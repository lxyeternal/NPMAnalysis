
let debug = false
if (debug) {
	var css = {
		bg: null,
		col: null,
		full: null,
		ps: null,
		move: null,
		scale: null,
		rotate: null,
		// border: null,
		img: null,
		//------
		webkitAppearance: 'none',
		webkitTapHighlightColor: 'transparent',
		webkitTouchCallout: 'none',
		webkitTransformStyle: 'preserve-3d',
		webkitBackfaceVisibility: 'hidden',
		webkitUserSelect: 'none',	/*webkit浏览器*/
		WebkitFilter: 'blur(10px)',
		webkitBackdropFilter: 'blur(15px)',
		webkitOverflowScrolling: 'touch',
		mozUserSelect: 'none',	/*火狐*/
		msUserSelect: 'none',	/*IE10*/
		userSelect: 'none',
		onselectstart: 'none',
		borderRadius: 0,
		transform3d: '',
		/**
		 * Aligns a flex container's lines within the flex container when there is extra space in the cross-axis, similar to how justify-content aligns individual items within the main-axis.
		 */
		alignContent: null,

		/**
		 * Sets the default alignment in the cross axis for all of the flex container's items, including anonymous flex items, similarly to how justify-content aligns items along the main axis.
		 */
		alignItems: null,

		/**
		 * Allows the default alignment to be overridden for individual flex items.
		 */
		alignSelf: null,

		/**
		 * This property allows precise alignment of elements, such as graphics, that do not have a baseline-table or lack the desired baseline in their baseline-table. With the alignment-adjust property, the position of the baseline identified by the alignment-baseline can be explicitly determined. It also determines precisely the alignment point for each glyph within a textual element.
		 */
		alignmentAdjust: null,

		alignmentBaseline: null,

		/**
		 * Defines a length of time to elapse before an animation starts, allowing an animation to begin execution some time after it is applied.
		 */
		animationDelay: null,

		/**
		 * Defines whether an animation should run in reverse on some or all cycles.
		 */
		animationDirection: null,

		/**
		 * Specifies how many times an animation cycle should play.
		 */
		animationIterationCount: null,

		/**
		 * Defines the list of animations that apply to the element.
		 */
		animationName: null,

		/**
		 * Defines whether an animation is running or paused.
		 */
		animationPlayState: null,

		/**
		 * Allows changing the style of any element to platform-based interface elements or vice versa.
		 */
		appearance: null,

		/**
		 * Determines whether or not the “back” side of a transformed element is visible when facing the viewer.
		 */
		backfaceVisibility: null,

		/**
		 * Shorthand property to set the values for one or more of:
		 * background-clip, background-color, background-image,
		 * background-origin, background-position, background-repeat,
		 * background-size, and background-attachment.
		 */
		background: null,

		/**
		 * If a background-image is specified, this property determines
		 * whether that image's position is fixed within the viewport,
		 * or scrolls along with its containing block.
		 */
		backgroundAttachment: "scroll" || "fixed" || "local",

		/**
		 * This property describes how the element's background images should blend with each other and the element's background color.
		 * The value is a list of blend modes that corresponds to each background image. Each element in the list will apply to the corresponding element of background-image. If a property doesn’t have enough comma-separated values to match the 0 of layers, the UA must calculate its used value by repeating the list of values until there are enough.
		 */
		backgroundBlendMode: null,

		/**
		 * Sets the background color of an element.
		 */
		backgroundColor: null,

		backgroundComposite: null,

		/**
		 * Applies one or more background images to an element. These can be any valid CSS image, including url() paths to image files or CSS gradients.
		 */
		backgroundImage: null,

		/**
		 * Specifies what the background-position property is relative to.
		 */
		backgroundOrigin: null,

		/**
		 * Sets the position of a background image.
		 */
		backgroundPosition: null,

		/**
		 * Background-repeat defines if and how background images will be repeated after they have been sized and positioned
		 */
		backgroundRepeat: null,

		/**
		 * Obsolete - spec retired, not implemented.
		 */
		baselineShift: null,

		/**
		 * Non standard. Sets or retrieves the location of the Dynamic HTML (DHTML) behavior.
		 */
		behavior: null,

		/**
		 * Shorthand property that defines the different properties of all four sides of an element's border in a single declaration. It can be used to set border-width, border-style and border-color, or a subset of these.
		 */
		border: null,

		/**
		 * Shorthand that sets the values of border-bottom-color,
		 * border-bottom-style, and border-bottom-width.
		 */
		borderBottom: null,

		/**
		 * Sets the color of the bottom border of an element.
		 */
		borderBottomColor: null,

		/**
		 * Defines the shape of the border of the bottom-left corner.
		 */
		borderBottomLeftRadius: null,

		/**
		 * Defines the shape of the border of the bottom-right corner.
		 */
		borderBottomRightRadius: null,

		/**
		 * Sets the line style of the bottom border of a box.
		 */
		borderBottomStyle: null,

		/**
		 * Sets the width of an element's bottom border. To set all four borders, use the border-width shorthand property which sets the values simultaneously for border-top-width, border-right-width, border-bottom-width, and border-left-width.
		 */
		borderBottomWidth: null,

		/**
		 * Border-collapse can be used for collapsing the borders between table cells
		 */
		borderCollapse: null,

		/**
		 * The CSS border-color property sets the color of an element's four borders. This property can have from one to four values, made up of the elementary properties:     •       border-top-color
		 *      •       border-right-color
		 *      •       border-bottom-color
		 *      •       border-left-color The default color is the currentColor of each of these values.
		 * If you provide one value, it sets the color for the element. Two values set the horizontal and vertical values, respectively. Providing three values sets the top, vertical, and bottom values, in that order. Four values set all for sides: top, right, bottom, and left, in that order.
		 */
		borderColor: null,

		/**
		 * Specifies different corner clipping effects, such as scoop (inner curves), bevel (straight cuts) or notch (cut-off rectangles). Works along with border-radius to specify the size of each corner effect.
		 */
		borderCornerShape: null,

		/**
		 * The property border-image-source is used to set the image to be used instead of the border style. If this is set to none the border-style is used instead.
		 */
		borderImageSource: null,

		/**
		 * The border-image-width CSS property defines the offset to use for dividing the border image in nine parts, the top-left corner, central top edge, top-right-corner, central right edge, bottom-right corner, central bottom edge, bottom-left corner, and central right edge. They represent inward distance from the top, right, bottom, and left edges.
		 */
		borderImageWidth: null,

		/**
		 * Shorthand property that defines the border-width, border-style and border-color of an element's left border in a single declaration. Note that you can use the corresponding longhand properties to set specific individual properties of the left border — border-left-width, border-left-style and border-left-color.
		 */
		borderLeft: null,

		/**
		 * The CSS border-left-color property sets the color of an element's left border. This page explains the border-left-color value, but often you will find it more convenient to fix the border's left color as part of a shorthand set, either border-left or border-color.
		 * Colors can be defined several ways. For more information, see Usage.
		 */
		borderLeftColor: null,

		/**
		 * Sets the style of an element's left border. To set all four borders, use the shorthand property, border-style. Otherwise, you can set the borders individually with border-top-style, border-right-style, border-bottom-style, border-left-style.
		 */
		borderLeftStyle: null,

		/**
		 * Sets the width of an element's left border. To set all four borders, use the border-width shorthand property which sets the values simultaneously for border-top-width, border-right-width, border-bottom-width, and border-left-width.
		 */
		borderLeftWidth: null,

		/**
		 * Shorthand property that defines the border-width, border-style and border-color of an element's right border in a single declaration. Note that you can use the corresponding longhand properties to set specific individual properties of the right border — border-right-width, border-right-style and border-right-color.
		 */
		borderRight: null,

		/**
		 * Sets the color of an element's right border. This page explains the border-right-color value, but often you will find it more convenient to fix the border's right color as part of a shorthand set, either border-right or border-color.
		 * Colors can be defined several ways. For more information, see Usage.
		 */
		borderRightColor: null,

		/**
		 * Sets the style of an element's right border. To set all four borders, use the shorthand property, border-style. Otherwise, you can set the borders individually with border-top-style, border-right-style, border-bottom-style, border-left-style.
		 */
		borderRightStyle: null,

		/**
		 * Sets the width of an element's right border. To set all four borders, use the border-width shorthand property which sets the values simultaneously for border-top-width, border-right-width, border-bottom-width, and border-left-width.
		 */
		borderRightWidth: null,

		/**
		 * Specifies the distance between the borders of adjacent cells.
		 */
		borderSpacing: null,

		/**
		 * Sets the style of an element's four borders. This property can have from one to four values. With only one value, the value will be applied to all four borders, otherwise, this works as a shorthand property for each of border-top-style, border-right-style, border-bottom-style, border-left-style, where each border style may be assigned a separate value.
		 */
		borderStyle: null,

		/**
		 * Shorthand property that defines the border-width, border-style and border-color of an element's top border in a single declaration. Note that you can use the corresponding longhand properties to set specific individual properties of the top border — border-top-width, border-top-style and border-top-color.
		 */
		borderTop: null,

		/**
		 * Sets the color of an element's top border. This page explains the border-top-color value, but often you will find it more convenient to fix the border's top color as part of a shorthand set, either border-top or border-color.
		 * Colors can be defined several ways. For more information, see Usage.
		 */
		borderTopColor: null,

		/**
		 * Sets the rounding of the top-left corner of the element.
		 */
		borderTopLeftRadius: null,

		/**
		 * Sets the rounding of the top-right corner of the element.
		 */
		borderTopRightRadius: null,

		/**
		 * Sets the style of an element's top border. To set all four borders, use the shorthand property, border-style. Otherwise, you can set the borders individually with border-top-style, border-right-style, border-bottom-style, border-left-style.
		 */
		borderTopStyle: null,

		/**
		 * Sets the width of an element's top border. To set all four borders, use the border-width shorthand property which sets the values simultaneously for border-top-width, border-right-width, border-bottom-width, and border-left-width.
		 */
		borderTopWidth: null,

		/**
		 * Sets the width of an element's four borders. This property can have from one to four values. This is a shorthand property for setting values simultaneously for border-top-width, border-right-width, border-bottom-width, and border-left-width.
		 */
		borderWidth: null,

		/**
		 * This property specifies how far an absolutely positioned box's bottom margin edge is offset above the bottom edge of the box's containing block. For relatively positioned boxes, the offset is with respect to the bottom edges of the box itself (i.e., the box is given a position in the normal flow, then offset from that position according to these properties).
		 */
		bottom: null,

		/**
		 * Obsolete.
		 */
		boxAlign: null,

		/**
		 * Breaks a box into fragments creating new borders, padding and repeating backgrounds or lets it stay as a continuous box on a page break, column break, or, for inline elements, at a line break.
		 */
		boxDecorationBreak: null,

		/**
		 * Deprecated
		 */
		boxDirection: null,

		/**
		 * Do not use. This property has been replaced by the flex-wrap property.
		 * Gets or sets a value that specifies the direction to add successive rows or columns when the value of box-lines is set to multiple.
		 */
		boxLineProgression: null,

		/**
		 * Do not use. This property has been replaced by the flex-wrap property.
		 * Gets or sets a value that specifies whether child elements wrap onto multiple lines or columns based on the space available in the object.
		 */
		boxLines: null,

		/**
		 * Do not use. This property has been replaced by flex-order.
		 * Specifies the ordinal group that a child element of the object belongs to. This ordinal value identifies the display order (along the axis defined by the box-orient property) for the group.
		 */
		boxOrdinalGroup: null,

		/**
		 * Deprecated.
		 */
		boxFlex: 0,

		/**
		 * Deprecated.
		 */
		boxFlexGroup: 0,

		/**
		 * The CSS break-after property allows you to force a break on multi-column layouts. More specifically, it allows you to force a break after an element. It allows you to determine if a break should occur, and what type of break it should be. The break-after CSS property describes how the page, column or region break behaves after the generated box. If there is no generated box, the property is ignored.
		 */
		breakAfter: null,

		/**
		 * Control page/column/region breaks that fall above a block of content
		 */
		breakBefore: null,

		/**
		 * Control page/column/region breaks that fall within a block of content
		 */
		breakInside: null,

		/**
		 * The clear CSS property specifies if an element can be positioned next to or must be positioned below the floating elements that precede it in the markup.
		 */
		clear: null,

		/**
		 * Deprecated, see clip-path.
		 * Lets you specify the dimensions of an absolutely positioned element that should be visible, and the element is clipped into this shape, and displayed.
		 */
		clip: null,

		/**
		 * Clipping crops an graphic, so that only a portion of the graphic is rendered, or filled. This clip-rule property, when used with the clip-path property, defines which clip rule, or algorithm, to use when filling the different parts of a graphics.
		 */
		clipRule: null,

		/**
		 * The color property sets the color of an element's foreground content (usually text), accepting any standard CSS color from keywords and hex values to RGB(a) and HSL(a).
		 */
		color: null,

		/**
		 * Describes the 0 of columns of the element.
		 */
		columnCount: 0,

		/**
		 * Specifies how to fill columns (balanced or sequential).
		 */
		columnFill: null,

		/**
		 * The column-gap property controls the width of the gap between columns in multi-column elements.
		 */
		columnGap: null,

		/**
		 * Sets the width, style, and color of the rule between columns.
		 */
		columnRule: null,

		/**
		 * Specifies the color of the rule between columns.
		 */
		columnRuleColor: null,

		/**
		 * Specifies the width of the rule between columns.
		 */
		columnRuleWidth: null,

		/**
		 * The column-span CSS property makes it possible for an element to span across all columns when its value is set to all. An element that spans more than one column is called a spanning element.
		 */
		columnSpan: null,

		/**
		 * Specifies the width of columns in multi-column elements.
		 */
		columnWidth: null,

		/**
		 * This property is a shorthand property for setting column-width and/or column-count.
		 */
		columns: null,

		/**
		 * The counter-increment property accepts one or more names of counters (identifiers), each one optionally followed by an integer which specifies the value by which the counter should be incremented (e.g. if the value is 2, the counter increases by 2 each time it is invoked).
		 */
		counterIncrement: null,

		/**
		 * The counter-reset property contains a list of one or more names of counters, each one optionally followed by an integer (otherwise, the integer defaults to 0.) Each time the given element is invoked, the counters specified by the property are set to the given integer.
		 */
		counterReset: null,

		/**
		 * The cue property specifies sound files (known as an "auditory icon") to be played by speech media agents before and after presenting an element's content, if only one file is specified, it is played both before and after. The volume at which the file(s) should be played, relative to the volume of the main element, may also be specified. The icon files may also be set separately with the cue-before and cue-after properties.
		 */
		cue: null,

		/**
		 * The cue-after property specifies a sound file (known as an "auditory icon") to be played by speech media agents after presenting an element's content, the volume at which the file should be played may also be specified. The shorthand property cue sets cue sounds for both before and after the element is presented.
		 */
		cueAfter: null,

		/**
		 * Specifies the mouse cursor displayed when the mouse pointer is over an element.
		 */
		cursor: null,

		/**
		 * The direction CSS property specifies the text direction/writing direction. The rtl is used for Hebrew or Arabic text, the ltr is for other languages.
		 */
		direction: null,

		/**
		 * This property specifies the type of rendering box used for an element. It is a shorthand property for many other display properties.
		 */
		display: null,

		/**
		 * The ‘fill’ property paints the interior of the given graphical element. The area to be painted consists of any areas inside the outline of the shape. To determine the inside of the shape, all subpaths are considered, and the interior is determined according to the rules associated with the current value of the ‘fill-rule’ property. The zero-width geometric outline of a shape is included in the area to be painted.
		 */
		fill: null,

		/**
		 * SVG: Specifies the opacity of the color or the content the current object is filled with.
		 */
		fillOpacity: 0,

		/**
		 * The ‘fill-rule’ property indicates the algorithm which is to be used to determine what parts of the canvas are included inside the shape. For a simple, non-intersecting path, it is intuitively clear what region lies "inside", however, for a more complex path, such as a path that intersects itself or where one subpath encloses another, the interpretation of "inside" is not so obvious.
		 * The ‘fill-rule’ property provides two options for how the inside of a shape is determined:
		 */
		fillRule: null,

		/**
		 * Applies various image processing effects. This property is largely unsupported. See Compatibility section for more information.
		 */
		filter: null,

		/**
		 * Shorthand for `flex-grow`, `flex-shrink`, and `flex-basis`.
		 */
		flex: 0,

		/**
		 * Obsolete, do not use. This property has been renamed to align-items.
		 * Specifies the alignment (perpendicular to the layout axis defined by the flex-direction property) of child elements of the object.
		 */
		flexAlign: null,

		/**
		 * The flex-basis CSS property describes the initial main size of the flex item before any free space is distributed according to the flex factors described in the flex property (flex-grow and flex-shrink).
		 */
		flexBasis: null,

		/**
		 * The flex-direction CSS property describes how flex items are placed in the flex container, by setting the direction of the flex container's main axis.
		 */
		flexDirection: null,

		/**
		 * The flex-flow CSS property defines the flex container's main and cross axis. It is a shorthand property for the flex-direction and flex-wrap properties.
		 */
		flexFlow: null,

		/**
		 * Specifies the flex grow factor of a flex item.
		 */
		flexGrow: 0,

		/**
		 * Do not use. This property has been renamed to align-self
		 * Specifies the alignment (perpendicular to the layout axis defined by flex-direction) of child elements of the object.
		 */
		flexItemAlign: null,

		/**
		 * Do not use. This property has been renamed to align-content.
		 * Specifies how a flexbox's lines align within the flexbox when there is extra space along the axis that is perpendicular to the axis defined by the flex-direction property.
		 */
		flexLinePack: null,

		/**
		 * Gets or sets a value that specifies the ordinal group that a flexbox element belongs to. This ordinal value identifies the display order for the group.
		 */
		flexOrder: null,

		/**
		 * Specifies the flex shrink factor of a flex item.
		 */
		flexShrink: 0,

		/**
		 * Elements which have the style float are floated horizontally. These elements can move as far to the left or right of the containing element. All elements after the floating element will flow around it, but elements before the floating element are not impacted. If several floating elements are placed after each other, they will float next to each other as long as there is room.
		 */
		float: null,

		/**
		 * Flows content from a named flow (specified by a corresponding flow-into) through selected elements to form a dynamic chain of layout regions.
		 */
		flowFrom: null,

		/**
		 * The font property is shorthand that allows you to do one of two things: you can either set up six of the most mature font properties in one line, or you can set one of a choice of keywords to adopt a system font setting.
		 */
		font: null,

		/**
		 * The font-family property allows one or more font family names and/or generic family names to be specified for usage on the selected element(s)' text. The browser then goes through the list; for each character in the selection it applies the first font family that has an available glyph for that character.
		 */
		fontFamily: null,

		/**
		 * The font-kerning property allows contextual adjustment of inter-glyph spacing, i.e. the spaces between the characters in text. This property controls <bold>metric kerning</bold> - that utilizes adjustment data contained in the font. Optical Kerning is not supported as yet.
		 */
		fontKerning: null,

		/**
		 * Specifies the size of the font. Used to compute em and ex units.
		 */
		fontSize: 0,

		/**
		 * The font-size-adjust property adjusts the font-size of the fallback fonts defined with font-family, so that the x-height is the same no matter what font is used. This preserves the readability of the text when fallback happens.
		 */
		fontSizeAdjust: null,

		/**
		 * Allows you to expand or condense the widths for a normal, condensed, or expanded font face.
		 */
		fontStretch: null,

		/**
		 * The font-style property allows normal, italic, or oblique faces to be selected. Italic forms are generally cursive in nature while oblique faces are typically sloped versions of the regular face. Oblique faces can be simulated by artificially sloping the glyphs of the regular face.
		 */
		fontStyle: null,

		/**
		 * This value specifies whether the user agent is allowed to synthesize bold or oblique font faces when a font family lacks bold or italic faces.
		 */
		fontSynthesis: null,

		/**
		 * The font-variant property enables you to select the small-caps font within a font family.
		 */
		fontVariant: null,

		/**
		 * Fonts can provide alternate glyphs in addition to default glyph for a character. This property provides control over the selection of these alternate glyphs.
		 */
		fontVariantAlternates: null,

		/**
		 * Specifies the weight or boldness of the font.
		 */
		fontWeight: "normal" || "bold" || "lighter" || "bolder" || "0",

		/**
		 * Lays out one or more grid items bound by 4 grid lines. Shorthand for setting grid-column-start, grid-column-end, grid-row-start, and grid-row-end in a single declaration.
		 */
		gridArea: null,

		/**
		 * Controls a grid item's placement in a grid area, particularly grid position and a grid span. Shorthand for setting grid-column-start and grid-column-end in a single declaration.
		 */
		gridColumn: null,

		/**
		 * Controls a grid item's placement in a grid area as well as grid position and a grid span. The grid-column-end property (with grid-row-start, grid-row-end, and grid-column-start) determines a grid item's placement by specifying the grid lines of a grid item's grid area.
		 */
		gridColumnEnd: null,

		/**
		 * Determines a grid item's placement by specifying the starting grid lines of a grid item's grid area . A grid item's placement in a grid area consists of a grid position and a grid span. See also ( grid-row-start, grid-row-end, and grid-column-end)
		 */
		gridColumnStart: null,

		/**
		 * Gets or sets a value that indicates which row an element within a Grid should appear in. Shorthand for setting grid-row-start and grid-row-end in a single declaration.
		 */
		gridRow: null,

		/**
		 * Determines a grid item’s placement by specifying the block-end. A grid item's placement in a grid area consists of a grid position and a grid span. The grid-row-end property (with grid-row-start, grid-column-start, and grid-column-end) determines a grid item's placement by specifying the grid lines of a grid item's grid area.
		 */
		gridRowEnd: null,

		/**
		 * Specifies a row position based upon an integer location, string value, or desired row size.
		 * css/properties/grid-row is used as short-hand for grid-row-position and grid-row-position
		 */
		gridRowPosition: null,

		gridRowSpan: null,

		/**
		 * Specifies named grid areas which are not associated with any particular grid item, but can be referenced from the grid-placement properties. The syntax of the grid-template-areas property also provides a visualization of the structure of the grid, making the overall layout of the grid container easier to understand.
		 */
		gridTemplateAreas: null,

		/**
		 * Specifies (with grid-template-rows) the line names and track sizing functions of the grid. Each sizing function can be specified as a length, a percentage of the grid container’s size, a measurement of the contents occupying the column or row, or a fraction of the free space in the grid.
		 */
		gridTemplateColumns: null,

		/**
		 * Specifies (with grid-template-columns) the line names and track sizing functions of the grid. Each sizing function can be specified as a length, a percentage of the grid container’s size, a measurement of the contents occupying the column or row, or a fraction of the free space in the grid.
		 */
		gridTemplateRows: null,

		/**
		 * Sets the height of an element. The content area of the element height does not include the padding, border, and margin of the element.
		 */
		height: null,

		/**
		 * Specifies the minimum 0 of characters in a hyphenated word
		 */
		hyphenateLimitChars: null,

		/**
		 * Indicates the maximum 0 of successive hyphenated lines in an element. The ‘no-limit’ value means that there is no limit.
		 */
		hyphenateLimitLines: null,

		/**
		 * Specifies the maximum amount of trailing whitespace (before justification) that may be left in a line before hyphenation is triggered to pull part of a word from the next line back up into the current one.
		 */
		hyphenateLimitZone: null,

		/**
		 * Specifies whether or not words in a sentence can be split by the use of a manual or automatic hyphenation mechanism.
		 */
		hyphens: null,

		imeMode: null,

		/**
		 * Defines how the browser distributes space between and around flex items
		 * along the main-axis of their container.
		 */
		justifyContent: "flex-start" || "flex-end" || "center" || "space-between" || "space-around",

		layoutGrid: null,

		layoutGridChar: null,

		layoutGridLine: null,

		layoutGridMode: null,

		layoutGridType: null,

		/**
		 * Sets the left edge of an element
		 */
		left: null,

		/**
		 * The letter-spacing CSS property specifies the spacing behavior between text characters.
		 */
		letterSpacing: null,

		/**
		 * Deprecated. Gets or sets line-breaking rules for text in selected languages such as Japanese, Chinese, and Korean.
		 */
		lineBreak: null,

		lineClamp: 0,

		/**
		 * Specifies the height of an inline block level element.
		 */
		lineHeight: 0,

		/**
		 * Shorthand property that sets the list-style-type, list-style-position and list-style-image properties in one declaration.
		 */
		listStyle: null,

		/**
		 * This property sets the image that will be used as the list item marker. When the image is available, it will replace the marker set with the 'list-style-type' marker. That also means that if the image is not available, it will show the style specified by list-style-property
		 */
		listStyleImage: null,

		/**
		 * Specifies if the list-item markers should appear inside or outside the content flow.
		 */
		listStylePosition: null,

		/**
		 * Specifies the type of list-item marker in a list.
		 */
		listStyleType: null,

		/**
		 * The margin property is shorthand to allow you to set all four margins of an element at once. Its equivalent longhand properties are margin-top, margin-right, margin-bottom and margin-left. Negative values are also allowed.
		 */
		margin: null,

		/**
		 * margin-bottom sets the bottom margin of an element.
		 */
		marginBottom: null,

		/**
		 * margin-left sets the left margin of an element.
		 */
		marginLeft: null,

		/**
		 * margin-right sets the right margin of an element.
		 */
		marginRight: null,

		/**
		 * margin-top sets the top margin of an element.
		 */
		marginTop: null,

		/**
		 * The marquee-direction determines the initial direction in which the marquee content moves.
		 */
		marqueeDirection: null,

		/**
		 * The 'marquee-style' property determines a marquee's scrolling behavior.
		 */
		marqueeStyle: null,

		/**
		 * This property is shorthand for setting mask-image, mask-mode, mask-repeat, mask-position, mask-clip, mask-origin, mask-composite and mask-size. Omitted values are set to their original properties' initial values.
		 */
		mask: null,

		/**
		 * This property is shorthand for setting mask-border-source, mask-border-slice, mask-border-width, mask-border-outset, and mask-border-repeat. Omitted values are set to their original properties' initial values.
		 */
		maskBorder: null,

		/**
		 * This property specifies how the images for the sides and the middle part of the mask image are scaled and tiled. The first keyword applies to the horizontal sides, the second one applies to the vertical ones. If the second keyword is absent, it is assumed to be the same as the first, similar to the CSS border-image-repeat property.
		 */
		maskBorderRepeat: null,

		/**
		 * This property specifies inward offsets from the top, right, bottom, and left edges of the mask image, dividing it into nine regions: four corners, four edges, and a middle. The middle image part is discarded and treated as fully transparent black unless the fill keyword is present. The four values set the top, right, bottom and left offsets in that order, similar to the CSS border-image-slice property.
		 */
		maskBorderSlice: null,

		/**
		 * Specifies an image to be used as a mask. An image that is empty, fails to download, is non-existent, or cannot be displayed is ignored and does not mask the element.
		 */
		maskBorderSource: null,

		/**
		 * This property sets the width of the mask box image, similar to the CSS border-image-width property.
		 */
		maskBorderWidth: null,

		/**
		 * Determines the mask painting area, which defines the area that is affected by the mask. The painted content of an element may be restricted to this area.
		 */
		maskClip: null,

		/**
		 * For elements rendered as a single box, specifies the mask positioning area. For elements rendered as multiple boxes (e.g., inline boxes on several lines, boxes on several pages) specifies which boxes box-decoration-break operates on to determine the mask positioning area(s).
		 */
		maskOrigin: null,

		/**
		 * This property must not be used. It is no longer included in any standard or standard track specification, nor is it implemented in any browser. It is only used when the text-align-last property is set to size. It controls allowed adjustments of font-size to fit line content.
		 */
		maxFontSize: null,

		/**
		 * Sets the maximum height for an element. It prevents the height of the element to exceed the specified value. If min-height is specified and is greater than max-height, max-height is overridden.
		 */
		maxHeight: null,

		/**
		 * Sets the maximum width for an element. It limits the width property to be larger than the value specified in max-width.
		 */
		maxWidth: null,

		/**
		 * Sets the minimum height for an element. It prevents the height of the element to be smaller than the specified value. The value of min-height overrides both max-height and height.
		 */
		minHeight: null,

		/**
		 * Sets the minimum width of an element. It limits the width property to be not smaller than the value specified in min-width.
		 */
		minWidth: null,

		/**
		 * Specifies the transparency of an element.
		 */
		opacity: 0,

		/**
		 * Specifies the order used to lay out flex items in their flex container.
		 * Elements are laid out in the ascending order of the order value.
		 */
		order: 0,

		/**
		 * In paged media, this property defines the minimum 0 of lines in
		 * a block container that must be left at the bottom of the page.
		 */
		orphans: 0,

		/**
		 * The CSS outline property is a shorthand property for setting one or more of the individual outline properties outline-style, outline-width and outline-color in a single rule. In most cases the use of this shortcut is preferable and more convenient.
		 * Outlines differ from borders in the following ways:  •       Outlines do not take up space, they are drawn above the content.
		 *      •       Outlines may be non-rectangular. They are rectangular in Gecko/Firefox. Internet Explorer attempts to place the smallest contiguous outline around all elements or shapes that are indicated to have an outline. Opera draws a non-rectangular shape around a construct.
		 */
		outline: null,

		/**
		 * The outline-color property sets the color of the outline of an element. An outline is a line that is drawn around elements, outside the border edge, to make the element stand out.
		 */
		outlineColor: null,

		/**
		 * The outline-offset property offsets the outline and draw it beyond the border edge.
		 */
		outlineOffset: null,

		/**
		 * The overflow property controls how extra content exceeding the bounding box of an element is rendered. It can be used in conjunction with an element that has a fixed width and height, to eliminate text-induced page distortion.
		 */
		overflow: null,

		/**
		 * Specifies the preferred scrolling methods for elements that overflow.
		 */
		overflowStyle: null,

		/**
		 * Controls how extra content exceeding the x-axis of the bounding box of an element is rendered.
		 */
		overflowX: null,

		/**
		 * Controls how extra content exceeding the y-axis of the bounding box of an element is rendered.
		 */
		overflowY: null,

		/**
		 * The padding optional CSS property sets the required padding space on one to four sides of an element. The padding area is the space between an element and its border. Negative values are not allowed but decimal values are permitted. The element size is treated as fixed, and the content of the element shifts toward the center as padding is increased.
		 * The padding property is a shorthand to avoid setting each side separately (padding-top, padding-right, padding-bottom, padding-left).
		 */
		padding: null,

		/**
		 * The padding-bottom CSS property of an element sets the padding space required on the bottom of an element. The padding area is the space between the content of the element and its border. Contrary to margin-bottom values, negative values of padding-bottom are invalid.
		 */
		paddingBottom: null,

		/**
		 * The padding-left CSS property of an element sets the padding space required on the left side of an element. The padding area is the space between the content of the element and its border. Contrary to margin-left values, negative values of padding-left are invalid.
		 */
		paddingLeft: null,

		/**
		 * The padding-right CSS property of an element sets the padding space required on the right side of an element. The padding area is the space between the content of the element and its border. Contrary to margin-right values, negative values of padding-right are invalid.
		 */
		paddingRight: null,

		/**
		 * The padding-top CSS property of an element sets the padding space required on the top of an element. The padding area is the space between the content of the element and its border. Contrary to margin-top values, negative values of padding-top are invalid.
		 */
		paddingTop: null,

		/**
		 * The page-break-after property is supported in all major browsers. With CSS3, page-break-* properties are only aliases of the break-* properties. The CSS3 Fragmentation spec defines breaks for all CSS box fragmentation.
		 */
		pageBreakAfter: null,

		/**
		 * The page-break-before property sets the page-breaking behavior before an element. With CSS3, page-break-* properties are only aliases of the break-* properties. The CSS3 Fragmentation spec defines breaks for all CSS box fragmentation.
		 */
		pageBreakBefore: null,

		/**
		 * Sets the page-breaking behavior inside an element. With CSS3, page-break-* properties are only aliases of the break-* properties. The CSS3 Fragmentation spec defines breaks for all CSS box fragmentation.
		 */
		pageBreakInside: null,

		/**
		 * The pause property determines how long a speech media agent should pause before and after presenting an element. It is a shorthand for the pause-before and pause-after properties.
		 */
		pause: null,

		/**
		 * The pause-after property determines how long a speech media agent should pause after presenting an element. It may be replaced by the shorthand property pause, which sets pause time before and after.
		 */
		pauseAfter: null,

		/**
		 * The pause-before property determines how long a speech media agent should pause before presenting an element. It may be replaced by the shorthand property pause, which sets pause time before and after.
		 */
		pauseBefore: null,

		/**
		 * The perspective property defines how far an element is placed from the view on the z-axis, from the screen to the viewer.
		 * Perspective defines how an object is viewed. In graphic arts, perspective is the representation on a flat surface of what the viewer's eye would see in a 3D space. (See Wikipedia for more information about graphical perspective and for related illustrations.)
		 * The illusion of perspective on a flat surface, such as a computer screen, is created by projecting points on the flat surface as they would appear if the flat surface were a window through which the viewer was looking at the object. In discussion of virtual environments, this flat surface is called a projection plane.
		 */
		perspective: null,

		/**
		 * The perspective-origin property establishes the origin for the perspective property. It effectively sets the X and Y position at which the viewer appears to be looking at the children of the element.
		 * When used with perspective, perspective-origin changes the appearance of an object, as if a viewer were looking at it from a different origin. An object appears differently if a viewer is looking directly at it versus looking at it from below, above, or from the side. Thus, the perspective-origin is like a vanishing point.
		 * The default value of perspective-origin is 50% 50%. This displays an object as if the viewer's eye were positioned directly at the center of the screen, both top-to-bottom and left-to-right. A value of 0% 0% changes the object as if the viewer was looking toward the top left angle. A value of 100% 100% changes the appearance as if viewed toward the bottom right angle.
		 */
		perspectiveOrigin: null,

		/**
		 * The pointer-events property allows you to control whether an element can be the target for the pointing device (e.g, mouse, pen) events.
		 */
		pointerEvents: null,

		/**
		 * The position property controls the type of positioning used by an element within its parent elements. The effect of the position property depends on a lot of factors, for example the position property of parent elements.
		 */
		position: null,

		/**
		 * Obsolete: unsupported.
		 * This property determines whether or not a full-width punctuation mark character should be trimmed if it appears at the beginning of a line, so that its "ink" lines up with the first glyph in the line above and below.
		 */
		punctuationTrim: null,

		/**
		 * Sets the type of quotation marks for embedded quotations.
		 */
		quotes: null,

		/**
		 * Controls whether the last region in a chain displays additional 'overset' content according its default overflow property, or if it displays a fragment of content as if it were flowing into a subsequent region.
		 */
		regionFragment: null,

		/**
		 * The rest-after property determines how long a speech media agent should pause after presenting an element's main content, before presenting that element's exit cue sound. It may be replaced by the shorthand property rest, which sets rest time before and after.
		 */
		restAfter: null,

		/**
		 * The rest-before property determines how long a speech media agent should pause after presenting an intro cue sound for an element, before presenting that element's main content. It may be replaced by the shorthand property rest, which sets rest time before and after.
		 */
		restBefore: null,

		/**
		 * Specifies the position an element in relation to the right side of the containing element.
		 */
		right: null,

		rubyAlign: null,

		rubyPosition: null,

		/**
		 * Defines the alpha channel threshold used to extract a shape from an image. Can be thought of as a "minimum opacity" threshold; that is, a value of 0.5 means that the shape will enclose all the pixels that are more than 50% opaque.
		 */
		shapeImageThreshold: null,

		/**
		 * A future level of CSS Shapes will define a shape-inside property, which will define a shape to wrap content within the element. See Editor's Draft <http://dev.w3.org/csswg/css-shapes/> and CSSWG wiki page on next-level plans <http://wiki.csswg.org/spec/css-shapes>
		 */
		shapeInside: null,

		/**
		 * Adds a margin to a shape-outside. In effect, defines a new shape that is the smallest contour around all the points that are the shape-margin distance outward perpendicular to each point on the underlying shape. For points where a perpendicular direction is not defined (e.g., a triangle corner), takes all points on a circle centered at the point and with a radius of the shape-margin distance. This property accepts only non-negative values.
		 */
		shapeMargin: null,

		/**
		 * Declares a shape around which text should be wrapped, with possible modifications from the shape-margin property. The shape defined by shape-outside and shape-margin changes the geometry of a float element's float area.
		 */
		shapeOutside: null,

		/**
		 * The speak property determines whether or not a speech synthesizer will read aloud the contents of an element.
		 */
		speak: null,

		/**
		 * The speak-as property determines how the speech synthesizer interprets the content: words as whole words or as a sequence of letters, numbers as a numerical value or a sequence of digits, punctuation as pauses in speech or named punctuation characters.
		 */
		speakAs: null,

		/**
		 * SVG: Specifies the opacity of the outline on the current object.
		 */
		strokeOpacity: 0,

		/**
		 * SVG: Specifies the width of the outline on the current object.
		 */
		strokeWidth: 0,

		/**
		 * The tab-size CSS property is used to customise the width of a tab (U+0009) character.
		 */
		tabSize: null,

		/**
		 * The 'table-layout' property controls the algorithm used to lay out the table cells, rows, and columns.
		 */
		tableLayout: null,

		/**
		 * The text-align CSS property describes how inline content like text is aligned in its parent block element. text-align does not control the alignment of block elements itself, only their inline content.
		 */
		textAlign: null,

		/**
		 * The text-align-last CSS property describes how the last line of a block element or a line before line break is aligned in its parent block element.
		 */
		textAlignLast: null,

		/**
		 * The text-decoration CSS property is used to set the text formatting to underline, overline, line-through or blink.
		 * underline and overline decorations are positioned under the text, line-through over it.
		 */
		textDecoration: null,

		/**
		 * Sets the color of any text decoration, such as underlines, overlines, and strike throughs.
		 */
		textDecorationColor: null,

		/**
		 * Sets what kind of line decorations are added to an element, such as underlines, overlines, etc.
		 */
		textDecorationLine: null,

		textDecorationLineThrough: null,

		textDecorationNone: null,

		textDecorationOverline: null,

		/**
		 * Specifies what parts of an element’s content are skipped over when applying any text decoration.
		 */
		textDecorationSkip: null,

		/**
		 * This property specifies the style of the text decoration line drawn on the specified element. The intended meaning for the values are the same as those of the border-style-properties.
		 */
		textDecorationStyle: null,

		textDecorationUnderline: null,

		/**
		 * The text-emphasis property will apply special emphasis marks to the elements text. Slightly similar to the text-decoration property only that this property can have affect on the line-height. It also is noted that this is shorthand for text-emphasis-style and for text-emphasis-color.
		 */
		textEmphasis: null,

		/**
		 * The text-emphasis-color property specifies the foreground color of the emphasis marks.
		 */
		textEmphasisColor: null,

		/**
		 * The text-emphasis-style property applies special emphasis marks to an element's text.
		 */
		textEmphasisStyle: null,

		/**
		 * This property helps determine an inline box's block-progression dimension, derived from the text-height and font-size properties for non-replaced elements, the height or the width for replaced elements, and the stacked block-progression dimension for inline-block elements. The block-progression dimension determines the position of the padding, border and margin for the element.
		 */
		textHeight: null,

		/**
		 * Specifies the amount of space horizontally that should be left on the first line of the text of an element. This horizontal spacing is at the beginning of the first line and is in respect to the left edge of the containing block box.
		 */
		textIndent: null,

		textJustifyTrim: null,

		textKashidaSpace: null,

		/**
		 * The text-line-through property is a shorthand property for text-line-through-style, text-line-through-color and text-line-through-mode. (Considered obsolete; use text-decoration instead.)
		 */
		textLineThrough: null,

		/**
		 * Specifies the line colors for the line-through text decoration.
		 * (Considered obsolete; use text-decoration-color instead.)
		 */
		textLineThroughColor: null,

		/**
		 * Sets the mode for the line-through text decoration, determining whether the text decoration affects the space characters or not.
		 * (Considered obsolete; use text-decoration-skip instead.)
		 */
		textLineThroughMode: null,

		/**
		 * Specifies the line style for line-through text decoration.
		 * (Considered obsolete; use text-decoration-style instead.)
		 */
		textLineThroughStyle: null,

		/**
		 * Specifies the line width for the line-through text decoration.
		 */
		textLineThroughWidth: null,

		/**
		 * The text-overflow shorthand CSS property determines how overflowed content that is not displayed is signaled to the users. It can be clipped, display an ellipsis ('…', U+2026 HORIZONTAL ELLIPSIS) or a Web author-defined string. It covers the two long-hand properties text-overflow-mode and text-overflow-ellipsis
		 */
		textOverflow: null,

		/**
		 * The text-overline property is the shorthand for the text-overline-style, text-overline-width, text-overline-color, and text-overline-mode properties.
		 */
		textOverline: null,

		/**
		 * Specifies the line color for the overline text decoration.
		 */
		textOverlineColor: null,

		/**
		 * Sets the mode for the overline text decoration, determining whether the text decoration affects the space characters or not.
		 */
		textOverlineMode: null,

		/**
		 * Specifies the line style for overline text decoration.
		 */
		textOverlineStyle: null,

		/**
		 * Specifies the line width for the overline text decoration.
		 */
		textOverlineWidth: null,

		/**
		 * The text-rendering CSS property provides information to the browser about how to optimize when rendering text. Options are: legibility, speed or geometric precision.
		 */
		textRendering: null,

		/**
		 * Obsolete: unsupported.
		 */
		textScript: null,

		/**
		 * The CSS text-shadow property applies one or more drop shadows to the text and <text-decorations> of an element. Each shadow is specified as an offset from the text, along with optional color and blur radius values.
		 */
		textShadow: null,

		/**
		 * This property transforms text for styling purposes. (It has no effect on the underlying content.)
		 */
		textTransform: null,

		/**
		 * Unsupported.
		 * This property will add a underline position value to the element that has an underline defined.
		 */
		textUnderlinePosition: null,

		/**
		 * After review this should be replaced by text-decoration should it not?
		 * This property will set the underline style for text with a line value for underline, overline, and line-through.
		 */
		textUnderlineStyle: null,

		/**
		 * This property specifies how far an absolutely positioned box's top margin edge is offset below the top edge of the box's containing block. For relatively positioned boxes, the offset is with respect to the top edges of the box itself (i.e., the box is given a position in the normal flow, then offset from that position according to these properties).
		 */
		top: null,

		/**
		 * Determines whether touch input may trigger default behavior supplied by the user agent, such as panning or zooming.
		 */
		touchAction: null,

		/**
		 * CSS transforms allow elements styled with CSS to be transformed in two-dimensional or three-dimensional space. Using this property, elements can be translated, rotated, scaled, and skewed. The value list may consist of 2D and/or 3D transform values.
		 */
		transform: null,

		/**
		 * This property defines the origin of the transformation axes relative to the element to which the transformation is applied.
		 */
		transformOrigin: null,

		/**
		 * This property allows you to define the relative position of the origin of the transformation grid along the z-axis.
		 */
		transformOriginZ: null,

		/**
		 * This property specifies how nested elements are rendered in 3D space relative to their parent.
		 */
		transformStyle: null,

		/**
		 * The transition CSS property is a shorthand property for transition-property, transition-duration, transition-timing-function, and transition-delay. It allows to define the transition between two states of an element.
		 */
		transition: null,

		/**
		 * Defines when the transition will start. A value of ‘0s’ means the transition will execute as soon as the property is changed. Otherwise, the value specifies an offset from the moment the property is changed, and the transition will delay execution by that offset.
		 */
		transitionDelay: null,

		/**
		 * The 'transition-duration' property specifies the length of time a transition animation takes to complete.
		 */
		transitionDuration: null,

		/**
		 * The 'transition-property' property specifies the name of the CSS property to which the transition is applied.
		 */
		transitionProperty: null,

		/**
		 * Sets the pace of action within a transition
		 */
		transitionTimingFunction: null,

		/**
		 * The unicode-bidi CSS property specifies the level of embedding with respect to the bidirectional algorithm.
		 */
		unicodeBidi: null,

		/**
		 * unicode-range allows you to set a specific range of characters to be downloaded from a font (embedded using @font-face) and made available for use on the current page.
		 */
		unicodeRange: null,

		/**
		 * This is for all the high level UX stuff.
		 */
		userFocus: null,

		/**
		 * For inputing user content
		 */
		userInput: null,

		/**
		 * The vertical-align property controls how inline elements or text are vertically aligned compared to the baseline. If this property is used on table-cells it controls the vertical alignment of content of the table cell.
		 */
		verticalAlign: null,

		/**
		 * The visibility property specifies whether the boxes generated by an element are rendered.
		 */
		visibility: null,

		/**
		 * The voice-balance property sets the apparent position (in stereo sound) of the synthesized voice for spoken media.
		 */
		voiceBalance: null,

		/**
		 * The voice-duration property allows the author to explicitly set the amount of time it should take a speech synthesizer to read an element's content, for example to allow the speech to be synchronized with other media. With a value of auto (the default) the length of time it takes to read the content is determined by the content itself and the voice-rate property.
		 */
		voiceDuration: null,

		/**
		 * The voice-family property sets the speaker's voice used by a speech media agent to read an element. The speaker may be specified as a named character (to match a voice option in the speech reading software) or as a generic description of the age and gender of the voice. Similar to the font-family property for visual media, a comma-separated list of fallback options may be given in case the speech reader does not recognize the character name or cannot synthesize the requested combination of generic properties.
		 */
		voiceFamily: null,

		/**
		 * The voice-pitch property sets pitch or tone (high or low) for the synthesized speech when reading an element; the pitch may be specified absolutely or relative to the normal pitch for the voice-family used to read the text.
		 */
		voicePitch: null,

		/**
		 * The voice-range property determines how much variation in pitch or tone will be created by the speech synthesize when reading an element. Emphasized text, grammatical structures and punctuation may all be rendered as changes in pitch, this property determines how strong or obvious those changes are; large ranges are associated with enthusiastic or emotional speech, while small ranges are associated with flat or mechanical speech.
		 */
		voiceRange: null,

		/**
		 * The voice-rate property sets the speed at which the voice synthesized by a speech media agent will read content.
		 */
		voiceRate: null,

		/**
		 * The voice-stress property sets the level of vocal emphasis to be used for synthesized speech reading the element.
		 */
		voiceStress: null,

		/**
		 * The voice-volume property sets the volume for spoken content in speech media. It replaces the deprecated volume property.
		 */
		voiceVolume: null,

		/**
		 * The white-space property controls whether and how white space inside the element is collapsed, and whether lines may wrap at unforced "soft wrap" opportunities.
		 */
		whiteSpace: null,

		/**
		 * Obsolete: unsupported.
		 */
		whiteSpaceTreatment: null,

		/**
		 * Specifies the width of the content area of an element. The content area of the element width does not include the padding, border, and margin of the element.
		 */
		width: null,

		/**
		 * In paged media, this property defines the mimimum number of lines
		 * that must be left at the top of the second page.
		 */
		// widows: 0,

		/**
		 * The word-break property is often used when there is long generated content that is strung together without and spaces or hyphens to beak apart. A common case of this is when there is a long URL that does not have any hyphens. This case could potentially cause the breaking of the layout as it could extend past the parent element.
		 */
		wordBreak: null,

		/**
		 * The word-spacing CSS property specifies the spacing behavior between "words".
		 */
		wordSpacing: null,

		/**
		 * An alias of css/properties/overflow-wrap, word-wrap defines whether to break words when the content exceeds the boundaries of its container.
		 */
		wordWrap: null,

		/**
		 * Specifies how exclusions affect inline content within block-level elements. Elements lay out their inline content in their content area but wrap around exclusion areas.
		 */
		wrapFlow: null,

		/**
		 * Set the value that is used to offset the inner wrap shape from other shapes. Inline content that intersects a shape with this property will be pushed by this shape's margin.
		 */
		wrapMargin: null,

		/**
		 * Obsolete and unsupported. Do not use.
		 * This CSS property controls the text when it reaches the end of the block in which it is enclosed.
		 */
		wrapOption: null,

		/**
		 * writing-mode specifies if lines of text are laid out horizontally or vertically, and the direction which lines of text and blocks progress.
		 */
		writingMode: null,

		/**
		 * The z-index property specifies the z-order of an element and its descendants.
		 * When elements overlap, z-order determines which one covers the other.
		 */
		zIndex: 0,

		/**
		 * Sets the initial zoom factor of a document defined by @viewport.
		 */
		zoom: 0
	}


	var propsNotCss = {
		placeholder: '',
		className: '',
		children: null,
		// Clipboard Events
		onCopy: null,
		onCopyCapture: null,
		onCut: null,
		onCutCapture: null,
		onPaste: null,
		onPasteCapture: null,

		// Composition Events
		onCompositionEnd: null,
		onCompositionEndCapture: null,
		onCompositionStart: null,
		onCompositionStartCapture: null,
		onCompositionUpdate: null,
		onCompositionUpdateCapture: null,

		// Focus Events
		onFocus: null,
		onFocusCapture: null,
		onBlur: null,
		onBlurCapture: null,

		// Form Events
		onChange: null,
		onChangeCapture: null,
		onInput: null,
		onInputCapture: null,
		onReset: null,
		onResetCapture: null,
		onSubmit: null,
		onSubmitCapture: null,

		// Image Events
		onLoad: null,
		onLoadCapture: null,
		onError: null,
		onErrorCapture: null,

		// Keyboard Events
		onKeyDown: null,
		onKeyDownCapture: null,
		onKeyPress: null,
		onKeyPressCapture: null,
		onKeyUp: null,
		onKeyUpCapture: null,

		// Media Events
		onAbort: null,
		onAbortCapture: null,
		onCanPlay: null,
		onCanPlayCapture: null,
		onCanPlayThrough: null,
		onCanPlayThroughCapture: null,
		onDurationChange: null,
		onDurationChangeCapture: null,
		onEmptied: null,
		onEmptiedCapture: null,
		onEncrypted: null,
		onEncryptedCapture: null,
		onEnded: null,
		onEndedCapture: null,
		onLoadedData: null,
		onLoadedDataCapture: null,
		onLoadedMetadata: null,
		onLoadedMetadataCapture: null,
		onLoadStart: null,
		onLoadStartCapture: null,
		onPause: null,
		onPauseCapture: null,
		onPlay: null,
		onPlayCapture: null,
		onPlaying: null,
		onPlayingCapture: null,
		onProgress: null,
		onProgressCapture: null,
		onRateChange: null,
		onRateChangeCapture: null,
		onSeeked: null,
		onSeekedCapture: null,
		onSeeking: null,
		onSeekingCapture: null,
		onStalled: null,
		onStalledCapture: null,
		onSuspend: null,
		onSuspendCapture: null,
		onTimeUpdate: null,
		onTimeUpdateCapture: null,
		onVolumeChange: null,
		onVolumeChangeCapture: null,
		onWaiting: null,
		onWaitingCapture: null,

		// MouseEvents
		onClick: null,
		onClickCapture: null,
		onContextMenu: null,
		onContextMenuCapture: null,
		onDoubleClick: null,
		onDoubleClickCapture: null,
		onDrag: null,
		onDragCapture: null,
		onDragEnd: null,
		onDragEndCapture: null,
		onDragEnter: null,
		onDragEnterCapture: null,
		onDragExit: null,
		onDragExitCapture: null,
		onDragLeave: null,
		onDragLeaveCapture: null,
		onDragOver: null,
		onDragOverCapture: null,
		onDragStart: null,
		onDragStartCapture: null,
		onDrop: null,
		onDropCapture: null,
		onMouseDown: null,
		onMouseDownCapture: null,
		onMouseEnter: null,
		onMouseLeave: null,
		onMouseMove: null,
		onMouseMoveCapture: null,
		onMouseOut: null,
		onMouseOutCapture: null,
		onMouseOver: null,
		onMouseOverCapture: null,
		onMouseUp: null,
		onMouseUpCapture: null,

		// Selection Events
		onSelect: null,
		onSelectCapture: null,

		// Touch Events
		onTouchCancel: null,
		onTouchCancelCapture: null,
		onTouchEnd: null,
		onTouchEndCapture: null,
		onTouchMove: null,
		onTouchMoveCapture: null,
		onTouchStart: null,
		onTouchStartCapture: null,

		// UI Events
		onScroll: null,
		onScrollCapture: null,

		// Wheel Events
		onWheel: null,
		onWheelCapture: null,

		// Animation Events
		onAnimationStart: null,
		onAnimationStartCapture: null,
		onAnimationEnd: null,
		onAnimationEndCapture: null,
		onAnimationIteration: null,
		onAnimationIterationCapture: null,

		// Transition Events
		onTransitionEnd: null,
		onTransitionEndCapture: null,
	}

	var reactLife = {
		getDefaultProps: function () { },
		getInitialState: function () { },
		componentWillMount: function () { },
		render: function () { },
		componentDidMount: function () { },
		componentWillReceiveProps: function (nextProps) { },
		shouldComponentUpdate: function () { return true },
		componentWillUpdate: function () { },
		componentWillUnmount: function () { },
		childContextTypes: 'React.Mixin',
		contextTypes: 'React.Mixin',
		displayName: 'React.Mixin',
		mixins: 'React.Mixin',
		propTypes: 'React.Mixin',
		statics: 'React.Mixin',
	}

	var props = {
		...propsNotCss,
		style: css,
	}

	var viewProps = {
		...props,
		random: false,
		img: null,
		flex: 1,
	}

	var svg = {
		accentHeight: null,
		accumulate: null,
		additive: null,
		alignmentBaseline: null,
		allowReorder: null,
		alphabetic: null,
		amplitude: null,
		arabicForm: null,
		ascent: null,
		attributeName: null,
		attributeType: null,
		autoReverse: null,
		azimuth: null,
		baseFrequency: null,
		baselineShift: null,
		baseProfile: null,
		bbox: null,
		begin: null,
		bias: null,
		by: null,
		calcMode: null,
		capHeight: null,
		clip: null,
		clipPath: null,
		clipPathUnits: null,
		clipRule: null,
		colorInterpolation: null,
		colorInterpolationFilters: null,
		colorProfile: null,
		colorRendering: null,
		contentScriptType: null,
		contentStyleType: null,
		cursor: null,
		cx: null,
		cy: null,
		d: null,
		decelerate: null,
		descent: null,
		diffuseConstant: null,
		direction: null,
		display: null,
		divisor: null,
		dominantBaseline: null,
		dur: null,
		dx: null,
		dy: null,
		edgeMode: null,
		elevation: null,
		enableBackground: null,
		end: null,
		exponent: null,
		externalResourcesRequired: null,
		fill: null,
		fillOpacity: null,
		fillRule: null,
		filter: null,
		filterRes: null,
		filterUnits: null,
		floodColor: null,
		floodOpacity: null,
		focusable: null,
		fontFamily: null,
		fontSize: null,
		fontSizeAdjust: null,
		fontStretch: null,
		fontStyle: null,
		fontVariant: null,
		fontWeight: null,
		format: null,
		from: null,
		fx: null,
		fy: null,
		g1: null,
		g2: null,
		glyphName: null,
		glyphOrientationHorizontal: null,
		glyphOrientationVertical: null,
		glyphRef: null,
		gradientTransform: null,
		gradientUnits: null,
		hanging: null,
		horizAdvX: null,
		horizOriginX: null,
		ideographic: null,
		imageRendering: null,
		in2: null,
		intercept: null,
		k1: null,
		k2: null,
		k3: null,
		k4: null,
		k: null,
		kernelMatrix: null,
		kernelUnitLength: null,
		kerning: null,
		keyPoints: null,
		keySplines: null,
		keyTimes: null,
		lengthAdjust: null,
		letterSpacing: null,
		lightingColor: null,
		limitingConeAngle: null,
		local: null,
		markerEnd: null,
		markerHeight: null,
		markerMid: null,
		markerStart: null,
		markerUnits: null,
		markerWidth: null,
		mask: null,
		maskContentUnits: null,
		maskUnits: null,
		mathematical: null,
		mode: null,
		numOctaves: null,
		offset: null,
		opacity: null,
		operator: null,
		order: null,
		orient: null,
		orientation: null,
		origin: null,
		overflow: null,
		overlinePosition: null,
		overlineThickness: null,
		paintOrder: null,
		panose1: null,
		pathLength: null,
		patternContentUnits: null,
		patternTransform: null,
		patternUnits: null,
		pointerEvents: null,
		points: null,
		pointsAtX: null,
		pointsAtY: null,
		pointsAtZ: null,
		preserveAlpha: null,
		preserveAspectRatio: null,
		primitiveUnits: null,
		r: null,
		radius: null,
		refX: null,
		refY: null,
		renderingIntent: null,
		repeatCount: null,
		repeatDur: null,
		requiredExtensions: null,
		requiredFeatures: null,
		restart: null,
		result: null,
		rotate: null,
		rx: null,
		ry: null,
		scale: null,
		seed: null,
		shapeRendering: null,
		slope: null,
		spacing: null,
		specularConstant: null,
		specularExponent: null,
		speed: null,
		spreadMethod: null,
		startOffset: null,
		stdDeviation: null,
		stemh: null,
		stemv: null,
		stitchTiles: null,
		stopColor: null,
		stopOpacity: null,
		strikethroughPosition: null,
		strikethroughThickness: null,
		string: null,
		stroke: null,
		strokeDasharray: null,
		strokeDashoffset: null,
		strokeLinecap: null,
		strokeLinejoin: null,
		strokeMiterlimit: null,
		strokeOpacity: null,
		strokeWidth: null,
		surfaceScale: null,
		systemLanguage: null,
		tableValues: null,
		targetX: null,
		targetY: null,
		textAnchor: null,
		textDecoration: null,
		textLength: null,
		textRendering: null,
		to: null,
		transform: null,
		type: null,
		u1: null,
		u2: null,
		underlinePosition: null,
		underlineThickness: null,
		unicode: null,
		unicodeBidi: null,
		unicodeRange: null,
		unitsPerEm: null,
		vAlphabetic: null,
		values: null,
		vectorEffect: null,
		version: null,
		vertAdvY: null,
		vertOriginX: null,
		vertOriginY: null,
		vHanging: null,
		vIdeographic: null,
		viewBox: null,
		viewTarget: null,
		visibility: null,
		vMathematical: null,
		widths: null,
		wordSpacing: null,
		writingMode: null,
		x1: null,
		x2: null,
		x: null,
		xChannelSelector: null,
		xHeight: null,
		xlinkActuate: null,
		xlinkArcrole: null,
		xlinkHref: null,
		xlinkRole: null,
		xlinkShow: null,
		xlinkTitle: null,
		xlinkType: null,
		xmlBase: null,
		xmlLang: null,
		xmlns: null,
		xmlnsXlink: null,
		xmlSpace: null,
		y1: null,
		y2: null,
		y: null,
		yChannelSelector: null,
		z: null,
		zoomAndPan: null,
	}

	var dom = {
		// HTML
		a: null,
		abbr: null,
		address: null,
		area: null,
		article: null,
		aside: null,
		audio: null,
		b: null,
		base: null,
		bdi: null,
		bdo: null,
		big: null,
		blockquote: null,
		body: null,
		br: null,
		button: null,
		canvas: null,
		caption: null,
		cite: null,
		code: null,
		col: null,
		colgroup: null,
		data: null,
		datalist: null,
		dd: null,
		del: null,
		details: null,
		dfn: null,
		dialog: null,
		div: null,
		dl: null,
		dt: null,
		em: null,
		embed: null,
		fieldset: null,
		figcaption: null,
		figure: null,
		footer: null,
		form: null,
		h1: null,
		h2: null,
		h3: null,
		h4: null,
		h5: null,
		h6: null,
		head: null,
		header: null,
		hgroup: null,
		hr: null,
		html: null,
		i: null,
		iframe: null,
		img: null,
		input: null,
		ins: null,
		kbd: null,
		keygen: null,
		label: null,
		legend: null,
		li: null,
		link: null,
		main: null,
		map: null,
		mark: null,
		menu: null,
		menuitem: null,
		meta: null,
		meter: null,
		nav: null,
		noscript: null,
		object: null,
		ol: null,
		optgroup: null,
		option: null,
		output: null,
		p: null,
		param: null,
		picture: null,
		pre: null,
		progress: null,
		q: null,
		rp: null,
		rt: null,
		ruby: null,
		s: null,
		samp: null,
		script: null,
		section: null,
		select: null,
		small: null,
		source: null,
		span: null,
		strong: null,
		style: null,
		sub: null,
		summary: null,
		sup: null,
		table: null,
		tbody: null,
		td: null,
		textarea: null,
		tfoot: null,
		th: null,
		thead: null,
		time: null,
		title: null,
		tr: null,
		track: null,
		u: null,
		ul: null,
		video: null,
		wbr: null,

		// SVG
		svg: null,
		circle: null,
		defs: null,
		ellipse: null,
		g: null,
		image: null,
		line: null,
		linearGradient: null,
		mask: null,
		path: null,
		pattern: null,
		polygon: null,
		polyline: null,
		radialGradient: null,
		rect: null,
		stop: null,
		symbol: null,
		text: null,
		tspan: null,
		use: null,
	}
	var table = {
        /**
          * Pixel width of table. If all columns do not fit, a
          * horizontal scrollbar will appear.
          */
		width: 0,

        /**
          * Pixel height of table. If all rows do not fit, a
          * vertical scrollbar will appear.
          *
          * Either height or maxHeight must be specified.
          */
		height: 0,

        /**
          * Maximum pixel height of table. If all rows do not fit,
          * a vertical scrollbar will appear.
          *
          * Either height or maxHeight must be specified.
          */
		maxHeight: 0,

        /**
          * Pixel height of table's owner, this is used in a managed
          * scrolling situation when you want to slide the table up
          * from below the fold without having to constantly update
          * the height on every scroll tick. Instead, vary this
          * property on scroll. By using ownerHeight, we over-render
          * the table while making sure the footer and horizontal
          * scrollbar of the table are visible when the current space
          * for the table in view is smaller than the final,
          * over-flowing height of table. It allows us to avoid
          * resizing and reflowing table when it is moving in the
          * view.
          *
          * This is used if ownerHeight < height (or maxHeight).
          */
		ownerHeight: 0,

        /**
          * 'hidden'|'auto'
          */
		overflowX: 'string',

        /**
          * 'hidden'|'auto'
          */
		overflowY: 'string',

        /**
          * 0 of rows in the table.
          */
		rowsCount: 0,

        /**
          * Pixel height of rows unless rowHeightGetter is specified
          * and returns different value.
          */
		rowHeight: 0,

        /**
          * If specified, rowHeightGetter(index) is called for each
          * row and the returned value overrides rowHeight for
          * particular row.
          */
		rowHeightGetter: (index) => 0,

        /**
          * To get any additional CSS classes that should be added to
          *  a row, rowClassNameGetter(index) is called.
          */
		rowClassNameGetter: (index) => 20,

        /**
          * Pixel height of the column group header.
          *
          * defaultValue: 0
          */
		groupHeaderHeight: 0,

        /**
          * Pixel height of the header.
          *
          * defaultValue: 0
          */
		headerHeight: 0,

        /**
          * Pixel height of the footer.
          *
          * defaultValue: 0
          */
		footerHeight: 0,

        /**
          * Value of horizontal scroll.
          *
          * defaultValue: 0
          */
		scrollLeft: 0,

        /**
          * Index of column to scroll to.
          */
		scrollToColumn: 0,

        /**
          * Value of vertical scroll.
          *
          * defaultValue: 0
          */
		scrollTop: 0,

        /**
          * Index of row to scroll to.
          */
		scrollToRow: 0,

        /**
          * Callback that is called when scrolling starts with
          * current horizontal and vertical scroll values.
          */
		onScrollStart: (x, y) => null,

        /**
          * Callback that is called when scrolling ends or stops with
          * new horizontal and vertical scroll values.
          */
		onScrollEnd: (x, y) => null,

        /**
          * Callback that is called when rowHeightGetter returns a
          * different height for a row than the rowHeight prop. This
          *  is necessary because initially table estimates heights
          * of some parts of the content.
          */
		onContentHeightChange: (newHeight) => null,

        /**
          * Callback that is called when a row is clicked.
          */
		onRowClick: (event, rowIndex) => null,

        /**
          * Callback that is called when a row is double clicked.
          */
		onRowDoubleClick: (event, rowIndex) => null,

        /**
          * Callback that is called when a mouse-down event happens
          * on a row.
          */
		onRowMouseDown: (event, rowIndex) => null,

        /**
          * Callback that is called when a mouse-enter event happens
          * on a row.
          */
		onRowMouseEnter: (event, rowIndex) => null,

        /**
          * Callback that is called when a mouse-leave event happens
          * on a row.
          */
		onRowMouseLeave: (event, rowIndex) => null,

        /**
          * Callback that is called when resizer has been released
          * and column needs to be updated.
          *
          * Required if the isResizable property is true on any
          * column.
          */
		onColumnResizeEndCallback: (newColumnWidth, columnKey) => null,

        /**
          * Whether a column is currently being resized.
          */
		isColumnResizing: 'boolean',
	}

    /**
     * Component that defines the attributes of table column.
     */
	var column = {
        /**
          * The horizontal alignment of the table cell content.
          *
          * 'left'|'center'|'right'
          */
		align: 'string',

        /**
          * Controls if the column is fixed when scrolling in the X
          * axis.
          *
          * defaultValue: false
          */
		fixed: 'boolean',

        /**
          * The header cell for this column. This can either be a
          * string. a React element, or a function that generates a
          * React Element. Passing in a string will render a default
          * header cell with that string. By default, the React
          * element passed in can expect to receive the following
          * props:
          *
          * props: {
          *   columnKey: string // (of the column, if given)
          *   height: 0 // (supplied from the Table or rowHeightGetter)
          *   width: 0 // (supplied from the Column)
          * }
          *
          * Because you are passing in your own React element, you
          * can feel free to pass in whatever props you may want or need.
          *
          * If you pass in a function, you will receive the same props object as the first argument.
          */
		header: '',

        /**
          * This is the body cell that will be cloned for this
          * column. This can either be a string a React element,
          * or a function that generates a React Element. Passing
          * in a string will render a default cell with that
          * string. By default, the React element passed in can
          * expect to receive the following props:
          *
          * props: {
          *   rowIndex, 0 // (the row index of the cell)
          *   columnKey: string // (of the column, if given)
          *   height: 0 // (supplied from the Table or rowHeightGetter)
          *   width: 0 // (supplied from the Column)
          * }
          *
          * Because you are passing in your own React element, you
          * can feel free to pass in whatever props you may want or
          * need.
          *
          * If you pass in a function, you will receive the same
          * props object as the first argument.
          */
		cell: '',

		/**
		 * The footer cell for this column. This can either be a
		 * string. a React element, or a function that generates a
		 * React Element. Passing in a string will render a default
		 * header cell with that string. By default, the React
		 * element passed in can expect to receive the following
		 * props:
		 *
		 * props: {
		 *   columnKey: string // (of the column, if given)
		 *   height: 0 // (supplied from the Table or rowHeightGetter)
		 *   width: 0 // (supplied from the Column)
		 * }
		 *
		 * Because you are passing in your own React element, you
		 * can feel free to pass in whatever props you may want or
		 * need.
		 *
		 * If you pass in a function, you will receive the same
		 * props object as the first argument.
		 */
		footer: '',

        /**
          * This is used to uniquely identify the column, and is not
          * required unless you a resizing columns. This will be the
          * key given in the onColumnResizeEndCallback on the Table.
          */
		columnKey: 0,

        /**
          * The pixel width of the column.
          */
		width: 0,

        /**
          * If this is a resizable column this is its minimum pixel
          * width.
          */
		minWidth: 0,

        /**
          * If this is a resizable column this is its maximum pixel
          * width.
          */
		maxWidth: 0,

        /**
          * The grow factor relative to other columns. Same as the
          * flex-grow API from http://www.w3.org/TR/css3-flexbox/.
          * Basically, take any available extra width and distribute
          * it proportionally according to all columns' flexGrow
          * values. Defaults to zero (no-flexing).
          */
		flexGrow: 0,

        /**
         * Whether the column can be resized with the
         * FixedDataTableColumnResizeHandle. Please note that if a
         * column has a flex grow, once you resize the column this
         * will be set to 0.
         *
         * This property only provides the UI for the column
         * resizing. If this is set to true, you will need to set the
         * onColumnResizeEndCallback table property and render your
         * columns appropriately.
         */
		isResizable: 'boolean',

        /**
          * Whether cells in this column can be removed from document
          * when outside of viewport as a result of horizontal
          * scrolling. Setting this property to true allows the table
          * to not render cells in particular column that are outside
          * of viewport for visible rows. This allows to create table
          * with many columns and not have vertical scrolling
          * performance drop. Setting the property to false will keep
          * previous behaviour and keep cell rendered if the row it
          * belongs to is visible.
          *
          * defaultValue: false
          */
		allowCellsRecycling: 'boolean',
	}

    /**
     * Component that defines the attributes of a table column group.
     */
	var columnGroup = {
        /**
	     * The horizontal alignment of the table cell content.
         * 'left', 'center', 'right'
	     */
		align: 'string',

	    /**
	     * Controls if the column group is fixed when scrolling in the X
	     * axis.
	     *
	     * defaultValue: false
	     */
		fixed: 'boolean',

        /**
          * The header cell for this column group. This can either be
          * a string. a React element, or a function that generates a
          * React Element. Passing in a string will render a default
          * header cell with that string. By default, the React
          * element passed in can expect to receive the following
          * props:
          *
          * props: {
          *   height: 0 // (supplied from the groupHeaderHeight)
          *   width: 0 // (supplied from the Column)
          * }
          *
          * Because you are passing in your own React element, you
          * can feel free to pass in whatever props you may want or
          * need.
          *
          * If you pass in a function, you will receive the same props
          * object as the first argument.
          */
		header: '',
	}

    /**
     * Component that handles default cell layout and styling.
     *
     * All props unless specified below will be set onto the top
	 * level div rendered by the cell.
     *
     * Example usage via from a Column:
     *
     * const MyColumn = (
     *   <Column
     *     cell={({rowIndex, width, height}) => (
     *       <Cell
     *         width={width}
     *         height={height}
     *         className="my-class">
     *         Cell 0: <span>{rowIndex}</span>
     *        </Cell>
     *     )}
     *     width={100}
     *   />
     * ),
     */
	var cell = {
        /**
         * The row index of the cell.
         */
		rowIndex: 0,

        /**
         * Outer height of the cell.
         */
		height: 0,

        /**
         * Outer width of the cell.
         */
		width: 0,

        /**
         * Optional prop that if specified on the Column will be
         * passed to the cell. It can be used to uniquely identify
         * which column is the cell is in.
         */
		columnKey: 'string',
	}
	var styleValue = {
		row: 'row',
		rowReverse: 'row-reverse',
		column: 'column',
		columnReverse: 'column-reverse',
		wrap: 'wrap',
		nowrap: 'nowrap',
		auto: 'auto',
		flexStart: 'flex-start',
		flexEnd: 'flex-end',
		spaceBetween: 'space-between',
		spaceAround: 'space-around',
		baseline: 'baseline',
		stretch: 'stretch',
		static: 'static',
		relative: 'relative',
		absolute: 'absolute',
		fixed: 'fixed',
		center: 'center',
		page: 'page',
		sticky: 'sticky',
	}
	var mojsShape = {

		/* SHAPE PROPERTIES */

		// Parent of the module. {String, Object} [selector, HTMLElement]
		parent: document.body,

		// Class name. {String}
		className: '',

		// Shape name. {String} [ 'circle' | 'rect' | 'polygon' | 'line' | 'cross' | 'equal' | 'curve' | 'zigzag' | '*custom defined name*' ]
		shape: 'circle',

		// ∆ :: Stroke color. {String} [color name, rgb, rgba, hex]
		stroke: 'transparent',

		// ∆ :: Stroke Opacity. {Number} [ 0..1 ]
		strokeOpacity: 1,

		// Stroke Line Cap. {String} ['butt' | 'round' | 'square']
		strokeLinecap: '',

		// ∆ :: Stroke Width. {Number} [ number ]
		strokeWidth: 2,

		// ∆ , Units :: Stroke Dash Array. {String, Number}
		strokeDasharray: 0,

		// ∆ , Units :: Stroke Dash Offset. {String, Number}
		strokeDashoffset: 0,

		// ∆ :: Fill Color. {String} [color name, rgb, rgba, hex]
		fill: 'deeppink',

		// ∆ :: Fill Opacity. {Number} [ 0..1 ]
		fillOpacity: 1,

		// ∆ , Units :: Left position of the module. {Number, String}
		left: '50%',

		// ∆ , Units :: Top position of the module. {Number, String}
		top: '50%',

		// ∆ , Units :: X shift. {Number, String}
		x: 0,

		// ∆ , Units :: Y shift. {Number, String}
		y: 0,

		// ∆ :: Angle. {Number, String}
		angle: 0,

		// ∆ :: Scale of the module. {Number}
		scale: 1,

		// ∆ :: Explicit scaleX value (fallbacks to `scale`). {Number}
		scaleX: null,

		// ∆ :: Explicit scaleX value (fallbacks to `scale`). {Number}
		scaleY: null,

		// ∆ , Unit :: Origin for `x`, `y`, `scale`, `rotate` properties. {String}
		origin: '50% 50%',

		// ∆ :: Opacity. {Number} [ 0..1 ]
		opacity: 1,

		// ∆ :: X border radius. {Number, String}
		rx: 0,

		// ∆ :: Y border radius. {Number, String}
		ry: 0,

		// ∆ :: Points count ( for polygon, zigzag, equal ). {Number, String}
		points: 3,

		// ∆ :: Radius of the shape. {Number, String}
		radius: 50,

		// ∆ :: Radius X of the shape (fallbacks to `radius`). {Number, String}
		radiusX: null,

		// ∆ :: Radius Y of the shape (fallbacks to `radius`). {Number, String}
		radiusY: null,

		// If should hide module with `transforms` instead of `display`. {Boolean}
		isSoftHide: true,

		// If should trigger composite layer for the module. {Boolean}
		isForce3d: false,

		// If should be shown before animation starts. {Boolean}

		// If should stay shown after animation ends. {Boolean}
		isShowEnd: true,

		// If refresh state on subsequent plays. {Boolean}
		isRefreshState: true,

		// Context callbacks will be called with. {Object}
		callbacksContext: this,

		/* TWEEN PROPERTIES */
		// Duration {Number}
		duration: 350,
		// Delay {Number}
		delay: 0,
		// If should repeat after animation finished {Number} *(1)
		repeat: 0,
		// Speed of the tween {Number}[0..∞]
		speed: 1,
		// If the progress should be flipped on repeat animation end {Boolean}
		yoyo: false,
		// Easing function {String, Function}[ easing name, path coordinates, bezier string, easing function ]
		easing: 'sin.out',
		// Easing function for backward direction of the tween animation (fallbacks to `easing`) {String, Function}[ easing name, path coordinates, bezier string, easing function ]
		backwardEasing: null,

		/* TWEEN CALLBACKS */
		/*
			Fires on every update of the tween in any period (including delay periods). You probably want to use `onUpdate` method instead.
			@param p {Number} Normal (not eased) progress.
			@param isForward {Boolean} Direction of the progress.
			@param isYoyo {Boolean} If in `yoyo` period.
		*/
		onProgress(p, isForward, isYoyo) { },
		/*
			Fires when tween's the entire progress reaches `0` point(doesn't fire in repeat periods).
			@param isForward {Boolean} If progress moves in forward direction.
			@param isYoyo {Boolean} If progress inside `yoyo` flip period.
		*/
		onStart(isForward, isYoyo) { },
		/*
			Fires when tween's the progress reaches `0` point in normal or repeat period.
			@param isForward {Boolean} If progress moves in forward direction.
			@param isYoyo {Boolean} If progress inside `yoyo` flip period.
		*/
		onFirstUpdate(isForward, isYoyo) { },
		/*
			Fires on first update of the tween in sufficiently active period (excluding delay periods).
			@param ep {Number} Eased progress.
			@param p {Number} Normal (not eased) progress.
			@param isForward {Boolean} Direction of the progress.
			@param isYoyo {Boolean} If in `yoyo` period.
		*/
		onUpdate(ep, p, isForward, isYoyo) { },
		/*
			Fires when tween's the progress reaches `1` point in normal or repeat period.
			@param isForward {Boolean} If progress moves in forward direction.
			@param isYoyo {Boolean} If progress inside `yoyo` flip period.
		*/
		onRepeatComplete(isForward, isYoyo) { },
		/*
			Fires when tween's the entire progress reaches `1` point(doesn't fire in repeat periods).
			@param isForward {Boolean} If progress moves in forward direction.
			@param isYoyo {Boolean} If progress inside `yoyo` flip period.
		*/
		onComplete(isForward, isYoyo) { },
		/* Fires when the `.play` method called and tween isn't in play state yet. */
		onPlaybackStart() { },
		/* Fires when the `.pause` method called and tween isn't in pause state yet. */
		onPlaybackPause() { },
		/* Fires when the `.stop` method called and tween isn't in stop state yet. */
		onPlaybackStop() { },
		/* Fires when the tween end's animation (regardless progress) */
		onPlaybackComplete() { },
		/*
			Creates next state transition chain.
			@param options {Object} Next shape state.
		*/
		// then({ /* next state options */ }){},
		/*
			Tunes start state with new options.
			@param options {Object} New start properties.
		*/
		// tune({ /* new start properties */ }){},

		/*
			Regenerates all randoms in initial properties.
		*/
		generate() { },
		/*
			Starts playback.
			@param shift {Number} Start progress shift in milliseconds.
		*/
		play(shift = 0) { },
		/*
			Starts playback in backward direction.
			@param shift {Number} Start progress shift in milliseconds.
		*/
		playBackward(shift = 0) { },
		/*
			Pauses playback.
		*/
		pause() { },
		/*
			Restarts playback.
			@param shift {Number} Start progress shift in milliseconds.
		*/
		replay(shift = 0) { },
		/*
			Restarts playback in backward direction.
			@param shift {Number} Start progress shift in milliseconds.
		*/
		replayBackward(shift = 0) { },
		/*
			Resumes playback in direction it was prior to `pause`.
			@param shift {Number} Start progress shift in milliseconds.
		*/
		resume(shift = 0) { },
		/*
			Sets progress of the tween.
			@param progress {Number} Progress to set [ 0..1 ].
		*/
		setProgress(progress) { },
		/*
			Sets speed of the tween.
			@param speed {Number} Progress to set [ 0..∞ ].
		*/
		setSpeed(speed) { },
		/* Stops and resets the tween. */
		reset(speed) { },
	}
	var mojsHtml = {
		// HTMLElement to animate. {String, Object} [selector, HTMLElement]
		el: null,
		// ∆ :: translateX property. {String, Number, Object} [value, delta]
		x: 0,
		// ∆ :: translateY property. {String, Number, Object} [value, delta]
		y: 0,
		// ∆ :: translateZ property. {String, Number, Object} [value, delta]
		z: 0,
		// ∆ :: skewX property. {String, Number, Object} [value, delta]
		skewX: 0,
		// ∆ :: skewY property. {String, Number, Object} [value, delta]
		skewY: 0,
		// ∆ :: rotateX property. {String, Number, Object} [value, delta]
		angleX: 0,
		// ∆ :: rotateY property. {String, Number, Object} [value, delta]
		angleY: 0,
		// ∆ :: rotateZ property. {String, Number, Object} [value, delta]
		angleZ: 0,
		// ∆ :: scale property. {String, Number, Object} [value, delta]
		scale: 1,
		// ∆ :: scaleX property. {String, Number, Object} [value, delta]
		scaleX: 1,
		// ∆ :: scaleY property. {String, Number, Object} [value, delta]
		scaleY: 1,
		// ∆ :: opacity property. {String, Number, Object} [value, delta]
		opacity: 1,

		/*
			For other CSS properties please see `Other CSS properties` section.
		*/

		// Custom properties to alter mojs behaviour (see `Teach mojs with customProperties` section). {Object}
		customProperties: null,
		// If should be shown before animation starts. {Boolean}
		// If should stay shown after animation ends. {Boolean}
		isShowEnd: true,
		// If refresh state on subsequent plays. {Boolean}
		isShowStart: true,
		// If should trigger composite layer for the module. {Boolean}
		isForce3d: false,
		// If should hide module with `transforms` instead of `display`. {Boolean}
		isSoftHide: true,
		// If refresh state on subsequent plays. {Boolean}
		isRefreshState: true,
		// Context callbacks will be called with. {Object}
		callbacksContext: this,

		/* TWEEN PROPERTIES */
		// Duration {Number}
		duration: 350,
		// Delay {Number}
		delay: 0,
		// If should repeat after animation finished {Number} *(1)
		repeat: 0,
		// Speed of the tween {Number}[0..∞]
		speed: 1,
		// If the progress should be flipped on repeat animation end {Boolean}
		yoyo: false,
		// Easing function {String, Function}[ easing name, path coordinates, bezier string, easing function ]
		easing: 'sin.out',
		// Easing function for backward direction of the tween animation (fallbacks to `easing`) {String, Function}[ easing name, path coordinates, bezier string, easing function ]
		backwardEasing: null,
		// properties fro entire timeline
		timeline: {
			/* (+) TIMELINE PROPERTIES AND CALLBACKS - see Tween API */
		},

		/* TWEEN CALLBACKS */
		/*
			Fires on every update of the tween in any period (including delay periods). You probably want to use `onUpdate` method instead.
			@param p {Number} Normal (not eased) progress.
			@param isForward {Boolean} Direction of the progress.
			@param isYoyo {Boolean} If in `yoyo` period.
		*/
		onProgress(p, isForward, isYoyo) { },
		/*
			Fires when tween's the entire progress reaches `0` point(doesn't fire in repeat periods).
			@param isForward {Boolean} If progress moves in forward direction.
			@param isYoyo {Boolean} If progress inside `yoyo` flip period.
		*/
		onStart(isForward, isYoyo) { },
		/*
			Fires when tween's the progress reaches `0` point in normal or repeat period.
			@param isForward {Boolean} If progress moves in forward direction.
			@param isYoyo {Boolean} If progress inside `yoyo` flip period.
		*/
		onFirstUpdate(isForward, isYoyo) { },
		/*
			Fires on first update of the tween in sufficiently active period (excluding delay periods).
			@param ep {Number} Eased progress.
			@param p {Number} Normal (not eased) progress.
			@param isForward {Boolean} Direction of the progress.
			@param isYoyo {Boolean} If in `yoyo` period.
		*/
		onUpdate(ep, p, isForward, isYoyo) { },
		/*
			Fires when tween's the progress reaches `1` point in normal or repeat period.
			@param isForward {Boolean} If progress moves in forward direction.
			@param isYoyo {Boolean} If progress inside `yoyo` flip period.
		*/
		onRepeatComplete(isForward, isYoyo) { },
		/*
			Fires when tween's the entire progress reaches `1` point(doesn't fire in repeat periods).
			@param isForward {Boolean} If progress moves in forward direction.
			@param isYoyo {Boolean} If progress inside `yoyo` flip period.
		*/
		onComplete(isForward, isYoyo) { },
		/* Fires when the `.play` method called and tween isn't in play state yet. */
		onPlaybackStart() { },
		/* Fires when the `.pause` method called and tween isn't in pause state yet. */
		onPlaybackPause() { },
		/* Fires when the `.stop` method called and tween isn't in stop state yet. */
		onPlaybackStop() { },
		/* Fires when the tween end's animation (regardless progress) */
		onPlaybackComplete() { },
		/*
			Creates next state transition chain.
			@param options {Object} Next shape state.
		*/
		// then({ /* next state options */ }){},

		/*
			Starts playback.
			@param shift {Number} Start progress shift in milliseconds.
		*/
		play(shift = 0) { },
		/*
			Starts playback in backward direction.
			@param shift {Number} Start progress shift in milliseconds.
		*/
		playBackward(shift = 0) { },
		/*
			Resumes playback in direction it was prior to `pause`.
			@param shift {Number} Start progress shift in milliseconds.
		*/
		resume(shift = 0) { },
		/*
			Pauses playback.
		*/
		pause() { },
		/*
			Stops playback.
			@param {Number} Progress to set after the stop [0...1].
		*/
		stop(progress = 0) { },
		/*
			Restarts playback.
			@param shift {Number} Start progress shift in milliseconds.
		*/
		replay(shift = 0) { },
		/*
			Restarts playback in backward direction.
			@param shift {Number} Start progress shift in milliseconds.
		*/
		replayBackward(shift = 0) { },
		/*
			Sets progress of the tween.
			@param progress {Number} Progress to set [ 0..1 ].
		*/
		setProgress(progress) { },
		/*
			Sets speed of the tween.
			@param speed {Number} Progress to set [ 0..∞ ].
		*/
		setSpeed(speed) { },

		/* Stops and resets the tween. */
		reset(speed) { },
	}
}

css = null
propsNotCss = null
reactLife = null
props = null
viewProps = null
svg = null
dom = null
table = null
column = null
columnGroup = null
cell = null
mojsShape = null

module.exports = {
	css,
	propsNotCss,
	reactLife,
	props,
	viewProps,
	svg,
	dom,
	table,
	column,
	columnGroup,
	cell,
	styleValue,
	mojsShape,
}