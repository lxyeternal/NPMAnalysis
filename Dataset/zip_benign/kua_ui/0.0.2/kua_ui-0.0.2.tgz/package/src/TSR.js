let translate3d = (x, y, z, kx)=>{
	return `translate3d(${x*kx}px, ${y*kx}px, ${z*kx}px) `
}

let scale3d = (x, y, z)=>{
	return `scale3d(${x},${y},${y}) `
}

let rotate3d = (x, y, z) => {
	let _x = x ? `rotateX(${x}deg)` : ' '
	let _y = y ? `rotateX(${y}deg)` : ' '
	let _z = z ? `rotateX(${z}deg)` : ' '
	return `${_x} ${_y} ${_z}`
}

let TSR = (t3D, s3D, r3D, kx = 1)=>{
	if (!t3D && !s3D && !r3D) return null
	let _t = ' '
	let _s = ' ' 
	let _r = ' '
	if (t3D && t3D !== 0) {
		_t = translate3d(t3D[0], t3D[1], t3D[2], kx)
	}
	if (s3D && s3D !== 0) {
		_s = scale3d(s3D[0], s3D[1], s3D[2])
	}
	if(r3D && r3D !== 0) {
		_r = rotate3d(r3D[0], r3D[1], r3D[2])
	}
	return _t + _s + _r
}

module.exports = TSR

// translate3d,
// scale2d,
// rotate3d,
// perspective,
// position,