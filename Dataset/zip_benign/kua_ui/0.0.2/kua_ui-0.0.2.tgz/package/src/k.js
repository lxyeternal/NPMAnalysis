/* eslint-disable */
let k = {
	debug: false,
	server: 'http://127.0.0.1:4000/' + 'public/',
	created: false,
	s: document.documentElement.clientWidth / 750,
	w: document.documentElement.clientWidth / (document.documentElement.clientWidth / 750),
	h: document.documentElement.clientHeight / (document.documentElement.clientWidth / 750),
	fontFamily: 'Helvetica Neue, Helvetic, PingFang SC, Hiragino Sans GB, Microsoft YaHei, 微软雅黑, Arial, sans-serif',
	pc: true,
	android: false,
	ios: false,
	changePc() {
		let u = navigator.userAgent;
		k.android = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1 //android终端
		k.ios = u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) ? false : true //ios终端
		k.pc = u.match(/(iPhone|iPad|iPod|Android|ios)/i) ? false : true
	},
	phoneCss: {
		webkitAppearance: 'none',
		webkitTapHighlightColor: 'transparent',
		webkitTouchCallout: 'none',
		webkitTransformStyle: 'preserve-3d',
		// webkitBackfaceVisibility: 'hidden',
		webkitUserSelect: 'none',	/*webkit浏览器*/
		mozUserSelect: 'none',	/*火狐*/
		msUserSelect: 'none',	/*IE10*/
		userSelect: 'none',
		onselectstart: 'none',
	},
	onload() {
		let body = document.getElementsByTagName('body')[0];
		body.style.margin = '0';
		body.style.border = '0';
		function doubleTouch () {
			//防止缩放
			// document.addEventListener('touchstart', function (event) {
			// 	if (event.touches.length > 1) {
			// 		event.preventDefault();
			// 	}
			// })
			//防止双击放大
			var lastTouchEnd = 0;
			document.addEventListener('touchend', function (event) {
				var now = (new Date()).getTime();
				if (now - lastTouchEnd <= 300) {
					event.preventDefault();
				}
				lastTouchEnd = now;
			}, false)
		}
		window.onload = doubleTouch
	},
	toFixed(obj, num) {
		let n = obj.toFixed(1)
		return n;
	},
	randomColor() {
		// let r = parseInt(Math.random()*256)
		let g = parseInt(Math.random() * 256)
		let b = parseInt(Math.random() * 256)
		return `rgba(0,${g},${b},0.5)`
	},
	fetchGetIp(block) {
		fetch(`http://127.0.0.1:4000/api/ip`)
			.then(function (res) {
				if (res.status >= 400) {
					throw new Error('bad')
					console.log('无法连接到 http://127.0.0.1:4000/api/ip')
				}
				return res.text()
			})
			.then(function (res) {
				k.server = res + 'public/'
				if (block) block()
			})
	},
	isArray(o) {
		return Object.prototype.toString.call(o) === '[object Array]'
	},
	isString(str) {
		return (typeof str == 'string') && str.constructor == String
	}
}

if (k.created === false) {
	k.changePc()
	k.onload()
	k.created = true
}

module.exports = k