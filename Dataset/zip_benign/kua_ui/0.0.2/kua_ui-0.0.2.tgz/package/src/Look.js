/* eslint-disable */
let Look = {
	init() {
		let child = {
			actions: [],
			values: [],
			bindValue(key, value) {
				this.values[key] = Object.assign({}, this.values[key], value)
			},
			listen(key, fn) {
				if (!this.actions[key]) {
					this.actions[key] = []
				}
				this.actions[key].push(fn)
			},
			trigger() {
				let key = [].shift.apply(arguments)
				let fns = this.actions[key]
				if (!fns || !fns.length === 0) {
					return false
				}
				for (let i = 0, fn; fn = fns[i++];) {
					fn.apply(this, arguments)
				}
			},
			remove(key, fn = null) {
				if (fn === null) {
					this.actions[key] = null
				}
				let fns = this.actions[key]
				if (!fns || fns.length === 0) return false
				for (let i = fns.length - 1; i >= 0; i--) {
					let _fn = fns[i]
					if (_fn === fn) {
						//删除改订阅函数
						fns.splice(i, 1)
					}
				}
			}
		}
		return child
	}
}
module.exports = Look



