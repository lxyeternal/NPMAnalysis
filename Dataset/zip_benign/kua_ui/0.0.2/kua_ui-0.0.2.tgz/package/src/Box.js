/* eslint-disable */
const React = require('react')
const k = require('./k')
const Snip = require('./Snip')
const TSR = require('./TSR')

let BoxClass =  {
	css: {},
	rest: {},
	getDefaultProps() {
		return {
			...Snip.propsNotCss,
			style: {
				...Snip.css,
				bg: null,
				col: null,
				full: null,
				ps: null,
				move: null,
				scale: null,
				rotate: null,
				border: null,
				img: null,
			}
		}
	},
	componentWillMount() {
		this.init()
	},
	render() {
		return (
			<div {...this.rest}>{this.props.children}</div>
		)
	},
	init() {
		let { fontSize, col, full, ps, bg, img, border, move, scale, rotate, justifyContent, alignSelf, ...restStyle } = this.props.style
		if (!k.pc) {
			this.css = { ...k.phoneCss }
		}
		this.css = {
			...this.css,
			display: 'flex',
			textAlign: 'center',
			alignItems: 'center',
			alignSelf: 'center',
			justifyContent: 'center',
			position: 'relative', // static relative absolute fixed center page stickys
			perspective: 800,
		}
		if (full === 1) {
			this.css = {
				...this.css,
				position: 'absolute',
				overflow: 'auto',
				webkitOverflowScrolling: 'touch',
				top: 0,
				left: 0,
				bottom: 0,
				right: 0,
			}
		}

		let _bg = this.props.style.bg
		if (_bg === 1) {
			this.bg = k.randomColor()
		}
		if (col != null) restStyle['flexDirection'] = col === 1 ? 'column' : 'row'
		if (ps != null) restStyle['position'] = ps === 1 ? 'absolute' : ps === 2 ? 'fixed' : ps
		if (justifyContent != null) restStyle['justifyContent'] = justifyContent === 0 ? 'flex-start' : (justifyContent === 1 ? 'center' : (justifyContent === 2) ? 'flex-end' : justifyContent)
		if (alignSelf != null) restStyle['alignSelf'] = alignSelf === 0 ? 'flex-start' : (alignSelf === 1 ? 'center' : (alignSelf === 2) ? 'flex-end' : alignSelf)
		if (rotate != null) {
			restStyle['WebkitBackfaceVisibility'] = 'visible'
			restStyle['backfaceVisibility'] = 'visible'
		}
		if (img) {
			this.css = Snip.css || {
				...this.css,
				background: `url(${img})`,
				backgroundRepeat: 'no-repeat',
				backgroundPosition: 'center',
				backgroundSize: 'contain' //contain cover auto
			}
		}
		if (fontSize) {
			this.css = Snip.css || {
				...this.css,
				fontFamily: k.fontFamily,
			}
		}
		this.css = {
			...this.css,
			...restStyle,
		}
	},
	componentWillUpdate() {
		let { style, ...rest } = this.props
		let { col, full, ps, bg, img, border, move, scale, rotate, justifyContent, alignSelf, ...restStyle } = style
		let ks = k.s
		let trans = TSR(move, scale, rotate, ks)
		if (trans != null) restStyle['transform'] = trans
		if (bg != null) restStyle['backgroundColor'] = bg === 1 ? this.bg : bg
		if (border != null) restStyle['border'] = k.isArray(border) ? `${border[0]} solid ${border[1] * ks}px` : border
		let endStyle = {}
		for (let prop in restStyle) {
			endStyle[prop] = k.isString(restStyle[prop]) ? restStyle[prop] : restStyle[prop] * ks
		}
		this.css = {
			...this.css,
			...endStyle,
		}
		this.rest = {
			...rest,
			style: this.css
		}
	},
}
const Box = React.createClass(BoxClass)


module.exports = { BoxClass, Box }
