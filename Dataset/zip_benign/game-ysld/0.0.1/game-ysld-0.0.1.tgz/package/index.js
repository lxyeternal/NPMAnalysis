Component({
  mixins: [],
  data: {
    boxId: ""
  },
  props: {},
  didMount() {
    this.destroy();
    this.setData({
      boxId: `f_${this.uniId()}`
    }, () => {
      this.componentInit();
    })
  },
  didUpdate() { },
  didUnmount() {
    this.destroy();
  },
  methods: {
    destroy() {
      this.gameStatus = false;
      clearTimeout(this.timer);
    },
    uniId: function () {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    },
    //读取节点信息
    dom(className) {
      return new Promise(function (resolve, reject) {
        let result = {};
        my.createSelectorQuery()
          .select(className)
          .boundingClientRect()
          .exec(([ret]) => {
            if (ret) {
              result.success = true;
              result.data = ret;
            } else {
              result.success = false;
            }
            resolve(result);
          })
      })
    },
    parFun(funName, options) {
      let bl = false;
      try {
        // 判断组件是否有传入事件，如果没有，则再判断页面上是否有指定事件
        this.props[funName](options);
      } catch (e) {
        bl = true;
      }
      if (bl) {
        try {
          // 判断组件是否有传入事件，如果没有，则再判断页面上是否有指定事件
          this.$page[funName](options);
        } catch (e) {
          bl = true;
        }
      }
      if (bl) {
        console.log(`页面和组件传递都没有找到方法：${funName}`)
      }
    },
    async componentInit() {
      this.gameStatus = false;
      let domData = await this.dom(`#${this.data.boxId}`);
      this.winW = domData.data.width;
      this.winH = domData.data.height;


      let gameData = this.props.gameSource;
      try {
        gameData = JSON.parse(gameData);
      } catch (e) { }
      this.gameData = gameData;
      this.setData({
        gameData,
        boxs: [1, 2, 3],
        prevIdx: 0,
        curIdx: 1,
        nextIdx: 2,

        endLeft: gameData.item.left,
        endTop: gameData.item.top,
        endOpacity: (gameData.item.opacity || 1),
        endScale: (gameData.item.scale || 1),

        leftSize: `width:${gameData.leftOps.width}rpx;height:${gameData.leftOps.height}rpx;left:${gameData.leftOps.left}rpx;top:${gameData.leftOps.top}rpx;`,
        centerSize: `width:${gameData.box.width}rpx;height:${gameData.box.height}rpx;left:${gameData.box.left}rpx;top:${gameData.box.top}rpx;`,
        rightSize: `width:${gameData.rightOps.width}rpx;height:${gameData.rightOps.height}rpx;left:${gameData.rightOps.left}rpx;top:${gameData.rightOps.top}rpx;`,
      })

      this.parFun("onInitDone", this);
    },
    checkV(v) {
      let vv = v;
      if (vv < 0) {
        vv = 2;
      }
      if (vv > 2) {
        vv = 0;
      }
      return vv;
    },
    moveAni() {
      return new Promise((resolve, reject) => {
        let gameData = this.data.gameData;
        let endArr = [
          { left: gameData.leftOps.left, top: gameData.leftOps.top },
          { left: gameData.box.left + gameData.box.width / 2, top: gameData.box.top },
          { left: gameData.rightOps.left, top: gameData.rightOps.top },
        ];
        let idx = parseInt(Math.random() * endArr.length);
        let endObj = endArr[idx];
        this.setData({
          endLeft: endObj.left,
          endTop: endObj.top,
          endOpacity: 0,
          endScale: 0.2,
        }, () => {
          setTimeout(() => { resolve(); }, (this.data.gameData.moveTime || 0.2) * 1000)
        })
      })
    },
    replaceAni(prevIdx, curIdx, nextIdx) {
      return new Promise((resolve, reject) => {
        this.setData({
          prevIdx,
          curIdx,
          nextIdx,
        }, () => {
          setTimeout(() => { resolve(); }, (this.data.gameData.aniTime || 0.2) * 1000)
        })
      })
    },
    leftAni() {
      return new Promise((resolve, reject) => {
        let curIdx = this.data.curIdx - 1;
        curIdx = this.checkV(curIdx);
        let prevIdx = this.checkV(curIdx - 1);
        let nextIdx = this.checkV(curIdx + 1);
        this.setData({
          prevIdx,
          curIdx,
          nextIdx,
        }, () => {
          setTimeout(() => { resolve(); }, (this.data.gameData.aniTime || 0.2) * 1000)
        })
      })
    },
    rightAni() {
      return new Promise((resolve, reject) => {
        let curIdx = this.data.curIdx + 1;
        curIdx = this.checkV(curIdx);
        let prevIdx = this.checkV(curIdx - 1);
        let nextIdx = this.checkV(curIdx + 1);
        this.setData({
          prevIdx,
          curIdx,
          nextIdx,
        }, () => {
          setTimeout(() => { resolve(); }, (this.data.gameData.aniTime || 0.2) * 1000)
        })
      })
    },
    clickFun(e) {
      let { currentTarget: { dataset: { index } } } = e;
      if (!this.gameStatus) { return false; }
      this.parFun("onUpdate", { index });
    },
    async start() {
      if (this.gameStatus) { return false; }
      this.gameStatus = true;
      await this.moveAni();
      await this.replaceAni(1, 0, 2);
      await this.replaceAni(1, 2, 0);
      await this.replaceAni(0, 2, 1);
      await this.replaceAni(2, 0, 1);
    },
    stop() {
      this.gameStatus = false;
      // this.destroy();
      // this.replaceAni(0, 1, 2);
    },
    reset() {
      this.componentInit();
    }
  },
});