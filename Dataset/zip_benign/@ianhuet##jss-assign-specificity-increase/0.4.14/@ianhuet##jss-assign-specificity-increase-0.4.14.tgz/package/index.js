/**
 * Fork jss-increase-specificty to add declared prefix
 * by @ianhuet, 2022-01-19
 * 
 * use :not(#\20), :not(.\20) and :not(\20) instead of generating unlikely
 * appearing ids…
 * — twitter.com/subzey/status/829050478721896448
 * Rationale: \20 is a css escape for U+0020 Space, and neither classname,
 * nor id, nor tagname can contain a space
 * — twitter.com/subzey/status/829051085885153280
 */

var selector = ':not(#\\20)';
var defaultOptions = { prefix: selector, separatePrefix: false, repeat: 1 };

module.exports = function assignSpecificityIncrease(userOptions) {
  var options = Object.assign({}, defaultOptions, userOptions);
  var prefix = Array(options.repeat + 1).join(options.prefix);
  var selectors = prefix.split(' ');
  var pattern = selectors.length > 1 ? `^(${prefix}|${selectors.join('|')})` : prefix;

  function onProcessRule(rule, sheet) {
    var parent = rule.options.parent;

    if (
      sheet.options.assignSpecificityIncrease === false ||
      rule.type !== 'style' ||
      (parent && parent.type === 'keyframes')
    ) return;

    const avoidDuplicatePrefix = new RegExp(pattern)
    if (avoidDuplicatePrefix.test(rule.selectorText)) {
      return;
    }

    if (options.separatePrefix) {
      prefix = prefix + ' ';
    }

    rule.selectorText = prefix + rule.selectorText;
  }

  return { onProcessRule: onProcessRule };
};
