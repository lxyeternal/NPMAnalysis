# JSNoterk

A cli tool for taking JavaScript notes. Includes in-browser bundling and transpiling with **esbuild**, as well as a text editor with **markdown** support.

The original was developed by [Stephen Grider](https://www.udemy.com/user/sgslo/), from his course on [React and Typescript: Build a Portfolio Project](https://www.udemy.com/course/react-and-typescript-build-a-portfolio-project/). If you want to learn to build this app yourself then here you go!

Essentially, this app is like a Jupyter Notebook, but for JavaScript. It's an interactive browser-based coding environment. Code is bundled and transpiled in the browser by esbuild, which is included using a wasm wrapper. You can even import NPM packages and CSS! These will be fetched from unpkg and included in the file. There's also a cumulative code feature so subsequent code cells will have access to variables and data declared in prior cells.

# CLI Usage

```sh
npx jsnoterk [options] [command]
```

- `serve [options] [filename]` - open a file for editing
- `help [command]` - display help for command

### Serve Command

```sh
npx jsnoterk serve [options] [filename]
```

- `-p, --port <number>` - port to run server on (default: `4005`)
- `[filename]` - specify filename to use (default: `notebook.js`)

> `Serve` is the only available command at this time. Eventually there could be a `Login` and `Publish` as a way to allow users to publish their notes to a publicly accessible url.

# Features

- Code Editor
  - [Monaco Editor](https://microsoft.github.io/monaco-editor/)
  - Import NPM Modules - Imports are dynamically fetched using unpkg. The bundler will account for nested imports too.
  - Import CSS - Stylesheets can be imported as well. However, some modern features of CSS won't work due to the way CSS gets included.
  - File Caching - To avoid endless network requests, `localForage` is used to store fetched content in IndexedDB.
  - Debounced Bundling - Stop typing code for at least 1 second in order for bundling to occur.
  - `show()` - built-in feature allows rendering to the preview window without setup.
    - Example: `show('Text')`
    - Example: `show(<div>JSX Element</div>)`
  - Formatting: `Prettier` is built-in. Click the **Format** button to format your code.
  - Cumulative Code Bundling - Subsequent cells include declarations from previous cells. No need to duplicate code.
  - Error Handling - The preview window listens for `error` and `message` events. The bundler also returns an error message if it fails.
- Text Editor
  - Markdown - Features of the [Markdown Editor](https://www.npmjs.com/package/@uiw/react-md-editor) are provided by its developer. Some CSS was applied.
- General
  - Automatic Saving - Stop updating global cell state for at least 0.5 seconds and the save file will be updated.
  - Add new Text or Code cells
  - Move Cells up or down
  - Delete Cells

# Credits

Here are some great packages used for this project. Check them out!

- [@fortawesome/fontawesome-free](https://www.npmjs.com/package/@fortawesome/fontawesome-free)
- [@monaco-editor/react](https://www.npmjs.com/package/@monaco-editor/react)
- [@uiw/react-md-editor](https://www.npmjs.com/package/@uiw/react-md-editor)
- [axios](https://www.npmjs.com/package/axios)
- [bulma](https://www.npmjs.com/package/bulma)
- [bulmaswatch](https://www.npmjs.com/package/bulmaswatch)
- [esbuild](https://esbuild.github.io/)
- [esbuild-wasm](https://www.npmjs.com/package/esbuild-wasm)
- [immer](https://www.npmjs.com/package/immer)
- [jscodeshift](https://www.npmjs.com/package/jscodeshift)
- [localforage](https://www.npmjs.com/package/localforage)
- [monaco-editor](https://www.npmjs.com/package/monaco-editor)
- [monaco-jsx-highlighter](https://www.npmjs.com/package/monaco-jsx-highlighter)
- [prettier](https://www.npmjs.com/package/prettier)
- [react](https://www.npmjs.com/package/react)
- [react-resizable](https://www.npmjs.com/package/react-resizable)
- [redux](https://www.npmjs.com/package/redux)
- [typescript](https://www.npmjs.com/package/typescript)
- [@types](https://github.com/DefinitelyTyped/DefinitelyTyped)

- [commander](https://www.npmjs.com/package/commander)
- [http-proxy-middleware](https://www.npmjs.com/package/http-proxy-middleware)

- [lerna](https://www.npmjs.com/package/lerna)
