/* eslint-disable @typescript-eslint/no-explicit-any */
declare module "@brian-dausman/aog-widget" {
  export interface WidgetConfig {
    projectId: string;
    animation?: any;
    button?: any;
    messages?: any;
    modal?: any;
    ratings?: any[];
    inputs?: any;
    submit?: any;
    theme?: any;
    onSubmit?: (payload: any) => Promise<void>;
    disableScreenshot?: boolean;
  }
  const widget: {
    init(config: WidgetConfig): {
      open(): void;
      close(): void;
      setProject(projectId: string): void;
    };
  };

  export default widget;
}
