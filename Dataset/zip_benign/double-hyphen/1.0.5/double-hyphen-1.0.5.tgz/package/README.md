# double-hyphen
Node.js Argv Parser

## Install
```
npm install double-hyphen
```
## Use
```javascript
var args = require('double-hyphen');
```
## Command Line
```
$ node foo.js --a --b=1 --c=1.5 --d=.5 --e=0 --f=FALSE --g=true --h=/a/b/c
```
```
{
  a: true,
  b: 1,
  c: 1.5,
  d: 0.5,
  e: 0,
  f: false,
  g: true,
  h: '/a/b/c'
}
```