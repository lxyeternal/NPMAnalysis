#!/usr/bin/env node

var args = process.argv;

var double_hyphen = function() {
    'use strict';

    var flags = {};

    args.filter(function(arg) {
        return /^--+/.test(arg);
    }).map(function(arg) {
        return arg.replace(/^--+/, '');
    }).forEach(function(arg) {
        var key, value, isBoolean, isNumber;

        if (arg.indexOf('=') < 0)
            return (flags[arg.toLowerCase()] = true);

        arg = arg.split('=');
        key = arg[0];
        value = arg[1];
        isBoolean = /^(true|false)$/i.test(value);
        isNumber = !isNaN(value);

        flags[key.toLowerCase()] =
            (isBoolean) ? /true/i.test(value) :
            (isNumber) ? +value : value;
    });

    return flags;
};

module.exports = double_hyphen();