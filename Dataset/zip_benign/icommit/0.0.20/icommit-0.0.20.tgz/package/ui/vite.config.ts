// Plugins
import vue from '@vitejs/plugin-vue'
import vuetify, { transformAssetUrls } from 'vite-plugin-vuetify'
import ViteFonts from 'unplugin-fonts/vite'

// Utilities
import { defineConfig } from 'vite'
import { fileURLToPath, URL } from 'node:url'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    vue({
      template: { transformAssetUrls }
    }),
    // https://github.com/vuetifyjs/vuetify-loader/tree/next/packages/vite-plugin
    vuetify({
      autoImport: true,
    }),
    ViteFonts({
      google: {
        families: [{
          name: 'Roboto',
          styles: 'wght@100;300;400;500;700;900',
        }],
      },
    }),
  ],
  define: { 'process.env': {} },
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    },
    extensions: [
      '.js',
      '.json',
      '.jsx',
      '.mjs',
      '.ts',
      '.tsx',
      '.vue',
    ],
  },
  server: {
    port: 8401,
    host: '0.0.0.0',
    open: '/',
    headers: {
      Wsp: 8402,
      host: '0.0.0.0'
    }
  },
  preview: {
    port: 8401,
    host: '0.0.0.0',
    open: '/',
    headers: {
      Wsp: 8402,
      host: '0.0.0.0'
    }
  },
  build: {
    // 将Web Worker文件复制到输出目录
    assetsInlineLimit: 0,
  },
  // 注册Web Worker
  optimizeDeps: {
    include: ['src/workers/**/*.worker.ts'],
  },
})
