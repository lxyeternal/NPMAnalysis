# icommit

### 介绍

icommit 是一个撰写合格 Commit message 的工具，遵循 angular commit 规范。

以后，凡是用到 git commit 命令，一律改为使用 `git ct`。这时，就会出现选项，用来生成符合格式的 Commit message。

#### 0. `git ct`

##### 0.1 选择 Commit 类型

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015210722594511/fe7df4f93b2c277575ae9d4ff.jpg" alt="步骤1"/>

##### 0.2 输入 Commit 主题

> 尽量简洁明了，不用写的过于细节。

> 建议不超过 50 个字符

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015257989672395/75451086f6c9e8bb02cc67500.jpg" alt="步骤2"/>

##### 0.3 输入影响范围(scope)

> 用于说明 Commit 影响的范围

> 如果不止一个 scope，则直接按 `Enter`

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015283519618053/75451086f6c9e8bb02cc67501.jpg" alt="步骤3"/>

##### 0.4 输入关联的 Issue 编号

> 可以是 github/gitlab 等的 Issue 编号；也支持 `teambition` 的 `taskId`

> 会在当次 Commit 中添加 `Closes #编号` 的 Footer；生成 `CHANGELOG` 时，会创建一个超链

> 多个编号用 `,` 分隔；同一次提交，编号应该为同一类型

> 如果没有，则按 `Enter` 跳过

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015301101114102/75451086f6c9e8bb02cc67502.jpg" alt="步骤4"/>

##### 0.5 选择 Issue 编号的类型

> 关联上一步，选择 Issue 编号的类型

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015315502050640/75451086f6c9e8bb02cc67503.jpg" alt="步骤5"/>

##### 0.6 输入 Commit 详细说明

> 是对当次 Commit 的详细描述

> 如果没有，则按 `Enter` 跳过

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015336506829668/75451086f6c9e8bb02cc67504.jpg" alt="步骤6"/>

##### 0.7 是否存在不兼容变动

> 如果当次 Commit 会导致某些代码存在不兼容的修改，则输入 `Y`；否则直接按 `Enter`

> 输入 `Y`，则进入 `0.9`

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015405640627137/75451086f6c9e8bb02cc67507.jpg" alt="步骤9"/>

> 输入 `N`，或直接按 `Enter` ，则进入 `0.8`

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015359588173783/75451086f6c9e8bb02cc67505.jpg" alt="步骤7"/>

##### 0.8 提交成功

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015372589927438/75451086f6c9e8bb02cc67506.jpg" alt="步骤8"/>

##### 0.9 输入不兼容的变动

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015441808682572/75451086f6c9e8bb02cc67508.jpg" alt="步骤10"/>

> 内容模板

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015456129566265/75451086f6c9e8bb02cc67509.jpg" alt="步骤11"/>

> 保存

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015467093779849/75451086f6c9e8bb02cc6750a.jpg" alt="步骤12"/>

##### 0.10 提交成功

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015486660439577/75451086f6c9e8bb02cc6750b.jpg" alt="步骤13"/>

##### 提交的 Commit 具体内容

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015513240763030/75451086f6c9e8bb02cc6750c.png" alt="步骤14"/>

#### 1. `git cl`

##### 生成 CHANGELGO

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015525739590537/75451086f6c9e8bb02cc6750d.jpg" alt="步骤15"/>

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015539332193092/75451086f6c9e8bb02cc6750e.png" alt="步骤16"/>

##### 生成的 CHANGELOG 示例

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015562112231464/75451086f6c9e8bb02cc6750f.png" style="border: 1px solid #333;" alt="步骤17"/>

<img src="https://storage-public.zhaopin.cn/kongxuan/org/image/1697015577083969122/75451086f6c9e8bb02cc67510.png" style="border: 1px solid #333;" alt="步骤18"/>

#### 选项

使用 `-l` 或 `--lite`，生成精简的 Commit message

```bash
git ct -l

// 或

git ct --lite
```

    [旗子] Angular Commit 规范
    [旗子] 可自动生成 CHANGELOG
    [旗子] 使用 git ct 代替 git commit

### 1. 安装

```bash
npm i icommit -g
```

### 2. 使用

#### 2.1 `git ct`

> 之前使用 git commit 的地方，直接用 git ct 代替，ct 为 commit 缩写

`git ct` 命令只会生成并提交 Commit，不会执行 `git push`，需要手动执行 `git push`，或执行 `git cl`

##### 2.1.1 支持 -l 或--lite

> 生成最小单元的 Commit Message

#### 2.2 git cl

> cl 为 changelog 缩写，用于生成 CHANGELOG

> git cl 包含多个命令

- 生成 CHANGELOG
- git add package.json && git add CHANGELOG.md
- git tag X.X.X（tag 为 package.json 中的 `version` 字段）
- git push

### 3. 工作流

    3.1. 修改代码
    3.2. git add .
    3.3. git ct 生成语义化的 Commit Message
    3.4. 可选的:git cl 生成 CHANGELOG，执行此步时，不需要再执行第 5 步
    3.5. 未执行第 4 步时，执行此步。git push

### 4. Commit 建议

- 少修改，多提交。尽可能每改一个要点就提交一次
- 不要每提交一次就推送一次，多积攒几个提交后一次性推送

### 5. Commit Type

- feat: 新增 feature
- fix: 修复 bug
- docs: 仅仅修改了文档，如 readme.md
- style: 仅仅是对格式进行修改，如逗号、缩进、空格等。不改变代码逻辑。
- refactor: 代码重构，没有新增功能或修复 bug
- perf: 优化相关，如提升性能、用户体验等。
- test: 测试用例，包括单元测试、集成测试。
- chore: 改变构建流程、或者增加依赖库、工具等。
- build: 影响项目构建或依赖项修改
- ci: 持续集成相关文件修改
