当**defineSteps**方法入参为**str 类型**的**html**时将自动获取 html 中的特定属性值  
实例:`driver.defineSteps('html').start();`

附加了**nowStep**属性代表当前步骤 回调**onNext,onPrevious**中获得
| 属性名| 对应功能| 默认值| 可选参数|
| ------ | ------ | ------ | ------ |
| d-title| 标题| 无| 任何属性为 str 的值|
| d-val| 内容| 无| 任何属性为 str 的值|
| d-position| 位置| bottom| 'left','right','top','bottom'|
| d-classname| 额外添加的 class| 无| |
| d-nextbtn| 下一步的按钮文本| 对象的 option| 任何属性为 str 的值|
| d-prevbtn| 上一步的按钮文本| 对象的 option| 任何属性为 str 的值|
| d-closebtn| 关闭的按钮文本| 对象的 option| 任何属性为 str 的值|
