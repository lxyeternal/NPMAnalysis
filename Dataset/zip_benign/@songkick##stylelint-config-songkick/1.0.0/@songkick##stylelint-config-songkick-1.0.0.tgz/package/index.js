module.exports = {
    rules: {

        // General
        "indentation": 4,
        "max-empty-lines": 1,
        "no-empty-source": true,
        "no-eol-whitespace": true,
        "no-extra-semicolons": true,
        "no-invalid-double-slash-comments": true,
        "string-no-newline": true,

        // Rules
        "rule-empty-line-before": ["always-multi-line", {
            "except": ["after-single-line-comment", "first-nested"]
        }],

        // Selectors
        "selector-attribute-brackets-space-inside": "never",
        "selector-attribute-operator-space-after": "never",
        "selector-attribute-operator-space-before": "never",
        "selector-descendant-combinator-no-non-space": true,
        "selector-combinator-space-after": "always",
        "selector-combinator-space-before": "always",
        "selector-list-comma-space-before": "never",
        "selector-list-comma-newline-after": "always",
        "selector-no-qualifying-type": [true, {
            "ignore": ["attribute"]
        }],
        "selector-max-empty-lines": 0,
        "selector-pseudo-class-case": "lower",
        "selector-pseudo-class-no-unknown": true,
        "selector-pseudo-class-parentheses-space-inside": "never",
        "selector-pseudo-element-case": "lower",
        "selector-pseudo-element-no-unknown": true,
        "selector-type-case": "lower",
        "selector-type-no-unknown": true,

        // Blocks
        "block-closing-brace-newline-after": "always",
        "block-closing-brace-newline-before": "always-multi-line",
        "block-no-empty": true,
        "block-opening-brace-space-before": "always",

        // Declarations
        "declaration-bang-space-after": "never",
        "declaration-bang-space-before": "always",
        "declaration-colon-newline-after": "always-multi-line",
        "declaration-colon-space-after": "always",
        "declaration-colon-space-before": "never",
        "declaration-block-no-duplicate-properties": [true, {
            "ignore": ["consecutive-duplicates-with-different-values"]
        }],
        "declaration-block-trailing-semicolon": "always",
        "declaration-block-semicolon-newline-after": "always-multi-line",
        "declaration-block-semicolon-newline-before": "never-multi-line",
        "declaration-block-semicolon-space-after": "always-single-line",
        "declaration-block-single-line-max-declarations": 1,
        "declaration-block-no-shorthand-property-overrides": true,
        "declaration-no-important": true,

        // Properties
        "property-case": "lower",
        "property-no-unknown": [ true, {
            "checkPrefixed": true
        }],

        // @-rules
        "at-rule-name-case": "lower",
        "at-rule-name-space-after": "always",
        "at-rule-semicolon-newline-after": "always",
        "media-feature-name-case": "lower",
        "media-feature-colon-space-after": "always",
        "media-feature-colon-space-before": "never",
        "media-feature-range-operator-space-after": "always",
        "media-feature-range-operator-space-before": "always",
        "media-query-list-comma-newline-after": "always-multi-line",
        "media-query-list-comma-space-after": "always",
        "media-query-list-comma-space-before": "never",
        "keyframe-declaration-no-important": true,

        // Functions
        "function-comma-space-after": "always",
        "function-comma-space-before": "never",
        "function-max-empty-lines": 0,
        "function-name-case": "lower",
        "function-parentheses-newline-inside": "always-multi-line",
        "function-parentheses-space-inside": "never-single-line",
        "function-whitespace-after": "always",
        "function-url-quotes": "never",

        // Values
        "shorthand-property-no-redundant-values": true,
        "value-list-comma-space-after": "always-single-line",
        "value-list-comma-space-before": "never",

        // Color lints
        "color-hex-case": "lower",
        "color-no-invalid-hex": true,

        // Fonts
        "font-family-name-quotes": "always-where-recommended",

        // Units
        "unit-case": "lower",
        "unit-no-unknown": true,
        "number-no-trailing-zeros": true,
        "number-max-precision": 2,
        "number-leading-zero": "always",
        "length-zero-no-unit": true,
    }
};
