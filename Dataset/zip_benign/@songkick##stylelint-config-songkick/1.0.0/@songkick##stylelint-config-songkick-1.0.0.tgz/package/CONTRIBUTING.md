# Contributing

Changes to this linter _must_ be made as a Pull Request, to be discussed by the client-side council team.

When updating or changing files, please set your editor to follow the patterns defined in the `.editorconfig` file included.
