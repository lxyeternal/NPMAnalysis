This package contains type definitions for Grunt 0.4.x.

The project URL or description is http://gruntjs.com

These definitions were written by Jeff May <https://github.com/jeffmay/>, Basarat Ali Syed <https://github.com/basarat/>.

Typings were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped in the gruntjs directory.

Additional Details
 * Last updated: Fri, 01 Apr 2016 16:52:10 GMT
 * Typings kind: Mixed
 * Library Dependencies: node
 * Module Dependencies: none
 * Global values: grunt
