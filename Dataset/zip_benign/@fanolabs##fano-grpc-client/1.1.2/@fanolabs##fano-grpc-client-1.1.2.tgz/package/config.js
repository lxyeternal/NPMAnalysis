const path = require('path')
module.exports = Object.freeze({
    FANOGRPC:{
        NAME: 'FANOGRPC',
        ASR_HIGHWATERMARK: 2400,
        ASR_ENGINE: 'fano-grpc-node',
        IS_SSL: process.env.MIDDLEWARE_FANO_GRPC_IS_SSL || 'true',
        CA_CERT_PATH: process.env.MIDDLEWARE_FANO_GRPC_CA_PATH || path.resolve(process.cwd(), './vad-ssl/ca.crt'),
        PK_PATH: process.env.MIDDLEWARE_FANO_GRPC_PK_PATH || path.resolve(process.cwd(), './vad-ssl/tls.key'),
        CERTIFICATE_CHAIN_PATH: process.env.MIDDLEWARE_FANO_GRPC_CHAIN_PATH || path.resolve(process.cwd(), './vad-ssl/tls.crt'),
        POOL_SIZE: process.env.MIDDLEWARE_FANO_GRPC_POOL_SIZE || 6 
    },
})