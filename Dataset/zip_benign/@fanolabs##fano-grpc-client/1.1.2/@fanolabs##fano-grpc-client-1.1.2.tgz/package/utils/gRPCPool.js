const { getGRPCCall } = require('./gRPCClient');
const { sleep } = require('../utils/common');
const { struct } = require('pb-util');
const commonTimeout = 60000
const connectFile = Buffer.from([127, 127, 127, 127]);
let POOL_SIZE = 6;
class CircularQueue {
    constructor(size = 5) {
        this.length = 0;
        this.array = new Array(size);
        this.top = 0;
        this.current = -1;
        this.size = size;
    }
    push(obj) {
        if (this.length >= this.size) return false;
        this.length++;
        this.current = (this.current + 1) % this.size
        this.array[this.current] = obj;
        return true;
    }
    pop() {
        if (this.length <= 0) return null;
        this.length--;
        const result = this.array[this.top];
        this.top = (this.top + 1) % this.size;
        return result;
    }
}
//grpcPoll: {
//     host: pool
// }
const grpcPoll = {};
//working: {
//     host:{
//         length, 
//         workers: {
//             call_id: {
//                 client,
//                 timeout,
//             }
//         }
//     }
// }
const working = {};

const sendConnectAudio = async (client, host, protoPath, package, serverName, method) => {
    if (!!client) await doWrite(client, package).catch((err) => {
        console.info(err)
        client = null;
    });
    if(!protoPath) return client;
    let i = 1;
    while (i < 5 && (!client || !client.reading)) {
        client = getGRPCCall(protoPath, host, package, serverName, method);
        await doWrite(client, package).catch((err) => {
            console.info(err)
            client = null;
        });
        i++;
    }
    return client
}
const workerDestroy = async (call_id, host, package) => {
    if (!working[host] || !working[host].workers[call_id] || !working[host].workers[call_id].client) return;
    clearTimeout(working[host].workers[call_id].timeout)
    let client = working[host].workers[call_id].client;
    client = await sendConnectAudio(client, host, null, package)
    clearEvents(client);
    if (!!client) grpcPoll[host].push(client);
    working[host].length = working[host].length - 1;
    delete working[host].workers[call_id];
}
const getGRPCClient = async (call_id, host, protoPath, package, serverName, method) => {
    try {
        let client;
        const poll = grpcPoll[host]
        if (!working[host] || !working[host].length) {
            working[host] = { length: 1, workers: { [call_id]: {} } };
        } else {
            working[host].length = working[host].length + 1
            working[host].workers[call_id] = {}
        }
        if (!poll) {
            client = await initPool(host, protoPath, package, serverName, method);
        } else {
            let retryCount = 0;
            while (retryCount < 3 && poll.length < 1) {
                retryCount++;
                await sleep(2000);
            }
            if (poll.length < 1) {
                console.info(JSON.stringify({message: `No connection left with host ${host}`}));
                return null;
            }
            else {
                while (!client && poll.length > 0) {
                    client = poll.pop();
                }
            }
        }
        if (!!client) {
            working[host].workers[call_id].client = client;
            working[host].workers[call_id].timeout = setTimeout(workerDestroy, commonTimeout, call_id, host, package);
            client.on('data', () => {
                clearTimeout(working[host].workers[call_id].timeout);
                working[host].workers[call_id].timeout = setTimeout(workerDestroy, commonTimeout, call_id, host, package);
            });
        } else {
            working[host].length = working[host].length - 1;
            delete working[host].workers[call_id];
        }
        return client;
    } catch (e) {
        console.info(e)
    }
}
const clearEvents = client => {
    if(!client) return;
    client.removeAllListeners('data');
    client.removeAllListeners('error');
    client.removeAllListeners('finish');
}
const doWrite = async (client, package, metadata = {}) => {
    return new Promise(async (resolve, reject) => {
        const isVad = package == 'fano_ms_online_vad';
        client.on('data', (res) => {
            clearEvents(client);
            resolve(res)
        }).on('error', (err) => {
            clearEvents(client);
            reject(err)
        })
        const data = {
            frequency: 16000,
            chunk: connectFile,
            sos: true,
            eos: true,
            metadata: struct.encode(metadata)
        }
        if (isVad) {
            data.tipping_point = { value: 0.3 };
            data.trail_silence = { value: 500 };
            data.thresh = { value: 0.9 };
        }
        await client.write(data);
    })
}
const initPool = async (host, protoPath, package, serverName, method) => {
    const client = await sendConnectAudio(null, host, protoPath, package, serverName, method);
    if (!working[host] || !working[host].length || !grpcPoll[host]) {
        grpcPoll[host] = new CircularQueue(POOL_SIZE);
        process.nextTick(async () => {
            try {
                let i = 0;
                while (grpcPoll[host].length + working[host].length < POOL_SIZE && i < 5) {
                    const tempClient = await sendConnectAudio(null, host, protoPath, package, serverName, method);
                    if (!!tempClient && !!tempClient.reading) grpcPoll[host].push(tempClient);
                    else i++;
                } 
            } catch (e) { }
        });
        setInterval(checkHealth, commonTimeout, host, protoPath, package, serverName, method)
    }
    return client
}
const checkHealth = async (host, protoPath, package, serverName, method) => { 
    let workersLength = working[host].lenght;
    let poolLength = grpcPoll[host].length;
    let message = `Health Check Before(${host})`;
    console.info(JSON.stringify({ message, POOL_SIZE, workersLength, poolLength }));
    const poll = grpcPoll[host];
    const array = [];
    let index = 0;
    while (array.length + working[host].length < POOL_SIZE && index < 3) {
        index += (poll.lenght > 0 ? 0 : 1)
        const client = await sendConnectAudio(poll.pop(), host, protoPath, package, serverName, method);
        if (!!client) array.push(client);
    }
    array.forEach(client => {
        if (!!client) poll.push(client);
    });
    workersLength = working[host].lenght;
    poolLength = grpcPoll[host].length;
    message = `Health Check After(${host})`;
    console.info(JSON.stringify({ message, POOL_SIZE, workersLength, poolLength }));
}
const poolSizeInit = (size) => {
    POOL_SIZE = size;
}
module.exports = {
    getGRPCClient,
    workerDestroy,
    poolSizeInit
}