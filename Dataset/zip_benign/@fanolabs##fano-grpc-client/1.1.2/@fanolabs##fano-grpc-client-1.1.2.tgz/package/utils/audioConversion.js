const cp = require('child_process');
const stream = require('stream');
const bufferToStream = require('buffer-to-stream');
const process = require('process')


const _buildSoxProcessOutputArgs = ({
  noDither=true,
  inputRate=16000,
  inputFormat='raw',
  inputChannels=1,
  inputEncoding='signed-integer',
  inputBits=16,
  outputRate=16000,
  outputFormat='raw',
  outputChannels=1,
  outputEncoding='signed-integer',
  outputBits=16,
}) => {
  let soxProcessArgsString = '';
  if (!!noDither) soxProcessArgsString = `${soxProcessArgsString} -D`;
  if (inputRate > 0) soxProcessArgsString = `${soxProcessArgsString} -r ${inputRate}`;
  if (!!inputFormat) soxProcessArgsString = `${soxProcessArgsString} -t ${inputFormat}`;
  if (inputChannels > 0) soxProcessArgsString = `${soxProcessArgsString} -c ${inputChannels}`;
  if (!!inputEncoding) soxProcessArgsString = `${soxProcessArgsString} -e ${inputEncoding}`;
  if (inputBits > 0) soxProcessArgsString = `${soxProcessArgsString} -b ${inputBits}`;
  soxProcessArgsString = `${soxProcessArgsString} -`;
  if (outputRate > 0) soxProcessArgsString = `${soxProcessArgsString} -r ${outputRate}`;
  if (!!outputFormat) soxProcessArgsString = `${soxProcessArgsString} -t ${outputFormat}`;
  if (outputChannels > 0) soxProcessArgsString = `${soxProcessArgsString} -c ${outputChannels}`;
  if (!!outputEncoding) soxProcessArgsString = `${soxProcessArgsString} -e ${outputEncoding}`;
  if (outputBits > 0) soxProcessArgsString = `${soxProcessArgsString} -b ${outputBits}`;
  soxProcessArgsString = `${soxProcessArgsString} -`;
  return  soxProcessArgsString
    .split(' ')
    .filter(str => !!str)
    .map(str => str.trim());
};


/**
 *
 * @param {Buffer} buffer Audio file buffer
 * @param {Object} conversionConfig Configuration of audio conversion
 * @returns {Promise<Buffer>} The converted audio buffer
 */
const convertAudio = async (buffer, conversionConfig = {}) => {
  return new Promise((resolve, reject) => {
    const audioStream = bufferToStream(buffer);
    const convertedAudioBufferArr = [];

    let { inOutConfig = {} } = conversionConfig;

    const soxProcessArgs = _buildSoxProcessOutputArgs(inOutConfig);

    const soxProcess = cp.spawn('sox', soxProcessArgs);

    let convertedStream = new stream.PassThrough();

    soxProcess.stderr.setEncoding('utf8');
    // soxProcess.stderr.on('data', data => {
    //   // We are not rejecting with data from stderr as it includes warning message
    // });


    audioStream.pipe(soxProcess.stdin);       // audioStream STREAM TO soxProcess stdin
    soxProcess.stdout.pipe(convertedStream);  // soxProcess stdout STREAM to passThroughStream

    soxProcess.stdin.on('error', err => reject(err));

    // Hacky workaround
    // It is required to listen to 'data' event and push it to buffer instead of piping directly to output stream
    // This is because when we are converting from mp3 to other format, warning in audio will make the pipeline get stuck
    // This is also the reason why sox-stream library create temp. file in order to get rid of the stuck-by-warning issues
    convertedStream
      .on('finish', () => {
        // setTimeout(() => {
        //   soxProcess.kill();
        //   resolve(Buffer.concat(convertedAudioBufferArr));
        // }, timeout)
        process.nextTick(() => {
          soxProcess.kill();
        })
        resolve(Buffer.concat(convertedAudioBufferArr));
      })
      .on('error', err => {
        reject(err);
      })
      .on('data', data => {
        convertedAudioBufferArr.push(data);
      });
  });
};


module.exports = {
  convertAudio,
};
