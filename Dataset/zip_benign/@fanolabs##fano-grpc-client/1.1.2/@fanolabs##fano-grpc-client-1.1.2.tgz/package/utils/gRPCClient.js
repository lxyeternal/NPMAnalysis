const grpc = require('grpc');
const protoLoader = require('@grpc/proto-loader');
const fs = require('fs')
let is_ssl = false, CA_CERT_PATH, PK_PATH, CERTIFICATE_CHAIN_PATH;
const sslAbled = (caCertPath, pkPath, certificateChainPath) => {
    is_ssl = true;
    CA_CERT_PATH = caCertPath;
    PK_PATH = pkPath;
    CERTIFICATE_CHAIN_PATH = certificateChainPath;
}
const sslDisabled = () => {
    is_ssl = false;
}
const getGRPCCall = (path, host, package, serverName, methodName) => {
    console.info(JSON.stringify({ message: 'GRPC query', path, host, package, serverName, methodName}));
    const packageDefinition = protoLoader.loadSync(
        path,
        {
            keepCase: true,
            longs: String,
            enums: String,
            defaults: true,
            oneofs: true
        });
    const fano_proto = grpc.loadPackageDefinition(packageDefinition)[package];
    let secure
    if (is_ssl) {
        const ca_cert = fs.readFileSync(CA_CERT_PATH);
        const private_key = fs.readFileSync(PK_PATH);
        const certificate_chain = fs.readFileSync(CERTIFICATE_CHAIN_PATH)
        secure = grpc.credentials.createSsl(ca_cert, private_key, certificate_chain);
    } else {
        secure = grpc.credentials.createInsecure();
    }
    const client = new fano_proto[serverName](host, secure)[methodName]();
    return client;
}
module.exports = {
    getGRPCCall,
    sslAbled,
    sslDisabled
}
