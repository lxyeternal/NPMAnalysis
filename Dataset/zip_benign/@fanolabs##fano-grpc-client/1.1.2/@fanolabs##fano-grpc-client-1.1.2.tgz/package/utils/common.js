const sleep = async (time) => {
    return new Promise(async (resolve, reject) => {
        setTimeout(() => {
            resolve(true);
        }, time)
    })
}
module.exports = {
    sleep
}