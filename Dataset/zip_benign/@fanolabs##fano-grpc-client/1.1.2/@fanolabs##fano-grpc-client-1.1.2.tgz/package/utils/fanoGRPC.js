const { getGRPCClient, workerDestroy } = require('./gRPCPool');
const { struct } = require('pb-util');
const { convertAudio } = require('./audioConversion');
class gRPCEngine {
    constructor(url, callId) {
        this.callId = callId;
        const urlParam = url.split('?')
        this.host = urlParam[0];
        this.params = {};
        if (urlParam.length > 1) {
            urlParam[1].split('&').forEach(e => {
                const keyValue = e.split('=');
                if (keyValue.length > 1) {
                    try {
                        this.params[keyValue[0]] = { value: Number(keyValue[1]) }
                    } catch (e) { }
                }
            });
        }
    }
    async connect(callback) {
        this.client = await getGRPCClient(this.callId, this.host, this.protoPath, this.package, this.serverName, this.method);
        if(!this.client) return false;
        if (!!callback){
            this.client.on('data', res => callback(null, res));
            this.client.on('error', err => callback(err));
        }
        return true;
    }
    async send(bufferData, metadata, inputRate = 8000, inputBits = 16) {
        const client = this.client
        const convertData = await convertAudio(bufferData, { inOutConfig: { inputRate, inputBits } })
        if (!!client && !!client.write) {
            client.write({
                frequency: 16000,
                chunk: convertData,
                sos: metadata.sos,
                eos: metadata.eos,
                ...this.params,
                metadata: struct.encode({ ...metadata, callId: this.callId })
            });
        }
    }
    handleMessage(data) {
        data.metadata = struct.decode(data.metadata);
        return data;
    }
    close() {
        if (!!this.client) {
            workerDestroy(this.callId, this.host, this.package);
            return true;
        } else {
            return false;
        }
    }
}

class vadGRPCEngine extends gRPCEngine {
    constructor(url, callId) {
        super(url, callId);
        this.protoPath =  __dirname + '/gRPCFanoVAD.proto';
        this.package = 'fano_ms_online_vad';
        this.serverName = 'OnlineVAD';
        this.method = 'DetectActivity';
        this.params = {
            tipping_point: { value: 0.3 },
            trail_silence: { value: 500 },
            thresh: { value: 0.9 },
            ...this.params
        }
    }
}

class asrGRPCEngine extends gRPCEngine {
    constructor(url, callId) {
        super(url, callId);
        this.protoPath =  __dirname + '/gRPCFanoAsr.proto';
        this.package = 'fano_ms_online_asr';
        this.serverName = 'OnlineASR';
        this.method = 'Recognize';
    }
    // handleMessage(data) {
    //     // const metadata = struct.decode(data.metadata);
    //     const resultStr = data.trans.split(' ').join('')
    //     const fanoASRJson = {
    //         status: 0,
    //         result: {
    //             hypotheses: [
    //                 {
    //                     transcript: resultStr,
    //                     confidence: 0.9,
    //                     processing_duration: 1.870168924331665,
    //                     received_audio_duration: 4.080000000000001,
    //                     model_rtf: 0.45837473635580017
    //                 }
    //             ],
    //             final: data.is_final
    //         }
    //     }
    //     return { fanoASRJson, callSid: this.callId, resultStatus: data.is_final, resultStr }
    // }
}

module.exports = {
    vadGRPCEngine,
    asrGRPCEngine
}
