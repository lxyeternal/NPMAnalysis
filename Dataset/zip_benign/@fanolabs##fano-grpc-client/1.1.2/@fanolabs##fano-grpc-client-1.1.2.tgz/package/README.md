@fanolabs/fano-grpc-client
==========

[![npm version][npm-image]][npm-url]

FanoLabs gRPC module for Node.js

<!-- TOC -->

- [Installation](#installation)
- [Common Usage](#Common Usage)
- [License](#license)
- [API](#api)
    - [send(bufferData, metadata, inputRate = 8000, inputBits = 16)](#send(bufferData, metadata, inputRate = 8000, inputBits = 16))
    - [handleMessage(data)](#handleMessage(data))
    - [close()](#close())


<!-- /TOC -->

## Installation

Current stable release (`1.0.0`)

```sh
$ npm install @fanolabs/fano-grpc-client --save
```

## Common Usage
We suggest you load the module via `require`, pending the stabalizing of es modules in node:
```js
const { init, vadGRPCEngine, asrGRPCEngine } = require('@fanolabs/fano-grpc-client');
init(poolSize, sslParams = { caCertPath, pkPath, certificateChainPath });
const vadClient = new vadGRPCEngine(
    'fano-ms-online-speech-vad:50000?tipping_point=0.3&trail_silence=500',
    callId
);
vadClient.connet((err, res) => {
    if(!!err) {
        errorHandle(err);
        return;
    }
    const result = client.handleMessage(res);
    dataHandle(result)
});

const asrClient = new asrGRPCEngine(
    'fano-ms-online-speech-asr:50000',
    callId
);
asrClient.connet((err, res) => {
    if(!!err) {
        errorHandle(err);
        return;
    }
    const result = client.handleMessage(res);
    dataHandle(result)
})

```

## API

### send(bufferData, metadata, inputRate = 8000, inputBits = 16)

- `bufferData` 音频文件buffer(分片)。
- `metadata` metadata 可以包含sos、eos、call id等。
- `inputRate` 音频文件采样率。
- `inputBits` 音频文件字节数。

### handleMessage(data)
- `data` response data
- Returns: 

    `Note`: vad response
    ```js
    {
        "activity_code": 2,
        "ongoing_speech": true,
        "metadata": {
            "sos": false,
            "eos": true,
            "callId": "ee00b670f97711eabe553f98332fa274"
        }
    }
    ```

    `Note`: asr response
    ```js
    {
        "trans": "有 問 題 呀",
        "is_final": true,
        "metadata": {
            "sos": false,
            "eos": true,
            "callId": "4596a300f96311eab2bb89c93f468cad"
        }
    }
    ```

### close()

## License

MIT

[npm-image]: https://flat.badgen.net/npm/v/babel-core
[npm-url]: https://www.npmjs.com/package/@fanolabs/fano-grpc-client