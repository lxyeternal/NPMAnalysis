const { init, vadGRPCEngine, asrGRPCEngine } = require('../index')
const path = require('path')
const fs = require('fs')
const files = [fs.readFileSync(path.resolve(process.cwd(), './test/test.pcm')), fs.readFileSync(path.resolve('./test/test1.pcm'))];
const uuid = require('uuid');
const size = 3;
const sslParams = {
    caCertPath: path.resolve(process.cwd(), './vad-ssl/ca.crt'),
    pkPath: path.resolve(process.cwd(), './vad-ssl/tls.key'),
    certificateChainPath:  path.resolve(process.cwd(), './vad-ssl/tls.crt')
}

const main = async (id) => {
    init(size, sslParams);
    const client = new asrGRPCEngine('navinter-asr-dev01.fano.ai:443', uuid.v1().replace(/\-/g, ''));
    if (!client) return;
    if (!await client.connect((err, res) => {
        if(!!err) {
            console.info("error: ", err);
            return;
        }
        const result = client.handleMessage(res);
        if(result.metadata.eos){
            console.info(`No.${id}: `, JSON.stringify(result))
            client.close();
        }
    })) return;
    doWrite(client, files[id % 2]);
}
const doWrite = async (client, file) => {
    let start = 0, size = 2400
    while (start < file.length) {
        const isLast = start + size >= file.length
        const data = isLast ? file.slice(start) : file.slice(start, start + size)
        const metadata = {
            sos: start == 0,
            eos: isLast
        }
        client.send(data, metadata)
        start = start + size
    }
}
const domain = async () => {
    let flag = 0;
    const func = async ()=>{ 
        await main(flag++);
    }
    const func2 = () => {
        if(flag < 60){
            for(let i = 0; i < size; i++) process.nextTick(func);
            setTimeout(func2, 3000);
        }
    }
    func2();
}
domain();
// main(2);
