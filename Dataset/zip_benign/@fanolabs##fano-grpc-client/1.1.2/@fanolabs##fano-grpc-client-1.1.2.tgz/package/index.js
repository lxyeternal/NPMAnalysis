const { sslAbled, sslDisabled } = require('./utils/gRPCClient');
const { poolSizeInit } = require('./utils/gRPCPool')
const { vadGRPCEngine, asrGRPCEngine } = require('./utils/fanoGRPC');
/**
 * pool Initialization
 * @param {Number} poolSize 
 * @param {Object} sslParams { caCertPath, pkPath, certificateChainPath }
 */
const init = (poolSize, sslParams = {}) => {
    poolSizeInit(poolSize);
    if(!sslParams) return;
    const { caCertPath, pkPath, certificateChainPath } = sslParams;
    if( !!caCertPath && !!pkPath && !!certificateChainPath){
        sslAbled(caCertPath, pkPath, certificateChainPath);
    }else{
        sslDisabled();
    }
}
module.exports = {
    init,
    vadGRPCEngine,
    asrGRPCEngine
}