export interface PercentageOptions {
    /**
     * Number of decimals to show after the
     *
     * Defaults to 2
     */
    decimals?: number;
    /**
     * Should the percentage sign be appended to the value?
     *
     * Defaults to `true`
     */
    sign?: boolean;
}
/**
 * Turn the number into a percentage
 *
 * @param absolute  the value (between 0 and 1) to become a percentage
 * @param decimals  the number of decimals to show
 */
export declare function toPercentage(absolute: number, options?: PercentageOptions): string;
export declare namespace toPercentage {
    /**
     * Default options for {@link toPercentage}
     */
    const defaults: Required<PercentageOptions>;
    /**
     * Shift the decimal point to the right
     *
     * @param value   number to shift
     * @param right   places to shift right by (increases numer's size)
     */
    function increaseOrder(value: number, right: number): number;
    /**
     * Round to the given number of decimals
     *
     * @param value           value to trim decimals from
     * @param keepDecimals    the numer of decimals to keep
     * @returns               the number rounded to the given decimals
     */
    function round(value: number, keepDecimals: number): number;
    /**
     * Get the safe floor of a floating point number
     *
     * @param number
     * @returns
     */
    function floatingFloor(number: number): number;
}
