# `nn-randomizing`

> Functions for getting random values.

## Usage

* Assume container = { 'A': 1, 'B': 2, 'C': 3 } and list = [ 1, 2, 3, 4, 5, 6, 7, 8, 9 ].

```
import { getRandomInteger } from 'nn-randomize';
import { getRandomNumber } from 'nn-randomize';
import { getRandomIndex } from 'nn-randomize';
import { getRandomValue } from 'nn-randomize';

// Get a random integer from 1 to 10.
const num = getRandomInteger( 1, 10 );

// Get a random number from 0.5 to 10.5.
const num = getRandomNumber( 0.5, 10.5 );

// Get a random index from an array. Returns an integer 0 - 8.
const index = getRandomIndex( list );

// Get a random value from an array. Returns an integer 1 - 9.
const value = getRandomValue( list );

// Get a random key from an object. Returns 'A', 'B', or 'C'.
const key = getRandomIndex( container );

// Get a random value from an object. Returns 1, 2, or 3.
const value = getRandomValue( container );

// Returns a copy of list with values in random order.
const scrambled = scramble( list );
```
