import type { Plugin } from '@vuepress/core';
import { ribbonDataOption } from '../types';
export * from '../types';
export declare const ribbon: (options?: ribbonDataOption) => Plugin;
