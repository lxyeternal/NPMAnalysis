export interface ribbonOption {
    colorSaturation: string;
    colorBrightness: string;
    colorAlpha: number;
    colorCycleSpeed: number;
    verticalPosition: string;
    horizontalSpeed: number;
    ribbonCount: number;
    strokeSize: number;
    parallaxAmount: number;
    animateSections: true;
}
export interface ribbonDataOption {
    size: number;
    opacity: number;
    zIndex: number;
    option: ribbonOption;
    ribbonShow: boolean;
    ribbonAnimationShow: boolean;
}
