export declare enum RESULT_SCORE {
    WIN = 1,
    DRAW = 0.5,
    LOSS = 0
}
export declare enum IMPORTANCE {
    FRIENDLY_OUTSIDE_WINDOW = 5,
    FRIENDLY_INSIDE_WINDOW = 10,
    GROUP_NATIONS_LEAGUE = 15,
    PLAY_OFF_AND_FINAL_NATIONS_LEAGUE = 25,
    CONF_FINAL_UP_TO_QF = 35,
    CONF_FINAL_QF_AND_ABOVE = 40,
    WORLD_CUP_UP_TO_QF = 50,
    WORLD_CUP_QF_AND_ABOVE = 60
}
interface calculatePointsOptions {
    PBefore: number;
    I: IMPORTANCE;
    W: RESULT_SCORE;
    PBeforeTeamB: number;
    PSO?: boolean;
    KnockoutRound?: boolean;
}
declare const calculatePoints: ({ PBefore, I, W, PBeforeTeamB, PSO, KnockoutRound, }: calculatePointsOptions) => number;
export default calculatePoints;
