var synaptic = require('synaptic');
var parse = require('csv-parse/lib/sync');
var fs = require('fs');
var stats = require('stats-lite');
var fft = require('fft-js').fft;

var stepdata=fs.readFileSync('./data/newSteps.csv','utf8');
stepdata=parse(stepdata, {trim: true, auto_parse: true,relax_column_count:true });


var nostepdata=fs.readFileSync('./data/newNoSteps.csv','utf8');
nostepdata=parse(nostepdata, {trim: true, auto_parse: true,relax_column_count:true });


var set=[];

var signalLength=10;

var setcounter=0;
for (var i=0;i<stepdata.length;i++){
    if (stepdata[i].length>=signalLength){
        var inputdata=[];
        for (var j=0;j<signalLength;j++){
            var scaledPosition=j*stepdata[i].length/signalLength;
            //Linear interpolation
            inputdata[j]=stepdata[i][Math.floor(scaledPosition)]*(1-(scaledPosition%1))+stepdata[i][Math.ceil(scaledPosition)]*(scaledPosition%1);
        }
        var min=Infinity,max=-Infinity;
        var sum=0,sum2=0;
        for (var j=0;j<stepdata[i].length;j++){
            if (stepdata[i][j]<min)
                min=stepdata[i][j];
            if (stepdata[i][j]>max)
                max=stepdata[i][j];
            sum+=stepdata[i][j];
            sum2+=stepdata[i][j]*stepdata[i][j];
        }    
        
        inputdata[signalLength]=sum/stepdata[i].length;
        inputdata[signalLength+1]=(sum2/stepdata[i].length)-inputdata[signalLength]*inputdata[signalLength];
        inputdata[signalLength+2]=min;
        inputdata[signalLength+3]=max;
        //console.log(inputdata);
        set[setcounter++]={
            input:inputdata,
            output:[1]
        };
    }
}
for (var i=0;i<nostepdata.length;i++){ 
    if (nostepdata[i].length>=signalLength){    
        var inputdata=[];
        for (var j=0;j<signalLength;j++){
            var scaledPosition=j*nostepdata[i].length/signalLength;
            //Linear interpolation
            inputdata[j]=nostepdata[i][Math.floor(scaledPosition)]*(1-(scaledPosition%1))+nostepdata[i][Math.ceil(scaledPosition)]*(scaledPosition%1);
        }
         var min=Infinity,max=-Infinity;
        var sum=0,sum2=0;
        for (var j=0;j<nostepdata[i].length;j++){
            if (nostepdata[i][j]<min)
                min=nostepdata[i][j];
            if (nostepdata[i][j]>max)
                max=nostepdata[i][j];
            sum+=nostepdata[i][j];
            sum2+=nostepdata[i][j]*nostepdata[i][j];
        }    
        
        inputdata[signalLength]=sum/nostepdata[i].length;
        inputdata[signalLength+1]=(sum2/nostepdata[i].length)-inputdata[signalLength]*inputdata[signalLength];
        inputdata[signalLength+2]=min;
        inputdata[signalLength+3]=max;
        //console.log(inputdata);
        set[setcounter++]={
            input:inputdata,
            output:[0]
        };
    }
}


var Trainer = synaptic.Trainer,
    Architect = synaptic.Architect;
var myPerceptron = new Architect.Perceptron(signalLength+4, 5,5, 1);
var trainer = myPerceptron.trainer;

function shuffle(o) { //v1.0
  for (var j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
  return o;
}

shuffle(set);

trainer.train(set,{
    rate: 0.0005,
    iterations: 100000,//set.length*20,
    error: 0.0001,
    shuffle: true,
    log: 10,
    cost: Trainer.cost.MSE,
    crossValidate: {
        testSize: 0.5
    }
});


//myPerceptron.optimize();
fs.writeFileSync('./data/neuralnetwork.json',JSON.stringify(myPerceptron.toJSON()),'utf8');

console.log('trained with '+set.length+' samples. Final test MSE: '+trainer.test(set).error);