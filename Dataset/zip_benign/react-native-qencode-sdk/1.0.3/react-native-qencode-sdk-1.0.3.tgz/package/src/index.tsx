import { type ViewProps } from 'react-native';
import { WebView } from 'react-native-webview';
//import React from 'react';

export type QencodePlayerProps = ViewProps & {
  videoSources: any[];
  licenseKey: string;
  withCredentials: boolean;
  size: any;
  titleBar?: any;
  social?: any;
  colors: any;
  thumbnails?: any;
  textTracks?: any[];
  playback: any;
  playerHeight?: number;
  emeHeaders?: any;
  keySystems?: any;
};

export type QencodePlayerSize = {
  aspectRatio?: string;
  fluid: boolean;
  fill: boolean;
};

export function QencodePlayer({
  style,
  videoSources,
  licenseKey,
  withCredentials,
  size,
  titleBar,
  social,
  colors,
  thumbnails,
  textTracks,
  playback,
  playerHeight,
  emeHeaders, 
  keySystems,
  ...otherProps
}: QencodePlayerProps) {
  {
    const INJECTEDJAVASCRIPT =
      "const meta = document.createElement('meta'); meta.setAttribute('content', 'width=device-width, initial-scale=1, maximum-scale=0.99, user-scalable=0'); meta.setAttribute('name', 'viewport'); document.getElementsByTagName('head')[0].appendChild(meta);";
    var heightStyle = '';
    if (playerHeight != null && size != null && size.fill) {
      heightStyle = `style="height: ${playerHeight}px !important;"`;
    }

    return (
      <WebView
        allowsFullscreenVideo={true}
        onLoadEnd={() => console.log('load end')}
        source={{
          html: `<!DOCTYPE html>
        <html>
          <head>
            <meta charset='utf-8'>
          </head>
          <body style="margin:0;padding:0">
            <script src='https://player-static.qencode.com/release/qencode-bootstrapper.min.js'></script>
            <div id='player' ${heightStyle}></div>
            <script>
              qPlayer('player', {
                  licenseKey: '${licenseKey}',
                  videoSources: ${JSON.stringify(videoSources)},
                  withCredentials: ${withCredentials},
                  size: ${JSON.stringify(size)},
                  ${titleBar != null ? 'titleBar: ' + JSON.stringify(titleBar) + ',' : ''}
                  ${social != null ? 'social: ' + JSON.stringify(social) + ',' : ''}
                  colors: ${JSON.stringify(colors)},
                  ${thumbnails != null ? 'thumbnails: ' + JSON.stringify(thumbnails) + ',' : ''}
                  ${textTracks != null ? 'textTracks: ' + JSON.stringify(textTracks) + ',' : ''}
                  ${emeHeaders != null ? 'emeHeaders: ' + JSON.stringify(emeHeaders) + ',' : ''}
                  ${keySystems != null ? 'keySystems: ' + JSON.stringify(keySystems) + ',' : ''}
                  playback: ${JSON.stringify(playback)},
              });  
            </script>    
          </body>
        </html>`,
        }}
        javaScriptEnabled={true}
        userAgent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"
        bounces={false}
        scrollEnabled={false}
        style={style}
        setBuiltInZoomControls={false}
        setDisplayZoomControls={false}
        automaticallyAdjustContentInsets={false}
        injectedJavaScript={INJECTEDJAVASCRIPT}
        {...otherProps}
      />
    );
  }
}
