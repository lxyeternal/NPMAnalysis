import { type ViewProps } from 'react-native';
export type QencodePlayerProps = ViewProps & {
    videoSources: any[];
    licenseKey: string;
    withCredentials: boolean;
    size: any;
    titleBar?: any;
    social?: any;
    colors: any;
    thumbnails?: any;
    textTracks?: any[];
    playback: any;
    playerHeight?: number;
    emeHeaders?: any;
    keySystems?: any;
};
export type QencodePlayerSize = {
    aspectRatio?: string;
    fluid: boolean;
    fill: boolean;
};
export declare function QencodePlayer({ style, videoSources, licenseKey, withCredentials, size, titleBar, social, colors, thumbnails, textTracks, playback, playerHeight, emeHeaders, keySystems, ...otherProps }: QencodePlayerProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map