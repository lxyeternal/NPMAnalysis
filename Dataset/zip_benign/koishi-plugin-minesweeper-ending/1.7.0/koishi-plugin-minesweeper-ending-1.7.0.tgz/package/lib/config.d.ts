import { Schema } from 'koishi';
export declare const MineConfig: Schema<Schemastery.ObjectS<{
    MinHintTime: Schema<number, number>;
    wrongSleep: Schema<number, number>;
    DifficultyLevel: Schema<number, number>;
    InitFlag: Schema<boolean, boolean>;
    InitOpen: Schema<boolean, boolean>;
    Guess: Schema<boolean, boolean>;
}> | Schemastery.ObjectS<{
    theme: Schema<string, string>;
    colorForSerialNum: Schema<string, string>;
}> | Schemastery.ObjectS<{
    width: Schema<number, number>;
    height: Schema<number, number>;
    mines: Schema<number, number>;
}> | Schemastery.ObjectS<{
    widthC: Schema<number, number>;
    heightC: Schema<number, number>;
    minesC: Schema<number, number>;
}> | Schemastery.ObjectS<{
    EntryFee: Schema<number, number>;
}>, {
    MinHintTime: number;
    wrongSleep: number;
    DifficultyLevel: number;
    InitFlag: boolean;
    InitOpen: boolean;
    Guess: boolean;
} & import("cosmokit").Dict & {
    theme: string;
    colorForSerialNum: string;
} & {
    width: number;
    height: number;
    mines: number;
} & {
    widthC: number;
    heightC: number;
    minesC: number;
} & {
    EntryFee: number;
}>;
export interface MineConfig {
    MinHintTime: number;
    wrongSleep: number;
    DifficultyLevel: number;
    InitFlag: boolean;
    InitOpen: boolean;
    Guess: boolean;
    EntryFee: number;
    theme: string;
    colorForSerialNum: string;
    width: number;
    height: number;
    mines: number;
    widthC: number;
    heightC: number;
    minesC: number;
}
export declare const mineUsage: Buffer;
