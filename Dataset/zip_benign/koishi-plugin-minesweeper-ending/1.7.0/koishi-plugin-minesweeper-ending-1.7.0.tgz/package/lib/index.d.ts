import { Context, Schema, Dict, Session } from 'koishi';
import Minefield from "./minesweeper";
export declare const name = "minesweeper-ending";
import { MineConfig } from "./config";
export interface MinesweeperRank {
    id: number;
    userId: string;
    userName: string;
    score: number;
    isFlag: boolean;
    LastChallenge: number;
    ChallengeScore: number;
    openNums: number;
    games: number;
    wins: number;
    title: string;
}
declare module 'koishi' {
    interface Tables {
        minesweeper_ending_rank: MinesweeperRank;
    }
}
declare class EndingGame {
    private config;
    static inject: {
        required: string[];
    };
    minefieldDict: Dict;
    banList: Dict;
    theme: string;
    constructor(ctx: Context, config: MineConfig);
    /**
     * 冻结模块
     * @param userId
     */
    ban(userId: string): Promise<void>;
    checkPermision(userId: string): number;
    /**
     * 提示模块
     * @param m
     * @param session
     * @returns
     */
    getHint(m: Minefield, session: Session, ctx: Context): Promise<string>;
    /**
     *
     * @param m 挑战模式 FL
     * @param inputString
     * @param session
     * @returns
     */
    challengeFl(m: Minefield, inputString: string, session: Session): Minefield;
    /**
     * 挑战模式 NF
     * @param m
     * @param inputString
     * @param session
     * @returns
     */
    challengeNf(m: Minefield, inputString: string, session: Session): Minefield;
    /**
     * 一.初始化，生成一个小的残局
     * 1.破空(就是打开所有雷数为0的格子)
     * 2.随机打开不为雷的格子
     * @param x 行
     * @param y 列
     * @param z 雷
     */
    initialize(x?: number, y?: number, z?: number): Minefield;
    /**
     * random openCell
     */
    makeEnding(m: Minefield): Minefield;
    /**
     * 重置游戏
     * @param session
     * @param x
     * @param y
     * @param z
     * @returns
     */
    renew(session: Session, x: number, y: number, z: number, ctx: Context): Promise<string>;
    /**
     * 删除数字前面的0
     * 01，0002 返回 1 2
     * @param s
     * @returns string
     */
    remove0(s: String): any;
}
declare namespace EndingGame {
    const usage: string;
    const Config: Schema;
}
export default EndingGame;
