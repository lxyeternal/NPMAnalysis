import Minefield from "./minesweeper";
import { MineConfig } from "./config";
import { Context } from "koishi";
/**
 * 初始化
 * @param ctx
 * @param config
 */
export declare function setTheme(ctx: Context, config: MineConfig): Promise<void>;
/**
 * 渲染雷图
 * @param m 雷图对象
 * @returns Arraybuffer
 */
export declare function renderX(m: Minefield, ctx: Context): Promise<Buffer>;
