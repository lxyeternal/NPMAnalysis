import { Context, Keys, Session } from 'koishi';
import Minefield from "./minesweeper";
import { MinesweeperRank } from '.';
export declare const name = "minesweeper-ending";
export interface GameInfo {
    userId: string;
    username: string;
    score: number;
    ChallengeScore: number;
    openNums: number;
    games: number;
    wins: number;
}
/**
 * 无猜暴力求解
 * @param m
 * @param cell
 * @returns
 */
export declare function findNoGuess(m: Minefield, cell: string): Minefield;
/**
 * 数据库操作，抄自[koishi-plugin-minesweeper](https://github.com/araea/koishi-plugin-minesweeper)
 * @param ctx
 * @param userId
 * @param userName
 * @param score
 */
export declare function updateRank(ctx: Context, info: GameInfo): Promise<void>;
/**
 * 设置挑战模式分数
 * @param ctx
 * @param userId
 * @param userName
 * @param score
 */
export declare function updateChallengeRank(session: Session, ctx: Context, userId: string, userName: string, score: number): Promise<void>;
/**
 * 根据雷图的行和列计算出合适的雷数
 * @param x 行
 * @param y 列
 * @returns 雷数
 */
export declare function getMineNums(x: number, y: number): number;
/**
 * 睡眠函数
 * @param ms 等待时间
 * @returns
 */
export declare function sleep(ms: number): Promise<unknown>;
/**
* 获取所有数据
* @param ctx
* @param userId
* @returns
*/
export declare function getProfiles(ctx: Context, userId: string): Promise<Pick<MinesweeperRank, Keys<MinesweeperRank, any>>>;
/**
 * 更新 雷 和 空的池子
 * @param m Minefield
 * @returns Minefield
 */
export declare function makePool(m: Minefield): Minefield;
/**
 * 渲染
 * @param ctx
 * @param info
 * @returns
 */
export declare function renderProfiles(ctx: Context, info: Pick<MinesweeperRank, Keys<MinesweeperRank, any>>): Promise<string>;
