/**
 * An Object containing:
 * @property {Number}  width         - The minefield width (1-based)
 * @property {Number}  height        - The minefield height (1-based)
 * @property {Number}  cells         - The minefield total cells number
 * @property {Number}  mines         - The minefield total mines number
 * @property {Object}  [X]           - Each minefield cell on its index ([0]..[99]+)
 * @property {Boolean} [X].isOpen    - Whether a cell is revealed
 * @property {Boolean} [X].isMine    - Whether a cell is a mine
 * @property {Boolean} [X].isFlagged - Whether a cell is flagged
 * @property {Number}  [X].mines     - Number of mines present around a cell
 */
export default class Minefield {
    /**
     * Creates a new minefield with the given width, height and mines number (and randomizes them)
     * @param {Number} width The width of the minefield (1-based)
     * @param {Number} height The height of the minefield (1-based)
     * @param {Number} mines The number of total mines (default: width*height/5). If an array is given, its values will represent the indexes where the mines will be placed
     * @param {Function} randomizer A function that returns a random decimal number between 0 and 1 (default: {@link Math.random})
     * @returns {Minefield} A new Minefield object
     * @throws An error if parameters are invalid
     */
    width: number;
    height: number;
    cells: any;
    mines: any;
    start_time: number;
    constructor(width: any, height: any, mines?: number, randomizer?: () => number);
    /**
     * Converts the Minefield object to a Minefield2D object.
     *
     * WARNING! The two objects will share the same reference to the same cells so any changes made to one will be reflected in the other
     * @returns {Minefield2D} A Minefield2D object
     * @throws An error if object is already an instance of Minefield2D
     */
    toMinefield2D(): Minefield2D;
    /**
     * Returns a simplified version of the minefield.
     *
     *  - -1: A mine
     *  - [0-8]: A cell with the number of nearby mines
     *
     * @returns {Array.<number>>} A Number-Only array containing the numbers with meanings explained above
     */
    simplify(): any[];
    /**
     * Opens a given cell and may open nearby ones following the minesweeper game rules.
     * @example
     * minefield.openCell(20, false, {nearbyOpening: true, nearbyFlagging: false});
     * @param {Number} cell The index of the cell to open
     * @param {Boolean} firstclick If true, and a bomb is opened, it will be moved in another cell starting from 0 (default: {@link isNew()})
     * @param {Boolean} nearbyOpening Enables the opening of nearby cells if the given cell is already open and its nearby mines number matches the number of nearby flagged cells (default: true)
     * @param {Boolean} nearbyFlagging Enables the flagging of nearby cells if the given cell is already open and its nearby mines number matches the number of nearby closed cells (default: true)
     * @returns {Array.<number>} An array containing the indexes of the updated cells
     * @throws An error if parameters are invalid
     */
    openCell(cell: any, firstclick?: any, { nearbyOpening, nearbyFlagging }?: {
        nearbyOpening?: boolean;
        nearbyFlagging?: boolean;
    }): any[];
    /**
     * Checks if a minefield is solvable from a given cell (by not guessing)
     *
     * WARNING! This method gets resource-intensive the more the minefield is big.
     * @param {Number} cell The index of the cell where to start
     * @param {Boolean} restore If true, the Minefield will be restored after the function ends (default: true)
     * @returns {Boolean} A Boolean value that indicates whether the minefield is solvable from the given cell
     * @throws An error if parameters are invalid
     */
    isSolvableFrom(cell: any, restore?: boolean): boolean;
    /**
     * Checks the minefield to find hints about its state
     * @param {Boolean} accurateHint If false, the function will return the nearby cells around the hint. If true, it will only return the exact cells to open/flag. (default: false)
     * @param {Boolean} getOneHint If true, the function will only return a single hint (the first one found starting from the top) (default: true)
     * @returns {Array.<any>} An array containing arrays of the indexes of hint cells + a char value at index 0 of each (O/F) indicating if the hint is about opening or flagging cells
     * @example minefield.getHint(false, false) //returns [['O', 6, 7, 8], ['F', 15, 25, 35]]
     */
    getHint(accurateHint?: boolean, getOneHint?: boolean): any[];
    /**
     * Calculates nearby mines number for each cell and assigns the value*/
    resetMines(): void;
    /**
     * Executes a given function for every cell (passing them as parameters along with the corresponding index, like a forEach)
     * @param {Function} fun A function to execute for each cell
     * @param {Boolean} returnBreak If true, the loop breaks whenever the given function returns a value that is not undefined and returns that value (default: false)
     * @param {Boolean} giveIndex If false, the method will replace the index of the cell with its corresponding coordinates (default: true)
     * @returns {any} Any value returned from the function if returnBreak is true
     */
    forEachCell(fun: any, returnBreak?: boolean, giveIndex?: boolean): any;
    /**
     * Finds the coordinates of the nearby cell at the given index
     * @param {Number} cell The index of the concerned cell
     * @param {Boolean} includeSelf If true, also include the index of the concerned cell (default: false)
     * @returns {Array.<number>} An Array containing the indexes of the cells directly around the given one
     * @throws An error if parameters are invalid
     */
    getNearbyCells(cell: any, includeSelf?: boolean): any[];
    /**
     * Uses a flood fill algorithm to find all the cells that have 0 mines nearby
     * @param {Number} cell The index of the concerned cell
     * @param {Boolean} includeFlags Whether to include flagged cells in the empty zone (default: false)
     * @returns {Array.<number>} An Array containing the indexes of the empty cells zone starting from the given one
     * @throws An error if parameters are invalid
     */
    getEmptyZone(cell: any, includeFlags?: boolean): any[];
    /**
     * Finds the indexes of all the square zone cells starting and ending at the specified indexes.
     * @param {Number} begIndex The index of the start of the square zone
     * @param {Number} endIndex The index of the end of the square zone
     * @return {Array<number>} An array containing the indexes of all the cells present in the square zone
     * @throws An error if parameters are invalid
     */
    getSquareZone(begIndex: any, endIndex: any): any[];
    /**
     * @param {Number} cell The index of the desired cell
     * @returns {Array<Number>} An array that has the x and y cords of the desired cell at index 0 and 1 respectively
     * @throws An error if parameters are invalid
     */
    getCellCords(cell: any): number[];
    /**
     * @param {Number} x The X coordinate of the desired cell
     * @param {Number} y The Y coordinate of the desired cell
     * @returns {Number} A Number that indicates the index of the cell that is in the specified row and column
     * @throws An error if parameters are invalid
     */
    getCellIndex([x, y]: [any, any]): any;
    /**
     * @returns {Boolean} a Boolean value that indicates whether the game is new (before the first move)
     */
    isNew(): any;
    /**
     * @returns {Boolean} a Boolean value that indicates whether the game is going on (after the first move, before game over)
     */
    isGoingOn(): any;
    /**
     * @returns {Boolean} a Boolean value that indicates whether the game is over (both cleared or lost)
     */
    isOver(): any;
    /**
     * @returns {Boolean} a Boolean value that indicates whether the minefield has been cleared (no mines opened)
     */
    isCleared(): any;
    /**
     * @returns {Boolean} a Boolean value that indicates whether a mine has been opened in the current minefield
     */
    isLost(): any;
    /**
     * Console logs the minefield in a visual way. Legend:
     *
     *  - ?: Unknown cells (neither opened or flagged)
     *  - F: Flagged cells
     *  - [N]: An open cell, with its nearby mines number
     *  - X: An open mine
     *
     * @param {Boolean} allsee If true, every cell will be showed as if they were open (default: false)
     */
    visualDebug(allsee?: boolean): void;
    /**
     * @returns {Number} A Number that indicates the used flags in the current minefield
     */
    get usedFlags(): number;
}
/**
 * An Object containing:
 * @property {Number}  width            - The minefield width (1-based)
 * @property {Number}  height           - The minefield height (1-based)
 * @property {Number}  cells            - The minefield total cells number
 * @property {Number}  mines            - The minefield total mines number
 * @property {Object}  [X][Y]           - Each minefield cell on its coordinates
 * @property {Boolean} [X][Y].isOpen    - Whether a cell is revealed
 * @property {Boolean} [X][Y].isMine    - Whether a cell is a mine
 * @property {Boolean} [X][Y].isFlagged - Whether a cell is flagged
 * @property {Number}  [X][Y].mines     - Number of mines present around a cell
 */
declare class Minefield2D extends Minefield {
    constructor(width: any, height: any, mines?: number, randomizer?: () => number);
    /**
     * Converts the Minefield2D object to a Minefield object.
     *
     * WARNING! The two objects will share the same reference to the same cells so any changes made to one will be reflected in the other
     * @returns {Minefield} A Minefield object
     */
    toMinefield(): Minefield;
    /**
     * Returns a simplified version of the minefield.
     *
     *  - -1: A mine
     *  - [0-8]: A cell with the number of nearby mines
     *
     * @returns {Array.<Array.<number>>} A Number-Only 2D-Array containing the numbers with meanings explained above
     */
    simplify(): any[];
    /**
     * Opens a given cell and may open nearby ones following the minesweeper game rules.
     * @example
     * minefield2D.openCell([5, 8], false, {nearbyOpening: true, nearbyFlagging: false});
     * @param {Number} x The X coordinate of the cell to open
     * @param {Number} y The Y coordinate of the cell to open
     * @param {Boolean} firstclick If true, and a bomb is opened, it will be moved in another cell starting from 0 (default: {@link isNew()})
     * @param {Boolean} nearbyOpening Enables the opening of nearby cells if the given cell is already open and its nearby mines number matches the number of nearby flagged cells (default: true)
     * @param {Boolean} nearbyFlagging Enables the flagging of nearby cells if the given cell is already open and its nearby mines number matches the number of nearby closed cells (default: true)
     * @returns {Array.<Array.<number>>} An array containing arrays with the coordinates of the updated cells
     * @throws An error if parameters are invalid
     */
    openCell([x, y]: [any, any], firstclick?: any, { nearbyOpening, nearbyFlagging }?: {
        nearbyOpening?: boolean;
        nearbyFlagging?: boolean;
    }): any[];
    /**
     * Checks if a minefield is solvable from a given cell (by not guessing)
     *
     * WARNING! This method gets resource-intensive the more the minefield is big.
     * @param {Number} x The X coordinate of the cell where to start
     * @param {Number} y The Y coordinate of the cell where to start
     * @param {Boolean} restore If true, the Minefield will be restored after the function ends (default: true)
     * @returns {Boolean} A Boolean value that indicates whether the minefield is solvable from the given cell
     * @throws An error if parameters are invalid
     */
    isSolvableFrom([x, y]: [any, any], restore?: boolean): boolean;
    /**
     * Checks the minefield to find hints about its state
     * @param {Boolean} accurateHint If false, the function will return the nearby cells around the hint. If true, it will only return the exact cells to open/flag. (default: false)
     * @param {Boolean} getOneHint If true, the function will only return a single hint (the first one found starting from the top) (default: true)
     * @returns {Array.<any>} An array containing arrays with the coordinates of hint cells + a char value at index 0 of each (O/F) indicating if the hint is about opening or flagging cells
     * @example minefield.getHint(true, false) //returns [['O', [2, 3], [2, 4]], ['F', [6, 5], [7, 5]]]
     * minefield.getHint(true, true) //returns ['O', [2, 3], [2, 4]]
     */
    getHint(accurateHint?: boolean, getOneHint?: boolean): any[];
    /**
     * Calculates nearby mines number for each cell and assigns the value*/
    resetMines(): void;
    /**
     * Executes a given function for every cell (passing them as parameters along with the corresponding coordinates, like a forEach)
     * @param {Function} fun A function to execute for each cell
     * @param {Boolean} returnBreak If true, the loop breaks whenever the given function returns a value that is not undefined and returns that value (default: false)
     * @param {Boolean} giveIndex If true, the method will replace the coordinates of the cell with its corresponding index (default: false)
     * @returns {any} Any value returned from the function if returnBreak is true
     */
    forEachCell(fun: any, returnBreak?: boolean, giveIndex?: boolean): any;
    /**
     * Finds the coordinates of the nearby cell at the given index
     * @param {Number} x The X coordinate of the concerned cell
     * @param {Number} y The Y coordinate of the concerned cell
     * @param {Boolean} includeSelf If true, also include the coordinates of the concerned cell (default: false)
     * @returns {Array.<Array.<number>>} An Array containing arrays with the coordinates of of the cells directly around the given one
     * @throws An error if parameters are invalid
     */
    getNearbyCells([x, y]: [any, any], includeSelf?: boolean): any[];
    /**
     * Uses a flood fill algorithm to find all the cells that have 0 mines nearby
     * @param {Number} x The X coordinate of the concerned cell
     * @param {Number} y The Y coordinate of the concerned cell
     * @param {Boolean} includeFlags If true, the flagged cells will be included in the empty zone (default: false)
     * @returns {Array.<Array.<number>>} An Array containing arrays with the coordinates of the empty cells zone starting from the given one
     * @throws An error if parameters are invalid
     */
    getEmptyZone([x, y]: [any, any], includeFlags?: boolean): any[];
    /**
     * Finds the coordinates of all the square zone cells starting and ending at the specified coordinates
     * @param {Number} begX The X coordinate of the start of the square zone
     * @param {Number} begY The Y coordinate of the start of the square zone
     * @param {Number} endX The X coordinate of the end of the square zone
     * @param {Number} endY The Y coordinate of the end of the square zone
     * @return {Array.<Array.<number>>} An array containing the coordinates of all the cells present in the square zone
     * @throws An error if parameters are invalid
     */
    getSquareZone([begX, begY]: [any, any], [endX, endY]: [any, any]): any[];
}
export {};
