export declare type FileOptionType = {
    file: File;
    base64: string | ArrayBuffer | null;
    size: number;
    width: number;
    height: number;
    img?: HTMLImageElement;
};
/**
 * 压缩参数
 */
export declare type CompressOptions = {
    quality: number;
    width?: number;
    height?: number;
    ratio?: number;
};
export declare type ImgType = 'image/jpeg' | 'image/png' | 'image/webp' | string;
export interface ImageProcessType {
    /**
     * 读取文件
     */
    reader: () => Promise<FileOptionType>;
    /**
     * 获取文件options
     * @param file
     */
    getFileOptions: (file?: File) => Promise<FileOptionType>;
    /**
     * 转base64
     */
    toBase64: () => Promise<FileOptionType['base64']>;
    compress: (options?: CompressOptions) => Promise<FileOptionType>;
}
declare class ImageProcess implements ImageProcessType {
    private file;
    private type;
    constructor(file: File);
    /**
     *
     */
    reader(): Promise<FileOptionType>;
    toBase64(): Promise<string | ArrayBuffer | null>;
    /**
     * 压缩
     */
    compress(options?: CompressOptions): Promise<{
        file: File;
        size: number;
        width: number;
        height: number;
        base64: string;
    }>;
    /**
     * 获取文件相关参数
     * @param file
     */
    getFileOptions(file?: File): Promise<FileOptionType>;
    /**
     * base64转文件流
     * @param base64
     * @param type
     */
    private static base64ToBlob;
    /**
     * blob转file
     * @param blob
     */
    private blobToFile;
}
export default ImageProcess;
