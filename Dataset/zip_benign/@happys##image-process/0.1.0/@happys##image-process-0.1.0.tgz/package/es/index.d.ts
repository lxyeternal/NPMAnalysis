import ImageProcess, { FileOptionType, CompressOptions } from './compression';
export { ImageProcess };
export type { FileOptionType, CompressOptions, };
export default ImageProcess;
