/// <reference types="react" />
import { SelectProps } from "./types/index.js";
declare const Select: import("react").ForwardRefExoticComponent<SelectProps & import("react").RefAttributes<HTMLDivElement>>;
export { Select };
