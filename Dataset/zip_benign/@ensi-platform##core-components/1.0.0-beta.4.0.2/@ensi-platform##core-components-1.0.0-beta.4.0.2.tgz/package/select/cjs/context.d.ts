import { BaseThemeState } from "../../common/cjs";
import { FC, ReactNode } from 'react';
import { SelectSize, SelectState, SelectTheme, SelectThemeState, SelectVariant } from "./types/index.js";
declare const useFoo: () => <K extends "optgroup" | "option" | "field" | "optionList" | "arrowButton" | "closeButton" | "optionListWrapper">(key: K, extraData?: ((Record<"optgroup" | "optionList" | "arrowButton" | "closeButton" | "optionListWrapper", import("../../common/cjs").StyleDefinition<SelectThemeState>> & {
    field: import("../../common/cjs").StyleDefinition<BaseThemeState<typeof SelectVariant, typeof SelectSize, never> & SelectState & {
        isFocused: boolean;
    }>;
    option: import("../../common/cjs").StyleDefinition<BaseThemeState<typeof SelectVariant, typeof SelectSize, never> & SelectState & {
        isSelected: boolean;
        isHover: boolean;
        isDisabled: boolean;
        isPreloader: boolean;
    }>;
})[K] extends import("../../common/cjs").ValueOrFunction<import("@emotion/serialize").CSSObject, [state: infer A]> ? Omit<A, "size" | "variant" | keyof SelectState> : never) | undefined) => import("@emotion/serialize").CSSObject;
interface IContext extends Required<BaseThemeState<typeof SelectVariant, typeof SelectSize, SelectTheme>> {
    state: SelectState;
    getCSS: ReturnType<typeof useFoo>;
}
type ContextPropsType = Required<BaseThemeState<typeof SelectVariant, typeof SelectSize, SelectTheme>> & {
    state: SelectState;
};
declare const SelectThemeProvider: FC<{
    children: ReactNode;
} & ContextPropsType>;
declare const useSelectTheme: () => IContext;
export { SelectThemeProvider, useSelectTheme };
