/// <reference types="react" />
import { SelectProps } from "./types/index.js";
declare const SimpleSelect: import("react").ForwardRefExoticComponent<SelectProps & import("react").RefAttributes<HTMLDivElement>>;
export { SimpleSelect };
