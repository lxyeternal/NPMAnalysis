/// <reference types="react" />
import { IPortalProps } from "../../portal/cjs";
import { CSSObject } from '@emotion/react';
import { BasePlacement, VariationPlacement } from '@popperjs/core';
import { MutableRefObject, ReactNode } from 'react';
import { TransitionOptions } from 'react-transition-state';
type RefElement = HTMLElement | null;
type Position = BasePlacement | VariationPlacement;
type PopoverProps = {
    tabFocusableWrapper?: boolean;
    /**
     * Управление состоянием поповера (открыт/закрыт)
     */
    open: boolean;
    /**
     * Элемент, относительного которого появляется поповер
     */
    anchorElement: RefElement;
    /**
     * Использовать ширину родительского элемента
     */
    useAnchorWidth?: boolean;
    /**
     * Позиционирование поповера
     */
    position?: Position;
    /**
     * Запрещает поповеру менять свою позицию.
     * Например, если места снизу недостаточно,то он все равно будет показан снизу
     */
    preventFlip?: boolean;
    /**
     * Запрещает поповеру менять свою позицию, если он не влезает в видимую область.
     */
    preventOverflow?: boolean;
    /**
     *  Позволяет поповеру подствраивать свою высоту под границы экрана, если из-за величины контента он выходит за рамки видимой области экрана
     */
    availableHeight?: boolean;
    /**
     * Если `true`, будет отрисована стрелочка
     */
    withArrow?: boolean;
    /**
     * Смещение поповера.
     * Если позиционирование top, bottom, то [x, y].
     * Если позиционирование left, right то [y, x].
     */
    offset?: [number, number];
    /**
     * Дополнительный стилб для поповера
     */
    popperCSS?: CSSObject;
    /**
     * Дополнительный стиль для стрелочки
     */
    arrowCSS?: CSSObject;
    /**
     * Функция, возвращающая контейнер, в который будет рендериться поповер
     */
    container?: IPortalProps['getPortalContainer'];
    /**
     * TransitionOptions, прокидываются в хук useTransition.
     */
    transitionOptions?: TransitionOptions;
    /**
     * Рендерит компонент, обернутый в Transition
     */
    withTransition?: boolean;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    dataTestId?: string;
    /**
     * Хранит функцию, с помощью которой можно обновить положение компонента
     */
    update?: MutableRefObject<() => void>;
    /**
     * Дополнительный класс
     */
    className?: string;
    /**
     * z-index компонента
     */
    zIndex?: number;
    /**
     * Если поповер не помещается в переданной позиции (position), он попробует открыться в другой позиции,
     * по очереди для каждой позиции из этого списка.
     * Если не передавать, то поповер открывается в противоположном направлении от переданного position.
     */
    fallbackPlacements?: Position[];
    /**
     * Контент
     */
    children?: ReactNode;
};
declare const Popover: import("react").ForwardRefExoticComponent<PopoverProps & import("react").RefAttributes<HTMLDivElement>>;
export { Position, PopoverProps, Popover };
