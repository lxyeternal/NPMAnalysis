import { SVGProps } from 'react';
declare const IconSmallSearch: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallSearch };
