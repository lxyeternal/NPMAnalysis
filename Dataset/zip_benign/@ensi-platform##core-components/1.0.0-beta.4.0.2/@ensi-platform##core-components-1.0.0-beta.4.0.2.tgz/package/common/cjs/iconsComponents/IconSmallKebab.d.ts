import { SVGProps } from 'react';
declare const IconSmallKebab: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallKebab };
