import { SVGProps } from 'react';
declare const Icon20Warning: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { Icon20Warning };
