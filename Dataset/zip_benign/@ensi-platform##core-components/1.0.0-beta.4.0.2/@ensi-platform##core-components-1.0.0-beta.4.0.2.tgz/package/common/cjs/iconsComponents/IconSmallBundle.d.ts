import { SVGProps } from 'react';
declare const IconSmallBundle: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallBundle };
