/// <reference types="node" />
import { ParsedUrlQuery } from 'querystring';
declare const isTouch: () => boolean;
declare const toArray: (arg: any) => never[];
declare const lang: () => string;
declare const isObject: (item: any) => boolean;
declare const repeat: (value: any, count: number) => any[];
declare const debounce: (func: any, wait?: number) => (this: any, ...args: any) => void;
declare const isEmptyArray: (arg: any) => boolean;
declare const prepareForSelect: (val: string[]) => {
    value: string;
    label: string;
}[];
declare const prepareEnumForSelect: (val: Record<string, string>) => {
    value: string;
    label: string;
}[];
declare const prepareForSelectFromObject: (obj: Record<string, string>) => {
    value: number;
    label: string;
}[];
declare const humanize: (str: string) => string;
declare const randomizeInt: (min: number, max: number) => number;
declare const declOfNum: (n: number, titles: string[]) => string;
declare const getCodeFromUrl: (url: string) => string;
declare const wait: (time?: number) => Promise<unknown>;
declare const trimString: (s: string, count: number) => string;
declare const convertPrice: (rub: string | number, penny: string | number) => string | 0;
declare const fromKopecksToRouble: (kopecks: number) => number;
declare const fromRoubleToKopecks: (rub: number) => number;
declare const formatPrice: (unsafeValue: number | string, locale?: string) => string;
declare const formatDate: (date: Date, dateFormat?: string, withTimeZone?: boolean) => string;
type Flatten<T> = T extends any[] ? T[number] : T;
interface INestedRow {
    id: number;
    parent_id?: number | null;
    subRows?: INestedRow[] | [];
    [key: string]: any;
}
declare const getNestedData: (data: INestedRow[]) => INestedRow[];
declare const getFlatRows: (rows: INestedRow[]) => INestedRow[];
declare const getObjectWithoutEmptyFields: (obj: any) => any;
declare const getTextValueByBoolean: (value: boolean) => "Да" | "Нет";
declare const getQueryKeysFromBrackets: (value: string) => string[] | undefined;
/**
 * router next возвращает pathname в виде /path/[param], и query в виде {param: '123'}
 * поэтому getQueryObjectForPathname возвращает те query, которые соответствуют pathname
 */
declare const getQueryObjectForPathname: (pathname: string, query: ParsedUrlQuery) => ParsedUrlQuery;
declare const prepareTelValue: (tel: string) => string;
declare const cleanPhoneValue: (tel: string) => string;
declare const getDate: (date: string | null | undefined, type?: 'start' | 'end') => string;
declare const getPeriod: (start: string | null | undefined, end: string | null | undefined) => string;
declare const toISOStringWithZone: (date: Date | string | undefined) => string | undefined;
declare const isNotEmptyObject: (obj: any) => boolean;
declare const protectFieldName: (name: string) => string;
declare const formatISOTimeFromDate: (date: Date | string) => string;
declare const getValueFromObject: (keys: string, obj: Record<string, any>, emptyObject?: null | number) => Record<string, any>;
export { isTouch, toArray, lang, isObject, repeat, debounce, isEmptyArray, prepareForSelect, prepareEnumForSelect, prepareForSelectFromObject, humanize, randomizeInt, declOfNum, getCodeFromUrl, wait, trimString, convertPrice, fromKopecksToRouble, fromRoubleToKopecks, formatPrice, formatDate, Flatten, INestedRow, getNestedData, getFlatRows, getObjectWithoutEmptyFields, getTextValueByBoolean, getQueryKeysFromBrackets, getQueryObjectForPathname, prepareTelValue, cleanPhoneValue, getDate, getPeriod, toISOStringWithZone, isNotEmptyObject, protectFieldName, formatISOTimeFromDate, getValueFromObject };
