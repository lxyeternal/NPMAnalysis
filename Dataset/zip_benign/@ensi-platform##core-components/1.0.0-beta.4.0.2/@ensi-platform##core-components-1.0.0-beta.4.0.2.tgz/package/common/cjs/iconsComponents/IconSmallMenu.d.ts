import { SVGProps } from 'react';
declare const IconSmallMenu: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallMenu };
