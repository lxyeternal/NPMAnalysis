import { SVGProps } from 'react';
declare const IconPhoneOutgoing: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconPhoneOutgoing };
