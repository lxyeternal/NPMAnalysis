import { SVGProps } from 'react';
declare const IconSmallDragAndDrop: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallDragAndDrop };
