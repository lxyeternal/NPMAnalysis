import { SVGProps } from 'react';
declare const IconSmallTrello: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallTrello };
