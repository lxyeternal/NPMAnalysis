import { SVGProps } from 'react';
declare const IconBigTwxtArea: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconBigTwxtArea };
