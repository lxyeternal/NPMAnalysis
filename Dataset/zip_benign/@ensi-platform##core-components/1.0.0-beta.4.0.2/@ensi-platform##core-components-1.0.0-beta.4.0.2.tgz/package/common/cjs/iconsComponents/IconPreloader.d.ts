import { SVGProps } from 'react';
declare const IconPreloader: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconPreloader };
