import { SVGProps } from 'react';
declare const IconSmallHistory: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallHistory };
