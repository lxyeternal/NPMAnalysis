import { SVGProps } from 'react';
declare const IconArrowLeft: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconArrowLeft };
