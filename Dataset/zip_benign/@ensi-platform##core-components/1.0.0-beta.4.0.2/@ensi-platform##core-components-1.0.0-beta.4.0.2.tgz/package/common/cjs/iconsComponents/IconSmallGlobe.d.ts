import { SVGProps } from 'react';
declare const IconSmallGlobe: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallGlobe };
