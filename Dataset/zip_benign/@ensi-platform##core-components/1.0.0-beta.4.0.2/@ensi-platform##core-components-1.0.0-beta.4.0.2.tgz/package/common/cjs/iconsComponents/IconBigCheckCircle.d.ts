import { SVGProps } from 'react';
declare const IconBigCheckCircle: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconBigCheckCircle };
