import { SVGProps } from 'react';
declare const IconSmallFileAttach: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallFileAttach };
