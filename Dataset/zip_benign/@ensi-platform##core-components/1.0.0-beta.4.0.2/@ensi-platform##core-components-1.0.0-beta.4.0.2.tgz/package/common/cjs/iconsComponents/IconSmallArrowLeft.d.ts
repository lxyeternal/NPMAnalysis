import { SVGProps } from 'react';
declare const IconSmallArrowLeft: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallArrowLeft };
