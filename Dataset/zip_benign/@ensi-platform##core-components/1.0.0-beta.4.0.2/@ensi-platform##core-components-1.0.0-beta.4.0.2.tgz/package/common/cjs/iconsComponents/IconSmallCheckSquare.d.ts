import { SVGProps } from 'react';
declare const IconSmallCheckSquare: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallCheckSquare };
