import { SVGProps } from 'react';
declare const IconSmallNoVideo: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallNoVideo };
