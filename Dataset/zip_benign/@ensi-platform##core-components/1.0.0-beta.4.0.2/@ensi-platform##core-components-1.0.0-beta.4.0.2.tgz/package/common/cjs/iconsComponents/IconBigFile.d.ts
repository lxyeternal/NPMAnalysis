import { SVGProps } from 'react';
declare const IconBigFile: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconBigFile };
