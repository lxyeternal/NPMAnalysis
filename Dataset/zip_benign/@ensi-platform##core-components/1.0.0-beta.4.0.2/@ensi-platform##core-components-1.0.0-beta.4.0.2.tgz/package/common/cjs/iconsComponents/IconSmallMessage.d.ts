import { SVGProps } from 'react';
declare const IconSmallMessage: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallMessage };
