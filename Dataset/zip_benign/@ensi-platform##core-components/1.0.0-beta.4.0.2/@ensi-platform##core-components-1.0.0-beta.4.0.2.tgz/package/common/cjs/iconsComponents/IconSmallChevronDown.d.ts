import { SVGProps } from 'react';
declare const IconSmallChevronDown: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallChevronDown };
