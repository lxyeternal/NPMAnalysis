import { SVGProps } from 'react';
declare const IconSmallShildik: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallShildik };
