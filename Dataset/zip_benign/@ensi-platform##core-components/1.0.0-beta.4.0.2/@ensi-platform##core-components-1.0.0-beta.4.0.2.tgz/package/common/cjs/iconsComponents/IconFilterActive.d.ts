import { SVGProps } from 'react';
declare const IconFilterActive: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconFilterActive };
