import { SVGProps } from 'react';
declare const IconSmallChevronUp: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallChevronUp };
