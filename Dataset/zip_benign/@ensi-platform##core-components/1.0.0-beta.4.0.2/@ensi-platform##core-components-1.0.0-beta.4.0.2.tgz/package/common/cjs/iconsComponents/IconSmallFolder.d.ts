import { SVGProps } from 'react';
declare const IconSmallFolder: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallFolder };
