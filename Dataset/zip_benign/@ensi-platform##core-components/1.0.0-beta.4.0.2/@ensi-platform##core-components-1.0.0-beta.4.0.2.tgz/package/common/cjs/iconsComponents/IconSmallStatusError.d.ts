import { SVGProps } from 'react';
declare const IconSmallStatusError: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallStatusError };
