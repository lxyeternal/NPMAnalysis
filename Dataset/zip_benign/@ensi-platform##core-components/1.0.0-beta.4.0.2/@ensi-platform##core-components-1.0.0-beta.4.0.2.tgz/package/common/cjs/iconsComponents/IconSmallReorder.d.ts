import { SVGProps } from 'react';
declare const IconSmallReorder: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallReorder };
