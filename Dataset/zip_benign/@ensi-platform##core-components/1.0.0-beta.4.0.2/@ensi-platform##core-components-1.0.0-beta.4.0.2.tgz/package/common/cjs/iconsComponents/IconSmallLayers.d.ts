import { SVGProps } from 'react';
declare const IconSmallLayers: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallLayers };
