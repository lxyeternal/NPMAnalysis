import { SVGProps } from 'react';
declare const IconSmallWarehouse: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallWarehouse };
