import { SVGProps } from 'react';
declare const IconSmallBirka: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallBirka };
