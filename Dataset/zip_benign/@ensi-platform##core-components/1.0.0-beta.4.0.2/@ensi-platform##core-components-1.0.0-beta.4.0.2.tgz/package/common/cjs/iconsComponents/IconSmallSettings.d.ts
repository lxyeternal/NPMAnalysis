import { SVGProps } from 'react';
declare const IconSmallSettings: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallSettings };
