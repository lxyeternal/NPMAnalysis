import { SVGProps } from 'react';
declare const IconBigCalculator: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconBigCalculator };
