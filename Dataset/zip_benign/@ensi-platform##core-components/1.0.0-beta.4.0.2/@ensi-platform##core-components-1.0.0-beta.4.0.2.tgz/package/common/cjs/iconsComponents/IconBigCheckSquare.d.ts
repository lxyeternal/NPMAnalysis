import { SVGProps } from 'react';
declare const IconBigCheckSquare: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconBigCheckSquare };
