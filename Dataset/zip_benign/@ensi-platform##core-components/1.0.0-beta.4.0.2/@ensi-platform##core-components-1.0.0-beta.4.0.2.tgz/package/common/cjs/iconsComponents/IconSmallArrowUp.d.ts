import { SVGProps } from 'react';
declare const IconSmallArrowUp: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallArrowUp };
