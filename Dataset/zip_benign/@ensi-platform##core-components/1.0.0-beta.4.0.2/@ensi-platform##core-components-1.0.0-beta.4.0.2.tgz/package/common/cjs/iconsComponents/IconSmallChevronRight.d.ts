import { SVGProps } from 'react';
declare const IconSmallChevronRight: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallChevronRight };
