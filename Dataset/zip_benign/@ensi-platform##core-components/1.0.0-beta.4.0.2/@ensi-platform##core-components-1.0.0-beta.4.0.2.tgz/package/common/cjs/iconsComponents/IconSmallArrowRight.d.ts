import { SVGProps } from 'react';
declare const IconSmallArrowRight: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallArrowRight };
