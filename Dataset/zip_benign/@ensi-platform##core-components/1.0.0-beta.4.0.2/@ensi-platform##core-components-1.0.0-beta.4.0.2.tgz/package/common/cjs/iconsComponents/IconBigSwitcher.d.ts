import { SVGProps } from 'react';
declare const IconBigSwitcher: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconBigSwitcher };
