import { SVGProps } from 'react';
declare const IconSmallCheck: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallCheck };
