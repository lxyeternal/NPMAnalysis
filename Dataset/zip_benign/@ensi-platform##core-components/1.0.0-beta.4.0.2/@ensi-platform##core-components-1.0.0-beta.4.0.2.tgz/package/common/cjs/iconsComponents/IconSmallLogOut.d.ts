import { SVGProps } from 'react';
declare const IconSmallLogOut: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallLogOut };
