import { SVGProps } from 'react';
declare const IconArrowRight: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconArrowRight };
