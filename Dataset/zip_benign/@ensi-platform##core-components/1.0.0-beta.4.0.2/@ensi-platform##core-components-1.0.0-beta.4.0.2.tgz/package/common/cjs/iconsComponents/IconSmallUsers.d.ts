import { SVGProps } from 'react';
declare const IconSmallUsers: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallUsers };
