import { SVGProps } from 'react';
declare const IconTableImgPreview: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconTableImgPreview };
