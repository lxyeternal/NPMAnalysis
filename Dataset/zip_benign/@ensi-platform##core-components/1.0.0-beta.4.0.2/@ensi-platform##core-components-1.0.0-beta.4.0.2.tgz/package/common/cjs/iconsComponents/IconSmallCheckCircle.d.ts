import { SVGProps } from 'react';
declare const IconSmallCheckCircle: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallCheckCircle };
