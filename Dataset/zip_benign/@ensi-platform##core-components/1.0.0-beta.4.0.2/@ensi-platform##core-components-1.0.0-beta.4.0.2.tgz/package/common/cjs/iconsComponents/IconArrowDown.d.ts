import { SVGProps } from 'react';
declare const IconArrowDown: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconArrowDown };
