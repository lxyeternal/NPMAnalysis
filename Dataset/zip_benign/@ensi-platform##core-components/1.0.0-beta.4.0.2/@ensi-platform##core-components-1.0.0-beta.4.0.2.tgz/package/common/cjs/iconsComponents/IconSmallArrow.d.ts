import { SVGProps } from 'react';
declare const IconSmallArrow: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallArrow };
