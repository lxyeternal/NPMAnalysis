import { SVGProps } from 'react';
declare const IconSmallSliders: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallSliders };
