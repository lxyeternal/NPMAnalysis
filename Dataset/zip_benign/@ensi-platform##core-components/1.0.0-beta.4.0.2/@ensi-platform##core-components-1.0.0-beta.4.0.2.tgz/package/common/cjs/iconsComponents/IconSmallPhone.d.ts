import { SVGProps } from 'react';
declare const IconSmallPhone: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallPhone };
