import { SVGProps } from 'react';
declare const Icon20CheckCircle: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { Icon20CheckCircle };
