import { SVGProps } from 'react';
declare const IconSmallPackage: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallPackage };
