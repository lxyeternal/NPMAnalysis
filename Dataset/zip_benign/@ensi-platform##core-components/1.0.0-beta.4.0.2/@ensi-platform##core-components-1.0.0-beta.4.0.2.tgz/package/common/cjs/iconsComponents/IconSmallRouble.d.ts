import { SVGProps } from 'react';
declare const IconSmallRouble: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallRouble };
