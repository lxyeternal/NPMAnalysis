import { SVGProps } from 'react';
declare const IconSmallEdit: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallEdit };
