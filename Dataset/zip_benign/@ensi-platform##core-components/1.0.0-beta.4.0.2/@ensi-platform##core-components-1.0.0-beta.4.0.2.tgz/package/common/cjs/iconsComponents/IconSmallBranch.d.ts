import { SVGProps } from 'react';
declare const IconSmallBranch: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallBranch };
