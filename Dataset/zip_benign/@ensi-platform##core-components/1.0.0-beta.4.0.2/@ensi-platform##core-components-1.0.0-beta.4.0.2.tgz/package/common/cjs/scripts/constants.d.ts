import { CSSObject } from '@emotion/react';
declare const MAX_AGE_NEVER: number;
declare const MAX_STRING_SIZE = 40;
declare const DAYS: string[];
declare const HttpCode: {
    OK: number;
    CREATED: number;
    BAD_REQUEST: number;
    UNAUTHORIZED: number;
    FORBIDDEN: number;
    NOT_FOUND: number;
    INTERNAL_SERVER_ERROR: number;
};
declare const KOPECKS_IN_ROUBLE = 100;
declare const ErrorMessages: {
    REQUIRED: string;
    PHONE: string;
    EMAIL: string;
    PASSWORD: string;
    SITE: string;
    INTEGER: string;
    GREATER_OR_EQUAL: string;
    LESS_OR_EQUAL: string;
    WRONG_FORMAT: string;
    ARRAY: string;
    MIN_SYMBOLS: (num: number) => string;
    MIN_ITEMS: (num: number) => string;
    MIN_FILES: (num: number) => string;
    MAX_FILES: (num: number) => string;
};
declare const ModalMessages: {
    SUCCESS_CREATE: string;
    SUCCESS_SAVE: string;
    SUCCESS_UPDATE: string;
    SUCCESS_DELETE: string;
    ERROR_UPDATE: string;
    LOADING: string;
};
declare const FileTypes: {
    IMAGES: string[];
    PDF: string[];
};
declare const DEFAULT_TIMEZONE = "Europe/Moscow";
declare const DateFormatters: {
    DEFAULT: string;
    DATE_ISO: string;
    DATE_AND_TIME: string;
    DATE_AND_TIME_FULL_MONTH: string;
    DATE_FULL_MONTH: string;
    TIME: string;
};
declare const FileSizes: {
    KB256: number;
    MB1: number;
    MB2: number;
    MB10: number;
};
declare const emptyCSS: CSSObject;
export { MAX_AGE_NEVER, MAX_STRING_SIZE, DAYS, HttpCode, KOPECKS_IN_ROUBLE, ErrorMessages, ModalMessages, FileTypes, DEFAULT_TIMEZONE, DateFormatters, FileSizes, emptyCSS };
