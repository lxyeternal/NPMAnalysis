import { SVGProps } from 'react';
declare const IconSmallMinus: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallMinus };
