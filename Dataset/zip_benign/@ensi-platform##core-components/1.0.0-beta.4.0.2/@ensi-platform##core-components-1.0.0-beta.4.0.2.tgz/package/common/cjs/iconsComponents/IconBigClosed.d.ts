import { SVGProps } from 'react';
declare const IconBigClosed: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconBigClosed };
