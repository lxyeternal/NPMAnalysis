declare namespace colors {
    let grey900: string;
    let black: string;
    let grey800: string;
    let grey700: string;
    let grey600: string;
    let grey500: string;
    let grey400: string;
    let grey300: string;
    let grey100: string;
    let white: string;
    let grey200: string;
    let fade: string;
    let primary: string;
    let primaryHover: string;
    let secondary: string;
    let secondaryHover: string;
    let dark: string;
    let danger: string;
    let dangerBg: string;
    let dangerDivider: string;
    let warning: string;
    let warningBg: string;
    let warningDivider: string;
    let success: string;
    let successBg: string;
    let successDivider: string;
    let lightBlue: string;
    let link: string;
    let linkHover: string;
    let infoBg: string;
    let infoDivider: string;
}
declare namespace typography {
    let breakpoints: number[];
    namespace styles {
        namespace button {
            namespace desktop {
                let fontFamily: string;
                let fontWeight: number;
                let fontSize: string;
                let lineHeight: number;
            }
        }
        namespace buttonBold {
            export namespace desktop_1 {
                let fontFamily_1: string;
                export { fontFamily_1 as fontFamily };
                let fontWeight_1: number;
                export { fontWeight_1 as fontWeight };
                let fontSize_1: string;
                export { fontSize_1 as fontSize };
                let lineHeight_1: number;
                export { lineHeight_1 as lineHeight };
            }
            export { desktop_1 as desktop };
        }
        namespace caption {
            export namespace desktop_2 {
                let fontFamily_2: string;
                export { fontFamily_2 as fontFamily };
                let fontWeight_2: number;
                export { fontWeight_2 as fontWeight };
                let fontSize_2: string;
                export { fontSize_2 as fontSize };
                let lineHeight_2: number;
                export { lineHeight_2 as lineHeight };
                export let letterSpacing: string;
                export let textTransform: string;
            }
            export { desktop_2 as desktop };
        }
        namespace captionBold {
            export namespace desktop_3 {
                let fontFamily_3: string;
                export { fontFamily_3 as fontFamily };
                let fontWeight_3: number;
                export { fontWeight_3 as fontWeight };
                let fontSize_3: string;
                export { fontSize_3 as fontSize };
                let lineHeight_3: number;
                export { lineHeight_3 as lineHeight };
                let letterSpacing_1: string;
                export { letterSpacing_1 as letterSpacing };
                let textTransform_1: string;
                export { textTransform_1 as textTransform };
            }
            export { desktop_3 as desktop };
        }
        namespace captionBoldLower {
            export namespace desktop_4 {
                let fontFamily_4: string;
                export { fontFamily_4 as fontFamily };
                let fontWeight_4: number;
                export { fontWeight_4 as fontWeight };
                let fontSize_4: string;
                export { fontSize_4 as fontSize };
                let lineHeight_4: number;
                export { lineHeight_4 as lineHeight };
            }
            export { desktop_4 as desktop };
        }
        namespace small {
            export namespace desktop_5 {
                let fontFamily_5: string;
                export { fontFamily_5 as fontFamily };
                let fontWeight_5: number;
                export { fontWeight_5 as fontWeight };
                let fontSize_5: string;
                export { fontSize_5 as fontSize };
                let lineHeight_5: number;
                export { lineHeight_5 as lineHeight };
            }
            export { desktop_5 as desktop };
        }
        namespace smallBold {
            export namespace desktop_6 {
                let fontFamily_6: string;
                export { fontFamily_6 as fontFamily };
                let fontWeight_6: number;
                export { fontWeight_6 as fontWeight };
                let fontSize_6: string;
                export { fontSize_6 as fontSize };
                let lineHeight_6: number;
                export { lineHeight_6 as lineHeight };
            }
            export { desktop_6 as desktop };
        }
        namespace bodySm {
            export namespace desktop_7 {
                let fontFamily_7: string;
                export { fontFamily_7 as fontFamily };
                let fontWeight_7: number;
                export { fontWeight_7 as fontWeight };
                let fontSize_7: string;
                export { fontSize_7 as fontSize };
                let lineHeight_7: number;
                export { lineHeight_7 as lineHeight };
            }
            export { desktop_7 as desktop };
        }
        namespace bodySmBold {
            export namespace desktop_8 {
                let fontFamily_8: string;
                export { fontFamily_8 as fontFamily };
                let fontWeight_8: number;
                export { fontWeight_8 as fontWeight };
                let fontSize_8: string;
                export { fontSize_8 as fontSize };
                let lineHeight_8: number;
                export { lineHeight_8 as lineHeight };
            }
            export { desktop_8 as desktop };
        }
        namespace bodyMdBold {
            export namespace desktop_9 {
                let fontFamily_9: string;
                export { fontFamily_9 as fontFamily };
                let fontWeight_9: number;
                export { fontWeight_9 as fontWeight };
                let fontSize_9: string;
                export { fontSize_9 as fontSize };
                let lineHeight_9: number;
                export { lineHeight_9 as lineHeight };
                export let fontVariantNumeric: string;
            }
            export { desktop_9 as desktop };
        }
        namespace bodyMd {
            export namespace desktop_10 {
                let fontFamily_10: string;
                export { fontFamily_10 as fontFamily };
                let fontWeight_10: number;
                export { fontWeight_10 as fontWeight };
                let fontSize_10: string;
                export { fontSize_10 as fontSize };
                let lineHeight_10: number;
                export { lineHeight_10 as lineHeight };
            }
            export { desktop_10 as desktop };
        }
        namespace subheading {
            export namespace desktop_11 {
                let fontFamily_11: string;
                export { fontFamily_11 as fontFamily };
                let fontWeight_11: number;
                export { fontWeight_11 as fontWeight };
                let fontSize_11: string;
                export { fontSize_11 as fontSize };
                let lineHeight_11: number;
                export { lineHeight_11 as lineHeight };
            }
            export { desktop_11 as desktop };
        }
        namespace h3 {
            export namespace desktop_12 {
                let fontFamily_12: string;
                export { fontFamily_12 as fontFamily };
                let fontWeight_12: number;
                export { fontWeight_12 as fontWeight };
                let fontSize_12: string;
                export { fontSize_12 as fontSize };
                let lineHeight_12: number;
                export { lineHeight_12 as lineHeight };
            }
            export { desktop_12 as desktop };
        }
        namespace h2 {
            export namespace desktop_13 {
                let fontFamily_13: string;
                export { fontFamily_13 as fontFamily };
                let fontWeight_13: number;
                export { fontWeight_13 as fontWeight };
                let fontSize_13: string;
                export { fontSize_13 as fontSize };
                let lineHeight_13: number;
                export { lineHeight_13 as lineHeight };
            }
            export { desktop_13 as desktop };
        }
        namespace h1 {
            export namespace desktop_14 {
                let fontFamily_14: string;
                export { fontFamily_14 as fontFamily };
                let fontWeight_14: number;
                export { fontWeight_14 as fontWeight };
                let fontSize_14: string;
                export { fontSize_14 as fontSize };
                let lineHeight_14: number;
                export { lineHeight_14 as lineHeight };
            }
            export { desktop_14 as desktop };
        }
    }
}
declare namespace shadows {
    let small_1: string;
    export { small_1 as small };
    export let big: string;
    export let box: string;
    export let bigInversion: string;
    export let inner: string;
}
declare namespace layout {
    export namespace cols {
        let xxxl: number;
        let md: number;
        let xs: number;
        let xxs: number;
    }
    export namespace container {
        let xxxl_1: number;
        export { xxxl_1 as xxxl };
        export let xxl: string;
    }
    export namespace marginLeft {
        let xxxl_2: string;
        export { xxxl_2 as xxxl };
        let xxl_1: number;
        export { xxl_1 as xxl };
    }
    export namespace marginRight {
        let xxxl_3: string;
        export { xxxl_3 as xxxl };
        let xxl_2: number;
        export { xxl_2 as xxl };
    }
    export namespace breakpoints_1 {
        let xxxl_4: number;
        export { xxxl_4 as xxxl };
        let xxl_3: number;
        export { xxl_3 as xxl };
        export let xl: number;
        export let lg: number;
        let md_1: number;
        export { md_1 as md };
        export let sm: number;
        let xs_1: number;
        export { xs_1 as xs };
        let xxs_1: number;
        export { xxs_1 as xxs };
        export let xxxs: number;
    }
    export { breakpoints_1 as breakpoints };
    export namespace gap {
        let xxxl_5: number;
        export { xxxl_5 as xxxl };
        let xl_1: number;
        export { xl_1 as xl };
        let lg_1: number;
        export { lg_1 as lg };
        let sm_1: number;
        export { sm_1 as sm };
    }
    export namespace padding {
        let xxl_4: number;
        export { xxl_4 as xxl };
        let xl_2: number;
        export { xl_2 as xl };
        let lg_2: number;
        export { lg_2 as lg };
        let md_2: number;
        export { md_2 as md };
        let xs_2: number;
        export { xs_2 as xs };
        let xxxs_1: number;
        export { xxxs_1 as xxxs };
    }
}
export { colors, typography, shadows, layout };
