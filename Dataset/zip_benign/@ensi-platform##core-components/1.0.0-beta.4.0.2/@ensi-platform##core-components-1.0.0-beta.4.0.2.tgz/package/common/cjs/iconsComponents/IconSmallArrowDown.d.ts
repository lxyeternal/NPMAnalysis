import { SVGProps } from 'react';
declare const IconSmallArrowDown: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallArrowDown };
