/** Телефонный номер (+7(000) 000-00-00) */
declare const maskPhone = "+7(000) 000-00-00";
/** Одиночная дата (00.00.0000) */
declare const maskDateSingle = "00.00.0000";
/** Диапазон дат (00.00.0000 — 00.00.0000) */
declare const maskDateRange = "00.00.0000 \u2014 00.00.0000";
declare const getMaskTime: (prefix?: string) => string;
export { maskPhone, maskDateSingle, maskDateRange, getMaskTime };
