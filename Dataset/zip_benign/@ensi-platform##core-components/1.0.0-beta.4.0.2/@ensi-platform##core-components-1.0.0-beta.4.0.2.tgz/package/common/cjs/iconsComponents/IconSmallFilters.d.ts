import { SVGProps } from 'react';
declare const IconSmallFilters: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallFilters };
