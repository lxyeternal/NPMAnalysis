import { SVGProps } from 'react';
declare const IconSmallChevronLeft: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallChevronLeft };
