import { SVGProps } from 'react';
declare const IconSmallBarcode: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallBarcode };
