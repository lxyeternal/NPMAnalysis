import { SVGProps } from 'react';
declare const IconCalendar: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconCalendar };
