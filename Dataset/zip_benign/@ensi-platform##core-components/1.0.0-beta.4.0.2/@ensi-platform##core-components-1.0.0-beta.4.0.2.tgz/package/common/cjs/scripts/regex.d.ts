/** Names (Latin and Cyrillic letters, dashes and spaces) */
declare const regName: RegExp;
/** Russian names (cyrillic letters, dashes) */
declare const regNameRu: RegExp;
/** English names (latin letters, dashes and spaces) */
declare const regNameEn: RegExp;
/** Checking for the content of at least 1 Latin letter */
declare const regOneLetter: RegExp;
/** Checking for the content of at least 1 digit */
declare const regOneDigit: RegExp;
/** Phone number (+7(000) 000-00-00) */
declare const regPhone: RegExp;
/** Email */
declare const regEmail: RegExp;
/** Accept only cyrillic letters and digits */
declare const onlyRussianLettersDigits: RegExp;
/** Accept only latin letters and digits */
declare const onlyEnglishLettersDigits: RegExp;
export { regName, regNameRu, regNameEn, regOneLetter, regOneDigit, regPhone, regEmail, onlyRussianLettersDigits, onlyEnglishLettersDigits };
