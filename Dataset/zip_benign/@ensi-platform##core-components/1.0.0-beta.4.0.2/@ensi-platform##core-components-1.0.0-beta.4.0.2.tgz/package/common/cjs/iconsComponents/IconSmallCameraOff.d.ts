import { SVGProps } from 'react';
declare const IconSmallCameraOff: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallCameraOff };
