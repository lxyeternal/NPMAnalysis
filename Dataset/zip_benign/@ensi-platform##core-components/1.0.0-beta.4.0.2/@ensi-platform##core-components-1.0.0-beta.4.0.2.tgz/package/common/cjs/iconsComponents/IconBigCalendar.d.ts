import { SVGProps } from 'react';
declare const IconBigCalendar: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconBigCalendar };
