import { SVGProps } from 'react';
declare const IconSmallFolders: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallFolders };
