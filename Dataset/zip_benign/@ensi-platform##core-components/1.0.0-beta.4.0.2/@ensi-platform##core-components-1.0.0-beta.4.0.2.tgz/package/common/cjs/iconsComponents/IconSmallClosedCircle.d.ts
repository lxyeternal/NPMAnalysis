import { SVGProps } from 'react';
declare const IconSmallClosedCircle: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallClosedCircle };
