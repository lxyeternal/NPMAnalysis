import { SVGProps } from 'react';
declare const IconBigRouble: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconBigRouble };
