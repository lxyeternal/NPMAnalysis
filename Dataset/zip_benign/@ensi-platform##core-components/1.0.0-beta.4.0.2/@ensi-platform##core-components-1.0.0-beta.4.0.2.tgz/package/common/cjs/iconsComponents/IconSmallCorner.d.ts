import { SVGProps } from 'react';
declare const IconSmallCorner: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallCorner };
