import { SVGProps } from 'react';
declare const IconSmallEyeOff: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallEyeOff };
