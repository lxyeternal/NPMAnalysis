import { SVGProps } from 'react';
declare const IconSmallWatch: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallWatch };
