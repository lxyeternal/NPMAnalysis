import { SVGProps } from 'react';
declare const IconSpinner: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSpinner };
