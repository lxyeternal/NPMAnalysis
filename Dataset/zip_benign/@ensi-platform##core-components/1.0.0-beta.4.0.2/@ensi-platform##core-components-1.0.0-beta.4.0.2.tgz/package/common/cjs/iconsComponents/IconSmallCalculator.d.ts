import { SVGProps } from 'react';
declare const IconSmallCalculator: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallCalculator };
