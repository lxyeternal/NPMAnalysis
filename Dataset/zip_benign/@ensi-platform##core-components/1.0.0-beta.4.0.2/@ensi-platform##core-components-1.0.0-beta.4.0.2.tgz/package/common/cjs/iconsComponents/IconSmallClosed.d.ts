import { SVGProps } from 'react';
declare const IconSmallClosed: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallClosed };
