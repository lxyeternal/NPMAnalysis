import { SVGProps } from 'react';
declare const IconSmallWarningCircle: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallWarningCircle };
