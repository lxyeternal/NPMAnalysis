import { SVGProps } from 'react';
declare const IconPhoneIncoming: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconPhoneIncoming };
