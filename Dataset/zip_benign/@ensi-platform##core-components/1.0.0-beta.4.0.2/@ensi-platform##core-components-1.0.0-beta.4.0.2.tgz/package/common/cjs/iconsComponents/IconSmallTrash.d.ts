import { SVGProps } from 'react';
declare const IconSmallTrash: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallTrash };
