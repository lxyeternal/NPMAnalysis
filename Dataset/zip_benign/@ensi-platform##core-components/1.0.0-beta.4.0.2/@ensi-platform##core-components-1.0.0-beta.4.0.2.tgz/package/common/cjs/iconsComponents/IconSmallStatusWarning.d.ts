import { SVGProps } from 'react';
declare const IconSmallStatusWarning: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallStatusWarning };
