import { SVGProps } from 'react';
declare const IconBigImage: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconBigImage };
