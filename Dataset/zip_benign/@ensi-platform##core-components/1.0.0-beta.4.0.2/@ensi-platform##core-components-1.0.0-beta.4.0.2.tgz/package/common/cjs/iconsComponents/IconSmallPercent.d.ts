import { SVGProps } from 'react';
declare const IconSmallPercent: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallPercent };
