import { SVGProps } from 'react';
declare const IconSmallNavigation: ({ title, ...props }: SVGProps<SVGSVGElement> & {
    title?: string;
}) => import("@emotion/react/jsx-runtime").JSX.Element;
export { IconSmallNavigation };
