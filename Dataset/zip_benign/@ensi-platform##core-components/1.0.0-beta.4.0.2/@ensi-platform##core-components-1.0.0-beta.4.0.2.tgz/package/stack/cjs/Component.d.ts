import { FC } from 'react';
import { IStackProps } from "./types/index.js";
declare const Stack: FC<IStackProps>;
export { Stack as default };
