import { CSSObject } from '@emotion/react';
import { HTMLProps, ReactEventHandler, ReactNode } from 'react';
interface PictureSource {
    media: string;
    image: string;
}
type SafeNumber = number | `${number}`;
type ImgElementWithDataProp = HTMLImageElement & {
    'data-loaded-src': string | undefined;
};
type PlaceholderValue = 'blur' | 'empty' | 'fade';
type OnLoad = ReactEventHandler<HTMLImageElement> | undefined;
type OnLoadingComplete = (img: HTMLImageElement) => void;
declare const VALID_LOADING_VALUES: readonly ["lazy", "eager", undefined];
type LoadingValue = (typeof VALID_LOADING_VALUES)[number];
type PlaceholderProps = {
    placeholder: 'blur';
    blurDataURL: string;
    fadeCSS?: never;
    fadeCompleteCSS?: never;
} | {
    placeholder?: 'empty';
    blurDataURL?: never;
    fadeCSS?: never;
    fadeCompleteCSS?: never;
} | {
    placeholder?: 'fade';
    blurDataURL?: never;
    fadeCSS?: CSSObject;
    fadeCompleteCSS?: CSSObject;
};
type PictureProps = Omit<HTMLProps<HTMLPictureElement>, 'src' | 'srcSet' | 'ref' | 'alt' | 'width' | 'height' | 'loading' | 'style' | 'crossOrigin' | 'preload'> & {
    crossOrigin?: '' | 'anonymous' | 'use-credentials';
    sources: PictureSource[];
    className?: string;
    css?: never;
    /**
     * Вставить ли в <head> тег <link rel="preload"
     * для Next среды использовать Head из next/head
     */
    PreloadComponent?: (props: {
        children: ReactNode;
    }) => ReactNode;
    loading?: LoadingValue;
    alt: string;
    width: SafeNumber;
    height: SafeNumber;
    style?: CSSObject;
    onLoadingComplete?: OnLoadingComplete;
} & PlaceholderProps;
export { PictureSource, ImgElementWithDataProp, PlaceholderValue, OnLoad, OnLoadingComplete, PlaceholderProps, PictureProps };
