import { PictureProps } from "./types.js";
declare const Picture: ({ sources, placeholder, fadeCompleteCSS, fadeCSS, blurDataURL, PreloadComponent, style: imgStyle, width, height, onLoad, onError, onLoadingComplete, alt, ...restProps }: PictureProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export { Picture };
