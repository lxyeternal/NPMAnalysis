import { IFieldWrapperProps } from "./index-5fd63277.js";
import { FC } from 'react';
import { DropzoneProps as UseDropzoneProps } from 'react-dropzone';
import { DropzoneFileProps, FileType } from "./components/DropzoneFile.js";
type DropzoneProps = UseDropzoneProps & Partial<IFieldWrapperProps<FileType[]>> & {
    label?: string;
    /** On files change callback */
    onFilesChange?: (files: FileType[]) => void;
    /** On file remove callback. You may need it for remove already uploaded file from Database */
    onFileRemove?: DropzoneFileProps['onRemoveClick'];
    /** On file click callback. You may need it for downloading file */
    onFileClick?: DropzoneFileProps['onFileClick'];
    /** Enable file click callback. */
    enableFileClick?: DropzoneFileProps['enableFileClick'];
    /** Disable dragging */
    isDragDisabled?: boolean;
    /** Disable delete button */
    isDisableRemove?: boolean;
    /** Button-like view */
    simple?: boolean;
    maxFileNameLength?: number;
    isLoading?: boolean;
    onBlur?: () => void;
};
declare const Dropzone: FC<DropzoneProps>;
export { Dropzone };
