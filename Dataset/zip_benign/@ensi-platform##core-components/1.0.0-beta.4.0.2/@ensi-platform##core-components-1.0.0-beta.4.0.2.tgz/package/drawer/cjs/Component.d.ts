/// <reference types="react" />
import { IDrawerProps } from "./types/index.js";
declare const Drawer: import("react").ForwardRefExoticComponent<IDrawerProps & import("react").RefAttributes<HTMLDivElement>>;
export { Drawer as default };
