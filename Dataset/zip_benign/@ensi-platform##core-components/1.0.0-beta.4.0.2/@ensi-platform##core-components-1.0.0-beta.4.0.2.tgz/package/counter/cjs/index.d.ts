import { CounterProps } from "./types.js";
declare const Counter: ({ value, label, step, min, max, onChange, view, hint, field, setFieldValue, error, size, variant, theme, rounded, ...props }: CounterProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export { Counter };
