import { BaseThemeState, StyleDefinition, ValueOrFunction } from "../../common/cjs";
import { IFieldWrapperProps } from "./index-5fd63277.js";
import { HTMLProps } from 'react';
type View = 'vertical' | 'horizontal';
interface CounterState {
    hasLabel: boolean;
    view: View;
    max: number;
    rounded: boolean;
}
declare const CounterVariant: {
    readonly primary: "primary";
};
declare const CounterSize: {
    readonly md: "md";
    readonly lg: "lg";
};
type CounterThemeState = BaseThemeState<typeof CounterVariant, typeof CounterSize> & CounterState;
type CounterTheme = ValueOrFunction<{
    decrButton: StyleDefinition<CounterThemeState>;
    incrButton: StyleDefinition<CounterThemeState>;
    icon: StyleDefinition<CounterThemeState>;
    input: StyleDefinition<CounterThemeState>;
    layout: StyleDefinition<CounterThemeState>;
}, [
    CounterThemeState
]>;
type CounterProps = Partial<Omit<CounterState, 'hasLabel' | 'view'>> & Partial<Omit<BaseThemeState<typeof CounterVariant, typeof CounterSize, CounterTheme>, 'theme'>> & Omit<HTMLProps<HTMLInputElement>, 'onChange' | 'size'> & Partial<IFieldWrapperProps<number>> & {
    /** Parsed value */
    value?: number;
    /** Вид отображения */
    view?: View;
    /** Minimum value */
    min?: number;
    /** Maximum value */
    max?: number;
    /** Step value */
    step?: number;
    /** Handler change event on input */
    onChange?: (value: number) => void;
    /** Hint text */
    hint?: string;
    theme?: CounterTheme;
};
export { View, CounterState, CounterVariant, CounterSize, CounterThemeState, CounterTheme, CounterProps };
