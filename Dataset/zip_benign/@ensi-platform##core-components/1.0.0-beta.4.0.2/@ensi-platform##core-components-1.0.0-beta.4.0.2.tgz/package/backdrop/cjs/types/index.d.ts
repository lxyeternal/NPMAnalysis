export * from "./component.js";
