import { FC } from 'react';
import { IBackdropProps } from "./types/index.js";
declare const Backdrop: FC<IBackdropProps>;
export * from "./types/index.js";
export { Backdrop as default };
