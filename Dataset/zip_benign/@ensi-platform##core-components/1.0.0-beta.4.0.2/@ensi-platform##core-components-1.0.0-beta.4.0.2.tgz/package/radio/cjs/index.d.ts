/// <reference types="react" />
import { RadioProps } from "./types.js";
declare const Radio: ({ name, value, label, error, inputRef: innerRef, children, className, theme: themeName, size, variant, checked: propsChecked, allowUnselectDisabledOptions, disabled, inputCSS: propsInputCSS, labelCSS: propsLabelCSS, wrapperCSS, view, onChange, useControlHook, ...props }: RadioProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export * from "./types.js";
export { Radio };
