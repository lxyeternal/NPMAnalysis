import { BaseThemeState, StyleDefinition, ValueOrFunction, useCheckboxLikeControlHookType } from "../../common/esm";
import { CSSObject } from '@emotion/react';
import { HTMLProps, Ref } from 'react';
import { radioThemes } from "./themes/index.js";
/**
 * Размеры радио-кнопки
 */
declare enum RadioSize {
    sm = "sm",
    md = "md"
}
/**
 * Варианты радио-кнопки
 */
declare enum RadioVariant {
    primary = "primary"
}
/**
 * Состояния радиокнопки
 */
interface RadioState {
    /**
     * Выбранное состояние
     */
    checked?: boolean;
    /**
     * Заблокированное состояние
     */
    disabled?: boolean;
    /**
     * Cостояние только для чтения
     */
    readOnly?: boolean;
    /**
     * С ошибкой
     */
    hasError?: boolean;
    /**
     * Только чтение, либо анселект
     */
    disabledCanUnselect?: boolean;
    /**
     * Стиль отображения, либо пустой, либо с колечком
     */
    view: 'padded-knob' | 'plain';
}
/**
 * Состояния радио-кнопки
 */
type RadioThemeState = BaseThemeState<typeof RadioVariant, typeof RadioSize, never> & RadioState;
declare enum RadioParts {
    label = 0,
    icon = 1,
    input = 2,
    error = 3
}
/**
 * Темы радио-кнопки
 */
type RadioTheme = ValueOrFunction<Record<keyof typeof RadioParts, StyleDefinition<RadioThemeState>>, [
    RadioThemeState
]>;
/**
 * Пропсы радио-кнопки
 */
interface RadioProps extends Omit<BaseThemeState<typeof RadioVariant, typeof RadioSize, RadioTheme>, 'theme'>, Omit<HTMLProps<HTMLInputElement>, 'size'> {
    /** Ref for inner input */
    inputRef?: Ref<HTMLInputElement>;
    /** Additional class */
    className?: string;
    /** Error message */
    error?: string;
    /** Show error flag */
    showError?: boolean;
    theme?: RadioTheme | keyof typeof radioThemes;
    allowUnselectDisabledOptions?: boolean;
    view?: 'padded-knob' | 'plain';
    inputCSS?: CSSObject;
    wrapperCSS?: CSSObject;
    labelCSS?: CSSObject;
    useControlHook?: useCheckboxLikeControlHookType;
}
export { RadioSize, RadioVariant, RadioState, RadioThemeState, RadioTheme, RadioProps };
