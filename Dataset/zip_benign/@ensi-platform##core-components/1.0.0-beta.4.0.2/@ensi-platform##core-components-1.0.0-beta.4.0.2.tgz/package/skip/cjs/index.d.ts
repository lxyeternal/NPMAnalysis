import { SkipProps } from "./types.js";
declare const Skip: ({ link, children, ...props }: SkipProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export * from "./types.js";
export { Skip };
