import { HTMLProps } from 'react';
interface SkipProps extends HTMLProps<HTMLAnchorElement> {
    /** Anchor link ('#example') */
    link: string;
    /** Link text */
    children: string;
}
export { SkipProps };
