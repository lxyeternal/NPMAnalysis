import { IPopupProps } from "../../../popup/esm";
import { KeyboardEvent, MouseEvent } from 'react';
import { ActionEnum, ThemesEnum } from "../scripts/enums.js";
interface IActionPopupProps extends Omit<IPopupProps, 'title' | 'onBackdropClick'> {
    action?: ActionEnum;
    title?: string;
    leftAddonIconTheme?: `${ThemesEnum}`;
    onAction?: () => void;
    disableAction?: boolean;
    disableClose?: boolean;
    disableFooter?: boolean;
    blockButtons?: boolean;
    onBackdropClick?: (event: MouseEvent<HTMLElement> | KeyboardEvent<HTMLElement>, reason?: 'backdropClick' | 'escapeKeyDown' | 'closerClick') => void;
}
export { IActionPopupProps };
