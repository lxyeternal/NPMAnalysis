declare enum ActionEnum {
    DELETE = "delete",
    COPY = "copy",
    UNTIE = "untie",
    CONFIRM = "confirm"
}
declare enum ThemesEnum {
    INFO = "info",
    ERROR = "error",
    WARNING = "warning",
    SUCCESS = "success",
    DELETE = "delete"
}
export { ActionEnum, ThemesEnum };
