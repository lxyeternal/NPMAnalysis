/// <reference types="react" />
import { IActionPopupProps } from "./types/index.js";
declare const ActionPopup: ({ action, title, leftAddonIconTheme, children, onClose, onAction, onBackdropClick, disableAction, disableClose, blockButtons, disableFooter, ...props }: IActionPopupProps) => import("@emotion/react/jsx-runtime").JSX.Element;
declare const ActionPopupContent: import("react").ForwardRefExoticComponent<import("../../popup/cjs").IPopupContentProps & import("react").RefAttributes<HTMLDivElement>>;
export * from "./scripts/enums.js";
export * from "./scripts/hooks/useActionPopup.js";
export * from "./types/index.js";
export { ActionPopup, ActionPopupContent };
