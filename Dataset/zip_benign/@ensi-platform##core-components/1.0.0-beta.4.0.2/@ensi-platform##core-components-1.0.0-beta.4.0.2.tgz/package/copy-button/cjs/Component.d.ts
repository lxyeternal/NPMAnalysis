import { FC } from 'react';
import { ICopyButtonProps } from "./types/index.js";
/**
 * A button for copying text content
 */
declare const CopyButton: FC<ICopyButtonProps>;
export { CopyButton as default };
