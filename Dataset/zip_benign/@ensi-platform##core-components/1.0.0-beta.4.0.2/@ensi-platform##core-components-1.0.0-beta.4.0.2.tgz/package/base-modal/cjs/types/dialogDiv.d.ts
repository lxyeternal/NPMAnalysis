import { HTMLProps } from 'react';
interface IDialogDivProps extends HTMLProps<HTMLDivElement> {
    dataTestId?: string;
}
export { IDialogDivProps };
