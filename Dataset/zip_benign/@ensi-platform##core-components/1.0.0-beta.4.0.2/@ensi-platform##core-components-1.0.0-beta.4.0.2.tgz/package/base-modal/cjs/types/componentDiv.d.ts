import { HTMLProps } from 'react';
interface IComponentDivProps extends HTMLProps<HTMLDivElement> {
}
export { IComponentDivProps };
