/// <reference types="react" />
import { IBaseModalProps } from "./types/index.js";
declare const BaseModal: import("react").ForwardRefExoticComponent<IBaseModalProps & import("react").RefAttributes<HTMLDivElement>>;
export { BaseModal as default };
