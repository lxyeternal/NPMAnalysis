import { GlobalStore } from "./GlobalStore.js";
import { ModalStore, SavedStyle } from "./ModalStore.js";
declare global {
    interface Window {
        globalStore: GlobalStore;
    }
}
declare const getModalStore: () => ModalStore;
export type { SavedStyle };
export { getModalStore };
