declare enum ClosureReasonsEmum {
    backdropClick = "backdropClick",
    escapeKeyDown = "escapeKeyDown",
    closerClick = "closerClick"
}
declare enum TransitionStatusesEnum {
    preEnter = "preEnter",
    entering = "entering",
    entered = "entered",
    preExit = "preExit",
    exiting = "exiting",
    exited = "exited",
    unmounted = "unmounted"
}
export { ClosureReasonsEmum, TransitionStatusesEnum };
