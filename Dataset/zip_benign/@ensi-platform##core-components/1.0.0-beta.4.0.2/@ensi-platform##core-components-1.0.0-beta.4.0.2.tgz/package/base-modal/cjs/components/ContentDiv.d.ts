/// <reference types="react" />
import { IContentDivProps } from "../types/index.js";
declare const ContentDiv: import("react").ForwardRefExoticComponent<Omit<IContentDivProps, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
export { ContentDiv as default };
