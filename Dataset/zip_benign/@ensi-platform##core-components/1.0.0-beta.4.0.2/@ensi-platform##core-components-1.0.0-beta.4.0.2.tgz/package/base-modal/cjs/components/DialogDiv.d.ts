/// <reference types="react" />
import { IDialogDivProps } from "../types/index.js";
declare const DialogDiv: import("react").ForwardRefExoticComponent<Omit<IDialogDivProps, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
export { DialogDiv as default };
