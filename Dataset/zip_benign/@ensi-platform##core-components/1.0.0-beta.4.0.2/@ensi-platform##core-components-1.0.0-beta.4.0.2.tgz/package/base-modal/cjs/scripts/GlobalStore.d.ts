import { ModalStore } from "./ModalStore.js";
declare class GlobalStore {
    private readonly modalStore;
    constructor();
    getModalStore: () => ModalStore;
}
export { GlobalStore };
