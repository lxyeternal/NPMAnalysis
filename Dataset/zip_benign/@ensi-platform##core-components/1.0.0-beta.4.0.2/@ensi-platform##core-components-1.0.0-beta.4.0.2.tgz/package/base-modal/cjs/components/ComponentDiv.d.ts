/// <reference types="react" />
import { IComponentDivProps } from "../types/index.js";
declare const ComponentDiv: import("react").ForwardRefExoticComponent<Omit<IComponentDivProps, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
export { ComponentDiv as default };
