/// <reference types="react" />
import { IBaseModalContext } from "../types/index.js";
declare const BaseModalContext: import("react").Context<IBaseModalContext>;
export { BaseModalContext };
