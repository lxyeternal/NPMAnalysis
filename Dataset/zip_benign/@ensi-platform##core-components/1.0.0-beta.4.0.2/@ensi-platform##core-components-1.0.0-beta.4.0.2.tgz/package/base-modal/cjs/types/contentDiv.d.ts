import { HTMLProps } from 'react';
import { IBaseModalProps } from "./component.js";
interface IContentDivProps extends HTMLProps<HTMLDivElement>, Pick<IBaseModalProps, 'contentCSS'> {
}
export { IContentDivProps };
