import BaseModal from "./Component.js";
export { BaseModal };
export * from "./context/index.js";
export * from "./scripts/index.js";
export * from "./types/index.js";
