/// <reference types="react" />
import { ReactNode, ChangeEvent, MouseEvent } from "react";
import { ControllerFieldState, ControllerRenderProps, NativeFieldValue } from "react-hook-form";
import { CSSObject } from '@emotion/react';
type ExtendedValue<T> = T | T[] | Record<string, T> | Record<string, T>[];
type IFieldValueType = Exclude<ExtendedValue<NativeFieldValue>, undefined>;
interface IControllerRenderProps<T extends IFieldValueType> extends Omit<ControllerRenderProps, "value"> {
    value: T;
}
/**
 * Interface props passed by the field wrapper component
 */
interface IFieldWrapperProps<T extends IFieldValueType> {
    /**
     * Returned property of useController
     * Contains a meta
     * https://react-hook-form.com/docs/usecontroller
     * */
    fieldState: ControllerFieldState;
    /**
     * Returned property of useController
     * Contains a value and a value change handler
     * https://react-hook-form.com/docs/usecontroller
     * */
    field: IControllerRenderProps<T>;
    /**
     * Handler for changing field value
     * @param value - field value, not event
     */
    setFieldValue: (value: T) => void;
    /**
     * Field error
     */
    error?: string;
}
declare const BASE_INPUT_CSS: CSSObject;
declare const Input: import("react").ForwardRefExoticComponent<Omit<import("react").InputHTMLAttributes<HTMLInputElement>, "size" | "value" | "type" | "onChange" | "onClick" | "onMouseDown" | "defaultValue" | "enterKeyHint"> & {
    value?: string | undefined;
    defaultValue?: string | undefined;
    error?: string | undefined;
    block?: boolean | undefined;
    clear?: boolean | undefined;
    theme?: import("../../form-control/cjs").FormControlTheme | "basic" | undefined;
    variant?: "primary" | typeof import("../../form-control/cjs").FormControlVariant | undefined;
    size?: "md" | "sm" | "lg" | typeof import("../../form-control/cjs").FormControlSize | undefined;
    labelWrap?: boolean | undefined;
    showError?: boolean | undefined;
    hint?: import("react").ReactNode;
    label?: import("react").ReactNode;
    type?: "number" | "color" | "link" | "time" | "text" | "url" | "tel" | "email" | "password" | "card" | "money" | undefined;
    wrapperRef?: import("react").Ref<HTMLDivElement> | undefined;
    leftAddons?: import("react").ReactNode;
    rightAddons?: import("react").ReactNode;
    innerLeftAddons?: import("react").ReactNode;
    bottomAddons?: import("react").ReactNode;
    className?: string | undefined;
    fieldCSS?: CSSObject | undefined;
    wrapperCSS?: CSSObject | undefined;
    inputCSS?: CSSObject | undefined;
    labelCSS?: CSSObject | undefined;
    leftAddonsCSS?: CSSObject | undefined;
    rightAddonsCSS?: CSSObject | undefined;
    disableUserInput?: boolean | undefined;
    onChange?: ((event: ChangeEvent<HTMLInputElement>, payload: {
        value: string;
    }) => void) | undefined;
    onClear?: ((event: MouseEvent<HTMLButtonElement, globalThis.MouseEvent>) => void) | undefined;
    onClick?: ((event: MouseEvent<HTMLDivElement, globalThis.MouseEvent>) => void) | undefined;
    onMouseDown?: ((event: MouseEvent<HTMLDivElement, globalThis.MouseEvent>) => void) | undefined;
    onMouseUp?: ((event: MouseEvent<HTMLDivElement, globalThis.MouseEvent>) => void) | undefined;
    isLegend?: boolean | undefined;
} & Partial<IFieldWrapperProps<string>> & import("react").RefAttributes<HTMLInputElement>>;
export * from "./types.js";
export { BASE_INPUT_CSS, Input };
