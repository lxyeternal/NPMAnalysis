import { IDescriptionListProps } from "./types/index.js";
/**
 * List of term-definition pairs with leader dots between them
 */
declare const DescriptionList: {
    ({ children, className }: IDescriptionListProps): import("@emotion/react/jsx-runtime").JSX.Element;
    Item: ({ name, valueNoWrap, className, ...props }: import("./types/index.js").DescriptionListItemType) => import("@emotion/react/jsx-runtime").JSX.Element;
};
export { DescriptionList };
