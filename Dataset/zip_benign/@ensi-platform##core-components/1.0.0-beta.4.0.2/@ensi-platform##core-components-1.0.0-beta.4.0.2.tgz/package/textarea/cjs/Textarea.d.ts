import { CSSObject } from '@emotion/react';
import { ITextareaProps } from "./types/index.js";
declare const BASE_CSS: CSSObject;
declare const Textarea: ({ name, value, field, minRows, maxRows, maxLength, threshold, isResize, label, bottomAddons, disabled, labelWrap, error, hint, className, textAreaCSS, labelCSS, leftAddonsCSS, rightAddonsCSS, leftAddons, rightAddons, wrapperRef, readOnly, showError, fieldCSS, wrapperCSS, block, onHeightChange, cacheMeasurements, ...props }: ITextareaProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export { Textarea as default, Textarea, BASE_CSS };
