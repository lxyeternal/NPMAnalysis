import { FieldValues } from 'react-hook-form';
import { IFormProps } from "./index-1dce143c.js";
/**
 * Form - is a wrapper for RHF's form initialization logic
 */
declare const Form: <T extends FieldValues>({ initialValues, validationSchema, children: childrenProp, mode, className, isForm, enableReinitialize, disabled, onSubmit, onReset, onChange, ...props }: IFormProps<T>) => import("@emotion/react/jsx-runtime").JSX.Element;
export { Form as default, Form };
