import { Dispatch } from 'react';
import { ActionType } from "./index-0e9b44cf.js";
type Action<T> = {
    type: ActionType;
    payload?: T;
};
declare const usePopupState: <T>(initialState: T) => [T, Dispatch<Action<T>>];
export { Action, usePopupState };
