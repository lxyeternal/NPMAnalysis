import { CSSObject } from '@emotion/react';
type LinkColorType = 'blue' | 'black' | 'grey' | 'red';
declare const useLinkCSS: (type?: LinkColorType) => CSSObject;
export { LinkColorType, useLinkCSS };
