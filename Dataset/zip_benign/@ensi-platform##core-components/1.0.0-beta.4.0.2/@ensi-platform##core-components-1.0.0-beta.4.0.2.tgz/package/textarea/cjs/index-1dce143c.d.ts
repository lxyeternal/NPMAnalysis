import { HTMLProps, ReactNode } from "react";
import { DefaultValues, FieldValues, UseFormProps, UseFormReturn, ControllerFieldState, ControllerRenderProps, NativeFieldValue } from "react-hook-form";
import { AnyObjectSchema } from "yup";
/**
 * Form component interface
 */
interface IFormProps<T extends FieldValues> extends Omit<UseFormProps<T>, "children">, Omit<HTMLProps<HTMLFormElement>, "onSubmit" | "ref" | "onReset" | "children" | "onChange"> {
    /**
     * Initial values
     */
    initialValues: DefaultValues<T>;
    /**
     * Yup validation schema
     */
    validationSchema?: AnyObjectSchema;
    /**
     * Form content
     */
    children?: ReactNode | ((props: UseFormReturn<T, unknown>) => ReactNode);
    /**
     * Enable reinitialize on initialValues change
     * @default false
     */
    enableReinitialize?: boolean;
    /**
     * Whether to render form tag
     * @default true
     */
    isForm?: boolean;
    /**
     * Disabled flag
     * @default false
     */
    disabled?: boolean;
    /**
     * Form submit handler
     */
    onSubmit: (values: T, formProps: UseFormReturn<T, unknown>) => void | Promise<void>;
    /**
     * Form reset handler
     */
    onReset?: (values: T, formProps: UseFormReturn<T, unknown>) => void | Promise<void>;
    /**
     * Form change handler
     */
    onChange?: (values: T, formProps: UseFormReturn<T, unknown>, exactChange: {
        [name: string]: unknown;
    }) => void | Promise<unknown>;
}
type ExtendedValue<T> = T | T[] | Record<string, T> | Record<string, T>[];
type IFieldValueType = Exclude<ExtendedValue<NativeFieldValue>, undefined>;
interface IControllerRenderProps<T extends IFieldValueType> extends Omit<ControllerRenderProps, "value"> {
    value: T;
}
/**
 * Interface props passed by the field wrapper component
 */
interface IFieldWrapperProps<T extends IFieldValueType> {
    /**
     * Returned property of useController
     * Contains a meta
     * https://react-hook-form.com/docs/usecontroller
     * */
    fieldState: ControllerFieldState;
    /**
     * Returned property of useController
     * Contains a value and a value change handler
     * https://react-hook-form.com/docs/usecontroller
     * */
    field: IControllerRenderProps<T>;
    /**
     * Handler for changing field value
     * @param value - field value, not event
     */
    setFieldValue: (value: T) => void;
    /**
     * Field error
     */
    error?: string;
}
export { IFormProps, IFieldValueType, IControllerRenderProps, IFieldWrapperProps };
