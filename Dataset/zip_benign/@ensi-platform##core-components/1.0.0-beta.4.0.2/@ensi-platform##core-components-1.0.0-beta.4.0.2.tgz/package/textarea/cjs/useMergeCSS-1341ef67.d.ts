import { CSSObject } from '@emotion/react';
declare const useMergeCSS: (...CSSToMerge: CSSObject[]) => CSSObject;
export { useMergeCSS };
