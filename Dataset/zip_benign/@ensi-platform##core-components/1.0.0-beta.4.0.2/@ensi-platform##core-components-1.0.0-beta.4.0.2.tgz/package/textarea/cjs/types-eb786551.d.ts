import { ButtonProps } from "./index-772da75d.js";
import { DeepPartial } from 'react-hook-form';
interface IFormResetProps<T> extends Omit<ButtonProps, 'as'> {
    /**
     * Initial values to reset form
     */
    initialValues?: DeepPartial<T>;
}
export { IFormResetProps };
