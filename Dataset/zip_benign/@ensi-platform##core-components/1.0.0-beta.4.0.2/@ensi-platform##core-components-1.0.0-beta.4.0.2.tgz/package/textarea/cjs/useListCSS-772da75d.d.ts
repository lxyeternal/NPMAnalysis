import { CSSObject } from '@emotion/react';
declare const useListCSS: () => {
    dlBaseStyles: CSSObject;
    dtBaseStyles: CSSObject;
    ddBaseStyles: CSSObject;
};
export { useListCSS };
