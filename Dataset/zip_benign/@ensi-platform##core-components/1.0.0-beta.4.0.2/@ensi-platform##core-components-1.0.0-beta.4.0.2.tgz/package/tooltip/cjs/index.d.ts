import { FC } from 'react';
import { TooltipProps } from "./types.js";
declare const Tooltip: FC<TooltipProps>;
export * from "./types.js";
export { Tooltip };
