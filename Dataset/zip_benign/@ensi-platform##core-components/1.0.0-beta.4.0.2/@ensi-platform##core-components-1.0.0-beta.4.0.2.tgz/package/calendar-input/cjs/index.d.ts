/// <reference types="react" />
import { BaseCalendarInputProps } from "./types.js";
declare const CalendarInput: import("react").ForwardRefExoticComponent<BaseCalendarInputProps & import("react").RefAttributes<HTMLInputElement>>;
export { CalendarInput };
