import { MaskitoPreprocessor } from '@maskito/core';
import { DateTemplate } from "../types.js";
declare function createDisallowInputPreprocessor(): MaskitoPreprocessor;
declare function createValidationPreprocessor(template: DateTemplate, fullStringTemplate: string, min: Date, max: Date, onCorrection: () => void): MaskitoPreprocessor;
export { createDisallowInputPreprocessor, createValidationPreprocessor };
