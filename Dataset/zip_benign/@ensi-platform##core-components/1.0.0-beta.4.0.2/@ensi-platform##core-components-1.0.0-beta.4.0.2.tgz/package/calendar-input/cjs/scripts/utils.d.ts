import { SyntheticEvent } from 'react';
declare function parseDateString(value: string, format?: string): Date;
declare const formatDate: (date: Date | number, dateFormat?: string) => string;
declare function isCompleteDate(value?: string): boolean;
declare function isCompleteTime(value?: string, withTime?: boolean): boolean;
declare function isCompleteDateRange(value?: string): boolean;
declare function isValidDate({ value, minDate, maxDate, offDays, }: {
    value?: string;
    minDate: number;
    maxDate: number;
    offDays?: Array<Date | number>;
}): boolean;
declare function preventDefault(e: SyntheticEvent): void;
declare function getValidRange({ from, to, offDays, minDate, maxDate, }: {
    from: string;
    to: string;
    offDays?: Array<Date | number>;
    minDate: number;
    maxDate: number;
}): {
    validFrom: Date | undefined;
    validTo: Date | undefined;
};
/**
 * Частично копипаста updatePeriod хука в календаре
 */
declare function updateRange({ date, validFrom, validTo, rangeBehavior, }: {
    date?: number;
    validFrom?: Date;
    validTo?: Date;
    rangeBehavior: 'clarification' | 'reset';
}): string;
export { parseDateString, formatDate, isCompleteDate, isCompleteTime, isCompleteDateRange, isValidDate, preventDefault, getValidRange, updateRange };
