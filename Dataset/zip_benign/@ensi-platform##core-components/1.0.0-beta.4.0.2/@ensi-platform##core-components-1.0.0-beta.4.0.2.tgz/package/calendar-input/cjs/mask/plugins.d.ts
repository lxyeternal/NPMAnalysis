import { MaskitoPlugin } from '@maskito/core';
import { DateTemplate } from "../types.js";
declare function createCaretPosPlugin(template: DateTemplate): MaskitoPlugin;
export { createCaretPosPlugin };
