import { MaskitoPostprocessor } from '@maskito/core';
declare function createPreventCaretJumpPostprocessor(): MaskitoPostprocessor;
export { createPreventCaretJumpPostprocessor };
