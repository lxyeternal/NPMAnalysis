import { MaskitoOptions } from '@maskito/core';
import { View } from "../types.js";
declare function createMaskOptions(view: View, min: Date, max: Date, autoCorrection: boolean, onCorrection: () => void): MaskitoOptions;
export { createMaskOptions };
