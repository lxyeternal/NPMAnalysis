/// <reference types="react" />
import { BaseThemeState, StyleDefinition, ValueOrFunction } from "../../common/esm";
import { CSSObject } from "@emotion/react";
import { HTMLAttributes, ReactNode, FC, HTMLProps, SVGProps, ChangeEvent, InputHTMLAttributes, MouseEvent, Ref } from "react";
import { ControllerFieldState, ControllerRenderProps, NativeFieldValue } from "react-hook-form";
declare enum FormControlSize {
    sm = "sm",
    md = "md",
    lg = "lg"
}
declare enum FormControlVariant {
    primary = "primary"
}
interface FormControlState {
    /**
     * Растягивает компонент на ширину контейнера
     */
    block?: boolean;
    /**
     * Заблокированное состояние
     */
    disabled?: boolean;
    /**
     * Cостояние только для чтения
     */
    readOnly?: boolean;
    /**
     * Заполненное состояние
     */
    filled?: boolean;
    /**
     * Выбранное (фокус) состояние
     */
    focused?: boolean;
    /**
     * С ошибкой
     */
    hasError?: boolean;
    /**
     * Разрешить лейблу переноситься по строчкам
     */
    labelWrap?: boolean;
    /**
     * Есть ли левый слот
     */
    hasLeftAddons?: boolean;
    /**
     * Есть ли правый слот
     */
    hasRightAddons?: boolean;
    /**
     * Есть ли внутренний лейбл
     */
    hasInnerLabel?: boolean;
    /**
     * Положение ошибки относительно элемента
     * @default 'above'
     */
    errorPlacement?: "under" | "above";
}
type FormControlThemeState = BaseThemeState<typeof FormControlVariant, typeof FormControlSize, never> & FormControlState;
declare enum FormControlParts {
    wrapper = 0,
    inner = 1,
    label = 2,
    sub = 3,
    controlWrapper = 4,
    error = 5,
    clear = 6
}
type FormControlTheme = ValueOrFunction<Record<keyof typeof FormControlParts, StyleDefinition<FormControlThemeState>> & {
    addons: StyleDefinition<FormControlThemeState & {
        isLeft: boolean;
    }>;
}, [
    FormControlThemeState
]>;
type FormControlProps = Partial<Omit<BaseThemeState<typeof FormControlVariant, typeof FormControlSize, FormControlTheme>, "theme">> & Partial<Omit<FormControlState, "hasInnerLabel" | "hasError" | "hasRightAddons" | "hasLeftAddons">> & HTMLAttributes<HTMLDivElement> & {
    /**
     * Пропы для лейблов (обычно id и htmlFor)
     */
    labelProps?: HTMLAttributes<HTMLLabelElement>;
    /**
     * ID элемента к которому обращен label
     */
    htmlFor?: string;
    /**
     * Отображение ошибки
     */
    error?: string;
    /**
     * Флаг отображения ошибки
     */
    showError?: boolean;
    /**
     * Текст подсказки
     */
    hint?: ReactNode;
    /**
     * Лейбл компонента
     */
    label?: ReactNode;
    /**
     * Слот слева
     */
    leftAddons?: ReactNode;
    /**
     * Слот справа
     */
    rightAddons?: ReactNode;
    /**
     * Слот под полем
     */
    bottomAddons?: ReactNode;
    /**
     * Дополнительный класс
     */
    className?: string;
    /**
     * Дополнительный стиль для лейбла
     */
    labelCSS?: CSSObject;
    /**
     * Дополнительный стиль для поля
     */
    fieldCSS?: CSSObject;
    /**
     * Дополнительный стиль для обертки
     */
    wrapperCSS?: CSSObject;
    /**
     * Дополнительный стиль для левых аддонов
     */
    leftAddonsCSS?: CSSObject;
    /**
     * Дополнительный стиль для правых аддонов
     */
    rightAddonsCSS?: CSSObject;
    /**
     * Компонент поля (инпут, textarea и пр.)
     */
    children?: ReactNode;
    theme?: FormControlTheme | keyof typeof formControlThemes;
};
declare const formControlThemes: {
    basic: FormControlTheme;
};
declare const FormControl: import("react").ForwardRefExoticComponent<Partial<Omit<import("../../common/esm").BaseThemeState<typeof FormControlVariant, typeof FormControlSize, FormControlTheme>, "theme">> & Partial<Omit<FormControlState, "hasInnerLabel" | "hasError" | "hasRightAddons" | "hasLeftAddons">> & import("react").HTMLAttributes<HTMLDivElement> & {
    labelProps?: import("react").HTMLAttributes<HTMLLabelElement> | undefined;
    htmlFor?: string | undefined;
    error?: string | undefined;
    showError?: boolean | undefined;
    hint?: import("react").ReactNode;
    label?: import("react").ReactNode;
    leftAddons?: import("react").ReactNode;
    rightAddons?: import("react").ReactNode;
    bottomAddons?: import("react").ReactNode;
    className?: string | undefined;
    labelCSS?: CSSObject | undefined;
    fieldCSS?: CSSObject | undefined;
    wrapperCSS?: CSSObject | undefined;
    leftAddonsCSS?: CSSObject | undefined;
    rightAddonsCSS?: CSSObject | undefined;
    children?: import("react").ReactNode;
    theme?: FormControlTheme | "basic" | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
interface FormMessageProps extends HTMLProps<HTMLDivElement> {
    /**
     * Error text
     */
    message: string;
    /**
     * Alert type
     */
    type?: "error" | "warning";
    /**
     * Message element id for linking with aria-attributes
     */
    id?: string;
    className?: string;
}
interface IMessageIconProps extends SVGProps<SVGSVGElement> {
    type: FormMessageProps["type"];
}
declare const FormMessage: FC<FormMessageProps>;
type InputProps = Omit<InputHTMLAttributes<HTMLInputElement>, "size" | "type" | "value" | "defaultValue" | "onChange" | "onClick" | "onMouseDown" | "enterKeyHint"> & {
    /**
     * Значение поля ввода
     */
    value?: string;
    /**
     * Начальное значение поля
     */
    defaultValue?: string;
    error?: string;
    /**
     * Растягивает компонент на ширину контейнера
     */
    block?: boolean;
    /**
     * Крестик для очистки поля
     */
    clear?: boolean;
    theme?: FormControlProps["theme"] | keyof FormControlProps["theme"];
    variant?: FormControlProps["variant"];
    size?: FormControlProps["size"];
    labelWrap?: FormControlProps["labelWrap"];
    /**
     * Флаг отображения ошибки
     */
    showError?: boolean;
    /**
     * Текст подсказки
     */
    hint?: ReactNode;
    /**
     * Лейбл компонента
     */
    label?: ReactNode;
    /**
     * Атрибут type
     */
    type?: "number" | "card" | "email" | "money" | "password" | "tel" | "text" | "time" | "color" | "url" | "link";
    /**
     * Ref для обертки input
     */
    wrapperRef?: Ref<HTMLDivElement>;
    /**
     * Слот слева
     */
    leftAddons?: ReactNode;
    /**
     * Слот справа
     */
    rightAddons?: ReactNode;
    /**
     * Внутренний слот слева
     */
    innerLeftAddons?: ReactNode;
    /**
     * Слот под инпутом
     */
    bottomAddons?: ReactNode;
    /**
     * Дополнительный класс
     */
    className?: string;
    /**
     * Дополнительный стиль для поля
     */
    fieldCSS?: CSSObject;
    /**
     * Дополнительный стиль для обертки
     */
    wrapperCSS?: CSSObject;
    /**
     * Дополнительный стиль инпута
     */
    inputCSS?: CSSObject;
    /**
     * Дополнительный стиль для лейбла
     */
    labelCSS?: CSSObject;
    /**
     * Дополнительный стиль для аддонов
     */
    leftAddonsCSS?: CSSObject;
    rightAddonsCSS?: CSSObject;
    /**
     * Запрещает ввод с клавиатуры
     */
    disableUserInput?: boolean;
    /**
     * Обработчик поля ввода
     */
    onChange?: (event: ChangeEvent<HTMLInputElement>, payload: {
        value: string;
    }) => void;
    /**
     * Обработчик нажатия на кнопку очистки
     */
    onClear?: (event: MouseEvent<HTMLButtonElement>) => void;
    /**
     * Обработчик клика по полю
     */
    onClick?: (event: MouseEvent<HTMLDivElement>) => void;
    /**
     * Обработчик MouseDown по полю
     */
    onMouseDown?: (event: MouseEvent<HTMLDivElement>) => void;
    /**
     * Обработчик MouseUp по полю
     */
    onMouseUp?: (event: MouseEvent<HTMLDivElement>) => void;
    isLegend?: boolean;
};
type ExtendedValue<T> = T | T[] | Record<string, T> | Record<string, T>[];
type IFieldValueType = Exclude<ExtendedValue<NativeFieldValue>, undefined>;
interface IControllerRenderProps<T extends IFieldValueType> extends Omit<ControllerRenderProps, "value"> {
    value: T;
}
/**
 * Interface props passed by the field wrapper component
 */
interface IFieldWrapperProps<T extends IFieldValueType> {
    /**
     * Returned property of useController
     * Contains a meta
     * https://react-hook-form.com/docs/usecontroller
     * */
    fieldState: ControllerFieldState;
    /**
     * Returned property of useController
     * Contains a value and a value change handler
     * https://react-hook-form.com/docs/usecontroller
     * */
    field: IControllerRenderProps<T>;
    /**
     * Handler for changing field value
     * @param value - field value, not event
     */
    setFieldValue: (value: T) => void;
    /**
     * Field error
     */
    error?: string;
}
declare const BASE_INPUT_CSS: CSSObject;
declare const Input: import("react").ForwardRefExoticComponent<Omit<import("react").InputHTMLAttributes<HTMLInputElement>, "size" | "value" | "type" | "onChange" | "onClick" | "onMouseDown" | "defaultValue" | "enterKeyHint"> & {
    value?: string | undefined;
    defaultValue?: string | undefined;
    error?: string | undefined;
    block?: boolean | undefined;
    clear?: boolean | undefined;
    theme?: FormControlTheme | "basic" | undefined;
    variant?: "primary" | typeof FormControlVariant | undefined;
    size?: "md" | "sm" | "lg" | typeof FormControlSize | undefined;
    labelWrap?: boolean | undefined;
    showError?: boolean | undefined;
    hint?: import("react").ReactNode;
    label?: import("react").ReactNode;
    type?: "number" | "color" | "link" | "time" | "text" | "url" | "tel" | "email" | "password" | "card" | "money" | undefined;
    wrapperRef?: import("react").Ref<HTMLDivElement> | undefined;
    leftAddons?: import("react").ReactNode;
    rightAddons?: import("react").ReactNode;
    innerLeftAddons?: import("react").ReactNode;
    bottomAddons?: import("react").ReactNode;
    className?: string | undefined;
    fieldCSS?: CSSObject | undefined;
    wrapperCSS?: CSSObject | undefined;
    inputCSS?: CSSObject | undefined;
    labelCSS?: CSSObject | undefined;
    leftAddonsCSS?: CSSObject | undefined;
    rightAddonsCSS?: CSSObject | undefined;
    disableUserInput?: boolean | undefined;
    onChange?: ((event: ChangeEvent<HTMLInputElement>, payload: {
        value: string;
    }) => void) | undefined;
    onClear?: ((event: MouseEvent<HTMLButtonElement, globalThis.MouseEvent>) => void) | undefined;
    onClick?: ((event: MouseEvent<HTMLDivElement, globalThis.MouseEvent>) => void) | undefined;
    onMouseDown?: ((event: MouseEvent<HTMLDivElement, globalThis.MouseEvent>) => void) | undefined;
    onMouseUp?: ((event: MouseEvent<HTMLDivElement, globalThis.MouseEvent>) => void) | undefined;
    isLegend?: boolean | undefined;
} & Partial<IFieldWrapperProps<string>> & import("react").RefAttributes<HTMLInputElement>>;
export { formControlThemes, FormControl, FormControlSize, FormControlVariant, FormControlState, FormControlThemeState, FormControlTheme, FormControlProps, FormMessage, FormMessageProps, IMessageIconProps, InputProps, BASE_INPUT_CSS, Input };
