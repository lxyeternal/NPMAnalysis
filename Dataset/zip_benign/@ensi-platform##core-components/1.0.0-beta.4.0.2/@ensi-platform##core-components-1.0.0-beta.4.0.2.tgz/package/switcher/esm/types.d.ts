import { BaseThemeState, StyleDefinition, ValueOrFunction, useCheckboxLikeControlHookType } from "../../common/esm";
import { IFieldWrapperProps } from "./index-5fd63277.js";
import { CSSObject } from '@emotion/react';
import { ChangeEventHandler, HTMLProps, Ref } from 'react';
import { switcherThemes } from "./themes/index.js";
/**
 * Размеры переключателя
 */
declare enum SwitcherSize {
    sm = "sm",
    md = "md"
}
/**
 * Варианты переключателя
 */
declare enum SwitcherVariant {
    primary = "primary"
}
/**
 * Состояния свитчера
 */
interface SwitcherState {
    /**
     * Выбранное состояние
     */
    checked?: boolean;
    /**
     * Заблокированное состояние
     */
    disabled?: boolean;
    /**
     * Cостояние только для чтения
     */
    readOnly?: boolean;
    /**
     * С ошибкой
     */
    hasError?: boolean;
}
/**
 * Состояния переключателя
 */
type SwitcherThemeState = BaseThemeState<typeof SwitcherVariant, typeof SwitcherSize, never> & SwitcherState;
declare enum SwitcherParts {
    label = 0,
    icon = 1,
    input = 2,
    error = 3
}
/**
 * Темы переключателя
 */
type SwitcherTheme = ValueOrFunction<Record<keyof typeof SwitcherParts, StyleDefinition<SwitcherThemeState>>, [
    SwitcherThemeState
]>;
/**
 * Пропсы переключателя
 */
interface SwitcherProps extends Omit<BaseThemeState<typeof SwitcherVariant, typeof SwitcherSize, SwitcherTheme>, 'theme'>, Omit<HTMLProps<HTMLInputElement>, 'size' | 'onChange'>, Partial<IFieldWrapperProps<boolean>> {
    /** Ref for inner input */
    inputRef?: Ref<HTMLInputElement>;
    /** Additional css for label */
    labelCSS?: CSSObject;
    /** Additional class */
    className?: string;
    /** Additional css for input */
    inputCSS?: CSSObject;
    error?: string;
    theme?: SwitcherTheme | keyof typeof switcherThemes;
    allowUnselectDisabledOptions?: boolean;
    useControlHook?: useCheckboxLikeControlHookType;
    onChange?: ChangeEventHandler;
}
export { SwitcherSize, SwitcherVariant, SwitcherState, SwitcherThemeState, SwitcherTheme, SwitcherProps };
