/// <reference types="react" />
import { SwitcherProps } from "./types.js";
/**
 * Компонент переключателя
 */
declare const Switcher: ({ name, field, value, error, inputCSS: propsInputCSS, labelCSS: propsLabelCSS, inputRef, className, theme: themeName, size, variant, css, checked: propChecked, allowUnselectDisabledOptions, disabled, onChange, ...props }: SwitcherProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export * from "./types.js";
export { Switcher };
