/// <reference types="react" />
import { ElementType } from 'react';
import BlockBody from "./components/BlockBody.js";
import BlockMobileFluid from "./components/BlockBodyFluid.js";
import BlockFooter from "./components/BlockFooter.js";
import BlockHeader from "./components/BlockHeader.js";
import { IBlockProps } from "./types/index.js";
declare const Block: {
    <T extends ElementType = "section">({ as, background, boxShadow, ...props }: IBlockProps<T>): import("react").ReactElement<any, string | import("react").JSXElementConstructor<any>>;
    Header: ({ className, children, borderColor }: import("./components/BlockHeader.js").BlockHeaderProps) => import("@emotion/react/jsx-runtime").JSX.Element;
    Body: ({ className, children }: import("./components/BlockBody.js").BlockBodyProps) => import("@emotion/react/jsx-runtime").JSX.Element;
    MobileFluid: ({ className, children }: import("./components/BlockBodyFluid.js").BlockBodyFluidProps) => import("@emotion/react/jsx-runtime").JSX.Element;
    Footer: ({ className, children, borderColor }: import("./components/BlockFooter.js").BlockFooterProps) => import("@emotion/react/jsx-runtime").JSX.Element;
};
export { BlockHeader, BlockMobileFluid, BlockBody, BlockFooter, Block };
