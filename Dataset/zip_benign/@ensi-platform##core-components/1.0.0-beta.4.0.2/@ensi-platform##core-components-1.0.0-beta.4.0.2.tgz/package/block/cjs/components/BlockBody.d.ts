import { ReactNode } from 'react';
interface BlockBodyProps {
    className?: string;
    children?: ReactNode | ReactNode[];
}
declare const BlockBody: ({ className, children }: BlockBodyProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export { BlockBody as default, BlockBodyProps };
