import { ReactNode } from 'react';
interface BlockFooterProps {
    className?: string;
    children?: ReactNode;
    borderColor?: string;
}
declare const BlockFooter: ({ className, children, borderColor }: BlockFooterProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export { BlockFooter as default, BlockFooterProps };
