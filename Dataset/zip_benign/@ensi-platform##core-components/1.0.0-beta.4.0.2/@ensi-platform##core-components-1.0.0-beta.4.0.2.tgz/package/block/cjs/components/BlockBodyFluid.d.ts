import { ReactNode } from 'react';
interface BlockBodyFluidProps {
    className?: string;
    children?: ReactNode;
}
/**
 * Через отрицательный margin заполняет содержимое блока во всю ширину.
 * Работает только на мобилках для таблиц.
 */
declare const BlockBodyFluid: ({ className, children }: BlockBodyFluidProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export { BlockBodyFluid as default, BlockBodyFluidProps };
