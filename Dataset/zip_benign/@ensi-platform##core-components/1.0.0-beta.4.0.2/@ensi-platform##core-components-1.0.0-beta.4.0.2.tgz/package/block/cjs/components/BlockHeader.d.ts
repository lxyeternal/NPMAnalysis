import { ReactNode } from 'react';
interface BlockHeaderProps {
    className?: string;
    children?: ReactNode;
    borderColor?: string;
}
declare const BlockHeader: ({ className, children, borderColor }: BlockHeaderProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export { BlockHeader as default, BlockHeaderProps };
