import { ElementType, ReactNode } from 'react';
interface IBlockProps<P extends ElementType = 'section'> {
    /** Use your own React component for render. */
    as?: P;
    children: ReactNode | ReactNode[];
    className?: string;
    background?: string;
    boxShadow?: string;
}
export { IBlockProps };
