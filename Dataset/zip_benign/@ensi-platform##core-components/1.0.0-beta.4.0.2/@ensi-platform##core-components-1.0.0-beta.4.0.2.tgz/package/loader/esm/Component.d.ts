import { EnumLike } from "../../common/esm";
import { FC } from 'react';
import { LoaderSizes, LoaderVariants } from "./scripts/index.js";
import { ILoaderProps } from "./types/index.js";
declare const BaseLoader: <V extends EnumLike, S extends EnumLike>({ message, wrapperCSS: wrapperCSSProp, containerCSS: containerCSSProp, spinnerCSS: spinnerCSSProp, messageCSS: messageCSSProp, className, theme, variant, size, }: ILoaderProps<V, S>) => import("@emotion/react/jsx-runtime").JSX.Element;
declare const Loader: FC<ILoaderProps<typeof LoaderVariants, typeof LoaderSizes>>;
export { Loader as default, BaseLoader };
