import Loader from "./Component.js";
export { Loader };
export * from "./Component.js";
export * from "./scripts/index.js";
export * from "./themes/index.js";
export * from "./types/index.js";
