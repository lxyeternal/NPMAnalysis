/// <reference types="react" />
import { IPortalProps } from "./types/index.js";
declare const Portal: import("react").ForwardRefExoticComponent<IPortalProps & import("react").RefAttributes<Element>>;
export { Portal as default };
