import Portal from "./Component.js";
export { Portal };
export * from "./types/index.js";
export * from "./scripts/index.js";
