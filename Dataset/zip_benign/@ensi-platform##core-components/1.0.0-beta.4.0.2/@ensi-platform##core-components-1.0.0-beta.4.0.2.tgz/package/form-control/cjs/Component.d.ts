/// <reference types="react" />
import { CSSObject } from '@emotion/react';
declare const FormControl: import("react").ForwardRefExoticComponent<Partial<Omit<import("../../common/cjs").BaseThemeState<typeof import("./types.js").FormControlVariant, typeof import("./types.js").FormControlSize, import("./types.js").FormControlTheme>, "theme">> & Partial<Omit<import("./types.js").FormControlState, "hasInnerLabel" | "hasError" | "hasRightAddons" | "hasLeftAddons">> & import("react").HTMLAttributes<HTMLDivElement> & {
    labelProps?: import("react").HTMLAttributes<HTMLLabelElement> | undefined;
    htmlFor?: string | undefined;
    error?: string | undefined;
    showError?: boolean | undefined;
    hint?: import("react").ReactNode;
    label?: import("react").ReactNode;
    leftAddons?: import("react").ReactNode;
    rightAddons?: import("react").ReactNode;
    bottomAddons?: import("react").ReactNode;
    className?: string | undefined;
    labelCSS?: CSSObject | undefined;
    fieldCSS?: CSSObject | undefined;
    wrapperCSS?: CSSObject | undefined;
    leftAddonsCSS?: CSSObject | undefined;
    rightAddonsCSS?: CSSObject | undefined;
    children?: import("react").ReactNode;
    theme?: import("./types.js").FormControlTheme | "basic" | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
export { FormControl as default, FormControl };
