import { BaseThemeState, StyleDefinition, ValueOrFunction } from "../../common/cjs";
import { CSSObject } from '@emotion/react';
import { HTMLAttributes, ReactNode } from 'react';
import { formControlThemes } from "./themes/defaultTheme.js";
declare enum FormControlSize {
    sm = "sm",
    md = "md",
    lg = "lg"
}
declare enum FormControlVariant {
    primary = "primary"
}
interface FormControlState {
    /**
     * Растягивает компонент на ширину контейнера
     */
    block?: boolean;
    /**
     * Заблокированное состояние
     */
    disabled?: boolean;
    /**
     * Cостояние только для чтения
     */
    readOnly?: boolean;
    /**
     * Заполненное состояние
     */
    filled?: boolean;
    /**
     * Выбранное (фокус) состояние
     */
    focused?: boolean;
    /**
     * С ошибкой
     */
    hasError?: boolean;
    /**
     * Разрешить лейблу переноситься по строчкам
     */
    labelWrap?: boolean;
    /**
     * Есть ли левый слот
     */
    hasLeftAddons?: boolean;
    /**
     * Есть ли правый слот
     */
    hasRightAddons?: boolean;
    /**
     * Есть ли внутренний лейбл
     */
    hasInnerLabel?: boolean;
    /**
     * Положение ошибки относительно элемента
     * @default 'above'
     */
    errorPlacement?: 'under' | 'above';
}
type FormControlThemeState = BaseThemeState<typeof FormControlVariant, typeof FormControlSize, never> & FormControlState;
declare enum FormControlParts {
    wrapper = 0,
    inner = 1,
    label = 2,
    sub = 3,
    controlWrapper = 4,
    error = 5,
    clear = 6
}
type FormControlTheme = ValueOrFunction<Record<keyof typeof FormControlParts, StyleDefinition<FormControlThemeState>> & {
    addons: StyleDefinition<FormControlThemeState & {
        isLeft: boolean;
    }>;
}, [
    FormControlThemeState
]>;
type FormControlProps = Partial<Omit<BaseThemeState<typeof FormControlVariant, typeof FormControlSize, FormControlTheme>, 'theme'>> & Partial<Omit<FormControlState, 'hasInnerLabel' | 'hasError' | 'hasRightAddons' | 'hasLeftAddons'>> & HTMLAttributes<HTMLDivElement> & {
    /**
     * Пропы для лейблов (обычно id и htmlFor)
     */
    labelProps?: HTMLAttributes<HTMLLabelElement>;
    /**
     * ID элемента к которому обращен label
     */
    htmlFor?: string;
    /**
     * Отображение ошибки
     */
    error?: string;
    /**
     * Флаг отображения ошибки
     */
    showError?: boolean;
    /**
     * Текст подсказки
     */
    hint?: ReactNode;
    /**
     * Лейбл компонента
     */
    label?: ReactNode;
    /**
     * Слот слева
     */
    leftAddons?: ReactNode;
    /**
     * Слот справа
     */
    rightAddons?: ReactNode;
    /**
     * Слот под полем
     */
    bottomAddons?: ReactNode;
    /**
     * Дополнительный класс
     */
    className?: string;
    /**
     * Дополнительный стиль для лейбла
     */
    labelCSS?: CSSObject;
    /**
     * Дополнительный стиль для поля
     */
    fieldCSS?: CSSObject;
    /**
     * Дополнительный стиль для обертки
     */
    wrapperCSS?: CSSObject;
    /**
     * Дополнительный стиль для левых аддонов
     */
    leftAddonsCSS?: CSSObject;
    /**
     * Дополнительный стиль для правых аддонов
     */
    rightAddonsCSS?: CSSObject;
    /**
     * Компонент поля (инпут, textarea и пр.)
     */
    children?: ReactNode;
    theme?: FormControlTheme | keyof typeof formControlThemes;
};
export { FormControlSize, FormControlVariant, FormControlState, FormControlThemeState, FormControlTheme, FormControlProps };
