import { FC } from 'react';
import { PriceSizes, PriceVariants } from "./scripts/index.js";
import { IPriceProps } from "./types/index.js";
declare const Price: FC<IPriceProps<typeof PriceVariants, typeof PriceSizes>>;
export { Price as default };
