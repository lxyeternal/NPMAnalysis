/// <reference types="react" />
import { BaseThemeState, StyleDefinition, ValueOrFunction } from "../../common/esm";
import { HTMLProps, ReactNode, SVGProps } from 'react';
declare const AccordionSize: {
    readonly md: "md";
};
declare const AccordionVariant: {
    readonly primary: "primary";
};
type SVGRIcon = (props: SVGProps<SVGSVGElement>) => JSX.Element;
interface AccordionState {
    /** CSSTransition timeout */
    transitionTimeout?: number;
    /** CSSTransition timeout on exit (if differs) */
    transitionTimeoutExit?: number;
    /** Type of panel toggle animation */
    animationType?: 'height' | 'fadeIn' | 'custom';
    /** Icon for arrow */
    Icon?: SVGRIcon;
}
type AccordionThemeState = BaseThemeState<typeof AccordionVariant, typeof AccordionSize> & AccordionState;
type AccordionTheme = ValueOrFunction<{
    container: StyleDefinition<AccordionThemeState>;
    button: StyleDefinition<AccordionThemeState>;
    buttonIcon: StyleDefinition<AccordionThemeState>;
    item: StyleDefinition<AccordionThemeState>;
    panel: StyleDefinition<AccordionThemeState>;
}, [
    AccordionThemeState
]>;
declare const useFoo: () => <K extends "button" | "container" | "buttonIcon" | "item" | "panel">(key: K, extraData?: ({
    container: StyleDefinition<AccordionThemeState>;
    button: StyleDefinition<AccordionThemeState>;
    buttonIcon: StyleDefinition<AccordionThemeState>;
    item: StyleDefinition<AccordionThemeState>;
    panel: StyleDefinition<AccordionThemeState>;
}[K] extends ValueOrFunction<import("@emotion/serialize").CSSObject, [state: infer A]> ? Omit<A, keyof BaseThemeState<{
    readonly primary: "primary";
}, {
    readonly md: "md";
}> | keyof AccordionState> : never) | undefined) => import("@emotion/serialize").CSSObject;
interface AccordionContextProps extends AccordionState {
    /** CSSTransition handler, triggers after add 'enter' class */
    onEnter?: (node: HTMLElement, isAppearing: boolean) => void;
    /** CSSTransition handler, triggers after add 'enter-active' class */
    onEntering?: (node: HTMLElement, isAppearing: boolean) => void;
    /** CSSTransition handler, triggers after add 'exit' class */
    onExit?: (node: HTMLElement) => void;
    theme?: AccordionTheme;
    getCSS: ReturnType<typeof useFoo>;
}
interface AccordionProps extends Partial<Omit<BaseThemeState<typeof AccordionVariant, typeof AccordionSize, AccordionTheme>, 'theme'>>, Omit<AccordionContextProps, 'getCSS'>, Omit<HTMLProps<HTMLDivElement>, 'onChange' | 'ref' | 'size'> {
    /** List of Accordion.Item components */
    children: ReactNode;
    /** Panel change handler */
    onChange?: (ids: string[]) => void;
    /** Allow to simultaneously open multiple panels */
    allowMultipleExpanded?: boolean;
    /** Allow to simultaneously close all panels */
    allowZeroExpanded?: boolean;
    /** List of expanded panels by default */
    preExpanded?: string[];
}
export { AccordionSize, AccordionVariant, AccordionState, AccordionThemeState, AccordionTheme, AccordionContextProps, AccordionProps };
