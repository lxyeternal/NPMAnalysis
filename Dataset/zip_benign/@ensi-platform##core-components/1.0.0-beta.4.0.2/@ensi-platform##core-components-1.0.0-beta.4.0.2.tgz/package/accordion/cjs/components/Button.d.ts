import { HTMLProps, ReactNode } from 'react';
interface AccordionButtonProps extends HTMLProps<HTMLDivElement> {
    /** Heading content */
    children: ReactNode;
}
declare const AccordionButton: ({ children, ...props }: AccordionButtonProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export { AccordionButtonProps, AccordionButton };
