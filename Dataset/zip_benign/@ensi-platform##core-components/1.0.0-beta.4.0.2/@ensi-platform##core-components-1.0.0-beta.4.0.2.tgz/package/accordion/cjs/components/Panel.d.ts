import { HTMLProps, ReactNode } from 'react';
interface AccordionPanelProps extends Omit<HTMLProps<HTMLDivElement>, 'ref'> {
    /** Panel content */
    children: ReactNode;
}
declare const AccordionPanel: ({ children, ...props }: AccordionPanelProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export { AccordionPanelProps, AccordionPanel };
