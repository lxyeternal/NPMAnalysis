import { AccordionTheme } from "../types.js";
declare const accordionThemes: {
    basic: AccordionTheme;
};
declare const setBasicAccordionTheme: (popupTheme: AccordionTheme) => void;
export { accordionThemes, setBasicAccordionTheme };
