import { HTMLProps, ReactNode } from 'react';
interface AccordionHeadingProps extends HTMLProps<HTMLDivElement> {
    /** Accordion.Button */
    children: ReactNode;
    /** Heading level */
    'aria-level'?: number;
}
declare const AccordionHeading: ({ children, "aria-level": ariaLevel, ...props }: AccordionHeadingProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export { AccordionHeadingProps, AccordionHeading };
