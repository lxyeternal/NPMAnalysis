import { HTMLProps, ReactNode } from 'react';
interface AccordionItemProps extends Omit<HTMLProps<HTMLDivElement>, 'ref'> {
    /** Accordion.Heading and Accordion.Panel */
    children: ReactNode;
    /** Unique panel id */
    uuid?: string;
}
declare const AccordionItem: ({ children, uuid, ...props }: AccordionItemProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export { AccordionItemProps, AccordionItem };
