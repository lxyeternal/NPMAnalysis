/// <reference types="react" />
import { AccordionContextProps } from "../types.js";
declare const AccordionContext: import("react").Context<AccordionContextProps | undefined>;
declare const useAccordion: () => AccordionContextProps;
export { AccordionContext, useAccordion };
