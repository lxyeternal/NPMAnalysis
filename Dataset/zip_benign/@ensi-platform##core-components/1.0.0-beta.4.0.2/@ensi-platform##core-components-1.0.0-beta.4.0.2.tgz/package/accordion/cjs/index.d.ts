import { AccordionProps } from "./types.js";
declare const Accordion: (({ children, allowMultipleExpanded, allowZeroExpanded, preExpanded, onChange, Icon, animationType, transitionTimeout, transitionTimeoutExit, onEnter, onEntering, onExit, theme, size, variant, ...props }: AccordionProps) => import("@emotion/react/jsx-runtime").JSX.Element) & {
    Item: ({ children, uuid, ...props }: import("./components/Item.js").AccordionItemProps) => import("@emotion/react/jsx-runtime").JSX.Element;
    Heading: ({ children, "aria-level": ariaLevel, ...props }: import("./components/Heading.js").AccordionHeadingProps) => import("@emotion/react/jsx-runtime").JSX.Element;
    Button: ({ children, ...props }: import("./components/Button.js").AccordionButtonProps) => import("@emotion/react/jsx-runtime").JSX.Element;
    Panel: ({ children, ...props }: import("./components/Panel.js").AccordionPanelProps) => import("@emotion/react/jsx-runtime").JSX.Element;
};
export { Accordion };
