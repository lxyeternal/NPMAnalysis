/// <reference types="react" />
import { CalendarState } from "./types.js";
declare const Calendar: import("react").ForwardRefExoticComponent<Omit<CalendarState, "weeksCount"> & Partial<Omit<import("../../common/esm").BaseThemeState<{
    readonly primary: "primary";
}, {
    readonly md: "md";
}, import("./types.js").CalendarTheme>, "theme">> & {
    className?: string | undefined;
    value?: number | undefined;
    month?: number | undefined;
    defaultMonth?: number | undefined;
    minDate?: number | undefined;
    maxDate?: number | undefined;
    selectedFrom?: number | undefined;
    selectedTo?: number | undefined;
    events?: (number | Date)[] | undefined;
    offDays?: (number | Date)[] | undefined;
    onMonthChange?: ((month: number) => void) | undefined;
    onChange?: ((date: number, isKeyboard: boolean) => void) | undefined;
    dataTestId?: string | undefined;
    theme?: import("./types.js").CalendarTheme | undefined;
} & import("react").RefAttributes<HTMLDivElement>>;
export * from "./types.js";
export * from "./scripts/utils.js";
export { Calendar };
