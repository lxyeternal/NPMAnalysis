import { BaseThemeState, StyleDefinition, ValueOrFunction } from "../../common/esm";
import { ReactNode } from 'react';
declare const CalendarSize: {
    readonly md: "md";
};
declare const CalendarVariant: {
    readonly primary: "primary";
};
type SpecialDays = Record<number, boolean>;
type SpecialDaysAddon = Record<number, ReactNode>;
type DayAddons = {
    date: Date | number;
    addon: ReactNode;
};
type Day = {
    date: Date;
    disabled?: boolean;
    event?: boolean;
    selected?: boolean;
    holiday?: boolean;
    dayAddon?: ReactNode;
};
type Month = {
    date: Date;
    disabled?: boolean;
};
type DateShift = 'prev' | 'prevWeek' | 'prevMonth' | 'startOfWeek' | 'next' | 'nextWeek' | 'nextMonth' | 'endOfWeek';
type View = 'years' | 'months' | 'days';
type SelectorView = 'month-only' | 'full';
interface CalendarState {
    weeksCount: number;
    /**
     * Вид по умолчанию (выбор дней, месяцев, лет)
     */
    defaultView?: View;
    /**
     * Вид шапки — месяц и год или только месяц
     */
    selectorView?: SelectorView;
}
type CalendarThemeState = BaseThemeState<typeof CalendarVariant, typeof CalendarSize> & CalendarState;
type CalendarTheme = ValueOrFunction<{
    container: StyleDefinition<CalendarThemeState>;
    wrapper: StyleDefinition<CalendarThemeState>;
    daysTableRoot: StyleDefinition<CalendarThemeState>;
    daysTableTh: StyleDefinition<CalendarThemeState>;
    daysTableButton: StyleDefinition<CalendarThemeState & Partial<{
        highlighted: boolean;
        selected: boolean;
        range: boolean;
        rangeStart: boolean;
        transitLeft: boolean;
        transitRight: boolean;
        today: boolean;
        firstDay: boolean;
        lastDay: boolean;
        event: boolean;
        disabled: boolean;
    }>>;
    keyframes: StyleDefinition<CalendarThemeState & {
        direction?: 'left' | 'right' | null;
    }>;
    selectButton: StyleDefinition<CalendarThemeState & {
        buttonVariant?: 'default' | 'outlined' | 'selected';
    }>;
    yearsTable: StyleDefinition<CalendarThemeState>;
}, [
    CalendarThemeState
]>;
declare const useFoo: () => <K extends "container" | "wrapper" | "daysTableRoot" | "daysTableTh" | "daysTableButton" | "keyframes" | "selectButton" | "yearsTable">(key: K, extraData?: ({
    container: StyleDefinition<CalendarThemeState>;
    wrapper: StyleDefinition<CalendarThemeState>;
    daysTableRoot: StyleDefinition<CalendarThemeState>;
    daysTableTh: StyleDefinition<CalendarThemeState>;
    daysTableButton: StyleDefinition<CalendarThemeState & Partial<{
        highlighted: boolean;
        selected: boolean;
        range: boolean;
        rangeStart: boolean;
        transitLeft: boolean;
        transitRight: boolean;
        today: boolean;
        firstDay: boolean;
        lastDay: boolean;
        event: boolean;
        disabled: boolean;
    }>>;
    keyframes: StyleDefinition<CalendarThemeState & {
        direction?: 'left' | 'right' | null;
    }>;
    selectButton: StyleDefinition<CalendarThemeState & {
        buttonVariant?: 'default' | 'outlined' | 'selected';
    }>;
    yearsTable: StyleDefinition<CalendarThemeState>;
}[K] extends ValueOrFunction<import("@emotion/serialize").CSSObject, [state: infer A]> ? Omit<A, keyof BaseThemeState<{
    readonly primary: "primary";
}, {
    readonly md: "md";
}> | keyof CalendarState> : never) | undefined) => import("@emotion/serialize").CSSObject;
interface CalendarThemeContextProps extends CalendarState {
    theme: CalendarTheme;
    getCSS: ReturnType<typeof useFoo>;
}
type CalendarProps = Omit<CalendarState, 'weeksCount'> & Partial<Omit<BaseThemeState<typeof CalendarVariant, typeof CalendarSize, CalendarTheme>, 'theme'>> & {
    /**
     * Дополнительный класс
     */
    className?: string;
    /**
     * Выбранная дата (timestamp)
     */
    value?: number;
    /**
     * Открытый месяц (timestamp)
     */
    month?: number;
    /**
     * Месяц, открытый по умолчанию (timestamp)
     */
    defaultMonth?: number;
    /**
     * Минимальная дата, доступная для выбора (timestamp)
     */
    minDate?: number;
    /**
     * Максимальная дата, доступная для выбора (timestamp)
     */
    maxDate?: number;
    /**
     * Начало выделенного периода (timestamp)
     */
    selectedFrom?: number;
    /**
     * Конец выделенного периода (timestamp)
     */
    selectedTo?: number;
    /**
     * Список событий
     */
    events?: Array<Date | number>;
    /**
     * Список выходных
     */
    offDays?: Array<Date | number>;
    /**
     * Обработчик изменения месяца (или года)
     */
    onMonthChange?: (month: number) => void;
    /**
     * Обработчик выбора даты
     */
    onChange?: (date: number, isKeyboard: boolean) => void;
    /**
     * Идентификатор для систем автоматизированного тестирования
     */
    dataTestId?: string;
    theme?: CalendarTheme;
};
export { CalendarSize, CalendarVariant, SpecialDays, SpecialDaysAddon, DayAddons, Day, Month, DateShift, View, SelectorView, CalendarState, CalendarThemeState, CalendarTheme, CalendarThemeContextProps, CalendarProps };
