/// <reference types="react" />
import { KeyboardEvent, MouseEvent, Ref } from 'react';
import { Day, DayAddons, Month, View } from "../types.js";
type UseCalendarProps = {
    /**
     * Активный вид (выбор дней, месяцев, лет)
     */
    view?: View;
    /**
     * Выбранный месяц (controlled)
     */
    month?: Date;
    /**
     * Начальный месяц
     */
    defaultMonth: Date;
    /**
     * Минимальная дата, доступная для выбора
     */
    minDate?: Date;
    /**
     * Максимальная дата, доступная для выбора
     */
    maxDate?: Date;
    /**
     * Выбранная дата
     */
    selected?: Date;
    /**
     * Список событий
     */
    events?: Array<Date | number>;
    /**
     * Список недоступных дней
     */
    offDays?: Array<Date | number>;
    /**
     * Список выходных дней
     */
    holidays?: Array<Date | number>;
    /**
     * Обработчик изменения месяца (или года)
     */
    onMonthChange?: (month: number) => void;
    /**
     * Обработчик выбора даты
     */
    onChange?: (date: number, isKeyboard: boolean) => void;
    /**
     * Дополнительный контент под числом
     */
    dayAddons?: DayAddons[];
};
declare function useCalendar({ defaultMonth, month, minDate, view, maxDate, selected, events, offDays, dayAddons, holidays, onMonthChange, onChange, }: UseCalendarProps): {
    activeMonth: Date;
    weeks: Day[][];
    months: Month[];
    years: Date[];
    canSetPrevMonth: boolean;
    canSetNextMonth: boolean;
    highlighted: number | Date | undefined;
    setPrevMonth: () => void;
    setNextMonth: () => void;
    setMonthByDate: (newMonth: Date) => void;
    getDayProps: (day: Day) => {
        'data-date': number;
        'aria-selected': boolean | undefined;
        ref: (node: HTMLButtonElement) => void;
        tabIndex: number;
        onMouseEnter: (event: MouseEvent<HTMLButtonElement>) => void;
        onMouseLeave: () => void;
        onClick: (event: MouseEvent<HTMLButtonElement>) => void;
    };
    getMonthProps: (month: Month) => {
        'data-date': number;
        'aria-selected': boolean;
        ref: (node: HTMLButtonElement) => void;
        tabIndex: number;
        disabled: boolean | undefined;
        onClick: (event: MouseEvent<HTMLButtonElement>) => void;
    };
    getYearProps: (year: Date) => {
        'data-date': number;
        'aria-selected': boolean;
        ref: (node: HTMLButtonElement) => void;
        tabIndex: number;
        onClick: (event: MouseEvent<HTMLButtonElement>) => void;
    };
    getRootProps: ({ ref }: {
        ref?: Ref<HTMLDivElement>;
    }) => {
        onKeyDown: (event: KeyboardEvent<HTMLDivElement>) => void;
        ref: (instance: HTMLDivElement | null) => void;
        tabIndex: number;
    };
};
export { UseCalendarProps, useCalendar };
