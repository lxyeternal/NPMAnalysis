import { CalendarTheme } from "../types.js";
declare const сalendarThemes: {
    basic: CalendarTheme;
};
declare const setBasicCalendarTheme: (popupTheme: CalendarTheme) => void;
export { сalendarThemes, setBasicCalendarTheme };
