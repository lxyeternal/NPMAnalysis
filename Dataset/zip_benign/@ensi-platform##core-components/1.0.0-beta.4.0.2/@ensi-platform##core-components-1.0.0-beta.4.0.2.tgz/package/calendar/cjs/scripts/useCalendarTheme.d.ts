/// <reference types="react" />
import { CalendarThemeContextProps } from "../types.js";
declare const CalendarThemeContext: import("react").Context<CalendarThemeContextProps | undefined>;
declare const useCalendarTheme: () => CalendarThemeContextProps;
export { useCalendarTheme as default, CalendarThemeContext };
