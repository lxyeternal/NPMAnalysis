import { BaseThemeState } from "../../common/cjs";
import { FC, ReactNode } from 'react';
import { TabsSize, TabsState, TabsTheme, TabsVariant } from "./types.js";
declare const useFoo: () => <K extends keyof TabsTheme>(key: K, extraData?: (TabsTheme[K] extends import("../../common/cjs").ValueOrFunction<import("@emotion/serialize").CSSObject, [state: infer A]> ? Omit<A, "size" | "variant" | keyof TabsState> : never) | undefined) => import("@emotion/serialize").CSSObject;
type Context = Required<BaseThemeState<typeof TabsVariant, typeof TabsSize, TabsTheme>> & {
    state: TabsState;
    getCSS: ReturnType<typeof useFoo>;
    idPrefix: string;
};
type ContextProps = Required<BaseThemeState<typeof TabsVariant, typeof TabsSize, TabsTheme>> & {
    idPrefix: string;
    state: TabsState;
};
declare const TabsThemeProvider: FC<{
    children: ReactNode;
} & ContextProps>;
declare const useTabsTheme: () => Context;
export { TabsThemeProvider, useTabsTheme };
