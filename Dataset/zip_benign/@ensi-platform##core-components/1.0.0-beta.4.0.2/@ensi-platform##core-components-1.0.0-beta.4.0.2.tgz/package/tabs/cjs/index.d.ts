import { FC } from 'react';
import { Tab } from "./components/Tab/index.js";
import { LinkTitle } from "./components/Title/LinkTitle.js";
import { TabsProps } from "./types.js";
interface TabsCompositionProps {
    Tab: typeof Tab;
    LinkTitle: typeof LinkTitle;
}
type TabsComponentProps = Omit<TabsProps, 'TabList'> & {
    TabList?: TabsProps['TabList'];
};
declare const Tabs: FC<TabsComponentProps> & TabsCompositionProps;
export type { TabsProps };
export { Tabs };
