import { FC } from 'react';
import { IInternalThemeProviderProps } from "./types/index.js";
declare const InternalThemeProvider: FC<IInternalThemeProviderProps>;
export { InternalThemeProvider as default };
