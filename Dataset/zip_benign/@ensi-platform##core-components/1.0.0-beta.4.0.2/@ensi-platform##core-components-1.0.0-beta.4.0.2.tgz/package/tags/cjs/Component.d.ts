import { ITagsCompositionProps, ITagsProps } from "./types/index.js";
/**
 * Wrapper for nameplates list
 */
declare const Tags: {
    ({ className, disabled, wrap, CloseIcon, children, onDelete, }: ITagsProps & Partial<ITagsCompositionProps>): import("@emotion/react/jsx-runtime").JSX.Element | null;
    Tag: ({ disabled, onDelete, onClick, CloseIcon, tabIndex, children, css: buttonCss, closerCss, ...props }: import("./types/index.js").ITagProps, ref: any) => import("@emotion/react/jsx-runtime").JSX.Element;
};
export { Tags };
