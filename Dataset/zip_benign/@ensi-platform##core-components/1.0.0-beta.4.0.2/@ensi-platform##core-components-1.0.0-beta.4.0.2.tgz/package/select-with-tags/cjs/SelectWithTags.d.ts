/// <reference types="react" />
import { SelectWithTagsProps } from "./types/index.js";
declare const SimpleSelectWithTags: import("react").ForwardRefExoticComponent<SelectWithTagsProps & import("react").RefAttributes<HTMLDivElement>>;
declare const SelectWithTags: import("react").ForwardRefExoticComponent<Omit<SelectWithTagsProps, "value" | "onInput"> & import("react").RefAttributes<HTMLDivElement>>;
export { SimpleSelectWithTags, SelectWithTags };
