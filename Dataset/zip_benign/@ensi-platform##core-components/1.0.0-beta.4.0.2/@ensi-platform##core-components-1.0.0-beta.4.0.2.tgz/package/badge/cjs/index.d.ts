import { STATUSES } from "../../common/cjs";
interface BadgeProps {
    text: string;
    bgColor?: string;
    type?: STATUSES;
}
declare const Badge: ({ text, bgColor, type }: BadgeProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export { BadgeProps, Badge };
