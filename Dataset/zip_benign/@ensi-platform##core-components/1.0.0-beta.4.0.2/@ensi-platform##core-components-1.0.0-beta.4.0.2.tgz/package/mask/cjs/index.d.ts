/// <reference types="react" />
import { ControllerFieldState, ControllerRenderProps, NativeFieldValue } from "react-hook-form";
import { useIMask } from 'react-imask';
type ExtendedValue<T> = T | T[] | Record<string, T> | Record<string, T>[];
type IFieldValueType = Exclude<ExtendedValue<NativeFieldValue>, undefined>;
interface IControllerRenderProps<T extends IFieldValueType> extends Omit<ControllerRenderProps, "value"> {
    value: T;
}
/**
 * Interface props passed by the field wrapper component
 */
interface IFieldWrapperProps<T extends IFieldValueType> {
    /**
     * Returned property of useController
     * Contains a meta
     * https://react-hook-form.com/docs/usecontroller
     * */
    fieldState: ControllerFieldState;
    /**
     * Returned property of useController
     * Contains a value and a value change handler
     * https://react-hook-form.com/docs/usecontroller
     * */
    field: IControllerRenderProps<T>;
    /**
     * Handler for changing field value
     * @param value - field value, not event
     */
    setFieldValue: (value: T) => void;
    /**
     * Field error
     */
    error?: string;
}
type MaskType = Exclude<Parameters<typeof useIMask>[0]['mask'], undefined>;
interface MaskProps extends Partial<IFieldWrapperProps<string>> {
    /** Mask for input */
    mask: MaskType;
    /** Placeholder for mask */
    placeholderChar?: string;
    /** Is show placholder */
    lazy?: boolean;
    label?: string;
    className?: string;
    blocks?: Record<string, any>;
    format?: (input: any) => string;
    unmask?: (val: string) => any;
    autofix?: boolean;
    overwrite?: boolean;
    hint?: string;
}
declare const Mask: import("react").ForwardRefExoticComponent<MaskProps & import("react").RefAttributes<HTMLInputElement>>;
export { MaskProps, Mask };
