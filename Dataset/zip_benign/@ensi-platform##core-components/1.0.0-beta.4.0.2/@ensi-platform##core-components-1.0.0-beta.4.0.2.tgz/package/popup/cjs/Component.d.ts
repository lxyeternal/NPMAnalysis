/// <reference types="react" />
import { IModalResponsiveProps } from "./types/index.js";
declare const PopupResponsiveComponent: import("react").ForwardRefExoticComponent<IModalResponsiveProps & import("react").RefAttributes<HTMLDivElement>>;
export { PopupResponsiveComponent as default };
