import { BaseThemeState, StyleDefinition, ValueOrFunction } from "../../common/esm";
import { IFieldWrapperProps } from "./index-5fd63277.js";
import { CSSObject } from '@emotion/react';
import { FC, FocusEvent, HTMLProps, MouseEvent, MouseEventHandler } from 'react';
import { ratingThemes } from "./themes/index.js";
declare enum RatingSize {
    sm = "sm",
    md = "md",
    lg = "lg"
}
declare enum RatingVariant {
    primary = "primary"
}
interface RatingState {
    disabled: boolean;
    value: number;
    readOnly: boolean;
    label: string;
    showReadOnlyEmptyStar: boolean;
    /**
     * Точность, кратность дробности
     * @example 1 - только целые шаги, 0.5 - половина
     */
    precision: number;
}
interface RatingStarState {
    isLast: boolean;
    isChecked: boolean;
    isFilled: boolean;
    isHovered: boolean;
    isFocusVisible: boolean;
    isActive: boolean;
}
type RatingThemeState = BaseThemeState<typeof RatingVariant, typeof RatingSize, never> & RatingState;
type RatingTheme = ValueOrFunction<{
    container: StyleDefinition<RatingThemeState & {
        isFocused?: boolean;
    }>;
    fractionWrapper: StyleDefinition<RatingThemeState>;
    iconWrapper: StyleDefinition<RatingThemeState & Partial<RatingStarState>>;
    icon: StyleDefinition<RatingThemeState & Partial<RatingStarState>>;
}, [
    RatingThemeState
]>;
type RatingProps = Partial<Omit<BaseThemeState<typeof RatingVariant, typeof RatingSize, RatingTheme>, 'theme'>> & Partial<RatingState> & Partial<IFieldWrapperProps<number>> & {
    onMouseMove?: MouseEventHandler;
    name?: string;
    className?: string;
    onChange?: (e: {
        target: {
            value: number;
        };
    }) => void;
    onHoverChange?: (e: MouseEvent, payload: {
        value: number;
    }) => void;
    getLabelText?: (val: number) => string;
    emptyLabelText?: string;
    containerCSS?: CSSObject;
    fractionWrapperCSS?: CSSObject;
    iconWrapperCSS?: CSSObject;
    iconCSS?: CSSObject;
    StarIcon?: FC<any>;
    theme?: RatingTheme | keyof typeof ratingThemes;
};
interface RatingStarProps extends Omit<HTMLProps<HTMLLabelElement>, 'onChange' | 'name'> {
    itemValue: number;
    disabled?: boolean;
    id: string;
    name: string;
    onChange: (val: number) => void;
    onBlur: (event: FocusEvent) => void;
    onFocus: (event: FocusEvent) => void;
    onClick: (event: MouseEvent) => void;
    getLabelText: RatingProps['getLabelText'];
    showReadOnlyEmptyStar: boolean;
    isReadonly?: boolean;
    iconCSS?: CSSObject;
    iconWrapperCSS?: CSSObject;
    isFilled?: boolean;
    isChecked?: boolean;
    StarIcon: FC<any>;
}
export { RatingSize, RatingVariant, RatingState, RatingStarState, RatingThemeState, RatingTheme, RatingProps, RatingStarProps };
