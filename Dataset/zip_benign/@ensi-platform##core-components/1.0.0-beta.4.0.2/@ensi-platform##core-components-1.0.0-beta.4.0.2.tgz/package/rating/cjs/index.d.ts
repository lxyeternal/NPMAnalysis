import { RatingProps } from "./types.js";
declare const Rating: ({ name, label, error, value: propsValue, field, setFieldValue, getLabelText, precision, showReadOnlyEmptyStar, disabled, readOnly, className, size, theme: themeProp, variant, StarIcon, containerCSS, fractionWrapperCSS, iconCSS, iconWrapperCSS, onMouseMove, onChange, onHoverChange, }: RatingProps) => import("@emotion/react/jsx-runtime").JSX.Element;
export * from "./types.js";
export { Rating };
