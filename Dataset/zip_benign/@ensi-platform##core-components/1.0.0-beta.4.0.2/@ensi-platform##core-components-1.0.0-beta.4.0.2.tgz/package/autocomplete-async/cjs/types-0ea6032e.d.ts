import { HTMLProps, ReactNode } from 'react';
interface IFormFieldWrapperProps extends Omit<HTMLProps<HTMLDivElement>, 'children'> {
    /** Name of field */
    name: string;
    /** Form component */
    children: ReactNode;
}
export { IFormFieldWrapperProps };
