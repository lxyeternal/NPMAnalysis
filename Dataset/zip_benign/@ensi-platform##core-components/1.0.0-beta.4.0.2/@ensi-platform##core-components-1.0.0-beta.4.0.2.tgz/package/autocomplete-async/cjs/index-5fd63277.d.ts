/// <reference types="react" />
import { IFormFieldWrapperProps } from "./types-0ea6032e.js";
/**
 * FieldWrapper - is a wrapper for any field, controlled with RHF
 */
declare const FormFieldWrapper: import("react").ForwardRefExoticComponent<Omit<IFormFieldWrapperProps, "ref"> & import("react").RefAttributes<HTMLInputElement>>;
export { FormFieldWrapper as default, FormFieldWrapper };
