import { actions } from "../scripts/constants.js";
type Actions = typeof actions extends {
    [key: string]: (...args: any) => infer U;
} ? U : never;
export { Actions };
