import { SyntheticEvent } from 'react';
import { NativeFieldValue } from 'react-hook-form';
import { IFormFieldWrapperProps } from "./types-0ea6032e.js";
/**
 * Prepare props for controlled field by its name
 */
declare const useFieldHook: ({ name }: Pick<IFormFieldWrapperProps, 'name'>) => {
    field: import("react-hook-form").ControllerRenderProps<import("react-hook-form").FieldValues, string>;
    onChange: (key: string, value?: NativeFieldValue) => void;
    setValue: import("react-hook-form").UseFormSetValue<import("react-hook-form").FieldValues>;
    fieldState: {
        error: any;
        invalid: boolean;
        isTouched: boolean;
        isDirty: boolean;
        isValidating: boolean;
    };
    inputProps: {
        name: string;
        onBlur: import("react-hook-form").Noop;
        disabled: boolean | undefined;
    };
    setFieldValue: (value: NativeFieldValue) => void;
    onChangeHandler: <T extends HTMLInputElement, E extends Event>(e: SyntheticEvent<T, E>) => void;
};
export { useFieldHook };
