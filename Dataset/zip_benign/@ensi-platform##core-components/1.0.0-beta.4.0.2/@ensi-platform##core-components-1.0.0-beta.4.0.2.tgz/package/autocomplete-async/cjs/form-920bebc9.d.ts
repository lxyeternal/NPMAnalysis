/// <reference types="react" />
import { IFormProps } from "./index-5fd63277.js";
import { FieldValues, NativeFieldValue } from 'react-hook-form';
interface IFormContextProps<T extends FieldValues> {
    onChange: (key: string, value?: NativeFieldValue) => void;
    onSubmit: IFormProps<T>['onSubmit'];
    disabled?: boolean;
}
declare const FormContext: import("react").Context<IFormContextProps<any> | undefined>;
declare const useForm: <T extends FieldValues>() => IFormContextProps<T>;
export { useForm as default, useForm, IFormContextProps, FormContext };
