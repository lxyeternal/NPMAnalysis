/// <reference types="react" />
import { OptionProps, SelectItem } from "../../../select/esm";
import { ChangeEvent } from 'react';
import { IUseLazyLoadingProps } from "../types/index.js";
declare function useLazyLoading({ limit, initialOffset, optionsFetcher, onOptionsChange, skeleton, Option, isValuesLoading, clearOnClose, }: IUseLazyLoadingProps): {
    isLoading: boolean;
    isNotFound: boolean;
    optionsProps: {
        Option: (props: OptionProps) => import("@emotion/react/jsx-runtime").JSX.Element;
        options: SelectItem[];
        optionsListProps: {
            ref: import("react").RefObject<HTMLDivElement>;
            inputProps: {
                onChange: (event: ChangeEvent<HTMLInputElement>, payload: {
                    value: string;
                }) => void;
                value: string;
            };
        };
        onOpen: (payload: {
            open?: boolean;
        }) => void;
    };
    setValue: (value: string, revalidate?: boolean) => void;
    reset: () => void;
};
export { useLazyLoading };
