/// <reference types="react" />
import { SelectItem } from "../../select/esm";
import { AutocompleteAsyncValue } from "./types/index.js";
declare const AutocompleteAsync: import("react").ForwardRefExoticComponent<Omit<import("../../select-with-tags/esm").SelectWithTagsProps, "value" | "onChange" | "onInput" | "selected" | "options"> & Partial<import("./index-5fd63277.js").IFieldWrapperProps<AutocompleteAsyncValue>> & import("./types/index.js").AutocompleteAsyncHandlers & import("./types/index.js").AutocompleteAsyncState & {
    asyncSearchFn: (queryString: string, offset: number, limit: number) => Promise<import("./types/index.js").IOptionsFetcherResponse>;
    asyncOptionsByValuesFn(values: any[], abortController: AbortController): Promise<SelectItem[]>;
} & import("react").RefAttributes<HTMLInputElement>>;
export { AutocompleteAsync };
