import { IFieldWrapperProps } from "../index-5fd63277.js";
import { OptionProps, SelectItem } from "../../../select/esm";
import { SelectWithTagsProps } from "../../../select-with-tags/esm";
import { FC, ReactNode } from 'react';
interface IOptionsFetcherResponse {
    options: SelectItem[];
    hasMore: boolean;
}
interface IUseLazyLoadingProps {
    isValuesLoading?: boolean;
    clearOnClose?: boolean;
    limit?: number;
    initialOffset?: number;
    skeleton?: ReactNode;
    Option?: FC<OptionProps>;
    optionsFetcher(queryString: string, offset: number, limit: number): Promise<IOptionsFetcherResponse>;
    onOptionsChange?: (options: SelectItem[]) => void;
}
interface AutocompleteAsyncState {
    /**
     * Возможность выбрать несколько значений
     */
    multiple?: boolean;
    clearOnSelect?: boolean;
    extractKeyFromValue?: (value: any) => string;
}
interface AutocompleteAsyncHandlers {
    onInput?: SelectWithTagsProps['onInput'];
    /**
     * Обработчик выбора
     */
    onChange?: (payload: {
        selected: SelectItem[] | null;
        actionItem?: SelectItem | null;
        name?: string;
    }) => void;
    /**
     * Обработчик загрузки новых опций. Предполагается,
     * что в родительском компоненте будет писаться в ref.current
     */
    onOptionsChange?: (options: SelectItem[]) => void;
    onClear?: () => void;
}
type ExtendedValue<T> = T | T[] | Record<string, T> | Record<string, T>[];
type AutocompleteAsyncValue = ExtendedValue<string | number | boolean | null>;
type AutocompleteAsyncPropsType = Omit<SelectWithTagsProps, 'options' | 'selected' | 'value' | 'onInput' | 'onChange'> & Partial<IFieldWrapperProps<AutocompleteAsyncValue>> & AutocompleteAsyncHandlers & AutocompleteAsyncState & {
    asyncSearchFn: IUseLazyLoadingProps['optionsFetcher'];
    /**
     * Фетчер-функция для получения опций из массива уже выбранных значений
     * @param values массив выбранных значений
     */
    asyncOptionsByValuesFn(values: any[], abortController: AbortController): Promise<SelectItem[]>;
};
export { IOptionsFetcherResponse, IUseLazyLoadingProps, AutocompleteAsyncState, AutocompleteAsyncHandlers, AutocompleteAsyncValue, AutocompleteAsyncPropsType };
