import { SelectItem } from "../../../select/esm";
declare const DEBOUNCE_TIMEOUT = 300;
declare const actions: {
    fetchOptionsStart(): {
        readonly type: "FETCH_OPTIONS_START";
    };
    fetchOptionsBreak(): {
        readonly type: "FETCH_OPTIONS_BREAK";
    };
    fetchOptionsSuccess(payload: {
        options: SelectItem[];
        hasMore: boolean;
    }): {
        readonly type: "FETCH_OPTIONS_SUCCESS";
        readonly payload: {
            options: SelectItem[];
            hasMore: boolean;
        };
    };
    setIsOpened(opened: boolean): {
        readonly type: "SET_IS_OPENED";
        readonly payload: boolean;
    };
    setQueryString(qs: string, resetOptions?: boolean): {
        readonly type: "SET_QUERY_STRING";
        readonly payload: {
            readonly qs: string;
            readonly resetOptions: boolean;
        };
    };
    reset(): {
        readonly type: "RESET";
    };
};
export { DEBOUNCE_TIMEOUT, actions };
