import { CheckboxThemeType } from "../types/index.js";
declare const basicTheme: CheckboxThemeType;
export { basicTheme };
