/// <reference types="react" />
import { ICheckboxWrapperProps } from "./types/index.js";
/**
 * Wrapper for controlling checkbox by RHF
 */
declare const CheckboxFormWrapper: import("react").ForwardRefExoticComponent<ICheckboxWrapperProps & import("react").RefAttributes<HTMLInputElement>>;
export { CheckboxFormWrapper };
