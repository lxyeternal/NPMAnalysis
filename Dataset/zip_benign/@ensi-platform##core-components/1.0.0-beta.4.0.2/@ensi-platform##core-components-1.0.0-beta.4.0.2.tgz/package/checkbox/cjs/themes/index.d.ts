declare const checkboxThemes: {
    basic: import("../index.js").CheckboxThemeType;
};
export { checkboxThemes };
