import { MutableRefObject, RefObject } from 'react';
type InputMethod = 'keyboard' | 'mouse';
/**
 * Hook sets the event handler to focusin and focusout
 * for a specific type of event
 * @param node The element on which the handler will be installed (default = document)
 * @param inputMethod If the parameter is not specified, set a handler for any focus event
 */
declare function useFocus<T extends HTMLElement>(ref: MutableRefObject<T> | RefObject<T>, inputMethod?: InputMethod): [boolean];
export { InputMethod, useFocus };
