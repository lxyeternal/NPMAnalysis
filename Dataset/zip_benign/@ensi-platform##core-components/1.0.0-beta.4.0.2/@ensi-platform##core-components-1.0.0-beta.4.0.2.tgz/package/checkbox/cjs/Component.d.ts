/// <reference types="react" />
import { checkboxThemes } from "./themes/index.js";
import { CheckboxSizeEnum, CheckboxVariantEnum, ICheckboxProps } from "./types/index.js";
/**
 * Basic checkbox component
 */
declare const Checkbox: import("react").ForwardRefExoticComponent<Omit<ICheckboxProps, "ref"> & import("react").RefAttributes<HTMLLabelElement>>;
export * from "./types/index.js";
export { checkboxThemes, CheckboxSizeEnum, CheckboxVariantEnum, Checkbox };
