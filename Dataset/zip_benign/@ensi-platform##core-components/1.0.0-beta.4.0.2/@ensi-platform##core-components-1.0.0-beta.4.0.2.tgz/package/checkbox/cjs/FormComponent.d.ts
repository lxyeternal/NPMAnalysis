/// <reference types="react" />
import { checkboxThemes } from "./themes/index.js";
import { CheckboxSizeEnum, CheckboxVariantEnum, IFormCheckboxProps } from "./types/index.js";
/**
 * Controlled by RHF checkbox component
 */
declare const FormCheckbox: import("react").ForwardRefExoticComponent<IFormCheckboxProps & import("react").RefAttributes<HTMLLabelElement>>;
export * from "./types/index.js";
export { checkboxThemes, CheckboxSizeEnum, CheckboxVariantEnum, FormCheckbox };
