/// <reference types="react" />
import { FormControlProps } from "../../form-control/esm";
import { CSSObject } from "@emotion/react";
import { ChangeEvent, InputHTMLAttributes, MouseEvent, ReactNode, Ref } from "react";
import { ControllerFieldState, ControllerRenderProps, NativeFieldValue } from "react-hook-form";
type InputProps = Omit<InputHTMLAttributes<HTMLInputElement>, "size" | "type" | "value" | "defaultValue" | "onChange" | "onClick" | "onMouseDown" | "enterKeyHint"> & {
    /**
     * Значение поля ввода
     */
    value?: string;
    /**
     * Начальное значение поля
     */
    defaultValue?: string;
    error?: string;
    /**
     * Растягивает компонент на ширину контейнера
     */
    block?: boolean;
    /**
     * Крестик для очистки поля
     */
    clear?: boolean;
    theme?: FormControlProps["theme"] | keyof FormControlProps["theme"];
    variant?: FormControlProps["variant"];
    size?: FormControlProps["size"];
    labelWrap?: FormControlProps["labelWrap"];
    /**
     * Флаг отображения ошибки
     */
    showError?: boolean;
    /**
     * Текст подсказки
     */
    hint?: ReactNode;
    /**
     * Лейбл компонента
     */
    label?: ReactNode;
    /**
     * Атрибут type
     */
    type?: "number" | "card" | "email" | "money" | "password" | "tel" | "text" | "time" | "color" | "url" | "link";
    /**
     * Ref для обертки input
     */
    wrapperRef?: Ref<HTMLDivElement>;
    /**
     * Слот слева
     */
    leftAddons?: ReactNode;
    /**
     * Слот справа
     */
    rightAddons?: ReactNode;
    /**
     * Внутренний слот слева
     */
    innerLeftAddons?: ReactNode;
    /**
     * Слот под инпутом
     */
    bottomAddons?: ReactNode;
    /**
     * Дополнительный класс
     */
    className?: string;
    /**
     * Дополнительный стиль для поля
     */
    fieldCSS?: CSSObject;
    /**
     * Дополнительный стиль для обертки
     */
    wrapperCSS?: CSSObject;
    /**
     * Дополнительный стиль инпута
     */
    inputCSS?: CSSObject;
    /**
     * Дополнительный стиль для лейбла
     */
    labelCSS?: CSSObject;
    /**
     * Дополнительный стиль для аддонов
     */
    leftAddonsCSS?: CSSObject;
    rightAddonsCSS?: CSSObject;
    /**
     * Запрещает ввод с клавиатуры
     */
    disableUserInput?: boolean;
    /**
     * Обработчик поля ввода
     */
    onChange?: (event: ChangeEvent<HTMLInputElement>, payload: {
        value: string;
    }) => void;
    /**
     * Обработчик нажатия на кнопку очистки
     */
    onClear?: (event: MouseEvent<HTMLButtonElement>) => void;
    /**
     * Обработчик клика по полю
     */
    onClick?: (event: MouseEvent<HTMLDivElement>) => void;
    /**
     * Обработчик MouseDown по полю
     */
    onMouseDown?: (event: MouseEvent<HTMLDivElement>) => void;
    /**
     * Обработчик MouseUp по полю
     */
    onMouseUp?: (event: MouseEvent<HTMLDivElement>) => void;
    isLegend?: boolean;
};
type ExtendedValue<T> = T | T[] | Record<string, T> | Record<string, T>[];
type IFieldValueType = Exclude<ExtendedValue<NativeFieldValue>, undefined>;
interface IControllerRenderProps<T extends IFieldValueType> extends Omit<ControllerRenderProps, "value"> {
    value: T;
}
/**
 * Interface props passed by the field wrapper component
 */
interface IFieldWrapperProps<T extends IFieldValueType> {
    /**
     * Returned property of useController
     * Contains a meta
     * https://react-hook-form.com/docs/usecontroller
     * */
    fieldState: ControllerFieldState;
    /**
     * Returned property of useController
     * Contains a value and a value change handler
     * https://react-hook-form.com/docs/usecontroller
     * */
    field: IControllerRenderProps<T>;
    /**
     * Handler for changing field value
     * @param value - field value, not event
     */
    setFieldValue: (value: T) => void;
    /**
     * Field error
     */
    error?: string;
}
declare const BASE_INPUT_CSS: CSSObject;
declare const Input: import("react").ForwardRefExoticComponent<Omit<import("react").InputHTMLAttributes<HTMLInputElement>, "size" | "value" | "type" | "onChange" | "onClick" | "onMouseDown" | "defaultValue" | "enterKeyHint"> & {
    value?: string | undefined;
    defaultValue?: string | undefined;
    error?: string | undefined;
    block?: boolean | undefined;
    clear?: boolean | undefined;
    theme?: import("../../form-control/esm").FormControlTheme | "basic" | undefined;
    variant?: "primary" | typeof import("../../form-control/esm").FormControlVariant | undefined;
    size?: "md" | "sm" | "lg" | typeof import("../../form-control/esm").FormControlSize | undefined;
    labelWrap?: boolean | undefined;
    showError?: boolean | undefined;
    hint?: import("react").ReactNode;
    label?: import("react").ReactNode;
    type?: "number" | "color" | "link" | "time" | "text" | "url" | "tel" | "email" | "password" | "card" | "money" | undefined;
    wrapperRef?: import("react").Ref<HTMLDivElement> | undefined;
    leftAddons?: import("react").ReactNode;
    rightAddons?: import("react").ReactNode;
    innerLeftAddons?: import("react").ReactNode;
    bottomAddons?: import("react").ReactNode;
    className?: string | undefined;
    fieldCSS?: CSSObject | undefined;
    wrapperCSS?: CSSObject | undefined;
    inputCSS?: CSSObject | undefined;
    labelCSS?: CSSObject | undefined;
    leftAddonsCSS?: CSSObject | undefined;
    rightAddonsCSS?: CSSObject | undefined;
    disableUserInput?: boolean | undefined;
    onChange?: ((event: ChangeEvent<HTMLInputElement>, payload: {
        value: string;
    }) => void) | undefined;
    onClear?: ((event: MouseEvent<HTMLButtonElement, globalThis.MouseEvent>) => void) | undefined;
    onClick?: ((event: MouseEvent<HTMLDivElement, globalThis.MouseEvent>) => void) | undefined;
    onMouseDown?: ((event: MouseEvent<HTMLDivElement, globalThis.MouseEvent>) => void) | undefined;
    onMouseUp?: ((event: MouseEvent<HTMLDivElement, globalThis.MouseEvent>) => void) | undefined;
    isLegend?: boolean | undefined;
} & Partial<IFieldWrapperProps<string>> & import("react").RefAttributes<HTMLInputElement>>;
export { InputProps, BASE_INPUT_CSS, Input };
