import { BaseThemeState, StyleDefinition, ValueOrFunction } from "../../../common/esm";
import { CSSObject } from '@emotion/react';
import { ICheckboxState } from "./component.js";
declare enum CheckboxSizeEnum {
    md = "md"
}
declare enum CheckboxVariantEnum {
    primary = "primary"
}
/**
 * Interface of additional classes for checkbox
 */
interface ICheckboxCSS {
    /**
     * Root container
     */
    css?: CSSObject;
    /**
     * Container with check icon
     */
    boxCSS?: CSSObject;
    /**
     * Icon
     */
    iconCSS?: CSSObject;
    /**
     * Container for indeterminate state style
     */
    indeterminateLineCSS?: CSSObject;
    /**
     * Message container with error message and hint
     */
    messageCSS?: CSSObject;
    /**
     * Container with label
     */
    labelCSS?: CSSObject;
    /**
     * Container with hint message
     */
    hintCSS?: CSSObject;
}
type CheckboxThemeStateType = BaseThemeState<typeof CheckboxVariantEnum, typeof CheckboxSizeEnum> & ICheckboxState;
declare enum CheckboxThemeParts {
    container = 0,
    message = 1,
    label = 2,
    box = 3,
    icon = 4,
    indeterminateLine = 5,
    hint = 6
}
type CheckboxThemeType = ValueOrFunction<Record<keyof typeof CheckboxThemeParts, StyleDefinition<CheckboxThemeStateType>>, [
    CheckboxThemeStateType
]>;
export { CheckboxSizeEnum, CheckboxVariantEnum, ICheckboxCSS, CheckboxThemeStateType, CheckboxThemeType };
