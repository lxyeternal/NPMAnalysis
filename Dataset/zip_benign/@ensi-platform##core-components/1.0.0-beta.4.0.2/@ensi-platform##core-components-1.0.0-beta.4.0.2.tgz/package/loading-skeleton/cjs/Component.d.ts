import { EnumLike } from "../../common/cjs";
import { FC } from 'react';
import { LoadingSkeletonSizes, LoadingSkeletonVariants } from "./scripts/index.js";
import { ILoadingSkeletonProps, LoadingSkeletonThemeType } from "./types/index.js";
declare const BaseLoadingSkeleton: <V extends EnumLike, S extends EnumLike>({ theme, variant, size, count, duration, verticalStep, width, height, skeletonWrapperCSS: skeletonWrapperCSSProp, skeletonCSS: skeletonCSSProp, className, circle, reverseAnimationDirection, disableAnimation, }: ILoadingSkeletonProps<V, S>) => import("@emotion/react/jsx-runtime").JSX.Element;
declare const createLoadingSkeletonWithTheme: <V extends EnumLike, S extends EnumLike>(defaultTheme: LoadingSkeletonThemeType<V, S>, defaultVariant: V | keyof V, defaultSize: S | keyof S) => FC<ILoadingSkeletonProps<V, S>>;
declare const LoadingSkeleton: FC<ILoadingSkeletonProps<typeof LoadingSkeletonVariants, typeof LoadingSkeletonSizes>>;
export { LoadingSkeleton as default, BaseLoadingSkeleton, createLoadingSkeletonWithTheme };
