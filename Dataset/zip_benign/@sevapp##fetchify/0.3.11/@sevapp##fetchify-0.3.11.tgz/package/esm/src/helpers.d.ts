/// <reference types="node" />
import { FetchInput, IQueryParams } from "./types.js";
export declare const objectToQueryParams: (params: IQueryParams) => string;
export declare const getUrlFromStringOrRequest: (input: FetchInput) => string;
export declare const combineURL: (baseURL: FetchInput, path: FetchInput, params?: IQueryParams) => URL;
