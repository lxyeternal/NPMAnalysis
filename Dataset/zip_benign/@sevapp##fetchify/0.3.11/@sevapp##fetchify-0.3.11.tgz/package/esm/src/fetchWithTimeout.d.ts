import * as dntShim from "../_dnt.shims.js";
import { FetchInput, ILimiterRequestInit } from "./types.js";
export declare function fetchWithTimeout(input: FetchInput, timeout: number, init?: ILimiterRequestInit): Promise<dntShim.Response>;
