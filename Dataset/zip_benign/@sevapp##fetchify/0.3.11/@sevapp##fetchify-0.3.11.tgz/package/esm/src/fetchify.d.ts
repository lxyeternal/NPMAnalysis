import { FetchInput, IFetchifyConfig, ILimiterRequestInit } from "./types.js";
export declare const fetchify: {
    (input: FetchInput, init?: ILimiterRequestInit): Promise<import("undici").Response>;
    create(options?: IFetchifyConfig): Fetchify;
};
export declare class Fetchify {
    #private;
    constructor(config?: IFetchifyConfig);
    get(input: FetchInput, init?: ILimiterRequestInit): Promise<import("undici").Response>;
    post(input: FetchInput, init?: ILimiterRequestInit): Promise<import("undici").Response>;
    put(input: FetchInput, init?: ILimiterRequestInit): Promise<import("undici").Response>;
    delete(input: FetchInput, init?: ILimiterRequestInit): Promise<import("undici").Response>;
    head(input: FetchInput, init?: ILimiterRequestInit): Promise<import("undici").Response>;
    patch(input: FetchInput, init?: ILimiterRequestInit): Promise<import("undici").Response>;
}
