import type { IssueReason, ParseInfo, PipeInfo } from '../../../../types.js';
/**
 * Returns the pipe info.
 *
 * @param info The parse info.
 * @param reason The issue reason.
 *
 * @returns The pipe info.
 */
export declare function getPipeInfo(info: ParseInfo | undefined, reason: IssueReason): PipeInfo;
