export * from './toTrimmedStart.js';
