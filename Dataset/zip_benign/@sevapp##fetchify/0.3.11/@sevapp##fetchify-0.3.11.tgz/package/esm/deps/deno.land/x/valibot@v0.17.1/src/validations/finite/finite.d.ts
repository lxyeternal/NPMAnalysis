import type { ErrorMessage, PipeResult } from '../../types.js';
/**
 * Creates a validation function that validates whether a number is finite.
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
export declare function finite<TInput extends number>(error?: ErrorMessage): (input: TInput) => PipeResult<TInput>;
