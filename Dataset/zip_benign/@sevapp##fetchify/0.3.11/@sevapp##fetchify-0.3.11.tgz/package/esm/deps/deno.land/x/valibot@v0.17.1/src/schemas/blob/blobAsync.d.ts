/// <reference types="node" />
import type { BaseSchemaAsync, ErrorMessage, PipeAsync } from '../../types.js';
/**
 * Blob schema async type.
 */
export type BlobSchemaAsync<TOutput = Blob> = BaseSchemaAsync<Blob, TOutput> & {
    schema: 'blob';
};
/**
 * Creates an async blob schema.
 *
 * @param pipe A validation and transformation pipe.
 *
 * @returns An async blob schema.
 */
export declare function blobAsync(pipe?: PipeAsync<Blob>): BlobSchemaAsync;
/**
 * Creates an async blob schema.
 *
 * @param error The error message.
 * @param pipe A validation and transformation pipe.
 *
 * @returns An async blob schema.
 */
export declare function blobAsync(error?: ErrorMessage, pipe?: PipeAsync<Blob>): BlobSchemaAsync;
