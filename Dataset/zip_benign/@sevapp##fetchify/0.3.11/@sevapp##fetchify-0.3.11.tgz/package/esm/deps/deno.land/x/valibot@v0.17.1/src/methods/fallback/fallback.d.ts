import type { BaseSchema, Output } from '../../types.js';
import type { FallbackInfo } from './types.js';
/**
 * Returns a fallback value when validating the passed schema failed.
 *
 * @param schema The schema to catch.
 * @param value The fallback value.
 *
 * @returns The passed schema.
 */
export declare function fallback<TSchema extends BaseSchema>(schema: TSchema, value: Output<TSchema> | ((info: FallbackInfo) => Output<TSchema>)): TSchema;
