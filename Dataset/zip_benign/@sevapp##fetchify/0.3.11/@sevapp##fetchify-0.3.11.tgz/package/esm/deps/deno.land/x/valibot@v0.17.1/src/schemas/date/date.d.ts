import type { BaseSchema, ErrorMessage, Pipe } from '../../types.js';
/**
 * Date schema type.
 */
export type DateSchema<TOutput = Date> = BaseSchema<Date, TOutput> & {
    schema: 'date';
};
/**
 * Creates a date schema.
 *
 * @param pipe A validation and transformation pipe.
 *
 * @returns A date schema.
 */
export declare function date(pipe?: Pipe<Date>): DateSchema;
/**
 * Creates a date schema.
 *
 * @param error The error message.
 * @param pipe A validation and transformation pipe.
 *
 * @returns A date schema.
 */
export declare function date(error?: ErrorMessage, pipe?: Pipe<Date>): DateSchema;
