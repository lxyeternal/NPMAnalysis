import type { BaseSchema, ErrorMessage, Pipe } from '../../types.js';
/**
 * Bigint schema type.
 */
export type BigintSchema<TOutput = bigint> = BaseSchema<bigint, TOutput> & {
    schema: 'bigint';
};
/**
 * Creates a bigint schema.
 *
 * @param pipe A validation and transformation pipe.
 *
 * @returns A bigint schema.
 */
export declare function bigint(pipe?: Pipe<bigint>): BigintSchema;
/**
 * Creates a bigint schema.
 *
 * @param error The error message.
 * @param pipe A validation and transformation pipe.
 *
 * @returns A bigint schema.
 */
export declare function bigint(error?: ErrorMessage, pipe?: Pipe<bigint>): BigintSchema;
