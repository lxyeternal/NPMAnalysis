/// <reference types="node" />
import type { BaseSchema, ErrorMessage, Pipe } from '../../types.js';
/**
 * Blob schema type.
 */
export type BlobSchema<TOutput = Blob> = BaseSchema<Blob, TOutput> & {
    schema: 'blob';
};
/**
 * Creates a blob schema.
 *
 * @param pipe A validation and transformation pipe.
 *
 * @returns A blob schema.
 */
export declare function blob(pipe?: Pipe<Blob>): BlobSchema;
/**
 * Creates a blob schema.
 *
 * @param error The error message.
 * @param pipe A validation and transformation pipe.
 *
 * @returns A blob schema.
 */
export declare function blob(error?: ErrorMessage, pipe?: Pipe<Blob>): BlobSchema;
