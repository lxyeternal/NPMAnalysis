export * from './toTrimmed.js';
