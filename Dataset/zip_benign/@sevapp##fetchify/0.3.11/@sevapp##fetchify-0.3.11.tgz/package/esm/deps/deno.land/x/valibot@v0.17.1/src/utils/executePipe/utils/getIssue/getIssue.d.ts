import type { Issue, PipeInfo } from '../../../../types.js';
/**
 * Returns the final issue data.
 *
 * @param info The pipe info.
 * @param issue The issue data.
 *
 * @returns The issue data.
 */
export declare function getIssue(info: PipeInfo, issue: Pick<Issue, 'validation' | 'message' | 'input' | 'path'>): Issue;
