import type { ErrorMessage, Issue } from '../../types.js';
/**
 * Returns the pipeline result object with issues.
 *
 * @param validation The validation name.
 * @param message The error message.
 * @param input The input value.
 *
 * @returns The pipeline result object.
 */
export declare function getPipeIssues(validation: string, error: ErrorMessage, input: unknown): {
    issues: Pick<Issue, 'validation' | 'message' | 'input' | 'path'>[];
};
