import type { BaseSchema, BaseSchemaAsync, Output } from '../../types.js';
import type { FallbackInfo } from './types.js';
/**
 * Returns a fallback value when validating the passed schema failed.
 *
 * @param schema The schema to catch.
 * @param value The fallback value.
 *
 * @returns The passed schema.
 */
export declare function fallbackAsync<TSchema extends BaseSchema | BaseSchemaAsync>(schema: TSchema, value: Output<TSchema> | ((info: FallbackInfo) => Output<TSchema>)): TSchema;
