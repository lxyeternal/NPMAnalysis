import type { ErrorMessage } from '../../types.js';
/**
 * Returns the final string of the error message.
 *
 * @param error The error message.
 *
 * @returns The error message.
 */
export declare function getErrorMessage(error: ErrorMessage): string;
