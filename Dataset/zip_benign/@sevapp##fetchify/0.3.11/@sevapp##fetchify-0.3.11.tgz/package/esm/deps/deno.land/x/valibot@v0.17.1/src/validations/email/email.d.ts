import type { ErrorMessage, PipeResult } from '../../types.js';
/**
 * Creates a validation functions that validates a email.
 *
 * Hint: The regex used is not perfect, but should work for most emails.
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
export declare function email<TInput extends string>(error?: ErrorMessage): (input: TInput) => PipeResult<TInput>;
