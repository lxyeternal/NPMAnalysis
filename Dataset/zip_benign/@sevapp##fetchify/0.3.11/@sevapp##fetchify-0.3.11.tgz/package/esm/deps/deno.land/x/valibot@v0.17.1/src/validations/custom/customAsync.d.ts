import type { ErrorMessage, PipeResult } from '../../types.js';
/**
 * Creates a async custom validation function.
 *
 * @param requirement The async validation function.
 * @param error The error message.
 *
 * @returns A async validation function.
 */
export declare function customAsync<TInput>(requirement: (input: TInput) => Promise<boolean>, error?: ErrorMessage): (input: TInput) => Promise<PipeResult<TInput>>;
