import type { BaseSchemaAsync, ErrorMessage, PipeAsync } from '../../types.js';
/**
 * Boolean schema async type.
 */
export type BooleanSchemaAsync<TOutput = boolean> = BaseSchemaAsync<boolean, TOutput> & {
    schema: 'boolean';
};
/**
 * Creates an async boolean schema.
 *
 * @param pipe A validation and transformation pipe.
 *
 * @returns An async boolean schema.
 */
export declare function booleanAsync(pipe?: PipeAsync<boolean>): BooleanSchemaAsync;
/**
 * Creates an async boolean schema.
 *
 * @param error The error message.
 * @param pipe A validation and transformation pipe.
 *
 * @returns An async boolean schema.
 */
export declare function booleanAsync(error?: ErrorMessage, pipe?: PipeAsync<boolean>): BooleanSchemaAsync;
