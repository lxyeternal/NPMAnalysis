import type { BaseSchema, BaseSchemaAsync, ErrorMessage, Pipe, PipeAsync } from '../../../../types.js';
import type { RecordKey } from '../../record.js';
import type { RecordKeyAsync } from '../../recordAsync.js';
/**
 * Returns key, value, error and pipe from dynamic arguments.
 *
 * @param arg1 First argument.
 * @param arg2 Second argument.
 * @param arg3 Third argument.
 * @param arg4 Fourth argument.
 *
 * @returns The record arguments.
 */
export declare function getRecordArgs<TRecordKey extends RecordKey | RecordKeyAsync, TRecordValue extends BaseSchema | BaseSchemaAsync, TPipe extends Pipe<any> | PipeAsync<any>>(arg1: TRecordValue | TRecordKey, arg2: TPipe | ErrorMessage | TRecordValue | undefined, arg3: TPipe | ErrorMessage | undefined, arg4: TPipe | undefined): [TRecordKey, TRecordValue, ErrorMessage | undefined, TPipe | undefined];
