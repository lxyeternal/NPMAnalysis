import type { ErrorMessage, PipeResult } from '../../types.js';
export declare function excludes<TInput extends string>(requirement: string, error?: ErrorMessage): (input: TInput) => PipeResult<TInput>;
export declare function excludes<TInput extends TItem[], TItem>(requirement: TItem, error?: ErrorMessage): (input: TInput) => PipeResult<TInput>;
