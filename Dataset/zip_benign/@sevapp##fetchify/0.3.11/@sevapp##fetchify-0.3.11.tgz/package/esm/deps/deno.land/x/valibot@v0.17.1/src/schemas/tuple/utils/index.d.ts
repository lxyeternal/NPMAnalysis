export * from './getTupleArgs/index.js';
