import type { ErrorMessage, IssueReason, Issues, ParseInfo } from '../../types.js';
/**
 * Returns the schema result object with issues.
 *
 * @param info The parse info.
 * @param reason The issue reason.
 * @param validation The validation name.
 * @param message The error message.
 * @param input The input value.
 * @param issues The sub issues.
 *
 * @returns The schema result object.
 */
export declare function getSchemaIssues(info: ParseInfo | undefined, reason: IssueReason, validation: string, error: ErrorMessage, input: unknown, issues?: Issues): {
    issues: Issues;
};
