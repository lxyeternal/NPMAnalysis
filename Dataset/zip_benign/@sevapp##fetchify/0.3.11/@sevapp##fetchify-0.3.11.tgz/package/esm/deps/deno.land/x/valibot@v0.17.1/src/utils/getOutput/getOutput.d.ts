/**
 * Returns the result object with an output.
 *
 * @param output The output value.
 *
 * @returns The result object.
 */
export declare function getOutput<TOutput>(output: TOutput): {
    output: TOutput;
};
