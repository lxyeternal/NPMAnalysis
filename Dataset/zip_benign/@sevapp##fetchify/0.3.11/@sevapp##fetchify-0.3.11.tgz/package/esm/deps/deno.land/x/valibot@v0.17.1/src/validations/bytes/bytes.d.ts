import type { ErrorMessage, PipeResult } from '../../types.js';
/**
 * Creates a validation functions that validates the byte length of a string.
 *
 * @param requirement The byte length.
 * @param error The error message.
 *
 * @returns A validation function.
 */
export declare function bytes<TInput extends string>(requirement: number, error?: ErrorMessage): (input: TInput) => PipeResult<TInput>;
