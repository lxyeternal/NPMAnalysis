import type { ErrorMessage, PipeResult } from '../../types.js';
/**
 * Creates a validation functions that validates a IMEI.
 *
 * Format: AA-BBBBBB-CCCCCC-D
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
export declare function imei<TInput extends string>(error?: ErrorMessage): (input: TInput) => PipeResult<TInput>;
