export * from './getTupleArgs.js';
