import type { ErrorMessage, PipeResult } from '../../types.js';
/**
 * Creates a validation functions that validates a emoji.
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
export declare function emoji<TInput extends string>(error?: ErrorMessage): (input: TInput) => PipeResult<TInput>;
