import type { _ParseResult, IssueReason, ParseInfo, PipeAsync } from '../../types.js';
/**
 * Executes the async validation and transformation pipe.
 *
 * @param input The input value.
 * @param pipe The pipe to be executed.
 * @param info The validation info.
 *
 * @returns The output value.
 */
export declare function executePipeAsync<TValue>(input: TValue, pipe: PipeAsync<TValue> | undefined, parseInfo: ParseInfo | undefined, reason: IssueReason): Promise<_ParseResult<TValue>>;
