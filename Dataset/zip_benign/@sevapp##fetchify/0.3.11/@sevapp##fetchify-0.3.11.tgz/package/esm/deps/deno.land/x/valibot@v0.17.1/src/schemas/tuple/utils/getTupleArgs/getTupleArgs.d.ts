import type { BaseSchema, BaseSchemaAsync, ErrorMessage, Pipe, PipeAsync } from '../../../../types.js';
/**
 * Returns rest, error and pipe from dynamic arguments.
 *
 * @param arg1 First argument.
 * @param arg2 Second argument.
 * @param arg3 Third argument.
 *
 * @returns The tuple arguments.
 */
export declare function getTupleArgs<TRest extends BaseSchema | BaseSchemaAsync | undefined, TPipe extends Pipe<any> | PipeAsync<any>>(arg1: TPipe | ErrorMessage | TRest | undefined, arg2: TPipe | ErrorMessage | undefined, arg3: TPipe | undefined): [TRest, ErrorMessage | undefined, TPipe | undefined];
