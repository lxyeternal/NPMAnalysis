import type { ErrorMessage, PipeResult } from '../../types.js';
/**
 * Creates a validation functions that validates a [cuid2](https://github.com/paralleldrive/cuid2#cuid2).
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
export declare function cuid2<TInput extends string>(error?: ErrorMessage): (input: TInput) => PipeResult<TInput>;
