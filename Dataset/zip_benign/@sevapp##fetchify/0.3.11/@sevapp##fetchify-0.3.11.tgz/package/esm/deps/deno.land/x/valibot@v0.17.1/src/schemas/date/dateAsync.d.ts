import type { BaseSchemaAsync, ErrorMessage, PipeAsync } from '../../types.js';
/**
 * Date schema async type.
 */
export type DateSchemaAsync<TOutput = Date> = BaseSchemaAsync<Date, TOutput> & {
    schema: 'date';
};
/**
 * Creates an async date schema.
 *
 * @param pipe A validation and transformation pipe.
 *
 * @returns An async date schema.
 */
export declare function dateAsync(pipe?: PipeAsync<Date>): DateSchemaAsync;
/**
 * Creates an async date schema.
 *
 * @param error The error message.
 * @param pipe A validation and transformation pipe.
 *
 * @returns An async date schema.
 */
export declare function dateAsync(error?: ErrorMessage, pipe?: PipeAsync<Date>): DateSchemaAsync;
