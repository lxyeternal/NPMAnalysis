import type { ErrorMessage, PipeResult } from '../../types.js';
/**
 * Creates a custom validation function.
 *
 * @param requirement The validation function.
 * @param error The error message.
 *
 * @returns A validation function.
 */
export declare function custom<TInput>(requirement: (input: TInput) => boolean, error?: ErrorMessage): (input: TInput) => PipeResult<TInput>;
