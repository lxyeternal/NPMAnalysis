"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isoTime = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates a time.
 *
 * Format: hh:mm
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function isoTime(error) {
    return (input) => !/^(0[0-9]|1\d|2[0-3]):[0-5]\d$/.test(input)
        ? (0, index_js_1.getPipeIssues)('iso_time', error || 'Invalid time', input)
        : (0, index_js_1.getOutput)(input);
}
exports.isoTime = isoTime;
