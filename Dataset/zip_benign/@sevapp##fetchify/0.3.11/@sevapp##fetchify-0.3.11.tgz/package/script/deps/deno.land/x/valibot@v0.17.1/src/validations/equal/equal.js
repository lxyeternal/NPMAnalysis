"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.equal = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation function that checks the value for equality.
 *
 * @param requirement The required value.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function equal(requirement, error) {
    return (input) => input !== requirement
        ? (0, index_js_1.getPipeIssues)('equal', error || 'Invalid input', input)
        : (0, index_js_1.getOutput)(input);
}
exports.equal = equal;
