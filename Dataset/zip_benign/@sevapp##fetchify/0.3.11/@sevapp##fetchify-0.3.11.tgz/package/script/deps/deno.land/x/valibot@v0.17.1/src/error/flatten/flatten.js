"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.flatten = void 0;
function flatten(arg1) {
    return (Array.isArray(arg1) ? arg1 : arg1.issues).reduce((flatErrors, issue) => {
        if (issue.path) {
            const path = issue.path.map(({ key }) => key).join('.');
            flatErrors.nested[path] = [
                ...(flatErrors.nested[path] || []),
                issue.message,
            ];
        }
        else {
            flatErrors.root = [...(flatErrors.root || []), issue.message];
        }
        return flatErrors;
    }, { nested: {} });
}
exports.flatten = flatten;
