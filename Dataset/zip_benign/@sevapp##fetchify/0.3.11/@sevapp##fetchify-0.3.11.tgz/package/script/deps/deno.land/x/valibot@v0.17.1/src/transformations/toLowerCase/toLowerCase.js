"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toLowerCase = void 0;
/**
 * Creates a transformation function that converts all the alphabetic
 * characters in a string to lowercase.
 *
 * @returns A transformation function.
 */
function toLowerCase() {
    return (input) => ({
        output: input.toLocaleLowerCase(),
    });
}
exports.toLowerCase = toLowerCase;
