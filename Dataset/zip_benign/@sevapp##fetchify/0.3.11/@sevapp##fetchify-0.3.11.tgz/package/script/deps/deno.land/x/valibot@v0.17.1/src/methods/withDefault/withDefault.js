"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.useDefault = exports.withDefault = void 0;
/**
 * Passes a default value to a schema in case of an undefined input.
 *
 * @deprecated Use `optional` instead.
 *
 * @param schema The affected schema.
 * @param value The default value.
 *
 * @returns The passed schema.
 */
function withDefault(schema, value) {
    return {
        ...schema,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            return schema._parse(input === undefined
                ? typeof value === 'function'
                    ? value()
                    : value
                : input, info);
        },
    };
}
exports.withDefault = withDefault;
/**
 * See {@link withDefault}
 *
 * @deprecated Use `optional` instead.
 */
exports.useDefault = withDefault;
