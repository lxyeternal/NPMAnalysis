"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toUpperCase = void 0;
/**
 * Creates a transformation function that converts all the alphabetic
 * characters in a string to uppercase.
 *
 * @returns A transformation function.
 */
function toUpperCase() {
    return (input) => ({
        output: input.toUpperCase(),
    });
}
exports.toUpperCase = toUpperCase;
