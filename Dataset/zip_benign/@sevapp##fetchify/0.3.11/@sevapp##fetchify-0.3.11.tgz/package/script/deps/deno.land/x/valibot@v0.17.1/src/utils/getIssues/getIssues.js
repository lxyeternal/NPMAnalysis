"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getIssues = void 0;
/**
 * Returns the result object with issues.
 *
 * @param issues The issues.
 *
 * @returns The result object.
 */
function getIssues(issues) {
    return { issues };
}
exports.getIssues = getIssues;
