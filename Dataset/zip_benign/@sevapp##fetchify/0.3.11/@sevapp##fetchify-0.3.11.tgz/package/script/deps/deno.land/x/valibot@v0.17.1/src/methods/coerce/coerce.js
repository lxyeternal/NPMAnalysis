"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.coerce = void 0;
/**
 * Coerces the input of a schema to match the required type.
 *
 * @param schema The affected schema.
 * @param action The coerceation action.
 *
 * @returns The passed schema.
 */
function coerce(schema, action) {
    return {
        ...schema,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            return schema._parse(action(input), info);
        },
    };
}
exports.coerce = coerce;
