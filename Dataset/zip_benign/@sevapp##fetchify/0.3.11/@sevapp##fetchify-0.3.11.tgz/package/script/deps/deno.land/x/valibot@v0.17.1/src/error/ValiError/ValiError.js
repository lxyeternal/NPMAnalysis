"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ValiError = void 0;
/**
 * A Valibot error with useful information.
 */
class ValiError extends Error {
    /**
     * Creates a Valibot error with useful information.
     *
     * @param issues The error issues.
     */
    constructor(issues) {
        super(issues[0].message);
        Object.defineProperty(this, "issues", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        this.name = 'ValiError';
        this.issues = issues;
    }
}
exports.ValiError = ValiError;
