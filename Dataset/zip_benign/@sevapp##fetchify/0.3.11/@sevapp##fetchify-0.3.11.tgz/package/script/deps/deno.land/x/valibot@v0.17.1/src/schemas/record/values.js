"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BLOCKED_KEYS = void 0;
exports.BLOCKED_KEYS = ['__proto__', 'prototype', 'constructor'];
