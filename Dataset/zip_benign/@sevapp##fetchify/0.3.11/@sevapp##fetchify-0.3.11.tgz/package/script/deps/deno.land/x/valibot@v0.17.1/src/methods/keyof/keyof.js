"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.keyof = void 0;
const index_js_1 = require("../../schemas/index.js");
/**
 * Creates a enum schema of object keys.
 *
 * @param schema The object schema.
 *
 * @returns A enum schema.
 */
function keyof(schema) {
    return (0, index_js_1.enumType)(Object.keys(schema.object));
}
exports.keyof = keyof;
