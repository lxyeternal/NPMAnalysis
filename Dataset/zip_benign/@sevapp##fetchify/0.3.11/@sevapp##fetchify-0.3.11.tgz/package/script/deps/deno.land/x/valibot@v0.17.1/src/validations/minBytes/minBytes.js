"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.minBytes = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates the byte length of a string.
 *
 * @param requirement The minimum length in byte.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function minBytes(requirement, error) {
    return (input) => new TextEncoder().encode(input).length < requirement
        ? (0, index_js_1.getPipeIssues)('min_bytes', error || 'Invalid byte length', input)
        : (0, index_js_1.getOutput)(input);
}
exports.minBytes = minBytes;
