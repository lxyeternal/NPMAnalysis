"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSchemaIssues = void 0;
const getErrorMessage_js_1 = require("../getErrorMessage/getErrorMessage.js");
/**
 * Returns the schema result object with issues.
 *
 * @param info The parse info.
 * @param reason The issue reason.
 * @param validation The validation name.
 * @param message The error message.
 * @param input The input value.
 * @param issues The sub issues.
 *
 * @returns The schema result object.
 */
function getSchemaIssues(info, reason, validation, error, input, issues) {
    // Note: The issue is deliberately not constructed with the spread operator
    // for performance reasons
    return {
        issues: [
            {
                reason,
                validation,
                origin: info?.origin || 'value',
                message: (0, getErrorMessage_js_1.getErrorMessage)(error),
                input,
                issues,
                abortEarly: info?.abortEarly,
                abortPipeEarly: info?.abortPipeEarly,
                skipPipe: info?.skipPipe,
            },
        ],
    };
}
exports.getSchemaIssues = getSchemaIssues;
