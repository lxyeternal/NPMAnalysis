"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.custom = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a custom validation function.
 *
 * @param requirement The validation function.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function custom(requirement, error) {
    return (input) => !requirement(input)
        ? (0, index_js_1.getPipeIssues)('custom', error || 'Invalid input', input)
        : (0, index_js_1.getOutput)(input);
}
exports.custom = custom;
