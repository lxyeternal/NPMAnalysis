"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.minSize = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates the size of a map, set or blob.
 *
 * @param requirement The minimum size.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function minSize(requirement, error) {
    return (input) => input.size < requirement
        ? (0, index_js_1.getPipeIssues)('min_size', error || 'Invalid size', input)
        : (0, index_js_1.getOutput)(input);
}
exports.minSize = minSize;
