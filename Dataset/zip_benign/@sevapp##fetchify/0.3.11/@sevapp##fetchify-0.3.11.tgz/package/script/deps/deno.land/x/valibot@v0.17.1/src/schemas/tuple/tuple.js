"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tuple = void 0;
const index_js_1 = require("../../utils/index.js");
const index_js_2 = require("./utils/index.js");
function tuple(items, arg2, arg3, arg4) {
    // Get rest, error and pipe argument
    const [rest, error, pipe] = (0, index_js_2.getTupleArgs)(arg2, arg3, arg4);
    // Create and return tuple schema
    return {
        /**
         * The schema type.
         */
        schema: 'tuple',
        /**
         * The tuple items and rest schema.
         */
        tuple: { items, rest },
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Check type of input
            if (!Array.isArray(input) ||
                (!rest && items.length !== input.length) ||
                (rest && items.length > input.length)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'tuple', error || 'Invalid type', input);
            }
            // Create issues and output
            let issues;
            const output = [];
            // Parse schema of each tuple item
            for (let key = 0; key < items.length; key++) {
                const value = input[key];
                const result = items[key]._parse(value, info);
                // If there are issues, capture them
                if (result.issues) {
                    // Create tuple path item
                    const pathItem = {
                        schema: 'tuple',
                        input: input,
                        key,
                        value,
                    };
                    // Add modified result issues to issues
                    for (const issue of result.issues) {
                        if (issue.path) {
                            issue.path.unshift(pathItem);
                        }
                        else {
                            issue.path = [pathItem];
                        }
                        issues?.push(issue);
                    }
                    if (!issues) {
                        issues = result.issues;
                    }
                    // If necessary, abort early
                    if (info?.abortEarly) {
                        break;
                    }
                    // Otherwise, add item to tuple
                }
                else {
                    output[key] = result.output;
                }
            }
            // If necessary parse schema of each rest item
            if (rest) {
                for (let key = items.length; key < input.length; key++) {
                    const value = input[key];
                    const result = rest._parse(value, info);
                    // If there are issues, capture them
                    if (result.issues) {
                        // Create tuple path item
                        const pathItem = {
                            schema: 'tuple',
                            input: input,
                            key,
                            value,
                        };
                        // Add modified result issues to issues
                        for (const issue of result.issues) {
                            if (issue.path) {
                                issue.path.unshift(pathItem);
                            }
                            else {
                                issue.path = [pathItem];
                            }
                            issues?.push(issue);
                        }
                        if (!issues) {
                            issues = result.issues;
                        }
                        // If necessary, abort early
                        if (info?.abortEarly) {
                            break;
                        }
                        // Otherwise, add item to tuple
                    }
                    else {
                        output[key] = result.output;
                    }
                }
            }
            // Return issues or pipe result
            return issues
                ? (0, index_js_1.getIssues)(issues)
                : (0, index_js_1.executePipe)(output, pipe, info, 'tuple');
        },
    };
}
exports.tuple = tuple;
