"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.instanceAsync = void 0;
const index_js_1 = require("../../utils/index.js");
function instanceAsync(of, arg2, arg3) {
    // Get error and pipe argument
    const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg2, arg3);
    // Create and return string schema
    return {
        /**
         * The schema type.
         */
        schema: 'instance',
        /**
         * The class of the instance.
         */
        class: of,
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            // Check type of input
            if (!(input instanceof of)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'instance', error || 'Invalid type', input);
            }
            // Execute pipe and return result
            return (0, index_js_1.executePipeAsync)(input, pipe, info, 'instance');
        },
    };
}
exports.instanceAsync = instanceAsync;
