"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toCustom = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a custom transformation function.
 *
 * @param action The transform action.
 *
 * @returns A transformation function.
 */
function toCustom(action) {
    return (input) => (0, index_js_1.getOutput)(action(input));
}
exports.toCustom = toCustom;
