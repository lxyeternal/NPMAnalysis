"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.enumTypeAsync = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates an async enum schema.
 *
 * @param enumValue The enum value.
 * @param error The error message.
 *
 * @returns An async enum schema.
 */
function enumTypeAsync(enumValue, error) {
    return {
        /**
         * The schema type.
         */
        schema: 'enum',
        /**
         * The enum value.
         */
        enum: enumValue,
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            // Check type of input
            if (!enumValue.includes(input)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'enum', error || 'Invalid type', input);
            }
            // Return inpot as output
            return (0, index_js_1.getOutput)(input);
        },
    };
}
exports.enumTypeAsync = enumTypeAsync;
