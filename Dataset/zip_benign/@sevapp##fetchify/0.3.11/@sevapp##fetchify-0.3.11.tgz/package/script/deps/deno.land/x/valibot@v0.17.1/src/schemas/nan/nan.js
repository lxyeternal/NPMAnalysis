"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nan = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a NaN schema.
 *
 * @param error The error message.
 *
 * @returns A NaN schema.
 */
function nan(error) {
    return {
        /**
         * The schema type.
         */
        schema: 'nan',
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Check type of input
            if (!Number.isNaN(input)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'nan', error || 'Invalid type', input);
            }
            // Return input as output
            return (0, index_js_1.getOutput)(input);
        },
    };
}
exports.nan = nan;
