"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recursive = void 0;
/**
 * Creates a recursive schema.
 *
 * @param getter The schema getter.
 *
 * @returns A recursive schema.
 */
function recursive(getter) {
    return {
        /**
         * The schema type.
         */
        schema: 'recursive',
        /**
         * The schema getter.
         */
        getter,
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            return getter()._parse(input, info);
        },
    };
}
exports.recursive = recursive;
