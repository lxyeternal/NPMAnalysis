"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.includes = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates the content of a string or array.
 *
 * @param requirement The content to be included.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function includes(requirement, error) {
    return (input) => !input.includes(requirement)
        ? (0, index_js_1.getPipeIssues)('includes', error || 'Invalid content', input)
        : (0, index_js_1.getOutput)(input);
}
exports.includes = includes;
