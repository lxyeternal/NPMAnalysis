"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.number = void 0;
const index_js_1 = require("../../utils/index.js");
function number(arg1, arg2) {
    // Get error and pipe argument
    const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg1, arg2);
    // Create and return number schema
    return {
        /**
         * The schema type.
         */
        schema: 'number',
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Check type of input
            if (typeof input !== 'number' || Number.isNaN(input)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'number', error || 'Invalid type', input);
            }
            // Execute pipe and return result
            return (0, index_js_1.executePipe)(input, pipe, info, 'number');
        },
    };
}
exports.number = number;
