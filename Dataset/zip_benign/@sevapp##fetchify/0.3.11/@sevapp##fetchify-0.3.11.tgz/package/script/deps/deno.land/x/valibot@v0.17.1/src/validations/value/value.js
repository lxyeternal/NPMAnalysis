"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.value = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates the value of a string or number.
 *
 * @param requirement The value.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function value(requirement, error) {
    return (input) => input !== requirement
        ? (0, index_js_1.getPipeIssues)('value', error || 'Invalid value', input)
        : (0, index_js_1.getOutput)(input);
}
exports.value = value;
