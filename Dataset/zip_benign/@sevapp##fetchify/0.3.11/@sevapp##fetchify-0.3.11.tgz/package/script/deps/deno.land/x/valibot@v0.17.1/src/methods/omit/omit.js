"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.omit = void 0;
const index_js_1 = require("../../schemas/index.js");
const index_js_2 = require("../../utils/index.js");
function omit(schema, keys, arg3, arg4) {
    // Get error and pipe argument
    const [error, pipe] = (0, index_js_2.getDefaultArgs)(arg3, arg4);
    // Create and return object schema
    return (0, index_js_1.object)(Object.entries(schema.object).reduce((object, [key, schema]) => keys.includes(key) ? object : { ...object, [key]: schema }, {}), error, pipe);
}
exports.omit = omit;
