"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ulid = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates a [ULID](https://github.com/ulid/spec).
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function ulid(error) {
    return (input) => !/^[0-9A-HJKMNPQ-TV-Z]{26}$/i.test(input)
        ? (0, index_js_1.getPipeIssues)('ulid', error || 'Invalid ULID', input)
        : (0, index_js_1.getOutput)(input);
}
exports.ulid = ulid;
