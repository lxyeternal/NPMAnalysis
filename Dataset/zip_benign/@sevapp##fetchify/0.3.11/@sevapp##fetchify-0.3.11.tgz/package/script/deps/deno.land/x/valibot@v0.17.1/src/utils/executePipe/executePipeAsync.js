"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.executePipeAsync = void 0;
const getIssues_js_1 = require("../getIssues/getIssues.js");
const getOutput_js_1 = require("../getOutput/getOutput.js");
const index_js_1 = require("./utils/index.js");
/**
 * Executes the async validation and transformation pipe.
 *
 * @param input The input value.
 * @param pipe The pipe to be executed.
 * @param info The validation info.
 *
 * @returns The output value.
 */
async function executePipeAsync(input, pipe, parseInfo, reason) {
    // If pipe is empty, return input as output
    if (!pipe || !pipe.length || parseInfo?.skipPipe) {
        return (0, getOutput_js_1.getOutput)(input);
    }
    // Create pipe info, issues and output
    let pipeInfo;
    let issues;
    let output = input;
    // Execute any action of pipe
    for (const action of pipe) {
        const result = await action(output);
        // If there are issues, capture them
        if (result.issues) {
            // Cache pipe info lazy
            pipeInfo = pipeInfo || (0, index_js_1.getPipeInfo)(parseInfo, reason);
            // Create each issue and add it to issues
            for (const issueInfo of result.issues) {
                const issue = (0, index_js_1.getIssue)(pipeInfo, issueInfo);
                issues ? issues.push(issue) : (issues = [issue]);
            }
            // If necessary, abort early
            if (pipeInfo.abortEarly || pipeInfo.abortPipeEarly) {
                break;
            }
            // Otherwise, overwrite output
        }
        else {
            output = result.output;
        }
    }
    // Return pipe issues or output
    return issues ? (0, getIssues_js_1.getIssues)(issues) : (0, getOutput_js_1.getOutput)(output);
}
exports.executePipeAsync = executePipeAsync;
