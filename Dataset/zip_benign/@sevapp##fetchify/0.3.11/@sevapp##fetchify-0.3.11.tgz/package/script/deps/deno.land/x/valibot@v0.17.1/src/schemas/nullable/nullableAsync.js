"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nullableAsync = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates an async nullable schema.
 *
 * @param wrapped The wrapped schema.
 * @param default_ The default value.
 *
 * @returns An async nullable schema.
 */
function nullableAsync(wrapped, default_) {
    return {
        /**
         * The schema type.
         */
        schema: 'nullable',
        /**
         * The wrapped schema.
         */
        wrapped,
        /**
         * The default value.
         */
        get default() {
            return typeof default_ === 'function'
                ? default_()
                : default_;
        },
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            // Get default or input value
            let default_;
            const value = input === null &&
                (default_ = await this.default) &&
                default_ !== undefined
                ? default_
                : input;
            // Allow `null` value to pass
            if (value === null) {
                return (0, index_js_1.getOutput)(value);
            }
            // Return result of wrapped schema
            return wrapped._parse(value, info);
        },
    };
}
exports.nullableAsync = nullableAsync;
