"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.finite = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation function that validates whether a number is finite.
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function finite(error) {
    return (input) => !Number.isFinite(input)
        ? (0, index_js_1.getPipeIssues)('finite', error || 'Invalid finite number', input)
        : (0, index_js_1.getOutput)(input);
}
exports.finite = finite;
