"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toTrimmedStart = void 0;
/**
 * Creates a transformation function that removes the leading white space and
 * line terminator characters from a string.
 *
 * @returns A transformation function.
 */
function toTrimmedStart() {
    return (input) => ({
        output: input.trimStart(),
    });
}
exports.toTrimmedStart = toTrimmedStart;
