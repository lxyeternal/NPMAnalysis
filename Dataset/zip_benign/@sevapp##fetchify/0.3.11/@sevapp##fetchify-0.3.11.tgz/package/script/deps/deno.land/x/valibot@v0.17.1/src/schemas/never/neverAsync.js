"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.neverAsync = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates an async never schema.
 *
 * @param error The error message.
 *
 * @returns An async never schema.
 */
function neverAsync(error) {
    return {
        /**
         * The schema type.
         */
        schema: 'never',
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            return (0, index_js_1.getSchemaIssues)(info, 'type', 'never', error || 'Invalid type', input);
        },
    };
}
exports.neverAsync = neverAsync;
