"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRecordArgs = void 0;
const index_js_1 = require("../../../../utils/index.js");
const index_js_2 = require("../../../string/index.js");
/**
 * Returns key, value, error and pipe from dynamic arguments.
 *
 * @param arg1 First argument.
 * @param arg2 Second argument.
 * @param arg3 Third argument.
 * @param arg4 Fourth argument.
 *
 * @returns The record arguments.
 */
function getRecordArgs(arg1, arg2, arg3, arg4) {
    if (typeof arg2 === 'object' && !Array.isArray(arg2)) {
        const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg3, arg4);
        return [arg1, arg2, error, pipe];
    }
    const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg2, arg3);
    return [(0, index_js_2.string)(), arg1, error, pipe];
}
exports.getRecordArgs = getRecordArgs;
