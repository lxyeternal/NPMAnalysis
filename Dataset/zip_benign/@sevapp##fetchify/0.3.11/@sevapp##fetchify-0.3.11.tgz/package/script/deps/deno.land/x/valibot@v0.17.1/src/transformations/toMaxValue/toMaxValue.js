"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toMaxValue = void 0;
/**
 * Creates a transformation function that sets a string, number or date to a
 * maximum value.
 *
 * @param requirement The maximum value.
 *
 * @returns A transformation function.
 */
function toMaxValue(requirement) {
    return (input) => ({
        output: input > requirement ? requirement : input,
    });
}
exports.toMaxValue = toMaxValue;
