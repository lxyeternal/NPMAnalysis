"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.customAsync = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a async custom validation function.
 *
 * @param requirement The async validation function.
 * @param error The error message.
 *
 * @returns A async validation function.
 */
function customAsync(requirement, error) {
    return async (input) => !(await requirement(input))
        ? (0, index_js_1.getPipeIssues)('custom', error || 'Invalid input', input)
        : (0, index_js_1.getOutput)(input);
}
exports.customAsync = customAsync;
