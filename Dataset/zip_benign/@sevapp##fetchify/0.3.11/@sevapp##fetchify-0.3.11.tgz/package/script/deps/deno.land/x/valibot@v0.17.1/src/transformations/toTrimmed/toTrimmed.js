"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toTrimmed = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a transformation function that removes the leading and trailing
 * white space and line terminator characters from a string.
 *
 * @returns A transformation function.
 */
function toTrimmed() {
    return (input) => (0, index_js_1.getOutput)(input.trim());
}
exports.toTrimmed = toTrimmed;
