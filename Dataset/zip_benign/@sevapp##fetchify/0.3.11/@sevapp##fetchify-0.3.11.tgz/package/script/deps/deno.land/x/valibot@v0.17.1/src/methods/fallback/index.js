"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fallbackAsync = exports.fallback = void 0;
var fallback_js_1 = require("./fallback.js");
Object.defineProperty(exports, "fallback", { enumerable: true, get: function () { return fallback_js_1.fallback; } });
var fallbackAsync_js_1 = require("./fallbackAsync.js");
Object.defineProperty(exports, "fallbackAsync", { enumerable: true, get: function () { return fallbackAsync_js_1.fallbackAsync; } });
