"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.special = void 0;
const index_js_1 = require("../../utils/index.js");
function special(check, arg2, arg3) {
    // Get error and pipe argument
    const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg2, arg3);
    // Create and return string schema
    return {
        /**
         * The schema type.
         */
        schema: 'special',
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Check type of input
            if (!check(input)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'special', error || 'Invalid type', input);
            }
            // Execute pipe and return result
            return (0, index_js_1.executePipe)(input, pipe, info, 'special');
        },
    };
}
exports.special = special;
