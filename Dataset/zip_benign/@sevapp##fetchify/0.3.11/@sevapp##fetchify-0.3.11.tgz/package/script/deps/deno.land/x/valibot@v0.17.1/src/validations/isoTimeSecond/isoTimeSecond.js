"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isoTimeSecond = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates a time with seconds.
 *
 * Format: hh:mm:ss
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function isoTimeSecond(error) {
    return (input) => !/^(0[0-9]|1\d|2[0-3]):[0-5]\d:[0-5]\d$/.test(input)
        ? (0, index_js_1.getPipeIssues)('iso_time_second', error || 'Invalid time', input)
        : (0, index_js_1.getOutput)(input);
}
exports.isoTimeSecond = isoTimeSecond;
