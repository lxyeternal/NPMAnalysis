"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.merge = void 0;
const index_js_1 = require("../../schemas/index.js");
const index_js_2 = require("../../utils/index.js");
function merge(schemas, arg2, arg3) {
    // Get error and pipe argument
    const [error, pipe] = (0, index_js_2.getDefaultArgs)(arg2, arg3);
    // Create and return object schema
    return (0, index_js_1.object)(schemas.reduce((object, schemas) => ({ ...object, ...schemas.object }), {}), error, pipe);
}
exports.merge = merge;
