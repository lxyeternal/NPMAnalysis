"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setAsync = void 0;
const index_js_1 = require("../../utils/index.js");
function setAsync(value, arg2, arg3) {
    // Get error and pipe argument
    const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg2, arg3);
    // Create and return async set schema
    return {
        /**
         * The schema type.
         */
        schema: 'set',
        /**
         * The set value schema.
         */
        set: { value },
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            // Check type of input
            if (!(input instanceof Set)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'set', error || 'Invalid type', input);
            }
            // Create index, output and issues
            let issues;
            const output = new Set();
            // Parse each value by schema
            await Promise.all(Array.from(input.values()).map(async (inputValue, key) => {
                // If not aborted early, continue execution
                if (!(info?.abortEarly && issues)) {
                    // Get parse result of input value
                    const result = await value._parse(inputValue, info);
                    // If not aborted early, continue execution
                    if (!(info?.abortEarly && issues)) {
                        // If there are issues, capture them
                        if (result.issues) {
                            // Create set path item
                            const pathItem = {
                                schema: 'set',
                                input,
                                key,
                                value: inputValue,
                            };
                            // Add modified result issues to issues
                            for (const issue of result.issues) {
                                if (issue.path) {
                                    issue.path.unshift(pathItem);
                                }
                                else {
                                    issue.path = [pathItem];
                                }
                                issues?.push(issue);
                            }
                            if (!issues) {
                                issues = result.issues;
                            }
                            // If necessary, abort early
                            if (info?.abortEarly) {
                                throw null;
                            }
                            // Otherwise, add item to set
                        }
                        else {
                            output.add(result.output);
                        }
                    }
                }
            })).catch(() => null);
            // Return issues or pipe result
            return issues
                ? (0, index_js_1.getIssues)(issues)
                : (0, index_js_1.executePipeAsync)(input, pipe, info, 'set');
        },
    };
}
exports.setAsync = setAsync;
