"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cuid2 = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates a [cuid2](https://github.com/paralleldrive/cuid2#cuid2).
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function cuid2(error) {
    return (input) => !/^[a-z][a-z0-9]*$/.test(input)
        ? (0, index_js_1.getPipeIssues)('cuid2', error || 'Invalid cuid2', input)
        : (0, index_js_1.getOutput)(input);
}
exports.cuid2 = cuid2;
