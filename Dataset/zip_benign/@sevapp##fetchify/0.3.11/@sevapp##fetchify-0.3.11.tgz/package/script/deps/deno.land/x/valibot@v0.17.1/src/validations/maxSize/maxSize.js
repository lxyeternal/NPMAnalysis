"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.maxSize = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates the size of a map, set or blob.
 *
 * @param requirement The maximum size.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function maxSize(requirement, error) {
    return (input) => input.size > requirement
        ? (0, index_js_1.getPipeIssues)('max_size', error || 'Invalid size', input)
        : (0, index_js_1.getOutput)(input);
}
exports.maxSize = maxSize;
