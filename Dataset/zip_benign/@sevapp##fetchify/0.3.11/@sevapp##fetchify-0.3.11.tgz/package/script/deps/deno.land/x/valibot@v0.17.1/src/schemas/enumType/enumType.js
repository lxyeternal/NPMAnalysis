"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.enumType = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a enum schema.
 *
 * @param enumValue The enum value.
 * @param error The error message.
 *
 * @returns A enum schema.
 */
function enumType(enumValue, error) {
    return {
        /**
         * The schema type.
         */
        schema: 'enum',
        /**
         * The enum value.
         */
        enum: enumValue,
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Check type of input
            if (!enumValue.includes(input)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'enum', error || 'Invalid type', input);
            }
            // Return inpot as output
            return (0, index_js_1.getOutput)(input);
        },
    };
}
exports.enumType = enumType;
