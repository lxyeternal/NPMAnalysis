"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.startsWith = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates the start of a string.
 *
 * @param requirement The start string.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function startsWith(requirement, error) {
    return (input) => !input.startsWith(requirement)
        ? (0, index_js_1.getPipeIssues)('starts_with', error || 'Invalid start', input)
        : (0, index_js_1.getOutput)(input);
}
exports.startsWith = startsWith;
