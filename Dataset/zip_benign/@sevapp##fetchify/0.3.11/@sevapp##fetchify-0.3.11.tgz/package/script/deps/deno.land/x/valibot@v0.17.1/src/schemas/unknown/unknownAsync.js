"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.unknownAsync = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates an async unknown schema.
 *
 * @param pipe A validation and transformation pipe.
 *
 * @returns An async unknown schema.
 */
function unknownAsync(pipe = []) {
    return {
        /**
         * The schema type.
         */
        schema: 'unknown',
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            return (0, index_js_1.executePipeAsync)(input, pipe, info, 'unknown');
        },
    };
}
exports.unknownAsync = unknownAsync;
