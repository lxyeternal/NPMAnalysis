"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.regex = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates a string with a regex.
 *
 * @param requirement The regex pattern.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function regex(requirement, error) {
    return (input) => !requirement.test(input)
        ? (0, index_js_1.getPipeIssues)('regex', error || 'Invalid regex', input)
        : (0, index_js_1.getOutput)(input);
}
exports.regex = regex;
