"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getOutput = void 0;
/**
 * Returns the result object with an output.
 *
 * @param output The output value.
 *
 * @returns The result object.
 */
function getOutput(output) {
    return { output };
}
exports.getOutput = getOutput;
