"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.blobAsync = void 0;
const index_js_1 = require("../../utils/index.js");
function blobAsync(arg1, arg2) {
    // Get error and pipe argument
    const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg1, arg2);
    // Create and return async blob schema
    return {
        /**
         * The schema type.
         */
        schema: 'blob',
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            // Check type of input
            if (!(input instanceof Blob)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'blob', error || 'Invalid type', input);
            }
            // Execute pipe and return result
            return (0, index_js_1.executePipeAsync)(input, pipe, info, 'blob');
        },
    };
}
exports.blobAsync = blobAsync;
