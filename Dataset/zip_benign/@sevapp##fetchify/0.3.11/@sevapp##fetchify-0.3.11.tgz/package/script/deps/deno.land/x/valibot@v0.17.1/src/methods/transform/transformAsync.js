"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformAsync = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Adds an async transformation step to a schema, which is executed at the end
 * of parsing and can change the output type.
 *
 * @param schema The schema to be used.
 * @param action The transformation action.
 *
 * @returns A transformed schema.
 */
function transformAsync(schema, action) {
    return {
        ...schema,
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            const result = await schema._parse(input, info);
            return result.issues ? result : (0, index_js_1.getOutput)(await action(result.output));
        },
    };
}
exports.transformAsync = transformAsync;
