"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPipeIssues = void 0;
const index_js_1 = require("../getErrorMessage/index.js");
const getIssues_js_1 = require("../getIssues/getIssues.js");
/**
 * Returns the pipeline result object with issues.
 *
 * @param validation The validation name.
 * @param message The error message.
 * @param input The input value.
 *
 * @returns The pipeline result object.
 */
function getPipeIssues(validation, error, input) {
    return (0, getIssues_js_1.getIssues)([
        {
            validation,
            message: (0, index_js_1.getErrorMessage)(error),
            input,
        },
    ]);
}
exports.getPipeIssues = getPipeIssues;
