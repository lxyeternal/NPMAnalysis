"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.safeInteger = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation function that validates whether a number is a safe integer.
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function safeInteger(error) {
    return (input) => !Number.isSafeInteger(input)
        ? (0, index_js_1.getPipeIssues)('safe_integer', error || 'Invalid safe integer', input)
        : (0, index_js_1.getOutput)(input);
}
exports.safeInteger = safeInteger;
