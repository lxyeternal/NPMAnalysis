"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toCustomAsync = void 0;
/**
 * Creates a async custom transformation function.
 *
 * @param action The transform action.
 *
 * @returns A async transformation function.
 */
function toCustomAsync(action) {
    return async (input) => ({
        output: await action(input),
    });
}
exports.toCustomAsync = toCustomAsync;
