"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.unwrap = void 0;
/**
 * Unwraps the wrapped schema.
 *
 * @param schema The schema to be unwrapped.
 *
 * @returns The unwrapped schema.
 */
function unwrap(schema) {
    return schema.wrapped;
}
exports.unwrap = unwrap;
