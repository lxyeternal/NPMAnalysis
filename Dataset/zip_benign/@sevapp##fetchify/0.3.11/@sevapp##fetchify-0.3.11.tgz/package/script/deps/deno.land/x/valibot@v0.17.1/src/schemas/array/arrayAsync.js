"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.arrayAsync = void 0;
const index_js_1 = require("../../utils/index.js");
function arrayAsync(item, arg2, arg3) {
    // Get error and pipe argument
    const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg2, arg3);
    // Create and return async array schema
    return {
        /**
         * The schema type.
         */
        schema: 'array',
        /**
         * The array item schema.
         */
        array: { item },
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            // Check type of input
            if (!Array.isArray(input)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'array', error || 'Invalid type', input);
            }
            // Create issues and output
            let issues;
            const output = [];
            // Parse schema of each array item
            await Promise.all(input.map(async (value, key) => {
                // If not aborted early, continue execution
                if (!(info?.abortEarly && issues)) {
                    // Parse schema of array item
                    const result = await item._parse(value, info);
                    // If not aborted early, continue execution
                    if (!(info?.abortEarly && issues)) {
                        // If there are issues, capture them
                        if (result.issues) {
                            // Create array path item
                            const pathItem = {
                                schema: 'array',
                                input,
                                key,
                                value,
                            };
                            // Add modified result issues to issues
                            for (const issue of result.issues) {
                                if (issue.path) {
                                    issue.path.unshift(pathItem);
                                }
                                else {
                                    issue.path = [pathItem];
                                }
                                issues?.push(issue);
                            }
                            if (!issues) {
                                issues = result.issues;
                            }
                            // If necessary, abort early
                            if (info?.abortEarly) {
                                throw null;
                            }
                            // Otherwise, add item to array
                        }
                        else {
                            output[key] = result.output;
                        }
                    }
                }
            })).catch(() => null);
            // Return issues or pipe result
            return issues
                ? (0, index_js_1.getIssues)(issues)
                : (0, index_js_1.executePipeAsync)(output, pipe, info, 'array');
        },
    };
}
exports.arrayAsync = arrayAsync;
