"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.length = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates the length of a string or array.
 *
 * @param requirement The length.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function length(requirement, error) {
    return (input) => input.length !== requirement
        ? (0, index_js_1.getPipeIssues)('length', error || 'Invalid length', input)
        : (0, index_js_1.getOutput)(input);
}
exports.length = length;
