"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tupleAsync = void 0;
const index_js_1 = require("../../utils/index.js");
const index_js_2 = require("./utils/index.js");
function tupleAsync(items, arg2, arg3, arg4) {
    // Get rest, error and pipe argument
    const [rest, error, pipe] = (0, index_js_2.getTupleArgs)(arg2, arg3, arg4);
    // Create and return async tuple schema
    return {
        /**
         * The schema type.
         */
        schema: 'tuple',
        /**
         * The tuple items and rest schema.
         */
        tuple: { items, rest },
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            // Check type of input
            if (!Array.isArray(input) ||
                (!rest && items.length !== input.length) ||
                (rest && items.length > input.length)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'tuple', error || 'Invalid type', input);
            }
            // Create issues and output
            let issues;
            const output = [];
            await Promise.all([
                // Parse schema of each tuple item
                Promise.all(items.map(async (schema, key) => {
                    // If not aborted early, continue execution
                    if (!(info?.abortEarly && issues)) {
                        const value = input[key];
                        const result = await schema._parse(value, info);
                        // If not aborted early, continue execution
                        if (!(info?.abortEarly && issues)) {
                            // If there are issues, capture them
                            if (result.issues) {
                                // Create tuple path item
                                const pathItem = {
                                    schema: 'tuple',
                                    input: input,
                                    key,
                                    value,
                                };
                                // Add modified result issues to issues
                                for (const issue of result.issues) {
                                    if (issue.path) {
                                        issue.path.unshift(pathItem);
                                    }
                                    else {
                                        issue.path = [pathItem];
                                    }
                                    issues?.push(issue);
                                }
                                if (!issues) {
                                    issues = result.issues;
                                }
                                // If necessary, abort early
                                if (info?.abortEarly) {
                                    throw null;
                                }
                                // Otherwise, add item to tuple
                            }
                            else {
                                output[key] = result.output;
                            }
                        }
                    }
                })),
                // If necessary parse schema of each rest item
                rest &&
                    Promise.all(input.slice(items.length).map(async (value, index) => {
                        // If not aborted early, continue execution
                        if (!(info?.abortEarly && issues)) {
                            const key = items.length + index;
                            const result = await rest._parse(value, info);
                            // If not aborted early, continue execution
                            if (!(info?.abortEarly && issues)) {
                                // If there are issues, capture them
                                if (result.issues) {
                                    // Create tuple path item
                                    const pathItem = {
                                        schema: 'tuple',
                                        input: input,
                                        key,
                                        value,
                                    };
                                    // Add modified result issues to issues
                                    for (const issue of result.issues) {
                                        if (issue.path) {
                                            issue.path.unshift(pathItem);
                                        }
                                        else {
                                            issue.path = [pathItem];
                                        }
                                        issues?.push(issue);
                                    }
                                    if (!issues) {
                                        issues = result.issues;
                                    }
                                    // If necessary, abort early
                                    if (info?.abortEarly) {
                                        throw null;
                                    }
                                    // Otherwise, add item to tuple
                                }
                                else {
                                    output[key] = result.output;
                                }
                            }
                        }
                    })),
            ]).catch(() => null);
            // Return issues or pipe result
            return issues
                ? (0, index_js_1.getIssues)(issues)
                : (0, index_js_1.executePipeAsync)(output, pipe, info, 'tuple');
        },
    };
}
exports.tupleAsync = tupleAsync;
