"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nonOptionalAsync = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates an async non optional schema.
 *
 * @param wrapped The wrapped schema.
 * @param error The error message.
 *
 * @returns An async non optional schema.
 */
function nonOptionalAsync(wrapped, error) {
    return {
        /**
         * The schema type.
         */
        schema: 'non_optional',
        /**
         * The wrapped schema.
         */
        wrapped,
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            // Allow `undefined` values not to pass
            if (input === undefined) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'non_optional', error || 'Invalid type', input);
            }
            // Return result of wrapped schema
            return wrapped._parse(input, info);
        },
    };
}
exports.nonOptionalAsync = nonOptionalAsync;
