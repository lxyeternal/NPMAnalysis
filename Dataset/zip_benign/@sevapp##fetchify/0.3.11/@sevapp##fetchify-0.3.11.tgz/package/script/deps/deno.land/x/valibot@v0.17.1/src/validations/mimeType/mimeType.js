"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mimeType = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates the MIME type of a file.
 *
 * @param requirement The MIME types.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function mimeType(requirement, error) {
    return (input) => !requirement.includes(input.type)
        ? (0, index_js_1.getPipeIssues)('mime_type', error || 'Invalid MIME type', input)
        : (0, index_js_1.getOutput)(input);
}
exports.mimeType = mimeType;
