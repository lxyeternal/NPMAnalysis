"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.voidType = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a void schema.
 *
 * @param error The error message.
 *
 * @returns A void schema.
 */
function voidType(error) {
    return {
        /**
         * The schema type.
         */
        schema: 'void',
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Check type of input
            if (typeof input !== 'undefined') {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'void', error || 'Invalid type', input);
            }
            // Return input as output
            return (0, index_js_1.getOutput)(input);
        },
    };
}
exports.voidType = voidType;
