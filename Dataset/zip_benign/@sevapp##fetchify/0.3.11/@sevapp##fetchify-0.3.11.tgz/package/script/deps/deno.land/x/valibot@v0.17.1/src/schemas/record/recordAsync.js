"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recordAsync = void 0;
const index_js_1 = require("../../utils/index.js");
const index_js_2 = require("./utils/index.js");
const values_js_1 = require("./values.js");
function recordAsync(arg1, arg2, arg3, arg4) {
    // Get key, value, error and pipe argument
    const [key, value, error, pipe] = (0, index_js_2.getRecordArgs)(arg1, arg2, arg3, arg4);
    // Create and return async record schema
    return {
        /**
         * The schema type.
         */
        schema: 'record',
        /**
         * The record key and value schema.
         */
        record: { key, value },
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            // Check type of input
            if (!input || typeof input !== 'object') {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'record', error || 'Invalid type', input);
            }
            // Create issues and output
            let issues;
            const output = {};
            // Parse each key and value by schema
            await Promise.all(
            // Note: `Object.entries(...)` converts each key to a string
            Object.entries(input).map(async ([inputKey, inputValue]) => {
                // Exclude blocked keys to prevent prototype pollutions
                if (!values_js_1.BLOCKED_KEYS.includes(inputKey)) {
                    // Create path item variable
                    let pathItem;
                    // Get parse result of key and value
                    const [keyResult, valueResult] = await Promise.all([
                        { schema: key, value: inputKey, origin: 'key' },
                        { schema: value, value: inputValue, origin: 'value' },
                    ].map(async ({ schema, value, origin }) => {
                        // If not aborted early, continue execution
                        if (!(info?.abortEarly && issues)) {
                            // Get parse result of value
                            const result = await schema._parse(value, {
                                origin,
                                abortEarly: info?.abortEarly,
                                abortPipeEarly: info?.abortPipeEarly,
                                skipPipe: info?.skipPipe,
                            });
                            // If not aborted early, continue execution
                            if (!(info?.abortEarly && issues)) {
                                // If there are issues, capture them
                                if (result.issues) {
                                    // Create record path item
                                    pathItem = pathItem || {
                                        schema: 'record',
                                        input,
                                        key: inputKey,
                                        value: inputValue,
                                    };
                                    // Add modified result issues to issues
                                    for (const issue of result.issues) {
                                        if (issue.path) {
                                            issue.path.unshift(pathItem);
                                        }
                                        else {
                                            issue.path = [pathItem];
                                        }
                                        issues?.push(issue);
                                    }
                                    if (!issues) {
                                        issues = result.issues;
                                    }
                                    // If necessary, abort early
                                    if (info?.abortEarly) {
                                        throw null;
                                    }
                                    // Otherwise, return parse result
                                }
                                else {
                                    return result;
                                }
                            }
                        }
                    })).catch(() => []);
                    // Set entry if there are no issues
                    if (keyResult && valueResult) {
                        output[keyResult.output] = valueResult.output;
                    }
                }
            }));
            // Return issues or pipe result
            return issues
                ? (0, index_js_1.getIssues)(issues)
                : (0, index_js_1.executePipeAsync)(output, pipe, info, 'record');
        },
    };
}
exports.recordAsync = recordAsync;
