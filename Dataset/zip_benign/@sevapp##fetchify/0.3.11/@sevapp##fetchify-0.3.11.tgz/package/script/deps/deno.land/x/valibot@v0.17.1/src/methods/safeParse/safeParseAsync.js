"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.safeParseAsync = void 0;
const index_js_1 = require("../../error/index.js");
/**
 * Parses unknown input based on a schema.
 *
 * @param schema The schema to be used.
 * @param input The input to be parsed.
 * @param info The optional parse info.
 *
 * @returns The parsed output.
 */
async function safeParseAsync(schema, input, info) {
    const result = await schema._parse(input, info);
    return result.issues
        ? {
            success: false,
            error: new index_js_1.ValiError(result.issues),
            issues: result.issues,
        }
        : {
            success: true,
            data: result.output,
            output: result.output,
        };
}
exports.safeParseAsync = safeParseAsync;
