"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDefault = void 0;
/**
 * Returns the default value of the schema.
 *
 * @param schema The schema to get the default value from.
 *
 * @returns The default value.
 */
function getDefault(schema) {
    return schema.default;
}
exports.getDefault = getDefault;
