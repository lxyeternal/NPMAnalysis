"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isoWeek = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates a week.
 *
 * Format: yyyy-Www
 *
 * Hint: The regex used cannot validate the maximum number of weeks based on
 * the year. For example, "2021W53" is valid even though the year 2021 has only
 * 52 weeks.
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function isoWeek(error) {
    return (input) => !/^\d{4}-W(0[1-9]|[1-4]\d|5[0-3])$/.test(input)
        ? (0, index_js_1.getPipeIssues)('iso_week', error || 'Invalid week', input)
        : (0, index_js_1.getOutput)(input);
}
exports.isoWeek = isoWeek;
