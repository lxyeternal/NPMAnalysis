"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.emoji = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates a emoji.
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function emoji(error) {
    return (input) => !/^(\p{Extended_Pictographic}|\p{Emoji_Component})+$/u.test(input)
        ? (0, index_js_1.getPipeIssues)('emoji', error || 'Invalid emoji', input)
        : (0, index_js_1.getOutput)(input);
}
exports.emoji = emoji;
