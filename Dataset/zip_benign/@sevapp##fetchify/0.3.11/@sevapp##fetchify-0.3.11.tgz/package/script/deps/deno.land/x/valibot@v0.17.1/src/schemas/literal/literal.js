"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.literal = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a literal schema.
 *
 * @param literal The literal value.
 * @param error The error message.
 *
 * @returns A literal schema.
 */
function literal(literal, error) {
    return {
        /**
         * The schema type.
         */
        schema: 'literal',
        /**
         * The literal value.
         */
        literal,
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Check type of input
            if (input !== literal) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'literal', error || 'Invalid type', input);
            }
            // Return input as output
            return (0, index_js_1.getOutput)(input);
        },
    };
}
exports.literal = literal;
