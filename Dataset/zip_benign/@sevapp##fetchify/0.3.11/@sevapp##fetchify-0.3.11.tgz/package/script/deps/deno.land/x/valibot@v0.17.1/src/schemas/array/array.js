"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.array = void 0;
const index_js_1 = require("../../utils/index.js");
function array(item, arg2, arg3) {
    // Get error and pipe argument
    const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg2, arg3);
    // Create and return array schema
    return {
        /**
         * The schema type.
         */
        schema: 'array',
        /**
         * The array item schema.
         */
        array: { item },
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Check type of input
            if (!Array.isArray(input)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'array', error || 'Invalid type', input);
            }
            // Create issues and output
            let issues;
            const output = [];
            // Parse schema of each array item
            for (let key = 0; key < input.length; key++) {
                const value = input[key];
                const result = item._parse(value, info);
                // If there are issues, capture them
                if (result.issues) {
                    // Create array path item
                    const pathItem = {
                        schema: 'array',
                        input,
                        key,
                        value,
                    };
                    // Add modified result issues to issues
                    for (const issue of result.issues) {
                        if (issue.path) {
                            issue.path.unshift(pathItem);
                        }
                        else {
                            issue.path = [pathItem];
                        }
                        issues?.push(issue);
                    }
                    if (!issues) {
                        issues = result.issues;
                    }
                    // If necessary, abort early
                    if (info?.abortEarly) {
                        break;
                    }
                    // Otherwise, add item to array
                }
                else {
                    output.push(result.output);
                }
            }
            // Return issues or pipe result
            return issues
                ? (0, index_js_1.getIssues)(issues)
                : (0, index_js_1.executePipe)(output, pipe, info, 'array');
        },
    };
}
exports.array = array;
