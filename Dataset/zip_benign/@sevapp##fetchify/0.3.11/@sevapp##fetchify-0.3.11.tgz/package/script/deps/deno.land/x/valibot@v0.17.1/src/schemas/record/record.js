"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.record = void 0;
const index_js_1 = require("../../utils/index.js");
const index_js_2 = require("./utils/index.js");
const values_js_1 = require("./values.js");
function record(arg1, arg2, arg3, arg4) {
    // Get key, value, error and pipe argument
    const [key, value, error, pipe] = (0, index_js_2.getRecordArgs)(arg1, arg2, arg3, arg4);
    // Create and return record schema
    return {
        /**
         * The schema type.
         */
        schema: 'record',
        /**
         * The record key and value schema.
         */
        record: { key, value },
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Check type of input
            if (!input || typeof input !== 'object') {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'record', error || 'Invalid type', input);
            }
            // Create issues and output
            let issues;
            const output = {};
            // Parse each key and value by schema
            // Note: `Object.entries(...)` converts each key to a string
            for (const [inputKey, inputValue] of Object.entries(input)) {
                // Exclude blocked keys to prevent prototype pollutions
                if (!values_js_1.BLOCKED_KEYS.includes(inputKey)) {
                    // Create path item variable
                    let pathItem;
                    // Get parse result of key
                    const keyResult = key._parse(inputKey, {
                        origin: 'key',
                        abortEarly: info?.abortEarly,
                        abortPipeEarly: info?.abortPipeEarly,
                        skipPipe: info?.skipPipe,
                    });
                    // If there are issues, capture them
                    if (keyResult.issues) {
                        // Create record path item
                        pathItem = {
                            schema: 'record',
                            input,
                            key: inputKey,
                            value: inputValue,
                        };
                        // Add modified result issues to issues
                        for (const issue of keyResult.issues) {
                            issue.path = [pathItem];
                            issues?.push(issue);
                        }
                        if (!issues) {
                            issues = keyResult.issues;
                        }
                        // If necessary, abort early
                        if (info?.abortEarly) {
                            break;
                        }
                    }
                    // Get parse result of value
                    const valueResult = value._parse(inputValue, info);
                    // If there are issues, capture them
                    if (valueResult.issues) {
                        // Create record path item
                        pathItem = pathItem || {
                            schema: 'record',
                            input,
                            key: inputKey,
                            value: inputValue,
                        };
                        // Add modified result issues to issues
                        for (const issue of valueResult.issues) {
                            if (issue.path) {
                                issue.path.unshift(pathItem);
                            }
                            else {
                                issue.path = [pathItem];
                            }
                            issues?.push(issue);
                        }
                        if (!issues) {
                            issues = valueResult.issues;
                        }
                        // If necessary, abort early
                        if (info?.abortEarly) {
                            break;
                        }
                    }
                    // Set entry if there are no issues
                    if (!keyResult.issues && !valueResult.issues) {
                        output[keyResult.output] = valueResult.output;
                    }
                }
            }
            // Return issues or pipe result
            return issues
                ? (0, index_js_1.getIssues)(issues)
                : (0, index_js_1.executePipe)(output, pipe, info, 'record');
        },
    };
}
exports.record = record;
