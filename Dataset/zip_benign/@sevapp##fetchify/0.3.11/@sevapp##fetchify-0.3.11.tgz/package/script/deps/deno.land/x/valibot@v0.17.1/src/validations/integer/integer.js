"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.integer = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation function that validates whether a number is an integer.
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function integer(error) {
    return (input) => !Number.isInteger(input)
        ? (0, index_js_1.getPipeIssues)('integer', error || 'Invalid integer', input)
        : (0, index_js_1.getOutput)(input);
}
exports.integer = integer;
