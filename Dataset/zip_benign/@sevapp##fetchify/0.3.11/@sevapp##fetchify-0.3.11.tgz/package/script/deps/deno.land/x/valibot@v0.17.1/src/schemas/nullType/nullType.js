"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nullType = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a null schema.
 *
 * @param error The error message.
 *
 * @returns A null schema.
 */
function nullType(error) {
    return {
        /**
         * The schema type.
         */
        schema: 'null',
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Check type of input
            if (input !== null) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'null', error || 'Invalid type', input);
            }
            // Return input as output
            return (0, index_js_1.getOutput)(input);
        },
    };
}
exports.nullType = nullType;
