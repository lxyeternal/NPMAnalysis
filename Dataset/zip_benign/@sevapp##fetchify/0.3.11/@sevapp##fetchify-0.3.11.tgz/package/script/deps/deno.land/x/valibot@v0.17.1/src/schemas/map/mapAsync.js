"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapAsync = void 0;
const index_js_1 = require("../../utils/index.js");
function mapAsync(key, value, arg3, arg4) {
    // Get error and pipe argument
    const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg3, arg4);
    // Create and return async map schema
    return {
        /**
         * The schema type.
         */
        schema: 'map',
        /**
         * The map key and value schema.
         */
        map: { key, value },
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            // Check type of input
            if (!(input instanceof Map)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'map', error || 'Invalid type', input);
            }
            // Create issues and output
            const output = new Map();
            let issues;
            // Parse each key and value by schema
            await Promise.all(Array.from(input.entries()).map(async ([inputKey, inputValue]) => {
                // Create path item variable
                let pathItem;
                // Get parse result of key and value
                const [keyResult, valueResult] = await Promise.all([
                    { schema: key, value: inputKey, origin: 'key' },
                    { schema: value, value: inputValue, origin: 'value' },
                ].map(async ({ schema, value, origin }) => {
                    // If not aborted early, continue execution
                    if (!(info?.abortEarly && issues)) {
                        // Get parse result of value
                        const result = await schema._parse(value, {
                            origin,
                            abortEarly: info?.abortEarly,
                            abortPipeEarly: info?.abortPipeEarly,
                            skipPipe: info?.skipPipe,
                        });
                        // If not aborted early, continue execution
                        if (!(info?.abortEarly && issues)) {
                            // If there are issues, capture them
                            if (result.issues) {
                                // Create map path item
                                pathItem = pathItem || {
                                    schema: 'map',
                                    input,
                                    key: inputKey,
                                    value: inputValue,
                                };
                                // Add modified result issues to issues
                                for (const issue of result.issues) {
                                    if (issue.path) {
                                        issue.path.unshift(pathItem);
                                    }
                                    else {
                                        issue.path = [pathItem];
                                    }
                                    issues?.push(issue);
                                }
                                if (!issues) {
                                    issues = result.issues;
                                }
                                // If necessary, abort early
                                if (info?.abortEarly) {
                                    throw null;
                                }
                                // Otherwise, return parse result
                            }
                            else {
                                return result;
                            }
                        }
                    }
                })).catch(() => []);
                // Set entry if there are no issues
                if (keyResult && valueResult) {
                    output.set(keyResult.output, valueResult.output);
                }
            }));
            // Return issues or pipe result
            return issues
                ? (0, index_js_1.getIssues)(issues)
                : (0, index_js_1.executePipeAsync)(input, pipe, info, 'map');
        },
    };
}
exports.mapAsync = mapAsync;
