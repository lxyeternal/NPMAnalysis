"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nonNullable = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a non nullable schema.
 *
 * @param wrapped The wrapped schema.
 * @param error The error message.
 *
 * @returns A non nullable schema.
 */
function nonNullable(wrapped, error) {
    return {
        /**
         * The schema type.
         */
        schema: 'non_nullable',
        /**
         * The wrapped schema.
         */
        wrapped,
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Allow `null` values not to pass
            if (input === null) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'non_nullable', error || 'Invalid type', input);
            }
            // Return result of wrapped schema
            return wrapped._parse(input, info);
        },
    };
}
exports.nonNullable = nonNullable;
