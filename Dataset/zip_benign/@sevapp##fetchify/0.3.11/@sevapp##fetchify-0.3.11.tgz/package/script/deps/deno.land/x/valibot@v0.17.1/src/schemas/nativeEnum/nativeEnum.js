"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nativeEnum = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a enum schema.
 *
 * @param nativeEnum The native enum value.
 * @param error The error message.
 *
 * @returns A enum schema.
 */
function nativeEnum(nativeEnum, error) {
    return {
        /**
         * The schema type.
         */
        schema: 'native_enum',
        /**
         * The native enum value.
         */
        nativeEnum,
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Check type of input
            if (!Object.values(nativeEnum).includes(input)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'native_enum', error || 'Invalid type', input);
            }
            // Return input as output
            return (0, index_js_1.getOutput)(input);
        },
    };
}
exports.nativeEnum = nativeEnum;
