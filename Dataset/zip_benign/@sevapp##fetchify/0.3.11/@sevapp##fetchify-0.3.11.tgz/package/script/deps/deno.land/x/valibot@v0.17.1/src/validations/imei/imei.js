"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.imei = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates a IMEI.
 *
 * Format: AA-BBBBBB-CCCCCC-D
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function imei(error) {
    return (input) => !/^\d{2}[ |/|-]?\d{6}[ |/|-]?\d{6}[ |/|-]?\d$/.test(input) ||
        !(0, index_js_1.isLuhnAlgo)(input)
        ? (0, index_js_1.getPipeIssues)('imei', error || 'Invalid IMEI', input)
        : (0, index_js_1.getOutput)(input);
}
exports.imei = imei;
