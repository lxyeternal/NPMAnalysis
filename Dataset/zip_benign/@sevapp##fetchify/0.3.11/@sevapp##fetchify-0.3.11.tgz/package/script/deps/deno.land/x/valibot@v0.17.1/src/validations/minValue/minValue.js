"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.minRange = exports.minValue = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates the value of a string, number or date.
 *
 * @param requirement The minimum value.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function minValue(requirement, error) {
    return (input) => input < requirement
        ? (0, index_js_1.getPipeIssues)('min_value', error || 'Invalid value', input)
        : (0, index_js_1.getOutput)(input);
}
exports.minValue = minValue;
/**
 * See {@link minValue}
 *
 * @deprecated Function has been renamed to `minValue`.
 */
exports.minRange = minValue;
