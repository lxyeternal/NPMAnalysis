"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ipv4 = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates a IP v4 address.
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function ipv4(error) {
    return (input) => !/^((25[0-5]|(2[0-4]|1\d|[1-9]|)\d)\.?\b){4}$/.test(input)
        ? (0, index_js_1.getPipeIssues)('ipv4', error || 'Invalid IP v4', input)
        : (0, index_js_1.getOutput)(input);
}
exports.ipv4 = ipv4;
