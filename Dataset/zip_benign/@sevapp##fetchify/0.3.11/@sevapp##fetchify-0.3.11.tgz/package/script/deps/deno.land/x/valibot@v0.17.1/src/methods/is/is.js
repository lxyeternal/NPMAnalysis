"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.is = void 0;
/**
 * Checks if the input matches the scheme. By using a type predicate, this
 * function can be used as a type guard.
 *
 * @param schema The schema to be used.
 * @param input The input to be tested.
 *
 * @returns Whether the input matches the scheme.
 */
function is(schema, input) {
    return !schema._parse(input, { abortEarly: true }).issues;
}
exports.is = is;
