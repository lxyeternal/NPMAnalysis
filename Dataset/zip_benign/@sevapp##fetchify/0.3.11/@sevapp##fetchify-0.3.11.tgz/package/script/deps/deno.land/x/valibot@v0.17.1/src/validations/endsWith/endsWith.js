"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.endsWith = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates the end of a string.
 *
 * @param requirement The end string.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function endsWith(requirement, error) {
    return (input) => !input.endsWith(requirement)
        ? (0, index_js_1.getPipeIssues)('ends_with', error || 'Invalid end', input)
        : (0, index_js_1.getOutput)(input);
}
exports.endsWith = endsWith;
