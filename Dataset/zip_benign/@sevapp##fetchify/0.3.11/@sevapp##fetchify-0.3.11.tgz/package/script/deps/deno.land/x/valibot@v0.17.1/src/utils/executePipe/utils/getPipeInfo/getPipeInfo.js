"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPipeInfo = void 0;
/**
 * Returns the pipe info.
 *
 * @param info The parse info.
 * @param reason The issue reason.
 *
 * @returns The pipe info.
 */
function getPipeInfo(info, reason) {
    // Note: The pipe info is deliberately not constructed with the spread
    // operator for performance reasons
    return {
        reason,
        origin: info?.origin,
        abortEarly: info?.abortEarly,
        abortPipeEarly: info?.abortPipeEarly,
        skipPipe: info?.skipPipe,
    };
}
exports.getPipeInfo = getPipeInfo;
