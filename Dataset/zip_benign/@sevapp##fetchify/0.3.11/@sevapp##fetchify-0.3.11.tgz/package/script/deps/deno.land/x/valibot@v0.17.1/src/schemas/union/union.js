"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.union = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a union schema.
 *
 * @param union The union schema.
 * @param error The error message.
 *
 * @returns A union schema.
 */
function union(union, error) {
    return {
        /**
         * The schema type.
         */
        schema: 'union',
        /**
         * The union schema.
         */
        union,
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Create issues and output
            let issues;
            let output;
            // Parse schema of each option
            for (const schema of union) {
                const result = schema._parse(input, info);
                // If there are issues, capture them
                if (result.issues) {
                    if (issues) {
                        for (const issue of result.issues) {
                            issues.push(issue);
                        }
                    }
                    else {
                        issues = result.issues;
                    }
                    // Otherwise, set output and break loop
                }
                else {
                    // Note: Output is nested in array, so that also a falsy value
                    // further down can be recognized as valid value
                    output = [result.output];
                    break;
                }
            }
            // Return input as output or issues
            return output
                ? (0, index_js_1.getOutput)(output[0])
                : (0, index_js_1.getSchemaIssues)(info, 'type', 'union', error || 'Invalid type', input, issues);
        },
    };
}
exports.union = union;
