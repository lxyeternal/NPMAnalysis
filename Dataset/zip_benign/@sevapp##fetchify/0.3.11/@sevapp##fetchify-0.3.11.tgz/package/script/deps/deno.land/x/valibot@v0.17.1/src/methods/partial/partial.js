"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.partial = void 0;
const index_js_1 = require("../../schemas/index.js");
const index_js_2 = require("../../utils/index.js");
function partial(schema, arg3, arg4) {
    // Get error and pipe argument
    const [error, pipe] = (0, index_js_2.getDefaultArgs)(arg3, arg4);
    // Create and return object schema
    // @ts-ignore FIXME: Remove line once bug in TS is fixed
    return (0, index_js_1.object)(Object.entries(schema.object).reduce((object, [key, schema]) => ({
        ...object,
        [key]: (0, index_js_1.optional)(schema),
    }), {}), error, 
    // @ts-ignore FIXME: Remove line once bug in TS is fixed
    pipe);
}
exports.partial = partial;
