"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.excludes = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates the content of a string or array.
 *
 * @param requirement The content to be excluded.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function excludes(requirement, error) {
    return (input) => input.includes(requirement)
        ? (0, index_js_1.getPipeIssues)('excludes', error || 'Invalid content', input)
        : (0, index_js_1.getOutput)(input);
}
exports.excludes = excludes;
