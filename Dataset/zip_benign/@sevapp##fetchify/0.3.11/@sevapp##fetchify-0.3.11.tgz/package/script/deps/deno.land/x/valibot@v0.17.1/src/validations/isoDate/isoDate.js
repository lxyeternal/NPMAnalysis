"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isoDate = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates a date.
 *
 * Format: yyyy-mm-dd
 *
 * Hint: The regex used cannot validate the maximum number of days based on
 * year and month. For example, "2023-06-31" is valid although June has only
 * 30 days.
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function isoDate(error) {
    return (input) => !/^\d{4}-(0[1-9]|1[0-2])-([12]\d|0[1-9]|3[01])$/.test(input)
        ? (0, index_js_1.getPipeIssues)('iso_date', error || 'Invalid date', input)
        : (0, index_js_1.getOutput)(input);
}
exports.isoDate = isoDate;
