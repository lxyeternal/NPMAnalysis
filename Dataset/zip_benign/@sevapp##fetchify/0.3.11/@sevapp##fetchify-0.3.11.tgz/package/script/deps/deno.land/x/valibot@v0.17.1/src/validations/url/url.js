"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.url = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates a URL.
 *
 * Hint: The value is passed to the URL constructor to check if it is valid.
 * This check is not perfect. For example, values like "abc:1234" are accepted.
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function url(error) {
    return (input) => {
        try {
            new URL(input);
            return (0, index_js_1.getOutput)(input);
        }
        catch (_) {
            return (0, index_js_1.getPipeIssues)('url', error || 'Invalid URL', input);
        }
    };
}
exports.url = url;
