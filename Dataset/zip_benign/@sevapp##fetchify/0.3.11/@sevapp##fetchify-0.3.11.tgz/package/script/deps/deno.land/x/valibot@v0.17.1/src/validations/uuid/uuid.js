"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.uuid = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates a UUID.
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function uuid(error) {
    return (input) => !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(input)
        ? (0, index_js_1.getPipeIssues)('uuid', error || 'Invalid UUID', input)
        : (0, index_js_1.getOutput)(input);
}
exports.uuid = uuid;
