"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.objectAsync = void 0;
const index_js_1 = require("../../utils/index.js");
function objectAsync(object, arg2, arg3) {
    // Get error and pipe argument
    const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg2, arg3);
    // Create cached entries
    let cachedEntries;
    // Create and return async object schema
    return {
        /**
         * The schema type.
         */
        schema: 'object',
        /**
         * The object schema.
         */
        object,
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            // Check type of input
            if (!input || typeof input !== 'object') {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'object', error || 'Invalid type', input);
            }
            // Cache object entries lazy
            cachedEntries = cachedEntries || Object.entries(object);
            // Create issues and output
            let issues;
            const output = {};
            // Parse schema of each key
            await Promise.all(cachedEntries.map(async ([key, schema]) => {
                // If not aborted early, continue execution
                if (!(info?.abortEarly && issues)) {
                    // Get value by key
                    const value = input[key];
                    // Get parse result of value
                    const result = await schema._parse(value, info);
                    // If not aborted early, continue execution
                    if (!(info?.abortEarly && issues)) {
                        // If there are issues, capture them
                        if (result.issues) {
                            // Create object path item
                            const pathItem = {
                                schema: 'object',
                                input,
                                key,
                                value,
                            };
                            // Add modified result issues to issues
                            for (const issue of result.issues) {
                                if (issue.path) {
                                    issue.path.unshift(pathItem);
                                }
                                else {
                                    issue.path = [pathItem];
                                }
                                issues?.push(issue);
                            }
                            if (!issues) {
                                issues = result.issues;
                            }
                            // If necessary, abort early
                            if (info?.abortEarly) {
                                throw null;
                            }
                            // Otherwise, add value to object
                        }
                        else {
                            output[key] = result.output;
                        }
                    }
                }
            })).catch(() => null);
            // Return issues or pipe result
            return issues
                ? (0, index_js_1.getIssues)(issues)
                : (0, index_js_1.executePipeAsync)(output, pipe, info, 'object');
        },
    };
}
exports.objectAsync = objectAsync;
