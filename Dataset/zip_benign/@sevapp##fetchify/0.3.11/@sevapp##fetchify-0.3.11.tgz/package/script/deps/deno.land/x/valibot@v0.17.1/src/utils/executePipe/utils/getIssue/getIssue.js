"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getIssue = void 0;
/**
 * Returns the final issue data.
 *
 * @param info The pipe info.
 * @param issue The issue data.
 *
 * @returns The issue data.
 */
function getIssue(info, issue) {
    // Note: The issue is deliberately not constructed with the spread operator
    // for performance reasons
    return {
        reason: info?.reason,
        validation: issue.validation,
        origin: info?.origin || 'value',
        message: issue.message,
        input: issue.input,
        path: issue.path,
        abortEarly: info?.abortEarly,
        abortPipeEarly: info?.abortPipeEarly,
        skipPipe: info?.skipPipe,
    };
}
exports.getIssue = getIssue;
