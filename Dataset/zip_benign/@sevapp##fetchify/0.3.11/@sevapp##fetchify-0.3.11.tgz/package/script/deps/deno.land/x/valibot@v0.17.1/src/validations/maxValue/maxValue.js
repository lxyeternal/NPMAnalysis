"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.maxRange = exports.maxValue = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates the value of a string, number or date.
 *
 * @param requirement The maximum value.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function maxValue(requirement, error) {
    return (input) => input > requirement
        ? (0, index_js_1.getPipeIssues)('max_value', error || 'Invalid value', input)
        : (0, index_js_1.getOutput)(input);
}
exports.maxValue = maxValue;
/**
 * See {@link maxValue}
 *
 * @deprecated Function has been renamed to `maxValue`.
 */
exports.maxRange = maxValue;
