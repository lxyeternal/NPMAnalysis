"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTupleArgs = void 0;
const index_js_1 = require("../../../../utils/index.js");
/**
 * Returns rest, error and pipe from dynamic arguments.
 *
 * @param arg1 First argument.
 * @param arg2 Second argument.
 * @param arg3 Third argument.
 *
 * @returns The tuple arguments.
 */
function getTupleArgs(arg1, arg2, arg3) {
    if (typeof arg1 === 'object' && !Array.isArray(arg1)) {
        const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg2, arg3);
        return [arg1, error, pipe];
    }
    const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg1, arg2);
    return [undefined, error, pipe];
}
exports.getTupleArgs = getTupleArgs;
