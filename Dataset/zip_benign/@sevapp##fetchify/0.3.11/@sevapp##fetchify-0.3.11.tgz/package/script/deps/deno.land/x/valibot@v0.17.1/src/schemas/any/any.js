"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.any = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a any schema.
 *
 * @param pipe A validation and transformation pipe.
 *
 * @returns A any schema.
 */
function any(pipe = []) {
    return {
        /**
         * The schema type.
         */
        schema: 'any',
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            return (0, index_js_1.executePipe)(input, pipe, info, 'any');
        },
    };
}
exports.any = any;
