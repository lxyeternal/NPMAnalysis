"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.multipleOf = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation function that validates whether a number is a multiple.
 *
 * @param requirement The divisor.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function multipleOf(requirement, error) {
    return (input) => input % requirement !== 0
        ? (0, index_js_1.getPipeIssues)('multiple_of', error || 'Invalid multiple', input)
        : (0, index_js_1.getOutput)(input);
}
exports.multipleOf = multipleOf;
