"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fallbackAsync = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Returns a fallback value when validating the passed schema failed.
 *
 * @param schema The schema to catch.
 * @param value The fallback value.
 *
 * @returns The passed schema.
 */
function fallbackAsync(schema, value) {
    return {
        ...schema,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            const result = await schema._parse(input, info);
            return (0, index_js_1.getOutput)(result.issues
                ? typeof value === 'function'
                    ? value({
                        input,
                        issues: result.issues,
                    })
                    : value
                : result.output);
        },
    };
}
exports.fallbackAsync = fallbackAsync;
