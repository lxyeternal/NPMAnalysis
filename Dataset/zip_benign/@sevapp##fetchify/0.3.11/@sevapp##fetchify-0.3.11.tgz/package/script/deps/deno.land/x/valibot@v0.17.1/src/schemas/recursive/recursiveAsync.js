"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recursiveAsync = void 0;
/**
 * Creates an async recursive schema.
 *
 * @param getter The schema getter.
 *
 * @returns An async recursive schema.
 */
function recursiveAsync(getter) {
    return {
        /**
         * The schema type.
         */
        schema: 'recursive',
        /**
         * The schema getter.
         */
        getter,
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            return getter()._parse(input, info);
        },
    };
}
exports.recursiveAsync = recursiveAsync;
