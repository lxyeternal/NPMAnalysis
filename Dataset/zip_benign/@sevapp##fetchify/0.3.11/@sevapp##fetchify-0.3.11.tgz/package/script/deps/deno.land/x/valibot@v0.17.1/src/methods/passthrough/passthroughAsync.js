"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.passthroughAsync = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates an object schema that passes unknown keys.
 *
 * @param schema A object schema.
 *
 * @returns A object schema.
 */
function passthroughAsync(schema) {
    return {
        ...schema,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            const result = await schema._parse(input, info);
            return !result.issues
                ? (0, index_js_1.getOutput)({ ...input, ...result.output })
                : result;
        },
    };
}
exports.passthroughAsync = passthroughAsync;
