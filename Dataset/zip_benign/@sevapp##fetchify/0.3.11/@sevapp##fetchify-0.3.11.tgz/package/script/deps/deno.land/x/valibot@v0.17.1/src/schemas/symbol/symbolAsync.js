"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.symbolAsync = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates an async symbol schema.
 *
 * @param error The error message.
 *
 * @returns An async symbol schema.
 */
function symbolAsync(error) {
    return {
        /**
         * The schema type.
         */
        schema: 'symbol',
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            // Check type of input
            if (typeof input !== 'symbol') {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'symbol', error || 'Invalid type', input);
            }
            // Return input as output
            return (0, index_js_1.getOutput)(input);
        },
    };
}
exports.symbolAsync = symbolAsync;
