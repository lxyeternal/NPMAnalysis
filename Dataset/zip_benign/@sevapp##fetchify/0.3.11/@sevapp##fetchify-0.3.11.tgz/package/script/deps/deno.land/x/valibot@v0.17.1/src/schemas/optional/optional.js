"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.optional = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a optional schema.
 *
 * @param wrapped The wrapped schema.
 * @param default_ The default value.
 *
 * @returns A optional schema.
 */
function optional(wrapped, default_) {
    return {
        /**
         * The schema type.
         */
        schema: 'optional',
        /**
         * The wrapped schema.
         */
        wrapped,
        /**
         * The default value.
         */
        get default() {
            return typeof default_ === 'function'
                ? default_()
                : default_;
        },
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Get default or input value
            const value = input === undefined ? this.default : input;
            // Allow `undefined` value to pass
            if (value === undefined) {
                return (0, index_js_1.getOutput)(value);
            }
            // Return result of wrapped schema
            return wrapped._parse(value, info);
        },
    };
}
exports.optional = optional;
