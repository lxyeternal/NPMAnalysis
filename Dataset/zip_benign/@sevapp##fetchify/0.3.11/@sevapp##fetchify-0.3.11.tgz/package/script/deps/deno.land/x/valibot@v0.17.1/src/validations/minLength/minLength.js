"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.minLength = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates the length of a string or array.
 *
 * @param requirement The minimum length.
 * @param error The error message.
 *
 * @returns A validation function.
 */
function minLength(requirement, error) {
    return (input) => input.length < requirement
        ? (0, index_js_1.getPipeIssues)('min_length', error || 'Invalid length', input)
        : (0, index_js_1.getOutput)(input);
}
exports.minLength = minLength;
