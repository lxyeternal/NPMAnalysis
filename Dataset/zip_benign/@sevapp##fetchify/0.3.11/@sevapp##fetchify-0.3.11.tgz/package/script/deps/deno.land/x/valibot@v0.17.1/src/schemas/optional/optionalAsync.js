"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.optionalAsync = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates an async optional schema.
 *
 * @param wrapped The wrapped schema.
 * @param default_ The default value.
 *
 * @returns An async optional schema.
 */
function optionalAsync(wrapped, default_) {
    return {
        /**
         * The schema type.
         */
        schema: 'optional',
        /**
         * The wrapped schema.
         */
        wrapped,
        /**
         * The default value.
         */
        get default() {
            return typeof default_ === 'function'
                ? default_()
                : default_;
        },
        /**
         * Whether it's async.
         */
        async: true,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            // Get default or input value
            const value = input === undefined ? await this.default : input;
            // Allow `undefined` value to pass
            if (value === undefined) {
                return (0, index_js_1.getOutput)(value);
            }
            // Return result of wrapped schema
            return wrapped._parse(value, info);
        },
    };
}
exports.optionalAsync = optionalAsync;
