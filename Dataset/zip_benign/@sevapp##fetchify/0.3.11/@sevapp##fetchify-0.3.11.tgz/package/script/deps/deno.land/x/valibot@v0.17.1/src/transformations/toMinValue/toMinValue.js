"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toMinValue = void 0;
/**
 * Creates a transformation function that sets a string, number or date to a
 * minimum value.
 *
 * @param requirement The minimum value.
 *
 * @returns A transformation function.
 */
function toMinValue(requirement) {
    return (input) => ({
        output: input < requirement ? requirement : input,
    });
}
exports.toMinValue = toMinValue;
