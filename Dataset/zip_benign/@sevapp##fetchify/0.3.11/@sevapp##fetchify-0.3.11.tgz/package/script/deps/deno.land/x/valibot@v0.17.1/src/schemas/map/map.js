"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.map = void 0;
const index_js_1 = require("../../utils/index.js");
function map(key, value, arg3, arg4) {
    // Get error and pipe argument
    const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg3, arg4);
    // Create and return map schema
    return {
        /**
         * The schema type.
         */
        schema: 'map',
        /**
         * The map key and value schema.
         */
        map: { key, value },
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Check type of input
            if (!(input instanceof Map)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'map', error || 'Invalid type', input);
            }
            // Create issues and output
            let issues;
            const output = new Map();
            // Parse each key and value by schema
            for (const [inputKey, inputValue] of input.entries()) {
                // Create path item variable
                let pathItem;
                // Get parse result of key
                const keyResult = key._parse(inputKey, {
                    origin: 'key',
                    abortEarly: info?.abortEarly,
                    abortPipeEarly: info?.abortPipeEarly,
                    skipPipe: info?.skipPipe,
                });
                // If there are issues, capture them
                if (keyResult.issues) {
                    // Create map path item
                    pathItem = {
                        schema: 'map',
                        input,
                        key: inputKey,
                        value: inputValue,
                    };
                    // Add modified result issues to issues
                    for (const issue of keyResult.issues) {
                        if (issue.path) {
                            issue.path.unshift(pathItem);
                        }
                        else {
                            issue.path = [pathItem];
                        }
                        issues?.push(issue);
                    }
                    if (!issues) {
                        issues = keyResult.issues;
                    }
                    // If necessary, abort early
                    if (info?.abortEarly) {
                        break;
                    }
                }
                // Get parse result of value
                const valueResult = value._parse(inputValue, info);
                // If there are issues, capture them
                if (valueResult.issues) {
                    // Create map path item
                    pathItem = pathItem || {
                        schema: 'map',
                        input,
                        key: inputKey,
                        value: inputValue,
                    };
                    // Add modified result issues to issues
                    for (const issue of valueResult.issues) {
                        if (issue.path) {
                            issue.path.unshift(pathItem);
                        }
                        else {
                            issue.path = [pathItem];
                        }
                        issues?.push(issue);
                    }
                    if (!issues) {
                        issues = valueResult.issues;
                    }
                    // If necessary, abort early
                    if (info?.abortEarly) {
                        break;
                    }
                }
                // Set entry if there are no issues
                if (!keyResult.issues && !valueResult.issues) {
                    output.set(keyResult.output, valueResult.output);
                }
            }
            // Return issues or pipe result
            return issues
                ? (0, index_js_1.getIssues)(issues)
                : (0, index_js_1.executePipe)(output, pipe, info, 'map');
        },
    };
}
exports.map = map;
