"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDefaultArgs = void 0;
/**
 * Returns error and pipe from dynamic arguments.
 *
 * @param arg1 First argument.
 * @param arg2 Second argument.
 *
 * @returns The default arguments.
 */
function getDefaultArgs(arg1, arg2) {
    return Array.isArray(arg1) ? [undefined, arg1] : [arg1, arg2];
}
exports.getDefaultArgs = getDefaultArgs;
