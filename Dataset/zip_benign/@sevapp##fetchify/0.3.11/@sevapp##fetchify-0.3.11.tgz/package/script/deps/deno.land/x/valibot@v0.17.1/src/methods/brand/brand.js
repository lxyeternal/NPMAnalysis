"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.brand = exports.BrandSymbol = void 0;
exports.BrandSymbol = Symbol('brand');
/**
 * Brands the output type of a schema.
 *
 * @param schema The scheme to be branded.
 * @param brand The brand name.
 *
 * @returns The branded schema.
 */
function brand(schema, 
// eslint-disable-next-line @typescript-eslint/no-unused-vars
name) {
    return schema;
}
exports.brand = brand;
