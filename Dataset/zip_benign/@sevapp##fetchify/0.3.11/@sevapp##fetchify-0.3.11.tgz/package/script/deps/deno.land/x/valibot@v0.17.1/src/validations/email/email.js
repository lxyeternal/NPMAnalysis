"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.email = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a validation functions that validates a email.
 *
 * Hint: The regex used is not perfect, but should work for most emails.
 *
 * @param error The error message.
 *
 * @returns A validation function.
 */
function email(error) {
    return (input) => !/^(([^<>()[\].,;:\s@"]+(\.[^<>()[\].,;:\s@"]+)*)|(".+"))@(([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{2,})$/i.test(input)
        ? (0, index_js_1.getPipeIssues)('email', error || 'Invalid email', input)
        : (0, index_js_1.getOutput)(input);
}
exports.email = email;
