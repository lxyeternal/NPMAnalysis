"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toTrimmedEnd = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a transformation function that removes the trailing white space and
 * line terminator characters from a string.
 *
 * @returns A transformation function.
 */
function toTrimmedEnd() {
    return (input) => (0, index_js_1.getOutput)(input.trimEnd());
}
exports.toTrimmedEnd = toTrimmedEnd;
