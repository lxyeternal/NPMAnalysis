"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.set = void 0;
const index_js_1 = require("../../utils/index.js");
function set(value, arg2, arg3) {
    // Get error and pipe argument
    const [error, pipe] = (0, index_js_1.getDefaultArgs)(arg2, arg3);
    // Create and return set schema
    return {
        /**
         * The schema type.
         */
        schema: 'set',
        /**
         * The set value schema.
         */
        set: { value },
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            // Check type of input
            if (!(input instanceof Set)) {
                return (0, index_js_1.getSchemaIssues)(info, 'type', 'set', error || 'Invalid type', input);
            }
            // Create key, output and issues
            let key = 0;
            let issues;
            const output = new Set();
            // Parse each value by schema
            for (const inputValue of input) {
                // Get parse result of input value
                const result = value._parse(inputValue, info);
                // If there are issues, capture them
                if (result.issues) {
                    // Create set path item
                    const pathItem = {
                        schema: 'set',
                        input,
                        key,
                        value: inputValue,
                    };
                    // Add modified result issues to issues
                    for (const issue of result.issues) {
                        if (issue.path) {
                            issue.path.unshift(pathItem);
                        }
                        else {
                            issue.path = [pathItem];
                        }
                        issues?.push(issue);
                    }
                    if (!issues) {
                        issues = result.issues;
                    }
                    // If necessary, abort early
                    if (info?.abortEarly) {
                        break;
                    }
                    // Otherwise, add item to set
                }
                else {
                    output.add(result.output);
                }
                // Increment key
                key++;
            }
            // Return issues or pipe result
            return issues
                ? (0, index_js_1.getIssues)(issues)
                : (0, index_js_1.executePipe)(output, pipe, info, 'set');
        },
    };
}
exports.set = set;
