"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.stripAsync = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates an object schema that strips unknown keys.
 *
 * @param schema A object schema.
 *
 * @returns A object schema.
 */
function stripAsync(schema) {
    // Create cached keys
    let cachedKeys;
    // Create and return object schema
    return {
        ...schema,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            // Get parse result of schema
            const result = await schema._parse(input, info);
            // Return result if there are issues
            if (result.issues) {
                return result;
            }
            // Cache object keys lazy
            cachedKeys = cachedKeys || Object.keys(schema.object);
            // Strip unknown keys
            const output = {};
            for (const key of cachedKeys) {
                output[key] = result.output[key];
            }
            // Return stripped output
            return (0, index_js_1.getOutput)(output);
        },
    };
}
exports.stripAsync = stripAsync;
