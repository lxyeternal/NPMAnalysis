"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.never = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a never schema.
 *
 * @param error The error message.
 *
 * @returns A never schema.
 */
function never(error) {
    return {
        /**
         * The schema type.
         */
        schema: 'never',
        /**
         * Whether it's async.
         */
        async: false,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        _parse(input, info) {
            return (0, index_js_1.getSchemaIssues)(info, 'type', 'never', error || 'Invalid type', input);
        },
    };
}
exports.never = never;
