"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getErrorMessage = void 0;
/**
 * Returns the final string of the error message.
 *
 * @param error The error message.
 *
 * @returns The error message.
 */
function getErrorMessage(error) {
    return typeof error === 'function' ? error() : error;
}
exports.getErrorMessage = getErrorMessage;
