"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.strictAsync = void 0;
const index_js_1 = require("../../utils/index.js");
/**
 * Creates a strict async object schema that throws an error if an input
 * contains unknown keys.
 *
 * @param schema A object schema.
 * @param error The error message.
 *
 * @returns A strict object schema.
 */
function strictAsync(schema, error) {
    return {
        ...schema,
        /**
         * Parses unknown input based on its schema.
         *
         * @param input The input to be parsed.
         * @param info The parse info.
         *
         * @returns The parsed output.
         */
        async _parse(input, info) {
            const result = await schema._parse(input, info);
            return !result.issues &&
                Object.keys(input).some((key) => !(key in schema.object))
                ? (0, index_js_1.getSchemaIssues)(info, 'object', 'strict', error || 'Invalid keys', input)
                : result;
        },
    };
}
exports.strictAsync = strictAsync;
