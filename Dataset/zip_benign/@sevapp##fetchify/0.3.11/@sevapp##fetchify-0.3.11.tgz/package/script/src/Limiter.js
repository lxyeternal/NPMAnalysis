"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var __classPrivateFieldSet = (this && this.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var _Limiter_instances, _Limiter_options, _Limiter_queue, _Limiter_iterationStartTime, _Limiter_requestsPerIteration, _Limiter_loopIsWorking, _Limiter_timeoutAfter429, _Limiter_fetchThen, _Limiter_fetchCatch, _Limiter_fetchFinally, _Limiter_loop, _Limiter_limitedFetch;
Object.defineProperty(exports, "__esModule", { value: true });
exports.Limiter = void 0;
const dntShim = __importStar(require("../_dnt.shims.js"));
const deps_js_1 = require("../deps.js");
const fetchWithTimeout_js_1 = require("./fetchWithTimeout.js");
const helpers_js_1 = require("./helpers.js");
class Limiter {
    constructor(options) {
        _Limiter_instances.add(this);
        _Limiter_options.set(this, {
            rps: 1,
        });
        _Limiter_queue.set(this, []);
        _Limiter_iterationStartTime.set(this, 0);
        _Limiter_requestsPerIteration.set(this, 0);
        _Limiter_loopIsWorking.set(this, false);
        _Limiter_timeoutAfter429.set(this, 0);
        if (options) {
            __classPrivateFieldSet(this, _Limiter_options, { ...__classPrivateFieldGet(this, _Limiter_options, "f"), ...options }, "f");
        }
    }
    static fetch(input, init) {
        let promise = undefined;
        const url = new URL((0, helpers_js_1.getUrlFromStringOrRequest)(input));
        if (init?.params)
            url.search = (0, helpers_js_1.objectToQueryParams)(init.params);
        if (init && init.timeout) {
            promise = (0, fetchWithTimeout_js_1.fetchWithTimeout)(url, init.timeout, init);
        }
        else {
            promise = dntShim.fetch(url, init);
        }
        return promise;
    }
    fetch(input, init) {
        return init && init.unlimited === true
            ? Limiter.fetch(input, init)
            : __classPrivateFieldGet(this, _Limiter_instances, "m", _Limiter_limitedFetch).call(this, input, init);
    }
}
exports.Limiter = Limiter;
_Limiter_options = new WeakMap(), _Limiter_queue = new WeakMap(), _Limiter_iterationStartTime = new WeakMap(), _Limiter_requestsPerIteration = new WeakMap(), _Limiter_loopIsWorking = new WeakMap(), _Limiter_timeoutAfter429 = new WeakMap(), _Limiter_instances = new WeakSet(), _Limiter_fetchThen = function _Limiter_fetchThen(entity, response) {
    if (__classPrivateFieldGet(this, _Limiter_options, "f").rt && response.status == 429) {
        __classPrivateFieldSet(this, _Limiter_timeoutAfter429, __classPrivateFieldGet(this, _Limiter_options, "f").rt(response), "f");
    }
    if (__classPrivateFieldGet(this, _Limiter_options, "f").status && __classPrivateFieldGet(this, _Limiter_options, "f").status[response.status]) {
        __classPrivateFieldGet(this, _Limiter_options, "f").status[response.status](response, entity.resolve, entity.reject, () => {
            if (entity.init?.attempts != undefined &&
                entity.attempt < entity.init?.attempts) {
                entity.attempt += 1;
                __classPrivateFieldGet(this, _Limiter_queue, "f").push(entity);
            }
            else {
                entity.reject(new Error("max attempts!"));
            }
        });
    }
    else {
        entity.resolve(response);
    }
}, _Limiter_fetchCatch = function _Limiter_fetchCatch(entity, error) {
    if (entity.init?.attempts != undefined &&
        entity.attempt < entity.init?.attempts) {
        entity.attempt += 1;
        __classPrivateFieldGet(this, _Limiter_queue, "f").push(entity);
    }
    else {
        entity.reject(error);
    }
}, _Limiter_fetchFinally = function _Limiter_fetchFinally(enitty) {
    var _a;
    if (__classPrivateFieldGet(this, _Limiter_requestsPerIteration, "f") > 0)
        __classPrivateFieldSet(this, _Limiter_requestsPerIteration, (_a = __classPrivateFieldGet(this, _Limiter_requestsPerIteration, "f"), _a--, _a), "f");
}, _Limiter_loop = async function _Limiter_loop() {
    var _a;
    __classPrivateFieldSet(this, _Limiter_iterationStartTime, new Date().getTime(), "f");
    while (true) {
        if (__classPrivateFieldGet(this, _Limiter_timeoutAfter429, "f") > 0) {
            await (0, deps_js_1.delay)(__classPrivateFieldGet(this, _Limiter_timeoutAfter429, "f"));
            __classPrivateFieldSet(this, _Limiter_timeoutAfter429, 0, "f");
        }
        if (__classPrivateFieldGet(this, _Limiter_requestsPerIteration, "f") >= __classPrivateFieldGet(this, _Limiter_options, "f").rps) {
            await (0, deps_js_1.delay)(0);
            continue;
        }
        const entity = __classPrivateFieldGet(this, _Limiter_queue, "f").shift();
        if (entity) {
            __classPrivateFieldSet(this, _Limiter_requestsPerIteration, (_a = __classPrivateFieldGet(this, _Limiter_requestsPerIteration, "f"), _a++, _a), "f");
            console.log(entity.input.toString());
            if (entity.init?.timeout && entity.init?.timeout > 0) {
                (0, fetchWithTimeout_js_1.fetchWithTimeout)(entity.input, entity.init.timeout, entity.init)
                    .then((response) => __classPrivateFieldGet(this, _Limiter_instances, "m", _Limiter_fetchThen).call(this, entity, response))
                    .catch((error) => __classPrivateFieldGet(this, _Limiter_instances, "m", _Limiter_fetchCatch).call(this, entity, error))
                    .finally(() => __classPrivateFieldGet(this, _Limiter_instances, "m", _Limiter_fetchFinally).call(this, entity));
            }
            else {
                dntShim.fetch(entity.input, entity.init)
                    .then((response) => __classPrivateFieldGet(this, _Limiter_instances, "m", _Limiter_fetchThen).call(this, entity, response))
                    .catch((error) => __classPrivateFieldGet(this, _Limiter_instances, "m", _Limiter_fetchCatch).call(this, entity, error))
                    .finally(() => __classPrivateFieldGet(this, _Limiter_instances, "m", _Limiter_fetchFinally).call(this, entity));
            }
        }
        if (__classPrivateFieldGet(this, _Limiter_queue, "f").length == 0 && __classPrivateFieldGet(this, _Limiter_requestsPerIteration, "f") == 0) {
            __classPrivateFieldSet(this, _Limiter_loopIsWorking, !__classPrivateFieldGet(this, _Limiter_loopIsWorking, "f"), "f");
            return;
        }
        if (!entity && __classPrivateFieldGet(this, _Limiter_iterationStartTime, "f") > 0) {
            await (0, deps_js_1.delay)(0);
        }
        if (__classPrivateFieldGet(this, _Limiter_requestsPerIteration, "f") == __classPrivateFieldGet(this, _Limiter_options, "f").rps) {
            const timeOffset = __classPrivateFieldGet(this, _Limiter_iterationStartTime, "f") + 1000 -
                new Date().getTime();
            await (0, deps_js_1.delay)(timeOffset);
            __classPrivateFieldSet(this, _Limiter_requestsPerIteration, 0, "f");
            __classPrivateFieldSet(this, _Limiter_iterationStartTime, new Date().getTime(), "f");
        }
    }
}, _Limiter_limitedFetch = function _Limiter_limitedFetch(input, init) {
    const url = new URL((0, helpers_js_1.getUrlFromStringOrRequest)(input));
    if (init?.params)
        url.search = (0, helpers_js_1.objectToQueryParams)(init.params);
    const promise = new Promise((resolve, reject) => {
        __classPrivateFieldGet(this, _Limiter_queue, "f").push({
            input: url,
            init,
            resolve,
            reject,
            attempt: 1,
        });
    });
    if (!__classPrivateFieldGet(this, _Limiter_loopIsWorking, "f")) {
        __classPrivateFieldSet(this, _Limiter_loopIsWorking, !__classPrivateFieldGet(this, _Limiter_loopIsWorking, "f"), "f");
        __classPrivateFieldGet(this, _Limiter_instances, "m", _Limiter_loop).call(this);
    }
    return promise;
};
