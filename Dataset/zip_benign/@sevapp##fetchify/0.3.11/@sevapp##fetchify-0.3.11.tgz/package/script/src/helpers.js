"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.combineURL = exports.getUrlFromStringOrRequest = exports.objectToQueryParams = void 0;
const dntShim = __importStar(require("../_dnt.shims.js"));
const objectToQueryParams = (params) => {
    return Object.entries(params)
        .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
        .join("&");
};
exports.objectToQueryParams = objectToQueryParams;
const getUrlFromStringOrRequest = (input) => {
    if (input instanceof URL) {
        return input.toString();
    }
    else if (input instanceof dntShim.Request) {
        return input.url;
    }
    else {
        return input;
    }
};
exports.getUrlFromStringOrRequest = getUrlFromStringOrRequest;
const combineURL = (baseURL, path, params) => {
    const url = new URL((0, exports.getUrlFromStringOrRequest)(baseURL), (0, exports.getUrlFromStringOrRequest)(path));
    if (params)
        url.search = (0, exports.objectToQueryParams)(params);
    return url;
};
exports.combineURL = combineURL;
