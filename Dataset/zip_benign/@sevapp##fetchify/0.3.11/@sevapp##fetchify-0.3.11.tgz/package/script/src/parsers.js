"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.jsonZ = exports.jsonV = exports.json = exports.text = void 0;
const deps_js_1 = require("../deps.js");
const text = async (promise) => {
    const response = await promise;
    const data = await response.text();
    return { data, response };
};
exports.text = text;
const json = async (promise, schema) => {
    const response = await promise;
    const data = await response.json();
    return { data, response };
};
exports.json = json;
const jsonV = async (promise, schema) => {
    const response = await promise;
    return {
        data: deps_js_1.v.parse(schema, await response.json()),
        response,
    };
};
exports.jsonV = jsonV;
const jsonZ = async (promise, schema) => {
    const response = await promise;
    return {
        data: schema.parse(await response.json()),
        response,
    };
};
exports.jsonZ = jsonZ;
