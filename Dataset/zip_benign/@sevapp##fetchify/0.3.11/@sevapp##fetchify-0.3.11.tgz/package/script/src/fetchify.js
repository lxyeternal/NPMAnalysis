"use strict";
var __classPrivateFieldSet = (this && this.__classPrivateFieldSet) || function (receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
};
var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _Fetchify_instances, _Fetchify_config, _Fetchify_limiter, _Fetchify_request;
Object.defineProperty(exports, "__esModule", { value: true });
exports.Fetchify = exports.fetchify = void 0;
const mod_js_1 = require("../mod.js");
const helpers_js_1 = require("./helpers.js");
const fetchify = (input, init) => {
    return mod_js_1.Limiter.fetch(input, init);
};
exports.fetchify = fetchify;
exports.fetchify.create = (options) => {
    return new Fetchify(options);
};
class Fetchify {
    constructor(config) {
        _Fetchify_instances.add(this);
        _Fetchify_config.set(this, {});
        _Fetchify_limiter.set(this, void 0);
        __classPrivateFieldSet(this, _Fetchify_limiter, new mod_js_1.Limiter(config?.limiter), "f");
        __classPrivateFieldSet(this, _Fetchify_config, { ...__classPrivateFieldGet(this, _Fetchify_config, "f"), ...config }, "f");
    }
    get(input, init) {
        return __classPrivateFieldGet(this, _Fetchify_instances, "m", _Fetchify_request).call(this, "GET", input, init);
    }
    post(input, init) {
        return __classPrivateFieldGet(this, _Fetchify_instances, "m", _Fetchify_request).call(this, "POST", input, init);
    }
    put(input, init) {
        return __classPrivateFieldGet(this, _Fetchify_instances, "m", _Fetchify_request).call(this, "PUT", input, init);
    }
    delete(input, init) {
        return __classPrivateFieldGet(this, _Fetchify_instances, "m", _Fetchify_request).call(this, "DELETE", input, init);
    }
    head(input, init) {
        return __classPrivateFieldGet(this, _Fetchify_instances, "m", _Fetchify_request).call(this, "HEAD", input, init);
    }
    patch(input, init) {
        return __classPrivateFieldGet(this, _Fetchify_instances, "m", _Fetchify_request).call(this, "PATH", input, init);
    }
}
exports.Fetchify = Fetchify;
_Fetchify_config = new WeakMap(), _Fetchify_limiter = new WeakMap(), _Fetchify_instances = new WeakSet(), _Fetchify_request = function _Fetchify_request(method, input, init) {
    return __classPrivateFieldGet(this, _Fetchify_limiter, "f").fetch(__classPrivateFieldGet(this, _Fetchify_config, "f").baseURL
        ? (0, helpers_js_1.combineURL)(input, __classPrivateFieldGet(this, _Fetchify_config, "f").baseURL)
        : (0, helpers_js_1.getUrlFromStringOrRequest)(input), {
        method,
        ...init,
        headers: __classPrivateFieldGet(this, _Fetchify_config, "f").headers,
    });
};
