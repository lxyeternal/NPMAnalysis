"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.z = exports.v = exports.Limiter = void 0;
const deps_js_1 = require("./deps.js");
Object.defineProperty(exports, "v", { enumerable: true, get: function () { return deps_js_1.v; } });
Object.defineProperty(exports, "z", { enumerable: true, get: function () { return deps_js_1.z; } });
const Limiter_js_1 = require("./src/Limiter.js");
Object.defineProperty(exports, "Limiter", { enumerable: true, get: function () { return Limiter_js_1.Limiter; } });
const fetchify_js_1 = require("./src/fetchify.js");
__exportStar(require("./src/parsers.js"), exports);
exports.default = fetchify_js_1.fetchify;
