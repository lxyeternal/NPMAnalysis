import { IFrame, MainAreaWidget } from '@jupyterlab/apputils';
import { JSONObject } from '@lumino/coreutils';
import { Message } from '@lumino/messaging';
import { Widget } from '@lumino/widgets';
/**
 * A class for hosting a Bokeh dashboard in an iframe.
 */
export declare class BokehDashboard extends MainAreaWidget<IFrame> {
    /**
     * Construct a new dashboard widget.
     */
    constructor();
    /**
     * The current dashboard item for the widget.
     */
    item: IDashboardItem | null;
    /**
     * Handle an update request to the dashboard panel.
     */
    protected onUpdateRequest(): void;
    private _item;
    private _inactivePanel;
}
/**
 * A widget for hosting Bokeh dashboard launchers.
 */
export declare class BokehDashboardLauncher extends Widget {
    /**
     * Create a new Bokeh sidebar.
     */
    constructor(options: BokehDashboardLauncher.IOptions);
    /**
     * The list of dashboard items which can be launched.
     */
    readonly items: IDashboardItem[];
    /**
     * Handle an update request.
     */
    protected onUpdateRequest(msg: Message): void;
    /**
     * Rerender after showing.
     */
    protected onAfterShow(msg: Message): void;
    private _dashboard;
    private _launchItem;
    private _items;
    private _connection;
}
/**
 * A namespace for BokehDashboardLauncher statics.
 */
export declare namespace BokehDashboardLauncher {
    /**
     * Options for the constructor.
     */
    interface IOptions {
        /**
         * A function that attempts to find a link to
         * a bokeh bokeh server in the current application
         * context.
         */
        linkFinder?: () => Promise<string>;
        /**
         * A callback to launch a dashboard item.
         */
        launchItem: (item: IDashboardItem) => void;
        /**
         * A list of items for the launcher.
         */
        items?: IDashboardItem[];
    }
}
/**
 * Props for the dashboard listing component.
 */
export interface IDashboardListingProps {
    /**
     * A list of dashboard items to render.
     */
    items: IDashboardItem[];
    /**
     * A callback to launch a dashboard item.
     */
    launchItem: (item: IDashboardItem) => void;
}
/**
 * An interface dashboard launcher item.
 */
export interface IDashboardItem extends JSONObject {
    /**
     * The route to add the the base url.
     */
    route: string;
    /**
     * The display label for the item.
     */
    label: string;
}
