import { Observable } from 'rxjs';
export declare type ALL = '__ALL__';
export declare type Options<Messages> = {
    onCycle(chain: (keyof Messages | ALL)[]): void;
    isDevMode: boolean;
};
export declare class Emitter<Messages extends object> {
    private emitterState;
    constructor(options?: Partial<Options<Messages>>);
    /**
     * Emit an event (silently fails if no listeners are hooked up yet)
     */
    emit<K extends keyof Messages>(key: K, value: Messages[K]): this;
    /**
     * Subscribe to an event
     */
    on<K extends keyof Messages>(key: K): Observable<Messages[K]>;
    /**
     * Subscribe to all events
     */
    all(): Observable<Messages[keyof Messages]>;
    private createChannel;
    private deleteChannel;
    private emitOnChannel;
    private hasChannel;
}
