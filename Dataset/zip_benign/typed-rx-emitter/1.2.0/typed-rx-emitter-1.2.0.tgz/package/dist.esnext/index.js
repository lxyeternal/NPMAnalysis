import { Observable } from 'rxjs';
const ALL = '__ALL__';
export class Emitter {
    constructor(options) {
        let DEFAULT_OPTIONS = {
            isDevMode: false,
            onCycle(chain) {
                console.error('[typed-rx-emitter] Error: Cyclical dependency detected. '
                    + 'This may cause a stack overflow unless you fix it. '
                    + chain.join(' -> '));
            }
        };
        this.emitterState = {
            callChain: new Set,
            observables: new Map,
            observers: new Map,
            options: { ...DEFAULT_OPTIONS, ...options }
        };
    }
    /**
     * Emit an event (silently fails if no listeners are hooked up yet)
     */
    emit(key, value) {
        let { isDevMode, onCycle } = this.emitterState.options;
        if (isDevMode) {
            if (this.emitterState.callChain.has(key)) {
                onCycle(Array.from(this.emitterState.callChain).concat(key));
                return this;
            }
            else {
                this.emitterState.callChain.add(key);
            }
        }
        if (this.hasChannel(key)) {
            this.emitOnChannel(key, value);
        }
        if (this.hasChannel(ALL)) {
            this.emitOnChannel(ALL, value);
        }
        if (isDevMode)
            this.emitterState.callChain.clear();
        return this;
    }
    /**
     * Subscribe to an event
     */
    on(key) {
        return this.createChannel(key);
    }
    /**
     * Subscribe to all events
     */
    all() {
        return this.createChannel(ALL);
    }
    ///////////////////// privates /////////////////////
    createChannel(key) {
        if (!this.emitterState.observers.has(key)) {
            this.emitterState.observers.set(key, []);
        }
        if (!this.emitterState.observables.has(key)) {
            this.emitterState.observables.set(key, []);
        }
        const observable = Observable
            .create((_) => {
            this.emitterState.observers.get(key).push(_);
            return () => this.deleteChannel(key, observable);
        });
        this.emitterState.observables.get(key).push(observable);
        return observable;
    }
    deleteChannel(key, observable) {
        if (!this.emitterState.observables.has(key)) {
            return;
        }
        const array = this.emitterState.observables.get(key);
        const index = array.indexOf(observable);
        if (index < 0) {
            return;
        }
        array.splice(index, 1);
        if (!array.length) {
            this.emitterState.observables.delete(key);
            this.emitterState.observers.delete(key);
        }
    }
    emitOnChannel(key, value) {
        this.emitterState.observers.get(key).forEach(_ => _.next(value));
    }
    hasChannel(key) {
        return this.emitterState.observables.has(key);
    }
}
//# sourceMappingURL=index.js.map