class FuzzyBoolean {
	constructor(truth_value=0.5) {
		if (truth_value instanceof FuzzyBoolean) this.truth_value = truth_value.truth_value;
		else {
			this.truth_value = Number(truth_value);
			if (Number.isNaN(this.truth_value)) this.truth_value = 0.5;
			if (this.truth_value < 0) this.truth_value = 0;
			if (this.truth_value > 1) this.truth_value = 1;
		}
	}
	
	valueOf() {
		return Math.random() < this.truth_value;
	}
	
	realBoolean() {
		if (this.truth_value === 1) return true;
		if (this.truth_value === 0) return false;
		return null;
	}
	
	closestBoolean() {
		return this.truth_value >= 0.5;
	}
	
	not() {
		return new FuzzyBoolean(1 - this.truth_value);
	}
	
	and(value) {
		return new FuzzyBoolean(this.truth_value * new FuzzyBoolean(value).truth_value);
	}
	
	or(value) {
		return this.sub(this.and(value)).add(value);
	}
	
	xor(value) {
		return this.or(value).sub(this.and(value));
	}
	
	min(value) {
		return new FuzzyBoolean(Math.min(this.truth_value, new FuzzyBoolean(value).truth_value));
	}
	
	max(value) {
		return new FuzzyBoolean(Math.max(this.truth_value, new FuzzyBoolean(value).truth_value));
	}
	
	add(value) {
		return new FuzzyBoolean(this.truth_value + new FuzzyBoolean(value).truth_value);
	}
	
	sub(value) {
		return new FuzzyBoolean(this.truth_value - new FuzzyBoolean(value).truth_value);
	}
	
	btw(value) {
		return new FuzzyBoolean((this.truth_value + new FuzzyBoolean(value).truth_value)/2);
	}
}

module.exports = FuzzyBoolean;
