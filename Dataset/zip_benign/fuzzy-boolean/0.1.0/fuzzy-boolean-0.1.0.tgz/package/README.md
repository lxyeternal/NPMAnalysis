# fuzzy-boolean

This package contains the class `FuzzyBoolean` that uses a truth value between 0 and 1, and returns a random boolean in `valueOf()` that varies depending on the current truth value.

# Install

```bash
npm install fuzzy-boolean
```

# Fields and Methods

`FuzzyBoolean` class :
* `truth_value`: The truth value of the fuzzy boolean
* `constructor(truth_value=0.5)`
* Boolean returners :
  * `valueOf()`: Returns a random boolean, with `truth_value` being the probability of returning `true`
  * `realBoolean()`: Returns the strict boolean equivalent, `null` otherwise
  * `closestBoolean()`: Returns the boolean that corresponds the most (If `truth_value` is one-half, returns `true`)
* Operations :
  * `not()`, `and(value)`, `or(value)`, `xor(value)`, `min(value)`, `max(value)`, `add(value)`, `sub(value)`, `btw(value)`

Values are automatically transformed into `FuzzyBoolean` if it's not already the case.

# Example

```javascript
var FuzzyBoolean = require('fuzzy-boolean');

var heroHP = 200;
var enemyHP = 200;
var criticalHit = new FuzzyBoolean(0.4);
var useEffect = new FuzzyBoolean(0.25);

while (heroHP > 0) {
	console.log("Hero: " + heroHP + " HP, Enemy: " + enemyHP + " HP");
	
	var damages = 25 + criticalHit * 15;
	enemyHP -= damages;
	console.log("Your enemy lost " + damages + " HP");
	if (enemyHP <= 0) {
		console.log("");
		break;
	}
	
	// You can't use a fuzzy boolean alone, because it would return the object instead of the value given by valueOf()
	// You can instead do useEfect==true, useEffect&true, useEffect^false, useEffect.valueOf(), etc.
	if (useEffect == true) {
		console.log("The enemy used an effect");
		criticalHit = criticalHit.and(0.5);
		console.log("Critical hits will now occur 50% less frequently");
	}
	heroHP -= 30;
	console.log("You lost 30 HP");
	console.log("");
}
if (heroHP > 0) console.log("You won!");
else console.log("You lost...");
```

# License

[WTFPL](http://www.wtfpl.net/)
