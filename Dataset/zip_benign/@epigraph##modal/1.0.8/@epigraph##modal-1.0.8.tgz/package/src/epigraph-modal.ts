/* @license
 * Copyright 2021 Epigraph LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { LitElement, html, css, TemplateResult } from "lit";
import { createRef, Ref, ref } from "lit/directives/ref.js";
import { customElement, property } from "lit/decorators.js";

/**
 * An example element.
 *
 * @slot - This element has a slot
 * @csspart button - The button
 */
@customElement("epigraph-modal")
export class EpigraphModal extends LitElement {
	static styles = css`
		:host {
			border: none;
			padding: 0;
			height: inherit;
			width: 100%;
			display: flex;
			flex-direction: column;
			align-items: center;
		}

		:host * {
			transition: 0.1s ease-in-out;
			box-sizing: border-box;
		}

		.modal-background {
			position: fixed;
			background-color: rgba(0, 0, 0, 0.5);
			transition: opacity 700ms;
			visibility: hidden;
			opacity: 0;
			width: 100%;
			height: 100%;
			display: flex;
			top: -100%;
			z-index: 9999998;
		}

		.modal-background.show {
			transition: opacity 700ms top 500ms;
			visibility: visible;
			opacity: 1;
			top: 0;
		}

		.modal {
			font-family: Roboto;
			position: fixed;
			box-shadow: rgba(0, 0, 0, 0.15) 0px 3px 15px;
			background: rgb(255, 255, 255);
			transition: opacity 700ms;
			transition-delay: 200ms;
			visibility: hidden;
			opacity: 0;
			top: -100%;
			width: 645px;
			height: 640px;
			padding: 25px 45px;
			display: flex;
			flex-direction: column;
			z-index: 9999999;
		}

		.modal.show {
			transition: opacity 700ms, top 500ms;
			visibility: visible;
			opacity: 1;
			top: 50%;
			transform: translateY(-50%);
		}

		/* .show {
			transition: opacity 700ms, top 500ms;
			visibility: visible;
			opacity: 1;
		} */

		.modal-close {
			opacity: 0.5;
			position: absolute;
			width: 22px;
			height: 22px;
			top: 25px;
			right: 25px;
			cursor: pointer;
		}

		.modal-done {
			cursor: pointer;
			color: #ffffff;
			width: 81px;
			height: 48px;
			font-size: 16px;
			align-self: center;
			display: flex;
			flex-direction: row;
			align-items: center;
			justify-content: center;
			opacity: 0.5;
			padding: 12px 22px;
			margin-top: 26.08px;
			border: 0;
			border-radius: 5px;
			background-color: #3f82f9;
		}

		.modal-done:active {
			transform: translate3d(0, 2px, 0);
		}

		.modal-close:hover,
		.modal-done:hover {
			opacity: 1;
		}

		.modal-close:active {
			transform: translateY(2px);
		}

		.modal-title-text {
			margin-top: 50px;
			font-size: 28px;
			font-weight: 500;
			line-height: 33px;
			color: #1f1f1f;
		}

		.modal-text-instructions {
			width: 492px;
			height: 81px;
			font-size: 18px;
			line-height: 27px;
			color: #404040;
		}

		.modal-tech-requirement {
			font-size: 16px;
			line-height: 24px;
			color: #3f82f9;
		}

		.modal-qr-container {
			margin-top: 53px;
			display: flex;
			flex-direction: row;
			justify-content: center;
			align-items: center;
		}

		.modal-qr-img {
			width: 200px;
			height: 200px;
		}
	`;

	@property({
		type: String,
		reflect: true,
		attribute: "modal-background-style",
	})
	modalBackgroundStyle = "";
	@property({ type: String, reflect: true, attribute: "modal-style" })
	modalStyle = "";
	@property({ type: String, reflect: true, attribute: "close-button-style" })
	closeButtonStyle = "";
	@property({ type: String, reflect: true, attribute: "title-text-style" })
	titleTextStyle = "";
	@property({ type: String, reflect: true, attribute: "instruction-style" })
	instructionStyle = "";
	@property({
		type: String,
		reflect: true,
		attribute: "tech-requirement-style",
	})
	techReqStyle = "";
	@property({
		type: String,
		reflect: true,
		attribute: "qr-image-container-style",
	})
	qrImageContainerStyle = "";
	@property({ type: String, reflect: true, attribute: "qr-image-src" })
	qrImageSrc = "";
	@property({ type: String, reflect: true, attribute: "done-button-style" })
	doneButtonStyle = "";

	// private _cacheTimeout = setTimeout(() => {}, 100);
	private _modal: Ref<Element> = createRef();
	private _modalBackground: Ref<Element> = createRef();

	private _showElement(...input: Array<Element | undefined>) {
		input.forEach((itm) => itm?.classList.add("show"));
	}

	private _hideElement(...input: Array<Element | undefined>) {
		input.forEach((itm) => itm?.classList.remove("show"));
	}

	private _renderModalBackground(): TemplateResult {
		return html`
			<div
				class="modal-background"
				style=${this.modalBackgroundStyle}
				@click=${() =>
					this._hideElement(this._modal.value, this._modalBackground.value)}
				${ref(this._modalBackground)}
			></div>
		`;
	}

	private _renderModal(): TemplateResult {
		return html`
			<div class="modal" style=${this.modalStyle} ${ref(this._modal)}>
				${this._renderCloseButton()}
				<slot name="modal-content">
					${this._renderTitle()}
					<br />
					${this._renderInstruction()}
					<br />
					${this._renderTechRequirement()} ${this._renderModalImage()}
				</slot>
				${this._renderDoneButton()}
			</div>
		`;
	}

	private _renderCloseButton(): TemplateResult {
		if (!this._modal || !this._modalBackground) {
			return html``;
		}

		return html`
			<slot
				name="modal-close"
				@click=${() =>
					this._hideElement(this._modal.value, this._modalBackground.value)}
			>
				<span class="modal-close" style=${this.closeButtonStyle}>
					<svg
						width="22"
						height="22"
						viewBox="0 0 22 22"
						fill="none"
						xmlns="http://www.w3.org/2000/svg"
					>
						<path
							d="M1 1L22 22"
							stroke="#404040"
							stroke-width="2"
							stroke-linecap="round"
							stroke-linejoin="round"
						/>
						<path
							d="M22 1L1 22"
							stroke="#404040"
							stroke-width="2"
							stroke-linecap="round"
							stroke-linejoin="round"
						/>
					</svg>
				</span>
			</slot>
		`;
	}

	private _renderTitle(): TemplateResult {
		return html`
			<slot name="modal-title">
				<div class="modal-title-text" style=${this.titleTextStyle}>
					Scan the QR code to view this item in your space.
				</div>
			</slot>
		`;
	}

	private _renderInstruction(): TemplateResult {
		return html`
			<slot name="modal-instruction">
				<div class="modal-text-instructions" style=${this.instructionStyle}>
					Using your mobile device* camera, scan the QR code below and follow
					the on-screen directions to see how this item looks in your space.
				</div>
			</slot>
		`;
	}

	private _renderTechRequirement(): TemplateResult {
		return html`
			<slot name="modal-requirement">
				<div class="modal-tech-requirement" style=${this.techReqStyle}>
					*Technical requirements: iOS Version 11 and later or Android 8 and
					later.
				</div>
			</slot>
		`;
	}

	private _renderModalImage(): TemplateResult {
		return html`
			<slot name="modal-image">
				<div class="modal-qr-container" style=${this.qrImageContainerStyle}>
					<img
						class="modal-qr-image"
						src=${this.qrImageSrc}
						style="width: 200px; height: 200px;"
					/>
				</div>
			</slot>
		`;
	}

	private _renderDoneButton(): TemplateResult {
		if (!this._modal || !this._modalBackground) {
			return html``;
		}

		return html`
			<slot
				name="modal-done"
				@click=${() =>
					this._hideElement(this._modal.value, this._modalBackground.value)}
			>
				<button class="modal-done" style=${this.doneButtonStyle}>Done</button>
			</slot>
		`;
	}

	protected render() {
		return html` ${this._renderModalBackground()} ${this._renderModal()} `;
	}

	public show() {
		this._showElement(this._modal.value, this._modalBackground.value);
	}

	public hide() {
		this._hideElement(this._modal.value, this._modalBackground.value);
	}
}

declare global {
	interface HTMLElementTagNameMap {
		"epigraph-modal": EpigraphModal;
	}
}
