# Epigraph Modal

This project includes a sample component using LitElement with TypeScript.

## Import

You need to import our web component module. We recommend that you do this in the head. It's important that `type="module"` is specified.

### Example

```html
<head>
  <script type="module" async src="https://www.unpkg.com/@epigraph/modal/dist/epigraph-modal.min.js"></script>
</head>
```

## Usage

You can insert epigraph-modal elements anywhere you'd like. Epigraph modal currently serves one purpose: to embed a responsive, customizable modal directly in your page.

## Attributes

1. **`modal-background-style`**: [String, optional] Allows you to add additional styling onto the default modal background styling. This is a reactive attribute, so changing the attribute will force a modal reload.
2. **`modal-style`**: [String, optional] Allows you to add additional styling onto the default modal styling. This is a reactive attribute, so changing the attribute will force a modal reload.
3. **`close-button-style`**: [String, optional] Allows you to add additional styling onto the default close button styling. This is a reactive attribute, so changing the attribute will force a modal reload.
4. **`done-button-style`**: [String, optional] Allows you to add additional styling onto the default done button styling. This is a reactive attribute, so changing the attribute will force a modal reload.

### Example: Modal for all platforms

```html
<epigraph-modal modal-background-style="background-color: rgba(0, 255, 0, 0.5);">
  <div class="modal-content" slot="modal-content">
    <div class="modal-text">
      <div class="modal-text-scan-line">
        Scan the QR code to view this item in your space.
      </div>
      <br />
      <div class="modal-text-instructions">
        Using your mobile device* camera, scan the QR code below and
        follow the on-screen directions to see how this item looks in
        your space. <br />
        <br />
        *Technical requirements: iOS Version 11 and later or Android 8
        and later.
      </div>
    </div>
    <div class="modal-qr-container">
      <img class="modal-qr-image"
        src="qr-source-image.png" />
    </div>
  </div>
</epigraph-modal>
```

## Events/Event Listeners

Currently the modal is shown upon receiving a `show-modal` event.

### Example: dispatching an event

```JavaScript
window.onload = () => {
    document.querySelector('epigraph-modal').dispatchEvent(new Event('show-modal'));
}
```

## Known Issues

Currently, the web component only nallows limited custom inline styling through the use of reactive properties, it is our hope that we will have more options in the future to allow more custom styling of the web component.
