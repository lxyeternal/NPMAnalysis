/*
 * grunt-dj-rename
 * http://gruntjs.com/
 *
 * Copyright (c) 2015 Chris Talkington, contributors
 * Licensed under the MIT license.
 */

module.exports = function (grunt) {
  'use strict';

  var path = require('path');
  var fs = require('fs');
  var chalk = require('chalk');
  var fileSyncCmp = require('file-sync-cmp');

  grunt.registerMultiTask('rename', 'rename files.', function () {

    var options = this.options({
      encoding: grunt.file.defaultEncoding,
      // processContent/processContentExclude deprecated renamed to process/noProcess
      processContent: false,
      processContentExclude: [],
      timestamp: false,
      mode: false,
    });

    var copyOptions = {
      encoding: options.encoding,
      process: options.process || options.processContent,
      noProcess: options.noProcess || options.processContentExclude,
    };

    var isExpandedPair;
    var dirs = {};
    var tally = {
      dirs: 0,
      files: 0,
    };

    var ignoreFileList = {length: 0};
    var fileList = {length: 0};

    this.files.forEach(function (filePair) {
      isExpandedPair = filePair.orig.expand || false;

      filePair.src.forEach(function (src) {
        src = unixifyPath(src);
        var fileName = getFileName(src);

        if (!options.ignoreFile || !options.ignoreFile(src, fileName)) {
          var dest = unixifyPath(filePair.dest);

          if (detectDestType(dest) === 'directory') {
            dest = (isExpandedPair) ? dest : path.join(dest, src);
          }

          if (options.hanldeDest) {
            dest = unixifyPath(options.hanldeDest(dest, fileName, src));
          }

          if (grunt.file.isDir(src)) {
            grunt.verbose.writeln('Creating ' + chalk.cyan(dest));
            grunt.file.mkdir(dest);
            if (options.mode !== false) {
              fs.chmodSync(dest, (options.mode === true) ? fs.lstatSync(src).mode : options.mode);
            }

            if (options.timestamp) {
              dirs[dest] = src;
            }

            tally.dirs++;
          } else {
            grunt.verbose.writeln('Copying ' + chalk.cyan(src) + ' -> ' + chalk.cyan(dest));
            grunt.file.copy(src, dest, copyOptions);
            syncTimestamp(src, dest);
            if (options.mode !== false) {
              fs.chmodSync(dest, (options.mode === true) ? fs.lstatSync(src).mode : options.mode);
            }
            tally.files++;

            //CSS选择和JS函数的替换是内容改造,这里不进行文件名映射记录
            if(options.renameFileLogConfigKey !== 'CSSSelectorLOG' && options.renameFileLogConfigKey !== 'JSSelectorLOG') {
              fileList[fileName] = [getFileName(dest), src, dest];
              fileList.length += 1;
            } else {
              var a = options.renameFileLogConfigKey;
            }
          }
        } else {
          ignoreFileList[fileName] = src;
          ignoreFileList.length += 1;
        }
      });
    });

    if (options.timestamp) {
      Object.keys(dirs).sort(function (a, b) {
        return b.length - a.length;
      }).forEach(function (dest) {
        syncTimestamp(dirs[dest], dest);
      });
    }

    if (tally.dirs) {
      grunt.log.write('Created ' + chalk.cyan(tally.dirs.toString()) + (tally.dirs === 1 ? ' directory' : ' directories'));
    }

    if (tally.files) {
      grunt.log.write((tally.dirs ? ', copied ' : 'Copied ') + chalk.cyan(tally.files.toString()) + (tally.files === 1 ? ' file' : ' files'));
    }

    grunt.log.writeln();

    if(options.ignoreFileLog) {
      var ignoreFileLog = JSON.stringify(ignoreFileList);
      grunt.file.write(options.ignoreFileLog, ignoreFileLog, {encoding: 'utf8'});
    }

    if(fileList.length === 0 && grunt.config(options.renameFileLogConfigKey) && grunt.config(options.renameFileLogConfigKey).length > 0) {
      fileList = grunt.config(options.renameFileLogConfigKey);
      grunt.config(options.renameFileLogConfigKey, {length: 0});
    }

    if(options.renameFileLog) {
      var renameFileLog = JSON.stringify(fileList);
      grunt.file.write(options.renameFileLog, renameFileLog, {encoding: 'utf8'});
    }

    if(options.renameFileLogConfigKey) {
      grunt.config(options.renameFileLogConfigKey, fileList);
    }
  });

  var detectDestType = function (dest) {
    if (grunt.util._.endsWith(dest, '/')) {
      return 'directory';
    } else {
      return 'file';
    }
  };

  var unixifyPath = function (filepath) {
    if (process.platform === 'win32') {
      return filepath.replace(/\\/g, '/');
    } else {
      return filepath;
    }
  };

  var syncTimestamp = function (src, dest) {
    var stat = fs.lstatSync(src);
    if (path.basename(src) !== path.basename(dest)) {
      return;
    }

    if (stat.isFile() && !fileSyncCmp.equalFiles(src, dest)) {
      return;
    }

    fs.utimesSync(dest, stat.atime, stat.mtime);
  };

  var getFileName = function (path) {
    var index = path.lastIndexOf("/");
    var fileName = path.substring(index + 1);
    return fileName;
  };
};
