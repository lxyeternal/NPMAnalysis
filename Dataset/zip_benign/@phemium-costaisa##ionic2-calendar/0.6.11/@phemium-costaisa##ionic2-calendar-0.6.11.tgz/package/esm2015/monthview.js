var MonthViewComponent_1;
import { __decorate } from "tslib";
import { Component, Input, Output, EventEmitter, ViewChild, } from '@angular/core';
import { DatePipe } from '@angular/common';
import { CalendarService } from './calendar.service';
let MonthViewComponent = MonthViewComponent_1 = class MonthViewComponent {
    constructor(calendarService) {
        this.calendarService = calendarService;
        this.autoSelect = true;
        this.dir = '';
        this.onRangeChanged = new EventEmitter();
        this.onEventSelected = new EventEmitter();
        this.onTimeSelected = new EventEmitter(true);
        this.onTitleChanged = new EventEmitter(true);
        this.views = [];
        this.currentViewIndex = 0;
        this.mode = 'month';
        this.direction = 0;
        this.moveOnSelected = false;
        this.inited = false;
        this.callbackOnInit = true;
    }
    static getDates(startDate, n) {
        const dates = new Array(n), current = new Date(startDate.getTime());
        let i = 0;
        while (i < n) {
            dates[i++] = new Date(current.getTime());
            current.setDate(current.getDate() + 1);
        }
        return dates;
    }
    ngOnInit() {
        if (!this.sliderOptions) {
            this.sliderOptions = {};
        }
        this.sliderOptions.loop = true;
        if (this.dateFormatter && this.dateFormatter.formatMonthViewDay) {
            this.formatDayLabel = this.dateFormatter.formatMonthViewDay;
        }
        else {
            const dayLabelDatePipe = new DatePipe('en-US');
            this.formatDayLabel = function (date) {
                return dayLabelDatePipe.transform(date, this.formatDay);
            };
        }
        if (this.dateFormatter && this.dateFormatter.formatMonthViewDayHeader) {
            this.formatDayHeaderLabel = this.dateFormatter.formatMonthViewDayHeader;
        }
        else {
            const datePipe = new DatePipe(this.locale);
            this.formatDayHeaderLabel = function (date) {
                return datePipe.transform(date, this.formatDayHeader);
            };
        }
        if (this.dateFormatter && this.dateFormatter.formatMonthViewTitle) {
            this.formatTitle = this.dateFormatter.formatMonthViewTitle;
        }
        else {
            const datePipe = new DatePipe(this.locale);
            this.formatTitle = function (date) {
                return datePipe.transform(date, this.formatMonthTitle);
            };
        }
        if (this.lockSwipeToPrev) {
            this.slider.lockSwipeToPrev(true);
        }
        if (this.lockSwipes) {
            this.slider.lockSwipes(true);
        }
        this.refreshView();
        this.inited = true;
        this.currentDateChangedFromParentSubscription = this.calendarService.currentDateChangedFromParent$.subscribe((currentDate) => {
            this.refreshView();
        });
        this.eventSourceChangedSubscription = this.calendarService.eventSourceChanged$.subscribe(() => {
            this.onDataLoaded();
        });
        this.slideChangedSubscription = this.calendarService.slideChanged$.subscribe((direction) => {
            if (direction === 1) {
                this.slider.slideNext();
            }
            else if (direction === -1) {
                this.slider.slidePrev();
            }
        });
        this.slideUpdatedSubscription = this.calendarService.slideUpdated$.subscribe(() => {
            this.slider.update();
        });
    }
    ngOnDestroy() {
        if (this.currentDateChangedFromParentSubscription) {
            this.currentDateChangedFromParentSubscription.unsubscribe();
            this.currentDateChangedFromParentSubscription = null;
        }
        if (this.eventSourceChangedSubscription) {
            this.eventSourceChangedSubscription.unsubscribe();
            this.eventSourceChangedSubscription = null;
        }
        if (this.slideChangedSubscription) {
            this.slideChangedSubscription.unsubscribe();
            this.slideChangedSubscription = null;
        }
        if (this.slideUpdatedSubscription) {
            this.slideUpdatedSubscription.unsubscribe();
            this.slideUpdatedSubscription = null;
        }
    }
    ngOnChanges(changes) {
        if (!this.inited) {
            return;
        }
        const eventSourceChange = changes.eventSource;
        if (eventSourceChange && eventSourceChange.currentValue) {
            this.onDataLoaded();
        }
        const lockSwipeToPrev = changes.lockSwipeToPrev;
        if (lockSwipeToPrev) {
            this.slider.lockSwipeToPrev(lockSwipeToPrev.currentValue);
        }
        const lockSwipes = changes.lockSwipes;
        if (lockSwipes) {
            this.slider.lockSwipes(lockSwipes.currentValue);
        }
    }
    ngAfterViewInit() {
        const title = this.getTitle();
        this.onTitleChanged.emit(title);
    }
    onSlideChanged() {
        if (this.callbackOnInit) {
            this.callbackOnInit = false;
            return;
        }
        let direction = 0;
        const currentViewIndex = this.currentViewIndex;
        this.slider.getActiveIndex().then((currentSlideIndex) => {
            currentSlideIndex = (currentSlideIndex + 2) % 3;
            if (isNaN(currentSlideIndex)) {
                currentSlideIndex = currentViewIndex;
            }
            if (currentSlideIndex - currentViewIndex === 1) {
                direction = 1;
            }
            else if (currentSlideIndex === 0 && currentViewIndex === 2) {
                direction = 1;
                this.slider.slideTo(1, 0, false);
            }
            else if (currentViewIndex - currentSlideIndex === 1) {
                direction = -1;
            }
            else if (currentSlideIndex === 2 && currentViewIndex === 0) {
                direction = -1;
                this.slider.slideTo(3, 0, false);
            }
            this.currentViewIndex = currentSlideIndex;
            this.move(direction);
        });
    }
    move(direction) {
        if (direction === 0) {
            return;
        }
        this.direction = direction;
        if (!this.moveOnSelected) {
            const adjacentDate = this.calendarService.getAdjacentCalendarDate(this.mode, direction);
            this.calendarService.setCurrentDate(adjacentDate);
        }
        this.refreshView();
        this.direction = 0;
        this.moveOnSelected = false;
    }
    createDateObject(date) {
        let disabled = false;
        if (this.markDisabled) {
            disabled = this.markDisabled(date);
        }
        return {
            date,
            events: [],
            label: this.formatDayLabel(date),
            secondary: false,
            disabled,
        };
    }
    getViewData(startTime) {
        const startDate = startTime, date = startDate.getDate(), month = (startDate.getMonth() + (date !== 1 ? 1 : 0)) % 12;
        const dates = MonthViewComponent_1.getDates(startDate, 42);
        const days = [];
        for (let i = 0; i < 42; i++) {
            const dateObject = this.createDateObject(dates[i]);
            dateObject.secondary = dates[i].getMonth() !== month;
            days[i] = dateObject;
        }
        const dayHeaders = [];
        for (let i = 0; i < 7; i++) {
            dayHeaders.push(this.formatDayHeaderLabel(days[i].date));
        }
        return {
            dates: days,
            dayHeaders,
        };
    }
    getHighlightClass(date) {
        let className = '';
        if (date.hasEvent) {
            if (date.secondary) {
                className = 'monthview-secondary-with-event';
            }
            else {
                className = 'monthview-primary-with-event';
            }
        }
        if (date.selected) {
            if (className) {
                className += ' ';
            }
            className += 'monthview-selected';
        }
        if (date.current) {
            if (className) {
                className += ' ';
            }
            className += 'monthview-current';
        }
        if (date.secondary) {
            if (className) {
                className += ' ';
            }
            className += 'text-muted';
        }
        if (date.disabled) {
            if (className) {
                className += ' ';
            }
            className += 'monthview-disabled';
        }
        return className;
    }
    getRange(currentDate) {
        const year = currentDate.getFullYear(), month = currentDate.getMonth(), firstDayOfMonth = new Date(year, month, 1, 12, 0, 0), // set hour to 12 to avoid DST problem
        difference = this.startingDayMonth - firstDayOfMonth.getDay(), numDisplayedFromPreviousMonth = difference > 0 ? 7 - difference : -difference, startDate = new Date(firstDayOfMonth.getTime());
        if (numDisplayedFromPreviousMonth > 0) {
            startDate.setDate(-numDisplayedFromPreviousMonth + 1);
        }
        const endDate = new Date(startDate.getTime());
        endDate.setDate(endDate.getDate() + 42);
        return {
            startTime: startDate,
            endTime: endDate,
        };
    }
    onDataLoaded() {
        const range = this.range, eventSource = this.eventSource, len = eventSource ? eventSource.length : 0, startTime = range.startTime, endTime = range.endTime, utcStartTime = Date.UTC(startTime.getFullYear(), startTime.getMonth(), startTime.getDate()), utcEndTime = Date.UTC(endTime.getFullYear(), endTime.getMonth(), endTime.getDate()), currentViewIndex = this.currentViewIndex, dates = this.views[currentViewIndex].dates, oneDay = 86400000, eps = 0.0006;
        for (let r = 0; r < 42; r += 1) {
            if (dates[r].hasEvent) {
                dates[r].hasEvent = false;
                dates[r].events = [];
            }
        }
        for (let i = 0; i < len; i += 1) {
            const event = eventSource[i], eventStartTime = event.startTime, eventEndTime = event.endTime;
            let eventUTCStartTime, eventUTCEndTime;
            if (event.allDay) {
                eventUTCStartTime = eventStartTime.getTime();
                eventUTCEndTime = eventEndTime.getTime();
            }
            else {
                eventUTCStartTime = Date.UTC(eventStartTime.getFullYear(), eventStartTime.getMonth(), eventStartTime.getDate());
                eventUTCEndTime = Date.UTC(eventEndTime.getFullYear(), eventEndTime.getMonth(), eventEndTime.getDate() + 1);
            }
            if (eventUTCEndTime <= utcStartTime || eventUTCStartTime >= utcEndTime) {
                continue;
            }
            let timeDifferenceStart, timeDifferenceEnd;
            if (eventUTCStartTime < utcStartTime) {
                timeDifferenceStart = 0;
            }
            else {
                timeDifferenceStart = (eventUTCStartTime - utcStartTime) / oneDay;
            }
            if (eventUTCEndTime > utcEndTime) {
                timeDifferenceEnd = (utcEndTime - utcStartTime) / oneDay;
            }
            else {
                timeDifferenceEnd = (eventUTCEndTime - utcStartTime) / oneDay;
            }
            let index = Math.floor(timeDifferenceStart);
            const endIndex = Math.ceil(timeDifferenceEnd - eps);
            while (index < endIndex) {
                dates[index].hasEvent = true;
                let eventSet = dates[index].events;
                if (eventSet) {
                    eventSet.push(event);
                }
                else {
                    eventSet = [];
                    eventSet.push(event);
                    dates[index].events = eventSet;
                }
                index += 1;
            }
        }
        for (let r = 0; r < 42; r += 1) {
            if (dates[r].hasEvent) {
                dates[r].events.sort(this.compareEvent);
            }
        }
        if (this.autoSelect) {
            let findSelected = false;
            for (let r = 0; r < 42; r += 1) {
                if (dates[r].selected) {
                    this.selectedDate = dates[r];
                    findSelected = true;
                    break;
                }
            }
            if (findSelected) {
                this.onTimeSelected.emit({
                    selectedTime: this.selectedDate.date,
                    events: this.selectedDate.events,
                    disabled: this.selectedDate.disabled,
                });
            }
        }
    }
    refreshView() {
        this.range = this.getRange(this.calendarService.currentDate);
        if (this.inited) {
            const title = this.getTitle();
            this.onTitleChanged.emit(title);
        }
        this.calendarService.populateAdjacentViews(this);
        this.updateCurrentView(this.range.startTime, this.views[this.currentViewIndex]);
        this.calendarService.rangeChanged(this);
    }
    getTitle() {
        const currentViewStartDate = this.range.startTime, date = currentViewStartDate.getDate(), month = (currentViewStartDate.getMonth() + (date !== 1 ? 1 : 0)) % 12, year = currentViewStartDate.getFullYear() + (date !== 1 && month === 0 ? 1 : 0), headerDate = new Date(year, month, 1, 12, 0, 0, 0);
        return this.formatTitle(headerDate);
    }
    compareEvent(event1, event2) {
        if (event1.allDay) {
            return 1;
        }
        else if (event2.allDay) {
            return -1;
        }
        else {
            return event1.startTime.getTime() - event2.startTime.getTime();
        }
    }
    select(viewDate) {
        if (!this.views) {
            return;
        }
        const selectedDate = viewDate.date, events = viewDate.events;
        if (!viewDate.disabled) {
            const dates = this.views[this.currentViewIndex].dates, currentCalendarDate = this.calendarService.currentDate, currentMonth = currentCalendarDate.getMonth(), currentYear = currentCalendarDate.getFullYear(), selectedMonth = selectedDate.getMonth(), selectedYear = selectedDate.getFullYear();
            let direction = 0;
            if (currentYear === selectedYear) {
                if (currentMonth !== selectedMonth) {
                    direction = currentMonth < selectedMonth ? 1 : -1;
                }
            }
            else {
                direction = currentYear < selectedYear ? 1 : -1;
            }
            this.calendarService.setInitialDate(selectedDate);
            if (direction === 0) {
                const currentViewStartDate = this.range.startTime, oneDay = 86400000, selectedDayDifference = Math.round((Date.UTC(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate()) -
                    Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) /
                    oneDay);
                for (let r = 0; r < 42; r += 1) {
                    dates[r].selected = false;
                }
                if (selectedDayDifference >= 0 && selectedDayDifference < 42) {
                    dates[selectedDayDifference].selected = true;
                    this.selectedDate = dates[selectedDayDifference];
                }
            }
            else {
                this.moveOnSelected = true;
                this.slideView(direction);
            }
        }
        this.onTimeSelected.emit({
            selectedTime: selectedDate,
            events,
            disabled: viewDate.disabled,
        });
    }
    slideView(direction) {
        if (direction === 1) {
            this.slider.slideNext();
        }
        else if (direction === -1) {
            this.slider.slidePrev();
        }
    }
    updateCurrentView(currentViewStartDate, view) {
        const currentCalendarDate = this.calendarService.initialDate, today = new Date(), oneDay = 86400000, selectedDayDifference = Math.round((Date.UTC(currentCalendarDate.getFullYear(), currentCalendarDate.getMonth(), currentCalendarDate.getDate()) -
            Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) /
            oneDay), currentDayDifference = Math.round((Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()) -
            Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) /
            oneDay);
        for (let r = 0; r < 42; r += 1) {
            view.dates[r].selected = false;
        }
        if (selectedDayDifference >= 0 &&
            selectedDayDifference < 42 &&
            !view.dates[selectedDayDifference].disabled &&
            (this.autoSelect || this.moveOnSelected)) {
            view.dates[selectedDayDifference].selected = true;
            this.selectedDate = view.dates[selectedDayDifference];
        }
        else {
            this.selectedDate = {
                date: null,
                events: [],
                label: null,
                secondary: null,
                disabled: false,
            };
        }
        if (currentDayDifference >= 0 && currentDayDifference < 42) {
            view.dates[currentDayDifference].current = true;
        }
    }
    eventSelected(event) {
        this.onEventSelected.emit(event);
    }
};
MonthViewComponent.ctorParameters = () => [
    { type: CalendarService }
];
__decorate([
    ViewChild('monthSlider', { static: true })
], MonthViewComponent.prototype, "slider", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "monthviewDisplayEventTemplate", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "monthviewInactiveDisplayEventTemplate", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "monthviewEventDetailTemplate", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "formatDay", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "formatDayHeader", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "formatMonthTitle", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "eventSource", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "startingDayMonth", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "showEventDetail", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "noEventsLabel", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "autoSelect", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "markDisabled", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "locale", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "dateFormatter", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "dir", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "lockSwipeToPrev", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "lockSwipes", void 0);
__decorate([
    Input()
], MonthViewComponent.prototype, "sliderOptions", void 0);
__decorate([
    Output()
], MonthViewComponent.prototype, "onRangeChanged", void 0);
__decorate([
    Output()
], MonthViewComponent.prototype, "onEventSelected", void 0);
__decorate([
    Output()
], MonthViewComponent.prototype, "onTimeSelected", void 0);
__decorate([
    Output()
], MonthViewComponent.prototype, "onTitleChanged", void 0);
MonthViewComponent = MonthViewComponent_1 = __decorate([
    Component({
        selector: 'monthview',
        template: `
		<div>
			<ion-slides #monthSlider [options]="sliderOptions" [dir]="dir" (ionSlideDidChange)="onSlideChanged()">
				<ion-slide>
					<table *ngIf="0 === currentViewIndex" class="table table-bordered table-fixed monthview-datetable">
						<thead>
							<tr>
								<th *ngFor="let dayHeader of views[0].dayHeaders">
									<small>{{ dayHeader }}</small>
								</th>
							</tr>
						</thead>
						<tbody>
							<tr *ngFor="let row of [0, 1, 2, 3, 4, 5]">
								<td
									*ngFor="let col of [0, 1, 2, 3, 4, 5, 6]"
									tappable
									(click)="select(views[0].dates[row * 7 + col])"
									[ngClass]="getHighlightClass(views[0].dates[row * 7 + col])"
								>
									<ng-template
										[ngTemplateOutlet]="monthviewDisplayEventTemplate"
										[ngTemplateOutletContext]="{
											view: views[0],
											row: row,
											col: col
										}"
									>
									</ng-template>
								</td>
							</tr>
						</tbody>
					</table>
					<table *ngIf="0 !== currentViewIndex" class="table table-bordered table-fixed monthview-datetable">
						<thead>
							<tr class="text-center">
								<th *ngFor="let dayHeader of views[0].dayHeaders">
									<small>{{ dayHeader }}</small>
								</th>
							</tr>
						</thead>
						<tbody>
							<tr *ngFor="let row of [0, 1, 2, 3, 4, 5]">
								<td *ngFor="let col of [0, 1, 2, 3, 4, 5, 6]">
									<ng-template
										[ngTemplateOutlet]="monthviewInactiveDisplayEventTemplate"
										[ngTemplateOutletContext]="{
											view: views[0],
											row: row,
											col: col
										}"
									>
									</ng-template>
								</td>
							</tr>

							<tr></tr>
						</tbody>
					</table>
				</ion-slide>
				<ion-slide>
					<table *ngIf="1 === currentViewIndex" class="table table-bordered table-fixed monthview-datetable">
						<thead>
							<tr>
								<th *ngFor="let dayHeader of views[1].dayHeaders">
									<small>{{ dayHeader }}</small>
								</th>
							</tr>
						</thead>
						<tbody>
							<tr *ngFor="let row of [0, 1, 2, 3, 4, 5]">
								<td
									*ngFor="let col of [0, 1, 2, 3, 4, 5, 6]"
									tappable
									(click)="select(views[1].dates[row * 7 + col])"
									[ngClass]="getHighlightClass(views[1].dates[row * 7 + col])"
								>
									<ng-template
										[ngTemplateOutlet]="monthviewDisplayEventTemplate"
										[ngTemplateOutletContext]="{
											view: views[1],
											row: row,
											col: col
										}"
									>
									</ng-template>
								</td>
							</tr>
						</tbody>
					</table>
					<table *ngIf="1 !== currentViewIndex" class="table table-bordered table-fixed monthview-datetable">
						<thead>
							<tr class="text-center">
								<th *ngFor="let dayHeader of views[1].dayHeaders">
									<small>{{ dayHeader }}</small>
								</th>
							</tr>
						</thead>
						<tbody>
							<tr *ngFor="let row of [0, 1, 2, 3, 4, 5]">
								<td *ngFor="let col of [0, 1, 2, 3, 4, 5, 6]">
									<ng-template
										[ngTemplateOutlet]="monthviewInactiveDisplayEventTemplate"
										[ngTemplateOutletContext]="{
											view: views[1],
											row: row,
											col: col
										}"
									>
									</ng-template>
								</td>
							</tr>

							<tr></tr>
						</tbody>
					</table>
				</ion-slide>
				<ion-slide>
					<table *ngIf="2 === currentViewIndex" class="table table-bordered table-fixed monthview-datetable">
						<thead>
							<tr>
								<th *ngFor="let dayHeader of views[2].dayHeaders">
									<small>{{ dayHeader }}</small>
								</th>
							</tr>
						</thead>
						<tbody>
							<tr *ngFor="let row of [0, 1, 2, 3, 4, 5]">
								<td
									*ngFor="let col of [0, 1, 2, 3, 4, 5, 6]"
									tappable
									(click)="select(views[2].dates[row * 7 + col])"
									[ngClass]="getHighlightClass(views[2].dates[row * 7 + col])"
								>
									<ng-template
										[ngTemplateOutlet]="monthviewDisplayEventTemplate"
										[ngTemplateOutletContext]="{
											view: views[2],
											row: row,
											col: col
										}"
									>
									</ng-template>
								</td>
							</tr>
						</tbody>
					</table>
					<table *ngIf="2 !== currentViewIndex" class="table table-bordered table-fixed monthview-datetable">
						<thead>
							<tr class="text-center">
								<th *ngFor="let dayHeader of views[2].dayHeaders">
									<small>{{ dayHeader }}</small>
								</th>
							</tr>
						</thead>
						<tbody>
							<tr *ngFor="let row of [0, 1, 2, 3, 4, 5]">
								<td *ngFor="let col of [0, 1, 2, 3, 4, 5, 6]">
									<ng-template
										[ngTemplateOutlet]="monthviewInactiveDisplayEventTemplate"
										[ngTemplateOutletContext]="{
											view: views[2],
											row: row,
											col: col
										}"
									>
									</ng-template>
								</td>
							</tr>

							<tr></tr>
						</tbody>
					</table>
				</ion-slide>
			</ion-slides>
			<ng-template
				[ngTemplateOutlet]="monthviewEventDetailTemplate"
				[ngTemplateOutletContext]="{
					showEventDetail: showEventDetail,
					selectedDate: selectedDate,
					noEventsLabel: noEventsLabel
				}"
			>
			</ng-template>
		</div>
	`,
        styles: [`
			.text-muted {
				color: #999;
			}

			.table-fixed {
				table-layout: fixed;
			}

			.table {
				width: 100%;
				max-width: 100%;
				background-color: transparent;
			}

			.table > thead > tr > th,
			.table > tbody > tr > th,
			.table > tfoot > tr > th,
			.table > thead > tr > td,
			.table > tbody > tr > td,
			.table > tfoot > tr > td {
				padding: 8px;
				line-height: 20px;
				vertical-align: top;
			}

			.table > thead > tr > th {
				vertical-align: bottom;
				border-bottom: 2px solid #ddd;
			}

			.table > thead:first-child > tr:first-child > th,
			.table > thead:first-child > tr:first-child > td {
				border-top: 0;
			}

			.table > tbody + tbody {
				border-top: 2px solid #ddd;
			}

			.table-bordered {
				border: 1px solid #ddd;
			}

			.table-bordered > thead > tr > th,
			.table-bordered > tbody > tr > th,
			.table-bordered > tfoot > tr > th,
			.table-bordered > thead > tr > td,
			.table-bordered > tbody > tr > td,
			.table-bordered > tfoot > tr > td {
				border: 1px solid #ddd;
			}

			.table-bordered > thead > tr > th,
			.table-bordered > thead > tr > td {
				border-bottom-width: 2px;
			}

			.table-striped > tbody > tr:nth-child(odd) > td,
			.table-striped > tbody > tr:nth-child(odd) > th {
				background-color: #f9f9f9;
			}

			.monthview-primary-with-event {
				background-color: #3a87ad;
				color: white;
			}

			.monthview-current {
				background-color: #f0f0f0;
			}

			.monthview-selected {
				background-color: #009900;
				color: white;
			}

			.monthview-datetable td.monthview-disabled {
				color: lightgrey;
				cursor: default;
			}

			.monthview-datetable th {
				text-align: center;
			}

			.monthview-datetable td {
				cursor: pointer;
				text-align: center;
			}

			.monthview-secondary-with-event {
				background-color: #d9edf7;
			}

			::-webkit-scrollbar,
			*::-webkit-scrollbar {
				display: none;
			}
		`]
    })
], MonthViewComponent);
export { MonthViewComponent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9udGh2aWV3LmpzIiwic291cmNlUm9vdCI6Im5nOi8vQHBoZW1pdW0tY29zdGFpc2EvaW9uaWMyLWNhbGVuZGFyLyIsInNvdXJjZXMiOlsibW9udGh2aWV3LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsT0FBTyxFQUNOLFNBQVMsRUFHVCxLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFFWixTQUFTLEdBSVQsTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBSTNDLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQXNTckQsSUFBYSxrQkFBa0IsMEJBQS9CLE1BQWEsa0JBQWtCO0lBQzlCLFlBQW9CLGVBQWdDO1FBQWhDLG9CQUFlLEdBQWYsZUFBZSxDQUFpQjtRQWlCM0MsZUFBVSxHQUFHLElBQUksQ0FBQztRQUlsQixRQUFHLEdBQUcsRUFBRSxDQUFDO1FBS1IsbUJBQWMsR0FBRyxJQUFJLFlBQVksRUFBVSxDQUFDO1FBQzVDLG9CQUFlLEdBQUcsSUFBSSxZQUFZLEVBQVUsQ0FBQztRQUM3QyxtQkFBYyxHQUFHLElBQUksWUFBWSxDQUFnQixJQUFJLENBQUMsQ0FBQztRQUN2RCxtQkFBYyxHQUFHLElBQUksWUFBWSxDQUFTLElBQUksQ0FBQyxDQUFDO1FBRW5ELFVBQUssR0FBaUIsRUFBRSxDQUFDO1FBQ3pCLHFCQUFnQixHQUFHLENBQUMsQ0FBQztRQUdyQixTQUFJLEdBQWlCLE9BQU8sQ0FBQztRQUM3QixjQUFTLEdBQUcsQ0FBQyxDQUFDO1FBRWIsbUJBQWMsR0FBRyxLQUFLLENBQUM7UUFDdkIsV0FBTSxHQUFHLEtBQUssQ0FBQztRQUNmLG1CQUFjLEdBQUcsSUFBSSxDQUFDO0lBeEN5QixDQUFDO0lBbUR4RCxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQWUsRUFBRSxDQUFTO1FBQ3pDLE1BQU0sS0FBSyxHQUFHLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUN6QixPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ1YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ2IsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFDekMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDdkM7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNkLENBQUM7SUFFRCxRQUFRO1FBQ1AsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUU7WUFDeEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7U0FDeEI7UUFDRCxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7UUFFL0IsSUFBSSxJQUFJLENBQUMsYUFBYSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsa0JBQWtCLEVBQUU7WUFDaEUsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDO1NBQzVEO2FBQU07WUFDTixNQUFNLGdCQUFnQixHQUFHLElBQUksUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQy9DLElBQUksQ0FBQyxjQUFjLEdBQUcsVUFBVSxJQUFVO2dCQUN6QyxPQUFPLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3pELENBQUMsQ0FBQztTQUNGO1FBRUQsSUFBSSxJQUFJLENBQUMsYUFBYSxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsd0JBQXdCLEVBQUU7WUFDdEUsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsd0JBQXdCLENBQUM7U0FDeEU7YUFBTTtZQUNOLE1BQU0sUUFBUSxHQUFHLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUMzQyxJQUFJLENBQUMsb0JBQW9CLEdBQUcsVUFBVSxJQUFVO2dCQUMvQyxPQUFPLFFBQVEsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUN2RCxDQUFDLENBQUM7U0FDRjtRQUVELElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLG9CQUFvQixFQUFFO1lBQ2xFLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQztTQUMzRDthQUFNO1lBQ04sTUFBTSxRQUFRLEdBQUcsSUFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzNDLElBQUksQ0FBQyxXQUFXLEdBQUcsVUFBVSxJQUFVO2dCQUN0QyxPQUFPLFFBQVEsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ3hELENBQUMsQ0FBQztTQUNGO1FBRUQsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFO1lBQ3pCLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ2xDO1FBRUQsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ3BCLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQzdCO1FBRUQsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBRW5CLElBQUksQ0FBQyx3Q0FBd0MsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLDZCQUE2QixDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxFQUFFO1lBQzVILElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNwQixDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyw4QkFBOEIsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7WUFDN0YsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3JCLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxFQUFFO1lBQzFGLElBQUksU0FBUyxLQUFLLENBQUMsRUFBRTtnQkFDcEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQzthQUN4QjtpQkFBTSxJQUFJLFNBQVMsS0FBSyxDQUFDLENBQUMsRUFBRTtnQkFDNUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQzthQUN4QjtRQUNGLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7WUFDakYsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUN0QixDQUFDLENBQUMsQ0FBQztJQUNKLENBQUM7SUFFRCxXQUFXO1FBQ1YsSUFBSSxJQUFJLENBQUMsd0NBQXdDLEVBQUU7WUFDbEQsSUFBSSxDQUFDLHdDQUF3QyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzVELElBQUksQ0FBQyx3Q0FBd0MsR0FBRyxJQUFJLENBQUM7U0FDckQ7UUFFRCxJQUFJLElBQUksQ0FBQyw4QkFBOEIsRUFBRTtZQUN4QyxJQUFJLENBQUMsOEJBQThCLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDbEQsSUFBSSxDQUFDLDhCQUE4QixHQUFHLElBQUksQ0FBQztTQUMzQztRQUVELElBQUksSUFBSSxDQUFDLHdCQUF3QixFQUFFO1lBQ2xDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUM1QyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsSUFBSSxDQUFDO1NBQ3JDO1FBRUQsSUFBSSxJQUFJLENBQUMsd0JBQXdCLEVBQUU7WUFDbEMsSUFBSSxDQUFDLHdCQUF3QixDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzVDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxJQUFJLENBQUM7U0FDckM7SUFDRixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQXNCO1FBQ2pDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2pCLE9BQU87U0FDUDtRQUVELE1BQU0saUJBQWlCLEdBQUcsT0FBTyxDQUFDLFdBQVcsQ0FBQztRQUM5QyxJQUFJLGlCQUFpQixJQUFJLGlCQUFpQixDQUFDLFlBQVksRUFBRTtZQUN4RCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDcEI7UUFFRCxNQUFNLGVBQWUsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDO1FBQ2hELElBQUksZUFBZSxFQUFFO1lBQ3BCLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsQ0FBQztTQUMxRDtRQUVELE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUM7UUFDdEMsSUFBSSxVQUFVLEVBQUU7WUFDZixJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDaEQ7SUFDRixDQUFDO0lBRUQsZUFBZTtRQUNkLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUM5QixJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBRUQsY0FBYztRQUNiLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTtZQUN4QixJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztZQUM1QixPQUFPO1NBQ1A7UUFFRCxJQUFJLFNBQVMsR0FBRyxDQUFDLENBQUM7UUFDbEIsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7UUFFL0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxpQkFBaUIsRUFBRSxFQUFFO1lBQ3ZELGlCQUFpQixHQUFHLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2hELElBQUksS0FBSyxDQUFDLGlCQUFpQixDQUFDLEVBQUU7Z0JBQzdCLGlCQUFpQixHQUFHLGdCQUFnQixDQUFDO2FBQ3JDO1lBRUQsSUFBSSxpQkFBaUIsR0FBRyxnQkFBZ0IsS0FBSyxDQUFDLEVBQUU7Z0JBQy9DLFNBQVMsR0FBRyxDQUFDLENBQUM7YUFDZDtpQkFBTSxJQUFJLGlCQUFpQixLQUFLLENBQUMsSUFBSSxnQkFBZ0IsS0FBSyxDQUFDLEVBQUU7Z0JBQzdELFNBQVMsR0FBRyxDQUFDLENBQUM7Z0JBQ2QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUNqQztpQkFBTSxJQUFJLGdCQUFnQixHQUFHLGlCQUFpQixLQUFLLENBQUMsRUFBRTtnQkFDdEQsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDO2FBQ2Y7aUJBQU0sSUFBSSxpQkFBaUIsS0FBSyxDQUFDLElBQUksZ0JBQWdCLEtBQUssQ0FBQyxFQUFFO2dCQUM3RCxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUNqQztZQUNELElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxpQkFBaUIsQ0FBQztZQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3RCLENBQUMsQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQUVELElBQUksQ0FBQyxTQUFpQjtRQUNyQixJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUU7WUFDcEIsT0FBTztTQUNQO1FBQ0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7UUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDekIsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQ3hGLElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQ2xEO1FBQ0QsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ25CLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0lBQzdCLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxJQUFVO1FBQzFCLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQztRQUNyQixJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUU7WUFDdEIsUUFBUSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDbkM7UUFFRCxPQUFPO1lBQ04sSUFBSTtZQUNKLE1BQU0sRUFBRSxFQUFFO1lBQ1YsS0FBSyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDO1lBQ2hDLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLFFBQVE7U0FDUixDQUFDO0lBQ0gsQ0FBQztJQUVELFdBQVcsQ0FBQyxTQUFlO1FBQzFCLE1BQU0sU0FBUyxHQUFHLFNBQVMsRUFDMUIsSUFBSSxHQUFHLFNBQVMsQ0FBQyxPQUFPLEVBQUUsRUFDMUIsS0FBSyxHQUFHLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUU1RCxNQUFNLEtBQUssR0FBRyxvQkFBa0IsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3pELE1BQU0sSUFBSSxHQUFvQixFQUFFLENBQUM7UUFDakMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUM1QixNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbkQsVUFBVSxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEtBQUssS0FBSyxDQUFDO1lBQ3JELElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUM7U0FDckI7UUFFRCxNQUFNLFVBQVUsR0FBYSxFQUFFLENBQUM7UUFDaEMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUMzQixVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztTQUN6RDtRQUNELE9BQU87WUFDTixLQUFLLEVBQUUsSUFBSTtZQUNYLFVBQVU7U0FDVixDQUFDO0lBQ0gsQ0FBQztJQUVELGlCQUFpQixDQUFDLElBQW1CO1FBQ3BDLElBQUksU0FBUyxHQUFHLEVBQUUsQ0FBQztRQUVuQixJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDbEIsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO2dCQUNuQixTQUFTLEdBQUcsZ0NBQWdDLENBQUM7YUFDN0M7aUJBQU07Z0JBQ04sU0FBUyxHQUFHLDhCQUE4QixDQUFDO2FBQzNDO1NBQ0Q7UUFFRCxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDbEIsSUFBSSxTQUFTLEVBQUU7Z0JBQ2QsU0FBUyxJQUFJLEdBQUcsQ0FBQzthQUNqQjtZQUNELFNBQVMsSUFBSSxvQkFBb0IsQ0FBQztTQUNsQztRQUVELElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNqQixJQUFJLFNBQVMsRUFBRTtnQkFDZCxTQUFTLElBQUksR0FBRyxDQUFDO2FBQ2pCO1lBQ0QsU0FBUyxJQUFJLG1CQUFtQixDQUFDO1NBQ2pDO1FBRUQsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO1lBQ25CLElBQUksU0FBUyxFQUFFO2dCQUNkLFNBQVMsSUFBSSxHQUFHLENBQUM7YUFDakI7WUFDRCxTQUFTLElBQUksWUFBWSxDQUFDO1NBQzFCO1FBRUQsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2xCLElBQUksU0FBUyxFQUFFO2dCQUNkLFNBQVMsSUFBSSxHQUFHLENBQUM7YUFDakI7WUFDRCxTQUFTLElBQUksb0JBQW9CLENBQUM7U0FDbEM7UUFDRCxPQUFPLFNBQVMsQ0FBQztJQUNsQixDQUFDO0lBRUQsUUFBUSxDQUFDLFdBQWlCO1FBQ3pCLE1BQU0sSUFBSSxHQUFHLFdBQVcsQ0FBQyxXQUFXLEVBQUUsRUFDckMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxRQUFRLEVBQUUsRUFDOUIsZUFBZSxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsc0NBQXNDO1FBQzVGLFVBQVUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsZUFBZSxDQUFDLE1BQU0sRUFBRSxFQUM3RCw2QkFBNkIsR0FBRyxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsRUFDN0UsU0FBUyxHQUFHLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBRWpELElBQUksNkJBQTZCLEdBQUcsQ0FBQyxFQUFFO1lBQ3RDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyw2QkFBNkIsR0FBRyxDQUFDLENBQUMsQ0FBQztTQUN0RDtRQUVELE1BQU0sT0FBTyxHQUFHLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQzlDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDO1FBRXhDLE9BQU87WUFDTixTQUFTLEVBQUUsU0FBUztZQUNwQixPQUFPLEVBQUUsT0FBTztTQUNoQixDQUFDO0lBQ0gsQ0FBQztJQUVELFlBQVk7UUFDWCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxFQUN2QixXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFDOUIsR0FBRyxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUMxQyxTQUFTLEdBQUcsS0FBSyxDQUFDLFNBQVMsRUFDM0IsT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLEVBQ3ZCLFlBQVksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsRUFBRSxTQUFTLENBQUMsUUFBUSxFQUFFLEVBQUUsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDLEVBQzNGLFVBQVUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsRUFBRSxPQUFPLENBQUMsUUFBUSxFQUFFLEVBQUUsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLEVBQ25GLGdCQUFnQixHQUFHLElBQUksQ0FBQyxnQkFBZ0IsRUFDeEMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxLQUFLLEVBQzFDLE1BQU0sR0FBRyxRQUFRLEVBQ2pCLEdBQUcsR0FBRyxNQUFNLENBQUM7UUFFZCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDL0IsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFO2dCQUN0QixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztnQkFDMUIsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUM7YUFDckI7U0FDRDtRQUVELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNoQyxNQUFNLEtBQUssR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQzNCLGNBQWMsR0FBRyxLQUFLLENBQUMsU0FBUyxFQUNoQyxZQUFZLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQztZQUU5QixJQUFJLGlCQUF5QixFQUFFLGVBQXVCLENBQUM7WUFDdkQsSUFBSSxLQUFLLENBQUMsTUFBTSxFQUFFO2dCQUNqQixpQkFBaUIsR0FBRyxjQUFjLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQzdDLGVBQWUsR0FBRyxZQUFZLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDekM7aUJBQU07Z0JBQ04saUJBQWlCLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsV0FBVyxFQUFFLEVBQUUsY0FBYyxDQUFDLFFBQVEsRUFBRSxFQUFFLGNBQWMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO2dCQUNoSCxlQUFlLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsV0FBVyxFQUFFLEVBQUUsWUFBWSxDQUFDLFFBQVEsRUFBRSxFQUFFLFlBQVksQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQzthQUM1RztZQUVELElBQUksZUFBZSxJQUFJLFlBQVksSUFBSSxpQkFBaUIsSUFBSSxVQUFVLEVBQUU7Z0JBQ3ZFLFNBQVM7YUFDVDtZQUVELElBQUksbUJBQTJCLEVBQUUsaUJBQXlCLENBQUM7WUFFM0QsSUFBSSxpQkFBaUIsR0FBRyxZQUFZLEVBQUU7Z0JBQ3JDLG1CQUFtQixHQUFHLENBQUMsQ0FBQzthQUN4QjtpQkFBTTtnQkFDTixtQkFBbUIsR0FBRyxDQUFDLGlCQUFpQixHQUFHLFlBQVksQ0FBQyxHQUFHLE1BQU0sQ0FBQzthQUNsRTtZQUVELElBQUksZUFBZSxHQUFHLFVBQVUsRUFBRTtnQkFDakMsaUJBQWlCLEdBQUcsQ0FBQyxVQUFVLEdBQUcsWUFBWSxDQUFDLEdBQUcsTUFBTSxDQUFDO2FBQ3pEO2lCQUFNO2dCQUNOLGlCQUFpQixHQUFHLENBQUMsZUFBZSxHQUFHLFlBQVksQ0FBQyxHQUFHLE1BQU0sQ0FBQzthQUM5RDtZQUVELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQztZQUM1QyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEdBQUcsQ0FBQyxDQUFDO1lBQ3BELE9BQU8sS0FBSyxHQUFHLFFBQVEsRUFBRTtnQkFDeEIsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7Z0JBQzdCLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUM7Z0JBQ25DLElBQUksUUFBUSxFQUFFO29CQUNiLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQ3JCO3FCQUFNO29CQUNOLFFBQVEsR0FBRyxFQUFFLENBQUM7b0JBQ2QsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDckIsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUM7aUJBQy9CO2dCQUNELEtBQUssSUFBSSxDQUFDLENBQUM7YUFDWDtTQUNEO1FBRUQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQy9CLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRTtnQkFDdEIsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO2FBQ3hDO1NBQ0Q7UUFFRCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDcEIsSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDO1lBQ3pCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDL0IsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFO29CQUN0QixJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDN0IsWUFBWSxHQUFHLElBQUksQ0FBQztvQkFDcEIsTUFBTTtpQkFDTjthQUNEO1lBRUQsSUFBSSxZQUFZLEVBQUU7Z0JBQ2pCLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDO29CQUN4QixZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJO29CQUNwQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNO29CQUNoQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRO2lCQUNwQyxDQUFDLENBQUM7YUFDSDtTQUNEO0lBQ0YsQ0FBQztJQUVELFdBQVc7UUFDVixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUU3RCxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQzlCLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ2hDO1FBQ0QsSUFBSSxDQUFDLGVBQWUsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNqRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO1FBQ2hGLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRCxRQUFRO1FBQ1AsTUFBTSxvQkFBb0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFDaEQsSUFBSSxHQUFHLG9CQUFvQixDQUFDLE9BQU8sRUFBRSxFQUNyQyxLQUFLLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQ3JFLElBQUksR0FBRyxvQkFBb0IsQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFDL0UsVUFBVSxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3BELE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRU8sWUFBWSxDQUFDLE1BQWMsRUFBRSxNQUFjO1FBQ2xELElBQUksTUFBTSxDQUFDLE1BQU0sRUFBRTtZQUNsQixPQUFPLENBQUMsQ0FBQztTQUNUO2FBQU0sSUFBSSxNQUFNLENBQUMsTUFBTSxFQUFFO1lBQ3pCLE9BQU8sQ0FBQyxDQUFDLENBQUM7U0FDVjthQUFNO1lBQ04sT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUM7U0FDL0Q7SUFDRixDQUFDO0lBRUQsTUFBTSxDQUFDLFFBQXVCO1FBQzdCLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFO1lBQ2hCLE9BQU87U0FDUDtRQUVELE1BQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQyxJQUFJLEVBQ2pDLE1BQU0sR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO1FBRTFCLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO1lBQ3ZCLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsS0FBSyxFQUNwRCxtQkFBbUIsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsRUFDdEQsWUFBWSxHQUFHLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxFQUM3QyxXQUFXLEdBQUcsbUJBQW1CLENBQUMsV0FBVyxFQUFFLEVBQy9DLGFBQWEsR0FBRyxZQUFZLENBQUMsUUFBUSxFQUFFLEVBQ3ZDLFlBQVksR0FBRyxZQUFZLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDM0MsSUFBSSxTQUFTLEdBQUcsQ0FBQyxDQUFDO1lBRWxCLElBQUksV0FBVyxLQUFLLFlBQVksRUFBRTtnQkFDakMsSUFBSSxZQUFZLEtBQUssYUFBYSxFQUFFO29CQUNuQyxTQUFTLEdBQUcsWUFBWSxHQUFHLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDbEQ7YUFDRDtpQkFBTTtnQkFDTixTQUFTLEdBQUcsV0FBVyxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNoRDtZQUVELElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ2xELElBQUksU0FBUyxLQUFLLENBQUMsRUFBRTtnQkFDcEIsTUFBTSxvQkFBb0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFDaEQsTUFBTSxHQUFHLFFBQVEsRUFDakIscUJBQXFCLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FDakMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUUsRUFBRSxZQUFZLENBQUMsUUFBUSxFQUFFLEVBQUUsWUFBWSxDQUFDLE9BQU8sRUFBRSxDQUFDO29CQUNyRixJQUFJLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLFdBQVcsRUFBRSxFQUFFLG9CQUFvQixDQUFDLFFBQVEsRUFBRSxFQUFFLG9CQUFvQixDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7b0JBQzlHLE1BQU0sQ0FDUCxDQUFDO2dCQUVILEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDL0IsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7aUJBQzFCO2dCQUVELElBQUkscUJBQXFCLElBQUksQ0FBQyxJQUFJLHFCQUFxQixHQUFHLEVBQUUsRUFBRTtvQkFDN0QsS0FBSyxDQUFDLHFCQUFxQixDQUFDLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztvQkFDN0MsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQztpQkFDakQ7YUFDRDtpQkFBTTtnQkFDTixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztnQkFDM0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUMxQjtTQUNEO1FBRUQsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUM7WUFDeEIsWUFBWSxFQUFFLFlBQVk7WUFDMUIsTUFBTTtZQUNOLFFBQVEsRUFBRSxRQUFRLENBQUMsUUFBUTtTQUMzQixDQUFDLENBQUM7SUFDSixDQUFDO0lBRUQsU0FBUyxDQUFDLFNBQWlCO1FBQzFCLElBQUksU0FBUyxLQUFLLENBQUMsRUFBRTtZQUNwQixJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDO1NBQ3hCO2FBQU0sSUFBSSxTQUFTLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFDNUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQztTQUN4QjtJQUNGLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxvQkFBMEIsRUFBRSxJQUFnQjtRQUM3RCxNQUFNLG1CQUFtQixHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxFQUMzRCxLQUFLLEdBQUcsSUFBSSxJQUFJLEVBQUUsRUFDbEIsTUFBTSxHQUFHLFFBQVEsRUFDakIscUJBQXFCLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FDakMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLFdBQVcsRUFBRSxFQUFFLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxFQUFFLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQzFHLElBQUksQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsV0FBVyxFQUFFLEVBQUUsb0JBQW9CLENBQUMsUUFBUSxFQUFFLEVBQUUsb0JBQW9CLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUM5RyxNQUFNLENBQ1AsRUFDRCxvQkFBb0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUNoQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxFQUFFLEtBQUssQ0FBQyxRQUFRLEVBQUUsRUFBRSxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDaEUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxXQUFXLEVBQUUsRUFBRSxvQkFBb0IsQ0FBQyxRQUFRLEVBQUUsRUFBRSxvQkFBb0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQzlHLE1BQU0sQ0FDUCxDQUFDO1FBRUgsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQy9CLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztTQUMvQjtRQUVELElBQ0MscUJBQXFCLElBQUksQ0FBQztZQUMxQixxQkFBcUIsR0FBRyxFQUFFO1lBQzFCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLFFBQVE7WUFDM0MsQ0FBQyxJQUFJLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsRUFDdkM7WUFDRCxJQUFJLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztZQUNsRCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQztTQUN0RDthQUFNO1lBQ04sSUFBSSxDQUFDLFlBQVksR0FBRztnQkFDbkIsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsTUFBTSxFQUFFLEVBQUU7Z0JBQ1YsS0FBSyxFQUFFLElBQUk7Z0JBQ1gsU0FBUyxFQUFFLElBQUk7Z0JBQ2YsUUFBUSxFQUFFLEtBQUs7YUFDZixDQUFDO1NBQ0Y7UUFFRCxJQUFJLG9CQUFvQixJQUFJLENBQUMsSUFBSSxvQkFBb0IsR0FBRyxFQUFFLEVBQUU7WUFDM0QsSUFBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7U0FDaEQ7SUFDRixDQUFDO0lBRUQsYUFBYSxDQUFDLEtBQWE7UUFDMUIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDbEMsQ0FBQztDQUNELENBQUE7O1lBMWlCcUMsZUFBZTs7QUFDUjtJQUEzQyxTQUFTLENBQUMsYUFBYSxFQUFFLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDO2tEQUFtQjtBQUc5RDtJQURDLEtBQUssRUFBRTt5RUFDMEU7QUFFbEY7SUFEQyxLQUFLLEVBQUU7aUZBQ2tGO0FBRTFGO0lBREMsS0FBSyxFQUFFO3dFQUN5RTtBQUV4RTtJQUFSLEtBQUssRUFBRTtxREFBbUI7QUFDbEI7SUFBUixLQUFLLEVBQUU7MkRBQXlCO0FBQ3hCO0lBQVIsS0FBSyxFQUFFOzREQUEwQjtBQUN6QjtJQUFSLEtBQUssRUFBRTt1REFBdUI7QUFDdEI7SUFBUixLQUFLLEVBQUU7NERBQTBCO0FBQ3pCO0lBQVIsS0FBSyxFQUFFOzJEQUEwQjtBQUN6QjtJQUFSLEtBQUssRUFBRTt5REFBdUI7QUFDdEI7SUFBUixLQUFLLEVBQUU7c0RBQW1CO0FBQ2xCO0lBQVIsS0FBSyxFQUFFO3dEQUF1QztBQUN0QztJQUFSLEtBQUssRUFBRTtrREFBZ0I7QUFDZjtJQUFSLEtBQUssRUFBRTt5REFBK0I7QUFDOUI7SUFBUixLQUFLLEVBQUU7K0NBQVU7QUFDVDtJQUFSLEtBQUssRUFBRTsyREFBMEI7QUFDekI7SUFBUixLQUFLLEVBQUU7c0RBQXFCO0FBQ3BCO0lBQVIsS0FBSyxFQUFFO3lEQUFvQjtBQUVsQjtJQUFULE1BQU0sRUFBRTswREFBNkM7QUFDNUM7SUFBVCxNQUFNLEVBQUU7MkRBQThDO0FBQzdDO0lBQVQsTUFBTSxFQUFFOzBEQUF3RDtBQUN2RDtJQUFULE1BQU0sRUFBRTswREFBaUQ7QUE5QjlDLGtCQUFrQjtJQW5TOUIsU0FBUyxDQUFDO1FBQ1YsUUFBUSxFQUFFLFdBQVc7UUFDckIsUUFBUSxFQUFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQXlMVDtpQkFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBbUdDO0tBRUYsQ0FBQztHQUNXLGtCQUFrQixDQTJpQjlCO1NBM2lCWSxrQkFBa0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG5cdENvbXBvbmVudCxcclxuXHRPbkluaXQsXHJcblx0T25DaGFuZ2VzLFxyXG5cdElucHV0LFxyXG5cdE91dHB1dCxcclxuXHRFdmVudEVtaXR0ZXIsXHJcblx0U2ltcGxlQ2hhbmdlcyxcclxuXHRWaWV3Q2hpbGQsXHJcblx0VGVtcGxhdGVSZWYsXHJcblx0T25EZXN0cm95LFxyXG5cdEFmdGVyVmlld0luaXQsXHJcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xyXG5pbXBvcnQgeyBEYXRlUGlwZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XHJcbmltcG9ydCB7IElvblNsaWRlcyB9IGZyb20gJ0Bpb25pYy9hbmd1bGFyJztcclxuXHJcbmltcG9ydCB7IElDYWxlbmRhckNvbXBvbmVudCwgSUV2ZW50LCBJTW9udGhWaWV3LCBJTW9udGhWaWV3Um93LCBJVGltZVNlbGVjdGVkLCBJUmFuZ2UsIENhbGVuZGFyTW9kZSwgSURhdGVGb3JtYXR0ZXIgfSBmcm9tICcuL2NhbGVuZGFyJztcclxuaW1wb3J0IHsgQ2FsZW5kYXJTZXJ2aWNlIH0gZnJvbSAnLi9jYWxlbmRhci5zZXJ2aWNlJztcclxuaW1wb3J0IHsgSU1vbnRoVmlld0Rpc3BsYXlFdmVudFRlbXBsYXRlQ29udGV4dCB9IGZyb20gJy4vY2FsZW5kYXInO1xyXG5cclxuQENvbXBvbmVudCh7XHJcblx0c2VsZWN0b3I6ICdtb250aHZpZXcnLFxyXG5cdHRlbXBsYXRlOiBgXHJcblx0XHQ8ZGl2PlxyXG5cdFx0XHQ8aW9uLXNsaWRlcyAjbW9udGhTbGlkZXIgW29wdGlvbnNdPVwic2xpZGVyT3B0aW9uc1wiIFtkaXJdPVwiZGlyXCIgKGlvblNsaWRlRGlkQ2hhbmdlKT1cIm9uU2xpZGVDaGFuZ2VkKClcIj5cclxuXHRcdFx0XHQ8aW9uLXNsaWRlPlxyXG5cdFx0XHRcdFx0PHRhYmxlICpuZ0lmPVwiMCA9PT0gY3VycmVudFZpZXdJbmRleFwiIGNsYXNzPVwidGFibGUgdGFibGUtYm9yZGVyZWQgdGFibGUtZml4ZWQgbW9udGh2aWV3LWRhdGV0YWJsZVwiPlxyXG5cdFx0XHRcdFx0XHQ8dGhlYWQ+XHJcblx0XHRcdFx0XHRcdFx0PHRyPlxyXG5cdFx0XHRcdFx0XHRcdFx0PHRoICpuZ0Zvcj1cImxldCBkYXlIZWFkZXIgb2Ygdmlld3NbMF0uZGF5SGVhZGVyc1wiPlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ8c21hbGw+e3sgZGF5SGVhZGVyIH19PC9zbWFsbD5cclxuXHRcdFx0XHRcdFx0XHRcdDwvdGg+XHJcblx0XHRcdFx0XHRcdFx0PC90cj5cclxuXHRcdFx0XHRcdFx0PC90aGVhZD5cclxuXHRcdFx0XHRcdFx0PHRib2R5PlxyXG5cdFx0XHRcdFx0XHRcdDx0ciAqbmdGb3I9XCJsZXQgcm93IG9mIFswLCAxLCAyLCAzLCA0LCA1XVwiPlxyXG5cdFx0XHRcdFx0XHRcdFx0PHRkXHJcblx0XHRcdFx0XHRcdFx0XHRcdCpuZ0Zvcj1cImxldCBjb2wgb2YgWzAsIDEsIDIsIDMsIDQsIDUsIDZdXCJcclxuXHRcdFx0XHRcdFx0XHRcdFx0dGFwcGFibGVcclxuXHRcdFx0XHRcdFx0XHRcdFx0KGNsaWNrKT1cInNlbGVjdCh2aWV3c1swXS5kYXRlc1tyb3cgKiA3ICsgY29sXSlcIlxyXG5cdFx0XHRcdFx0XHRcdFx0XHRbbmdDbGFzc109XCJnZXRIaWdobGlnaHRDbGFzcyh2aWV3c1swXS5kYXRlc1tyb3cgKiA3ICsgY29sXSlcIlxyXG5cdFx0XHRcdFx0XHRcdFx0PlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ8bmctdGVtcGxhdGVcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRbbmdUZW1wbGF0ZU91dGxldF09XCJtb250aHZpZXdEaXNwbGF5RXZlbnRUZW1wbGF0ZVwiXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0W25nVGVtcGxhdGVPdXRsZXRDb250ZXh0XT1cIntcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdHZpZXc6IHZpZXdzWzBdLFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0cm93OiByb3csXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjb2w6IGNvbFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdH1cIlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDwvbmctdGVtcGxhdGU+XHJcblx0XHRcdFx0XHRcdFx0XHQ8L3RkPlxyXG5cdFx0XHRcdFx0XHRcdDwvdHI+XHJcblx0XHRcdFx0XHRcdDwvdGJvZHk+XHJcblx0XHRcdFx0XHQ8L3RhYmxlPlxyXG5cdFx0XHRcdFx0PHRhYmxlICpuZ0lmPVwiMCAhPT0gY3VycmVudFZpZXdJbmRleFwiIGNsYXNzPVwidGFibGUgdGFibGUtYm9yZGVyZWQgdGFibGUtZml4ZWQgbW9udGh2aWV3LWRhdGV0YWJsZVwiPlxyXG5cdFx0XHRcdFx0XHQ8dGhlYWQ+XHJcblx0XHRcdFx0XHRcdFx0PHRyIGNsYXNzPVwidGV4dC1jZW50ZXJcIj5cclxuXHRcdFx0XHRcdFx0XHRcdDx0aCAqbmdGb3I9XCJsZXQgZGF5SGVhZGVyIG9mIHZpZXdzWzBdLmRheUhlYWRlcnNcIj5cclxuXHRcdFx0XHRcdFx0XHRcdFx0PHNtYWxsPnt7IGRheUhlYWRlciB9fTwvc21hbGw+XHJcblx0XHRcdFx0XHRcdFx0XHQ8L3RoPlxyXG5cdFx0XHRcdFx0XHRcdDwvdHI+XHJcblx0XHRcdFx0XHRcdDwvdGhlYWQ+XHJcblx0XHRcdFx0XHRcdDx0Ym9keT5cclxuXHRcdFx0XHRcdFx0XHQ8dHIgKm5nRm9yPVwibGV0IHJvdyBvZiBbMCwgMSwgMiwgMywgNCwgNV1cIj5cclxuXHRcdFx0XHRcdFx0XHRcdDx0ZCAqbmdGb3I9XCJsZXQgY29sIG9mIFswLCAxLCAyLCAzLCA0LCA1LCA2XVwiPlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ8bmctdGVtcGxhdGVcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRbbmdUZW1wbGF0ZU91dGxldF09XCJtb250aHZpZXdJbmFjdGl2ZURpc3BsYXlFdmVudFRlbXBsYXRlXCJcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRbbmdUZW1wbGF0ZU91dGxldENvbnRleHRdPVwie1xyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmlldzogdmlld3NbMF0sXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRyb3c6IHJvdyxcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNvbDogY29sXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0fVwiXHJcblx0XHRcdFx0XHRcdFx0XHRcdD5cclxuXHRcdFx0XHRcdFx0XHRcdFx0PC9uZy10ZW1wbGF0ZT5cclxuXHRcdFx0XHRcdFx0XHRcdDwvdGQ+XHJcblx0XHRcdFx0XHRcdFx0PC90cj5cclxuXHJcblx0XHRcdFx0XHRcdFx0PHRyPjwvdHI+XHJcblx0XHRcdFx0XHRcdDwvdGJvZHk+XHJcblx0XHRcdFx0XHQ8L3RhYmxlPlxyXG5cdFx0XHRcdDwvaW9uLXNsaWRlPlxyXG5cdFx0XHRcdDxpb24tc2xpZGU+XHJcblx0XHRcdFx0XHQ8dGFibGUgKm5nSWY9XCIxID09PSBjdXJyZW50Vmlld0luZGV4XCIgY2xhc3M9XCJ0YWJsZSB0YWJsZS1ib3JkZXJlZCB0YWJsZS1maXhlZCBtb250aHZpZXctZGF0ZXRhYmxlXCI+XHJcblx0XHRcdFx0XHRcdDx0aGVhZD5cclxuXHRcdFx0XHRcdFx0XHQ8dHI+XHJcblx0XHRcdFx0XHRcdFx0XHQ8dGggKm5nRm9yPVwibGV0IGRheUhlYWRlciBvZiB2aWV3c1sxXS5kYXlIZWFkZXJzXCI+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDxzbWFsbD57eyBkYXlIZWFkZXIgfX08L3NtYWxsPlxyXG5cdFx0XHRcdFx0XHRcdFx0PC90aD5cclxuXHRcdFx0XHRcdFx0XHQ8L3RyPlxyXG5cdFx0XHRcdFx0XHQ8L3RoZWFkPlxyXG5cdFx0XHRcdFx0XHQ8dGJvZHk+XHJcblx0XHRcdFx0XHRcdFx0PHRyICpuZ0Zvcj1cImxldCByb3cgb2YgWzAsIDEsIDIsIDMsIDQsIDVdXCI+XHJcblx0XHRcdFx0XHRcdFx0XHQ8dGRcclxuXHRcdFx0XHRcdFx0XHRcdFx0Km5nRm9yPVwibGV0IGNvbCBvZiBbMCwgMSwgMiwgMywgNCwgNSwgNl1cIlxyXG5cdFx0XHRcdFx0XHRcdFx0XHR0YXBwYWJsZVxyXG5cdFx0XHRcdFx0XHRcdFx0XHQoY2xpY2spPVwic2VsZWN0KHZpZXdzWzFdLmRhdGVzW3JvdyAqIDcgKyBjb2xdKVwiXHJcblx0XHRcdFx0XHRcdFx0XHRcdFtuZ0NsYXNzXT1cImdldEhpZ2hsaWdodENsYXNzKHZpZXdzWzFdLmRhdGVzW3JvdyAqIDcgKyBjb2xdKVwiXHJcblx0XHRcdFx0XHRcdFx0XHQ+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDxuZy10ZW1wbGF0ZVxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFtuZ1RlbXBsYXRlT3V0bGV0XT1cIm1vbnRodmlld0Rpc3BsYXlFdmVudFRlbXBsYXRlXCJcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRbbmdUZW1wbGF0ZU91dGxldENvbnRleHRdPVwie1xyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmlldzogdmlld3NbMV0sXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRyb3c6IHJvdyxcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNvbDogY29sXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0fVwiXHJcblx0XHRcdFx0XHRcdFx0XHRcdD5cclxuXHRcdFx0XHRcdFx0XHRcdFx0PC9uZy10ZW1wbGF0ZT5cclxuXHRcdFx0XHRcdFx0XHRcdDwvdGQ+XHJcblx0XHRcdFx0XHRcdFx0PC90cj5cclxuXHRcdFx0XHRcdFx0PC90Ym9keT5cclxuXHRcdFx0XHRcdDwvdGFibGU+XHJcblx0XHRcdFx0XHQ8dGFibGUgKm5nSWY9XCIxICE9PSBjdXJyZW50Vmlld0luZGV4XCIgY2xhc3M9XCJ0YWJsZSB0YWJsZS1ib3JkZXJlZCB0YWJsZS1maXhlZCBtb250aHZpZXctZGF0ZXRhYmxlXCI+XHJcblx0XHRcdFx0XHRcdDx0aGVhZD5cclxuXHRcdFx0XHRcdFx0XHQ8dHIgY2xhc3M9XCJ0ZXh0LWNlbnRlclwiPlxyXG5cdFx0XHRcdFx0XHRcdFx0PHRoICpuZ0Zvcj1cImxldCBkYXlIZWFkZXIgb2Ygdmlld3NbMV0uZGF5SGVhZGVyc1wiPlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ8c21hbGw+e3sgZGF5SGVhZGVyIH19PC9zbWFsbD5cclxuXHRcdFx0XHRcdFx0XHRcdDwvdGg+XHJcblx0XHRcdFx0XHRcdFx0PC90cj5cclxuXHRcdFx0XHRcdFx0PC90aGVhZD5cclxuXHRcdFx0XHRcdFx0PHRib2R5PlxyXG5cdFx0XHRcdFx0XHRcdDx0ciAqbmdGb3I9XCJsZXQgcm93IG9mIFswLCAxLCAyLCAzLCA0LCA1XVwiPlxyXG5cdFx0XHRcdFx0XHRcdFx0PHRkICpuZ0Zvcj1cImxldCBjb2wgb2YgWzAsIDEsIDIsIDMsIDQsIDUsIDZdXCI+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDxuZy10ZW1wbGF0ZVxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFtuZ1RlbXBsYXRlT3V0bGV0XT1cIm1vbnRodmlld0luYWN0aXZlRGlzcGxheUV2ZW50VGVtcGxhdGVcIlxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFtuZ1RlbXBsYXRlT3V0bGV0Q29udGV4dF09XCJ7XHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR2aWV3OiB2aWV3c1sxXSxcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdHJvdzogcm93LFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y29sOiBjb2xcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHR9XCJcclxuXHRcdFx0XHRcdFx0XHRcdFx0PlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ8L25nLXRlbXBsYXRlPlxyXG5cdFx0XHRcdFx0XHRcdFx0PC90ZD5cclxuXHRcdFx0XHRcdFx0XHQ8L3RyPlxyXG5cclxuXHRcdFx0XHRcdFx0XHQ8dHI+PC90cj5cclxuXHRcdFx0XHRcdFx0PC90Ym9keT5cclxuXHRcdFx0XHRcdDwvdGFibGU+XHJcblx0XHRcdFx0PC9pb24tc2xpZGU+XHJcblx0XHRcdFx0PGlvbi1zbGlkZT5cclxuXHRcdFx0XHRcdDx0YWJsZSAqbmdJZj1cIjIgPT09IGN1cnJlbnRWaWV3SW5kZXhcIiBjbGFzcz1cInRhYmxlIHRhYmxlLWJvcmRlcmVkIHRhYmxlLWZpeGVkIG1vbnRodmlldy1kYXRldGFibGVcIj5cclxuXHRcdFx0XHRcdFx0PHRoZWFkPlxyXG5cdFx0XHRcdFx0XHRcdDx0cj5cclxuXHRcdFx0XHRcdFx0XHRcdDx0aCAqbmdGb3I9XCJsZXQgZGF5SGVhZGVyIG9mIHZpZXdzWzJdLmRheUhlYWRlcnNcIj5cclxuXHRcdFx0XHRcdFx0XHRcdFx0PHNtYWxsPnt7IGRheUhlYWRlciB9fTwvc21hbGw+XHJcblx0XHRcdFx0XHRcdFx0XHQ8L3RoPlxyXG5cdFx0XHRcdFx0XHRcdDwvdHI+XHJcblx0XHRcdFx0XHRcdDwvdGhlYWQ+XHJcblx0XHRcdFx0XHRcdDx0Ym9keT5cclxuXHRcdFx0XHRcdFx0XHQ8dHIgKm5nRm9yPVwibGV0IHJvdyBvZiBbMCwgMSwgMiwgMywgNCwgNV1cIj5cclxuXHRcdFx0XHRcdFx0XHRcdDx0ZFxyXG5cdFx0XHRcdFx0XHRcdFx0XHQqbmdGb3I9XCJsZXQgY29sIG9mIFswLCAxLCAyLCAzLCA0LCA1LCA2XVwiXHJcblx0XHRcdFx0XHRcdFx0XHRcdHRhcHBhYmxlXHJcblx0XHRcdFx0XHRcdFx0XHRcdChjbGljayk9XCJzZWxlY3Qodmlld3NbMl0uZGF0ZXNbcm93ICogNyArIGNvbF0pXCJcclxuXHRcdFx0XHRcdFx0XHRcdFx0W25nQ2xhc3NdPVwiZ2V0SGlnaGxpZ2h0Q2xhc3Modmlld3NbMl0uZGF0ZXNbcm93ICogNyArIGNvbF0pXCJcclxuXHRcdFx0XHRcdFx0XHRcdD5cclxuXHRcdFx0XHRcdFx0XHRcdFx0PG5nLXRlbXBsYXRlXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0W25nVGVtcGxhdGVPdXRsZXRdPVwibW9udGh2aWV3RGlzcGxheUV2ZW50VGVtcGxhdGVcIlxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFtuZ1RlbXBsYXRlT3V0bGV0Q29udGV4dF09XCJ7XHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR2aWV3OiB2aWV3c1syXSxcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdHJvdzogcm93LFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y29sOiBjb2xcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHR9XCJcclxuXHRcdFx0XHRcdFx0XHRcdFx0PlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ8L25nLXRlbXBsYXRlPlxyXG5cdFx0XHRcdFx0XHRcdFx0PC90ZD5cclxuXHRcdFx0XHRcdFx0XHQ8L3RyPlxyXG5cdFx0XHRcdFx0XHQ8L3Rib2R5PlxyXG5cdFx0XHRcdFx0PC90YWJsZT5cclxuXHRcdFx0XHRcdDx0YWJsZSAqbmdJZj1cIjIgIT09IGN1cnJlbnRWaWV3SW5kZXhcIiBjbGFzcz1cInRhYmxlIHRhYmxlLWJvcmRlcmVkIHRhYmxlLWZpeGVkIG1vbnRodmlldy1kYXRldGFibGVcIj5cclxuXHRcdFx0XHRcdFx0PHRoZWFkPlxyXG5cdFx0XHRcdFx0XHRcdDx0ciBjbGFzcz1cInRleHQtY2VudGVyXCI+XHJcblx0XHRcdFx0XHRcdFx0XHQ8dGggKm5nRm9yPVwibGV0IGRheUhlYWRlciBvZiB2aWV3c1syXS5kYXlIZWFkZXJzXCI+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDxzbWFsbD57eyBkYXlIZWFkZXIgfX08L3NtYWxsPlxyXG5cdFx0XHRcdFx0XHRcdFx0PC90aD5cclxuXHRcdFx0XHRcdFx0XHQ8L3RyPlxyXG5cdFx0XHRcdFx0XHQ8L3RoZWFkPlxyXG5cdFx0XHRcdFx0XHQ8dGJvZHk+XHJcblx0XHRcdFx0XHRcdFx0PHRyICpuZ0Zvcj1cImxldCByb3cgb2YgWzAsIDEsIDIsIDMsIDQsIDVdXCI+XHJcblx0XHRcdFx0XHRcdFx0XHQ8dGQgKm5nRm9yPVwibGV0IGNvbCBvZiBbMCwgMSwgMiwgMywgNCwgNSwgNl1cIj5cclxuXHRcdFx0XHRcdFx0XHRcdFx0PG5nLXRlbXBsYXRlXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0W25nVGVtcGxhdGVPdXRsZXRdPVwibW9udGh2aWV3SW5hY3RpdmVEaXNwbGF5RXZlbnRUZW1wbGF0ZVwiXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0W25nVGVtcGxhdGVPdXRsZXRDb250ZXh0XT1cIntcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdHZpZXc6IHZpZXdzWzJdLFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0cm93OiByb3csXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjb2w6IGNvbFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdH1cIlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDwvbmctdGVtcGxhdGU+XHJcblx0XHRcdFx0XHRcdFx0XHQ8L3RkPlxyXG5cdFx0XHRcdFx0XHRcdDwvdHI+XHJcblxyXG5cdFx0XHRcdFx0XHRcdDx0cj48L3RyPlxyXG5cdFx0XHRcdFx0XHQ8L3Rib2R5PlxyXG5cdFx0XHRcdFx0PC90YWJsZT5cclxuXHRcdFx0XHQ8L2lvbi1zbGlkZT5cclxuXHRcdFx0PC9pb24tc2xpZGVzPlxyXG5cdFx0XHQ8bmctdGVtcGxhdGVcclxuXHRcdFx0XHRbbmdUZW1wbGF0ZU91dGxldF09XCJtb250aHZpZXdFdmVudERldGFpbFRlbXBsYXRlXCJcclxuXHRcdFx0XHRbbmdUZW1wbGF0ZU91dGxldENvbnRleHRdPVwie1xyXG5cdFx0XHRcdFx0c2hvd0V2ZW50RGV0YWlsOiBzaG93RXZlbnREZXRhaWwsXHJcblx0XHRcdFx0XHRzZWxlY3RlZERhdGU6IHNlbGVjdGVkRGF0ZSxcclxuXHRcdFx0XHRcdG5vRXZlbnRzTGFiZWw6IG5vRXZlbnRzTGFiZWxcclxuXHRcdFx0XHR9XCJcclxuXHRcdFx0PlxyXG5cdFx0XHQ8L25nLXRlbXBsYXRlPlxyXG5cdFx0PC9kaXY+XHJcblx0YCxcclxuXHRzdHlsZXM6IFtcclxuXHRcdGBcclxuXHRcdFx0LnRleHQtbXV0ZWQge1xyXG5cdFx0XHRcdGNvbG9yOiAjOTk5O1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQudGFibGUtZml4ZWQge1xyXG5cdFx0XHRcdHRhYmxlLWxheW91dDogZml4ZWQ7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdC50YWJsZSB7XHJcblx0XHRcdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRcdFx0bWF4LXdpZHRoOiAxMDAlO1xyXG5cdFx0XHRcdGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQudGFibGUgPiB0aGVhZCA+IHRyID4gdGgsXHJcblx0XHRcdC50YWJsZSA+IHRib2R5ID4gdHIgPiB0aCxcclxuXHRcdFx0LnRhYmxlID4gdGZvb3QgPiB0ciA+IHRoLFxyXG5cdFx0XHQudGFibGUgPiB0aGVhZCA+IHRyID4gdGQsXHJcblx0XHRcdC50YWJsZSA+IHRib2R5ID4gdHIgPiB0ZCxcclxuXHRcdFx0LnRhYmxlID4gdGZvb3QgPiB0ciA+IHRkIHtcclxuXHRcdFx0XHRwYWRkaW5nOiA4cHg7XHJcblx0XHRcdFx0bGluZS1oZWlnaHQ6IDIwcHg7XHJcblx0XHRcdFx0dmVydGljYWwtYWxpZ246IHRvcDtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0LnRhYmxlID4gdGhlYWQgPiB0ciA+IHRoIHtcclxuXHRcdFx0XHR2ZXJ0aWNhbC1hbGlnbjogYm90dG9tO1xyXG5cdFx0XHRcdGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjZGRkO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQudGFibGUgPiB0aGVhZDpmaXJzdC1jaGlsZCA+IHRyOmZpcnN0LWNoaWxkID4gdGgsXHJcblx0XHRcdC50YWJsZSA+IHRoZWFkOmZpcnN0LWNoaWxkID4gdHI6Zmlyc3QtY2hpbGQgPiB0ZCB7XHJcblx0XHRcdFx0Ym9yZGVyLXRvcDogMDtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0LnRhYmxlID4gdGJvZHkgKyB0Ym9keSB7XHJcblx0XHRcdFx0Ym9yZGVyLXRvcDogMnB4IHNvbGlkICNkZGQ7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdC50YWJsZS1ib3JkZXJlZCB7XHJcblx0XHRcdFx0Ym9yZGVyOiAxcHggc29saWQgI2RkZDtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0LnRhYmxlLWJvcmRlcmVkID4gdGhlYWQgPiB0ciA+IHRoLFxyXG5cdFx0XHQudGFibGUtYm9yZGVyZWQgPiB0Ym9keSA+IHRyID4gdGgsXHJcblx0XHRcdC50YWJsZS1ib3JkZXJlZCA+IHRmb290ID4gdHIgPiB0aCxcclxuXHRcdFx0LnRhYmxlLWJvcmRlcmVkID4gdGhlYWQgPiB0ciA+IHRkLFxyXG5cdFx0XHQudGFibGUtYm9yZGVyZWQgPiB0Ym9keSA+IHRyID4gdGQsXHJcblx0XHRcdC50YWJsZS1ib3JkZXJlZCA+IHRmb290ID4gdHIgPiB0ZCB7XHJcblx0XHRcdFx0Ym9yZGVyOiAxcHggc29saWQgI2RkZDtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0LnRhYmxlLWJvcmRlcmVkID4gdGhlYWQgPiB0ciA+IHRoLFxyXG5cdFx0XHQudGFibGUtYm9yZGVyZWQgPiB0aGVhZCA+IHRyID4gdGQge1xyXG5cdFx0XHRcdGJvcmRlci1ib3R0b20td2lkdGg6IDJweDtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0LnRhYmxlLXN0cmlwZWQgPiB0Ym9keSA+IHRyOm50aC1jaGlsZChvZGQpID4gdGQsXHJcblx0XHRcdC50YWJsZS1zdHJpcGVkID4gdGJvZHkgPiB0cjpudGgtY2hpbGQob2RkKSA+IHRoIHtcclxuXHRcdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAjZjlmOWY5O1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQubW9udGh2aWV3LXByaW1hcnktd2l0aC1ldmVudCB7XHJcblx0XHRcdFx0YmFja2dyb3VuZC1jb2xvcjogIzNhODdhZDtcclxuXHRcdFx0XHRjb2xvcjogd2hpdGU7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdC5tb250aHZpZXctY3VycmVudCB7XHJcblx0XHRcdFx0YmFja2dyb3VuZC1jb2xvcjogI2YwZjBmMDtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0Lm1vbnRodmlldy1zZWxlY3RlZCB7XHJcblx0XHRcdFx0YmFja2dyb3VuZC1jb2xvcjogIzAwOTkwMDtcclxuXHRcdFx0XHRjb2xvcjogd2hpdGU7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdC5tb250aHZpZXctZGF0ZXRhYmxlIHRkLm1vbnRodmlldy1kaXNhYmxlZCB7XHJcblx0XHRcdFx0Y29sb3I6IGxpZ2h0Z3JleTtcclxuXHRcdFx0XHRjdXJzb3I6IGRlZmF1bHQ7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdC5tb250aHZpZXctZGF0ZXRhYmxlIHRoIHtcclxuXHRcdFx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdC5tb250aHZpZXctZGF0ZXRhYmxlIHRkIHtcclxuXHRcdFx0XHRjdXJzb3I6IHBvaW50ZXI7XHJcblx0XHRcdFx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQubW9udGh2aWV3LXNlY29uZGFyeS13aXRoLWV2ZW50IHtcclxuXHRcdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAjZDllZGY3O1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQ6Oi13ZWJraXQtc2Nyb2xsYmFyLFxyXG5cdFx0XHQqOjotd2Via2l0LXNjcm9sbGJhciB7XHJcblx0XHRcdFx0ZGlzcGxheTogbm9uZTtcclxuXHRcdFx0fVxyXG5cdFx0YCxcclxuXHRdLFxyXG59KVxyXG5leHBvcnQgY2xhc3MgTW9udGhWaWV3Q29tcG9uZW50IGltcGxlbWVudHMgSUNhbGVuZGFyQ29tcG9uZW50LCBPbkluaXQsIE9uRGVzdHJveSwgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0IHtcclxuXHRjb25zdHJ1Y3Rvcihwcml2YXRlIGNhbGVuZGFyU2VydmljZTogQ2FsZW5kYXJTZXJ2aWNlKSB7fVxyXG5cdEBWaWV3Q2hpbGQoJ21vbnRoU2xpZGVyJywgeyBzdGF0aWM6IHRydWUgfSkgc2xpZGVyOiBJb25TbGlkZXM7XHJcblxyXG5cdEBJbnB1dCgpXHJcblx0bW9udGh2aWV3RGlzcGxheUV2ZW50VGVtcGxhdGU6IFRlbXBsYXRlUmVmPElNb250aFZpZXdEaXNwbGF5RXZlbnRUZW1wbGF0ZUNvbnRleHQ+O1xyXG5cdEBJbnB1dCgpXHJcblx0bW9udGh2aWV3SW5hY3RpdmVEaXNwbGF5RXZlbnRUZW1wbGF0ZTogVGVtcGxhdGVSZWY8SU1vbnRoVmlld0Rpc3BsYXlFdmVudFRlbXBsYXRlQ29udGV4dD47XHJcblx0QElucHV0KClcclxuXHRtb250aHZpZXdFdmVudERldGFpbFRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxJTW9udGhWaWV3RGlzcGxheUV2ZW50VGVtcGxhdGVDb250ZXh0PjtcclxuXHJcblx0QElucHV0KCkgZm9ybWF0RGF5OiBzdHJpbmc7XHJcblx0QElucHV0KCkgZm9ybWF0RGF5SGVhZGVyOiBzdHJpbmc7XHJcblx0QElucHV0KCkgZm9ybWF0TW9udGhUaXRsZTogc3RyaW5nO1xyXG5cdEBJbnB1dCgpIGV2ZW50U291cmNlOiBJRXZlbnRbXTtcclxuXHRASW5wdXQoKSBzdGFydGluZ0RheU1vbnRoOiBudW1iZXI7XHJcblx0QElucHV0KCkgc2hvd0V2ZW50RGV0YWlsOiBib29sZWFuO1xyXG5cdEBJbnB1dCgpIG5vRXZlbnRzTGFiZWw6IHN0cmluZztcclxuXHRASW5wdXQoKSBhdXRvU2VsZWN0ID0gdHJ1ZTtcclxuXHRASW5wdXQoKSBtYXJrRGlzYWJsZWQ6IChkYXRlOiBEYXRlKSA9PiBib29sZWFuO1xyXG5cdEBJbnB1dCgpIGxvY2FsZTogc3RyaW5nO1xyXG5cdEBJbnB1dCgpIGRhdGVGb3JtYXR0ZXI6IElEYXRlRm9ybWF0dGVyO1xyXG5cdEBJbnB1dCgpIGRpciA9ICcnO1xyXG5cdEBJbnB1dCgpIGxvY2tTd2lwZVRvUHJldjogYm9vbGVhbjtcclxuXHRASW5wdXQoKSBsb2NrU3dpcGVzOiBib29sZWFuO1xyXG5cdEBJbnB1dCgpIHNsaWRlck9wdGlvbnM6IGFueTtcclxuXHJcblx0QE91dHB1dCgpIG9uUmFuZ2VDaGFuZ2VkID0gbmV3IEV2ZW50RW1pdHRlcjxJUmFuZ2U+KCk7XHJcblx0QE91dHB1dCgpIG9uRXZlbnRTZWxlY3RlZCA9IG5ldyBFdmVudEVtaXR0ZXI8SUV2ZW50PigpO1xyXG5cdEBPdXRwdXQoKSBvblRpbWVTZWxlY3RlZCA9IG5ldyBFdmVudEVtaXR0ZXI8SVRpbWVTZWxlY3RlZD4odHJ1ZSk7XHJcblx0QE91dHB1dCgpIG9uVGl0bGVDaGFuZ2VkID0gbmV3IEV2ZW50RW1pdHRlcjxzdHJpbmc+KHRydWUpO1xyXG5cclxuXHRwdWJsaWMgdmlld3M6IElNb250aFZpZXdbXSA9IFtdO1xyXG5cdHB1YmxpYyBjdXJyZW50Vmlld0luZGV4ID0gMDtcclxuXHRwdWJsaWMgc2VsZWN0ZWREYXRlOiBJTW9udGhWaWV3Um93O1xyXG5cdHB1YmxpYyByYW5nZTogSVJhbmdlO1xyXG5cdHB1YmxpYyBtb2RlOiBDYWxlbmRhck1vZGUgPSAnbW9udGgnO1xyXG5cdHB1YmxpYyBkaXJlY3Rpb24gPSAwO1xyXG5cclxuXHRwcml2YXRlIG1vdmVPblNlbGVjdGVkID0gZmFsc2U7XHJcblx0cHJpdmF0ZSBpbml0ZWQgPSBmYWxzZTtcclxuXHRwcml2YXRlIGNhbGxiYWNrT25Jbml0ID0gdHJ1ZTtcclxuXHJcblx0cHJpdmF0ZSBjdXJyZW50RGF0ZUNoYW5nZWRGcm9tUGFyZW50U3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb247XHJcblx0cHJpdmF0ZSBldmVudFNvdXJjZUNoYW5nZWRTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcclxuXHRwcml2YXRlIHNsaWRlQ2hhbmdlZFN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xyXG5cdHByaXZhdGUgc2xpZGVVcGRhdGVkU3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb247XHJcblxyXG5cdHByaXZhdGUgZm9ybWF0RGF5TGFiZWw6IChkYXRlOiBEYXRlKSA9PiBzdHJpbmc7XHJcblx0cHJpdmF0ZSBmb3JtYXREYXlIZWFkZXJMYWJlbDogKGRhdGU6IERhdGUpID0+IHN0cmluZztcclxuXHRwcml2YXRlIGZvcm1hdFRpdGxlOiAoZGF0ZTogRGF0ZSkgPT4gc3RyaW5nO1xyXG5cclxuXHRzdGF0aWMgZ2V0RGF0ZXMoc3RhcnREYXRlOiBEYXRlLCBuOiBudW1iZXIpOiBEYXRlW10ge1xyXG5cdFx0Y29uc3QgZGF0ZXMgPSBuZXcgQXJyYXkobiksXHJcblx0XHRcdGN1cnJlbnQgPSBuZXcgRGF0ZShzdGFydERhdGUuZ2V0VGltZSgpKTtcclxuXHRcdGxldCBpID0gMDtcclxuXHRcdHdoaWxlIChpIDwgbikge1xyXG5cdFx0XHRkYXRlc1tpKytdID0gbmV3IERhdGUoY3VycmVudC5nZXRUaW1lKCkpO1xyXG5cdFx0XHRjdXJyZW50LnNldERhdGUoY3VycmVudC5nZXREYXRlKCkgKyAxKTtcclxuXHRcdH1cclxuXHRcdHJldHVybiBkYXRlcztcclxuXHR9XHJcblxyXG5cdG5nT25Jbml0KCkge1xyXG5cdFx0aWYgKCF0aGlzLnNsaWRlck9wdGlvbnMpIHtcclxuXHRcdFx0dGhpcy5zbGlkZXJPcHRpb25zID0ge307XHJcblx0XHR9XHJcblx0XHR0aGlzLnNsaWRlck9wdGlvbnMubG9vcCA9IHRydWU7XHJcblxyXG5cdFx0aWYgKHRoaXMuZGF0ZUZvcm1hdHRlciAmJiB0aGlzLmRhdGVGb3JtYXR0ZXIuZm9ybWF0TW9udGhWaWV3RGF5KSB7XHJcblx0XHRcdHRoaXMuZm9ybWF0RGF5TGFiZWwgPSB0aGlzLmRhdGVGb3JtYXR0ZXIuZm9ybWF0TW9udGhWaWV3RGF5O1xyXG5cdFx0fSBlbHNlIHtcclxuXHRcdFx0Y29uc3QgZGF5TGFiZWxEYXRlUGlwZSA9IG5ldyBEYXRlUGlwZSgnZW4tVVMnKTtcclxuXHRcdFx0dGhpcy5mb3JtYXREYXlMYWJlbCA9IGZ1bmN0aW9uIChkYXRlOiBEYXRlKSB7XHJcblx0XHRcdFx0cmV0dXJuIGRheUxhYmVsRGF0ZVBpcGUudHJhbnNmb3JtKGRhdGUsIHRoaXMuZm9ybWF0RGF5KTtcclxuXHRcdFx0fTtcclxuXHRcdH1cclxuXHJcblx0XHRpZiAodGhpcy5kYXRlRm9ybWF0dGVyICYmIHRoaXMuZGF0ZUZvcm1hdHRlci5mb3JtYXRNb250aFZpZXdEYXlIZWFkZXIpIHtcclxuXHRcdFx0dGhpcy5mb3JtYXREYXlIZWFkZXJMYWJlbCA9IHRoaXMuZGF0ZUZvcm1hdHRlci5mb3JtYXRNb250aFZpZXdEYXlIZWFkZXI7XHJcblx0XHR9IGVsc2Uge1xyXG5cdFx0XHRjb25zdCBkYXRlUGlwZSA9IG5ldyBEYXRlUGlwZSh0aGlzLmxvY2FsZSk7XHJcblx0XHRcdHRoaXMuZm9ybWF0RGF5SGVhZGVyTGFiZWwgPSBmdW5jdGlvbiAoZGF0ZTogRGF0ZSkge1xyXG5cdFx0XHRcdHJldHVybiBkYXRlUGlwZS50cmFuc2Zvcm0oZGF0ZSwgdGhpcy5mb3JtYXREYXlIZWFkZXIpO1xyXG5cdFx0XHR9O1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmICh0aGlzLmRhdGVGb3JtYXR0ZXIgJiYgdGhpcy5kYXRlRm9ybWF0dGVyLmZvcm1hdE1vbnRoVmlld1RpdGxlKSB7XHJcblx0XHRcdHRoaXMuZm9ybWF0VGl0bGUgPSB0aGlzLmRhdGVGb3JtYXR0ZXIuZm9ybWF0TW9udGhWaWV3VGl0bGU7XHJcblx0XHR9IGVsc2Uge1xyXG5cdFx0XHRjb25zdCBkYXRlUGlwZSA9IG5ldyBEYXRlUGlwZSh0aGlzLmxvY2FsZSk7XHJcblx0XHRcdHRoaXMuZm9ybWF0VGl0bGUgPSBmdW5jdGlvbiAoZGF0ZTogRGF0ZSkge1xyXG5cdFx0XHRcdHJldHVybiBkYXRlUGlwZS50cmFuc2Zvcm0oZGF0ZSwgdGhpcy5mb3JtYXRNb250aFRpdGxlKTtcclxuXHRcdFx0fTtcclxuXHRcdH1cclxuXHJcblx0XHRpZiAodGhpcy5sb2NrU3dpcGVUb1ByZXYpIHtcclxuXHRcdFx0dGhpcy5zbGlkZXIubG9ja1N3aXBlVG9QcmV2KHRydWUpO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmICh0aGlzLmxvY2tTd2lwZXMpIHtcclxuXHRcdFx0dGhpcy5zbGlkZXIubG9ja1N3aXBlcyh0cnVlKTtcclxuXHRcdH1cclxuXHJcblx0XHR0aGlzLnJlZnJlc2hWaWV3KCk7XHJcblx0XHR0aGlzLmluaXRlZCA9IHRydWU7XHJcblxyXG5cdFx0dGhpcy5jdXJyZW50RGF0ZUNoYW5nZWRGcm9tUGFyZW50U3Vic2NyaXB0aW9uID0gdGhpcy5jYWxlbmRhclNlcnZpY2UuY3VycmVudERhdGVDaGFuZ2VkRnJvbVBhcmVudCQuc3Vic2NyaWJlKChjdXJyZW50RGF0ZSkgPT4ge1xyXG5cdFx0XHR0aGlzLnJlZnJlc2hWaWV3KCk7XHJcblx0XHR9KTtcclxuXHJcblx0XHR0aGlzLmV2ZW50U291cmNlQ2hhbmdlZFN1YnNjcmlwdGlvbiA9IHRoaXMuY2FsZW5kYXJTZXJ2aWNlLmV2ZW50U291cmNlQ2hhbmdlZCQuc3Vic2NyaWJlKCgpID0+IHtcclxuXHRcdFx0dGhpcy5vbkRhdGFMb2FkZWQoKTtcclxuXHRcdH0pO1xyXG5cclxuXHRcdHRoaXMuc2xpZGVDaGFuZ2VkU3Vic2NyaXB0aW9uID0gdGhpcy5jYWxlbmRhclNlcnZpY2Uuc2xpZGVDaGFuZ2VkJC5zdWJzY3JpYmUoKGRpcmVjdGlvbikgPT4ge1xyXG5cdFx0XHRpZiAoZGlyZWN0aW9uID09PSAxKSB7XHJcblx0XHRcdFx0dGhpcy5zbGlkZXIuc2xpZGVOZXh0KCk7XHJcblx0XHRcdH0gZWxzZSBpZiAoZGlyZWN0aW9uID09PSAtMSkge1xyXG5cdFx0XHRcdHRoaXMuc2xpZGVyLnNsaWRlUHJldigpO1xyXG5cdFx0XHR9XHJcblx0XHR9KTtcclxuXHJcblx0XHR0aGlzLnNsaWRlVXBkYXRlZFN1YnNjcmlwdGlvbiA9IHRoaXMuY2FsZW5kYXJTZXJ2aWNlLnNsaWRlVXBkYXRlZCQuc3Vic2NyaWJlKCgpID0+IHtcclxuXHRcdFx0dGhpcy5zbGlkZXIudXBkYXRlKCk7XHJcblx0XHR9KTtcclxuXHR9XHJcblxyXG5cdG5nT25EZXN0cm95KCkge1xyXG5cdFx0aWYgKHRoaXMuY3VycmVudERhdGVDaGFuZ2VkRnJvbVBhcmVudFN1YnNjcmlwdGlvbikge1xyXG5cdFx0XHR0aGlzLmN1cnJlbnREYXRlQ2hhbmdlZEZyb21QYXJlbnRTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuXHRcdFx0dGhpcy5jdXJyZW50RGF0ZUNoYW5nZWRGcm9tUGFyZW50U3Vic2NyaXB0aW9uID0gbnVsbDtcclxuXHRcdH1cclxuXHJcblx0XHRpZiAodGhpcy5ldmVudFNvdXJjZUNoYW5nZWRTdWJzY3JpcHRpb24pIHtcclxuXHRcdFx0dGhpcy5ldmVudFNvdXJjZUNoYW5nZWRTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuXHRcdFx0dGhpcy5ldmVudFNvdXJjZUNoYW5nZWRTdWJzY3JpcHRpb24gPSBudWxsO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmICh0aGlzLnNsaWRlQ2hhbmdlZFN1YnNjcmlwdGlvbikge1xyXG5cdFx0XHR0aGlzLnNsaWRlQ2hhbmdlZFN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xyXG5cdFx0XHR0aGlzLnNsaWRlQ2hhbmdlZFN1YnNjcmlwdGlvbiA9IG51bGw7XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKHRoaXMuc2xpZGVVcGRhdGVkU3Vic2NyaXB0aW9uKSB7XHJcblx0XHRcdHRoaXMuc2xpZGVVcGRhdGVkU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcblx0XHRcdHRoaXMuc2xpZGVVcGRhdGVkU3Vic2NyaXB0aW9uID0gbnVsbDtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcclxuXHRcdGlmICghdGhpcy5pbml0ZWQpIHtcclxuXHRcdFx0cmV0dXJuO1xyXG5cdFx0fVxyXG5cclxuXHRcdGNvbnN0IGV2ZW50U291cmNlQ2hhbmdlID0gY2hhbmdlcy5ldmVudFNvdXJjZTtcclxuXHRcdGlmIChldmVudFNvdXJjZUNoYW5nZSAmJiBldmVudFNvdXJjZUNoYW5nZS5jdXJyZW50VmFsdWUpIHtcclxuXHRcdFx0dGhpcy5vbkRhdGFMb2FkZWQoKTtcclxuXHRcdH1cclxuXHJcblx0XHRjb25zdCBsb2NrU3dpcGVUb1ByZXYgPSBjaGFuZ2VzLmxvY2tTd2lwZVRvUHJldjtcclxuXHRcdGlmIChsb2NrU3dpcGVUb1ByZXYpIHtcclxuXHRcdFx0dGhpcy5zbGlkZXIubG9ja1N3aXBlVG9QcmV2KGxvY2tTd2lwZVRvUHJldi5jdXJyZW50VmFsdWUpO1xyXG5cdFx0fVxyXG5cclxuXHRcdGNvbnN0IGxvY2tTd2lwZXMgPSBjaGFuZ2VzLmxvY2tTd2lwZXM7XHJcblx0XHRpZiAobG9ja1N3aXBlcykge1xyXG5cdFx0XHR0aGlzLnNsaWRlci5sb2NrU3dpcGVzKGxvY2tTd2lwZXMuY3VycmVudFZhbHVlKTtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdG5nQWZ0ZXJWaWV3SW5pdCgpIHtcclxuXHRcdGNvbnN0IHRpdGxlID0gdGhpcy5nZXRUaXRsZSgpO1xyXG5cdFx0dGhpcy5vblRpdGxlQ2hhbmdlZC5lbWl0KHRpdGxlKTtcclxuXHR9XHJcblxyXG5cdG9uU2xpZGVDaGFuZ2VkKCkge1xyXG5cdFx0aWYgKHRoaXMuY2FsbGJhY2tPbkluaXQpIHtcclxuXHRcdFx0dGhpcy5jYWxsYmFja09uSW5pdCA9IGZhbHNlO1xyXG5cdFx0XHRyZXR1cm47XHJcblx0XHR9XHJcblxyXG5cdFx0bGV0IGRpcmVjdGlvbiA9IDA7XHJcblx0XHRjb25zdCBjdXJyZW50Vmlld0luZGV4ID0gdGhpcy5jdXJyZW50Vmlld0luZGV4O1xyXG5cclxuXHRcdHRoaXMuc2xpZGVyLmdldEFjdGl2ZUluZGV4KCkudGhlbigoY3VycmVudFNsaWRlSW5kZXgpID0+IHtcclxuXHRcdFx0Y3VycmVudFNsaWRlSW5kZXggPSAoY3VycmVudFNsaWRlSW5kZXggKyAyKSAlIDM7XHJcblx0XHRcdGlmIChpc05hTihjdXJyZW50U2xpZGVJbmRleCkpIHtcclxuXHRcdFx0XHRjdXJyZW50U2xpZGVJbmRleCA9IGN1cnJlbnRWaWV3SW5kZXg7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGlmIChjdXJyZW50U2xpZGVJbmRleCAtIGN1cnJlbnRWaWV3SW5kZXggPT09IDEpIHtcclxuXHRcdFx0XHRkaXJlY3Rpb24gPSAxO1xyXG5cdFx0XHR9IGVsc2UgaWYgKGN1cnJlbnRTbGlkZUluZGV4ID09PSAwICYmIGN1cnJlbnRWaWV3SW5kZXggPT09IDIpIHtcclxuXHRcdFx0XHRkaXJlY3Rpb24gPSAxO1xyXG5cdFx0XHRcdHRoaXMuc2xpZGVyLnNsaWRlVG8oMSwgMCwgZmFsc2UpO1xyXG5cdFx0XHR9IGVsc2UgaWYgKGN1cnJlbnRWaWV3SW5kZXggLSBjdXJyZW50U2xpZGVJbmRleCA9PT0gMSkge1xyXG5cdFx0XHRcdGRpcmVjdGlvbiA9IC0xO1xyXG5cdFx0XHR9IGVsc2UgaWYgKGN1cnJlbnRTbGlkZUluZGV4ID09PSAyICYmIGN1cnJlbnRWaWV3SW5kZXggPT09IDApIHtcclxuXHRcdFx0XHRkaXJlY3Rpb24gPSAtMTtcclxuXHRcdFx0XHR0aGlzLnNsaWRlci5zbGlkZVRvKDMsIDAsIGZhbHNlKTtcclxuXHRcdFx0fVxyXG5cdFx0XHR0aGlzLmN1cnJlbnRWaWV3SW5kZXggPSBjdXJyZW50U2xpZGVJbmRleDtcclxuXHRcdFx0dGhpcy5tb3ZlKGRpcmVjdGlvbik7XHJcblx0XHR9KTtcclxuXHR9XHJcblxyXG5cdG1vdmUoZGlyZWN0aW9uOiBudW1iZXIpIHtcclxuXHRcdGlmIChkaXJlY3Rpb24gPT09IDApIHtcclxuXHRcdFx0cmV0dXJuO1xyXG5cdFx0fVxyXG5cdFx0dGhpcy5kaXJlY3Rpb24gPSBkaXJlY3Rpb247XHJcblx0XHRpZiAoIXRoaXMubW92ZU9uU2VsZWN0ZWQpIHtcclxuXHRcdFx0Y29uc3QgYWRqYWNlbnREYXRlID0gdGhpcy5jYWxlbmRhclNlcnZpY2UuZ2V0QWRqYWNlbnRDYWxlbmRhckRhdGUodGhpcy5tb2RlLCBkaXJlY3Rpb24pO1xyXG5cdFx0XHR0aGlzLmNhbGVuZGFyU2VydmljZS5zZXRDdXJyZW50RGF0ZShhZGphY2VudERhdGUpO1xyXG5cdFx0fVxyXG5cdFx0dGhpcy5yZWZyZXNoVmlldygpO1xyXG5cdFx0dGhpcy5kaXJlY3Rpb24gPSAwO1xyXG5cdFx0dGhpcy5tb3ZlT25TZWxlY3RlZCA9IGZhbHNlO1xyXG5cdH1cclxuXHJcblx0Y3JlYXRlRGF0ZU9iamVjdChkYXRlOiBEYXRlKTogSU1vbnRoVmlld1JvdyB7XHJcblx0XHRsZXQgZGlzYWJsZWQgPSBmYWxzZTtcclxuXHRcdGlmICh0aGlzLm1hcmtEaXNhYmxlZCkge1xyXG5cdFx0XHRkaXNhYmxlZCA9IHRoaXMubWFya0Rpc2FibGVkKGRhdGUpO1xyXG5cdFx0fVxyXG5cclxuXHRcdHJldHVybiB7XHJcblx0XHRcdGRhdGUsXHJcblx0XHRcdGV2ZW50czogW10sXHJcblx0XHRcdGxhYmVsOiB0aGlzLmZvcm1hdERheUxhYmVsKGRhdGUpLFxyXG5cdFx0XHRzZWNvbmRhcnk6IGZhbHNlLFxyXG5cdFx0XHRkaXNhYmxlZCxcclxuXHRcdH07XHJcblx0fVxyXG5cclxuXHRnZXRWaWV3RGF0YShzdGFydFRpbWU6IERhdGUpOiBJTW9udGhWaWV3IHtcclxuXHRcdGNvbnN0IHN0YXJ0RGF0ZSA9IHN0YXJ0VGltZSxcclxuXHRcdFx0ZGF0ZSA9IHN0YXJ0RGF0ZS5nZXREYXRlKCksXHJcblx0XHRcdG1vbnRoID0gKHN0YXJ0RGF0ZS5nZXRNb250aCgpICsgKGRhdGUgIT09IDEgPyAxIDogMCkpICUgMTI7XHJcblxyXG5cdFx0Y29uc3QgZGF0ZXMgPSBNb250aFZpZXdDb21wb25lbnQuZ2V0RGF0ZXMoc3RhcnREYXRlLCA0Mik7XHJcblx0XHRjb25zdCBkYXlzOiBJTW9udGhWaWV3Um93W10gPSBbXTtcclxuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgNDI7IGkrKykge1xyXG5cdFx0XHRjb25zdCBkYXRlT2JqZWN0ID0gdGhpcy5jcmVhdGVEYXRlT2JqZWN0KGRhdGVzW2ldKTtcclxuXHRcdFx0ZGF0ZU9iamVjdC5zZWNvbmRhcnkgPSBkYXRlc1tpXS5nZXRNb250aCgpICE9PSBtb250aDtcclxuXHRcdFx0ZGF5c1tpXSA9IGRhdGVPYmplY3Q7XHJcblx0XHR9XHJcblxyXG5cdFx0Y29uc3QgZGF5SGVhZGVyczogc3RyaW5nW10gPSBbXTtcclxuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgNzsgaSsrKSB7XHJcblx0XHRcdGRheUhlYWRlcnMucHVzaCh0aGlzLmZvcm1hdERheUhlYWRlckxhYmVsKGRheXNbaV0uZGF0ZSkpO1xyXG5cdFx0fVxyXG5cdFx0cmV0dXJuIHtcclxuXHRcdFx0ZGF0ZXM6IGRheXMsXHJcblx0XHRcdGRheUhlYWRlcnMsXHJcblx0XHR9O1xyXG5cdH1cclxuXHJcblx0Z2V0SGlnaGxpZ2h0Q2xhc3MoZGF0ZTogSU1vbnRoVmlld1Jvdyk6IHN0cmluZyB7XHJcblx0XHRsZXQgY2xhc3NOYW1lID0gJyc7XHJcblxyXG5cdFx0aWYgKGRhdGUuaGFzRXZlbnQpIHtcclxuXHRcdFx0aWYgKGRhdGUuc2Vjb25kYXJ5KSB7XHJcblx0XHRcdFx0Y2xhc3NOYW1lID0gJ21vbnRodmlldy1zZWNvbmRhcnktd2l0aC1ldmVudCc7XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0Y2xhc3NOYW1lID0gJ21vbnRodmlldy1wcmltYXJ5LXdpdGgtZXZlbnQnO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKGRhdGUuc2VsZWN0ZWQpIHtcclxuXHRcdFx0aWYgKGNsYXNzTmFtZSkge1xyXG5cdFx0XHRcdGNsYXNzTmFtZSArPSAnICc7XHJcblx0XHRcdH1cclxuXHRcdFx0Y2xhc3NOYW1lICs9ICdtb250aHZpZXctc2VsZWN0ZWQnO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmIChkYXRlLmN1cnJlbnQpIHtcclxuXHRcdFx0aWYgKGNsYXNzTmFtZSkge1xyXG5cdFx0XHRcdGNsYXNzTmFtZSArPSAnICc7XHJcblx0XHRcdH1cclxuXHRcdFx0Y2xhc3NOYW1lICs9ICdtb250aHZpZXctY3VycmVudCc7XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKGRhdGUuc2Vjb25kYXJ5KSB7XHJcblx0XHRcdGlmIChjbGFzc05hbWUpIHtcclxuXHRcdFx0XHRjbGFzc05hbWUgKz0gJyAnO1xyXG5cdFx0XHR9XHJcblx0XHRcdGNsYXNzTmFtZSArPSAndGV4dC1tdXRlZCc7XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKGRhdGUuZGlzYWJsZWQpIHtcclxuXHRcdFx0aWYgKGNsYXNzTmFtZSkge1xyXG5cdFx0XHRcdGNsYXNzTmFtZSArPSAnICc7XHJcblx0XHRcdH1cclxuXHRcdFx0Y2xhc3NOYW1lICs9ICdtb250aHZpZXctZGlzYWJsZWQnO1xyXG5cdFx0fVxyXG5cdFx0cmV0dXJuIGNsYXNzTmFtZTtcclxuXHR9XHJcblxyXG5cdGdldFJhbmdlKGN1cnJlbnREYXRlOiBEYXRlKTogSVJhbmdlIHtcclxuXHRcdGNvbnN0IHllYXIgPSBjdXJyZW50RGF0ZS5nZXRGdWxsWWVhcigpLFxyXG5cdFx0XHRtb250aCA9IGN1cnJlbnREYXRlLmdldE1vbnRoKCksXHJcblx0XHRcdGZpcnN0RGF5T2ZNb250aCA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCAxLCAxMiwgMCwgMCksIC8vIHNldCBob3VyIHRvIDEyIHRvIGF2b2lkIERTVCBwcm9ibGVtXHJcblx0XHRcdGRpZmZlcmVuY2UgPSB0aGlzLnN0YXJ0aW5nRGF5TW9udGggLSBmaXJzdERheU9mTW9udGguZ2V0RGF5KCksXHJcblx0XHRcdG51bURpc3BsYXllZEZyb21QcmV2aW91c01vbnRoID0gZGlmZmVyZW5jZSA+IDAgPyA3IC0gZGlmZmVyZW5jZSA6IC1kaWZmZXJlbmNlLFxyXG5cdFx0XHRzdGFydERhdGUgPSBuZXcgRGF0ZShmaXJzdERheU9mTW9udGguZ2V0VGltZSgpKTtcclxuXHJcblx0XHRpZiAobnVtRGlzcGxheWVkRnJvbVByZXZpb3VzTW9udGggPiAwKSB7XHJcblx0XHRcdHN0YXJ0RGF0ZS5zZXREYXRlKC1udW1EaXNwbGF5ZWRGcm9tUHJldmlvdXNNb250aCArIDEpO1xyXG5cdFx0fVxyXG5cclxuXHRcdGNvbnN0IGVuZERhdGUgPSBuZXcgRGF0ZShzdGFydERhdGUuZ2V0VGltZSgpKTtcclxuXHRcdGVuZERhdGUuc2V0RGF0ZShlbmREYXRlLmdldERhdGUoKSArIDQyKTtcclxuXHJcblx0XHRyZXR1cm4ge1xyXG5cdFx0XHRzdGFydFRpbWU6IHN0YXJ0RGF0ZSxcclxuXHRcdFx0ZW5kVGltZTogZW5kRGF0ZSxcclxuXHRcdH07XHJcblx0fVxyXG5cclxuXHRvbkRhdGFMb2FkZWQoKSB7XHJcblx0XHRjb25zdCByYW5nZSA9IHRoaXMucmFuZ2UsXHJcblx0XHRcdGV2ZW50U291cmNlID0gdGhpcy5ldmVudFNvdXJjZSxcclxuXHRcdFx0bGVuID0gZXZlbnRTb3VyY2UgPyBldmVudFNvdXJjZS5sZW5ndGggOiAwLFxyXG5cdFx0XHRzdGFydFRpbWUgPSByYW5nZS5zdGFydFRpbWUsXHJcblx0XHRcdGVuZFRpbWUgPSByYW5nZS5lbmRUaW1lLFxyXG5cdFx0XHR1dGNTdGFydFRpbWUgPSBEYXRlLlVUQyhzdGFydFRpbWUuZ2V0RnVsbFllYXIoKSwgc3RhcnRUaW1lLmdldE1vbnRoKCksIHN0YXJ0VGltZS5nZXREYXRlKCkpLFxyXG5cdFx0XHR1dGNFbmRUaW1lID0gRGF0ZS5VVEMoZW5kVGltZS5nZXRGdWxsWWVhcigpLCBlbmRUaW1lLmdldE1vbnRoKCksIGVuZFRpbWUuZ2V0RGF0ZSgpKSxcclxuXHRcdFx0Y3VycmVudFZpZXdJbmRleCA9IHRoaXMuY3VycmVudFZpZXdJbmRleCxcclxuXHRcdFx0ZGF0ZXMgPSB0aGlzLnZpZXdzW2N1cnJlbnRWaWV3SW5kZXhdLmRhdGVzLFxyXG5cdFx0XHRvbmVEYXkgPSA4NjQwMDAwMCxcclxuXHRcdFx0ZXBzID0gMC4wMDA2O1xyXG5cclxuXHRcdGZvciAobGV0IHIgPSAwOyByIDwgNDI7IHIgKz0gMSkge1xyXG5cdFx0XHRpZiAoZGF0ZXNbcl0uaGFzRXZlbnQpIHtcclxuXHRcdFx0XHRkYXRlc1tyXS5oYXNFdmVudCA9IGZhbHNlO1xyXG5cdFx0XHRcdGRhdGVzW3JdLmV2ZW50cyA9IFtdO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblxyXG5cdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkgKz0gMSkge1xyXG5cdFx0XHRjb25zdCBldmVudCA9IGV2ZW50U291cmNlW2ldLFxyXG5cdFx0XHRcdGV2ZW50U3RhcnRUaW1lID0gZXZlbnQuc3RhcnRUaW1lLFxyXG5cdFx0XHRcdGV2ZW50RW5kVGltZSA9IGV2ZW50LmVuZFRpbWU7XHJcblxyXG5cdFx0XHRsZXQgZXZlbnRVVENTdGFydFRpbWU6IG51bWJlciwgZXZlbnRVVENFbmRUaW1lOiBudW1iZXI7XHJcblx0XHRcdGlmIChldmVudC5hbGxEYXkpIHtcclxuXHRcdFx0XHRldmVudFVUQ1N0YXJ0VGltZSA9IGV2ZW50U3RhcnRUaW1lLmdldFRpbWUoKTtcclxuXHRcdFx0XHRldmVudFVUQ0VuZFRpbWUgPSBldmVudEVuZFRpbWUuZ2V0VGltZSgpO1xyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdGV2ZW50VVRDU3RhcnRUaW1lID0gRGF0ZS5VVEMoZXZlbnRTdGFydFRpbWUuZ2V0RnVsbFllYXIoKSwgZXZlbnRTdGFydFRpbWUuZ2V0TW9udGgoKSwgZXZlbnRTdGFydFRpbWUuZ2V0RGF0ZSgpKTtcclxuXHRcdFx0XHRldmVudFVUQ0VuZFRpbWUgPSBEYXRlLlVUQyhldmVudEVuZFRpbWUuZ2V0RnVsbFllYXIoKSwgZXZlbnRFbmRUaW1lLmdldE1vbnRoKCksIGV2ZW50RW5kVGltZS5nZXREYXRlKCkgKyAxKTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0aWYgKGV2ZW50VVRDRW5kVGltZSA8PSB1dGNTdGFydFRpbWUgfHwgZXZlbnRVVENTdGFydFRpbWUgPj0gdXRjRW5kVGltZSkge1xyXG5cdFx0XHRcdGNvbnRpbnVlO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRsZXQgdGltZURpZmZlcmVuY2VTdGFydDogbnVtYmVyLCB0aW1lRGlmZmVyZW5jZUVuZDogbnVtYmVyO1xyXG5cclxuXHRcdFx0aWYgKGV2ZW50VVRDU3RhcnRUaW1lIDwgdXRjU3RhcnRUaW1lKSB7XHJcblx0XHRcdFx0dGltZURpZmZlcmVuY2VTdGFydCA9IDA7XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0dGltZURpZmZlcmVuY2VTdGFydCA9IChldmVudFVUQ1N0YXJ0VGltZSAtIHV0Y1N0YXJ0VGltZSkgLyBvbmVEYXk7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGlmIChldmVudFVUQ0VuZFRpbWUgPiB1dGNFbmRUaW1lKSB7XHJcblx0XHRcdFx0dGltZURpZmZlcmVuY2VFbmQgPSAodXRjRW5kVGltZSAtIHV0Y1N0YXJ0VGltZSkgLyBvbmVEYXk7XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0dGltZURpZmZlcmVuY2VFbmQgPSAoZXZlbnRVVENFbmRUaW1lIC0gdXRjU3RhcnRUaW1lKSAvIG9uZURheTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0bGV0IGluZGV4ID0gTWF0aC5mbG9vcih0aW1lRGlmZmVyZW5jZVN0YXJ0KTtcclxuXHRcdFx0Y29uc3QgZW5kSW5kZXggPSBNYXRoLmNlaWwodGltZURpZmZlcmVuY2VFbmQgLSBlcHMpO1xyXG5cdFx0XHR3aGlsZSAoaW5kZXggPCBlbmRJbmRleCkge1xyXG5cdFx0XHRcdGRhdGVzW2luZGV4XS5oYXNFdmVudCA9IHRydWU7XHJcblx0XHRcdFx0bGV0IGV2ZW50U2V0ID0gZGF0ZXNbaW5kZXhdLmV2ZW50cztcclxuXHRcdFx0XHRpZiAoZXZlbnRTZXQpIHtcclxuXHRcdFx0XHRcdGV2ZW50U2V0LnB1c2goZXZlbnQpO1xyXG5cdFx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0XHRldmVudFNldCA9IFtdO1xyXG5cdFx0XHRcdFx0ZXZlbnRTZXQucHVzaChldmVudCk7XHJcblx0XHRcdFx0XHRkYXRlc1tpbmRleF0uZXZlbnRzID0gZXZlbnRTZXQ7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGluZGV4ICs9IDE7XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHJcblx0XHRmb3IgKGxldCByID0gMDsgciA8IDQyOyByICs9IDEpIHtcclxuXHRcdFx0aWYgKGRhdGVzW3JdLmhhc0V2ZW50KSB7XHJcblx0XHRcdFx0ZGF0ZXNbcl0uZXZlbnRzLnNvcnQodGhpcy5jb21wYXJlRXZlbnQpO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKHRoaXMuYXV0b1NlbGVjdCkge1xyXG5cdFx0XHRsZXQgZmluZFNlbGVjdGVkID0gZmFsc2U7XHJcblx0XHRcdGZvciAobGV0IHIgPSAwOyByIDwgNDI7IHIgKz0gMSkge1xyXG5cdFx0XHRcdGlmIChkYXRlc1tyXS5zZWxlY3RlZCkge1xyXG5cdFx0XHRcdFx0dGhpcy5zZWxlY3RlZERhdGUgPSBkYXRlc1tyXTtcclxuXHRcdFx0XHRcdGZpbmRTZWxlY3RlZCA9IHRydWU7XHJcblx0XHRcdFx0XHRicmVhaztcclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGlmIChmaW5kU2VsZWN0ZWQpIHtcclxuXHRcdFx0XHR0aGlzLm9uVGltZVNlbGVjdGVkLmVtaXQoe1xyXG5cdFx0XHRcdFx0c2VsZWN0ZWRUaW1lOiB0aGlzLnNlbGVjdGVkRGF0ZS5kYXRlLFxyXG5cdFx0XHRcdFx0ZXZlbnRzOiB0aGlzLnNlbGVjdGVkRGF0ZS5ldmVudHMsXHJcblx0XHRcdFx0XHRkaXNhYmxlZDogdGhpcy5zZWxlY3RlZERhdGUuZGlzYWJsZWQsXHJcblx0XHRcdFx0fSk7XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdHJlZnJlc2hWaWV3KCkge1xyXG5cdFx0dGhpcy5yYW5nZSA9IHRoaXMuZ2V0UmFuZ2UodGhpcy5jYWxlbmRhclNlcnZpY2UuY3VycmVudERhdGUpO1xyXG5cclxuXHRcdGlmICh0aGlzLmluaXRlZCkge1xyXG5cdFx0XHRjb25zdCB0aXRsZSA9IHRoaXMuZ2V0VGl0bGUoKTtcclxuXHRcdFx0dGhpcy5vblRpdGxlQ2hhbmdlZC5lbWl0KHRpdGxlKTtcclxuXHRcdH1cclxuXHRcdHRoaXMuY2FsZW5kYXJTZXJ2aWNlLnBvcHVsYXRlQWRqYWNlbnRWaWV3cyh0aGlzKTtcclxuXHRcdHRoaXMudXBkYXRlQ3VycmVudFZpZXcodGhpcy5yYW5nZS5zdGFydFRpbWUsIHRoaXMudmlld3NbdGhpcy5jdXJyZW50Vmlld0luZGV4XSk7XHJcblx0XHR0aGlzLmNhbGVuZGFyU2VydmljZS5yYW5nZUNoYW5nZWQodGhpcyk7XHJcblx0fVxyXG5cclxuXHRnZXRUaXRsZSgpOiBzdHJpbmcge1xyXG5cdFx0Y29uc3QgY3VycmVudFZpZXdTdGFydERhdGUgPSB0aGlzLnJhbmdlLnN0YXJ0VGltZSxcclxuXHRcdFx0ZGF0ZSA9IGN1cnJlbnRWaWV3U3RhcnREYXRlLmdldERhdGUoKSxcclxuXHRcdFx0bW9udGggPSAoY3VycmVudFZpZXdTdGFydERhdGUuZ2V0TW9udGgoKSArIChkYXRlICE9PSAxID8gMSA6IDApKSAlIDEyLFxyXG5cdFx0XHR5ZWFyID0gY3VycmVudFZpZXdTdGFydERhdGUuZ2V0RnVsbFllYXIoKSArIChkYXRlICE9PSAxICYmIG1vbnRoID09PSAwID8gMSA6IDApLFxyXG5cdFx0XHRoZWFkZXJEYXRlID0gbmV3IERhdGUoeWVhciwgbW9udGgsIDEsIDEyLCAwLCAwLCAwKTtcclxuXHRcdHJldHVybiB0aGlzLmZvcm1hdFRpdGxlKGhlYWRlckRhdGUpO1xyXG5cdH1cclxuXHJcblx0cHJpdmF0ZSBjb21wYXJlRXZlbnQoZXZlbnQxOiBJRXZlbnQsIGV2ZW50MjogSUV2ZW50KTogbnVtYmVyIHtcclxuXHRcdGlmIChldmVudDEuYWxsRGF5KSB7XHJcblx0XHRcdHJldHVybiAxO1xyXG5cdFx0fSBlbHNlIGlmIChldmVudDIuYWxsRGF5KSB7XHJcblx0XHRcdHJldHVybiAtMTtcclxuXHRcdH0gZWxzZSB7XHJcblx0XHRcdHJldHVybiBldmVudDEuc3RhcnRUaW1lLmdldFRpbWUoKSAtIGV2ZW50Mi5zdGFydFRpbWUuZ2V0VGltZSgpO1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0c2VsZWN0KHZpZXdEYXRlOiBJTW9udGhWaWV3Um93KSB7XHJcblx0XHRpZiAoIXRoaXMudmlld3MpIHtcclxuXHRcdFx0cmV0dXJuO1xyXG5cdFx0fVxyXG5cclxuXHRcdGNvbnN0IHNlbGVjdGVkRGF0ZSA9IHZpZXdEYXRlLmRhdGUsXHJcblx0XHRcdGV2ZW50cyA9IHZpZXdEYXRlLmV2ZW50cztcclxuXHJcblx0XHRpZiAoIXZpZXdEYXRlLmRpc2FibGVkKSB7XHJcblx0XHRcdGNvbnN0IGRhdGVzID0gdGhpcy52aWV3c1t0aGlzLmN1cnJlbnRWaWV3SW5kZXhdLmRhdGVzLFxyXG5cdFx0XHRcdGN1cnJlbnRDYWxlbmRhckRhdGUgPSB0aGlzLmNhbGVuZGFyU2VydmljZS5jdXJyZW50RGF0ZSxcclxuXHRcdFx0XHRjdXJyZW50TW9udGggPSBjdXJyZW50Q2FsZW5kYXJEYXRlLmdldE1vbnRoKCksXHJcblx0XHRcdFx0Y3VycmVudFllYXIgPSBjdXJyZW50Q2FsZW5kYXJEYXRlLmdldEZ1bGxZZWFyKCksXHJcblx0XHRcdFx0c2VsZWN0ZWRNb250aCA9IHNlbGVjdGVkRGF0ZS5nZXRNb250aCgpLFxyXG5cdFx0XHRcdHNlbGVjdGVkWWVhciA9IHNlbGVjdGVkRGF0ZS5nZXRGdWxsWWVhcigpO1xyXG5cdFx0XHRsZXQgZGlyZWN0aW9uID0gMDtcclxuXHJcblx0XHRcdGlmIChjdXJyZW50WWVhciA9PT0gc2VsZWN0ZWRZZWFyKSB7XHJcblx0XHRcdFx0aWYgKGN1cnJlbnRNb250aCAhPT0gc2VsZWN0ZWRNb250aCkge1xyXG5cdFx0XHRcdFx0ZGlyZWN0aW9uID0gY3VycmVudE1vbnRoIDwgc2VsZWN0ZWRNb250aCA/IDEgOiAtMTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0ZGlyZWN0aW9uID0gY3VycmVudFllYXIgPCBzZWxlY3RlZFllYXIgPyAxIDogLTE7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdHRoaXMuY2FsZW5kYXJTZXJ2aWNlLnNldEluaXRpYWxEYXRlKHNlbGVjdGVkRGF0ZSk7XHJcblx0XHRcdGlmIChkaXJlY3Rpb24gPT09IDApIHtcclxuXHRcdFx0XHRjb25zdCBjdXJyZW50Vmlld1N0YXJ0RGF0ZSA9IHRoaXMucmFuZ2Uuc3RhcnRUaW1lLFxyXG5cdFx0XHRcdFx0b25lRGF5ID0gODY0MDAwMDAsXHJcblx0XHRcdFx0XHRzZWxlY3RlZERheURpZmZlcmVuY2UgPSBNYXRoLnJvdW5kKFxyXG5cdFx0XHRcdFx0XHQoRGF0ZS5VVEMoc2VsZWN0ZWREYXRlLmdldEZ1bGxZZWFyKCksIHNlbGVjdGVkRGF0ZS5nZXRNb250aCgpLCBzZWxlY3RlZERhdGUuZ2V0RGF0ZSgpKSAtXHJcblx0XHRcdFx0XHRcdFx0RGF0ZS5VVEMoY3VycmVudFZpZXdTdGFydERhdGUuZ2V0RnVsbFllYXIoKSwgY3VycmVudFZpZXdTdGFydERhdGUuZ2V0TW9udGgoKSwgY3VycmVudFZpZXdTdGFydERhdGUuZ2V0RGF0ZSgpKSkgL1xyXG5cdFx0XHRcdFx0XHRcdG9uZURheVxyXG5cdFx0XHRcdFx0KTtcclxuXHJcblx0XHRcdFx0Zm9yIChsZXQgciA9IDA7IHIgPCA0MjsgciArPSAxKSB7XHJcblx0XHRcdFx0XHRkYXRlc1tyXS5zZWxlY3RlZCA9IGZhbHNlO1xyXG5cdFx0XHRcdH1cclxuXHJcblx0XHRcdFx0aWYgKHNlbGVjdGVkRGF5RGlmZmVyZW5jZSA+PSAwICYmIHNlbGVjdGVkRGF5RGlmZmVyZW5jZSA8IDQyKSB7XHJcblx0XHRcdFx0XHRkYXRlc1tzZWxlY3RlZERheURpZmZlcmVuY2VdLnNlbGVjdGVkID0gdHJ1ZTtcclxuXHRcdFx0XHRcdHRoaXMuc2VsZWN0ZWREYXRlID0gZGF0ZXNbc2VsZWN0ZWREYXlEaWZmZXJlbmNlXTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0dGhpcy5tb3ZlT25TZWxlY3RlZCA9IHRydWU7XHJcblx0XHRcdFx0dGhpcy5zbGlkZVZpZXcoZGlyZWN0aW9uKTtcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cclxuXHRcdHRoaXMub25UaW1lU2VsZWN0ZWQuZW1pdCh7XHJcblx0XHRcdHNlbGVjdGVkVGltZTogc2VsZWN0ZWREYXRlLFxyXG5cdFx0XHRldmVudHMsXHJcblx0XHRcdGRpc2FibGVkOiB2aWV3RGF0ZS5kaXNhYmxlZCxcclxuXHRcdH0pO1xyXG5cdH1cclxuXHJcblx0c2xpZGVWaWV3KGRpcmVjdGlvbjogbnVtYmVyKSB7XHJcblx0XHRpZiAoZGlyZWN0aW9uID09PSAxKSB7XHJcblx0XHRcdHRoaXMuc2xpZGVyLnNsaWRlTmV4dCgpO1xyXG5cdFx0fSBlbHNlIGlmIChkaXJlY3Rpb24gPT09IC0xKSB7XHJcblx0XHRcdHRoaXMuc2xpZGVyLnNsaWRlUHJldigpO1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0dXBkYXRlQ3VycmVudFZpZXcoY3VycmVudFZpZXdTdGFydERhdGU6IERhdGUsIHZpZXc6IElNb250aFZpZXcpIHtcclxuXHRcdGNvbnN0IGN1cnJlbnRDYWxlbmRhckRhdGUgPSB0aGlzLmNhbGVuZGFyU2VydmljZS5pbml0aWFsRGF0ZSxcclxuXHRcdFx0dG9kYXkgPSBuZXcgRGF0ZSgpLFxyXG5cdFx0XHRvbmVEYXkgPSA4NjQwMDAwMCxcclxuXHRcdFx0c2VsZWN0ZWREYXlEaWZmZXJlbmNlID0gTWF0aC5yb3VuZChcclxuXHRcdFx0XHQoRGF0ZS5VVEMoY3VycmVudENhbGVuZGFyRGF0ZS5nZXRGdWxsWWVhcigpLCBjdXJyZW50Q2FsZW5kYXJEYXRlLmdldE1vbnRoKCksIGN1cnJlbnRDYWxlbmRhckRhdGUuZ2V0RGF0ZSgpKSAtXHJcblx0XHRcdFx0XHREYXRlLlVUQyhjdXJyZW50Vmlld1N0YXJ0RGF0ZS5nZXRGdWxsWWVhcigpLCBjdXJyZW50Vmlld1N0YXJ0RGF0ZS5nZXRNb250aCgpLCBjdXJyZW50Vmlld1N0YXJ0RGF0ZS5nZXREYXRlKCkpKSAvXHJcblx0XHRcdFx0XHRvbmVEYXlcclxuXHRcdFx0KSxcclxuXHRcdFx0Y3VycmVudERheURpZmZlcmVuY2UgPSBNYXRoLnJvdW5kKFxyXG5cdFx0XHRcdChEYXRlLlVUQyh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCB0b2RheS5nZXREYXRlKCkpIC1cclxuXHRcdFx0XHRcdERhdGUuVVRDKGN1cnJlbnRWaWV3U3RhcnREYXRlLmdldEZ1bGxZZWFyKCksIGN1cnJlbnRWaWV3U3RhcnREYXRlLmdldE1vbnRoKCksIGN1cnJlbnRWaWV3U3RhcnREYXRlLmdldERhdGUoKSkpIC9cclxuXHRcdFx0XHRcdG9uZURheVxyXG5cdFx0XHQpO1xyXG5cclxuXHRcdGZvciAobGV0IHIgPSAwOyByIDwgNDI7IHIgKz0gMSkge1xyXG5cdFx0XHR2aWV3LmRhdGVzW3JdLnNlbGVjdGVkID0gZmFsc2U7XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKFxyXG5cdFx0XHRzZWxlY3RlZERheURpZmZlcmVuY2UgPj0gMCAmJlxyXG5cdFx0XHRzZWxlY3RlZERheURpZmZlcmVuY2UgPCA0MiAmJlxyXG5cdFx0XHQhdmlldy5kYXRlc1tzZWxlY3RlZERheURpZmZlcmVuY2VdLmRpc2FibGVkICYmXHJcblx0XHRcdCh0aGlzLmF1dG9TZWxlY3QgfHwgdGhpcy5tb3ZlT25TZWxlY3RlZClcclxuXHRcdCkge1xyXG5cdFx0XHR2aWV3LmRhdGVzW3NlbGVjdGVkRGF5RGlmZmVyZW5jZV0uc2VsZWN0ZWQgPSB0cnVlO1xyXG5cdFx0XHR0aGlzLnNlbGVjdGVkRGF0ZSA9IHZpZXcuZGF0ZXNbc2VsZWN0ZWREYXlEaWZmZXJlbmNlXTtcclxuXHRcdH0gZWxzZSB7XHJcblx0XHRcdHRoaXMuc2VsZWN0ZWREYXRlID0ge1xyXG5cdFx0XHRcdGRhdGU6IG51bGwsXHJcblx0XHRcdFx0ZXZlbnRzOiBbXSxcclxuXHRcdFx0XHRsYWJlbDogbnVsbCxcclxuXHRcdFx0XHRzZWNvbmRhcnk6IG51bGwsXHJcblx0XHRcdFx0ZGlzYWJsZWQ6IGZhbHNlLFxyXG5cdFx0XHR9O1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmIChjdXJyZW50RGF5RGlmZmVyZW5jZSA+PSAwICYmIGN1cnJlbnREYXlEaWZmZXJlbmNlIDwgNDIpIHtcclxuXHRcdFx0dmlldy5kYXRlc1tjdXJyZW50RGF5RGlmZmVyZW5jZV0uY3VycmVudCA9IHRydWU7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHRldmVudFNlbGVjdGVkKGV2ZW50OiBJRXZlbnQpIHtcclxuXHRcdHRoaXMub25FdmVudFNlbGVjdGVkLmVtaXQoZXZlbnQpO1xyXG5cdH1cclxufVxyXG4iXX0=