import { __decorate, __param } from "tslib";
import { Component, EventEmitter, Input, Output, Inject, LOCALE_ID, } from "@angular/core";
import { CalendarService } from "./calendar.service";
export var Step;
(function (Step) {
    Step[Step["QuarterHour"] = 15] = "QuarterHour";
    Step[Step["HalfHour"] = 30] = "HalfHour";
    Step[Step["Hour"] = 60] = "Hour";
})(Step || (Step = {}));
let CalendarComponent = class CalendarComponent {
    constructor(calendarService, appLocale) {
        this.calendarService = calendarService;
        this.appLocale = appLocale;
        this.eventSource = [];
        this.calendarMode = "month";
        this.formatDay = "d";
        this.formatDayHeader = "EEE";
        this.formatDayTitle = "MMMM dd, yyyy";
        this.formatWeekTitle = "MMMM yyyy, 'Week' w";
        this.formatMonthTitle = "MMMM yyyy";
        this.formatWeekViewDayHeader = "EEE d";
        this.formatHourColumn = "ha";
        this.showEventDetail = true;
        this.startingDayMonth = 0;
        this.startingDayWeek = 0;
        this.allDayLabel = "all day";
        this.noEventsLabel = "No Events";
        this.queryMode = "local";
        this.step = Step.Hour;
        this.timeInterval = 60;
        this.autoSelect = true;
        this.dir = "";
        this.scrollToHour = 0;
        this.preserveScrollPosition = false;
        this.lockSwipeToPrev = false;
        this.lockSwipes = false;
        this.locale = "";
        this.startHour = 0;
        this.endHour = 24;
        this.onCurrentDateChanged = new EventEmitter();
        this.onRangeChanged = new EventEmitter();
        this.onEventSelected = new EventEmitter();
        this.onTimeSelected = new EventEmitter();
        this.onDayHeaderSelected = new EventEmitter();
        this.onTitleChanged = new EventEmitter();
        this.hourParts = 1;
        this.hourSegments = 1;
        this.locale = appLocale;
    }
    get currentDate() {
        return this._currentDate;
    }
    set currentDate(val) {
        if (!val) {
            val = new Date();
        }
        this._currentDate = val;
        this.calendarService.setInitialDate(val, true);
        this.onCurrentDateChanged.emit(this._currentDate);
    }
    ngOnInit() {
        if (this.autoSelect) {
            if (this.autoSelect.toString() === "false") {
                this.autoSelect = false;
            }
            else {
                this.autoSelect = true;
            }
        }
        this.hourSegments = 60 / this.timeInterval;
        this.hourParts = 60 / this.step;
        if (this.hourParts <= this.hourSegments) {
            this.hourParts = 1;
        }
        else {
            this.hourParts = this.hourParts / this.hourSegments;
        }
        this.startHour = parseInt(this.startHour.toString());
        this.endHour = parseInt(this.endHour.toString());
        this.calendarService.queryMode = this.queryMode;
        this.currentDateChangedFromChildrenSubscription =
            this.calendarService.currentDateChangedFromChildren$.subscribe((currentDate) => {
                this._currentDate = currentDate;
                this.onCurrentDateChanged.emit(currentDate);
            });
    }
    ngOnDestroy() {
        if (this.currentDateChangedFromChildrenSubscription) {
            this.currentDateChangedFromChildrenSubscription.unsubscribe();
            this.currentDateChangedFromChildrenSubscription = null;
        }
    }
    rangeChanged(range) {
        this.onRangeChanged.emit(range);
    }
    eventSelected(event) {
        this.onEventSelected.emit(event);
    }
    timeSelected(timeSelected) {
        this.onTimeSelected.emit(timeSelected);
    }
    daySelected(daySelected) {
        this.onDayHeaderSelected.emit(daySelected);
    }
    titleChanged(title) {
        this.onTitleChanged.emit(title);
    }
    loadEvents() {
        this.calendarService.loadEvents();
    }
    slideNext() {
        this.calendarService.slide(1);
    }
    slidePrev() {
        this.calendarService.slide(-1);
    }
    update() {
        this.calendarService.update();
    }
};
CalendarComponent.ctorParameters = () => [
    { type: CalendarService },
    { type: String, decorators: [{ type: Inject, args: [LOCALE_ID,] }] }
];
__decorate([
    Input()
], CalendarComponent.prototype, "currentDate", null);
__decorate([
    Input()
], CalendarComponent.prototype, "eventSource", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "calendarMode", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "formatDay", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "formatDayHeader", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "formatDayTitle", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "formatWeekTitle", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "formatMonthTitle", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "formatWeekViewDayHeader", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "formatHourColumn", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "showEventDetail", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "startingDayMonth", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "startingDayWeek", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "allDayLabel", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "noEventsLabel", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "queryMode", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "step", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "timeInterval", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "autoSelect", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "markDisabled", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "monthviewDisplayEventTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "monthviewInactiveDisplayEventTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "monthviewEventDetailTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "weekviewHeaderTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "weekviewAllDayEventTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "weekviewNormalEventTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dayviewAllDayEventTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dayviewNormalEventTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "weekviewAllDayEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "weekviewNormalEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dayviewAllDayEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dayviewNormalEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "weekviewInactiveAllDayEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "weekviewInactiveNormalEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dayviewInactiveAllDayEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dayviewInactiveNormalEventSectionTemplate", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dateFormatter", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "dir", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "scrollToHour", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "preserveScrollPosition", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "lockSwipeToPrev", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "lockSwipes", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "locale", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "startHour", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "endHour", void 0);
__decorate([
    Input()
], CalendarComponent.prototype, "sliderOptions", void 0);
__decorate([
    Output()
], CalendarComponent.prototype, "onCurrentDateChanged", void 0);
__decorate([
    Output()
], CalendarComponent.prototype, "onRangeChanged", void 0);
__decorate([
    Output()
], CalendarComponent.prototype, "onEventSelected", void 0);
__decorate([
    Output()
], CalendarComponent.prototype, "onTimeSelected", void 0);
__decorate([
    Output()
], CalendarComponent.prototype, "onDayHeaderSelected", void 0);
__decorate([
    Output()
], CalendarComponent.prototype, "onTitleChanged", void 0);
CalendarComponent = __decorate([
    Component({
        selector: "calendar",
        template: `
        <ng-template
            #monthviewDefaultDisplayEventTemplate
            let-view="view"
            let-row="row"
            let-col="col"
        >
            {{ view.dates[row * 7 + col].label }}
        </ng-template>
        <ng-template
            #monthviewDefaultEventDetailTemplate
            let-showEventDetail="showEventDetail"
            let-selectedDate="selectedDate"
            let-noEventsLabel="noEventsLabel"
        >
            <ion-list
                class="event-detail-container"
                has-bouncing="false"
                *ngIf="showEventDetail"
                overflow-scroll="false"
            >
                <ion-item
                    *ngFor="let event of selectedDate?.events"
                    (click)="eventSelected(event)"
                >
                    <span
                        *ngIf="!event.allDay"
                        class="monthview-eventdetail-timecolumn"
                        >{{ event.startTime | date: "HH:mm" }}
                        -
                        {{ event.endTime | date: "HH:mm" }}
                    </span>
                    <span
                        *ngIf="event.allDay"
                        class="monthview-eventdetail-timecolumn"
                        >{{ allDayLabel }}</span
                    >
                    <span class="event-detail"> | {{ event.title }}</span>
                </ion-item>
                <ion-item *ngIf="selectedDate?.events.length == 0">
                    <div class="no-events-label">{{ noEventsLabel }}</div>
                </ion-item>
            </ion-list>
        </ng-template>
        <ng-template #defaultWeekviewHeaderTemplate let-viewDate="viewDate">
            {{ viewDate.dayHeader }}
        </ng-template>
        <ng-template
            #defaultAllDayEventTemplate
            let-displayEvent="displayEvent"
        >
            <div class="calendar-event-inner">
                {{ displayEvent.event.title }}
            </div>
        </ng-template>
        <ng-template
            #defaultNormalEventTemplate
            let-displayEvent="displayEvent"
        >
            <div class="calendar-event-inner">
                {{ displayEvent.event.title }}
            </div>
        </ng-template>
        <ng-template
            #defaultWeekViewAllDayEventSectionTemplate
            let-day="day"
            let-eventTemplate="eventTemplate"
        >
            <div
                [ngClass]="{ 'calendar-event-wrap': day.events }"
                *ngIf="day.events"
                [ngStyle]="{ height: 25 * day.events.length + 'px' }"
            >
                <div
                    *ngFor="let displayEvent of day.events"
                    class="calendar-event"
                    tappable
                    (click)="eventSelected(displayEvent.event)"
                    [ngStyle]="{
                        top: 25 * displayEvent.position + 'px',
                        width:
                            100 *
                                (displayEvent.endIndex -
                                    displayEvent.startIndex) +
                            '%',
                        height: '25px'
                    }"
                >
                    <ng-template
                        [ngTemplateOutlet]="eventTemplate"
                        [ngTemplateOutletContext]="{
                            displayEvent: displayEvent
                        }"
                    >
                    </ng-template>
                </div>
            </div>
        </ng-template>
        <ng-template
            #defaultDayViewAllDayEventSectionTemplate
            let-allDayEvents="allDayEvents"
            let-eventTemplate="eventTemplate"
        >
            <div
                *ngFor="
                    let displayEvent of allDayEvents;
                    let eventIndex = index
                "
                class="calendar-event"
                tappable
                (click)="eventSelected(displayEvent.event)"
                [ngStyle]="{
                    top: 25 * eventIndex + 'px',
                    width: '100%',
                    height: '25px'
                }"
            >
                <ng-template
                    [ngTemplateOutlet]="eventTemplate"
                    [ngTemplateOutletContext]="{ displayEvent: displayEvent }"
                >
                </ng-template>
            </div>
        </ng-template>
        <ng-template
            #defaultNormalEventSectionTemplate
            let-tm="tm"
            let-hourParts="hourParts"
            let-eventTemplate="eventTemplate"
        >
            <div
                [ngClass]="{ 'calendar-event-wrap': tm.events }"
                *ngIf="tm.events"
            >
                <div
                    *ngFor="let displayEvent of tm.events"
                    class="calendar-event"
                    tappable
                    (click)="eventSelected(displayEvent.event)"
                    [ngStyle]="{
                        top: (37 * displayEvent.startOffset) / hourParts + 'px',
                        left:
                            (100 / displayEvent.overlapNumber) *
                                displayEvent.position +
                            '%',
                        width: 100 / displayEvent.overlapNumber + '%',
                        height:
                            37 *
                                (displayEvent.endIndex -
                                    displayEvent.startIndex -
                                    (displayEvent.endOffset +
                                        displayEvent.startOffset) /
                                        hourParts) +
                            'px'
                    }"
                >
                    <ng-template
                        [ngTemplateOutlet]="eventTemplate"
                        [ngTemplateOutletContext]="{
                            displayEvent: displayEvent
                        }"
                    >
                    </ng-template>
                </div>
            </div>
        </ng-template>
        <ng-template #defaultInactiveAllDayEventSectionTemplate> </ng-template>
        <ng-template #defaultInactiveNormalEventSectionTemplate> </ng-template>

        <div [ngSwitch]="calendarMode" class="{{ calendarMode }}view-container">
            <monthview
                *ngSwitchCase="'month'"
                [formatDay]="formatDay"
                [formatDayHeader]="formatDayHeader"
                [formatMonthTitle]="formatMonthTitle"
                [startingDayMonth]="startingDayMonth"
                [showEventDetail]="showEventDetail"
                [noEventsLabel]="noEventsLabel"
                [autoSelect]="autoSelect"
                [eventSource]="eventSource"
                [markDisabled]="markDisabled"
                [monthviewDisplayEventTemplate]="
                    monthviewDisplayEventTemplate ||
                    monthviewDefaultDisplayEventTemplate
                "
                [monthviewInactiveDisplayEventTemplate]="
                    monthviewInactiveDisplayEventTemplate ||
                    monthviewDefaultDisplayEventTemplate
                "
                [monthviewEventDetailTemplate]="
                    monthviewEventDetailTemplate ||
                    monthviewDefaultEventDetailTemplate
                "
                [locale]="locale"
                [dateFormatter]="dateFormatter"
                [dir]="dir"
                [lockSwipeToPrev]="lockSwipeToPrev"
                [lockSwipes]="lockSwipes"
                [sliderOptions]="sliderOptions"
                (onRangeChanged)="rangeChanged($event)"
                (onEventSelected)="eventSelected($event)"
                (onTimeSelected)="timeSelected($event)"
                (onTitleChanged)="titleChanged($event)"
            >
            </monthview>
            <weekview
                *ngSwitchCase="'week'"
                [formatWeekTitle]="formatWeekTitle"
                [formatWeekViewDayHeader]="formatWeekViewDayHeader"
                [formatHourColumn]="formatHourColumn"
                [startingDayWeek]="startingDayWeek"
                [allDayLabel]="allDayLabel"
                [hourParts]="hourParts"
                [autoSelect]="autoSelect"
                [hourSegments]="hourSegments"
                [eventSource]="eventSource"
                [markDisabled]="markDisabled"
                [weekviewHeaderTemplate]="
                    weekviewHeaderTemplate || defaultWeekviewHeaderTemplate
                "
                [weekviewAllDayEventTemplate]="
                    weekviewAllDayEventTemplate || defaultAllDayEventTemplate
                "
                [weekviewNormalEventTemplate]="
                    weekviewNormalEventTemplate || defaultNormalEventTemplate
                "
                [weekviewAllDayEventSectionTemplate]="
                    weekviewAllDayEventSectionTemplate ||
                    defaultWeekViewAllDayEventSectionTemplate
                "
                [weekviewNormalEventSectionTemplate]="
                    weekviewNormalEventSectionTemplate ||
                    defaultNormalEventSectionTemplate
                "
                [weekviewInactiveAllDayEventSectionTemplate]="
                    weekviewInactiveAllDayEventSectionTemplate ||
                    defaultInactiveAllDayEventSectionTemplate
                "
                [weekviewInactiveNormalEventSectionTemplate]="
                    weekviewInactiveNormalEventSectionTemplate ||
                    defaultInactiveNormalEventSectionTemplate
                "
                [locale]="locale"
                [dateFormatter]="dateFormatter"
                [dir]="dir"
                [scrollToHour]="scrollToHour"
                [preserveScrollPosition]="preserveScrollPosition"
                [lockSwipeToPrev]="lockSwipeToPrev"
                [lockSwipes]="lockSwipes"
                [startHour]="startHour"
                [endHour]="endHour"
                [sliderOptions]="sliderOptions"
                (onRangeChanged)="rangeChanged($event)"
                (onEventSelected)="eventSelected($event)"
                (onDayHeaderSelected)="daySelected($event)"
                (onTimeSelected)="timeSelected($event)"
                (onTitleChanged)="titleChanged($event)"
            >
            </weekview>
            <dayview
                *ngSwitchCase="'day'"
                [formatDayTitle]="formatDayTitle"
                [formatHourColumn]="formatHourColumn"
                [allDayLabel]="allDayLabel"
                [hourParts]="hourParts"
                [hourSegments]="hourSegments"
                [eventSource]="eventSource"
                [markDisabled]="markDisabled"
                [dayviewAllDayEventTemplate]="
                    dayviewAllDayEventTemplate || defaultAllDayEventTemplate
                "
                [dayviewNormalEventTemplate]="
                    dayviewNormalEventTemplate || defaultNormalEventTemplate
                "
                [dayviewAllDayEventSectionTemplate]="
                    dayviewAllDayEventSectionTemplate ||
                    defaultDayViewAllDayEventSectionTemplate
                "
                [dayviewNormalEventSectionTemplate]="
                    dayviewNormalEventSectionTemplate ||
                    defaultNormalEventSectionTemplate
                "
                [dayviewInactiveAllDayEventSectionTemplate]="
                    dayviewInactiveAllDayEventSectionTemplate ||
                    defaultInactiveAllDayEventSectionTemplate
                "
                [dayviewInactiveNormalEventSectionTemplate]="
                    dayviewInactiveNormalEventSectionTemplate ||
                    defaultInactiveNormalEventSectionTemplate
                "
                [locale]="locale"
                [dateFormatter]="dateFormatter"
                [dir]="dir"
                [scrollToHour]="scrollToHour"
                [preserveScrollPosition]="preserveScrollPosition"
                [lockSwipeToPrev]="lockSwipeToPrev"
                [lockSwipes]="lockSwipes"
                [startHour]="startHour"
                [endHour]="endHour"
                [sliderOptions]="sliderOptions"
                (onRangeChanged)="rangeChanged($event)"
                (onEventSelected)="eventSelected($event)"
                (onTimeSelected)="timeSelected($event)"
                (onTitleChanged)="titleChanged($event)"
            >
            </dayview>
        </div>
    `,
        providers: [CalendarService],
        styles: [`
            :host > div {
                height: 100%;
            }

            .event-detail-container {
                border-top: 2px darkgrey solid;
            }

            .no-events-label {
                font-weight: bold;
                color: darkgrey;
                text-align: center;
            }

            .event-detail {
                cursor: pointer;
                white-space: nowrap;
                text-overflow: ellipsis;
            }

            .monthview-eventdetail-timecolumn {
                width: 110px;
                overflow: hidden;
            }

            .calendar-event-inner {
                overflow: hidden;
                background-color: #3a87ad;
                color: white;
                height: 100%;
                width: 100%;
                padding: 2px;
                line-height: 15px;
                text-align: initial;
            }

            @media (max-width: 750px) {
                .calendar-event-inner {
                    font-size: 12px;
                }
            }
        `]
    }),
    __param(1, Inject(LOCALE_ID))
], CalendarComponent);
export { CalendarComponent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FsZW5kYXIuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AcGhlbWl1bS1jb3N0YWlzYS9pb25pYzItY2FsZW5kYXIvIiwic291cmNlcyI6WyJjYWxlbmRhci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxZQUFZLEVBQ1osS0FBSyxFQUVMLE1BQU0sRUFFTixNQUFNLEVBQ04sU0FBUyxHQUNaLE1BQU0sZUFBZSxDQUFDO0FBR3ZCLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQWdKckQsTUFBTSxDQUFOLElBQVksSUFJWDtBQUpELFdBQVksSUFBSTtJQUNaLDhDQUFnQixDQUFBO0lBQ2hCLHdDQUFhLENBQUE7SUFDYixnQ0FBUyxDQUFBO0FBQ2IsQ0FBQyxFQUpXLElBQUksS0FBSixJQUFJLFFBSWY7QUF1V0QsSUFBYSxpQkFBaUIsR0FBOUIsTUFBYSxpQkFBaUI7SUFxRjFCLFlBQ1ksZUFBZ0MsRUFDYixTQUFpQjtRQURwQyxvQkFBZSxHQUFmLGVBQWUsQ0FBaUI7UUFDYixjQUFTLEdBQVQsU0FBUyxDQUFRO1FBdkV2QyxnQkFBVyxHQUFhLEVBQUUsQ0FBQztRQUMzQixpQkFBWSxHQUFpQixPQUFPLENBQUM7UUFDckMsY0FBUyxHQUFXLEdBQUcsQ0FBQztRQUN4QixvQkFBZSxHQUFXLEtBQUssQ0FBQztRQUNoQyxtQkFBYyxHQUFXLGVBQWUsQ0FBQztRQUN6QyxvQkFBZSxHQUFXLHFCQUFxQixDQUFDO1FBQ2hELHFCQUFnQixHQUFXLFdBQVcsQ0FBQztRQUN2Qyw0QkFBdUIsR0FBVyxPQUFPLENBQUM7UUFDMUMscUJBQWdCLEdBQVcsSUFBSSxDQUFDO1FBQ2hDLG9CQUFlLEdBQVksSUFBSSxDQUFDO1FBQ2hDLHFCQUFnQixHQUFXLENBQUMsQ0FBQztRQUM3QixvQkFBZSxHQUFXLENBQUMsQ0FBQztRQUM1QixnQkFBVyxHQUFXLFNBQVMsQ0FBQztRQUNoQyxrQkFBYSxHQUFXLFdBQVcsQ0FBQztRQUNwQyxjQUFTLEdBQWMsT0FBTyxDQUFDO1FBQy9CLFNBQUksR0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQ3ZCLGlCQUFZLEdBQVcsRUFBRSxDQUFDO1FBQzFCLGVBQVUsR0FBWSxJQUFJLENBQUM7UUE4QjNCLFFBQUcsR0FBVyxFQUFFLENBQUM7UUFDakIsaUJBQVksR0FBVyxDQUFDLENBQUM7UUFDekIsMkJBQXNCLEdBQVksS0FBSyxDQUFDO1FBQ3hDLG9CQUFlLEdBQVksS0FBSyxDQUFDO1FBQ2pDLGVBQVUsR0FBWSxLQUFLLENBQUM7UUFDNUIsV0FBTSxHQUFXLEVBQUUsQ0FBQztRQUNwQixjQUFTLEdBQVcsQ0FBQyxDQUFDO1FBQ3RCLFlBQU8sR0FBVyxFQUFFLENBQUM7UUFHcEIseUJBQW9CLEdBQUcsSUFBSSxZQUFZLEVBQVEsQ0FBQztRQUNoRCxtQkFBYyxHQUFHLElBQUksWUFBWSxFQUFVLENBQUM7UUFDNUMsb0JBQWUsR0FBRyxJQUFJLFlBQVksRUFBVSxDQUFDO1FBQzdDLG1CQUFjLEdBQUcsSUFBSSxZQUFZLEVBQWlCLENBQUM7UUFDbkQsd0JBQW1CLEdBQUcsSUFBSSxZQUFZLEVBQWlCLENBQUM7UUFDeEQsbUJBQWMsR0FBRyxJQUFJLFlBQVksRUFBVSxDQUFDO1FBRy9DLGNBQVMsR0FBRyxDQUFDLENBQUM7UUFDZCxpQkFBWSxHQUFHLENBQUMsQ0FBQztRQU9wQixJQUFJLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQztJQUM1QixDQUFDO0lBeEZELElBQUksV0FBVztRQUNYLE9BQU8sSUFBSSxDQUFDLFlBQVksQ0FBQztJQUM3QixDQUFDO0lBRUQsSUFBSSxXQUFXLENBQUMsR0FBUztRQUNyQixJQUFJLENBQUMsR0FBRyxFQUFFO1lBQ04sR0FBRyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7U0FDcEI7UUFFRCxJQUFJLENBQUMsWUFBWSxHQUFHLEdBQUcsQ0FBQztRQUN4QixJQUFJLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDL0MsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDdEQsQ0FBQztJQThFRCxRQUFRO1FBQ0osSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ2pCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsS0FBSyxPQUFPLEVBQUU7Z0JBQ3hDLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO2FBQzNCO2lCQUFNO2dCQUNILElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO2FBQzFCO1NBQ0o7UUFDRCxJQUFJLENBQUMsWUFBWSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1FBQzNDLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDaEMsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUU7WUFDckMsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUM7U0FDdEI7YUFBTTtZQUNILElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1NBQ3ZEO1FBQ0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBQ3JELElBQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztRQUNqRCxJQUFJLENBQUMsZUFBZSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBRWhELElBQUksQ0FBQywwQ0FBMEM7WUFDM0MsSUFBSSxDQUFDLGVBQWUsQ0FBQywrQkFBK0IsQ0FBQyxTQUFTLENBQzFELENBQUMsV0FBVyxFQUFFLEVBQUU7Z0JBQ1osSUFBSSxDQUFDLFlBQVksR0FBRyxXQUFXLENBQUM7Z0JBQ2hDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7WUFDaEQsQ0FBQyxDQUNKLENBQUM7SUFDVixDQUFDO0lBRUQsV0FBVztRQUNQLElBQUksSUFBSSxDQUFDLDBDQUEwQyxFQUFFO1lBQ2pELElBQUksQ0FBQywwQ0FBMEMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUM5RCxJQUFJLENBQUMsMENBQTBDLEdBQUcsSUFBSSxDQUFDO1NBQzFEO0lBQ0wsQ0FBQztJQUVELFlBQVksQ0FBQyxLQUFhO1FBQ3RCLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFFRCxhQUFhLENBQUMsS0FBYTtRQUN2QixJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQsWUFBWSxDQUFDLFlBQTJCO1FBQ3BDLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFRCxXQUFXLENBQUMsV0FBMEI7UUFDbEMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQsWUFBWSxDQUFDLEtBQWE7UUFDdEIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVELFVBQVU7UUFDTixJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQ3RDLENBQUM7SUFFRCxTQUFTO1FBQ0wsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDbEMsQ0FBQztJQUVELFNBQVM7UUFDTCxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFRCxNQUFNO1FBQ0YsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0NBQ0osQ0FBQTs7WUE1RWdDLGVBQWU7eUNBQ3ZDLE1BQU0sU0FBQyxTQUFTOztBQXJGckI7SUFEQyxLQUFLLEVBQUU7b0RBR1A7QUFZUTtJQUFSLEtBQUssRUFBRTtzREFBNEI7QUFDM0I7SUFBUixLQUFLLEVBQUU7dURBQXNDO0FBQ3JDO0lBQVIsS0FBSyxFQUFFO29EQUF5QjtBQUN4QjtJQUFSLEtBQUssRUFBRTswREFBaUM7QUFDaEM7SUFBUixLQUFLLEVBQUU7eURBQTBDO0FBQ3pDO0lBQVIsS0FBSyxFQUFFOzBEQUFpRDtBQUNoRDtJQUFSLEtBQUssRUFBRTsyREFBd0M7QUFDdkM7SUFBUixLQUFLLEVBQUU7a0VBQTJDO0FBQzFDO0lBQVIsS0FBSyxFQUFFOzJEQUFpQztBQUNoQztJQUFSLEtBQUssRUFBRTswREFBaUM7QUFDaEM7SUFBUixLQUFLLEVBQUU7MkRBQThCO0FBQzdCO0lBQVIsS0FBSyxFQUFFOzBEQUE2QjtBQUM1QjtJQUFSLEtBQUssRUFBRTtzREFBaUM7QUFDaEM7SUFBUixLQUFLLEVBQUU7d0RBQXFDO0FBQ3BDO0lBQVIsS0FBSyxFQUFFO29EQUFnQztBQUMvQjtJQUFSLEtBQUssRUFBRTsrQ0FBd0I7QUFDdkI7SUFBUixLQUFLLEVBQUU7dURBQTJCO0FBQzFCO0lBQVIsS0FBSyxFQUFFO3FEQUE0QjtBQUMzQjtJQUFSLEtBQUssRUFBRTt1REFBdUM7QUFFL0M7SUFEQyxLQUFLLEVBQUU7d0VBQzBFO0FBRWxGO0lBREMsS0FBSyxFQUFFO2dGQUNrRjtBQUUxRjtJQURDLEtBQUssRUFBRTt1RUFDd0U7QUFDdkU7SUFBUixLQUFLLEVBQUU7aUVBQTZEO0FBQzVEO0lBQVIsS0FBSyxFQUFFO3NFQUErRDtBQUM5RDtJQUFSLEtBQUssRUFBRTtzRUFBeUQ7QUFDeEQ7SUFBUixLQUFLLEVBQUU7cUVBQThEO0FBQzdEO0lBQVIsS0FBSyxFQUFFO3FFQUF3RDtBQUVoRTtJQURDLEtBQUssRUFBRTs2RUFDb0Y7QUFFNUY7SUFEQyxLQUFLLEVBQUU7NkVBQ29GO0FBRTVGO0lBREMsS0FBSyxFQUFFOzRFQUNrRjtBQUUxRjtJQURDLEtBQUssRUFBRTs0RUFDa0Y7QUFFMUY7SUFEQyxLQUFLLEVBQUU7cUZBQzRGO0FBRXBHO0lBREMsS0FBSyxFQUFFO3FGQUM0RjtBQUVwRztJQURDLEtBQUssRUFBRTtvRkFDMEY7QUFFbEc7SUFEQyxLQUFLLEVBQUU7b0ZBQzBGO0FBQ3pGO0lBQVIsS0FBSyxFQUFFO3dEQUErQjtBQUM5QjtJQUFSLEtBQUssRUFBRTs4Q0FBa0I7QUFDakI7SUFBUixLQUFLLEVBQUU7dURBQTBCO0FBQ3pCO0lBQVIsS0FBSyxFQUFFO2lFQUF5QztBQUN4QztJQUFSLEtBQUssRUFBRTswREFBa0M7QUFDakM7SUFBUixLQUFLLEVBQUU7cURBQTZCO0FBQzVCO0lBQVIsS0FBSyxFQUFFO2lEQUFxQjtBQUNwQjtJQUFSLEtBQUssRUFBRTtvREFBdUI7QUFDdEI7SUFBUixLQUFLLEVBQUU7a0RBQXNCO0FBQ3JCO0lBQVIsS0FBSyxFQUFFO3dEQUFvQjtBQUVsQjtJQUFULE1BQU0sRUFBRTsrREFBaUQ7QUFDaEQ7SUFBVCxNQUFNLEVBQUU7eURBQTZDO0FBQzVDO0lBQVQsTUFBTSxFQUFFOzBEQUE4QztBQUM3QztJQUFULE1BQU0sRUFBRTt5REFBb0Q7QUFDbkQ7SUFBVCxNQUFNLEVBQUU7OERBQXlEO0FBQ3hEO0lBQVQsTUFBTSxFQUFFO3lEQUE2QztBQTlFN0MsaUJBQWlCO0lBclc3QixTQUFTLENBQUM7UUFDUCxRQUFRLEVBQUUsVUFBVTtRQUNwQixRQUFRLEVBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7S0FtVFQ7UUE4Q0QsU0FBUyxFQUFFLENBQUMsZUFBZSxDQUFDO2lCQTVDeEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztTQTBDQztLQUdSLENBQUM7SUF3Rk8sV0FBQSxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUE7R0F2RmIsaUJBQWlCLENBa0s3QjtTQWxLWSxpQkFBaUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgQ29tcG9uZW50LFxyXG4gICAgRXZlbnRFbWl0dGVyLFxyXG4gICAgSW5wdXQsXHJcbiAgICBPbkluaXQsXHJcbiAgICBPdXRwdXQsXHJcbiAgICBUZW1wbGF0ZVJlZixcclxuICAgIEluamVjdCxcclxuICAgIExPQ0FMRV9JRCxcclxufSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tIFwicnhqc1wiO1xyXG5cclxuaW1wb3J0IHsgQ2FsZW5kYXJTZXJ2aWNlIH0gZnJvbSBcIi4vY2FsZW5kYXIuc2VydmljZVwiO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJRXZlbnQge1xyXG4gICAgYWxsRGF5OiBib29sZWFuO1xyXG4gICAgZW5kVGltZTogRGF0ZTtcclxuICAgIHN0YXJ0VGltZTogRGF0ZTtcclxuICAgIHRpdGxlOiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVJhbmdlIHtcclxuICAgIHN0YXJ0VGltZTogRGF0ZTtcclxuICAgIGVuZFRpbWU6IERhdGU7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVZpZXcge31cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSURheVZpZXcgZXh0ZW5kcyBJVmlldyB7XHJcbiAgICBhbGxEYXlFdmVudHM6IElEaXNwbGF5QWxsRGF5RXZlbnRbXTtcclxuICAgIHJvd3M6IElEYXlWaWV3Um93W107XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSURheVZpZXdSb3cge1xyXG4gICAgZXZlbnRzOiBJRGlzcGxheUV2ZW50W107XHJcbiAgICB0aW1lOiBEYXRlO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElNb250aFZpZXcgZXh0ZW5kcyBJVmlldyB7XHJcbiAgICBkYXRlczogSU1vbnRoVmlld1Jvd1tdO1xyXG4gICAgZGF5SGVhZGVyczogc3RyaW5nW107XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSU1vbnRoVmlld1JvdyB7XHJcbiAgICBjdXJyZW50PzogYm9vbGVhbjtcclxuICAgIGRhdGU6IERhdGU7XHJcbiAgICBldmVudHM6IElFdmVudFtdO1xyXG4gICAgaGFzRXZlbnQ/OiBib29sZWFuO1xyXG4gICAgbGFiZWw6IHN0cmluZztcclxuICAgIHNlY29uZGFyeTogYm9vbGVhbjtcclxuICAgIHNlbGVjdGVkPzogYm9vbGVhbjtcclxuICAgIGRpc2FibGVkOiBib29sZWFuO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElXZWVrVmlldyBleHRlbmRzIElWaWV3IHtcclxuICAgIGRhdGVzOiBJV2Vla1ZpZXdEYXRlUm93W107XHJcbiAgICByb3dzOiBJV2Vla1ZpZXdSb3dbXVtdO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElXZWVrVmlld0RhdGVSb3cge1xyXG4gICAgY3VycmVudD86IGJvb2xlYW47XHJcbiAgICBkYXRlOiBEYXRlO1xyXG4gICAgZXZlbnRzOiBJRGlzcGxheUV2ZW50W107XHJcbiAgICBoYXNFdmVudD86IGJvb2xlYW47XHJcbiAgICBzZWxlY3RlZD86IGJvb2xlYW47XHJcbiAgICBkYXlIZWFkZXI6IHN0cmluZztcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJV2Vla1ZpZXdSb3cge1xyXG4gICAgZXZlbnRzOiBJRGlzcGxheUV2ZW50W107XHJcbiAgICB0aW1lOiBEYXRlO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElEaXNwbGF5RXZlbnQge1xyXG4gICAgZW5kSW5kZXg6IG51bWJlcjtcclxuICAgIGVuZE9mZnNldD86IG51bWJlcjtcclxuICAgIGV2ZW50OiBJRXZlbnQ7XHJcbiAgICBzdGFydEluZGV4OiBudW1iZXI7XHJcbiAgICBzdGFydE9mZnNldD86IG51bWJlcjtcclxuICAgIG92ZXJsYXBOdW1iZXI/OiBudW1iZXI7XHJcbiAgICBwb3NpdGlvbj86IG51bWJlcjtcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJRGlzcGxheVdlZWtWaWV3SGVhZGVyIHtcclxuICAgIHZpZXdEYXRlOiBJV2Vla1ZpZXdEYXRlUm93O1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElEaXNwbGF5QWxsRGF5RXZlbnQge1xyXG4gICAgZXZlbnQ6IElFdmVudDtcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJQ2FsZW5kYXJDb21wb25lbnQge1xyXG4gICAgY3VycmVudFZpZXdJbmRleDogbnVtYmVyO1xyXG4gICAgZGlyZWN0aW9uOiBudW1iZXI7XHJcbiAgICBldmVudFNvdXJjZTogSUV2ZW50W107XHJcbiAgICBnZXRSYW5nZTogeyAoZGF0ZTogRGF0ZSk6IElSYW5nZSB9O1xyXG4gICAgZ2V0Vmlld0RhdGE6IHsgKGRhdGU6IERhdGUpOiBJVmlldyB9O1xyXG4gICAgbW9kZTogQ2FsZW5kYXJNb2RlO1xyXG4gICAgcmFuZ2U6IElSYW5nZTtcclxuICAgIHZpZXdzOiBJVmlld1tdO1xyXG4gICAgb25EYXRhTG9hZGVkOiB7ICgpOiB2b2lkIH07XHJcbiAgICBvblJhbmdlQ2hhbmdlZDogRXZlbnRFbWl0dGVyPElSYW5nZT47XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVRpbWVTZWxlY3RlZCB7XHJcbiAgICBldmVudHM6IElFdmVudFtdO1xyXG4gICAgc2VsZWN0ZWRUaW1lOiBEYXRlO1xyXG4gICAgZGlzYWJsZWQ6IGJvb2xlYW47XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSU1vbnRoVmlld0Rpc3BsYXlFdmVudFRlbXBsYXRlQ29udGV4dCB7XHJcbiAgICB2aWV3OiBJVmlldztcclxuICAgIHJvdzogbnVtYmVyO1xyXG4gICAgY29sOiBudW1iZXI7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSU1vbnRoVmlld0V2ZW50RGV0YWlsVGVtcGxhdGVDb250ZXh0IHtcclxuICAgIHNlbGVjdGVkRGF0ZTogSVRpbWVTZWxlY3RlZDtcclxuICAgIG5vRXZlbnRzTGFiZWw6IHN0cmluZztcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJV2Vla1ZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZUNvbnRleHQge1xyXG4gICAgZGF5OiBJV2Vla1ZpZXdEYXRlUm93O1xyXG4gICAgZXZlbnRUZW1wbGF0ZTogVGVtcGxhdGVSZWY8SURpc3BsYXlBbGxEYXlFdmVudD47XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgSVdlZWtWaWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVDb250ZXh0IHtcclxuICAgIHRtOiBJV2Vla1ZpZXdSb3c7XHJcbiAgICBldmVudFRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxJRGlzcGxheUV2ZW50PjtcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBJRGF5Vmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlQ29udGV4dCB7XHJcbiAgICBhbGxkYXlFdmVudHM6IElEaXNwbGF5QWxsRGF5RXZlbnRbXTtcclxuICAgIGV2ZW50VGVtcGxhdGU6IFRlbXBsYXRlUmVmPElEaXNwbGF5QWxsRGF5RXZlbnQ+O1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElEYXlWaWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVDb250ZXh0IHtcclxuICAgIHRtOiBJRGF5Vmlld1JvdztcclxuICAgIGV2ZW50VGVtcGxhdGU6IFRlbXBsYXRlUmVmPElEaXNwbGF5RXZlbnQ+O1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIElEYXRlRm9ybWF0dGVyIHtcclxuICAgIGZvcm1hdE1vbnRoVmlld0RheT86IHsgKGRhdGU6IERhdGUpOiBzdHJpbmcgfTtcclxuICAgIGZvcm1hdE1vbnRoVmlld0RheUhlYWRlcj86IHsgKGRhdGU6IERhdGUpOiBzdHJpbmcgfTtcclxuICAgIGZvcm1hdE1vbnRoVmlld1RpdGxlPzogeyAoZGF0ZTogRGF0ZSk6IHN0cmluZyB9O1xyXG4gICAgZm9ybWF0V2Vla1ZpZXdEYXlIZWFkZXI/OiB7IChkYXRlOiBEYXRlKTogc3RyaW5nIH07XHJcbiAgICBmb3JtYXRXZWVrVmlld1RpdGxlPzogeyAoZGF0ZTogRGF0ZSk6IHN0cmluZyB9O1xyXG4gICAgZm9ybWF0V2Vla1ZpZXdIb3VyQ29sdW1uPzogeyAoZGF0ZTogRGF0ZSk6IHN0cmluZyB9O1xyXG4gICAgZm9ybWF0RGF5Vmlld1RpdGxlPzogeyAoZGF0ZTogRGF0ZSk6IHN0cmluZyB9O1xyXG4gICAgZm9ybWF0RGF5Vmlld0hvdXJDb2x1bW4/OiB7IChkYXRlOiBEYXRlKTogc3RyaW5nIH07XHJcbn1cclxuXHJcbmV4cG9ydCB0eXBlIENhbGVuZGFyTW9kZSA9IFwiZGF5XCIgfCBcIm1vbnRoXCIgfCBcIndlZWtcIjtcclxuXHJcbmV4cG9ydCB0eXBlIFF1ZXJ5TW9kZSA9IFwibG9jYWxcIiB8IFwicmVtb3RlXCI7XHJcblxyXG5leHBvcnQgZW51bSBTdGVwIHtcclxuICAgIFF1YXJ0ZXJIb3VyID0gMTUsXHJcbiAgICBIYWxmSG91ciA9IDMwLFxyXG4gICAgSG91ciA9IDYwLFxyXG59XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICAgIHNlbGVjdG9yOiBcImNhbGVuZGFyXCIsXHJcbiAgICB0ZW1wbGF0ZTogYFxyXG4gICAgICAgIDxuZy10ZW1wbGF0ZVxyXG4gICAgICAgICAgICAjbW9udGh2aWV3RGVmYXVsdERpc3BsYXlFdmVudFRlbXBsYXRlXHJcbiAgICAgICAgICAgIGxldC12aWV3PVwidmlld1wiXHJcbiAgICAgICAgICAgIGxldC1yb3c9XCJyb3dcIlxyXG4gICAgICAgICAgICBsZXQtY29sPVwiY29sXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICAgIHt7IHZpZXcuZGF0ZXNbcm93ICogNyArIGNvbF0ubGFiZWwgfX1cclxuICAgICAgICA8L25nLXRlbXBsYXRlPlxyXG4gICAgICAgIDxuZy10ZW1wbGF0ZVxyXG4gICAgICAgICAgICAjbW9udGh2aWV3RGVmYXVsdEV2ZW50RGV0YWlsVGVtcGxhdGVcclxuICAgICAgICAgICAgbGV0LXNob3dFdmVudERldGFpbD1cInNob3dFdmVudERldGFpbFwiXHJcbiAgICAgICAgICAgIGxldC1zZWxlY3RlZERhdGU9XCJzZWxlY3RlZERhdGVcIlxyXG4gICAgICAgICAgICBsZXQtbm9FdmVudHNMYWJlbD1cIm5vRXZlbnRzTGFiZWxcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgICAgPGlvbi1saXN0XHJcbiAgICAgICAgICAgICAgICBjbGFzcz1cImV2ZW50LWRldGFpbC1jb250YWluZXJcIlxyXG4gICAgICAgICAgICAgICAgaGFzLWJvdW5jaW5nPVwiZmFsc2VcIlxyXG4gICAgICAgICAgICAgICAgKm5nSWY9XCJzaG93RXZlbnREZXRhaWxcIlxyXG4gICAgICAgICAgICAgICAgb3ZlcmZsb3ctc2Nyb2xsPVwiZmFsc2VcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8aW9uLWl0ZW1cclxuICAgICAgICAgICAgICAgICAgICAqbmdGb3I9XCJsZXQgZXZlbnQgb2Ygc2VsZWN0ZWREYXRlPy5ldmVudHNcIlxyXG4gICAgICAgICAgICAgICAgICAgIChjbGljayk9XCJldmVudFNlbGVjdGVkKGV2ZW50KVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKm5nSWY9XCIhZXZlbnQuYWxsRGF5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJtb250aHZpZXctZXZlbnRkZXRhaWwtdGltZWNvbHVtblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID57eyBldmVudC5zdGFydFRpbWUgfCBkYXRlOiBcIkhIOm1tXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7eyBldmVudC5lbmRUaW1lIHwgZGF0ZTogXCJISDptbVwiIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICpuZ0lmPVwiZXZlbnQuYWxsRGF5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJtb250aHZpZXctZXZlbnRkZXRhaWwtdGltZWNvbHVtblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID57eyBhbGxEYXlMYWJlbCB9fTwvc3BhblxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cImV2ZW50LWRldGFpbFwiPiB8IHt7IGV2ZW50LnRpdGxlIH19PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9pb24taXRlbT5cclxuICAgICAgICAgICAgICAgIDxpb24taXRlbSAqbmdJZj1cInNlbGVjdGVkRGF0ZT8uZXZlbnRzLmxlbmd0aCA9PSAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm5vLWV2ZW50cy1sYWJlbFwiPnt7IG5vRXZlbnRzTGFiZWwgfX08L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvaW9uLWl0ZW0+XHJcbiAgICAgICAgICAgIDwvaW9uLWxpc3Q+XHJcbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgICA8bmctdGVtcGxhdGUgI2RlZmF1bHRXZWVrdmlld0hlYWRlclRlbXBsYXRlIGxldC12aWV3RGF0ZT1cInZpZXdEYXRlXCI+XHJcbiAgICAgICAgICAgIHt7IHZpZXdEYXRlLmRheUhlYWRlciB9fVxyXG4gICAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgICAgPG5nLXRlbXBsYXRlXHJcbiAgICAgICAgICAgICNkZWZhdWx0QWxsRGF5RXZlbnRUZW1wbGF0ZVxyXG4gICAgICAgICAgICBsZXQtZGlzcGxheUV2ZW50PVwiZGlzcGxheUV2ZW50XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYWxlbmRhci1ldmVudC1pbm5lclwiPlxyXG4gICAgICAgICAgICAgICAge3sgZGlzcGxheUV2ZW50LmV2ZW50LnRpdGxlIH19XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgICAgPG5nLXRlbXBsYXRlXHJcbiAgICAgICAgICAgICNkZWZhdWx0Tm9ybWFsRXZlbnRUZW1wbGF0ZVxyXG4gICAgICAgICAgICBsZXQtZGlzcGxheUV2ZW50PVwiZGlzcGxheUV2ZW50XCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjYWxlbmRhci1ldmVudC1pbm5lclwiPlxyXG4gICAgICAgICAgICAgICAge3sgZGlzcGxheUV2ZW50LmV2ZW50LnRpdGxlIH19XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgICAgPG5nLXRlbXBsYXRlXHJcbiAgICAgICAgICAgICNkZWZhdWx0V2Vla1ZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZVxyXG4gICAgICAgICAgICBsZXQtZGF5PVwiZGF5XCJcclxuICAgICAgICAgICAgbGV0LWV2ZW50VGVtcGxhdGU9XCJldmVudFRlbXBsYXRlXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIFtuZ0NsYXNzXT1cInsgJ2NhbGVuZGFyLWV2ZW50LXdyYXAnOiBkYXkuZXZlbnRzIH1cIlxyXG4gICAgICAgICAgICAgICAgKm5nSWY9XCJkYXkuZXZlbnRzXCJcclxuICAgICAgICAgICAgICAgIFtuZ1N0eWxlXT1cInsgaGVpZ2h0OiAyNSAqIGRheS5ldmVudHMubGVuZ3RoICsgJ3B4JyB9XCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICpuZ0Zvcj1cImxldCBkaXNwbGF5RXZlbnQgb2YgZGF5LmV2ZW50c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJjYWxlbmRhci1ldmVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdGFwcGFibGVcclxuICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwiZXZlbnRTZWxlY3RlZChkaXNwbGF5RXZlbnQuZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgICAgICBbbmdTdHlsZV09XCJ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvcDogMjUgKiBkaXNwbGF5RXZlbnQucG9zaXRpb24gKyAncHgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDEwMCAqXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGRpc3BsYXlFdmVudC5lbmRJbmRleCAtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXlFdmVudC5zdGFydEluZGV4KSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAnJScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogJzI1cHgnXHJcbiAgICAgICAgICAgICAgICAgICAgfVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPG5nLXRlbXBsYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFtuZ1RlbXBsYXRlT3V0bGV0XT1cImV2ZW50VGVtcGxhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbbmdUZW1wbGF0ZU91dGxldENvbnRleHRdPVwie1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheUV2ZW50OiBkaXNwbGF5RXZlbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgICA8bmctdGVtcGxhdGVcclxuICAgICAgICAgICAgI2RlZmF1bHREYXlWaWV3QWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGVcclxuICAgICAgICAgICAgbGV0LWFsbERheUV2ZW50cz1cImFsbERheUV2ZW50c1wiXHJcbiAgICAgICAgICAgIGxldC1ldmVudFRlbXBsYXRlPVwiZXZlbnRUZW1wbGF0ZVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAqbmdGb3I9XCJcclxuICAgICAgICAgICAgICAgICAgICBsZXQgZGlzcGxheUV2ZW50IG9mIGFsbERheUV2ZW50cztcclxuICAgICAgICAgICAgICAgICAgICBsZXQgZXZlbnRJbmRleCA9IGluZGV4XHJcbiAgICAgICAgICAgICAgICBcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJjYWxlbmRhci1ldmVudFwiXHJcbiAgICAgICAgICAgICAgICB0YXBwYWJsZVxyXG4gICAgICAgICAgICAgICAgKGNsaWNrKT1cImV2ZW50U2VsZWN0ZWQoZGlzcGxheUV2ZW50LmV2ZW50KVwiXHJcbiAgICAgICAgICAgICAgICBbbmdTdHlsZV09XCJ7XHJcbiAgICAgICAgICAgICAgICAgICAgdG9wOiAyNSAqIGV2ZW50SW5kZXggKyAncHgnLFxyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAnMTAwJScsXHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAnMjVweCdcclxuICAgICAgICAgICAgICAgIH1cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8bmctdGVtcGxhdGVcclxuICAgICAgICAgICAgICAgICAgICBbbmdUZW1wbGF0ZU91dGxldF09XCJldmVudFRlbXBsYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBbbmdUZW1wbGF0ZU91dGxldENvbnRleHRdPVwieyBkaXNwbGF5RXZlbnQ6IGRpc3BsYXlFdmVudCB9XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgICAgPG5nLXRlbXBsYXRlXHJcbiAgICAgICAgICAgICNkZWZhdWx0Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVcclxuICAgICAgICAgICAgbGV0LXRtPVwidG1cIlxyXG4gICAgICAgICAgICBsZXQtaG91clBhcnRzPVwiaG91clBhcnRzXCJcclxuICAgICAgICAgICAgbGV0LWV2ZW50VGVtcGxhdGU9XCJldmVudFRlbXBsYXRlXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIFtuZ0NsYXNzXT1cInsgJ2NhbGVuZGFyLWV2ZW50LXdyYXAnOiB0bS5ldmVudHMgfVwiXHJcbiAgICAgICAgICAgICAgICAqbmdJZj1cInRtLmV2ZW50c1wiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAqbmdGb3I9XCJsZXQgZGlzcGxheUV2ZW50IG9mIHRtLmV2ZW50c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3M9XCJjYWxlbmRhci1ldmVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdGFwcGFibGVcclxuICAgICAgICAgICAgICAgICAgICAoY2xpY2spPVwiZXZlbnRTZWxlY3RlZChkaXNwbGF5RXZlbnQuZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgICAgICBbbmdTdHlsZV09XCJ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvcDogKDM3ICogZGlzcGxheUV2ZW50LnN0YXJ0T2Zmc2V0KSAvIGhvdXJQYXJ0cyArICdweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoMTAwIC8gZGlzcGxheUV2ZW50Lm92ZXJsYXBOdW1iZXIpICpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5RXZlbnQucG9zaXRpb24gK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJyUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogMTAwIC8gZGlzcGxheUV2ZW50Lm92ZXJsYXBOdW1iZXIgKyAnJScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDM3ICpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZGlzcGxheUV2ZW50LmVuZEluZGV4IC1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheUV2ZW50LnN0YXJ0SW5kZXggLVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZGlzcGxheUV2ZW50LmVuZE9mZnNldCArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5RXZlbnQuc3RhcnRPZmZzZXQpIC9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhvdXJQYXJ0cykgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3B4J1xyXG4gICAgICAgICAgICAgICAgICAgIH1cIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxuZy10ZW1wbGF0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBbbmdUZW1wbGF0ZU91dGxldF09XCJldmVudFRlbXBsYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgW25nVGVtcGxhdGVPdXRsZXRDb250ZXh0XT1cIntcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXlFdmVudDogZGlzcGxheUV2ZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8L25nLXRlbXBsYXRlPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbmctdGVtcGxhdGU+XHJcbiAgICAgICAgPG5nLXRlbXBsYXRlICNkZWZhdWx0SW5hY3RpdmVBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZT4gPC9uZy10ZW1wbGF0ZT5cclxuICAgICAgICA8bmctdGVtcGxhdGUgI2RlZmF1bHRJbmFjdGl2ZU5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlPiA8L25nLXRlbXBsYXRlPlxyXG5cclxuICAgICAgICA8ZGl2IFtuZ1N3aXRjaF09XCJjYWxlbmRhck1vZGVcIiBjbGFzcz1cInt7IGNhbGVuZGFyTW9kZSB9fXZpZXctY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgIDxtb250aHZpZXdcclxuICAgICAgICAgICAgICAgICpuZ1N3aXRjaENhc2U9XCInbW9udGgnXCJcclxuICAgICAgICAgICAgICAgIFtmb3JtYXREYXldPVwiZm9ybWF0RGF5XCJcclxuICAgICAgICAgICAgICAgIFtmb3JtYXREYXlIZWFkZXJdPVwiZm9ybWF0RGF5SGVhZGVyXCJcclxuICAgICAgICAgICAgICAgIFtmb3JtYXRNb250aFRpdGxlXT1cImZvcm1hdE1vbnRoVGl0bGVcIlxyXG4gICAgICAgICAgICAgICAgW3N0YXJ0aW5nRGF5TW9udGhdPVwic3RhcnRpbmdEYXlNb250aFwiXHJcbiAgICAgICAgICAgICAgICBbc2hvd0V2ZW50RGV0YWlsXT1cInNob3dFdmVudERldGFpbFwiXHJcbiAgICAgICAgICAgICAgICBbbm9FdmVudHNMYWJlbF09XCJub0V2ZW50c0xhYmVsXCJcclxuICAgICAgICAgICAgICAgIFthdXRvU2VsZWN0XT1cImF1dG9TZWxlY3RcIlxyXG4gICAgICAgICAgICAgICAgW2V2ZW50U291cmNlXT1cImV2ZW50U291cmNlXCJcclxuICAgICAgICAgICAgICAgIFttYXJrRGlzYWJsZWRdPVwibWFya0Rpc2FibGVkXCJcclxuICAgICAgICAgICAgICAgIFttb250aHZpZXdEaXNwbGF5RXZlbnRUZW1wbGF0ZV09XCJcclxuICAgICAgICAgICAgICAgICAgICBtb250aHZpZXdEaXNwbGF5RXZlbnRUZW1wbGF0ZSB8fFxyXG4gICAgICAgICAgICAgICAgICAgIG1vbnRodmlld0RlZmF1bHREaXNwbGF5RXZlbnRUZW1wbGF0ZVxyXG4gICAgICAgICAgICAgICAgXCJcclxuICAgICAgICAgICAgICAgIFttb250aHZpZXdJbmFjdGl2ZURpc3BsYXlFdmVudFRlbXBsYXRlXT1cIlxyXG4gICAgICAgICAgICAgICAgICAgIG1vbnRodmlld0luYWN0aXZlRGlzcGxheUV2ZW50VGVtcGxhdGUgfHxcclxuICAgICAgICAgICAgICAgICAgICBtb250aHZpZXdEZWZhdWx0RGlzcGxheUV2ZW50VGVtcGxhdGVcclxuICAgICAgICAgICAgICAgIFwiXHJcbiAgICAgICAgICAgICAgICBbbW9udGh2aWV3RXZlbnREZXRhaWxUZW1wbGF0ZV09XCJcclxuICAgICAgICAgICAgICAgICAgICBtb250aHZpZXdFdmVudERldGFpbFRlbXBsYXRlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgbW9udGh2aWV3RGVmYXVsdEV2ZW50RGV0YWlsVGVtcGxhdGVcclxuICAgICAgICAgICAgICAgIFwiXHJcbiAgICAgICAgICAgICAgICBbbG9jYWxlXT1cImxvY2FsZVwiXHJcbiAgICAgICAgICAgICAgICBbZGF0ZUZvcm1hdHRlcl09XCJkYXRlRm9ybWF0dGVyXCJcclxuICAgICAgICAgICAgICAgIFtkaXJdPVwiZGlyXCJcclxuICAgICAgICAgICAgICAgIFtsb2NrU3dpcGVUb1ByZXZdPVwibG9ja1N3aXBlVG9QcmV2XCJcclxuICAgICAgICAgICAgICAgIFtsb2NrU3dpcGVzXT1cImxvY2tTd2lwZXNcIlxyXG4gICAgICAgICAgICAgICAgW3NsaWRlck9wdGlvbnNdPVwic2xpZGVyT3B0aW9uc1wiXHJcbiAgICAgICAgICAgICAgICAob25SYW5nZUNoYW5nZWQpPVwicmFuZ2VDaGFuZ2VkKCRldmVudClcIlxyXG4gICAgICAgICAgICAgICAgKG9uRXZlbnRTZWxlY3RlZCk9XCJldmVudFNlbGVjdGVkKCRldmVudClcIlxyXG4gICAgICAgICAgICAgICAgKG9uVGltZVNlbGVjdGVkKT1cInRpbWVTZWxlY3RlZCgkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgIChvblRpdGxlQ2hhbmdlZCk9XCJ0aXRsZUNoYW5nZWQoJGV2ZW50KVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgPC9tb250aHZpZXc+XHJcbiAgICAgICAgICAgIDx3ZWVrdmlld1xyXG4gICAgICAgICAgICAgICAgKm5nU3dpdGNoQ2FzZT1cIid3ZWVrJ1wiXHJcbiAgICAgICAgICAgICAgICBbZm9ybWF0V2Vla1RpdGxlXT1cImZvcm1hdFdlZWtUaXRsZVwiXHJcbiAgICAgICAgICAgICAgICBbZm9ybWF0V2Vla1ZpZXdEYXlIZWFkZXJdPVwiZm9ybWF0V2Vla1ZpZXdEYXlIZWFkZXJcIlxyXG4gICAgICAgICAgICAgICAgW2Zvcm1hdEhvdXJDb2x1bW5dPVwiZm9ybWF0SG91ckNvbHVtblwiXHJcbiAgICAgICAgICAgICAgICBbc3RhcnRpbmdEYXlXZWVrXT1cInN0YXJ0aW5nRGF5V2Vla1wiXHJcbiAgICAgICAgICAgICAgICBbYWxsRGF5TGFiZWxdPVwiYWxsRGF5TGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgW2hvdXJQYXJ0c109XCJob3VyUGFydHNcIlxyXG4gICAgICAgICAgICAgICAgW2F1dG9TZWxlY3RdPVwiYXV0b1NlbGVjdFwiXHJcbiAgICAgICAgICAgICAgICBbaG91clNlZ21lbnRzXT1cImhvdXJTZWdtZW50c1wiXHJcbiAgICAgICAgICAgICAgICBbZXZlbnRTb3VyY2VdPVwiZXZlbnRTb3VyY2VcIlxyXG4gICAgICAgICAgICAgICAgW21hcmtEaXNhYmxlZF09XCJtYXJrRGlzYWJsZWRcIlxyXG4gICAgICAgICAgICAgICAgW3dlZWt2aWV3SGVhZGVyVGVtcGxhdGVdPVwiXHJcbiAgICAgICAgICAgICAgICAgICAgd2Vla3ZpZXdIZWFkZXJUZW1wbGF0ZSB8fCBkZWZhdWx0V2Vla3ZpZXdIZWFkZXJUZW1wbGF0ZVxyXG4gICAgICAgICAgICAgICAgXCJcclxuICAgICAgICAgICAgICAgIFt3ZWVrdmlld0FsbERheUV2ZW50VGVtcGxhdGVdPVwiXHJcbiAgICAgICAgICAgICAgICAgICAgd2Vla3ZpZXdBbGxEYXlFdmVudFRlbXBsYXRlIHx8IGRlZmF1bHRBbGxEYXlFdmVudFRlbXBsYXRlXHJcbiAgICAgICAgICAgICAgICBcIlxyXG4gICAgICAgICAgICAgICAgW3dlZWt2aWV3Tm9ybWFsRXZlbnRUZW1wbGF0ZV09XCJcclxuICAgICAgICAgICAgICAgICAgICB3ZWVrdmlld05vcm1hbEV2ZW50VGVtcGxhdGUgfHwgZGVmYXVsdE5vcm1hbEV2ZW50VGVtcGxhdGVcclxuICAgICAgICAgICAgICAgIFwiXHJcbiAgICAgICAgICAgICAgICBbd2Vla3ZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZV09XCJcclxuICAgICAgICAgICAgICAgICAgICB3ZWVrdmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFdlZWtWaWV3QWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGVcclxuICAgICAgICAgICAgICAgIFwiXHJcbiAgICAgICAgICAgICAgICBbd2Vla3ZpZXdOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZV09XCJcclxuICAgICAgICAgICAgICAgICAgICB3ZWVrdmlld05vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdE5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlXHJcbiAgICAgICAgICAgICAgICBcIlxyXG4gICAgICAgICAgICAgICAgW3dlZWt2aWV3SW5hY3RpdmVBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZV09XCJcclxuICAgICAgICAgICAgICAgICAgICB3ZWVrdmlld0luYWN0aXZlQWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGUgfHxcclxuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0SW5hY3RpdmVBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZVxyXG4gICAgICAgICAgICAgICAgXCJcclxuICAgICAgICAgICAgICAgIFt3ZWVrdmlld0luYWN0aXZlTm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVdPVwiXHJcbiAgICAgICAgICAgICAgICAgICAgd2Vla3ZpZXdJbmFjdGl2ZU5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdEluYWN0aXZlTm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVcclxuICAgICAgICAgICAgICAgIFwiXHJcbiAgICAgICAgICAgICAgICBbbG9jYWxlXT1cImxvY2FsZVwiXHJcbiAgICAgICAgICAgICAgICBbZGF0ZUZvcm1hdHRlcl09XCJkYXRlRm9ybWF0dGVyXCJcclxuICAgICAgICAgICAgICAgIFtkaXJdPVwiZGlyXCJcclxuICAgICAgICAgICAgICAgIFtzY3JvbGxUb0hvdXJdPVwic2Nyb2xsVG9Ib3VyXCJcclxuICAgICAgICAgICAgICAgIFtwcmVzZXJ2ZVNjcm9sbFBvc2l0aW9uXT1cInByZXNlcnZlU2Nyb2xsUG9zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgW2xvY2tTd2lwZVRvUHJldl09XCJsb2NrU3dpcGVUb1ByZXZcIlxyXG4gICAgICAgICAgICAgICAgW2xvY2tTd2lwZXNdPVwibG9ja1N3aXBlc1wiXHJcbiAgICAgICAgICAgICAgICBbc3RhcnRIb3VyXT1cInN0YXJ0SG91clwiXHJcbiAgICAgICAgICAgICAgICBbZW5kSG91cl09XCJlbmRIb3VyXCJcclxuICAgICAgICAgICAgICAgIFtzbGlkZXJPcHRpb25zXT1cInNsaWRlck9wdGlvbnNcIlxyXG4gICAgICAgICAgICAgICAgKG9uUmFuZ2VDaGFuZ2VkKT1cInJhbmdlQ2hhbmdlZCgkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgIChvbkV2ZW50U2VsZWN0ZWQpPVwiZXZlbnRTZWxlY3RlZCgkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgIChvbkRheUhlYWRlclNlbGVjdGVkKT1cImRheVNlbGVjdGVkKCRldmVudClcIlxyXG4gICAgICAgICAgICAgICAgKG9uVGltZVNlbGVjdGVkKT1cInRpbWVTZWxlY3RlZCgkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgIChvblRpdGxlQ2hhbmdlZCk9XCJ0aXRsZUNoYW5nZWQoJGV2ZW50KVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgPC93ZWVrdmlldz5cclxuICAgICAgICAgICAgPGRheXZpZXdcclxuICAgICAgICAgICAgICAgICpuZ1N3aXRjaENhc2U9XCInZGF5J1wiXHJcbiAgICAgICAgICAgICAgICBbZm9ybWF0RGF5VGl0bGVdPVwiZm9ybWF0RGF5VGl0bGVcIlxyXG4gICAgICAgICAgICAgICAgW2Zvcm1hdEhvdXJDb2x1bW5dPVwiZm9ybWF0SG91ckNvbHVtblwiXHJcbiAgICAgICAgICAgICAgICBbYWxsRGF5TGFiZWxdPVwiYWxsRGF5TGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgW2hvdXJQYXJ0c109XCJob3VyUGFydHNcIlxyXG4gICAgICAgICAgICAgICAgW2hvdXJTZWdtZW50c109XCJob3VyU2VnbWVudHNcIlxyXG4gICAgICAgICAgICAgICAgW2V2ZW50U291cmNlXT1cImV2ZW50U291cmNlXCJcclxuICAgICAgICAgICAgICAgIFttYXJrRGlzYWJsZWRdPVwibWFya0Rpc2FibGVkXCJcclxuICAgICAgICAgICAgICAgIFtkYXl2aWV3QWxsRGF5RXZlbnRUZW1wbGF0ZV09XCJcclxuICAgICAgICAgICAgICAgICAgICBkYXl2aWV3QWxsRGF5RXZlbnRUZW1wbGF0ZSB8fCBkZWZhdWx0QWxsRGF5RXZlbnRUZW1wbGF0ZVxyXG4gICAgICAgICAgICAgICAgXCJcclxuICAgICAgICAgICAgICAgIFtkYXl2aWV3Tm9ybWFsRXZlbnRUZW1wbGF0ZV09XCJcclxuICAgICAgICAgICAgICAgICAgICBkYXl2aWV3Tm9ybWFsRXZlbnRUZW1wbGF0ZSB8fCBkZWZhdWx0Tm9ybWFsRXZlbnRUZW1wbGF0ZVxyXG4gICAgICAgICAgICAgICAgXCJcclxuICAgICAgICAgICAgICAgIFtkYXl2aWV3QWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGVdPVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF5dmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdERheVZpZXdBbGxEYXlFdmVudFNlY3Rpb25UZW1wbGF0ZVxyXG4gICAgICAgICAgICAgICAgXCJcclxuICAgICAgICAgICAgICAgIFtkYXl2aWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVdPVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF5dmlld05vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdE5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlXHJcbiAgICAgICAgICAgICAgICBcIlxyXG4gICAgICAgICAgICAgICAgW2RheXZpZXdJbmFjdGl2ZUFsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlXT1cIlxyXG4gICAgICAgICAgICAgICAgICAgIGRheXZpZXdJbmFjdGl2ZUFsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgZGVmYXVsdEluYWN0aXZlQWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGVcclxuICAgICAgICAgICAgICAgIFwiXHJcbiAgICAgICAgICAgICAgICBbZGF5dmlld0luYWN0aXZlTm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVdPVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF5dmlld0luYWN0aXZlTm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGUgfHxcclxuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0SW5hY3RpdmVOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZVxyXG4gICAgICAgICAgICAgICAgXCJcclxuICAgICAgICAgICAgICAgIFtsb2NhbGVdPVwibG9jYWxlXCJcclxuICAgICAgICAgICAgICAgIFtkYXRlRm9ybWF0dGVyXT1cImRhdGVGb3JtYXR0ZXJcIlxyXG4gICAgICAgICAgICAgICAgW2Rpcl09XCJkaXJcIlxyXG4gICAgICAgICAgICAgICAgW3Njcm9sbFRvSG91cl09XCJzY3JvbGxUb0hvdXJcIlxyXG4gICAgICAgICAgICAgICAgW3ByZXNlcnZlU2Nyb2xsUG9zaXRpb25dPVwicHJlc2VydmVTY3JvbGxQb3NpdGlvblwiXHJcbiAgICAgICAgICAgICAgICBbbG9ja1N3aXBlVG9QcmV2XT1cImxvY2tTd2lwZVRvUHJldlwiXHJcbiAgICAgICAgICAgICAgICBbbG9ja1N3aXBlc109XCJsb2NrU3dpcGVzXCJcclxuICAgICAgICAgICAgICAgIFtzdGFydEhvdXJdPVwic3RhcnRIb3VyXCJcclxuICAgICAgICAgICAgICAgIFtlbmRIb3VyXT1cImVuZEhvdXJcIlxyXG4gICAgICAgICAgICAgICAgW3NsaWRlck9wdGlvbnNdPVwic2xpZGVyT3B0aW9uc1wiXHJcbiAgICAgICAgICAgICAgICAob25SYW5nZUNoYW5nZWQpPVwicmFuZ2VDaGFuZ2VkKCRldmVudClcIlxyXG4gICAgICAgICAgICAgICAgKG9uRXZlbnRTZWxlY3RlZCk9XCJldmVudFNlbGVjdGVkKCRldmVudClcIlxyXG4gICAgICAgICAgICAgICAgKG9uVGltZVNlbGVjdGVkKT1cInRpbWVTZWxlY3RlZCgkZXZlbnQpXCJcclxuICAgICAgICAgICAgICAgIChvblRpdGxlQ2hhbmdlZCk9XCJ0aXRsZUNoYW5nZWQoJGV2ZW50KVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgPC9kYXl2aWV3PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgYCxcclxuICAgIHN0eWxlczogW1xyXG4gICAgICAgIGBcclxuICAgICAgICAgICAgOmhvc3QgPiBkaXYge1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuZXZlbnQtZGV0YWlsLWNvbnRhaW5lciB7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItdG9wOiAycHggZGFya2dyZXkgc29saWQ7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5uby1ldmVudHMtbGFiZWwge1xyXG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogZGFya2dyZXk7XHJcbiAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5ldmVudC1kZXRhaWwge1xyXG4gICAgICAgICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICAgICAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgICAgICAgICAgICAgIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAubW9udGh2aWV3LWV2ZW50ZGV0YWlsLXRpbWVjb2x1bW4ge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDExMHB4O1xyXG4gICAgICAgICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLmNhbGVuZGFyLWV2ZW50LWlubmVyIHtcclxuICAgICAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjM2E4N2FkO1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAycHg7XHJcbiAgICAgICAgICAgICAgICBsaW5lLWhlaWdodDogMTVweDtcclxuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGluaXRpYWw7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiA3NTBweCkge1xyXG4gICAgICAgICAgICAgICAgLmNhbGVuZGFyLWV2ZW50LWlubmVyIHtcclxuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICBgLFxyXG4gICAgXSxcclxuICAgIHByb3ZpZGVyczogW0NhbGVuZGFyU2VydmljZV0sXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBDYWxlbmRhckNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgICBASW5wdXQoKVxyXG4gICAgZ2V0IGN1cnJlbnREYXRlKCk6IERhdGUge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9jdXJyZW50RGF0ZTtcclxuICAgIH1cclxuXHJcbiAgICBzZXQgY3VycmVudERhdGUodmFsOiBEYXRlKSB7XHJcbiAgICAgICAgaWYgKCF2YWwpIHtcclxuICAgICAgICAgICAgdmFsID0gbmV3IERhdGUoKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX2N1cnJlbnREYXRlID0gdmFsO1xyXG4gICAgICAgIHRoaXMuY2FsZW5kYXJTZXJ2aWNlLnNldEluaXRpYWxEYXRlKHZhbCwgdHJ1ZSk7XHJcbiAgICAgICAgdGhpcy5vbkN1cnJlbnREYXRlQ2hhbmdlZC5lbWl0KHRoaXMuX2N1cnJlbnREYXRlKTtcclxuICAgIH1cclxuXHJcbiAgICBASW5wdXQoKSBldmVudFNvdXJjZTogSUV2ZW50W10gPSBbXTtcclxuICAgIEBJbnB1dCgpIGNhbGVuZGFyTW9kZTogQ2FsZW5kYXJNb2RlID0gXCJtb250aFwiO1xyXG4gICAgQElucHV0KCkgZm9ybWF0RGF5OiBzdHJpbmcgPSBcImRcIjtcclxuICAgIEBJbnB1dCgpIGZvcm1hdERheUhlYWRlcjogc3RyaW5nID0gXCJFRUVcIjtcclxuICAgIEBJbnB1dCgpIGZvcm1hdERheVRpdGxlOiBzdHJpbmcgPSBcIk1NTU0gZGQsIHl5eXlcIjtcclxuICAgIEBJbnB1dCgpIGZvcm1hdFdlZWtUaXRsZTogc3RyaW5nID0gXCJNTU1NIHl5eXksICdXZWVrJyB3XCI7XHJcbiAgICBASW5wdXQoKSBmb3JtYXRNb250aFRpdGxlOiBzdHJpbmcgPSBcIk1NTU0geXl5eVwiO1xyXG4gICAgQElucHV0KCkgZm9ybWF0V2Vla1ZpZXdEYXlIZWFkZXI6IHN0cmluZyA9IFwiRUVFIGRcIjtcclxuICAgIEBJbnB1dCgpIGZvcm1hdEhvdXJDb2x1bW46IHN0cmluZyA9IFwiaGFcIjtcclxuICAgIEBJbnB1dCgpIHNob3dFdmVudERldGFpbDogYm9vbGVhbiA9IHRydWU7XHJcbiAgICBASW5wdXQoKSBzdGFydGluZ0RheU1vbnRoOiBudW1iZXIgPSAwO1xyXG4gICAgQElucHV0KCkgc3RhcnRpbmdEYXlXZWVrOiBudW1iZXIgPSAwO1xyXG4gICAgQElucHV0KCkgYWxsRGF5TGFiZWw6IHN0cmluZyA9IFwiYWxsIGRheVwiO1xyXG4gICAgQElucHV0KCkgbm9FdmVudHNMYWJlbDogc3RyaW5nID0gXCJObyBFdmVudHNcIjtcclxuICAgIEBJbnB1dCgpIHF1ZXJ5TW9kZTogUXVlcnlNb2RlID0gXCJsb2NhbFwiO1xyXG4gICAgQElucHV0KCkgc3RlcDogU3RlcCA9IFN0ZXAuSG91cjtcclxuICAgIEBJbnB1dCgpIHRpbWVJbnRlcnZhbDogbnVtYmVyID0gNjA7XHJcbiAgICBASW5wdXQoKSBhdXRvU2VsZWN0OiBib29sZWFuID0gdHJ1ZTtcclxuICAgIEBJbnB1dCgpIG1hcmtEaXNhYmxlZDogKGRhdGU6IERhdGUpID0+IGJvb2xlYW47XHJcbiAgICBASW5wdXQoKVxyXG4gICAgbW9udGh2aWV3RGlzcGxheUV2ZW50VGVtcGxhdGU6IFRlbXBsYXRlUmVmPElNb250aFZpZXdEaXNwbGF5RXZlbnRUZW1wbGF0ZUNvbnRleHQ+O1xyXG4gICAgQElucHV0KClcclxuICAgIG1vbnRodmlld0luYWN0aXZlRGlzcGxheUV2ZW50VGVtcGxhdGU6IFRlbXBsYXRlUmVmPElNb250aFZpZXdEaXNwbGF5RXZlbnRUZW1wbGF0ZUNvbnRleHQ+O1xyXG4gICAgQElucHV0KClcclxuICAgIG1vbnRodmlld0V2ZW50RGV0YWlsVGVtcGxhdGU6IFRlbXBsYXRlUmVmPElNb250aFZpZXdFdmVudERldGFpbFRlbXBsYXRlQ29udGV4dD47XHJcbiAgICBASW5wdXQoKSB3ZWVrdmlld0hlYWRlclRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxJRGlzcGxheVdlZWtWaWV3SGVhZGVyPjtcclxuICAgIEBJbnB1dCgpIHdlZWt2aWV3QWxsRGF5RXZlbnRUZW1wbGF0ZTogVGVtcGxhdGVSZWY8SURpc3BsYXlBbGxEYXlFdmVudD47XHJcbiAgICBASW5wdXQoKSB3ZWVrdmlld05vcm1hbEV2ZW50VGVtcGxhdGU6IFRlbXBsYXRlUmVmPElEaXNwbGF5RXZlbnQ+O1xyXG4gICAgQElucHV0KCkgZGF5dmlld0FsbERheUV2ZW50VGVtcGxhdGU6IFRlbXBsYXRlUmVmPElEaXNwbGF5QWxsRGF5RXZlbnQ+O1xyXG4gICAgQElucHV0KCkgZGF5dmlld05vcm1hbEV2ZW50VGVtcGxhdGU6IFRlbXBsYXRlUmVmPElEaXNwbGF5RXZlbnQ+O1xyXG4gICAgQElucHV0KClcclxuICAgIHdlZWt2aWV3QWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGU6IFRlbXBsYXRlUmVmPElXZWVrVmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlQ29udGV4dD47XHJcbiAgICBASW5wdXQoKVxyXG4gICAgd2Vla3ZpZXdOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZTogVGVtcGxhdGVSZWY8SVdlZWtWaWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVDb250ZXh0PjtcclxuICAgIEBJbnB1dCgpXHJcbiAgICBkYXl2aWV3QWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGU6IFRlbXBsYXRlUmVmPElEYXlWaWV3QWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGVDb250ZXh0PjtcclxuICAgIEBJbnB1dCgpXHJcbiAgICBkYXl2aWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGU6IFRlbXBsYXRlUmVmPElEYXlWaWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVDb250ZXh0PjtcclxuICAgIEBJbnB1dCgpXHJcbiAgICB3ZWVrdmlld0luYWN0aXZlQWxsRGF5RXZlbnRTZWN0aW9uVGVtcGxhdGU6IFRlbXBsYXRlUmVmPElXZWVrVmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlQ29udGV4dD47XHJcbiAgICBASW5wdXQoKVxyXG4gICAgd2Vla3ZpZXdJbmFjdGl2ZU5vcm1hbEV2ZW50U2VjdGlvblRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxJV2Vla1ZpZXdOb3JtYWxFdmVudFNlY3Rpb25UZW1wbGF0ZUNvbnRleHQ+O1xyXG4gICAgQElucHV0KClcclxuICAgIGRheXZpZXdJbmFjdGl2ZUFsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxJRGF5Vmlld0FsbERheUV2ZW50U2VjdGlvblRlbXBsYXRlQ29udGV4dD47XHJcbiAgICBASW5wdXQoKVxyXG4gICAgZGF5dmlld0luYWN0aXZlTm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGU6IFRlbXBsYXRlUmVmPElEYXlWaWV3Tm9ybWFsRXZlbnRTZWN0aW9uVGVtcGxhdGVDb250ZXh0PjtcclxuICAgIEBJbnB1dCgpIGRhdGVGb3JtYXR0ZXI6IElEYXRlRm9ybWF0dGVyO1xyXG4gICAgQElucHV0KCkgZGlyOiBzdHJpbmcgPSBcIlwiO1xyXG4gICAgQElucHV0KCkgc2Nyb2xsVG9Ib3VyOiBudW1iZXIgPSAwO1xyXG4gICAgQElucHV0KCkgcHJlc2VydmVTY3JvbGxQb3NpdGlvbjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgQElucHV0KCkgbG9ja1N3aXBlVG9QcmV2OiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBASW5wdXQoKSBsb2NrU3dpcGVzOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICBASW5wdXQoKSBsb2NhbGU6IHN0cmluZyA9IFwiXCI7XHJcbiAgICBASW5wdXQoKSBzdGFydEhvdXI6IG51bWJlciA9IDA7XHJcbiAgICBASW5wdXQoKSBlbmRIb3VyOiBudW1iZXIgPSAyNDtcclxuICAgIEBJbnB1dCgpIHNsaWRlck9wdGlvbnM6IGFueTtcclxuXHJcbiAgICBAT3V0cHV0KCkgb25DdXJyZW50RGF0ZUNoYW5nZWQgPSBuZXcgRXZlbnRFbWl0dGVyPERhdGU+KCk7XHJcbiAgICBAT3V0cHV0KCkgb25SYW5nZUNoYW5nZWQgPSBuZXcgRXZlbnRFbWl0dGVyPElSYW5nZT4oKTtcclxuICAgIEBPdXRwdXQoKSBvbkV2ZW50U2VsZWN0ZWQgPSBuZXcgRXZlbnRFbWl0dGVyPElFdmVudD4oKTtcclxuICAgIEBPdXRwdXQoKSBvblRpbWVTZWxlY3RlZCA9IG5ldyBFdmVudEVtaXR0ZXI8SVRpbWVTZWxlY3RlZD4oKTtcclxuICAgIEBPdXRwdXQoKSBvbkRheUhlYWRlclNlbGVjdGVkID0gbmV3IEV2ZW50RW1pdHRlcjxJVGltZVNlbGVjdGVkPigpO1xyXG4gICAgQE91dHB1dCgpIG9uVGl0bGVDaGFuZ2VkID0gbmV3IEV2ZW50RW1pdHRlcjxzdHJpbmc+KCk7XHJcblxyXG4gICAgcHJpdmF0ZSBfY3VycmVudERhdGU6IERhdGU7XHJcbiAgICBwdWJsaWMgaG91clBhcnRzID0gMTtcclxuICAgIHB1YmxpYyBob3VyU2VnbWVudHMgPSAxO1xyXG4gICAgcHJpdmF0ZSBjdXJyZW50RGF0ZUNoYW5nZWRGcm9tQ2hpbGRyZW5TdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIGNhbGVuZGFyU2VydmljZTogQ2FsZW5kYXJTZXJ2aWNlLFxyXG4gICAgICAgIEBJbmplY3QoTE9DQUxFX0lEKSBwcml2YXRlIGFwcExvY2FsZTogc3RyaW5nXHJcbiAgICApIHtcclxuICAgICAgICB0aGlzLmxvY2FsZSA9IGFwcExvY2FsZTtcclxuICAgIH1cclxuXHJcbiAgICBuZ09uSW5pdCgpIHtcclxuICAgICAgICBpZiAodGhpcy5hdXRvU2VsZWN0KSB7XHJcbiAgICAgICAgICAgIGlmICh0aGlzLmF1dG9TZWxlY3QudG9TdHJpbmcoKSA9PT0gXCJmYWxzZVwiKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmF1dG9TZWxlY3QgPSBmYWxzZTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuYXV0b1NlbGVjdCA9IHRydWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5ob3VyU2VnbWVudHMgPSA2MCAvIHRoaXMudGltZUludGVydmFsO1xyXG4gICAgICAgIHRoaXMuaG91clBhcnRzID0gNjAgLyB0aGlzLnN0ZXA7XHJcbiAgICAgICAgaWYgKHRoaXMuaG91clBhcnRzIDw9IHRoaXMuaG91clNlZ21lbnRzKSB7XHJcbiAgICAgICAgICAgIHRoaXMuaG91clBhcnRzID0gMTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB0aGlzLmhvdXJQYXJ0cyA9IHRoaXMuaG91clBhcnRzIC8gdGhpcy5ob3VyU2VnbWVudHM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuc3RhcnRIb3VyID0gcGFyc2VJbnQodGhpcy5zdGFydEhvdXIudG9TdHJpbmcoKSk7XHJcbiAgICAgICAgdGhpcy5lbmRIb3VyID0gcGFyc2VJbnQodGhpcy5lbmRIb3VyLnRvU3RyaW5nKCkpO1xyXG4gICAgICAgIHRoaXMuY2FsZW5kYXJTZXJ2aWNlLnF1ZXJ5TW9kZSA9IHRoaXMucXVlcnlNb2RlO1xyXG5cclxuICAgICAgICB0aGlzLmN1cnJlbnREYXRlQ2hhbmdlZEZyb21DaGlsZHJlblN1YnNjcmlwdGlvbiA9XHJcbiAgICAgICAgICAgIHRoaXMuY2FsZW5kYXJTZXJ2aWNlLmN1cnJlbnREYXRlQ2hhbmdlZEZyb21DaGlsZHJlbiQuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgICAgICAgKGN1cnJlbnREYXRlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fY3VycmVudERhdGUgPSBjdXJyZW50RGF0ZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uQ3VycmVudERhdGVDaGFuZ2VkLmVtaXQoY3VycmVudERhdGUpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIG5nT25EZXN0cm95KCkge1xyXG4gICAgICAgIGlmICh0aGlzLmN1cnJlbnREYXRlQ2hhbmdlZEZyb21DaGlsZHJlblN1YnNjcmlwdGlvbikge1xyXG4gICAgICAgICAgICB0aGlzLmN1cnJlbnREYXRlQ2hhbmdlZEZyb21DaGlsZHJlblN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xyXG4gICAgICAgICAgICB0aGlzLmN1cnJlbnREYXRlQ2hhbmdlZEZyb21DaGlsZHJlblN1YnNjcmlwdGlvbiA9IG51bGw7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJhbmdlQ2hhbmdlZChyYW5nZTogSVJhbmdlKSB7XHJcbiAgICAgICAgdGhpcy5vblJhbmdlQ2hhbmdlZC5lbWl0KHJhbmdlKTtcclxuICAgIH1cclxuXHJcbiAgICBldmVudFNlbGVjdGVkKGV2ZW50OiBJRXZlbnQpIHtcclxuICAgICAgICB0aGlzLm9uRXZlbnRTZWxlY3RlZC5lbWl0KGV2ZW50KTtcclxuICAgIH1cclxuXHJcbiAgICB0aW1lU2VsZWN0ZWQodGltZVNlbGVjdGVkOiBJVGltZVNlbGVjdGVkKSB7XHJcbiAgICAgICAgdGhpcy5vblRpbWVTZWxlY3RlZC5lbWl0KHRpbWVTZWxlY3RlZCk7XHJcbiAgICB9XHJcblxyXG4gICAgZGF5U2VsZWN0ZWQoZGF5U2VsZWN0ZWQ6IElUaW1lU2VsZWN0ZWQpIHtcclxuICAgICAgICB0aGlzLm9uRGF5SGVhZGVyU2VsZWN0ZWQuZW1pdChkYXlTZWxlY3RlZCk7XHJcbiAgICB9XHJcblxyXG4gICAgdGl0bGVDaGFuZ2VkKHRpdGxlOiBzdHJpbmcpIHtcclxuICAgICAgICB0aGlzLm9uVGl0bGVDaGFuZ2VkLmVtaXQodGl0bGUpO1xyXG4gICAgfVxyXG5cclxuICAgIGxvYWRFdmVudHMoKSB7XHJcbiAgICAgICAgdGhpcy5jYWxlbmRhclNlcnZpY2UubG9hZEV2ZW50cygpO1xyXG4gICAgfVxyXG5cclxuICAgIHNsaWRlTmV4dCgpIHtcclxuICAgICAgICB0aGlzLmNhbGVuZGFyU2VydmljZS5zbGlkZSgxKTtcclxuICAgIH1cclxuXHJcbiAgICBzbGlkZVByZXYoKSB7XHJcbiAgICAgICAgdGhpcy5jYWxlbmRhclNlcnZpY2Uuc2xpZGUoLTEpO1xyXG4gICAgfVxyXG5cclxuICAgIHVwZGF0ZSgpIHtcclxuICAgICAgICB0aGlzLmNhbGVuZGFyU2VydmljZS51cGRhdGUoKTtcclxuICAgIH1cclxufVxyXG4iXX0=