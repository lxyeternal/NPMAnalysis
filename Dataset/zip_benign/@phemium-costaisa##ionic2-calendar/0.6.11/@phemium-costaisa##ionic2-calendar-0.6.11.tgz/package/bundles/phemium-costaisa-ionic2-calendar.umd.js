(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common'), require('@ionic/angular'), require('rxjs')) :
    typeof define === 'function' && define.amd ? define('@phemium-costaisa/ionic2-calendar', ['exports', '@angular/core', '@angular/common', '@ionic/angular', 'rxjs'], factory) :
    (global = global || self, factory((global['phemium-costaisa'] = global['phemium-costaisa'] || {}, global['phemium-costaisa']['ionic2-calendar'] = {}), global.ng.core, global.ng.common, global.angular, global.rxjs));
}(this, (function (exports, core, common, angular, rxjs) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    var __createBinding = Object.create ? (function(o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
    }) : (function(o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
    });

    function __exportStar(m, o) {
        for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    /** @deprecated */
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    /** @deprecated */
    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }

    function __spreadArray(to, from, pack) {
        if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
            if (ar || !(i in from)) {
                if (!ar) ar = Array.prototype.slice.call(from, 0, i);
                ar[i] = from[i];
            }
        }
        return to.concat(ar || from);
    }

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    var __setModuleDefault = Object.create ? (function(o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
        o["default"] = v;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
        __setModuleDefault(result, mod);
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, state, kind, f) {
        if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
        return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
    }

    function __classPrivateFieldSet(receiver, state, value, kind, f) {
        if (kind === "m") throw new TypeError("Private method is not writable");
        if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
        return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
    }

    var CalendarService = /** @class */ (function () {
        function CalendarService() {
            this.currentDateChangedFromParent = new rxjs.Subject();
            this.currentDateChangedFromChildren = new rxjs.Subject();
            this.eventSourceChanged = new rxjs.Subject();
            this.slideChanged = new rxjs.Subject();
            this.slideUpdated = new rxjs.Subject();
            this.currentDateChangedFromParent$ = this.currentDateChangedFromParent.asObservable();
            this.currentDateChangedFromChildren$ = this.currentDateChangedFromChildren.asObservable();
            this.eventSourceChanged$ = this.eventSourceChanged.asObservable();
            this.slideChanged$ = this.slideChanged.asObservable();
            this.slideUpdated$ = this.slideUpdated.asObservable();
        }
        CalendarService.prototype.setInitialDate = function (val, fromParent) {
            if (fromParent === void 0) { fromParent = false; }
            this._initialDate = new Date(val);
            this.setCurrentDate(val, fromParent);
        };
        CalendarService.prototype.setCurrentDate = function (val, fromParent) {
            if (fromParent === void 0) { fromParent = false; }
            this._currentDate = new Date(val);
            if (fromParent) {
                this.currentDateChangedFromParent.next(val);
            }
            else {
                this.currentDateChangedFromChildren.next(val);
            }
        };
        Object.defineProperty(CalendarService.prototype, "currentDate", {
            get: function () {
                return this._currentDate;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(CalendarService.prototype, "initialDate", {
            get: function () {
                return this._initialDate;
            },
            enumerable: true,
            configurable: true
        });
        CalendarService.prototype.rangeChanged = function (component) {
            if (this.queryMode === 'local') {
                if (component.eventSource && component.onDataLoaded) {
                    component.onDataLoaded();
                }
            }
            else if (this.queryMode === 'remote') {
                var rangeStart = new Date(component.range.startTime.getTime()), rangeEnd = new Date(component.range.endTime.getTime());
                rangeStart.setHours(0);
                if (rangeStart.getHours() === 23) {
                    rangeStart.setTime(rangeStart.getTime() + 3600000);
                }
                rangeEnd.setHours(0);
                if (rangeEnd.getHours() === 23) {
                    rangeEnd.setTime(rangeEnd.getTime() + 3600000);
                }
                component.onRangeChanged.emit({
                    startTime: rangeStart,
                    endTime: rangeEnd,
                });
            }
        };
        CalendarService.prototype.getStep = function (mode) {
            switch (mode) {
                case 'month':
                    return {
                        years: 0,
                        months: 1,
                        days: 0,
                    };
                case 'week':
                    return {
                        years: 0,
                        months: 0,
                        days: 7,
                    };
                case 'day':
                    return {
                        years: 0,
                        months: 0,
                        days: 1,
                    };
            }
        };
        CalendarService.prototype.getAdjacentCalendarDate = function (mode, direction) {
            var calculateCalendarDate = this.currentDate;
            var step = this.getStep(mode), year = calculateCalendarDate.getFullYear() + direction * step.years, month = calculateCalendarDate.getMonth() + direction * step.months, date = calculateCalendarDate.getDate() + direction * step.days;
            calculateCalendarDate = new Date(year, month, date, 12, 0, 0);
            if (mode === 'month') {
                var firstDayInNextMonth = new Date(year, month + 1, 1, 12, 0, 0);
                if (firstDayInNextMonth.getTime() <= calculateCalendarDate.getTime()) {
                    calculateCalendarDate = new Date(firstDayInNextMonth.getTime() - 24 * 60 * 60 * 1000);
                }
            }
            return calculateCalendarDate;
        };
        CalendarService.prototype.getAdjacentViewStartTime = function (component, direction) {
            var adjacentCalendarDate = this.getAdjacentCalendarDate(component.mode, direction);
            return component.getRange(adjacentCalendarDate).startTime;
        };
        CalendarService.prototype.populateAdjacentViews = function (component) {
            var currentViewStartDate, currentViewData, toUpdateViewIndex, currentViewIndex = component.currentViewIndex;
            if (component.direction === 1) {
                currentViewStartDate = this.getAdjacentViewStartTime(component, 1);
                toUpdateViewIndex = (currentViewIndex + 1) % 3;
                component.views[toUpdateViewIndex] = component.getViewData(currentViewStartDate);
            }
            else if (component.direction === -1) {
                currentViewStartDate = this.getAdjacentViewStartTime(component, -1);
                toUpdateViewIndex = (currentViewIndex + 2) % 3;
                component.views[toUpdateViewIndex] = component.getViewData(currentViewStartDate);
            }
            else {
                if (!component.views) {
                    currentViewData = [];
                    currentViewStartDate = component.range.startTime;
                    currentViewData.push(component.getViewData(currentViewStartDate));
                    currentViewStartDate = this.getAdjacentViewStartTime(component, 1);
                    currentViewData.push(component.getViewData(currentViewStartDate));
                    currentViewStartDate = this.getAdjacentViewStartTime(component, -1);
                    currentViewData.push(component.getViewData(currentViewStartDate));
                    component.views = currentViewData;
                }
                else {
                    currentViewStartDate = component.range.startTime;
                    component.views[currentViewIndex] = component.getViewData(currentViewStartDate);
                    currentViewStartDate = this.getAdjacentViewStartTime(component, -1);
                    toUpdateViewIndex = (currentViewIndex + 2) % 3;
                    component.views[toUpdateViewIndex] = component.getViewData(currentViewStartDate);
                    currentViewStartDate = this.getAdjacentViewStartTime(component, 1);
                    toUpdateViewIndex = (currentViewIndex + 1) % 3;
                    component.views[toUpdateViewIndex] = component.getViewData(currentViewStartDate);
                }
            }
        };
        CalendarService.prototype.loadEvents = function () {
            this.eventSourceChanged.next();
        };
        CalendarService.prototype.slide = function (direction) {
            this.slideChanged.next(direction);
        };
        CalendarService.prototype.update = function () {
            this.slideUpdated.next();
        };
        CalendarService = __decorate([
            core.Injectable()
        ], CalendarService);
        return CalendarService;
    }());

    var MonthViewComponent = /** @class */ (function () {
        function MonthViewComponent(calendarService) {
            this.calendarService = calendarService;
            this.autoSelect = true;
            this.dir = '';
            this.onRangeChanged = new core.EventEmitter();
            this.onEventSelected = new core.EventEmitter();
            this.onTimeSelected = new core.EventEmitter(true);
            this.onTitleChanged = new core.EventEmitter(true);
            this.views = [];
            this.currentViewIndex = 0;
            this.mode = 'month';
            this.direction = 0;
            this.moveOnSelected = false;
            this.inited = false;
            this.callbackOnInit = true;
        }
        MonthViewComponent_1 = MonthViewComponent;
        MonthViewComponent.getDates = function (startDate, n) {
            var dates = new Array(n), current = new Date(startDate.getTime());
            var i = 0;
            while (i < n) {
                dates[i++] = new Date(current.getTime());
                current.setDate(current.getDate() + 1);
            }
            return dates;
        };
        MonthViewComponent.prototype.ngOnInit = function () {
            var _this = this;
            if (!this.sliderOptions) {
                this.sliderOptions = {};
            }
            this.sliderOptions.loop = true;
            if (this.dateFormatter && this.dateFormatter.formatMonthViewDay) {
                this.formatDayLabel = this.dateFormatter.formatMonthViewDay;
            }
            else {
                var dayLabelDatePipe_1 = new common.DatePipe('en-US');
                this.formatDayLabel = function (date) {
                    return dayLabelDatePipe_1.transform(date, this.formatDay);
                };
            }
            if (this.dateFormatter && this.dateFormatter.formatMonthViewDayHeader) {
                this.formatDayHeaderLabel = this.dateFormatter.formatMonthViewDayHeader;
            }
            else {
                var datePipe_1 = new common.DatePipe(this.locale);
                this.formatDayHeaderLabel = function (date) {
                    return datePipe_1.transform(date, this.formatDayHeader);
                };
            }
            if (this.dateFormatter && this.dateFormatter.formatMonthViewTitle) {
                this.formatTitle = this.dateFormatter.formatMonthViewTitle;
            }
            else {
                var datePipe_2 = new common.DatePipe(this.locale);
                this.formatTitle = function (date) {
                    return datePipe_2.transform(date, this.formatMonthTitle);
                };
            }
            if (this.lockSwipeToPrev) {
                this.slider.lockSwipeToPrev(true);
            }
            if (this.lockSwipes) {
                this.slider.lockSwipes(true);
            }
            this.refreshView();
            this.inited = true;
            this.currentDateChangedFromParentSubscription = this.calendarService.currentDateChangedFromParent$.subscribe(function (currentDate) {
                _this.refreshView();
            });
            this.eventSourceChangedSubscription = this.calendarService.eventSourceChanged$.subscribe(function () {
                _this.onDataLoaded();
            });
            this.slideChangedSubscription = this.calendarService.slideChanged$.subscribe(function (direction) {
                if (direction === 1) {
                    _this.slider.slideNext();
                }
                else if (direction === -1) {
                    _this.slider.slidePrev();
                }
            });
            this.slideUpdatedSubscription = this.calendarService.slideUpdated$.subscribe(function () {
                _this.slider.update();
            });
        };
        MonthViewComponent.prototype.ngOnDestroy = function () {
            if (this.currentDateChangedFromParentSubscription) {
                this.currentDateChangedFromParentSubscription.unsubscribe();
                this.currentDateChangedFromParentSubscription = null;
            }
            if (this.eventSourceChangedSubscription) {
                this.eventSourceChangedSubscription.unsubscribe();
                this.eventSourceChangedSubscription = null;
            }
            if (this.slideChangedSubscription) {
                this.slideChangedSubscription.unsubscribe();
                this.slideChangedSubscription = null;
            }
            if (this.slideUpdatedSubscription) {
                this.slideUpdatedSubscription.unsubscribe();
                this.slideUpdatedSubscription = null;
            }
        };
        MonthViewComponent.prototype.ngOnChanges = function (changes) {
            if (!this.inited) {
                return;
            }
            var eventSourceChange = changes.eventSource;
            if (eventSourceChange && eventSourceChange.currentValue) {
                this.onDataLoaded();
            }
            var lockSwipeToPrev = changes.lockSwipeToPrev;
            if (lockSwipeToPrev) {
                this.slider.lockSwipeToPrev(lockSwipeToPrev.currentValue);
            }
            var lockSwipes = changes.lockSwipes;
            if (lockSwipes) {
                this.slider.lockSwipes(lockSwipes.currentValue);
            }
        };
        MonthViewComponent.prototype.ngAfterViewInit = function () {
            var title = this.getTitle();
            this.onTitleChanged.emit(title);
        };
        MonthViewComponent.prototype.onSlideChanged = function () {
            var _this = this;
            if (this.callbackOnInit) {
                this.callbackOnInit = false;
                return;
            }
            var direction = 0;
            var currentViewIndex = this.currentViewIndex;
            this.slider.getActiveIndex().then(function (currentSlideIndex) {
                currentSlideIndex = (currentSlideIndex + 2) % 3;
                if (isNaN(currentSlideIndex)) {
                    currentSlideIndex = currentViewIndex;
                }
                if (currentSlideIndex - currentViewIndex === 1) {
                    direction = 1;
                }
                else if (currentSlideIndex === 0 && currentViewIndex === 2) {
                    direction = 1;
                    _this.slider.slideTo(1, 0, false);
                }
                else if (currentViewIndex - currentSlideIndex === 1) {
                    direction = -1;
                }
                else if (currentSlideIndex === 2 && currentViewIndex === 0) {
                    direction = -1;
                    _this.slider.slideTo(3, 0, false);
                }
                _this.currentViewIndex = currentSlideIndex;
                _this.move(direction);
            });
        };
        MonthViewComponent.prototype.move = function (direction) {
            if (direction === 0) {
                return;
            }
            this.direction = direction;
            if (!this.moveOnSelected) {
                var adjacentDate = this.calendarService.getAdjacentCalendarDate(this.mode, direction);
                this.calendarService.setCurrentDate(adjacentDate);
            }
            this.refreshView();
            this.direction = 0;
            this.moveOnSelected = false;
        };
        MonthViewComponent.prototype.createDateObject = function (date) {
            var disabled = false;
            if (this.markDisabled) {
                disabled = this.markDisabled(date);
            }
            return {
                date: date,
                events: [],
                label: this.formatDayLabel(date),
                secondary: false,
                disabled: disabled,
            };
        };
        MonthViewComponent.prototype.getViewData = function (startTime) {
            var startDate = startTime, date = startDate.getDate(), month = (startDate.getMonth() + (date !== 1 ? 1 : 0)) % 12;
            var dates = MonthViewComponent_1.getDates(startDate, 42);
            var days = [];
            for (var i = 0; i < 42; i++) {
                var dateObject = this.createDateObject(dates[i]);
                dateObject.secondary = dates[i].getMonth() !== month;
                days[i] = dateObject;
            }
            var dayHeaders = [];
            for (var i = 0; i < 7; i++) {
                dayHeaders.push(this.formatDayHeaderLabel(days[i].date));
            }
            return {
                dates: days,
                dayHeaders: dayHeaders,
            };
        };
        MonthViewComponent.prototype.getHighlightClass = function (date) {
            var className = '';
            if (date.hasEvent) {
                if (date.secondary) {
                    className = 'monthview-secondary-with-event';
                }
                else {
                    className = 'monthview-primary-with-event';
                }
            }
            if (date.selected) {
                if (className) {
                    className += ' ';
                }
                className += 'monthview-selected';
            }
            if (date.current) {
                if (className) {
                    className += ' ';
                }
                className += 'monthview-current';
            }
            if (date.secondary) {
                if (className) {
                    className += ' ';
                }
                className += 'text-muted';
            }
            if (date.disabled) {
                if (className) {
                    className += ' ';
                }
                className += 'monthview-disabled';
            }
            return className;
        };
        MonthViewComponent.prototype.getRange = function (currentDate) {
            var year = currentDate.getFullYear(), month = currentDate.getMonth(), firstDayOfMonth = new Date(year, month, 1, 12, 0, 0), // set hour to 12 to avoid DST problem
            difference = this.startingDayMonth - firstDayOfMonth.getDay(), numDisplayedFromPreviousMonth = difference > 0 ? 7 - difference : -difference, startDate = new Date(firstDayOfMonth.getTime());
            if (numDisplayedFromPreviousMonth > 0) {
                startDate.setDate(-numDisplayedFromPreviousMonth + 1);
            }
            var endDate = new Date(startDate.getTime());
            endDate.setDate(endDate.getDate() + 42);
            return {
                startTime: startDate,
                endTime: endDate,
            };
        };
        MonthViewComponent.prototype.onDataLoaded = function () {
            var range = this.range, eventSource = this.eventSource, len = eventSource ? eventSource.length : 0, startTime = range.startTime, endTime = range.endTime, utcStartTime = Date.UTC(startTime.getFullYear(), startTime.getMonth(), startTime.getDate()), utcEndTime = Date.UTC(endTime.getFullYear(), endTime.getMonth(), endTime.getDate()), currentViewIndex = this.currentViewIndex, dates = this.views[currentViewIndex].dates, oneDay = 86400000, eps = 0.0006;
            for (var r = 0; r < 42; r += 1) {
                if (dates[r].hasEvent) {
                    dates[r].hasEvent = false;
                    dates[r].events = [];
                }
            }
            for (var i = 0; i < len; i += 1) {
                var event_1 = eventSource[i], eventStartTime = event_1.startTime, eventEndTime = event_1.endTime;
                var eventUTCStartTime = void 0, eventUTCEndTime = void 0;
                if (event_1.allDay) {
                    eventUTCStartTime = eventStartTime.getTime();
                    eventUTCEndTime = eventEndTime.getTime();
                }
                else {
                    eventUTCStartTime = Date.UTC(eventStartTime.getFullYear(), eventStartTime.getMonth(), eventStartTime.getDate());
                    eventUTCEndTime = Date.UTC(eventEndTime.getFullYear(), eventEndTime.getMonth(), eventEndTime.getDate() + 1);
                }
                if (eventUTCEndTime <= utcStartTime || eventUTCStartTime >= utcEndTime) {
                    continue;
                }
                var timeDifferenceStart = void 0, timeDifferenceEnd = void 0;
                if (eventUTCStartTime < utcStartTime) {
                    timeDifferenceStart = 0;
                }
                else {
                    timeDifferenceStart = (eventUTCStartTime - utcStartTime) / oneDay;
                }
                if (eventUTCEndTime > utcEndTime) {
                    timeDifferenceEnd = (utcEndTime - utcStartTime) / oneDay;
                }
                else {
                    timeDifferenceEnd = (eventUTCEndTime - utcStartTime) / oneDay;
                }
                var index = Math.floor(timeDifferenceStart);
                var endIndex = Math.ceil(timeDifferenceEnd - eps);
                while (index < endIndex) {
                    dates[index].hasEvent = true;
                    var eventSet = dates[index].events;
                    if (eventSet) {
                        eventSet.push(event_1);
                    }
                    else {
                        eventSet = [];
                        eventSet.push(event_1);
                        dates[index].events = eventSet;
                    }
                    index += 1;
                }
            }
            for (var r = 0; r < 42; r += 1) {
                if (dates[r].hasEvent) {
                    dates[r].events.sort(this.compareEvent);
                }
            }
            if (this.autoSelect) {
                var findSelected = false;
                for (var r = 0; r < 42; r += 1) {
                    if (dates[r].selected) {
                        this.selectedDate = dates[r];
                        findSelected = true;
                        break;
                    }
                }
                if (findSelected) {
                    this.onTimeSelected.emit({
                        selectedTime: this.selectedDate.date,
                        events: this.selectedDate.events,
                        disabled: this.selectedDate.disabled,
                    });
                }
            }
        };
        MonthViewComponent.prototype.refreshView = function () {
            this.range = this.getRange(this.calendarService.currentDate);
            if (this.inited) {
                var title = this.getTitle();
                this.onTitleChanged.emit(title);
            }
            this.calendarService.populateAdjacentViews(this);
            this.updateCurrentView(this.range.startTime, this.views[this.currentViewIndex]);
            this.calendarService.rangeChanged(this);
        };
        MonthViewComponent.prototype.getTitle = function () {
            var currentViewStartDate = this.range.startTime, date = currentViewStartDate.getDate(), month = (currentViewStartDate.getMonth() + (date !== 1 ? 1 : 0)) % 12, year = currentViewStartDate.getFullYear() + (date !== 1 && month === 0 ? 1 : 0), headerDate = new Date(year, month, 1, 12, 0, 0, 0);
            return this.formatTitle(headerDate);
        };
        MonthViewComponent.prototype.compareEvent = function (event1, event2) {
            if (event1.allDay) {
                return 1;
            }
            else if (event2.allDay) {
                return -1;
            }
            else {
                return event1.startTime.getTime() - event2.startTime.getTime();
            }
        };
        MonthViewComponent.prototype.select = function (viewDate) {
            if (!this.views) {
                return;
            }
            var selectedDate = viewDate.date, events = viewDate.events;
            if (!viewDate.disabled) {
                var dates = this.views[this.currentViewIndex].dates, currentCalendarDate = this.calendarService.currentDate, currentMonth = currentCalendarDate.getMonth(), currentYear = currentCalendarDate.getFullYear(), selectedMonth = selectedDate.getMonth(), selectedYear = selectedDate.getFullYear();
                var direction = 0;
                if (currentYear === selectedYear) {
                    if (currentMonth !== selectedMonth) {
                        direction = currentMonth < selectedMonth ? 1 : -1;
                    }
                }
                else {
                    direction = currentYear < selectedYear ? 1 : -1;
                }
                this.calendarService.setInitialDate(selectedDate);
                if (direction === 0) {
                    var currentViewStartDate = this.range.startTime, oneDay = 86400000, selectedDayDifference = Math.round((Date.UTC(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate()) -
                        Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) /
                        oneDay);
                    for (var r = 0; r < 42; r += 1) {
                        dates[r].selected = false;
                    }
                    if (selectedDayDifference >= 0 && selectedDayDifference < 42) {
                        dates[selectedDayDifference].selected = true;
                        this.selectedDate = dates[selectedDayDifference];
                    }
                }
                else {
                    this.moveOnSelected = true;
                    this.slideView(direction);
                }
            }
            this.onTimeSelected.emit({
                selectedTime: selectedDate,
                events: events,
                disabled: viewDate.disabled,
            });
        };
        MonthViewComponent.prototype.slideView = function (direction) {
            if (direction === 1) {
                this.slider.slideNext();
            }
            else if (direction === -1) {
                this.slider.slidePrev();
            }
        };
        MonthViewComponent.prototype.updateCurrentView = function (currentViewStartDate, view) {
            var currentCalendarDate = this.calendarService.initialDate, today = new Date(), oneDay = 86400000, selectedDayDifference = Math.round((Date.UTC(currentCalendarDate.getFullYear(), currentCalendarDate.getMonth(), currentCalendarDate.getDate()) -
                Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) /
                oneDay), currentDayDifference = Math.round((Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()) -
                Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) /
                oneDay);
            for (var r = 0; r < 42; r += 1) {
                view.dates[r].selected = false;
            }
            if (selectedDayDifference >= 0 &&
                selectedDayDifference < 42 &&
                !view.dates[selectedDayDifference].disabled &&
                (this.autoSelect || this.moveOnSelected)) {
                view.dates[selectedDayDifference].selected = true;
                this.selectedDate = view.dates[selectedDayDifference];
            }
            else {
                this.selectedDate = {
                    date: null,
                    events: [],
                    label: null,
                    secondary: null,
                    disabled: false,
                };
            }
            if (currentDayDifference >= 0 && currentDayDifference < 42) {
                view.dates[currentDayDifference].current = true;
            }
        };
        MonthViewComponent.prototype.eventSelected = function (event) {
            this.onEventSelected.emit(event);
        };
        var MonthViewComponent_1;
        MonthViewComponent.ctorParameters = function () { return [
            { type: CalendarService }
        ]; };
        __decorate([
            core.ViewChild('monthSlider', { static: true })
        ], MonthViewComponent.prototype, "slider", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "monthviewDisplayEventTemplate", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "monthviewInactiveDisplayEventTemplate", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "monthviewEventDetailTemplate", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "formatDay", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "formatDayHeader", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "formatMonthTitle", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "eventSource", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "startingDayMonth", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "showEventDetail", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "noEventsLabel", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "autoSelect", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "markDisabled", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "locale", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "dateFormatter", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "dir", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "lockSwipeToPrev", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "lockSwipes", void 0);
        __decorate([
            core.Input()
        ], MonthViewComponent.prototype, "sliderOptions", void 0);
        __decorate([
            core.Output()
        ], MonthViewComponent.prototype, "onRangeChanged", void 0);
        __decorate([
            core.Output()
        ], MonthViewComponent.prototype, "onEventSelected", void 0);
        __decorate([
            core.Output()
        ], MonthViewComponent.prototype, "onTimeSelected", void 0);
        __decorate([
            core.Output()
        ], MonthViewComponent.prototype, "onTitleChanged", void 0);
        MonthViewComponent = MonthViewComponent_1 = __decorate([
            core.Component({
                selector: 'monthview',
                template: "\n\t\t<div>\n\t\t\t<ion-slides #monthSlider [options]=\"sliderOptions\" [dir]=\"dir\" (ionSlideDidChange)=\"onSlideChanged()\">\n\t\t\t\t<ion-slide>\n\t\t\t\t\t<table *ngIf=\"0 === currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[0].dayHeaders\">\n\t\t\t\t\t\t\t\t\t<small>{{ dayHeader }}</small>\n\t\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t\t<tr *ngFor=\"let row of [0, 1, 2, 3, 4, 5]\">\n\t\t\t\t\t\t\t\t<td\n\t\t\t\t\t\t\t\t\t*ngFor=\"let col of [0, 1, 2, 3, 4, 5, 6]\"\n\t\t\t\t\t\t\t\t\ttappable\n\t\t\t\t\t\t\t\t\t(click)=\"select(views[0].dates[row * 7 + col])\"\n\t\t\t\t\t\t\t\t\t[ngClass]=\"getHighlightClass(views[0].dates[row * 7 + col])\"\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{\n\t\t\t\t\t\t\t\t\t\t\tview: views[0],\n\t\t\t\t\t\t\t\t\t\t\trow: row,\n\t\t\t\t\t\t\t\t\t\t\tcol: col\n\t\t\t\t\t\t\t\t\t\t}\"\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t\t<table *ngIf=\"0 !== currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t\t<tr class=\"text-center\">\n\t\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[0].dayHeaders\">\n\t\t\t\t\t\t\t\t\t<small>{{ dayHeader }}</small>\n\t\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t\t<tr *ngFor=\"let row of [0, 1, 2, 3, 4, 5]\">\n\t\t\t\t\t\t\t\t<td *ngFor=\"let col of [0, 1, 2, 3, 4, 5, 6]\">\n\t\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewInactiveDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{\n\t\t\t\t\t\t\t\t\t\t\tview: views[0],\n\t\t\t\t\t\t\t\t\t\t\trow: row,\n\t\t\t\t\t\t\t\t\t\t\tcol: col\n\t\t\t\t\t\t\t\t\t\t}\"\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t</tr>\n\n\t\t\t\t\t\t\t<tr></tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t</ion-slide>\n\t\t\t\t<ion-slide>\n\t\t\t\t\t<table *ngIf=\"1 === currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[1].dayHeaders\">\n\t\t\t\t\t\t\t\t\t<small>{{ dayHeader }}</small>\n\t\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t\t<tr *ngFor=\"let row of [0, 1, 2, 3, 4, 5]\">\n\t\t\t\t\t\t\t\t<td\n\t\t\t\t\t\t\t\t\t*ngFor=\"let col of [0, 1, 2, 3, 4, 5, 6]\"\n\t\t\t\t\t\t\t\t\ttappable\n\t\t\t\t\t\t\t\t\t(click)=\"select(views[1].dates[row * 7 + col])\"\n\t\t\t\t\t\t\t\t\t[ngClass]=\"getHighlightClass(views[1].dates[row * 7 + col])\"\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{\n\t\t\t\t\t\t\t\t\t\t\tview: views[1],\n\t\t\t\t\t\t\t\t\t\t\trow: row,\n\t\t\t\t\t\t\t\t\t\t\tcol: col\n\t\t\t\t\t\t\t\t\t\t}\"\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t\t<table *ngIf=\"1 !== currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t\t<tr class=\"text-center\">\n\t\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[1].dayHeaders\">\n\t\t\t\t\t\t\t\t\t<small>{{ dayHeader }}</small>\n\t\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t\t<tr *ngFor=\"let row of [0, 1, 2, 3, 4, 5]\">\n\t\t\t\t\t\t\t\t<td *ngFor=\"let col of [0, 1, 2, 3, 4, 5, 6]\">\n\t\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewInactiveDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{\n\t\t\t\t\t\t\t\t\t\t\tview: views[1],\n\t\t\t\t\t\t\t\t\t\t\trow: row,\n\t\t\t\t\t\t\t\t\t\t\tcol: col\n\t\t\t\t\t\t\t\t\t\t}\"\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t</tr>\n\n\t\t\t\t\t\t\t<tr></tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t</ion-slide>\n\t\t\t\t<ion-slide>\n\t\t\t\t\t<table *ngIf=\"2 === currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[2].dayHeaders\">\n\t\t\t\t\t\t\t\t\t<small>{{ dayHeader }}</small>\n\t\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t\t<tr *ngFor=\"let row of [0, 1, 2, 3, 4, 5]\">\n\t\t\t\t\t\t\t\t<td\n\t\t\t\t\t\t\t\t\t*ngFor=\"let col of [0, 1, 2, 3, 4, 5, 6]\"\n\t\t\t\t\t\t\t\t\ttappable\n\t\t\t\t\t\t\t\t\t(click)=\"select(views[2].dates[row * 7 + col])\"\n\t\t\t\t\t\t\t\t\t[ngClass]=\"getHighlightClass(views[2].dates[row * 7 + col])\"\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{\n\t\t\t\t\t\t\t\t\t\t\tview: views[2],\n\t\t\t\t\t\t\t\t\t\t\trow: row,\n\t\t\t\t\t\t\t\t\t\t\tcol: col\n\t\t\t\t\t\t\t\t\t\t}\"\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t\t<table *ngIf=\"2 !== currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t\t<tr class=\"text-center\">\n\t\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[2].dayHeaders\">\n\t\t\t\t\t\t\t\t\t<small>{{ dayHeader }}</small>\n\t\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t\t<tr *ngFor=\"let row of [0, 1, 2, 3, 4, 5]\">\n\t\t\t\t\t\t\t\t<td *ngFor=\"let col of [0, 1, 2, 3, 4, 5, 6]\">\n\t\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewInactiveDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{\n\t\t\t\t\t\t\t\t\t\t\tview: views[2],\n\t\t\t\t\t\t\t\t\t\t\trow: row,\n\t\t\t\t\t\t\t\t\t\t\tcol: col\n\t\t\t\t\t\t\t\t\t\t}\"\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t</tr>\n\n\t\t\t\t\t\t\t<tr></tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t</ion-slide>\n\t\t\t</ion-slides>\n\t\t\t<ng-template\n\t\t\t\t[ngTemplateOutlet]=\"monthviewEventDetailTemplate\"\n\t\t\t\t[ngTemplateOutletContext]=\"{\n\t\t\t\t\tshowEventDetail: showEventDetail,\n\t\t\t\t\tselectedDate: selectedDate,\n\t\t\t\t\tnoEventsLabel: noEventsLabel\n\t\t\t\t}\"\n\t\t\t>\n\t\t\t</ng-template>\n\t\t</div>\n\t",
                styles: ["\n\t\t\t.text-muted {\n\t\t\t\tcolor: #999;\n\t\t\t}\n\n\t\t\t.table-fixed {\n\t\t\t\ttable-layout: fixed;\n\t\t\t}\n\n\t\t\t.table {\n\t\t\t\twidth: 100%;\n\t\t\t\tmax-width: 100%;\n\t\t\t\tbackground-color: transparent;\n\t\t\t}\n\n\t\t\t.table > thead > tr > th,\n\t\t\t.table > tbody > tr > th,\n\t\t\t.table > tfoot > tr > th,\n\t\t\t.table > thead > tr > td,\n\t\t\t.table > tbody > tr > td,\n\t\t\t.table > tfoot > tr > td {\n\t\t\t\tpadding: 8px;\n\t\t\t\tline-height: 20px;\n\t\t\t\tvertical-align: top;\n\t\t\t}\n\n\t\t\t.table > thead > tr > th {\n\t\t\t\tvertical-align: bottom;\n\t\t\t\tborder-bottom: 2px solid #ddd;\n\t\t\t}\n\n\t\t\t.table > thead:first-child > tr:first-child > th,\n\t\t\t.table > thead:first-child > tr:first-child > td {\n\t\t\t\tborder-top: 0;\n\t\t\t}\n\n\t\t\t.table > tbody + tbody {\n\t\t\t\tborder-top: 2px solid #ddd;\n\t\t\t}\n\n\t\t\t.table-bordered {\n\t\t\t\tborder: 1px solid #ddd;\n\t\t\t}\n\n\t\t\t.table-bordered > thead > tr > th,\n\t\t\t.table-bordered > tbody > tr > th,\n\t\t\t.table-bordered > tfoot > tr > th,\n\t\t\t.table-bordered > thead > tr > td,\n\t\t\t.table-bordered > tbody > tr > td,\n\t\t\t.table-bordered > tfoot > tr > td {\n\t\t\t\tborder: 1px solid #ddd;\n\t\t\t}\n\n\t\t\t.table-bordered > thead > tr > th,\n\t\t\t.table-bordered > thead > tr > td {\n\t\t\t\tborder-bottom-width: 2px;\n\t\t\t}\n\n\t\t\t.table-striped > tbody > tr:nth-child(odd) > td,\n\t\t\t.table-striped > tbody > tr:nth-child(odd) > th {\n\t\t\t\tbackground-color: #f9f9f9;\n\t\t\t}\n\n\t\t\t.monthview-primary-with-event {\n\t\t\t\tbackground-color: #3a87ad;\n\t\t\t\tcolor: white;\n\t\t\t}\n\n\t\t\t.monthview-current {\n\t\t\t\tbackground-color: #f0f0f0;\n\t\t\t}\n\n\t\t\t.monthview-selected {\n\t\t\t\tbackground-color: #009900;\n\t\t\t\tcolor: white;\n\t\t\t}\n\n\t\t\t.monthview-datetable td.monthview-disabled {\n\t\t\t\tcolor: lightgrey;\n\t\t\t\tcursor: default;\n\t\t\t}\n\n\t\t\t.monthview-datetable th {\n\t\t\t\ttext-align: center;\n\t\t\t}\n\n\t\t\t.monthview-datetable td {\n\t\t\t\tcursor: pointer;\n\t\t\t\ttext-align: center;\n\t\t\t}\n\n\t\t\t.monthview-secondary-with-event {\n\t\t\t\tbackground-color: #d9edf7;\n\t\t\t}\n\n\t\t\t::-webkit-scrollbar,\n\t\t\t*::-webkit-scrollbar {\n\t\t\t\tdisplay: none;\n\t\t\t}\n\t\t"]
            })
        ], MonthViewComponent);
        return MonthViewComponent;
    }());

    var WeekViewComponent = /** @class */ (function () {
        function WeekViewComponent(calendarService, elm) {
            this.calendarService = calendarService;
            this.elm = elm;
            this.class = true;
            this.autoSelect = true;
            this.dir = '';
            this.scrollToHour = 0;
            this.onRangeChanged = new core.EventEmitter();
            this.onEventSelected = new core.EventEmitter();
            this.onTimeSelected = new core.EventEmitter();
            this.onDayHeaderSelected = new core.EventEmitter();
            this.onTitleChanged = new core.EventEmitter(true);
            this.views = [];
            this.currentViewIndex = 0;
            this.direction = 0;
            this.mode = 'week';
            this.inited = false;
            this.callbackOnInit = true;
        }
        WeekViewComponent_1 = WeekViewComponent;
        WeekViewComponent.createDateObjects = function (startTime, startHour, endHour, timeInterval) {
            var times = [], currentHour = 0, currentDate = startTime.getDate();
            var hourStep, minStep;
            if (timeInterval < 1) {
                hourStep = Math.floor(1 / timeInterval);
                minStep = 60;
            }
            else {
                hourStep = 1;
                minStep = Math.floor(60 / timeInterval);
            }
            for (var hour = startHour; hour < endHour; hour += hourStep) {
                for (var interval = 0; interval < 60; interval += minStep) {
                    var row = [];
                    for (var day = 0; day < 7; day += 1) {
                        var time = new Date(startTime.getTime());
                        time.setHours(currentHour + hour, interval);
                        time.setDate(currentDate + day);
                        row.push({
                            events: [],
                            time: time
                        });
                    }
                    times.push(row);
                }
            }
            return times;
        };
        WeekViewComponent.getDates = function (startTime, n) {
            var dates = new Array(n), current = new Date(startTime.getTime());
            var i = 0;
            while (i < n) {
                dates[i++] = {
                    date: new Date(current.getTime()),
                    events: [],
                    dayHeader: ''
                };
                current.setDate(current.getDate() + 1);
            }
            return dates;
        };
        WeekViewComponent.compareEventByStartOffset = function (eventA, eventB) {
            return eventA.startOffset - eventB.startOffset;
        };
        WeekViewComponent.calculateWidth = function (orderedEvents, size, hourParts) {
            var totalSize = size * hourParts, cells = new Array(totalSize);
            // sort by position in descending order, the right most columns should be calculated first
            orderedEvents.sort(function (eventA, eventB) {
                return eventB.position - eventA.position;
            });
            for (var i_1 = 0; i_1 < totalSize; i_1 += 1) {
                cells[i_1] = {
                    calculated: false,
                    events: []
                };
            }
            var len = orderedEvents.length;
            for (var i_2 = 0; i_2 < len; i_2 += 1) {
                var event_1 = orderedEvents[i_2];
                var index = event_1.startIndex * hourParts + event_1.startOffset;
                while (index < event_1.endIndex * hourParts - event_1.endOffset) {
                    cells[index].events.push(event_1);
                    index += 1;
                }
            }
            var i = 0;
            while (i < len) {
                var event_2 = orderedEvents[i];
                if (!event_2.overlapNumber) {
                    var overlapNumber = event_2.position + 1;
                    event_2.overlapNumber = overlapNumber;
                    var eventQueue = [event_2];
                    while (event_2 = eventQueue.shift()) {
                        var index = event_2.startIndex * hourParts + event_2.startOffset;
                        while (index < event_2.endIndex * hourParts - event_2.endOffset) {
                            if (!cells[index].calculated) {
                                cells[index].calculated = true;
                                if (cells[index].events) {
                                    var eventCountInCell = cells[index].events.length;
                                    for (var j = 0; j < eventCountInCell; j += 1) {
                                        var currentEventInCell = cells[index].events[j];
                                        if (!currentEventInCell.overlapNumber) {
                                            currentEventInCell.overlapNumber = overlapNumber;
                                            eventQueue.push(currentEventInCell);
                                        }
                                    }
                                }
                            }
                            index += 1;
                        }
                    }
                }
                i += 1;
            }
        };
        WeekViewComponent.prototype.ngOnInit = function () {
            var _this = this;
            if (!this.sliderOptions) {
                this.sliderOptions = {};
            }
            this.sliderOptions.loop = true;
            this.hourRange = (this.endHour - this.startHour) * this.hourSegments;
            if (this.dateFormatter && this.dateFormatter.formatWeekViewDayHeader) {
                this.formatDayHeader = this.dateFormatter.formatWeekViewDayHeader;
            }
            else {
                var datePipe_1 = new common.DatePipe(this.locale);
                this.formatDayHeader = function (date) {
                    return datePipe_1.transform(date, this.formatWeekViewDayHeader);
                };
            }
            if (this.dateFormatter && this.dateFormatter.formatWeekViewTitle) {
                this.formatTitle = this.dateFormatter.formatWeekViewTitle;
            }
            else {
                var datePipe_2 = new common.DatePipe(this.locale);
                this.formatTitle = function (date) {
                    return datePipe_2.transform(date, this.formatWeekTitle);
                };
            }
            if (this.dateFormatter && this.dateFormatter.formatWeekViewHourColumn) {
                this.formatHourColumnLabel = this.dateFormatter.formatWeekViewHourColumn;
            }
            else {
                var datePipe_3 = new common.DatePipe(this.locale);
                this.formatHourColumnLabel = function (date) {
                    return datePipe_3.transform(date, this.formatHourColumn);
                };
            }
            if (this.lockSwipeToPrev) {
                this.slider.lockSwipeToPrev(true);
            }
            if (this.lockSwipes) {
                this.slider.lockSwipes(true);
            }
            this.refreshView();
            this.hourColumnLabels = this.getHourColumnLabels();
            this.inited = true;
            this.currentDateChangedFromParentSubscription = this.calendarService.currentDateChangedFromParent$.subscribe(function (currentDate) {
                _this.refreshView();
            });
            this.eventSourceChangedSubscription = this.calendarService.eventSourceChanged$.subscribe(function () {
                _this.onDataLoaded();
            });
            this.slideChangedSubscription = this.calendarService.slideChanged$.subscribe(function (direction) {
                if (direction === 1) {
                    _this.slider.slideNext();
                }
                else if (direction === -1) {
                    _this.slider.slidePrev();
                }
            });
            this.slideUpdatedSubscription = this.calendarService.slideUpdated$.subscribe(function () {
                _this.slider.update();
            });
        };
        WeekViewComponent.prototype.ngAfterViewInit = function () {
            var title = this.getTitle();
            this.onTitleChanged.emit(title);
            if (this.scrollToHour > 0) {
                var hourColumns_1 = this.elm.nativeElement.querySelector('.weekview-normal-event-container').querySelectorAll('.calendar-hour-column');
                var me_1 = this;
                setTimeout(function () {
                    me_1.initScrollPosition = hourColumns_1[me_1.scrollToHour - me_1.startHour].offsetTop;
                }, 50);
            }
        };
        WeekViewComponent.prototype.ngOnChanges = function (changes) {
            if (!this.inited) {
                return;
            }
            if ((changes.startHour || changes.endHour) && (!changes.startHour.isFirstChange() || !changes.endHour.isFirstChange())) {
                this.views = undefined;
                this.hourRange = (this.endHour - this.startHour) * this.hourSegments;
                this.direction = 0;
                this.refreshView();
                this.hourColumnLabels = this.getHourColumnLabels();
            }
            var eventSourceChange = changes.eventSource;
            if (eventSourceChange && eventSourceChange.currentValue) {
                this.onDataLoaded();
            }
            var lockSwipeToPrev = changes.lockSwipeToPrev;
            if (lockSwipeToPrev) {
                this.slider.lockSwipeToPrev(lockSwipeToPrev.currentValue);
            }
            var lockSwipes = changes.lockSwipes;
            if (lockSwipes) {
                this.slider.lockSwipes(lockSwipes.currentValue);
            }
        };
        WeekViewComponent.prototype.ngOnDestroy = function () {
            if (this.currentDateChangedFromParentSubscription) {
                this.currentDateChangedFromParentSubscription.unsubscribe();
                this.currentDateChangedFromParentSubscription = null;
            }
            if (this.eventSourceChangedSubscription) {
                this.eventSourceChangedSubscription.unsubscribe();
                this.eventSourceChangedSubscription = null;
            }
            if (this.slideChangedSubscription) {
                this.slideChangedSubscription.unsubscribe();
                this.slideChangedSubscription = null;
            }
            if (this.slideUpdatedSubscription) {
                this.slideUpdatedSubscription.unsubscribe();
                this.slideUpdatedSubscription = null;
            }
        };
        WeekViewComponent.prototype.onSlideChanged = function () {
            var _this = this;
            if (this.callbackOnInit) {
                this.callbackOnInit = false;
                return;
            }
            var currentViewIndex = this.currentViewIndex;
            var direction = 0;
            this.slider.getActiveIndex().then(function (currentSlideIndex) {
                currentSlideIndex = (currentSlideIndex + 2) % 3;
                if (isNaN(currentSlideIndex)) {
                    currentSlideIndex = currentViewIndex;
                }
                if (currentSlideIndex - currentViewIndex === 1) {
                    direction = 1;
                }
                else if (currentSlideIndex === 0 && currentViewIndex === 2) {
                    direction = 1;
                    _this.slider.slideTo(1, 0, false);
                }
                else if (currentViewIndex - currentSlideIndex === 1) {
                    direction = -1;
                }
                else if (currentSlideIndex === 2 && currentViewIndex === 0) {
                    direction = -1;
                    _this.slider.slideTo(3, 0, false);
                }
                _this.currentViewIndex = currentSlideIndex;
                _this.move(direction);
            });
        };
        WeekViewComponent.prototype.move = function (direction) {
            if (direction === 0) {
                return;
            }
            this.direction = direction;
            var adjacent = this.calendarService.getAdjacentCalendarDate(this.mode, direction);
            this.calendarService.setCurrentDate(adjacent);
            this.refreshView();
            this.direction = 0;
        };
        WeekViewComponent.prototype.getHourColumnLabels = function () {
            var hourColumnLabels = [];
            for (var hour = 0, length_1 = this.views[0].rows.length; hour < length_1; hour += 1) {
                // handle edge case for DST
                if (hour === 0 && this.views[0].rows[hour][0].time.getHours() !== this.startHour) {
                    var time = new Date(this.views[0].rows[hour][0].time);
                    time.setDate(time.getDate() + 1);
                    time.setHours(this.startHour);
                    hourColumnLabels.push(this.formatHourColumnLabel(time));
                }
                else {
                    hourColumnLabels.push(this.formatHourColumnLabel(this.views[0].rows[hour][0].time));
                }
            }
            return hourColumnLabels;
        };
        WeekViewComponent.prototype.getViewData = function (startTime) {
            var dates = WeekViewComponent_1.getDates(startTime, 7);
            for (var i = 0; i < 7; i++) {
                dates[i].dayHeader = this.formatDayHeader(dates[i].date);
            }
            return {
                rows: WeekViewComponent_1.createDateObjects(startTime, this.startHour, this.endHour, this.hourSegments),
                dates: dates
            };
        };
        WeekViewComponent.prototype.getRange = function (currentDate) {
            var year = currentDate.getFullYear(), month = currentDate.getMonth(), date = currentDate.getDate(), day = currentDate.getDay();
            var difference = day - this.startingDayWeek;
            if (difference < 0) {
                difference += 7;
            }
            // set hour to 12 to avoid DST problem
            var firstDayOfWeek = new Date(year, month, date - difference, 12, 0, 0), endTime = new Date(year, month, date - difference + 7, 12, 0, 0);
            return {
                startTime: firstDayOfWeek,
                endTime: endTime
            };
        };
        WeekViewComponent.prototype.onDataLoaded = function () {
            var eventSource = this.eventSource, len = eventSource ? eventSource.length : 0, startTime = this.range.startTime, endTime = this.range.endTime, utcStartTime = Date.UTC(startTime.getFullYear(), startTime.getMonth(), startTime.getDate()), utcEndTime = Date.UTC(endTime.getFullYear(), endTime.getMonth(), endTime.getDate()), currentViewIndex = this.currentViewIndex, rows = this.views[currentViewIndex].rows, dates = this.views[currentViewIndex].dates, oneHour = 3600000, oneDay = 86400000, 
            // add allday eps
            eps = 0.016, rangeStartRowIndex = this.startHour * this.hourSegments, rangeEndRowIndex = this.endHour * this.hourSegments, allRows = 24 * this.hourSegments;
            var allDayEventInRange = false, normalEventInRange = false;
            for (var i = 0; i < 7; i += 1) {
                dates[i].events = [];
                dates[i].hasEvent = false;
            }
            for (var day = 0; day < 7; day += 1) {
                for (var hour = 0; hour < this.hourRange; hour += 1) {
                    rows[hour][day].events = [];
                }
            }
            for (var i = 0; i < len; i += 1) {
                var event_3 = eventSource[i];
                var eventStartTime = event_3.startTime;
                var eventEndTime = event_3.endTime;
                var eventUTCStartTime = void 0, eventUTCEndTime = void 0;
                if (event_3.allDay) {
                    eventUTCStartTime = eventStartTime.getTime();
                    eventUTCEndTime = eventEndTime.getTime();
                }
                else {
                    eventUTCStartTime = Date.UTC(eventStartTime.getFullYear(), eventStartTime.getMonth(), eventStartTime.getDate());
                    eventUTCEndTime = Date.UTC(eventEndTime.getFullYear(), eventEndTime.getMonth(), eventEndTime.getDate() + 1);
                }
                if (eventUTCEndTime <= utcStartTime || eventUTCStartTime >= utcEndTime || eventStartTime >= eventEndTime) {
                    continue;
                }
                if (event_3.allDay) {
                    allDayEventInRange = true;
                    var allDayStartIndex = void 0;
                    if (eventUTCStartTime <= utcStartTime) {
                        allDayStartIndex = 0;
                    }
                    else {
                        allDayStartIndex = Math.round((eventUTCStartTime - utcStartTime) / oneDay);
                    }
                    var allDayEndIndex = void 0;
                    if (eventUTCEndTime >= utcEndTime) {
                        allDayEndIndex = Math.round((utcEndTime - utcStartTime) / oneDay);
                    }
                    else {
                        allDayEndIndex = Math.round((eventUTCEndTime - utcStartTime) / oneDay);
                    }
                    var displayAllDayEvent = {
                        event: event_3,
                        startIndex: allDayStartIndex,
                        endIndex: allDayEndIndex
                    };
                    var eventSet = dates[allDayStartIndex].events;
                    if (eventSet) {
                        eventSet.push(displayAllDayEvent);
                    }
                    else {
                        eventSet = [];
                        eventSet.push(displayAllDayEvent);
                        dates[allDayStartIndex].events = eventSet;
                    }
                    dates[allDayStartIndex].hasEvent = true;
                }
                else {
                    normalEventInRange = true;
                    var timeDifferenceStart = void 0;
                    if (eventUTCStartTime < utcStartTime) {
                        timeDifferenceStart = 0;
                    }
                    else {
                        timeDifferenceStart = (eventUTCStartTime - utcStartTime) / oneHour * this.hourSegments + (eventStartTime.getHours() + eventStartTime.getMinutes() / 60) * this.hourSegments;
                    }
                    var timeDifferenceEnd = void 0;
                    if (eventUTCEndTime > utcEndTime) {
                        timeDifferenceEnd = (utcEndTime - utcStartTime) / oneHour * this.hourSegments;
                    }
                    else {
                        timeDifferenceEnd = (eventUTCEndTime - oneDay - utcStartTime) / oneHour * this.hourSegments + (eventEndTime.getHours() + eventEndTime.getMinutes() / 60) * this.hourSegments;
                    }
                    var startIndex = Math.floor(timeDifferenceStart), endIndex = Math.ceil(timeDifferenceEnd - eps);
                    var startRowIndex = startIndex % allRows, dayIndex = Math.floor(startIndex / allRows), endOfDay = dayIndex * allRows, startOffset = 0, endOffset = 0;
                    if (this.hourParts !== 1) {
                        if (startRowIndex < rangeStartRowIndex) {
                            startOffset = 0;
                        }
                        else {
                            startOffset = Math.floor((timeDifferenceStart - startIndex) * this.hourParts);
                        }
                    }
                    do {
                        endOfDay += allRows;
                        var endRowIndex = void 0;
                        if (endOfDay < endIndex) {
                            endRowIndex = allRows;
                        }
                        else {
                            if (endOfDay === endIndex) {
                                endRowIndex = allRows;
                            }
                            else {
                                endRowIndex = endIndex % allRows;
                            }
                            if (this.hourParts !== 1) {
                                if (endRowIndex > rangeEndRowIndex) {
                                    endOffset = 0;
                                }
                                else {
                                    endOffset = Math.floor((endIndex - timeDifferenceEnd) * this.hourParts);
                                }
                            }
                        }
                        if (startRowIndex < rangeStartRowIndex) {
                            startRowIndex = 0;
                        }
                        else {
                            startRowIndex -= rangeStartRowIndex;
                        }
                        if (endRowIndex > rangeEndRowIndex) {
                            endRowIndex = rangeEndRowIndex;
                        }
                        endRowIndex -= rangeStartRowIndex;
                        if (startRowIndex < endRowIndex) {
                            var displayEvent = {
                                event: event_3,
                                startIndex: startRowIndex,
                                endIndex: endRowIndex,
                                startOffset: startOffset,
                                endOffset: endOffset
                            };
                            var eventSet = rows[startRowIndex][dayIndex].events;
                            if (eventSet) {
                                eventSet.push(displayEvent);
                            }
                            else {
                                eventSet = [];
                                eventSet.push(displayEvent);
                                rows[startRowIndex][dayIndex].events = eventSet;
                            }
                            dates[dayIndex].hasEvent = true;
                        }
                        startRowIndex = 0;
                        startOffset = 0;
                        dayIndex += 1;
                    } while (endOfDay < endIndex);
                }
            }
            if (normalEventInRange) {
                for (var day = 0; day < 7; day += 1) {
                    var orderedEvents = [];
                    for (var hour = 0; hour < this.hourRange; hour += 1) {
                        if (rows[hour][day].events) {
                            rows[hour][day].events.sort(WeekViewComponent_1.compareEventByStartOffset);
                            orderedEvents = orderedEvents.concat(rows[hour][day].events);
                        }
                    }
                    if (orderedEvents.length > 0) {
                        this.placeEvents(orderedEvents);
                    }
                }
            }
            if (allDayEventInRange) {
                var orderedAllDayEvents = [];
                for (var day = 0; day < 7; day += 1) {
                    if (dates[day].events) {
                        orderedAllDayEvents = orderedAllDayEvents.concat(dates[day].events);
                    }
                }
                if (orderedAllDayEvents.length > 0) {
                    this.placeAllDayEvents(orderedAllDayEvents);
                }
            }
            if (this.autoSelect) {
                var findSelected = false;
                var selectedDate = void 0;
                for (var r = 0; r < 7; r += 1) {
                    if (dates[r].selected) {
                        selectedDate = dates[r];
                        findSelected = true;
                        break;
                    }
                }
                if (findSelected) {
                    var disabled = false;
                    if (this.markDisabled) {
                        disabled = this.markDisabled(selectedDate.date);
                    }
                    this.onTimeSelected.emit({
                        selectedTime: selectedDate.date,
                        events: selectedDate.events.map(function (e) { return e.event; }),
                        disabled: disabled
                    });
                }
            }
        };
        WeekViewComponent.prototype.refreshView = function () {
            this.range = this.getRange(this.calendarService.currentDate);
            if (this.inited) {
                var title = this.getTitle();
                this.onTitleChanged.emit(title);
            }
            this.calendarService.populateAdjacentViews(this);
            this.updateCurrentView(this.range.startTime, this.views[this.currentViewIndex]);
            this.calendarService.rangeChanged(this);
        };
        WeekViewComponent.prototype.getTitle = function () {
            var firstDayOfWeek = new Date(this.range.startTime.getTime());
            firstDayOfWeek.setHours(12, 0, 0, 0);
            return this.formatTitle(firstDayOfWeek);
        };
        WeekViewComponent.prototype.getHighlightClass = function (date) {
            var className = '';
            if (date.hasEvent) {
                if (className) {
                    className += ' ';
                }
                className = 'weekview-with-event';
            }
            if (date.selected) {
                if (className) {
                    className += ' ';
                }
                className += 'weekview-selected';
            }
            if (date.current) {
                if (className) {
                    className += ' ';
                }
                className += 'weekview-current';
            }
            return className;
        };
        WeekViewComponent.prototype.select = function (selectedTime, events) {
            var disabled = false;
            if (this.markDisabled) {
                disabled = this.markDisabled(selectedTime);
            }
            this.onTimeSelected.emit({
                selectedTime: selectedTime,
                events: events.map(function (e) { return e.event; }),
                disabled: disabled
            });
        };
        WeekViewComponent.prototype.placeEvents = function (orderedEvents) {
            this.calculatePosition(orderedEvents);
            WeekViewComponent_1.calculateWidth(orderedEvents, this.hourRange, this.hourParts);
        };
        WeekViewComponent.prototype.placeAllDayEvents = function (orderedEvents) {
            this.calculatePosition(orderedEvents);
        };
        WeekViewComponent.prototype.overlap = function (event1, event2) {
            var earlyEvent = event1, lateEvent = event2;
            if (event1.startIndex > event2.startIndex || (event1.startIndex === event2.startIndex && event1.startOffset > event2.startOffset)) {
                earlyEvent = event2;
                lateEvent = event1;
            }
            if (earlyEvent.endIndex <= lateEvent.startIndex) {
                return false;
            }
            else {
                return !(earlyEvent.endIndex - lateEvent.startIndex === 1 && earlyEvent.endOffset + lateEvent.startOffset >= this.hourParts);
            }
        };
        WeekViewComponent.prototype.calculatePosition = function (events) {
            var len = events.length, isForbidden = new Array(len);
            var maxColumn = 0;
            for (var i = 0; i < len; i += 1) {
                var col = void 0;
                for (col = 0; col < maxColumn; col += 1) {
                    isForbidden[col] = false;
                }
                for (var j = 0; j < i; j += 1) {
                    if (this.overlap(events[i], events[j])) {
                        isForbidden[events[j].position] = true;
                    }
                }
                for (col = 0; col < maxColumn; col += 1) {
                    if (!isForbidden[col]) {
                        break;
                    }
                }
                if (col < maxColumn) {
                    events[i].position = col;
                }
                else {
                    events[i].position = maxColumn++;
                }
            }
            if (this.dir === 'rtl') {
                for (var i = 0; i < len; i += 1) {
                    events[i].position = maxColumn - 1 - events[i].position;
                }
            }
        };
        WeekViewComponent.prototype.updateCurrentView = function (currentViewStartDate, view) {
            var currentCalendarDate = this.calendarService.currentDate, today = new Date(), oneDay = 86400000, selectedDayDifference = Math.round((Date.UTC(currentCalendarDate.getFullYear(), currentCalendarDate.getMonth(), currentCalendarDate.getDate()) - Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) / oneDay), currentDayDifference = Math.floor((Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()) - Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) / oneDay);
            for (var r = 0; r < 7; r += 1) {
                view.dates[r].selected = false;
            }
            if (selectedDayDifference >= 0 && selectedDayDifference < 7 && this.autoSelect) {
                view.dates[selectedDayDifference].selected = true;
            }
            if (currentDayDifference >= 0 && currentDayDifference < 7) {
                view.dates[currentDayDifference].current = true;
            }
        };
        WeekViewComponent.prototype.daySelected = function (viewDate) {
            var selectedDate = viewDate.date, dates = this.views[this.currentViewIndex].dates, currentViewStartDate = this.range.startTime, oneDay = 86400000, selectedDayDifference = Math.round((Date.UTC(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate()) - Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) / oneDay);
            this.calendarService.setCurrentDate(selectedDate);
            for (var r = 0; r < 7; r += 1) {
                dates[r].selected = false;
            }
            if (selectedDayDifference >= 0 && selectedDayDifference < 7) {
                dates[selectedDayDifference].selected = true;
            }
            var disabled = false;
            if (this.markDisabled) {
                disabled = this.markDisabled(selectedDate);
            }
            this.onDayHeaderSelected.emit({ selectedTime: selectedDate, events: viewDate.events.map(function (e) { return e.event; }), disabled: disabled });
        };
        WeekViewComponent.prototype.setScrollPosition = function (scrollPosition) {
            this.initScrollPosition = scrollPosition;
        };
        var WeekViewComponent_1;
        WeekViewComponent.ctorParameters = function () { return [
            { type: CalendarService },
            { type: core.ElementRef }
        ]; };
        __decorate([
            core.ViewChild('weekSlider', { static: true })
        ], WeekViewComponent.prototype, "slider", void 0);
        __decorate([
            core.HostBinding('class.weekview')
        ], WeekViewComponent.prototype, "class", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "weekviewHeaderTemplate", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "weekviewAllDayEventTemplate", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "weekviewNormalEventTemplate", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "weekviewAllDayEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "weekviewNormalEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "weekviewInactiveAllDayEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "weekviewInactiveNormalEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "formatWeekTitle", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "formatWeekViewDayHeader", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "formatHourColumn", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "startingDayWeek", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "allDayLabel", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "hourParts", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "eventSource", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "autoSelect", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "markDisabled", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "locale", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "dateFormatter", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "dir", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "scrollToHour", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "preserveScrollPosition", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "lockSwipeToPrev", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "lockSwipes", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "startHour", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "endHour", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "sliderOptions", void 0);
        __decorate([
            core.Input()
        ], WeekViewComponent.prototype, "hourSegments", void 0);
        __decorate([
            core.Output()
        ], WeekViewComponent.prototype, "onRangeChanged", void 0);
        __decorate([
            core.Output()
        ], WeekViewComponent.prototype, "onEventSelected", void 0);
        __decorate([
            core.Output()
        ], WeekViewComponent.prototype, "onTimeSelected", void 0);
        __decorate([
            core.Output()
        ], WeekViewComponent.prototype, "onDayHeaderSelected", void 0);
        __decorate([
            core.Output()
        ], WeekViewComponent.prototype, "onTitleChanged", void 0);
        WeekViewComponent = WeekViewComponent_1 = __decorate([
            core.Component({
                selector: 'weekview',
                template: "\n        <ion-slides #weekSlider [options]=\"sliderOptions\" [dir]=\"dir\" (ionSlideDidChange)=\"onSlideChanged()\"\n                    class=\"slides-container\">\n            <ion-slide class=\"slide-container\">\n                <table class=\"table table-bordered table-fixed weekview-header\">\n                    <thead>\n                    <tr>\n                        <th class=\"calendar-hour-column\"></th>\n                        <th class=\"weekview-header text-center\" *ngFor=\"let date of views[0].dates\"\n                            [ngClass]=\"getHighlightClass(date)\"\n                            (click)=\"daySelected(date)\">\n                            <ng-template [ngTemplateOutlet]=\"weekviewHeaderTemplate\"\n                                         [ngTemplateOutletContext]=\"{viewDate:date}\">\n                            </ng-template>\n                        </th>\n                    </tr>\n                    </thead>\n                </table>\n                <div *ngIf=\"0===currentViewIndex\">\n                    <div class=\"weekview-allday-table\">\n                        <div class=\"weekview-allday-label\">{{allDayLabel}}</div>\n                        <div class=\"weekview-allday-content-wrapper scroll-content\">\n                            <table class=\"table table-fixed weekview-allday-content-table\">\n                                <tbody>\n                                <tr>\n                                    <td *ngFor=\"let day of views[0].dates\" class=\"calendar-cell\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewAllDayEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{day:day, eventTemplate:weekviewAllDayEventTemplate}\">\n                                        </ng-template>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                    <init-position-scroll class=\"weekview-normal-event-container\" [initPosition]=\"initScrollPosition\"\n                                          [emitEvent]=\"preserveScrollPosition\" (onScroll)=\"setScrollPosition($event)\">\n                        <table class=\"table table-bordered table-fixed weekview-normal-event-table\">\n                            <tbody>\n                            <tr *ngFor=\"let row of views[0].rows; let i = index\">\n                                <td class=\"calendar-hour-column text-center\">\n                                    {{hourColumnLabels[i]}}\n                                </td>\n                                <td *ngFor=\"let tm of row\" class=\"calendar-cell\" tappable\n                                    (click)=\"select(tm.time, tm.events)\">\n                                    <ng-template [ngTemplateOutlet]=\"weekviewNormalEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts, eventTemplate:weekviewNormalEventTemplate}\">\n                                    </ng-template>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </init-position-scroll>\n                </div>\n                <div *ngIf=\"0!==currentViewIndex\">\n                    <div class=\"weekview-allday-table\">\n                        <div class=\"weekview-allday-label\">{{allDayLabel}}</div>\n                        <div class=\"weekview-allday-content-wrapper scroll-content\">\n                            <table class=\"table table-fixed weekview-allday-content-table\">\n                                <tbody>\n                                <tr>\n                                    <td *ngFor=\"let day of views[0].dates\" class=\"calendar-cell\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewInactiveAllDayEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{day:day}\">\n                                        </ng-template>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                    <init-position-scroll class=\"weekview-normal-event-container\" [initPosition]=\"initScrollPosition\">\n                        <table class=\"table table-bordered table-fixed weekview-normal-event-table\">\n                            <tbody>\n                            <tr *ngFor=\"let row of views[0].rows; let i = index\">\n                                <td class=\"calendar-hour-column text-center\">\n                                    {{hourColumnLabels[i]}}\n                                </td>\n                                <td *ngFor=\"let tm of row\" class=\"calendar-cell\">\n                                    <ng-template [ngTemplateOutlet]=\"weekviewInactiveNormalEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts}\">\n                                    </ng-template>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </init-position-scroll>\n                </div>\n            </ion-slide>\n            <ion-slide class=\"slide-container\">\n                <table class=\"table table-bordered table-fixed weekview-header\">\n                    <thead>\n                    <tr>\n                        <th class=\"calendar-hour-column\"></th>\n                        <th class=\"weekview-header text-center\" *ngFor=\"let date of views[1].dates\"\n                            [ngClass]=\"getHighlightClass(date)\"\n                            (click)=\"daySelected(date)\">\n                            <ng-template [ngTemplateOutlet]=\"weekviewHeaderTemplate\"\n                                         [ngTemplateOutletContext]=\"{viewDate:date}\">\n                            </ng-template>\n                        </th>\n                    </tr>\n                    </thead>\n                </table>\n                <div *ngIf=\"1===currentViewIndex\">\n                    <div class=\"weekview-allday-table\">\n                        <div class=\"weekview-allday-label\">{{allDayLabel}}</div>\n                        <div class=\"weekview-allday-content-wrapper scroll-content\">\n                            <table class=\"table table-fixed weekview-allday-content-table\">\n                                <tbody>\n                                <tr>\n                                    <td *ngFor=\"let day of views[1].dates\" class=\"calendar-cell\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewAllDayEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{day:day, eventTemplate:weekviewAllDayEventTemplate}\">\n                                        </ng-template>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                    <init-position-scroll class=\"weekview-normal-event-container\" [initPosition]=\"initScrollPosition\"\n                                          [emitEvent]=\"preserveScrollPosition\" (onScroll)=\"setScrollPosition($event)\">\n                        <table class=\"table table-bordered table-fixed weekview-normal-event-table\">\n                            <tbody>\n                            <tr *ngFor=\"let row of views[1].rows; let i = index\">\n                                <td class=\"calendar-hour-column text-center\">\n                                    {{hourColumnLabels[i]}}\n                                </td>\n                                <td *ngFor=\"let tm of row\" class=\"calendar-cell\" tappable\n                                    (click)=\"select(tm.time, tm.events)\">\n                                    <div [ngClass]=\"{'calendar-event-wrap': tm.events}\" *ngIf=\"tm.events\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewNormalEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts, eventTemplate:weekviewNormalEventTemplate}\">\n                                        </ng-template>\n                                    </div>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </init-position-scroll>\n                </div>\n                <div *ngIf=\"1!==currentViewIndex\">\n                    <div class=\"weekview-allday-table\">\n                        <div class=\"weekview-allday-label\">{{allDayLabel}}</div>\n                        <div class=\"weekview-allday-content-wrapper scroll-content\">\n                            <table class=\"table table-fixed weekview-allday-content-table\">\n                                <tbody>\n                                <tr>\n                                    <td *ngFor=\"let day of views[1].dates\" class=\"calendar-cell\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewInactiveAllDayEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{day:day}\">\n                                        </ng-template>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                    <init-position-scroll class=\"weekview-normal-event-container\" [initPosition]=\"initScrollPosition\">\n                        <table class=\"table table-bordered table-fixed weekview-normal-event-table\">\n                            <tbody>\n                            <tr *ngFor=\"let row of views[1].rows; let i = index\">\n                                <td class=\"calendar-hour-column text-center\">\n                                    {{hourColumnLabels[i]}}\n                                </td>\n                                <td *ngFor=\"let tm of row\" class=\"calendar-cell\">\n                                    <div [ngClass]=\"{'calendar-event-wrap': tm.events}\" *ngIf=\"tm.events\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewInactiveNormalEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts}\">\n                                        </ng-template>\n                                    </div>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </init-position-scroll>\n                </div>\n            </ion-slide>\n            <ion-slide class=\"slide-container\">\n                <table class=\"table table-bordered table-fixed weekview-header\">\n                    <thead>\n                    <tr>\n                        <th class=\"calendar-hour-column\"></th>\n                        <th class=\"weekview-header text-center\" *ngFor=\"let date of views[2].dates\"\n                            [ngClass]=\"getHighlightClass(date)\"\n                            (click)=\"daySelected(date)\">\n                            <ng-template [ngTemplateOutlet]=\"weekviewHeaderTemplate\"\n                                         [ngTemplateOutletContext]=\"{viewDate:date}\">\n                            </ng-template>\n                        </th>\n                    </tr>\n                    </thead>\n                </table>\n                <div *ngIf=\"2===currentViewIndex\">\n                    <div class=\"weekview-allday-table\">\n                        <div class=\"weekview-allday-label\">{{allDayLabel}}</div>\n                        <div class=\"weekview-allday-content-wrapper scroll-content\">\n                            <table class=\"table table-fixed weekview-allday-content-table\">\n                                <tbody>\n                                <tr>\n                                    <td *ngFor=\"let day of views[2].dates\" class=\"calendar-cell\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewAllDayEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{day:day, eventTemplate:weekviewAllDayEventTemplate}\">\n                                        </ng-template>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                    <init-position-scroll class=\"weekview-normal-event-container\" [initPosition]=\"initScrollPosition\"\n                                          [emitEvent]=\"preserveScrollPosition\" (onScroll)=\"setScrollPosition($event)\">\n                        <table class=\"table table-bordered table-fixed weekview-normal-event-table\">\n                            <tbody>\n                            <tr *ngFor=\"let row of views[2].rows; let i = index\">\n                                <td class=\"calendar-hour-column text-center\">\n                                    {{hourColumnLabels[i]}}\n                                </td>\n                                <td *ngFor=\"let tm of row\" class=\"calendar-cell\" tappable\n                                    (click)=\"select(tm.time, tm.events)\">\n                                    <div [ngClass]=\"{'calendar-event-wrap': tm.events}\" *ngIf=\"tm.events\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewNormalEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts, eventTemplate:weekviewNormalEventTemplate}\">\n                                        </ng-template>\n                                    </div>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </init-position-scroll>\n                </div>\n                <div *ngIf=\"2!==currentViewIndex\">\n                    <div class=\"weekview-allday-table\">\n                        <div class=\"weekview-allday-label\">{{allDayLabel}}</div>\n                        <div class=\"weekview-allday-content-wrapper scroll-content\">\n                            <table class=\"table table-fixed weekview-allday-content-table\">\n                                <tbody>\n                                <tr>\n                                    <td *ngFor=\"let day of views[2].dates\" class=\"calendar-cell\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewInactiveAllDayEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{day:day}\">\n                                        </ng-template>\n                                    </td>\n                                </tr>\n                                </tbody>\n                            </table>\n                        </div>\n                    </div>\n                    <init-position-scroll class=\"weekview-normal-event-container\" [initPosition]=\"initScrollPosition\">\n                        <table class=\"table table-bordered table-fixed weekview-normal-event-table\">\n                            <tbody>\n                            <tr *ngFor=\"let row of views[2].rows; let i = index\">\n                                <td class=\"calendar-hour-column text-center\">\n                                    {{hourColumnLabels[i]}}\n                                </td>\n                                <td *ngFor=\"let tm of row\" class=\"calendar-cell\">\n                                    <div [ngClass]=\"{'calendar-event-wrap': tm.events}\" *ngIf=\"tm.events\">\n                                        <ng-template [ngTemplateOutlet]=\"weekviewInactiveNormalEventSectionTemplate\"\n                                                     [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts}\">\n                                        </ng-template>\n                                    </div>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </init-position-scroll>\n                </div>\n            </ion-slide>\n        </ion-slides>\n    ",
                encapsulation: core.ViewEncapsulation.None,
                styles: ["\n        .table-fixed {\n            table-layout: fixed;\n        }\n\n        .table {\n            width: 100%;\n            max-width: 100%;\n            background-color: transparent;\n        }\n\n        .table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td,\n        .table > tbody > tr > td, .table > tfoot > tr > td {\n            padding: 8px;\n            line-height: 20px;\n            vertical-align: top;\n        }\n\n        .table > thead > tr > th {\n            vertical-align: bottom;\n            border-bottom: 2px solid #ddd;\n        }\n\n        .table > thead:first-child > tr:first-child > th, .table > thead:first-child > tr:first-child > td {\n            border-top: 0\n        }\n\n        .table > tbody + tbody {\n            border-top: 2px solid #ddd;\n        }\n\n        .table-bordered {\n            border: 1px solid #ddd;\n        }\n\n        .table-bordered > thead > tr > th, .table-bordered > tbody > tr > th, .table-bordered > tfoot > tr > th,\n        .table-bordered > thead > tr > td, .table-bordered > tbody > tr > td, .table-bordered > tfoot > tr > td {\n            border: 1px solid #ddd;\n        }\n\n        .table-bordered > thead > tr > th, .table-bordered > thead > tr > td {\n            border-bottom-width: 2px;\n        }\n\n        .table-striped > tbody > tr:nth-child(odd) > td, .table-striped > tbody > tr:nth-child(odd) > th {\n            background-color: #f9f9f9\n        }\n\n        .calendar-hour-column {\n            width: 50px;\n            white-space: nowrap;\n        }\n\n        .calendar-event-wrap {\n            position: relative;\n            width: 100%;\n            height: 100%;\n        }\n\n        .calendar-event {\n            position: absolute;\n            padding: 2px;\n            cursor: pointer;\n            z-index: 10000;\n        }\n\n        .calendar-cell {\n            padding: 0 !important;\n            height: 37px;\n        }\n\n        .slides-container {\n            height: 100%;\n        }\n\n        .slide-container {\n            display: block;\n        }\n\n        .weekview-allday-label {\n            float: left;\n            height: 100%;\n            line-height: 50px;\n            text-align: center;\n            width: 50px;\n            border-left: 1px solid #ddd;\n        }\n\n        [dir=\"rtl\"] .weekview-allday-label {\n            float: right;\n            border-right: 1px solid #ddd;\n        }\n\n        .weekview-allday-content-wrapper {\n            margin-left: 50px;\n            overflow: hidden;\n            height: 51px;\n        }\n\n        [dir=\"rtl\"] .weekview-allday-content-wrapper {\n            margin-left: 0;\n            margin-right: 50px;\n        }\n\n        .weekview-allday-content-table {\n            min-height: 50px;\n        }\n\n        .weekview-allday-content-table td {\n            border-left: 1px solid #ddd;\n            border-right: 1px solid #ddd;\n        }\n\n        .weekview-header th {\n            overflow: hidden;\n            white-space: nowrap;\n            font-size: 14px;\n        }\n\n        .weekview-allday-table {\n            height: 50px;\n            position: relative;\n            border-bottom: 1px solid #ddd;\n            font-size: 14px;\n        }\n\n        .weekview-normal-event-container {\n            margin-top: 87px;\n            overflow: hidden;\n            left: 0;\n            right: 0;\n            top: 0;\n            bottom: 0;\n            position: absolute;\n            font-size: 14px;\n        }\n\n        .scroll-content {\n            overflow-y: auto;\n            overflow-x: hidden;\n        }\n\n        ::-webkit-scrollbar,\n        *::-webkit-scrollbar {\n            display: none;\n        }\n\n        .table > tbody > tr > td.calendar-hour-column {\n            padding-left: 0;\n            padding-right: 0;\n            vertical-align: middle;\n        }\n\n        @media (max-width: 750px) {\n            .weekview-allday-label, .calendar-hour-column {\n                width: 31px;\n                font-size: 12px;\n            }\n\n            .weekview-allday-label {\n                padding-top: 4px;\n            }\n\n            .table > tbody > tr > td.calendar-hour-column {\n                padding-left: 0;\n                padding-right: 0;\n                vertical-align: middle;\n                line-height: 12px;\n            }\n\n            .table > thead > tr > th.weekview-header {\n                padding-left: 0;\n                padding-right: 0;\n                font-size: 12px;\n            }\n\n            .weekview-allday-label {\n                line-height: 20px;\n            }\n\n            .weekview-allday-content-wrapper {\n                margin-left: 31px;\n            }\n\n            [dir=\"rtl\"] .weekview-allday-content-wrapper {\n                margin-left: 0;\n                margin-right: 31px;\n            }\n        }\n    "]
            })
        ], WeekViewComponent);
        return WeekViewComponent;
    }());

    var DayViewComponent = /** @class */ (function () {
        function DayViewComponent(calendarService, elm) {
            this.calendarService = calendarService;
            this.elm = elm;
            this.class = true;
            this.dir = '';
            this.scrollToHour = 0;
            this.onRangeChanged = new core.EventEmitter();
            this.onEventSelected = new core.EventEmitter();
            this.onTimeSelected = new core.EventEmitter();
            this.onTitleChanged = new core.EventEmitter(true);
            this.views = [];
            this.currentViewIndex = 0;
            this.direction = 0;
            this.mode = 'day';
            this.inited = false;
            this.callbackOnInit = true;
        }
        DayViewComponent_1 = DayViewComponent;
        DayViewComponent.createDateObjects = function (startTime, startHour, endHour, timeInterval) {
            var rows = [], currentHour = 0, currentDate = startTime.getDate();
            var time, hourStep, minStep;
            if (timeInterval < 1) {
                hourStep = Math.floor(1 / timeInterval);
                minStep = 60;
            }
            else {
                hourStep = 1;
                minStep = Math.floor(60 / timeInterval);
            }
            for (var hour = startHour; hour < endHour; hour += hourStep) {
                for (var interval = 0; interval < 60; interval += minStep) {
                    time = new Date(startTime.getTime());
                    time.setHours(currentHour + hour, interval);
                    time.setDate(currentDate);
                    rows.push({
                        time: time,
                        events: []
                    });
                }
            }
            return rows;
        };
        DayViewComponent.compareEventByStartOffset = function (eventA, eventB) {
            return eventA.startOffset - eventB.startOffset;
        };
        DayViewComponent.calculateWidth = function (orderedEvents, size, hourParts) {
            var totalSize = size * hourParts, cells = new Array(totalSize);
            // sort by position in descending order, the right most columns should be calculated first
            orderedEvents.sort(function (eventA, eventB) {
                return eventB.position - eventA.position;
            });
            for (var i_1 = 0; i_1 < totalSize; i_1 += 1) {
                cells[i_1] = {
                    calculated: false,
                    events: []
                };
            }
            var len = orderedEvents.length;
            for (var i_2 = 0; i_2 < len; i_2 += 1) {
                var event_1 = orderedEvents[i_2];
                var index = event_1.startIndex * hourParts + event_1.startOffset;
                while (index < event_1.endIndex * hourParts - event_1.endOffset) {
                    cells[index].events.push(event_1);
                    index += 1;
                }
            }
            var i = 0;
            while (i < len) {
                var event_2 = orderedEvents[i];
                if (!event_2.overlapNumber) {
                    var overlapNumber = event_2.position + 1;
                    event_2.overlapNumber = overlapNumber;
                    var eventQueue = [event_2];
                    while (event_2 = eventQueue.shift()) {
                        var index = event_2.startIndex * hourParts + event_2.startOffset;
                        while (index < event_2.endIndex * hourParts - event_2.endOffset) {
                            if (!cells[index].calculated) {
                                cells[index].calculated = true;
                                if (cells[index].events) {
                                    var eventCountInCell = cells[index].events.length;
                                    for (var j = 0; j < eventCountInCell; j += 1) {
                                        var currentEventInCell = cells[index].events[j];
                                        if (!currentEventInCell.overlapNumber) {
                                            currentEventInCell.overlapNumber = overlapNumber;
                                            eventQueue.push(currentEventInCell);
                                        }
                                    }
                                }
                            }
                            index += 1;
                        }
                    }
                }
                i += 1;
            }
        };
        DayViewComponent.prototype.ngOnInit = function () {
            var _this = this;
            if (!this.sliderOptions) {
                this.sliderOptions = {};
            }
            this.sliderOptions.loop = true;
            this.hourRange = (this.endHour - this.startHour) * this.hourSegments;
            if (this.dateFormatter && this.dateFormatter.formatDayViewTitle) {
                this.formatTitle = this.dateFormatter.formatDayViewTitle;
            }
            else {
                var datePipe_1 = new common.DatePipe(this.locale);
                this.formatTitle = function (date) {
                    return datePipe_1.transform(date, this.formatDayTitle);
                };
            }
            if (this.dateFormatter && this.dateFormatter.formatDayViewHourColumn) {
                this.formatHourColumnLabel = this.dateFormatter.formatDayViewHourColumn;
            }
            else {
                var datePipe_2 = new common.DatePipe(this.locale);
                this.formatHourColumnLabel = function (date) {
                    return datePipe_2.transform(date, this.formatHourColumn);
                };
            }
            if (this.lockSwipeToPrev) {
                this.slider.lockSwipeToPrev(true);
            }
            if (this.lockSwipes) {
                this.slider.lockSwipes(true);
            }
            this.refreshView();
            this.hourColumnLabels = this.getHourColumnLabels();
            this.inited = true;
            this.currentDateChangedFromParentSubscription = this.calendarService.currentDateChangedFromParent$.subscribe(function (currentDate) {
                _this.refreshView();
            });
            this.eventSourceChangedSubscription = this.calendarService.eventSourceChanged$.subscribe(function () {
                _this.onDataLoaded();
            });
            this.slideChangedSubscription = this.calendarService.slideChanged$.subscribe(function (direction) {
                if (direction === 1) {
                    _this.slider.slideNext();
                }
                else if (direction === -1) {
                    _this.slider.slidePrev();
                }
            });
            this.slideUpdatedSubscription = this.calendarService.slideUpdated$.subscribe(function () {
                _this.slider.update();
            });
        };
        DayViewComponent.prototype.ngAfterViewInit = function () {
            var title = this.getTitle();
            this.onTitleChanged.emit(title);
            if (this.scrollToHour > 0) {
                var hourColumns_1 = this.elm.nativeElement.querySelector('.dayview-normal-event-container').querySelectorAll('.calendar-hour-column');
                var me_1 = this;
                setTimeout(function () {
                    me_1.initScrollPosition = hourColumns_1[me_1.scrollToHour - me_1.startHour].offsetTop;
                }, 50);
            }
        };
        DayViewComponent.prototype.ngOnChanges = function (changes) {
            if (!this.inited) {
                return;
            }
            if ((changes.startHour || changes.endHour) && (!changes.startHour.isFirstChange() || !changes.endHour.isFirstChange())) {
                this.views = undefined;
                this.hourRange = (this.endHour - this.startHour) * this.hourSegments;
                this.direction = 0;
                this.refreshView();
                this.hourColumnLabels = this.getHourColumnLabels();
            }
            var eventSourceChange = changes.eventSource;
            if (eventSourceChange && eventSourceChange.currentValue) {
                this.onDataLoaded();
            }
            var lockSwipeToPrev = changes.lockSwipeToPrev;
            if (lockSwipeToPrev) {
                this.slider.lockSwipeToPrev(lockSwipeToPrev.currentValue);
            }
            var lockSwipes = changes.lockSwipes;
            if (lockSwipes) {
                this.slider.lockSwipes(lockSwipes.currentValue);
            }
        };
        DayViewComponent.prototype.ngOnDestroy = function () {
            if (this.currentDateChangedFromParentSubscription) {
                this.currentDateChangedFromParentSubscription.unsubscribe();
                this.currentDateChangedFromParentSubscription = null;
            }
            if (this.eventSourceChangedSubscription) {
                this.eventSourceChangedSubscription.unsubscribe();
                this.eventSourceChangedSubscription = null;
            }
            if (this.slideChangedSubscription) {
                this.slideChangedSubscription.unsubscribe();
                this.slideChangedSubscription = null;
            }
            if (this.slideUpdatedSubscription) {
                this.slideUpdatedSubscription.unsubscribe();
                this.slideUpdatedSubscription = null;
            }
        };
        DayViewComponent.prototype.onSlideChanged = function () {
            var _this = this;
            if (this.callbackOnInit) {
                this.callbackOnInit = false;
                return;
            }
            var direction = 0;
            var currentViewIndex = this.currentViewIndex;
            this.slider.getActiveIndex().then(function (currentSlideIndex) {
                currentSlideIndex = (currentSlideIndex + 2) % 3;
                if (isNaN(currentSlideIndex)) {
                    currentSlideIndex = currentViewIndex;
                }
                if (currentSlideIndex - currentViewIndex === 1) {
                    direction = 1;
                }
                else if (currentSlideIndex === 0 && currentViewIndex === 2) {
                    direction = 1;
                    _this.slider.slideTo(1, 0, false);
                }
                else if (currentViewIndex - currentSlideIndex === 1) {
                    direction = -1;
                }
                else if (currentSlideIndex === 2 && currentViewIndex === 0) {
                    direction = -1;
                    _this.slider.slideTo(3, 0, false);
                }
                _this.currentViewIndex = currentSlideIndex;
                _this.move(direction);
            });
        };
        DayViewComponent.prototype.move = function (direction) {
            if (direction === 0) {
                return;
            }
            this.direction = direction;
            var adjacentDate = this.calendarService.getAdjacentCalendarDate(this.mode, direction);
            this.calendarService.setCurrentDate(adjacentDate);
            this.refreshView();
            this.direction = 0;
        };
        DayViewComponent.prototype.getHourColumnLabels = function () {
            var hourColumnLabels = [];
            for (var hour = 0, length_1 = this.views[0].rows.length; hour < length_1; hour += 1) {
                // handle edge case for DST
                if (hour === 0 && this.views[0].rows[hour].time.getHours() !== this.startHour) {
                    var time = new Date(this.views[0].rows[hour].time);
                    time.setDate(time.getDate() + 1);
                    time.setHours(this.startHour);
                    hourColumnLabels.push(this.formatHourColumnLabel(time));
                }
                else {
                    hourColumnLabels.push(this.formatHourColumnLabel(this.views[0].rows[hour].time));
                }
            }
            return hourColumnLabels;
        };
        DayViewComponent.prototype.getViewData = function (startTime) {
            return {
                rows: DayViewComponent_1.createDateObjects(startTime, this.startHour, this.endHour, this.hourSegments),
                allDayEvents: []
            };
        };
        DayViewComponent.prototype.getRange = function (currentDate) {
            var year = currentDate.getFullYear(), month = currentDate.getMonth(), date = currentDate.getDate(), startTime = new Date(year, month, date, 12, 0, 0), endTime = new Date(year, month, date + 1, 12, 0, 0);
            return {
                startTime: startTime,
                endTime: endTime
            };
        };
        DayViewComponent.prototype.onDataLoaded = function () {
            var eventSource = this.eventSource, len = eventSource ? eventSource.length : 0, startTime = this.range.startTime, endTime = this.range.endTime, utcStartTime = Date.UTC(startTime.getFullYear(), startTime.getMonth(), startTime.getDate()), utcEndTime = Date.UTC(endTime.getFullYear(), endTime.getMonth(), endTime.getDate()), currentViewIndex = this.currentViewIndex, rows = this.views[currentViewIndex].rows, allDayEvents = this.views[currentViewIndex].allDayEvents = [], oneHour = 3600000, eps = 0.016, rangeStartRowIndex = this.startHour * this.hourSegments, rangeEndRowIndex = this.endHour * this.hourSegments;
            var normalEventInRange = false;
            for (var hour = 0; hour < this.hourRange; hour += 1) {
                rows[hour].events = [];
            }
            for (var i = 0; i < len; i += 1) {
                var event_3 = eventSource[i];
                var eventStartTime = event_3.startTime;
                var eventEndTime = event_3.endTime;
                var eventUTCStartTime = void 0, eventUTCEndTime = void 0;
                if (event_3.allDay) {
                    eventUTCStartTime = eventStartTime.getTime();
                    eventUTCEndTime = eventEndTime.getTime();
                }
                else {
                    eventUTCStartTime = Date.UTC(eventStartTime.getFullYear(), eventStartTime.getMonth(), eventStartTime.getDate());
                    eventUTCEndTime = Date.UTC(eventEndTime.getFullYear(), eventEndTime.getMonth(), eventEndTime.getDate() + 1);
                }
                if (eventUTCEndTime <= utcStartTime || eventUTCStartTime >= utcEndTime || eventStartTime >= eventEndTime) {
                    continue;
                }
                if (event_3.allDay) {
                    allDayEvents.push({
                        event: event_3
                    });
                }
                else {
                    normalEventInRange = true;
                    var timeDifferenceStart = void 0;
                    if (eventUTCStartTime < utcStartTime) {
                        timeDifferenceStart = 0;
                    }
                    else {
                        timeDifferenceStart = (eventStartTime.getHours() + eventStartTime.getMinutes() / 60) * this.hourSegments;
                    }
                    var timeDifferenceEnd = void 0;
                    if (eventUTCEndTime > utcEndTime) {
                        timeDifferenceEnd = (utcEndTime - utcStartTime) / oneHour * this.hourSegments;
                    }
                    else {
                        timeDifferenceEnd = (eventEndTime.getHours() + eventEndTime.getMinutes() / 60) * this.hourSegments;
                    }
                    var startIndex = Math.floor(timeDifferenceStart);
                    var endIndex = Math.ceil(timeDifferenceEnd - eps);
                    var startOffset = 0;
                    var endOffset = 0;
                    if (this.hourParts !== 1) {
                        if (startIndex < rangeStartRowIndex) {
                            startOffset = 0;
                        }
                        else {
                            startOffset = Math.floor((timeDifferenceStart - startIndex) * this.hourParts);
                        }
                        if (endIndex > rangeEndRowIndex) {
                            endOffset = 0;
                        }
                        else {
                            endOffset = Math.floor((endIndex - timeDifferenceEnd) * this.hourParts);
                        }
                    }
                    if (startIndex < rangeStartRowIndex) {
                        startIndex = 0;
                    }
                    else {
                        startIndex -= rangeStartRowIndex;
                    }
                    if (endIndex > rangeEndRowIndex) {
                        endIndex = rangeEndRowIndex;
                    }
                    endIndex -= rangeStartRowIndex;
                    if (startIndex < endIndex) {
                        var displayEvent = {
                            event: event_3,
                            startIndex: startIndex,
                            endIndex: endIndex,
                            startOffset: startOffset,
                            endOffset: endOffset
                        };
                        var eventSet = rows[startIndex].events;
                        if (eventSet) {
                            eventSet.push(displayEvent);
                        }
                        else {
                            eventSet = [];
                            eventSet.push(displayEvent);
                            rows[startIndex].events = eventSet;
                        }
                    }
                }
            }
            if (normalEventInRange) {
                var orderedEvents = [];
                for (var hour = 0; hour < this.hourRange; hour += 1) {
                    if (rows[hour].events) {
                        rows[hour].events.sort(DayViewComponent_1.compareEventByStartOffset);
                        orderedEvents = orderedEvents.concat(rows[hour].events);
                    }
                }
                if (orderedEvents.length > 0) {
                    this.placeEvents(orderedEvents);
                }
            }
        };
        DayViewComponent.prototype.refreshView = function () {
            this.range = this.getRange(this.calendarService.currentDate);
            if (this.inited) {
                var title = this.getTitle();
                this.onTitleChanged.emit(title);
            }
            this.calendarService.populateAdjacentViews(this);
            this.calendarService.rangeChanged(this);
        };
        DayViewComponent.prototype.getTitle = function () {
            var startingDate = new Date(this.range.startTime.getTime());
            startingDate.setHours(12, 0, 0, 0);
            return this.formatTitle(startingDate);
        };
        DayViewComponent.prototype.select = function (selectedTime, events) {
            var disabled = false;
            if (this.markDisabled) {
                disabled = this.markDisabled(selectedTime);
            }
            this.onTimeSelected.emit({
                selectedTime: selectedTime,
                events: events.map(function (e) { return e.event; }),
                disabled: disabled
            });
        };
        DayViewComponent.prototype.placeEvents = function (orderedEvents) {
            this.calculatePosition(orderedEvents);
            DayViewComponent_1.calculateWidth(orderedEvents, this.hourRange, this.hourParts);
        };
        DayViewComponent.prototype.placeAllDayEvents = function (orderedEvents) {
            this.calculatePosition(orderedEvents);
        };
        DayViewComponent.prototype.overlap = function (event1, event2) {
            var earlyEvent = event1, lateEvent = event2;
            if (event1.startIndex > event2.startIndex || (event1.startIndex === event2.startIndex && event1.startOffset > event2.startOffset)) {
                earlyEvent = event2;
                lateEvent = event1;
            }
            if (earlyEvent.endIndex <= lateEvent.startIndex) {
                return false;
            }
            else {
                return !(earlyEvent.endIndex - lateEvent.startIndex === 1 && earlyEvent.endOffset + lateEvent.startOffset >= this.hourParts);
            }
        };
        DayViewComponent.prototype.calculatePosition = function (events) {
            var len = events.length, isForbidden = new Array(len);
            var maxColumn = 0, col;
            for (var i = 0; i < len; i += 1) {
                for (col = 0; col < maxColumn; col += 1) {
                    isForbidden[col] = false;
                }
                for (var j = 0; j < i; j += 1) {
                    if (this.overlap(events[i], events[j])) {
                        isForbidden[events[j].position] = true;
                    }
                }
                for (col = 0; col < maxColumn; col += 1) {
                    if (!isForbidden[col]) {
                        break;
                    }
                }
                if (col < maxColumn) {
                    events[i].position = col;
                }
                else {
                    events[i].position = maxColumn++;
                }
            }
            if (this.dir === 'rtl') {
                for (var i = 0; i < len; i += 1) {
                    events[i].position = maxColumn - 1 - events[i].position;
                }
            }
        };
        DayViewComponent.prototype.eventSelected = function (event) {
            this.onEventSelected.emit(event);
        };
        DayViewComponent.prototype.setScrollPosition = function (scrollPosition) {
            this.initScrollPosition = scrollPosition;
        };
        var DayViewComponent_1;
        DayViewComponent.ctorParameters = function () { return [
            { type: CalendarService },
            { type: core.ElementRef }
        ]; };
        __decorate([
            core.ViewChild('daySlider', { static: true })
        ], DayViewComponent.prototype, "slider", void 0);
        __decorate([
            core.HostBinding('class.dayview')
        ], DayViewComponent.prototype, "class", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "dayviewAllDayEventTemplate", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "dayviewNormalEventTemplate", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "dayviewAllDayEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "dayviewNormalEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "dayviewInactiveAllDayEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "dayviewInactiveNormalEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "formatHourColumn", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "formatDayTitle", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "allDayLabel", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "hourParts", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "eventSource", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "markDisabled", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "locale", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "dateFormatter", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "dir", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "scrollToHour", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "preserveScrollPosition", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "lockSwipeToPrev", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "lockSwipes", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "startHour", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "endHour", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "sliderOptions", void 0);
        __decorate([
            core.Input()
        ], DayViewComponent.prototype, "hourSegments", void 0);
        __decorate([
            core.Output()
        ], DayViewComponent.prototype, "onRangeChanged", void 0);
        __decorate([
            core.Output()
        ], DayViewComponent.prototype, "onEventSelected", void 0);
        __decorate([
            core.Output()
        ], DayViewComponent.prototype, "onTimeSelected", void 0);
        __decorate([
            core.Output()
        ], DayViewComponent.prototype, "onTitleChanged", void 0);
        DayViewComponent = DayViewComponent_1 = __decorate([
            core.Component({
                selector: 'dayview',
                template: "\n        <ion-slides #daySlider [options]=\"sliderOptions\" [dir]=\"dir\" (ionSlideDidChange)=\"onSlideChanged()\" class=\"slides-container\">\n            <ion-slide class=\"slide-container\">\n                <div class=\"dayview-allday-table\">\n                    <div class=\"dayview-allday-label\">{{allDayLabel}}</div>\n                    <div class=\"dayview-allday-content-wrapper scroll-content\">\n                        <table class=\"table table-bordered dayview-allday-content-table\">\n                            <tbody>\n                            <tr>\n                                <td class=\"calendar-cell\" [ngClass]=\"{'calendar-event-wrap':views[0].allDayEvents.length>0}\"\n                                    [ngStyle]=\"{height: 25*views[0].allDayEvents.length+'px'}\"\n                                    *ngIf=\"0===currentViewIndex\">\n                                    <ng-template [ngTemplateOutlet]=\"dayviewAllDayEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{allDayEvents:views[0].allDayEvents,eventTemplate:dayviewAllDayEventTemplate}\">\n                                    </ng-template>\n                                </td>\n                                <td class=\"calendar-cell\" *ngIf=\"0!==currentViewIndex\">\n                                    <ng-template [ngTemplateOutlet]=\"dayviewInactiveAllDayEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{allDayEvents:views[0].allDayEvents}\">\n                                    </ng-template>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </div>\n                </div>\n                <init-position-scroll *ngIf=\"0===currentViewIndex\" class=\"dayview-normal-event-container\"\n                                      [initPosition]=\"initScrollPosition\" [emitEvent]=\"preserveScrollPosition\"\n                                      (onScroll)=\"setScrollPosition($event)\">\n                    <table class=\"table table-bordered table-fixed dayview-normal-event-table\">\n                        <tbody>\n                        <tr *ngFor=\"let tm of views[0].rows; let i = index\">\n                            <td class=\"calendar-hour-column text-center\">\n                                {{hourColumnLabels[i]}}\n                            </td>\n                            <td class=\"calendar-cell\" tappable (click)=\"select(tm.time, tm.events)\">\n                                <ng-template [ngTemplateOutlet]=\"dayviewNormalEventSectionTemplate\"\n                                             [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts, eventTemplate:dayviewNormalEventTemplate}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                </init-position-scroll>\n                <init-position-scroll *ngIf=\"0!==currentViewIndex\" class=\"dayview-normal-event-container\"\n                                      [initPosition]=\"initScrollPosition\">\n                    <table class=\"table table-bordered table-fixed dayview-normal-event-table\">\n                        <tbody>\n                        <tr *ngFor=\"let tm of views[0].rows; let i = index\">\n                            <td class=\"calendar-hour-column text-center\">\n                                {{hourColumnLabels[i]}}\n                            </td>\n                            <td class=\"calendar-cell\">\n                                <ng-template [ngTemplateOutlet]=\"dayviewInactiveNormalEventSectionTemplate\"\n                                             [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                </init-position-scroll>\n            </ion-slide>\n            <ion-slide class=\"slide-container\">\n                <div class=\"dayview-allday-table\">\n                    <div class=\"dayview-allday-label\">{{allDayLabel}}</div>\n                    <div class=\"dayview-allday-content-wrapper scroll-content\">\n                        <table class=\"table table-bordered dayview-allday-content-table\">\n                            <tbody>\n                            <tr>\n                                <td class=\"calendar-cell\" [ngClass]=\"{'calendar-event-wrap':views[1].allDayEvents.length>0}\"\n                                    [ngStyle]=\"{height: 25*views[1].allDayEvents.length+'px'}\"\n                                    *ngIf=\"1===currentViewIndex\">\n                                    <ng-template [ngTemplateOutlet]=\"dayviewAllDayEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{allDayEvents:views[1].allDayEvents,eventTemplate:dayviewAllDayEventTemplate}\">\n                                    </ng-template>\n                                </td>\n                                <td class=\"calendar-cell\" *ngIf=\"1!==currentViewIndex\">\n                                    <ng-template [ngTemplateOutlet]=\"dayviewInactiveAllDayEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{allDayEvents:views[1].allDayEvents}\">\n                                    </ng-template>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </div>\n                </div>\n                <init-position-scroll *ngIf=\"1===currentViewIndex\" class=\"dayview-normal-event-container\"\n                                      [initPosition]=\"initScrollPosition\" [emitEvent]=\"preserveScrollPosition\"\n                                      (onScroll)=\"setScrollPosition($event)\">\n                    <table class=\"table table-bordered table-fixed dayview-normal-event-table\">\n                        <tbody>\n                        <tr *ngFor=\"let tm of views[1].rows; let i = index\">\n                            <td class=\"calendar-hour-column text-center\">\n                                {{hourColumnLabels[i]}}\n                            </td>\n                            <td class=\"calendar-cell\" tappable (click)=\"select(tm.time, tm.events)\">\n                                <ng-template [ngTemplateOutlet]=\"dayviewNormalEventSectionTemplate\"\n                                             [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts, eventTemplate:dayviewNormalEventTemplate}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                </init-position-scroll>\n                <init-position-scroll *ngIf=\"1!==currentViewIndex\" class=\"dayview-normal-event-container\"\n                                      [initPosition]=\"initScrollPosition\">\n                    <table class=\"table table-bordered table-fixed dayview-normal-event-table\">\n                        <tbody>\n                        <tr *ngFor=\"let tm of views[1].rows; let i = index\">\n                            <td class=\"calendar-hour-column text-center\">\n                                {{hourColumnLabels[i]}}\n                            </td>\n                            <td class=\"calendar-cell\">\n                                <ng-template [ngTemplateOutlet]=\"dayviewInactiveNormalEventSectionTemplate\"\n                                             [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                </init-position-scroll>\n            </ion-slide>\n            <ion-slide class=\"slide-container\">\n                <div class=\"dayview-allday-table\">\n                    <div class=\"dayview-allday-label\">{{allDayLabel}}</div>\n                    <div class=\"dayview-allday-content-wrapper scroll-content\">\n                        <table class=\"table table-bordered dayview-allday-content-table\">\n                            <tbody>\n                            <tr>\n                                <td class=\"calendar-cell\" [ngClass]=\"{'calendar-event-wrap':views[2].allDayEvents.length>0}\"\n                                    [ngStyle]=\"{height: 25*views[2].allDayEvents.length+'px'}\"\n                                    *ngIf=\"2===currentViewIndex\">\n                                    <ng-template [ngTemplateOutlet]=\"dayviewAllDayEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{allDayEvents:views[2].allDayEvents,eventTemplate:dayviewAllDayEventTemplate}\">\n                                    </ng-template>\n                                </td>\n                                <td class=\"calendar-cell\" *ngIf=\"2!==currentViewIndex\">\n                                    <ng-template [ngTemplateOutlet]=\"dayviewInactiveAllDayEventSectionTemplate\"\n                                                 [ngTemplateOutletContext]=\"{allDayEvents:views[2].allDayEvents}\">\n                                    </ng-template>\n                                </td>\n                            </tr>\n                            </tbody>\n                        </table>\n                    </div>\n                </div>\n                <init-position-scroll *ngIf=\"2===currentViewIndex\" class=\"dayview-normal-event-container\"\n                                      [initPosition]=\"initScrollPosition\" [emitEvent]=\"preserveScrollPosition\"\n                                      (onScroll)=\"setScrollPosition($event)\">\n                    <table class=\"table table-bordered table-fixed dayview-normal-event-table\">\n                        <tbody>\n                        <tr *ngFor=\"let tm of views[2].rows; let i = index\">\n                            <td class=\"calendar-hour-column text-center\">\n                                {{hourColumnLabels[i]}}\n                            </td>\n                            <td class=\"calendar-cell\" tappable (click)=\"select(tm.time, tm.events)\">\n                                <ng-template [ngTemplateOutlet]=\"dayviewNormalEventSectionTemplate\"\n                                             [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts, eventTemplate:dayviewNormalEventTemplate}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                </init-position-scroll>\n                <init-position-scroll *ngIf=\"2!==currentViewIndex\" class=\"dayview-normal-event-container\"\n                                      [initPosition]=\"initScrollPosition\">\n                    <table class=\"table table-bordered table-fixed dayview-normal-event-table\">\n                        <tbody>\n                        <tr *ngFor=\"let tm of views[2].rows; let i = index\">\n                            <td class=\"calendar-hour-column text-center\">\n                                {{hourColumnLabels[i]}}\n                            </td>\n                            <td class=\"calendar-cell\">\n                                <ng-template [ngTemplateOutlet]=\"dayviewInactiveNormalEventSectionTemplate\"\n                                             [ngTemplateOutletContext]=\"{tm:tm, hourParts: hourParts}\">\n                                </ng-template>\n                            </td>\n                        </tr>\n                        </tbody>\n                    </table>\n                </init-position-scroll>\n            </ion-slide>\n        </ion-slides>\n    ",
                encapsulation: core.ViewEncapsulation.None,
                styles: ["\n        .table-fixed {\n            table-layout: fixed;\n        }\n\n        .table {\n            width: 100%;\n            max-width: 100%;\n            background-color: transparent;\n        }\n\n        .table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td,\n        .table > tbody > tr > td, .table > tfoot > tr > td {\n            padding: 8px;\n            line-height: 20px;\n            vertical-align: top;\n        }\n\n        .table > thead > tr > th {\n            vertical-align: bottom;\n            border-bottom: 2px solid #ddd;\n        }\n\n        .table > thead:first-child > tr:first-child > th, .table > thead:first-child > tr:first-child > td {\n            border-top: 0\n        }\n\n        .table > tbody + tbody {\n            border-top: 2px solid #ddd;\n        }\n\n        .table-bordered {\n            border: 1px solid #ddd;\n        }\n\n        .table-bordered > thead > tr > th, .table-bordered > tbody > tr > th, .table-bordered > tfoot > tr > th,\n        .table-bordered > thead > tr > td, .table-bordered > tbody > tr > td, .table-bordered > tfoot > tr > td {\n            border: 1px solid #ddd;\n        }\n\n        .table-bordered > thead > tr > th, .table-bordered > thead > tr > td {\n            border-bottom-width: 2px;\n        }\n\n        .table-striped > tbody > tr:nth-child(odd) > td, .table-striped > tbody > tr:nth-child(odd) > th {\n            background-color: #f9f9f9\n        }\n\n        .calendar-hour-column {\n            width: 50px;\n            white-space: nowrap;\n        }\n\n        .calendar-event-wrap {\n            position: relative;\n            width: 100%;\n            height: 100%;\n        }\n\n        .calendar-event {\n            position: absolute;\n            padding: 2px;\n            cursor: pointer;\n            z-index: 10000;\n        }\n\n        .slides-container {\n            height: 100%;\n        }\n\n        .slide-container {\n            display: block;\n        }\n\n        .calendar-cell {\n            padding: 0 !important;\n            height: 37px;\n        }\n\n        .dayview-allday-label {\n            float: left;\n            height: 100%;\n            line-height: 50px;\n            text-align: center;\n            width: 50px;\n            border-left: 1px solid #ddd;\n        }\n\n        [dir=\"rtl\"] .dayview-allday-label {\n            border-right: 1px solid #ddd;\n            float: right;\n        }\n\n        .dayview-allday-content-wrapper {\n            margin-left: 50px;\n            overflow: hidden;\n            height: 51px;\n        }\n\n        [dir=\"rtl\"] .dayview-allday-content-wrapper {\n            margin-left: 0;\n            margin-right: 50px;\n        }\n\n        .dayview-allday-content-table {\n            min-height: 50px;\n        }\n\n        .dayview-allday-content-table td {\n            border-left: 1px solid #ddd;\n            border-right: 1px solid #ddd;\n        }\n\n        .dayview-allday-table {\n            height: 50px;\n            position: relative;\n            border-bottom: 1px solid #ddd;\n            font-size: 14px;\n        }\n\n        .dayview-normal-event-container {\n            margin-top: 50px;\n            overflow: hidden;\n            left: 0;\n            right: 0;\n            top: 0;\n            bottom: 0;\n            position: absolute;\n            font-size: 14px;\n        }\n\n        .scroll-content {\n            overflow-y: auto;\n            overflow-x: hidden;\n        }\n\n        ::-webkit-scrollbar,\n        *::-webkit-scrollbar {\n            display: none;\n        }\n\n        .table > tbody > tr > td.calendar-hour-column {\n            padding-left: 0;\n            padding-right: 0;\n            vertical-align: middle;\n        }\n\n        @media (max-width: 750px) {\n            .dayview-allday-label, .calendar-hour-column {\n                width: 31px;\n                font-size: 12px;\n            }\n\n            .dayview-allday-label {\n                padding-top: 4px;\n            }\n\n            .table > tbody > tr > td.calendar-hour-column {\n                padding-left: 0;\n                padding-right: 0;\n                vertical-align: middle;\n                line-height: 12px;\n            }\n\n            .dayview-allday-label {\n                line-height: 20px;\n            }\n\n            .dayview-allday-content-wrapper {\n                margin-left: 31px;\n            }\n\n            [dir=\"rtl\"] .dayview-allday-content-wrapper {\n                margin-left: 0;\n                margin-right: 31px;\n            }\n        }\n    "]
            })
        ], DayViewComponent);
        return DayViewComponent;
    }());

    var Step;
    (function (Step) {
        Step[Step["QuarterHour"] = 15] = "QuarterHour";
        Step[Step["HalfHour"] = 30] = "HalfHour";
        Step[Step["Hour"] = 60] = "Hour";
    })(Step || (Step = {}));
    var CalendarComponent = /** @class */ (function () {
        function CalendarComponent(calendarService, appLocale) {
            this.calendarService = calendarService;
            this.appLocale = appLocale;
            this.eventSource = [];
            this.calendarMode = "month";
            this.formatDay = "d";
            this.formatDayHeader = "EEE";
            this.formatDayTitle = "MMMM dd, yyyy";
            this.formatWeekTitle = "MMMM yyyy, 'Week' w";
            this.formatMonthTitle = "MMMM yyyy";
            this.formatWeekViewDayHeader = "EEE d";
            this.formatHourColumn = "ha";
            this.showEventDetail = true;
            this.startingDayMonth = 0;
            this.startingDayWeek = 0;
            this.allDayLabel = "all day";
            this.noEventsLabel = "No Events";
            this.queryMode = "local";
            this.step = Step.Hour;
            this.timeInterval = 60;
            this.autoSelect = true;
            this.dir = "";
            this.scrollToHour = 0;
            this.preserveScrollPosition = false;
            this.lockSwipeToPrev = false;
            this.lockSwipes = false;
            this.locale = "";
            this.startHour = 0;
            this.endHour = 24;
            this.onCurrentDateChanged = new core.EventEmitter();
            this.onRangeChanged = new core.EventEmitter();
            this.onEventSelected = new core.EventEmitter();
            this.onTimeSelected = new core.EventEmitter();
            this.onDayHeaderSelected = new core.EventEmitter();
            this.onTitleChanged = new core.EventEmitter();
            this.hourParts = 1;
            this.hourSegments = 1;
            this.locale = appLocale;
        }
        Object.defineProperty(CalendarComponent.prototype, "currentDate", {
            get: function () {
                return this._currentDate;
            },
            set: function (val) {
                if (!val) {
                    val = new Date();
                }
                this._currentDate = val;
                this.calendarService.setInitialDate(val, true);
                this.onCurrentDateChanged.emit(this._currentDate);
            },
            enumerable: true,
            configurable: true
        });
        CalendarComponent.prototype.ngOnInit = function () {
            var _this = this;
            if (this.autoSelect) {
                if (this.autoSelect.toString() === "false") {
                    this.autoSelect = false;
                }
                else {
                    this.autoSelect = true;
                }
            }
            this.hourSegments = 60 / this.timeInterval;
            this.hourParts = 60 / this.step;
            if (this.hourParts <= this.hourSegments) {
                this.hourParts = 1;
            }
            else {
                this.hourParts = this.hourParts / this.hourSegments;
            }
            this.startHour = parseInt(this.startHour.toString());
            this.endHour = parseInt(this.endHour.toString());
            this.calendarService.queryMode = this.queryMode;
            this.currentDateChangedFromChildrenSubscription =
                this.calendarService.currentDateChangedFromChildren$.subscribe(function (currentDate) {
                    _this._currentDate = currentDate;
                    _this.onCurrentDateChanged.emit(currentDate);
                });
        };
        CalendarComponent.prototype.ngOnDestroy = function () {
            if (this.currentDateChangedFromChildrenSubscription) {
                this.currentDateChangedFromChildrenSubscription.unsubscribe();
                this.currentDateChangedFromChildrenSubscription = null;
            }
        };
        CalendarComponent.prototype.rangeChanged = function (range) {
            this.onRangeChanged.emit(range);
        };
        CalendarComponent.prototype.eventSelected = function (event) {
            this.onEventSelected.emit(event);
        };
        CalendarComponent.prototype.timeSelected = function (timeSelected) {
            this.onTimeSelected.emit(timeSelected);
        };
        CalendarComponent.prototype.daySelected = function (daySelected) {
            this.onDayHeaderSelected.emit(daySelected);
        };
        CalendarComponent.prototype.titleChanged = function (title) {
            this.onTitleChanged.emit(title);
        };
        CalendarComponent.prototype.loadEvents = function () {
            this.calendarService.loadEvents();
        };
        CalendarComponent.prototype.slideNext = function () {
            this.calendarService.slide(1);
        };
        CalendarComponent.prototype.slidePrev = function () {
            this.calendarService.slide(-1);
        };
        CalendarComponent.prototype.update = function () {
            this.calendarService.update();
        };
        CalendarComponent.ctorParameters = function () { return [
            { type: CalendarService },
            { type: String, decorators: [{ type: core.Inject, args: [core.LOCALE_ID,] }] }
        ]; };
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "currentDate", null);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "eventSource", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "calendarMode", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "formatDay", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "formatDayHeader", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "formatDayTitle", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "formatWeekTitle", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "formatMonthTitle", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "formatWeekViewDayHeader", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "formatHourColumn", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "showEventDetail", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "startingDayMonth", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "startingDayWeek", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "allDayLabel", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "noEventsLabel", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "queryMode", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "step", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "timeInterval", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "autoSelect", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "markDisabled", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "monthviewDisplayEventTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "monthviewInactiveDisplayEventTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "monthviewEventDetailTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "weekviewHeaderTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "weekviewAllDayEventTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "weekviewNormalEventTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "dayviewAllDayEventTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "dayviewNormalEventTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "weekviewAllDayEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "weekviewNormalEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "dayviewAllDayEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "dayviewNormalEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "weekviewInactiveAllDayEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "weekviewInactiveNormalEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "dayviewInactiveAllDayEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "dayviewInactiveNormalEventSectionTemplate", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "dateFormatter", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "dir", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "scrollToHour", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "preserveScrollPosition", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "lockSwipeToPrev", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "lockSwipes", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "locale", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "startHour", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "endHour", void 0);
        __decorate([
            core.Input()
        ], CalendarComponent.prototype, "sliderOptions", void 0);
        __decorate([
            core.Output()
        ], CalendarComponent.prototype, "onCurrentDateChanged", void 0);
        __decorate([
            core.Output()
        ], CalendarComponent.prototype, "onRangeChanged", void 0);
        __decorate([
            core.Output()
        ], CalendarComponent.prototype, "onEventSelected", void 0);
        __decorate([
            core.Output()
        ], CalendarComponent.prototype, "onTimeSelected", void 0);
        __decorate([
            core.Output()
        ], CalendarComponent.prototype, "onDayHeaderSelected", void 0);
        __decorate([
            core.Output()
        ], CalendarComponent.prototype, "onTitleChanged", void 0);
        CalendarComponent = __decorate([
            core.Component({
                selector: "calendar",
                template: "\n        <ng-template\n            #monthviewDefaultDisplayEventTemplate\n            let-view=\"view\"\n            let-row=\"row\"\n            let-col=\"col\"\n        >\n            {{ view.dates[row * 7 + col].label }}\n        </ng-template>\n        <ng-template\n            #monthviewDefaultEventDetailTemplate\n            let-showEventDetail=\"showEventDetail\"\n            let-selectedDate=\"selectedDate\"\n            let-noEventsLabel=\"noEventsLabel\"\n        >\n            <ion-list\n                class=\"event-detail-container\"\n                has-bouncing=\"false\"\n                *ngIf=\"showEventDetail\"\n                overflow-scroll=\"false\"\n            >\n                <ion-item\n                    *ngFor=\"let event of selectedDate?.events\"\n                    (click)=\"eventSelected(event)\"\n                >\n                    <span\n                        *ngIf=\"!event.allDay\"\n                        class=\"monthview-eventdetail-timecolumn\"\n                        >{{ event.startTime | date: \"HH:mm\" }}\n                        -\n                        {{ event.endTime | date: \"HH:mm\" }}\n                    </span>\n                    <span\n                        *ngIf=\"event.allDay\"\n                        class=\"monthview-eventdetail-timecolumn\"\n                        >{{ allDayLabel }}</span\n                    >\n                    <span class=\"event-detail\"> | {{ event.title }}</span>\n                </ion-item>\n                <ion-item *ngIf=\"selectedDate?.events.length == 0\">\n                    <div class=\"no-events-label\">{{ noEventsLabel }}</div>\n                </ion-item>\n            </ion-list>\n        </ng-template>\n        <ng-template #defaultWeekviewHeaderTemplate let-viewDate=\"viewDate\">\n            {{ viewDate.dayHeader }}\n        </ng-template>\n        <ng-template\n            #defaultAllDayEventTemplate\n            let-displayEvent=\"displayEvent\"\n        >\n            <div class=\"calendar-event-inner\">\n                {{ displayEvent.event.title }}\n            </div>\n        </ng-template>\n        <ng-template\n            #defaultNormalEventTemplate\n            let-displayEvent=\"displayEvent\"\n        >\n            <div class=\"calendar-event-inner\">\n                {{ displayEvent.event.title }}\n            </div>\n        </ng-template>\n        <ng-template\n            #defaultWeekViewAllDayEventSectionTemplate\n            let-day=\"day\"\n            let-eventTemplate=\"eventTemplate\"\n        >\n            <div\n                [ngClass]=\"{ 'calendar-event-wrap': day.events }\"\n                *ngIf=\"day.events\"\n                [ngStyle]=\"{ height: 25 * day.events.length + 'px' }\"\n            >\n                <div\n                    *ngFor=\"let displayEvent of day.events\"\n                    class=\"calendar-event\"\n                    tappable\n                    (click)=\"eventSelected(displayEvent.event)\"\n                    [ngStyle]=\"{\n                        top: 25 * displayEvent.position + 'px',\n                        width:\n                            100 *\n                                (displayEvent.endIndex -\n                                    displayEvent.startIndex) +\n                            '%',\n                        height: '25px'\n                    }\"\n                >\n                    <ng-template\n                        [ngTemplateOutlet]=\"eventTemplate\"\n                        [ngTemplateOutletContext]=\"{\n                            displayEvent: displayEvent\n                        }\"\n                    >\n                    </ng-template>\n                </div>\n            </div>\n        </ng-template>\n        <ng-template\n            #defaultDayViewAllDayEventSectionTemplate\n            let-allDayEvents=\"allDayEvents\"\n            let-eventTemplate=\"eventTemplate\"\n        >\n            <div\n                *ngFor=\"\n                    let displayEvent of allDayEvents;\n                    let eventIndex = index\n                \"\n                class=\"calendar-event\"\n                tappable\n                (click)=\"eventSelected(displayEvent.event)\"\n                [ngStyle]=\"{\n                    top: 25 * eventIndex + 'px',\n                    width: '100%',\n                    height: '25px'\n                }\"\n            >\n                <ng-template\n                    [ngTemplateOutlet]=\"eventTemplate\"\n                    [ngTemplateOutletContext]=\"{ displayEvent: displayEvent }\"\n                >\n                </ng-template>\n            </div>\n        </ng-template>\n        <ng-template\n            #defaultNormalEventSectionTemplate\n            let-tm=\"tm\"\n            let-hourParts=\"hourParts\"\n            let-eventTemplate=\"eventTemplate\"\n        >\n            <div\n                [ngClass]=\"{ 'calendar-event-wrap': tm.events }\"\n                *ngIf=\"tm.events\"\n            >\n                <div\n                    *ngFor=\"let displayEvent of tm.events\"\n                    class=\"calendar-event\"\n                    tappable\n                    (click)=\"eventSelected(displayEvent.event)\"\n                    [ngStyle]=\"{\n                        top: (37 * displayEvent.startOffset) / hourParts + 'px',\n                        left:\n                            (100 / displayEvent.overlapNumber) *\n                                displayEvent.position +\n                            '%',\n                        width: 100 / displayEvent.overlapNumber + '%',\n                        height:\n                            37 *\n                                (displayEvent.endIndex -\n                                    displayEvent.startIndex -\n                                    (displayEvent.endOffset +\n                                        displayEvent.startOffset) /\n                                        hourParts) +\n                            'px'\n                    }\"\n                >\n                    <ng-template\n                        [ngTemplateOutlet]=\"eventTemplate\"\n                        [ngTemplateOutletContext]=\"{\n                            displayEvent: displayEvent\n                        }\"\n                    >\n                    </ng-template>\n                </div>\n            </div>\n        </ng-template>\n        <ng-template #defaultInactiveAllDayEventSectionTemplate> </ng-template>\n        <ng-template #defaultInactiveNormalEventSectionTemplate> </ng-template>\n\n        <div [ngSwitch]=\"calendarMode\" class=\"{{ calendarMode }}view-container\">\n            <monthview\n                *ngSwitchCase=\"'month'\"\n                [formatDay]=\"formatDay\"\n                [formatDayHeader]=\"formatDayHeader\"\n                [formatMonthTitle]=\"formatMonthTitle\"\n                [startingDayMonth]=\"startingDayMonth\"\n                [showEventDetail]=\"showEventDetail\"\n                [noEventsLabel]=\"noEventsLabel\"\n                [autoSelect]=\"autoSelect\"\n                [eventSource]=\"eventSource\"\n                [markDisabled]=\"markDisabled\"\n                [monthviewDisplayEventTemplate]=\"\n                    monthviewDisplayEventTemplate ||\n                    monthviewDefaultDisplayEventTemplate\n                \"\n                [monthviewInactiveDisplayEventTemplate]=\"\n                    monthviewInactiveDisplayEventTemplate ||\n                    monthviewDefaultDisplayEventTemplate\n                \"\n                [monthviewEventDetailTemplate]=\"\n                    monthviewEventDetailTemplate ||\n                    monthviewDefaultEventDetailTemplate\n                \"\n                [locale]=\"locale\"\n                [dateFormatter]=\"dateFormatter\"\n                [dir]=\"dir\"\n                [lockSwipeToPrev]=\"lockSwipeToPrev\"\n                [lockSwipes]=\"lockSwipes\"\n                [sliderOptions]=\"sliderOptions\"\n                (onRangeChanged)=\"rangeChanged($event)\"\n                (onEventSelected)=\"eventSelected($event)\"\n                (onTimeSelected)=\"timeSelected($event)\"\n                (onTitleChanged)=\"titleChanged($event)\"\n            >\n            </monthview>\n            <weekview\n                *ngSwitchCase=\"'week'\"\n                [formatWeekTitle]=\"formatWeekTitle\"\n                [formatWeekViewDayHeader]=\"formatWeekViewDayHeader\"\n                [formatHourColumn]=\"formatHourColumn\"\n                [startingDayWeek]=\"startingDayWeek\"\n                [allDayLabel]=\"allDayLabel\"\n                [hourParts]=\"hourParts\"\n                [autoSelect]=\"autoSelect\"\n                [hourSegments]=\"hourSegments\"\n                [eventSource]=\"eventSource\"\n                [markDisabled]=\"markDisabled\"\n                [weekviewHeaderTemplate]=\"\n                    weekviewHeaderTemplate || defaultWeekviewHeaderTemplate\n                \"\n                [weekviewAllDayEventTemplate]=\"\n                    weekviewAllDayEventTemplate || defaultAllDayEventTemplate\n                \"\n                [weekviewNormalEventTemplate]=\"\n                    weekviewNormalEventTemplate || defaultNormalEventTemplate\n                \"\n                [weekviewAllDayEventSectionTemplate]=\"\n                    weekviewAllDayEventSectionTemplate ||\n                    defaultWeekViewAllDayEventSectionTemplate\n                \"\n                [weekviewNormalEventSectionTemplate]=\"\n                    weekviewNormalEventSectionTemplate ||\n                    defaultNormalEventSectionTemplate\n                \"\n                [weekviewInactiveAllDayEventSectionTemplate]=\"\n                    weekviewInactiveAllDayEventSectionTemplate ||\n                    defaultInactiveAllDayEventSectionTemplate\n                \"\n                [weekviewInactiveNormalEventSectionTemplate]=\"\n                    weekviewInactiveNormalEventSectionTemplate ||\n                    defaultInactiveNormalEventSectionTemplate\n                \"\n                [locale]=\"locale\"\n                [dateFormatter]=\"dateFormatter\"\n                [dir]=\"dir\"\n                [scrollToHour]=\"scrollToHour\"\n                [preserveScrollPosition]=\"preserveScrollPosition\"\n                [lockSwipeToPrev]=\"lockSwipeToPrev\"\n                [lockSwipes]=\"lockSwipes\"\n                [startHour]=\"startHour\"\n                [endHour]=\"endHour\"\n                [sliderOptions]=\"sliderOptions\"\n                (onRangeChanged)=\"rangeChanged($event)\"\n                (onEventSelected)=\"eventSelected($event)\"\n                (onDayHeaderSelected)=\"daySelected($event)\"\n                (onTimeSelected)=\"timeSelected($event)\"\n                (onTitleChanged)=\"titleChanged($event)\"\n            >\n            </weekview>\n            <dayview\n                *ngSwitchCase=\"'day'\"\n                [formatDayTitle]=\"formatDayTitle\"\n                [formatHourColumn]=\"formatHourColumn\"\n                [allDayLabel]=\"allDayLabel\"\n                [hourParts]=\"hourParts\"\n                [hourSegments]=\"hourSegments\"\n                [eventSource]=\"eventSource\"\n                [markDisabled]=\"markDisabled\"\n                [dayviewAllDayEventTemplate]=\"\n                    dayviewAllDayEventTemplate || defaultAllDayEventTemplate\n                \"\n                [dayviewNormalEventTemplate]=\"\n                    dayviewNormalEventTemplate || defaultNormalEventTemplate\n                \"\n                [dayviewAllDayEventSectionTemplate]=\"\n                    dayviewAllDayEventSectionTemplate ||\n                    defaultDayViewAllDayEventSectionTemplate\n                \"\n                [dayviewNormalEventSectionTemplate]=\"\n                    dayviewNormalEventSectionTemplate ||\n                    defaultNormalEventSectionTemplate\n                \"\n                [dayviewInactiveAllDayEventSectionTemplate]=\"\n                    dayviewInactiveAllDayEventSectionTemplate ||\n                    defaultInactiveAllDayEventSectionTemplate\n                \"\n                [dayviewInactiveNormalEventSectionTemplate]=\"\n                    dayviewInactiveNormalEventSectionTemplate ||\n                    defaultInactiveNormalEventSectionTemplate\n                \"\n                [locale]=\"locale\"\n                [dateFormatter]=\"dateFormatter\"\n                [dir]=\"dir\"\n                [scrollToHour]=\"scrollToHour\"\n                [preserveScrollPosition]=\"preserveScrollPosition\"\n                [lockSwipeToPrev]=\"lockSwipeToPrev\"\n                [lockSwipes]=\"lockSwipes\"\n                [startHour]=\"startHour\"\n                [endHour]=\"endHour\"\n                [sliderOptions]=\"sliderOptions\"\n                (onRangeChanged)=\"rangeChanged($event)\"\n                (onEventSelected)=\"eventSelected($event)\"\n                (onTimeSelected)=\"timeSelected($event)\"\n                (onTitleChanged)=\"titleChanged($event)\"\n            >\n            </dayview>\n        </div>\n    ",
                providers: [CalendarService],
                styles: ["\n            :host > div {\n                height: 100%;\n            }\n\n            .event-detail-container {\n                border-top: 2px darkgrey solid;\n            }\n\n            .no-events-label {\n                font-weight: bold;\n                color: darkgrey;\n                text-align: center;\n            }\n\n            .event-detail {\n                cursor: pointer;\n                white-space: nowrap;\n                text-overflow: ellipsis;\n            }\n\n            .monthview-eventdetail-timecolumn {\n                width: 110px;\n                overflow: hidden;\n            }\n\n            .calendar-event-inner {\n                overflow: hidden;\n                background-color: #3a87ad;\n                color: white;\n                height: 100%;\n                width: 100%;\n                padding: 2px;\n                line-height: 15px;\n                text-align: initial;\n            }\n\n            @media (max-width: 750px) {\n                .calendar-event-inner {\n                    font-size: 12px;\n                }\n            }\n        "]
            }),
            __param(1, core.Inject(core.LOCALE_ID))
        ], CalendarComponent);
        return CalendarComponent;
    }());

    var initPositionScrollComponent = /** @class */ (function () {
        function initPositionScrollComponent(el) {
            this.onScroll = new core.EventEmitter();
            this.listenerAttached = false;
            this.element = el;
        }
        initPositionScrollComponent.prototype.ngOnChanges = function (changes) {
            var initPosition = changes['initPosition'];
            if (initPosition && initPosition.currentValue !== undefined && this.scrollContent) {
                var me_1 = this;
                setTimeout(function () {
                    me_1.scrollContent.scrollTop = initPosition.currentValue;
                }, 0);
            }
        };
        initPositionScrollComponent.prototype.ngAfterViewInit = function () {
            var scrollContent = this.scrollContent = this.element.nativeElement.querySelector('.scroll-content');
            if (this.initPosition !== undefined) {
                scrollContent.scrollTop = this.initPosition;
            }
            if (this.emitEvent && !this.listenerAttached) {
                var onScroll_1 = this.onScroll;
                this.handler = function () {
                    onScroll_1.emit(scrollContent.scrollTop);
                };
                this.listenerAttached = true;
                scrollContent.addEventListener('scroll', this.handler);
            }
        };
        initPositionScrollComponent.prototype.ngOnDestroy = function () {
            if (this.listenerAttached) {
                this.scrollContent.removeEventListener('scroll', this.handler);
            }
        };
        initPositionScrollComponent.ctorParameters = function () { return [
            { type: core.ElementRef }
        ]; };
        __decorate([
            core.Input()
        ], initPositionScrollComponent.prototype, "initPosition", void 0);
        __decorate([
            core.Input()
        ], initPositionScrollComponent.prototype, "emitEvent", void 0);
        __decorate([
            core.Output()
        ], initPositionScrollComponent.prototype, "onScroll", void 0);
        initPositionScrollComponent = __decorate([
            core.Component({
                selector: 'init-position-scroll',
                template: "\n        <div class=\"scroll-content\" style=\"height:100%\">\n            <ng-content></ng-content>\n        </div>\n    ",
                encapsulation: core.ViewEncapsulation.None,
                styles: ["\n        .scroll-content {\n            overflow-y: auto;\n            overflow-x: hidden;\n        }        \n    "]
            })
        ], initPositionScrollComponent);
        return initPositionScrollComponent;
    }());

    var NgCalendarModule = /** @class */ (function () {
        function NgCalendarModule() {
        }
        NgCalendarModule = __decorate([
            core.NgModule({
                declarations: [
                    MonthViewComponent, WeekViewComponent, DayViewComponent, CalendarComponent, initPositionScrollComponent
                ],
                imports: [angular.IonicModule, common.CommonModule],
                exports: [CalendarComponent]
            })
        ], NgCalendarModule);
        return NgCalendarModule;
    }());

    exports.CalendarComponent = CalendarComponent;
    exports.NgCalendarModule = NgCalendarModule;
    exports.ɵa = MonthViewComponent;
    exports.ɵb = CalendarService;
    exports.ɵc = WeekViewComponent;
    exports.ɵd = DayViewComponent;
    exports.ɵe = initPositionScrollComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=phemium-costaisa-ionic2-calendar.umd.js.map
