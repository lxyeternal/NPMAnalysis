import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
var CalendarService = /** @class */ (function () {
    function CalendarService() {
        this.currentDateChangedFromParent = new Subject();
        this.currentDateChangedFromChildren = new Subject();
        this.eventSourceChanged = new Subject();
        this.slideChanged = new Subject();
        this.slideUpdated = new Subject();
        this.currentDateChangedFromParent$ = this.currentDateChangedFromParent.asObservable();
        this.currentDateChangedFromChildren$ = this.currentDateChangedFromChildren.asObservable();
        this.eventSourceChanged$ = this.eventSourceChanged.asObservable();
        this.slideChanged$ = this.slideChanged.asObservable();
        this.slideUpdated$ = this.slideUpdated.asObservable();
    }
    CalendarService.prototype.setInitialDate = function (val, fromParent) {
        if (fromParent === void 0) { fromParent = false; }
        this._initialDate = new Date(val);
        this.setCurrentDate(val, fromParent);
    };
    CalendarService.prototype.setCurrentDate = function (val, fromParent) {
        if (fromParent === void 0) { fromParent = false; }
        this._currentDate = new Date(val);
        if (fromParent) {
            this.currentDateChangedFromParent.next(val);
        }
        else {
            this.currentDateChangedFromChildren.next(val);
        }
    };
    Object.defineProperty(CalendarService.prototype, "currentDate", {
        get: function () {
            return this._currentDate;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CalendarService.prototype, "initialDate", {
        get: function () {
            return this._initialDate;
        },
        enumerable: true,
        configurable: true
    });
    CalendarService.prototype.rangeChanged = function (component) {
        if (this.queryMode === 'local') {
            if (component.eventSource && component.onDataLoaded) {
                component.onDataLoaded();
            }
        }
        else if (this.queryMode === 'remote') {
            var rangeStart = new Date(component.range.startTime.getTime()), rangeEnd = new Date(component.range.endTime.getTime());
            rangeStart.setHours(0);
            if (rangeStart.getHours() === 23) {
                rangeStart.setTime(rangeStart.getTime() + 3600000);
            }
            rangeEnd.setHours(0);
            if (rangeEnd.getHours() === 23) {
                rangeEnd.setTime(rangeEnd.getTime() + 3600000);
            }
            component.onRangeChanged.emit({
                startTime: rangeStart,
                endTime: rangeEnd,
            });
        }
    };
    CalendarService.prototype.getStep = function (mode) {
        switch (mode) {
            case 'month':
                return {
                    years: 0,
                    months: 1,
                    days: 0,
                };
            case 'week':
                return {
                    years: 0,
                    months: 0,
                    days: 7,
                };
            case 'day':
                return {
                    years: 0,
                    months: 0,
                    days: 1,
                };
        }
    };
    CalendarService.prototype.getAdjacentCalendarDate = function (mode, direction) {
        var calculateCalendarDate = this.currentDate;
        var step = this.getStep(mode), year = calculateCalendarDate.getFullYear() + direction * step.years, month = calculateCalendarDate.getMonth() + direction * step.months, date = calculateCalendarDate.getDate() + direction * step.days;
        calculateCalendarDate = new Date(year, month, date, 12, 0, 0);
        if (mode === 'month') {
            var firstDayInNextMonth = new Date(year, month + 1, 1, 12, 0, 0);
            if (firstDayInNextMonth.getTime() <= calculateCalendarDate.getTime()) {
                calculateCalendarDate = new Date(firstDayInNextMonth.getTime() - 24 * 60 * 60 * 1000);
            }
        }
        return calculateCalendarDate;
    };
    CalendarService.prototype.getAdjacentViewStartTime = function (component, direction) {
        var adjacentCalendarDate = this.getAdjacentCalendarDate(component.mode, direction);
        return component.getRange(adjacentCalendarDate).startTime;
    };
    CalendarService.prototype.populateAdjacentViews = function (component) {
        var currentViewStartDate, currentViewData, toUpdateViewIndex, currentViewIndex = component.currentViewIndex;
        if (component.direction === 1) {
            currentViewStartDate = this.getAdjacentViewStartTime(component, 1);
            toUpdateViewIndex = (currentViewIndex + 1) % 3;
            component.views[toUpdateViewIndex] = component.getViewData(currentViewStartDate);
        }
        else if (component.direction === -1) {
            currentViewStartDate = this.getAdjacentViewStartTime(component, -1);
            toUpdateViewIndex = (currentViewIndex + 2) % 3;
            component.views[toUpdateViewIndex] = component.getViewData(currentViewStartDate);
        }
        else {
            if (!component.views) {
                currentViewData = [];
                currentViewStartDate = component.range.startTime;
                currentViewData.push(component.getViewData(currentViewStartDate));
                currentViewStartDate = this.getAdjacentViewStartTime(component, 1);
                currentViewData.push(component.getViewData(currentViewStartDate));
                currentViewStartDate = this.getAdjacentViewStartTime(component, -1);
                currentViewData.push(component.getViewData(currentViewStartDate));
                component.views = currentViewData;
            }
            else {
                currentViewStartDate = component.range.startTime;
                component.views[currentViewIndex] = component.getViewData(currentViewStartDate);
                currentViewStartDate = this.getAdjacentViewStartTime(component, -1);
                toUpdateViewIndex = (currentViewIndex + 2) % 3;
                component.views[toUpdateViewIndex] = component.getViewData(currentViewStartDate);
                currentViewStartDate = this.getAdjacentViewStartTime(component, 1);
                toUpdateViewIndex = (currentViewIndex + 1) % 3;
                component.views[toUpdateViewIndex] = component.getViewData(currentViewStartDate);
            }
        }
    };
    CalendarService.prototype.loadEvents = function () {
        this.eventSourceChanged.next();
    };
    CalendarService.prototype.slide = function (direction) {
        this.slideChanged.next(direction);
    };
    CalendarService.prototype.update = function () {
        this.slideUpdated.next();
    };
    CalendarService = __decorate([
        Injectable()
    ], CalendarService);
    return CalendarService;
}());
export { CalendarService };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FsZW5kYXIuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BwaGVtaXVtLWNvc3RhaXNhL2lvbmljMi1jYWxlbmRhci8iLCJzb3VyY2VzIjpbImNhbGVuZGFyLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDM0MsT0FBTyxFQUFjLE9BQU8sRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUszQztJQWdCQztRQU5RLGlDQUE0QixHQUFHLElBQUksT0FBTyxFQUFRLENBQUM7UUFDbkQsbUNBQThCLEdBQUcsSUFBSSxPQUFPLEVBQVEsQ0FBQztRQUNyRCx1QkFBa0IsR0FBRyxJQUFJLE9BQU8sRUFBUSxDQUFDO1FBQ3pDLGlCQUFZLEdBQUcsSUFBSSxPQUFPLEVBQVUsQ0FBQztRQUNyQyxpQkFBWSxHQUFHLElBQUksT0FBTyxFQUFRLENBQUM7UUFHMUMsSUFBSSxDQUFDLDZCQUE2QixHQUFHLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUN0RixJQUFJLENBQUMsK0JBQStCLEdBQUcsSUFBSSxDQUFDLDhCQUE4QixDQUFDLFlBQVksRUFBRSxDQUFDO1FBQzFGLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDbEUsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFlBQVksRUFBRSxDQUFDO1FBQ3RELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUN2RCxDQUFDO0lBRUQsd0NBQWMsR0FBZCxVQUFlLEdBQVMsRUFBRSxVQUEyQjtRQUEzQiwyQkFBQSxFQUFBLGtCQUEyQjtRQUNwRCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRCx3Q0FBYyxHQUFkLFVBQWUsR0FBUyxFQUFFLFVBQTJCO1FBQTNCLDJCQUFBLEVBQUEsa0JBQTJCO1FBQ3BELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDbEMsSUFBSSxVQUFVLEVBQUU7WUFDZixJQUFJLENBQUMsNEJBQTRCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQzVDO2FBQU07WUFDTixJQUFJLENBQUMsOEJBQThCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQzlDO0lBQ0YsQ0FBQztJQUVELHNCQUFJLHdDQUFXO2FBQWY7WUFDQyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDMUIsQ0FBQzs7O09BQUE7SUFFRCxzQkFBSSx3Q0FBVzthQUFmO1lBQ0MsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDO1FBQzFCLENBQUM7OztPQUFBO0lBRUQsc0NBQVksR0FBWixVQUFhLFNBQTZCO1FBQ3pDLElBQUksSUFBSSxDQUFDLFNBQVMsS0FBSyxPQUFPLEVBQUU7WUFDL0IsSUFBSSxTQUFTLENBQUMsV0FBVyxJQUFJLFNBQVMsQ0FBQyxZQUFZLEVBQUU7Z0JBQ3BELFNBQVMsQ0FBQyxZQUFZLEVBQUUsQ0FBQzthQUN6QjtTQUNEO2FBQU0sSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLFFBQVEsRUFBRTtZQUN2QyxJQUFJLFVBQVUsR0FBRyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUM3RCxRQUFRLEdBQUcsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUV4RCxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3ZCLElBQUksVUFBVSxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDakMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLEdBQUcsT0FBTyxDQUFDLENBQUM7YUFDbkQ7WUFFRCxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3JCLElBQUksUUFBUSxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDL0IsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLEdBQUcsT0FBTyxDQUFDLENBQUM7YUFDL0M7WUFDRCxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQztnQkFDN0IsU0FBUyxFQUFFLFVBQVU7Z0JBQ3JCLE9BQU8sRUFBRSxRQUFRO2FBQ2pCLENBQUMsQ0FBQztTQUNIO0lBQ0YsQ0FBQztJQUVPLGlDQUFPLEdBQWYsVUFBZ0IsSUFBa0I7UUFDakMsUUFBUSxJQUFJLEVBQUU7WUFDYixLQUFLLE9BQU87Z0JBQ1gsT0FBTztvQkFDTixLQUFLLEVBQUUsQ0FBQztvQkFDUixNQUFNLEVBQUUsQ0FBQztvQkFDVCxJQUFJLEVBQUUsQ0FBQztpQkFDUCxDQUFDO1lBQ0gsS0FBSyxNQUFNO2dCQUNWLE9BQU87b0JBQ04sS0FBSyxFQUFFLENBQUM7b0JBQ1IsTUFBTSxFQUFFLENBQUM7b0JBQ1QsSUFBSSxFQUFFLENBQUM7aUJBQ1AsQ0FBQztZQUNILEtBQUssS0FBSztnQkFDVCxPQUFPO29CQUNOLEtBQUssRUFBRSxDQUFDO29CQUNSLE1BQU0sRUFBRSxDQUFDO29CQUNULElBQUksRUFBRSxDQUFDO2lCQUNQLENBQUM7U0FDSDtJQUNGLENBQUM7SUFFRCxpREFBdUIsR0FBdkIsVUFBd0IsSUFBa0IsRUFBRSxTQUFpQjtRQUM1RCxJQUFJLHFCQUFxQixHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7UUFDN0MsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFDOUIsSUFBSSxHQUFHLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxHQUFHLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUNuRSxLQUFLLEdBQUcscUJBQXFCLENBQUMsUUFBUSxFQUFFLEdBQUcsU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQ2xFLElBQUksR0FBRyxxQkFBcUIsQ0FBQyxPQUFPLEVBQUUsR0FBRyxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztRQUVoRSxxQkFBcUIsR0FBRyxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRTlELElBQUksSUFBSSxLQUFLLE9BQU8sRUFBRTtZQUNyQixJQUFNLG1CQUFtQixHQUFHLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ25FLElBQUksbUJBQW1CLENBQUMsT0FBTyxFQUFFLElBQUkscUJBQXFCLENBQUMsT0FBTyxFQUFFLEVBQUU7Z0JBQ3JFLHFCQUFxQixHQUFHLElBQUksSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFDO2FBQ3RGO1NBQ0Q7UUFDRCxPQUFPLHFCQUFxQixDQUFDO0lBQzlCLENBQUM7SUFFRCxrREFBd0IsR0FBeEIsVUFBeUIsU0FBNkIsRUFBRSxTQUFpQjtRQUN4RSxJQUFJLG9CQUFvQixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ25GLE9BQU8sU0FBUyxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLFNBQVMsQ0FBQztJQUMzRCxDQUFDO0lBRUQsK0NBQXFCLEdBQXJCLFVBQXNCLFNBQTZCO1FBQ2xELElBQUksb0JBQTBCLEVBQzdCLGVBQXdCLEVBQ3hCLGlCQUF5QixFQUN6QixnQkFBZ0IsR0FBRyxTQUFTLENBQUMsZ0JBQWdCLENBQUM7UUFFL0MsSUFBSSxTQUFTLENBQUMsU0FBUyxLQUFLLENBQUMsRUFBRTtZQUM5QixvQkFBb0IsR0FBRyxJQUFJLENBQUMsd0JBQXdCLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQ25FLGlCQUFpQixHQUFHLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQy9DLFNBQVMsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsR0FBRyxTQUFTLENBQUMsV0FBVyxDQUFDLG9CQUFvQixDQUFDLENBQUM7U0FDakY7YUFBTSxJQUFJLFNBQVMsQ0FBQyxTQUFTLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFDdEMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BFLGlCQUFpQixHQUFHLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQy9DLFNBQVMsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsR0FBRyxTQUFTLENBQUMsV0FBVyxDQUFDLG9CQUFvQixDQUFDLENBQUM7U0FDakY7YUFBTTtZQUNOLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFO2dCQUNyQixlQUFlLEdBQUcsRUFBRSxDQUFDO2dCQUNyQixvQkFBb0IsR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztnQkFDakQsZUFBZSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQztnQkFDbEUsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDbkUsZUFBZSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQztnQkFDbEUsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwRSxlQUFlLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDO2dCQUNsRSxTQUFTLENBQUMsS0FBSyxHQUFHLGVBQWUsQ0FBQzthQUNsQztpQkFBTTtnQkFDTixvQkFBb0IsR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztnQkFDakQsU0FBUyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsQ0FBQztnQkFDaEYsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwRSxpQkFBaUIsR0FBRyxDQUFDLGdCQUFnQixHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDL0MsU0FBUyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsQ0FBQztnQkFDakYsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDbkUsaUJBQWlCLEdBQUcsQ0FBQyxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQy9DLFNBQVMsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsR0FBRyxTQUFTLENBQUMsV0FBVyxDQUFDLG9CQUFvQixDQUFDLENBQUM7YUFDakY7U0FDRDtJQUNGLENBQUM7SUFFRCxvQ0FBVSxHQUFWO1FBQ0MsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksRUFBRSxDQUFDO0lBQ2hDLENBQUM7SUFFRCwrQkFBSyxHQUFMLFVBQU0sU0FBaUI7UUFDdEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUVELGdDQUFNLEdBQU47UUFDQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFwS1csZUFBZTtRQUQzQixVQUFVLEVBQUU7T0FDQSxlQUFlLENBcUszQjtJQUFELHNCQUFDO0NBQUEsQUFyS0QsSUFxS0M7U0FyS1ksZUFBZSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xyXG5cclxuaW1wb3J0IHsgSUNhbGVuZGFyQ29tcG9uZW50LCBJVmlldywgQ2FsZW5kYXJNb2RlLCBRdWVyeU1vZGUgfSBmcm9tICcuL2NhbGVuZGFyJztcclxuXHJcbkBJbmplY3RhYmxlKClcclxuZXhwb3J0IGNsYXNzIENhbGVuZGFyU2VydmljZSB7XHJcblx0cXVlcnlNb2RlOiBRdWVyeU1vZGU7XHJcblx0Y3VycmVudERhdGVDaGFuZ2VkRnJvbVBhcmVudCQ6IE9ic2VydmFibGU8RGF0ZT47XHJcblx0Y3VycmVudERhdGVDaGFuZ2VkRnJvbUNoaWxkcmVuJDogT2JzZXJ2YWJsZTxEYXRlPjtcclxuXHRldmVudFNvdXJjZUNoYW5nZWQkOiBPYnNlcnZhYmxlPHZvaWQ+O1xyXG5cdHNsaWRlQ2hhbmdlZCQ6IE9ic2VydmFibGU8bnVtYmVyPjtcclxuXHRzbGlkZVVwZGF0ZWQkOiBPYnNlcnZhYmxlPHZvaWQ+O1xyXG5cclxuXHRwcml2YXRlIF9jdXJyZW50RGF0ZTogRGF0ZTtcclxuXHRwcml2YXRlIF9pbml0aWFsRGF0ZTogRGF0ZTtcclxuXHRwcml2YXRlIGN1cnJlbnREYXRlQ2hhbmdlZEZyb21QYXJlbnQgPSBuZXcgU3ViamVjdDxEYXRlPigpO1xyXG5cdHByaXZhdGUgY3VycmVudERhdGVDaGFuZ2VkRnJvbUNoaWxkcmVuID0gbmV3IFN1YmplY3Q8RGF0ZT4oKTtcclxuXHRwcml2YXRlIGV2ZW50U291cmNlQ2hhbmdlZCA9IG5ldyBTdWJqZWN0PHZvaWQ+KCk7XHJcblx0cHJpdmF0ZSBzbGlkZUNoYW5nZWQgPSBuZXcgU3ViamVjdDxudW1iZXI+KCk7XHJcblx0cHJpdmF0ZSBzbGlkZVVwZGF0ZWQgPSBuZXcgU3ViamVjdDx2b2lkPigpO1xyXG5cclxuXHRjb25zdHJ1Y3RvcigpIHtcclxuXHRcdHRoaXMuY3VycmVudERhdGVDaGFuZ2VkRnJvbVBhcmVudCQgPSB0aGlzLmN1cnJlbnREYXRlQ2hhbmdlZEZyb21QYXJlbnQuYXNPYnNlcnZhYmxlKCk7XHJcblx0XHR0aGlzLmN1cnJlbnREYXRlQ2hhbmdlZEZyb21DaGlsZHJlbiQgPSB0aGlzLmN1cnJlbnREYXRlQ2hhbmdlZEZyb21DaGlsZHJlbi5hc09ic2VydmFibGUoKTtcclxuXHRcdHRoaXMuZXZlbnRTb3VyY2VDaGFuZ2VkJCA9IHRoaXMuZXZlbnRTb3VyY2VDaGFuZ2VkLmFzT2JzZXJ2YWJsZSgpO1xyXG5cdFx0dGhpcy5zbGlkZUNoYW5nZWQkID0gdGhpcy5zbGlkZUNoYW5nZWQuYXNPYnNlcnZhYmxlKCk7XHJcblx0XHR0aGlzLnNsaWRlVXBkYXRlZCQgPSB0aGlzLnNsaWRlVXBkYXRlZC5hc09ic2VydmFibGUoKTtcclxuXHR9XHJcblxyXG5cdHNldEluaXRpYWxEYXRlKHZhbDogRGF0ZSwgZnJvbVBhcmVudDogYm9vbGVhbiA9IGZhbHNlKSB7XHJcblx0XHR0aGlzLl9pbml0aWFsRGF0ZSA9IG5ldyBEYXRlKHZhbCk7XHJcblx0XHR0aGlzLnNldEN1cnJlbnREYXRlKHZhbCwgZnJvbVBhcmVudCk7XHJcblx0fVxyXG5cclxuXHRzZXRDdXJyZW50RGF0ZSh2YWw6IERhdGUsIGZyb21QYXJlbnQ6IGJvb2xlYW4gPSBmYWxzZSkge1xyXG5cdFx0dGhpcy5fY3VycmVudERhdGUgPSBuZXcgRGF0ZSh2YWwpO1xyXG5cdFx0aWYgKGZyb21QYXJlbnQpIHtcclxuXHRcdFx0dGhpcy5jdXJyZW50RGF0ZUNoYW5nZWRGcm9tUGFyZW50Lm5leHQodmFsKTtcclxuXHRcdH0gZWxzZSB7XHJcblx0XHRcdHRoaXMuY3VycmVudERhdGVDaGFuZ2VkRnJvbUNoaWxkcmVuLm5leHQodmFsKTtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdGdldCBjdXJyZW50RGF0ZSgpOiBEYXRlIHtcclxuXHRcdHJldHVybiB0aGlzLl9jdXJyZW50RGF0ZTtcclxuXHR9XHJcblxyXG5cdGdldCBpbml0aWFsRGF0ZSgpOiBEYXRlIHtcclxuXHRcdHJldHVybiB0aGlzLl9pbml0aWFsRGF0ZTtcclxuXHR9XHJcblxyXG5cdHJhbmdlQ2hhbmdlZChjb21wb25lbnQ6IElDYWxlbmRhckNvbXBvbmVudCkge1xyXG5cdFx0aWYgKHRoaXMucXVlcnlNb2RlID09PSAnbG9jYWwnKSB7XHJcblx0XHRcdGlmIChjb21wb25lbnQuZXZlbnRTb3VyY2UgJiYgY29tcG9uZW50Lm9uRGF0YUxvYWRlZCkge1xyXG5cdFx0XHRcdGNvbXBvbmVudC5vbkRhdGFMb2FkZWQoKTtcclxuXHRcdFx0fVxyXG5cdFx0fSBlbHNlIGlmICh0aGlzLnF1ZXJ5TW9kZSA9PT0gJ3JlbW90ZScpIHtcclxuXHRcdFx0bGV0IHJhbmdlU3RhcnQgPSBuZXcgRGF0ZShjb21wb25lbnQucmFuZ2Uuc3RhcnRUaW1lLmdldFRpbWUoKSksXHJcblx0XHRcdFx0cmFuZ2VFbmQgPSBuZXcgRGF0ZShjb21wb25lbnQucmFuZ2UuZW5kVGltZS5nZXRUaW1lKCkpO1xyXG5cclxuXHRcdFx0cmFuZ2VTdGFydC5zZXRIb3VycygwKTtcclxuXHRcdFx0aWYgKHJhbmdlU3RhcnQuZ2V0SG91cnMoKSA9PT0gMjMpIHtcclxuXHRcdFx0XHRyYW5nZVN0YXJ0LnNldFRpbWUocmFuZ2VTdGFydC5nZXRUaW1lKCkgKyAzNjAwMDAwKTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0cmFuZ2VFbmQuc2V0SG91cnMoMCk7XHJcblx0XHRcdGlmIChyYW5nZUVuZC5nZXRIb3VycygpID09PSAyMykge1xyXG5cdFx0XHRcdHJhbmdlRW5kLnNldFRpbWUocmFuZ2VFbmQuZ2V0VGltZSgpICsgMzYwMDAwMCk7XHJcblx0XHRcdH1cclxuXHRcdFx0Y29tcG9uZW50Lm9uUmFuZ2VDaGFuZ2VkLmVtaXQoe1xyXG5cdFx0XHRcdHN0YXJ0VGltZTogcmFuZ2VTdGFydCxcclxuXHRcdFx0XHRlbmRUaW1lOiByYW5nZUVuZCxcclxuXHRcdFx0fSk7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHRwcml2YXRlIGdldFN0ZXAobW9kZTogQ2FsZW5kYXJNb2RlKTogeyB5ZWFyczogbnVtYmVyOyBtb250aHM6IG51bWJlcjsgZGF5czogbnVtYmVyIH0ge1xyXG5cdFx0c3dpdGNoIChtb2RlKSB7XHJcblx0XHRcdGNhc2UgJ21vbnRoJzpcclxuXHRcdFx0XHRyZXR1cm4ge1xyXG5cdFx0XHRcdFx0eWVhcnM6IDAsXHJcblx0XHRcdFx0XHRtb250aHM6IDEsXHJcblx0XHRcdFx0XHRkYXlzOiAwLFxyXG5cdFx0XHRcdH07XHJcblx0XHRcdGNhc2UgJ3dlZWsnOlxyXG5cdFx0XHRcdHJldHVybiB7XHJcblx0XHRcdFx0XHR5ZWFyczogMCxcclxuXHRcdFx0XHRcdG1vbnRoczogMCxcclxuXHRcdFx0XHRcdGRheXM6IDcsXHJcblx0XHRcdFx0fTtcclxuXHRcdFx0Y2FzZSAnZGF5JzpcclxuXHRcdFx0XHRyZXR1cm4ge1xyXG5cdFx0XHRcdFx0eWVhcnM6IDAsXHJcblx0XHRcdFx0XHRtb250aHM6IDAsXHJcblx0XHRcdFx0XHRkYXlzOiAxLFxyXG5cdFx0XHRcdH07XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHRnZXRBZGphY2VudENhbGVuZGFyRGF0ZShtb2RlOiBDYWxlbmRhck1vZGUsIGRpcmVjdGlvbjogbnVtYmVyKTogRGF0ZSB7XHJcblx0XHRsZXQgY2FsY3VsYXRlQ2FsZW5kYXJEYXRlID0gdGhpcy5jdXJyZW50RGF0ZTtcclxuXHRcdGNvbnN0IHN0ZXAgPSB0aGlzLmdldFN0ZXAobW9kZSksXHJcblx0XHRcdHllYXIgPSBjYWxjdWxhdGVDYWxlbmRhckRhdGUuZ2V0RnVsbFllYXIoKSArIGRpcmVjdGlvbiAqIHN0ZXAueWVhcnMsXHJcblx0XHRcdG1vbnRoID0gY2FsY3VsYXRlQ2FsZW5kYXJEYXRlLmdldE1vbnRoKCkgKyBkaXJlY3Rpb24gKiBzdGVwLm1vbnRocyxcclxuXHRcdFx0ZGF0ZSA9IGNhbGN1bGF0ZUNhbGVuZGFyRGF0ZS5nZXREYXRlKCkgKyBkaXJlY3Rpb24gKiBzdGVwLmRheXM7XHJcblxyXG5cdFx0Y2FsY3VsYXRlQ2FsZW5kYXJEYXRlID0gbmV3IERhdGUoeWVhciwgbW9udGgsIGRhdGUsIDEyLCAwLCAwKTtcclxuXHJcblx0XHRpZiAobW9kZSA9PT0gJ21vbnRoJykge1xyXG5cdFx0XHRjb25zdCBmaXJzdERheUluTmV4dE1vbnRoID0gbmV3IERhdGUoeWVhciwgbW9udGggKyAxLCAxLCAxMiwgMCwgMCk7XHJcblx0XHRcdGlmIChmaXJzdERheUluTmV4dE1vbnRoLmdldFRpbWUoKSA8PSBjYWxjdWxhdGVDYWxlbmRhckRhdGUuZ2V0VGltZSgpKSB7XHJcblx0XHRcdFx0Y2FsY3VsYXRlQ2FsZW5kYXJEYXRlID0gbmV3IERhdGUoZmlyc3REYXlJbk5leHRNb250aC5nZXRUaW1lKCkgLSAyNCAqIDYwICogNjAgKiAxMDAwKTtcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdFx0cmV0dXJuIGNhbGN1bGF0ZUNhbGVuZGFyRGF0ZTtcclxuXHR9XHJcblxyXG5cdGdldEFkamFjZW50Vmlld1N0YXJ0VGltZShjb21wb25lbnQ6IElDYWxlbmRhckNvbXBvbmVudCwgZGlyZWN0aW9uOiBudW1iZXIpOiBEYXRlIHtcclxuXHRcdGxldCBhZGphY2VudENhbGVuZGFyRGF0ZSA9IHRoaXMuZ2V0QWRqYWNlbnRDYWxlbmRhckRhdGUoY29tcG9uZW50Lm1vZGUsIGRpcmVjdGlvbik7XHJcblx0XHRyZXR1cm4gY29tcG9uZW50LmdldFJhbmdlKGFkamFjZW50Q2FsZW5kYXJEYXRlKS5zdGFydFRpbWU7XHJcblx0fVxyXG5cclxuXHRwb3B1bGF0ZUFkamFjZW50Vmlld3MoY29tcG9uZW50OiBJQ2FsZW5kYXJDb21wb25lbnQpIHtcclxuXHRcdGxldCBjdXJyZW50Vmlld1N0YXJ0RGF0ZTogRGF0ZSxcclxuXHRcdFx0Y3VycmVudFZpZXdEYXRhOiBJVmlld1tdLFxyXG5cdFx0XHR0b1VwZGF0ZVZpZXdJbmRleDogbnVtYmVyLFxyXG5cdFx0XHRjdXJyZW50Vmlld0luZGV4ID0gY29tcG9uZW50LmN1cnJlbnRWaWV3SW5kZXg7XHJcblxyXG5cdFx0aWYgKGNvbXBvbmVudC5kaXJlY3Rpb24gPT09IDEpIHtcclxuXHRcdFx0Y3VycmVudFZpZXdTdGFydERhdGUgPSB0aGlzLmdldEFkamFjZW50Vmlld1N0YXJ0VGltZShjb21wb25lbnQsIDEpO1xyXG5cdFx0XHR0b1VwZGF0ZVZpZXdJbmRleCA9IChjdXJyZW50Vmlld0luZGV4ICsgMSkgJSAzO1xyXG5cdFx0XHRjb21wb25lbnQudmlld3NbdG9VcGRhdGVWaWV3SW5kZXhdID0gY29tcG9uZW50LmdldFZpZXdEYXRhKGN1cnJlbnRWaWV3U3RhcnREYXRlKTtcclxuXHRcdH0gZWxzZSBpZiAoY29tcG9uZW50LmRpcmVjdGlvbiA9PT0gLTEpIHtcclxuXHRcdFx0Y3VycmVudFZpZXdTdGFydERhdGUgPSB0aGlzLmdldEFkamFjZW50Vmlld1N0YXJ0VGltZShjb21wb25lbnQsIC0xKTtcclxuXHRcdFx0dG9VcGRhdGVWaWV3SW5kZXggPSAoY3VycmVudFZpZXdJbmRleCArIDIpICUgMztcclxuXHRcdFx0Y29tcG9uZW50LnZpZXdzW3RvVXBkYXRlVmlld0luZGV4XSA9IGNvbXBvbmVudC5nZXRWaWV3RGF0YShjdXJyZW50Vmlld1N0YXJ0RGF0ZSk7XHJcblx0XHR9IGVsc2Uge1xyXG5cdFx0XHRpZiAoIWNvbXBvbmVudC52aWV3cykge1xyXG5cdFx0XHRcdGN1cnJlbnRWaWV3RGF0YSA9IFtdO1xyXG5cdFx0XHRcdGN1cnJlbnRWaWV3U3RhcnREYXRlID0gY29tcG9uZW50LnJhbmdlLnN0YXJ0VGltZTtcclxuXHRcdFx0XHRjdXJyZW50Vmlld0RhdGEucHVzaChjb21wb25lbnQuZ2V0Vmlld0RhdGEoY3VycmVudFZpZXdTdGFydERhdGUpKTtcclxuXHRcdFx0XHRjdXJyZW50Vmlld1N0YXJ0RGF0ZSA9IHRoaXMuZ2V0QWRqYWNlbnRWaWV3U3RhcnRUaW1lKGNvbXBvbmVudCwgMSk7XHJcblx0XHRcdFx0Y3VycmVudFZpZXdEYXRhLnB1c2goY29tcG9uZW50LmdldFZpZXdEYXRhKGN1cnJlbnRWaWV3U3RhcnREYXRlKSk7XHJcblx0XHRcdFx0Y3VycmVudFZpZXdTdGFydERhdGUgPSB0aGlzLmdldEFkamFjZW50Vmlld1N0YXJ0VGltZShjb21wb25lbnQsIC0xKTtcclxuXHRcdFx0XHRjdXJyZW50Vmlld0RhdGEucHVzaChjb21wb25lbnQuZ2V0Vmlld0RhdGEoY3VycmVudFZpZXdTdGFydERhdGUpKTtcclxuXHRcdFx0XHRjb21wb25lbnQudmlld3MgPSBjdXJyZW50Vmlld0RhdGE7XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0Y3VycmVudFZpZXdTdGFydERhdGUgPSBjb21wb25lbnQucmFuZ2Uuc3RhcnRUaW1lO1xyXG5cdFx0XHRcdGNvbXBvbmVudC52aWV3c1tjdXJyZW50Vmlld0luZGV4XSA9IGNvbXBvbmVudC5nZXRWaWV3RGF0YShjdXJyZW50Vmlld1N0YXJ0RGF0ZSk7XHJcblx0XHRcdFx0Y3VycmVudFZpZXdTdGFydERhdGUgPSB0aGlzLmdldEFkamFjZW50Vmlld1N0YXJ0VGltZShjb21wb25lbnQsIC0xKTtcclxuXHRcdFx0XHR0b1VwZGF0ZVZpZXdJbmRleCA9IChjdXJyZW50Vmlld0luZGV4ICsgMikgJSAzO1xyXG5cdFx0XHRcdGNvbXBvbmVudC52aWV3c1t0b1VwZGF0ZVZpZXdJbmRleF0gPSBjb21wb25lbnQuZ2V0Vmlld0RhdGEoY3VycmVudFZpZXdTdGFydERhdGUpO1xyXG5cdFx0XHRcdGN1cnJlbnRWaWV3U3RhcnREYXRlID0gdGhpcy5nZXRBZGphY2VudFZpZXdTdGFydFRpbWUoY29tcG9uZW50LCAxKTtcclxuXHRcdFx0XHR0b1VwZGF0ZVZpZXdJbmRleCA9IChjdXJyZW50Vmlld0luZGV4ICsgMSkgJSAzO1xyXG5cdFx0XHRcdGNvbXBvbmVudC52aWV3c1t0b1VwZGF0ZVZpZXdJbmRleF0gPSBjb21wb25lbnQuZ2V0Vmlld0RhdGEoY3VycmVudFZpZXdTdGFydERhdGUpO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHRsb2FkRXZlbnRzKCkge1xyXG5cdFx0dGhpcy5ldmVudFNvdXJjZUNoYW5nZWQubmV4dCgpO1xyXG5cdH1cclxuXHJcblx0c2xpZGUoZGlyZWN0aW9uOiBudW1iZXIpIHtcclxuXHRcdHRoaXMuc2xpZGVDaGFuZ2VkLm5leHQoZGlyZWN0aW9uKTtcclxuXHR9XHJcblxyXG5cdHVwZGF0ZSgpIHtcclxuXHRcdHRoaXMuc2xpZGVVcGRhdGVkLm5leHQoKTtcclxuXHR9XHJcbn1cclxuIl19