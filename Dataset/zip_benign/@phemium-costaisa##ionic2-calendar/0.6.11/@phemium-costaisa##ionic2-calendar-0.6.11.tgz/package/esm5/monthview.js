import { __decorate } from "tslib";
import { Component, Input, Output, EventEmitter, ViewChild, } from '@angular/core';
import { DatePipe } from '@angular/common';
import { CalendarService } from './calendar.service';
var MonthViewComponent = /** @class */ (function () {
    function MonthViewComponent(calendarService) {
        this.calendarService = calendarService;
        this.autoSelect = true;
        this.dir = '';
        this.onRangeChanged = new EventEmitter();
        this.onEventSelected = new EventEmitter();
        this.onTimeSelected = new EventEmitter(true);
        this.onTitleChanged = new EventEmitter(true);
        this.views = [];
        this.currentViewIndex = 0;
        this.mode = 'month';
        this.direction = 0;
        this.moveOnSelected = false;
        this.inited = false;
        this.callbackOnInit = true;
    }
    MonthViewComponent_1 = MonthViewComponent;
    MonthViewComponent.getDates = function (startDate, n) {
        var dates = new Array(n), current = new Date(startDate.getTime());
        var i = 0;
        while (i < n) {
            dates[i++] = new Date(current.getTime());
            current.setDate(current.getDate() + 1);
        }
        return dates;
    };
    MonthViewComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (!this.sliderOptions) {
            this.sliderOptions = {};
        }
        this.sliderOptions.loop = true;
        if (this.dateFormatter && this.dateFormatter.formatMonthViewDay) {
            this.formatDayLabel = this.dateFormatter.formatMonthViewDay;
        }
        else {
            var dayLabelDatePipe_1 = new DatePipe('en-US');
            this.formatDayLabel = function (date) {
                return dayLabelDatePipe_1.transform(date, this.formatDay);
            };
        }
        if (this.dateFormatter && this.dateFormatter.formatMonthViewDayHeader) {
            this.formatDayHeaderLabel = this.dateFormatter.formatMonthViewDayHeader;
        }
        else {
            var datePipe_1 = new DatePipe(this.locale);
            this.formatDayHeaderLabel = function (date) {
                return datePipe_1.transform(date, this.formatDayHeader);
            };
        }
        if (this.dateFormatter && this.dateFormatter.formatMonthViewTitle) {
            this.formatTitle = this.dateFormatter.formatMonthViewTitle;
        }
        else {
            var datePipe_2 = new DatePipe(this.locale);
            this.formatTitle = function (date) {
                return datePipe_2.transform(date, this.formatMonthTitle);
            };
        }
        if (this.lockSwipeToPrev) {
            this.slider.lockSwipeToPrev(true);
        }
        if (this.lockSwipes) {
            this.slider.lockSwipes(true);
        }
        this.refreshView();
        this.inited = true;
        this.currentDateChangedFromParentSubscription = this.calendarService.currentDateChangedFromParent$.subscribe(function (currentDate) {
            _this.refreshView();
        });
        this.eventSourceChangedSubscription = this.calendarService.eventSourceChanged$.subscribe(function () {
            _this.onDataLoaded();
        });
        this.slideChangedSubscription = this.calendarService.slideChanged$.subscribe(function (direction) {
            if (direction === 1) {
                _this.slider.slideNext();
            }
            else if (direction === -1) {
                _this.slider.slidePrev();
            }
        });
        this.slideUpdatedSubscription = this.calendarService.slideUpdated$.subscribe(function () {
            _this.slider.update();
        });
    };
    MonthViewComponent.prototype.ngOnDestroy = function () {
        if (this.currentDateChangedFromParentSubscription) {
            this.currentDateChangedFromParentSubscription.unsubscribe();
            this.currentDateChangedFromParentSubscription = null;
        }
        if (this.eventSourceChangedSubscription) {
            this.eventSourceChangedSubscription.unsubscribe();
            this.eventSourceChangedSubscription = null;
        }
        if (this.slideChangedSubscription) {
            this.slideChangedSubscription.unsubscribe();
            this.slideChangedSubscription = null;
        }
        if (this.slideUpdatedSubscription) {
            this.slideUpdatedSubscription.unsubscribe();
            this.slideUpdatedSubscription = null;
        }
    };
    MonthViewComponent.prototype.ngOnChanges = function (changes) {
        if (!this.inited) {
            return;
        }
        var eventSourceChange = changes.eventSource;
        if (eventSourceChange && eventSourceChange.currentValue) {
            this.onDataLoaded();
        }
        var lockSwipeToPrev = changes.lockSwipeToPrev;
        if (lockSwipeToPrev) {
            this.slider.lockSwipeToPrev(lockSwipeToPrev.currentValue);
        }
        var lockSwipes = changes.lockSwipes;
        if (lockSwipes) {
            this.slider.lockSwipes(lockSwipes.currentValue);
        }
    };
    MonthViewComponent.prototype.ngAfterViewInit = function () {
        var title = this.getTitle();
        this.onTitleChanged.emit(title);
    };
    MonthViewComponent.prototype.onSlideChanged = function () {
        var _this = this;
        if (this.callbackOnInit) {
            this.callbackOnInit = false;
            return;
        }
        var direction = 0;
        var currentViewIndex = this.currentViewIndex;
        this.slider.getActiveIndex().then(function (currentSlideIndex) {
            currentSlideIndex = (currentSlideIndex + 2) % 3;
            if (isNaN(currentSlideIndex)) {
                currentSlideIndex = currentViewIndex;
            }
            if (currentSlideIndex - currentViewIndex === 1) {
                direction = 1;
            }
            else if (currentSlideIndex === 0 && currentViewIndex === 2) {
                direction = 1;
                _this.slider.slideTo(1, 0, false);
            }
            else if (currentViewIndex - currentSlideIndex === 1) {
                direction = -1;
            }
            else if (currentSlideIndex === 2 && currentViewIndex === 0) {
                direction = -1;
                _this.slider.slideTo(3, 0, false);
            }
            _this.currentViewIndex = currentSlideIndex;
            _this.move(direction);
        });
    };
    MonthViewComponent.prototype.move = function (direction) {
        if (direction === 0) {
            return;
        }
        this.direction = direction;
        if (!this.moveOnSelected) {
            var adjacentDate = this.calendarService.getAdjacentCalendarDate(this.mode, direction);
            this.calendarService.setCurrentDate(adjacentDate);
        }
        this.refreshView();
        this.direction = 0;
        this.moveOnSelected = false;
    };
    MonthViewComponent.prototype.createDateObject = function (date) {
        var disabled = false;
        if (this.markDisabled) {
            disabled = this.markDisabled(date);
        }
        return {
            date: date,
            events: [],
            label: this.formatDayLabel(date),
            secondary: false,
            disabled: disabled,
        };
    };
    MonthViewComponent.prototype.getViewData = function (startTime) {
        var startDate = startTime, date = startDate.getDate(), month = (startDate.getMonth() + (date !== 1 ? 1 : 0)) % 12;
        var dates = MonthViewComponent_1.getDates(startDate, 42);
        var days = [];
        for (var i = 0; i < 42; i++) {
            var dateObject = this.createDateObject(dates[i]);
            dateObject.secondary = dates[i].getMonth() !== month;
            days[i] = dateObject;
        }
        var dayHeaders = [];
        for (var i = 0; i < 7; i++) {
            dayHeaders.push(this.formatDayHeaderLabel(days[i].date));
        }
        return {
            dates: days,
            dayHeaders: dayHeaders,
        };
    };
    MonthViewComponent.prototype.getHighlightClass = function (date) {
        var className = '';
        if (date.hasEvent) {
            if (date.secondary) {
                className = 'monthview-secondary-with-event';
            }
            else {
                className = 'monthview-primary-with-event';
            }
        }
        if (date.selected) {
            if (className) {
                className += ' ';
            }
            className += 'monthview-selected';
        }
        if (date.current) {
            if (className) {
                className += ' ';
            }
            className += 'monthview-current';
        }
        if (date.secondary) {
            if (className) {
                className += ' ';
            }
            className += 'text-muted';
        }
        if (date.disabled) {
            if (className) {
                className += ' ';
            }
            className += 'monthview-disabled';
        }
        return className;
    };
    MonthViewComponent.prototype.getRange = function (currentDate) {
        var year = currentDate.getFullYear(), month = currentDate.getMonth(), firstDayOfMonth = new Date(year, month, 1, 12, 0, 0), // set hour to 12 to avoid DST problem
        difference = this.startingDayMonth - firstDayOfMonth.getDay(), numDisplayedFromPreviousMonth = difference > 0 ? 7 - difference : -difference, startDate = new Date(firstDayOfMonth.getTime());
        if (numDisplayedFromPreviousMonth > 0) {
            startDate.setDate(-numDisplayedFromPreviousMonth + 1);
        }
        var endDate = new Date(startDate.getTime());
        endDate.setDate(endDate.getDate() + 42);
        return {
            startTime: startDate,
            endTime: endDate,
        };
    };
    MonthViewComponent.prototype.onDataLoaded = function () {
        var range = this.range, eventSource = this.eventSource, len = eventSource ? eventSource.length : 0, startTime = range.startTime, endTime = range.endTime, utcStartTime = Date.UTC(startTime.getFullYear(), startTime.getMonth(), startTime.getDate()), utcEndTime = Date.UTC(endTime.getFullYear(), endTime.getMonth(), endTime.getDate()), currentViewIndex = this.currentViewIndex, dates = this.views[currentViewIndex].dates, oneDay = 86400000, eps = 0.0006;
        for (var r = 0; r < 42; r += 1) {
            if (dates[r].hasEvent) {
                dates[r].hasEvent = false;
                dates[r].events = [];
            }
        }
        for (var i = 0; i < len; i += 1) {
            var event_1 = eventSource[i], eventStartTime = event_1.startTime, eventEndTime = event_1.endTime;
            var eventUTCStartTime = void 0, eventUTCEndTime = void 0;
            if (event_1.allDay) {
                eventUTCStartTime = eventStartTime.getTime();
                eventUTCEndTime = eventEndTime.getTime();
            }
            else {
                eventUTCStartTime = Date.UTC(eventStartTime.getFullYear(), eventStartTime.getMonth(), eventStartTime.getDate());
                eventUTCEndTime = Date.UTC(eventEndTime.getFullYear(), eventEndTime.getMonth(), eventEndTime.getDate() + 1);
            }
            if (eventUTCEndTime <= utcStartTime || eventUTCStartTime >= utcEndTime) {
                continue;
            }
            var timeDifferenceStart = void 0, timeDifferenceEnd = void 0;
            if (eventUTCStartTime < utcStartTime) {
                timeDifferenceStart = 0;
            }
            else {
                timeDifferenceStart = (eventUTCStartTime - utcStartTime) / oneDay;
            }
            if (eventUTCEndTime > utcEndTime) {
                timeDifferenceEnd = (utcEndTime - utcStartTime) / oneDay;
            }
            else {
                timeDifferenceEnd = (eventUTCEndTime - utcStartTime) / oneDay;
            }
            var index = Math.floor(timeDifferenceStart);
            var endIndex = Math.ceil(timeDifferenceEnd - eps);
            while (index < endIndex) {
                dates[index].hasEvent = true;
                var eventSet = dates[index].events;
                if (eventSet) {
                    eventSet.push(event_1);
                }
                else {
                    eventSet = [];
                    eventSet.push(event_1);
                    dates[index].events = eventSet;
                }
                index += 1;
            }
        }
        for (var r = 0; r < 42; r += 1) {
            if (dates[r].hasEvent) {
                dates[r].events.sort(this.compareEvent);
            }
        }
        if (this.autoSelect) {
            var findSelected = false;
            for (var r = 0; r < 42; r += 1) {
                if (dates[r].selected) {
                    this.selectedDate = dates[r];
                    findSelected = true;
                    break;
                }
            }
            if (findSelected) {
                this.onTimeSelected.emit({
                    selectedTime: this.selectedDate.date,
                    events: this.selectedDate.events,
                    disabled: this.selectedDate.disabled,
                });
            }
        }
    };
    MonthViewComponent.prototype.refreshView = function () {
        this.range = this.getRange(this.calendarService.currentDate);
        if (this.inited) {
            var title = this.getTitle();
            this.onTitleChanged.emit(title);
        }
        this.calendarService.populateAdjacentViews(this);
        this.updateCurrentView(this.range.startTime, this.views[this.currentViewIndex]);
        this.calendarService.rangeChanged(this);
    };
    MonthViewComponent.prototype.getTitle = function () {
        var currentViewStartDate = this.range.startTime, date = currentViewStartDate.getDate(), month = (currentViewStartDate.getMonth() + (date !== 1 ? 1 : 0)) % 12, year = currentViewStartDate.getFullYear() + (date !== 1 && month === 0 ? 1 : 0), headerDate = new Date(year, month, 1, 12, 0, 0, 0);
        return this.formatTitle(headerDate);
    };
    MonthViewComponent.prototype.compareEvent = function (event1, event2) {
        if (event1.allDay) {
            return 1;
        }
        else if (event2.allDay) {
            return -1;
        }
        else {
            return event1.startTime.getTime() - event2.startTime.getTime();
        }
    };
    MonthViewComponent.prototype.select = function (viewDate) {
        if (!this.views) {
            return;
        }
        var selectedDate = viewDate.date, events = viewDate.events;
        if (!viewDate.disabled) {
            var dates = this.views[this.currentViewIndex].dates, currentCalendarDate = this.calendarService.currentDate, currentMonth = currentCalendarDate.getMonth(), currentYear = currentCalendarDate.getFullYear(), selectedMonth = selectedDate.getMonth(), selectedYear = selectedDate.getFullYear();
            var direction = 0;
            if (currentYear === selectedYear) {
                if (currentMonth !== selectedMonth) {
                    direction = currentMonth < selectedMonth ? 1 : -1;
                }
            }
            else {
                direction = currentYear < selectedYear ? 1 : -1;
            }
            this.calendarService.setInitialDate(selectedDate);
            if (direction === 0) {
                var currentViewStartDate = this.range.startTime, oneDay = 86400000, selectedDayDifference = Math.round((Date.UTC(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate()) -
                    Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) /
                    oneDay);
                for (var r = 0; r < 42; r += 1) {
                    dates[r].selected = false;
                }
                if (selectedDayDifference >= 0 && selectedDayDifference < 42) {
                    dates[selectedDayDifference].selected = true;
                    this.selectedDate = dates[selectedDayDifference];
                }
            }
            else {
                this.moveOnSelected = true;
                this.slideView(direction);
            }
        }
        this.onTimeSelected.emit({
            selectedTime: selectedDate,
            events: events,
            disabled: viewDate.disabled,
        });
    };
    MonthViewComponent.prototype.slideView = function (direction) {
        if (direction === 1) {
            this.slider.slideNext();
        }
        else if (direction === -1) {
            this.slider.slidePrev();
        }
    };
    MonthViewComponent.prototype.updateCurrentView = function (currentViewStartDate, view) {
        var currentCalendarDate = this.calendarService.initialDate, today = new Date(), oneDay = 86400000, selectedDayDifference = Math.round((Date.UTC(currentCalendarDate.getFullYear(), currentCalendarDate.getMonth(), currentCalendarDate.getDate()) -
            Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) /
            oneDay), currentDayDifference = Math.round((Date.UTC(today.getFullYear(), today.getMonth(), today.getDate()) -
            Date.UTC(currentViewStartDate.getFullYear(), currentViewStartDate.getMonth(), currentViewStartDate.getDate())) /
            oneDay);
        for (var r = 0; r < 42; r += 1) {
            view.dates[r].selected = false;
        }
        if (selectedDayDifference >= 0 &&
            selectedDayDifference < 42 &&
            !view.dates[selectedDayDifference].disabled &&
            (this.autoSelect || this.moveOnSelected)) {
            view.dates[selectedDayDifference].selected = true;
            this.selectedDate = view.dates[selectedDayDifference];
        }
        else {
            this.selectedDate = {
                date: null,
                events: [],
                label: null,
                secondary: null,
                disabled: false,
            };
        }
        if (currentDayDifference >= 0 && currentDayDifference < 42) {
            view.dates[currentDayDifference].current = true;
        }
    };
    MonthViewComponent.prototype.eventSelected = function (event) {
        this.onEventSelected.emit(event);
    };
    var MonthViewComponent_1;
    MonthViewComponent.ctorParameters = function () { return [
        { type: CalendarService }
    ]; };
    __decorate([
        ViewChild('monthSlider', { static: true })
    ], MonthViewComponent.prototype, "slider", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "monthviewDisplayEventTemplate", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "monthviewInactiveDisplayEventTemplate", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "monthviewEventDetailTemplate", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "formatDay", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "formatDayHeader", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "formatMonthTitle", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "eventSource", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "startingDayMonth", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "showEventDetail", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "noEventsLabel", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "autoSelect", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "markDisabled", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "locale", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "dateFormatter", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "dir", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "lockSwipeToPrev", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "lockSwipes", void 0);
    __decorate([
        Input()
    ], MonthViewComponent.prototype, "sliderOptions", void 0);
    __decorate([
        Output()
    ], MonthViewComponent.prototype, "onRangeChanged", void 0);
    __decorate([
        Output()
    ], MonthViewComponent.prototype, "onEventSelected", void 0);
    __decorate([
        Output()
    ], MonthViewComponent.prototype, "onTimeSelected", void 0);
    __decorate([
        Output()
    ], MonthViewComponent.prototype, "onTitleChanged", void 0);
    MonthViewComponent = MonthViewComponent_1 = __decorate([
        Component({
            selector: 'monthview',
            template: "\n\t\t<div>\n\t\t\t<ion-slides #monthSlider [options]=\"sliderOptions\" [dir]=\"dir\" (ionSlideDidChange)=\"onSlideChanged()\">\n\t\t\t\t<ion-slide>\n\t\t\t\t\t<table *ngIf=\"0 === currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[0].dayHeaders\">\n\t\t\t\t\t\t\t\t\t<small>{{ dayHeader }}</small>\n\t\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t\t<tr *ngFor=\"let row of [0, 1, 2, 3, 4, 5]\">\n\t\t\t\t\t\t\t\t<td\n\t\t\t\t\t\t\t\t\t*ngFor=\"let col of [0, 1, 2, 3, 4, 5, 6]\"\n\t\t\t\t\t\t\t\t\ttappable\n\t\t\t\t\t\t\t\t\t(click)=\"select(views[0].dates[row * 7 + col])\"\n\t\t\t\t\t\t\t\t\t[ngClass]=\"getHighlightClass(views[0].dates[row * 7 + col])\"\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{\n\t\t\t\t\t\t\t\t\t\t\tview: views[0],\n\t\t\t\t\t\t\t\t\t\t\trow: row,\n\t\t\t\t\t\t\t\t\t\t\tcol: col\n\t\t\t\t\t\t\t\t\t\t}\"\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t\t<table *ngIf=\"0 !== currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t\t<tr class=\"text-center\">\n\t\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[0].dayHeaders\">\n\t\t\t\t\t\t\t\t\t<small>{{ dayHeader }}</small>\n\t\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t\t<tr *ngFor=\"let row of [0, 1, 2, 3, 4, 5]\">\n\t\t\t\t\t\t\t\t<td *ngFor=\"let col of [0, 1, 2, 3, 4, 5, 6]\">\n\t\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewInactiveDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{\n\t\t\t\t\t\t\t\t\t\t\tview: views[0],\n\t\t\t\t\t\t\t\t\t\t\trow: row,\n\t\t\t\t\t\t\t\t\t\t\tcol: col\n\t\t\t\t\t\t\t\t\t\t}\"\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t</tr>\n\n\t\t\t\t\t\t\t<tr></tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t</ion-slide>\n\t\t\t\t<ion-slide>\n\t\t\t\t\t<table *ngIf=\"1 === currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[1].dayHeaders\">\n\t\t\t\t\t\t\t\t\t<small>{{ dayHeader }}</small>\n\t\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t\t<tr *ngFor=\"let row of [0, 1, 2, 3, 4, 5]\">\n\t\t\t\t\t\t\t\t<td\n\t\t\t\t\t\t\t\t\t*ngFor=\"let col of [0, 1, 2, 3, 4, 5, 6]\"\n\t\t\t\t\t\t\t\t\ttappable\n\t\t\t\t\t\t\t\t\t(click)=\"select(views[1].dates[row * 7 + col])\"\n\t\t\t\t\t\t\t\t\t[ngClass]=\"getHighlightClass(views[1].dates[row * 7 + col])\"\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{\n\t\t\t\t\t\t\t\t\t\t\tview: views[1],\n\t\t\t\t\t\t\t\t\t\t\trow: row,\n\t\t\t\t\t\t\t\t\t\t\tcol: col\n\t\t\t\t\t\t\t\t\t\t}\"\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t\t<table *ngIf=\"1 !== currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t\t<tr class=\"text-center\">\n\t\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[1].dayHeaders\">\n\t\t\t\t\t\t\t\t\t<small>{{ dayHeader }}</small>\n\t\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t\t<tr *ngFor=\"let row of [0, 1, 2, 3, 4, 5]\">\n\t\t\t\t\t\t\t\t<td *ngFor=\"let col of [0, 1, 2, 3, 4, 5, 6]\">\n\t\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewInactiveDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{\n\t\t\t\t\t\t\t\t\t\t\tview: views[1],\n\t\t\t\t\t\t\t\t\t\t\trow: row,\n\t\t\t\t\t\t\t\t\t\t\tcol: col\n\t\t\t\t\t\t\t\t\t\t}\"\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t</tr>\n\n\t\t\t\t\t\t\t<tr></tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t</ion-slide>\n\t\t\t\t<ion-slide>\n\t\t\t\t\t<table *ngIf=\"2 === currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[2].dayHeaders\">\n\t\t\t\t\t\t\t\t\t<small>{{ dayHeader }}</small>\n\t\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t\t<tr *ngFor=\"let row of [0, 1, 2, 3, 4, 5]\">\n\t\t\t\t\t\t\t\t<td\n\t\t\t\t\t\t\t\t\t*ngFor=\"let col of [0, 1, 2, 3, 4, 5, 6]\"\n\t\t\t\t\t\t\t\t\ttappable\n\t\t\t\t\t\t\t\t\t(click)=\"select(views[2].dates[row * 7 + col])\"\n\t\t\t\t\t\t\t\t\t[ngClass]=\"getHighlightClass(views[2].dates[row * 7 + col])\"\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{\n\t\t\t\t\t\t\t\t\t\t\tview: views[2],\n\t\t\t\t\t\t\t\t\t\t\trow: row,\n\t\t\t\t\t\t\t\t\t\t\tcol: col\n\t\t\t\t\t\t\t\t\t\t}\"\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t\t<table *ngIf=\"2 !== currentViewIndex\" class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t\t<tr class=\"text-center\">\n\t\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[2].dayHeaders\">\n\t\t\t\t\t\t\t\t\t<small>{{ dayHeader }}</small>\n\t\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t\t<tr *ngFor=\"let row of [0, 1, 2, 3, 4, 5]\">\n\t\t\t\t\t\t\t\t<td *ngFor=\"let col of [0, 1, 2, 3, 4, 5, 6]\">\n\t\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewInactiveDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{\n\t\t\t\t\t\t\t\t\t\t\tview: views[2],\n\t\t\t\t\t\t\t\t\t\t\trow: row,\n\t\t\t\t\t\t\t\t\t\t\tcol: col\n\t\t\t\t\t\t\t\t\t\t}\"\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t</tr>\n\n\t\t\t\t\t\t\t<tr></tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t</ion-slide>\n\t\t\t</ion-slides>\n\t\t\t<ng-template\n\t\t\t\t[ngTemplateOutlet]=\"monthviewEventDetailTemplate\"\n\t\t\t\t[ngTemplateOutletContext]=\"{\n\t\t\t\t\tshowEventDetail: showEventDetail,\n\t\t\t\t\tselectedDate: selectedDate,\n\t\t\t\t\tnoEventsLabel: noEventsLabel\n\t\t\t\t}\"\n\t\t\t>\n\t\t\t</ng-template>\n\t\t</div>\n\t",
            styles: ["\n\t\t\t.text-muted {\n\t\t\t\tcolor: #999;\n\t\t\t}\n\n\t\t\t.table-fixed {\n\t\t\t\ttable-layout: fixed;\n\t\t\t}\n\n\t\t\t.table {\n\t\t\t\twidth: 100%;\n\t\t\t\tmax-width: 100%;\n\t\t\t\tbackground-color: transparent;\n\t\t\t}\n\n\t\t\t.table > thead > tr > th,\n\t\t\t.table > tbody > tr > th,\n\t\t\t.table > tfoot > tr > th,\n\t\t\t.table > thead > tr > td,\n\t\t\t.table > tbody > tr > td,\n\t\t\t.table > tfoot > tr > td {\n\t\t\t\tpadding: 8px;\n\t\t\t\tline-height: 20px;\n\t\t\t\tvertical-align: top;\n\t\t\t}\n\n\t\t\t.table > thead > tr > th {\n\t\t\t\tvertical-align: bottom;\n\t\t\t\tborder-bottom: 2px solid #ddd;\n\t\t\t}\n\n\t\t\t.table > thead:first-child > tr:first-child > th,\n\t\t\t.table > thead:first-child > tr:first-child > td {\n\t\t\t\tborder-top: 0;\n\t\t\t}\n\n\t\t\t.table > tbody + tbody {\n\t\t\t\tborder-top: 2px solid #ddd;\n\t\t\t}\n\n\t\t\t.table-bordered {\n\t\t\t\tborder: 1px solid #ddd;\n\t\t\t}\n\n\t\t\t.table-bordered > thead > tr > th,\n\t\t\t.table-bordered > tbody > tr > th,\n\t\t\t.table-bordered > tfoot > tr > th,\n\t\t\t.table-bordered > thead > tr > td,\n\t\t\t.table-bordered > tbody > tr > td,\n\t\t\t.table-bordered > tfoot > tr > td {\n\t\t\t\tborder: 1px solid #ddd;\n\t\t\t}\n\n\t\t\t.table-bordered > thead > tr > th,\n\t\t\t.table-bordered > thead > tr > td {\n\t\t\t\tborder-bottom-width: 2px;\n\t\t\t}\n\n\t\t\t.table-striped > tbody > tr:nth-child(odd) > td,\n\t\t\t.table-striped > tbody > tr:nth-child(odd) > th {\n\t\t\t\tbackground-color: #f9f9f9;\n\t\t\t}\n\n\t\t\t.monthview-primary-with-event {\n\t\t\t\tbackground-color: #3a87ad;\n\t\t\t\tcolor: white;\n\t\t\t}\n\n\t\t\t.monthview-current {\n\t\t\t\tbackground-color: #f0f0f0;\n\t\t\t}\n\n\t\t\t.monthview-selected {\n\t\t\t\tbackground-color: #009900;\n\t\t\t\tcolor: white;\n\t\t\t}\n\n\t\t\t.monthview-datetable td.monthview-disabled {\n\t\t\t\tcolor: lightgrey;\n\t\t\t\tcursor: default;\n\t\t\t}\n\n\t\t\t.monthview-datetable th {\n\t\t\t\ttext-align: center;\n\t\t\t}\n\n\t\t\t.monthview-datetable td {\n\t\t\t\tcursor: pointer;\n\t\t\t\ttext-align: center;\n\t\t\t}\n\n\t\t\t.monthview-secondary-with-event {\n\t\t\t\tbackground-color: #d9edf7;\n\t\t\t}\n\n\t\t\t::-webkit-scrollbar,\n\t\t\t*::-webkit-scrollbar {\n\t\t\t\tdisplay: none;\n\t\t\t}\n\t\t"]
        })
    ], MonthViewComponent);
    return MonthViewComponent;
}());
export { MonthViewComponent };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9udGh2aWV3LmpzIiwic291cmNlUm9vdCI6Im5nOi8vQHBoZW1pdW0tY29zdGFpc2EvaW9uaWMyLWNhbGVuZGFyLyIsInNvdXJjZXMiOlsibW9udGh2aWV3LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQ04sU0FBUyxFQUdULEtBQUssRUFDTCxNQUFNLEVBQ04sWUFBWSxFQUVaLFNBQVMsR0FJVCxNQUFNLGVBQWUsQ0FBQztBQUV2QixPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFJM0MsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBc1NyRDtJQUNDLDRCQUFvQixlQUFnQztRQUFoQyxvQkFBZSxHQUFmLGVBQWUsQ0FBaUI7UUFpQjNDLGVBQVUsR0FBRyxJQUFJLENBQUM7UUFJbEIsUUFBRyxHQUFHLEVBQUUsQ0FBQztRQUtSLG1CQUFjLEdBQUcsSUFBSSxZQUFZLEVBQVUsQ0FBQztRQUM1QyxvQkFBZSxHQUFHLElBQUksWUFBWSxFQUFVLENBQUM7UUFDN0MsbUJBQWMsR0FBRyxJQUFJLFlBQVksQ0FBZ0IsSUFBSSxDQUFDLENBQUM7UUFDdkQsbUJBQWMsR0FBRyxJQUFJLFlBQVksQ0FBUyxJQUFJLENBQUMsQ0FBQztRQUVuRCxVQUFLLEdBQWlCLEVBQUUsQ0FBQztRQUN6QixxQkFBZ0IsR0FBRyxDQUFDLENBQUM7UUFHckIsU0FBSSxHQUFpQixPQUFPLENBQUM7UUFDN0IsY0FBUyxHQUFHLENBQUMsQ0FBQztRQUViLG1CQUFjLEdBQUcsS0FBSyxDQUFDO1FBQ3ZCLFdBQU0sR0FBRyxLQUFLLENBQUM7UUFDZixtQkFBYyxHQUFHLElBQUksQ0FBQztJQXhDeUIsQ0FBQzsyQkFENUMsa0JBQWtCO0lBb0R2QiwyQkFBUSxHQUFmLFVBQWdCLFNBQWUsRUFBRSxDQUFTO1FBQ3pDLElBQU0sS0FBSyxHQUFHLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUN6QixPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ1YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ2IsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFDekMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDdkM7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNkLENBQUM7SUFFRCxxQ0FBUSxHQUFSO1FBQUEsaUJBK0RDO1FBOURBLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQ3hCLElBQUksQ0FBQyxhQUFhLEdBQUcsRUFBRSxDQUFDO1NBQ3hCO1FBQ0QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBRS9CLElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLGtCQUFrQixFQUFFO1lBQ2hFLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQztTQUM1RDthQUFNO1lBQ04sSUFBTSxrQkFBZ0IsR0FBRyxJQUFJLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUMvQyxJQUFJLENBQUMsY0FBYyxHQUFHLFVBQVUsSUFBVTtnQkFDekMsT0FBTyxrQkFBZ0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUN6RCxDQUFDLENBQUM7U0FDRjtRQUVELElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLHdCQUF3QixFQUFFO1lBQ3RFLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLHdCQUF3QixDQUFDO1NBQ3hFO2FBQU07WUFDTixJQUFNLFVBQVEsR0FBRyxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDM0MsSUFBSSxDQUFDLG9CQUFvQixHQUFHLFVBQVUsSUFBVTtnQkFDL0MsT0FBTyxVQUFRLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7WUFDdkQsQ0FBQyxDQUFDO1NBQ0Y7UUFFRCxJQUFJLElBQUksQ0FBQyxhQUFhLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxvQkFBb0IsRUFBRTtZQUNsRSxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsb0JBQW9CLENBQUM7U0FDM0Q7YUFBTTtZQUNOLElBQU0sVUFBUSxHQUFHLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUMzQyxJQUFJLENBQUMsV0FBVyxHQUFHLFVBQVUsSUFBVTtnQkFDdEMsT0FBTyxVQUFRLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztZQUN4RCxDQUFDLENBQUM7U0FDRjtRQUVELElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRTtZQUN6QixJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNsQztRQUVELElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtZQUNwQixJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUM3QjtRQUVELElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNuQixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztRQUVuQixJQUFJLENBQUMsd0NBQXdDLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyw2QkFBNkIsQ0FBQyxTQUFTLENBQUMsVUFBQyxXQUFXO1lBQ3hILEtBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNwQixDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyw4QkFBOEIsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQztZQUN4RixLQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDckIsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsd0JBQXdCLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLFVBQUMsU0FBUztZQUN0RixJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUU7Z0JBQ3BCLEtBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLENBQUM7YUFDeEI7aUJBQU0sSUFBSSxTQUFTLEtBQUssQ0FBQyxDQUFDLEVBQUU7Z0JBQzVCLEtBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLENBQUM7YUFDeEI7UUFDRixDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyx3QkFBd0IsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUM7WUFDNUUsS0FBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUN0QixDQUFDLENBQUMsQ0FBQztJQUNKLENBQUM7SUFFRCx3Q0FBVyxHQUFYO1FBQ0MsSUFBSSxJQUFJLENBQUMsd0NBQXdDLEVBQUU7WUFDbEQsSUFBSSxDQUFDLHdDQUF3QyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzVELElBQUksQ0FBQyx3Q0FBd0MsR0FBRyxJQUFJLENBQUM7U0FDckQ7UUFFRCxJQUFJLElBQUksQ0FBQyw4QkFBOEIsRUFBRTtZQUN4QyxJQUFJLENBQUMsOEJBQThCLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDbEQsSUFBSSxDQUFDLDhCQUE4QixHQUFHLElBQUksQ0FBQztTQUMzQztRQUVELElBQUksSUFBSSxDQUFDLHdCQUF3QixFQUFFO1lBQ2xDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUM1QyxJQUFJLENBQUMsd0JBQXdCLEdBQUcsSUFBSSxDQUFDO1NBQ3JDO1FBRUQsSUFBSSxJQUFJLENBQUMsd0JBQXdCLEVBQUU7WUFDbEMsSUFBSSxDQUFDLHdCQUF3QixDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzVDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxJQUFJLENBQUM7U0FDckM7SUFDRixDQUFDO0lBRUQsd0NBQVcsR0FBWCxVQUFZLE9BQXNCO1FBQ2pDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ2pCLE9BQU87U0FDUDtRQUVELElBQU0saUJBQWlCLEdBQUcsT0FBTyxDQUFDLFdBQVcsQ0FBQztRQUM5QyxJQUFJLGlCQUFpQixJQUFJLGlCQUFpQixDQUFDLFlBQVksRUFBRTtZQUN4RCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7U0FDcEI7UUFFRCxJQUFNLGVBQWUsR0FBRyxPQUFPLENBQUMsZUFBZSxDQUFDO1FBQ2hELElBQUksZUFBZSxFQUFFO1lBQ3BCLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsQ0FBQztTQUMxRDtRQUVELElBQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUM7UUFDdEMsSUFBSSxVQUFVLEVBQUU7WUFDZixJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7U0FDaEQ7SUFDRixDQUFDO0lBRUQsNENBQWUsR0FBZjtRQUNDLElBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUM5QixJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBRUQsMkNBQWMsR0FBZDtRQUFBLGlCQTZCQztRQTVCQSxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDeEIsSUFBSSxDQUFDLGNBQWMsR0FBRyxLQUFLLENBQUM7WUFDNUIsT0FBTztTQUNQO1FBRUQsSUFBSSxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ2xCLElBQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDO1FBRS9DLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQUMsaUJBQWlCO1lBQ25ELGlCQUFpQixHQUFHLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2hELElBQUksS0FBSyxDQUFDLGlCQUFpQixDQUFDLEVBQUU7Z0JBQzdCLGlCQUFpQixHQUFHLGdCQUFnQixDQUFDO2FBQ3JDO1lBRUQsSUFBSSxpQkFBaUIsR0FBRyxnQkFBZ0IsS0FBSyxDQUFDLEVBQUU7Z0JBQy9DLFNBQVMsR0FBRyxDQUFDLENBQUM7YUFDZDtpQkFBTSxJQUFJLGlCQUFpQixLQUFLLENBQUMsSUFBSSxnQkFBZ0IsS0FBSyxDQUFDLEVBQUU7Z0JBQzdELFNBQVMsR0FBRyxDQUFDLENBQUM7Z0JBQ2QsS0FBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUNqQztpQkFBTSxJQUFJLGdCQUFnQixHQUFHLGlCQUFpQixLQUFLLENBQUMsRUFBRTtnQkFDdEQsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDO2FBQ2Y7aUJBQU0sSUFBSSxpQkFBaUIsS0FBSyxDQUFDLElBQUksZ0JBQWdCLEtBQUssQ0FBQyxFQUFFO2dCQUM3RCxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ2YsS0FBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUNqQztZQUNELEtBQUksQ0FBQyxnQkFBZ0IsR0FBRyxpQkFBaUIsQ0FBQztZQUMxQyxLQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3RCLENBQUMsQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQUVELGlDQUFJLEdBQUosVUFBSyxTQUFpQjtRQUNyQixJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUU7WUFDcEIsT0FBTztTQUNQO1FBQ0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7UUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUU7WUFDekIsSUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQ3hGLElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQ2xEO1FBQ0QsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ25CLElBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0lBQzdCLENBQUM7SUFFRCw2Q0FBZ0IsR0FBaEIsVUFBaUIsSUFBVTtRQUMxQixJQUFJLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDckIsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQ3RCLFFBQVEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ25DO1FBRUQsT0FBTztZQUNOLElBQUksTUFBQTtZQUNKLE1BQU0sRUFBRSxFQUFFO1lBQ1YsS0FBSyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDO1lBQ2hDLFNBQVMsRUFBRSxLQUFLO1lBQ2hCLFFBQVEsVUFBQTtTQUNSLENBQUM7SUFDSCxDQUFDO0lBRUQsd0NBQVcsR0FBWCxVQUFZLFNBQWU7UUFDMUIsSUFBTSxTQUFTLEdBQUcsU0FBUyxFQUMxQixJQUFJLEdBQUcsU0FBUyxDQUFDLE9BQU8sRUFBRSxFQUMxQixLQUFLLEdBQUcsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBRTVELElBQU0sS0FBSyxHQUFHLG9CQUFrQixDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDekQsSUFBTSxJQUFJLEdBQW9CLEVBQUUsQ0FBQztRQUNqQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzVCLElBQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNuRCxVQUFVLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxLQUFLLENBQUM7WUFDckQsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQztTQUNyQjtRQUVELElBQU0sVUFBVSxHQUFhLEVBQUUsQ0FBQztRQUNoQyxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzNCLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1NBQ3pEO1FBQ0QsT0FBTztZQUNOLEtBQUssRUFBRSxJQUFJO1lBQ1gsVUFBVSxZQUFBO1NBQ1YsQ0FBQztJQUNILENBQUM7SUFFRCw4Q0FBaUIsR0FBakIsVUFBa0IsSUFBbUI7UUFDcEMsSUFBSSxTQUFTLEdBQUcsRUFBRSxDQUFDO1FBRW5CLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNsQixJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ25CLFNBQVMsR0FBRyxnQ0FBZ0MsQ0FBQzthQUM3QztpQkFBTTtnQkFDTixTQUFTLEdBQUcsOEJBQThCLENBQUM7YUFDM0M7U0FDRDtRQUVELElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNsQixJQUFJLFNBQVMsRUFBRTtnQkFDZCxTQUFTLElBQUksR0FBRyxDQUFDO2FBQ2pCO1lBQ0QsU0FBUyxJQUFJLG9CQUFvQixDQUFDO1NBQ2xDO1FBRUQsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ2pCLElBQUksU0FBUyxFQUFFO2dCQUNkLFNBQVMsSUFBSSxHQUFHLENBQUM7YUFDakI7WUFDRCxTQUFTLElBQUksbUJBQW1CLENBQUM7U0FDakM7UUFFRCxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDbkIsSUFBSSxTQUFTLEVBQUU7Z0JBQ2QsU0FBUyxJQUFJLEdBQUcsQ0FBQzthQUNqQjtZQUNELFNBQVMsSUFBSSxZQUFZLENBQUM7U0FDMUI7UUFFRCxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7WUFDbEIsSUFBSSxTQUFTLEVBQUU7Z0JBQ2QsU0FBUyxJQUFJLEdBQUcsQ0FBQzthQUNqQjtZQUNELFNBQVMsSUFBSSxvQkFBb0IsQ0FBQztTQUNsQztRQUNELE9BQU8sU0FBUyxDQUFDO0lBQ2xCLENBQUM7SUFFRCxxQ0FBUSxHQUFSLFVBQVMsV0FBaUI7UUFDekIsSUFBTSxJQUFJLEdBQUcsV0FBVyxDQUFDLFdBQVcsRUFBRSxFQUNyQyxLQUFLLEdBQUcsV0FBVyxDQUFDLFFBQVEsRUFBRSxFQUM5QixlQUFlLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxzQ0FBc0M7UUFDNUYsVUFBVSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxlQUFlLENBQUMsTUFBTSxFQUFFLEVBQzdELDZCQUE2QixHQUFHLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxFQUM3RSxTQUFTLEdBQUcsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFFakQsSUFBSSw2QkFBNkIsR0FBRyxDQUFDLEVBQUU7WUFDdEMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLDZCQUE2QixHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQ3REO1FBRUQsSUFBTSxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDOUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFFeEMsT0FBTztZQUNOLFNBQVMsRUFBRSxTQUFTO1lBQ3BCLE9BQU8sRUFBRSxPQUFPO1NBQ2hCLENBQUM7SUFDSCxDQUFDO0lBRUQseUNBQVksR0FBWjtRQUNDLElBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQ3ZCLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUM5QixHQUFHLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQzFDLFNBQVMsR0FBRyxLQUFLLENBQUMsU0FBUyxFQUMzQixPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sRUFDdkIsWUFBWSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxFQUFFLFNBQVMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUMsRUFDM0YsVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxFQUFFLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRSxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsRUFDbkYsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUN4QyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEtBQUssRUFDMUMsTUFBTSxHQUFHLFFBQVEsRUFDakIsR0FBRyxHQUFHLE1BQU0sQ0FBQztRQUVkLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUMvQixJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUU7Z0JBQ3RCLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO2dCQUMxQixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQzthQUNyQjtTQUNEO1FBRUQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2hDLElBQU0sT0FBSyxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFDM0IsY0FBYyxHQUFHLE9BQUssQ0FBQyxTQUFTLEVBQ2hDLFlBQVksR0FBRyxPQUFLLENBQUMsT0FBTyxDQUFDO1lBRTlCLElBQUksaUJBQWlCLFNBQVEsRUFBRSxlQUFlLFNBQVEsQ0FBQztZQUN2RCxJQUFJLE9BQUssQ0FBQyxNQUFNLEVBQUU7Z0JBQ2pCLGlCQUFpQixHQUFHLGNBQWMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDN0MsZUFBZSxHQUFHLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQzthQUN6QztpQkFBTTtnQkFDTixpQkFBaUIsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxXQUFXLEVBQUUsRUFBRSxjQUFjLENBQUMsUUFBUSxFQUFFLEVBQUUsY0FBYyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7Z0JBQ2hILGVBQWUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUUsRUFBRSxZQUFZLENBQUMsUUFBUSxFQUFFLEVBQUUsWUFBWSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO2FBQzVHO1lBRUQsSUFBSSxlQUFlLElBQUksWUFBWSxJQUFJLGlCQUFpQixJQUFJLFVBQVUsRUFBRTtnQkFDdkUsU0FBUzthQUNUO1lBRUQsSUFBSSxtQkFBbUIsU0FBUSxFQUFFLGlCQUFpQixTQUFRLENBQUM7WUFFM0QsSUFBSSxpQkFBaUIsR0FBRyxZQUFZLEVBQUU7Z0JBQ3JDLG1CQUFtQixHQUFHLENBQUMsQ0FBQzthQUN4QjtpQkFBTTtnQkFDTixtQkFBbUIsR0FBRyxDQUFDLGlCQUFpQixHQUFHLFlBQVksQ0FBQyxHQUFHLE1BQU0sQ0FBQzthQUNsRTtZQUVELElBQUksZUFBZSxHQUFHLFVBQVUsRUFBRTtnQkFDakMsaUJBQWlCLEdBQUcsQ0FBQyxVQUFVLEdBQUcsWUFBWSxDQUFDLEdBQUcsTUFBTSxDQUFDO2FBQ3pEO2lCQUFNO2dCQUNOLGlCQUFpQixHQUFHLENBQUMsZUFBZSxHQUFHLFlBQVksQ0FBQyxHQUFHLE1BQU0sQ0FBQzthQUM5RDtZQUVELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQztZQUM1QyxJQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEdBQUcsQ0FBQyxDQUFDO1lBQ3BELE9BQU8sS0FBSyxHQUFHLFFBQVEsRUFBRTtnQkFDeEIsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7Z0JBQzdCLElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUM7Z0JBQ25DLElBQUksUUFBUSxFQUFFO29CQUNiLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBSyxDQUFDLENBQUM7aUJBQ3JCO3FCQUFNO29CQUNOLFFBQVEsR0FBRyxFQUFFLENBQUM7b0JBQ2QsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFLLENBQUMsQ0FBQztvQkFDckIsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUM7aUJBQy9CO2dCQUNELEtBQUssSUFBSSxDQUFDLENBQUM7YUFDWDtTQUNEO1FBRUQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQy9CLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRTtnQkFDdEIsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO2FBQ3hDO1NBQ0Q7UUFFRCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDcEIsSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDO1lBQ3pCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDL0IsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFO29CQUN0QixJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDN0IsWUFBWSxHQUFHLElBQUksQ0FBQztvQkFDcEIsTUFBTTtpQkFDTjthQUNEO1lBRUQsSUFBSSxZQUFZLEVBQUU7Z0JBQ2pCLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDO29CQUN4QixZQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJO29CQUNwQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNO29CQUNoQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRO2lCQUNwQyxDQUFDLENBQUM7YUFDSDtTQUNEO0lBQ0YsQ0FBQztJQUVELHdDQUFXLEdBQVg7UUFDQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUU3RCxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsSUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQzlCLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ2hDO1FBQ0QsSUFBSSxDQUFDLGVBQWUsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNqRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO1FBQ2hGLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRCxxQ0FBUSxHQUFSO1FBQ0MsSUFBTSxvQkFBb0IsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFDaEQsSUFBSSxHQUFHLG9CQUFvQixDQUFDLE9BQU8sRUFBRSxFQUNyQyxLQUFLLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQ3JFLElBQUksR0FBRyxvQkFBb0IsQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFDL0UsVUFBVSxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3BELE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRU8seUNBQVksR0FBcEIsVUFBcUIsTUFBYyxFQUFFLE1BQWM7UUFDbEQsSUFBSSxNQUFNLENBQUMsTUFBTSxFQUFFO1lBQ2xCLE9BQU8sQ0FBQyxDQUFDO1NBQ1Q7YUFBTSxJQUFJLE1BQU0sQ0FBQyxNQUFNLEVBQUU7WUFDekIsT0FBTyxDQUFDLENBQUMsQ0FBQztTQUNWO2FBQU07WUFDTixPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUMvRDtJQUNGLENBQUM7SUFFRCxtQ0FBTSxHQUFOLFVBQU8sUUFBdUI7UUFDN0IsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDaEIsT0FBTztTQUNQO1FBRUQsSUFBTSxZQUFZLEdBQUcsUUFBUSxDQUFDLElBQUksRUFDakMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUM7UUFFMUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7WUFDdkIsSUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxLQUFLLEVBQ3BELG1CQUFtQixHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxFQUN0RCxZQUFZLEdBQUcsbUJBQW1CLENBQUMsUUFBUSxFQUFFLEVBQzdDLFdBQVcsR0FBRyxtQkFBbUIsQ0FBQyxXQUFXLEVBQUUsRUFDL0MsYUFBYSxHQUFHLFlBQVksQ0FBQyxRQUFRLEVBQUUsRUFDdkMsWUFBWSxHQUFHLFlBQVksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUMzQyxJQUFJLFNBQVMsR0FBRyxDQUFDLENBQUM7WUFFbEIsSUFBSSxXQUFXLEtBQUssWUFBWSxFQUFFO2dCQUNqQyxJQUFJLFlBQVksS0FBSyxhQUFhLEVBQUU7b0JBQ25DLFNBQVMsR0FBRyxZQUFZLEdBQUcsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNsRDthQUNEO2lCQUFNO2dCQUNOLFNBQVMsR0FBRyxXQUFXLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2hEO1lBRUQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDbEQsSUFBSSxTQUFTLEtBQUssQ0FBQyxFQUFFO2dCQUNwQixJQUFNLG9CQUFvQixHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUNoRCxNQUFNLEdBQUcsUUFBUSxFQUNqQixxQkFBcUIsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUNqQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxFQUFFLFlBQVksQ0FBQyxRQUFRLEVBQUUsRUFBRSxZQUFZLENBQUMsT0FBTyxFQUFFLENBQUM7b0JBQ3JGLElBQUksQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsV0FBVyxFQUFFLEVBQUUsb0JBQW9CLENBQUMsUUFBUSxFQUFFLEVBQUUsb0JBQW9CLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztvQkFDOUcsTUFBTSxDQUNQLENBQUM7Z0JBRUgsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFO29CQUMvQixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztpQkFDMUI7Z0JBRUQsSUFBSSxxQkFBcUIsSUFBSSxDQUFDLElBQUkscUJBQXFCLEdBQUcsRUFBRSxFQUFFO29CQUM3RCxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO29CQUM3QyxJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO2lCQUNqRDthQUNEO2lCQUFNO2dCQUNOLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDO2dCQUMzQixJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2FBQzFCO1NBQ0Q7UUFFRCxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQztZQUN4QixZQUFZLEVBQUUsWUFBWTtZQUMxQixNQUFNLFFBQUE7WUFDTixRQUFRLEVBQUUsUUFBUSxDQUFDLFFBQVE7U0FDM0IsQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQUVELHNDQUFTLEdBQVQsVUFBVSxTQUFpQjtRQUMxQixJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUU7WUFDcEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQztTQUN4QjthQUFNLElBQUksU0FBUyxLQUFLLENBQUMsQ0FBQyxFQUFFO1lBQzVCLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLENBQUM7U0FDeEI7SUFDRixDQUFDO0lBRUQsOENBQWlCLEdBQWpCLFVBQWtCLG9CQUEwQixFQUFFLElBQWdCO1FBQzdELElBQU0sbUJBQW1CLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLEVBQzNELEtBQUssR0FBRyxJQUFJLElBQUksRUFBRSxFQUNsQixNQUFNLEdBQUcsUUFBUSxFQUNqQixxQkFBcUIsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUNqQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsV0FBVyxFQUFFLEVBQUUsbUJBQW1CLENBQUMsUUFBUSxFQUFFLEVBQUUsbUJBQW1CLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDMUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxXQUFXLEVBQUUsRUFBRSxvQkFBb0IsQ0FBQyxRQUFRLEVBQUUsRUFBRSxvQkFBb0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQzlHLE1BQU0sQ0FDUCxFQUNELG9CQUFvQixHQUFHLElBQUksQ0FBQyxLQUFLLENBQ2hDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLEVBQUUsS0FBSyxDQUFDLFFBQVEsRUFBRSxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNoRSxJQUFJLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLFdBQVcsRUFBRSxFQUFFLG9CQUFvQixDQUFDLFFBQVEsRUFBRSxFQUFFLG9CQUFvQixDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFDOUcsTUFBTSxDQUNQLENBQUM7UUFFSCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDL0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1NBQy9CO1FBRUQsSUFDQyxxQkFBcUIsSUFBSSxDQUFDO1lBQzFCLHFCQUFxQixHQUFHLEVBQUU7WUFDMUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDLENBQUMsUUFBUTtZQUMzQyxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUN2QztZQUNELElBQUksQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1lBQ2xELElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO1NBQ3REO2FBQU07WUFDTixJQUFJLENBQUMsWUFBWSxHQUFHO2dCQUNuQixJQUFJLEVBQUUsSUFBSTtnQkFDVixNQUFNLEVBQUUsRUFBRTtnQkFDVixLQUFLLEVBQUUsSUFBSTtnQkFDWCxTQUFTLEVBQUUsSUFBSTtnQkFDZixRQUFRLEVBQUUsS0FBSzthQUNmLENBQUM7U0FDRjtRQUVELElBQUksb0JBQW9CLElBQUksQ0FBQyxJQUFJLG9CQUFvQixHQUFHLEVBQUUsRUFBRTtZQUMzRCxJQUFJLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztTQUNoRDtJQUNGLENBQUM7SUFFRCwwQ0FBYSxHQUFiLFVBQWMsS0FBYTtRQUMxQixJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNsQyxDQUFDOzs7Z0JBemlCb0MsZUFBZTs7SUFDUjtRQUEzQyxTQUFTLENBQUMsYUFBYSxFQUFFLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxDQUFDO3NEQUFtQjtJQUc5RDtRQURDLEtBQUssRUFBRTs2RUFDMEU7SUFFbEY7UUFEQyxLQUFLLEVBQUU7cUZBQ2tGO0lBRTFGO1FBREMsS0FBSyxFQUFFOzRFQUN5RTtJQUV4RTtRQUFSLEtBQUssRUFBRTt5REFBbUI7SUFDbEI7UUFBUixLQUFLLEVBQUU7K0RBQXlCO0lBQ3hCO1FBQVIsS0FBSyxFQUFFO2dFQUEwQjtJQUN6QjtRQUFSLEtBQUssRUFBRTsyREFBdUI7SUFDdEI7UUFBUixLQUFLLEVBQUU7Z0VBQTBCO0lBQ3pCO1FBQVIsS0FBSyxFQUFFOytEQUEwQjtJQUN6QjtRQUFSLEtBQUssRUFBRTs2REFBdUI7SUFDdEI7UUFBUixLQUFLLEVBQUU7MERBQW1CO0lBQ2xCO1FBQVIsS0FBSyxFQUFFOzREQUF1QztJQUN0QztRQUFSLEtBQUssRUFBRTtzREFBZ0I7SUFDZjtRQUFSLEtBQUssRUFBRTs2REFBK0I7SUFDOUI7UUFBUixLQUFLLEVBQUU7bURBQVU7SUFDVDtRQUFSLEtBQUssRUFBRTsrREFBMEI7SUFDekI7UUFBUixLQUFLLEVBQUU7MERBQXFCO0lBQ3BCO1FBQVIsS0FBSyxFQUFFOzZEQUFvQjtJQUVsQjtRQUFULE1BQU0sRUFBRTs4REFBNkM7SUFDNUM7UUFBVCxNQUFNLEVBQUU7K0RBQThDO0lBQzdDO1FBQVQsTUFBTSxFQUFFOzhEQUF3RDtJQUN2RDtRQUFULE1BQU0sRUFBRTs4REFBaUQ7SUE5QjlDLGtCQUFrQjtRQW5TOUIsU0FBUyxDQUFDO1lBQ1YsUUFBUSxFQUFFLFdBQVc7WUFDckIsUUFBUSxFQUFFLHd2TkF5TFQ7cUJBRUEsOHVFQW1HQztTQUVGLENBQUM7T0FDVyxrQkFBa0IsQ0EyaUI5QjtJQUFELHlCQUFDO0NBQUEsQUEzaUJELElBMmlCQztTQTNpQlksa0JBQWtCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuXHRDb21wb25lbnQsXHJcblx0T25Jbml0LFxyXG5cdE9uQ2hhbmdlcyxcclxuXHRJbnB1dCxcclxuXHRPdXRwdXQsXHJcblx0RXZlbnRFbWl0dGVyLFxyXG5cdFNpbXBsZUNoYW5nZXMsXHJcblx0Vmlld0NoaWxkLFxyXG5cdFRlbXBsYXRlUmVmLFxyXG5cdE9uRGVzdHJveSxcclxuXHRBZnRlclZpZXdJbml0LFxyXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcclxuaW1wb3J0IHsgRGF0ZVBpcGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xyXG5pbXBvcnQgeyBJb25TbGlkZXMgfSBmcm9tICdAaW9uaWMvYW5ndWxhcic7XHJcblxyXG5pbXBvcnQgeyBJQ2FsZW5kYXJDb21wb25lbnQsIElFdmVudCwgSU1vbnRoVmlldywgSU1vbnRoVmlld1JvdywgSVRpbWVTZWxlY3RlZCwgSVJhbmdlLCBDYWxlbmRhck1vZGUsIElEYXRlRm9ybWF0dGVyIH0gZnJvbSAnLi9jYWxlbmRhcic7XHJcbmltcG9ydCB7IENhbGVuZGFyU2VydmljZSB9IGZyb20gJy4vY2FsZW5kYXIuc2VydmljZSc7XHJcbmltcG9ydCB7IElNb250aFZpZXdEaXNwbGF5RXZlbnRUZW1wbGF0ZUNvbnRleHQgfSBmcm9tICcuL2NhbGVuZGFyJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG5cdHNlbGVjdG9yOiAnbW9udGh2aWV3JyxcclxuXHR0ZW1wbGF0ZTogYFxyXG5cdFx0PGRpdj5cclxuXHRcdFx0PGlvbi1zbGlkZXMgI21vbnRoU2xpZGVyIFtvcHRpb25zXT1cInNsaWRlck9wdGlvbnNcIiBbZGlyXT1cImRpclwiIChpb25TbGlkZURpZENoYW5nZSk9XCJvblNsaWRlQ2hhbmdlZCgpXCI+XHJcblx0XHRcdFx0PGlvbi1zbGlkZT5cclxuXHRcdFx0XHRcdDx0YWJsZSAqbmdJZj1cIjAgPT09IGN1cnJlbnRWaWV3SW5kZXhcIiBjbGFzcz1cInRhYmxlIHRhYmxlLWJvcmRlcmVkIHRhYmxlLWZpeGVkIG1vbnRodmlldy1kYXRldGFibGVcIj5cclxuXHRcdFx0XHRcdFx0PHRoZWFkPlxyXG5cdFx0XHRcdFx0XHRcdDx0cj5cclxuXHRcdFx0XHRcdFx0XHRcdDx0aCAqbmdGb3I9XCJsZXQgZGF5SGVhZGVyIG9mIHZpZXdzWzBdLmRheUhlYWRlcnNcIj5cclxuXHRcdFx0XHRcdFx0XHRcdFx0PHNtYWxsPnt7IGRheUhlYWRlciB9fTwvc21hbGw+XHJcblx0XHRcdFx0XHRcdFx0XHQ8L3RoPlxyXG5cdFx0XHRcdFx0XHRcdDwvdHI+XHJcblx0XHRcdFx0XHRcdDwvdGhlYWQ+XHJcblx0XHRcdFx0XHRcdDx0Ym9keT5cclxuXHRcdFx0XHRcdFx0XHQ8dHIgKm5nRm9yPVwibGV0IHJvdyBvZiBbMCwgMSwgMiwgMywgNCwgNV1cIj5cclxuXHRcdFx0XHRcdFx0XHRcdDx0ZFxyXG5cdFx0XHRcdFx0XHRcdFx0XHQqbmdGb3I9XCJsZXQgY29sIG9mIFswLCAxLCAyLCAzLCA0LCA1LCA2XVwiXHJcblx0XHRcdFx0XHRcdFx0XHRcdHRhcHBhYmxlXHJcblx0XHRcdFx0XHRcdFx0XHRcdChjbGljayk9XCJzZWxlY3Qodmlld3NbMF0uZGF0ZXNbcm93ICogNyArIGNvbF0pXCJcclxuXHRcdFx0XHRcdFx0XHRcdFx0W25nQ2xhc3NdPVwiZ2V0SGlnaGxpZ2h0Q2xhc3Modmlld3NbMF0uZGF0ZXNbcm93ICogNyArIGNvbF0pXCJcclxuXHRcdFx0XHRcdFx0XHRcdD5cclxuXHRcdFx0XHRcdFx0XHRcdFx0PG5nLXRlbXBsYXRlXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0W25nVGVtcGxhdGVPdXRsZXRdPVwibW9udGh2aWV3RGlzcGxheUV2ZW50VGVtcGxhdGVcIlxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFtuZ1RlbXBsYXRlT3V0bGV0Q29udGV4dF09XCJ7XHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR2aWV3OiB2aWV3c1swXSxcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdHJvdzogcm93LFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y29sOiBjb2xcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHR9XCJcclxuXHRcdFx0XHRcdFx0XHRcdFx0PlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ8L25nLXRlbXBsYXRlPlxyXG5cdFx0XHRcdFx0XHRcdFx0PC90ZD5cclxuXHRcdFx0XHRcdFx0XHQ8L3RyPlxyXG5cdFx0XHRcdFx0XHQ8L3Rib2R5PlxyXG5cdFx0XHRcdFx0PC90YWJsZT5cclxuXHRcdFx0XHRcdDx0YWJsZSAqbmdJZj1cIjAgIT09IGN1cnJlbnRWaWV3SW5kZXhcIiBjbGFzcz1cInRhYmxlIHRhYmxlLWJvcmRlcmVkIHRhYmxlLWZpeGVkIG1vbnRodmlldy1kYXRldGFibGVcIj5cclxuXHRcdFx0XHRcdFx0PHRoZWFkPlxyXG5cdFx0XHRcdFx0XHRcdDx0ciBjbGFzcz1cInRleHQtY2VudGVyXCI+XHJcblx0XHRcdFx0XHRcdFx0XHQ8dGggKm5nRm9yPVwibGV0IGRheUhlYWRlciBvZiB2aWV3c1swXS5kYXlIZWFkZXJzXCI+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDxzbWFsbD57eyBkYXlIZWFkZXIgfX08L3NtYWxsPlxyXG5cdFx0XHRcdFx0XHRcdFx0PC90aD5cclxuXHRcdFx0XHRcdFx0XHQ8L3RyPlxyXG5cdFx0XHRcdFx0XHQ8L3RoZWFkPlxyXG5cdFx0XHRcdFx0XHQ8dGJvZHk+XHJcblx0XHRcdFx0XHRcdFx0PHRyICpuZ0Zvcj1cImxldCByb3cgb2YgWzAsIDEsIDIsIDMsIDQsIDVdXCI+XHJcblx0XHRcdFx0XHRcdFx0XHQ8dGQgKm5nRm9yPVwibGV0IGNvbCBvZiBbMCwgMSwgMiwgMywgNCwgNSwgNl1cIj5cclxuXHRcdFx0XHRcdFx0XHRcdFx0PG5nLXRlbXBsYXRlXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0W25nVGVtcGxhdGVPdXRsZXRdPVwibW9udGh2aWV3SW5hY3RpdmVEaXNwbGF5RXZlbnRUZW1wbGF0ZVwiXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0W25nVGVtcGxhdGVPdXRsZXRDb250ZXh0XT1cIntcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdHZpZXc6IHZpZXdzWzBdLFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0cm93OiByb3csXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjb2w6IGNvbFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdH1cIlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDwvbmctdGVtcGxhdGU+XHJcblx0XHRcdFx0XHRcdFx0XHQ8L3RkPlxyXG5cdFx0XHRcdFx0XHRcdDwvdHI+XHJcblxyXG5cdFx0XHRcdFx0XHRcdDx0cj48L3RyPlxyXG5cdFx0XHRcdFx0XHQ8L3Rib2R5PlxyXG5cdFx0XHRcdFx0PC90YWJsZT5cclxuXHRcdFx0XHQ8L2lvbi1zbGlkZT5cclxuXHRcdFx0XHQ8aW9uLXNsaWRlPlxyXG5cdFx0XHRcdFx0PHRhYmxlICpuZ0lmPVwiMSA9PT0gY3VycmVudFZpZXdJbmRleFwiIGNsYXNzPVwidGFibGUgdGFibGUtYm9yZGVyZWQgdGFibGUtZml4ZWQgbW9udGh2aWV3LWRhdGV0YWJsZVwiPlxyXG5cdFx0XHRcdFx0XHQ8dGhlYWQ+XHJcblx0XHRcdFx0XHRcdFx0PHRyPlxyXG5cdFx0XHRcdFx0XHRcdFx0PHRoICpuZ0Zvcj1cImxldCBkYXlIZWFkZXIgb2Ygdmlld3NbMV0uZGF5SGVhZGVyc1wiPlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ8c21hbGw+e3sgZGF5SGVhZGVyIH19PC9zbWFsbD5cclxuXHRcdFx0XHRcdFx0XHRcdDwvdGg+XHJcblx0XHRcdFx0XHRcdFx0PC90cj5cclxuXHRcdFx0XHRcdFx0PC90aGVhZD5cclxuXHRcdFx0XHRcdFx0PHRib2R5PlxyXG5cdFx0XHRcdFx0XHRcdDx0ciAqbmdGb3I9XCJsZXQgcm93IG9mIFswLCAxLCAyLCAzLCA0LCA1XVwiPlxyXG5cdFx0XHRcdFx0XHRcdFx0PHRkXHJcblx0XHRcdFx0XHRcdFx0XHRcdCpuZ0Zvcj1cImxldCBjb2wgb2YgWzAsIDEsIDIsIDMsIDQsIDUsIDZdXCJcclxuXHRcdFx0XHRcdFx0XHRcdFx0dGFwcGFibGVcclxuXHRcdFx0XHRcdFx0XHRcdFx0KGNsaWNrKT1cInNlbGVjdCh2aWV3c1sxXS5kYXRlc1tyb3cgKiA3ICsgY29sXSlcIlxyXG5cdFx0XHRcdFx0XHRcdFx0XHRbbmdDbGFzc109XCJnZXRIaWdobGlnaHRDbGFzcyh2aWV3c1sxXS5kYXRlc1tyb3cgKiA3ICsgY29sXSlcIlxyXG5cdFx0XHRcdFx0XHRcdFx0PlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ8bmctdGVtcGxhdGVcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRbbmdUZW1wbGF0ZU91dGxldF09XCJtb250aHZpZXdEaXNwbGF5RXZlbnRUZW1wbGF0ZVwiXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0W25nVGVtcGxhdGVPdXRsZXRDb250ZXh0XT1cIntcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdHZpZXc6IHZpZXdzWzFdLFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0cm93OiByb3csXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRjb2w6IGNvbFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdH1cIlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDwvbmctdGVtcGxhdGU+XHJcblx0XHRcdFx0XHRcdFx0XHQ8L3RkPlxyXG5cdFx0XHRcdFx0XHRcdDwvdHI+XHJcblx0XHRcdFx0XHRcdDwvdGJvZHk+XHJcblx0XHRcdFx0XHQ8L3RhYmxlPlxyXG5cdFx0XHRcdFx0PHRhYmxlICpuZ0lmPVwiMSAhPT0gY3VycmVudFZpZXdJbmRleFwiIGNsYXNzPVwidGFibGUgdGFibGUtYm9yZGVyZWQgdGFibGUtZml4ZWQgbW9udGh2aWV3LWRhdGV0YWJsZVwiPlxyXG5cdFx0XHRcdFx0XHQ8dGhlYWQ+XHJcblx0XHRcdFx0XHRcdFx0PHRyIGNsYXNzPVwidGV4dC1jZW50ZXJcIj5cclxuXHRcdFx0XHRcdFx0XHRcdDx0aCAqbmdGb3I9XCJsZXQgZGF5SGVhZGVyIG9mIHZpZXdzWzFdLmRheUhlYWRlcnNcIj5cclxuXHRcdFx0XHRcdFx0XHRcdFx0PHNtYWxsPnt7IGRheUhlYWRlciB9fTwvc21hbGw+XHJcblx0XHRcdFx0XHRcdFx0XHQ8L3RoPlxyXG5cdFx0XHRcdFx0XHRcdDwvdHI+XHJcblx0XHRcdFx0XHRcdDwvdGhlYWQ+XHJcblx0XHRcdFx0XHRcdDx0Ym9keT5cclxuXHRcdFx0XHRcdFx0XHQ8dHIgKm5nRm9yPVwibGV0IHJvdyBvZiBbMCwgMSwgMiwgMywgNCwgNV1cIj5cclxuXHRcdFx0XHRcdFx0XHRcdDx0ZCAqbmdGb3I9XCJsZXQgY29sIG9mIFswLCAxLCAyLCAzLCA0LCA1LCA2XVwiPlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ8bmctdGVtcGxhdGVcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRbbmdUZW1wbGF0ZU91dGxldF09XCJtb250aHZpZXdJbmFjdGl2ZURpc3BsYXlFdmVudFRlbXBsYXRlXCJcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRbbmdUZW1wbGF0ZU91dGxldENvbnRleHRdPVwie1xyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmlldzogdmlld3NbMV0sXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRyb3c6IHJvdyxcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNvbDogY29sXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0fVwiXHJcblx0XHRcdFx0XHRcdFx0XHRcdD5cclxuXHRcdFx0XHRcdFx0XHRcdFx0PC9uZy10ZW1wbGF0ZT5cclxuXHRcdFx0XHRcdFx0XHRcdDwvdGQ+XHJcblx0XHRcdFx0XHRcdFx0PC90cj5cclxuXHJcblx0XHRcdFx0XHRcdFx0PHRyPjwvdHI+XHJcblx0XHRcdFx0XHRcdDwvdGJvZHk+XHJcblx0XHRcdFx0XHQ8L3RhYmxlPlxyXG5cdFx0XHRcdDwvaW9uLXNsaWRlPlxyXG5cdFx0XHRcdDxpb24tc2xpZGU+XHJcblx0XHRcdFx0XHQ8dGFibGUgKm5nSWY9XCIyID09PSBjdXJyZW50Vmlld0luZGV4XCIgY2xhc3M9XCJ0YWJsZSB0YWJsZS1ib3JkZXJlZCB0YWJsZS1maXhlZCBtb250aHZpZXctZGF0ZXRhYmxlXCI+XHJcblx0XHRcdFx0XHRcdDx0aGVhZD5cclxuXHRcdFx0XHRcdFx0XHQ8dHI+XHJcblx0XHRcdFx0XHRcdFx0XHQ8dGggKm5nRm9yPVwibGV0IGRheUhlYWRlciBvZiB2aWV3c1syXS5kYXlIZWFkZXJzXCI+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDxzbWFsbD57eyBkYXlIZWFkZXIgfX08L3NtYWxsPlxyXG5cdFx0XHRcdFx0XHRcdFx0PC90aD5cclxuXHRcdFx0XHRcdFx0XHQ8L3RyPlxyXG5cdFx0XHRcdFx0XHQ8L3RoZWFkPlxyXG5cdFx0XHRcdFx0XHQ8dGJvZHk+XHJcblx0XHRcdFx0XHRcdFx0PHRyICpuZ0Zvcj1cImxldCByb3cgb2YgWzAsIDEsIDIsIDMsIDQsIDVdXCI+XHJcblx0XHRcdFx0XHRcdFx0XHQ8dGRcclxuXHRcdFx0XHRcdFx0XHRcdFx0Km5nRm9yPVwibGV0IGNvbCBvZiBbMCwgMSwgMiwgMywgNCwgNSwgNl1cIlxyXG5cdFx0XHRcdFx0XHRcdFx0XHR0YXBwYWJsZVxyXG5cdFx0XHRcdFx0XHRcdFx0XHQoY2xpY2spPVwic2VsZWN0KHZpZXdzWzJdLmRhdGVzW3JvdyAqIDcgKyBjb2xdKVwiXHJcblx0XHRcdFx0XHRcdFx0XHRcdFtuZ0NsYXNzXT1cImdldEhpZ2hsaWdodENsYXNzKHZpZXdzWzJdLmRhdGVzW3JvdyAqIDcgKyBjb2xdKVwiXHJcblx0XHRcdFx0XHRcdFx0XHQ+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDxuZy10ZW1wbGF0ZVxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFtuZ1RlbXBsYXRlT3V0bGV0XT1cIm1vbnRodmlld0Rpc3BsYXlFdmVudFRlbXBsYXRlXCJcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRbbmdUZW1wbGF0ZU91dGxldENvbnRleHRdPVwie1xyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0dmlldzogdmlld3NbMl0sXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRyb3c6IHJvdyxcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdGNvbDogY29sXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0fVwiXHJcblx0XHRcdFx0XHRcdFx0XHRcdD5cclxuXHRcdFx0XHRcdFx0XHRcdFx0PC9uZy10ZW1wbGF0ZT5cclxuXHRcdFx0XHRcdFx0XHRcdDwvdGQ+XHJcblx0XHRcdFx0XHRcdFx0PC90cj5cclxuXHRcdFx0XHRcdFx0PC90Ym9keT5cclxuXHRcdFx0XHRcdDwvdGFibGU+XHJcblx0XHRcdFx0XHQ8dGFibGUgKm5nSWY9XCIyICE9PSBjdXJyZW50Vmlld0luZGV4XCIgY2xhc3M9XCJ0YWJsZSB0YWJsZS1ib3JkZXJlZCB0YWJsZS1maXhlZCBtb250aHZpZXctZGF0ZXRhYmxlXCI+XHJcblx0XHRcdFx0XHRcdDx0aGVhZD5cclxuXHRcdFx0XHRcdFx0XHQ8dHIgY2xhc3M9XCJ0ZXh0LWNlbnRlclwiPlxyXG5cdFx0XHRcdFx0XHRcdFx0PHRoICpuZ0Zvcj1cImxldCBkYXlIZWFkZXIgb2Ygdmlld3NbMl0uZGF5SGVhZGVyc1wiPlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ8c21hbGw+e3sgZGF5SGVhZGVyIH19PC9zbWFsbD5cclxuXHRcdFx0XHRcdFx0XHRcdDwvdGg+XHJcblx0XHRcdFx0XHRcdFx0PC90cj5cclxuXHRcdFx0XHRcdFx0PC90aGVhZD5cclxuXHRcdFx0XHRcdFx0PHRib2R5PlxyXG5cdFx0XHRcdFx0XHRcdDx0ciAqbmdGb3I9XCJsZXQgcm93IG9mIFswLCAxLCAyLCAzLCA0LCA1XVwiPlxyXG5cdFx0XHRcdFx0XHRcdFx0PHRkICpuZ0Zvcj1cImxldCBjb2wgb2YgWzAsIDEsIDIsIDMsIDQsIDUsIDZdXCI+XHJcblx0XHRcdFx0XHRcdFx0XHRcdDxuZy10ZW1wbGF0ZVxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFtuZ1RlbXBsYXRlT3V0bGV0XT1cIm1vbnRodmlld0luYWN0aXZlRGlzcGxheUV2ZW50VGVtcGxhdGVcIlxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFtuZ1RlbXBsYXRlT3V0bGV0Q29udGV4dF09XCJ7XHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHR2aWV3OiB2aWV3c1syXSxcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdHJvdzogcm93LFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0Y29sOiBjb2xcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHR9XCJcclxuXHRcdFx0XHRcdFx0XHRcdFx0PlxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ8L25nLXRlbXBsYXRlPlxyXG5cdFx0XHRcdFx0XHRcdFx0PC90ZD5cclxuXHRcdFx0XHRcdFx0XHQ8L3RyPlxyXG5cclxuXHRcdFx0XHRcdFx0XHQ8dHI+PC90cj5cclxuXHRcdFx0XHRcdFx0PC90Ym9keT5cclxuXHRcdFx0XHRcdDwvdGFibGU+XHJcblx0XHRcdFx0PC9pb24tc2xpZGU+XHJcblx0XHRcdDwvaW9uLXNsaWRlcz5cclxuXHRcdFx0PG5nLXRlbXBsYXRlXHJcblx0XHRcdFx0W25nVGVtcGxhdGVPdXRsZXRdPVwibW9udGh2aWV3RXZlbnREZXRhaWxUZW1wbGF0ZVwiXHJcblx0XHRcdFx0W25nVGVtcGxhdGVPdXRsZXRDb250ZXh0XT1cIntcclxuXHRcdFx0XHRcdHNob3dFdmVudERldGFpbDogc2hvd0V2ZW50RGV0YWlsLFxyXG5cdFx0XHRcdFx0c2VsZWN0ZWREYXRlOiBzZWxlY3RlZERhdGUsXHJcblx0XHRcdFx0XHRub0V2ZW50c0xhYmVsOiBub0V2ZW50c0xhYmVsXHJcblx0XHRcdFx0fVwiXHJcblx0XHRcdD5cclxuXHRcdFx0PC9uZy10ZW1wbGF0ZT5cclxuXHRcdDwvZGl2PlxyXG5cdGAsXHJcblx0c3R5bGVzOiBbXHJcblx0XHRgXHJcblx0XHRcdC50ZXh0LW11dGVkIHtcclxuXHRcdFx0XHRjb2xvcjogIzk5OTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0LnRhYmxlLWZpeGVkIHtcclxuXHRcdFx0XHR0YWJsZS1sYXlvdXQ6IGZpeGVkO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQudGFibGUge1xyXG5cdFx0XHRcdHdpZHRoOiAxMDAlO1xyXG5cdFx0XHRcdG1heC13aWR0aDogMTAwJTtcclxuXHRcdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0LnRhYmxlID4gdGhlYWQgPiB0ciA+IHRoLFxyXG5cdFx0XHQudGFibGUgPiB0Ym9keSA+IHRyID4gdGgsXHJcblx0XHRcdC50YWJsZSA+IHRmb290ID4gdHIgPiB0aCxcclxuXHRcdFx0LnRhYmxlID4gdGhlYWQgPiB0ciA+IHRkLFxyXG5cdFx0XHQudGFibGUgPiB0Ym9keSA+IHRyID4gdGQsXHJcblx0XHRcdC50YWJsZSA+IHRmb290ID4gdHIgPiB0ZCB7XHJcblx0XHRcdFx0cGFkZGluZzogOHB4O1xyXG5cdFx0XHRcdGxpbmUtaGVpZ2h0OiAyMHB4O1xyXG5cdFx0XHRcdHZlcnRpY2FsLWFsaWduOiB0b3A7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdC50YWJsZSA+IHRoZWFkID4gdHIgPiB0aCB7XHJcblx0XHRcdFx0dmVydGljYWwtYWxpZ246IGJvdHRvbTtcclxuXHRcdFx0XHRib3JkZXItYm90dG9tOiAycHggc29saWQgI2RkZDtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0LnRhYmxlID4gdGhlYWQ6Zmlyc3QtY2hpbGQgPiB0cjpmaXJzdC1jaGlsZCA+IHRoLFxyXG5cdFx0XHQudGFibGUgPiB0aGVhZDpmaXJzdC1jaGlsZCA+IHRyOmZpcnN0LWNoaWxkID4gdGQge1xyXG5cdFx0XHRcdGJvcmRlci10b3A6IDA7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdC50YWJsZSA+IHRib2R5ICsgdGJvZHkge1xyXG5cdFx0XHRcdGJvcmRlci10b3A6IDJweCBzb2xpZCAjZGRkO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQudGFibGUtYm9yZGVyZWQge1xyXG5cdFx0XHRcdGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdC50YWJsZS1ib3JkZXJlZCA+IHRoZWFkID4gdHIgPiB0aCxcclxuXHRcdFx0LnRhYmxlLWJvcmRlcmVkID4gdGJvZHkgPiB0ciA+IHRoLFxyXG5cdFx0XHQudGFibGUtYm9yZGVyZWQgPiB0Zm9vdCA+IHRyID4gdGgsXHJcblx0XHRcdC50YWJsZS1ib3JkZXJlZCA+IHRoZWFkID4gdHIgPiB0ZCxcclxuXHRcdFx0LnRhYmxlLWJvcmRlcmVkID4gdGJvZHkgPiB0ciA+IHRkLFxyXG5cdFx0XHQudGFibGUtYm9yZGVyZWQgPiB0Zm9vdCA+IHRyID4gdGQge1xyXG5cdFx0XHRcdGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdC50YWJsZS1ib3JkZXJlZCA+IHRoZWFkID4gdHIgPiB0aCxcclxuXHRcdFx0LnRhYmxlLWJvcmRlcmVkID4gdGhlYWQgPiB0ciA+IHRkIHtcclxuXHRcdFx0XHRib3JkZXItYm90dG9tLXdpZHRoOiAycHg7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdC50YWJsZS1zdHJpcGVkID4gdGJvZHkgPiB0cjpudGgtY2hpbGQob2RkKSA+IHRkLFxyXG5cdFx0XHQudGFibGUtc3RyaXBlZCA+IHRib2R5ID4gdHI6bnRoLWNoaWxkKG9kZCkgPiB0aCB7XHJcblx0XHRcdFx0YmFja2dyb3VuZC1jb2xvcjogI2Y5ZjlmOTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0Lm1vbnRodmlldy1wcmltYXJ5LXdpdGgtZXZlbnQge1xyXG5cdFx0XHRcdGJhY2tncm91bmQtY29sb3I6ICMzYTg3YWQ7XHJcblx0XHRcdFx0Y29sb3I6IHdoaXRlO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQubW9udGh2aWV3LWN1cnJlbnQge1xyXG5cdFx0XHRcdGJhY2tncm91bmQtY29sb3I6ICNmMGYwZjA7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdC5tb250aHZpZXctc2VsZWN0ZWQge1xyXG5cdFx0XHRcdGJhY2tncm91bmQtY29sb3I6ICMwMDk5MDA7XHJcblx0XHRcdFx0Y29sb3I6IHdoaXRlO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQubW9udGh2aWV3LWRhdGV0YWJsZSB0ZC5tb250aHZpZXctZGlzYWJsZWQge1xyXG5cdFx0XHRcdGNvbG9yOiBsaWdodGdyZXk7XHJcblx0XHRcdFx0Y3Vyc29yOiBkZWZhdWx0O1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQubW9udGh2aWV3LWRhdGV0YWJsZSB0aCB7XHJcblx0XHRcdFx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHQubW9udGh2aWV3LWRhdGV0YWJsZSB0ZCB7XHJcblx0XHRcdFx0Y3Vyc29yOiBwb2ludGVyO1xyXG5cdFx0XHRcdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0Lm1vbnRodmlldy1zZWNvbmRhcnktd2l0aC1ldmVudCB7XHJcblx0XHRcdFx0YmFja2dyb3VuZC1jb2xvcjogI2Q5ZWRmNztcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0Ojotd2Via2l0LXNjcm9sbGJhcixcclxuXHRcdFx0Kjo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG5cdFx0XHRcdGRpc3BsYXk6IG5vbmU7XHJcblx0XHRcdH1cclxuXHRcdGAsXHJcblx0XSxcclxufSlcclxuZXhwb3J0IGNsYXNzIE1vbnRoVmlld0NvbXBvbmVudCBpbXBsZW1lbnRzIElDYWxlbmRhckNvbXBvbmVudCwgT25Jbml0LCBPbkRlc3Ryb3ksIE9uQ2hhbmdlcywgQWZ0ZXJWaWV3SW5pdCB7XHJcblx0Y29uc3RydWN0b3IocHJpdmF0ZSBjYWxlbmRhclNlcnZpY2U6IENhbGVuZGFyU2VydmljZSkge31cclxuXHRAVmlld0NoaWxkKCdtb250aFNsaWRlcicsIHsgc3RhdGljOiB0cnVlIH0pIHNsaWRlcjogSW9uU2xpZGVzO1xyXG5cclxuXHRASW5wdXQoKVxyXG5cdG1vbnRodmlld0Rpc3BsYXlFdmVudFRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxJTW9udGhWaWV3RGlzcGxheUV2ZW50VGVtcGxhdGVDb250ZXh0PjtcclxuXHRASW5wdXQoKVxyXG5cdG1vbnRodmlld0luYWN0aXZlRGlzcGxheUV2ZW50VGVtcGxhdGU6IFRlbXBsYXRlUmVmPElNb250aFZpZXdEaXNwbGF5RXZlbnRUZW1wbGF0ZUNvbnRleHQ+O1xyXG5cdEBJbnB1dCgpXHJcblx0bW9udGh2aWV3RXZlbnREZXRhaWxUZW1wbGF0ZTogVGVtcGxhdGVSZWY8SU1vbnRoVmlld0Rpc3BsYXlFdmVudFRlbXBsYXRlQ29udGV4dD47XHJcblxyXG5cdEBJbnB1dCgpIGZvcm1hdERheTogc3RyaW5nO1xyXG5cdEBJbnB1dCgpIGZvcm1hdERheUhlYWRlcjogc3RyaW5nO1xyXG5cdEBJbnB1dCgpIGZvcm1hdE1vbnRoVGl0bGU6IHN0cmluZztcclxuXHRASW5wdXQoKSBldmVudFNvdXJjZTogSUV2ZW50W107XHJcblx0QElucHV0KCkgc3RhcnRpbmdEYXlNb250aDogbnVtYmVyO1xyXG5cdEBJbnB1dCgpIHNob3dFdmVudERldGFpbDogYm9vbGVhbjtcclxuXHRASW5wdXQoKSBub0V2ZW50c0xhYmVsOiBzdHJpbmc7XHJcblx0QElucHV0KCkgYXV0b1NlbGVjdCA9IHRydWU7XHJcblx0QElucHV0KCkgbWFya0Rpc2FibGVkOiAoZGF0ZTogRGF0ZSkgPT4gYm9vbGVhbjtcclxuXHRASW5wdXQoKSBsb2NhbGU6IHN0cmluZztcclxuXHRASW5wdXQoKSBkYXRlRm9ybWF0dGVyOiBJRGF0ZUZvcm1hdHRlcjtcclxuXHRASW5wdXQoKSBkaXIgPSAnJztcclxuXHRASW5wdXQoKSBsb2NrU3dpcGVUb1ByZXY6IGJvb2xlYW47XHJcblx0QElucHV0KCkgbG9ja1N3aXBlczogYm9vbGVhbjtcclxuXHRASW5wdXQoKSBzbGlkZXJPcHRpb25zOiBhbnk7XHJcblxyXG5cdEBPdXRwdXQoKSBvblJhbmdlQ2hhbmdlZCA9IG5ldyBFdmVudEVtaXR0ZXI8SVJhbmdlPigpO1xyXG5cdEBPdXRwdXQoKSBvbkV2ZW50U2VsZWN0ZWQgPSBuZXcgRXZlbnRFbWl0dGVyPElFdmVudD4oKTtcclxuXHRAT3V0cHV0KCkgb25UaW1lU2VsZWN0ZWQgPSBuZXcgRXZlbnRFbWl0dGVyPElUaW1lU2VsZWN0ZWQ+KHRydWUpO1xyXG5cdEBPdXRwdXQoKSBvblRpdGxlQ2hhbmdlZCA9IG5ldyBFdmVudEVtaXR0ZXI8c3RyaW5nPih0cnVlKTtcclxuXHJcblx0cHVibGljIHZpZXdzOiBJTW9udGhWaWV3W10gPSBbXTtcclxuXHRwdWJsaWMgY3VycmVudFZpZXdJbmRleCA9IDA7XHJcblx0cHVibGljIHNlbGVjdGVkRGF0ZTogSU1vbnRoVmlld1JvdztcclxuXHRwdWJsaWMgcmFuZ2U6IElSYW5nZTtcclxuXHRwdWJsaWMgbW9kZTogQ2FsZW5kYXJNb2RlID0gJ21vbnRoJztcclxuXHRwdWJsaWMgZGlyZWN0aW9uID0gMDtcclxuXHJcblx0cHJpdmF0ZSBtb3ZlT25TZWxlY3RlZCA9IGZhbHNlO1xyXG5cdHByaXZhdGUgaW5pdGVkID0gZmFsc2U7XHJcblx0cHJpdmF0ZSBjYWxsYmFja09uSW5pdCA9IHRydWU7XHJcblxyXG5cdHByaXZhdGUgY3VycmVudERhdGVDaGFuZ2VkRnJvbVBhcmVudFN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xyXG5cdHByaXZhdGUgZXZlbnRTb3VyY2VDaGFuZ2VkU3Vic2NyaXB0aW9uOiBTdWJzY3JpcHRpb247XHJcblx0cHJpdmF0ZSBzbGlkZUNoYW5nZWRTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcclxuXHRwcml2YXRlIHNsaWRlVXBkYXRlZFN1YnNjcmlwdGlvbjogU3Vic2NyaXB0aW9uO1xyXG5cclxuXHRwcml2YXRlIGZvcm1hdERheUxhYmVsOiAoZGF0ZTogRGF0ZSkgPT4gc3RyaW5nO1xyXG5cdHByaXZhdGUgZm9ybWF0RGF5SGVhZGVyTGFiZWw6IChkYXRlOiBEYXRlKSA9PiBzdHJpbmc7XHJcblx0cHJpdmF0ZSBmb3JtYXRUaXRsZTogKGRhdGU6IERhdGUpID0+IHN0cmluZztcclxuXHJcblx0c3RhdGljIGdldERhdGVzKHN0YXJ0RGF0ZTogRGF0ZSwgbjogbnVtYmVyKTogRGF0ZVtdIHtcclxuXHRcdGNvbnN0IGRhdGVzID0gbmV3IEFycmF5KG4pLFxyXG5cdFx0XHRjdXJyZW50ID0gbmV3IERhdGUoc3RhcnREYXRlLmdldFRpbWUoKSk7XHJcblx0XHRsZXQgaSA9IDA7XHJcblx0XHR3aGlsZSAoaSA8IG4pIHtcclxuXHRcdFx0ZGF0ZXNbaSsrXSA9IG5ldyBEYXRlKGN1cnJlbnQuZ2V0VGltZSgpKTtcclxuXHRcdFx0Y3VycmVudC5zZXREYXRlKGN1cnJlbnQuZ2V0RGF0ZSgpICsgMSk7XHJcblx0XHR9XHJcblx0XHRyZXR1cm4gZGF0ZXM7XHJcblx0fVxyXG5cclxuXHRuZ09uSW5pdCgpIHtcclxuXHRcdGlmICghdGhpcy5zbGlkZXJPcHRpb25zKSB7XHJcblx0XHRcdHRoaXMuc2xpZGVyT3B0aW9ucyA9IHt9O1xyXG5cdFx0fVxyXG5cdFx0dGhpcy5zbGlkZXJPcHRpb25zLmxvb3AgPSB0cnVlO1xyXG5cclxuXHRcdGlmICh0aGlzLmRhdGVGb3JtYXR0ZXIgJiYgdGhpcy5kYXRlRm9ybWF0dGVyLmZvcm1hdE1vbnRoVmlld0RheSkge1xyXG5cdFx0XHR0aGlzLmZvcm1hdERheUxhYmVsID0gdGhpcy5kYXRlRm9ybWF0dGVyLmZvcm1hdE1vbnRoVmlld0RheTtcclxuXHRcdH0gZWxzZSB7XHJcblx0XHRcdGNvbnN0IGRheUxhYmVsRGF0ZVBpcGUgPSBuZXcgRGF0ZVBpcGUoJ2VuLVVTJyk7XHJcblx0XHRcdHRoaXMuZm9ybWF0RGF5TGFiZWwgPSBmdW5jdGlvbiAoZGF0ZTogRGF0ZSkge1xyXG5cdFx0XHRcdHJldHVybiBkYXlMYWJlbERhdGVQaXBlLnRyYW5zZm9ybShkYXRlLCB0aGlzLmZvcm1hdERheSk7XHJcblx0XHRcdH07XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKHRoaXMuZGF0ZUZvcm1hdHRlciAmJiB0aGlzLmRhdGVGb3JtYXR0ZXIuZm9ybWF0TW9udGhWaWV3RGF5SGVhZGVyKSB7XHJcblx0XHRcdHRoaXMuZm9ybWF0RGF5SGVhZGVyTGFiZWwgPSB0aGlzLmRhdGVGb3JtYXR0ZXIuZm9ybWF0TW9udGhWaWV3RGF5SGVhZGVyO1xyXG5cdFx0fSBlbHNlIHtcclxuXHRcdFx0Y29uc3QgZGF0ZVBpcGUgPSBuZXcgRGF0ZVBpcGUodGhpcy5sb2NhbGUpO1xyXG5cdFx0XHR0aGlzLmZvcm1hdERheUhlYWRlckxhYmVsID0gZnVuY3Rpb24gKGRhdGU6IERhdGUpIHtcclxuXHRcdFx0XHRyZXR1cm4gZGF0ZVBpcGUudHJhbnNmb3JtKGRhdGUsIHRoaXMuZm9ybWF0RGF5SGVhZGVyKTtcclxuXHRcdFx0fTtcclxuXHRcdH1cclxuXHJcblx0XHRpZiAodGhpcy5kYXRlRm9ybWF0dGVyICYmIHRoaXMuZGF0ZUZvcm1hdHRlci5mb3JtYXRNb250aFZpZXdUaXRsZSkge1xyXG5cdFx0XHR0aGlzLmZvcm1hdFRpdGxlID0gdGhpcy5kYXRlRm9ybWF0dGVyLmZvcm1hdE1vbnRoVmlld1RpdGxlO1xyXG5cdFx0fSBlbHNlIHtcclxuXHRcdFx0Y29uc3QgZGF0ZVBpcGUgPSBuZXcgRGF0ZVBpcGUodGhpcy5sb2NhbGUpO1xyXG5cdFx0XHR0aGlzLmZvcm1hdFRpdGxlID0gZnVuY3Rpb24gKGRhdGU6IERhdGUpIHtcclxuXHRcdFx0XHRyZXR1cm4gZGF0ZVBpcGUudHJhbnNmb3JtKGRhdGUsIHRoaXMuZm9ybWF0TW9udGhUaXRsZSk7XHJcblx0XHRcdH07XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKHRoaXMubG9ja1N3aXBlVG9QcmV2KSB7XHJcblx0XHRcdHRoaXMuc2xpZGVyLmxvY2tTd2lwZVRvUHJldih0cnVlKTtcclxuXHRcdH1cclxuXHJcblx0XHRpZiAodGhpcy5sb2NrU3dpcGVzKSB7XHJcblx0XHRcdHRoaXMuc2xpZGVyLmxvY2tTd2lwZXModHJ1ZSk7XHJcblx0XHR9XHJcblxyXG5cdFx0dGhpcy5yZWZyZXNoVmlldygpO1xyXG5cdFx0dGhpcy5pbml0ZWQgPSB0cnVlO1xyXG5cclxuXHRcdHRoaXMuY3VycmVudERhdGVDaGFuZ2VkRnJvbVBhcmVudFN1YnNjcmlwdGlvbiA9IHRoaXMuY2FsZW5kYXJTZXJ2aWNlLmN1cnJlbnREYXRlQ2hhbmdlZEZyb21QYXJlbnQkLnN1YnNjcmliZSgoY3VycmVudERhdGUpID0+IHtcclxuXHRcdFx0dGhpcy5yZWZyZXNoVmlldygpO1xyXG5cdFx0fSk7XHJcblxyXG5cdFx0dGhpcy5ldmVudFNvdXJjZUNoYW5nZWRTdWJzY3JpcHRpb24gPSB0aGlzLmNhbGVuZGFyU2VydmljZS5ldmVudFNvdXJjZUNoYW5nZWQkLnN1YnNjcmliZSgoKSA9PiB7XHJcblx0XHRcdHRoaXMub25EYXRhTG9hZGVkKCk7XHJcblx0XHR9KTtcclxuXHJcblx0XHR0aGlzLnNsaWRlQ2hhbmdlZFN1YnNjcmlwdGlvbiA9IHRoaXMuY2FsZW5kYXJTZXJ2aWNlLnNsaWRlQ2hhbmdlZCQuc3Vic2NyaWJlKChkaXJlY3Rpb24pID0+IHtcclxuXHRcdFx0aWYgKGRpcmVjdGlvbiA9PT0gMSkge1xyXG5cdFx0XHRcdHRoaXMuc2xpZGVyLnNsaWRlTmV4dCgpO1xyXG5cdFx0XHR9IGVsc2UgaWYgKGRpcmVjdGlvbiA9PT0gLTEpIHtcclxuXHRcdFx0XHR0aGlzLnNsaWRlci5zbGlkZVByZXYoKTtcclxuXHRcdFx0fVxyXG5cdFx0fSk7XHJcblxyXG5cdFx0dGhpcy5zbGlkZVVwZGF0ZWRTdWJzY3JpcHRpb24gPSB0aGlzLmNhbGVuZGFyU2VydmljZS5zbGlkZVVwZGF0ZWQkLnN1YnNjcmliZSgoKSA9PiB7XHJcblx0XHRcdHRoaXMuc2xpZGVyLnVwZGF0ZSgpO1xyXG5cdFx0fSk7XHJcblx0fVxyXG5cclxuXHRuZ09uRGVzdHJveSgpIHtcclxuXHRcdGlmICh0aGlzLmN1cnJlbnREYXRlQ2hhbmdlZEZyb21QYXJlbnRTdWJzY3JpcHRpb24pIHtcclxuXHRcdFx0dGhpcy5jdXJyZW50RGF0ZUNoYW5nZWRGcm9tUGFyZW50U3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcblx0XHRcdHRoaXMuY3VycmVudERhdGVDaGFuZ2VkRnJvbVBhcmVudFN1YnNjcmlwdGlvbiA9IG51bGw7XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKHRoaXMuZXZlbnRTb3VyY2VDaGFuZ2VkU3Vic2NyaXB0aW9uKSB7XHJcblx0XHRcdHRoaXMuZXZlbnRTb3VyY2VDaGFuZ2VkU3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKCk7XHJcblx0XHRcdHRoaXMuZXZlbnRTb3VyY2VDaGFuZ2VkU3Vic2NyaXB0aW9uID0gbnVsbDtcclxuXHRcdH1cclxuXHJcblx0XHRpZiAodGhpcy5zbGlkZUNoYW5nZWRTdWJzY3JpcHRpb24pIHtcclxuXHRcdFx0dGhpcy5zbGlkZUNoYW5nZWRTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuXHRcdFx0dGhpcy5zbGlkZUNoYW5nZWRTdWJzY3JpcHRpb24gPSBudWxsO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmICh0aGlzLnNsaWRlVXBkYXRlZFN1YnNjcmlwdGlvbikge1xyXG5cdFx0XHR0aGlzLnNsaWRlVXBkYXRlZFN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xyXG5cdFx0XHR0aGlzLnNsaWRlVXBkYXRlZFN1YnNjcmlwdGlvbiA9IG51bGw7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHRuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XHJcblx0XHRpZiAoIXRoaXMuaW5pdGVkKSB7XHJcblx0XHRcdHJldHVybjtcclxuXHRcdH1cclxuXHJcblx0XHRjb25zdCBldmVudFNvdXJjZUNoYW5nZSA9IGNoYW5nZXMuZXZlbnRTb3VyY2U7XHJcblx0XHRpZiAoZXZlbnRTb3VyY2VDaGFuZ2UgJiYgZXZlbnRTb3VyY2VDaGFuZ2UuY3VycmVudFZhbHVlKSB7XHJcblx0XHRcdHRoaXMub25EYXRhTG9hZGVkKCk7XHJcblx0XHR9XHJcblxyXG5cdFx0Y29uc3QgbG9ja1N3aXBlVG9QcmV2ID0gY2hhbmdlcy5sb2NrU3dpcGVUb1ByZXY7XHJcblx0XHRpZiAobG9ja1N3aXBlVG9QcmV2KSB7XHJcblx0XHRcdHRoaXMuc2xpZGVyLmxvY2tTd2lwZVRvUHJldihsb2NrU3dpcGVUb1ByZXYuY3VycmVudFZhbHVlKTtcclxuXHRcdH1cclxuXHJcblx0XHRjb25zdCBsb2NrU3dpcGVzID0gY2hhbmdlcy5sb2NrU3dpcGVzO1xyXG5cdFx0aWYgKGxvY2tTd2lwZXMpIHtcclxuXHRcdFx0dGhpcy5zbGlkZXIubG9ja1N3aXBlcyhsb2NrU3dpcGVzLmN1cnJlbnRWYWx1ZSk7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHRuZ0FmdGVyVmlld0luaXQoKSB7XHJcblx0XHRjb25zdCB0aXRsZSA9IHRoaXMuZ2V0VGl0bGUoKTtcclxuXHRcdHRoaXMub25UaXRsZUNoYW5nZWQuZW1pdCh0aXRsZSk7XHJcblx0fVxyXG5cclxuXHRvblNsaWRlQ2hhbmdlZCgpIHtcclxuXHRcdGlmICh0aGlzLmNhbGxiYWNrT25Jbml0KSB7XHJcblx0XHRcdHRoaXMuY2FsbGJhY2tPbkluaXQgPSBmYWxzZTtcclxuXHRcdFx0cmV0dXJuO1xyXG5cdFx0fVxyXG5cclxuXHRcdGxldCBkaXJlY3Rpb24gPSAwO1xyXG5cdFx0Y29uc3QgY3VycmVudFZpZXdJbmRleCA9IHRoaXMuY3VycmVudFZpZXdJbmRleDtcclxuXHJcblx0XHR0aGlzLnNsaWRlci5nZXRBY3RpdmVJbmRleCgpLnRoZW4oKGN1cnJlbnRTbGlkZUluZGV4KSA9PiB7XHJcblx0XHRcdGN1cnJlbnRTbGlkZUluZGV4ID0gKGN1cnJlbnRTbGlkZUluZGV4ICsgMikgJSAzO1xyXG5cdFx0XHRpZiAoaXNOYU4oY3VycmVudFNsaWRlSW5kZXgpKSB7XHJcblx0XHRcdFx0Y3VycmVudFNsaWRlSW5kZXggPSBjdXJyZW50Vmlld0luZGV4O1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRpZiAoY3VycmVudFNsaWRlSW5kZXggLSBjdXJyZW50Vmlld0luZGV4ID09PSAxKSB7XHJcblx0XHRcdFx0ZGlyZWN0aW9uID0gMTtcclxuXHRcdFx0fSBlbHNlIGlmIChjdXJyZW50U2xpZGVJbmRleCA9PT0gMCAmJiBjdXJyZW50Vmlld0luZGV4ID09PSAyKSB7XHJcblx0XHRcdFx0ZGlyZWN0aW9uID0gMTtcclxuXHRcdFx0XHR0aGlzLnNsaWRlci5zbGlkZVRvKDEsIDAsIGZhbHNlKTtcclxuXHRcdFx0fSBlbHNlIGlmIChjdXJyZW50Vmlld0luZGV4IC0gY3VycmVudFNsaWRlSW5kZXggPT09IDEpIHtcclxuXHRcdFx0XHRkaXJlY3Rpb24gPSAtMTtcclxuXHRcdFx0fSBlbHNlIGlmIChjdXJyZW50U2xpZGVJbmRleCA9PT0gMiAmJiBjdXJyZW50Vmlld0luZGV4ID09PSAwKSB7XHJcblx0XHRcdFx0ZGlyZWN0aW9uID0gLTE7XHJcblx0XHRcdFx0dGhpcy5zbGlkZXIuc2xpZGVUbygzLCAwLCBmYWxzZSk7XHJcblx0XHRcdH1cclxuXHRcdFx0dGhpcy5jdXJyZW50Vmlld0luZGV4ID0gY3VycmVudFNsaWRlSW5kZXg7XHJcblx0XHRcdHRoaXMubW92ZShkaXJlY3Rpb24pO1xyXG5cdFx0fSk7XHJcblx0fVxyXG5cclxuXHRtb3ZlKGRpcmVjdGlvbjogbnVtYmVyKSB7XHJcblx0XHRpZiAoZGlyZWN0aW9uID09PSAwKSB7XHJcblx0XHRcdHJldHVybjtcclxuXHRcdH1cclxuXHRcdHRoaXMuZGlyZWN0aW9uID0gZGlyZWN0aW9uO1xyXG5cdFx0aWYgKCF0aGlzLm1vdmVPblNlbGVjdGVkKSB7XHJcblx0XHRcdGNvbnN0IGFkamFjZW50RGF0ZSA9IHRoaXMuY2FsZW5kYXJTZXJ2aWNlLmdldEFkamFjZW50Q2FsZW5kYXJEYXRlKHRoaXMubW9kZSwgZGlyZWN0aW9uKTtcclxuXHRcdFx0dGhpcy5jYWxlbmRhclNlcnZpY2Uuc2V0Q3VycmVudERhdGUoYWRqYWNlbnREYXRlKTtcclxuXHRcdH1cclxuXHRcdHRoaXMucmVmcmVzaFZpZXcoKTtcclxuXHRcdHRoaXMuZGlyZWN0aW9uID0gMDtcclxuXHRcdHRoaXMubW92ZU9uU2VsZWN0ZWQgPSBmYWxzZTtcclxuXHR9XHJcblxyXG5cdGNyZWF0ZURhdGVPYmplY3QoZGF0ZTogRGF0ZSk6IElNb250aFZpZXdSb3cge1xyXG5cdFx0bGV0IGRpc2FibGVkID0gZmFsc2U7XHJcblx0XHRpZiAodGhpcy5tYXJrRGlzYWJsZWQpIHtcclxuXHRcdFx0ZGlzYWJsZWQgPSB0aGlzLm1hcmtEaXNhYmxlZChkYXRlKTtcclxuXHRcdH1cclxuXHJcblx0XHRyZXR1cm4ge1xyXG5cdFx0XHRkYXRlLFxyXG5cdFx0XHRldmVudHM6IFtdLFxyXG5cdFx0XHRsYWJlbDogdGhpcy5mb3JtYXREYXlMYWJlbChkYXRlKSxcclxuXHRcdFx0c2Vjb25kYXJ5OiBmYWxzZSxcclxuXHRcdFx0ZGlzYWJsZWQsXHJcblx0XHR9O1xyXG5cdH1cclxuXHJcblx0Z2V0Vmlld0RhdGEoc3RhcnRUaW1lOiBEYXRlKTogSU1vbnRoVmlldyB7XHJcblx0XHRjb25zdCBzdGFydERhdGUgPSBzdGFydFRpbWUsXHJcblx0XHRcdGRhdGUgPSBzdGFydERhdGUuZ2V0RGF0ZSgpLFxyXG5cdFx0XHRtb250aCA9IChzdGFydERhdGUuZ2V0TW9udGgoKSArIChkYXRlICE9PSAxID8gMSA6IDApKSAlIDEyO1xyXG5cclxuXHRcdGNvbnN0IGRhdGVzID0gTW9udGhWaWV3Q29tcG9uZW50LmdldERhdGVzKHN0YXJ0RGF0ZSwgNDIpO1xyXG5cdFx0Y29uc3QgZGF5czogSU1vbnRoVmlld1Jvd1tdID0gW107XHJcblx0XHRmb3IgKGxldCBpID0gMDsgaSA8IDQyOyBpKyspIHtcclxuXHRcdFx0Y29uc3QgZGF0ZU9iamVjdCA9IHRoaXMuY3JlYXRlRGF0ZU9iamVjdChkYXRlc1tpXSk7XHJcblx0XHRcdGRhdGVPYmplY3Quc2Vjb25kYXJ5ID0gZGF0ZXNbaV0uZ2V0TW9udGgoKSAhPT0gbW9udGg7XHJcblx0XHRcdGRheXNbaV0gPSBkYXRlT2JqZWN0O1xyXG5cdFx0fVxyXG5cclxuXHRcdGNvbnN0IGRheUhlYWRlcnM6IHN0cmluZ1tdID0gW107XHJcblx0XHRmb3IgKGxldCBpID0gMDsgaSA8IDc7IGkrKykge1xyXG5cdFx0XHRkYXlIZWFkZXJzLnB1c2godGhpcy5mb3JtYXREYXlIZWFkZXJMYWJlbChkYXlzW2ldLmRhdGUpKTtcclxuXHRcdH1cclxuXHRcdHJldHVybiB7XHJcblx0XHRcdGRhdGVzOiBkYXlzLFxyXG5cdFx0XHRkYXlIZWFkZXJzLFxyXG5cdFx0fTtcclxuXHR9XHJcblxyXG5cdGdldEhpZ2hsaWdodENsYXNzKGRhdGU6IElNb250aFZpZXdSb3cpOiBzdHJpbmcge1xyXG5cdFx0bGV0IGNsYXNzTmFtZSA9ICcnO1xyXG5cclxuXHRcdGlmIChkYXRlLmhhc0V2ZW50KSB7XHJcblx0XHRcdGlmIChkYXRlLnNlY29uZGFyeSkge1xyXG5cdFx0XHRcdGNsYXNzTmFtZSA9ICdtb250aHZpZXctc2Vjb25kYXJ5LXdpdGgtZXZlbnQnO1xyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdGNsYXNzTmFtZSA9ICdtb250aHZpZXctcHJpbWFyeS13aXRoLWV2ZW50JztcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cclxuXHRcdGlmIChkYXRlLnNlbGVjdGVkKSB7XHJcblx0XHRcdGlmIChjbGFzc05hbWUpIHtcclxuXHRcdFx0XHRjbGFzc05hbWUgKz0gJyAnO1xyXG5cdFx0XHR9XHJcblx0XHRcdGNsYXNzTmFtZSArPSAnbW9udGh2aWV3LXNlbGVjdGVkJztcclxuXHRcdH1cclxuXHJcblx0XHRpZiAoZGF0ZS5jdXJyZW50KSB7XHJcblx0XHRcdGlmIChjbGFzc05hbWUpIHtcclxuXHRcdFx0XHRjbGFzc05hbWUgKz0gJyAnO1xyXG5cdFx0XHR9XHJcblx0XHRcdGNsYXNzTmFtZSArPSAnbW9udGh2aWV3LWN1cnJlbnQnO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmIChkYXRlLnNlY29uZGFyeSkge1xyXG5cdFx0XHRpZiAoY2xhc3NOYW1lKSB7XHJcblx0XHRcdFx0Y2xhc3NOYW1lICs9ICcgJztcclxuXHRcdFx0fVxyXG5cdFx0XHRjbGFzc05hbWUgKz0gJ3RleHQtbXV0ZWQnO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmIChkYXRlLmRpc2FibGVkKSB7XHJcblx0XHRcdGlmIChjbGFzc05hbWUpIHtcclxuXHRcdFx0XHRjbGFzc05hbWUgKz0gJyAnO1xyXG5cdFx0XHR9XHJcblx0XHRcdGNsYXNzTmFtZSArPSAnbW9udGh2aWV3LWRpc2FibGVkJztcclxuXHRcdH1cclxuXHRcdHJldHVybiBjbGFzc05hbWU7XHJcblx0fVxyXG5cclxuXHRnZXRSYW5nZShjdXJyZW50RGF0ZTogRGF0ZSk6IElSYW5nZSB7XHJcblx0XHRjb25zdCB5ZWFyID0gY3VycmVudERhdGUuZ2V0RnVsbFllYXIoKSxcclxuXHRcdFx0bW9udGggPSBjdXJyZW50RGF0ZS5nZXRNb250aCgpLFxyXG5cdFx0XHRmaXJzdERheU9mTW9udGggPSBuZXcgRGF0ZSh5ZWFyLCBtb250aCwgMSwgMTIsIDAsIDApLCAvLyBzZXQgaG91ciB0byAxMiB0byBhdm9pZCBEU1QgcHJvYmxlbVxyXG5cdFx0XHRkaWZmZXJlbmNlID0gdGhpcy5zdGFydGluZ0RheU1vbnRoIC0gZmlyc3REYXlPZk1vbnRoLmdldERheSgpLFxyXG5cdFx0XHRudW1EaXNwbGF5ZWRGcm9tUHJldmlvdXNNb250aCA9IGRpZmZlcmVuY2UgPiAwID8gNyAtIGRpZmZlcmVuY2UgOiAtZGlmZmVyZW5jZSxcclxuXHRcdFx0c3RhcnREYXRlID0gbmV3IERhdGUoZmlyc3REYXlPZk1vbnRoLmdldFRpbWUoKSk7XHJcblxyXG5cdFx0aWYgKG51bURpc3BsYXllZEZyb21QcmV2aW91c01vbnRoID4gMCkge1xyXG5cdFx0XHRzdGFydERhdGUuc2V0RGF0ZSgtbnVtRGlzcGxheWVkRnJvbVByZXZpb3VzTW9udGggKyAxKTtcclxuXHRcdH1cclxuXHJcblx0XHRjb25zdCBlbmREYXRlID0gbmV3IERhdGUoc3RhcnREYXRlLmdldFRpbWUoKSk7XHJcblx0XHRlbmREYXRlLnNldERhdGUoZW5kRGF0ZS5nZXREYXRlKCkgKyA0Mik7XHJcblxyXG5cdFx0cmV0dXJuIHtcclxuXHRcdFx0c3RhcnRUaW1lOiBzdGFydERhdGUsXHJcblx0XHRcdGVuZFRpbWU6IGVuZERhdGUsXHJcblx0XHR9O1xyXG5cdH1cclxuXHJcblx0b25EYXRhTG9hZGVkKCkge1xyXG5cdFx0Y29uc3QgcmFuZ2UgPSB0aGlzLnJhbmdlLFxyXG5cdFx0XHRldmVudFNvdXJjZSA9IHRoaXMuZXZlbnRTb3VyY2UsXHJcblx0XHRcdGxlbiA9IGV2ZW50U291cmNlID8gZXZlbnRTb3VyY2UubGVuZ3RoIDogMCxcclxuXHRcdFx0c3RhcnRUaW1lID0gcmFuZ2Uuc3RhcnRUaW1lLFxyXG5cdFx0XHRlbmRUaW1lID0gcmFuZ2UuZW5kVGltZSxcclxuXHRcdFx0dXRjU3RhcnRUaW1lID0gRGF0ZS5VVEMoc3RhcnRUaW1lLmdldEZ1bGxZZWFyKCksIHN0YXJ0VGltZS5nZXRNb250aCgpLCBzdGFydFRpbWUuZ2V0RGF0ZSgpKSxcclxuXHRcdFx0dXRjRW5kVGltZSA9IERhdGUuVVRDKGVuZFRpbWUuZ2V0RnVsbFllYXIoKSwgZW5kVGltZS5nZXRNb250aCgpLCBlbmRUaW1lLmdldERhdGUoKSksXHJcblx0XHRcdGN1cnJlbnRWaWV3SW5kZXggPSB0aGlzLmN1cnJlbnRWaWV3SW5kZXgsXHJcblx0XHRcdGRhdGVzID0gdGhpcy52aWV3c1tjdXJyZW50Vmlld0luZGV4XS5kYXRlcyxcclxuXHRcdFx0b25lRGF5ID0gODY0MDAwMDAsXHJcblx0XHRcdGVwcyA9IDAuMDAwNjtcclxuXHJcblx0XHRmb3IgKGxldCByID0gMDsgciA8IDQyOyByICs9IDEpIHtcclxuXHRcdFx0aWYgKGRhdGVzW3JdLmhhc0V2ZW50KSB7XHJcblx0XHRcdFx0ZGF0ZXNbcl0uaGFzRXZlbnQgPSBmYWxzZTtcclxuXHRcdFx0XHRkYXRlc1tyXS5ldmVudHMgPSBbXTtcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cclxuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpICs9IDEpIHtcclxuXHRcdFx0Y29uc3QgZXZlbnQgPSBldmVudFNvdXJjZVtpXSxcclxuXHRcdFx0XHRldmVudFN0YXJ0VGltZSA9IGV2ZW50LnN0YXJ0VGltZSxcclxuXHRcdFx0XHRldmVudEVuZFRpbWUgPSBldmVudC5lbmRUaW1lO1xyXG5cclxuXHRcdFx0bGV0IGV2ZW50VVRDU3RhcnRUaW1lOiBudW1iZXIsIGV2ZW50VVRDRW5kVGltZTogbnVtYmVyO1xyXG5cdFx0XHRpZiAoZXZlbnQuYWxsRGF5KSB7XHJcblx0XHRcdFx0ZXZlbnRVVENTdGFydFRpbWUgPSBldmVudFN0YXJ0VGltZS5nZXRUaW1lKCk7XHJcblx0XHRcdFx0ZXZlbnRVVENFbmRUaW1lID0gZXZlbnRFbmRUaW1lLmdldFRpbWUoKTtcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRldmVudFVUQ1N0YXJ0VGltZSA9IERhdGUuVVRDKGV2ZW50U3RhcnRUaW1lLmdldEZ1bGxZZWFyKCksIGV2ZW50U3RhcnRUaW1lLmdldE1vbnRoKCksIGV2ZW50U3RhcnRUaW1lLmdldERhdGUoKSk7XHJcblx0XHRcdFx0ZXZlbnRVVENFbmRUaW1lID0gRGF0ZS5VVEMoZXZlbnRFbmRUaW1lLmdldEZ1bGxZZWFyKCksIGV2ZW50RW5kVGltZS5nZXRNb250aCgpLCBldmVudEVuZFRpbWUuZ2V0RGF0ZSgpICsgMSk7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGlmIChldmVudFVUQ0VuZFRpbWUgPD0gdXRjU3RhcnRUaW1lIHx8IGV2ZW50VVRDU3RhcnRUaW1lID49IHV0Y0VuZFRpbWUpIHtcclxuXHRcdFx0XHRjb250aW51ZTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0bGV0IHRpbWVEaWZmZXJlbmNlU3RhcnQ6IG51bWJlciwgdGltZURpZmZlcmVuY2VFbmQ6IG51bWJlcjtcclxuXHJcblx0XHRcdGlmIChldmVudFVUQ1N0YXJ0VGltZSA8IHV0Y1N0YXJ0VGltZSkge1xyXG5cdFx0XHRcdHRpbWVEaWZmZXJlbmNlU3RhcnQgPSAwO1xyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdHRpbWVEaWZmZXJlbmNlU3RhcnQgPSAoZXZlbnRVVENTdGFydFRpbWUgLSB1dGNTdGFydFRpbWUpIC8gb25lRGF5O1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRpZiAoZXZlbnRVVENFbmRUaW1lID4gdXRjRW5kVGltZSkge1xyXG5cdFx0XHRcdHRpbWVEaWZmZXJlbmNlRW5kID0gKHV0Y0VuZFRpbWUgLSB1dGNTdGFydFRpbWUpIC8gb25lRGF5O1xyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdHRpbWVEaWZmZXJlbmNlRW5kID0gKGV2ZW50VVRDRW5kVGltZSAtIHV0Y1N0YXJ0VGltZSkgLyBvbmVEYXk7XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGxldCBpbmRleCA9IE1hdGguZmxvb3IodGltZURpZmZlcmVuY2VTdGFydCk7XHJcblx0XHRcdGNvbnN0IGVuZEluZGV4ID0gTWF0aC5jZWlsKHRpbWVEaWZmZXJlbmNlRW5kIC0gZXBzKTtcclxuXHRcdFx0d2hpbGUgKGluZGV4IDwgZW5kSW5kZXgpIHtcclxuXHRcdFx0XHRkYXRlc1tpbmRleF0uaGFzRXZlbnQgPSB0cnVlO1xyXG5cdFx0XHRcdGxldCBldmVudFNldCA9IGRhdGVzW2luZGV4XS5ldmVudHM7XHJcblx0XHRcdFx0aWYgKGV2ZW50U2V0KSB7XHJcblx0XHRcdFx0XHRldmVudFNldC5wdXNoKGV2ZW50KTtcclxuXHRcdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdFx0ZXZlbnRTZXQgPSBbXTtcclxuXHRcdFx0XHRcdGV2ZW50U2V0LnB1c2goZXZlbnQpO1xyXG5cdFx0XHRcdFx0ZGF0ZXNbaW5kZXhdLmV2ZW50cyA9IGV2ZW50U2V0O1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRpbmRleCArPSAxO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblxyXG5cdFx0Zm9yIChsZXQgciA9IDA7IHIgPCA0MjsgciArPSAxKSB7XHJcblx0XHRcdGlmIChkYXRlc1tyXS5oYXNFdmVudCkge1xyXG5cdFx0XHRcdGRhdGVzW3JdLmV2ZW50cy5zb3J0KHRoaXMuY29tcGFyZUV2ZW50KTtcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cclxuXHRcdGlmICh0aGlzLmF1dG9TZWxlY3QpIHtcclxuXHRcdFx0bGV0IGZpbmRTZWxlY3RlZCA9IGZhbHNlO1xyXG5cdFx0XHRmb3IgKGxldCByID0gMDsgciA8IDQyOyByICs9IDEpIHtcclxuXHRcdFx0XHRpZiAoZGF0ZXNbcl0uc2VsZWN0ZWQpIHtcclxuXHRcdFx0XHRcdHRoaXMuc2VsZWN0ZWREYXRlID0gZGF0ZXNbcl07XHJcblx0XHRcdFx0XHRmaW5kU2VsZWN0ZWQgPSB0cnVlO1xyXG5cdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRpZiAoZmluZFNlbGVjdGVkKSB7XHJcblx0XHRcdFx0dGhpcy5vblRpbWVTZWxlY3RlZC5lbWl0KHtcclxuXHRcdFx0XHRcdHNlbGVjdGVkVGltZTogdGhpcy5zZWxlY3RlZERhdGUuZGF0ZSxcclxuXHRcdFx0XHRcdGV2ZW50czogdGhpcy5zZWxlY3RlZERhdGUuZXZlbnRzLFxyXG5cdFx0XHRcdFx0ZGlzYWJsZWQ6IHRoaXMuc2VsZWN0ZWREYXRlLmRpc2FibGVkLFxyXG5cdFx0XHRcdH0pO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHRyZWZyZXNoVmlldygpIHtcclxuXHRcdHRoaXMucmFuZ2UgPSB0aGlzLmdldFJhbmdlKHRoaXMuY2FsZW5kYXJTZXJ2aWNlLmN1cnJlbnREYXRlKTtcclxuXHJcblx0XHRpZiAodGhpcy5pbml0ZWQpIHtcclxuXHRcdFx0Y29uc3QgdGl0bGUgPSB0aGlzLmdldFRpdGxlKCk7XHJcblx0XHRcdHRoaXMub25UaXRsZUNoYW5nZWQuZW1pdCh0aXRsZSk7XHJcblx0XHR9XHJcblx0XHR0aGlzLmNhbGVuZGFyU2VydmljZS5wb3B1bGF0ZUFkamFjZW50Vmlld3ModGhpcyk7XHJcblx0XHR0aGlzLnVwZGF0ZUN1cnJlbnRWaWV3KHRoaXMucmFuZ2Uuc3RhcnRUaW1lLCB0aGlzLnZpZXdzW3RoaXMuY3VycmVudFZpZXdJbmRleF0pO1xyXG5cdFx0dGhpcy5jYWxlbmRhclNlcnZpY2UucmFuZ2VDaGFuZ2VkKHRoaXMpO1xyXG5cdH1cclxuXHJcblx0Z2V0VGl0bGUoKTogc3RyaW5nIHtcclxuXHRcdGNvbnN0IGN1cnJlbnRWaWV3U3RhcnREYXRlID0gdGhpcy5yYW5nZS5zdGFydFRpbWUsXHJcblx0XHRcdGRhdGUgPSBjdXJyZW50Vmlld1N0YXJ0RGF0ZS5nZXREYXRlKCksXHJcblx0XHRcdG1vbnRoID0gKGN1cnJlbnRWaWV3U3RhcnREYXRlLmdldE1vbnRoKCkgKyAoZGF0ZSAhPT0gMSA/IDEgOiAwKSkgJSAxMixcclxuXHRcdFx0eWVhciA9IGN1cnJlbnRWaWV3U3RhcnREYXRlLmdldEZ1bGxZZWFyKCkgKyAoZGF0ZSAhPT0gMSAmJiBtb250aCA9PT0gMCA/IDEgOiAwKSxcclxuXHRcdFx0aGVhZGVyRGF0ZSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCAxLCAxMiwgMCwgMCwgMCk7XHJcblx0XHRyZXR1cm4gdGhpcy5mb3JtYXRUaXRsZShoZWFkZXJEYXRlKTtcclxuXHR9XHJcblxyXG5cdHByaXZhdGUgY29tcGFyZUV2ZW50KGV2ZW50MTogSUV2ZW50LCBldmVudDI6IElFdmVudCk6IG51bWJlciB7XHJcblx0XHRpZiAoZXZlbnQxLmFsbERheSkge1xyXG5cdFx0XHRyZXR1cm4gMTtcclxuXHRcdH0gZWxzZSBpZiAoZXZlbnQyLmFsbERheSkge1xyXG5cdFx0XHRyZXR1cm4gLTE7XHJcblx0XHR9IGVsc2Uge1xyXG5cdFx0XHRyZXR1cm4gZXZlbnQxLnN0YXJ0VGltZS5nZXRUaW1lKCkgLSBldmVudDIuc3RhcnRUaW1lLmdldFRpbWUoKTtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdHNlbGVjdCh2aWV3RGF0ZTogSU1vbnRoVmlld1Jvdykge1xyXG5cdFx0aWYgKCF0aGlzLnZpZXdzKSB7XHJcblx0XHRcdHJldHVybjtcclxuXHRcdH1cclxuXHJcblx0XHRjb25zdCBzZWxlY3RlZERhdGUgPSB2aWV3RGF0ZS5kYXRlLFxyXG5cdFx0XHRldmVudHMgPSB2aWV3RGF0ZS5ldmVudHM7XHJcblxyXG5cdFx0aWYgKCF2aWV3RGF0ZS5kaXNhYmxlZCkge1xyXG5cdFx0XHRjb25zdCBkYXRlcyA9IHRoaXMudmlld3NbdGhpcy5jdXJyZW50Vmlld0luZGV4XS5kYXRlcyxcclxuXHRcdFx0XHRjdXJyZW50Q2FsZW5kYXJEYXRlID0gdGhpcy5jYWxlbmRhclNlcnZpY2UuY3VycmVudERhdGUsXHJcblx0XHRcdFx0Y3VycmVudE1vbnRoID0gY3VycmVudENhbGVuZGFyRGF0ZS5nZXRNb250aCgpLFxyXG5cdFx0XHRcdGN1cnJlbnRZZWFyID0gY3VycmVudENhbGVuZGFyRGF0ZS5nZXRGdWxsWWVhcigpLFxyXG5cdFx0XHRcdHNlbGVjdGVkTW9udGggPSBzZWxlY3RlZERhdGUuZ2V0TW9udGgoKSxcclxuXHRcdFx0XHRzZWxlY3RlZFllYXIgPSBzZWxlY3RlZERhdGUuZ2V0RnVsbFllYXIoKTtcclxuXHRcdFx0bGV0IGRpcmVjdGlvbiA9IDA7XHJcblxyXG5cdFx0XHRpZiAoY3VycmVudFllYXIgPT09IHNlbGVjdGVkWWVhcikge1xyXG5cdFx0XHRcdGlmIChjdXJyZW50TW9udGggIT09IHNlbGVjdGVkTW9udGgpIHtcclxuXHRcdFx0XHRcdGRpcmVjdGlvbiA9IGN1cnJlbnRNb250aCA8IHNlbGVjdGVkTW9udGggPyAxIDogLTE7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdGRpcmVjdGlvbiA9IGN1cnJlbnRZZWFyIDwgc2VsZWN0ZWRZZWFyID8gMSA6IC0xO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHR0aGlzLmNhbGVuZGFyU2VydmljZS5zZXRJbml0aWFsRGF0ZShzZWxlY3RlZERhdGUpO1xyXG5cdFx0XHRpZiAoZGlyZWN0aW9uID09PSAwKSB7XHJcblx0XHRcdFx0Y29uc3QgY3VycmVudFZpZXdTdGFydERhdGUgPSB0aGlzLnJhbmdlLnN0YXJ0VGltZSxcclxuXHRcdFx0XHRcdG9uZURheSA9IDg2NDAwMDAwLFxyXG5cdFx0XHRcdFx0c2VsZWN0ZWREYXlEaWZmZXJlbmNlID0gTWF0aC5yb3VuZChcclxuXHRcdFx0XHRcdFx0KERhdGUuVVRDKHNlbGVjdGVkRGF0ZS5nZXRGdWxsWWVhcigpLCBzZWxlY3RlZERhdGUuZ2V0TW9udGgoKSwgc2VsZWN0ZWREYXRlLmdldERhdGUoKSkgLVxyXG5cdFx0XHRcdFx0XHRcdERhdGUuVVRDKGN1cnJlbnRWaWV3U3RhcnREYXRlLmdldEZ1bGxZZWFyKCksIGN1cnJlbnRWaWV3U3RhcnREYXRlLmdldE1vbnRoKCksIGN1cnJlbnRWaWV3U3RhcnREYXRlLmdldERhdGUoKSkpIC9cclxuXHRcdFx0XHRcdFx0XHRvbmVEYXlcclxuXHRcdFx0XHRcdCk7XHJcblxyXG5cdFx0XHRcdGZvciAobGV0IHIgPSAwOyByIDwgNDI7IHIgKz0gMSkge1xyXG5cdFx0XHRcdFx0ZGF0ZXNbcl0uc2VsZWN0ZWQgPSBmYWxzZTtcclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdGlmIChzZWxlY3RlZERheURpZmZlcmVuY2UgPj0gMCAmJiBzZWxlY3RlZERheURpZmZlcmVuY2UgPCA0Mikge1xyXG5cdFx0XHRcdFx0ZGF0ZXNbc2VsZWN0ZWREYXlEaWZmZXJlbmNlXS5zZWxlY3RlZCA9IHRydWU7XHJcblx0XHRcdFx0XHR0aGlzLnNlbGVjdGVkRGF0ZSA9IGRhdGVzW3NlbGVjdGVkRGF5RGlmZmVyZW5jZV07XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdHRoaXMubW92ZU9uU2VsZWN0ZWQgPSB0cnVlO1xyXG5cdFx0XHRcdHRoaXMuc2xpZGVWaWV3KGRpcmVjdGlvbik7XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHJcblx0XHR0aGlzLm9uVGltZVNlbGVjdGVkLmVtaXQoe1xyXG5cdFx0XHRzZWxlY3RlZFRpbWU6IHNlbGVjdGVkRGF0ZSxcclxuXHRcdFx0ZXZlbnRzLFxyXG5cdFx0XHRkaXNhYmxlZDogdmlld0RhdGUuZGlzYWJsZWQsXHJcblx0XHR9KTtcclxuXHR9XHJcblxyXG5cdHNsaWRlVmlldyhkaXJlY3Rpb246IG51bWJlcikge1xyXG5cdFx0aWYgKGRpcmVjdGlvbiA9PT0gMSkge1xyXG5cdFx0XHR0aGlzLnNsaWRlci5zbGlkZU5leHQoKTtcclxuXHRcdH0gZWxzZSBpZiAoZGlyZWN0aW9uID09PSAtMSkge1xyXG5cdFx0XHR0aGlzLnNsaWRlci5zbGlkZVByZXYoKTtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdHVwZGF0ZUN1cnJlbnRWaWV3KGN1cnJlbnRWaWV3U3RhcnREYXRlOiBEYXRlLCB2aWV3OiBJTW9udGhWaWV3KSB7XHJcblx0XHRjb25zdCBjdXJyZW50Q2FsZW5kYXJEYXRlID0gdGhpcy5jYWxlbmRhclNlcnZpY2UuaW5pdGlhbERhdGUsXHJcblx0XHRcdHRvZGF5ID0gbmV3IERhdGUoKSxcclxuXHRcdFx0b25lRGF5ID0gODY0MDAwMDAsXHJcblx0XHRcdHNlbGVjdGVkRGF5RGlmZmVyZW5jZSA9IE1hdGgucm91bmQoXHJcblx0XHRcdFx0KERhdGUuVVRDKGN1cnJlbnRDYWxlbmRhckRhdGUuZ2V0RnVsbFllYXIoKSwgY3VycmVudENhbGVuZGFyRGF0ZS5nZXRNb250aCgpLCBjdXJyZW50Q2FsZW5kYXJEYXRlLmdldERhdGUoKSkgLVxyXG5cdFx0XHRcdFx0RGF0ZS5VVEMoY3VycmVudFZpZXdTdGFydERhdGUuZ2V0RnVsbFllYXIoKSwgY3VycmVudFZpZXdTdGFydERhdGUuZ2V0TW9udGgoKSwgY3VycmVudFZpZXdTdGFydERhdGUuZ2V0RGF0ZSgpKSkgL1xyXG5cdFx0XHRcdFx0b25lRGF5XHJcblx0XHRcdCksXHJcblx0XHRcdGN1cnJlbnREYXlEaWZmZXJlbmNlID0gTWF0aC5yb3VuZChcclxuXHRcdFx0XHQoRGF0ZS5VVEModG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgdG9kYXkuZ2V0RGF0ZSgpKSAtXHJcblx0XHRcdFx0XHREYXRlLlVUQyhjdXJyZW50Vmlld1N0YXJ0RGF0ZS5nZXRGdWxsWWVhcigpLCBjdXJyZW50Vmlld1N0YXJ0RGF0ZS5nZXRNb250aCgpLCBjdXJyZW50Vmlld1N0YXJ0RGF0ZS5nZXREYXRlKCkpKSAvXHJcblx0XHRcdFx0XHRvbmVEYXlcclxuXHRcdFx0KTtcclxuXHJcblx0XHRmb3IgKGxldCByID0gMDsgciA8IDQyOyByICs9IDEpIHtcclxuXHRcdFx0dmlldy5kYXRlc1tyXS5zZWxlY3RlZCA9IGZhbHNlO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmIChcclxuXHRcdFx0c2VsZWN0ZWREYXlEaWZmZXJlbmNlID49IDAgJiZcclxuXHRcdFx0c2VsZWN0ZWREYXlEaWZmZXJlbmNlIDwgNDIgJiZcclxuXHRcdFx0IXZpZXcuZGF0ZXNbc2VsZWN0ZWREYXlEaWZmZXJlbmNlXS5kaXNhYmxlZCAmJlxyXG5cdFx0XHQodGhpcy5hdXRvU2VsZWN0IHx8IHRoaXMubW92ZU9uU2VsZWN0ZWQpXHJcblx0XHQpIHtcclxuXHRcdFx0dmlldy5kYXRlc1tzZWxlY3RlZERheURpZmZlcmVuY2VdLnNlbGVjdGVkID0gdHJ1ZTtcclxuXHRcdFx0dGhpcy5zZWxlY3RlZERhdGUgPSB2aWV3LmRhdGVzW3NlbGVjdGVkRGF5RGlmZmVyZW5jZV07XHJcblx0XHR9IGVsc2Uge1xyXG5cdFx0XHR0aGlzLnNlbGVjdGVkRGF0ZSA9IHtcclxuXHRcdFx0XHRkYXRlOiBudWxsLFxyXG5cdFx0XHRcdGV2ZW50czogW10sXHJcblx0XHRcdFx0bGFiZWw6IG51bGwsXHJcblx0XHRcdFx0c2Vjb25kYXJ5OiBudWxsLFxyXG5cdFx0XHRcdGRpc2FibGVkOiBmYWxzZSxcclxuXHRcdFx0fTtcclxuXHRcdH1cclxuXHJcblx0XHRpZiAoY3VycmVudERheURpZmZlcmVuY2UgPj0gMCAmJiBjdXJyZW50RGF5RGlmZmVyZW5jZSA8IDQyKSB7XHJcblx0XHRcdHZpZXcuZGF0ZXNbY3VycmVudERheURpZmZlcmVuY2VdLmN1cnJlbnQgPSB0cnVlO1xyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0ZXZlbnRTZWxlY3RlZChldmVudDogSUV2ZW50KSB7XHJcblx0XHR0aGlzLm9uRXZlbnRTZWxlY3RlZC5lbWl0KGV2ZW50KTtcclxuXHR9XHJcbn1cclxuIl19