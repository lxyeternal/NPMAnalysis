export declare class NgCalendarModule {
}
