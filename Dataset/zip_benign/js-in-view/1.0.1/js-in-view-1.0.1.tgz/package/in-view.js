function inView(options) {
    // If selector is undfined, throw error
    if (options.selector == undefined) {
        throw new Error('Either an empty or incorrect selector has been passed.')
    }

    // If addedClass is undefined, set to default
    if (options.addedClass == undefined) {
        options.addedClass = 'in-view'
    }

    // If windowTrigger is undefined, set to default
    if (options.windowTrigger == undefined) {
        options.windowTrigger = 0.5
    }

    // If enableExit is undefined, set to default
    if (options.enableExit == undefined) {
        options.enableExit = false
    }

    // Get all targeted elements
    const targetElements = document.querySelectorAll(options.selector)
    // Count number of targeted elements
    const targetElementsLength = targetElements.length

    // If DOM contains targeted elements
    if (targetElementsLength > 0) {
        // Call function to calculate position on page load
        calculatePosition()

        // Call function to calculate position on resize
        window.addEventListener('resize', calculatePosition)

        // Call function to calculate position on scroll
        window.addEventListener('scroll', calculatePosition)
    }

    function calculatePosition() {
        // Get window height
        const windowHeight = window.innerHeight
        // Get scrollTop position
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop
        // Calculate when to trigger inView in viewport
        const offsetAmount = windowHeight * options.windowTrigger
        // Should inView remove class on exit of viewport
        const enableExit = options.enableExit

        // Loop through all instances of selector class
        for (let i = 0; i < targetElementsLength; i++) {
            // Target each selector class
            const targetElement = targetElements[i]
            // Get position of selected class from top of document
            const targetElementOffsetTop = targetElement.offsetTop

            // Option for removing class when exiting viewport
            if (enableExit == false) {
                // If top of the targeted selector is within the calculated position in viewport, add class
                if (scrollTop > (targetElementOffsetTop - offsetAmount)) {
                    targetElement.classList.add(options.addedClass)
                }
            } else {
                // If enableExit = true, get the height of the targeted selector
                let targetElementHeight = Math.round(targetElement.offsetHeight)

                // If the top of targeted selector is past the top of calculated trigger point AND the bottom of the bottom of the targeted selector is below the top of the window, add class, else remove class.
                if (scrollTop > (targetElementOffsetTop - offsetAmount) && scrollTop < (targetElementOffsetTop + targetElementHeight)) {
                    targetElement.classList.add(options.addedClass)
                } else {
                    targetElement.classList.remove(options.addedClass)
                }
            }
        }
    }
}
