# inView
A simple js plugin to add/remove classes when elements enter the viewport

# Package Managers

<pre>
  yarn add js-in-view
</pre>

To initialise inView, simply run in your js file:

<pre>
  inView();
</pre>

# Settings
<table>
  <thead>
    <tr>
      <th>Option</th>
      <th>Type</th>
      <th>Default</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>selector</td>
      <td>string</td>
      <td>'.trigger'</td>
      <td>The class of the elements that will be used to trigger inView</td>
    </tr>
    <tr>
      <td>addedClass</td>
      <td>string</td>
      <td>'in-view'</td>
      <td>The class that will be added/removed on entering/leaving the viewport (optional)</td>
    </tr>
    <tr>
      <td>windowTrigger</td>
      <td>integer</td>
      <td>0.5</td>
      <td>Number between 0-1. Percentage in decimal from top of window which will trigger inView (optional)</td>
    </tr>
    <tr>
      <td>enableExit</td>
      <td>boolean</td>
      <td>false</td>
      <td>Boolean for option to remove class when out of viewport (optional)</td>
    </tr>
  </tbody>
</table>

