/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Images = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M13 12h1a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v1h7a2 2 0 0 1 2 2v7z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M10 4a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h8zM3.5 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M4.732 9.477l1.544 2.381.955-1.104a1.022 1.022 0 0 1 1.645.117l.949 1.464a1.09 1.09 0 0 1-.289 1.485c-.171.117-.372.18-.578.18H3.042C2.466 14 2 13.52 2 12.93c0-.104.014-.206.043-.305l.823-2.858c.164-.567.743-.89 1.295-.723.234.072.436.225.57.433z"
      opacity=".7"
      transform="matrix(-1 0 0 1 12 0)"
    />
    <circle
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      cx="3.5"
      cy="7.5"
      r="1.5"
    />
  </svg>
);

Images.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Images;
