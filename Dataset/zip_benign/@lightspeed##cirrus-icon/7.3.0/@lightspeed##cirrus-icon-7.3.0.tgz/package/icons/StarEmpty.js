/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const StarEmpty = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M7.999 11.272l2.7 1.485-.519-3.163 2.294-2.34-3.16-.481-1.315-2.789-1.315 2.789-3.16.48 2.293 2.34-.518 3.164 2.7-1.485zm0 2.283l-4.18 2.3c-.64.352-1.061.04-.943-.682l.804-4.903L.298 6.82c-.518-.528-.343-1.047.387-1.158l4.644-.706L7.433.496c.312-.664.822-.658 1.132 0l2.103 4.46 4.644.706c.732.111.91.624.387 1.158l-3.381 3.45.803 4.903c.12.728-.315 1.027-.942.682l-4.18-2.3z"
    />
  </svg>
);

StarEmpty.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default StarEmpty;
