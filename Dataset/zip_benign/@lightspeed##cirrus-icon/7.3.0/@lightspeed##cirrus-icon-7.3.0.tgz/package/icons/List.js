/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const List = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M1 1h14a1 1 0 0 1 0 2H1a1 1 0 1 1 0-2zm0 8h14a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M1 5h14a1 1 0 0 1 0 2H1a1 1 0 1 1 0-2zm0 8h14a1 1 0 0 1 0 2H1a1 1 0 0 1 0-2z"
      opacity=".7"
    />
  </svg>
);

List.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default List;
