/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Shipments = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 1c1.113 0 2 .892 2 1.992v7.016A2.001 2.001 0 0 1 8 12H6.829a3.001 3.001 0 0 0-5.6-.152A1.988 1.988 0 0 1 0 10.008V2.992C0 1.9.895 1 2 1h6zm3 2.5a.5.5 0 0 1 .5-.5h.5l3.445 1.71a1 1 0 0 1 .555.895V12l-.19-.053A3 3 0 0 0 11 10.764V3.5zm2 2.229V8c.34 0 .675.035 1 .102V6.225l-1-.496z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M13 11a2 2 0 1 1 .001 3.999A2 2 0 0 1 13 11zm-9 0a2 2 0 1 1 .001 3.999A2 2 0 0 1 4 11z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M13 5.729l1 .496v1.877A4.953 4.953 0 0 0 13 8V5.729z"
    />
    <rect
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      width="4"
      height="2"
      x="3"
      y="5"
      opacity=".7"
      rx="1"
    />
  </svg>
);

Shipments.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Shipments;
