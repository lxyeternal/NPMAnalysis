/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ArrowUpRight = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2,
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M13.533 9.944l.45-7.663a.25.25 0 0 0-.264-.264l-7.663.45a.25.25 0 0 0-.162.427l1.752 1.752a.5.5 0 0 1 0 .708l-4.939 4.939a1 1 0 0 0 0 1.414l1.586 1.586a1 1 0 0 0 1.414 0l4.94-4.94a.5.5 0 0 1 .707 0l1.752 1.753a.25.25 0 0 0 .427-.162z"
    />
  </svg>
);

ArrowUpRight.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ArrowUpRight;
