/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ContentTemplates = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M5 0h9a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5V0zm3 6a1 1 0 1 0 0 2h1a1 1 0 1 0 0-2H8zm4 0a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2h-1zM8 2a1 1 0 1 0 0 2h2a1 1 0 0 0 0-2H8zm-.5 10a.5.5 0 0 0-.5.5v1a.5.5 0 1 0 1 0v-1a.5.5 0 0 0-.5-.5zm2.5 0a1 1 0 0 0 0 2h3a1 1 0 0 0 0-2h-3zm3-10a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M3 0v16H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h1z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M8 6h1a1 1 0 1 1 0 2H8a1 1 0 1 1 0-2zm4 0h1a1 1 0 0 1 0 2h-1a1 1 0 0 1 0-2zM8 2h2a1 1 0 0 1 0 2H8a1 1 0 1 1 0-2zm-.5 10a.5.5 0 0 1 .5.5v1a.5.5 0 1 1-1 0v-1a.5.5 0 0 1 .5-.5zm2.5 0h3a1 1 0 0 1 0 2h-3a1 1 0 0 1 0-2zm3-10a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"
    />
  </svg>
);

ContentTemplates.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ContentTemplates;
