/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Logout = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M11 3.005c0-1.11-.9-2.008-1.992-2.008H1.992C.892.997 0 1.884 0 2.999v7.797c0 1.105.856 2.296 1.896 2.653l4.208 1.445C7.151 15.254 8 14.653 8 13.543v-.509h.999c1.105 0 2.001-.89 2.001-2.004V9.517a.49.49 0 0 0-.505-.492h-.99A.498.498 0 0 0 9 9.53v1.253a.245.245 0 0 1-.252.245h-.496A.249.249 0 0 1 8 10.77V6.003c0-.549-.398-1.193-.888-1.438L4 3.006h4.759c.133 0 .241.108.241.247v1.255c0 .28.214.507.505.507l.99-.002A.497.497 0 0 0 11 4.52V3.005z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M13 4.006c0-.28.145-.337.321-.131l2.518 2.937a.301.301 0 0 1 0 .376l-2.518 2.937c-.177.207-.321.144-.321-.13V8l-3.75-.003A.246.246 0 0 1 9 7.752V6.245A.25.25 0 0 1 9.25 6H13V4.006z"
      opacity=".7"
    />
  </svg>
);

Logout.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Logout;
