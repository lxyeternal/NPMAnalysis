/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Location = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 16c-.5 0-6-6.686-6-10a6 6 0 1 1 12 0c0 3.314-5.5 10-6 10zm0-8a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"
    />
  </svg>
);

Location.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Location;
