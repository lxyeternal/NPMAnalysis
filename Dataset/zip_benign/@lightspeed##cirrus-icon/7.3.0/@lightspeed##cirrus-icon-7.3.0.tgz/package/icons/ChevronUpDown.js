/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ChevronUpDown = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 12l2-2 1 1-3 3-3-3 1-1 2 2zm0-8L6 6 5 5l3-3 3 3-1 1-2-2z"
    />
  </svg>
);

ChevronUpDown.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ChevronUpDown;
