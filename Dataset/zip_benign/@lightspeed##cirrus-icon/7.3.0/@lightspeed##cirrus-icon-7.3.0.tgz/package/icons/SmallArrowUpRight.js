/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const SmallArrowUpRight = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M10.091 7.296l-4.927 4.927a1 1 0 1 1-1.414-1.414l4.927-4.927-1.19-1.19a.7.7 0 0 1 .487-1.195l3.415-.042a.998.998 0 0 1 1.001.483c.11.16.173.354.173.562l.005 3.582a.7.7 0 0 1-1.195.496l-1.282-1.282z"
    />
  </svg>
);

SmallArrowUpRight.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default SmallArrowUpRight;
