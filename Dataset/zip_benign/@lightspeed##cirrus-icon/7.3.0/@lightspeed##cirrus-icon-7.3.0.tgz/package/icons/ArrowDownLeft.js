/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ArrowDownLeft = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2,
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M2.467 6.062l-.45 7.657a.25.25 0 0 0 .264.264l7.657-.45a.25.25 0 0 0 .162-.426l-1.748-1.748a.5.5 0 0 1 .003-.71l5.346-5.257a1 1 0 0 0 .006-1.42l-1.679-1.679a1 1 0 0 0-1.42.006L5.35 7.645a.5.5 0 0 1-.71.003L2.893 5.9a.25.25 0 0 0-.426.162z"
    />
  </svg>
);

ArrowDownLeft.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ArrowDownLeft;
