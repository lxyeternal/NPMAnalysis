/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const SupportTickets = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M12 4.99h2a1 1 0 0 1 1 1v4.02a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1V5.99a1 1 0 0 1 1-1zM2 5h2a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm6-3c-2.667 0-4 .667-4 2H2c0-2.667 2-4 6-4s6 1.333 6 4h-1.983C12.006 2.667 10.667 2 8 2z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M10 14l2.658-.886A.5.5 0 0 0 13 12.64V12h1v1.5a.5.5 0 0 1-.5.5H13l-3 1a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-1a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1z"
      opacity=".7"
    />
  </svg>
);

SupportTickets.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default SupportTickets;
