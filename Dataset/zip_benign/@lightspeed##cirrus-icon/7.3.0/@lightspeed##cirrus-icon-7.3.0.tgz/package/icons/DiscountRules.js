/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const DiscountRules = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M3 15a1 1 0 0 1-1-1v-2.5a.5.5 0 0 1 .501-.499l3 .007a.5.5 0 0 1 .499.5v.002a.499.499 0 0 1-.5.498l-.5.001V14a1 1 0 0 1-1 1H3zM7 4.132c0-.083.04-.16.109-.207C9.965 1.975 11.762 1 12.5 1c.5 0 .5 4 .5 6s0 6-.5 6c-.733 0-2.53-.978-5.391-2.935A.25.25 0 0 1 7 9.86V4.132zM2 4h3.75a.25.25 0 0 1 .25.25v5.5a.25.25 0 0 1-.25.25H2a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M14 7v1.6a.4.4 0 0 0 .455.396C15.485 8.852 16 8.186 16 7c0-1.187-.515-1.852-1.545-1.996A.4.4 0 0 0 14 5.4V7z"
      opacity=".7"
    />
  </svg>
);

DiscountRules.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default DiscountRules;
