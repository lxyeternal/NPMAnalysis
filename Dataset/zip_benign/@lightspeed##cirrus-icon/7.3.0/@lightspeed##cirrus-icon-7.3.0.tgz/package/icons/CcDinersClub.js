/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const CcDinersClub = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M1.5 3h13A1.5 1.5 0 0 1 16 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 11.5v-7A1.5 1.5 0 0 1 1.5 3zm5.92 6.67V6.22c.714.265 1.22.937 1.222 1.725A1.853 1.853 0 0 1 7.42 9.67zM4.838 7.945a1.854 1.854 0 0 1 1.22-1.726v3.45a1.853 1.853 0 0 1-1.22-1.724zM6.74 5.028c-1.657 0-3 1.306-3 2.917 0 1.61 1.343 2.916 3 2.916s3-1.306 3-2.916c0-1.611-1.343-2.917-3-2.917z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M12.691 8.03c0 1.862-1.62 3.394-3.394 3.385H6.599c-1.796.009-3.274-1.522-3.274-3.385 0-2.037 1.478-3.445 3.274-3.445h2.698a3.396 3.396 0 0 1 3.394 3.445zm-5.27 1.64V6.22c.713.265 1.22.937 1.22 1.725a1.853 1.853 0 0 1-1.22 1.725zM4.837 7.945a1.854 1.854 0 0 1 1.22-1.726v3.45a1.853 1.853 0 0 1-1.22-1.724zM6.74 5.028c-1.657 0-3 1.306-3 2.917 0 1.61 1.343 2.916 3 2.916s3-1.306 3-2.916c0-1.611-1.343-2.917-3-2.917z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M7.42 9.67V6.22c.714.265 1.22.937 1.222 1.725A1.853 1.853 0 0 1 7.42 9.67M4.838 7.945a1.854 1.854 0 0 1 1.22-1.726v3.45a1.853 1.853 0 0 1-1.22-1.724M6.74 5.028c-1.657 0-3 1.306-3 2.917 0 1.61 1.343 2.916 3 2.916s3-1.306 3-2.916c0-1.611-1.343-2.917-3-2.917"
    />
  </svg>
);

CcDinersClub.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default CcDinersClub;
