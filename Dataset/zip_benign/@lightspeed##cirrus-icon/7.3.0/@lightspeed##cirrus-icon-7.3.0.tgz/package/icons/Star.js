/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Star = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M7.999 13.555l-4.18 2.3c-.64.352-1.061.04-.943-.682l.804-4.903L.298 6.82c-.518-.528-.343-1.047.387-1.158l4.644-.706L7.433.496c.312-.664.822-.658 1.132 0l2.103 4.46 4.644.706c.732.111.91.624.387 1.158l-3.381 3.45.803 4.903c.12.728-.315 1.027-.942.682l-4.18-2.3z"
    />
  </svg>
);

Star.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Star;
