/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const SmallArrowRight = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M10 8.968H3.032a1 1 0 1 1 0-2H10V5.286a.7.7 0 0 1 1.189-.501l2.444 2.385A.998.998 0 0 1 14 8.22a.995.995 0 0 1-.275.52l-2.53 2.536A.7.7 0 0 1 10 10.78V8.968z"
    />
  </svg>
);

SmallArrowRight.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default SmallArrowRight;
