/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const CashOutline = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M13.863 14.01l-.002-.056c-.018-.418.091-.716.32-.923.191-.173.471-.252.82-.27v.614c0 .625 0 .636-.572.636h-.566zM1 12.739c.402.017.83.14 1.003.333.172.189.268.498.284.933h-.836C1 14.011 1 14.011 1 13.5v-.762zM2.287 6c-.023.42-.116.807-.287 1-.176.201-.601.275-.994.294L1 6.664c0-.612.155-.669.71-.669L2.287 6zm12.71 1.255c-.403.008-.684-.094-.867-.295-.183-.2-.277-.507-.27-.947l.858-.008c.167 0 .285.114.285.218l-.007 1.032zM3.428 14c-.025-.785-.137-1.434-.572-1.875-.439-.446-1.072-.604-1.857-.625v-3c.759-.026 1.28-.146 1.714-.586.423-.43.786-1.284.786-1.909 0-.03 3.071-.03 9.214-.005-.013.832.146 1.41.572 1.875.425.465.895.638 1.714.625v3c-.689.024-1.282.202-1.714.641-.49.498-.604 1.03-.572 1.859H3.43zM1.467 5C.674 5 0 5.611 0 6.402v7.196C0 14.388.674 15 1.467 15h13.066c.793 0 1.467-.611 1.467-1.402V6.402C16 5.612 15.326 5 14.533 5H1.467z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M2 2a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1H2zM1 4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1H1z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M8 13a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0-1a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"
      opacity=".7"
    />
  </svg>
);

CashOutline.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default CashOutline;
