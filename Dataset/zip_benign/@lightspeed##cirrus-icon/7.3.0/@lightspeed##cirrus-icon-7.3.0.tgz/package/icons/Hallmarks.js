/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Hallmarks = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M12.467 15.326a.498.498 0 0 1-.286.641.493.493 0 0 1-.428-.036L8 11.996l-3.75 3.93a.494.494 0 0 1-.68-.17.5.5 0 0 1-.039-.43l1.506-4.704c.543.458 1.261.663 1.964.377L8 10.5l.997.5c.814.347 1.239.013 1.888-.5l1.582 4.826z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M4.911 1.857l.402-.946a1.357 1.357 0 0 1 1.78-.719L8 .627 9.322.075a1 1 0 0 1 1.302.552l.519 1.284.946.402c.69.293 1.012 1.09.719 1.78l-.402.945.52 1.284a1 1 0 0 1-.553 1.302l-1.284.519-.402.946a1.357 1.357 0 0 1-1.78.719L8 9.419l-1.322.506a1 1 0 0 1-1.302-.552l-.519-1.284-.946-.402a1.357 1.357 0 0 1-.719-1.78l.402-.945-.52-1.284a1 1 0 0 1 .553-1.302l1.284-.519zM8 7.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M8 7.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z"
      opacity=".7"
    />
  </svg>
);

Hallmarks.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Hallmarks;
