/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const EyeOff = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M10.976 7.602l2.652-2.652c1.43 1.098 2.146 2.25 2.146 2.25.301.4.301 1.2 0 1.6 0 0-2.608 4.2-7.824 4.2-.767 0-1.476-.09-2.126-.246l1.778-1.778c.13.016.263.024.398.024 1.7 0 3-1.3 3-3a3.26 3.26 0 0 0-.024-.398zM8.529 5.043A3.221 3.221 0 0 0 8 5C6.3 5 5 6.3 5 8c0 .199.018.392.052.578l-2.56 2.603C.97 10.047.225 8.8.225 8.8c-.301-.4-.301-1.2 0-1.6 0 0 2.508-4.2 7.724-4.2a9.2 9.2 0 0 1 2.305.288L8.529 5.043z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M12.178 1.333L1.51 12.178c-.889.622-.889 1.778 0 2.489.533.71 1.778.71 2.4 0L14.578 4c.889-.889.889-1.956 0-2.667-.622-.71-1.778-.71-2.4 0z"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M12.8 1.956L2.133 12.8c-.444.356-.444.889 0 1.244.178.356.89.356 1.156 0L13.956 3.2c.444-.267.444-.889 0-1.244-.267-.356-.89-.356-1.156 0z"
    />
  </svg>
);

EyeOff.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default EyeOff;
