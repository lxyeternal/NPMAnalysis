/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Translations = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M11 3H7a3 3 0 0 0-3 3v4c0 .115.007.23.02.341-1.908 1.119-2.862 1.67-2.862 1.657.522-.72.906-2.053 1.152-3.998H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v1z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M13.756 12c.307 1.947.722 3.28 1.244 4l-7-4H7a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-.244zM13 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-1.962-1a1 1 0 0 0-.998-1H7.998a1 1 0 1 0 0 2h2.042a.997.997 0 0 0 .998-1zM11 11a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M13 8a1 1 0 1 1 0-2 1 1 0 0 1 0 2zm-2-1c0-.552-.443-1-.989-1H7.99A.992.992 0 0 0 7 7c0 .552.443 1 .989 1h2.022A.992.992 0 0 0 11 7zm0 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"
    />
  </svg>
);

Translations.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Translations;
