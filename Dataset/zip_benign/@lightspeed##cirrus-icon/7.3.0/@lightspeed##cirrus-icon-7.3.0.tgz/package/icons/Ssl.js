/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Ssl = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M7.996 16c-.986 0-4.685-2.74-5.902-5.6a11.767 11.767 0 0 1-.214-.539c-.73-1.983-.938-4.018-.867-5.702a6.63 6.63 0 0 1 .012-.21l.035-.45.36-.272a30.936 30.936 0 0 1 2.337-1.57c.456-.276.9-.526 1.327-.744C6.227.33 7.19 0 7.996 0c.807 0 1.773.33 2.92.915.425.217.868.466 1.324.742a31.056 31.056 0 0 1 2.34 1.57l.363.272.034.453c.003.04.007.107.01.198.07 1.692-.145 3.745-.894 5.748-.064.17-.131.337-.202.502-1.22 2.857-4.908 5.6-5.895 5.6zM9 7h3.5c.499-1 .502-1.978.499-2.42.003 0 .047.003-.248-.203a29.074 29.074 0 0 0-1.544-1.005A19.072 19.072 0 0 0 10.01 2.7C9.123 2.248 8.41 2 8 2c-.002 0-.002 1.333 0 3.998a1 1 0 0 1-1 1H3.5C3.5 11 7.06 13.985 8 14V8a1 1 0 0 1 1-1z"
    />
  </svg>
);

Ssl.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Ssl;
