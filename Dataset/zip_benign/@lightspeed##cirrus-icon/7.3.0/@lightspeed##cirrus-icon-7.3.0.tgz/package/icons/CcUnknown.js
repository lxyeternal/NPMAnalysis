/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const CcUnknown = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M1.5 3h13A1.5 1.5 0 0 1 16 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 11.5v-7A1.5 1.5 0 0 1 1.5 3zm5.511 3.323c.016-.52.374-.864.895-.864.508 0 .866.3.866.735 0 .472-.191.697-.927 1.126-.754.43-1.025.913-.92 1.83l.016.216h1.69v-.253c0-.504.206-.745.948-1.17.797-.455 1.171-1.003 1.171-1.797C10.75 4.858 9.677 4 8.03 4c-1.735 0-2.765.918-2.78 2.323h1.761zm1.928 4.7c0-.622-.405-.98-1.106-.98-.697 0-1.11.358-1.11.98 0 .618.413.977 1.111.977.7 0 1.105-.36 1.105-.977z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M5.25 6.323h1.761c.016-.52.374-.864.895-.864.508 0 .866.3.866.735 0 .472-.191.697-.927 1.126-.754.43-1.025.913-.92 1.83l.016.216h1.69v-.253c0-.504.206-.745.948-1.17.797-.455 1.171-1.003 1.171-1.797C10.75 4.858 9.677 4 8.03 4c-1.735 0-2.765.918-2.78 2.323zM7.833 12c.7 0 1.106-.36 1.106-.977 0-.622-.405-.98-1.106-.98-.697 0-1.11.358-1.11.98 0 .618.413.977 1.111.977z"
    />
  </svg>
);

CcUnknown.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default CcUnknown;
