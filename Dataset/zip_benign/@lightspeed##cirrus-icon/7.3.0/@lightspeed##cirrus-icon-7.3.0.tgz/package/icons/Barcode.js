/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Barcode = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M0 14v-2a1 1 0 0 1 2 0v1h1a1 1 0 0 1 0 2H1a1 1 0 0 1-1-1zM16 2v2a1 1 0 0 1-2 0V3h-1a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1zm-2 11v-1a1 1 0 0 1 2 0v2a1 1 0 0 1-1 1h-2a1 1 0 0 1 0-2h1zM2 3v1a1 1 0 1 1-2 0V2a1 1 0 0 1 1-1h2a1 1 0 1 1 0 2H2z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M3.5 4a.5.5 0 0 1 .5.5v7a.5.5 0 1 1-1 0v-7a.5.5 0 0 1 .5-.5zm2 0h1a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .5-.5zm3 0a.5.5 0 0 1 .5.5v7a.5.5 0 1 1-1 0v-7a.5.5 0 0 1 .5-.5zm2 0h2a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .5-.5z"
    />
  </svg>
);

Barcode.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Barcode;
