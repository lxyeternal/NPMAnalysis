/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ChevronLeft = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M11.538 11.59c.577.515.62 1.39.095 1.957a1.431 1.431 0 0 1-1.994.093L4.462 9.025a1.367 1.367 0 0 1 0-2.05L9.64 2.36a1.431 1.431 0 0 1 1.994.093 1.366 1.366 0 0 1-.095 1.956L7.51 8l4.028 3.59z"
    />
  </svg>
);

ChevronLeft.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ChevronLeft;
