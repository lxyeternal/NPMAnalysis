/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const GiftcardOutline = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M14.01 13.765c0 .131-.092.238-.207.238H8.011v-5h6v4.762zm-11.763.24a.242.242 0 0 1-.244-.238V9.006h4v5H2.247zm3.755-8.023L6 7H2l.002-.8c0-.12.11-.218.244-.218h3.756zM14 7H8l.005-.98h5.792c.115 0 .208.096.208.216L14 7zM5 5a2 2 0 1 1 2-2 2 2 0 1 1 2 2h4.477C14.654 5 15 5.443 15 7c.333.005.5.113.5.324v1.352c0 .348-.332.324-.5.324v4.5c0 1.29-.27 1.5-1.5 1.5h-11C1.325 15 1 14.764 1 13.5V9.006c-.168 0-.5-.033-.5-.506v-1c0-.489.332-.499.5-.5v-.403C1 5.024 1.326 5 2.521 5H5zm3-1h1a1 1 0 1 0-1-1v1zM6 4V3a1 1 0 1 0-1 1h1z"
    />
  </svg>
);

GiftcardOutline.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default GiftcardOutline;
