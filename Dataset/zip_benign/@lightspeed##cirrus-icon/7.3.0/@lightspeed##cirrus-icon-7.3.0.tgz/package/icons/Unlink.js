/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Unlink = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M9.582 12.07a1.119 1.119 0 0 1-.09.104L5.96 15.707a1.004 1.004 0 0 1-1.415.003L.294 11.456a.994.994 0 0 1 .004-1.416l3.53-3.533c.032-.032.066-.062.101-.089l1.409 1.409-1.799 1.8-1.12 1.124 2.83 2.834 2.122-2.122.8-.804 1.41 1.412zm1.068-3.885l1.81-1.813 1.122-1.123-2.832-2.834L8.63 4.54l-.789.79L6.44 3.903c.022-.026.045-.052.07-.077L10.04.293A1.004 1.004 0 0 1 11.454.29l4.252 4.254a.994.994 0 0 1-.004 1.416l-3.53 3.533c-.04.04-.083.076-.128.108L10.65 8.185zm-.704-.716L8.543 6.043l.25-.25a1 1 0 0 1 1.414 1.414l-.261.262zM7.463 9.952l-.256.255a1 1 0 1 1-1.414-1.414l.255-.256 1.415 1.415z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M3.911 1.333l10.667 10.845c.889.622.889 1.778 0 2.489-.534.71-1.778.71-2.4 0L1.51 4c-.889-.889-.889-1.956 0-2.667.622-.71 1.778-.71 2.4 0zm-.622.623c-.267-.356-.889-.356-1.156 0-.444.355-.444.977 0 1.244L12.8 14.044c.267.356.978.356 1.156 0 .444-.355.444-.888 0-1.244L3.289 1.956z"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M3.289 1.956L13.956 12.8c.444.356.444.889 0 1.244-.178.356-.89.356-1.156 0L2.133 3.2c-.444-.267-.444-.889 0-1.244.267-.356.89-.356 1.156 0z"
    />
  </svg>
);

Unlink.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Unlink;
