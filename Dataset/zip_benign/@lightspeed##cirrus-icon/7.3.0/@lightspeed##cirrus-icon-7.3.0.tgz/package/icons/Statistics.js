/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Statistics = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M5.36 7.08l3.222 3.22a1 1 0 0 0 1.555-.177l4.803-7.685a1 1 0 0 0-.318-1.378l-.848-.53a1 1 0 0 0-1.378.318l-3.47 5.553L5.85 3.327a1 1 0 0 0-1.508.107L1.6 7.095a1 1 0 0 0 .2 1.4l.8.6a1 1 0 0 0 1.4-.2l1.36-1.816z"
    />
    <rect
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      width="14"
      height="2"
      x="1"
      y="14"
      opacity=".7"
      rx="1"
    />
  </svg>
);

Statistics.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Statistics;
