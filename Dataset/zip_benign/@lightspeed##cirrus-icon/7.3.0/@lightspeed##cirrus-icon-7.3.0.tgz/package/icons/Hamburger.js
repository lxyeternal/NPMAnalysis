/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Hamburger = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <rect width="16" height="2" y="2" rx="1" />
    <rect width="16" height="2" y="7" rx="1" />
    <rect width="16" height="2" y="12" rx="1" />
  </svg>
);

Hamburger.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Hamburger;
