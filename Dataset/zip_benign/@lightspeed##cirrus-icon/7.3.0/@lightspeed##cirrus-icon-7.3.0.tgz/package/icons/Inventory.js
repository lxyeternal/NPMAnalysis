/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Inventory = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M1.5 2h13a.5.5 0 1 1 0 1h-13a.5.5 0 0 1 0-1zm1-2h11a.5.5 0 1 1 0 1h-11a.5.5 0 0 1 0-1z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M0 9h16v6a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V9zm1-5h14a1 1 0 0 1 1 1v3H0V5a1 1 0 0 1 1-1zm5.5 7a.5.5 0 1 0 0 1h3a.5.5 0 1 0 0-1h-3z"
    />
    <rect
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      width="4"
      height="1"
      x="6"
      y="11"
      rx=".5"
    />
  </svg>
);

Inventory.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Inventory;
