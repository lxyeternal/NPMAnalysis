/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Domains = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M9.497 10.758a.994.994 0 0 1-.003 1.416l-3.532 3.533a1.005 1.005 0 0 1-1.415.003L.294 11.456a.994.994 0 0 1 .004-1.416l3.531-3.533a1.005 1.005 0 0 1 1.415-.003l.709.709L3.54 9.627 2.42 10.75l2.832 2.834 2.122-2.122.845-.849.571-.564.708.708zm1.263-1.262a1.005 1.005 0 0 0 1.415-.003l3.532-3.533c.4-.4.393-1.026.003-1.416L11.457.29a1.005 1.005 0 0 0-1.415.003L6.51 3.826a.994.994 0 0 0-.004 1.416l.712.712 1.414-1.415 2.12-2.124 2.832 2.834-1.122 1.123-2.412 2.415.71.71z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M10.206 7.207a1 1 0 0 0-1.414-1.414l-3 3a1 1 0 1 0 1.414 1.414l3-3z"
      opacity=".7"
    />
  </svg>
);

Domains.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Domains;
