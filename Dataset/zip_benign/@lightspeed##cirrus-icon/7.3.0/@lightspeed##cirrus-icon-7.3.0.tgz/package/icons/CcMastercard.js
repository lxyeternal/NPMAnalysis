/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const CcMastercard = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M1.5 3h13A1.5 1.5 0 0 1 16 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 11.5v-7A1.5 1.5 0 0 1 1.5 3zm8.5 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M8 5.764C7.386 6.314 7 7.112 7 8c0 .888.386 1.687 1 2.236a3 3 0 1 1 0-4.472z"
      opacity=".7"
    />
    <circle className="cr-icon__details cr-icon__details-1" fill={detailsColor || detailsColor1} cx="10" cy="8" r="3" />
  </svg>
);

CcMastercard.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default CcMastercard;
