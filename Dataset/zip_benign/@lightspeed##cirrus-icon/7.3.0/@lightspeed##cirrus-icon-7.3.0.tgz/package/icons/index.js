import Add from './Add';
import Apps from './Apps';
import AppsPurchased from './AppsPurchased';
import ArrowDown from './ArrowDown';
import ArrowDownLeft from './ArrowDownLeft';
import ArrowDownRight from './ArrowDownRight';
import ArrowLeft from './ArrowLeft';
import ArrowRight from './ArrowRight';
import ArrowUp from './ArrowUp';
import ArrowUpLeft from './ArrowUpLeft';
import ArrowUpRight from './ArrowUpRight';
import Barcode from './Barcode';
import Blogs from './Blogs';
import Brands from './Brands';
import Business from './Business';
import Calendar from './Calendar';
import Cash from './Cash';
import CashOutline from './CashOutline';
import Categories from './Categories';
import CcAmex from './CcAmex';
import CcDebit from './CcDebit';
import CcDinersClub from './CcDinersClub';
import CcDiscover from './CcDiscover';
import CcGeneric from './CcGeneric';
import CcGenericOutline from './CcGenericOutline';
import CcJcb from './CcJcb';
import CcMastercard from './CcMastercard';
import CcMissing from './CcMissing';
import CcUnionPay from './CcUnionPay';
import CcUnknown from './CcUnknown';
import CcVisa from './CcVisa';
import Chat from './Chat';
import Checkmark from './Checkmark';
import Cheque from './Cheque';
import ChevronDown from './ChevronDown';
import ChevronLeft from './ChevronLeft';
import ChevronRight from './ChevronRight';
import ChevronUp from './ChevronUp';
import ChevronUpDown from './ChevronUpDown';
import Clipboard from './Clipboard';
import Clock from './Clock';
import ClockOutline from './ClockOutline';
import Close from './Close';
import Content from './Content';
import ContentTemplates from './ContentTemplates';
import Cross from './Cross';
import CustomFields from './CustomFields';
import CustomerGroups from './CustomerGroups';
import Customers from './Customers';
import Danger from './Danger';
import Dashboard from './Dashboard';
import Delete from './Delete';
import Design from './Design';
import Devices from './Devices';
import DiscountCodes from './DiscountCodes';
import DiscountRules from './DiscountRules';
import Domains from './Domains';
import Download from './Download';
import EcomAm from './EcomAm';
import EcomAs from './EcomAs';
import EcomEu from './EcomEu';
import Edit from './Edit';
import Establishments from './Establishments';
import Export from './Export';
import ExternalLink from './ExternalLink';
import EyeOff from './EyeOff';
import EyeOn from './EyeOn';
import Facebook from './Facebook';
import Faq from './Faq';
import FeatCategories from './FeatCategories';
import FeatProducts from './FeatProducts';
import Files from './Files';
import Filters from './Filters';
import Floors from './Floors';
import Giftcard from './Giftcard';
import GiftcardOutline from './GiftcardOutline';
import Grid from './Grid';
import Hallmarks from './Hallmarks';
import Hamburger from './Hamburger';
import Headlines from './Headlines';
import Help from './Help';
import Home from './Home';
import Image from './Image';
import Images from './Images';
import Import from './Import';
import Info from './Info';
import Inventory from './Inventory';
import Languages from './Languages';
import List from './List';
import Location from './Location';
import LockClosed from './LockClosed';
import LockOpen from './LockOpen';
import Logout from './Logout';
import Mail from './Mail';
import Navigation from './Navigation';
import NoPay from './NoPay';
import Notification from './Notification';
import Orders from './Orders';
import Pages from './Pages';
import Payments from './Payments';
import Pin from './Pin';
import Power from './Power';
import Printers from './Printers';
import ProductOptions from './ProductOptions';
import Products from './Products';
import ProductsResto from './ProductsResto';
import Quotes from './Quotes';
import Receipt from './Receipt';
import Register from './Register';
import Returns from './Returns';
import Reviews from './Reviews';
import Search from './Search';
import Settings from './Settings';
import Shipments from './Shipments';
import Shop from './Shop';
import SmallArrowDown from './SmallArrowDown';
import SmallArrowDownLeft from './SmallArrowDownLeft';
import SmallArrowDownRight from './SmallArrowDownRight';
import SmallArrowLeft from './SmallArrowLeft';
import SmallArrowRight from './SmallArrowRight';
import SmallArrowUp from './SmallArrowUp';
import SmallArrowUpLeft from './SmallArrowUpLeft';
import SmallArrowUpRight from './SmallArrowUpRight';
import SmallChevronDown from './SmallChevronDown';
import SmallChevronLeft from './SmallChevronLeft';
import SmallChevronRight from './SmallChevronRight';
import SmallChevronUp from './SmallChevronUp';
import SortAsc from './SortAsc';
import SortDesc from './SortDesc';
import Specifications from './Specifications';
import Spinner from './Spinner';
import Ssl from './Ssl';
import Star from './Star';
import StarEmpty from './StarEmpty';
import StarHalf from './StarHalf';
import Statistics from './Statistics';
import Suppliers from './Suppliers';
import SupportTickets from './SupportTickets';
import Sync from './Sync';
import ThemeEditor from './ThemeEditor';
import Tools from './Tools';
import Translations from './Translations';
import Unlink from './Unlink';
import Upload from './Upload';
import Users from './Users';
import Verified from './Verified';
import Warning from './Warning';
import ZoomIn from './ZoomIn';
import ZoomOut from './ZoomOut';

export default {
  Add,
  Apps,
  AppsPurchased,
  ArrowDown,
  ArrowDownLeft,
  ArrowDownRight,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ArrowUpLeft,
  ArrowUpRight,
  Barcode,
  Blogs,
  Brands,
  Business,
  Calendar,
  Cash,
  CashOutline,
  Categories,
  CcAmex,
  CcDebit,
  CcDinersClub,
  CcDiscover,
  CcGeneric,
  CcGenericOutline,
  CcJcb,
  CcMastercard,
  CcMissing,
  CcUnionPay,
  CcUnknown,
  CcVisa,
  Chat,
  Checkmark,
  Cheque,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  ChevronUpDown,
  Clipboard,
  Clock,
  ClockOutline,
  Close,
  Content,
  ContentTemplates,
  Cross,
  CustomFields,
  CustomerGroups,
  Customers,
  Danger,
  Dashboard,
  Delete,
  Design,
  Devices,
  DiscountCodes,
  DiscountRules,
  Domains,
  Download,
  EcomAm,
  EcomAs,
  EcomEu,
  Edit,
  Establishments,
  Export,
  ExternalLink,
  EyeOff,
  EyeOn,
  Facebook,
  Faq,
  FeatCategories,
  FeatProducts,
  Files,
  Filters,
  Floors,
  Giftcard,
  GiftcardOutline,
  Grid,
  Hallmarks,
  Hamburger,
  Headlines,
  Help,
  Home,
  Image,
  Images,
  Import,
  Info,
  Inventory,
  Languages,
  List,
  Location,
  LockClosed,
  LockOpen,
  Logout,
  Mail,
  Navigation,
  NoPay,
  Notification,
  Orders,
  Pages,
  Payments,
  Pin,
  Power,
  Printers,
  ProductOptions,
  Products,
  ProductsResto,
  Quotes,
  Receipt,
  Register,
  Returns,
  Reviews,
  Search,
  Settings,
  Shipments,
  Shop,
  SmallArrowDown,
  SmallArrowDownLeft,
  SmallArrowDownRight,
  SmallArrowLeft,
  SmallArrowRight,
  SmallArrowUp,
  SmallArrowUpLeft,
  SmallArrowUpRight,
  SmallChevronDown,
  SmallChevronLeft,
  SmallChevronRight,
  SmallChevronUp,
  SortAsc,
  SortDesc,
  Specifications,
  Spinner,
  Ssl,
  Star,
  StarEmpty,
  StarHalf,
  Statistics,
  Suppliers,
  SupportTickets,
  Sync,
  ThemeEditor,
  Tools,
  Translations,
  Unlink,
  Upload,
  Users,
  Verified,
  Warning,
  ZoomIn,
  ZoomOut,
};
