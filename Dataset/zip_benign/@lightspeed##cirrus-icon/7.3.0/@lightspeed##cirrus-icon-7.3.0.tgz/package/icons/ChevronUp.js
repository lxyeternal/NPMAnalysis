/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ChevronUp = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M4.41 11.538c-.515.577-1.39.62-1.957.095a1.431 1.431 0 0 1-.093-1.994l4.615-5.177c.55-.616 1.5-.616 2.05 0L13.64 9.64c.514.577.473 1.47-.093 1.994a1.366 1.366 0 0 1-1.956-.095L8 7.51l-3.59 4.028z"
    />
  </svg>
);

ChevronUp.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ChevronUp;
