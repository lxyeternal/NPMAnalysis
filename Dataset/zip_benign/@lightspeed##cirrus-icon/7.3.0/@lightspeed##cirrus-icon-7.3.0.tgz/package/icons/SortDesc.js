/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const SortDesc = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M11 4.75c0-.414.594-.75 1-.75s1 .281 1 .695v4.558c.163-.177.412-.442.745-.796a.725.725 0 0 1 1.04 0 .76.76 0 0 1 0 1.06l-2.08 2.122c-.19.195-.42.367-.705.36-.285-.006-.514-.165-.705-.36l-2.08-2.121a.76.76 0 0 1 0-1.061.725.725 0 0 1 1.04 0c.329.33.577.579.745.744V4.75zM2 4h5a1 1 0 1 1 0 2H2a1 1 0 1 1 0-2zm0 3h3a1 1 0 1 1 0 2H2a1 1 0 1 1 0-2zm0 3h1a1 1 0 0 1 0 2H2a1 1 0 0 1 0-2z"
    />
  </svg>
);

SortDesc.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default SortDesc;
