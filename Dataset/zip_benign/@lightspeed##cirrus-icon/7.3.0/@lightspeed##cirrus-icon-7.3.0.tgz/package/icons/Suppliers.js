/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Suppliers = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M5 12V6.5l4.413-2.4c.304-.165.735-.12.963.101a.405.405 0 0 1 .124.3V7l4.439-2.9c.304-.165 1.061-.126 1.061.15V12H5zm3-4a1 1 0 1 0 0 2h1a1 1 0 1 0 0-2H8zm4 0h1a1 1 0 0 1 0 2h-1a1 1 0 0 1 0-2zM1 13h14a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1v-1a1 1 0 0 1 1-1z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M1 4.003h1a1 1 0 0 1 1 1v7H0v-7a1 1 0 0 1 1-1zm1-2.997v1.513a.487.487 0 0 1-.5.484.487.487 0 0 1-.5-.484V0h7.5a.502.502 0 0 1 0 1.006H2z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M8 8h1a1 1 0 1 1 0 2H8a1 1 0 1 1 0-2zm4 0h1a1 1 0 0 1 0 2h-1a1 1 0 0 1 0-2z"
    />
  </svg>
);

Suppliers.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Suppliers;
