/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const SmallArrowLeft = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M6.07 7.092h6.969a1 1 0 1 1 0 2H6.07v1.682a.7.7 0 0 1-1.188.501L2.437 8.891a.998.998 0 0 1-.366-1.05.995.995 0 0 1 .275-.52l2.529-2.536a.7.7 0 0 1 1.195.494v1.813z"
    />
  </svg>
);

SmallArrowLeft.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default SmallArrowLeft;
