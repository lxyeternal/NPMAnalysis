/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const FeatProducts = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M15.26 8.19a11.477 11.477 0 0 1-1.022-.49c-.352-.19-.79-.568-1.188-.672L13 7v.017C12.677 6.95 12.342 7 12 7a5 5 0 0 0-4 8c-1.5 0-2.607-.136-3.5-.5-.599-.244-1.037-.516-1.25-.75-.169-.184-.25-.5-.25-.75V7L1.25 8C.604 8.215 0 8.683 0 8V4c0-.334.222-.565.5-.75C.5 3.25 4.5 1 5 1h.748c.139 0 .258.108.273.245C6.02 1.245 6 3 8 3s1.98-1.755 1.98-1.755A.272.272 0 0 1 10.251 1H11c.5 0 4.5 2.25 4.5 2.25.278.185.5.416.5.75v4c0 .476-.325.37-.74.19z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm1.357-3.194a.147.147 0 0 1 .046-.154l1.545-1.305a.147.147 0 0 0-.094-.26l-1.867-.019a.148.148 0 0 1-.136-.095l-.713-1.878a.148.148 0 0 0-.276 0l-.713 1.877a.148.148 0 0 1-.138.095H9.148a.148.148 0 0 0-.096.26l1.545 1.324a.147.147 0 0 1 .046.154l-.591 2.006a.147.147 0 0 0 .228.162l1.634-1.166a.148.148 0 0 1 .172 0l1.634 1.166a.148.148 0 0 0 .228-.162l-.591-2.005z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M13.357 12.806l.59 2.005a.147.147 0 0 1-.227.162l-1.634-1.166a.148.148 0 0 0-.172 0l-1.634 1.166a.148.148 0 0 1-.228-.162l.591-2.006a.147.147 0 0 0-.046-.154l-1.545-1.325a.147.147 0 0 1 .096-.259h1.863a.148.148 0 0 0 .138-.095l.713-1.877a.148.148 0 0 1 .276 0l.713 1.878a.148.148 0 0 0 .136.095l1.867.02a.148.148 0 0 1 .094.26l-1.545 1.304a.147.147 0 0 0-.046.154z"
    />
  </svg>
);

FeatProducts.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default FeatProducts;
