/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const CcAmex = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8.243 10h4.043l.571-.686.572.686h2.483l-1.796-2L16 6h-2.571l-.572.686L12.286 6h-5.6l-.4.857-.4-.857H1.775L0 10h2.176l.246-.571h.545L3.25 10h4.993zM1.5 3h13A1.5 1.5 0 0 1 16 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 11.5v-7A1.5 1.5 0 0 1 1.5 3zm5.689 3.571h.954V9.43h-.714V7.714l-.78 1.715H6.01l-.867-1.715V9.43h-1.47l-.244-.572H2l-.27.572H.986l1.3-2.858h.948l1.195 2.717V6.57H5.47l.815 1.715.903-1.715zm4.925 0l.743.947.819-.947h.848L13.246 8l1.242 1.429h-.812l-.819-.958-.743.958H9V6.57h3.114zm-.685 2.286v.348L12.457 8 11.43 6.712v.43H9.714v.572h1.715v.572H9.714v.571h1.715zM2.727 7.08L2.23 8.286h1l-.502-1.207z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M8.243 10H3.25l-.283-.571h-.545L2.176 10H0l1.775-4h4.11l.4.857.4-.857h5.601l.571.686L13.43 6H16l-1.884 2 1.796 2h-2.483l-.572-.686-.571.686H8.243zm3.871-3.429H9V9.43h3.114l.743-.958.819.958h.812L13.246 8l1.278-1.429h-.848l-.819.947-.743-.947zm-.685 2.286H9.714v-.571h1.715v-.572H9.714v-.571h1.715v-.43L12.457 8 11.43 9.205v-.348zm-4.24-2.286l-.903 1.715L5.47 6.57H4.429v2.717L3.234 6.57h-.948l-1.3 2.86h.744L2 8.857h1.429l.245.572h1.469V7.714L6.01 9.43h.64l.779-1.715V9.43h.714V6.57h-.954zm-4.462.508l.502 1.207h-1l.498-1.207z"
    />
  </svg>
);

CcAmex.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default CcAmex;
