/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Image = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M13.333 0A2.667 2.667 0 0 1 16 2.667v10.666A2.667 2.667 0 0 1 13.333 16H2.667A2.667 2.667 0 0 1 0 13.333V2.667A2.667 2.667 0 0 1 2.667 0h10.666zM4 6a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M6.098 6.763l2.315 3.81 1.433-1.767c.573-.708 1.56-.771 2.205-.143.1.098.188.209.262.33l1.424 2.343c.48.788.285 1.851-.433 2.376a1.466 1.466 0 0 1-.866.288H3.562C2.7 14 2 13.233 2 12.287c0-.165.022-.33.064-.487L3.3 7.227c.245-.907 1.114-1.425 1.941-1.156.35.114.654.359.857.692z"
      opacity=".7"
      transform="matrix(-1 0 0 1 16 0)"
    />
    <circle className="cr-icon__details cr-icon__details-1" fill={detailsColor || detailsColor1} cx="4" cy="4" r="2" />
  </svg>
);

Image.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Image;
