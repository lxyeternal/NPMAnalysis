/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Products = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M13 13c0 .5-.058.586-.25.77-.222.213-.655.504-1.25.738-.905.354-2 .492-3.5.492s-2.607-.134-3.5-.492c-.599-.24-1.037-.507-1.25-.738C3.081 13.59 3 13.5 3 13v-.934c0 .245.081.556.25.737.213.23.651.498 1.25.738.893.358 2 .459 3.5.459s2.595-.105 3.5-.459c.595-.234 1.028-.525 1.25-.738.192-.185.25-.473.25-.737V13z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M5.748 1c.139 0 .258.108.273.245C6.02 1.245 6 3 8 3s1.98-1.755 1.98-1.755A.272.272 0 0 1 10.251 1H11c.5 0 4.5 2.25 4.5 2.25.278.185.5.416.5.75v4c0 .683-.669.168-1.317-.049L13 7v4c0 .269-.058.562-.25.75-.222.216-.655.512-1.25.75-.905.36-2 .5-3.5.5s-2.607-.136-3.5-.5c-.599-.244-1.037-.516-1.25-.75-.169-.184-.25-.5-.25-.75V7L1.25 8C.604 8.215 0 8.683 0 8V4c0-.334.222-.565.5-.75C.5 3.25 4.5 1 5 1h.748z"
    />
  </svg>
);

Products.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Products;
