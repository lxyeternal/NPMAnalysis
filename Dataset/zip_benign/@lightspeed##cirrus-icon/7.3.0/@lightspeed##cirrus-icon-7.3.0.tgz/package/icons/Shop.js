/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Shop = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M2 1c0-.552.456-1 1.002-1h9.996A.999.999 0 0 1 14 1v1H2V1z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M14 9v5.997A.999.999 0 0 1 13 16h-1v-6h-2v6H2.997A.993.993 0 0 1 2 14.997V9H.72c-.552 0-.842-.412-.643-.938L2 3h12l1.922 5.063c.197.517-.087.937-.642.937H14zM4 10v4h4v-4H4z"
    />
  </svg>
);

Shop.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Shop;
