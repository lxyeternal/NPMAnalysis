/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Filters = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M9.997 12.002L10.5 12c.095 0 .928.005.5.5-1.878 2.171-2.866 3.444-2.868 3.445a.188.188 0 0 1-.272-.008L5 12.5c-.368-.425.287-.5.5-.5.629.001.5.002.5.002.284 0 .451-.334.5-1.002H1.994A1.997 1.997 0 0 1 0 9.003V6.997S-.006 6 .994 6s1 1 1 1v2.003h12.012V6.997s.006-.997 1-.997.994.997.994.997v2.006A1.997 1.997 0 0 1 14.006 11H9.5c.037.669.202 1.003.497 1.002z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M6.496 0c.14 0 .26.105.282.257 0 0-.028 1.076 1.222 1.076S9.224.245 9.224.245A.289.289 0 0 1 9.504 0h.371c.313 0 2.813 1.5 2.813 1.5.173.123.312.277.312.5v2.667c0 .455-.418.112-.823-.033L11.125 4v2.667C11.125 6.846 10.954 8 8 8S4.875 6.833 4.875 6.667V4l-1.094.667c-.404.143-.781.455-.781 0V2c0-.223.139-.377.313-.5 0 0 2.5-1.5 2.812-1.5h.37z"
      opacity=".7"
    />
  </svg>
);

Filters.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Filters;
