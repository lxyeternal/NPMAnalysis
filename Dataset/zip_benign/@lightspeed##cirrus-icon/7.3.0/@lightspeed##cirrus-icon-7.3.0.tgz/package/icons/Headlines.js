/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Headlines = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M4 0h10a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H3.5c.314-.418.5-.937.5-1.5V0zm3 2a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H7z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M0 5h3v9.5a1.5 1.5 0 0 1-3 0V5z"
      opacity=".7"
    />
    <path className="cr-icon__details cr-icon__details-1" fill={detailsColor || detailsColor1} d="M6 2h4v4H6z" />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M13 3a1 1 0 1 1 0 2 1 1 0 0 1 0-2zM7 8h6a1 1 0 0 1 0 2H7a1 1 0 1 1 0-2zm4 4h2a1 1 0 0 1 0 2h-2a1 1 0 0 1 0-2zm-4 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"
      opacity=".7"
    />
  </svg>
);

Headlines.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Headlines;
