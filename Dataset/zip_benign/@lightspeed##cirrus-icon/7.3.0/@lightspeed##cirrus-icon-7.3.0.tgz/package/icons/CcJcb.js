/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const CcJcb = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M1.5 3h13A1.5 1.5 0 0 1 16 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 11.5v-7A1.5 1.5 0 0 1 1.5 3zM11 5a1 1 0 0 0-1 1v5h1a1 1 0 0 0 1-1V5h-1zM5 5a1 1 0 0 0-1 1v5h1a1 1 0 0 0 1-1V5H5z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M5 5h1v5a1 1 0 0 1-1 1H4V6a1 1 0 0 1 1-1z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M8 5h1v5a1 1 0 0 1-1 1H7V6a1 1 0 0 1 1-1z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M11 5h1v5a1 1 0 0 1-1 1h-1V6a1 1 0 0 1 1-1z"
    />
  </svg>
);

CcJcb.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default CcJcb;
