/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const SmallArrowDown = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M7.104 9.995V3.027a1 1 0 1 1 2 0v6.968h1.683a.7.7 0 0 1 .5 1.189l-2.384 2.444a.998.998 0 0 1-1.05.367.995.995 0 0 1-.52-.275l-2.536-2.53a.7.7 0 0 1 .494-1.195h1.813z"
    />
  </svg>
);

SmallArrowDown.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default SmallArrowDown;
