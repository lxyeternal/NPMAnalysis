/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const CcGeneric = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M16 5H0v-.5A1.5 1.5 0 0 1 1.5 3h13A1.5 1.5 0 0 1 16 4.5V5zm0 2v4.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 11.5V7h16zM1.5 11a.5.5 0 1 0 0 1h1a.5.5 0 1 0 0-1h-1z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M1.5 11h1a.5.5 0 1 1 0 1h-1a.5.5 0 1 1 0-1zM0 5h16v2H0V5z"
    />
    <rect
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      width="6"
      height="1"
      x="1"
      y="9"
      opacity=".7"
      rx=".5"
    />
  </svg>
);

CcGeneric.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default CcGeneric;
