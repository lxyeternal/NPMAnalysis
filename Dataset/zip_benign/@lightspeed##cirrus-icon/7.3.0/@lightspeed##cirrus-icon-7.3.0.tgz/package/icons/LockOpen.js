/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const LockOpen = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M4.009 6h7.982C13.098 6 14 6.895 14 8v6a2 2 0 0 1-2.009 2H4.01A2.006 2.006 0 0 1 2 14V8a2 2 0 0 1 2.009-2zm2.13 6.792c-.077.116-.024.209.111.209h3.5c.138 0 .184-.098.111-.209L9 11.5v-1.498a.999.999 0 1 0-2 0V11.5l-.861 1.292z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M6.139 12.792c-.077.116-.024.209.111.209h3.5c.138 0 .184-.098.111-.209L9 11.5v-1.498a1 1 0 0 0-2 0V11.5l-.861 1.292z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M4 6V4s0-4 4-4 4 4 4 4v.748c0 .139-.108.198-.23.137l-1.54-.77a.441.441 0 0 1-.23-.36V4c0-1.105-.888-2-2-2-1.105 0-2 .888-2 2v2H4z"
      opacity=".7"
    />
  </svg>
);

LockOpen.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default LockOpen;
