/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ThemeEditor = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M4.732 4.5l-.967.967c-.531.532-.427 1.66.233 2.508 0 0 .651.862.068 1.444-.031.032-3.385 2.723-3.408 2.747a2.246 2.246 0 0 0 3.177 3.176c.023-.023 2.714-3.376 2.746-3.408.583-.583 1.444.068 1.444.068.848.66 1.976.764 2.508.232l.967-.966L4.732 4.5z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M12.27 3.04l-1.036 1.035a.489.489 0 0 1-.69-.69l1.035-1.036-.69-.691L9.16 3.385a.488.488 0 0 1-.69-.69L10.196.966 9.23 0 5.5 3.73l6.77 6.77L16 6.77l-3.73-3.73z"
    />
  </svg>
);

ThemeEditor.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ThemeEditor;
