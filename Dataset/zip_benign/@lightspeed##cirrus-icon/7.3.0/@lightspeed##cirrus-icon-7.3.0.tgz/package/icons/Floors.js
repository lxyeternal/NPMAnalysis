/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Floors = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M13 10.5l2.106 1.053a.5.5 0 0 1 0 .894l-6.882 3.441a.5.5 0 0 1-.448 0l-6.882-3.44a.5.5 0 0 1 0-.895L3 10.5l4.776 2.388a.5.5 0 0 0 .448 0L13 10.5zM8.224.112l6.882 3.44a.5.5 0 0 1 0 .895L8.224 7.888a.5.5 0 0 1-.448 0L.894 4.448a.5.5 0 0 1 0-.895L7.776.112a.5.5 0 0 1 .448 0z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M13 6.5l2.106 1.053a.5.5 0 0 1 0 .894l-6.882 3.441a.5.5 0 0 1-.448 0L.894 8.448a.5.5 0 0 1 0-.895L3 6.5l4.776 2.388a.5.5 0 0 0 .448 0L13 6.5z"
      opacity=".7"
    />
  </svg>
);

Floors.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Floors;
