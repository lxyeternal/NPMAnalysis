/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Clipboard = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M4 1.245C4 1.11 4.107 1 4.252 1H5l1-1h4l1 1h.748c.139 0 .252.108.252.245v1.51a.248.248 0 0 1-.248.245H4.248A.245.245 0 0 1 4 2.755v-1.51z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M15 8h-1.524a.46.46 0 0 1-.468-.45l.003-1.1a.46.46 0 0 0-.468-.45.478.478 0 0 0-.313.115L8.074 9.336a.219.219 0 0 0-.01.318c.002.002 1.39 1.08 4.166 3.23a.48.48 0 0 0 .66-.033.44.44 0 0 0 .12-.301l-.002-1.087a.46.46 0 0 1 .467-.45H15v2.995c0 1.1-.897 1.992-2.006 1.992H3.006A2 2 0 0 1 1 14.008V2.992C1 1.892 1.897 1 3.006 1h9.988A2 2 0 0 1 15 2.992V8zM3 1v2.505c0 .28.228.495.51.495h8.98c.282 0 .51-.222.51-.495V1H3zm1.501 6a.5.5 0 0 0 0 1h3a.5.5 0 1 0 0-1h-3zM4.5 11a.5.5 0 1 0 0 1h3a.5.5 0 1 0 0-1h-3z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M4.5 9h2a.5.5 0 0 1 0 1h-2a.5.5 0 0 1 0-1z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M4.501 7h3a.5.5 0 1 1 0 1h-3a.5.5 0 0 1 0-1zM4.5 11h3a.5.5 0 1 1 0 1h-3a.5.5 0 1 1 0-1z"
    />
  </svg>
);

Clipboard.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Clipboard;
