/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Cash = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M2 2a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1H2zM1 4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1H1z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M1.467 5h13.066C15.326 5 16 5.611 16 6.402v7.196c0 .79-.674 1.402-1.467 1.402H1.467C.674 15 0 14.389 0 13.598V6.402C0 5.612.674 5 1.467 5zM2 6a1 1 0 0 0-1 1v1a2 2 0 0 0 2-2H2zm11 0a2 2 0 0 0 2 2V7a1 1 0 0 0-1-1h-1zm2 6a2 2 0 0 0-2 2h1a1 1 0 0 0 1-1v-1zM1 12v1a1 1 0 0 0 1 1h1a2 2 0 0 0-2-2z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M8 13a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0-1a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M2 6h1a2 2 0 0 1-2 2V7a1 1 0 0 1 1-1zm11 0h1a1 1 0 0 1 1 1v1a2 2 0 0 1-2-2zm2 6v1a1 1 0 0 1-1 1h-1a2 2 0 0 1 2-2zM1 12a2 2 0 0 1 2 2H2a1 1 0 0 1-1-1v-1z"
    />
  </svg>
);

Cash.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Cash;
