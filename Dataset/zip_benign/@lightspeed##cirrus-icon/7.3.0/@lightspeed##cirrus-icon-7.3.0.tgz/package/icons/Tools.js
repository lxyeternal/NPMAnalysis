/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Tools = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M5.629 5.712a.24.24 0 0 1 .334-.084l2.074 1.244a.3.3 0 0 1 .115.356l-3.299 7.69c-.48 1.018-1.606 1.384-2.524.81l-.163-.101c-.915-.57-1.193-1.804-.613-2.77L5.63 5.712z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M13.554 7.968l-.514-.28a.597.597 0 0 1-.266-.36s-.119-.963-.696-1.277c-.671-.366-1.527.154-1.527.154-.246.11-.662.144-.924.06l-.523-.167 2.55-4.171.415.344c.21.174.39.525.407.785 0 0-.049.96.622 1.326.577.315 1.52-.07 1.52-.07a.681.681 0 0 1 .463.039l.514.28c.12.065.199.254.128.369l-1.818 2.88a.267.267 0 0 1-.35.088zM8.12 0l3.534 1.927-2.55 4.171-3.102-1.69a.457.457 0 0 1-.18-.652L8.12 0zM2.053.223A.479.479 0 0 1 2.427 0H8.12L6.844 2.086 1.911 1.017C1.773.987 1.708.874 1.779.74l.274-.517z"
      opacity=".7"
    />
  </svg>
);

Tools.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Tools;
