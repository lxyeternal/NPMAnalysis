/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Orders = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M4 1.245C4 1.11 4.107 1 4.252 1H5l1-1h4l1 1h.748c.139 0 .252.108.252.245v1.51a.248.248 0 0 1-.248.245H4.248A.245.245 0 0 1 4 2.755v-1.51z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M1 2.992C1 1.892 1.897 1 3.006 1h9.988A2 2 0 0 1 15 2.992v11.016c0 1.1-.897 1.992-2.006 1.992H3.006A2 2 0 0 1 1 14.008V2.992zM3 1v2.505c0 .28.228.495.51.495h8.98c.282 0 .51-.222.51-.495V1H3zm1 6.5c0 .268.224.5.5.5h7c.27 0 .5-.224.5-.5 0-.268-.224-.5-.5-.5h-7c-.27 0-.5.224-.5.5zm0 4c0 .268.224.5.5.5h7c.27 0 .5-.224.5-.5 0-.268-.224-.5-.5-.5h-7c-.27 0-.5.224-.5.5z"
    />
    <rect
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      width="8"
      height="1"
      x="4"
      y="9"
      opacity=".7"
      rx=".5"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M4 7.5c0-.276.23-.5.5-.5h7c.276 0 .5.232.5.5 0 .276-.23.5-.5.5h-7a.505.505 0 0 1-.5-.5zm0 4c0-.276.23-.5.5-.5h7c.276 0 .5.232.5.5 0 .276-.23.5-.5.5h-7a.505.505 0 0 1-.5-.5z"
    />
  </svg>
);

Orders.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Orders;
