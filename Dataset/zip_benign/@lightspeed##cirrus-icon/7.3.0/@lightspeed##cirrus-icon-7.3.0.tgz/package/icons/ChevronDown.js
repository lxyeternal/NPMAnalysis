/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ChevronDown = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M4.41 4.462a1.366 1.366 0 0 0-1.957-.095 1.431 1.431 0 0 0-.093 1.994l4.615 5.177c.55.616 1.5.616 2.05 0L13.64 6.36a1.431 1.431 0 0 0-.093-1.994 1.366 1.366 0 0 0-1.956.095L8 8.49 4.41 4.462z"
    />
  </svg>
);

ChevronDown.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ChevronDown;
