/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const SmallArrowUpLeft = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M7.308 5.974l4.927 4.927a1 1 0 0 1-1.414 1.414L5.894 7.388l-1.19 1.19a.7.7 0 0 1-1.195-.486l-.042-3.415a.998.998 0 0 1 .483-1.002.995.995 0 0 1 .562-.173l3.582-.005a.7.7 0 0 1 .496 1.195L7.308 5.974z"
    />
  </svg>
);

SmallArrowUpLeft.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default SmallArrowUpLeft;
