/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Devices = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 16V4.999A.998.998 0 0 0 7.003 4H5V1.994C5 .893 5.9 0 6.992 0h7.016C15.108 0 16 .895 16 1.994v12.012C16 15.107 15.1 16 14.008 16H8zM0 5.996C0 5.446.438 5 1.003 5h4.994A.999.999 0 0 1 7 5.996v9.008c0 .55-.438.996-1.003.996H1.003A.999.999 0 0 1 0 15.004V5.996z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M8 14V4.999A.998.998 0 0 0 7.003 4H6V2h9v12H8zM1 7h5v7H1V7z"
      opacity=".7"
    />
  </svg>
);

Devices.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Devices;
