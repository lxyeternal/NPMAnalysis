/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Giftcard = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M7 10v6H2a1 1 0 0 1-1-1v-5h6zm2 0h6v5a1 1 0 0 1-1 1H9v-6zm0-5h6a1 1 0 0 1 1 1v2H9V5zM1 5h6v3H0V6a1 1 0 0 1 1-1z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M8 2.5A2.5 2.5 0 1 1 10.5 5h-5A2.5 2.5 0 1 1 8 2.5zM7 4V3a1 1 0 1 0-1 1h1zm2 0h1a1 1 0 1 0-1-1v1z"
      opacity=".7"
    />
  </svg>
);

Giftcard.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Giftcard;
