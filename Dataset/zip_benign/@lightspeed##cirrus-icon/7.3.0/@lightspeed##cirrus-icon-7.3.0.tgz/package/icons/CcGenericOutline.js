/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const CcGenericOutline = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M14.533 2.5V2A1.46 1.46 0 0 1 16 3.452v9.096c0 .79-.648 1.452-1.467 1.452H1.467A1.461 1.461 0 0 1 0 12.548V3.452C0 2.662.648 2 1.467 2h13.066v.5zM1.008 4H1v2h.008v6.563c0 .257.193.452.403.452h13.193c.21 0 .404-.195.404-.452V3.468c0-.257-.194-.453-.404-.453v-.5.5H1.41c-.21 0-.403.196-.403.453V4zm0 0H15v2H1.008V4z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M11.36 7.992h.053c.193 0 .348.156.348.348v.304a.348.348 0 0 1-.348.348h-.054a.348.348 0 0 1-.348-.348V8.34c0-.192.156-.348.348-.348zm1 .011h.054c.193 0 .348.156.348.348v.304a.348.348 0 0 1-.348.348h-.054a.348.348 0 0 1-.348-.348v-.304c0-.192.156-.348.348-.348zm.991-.013h.055c.192 0 .347.156.347.348v.304a.348.348 0 0 1-.347.348h-.055a.348.348 0 0 1-.348-.348v-.304c0-.192.156-.348.348-.348zm-2.993.013h.054c.192 0 .348.156.348.348v.304a.348.348 0 0 1-.348.348h-.054a.348.348 0 0 1-.348-.348v-.304c0-.192.156-.348.348-.348zm-.998.004h.054c.192 0 .348.156.348.348v.304a.348.348 0 0 1-.348.348H9.36a.348.348 0 0 1-.348-.348v-.304c0-.192.155-.348.348-.348zm-1.02-.004h.055c.192 0 .348.156.348.348v.304a.348.348 0 0 1-.348.348h-.054a.348.348 0 0 1-.348-.348v-.304c0-.192.156-.348.348-.348zm-3.733.001h.054c.192 0 .348.156.348.348v.304a.348.348 0 0 1-.348.348h-.054a.348.348 0 0 1-.348-.348v-.304c0-.192.156-.348.348-.348zm-2.25 0h.054c.192 0 .348.156.348.348v.304a.348.348 0 0 1-.348.348h-.054a.348.348 0 0 1-.348-.348v-.304c0-.192.156-.348.348-.348zm1.125 0h.054c.192 0 .348.156.348.348v.304a.348.348 0 0 1-.348.348h-.054a.348.348 0 0 1-.348-.348v-.304c0-.192.156-.348.348-.348z"
      opacity=".7"
    />
  </svg>
);

CcGenericOutline.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default CcGenericOutline;
