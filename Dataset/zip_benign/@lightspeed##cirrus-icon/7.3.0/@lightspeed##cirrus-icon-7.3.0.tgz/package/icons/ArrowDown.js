/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ArrowDown = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2,
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M12.502 8.999a.5.5 0 0 1 .372.833l-4.692 4.975a.25.25 0 0 1-.364 0L3.131 9.832A.5.5 0 0 1 3.503 9H5.5a.5.5 0 0 0 .5-.5V2a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v6.499a.5.5 0 0 0 .5.5h2.002z"
    />
  </svg>
);

ArrowDown.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ArrowDown;
