/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Export = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M0 8.031C0 3.596 3.582 0 8 0s8 3.596 8 8.031c0 4.096-3.054 7.475-7 7.969V8.048a.25.25 0 0 1 .427-.176l.866.869a.997.997 0 0 0 1.414 0c.39-.392.39-1.028 0-1.42l-3-3.011a.997.997 0 0 0-1.414 0l-3 3.011a1.007 1.007 0 0 0 0 1.42.997.997 0 0 0 1.414 0l.866-.87A.25.25 0 0 1 7 8.049V16c-3.946-.494-7-3.873-7-7.969z"
    />
  </svg>
);

Export.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Export;
