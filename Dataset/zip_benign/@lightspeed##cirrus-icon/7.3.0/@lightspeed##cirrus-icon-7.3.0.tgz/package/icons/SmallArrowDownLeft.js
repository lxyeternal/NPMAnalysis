/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const SmallArrowDownLeft = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M5.986 8.758l4.927-4.928a1 1 0 0 1 1.415 1.414L7.4 10.172l1.19 1.19a.7.7 0 0 1-.486 1.194l-3.415.043a.998.998 0 0 1-1.002-.483.995.995 0 0 1-.173-.563L3.51 7.971a.7.7 0 0 1 1.195-.496l1.282 1.283z"
    />
  </svg>
);

SmallArrowDownLeft.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default SmallArrowDownLeft;
