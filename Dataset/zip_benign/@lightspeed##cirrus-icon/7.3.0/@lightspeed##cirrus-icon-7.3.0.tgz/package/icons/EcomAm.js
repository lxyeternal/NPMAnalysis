/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const EcomAm = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 16A8 8 0 1 1 8 0a8 8 0 0 1 0 16zM6.317 1A6.929 6.929 0 0 0 2.75 3.275l.231 2.403.84 1.344 1.576.833 1.218.35 1.25.913-.21.753v1.182l.893 1.613-.683 2.096.419.238.102-.004 4.364-3.244-.21-1.075-1.786-1.559-1.628-.914-1.26.538-.893-1.075-1.996-.968.21-.806 1.786-.215.682 1.021.21-1.827.998-1.828 1.156-.322-1.47-1.183h-.684l-.682-.43-.21 1.29-1.05-.86L6.316 1z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M6.317 1l-.395.539 1.05.86.21-1.29.683.43h.683l1.47 1.183-1.155.322-.998 1.828-.21 1.827-.682-1.021-1.786.215-.21.806 1.996.968.892 1.075 1.261-.538 1.628.914 1.786 1.559.21 1.075-4.364 3.244a6.879 6.879 0 0 1-.102.004l-.419-.238.683-2.096-.893-1.613V9.871l.21-.753-1.25-.914-1.218-.35-1.576-.832-.84-1.344-.231-2.403A6.929 6.929 0 0 1 6.317 1z"
    />
  </svg>
);

EcomAm.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default EcomAm;
