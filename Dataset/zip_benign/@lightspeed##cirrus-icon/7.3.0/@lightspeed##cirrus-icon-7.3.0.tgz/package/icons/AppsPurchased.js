/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const AppsPurchased = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2,
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M1 0h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V1a1 1 0 0 1 1-1zm0 9h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1zm9-9h5a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-5a1 1 0 0 1-1-1V1a1 1 0 0 1 1-1z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M10.984 15.15a.846.846 0 0 0 1.27-.043l3.033-3.618a.923.923 0 0 0-.085-1.268.846.846 0 0 0-1.223.088L11.6 13.147l-1.118-1.076a.845.845 0 0 0-1.226-.006.923.923 0 0 0-.006 1.272l1.733 1.813z"
      opacity=".7"
    />
  </svg>
);

AppsPurchased.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default AppsPurchased;
