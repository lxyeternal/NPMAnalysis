/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Design = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 0a8 8 0 0 1 8 8c0 2.206-1.993 3.667-4.333 3.667H10c-.59 0-1.333.107-1.333 1 0 .875.666 1.426.666 2.333 0 .539-.424 1-1.333 1A8 8 0 1 1 8 0zM5.997 14a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-2.5-5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm7-4a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M3.497 9a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm7-4a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M5.497 5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm7 4a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z"
      opacity=".7"
    />
  </svg>
);

Design.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Design;
