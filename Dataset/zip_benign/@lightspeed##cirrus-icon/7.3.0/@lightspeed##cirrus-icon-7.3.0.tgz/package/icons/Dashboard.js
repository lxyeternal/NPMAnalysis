/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Dashboard = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M0 3.01A3.003 3.003 0 0 1 3.01 0h9.98A3.003 3.003 0 0 1 16 3.01v9.98A3.003 3.003 0 0 1 12.99 16H3.01A3.003 3.003 0 0 1 0 12.99V3.01zm3 .48v3.02c0 .275.22.49.49.49h3.02c.275 0 .49-.22.49-.49V3.49C7 3.215 6.78 3 6.51 3H3.49c-.275 0-.49.22-.49.49zM9 10v2l1 1h2l1-1v-2l-1-1h-2l-1 1z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M3 11c0-1.105.888-2 2-2 1.105 0 2 .888 2 2 0 1.105-.888 2-2 2-1.105 0-2-.888-2-2zm8-8l2 4H9l2-4z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M3 3.49c0-.27.215-.49.49-.49h3.02c.27 0 .49.215.49.49v3.02c0 .27-.215.49-.49.49H3.49A.488.488 0 0 1 3 6.51V3.49zM9 10l1-1h2l1 1v2l-1 1h-2l-1-1v-2z"
    />
  </svg>
);

Dashboard.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Dashboard;
