/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Users = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M0 4.009C0 2.899.895 2 1.994 2h12.012C15.107 2 16 2.902 16 4.009v7.982c0 1.11-.895 2.009-1.994 2.009H1.994A2.003 2.003 0 0 1 0 11.991V4.01zM2.127 9.79c-.22.944.379 1.709 1.355 1.709h3.032c.967 0 1.594-.777 1.355-1.709 0 0-.198-1.791-1.089-1.791s-.99.5-1.782.5c-.791 0-.891-.5-1.782-.5-.892 0-1.09 1.791-1.09 1.791zM6.47 6.25c0-.966-.66-1.75-1.472-1.75-.813 0-1.472.784-1.472 1.75S4.185 8 4.998 8 6.47 7.216 6.47 6.25z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M2.127 9.791S2.324 8 3.216 8c.89 0 .99.5 1.782.5.793 0 .89-.5 1.782-.5.891 0 1.089 1.791 1.089 1.791.24.932-.388 1.709-1.355 1.709H3.482c-.976 0-1.574-.765-1.355-1.709zM6.47 6.25C6.47 7.216 5.81 8 4.998 8c-.813 0-1.472-.784-1.472-1.75S4.185 4.5 4.998 4.5s1.472.784 1.472 1.75z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M10 6.5c0-.276.215-.5.49-.5h3.02a.5.5 0 0 1 .49.5c0 .276-.215.5-.49.5h-3.02a.5.5 0 0 1-.49-.5zm0 3c0-.276.215-.5.49-.5h3.02a.5.5 0 0 1 .49.5c0 .276-.215.5-.49.5h-3.02a.5.5 0 0 1-.49-.5z"
      opacity=".7"
    />
  </svg>
);

Users.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Users;
