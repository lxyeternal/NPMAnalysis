/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Chat = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 12.998l-3.6 2.7a.25.25 0 0 1-.4-.2v-2.5L2 13a2 2 0 0 1-2-2l.004-9a2 2 0 0 1 2-1.999h11.993a2 2 0 0 1 2 2L16 10.998a2 2 0 0 1-2 2H8zm1-7a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-4.962-1a1 1 0 0 0-.998-1H3.998a1 1 0 1 0 0 2H6.04a.997.997 0 0 0 .998-1zm-.038 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm4.962-1c0 .557.447 1 .998 1h2.042a1 1 0 0 0 0-2H9.96a1 1 0 0 0-.998 1z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M9 5.998a1 1 0 1 1 0-2 1 1 0 0 1 0 2zm3 0a1 1 0 1 1 0-2 1 1 0 0 1 0 2zm-4.962-1a1 1 0 0 0-.998-1H3.998a1 1 0 1 0 0 2H6.04a.997.997 0 0 0 .998-1zm-.038 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm-3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm4.962-1a1 1 0 0 1 .998-1h2.042a1 1 0 1 1 0 2H9.96a.997.997 0 0 1-.998-1z"
    />
  </svg>
);

Chat.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Chat;
