/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ProductsResto = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M3.338 11h.664A2 2 0 0 0 6 9V1.675A7.005 7.005 0 0 1 16 8a7.005 7.005 0 0 1-10 6.325v-.33A1 1 0 0 0 5.01 13h-.906A7.056 7.056 0 0 1 4 12.896V11h-.662z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M6 4.001A4.976 4.976 0 0 1 9 3c2.761 0 5 2.244 5 5 0 2.761-2.244 5-5 5a4.996 4.996 0 0 1-4.138-2.195c.308-.148.573-.372.77-.649A4 4 0 1 0 6 5.356V4.001z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M2 14v-4a1.996 1.996 0 0 1-2-1.998V2.5c0-.276.215-.5.498-.5h4.004c.275 0 .498.23.498.5v5.502A2 2 0 0 1 3 10v4h1.502c.275 0 .498.232.498.5 0 .276-.215.5-.498.5H.498A.504.504 0 0 1 0 14.5c0-.276.215-.5.498-.5H2z"
      opacity=".7"
    />
  </svg>
);

ProductsResto.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ProductsResto;
