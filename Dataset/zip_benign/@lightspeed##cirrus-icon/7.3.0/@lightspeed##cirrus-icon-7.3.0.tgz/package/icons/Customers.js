/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Customers = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 16A8 8 0 1 1 8 0a8 8 0 0 1 0 16zm2-10.5C10 4.12 9.105 3 8 3S6 4.12 6 5.5 6.895 8 8 8s2-1.12 2-2.5z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M3.969 11.053C3.743 12.128 4.46 13 5.553 13h4.894c1.1 0 1.83-.87 1.585-1.947 0 0-.4-3.053-1.61-3.053S9.078 8.714 8 8.714C6.925 8.714 6.79 8 5.58 8c-1.211 0-1.61 3.053-1.61 3.053z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M10 5.5C10 6.88 9.105 8 8 8S6 6.88 6 5.5 6.895 3 8 3s2 1.12 2 2.5z"
    />
  </svg>
);

Customers.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Customers;
