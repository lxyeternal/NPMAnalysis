/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Add = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2,
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 16A8 8 0 1 1 8 0a8 8 0 0 1 0 16zM7 7H5c-.516 0-1 .264-1 1 0 .742.531 1 1 1h2v2c0 .453.264 1 1 1 .742 0 1-.547 1-1V9h2c.437 0 1-.264 1-1 0-.742-.531-1-1-1H9V5c0-.422-.264-1-1-1-.742 0-1 .547-1 1v2z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M7 7H5c-.516 0-1 .264-1 1 0 .742.531 1 1 1h2v2c0 .453.264 1 1 1 .742 0 1-.547 1-1V9h2c.437 0 1-.264 1-1 0-.742-.531-1-1-1H9V5c0-.422-.264-1-1-1-.742 0-1 .547-1 1v2z"
    />
  </svg>
);

Add.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Add;
