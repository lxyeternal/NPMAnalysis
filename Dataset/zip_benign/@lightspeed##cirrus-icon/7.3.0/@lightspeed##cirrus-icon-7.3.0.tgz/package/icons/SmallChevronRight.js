/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const SmallChevronRight = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M10.641 7.299c.475.388.482 1.012 0 1.406L6.86 11.8c-.475.389-.86.194-.86-.418V4.623c0-.62.378-.812.86-.418l3.781 3.094z"
    />
  </svg>
);

SmallChevronRight.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default SmallChevronRight;
