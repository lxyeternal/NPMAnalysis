/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Specifications = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M3.676 7L2 5.324 5.324 2 7 3.676 3.676 7zm12.264 7.966a.741.741 0 0 1-.974.974l-4.358-1.874L9 12.464 12.465 9l1.606 1.605 1.869 4.361zM3.828.426l.672.672L1.098 4.5l-.672-.672a1.455 1.455 0 0 1 0-2.058L1.77.426a1.455 1.455 0 0 1 2.058 0z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M14.693 4.985L13.06 3.354a.5.5 0 0 0-.707.707l1.631 1.632-.792.792L12.707 6a.5.5 0 0 0-.707.707l.485.486-.792.792-1.632-1.631a.5.5 0 0 0-.707.707l1.631 1.632-.792.792L9.707 9A.5.5 0 1 0 9 9.707l.485.486-.792.792L7.06 9.354a.5.5 0 1 0-.707.707l1.631 1.632-.792.792L6.707 12a.5.5 0 0 0-.707.707l.485.486-.792.792-1.632-1.631a.5.5 0 1 0-.707.707l1.631 1.632-.998.998a1.055 1.055 0 0 1-1.492 0L.31 13.505a1.055 1.055 0 0 1 0-1.492L12.013.31a1.055 1.055 0 0 1 1.492 0l2.186 2.186c.412.412.412 1.08 0 1.492l-.998.998z"
    />
  </svg>
);

Specifications.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Specifications;
