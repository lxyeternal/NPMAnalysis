/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const StarHalf = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 11.272l2.699 1.485-.519-3.163 2.294-2.34-3.16-.481L8 3.987v7.285zM7.698.122c.29-.246.634-.12.867.373l2.103 4.46 4.644.707c.732.111.91.624.387 1.158l-3.381 3.45.803 4.903c.12.728-.315 1.027-.942.682l-4.18-2.3-4.18 2.3c-.64.352-1.061.04-.943-.682l.804-4.903L.298 6.82c-.518-.528-.343-1.047.387-1.158l4.644-.706L7.433.496a1.09 1.09 0 0 1 .265-.373z"
    />
  </svg>
);

StarHalf.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default StarHalf;
