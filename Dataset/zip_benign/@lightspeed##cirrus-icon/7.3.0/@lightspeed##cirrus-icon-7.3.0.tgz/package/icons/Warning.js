/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Warning = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M6.47 2.215c.845-1.43 2.213-1.435 3.061 0l6.022 10.194c.845 1.431.195 2.591-1.47 2.591H1.917C.26 15-.4 13.844.447 12.41L6.47 2.214zM7.5 4a.5.5 0 0 0-.5.5V9a1 1 0 1 0 2 0V4.5a.5.5 0 0 0-.5-.5h-1zM7 12c0 .556.448 1 1 1 .556 0 1-.448 1-1 0-.556-.448-1-1-1-.556 0-1 .448-1 1z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M7.5 4h1a.5.5 0 0 1 .5.5V9a1 1 0 1 1-2 0V4.5a.5.5 0 0 1 .5-.5zM7 12c0-.552.444-1 1-1 .552 0 1 .444 1 1 0 .552-.444 1-1 1-.552 0-1-.444-1-1z"
    />
  </svg>
);

Warning.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Warning;
