/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Payments = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M14 11h1.001a.998.998 0 0 0 .999-.998V2.998A.998.998 0 0 0 15.001 2H4a.998.998 0 0 0-1 .998V4h10.001c.552 0 .999.446.999.998V11z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M13 7H0V5.998C0 5.447.447 5 .999 5H12c.552 0 .999.446.999.998V7zm0 2v4.002a.998.998 0 0 1-.999.998H1a.998.998 0 0 1-1-.998V9h13z"
    />
  </svg>
);

Payments.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Payments;
