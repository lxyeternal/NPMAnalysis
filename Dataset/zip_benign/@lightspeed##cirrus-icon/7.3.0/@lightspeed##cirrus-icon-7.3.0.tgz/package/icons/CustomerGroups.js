/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const CustomerGroups = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M7.665 8.02c.238-.561.57-1.02 1.02-1.02 1.157 0 1.286.714 2.314.714 1.03 0 1.157-.714 2.314-.714s1.535 3.038 1.535 3.038c.235 1.08-.502 1.962-1.607 1.962h-3.28a3.034 3.034 0 0 0-.032-.169 9.969 9.969 0 0 0-.37-1.617C9.16 8.99 8.607 8.157 7.664 8.02z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M7 6.5C7 7.88 6.105 9 5 9S3 7.88 3 6.5 3.895 4 5 4s2 1.12 2 2.5z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M1.039 12.038C.822 13.122 1.538 14 2.646 14H7.13c1.105 0 1.842-.882 1.607-1.962 0 0-.378-3.038-1.535-3.038s-1.285.714-2.314.714C3.86 9.714 3.73 9 2.574 9s-1.535 3.038-1.535 3.038z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M13 4.5c0 1.38-.895 2.5-2 2.5S9 5.88 9 4.5 9.895 2 11 2s2 1.12 2 2.5z"
      opacity=".7"
    />
  </svg>
);

CustomerGroups.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default CustomerGroups;
