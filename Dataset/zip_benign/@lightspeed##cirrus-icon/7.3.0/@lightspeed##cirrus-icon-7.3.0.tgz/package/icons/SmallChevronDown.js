/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const SmallChevronDown = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M7.299 10.641c.388.475 1.012.482 1.406 0L11.8 6.86c.389-.475.194-.86-.418-.86H4.623c-.62 0-.812.378-.418.86l3.094 3.781z"
    />
  </svg>
);

SmallChevronDown.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default SmallChevronDown;
