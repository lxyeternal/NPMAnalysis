/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Download = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 16A8 8 0 1 1 8 0a8 8 0 0 1 0 16zm-.2-5.267a.25.25 0 0 0 .4 0L10.7 7.4a.25.25 0 0 0-.2-.4H9.25A.25.25 0 0 1 9 6.75v-3.5A.25.25 0 0 0 8.75 3h-1.5a.25.25 0 0 0-.25.25v3.5a.25.25 0 0 1-.25.25H5.5a.25.25 0 0 0-.2.4l2.5 3.333zM5.5 12a.5.5 0 1 0 0 1h5a.5.5 0 1 0 0-1h-5z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M7.8 10.733L5.3 7.4a.25.25 0 0 1 .2-.4h1.25A.25.25 0 0 0 7 6.75v-3.5A.25.25 0 0 1 7.25 3h1.5a.25.25 0 0 1 .25.25v3.5c0 .138.112.25.25.25h1.25a.25.25 0 0 1 .2.4l-2.5 3.333a.25.25 0 0 1-.4 0zM5.5 12h5a.5.5 0 1 1 0 1h-5a.5.5 0 1 1 0-1z"
    />
  </svg>
);

Download.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Download;
