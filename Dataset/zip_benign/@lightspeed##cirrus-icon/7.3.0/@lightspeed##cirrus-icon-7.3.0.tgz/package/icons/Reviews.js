/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Reviews = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M2 0h12a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H7l-3.6 2.7a.25.25 0 0 1-.4-.2V13H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2zm7.81 7.074a.196.196 0 0 1 .061-.205l2.06-1.74a.197.197 0 0 0-.126-.346l-2.488-.026a.197.197 0 0 1-.183-.127l-.95-2.503a.197.197 0 0 0-.368 0l-.95 2.502a.197.197 0 0 1-.184.127H4.197a.197.197 0 0 0-.128.346L6.13 6.869c.059.05.082.13.06.204l-.787 2.675a.196.196 0 0 0 .303.215l2.18-1.553a.197.197 0 0 1 .228 0l2.18 1.553a.197.197 0 0 0 .303-.215L9.81 7.074z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M9.81 7.074l.787 2.674a.197.197 0 0 1-.303.215L8.114 8.41a.197.197 0 0 0-.229 0L5.706 9.963a.197.197 0 0 1-.303-.215l.788-2.675a.196.196 0 0 0-.061-.204L4.069 5.102a.196.196 0 0 1 .128-.346h2.485c.081 0 .155-.05.184-.127l.95-2.502a.197.197 0 0 1 .368 0l.95 2.503a.197.197 0 0 0 .183.127l2.488.026a.197.197 0 0 1 .125.347L9.871 6.869a.196.196 0 0 0-.062.205z"
    />
  </svg>
);

Reviews.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Reviews;
