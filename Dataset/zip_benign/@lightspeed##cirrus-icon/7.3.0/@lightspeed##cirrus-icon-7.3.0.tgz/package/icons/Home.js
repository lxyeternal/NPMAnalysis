/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Home = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M14 15h.5a.5.5 0 1 1 0 1H10v-6H6v6H1.5a.5.5 0 1 1 0-1H2V9.5l6-6 6 6V15z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M8 2L1.5 8.5a.707.707 0 1 1-1-1L2 6V4a1 1 0 0 1 1-1h2L7.293.707a1 1 0 0 1 1.414 0L15.5 7.5a.707.707 0 0 1-1 1L8 2z"
      opacity=".7"
    />
  </svg>
);

Home.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Home;
