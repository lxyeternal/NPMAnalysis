/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const NoPay = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M9.555 4L3.702 9.95A1.999 1.999 0 0 0 2 9v1a1 1 0 0 0 .711.958l-.935.95c-.451-.17-.776-.56-.776-1.03V5.122C1 4.489 1.59 4 2.283 4h7.272zm4.848.174c.356.197.597.543.597.948v5.756c0 .633-.59 1.122-1.283 1.122h-7.14l5.813-5.813A2 2 0 0 0 14 7V6a1 1 0 0 0-.536-.886l.94-.94zM3 5a1 1 0 0 0-1 1v1a2 2 0 0 0 2-2H3zm11 4a2 2 0 0 0-2 2h1a1 1 0 0 0 1-1V9z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M3 5h1a2 2 0 0 1-2 2V6a1 1 0 0 1 1-1zm9 0h1a1 1 0 0 1 1 1v1a2 2 0 0 1-2-2zm2 4v1a1 1 0 0 1-1 1h-1a2 2 0 0 1 2-2zM2 9a2 2 0 0 1 2 2H3a1 1 0 0 1-1-1V9z"
    />
    <path id="Path-2" d="M13.293 1.293a1 1 0 0 1 1.414 1.414l-12 12a1 1 0 0 1-1.414-1.414l12-12z" />
  </svg>
);

NoPay.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default NoPay;
