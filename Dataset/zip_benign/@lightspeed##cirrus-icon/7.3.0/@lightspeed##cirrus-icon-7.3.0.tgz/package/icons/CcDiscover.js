/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const CcDiscover = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M1.5 3h13A1.5 1.5 0 0 1 16 4.5v7a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 11.5v-7A1.5 1.5 0 0 1 1.5 3zM3 7a1 1 0 1 0 0 2h2a1 1 0 1 0 0-2H3zm8 0a1 1 0 0 0 0 2h1a1 1 0 0 0 0-2h-1z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M8.001 7c.561 0 .999.44.999.998A.99.99 0 0 1 8.001 9C7.43 9 7 8.567 7 7.987A.994.994 0 0 1 8.001 7zM16 6v5.5a1.5 1.5 0 0 1-1.5 1.5H3c4.078 0 7.137-.7 9.176-2.1C14.216 9.5 15.49 7.867 16 6z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M3 7h2a1 1 0 1 1 0 2H3a1 1 0 1 1 0-2zm8 0h1a1 1 0 0 1 0 2h-1a1 1 0 0 1 0-2z"
    />
  </svg>
);

CcDiscover.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default CcDiscover;
