/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Printers = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M3 11.25a.253.253 0 0 0-.256-.25H1a.994.994 0 0 1-1-1.003V5.003A1 1 0 0 1 1 4h14c.552 0 1 .438 1 1.003v4.994A.998.998 0 0 1 15.001 11h-1.745a.255.255 0 0 0-.256.25v3.26a.5.5 0 0 1-.51.49H3.51a.497.497 0 0 1-.51-.49v-3.26zm1-3.747v5.994c0 .27.224.503.5.503h7c.27 0 .5-.225.5-.503V7.503A.507.507 0 0 0 11.5 7h-7c-.27 0-.5.225-.5.503z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M4 7.503C4 7.225 4.23 7 4.5 7h7c.276 0 .5.233.5.503v5.994c0 .278-.23.503-.5.503h-7a.507.507 0 0 1-.5-.503V7.503z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M3 2c0-.552.456-1 .995-1h8.01c.55 0 .995.444.995 1v1H3V2z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M5 12.759c0 .133.104.241.258.241h5.484c.143 0 .258-.104.258-.241V8.24c0-.133-.104-.241-.258-.241H5.258C5.115 8 5 8.104 5 8.241v4.518z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M6 9.5c0-.276.215-.5.49-.5h3.02a.5.5 0 0 1 .49.5c0 .276-.215.5-.49.5H6.49A.5.5 0 0 1 6 9.5zm0 2c0-.276.215-.5.49-.5h3.02a.5.5 0 0 1 .49.5c0 .276-.215.5-.49.5H6.49a.5.5 0 0 1-.49-.5zM13 6c0-.552.464-1 1-1 .552 0 1 .464 1 1 0 .552-.464 1-1 1-.552 0-1-.464-1-1z"
      opacity=".7"
    />
  </svg>
);

Printers.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Printers;
