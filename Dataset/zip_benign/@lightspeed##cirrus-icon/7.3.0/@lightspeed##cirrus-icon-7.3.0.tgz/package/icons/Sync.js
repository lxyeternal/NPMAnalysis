/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Sync = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 12a4 4 0 0 0 4-4 1 1 0 0 1 2 0 6 6 0 0 1-6 6v1.396a.25.25 0 0 1-.427.177l-2.396-2.396a.25.25 0 0 1 0-.354l2.396-2.396a.25.25 0 0 1 .427.177V12zm0-8a4 4 0 0 0-4 4 1 1 0 1 1-2 0 6 6 0 0 1 6-6V.604a.25.25 0 0 1 .427-.177l2.396 2.396a.25.25 0 0 1 0 .354L8.427 5.573A.25.25 0 0 1 8 5.396V4z"
    />
  </svg>
);

Sync.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Sync;
