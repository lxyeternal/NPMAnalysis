/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const LockClosed = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M4.015 6h7.97c1.105 0 2.005.895 2.005 2v6c0 1.113-.898 2-2.005 2h-7.97a2.004 2.004 0 0 1-2.005-2V8c0-1.113.898-2 2.005-2zm2.124 6.792c-.077.116-.024.209.111.209h3.5c.138 0 .184-.098.111-.209L9 11.5v-1.498a.999.999 0 1 0-2 0V11.5l-.861 1.292z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M6.139 12.792c-.077.116-.024.209.111.209h3.5c.138 0 .184-.098.111-.209L9 11.5v-1.498a1 1 0 0 0-2 0V11.5l-.861 1.292z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M4 6V4s0-4 4-4 4 4 4 4v2h-2V4c0-1.105-.888-2-2-2-1.105 0-2 .888-2 2v2H4z"
      opacity=".7"
    />
  </svg>
);

LockClosed.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default LockClosed;
