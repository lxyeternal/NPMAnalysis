/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Brands = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M7.254.309A1.05 1.05 0 0 1 8 0h6.795C15.46 0 16 .54 16 1.205V8c0 .28-.111.548-.309.746l-6.636 6.636a2.11 2.11 0 0 1-2.983 0L.618 9.928a2.11 2.11 0 0 1 0-2.983L7.254.31zM12.5 5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM4.714 7.767a.998.998 0 1 0 1.41 1.41l2.832-2.83a.998.998 0 0 0-1.41-1.412L4.714 7.767zm2 1.75a.998.998 0 1 0 1.41 1.41l2.832-2.83a.998.998 0 1 0-1.41-1.412L6.714 9.517z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M12.514 5.003a1.494 1.494 0 0 1-1.487-1.501c0-.83.666-1.502 1.487-1.502.82 0 1.486.672 1.486 1.502 0 .829-.665 1.501-1.486 1.501zM4.79 7.793L7.596 4.96a.982.982 0 0 1 1.398 0c.386.39.386 1.022 0 1.412L6.188 9.206a.982.982 0 0 1-1.398 0 1.006 1.006 0 0 1 0-1.413zm1.98 1.752L9.578 6.71a.982.982 0 0 1 1.398 0c.386.39.386 1.023 0 1.413l-2.807 2.835a.982.982 0 0 1-1.398 0 1.006 1.006 0 0 1 0-1.413z"
    />
  </svg>
);

Brands.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Brands;
