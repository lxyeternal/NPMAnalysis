/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Files = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M1.614 14.39a5.495 5.495 0 0 1 0-7.775l.353-.353 5.11-5.086a4.001 4.001 0 0 1 5.657 0 3.996 3.996 0 0 1 0 5.654l-5.11 5.086-.353.354a2.5 2.5 0 0 1-3.536-3.534l.354-.354 5.11-5.086a1 1 0 0 1 1.414 1.413l-5.11 5.087-.354.354a.5.5 0 1 0 .707.706l.354-.354 5.11-5.087a1.998 1.998 0 0 0 0-2.827 2.001 2.001 0 0 0-2.829 0l-5.11 5.088-.353.353a3.497 3.497 0 0 0 0 4.947 3.502 3.502 0 0 0 4.95 0l.354-.353 5.964-5.93a1 1 0 0 1 1.414 1.414l-5.964 5.93-.354.353a5.502 5.502 0 0 1-7.778 0z"
    />
  </svg>
);

Files.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Files;
