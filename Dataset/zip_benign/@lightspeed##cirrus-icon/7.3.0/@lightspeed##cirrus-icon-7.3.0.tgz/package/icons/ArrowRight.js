/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ArrowRight = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2,
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M9.001 12.5a.5.5 0 0 0 .834.372l4.972-4.69a.25.25 0 0 0 0-.364l-4.972-4.69A.5.5 0 0 0 9 3.5v2a.5.5 0 0 1-.5.5H2a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h6.5a.5.5 0 0 1 .5.5l.001 2z"
    />
  </svg>
);

ArrowRight.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ArrowRight;
