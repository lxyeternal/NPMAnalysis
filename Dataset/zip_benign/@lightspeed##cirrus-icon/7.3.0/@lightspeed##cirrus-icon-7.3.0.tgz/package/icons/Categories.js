/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Categories = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M1.012 4h13.976a1.006 1.006 0 0 1 1.008 1.09l-.744 8.091A2.015 2.015 0 0 1 13.236 15H2.764A2.015 2.015 0 0 1 .75 13.181l-.745-8.09A1.003 1.003 0 0 1 1.012 4zM6 6a1 1 0 1 0 0 2h4a1 1 0 0 0 0-2H6z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M2 1h7a1 1 0 0 1 1 1h4a1 1 0 0 1 1 1H1V2a1 1 0 0 1 1-1z"
      opacity=".7"
    />
    <rect
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      width="6"
      height="2"
      x="5"
      y="6"
      rx="1"
    />
  </svg>
);

Categories.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Categories;
