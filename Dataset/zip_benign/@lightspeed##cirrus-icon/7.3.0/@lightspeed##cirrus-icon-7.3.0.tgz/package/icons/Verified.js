/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Verified = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 16A8 8 0 1 1 8 0a8 8 0 0 1 0 16zm-1.558-5.295a1.12 1.12 0 0 0 1.563-.048l3.733-4.007a.95.95 0 0 0-.105-1.406 1.12 1.12 0 0 0-1.505.099L7.2 8.486 5.825 7.294a1.122 1.122 0 0 0-1.509-.007.95.95 0 0 0-.007 1.409l2.133 2.009z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M6.442 10.705a1.12 1.12 0 0 0 1.563-.048l3.733-4.007a.95.95 0 0 0-.105-1.406 1.12 1.12 0 0 0-1.505.099L7.2 8.486 5.825 7.294a1.122 1.122 0 0 0-1.509-.007.95.95 0 0 0-.007 1.409l2.133 2.009z"
    />
  </svg>
);

Verified.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Verified;
