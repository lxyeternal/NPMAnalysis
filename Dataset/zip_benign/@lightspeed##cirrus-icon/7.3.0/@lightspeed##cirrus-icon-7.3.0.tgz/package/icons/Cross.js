/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Cross = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M10.216 8l3.325-3.325a1.567 1.567 0 1 0-2.216-2.216L8 5.784 4.675 2.459A1.567 1.567 0 0 0 2.46 4.675L5.784 8l-3.325 3.325a1.567 1.567 0 1 0 2.216 2.216L8 10.216l3.325 3.325a1.567 1.567 0 1 0 2.216-2.216L10.216 8z"
    />
  </svg>
);

Cross.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Cross;
