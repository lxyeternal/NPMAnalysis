/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Facebook = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M15.117 16H11.04V9.804h2.08l.311-2.414H11.04V5.848c0-.7.194-1.176 1.196-1.176h1.28v-2.16a17.15 17.15 0 0 0-1.864-.096c-1.844 0-3.106 1.125-3.106 3.192v1.78H6.46v2.415h2.085V16H.885A.866.866 0 0 1 0 15.117V.884C0 .394.396 0 .883 0h14.234c.487 0 .883.396.883.884v14.233a.883.883 0 0 1-.883.883z"
    />
  </svg>
);

Facebook.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Facebook;
