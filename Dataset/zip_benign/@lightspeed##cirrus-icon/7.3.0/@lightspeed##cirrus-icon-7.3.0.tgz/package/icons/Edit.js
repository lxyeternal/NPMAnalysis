/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Edit = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M1.924 10.62l3.456 3.456-4.35 1.864a.74.74 0 0 1-.97-.97l1.864-4.35zm8.64-8.64l3.456 3.456-7.776 7.776-3.456-3.456 7.776-7.776zM12.111.433a1.478 1.478 0 0 1 2.09 0l1.366 1.365a1.478 1.478 0 0 1 0 2.091l-.683.683-3.456-3.456.683-.683z"
    />
  </svg>
);

Edit.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Edit;
