/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ChevronRight = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M4.462 4.41a1.366 1.366 0 0 1-.095-1.957 1.431 1.431 0 0 1 1.994-.093l5.177 4.615c.616.55.616 1.5 0 2.05L6.36 13.64a1.431 1.431 0 0 1-1.994-.093 1.366 1.366 0 0 1 .095-1.956L8.49 8 4.462 4.41z"
    />
  </svg>
);

ChevronRight.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ChevronRight;
