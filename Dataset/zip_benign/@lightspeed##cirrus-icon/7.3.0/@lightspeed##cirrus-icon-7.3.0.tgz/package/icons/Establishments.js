/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Establishments = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M5.332 2.128l4 3.606a.51.51 0 0 1 .168.38v7.379c0 .28-.224.507-.5.507H1a.504.504 0 0 1-.5-.507v-7.38a.51.51 0 0 1 .168-.379l4-3.606c.19-.17.475-.17.664 0zM3.5 10.25a.25.25 0 0 1 .25-.25h2.5a.25.25 0 0 1 .25.25V14h-3v-3.75zM10.25 14h3.25V6.113a.51.51 0 0 0-.168-.379L10 2.73l.668-.602c.19-.17.475-.17.664 0l4 3.606a.51.51 0 0 1 .168.38v7.379c0 .28-.224.507-.5.507h-4.75z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M7.25 14H12c.276 0 .5-.227.5-.507v-7.38a.51.51 0 0 0-.168-.379l-4-3.606a.495.495 0 0 0-.664 0L7 2.73l3.332 3.004a.51.51 0 0 1 .168.38V14H7.25z"
      opacity=".7"
    />
  </svg>
);

Establishments.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Establishments;
