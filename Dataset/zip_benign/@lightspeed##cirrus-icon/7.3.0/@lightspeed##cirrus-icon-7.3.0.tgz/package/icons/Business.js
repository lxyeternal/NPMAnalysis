/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Business = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M11 8H5v-.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5V8H.5a.5.5 0 0 1-.5-.5V4a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v3.5a.5.5 0 0 1-.5.5H13v-.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5V8zm2 1h2.5a.5.5 0 0 1 .5.5V14a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V9.5A.5.5 0 0 1 .5 9H3v.5a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5V9h6v.5a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5V9z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M10 3v-.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5V3H4V1a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2h-2z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M3.5 7h1a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 1 .5-.5zm8 0h1a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 1 .5-.5z"
    />
  </svg>
);

Business.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Business;
