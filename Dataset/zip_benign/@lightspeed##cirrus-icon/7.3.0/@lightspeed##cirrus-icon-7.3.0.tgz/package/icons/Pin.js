/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Pin = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M6.5 11c0 1.25 1.5 4.997 1.5 4.997S9.5 12.25 9.5 11h-3z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M12 1.498a.5.5 0 0 0 .5-.508V.507A.505.505 0 0 0 11.99 0H4.01c-.282 0-.51.22-.51.507V.99c0 .28.232.508.5.508l.248.001c.139 0 .236.11.216.25l-.928 6.499a.302.302 0 0 1-.284.249h-.744A.502.502 0 0 0 2 9.005l.002.484c0 .28.23.508.501.508H13.5a.5.5 0 0 0 .5-.508l-.001-.484a.504.504 0 0 0-.508-.508h-.744a.295.295 0 0 1-.283-.249l-.928-6.499a.21.21 0 0 1 .216-.25H12z"
    />
  </svg>
);

Pin.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Pin;
