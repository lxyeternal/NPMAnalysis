/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const SmallArrowUp = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8.973 6.058v6.969a1 1 0 1 1-2 0V6.058H5.291A.7.7 0 0 1 4.79 4.87l2.385-2.445a.998.998 0 0 1 1.05-.367c.19.036.372.128.52.276l2.536 2.529a.7.7 0 0 1-.494 1.195H8.973z"
    />
  </svg>
);

SmallArrowUp.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default SmallArrowUp;
