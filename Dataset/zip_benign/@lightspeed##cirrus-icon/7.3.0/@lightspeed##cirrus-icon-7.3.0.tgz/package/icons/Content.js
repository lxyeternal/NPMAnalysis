/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Content = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M0 6h16v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V6zm3 2a1 1 0 1 0 0 2h10a1 1 0 0 0 0-2H3z"
    />
    <rect
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      width="12"
      height="2"
      x="2"
      y="8"
      rx="1"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M2 0h12a2 2 0 0 1 2 2v2H0V2a2 2 0 0 1 2-2zm0 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm3 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M2 3a1 1 0 1 1 0-2 1 1 0 0 1 0 2zm3 0a1 1 0 1 1 0-2 1 1 0 0 1 0 2zm3 0a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"
    />
    <rect
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      width="9"
      height="2"
      x="2"
      y="12"
      opacity=".7"
      rx="1"
    />
  </svg>
);

Content.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Content;
