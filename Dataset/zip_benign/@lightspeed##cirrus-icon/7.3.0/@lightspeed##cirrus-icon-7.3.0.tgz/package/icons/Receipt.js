/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Receipt = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M3 0h10a2 2 0 0 1 2 2v13.001a1 1 0 0 1-1.003 1L13 16l-2.5-2L8 16l-2.5-2L3 16l-.997.001a1 1 0 0 1-1.003-1V2a2 2 0 0 1 2-2zm1 10a1 1 0 0 0 0 2h2a1 1 0 0 0 0-2H4zm0-3a1 1 0 1 0 0 2h4a1 1 0 1 0 0-2H4zm8 3a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm0-3a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M4 10h2a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2zm0-3h4a1 1 0 1 1 0 2H4a1 1 0 1 1 0-2zm8 3a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm0-3a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"
    />
    <rect
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      width="10"
      height="3"
      x="3"
      y="2"
      opacity=".7"
      rx="1"
    />
  </svg>
);

Receipt.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Receipt;
