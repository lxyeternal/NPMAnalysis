/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ArrowLeft = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2,
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M7.004 3.5a.5.5 0 0 0-.834-.372l-4.977 4.69a.25.25 0 0 0 0 .364l4.977 4.69a.5.5 0 0 0 .834-.372L7 10.5a.5.5 0 0 1 .5-.5H14a1 1 0 0 0 1-1V7a1 1 0 0 0-1-1H7.5a.5.5 0 0 1-.5-.5l.004-2z"
    />
  </svg>
);

ArrowLeft.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ArrowLeft;
