/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Notification = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M13 10.691V6.5C13 4 12 2 9.5 2v-.5a1.5 1.5 0 0 0-3 0V2C4 2 3 4 3 6.5v4.191a.5.5 0 0 1-.276.447l-1.448.724a.5.5 0 0 0-.276.447v.191a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5v-.191a.5.5 0 0 0-.276-.447l-1.448-.724a.5.5 0 0 1-.276-.447z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M6 14h4a2 2 0 1 1-4 0z"
      opacity=".7"
    />
  </svg>
);

Notification.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Notification;
