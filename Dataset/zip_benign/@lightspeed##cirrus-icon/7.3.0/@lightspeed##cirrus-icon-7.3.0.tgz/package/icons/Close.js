/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Close = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zm1.478 8l2.216-2.216a1.045 1.045 0 1 0-1.478-1.478L8 6.522 5.784 4.306a1.045 1.045 0 0 0-1.478 1.478L6.522 8l-2.216 2.216a1.045 1.045 0 1 0 1.478 1.478L8 9.478l2.216 2.216a1.045 1.045 0 1 0 1.478-1.478L9.478 8z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M9.478 8l2.216-2.216a1.045 1.045 0 1 0-1.478-1.478L8 6.522 5.784 4.306a1.045 1.045 0 0 0-1.478 1.478L6.522 8l-2.216 2.216a1.045 1.045 0 1 0 1.478 1.478L8 9.478l2.216 2.216a1.045 1.045 0 1 0 1.478-1.478L9.478 8z"
    />
  </svg>
);

Close.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Close;
