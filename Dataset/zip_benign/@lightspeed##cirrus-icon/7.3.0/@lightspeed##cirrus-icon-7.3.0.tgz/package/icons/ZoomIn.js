/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ZoomIn = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M15.561 15.56c-.283.284-.659.44-1.06.44-.4 0-.777-.156-1.06-.44l-2.677-2.676a6.955 6.955 0 0 1-3.769 1.108 6.996 6.996 0 1 1 6.995-6.996 6.962 6.962 0 0 1-1.105 3.767l2.676 2.677a1.501 1.501 0 0 1 0 2.12zM6 6H4a1 1 0 1 0 0 2h2v2a1 1 0 0 0 2 0V8h2a1 1 0 0 0 0-2H8V4a1 1 0 1 0-2 0v2z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M6 6H4a1 1 0 1 0 0 2h2v2a1 1 0 0 0 2 0V8h2a1 1 0 0 0 0-2H8V4a1 1 0 1 0-2 0v2z"
    />
  </svg>
);

ZoomIn.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ZoomIn;
