/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ProductOptions = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M3 0h10a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2zm3.874 2H6.5c-.25 0-2.25 1.125-2.25 1.125-.139.092-.25.208-.25.375v2c0 .341.302.107.625 0L6 5l-.36 2.876A1 1 0 0 0 6.634 9h2.734a1 1 0 0 0 .992-1.124L10 5l1.341.476c.325.108.659.365.659.024v-2c0-.167-.111-.283-.25-.375 0 0-2-1.125-2.25-1.125h-.374a.136.136 0 0 0-.136.123S9 3 8 3s-.99-.877-.99-.877A.139.139 0 0 0 6.874 2z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M3 11.999c0-.552.443-.999.999-.999h1.002c.552 0 .999.443.999.999v1.002a.996.996 0 0 1-.999.999H3.999A.996.996 0 0 1 3 13.001v-1.002zM4 12v1h1v-1H4zm3.5-1h5a.5.5 0 1 1 0 1h-5a.5.5 0 1 1 0-1zm0 2h5a.5.5 0 1 1 0 1h-5a.5.5 0 1 1 0-1z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M6.874 2c.07 0 .129.054.136.123 0 0-.01.877.99.877s.99-.877.99-.877A.136.136 0 0 1 9.126 2H9.5c.25 0 2.25 1.125 2.25 1.125.139.092.25.208.25.375v2c0 .341-.335.084-.659-.024L10 5l.36 2.876A1 1 0 0 1 9.366 9H6.633a1 1 0 0 1-.992-1.124L6 5l-1.375.5c-.323.107-.625.341-.625 0v-2c0-.167.111-.283.25-.375 0 0 2-1.125 2.25-1.125h.374z"
    />
  </svg>
);

ProductOptions.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ProductOptions;
