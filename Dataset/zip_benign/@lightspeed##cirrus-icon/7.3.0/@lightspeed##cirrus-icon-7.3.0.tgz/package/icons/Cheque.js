/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Cheque = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M1 4h9v8H1a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1zm13 0h1a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1h-1V4zM2.5 7a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1h-3zm0 2a.5.5 0 0 0 0 1h5a.5.5 0 0 0 0-1h-5z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M12.845 14.37l-.621 1.488a.247.247 0 0 1-.448 0l-.621-1.488a2 2 0 0 1-.155-.771v-11.6h2v11.6a2 2 0 0 1-.155.771zM11.5 0h1a.5.5 0 0 1 .5.5V1h-2V.5a.5.5 0 0 1 .5-.5z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M2.5 7h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1 0-1zm0 2h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1 0-1z"
    />
  </svg>
);

Cheque.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Cheque;
