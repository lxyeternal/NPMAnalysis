/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const SmallArrowDownRight = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8.77 10.08L3.842 5.151a1 1 0 0 1 1.415-1.414l4.927 4.927 1.19-1.19a.7.7 0 0 1 1.194.487l.043 3.415a.998.998 0 0 1-.483 1.001.995.995 0 0 1-.563.173l-3.581.005a.7.7 0 0 1-.496-1.195l1.282-1.28z"
    />
  </svg>
);

SmallArrowDownRight.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default SmallArrowDownRight;
