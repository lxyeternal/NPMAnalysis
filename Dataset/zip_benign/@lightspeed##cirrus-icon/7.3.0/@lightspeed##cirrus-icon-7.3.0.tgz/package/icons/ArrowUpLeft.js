/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ArrowUpLeft = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2,
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M2.467 9.944l-.45-7.663a.25.25 0 0 1 .264-.264l7.663.45a.25.25 0 0 1 .162.427L8.354 4.646a.5.5 0 0 0 0 .708l4.939 4.939a1 1 0 0 1 0 1.414l-1.586 1.586a1 1 0 0 1-1.414 0l-4.94-4.94a.5.5 0 0 0-.707 0l-1.752 1.753a.25.25 0 0 1-.427-.162z"
    />
  </svg>
);

ArrowUpLeft.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ArrowUpLeft;
