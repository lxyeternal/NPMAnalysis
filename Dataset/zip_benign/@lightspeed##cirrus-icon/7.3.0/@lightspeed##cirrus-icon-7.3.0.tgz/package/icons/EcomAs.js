/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const EcomAs = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 16A8 8 0 1 1 8 0a8 8 0 0 1 0 16zM6.767 1.004C3.489 1.6 1 4.515 1 8.024c0 .598.072 1.18.209 1.735l.622 1.512h.768l.236-1.684.65-1.503.65-.421.945 1.323.354.601.945-.902.473.301.945 1.323h.768l1.004-.722-.265-.601v-.902l.738-.421.768-.722V5.98l-.768-1.504h.414l1.063 1.143.354-.601-.354-1.023 1.063-.48.154-.747A6.935 6.935 0 0 0 9.217 1l-1.183.649-1.267-.645zm6.784 11.374l-.378-.385-1.004-.36-.71.36-.59-.36-.945.961-1.004.542v.902l.295.962.709-.24.709-.722.392.42a7.058 7.058 0 0 0 2.526-2.08zm-.792-7.963v.902l-.295.842-.65.542v.601h.65l.709-1.443.236-.842-.65-.602zm-1.83 3.609l-.296.42.295.362.532-.361-.532-.421zm-3.25 2.345l.65 1.383h1.359l-1.064-.721-.945-.662zm3.19-.24l.65.48H12.7l.591.482H14l-1.063-.962h-2.068z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M6.767 1.004l1.267.645L9.217 1a6.935 6.935 0 0 1 3.52 1.767l-.155.746-1.063.481.354 1.023-.354.601-1.063-1.143h-.414l.768 1.504v.962l-.768.722-.738.42v.903l.265.601-1.004.722h-.768l-.945-1.323-.473-.3-.945.901-.354-.601-.945-1.323-.65.42-.65 1.504-.236 1.684H1.83L1.209 9.76A7.268 7.268 0 0 1 1 8.024c0-3.509 2.489-6.425 5.767-7.02zm6.784 11.374a7.058 7.058 0 0 1-2.526 2.08l-.392-.42-.71.721-.708.241-.295-.962v-.902l1.004-.542.945-.962.59.361.71-.36 1.004.36.378.385zm-.792-7.963l.65.602-.236.842-.709 1.443h-.65v-.601l.65-.542.295-.842v-.902zm-1.83 3.609l.53.42-.53.362-.296-.361.295-.421zm-3.25 2.345l.945.662 1.064.721h-1.36L7.68 10.37zm3.19-.24h2.068L14 11.09h-.709l-.59-.481h-1.182l-.65-.481z"
    />
  </svg>
);

EcomAs.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default EcomAs;
