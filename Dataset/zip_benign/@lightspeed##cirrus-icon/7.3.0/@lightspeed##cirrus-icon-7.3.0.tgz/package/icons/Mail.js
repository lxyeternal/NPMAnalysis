/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Mail = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M2 2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zm.854 2.158a.475.475 0 0 0-.708 0 .568.568 0 0 0 0 .761l5.5 5.923c.196.21.512.21.708 0l5.5-5.923a.568.568 0 0 0 0-.761.475.475 0 0 0-.708 0l-4.78 5.147a.5.5 0 0 1-.732 0l-4.78-5.147z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M4.601 7.563l.693.746-2.441 2.53a.487.487 0 0 1-.707 0 .531.531 0 0 1 0-.732l2.455-2.544zm6.1.75l.693-.746 2.45 2.54c.472.488-.235 1.22-.706.732l-2.437-2.525z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M2.854 4.158a.475.475 0 0 0-.708 0 .568.568 0 0 0 0 .761l5.5 5.923c.196.21.512.21.708 0l5.5-5.923a.568.568 0 0 0 0-.761.475.475 0 0 0-.708 0l-4.78 5.147a.5.5 0 0 1-.732 0l-4.78-5.147z"
    />
  </svg>
);

Mail.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Mail;
