/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const CustomFields = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M2 0h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2zm1 2a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H3zm6.5 2a.5.5 0 0 0 0 1h4a.5.5 0 1 0 0-1h-4zM3 9a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1H3zm6.5 2a.5.5 0 1 0 0 1h4a.5.5 0 1 0 0-1h-4z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M9.5 4h4a.5.5 0 1 1 0 1h-4a.5.5 0 0 1 0-1zm0 7h4a.5.5 0 1 1 0 1h-4a.5.5 0 1 1 0-1zM3 9h3a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1zm0-7h3a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z"
    />
    <circle
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      cx="4.5"
      cy="11.5"
      r="1.5"
      opacity=".7"
    />
  </svg>
);

CustomFields.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default CustomFields;
