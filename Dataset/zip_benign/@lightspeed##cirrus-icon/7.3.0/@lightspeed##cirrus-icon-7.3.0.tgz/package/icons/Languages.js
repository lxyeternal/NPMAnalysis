/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Languages = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M9.528 14H2.997A3.003 3.003 0 0 1 0 11.005v-8.01A3.003 3.003 0 0 1 3.002 0h9.996A3.007 3.007 0 0 1 16 3.002V14a2 2 0 0 1-2.894 1.789L9.528 14zm2.464-3.002L8.777 3.004H7.226l-3.221 7.994h1.189a.53.53 0 0 0 .498-.337l.765-1.949h3.114l.734 1.95a.604.604 0 0 0 .187.24.51.51 0 0 0 .322.096h1.178zm-2.84-3.427l-2.319.012s1.113-3.06 1.162-3.247c.053.188 1.157 3.235 1.157 3.235z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M11.992 10.998h-1.178a.51.51 0 0 1-.322-.096.604.604 0 0 1-.187-.24l-.734-1.95H6.457l-.765 1.95a.53.53 0 0 1-.498.336h-1.19l3.222-7.994h1.55l3.216 7.994zm-2.84-3.427S8.048 4.524 7.995 4.336c-.049.188-1.162 3.247-1.162 3.247l2.319-.012z"
    />
  </svg>
);

Languages.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Languages;
