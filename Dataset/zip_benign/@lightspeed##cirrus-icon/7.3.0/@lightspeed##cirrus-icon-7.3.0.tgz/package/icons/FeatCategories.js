/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const FeatCategories = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M10.995 7.101A1 1 0 0 0 10 6H6a1 1 0 1 0 0 2h3a4.992 4.992 0 0 0-2 4c0 1.126.372 2.164 1 3H3c-1.047 0-1.905-.97-2-2L0 5c0-.5.5-1 1-1h14c.512 0 1 .5 1 1 0 .013-.145 1.178-.435 3.494A4.985 4.985 0 0 0 12 7c-.344 0-.68.035-1.005.101zM2 1h7a1 1 0 0 1 1 1h4a1 1 0 0 1 1 1H1V2a1 1 0 0 1 1-1z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M13.357 12.806l.59 2.005a.147.147 0 0 1-.227.162l-1.634-1.166a.148.148 0 0 0-.172 0l-1.634 1.166a.148.148 0 0 1-.228-.162l.591-2.006a.147.147 0 0 0-.046-.154l-1.545-1.325a.147.147 0 0 1 .096-.259h1.863a.148.148 0 0 0 .138-.095l.713-1.877a.148.148 0 0 1 .276 0l.713 1.878a.148.148 0 0 0 .136.095l1.867.02a.148.148 0 0 1 .094.26l-1.545 1.304a.147.147 0 0 0-.046.154z"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm1.357-3.194a.147.147 0 0 1 .046-.154l1.545-1.305a.147.147 0 0 0-.094-.26l-1.867-.019a.148.148 0 0 1-.136-.095l-.713-1.878a.148.148 0 0 0-.276 0l-.713 1.877a.148.148 0 0 1-.138.095H9.148a.148.148 0 0 0-.096.26l1.545 1.324a.147.147 0 0 1 .046.154l-.591 2.006a.147.147 0 0 0 .228.162l1.634-1.166a.148.148 0 0 1 .172 0l1.634 1.166a.148.148 0 0 0 .228-.162l-.591-2.005z"
    />
  </svg>
);

FeatCategories.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default FeatCategories;
