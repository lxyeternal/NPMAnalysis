/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Import = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M3.009 16A2.003 2.003 0 0 1 1 14.006V1.994C1 .894 1.9 0 3.009 0h7.982L15 3.994v10.012c0 1.1-.9 1.994-2.009 1.994H3.01zM7.8 9.733a.25.25 0 0 0 .4 0L10.7 6.4a.25.25 0 0 0-.2-.4H9.25A.25.25 0 0 1 9 5.75v-1.5A.25.25 0 0 0 8.75 4h-1.5a.25.25 0 0 0-.25.25v1.5a.25.25 0 0 1-.25.25H5.5a.25.25 0 0 0-.2.4l2.5 3.333zM5.5 11a.5.5 0 1 0 0 1h5a.5.5 0 1 0 0-1h-5z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M11 0l4 4h-3.5a.5.5 0 0 1-.5-.5V0z"
      opacity=".7"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M7.8 9.733L5.3 6.4a.25.25 0 0 1 .2-.4h1.25A.25.25 0 0 0 7 5.75v-1.5A.25.25 0 0 1 7.25 4h1.5a.25.25 0 0 1 .25.25v1.5c0 .138.112.25.25.25h1.25a.25.25 0 0 1 .2.4L8.2 9.733a.25.25 0 0 1-.4 0zM5.5 11h5a.5.5 0 1 1 0 1h-5a.5.5 0 1 1 0-1z"
    />
  </svg>
);

Import.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Import;
