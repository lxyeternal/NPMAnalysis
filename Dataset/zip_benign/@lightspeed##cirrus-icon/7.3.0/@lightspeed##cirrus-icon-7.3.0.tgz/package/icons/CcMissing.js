/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const CcMissing = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M15 13h-1v-1h1v-1h1v1a1 1 0 0 1-1 1zM1 3h1v1H1v1H0V4a1 1 0 0 1 1-1zm-1 9v-1h1v1h1v1H1a1 1 0 0 1-1-1zm16-8v1h-1V4h-1V3h1a1 1 0 0 1 1 1zM4 3h3v1H4V3zm5 0h3v1H9V3zm0 9h3v1H9v-1zm-5 0h3v1H4v-1zm11-5h1v2h-1V7zM0 7h1v2H0V7z"
    />
  </svg>
);

CcMissing.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default CcMissing;
