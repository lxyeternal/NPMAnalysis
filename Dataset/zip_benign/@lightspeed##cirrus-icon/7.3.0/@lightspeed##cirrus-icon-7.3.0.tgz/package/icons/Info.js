/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Info = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 16A8 8 0 1 1 8 0a8 8 0 0 1 0 16zm1-9.204H7v5.2h2v-5.2zm.06-1.79a.917.917 0 0 0-.085-.393 1.035 1.035 0 0 0-.232-.32 1.122 1.122 0 0 0-1.162-.215 1.064 1.064 0 0 0-.559.535.943.943 0 0 0 0 .777.98.98 0 0 0 .227.314c.096.09.207.162.332.216a1.088 1.088 0 0 0 .82 0c.129-.054.243-.125.342-.216.098-.09.175-.195.232-.314a.886.886 0 0 0 .085-.384z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M9 6.796v5.2H7v-5.2h2zm.06-1.79a.886.886 0 0 1-.085.384 1.01 1.01 0 0 1-.232.314 1.141 1.141 0 0 1-.76.296c-.144 0-.278-.027-.402-.08a1.134 1.134 0 0 1-.332-.216.995.995 0 0 1-.227-.314.943.943 0 0 1 0-.776A1.064 1.064 0 0 1 7.982 4a1.122 1.122 0 0 1 .76.292c.099.092.176.199.233.32a.917.917 0 0 1 .085.393z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M8 14A6 6 0 1 0 8 2a6 6 0 0 0 0 12zm0 1A7 7 0 1 1 8 1a7 7 0 0 1 0 14z"
      opacity=".7"
    />
  </svg>
);

Info.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Info;
