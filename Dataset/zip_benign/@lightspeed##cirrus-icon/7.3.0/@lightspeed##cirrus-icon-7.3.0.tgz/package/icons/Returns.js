/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Returns = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M0 3.303a1 1 0 0 1 .168-.555L1.703.445A1 1 0 0 1 2.535 0h10.93a1 1 0 0 1 .832.445l1.535 2.303a1 1 0 0 1 .168.555v.447a.25.25 0 0 1-.25.25H.25A.25.25 0 0 1 0 3.75v-.447zM.25 6h15.5a.25.25 0 0 1 .25.25V14a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V6.25A.25.25 0 0 1 .25 6zM4 11l3.675 2.953A.2.2 0 0 0 8 13.797v-1.526c0-.11.09-.2.2-.2h3.3a.5.5 0 0 0 .5-.5V10.43a.5.5 0 0 0-.5-.5H8.2a.2.2 0 0 1-.2-.2V8.203a.2.2 0 0 0-.325-.156L4 11z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M4 11l3.675 2.953A.2.2 0 0 0 8 13.797v-1.526c0-.11.09-.2.2-.2h3.3a.5.5 0 0 0 .5-.5V10.43a.5.5 0 0 0-.5-.5H8.2a.2.2 0 0 1-.2-.2V8.203a.2.2 0 0 0-.325-.156L4 11z"
    />
    <path
      className="cr-icon__details cr-icon__details-2"
      fill={detailsColor || detailsColor2}
      d="M7 0h2v4H7z"
      opacity=".7"
    />
  </svg>
);

Returns.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Returns;
