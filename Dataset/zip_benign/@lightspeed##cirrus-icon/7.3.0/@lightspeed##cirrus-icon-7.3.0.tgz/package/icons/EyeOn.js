/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const EyeOn = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M15.774 8.8S13.166 13 7.95 13C2.734 13 .226 8.8.226 8.8c-.301-.4-.301-1.2 0-1.6 0 0 2.508-4.2 7.724-4.2s7.824 4.2 7.824 4.2c.301.4.301 1.2 0 1.6zM8 11c1.7 0 3-1.3 3-3S9.7 5 8 5 5 6.3 5 8s1.3 3 3 3z"
    />
    <circle className="cr-icon__base cr-icon__base-2" fill={baseColor || baseColor2} cx="8" cy="8" r="2" opacity=".7" />
  </svg>
);

EyeOn.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default EyeOn;
