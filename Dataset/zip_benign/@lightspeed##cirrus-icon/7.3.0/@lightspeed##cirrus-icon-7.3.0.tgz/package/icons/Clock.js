/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Clock = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M8 16A8 8 0 1 1 8 0a8 8 0 0 1 0 16zM7 3.25v6.5c0 .129.108.25.241.25h4.518A.24.24 0 0 0 12 9.755v-1.51A.25.25 0 0 0 11.744 8H9.256A.248.248 0 0 1 9 7.759V3.24A.241.241 0 0 0 8.755 3h-1.51A.246.246 0 0 0 7 3.25z"
    />
    <path
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      d="M7 3.25c0-.138.108-.25.245-.25h1.51A.24.24 0 0 1 9 3.241V7.76c0 .133.114.241.256.241h2.488a.25.25 0 0 1 .256.245v1.51a.241.241 0 0 1-.241.245H7.24C7.108 10 7 9.879 7 9.75v-6.5z"
    />
  </svg>
);

Clock.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Clock;
