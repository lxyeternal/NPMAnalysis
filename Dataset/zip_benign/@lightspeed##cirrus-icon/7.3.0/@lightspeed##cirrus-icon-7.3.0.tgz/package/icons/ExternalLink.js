/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ExternalLink = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M7.559 0c-.125.73.096 1.551.743 2.261L7.574 3H4a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V8.309l.63-.638c.733.744 1.601.999 2.37.866V14a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.559z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M11 2.25L6.25 7c-.526.534-.022 1.72.5 2.25 1.152.853 1.902 1.103 2.25.75l4.5-5L15 6.25c.409.312 1 .367 1-.383V.5c0-.25-.254-.5-.5-.5H10c-.497 0-.497.333 0 1l1 1.25z"
      opacity=".7"
    />
  </svg>
);

ExternalLink.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ExternalLink;
