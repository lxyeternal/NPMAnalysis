/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Register = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M15.618 11H.382A.382.382 0 0 1 0 10.618c0-.205.057-.408.167-.589L1.86 7.645a1 1 0 0 0 .184-.58V5.693A1.695 1.695 0 0 1 3.738 4h8.524c.935 0 1.693.758 1.693 1.692v1.374a1 1 0 0 0 .184.579l1.694 2.384c.11.18.167.384.167.59 0 .21-.17.381-.382.381zM7.5 5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h5a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-5z"
      opacity=".7"
    />
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M11 3v1H9V3H8a1 1 0 0 1-1-1V1a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1h-1zm3 13H2a2 2 0 0 1-2-2v-1.5a.5.5 0 0 1 .5-.5h5.25a.25.25 0 0 1 .25.25v.25a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5v-.25a.25.25 0 0 1 .25-.25h5.25a.5.5 0 0 1 .5.5V14a2 2 0 0 1-2 2z"
    />
    <rect
      className="cr-icon__details cr-icon__details-1"
      fill={detailsColor || detailsColor1}
      width="6"
      height="2"
      x="7"
      y="5"
      rx=".5"
    />
  </svg>
);

Register.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Register;
