/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const ArrowUp = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2,
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M12.502 7.001a.5.5 0 0 0 .372-.833l-4.69-4.975a.25.25 0 0 0-.364 0L3.13 6.168A.5.5 0 0 0 3.5 7h2a.5.5 0 0 1 .5.5V14a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1V7.501a.5.5 0 0 1 .5-.5h2.002z"
    />
  </svg>
);

ArrowUp.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default ArrowUp;
