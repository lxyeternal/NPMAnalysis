/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Power = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M9.293.309a.875.875 0 0 1 1.033-.227c.48.224.705.838.503 1.37l-1.887 4.98 3.31.775c.178.042.341.14.47.282.37.408.37 1.07.004 1.48L6.709 15.69a.875.875 0 0 1-1.034.227c-.48-.225-.705-.838-.503-1.37L7.06 9.57l-3.312-.776a.918.918 0 0 1-.47-.282 1.13 1.13 0 0 1-.004-1.48L9.293.309z"
    />
  </svg>
);

Power.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Power;
