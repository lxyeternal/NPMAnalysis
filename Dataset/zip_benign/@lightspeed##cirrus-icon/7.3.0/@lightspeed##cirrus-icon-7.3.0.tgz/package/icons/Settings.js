/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const Settings = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M12.058 2.82c.489.381.914.826 1.269 1.316l1.729-.077a.367.367 0 0 1 .332.219l.593 1.545a.369.369 0 0 1-.1.385l-1.337 1.099a6.538 6.538 0 0 1-.064 1.842l1.146 1.051c.101.093.14.268.083.396l-.622 1.396a.363.363 0 0 1-.35.202l-1.545-.15a6.539 6.539 0 0 1-1.328 1.283l.077 1.729a.369.369 0 0 1-.219.332l-1.545.593a.367.367 0 0 1-.385-.1l-1.099-1.337a6.539 6.539 0 0 1-1.846-.065L5.8 15.624a.367.367 0 0 1-.396.084l-1.396-.621a.363.363 0 0 1-.202-.351l.15-1.544a6.538 6.538 0 0 1-1.283-1.328l-1.729.077a.367.367 0 0 1-.332-.219l-.593-1.545a.369.369 0 0 1 .1-.385l1.337-1.099a6.538 6.538 0 0 1 .065-1.846L.376 5.801a.367.367 0 0 1-.085-.397l.622-1.396a.363.363 0 0 1 .35-.202l1.546.15a6.539 6.539 0 0 1 1.327-1.283L4.06.944a.369.369 0 0 1 .219-.332L5.823.02a.367.367 0 0 1 .385.1l1.099 1.337a6.539 6.539 0 0 1 1.843.064L10.2.375a.367.367 0 0 1 .396-.083l1.396.621a.362.362 0 0 1 .205.345l-.139 1.561zm-5.705 8.879A4.05 4.05 0 1 0 9.647 4.3a4.05 4.05 0 0 0-3.294 7.398z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M8 6l1.732 1v2L8 10 6.268 9V7z"
      opacity=".7"
    />
  </svg>
);

Settings.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default Settings;
