/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';

const DiscountCodes = ({
  color,
  baseColor,
  baseColor1,
  detailsColor,
  detailsColor1 = 'none',
  baseColor2,
  detailsColor2 = '#fff',
  ...rest
}) => (
  <svg {...rest} fill={color}>
    <path
      className="cr-icon__base cr-icon__base-1"
      fill={baseColor || baseColor1}
      d="M11.322 3.251l4.347 4.018a1 1 0 0 1 0 1.47l-4.347 4.01a1 1 0 0 1-.678.266h-2.61l2-10.03h.61a1 1 0 0 1 .678.266zm.72 4.753c0 .554.448 1.003 1 1.003.553 0 1-.45 1-1.003a1.001 1.001 0 1 0-2 0zM6.01 2.985l-2 10.03h-2a2 2 0 0 1-2-2v-6.03a2 2 0 0 1 2-2h4z"
    />
    <path
      className="cr-icon__base cr-icon__base-2"
      fill={baseColor || baseColor2}
      d="M6.478 15.21l3-14A1 1 0 1 0 7.522.79l-3 14a1 1 0 1 0 1.956.42z"
      opacity=".7"
    />
  </svg>
);

DiscountCodes.propTypes = {
  color: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor2: PropTypes.string,
};

export default DiscountCodes;
