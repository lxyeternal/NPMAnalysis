# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

<a name="7.3.0"></a>
# [7.3.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@7.2.1...@lightspeed/cirrus-icon@7.3.0) (2019-02-26)


### Features

* **Icon:** add diners club Icon ([#670](https://github.com/lightspeedretail/cirrus/issues/670)) ([68fe542](https://github.com/lightspeedretail/cirrus/commit/68fe542))





<a name="7.2.1"></a>
## [7.2.1](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@7.2.0...@lightspeed/cirrus-icon@7.2.1) (2018-10-30)


### Bug Fixes

* **Icon:** change layer composition for discover card icon ([c89925b](https://github.com/lightspeedretail/cirrus/commit/c89925b))





<a name="7.2.0"></a>
# [7.2.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@7.1.0...@lightspeed/cirrus-icon@7.2.0) (2018-10-29)


### Features

* **icon:** add clock-outline icon ([#501](https://github.com/lightspeedretail/cirrus/issues/501)) ([256ed57](https://github.com/lightspeedretail/cirrus/commit/256ed57))





<a name="7.1.0"></a>
# [7.1.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@7.0.0...@lightspeed/cirrus-icon@7.1.0) (2018-09-06)


### Features

* **icon:** change `apps`, add `apps-purchased` ([#486](https://github.com/lightspeedretail/cirrus/issues/486)) ([eb3ad5e](https://github.com/lightspeedretail/cirrus/commit/eb3ad5e))





<a name="7.0.0"></a>
# [7.0.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@6.0.0...@lightspeed/cirrus-icon@7.0.0) (2018-08-28)


* fix(Icon) - rework Sketch file to simplify icon generation (#480) ([48ee495](https://github.com/lightspeedretail/cirrus/commit/48ee495)), closes [#480](https://github.com/lightspeedretail/cirrus/issues/480) [#480](https://github.com/lightspeedretail/cirrus/issues/480)


### BREAKING CHANGES

* 





<a name="6.0.0"></a>
# [6.0.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@5.1.0...@lightspeed/cirrus-icon@6.0.0) (2018-08-03)


### Bug Fixes

* **Icon:** prevent error when invalid name ([#458](https://github.com/lightspeedretail/cirrus/issues/458)) ([f770a3e](https://github.com/lightspeedretail/cirrus/commit/f770a3e))


### Features

* Add className support to all components ([#452](https://github.com/lightspeedretail/cirrus/issues/452)) ([78f9bf7](https://github.com/lightspeedretail/cirrus/commit/78f9bf7))


### BREAKING CHANGES

* * Add className support to all components

* revert some "not-needed" changes





<a name="5.1.0"></a>
# [5.1.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@5.0.0...@lightspeed/cirrus-icon@5.1.0) (2018-05-29)


### Features

* **icon:** add credit card icons ([#434](https://github.com/lightspeedretail/cirrus/issues/434)) ([af44f2a](https://github.com/lightspeedretail/cirrus/commit/af44f2a))




<a name="5.0.0"></a>
# [5.0.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.9.3...@lightspeed/cirrus-icon@5.0.0) (2018-05-17)


* Update to react 16.3 (#410) ([203bc4b](https://github.com/lightspeedretail/cirrus/commit/203bc4b))


### Bug Fixes

* **icon:** remove babel stage1 transformation requirement ([#352](https://github.com/lightspeedretail/cirrus/issues/352)) ([9cd04cf](https://github.com/lightspeedretail/cirrus/commit/9cd04cf)), closes [#316](https://github.com/lightspeedretail/cirrus/issues/316)
* **Icon:** Remove propTypes check ([#425](https://github.com/lightspeedretail/cirrus/issues/425)) ([c56fd0f](https://github.com/lightspeedretail/cirrus/commit/c56fd0f))


### Features

* **icon:** Add fill utility classes ([#367](https://github.com/lightspeedretail/cirrus/issues/367)) ([e12c9c9](https://github.com/lightspeedretail/cirrus/commit/e12c9c9))
* **icon:** add icon for home ([#336](https://github.com/lightspeedretail/cirrus/issues/336)) ([1da5c52](https://github.com/lightspeedretail/cirrus/commit/1da5c52))
* **icon:** add unlink icon ([#394](https://github.com/lightspeedretail/cirrus/issues/394)) ([266f4a3](https://github.com/lightspeedretail/cirrus/commit/266f4a3))
* **icon:** add Up-down indicator for use in `<Dropdown>` ([#326](https://github.com/lightspeedretail/cirrus/issues/326)) ([3c2a7a3](https://github.com/lightspeedretail/cirrus/commit/3c2a7a3))
* **icons:** Big icon update ([#341](https://github.com/lightspeedretail/cirrus/issues/341)) ([2e7d1ea](https://github.com/lightspeedretail/cirrus/commit/2e7d1ea))


### BREAKING CHANGES

* * Update react

* Remove deprecated lifecycle methods from Modal & Checkbox

* Fix appElement warning in Modal test

* disable eslint sort order

* Remove react 15 dependecy

* Change peerdeps for Modal & Checkbox

* explicitly set semi to true in prettier config

* update template package.json




<a name="4.0.0"></a>
# [4.0.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.9.3...@lightspeed/cirrus-icon@4.0.0) (2018-04-30)


### Bug Fixes

* **icon:** remove babel stage1 transformation requirement ([#352](https://github.com/lightspeedretail/cirrus/issues/352)) ([9cd04cf](https://github.com/lightspeedretail/cirrus/commit/9cd04cf)), closes [#316](https://github.com/lightspeedretail/cirrus/issues/316)


### Features

* **icon:** Add fill utility classes ([#367](https://github.com/lightspeedretail/cirrus/issues/367)) ([e12c9c9](https://github.com/lightspeedretail/cirrus/commit/e12c9c9))
* **icon:** add icon for home ([#336](https://github.com/lightspeedretail/cirrus/issues/336)) ([1da5c52](https://github.com/lightspeedretail/cirrus/commit/1da5c52))
* **icon:** add unlink icon ([#394](https://github.com/lightspeedretail/cirrus/issues/394)) ([266f4a3](https://github.com/lightspeedretail/cirrus/commit/266f4a3))
* **icon:** add Up-down indicator for use in `<Dropdown>` ([#326](https://github.com/lightspeedretail/cirrus/issues/326)) ([3c2a7a3](https://github.com/lightspeedretail/cirrus/commit/3c2a7a3))
* **icons:** Big icon update ([#341](https://github.com/lightspeedretail/cirrus/issues/341)) ([2e7d1ea](https://github.com/lightspeedretail/cirrus/commit/2e7d1ea))


* Update to react 16.3 (#410) ([203bc4b](https://github.com/lightspeedretail/cirrus/commit/203bc4b))


### BREAKING CHANGES

* * Update react

* Remove deprecated lifecycle methods from Modal & Checkbox

* Fix appElement warning in Modal test

* disable eslint sort order

* Remove react 15 dependecy

* Change peerdeps for Modal & Checkbox

* explicitly set semi to true in prettier config

* update template package.json




<a name="3.15.0"></a>
# [3.15.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.9.3...@lightspeed/cirrus-icon@3.15.0) (2018-03-16)


### Bug Fixes

* **icon:** remove babel stage1 transformation requirement ([#352](https://github.com/lightspeedretail/cirrus/issues/352)) ([9cd04cf](https://github.com/lightspeedretail/cirrus/commit/9cd04cf)), closes [#316](https://github.com/lightspeedretail/cirrus/issues/316)


### Features

* **icon:** Add fill utility classes ([#367](https://github.com/lightspeedretail/cirrus/issues/367)) ([e12c9c9](https://github.com/lightspeedretail/cirrus/commit/e12c9c9))
* **icon:** add icon for home ([#336](https://github.com/lightspeedretail/cirrus/issues/336)) ([1da5c52](https://github.com/lightspeedretail/cirrus/commit/1da5c52))
* **icon:** add unlink icon ([#394](https://github.com/lightspeedretail/cirrus/issues/394)) ([266f4a3](https://github.com/lightspeedretail/cirrus/commit/266f4a3))
* **icon:** add Up-down indicator for use in `<Dropdown>` ([#326](https://github.com/lightspeedretail/cirrus/issues/326)) ([3c2a7a3](https://github.com/lightspeedretail/cirrus/commit/3c2a7a3))
* **icons:** Big icon update ([#341](https://github.com/lightspeedretail/cirrus/issues/341)) ([2e7d1ea](https://github.com/lightspeedretail/cirrus/commit/2e7d1ea))




<a name="3.14.0"></a>
# [3.14.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.9.3...@lightspeed/cirrus-icon@3.14.0) (2018-02-21)


### Bug Fixes

* **icon:** remove babel stage1 transformation requirement ([#352](https://github.com/lightspeedretail/cirrus/issues/352)) ([9cd04cf](https://github.com/lightspeedretail/cirrus/commit/9cd04cf)), closes [#316](https://github.com/lightspeedretail/cirrus/issues/316)


### Features

* **icon:** Add fill utility classes ([#367](https://github.com/lightspeedretail/cirrus/issues/367)) ([e12c9c9](https://github.com/lightspeedretail/cirrus/commit/e12c9c9))
* **icon:** add icon for home ([#336](https://github.com/lightspeedretail/cirrus/issues/336)) ([1da5c52](https://github.com/lightspeedretail/cirrus/commit/1da5c52))
* **icon:** add Up-down indicator for use in `<Dropdown>` ([#326](https://github.com/lightspeedretail/cirrus/issues/326)) ([3c2a7a3](https://github.com/lightspeedretail/cirrus/commit/3c2a7a3))
* **icons:** Big icon update ([#341](https://github.com/lightspeedretail/cirrus/issues/341)) ([2e7d1ea](https://github.com/lightspeedretail/cirrus/commit/2e7d1ea))




<a name="3.13.0"></a>
# [3.13.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.9.3...@lightspeed/cirrus-icon@3.13.0) (2018-02-09)


### Bug Fixes

* **icon:** remove babel stage1 transformation requirement ([#352](https://github.com/lightspeedretail/cirrus/issues/352)) ([9cd04cf](https://github.com/lightspeedretail/cirrus/commit/9cd04cf)), closes [#316](https://github.com/lightspeedretail/cirrus/issues/316)


### Features

* **icon:** add icon for home ([#336](https://github.com/lightspeedretail/cirrus/issues/336)) ([1da5c52](https://github.com/lightspeedretail/cirrus/commit/1da5c52))
* **icon:** add Up-down indicator for use in `<Dropdown>` ([#326](https://github.com/lightspeedretail/cirrus/issues/326)) ([3c2a7a3](https://github.com/lightspeedretail/cirrus/commit/3c2a7a3))
* **icons:** Big icon update ([#341](https://github.com/lightspeedretail/cirrus/issues/341)) ([2e7d1ea](https://github.com/lightspeedretail/cirrus/commit/2e7d1ea))




<a name="3.12.0"></a>
# [3.12.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.9.3...@lightspeed/cirrus-icon@3.12.0) (2018-02-01)


### Features

* **icon:** add icon for home ([#336](https://github.com/lightspeedretail/cirrus/issues/336)) ([1da5c52](https://github.com/lightspeedretail/cirrus/commit/1da5c52))
* **icon:** add Up-down indicator for use in `<Dropdown>` ([#326](https://github.com/lightspeedretail/cirrus/issues/326)) ([3c2a7a3](https://github.com/lightspeedretail/cirrus/commit/3c2a7a3))
* **icons:** Big icon update ([#341](https://github.com/lightspeedretail/cirrus/issues/341)) ([2e7d1ea](https://github.com/lightspeedretail/cirrus/commit/2e7d1ea))




<a name="3.11.0"></a>
# [3.11.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.9.3...@lightspeed/cirrus-icon@3.11.0) (2018-01-25)


### Features

* **icon:** add icon for home ([#336](https://github.com/lightspeedretail/cirrus/issues/336)) ([1da5c52](https://github.com/lightspeedretail/cirrus/commit/1da5c52))
* **icon:** add Up-down indicator for use in `<Dropdown>` ([#326](https://github.com/lightspeedretail/cirrus/issues/326)) ([3c2a7a3](https://github.com/lightspeedretail/cirrus/commit/3c2a7a3))




<a name="3.10.0"></a>
# [3.10.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.9.3...@lightspeed/cirrus-icon@3.10.0) (2018-01-18)


### Features

* **icon:** add Up-down indicator for use in `<Dropdown>` ([#326](https://github.com/lightspeedretail/cirrus/issues/326)) ([3c2a7a3](https://github.com/lightspeedretail/cirrus/commit/3c2a7a3))




<a name="3.9.3"></a>
## [3.9.3](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.9.2...@lightspeed/cirrus-icon@3.9.3) (2018-01-15)


### Bug Fixes

* **deps:** add react 16 as valid peerdependency ([#309](https://github.com/lightspeedretail/cirrus/issues/309)) ([cb84a1e](https://github.com/lightspeedretail/cirrus/commit/cb84a1e))




<a name="3.9.2"></a>
## [3.9.2](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.9.0...@lightspeed/cirrus-icon@3.9.2) (2018-01-08)




**Note:** Version bump only for package @lightspeed/cirrus-icon

<a name="3.9.1"></a>
## [3.9.1](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.9.0...@lightspeed/cirrus-icon@3.9.1) (2018-01-08)




**Note:** Version bump only for package @lightspeed/cirrus-icon

<a name="3.9.0"></a>
# [3.9.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.8.0...@lightspeed/cirrus-icon@3.9.0) (2017-12-22)


### Features

* **icon:** Icons update [#4](https://github.com/lightspeedretail/cirrus/issues/4) ([#312](https://github.com/lightspeedretail/cirrus/issues/312)) ([e2b764a](https://github.com/lightspeedretail/cirrus/commit/e2b764a))




<a name="3.8.0"></a>
# [3.8.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.7.0...@lightspeed/cirrus-icon@3.8.0) (2017-12-20)


### Features

* **icon:** add languages and power icons, fix mail icon and update cash icon ([#303](https://github.com/lightspeedretail/cirrus/issues/303)) ([a9ac109](https://github.com/lightspeedretail/cirrus/commit/a9ac109))




<a name="3.7.0"></a>
# [3.7.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.6.0...@lightspeed/cirrus-icon@3.7.0) (2017-12-14)


### Features

* add spinner component ([#295](https://github.com/lightspeedretail/cirrus/issues/295)) ([839f7e0](https://github.com/lightspeedretail/cirrus/commit/839f7e0))




<a name="3.6.0"></a>
# [3.6.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.5.0...@lightspeed/cirrus-icon@3.6.0) (2017-12-14)


### Features

* **icon:** add spinner icon & add missing groups with IDs for sprite sheet ([#292](https://github.com/lightspeedretail/cirrus/issues/292)) ([a2e8c58](https://github.com/lightspeedretail/cirrus/commit/a2e8c58))




<a name="3.5.0"></a>
# [3.5.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.4.0...@lightspeed/cirrus-icon@3.5.0) (2017-12-12)


### Features

* **button:** Add positioning support for childrens ([#284](https://github.com/lightspeedretail/cirrus/issues/284)) ([20f40ed](https://github.com/lightspeedretail/cirrus/commit/20f40ed))




<a name="3.4.0"></a>
# [3.4.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.3.1...@lightspeed/cirrus-icon@3.4.0) (2017-12-11)


### Features

* **Icon:** Added Domains, Categories, Navigation, Reviews and Product options icons ([#285](https://github.com/lightspeedretail/cirrus/issues/285)) ([150e179](https://github.com/lightspeedretail/cirrus/commit/150e179))




<a name="3.3.1"></a>
## [3.3.1](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.3.0...@lightspeed/cirrus-icon@3.3.1) (2017-12-05)




**Note:** Version bump only for package @lightspeed/cirrus-icon

<a name="3.3.0"></a>
# [3.3.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.2.1...@lightspeed/cirrus-icon@3.3.0) (2017-11-27)


### Features

* **Icon:** adjust small-chevron icons ([#263](https://github.com/lightspeedretail/cirrus/issues/263)) ([8271274](https://github.com/lightspeedretail/cirrus/commit/8271274))




<a name="3.2.1"></a>
## [3.2.1](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.2.0...@lightspeed/cirrus-icon@3.2.1) (2017-11-24)




**Note:** Version bump only for package @lightspeed/cirrus-icon

<a name="3.2.0"></a>
# [3.2.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.1.0...@lightspeed/cirrus-icon@3.2.0) (2017-11-21)


### Features

* **Icon:** Add icon customergroups ([#249](https://github.com/lightspeedretail/cirrus/issues/249)) ([41c5ebe](https://github.com/lightspeedretail/cirrus/commit/41c5ebe))




<a name="3.1.0"></a>
# [3.1.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@3.0.0...@lightspeed/cirrus-icon@3.1.0) (2017-11-17)


### Features

* **Icon:** Add quotes icon ([#246](https://github.com/lightspeedretail/cirrus/issues/246)) ([d042efa](https://github.com/lightspeedretail/cirrus/commit/d042efa))




<a name="3.0.0"></a>
# [3.0.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@2.2.0...@lightspeed/cirrus-icon@3.0.0) (2017-11-09)


### Chores

* use css modules instead of .json for styles ([#164](https://github.com/lightspeedretail/cirrus/issues/164)) ([a4d6109](https://github.com/lightspeedretail/cirrus/commit/a4d6109))


### Features

* **icon:** replace hamburger icon ([#229](https://github.com/lightspeedretail/cirrus/issues/229)) ([0dc4c1c](https://github.com/lightspeedretail/cirrus/commit/0dc4c1c))


### BREAKING CHANGES

* * cleanup package.json & remove build script

* use CSS Modules

* import tokens CSS form node_modules

* update CSS loaders

* make storybook happy

* move tokens to peerDependencies

* Update packges yarn.lock

* make sure we use tokens from the file system

* remove alias, not needed

* rebuild tokens when files change

* remove unused import

* remove duplicate dev packages

* make sure yarn install

* update README(s)

* fix lockfile after rebase

* fix package.json after rebase

* Update Styles Getting Started section

* Add tokens to peer deps in README install guide




<a name="2.2.0"></a>
# [2.2.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@2.1.0...@lightspeed/cirrus-icon@2.2.0) (2017-10-30)


### Features

* **icon:** add info icon, further fix run-svgo, update README ([#215](https://github.com/lightspeedretail/cirrus/issues/215)) ([ea87120](https://github.com/lightspeedretail/cirrus/commit/ea87120))




<a name="2.1.0"></a>
# [2.1.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@2.0.0...@lightspeed/cirrus-icon@2.1.0) (2017-10-26)


### Features

* **icon:** add cash icon + fix run-svgo script for new svg structure ([#212](https://github.com/lightspeedretail/cirrus/issues/212)) ([08f6856](https://github.com/lightspeedretail/cirrus/commit/08f6856))




<a name="2.0.0"></a>
# [2.0.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@1.1.1...@lightspeed/cirrus-icon@2.0.0) (2017-10-26)


### Features

* **icon:** rename tickets icon to support-tickets ([#211](https://github.com/lightspeedretail/cirrus/issues/211)) ([3be4b0f](https://github.com/lightspeedretail/cirrus/commit/3be4b0f))


### BREAKING CHANGES

* **icon:** * Renamed tickets icon

* Retry of icon




<a name="1.1.1"></a>
## [1.1.1](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@1.1.0...@lightspeed/cirrus-icon@1.1.1) (2017-10-25)




**Note:** Version bump only for package @lightspeed/cirrus-icon

<a name="1.1.0"></a>
# [1.1.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@1.0.1...@lightspeed/cirrus-icon@1.1.0) (2017-10-16)


### Features

* **icon:** add star and eye icons ([#192](https://github.com/lightspeedretail/cirrus/issues/192)) ([482edca](https://github.com/lightspeedretail/cirrus/commit/482edca))




<a name="1.0.1"></a>
## [1.0.1](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@1.0.0...@lightspeed/cirrus-icon@1.0.1) (2017-10-10)




**Note:** Version bump only for package @lightspeed/cirrus-icon

<a name="1.0.0"></a>
# [1.0.0](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@0.2.2...@lightspeed/cirrus-icon@1.0.0) (2017-10-10)


### Features

* **icon:** rewrite icon api, update raw svgs code, add svg sprite ([#169](https://github.com/lightspeedretail/cirrus/issues/169)) ([208bafd](https://github.com/lightspeedretail/cirrus/commit/208bafd))




<a name="0.2.2"></a>
## [0.2.2](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@0.2.1...@lightspeed/cirrus-icon@0.2.2) (2017-10-03)


### Bug Fixes

* **icon:** add clipboard icon ([2716cee](https://github.com/lightspeedretail/cirrus/commit/2716cee))




<a name="0.2.1"></a>
## [0.2.1](https://github.com/lightspeedretail/cirrus/compare/@lightspeed/cirrus-icon@0.2.0...@lightspeed/cirrus-icon@0.2.1) (2017-10-02)


### Bug Fixes

* **icon:** add icons from design-icon repo ([#167](https://github.com/lightspeedretail/cirrus/issues/167)) ([9f9d271](https://github.com/lightspeedretail/cirrus/commit/9f9d271))
* **icon:** update ecom icons, fix svg permissions ([#168](https://github.com/lightspeedretail/cirrus/issues/168)) ([4778b74](https://github.com/lightspeedretail/cirrus/commit/4778b74))




<a name="0.2.0"></a>
# 0.2.0 (2017-09-25)


### Features

* add icon component ([#157](https://github.com/lightspeedretail/cirrus/issues/157)) ([55c0b98](https://github.com/lightspeedretail/cirrus/commit/55c0b98))
