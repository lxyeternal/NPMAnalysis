import React from 'react';
import PropTypes from 'prop-types';
import get from 'lodash/get';
import camelCase from 'lodash/camelCase';
import upperFirst from 'lodash/upperFirst';
import cn from 'classnames';
import { colors } from '@lightspeed/cirrus-tokens/src/colors';
import { fontSizeAliases } from '@lightspeed/cirrus-tokens/src/typography';
import icons from './icons/';
import styles from './Icon.scss';

const baseClass = 'cr-icon';

const Icon = ({
  name,
  size = '1rem',
  color,
  className,
  baseColor,
  baseColor1,
  baseColor2,
  detailsColor,
  detailsColor1,
  detailsColor2,
  ...rest
}) => {
  const classNames = cn(styles[baseClass], `${styles[baseClass]}-${name}`, className);
  const iconSize = get(fontSizeAliases, size, size);
  const Component = name && icons[upperFirst(camelCase(name))];

  return Component ? (
    <Component
      {...rest}
      className={classNames}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 16 16"
      style={{ width: iconSize, height: iconSize }}
      color={get(colors, color, color)}
      baseColor={get(colors, baseColor, baseColor)}
      baseColor1={get(colors, baseColor1, baseColor1)}
      baseColor2={get(colors, baseColor2, baseColor2)}
      detailsColor={get(colors, detailsColor, detailsColor)}
      detailsColor1={get(colors, detailsColor1, detailsColor1)}
      detailsColor2={get(colors, detailsColor2, detailsColor2)}
    />
  ) : null;
};

Icon.propTypes = {
  name: PropTypes.string,
  size: PropTypes.string,
  color: PropTypes.string,
  className: PropTypes.string,
  baseColor: PropTypes.string,
  baseColor1: PropTypes.string,
  baseColor2: PropTypes.string,
  detailsColor: PropTypes.string,
  detailsColor1: PropTypes.string,
  detailsColor2: PropTypes.string,
};

Icon.cirrusName = 'Icon';

export default Icon;
