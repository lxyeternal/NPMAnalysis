#### cy-mathjs
更精准的加减乘除运算，解决js因二进制问题引起的运算差异
#### install
npm/cnpm install 或者 yarn add cy-mathjs
#### property api
property | description
---------| -----------
Add      | 加法运算
AddGroup | 多个数相加
Sub      | 减法运算
SubGroup | 多个数相减
Mul      | 乘法运算
MulGroup | 多个数相乘
Div      | 除法运算
DivGroup | 多个数相除
Floor    | 保留小数位数

