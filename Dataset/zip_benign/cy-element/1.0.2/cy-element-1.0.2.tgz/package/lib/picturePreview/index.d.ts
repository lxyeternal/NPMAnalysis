/// <reference types="react" />
import './index.less';
interface IProps {
    visible: boolean;
    data?: Array<string | {}>;
    close: (e: any) => void;
}
declare const PickurePreview: ({ visible, data, close }: IProps) => JSX.Element;
export default PickurePreview;
