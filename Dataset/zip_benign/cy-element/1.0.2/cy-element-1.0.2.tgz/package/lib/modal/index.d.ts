import React, { SFC } from 'react';
import './index.less';
declare type IProps = {
    title?: string;
    onSure?: () => React.FormEventHandler<any>;
    onCancel?: () => React.FormEventHandler<any>;
    sureText?: string;
    cancelText?: string;
    closeAble?: true;
    children?: React.ReactChild;
    footer?: React.ReactHTML;
    style?: React.CSSProperties;
    className?: string;
    isCenter?: boolean;
    sureButtonProps?: {
        loading?: boolean;
        disabled?: boolean;
    };
};
declare const Modal: SFC<IProps>;
export default Modal;
