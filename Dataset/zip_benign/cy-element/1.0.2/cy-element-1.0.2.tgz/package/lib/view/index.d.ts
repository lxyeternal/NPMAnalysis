import React from 'react';
import './index.less';
/**
 * base on css3 flex layout
 * @author zou yong hong
 * @created at 2019-05-27
 */
interface IProps {
    className?: string;
    justContent?: string;
    alignItems?: string;
    line?: string;
    around?: string;
    column?: boolean | undefined;
    row?: boolean | undefined;
    wrap?: boolean;
    flex?: boolean;
    width?: number | string;
    height?: number | string;
    style?: React.CSSProperties;
    children?: any;
    onClick?(e: React.MouseEvent): void;
    onMouseEnter?(e: React.MouseEvent): void;
    onMouseLeave?(e: React.MouseEvent): void;
    onScroll?(e: React.UIEvent): void;
}
declare const View: React.ForwardRefExoticComponent<IProps & React.RefAttributes<unknown>>;
export default View;
