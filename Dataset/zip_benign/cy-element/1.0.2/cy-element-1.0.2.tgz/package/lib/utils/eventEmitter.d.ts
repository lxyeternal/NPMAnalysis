/**
 * 事件发布订阅工具类
 * @author zou yong hong
 * created at 2019-05-27
 */
declare class EventEmitter {
    private EVENTS;
    private static instance;
    constructor();
    static getInstance(): EventEmitter;
    emit(type: string, ...args: any): void;
    listenerEmit(type: string, fn: void): void;
    removeListeners(type: string, fn: void): void;
}
declare const _default: EventEmitter;
export default _default;
