/**
 * 更安全和精准的运算
 * @author zouyonghong
 * @since 19/12/19
 */
declare class MatchJs {
    private static instance;
    static getInstance(): MatchJs;
    Add(arg1: number, arg2: number): number;
    AddGroup(...numbers: number[]): number;
    Sub(arg1: number, arg2: number): number;
    SubGroup(...numbers: number[]): number;
    Mul(arg1: number, arg2: number): number;
    MulGroup(...numbers: number[]): number;
    Div(arg1: number, arg2: number): number;
    DivGroup(...numbers: number[]): number;
    Floor(value: number | string, precision: number): number;
}
declare const _default: MatchJs;
export default _default;
