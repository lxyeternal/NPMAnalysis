import React, { useImperativeHandle, forwardRef, useRef } from 'react'
import './index.less'

/**
 * base on css3 flex layout
 * @author zou yong hong
 * @created at 2019-05-27
 */

interface IProps{
    className?: string,
    justContent?: string,
    alignItems?: string,
    line?: string, 
    around?: string,
    column?: boolean | undefined,
    row?: boolean | undefined,
    wrap?: boolean,
    flex?: boolean,
    width?: number | string,
    height?: number | string,
    style?: React.CSSProperties,
    children?: any,
    onClick?(e: React.MouseEvent): void,
    onMouseEnter?(e: React.MouseEvent): void,
    onMouseLeave?(e: React.MouseEvent): void,
    onScroll?(e: React.UIEvent): void
}

const View = forwardRef((props:IProps, ref:any):any => {
    const{
        className, 
        justContent,
        alignItems,
        line,
        around,
        column, 
        row, 
        wrap,
        flex,
        width,
        height,
        style = {}, 
        children, 
        ...rest
    } = props

    let classNames:Array<string | undefined | boolean> = [
        'bonc-box',
        column && 'bonc-column',
        around && 'bonc-space-arund',
        row && 'bonc-row',
        flex && 'bonc-flex',
        wrap && 'bonc-wrap',
        justContent === 'start' && 'bonc-j-start',
        justContent === 'center' && 'bonc-j-center',
        justContent === 'end' && 'bonc-j-end',
        alignItems === 'top' && 'bonc-a-top',
        alignItems === 'middle' && 'bonc-a-middle',
        alignItems === 'bottom' && 'bonc-a-bottom',
        line === 'top' && 'bonc-ty-line',
        line === 'bottom' && 'bonc-by-line',
        line === 'left' && 'bonc-xl-line',
        line === 'right' && 'bonc-xr-line',
        className
    ]
    classNames = classNames.filter(item => item)
    let _class = classNames.join(' ')
    const domRef = useRef<HTMLDivElement>(null)
    useImperativeHandle(ref, () => domRef.current)
    return <div ref={domRef} className={_class} style={{...style, width, height}} {...rest}>
        {children}
    </div>
})

export default View