import React, { useState, SFC } from 'react'
import View from '../view'
import './index.less'

type IProps = {
    title?: string,
    onSure?: () => React.FormEventHandler<any>,
    onCancel?: () => React.FormEventHandler<any>,
    sureText?: string,
    cancelText?: string,
    closeAble?: true, 
    children?: React.ReactChild,
    footer?: React.ReactHTML,
    style?: React.CSSProperties,
    className?: string,
    isCenter?: boolean,
    sureButtonProps?: {
        loading?: boolean,
        disabled?: boolean
    }
}
const Modal:SFC<IProps> = props => {
    const { title } = props
    return<View className='bonc-modal-wrapper' alignItems='middle' column>
        <View className='bonc-modal-content' column>
            <View className='bonc-modal-title' row alignItems='middle'>
                <View flex className='bonc-modal-title-txt'>{title}</View>
                <View className='bonc-modal-close'>X</View>
            </View>
            <View className='bonc-modal-body'>

            </View>
            <View className='bonc-modal-footer' justContent='end'>
                <button className='bonc-button'>取消</button>
                <button style={{marginLeft: 10}} className='bonc-button'>确定</button>
            </View>
        </View>
    </View>
}

export default Modal