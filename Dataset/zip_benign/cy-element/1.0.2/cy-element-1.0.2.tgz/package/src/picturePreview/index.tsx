import React, { useState, useEffect, useCallback, useRef } from 'react'
import View from '../view'
import './index.less'

/**
 * 根据屏幕尺寸查看图片大图
 * @author zou yong hong
 * created at 2019-05-28
 */
let throttle:boolean = true
let hasCallFun: () => void | null
interface IProps{
    visible: boolean,
    data?: Array<string | {}>,
    close: (e:any) => void
}
const PickurePreview = ({ visible = false, data, close }:IProps) => {
    const [loadedImg, setLoadedImg] = useState<any>([])
    const target = useRef(0)
    const imgScroll:any = useRef(null)
    //获取窗口宽高
    const getWinSize = () => {
        let de = document.documentElement,
			db = document.body,
			width = de.clientWidth == 0 ?  db.clientWidth : de.clientWidth,
			height = de.clientHeight == 0 ?  db.clientHeight : de.clientHeight
		return { width, height }
    }
    const winSize:any = getWinSize()
    //当弹窗显示时渲染视图
    useEffect(() => {
        if(!visible) return
        let bakImgs = JSON.parse(JSON.stringify(data))
        loadImg(bakImgs, [], (imgs:any[]) => {
            let _imgStore = setImgSize(imgs, winSize)
            if(hasCallFun) window.removeEventListener('resize', hasCallFun, false)
            hasCallFun = ():void => {
                windowResizeHandle(_imgStore)
            }
            window.addEventListener('resize', hasCallFun, false)
            setLoadedImg(_imgStore)
        })
    }, [visible])
    const windowResizeHandle = useCallback((imgs:Array<any>):boolean | void => {
        if(!throttle || !imgs.length) return false
        throttle = false
        setTimeout(() => {
            clearTimeout()
            throttle = true
            const winSize = getWinSize()
            let _imgStore = setImgSize(imgs, winSize)
            imgScroll.current.style.transition = 'none'
            imgScroll.current.style.width = `${imgs.length * winSize.width}px`
            imgScroll.current.style.transform = `translate3d(${-target.current * winSize.width}px, 0, 0)`
            setLoadedImg(_imgStore)
        }, 50)
    }, [])
    //生成图片视图
    const renderImgView = ():ReactDOM.Renderer => {
        return loadedImg.map((item:any, idx:number) => (
            <View key={idx} 
                className='img-panner' 
                row 
                alignItems='middle' 
                justContent='center'>
                <View className='header' alignItems='middle' justContent='center'>
                    {item.title?`${item.title}/${loadedImg.length}`:`${idx + 1}/${loadedImg.length}`}
                </View>
                <img src={item.url} width={item.width} height={item.height} />
            </View>
        ))
    }
    //递归加载图片
    const loadImg = (imgs:Array<any>, loadImgs:Array<any>, callback:($imgs:Array<any>) => void) => {
        if(imgs.length === 0)
            return callback && callback(loadImgs)
        let data = imgs[0]
        data = typeof data === 'string' ? { url: data } : data
        let img = new Image, timer:any = null
        img.src = data.url
        if(img.complete){
            data.width = img.width
            data.height = img.height
            timer = setInterval(() => {
                if(img.width !== 0 && img.height !== 0){
                    clearInterval(timer)
                    loadImgs.push(data)
                    imgs.shift()
                    loadImg(imgs, loadImgs, callback)
                }
            }, 40)  
            return
        }
        img.onload = e => {
            data.width = img.width
            data.height = img.height
            loadImgs.push(data)
            imgs.shift()
            return loadImg(imgs, loadImgs, callback)
        }
    }
    //设置图片尺寸
    const setImgSize = (imgs:Array<any>, winSize:any):any[] => {
        return imgs.map(img => {                                                   
            if(winSize.width / winSize.height >= img.width / img.height){
                img.width = winSize.height * img.width / img.height
                img.height = winSize.height
            }else{
                img.height = winSize.width * img.height / img.width
                img.width = winSize.width
            }
            return img
        })
    }
    //图片切换
    const imgHandleChange = (type:string, e:any) => {
        e = e ? e : window.event
        e.stopPropagation()
        if(loadedImg.length <= 1) return
        const winSize = getWinSize()
        if(type == 'next'){
            if(target.current < loadedImg.length - 1){
                target.current += 1
            }else{
                target.current = 0
            }
        }else{
            if(target.current > 0){
                target.current -= 1
            }else{
                target.current = loadedImg.length - 1
            }
        }
        imgScroll.current.style.transition = 'transform .22s ease-in-out'
        imgScroll.current.style.transform = `translate3d(${-target.current * winSize.width}px, 0, 0)`
    }
    const handleClose = (e:any) => {
        close && close({visible: false, data: []})
        imgScroll.current.style.transform = 'translate3d(0, 0, 0)'
        target.current = 0
        setLoadedImg([])
    }

    return <View 
        className='bonc-picture-wrapper'
        column
        style={{display: visible ? '' : 'none'}}
        onClick={handleClose}>
        <View flex className='content' style={{display: loadedImg.length ? '' : 'none'}}>
            <View className='img-scroll' 
                ref={imgScroll} row 
                width={loadedImg.length * winSize.width}>
                {renderImgView()}
            </View>
            <View onClick={e => imgHandleChange('prev', e)} className='prev' alignItems='middle' justContent='center'><i className='icon-prev'/></View>
            <View onClick={e => imgHandleChange('next', e)} className='next' alignItems='middle' justContent='center'><i className='icon-next'/></View>
        </View>
        <View className='picture-loading' column 
            alignItems='middle' 
            justContent='center'
            style={{display: !loadedImg.length ? '' : 'none'}}>
            <View className='loading-content'>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </View>
            <View className='loading-txt'>正在加载图片，请稍后</View>
        </View>
    </View>
}

export default PickurePreview