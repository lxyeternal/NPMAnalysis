/**
 * 更安全和精准的运算
 * @author zouyonghong
 * @since 19/12/19
 */

class MatchJs{
    private static instance: MatchJs
    static getInstance(): MatchJs{
        if(!this.instance) this.instance = new MatchJs
        return this.instance
    }
    public Add(arg1: number, arg2: number): number {
        let r1, r2, m, c;
        if(arg1 == null)
            arg1 = 0
        if(arg2 == null)
            arg2 = 0
        try {
            r1 = arg1.toString().split(".")[1].length
        }
        catch (e) {
            r1 = 0
        }
        try {
            r2 = arg2.toString().split(".")[1].length
        }
        catch (e) {
            r2 = 0
        }
        c = Math.abs(r1 - r2)
        m = Math.pow(10, Math.max(r1, r2))
        if (c > 0) {
            let cm = Math.pow(10, c)
            if (r1 > r2) {
                arg1 = Number(arg1.toString().replace(".", ""))
                arg2 = Number(arg2.toString().replace(".", "")) * cm
            } else {
                arg1 = Number(arg1.toString().replace(".", "")) * cm
                arg2 = Number(arg2.toString().replace(".", ""))
            }
        } else {
            arg1 = Number(arg1.toString().replace(".", ""))
            arg2 = Number(arg2.toString().replace(".", ""))
        }
        return (arg1 + arg2) / m
    }
    public AddGroup(...numbers: number[]): number
    public AddGroup(): number{
        if(arguments.length == 0)
            return 0
        let result = 0
        for(let i in arguments){
            result = this.Add(result,arguments[i])
        }
        return result
    }
    public Sub(arg1: number, arg2: number): number {
        let r1, r2, m, n;
        if(arg1 == null)
            arg1 = 0
        if(arg2 == null)
            arg2 = 0
        try {
            r1 = arg1.toString().split(".")[1].length
        }
        catch (e) {
            r1 = 0
        }
        try {
            r2 = arg2.toString().split(".")[1].length
        }
        catch (e) {
            r2 = 0
        }
        m = Math.pow(10, Math.max(r1, r2))
        n = (r1 >= r2) ? r1 : r2
        return ((this.Mul(arg1,m) - this.Mul(arg2,m)) / m)
    }
    public SubGroup(...numbers: number[]): number
    public SubGroup(): number{
        if(arguments.length == 0)
            return 0
        if(arguments.length == 1)
            return arguments[0]
        let result = arguments[0]
        for(let i = 1;i<arguments.length;i++){
            result = this.Sub(result,arguments[i])
        }
        return result
    }
    public Mul(arg1: number, arg2: number): number {
        let m = 0, s1 = arg1.toString(), s2 = arg2.toString()
        try {
            m += s1.split(".")[1].length
        }
        catch (e) {
        }
        try {
            m += s2.split(".")[1].length
        }
        catch (e) {}
        return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m)
    }
    public MulGroup(...numbers: number[]): number
    public MulGroup(): number{
        if(arguments.length == 0)
            return 0
        let result = 1
        for(let i in arguments){
            result = this.Mul(result,arguments[i])
        }
        return result
    }
    public Div(arg1: number, arg2: number): number {
        let t1 = 0, t2 = 0, r1, r2;
        try {
            t1 = arg1.toString().split(".")[1].length
        }
        catch (e) {
        }
        try {
            t2 = arg2.toString().split(".")[1].length
        }
        catch (e) {}
        r1 = Number(arg1.toString().replace(".", ""))
        r2 = Number(arg2.toString().replace(".", ""))
        return this.Mul((r1 / r2),Math.pow(10, t2 - t1))
    }
    public DivGroup(...numbers: number[]): number
    public DivGroup(): number{
        if(arguments.length == 0)
            return 0
        if(arguments.length == 1)
            return arguments[0]
        let result = arguments[0]
        for(let i = 1;i<arguments.length;i++){
            result = this.Div(result,arguments[i])
        }
        return result
    }
    public Floor(value: number | string, precision: number): number{
        if(!precision)
            precision = 0
        if(isNaN(precision))
            return 0.00
        if(precision < 0)
            return 0.00
        value = Number(value)
        let tmp = Math.pow(10,precision)
        value = this.Mul(value,tmp)
        value = Math.floor(value)
        value = this.Div(value,tmp)
        return value
    }
}
export default MatchJs.getInstance()