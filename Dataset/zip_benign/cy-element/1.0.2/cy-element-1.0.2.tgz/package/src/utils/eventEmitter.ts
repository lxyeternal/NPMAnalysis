/**
 * 事件发布订阅工具类
 * @author zou yong hong
 * created at 2019-05-27
 */
class EventEmitter{
    private EVENTS:any
    private static instance:EventEmitter
    constructor(){
        this.EVENTS = new Map()
    }
    static getInstance():EventEmitter{
        if(!this.instance){
            this.instance = new EventEmitter()
        }
        return this.instance
    }
    //发布事件
    emit(type:string, ...args: any){
        const handle = this.EVENTS.get(type)
        if(Array.isArray(handle)){
            for(let fn of handle){
                if(args.length){
                    fn && fn.apply(this, args)
                }else{
                    fn && fn.call(this)
                }
            }
        }else{
            if(args.length){
                handle && handle.apply(this, args)
            }else{
                handle && handle.call(this)
            }
        }
    }
    //订阅事件
    listenerEmit(type:string, fn:void){
        const handle = this.EVENTS.get(type)
        if(handle) this.removeListeners(type, fn)
        if(Array.isArray(handle)){
            handle.push(fn)
        }else if(typeof handle === 'function'){
            this.EVENTS.set(type, [handle, fn])
        }else{
            this.EVENTS.set(type, fn)
        }
    }
    //移除订阅
    removeListeners(type:string, fn:void){
        if(!this.EVENTS.has(type)) return
        let handle:void | Array<void> = this.EVENTS.get(type)
        if(typeof handle === 'function'){
            this.EVENTS.delete(type)
        }else if(Array.isArray(handle)){
            handle = handle.filter(func => func !== fn)
        }
    }
}

export default EventEmitter.getInstance()