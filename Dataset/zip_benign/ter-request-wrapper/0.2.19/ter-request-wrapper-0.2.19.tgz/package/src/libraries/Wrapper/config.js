const React = require('react');

const config = (config) => (Request) => {
  return class CustomRequest extends React.Component {
    render() {
      return (
        <Request {...this.props} {...config}>
          {this.props.children}
        </Request>
      );
    }
  };
}

module.exports = config;