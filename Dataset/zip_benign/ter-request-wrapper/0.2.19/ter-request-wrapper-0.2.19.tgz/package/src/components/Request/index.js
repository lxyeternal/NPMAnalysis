const React = require('react');
const PropTypes = require('prop-types');

class Request extends React.Component {
  constructor(props, context) {
    super(props, context);
    this.state = {
      data: false,
      loading: false,
      loaded: false,
      error: false,
    }
  }

  async componentDidMount() {
    if (this.props.url) {
      try {
        this.setState({loading: true});
        if (this.props.onRequestStarted) this.props.onRequestStarted();

        const result = await fetch(this.props.url, {
          method: this.props.method || 'GET',
        });
        let data = await result.json();

        if (this.props.onDataUpdate) {
          data = this.props.onDataUpdate(data, this.state.data);
        }

        this.setState({
          data,
          loading: false,
          loaded: true,
        });

        if (this.props.onRequestCompleted) this.props.onRequestCompleted(data);
      }
      catch (error) {
        this.setState({
          loading: false,
          loaded: true,
          error,
        });
        if (this.props.onRequestError) {
          this.props.onRequestError(error);
        }
      }
    }
  }

  render() {
    return this.props.children(this.state);
  }
}

module.exports = Request;
Request.propTypes = {
  url: PropTypes.string,
  method: PropTypes.string,

  onRequestError: PropTypes.func,
  onRequestCompleted: PropTypes.func,
  onRequestStarted: PropTypes.func,
  onDataUpdate: PropTypes.func,
}