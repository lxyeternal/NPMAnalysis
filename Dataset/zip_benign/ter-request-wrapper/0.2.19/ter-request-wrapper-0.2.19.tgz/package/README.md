# ThreeEyeRaven91's RequestWrapper component for HTTP Request

## Installation

```
npm install ter-request-wrapper --save

# or

yarn add ter-request-wrapper
```

## How to use
### As Headless Component

```
import { Request } from 'ter-request-wrapper';

<Request url={someUrl}>
  {(props) => {
    return <Something />
  }}
</Request>
```

#### Params

| Params             | Type                   | Default  | Description                                                       |
|--------------------|------------------------|----------|-------------------------------------------------------------------|
| url                | String                 |          | URL of data                                                       |
| method             | String                 | GET      | Method of request                                                 |
| onRequestStarted   | Func                   |          | Call when request started                                         |
| onRequestCompleted | Func({rawData})        |          | Call when request finished                                        |
| onRequestError     | Func(error)           |          | Call when request error                                           |
| onDataUpdate       | Func(newData, oldData) |          | Provide the way to pre-process data before update to current data |

#### Children props

| Params  | Type            | Default | Description                              |
|---------|-----------------|---------|------------------------------------------|
| data    | object or array | false   | Data return after query and onDataUpdate |
| rawData | object or array | false   | Data return after query                  |
| loading | boolean         | false   | query is running or not                  |
| loaded  | boolean         | false   | true if query already performed once     |
| error   | object          | false   | return error of query                    | 

## Best Practice
### API Pre-defined

By using `config` function, you can predefine for all of your API and shortened source code, provide meaningful request component.

```
import {Request, config} from 'ter-request-wrapper';

export const RequestUser = config({
  url: 'http://example.com/api/user',
  method: 'GET',
})(Request);

# in component file

<RequestUser params={{ userId: this.state.userId }}>
  {({data}) => {
    // return somthing
  }}
</RequestUser>

```

## Roadmap

| Version | Description                                | Status      |
|---------|--------------------------------------------|-------------|
| 0.1.x   | Using render props for calling GET request | Done        |
| 0.2.x   | Apply with other method and params         | In Progress |
| 0.3.x   | Handle error, auto retry, polling          | To do       |
| 0.4.x   | Caching, nonce                             | To do       |
| 0.5.x   | Higher-Order Component                     | In Progress |
| 0.6.x   | Compose multiple request                   | To do       |
| 0.7.x   | Pre-defined API                            | To do       |
| 1.0.0   | Official release                           | To do       |
| 1.1.x   | Generate API from swagger                  | In Progress |