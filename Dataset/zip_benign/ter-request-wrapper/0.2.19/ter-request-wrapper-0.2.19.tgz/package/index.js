const Request = require('./src/components/Request');
const config = require('./src/libraries/Wrapper/config');

module.exports = {
  Request,
  config,
};