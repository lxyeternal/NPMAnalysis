# Operaciones matematicas

Modulo para realizar operaciones matematicas simples

## instalación

```
npm install npm-project-1a-math
```

# Uso

```
// importar el modulo
const m = require('.')

// Suma
console.log(m.suma(1, 2)) => 3

// Resta
console.log(m.resta(1, 12))  => 13

// Multiplicacion
console.log(m.multiplicacion(1, 5))  => 5

// Division
console.log(m.division(1, 2)) => 0.5
```