'use strict';

var _parseDates = require('./parseDates');

var _parseDates2 = _interopRequireDefault(_parseDates);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

describe('parseDates', function () {
	it('should parse dates correctly', function () {
		var object = {
			date: '2016-12-13T22:56:48.417Z',

			dates: ['2016-08-27T03:49:00Z', '2016-08-27T03:49:00.1Z', '2016-08-27T03:49:00.123Z', '2016-08-27T03:49:00-03', '2016-08-27T03:49:00+03', '2016-08-27T03:49:00+03:00', '2016-08-27T03:49:00+0300', '2016-08-27T21:12:24.506+03', '2016-08-27T21:12:24.506-03', '2016-12-13T22:56:48.417z'],

			non_dates: ['2011', '2011-01', '2011-01-01',

			// No seconds
			'2011-01-01T03:49Z', '2016-08-27T03:49Z',

			// Invalid month
			'2011-15-30T03:49:00Z',

			// Invalid day
			'2011-12-32T03:49:00Z', '2016-08-27T03', '2016-08-27T03Z', '2016-08-27T03:49', '2016-08-27T03:49:00', '2016-08-27T03:49:00.1', '2016-08-27T03:49:00.123', '2016-08-27 03:49:00+03', '2016-08-27 03:49:00+03:00', '2016-08-27 03:49:00+0300', '2016-08-27 21:12:24.506+03', '2016-08-27 21:12:24.506-03', '2016-12-13T22:56:48.417']
		};

		(0, _parseDates2.default)(object);

		expect(object.date).to.be.an.instanceof(Date);

		for (var _iterator = object.dates, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
			var _ref;

			if (_isArray) {
				if (_i >= _iterator.length) break;
				_ref = _iterator[_i++];
			} else {
				_i = _iterator.next();
				if (_i.done) break;
				_ref = _i.value;
			}

			var date = _ref;

			expect(date).to.be.an.instanceof(Date);
		}

		for (var _iterator2 = object.non_dates, _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
			var _ref2;

			if (_isArray2) {
				if (_i2 >= _iterator2.length) break;
				_ref2 = _iterator2[_i2++];
			} else {
				_i2 = _iterator2.next();
				if (_i2.done) break;
				_ref2 = _i2.value;
			}

			var non_date = _ref2;

			expect(non_date).to.be.a('string');
		}
	});
});
//# sourceMappingURL=parseDates.test.js.map