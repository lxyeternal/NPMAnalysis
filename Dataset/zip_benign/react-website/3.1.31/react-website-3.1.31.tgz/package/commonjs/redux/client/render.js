'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.default = render;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _location = require('../../location');

var _router = require('../../router');

var _client = require('../../router/client');

var _flags = require('../../client/flags');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Renders the current page React element inside the `to` DOM element.
//
// Returns a `Promise` resolving to `{ store, component }`,
// where `component` is the rendered React component
// and `store` is the Redux store.
//
function render(_ref) {
	var store = _ref.store;

	return (0, _router.matchRoutes)(store).then(function (renderArgs) {
		// The first pass of initial client-side render
		// was to render the markup which matches server-side one.
		// The second pass will be to render after resolving `getData`.
		if ((0, _flags.isServerSidePreloaded)()) {
			window._react_website_initial_prerender = false;
			window._react_website_skip_preload = false;
		}

		// `routes` are used when comparing `instantBack` chain items
		// for resetting `instantBack` chain when the same route is encountered twice.
		window._react_website_route_components = renderArgs.routeIndices;

		return {
			element: (0, _client.createRouterElement)(renderArgs, store),
			containerProps: { store: store },
			store: store
		};
	});
}
//# sourceMappingURL=render.js.map