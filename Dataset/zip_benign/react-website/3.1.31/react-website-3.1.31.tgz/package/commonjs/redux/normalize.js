'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

exports.default = normalizeSettings;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactRedux = require('react-redux');

var _helpers = require('../helpers');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Normalizes common settings
function normalizeSettings(settings) {
	if (settings === undefined) {
		throw new Error('Common settings weren\'t passed.');
	}

	if ((typeof settings === 'undefined' ? 'undefined' : _typeof(settings)) !== 'object') {
		throw new Error('Expected a settings object, got ' + (typeof settings === 'undefined' ? 'undefined' : _typeof(settings)) + ': ' + settings);
	}

	settings = (0, _helpers.clone)(settings);

	if (!settings.routes) {
		throw new Error('"routes" parameter is required');
	}

	if (!settings.reducers) {
		throw new Error('"reducers" parameter is required');
	}

	if (!settings.container) {
		// By default it wraps everything with Redux `<Provider/>`.
		settings.container = function Container(_ref) {
			var store = _ref.store,
			    children = _ref.children;

			return _react2.default.createElement(
				_reactRedux.Provider,
				{ store: store },
				children
			);
		};
	}

	if (settings.hot) {
		settings.container = settings.hot(module)(settings.container);
	}

	// Default value for `parseDates` is `true`
	if (settings.parseDates !== false) {
		settings.parseDates = true;
	}

	if (!settings.http) {
		settings.http = {};
	}

	if (!settings.authentication) {
		settings.authentication = {};
	}

	return settings;
}
//# sourceMappingURL=normalize.js.map