'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

exports.default = generatePreloadChain;
exports.filter_preloaders = filter_preloaders;
exports.chain_preloaders = chain_preloaders;

var _flags = require('../../client/flags');

// Returns function returning a Promise
// which resolves when all the required preload()s are resolved.
//
// If no preloading is needed, then returns nothing.
//
function generatePreloadChain(preloaders, server, isInitialClientSidePreload, getState, dispatch, location, parameters, getCookie, preloading) {
	// Set `.preload({ ... })` function arguments,
	// and also set default `@preload()` options.
	setUpPreloaders(preloaders, {
		dispatch: dispatch,
		getState: getState,
		location: location,
		// `parameters` property name is deprecated, use `params` instead.
		parameters: parameters,
		params: parameters,
		server: server,
		// `getCookie` `@preload()` parameter was requested:
		// https://github.com/catamphetamine/react-website/issues/71
		getCookie: getCookie
	}, server);

	// Only select those `@preload()`s which
	// should be run in current circumstances.
	preloaders = filter_preloaders(preloaders, server, isInitialClientSidePreload);

	// Construct a sequential chain out of preloaders.
	// Because each of them could be either parallel or sequential.
	var chain = chain_preloaders(preloaders);

	// If there are no `@preload()`s for this route, then exit.
	if (chain.length === 0) {
		return;
	}

	// Return a function which generates preloading `Promise` chain.
	return function () {
		return promisify(chain, preloading);
	};
}

// Applies default `@preload()` options
// and sets `@preload()` function arguments.
function setUpPreloaders(preloaders, preload_arguments, server) {
	for (var _iterator = preloaders, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
		var _ref;

		if (_isArray) {
			if (_i >= _iterator.length) break;
			_ref = _iterator[_i++];
		} else {
			_i = _iterator.next();
			if (_i.done) break;
			_ref = _i.value;
		}

		var component_preloaders = _ref;

		for (var _iterator2 = component_preloaders, _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
			var _ref2;

			if (_isArray2) {
				if (_i2 >= _iterator2.length) break;
				_ref2 = _iterator2[_i2++];
			} else {
				_i2 = _iterator2.next();
				if (_i2.done) break;
				_ref2 = _i2.value;
			}

			var preloader = _ref2;

			setUpPreloader(preloader, preload_arguments, server);
		}
	}
}

// Applies default `@preload()` options
// and sets `@preload()` function arguments.
function setUpPreloader(preloader, preload_arguments, server) {
	var preload = preloader.preload;
	preloader.preload = function () {
		return preload(preload_arguments);
	};

	// If Server-Side Rendering is not being used at all
	// then all `@preload()`s must be marked as client-side ones.
	if (!server && !(0, _flags.isServerSidePreloaded)()) {
		preloader.options.client = true;
	}
}

// Selects only those `@preload()`s which
// should be run in current circumstances.
function filter_preloaders(preloaders, server, isInitialClientSidePreload) {
	// `preloaders` array will be mutated
	preloaders = preloaders.slice();

	preloaders.forEach(function (_, i) {
		preloaders[i] = preloaders[i].filter(function (preloader) {
			// Don't execute client-side-only `@preload()`s on server side
			if (preloader.options.client && server) {
				return false;
			}
			// Don't execute server-side-only `@preload()`s on client side
			if (preloader.options.server && !server) {
				return false;
			}
			// If it's initial client side preload (after the page has been loaded),
			// then only execute those `@preload()`s marked as "client-side-only".
			if (isInitialClientSidePreload && !preloader.options.client) {
				return false;
			}
			return true;
		});
	});

	return preloaders.filter(function (component_preloaders) {
		return component_preloaders.length > 0;
	});
}

// Constructs `preload` chain.
//
// @param `preloaders` is an array of `component_preloaders`.
// `component_preloaders` is an array of all
// `@preload()`s for a particular React component.
// Therefore `preloaders` is an array of arrays.
function chain_preloaders(preloaders) {
	var chain = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
	var parallel = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];

	// If all `preload`s have been visited
	if (preloaders.length === 0) {
		if (parallel.length === 0) {
			return chain;
		}
		// Finalize pending parallel `preload`s
		if (parallel.length === 1) {
			return chain.concat(parallel);
		}
		return chain.concat({ parallel: parallel });
	}

	// `component_preloaders` is an array of all
	// `@preload()`s for a particular React component.
	var preloader = preloaders[0];
	preloaders = preloaders.slice(1);

	if (!is_preloader_blocking(preloader)) {
		return chain_preloaders(preloaders, chain, concat(parallel, get_preloader(preloader)));
	}

	if (parallel.length === 0) {
		return chain_preloaders(preloaders, concat(chain, get_preloader(preloader)), []);
	}

	return chain_preloaders(preloaders, chain.concat({ parallel: concat(parallel, get_preloader(preloader)) }), []);
}

function get_preloader(preloader) {
	// A list of same component's `@preload()`s
	if (Array.isArray(preloader)) {
		return chain_preloaders(preloader);
	}

	// Same component adjacent `@preload()`
	return preloader.preload;
}

function is_preloader_blocking(preloader) {
	// A list of same component's `@preload()`s
	if (Array.isArray(preloader)) {
		// Determine the proper `blocking` option
		// for this component's `@preload()`s.
		for (var _iterator3 = preloader, _isArray3 = Array.isArray(_iterator3), _i3 = 0, _iterator3 = _isArray3 ? _iterator3 : _iterator3[Symbol.iterator]();;) {
			var _ref3;

			if (_isArray3) {
				if (_i3 >= _iterator3.length) break;
				_ref3 = _iterator3[_i3++];
			} else {
				_i3 = _iterator3.next();
				if (_i3.done) break;
				_ref3 = _i3.value;
			}

			var sibling_preloader = _ref3;

			// If any of component's `@preload()`s are `blocking: true`
			// then all of them are `blocking: true`.
			if (sibling_preloader.options.blocking) {
				return true;
			}
		}

		return false;
	}

	// Same component adjacent `@preload()`
	return preloader.options.blockingSibling;
}

// Returns a `Promise` chain.
function promisify(chain, preloading) {
	if (typeof chain === 'function') {
		return chain();
	}

	if ((typeof chain === 'undefined' ? 'undefined' : _typeof(chain)) === 'object' && chain.parallel) {
		return Promise.all(chain.parallel.map(function (link) {
			return promisify(link, preloading);
		}));
	}

	return chain.reduce(function (promise, link) {
		return promise.then(function () {
			if (preloading.cancelled) {
				return;
			}
			return promisify(link, preloading);
		});
	}, Promise.resolve());
}

function concat(array, part) {
	if (Array.isArray(part) && part.length > 1) {
		// Pushes an array
		return array.concat([part]);
	}
	// Pushes a single element
	return array.concat(part);
}
//# sourceMappingURL=chain.js.map