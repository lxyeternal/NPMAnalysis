'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports.default = createPreloadReducer;

var _actions = require('./actions');

// `@preload()` reducer
function createPreloadReducer() {
	var showInitially = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;

	return function () {
		var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {
			initial: showInitially,
			pending: showInitially,
			immediate: showInitially
		};
		var action = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

		switch (action.type) {
			case _actions.PRELOAD_STARTED:
				return _extends({}, state, {
					pending: true,
					immediate: action.immediate || false,
					error: undefined
				});
			case _actions.PRELOAD_FINISHED:
				return _extends({}, state, {
					pending: false,
					immediate: false,
					initial: false
				});
			case _actions.PRELOAD_FAILED:
				return _extends({}, state, {
					pending: false,
					immediate: false,
					initial: false,
					error: action.error
				});
			default:
				return state;
		}
	};
}
//# sourceMappingURL=reducer.js.map