'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.default = createGetDataForPreload;

var _location = require('../../location');

var _router = require('../../router');

var _preload = require('./preload');

var _preload2 = _interopRequireDefault(_preload);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function createGetDataForPreload(codeSplit, server, onError, getLocale, getConvertedRoutes, getCookie) {
	return function (_ref) {
		var params = _ref.params,
		    _ref$context = _ref.context,
		    dispatch = _ref$context.dispatch,
		    getState = _ref$context.getState;

		if (!server) {
			if (window._react_website_skip_preload || window._react_website_skip_preload_update_location || window._react_website_hot_reload) {
				// Reset "skip @preload()" flag for `pushLocation()` and `replaceLocation()`.
				if (window._react_website_skip_preload_update_location) {
					window._react_website_skip_preload_update_location = false;
				}
				return;
			}
		}

		var _getLocations = getLocations(getState()),
		    location = _getLocations.location,
		    previousLocation = _getLocations.previousLocation;

		var isInitialClientSideNavigation = !server && !previousLocation;
		// A workaround for `found` router bug:
		// https://github.com/4Catalyzer/found/issues/239
		// Prevent executing `@preload()`s on "anchor" link click.
		if (!server && !isInitialClientSideNavigation) {
			if ((0, _location.shouldSkipPreloadForNavigation)(previousLocation, location)) {
				return;
			}
		}
		// Execute `@preload()`s.
		return (0, _preload2.default)(location, isInitialClientSideNavigation ? undefined : previousLocation, {
			routes: (0, _router.getMatchedRoutes)(getState(), getConvertedRoutes()),
			routeIndices: (0, _router.getMatchedRoutesIndices)(getState()),
			routeParams: (0, _router.getMatchedRoutesParams)(getState()),
			params: (0, _router.getRouteParams)(getState())
		}, codeSplit, server, getCookie, getLocale, dispatch, getState).then(function () {}, function (error) {
			// Possibly handle the error (for example, redirect to an error page).
			if (!(error instanceof _router.RedirectException)) {
				if (onError) {
					onError(error, {
						path: location.pathname,
						url: (0, _location.getLocationUrl)(location),
						// Using `redirect` instead of `goto` here
						// so that the user can't go "Back" to the page being preloaded
						// in case of an error because it would be in inconsistent state
						// due to `@preload()` being interrupted.
						redirect: function redirect(to) {
							throw new _router.RedirectException(to);
						},

						getState: getState,
						server: server
					});
				}
			}
			throw error;
		});
	};
}

function getLocations(state) {
	var server = typeof window === 'undefined';
	return {
		location: (0, _router.getCurrentlyMatchedLocation)(state),
		previousLocation: server || !window._react_website_router_rendered ? undefined : (0, _router.getPreviouslyMatchedLocation)(state)
	};
}
//# sourceMappingURL=getData.js.map