'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.ON_PAGE_LOADED_METHOD_NAME = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

exports.default = onPageLoaded;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _hoistNonReactStatics = require('hoist-non-react-statics');

var _hoistNonReactStatics2 = _interopRequireDefault(_hoistNonReactStatics);

var _utility = require('../../utility');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var ON_PAGE_LOADED_METHOD_NAME = exports.ON_PAGE_LOADED_METHOD_NAME = '__on_page_loaded__';

// `@onPageLoaded()` decorator.
//
// `function onPageLoaded({ dispatch, getState, location, params, server })`.
//
function onPageLoaded(onPageLoaded, options) {
	return function (DecoratedComponent) {
		var OnPageLoaded = function (_Component) {
			_inherits(OnPageLoaded, _Component);

			function OnPageLoaded() {
				_classCallCheck(this, OnPageLoaded);

				return _possibleConstructorReturn(this, (OnPageLoaded.__proto__ || Object.getPrototypeOf(OnPageLoaded)).apply(this, arguments));
			}

			_createClass(OnPageLoaded, [{
				key: 'render',
				value: function render() {
					return _react2.default.createElement(DecoratedComponent, this.props);
				}
			}]);

			return OnPageLoaded;
		}(_react.Component);

		OnPageLoaded[ON_PAGE_LOADED_METHOD_NAME] = onPageLoaded;
		// Component naming for React DevTools
		OnPageLoaded.displayName = 'OnPageLoaded(' + (0, _utility.getDisplayName)(DecoratedComponent) + ')';
		// Keep all non-React-specific static methods
		return (0, _hoistNonReactStatics2.default)(OnPageLoaded, DecoratedComponent);
	};
}
//# sourceMappingURL=onPageLoaded.js.map