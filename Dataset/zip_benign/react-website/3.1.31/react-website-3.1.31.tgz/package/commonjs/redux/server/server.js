'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.initialize = undefined;

var _stringify = require('babel-runtime/core-js/json/stringify');

var _stringify2 = _interopRequireDefault(_stringify);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var initialize = exports.initialize = function () {
	var _ref2 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee(settings, _ref) {
		var proxy = _ref.proxy,
		    cookies = _ref.cookies,
		    headers = _ref.headers,
		    locales = _ref.locales,
		    url = _ref.url,
		    getInitialState = _ref.getInitialState;
		var store, httpClient, initialState;
		return _regenerator2.default.wrap(function _callee$(_context) {
			while (1) {
				switch (_context.prev = _context.next) {
					case 0:
						// Redux store
						store = void 0;

						// Create HTTP client (Redux action creator `http` utility)

						httpClient = (0, _HttpClient2.default)(settings, function () {
							return store;
						}, {
							proxy: proxy,
							cookies: cookies
						});

						// Initial Redux state.
						// `User-Agent` and `Accept-Language` headers were requested:
						// https://github.com/catamphetamine/react-website/issues/72

						initialState = getInitialState ? getInitialState({
							cookies: cookies,
							headers: headers,
							locales: locales
						}) : {};

						// Create Redux store.

						store = (0, _store2.default)(settings, initialState, function () {
							return (0, _server.createHistoryProtocol)(url);
						}, httpClient, {
							getCookie: function getCookie(name) {
								return cookies[name];
							},
							server: true
						});

						return _context.abrupt('return', {
							store: store,
							generateJavascript: function generateJavascript() {
								return _generateJavascript(store, settings);
							},
							cookies: httpClient.set_cookies
						});

					case 5:
					case 'end':
						return _context.stop();
				}
			}
		}, _callee, this);
	}));

	return function initialize(_x, _x2) {
		return _ref2.apply(this, arguments);
	};
}();

var _uglifyJs = require('uglify-js');

var _uglifyJs2 = _interopRequireDefault(_uglifyJs);

var _parseDates = require('../../parseDates');

var _html = require('../../server/html');

var _store = require('../store');

var _store2 = _interopRequireDefault(_store);

var _HttpClient = require('../HttpClient');

var _HttpClient2 = _interopRequireDefault(_HttpClient);

var _server = require('../../router/server');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _generateJavascript(store, settings) {
	var code = '';

	// JSON Date deserializer
	if (settings.parseDates) {
		code += '<script>' + DEFINE_JSON_DATE_PARSER + '</script>';
	}

	// Store data will be reloaded into the store on the client-side.
	// All forward slashes are escaped to prevent XSS attacks.
	// Another solution would be replacing with `\uxxxx` sequences.
	// https://medium.com/node-security/the-most-common-xss-vulnerability-in-react-js-applications-2bdffbcc1fa0
	code += '<script>';
	code += 'window._redux_state = JSON.parse(' + (0, _stringify2.default)((0, _html.safeJsonStringify)(store.getState())) + (settings.parseDates ? ', JSON.dateParser' : '') + ')';
	code += '</script>';

	return code;
}

// JSON date deserializer.
// Use as the second, 'reviver' argument to `JSON.parse(json, JSON.dateParser)`.
// http://stackoverflow.com/questions/14488745/javascript-json-date-deserialization/23691273#23691273
var DEFINE_JSON_DATE_PARSER = _uglifyJs2.default.minify('\nif (!JSON.dateParser) {\n\tJSON.dateParser = function(key, value) {\n\t\tif (typeof value === \'string\' && /^' + _parseDates.ISO_date_regexp + '$/.test(value)) {\n\t\t\treturn new Date(value)\n\t\t}\n\t\treturn value\n\t}\n}\n', { fromString: true }).code;

// Just to be extra safe from XSS attacks
if (DEFINE_JSON_DATE_PARSER.indexOf('<') !== -1) {
	throw new Error('JSON Date parser XSS vulnerability detected');
}
//# sourceMappingURL=server.js.map