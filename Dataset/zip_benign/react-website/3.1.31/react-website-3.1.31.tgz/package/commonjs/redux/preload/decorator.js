'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.PRELOAD_OPTIONS_NAME = exports.PRELOAD_METHOD_NAME = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

exports.default = preload;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _hoistNonReactStatics = require('hoist-non-react-statics');

var _hoistNonReactStatics2 = _interopRequireDefault(_hoistNonReactStatics);

var _utility = require('../../utility');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var PRELOAD_METHOD_NAME = exports.PRELOAD_METHOD_NAME = '__preload__';
var PRELOAD_OPTIONS_NAME = exports.PRELOAD_OPTIONS_NAME = '__preload_options__';

// `@preload(preloader, [options])` decorator.
//
// `preloader` function must return a `Promise` (or be `async`):
//
// `function preloader({ dispatch, getState, location, params, server })`.
//
// The decorator also receives an optional `options` argument (advanced topic):
//
// * `blocking` — If `false` then all child `<Route/>`'s  `@preload()`s will not
//                wait for this `@preload()` to finish in order to get executed
//                (is `true` by default).
//
// * `blockingSibling` — If `true` then all further adjacent (sibling) `@preload()`s
//                       for the same `<Route/>`'s component will wait for this
//                       `@preload()` to finish in order to get executed.
//                       (is `true` by default).
//
// * `client`   — If `true` then the `@preload()` will be executed only on client side.
//                Otherwise the `@preload()` will be executed normally:
//                if part of initial page preloading then on server side and
//                if part of subsequent preloading (e.g. navigation) then on client side.
//
// * `server`   — If `true` then the `@preload()` will be executed only on server side.
//                Otherwise the `@preload()` will be executed normally:
//                if part of initial page preloading then on server side and
//                if part of subsequent preloading (e.g. navigation) then on client side.
//
function preload(preload) {
	var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

	return function (DecoratedComponent) {
		var PreloadedComponent = function (_Component) {
			_inherits(PreloadedComponent, _Component);

			function PreloadedComponent() {
				_classCallCheck(this, PreloadedComponent);

				return _possibleConstructorReturn(this, (PreloadedComponent.__proto__ || Object.getPrototypeOf(PreloadedComponent)).apply(this, arguments));
			}

			_createClass(PreloadedComponent, [{
				key: 'render',
				value: function render() {
					return _react2.default.createElement(DecoratedComponent, this.props);
				}
			}]);

			return PreloadedComponent;
		}(_react.Component);

		// Since there can be several `@preload()`s
		// on a single component, using arrays here.


		PreloadedComponent[PRELOAD_METHOD_NAME] = DecoratedComponent[PRELOAD_METHOD_NAME] || [];
		PreloadedComponent[PRELOAD_OPTIONS_NAME] = DecoratedComponent[PRELOAD_OPTIONS_NAME] || [];

		PreloadedComponent[PRELOAD_METHOD_NAME].unshift(preload);
		PreloadedComponent[PRELOAD_OPTIONS_NAME].unshift(options);

		// Component naming for React DevTools
		PreloadedComponent.displayName = 'Preload(' + (0, _utility.getDisplayName)(DecoratedComponent) + ')';

		// Keep all non-React-specific static methods
		return (0, _hoistNonReactStatics2.default)(PreloadedComponent, DecoratedComponent);
	};
}
//# sourceMappingURL=decorator.js.map