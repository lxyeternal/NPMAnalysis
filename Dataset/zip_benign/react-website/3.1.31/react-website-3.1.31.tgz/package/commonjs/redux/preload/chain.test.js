'use strict';

var _chain = require('./chain');

describe('@preload', function () {
	it('should filter preloaders', function () {
		var preload_1 = function preload_1() {};
		var preload_2 = function preload_2() {};
		var preload_3 = function preload_3() {};

		var preloaders = [[{
			preload: preload_1,
			options: { client: true }
		}], [{
			preload: preload_2,
			options: { blocking: false }
		}, {
			preload: preload_3,
			options: { server: true }
		}]];

		// server : true
		(0, _chain.filter_preloaders)(preloaders, true).should.deep.equal([[{
			preload: preload_2,
			options: { blocking: false }
		}, {
			preload: preload_3,
			options: { server: true }
		}]]);

		// server : false
		// initial_client_side_preload : false
		(0, _chain.filter_preloaders)(preloaders, false, false).should.deep.equal([[{
			preload: preload_1,
			options: { client: true }
		}], [{
			preload: preload_2,
			options: { blocking: false }
		}]]);

		// server : false
		// initial_client_side_preload : true
		(0, _chain.filter_preloaders)(preloaders, false, true).should.deep.equal([[{
			preload: preload_1,
			options: { client: true }
		}]]);
	});

	it('should chain preloaders', function () {
		var preload_1 = function preload_1() {};
		var preload_2 = function preload_2() {};
		var preload_3 = function preload_3() {};
		var preload_4 = function preload_4() {};
		var preload_5 = function preload_5() {};
		var preload_6 = function preload_6() {};

		(0, _chain.chain_preloaders)([[{
			preload: preload_1,
			options: { blocking: true }
		}, {
			preload: preload_2,
			options: {}
		}], [{
			preload: preload_3,
			options: { blocking: false }
		}, {
			preload: preload_4,
			options: {}
		}]]).should.deep.equal([{
			parallel: [preload_1, preload_2]
		}, {
			parallel: [preload_3, preload_4]
		}]);

		(0, _chain.chain_preloaders)([[{
			preload: preload_1,
			options: {}
		}, {
			preload: preload_2,
			options: {}
		}], [{
			preload: preload_3,
			options: {}
		}, {
			preload: preload_4,
			options: { blocking: true }
		}], [{
			preload: preload_5,
			options: {}
		}, {
			preload: preload_6,
			options: {}
		}]]).should.deep.equal([{
			parallel: [{
				parallel: [preload_1, preload_2]
			}, {
				parallel: [preload_3, preload_4]
			}]
		}, {
			parallel: [preload_5, preload_6]
		}]);

		(0, _chain.chain_preloaders)([[{
			preload: preload_1,
			options: {}
		}], [{
			preload: preload_3,
			options: {}
		}, {
			preload: preload_4,
			options: {}
		}], [{
			preload: preload_5,
			options: {}
		}]]).should.deep.equal([{
			parallel: [preload_1, {
				parallel: [preload_3, preload_4]
			}, preload_5]
		}]);

		(0, _chain.chain_preloaders)([[{
			preload: preload_1,
			options: {}
		}], [{
			preload: preload_3,
			options: {}
		}], [{
			preload: preload_5,
			options: {}
		}]]).should.deep.equal([{
			parallel: [preload_1, preload_3, preload_5]
		}]);

		(0, _chain.chain_preloaders)([[{
			preload: preload_1,
			options: {}
		}], [{
			preload: preload_3,
			options: { blocking: true }
		}], [{
			preload: preload_5,
			options: {}
		}]]).should.deep.equal([{
			parallel: [preload_1, preload_3]
		}, preload_5]);

		(0, _chain.chain_preloaders)([[{
			preload: preload_1,
			options: {}
		}], [{
			preload: preload_3,
			options: { blockingSibling: true }
		}, {
			preload: preload_4,
			options: {}
		}], [{
			preload: preload_5,
			options: { blocking: true }
		}]]).should.deep.equal([{
			parallel: [preload_1, [preload_3, preload_4], preload_5]
		}]);

		(0, _chain.chain_preloaders)([[{
			preload: preload_1,
			options: {}
		}], [{
			preload: preload_3,
			options: { blockingSibling: true }
		}, {
			preload: preload_4,
			options: { blockingSibling: true }
		}, {
			preload: preload_5,
			options: {}
		}], [{
			preload: preload_6,
			options: { blocking: true }
		}]]).should.deep.equal([{
			parallel: [preload_1, [preload_3, preload_4, preload_5], preload_6]
		}]);

		(0, _chain.chain_preloaders)([[{
			preload: preload_1,
			options: { blocking: true }
		}], [{
			preload: preload_3,
			options: { blockingSibling: true }
		}, {
			preload: preload_4,
			options: { blockingSibling: true }
		}, {
			preload: preload_5,
			options: { blocking: true }
		}], [{
			preload: preload_6,
			options: {}
		}]]).should.deep.equal([preload_1, [preload_3, preload_4, preload_5], preload_6]);

		(0, _chain.chain_preloaders)([[{
			preload: preload_1,
			options: {}
		}], [{
			preload: preload_3,
			options: { blockingSibling: true }
		}, {
			preload: preload_4,
			options: {}
		}, {
			preload: preload_5,
			options: {}
		}], [{
			preload: preload_6,
			options: {}
		}]]).should.deep.equal([{
			parallel: [preload_1, [preload_3, {
				parallel: [preload_4, preload_5]
			}], preload_6]
		}]);

		(0, _chain.chain_preloaders)([[{
			preload: preload_1,
			options: {}
		}], [{
			preload: preload_2,
			options: {}
		}, {
			preload: preload_3,
			options: { blockingSibling: true }
		}, {
			preload: preload_4,
			options: {}
		}, {
			preload: preload_5,
			options: {}
		}], [{
			preload: preload_6,
			options: { blocking: true }
		}]]).should.deep.equal([{
			parallel: [preload_1, [{
				parallel: [preload_2, preload_3]
			}, {
				parallel: [preload_4, preload_5]
			}], preload_6]
		}]);
	});
});
//# sourceMappingURL=chain.test.js.map