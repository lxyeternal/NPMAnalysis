'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.ERROR_ACTION_PROPERTY = exports.RESULT_ACTION_PROPERTY = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

exports.default = asynchronousMiddleware;

var _helpers = require('../../helpers');

var _location = require('../../location');

var _router = require('../../router');

var _naming = require('../naming');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

var RESULT_ACTION_PROPERTY = exports.RESULT_ACTION_PROPERTY = 'value';
var ERROR_ACTION_PROPERTY = exports.ERROR_ACTION_PROPERTY = 'error';

// Asynchronous middleware (e.g. for HTTP Ajax calls).
//
// Takes effect only if the `dispatch`ed action has
// `promise` function and `events` (or `event`) property.
//
// `dispatch()` call will return a `Promise`.
//
function asynchronousMiddleware(httpClient, reduxEventNaming, server, onError) {
	var parseError = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : defaultParseError;

	reduxEventNaming = reduxEventNaming || _naming.DEFAULT_REDUX_EVENT_NAMING;

	return function (_ref) {
		var dispatch = _ref.dispatch,
		    getState = _ref.getState;

		// Can cancel previous actions of the same `type` (if configured).
		// E.g. for an AJAX autocomplete.
		var cancellablePromises = {};

		return function (next) {
			return function (action) {
				var promise = action.promise,
				    event = action.event,
				    events = action.events,
				    cancelPrevious = action.cancelPrevious,
				    rest = _objectWithoutProperties(action, ['promise', 'event', 'events', 'cancelPrevious']);

				// If the dispatched action doesn't have a `promise` function property then do nothing


				if (typeof promise !== 'function') {
					return next(action);
				}

				// Generate the three event names automatically based on a base event name
				if (!events && typeof event === 'string') {
					events = reduxEventNaming(event);
				}

				// Validate `events` property
				if (!events || events.length !== 3) {
					throw new Error('"events" property must be an array of 3 event names: e.g. [\'pending\', \'success\', \'error\']');
				}

				// event names

				var _events = events,
				    _events2 = _slicedToArray(_events, 3),
				    Request = _events2[0],
				    Success = _events2[1],
				    Failure = _events2[2];

				// dispatch the `pending` event to the Redux store


				dispatch(_extends({}, rest, { type: Request }));

				// Run the asychronous action (e.g. an HTTP request)
				var promised = promise(httpClient,
				// `dispatch` and `getState` arguments are deprecated
				// and will be removed in some future major version release.
				dispatch, getState);

				// Validate that `promise()` actually returned a `Promise`
				if (!promised || typeof promised.then !== 'function') {
					console.error('Redux action\'s "promise" function returned:', promised);
					throw new Error('Redux action\'s "promise" function must return a Promise.');
				}

				// Is the action promise cancellable
				var cancellable = !server && cancelPrevious && typeof promised.cancel === 'function';

				// Cancel previous action of the same `type` (if configured).
				// E.g. for an AJAX autocomplete.
				if (cancellable) {
					if (cancellablePromises[Request]) {
						cancellablePromises[Request].cancel();
					}
					cancellablePromises[Request] = promised;
				}

				// Returning the result like this,
				// because if returned the `promised.then()` chain directly
				// then it wouldn't get detected as an "Unhandled rejection"
				// in case of an error.
				return new Promise(function (resolve, reject) {
					// Don't `return` this promise
					// so that it detects it as an "Unhandled rejection"
					// in case of an error.
					promised.then(
					// If the Promise resolved
					// (e.g. an HTTP request succeeded)
					function (result) {
						// The default `Promise` implementation has no `.finally()`
						if (cancellable) {
							delete cancellablePromises[Request];
						}

						// Dispatch the `success` event to the Redux store
						dispatch(_extends({}, rest, _defineProperty({
							type: Success
						}, RESULT_ACTION_PROPERTY, result)));

						// Returning the result like this,
						// because if returned the `promised.then()` chain directly
						// then it wouldn't get detected as an "Unhandled rejection"
						// in case of an error.
						resolve(result);

						// The Promise returned from `dispatch()` call
						// is resolved with the `promise` resolved value.
						return result;
					},
					// if the Http request failed
					//
					// (Http status !== 20x
					//  or the Http response JSON object has an `error` field)
					function (error) {
						// The default `Promise` implementation has no `.finally()`
						if (cancellable) {
							delete cancellablePromises[Request];
						}

						// Dispatch the `failure` event to the Redux store
						dispatch(_extends({}, rest, _defineProperty({
							type: Failure
						}, ERROR_ACTION_PROPERTY, parseError(error))));

						// The Promise returned from `dispatch()` call
						// is rejected with this error.

						// Also only checks `http` calls on client side
						// because on server side `http` calls can be
						// either part of `@preload` of part of `initialize`
						// which are already "error handled".
						// On the client side though, an `http` call
						// may be performed via some user input,
						// so it needs this separate case "error handler".
						if (!server && onError) {
							var location = getState().found.resolvedMatch.location;
							// Report the error
							// (for example, redirect to a login page
							//  if a JWT "access token" expired)
							onError(error, {
								path: location.pathname,
								url: (0, _location.getLocationUrl)(location),
								// Using `goto` instead of `redirect` here
								// because it's not part of `@preload()`
								// and is therefore part of some kind of an HTTP request
								// triggered by user input (e.g. form submission)
								// which means it is convenient to be able to
								// go "Back" to the page on which the error originated.
								redirect: function redirect(to) {
									return dispatch((0, _router.goto)(to));
								},
								dispatch: dispatch,
								getState: getState,
								server: server
							});
						}

						// Returning the result (error) like this,
						// because if returned the `promised.then()` chain directly
						// then it wouldn't get detected as an "Unhandled rejection"
						// in case of an error.
						reject(error);

						// Reduce client-side error reporting software (e.g. sentry.io)
						// noise for not-really-errors like "Unauthenticated" and "Unauthorized".
						if (error.status !== 401 && error.status !== 403) {
							throw error;
						}
					});
				});
			};
		};
	};
}

// Transform Javascript `Error` instance into a plain JSON object
// because the meaning of the `error` action is different
// from what `Error` class is: it should only carry info like
// `status`, `message` and possible other values (e.g. `code`),
// without any stack traces, line numbers, etc.
// I.e. the `error` action should be a plain javascript object,
// not an instance of an `Error` class, because it's Redux (stateless).
//
// Parses a `superagent` `Error` instance
// into a plain JSON object for storing it in Redux state.
// In case of an `application/json` HTTP response
// the `error` instance ha `.data` JSON object property
// which carries the `application/json` HTTP response data.
//
function defaultParseError(error) {
	// Copies JSON HTTP response entirely
	var errorData = (0, _helpers.isObject)(error.data) ? error.data : {};

	// Sets HTTP response `status` code
	// if `status` property wasn't present in JSON HTTP response.
	if (!(0, _helpers.exists)(errorData.status)) {
		errorData.status = error.status;
	}

	// Copies `message` from `Error` instance
	// if `message` property wasn't present in JSON HTTP response.
	if (!(0, _helpers.exists)(errorData.message)) {
		errorData.message = error.message;
	}

	return errorData;
}
//# sourceMappingURL=asynchronous.js.map