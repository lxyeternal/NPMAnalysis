'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _extends2 = require('babel-runtime/helpers/extends');

var _extends3 = _interopRequireDefault(_extends2);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _timer = require('../../timer');

var _timer2 = _interopRequireDefault(_timer);

var _meta = require('../../meta/meta');

var _router = require('../../router');

var _server = require('../../router/server');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Returns a Promise resolving to { status, content, redirect }.
//
exports.default = function () {
	var _ref2 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee(_ref) {
		var store = _ref.store,
		    codeSplit = _ref.codeSplit,
		    defaultMeta = _ref.defaultMeta;

		var time, preloadTimer, renderArgs, _renderArgs, routes, elements, meta;

		return _regenerator2.default.wrap(function _callee$(_context) {
			while (1) {
				switch (_context.prev = _context.next) {
					case 0:
						// Routing only takes a couple of milliseconds
						// const routingTimer = timer()

						// Profiling
						time = {};
						preloadTimer = (0, _timer2.default)();
						renderArgs = void 0;
						_context.prev = 3;
						_context.next = 6;
						return (0, _router.matchRoutes)(store);

					case 6:
						renderArgs = _context.sent;
						_context.next = 14;
						break;

					case 9:
						_context.prev = 9;
						_context.t0 = _context['catch'](3);

						if (!(_context.t0 instanceof _router.RedirectException)) {
							_context.next = 13;
							break;
						}

						return _context.abrupt('return', {
							redirect: _context.t0.location
						});

					case 13:
						throw _context.t0;

					case 14:

						time.preload = preloadTimer();

						// Gather `<title/>` and `<meta/>` tags for this route path
						_renderArgs = renderArgs, routes = _renderArgs.routes, elements = _renderArgs.elements;

						// Get `<meta/>` for the route.

						meta = codeSplit ? (0, _meta.getCodeSplitMeta)(routes, store.getState()) : (0, _meta.getComponentsMeta)(elements.map(function (_) {
							return _.type;
						}), store.getState());

						meta = (0, _meta.mergeMeta)(meta);
						meta = (0, _extends3.default)({}, defaultMeta, meta);

						// Return HTTP status code and the rendered page
						return _context.abrupt('return', {
							// Concatenated `react-router` route string.
							// E.g. "/user/:user_id/post/:post_id"
							route: getRoutePath(routes),
							status: getHttpResponseStatusCodeForTheRoute(routes),
							content: (0, _server.createRouterElement)(renderArgs),
							meta: meta,
							containerProps: { store: store },
							time: time
						});

					case 20:
					case 'end':
						return _context.stop();
				}
			}
		}, _callee, this, [[3, 9]]);
	}));

	function renderOnServer(_x) {
		return _ref2.apply(this, arguments);
	}

	return renderOnServer;
}();

// One can set a `status` prop for a react-router `Route`
// to be returned as an Http response status code (404, etc)


function getHttpResponseStatusCodeForTheRoute(matchedRoutes) {
	return matchedRoutes.reduce(function (previous, current) {
		return current && current.status || previous && current.status;
	}, null);
}

// Returns a complete path
// for matched `react-router` `<Route/>` chain.
// E.g. returns "/user/:user_id/post/:post_id"
// for matched URL "/user/1/post/123?key=value".
function getRoutePath(routes) {
	return routes
	// Select `<Route/>`s having `path` React property set.
	.filter(function (route) {
		return route.path;
	})
	// Trim leading and trailing slashes (`/`)
	// from each `<Route/>` `path` React property.
	.map(function (route) {
		return route.path.replace(/^\//, '').replace(/\/$/, '');
	})
	// Join `<Route/>` `path`s with slashes (`/`).
	.join('/') || '/';
}
//# sourceMappingURL=render.js.map