'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.indicateLoading = exports.PRELOAD_FAILED = exports.PRELOAD_FINISHED = exports.PRELOAD_STARTED = undefined;

var _location = require('../../location');

var PRELOAD_STARTED = exports.PRELOAD_STARTED = '@@react-website/redux/preload-started';
var PRELOAD_FINISHED = exports.PRELOAD_FINISHED = '@@react-website/redux/preload-finished';
var PRELOAD_FAILED = exports.PRELOAD_FAILED = '@@react-website/redux/preload-failed';

// Can be called manually to show the loading screen.
// E.g. when the user has been logged in
// and calling `window.location.reload()`.
var indicateLoading = exports.indicateLoading = function indicateLoading() {
	return {
		type: PRELOAD_STARTED,
		immediate: true
	};
};
//# sourceMappingURL=actions.js.map