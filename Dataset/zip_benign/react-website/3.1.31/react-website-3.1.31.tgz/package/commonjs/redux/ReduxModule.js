'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.default = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

exports.createReduxModule = createReduxModule;

var _naming = require('./naming');

var _asynchronous = require('./middleware/asynchronous');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

// Sometimes modules for one project are imported from another project directory.
// For example, Redux actions from one project may be imported into another project.
// In such cases `Counter` is not enough because Redux event names would collide
// because actions from the first project use different `node_modules` and therefore
// use different `react-website` modules having their own `Counter`.
// In such cases it's mandatory to pass Redux event name to `.action()` and `.simpleAction()`.
// Otherwise there will be Redux event name collisions.
// Importing packages from two different `node_modules` is not a good practice.

// Deprecated. Use `new ReduxModule()` instead.
function createReduxModule(namespace, settings) {
	return new ReduxModule(namespace, settings);
}

var ReduxModule = function () {
	function ReduxModule() {
		var _this = this;

		var namespace = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : (0, _naming.generateReduxNamespace)(counter.next());
		var settings = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

		_classCallCheck(this, ReduxModule);

		this.handlers = {};
		this.registered_state_properties = [];

		this.getProperties = function (state) {
			var properties = {};

			for (var _iterator = _this.registered_state_properties, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
				var _ref;

				if (_isArray) {
					if (_i >= _iterator.length) break;
					_ref = _iterator[_i++];
				} else {
					_i = _iterator.next();
					if (_i.done) break;
					_ref = _i.value;
				}

				var property_name = _ref;

				properties[property_name] = state[property_name];
			}

			return properties;
		};

		this.namespace = namespace;

		this.settings = {
			reduxEventNaming: settings.reduxEventNaming || _naming.DEFAULT_REDUX_EVENT_NAMING,
			reduxPropertyNaming: settings.reduxPropertyNaming || _naming.underscoredToCamelCase
		};
	}

	_createClass(ReduxModule, [{
		key: 'replace',
		value: function replace(event, handler) {
			if (!Array.isArray(handler)) {
				handler = [handler];
			}

			this.handlers[event] = handler;
		}
	}, {
		key: 'on',
		value: function on(namespace, event, handler) {
			if (typeof event === 'function') {
				handler = event;
				event = namespace;
				namespace = undefined;
			} else {
				// Use "success" event name.
				event = this.settings.reduxEventNaming((0, _naming.eventName)(namespace, event))[1];
			}

			if (!this.handlers[event]) {
				this.handlers[event] = [];
			}

			this.handlers[event].push(handler);
		}
	}, {
		key: 'action',
		value: function action(event, _action, result, options) {
			if (event && typeof event !== 'string') {
				options = result;
				result = _action;
				_action = event;
				event = undefined;
			}

			// Autogenerate `event` name.
			if (!event) {
				event = (0, _naming.generateReduxEventName)(counter.next());
			}

			options = options || {};

			if (typeof _action !== 'function') {
				throw new Error('[react-website] One must pass an `action()` argument (the second one) to Redux module action creator: `reduxModule(event, action, result, options = {})`.');
			}

			return create_action(event, _action, result, options, this);
		}
	}, {
		key: 'simpleAction',
		value: function simpleAction(event, action, result, options) {
			if (event && typeof event !== 'string') {
				options = result;
				result = action;
				action = event;
				event = undefined;
			}
			// `action` argument is currently a useless one:
			// taking arguments and converting them into an object.
			// This feature substitutes a missing `action` argument with a passthrough.
			// Deprecated: remove `action` argument in some future major version.
			if (action) {
				if (typeof result !== 'string' && typeof result !== 'function') {
					options = result;
					result = action;
					action = function action(object) {
						return object;
					};
				}
			}
			options = options || {};
			options.sync = true;
			return this.action(event, action, result, options);
		}

		// Returns Redux action creator for resetting error.

	}, {
		key: 'resetError',
		value: function resetError(event) {
			var _this2 = this;

			var _settings$reduxEventN = this.settings.reduxEventNaming(event),
			    _settings$reduxEventN2 = _slicedToArray(_settings$reduxEventN, 3),
			    pending_event_name = _settings$reduxEventN2[0],
			    success_event_name = _settings$reduxEventN2[1],
			    error_event_name = _settings$reduxEventN2[2];

			// Redux "action creator"


			return function () {
				return {
					type: (0, _naming.eventName)(_this2.namespace, error_event_name),
					error: undefined
				};
			};
		}

		// Deprecated.

	}, {
		key: 'createReducer',
		value: function createReducer() {
			var _this3 = this;

			var initialState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

			// Applies a handler based on the Redux action `type`.
			// (is copy & paste'd for all action response handlers)
			return function () {
				var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : initialState;
				var event = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

				try {
					for (var _iterator2 = _this3.handlers[event.type] || [], _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
						var _ref2;

						if (_isArray2) {
							if (_i2 >= _iterator2.length) break;
							_ref2 = _iterator2[_i2++];
						} else {
							_i2 = _iterator2.next();
							if (_i2.done) break;
							_ref2 = _i2.value;
						}

						var handler = _ref2;

						state = handler(state, _this3.getEventData(event));
					}
					return state;
				} catch (error) {
					// For some strange reason Redux didn't report
					// these errors to the console, hence the manual `console.error`.
					console.error(error);
					throw error;
				}
			};
		}
	}, {
		key: 'reducer',
		value: function reducer() {
			var initialState = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

			var reducer = this.createReducer(initialState);
			// The event names list is used for autogenerated
			// event names conflict detection.
			// See `checkForAutogeneratedEventNameCollision()`.
			reducer._react_website_events = Object.keys(this.handlers);
			return reducer;
		}
	}, {
		key: 'getEventData',
		value: function getEventData(event) {
			if (Object.prototype.hasOwnProperty.call(event, _asynchronous.RESULT_ACTION_PROPERTY)) {
				return event[_asynchronous.RESULT_ACTION_PROPERTY];
			} else if (event[_asynchronous.ERROR_ACTION_PROPERTY] !== undefined) {
				return event[_asynchronous.ERROR_ACTION_PROPERTY];
			} else {
				return event;
			}
		}
	}, {
		key: 'add_state_properties',
		value: function add_state_properties() {
			this.registered_state_properties.push.apply(this.registered_state_properties, arguments);
		}

		// Public alias.

	}, {
		key: 'properties',
		value: function properties() {
			this.add_state_properties.apply(this, arguments);
		}

		// Public alias.

	}, {
		key: 'property',
		value: function property() {
			this.add_state_properties.apply(this, arguments);
		}
	}]);

	return ReduxModule;
}();

// Returns Redux action creator.


exports.default = ReduxModule;
function create_action(event, action, result, options, redux) {
	var _this4 = this;

	var namespace = redux.namespace;

	var sync = options.sync,
	    cancelPrevious = options.cancelPrevious;

	// If `result` is a property name,
	// then add that property to `connectXxx()`.

	if (typeof result === 'string') {
		redux.add_state_properties(result);
	}
	// If `result` is an object of property getters,
	// then add those properties to `connectXxx()`.
	else if ((typeof result === 'undefined' ? 'undefined' : _typeof(result)) === 'object') {
			redux.add_state_properties.apply(redux, _toConsumableArray(Object.keys(result)));
		}

	// Default "on result" handler is a reducer that does nothing.
	// Actually, I guess it should throw an error instead.
	// Deprecated: throw an error in some future major version
	// instead of using a "no op" reducer.
	result = result || function (state) {
		return state;
	};

	// Synchronous action
	if (sync) {
		// Reducer
		redux.on((0, _naming.eventName)(namespace, event), get_action_value_reducer(result));

		// Redux "action creator"
		return function () {
			for (var _len = arguments.length, parameters = Array(_len), _key = 0; _key < _len; _key++) {
				parameters[_key] = arguments[_key];
			}

			return _defineProperty({
				type: (0, _naming.eventName)(namespace, event)
			}, _asynchronous.RESULT_ACTION_PROPERTY, action.apply(_this4, parameters));
		};
	}

	// Asynchronous action

	// Add Redux reducers handling events:
	//
	//   * pending
	//   * success
	//   * error
	//
	add_asynchronous_action_reducers(redux, namespace, event, get_action_value_reducer(result));

	// Redux "action creator"
	return function () {
		for (var _len2 = arguments.length, parameters = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
			parameters[_key2] = arguments[_key2];
		}

		return {
			event: (0, _naming.eventName)(namespace, event),
			// `dispatch` and `getState` arguments are deprecated
			// and will be removed in some future major version release.
			promise: function promise(http, dispatch, getState) {
				if (redux.v2) {
					// For gradual migration from version "2.x" syntax.
					return action.apply(_this4, [{ http: http, dispatch: dispatch, getState: getState }].concat(parameters));
				}
				return action.apply(_this4, parameters)(http);
			},
			cancelPrevious: cancelPrevious
		};
	};
}

// Adds handlers for:
//
//   * pending
//   * done
//   * failed
//   * reset error
//
function add_asynchronous_action_reducers(redux, namespace, event, result_reducer) {
	var _redux$settings$redux = redux.settings.reduxEventNaming(event),
	    _redux$settings$redux2 = _slicedToArray(_redux$settings$redux, 3),
	    pending_event_name = _redux$settings$redux2[0],
	    success_event_name = _redux$settings$redux2[1],
	    error_event_name = _redux$settings$redux2[2];

	var pending_property_name = redux.settings.reduxPropertyNaming(pending_event_name);
	var error_property_name = redux.settings.reduxPropertyNaming(error_event_name);

	// This info will be used in `storeConnector`
	redux.add_state_properties(pending_property_name, error_property_name);

	// When Promise is created: reset result variable, clear `error`, set `pending` flag.
	redux.on((0, _naming.eventName)(namespace, pending_event_name), function (state) {
		var new_state = _extends({}, state, _defineProperty({}, pending_property_name, true));

		// Clear `error`
		if (redux.v2) {
			// For gradual migration from version "2.x" syntax.
			new_state[error_property_name] = undefined;
		} else {
			delete new_state[error_property_name];
		}

		return new_state;
	});

	// When Promise succeeds: clear `pending` flag, set result variable.
	redux.on((0, _naming.eventName)(namespace, success_event_name), function (state, result) {
		var new_state = result_reducer(state, result);

		// Clear `pending` flag
		if (redux.v2) {
			// For gradual migration from version "2.x" syntax.
			new_state[pending_property_name] = false;
		} else {
			delete new_state[pending_property_name];
		}

		return new_state;
	});

	// When Promise fails, clear `pending` flag and set `error`.
	// Can also clear `error` when no `error` is passed as part of an action.
	redux.on((0, _naming.eventName)(namespace, error_event_name), function (state, error) {
		var new_state = _extends({}, state, _defineProperty({}, error_property_name, error));

		// Clear `pending` flag
		if (redux.v2) {
			// For gradual migration from version "2.x" syntax.
			new_state[pending_property_name] = false;
		} else {
			delete new_state[pending_property_name];
			// `resetError()`
			if (!error) {
				delete new_state[error_property_name];
			}
		}

		return new_state;
	});
}

// Returns a function
function get_action_value_reducer(reducer) {
	// If `reducer` is a property name,
	// then the reducer will write action value
	// to that property of Redux state.
	if (typeof reducer === 'string') {
		return function (state, value) {
			return _extends({}, state, _defineProperty({}, reducer, value));
		};
	}

	// If `reducer` is an object of property getters
	// then those properties will be added to Redux state.
	if ((typeof reducer === 'undefined' ? 'undefined' : _typeof(reducer)) === 'object') {
		return function (state, value) {
			var updated_properties = {};

			for (var _iterator3 = Object.keys(reducer), _isArray3 = Array.isArray(_iterator3), _i3 = 0, _iterator3 = _isArray3 ? _iterator3 : _iterator3[Symbol.iterator]();;) {
				var _ref4;

				if (_isArray3) {
					if (_i3 >= _iterator3.length) break;
					_ref4 = _iterator3[_i3++];
				} else {
					_i3 = _iterator3.next();
					if (_i3.done) break;
					_ref4 = _i3.value;
				}

				var property = _ref4;

				updated_properties[property] = reducer[property](value);

				// Don't know why did I previously write it like:
				// updated_properties =
				// {
				// 	...updated_properties,
				// 	...reducer[property](value)
				// }
			}

			return _extends({}, state, updated_properties);
		};
	}

	// Otherwise `reducer` is `(state, value) => ...`
	return reducer;
}

var Counter = function () {
	function Counter() {
		_classCallCheck(this, Counter);

		this.counter = 0;
	}

	_createClass(Counter, [{
		key: 'next',
		value: function next() {
			if (this.counter < MAX_SAFE_INTEGER) {
				this.counter++;
			} else {
				this.counter = 1;
			}
			return this.counter;
		}
	}]);

	return Counter;
}();

var counter = new Counter();

// `MAX_SAFE_INTEGER` is not supported by older browsers
var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || Math.pow(2, 53) - 1;
//# sourceMappingURL=ReduxModule.js.map