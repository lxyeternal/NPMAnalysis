'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.default = collectTranslations;

var _decorator = require('../translate/decorator');

function collectTranslations(components, routes, routeIndices, codeSplit, locale, dispatch) {
	// Set the `_key` for each `<Route/>`.
	// Each page component gets `route` property
	// from which it can get the `_key`
	// and using that `_key` it can get the
	// translation data from Redux state.
	routes.forEach(function (route, i) {
		route._key = routeIndices.slice(0, i + 1).join('/');
	});
	var translations = components.map(function (component, i) {
		return {
			path: routes[i]._key,
			getTranslation: component[_decorator.TRANSLATE_LOCALES_PROPERTY] && component[_decorator.TRANSLATE_LOCALES_PROPERTY][locale]
		};
	}).filter(function (_) {
		return _.getTranslation;
	});
	if (translations.length > 0) {
		return function () {
			return Promise.all(translations.map(function (_ref) {
				var path = _ref.path,
				    getTranslation = _ref.getTranslation;

				return getTranslation().then(function (translation) {
					return dispatch('@@react-website/translation', {
						path: path,
						translation: translation
					});
				});
			}));
		};
	}
}
//# sourceMappingURL=collect.js.map