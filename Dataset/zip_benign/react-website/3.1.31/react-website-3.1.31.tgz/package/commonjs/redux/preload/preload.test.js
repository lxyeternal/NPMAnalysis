'use strict';

var _preload = require('./preload');

var _decorator = require('./decorator');

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

describe('@preload', function () {
	it('should collect preloaders from React Components', function () {
		var _ref, _ref2;

		var preload_1 = function preload_1() {};
		var preload_2 = function preload_2() {};
		var preload_3 = function preload_3() {};

		(0, _preload.collectPreloadersFromComponents)([null, (_ref = {}, _defineProperty(_ref, _decorator.PRELOAD_METHOD_NAME, [preload_1]), _defineProperty(_ref, _decorator.PRELOAD_OPTIONS_NAME, [{ client: true }]), _ref), undefined, (_ref2 = {}, _defineProperty(_ref2, _decorator.PRELOAD_METHOD_NAME, [preload_2, preload_3]), _defineProperty(_ref2, _decorator.PRELOAD_OPTIONS_NAME, [{ blocking: false }, { server: true }]), _ref2), {}]).should.deep.equal([[{
			preload: preload_1,
			options: { client: true }
		}], [{
			preload: preload_2,
			options: { blocking: false }
		}, {
			preload: preload_3,
			options: { server: true }
		}]]);
	});
});
//# sourceMappingURL=preload.test.js.map