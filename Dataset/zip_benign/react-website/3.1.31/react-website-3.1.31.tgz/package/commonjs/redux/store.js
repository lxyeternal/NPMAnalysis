'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports.default = _createStore;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _redux = require('redux');

var _logOnlyInProduction = require('redux-devtools-extension/logOnlyInProduction');

var _asynchronous = require('./middleware/asynchronous');

var _asynchronous2 = _interopRequireDefault(_asynchronous);

var _router = require('./middleware/router');

var _router2 = _interopRequireDefault(_router);

var _reducer = require('./preload/reducer');

var _reducer2 = _interopRequireDefault(_reducer);

var _getData = require('./preload/getData');

var _getData2 = _interopRequireDefault(_getData);

var _reducer3 = require('./translate/reducer');

var _reducer4 = _interopRequireDefault(_reducer3);

var _naming = require('./naming');

var _router3 = require('../router');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

function _createStore(settings, data, createHistoryProtocol, httpClient, options) {
	var reducers = settings.reducers,
	    reduxMiddleware = settings.reduxMiddleware,
	    reduxStoreEnhancers = settings.reduxStoreEnhancers,
	    reduxEventNaming = settings.reduxEventNaming,
	    http = settings.http,
	    onError = settings.onError,
	    getLocale = settings.getLocale,
	    codeSplit = settings.codeSplit,
	    meta = settings.meta,
	    showPreloadInitially = settings.showPreloadInitially;
	var routes = settings.routes;
	var server = options.server,
	    devtools = options.devtools,
	    stats = options.stats,
	    onNavigate = options.onNavigate,
	    getCookie = options.getCookie;

	// `routes` will be converted.

	var convertedRoutes = void 0;
	var getConvertedRoutes = function getConvertedRoutes() {
		return convertedRoutes;
	};

	// Add `@preload()` data hook.
	var getData = (0, _getData2.default)(codeSplit, server, onError, getLocale, getConvertedRoutes, getCookie);
	if (Array.isArray(routes)) {
		// If there's an error on client side in `setUpAndRender()` then it's called again.
		// And in that case `getData` is set and this error will be thrown.
		// if (routes[0].getData) {
		// 	throw new Error('[react-website] `getData` found on the root route')
		// }
		routes[0].getData = getData;
	} else {
		// Set `getData`.
		// If there's an error on client side in `setUpAndRender()` then it's called again.
		// And in that case `getData` is set and this error will be thrown.
		// if (routes.props.getData) {
		// 	throw new Error('[react-website] `getData` found on the root route')
		// }
		routes = _react2.default.cloneElement(routes, { getData: getData });
		// Convert `found` `<Route/>`s to a JSON structure.
		routes = (0, _router3.convertRoutes)(routes);
	}
	convertedRoutes = routes;

	// Redux middleware.
	// User may supply his own Redux middleware.
	var middleware = reduxMiddleware ? reduxMiddleware() : [];

	// Built-in middleware.
	middleware.push(
	// Asynchronous middleware (e.g. for HTTP Ajax calls).
	(0, _asynchronous2.default)(httpClient, reduxEventNaming, server, http.onError, http.errorState));

	if (!server) {
		middleware.push((0, _router2.default)(routes, codeSplit, onNavigate, stats, meta));
	}

	// Redux "store enhancers"
	var storeEnhancers = [];

	// User may supply his own Redux store enhancers.
	if (reduxStoreEnhancers) {
		storeEnhancers.push.apply(storeEnhancers, _toConsumableArray(reduxStoreEnhancers()));
	}

	storeEnhancers.push.apply(storeEnhancers, _toConsumableArray((0, _router3.createRouterStoreEnhancers)(routes, createHistoryProtocol, {
		basename: settings.basename
	})));

	// Redux middleware are applied in reverse order.
	// (which is counter-intuitive)
	storeEnhancers.push(_redux.applyMiddleware.apply(undefined, _toConsumableArray(middleware)));

	// Create Redux store.
	var store = getStoreEnhancersComposer(server, devtools).apply(undefined, storeEnhancers)(_redux.createStore)(createReducer(reducers, showPreloadInitially), data);

	// On the client side, add `hotReload()` function to the `store`.
	// (could just add this function to `window` but adding it to the `store` fits more)
	if (!server) {
		// `hotReload` helper function gives the web application means to hot reload its Redux reducers
		store.hotReload = function (reducers) {
			return store.replaceReducer(createReducer(reducers, showPreloadInitially));
		};
	}

	// Initialize `found`.
	(0, _router3.initializeRouter)(store);

	// Return the Redux store
	return store;
}

function createReducer(reducers, showPreloadInitially) {
	// Check for reserved reducer names.
	for (var _iterator = RESERVED_REDUCER_NAMES, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
		var _ref;

		if (_isArray) {
			if (_i >= _iterator.length) break;
			_ref = _iterator[_i++];
		} else {
			_i = _iterator.next();
			if (_i.done) break;
			_ref = _i.value;
		}

		var reducerName = _ref;

		if (reducers[reducerName]) {
			throw new Error('"' + reducerName + '" reducer name is reserved.');
		}
	}
	// Check for `ReduxModule` autogenerated event names conflicts.
	(0, _naming.checkForAutogeneratedEventNameCollision)(reducers);
	// Clone the object because it will be modified.
	reducers = _extends({}, reducers);
	// Add `found` reducer.
	reducers.found = _router3.foundReducer;
	// Add `@preload()` status reducer.
	reducers.preload = (0, _reducer2.default)(showPreloadInitially);
	// // Add `@translate()` reducer.
	// reducers.translation = translateReducer
	// Create the compound reducer.
	return (0, _redux.combineReducers)(reducers);
}

function getStoreEnhancersComposer(server, devtools) {
	// Redux DevTools aren't used on the server side
	if (server) {
		return _redux.compose;
	}

	// Custom behaviour
	if (devtools && devtools.compose) {
		return devtools.compose;
	}

	// With custom options
	if (devtools && devtools.options) {
		return (0, _logOnlyInProduction.composeWithDevTools)(devtools.options);
	}

	// Without custom options
	return _logOnlyInProduction.composeWithDevTools;
}

var RESERVED_REDUCER_NAMES = ['found', 'location', 'preload', 'translation'];
//# sourceMappingURL=store.js.map