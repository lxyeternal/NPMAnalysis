'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports.default = setUpAndRender;
exports.getState = getState;
exports.getHttpClient = getHttpClient;

var _render = require('../../client/render');

var _render2 = _interopRequireDefault(_render);

var _flags = require('../../client/flags');

var _cookies = require('../../client/cookies');

var _render3 = require('./render');

var _render4 = _interopRequireDefault(_render3);

var _HttpClient = require('../HttpClient');

var _HttpClient2 = _interopRequireDefault(_HttpClient);

var _normalize = require('../normalize');

var _normalize2 = _interopRequireDefault(_normalize);

var _store = require('../store');

var _store2 = _interopRequireDefault(_store);

var _instantBack = require('./instantBack');

var _client = require('../../router/client');

var _router = require('../../router');

var _initialPreload = require('./initialPreload');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// This function is what's gonna be called from the project's code on the client-side.
//
// There are two passes of client-side render happening here.
// React has the concept of "re-hydration" which demands that
// the initial client-side React rendering results be equal to
// the server-side React rendering results, character-by-character.
// Otherwise it complains.
// That's the reason why the application on client side first performs
// a "dummy" rendering without resolving any `@preload`s, just to complete
// the React "hydration" process, and only when the "hydration" process finishes
// does it perform the second pass of rendering the page,
// now resolving all client-side `@preload`s.
// Therefore, the first pass of `.render()` always happens with data missing
// if that data is loaded in "client-side only" `@preload`s.
// (that is, the `@preload`s configured with `{ client: true }`).
//
// If React "re-hydration" step didn't exist
// then the library would first execute all client-side preloads
// and only then would it render the application.
// That would be more intuitive and convenient for developers I guess.
//
function setUpAndRender(settings) {
	var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};


	settings = (0, _normalize2.default)(settings);

	var devtools = options.devtools,
	    stats = options.stats,
	    onNavigate = options.onNavigate,
	    onStoreCreated = options.onStoreCreated;

	// Redux store.

	var store = void 0;

	// Create HTTP client (Redux action creator `http` utility)
	var httpClient = (0, _HttpClient2.default)(settings, function () {
		return store;
	});
	// E.g. for WebSocket message handlers, since they only run on the client side.
	window._react_website_http_client = httpClient;

	// Reset "instant back" on page reload
	// since Redux state is cleared.
	// "instant back" chain is stored in `window.sessionStorage`
	// and therefore it survives page reload.
	(0, _instantBack.resetInstantBack)();

	// `showPreloadInitially` is handled in a special way
	// in case of client-side-only rendering.
	var showPreloadInitially = settings.showPreloadInitially;

	// The first pass of initial client-side render
	// is to render the markup which matches server-side one.
	// The second pass will be to render after resolving `getData`.
	if ((0, _flags.isServerSidePreloaded)()) {
		window._react_website_initial_prerender = true;
		window._react_website_skip_preload = true;
	}

	// Create Redux store
	store = (0, _store2.default)(_extends({}, settings, {
		showPreloadInitially: !(0, _flags.isServerSidePreloaded)() && showPreloadInitially ? false : showPreloadInitially
	}), getState(true), _client.createHistoryProtocol, httpClient, {
		devtools: devtools,
		stats: stats,
		onNavigate: onNavigate,
		getCookie: _cookies.getCookie
	});

	// `onStoreCreated(store)` is called here.
	//
	// For example, client-side-only applications
	// may capture this `store` as `window.store`
	// to call `bindActionCreators()` for all actions (globally).
	//
	// onStoreCreated: store => window.store = store
	//
	// import { bindActionCreators } from 'redux'
	// import actionCreators from './actions'
	// const boundActionCreators = bindActionCreators(actionCreators, window.store.dispatch)
	// export default boundActionCreators
	//
	// Not saying that this is even a "good" practice,
	// more like "legacy code", but still my employer
	// happened to have such binding, so I added this feature.
	// Still this technique cuts down on a lot of redundant "wiring" code.
	//
	if (onStoreCreated) {
		onStoreCreated(store);
	}

	// Render loading indicator in case of client-side-only rendering
	// because the main application React tree won't be rendered
	// until `@preload`s finish.
	var showingInitialPreload = false;
	if (!(0, _flags.isServerSidePreloaded)() && showPreloadInitially) {
		(0, _initialPreload.showInitialPreload)();
		showingInitialPreload = true;
	}

	// Render the page.
	// If it's a server-side rendering case then that will be the
	// first pass, without preloading data, just for `React.hydrate()`.
	// If it's a client-side rendering case then that will be the
	// first pass with preloading data.
	return (0, _render2.default)({
		container: settings.container,
		render: _render4.default,
		renderParameters: {
			store: store
		}
	}).then(function (result) {
		// Perform the second pass of initial client-side rendering.
		// The second pass resolves `getData` on `<Route/>`s.
		// (which means it resolves all client-side `@preload()`s)
		if ((0, _flags.isServerSidePreloaded)()) {
			store.dispatch((0, _router.redirect)(document.location));
		} else {
			// Hide the "initial" loading indicator.
			if (showingInitialPreload) {
				(0, _initialPreload.hideInitialPreload)();
			}
			// `RESOLVE_MATCH` is not being dispatched
			// for the first render for some reason.
			// https://github.com/4Catalyzer/found/issues/202
			// With server-side rendering enabled
			// initially there are two rendering passes
			// and therefore `RESOLVE_MATCH` does get dispatched
			// after the page is initialized and rendered.
			// With server-side rendering disabled
			// `RESOLVE_MATCH` does not get dispatched
			// therefore a custom `_RESOLVE_MATCH` event is
			// dispatched manually.
			store.dispatch({
				type: _router._RESOLVE_MATCH,
				payload: window._react_website_update_match_event_payload
			});
		}
		return result;
	}, function (error) {
		// Hide the "initial" loading indicator.
		if (showingInitialPreload) {
			(0, _initialPreload.hideInitialPreload)();
		}
		// Catches redirects from `@preload()`s,
		// redirects from `onError` and from `<Redirect/>` routes.
		if (error instanceof _router.RedirectException) {
			// Change current location.
			store.dispatch((0, _router.pushLocation)(error.location));
			// Reset all `react-website` flags.
			for (var key in window) {
				if (key.indexOf('_react_website_') === 0 && key !== '_react_website_locales') {
					window[key] = undefined;
				}
			}
			// Re-render.
			return setUpAndRender(settings, options);
		}
		throw error;
	});
}

// Gets Redux store state before "rehydration".
// In case someone needs to somehow modify
// Redux state before client-side render.
// (because the variable could be potentially renamed in future)
function getState(erase) {
	var state = window._redux_state;
	if (erase) {
		delete window._redux_state;
	}
	return state;
}

// Returns `http` utility on client side.
// Can be used in WebSocket message handlers,
// since they only run on the client side.
function getHttpClient() {
	return window._react_website_http_client;
}
//# sourceMappingURL=client.js.map