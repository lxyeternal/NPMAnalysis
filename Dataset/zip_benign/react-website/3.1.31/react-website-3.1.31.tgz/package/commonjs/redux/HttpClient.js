'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports.default = createHttpClient;

var _HttpClient = require('../HttpClient');

var _HttpClient2 = _interopRequireDefault(_HttpClient);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function createHttpClient(settings, getStore) {
	var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

	var on_before_send = void 0;
	var catch_to_retry = void 0;
	var get_access_token = void 0;

	// Add `getState()` to `http.onRequest()` parameters.
	if (settings.http.onRequest) {
		on_before_send = function on_before_send(request, parameters) {
			settings.http.onRequest(request, _extends({}, parameters, {
				getState: getStore().getState
			}));
		};
	}

	// Add `store` and `http` helpers to `http.catch`
	if (settings.http.catch) {
		catch_to_retry = function catch_to_retry(error, retryCount, helpers) {
			return settings.http.catch(error, retryCount, helpers);
			// {
			// 	...helpers,
			// 	store: getStore()
			// })
		};
	}

	// Add `store` helper to `authentication.accessToken`
	if (settings.authentication.accessToken) {
		get_access_token = function get_access_token(getCookie, helpers) {
			return settings.authentication.accessToken(_extends({}, helpers, {
				getCookie: getCookie,
				getState: getStore().getState
			}));
		};
	}

	return new _HttpClient2.default(_extends({
		on_before_send: on_before_send,
		catch_to_retry: catch_to_retry,
		get_access_token: get_access_token,
		transform_url: settings.http.transformURL,
		// `allowAbsoluteURLs` flag is deprecated.
		allow_absolute_urls: settings.http.allowAbsoluteURLs,
		parseDates: settings.parseDates,
		authentication_token_header: settings.authentication.header
	}, options));
}
//# sourceMappingURL=HttpClient.js.map