'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

exports.showInitialPreload = showInitialPreload;
exports.hideInitialPreload = hideInitialPreload;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactDom = require('react-dom');

var _reactDom2 = _interopRequireDefault(_reactDom);

var _Loading = require('../../components/Loading');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// In cases when the initial page immediately redirects
// to another page (for example, to a "not found" page),
// `node` and `ref` would get overwritten have they been
// simple variables and not arrays.
var nodes = [];
var refs = [];

var LoadingContainer = function (_React$Component) {
	_inherits(LoadingContainer, _React$Component);

	function LoadingContainer() {
		var _ref;

		var _temp, _this, _ret;

		_classCallCheck(this, LoadingContainer);

		for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
			args[_key] = arguments[_key];
		}

		return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = LoadingContainer.__proto__ || Object.getPrototypeOf(LoadingContainer)).call.apply(_ref, [this].concat(args))), _this), _this.state = {
			loading: true
		}, _temp), _possibleConstructorReturn(_this, _ret);
	}

	_createClass(LoadingContainer, [{
		key: 'render',
		value: function render() {
			var loading = this.state.loading;

			return _react2.default.createElement(_Loading.Loading, {
				initial: loading,
				immediate: loading,
				pending: loading });
		}
	}]);

	return LoadingContainer;
}(_react2.default.Component);

function showInitialPreload() {
	var node = document.createElement('div');
	nodes.push(node);
	// Will prepend `element` to `<body/>` (even if `<body/>` is empty).
	// https://stackoverflow.com/questions/2007357/how-to-set-dom-element-as-the-first-child
	document.body.insertBefore(node, document.body.firstChild);
	var setRef = function setRef(ref) {
		var index = nodes.indexOf(node);
		if (index >= 0) {
			refs[index] = ref;
		}
	};
	_reactDom2.default.render(_react2.default.createElement(LoadingContainer, { ref: setRef }), node);
}

function hideInitialPreload() {
	var node = nodes.pop();
	var ref = refs.pop();
	ref.setState({ loading: false }, function () {
		setTimeout(function () {
			_reactDom2.default.unmountComponentAtNode(node);
			document.body.removeChild(node);
		}, 160);
	});
}
//# sourceMappingURL=initialPreload.js.map