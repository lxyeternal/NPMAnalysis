'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

exports.default = function () {
	var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
	var event = arguments[1];

	switch (event.type) {
		case '@@react-website/translation':
			// Put translation data in state.
			var path = event.path,
			    translation = event.translation;

			return state;

		default:
			return state;
	}
};
//# sourceMappingURL=reducer.js.map