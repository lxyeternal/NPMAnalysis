'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports.default = _preload;
exports.collectPreloadersFromComponents = collectPreloadersFromComponents;

var _isEqual = require('lodash/isEqual');

var _isEqual2 = _interopRequireDefault(_isEqual);

var _router = require('../../router');

var _instantBack = require('../client/instantBack');

var _chain = require('./chain');

var _chain2 = _interopRequireDefault(_chain);

var _actions = require('./actions');

var _collect = require('../translate/collect');

var _collect2 = _interopRequireDefault(_collect);

var _decorator = require('./decorator');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _preload(location, previousLocation, routerArgs, codeSplit, server, getCookie, getLocale, dispatch, getState) {
	// If it's an instant "Back"/"Forward" navigation
	// then navigate to the page without preloading it.
	// (has been previously preloaded and is in Redux state)
	var _isInstantTransition = !server && location.action === 'POP' && previousLocation && (0, _instantBack.isInstantTransition)(previousLocation, location);

	// Preload status object.
	// `preloading` holds the cancellation flag for this navigation process.
	// (e.g. preloading `Promise` chain could be cancelled in case of a redirect)
	var preloading = {};

	// Can cancel previous preloading (on the client side)
	var previousPreloading = void 0;
	if (!server) {
		previousPreloading = window.__preloading_page;
		window.__preloading_page = preloading;
	}

	if (!server) {
		// If on the client side, then store the current pending navigation,
		// so that it can be cancelled when a new navigation process takes place
		// before the current navigation process finishes.
		//
		// If there's preceeding navigation pending,
		// then cancel that previous navigation.
		if (previousPreloading && previousPreloading.pending && !previousPreloading.cancelled) {
			previousPreloading.cancel();
		}
	}

	var routes = routerArgs.routes,
	    routeParams = routerArgs.routeParams,
	    routeIndices = routerArgs.routeIndices,
	    params = routerArgs.params;

	var components = routes.map(function (_) {
		return _.Component;
	});

	// Instrument `dispatch`.
	// `dispatch` for server side `throw`s a special "redirect error" on redirect.
	// `dispatch` for client side cancels current `@preload()` on redirect.
	dispatch = instrumentDispatch(dispatch, server, preloading);

	// Preload all the required data for this route (page)
	var preload = void 0;
	if (!_isInstantTransition) {
		var _routes = routes;
		var _components = components;

		// Client-side optimization.
		// Skips `@preloads()` for `<Route/>`s that didn't change as a result of navigation.
		if (!server) {
			if (codeSplit) {
				_routes = filterByChangedRoutes(_routes, routeIndices, routeParams);
			} else {
				_components = filterByChangedRoutes(_components, routeIndices, routeParams);
			}
			window._react_website_previous_routes = routeIndices;
			window._react_website_previous_routes_parameters = routeParams;
		}

		// Get all `preload` methods on the React-Router component chain
		var preloaders = codeSplit ? collectPreloadersFromRoutes(_routes) : collectPreloadersFromComponents(_components);

		var isInitialClientSidePreload = !server && !previousLocation;

		preload = (0, _chain2.default)(preloaders, server, isInitialClientSidePreload, getState, dispatch, location, params, getCookie, preloading);
	}

	// Load translations (if any).
	var loadTranslation = void 0;
	if (getLocale) {
		loadTranslation = (0, _collect2.default)(components, routes, routeIndices, codeSplit, getLocale(getState()), dispatch);
	}

	// Combine promises.
	var promise = void 0;
	if (preload) {
		if (loadTranslation) {
			promise = Promise.all([preload(), loadTranslation()]);
		} else {
			promise = preload();
		}
	} else if (loadTranslation) {
		promise = loadTranslation();
	}

	// If nothing to preload, just move to the next middleware
	if (!promise) {
		return Promise.resolve();
	}

	preloading.pending = true;

	// Preloading process cancellation
	preloading.cancel = function () {
		preloading.cancelled = true;
		// If `bluebird` is used,
		// and promise cancellation has been set up,
		// then cancel the `Promise`.
		// http://bluebirdjs.com/docs/api/cancellation.html
		if (promise.cancel) {
			// `.catch()` is to suppress "Uncaught promise rejection" errors
			promise.catch(function () {
				return {};
			}).cancel();
		}
	};

	return promise.then(
	// Navigate to the new page
	function () {
		preloading.pending = false;
		// If this navigation process was cancelled
		// before @preload() finished its work,
		// then don't take any further steps on this cancelled navigation.
		if (preloading.cancelled) {
			// Return `false` out of the `Promise`
			// indicating that the navigation was cancelled.
			return false;
		}
	}, function (error) {
		// If this navigation process was cancelled
		// before @preload() finished its work,
		// then don't take any further steps on this cancelled navigation.
		if (!preloading.cancelled) {
			if (!server) {
				preloading.error = error;
			}
			// Page loading indicator could listen for this event
			dispatch({ type: _actions.PRELOAD_FAILED, error: error });
		}
		// Update preload status object
		preloading.pending = false;
		// May be a server-side special "redirect" error.
		throw error;
	});
}

// Instrument `dispatch`.
// `dispatch` for server side `throw`s a special "redirect error" on redirect.
// `dispatch` for client side cancels current `@preload()` on redirect.
function instrumentDispatch(dispatch, server, preloading) {
	return function (event) {
		switch (event.type) {
			// In case of navigation from @preload().
			case _router.REDIRECT_ACTION_TYPE:
			case _router.GOTO_ACTION_TYPE:
				// Discard the currently ongoing preloading.
				// (if some kind of a `bluebird` is used)
				if (preloading.cancel) {
					preloading.cancel();
				}
				// if (!server && window._react_website_skip_preload_update_location) {
				// 	console.warn('Looks like you\'re calling `dispatch(pushLocation())` or `dispatch(replaceLocation())` inside `@preload()`. Call them in `@onPageLoaded()` instead.')
				// }
				throw new _router.RedirectException(event.payload);
			default:
				// Proceed normally.
				return dispatch(event);
		}
	};
}

// Finds all `preload` (or `preload_deferred`) methods
// (they will be executed in parallel).
//
// @parameter components - `react-router` matched components
//
// @returns an array of `component_preloaders`.
// `component_preloaders` is an array of all
// `@preload()`s for a particular React component:
// objects having shape `{ preload(), options }`.
// Therefore the returned value is an array of arrays.
//
function collectPreloadersFromComponents(components) {
	// Find all static `preload` methods on the route component chain
	return components
	// Some wrapper `<Route/>`s can have no `component`.
	// Select all components having `@preload()`.
	.filter(function (component) {
		return component && component[_decorator.PRELOAD_METHOD_NAME];
	})
	// Extract `@preload()` functions and their options.
	.map(function (component) {
		return component[_decorator.PRELOAD_METHOD_NAME].map(function (preload, i) {
			return {
				preload: preload,
				options: component[_decorator.PRELOAD_OPTIONS_NAME][i]
			};
		});
	});
	// // Flatten `@preload()` functions and their options.
	// .reduce((all, preload_and_options) => all.concat(preload_and_options), [])
}

function collectPreloadersFromRoutes(routes) {
	// Find all preload properties on the route chain.
	return routes.map(function (route) {
		var preloads = [];
		if (route.preload) {
			var preload = route.preload;
			preloads.push({
				preload: preload,
				options: preload.options || {}
			});
		}
		if (route.preloadClient) {
			var _preload2 = route.preloadClient;
			preloads.push({
				preload: _preload2,
				options: _extends({}, _preload2.options, {
					client: true
				})
			});
		}
		if (route.preloadClientAfter) {
			var _preload3 = route.preloadClientAfter;
			preloads.push({
				preload: _preload3,
				options: _extends({}, _preload3.options, {
					client: true,
					blockingSibling: true
				})
			});
		}
		return preloads;
	}).filter(function (_) {
		return _.length > 0;
	});
	// Flatten the array.
	// .reduce((all, preload_and_options) => all.concat(preload_and_options), [])
}

// A minor optimization for skipping `@preload()`s
// for those parent `<Route/>`s which haven't changed
// as a result of a client-side navigation.
//
// On client side:
//
// Take the previous route components
// (along with their parameters)
// and the next route components
// (along with their parameters),
// and compare them side-by-side
// filtering out the same top level components
// (both having the same component classes
//  and having the same parameters).
//
// Therefore @preload() methods could be skipped
// for those top level components which remain
// the same (and in the same state).
// This would be an optimization.
//
// (e.g. the main <Route/> could be @preload()ed only once - on the server side)
//
// At the same time, at least one component should be preloaded:
// even if navigating to the same page it still kinda makes sense to reload it.
// (assuming it's not an "anchor" hyperlink navigation)
//
// Parameters for each `<Route/>` component can be found using this helper method:
// https://github.com/ReactTraining/react-router/blob/master/modules/getRouteParams.js
//
// Also, GET query parameters would also need to be compared, I guess.
// But, I guess, it would make sense to assume that GET parameters
// only affect the last `<Route/>` component in the chain.
// And, in general, GET query parameters should be avoided,
// but that's not the case for example with search forms.
// So here we assume that GET query parameters only
// influence the last `<Route/>` component in the chain
// which is gonna be reloaded anyway.
//
function filterByChangedRoutes(filtered, routes, routeParams) {
	var filteredByChangedRoutes = filtered;

	if (window._react_website_previous_routes) {
		var previous_routes = window._react_website_previous_routes;
		var previous_routes_parameters = window._react_website_previous_routes_parameters;

		var i = 0;
		while (i < routes.length - 1 && previous_routes[i] === routes[i] && (0, _isEqual2.default)(previous_routes_parameters[i], routeParams[i])) {
			i++;
		}

		filteredByChangedRoutes = filteredByChangedRoutes.slice(i);
	}

	return filteredByChangedRoutes;
}
//# sourceMappingURL=preload.js.map