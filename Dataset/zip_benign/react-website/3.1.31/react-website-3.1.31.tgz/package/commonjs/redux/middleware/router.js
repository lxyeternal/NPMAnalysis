'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports.default = routerMiddleware;

var _router = require('../../router');

var _meta = require('../../meta/meta');

var _location = require('../../location');

var _onPageLoaded = require('../client/onPageLoaded');

var _actions = require('../preload/actions');

var _instantBack = require('../client/instantBack');

var _flags = require('../../client/flags');

// Any events listened to here are being dispatched on client side.
function routerMiddleware(routes, codeSplit, onNavigate, reportStats, defaultMeta) {
	var startedAt = void 0;
	var previousLocation = void 0;
	var previousRouteIndices = void 0;

	return function (_ref) {
		var dispatch = _ref.dispatch,
		    getState = _ref.getState;

		return function (next) {
			return function (event) {
				// Skip the first pass of the initial client-side render.
				// for the case when server-side rendering is used.
				if (window._react_website_initial_prerender) {
					return next(event);
				}

				var location = event.payload && event.payload.location;
				var routeIndices = event.payload && event.payload.routeIndices;

				switch (event.type) {
					case _router.UPDATE_MATCH:
						// A workaround for `found` router bug:
						// https://github.com/4Catalyzer/found/issues/239
						// Skip `@preload()` and other stuff for anchor link navigation.
						if (previousLocation && (0, _location.shouldSkipPreloadForNavigation)(previousLocation, location)) {
							// I guess this workaround won't work with `codeSplit: true`
							// because it doesn't use the global `getData` preloader.
							if (!codeSplit) {
								break;
							}
						}

						// Store `event.payload` for the future `_UPDATE_MATCH` event.
						if (!window._react_website_router_rendered && !(0, _flags.isServerSidePreloaded)()) {
							window._react_website_update_match_event_payload = event.payload;
						}

						// Measure `@preload()` time.
						startedAt = Date.now();

						// If it's an instant "Back"/"Forward" navigation
						// then navigate to the page without preloading it.
						// (has been previously preloaded and is in Redux state)
						var _isInstantTransition = location.action === 'POP' && previousLocation && (0, _instantBack.isInstantTransition)(previousLocation, location);

						// Set the flag for `wasInstantNavigation()`.
						(0, _instantBack.setInstantNavigationFlag)(_isInstantTransition);

						// Indicates whether an `instantBack` `<Link/>` has been clicked.
						// (or if `goto()` has been called with `instantBack: true` option)
						var instantBack = window._react_website_instant_back_navigation;

						// Update instant back navigation chain.
						if (instantBack) {
							// Stores "current" (soon to be "previous") location
							// in "instant back chain", so that if "Back" is clicked
							// then such transition could be detected as "should be instant".
							(0, _instantBack.addInstantBack)(location, previousLocation, routeIndices, previousRouteIndices);
						} else if (!_isInstantTransition) {
							// If current transition is not "instant back" and not "instant"
							// then reset the whole "instant back" chain.
							// Only a consequitive "instant back" navigation chain
							// preserves the ability to instantly navigate "Back".
							// Once a regular navigation takes place
							// all previous "instant back" possibilities are discarded.
							(0, _instantBack.resetInstantBack)();
						}

						// Set the flag for `isInstantBackAbleNavigation()`.
						// `instantBack` is for a "forward" instant-back-able navigation.
						// `_isInstantTransition` is for a "backwards" instant-back-able navigation.
						if (instantBack || _isInstantTransition) {
							window._react_website_is_instant_back_able_navigation = true;
						}

						// // `RESOLVE_MATCH` is not being emitted
						// // for the first render for some reason.
						// // https://github.com/4Catalyzer/found/issues/202
						// const isFirstRender = !previousLocation
						// if (isFirstRender) {
						// 	updateMetaTags(
						// 		routeIndices,
						// 		getState(),
						// 		{
						// 			routes,
						// 			codeSplit,
						// 			defaultMeta
						// 		}
						// 	)
						// } else {
						// 	// Show page loading indicator.
						// 	dispatch({ type: PRELOAD_STARTED })
						// }

						// Show page loading indicator.
						if (!(0, _flags.isServerSidePreloaded)() && !window._react_website_router_rendered) {
							// Don't show page loading indicator
							// because it's already being shown manually.
						} else {
							// Show page loading indicator.
							dispatch({ type: _actions.PRELOAD_STARTED });
						}

						break;

					// `RESOLVE_MATCH` is not being dispatched
					// for the first render for some reason.
					// https://github.com/4Catalyzer/found/issues/202
					// With server-side rendering enabled
					// initially there are two rendering passes
					// and therefore `RESOLVE_MATCH` does get dispatched
					// after the page is initialized and rendered.
					// With server-side rendering disabled
					// `RESOLVE_MATCH` does not get dispatched
					// therefore a custom `_RESOLVE_MATCH` event is
					// dispatched manually.
					case _router.RESOLVE_MATCH:
					case _router._RESOLVE_MATCH:
						// A workaround for `found` router bug:
						// https://github.com/4Catalyzer/found/issues/239
						// Skip `@preload()` and other stuff for anchor link navigation.
						if (previousLocation && (0, _location.shouldSkipPreloadForNavigation)(previousLocation, location)) {
							// I guess this workaround won't work with `codeSplit: true`
							// because it doesn't use the global `getData` preloader.
							if (!codeSplit) {
								break;
							}
						}

						// `previousLocation` is only used for "instant back" navigation.
						// Therefore it can be skipped in case of anchor link navigation.
						previousLocation = location;
						previousRouteIndices = routeIndices;

						if (!window._react_website_router_rendered) {
							window._react_website_router_rendered = true;
						}

						// Call `@onPageLoaded()`.
						if (!codeSplit) {
							var routeChain = (0, _router.getRoutesByPath)(routeIndices, routes);
							var pageRoute = routeChain[routeChain.length - 1];
							// Routes don't have `.Component` property
							// set when using `codeSplit` feature.
							var onPageLoaded = pageRoute.Component[_onPageLoaded.ON_PAGE_LOADED_METHOD_NAME];
							if (onPageLoaded) {
								onPageLoaded({ dispatch: dispatch, getState: getState, location: location });
							}
						}

						// Update `<meta/>`.
						updateMetaTags(routeIndices, getState(), {
							routes: routes,
							codeSplit: codeSplit,
							defaultMeta: defaultMeta
						});

						if (onNavigate) {
							onNavigate((0, _location.getLocationUrl)(location), location, { dispatch: dispatch, getState: getState });
						}

						// Reset the flag for `isInstantBackAbleNavigation()`.
						window._react_website_is_instant_back_able_navigation = false;

						// Report preloading time.
						// This preloading time will be longer then
						// the server-side one, say, by 10 milliseconds,
						// probably because the web browser making
						// an asynchronous HTTP request is slower
						// than the Node.js server making a regular HTTP request.
						// Also this includes network latency
						// for a particular website user, etc.
						// So this `preload` time doesn't actually describe
						// the server-side performance.
						if (reportStats) {
							reportStats({
								url: (0, _location.getLocationUrl)(location),
								// Concatenated `react-router` route string.
								// E.g. "/user/:user_id/post/:post_id"
								route: (0, _router.getRoutePath)((0, _router.getRoutesByPath)(routeIndices, routes)),
								time: {
									preloadAndRender: Date.now() - startedAt
								}
							});
						}

						// Hide page loading indicator.
						dispatch({ type: _actions.PRELOAD_FINISHED });

						// Report preload time in console for debugging.
						if (Date.now() - startedAt > 30) {
							console.log('[react-website] "' + location.pathname + '" loaded and rendered in ' + (Date.now() - startedAt) + ' ms');
						}

						break;
				}

				return next(event);
			};
		};
	};
}

function updateMetaTags(routeIndices, state, _ref2) {
	var routes = _ref2.routes,
	    codeSplit = _ref2.codeSplit,
	    defaultMeta = _ref2.defaultMeta;

	var routeChain = (0, _router.getRoutesByPath)(routeIndices, routes);
	// Get `<meta/>` for the route.
	var meta = codeSplit ? (0, _meta.getCodeSplitMeta)(routeChain, state) : (0, _meta.getComponentsMeta)(routeChain.map(function (_) {
		return _.Component;
	}), state);
	meta = (0, _meta.mergeMeta)(meta);
	meta = _extends({}, defaultMeta, meta);
	// Update `<meta/>`.
	(0, _meta.updateMeta)(meta);
}
//# sourceMappingURL=router.js.map