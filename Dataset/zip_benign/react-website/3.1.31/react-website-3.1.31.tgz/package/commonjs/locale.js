'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.getLanguageFromLocale = getLanguageFromLocale;
function getLanguageFromLocale(locale) {
	// `ru-RU` -> `ru`.
	// "IETF language tags".
	// https://en.wikipedia.org/wiki/IETF_language_tag
	var dashIndex = locale.indexOf('-');
	if (dashIndex >= 0) {
		return locale.slice(0, dashIndex);
	}
	return locale;
}
//# sourceMappingURL=locale.js.map