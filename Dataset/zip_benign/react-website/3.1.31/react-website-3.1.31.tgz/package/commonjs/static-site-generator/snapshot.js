'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.snapshot = undefined;

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _getIterator2 = require('babel-runtime/core-js/get-iterator');

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _extends2 = require('babel-runtime/helpers/extends');

var _extends3 = _interopRequireDefault(_extends2);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

// Snapshots all pages (URLs).
var snapshot = exports.snapshot = function () {
	var _ref3 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(_ref2) {
		var host = _ref2.host,
		    port = _ref2.port,
		    pages = _ref2.pages,
		    outputPath = _ref2.outputPath,
		    transformContent = _ref2.transformContent;
		var snapshotProgress;
		return _regenerator2.default.wrap(function _callee2$(_context2) {
			while (1) {
				switch (_context2.prev = _context2.next) {
					case 0:
						// Could be `null`, not just `undefined`.
						if (!pages) {
							pages = [];
						}

						// Add the "base" page which is an empty page
						// which will be rendered in user's browser on client side.
						// This should be the "fallback" page.
						pages.unshift('/react-website-base');

						// The progress meter for the website snapshotting process.
						snapshotProgress = new _progress2.default(' Snapshotting [:bar] :total :percent :etas', {
							complete: '=',
							incomplete: ' ',
							width: 50,
							total: pages.length
						});

						// Start the website snapshotting process

						_context2.next = 5;
						return snapshotPages(host, port, pages, outputPath, transformContent, function () {
							return snapshotProgress.tick();
						});

					case 5:

						// Move `./react-website-base/index.html` to `./base.html`.
						_fsExtra2.default.moveSync(_path2.default.join(outputPath, 'react-website-base/index.html'), _path2.default.join(outputPath, 'base.html'));
						_fsExtra2.default.removeSync(_path2.default.join(outputPath, 'react-website-base'));

					case 7:
					case 'end':
						return _context2.stop();
				}
			}
		}, _callee2, this);
	}));

	return function snapshot(_x2) {
		return _ref3.apply(this, arguments);
	};
}();

var snapshotPages = function () {
	var _ref4 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee3(host, port, pages, outputPath, transformContent, tick) {
		var _iterator, _isArray, _i, _ref5, page;

		return _regenerator2.default.wrap(function _callee3$(_context3) {
			while (1) {
				switch (_context3.prev = _context3.next) {
					case 0:
						_context3.next = 2;
						return remove(outputPath);

					case 2:
						_iterator = pages, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : (0, _getIterator3.default)(_iterator);

					case 3:
						if (!_isArray) {
							_context3.next = 9;
							break;
						}

						if (!(_i >= _iterator.length)) {
							_context3.next = 6;
							break;
						}

						return _context3.abrupt('break', 19);

					case 6:
						_ref5 = _iterator[_i++];
						_context3.next = 13;
						break;

					case 9:
						_i = _iterator.next();

						if (!_i.done) {
							_context3.next = 12;
							break;
						}

						return _context3.abrupt('break', 19);

					case 12:
						_ref5 = _i.value;

					case 13:
						page = _ref5;
						_context3.next = 16;
						return snapshotPage(host, port, page, outputPath, transformContent);

					case 16:
						tick();

					case 17:
						_context3.next = 3;
						break;

					case 19:
					case 'end':
						return _context3.stop();
				}
			}
		}, _callee3, this);
	}));

	return function snapshotPages(_x3, _x4, _x5, _x6, _x7, _x8) {
		return _ref4.apply(this, arguments);
	};
}();

var snapshotPage = function () {
	var _ref6 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee4(host, port, page, outputPath, transformContent) {
		var url, targetStatusCode, _url, _ref7, status, content;

		return _regenerator2.default.wrap(function _callee4$(_context4) {
			while (1) {
				switch (_context4.prev = _context4.next) {
					case 0:
						url = page;
						targetStatusCode = 200;


						if (typeof page !== 'string' && page.status) {
							url = page.url;
							targetStatusCode = page.status;
						}

						_url = 'http://' + host + ':' + port + url;
						_context4.next = 6;
						return (0, _download2.default)(_url);

					case 6:
						_ref7 = _context4.sent;
						status = _ref7.status;
						content = _ref7.content;

						if (!(status !== targetStatusCode)) {
							_context4.next = 11;
							break;
						}

						throw new Error('Expected ' + targetStatusCode + ' HTTP status code for "' + _url + '". Got ' + status + '.');

					case 11:

						_fsExtra2.default.outputFileSync(_path2.default.join(outputPath, url, '/index.html'), transformContent ? transformContent(content) : content);

					case 12:
					case 'end':
						return _context4.stop();
				}
			}
		}, _callee4, this);
	}));

	return function snapshotPage(_x9, _x10, _x11, _x12, _x13) {
		return _ref6.apply(this, arguments);
	};
}();

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _progress = require('progress');

var _progress2 = _interopRequireDefault(_progress);

var _download = require('./download');

var _download2 = _interopRequireDefault(_download);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Snapshots all pages (URLs).
exports.default = function () {
	var _ref = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee(options) {
		return _regenerator2.default.wrap(function _callee$(_context) {
			while (1) {
				switch (_context.prev = _context.next) {
					case 0:
						return _context.abrupt('return', snapshot((0, _extends3.default)({}, options, {
							transformContent: function transformContent(content) {
								if (options.transformContent) {
									content = options.transformContent(content);
								}
								if (options.reloadData) {
									content = addReloadDataFlag(content);
								}
								return content;
							}
						})));

					case 1:
					case 'end':
						return _context.stop();
				}
			}
		}, _callee, this);
	}));

	function snapshotWebsite(_x) {
		return _ref.apply(this, arguments);
	}

	return snapshotWebsite;
}();

function remove(path) {
	return new _promise2.default(function (resolve, reject) {
		return _fsExtra2.default.remove(path, function (error) {
			return error ? reject(error) : resolve();
		});
	});
}

function addReloadDataFlag(content) {
	var headEndsAt = content.indexOf('</head>');
	if (headEndsAt < 0) {
		throw new Error('</head> not found');
	}
	return content.slice(0, headEndsAt) + '<script> window._react_website_reload_data = true </script>' + content.slice(headEndsAt);
}
//# sourceMappingURL=snapshot.js.map