'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

exports.default = walk;

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Returns the paths to all files in a directory.
 * (walks the subdirectory tree recursively).
 */
function walk(dir) {
  return new _promise2.default(function (resolve, reject) {
    _fs2.default.readdir(dir, function (error, files) {
      if (error) {
        return reject(error);
      }
      _promise2.default.all(files.map(function (file) {
        return new _promise2.default(function (resolve, reject) {
          var filepath = _path2.default.join(dir, file);
          _fs2.default.stat(filepath, function (error, stats) {
            if (error) {
              return reject(error);
            }
            if (stats.isDirectory()) {
              walk(filepath).then(resolve);
            } else if (stats.isFile()) {
              resolve(filepath);
            }
          });
        });
      })).then(function (foldersContents) {
        resolve(foldersContents.reduce(function (all, folderContents) {
          return all.concat(folderContents);
        }, []));
      });
    });
  });
}
//# sourceMappingURL=walk.js.map