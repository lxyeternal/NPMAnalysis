'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _progress = require('progress');

var _progress2 = _interopRequireDefault(_progress);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// const green = '\u001b[42m \u001b[0m'

exports.default = function () {
	var _ref = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee(filesPath, upload) {
		var progressBar;
		return _regenerator2.default.wrap(function _callee$(_context) {
			while (1) {
				switch (_context.prev = _context.next) {
					case 0:
						progressBar = void 0;
						_context.next = 3;
						return upload(filesPath, {
							started: function started(total) {
								progressBar = new _progress2.default('  Uploading [:bar] :percent :etas', {
									// complete : green,
									complete: '=',
									incomplete: ' ',
									width: 50,
									total: 100
								});
							},
							progress: function progress(value) {
								progressBar.update(value);
							}
						});

					case 3:
					case 'end':
						return _context.stop();
				}
			}
		}, _callee, this);
	}));

	function upload_website(_x, _x2) {
		return _ref.apply(this, arguments);
	}

	return upload_website;
}();
//# sourceMappingURL=upload.js.map