'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.default = undefined;

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

exports.get_cookie_key_value = get_cookie_key_value;

var _parseDates = require('./parseDates');

var _parseDates2 = _interopRequireDefault(_parseDates);

var _helpers = require('./helpers');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

// Performs HTTP requests
var HttpRequest = function () {
	function HttpRequest(method, url, data, options) {
		_classCallCheck(this, HttpRequest);

		var agent = options.agent,
		    headers = options.headers,
		    parse_json_dates = options.parse_json_dates,
		    new_cookies_added = options.new_cookies_added,
		    on_response_headers = options.on_response_headers;


		this.new_cookies_added = new_cookies_added;

		// Create Http request.
		this.request = agent[method](url);

		var isMultipartFormData = void 0;

		// Attach data to the outgoing HTTP request
		if (data) {
			switch (method) {
				case 'get':
					this.request.query(data);
					break;

				case 'post':
				case 'put':
				case 'patch':
				case 'head':
				case 'options':
					isMultipartFormData = has_binary_data(data);
					this.request.send(isMultipartFormData ? construct_form_data(data) : data);
					break;

				case 'delete':
					throw new Error('"data" supplied for HTTP DELETE request: ' + JSON.stringify(data));

				default:
					throw new Error('Unknown HTTP method: ' + method);
			}
		}

		// Apply HTTP headers
		this.request.set(headers);

		// `superagent` is supposed to set `Content-Type` automatically
		// when calling `.send()` but it doesn't get called for GET/HEAD/DELETE HTTP requests.
		// Also, when `.send()` is called with `FormData` it also doesn't set
		// any `Content-Type` HTTP header. So setting it here manually.
		if (!this.request._header['content-type']) {
			if (isMultipartFormData) {
				this.request.type('multipart/form-data');
			} else {
				this.request.type('application/json');
			}
		}

		// `true`/`false`
		this.parse_json_dates = parse_json_dates;

		// Can be used for examining HTTP response headers
		// (e.g. Amazon S3 file upload)
		this.on_response_headers = on_response_headers;
	}

	// Sets `Authorization: Bearer ${token}` in HTTP request header


	_createClass(HttpRequest, [{
		key: 'add_authentication',
		value: function add_authentication(authentication_token_header, authentication, get_access_token, getCookie, url, path) {
			var token = void 0;

			if (typeof authentication === 'string') {
				token = authentication;
			} else if (get_access_token) {
				token = get_access_token(getCookie, {
					url: url,
					// `path` is deprecated, use `requestedURL` instead.
					path: path,
					requestedURL: path
				});
			}

			if (token && authentication !== false) {
				this.request.set(authentication_token_header || 'Authorization', 'Bearer ' + token);
			}
		}

		// Server side only
		// (copies user authentication cookies to retain session specific data)

	}, {
		key: 'add_cookies',
		value: function add_cookies(cookies, set_cookies) {
			// Merge the initial HTTP request `cookies` and `set_cookies` (a `Set`)
			if (set_cookies.size > 0) {
				cookies = _extends({}, cookies);

				for (var _iterator = set_cookies, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
					var _ref;

					if (_isArray) {
						if (_i >= _iterator.length) break;
						_ref = _iterator[_i++];
					} else {
						_i = _iterator.next();
						if (_i.done) break;
						_ref = _i.value;
					}

					var cookie_raw = _ref;

					var _get_cookie_key_value = get_cookie_key_value(cookie_raw),
					    _get_cookie_key_value2 = _slicedToArray(_get_cookie_key_value, 2),
					    key = _get_cookie_key_value2[0],
					    value = _get_cookie_key_value2[1];

					cookies[key] = value;
				}
			}

			if (Object.keys(cookies).length > 0) {
				this.request.set('cookie', Object.keys(cookies).map(function (key) {
					return key + '=' + cookies[key];
				}).join(';'));
			}
		}

		// File upload progress metering
		// https://developer.mozilla.org/en/docs/Web/API/XMLHttpRequest/Using_XMLHttpRequest

	}, {
		key: 'progress',
		value: function progress(_progress) {
			this.request.on('progress', function (event) {
				if (event.direction !== 'upload') {
					// Only interested in file upload progress metering
					return;
				}

				if (!event.lengthComputable) {
					// Unable to compute progress information since the total size is unknown
					return;
				}

				_progress(event.percent, event);
			});
		}
	}, {
		key: 'send',
		value: function send() {
			var _this = this;

			return new Promise(function (resolve, reject) {
				_this.request.end(function (error, response) {
					if (response) {
						if (_this.on_response_headers) {
							_this.on_response_headers(response.headers);
						}

						// (on the server)
						// If any cookies were set then track them (for later).
						// `response.headers['set-cookie']` is an array of `String`s.
						if (response.headers['set-cookie']) {
							_this.new_cookies_added(response.headers['set-cookie']);
						}
					}

					if (error) {
						// Infer additional `error` properties from the HTTP response
						if (response) {
							_this.populate_error_data(error, response);
						}

						return reject(error);
					}

					// If HTTP response status is "204 - No content"
					// (e.g. PUT, DELETE)
					// then resolve with an empty result.
					if (response.statusCode === 204) {
						return resolve();
					}

					resolve(_this.get_response_data(response));
				});
			});
		}
	}, {
		key: 'populate_error_data',
		value: function populate_error_data(error, response) {
			// Set `error.status` to HTTP response status code
			error.status = response.statusCode;

			var response_data = this.get_response_data(response);

			switch (response.type) {
				// Set error `data` from response body,
				case 'application/json':
				// http://jsonapi.org/
				case 'application/vnd.api+json':
					error.data = response_data;

					// Set the more meaningful message for the error (if available)
					if (error.data.message) {
						error.message = error.data.message;
					}

					break;

				// If the HTTP response was not a JSON object,
				// but rather a text or an HTML page,
				// then include that information in the `error`
				// for future reference (e.g. easier debugging).

				case 'text/plain':
					error.message = response_data;
					break;

				case 'text/html':
					error.html = response_data;

					// Recover the original error message (if any)
					if (response.headers['x-error-message']) {
						error.message = response.headers['x-error-message'];
					}

					// Recover the original error stack trace (if any)
					if (response.headers['x-error-stack-trace']) {
						error.stack = JSON.parse(response.headers['x-error-stack-trace']);
					}

					break;
			}
		}
	}, {
		key: 'get_response_data',
		value: function get_response_data(response) {
			switch (response.type) {
				case 'application/json':
				// http://jsonapi.org/
				case 'application/vnd.api+json':
					if (this.parse_json_dates) {
						return (0, _parseDates2.default)(response.body);
					}
					return response.body;

				// case 'text/plain':
				// case 'text/html':
				default:
					return response.text;
			}
		}
	}]);

	return HttpRequest;
}();

// Returns `[key, value]` from a raw cookie string


exports.default = HttpRequest;
function get_cookie_key_value(cookie_raw) {
	var semicolon_index = cookie_raw.indexOf(';');

	if (semicolon_index >= 0) {
		cookie_raw = cookie_raw.slice(0, semicolon_index);
	}

	return cookie_raw.trim().split('=');
}

function construct_form_data(data) {
	// Just in case (who knows)
	if (typeof FormData === 'undefined') {
		// Silent fallback
		return data;
	}

	var form_data = new FormData();

	for (var _iterator2 = Object.keys(data), _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
		var _ref2;

		if (_isArray2) {
			if (_i2 >= _iterator2.length) break;
			_ref2 = _iterator2[_i2++];
		} else {
			_i2 = _iterator2.next();
			if (_i2.done) break;
			_ref2 = _i2.value;
		}

		var key = _ref2;

		var parameter = data[key];

		// For an `<input type="file"/>` DOM element just take its `.files`
		if (typeof HTMLInputElement !== 'undefined' && parameter instanceof HTMLInputElement) {
			parameter = parameter.files;
		}

		// For a `FileList` parameter (e.g. `multiple` file upload),
		// iterate the `File`s in the `FileList`
		// and add them to the form data as a `[File]` array.
		if (typeof FileList !== 'undefined' && parameter instanceof FileList) {
			var i = 0;
			while (i < parameter.length) {
				form_data.append(key, parameter[i]);
				i++;
			}
			continue;
		}

		form_data.append(key, parameter);
	}

	return form_data;
}

function has_binary_data(data) {
	if (!(0, _helpers.isObject)(data)) {
		return false;
	}

	for (var _iterator3 = Object.keys(data), _isArray3 = Array.isArray(_iterator3), _i3 = 0, _iterator3 = _isArray3 ? _iterator3 : _iterator3[Symbol.iterator]();;) {
		var _ref3;

		if (_isArray3) {
			if (_i3 >= _iterator3.length) break;
			_ref3 = _iterator3[_i3++];
		} else {
			_i3 = _iterator3.next();
			if (_i3.done) break;
			_ref3 = _i3.value;
		}

		var key = _ref3;

		var parameter = data[key];

		if (typeof HTMLInputElement !== 'undefined' && parameter instanceof HTMLInputElement) {
			return true;
		}

		if (typeof FileList !== 'undefined' && parameter instanceof FileList) {
			return true;
		}

		// `File` is a subclass of `Blob`
		// https://developer.mozilla.org/en-US/docs/Web/API/Blob
		if (typeof Blob !== 'undefined' && parameter instanceof Blob) {
			return true;
		}
	}
}
//# sourceMappingURL=HttpRequest.js.map