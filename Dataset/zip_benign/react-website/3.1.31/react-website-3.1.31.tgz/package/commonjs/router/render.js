'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _createRender = require('found/lib/createRender');

var _createRender2 = _interopRequireDefault(_createRender);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Seems to be ignored.
var render = (0, _createRender2.default)({
	renderError: function renderError(_ref) {
		var error = _ref.error;
		return _react2.default.createElement(
			'div',
			null,
			'Error'
		);
	}
});

exports.default = render;
//# sourceMappingURL=render.js.map