'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.createRouterElement = createRouterElement;
exports.createHistoryProtocol = createHistoryProtocol;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _ServerProtocol = require('farce/lib/ServerProtocol');

var _ServerProtocol2 = _interopRequireDefault(_ServerProtocol);

var _server = require('found/lib/server');

var _render = require('./render');

var _render2 = _interopRequireDefault(_render);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function createRouterElement(renderArgs) {
	return _react2.default.createElement(
		_server.RouterProvider,
		{ router: renderArgs.router },
		(0, _render2.default)(renderArgs)
	);
}

function createHistoryProtocol(url) {
	return new _ServerProtocol2.default(url);
}
//# sourceMappingURL=server.js.map