'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.createRouterElement = createRouterElement;
exports.createHistoryProtocol = createHistoryProtocol;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _BrowserProtocol = require('farce/lib/BrowserProtocol');

var _BrowserProtocol2 = _interopRequireDefault(_BrowserProtocol);

var _createConnectedRouter = require('found/lib/createConnectedRouter');

var _createConnectedRouter2 = _interopRequireDefault(_createConnectedRouter);

var _resolver = require('found/lib/resolver');

var _resolver2 = _interopRequireDefault(_resolver);

var _foundScroll = require('found-scroll');

var _render2 = require('./render');

var _render3 = _interopRequireDefault(_render2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function createRouterElement(renderArgs, _ref) {
	var dispatch = _ref.dispatch,
	    getState = _ref.getState;

	var ConnectedRouter = (0, _createConnectedRouter2.default)({
		render: function render(renderArgs) {
			// Force re-mount the last `<Route/>` component on location path change.
			// https://github.com/4Catalyzer/found/issues/199#issuecomment-415616836
			var elements = renderArgs.elements;
			if (elements && window.reactWebsiteRemountOnNavigate !== false) {
				elements[elements.length - 1] = _react2.default.cloneElement(elements[elements.length - 1], { key: renderArgs.location.pathname });
			}
			return _react2.default.createElement(
				_foundScroll.ScrollManager,
				{ renderArgs: renderArgs },
				(0, _render3.default)(renderArgs)
			);
		}
	});
	return _react2.default.createElement(ConnectedRouter, {
		matchContext: {
			dispatch: dispatch,
			getState: getState
		},
		resolver: _resolver2.default,
		initialRenderArgs: renderArgs });
}

function createHistoryProtocol() {
	return new _BrowserProtocol2.default();
}
//# sourceMappingURL=client.js.map