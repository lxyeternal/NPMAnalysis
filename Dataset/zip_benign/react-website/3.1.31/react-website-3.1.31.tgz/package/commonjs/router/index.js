'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports._RESOLVE_MATCH = exports.RESOLVE_MATCH = exports.UPDATE_MATCH = exports.GOTO_ACTION_TYPE = exports.REDIRECT_ACTION_TYPE = exports.goto = exports.redirect = exports.RedirectException = exports.withRouter = exports.Redirect = exports.Route = exports.foundReducer = undefined;

var _foundReducer = require('found/lib/foundReducer');

Object.defineProperty(exports, 'foundReducer', {
	enumerable: true,
	get: function get() {
		return _interopRequireDefault(_foundReducer).default;
	}
});

var _Route = require('found/lib/Route');

Object.defineProperty(exports, 'Route', {
	enumerable: true,
	get: function get() {
		return _interopRequireDefault(_Route).default;
	}
});

var _Redirect = require('found/lib/Redirect');

Object.defineProperty(exports, 'Redirect', {
	enumerable: true,
	get: function get() {
		return _interopRequireDefault(_Redirect).default;
	}
});

var _withRouter = require('found/lib/withRouter');

Object.defineProperty(exports, 'withRouter', {
	enumerable: true,
	get: function get() {
		return _interopRequireDefault(_withRouter).default;
	}
});

var _RedirectException = require('found/lib/RedirectException');

Object.defineProperty(exports, 'RedirectException', {
	enumerable: true,
	get: function get() {
		return _interopRequireDefault(_RedirectException).default;
	}
});
exports.createRouterStoreEnhancers = createRouterStoreEnhancers;
exports.matchRoutes = matchRoutes;
exports.getRoutesByPath = getRoutesByPath;
exports.getMatchedRoutes = getMatchedRoutes;
exports.getMatchedRoutesIndices = getMatchedRoutesIndices;
exports.getMatchedRoutesParams = getMatchedRoutesParams;
exports.getCurrentlyMatchedLocation = getCurrentlyMatchedLocation;
exports.getRouteParams = getRouteParams;
exports.getPreviouslyMatchedLocation = getPreviouslyMatchedLocation;
exports.getRoutePath = getRoutePath;
exports.convertRoutes = convertRoutes;
exports.initializeRouter = initializeRouter;
exports.goBack = goBack;
exports.pushLocation = pushLocation;
exports.replaceLocation = replaceLocation;

var _createMatchEnhancer = require('found/lib/createMatchEnhancer');

var _createMatchEnhancer2 = _interopRequireDefault(_createMatchEnhancer);

var _Matcher = require('found/lib/Matcher');

var _Matcher2 = _interopRequireDefault(_Matcher);

var _makeRouteConfig = require('found/lib/makeRouteConfig');

var _makeRouteConfig2 = _interopRequireDefault(_makeRouteConfig);

var _getStoreRenderArgs = require('found/lib/getStoreRenderArgs');

var _getStoreRenderArgs2 = _interopRequireDefault(_getStoreRenderArgs);

var _HttpError = require('found/lib/HttpError');

var _HttpError2 = _interopRequireDefault(_HttpError);

var _resolver = require('found/lib/resolver');

var _resolver2 = _interopRequireDefault(_resolver);

var _ActionTypes = require('found/lib/ActionTypes');

var _ActionTypes2 = _interopRequireDefault(_ActionTypes);

var _Actions = require('farce/lib/Actions');

var _Actions2 = _interopRequireDefault(_Actions);

var _ActionTypes3 = require('farce/lib/ActionTypes');

var _ActionTypes4 = _interopRequireDefault(_ActionTypes3);

var _createHistoryEnhancer = require('farce/lib/createHistoryEnhancer');

var _createHistoryEnhancer2 = _interopRequireDefault(_createHistoryEnhancer);

var _createBasenameMiddleware = require('farce/lib/createBasenameMiddleware');

var _createBasenameMiddleware2 = _interopRequireDefault(_createBasenameMiddleware);

var _queryMiddleware = require('farce/lib/queryMiddleware');

var _queryMiddleware2 = _interopRequireDefault(_queryMiddleware);

var _instantBack = require('../redux/client/instantBack');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function createRouterStoreEnhancers(routes, createHistoryProtocol) {
	var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

	var middlewares = [_queryMiddleware2.default];
	if (options.basename) {
		middlewares.push((0, _createBasenameMiddleware2.default)({
			basename: options.basename
		}));
	}
	return [(0, _createHistoryEnhancer2.default)({
		protocol: createHistoryProtocol(),
		middlewares: middlewares
	}), (0, _createMatchEnhancer2.default)(
	// new Matcher(hotRouteConfig(routes), { matchStemRoutes: false })
	new _Matcher2.default(routes, { matchStemRoutes: false }))];
}

function matchRoutes(store) {
	return (0, _getStoreRenderArgs2.default)({
		store: store,
		resolver: _resolver2.default,
		matchContext: {
			dispatch: store.dispatch,
			getState: store.getState
		}
	}).then(function (renderArgs) {
		if (renderArgs.error) {
			throw renderArgs.error;
		}
		return renderArgs;
	});
}

function getRoutesByPath(routeIndices, routes) {
	var matchedRoutes = [];
	for (var _iterator = routeIndices, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
		var _ref;

		if (_isArray) {
			if (_i >= _iterator.length) break;
			_ref = _iterator[_i++];
		} else {
			_i = _iterator.next();
			if (_i.done) break;
			_ref = _i.value;
		}

		var i = _ref;

		matchedRoutes.push(routes[i]);
		routes = routes[i].children;
	}
	return matchedRoutes;
}

function getMatchedRoutes(state, routes) {
	return getRoutesByPath(state.found.match.routeIndices, routes);
}

function getMatchedRoutesIndices(state) {
	return state.found.match.routeIndices;
}

function getMatchedRoutesParams(state) {
	return state.found.match.routeParams;
}

function getCurrentlyMatchedLocation(state) {
	return state.found.match.location;
}

function getRouteParams(state) {
	return state.found.match.params;
}

function getPreviouslyMatchedLocation(state) {
	return state.found.resolvedMatch &&
	// state.found.resolvedMatch.location.key === undefined &&
	state.found.resolvedMatch.location;
}

// Returns a complete route path
// for matched `<Route/>`s chain.
// E.g. returns "/user/:user_id/post/:post_id"
// for matched URL "/user/1/post/123?key=value".
function getRoutePath(routes) {
	return routes
	// Select `<Route/>`s having `path` React property set.
	.filter(function (route) {
		return route.path;
	})
	// Trim leading and trailing slashes (`/`)
	// from each `<Route/>` `path` React property.
	.map(function (route) {
		return route.path.replace(/^\//, '').replace(/\/$/, '');
	})
	// Join `<Route/>` `path`s with slashes (`/`).
	.join('/') || '/';
}

function convertRoutes(routes) {
	return (0, _makeRouteConfig2.default)(routes);
}

function initializeRouter(store) {
	store.dispatch(_Actions2.default.init());
}

var redirect = exports.redirect = _Actions2.default.replace;

var goto = exports.goto = function goto(location) {
	var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

	(0, _instantBack.markImmediateNavigationAsInstantBack)(options.instantBack);
	return _Actions2.default.push(location);
};

var REDIRECT_ACTION_TYPE = exports.REDIRECT_ACTION_TYPE = _ActionTypes4.default.REPLACE;
var GOTO_ACTION_TYPE = exports.GOTO_ACTION_TYPE = _ActionTypes4.default.PUSH;

function goBack() {
	return _Actions2.default.go(-1);
}

function pushLocation(location, options) {
	window._react_website_skip_preload_update_location = true;
	return goto(location, options);
}

function replaceLocation(location) {
	window._react_website_skip_preload_update_location = true;
	return redirect(location);
}

var UPDATE_MATCH = exports.UPDATE_MATCH = _ActionTypes2.default.UPDATE_MATCH;
var RESOLVE_MATCH = exports.RESOLVE_MATCH = _ActionTypes2.default.RESOLVE_MATCH;

var _RESOLVE_MATCH = exports._RESOLVE_MATCH = '@@react-website/RESOLVE_MATCH';
//# sourceMappingURL=index.js.map