'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

exports.getMetaAttributeFor = getMetaAttributeFor;

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var BrowserDocument = function () {
	function BrowserDocument() {
		_classCallCheck(this, BrowserDocument);
	}

	_createClass(BrowserDocument, [{
		key: 'getMetaTags',

		// Will be mutated.
		value: function getMetaTags() {
			return Array.prototype.slice.call(document.head.getElementsByTagName('meta'), 0);
		}
	}, {
		key: 'getTitle',
		value: function getTitle() {
			return document.title;
		}
	}, {
		key: 'setTitle',
		value: function setTitle(title) {
			document.title = title;
		}
	}, {
		key: 'addMetaTag',
		value: function addMetaTag(name, value) {
			document.head.appendChild(this.createMetaTag(name, value));
		}

		/**
   * Creates `<meta/>` tag with a `value`.
   * @return {Element}
   */

	}, {
		key: 'createMetaTag',
		value: function createMetaTag(name, value) {
			var meta = document.createElement('meta');
			if (name === 'charset') {
				meta.setAttribute('charset', value);
			} else {
				meta.setAttribute(getMetaAttributeFor(name), name);
				meta.setAttribute('content', value);
			}
			return meta;
		}
	}, {
		key: 'isMetaTag',
		value: function isMetaTag(meta, name) {
			if (name === 'charset') {
				return meta.hasAttribute('charset');
			}
			return meta.getAttribute(getMetaAttributeFor(name)) === name;
		}
	}, {
		key: 'getMetaTagValue',
		value: function getMetaTagValue(meta) {
			if (meta.getAttribute('charset')) {
				return meta.getAttribute('charset');
			}
			return meta.getAttribute('content');
		}
	}, {
		key: 'setMetaTagValue',
		value: function setMetaTagValue(meta, value) {
			if (meta.getAttribute('charset')) {
				return meta.setAttribute('charset', value);
			}
			meta.setAttribute('content', value);
		}
	}, {
		key: 'removeMetaTag',
		value: function removeMetaTag(meta) {
			meta.parentNode.removeChild(meta);
		}
	}]);

	return BrowserDocument;
}();

/**
 * Get `<meta/>` "name" attribute.
 * @return {string}
 */


exports.default = BrowserDocument;
function getMetaAttributeFor(name) {
	return name.indexOf(':') >= 0 ? 'property' : 'name';
}
//# sourceMappingURL=BrowserDocument.js.map