'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

exports.default = meta;
exports.mergeMeta = mergeMeta;
exports.getComponentsMeta = getComponentsMeta;
exports.getCodeSplitMeta = getCodeSplitMeta;
exports.updateMeta = updateMeta;
exports.generateMetaTagsMarkup = generateMetaTagsMarkup;
exports.convertMeta = convertMeta;
exports.expandArrays = expandArrays;
exports.expandObjects = expandObjects;
exports.convertOpenGraphLocaleToLanguageTag = convertOpenGraphLocaleToLanguageTag;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _hoistNonReactStatics = require('hoist-non-react-statics');

var _hoistNonReactStatics2 = _interopRequireDefault(_hoistNonReactStatics);

var _flatten = require('lodash/flatten');

var _flatten2 = _interopRequireDefault(_flatten);

var _compact = require('lodash/compact');

var _compact2 = _interopRequireDefault(_compact);

var _BrowserDocument = require('./BrowserDocument');

var _BrowserDocument2 = _interopRequireDefault(_BrowserDocument);

var _utility = require('../utility');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var browserDocument = new _BrowserDocument2.default();

var DEFAULT_META = {
	charset: 'utf-8',
	// Fixes CSS screen width on mobile devices.
	// Otherwise media queries would not be applied initially
	// and it would show desktop version design.
	// Also, for `/react-website-blank` page this meta tag
	// needs to be present in markup as the default one
	// because `/react-website-blank` page doesn't collect
	// meta from page components.
	viewport: 'width=device-width, initial-scale=1.0'
};

var META_METHOD_NAME = '__meta__';

/**
 * `@meta()` decorator used for adding `<title/>` and <meta/>` tags to a React page.
 * @param  {function} getMeta - A function of `state` returning this page's meta object.
 * @example
 * @meta(({ state }) => ({ title: `${state.user.name}'s profile` }))
 */
function meta(getMeta) {
	return function (DecoratedComponent) {
		var Meta = function (_Component) {
			_inherits(Meta, _Component);

			function Meta() {
				_classCallCheck(this, Meta);

				return _possibleConstructorReturn(this, (Meta.__proto__ || Object.getPrototypeOf(Meta)).apply(this, arguments));
			}

			_createClass(Meta, [{
				key: 'render',
				value: function render() {
					return _react2.default.createElement(DecoratedComponent, this.props);
				}
			}]);

			return Meta;
		}(_react.Component);

		Meta[META_METHOD_NAME] = getMeta;
		Meta.displayName = 'Meta(' + (0, _utility.getDisplayName)(DecoratedComponent) + ')';
		return (0, _hoistNonReactStatics2.default)(Meta, DecoratedComponent);
	};
}

/**
 * Gathers `<title/>` and `<meta/>` tags (inside `<head/>`)
 * defined for this route (`components` array).
 * @param {object[]} meta — An array of meta objects.
 * @return {object}
 */
function mergeMeta(meta) {
	// // `Object.assign` is not supported in Internet Explorer.
	// return Object.assign({}, DEFAULT_META, ...)

	meta = meta.reduce(function (meta, componentMeta) {
		return _extends({}, meta, componentMeta);
	}, _extends({}, DEFAULT_META));

	// Remove `locale` from `locales`.
	if (meta.locale && meta.locales) {
		meta.locales = meta.locales.filter(function (_) {
			return _ !== meta.locale;
		});
		if (meta.locales.length === 0) {
			delete meta.locales;
		}
	}

	return meta;
}

/**
 * Gets `React.Component` chain meta.
 * @return {object[]}
 */
function getComponentsMeta(components, state) {
	return components
	// `.filter(_ => _)` here just in case someone forgets to set
	// `codeSplit: true` for `<Route/>`s with `getComponent`.
	.filter(function (_) {
		return _;
	}).map(function (_) {
		return _[META_METHOD_NAME];
	}).filter(function (_) {
		return _;
	}).map(function (_) {
		return dropUndefinedProperties(_(state));
	});
}

/**
 * Gathers `meta` from `<Route/>`s chain.
 * Meta could have been provided via the standard `@meta()` decorator instead
 * but `found` router doesn't provide the actual React Components for `<Route/>`s
 * which are resolved through `getComponent` so there's currently no way
 * of getting the actual Route component classes, hence the `meta` property workaround.
 *
 * @return {object[]}
 */
function getCodeSplitMeta(routes, state) {
	return routes.map(function (_) {
		return _.meta;
	}).filter(function (_) {
		return _;
	}).map(function (_) {
		return dropUndefinedProperties(_(state));
	});
}

/**
 * Updates `<title/>` and `<meta/>` tags (inside `<head/>`).
 */
function updateMeta(meta) {
	var document = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : browserDocument;
	var _meta = meta,
	    title = _meta.title,
	    charset = _meta.charset;

	meta = normalizeMeta(meta);

	// Get all `<meta/>` tags.
	// (will be mutated)
	var meta_tags = document.getMetaTags();

	// Update `<title/>`.
	if (title && document.getTitle() !== title) {
		document.setTitle(title);
	}

	// Update `<meta charset/>`.
	if (charset) {
		updateMetaTag(document, meta_tags, 'charset', charset);
	}

	// Update existing `<meta/>` tags.
	// (removing them from `meta_tags` array)
	var new_meta_tags = (0, _compact2.default)(meta.map(function (_ref) {
		var _ref2 = _slicedToArray(_ref, 2),
		    key = _ref2[0],
		    value = _ref2[1];

		if (!updateMetaTag(document, meta_tags, key, value)) {
			return [key, value];
		}
	}));

	// Delete no longer existent `<meta/>` tags.
	meta_tags.forEach(document.removeMetaTag);

	// Create new `<meta/>` tags.
	for (var _iterator = new_meta_tags, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
		var _ref3;

		if (_isArray) {
			if (_i >= _iterator.length) break;
			_ref3 = _iterator[_i++];
		} else {
			_i = _iterator.next();
			if (_i.done) break;
			_ref3 = _i.value;
		}

		var _ref4 = _ref3,
		    _ref5 = _slicedToArray(_ref4, 2),
		    key = _ref5[0],
		    value = _ref5[1];

		document.addMetaTag(key, value);
	}
}

/**
 * Generates a list of `<title/>` and `<meta/>` tags markup.
 * @param  {object[]} meta
 * @return {string[]}
 */
function generateMetaTagsMarkup(meta) {
	var _meta2 = meta,
	    title = _meta2.title,
	    charset = _meta2.charset;

	meta = normalizeMeta(meta);

	return [
	// `<meta charset/>` should always come first
	// because some browsers only read the first
	// 1024 bytes when deciding on page encoding.
	// (`<meta charset/>` is always present)
	'<meta charset="' + escapeHTML(charset || DEFAULT_META.charset) + '"/>', '<title>' + escapeHTML(title || '') + '</title>'].concat(meta.map(function (_ref6) {
		var _ref7 = _slicedToArray(_ref6, 2),
		    key = _ref7[0],
		    value = _ref7[1];

		return generateMetaTagMarkup(key, value);
	}));
}

/**
 * Generates `<meta/>` tag HTML markup.
 * @param {string} key
 * @param {string} value
 * @return {string}
 */
function generateMetaTagMarkup(name, value) {
	if (typeof value === 'boolean' || typeof value === 'number') {
		value = String(value);
	} else {
		value = escapeHTML(String(value));
	}
	return '<meta ' + (0, _BrowserDocument.getMetaAttributeFor)(name) + '="' + name + '" content="' + value + '"/>';
}

/**
 * Gets `<meta/>` property aliases.
 * (for both `name` and `property`).
 * Also filters out `charset`.
 * @return {string}
 */
function getMetaKeyAliases(key) {
	switch (key) {
		// `<meta charset/>` is handled specially
		// because it doesn't have `name` attribute.
		case 'charset':
			return [];
		// `<meta name="description"/>` is an older and
		// more widely supported form than "og:description".
		// In practice there's no need to duplicate
		// `<meta name="description"/>` as "og:description".
		// Still, to keep it fully-OpenGraph-compliant
		// the description is duplicated as "og:description" here.
		// https://indieweb.org/The-Open-Graph-protocol#How_to_set_description
		case 'description':
			return [key, 'og:' + key];
		case 'site_name':
		// `title` property of `meta` object is
		// handled specially via a `<title/>` tag.
		// There would be no need to add `og:title`
		// which duplicates the existing `<title/>`,
		// and `title` property could be discarded here.
		// For example, Facebook falls back to `<title/>` tag.
		// Still, OpenGraph specs formally require an `og:title`.
		// So, to keep it fully-OpenGraph-compliant
		// the title is duplicated as "og:title" here.
		// https://indieweb.org/The-Open-Graph-protocol#How_to_set_title
		case 'title':
		// SVG images are not supported (boo).
		// https://indieweb.org/The-Open-Graph-protocol#How_to_set_image
		case 'image':
		case 'locale':
		case 'type':
		case 'url':
		case 'audio':
		case 'video':
			return ['og:' + key];
		case 'locales':
			return ['og:locale:alternate'];
		default:
			return [escapeHTML(key)];
	}
}

/**
 * Updates `<meta/>` tag to a new `value` and removes it from `meta_tags`.
 * @param {Document} document - `BrowserDocument` or `TestDocument`.
 * @return {boolean?}
 */
function updateMetaTag(document, meta_tags, name, value) {
	var i = 0;
	while (i < meta_tags.length) {
		var meta_tag = meta_tags[i];

		if (document.isMetaTag(meta_tag, name)) {
			// Update `<meta/>` tag `value`.
			if (document.getMetaTagValue(meta_tag) !== value) {
				document.setMetaTagValue(meta_tag, value);
			}
			// Remove it from `meta_tags`.
			meta_tags.splice(i, 1);
			// Updated.
			return true;
		}

		i++;
	}
}

/**
 * Escapes a string so that it's kinda safe to insert into HTML.
 * @return {string}
 */
function escapeHTML(string) {
	return string && string.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;').replace('\'', '&#x27;').replace('/', '&#x2F;');
}

/**
 * Transforms meta object having "keys"
 * into a meta object having the actual
 * `<meta/>` tag `name`s and `property`es.
 * @return Array of arrays having shape `[key, value]`.
 */
function normalizeMetaKeys(meta) {
	return Object.keys(meta).reduce(function (all, key) {
		for (var _iterator2 = getMetaKeyAliases(key), _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
			var _ref8;

			if (_isArray2) {
				if (_i2 >= _iterator2.length) break;
				_ref8 = _iterator2[_i2++];
			} else {
				_i2 = _iterator2.next();
				if (_i2.done) break;
				_ref8 = _i2.value;
			}

			var alias = _ref8;

			all.push([alias, meta[key]]);
		}
		return all;
	}, []);
}

function normalizeMeta(meta) {
	return convertMeta(normalizeMetaKeys(meta));
}

function dropUndefinedProperties(object) {
	var keys = Object.keys(object);
	for (var _iterator3 = keys, _isArray3 = Array.isArray(_iterator3), _i3 = 0, _iterator3 = _isArray3 ? _iterator3 : _iterator3[Symbol.iterator]();;) {
		var _ref9;

		if (_isArray3) {
			if (_i3 >= _iterator3.length) break;
			_ref9 = _iterator3[_i3++];
		} else {
			_i3 = _iterator3.next();
			if (_i3.done) break;
			_ref9 = _i3.value;
		}

		var key = _ref9;

		if (object[key] === undefined) {
			return keys.reduce(function (newObject, key) {
				if (object[key] !== undefined) {
					newObject[key] = object[key];
				}
				return newObject;
			}, {});
		}
	}
	return object;
}

// Expands nested objects.
// Expands arrays.
// @param meta — Either an object or an array of arrays having shape `[key, value]`.
// @return An array of arrays having shape `[key, value]`.
function convertMeta(meta) {
	// Convert meta object to an array of arrays having shape `[key, value]`.
	if (!Array.isArray(meta)) {
		meta = Object.keys(meta).map(function (key) {
			return [key, meta[key]];
		});
	}
	return (0, _flatten2.default)(meta.map(function (keyValue) {
		return (0, _flatten2.default)(expandArrays(keyValue).map(expandObjects));
	}));
}

// There can be arrays of properties.
// For example:
// <meta property="og:image" content="//example.com/image.jpg" />
// <meta property="og:image:width" content="100" />
// <meta property="og:image:height" content="100" />
// <meta property="og:image" content="//example.com/image@2x.jpg" />
// <meta property="og:image:width" content="200" />
// <meta property="og:image:height" content="200" />
function expandArrays(meta) {
	if (Array.isArray(meta[1])) {
		return meta[1].map(function (value) {
			return [meta[0], value];
		});
	}
	return [meta];
}

// If `value` is an object
// then expand such object
// prefixing property names.
function expandObjects(meta) {
	if (_typeof(meta[1]) === 'object') {
		return (0, _flatten2.default)(Object.keys(meta[1]).map(function (key) {
			return [key === '_' ? meta[0] : meta[0] + ':' + key, meta[1][key]];
		})
		// Expand objects recursively.
		.map(expandObjects));
	}
	return [meta];
}

function convertOpenGraphLocaleToLanguageTag(ogLocale) {
	return ogLocale.replace('_', '-');
}
//# sourceMappingURL=meta.js.map