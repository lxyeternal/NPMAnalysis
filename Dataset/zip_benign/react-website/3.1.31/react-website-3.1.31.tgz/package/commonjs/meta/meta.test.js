'use strict';

var _meta = require('./meta');

var _TestDocument = require('./TestDocument');

var _TestDocument2 = _interopRequireDefault(_TestDocument);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

describe('@meta', function () {
	it('should update meta', function () {
		var document = new _TestDocument2.default([['charset', 'win1250'], ['og:locale', 'de'], ['og:locale', 'fr']]);

		(0, _meta.updateMeta)({
			title: 'Test',
			description: 'Testing metadata',
			site_name: 'Testing',
			locale: 'ru',
			locales: ['en', 'fr'],
			viewport: 'width=device-width, initial-scale=1',
			keywords: 'react, redux, webpack',
			author: '@catamphetamine'
		}, document);

		document.getMetaTags().should.deep.equal([['og:locale', 'ru'], ['og:title', 'Test'], ['description', 'Testing metadata'], ['og:description', 'Testing metadata'], ['og:site_name', 'Testing'], ['og:locale:alternate', 'en'], ['og:locale:alternate', 'fr'], ['viewport', 'width=device-width, initial-scale=1'], ['keywords', 'react, redux, webpack'], ['author', '@catamphetamine']]);

		document.getTitle().should.equal('Test');
	});

	it('should update meta without title and charset', function () {
		var document = new _TestDocument2.default();
		(0, _meta.updateMeta)({}, document);
		document.getMetaTags().should.deep.equal([]);
		expect(document.getTitle()).to.be.undefined;
	});

	it('should update charset', function () {
		var document = new _TestDocument2.default([['charset', 'win1250']]);
		(0, _meta.updateMeta)({ charset: 'utf-8' }, document);
		document.getMetaTags().should.deep.equal([['charset', 'utf-8']]);
	});

	it('should skip updating same charset', function () {
		var document = new _TestDocument2.default([['charset', 'utf-8']]);
		(0, _meta.updateMeta)({ charset: 'utf-8' }, document);
		document.getMetaTags().should.deep.equal([['charset', 'utf-8']]);
	});

	it('should generate meta tags markup', function () {
		(0, _meta.generateMetaTagsMarkup)({
			charset: 'utf-8',
			title: 'Test',
			description: 'Testing metadata',
			locale: 'ru',
			locales: ['en', 'fr'],
			viewport: 'width=device-width, initial-scale=1',
			keywords: 'react, redux, webpack',
			author: '@catamphetamine'
		}).should.deep.equal(["<meta charset=\"utf-8\"/>", "<title>Test</title>", "<meta property=\"og:title\" content=\"Test\"/>", "<meta name=\"description\" content=\"Testing metadata\"/>", "<meta property=\"og:description\" content=\"Testing metadata\"/>", "<meta property=\"og:locale\" content=\"ru\"/>", "<meta property=\"og:locale:alternate\" content=\"en\"/>", "<meta property=\"og:locale:alternate\" content=\"fr\"/>", "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>", "<meta name=\"keywords\" content=\"react, redux, webpack\"/>", "<meta name=\"author\" content=\"@catamphetamine\"/>"]);
	});

	it('should generate meta tags markup with default title and charset', function () {
		(0, _meta.generateMetaTagsMarkup)({}).should.deep.equal(["<meta charset=\"utf-8\"/>", "<title></title>"]);
	});

	it('should expand objects', function () {
		(0, _meta.expandObjects)(['key', 'value']).should.deep.equal([['key', 'value']]);

		(0, _meta.expandObjects)(['key', {
			subkey1: 'subvalue1',
			subkey2: 'subvalue2',
			subkey3: {
				'subsubkey1': 'subsubvalue1',
				'subsubkey2': 'subsubvalue2'
			}
		}]).should.deep.equal([['key:subkey1', 'subvalue1'], ['key:subkey2', 'subvalue2'], ['key:subkey3:subsubkey1', 'subsubvalue1'], ['key:subkey3:subsubkey2', 'subsubvalue2']]);
	});

	it('should expand arrays', function () {
		(0, _meta.expandArrays)(['key', 'value']).should.deep.equal([['key', 'value']]);

		(0, _meta.expandArrays)(['key', ['subvalue1', 'subvalue2']]).should.deep.equal([['key', 'subvalue1'], ['key', 'subvalue2']]);

		(0, _meta.expandArrays)(['key', [{
			'subkey1': 'subvalue1',
			'subkey2': 'subvalue2'
		}, {
			'subkey3': 'subvalue3',
			'subkey4': 'subvalue4'
		}]]).should.deep.equal([['key', {
			'subkey1': 'subvalue1',
			'subkey2': 'subvalue2'
		}], ['key', {
			'subkey3': 'subvalue3',
			'subkey4': 'subvalue4'
		}]]);
	});

	it('should convert meta', function () {
		(0, _meta.convertMeta)({
			key: [{
				_: 'rootvalue1',
				subkey1: 'subvalue1',
				subkey2: 'subvalue2',
				subkey3: {
					'subsubkey1': 'subsubvalue1',
					'subsubkey2': 'subsubvalue2'
				}
			}, {
				_: 'rootvalue2',
				subkey4: 'subvalue3',
				subkey5: 'subvalue4',
				subkey6: {
					'subsubkey3': 'subsubvalue3',
					'subsubkey4': 'subsubvalue4'
				}
			}]
		}).should.deep.equal([['key', 'rootvalue1'], ['key:subkey1', 'subvalue1'], ['key:subkey2', 'subvalue2'], ['key:subkey3:subsubkey1', 'subsubvalue1'], ['key:subkey3:subsubkey2', 'subsubvalue2'], ['key', 'rootvalue2'], ['key:subkey4', 'subvalue3'], ['key:subkey5', 'subvalue4'], ['key:subkey6:subsubkey3', 'subsubvalue3'], ['key:subkey6:subsubkey4', 'subsubvalue4']]);
	});

	it('should convert locales', function () {
		(0, _meta.convertOpenGraphLocaleToLanguageTag)('ru_RU').should.equal('ru-RU');
		(0, _meta.convertOpenGraphLocaleToLanguageTag)('ru').should.equal('ru');
	});
});
//# sourceMappingURL=meta.test.js.map