"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var TestDocument = function () {
	function TestDocument() {
		var _this = this;

		var tags = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];

		_classCallCheck(this, TestDocument);

		this.removeMetaTag = function (meta) {
			_this.tags = _this.tags.filter(function (_) {
				return _ !== meta;
			});
		};

		this.tags = tags;
	}

	// Will be mutated.


	_createClass(TestDocument, [{
		key: "getMetaTags",
		value: function getMetaTags() {
			return this.tags.slice();
		}
	}, {
		key: "getTitle",
		value: function getTitle() {
			return this.title;
		}
	}, {
		key: "setTitle",
		value: function setTitle(title) {
			this.title = title;
		}
	}, {
		key: "addMetaTag",
		value: function addMetaTag(name, value) {
			this.tags.push([name, value]);
		}
	}, {
		key: "isMetaTag",
		value: function isMetaTag(meta, name) {
			return meta[0] === name;
		}
	}, {
		key: "getMetaTagValue",
		value: function getMetaTagValue(meta) {
			return meta[1];
		}
	}, {
		key: "setMetaTagValue",
		value: function setMetaTagValue(meta, value) {
			meta[1] = value;
		}
	}]);

	return TestDocument;
}();

exports.default = TestDocument;
//# sourceMappingURL=TestDocument.js.map