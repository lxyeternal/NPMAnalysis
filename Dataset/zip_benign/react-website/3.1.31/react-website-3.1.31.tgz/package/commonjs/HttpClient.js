'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.default = undefined;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _superagent = require('superagent');

var _superagent2 = _interopRequireDefault(_superagent);

var _helpers = require('./helpers');

var _cookies = require('./client/cookies');

var _HttpRequest = require('./HttpRequest');

var _HttpRequest2 = _interopRequireDefault(_HttpRequest);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

// This is an isomorphic (universal) HTTP client
// which works both on Node.js and in the web browser,
// and therefore can be used in Redux actions (for HTTP requests)
var HttpClient = function () {

	// Constructs a new instance of Http client.
	// Optionally takes an Http Request as a reference to mimic
	// (in this case, cookies, to make authentication work on the server-side).
	function HttpClient() {
		var _this = this;

		var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

		_classCallCheck(this, HttpClient);

		this.set_cookies = [];
		var proxy = options.proxy,
		    headers = options.headers,
		    cookies = options.cookies,
		    authentication_token_header = options.authentication_token_header,
		    on_before_send = options.on_before_send,
		    catch_to_retry = options.catch_to_retry,
		    get_access_token = options.get_access_token,
		    allow_absolute_urls = options.allow_absolute_urls;


		var parse_json_dates = options.parseDates !== false;

		var transform_url = options.transform_url || this.proxy_url.bind(this);

		// Clone HTTP request cookies on the server-side
		// (to make authentication work)
		if (cookies) {
			this.server = true;
		}

		this.proxy = proxy;

		var http_methods = ['get', 'post', 'put', 'patch', 'delete', 'head', 'options'];

		// "Get cookie value by name" helper (works both on client and server)
		var getCookie = this.server ? function (name) {
			// If this cookie was set dynamically then return it
			for (var _iterator = _this.set_cookies, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
				var _ref;

				if (_isArray) {
					if (_i >= _iterator.length) break;
					_ref = _iterator[_i++];
				} else {
					_i = _iterator.next();
					if (_i.done) break;
					_ref = _i.value;
				}

				var cookie_raw = _ref;

				if (cookie_raw.indexOf(name + '=') === 0) {
					var _get_cookie_key_value = (0, _HttpRequest.get_cookie_key_value)(cookie_raw),
					    _get_cookie_key_value2 = _slicedToArray(_get_cookie_key_value, 2),
					    key = _get_cookie_key_value2[0],
					    value = _get_cookie_key_value2[1];

					return value;
				}
			}

			// Return the original request cookie
			return cookies[name];
		} : _cookies.getCookie;

		// `superagent` doesn't save cookies by default on the server side.
		// Therefore calling `.agent()` explicitly to enable setting cookies.
		var agent = this.server ? _superagent2.default.agent() : _superagent2.default;

		// Define HTTP methods on this `http` utility instance

		var _loop = function _loop() {
			if (_isArray2) {
				if (_i2 >= _iterator2.length) return 'break';
				_ref2 = _iterator2[_i2++];
			} else {
				_i2 = _iterator2.next();
				if (_i2.done) return 'break';
				_ref2 = _i2.value;
			}

			var method = _ref2;

			_this[method] = function (path, data) {
				var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

				// `url` will be absolute for server-side
				var url = transform_url(path, _this.server);

				// Is incremented on each retry
				var retry_count = -1;

				// Performs an HTTP request to the given `url`.
				// Can retry itself.
				var perform_http_request = function perform_http_request() {
					// Create Http request
					var request = new _HttpRequest2.default(method, url, data, {
						agent: agent,
						parse_json_dates: parse_json_dates,
						on_response_headers: options.onResponseHeaders,
						headers: _extends({}, headers, options.headers),
						new_cookies_added: function new_cookies_added(cookies) {
							if (_this.server) {
								// Cookies will be duplicated here
								// because `superagent.agent()` persists
								// `Set-Cookie`s between subsequent requests
								// (i.e. for the same `HttpClient` instance).
								// Therefore using a `Set` instead of an array.
								for (var _iterator3 = cookies, _isArray3 = Array.isArray(_iterator3), _i3 = 0, _iterator3 = _isArray3 ? _iterator3 : _iterator3[Symbol.iterator]();;) {
									var _ref3;

									if (_isArray3) {
										if (_i3 >= _iterator3.length) break;
										_ref3 = _iterator3[_i3++];
									} else {
										_i3 = _iterator3.next();
										if (_i3.done) break;
										_ref3 = _i3.value;
									}

									var cookie = _ref3;

									// this.set_cookies.add(cookie)
									if (_this.set_cookies.indexOf(cookie) < 0) {
										_this.set_cookies.push(cookie);
									}
								}
							}
						}
					});

					// Sets `Authorization: Bearer ${token}` in HTTP request header
					request.add_authentication(authentication_token_header, options.authentication, get_access_token, getCookie, url, path);

					// On server side, add cookies to relative HTTP requests.
					if (_this.server && is_relative_url(path)) {
						request.add_cookies(cookies, _this.set_cookies);
					}

					// Allows customizing HTTP requests.
					// (for example, setting some HTTP headers,
					//  or changing HTTP request `Content-Type`).
					// https://github.com/catamphetamine/react-website/issues/73
					if (on_before_send) {
						on_before_send(request.request, {
							url: url,
							requestedURL: path
						});
					}

					// File upload progress metering
					// https://developer.mozilla.org/en/docs/Web/API/XMLHttpRequest/Using_XMLHttpRequest
					if (options.progress) {
						request.progress(options.progress);
					}

					// If using `bluebird` and `Promise` cancellation is configured
					// http://bluebirdjs.com/docs/api/cancellation.html
					return new Promise(function (resolve, reject, onCancel) {
						// Send HTTP request
						request.send().then(resolve, reject);

						// If using `bluebird` and `Promise` cancellation is configured
						// http://bluebirdjs.com/docs/api/cancellation.html
						// https://github.com/petkaantonov/bluebird/issues/1323
						if (Promise.version && onCancel) {
							onCancel(function () {
								return request.request.abort();
							});
						}

						// // One could store the `request` to later `.abort()` it.
						// // https://github.com/catamphetamine/react-website/issues/46
						// if (options.onRequest)
						// {
						// 	options.onRequest(request.request)
						// }
					}).then(function (response) {
						return response;
					}, function (error) {
						// `superagent` would have already output the error to console
						// console.error(error.stack)

						// (legacy)
						//
						// this turned out to be a lame way of handling cookies,
						// because cookies are sent in request
						// with no additional parameters
						// such as `path`, `httpOnly` and `expires`,
						// so there were cookie duplication issues.
						//
						// if (response)
						// {
						// 	if (response.get('set-cookie'))
						// 	{
						// 		this.cookies_raw = response.get('set-cookie')
						// 	}
						// }

						// Can optionally retry an HTTP request in case of an error
						// (e.g. if an Auth0 access token expired and has to be refreshed).
						// https://auth0.com/blog/refresh-tokens-what-are-they-and-when-to-use-them/
						if (catch_to_retry) {
							retry_count++;

							return catch_to_retry(error, retry_count, {
								getCookie: getCookie,
								http: _this
							}).then(perform_http_request);
						}

						// HTTP request failed with an `error`
						return Promise.reject(error);
					});
				};

				return perform_http_request();
			};
		};

		for (var _iterator2 = http_methods, _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
			var _ref2;

			var _ret = _loop();

			if (_ret === 'break') break;
		}
	}

	// Validates the requested URL,
	// and also prepends host and port to it on the server side.

	// `Set-Cookie` HTTP headers
	// (in case any cookies are set)
	// set_cookies = new Set()


	_createClass(HttpClient, [{
		key: 'proxy_url',
		value: function proxy_url(path, server) {
			// Prepend host and port on the server side
			if (this.proxy && server) {
				var protocol = this.proxy.secure ? 'https' : 'http';
				return protocol + '://' + this.proxy.host + ':' + (this.proxy.port || '80') + path;
			}

			return path;
		}
	}]);

	return HttpClient;
}();

exports.default = HttpClient;


function is_relative_url(path) {
	return (0, _helpers.starts_with)(path, '/') && !(0, _helpers.starts_with)(path, '//');
}
//# sourceMappingURL=HttpClient.js.map