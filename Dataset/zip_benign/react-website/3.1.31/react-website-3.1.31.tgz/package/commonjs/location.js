'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.getLocationUrl = getLocationUrl;
exports.parseLocation = parseLocation;
exports.shouldSkipPreloadForNavigation = shouldSkipPreloadForNavigation;
function getLocationUrl(location) {
	var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

	if (typeof location === 'string') {
		if (options.basename) {
			location = parseLocation(location);
		} else {
			return location;
		}
	}

	var origin = location.origin || '';
	var pathname = location.pathname;
	var search = location.search || '';
	var hash = location.hash || '';

	// Append `basename` only to relative URLs
	var basename = !origin && options.basename ? options.basename : '';

	return '' + origin + basename + pathname + search + hash;
}

// Doesn't construct `query` though
function parseLocation(location) {
	if (typeof location !== 'string') {
		return location;
	}

	var origin = void 0;
	var pathname = void 0;

	if (location === '') {
		pathname = '/';
	} else if (location[0] === '/') {
		pathname = location;
	} else {
		var pathname_starts_at = location.indexOf('/', location.indexOf('//') + '//'.length);

		if (pathname_starts_at > 0) {
			origin = location.slice(0, pathname_starts_at);
			pathname = location.slice(pathname_starts_at);
		} else {
			origin = location;
			pathname = '/';
		}
	}

	var search = '';
	var hash = '';

	var search_index = pathname.indexOf('?');
	if (search_index >= 0) {
		search = pathname.slice(search_index);
		pathname = pathname.slice(0, search_index);
	}

	var hash_index = search.indexOf('#');
	if (hash_index >= 0) {
		hash = search.slice(hash_index);
		search = search.slice(0, hash_index);
	}

	return { origin: origin, pathname: pathname, search: search, hash: hash };
}

function isSameLocationIgnoreHash(fromLocation, toLocation) {
	return toLocation.origin === fromLocation.origin && toLocation.pathname === fromLocation.pathname && toLocation.search === fromLocation.search;
}

// A workaround for `found` router bug:
// https://github.com/4Catalyzer/found/issues/239
// Skip `@preload()` and other stuff for anchor link navigation.
function shouldSkipPreloadForNavigation(fromLocation, toLocation) {
	if (isSameLocationIgnoreHash(fromLocation, toLocation)) {
		// If a "hash" link has been clicked,
		// or if it's a Back/Forward navigation
		// then `@preload()` should be skipped.
		if (toLocation.hash || toLocation.action === 'POP') {
			return true;
		}
	}
}
//# sourceMappingURL=location.js.map