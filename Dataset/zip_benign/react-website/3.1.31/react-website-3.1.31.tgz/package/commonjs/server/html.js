'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _stringify = require('babel-runtime/core-js/json/stringify');

var _stringify2 = _interopRequireDefault(_stringify);

exports.renderBeforeContent = renderBeforeContent;
exports.renderAfterContent = renderAfterContent;
exports.safeJsonStringify = safeJsonStringify;

var _nunjucks = require('nunjucks');

var _nunjucks2 = _interopRequireDefault(_nunjucks);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_nunjucks2.default.configure({ autoescape: true });

function renderBeforeContent(_ref) {
	var assets = _ref.assets,
	    locale = _ref.locale,
	    meta = _ref.meta,
	    head = _ref.head,
	    bodyStart = _ref.bodyStart;

	return TEMPLATE_BEFORE_CONTENT.render({
		icon: assets.icon,
		style_urls: assets.entries.map(function (entry) {
			return assets.styles && assets.styles[entry];
		}).filter(function (url) {
			return url;
		}),
		locale: locale,
		meta: meta,
		head: head,
		bodyStart: bodyStart
	});
}

function renderAfterContent(_ref2) {
	var assets = _ref2.assets,
	    contentNotRendered = _ref2.contentNotRendered,
	    locales = _ref2.locales,
	    javascript = _ref2.javascript,
	    bodyEnd = _ref2.bodyEnd;

	return TEMPLATE_AFTER_CONTENT.render({
		javascript_urls: assets.entries.map(function (entry) {
			return assets.javascript && assets.javascript[entry];
		}).filter(function (url) {
			return url;
		}),
		contentNotRendered: contentNotRendered,
		locales: locales,
		javascript: javascript,
		bodyEnd: bodyEnd,
		safeJsonStringify: safeJsonStringify
	});
}

function safeJsonStringify(json) {
	// The default javascript JSON.stringify doesn't escape forward slashes,
	// but it is allowed by the JSON specification, so we manually do it here.
	// (and javascript regular expressions don't support "negative lookbehind"
	//  so it's simply replacing all forward slashes with escaped ones,
	//  but also make sure to not call it twice on the same JSON)
	return (0, _stringify2.default)(json).replace(/\//g, '\\/');
}

var TEMPLATE_BEFORE_CONTENT = _nunjucks2.default.compile('\n\t<!doctype html>\n\t<html {% if locale %} lang="{{locale}}" {% endif %}>\n\t\t<head>\n\t\t\t{# <title/> and <meta/> tags, properly escaped #}\n\t\t\t{{ meta | safe }}\n\n\t\t\t{#\n\t\t\t\t(will be done only in production mode\n\t\t\t\t with webpack extract text plugin)\n\t\t\t\tMount CSS stylesheets for all entry points (e.g. "main")\n\t\t\t#}\n\t\t\t{% for style_url in style_urls %}\n\t\t\t\t<link\n\t\t\t\t\thref="{{ style_url | safe }}"\n\t\t\t\t\trel="stylesheet"\n\t\t\t\t\ttype="text/css"\n\t\t\t\t\tcharset="UTF-8"/>\n\t\t\t{% endfor %}\n\n\t\t\t{# Custom <head/> markup #}\n\t\t\t{{ head | safe }}\n\n\t\t\t{# Site icon #}\n\t\t\t{% if icon %}\n\t\t\t\t<link rel="shortcut icon" href="{{ icon | safe }}"/>\n\t\t\t{% endif %}\n\t\t</head>\n\n\t\t<body>\n\t\t\t{# Supports adding arbitrary markup to <body/> start #}\n\t\t\t{{ bodyStart | safe }}\n\n\t\t\t{# React page content. #}\n\t\t\t<div id="react" class="react--loading">'.replace(/\t/g, ''));

var TEMPLATE_AFTER_CONTENT = _nunjucks2.default.compile('</div>\n\n\t\t\t{#\n\t\t\t\tServer-Side Rendering "renderContent" flag.\n\t\t\t\tIt is used to determine whether to call\n\t\t\t\t"ReactDOM.hydrate()" or "ReactDOM.render()".\n\t\t\t#}\n\t\t\t<script>\n\t\t\t\t{# If renaming this variable don\'t reset it in "./redux/client/client.js" #}\n\t\t\t\twindow._server_side_render = true\n\t\t\t\t{% if contentNotRendered %}\n\t\t\t\t\t{# If renaming this variable don\'t reset it in "./redux/client/client.js" #}\n\t\t\t\t\twindow._empty_server_side_render = true\n\t\t\t\t{% endif %}\n\t\t\t</script>\n\n\t\t\t{# User\'s preferred locales (based on the "Accept-Locale" HTTP request header). #}\n\t\t\t{% if locales %}\n\t\t\t\t<script>\n\t\t\t\t\t{# If renaming this variable don\'t reset it in "./redux/client/client.js" #}\n\t\t\t\t\twindow._react_website_locales = {{ safeJsonStringify(locales) | safe }}\n\t\t\t\t</script>\n\t\t\t{% endif %}\n\n\t\t\t{# Custom javascript. Must be XSS-safe. #}\n\t\t\t{# e.g. Redux stuff goes here (Redux state, Date parser) #}\n\t\t\t{% if javascript %}\n\t\t\t\t{{ javascript | safe }}\n\t\t\t{% endif %}\n\n\t\t\t{# javascripts #}\n\n\t\t\t{#\n\t\t\t\tInclude all required "entry" points javascript\n\t\t\t\t(e.g. "common", "main")\n\t\t\t#}\n\t\t\t{% for javascript_url in javascript_urls %}\n\t\t\t\t<script src="{{ javascript_url | safe }}" charset="UTF-8"></script>\n\t\t\t{% endfor %}\n\n\t\t\t{# Supports adding arbitrary markup to <body/> end #}\n\t\t\t{{ bodyEnd | safe }}\n\t\t</body>\n\t</html>\n'.replace(/\t/g, ''));
//# sourceMappingURL=html.js.map