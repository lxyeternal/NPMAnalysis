'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.renderPage = undefined;

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _getIterator2 = require('babel-runtime/core-js/get-iterator');

var _getIterator3 = _interopRequireDefault(_getIterator2);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

// Renders a webpage
var respondWithPage = function () {
	var _ref = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee(request, response, settings, options) {
		var _ref2, redirect, cookies, status, content, _iterator, _isArray, _i, _ref3, _cookie;

		return _regenerator2.default.wrap(function _callee$(_context) {
			while (1) {
				switch (_context.prev = _context.next) {
					case 0:
						_context.next = 2;
						return renderPage(request.url, request.headers, settings, options);

					case 2:
						_ref2 = _context.sent;
						redirect = _ref2.redirect;
						cookies = _ref2.cookies;
						status = _ref2.status;
						content = _ref2.content;

						if (!redirect) {
							_context.next = 10;
							break;
						}

						response.writeHead(302, { Location: redirect });
						return _context.abrupt('return', response.end());

					case 10:
						_iterator = cookies, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : (0, _getIterator3.default)(_iterator);

					case 11:
						if (!_isArray) {
							_context.next = 17;
							break;
						}

						if (!(_i >= _iterator.length)) {
							_context.next = 14;
							break;
						}

						return _context.abrupt('break', 25);

					case 14:
						_ref3 = _iterator[_i++];
						_context.next = 21;
						break;

					case 17:
						_i = _iterator.next();

						if (!_i.done) {
							_context.next = 20;
							break;
						}

						return _context.abrupt('break', 25);

					case 20:
						_ref3 = _i.value;

					case 21:
						_cookie = _ref3;

						response.setHeader('Set-Cookie', _cookie);

					case 23:
						_context.next = 11;
						break;

					case 25:

						// HTTP response status and "Content-Type"
						response.writeHead(status || 200, { 'Content-Type': 'text/html' });

						// Stream the rendered React page
						content.pipe(response);

					case 27:
					case 'end':
						return _context.stop();
				}
			}
		}, _callee, this);
	}));

	return function respondWithPage(_x, _x2, _x3, _x4) {
		return _ref.apply(this, arguments);
	};
}();

// Renders a webpage.
// `headers`: `{ cookie, accept-language, host, user-agent }`.


var renderPage = exports.renderPage = function () {
	var _ref4 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee2(url, headers, settings, options) {
		var secure, proxy, assets, authentication, renderContent, html, stats, getInitialState, cookies, _ref5, status, content, redirect, route, time, cookiesToSet;

		return _regenerator2.default.wrap(function _callee2$(_context2) {
			while (1) {
				switch (_context2.prev = _context2.next) {
					case 0:
						secure = options.secure, proxy = options.proxy, assets = options.assets, authentication = options.authentication, renderContent = options.renderContent, html = options.html, stats = options.stats, getInitialState = options.getInitialState;
						cookies = headers.cookie ? _cookie3.default.parse(headers.cookie) : {};
						_context2.next = 4;
						return (0, _render2.default)(settings, {
							proxy: proxy,
							assets: assets,
							authentication: authentication,
							renderContent: renderContent,
							html: html,
							url: url,
							// Cookies for making `http` requests on server.
							cookies: cookies,
							locales: (0, _locale.getPreferredLocales)(headers),
							// Headers are used in `getInitialState()`.
							// https://github.com/catamphetamine/react-website/issues/72
							getInitialState: getInitialState,
							headers: headers
						});

					case 4:
						_ref5 = _context2.sent;
						status = _ref5.status;
						content = _ref5.content;
						redirect = _ref5.redirect;
						route = _ref5.route;
						time = _ref5.time;
						cookiesToSet = _ref5.cookies;

						if (!redirect) {
							_context2.next = 13;
							break;
						}

						return _context2.abrupt('return', { redirect: redirect });

					case 13:

						// Report page rendering stats
						if (stats) {
							stats({
								url: url,
								route: route,
								time: time
							});
						}

						return _context2.abrupt('return', {
							cookies: cookiesToSet,
							status: status,
							content: content
						});

					case 15:
					case 'end':
						return _context2.stop();
				}
			}
		}, _callee2, this);
	}));

	return function renderPage(_x5, _x6, _x7, _x8) {
		return _ref4.apply(this, arguments);
	};
}();

exports.default = server;

var _http = require('http');

var _http2 = _interopRequireDefault(_http);

var _https = require('https');

var _https2 = _interopRequireDefault(_https);

var _cookie2 = require('cookie');

var _cookie3 = _interopRequireDefault(_cookie2);

var _render = require('./render');

var _render2 = _interopRequireDefault(_render);

var _renderError2 = require('./renderError');

var _renderError3 = _interopRequireDefault(_renderError2);

var _timer = require('../timer');

var _timer2 = _interopRequireDefault(_timer);

var _locale = require('./locale');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function server(settings, options) {
	if (options.initialize) {
		throw new Error('[react-website] "initialize" server-side parameter function was removed. Use a root-level @preload() instead.');
	}
	return (options.secure ? _https2.default : _http2.default).createServer(function (request, response) {
		// Render the page (and handle errors, if any)
		respondWithPage(request, response, settings, options).catch(function (error) {
			return respondWithError(error, response, options.printError);
		});
	});
}

function respondWithError(error, response, options) {
	var _renderError = (0, _renderError3.default)(error, options),
	    status = _renderError.status,
	    content = _renderError.content,
	    contentType = _renderError.contentType;

	// HTTP response status and "Content-Type"


	response.writeHead(status, { 'Content-Type': contentType });

	// Output the error page
	return response.end(content);
}
//# sourceMappingURL=server.js.map