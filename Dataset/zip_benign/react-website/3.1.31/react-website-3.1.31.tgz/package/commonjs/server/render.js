'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _regenerator = require('babel-runtime/regenerator');

var _regenerator2 = _interopRequireDefault(_regenerator);

var _extends2 = require('babel-runtime/helpers/extends');

var _extends3 = _interopRequireDefault(_extends2);

var _slicedToArray2 = require('babel-runtime/helpers/slicedToArray');

var _slicedToArray3 = _interopRequireDefault(_slicedToArray2);

var _objectWithoutProperties2 = require('babel-runtime/helpers/objectWithoutProperties');

var _objectWithoutProperties3 = _interopRequireDefault(_objectWithoutProperties2);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _server = require('react-dom/server');

var _server2 = _interopRequireDefault(_server);

var _stringToStream = require('string-to-stream');

var _stringToStream2 = _interopRequireDefault(_stringToStream);

var _multistream = require('multistream');

var _multistream2 = _interopRequireDefault(_multistream);

var _html = require('./html');

var _normalize = require('../redux/normalize');

var _normalize2 = _interopRequireDefault(_normalize);

var _timer = require('../timer');

var _timer2 = _interopRequireDefault(_timer);

var _location = require('../location');

var _render = require('../redux/server/render');

var _render2 = _interopRequireDefault(_render);

var _server3 = require('../redux/server/server');

var _meta = require('../meta/meta');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function () {
	var _ref2 = (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee(settings, _ref) {
		var assets = _ref.assets,
		    proxy = _ref.proxy,
		    url = _ref.url,
		    renderContent = _ref.renderContent,
		    _ref$html = _ref.html,
		    html = _ref$html === undefined ? {} : _ref$html,
		    cookies = _ref.cookies,
		    locales = _ref.locales,
		    headers = _ref.headers,
		    getInitialState = _ref.getInitialState;

		var _settings, routes, container, defaultMeta, authentication, onError, codeSplit, render, _ref3, cookiesToSet, generateJavascript, parameters, location, path, generateOuterHtml, _generateOuterHtml, _generateOuterHtml2, _beforeContent, _afterContent, _ref4, redirect, route, status, content, meta, containerProps, time, _generateOuterHtml3, _generateOuterHtml4, beforeContent, afterContent, streams, pageElement;

		return _regenerator2.default.wrap(function _callee$(_context) {
			while (1) {
				switch (_context.prev = _context.next) {
					case 0:
						generateOuterHtml = function generateOuterHtml(meta) {
							// `html` modifiers
							var head = html.head,
							    bodyStart = html.bodyStart,
							    bodyEnd = html.bodyEnd;

							// Normalize `html` parameters

							head = typeof head === 'function' ? head(path, parameters) : head;
							bodyStart = typeof bodyStart === 'function' ? bodyStart(path, parameters) : bodyStart;
							bodyEnd = typeof bodyEnd === 'function' ? bodyEnd(path, parameters) : bodyEnd;

							// Normalize assets
							assets = typeof assets === 'function' ? assets(path, parameters) : assets;

							if (!assets.entries) {
								// Default `assets.entries` to `["main"]`.
								if (assets.javascript && assets.javascript.main) {
									assets.entries = ['main'];
								} else {
									throw new Error('"assets.entries[]" configuration parameter is required: it includes all Webpack "entries" for which javascripts and styles must be included on a server-rendered page. If you didn\'t set up any custom "entries" in Webpack configuration then the default Webpack entry is called "main". You don\'t seem to have the "main" entry so the server doesn\'t know which assets to include on the page ("[\'main\']" is the default value for "assets.entries").');
								}
							}

							// Render all HTML that goes before React markup.
							var beforeContent = (0, _html.renderBeforeContent)({
								assets: assets,
								locale: meta.locale && (0, _meta.convertOpenGraphLocaleToLanguageTag)(meta.locale),
								meta: (0, _meta.generateMetaTagsMarkup)(meta).join(''),
								head: head,
								bodyStart: bodyStart
							});

							// Render all HTML that goes after React markup
							var afterContent = (0, _html.renderAfterContent)({
								javascript: generateJavascript(),
								assets: assets,
								locales: locales,
								bodyEnd: bodyEnd,
								contentNotRendered: renderContent === false
							});

							return [beforeContent, afterContent];
						};

						settings = (0, _normalize2.default)(settings);

						_settings = settings, routes = _settings.routes, container = _settings.container, defaultMeta = _settings.meta, authentication = _settings.authentication, onError = _settings.onError, codeSplit = _settings.codeSplit;

						// If Redux is being used, then render for Redux.
						// Else render for pure React.

						render = _render2.default;

						// `parameters` are used for `assets` and `html` modifiers.

						_context.next = 6;
						return (0, _server3.initialize)(settings, {
							proxy: proxy,
							cookies: cookies,
							headers: headers,
							locales: locales,
							url: url,
							getInitialState: getInitialState
						});

					case 6:
						_ref3 = _context.sent;
						cookiesToSet = _ref3.cookies;
						generateJavascript = _ref3.generateJavascript;
						parameters = (0, _objectWithoutProperties3.default)(_ref3, ['cookies', 'generateJavascript']);
						location = (0, _location.parseLocation)(url);
						path = location.pathname;

						if (!(path.replace(/\/$/, '') === '/react-website-base')) {
							_context.next = 16;
							break;
						}

						renderContent = false;
						// Get `<meta/>` for the route.
						_generateOuterHtml = generateOuterHtml((0, _extends3.default)({}, defaultMeta, (0, _meta.mergeMeta)([]))), _generateOuterHtml2 = (0, _slicedToArray3.default)(_generateOuterHtml, 2), _beforeContent = _generateOuterHtml2[0], _afterContent = _generateOuterHtml2[1];
						return _context.abrupt('return', {
							route: '/react-website-base',
							status: 200,
							content: (0, _stringToStream2.default)(_beforeContent + _afterContent),
							cookies: []
						});

					case 16:
						_context.next = 18;
						return render((0, _extends3.default)({}, parameters, {
							// routes,
							codeSplit: codeSplit,
							defaultMeta: defaultMeta
						}));

					case 18:
						_ref4 = _context.sent;
						redirect = _ref4.redirect;
						route = _ref4.route;
						status = _ref4.status;
						content = _ref4.content;
						meta = _ref4.meta;
						containerProps = _ref4.containerProps;
						time = _ref4.time;

						if (!redirect) {
							_context.next = 28;
							break;
						}

						return _context.abrupt('return', {
							// Stringify `redirect` location.
							// Prepend `basename` to relative URLs for server-side redirect.
							redirect: (0, _location.getLocationUrl)(redirect, { basename: settings.basename })
						});

					case 28:
						_generateOuterHtml3 = generateOuterHtml(meta), _generateOuterHtml4 = (0, _slicedToArray3.default)(_generateOuterHtml3, 2), beforeContent = _generateOuterHtml4[0], afterContent = _generateOuterHtml4[1];
						streams = [(0, _stringToStream2.default)(beforeContent), (0, _stringToStream2.default)(afterContent)];


						if (renderContent !== false) {
							// Render page content to a `Stream`
							// inserting this stream in the middle of `streams` array.
							// `array.splice(index, 0, element)` inserts `element` at `index`.
							pageElement = _react2.default.createElement(container, containerProps, content);

							streams.splice(streams.length / 2, 0, _server2.default.renderToNodeStream(pageElement));
						}

						return _context.abrupt('return', {
							route: route,
							status: status,
							content: (0, _multistream2.default)(streams),
							time: time,
							cookies: cookiesToSet
						});

					case 32:
					case 'end':
						return _context.stop();
				}
			}
		}, _callee, this);
	}));

	return function (_x, _x2) {
		return _ref2.apply(this, arguments);
	};
}();
//# sourceMappingURL=render.js.map