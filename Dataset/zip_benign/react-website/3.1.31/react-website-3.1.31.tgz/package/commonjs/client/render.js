'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports.default = render;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _reactDom = require('react-dom');

var _reactDom2 = _interopRequireDefault(_reactDom);

var _flags = require('./flags');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }

// Performs client-side React application rendering.
// Takes `render()` function which renders the actual page.
// Then this rendered page is rendered in a `container`
// (e.g. Redux state `<Connector/>` and such).
// This function is not exported and is not called directly in an application:
// instead specific implementations call this function
// providing their own `render()` logic
// (e.g. Redux + React-router, React-router).
//
function render(_ref) {
	var render = _ref.render,
	    _ref$renderParameters = _ref.renderParameters,
	    renderParameters = _ref$renderParameters === undefined ? {} : _ref$renderParameters,
	    container = _ref.container;

	var firstRender = true;
	// Renders current React page (inside a container).
	// Returns a Promise for an object holding
	// `render` function for development mode hot reload,
	// and also `store` (if Redux is used).
	function renderPage() {
		if (firstRender) {
			firstRender = false;
		} else {
			window._react_website_hot_reload = true;
		}
		return render(renderParameters).then(function (_ref2) {
			var element = _ref2.element,
			    containerProps = _ref2.containerProps,
			    rest = _objectWithoutProperties(_ref2, ['element', 'containerProps']);

			// if (locale) {
			// 	containerProps.locale = locale
			// }
			renderReactElementTree(
			// Render page `element` inside a container element.
			// E.g. Redux context `<Provider/>`, and others.
			_react2.default.createElement(container, containerProps, element),
			// DOM element to which React markup will be rendered
			getReactContainerElement());
			window._react_website_hot_reload = false;
			return rest;
		});
	}
	// Render the page on the client side.
	return renderPage().then(function (result) {
		return _extends({}, result, {
			// Client side code can then rerender the page any time
			// by calling this `render()` function
			// (makes hot reload work in development mode).
			rerender: renderPage
		});
	});
}

// Renders React element to a DOM node
function renderReactElementTree(element, to) {
	// If using React >= 16 and the content is Server-Side Rendered.
	if ((0, _flags.isServerSidePreloaded)() && (0, _flags.isServerSideRendered)() && _reactDom2.default.hydrate) {
		// New API introduced in React 16
		// for "hydrating" Server-Side Rendered markup.
		// https://reactjs.org/docs/react-dom.html#hydrate
		return _reactDom2.default.hydrate(element, to);
	}
	// Clears `element` to prevent React warning:
	// "Calling ReactDOM.render() to hydrate server-rendered markup
	//  will stop working in React v17. Replace the ReactDOM.render() call
	//  with ReactDOM.hydrate() if you want React to attach to the server HTML."
	if (!window._react_website_hot_reload) {
		while (to.firstChild) {
			to.removeChild(to.firstChild);
		}
	}
	return _reactDom2.default.render(element, to);
}

// Retrieves a variable from `window` erasing it.
function getGlobalVariable(name) {
	var variable = window[name];
	if (variable !== undefined) {
		delete window[name];
	}
	return variable;
}

function getReactContainerElement() {
	var element = document.getElementById('react');

	if (!element) {
		var body = document.body;
		if (!body) {
			throw new Error('<body/> tag not found, make sure this script is added to the end of <body/> rather than inside <head/>.');
		}
		element = document.createElement('div');
		element.setAttribute('id', 'react');
		body.appendChild(element);
	}

	return element;
}
//# sourceMappingURL=render.js.map