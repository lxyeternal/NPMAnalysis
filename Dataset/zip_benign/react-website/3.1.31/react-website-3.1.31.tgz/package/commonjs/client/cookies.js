'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.getCookie = getCookie;
// https://learn.javascript.ru/cookie
function getCookie(name) {
	var matches = document.cookie.match(new RegExp('(?:^|; )' + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + '=([^;]*)'));
	if (matches) {
		return decodeURIComponent(matches[1]);
	}
}
//# sourceMappingURL=cookies.js.map