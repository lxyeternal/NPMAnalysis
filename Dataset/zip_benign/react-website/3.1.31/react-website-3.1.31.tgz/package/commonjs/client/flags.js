"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.isServerSidePreloaded = isServerSidePreloaded;
exports.isServerSideRendered = isServerSideRendered;
function isServerSidePreloaded() {
	return window._server_side_render && !window._react_website_reload_data;
}

function isServerSideRendered() {
	return window._server_side_render && !window._empty_server_side_render;
}
//# sourceMappingURL=flags.js.map