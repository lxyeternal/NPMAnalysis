'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.getDisplayName = getDisplayName;
function getDisplayName(Component) {
	return Component.displayName || Component.name || 'Component';
}
//# sourceMappingURL=utility.js.map