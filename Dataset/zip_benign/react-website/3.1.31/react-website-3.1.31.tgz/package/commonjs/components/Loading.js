'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.Loading = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _class, _temp;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _propTypes = require('prop-types');

var _propTypes2 = _interopRequireDefault(_propTypes);

var _reactRedux = require('react-redux');

var _classnames = require('classnames');

var _classnames2 = _interopRequireDefault(_classnames);

var _LoadingIndicator = require('./LoadingIndicator');

var _LoadingIndicator2 = _interopRequireDefault(_LoadingIndicator);

var _FadeInOut = require('./FadeInOut');

var _FadeInOut2 = _interopRequireDefault(_FadeInOut);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var Loading = exports.Loading = (_temp = _class = function (_React$Component) {
	_inherits(Loading, _React$Component);

	function Loading() {
		_classCallCheck(this, Loading);

		return _possibleConstructorReturn(this, (Loading.__proto__ || Object.getPrototypeOf(Loading)).apply(this, arguments));
	}

	_createClass(Loading, [{
		key: 'render',
		value: function render() {
			var _props = this.props,
			    initial = _props.initial,
			    pending = _props.pending,
			    immediate = _props.immediate,
			    Indicator = _props.indicator,
			    fadeOutDuration = _props.fadeOutDuration;


			return _react2.default.createElement(
				'div',
				{
					className: (0, _classnames2.default)('rrui__fixed-full-width', 'react-website__loading', {
						'react-website__loading--initial': initial,
						'react-website__loading--shown': pending,
						'react-website__loading--immediate': immediate
					}) },
				_react2.default.createElement(
					_FadeInOut2.default,
					{ show: pending, fadeOutDuration: fadeOutDuration },
					_react2.default.createElement(Indicator, { className: 'react-website__loading-spinner' })
				)
			);
		}
	}]);

	return Loading;
}(_react2.default.Component), _class.propTypes = {
	initial: _propTypes2.default.bool.isRequired,
	pending: _propTypes2.default.bool.isRequired,
	immediate: _propTypes2.default.bool.isRequired,
	indicator: _propTypes2.default.func.isRequired,
	fadeOutDuration: _propTypes2.default.number.isRequired
}, _class.defaultProps = {
	indicator: _LoadingIndicator2.default,
	fadeOutDuration: 160
}, _temp);
exports.default = (0, _reactRedux.connect)(function (_ref) {
	var preload = _ref.preload;
	return {
		initial: preload.initial,
		pending: preload.pending,
		immediate: preload.immediate
	};
})(Loading);
//# sourceMappingURL=Loading.js.map