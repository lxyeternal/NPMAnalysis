'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; // Copy-pasted from `react-responsive-ui/src/ActivityIndicator.js`.

// Taken from:
// https://loading.io/css/
//
// A colored variation:
// https://codeburst.io/how-to-create-a-simple-css-loading-spinner-make-it-accessible-e5c83c2e464c

exports.default = ActivityIndicator;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _propTypes = require('prop-types');

var _propTypes2 = _interopRequireDefault(_propTypes);

var _classnames = require('classnames');

var _classnames2 = _interopRequireDefault(_classnames);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function ActivityIndicator(props) {
	var className = props.className;


	return _react2.default.createElement(
		'div',
		_extends({}, props, {
			className: (0, _classnames2.default)('rrui__activity-indicator', className) }),
		_react2.default.createElement('div', { className: 'rrui__activity-indicator__arc' }),
		_react2.default.createElement('div', { className: 'rrui__activity-indicator__arc' }),
		_react2.default.createElement('div', { className: 'rrui__activity-indicator__arc' }),
		_react2.default.createElement('div', { className: 'rrui__activity-indicator__arc' })
	);
}

ActivityIndicator.propTypes = {
	// CSS class
	className: _propTypes2.default.string,

	// CSS style object
	style: _propTypes2.default.object
};
//# sourceMappingURL=LoadingIndicator.js.map