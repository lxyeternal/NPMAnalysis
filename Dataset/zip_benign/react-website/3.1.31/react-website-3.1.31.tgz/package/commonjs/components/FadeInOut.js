'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _class, _temp2;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _propTypes = require('prop-types');

var _propTypes2 = _interopRequireDefault(_propTypes);

var _classnames = require('classnames');

var _classnames2 = _interopRequireDefault(_classnames);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var FadeInOut = (_temp2 = _class = function (_React$Component) {
	_inherits(FadeInOut, _React$Component);

	function FadeInOut() {
		var _ref;

		var _temp, _this, _ret;

		_classCallCheck(this, FadeInOut);

		for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
			args[_key] = arguments[_key];
		}

		return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = FadeInOut.__proto__ || Object.getPrototypeOf(FadeInOut)).call.apply(_ref, [this].concat(args))), _this), _this.state = {
			show: _this.props.show
		}, _this.hide = function () {
			var fadeOutDuration = _this.props.fadeOutDuration;


			clearTimeout(_this.showTimer);

			if (!_this._isMounted) {
				return;
			}

			_this.setState({
				show: false,
				fadeIn: false,
				fadeOut: true
			});

			// Gives some time to CSS opacity transition to finish.
			_this.hideTimer = setTimeout(function () {
				if (_this._isMounted) {
					_this.setState({
						fadeOut: false
					});
				}
			}, fadeOutDuration);
		}, _temp), _possibleConstructorReturn(_this, _ret);
	}

	_createClass(FadeInOut, [{
		key: 'componentDidUpdate',
		value: function componentDidUpdate(prevProps) {
			if (!prevProps.show && this.props.show) {
				this.show();
			} else if (prevProps.show && !this.props.show) {
				this.hide();
			}
		}
	}, {
		key: 'componentDidMount',
		value: function componentDidMount() {
			this._isMounted = true;
		}
	}, {
		key: 'componentWillUnmount',
		value: function componentWillUnmount() {
			this._isMounted = false;

			clearTimeout(this.showTimer);
			clearTimeout(this.hideTimer);
		}
	}, {
		key: 'show',
		value: function show() {
			var _this2 = this;

			clearTimeout(this.showTimer);
			clearTimeout(this.hideTimer);

			this.setState({
				show: true,
				fadeIn: false,
				fadeOut: false
			});

			this.showTimer = setTimeout(function () {
				if (_this2._isMounted) {
					_this2.setState({
						fadeIn: true
					});
				}
			},
			// Adding a non-null delay in order to
			// prevent web browser from optimizing
			// adding CSS classes and doing it simultaneously
			// rather than sequentially (required for CSS transition).
			10);
		}
	}, {
		key: 'render',
		value: function render() {
			var _props = this.props,
			    fadeInClassName = _props.fadeInClassName,
			    hiddenClassName = _props.hiddenClassName,
			    children = _props.children;
			var _state = this.state,
			    show = _state.show,
			    fadeIn = _state.fadeIn,
			    fadeOut = _state.fadeOut;


			if (show || fadeOut) {
				if (fadeInClassName) {
					return _react2.default.cloneElement(children, {
						className: (0, _classnames2.default)(children.props.className, _defineProperty({}, fadeInClassName, fadeIn))
					});
				}
				return children;
			}

			if (hiddenClassName) {
				return _react2.default.cloneElement(children, {
					className: (0, _classnames2.default)(children.props.className, hiddenClassName)
				});
			}

			return null;
		}
	}]);

	return FadeInOut;
}(_react2.default.Component), _class.propTypes = {
	show: _propTypes2.default.bool.isRequired,
	hiddenClassName: _propTypes2.default.string,
	fadeOutDuration: _propTypes2.default.number.isRequired,
	fadeInClassName: _propTypes2.default.string,
	children: _propTypes2.default.node.isRequired
}, _class.defaultProps = {
	show: false
}, _temp2);
exports.default = FadeInOut;
//# sourceMappingURL=FadeInOut.js.map