'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.default = undefined;

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _dec, _class, _class2, _temp;

var _react = require('react');

var _react2 = _interopRequireDefault(_react);

var _propTypes = require('prop-types');

var _propTypes2 = _interopRequireDefault(_propTypes);

var _reactRedux = require('react-redux');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var RemountOnNavigate = (_dec = (0, _reactRedux.connect)(function (_ref) {
	var preload = _ref.preload,
	    found = _ref.found;
	return {
		preloading: preload.pending,
		matchedLocation: found.match.location,
		previousLocation: found.resolvedMatch.location
	};
}), _dec(_class = (_temp = _class2 = function (_React$Component) {
	_inherits(RemountOnNavigate, _React$Component);

	function RemountOnNavigate() {
		_classCallCheck(this, RemountOnNavigate);

		return _possibleConstructorReturn(this, (RemountOnNavigate.__proto__ || Object.getPrototypeOf(RemountOnNavigate)).apply(this, arguments));
	}

	_createClass(RemountOnNavigate, [{
		key: 'render',
		value: function render() {
			var _props = this.props,
			    preloading = _props.preloading,
			    matchedLocation = _props.matchedLocation,
			    previousLocation = _props.previousLocation,
			    children = _props.children;


			var location = preloading ? previousLocation : matchedLocation;

			return _react2.default.createElement(
				'div',
				{
					key: '' + location.pathname + location.search,
					className: 'remount-container' },
				children
			);
		}
	}]);

	return RemountOnNavigate;
}(_react2.default.Component), _class2.propTypes = {
	matchedLocation: _propTypes2.default.object.isRequired,
	previousLocation: _propTypes2.default.object.isRequired,
	children: _propTypes2.default.node.isRequired
}, _temp)) || _class);
exports.default = RemountOnNavigate;
//# sourceMappingURL=RemountOnNavigate.js.map