import { Location } from '@angular/common';
import { Observable } from 'rxjs';
import { StorageService } from './storage.service';
import { MultiWindowConfig } from '../types/multi-window.config';
import { KnownAppWindow } from '../types/window.type';
import { Message } from '../types/message.type';
import { WindowRef } from '../providers/window.provider';
import * as i0 from "@angular/core";
export declare class MultiWindowService {
    private location;
    private storageService;
    private windowRef;
    private config;
    private myWindow;
    private heartbeatId;
    private windowScanId;
    private knownWindows;
    /**
     * A hash that keeps track of subjects for all send messages
     */
    private messageTracker;
    /**
     * A copy of the outbox that is regularly written to the local storage
     */
    private outboxCache;
    /**
     * A subject to subscribe to in order to get notified about messages send to this window
     */
    private messageSubject;
    /**
     * A subject to subscribe to in order to get notified about all known windows
     */
    private windowSubject;
    private static generateId;
    private tryMatchWindowKey;
    private generatePayloadKey;
    private generateWindowKey;
    private isWindowKey;
    constructor(customConfig: MultiWindowConfig, location: Location, storageService: StorageService, windowRef: WindowRef);
    get name(): string;
    set name(value: string);
    get id(): string;
    /**
     * An observable to subscribe to. It emits all messages the current window receives.
     * After a message has been emitted by this observable it is marked as read, so the sending window
     * gets informed about successful delivery.
     */
    onMessage(): Observable<Message>;
    /**
     * An observable to subscribe to. It emits the array of known windows
     * whenever it is read again from the localstorage.
     *
     * This Observable emits the last list of known windows on subscription
     * (refer to rxjs BehaviorSubject).
     *
     * Use {@link getKnownWindows} to get the current list of
     * known windows or if you only need a snapshot of that list.
     *
     * @see {@link MultiWindowConfig#newWindowScan}
     * @returns
     */
    onWindows(): Observable<KnownAppWindow[]>;
    /**
     * Get the latest list of known windows.
     *
     * Use {@link onWindows} to get an observable which emits
     * whenever is updated.
     */
    getKnownWindows(): KnownAppWindow[];
    /**
     * Start so that the current instance of the angular app/service/tab participates in the cross window communication.
     * It starts the interval-based checking for messages and updating the heartbeat.
     *
     * Note: There should be no need to call this method in production apps. It will automatically be called internally
     * during service construction (see {@link MultiWindowService} constructor)
     */
    start(): void;
    /**
     * Stop the current instance of the angular app/service/tab from participating in the cross window communication.
     * It stops the interval-based checking for messages and updating the heartbeat.
     *
     * Note: There should be no need to call this method in production apps.
     */
    stop(): void;
    /**
     * Remove the current window representation from the localstorage.
     *
     * Note: Unless you {@link stop}ped the service the window representation will be
     * recreated after {@link MultiWindowConfig#heartbeat} milliseconds
     */
    clear(): void;
    /**
     * Send a message to another window.
     *
     * @param recipientId The ID of the recipient window.
     * @param event Custom identifier to distinguish certain events
     * @param data Custom data to contain the data for the event
     * @param payload Further data to be passed to the recipient window via a separate entry in the localstorage
     * @returns An observable that emits the messageId once the message has been put into
     * the current windows outbox. It completes on successful delivery and fails if the delivery times out.
     */
    sendMessage(recipientId: string, event: string, data: any, payload?: any): Observable<string>;
    /**
     * Create a new window and get informed once it has been created.
     *
     * Note: The actual window "creation" of redirection needs to be performed by
     * the library user. This method only returns helpful information on how to
     * do that
     *
     * The returned object contains three properties:
     *
     * windowId: An id generated to be assigned to the newly created window
     *
     * urlString: This string must be included in the url the new window loads.
     * It does not matter whether it is in the path, query or hash part
     *
     * created: An observable that will complete after new window was opened and was able
     * to receive a message. If the window does not start consuming messages within
     * {@link MultiWindowConfig#messageTimeout}, this observable will fail, although
     * the window might become present after that. The Observable will never emit any elements.
     */
    newWindow(): {
        windowId: string;
        urlString: string;
        created: Observable<string>;
    };
    saveWindow(): void;
    private init;
    private pushToOutbox;
    private heartbeat;
    private scanForWindows;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiWindowService, [null, { optional: true; }, null, null]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MultiWindowService>;
}
//# sourceMappingURL=multi-window.service.d.ts.map