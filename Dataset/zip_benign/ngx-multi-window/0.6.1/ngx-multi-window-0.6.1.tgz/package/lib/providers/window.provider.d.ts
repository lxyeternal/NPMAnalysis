import * as i0 from "@angular/core";
export declare class WindowRef {
    get nativeWindow(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<WindowRef, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WindowRef>;
}
//# sourceMappingURL=window.provider.d.ts.map