import { Optional } from '@angular/core';
import * as i0 from "@angular/core";
export declare class StorageService {
    private window;
    private localStorage;
    private sessionStorage;
    constructor();
    setLocalObject(key: string, obj: any): boolean;
    setLocalItem(key: string, obj: string): void;
    setSessionObject(key: string, obj: any): boolean;
    setSessionItem(key: string, obj: string): void;
    private setObject;
    private setItem;
    setWindowName(value: string): void;
    getLocalObject<T>(key: string): T | null;
    getLocalObjects<T>(keys: string[]): (T | null)[];
    getLocalItem(key: string): string | null;
    getSessionObject<T>(key: string): T | null;
    getSessionObjects<T>(keys: string[]): (T | null)[];
    getSessionItem(key: string): string | null;
    getObjects<T>(storage: Storage, keys: string[]): (T | null)[];
    private getObject;
    private getItem;
    getWindowName(): string;
    removeLocalItem(key: string): void;
    removeSessionItem(key: string): void;
    private removeItem;
    clearLocalStorage(): void;
    clearSessionStorage(): void;
    private clearStorage;
    getLocalItemKeys(): string[];
    getSessionItemKeys(): string[];
    private getStorageItemKeys;
    static ɵfac: i0.ɵɵFactoryDeclaration<StorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StorageService>;
}
export declare const StorageServiceProviderFactory: (parentDispatcher: StorageService) => StorageService;
export declare const StorageServiceProvider: {
    provide: typeof StorageService;
    deps: Optional[][];
    useFactory: (parentDispatcher: StorageService) => StorageService;
};
//# sourceMappingURL=storage.service.d.ts.map