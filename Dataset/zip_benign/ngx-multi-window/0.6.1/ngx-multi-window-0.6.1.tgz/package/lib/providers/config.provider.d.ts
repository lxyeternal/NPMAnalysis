import { InjectionToken } from '@angular/core';
import { MultiWindowConfig } from '../types/multi-window.config';
export declare const NGXMW_CONFIG: InjectionToken<MultiWindowConfig>;
export declare const defaultMultiWindowConfig: MultiWindowConfig;
//# sourceMappingURL=config.provider.d.ts.map