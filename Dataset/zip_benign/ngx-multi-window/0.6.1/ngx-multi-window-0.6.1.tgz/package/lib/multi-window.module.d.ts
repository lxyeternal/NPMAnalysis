import { ModuleWithProviders } from '@angular/core';
import { MultiWindowConfig } from './types/multi-window.config';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export declare class MultiWindowModule {
    static forRoot(config?: MultiWindowConfig): ModuleWithProviders<MultiWindowModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiWindowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MultiWindowModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MultiWindowModule>;
}
//# sourceMappingURL=multi-window.module.d.ts.map