export declare enum MessageType {
    MESSAGE = 0,
    MESSAGE_RECEIVED = 1,
    PING = 2
}
export interface MessageTemplate {
    recipientId: string;
    type: MessageType;
    event: string;
    data?: any;
    payload?: any;
}
export interface Message extends MessageTemplate {
    send?: boolean;
    messageId: string;
    sendTime: number;
    senderId: string;
}
//# sourceMappingURL=message.type.d.ts.map