import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { InjectionToken, Injectable, Optional, SkipSelf, Inject, NgModule } from '@angular/core';
import { Subject, BehaviorSubject } from 'rxjs';
import { ignoreElements } from 'rxjs/operators';

/**
 * A representation of a strategy on how to save the window id in the native window.name property.
 */
var WindowSaveStrategy;
(function (WindowSaveStrategy) {
    /**
     * Default behaviour. Window data will not be saved.
     */
    WindowSaveStrategy[WindowSaveStrategy["NONE"] = 0] = "NONE";
    /**
     * Only save the window data when the storage (native window.name property) is empty/undefined, meaning nothing else is
     * probably utilizing it
     */
    WindowSaveStrategy[WindowSaveStrategy["SAVE_WHEN_EMPTY"] = 1] = "SAVE_WHEN_EMPTY";
    /**
     * Save the window data without checking whether the storage might be used by another script
     */
    WindowSaveStrategy[WindowSaveStrategy["SAVE_FORCE"] = 2] = "SAVE_FORCE";
    /**
     * Save window data, but backup probable existing data in the storage and restore the original data after reading the window data.
     * Restoring the original data might not happen "on time" for the script using it, which would require delaying it's execution.
     */
    WindowSaveStrategy[WindowSaveStrategy["SAVE_BACKUP"] = 3] = "SAVE_BACKUP";
})(WindowSaveStrategy || (WindowSaveStrategy = {}));

const NGXMW_CONFIG = new InjectionToken('ngxmw_config');
const defaultMultiWindowConfig = {
    keyPrefix: 'ngxmw_',
    heartbeat: 1000,
    newWindowScan: 5000,
    messageTimeout: 10000,
    windowTimeout: 15000,
    windowSaveStrategy: WindowSaveStrategy.NONE,
};

var MessageType;
(function (MessageType) {
    MessageType[MessageType["MESSAGE"] = 0] = "MESSAGE";
    MessageType[MessageType["MESSAGE_RECEIVED"] = 1] = "MESSAGE_RECEIVED";
    MessageType[MessageType["PING"] = 2] = "PING";
})(MessageType || (MessageType = {}));

class StorageService {
    constructor() {
        this.window = window;
        this.localStorage = window.localStorage;
        this.sessionStorage = window.sessionStorage;
    }
    /*
     Write methods
     */
    setLocalObject(key, obj) {
        return this.setObject(this.localStorage, key, obj);
    }
    setLocalItem(key, obj) {
        this.setItem(this.localStorage, key, obj);
    }
    setSessionObject(key, obj) {
        return this.setObject(this.sessionStorage, key, obj);
    }
    setSessionItem(key, obj) {
        this.setItem(this.sessionStorage, key, obj);
    }
    setObject(storage, key, obj) {
        let jsonString;
        try {
            jsonString = JSON.stringify(obj);
        }
        catch (ex) {
            return false;
        }
        this.setItem(storage, key, jsonString);
        return true;
    }
    setItem(storage, key, obj) {
        storage.setItem(key, obj);
    }
    setWindowName(value) {
        this.window.name = value;
    }
    /*
     Read methods
     */
    getLocalObject(key) {
        return this.getObject(this.localStorage, key);
    }
    getLocalObjects(keys) {
        return this.getObjects(this.localStorage, keys);
    }
    getLocalItem(key) {
        return this.getItem(this.localStorage, key);
    }
    getSessionObject(key) {
        return this.getObject(this.sessionStorage, key);
    }
    getSessionObjects(keys) {
        return this.getObjects(this.sessionStorage, keys);
    }
    getSessionItem(key) {
        return this.getItem(this.sessionStorage, key);
    }
    getObjects(storage, keys) {
        return keys.map(key => this.getObject(storage, key));
    }
    getObject(storage, key) {
        const jsonString = this.getItem(storage, key);
        if (jsonString === null) {
            return null;
        }
        try {
            return JSON.parse(jsonString);
        }
        catch (ex) {
            return null;
        }
    }
    getItem(storage, key) {
        return storage.getItem(key) || null;
    }
    getWindowName() {
        return this.window.name;
    }
    /*
     Remove methods
     */
    removeLocalItem(key) {
        this.removeItem(this.localStorage, key);
    }
    removeSessionItem(key) {
        this.removeItem(this.sessionStorage, key);
    }
    removeItem(storage, key) {
        storage.removeItem(key);
    }
    clearLocalStorage() {
        this.clearStorage(this.localStorage);
    }
    clearSessionStorage() {
        this.clearStorage(this.sessionStorage);
    }
    clearStorage(storage) {
        storage.clear();
    }
    /*
     Inspection methods
     */
    getLocalItemKeys() {
        return this.getStorageItemKeys(this.localStorage);
    }
    getSessionItemKeys() {
        return this.getStorageItemKeys(this.sessionStorage);
    }
    getStorageItemKeys(storage) {
        const keys = [];
        for (let i = 0; i < storage.length; i++) {
            keys.push(storage.key(i));
        }
        return keys;
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.1.5", ngImport: i0, type: StorageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    /** @nocollapse */ static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.1.5", ngImport: i0, type: StorageService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.1.5", ngImport: i0, type: StorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return []; } });
/* singleton pattern taken from https://github.com/angular/angular/issues/13854 */
const StorageServiceProviderFactory = (parentDispatcher) => {
    return parentDispatcher || new StorageService();
};
const StorageServiceProvider = {
    provide: StorageService,
    deps: [[new Optional(), new SkipSelf(), StorageService]],
    useFactory: StorageServiceProviderFactory,
};

const _window = () => {
    // return the global native browser window object
    return window;
};
class WindowRef {
    get nativeWindow() {
        return _window();
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.1.5", ngImport: i0, type: WindowRef, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    /** @nocollapse */ static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.1.5", ngImport: i0, type: WindowRef }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.1.5", ngImport: i0, type: WindowRef, decorators: [{
            type: Injectable
        }] });

class MultiWindowService {
    static generateId() {
        return new Date().getTime().toString(36).substr(-4) + Math.random().toString(36).substr(2, 9);
    }
    tryMatchWindowKey(source) {
        const nameRegex = new RegExp(
        // Escape any potential regex-specific chars in the keyPrefix which may be changed by the dev
        this.config.keyPrefix.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&') + 'w_([a-z0-9]+)');
        const match = source.match(nameRegex);
        if (match !== null) {
            return match[1];
        }
        return null;
    }
    generatePayloadKey({ messageId }) {
        return this.config.keyPrefix + 'payload_' + messageId;
    }
    generateWindowKey(windowId) {
        return this.config.keyPrefix + 'w_' + windowId;
    }
    isWindowKey(key) {
        return key.indexOf(this.config.keyPrefix + 'w_') === 0;
    }
    constructor(customConfig, location, storageService, windowRef) {
        this.location = location;
        this.storageService = storageService;
        this.windowRef = windowRef;
        this.heartbeatId = null;
        this.windowScanId = null;
        this.knownWindows = [];
        /**
         * A hash that keeps track of subjects for all send messages
         */
        this.messageTracker = {};
        /**
         * A copy of the outbox that is regularly written to the local storage
         */
        this.outboxCache = {};
        /**
         * A subject to subscribe to in order to get notified about messages send to this window
         */
        this.messageSubject = new Subject();
        /**
         * A subject to subscribe to in order to get notified about all known windows
         */
        this.windowSubject = new BehaviorSubject(this.knownWindows);
        this.heartbeat = () => {
            const now = new Date().getTime();
            // Check whether there are new messages for the current window in the other window's outboxes
            // Store the ids of all messages we receive in this iteration
            const receivedMessages = [];
            this.knownWindows.forEach(windowData => {
                // Load the window from the localstorage
                const appWindow = this.storageService.getLocalObject(this.generateWindowKey(windowData.id));
                if (appWindow === null) {
                    // No window found, it possibly got closed/removed since our last scanForWindow
                    return;
                }
                if (appWindow.id === this.myWindow.id) {
                    // Ignore messages from myself (not done using Array.filter to reduce array iterations)
                    // but check for proper last heartbeat time
                    if (this.myWindow.heartbeat !== -1 && this.myWindow.heartbeat !== appWindow.heartbeat) {
                        // The heartbeat value in the localstorage is a different one than the one we wrote into localstorage
                        // during our last heartbeat. There are probably two app windows
                        // using the same window id => change the current windows id
                        this.myWindow.id = MultiWindowService.generateId();
                        // eslint-disable-next-line no-console
                        console.warn('Window ' + appWindow.id + '  detected that there is probably another instance with' +
                            ' this id, changed id to ' + this.myWindow.id);
                        this.storageService.setWindowName(this.generateWindowKey(this.myWindow.id));
                    }
                    return;
                }
                if (now - appWindow.heartbeat > this.config.windowTimeout) {
                    // The window seems to be dead, remove the entry from the localstorage
                    this.storageService.removeLocalItem(this.generateWindowKey(appWindow.id));
                }
                // Update the windows name and heartbeat value in the list of known windows (that's what we iterate over)
                windowData.name = appWindow.name;
                windowData.heartbeat = appWindow.heartbeat;
                if (appWindow.messages && appWindow.messages.length > 0) {
                    // This other window has messages, so iterate over the messages the other window has
                    appWindow.messages.forEach(message => {
                        if (message.recipientId !== this.myWindow.id) {
                            // The message is not targeted to the current window
                            return;
                        }
                        if (message.type === MessageType.MESSAGE_RECEIVED) {
                            // It's a message to inform the current window that a previously sent message from the
                            // current window has been processed by the recipient window
                            // Trigger the observable to complete and then remove it
                            if (this.messageTracker[message.messageId]) {
                                this.messageTracker[message.messageId].complete();
                            }
                            delete this.messageTracker[message.messageId];
                            // Remove the message from the outbox, as the transfer is complete
                            delete this.outboxCache[message.messageId];
                        }
                        else {
                            receivedMessages.push(message.messageId);
                            // Check whether we already processed that message. If that's the case we've got a 'message_received'
                            // confirmation in our own outbox.
                            if (!(this.outboxCache[message.messageId] &&
                                this.outboxCache[message.messageId].type === MessageType.MESSAGE_RECEIVED)) {
                                // We did not process that message
                                // Create a new message for the message sender in the current window's
                                // outbox that the message has been processed (reuse the message id for that)
                                this.pushToOutbox({
                                    recipientId: message.senderId,
                                    type: MessageType.MESSAGE_RECEIVED,
                                    event: undefined,
                                }, message.messageId);
                                // Process it locally, unless it's just a PING message
                                if (message.type !== MessageType.PING) {
                                    if (message.payload === true) {
                                        // The message has a separate payload
                                        const payloadKey = this.generatePayloadKey(message);
                                        message.payload = this.storageService.getLocalObject(payloadKey);
                                        this.storageService.removeLocalItem(payloadKey);
                                    }
                                    this.messageSubject.next(message);
                                }
                            }
                        }
                    });
                }
            });
            // Iterate over the outbox to clean it up, process timeouts and payloads
            Object.keys(this.outboxCache).forEach(messageId => {
                const message = this.outboxCache[messageId];
                if (message.type === MessageType.MESSAGE_RECEIVED && !receivedMessages.some(msgId => msgId === messageId)) {
                    // It's a message confirmation and we did not receive the 'original' method for that confirmation
                    // => the sender has received our confirmation and removed the message from it's outbox, thus we can
                    //     safely remove the message confirmation as well
                    delete this.outboxCache[messageId];
                }
                else if (message.type !== MessageType.MESSAGE_RECEIVED && now - message.sendTime > this.config.messageTimeout) {
                    // Delivering the message has failed, as the target window did not pick it up in time
                    // The type of message doesn't matter for that
                    delete this.outboxCache[messageId];
                    if (this.messageTracker[messageId]) {
                        this.messageTracker[messageId].error('Timeout');
                    }
                    delete this.messageTracker[messageId];
                }
                else if (message.type === MessageType.MESSAGE && message.send === false) {
                    if (message.payload !== undefined && message.payload !== true) {
                        // Message has a payload that has not been moved yet, so move that in a separate localstorage key
                        this.storageService.setLocalObject(this.generatePayloadKey(message), message.payload);
                        message.payload = true;
                    }
                    this.messageTracker[message.messageId].next(message.messageId);
                    // Set property to undefined, as we do not need to encode "send:true" in the localstorage json multiple times
                    message.send = undefined;
                }
            });
            this.storageService.setLocalObject(this.generateWindowKey(this.myWindow.id), {
                heartbeat: now,
                id: this.myWindow.id,
                name: this.myWindow.name,
                messages: Object.keys(this.outboxCache).map(key => this.outboxCache[key]),
            });
            if (this.myWindow.heartbeat === -1) {
                // This was the first heartbeat run for the local window, so rescan for known windows to get
                // the current (new) window in the list
                this.scanForWindows();
            }
            // Store the new heartbeat value in the local windowData copy
            this.myWindow.heartbeat = now;
        };
        this.scanForWindows = () => {
            this.knownWindows = this.storageService.getLocalObjects(this.storageService.getLocalItemKeys().filter((key) => this.isWindowKey(key)))
                .map(({ id, name, heartbeat }) => {
                return {
                    id,
                    name,
                    heartbeat,
                    stalled: new Date().getTime() - heartbeat > this.config.heartbeat * 2,
                    self: this.myWindow.id === id,
                };
            });
            this.windowSubject.next(this.knownWindows);
        };
        this.config = { ...defaultMultiWindowConfig, ...customConfig };
        let windowId;
        if (this.location) {
            // Try to extract the new window name from the location path
            windowId = this.tryMatchWindowKey(this.location.path(true));
        }
        // Only check the name save strategy if no id has been extracted from the path already
        if (!windowId && this.config.windowSaveStrategy !== WindowSaveStrategy.NONE) {
            // There might be window data stored in the window.name property, try restoring it
            const storedWindowData = this.windowRef.nativeWindow.name;
            if (this.config.windowSaveStrategy === WindowSaveStrategy.SAVE_BACKUP) {
                // There should be a JSON string in the window.name, try parsing it and set the values
                try {
                    const storedJsonData = JSON.parse(storedWindowData);
                    windowId = storedJsonData.ngxmw_id;
                    this.windowRef.nativeWindow.name = storedJsonData.backup;
                }
                catch (ex) { // Swallow JSON parsing exceptions, as we can't handle them anyway
                }
            }
            else {
                windowId = this.tryMatchWindowKey(storedWindowData);
                if (this.config.windowSaveStrategy === WindowSaveStrategy.SAVE_WHEN_EMPTY) {
                    this.windowRef.nativeWindow.name = '';
                }
            }
        }
        this.init(windowId);
        this.start();
    }
    get name() {
        return this.myWindow.name;
    }
    set name(value) {
        this.myWindow.name = value;
    }
    get id() {
        return this.myWindow.id;
    }
    /**
     * An observable to subscribe to. It emits all messages the current window receives.
     * After a message has been emitted by this observable it is marked as read, so the sending window
     * gets informed about successful delivery.
     */
    onMessage() {
        return this.messageSubject.asObservable();
    }
    /**
     * An observable to subscribe to. It emits the array of known windows
     * whenever it is read again from the localstorage.
     *
     * This Observable emits the last list of known windows on subscription
     * (refer to rxjs BehaviorSubject).
     *
     * Use {@link getKnownWindows} to get the current list of
     * known windows or if you only need a snapshot of that list.
     *
     * @see {@link MultiWindowConfig#newWindowScan}
     * @returns
     */
    onWindows() {
        return this.windowSubject.asObservable();
    }
    /**
     * Get the latest list of known windows.
     *
     * Use {@link onWindows} to get an observable which emits
     * whenever is updated.
     */
    getKnownWindows() {
        return this.knownWindows;
    }
    /**
     * Start so that the current instance of the angular app/service/tab participates in the cross window communication.
     * It starts the interval-based checking for messages and updating the heartbeat.
     *
     * Note: There should be no need to call this method in production apps. It will automatically be called internally
     * during service construction (see {@link MultiWindowService} constructor)
     */
    start() {
        if (!this.heartbeatId) {
            this.heartbeatId = setInterval(this.heartbeat, this.config.heartbeat);
        }
        if (!this.windowScanId) {
            this.windowScanId = setInterval(this.scanForWindows, this.config.newWindowScan);
        }
    }
    /**
     * Stop the current instance of the angular app/service/tab from participating in the cross window communication.
     * It stops the interval-based checking for messages and updating the heartbeat.
     *
     * Note: There should be no need to call this method in production apps.
     */
    stop() {
        if (this.heartbeatId) {
            clearInterval(this.heartbeatId);
            this.heartbeatId = null;
        }
        if (this.windowScanId) {
            clearInterval(this.windowScanId);
            this.windowScanId = null;
        }
    }
    /**
     * Remove the current window representation from the localstorage.
     *
     * Note: Unless you {@link stop}ped the service the window representation will be
     * recreated after {@link MultiWindowConfig#heartbeat} milliseconds
     */
    clear() {
        this.storageService.removeLocalItem(this.generateWindowKey(this.myWindow.id));
    }
    /**
     * Send a message to another window.
     *
     * @param recipientId The ID of the recipient window.
     * @param event Custom identifier to distinguish certain events
     * @param data Custom data to contain the data for the event
     * @param payload Further data to be passed to the recipient window via a separate entry in the localstorage
     * @returns An observable that emits the messageId once the message has been put into
     * the current windows outbox. It completes on successful delivery and fails if the delivery times out.
     */
    sendMessage(recipientId, event, data, payload) {
        const messageId = this.pushToOutbox({
            recipientId,
            type: MessageType.MESSAGE,
            event,
            data,
            payload,
        });
        this.messageTracker[messageId] = new Subject();
        return this.messageTracker[messageId].asObservable();
    }
    /**
     * Create a new window and get informed once it has been created.
     *
     * Note: The actual window "creation" of redirection needs to be performed by
     * the library user. This method only returns helpful information on how to
     * do that
     *
     * The returned object contains three properties:
     *
     * windowId: An id generated to be assigned to the newly created window
     *
     * urlString: This string must be included in the url the new window loads.
     * It does not matter whether it is in the path, query or hash part
     *
     * created: An observable that will complete after new window was opened and was able
     * to receive a message. If the window does not start consuming messages within
     * {@link MultiWindowConfig#messageTimeout}, this observable will fail, although
     * the window might become present after that. The Observable will never emit any elements.
     */
    newWindow() {
        if (this.location === null) {
            // Reading information from the URL is only possible with the Location provider. If
            // this window does not have one, another one will have none as well and thus would
            // not be able to read its new windowId from the url path
            throw new Error('No Location Provider present');
        }
        const newWindowId = MultiWindowService.generateId();
        const messageId = this.pushToOutbox({
            recipientId: newWindowId,
            type: MessageType.PING,
            event: undefined,
            data: undefined,
            payload: undefined,
        });
        this.messageTracker[messageId] = new Subject();
        return {
            windowId: newWindowId,
            urlString: this.generateWindowKey(newWindowId),
            created: this.messageTracker[messageId].pipe(ignoreElements()),
        };
    }
    saveWindow() {
        if (this.config.windowSaveStrategy !== WindowSaveStrategy.NONE) {
            const windowId = this.generateWindowKey(this.id);
            if ((this.config.windowSaveStrategy === WindowSaveStrategy.SAVE_WHEN_EMPTY && !this.windowRef.nativeWindow.name)
                || this.config.windowSaveStrategy === WindowSaveStrategy.SAVE_FORCE) {
                this.windowRef.nativeWindow.name = windowId;
            }
            else if (this.config.windowSaveStrategy === WindowSaveStrategy.SAVE_BACKUP) {
                this.windowRef.nativeWindow.name = JSON.stringify({ ngxmw_id: windowId, backup: this.windowRef.nativeWindow.name });
            }
        }
    }
    init(windowId) {
        const windowKey = windowId
            ? this.generateWindowKey(windowId)
            : this.storageService.getWindowName();
        let windowData = null;
        if (windowKey && this.isWindowKey(windowKey)) {
            windowData = this.storageService.getLocalObject(windowKey);
        }
        if (windowData !== null) {
            // Restore window information from storage
            this.myWindow = {
                id: windowData.id,
                name: windowData.name,
                heartbeat: windowData.heartbeat,
            };
        }
        else {
            const myWindowId = windowId || MultiWindowService.generateId();
            this.myWindow = {
                id: myWindowId,
                name: 'AppWindow ' + myWindowId,
                heartbeat: -1,
            };
        }
        this.storageService.setWindowName(windowKey);
        // Scan for already existing windows
        this.scanForWindows();
        // Trigger heartbeat for the first time
        this.heartbeat();
    }
    pushToOutbox({ recipientId, type, event, data, payload }, messageId = MultiWindowService.generateId()) {
        if (recipientId === this.id) {
            throw new Error('Cannot send messages to self');
        }
        this.outboxCache[messageId] = {
            messageId,
            recipientId,
            senderId: this.myWindow.id,
            sendTime: new Date().getTime(),
            type,
            event,
            data,
            payload,
            send: false,
        };
        return messageId;
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.1.5", ngImport: i0, type: MultiWindowService, deps: [{ token: NGXMW_CONFIG }, { token: i1.Location, optional: true }, { token: StorageService }, { token: WindowRef }], target: i0.ɵɵFactoryTarget.Injectable }); }
    /** @nocollapse */ static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.1.5", ngImport: i0, type: MultiWindowService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.1.5", ngImport: i0, type: MultiWindowService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [NGXMW_CONFIG]
                }] }, { type: i1.Location, decorators: [{
                    type: Optional
                }] }, { type: StorageService }, { type: WindowRef }]; } });

class MultiWindowModule {
    static forRoot(config) {
        return {
            ngModule: MultiWindowModule,
            providers: [MultiWindowService, { provide: NGXMW_CONFIG, useValue: config }],
        };
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.1.5", ngImport: i0, type: MultiWindowModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.1.5", ngImport: i0, type: MultiWindowModule, imports: [CommonModule] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.1.5", ngImport: i0, type: MultiWindowModule, providers: [
            StorageService,
            MultiWindowService,
            WindowRef,
            { provide: NGXMW_CONFIG, useValue: {} },
        ], imports: [CommonModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.1.5", ngImport: i0, type: MultiWindowModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    providers: [
                        StorageService,
                        MultiWindowService,
                        WindowRef,
                        { provide: NGXMW_CONFIG, useValue: {} },
                    ],
                }]
        }] });

/*
 * Public API Surface of ngx-multi-window
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MessageType, MultiWindowModule, MultiWindowService, NGXMW_CONFIG, StorageService, StorageServiceProvider, StorageServiceProviderFactory, WindowRef, WindowSaveStrategy, defaultMultiWindowConfig };
//# sourceMappingURL=ngx-multi-window.mjs.map
