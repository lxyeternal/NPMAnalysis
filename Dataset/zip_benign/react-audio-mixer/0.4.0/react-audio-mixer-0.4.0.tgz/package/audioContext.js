"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.useAudioNodes = exports.CustomNode = exports.AudioProvider = exports.FFT_MAX = exports.FFT_MID = exports.FFT_MIN = void 0;
const react_1 = __importStar(require("react"));
const make_list_provider_1 = __importDefault(require("make-list-provider"));
const nodeLink_1 = __importDefault(require("./hooks/nodeLink"));
exports.FFT_MIN = 32;
exports.FFT_MID = 8192;
exports.FFT_MAX = 32768;
let nodeCount = 0;
const [NodeProvider, useNode, useNodes] = (0, make_list_provider_1.default)();
const context = (0, react_1.createContext)(undefined);
function useAudio() {
    return (0, react_1.useContext)(context);
}
exports.default = useAudio;
function AudioProvider(props) {
    const { value, onNodes, children } = props;
    return (react_1.default.createElement(NodeProvider, { onChange: onNodes },
        react_1.default.createElement(context.Provider, { value: value }, children)));
}
exports.AudioProvider = AudioProvider;
function ConnectNodes(props) {
    const { source, destination, onError } = props;
    (0, nodeLink_1.default)(source, destination, onError);
    return null;
}
function ListenLink(props) {
    const { link, node, onError } = props;
    const links = useNodes().filter((lNode) => lNode.name && lNode.name === link);
    return (react_1.default.createElement(react_1.default.Fragment, null, links.map((lItem) => (react_1.default.createElement(ConnectNodes, { key: lItem.id, source: lItem.node, destination: node, onError: onError })))));
}
function CustomNode(props) {
    const { name, listen, type, node, onNode, onError } = props;
    const id = (0, react_1.useMemo)(() => {
        const index = nodeCount;
        nodeCount += 1;
        return index.toString(36);
    }, []);
    const state = (0, react_1.useMemo)(() => ({ name, type, node, id }), [name, type, node, id]);
    useNode(state);
    (0, react_1.useEffect)(() => {
        if (!onNode)
            return;
        onNode(node);
    }, [node, onNode]);
    const listeners = (0, react_1.useMemo)(() => {
        if (listen instanceof Array)
            return listen;
        if (typeof listen === 'string')
            return [listen];
        return [];
    }, [listen]);
    return (react_1.default.createElement(react_1.default.Fragment, null, listeners.map((link) => link && (react_1.default.createElement(ListenLink, { key: link, link: link, node: node, onError: onError })))));
}
exports.CustomNode = CustomNode;
exports.useAudioNodes = useNodes;
