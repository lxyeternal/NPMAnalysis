/// <reference types="react" />
import { BaseNodeProps } from '../audioContext';
import { AudioParamSequence } from '../hooks/param';
export interface GainNodeProps extends BaseNodeProps {
    gain: number;
    gainSequence?: AudioParamSequence;
}
export default function GainNode(props: GainNodeProps): JSX.Element | null;
