"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importStar(require("react"));
const audioContext_1 = __importStar(require("../audioContext"));
function AnalyserNode(props) {
    const { type, fftSize = audioContext_1.FFT_MIN, interval = 500, smoothing = 0, min = -100, max = 0, floatBuffer = false, onUpdate, ...baseNodeProps } = props;
    const { context, ready } = (0, audioContext_1.default)();
    const node = (0, react_1.useMemo)(() => {
        try {
            return context.createAnalyser();
        }
        catch (e) {
            return undefined;
        }
    }, [context]);
    (0, react_1.useEffect)(() => {
        if (!node)
            return;
        node.smoothingTimeConstant = smoothing;
    }, [node, smoothing]);
    (0, react_1.useEffect)(() => {
        if (!node)
            return;
        node.minDecibels = min;
        node.maxDecibels = max;
    }, [node, min, max]);
    (0, react_1.useEffect)(() => {
        if (!node || !ready)
            return undefined;
        node.fftSize = fftSize;
        const buffer = floatBuffer
            ? new Float32Array(node.frequencyBinCount)
            : new Uint8Array(node.frequencyBinCount);
        const update = () => {
            if (type === 'frequency') {
                if (buffer instanceof Uint8Array) {
                    node.getByteFrequencyData(buffer);
                }
                else if (buffer instanceof Float32Array) {
                    node.getFloatFrequencyData(buffer);
                }
            }
            else if (type === 'waveform') {
                if (buffer instanceof Uint8Array) {
                    node.getByteTimeDomainData(buffer);
                }
                else if (buffer instanceof Float32Array) {
                    node.getFloatTimeDomainData(buffer);
                }
            }
            onUpdate(buffer);
        };
        const timer = setInterval(update, interval);
        return () => {
            clearInterval(timer);
        };
    }, [node, ready, type, floatBuffer, interval, fftSize, onUpdate]);
    if (!node)
        return null;
    return react_1.default.createElement(audioContext_1.CustomNode, { type: "output", node: node, ...baseNodeProps });
}
exports.default = AnalyserNode;
