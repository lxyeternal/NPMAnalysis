"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.reduceFfts = exports.joinToneGroups = void 0;
const react_1 = __importStar(require("react"));
const audioContext_1 = __importStar(require("../audioContext"));
const Analyser_1 = __importDefault(require("./Analyser"));
const REDUCEFFTS_PADDING = 0.04; // About half a semitone
function joinToneGroups(list) {
    return list.reduce((a, b) => {
        const [atone, avolume, ajitter] = a;
        const [btone, bvolume, bjitter] = b;
        const sum = avolume + bvolume;
        return [
            sum ? (atone * avolume + btone * bvolume) / sum : 0,
            sum,
            ajitter + bjitter,
        ];
    }, [0, 0, 0]);
}
exports.joinToneGroups = joinToneGroups;
function reduceFfts(ffts, padding = REDUCEFFTS_PADDING, limit = 0) {
    const groups = [];
    let lastFft = 0;
    let newGroup = true;
    for (const [fftStr, volume] of Object.entries(ffts)) {
        const fft = parseInt(fftStr, 10);
        if (!(fft >= 0))
            continue;
        if (volume <= limit) {
            newGroup || (newGroup = 1 - lastFft / fft > padding);
            continue;
        }
        if (newGroup) {
            groups.push([0, 0, 0]);
        }
        const weightedVolume = volume / (fft + 1);
        groups.push(joinToneGroups([groups.pop() || [0, 0, 0], [fft, weightedVolume, 1]]));
        lastFft = fft;
        newGroup = false;
    }
    return groups.map(([fft, volume, jitter]) => [fft, fft * volume, jitter]);
}
exports.reduceFfts = reduceFfts;
function HzAnalyserNode(props) {
    const { fftSize = audioContext_1.FFT_MAX, padding = REDUCEFFTS_PADDING, limit = 0, onUpdate, ...analyserProps } = props;
    const { context } = (0, audioContext_1.default)();
    const handleUpdate = (0, react_1.useCallback)((buffer) => {
        const { sampleRate } = context;
        const mag = sampleRate / fftSize;
        const fftGroups = reduceFfts(buffer, padding, limit);
        const hzs = fftGroups.map(([fft, volume, jitter]) => [fft * mag, volume, jitter]);
        onUpdate(hzs);
    }, [context, fftSize, limit, padding, onUpdate]);
    return (react_1.default.createElement(Analyser_1.default, { fftSize: fftSize, type: "frequency", onUpdate: handleUpdate, ...analyserProps }));
}
exports.default = HzAnalyserNode;
