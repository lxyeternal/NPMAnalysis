import React from 'react';
import { BaseNodeProps } from '../audioContext';
export interface GroupNodeProps extends BaseNodeProps {
    children?: React.ReactNode;
    inputName?: string;
    outputName?: string;
}
export default function GroupNode(props: GroupNodeProps): JSX.Element;
