/// <reference types="react" />
import { BaseInNodeProps } from '../audioContext';
export interface MicrophoneNodeProps extends BaseInNodeProps {
    deviceId?: string;
    echoCancellation?: boolean;
    noiseSuppression?: boolean;
    autoGainControl?: boolean;
    onStream?: (stream: MediaStream | undefined) => void;
}
export default function MicrophoneNode(props: MicrophoneNodeProps): JSX.Element | null;
