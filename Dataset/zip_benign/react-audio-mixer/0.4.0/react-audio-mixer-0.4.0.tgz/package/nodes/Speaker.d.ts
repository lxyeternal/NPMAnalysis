/// <reference types="react" />
import { BaseOutNodeProps } from '../audioContext';
export interface SpeakerNodeProps extends BaseOutNodeProps {
    deviceId?: string;
}
export default function SpeakerNode(props: SpeakerNodeProps): JSX.Element | null;
