"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importStar(require("react"));
const audioContext_1 = __importStar(require("../audioContext"));
const param_1 = __importDefault(require("../hooks/param"));
function GainNode(props) {
    const { gain, gainSequence, ...baseNodeProps } = props;
    const { context } = (0, audioContext_1.default)();
    const node = (0, react_1.useMemo)(() => {
        try {
            return context.createGain();
        }
        catch (e) {
            return undefined;
        }
    }, [context]);
    (0, param_1.default)(node?.gain, gain, gainSequence);
    if (!node)
        return null;
    return react_1.default.createElement(audioContext_1.CustomNode, { type: "node", node: node, ...baseNodeProps });
}
exports.default = GainNode;
