/// <reference types="react" />
import { AnalyserNodePropsBase } from './Analyser';
export type AnalyserToneT = [value: number, volume: number, jitter: number];
export declare function joinToneGroups(list: AnalyserToneT[]): AnalyserToneT;
export declare function reduceFfts(ffts: Uint8Array, padding?: number, limit?: number): AnalyserToneT[];
export interface HzAnalyserNodeProps extends Omit<AnalyserNodePropsBase, 'type' | 'onUpdate'> {
    padding?: number;
    limit?: number;
    onUpdate: (list: AnalyserToneT[]) => void;
}
export default function HzAnalyserNode(props: HzAnalyserNodeProps): JSX.Element | null;
