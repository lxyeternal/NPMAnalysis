/// <reference types="react" />
import { BaseInNodeProps } from '../audioContext';
import { AudioParamSequence } from '../hooks/param';
export interface OscillatorNodeProps extends BaseInNodeProps {
    type?: OscillatorType;
    frequency: number;
    frequencySequence?: AudioParamSequence;
    detune?: number;
    detuneSequence?: AudioParamSequence;
    start?: number;
    end?: number;
    onEnded?: () => void;
}
export default function OscillatorNode(props: OscillatorNodeProps): JSX.Element | null;
