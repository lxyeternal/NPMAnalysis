"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.combineByNotes = exports.getNote = exports.createNoteList = exports.hz440 = exports.noteNames = void 0;
const react_1 = __importStar(require("react"));
const HzAnalyser_1 = __importStar(require("./HzAnalyser"));
exports.noteNames = [
    'C',
    'C#,Db',
    'D',
    'D#,Eb',
    'E',
    'F',
    'F#,Gb',
    'G',
    'G#,Ab',
    'A',
    'A#,Bb',
    'B',
];
exports.hz440 = [
    // Standard 440 hz
    16.35, 17.32, 18.35, 19.45, 20.6, 21.83, 23.12, 24.5, 25.96, 27.5, 29.14,
    30.87,
    // C1
    32.7, 34.65, 36.71, 38.89, 41.2, 43.65, 46.25, 49.0, 51.91, 55.0, 58.27,
    61.74,
    // C2
    65.41, 69.3, 73.42, 77.78, 82.41, 87.31, 92.5, 98.0, 103.83, 110.0, 116.54,
    123.47,
    // C3
    130.81, 138.59, 146.83, 155.56, 164.81, 174.61, 185.0, 196.0, 207.65, 220.0,
    233.08, 246.94,
    // C4
    261.63, 277.18, 293.66, 311.13, 329.63, 349.23, 369.99, 392.0, 415.3, 440.0,
    466.16, 493.88,
    // C5
    523.25, 554.37, 587.33, 622.25, 659.25, 698.46, 739.99, 783.99, 830.61, 880.0,
    932.33, 987.77,
    // C6
    1046.5, 1108.73, 1174.66, 1244.51, 1318.51, 1396.91, 1479.98, 1567.98,
    1661.22, 1760.0, 1864.66, 1975.53,
    // C7
    2093.0, 2217.46, 2349.32, 2489.02, 2637.02, 2793.83, 2959.96, 3135.96,
    3322.44, 3520.0, 3729.31, 3951.07,
    // C8
    4186.01, 4434.92, 4698.63, 4978.03, 5274.04, 5587.65, 5919.91, 6271.93,
    6644.88, 7040.0, 7458.62, 7902.13,
];
function createNoteList(hz) {
    return hz.reduce((list, value, index) => {
        const name = exports.noteNames[index % exports.noteNames.length];
        const octive = Math.floor(index / exports.noteNames.length);
        const octiveName = name.replace(/^|,/, (v) => `${octive}${v}`);
        return {
            ...list,
            [octiveName]: value,
        };
    }, {});
}
exports.createNoteList = createNoteList;
function getNote(list, hz) {
    const min = Object.values(list)
        .slice(0, 2)
        .reduce((a, b) => 2 * a - b);
    const max = Object.values(list)
        .slice(-2)
        .reduce((a, b) => 2 * b - a);
    if (hz < min)
        return ['', 0];
    if (hz > max)
        return ['', 0];
    let note = '4C';
    for (const [name, noteHz] of Object.entries(list)) {
        if (Math.abs(hz - noteHz) < Math.abs(hz - (list[note] || 0))) {
            note = name;
        }
    }
    return [note, hz - list[note]];
}
exports.getNote = getNote;
function combineByNotes(noteList, tones) {
    const notes = {};
    for (const tone of tones) {
        const [hz] = tone;
        const [note] = getNote(noteList, hz);
        notes[note] = [...(notes[note] || []), tone];
    }
    return Object.values(notes).map((tone) => (0, HzAnalyser_1.joinToneGroups)(tone));
}
exports.combineByNotes = combineByNotes;
const noteListDefault = createNoteList(exports.hz440);
function NoteAnalyserNode(props) {
    const { noteList = noteListDefault, onUpdate, ...hzAnalyserNodeProps } = props;
    const handleUpdate = (0, react_1.useCallback)((hzList) => {
        const tones = combineByNotes(noteList, hzList);
        const notes = tones.map((tone) => {
            const [hz, volume, jitter] = tone;
            const [note, offset] = getNote(noteList, hz);
            return [note, volume, offset, jitter];
        });
        onUpdate(notes);
    }, [noteList, onUpdate]);
    return react_1.default.createElement(HzAnalyser_1.default, { onUpdate: handleUpdate, ...hzAnalyserNodeProps });
}
exports.default = NoteAnalyserNode;
