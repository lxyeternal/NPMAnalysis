"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importStar(require("react"));
const audioContext_1 = __importStar(require("../audioContext"));
const stream_1 = __importDefault(require("../hooks/stream"));
function parseDeviceId(deviceId) {
    if (!deviceId || deviceId === 'default')
        return '';
    return { exact: deviceId };
}
function MicrophoneNode(props) {
    const { deviceId, echoCancellation, noiseSuppression, autoGainControl, onStream, ...baseNodeProps } = props;
    const { context } = (0, audioContext_1.default)();
    const constraints = (0, react_1.useMemo)(() => ({
        audio: {
            deviceId: parseDeviceId(deviceId),
            echoCancellation,
            noiseSuppression,
            autoGainControl,
        },
    }), [deviceId, echoCancellation, noiseSuppression, autoGainControl]);
    const stream = (0, stream_1.default)(constraints);
    (0, react_1.useEffect)(() => {
        if (!onStream)
            return;
        onStream(stream);
    }, [stream, onStream]);
    const node = (0, react_1.useMemo)(() => {
        if (!stream)
            return undefined;
        try {
            return context.createMediaStreamSource(stream);
        }
        catch (e) {
            return undefined;
        }
    }, [context, stream]);
    if (!node)
        return null;
    return react_1.default.createElement(audioContext_1.CustomNode, { type: "input", node: node, ...baseNodeProps });
}
exports.default = MicrophoneNode;
