"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importStar(require("react"));
const audioContext_1 = __importStar(require("../audioContext"));
const param_1 = __importDefault(require("../hooks/param"));
function OscillatorNode(props) {
    const { type = 'sine', frequency, frequencySequence, detune = 0, detuneSequence, start, end, onEnded, ...baseNodeProps } = props;
    const { context, ready } = (0, audioContext_1.default)();
    const onEndedRef = (0, react_1.useRef)(undefined);
    onEndedRef.current = onEnded;
    const node = (0, react_1.useMemo)(() => {
        if (!ready)
            return undefined;
        try {
            const oNode = context.createOscillator();
            if (start) {
                oNode.start(start);
            }
            else {
                oNode.start();
            }
            if (end) {
                oNode.stop(end);
            }
            return oNode;
        }
        catch (e) {
            return undefined;
        }
    }, [ready, context, start, end]);
    (0, react_1.useEffect)(() => {
        if (!node)
            return undefined;
        const handleEnded = () => {
            if (!onEndedRef.current)
                return;
            onEndedRef.current();
        };
        node.addEventListener('ended', handleEnded);
        return () => {
            node.removeEventListener('ended', handleEnded);
            node.stop();
        };
    }, [node]);
    (0, react_1.useEffect)(() => {
        if (!node)
            return;
        node.type = type;
    }, [node, type]);
    (0, param_1.default)(node?.frequency, frequency, frequencySequence);
    (0, param_1.default)(node?.detune, detune, detuneSequence);
    if (!node)
        return null;
    return react_1.default.createElement(audioContext_1.CustomNode, { type: "input", node: node, ...baseNodeProps });
}
exports.default = OscillatorNode;
