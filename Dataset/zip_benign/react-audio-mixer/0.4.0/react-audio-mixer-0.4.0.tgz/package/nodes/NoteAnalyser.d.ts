/// <reference types="react" />
import { AnalyserToneT, HzAnalyserNodeProps } from './HzAnalyser';
export declare const noteNames: string[];
export declare const hz440: number[];
export type NoteList = Record<string, number>;
export declare function createNoteList(hz: number[]): NoteList;
export declare function getNote(list: NoteList, hz: number): [string, number];
export declare function combineByNotes(noteList: NoteList, tones: AnalyserToneT[]): AnalyserToneT[];
export type AnalyserNoteT = [
    note: string,
    volume: number,
    offset: number,
    jitter: number
];
export interface NoteAnalyserNodeProps extends Omit<HzAnalyserNodeProps, 'onUpdate'> {
    noteList?: NoteList;
    onUpdate: (notes: AnalyserNoteT[]) => void;
}
export default function NoteAnalyserNode(props: NoteAnalyserNodeProps): JSX.Element | null;
