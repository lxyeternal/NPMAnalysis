/// <reference types="react" />
import { BaseOutNodeProps } from '../audioContext';
export interface StreamOutNodeProps extends BaseOutNodeProps {
    stream: MediaStream;
}
export default function StreamOutNode(props: StreamOutNodeProps): JSX.Element | null;
