/// <reference types="react" />
import { BaseInNodeProps } from '../audioContext';
export interface StreamInNodeProps extends BaseInNodeProps {
    stream: MediaProvider;
}
export default function StreamInNode(props: StreamInNodeProps): JSX.Element | null;
