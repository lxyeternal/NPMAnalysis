/// <reference types="react" />
import { BaseNodeProps } from '../audioContext';
export interface AnalyserNodePropsBase extends BaseNodeProps {
    type: 'frequency' | 'waveform';
    fftSize?: number;
    interval?: number;
    smoothing?: number;
    min?: number;
    max?: number;
}
interface AnalyserNodePropsByByte extends AnalyserNodePropsBase {
    onUpdate: (data: Uint8Array) => void;
    floatBuffer?: false;
}
interface AnalyserNodePropsByFloat extends AnalyserNodePropsBase {
    onUpdate: (data: Float32Array) => void;
    floatBuffer: true;
}
export type AnalyserNodeProps = AnalyserNodePropsByByte | AnalyserNodePropsByFloat;
export default function AnalyserNode(props: AnalyserNodeProps): JSX.Element | null;
export {};
