/// <reference types="react" />
import { BaseNodeProps } from '../audioContext';
export type NullNodeProps = BaseNodeProps;
export default function NullNode(props: NullNodeProps): JSX.Element | null;
