"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importStar(require("react"));
const audioContext_1 = __importDefault(require("../audioContext"));
const audioProvider_1 = __importDefault(require("../audioProvider"));
const Null_1 = __importDefault(require("./Null"));
const errorCallback_1 = __importDefault(require("../hooks/errorCallback"));
const nodeLink_1 = __importDefault(require("../hooks/nodeLink"));
function GroupNode(props) {
    const { children, inputName = 'input', outputName = 'output', listen, onNode, onError, ...baseProps } = props;
    const { context } = (0, audioContext_1.default)();
    const handleError = (0, errorCallback_1.default)(onError);
    const [outerInput, setOuterInput] = (0, react_1.useState)();
    const [innerInput, setInnerInput] = (0, react_1.useState)();
    const [innerOutput, setInnerOutput] = (0, react_1.useState)();
    const [outerOutput, setOuterOutput] = (0, react_1.useState)();
    (0, react_1.useEffect)(() => {
        if (!outerOutput || !onNode)
            return;
        onNode(outerOutput);
    }, [outerOutput, onNode]);
    (0, nodeLink_1.default)(outerInput, innerInput, handleError);
    (0, nodeLink_1.default)(innerOutput, outerOutput, handleError);
    return (react_1.default.createElement(react_1.default.Fragment, null,
        react_1.default.createElement(Null_1.default, { listen: listen, onNode: setOuterInput, onError: handleError }),
        react_1.default.createElement(audioProvider_1.default, { context: context },
            react_1.default.createElement(Null_1.default, { name: inputName, onNode: setInnerInput, onError: handleError }),
            react_1.default.createElement(Null_1.default, { listen: outputName, onNode: setInnerOutput, onError: handleError }),
            children),
        react_1.default.createElement(Null_1.default, { ...baseProps, onNode: setOuterOutput, onError: handleError })));
}
exports.default = GroupNode;
