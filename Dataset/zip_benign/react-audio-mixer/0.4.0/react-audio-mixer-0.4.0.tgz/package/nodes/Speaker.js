"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importStar(require("react"));
const audioContext_1 = __importStar(require("../audioContext"));
const speaker_1 = __importDefault(require("../hooks/speaker"));
const errorCallback_1 = __importDefault(require("../hooks/errorCallback"));
function SpeakerNode(props) {
    const { deviceId, onError, ...baseNodeProps } = props;
    const { context } = (0, audioContext_1.default)();
    const handleError = (0, errorCallback_1.default)(onError);
    const audio = (0, speaker_1.default)({ deviceId, onError });
    const node = (0, react_1.useMemo)(() => {
        try {
            const sNode = context.createMediaStreamDestination();
            audio.srcObject = sNode.stream;
            return sNode;
        }
        catch (error) {
            handleError(error);
            return undefined;
        }
    }, [context, audio, handleError]);
    if (!node)
        return null;
    return (react_1.default.createElement(audioContext_1.CustomNode, { type: "output", node: node, onError: onError, ...baseNodeProps }));
}
exports.default = SpeakerNode;
