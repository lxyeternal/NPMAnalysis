"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = __importStar(require("react"));
const gestured_1 = __importDefault(require("./hooks/gestured"));
const audioContext_1 = require("./audioContext");
function AudioProvider(props) {
    const { children, context: rootContext, latencyHint = 0, sampleRate = 44100, } = props;
    const ready = (0, gestured_1.default)();
    const context = (0, react_1.useMemo)(() => {
        if (rootContext)
            return rootContext;
        return new AudioContext({ latencyHint, sampleRate });
    }, [rootContext, latencyHint, sampleRate]);
    (0, react_1.useEffect)(() => {
        if (!ready)
            return;
        context.resume();
    }, [context, ready]);
    const value = (0, react_1.useMemo)(() => ({
        context,
        ready,
    }), [context, ready]);
    return react_1.default.createElement(audioContext_1.AudioProvider, { value: value }, children);
}
exports.default = AudioProvider;
