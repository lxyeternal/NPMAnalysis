import React from 'react';
interface AudioProviderPropsBase {
    children?: React.ReactNode;
    context?: void;
    latencyHint?: void;
    sampleRate?: void;
}
interface AudioProviderPropsWithContext extends Omit<AudioProviderPropsBase, 'context'> {
    context: AudioContext;
}
interface AudioProviderPropsWithHints extends Omit<AudioProviderPropsBase, 'latencyHint' | 'sampleRate'> {
    latencyHint?: number;
    sampleRate?: number;
}
export type AudioProviderProps = AudioProviderPropsWithContext | AudioProviderPropsWithHints;
export default function AudioProvider(props: AudioProviderProps): JSX.Element;
export {};
