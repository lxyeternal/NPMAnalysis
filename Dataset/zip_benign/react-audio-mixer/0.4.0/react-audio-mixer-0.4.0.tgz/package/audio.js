"use strict";
/*!
 * React Audio Hooks <https://github.com/smujmaiku/react-audio-mixer>
 * Copyright(c) 2021 Michael Szmadzinski
 * MIT Licensed
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.useNodeLink = exports.useParam = exports.useGestured = exports.canSinkId = exports.useSpeaker = exports.useStream = exports.useOutputDevices = exports.useInputDevices = exports.useAudioDevices = exports.StreamOutNode = exports.SpeakerNode = exports.NoteAnalyserNode = exports.HzAnalyserNode = exports.AnalyserNode = exports.GainNode = exports.NullNode = exports.OscillatorNode = exports.StreamInNode = exports.MicrophoneNode = exports.GroupNode = exports.AudioProvider = exports.CustomNode = exports.FFT_MAX = exports.FFT_MID = exports.FFT_MIN = void 0;
const audioContext_1 = __importDefault(require("./audioContext"));
exports.default = audioContext_1.default;
var audioContext_2 = require("./audioContext");
Object.defineProperty(exports, "FFT_MIN", { enumerable: true, get: function () { return audioContext_2.FFT_MIN; } });
Object.defineProperty(exports, "FFT_MID", { enumerable: true, get: function () { return audioContext_2.FFT_MID; } });
Object.defineProperty(exports, "FFT_MAX", { enumerable: true, get: function () { return audioContext_2.FFT_MAX; } });
Object.defineProperty(exports, "CustomNode", { enumerable: true, get: function () { return audioContext_2.CustomNode; } });
var audioProvider_1 = require("./audioProvider");
Object.defineProperty(exports, "AudioProvider", { enumerable: true, get: function () { return __importDefault(audioProvider_1).default; } });
var Group_1 = require("./nodes/Group");
Object.defineProperty(exports, "GroupNode", { enumerable: true, get: function () { return __importDefault(Group_1).default; } });
var Microphone_1 = require("./nodes/Microphone");
Object.defineProperty(exports, "MicrophoneNode", { enumerable: true, get: function () { return __importDefault(Microphone_1).default; } });
var StreamIn_1 = require("./nodes/StreamIn");
Object.defineProperty(exports, "StreamInNode", { enumerable: true, get: function () { return __importDefault(StreamIn_1).default; } });
var Oscillator_1 = require("./nodes/Oscillator");
Object.defineProperty(exports, "OscillatorNode", { enumerable: true, get: function () { return __importDefault(Oscillator_1).default; } });
var Null_1 = require("./nodes/Null");
Object.defineProperty(exports, "NullNode", { enumerable: true, get: function () { return __importDefault(Null_1).default; } });
var Gain_1 = require("./nodes/Gain");
Object.defineProperty(exports, "GainNode", { enumerable: true, get: function () { return __importDefault(Gain_1).default; } });
var Analyser_1 = require("./nodes/Analyser");
Object.defineProperty(exports, "AnalyserNode", { enumerable: true, get: function () { return __importDefault(Analyser_1).default; } });
var HzAnalyser_1 = require("./nodes/HzAnalyser");
Object.defineProperty(exports, "HzAnalyserNode", { enumerable: true, get: function () { return __importDefault(HzAnalyser_1).default; } });
var NoteAnalyser_1 = require("./nodes/NoteAnalyser");
Object.defineProperty(exports, "NoteAnalyserNode", { enumerable: true, get: function () { return __importDefault(NoteAnalyser_1).default; } });
var Speaker_1 = require("./nodes/Speaker");
Object.defineProperty(exports, "SpeakerNode", { enumerable: true, get: function () { return __importDefault(Speaker_1).default; } });
var StreamOut_1 = require("./nodes/StreamOut");
Object.defineProperty(exports, "StreamOutNode", { enumerable: true, get: function () { return __importDefault(StreamOut_1).default; } });
var devices_1 = require("./hooks/devices");
Object.defineProperty(exports, "useAudioDevices", { enumerable: true, get: function () { return __importDefault(devices_1).default; } });
Object.defineProperty(exports, "useInputDevices", { enumerable: true, get: function () { return devices_1.useInputDevices; } });
Object.defineProperty(exports, "useOutputDevices", { enumerable: true, get: function () { return devices_1.useOutputDevices; } });
var stream_1 = require("./hooks/stream");
Object.defineProperty(exports, "useStream", { enumerable: true, get: function () { return __importDefault(stream_1).default; } });
var speaker_1 = require("./hooks/speaker");
Object.defineProperty(exports, "useSpeaker", { enumerable: true, get: function () { return __importDefault(speaker_1).default; } });
Object.defineProperty(exports, "canSinkId", { enumerable: true, get: function () { return speaker_1.canSinkId; } });
var gestured_1 = require("./hooks/gestured");
Object.defineProperty(exports, "useGestured", { enumerable: true, get: function () { return __importDefault(gestured_1).default; } });
var param_1 = require("./hooks/param");
Object.defineProperty(exports, "useParam", { enumerable: true, get: function () { return __importDefault(param_1).default; } });
var nodeLink_1 = require("./hooks/nodeLink");
Object.defineProperty(exports, "useNodeLink", { enumerable: true, get: function () { return __importDefault(nodeLink_1).default; } });
