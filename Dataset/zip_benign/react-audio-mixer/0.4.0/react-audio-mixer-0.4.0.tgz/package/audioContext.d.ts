import React from 'react';
import { ErrorCallback } from './hooks/errorCallback';
export declare const FFT_MIN = 32;
export declare const FFT_MID = 8192;
export declare const FFT_MAX = 32768;
export type NodeTypeT = 'input' | 'node' | 'output';
export interface NodeI {
    id: string;
    name?: string;
    node: AudioNode;
    type: NodeTypeT;
}
export interface AudioContextI {
    context: AudioContext;
    ready: boolean;
}
export default function useAudio(): AudioContextI;
export interface AudioProviderProps {
    children?: React.ReactNode;
    value: AudioContextI;
    onNodes?: (state: NodeI[]) => void;
}
export declare function AudioProvider(props: AudioProviderProps): JSX.Element;
export interface BaseNodeProps {
    name?: string;
    listen?: string[] | string;
    onNode?: (node: AudioNode) => void;
    onError?: ErrorCallback;
}
export type BaseInNodeProps = Omit<BaseNodeProps, 'listen'>;
export type BaseOutNodeProps = BaseNodeProps;
export interface CustomNodeProps extends BaseNodeProps {
    type: NodeTypeT;
    node: AudioNode;
}
export declare function CustomNode(props: CustomNodeProps): JSX.Element;
export declare const useAudioNodes: import("make-list-provider").UseList<NodeI>;
