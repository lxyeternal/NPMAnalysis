"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = require("react");
const errorCallback_1 = __importDefault(require("./errorCallback"));
function useNodeLink(source, destination, onError) {
    const handleError = (0, errorCallback_1.default)(onError);
    (0, react_1.useEffect)(() => {
        if (!source || !destination)
            return undefined;
        try {
            source.connect(destination);
            return () => {
                try {
                    source.disconnect(destination);
                }
                catch (error) {
                    handleError(error);
                }
            };
        }
        catch (error) {
            handleError(error);
        }
        return undefined;
    }, [source, destination, handleError]);
}
exports.default = useNodeLink;
