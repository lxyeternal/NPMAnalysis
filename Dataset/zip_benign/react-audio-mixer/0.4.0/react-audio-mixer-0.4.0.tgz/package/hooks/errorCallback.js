"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = require("react");
function useErrorCallback(callback) {
    const ref = (0, react_1.useRef)();
    ref.current = callback;
    const handleError = (0, react_1.useCallback)((error) => {
        if (!ref.current)
            return;
        ref.current(error);
    }, [ref]);
    return handleError;
}
exports.default = useErrorCallback;
