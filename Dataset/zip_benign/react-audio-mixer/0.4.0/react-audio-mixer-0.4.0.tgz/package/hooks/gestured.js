"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.promise = void 0;
const react_1 = require("react");
let ready = false;
exports.promise = new Promise((resolve) => {
    document.addEventListener('click', resolve);
    document.addEventListener('touchstart', resolve);
    document.addEventListener('keydown', resolve);
}).then(() => {
    ready = true;
});
function useGestured() {
    const [state, setState] = (0, react_1.useState)(ready);
    (0, react_1.useEffect)(() => {
        if (state)
            return;
        exports.promise.then(() => {
            setState(true);
        });
    }, [state]);
    return state;
}
exports.default = useGestured;
