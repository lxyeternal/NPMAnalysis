"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const react_1 = require("react");
const audioContext_1 = __importDefault(require("../audioContext"));
async function getStreamClean(constraints) {
    try {
        const stream = await navigator.mediaDevices.getUserMedia(constraints);
        return stream;
    }
    catch (e) {
        return undefined;
    }
}
function useStream(constraints) {
    const { ready } = (0, audioContext_1.default)();
    const [state, setState] = (0, react_1.useState)();
    (0, react_1.useEffect)(() => {
        setState(undefined);
        if (!ready)
            return undefined;
        let cancel = false;
        let stream;
        const update = async () => {
            if (stream?.active)
                return;
            const res = await getStreamClean(constraints);
            // Prevent rapid events setting state
            if (cancel || stream?.active)
                return;
            stream = res;
            setState(stream);
        };
        update();
        navigator.mediaDevices.addEventListener('devicechange', update);
        return () => {
            cancel = true;
            navigator.mediaDevices.removeEventListener('devicechange', update);
        };
    }, [ready, constraints]);
    return state;
}
exports.default = useStream;
