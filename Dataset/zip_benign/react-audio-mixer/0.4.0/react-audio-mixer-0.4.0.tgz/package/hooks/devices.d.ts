export type UseDevicesT = [MediaDeviceInfo[], boolean];
export default function useDevices(): UseDevicesT;
export declare function useInputDevices(): UseDevicesT;
export declare function useOutputDevices(): UseDevicesT;
