import { ErrorCallback } from './errorCallback';
declare global {
    interface HTMLMediaElement {
        sinkId: string;
        setSinkId: (id: string) => Promise<void>;
    }
}
export declare const canSinkId: boolean;
export interface UseSpeakerOptions {
    deviceId?: string;
    onError?: ErrorCallback;
}
export default function useSpeaker(deviceId?: string): HTMLAudioElement;
export default function useSpeaker(options: UseSpeakerOptions): HTMLAudioElement;
