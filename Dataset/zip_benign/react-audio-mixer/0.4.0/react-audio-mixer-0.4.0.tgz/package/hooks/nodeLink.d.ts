import { ErrorCallback } from './errorCallback';
export default function useNodeLink(source: AudioNode | undefined, destination: AudioNode | undefined, onError?: ErrorCallback): void;
