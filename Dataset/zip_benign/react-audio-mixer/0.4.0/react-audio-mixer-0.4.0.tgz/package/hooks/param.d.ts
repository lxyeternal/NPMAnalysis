export type AudioParamSetValue = [
    type: 'setValue',
    value: number,
    startTime: number
];
export type AudioParamLinearRamp = [
    type: 'linearRamp',
    value: number,
    endTime: number
];
export type AudioParamExponentialRamp = [
    type: 'exponentialRamp',
    value: number,
    endTime: number
];
export type AudioParamSetTarget = [
    type: 'setTarget',
    target: number,
    startTime: number,
    timeConstant: number
];
export type AudioParamSetValueCurve = [
    type: 'setValueCurve',
    values: number[] | Float32Array,
    startTime: number,
    duration: number
];
export type AudioParamT = AudioParamSetValue | AudioParamLinearRamp | AudioParamExponentialRamp | AudioParamSetTarget | AudioParamSetValueCurve;
export type AudioParamSequence = AudioParamT[];
export declare function scheduleValues(param: AudioParam, sequence: AudioParamSequence): void;
export default function useParam(param: AudioParam | undefined, value: number, sequence?: AudioParamSequence): void;
