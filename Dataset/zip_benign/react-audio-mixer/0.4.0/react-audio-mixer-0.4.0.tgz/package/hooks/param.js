"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.scheduleValues = void 0;
const react_1 = require("react");
function scheduleValues(param, sequence) {
    for (const command of sequence) {
        switch (command[0]) {
            case 'setValue':
                param.setValueAtTime(command[1], command[2]);
                break;
            case 'linearRamp':
                param.linearRampToValueAtTime(command[1], command[2]);
                break;
            case 'exponentialRamp':
                param.exponentialRampToValueAtTime(command[1], command[2]);
                break;
            case 'setTarget':
                param.setTargetAtTime(command[1], command[2], command[3]);
                break;
            case 'setValueCurve':
                param.setValueCurveAtTime(command[1], command[2], command[3]);
                break;
            default:
        }
    }
}
exports.scheduleValues = scheduleValues;
function useParam(param, value, sequence) {
    (0, react_1.useEffect)(() => {
        if (!param)
            return undefined;
        // eslint-disable-next-line no-param-reassign
        param.value = value;
        if (sequence) {
            scheduleValues(param, sequence);
        }
        return () => {
            param.cancelScheduledValues(0);
        };
    }, [param, value, sequence]);
}
exports.default = useParam;
