export declare const promise: Promise<void>;
export default function useGestured(): boolean;
