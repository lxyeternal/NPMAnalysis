export type ErrorCallback = (error: unknown) => void;
export default function useErrorCallback(callback: ErrorCallback | undefined): ErrorCallback;
