export default function useStream(constraints?: MediaStreamConstraints | undefined): MediaStream | undefined;
