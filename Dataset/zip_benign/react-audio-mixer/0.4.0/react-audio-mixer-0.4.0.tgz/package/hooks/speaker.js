"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.canSinkId = void 0;
const react_1 = require("react");
const audioContext_1 = __importDefault(require("../audioContext"));
const devices_1 = require("./devices");
const errorCallback_1 = __importDefault(require("./errorCallback"));
const SETDEVICEID_ERROR_MSG = 'Cannot set deviceId as your browser does not support this feature';
exports.canSinkId = 'sinkId' in HTMLMediaElement.prototype;
function useSpeaker(options) {
    let opts = {};
    if (typeof options === 'string') {
        opts.deviceId = options;
    }
    else if (options) {
        opts = options;
    }
    const { deviceId, onError } = opts;
    const { ready } = (0, audioContext_1.default)();
    const handleError = (0, errorCallback_1.default)(onError);
    const [devices] = (0, devices_1.useOutputDevices)();
    const isDeviceKnown = !deviceId || devices.some((row) => row.deviceId === deviceId);
    const audio = (0, react_1.useMemo)(() => {
        const sAudio = new Audio();
        sAudio.muted = true;
        sAudio.autoplay = ready && isDeviceKnown;
        return sAudio;
        // Reload audio element when device is recovered
    }, [ready, isDeviceKnown]);
    (0, react_1.useEffect)(() => () => {
        audio.muted = true;
        audio.srcObject = null;
        audio.pause();
    }, [audio]);
    (0, react_1.useEffect)(() => {
        if (!audio || !ready)
            return undefined;
        let cancel = false;
        audio.muted = true;
        const setBySinkId = async () => {
            if (!exports.canSinkId)
                return;
            try {
                await audio.setSinkId('');
                if (cancel || !isDeviceKnown)
                    return;
                if (deviceId && deviceId !== 'default') {
                    await audio.setSinkId(deviceId);
                }
            }
            catch (error) {
                handleError(error);
            }
            if (cancel)
                return;
            audio.muted = false;
        };
        if (exports.canSinkId) {
            setBySinkId();
        }
        else if (deviceId) {
            handleError(new Error(SETDEVICEID_ERROR_MSG));
        }
        else {
            audio.muted = false;
        }
        return () => {
            cancel = true;
        };
    }, [audio, deviceId, ready, isDeviceKnown, handleError]);
    return audio;
}
exports.default = useSpeaker;
