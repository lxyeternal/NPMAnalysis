"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.useOutputDevices = exports.useInputDevices = void 0;
const react_1 = require("react");
const audioContext_1 = __importDefault(require("../audioContext"));
function useDevices() {
    const { context } = (0, audioContext_1.default)();
    const [allowed, setAllowed] = (0, react_1.useState)(false);
    const [ready, setReady] = (0, react_1.useState)(false);
    const [state, setState] = (0, react_1.useState)([]);
    (0, react_1.useEffect)(() => {
        if (!context) {
            setAllowed(false);
            setReady(false);
            setState([]);
            return () => { };
        }
        let cancel = false;
        if (!allowed) {
            navigator.mediaDevices
                .getUserMedia({ video: false, audio: true })
                .then(() => true, () => false)
                .then((value) => {
                if (cancel)
                    return;
                setAllowed(value);
            });
        }
        const updateDevices = async () => {
            const list = await navigator.mediaDevices.enumerateDevices();
            if (cancel)
                return;
            setState(list);
        };
        navigator.mediaDevices.addEventListener('devicechange', updateDevices);
        updateDevices();
        return () => {
            cancel = true;
            navigator.mediaDevices.removeEventListener('devicechange', updateDevices);
        };
    }, [context, allowed]);
    return [state, ready];
}
exports.default = useDevices;
function useInputDevices() {
    const [devices, ready] = useDevices();
    const inputDevices = devices.filter(({ kind }) => kind === 'audioinput');
    return [inputDevices, ready];
}
exports.useInputDevices = useInputDevices;
function useOutputDevices() {
    const [devices, ready] = useDevices();
    const outputDevices = devices.filter(({ kind }) => kind === 'audiooutput');
    return [outputDevices, ready];
}
exports.useOutputDevices = useOutputDevices;
