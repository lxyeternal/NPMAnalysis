module.exports = {
	_isSwitchedOn: false,
	selfcheckJS: function (callback) {
		callback('_success');
	},
	/*
	isRecognitionAvailable: function(successCallback, errorCallback) {
		cordova.exec(successCallback, errorCallback, 'SpeechRecognition', 'isRecognitionAvailable', []);
	},
	*/
	selfcheckJava: function (successCallback, errorCallback) {
		cordova.exec(successCallback, errorCallback, 'Flashlight', 'selfcheck', []);
	},
	available: function (callback) {
		cordova.exec(function (avail) {
			callback(avail ? true : false);
		}, function () { callback(false); }, "Flashlight", "available", []);
	},
	switchOn: function (successCallback, errorCallback, options) {
		var opts = options || {};
		this._isSwitchedOn = true;
		cordova.exec(successCallback, errorCallback, "Flashlight", "switchOn", [opts]);
	},
	switchOff: function (successCallback, errorCallback) {
		this._isSwitchedOn = false;
		cordova.exec(successCallback, errorCallback, "Flashlight", "switchOff", []);
	},
	toggle: function (successCallback, errorCallback, options) {
		if (this._isSwitchedOn) {
			this.switchOff(successCallback, errorCallback);
		} else {
			this.switchOn(successCallback, errorCallback, options);
		}
	},
	isSwitchedOn: function () {
		return this._isSwitchedOn;
	}
}