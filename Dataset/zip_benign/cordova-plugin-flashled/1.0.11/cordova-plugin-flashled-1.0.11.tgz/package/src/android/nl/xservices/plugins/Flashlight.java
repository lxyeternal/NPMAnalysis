package nl.xservices.plugins;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.FeatureInfo;
import android.content.pm.PackageManager;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;

import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;

import android.os.Build;
import android.util.Log;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.PermissionHelper;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.IOException;
import java.lang.reflect.Method;

public class Flashlight extends CordovaPlugin {

  private static final String ACTION_SELFCHECK = "selfcheck";
  private static final String ACTION_AVAILABLE = "available";
  private static final String ACTION_SWITCH_ON = "switchOn";
  private static final String ACTION_SWITCH_OFF = "switchOff";

  private static Boolean capable;
  private boolean releasing;

  @SuppressWarnings("deprecation")
  private Camera mCamera;

  private static final int PERMISSION_CALLBACK_CAMERA = 33;
  private String[] permissions = {Manifest.permission.CAMERA};
  private CallbackContext callbackContext;


  @Override
  public boolean execute(final String action, final JSONArray args, final CallbackContext callbackContext) throws JSONException {
    this.callbackContext = callbackContext;

    Log.d("Flashlight", "Plugin Called: " + action);

    try {
      if (action.equals(ACTION_SWITCH_ON)) {

        cordova.getThreadPool().execute(new Runnable() {
          public void run() {

            // When switching on immediately after checking for isAvailable,
            // the release method may still be running, so wait a bit.
            while (releasing) {
              try {
                Thread.sleep(10);
              } catch (InterruptedException ignore) {
              }
            }

            toggleTorch(true);
            /*
            // android M permission
            if (!hasPermisssion()) {
              requestPermissions(PERMISSION_CALLBACK_CAMERA);
            } else {
              toggleTorch(true);
            }
            */
          }
        });

        return true;
      } else if (action.equals(ACTION_SWITCH_OFF)) {
        cordova.getThreadPool().execute(new Runnable() {
          public void run() {
            toggleTorch(false);
            releaseCamera();
          }
        });
        return true;
      } else if (action.equals(ACTION_AVAILABLE)) {
        callbackContext.success(isCapable() ? 1 : 0);
        return true;
      } else if (ACTION_SELFCHECK.equals(action)) {
        callbackContext.success("heyHO");
        return true;
      }else {
        callbackContext.error("flashlight." + action + " is not a supported function.");
        return false;
      }
    } catch (Exception e) {
      callbackContext.error(e.getMessage());
      return false;
    }
  }

  private boolean isCapable() {
    if (capable == null) {
      capable = false;
      final PackageManager packageManager = this.cordova.getActivity().getPackageManager();
      for (final FeatureInfo feature : packageManager.getSystemAvailableFeatures()) {
        if (PackageManager.FEATURE_CAMERA_FLASH.equalsIgnoreCase(feature.name)) {
          capable = true;
          break;
        }
      }
    }
    //return capable;
    return true;
  }

  private void toggleTorch(boolean switchOn) {
    try {
      if (isCapable()) {
        doToggleTorch(switchOn);
      } else {
        callbackContext.error("Device is not capable of using the flashlight. Please test with flashlight.available()");
      }
    } catch (Exception e) {
      callbackContext.error(e.getMessage());
    }
  }
  @SuppressWarnings("deprecation")
  private void doToggleTorch(boolean switchOn) throws IOException, Exception {
    if (Build.VERSION.SDK_INT >= 23) { // Android M has such an easy API! <3
      doToggleTorchSdk23(switchOn);

    } else {
      if (mCamera == null) {
        mCamera = Camera.open();
        if (Build.VERSION.SDK_INT >= 11) { // honeycomb
          // required for (at least) the Nexus 5
          mCamera.setPreviewTexture(new SurfaceTexture(0));
        }
      }
      final Camera.Parameters mParameters = mCamera.getParameters();
      mParameters.setFlashMode(switchOn ? Camera.Parameters.FLASH_MODE_TORCH : Camera.Parameters.FLASH_MODE_OFF);
      mCamera.stopPreview();
      mCamera.setParameters(mParameters);
      mCamera.startPreview();
      callbackContext.success();
    }
  }
  @TargetApi(21)
  private void doToggleTorchSdk23(boolean switchOn) throws IOException, Exception {
    final CameraManager cameraManager = (CameraManager) cordova.getActivity().getSystemService(Context.CAMERA_SERVICE);
    for (final String id : cameraManager.getCameraIdList()) {
      // Turn on the flash if the camera has one (usually the one at index 0 has one)
      final Boolean hasFlash = cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
      if (Boolean.TRUE.equals(hasFlash)) {
        try {
          final Method setTorchMode = cameraManager.getClass().getMethod("setTorchMode", String.class, boolean.class);
          setTorchMode.invoke(cameraManager, id, switchOn);
          callbackContext.success();
        } catch (ReflectiveOperationException e) {
          callbackContext.error(e.getMessage());
        } catch (Throwable t) {
          callbackContext.error(t.getMessage());
        }
        break;
      }
    }
  }


/*
  private void toggleTorch(boolean switchOn) {
    try {
      if (isCapable()) {
        doToggleTorch(switchOn);
      } else {
        callbackContext.error("Device is not capable of using the flashlight. Please test with flashlight.available()");
      }
    } catch (Exception e) {
      callbackContext.error(e.getMessage());
    }
  }
  @SuppressWarnings("deprecation")
  private void doToggleTorch(boolean switchOn) throws Exception {
      if (mCamera == null) {
        mCamera = Camera.open();
      }
      final Camera.Parameters mParameters = mCamera.getParameters();
      mParameters.setFlashMode(switchOn ? Camera.Parameters.FLASH_MODE_TORCH : Camera.Parameters.FLASH_MODE_OFF);
      try {
          mCamera.stopPreview();
          mCamera.setParameters(mParameters);
          Thread.sleep(100);
          mCamera.startPreview();
      } catch (Exception e) {
          e.printStackTrace();
      }
      if (Build.VERSION.SDK_INT >= 11) { // honeycomb
          try {
               // required for (at least) the Nexus 5
              mCamera.setPreviewTexture(new SurfaceTexture(0));
              return;
          } catch (IOException e) {
              e.printStackTrace();
              return;
          }
      }
      callbackContext.success();
  }
*/


/*
    Parameters params = null;


if(mCamera != null) {
params = mCamera.getParameters();

if(params != null) {
List<String> supportedFlashModes = params.getSupportedFlashModes();

if(supportedFlashModes != null) {

if(supportedFlashModes.contains(Parameters.FLASH_MODE_TORCH)) {
params.setFlashMode( Parameters.FLASH_MODE_TORCH );
} else if(supportedFlashModes.contains(Parameters.FLASH_MODE_ON)) {
params.setFlashMode( Parameters.FLASH_MODE_ON );
} else mCamera = null;



} else Log.d(TAG, "Camera is null.");


if(mCamera != null) {
Log.d(TAG, "Flash disponibile (" + params.getFlashMode() + ")");
 mCamera.setParameters( params );
mCamera.startPreview();
mCamera.autoFocus(null);

} else Log.d(TAG, "Camera is null.");
*/

/*
  private void doToggleTorch(boolean switchOn) throws IOException, CameraAccessException {
    if (Build.VERSION.SDK_INT >= 23) { // Android M has such an easy API! <3
      doToggleTorchSdk23(switchOn);

    } else {
      if (mCamera == null) {
        mCamera = Camera.open();
        if (Build.VERSION.SDK_INT >= 11) { // honeycomb
          // required for (at least) the Nexus 5
          mCamera.setPreviewTexture(new SurfaceTexture(0));
        }
      }
      final Camera.Parameters mParameters = mCamera.getParameters();
      mParameters.setFlashMode(switchOn ? Camera.Parameters.FLASH_MODE_TORCH : Camera.Parameters.FLASH_MODE_OFF);
      mCamera.stopPreview();
      mCamera.setParameters(mParameters);
      mCamera.startPreview();
      callbackContext.success();
    }
  }
  @TargetApi(21)
  private void doToggleTorchSdk23(boolean switchOn) throws IOException, CameraAccessException {
    final CameraManager cameraManager = (CameraManager) cordova.getActivity().getSystemService(Context.CAMERA_SERVICE);
    for (final String id : cameraManager.getCameraIdList()) {
      // Turn on the flash if the camera has one (usually the one at index 0 has one)
      final Boolean hasFlash = cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
      if (Boolean.TRUE.equals(hasFlash)) {
        setTorchMode(cameraManager, id, switchOn);
        break;
      }
    }
  }
  @TargetApi(23)
  private void setTorchMode(CameraManager cameraManager, String id, boolean switchOn) throws CameraAccessException {
    // since folks may not use SDK 23 to compile we'll use reflection as a temporary solution
    try {
      final Method setTorchMode = cameraManager.getClass().getMethod("setTorchMode", String.class, boolean.class);
      setTorchMode.invoke(cameraManager, id, switchOn);
      callbackContext.success();
    } catch (ReflectiveOperationException e) {
      callbackContext.error(e.getMessage());
    } catch (Throwable t) {
      callbackContext.error(t.getMessage());
    }
  }
  */


  public boolean hasPermisssion() {
    for (final String p : permissions) {
      if (!PermissionHelper.hasPermission(this, p)) {
        return false;
      }
    }
    return true;
  }

  public void requestPermissions(int requestCode) {
    PermissionHelper.requestPermissions(this, requestCode, permissions);
  }

  public void onRequestPermissionResult(int requestCode, String[] permissions,
                                        int[] grantResults) throws JSONException {
    PluginResult result;
    for (int r : grantResults) {
      if (r == PackageManager.PERMISSION_DENIED) {
        result = new PluginResult(PluginResult.Status.ILLEGAL_ACCESS_EXCEPTION);
        this.callbackContext.sendPluginResult(result);
        return;
      }
    }

    switch (requestCode) {
      case PERMISSION_CALLBACK_CAMERA:
        toggleTorch(true);
        break;
    }
  }

  private void releaseCamera() {
    releasing = true;
    // we need to release the camera, so other apps can use it
    new Thread(new Runnable() {
      public void run() {
        if (mCamera != null) {
          mCamera.stopPreview();
          mCamera.setPreviewCallback(null);
          mCamera.unlock();
          mCamera.release();
          mCamera = null;
        }
        releasing = false;
      }
    }).start();
  }
}
