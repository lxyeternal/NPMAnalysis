import React from 'react';
declare const Goo: ({ children, className, composite, intensity, id, style, }: {
    children: React.ReactNode;
    className?: string | undefined;
    composite?: boolean | undefined;
    intensity?: "medium" | "strong" | "weak" | undefined;
    id?: string | undefined;
    style?: React.CSSProperties | undefined;
}) => JSX.Element;
export default Goo;
