"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _react = _interopRequireDefault(require("react"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const Goo = ({
  children,
  className,
  composite = false,
  intensity = 'medium',
  id = 'gooey-react',
  style
}) => {
  const blur = intensity === 'weak' ? 8 : intensity === 'strong' ? 16 : 12;
  const alpha = blur * 6;
  const shift = alpha / -2;
  const r = '1 0 0 0 0';
  const g = '0 1 0 0 0';
  const b = '0 0 1 0 0';
  const a = `0 0 0 ${alpha} ${shift}`;
  return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("svg", {
    style: {
      pointerEvents: 'none',
      position: 'absolute'
    }
  }, /*#__PURE__*/_react.default.createElement("defs", null, /*#__PURE__*/_react.default.createElement("filter", {
    colorInterpolationFilters: "sRGB",
    id: id
  }, /*#__PURE__*/_react.default.createElement("feGaussianBlur", {
    stdDeviation: blur
  }), /*#__PURE__*/_react.default.createElement("feColorMatrix", {
    values: `${r} ${g} ${b} ${a}`
  }), composite && /*#__PURE__*/_react.default.createElement("feComposite", {
    in: "SourceGraphic"
  })))), /*#__PURE__*/_react.default.createElement("div", {
    className: className,
    style: { ...style,
      filter: `url(#${id})`
    }
  }, children));
};

var _default = Goo;
exports.default = _default;