import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class TypedNgTemplateDirective<TypeToken> {
    private readonly contentTemplate;
    typeToken: TypeToken;
    constructor(contentTemplate: TemplateRef<TypeToken>);
    static ngTemplateContextGuard<TypeToken>(_dir: TypedNgTemplateDirective<TypeToken>, ctx: unknown): ctx is {
        $implicit: TypeToken;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<TypedNgTemplateDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TypedNgTemplateDirective<any>, "[typedNgTemplate]", never, { "typeToken": "typedNgTemplate"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=typed-ng-template.directive.d.ts.map