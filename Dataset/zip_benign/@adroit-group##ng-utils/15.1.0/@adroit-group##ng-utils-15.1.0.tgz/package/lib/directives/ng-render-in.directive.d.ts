import { EmbeddedViewRef, OnDestroy, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { EApplicationPlatform } from '../constants';
import { PlatformObserverService } from '../services';
import * as i0 from "@angular/core";
/**
 * A structural directive that allows the rendering on templates based on the platform the application is running on.
 * The typical use case of the directive is to enable the usage of different templates for different rendering modes, eg.: usae a different view when the application is ran in SSR.
 *
 * @example ```html
 * <app-splash-screen *ngRenderIn="'browser'"></app-splash-screen>
 *
 * <!-- With alternative template -->
 * <app-splash-screen *ngRenderIn="'browser' or ssrTpl"></app-splash-screen>
 *
 * <ng-template #ssrTpl>...</ng-template>
 * ```
 *
 * There are two utility versions of this directive
 * NgRenderInBrowser (*ngRenderInBrowser) and NgRenderInServer (*ngRenderServer)
 * that do exactly what their names suggest.
 */
export declare class NgRenderInDirective implements OnInit, OnDestroy {
    protected readonly vcr: ViewContainerRef;
    protected readonly templateRef: TemplateRef<unknown>;
    protected readonly platformObserver: PlatformObserverService;
    platform: keyof typeof EApplicationPlatform;
    alternativeTemplate?: TemplateRef<unknown>;
    protected _embeddedView: EmbeddedViewRef<unknown>;
    constructor(vcr: ViewContainerRef, templateRef: TemplateRef<unknown>, platformObserver: PlatformObserverService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgRenderInDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgRenderInDirective, "[ngRenderIn]", never, { "platform": "ngRenderIn"; "alternativeTemplate": "ngRenderInOr"; }, {}, never, never, false, never>;
}
/**
 * A structural directive that only renders it's template if the application is ran in the browser.
 *
 * @example ```html
 * <app-splash-screen *ngRenderInBrowser></app-splash-screen>
 *
 * <!-- With alternative template -->
 * <app-splash-screen *ngRenderInBrowser="or ssrTpl"></app-splash-screen>
 *
 * <ng-template #ssrTpl>...</ng-template>
 * ```
 */
export declare class NgRenderInBrowserDirective extends NgRenderInDirective {
    readonly platform: "browser";
    alternativeTemplate?: TemplateRef<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgRenderInBrowserDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgRenderInBrowserDirective, "[ngRenderInBrowser]", never, { "alternativeTemplate": "ngRenderInBrowserOr"; }, {}, never, never, false, never>;
}
/**
 * A structural directive that only renders it's template if the application is ran in the server environment (SSR).
 *
 * @example ```html
 * <app-splash-screen *ngRenderInServer></app-splash-screen>
 *
 * <!-- With alternative template -->
 * <app-splash-screen *ngRenderInServer="or browserTpl"></app-splash-screen>
 *
 * <ng-template #browserTpl>...</ng-template>
 * ```
 */
export declare class NgRenderInServerDirective extends NgRenderInDirective {
    readonly platform: "server";
    alternativeTemplate?: TemplateRef<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgRenderInServerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgRenderInServerDirective, "[ngRenderInServer]", never, { "alternativeTemplate": "ngRenderInServerOr"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=ng-render-in.directive.d.ts.map