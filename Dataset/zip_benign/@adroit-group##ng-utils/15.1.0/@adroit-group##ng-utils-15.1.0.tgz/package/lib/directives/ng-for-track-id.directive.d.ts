import { NgForOf } from '@angular/common';
import * as i0 from "@angular/core";
/**
 * A utility directive that enhances Angular's *ngFor directive with extra functionality.
 * The directive is implicitly applied every time the original *ngFor is used
 * and provides a trackBy function to it that uses the property name from the directive input or the TRACK_BY_ID injection token's value.
 * @example
 *
 * Implicit usage of the TRACK_BY_ID Injection token's value:
 * ```html
 * <p *ngFor="let item of items$ | async">
 *   {{item}}
 * </p>
 * ```
 *
 * Supplying a track id manually per *ngFor usage:
 * ```html
 * <p *ngFor="let item of items$ | async; trackId: 'name'">
 *   {{item}}
 * </p>
 * ```
 *
 * Overriding the TRACK_BY_ID Injection token's value per component:
 * ```ts
 * \@Component({
 *  selector: 'app-root',
 *  providers: [{provide: TRACK_BY_ID, useValue: 'name'}]
 * })
 * export class AppComponent { ... }
 * ```
 * No additional work needed in the HTML.
 * ```html
 * <p *ngFor="let item of items$ | async">
 *   {{item}}
 * </p>
 * ```
 *
 * @credit
 * Ankit kaushik - https://ankit-kaushik.medium.com/
 *
 * Author's Medium article about the Directive:
 * https://ankit-kaushik.medium.com/trackid-infixing-trackby-capabilities-to-ngfor-in-a-centralised-way-across-your-angular-f1286f703469
 */
export declare class NgForTrackIdDirective {
    private readonly trackId;
    ngForTrackId: string;
    constructor(ngFor: NgForOf<any>, trackId?: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<NgForTrackIdDirective, [{ host: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgForTrackIdDirective, "[ngFor][ngForOf]", never, { "ngForTrackId": "ngForTrackId"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=ng-for-track-id.directive.d.ts.map