import { ChangeDetectorRef, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * The object available in the the *ngLet directive's template.
 */
export declare class NgLetContext<T> {
    /**
     * The implicitly bindable property of the context object.
     */
    $implicit?: T;
    /**
     * The name-sake property of the context object.
     */
    ngLet?: T;
}
/**
 * A structural directive that allows the definition of template variables with ease.
 *
 * @example ```html
 * <!-- Simple case -->
 *  <div *ngLet="user.profileInfo.subscriptionInfo as userSubInfo"> ... </div>
 * <!-- With pipes -->
 *  <div *ngLet="userData$ | async as userData"> ... </div>
 * <!-- Object notation syntax -->
 * <div *ngLet="{ userData: userData$ | async, cartPrice: cartData.totalPrice} as userAndCartData">
 *    <p> {{ userAndCartData.userData.name }} </p>
 *    <p> {{ userAndCartData.cartPrice | currency }} </p>
 * </div>
 * <!-- Array notation syntax -->
 * <div *ngLet="[userData$ | async, cartData.totalPrice] as userAndCartData">
 *    <p> {{ userAndCartData[0].name }} </p>
 *    <p> {{ userAndCartData[1] | currency }} </p>
 * </div>
 * ```
 */
export declare class NgLetDirective<T> implements OnInit {
    #private;
    private readonly vcr;
    private readonly cdr;
    private readonly templateRef;
    private context;
    /**
     * The value(s) that will be made available inside the *ngLet template.
     */
    set ngLet(input: T);
    constructor(vcr: ViewContainerRef, cdr: ChangeDetectorRef, templateRef: TemplateRef<NgLetContext<T>>);
    /**
     * @ignore
     */
    static ngTemplateContextGuard<T>(_dir: NgLetDirective<T>, ctx: unknown): ctx is NgLetContext<T>;
    /**
     * @ignore
     */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgLetDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgLetDirective<any>, "[ngLet]", never, { "ngLet": "ngLet"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=ng-let.directive.d.ts.map