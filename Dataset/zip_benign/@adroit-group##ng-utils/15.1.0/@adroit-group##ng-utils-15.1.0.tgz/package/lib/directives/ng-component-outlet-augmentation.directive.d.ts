import { NgComponentOutlet } from '@angular/common';
import { ComponentRef, EventEmitter, Injector, NgModuleRef, Type, ViewContainerRef } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Interface for the event emitted by the {@link NgComponentOutletAugmentationDirective}
 */
export interface NgComponentOutletEvent {
    key: string;
    event: Record<string, unknown>;
}
/**
 * Augments the {@link NgComponentOutlet} directive to allow for binding of inputs and outputs.
 *
 * @example
 * In your lazy loaded component define the input and outputs you wish to bind to.
 *
 * ```ts
 * \@Component({
 *  selector: 'lazy-loaded-component',
 *  template: `...`
 * })
 * export class LazyLoadedComponent {
 *  \@Input() public input1: string;
 *
 * \@Output() public output1 = new EventEmitter<string>();
 * }
 *
 * ```
 *
 * In the template where you wish to use the component, use the directive to bind the inputs and outputs.
 *
 * ```html
 * <ng-container *ngComponentOutlet="lazyLoadedComp$ | async; inputs: { input1: 'test' }"></ng-container>
 * ```
 *
 * If you want to bind to the lazy loaded components outputs' as well, then you have to use the non-micro-syntax version of the directive, as the micro-syntax version does not support binding to outputs.
 *
 * ```html
 * <ng-container
 *  [ngComponentOutlet]="lazyLoadedComp$ | async"
 *  [ngComponentOutletInputs]="{ input1: 'test' }"
 *  [ngComponentOutletOutputs]="onComponentEvent($event)">
 * </ng-container>
 * ```
 *
 * Then in your component, you can handle the event like so:
 *
 * ```ts
 *
 * export class MyComponentThatUsesLazyLoadedComponent {
 *  public onComponentEvent(event: NgComponentOutletEvent): void {
 *    if (event.key === 'output1') {
 *      // do something with the received event data through event.event
 *    }
 *  }
 * }
 * ```
 */
export declare class NgComponentOutletAugmentationDirective {
    readonly viewContainerRef: ViewContainerRef;
    readonly ngComponentOutlet: NgComponentOutlet;
    component: Type<unknown> | null;
    injector?: Injector;
    content?: Node[][];
    ngModule?: Type<unknown>;
    inputs?: Record<string, unknown>;
    readonly componentEvent: EventEmitter<NgComponentOutletEvent>;
    private originalNgOnChanges;
    get componentRef(): ComponentRef<Record<string, unknown>> | undefined;
    readonly moduleRef: NgModuleRef<unknown> | undefined;
    constructor(viewContainerRef: ViewContainerRef, ngComponentOutlet: NgComponentOutlet);
    private augmentedNgOnChanges;
    private hookUpOutputs;
    private hookUpInputs;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgComponentOutletAugmentationDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgComponentOutletAugmentationDirective, "[ngComponentOutlet]", ["ngComponentOutlet"], { "component": "ngComponentOutlet"; "injector": "ngComponentOutletInjector"; "content": "ngComponentOutletContent"; "ngModule": "ngComponentOutletNgModule"; "inputs": "ngComponentOutletInputs"; }, { "componentEvent": "ngComponentOutletOutputs"; }, never, never, false, never>;
}
//# sourceMappingURL=ng-component-outlet-augmentation.directive.d.ts.map