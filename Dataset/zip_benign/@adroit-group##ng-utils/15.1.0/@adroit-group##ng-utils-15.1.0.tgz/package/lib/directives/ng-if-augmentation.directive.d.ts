import { NgIf, NgIfContext } from '@angular/common';
import { OnChanges, TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * A utility directive that enhances Angular's *ngIf directive with extra functionality.
 * The directive is implicitly applied every time the original *ngIf is used and provides two additional template options for *ngIF.
 * You can supply both a loading and error template for *ngIf.
 * This can be particularly useful when you are working with async data
 * @example ```html
 * <p *ngIf="value$ | async as value else default or loading but error">
 *   {{value}}
 * </p>
 * ```
 * @credit
 * Alexander Inkin - https://medium.com/@waterplea
 *
 * https://medium.com/angularwave/non-binary-ngif-cfdf7c474852
 */
export declare class NgIfAugmentedDirective<T> implements OnChanges {
    private readonly directive;
    private readonly templateRef;
    /**
     * Keeping track of the value
     */
    ngIf: unknown;
    /**
     * Keeping track of original template
     */
    ngIfThen: TemplateRef<NgIfContext<T>>;
    /**
     * Keeping track of original "else" template
     */
    ngIfElse: TemplateRef<NgIfContext<T>> | null;
    /**
     * Template for loading state
     */
    ngIfOr: TemplateRef<NgIfContext<T>> | null;
    /**
     * Template for error state
     */
    ngIfBut: TemplateRef<NgIfContext<T>> | null;
    /**
     * @param directive The original ngIf directive instance on this host element
     * @param templateRef The template encapsulated by the directive.
     */
    constructor(directive: NgIf<T>, templateRef: TemplateRef<NgIfContext<T>>);
    /**
     * @ignore
     */
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgIfAugmentedDirective<any>, [{ host: true; }, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgIfAugmentedDirective<any>, "[ngIf][ngIfOr],[ngIf][ngIfBut]", never, { "ngIf": "ngIf"; "ngIfThen": "ngIfThen"; "ngIfElse": "ngIfElse"; "ngIfOr": "ngIfOr"; "ngIfBut": "ngIfBut"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=ng-if-augmentation.directive.d.ts.map