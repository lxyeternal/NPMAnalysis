import { OnChanges, TemplateRef, ViewContainerRef } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * A utility directive that enhances Angular's *ngFor directive with extra functionality.
 * The directive is implicitly applied every time the original *ngFor is used and provides two additional template options for *ngFor.
 * You can supply both a no array and an empty array template to be rendered.
 * @example ```html
 * <p *ngFor="let item of items$ | async else loading empty blank">
 *   {{item}}
 * </p>
 * ```
 * @credit
 * Alexander Inkin - https://medium.com/@waterplea
 *
 * https://medium.com/angularwave/non-binary-ngif-cfdf7c474852
 */
export declare class NgForAugmentationDirective<T> implements OnChanges {
    private readonly vcr;
    ngForOf?: Array<T>;
    ngForEmpty?: TemplateRef<unknown>;
    ngForElse?: TemplateRef<unknown>;
    private ref?;
    constructor(vcr: ViewContainerRef);
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgForAugmentationDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgForAugmentationDirective<any>, "[ngFor][ngForOf][ngForEmpty],[ngFor][ngForOf][ngForElse]", never, { "ngForOf": "ngForOf"; "ngForEmpty": "ngForEmpty"; "ngForElse": "ngForElse"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=ng-for-augmentation.directive.d.ts.map