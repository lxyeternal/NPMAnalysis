import { FormControlName } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class FormControlNameAugmentationDirective extends FormControlName {
    static ɵfac: i0.ɵɵFactoryDeclaration<FormControlNameAugmentationDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormControlNameAugmentationDirective, "[formControlName]", ["formControlName"], {}, {}, never, never, false, never>;
}
//# sourceMappingURL=form-control-name-augmentation.directive.d.ts.map