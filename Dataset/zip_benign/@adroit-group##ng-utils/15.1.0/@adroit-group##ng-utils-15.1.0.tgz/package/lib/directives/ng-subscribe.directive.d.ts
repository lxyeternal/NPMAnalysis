import { ChangeDetectorRef, OnDestroy, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { Observable, ObservableInput as RxJsObservableInput, Subscribable } from 'rxjs';
import { NgSubscribeBehavior } from '../tokens';
import * as i0 from "@angular/core";
/**
 * The object available in the the *ngSubscribe directive's template.
 */
export declare class NgSubscribeContext<V extends unknown | Array<unknown>> {
    /**
     * The implicitly bindable property of the context object.
     */
    $implicit?: V;
    /**
     * The name-sake property of the context object.
     */
    ngSubscribe?: V;
    /**
     * The error received from the bound Observable or Promise
     */
    error?: Error | string;
    /**
     * Is the bound Observable closed or Promise resolved
     */
    completed: boolean;
}
/**
 * Az NgSubscribe direktíva által használt error template kontextus objektuma.
 * Ez az objektum tartja számon a a direktíva inputjában történt hibát
 */
export declare class NgSubscribeErrorContext {
    /**
     * The implicitly bindable property of the context object.
     */
    $implicit?: Error;
}
/**
 * @internal
 */
type CombineWith = 'combineLatest' | 'forkJoin' | 'zip';
/**
 * @internal
 */
type StreamCombinerFn = <T>(input: Array<RxJsObservableInput<T>>) => Observable<T>;
/**
 * The types of async values bindable to the NGSubscribe directive.
 */
export type AsyncInput<T> = PromiseLike<T> | Subscribable<T>;
/**
 * Egy aszinkron értékeket tartalmazó objektum alakját leíró típus
 */
export type AsyncValuesMap<T> = {
    [K in keyof T]: AsyncInput<T[K]>;
};
/**
 * @internal
 */
type NgSubscribeAsyncInput<T> = AsyncInput<T> | AsyncValuesMap<T>;
/**
* A structural directive that allows the definition of template variables from async sources with ease. This directive does essentially the same as \*ngLet="use$ | async as user" without having to use the `async` pipe explicitly.

* ```html
* <!-- Simple case -->
* <div *ngSubscribe="subscriptionInfo.paymentDueAt$ as paymentDueAt">...</div>
*
* <!-- Object notation syntax -->
* <div
*  \*ngSubscribe="{
*    userData: userData$,
*    paymentDueAt: subscriptionInfo.paymentDueAt$
*  } as userAndSubscriptionData">
*   <p>{{ userAndSubscriptionData.userData.name }}</p>
*   <p>{{ userAndSubscriptionData.paymentDueAt | date }}</p>
* </div>
*
* <!-- Array notation syntax -->
* <div
*  \*ngSubscribe="[
*    userData$,
*    subscriptionInfo.paymentDueAt$
*  ] as userAndSubscriptionData">
*   <p>{{ userAndSubscriptionData[0].name }}</p>
*   <p>{{ userAndSubscriptionData[1] | date }}</p>
* </div>
* ```
*
* The directive utilizes the Angular language service's capabilities and gives you full type checking in it's template.
*/
export declare class NgSubscribeDirective<T> implements OnInit, OnDestroy {
    private readonly vcr;
    private readonly cdr;
    private readonly tpl;
    private readonly missingStreamBehavior;
    private readonly exceptionBehavior;
    /**
     * @ignore
     */
    static ngTemplateGuard_ngSubscribe: 'binding';
    /**
     * Specify the change detection strategy used by the directive when a new async emission happens.
     * Available options are the methods of the `ChangeDetectorRef` responsible for facilitating change detection.
     * Defaults to `markForCheck`
     */
    strategy: 'markForCheck' | 'detectChanges';
    /**
     * Specify the observable combination strategy used by the directive.
     * Under the hood the directive converts all async values to observables so the strategy applies to all inputs supplied to the directive regardless of the input format used.
     * Available options are RXJS's `combineLatest`, `forkJoin`, `zip` or a custom function that takes an array of observable inputs and returns a single observable stream.
     * Defaults to `combineLatest`
     */
    combineWith: CombineWith | StreamCombinerFn;
    set ngSubscribe(input: NgSubscribeAsyncInput<T>);
    set errorTpl(ref: TemplateRef<NgSubscribeErrorContext>);
    set beforeTpl(ref: TemplateRef<null>);
    set afterTpl(ref: TemplateRef<null>);
    set customExceptionBehavior(behavior: NgSubscribeBehavior);
    set customMissingStreamBehavior(behavior: NgSubscribeBehavior);
    private _observable;
    private _context;
    private _errorContext;
    private _subscription;
    private _errorRef;
    private _customExceptionBehavior;
    private _customMissingStreamBehavior;
    private _beforeRef;
    private _afterRef;
    private get getMissingStreamBehavior();
    private readonly _init;
    constructor(vcr: ViewContainerRef, cdr: ChangeDetectorRef, tpl: TemplateRef<NgSubscribeContext<T>>, missingStreamBehavior: NgSubscribeBehavior, exceptionBehavior: NgSubscribeBehavior);
    /**
     * @ignore
     */
    static ngTemplateContextGuard<T>(_dir: NgSubscribeDirective<T>, ctx: unknown): ctx is NgSubscribeContext<T>;
    /**
     * @ignore
     */
    ngOnInit(): void;
    /**
     * @ignore
     */
    ngOnDestroy(): void;
    private handleStreamMerge;
    private subscribeToObservable;
    private mergeObservables;
    private isObservableMap;
    private showBefore;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgSubscribeDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NgSubscribeDirective<any>, "[ngSubscribe]", never, { "strategy": "ngSubscribeWithStrategy"; "combineWith": "ngSubscribeCombineWith"; "ngSubscribe": "ngSubscribe"; "errorTpl": "ngSubscribeError"; "beforeTpl": "ngSubscribeBefore"; "afterTpl": "ngSubscribeAfter"; "customExceptionBehavior": "ngSubscribeExceptionBehavior"; "customMissingStreamBehavior": "ngSubscribeMissingStreamBehavior"; }, {}, never, never, false, never>;
}
export {};
//# sourceMappingURL=ng-subscribe.directive.d.ts.map