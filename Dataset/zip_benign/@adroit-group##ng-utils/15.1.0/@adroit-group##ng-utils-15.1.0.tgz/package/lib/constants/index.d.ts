export * from './application-platform';
//# sourceMappingURL=index.d.ts.map