/**
 * An enum that specifies the platforms where an Angular application can be run.
 * The enum values correspond to the values of the platform id tokens that the Angular DI system can resolve.
 */
export declare const EApplicationPlatform: {
    readonly browser: "browser";
    readonly server: "server";
    readonly browserWorkerApp: "browserWorkerApp";
    readonly browserWorkerUi: "browserWorkerUi";
};
//# sourceMappingURL=application-platform.d.ts.map