export * from './angular-lifecycle-hooks';
//# sourceMappingURL=index.d.ts.map