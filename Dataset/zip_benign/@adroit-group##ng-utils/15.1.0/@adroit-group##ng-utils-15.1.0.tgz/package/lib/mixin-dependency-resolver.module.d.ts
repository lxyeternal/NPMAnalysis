import { Injector } from '@angular/core';
import * as i0 from "@angular/core";
declare const injectorSym: unique symbol;
/**
 * An eagerly loaded and globally available NgModule that's purpose is to act as a mediator between mixin classes and the Angular DI system.
 * If a mixin class requires dependencies from the Angular Di system it can request it through this Module class using
 * it's static property injector, which is an instance of the app's root injector.
 * If a mixin requires context or template specific dependencies than this module isn't a valid solution as it's injector
 * is the global injector and thus has no notion of the context and template specific dependencies.
 */
export declare class MixinDependencyResolverModule {
    static get injector(): Injector;
    private static [injectorSym];
    constructor(injector: Injector);
    static ɵfac: i0.ɵɵFactoryDeclaration<MixinDependencyResolverModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MixinDependencyResolverModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MixinDependencyResolverModule>;
}
export {};
//# sourceMappingURL=mixin-dependency-resolver.module.d.ts.map