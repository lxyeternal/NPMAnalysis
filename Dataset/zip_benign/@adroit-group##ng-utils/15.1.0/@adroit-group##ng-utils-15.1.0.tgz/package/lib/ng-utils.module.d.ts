import { ModuleWithProviders } from '@angular/core';
import { PlatformObserverService } from './services/platform-observer.service';
import * as i0 from "@angular/core";
import * as i1 from "./directives/form-control-name-augmentation.directive";
import * as i2 from "./directives/ng-component-outlet-augmentation.directive";
import * as i3 from "./directives/ng-let.directive";
import * as i4 from "./directives/ng-subscribe.directive";
import * as i5 from "./directives/ng-for-augmentation.directive";
import * as i6 from "./directives/ng-for-track-id.directive";
import * as i7 from "./directives/ng-if-augmentation.directive";
import * as i8 from "./directives/ng-render-in.directive";
import * as i9 from "./directives/typed-ng-template.directive";
import * as i10 from "./pipes/method-invoker.pipe";
import * as i11 from "./pipes/safe.pipe";
import * as i12 from "@angular/common";
import * as i13 from "./mixin-dependency-resolver.module";
import * as i14 from "@angular/cdk/layout";
export declare class AdroitNgUtilsModule {
    static platformObserver: PlatformObserverService;
    static forRoot(): ModuleWithProviders<AdroitNgUtilsModule>;
    constructor(platformObserver: PlatformObserverService);
    static ɵfac: i0.ɵɵFactoryDeclaration<AdroitNgUtilsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AdroitNgUtilsModule, [typeof i1.FormControlNameAugmentationDirective, typeof i2.NgComponentOutletAugmentationDirective, typeof i3.NgLetDirective, typeof i4.NgSubscribeDirective, typeof i5.NgForAugmentationDirective, typeof i6.NgForTrackIdDirective, typeof i7.NgIfAugmentedDirective, typeof i8.NgRenderInDirective, typeof i8.NgRenderInBrowserDirective, typeof i8.NgRenderInServerDirective, typeof i9.TypedNgTemplateDirective, typeof i10.MethodInvokerPipe, typeof i11.SafePipe], [typeof i12.CommonModule, typeof i13.MixinDependencyResolverModule, typeof i14.LayoutModule], [typeof i1.FormControlNameAugmentationDirective, typeof i2.NgComponentOutletAugmentationDirective, typeof i3.NgLetDirective, typeof i4.NgSubscribeDirective, typeof i5.NgForAugmentationDirective, typeof i6.NgForTrackIdDirective, typeof i7.NgIfAugmentedDirective, typeof i8.NgRenderInDirective, typeof i8.NgRenderInBrowserDirective, typeof i8.NgRenderInServerDirective, typeof i9.TypedNgTemplateDirective, typeof i10.MethodInvokerPipe, typeof i11.SafePipe, typeof i14.LayoutModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AdroitNgUtilsModule>;
}
//# sourceMappingURL=ng-utils.module.d.ts.map