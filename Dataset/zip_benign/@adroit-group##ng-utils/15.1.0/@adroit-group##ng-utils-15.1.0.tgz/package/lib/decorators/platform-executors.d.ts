import { EApplicationPlatform } from '../constants';
/**
 * An Alias decorator for \@RunIn(EApplicationPlatform.Server)
 *
 * @example ```ts
 * \@Component({
 *     selector: 'app-root',
 *     templateUrl: './app.component.html',
 *     styleUrls: ['./app.component.scss']
 * })
 * export class AppComponent {
 *   \@RunInServer()
 *   public set setterThatSetsMetaTags(value) { ... }
 * }
 * ```
 */
export declare function RunOnServer(): MethodDecorator;
/**
 * An Alias decorator for \@RunIn(EApplicationPlatform.Browser)
 *
 * @example ```ts
 * \@Component({
 *     selector: 'app-root',
 *     templateUrl: './app.component.html',
 *     styleUrls: ['./app.component.scss']
 * })
 * export class AppComponent {
 *   \@RunInBrowser()
 *   public set setterThatUsesWindow(value: string) { ... }
 * }
 * ```
 */
export declare function RunInBrowser(): MethodDecorator;
export declare function RunInWorkerApp(): MethodDecorator;
export declare function RunInWorkerUI(): MethodDecorator;
/**
 * A decorator that restricts the usage of methods and accessors.
 *
 * Methods and accessors decorated will only ran (when invoked
 * from the client code), if the application's active platform matches those supplied to the decorator.
 *
 * This makes it easy to optimize various execution scenarios
 * and rid the application of execution paths that would cause problems in certain environments.
 *
 * @param platforms An array of the platform IDs or a single platform ID where the method/accessor can be run.
 *
 * @example ```ts
 * \@Component({
 *     selector: 'app-root',
 *     templateUrl: './app.component.html',
 *     styleUrls: ['./app.component.scss']
 * })
 * export class AppComponent {
 *   \@RunInBrowser()
 *   public set setterThatUsesWindow(value: string) { ... }
 *
 *   \@RunIn(EApplicationPlatform.Browser)
 *   public methodThatUsesWindow(value: string) { ... }
 * }
 * ```
 */
export declare function RunOnPlatform(platforms: keyof typeof EApplicationPlatform | [keyof typeof EApplicationPlatform | string[]]): MethodDecorator;
//# sourceMappingURL=platform-executors.d.ts.map