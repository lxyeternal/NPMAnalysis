/**
 * A decorator which ensures that the lifecycle hooks of components and directives that use mixins are called properly.
 * The decorator applies automatic binding for the Angular specific lifecycle hook and the additionally supplied methods on classes  extending mixin functions by linking up the existing methods on the classes' prototype chains.
 * This ensures that both the components' own methods and any other method on the mixins' prototypes are called in the same order in which constructor calls would do. (Starting with the last mixin class and calling continuosly toward the actual class that extends the mixins)
 * @param additionalHooks An array of method names to be bound on top of the Angular lifecycle hooks
 * @remarks Nor the classes decorated with AutoHooks decorator neither the mixin or base classes applied to it are allowed to manually call the super version of the methods being bound.
 * That would result in unintended and multiply invocation of said methods.
 * The ngOnChanges hook is exempt from this behaviour when the decorator is used with an Angular version less than v10 as binding this lifecycle hooks results in a faulty behavior where the method does not receive the changes parameter object.
 * If a class's prototype chain contains real classes apart from the applied mixins those classes cannot use AutoHooks in tandem with the child class's decorator.
 * @example ```ts
 * \@Component({
 *   selector: 'my-comp',
 *   templateUrl: './my.component.html',
 *   styleUrls: ['./my.component.scss'],
 * })
 * \@AutoHooks()
 * export class MyComp extends SubscriptionHandlerMixin() implements OnInit { ... }
 * ```
 */
export declare function AutoHooks(additionalHooks?: Array<string>): ClassDecorator;
//# sourceMappingURL=auto-hooks.d.ts.map