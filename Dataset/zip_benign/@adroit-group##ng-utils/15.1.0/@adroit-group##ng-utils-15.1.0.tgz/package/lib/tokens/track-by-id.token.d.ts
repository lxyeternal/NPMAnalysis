import { InjectionToken } from "@angular/core";
export declare const TRACK_BY_ID: InjectionToken<string>;
//# sourceMappingURL=track-by-id.token.d.ts.map