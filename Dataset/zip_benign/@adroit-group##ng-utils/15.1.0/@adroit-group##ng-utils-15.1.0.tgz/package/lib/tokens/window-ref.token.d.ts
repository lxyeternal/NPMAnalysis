import { InjectionToken } from '@angular/core';
/**
 * An InjectionToken used to safely access window and workerGlobalScope in browser and worker contexts respectively.
 *
 * @throws TypeError: If used in the context of platformServer.
 */
export declare const WINDOW: InjectionToken<Window | null>;
//# sourceMappingURL=window-ref.token.d.ts.map