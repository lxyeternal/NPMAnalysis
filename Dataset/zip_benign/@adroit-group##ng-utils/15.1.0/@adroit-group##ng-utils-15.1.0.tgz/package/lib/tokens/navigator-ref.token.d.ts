import { InjectionToken } from '@angular/core';
/**
 * An InjectionToken used to safely access the navigator global object in the browser and worker contexts respectively.
 *
 * @throws TypeError: If used in an environment without window or navigator like global objects.
 */
export declare const NAVIGATOR: InjectionToken<Navigator | null>;
//# sourceMappingURL=navigator-ref.token.d.ts.map