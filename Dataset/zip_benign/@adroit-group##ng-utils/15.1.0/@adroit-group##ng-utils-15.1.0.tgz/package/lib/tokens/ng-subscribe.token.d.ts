import { InjectionToken } from '@angular/core';
import { Observable } from 'rxjs';
export type NgSubscribeBehaviorHandler = (...deps: Array<unknown>) => Observable<unknown>;
export type NgSubscribeBehavior = Observable<unknown> | NgSubscribeBehaviorHandler;
export declare const NG_SUBSCRIBE_EXCEPTION_BEHAVIOR: InjectionToken<NgSubscribeBehavior>;
export declare const NG_SUBSCRIBE_MISSING_STREAM_BEHAVIOR: InjectionToken<NgSubscribeBehavior>;
//# sourceMappingURL=ng-subscribe.token.d.ts.map