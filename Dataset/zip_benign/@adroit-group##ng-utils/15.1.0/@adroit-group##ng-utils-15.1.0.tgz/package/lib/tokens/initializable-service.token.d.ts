import { InjectionToken } from '@angular/core';
import { IInitializable } from '../interfaces';
export declare const INITIALIZABLE_SERVICE: InjectionToken<IInitializable>;
//# sourceMappingURL=initializable-service.token.d.ts.map