import { InjectionToken } from '@angular/core';
/**
 * @example
 * ```ts
 *   Component({
 *       selector: 'app-filters',
 *       templateUrl: './filters.component.html',
 *       styleUrls: ['./filters.component.scss'],
 *       viewProviders: [
 *           {
 *               provide: METHOD_INVOKER_PIPE_HOST,
 *               useExisting: forwardRef(() => FiltersComponent)
 *           }
 *       ]
 *   })
 *  ```
 */
export declare const METHOD_INVOKER_PIPE_HOST: InjectionToken<unknown>;
//# sourceMappingURL=method-invoker-pipe-host.token.d.ts.map