/**
 * An Error throw when a singleton module is loaded more than once.
 * This error should not be handled in the app because it indicates that a module that supposed to be included only once was included more than once.
 * Instead scenarios which would result in this error should be found and fixed during development.
 *
 * @example
 * ```ts
 *  throw new ModuleLoadError(((self as unknown) as Function).name);
 * ```
 */
export declare class ModuleLoadError extends Error {
    readonly moduleName: string;
    /**
     * @param moduleName The name of the NgModule which could no be loaded.
     */
    constructor(moduleName: string);
}
//# sourceMappingURL=module-load-error.d.ts.map