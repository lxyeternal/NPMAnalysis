export { ModuleLoadError } from './module-load-error';
export { ASingletonModule } from './singleton-module';
//# sourceMappingURL=index.d.ts.map