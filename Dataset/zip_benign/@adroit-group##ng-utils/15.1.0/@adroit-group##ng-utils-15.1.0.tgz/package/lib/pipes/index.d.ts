import { MethodInvokerPipe } from './method-invoker.pipe';
import { SafePipe } from './safe.pipe';
export { MethodInvokerPipe } from './method-invoker.pipe';
export { SafePipe } from './safe.pipe';
/**
 * @internal
 */
export declare const LIB_PIPES: (typeof MethodInvokerPipe | typeof SafePipe)[];
//# sourceMappingURL=index.d.ts.map