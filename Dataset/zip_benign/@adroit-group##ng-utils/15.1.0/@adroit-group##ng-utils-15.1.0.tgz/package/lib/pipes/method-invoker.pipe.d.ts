import { PipeTransform } from '@angular/core';
import { InvokableMethod } from '../types';
import * as i0 from "@angular/core";
/**
 * A meta pipe that aims to replace most or all other pipes in your application.
 * This pipe take a function and optionally it's arguments as parameter(s) an executes it.
 * A context object can be supply to the pipe through Angular's DI system
 * in turn enabling the usage and reference of the this parameter of the component or directive that defined the function.
 *
 * @example
 *
 * Without context
 *```html
 * <p> {{ getRelativeDateTime | invoke: orderDate }} </p>
 *```
 *
 * With context
 *```ts
 * \@component({
 *  ...
 *  providers: [
 *    {
 *      provide: METHOD_INVOKER_PIPE_HOST,
 *      useExisting: MyComponent
 *    }
 *  ]
 * })
 * export class MyComponent {
 *  ...
 *
 *  public title = 'My App';
 *
 *  public componentMethodThatUsesThis(): string {
 *    return this.title;
 *  }
 * }
 *```
 *```html
 * <p> {{ componentMethodThatUsesThis | invoke }} </p>
 *```
 */
export declare class MethodInvokerPipe implements PipeTransform {
    private readonly host?;
    constructor(host?: unknown);
    transform<T, U>(value: T, method: InvokableMethod<T, U>, ...restArgs: Array<unknown>): U;
    static ɵfac: i0.ɵɵFactoryDeclaration<MethodInvokerPipe, [{ optional: true; }]>;
    static ɵpipe: i0.ɵɵPipeDeclaration<MethodInvokerPipe, "invoke", false>;
}
//# sourceMappingURL=method-invoker.pipe.d.ts.map