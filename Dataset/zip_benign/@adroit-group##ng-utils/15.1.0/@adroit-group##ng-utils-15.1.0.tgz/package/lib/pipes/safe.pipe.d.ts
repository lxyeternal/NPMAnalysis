import { PipeTransform } from '@angular/core';
import { DomSanitizer, SafeHtml, SafeResourceUrl, SafeScript, SafeStyle, SafeUrl } from '@angular/platform-browser';
import * as i0 from "@angular/core";
/**
 * Union type of all possible safe value types.
 */
export type SafeValueType = 'url' | 'script' | 'style' | 'resourceUrl' | 'html';
/**
 * @ignore
 */
type SafeValueResultMap = {
    html: SafeHtml;
    resourceUrl: SafeResourceUrl;
    script: SafeScript;
    style: SafeStyle;
    url: SafeUrl;
};
/**
 * A pipe that bypasses Angular's built-in sanitization for the following
 * security contexts:
 * - HTML
 * - Style
 * - Script
 * - URL
 * - Resource URL
 *
 * @remarks The pipe assumes HTML content to be sanitized by default.
 *
 * Usage:
 *
 * @example ```html
 * {{ value | safe }}
 * {{ value | safe:'html' }}
 * {{ value | safe:'style' }}
 * {{ value | safe:'script' }}
 * {{ value | safe:'url' }}
 * {{ value | safe:'resourceUrl' }}
 * ```
 */
export declare class SafePipe implements PipeTransform {
    private readonly sanitizer;
    /**
     * @ignore
     */
    private readonly actionMap;
    constructor(sanitizer: DomSanitizer);
    /**
     * Use Angular's DOMSanitizer to bypass security for the specified content.
     *
     * @param content The content to be sanitized.
     * @param type The type of the content to be sanitized.
     * @returns A safe value of the specified type.
     */
    transform<Type extends SafeValueType = 'html'>(content: string, type?: Type): SafeValueResultMap[Type];
    static ɵfac: i0.ɵɵFactoryDeclaration<SafePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SafePipe, "safe", false>;
}
export {};
//# sourceMappingURL=safe.pipe.d.ts.map