import * as i0 from "@angular/core";
/**
 * An Injectable service that helps to identify the platform where the application runs.
 */
export declare class PlatformObserverService {
    readonly platformID: string;
    readonly window: Window;
    /**
     * Gets whether the app is running in the browser
     */
    get isPlatformBrowser(): boolean;
    /**
     * Gets whether the app is running on the server
     */
    get isPlatformServer(): boolean;
    /**
     * Gets whether the app is running in the web worker
     */
    get isPlatformWorker(): boolean;
    /**
     * @param platformID The platform id of the platform where the application is running
     */
    constructor(platformID: string, window: Window);
    static ɵfac: i0.ɵɵFactoryDeclaration<PlatformObserverService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PlatformObserverService>;
}
//# sourceMappingURL=platform-observer.service.d.ts.map