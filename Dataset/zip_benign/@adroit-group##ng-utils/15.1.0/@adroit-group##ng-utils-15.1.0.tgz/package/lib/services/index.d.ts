import { PlatformObserverService } from './platform-observer.service';
export { PlatformObserverService } from './platform-observer.service';
/**
 * @internal
 */
export declare const LIB_SERVICES: (typeof PlatformObserverService)[];
//# sourceMappingURL=index.d.ts.map