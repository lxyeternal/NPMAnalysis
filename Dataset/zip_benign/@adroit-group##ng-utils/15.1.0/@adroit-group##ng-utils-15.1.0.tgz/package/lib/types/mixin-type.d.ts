import { MappedToTuple } from './mapped';
import { CastToTuple, ConcatTuples, TupleToMapped } from './tuple';
import { ReturnTypeUnsafe } from '../interfaces/constructor';
/**
 * @summary Given a Constructor type gets the instance type created by the constructor.
 */
export type PrototypeOf<T> = T extends {
    prototype: infer P;
} ? P : unknown;
/**
 * Given a tuple that contains a rest type as it's last element (usually a constructor parameter type) returns a new tuple type with the same types in it except the last rest element.
 * @example
 * type testDropRestParams =
 *  DropRestParams<[string, number, ...any[]]>; // => [string, number];
 */
type DropRestParams<T extends any[]> = MappedToTuple<TupleToMapped<T>>;
/**
 * @summary Given a Constructor type gets the parameters expected by it.
 */
type CtorParams<T> = T extends MixinConstructor<any, infer Params> ? CastToTuple<Params> : [];
export type CopyStruct<T> = Pick<T, keyof T>;
type ParametersUnsafe<T> = T extends new (...args: infer P) => any ? P : [];
export declare type ComposePrototypes<Mixin, Base> = {
    prototype: InferProto<Base> & InferProto<Mixin>;
};
type ComposeCtors<Mixin, Base> = Omit<Base, 'prototype'> & Omit<Mixin, 'prototype'>;
export type ComposeClasses<Mixin, Base> = ComposeCtors<Mixin, Base> & ComposePrototypes<Mixin, Base>;
type AppendRestIfNeeded<T extends any[]> = T['length'] extends 0 ? T : [...T, ...any[]];
type MixinCtorParams<Mixin, Base> = AppendRestIfNeeded<ConcatTuples<DropRestParams<CtorParams<Mixin>>, DropRestParams<CtorParams<Base>>>>;
type InferProto<T> = ReturnTypeUnsafe<T> extends {
    prototype: infer Proto;
} ? Proto : ReturnTypeUnsafe<T>;
export declare type MixinConstructor<T, P = ParametersUnsafe<T>> = CopyStruct<T> & {
    new (...args: CastToTuple<P>): InferProto<T>;
    prototype: InferProto<T>;
};
/**
 * @summary The special constructor type used by mixin functions.
 * Returns a regular constructor type with the appropriate instance type and constructor parameters
 * after merging the types of the supplied mixin functions' results.
 */
export type MixinType<Mixin, Base> = Base extends new (...args: any[]) => any ? MixinConstructor<ComposeClasses<Mixin, Base>, MixinCtorParams<Mixin, Base>> : MixinConstructor<Mixin>;
export {};
//# sourceMappingURL=mixin-type.d.ts.map