import { Injector, InjectFlags, ProviderToken } from '@angular/core';
/**
 * @internal
 */
interface IMixinDependencyResolverConfig {
    injector?: Injector;
    notFoundValue?: any;
    flags?: InjectFlags;
}
export declare function resolveMixinDependency<T>(dep: ProviderToken<T>, config?: IMixinDependencyResolverConfig): T;
export {};
//# sourceMappingURL=resolve-mixin-dependency.d.ts.map