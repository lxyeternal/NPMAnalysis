import { Constructor } from '../interfaces';
import { MixinType } from '../types';
/**
 * A Mixin function that provides functionality related to handling track-by functions for ngFor directives used in the component's template.
 * A class extending this mixin will have access to a general purpose `trackBy` function that can be referenced in the component's template for ngFor directives' `trackBy` inputs.
 * The `trackBy` function will try to use the received objects' ids as unique keys, however this behavior can be configured in the mixin's second parameter.
 *
 * @example
 * ```ts
 * class MyComp extends TrackByHandlerMixin() {
 *    constructor() {
 *      super();
 *    }
 * }
 *```
 *
 *```html
 *  <div *ngFor="pics of pictures; trackBy: trackBy">...</div>
 *```
 **/
export declare function TrackByHandlerMixin<T extends Constructor<any, unknown[]>>(base?: T, trackByKeyOrPropFn?: string | ((item: any) => string)): MixinType<{
    new (...args: unknown[]): {
        
        trackBy(index: number, item: any): string;
    };
}, T>;
//# sourceMappingURL=track-by-handler.mixin.d.ts.map