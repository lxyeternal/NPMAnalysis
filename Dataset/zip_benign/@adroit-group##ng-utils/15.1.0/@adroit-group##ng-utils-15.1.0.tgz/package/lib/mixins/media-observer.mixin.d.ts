import { BreakpointObserver } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { Constructor } from '../interfaces';
import { MixinType } from '../types';
/**
 * A Mixin function that provides functionality related to observing the browser viewport's size.
 * A class extending this mixin will have access to various observables named after the convention followed by numerous CSS frameworks: xs$, sm$, md$, lg$, xl$, etc...
 * These observable stream will always emit a boolean value indicating if the browser's viewport currently has a size fitting that breakpoint size criteria.
 * @example
 * ```ts
 * class MyComp extends MediaObserver() {
 *      constructor() {
 *           super();
 *       }
 *  }
 * ```
 *
 * ```html
 * <div *ngIf="xs$ | async; else desktopTpl"> ... </div>
 * ```
 */
export declare function MediaObserverMixin<T extends Constructor<any, unknown[]>>(base?: T): MixinType<{
    new (...args: unknown[]): {
        
        readonly breakpointObserver: BreakpointObserver;
        readonly xs$: Observable<boolean>;
        readonly sm$: Observable<boolean>;
        readonly md$: Observable<boolean>;
        readonly lg$: Observable<boolean>;
        readonly xl$: Observable<boolean>;
        /**
         * An observable that indicates whether or not the window's viewport height is considered very low.
         */
        readonly veryLowMediaHeight$: Observable<boolean>;
        observe(size: string): Observable<boolean>;
    };
}, T>;
//# sourceMappingURL=media-observer.mixin.d.ts.map