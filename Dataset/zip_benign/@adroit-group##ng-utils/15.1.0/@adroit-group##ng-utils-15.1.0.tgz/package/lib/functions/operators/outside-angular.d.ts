import { NgZone } from '@angular/core';
import { Observable } from 'rxjs';
/**
 * An RXJS operator function that runs the supplied callback function outside Angular's zone thus bypassing change detection.
 */
export declare function outsideZone<T>(zone: NgZone): (source: Observable<T>) => Observable<T>;
//# sourceMappingURL=outside-angular.d.ts.map