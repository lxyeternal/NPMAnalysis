import { Observable } from 'rxjs';
import { AsyncValue } from '../types';
export declare function observify<T>(value: T | AsyncValue<T>): Observable<T>;
//# sourceMappingURL=observify.d.ts.map