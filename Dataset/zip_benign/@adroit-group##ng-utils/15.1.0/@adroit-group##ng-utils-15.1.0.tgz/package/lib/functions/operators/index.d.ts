export * from './outside-angular';
//# sourceMappingURL=index.d.ts.map