import { inject, EnvironmentInjector } from '@angular/core';

/* eslint-disable @typescript-eslint/triple-slash-reference */
/// <reference path="../typings.d.ts" />
/**
 * @internal
 */
function runInContext(fn) {
    const envInjector = window.DI_UNCHAINED_INJECTOR_SYMBOL;
    return envInjector.runInContext(fn);
}

/**
 * @internal
 */
function bindDescriptor(target, member, descriptor) {
    const { get, set, value } = descriptor;
    let changed = 0;
    if (typeof get === 'function') {
        descriptor['get'] = () => runInContext(() => get());
        changed++;
    }
    if (typeof set === 'function') {
        descriptor['set'] = (arg) => runInContext(() => set(arg));
        changed++;
    }
    if (typeof value === 'function') {
        descriptor['value'] = (...args) => runInContext(() => value(args));
        changed++;
    }
    if (changed) {
        Object.defineProperty(target, member, descriptor);
    }
}

/**
 * @internal
 */
function bindCLass(protoOrCtor) {
    const protoMembers = Object.entries(Object.getOwnPropertyDescriptors(protoOrCtor)).filter(([member, descriptor]) => (typeof descriptor.value === 'function' && member !== 'constructor') ||
        descriptor.get ||
        descriptor.set);
    protoMembers.forEach(([member, descriptor]) => bindDescriptor(protoOrCtor, member, descriptor));
}

/* eslint-disable @typescript-eslint/ban-types */
/**
 * @internal
 */
function wrapClass(target) {
    const proto = target.prototype;
    if (!target || !proto)
        return;
    bindCLass(proto);
    bindCLass(target);
    return new Proxy(target, {
        construct: (target, argArray, newTarget) => {
            return runInContext(() => Reflect.construct(target, argArray, newTarget));
        },
    });
}

/* eslint-disable @typescript-eslint/triple-slash-reference */
/**
 * The same as {@link WithDIContext} but with a fancier name.
 */
function Unchained() {
    return (target, propKey, descriptor) => {
        const mode = !!propKey && typeof descriptor === 'object' ? 'method' : 'class';
        return mode === 'method'
            ? bindDescriptor(target, propKey, descriptor)
            : wrapClass(target);
    };
}
/**
 * The same as {@link DIContextProvider} but with a fancier name.
 */
function DI() {
    return (target) => {
        return new Proxy(target, {
            construct(target, argArray, newTarget) {
                const instance = Reflect.construct(target, argArray, newTarget);
                window.DI_UNCHAINED_INJECTOR_SYMBOL = inject(EnvironmentInjector);
                return instance;
            },
        });
    };
}
/**
 * An Angular ngModule class decorator the marks an Angular NgModule as the DI provider for `@Unchained` classes.
 *
 * You have to use this decorator on your root module (AppModule) in order to use `@Unchained` decorator on non Angular classes.
 *
 * @note The normal DI resolution rules apply to `Unchained` classes and their providers as well.
 * e.g.: Providers provided in their own lazy-loaded modules' providers array ARE NOT resolvable in other modules contexts.
 *
 * @example ```ts
 * \@DI()
 * \@NgModule({
 *   declarations: [AppComponent],
 *   bootstrap: [AppComponent],
 * })
 * export class AppModule {}
 * ```
 */
const DIContextProvider = DI;
/**
 * Decorator that frees your classes from the shackles of Angular DI.
 * Allowing them to fully utilize it without requiring Angular's class decorators: Component, Directive, Injectable, Pipe, Module.
 *
 * The decorator can be used as a class, method, get/set accessor decorator.
 * But you
 *
 * @example ```ts
 * \@Unchained()
 * class MyClass {
 *   router: Router;
 *
 *   routerFn = () => inject(Router);
 *
 *   static routerFn = () => inject(Router);
 *
 *   constructor() {
 *     this.router = inject(Router);
 *   }
 *
 *   getTitleService() {
 *     const title = inject(Title);
 *
 *     console.log('title: ', title);
 *   }
 *
 *   public get neta() {
 *     return inject(Meta);
 *   }
 *
 *   public static get appRef() {
 *     return inject(ApplicationRef);
 *   }
 *
 *   static getRouter() {
 *     return inject(Router);
 *   }
 * }
 * ```
 */
const WithDIContext = Unchained;

/**
 * Generated bundle index. Do not edit.
 */

export { DI, DIContextProvider, Unchained, WithDIContext };
//# sourceMappingURL=adroit-group-ng-utils-di-unchained.mjs.map
