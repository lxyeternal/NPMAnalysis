import * as i0 from '@angular/core';
import { Component, Input, ViewChild, NgModule } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

class CdpsComponent {
    constructor() {
        this._counter = 0;
        this.cdps = 0;
    }
    ngOnInit() {
        setInterval(() => (this.cdps = 0), 1000);
    }
    ngDoCheck() {
        var _a;
        if ((_a = this.cdCounter) === null || _a === void 0 ? void 0 : _a.nativeElement) {
            this.cdCounter.nativeElement.innerHTML = `${this._counter++}`;
            this.cdps++;
        }
    }
}
CdpsComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: CdpsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
CdpsComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.0", type: CdpsComponent, selector: "ad-cdps", inputs: { styles: "styles" }, viewQueries: [{ propertyName: "cdCounter", first: true, predicate: ["cdCounter"], descendants: true }], ngImport: i0, template: "<div\n  class=\"cd-counter position-fixed\"\n  [ngStyle]=\"styles\"\n  style=\"font-size: 30px; color: red; bottom: 10px; left: 10px; z-index: 69420\"\n  #cdCounter\n>\n  0\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: CdpsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ad-cdps', template: "<div\n  class=\"cd-counter position-fixed\"\n  [ngStyle]=\"styles\"\n  style=\"font-size: 30px; color: red; bottom: 10px; left: 10px; z-index: 69420\"\n  #cdCounter\n>\n  0\n</div>\n" }]
        }], propDecorators: { styles: [{
                type: Input
            }], cdCounter: [{
                type: ViewChild,
                args: ['cdCounter']
            }] } });

class NgxCdpsMeterModule {
}
NgxCdpsMeterModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgxCdpsMeterModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
NgxCdpsMeterModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.0", ngImport: i0, type: NgxCdpsMeterModule, declarations: [CdpsComponent], imports: [CommonModule] });
NgxCdpsMeterModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgxCdpsMeterModule, imports: [CommonModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgxCdpsMeterModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule],
                    declarations: [CdpsComponent],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { NgxCdpsMeterModule };
//# sourceMappingURL=adroit-group-ng-utils-ngx-cdps-meter.mjs.map
