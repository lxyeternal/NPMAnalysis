/// <reference types="libs/ng-utils/di-unchained/src/typings" />
/**
 * @internal
 */
export declare function runInContext<T extends () => any>(fn: T): ReturnType<T>;
//# sourceMappingURL=run-in-context.d.ts.map