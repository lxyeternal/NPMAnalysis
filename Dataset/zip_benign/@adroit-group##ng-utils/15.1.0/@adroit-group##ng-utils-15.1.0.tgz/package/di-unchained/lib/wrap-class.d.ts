/**
 * @internal
 */
export declare function wrapClass(target: Function): Function | undefined;
//# sourceMappingURL=wrap-class.d.ts.map