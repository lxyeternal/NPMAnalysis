/**
 * @internal
 */
export declare function bindDescriptor(target: object, member: PropertyKey, descriptor: TypedPropertyDescriptor<unknown> & PropertyDescriptor): void;
//# sourceMappingURL=bind-descriptor.d.ts.map