/// <reference types="libs/ng-utils/di-unchained/src/typings" />
/**
 * The same as {@link WithDIContext} but with a fancier name.
 */
declare function Unchained(): (target: any, propKey?: PropertyKey, descriptor?: TypedPropertyDescriptor<any>) => any;
/**
 * The same as {@link DIContextProvider} but with a fancier name.
 */
declare function DI(): ClassDecorator;
/**
 * An Angular ngModule class decorator the marks an Angular NgModule as the DI provider for `@Unchained` classes.
 *
 * You have to use this decorator on your root module (AppModule) in order to use `@Unchained` decorator on non Angular classes.
 *
 * @note The normal DI resolution rules apply to `Unchained` classes and their providers as well.
 * e.g.: Providers provided in their own lazy-loaded modules' providers array ARE NOT resolvable in other modules contexts.
 *
 * @example ```ts
 * \@DI()
 * \@NgModule({
 *   declarations: [AppComponent],
 *   bootstrap: [AppComponent],
 * })
 * export class AppModule {}
 * ```
 */
declare const DIContextProvider: typeof DI;
/**
 * Decorator that frees your classes from the shackles of Angular DI.
 * Allowing them to fully utilize it without requiring Angular's class decorators: Component, Directive, Injectable, Pipe, Module.
 *
 * The decorator can be used as a class, method, get/set accessor decorator.
 * But you
 *
 * @example ```ts
 * \@Unchained()
 * class MyClass {
 *   router: Router;
 *
 *   routerFn = () => inject(Router);
 *
 *   static routerFn = () => inject(Router);
 *
 *   constructor() {
 *     this.router = inject(Router);
 *   }
 *
 *   getTitleService() {
 *     const title = inject(Title);
 *
 *     console.log('title: ', title);
 *   }
 *
 *   public get neta() {
 *     return inject(Meta);
 *   }
 *
 *   public static get appRef() {
 *     return inject(ApplicationRef);
 *   }
 *
 *   static getRouter() {
 *     return inject(Router);
 *   }
 * }
 * ```
 */
declare const WithDIContext: typeof Unchained;
export { DI, DIContextProvider, Unchained, WithDIContext };
//# sourceMappingURL=decorators.d.ts.map