/**
 * @internal
 */
export declare function bindCLass(protoOrCtor: object): void;
//# sourceMappingURL=bind-class.d.ts.map