import { LayoutModule, BreakpointObserver } from '@angular/cdk/layout';
import * as i1 from '@angular/common';
import { isPlatformBrowser, isPlatformServer, isPlatformWorkerUi, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Directive, EventEmitter, Input, Output, TemplateRef, InjectionToken, inject, PLATFORM_ID, Host, Optional, Inject, Injectable, NgModule, Pipe } from '@angular/core';
import { FormControlName } from '@angular/forms';
import { NEVER, EMPTY, Observable, from, of, combineLatest, forkJoin, zip, AsyncSubject, isObservable, Subject } from 'rxjs';
import { __classPrivateFieldGet, __classPrivateFieldSet } from 'tslib';
import { concatMapTo, map } from 'rxjs/operators';
import * as i1$1 from '@angular/platform-browser';

/**
 * An Error throw when a singleton module is loaded more than once.
 * This error should not be handled in the app because it indicates that a module that supposed to be included only once was included more than once.
 * Instead scenarios which would result in this error should be found and fixed during development.
 *
 * @example
 * ```ts
 *  throw new ModuleLoadError(((self as unknown) as Function).name);
 * ```
 */
class ModuleLoadError extends Error {
    /**
     * @param moduleName The name of the NgModule which could no be loaded.
     */
    constructor(moduleName) {
        super(`${moduleName} is already loaded. Make sure to only import it once directly or indirectly in AppModule`);
        this.moduleName = moduleName;
    }
}

/**
 * Extend this class by an NgModule to make the module singleton,
 * Causing it to throw a `ModuleLoadError` when loaded more than once.
 * The derived class must use the `Optional` and `SkipSelf` decorators
 * on it's constructor's first parameter that must be named `self`
 * and must have the type annotation of the derived class. see the example below
 *
 * @example
 * ```ts
 *  \@NgModule({
 *      ...
 *  })
 *  export class CoreModule extends SingletonModule {
 *      constructor(\@Optional() \@SkipSelf() protected self: CoreModule) {
 *          super(self);
 *      }
 *  }
 * ```
 */
class ASingletonModule {
    /**
     * @param self The same module class instance received from the DI system.
     */
    constructor(self) {
        if (self) {
            // eslint-disable-next-line @typescript-eslint/ban-types
            throw new ModuleLoadError(self.name);
        }
    }
}

/**
 * An enum that specifies the platforms where an Angular application can be run.
 * The enum values correspond to the values of the platform id tokens that the Angular DI system can resolve.
 */
const EApplicationPlatform = {
    browser: 'browser',
    server: 'server',
    browserWorkerApp: 'browserWorkerApp',
    browserWorkerUi: 'browserWorkerUi',
};

/**
 * An enum of the directive lifecycle hooks provided by Angular
 */
var ELifeCycleHook;
(function (ELifeCycleHook) {
    ELifeCycleHook["ngOnChanges"] = "ngOnChanges";
    ELifeCycleHook["ngOnInit"] = "ngOnInit";
    ELifeCycleHook["ngAfterViewInit"] = "ngAfterViewInit";
    ELifeCycleHook["ngAfterContentInit"] = "ngAfterContentInit";
    ELifeCycleHook["ngAfterViewChecked"] = "ngAfterViewChecked";
    ELifeCycleHook["ngAfterContentChecked"] = "ngAfterContentChecked";
    ELifeCycleHook["ngDoCheck"] = "ngDoCheck";
    ELifeCycleHook["ngOnDestroy"] = "ngOnDestroy";
})(ELifeCycleHook || (ELifeCycleHook = {}));

/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * @internal
 */
const AUTO_HOOKS_MARK = '__auto-wire-up-angular-hooks__';
/**
 * @internal
 */
const getParentProto = (target) => typeof target === 'function'
    ? Object.getPrototypeOf(target)?.prototype ?? null
    : null;
/**
 * @internal
 */
function gatherHookRecursively(target, hookName) {
    const hookFns = [];
    const targetHookFnDesc = Object.getOwnPropertyDescriptor(target.prototype, hookName);
    if (typeof targetHookFnDesc === 'object' &&
        typeof targetHookFnDesc.value === 'function') {
        hookFns.push({
            hook: targetHookFnDesc.value,
            proto: target.prototype,
        });
    }
    let parentProto = getParentProto(target);
    while (true) {
        if (parentProto === null) {
            break;
        }
        if (parentProto.constructor[Symbol.for(AUTO_HOOKS_MARK)]) {
            throw new Error(`
        Invalid usage of @AutoHooks decorator encountered!
        Only one class per prototype chain can be decorated by the @AutoHooks decorator.
        Class ${parentProto.constructor.name} is already decorated by @AutoHooks
        but appears in the prototype chain of another class decorated by it.
      `);
        }
        const parentHookFnDesc = Object.getOwnPropertyDescriptor(parentProto, hookName);
        if (typeof parentHookFnDesc === 'object' &&
            typeof parentHookFnDesc.value === 'function') {
            hookFns.push({
                hook: parentHookFnDesc.value,
                proto: parentProto,
            });
        }
        if (parentProto.constructor.hasOwnProperty(Symbol.for(AUTO_HOOKS_MARK))) {
            break;
        }
        parentProto = getParentProto(parentProto.constructor);
    }
    return hookFns.reverse();
}
/**
 * @internal
 */
function shouldAugmentPreV10Hooks(targetCtor, hookName, recognizedLifeCycleHookMethods) {
    const isLifecycleHookMethod = recognizedLifeCycleHookMethods.includes(hookName);
    return isLifecycleHookMethod && !!targetCtor['ɵcmp'];
}
/**
 * @internal
 */
function augmentPreV10Hooks(hookName, targetCtor, callableHooksWithOwningPrototypes) {
    const compFeatureName = hookName
        .replace('ng', '')
        .split('')
        .map((char, i) => (i === 0 ? char.toLowerCase() : char))
        .join('');
    targetCtor['ɵcmp'][compFeatureName] = function (...args) {
        callableHooksWithOwningPrototypes.forEach((hookWithOwningPrototype) => {
            const protoCtrIsMarkedAsFirst = hookWithOwningPrototype.proto.constructor.hasOwnProperty(Symbol.for('firstInProtoChain'));
            return hookWithOwningPrototype.hook.apply(protoCtrIsMarkedAsFirst ? this : hookWithOwningPrototype.proto, args);
        });
    };
}
/**
 * @internal
 */
function augmentHooksInV10Mode(hookName, target, callableHooksWithOwningPrototypes) {
    target[hookName] = function (...args) {
        callableHooksWithOwningPrototypes.forEach((hookWithOwningPrototype) => hookWithOwningPrototype.hook.apply(this, args));
    };
}
/**
 * A decorator which ensures that the lifecycle hooks of components and directives that use mixins are called properly.
 * The decorator applies automatic binding for the Angular specific lifecycle hook and the additionally supplied methods on classes  extending mixin functions by linking up the existing methods on the classes' prototype chains.
 * This ensures that both the components' own methods and any other method on the mixins' prototypes are called in the same order in which constructor calls would do. (Starting with the last mixin class and calling continuosly toward the actual class that extends the mixins)
 * @param additionalHooks An array of method names to be bound on top of the Angular lifecycle hooks
 * @remarks Nor the classes decorated with AutoHooks decorator neither the mixin or base classes applied to it are allowed to manually call the super version of the methods being bound.
 * That would result in unintended and multiply invocation of said methods.
 * The ngOnChanges hook is exempt from this behaviour when the decorator is used with an Angular version less than v10 as binding this lifecycle hooks results in a faulty behavior where the method does not receive the changes parameter object.
 * If a class's prototype chain contains real classes apart from the applied mixins those classes cannot use AutoHooks in tandem with the child class's decorator.
 * @example ```ts
 * \@Component({
 *   selector: 'my-comp',
 *   templateUrl: './my.component.html',
 *   styleUrls: ['./my.component.scss'],
 * })
 * \@AutoHooks()
 * export class MyComp extends SubscriptionHandlerMixin() implements OnInit { ... }
 * ```
 */
function AutoHooks(additionalHooks = []) {
    const recognizedLifeCycleHookMethods = Object.values(ELifeCycleHook);
    const hooksToWireUp = [...recognizedLifeCycleHookMethods, ...additionalHooks];
    return (target) => {
        if (typeof target !== 'function') {
            throw new TypeError(`
        AutoHooks decorator expected a class constructor function but got: ${target}!
        Make sure to only use AutoHooks as a class decorator.
      `);
        }
        for (const hookName of hooksToWireUp) {
            // ! OnChanges hook does not receive the changes argument when called as a feature. (prior to v10)
            // TODO: This might work and can be removed under v10.
            if (hookName === ELifeCycleHook.ngOnChanges) {
                continue;
            }
            const callableHooksWithOwningPrototypes = gatherHookRecursively(target, hookName);
            if (callableHooksWithOwningPrototypes.length === 0) {
                continue;
            }
            // ? We have to hook into Angular's component feature's private api to properly modify the lifecycle hooks
            // ? since the AOT generated code contains the _decorate function call after the component class definitions
            // ? Angular do not recognize the a decorate has modified the component's lifecycle hooks.
            if (shouldAugmentPreV10Hooks(target, hookName, recognizedLifeCycleHookMethods)) {
                augmentPreV10Hooks(hookName, target, callableHooksWithOwningPrototypes);
            }
            augmentHooksInV10Mode(hookName, target.prototype, callableHooksWithOwningPrototypes);
        }
        Object.defineProperty(target, Symbol.for(AUTO_HOOKS_MARK), {
            value: true,
            writable: false,
            configurable: false,
        });
        return target;
    };
}

/* eslint-disable @angular-eslint/directive-selector */
class FormControlNameAugmentationDirective extends FormControlName {
}
FormControlNameAugmentationDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: FormControlNameAugmentationDirective, deps: null, target: i0.ɵɵFactoryTarget.Directive });
FormControlNameAugmentationDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.0", type: FormControlNameAugmentationDirective, selector: "[formControlName]", exportAs: ["formControlName"], usesInheritance: true, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: FormControlNameAugmentationDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[formControlName]',
                    exportAs: 'formControlName',
                }]
        }] });

/* eslint-disable @angular-eslint/no-output-rename */
/**
 * Augments the {@link NgComponentOutlet} directive to allow for binding of inputs and outputs.
 *
 * @example
 * In your lazy loaded component define the input and outputs you wish to bind to.
 *
 * ```ts
 * \@Component({
 *  selector: 'lazy-loaded-component',
 *  template: `...`
 * })
 * export class LazyLoadedComponent {
 *  \@Input() public input1: string;
 *
 * \@Output() public output1 = new EventEmitter<string>();
 * }
 *
 * ```
 *
 * In the template where you wish to use the component, use the directive to bind the inputs and outputs.
 *
 * ```html
 * <ng-container *ngComponentOutlet="lazyLoadedComp$ | async; inputs: { input1: 'test' }"></ng-container>
 * ```
 *
 * If you want to bind to the lazy loaded components outputs' as well, then you have to use the non-micro-syntax version of the directive, as the micro-syntax version does not support binding to outputs.
 *
 * ```html
 * <ng-container
 *  [ngComponentOutlet]="lazyLoadedComp$ | async"
 *  [ngComponentOutletInputs]="{ input1: 'test' }"
 *  [ngComponentOutletOutputs]="onComponentEvent($event)">
 * </ng-container>
 * ```
 *
 * Then in your component, you can handle the event like so:
 *
 * ```ts
 *
 * export class MyComponentThatUsesLazyLoadedComponent {
 *  public onComponentEvent(event: NgComponentOutletEvent): void {
 *    if (event.key === 'output1') {
 *      // do something with the received event data through event.event
 *    }
 *  }
 * }
 * ```
 */
class NgComponentOutletAugmentationDirective {
    get componentRef() {
        return this.ngComponentOutlet['_componentRef'];
    }
    constructor(viewContainerRef, ngComponentOutlet) {
        this.viewContainerRef = viewContainerRef;
        this.ngComponentOutlet = ngComponentOutlet;
        this.component = null;
        this.componentEvent = new EventEmitter();
        this.originalNgOnChanges = this.ngComponentOutlet.ngOnChanges.bind(this.ngComponentOutlet);
        this.ngComponentOutlet.ngOnChanges = this.augmentedNgOnChanges.bind(this);
    }
    augmentedNgOnChanges(changes) {
        this.originalNgOnChanges(changes);
        const compChange = changes['ngComponentOutlet'];
        if (compChange && compChange.currentValue !== compChange.previousValue) {
            this.hookUpOutputs();
        }
        this.hookUpInputs();
    }
    hookUpOutputs() {
        Object.entries(this.componentRef.instance)
            .filter(([, value]) => value instanceof EventEmitter)
            .forEach(([key, value]) => {
            value.subscribe((event) => {
                this.componentEvent.emit({ key, event });
            });
        });
    }
    hookUpInputs() {
        if (!this.inputs || typeof this.inputs !== 'object') {
            return;
        }
        if (this.inputs && this.componentRef) {
            for (const [key, value] of Object.entries(this.inputs)) {
                this.componentRef.setInput(key, value);
            }
        }
    }
}
NgComponentOutletAugmentationDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgComponentOutletAugmentationDirective, deps: [{ token: i0.ViewContainerRef }, { token: i1.NgComponentOutlet }], target: i0.ɵɵFactoryTarget.Directive });
NgComponentOutletAugmentationDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.0", type: NgComponentOutletAugmentationDirective, selector: "[ngComponentOutlet]", inputs: { component: ["ngComponentOutlet", "component"], injector: ["ngComponentOutletInjector", "injector"], content: ["ngComponentOutletContent", "content"], ngModule: ["ngComponentOutletNgModule", "ngModule"], inputs: ["ngComponentOutletInputs", "inputs"] }, outputs: { componentEvent: "ngComponentOutletOutputs" }, exportAs: ["ngComponentOutlet"], ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgComponentOutletAugmentationDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngComponentOutlet]',
                    exportAs: 'ngComponentOutlet',
                }]
        }], ctorParameters: function () { return [{ type: i0.ViewContainerRef }, { type: i1.NgComponentOutlet }]; }, propDecorators: { component: [{
                type: Input,
                args: ['ngComponentOutlet']
            }], injector: [{
                type: Input,
                args: ['ngComponentOutletInjector']
            }], content: [{
                type: Input,
                args: ['ngComponentOutletContent']
            }], ngModule: [{
                type: Input,
                args: ['ngComponentOutletNgModule']
            }], inputs: [{
                type: Input,
                args: ['ngComponentOutletInputs']
            }], componentEvent: [{
                type: Output,
                args: ['ngComponentOutletOutputs']
            }] } });

/* eslint-disable @angular-eslint/directive-selector */
/**
 * A utility directive that enhances Angular's *ngFor directive with extra functionality.
 * The directive is implicitly applied every time the original *ngFor is used and provides two additional template options for *ngFor.
 * You can supply both a no array and an empty array template to be rendered.
 * @example ```html
 * <p *ngFor="let item of items$ | async else loading empty blank">
 *   {{item}}
 * </p>
 * ```
 * @credit
 * Alexander Inkin - https://medium.com/@waterplea
 *
 * https://medium.com/angularwave/non-binary-ngif-cfdf7c474852
 */
class NgForAugmentationDirective {
    constructor(vcr) {
        this.vcr = vcr;
    }
    ngOnChanges() {
        this.ref?.destroy();
        if (!Array.isArray(this.ngForOf) && this.ngForElse instanceof TemplateRef) {
            this.ref = this.vcr.createEmbeddedView(this.ngForElse);
            return;
        }
        if (this.ngForOf?.length === 0 && this.ngForEmpty instanceof TemplateRef) {
            this.ref = this.vcr.createEmbeddedView(this.ngForEmpty);
        }
    }
}
NgForAugmentationDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgForAugmentationDirective, deps: [{ token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
NgForAugmentationDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.0", type: NgForAugmentationDirective, selector: "[ngFor][ngForOf][ngForEmpty],[ngFor][ngForOf][ngForElse]", inputs: { ngForOf: "ngForOf", ngForEmpty: "ngForEmpty", ngForElse: "ngForElse" }, usesOnChanges: true, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgForAugmentationDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngFor][ngForOf][ngForEmpty],[ngFor][ngForOf][ngForElse]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ViewContainerRef }]; }, propDecorators: { ngForOf: [{
                type: Input
            }], ngForEmpty: [{
                type: Input
            }], ngForElse: [{
                type: Input
            }] } });

const INITIALIZABLE_SERVICE = new InjectionToken('initializable service');

/**
 * @example
 * ```ts
 *   Component({
 *       selector: 'app-filters',
 *       templateUrl: './filters.component.html',
 *       styleUrls: ['./filters.component.scss'],
 *       viewProviders: [
 *           {
 *               provide: METHOD_INVOKER_PIPE_HOST,
 *               useExisting: forwardRef(() => FiltersComponent)
 *           }
 *       ]
 *   })
 *  ```
 */
const METHOD_INVOKER_PIPE_HOST = new InjectionToken('Method Invoker Host');

/* eslint-disable no-undef */
/**
 * An InjectionToken used to safely access window and workerGlobalScope in browser and worker contexts respectively.
 *
 * @throws TypeError: If used in the context of platformServer.
 */
const WINDOW = new InjectionToken('Window global scope token', {
    providedIn: 'root',
    factory: () => {
        const platformId = inject(PLATFORM_ID);
        return isPlatformBrowser(platformId) ? globalThis.window : null;
    },
});

/**
 * An InjectionToken used to safely access the navigator global object in the browser and worker contexts respectively.
 *
 * @throws TypeError: If used in an environment without window or navigator like global objects.
 */
const NAVIGATOR = new InjectionToken('NavigatorToken', {
    factory: () => {
        const platformId = inject(PLATFORM_ID);
        const window = inject(WINDOW);
        return isPlatformBrowser(platformId) && !!window
            ? window.navigator
            : null;
    },
});

const NG_SUBSCRIBE_EXCEPTION_BEHAVIOR = new InjectionToken('NgSubscribe directive exception behavior', {
    factory: () => NEVER,
});
const NG_SUBSCRIBE_MISSING_STREAM_BEHAVIOR = new InjectionToken('NgSubscribe directive missing stream behavior', {
    factory: () => EMPTY,
});

const TRACK_BY_ID = new InjectionToken('TRACK_BY_ID');

/**
 * A utility directive that enhances Angular's *ngFor directive with extra functionality.
 * The directive is implicitly applied every time the original *ngFor is used
 * and provides a trackBy function to it that uses the property name from the directive input or the TRACK_BY_ID injection token's value.
 * @example
 *
 * Implicit usage of the TRACK_BY_ID Injection token's value:
 * ```html
 * <p *ngFor="let item of items$ | async">
 *   {{item}}
 * </p>
 * ```
 *
 * Supplying a track id manually per *ngFor usage:
 * ```html
 * <p *ngFor="let item of items$ | async; trackId: 'name'">
 *   {{item}}
 * </p>
 * ```
 *
 * Overriding the TRACK_BY_ID Injection token's value per component:
 * ```ts
 * \@Component({
 *  selector: 'app-root',
 *  providers: [{provide: TRACK_BY_ID, useValue: 'name'}]
 * })
 * export class AppComponent { ... }
 * ```
 * No additional work needed in the HTML.
 * ```html
 * <p *ngFor="let item of items$ | async">
 *   {{item}}
 * </p>
 * ```
 *
 * @credit
 * Ankit kaushik - https://ankit-kaushik.medium.com/
 *
 * Author's Medium article about the Directive:
 * https://ankit-kaushik.medium.com/trackid-infixing-trackby-capabilities-to-ngfor-in-a-centralised-way-across-your-angular-f1286f703469
 */
class NgForTrackIdDirective {
    constructor(ngFor, trackId = 'id') {
        this.trackId = trackId;
        this.ngForTrackId = this.trackId;
        ngFor.ngForTrackBy || (ngFor.ngForTrackBy = (index, item) => (typeof item === 'object' &&
            Reflect.has(item, this.ngForTrackId) &&
            item[this.ngForTrackId]) ||
            index.toString());
    }
}
NgForTrackIdDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgForTrackIdDirective, deps: [{ token: i1.NgForOf, host: true }, { token: TRACK_BY_ID, optional: true }], target: i0.ɵɵFactoryTarget.Directive });
NgForTrackIdDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.0", type: NgForTrackIdDirective, selector: "[ngFor][ngForOf]", inputs: { ngForTrackId: "ngForTrackId" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgForTrackIdDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[ngFor][ngForOf]',
                }]
        }], ctorParameters: function () { return [{ type: i1.NgForOf, decorators: [{
                    type: Host
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [TRACK_BY_ID]
                }] }]; }, propDecorators: { ngForTrackId: [{
                type: Input
            }] } });

/* eslint-disable @angular-eslint/directive-selector */
/**
 * A utility directive that enhances Angular's *ngIf directive with extra functionality.
 * The directive is implicitly applied every time the original *ngIf is used and provides two additional template options for *ngIF.
 * You can supply both a loading and error template for *ngIf.
 * This can be particularly useful when you are working with async data
 * @example ```html
 * <p *ngIf="value$ | async as value else default or loading but error">
 *   {{value}}
 * </p>
 * ```
 * @credit
 * Alexander Inkin - https://medium.com/@waterplea
 *
 * https://medium.com/angularwave/non-binary-ngif-cfdf7c474852
 */
class NgIfAugmentedDirective {
    /**
     * @param directive The original ngIf directive instance on this host element
     * @param templateRef The template encapsulated by the directive.
     */
    constructor(directive, templateRef) {
        this.directive = directive;
        this.templateRef = templateRef;
        /**
         * Keeping track of the value
         */
        this.ngIf = false;
        /**
         * Keeping track of original template
         */
        this.ngIfThen = this.templateRef;
        /**
         * Keeping track of original "else" template
         */
        this.ngIfElse = null;
        /**
         * Template for loading state
         */
        this.ngIfOr = null;
        /**
         * Template for error state
         */
        this.ngIfBut = null;
    }
    /**
     * @ignore
     */
    ngOnChanges() {
        if (!this.ngIf && this.ngIfOr) {
            this.directive.ngIfElse = this.ngIfOr;
            return;
        }
        if (this.ngIf instanceof Error && this.ngIfBut) {
            this.directive.ngIfThen = this.ngIfBut;
            return;
        }
        if (this.directive.ngIfThen !== this.ngIfThen) {
            this.directive.ngIfThen = this.ngIfThen;
        }
        if (this.directive.ngIfElse !== this.ngIfElse) {
            this.directive.ngIfElse = this.ngIfElse;
        }
    }
}
NgIfAugmentedDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgIfAugmentedDirective, deps: [{ token: i1.NgIf, host: true }, { token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
NgIfAugmentedDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.0", type: NgIfAugmentedDirective, selector: "[ngIf][ngIfOr],[ngIf][ngIfBut]", inputs: { ngIf: "ngIf", ngIfThen: "ngIfThen", ngIfElse: "ngIfElse", ngIfOr: "ngIfOr", ngIfBut: "ngIfBut" }, usesOnChanges: true, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgIfAugmentedDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngIf][ngIfOr],[ngIf][ngIfBut]',
                }]
        }], ctorParameters: function () { return [{ type: i1.NgIf, decorators: [{
                    type: Host
                }] }, { type: i0.TemplateRef }]; }, propDecorators: { ngIf: [{
                type: Input
            }], ngIfThen: [{
                type: Input
            }], ngIfElse: [{
                type: Input
            }], ngIfOr: [{
                type: Input
            }], ngIfBut: [{
                type: Input
            }] } });

var _NgLetDirective_memoizedValue;
/**
 * The object available in the the *ngLet directive's template.
 */
class NgLetContext {
}
/**
 * A structural directive that allows the definition of template variables with ease.
 *
 * @example ```html
 * <!-- Simple case -->
 *  <div *ngLet="user.profileInfo.subscriptionInfo as userSubInfo"> ... </div>
 * <!-- With pipes -->
 *  <div *ngLet="userData$ | async as userData"> ... </div>
 * <!-- Object notation syntax -->
 * <div *ngLet="{ userData: userData$ | async, cartPrice: cartData.totalPrice} as userAndCartData">
 *    <p> {{ userAndCartData.userData.name }} </p>
 *    <p> {{ userAndCartData.cartPrice | currency }} </p>
 * </div>
 * <!-- Array notation syntax -->
 * <div *ngLet="[userData$ | async, cartData.totalPrice] as userAndCartData">
 *    <p> {{ userAndCartData[0].name }} </p>
 *    <p> {{ userAndCartData[1] | currency }} </p>
 * </div>
 * ```
 */
class NgLetDirective {
    /**
     * The value(s) that will be made available inside the *ngLet template.
     */
    set ngLet(input) {
        if (input === __classPrivateFieldGet(this, _NgLetDirective_memoizedValue, "f")) {
            return;
        }
        __classPrivateFieldSet(this, _NgLetDirective_memoizedValue, input, "f");
        this.context.ngLet = input;
        this.cdr.markForCheck();
    }
    constructor(vcr, cdr, templateRef) {
        this.vcr = vcr;
        this.cdr = cdr;
        this.templateRef = templateRef;
        /**
         * @internal
         */
        _NgLetDirective_memoizedValue.set(this, void 0);
        this.context = new NgLetContext();
    }
    /**
     * @ignore
     */
    static ngTemplateContextGuard(_dir, ctx) {
        return true;
    }
    /**
     * @ignore
     */
    ngOnInit() {
        this.vcr.createEmbeddedView(this.templateRef, this.context);
    }
}
_NgLetDirective_memoizedValue = new WeakMap();
NgLetDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgLetDirective, deps: [{ token: i0.ViewContainerRef }, { token: i0.ChangeDetectorRef }, { token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
NgLetDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.0", type: NgLetDirective, selector: "[ngLet]", inputs: { ngLet: "ngLet" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgLetDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngLet]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ViewContainerRef }, { type: i0.ChangeDetectorRef }, { type: i0.TemplateRef }]; }, propDecorators: { ngLet: [{
                type: Input
            }] } });

/**
 * An Injectable service that helps to identify the platform where the application runs.
 */
class PlatformObserverService {
    /**
     * Gets whether the app is running in the browser
     */
    get isPlatformBrowser() {
        return isPlatformBrowser(this.platformID);
    }
    /**
     * Gets whether the app is running on the server
     */
    get isPlatformServer() {
        return isPlatformServer(this.platformID);
    }
    /**
     * Gets whether the app is running in the web worker
     */
    get isPlatformWorker() {
        return isPlatformWorkerUi(this.platformID);
    }
    /**
     * @param platformID The platform id of the platform where the application is running
     */
    constructor(platformID, window) {
        this.platformID = platformID;
        this.window = window;
    }
}
PlatformObserverService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: PlatformObserverService, deps: [{ token: PLATFORM_ID }, { token: WINDOW }], target: i0.ɵɵFactoryTarget.Injectable });
PlatformObserverService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: PlatformObserverService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: PlatformObserverService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }, { type: Window, decorators: [{
                    type: Inject,
                    args: [WINDOW]
                }] }]; } });

/**
 * @internal
 */
const LIB_SERVICES = [
    PlatformObserverService
];

/* eslint-disable @angular-eslint/directive-selector */
/**
 * A structural directive that allows the rendering on templates based on the platform the application is running on.
 * The typical use case of the directive is to enable the usage of different templates for different rendering modes, eg.: usae a different view when the application is ran in SSR.
 *
 * @example ```html
 * <app-splash-screen *ngRenderIn="'browser'"></app-splash-screen>
 *
 * <!-- With alternative template -->
 * <app-splash-screen *ngRenderIn="'browser' or ssrTpl"></app-splash-screen>
 *
 * <ng-template #ssrTpl>...</ng-template>
 * ```
 *
 * There are two utility versions of this directive
 * NgRenderInBrowser (*ngRenderInBrowser) and NgRenderInServer (*ngRenderServer)
 * that do exactly what their names suggest.
 */
class NgRenderInDirective {
    constructor(vcr, templateRef, platformObserver) {
        this.vcr = vcr;
        this.templateRef = templateRef;
        this.platformObserver = platformObserver;
    }
    ngOnInit() {
        if (this.platformObserver.platformID === this.platform) {
            this._embeddedView = this.vcr.createEmbeddedView(this.templateRef);
        }
        else if (this.alternativeTemplate) {
            this._embeddedView = this.vcr.createEmbeddedView(this.alternativeTemplate);
        }
    }
    ngOnDestroy() {
        if (!this._embeddedView.destroyed) {
            this._embeddedView.destroy();
        }
    }
}
NgRenderInDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgRenderInDirective, deps: [{ token: i0.ViewContainerRef }, { token: i0.TemplateRef }, { token: PlatformObserverService }], target: i0.ɵɵFactoryTarget.Directive });
NgRenderInDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.0", type: NgRenderInDirective, selector: "[ngRenderIn]", inputs: { platform: ["ngRenderIn", "platform"], alternativeTemplate: ["ngRenderInOr", "alternativeTemplate"] }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgRenderInDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngRenderIn]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ViewContainerRef }, { type: i0.TemplateRef }, { type: PlatformObserverService }]; }, propDecorators: { platform: [{
                type: Input,
                args: ['ngRenderIn']
            }], alternativeTemplate: [{
                type: Input,
                args: ['ngRenderInOr']
            }] } });
/**
 * A structural directive that only renders it's template if the application is ran in the browser.
 *
 * @example ```html
 * <app-splash-screen *ngRenderInBrowser></app-splash-screen>
 *
 * <!-- With alternative template -->
 * <app-splash-screen *ngRenderInBrowser="or ssrTpl"></app-splash-screen>
 *
 * <ng-template #ssrTpl>...</ng-template>
 * ```
 */
class NgRenderInBrowserDirective extends NgRenderInDirective {
    constructor() {
        super(...arguments);
        this.platform = EApplicationPlatform.browser;
    }
}
NgRenderInBrowserDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgRenderInBrowserDirective, deps: null, target: i0.ɵɵFactoryTarget.Directive });
NgRenderInBrowserDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.0", type: NgRenderInBrowserDirective, selector: "[ngRenderInBrowser]", inputs: { alternativeTemplate: ["ngRenderInBrowserOr", "alternativeTemplate"] }, usesInheritance: true, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgRenderInBrowserDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngRenderInBrowser]',
                }]
        }], propDecorators: { alternativeTemplate: [{
                type: Input,
                args: ['ngRenderInBrowserOr']
            }] } });
/**
 * A structural directive that only renders it's template if the application is ran in the server environment (SSR).
 *
 * @example ```html
 * <app-splash-screen *ngRenderInServer></app-splash-screen>
 *
 * <!-- With alternative template -->
 * <app-splash-screen *ngRenderInServer="or browserTpl"></app-splash-screen>
 *
 * <ng-template #browserTpl>...</ng-template>
 * ```
 */
class NgRenderInServerDirective extends NgRenderInDirective {
    constructor() {
        super(...arguments);
        this.platform = EApplicationPlatform.server;
    }
}
NgRenderInServerDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgRenderInServerDirective, deps: null, target: i0.ɵɵFactoryTarget.Directive });
NgRenderInServerDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.0", type: NgRenderInServerDirective, selector: "[ngRenderInServer]", inputs: { alternativeTemplate: ["ngRenderInServerOr", "alternativeTemplate"] }, usesInheritance: true, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgRenderInServerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngRenderInServer]',
                }]
        }], propDecorators: { alternativeTemplate: [{
                type: Input,
                args: ['ngRenderInServerOr']
            }] } });

/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * Egy segédfüggvény, mely eldönti a kapott értékről, hogy az képes-e async értékeket előállítani.
 * A függvény azt vizsgála meg, hogy az érték RXJS observable vagy natív Promise osztályok valamely példánya.
 *
 * @param value Az érték, melyről döntést kell hozni.
 */
function isAsyncGenerator(value) {
    return value instanceof Observable || value instanceof Promise;
}

function observify(value) {
    return isAsyncGenerator(value) ? from(value) : of(value);
}

/**
 * An RXJS operator function that runs the supplied callback function outside Angular's zone thus bypassing change detection.
 */
function outsideZone(zone) {
    return function (source) {
        return new Observable((observer) => {
            let sub;
            zone.runOutsideAngular(() => {
                sub = source.subscribe(observer);
            });
            return sub;
        });
    };
}

/* eslint-disable @angular-eslint/directive-selector */
/**
 * The object available in the the *ngSubscribe directive's template.
 */
class NgSubscribeContext {
    constructor() {
        /**
         * Is the bound Observable closed or Promise resolved
         */
        this.completed = false;
    }
}
/**
 * Az NgSubscribe direktíva által használt error template kontextus objektuma.
 * Ez az objektum tartja számon a a direktíva inputjában történt hibát
 */
class NgSubscribeErrorContext {
}
/**
 * @internal
 */
const combinerMap = {
    combineLatest,
    forkJoin,
    zip,
};
/**
* A structural directive that allows the definition of template variables from async sources with ease. This directive does essentially the same as \*ngLet="use$ | async as user" without having to use the `async` pipe explicitly.

* ```html
* <!-- Simple case -->
* <div *ngSubscribe="subscriptionInfo.paymentDueAt$ as paymentDueAt">...</div>
*
* <!-- Object notation syntax -->
* <div
*  \*ngSubscribe="{
*    userData: userData$,
*    paymentDueAt: subscriptionInfo.paymentDueAt$
*  } as userAndSubscriptionData">
*   <p>{{ userAndSubscriptionData.userData.name }}</p>
*   <p>{{ userAndSubscriptionData.paymentDueAt | date }}</p>
* </div>
*
* <!-- Array notation syntax -->
* <div
*  \*ngSubscribe="[
*    userData$,
*    subscriptionInfo.paymentDueAt$
*  ] as userAndSubscriptionData">
*   <p>{{ userAndSubscriptionData[0].name }}</p>
*   <p>{{ userAndSubscriptionData[1] | date }}</p>
* </div>
* ```
*
* The directive utilizes the Angular language service's capabilities and gives you full type checking in it's template.
*/
class NgSubscribeDirective {
    set ngSubscribe(input) {
        if (this._observable === input) {
            return;
        }
        if (!input) {
            this._observable = this.getMissingStreamBehavior;
        }
        this.showBefore();
        const source$ = Array.isArray(input) || this.isObservableMap(input)
            ? this.handleStreamMerge(input)
            : observify(input);
        this._observable = this._init.pipe(concatMapTo(source$));
        this._subscription && this._subscription.unsubscribe();
        this._subscription = this.subscribeToObservable(this._observable);
    }
    set errorTpl(ref) {
        this._errorRef = ref;
    }
    set beforeTpl(ref) {
        this._beforeRef = ref;
    }
    set afterTpl(ref) {
        this._afterRef = ref;
    }
    set customExceptionBehavior(behavior) {
        this._customExceptionBehavior = behavior;
    }
    set customMissingStreamBehavior(behavior) {
        this._customMissingStreamBehavior =
            typeof behavior === 'function' ? behavior() : behavior;
    }
    get getMissingStreamBehavior() {
        return (this._customMissingStreamBehavior ??
            (typeof this.missingStreamBehavior === 'function'
                ? this.missingStreamBehavior()
                : this.missingStreamBehavior));
    }
    constructor(vcr, cdr, tpl, missingStreamBehavior, exceptionBehavior) {
        this.vcr = vcr;
        this.cdr = cdr;
        this.tpl = tpl;
        this.missingStreamBehavior = missingStreamBehavior;
        this.exceptionBehavior = exceptionBehavior;
        /**
         * Specify the change detection strategy used by the directive when a new async emission happens.
         * Available options are the methods of the `ChangeDetectorRef` responsible for facilitating change detection.
         * Defaults to `markForCheck`
         */
        this.strategy = 'markForCheck';
        /**
         * Specify the observable combination strategy used by the directive.
         * Under the hood the directive converts all async values to observables so the strategy applies to all inputs supplied to the directive regardless of the input format used.
         * Available options are RXJS's `combineLatest`, `forkJoin`, `zip` or a custom function that takes an array of observable inputs and returns a single observable stream.
         * Defaults to `combineLatest`
         */
        this.combineWith = 'combineLatest';
        this._context = new NgSubscribeContext();
        this._errorContext = new NgSubscribeErrorContext();
        this._init = new AsyncSubject();
    }
    /**
     * @ignore
     */
    static ngTemplateContextGuard(_dir, ctx) {
        return true;
    }
    /**
     * @ignore
     */
    ngOnInit() {
        this.showBefore();
        this._init.next();
        this._init.complete();
        this.vcr.createEmbeddedView(this.tpl, this._context);
    }
    /**
     * @ignore
     */
    ngOnDestroy() {
        this._subscription && this._subscription.unsubscribe();
    }
    handleStreamMerge(input) {
        const mergedObservables = this.mergeObservables(input);
        const combiner = typeof this.combineWith === 'function'
            ? this.combineWith
            : combinerMap[this.combineWith];
        let combinedStreams;
        try {
            combinedStreams = combiner(Object.values(mergedObservables));
        }
        catch (error) {
            const exceptionBehavior = this._customExceptionBehavior ?? this.exceptionBehavior;
            const replacementStream = (typeof exceptionBehavior === 'function'
                ? exceptionBehavior(error)
                : exceptionBehavior);
            return (isObservable(replacementStream)
                ? replacementStream
                : this.getMissingStreamBehavior);
        }
        return combinedStreams.pipe(map((merged) => {
            if (Array.isArray(input)) {
                return merged;
            }
            else {
                const observableMapKeys = Object.keys(input);
                return Object.values(merged).reduce((acc, curr, index) => ({
                    ...acc,
                    [observableMapKeys[index]]: curr,
                }), {});
            }
        }));
    }
    subscribeToObservable(input) {
        return input.subscribe({
            next: (value) => {
                this._context.$implicit = value;
                this._context.ngSubscribe = value;
                this.cdr[this.strategy]();
            },
            error: (err) => {
                if (this._errorRef instanceof TemplateRef) {
                    this._errorContext.$implicit = err;
                    this.vcr.clear();
                    this.vcr.createEmbeddedView(this._errorRef, this._errorContext);
                }
                else {
                    this._context.error = err;
                }
                this.cdr[this.strategy]();
            },
            complete: () => {
                this._context.completed = true;
                if (this._afterRef instanceof TemplateRef) {
                    this.vcr.clear();
                    this.vcr.createEmbeddedView(this._afterRef, this._context);
                }
                this.cdr[this.strategy]();
            },
        });
    }
    mergeObservables(input) {
        return Array.isArray(input)
            ? input.reduce((acc, curr, index) => ({ ...acc, [index]: curr }), {})
            : input;
    }
    isObservableMap(input) {
        return Object.values(input).every((val) => isObservable(val));
    }
    showBefore() {
        if (this._beforeRef instanceof TemplateRef) {
            this.vcr.clear();
            this.vcr.createEmbeddedView(this._beforeRef);
        }
    }
}
NgSubscribeDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgSubscribeDirective, deps: [{ token: i0.ViewContainerRef }, { token: i0.ChangeDetectorRef }, { token: i0.TemplateRef }, { token: NG_SUBSCRIBE_MISSING_STREAM_BEHAVIOR }, { token: NG_SUBSCRIBE_EXCEPTION_BEHAVIOR }], target: i0.ɵɵFactoryTarget.Directive });
NgSubscribeDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.0", type: NgSubscribeDirective, selector: "[ngSubscribe]", inputs: { strategy: ["ngSubscribeWithStrategy", "strategy"], combineWith: ["ngSubscribeCombineWith", "combineWith"], ngSubscribe: "ngSubscribe", errorTpl: ["ngSubscribeError", "errorTpl"], beforeTpl: ["ngSubscribeBefore", "beforeTpl"], afterTpl: ["ngSubscribeAfter", "afterTpl"], customExceptionBehavior: ["ngSubscribeExceptionBehavior", "customExceptionBehavior"], customMissingStreamBehavior: ["ngSubscribeMissingStreamBehavior", "customMissingStreamBehavior"] }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: NgSubscribeDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngSubscribe]',
                }]
        }], ctorParameters: function () { return [{ type: i0.ViewContainerRef }, { type: i0.ChangeDetectorRef }, { type: i0.TemplateRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [NG_SUBSCRIBE_MISSING_STREAM_BEHAVIOR]
                }] }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [NG_SUBSCRIBE_EXCEPTION_BEHAVIOR]
                }] }]; }, propDecorators: { strategy: [{
                type: Input,
                args: ['ngSubscribeWithStrategy']
            }], combineWith: [{
                type: Input,
                args: ['ngSubscribeCombineWith']
            }], ngSubscribe: [{
                type: Input
            }], errorTpl: [{
                type: Input,
                args: ['ngSubscribeError']
            }], beforeTpl: [{
                type: Input,
                args: ['ngSubscribeBefore']
            }], afterTpl: [{
                type: Input,
                args: ['ngSubscribeAfter']
            }], customExceptionBehavior: [{
                type: Input,
                args: ['ngSubscribeExceptionBehavior']
            }], customMissingStreamBehavior: [{
                type: Input,
                args: ['ngSubscribeMissingStreamBehavior']
            }] } });

class TypedNgTemplateDirective {
    // the directive gets the template from Angular
    constructor(contentTemplate) {
        this.contentTemplate = contentTemplate;
    }
    // this magic is how we tell Angular the context type for this directive, which then propagates down to the type of the template
    static ngTemplateContextGuard(_dir, ctx) {
        return true;
    }
}
TypedNgTemplateDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: TypedNgTemplateDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
TypedNgTemplateDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.0", type: TypedNgTemplateDirective, selector: "[typedNgTemplate]", inputs: { typeToken: ["typedNgTemplate", "typeToken"] }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: TypedNgTemplateDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[typedNgTemplate]',
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }]; }, propDecorators: { typeToken: [{
                type: Input,
                args: ['typedNgTemplate']
            }] } });

/**
 * @internal
 */
const LIB_DIRECTIVES = [
    FormControlNameAugmentationDirective,
    NgComponentOutletAugmentationDirective,
    NgLetDirective,
    NgSubscribeDirective,
    NgForAugmentationDirective,
    NgForTrackIdDirective,
    NgIfAugmentedDirective,
    NgRenderInDirective,
    NgRenderInBrowserDirective,
    NgRenderInServerDirective,
    TypedNgTemplateDirective,
];

const injectorSym = Symbol('__MixinDependencyResolverModule:InjectorSym__');
/**
 * An eagerly loaded and globally available NgModule that's purpose is to act as a mediator between mixin classes and the Angular DI system.
 * If a mixin class requires dependencies from the Angular Di system it can request it through this Module class using
 * it's static property injector, which is an instance of the app's root injector.
 * If a mixin requires context or template specific dependencies than this module isn't a valid solution as it's injector
 * is the global injector and thus has no notion of the context and template specific dependencies.
 */
class MixinDependencyResolverModule {
    static get injector() {
        return MixinDependencyResolverModule[injectorSym];
    }
    constructor(injector) {
        MixinDependencyResolverModule[injectorSym] = injector;
    }
}
MixinDependencyResolverModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: MixinDependencyResolverModule, deps: [{ token: i0.Injector }], target: i0.ɵɵFactoryTarget.NgModule });
MixinDependencyResolverModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.0", ngImport: i0, type: MixinDependencyResolverModule });
MixinDependencyResolverModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: MixinDependencyResolverModule });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: MixinDependencyResolverModule, decorators: [{
            type: NgModule,
            args: [{}]
        }], ctorParameters: function () { return [{ type: i0.Injector }]; } });

// TODO: Add content arg to transform so that this can be set more easily and explicitly than with the method invoker pipe host token
/**
 * A meta pipe that aims to replace most or all other pipes in your application.
 * This pipe take a function and optionally it's arguments as parameter(s) an executes it.
 * A context object can be supply to the pipe through Angular's DI system
 * in turn enabling the usage and reference of the this parameter of the component or directive that defined the function.
 *
 * @example
 *
 * Without context
 *```html
 * <p> {{ getRelativeDateTime | invoke: orderDate }} </p>
 *```
 *
 * With context
 *```ts
 * \@component({
 *  ...
 *  providers: [
 *    {
 *      provide: METHOD_INVOKER_PIPE_HOST,
 *      useExisting: MyComponent
 *    }
 *  ]
 * })
 * export class MyComponent {
 *  ...
 *
 *  public title = 'My App';
 *
 *  public componentMethodThatUsesThis(): string {
 *    return this.title;
 *  }
 * }
 *```
 *```html
 * <p> {{ componentMethodThatUsesThis | invoke }} </p>
 *```
 */
class MethodInvokerPipe {
    constructor(host) {
        this.host = host;
    }
    transform(value, method, ...restArgs) {
        if (typeof method !== 'function') {
            throw new Error(`MethodInvoker Pipe expected a function but got: ${method}`);
        }
        return method.call(this.host, value, ...(restArgs ?? []));
    }
}
MethodInvokerPipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: MethodInvokerPipe, deps: [{ token: METHOD_INVOKER_PIPE_HOST, optional: true }], target: i0.ɵɵFactoryTarget.Pipe });
MethodInvokerPipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "15.2.0", ngImport: i0, type: MethodInvokerPipe, name: "invoke" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: MethodInvokerPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'invoke',
                }]
        }], ctorParameters: function () { return [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [METHOD_INVOKER_PIPE_HOST]
                }] }]; } });

/**
 * A pipe that bypasses Angular's built-in sanitization for the following
 * security contexts:
 * - HTML
 * - Style
 * - Script
 * - URL
 * - Resource URL
 *
 * @remarks The pipe assumes HTML content to be sanitized by default.
 *
 * Usage:
 *
 * @example ```html
 * {{ value | safe }}
 * {{ value | safe:'html' }}
 * {{ value | safe:'style' }}
 * {{ value | safe:'script' }}
 * {{ value | safe:'url' }}
 * {{ value | safe:'resourceUrl' }}
 * ```
 */
class SafePipe {
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
        /**
         * @ignore
         */
        this.actionMap = {
            html: this.sanitizer.bypassSecurityTrustHtml,
            resourceUrl: this.sanitizer.bypassSecurityTrustResourceUrl,
            script: this.sanitizer.bypassSecurityTrustScript,
            style: this.sanitizer.bypassSecurityTrustStyle,
            url: this.sanitizer.bypassSecurityTrustUrl,
        };
    }
    /**
     * Use Angular's DOMSanitizer to bypass security for the specified content.
     *
     * @param content The content to be sanitized.
     * @param type The type of the content to be sanitized.
     * @returns A safe value of the specified type.
     */
    transform(content, type) {
        return this.actionMap[type ?? 'html'](content);
    }
}
SafePipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: SafePipe, deps: [{ token: i1$1.DomSanitizer }], target: i0.ɵɵFactoryTarget.Pipe });
SafePipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "15.2.0", ngImport: i0, type: SafePipe, name: "safe" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: SafePipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'safe',
                }]
        }], ctorParameters: function () { return [{ type: i1$1.DomSanitizer }]; } });

/**
 * @internal
 */
const LIB_PIPES = [MethodInvokerPipe, SafePipe];

class AdroitNgUtilsModule {
    static forRoot() {
        return {
            ngModule: AdroitNgUtilsModule,
            providers: [...LIB_PIPES],
        };
    }
    constructor(platformObserver) {
        AdroitNgUtilsModule.platformObserver = platformObserver;
    }
}
AdroitNgUtilsModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: AdroitNgUtilsModule, deps: [{ token: PlatformObserverService }], target: i0.ɵɵFactoryTarget.NgModule });
AdroitNgUtilsModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.0", ngImport: i0, type: AdroitNgUtilsModule, declarations: [FormControlNameAugmentationDirective, NgComponentOutletAugmentationDirective, NgLetDirective, NgSubscribeDirective, NgForAugmentationDirective, NgForTrackIdDirective, NgIfAugmentedDirective, NgRenderInDirective, NgRenderInBrowserDirective, NgRenderInServerDirective, TypedNgTemplateDirective, MethodInvokerPipe, SafePipe], imports: [CommonModule, MixinDependencyResolverModule, LayoutModule], exports: [FormControlNameAugmentationDirective, NgComponentOutletAugmentationDirective, NgLetDirective, NgSubscribeDirective, NgForAugmentationDirective, NgForTrackIdDirective, NgIfAugmentedDirective, NgRenderInDirective, NgRenderInBrowserDirective, NgRenderInServerDirective, TypedNgTemplateDirective, MethodInvokerPipe, SafePipe, LayoutModule] });
AdroitNgUtilsModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: AdroitNgUtilsModule, imports: [CommonModule, MixinDependencyResolverModule, LayoutModule, LayoutModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.0", ngImport: i0, type: AdroitNgUtilsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, MixinDependencyResolverModule, LayoutModule],
                    declarations: [...LIB_DIRECTIVES, ...LIB_PIPES],
                    exports: [...LIB_DIRECTIVES, ...LIB_PIPES, LayoutModule],
                }]
        }], ctorParameters: function () { return [{ type: PlatformObserverService }]; } });

/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * An Alias decorator for \@RunIn(EApplicationPlatform.Server)
 *
 * @example ```ts
 * \@Component({
 *     selector: 'app-root',
 *     templateUrl: './app.component.html',
 *     styleUrls: ['./app.component.scss']
 * })
 * export class AppComponent {
 *   \@RunInServer()
 *   public set setterThatSetsMetaTags(value) { ... }
 * }
 * ```
 */
function RunOnServer() {
    return RunOnPlatform(EApplicationPlatform.server);
}
/**
 * An Alias decorator for \@RunIn(EApplicationPlatform.Browser)
 *
 * @example ```ts
 * \@Component({
 *     selector: 'app-root',
 *     templateUrl: './app.component.html',
 *     styleUrls: ['./app.component.scss']
 * })
 * export class AppComponent {
 *   \@RunInBrowser()
 *   public set setterThatUsesWindow(value: string) { ... }
 * }
 * ```
 */
function RunInBrowser() {
    return RunOnPlatform(EApplicationPlatform.browser);
}
function RunInWorkerApp() {
    return RunOnPlatform(EApplicationPlatform.browserWorkerApp);
}
function RunInWorkerUI() {
    return RunOnPlatform(EApplicationPlatform.browserWorkerUi);
}
/**
 * A decorator that restricts the usage of methods and accessors.
 *
 * Methods and accessors decorated will only ran (when invoked
 * from the client code), if the application's active platform matches those supplied to the decorator.
 *
 * This makes it easy to optimize various execution scenarios
 * and rid the application of execution paths that would cause problems in certain environments.
 *
 * @param platforms An array of the platform IDs or a single platform ID where the method/accessor can be run.
 *
 * @example ```ts
 * \@Component({
 *     selector: 'app-root',
 *     templateUrl: './app.component.html',
 *     styleUrls: ['./app.component.scss']
 * })
 * export class AppComponent {
 *   \@RunInBrowser()
 *   public set setterThatUsesWindow(value: string) { ... }
 *
 *   \@RunIn(EApplicationPlatform.Browser)
 *   public methodThatUsesWindow(value: string) { ... }
 * }
 * ```
 */
function RunOnPlatform(platforms) {
    return (_target, propKey, descriptor) => {
        if ((typeof propKey !== 'string' && typeof propKey !== 'symbol') ||
            typeof descriptor !== 'object') {
            return descriptor;
        }
        const appliedOn = getApplicationTarget(descriptor);
        if (!appliedOn) {
            return;
        }
        const allowedPlatforms = Array.isArray(platforms) ? platforms : [platforms];
        descriptor[appliedOn] = ((...args) => {
            if (allowedPlatforms.includes(AdroitNgUtilsModule.platformObserver
                .platformID)) {
                descriptor[appliedOn](...args);
                return;
            }
            console.log(`Method or accessor: ${propKey.toString()} did not get invoked on platform: ${AdroitNgUtilsModule.platformObserver.platformID}`);
        });
        return descriptor;
    };
}
/**
 * @internal
 */
function getApplicationTarget(descriptor) {
    if (typeof descriptor.value === 'function') {
        return 'value';
    }
    if (typeof descriptor.get === 'function') {
        return 'get';
    }
    if (typeof descriptor.set === 'function') {
        return 'set';
    }
    return undefined;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * A utility function used by mixin functions to ensure the returned mixin class expression extends from either the received base class or an empty class if no base if provided.
 *
 * @param base The provided base class
 * @example
 *
 * export function MyMixin<T extends Constructor<any, unknown[]>>(
 *   base?: T
 * ) {
 *    // ? Mixin functions class expressions should extend this function call as below
 *   const MyMixinClass = class extends mixinBase(base) {
 *     // Mixin class implementation
 *   };
 *
 *   return mixinClass(MyMixinClass, base);
 * }
 */
function mixinBase(base) {
    return (base ?? class {
    });
}

function resolveMixinDependency(dep, config = {
    injector: MixinDependencyResolverModule.injector,
    flags: undefined,
    notFoundValue: undefined,
}) {
    const { injector, flags, notFoundValue } = config;
    if (typeof injector !== 'object' || typeof injector.get !== 'function') {
        const depName = typeof dep === 'function' ? dep.name : dep?.toString() ?? dep;
        throw new Error(`
      Could not resolve dependency: ${depName} for mixin.
      Either import AdroitNgUtilsModule into your application
      or supply a valid child injector in the configuration of ${resolveMixinDependency.name}.
    `);
    }
    return injector.get(dep, notFoundValue, flags);
}

/* eslint-disable @typescript-eslint/no-explicit-any */
// TODO: Lehetne e zone-on kivül futtatni a streameket?
/**
 * A Mixin function that provides functionality related to observing the browser viewport's size.
 * A class extending this mixin will have access to various observables named after the convention followed by numerous CSS frameworks: xs$, sm$, md$, lg$, xl$, etc...
 * These observable stream will always emit a boolean value indicating if the browser's viewport currently has a size fitting that breakpoint size criteria.
 * @example
 * ```ts
 * class MyComp extends MediaObserver() {
 *      constructor() {
 *           super();
 *       }
 *  }
 * ```
 *
 * ```html
 * <div *ngIf="xs$ | async; else desktopTpl"> ... </div>
 * ```
 */
function MediaObserverMixin(base) {
    const MediaObserver = class extends mixinBase(base) {
        constructor() {
            super(...arguments);
            this.breakpointObserver = resolveMixinDependency(BreakpointObserver);
            this.xs$ = this.observe('(max-width: 600px)');
            this.sm$ = this.observe('(max-width: 960px)');
            this.md$ = this.observe('(max-width: 1280px)');
            this.lg$ = this.observe('(max-width: 1600px)');
            this.xl$ = this.observe('(min-width: 1601px)');
            /**
             * An observable that indicates whether or not the window's viewport height is considered very low.
             */
            this.veryLowMediaHeight$ = this.observe('(max-height: 500px)');
        }
        observe(size) {
            return this.breakpointObserver
                .observe(size)
                .pipe(map((breakpointState) => breakpointState.matches));
        }
    };
    return MediaObserver;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * A Mixin function that provides functionality related to handling subscriptions.
 * Class extending this mixin will have access to the 'onDestroy' property that should be used in the various takeUntil operators throughout the streams defined by the concrete class.
 * The mixin's subscription handling logic depends on it's 'ngOnDestroy' method being called by Angular. If you have to define 'onDestroy' in your concrete class make sure to call super.ngOnDestroy as well!
 *
 * @example
 * ```ts
 * class MyComp extends SubscriptionHandlerMixin() {
 *      constructor() {
 *           super();
 *       }
 *  }
 * ```
 */
function SubscriptionHandlerMixin(base) {
    const SubscriptionHandler = class extends mixinBase(base) {
        constructor() {
            super(...arguments);
            /**
             * The Subscription handler's subject that signals when the component's or directive's onDestroy hook is called to enable automatic unsubscribe logic.
             */
            this._onDestroy$ = new Subject();
            this.onDestroy$ = this._onDestroy$.asObservable();
        }
        ngOnDestroy() {
            this._onDestroy$.next();
            this._onDestroy$.complete();
        }
    };
    return SubscriptionHandler;
}

/**
 * A Mixin function that provides functionality related to handling track-by functions for ngFor directives used in the component's template.
 * A class extending this mixin will have access to a general purpose `trackBy` function that can be referenced in the component's template for ngFor directives' `trackBy` inputs.
 * The `trackBy` function will try to use the received objects' ids as unique keys, however this behavior can be configured in the mixin's second parameter.
 *
 * @example
 * ```ts
 * class MyComp extends TrackByHandlerMixin() {
 *    constructor() {
 *      super();
 *    }
 * }
 *```
 *
 *```html
 *  <div *ngFor="pics of pictures; trackBy: trackBy">...</div>
 *```
 **/
function TrackByHandlerMixin(base, trackByKeyOrPropFn) {
    const TrackByHandler = class extends mixinBase(base) {
        trackBy(index, item) {
            let trackBy = typeof trackByKeyOrPropFn === 'function'
                ? trackByKeyOrPropFn(item)
                : trackByKeyOrPropFn;
            if (!trackBy) {
                trackBy = 'id';
            }
            return typeof item === 'object'
                ? item[trackBy]
                : item.toString() ?? index.toString();
        }
    };
    return TrackByHandler;
}

/**
 * ? Classes
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ASingletonModule, AdroitNgUtilsModule, AutoHooks, EApplicationPlatform, FormControlNameAugmentationDirective, METHOD_INVOKER_PIPE_HOST, MediaObserverMixin, MethodInvokerPipe, MixinDependencyResolverModule, ModuleLoadError, NgComponentOutletAugmentationDirective, NgForAugmentationDirective, NgForTrackIdDirective, NgIfAugmentedDirective, NgLetDirective, NgRenderInBrowserDirective, NgRenderInDirective, NgRenderInServerDirective, NgSubscribeDirective, PlatformObserverService, SafePipe, SubscriptionHandlerMixin, TrackByHandlerMixin, TypedNgTemplateDirective, mixinBase, resolveMixinDependency };
//# sourceMappingURL=adroit-group-ng-utils.mjs.map
