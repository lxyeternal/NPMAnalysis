export * from './lib/ngx-cdps-meter.module';
//# sourceMappingURL=index.d.ts.map