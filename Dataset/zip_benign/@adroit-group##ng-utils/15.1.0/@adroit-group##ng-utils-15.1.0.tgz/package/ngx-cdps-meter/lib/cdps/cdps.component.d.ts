import { OnInit } from '@angular/core';
import { DoCheck, ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class CdpsComponent implements DoCheck, OnInit {
    styles: Record<string, any>;
    cdCounter: ElementRef<HTMLDivElement>;
    private _counter;
    cdps: number;
    ngOnInit(): void;
    ngDoCheck(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdpsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CdpsComponent, "ad-cdps", never, { "styles": "styles"; }, {}, never, never, false, never>;
}
//# sourceMappingURL=cdps.component.d.ts.map