import * as i0 from "@angular/core";
import * as i1 from "./cdps/cdps.component";
import * as i2 from "@angular/common";
export declare class NgxCdpsMeterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxCdpsMeterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NgxCdpsMeterModule, [typeof i1.CdpsComponent], [typeof i2.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NgxCdpsMeterModule>;
}
//# sourceMappingURL=ngx-cdps-meter.module.d.ts.map