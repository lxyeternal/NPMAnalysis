"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.useSeeding = exports.tearDownDatabase = exports.useRefreshDatabase = exports.runSeeder = exports.factory = exports.define = exports.times = void 0;
const tslib_1 = require("tslib");
require("reflect-metadata");
const connection_1 = require("./connection");
const entity_factory_1 = require("./entity-factory");
const factory_util_1 = require("./utils/factory.util");
const file_util_1 = require("./utils/file.util");
// -------------------------------------------------------------------------
// Handy Exports
// -------------------------------------------------------------------------
tslib_1.__exportStar(require("./connection"), exports);
var helpers_1 = require("./helpers");
Object.defineProperty(exports, "times", { enumerable: true, get: function () { return helpers_1.times; } });
tslib_1.__exportStar(require("./importer"), exports);
global.seeder = {
    entityFactories: new Map(),
};
// -------------------------------------------------------------------------
// Facade functions
// -------------------------------------------------------------------------
const define = (entity, factoryFn) => {
    ;
    global.seeder.entityFactories.set((0, factory_util_1.getNameOfEntity)(entity), {
        entity,
        factory: factoryFn,
    });
};
exports.define = define;
const factory = (entity) => (context) => {
    const name = (0, factory_util_1.getNameOfEntity)(entity);
    const entityFactoryObject = global.seeder.entityFactories.get(name);
    return new entity_factory_1.EntityFactory(name, entity, entityFactoryObject === null || entityFactoryObject === void 0 ? void 0 : entityFactoryObject.factory, context);
};
exports.factory = factory;
const runSeeder = async (queryRunner, clazz) => {
    const seeder = new clazz();
    return seeder.run(exports.factory, queryRunner);
};
exports.runSeeder = runSeeder;
// -------------------------------------------------------------------------
// Facade functions for testing
// -------------------------------------------------------------------------
const useRefreshDatabase = async (options = {}) => {
    (0, connection_1.configureConnection)(options);
    const option = await (0, connection_1.getConnectionOptions)();
    const connection = await (0, connection_1.createConnection)(option);
    if (connection && connection.isInitialized) {
        await connection.dropDatabase();
        await connection.synchronize();
    }
    return connection;
};
exports.useRefreshDatabase = useRefreshDatabase;
const tearDownDatabase = async () => {
    const connection = await (0, connection_1.createConnection)();
    return connection && connection.isInitialized ? connection.close() : undefined;
};
exports.tearDownDatabase = tearDownDatabase;
const useSeeding = async (options = {}) => {
    var _a;
    (0, connection_1.configureConnection)(options);
    const option = await (0, connection_1.getConnectionOptions)();
    const factoryFiles = (0, file_util_1.loadFiles)((_a = option === null || option === void 0 ? void 0 : option.factories) !== null && _a !== void 0 ? _a : []);
    await (0, file_util_1.importFiles)(factoryFiles);
};
exports.useSeeding = useSeeding;

//# sourceMappingURL=typeorm-seeding.js.map
