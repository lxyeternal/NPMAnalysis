import { DataSource as TODataSource, DataSourceOptions } from 'typeorm';
interface SeedingOptions {
    cli?: {
        seedsDir?: string;
    };
    factories?: string[];
    seeds?: string[];
    seedsTableName?: string;
}
export declare type ConnectionOptions = DataSourceOptions & SeedingOptions;
export declare class DataSource extends TODataSource {
    options: ConnectionOptions;
}
export interface ConfigureOption {
    configName?: string;
    connection?: string;
    root?: string;
}
export declare const configureConnection: (option?: ConfigureOption) => void;
export declare const setConnectionOptions: (options: Partial<DataSourceOptions & SeedingOptions>) => void;
export declare const getConnectionOptions: () => Promise<ConnectionOptions>;
export declare const createConnection: (option?: DataSourceOptions) => Promise<DataSource>;
export {};
