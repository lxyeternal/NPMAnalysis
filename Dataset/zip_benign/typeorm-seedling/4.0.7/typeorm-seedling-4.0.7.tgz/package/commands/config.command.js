"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.configCommand = void 0;
const connection_1 = require("../connection");
const command_util_1 = require("../utils/command.util");
const common_1 = require("./common");
exports.configCommand = {
    command: 'config',
    describe: 'Show the TypeORM config',
    builder(args) {
        return (0, common_1.setupCommonOptions)(args);
    },
    async handler(args) {
        const log = await (0, command_util_1.initCommand)();
        try {
            (0, connection_1.configureConnection)({
                root: args.root,
                configName: args.datasource,
                connection: args.connection,
            });
            const option = await (0, connection_1.getConnectionOptions)();
            log(option);
        }
        catch (error) {
            (0, command_util_1.panic)(undefined, error, 'Could not find the orm config file', 111);
        }
        process.exit(0);
    }
};

//# sourceMappingURL=config.command.js.map
