"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupCommonOptions = exports.stageLoadOrmConfig = void 0;
const connection_1 = require("../connection");
const command_util_1 = require("../utils/command.util");
async function stageLoadOrmConfig(spinner, args) {
    const configureOption = {
        configName: args.datasource,
        connection: args.connection,
        root: args.root,
    };
    try {
        (0, connection_1.configureConnection)(configureOption);
        const option = await (0, connection_1.getConnectionOptions)();
        spinner.succeed('ORM Config loaded');
        return option;
    }
    catch (error) {
        (0, command_util_1.panic)(spinner, error, 'Could not load the config file!');
    }
}
exports.stageLoadOrmConfig = stageLoadOrmConfig;
function setupCommonOptions(args) {
    return args
        .option('connection', {
        alias: 'c',
        describe: 'Name of the typeorm connection.',
        type: 'string',
    })
        .option('datasource', {
        alias: 'd',
        default: '',
        describe: 'Name of the typeorm datasource file (json or js).',
        type: 'string',
    })
        .option('root', {
        alias: 'r',
        default: process.cwd(),
        describe: 'Path to your typeorm datasource file',
        type: 'string',
    });
}
exports.setupCommonOptions = setupCommonOptions;

//# sourceMappingURL=common.js.map
