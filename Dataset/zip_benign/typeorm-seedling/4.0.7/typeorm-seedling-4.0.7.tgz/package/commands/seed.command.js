"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.seedCommand = void 0;
const tslib_1 = require("tslib");
const chalk_1 = tslib_1.__importDefault(require("chalk"));
const ora_1 = tslib_1.__importDefault(require("ora"));
const connection_1 = require("../connection");
const importer_1 = require("../importer");
const typeorm_seeding_1 = require("../typeorm-seeding");
const command_util_1 = require("../utils/command.util");
const file_util_1 = require("../utils/file.util");
const log_to_seed_table_util_1 = require("../utils/log-to-seed-table.util");
const seed_table_util_1 = require("./../utils/seed-table.util");
const common_1 = require("./common");
async function stageImportFactories(spinner, connectionOptions) {
    var _a;
    spinner.start('Import Factories');
    const factoryFiles = (0, file_util_1.loadFiles)((_a = connectionOptions.factories) !== null && _a !== void 0 ? _a : []);
    try {
        await (0, file_util_1.importFiles)(factoryFiles);
        spinner.succeed('Factories are imported');
    }
    catch (error) {
        (0, command_util_1.panic)(spinner, error, 'Could not import factories!', 131);
    }
}
async function stageImportSeeds(spinner, connectionOptions) {
    var _a;
    spinner.start('Importing Seeders');
    let seedFiles = (0, file_util_1.loadFiles)((_a = connectionOptions.seeds) !== null && _a !== void 0 ? _a : []);
    seedFiles = seedFiles.sort((fileName1, fileName2) => fileName1.localeCompare(fileName2));
    let seedFileObjects = [];
    try {
        seedFileObjects = await Promise.all(seedFiles.map((seedFile) => (0, importer_1.importSeed)(seedFile)));
        spinner.succeed('Seeders are imported');
        return seedFileObjects;
    }
    catch (error) {
        (0, command_util_1.panic)(spinner, error, 'Could not import seeders!', 132);
    }
}
async function stageConnectToDatabase(spinner) {
    spinner.start('Connecting to the database');
    try {
        await (0, connection_1.createConnection)();
        spinner.succeed('Database connected');
    }
    catch (error) {
        (0, command_util_1.panic)(spinner, error, 'Database connection failed! Check your typeORM config file.', 133);
    }
}
async function stageCreateSeedsTable(spinner, args, connectionOptions, seedFileObjects) {
    spinner.start('Get Executed Seeders & filter seed classes');
    let seedsAlreadyRan = [];
    try {
        const connection = await (0, connection_1.createConnection)(connectionOptions);
        const queryRunner = connection.createQueryRunner();
        await (0, seed_table_util_1.createSeedTable)(queryRunner, connectionOptions);
        seedsAlreadyRan = await (0, seed_table_util_1.getExecutedSeeds)(connectionOptions);
        const seedRanNames = seedsAlreadyRan.map(sar => sar.className);
        const filteredSeedFileObjects = seedFileObjects
            .map(sfo => (sfo === null || sfo === void 0 ? void 0 : sfo.default) ? sfo.default : sfo)
            .filter(sfo => !seedRanNames.includes(sfo.name) || (args.seed && args.seed === sfo.name));
        spinner.succeed(`Finish Getting Seeders. ${seedsAlreadyRan.length} seeders already ran, ${seedFileObjects.length} seeders are ready to be executed`);
        return filteredSeedFileObjects;
    }
    catch (error) {
        (0, command_util_1.panic)(spinner, error, 'Error getting executed seeders', 134);
    }
}
async function stageExecuteSeeds(spinner, connectionOptions, seedFileObjects) {
    for (const seedFileObject of seedFileObjects) {
        spinner.start(`Executing ${seedFileObject.name} Seeder`);
        const connection = await (0, connection_1.createConnection)(connectionOptions);
        const queryRunner = connection.createQueryRunner();
        try {
            await queryRunner.startTransaction();
        }
        catch (error) {
            (0, command_util_1.panic)(spinner, error, 'Failed to begin transaction', 135);
        }
        try {
            await (0, typeorm_seeding_1.runSeeder)(queryRunner, seedFileObject);
            await (0, log_to_seed_table_util_1.logToSeedTable)(queryRunner, seedFileObject.name, connectionOptions);
            spinner.succeed(`Seeder ${seedFileObject.name} executed`);
        }
        catch (error) {
            (0, command_util_1.panic)(spinner, error, `Could not run the seed ${seedFileObject.name}!`, 136);
        }
        try {
            await queryRunner.commitTransaction();
        }
        catch (error) {
            await queryRunner.rollbackTransaction();
        }
        finally {
            await queryRunner.release();
        }
    }
}
exports.seedCommand = {
    command: 'seed',
    describe: 'Runs the seeds',
    builder(args) {
        return (0, common_1.setupCommonOptions)(args)
            .option('seed', {
            alias: 's',
            describe: 'Specific seed class to run.',
            type: 'string',
        });
    },
    async handler(args) {
        const log = await (0, command_util_1.initCommand)();
        const spinner = (0, ora_1.default)('Loading ormconfig').start();
        // Get TypeORM config file
        const connectionOptions = await (0, common_1.stageLoadOrmConfig)(spinner, args);
        // Find all factories and seed with help of the config
        await stageImportFactories(spinner, connectionOptions);
        // Find all seeds and load them
        let seedFileObjects = await stageImportSeeds(spinner, connectionOptions);
        // Get database connection and pass it to the seeder
        await stageConnectToDatabase(spinner);
        // Create Seed table if not exists
        seedFileObjects = await stageCreateSeedsTable(spinner, args, connectionOptions, seedFileObjects);
        // Run seeds
        await stageExecuteSeeds(spinner, connectionOptions, seedFileObjects);
        log('👍 ', chalk_1.default.gray.underline(`Finished Seeding`));
        process.exit(0);
    }
};

//# sourceMappingURL=seed.command.js.map
