import * as yargs from 'yargs';
import { ICommonArgs } from './common';
interface IArgs extends ICommonArgs {
    fileName: string;
}
export declare const createCommand: yargs.CommandModule<{}, IArgs>;
export {};
