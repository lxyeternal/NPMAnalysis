import * as yargs from 'yargs';
import { ICommonArgs } from './common';
interface IArgs extends ICommonArgs {
    seed?: string;
}
export declare const seedCommand: yargs.CommandModule<{}, IArgs>;
export {};
