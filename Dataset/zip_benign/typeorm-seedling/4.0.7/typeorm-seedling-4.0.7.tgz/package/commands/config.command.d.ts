import * as yargs from 'yargs';
import { ICommonArgs } from './common';
interface IArgs extends ICommonArgs {
}
export declare const configCommand: yargs.CommandModule<{}, IArgs>;
export {};
