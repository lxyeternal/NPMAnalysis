import { Ora } from 'ora';
import yargs from 'yargs';
import { ConnectionOptions } from '../connection';
export interface ICommonArgs {
    connection?: string;
    datasource: string;
    root: string;
}
export declare function stageLoadOrmConfig<T extends ICommonArgs>(spinner: Ora, args: yargs.ArgumentsCamelCase<T>): Promise<ConnectionOptions>;
export declare function setupCommonOptions(args: yargs.Argv): yargs.Argv<ICommonArgs>;
