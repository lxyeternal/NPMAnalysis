"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCommand = void 0;
const tslib_1 = require("tslib");
const fs = tslib_1.__importStar(require("fs"));
const fp_1 = require("lodash/fp");
const ora_1 = tslib_1.__importDefault(require("ora"));
const path_1 = tslib_1.__importDefault(require("path"));
const create_seeder_template_1 = tslib_1.__importDefault(require("../templates/create-seeder.template"));
const command_util_1 = require("../utils/command.util");
const common_1 = require("./common");
function stageCreateSeed(spinner, args, seedsDir) {
    spinner.start('Creating file');
    const now = Date.now();
    const fileName = `${now}-${(0, fp_1.kebabCase)(args.fileName)}`;
    const className = `${(0, fp_1.upperFirst)((0, fp_1.camelCase)(args.fileName))}${now}`;
    try {
        if (!fs.existsSync(seedsDir)) {
            fs.mkdirSync(seedsDir, { recursive: true });
        }
        fs.writeFileSync(path_1.default.join(seedsDir, fileName + '.ts'), (0, create_seeder_template_1.default)({ className }));
    }
    catch (error) {
        (0, command_util_1.panic)(spinner, error, 'Error creating file', 121);
    }
    spinner.succeed(`File: ${fileName}.ts created successfully`);
}
exports.createCommand = {
    command: 'create',
    describe: 'Creates a new seeder file',
    builder(args) {
        return (0, common_1.setupCommonOptions)(args)
            .option('fileName', {
            alias: 'f',
            default: '',
            describe: 'Name of the seeder file to be created',
            type: 'string',
        });
    },
    async handler(args) {
        var _a;
        await (0, command_util_1.initCommand)();
        const spinner = (0, ora_1.default)('Loading ormconfig').start();
        // Get TypeORM config file
        const option = await (0, common_1.stageLoadOrmConfig)(spinner, args);
        let seedsDir = 'src/database/seeds';
        if (!((_a = option === null || option === void 0 ? void 0 : option.cli) === null || _a === void 0 ? void 0 : _a.seedsDir)) {
            return (0, command_util_1.panic)(spinner, new Error('NO_CLI_SEEDS_DIR'), 'cli.seedsDir was not set in the ormconfig file', 122);
        }
        else {
            seedsDir = option.cli.seedsDir;
        }
        if (!args.fileName) {
            return (0, command_util_1.panic)(spinner, new Error('NO_FILE_NAME'), 'no filename entered, please use -f or --fileName to specify the filename', 123);
        }
        stageCreateSeed(spinner, args, seedsDir);
        process.exit(0);
    }
};

//# sourceMappingURL=create.command.js.map
