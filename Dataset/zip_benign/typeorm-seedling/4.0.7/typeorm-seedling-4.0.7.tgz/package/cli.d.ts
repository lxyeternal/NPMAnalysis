#!/usr/bin/env node
import 'reflect-metadata';
export declare function runCli(args: Array<string>): object;
