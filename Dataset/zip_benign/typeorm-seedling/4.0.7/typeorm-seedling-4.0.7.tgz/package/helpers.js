"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.times = void 0;
/**
 * Times repeats a function n times
 */
const times = async (n, iteratee) => {
    const results = [];
    for (let i = 0; i < n; i++) {
        const r = await iteratee(i);
        results.push(r);
    }
    return results;
};
exports.times = times;

//# sourceMappingURL=helpers.js.map
