#!/usr/bin/env node
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runCli = void 0;
const tslib_1 = require("tslib");
require("reflect-metadata");
const yargs_1 = tslib_1.__importDefault(require("yargs/yargs"));
const helpers_1 = require("yargs/helpers");
const seed_command_1 = require("./commands/seed.command");
const config_command_1 = require("./commands/config.command");
const create_command_1 = require("./commands/create.command");
function runCli(args) {
    return (0, yargs_1.default)(args)
        .usage('Usage: $0 <command> [options]')
        .command(config_command_1.configCommand)
        .command(seed_command_1.seedCommand)
        .command(create_command_1.createCommand)
        .recommendCommands()
        .demandCommand(1)
        .strictCommands()
        .help('h')
        .alias('h', 'help')
        .argv;
}
exports.runCli = runCli;
runCli((0, helpers_1.hideBin)(process.argv));

//# sourceMappingURL=cli.js.map
