"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getExecutedSeeds = exports.createSeedTable = void 0;
const typeorm_1 = require("typeorm");
const connection_1 = require("./../connection");
const query_quote_util_1 = require("./query-quote.util");
function getCompatableTimestampColumnType(options) {
    if (options.type === 'mssql') {
        return 'datetime';
    }
    if (options.type === 'postgres') {
        return 'timestampz';
    }
    return 'timestamp';
}
const createSeedTable = async (queryRunner, options) => {
    await queryRunner.createTable(new typeorm_1.Table({
        name: options.seedsTableName || 'typeorm_seeds',
        columns: [
            {
                name: 'className',
                type: 'varchar',
                isUnique: true,
                isNullable: true,
            },
            {
                name: 'ran_at',
                type: getCompatableTimestampColumnType(options),
                default: 'CURRENT_TIMESTAMP',
            },
        ],
    }), true);
};
exports.createSeedTable = createSeedTable;
const getExecutedSeeds = async (options) => {
    const connection = await (0, connection_1.createConnection)(options);
    const tableName = (0, query_quote_util_1.queryQuote)(options, options.seedsTableName || 'typeorm_seeds');
    return await connection.query(`select * from ${tableName}`);
};
exports.getExecutedSeeds = getExecutedSeeds;

//# sourceMappingURL=seed-table.util.js.map
