import { QueryRunner } from 'typeorm';
import { ConnectionOptions } from '../connection.js';
export declare const logToSeedTable: (queryRunner: QueryRunner, seederName: string, options: ConnectionOptions) => Promise<any>;
