import { QueryRunner } from 'typeorm';
import { ConnectionOptions } from './../connection';
export interface ISeedTable {
    className: string;
    ran_at: Date;
}
export declare const createSeedTable: (queryRunner: QueryRunner, options: ConnectionOptions) => Promise<void>;
export declare const getExecutedSeeds: (options: ConnectionOptions) => Promise<any>;
