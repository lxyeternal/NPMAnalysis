"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.queryQuoteString = exports.queryQuote = void 0;
function queryQuote(options, whatever) {
    const connectionType = options.type;
    if (connectionType === 'mssql') {
        return `[${whatever}]`;
    }
    return `\`${whatever}\``;
}
exports.queryQuote = queryQuote;
function queryQuoteString(options, whatever) {
    const connectionType = options.type;
    if (connectionType === 'mssql') {
        return `N'${whatever}'`;
    }
    return `'${whatever}'`;
}
exports.queryQuoteString = queryQuoteString;

//# sourceMappingURL=query-quote.util.js.map
