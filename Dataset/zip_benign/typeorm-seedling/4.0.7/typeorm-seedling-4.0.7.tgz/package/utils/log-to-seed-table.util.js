"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logToSeedTable = void 0;
const query_quote_util_1 = require("./query-quote.util");
const logToSeedTable = async (queryRunner, seederName, options) => {
    const tableName = (0, query_quote_util_1.queryQuote)(options, options.seedsTableName || 'typeorm_seeds');
    const seederNameQuoted = (0, query_quote_util_1.queryQuoteString)(options, seederName);
    return await queryRunner.query(`insert into ${tableName} (className) values (${seederNameQuoted})`);
};
exports.logToSeedTable = logToSeedTable;

//# sourceMappingURL=log-to-seed-table.util.js.map
