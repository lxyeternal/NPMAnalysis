import { ConnectionOptions } from '../connection';
export declare function queryQuote(options: ConnectionOptions, whatever: any): string;
export declare function queryQuoteString(options: ConnectionOptions, whatever: any): string;
