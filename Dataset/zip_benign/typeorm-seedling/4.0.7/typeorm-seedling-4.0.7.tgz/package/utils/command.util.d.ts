import { Ora } from 'ora';
export declare function initCommand(): Promise<typeof console.log>;
export declare function panic(spinner: Ora | undefined, error: unknown, message: string, errorCode?: number): never;
