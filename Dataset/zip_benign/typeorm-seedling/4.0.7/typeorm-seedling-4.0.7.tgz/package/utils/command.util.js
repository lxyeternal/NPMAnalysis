"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.panic = exports.initCommand = void 0;
const tslib_1 = require("tslib");
const chalk_1 = tslib_1.__importDefault(require("chalk"));
const path_1 = tslib_1.__importDefault(require("path"));
const read_pkg_1 = tslib_1.__importDefault(require("read-pkg"));
async function initCommand() {
    const log = console.log;
    const pkg = await (0, read_pkg_1.default)({ cwd: path_1.default.join(process.cwd(), 'node_modules/typeorm-seedling') });
    log('🌱  ' + chalk_1.default.bold(`TypeORM Seeding v${pkg.version}`));
    return log;
}
exports.initCommand = initCommand;
function panic(spinner, error, message, errorCode = 101) {
    spinner === null || spinner === void 0 ? void 0 : spinner.fail(message);
    console.error(error);
    return process.exit(errorCode);
}
exports.panic = panic;

//# sourceMappingURL=command.util.js.map
