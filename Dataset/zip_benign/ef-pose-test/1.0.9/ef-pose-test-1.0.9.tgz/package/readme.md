# ElitePose

Library for Elitefit API and Posenet tasks.

## Installation

```bash
npm install @elitefit/elitepose
```

## Usage

```javascript
import {ElitePose,EliteService} from '@elitefit/elitepose';

//instantiate the eliteservice. and pass in accesstoken for
//authorization
const getAccessToken = () => localStorage.getItem('token');
const eliteService = new EliteSevice({
    authToken: getAccessToken,
});

//Getting videoInfo
const videoData = await eliteService.getVideoInfo(videoId);

//instantiate the ElitePose. and pass in customization options
let elitepose = new ElitePose(eliteService, {
        postAfterInterval: true,
        pauseVideoIfUserIsAway: true,
        renderer: {
          defaultColor: '#ffffff',
          errorColor: '#ff00ff',
          successColor: '#00ff00',
          minPoseConfidence: 0.3,
        },
      });

//initialse the camera and pass in the element references and video details.
 await elitepose.initCamera(
          this.$refs.userVideo,
          this.$refs.canvas,
          this.$refs.referenceVideo,
          videoId,
          videoData.steps
        ); 

```