export default class ElitePoseBase {

    constructor(eliteService) {
        if (!eliteService) {
            throw new Error('Please pass in an instance of EliteService class');
        }
        this.eliteService = eliteService;
        this.instanceDisposed = false;
        this.detectedPoses = []; //To collect the detected poses
        this.posesKeypoints = []
        this.pose = null
        this.camera = null
        this.oldAccuracy = 0;
        this.oldCalories = 0;
        this.timeLapsed = 0;
        this.isVideoPlaying = false;
    }

    _setVideoPlaying(playing) {
        this.isVideoPlaying = playing;
    }

    async _setupListeners(instructorVideoEl) {
        if (!instructorVideoEl) {
            return;
        }
        instructorVideoEl.onloadedmetadata = (metadata) => {
        }

        instructorVideoEl.addEventListener("onStateChange", (event) => {
            switch (event.data) {
                case 1: this._setVideoPlaying(true);
                    return;
                case 0:
                case 2:
                case 3:
                case 5:
                    this._setVideoPlaying(false);
                    return;
            }
        });
    }

    async createNewSession(EFTech, videoId = null) {
        this.reset();
        if (this.sessionId) {
            await this.eliteService.updateSession(this.sessionId);
        }
        const resp = await this.eliteService.generateSession(this.videoId, EFTech);
        this.sessionId = resp.sessionId;
        this.sessionMessage = (resp.message) ? resp.message : "";
        console.log("session id ::: ", this.sessionId, this.sessionMessage);
    }

    getSessionId() {
        return this.sessionId;
    }

    getSessionMessage() {
        return this.sessionMessage;
    }

    reset() {
        this.detectedPoses = [];
    }

    _roundTime(time) {
        return parseFloat(time).toFixed(3);
    }

}
