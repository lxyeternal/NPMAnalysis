/**
 * VideoInfo
 * @typedef {Object} VideoInfo
 * @property {string} title - The title of the video
 * @property {string} data - The data associated with the video
 * @property {number} id - id of the video
 * @property {string} thumbnail - thubnail of the video
 * @property {string} videoURL - Video URL
 */

/**
 * EliteServiceOptions
 * @typedef {Object} EliteServiceOptions
 * @property {baseUrl} baseUrl - Base URL for the serivce to connect to.
 * @property {Function} authToken - Function to return the auth token.
 * @property {Function} refreshToken - Function to return the refresh token.
 */

/**
 *  EliteService class can be used to communicate with the elitefit apis.
 * @class EliteService
 * @classdesc EliteService class can be used to communicate with the elitefit apis.
 * @example
 * let elitePose = new EliteService({baseUrl:"http://yourserver.com"});
 */
export default class EliteService {

    /**
     * @param {EliteServiceOptions?} options - options to override.
     */
    constructor(options = {}) {
        const defaultOptions = {
            authToken: null,
            refreshToken: null,
            baseUrl: process.env.VUE_APP_API_URL
        };
        this.options = Object.assign(defaultOptions, options);
    }

    _getAuth() {
        if (this.options.authToken && typeof this.options.authToken == "function") {
            return 'Bearer ' + this.options.authToken();
        }
        return this.options.authToken ? 'Bearer ' + this.options.authToken : null;
    }

    async _refreshToken(data) {
        if (this.options.refreshToken && typeof this.options.refreshToken == "function") {
            let refreshToken = await this.options.refreshToken(data);
            return refreshToken;
        }
    }

    /**
     * Post the user poses to server.
     * @method EliteService#postPoses
     * @param {Array} poses - Poses to be sent to the server.
     * @example
     * await eliteService.postPoses(poses);
     *
     */
    async postPoses(poses) {
        poses.forEach(pose => JSON.stringify(pose));
        const data = await fetch(`${this.options.baseUrl}/posenet/upload-poses`, {
            method: "POST",
            body: JSON.stringify(poses),
            headers: {
                'Content-Type': 'application/json',
                'ef-client-type': 'web',
                'authorization': this._getAuth() //localStorage.getItem('token')
            }
        })
        if (data.status == 200)
            return data.json()
        else if (data.status == 401) {
            await this._refreshToken({"status": 401});
            setTimeout(async () => {
                const data = await fetch(`${this.options.baseUrl}/posenet/upload-poses`, {
                    method: "POST",
                    body: JSON.stringify(poses),
                    headers: {
                        'Content-Type': 'application/json',
                        'ef-client-type': 'web',
                        'authorization': this._getAuth() //localStorage.getItem('token')
                    }
                })
                if (data.status == 200)
                    return data.json();
            }, 1000);

        } else return Promise.reject(data);
    }

    /**
     * Post the user poses to server and get Score.
     * @method EliteService#uploadPosesAndGetScore
     * @param {Array} poses - Poses to be sent to the server.
     * @param {number} oldAccuracy
     * @param {number} oldCalories
     * @param {number} timeLapsed
     * @example
     * uploadPosesAndGetScore(poses, oldAccuracy, oldCalories, timeLapsed);
     *0
     */
    async uploadPosesAndGetScore(poses, oldAccuracy, oldCalories, timeLapsed) {
        poses.forEach(pose => JSON.stringify(pose));
        const data = await fetch(`${this.options.baseUrl}/posenet/upload-poses-get-score?oldAccuracy=${oldAccuracy}&oldCalories=${oldCalories}&timeLapsed=${timeLapsed}`, {
            method: "POST",
            body: JSON.stringify(poses),
            headers: {
                'Content-Type': 'application/json',
                'ef-client-type': 'web',
                'authorization': this._getAuth() //localStorage.getItem('token')
            }
        })

        if (data.status == 200)
            return await data.json();
        else if (data.status == 401) {
            await this._refreshToken({"status": 401});
            setTimeout(async () => {
                const data = await fetch(`${this.options.baseUrl}/posenet/upload-poses-get-score?oldAccuracy=${oldAccuracy}&oldCalories=${oldCalories}&timeLapsed=${timeLapsed}`, {
                    method: "POST",
                    body: JSON.stringify(poses),
                    headers: {
                        'Content-Type': 'application/json',
                        'ef-client-type': 'web',
                        'authorization': this._getAuth() //localStorage.getItem('token')
                    }
                })
                if (data.status == 200)
                    return await data.json();
            }, 1000);
        } else return Promise.reject(await data.json());
    }

    /**
     * Get the video info.
     * @method EliteService#getVideoInfo
     * @param {int} videoId - id of the video.
     * @example
     * await eliteService.getVideoInfo(1);
     *
     */
    async getVideoInfo(videoId) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/user-videos/${videoId}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            }
        });
        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }

    /**
     * Get the default video info.
     * @method EliteService#getDefaultVideo
     * @example
     * await eliteService.getDefaultVideo();
     *
     */
    async getDefaultVideo(id) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/user-videos/get/default/${id}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            }
        });
        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }

    /**
     * Get the previous video info.
     * @method EliteService#getPreviousVideo
     * @param {int} videoId - id of the video.
     * @example
     * await eliteService.getPreviousVideo(1);
     *
     */
    async getPreviousVideo(videoId) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/user-videos/control/previous/${videoId}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            }
        });
        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }

    /**
     * Get the next video info.
     * @method EliteService#getNextVideo
     * @param {int} videoId - id of the video.
     * @example
     * await eliteService.getNextVideo(1);
     *
     */
    async getNextVideo(videoId) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/user-videos/control/next/${videoId}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            }
        });
        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }

    /**
     * Get the next/prev video.
     * @method EliteService#getNextVideoAllTenants
     * @param {int} videoId - id of the video.
     * @param {string} dir - direction of search
     * @example
     * await eliteService.getNextVideoAllTenants(1, 'next');
     *
     */
    async getNextVideoAllTenants(videoId, dir) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/user-videos/landing/${dir}/${videoId}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            }
        });
        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }

    /**
     * Get All Videos to display.
     *
     * @method EliteService#getAllVideos
     * @example
     * await eliteService.getAllVideos();
     *
     */
    async getAllVideos() {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/user-videos`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            }
        });
        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }

    /**
     * Get All Videos to display.
     *
     * @method EliteService#getAllVideos
     * @example
     * await eliteService.getAllVideos();
     *
     */
    async getAllVideosOfTenant(id) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/user-videos/tenant/${id}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            }
        });
        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }

    /**
     * Get upcoming videos to display.
     *
     * @method EliteService#getUpcomingVideos
     * @example
     * await eliteService.getUpcomingVideos();
     *
     */
    async getUpcomingVideos() {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/user-videos/upcoming-videos/all`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            }
        });
        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }

    /**
     * Get Calories burnt for the time passed Videos to display .
     *
     * @method EliteService#getCalories
     *  @param {int} time - time elapsed
     * @param {int} videoId - id of the video.
     * @param {int} sessionId - Session Id.
     * @example
     * await eliteService.getCalories({id:1, time:24});
     * @returns {Object}
     *
     */
    async getCalories(time, videoId, sessionId) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/session/calorie-burnt?videoId=${videoId}&sessionId=${sessionId}&time=${time}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            }
        });
        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }

    /**
     * Get Calories burnt for the time passed Videos to display .
     *
     * @method EliteService#getCalories
     * @param startTime
     * @param endTime
     * @param {int} sessionId - Session Id.
     * @param accuracy
     * @param calories
     * @param validTotalTime
     * @example
     * await eliteService.getCalories({id:1, time:24});
     * @returns {Object}
     *
     */
    async getCaloriesAndScore(startTime, endTime, sessionId, accuracy, calories, validTotalTime) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/session/get-results?sessionId=${sessionId}&startTime=${startTime}&endTime=${endTime}&oldAccuracy=${accuracy}&oldCalories=${calories}&timeLapsed=${validTotalTime}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            }
        });
        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }

    /**
     * Get the historical workout summary of the user.
     *
     * @method EliteService#getWorkoutSummary
     * @example
     * await eliteService.getWorkoutSummary();
     *
     *
     */
    async getWorkoutSummary() {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/session/workout-summary`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            }
        });
        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }

    /**
     * Get the historical workout data of the user.
     *
     * @method EliteService#getWorkoutData
     * @example
     * await eliteService.getWorkoutData();
     *
     *
     */
    async getWorkoutData() {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/user-detail/workouts`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            }
        });
        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }

    /**
     * Get the stored frame count of the user for the current workout.
     *
     * @method EliteService#loadFramesCount
     * @param {string} sessionId - session id of the workout.
     * @example
     * await eliteService.loadFramesCount(sessionId);
     *
     *
     */
    async loadFramesCount(sessionId) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/session/get-frames-count/${sessionId}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            }
        });
        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }

     /**
     * Get the accuracy score for session.
     *
     * @method EliteService#loadFeedback
     * @param {string} sessionId - Session Id
     * @example
     * await eliteService.getAccuracy("fetuywuewiu-whewhj-2askaklsd");
     *
     *
     */
    async getAccuracy(workoutData) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/session/score/${workoutData.sessionId}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            },
            method: 'POST',
            body: JSON.stringify(
                workoutData
            )
        });

        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }


    /**
     * Set the user feedback for the session.
     *
     * @method EliteService#sendFeedback
     * @param {string} sessionId - Session Id
     * @param {number} feedback - Feedback in the range 0-5
     * @example
     * await eliteService.sendFeedback("fetuywuewiu-whewhj-2askaklsd",5);
     *
     *
     */
    async sendFeedback(sessionId, feedback, feedbackText) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/session/user-rating/${sessionId}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            },
            method: 'POST',
            body: JSON.stringify({
                feedback,
                feedbackText
            })
        });

        if (data.status == 200)
            return true;
        return Promise.reject(data);
    }

    /**
     * Generate a new session
     *
     * @method EliteService#generateSession
     * @param videoId - Video Id
     * @example
     * await eliteService.generateSession(4);
     *
     *
     */
    async generateSession(videoId) {
        const authorization = this._getAuth();

        const data = await fetch(`${this.options.baseUrl}/session/create-session`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            },
            body: JSON.stringify({videoId}),
            method: 'POST',
        });

        if (data.status == 200)
            return data.json();
        else if (data.status == 401) {
            await this._refreshToken({"status": 401});
            const authorization = this._getAuth();

            const data = await fetch(`${this.options.baseUrl}/session/create-session`, {
                headers: {
                    'content-type': 'application/json',
                    'ef-client-type': 'web',
                    authorization
                },
                body: JSON.stringify({videoId}),
                method: 'POST',
            });
            if (data.status == 200)
                return data.json();
        }
        else if (data.status == 403) {
            return data.json();
        }
        else
            return Promise.reject(data);
    }

    /**
     * Update video view count for the video
     *
     * @method EliteService#updateVideoViews
     * @param {string} videoId - Video Id
     * @example
     * await eliteService.updateVideoViews(1);
     *
     *
     */
    async updateVideoViews(videoId) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/user-videos/views/${videoId}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            },
            method: 'POST',
        });

        if (data.status == 200)
            return data.json();
        return Promise.reject(data);

    }

    /**
     * Reload a session with the calries burnt getting updated
     *
     * @method EliteService#updateSession
     * @param {string} sessionId - Session Id
     * @example
     * await eliteService.updateSession('bsdlsdkjskdsd-sdsjdh-3jwdj');
     *
     *
     */
    async updateSession(sessionId) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/session/update-session/${sessionId}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            },
            method: 'PUT',
        });

        if (data.status == 200)
            // return data.json();
            return true;
        return Promise.reject(data);
    }

    /**
     * Get the data of tenant by name
     *
     * @method EliteService#getTenantData
     * @param {string} tenantName - tenant name
     * @example
     * await eliteService.getTenantData('elitefit');
     *
     *
     */
    async getTenantData(tenantName) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/trainer/${tenantName}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            },
            method: 'GET',
        });

        if (data.status == 200)
            // return data.json();
            return data.json();
        return Promise.reject(data);
    }

    /**
     * Get the data of tenant by name
     *
     * @method EliteService#getTenantData
     * @example
     * await eliteService.getTenantData('elitefit');
     *
     *
     * @param tenantId
     */
    async getTenantVideos(tenantId) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/trainer/videos/${tenantId}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            },
            method: 'GET',
        });

        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }

    /**
     * Get Calories burnt for the time passed Videos to display .
     *
     * @method EliteService#getAssistMessage
     *  @param {int} startTime - time elapsed
     *  @param {int} endTime - time elapsed
     * @param {int} videoId - id of the video.
     * @param {int} sessionId - Session Id.
     * @example
     * await eliteService.getAssistMessage({id:1, startTime:1, endTime:3});
     * @returns {Object}
     *
     */
    async getAssistMessage(startTime, endTime, videoId, sessionId) {
        const authorization = this._getAuth();
        const data = await fetch(`${this.options.baseUrl}/session/assist-message?videoId=${videoId}&sessionId=${sessionId}&startTime=${startTime}&endTime=${endTime}`, {
            headers: {
                'content-type': 'application/json',
                'ef-client-type': 'web',
                authorization
            }
        });
        if (data.status == 200)
            return data.json();
        return Promise.reject(data);
    }
}
