import ElitePoseBase from "../../ef-base/ElitePoseBase";

import PoseDetector from "./PoseDetector.js";
import PoseRenderer from "./PoseRenderer.js";
import PoseExaminer from "./PoseExaminer.js";

const COLLECTION_FREQUENCY = 3
const POSE_FRAME_COUNT_PER_SECOND = 5
const IS_OVERLAP_TIME = true
const POSE_DATA_FETCH_FROM_DB = true

/**
 ElitePoseOptions
 * @typedef {Object} ElitePoseOptions
 * @property {number} captureInterval - Capture interval in ms. Defaults to 1000
 * @property {boolean} postAfterInterval - Whether library should post the data after each interval. Defaults to true.
 * @property {PoseDetectorOptions} detector - Pose detector options
 * @property {PoseExaminerOptions} examiner - Pose examiner options
 * @property {PoseRendererOptions} renderer - Pose renderer options
 * @property {Function | null} userInFrameCallback - Callback function to indicate if user  in frame or not;
 *
 */

/**
 *  ElitePose class can be used to initialize video elements and track user poses.
 * @class PoseNet
 * @classdesc ElitePose class can be used to initialize video elements
 * @example
 * let elitePose = new ElitePose(options);
 *
 */
export default class PoseNet extends ElitePoseBase {

    /**
     * @param {Object} eliteService - EliteService instance.
     * @param {{captureInterval: number, debug: boolean, userInFrameCallback: options.userInFrameCallback, callBackLoaded: options.callBackLoaded, postAfterInterval: boolean, pauseVideoIfUserIsAway: boolean}} options - options to override.
     */
    constructor(eliteService, options = {}) {
        super(eliteService);
        let defaultOptions = {
            captureInterval: 1000,
            postAfterInterval: false,
            pauseVideoIfUserIsAway: false,
            pauseVideoCheckInterval: 5000,
            userInFrameCallback: null,
            debug: false,
            renderer: {
                successColor: 'green',
                errorColor: 'red',
                defaultColor: 'yellow',
            },
            examiner: {
                minPoseConfidence: 0.1,
                minPartConfidence: 0.5,
            },
            detector: {
                modelConfig: {
                    architecture: "MobileNetV1",
                    outputStride: 16,
                    inputResolution: 250,
                    multiplier: 1.0,
                    quantBytes: 2
                },
                algorithm: "single-pose"
            },
            collectionFrequency: COLLECTION_FREQUENCY,
            poseFrameCountPerSecond: POSE_FRAME_COUNT_PER_SECOND,
            isOverlapTime: IS_OVERLAP_TIME,
            poseDataFetchFromDb: POSE_DATA_FETCH_FROM_DB,
        };
        this.options = Object.assign(defaultOptions, options);
        this.uploadPosesAndGetScoreCallback = this.options.uploadPosesAndGetScoreCallback;
    }

    /**
     * initialize camera and canvas elements.
     * @method ElitePose#initCamera
     * @param {HTMLVideoElement} videoEl - Video Element corresponding to user video input.
     * @param {HTMLCanvasElement} canvasEl - Canvas element where the output should be drawn.
     * @param {HTMLVideoElement} instructorVideoEl - Instructor video element.
     * @param videoId
     * @param videoId
     * @param EFTech
     * @param computePosenetJSON
     * @param {Array=} steps - Steps defined for the instructor video.
     * @param EFTech
     * @param computePosenetJSON
     * @example
     * let elitePose = new ElitePose();
     * await elitePose.initCamera(videoEl, canvasEl, instructorVideoEl, steps);
     *
     */
    async initCamera(videoEl, canvasEl, instructorVideoEl, videoId, steps = [], EFTech, computePosenetJSON) {

        this.videoEl = videoEl;
        this.canvasEl = canvasEl;
        this.instructorVideoEl = instructorVideoEl;
        this.videoId = videoId;

        if (!(videoEl || canvasEl || instructorVideoEl || videoId)) {
            throw Error("Please pass required parameters");
        }

        this.videoEl.height = this.videoEl.offsetHeight;
        this.videoEl.width = this.videoEl.offsetWidth;

        this.steps = steps
        this.isVideoPlaying = false;

        this.videoElement = this.videoEl;
        this.canvasElement = this.canvasEl;
        this.canvasCtx = this.canvasElement.getContext('2d')

        await this.createNewSession(EFTech);

        if (this.sessionId) {
            await this._setupListeners(this.instructorVideoEl);
            await this._setupCamera(this.videoEl);
            this.renderer = new PoseRenderer(this.canvasEl, this.options.renderer);
            this.examiner = new PoseExaminer(steps, this.options.examiner);
            this.detector = new PoseDetector(this.options.detector);
            await this.detector.setup();
            this._render();
            this._storePoses(computePosenetJSON);
            if (this.options.pauseVideoIfUserIsAway) {
                this._checkUserMovement();
            }
        }
        else {
            throw new Error(this.getSessionMessage());
        }
    }

    async _debug(videoEl, canvasEl, steps = []) {
        this.videoEl = videoEl;
        this.videoEl.height = this.videoEl.offsetHeight;
        this.videoEl.width = this.videoEl.offsetWidth;
        this.canvasEl = canvasEl;
        await this._setupCamera(this.videoEl);
        this.renderer = new PoseRenderer(this.canvasEl, {...this.options.renderer, debug: true});
        this.examiner = new PoseExaminer(steps, this.options.examiner);
        this.detector = new PoseDetector(this.options.detector);
        this.isVideoPlaying = false;
        await this.detector.setup();
        this._renderDebug();
    }

    async _renderDebug() {
        if (!this.detector.net) {
            return;
        }//detector is not setup correctly or the detector is disposed

        const poses = await this.detector.getPoses(this.videoEl);
        const filteredPoses = await this.examiner.examine(poses, 0);
        const scale = {
            scaley: this.videoEl.offsetHeight / this.videoEl.height,
            scalex: this.videoEl.offsetWidth / this.videoEl.width,
        }
        this.renderer.draw(this.videoEl, filteredPoses, scale)
        requestAnimationFrame(() => this._renderDebug());
    }

    async _render() {
        if (!this.detector.net) {
            requestAnimationFrame(() => this._render());
            return;
        }
        const poses = await this.detector.getPoses(this.videoEl);
        let filteredPoses = poses;
        if (this.isVideoPlaying) {
            let time = await this.instructorVideoEl.getCurrentTime();
            filteredPoses = await this.examiner.examine(poses, time);
        }

        let scaleDownRatio = this.videoEl.offsetWidth / this.videoEl.width;

        if (!scaleDownRatio || scaleDownRatio < this.renderer.options.maxScaleDownRatio) {
            scaleDownRatio = this.renderer.options.maxScaleDownRatio;
        }
        const scale = {
            scaley: scaleDownRatio,
            scalex: scaleDownRatio
        }
        const shift = {
            shifty: (this.canvasEl.height - this.videoEl.height * scale.scaley) / 2,
            shiftx: (this.canvasEl.width - this.videoEl.width * scale.scalex) / 2,
        }

        this.renderer.draw(this.videoEl, filteredPoses, scale, shift);
        requestAnimationFrame(() => this._render());
    }

    async _setupCamera(video) {

        video.setAttribute('autoplay', '');
        video.setAttribute('muted', '');
        video.setAttribute('playsinline', '');

        let constraints = {

            audio: false,
            video: {
                facingMode: 'user',
            },
        };

        this._stream = await navigator.mediaDevices.getUserMedia(constraints);
        video.srcObject = this._stream;
        if (this.instanceDisposed) {
            if (this._stream) {
                this.videoEl.src = "";
                this._stream.getVideoTracks().forEach(track => track.stop());
            }
            return new Promise.resolve();
        } else {
            video.play();
            return new Promise((resolve) => {
                video.onloadeddata = () => {
                    resolve(video);
                };
            });
        }
    }

    /* Function call to cluster poses collected at intervals within a second, bundled poses go to postPoses to
    submit POST request to API side*/
    _storePoses(computePosenetJSON) {

        let iterations = 0;
        let clusterPosesArray = [];

        let clusterPosesArrayForGetScoreAndAddPose = [];
        // To store the last pose data details if overlap time is true
        let lastPoseData = null;
        //calculating number of frames based on frames per second and the frequency
        let pose_data_count = this.options.collectionFrequency * this.options.poseFrameCountPerSecond;

        this.intervalID = setInterval(async () => {
            iterations++;
            if (computePosenetJSON) {
                if (await this._shouldCapture()) {
                    let time = await this.instructorVideoEl.getCurrentTime();
                    let pose = this.detector.getLastDetectedPoses();
                    const poseDetails = {
                        time: this._roundTime(time),
                        steps: {pose, width: this.videoEl.offsetWidth, height: this.videoEl.offsetHeight}
                    };
                    const modifiedPoseDetails = {
                        ...poseDetails,
                        sessionId: this.sessionId,
                        videoId: this.videoId,
                        pose_by: 'OP'
                    };
                    this.detectedPoses.push(poseDetails);
                    if (this.options.debug) {
                        console.error("OP keypoints :: ", poseDetails);
                    }
                    clusterPosesArray.push(modifiedPoseDetails);
                    const hasConfidence = this._checkConfidence(pose);
                    /*Only calls postPoses to update to db once every second,
                    with cluster of poses accumulated within the second at every captureInterval*/
                    if (this.options.postAfterInterval && this.eliteService != undefined && !(iterations % (1000 / this.options.captureInterval))) {
                        this.eliteService.postPoses(clusterPosesArray);
                        clusterPosesArray = [];
                    }
                    if (this.options.userInFrameCallback && typeof this.options.userInFrameCallback == 'function') {
                        this.options.userInFrameCallback(hasConfidence);
                    }
                }
            }
            else {
                let time = await this.instructorVideoEl.getCurrentTime();
                let pose = this.detector.getLastDetectedPoses();
                const poseDetails = {
                    time: this._roundTime(time),
                    steps: {pose, width: this.videoEl.offsetWidth, height: this.videoEl.offsetHeight}
                };
                const modifiedPoseDetails = {...poseDetails, sessionId: this.sessionId, videoId: this.videoId};
                this.detectedPoses.push(poseDetails);
                clusterPosesArray.push(modifiedPoseDetails);
                if (!(iterations % (1000 / this.options.captureInterval))) {
                    this.eliteService.postPoses(clusterPosesArray);
                    clusterPosesArray = [];
                }
            }
        }, this.options.captureInterval);
    }

    _checkUserMovement() {
        this.intervalMovement = setInterval(() => {
            if (this.isVideoPlaying) {
                let poses = this.detector.getLastDetectedPoses();
                poses.forEach(pose => {
                    if (pose.score < this.renderer.options.minPoseConfidence) {
                        this.instructorVideoEl.pauseVideo();
                        this._setVideoPlaying(false);
                    }
                });
            }
        }, this.options.pauseVideoCheckInterval)
    }

    _checkConfidence(pose) {
        let p = pose[0];
        let minPartConfidence = this.renderer.options.minPartConfidence;
        return p.score > this.options.renderer.minPoseConfidence &&
            p.keypoints[7].score > minPartConfidence &&
            p.keypoints[8].score > minPartConfidence &&
            p.keypoints[15].score > minPartConfidence &&
            p.keypoints[16].score > minPartConfidence
    }

    async _shouldCapture() {
        let time = await this.instructorVideoEl.getCurrentTime();
        let currentTime = this._roundTime(time);
        return this.isVideoPlaying && this._checkStepExists(currentTime);
    }

    _checkStepExists(currentTime) {
        return !!this.steps.find(step => currentTime >= +step.start && currentTime <= +step.end);
    }

    /**
     * Returns all the detected poses.
     * @method ElitePose#getPoses
     */
    getPoses() {
        return this.detectedPoses;
    }

    /**
     * Releases the resources used and clears all internal timers.
     * Should be called at the end.
     * @method ElitePose#dispose
     */
    dispose() {
        clearInterval(this.intervalID);
        this.instanceDisposed = true;
        if (this._stream) {
            this.videoEl.src = "";
            this._stream.getVideoTracks().forEach(track => track.stop());
        }

        if (this.detector) {
            this.detector.dispose();
        }

        if (this.intervalMovement) {
            clearInterval(this.intervalMovement);
        }
    }

}
