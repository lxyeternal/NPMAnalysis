
/**
 PoseExaminerOptions
 * @typedef {Object} PoseExaminerOptions
 * @property {number} minPoseConfidence - minimum pose confidence for the pose to be considered
 * @property {number} minPartConfidence - minimum part confidence.
 * Requires a EliteService instance to be passed along.
 *
  */

/**
 *
 * @class PoseExaminer
 * @classdesc PoseExaminer class can be used to examine the poses of user.
 * @param {Object[]?} steps - steps assosciated with a video.
 * @param {PoseExaminerOptions=} options - options to override.
 * @example
 * let poseExaminer = new PoseExaminer();
 * await poseExaminer.examine(poses);
 */

export default class PoseExaminer {

    /**
     * @param {Object[]?} steps - steps assosciated with a video.
    * @param {PoseExaminerOptions?} options - options to override.
    */
    constructor(steps = [], options = {}) {
        this.steps = steps;
        let defaultOptions = {
            minPoseConfidence: 0.1,
            minPartConfidence: 0.5,
        }
        this.options = Object.assign(defaultOptions, options);
    }

    /**
    * Examine the input poses for errors and filter out the poses which doesnt matc the minimum confidence 
    * defined in the options.
    * @param {Pose[]} poses - input user poses to examine
    * @param {number} time - current time of the reference video / instructor video. 
    * @method PoseExaminer#examine
    * @example
    * await poseExaminer.examine();
    * @returns {Pose[]} filteredPoses - filtered poses specifying if the keypoints have error.
    */

    examine(poses, time) {
        let filteredPoses = this.filterPoses(poses);
        filteredPoses = filteredPoses.map(pose => this.detectSteps(pose, this.roundTime(time)));
        return filteredPoses;
    }

    //spacebox and timebox
    detectSteps(pose, time) {
        const currentStep = this.getStepFromTime(time);

        if (!currentStep) {
            this.setError(pose.keypoints, false);
            return pose;
        }
        const shoulders = this.filterKeyPointsByPart(pose.keypoints, "shoulder");
        const leftShoulder = shoulders[0];
        const rightShoulder = shoulders[1];

        if (leftShoulder.score > this.options.minPartConfidence && rightShoulder.score > this.options.minPartConfidence) {

            const shoulder_total = rightShoulder.position.x - leftShoulder.position.x;

            if (currentStep.parts && currentStep.parts.length > 0) {
                this.setError(pose.keypoints, false);
                currentStep.parts.forEach(bodyPart => {

                    const filteredKeypoints = this.filterKeyPointsByPart(pose.keypoints, bodyPart.part);

                    // calculating position based on shoulder position
                    const lowest_y = leftShoulder.position.y - bodyPart.ly * shoulder_total;
                    const highest_y = rightShoulder.position.y + bodyPart.hy * shoulder_total;
                    const lowest_x = leftShoulder.position.x - bodyPart.lx * shoulder_total;
                    const highest_x = rightShoulder.position.x + bodyPart.hx * shoulder_total;
                    filteredKeypoints.forEach(kp => {
                        kp.hx = highest_x;
                        kp.hy = highest_y;
                        kp.lx = lowest_x;
                        kp.ly = lowest_y;
                    })

                    this.checkForErrors(filteredKeypoints, lowest_y, highest_y, lowest_x, highest_x);
                });
            } else {
                this.setError(pose.keypoints, false);
            }

        } else {
            this.setError(pose.keypoints, true);
        }

        return pose;
    }

    checkForErrors(keypoints, lowY, highY, lowX, highX) {
        keypoints.forEach(keypoint => {
            if (keypoint.position.x > lowX &&
                keypoint.position.x < highX &&
                keypoint.position.y > lowY &&
                keypoint.position.y < highY) {
                keypoint.error = false;
            } else {
                keypoint.error = true;
            }
        });
    }

    setError(keypoints, error) {
        keypoints.forEach(point => {
            point.error = error;
        });
    }


    getStepFromTime(time) {
        return this.steps.find(step => time >= +step.start && time <= +step.end);
    }

    roundTime(time) {
        return Math.floor(time, 10);
    }

    filterPoses(poses) {
        return poses.filter(pose => pose.score >= this.options.minPoseConfidence);
    }

    filterKeyPointsByPart(keypoints = [], part = "") {
        return keypoints.filter(keypoint => keypoint.part.toLowerCase().includes(part.toLowerCase()))
    }

}







