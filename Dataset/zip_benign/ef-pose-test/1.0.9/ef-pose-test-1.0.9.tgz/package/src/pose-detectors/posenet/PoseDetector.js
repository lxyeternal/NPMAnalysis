import * as posenet from "@tensorflow-models/posenet";

/**
 PoseDetectorOptions
 * @typedef {Object} PoseDetectorOptions
 * @property {Object} modelConfig - Model Configuration Object for posenet model.
 * @property {string} algorithm - Algorithm to use (single-pose / multi-pose)
 *
  */

/**
 *  
 * @class PoseDetector
 * @classdesc PoseDetector class can be used to detect user poses from an image/video. It uses posenet to detect the poses.
 * @param {PoseDetectorOptions=} options - options to override
 * @example
 * let poseDetector = new PoseDetector();
 * await poseDetector.setup();
 */

export default class PoseDetector {


    /**
    * @param {PoseDetectorOptions?} options - options to override.
    */
    constructor(options = {}) {
        this.net = null;
        this.renderer = null;
        this.examiner = null;
        this.poses = [];
        let defaultOptions = {
            modelConfig: {
                architecture: "MobileNetV1",
                outputStride: 16,
                inputResolution: 250,
                multiplier: 1.0,
                quantBytes: 2
            },
            algorithm: "single-pose"
        }

        this.options = Object.assign(defaultOptions, options);
        this.modelConfig = this.options.modelConfig;
    }

    /**
    * Setup the posenet model based on the options.
    * This method should be called before starting the pose detection
    * @method PoseDetector#setup
    * @example
    * await poseDetector.setup();
    *
    */

    async setup() {
        this.net = await posenet.load(this.modelConfig);
    }

    /**
    * Get poses assosciated with an image/video.
    * 
    * @method PoseDetector#getPoses
    * @param {HTMLVideoElement | HTMLImageElement} image - image / video on which pose detection should run
    * @example
    * await poseDetector.getPoses(userVideo);
    *
    * @returns poses  detected in the image/video.
    */

    async getPoses(image) {
        if (!this.net) {
            return [];
        }

        const algorithm = this.options.algorithm;

        if (algorithm == "single-pose") {
            //console.time('estimate');
            const pose = await this.net.estimatePoses(image, {
                flipHorizontal: true,
                decodingMethod: "single-person"
            });
            // console.timeEnd('estimate');
            this.poses = pose;
        }
        else if (algorithm == "multi-pose") {
            let allPoses = await this.net.estimatePoses(image, {
                flipHorizontal: true,
                decodingMethod: "multi-person",
                maxDetections: 5,
                scoreThreshold: 0.1,
                nmsRadius: 30.0
            });
            this.poses = allPoses;;
        }
        return this.poses;
    }

    /**
    * Disposes the posenet model and all associated resources.
    * This method should be called when the resources should be cleared and there is no further use of 
    * the detector is required.
    *
    * @method PoseDetector#dispose
    *
    */

    dispose() {
        this.net.dispose();
        this.net = null;
    }

    /**
    * Returns the last detected poses by the detector. returns an empty array if there are no detected poses till now.
    *
    * @method PoseDetector#getLastDetectedPoses
    *
    */

    getLastDetectedPoses() {
        return this.poses;
    }


}



