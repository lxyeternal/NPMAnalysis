import * as posenet from "@tensorflow-models/posenet";

import '@tensorflow/tfjs-backend-webgl';
import '@tensorflow/tfjs-backend-cpu';

/**
 PoseRendererOptions
 * @typedef {Object} PoseRendererOptions
 * @property {number} minPoseConfidence - minimum pose confidence for the pose to be considered
 * @property {number} minPartConfidence - minimum part confidence.
 * @property {string} defaultColor - Default color. Defaults to yellow.
* @property {string} errorColor - Error color. Defaults to red
* @property {string} successColor - Success color. Defaults to green.
* @property {Array} keypointsToShow - Keypoints to be shown in the output. e.g ["shoulder", "hip", "knee", "ankle", "wrist", "elbow"]
* @property {boolean} showVideo - Whether the video has to be rendered. Defaults to true,
* @property {Object} scale -{scalex,scaley} the x and y mulptiplication factors

 * Requires a EliteService instance to be passed along.
 *
  */

/**
 *
 * @class PoseRenderer
 * @classdesc PoseRenderer class is used for visualisation of the keypoints on a canvas.
 * @param {HTMLCanvasElement} canvas - canvas on which the user video should be drawn.
 * @param {PoseRendererOptions=} options - options to override.
 * @example
 * let poseRenderer = new PoseRenderer();
 * await poseRenderer.draw(userVideo,poses);
 */
export default class PoseRenderer {

    /**
    * @param {HTMLCanvasElement} canvas - canvas on which the user video should be drawn.
    * @param {PoseRendererOptions?} options - options to override.
    */
    constructor(canvas, options = {}) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d');
        const defaultOptions = {
            minPoseConfidence: 0.1,
            minPartConfidence: 0.5,
            showVideo: true,
            defaultColor: "yellow",
            successColor: "green",
            errorColor: "red",
            scale: {
                scalex: 1,
                scaley: 1
            },
            shift: {
                shiftx: 0,
                shifty: 0,
            },
            maxScaleDownRatio: 0,
            keypointsToShow: ["shoulder", "hip", "knee", "ankle", "wrist", "elbow"],
            lineWidth: 5,
            debug: false
        };
        this.defaultOptions = Object.assign({}, defaultOptions);
        this.options = Object.assign(defaultOptions, options);
    }


    /**
      * Draws the input video on the canvas and drwas the skeleton on top of it.
      * @param {HTMLImageElement|HTMLVideoElement} image - Image / Video to be drwan
      * @param {Pose[]} poses - poses with keypoints to be visualised.
      * @param {Object} scale - Scale down or scale up factor. {scalex,scaley} the x and y mulptiplication factors. defults to 1
      * @method PoseRenderer#draw
      * @example
      * await poseRenderer.draw(userVideo,poses);
      */

    draw(image, poses = [], scale = this.options.scale, shift = this.options.shift) {
        this.drawImage(image);
        poses.forEach((pose) => {
            this.drawKeypoints(this._filterDisplayableParts(pose.keypoints, this.options.keypointsToShow), scale, shift);
            const adjacentKeyPoints = this.getAdjacentKeyPoints(pose.keypoints);
            this.drawSkeleton(adjacentKeyPoints, scale, shift);
        });

    }


    drawImage(image) {

        let width = image.offsetWidth;
        let height = image.offsetHeight;

        this.canvas.width = width;
        this.canvas.height = width / 1.385135135135135; //maintaining aspect ratio same as video div

        this.ctx.clearRect(0, 0, width, height);
        this.ctx.save();
        this.ctx.scale(-1, 1);
        this.ctx.translate(-width, 0);
        if (this.options.showVideo) {
            this.
                drawImageProp(this.ctx, image, 0, 0, this.canvas.width, this.canvas.height);
        } else {
            this.ctx.rect(0, 0, width, height);
            this.ctx.fillStyle = "#000000";
            this.ctx.fill();
        }

        this.ctx.restore();

    }

    //https://stackoverflow.com/questions/21961839/simulation-background-size-cover-in-canvas
    drawImageProp(ctx, img, x, y, w, h, offsetX, offsetY) {

        if (arguments.length === 2) {
            x = y = 0;
            w = ctx.canvas.width;
            h = ctx.canvas.height;
        }

        // default offset is center
        offsetX = typeof offsetX === "number" ? offsetX : 0.5;
        offsetY = typeof offsetY === "number" ? offsetY : 0.5;

        // keep bounds [0.0, 1.0]
        if (offsetX < 0) offsetX = 0;
        if (offsetY < 0) offsetY = 0;
        if (offsetX > 1) offsetX = 1;
        if (offsetY > 1) offsetY = 1;

        var iw = img.videoWidth, //incoming image is a video , so taking the videoWidth instead of width
            ih = img.videoHeight,//incoming image is a video , so taking the videoHeight instead of height
            r = Math.min(w / iw, h / ih),
            nw = iw * r,   // new prop. width
            nh = ih * r,   // new prop. height
            cx, cy, cw, ch, ar = 1;

        // decide which gap to fill    
        if (nw < w) ar = w / nw;
        if (Math.abs(ar - 1) < 1e-14 && nh < h) ar = h / nh;  // updated
        nw *= ar;
        nh *= ar;

        // calc source rectangle
        cw = iw / (nw / w);
        ch = ih / (nh / h);

        cx = (iw - cw) * offsetX;
        cy = (ih - ch) * offsetY;

        // make sure source rectangle is valid
        if (cx < 0) cx = 0;
        if (cy < 0) cy = 0;
        if (cw > iw) cw = iw;
        if (ch > ih) ch = ih;

        // fill image in dest. rectangle
        ctx.drawImage(img, cx, cy, cw, ch, x, y, w, h);
    }

    drawKeypoints(keypoints, scale = this.options.scale, shift = this.options.shift) {
        for (let i = 0; i < keypoints.length; i++) {
            const keypoint = keypoints[i];
            if (keypoint.score < this.options.minPartConfidence) {
                continue;
            }
            const { y, x } = keypoint.position;

            this.drawPoint((y * scale.scaley + shift.shifty), (x * scale.scalex + shift.shiftx), 3, this._getColor(keypoint));

            if (this.options.debug) {
                this.drawSegment([keypoint.ly, keypoint.lx], [keypoint.ly, keypoint.hx], scale, 'white');
                this.drawSegment([keypoint.ly, keypoint.hx], [keypoint.hy, keypoint.hx], scale, 'white');
                this.drawSegment([keypoint.hy, keypoint.hx], [keypoint.hy, keypoint.lx], scale, 'white');
                this.drawSegment([keypoint.hy, keypoint.lx], [keypoint.ly, keypoint.lx], scale, 'white');
            }
        }
    }

    drawSkeleton(adjacentKeyPoints, scale = this.defaultOptions.scale, shift = this.defaultOptions.shift,) {

        adjacentKeyPoints.forEach((keypoints) => {
            const keypointWithError = keypoints[1] && keypoints[1].error ? keypoints[1] : keypoints[0]
            this.drawSegment(toTuple(keypoints[0].position), toTuple(keypoints[1].position), scale, this._getColor(keypointWithError), shift);
        });

        function toTuple({ y, x }) {
            return [y, x];
        }
    }

    drawPoint(y, x, r, color = this.defaultOptions.defaultColor) {
        this.ctx.beginPath();
        this.ctx.arc(x, y, r, 0, 2 * Math.PI);
        this.ctx.fillStyle = color
        this.ctx.fill();
    }

    drawSegment([ay, ax], [by, bx], scale = this.options.scale, color = this.defaultOptions.defaultColor, shift = this.defaultOptions.shift) {
        this.ctx.beginPath();
        this.ctx.moveTo((ax * scale.scalex + shift.shiftx), (ay * scale.scaley + shift.shifty));
        this.ctx.lineTo((bx * scale.scalex + shift.shiftx), (by * scale.scaley + shift.shifty));
        this.ctx.lineWidth = this.options.lineWidth;
        this.ctx.strokeStyle = color
        this.ctx.stroke();
    }


    getAdjacentKeyPoints(keypoints) {
        return posenet.getAdjacentKeyPoints(keypoints, this.options.minPartConfidence);
    }

    addAdjacentKeyPoints(poses) {
        poses.forEach(pose => {
            pose._adjacentKeyPoints = this.getAdjacentKeyPoints(pose.keypoints);
        });

        return poses;
    }

    _getColor(keypoint) {
        return keypoint.error != undefined ? (keypoint.error == true ? (!!this.options.errorColor ? this.options.errorColor : this.defaultOptions.errorColor) : (!!this.options.successColor ? this.options.successColor : this.defaultOptions.successColor)) : (!!this.options.defaultColor ? this.options.defaultColor : this.defaultOptions.defaultColor);
    }

    _filterDisplayableParts(keypoints, parts = []) {
        return keypoints.filter(keypoint => !!parts.find(part => keypoint.part.toLowerCase().includes(part)))
    }

}







