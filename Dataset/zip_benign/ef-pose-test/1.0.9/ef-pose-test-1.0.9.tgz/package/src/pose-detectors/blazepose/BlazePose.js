import ElitePoseBase from "../../ef-base/ElitePoseBase";

import {Camera} from "@mediapipe/camera_utils/camera_utils.js";
import {drawConnectors, drawLandmarks} from "@mediapipe/drawing_utils/drawing_utils.js";
import {Pose, POSE_CONNECTIONS} from "@mediapipe/pose/pose.js";

const COLLECTION_FREQUENCY = 3
const POSE_FRAME_COUNT_PER_SECOND = 5
const IS_OVERLAP_TIME = true
const POSE_DATA_FETCH_FROM_DB = false
const ACC_SCORE_INTERVAL = 5000;

export default class BlazePose extends ElitePoseBase {

    constructor(eliteService, options = {}) {
        super(eliteService);
        const defaultOptions = {
            captureInterval: 1000,
            postAfterInterval: false,
            pauseVideoIfUserIsAway: false,
            pauseVideoCheckInterval: 5000,
            userInFrameCallback: null,
            callBackLoaded: null,
            stickFigureLineColor: null,
            modelComplexity: 0,
            minPoseConfidence: 0.1,
            minPartConfidence: 0.01,
            debug: false,
            renderer: {
                showVideo: true,
            },
            collectionFrequency: COLLECTION_FREQUENCY,
            poseFrameCountPerSecond: POSE_FRAME_COUNT_PER_SECOND,
            isOverlapTime: IS_OVERLAP_TIME,
            poseDataFetchFromDb: POSE_DATA_FETCH_FROM_DB,
            accScoreInterval: ACC_SCORE_INTERVAL
        };
        this.options = Object.assign(defaultOptions, options);
        this.uploadPosesAndGetScoreCallback = this.options.onResult ?
            this.options.onResult : this.options.uploadPosesAndGetScoreCallback;

        this.detectedPoses = [];//To collect the detected poses
        this.posesKeypoints = []
        this.pose = null
        this.camera = null

        this.oldAccuracy = 0;
        this.oldCalories = 0;
        this.timeLapsed = 0;
    }

    getLastDetectedPoses() {
        return this.posesKeypoints;
    }

    async _shouldCapture() {
        let time = await this.instructorVideoEl.getCurrentTime();
        let currentTime = this._roundTime(time);
        return this.isVideoPlaying && this._checkStepExists(currentTime);
    }

    _checkStepExists(currentTime) {
        return !!this.steps.find(step => currentTime >= +step.start && currentTime <= +step.end);
    }

    async initCamera(videoEl, canvasEl, instructorVideoEl, videoId, steps = [], EFTech) {

        this.videoEl = videoEl;
        this.videoId = videoId;
        this.canvasEl = canvasEl;

        if (!(videoEl || canvasEl || instructorVideoEl || videoId)) {
            throw Error("Please pass required parameters");
        }

        this.videoEl.height = this.videoEl.offsetHeight;
        this.videoEl.width = this.videoEl.offsetWidth;

        this.instructorVideoEl = instructorVideoEl;
        this.steps = steps
        this.isVideoPlaying = false;
        this.videoElement = this.videoEl;
        this.canvasElement = this.canvasEl;
        this.canvasCtx = this.canvasElement.getContext('2d');

        await this.createNewSession(EFTech);
        if (this.sessionId) {
            await this._setupListeners(this.instructorVideoEl);
            await this.startRendering()
            this._storePoses();
            if (this.options.pauseVideoIfUserIsAway) {
                this._checkUserMovementBP();
            }
        }
        else {
            throw new Error(this.getSessionMessage());
        }
    }

    async startRendering() {
        return new Promise(async (resolve, reject) => {
            try {
                this.onResults = (results) => {
                    try {
                        if (this.options.callBackLoaded && typeof this.options.callBackLoaded == 'function') {
                            this.options.callBackLoaded(true);
                        }
                        resolve(true);
                        this.drawImage(this.videoElement);
                        // Draw the overlays.
                        this.canvasCtx.save();
                        this.canvasCtx.clearRect(0, 0, this.canvasEl.width, this.canvasEl.height);
                        this.canvasCtx.drawImage(results.image, 0, 0, this.canvasEl.width, this.canvasEl.height);

                        this.canvasCtx.restore();

                        if (results.poseLandmarks) {
                            results.poseLandmarks.splice(0, 11, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {})
                        }
                        keypoints = results.poseLandmarks
                        this.posesKeypoints = keypoints;
                        let color = 'white';
                        if (typeof this.options.stickFigureLineColor === 'function') {
                            color = this.options.stickFigureLineColor();
                        }
                        drawConnectors(this.canvasCtx, results.poseLandmarks, POSE_CONNECTIONS,
                            {visibilityMin: 0.65, color: color});
                        drawLandmarks(this.canvasCtx, results.poseLandmarks,
                            {visibilityMin: 0.65, color: 'white', lineWidth: 3, radius: 3});
                        this.canvasCtx.restore();
                    } catch (err) {
                        console.error("blaze poser err ::: ", err)
                        reject(false)
                    }

                }
                let keypoints = []
                this.pose = new Pose({
                    locateFile: (file) => {
                        // return `https://cdn.jsdelivr.net/npm/@mediapipe/pose@0.3.1621277220/${file}`;
                        // return `https://cdn.jsdelivr.net/npm/@mediapipe/pose@0.1/${file}`;
                        // return `https://cdn.jsdelivr.net/npm/@mediapipe/pose@0.4.1627931336/${file}`;
                        return `https://cdn.jsdelivr.net/npm/@mediapipe/pose/${file}`;
                    }
                });
                this.pose.setOptions({
                    selfieMode: true,
                    upperBodyOnly: false,
                    smoothLandmarks: true,
                    modelComplexity: this.options.modelComplexity,
                    minDetectionConfidence: 0.5,
                    minTrackingConfidence: 0.5
                });
                this.pose.onResults(this.onResults);
                this.camera = new Camera(this.videoElement, {
                    onFrame: async () => {
                        await this.pose.send({image: this.videoElement});
                    }
                });
                await this.camera.start();
            } catch (e) {
                console.error("blaze pose error ::: ", e)
                reject(false)
            }
        })
    }

    async _storePoses() {
        let iterations = 0;
        let clusterPosesArray = [];
        let clusterPosesArrayForGetScoreAndAddPose = [];

        // To store the last pose data details if overlap time is true
        let lastPoseData = null;

        //calculating number of frames based on frames per second and the frequency
        let pose_data_count = this.options.collectionFrequency * this.options.poseFrameCountPerSecond;

        this.intervalID = setInterval(async () => {
            let pose = this.getLastDetectedPoses();
            const hasBPConfidence = this._isBodyVisible(pose);

            if (this.options.userInFrameCallback && typeof this.options.userInFrameCallback == 'function') {
                this.options.userInFrameCallback(hasBPConfidence);
            }
            if (await this._shouldCapture()) {
                if (pose === undefined) {
                    this.instructorVideoEl.pauseVideo();
                    this._setVideoPlaying(false);
                }

                iterations++;
                let time = await this.instructorVideoEl.getCurrentTime();

                const poseDetails = {
                    time: this._roundTime(time),
                    steps: {pose, width: this.videoEl.offsetWidth, height: this.videoEl.offsetHeight}
                };
                const modifiedPoseDetails = {
                    ...poseDetails,
                    sessionId: this.sessionId,
                    videoId: this.videoId,
                    pose_by: 'BP'
                };
                if (this.options.debug) {
                    console.log("BP keypoints :: ", poseDetails);
                }
                this.detectedPoses.push(poseDetails);
                clusterPosesArray.push(modifiedPoseDetails);
                clusterPosesArrayForGetScoreAndAddPose.push(modifiedPoseDetails);

                if (this.options.poseDataFetchFromDb && !(iterations % (1000 / this.options.captureInterval))) {
                    this.eliteService.postPoses(clusterPosesArray);
                    clusterPosesArray = [];
                }

                if (clusterPosesArrayForGetScoreAndAddPose.length >= pose_data_count && !this.options.poseDataFetchFromDb) {
                    let poseData = [];
                    if (this.options.isOverlapTime) {
                        if (lastPoseData) {
                            //adding overlapping pose data object at the beginning of the pose data array
                            clusterPosesArrayForGetScoreAndAddPose.unshift(lastPoseData);
                        }
                        poseData = clusterPosesArrayForGetScoreAndAddPose.splice(0, pose_data_count);
                        //if overlap time is true then storing the last pose data details for next request
                        lastPoseData = poseData[poseData.length - 1];
                    } else {
                        poseData = clusterPosesArrayForGetScoreAndAddPose.splice(0, pose_data_count);
                    }

                    this.eliteService.uploadPosesAndGetScore(poseData, this.oldAccuracy, this.oldCalories, this.timeLapsed)
                        .then(res => {
                            this.oldAccuracy = res.avgAccuracy;
                            this.oldCalories = res.calorieBurnt;
                            this.timeLapsed = res.validTotalTime;
                            if (typeof this.uploadPosesAndGetScoreCallback === 'function') {
                                this.uploadPosesAndGetScoreCallback(res);
                            }
                        })
                        .catch(err => {
                            console.error(err);
                        })
                }
            }
        }, this.options.captureInterval);
    }

    dispose() {
        clearInterval(this.intervalID);
        if (this.poses) {
            this.poses.close();
        }

        if(this.videoEl && this.videoEl.srcObject){
            this.videoEl.srcObject.getTracks().forEach(function(track) {
                //stop camera
                track.stop();
            });
        }

        if (this.resultInterval) {
            clearInterval(this.resultInterval);
        }
    }

    drawImage(image) {
        let width = image.offsetWidth;
        let height = image.offsetHeight;
        let cameraWidth = image.videoWidth;
        let cameraHeight = image.videoHeight;
        let aspectRatio = cameraWidth/cameraHeight;
        // The constant maintains the aspect ratio same as the video div
        // video div default aspect ratio is 538/426 or 1.385135135135135
        this.canvasEl.height = height;
        this.canvasEl.width = height*aspectRatio;
    }

    _checkUserMovementBP() {
        this.intervalMovement = setInterval(() => {
            if (this.isVideoPlaying) {
                let poses = this.getLastDetectedPoses();
            }
        }, this.options.pauseVideoCheckInterval)
    }

    _isBodyVisible(pose) {
        let minPartConfidence = this.options.minPartConfidence;
        if (!pose) return;
        // 11=left_shoulder, 12=right_shoulder, 27=left_ankle, 28=right_ankle
        let points = [11, 12, 27, 28];
        let inFrameList = []
        inFrameList = points.map(element => {
            if (pose[element].x < 0 || pose[element].x > 1 || pose[element].y < 0 || pose[element].y > 1 || pose[element].visibility < minPartConfidence) {
                return false
            } else {
                return true
            }
        });
        return inFrameList.every(Boolean);
    }

    async getRoundCurrentTime() {
        let time = await this.instructorVideoEl.getCurrentTime();
        return +this._roundTime(time);
    }

    async getResult(onResult) {
        let endTime = await this.getRoundCurrentTime();
        let startTime = endTime - 5;
        const ctx = this;
        this.resultInterval = setInterval(async () => {
            if (ctx.isVideoPlaying) {
                if (await ctx._shouldCapture()) {
                    if (ctx.options.debug) {
                        console.log("GetResult");
                        console.log("startTime", startTime);
                        console.log("endTime", endTime);
                    }
                    const data = await ctx.eliteService.getCaloriesAndScore(
                        startTime,
                        endTime,
                        this.sessionId,
                        this.oldAccuracy,
                        this.oldCalories,
                        this.timeLapsed
                    );
                    if (data) {
                        ctx.oldAccuracy = data.avgAccuracy;
                        ctx.oldCalories = data.calorieBurnt;
                        ctx.timeLapsed = data.validTotalTime;
                        if (onResult && typeof onResult === 'function') {
                            onResult(data);
                        }
                    }
                }
                endTime = await this.getRoundCurrentTime();
                startTime = endTime - 5;
            }
        }, this.options.accScoreInterval);
    }
}
