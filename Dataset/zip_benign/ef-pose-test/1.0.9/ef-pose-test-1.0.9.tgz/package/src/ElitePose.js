import BlazePose from "./pose-detectors/blazepose/BlazePose";
import PoseNet from "./pose-detectors/posenet/PoseNet";

export default class ElitePose {

    constructor(eliteService, options = {}, poseBy = 'BP') {
        console.log("poseBy", poseBy);
        this.poseDetector = null;
        switch (poseBy) {
            case "BP":
                this.poseDetector = new BlazePose(eliteService, options);
                break;
            case "OP":
                this.poseDetector = new PoseNet(eliteService, options);
                break;
            default:
                throw "Pose detector not supported";
        }
        return this.poseDetector;
    }
}
