import AC_75 from "../assets/images/feedback/accuracy_75.svg";
import AC_25 from "../assets/images/feedback/accuracy_25.svg";
import AC_50 from "../assets/images/feedback/accuracy_50.svg";
import AC_95 from "../assets/images/feedback/accuracy_95.svg";
import watchTrainer from "../assets/images/feedback/watch_the_trainer.svg";
import amazing from "../assets/images/feedback/amazing.svg";

import wellDone from "../assets/images/feedback/well_done.svg";
import wow from "../assets/images/feedback/wow.svg";

import excellent from "../assets/images/feedback/excellent.svg";
import killin_it from "../assets/images/feedback/killin_it.svg";
import watch_your_form from "../assets/images/feedback/watch_your_form.svg";
import way_to_go from "../assets/images/feedback/way_to_go.svg";

import fantastic from "../assets/images/feedback/fantastic.svg";
import feel_the_burn from "../assets/images/feedback/feel_the_burn.svg";
import fight_harder from "../assets/images/feedback/fight_harder.svg";
import push_a_lil_more from "../assets/images/feedback/push_a_lil_more.svg";
import you_can_do_better from "../assets/images/feedback/you_can_do_better.svg";
import you_got_it from "../assets/images/feedback/you_got_it.svg";

import accuracy_down from "../assets/images/feedback/accuracy_down.svg";
import accuracy_up from "../assets/images/feedback/accuracy_up.svg";

import keep_moving from "../assets/images/feedback/keep_moving.svg";
import watch_left_arm from "../assets/images/feedback/watch_left_arm.svg";
import watch_right_arm from "../assets/images/feedback/watch_right_arm.svg";
import watch_left_leg from "../assets/images/feedback/watch_left_leg.svg";
import watch_right_leg from "../assets/images/feedback/watch_right_leg.svg";

import go_go_go from "../assets/images/feedback/go_go_go.svg";
import keep_going from "../assets/images/feedback/keep_going.svg";
import keep_it_up from "../assets/images/feedback/keep_it_up.svg";
import looking_good from "../assets/images/feedback/looking_good.svg";

import positiveAudio from "../assets/audios/positive.mp3";
import negativeAudio from "../assets/audios/negative.mp3";
import silentAudio from "../assets/audios/silence.mp3";

const STICKERS_INTERVAL_TIME = 10000;
const UP_STICKER_ACCURACY_INCREASE_DIFFERENCE = 5;
const DOWN_STICKER_ACCURACY_DECREASE_DIFFERENCE = -10;

/**
 * Below 30% : Watch your form , Push a lil harder, You can do better
 * 30% to 70%: Well done , Fight harder , Feel burn, You got it
 * Above 70% : Excellent , Way to go , Fantastic, You’re killing it ! Done
 * If the user score reduces by 10% then show accuracy (down)
 * If the user scores increase by 5% then show accuracy (up)
 */
const acc_0_30 = [watch_your_form, push_a_lil_more, you_can_do_better];
const acc_30_70 = [wellDone, fight_harder, feel_the_burn, you_got_it];
const acc_70_above = [excellent, way_to_go, fantastic, killin_it, wow, amazing];
const negativeAudioStickers = [
    AC_25,
    AC_50,
    watch_your_form,
    watchTrainer,
    accuracy_down,
    keep_moving,
    watch_left_arm,
    watch_right_arm,
    watch_left_leg,
    watch_right_leg,
];
const neutralStickers = [
    go_go_go,
    keep_going,
    keep_it_up,
    looking_good
];

export default class FeedbackSticker {

    constructor() {
        this.instantScore = undefined;
        this.message = "";
        this.avgAccuracy = undefined;
        this.hidden = false;
        this.audio = null;
        this.showStickers = false;
        this.stickersList = [];
        this.interval = null;
        this.stickers = "";
        this.onStickerChange = null;
    }

    initStickers(onStickerChangeCallback, stickersIntervalTime = undefined) {
        this.onStickerChange = onStickerChangeCallback;
        this.stickersIntervalTime = stickersIntervalTime ? stickersIntervalTime : STICKERS_INTERVAL_TIME;
        this.setTimeForStickers();
    }

    audioInitialised() {
        return this.audio;
    }

    setTimeForStickers() {
        let ctx = this;
        this.interval = setInterval(function () {
            if (!ctx.hidden && ctx.showStickers) {
                let sticker =
                    ctx.stickersList.length > 0 ? ctx.getRandom(ctx.stickersList) : ctx.getRandom(neutralStickers);
                let isAccuracyConflict = false;
                //check average accuracy score before displaying a sticker on the screen
                if (sticker === AC_95 && ctx.avgAccuracy < 95) {
                    isAccuracyConflict = true;
                } else if (sticker === AC_75 && ctx.avgAccuracy < 75) {
                    isAccuracyConflict = true;
                } else if (sticker === AC_50 && ctx.avgAccuracy < 50) {
                    isAccuracyConflict = true;
                } else if (sticker === AC_25 && ctx.avgAccuracy < 25) {
                    isAccuracyConflict = true;
                }
                if (isAccuracyConflict) {
                    ctx.stickersList = [];
                    ctx.getInstantScoreStickers(ctx.instantScore);
                    sticker =
                        ctx.stickersList.length > 0
                            ? ctx.getRandom(ctx.stickersList)
                            : ctx.getRandom(neutralStickers);
                }
                if (sticker !== "") {
                    if (ctx.audioInitialised()) {
                        //set positive or negative sound
                        ctx.audio.src = ctx.isPositiveAudio(sticker)
                            ? positiveAudio
                            : negativeAudio;
                        ctx.audio.play();
                    }
                    ctx.stickers = sticker;
                    ctx.stickersList = [];
                    if (typeof ctx.onStickerChange === 'function') {
                        ctx.onStickerChange(ctx.stickers);
                    }
                }
            } else {
                ctx.stickers = "";
                ctx.stickersList = [];
                if (typeof ctx.onStickerChange === 'function') {
                    ctx.onStickerChange(ctx.stickers);
                }
            }
        }, STICKERS_INTERVAL_TIME);
    }

    isPositiveAudio(sticker) {
        if (negativeAudioStickers.includes(sticker)) {
            return false;
        } else {
            return true;
        }
    }

    getRandom(array) {
        return array[Math.floor(Math.random() * array.length)];
    }

    initAudioFiles(volume) {
        volume = volume <= 1 ? volume : 1;
        this.audio = new Audio(silentAudio);
        this.audio.autoplay = true;
        this.audio.volume = volume;
    }

    setVolume(volume) {
        if (this.audioInitialised()) {
            volume = volume <= 1 ? volume : 1;
            this.audio.volume = volume;
        }
    }

    muteAudio() {
        if (this.audioInitialised()) {
            this.audio.volume = 0;
        }
    }

    getInstantScoreStickers(val) {
        if (val < 30) {
            this.stickersList.push(...acc_0_30);
            if (val > 25) this.stickersList.push(watchTrainer);
        } else if (val >= 30 && val < 70) {
            this.stickersList.push(...acc_30_70);
        } else {
            this.stickersList.push(...acc_70_above);
        }
    }

    getPrescriptiveStickers(message) {
        //push prescriptive stickers to the stickersList array
        message.forEach((element) => {
            if (
                element == "UserStill" &&
                !this.stickersList.includes(keep_moving)
            ) {
                this.stickersList.push(keep_moving);
            } else if (
                element == "WatchLeftArm" &&
                !this.stickersList.includes(watch_left_arm)
            ) {
                this.stickersList.push(watch_left_arm);
            } else if (
                element == "WatchRightArm" &&
                !this.stickersList.includes(watch_right_arm)
            ) {
                this.stickersList.push(watch_right_arm);
            } else if (
                element == "WatchRightLeg" &&
                !this.stickersList.includes(watch_right_leg)
            ) {
                this.stickersList.push(watch_right_leg);
            } else if (
                element == "WatchLeftLeg" &&
                !this.stickersList.includes(watch_left_leg)
            ) {
                this.stickersList.push(watch_left_leg);
            }
        });
    }

    setInstantScore(instantScore) {
        this.showStickers = true;
        this.getInstantScoreStickers(instantScore);
    }

    setMessage(message) {
        this.getPrescriptiveStickers(message);
    }

    setAvgAccuracy(newAvg, oldAvg) {
        let difference = newAvg - oldAvg;

        if (difference >= UP_STICKER_ACCURACY_INCREASE_DIFFERENCE) {
            this.stickersList.push(accuracy_up);

            if (newAvg >= 95 && oldAvg < 95) {
                this.stickersList.push(AC_95);
            } else if (newAvg >= 75 && oldAvg < 75) {
                this.stickersList.push(AC_75);
            } else if (newAvg >= 50 && oldAvg < 50) {
                this.stickersList.push(AC_50);
            } else if (newAvg >= 25 && oldAvg < 25) {
                this.stickersList.push(AC_25);
            }
        }

        if (difference <= DOWN_STICKER_ACCURACY_DECREASE_DIFFERENCE)
            this.stickersList.push(accuracy_down);
    }

    setHidden(val) {
        this.hidden = val;
    }

    getSticker() {
        return this.stickers;
    }

    dispose() {
        this.stickersList = [];
        clearInterval(this.interval);
    }

}
