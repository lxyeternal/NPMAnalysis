### 依赖 javascript-obfuscator 做的js打包加密工具

#### 官方仓库 https://github.com/javascript-obfuscator/javascript-obfuscator

##### 加密单文件

```
jsjiami filename.js
```

##### 自定义加密 配置文件 jsjiami.config.js

```javascript
const path = require('path');
module.exports = {
        files:[
            path.join(__dirname,'a.js'),
            path.join(__dirname,'b.js')
        ],
        output:path.join(__dirname,'dist'),
        option:{
            compact: true,
            controlFlowFlattening: true,
            controlFlowFlatteningThreshold: 0.75,
            deadCodeInjection: true,
            deadCodeInjectionThreshold: 0.5,
            debugProtection: true,
            debugProtectionInterval: true,
            disableConsoleOutput: true,
            stringArrayEncoding: ['rc4'],
            stringArrayRotate: true,
            stringArrayThreshold: 0.75,
            renameProperties: true,
            renamePropertiesMode: 'safe',
        }
    }

```
##### 具体参数参照官方仓库 直接在jsjiami.config.js所在目录下执行
```
jsjiami
```