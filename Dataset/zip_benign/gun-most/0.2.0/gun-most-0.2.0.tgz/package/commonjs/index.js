'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CompleteToken = undefined;

var _gun = require('gun/gun');

var _gun2 = _interopRequireDefault(_gun);

var _mostSubject = require('most-subject');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* eslint-disable import/prefer-default-export */

_gun2.default.chain.most = function most() {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      completeToken = _ref.completeToken,
      options = _ref.options;

  var subject = (0, _mostSubject.async)();
  this.on(function (data) {
    return subject.next(data);
  }, options);
  if (completeToken) {
    completeToken.listen.observe(function () {
      return undefined;
    }).then(function () {
      return subject.complete();
    });
  }
  return subject;
};

var CompleteToken = function CompleteToken() {
  var subject = (0, _mostSubject.async)();
  return {
    listen: subject,
    complete: function complete() {
      return subject.complete();
    }
  };
};

exports.CompleteToken = CompleteToken;