
// instrument by jscoverage, do not modifly this file
(function (file, lines, conds, source) {
  var BASE;
  if (typeof global === 'object') {
    BASE = global;
  } else if (typeof window === 'object') {
    BASE = window;
  } else {
    throw new Error('[jscoverage] unknow ENV!');
  }
  if (BASE._$jscoverage) {
    BASE._$jscmd(file, 'init', lines, conds, source);
    return;
  }
  var cov = {};
  /**
   * jsc(file, 'init', lines, condtions)
   * jsc(file, 'line', lineNum)
   * jsc(file, 'cond', lineNum, expr, start, offset)
   */
  function jscmd(file, type, line, express, start, offset) {
    var storage;
    switch (type) {
      case 'init':
        if(cov[file]){
          storage = cov[file];
        } else {
          storage = [];
          for (var i = 0; i < line.length; i ++) {
            storage[line[i]] = 0;
          }
          var condition = express;
          var source = start;
          storage.condition = condition;
          storage.source = source;
        }
        cov[file] = storage;
        break;
      case 'line':
        storage = cov[file];
        storage[line] ++;
        break;
      case 'cond':
        storage = cov[file];
        storage.condition[line] ++;
        return express;
    }
  }

  BASE._$jscoverage = cov;
  BASE._$jscmd = jscmd;
  jscmd(file, 'init', lines, conds, source);
})('src/eeprom.js', [22,23,24,25,26,28,113,115,136,152,166,245,316,342,32,33,34,35,36,42,46,44,47,51,55,53,61,62,63,70,71,72,73,76,83,84,85,96,109,87,89,91,98,101,105,107,116,133,118,119,122,125,129,139,144,145,148,153,154,159,160,161,162,163,156,157,167,168,173,178,179,180,181,182,183,184,185,186,187,188,189,242,170,171,175,176,191,193,194,195,196,198,200,214,215,216,230,238,203,204,206,207,209,210,212,219,220,222,223,225,226,228,233,234,246,247,248,252,256,260,264,265,269,270,271,272,273,313,250,254,258,262,267,276,277,278,296,309,310,282,283,285,286,288,289,291,292,299,300,302,303,305,307], {"28_32_4":0,"28_39_5":0,"31_4_37":0,"41_4_33":0,"43_12_6":0,"48_12_19":0,"48_12_6":0,"48_22_9":0,"49_12_28":0,"49_12_15":0,"49_31_9":0,"49_12_4":0,"49_20_7":0,"60_4_38":0,"69_4_29":0,"71_8_5":0,"71_17_11":0,"72_8_5":0,"72_17_11":0,"73_8_3":0,"73_15_19":0,"82_4_33":0,"84_17_7":0,"86_12_7":0,"90_16_18":0,"97_12_10":0,"100_12_19":0,"106_16_11":0,"120_12_3":0,"121_16_26":0,"123_20_6":0,"126_20_6":0,"128_16_6":0,"138_12_5":0,"147_12_5":0,"155_8_25":0,"169_8_25":0,"174_8_22":0,"192_12_32":0,"197_16_13":0,"197_16_4":0,"197_24_5":0,"198_40_6":0,"198_49_11":0,"199_20_5":0,"214_52_6":0,"214_61_6":0,"215_50_9":0,"215_62_10":0,"236_24_5":0,"249_8_26":0,"253_8_23":0,"257_8_29":0,"261_8_27":0,"266_8_29":0,"275_12_38":0,"279_16_24":0,"294_16_24":0,"295_16_25":0}, ["// Functions derived from https://github.com/joyent/node/blob/master/lib/buffer.js are:","//","// Copyright Joyent, Inc. and other Node contributors. All rights reserved.","// Permission is hereby granted, free of charge, to any person obtaining a copy","// of this software and associated documentation files (the \"Software\"), to","// deal in the Software without restriction, including without limitation the","// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or","// sell copies of the Software, and to permit persons to whom the Software is","// furnished to do so, subject to the following conditions:","//","// The above copyright notice and this permission notice shall be included in","// all copies or substantial portions of the Software.","//","// THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR","// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,","// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE","// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER","// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING","// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS","// IN THE SOFTWARE.","","var fs = require('fs');","var buffer = require('buffer');","var util = require('util');","var winston = require('winston');","var bone = require('./bone');","","var debug = process.env.DEBUG ? true : false;","","// Function derived from https://github.com/joyent/node/blob/master/lib/buffer.js","if (!buffer.Buffer.prototype.readUint16BE) {","    buffer.Buffer.prototype.readUint16BE = function (offset) {","        var val = 0;","        val = this[offset] << 8;","        val |= this[offset + 1];","        return (val);","    };","}","","// Function derived from https://github.com/joyent/node/blob/master/lib/buffer.js","if (!buffer.Buffer.prototype.hexSlice) {","    var toHex = function (n) {","        if (n < 16) return '0' + n.toString(16);","        return n.toString(16);","    };","    buffer.Buffer.prototype.hexSlice = function (start, end) {","        var len = this.length;","        if (!start || start < 0) start = 0;","        if (!end || end < 0 || end > len) end = len;","","        var out = '';","        for (var i = start; i < end; i++) {","            out += toHex(this[i]);","        }","        return (out);","    };","}","","// Function derived from https://github.com/joyent/node/blob/master/lib/buffer.js","if (!buffer.Buffer.prototype.writeUint16BE) {","    buffer.Buffer.prototype.writeUint16BE = function (value, offset) {","        this[offset] = (value & 0xff00) >>> 8;","        this[offset + 1] = value & 0x00ff;","    };","}","","// Function derived from https://github.com/joyent/node/blob/master/lib/buffer.js","// fill(value, start=0, end=buffer.length)","if (!buffer.Buffer.prototype.fill) {","    buffer.Buffer.prototype.fill = function (value, start, end) {","        value || (value = 0);","        start || (start = 0);","        end || (end = this.length);","","        for (var i = start; i < end; i++) {","            this[i] = value;","        }","    };","}","","// Function derived from https://github.com/joyent/node/blob/master/lib/buffer.js","if (!buffer.Buffer.prototype.hexWrite) {","    buffer.Buffer.prototype.hexWrite = function (string, offset, length) {","        offset = +offset || 0;","        var remaining = this.length - offset;","        if (!length) {","            length = remaining;","        } else {","            length = +length;","            if (length > remaining) {","                length = remaining;","            }","        }","","        // must be an even number of digits","        var strLen = string.length;","        if (strLen % 2) {","            throw new Error('Invalid hex string');","        }","        if (length > strLen / 2) {","            length = strLen / 2;","        }","","        for (var i = 0; i < length; i++) {","            var byte = parseInt(string.substr(i * 2, 2), 16);","            if (isNaN(byte)) throw new Error('Invalid hex string');","            this[offset + i] = byte;","        }","        return i;","    };","}","","var eepromData = new buffer.Buffer(244);","","var readEeproms = function (files) {","    var data = {};","    for (var file in files) {","        var raw = fetchEepromData(file);","        var parsed = null;","        if (raw) {","            if (files[file].type == 'bone') {","                parsed = parseMainEeprom(raw);","                if (parsed) parsed.type = 'bone';","            } else {","                parsed = parseCapeEeprom(raw);","                if (parsed) parsed.type = 'cape';","            }","            if (parsed) {","                data[file] = parsed;","            }","        }","    }","    return (data);","};","","var fetchEepromData = function (address) {","    try {","        if (debug) winston.debug('Reading EEPROM at ' + address);","        var eepromFile =","            fs.openSync(","                address,","                'r'","            );","        fs.readSync(eepromFile, eepromData, 0, 244, 0);","        return (eepromData);","    } catch (ex) {","        if (debug) winston.debug('Unable to open EEPROM at ' + address + ': ' + ex);","        return (null);","    }","};","","var parseMainEeprom = function (x) {","    var data = {};","    data.header = x.hexSlice(0, 4);","    if (data.header != 'aa5533ee') {","        winston.error('Unknown EEPROM format: ' + data.header);","        return (null);","    }","    data.boardName = x.toString('ascii', 4, 12).trim().replace(/^\\x00+|\\x00+$/g, '');","    data.version = x.toString('ascii', 12, 16).trim().replace(/^\\x00+|\\x00+$/g, '');","    data.serialNumber = x.toString('ascii', 16, 28).trim().replace(/^\\x00+|\\x00+$/g, '');","    data.configOption = x.hexSlice(28, 60);","    return (data);","};","","var parseCapeEeprom = function (x) {","    var data = {};","    data.header = x.hexSlice(0, 4);","    if (data.header != 'aa5533ee') {","        winston.error('Unknown EEPROM format: ' + data.header);","        return (null);","    }","    data.formatRev = x.toString('ascii', 4, 6);","    if (data.formatRev != 'A0') {","        winston.error('Unknown EEPROM format revision: ' + data.formatRev);","        return (null);","    }","    data.boardName = x.toString('ascii', 6, 38).trim().replace(/^\\x00+|\\x00+$/g, '');","    data.version = x.toString('ascii', 38, 42).trim().replace(/^\\x00+|\\x00+$/g, '');","    data.manufacturer = x.toString('ascii', 42, 58).trim().replace(/^\\x00+|\\x00+$/g, '');","    data.partNumber = x.toString('ascii', 58, 74).trim().replace(/^\\x00+|\\x00+$/g, '');","    data.numPins = x.readUint16BE(74);","    data.serialNumber = x.toString('ascii', 76, 88).trim().replace(/^\\x00+|\\x00+$/g, '');","    data.currentVDD_3V3EXP = x.readUint16BE(236);","    data.currentVDD_5V = x.readUint16BE(238);","    data.currentSYS_5V = x.readUint16BE(240);","    data.DCSupplied = x.readUint16BE(242);","    data.mux = {};","    var pins = bone.getPinKeys(\"EEPROM\");","    for (var i = 0; i < pins.length; i++) {","        var pin = bone.getPinObject(pins[i]);","        if (typeof pin.eeprom != 'undefined') {","            var pinOffset = pin.eeprom * 2 + 88;","            var pinData = x.readUint16BE(pinOffset);","            var pinObject = {};","            var used = (pinData & 0x8000) >> 15;","            if (used || debug) {","                pinObject.used = used ? 'used' : 'available';","                if (debug) pinObject.data = x.hexSlice(pinOffset, pinOffset + 2);","                var direction = (pinData & 0x6000) >> 13;","                switch (direction) {","                case 1:","                    pinObject.direction = 'in';","                    break;","                case 2:","                    pinObject.direction = 'out';","                    break;","                case 3:","                    pinObject.direction = 'bidir';","                    break;","                default:","                    winston.error('Unknown direction value: ' + direction);","                }","                pinObject.slew = (pinData & 0x40) ? 'slow' : 'fast';","                pinObject.rx = (pinData & 0x20) ? 'enabled' : 'disabled';","                var pullup = (pinData & 0x18) >> 3;","                switch (pullup) {","                case 1:","                    pinObject.pullup = 'disabled';","                    break;","                case 2:","                    pinObject.pullup = 'pullup';","                    break;","                case 0:","                    pinObject.pullup = 'pulldown';","                    break;","                default:","                    winston.error('Unknown pullup value: ' + pullup);","                }","                pinObject.mode = (pinData & 0x0007);","                try {","                    // read mux from debugfs","                    var muxReadout = fs.readFileSync('/sys/kernel/debug/omap_mux/' + bone[pin].mux, 'ascii');","                    pinObject.function = muxReadout.split(\"\\n\")[2].split(\"|\")[pinObject.mode].replace('signals:', '').trim();","                } catch (ex) {","                    if (debug) winston.debug('Unable to read pin mux function name: ' + bone[pin].mux);","                }","                data.mux[pin] = pinObject;","            }","        }","    }","    return (data);","};","","var fillCapeEepromData = function (data) {","    eepromData.fill();","    eepromData.hexWrite('aa5533ee', 0, 4);","    eepromData.write('A0', 4, 2, 'ascii');","    if (data.boardName.length > 32) {","        data.boardName.length = 32;","    }","    eepromData.write(data.boardName, 6, 32, 'ascii');","    if (data.version.length > 4) {","        data.version.length = 4;","    }","    eepromData.write(data.version, 38, 4, 'ascii');","    if (data.manufacturer.length > 16) {","        data.manufacturer.length = 16;","    }","    eepromData.write(data.manufacturer, 42, 16, 'ascii');","    if (data.partNumber.length > 16) {","        data.partNumber.length = 16;","    }","    eepromData.write(data.partNumber, 58, 16, 'ascii');","    eepromData.writeUint16BE(data.numPins, 74, 'ascii');","    if (data.serialNumber.length > 12) {","        data.serialNumber.length = 12;","    }","    eepromData.write(data.serialNumber, 76, 12, 'ascii');","    eepromData.writeUint16BE(data.currentVDD_3V3EXP, 236);","    eepromData.writeUint16BE(data.currentVDD_5V, 238);","    eepromData.writeUint16BE(data.currentSYS_5V, 240);","    eepromData.writeUint16BE(data.DCSupplied, 242);","    for (var pin in data.mux) {","        if (typeof bone[pin].eeprom != 'undefined') {","            var pinOffset = bone[pin].eeprom * 2 + 88;","            var pinObject = data.mux[pin];","            var pinData = 0;","            if (pinObject.used == 'used') pinData |= 0x8000;","            switch (pinObject.direction) {","            case 'in':","                pinData |= 0x2000;","                break;","            case 'out':","                pinData |= 0x4000;","                break;","            case 'bidir':","                pinData |= 0x6000;","                break;","            default:","                winston.error('Unknown direction value: ' + pinObject.direction);","                pinData |= 0x2000;","            }","            if (pinObject.slew == 'slow') pinData |= 0x40;","            if (pinObject.rx == 'enabled') pinData |= 0x20;","            var pullup = (pinData & 0x18) >> 3;","            switch (pinObject.pullup) {","            case 'disabled':","                pinData |= 0x08;","                break;","            case 'pullup':","                pinData |= 0x10;","                break;","            case 'pulldown':","                break;","            default:","                winston.error('Unknown pullup value: ' + pullup);","            }","            pinData |= (pinObject.mode & 0x0007);","            eepromData.writeUint16BE(pinData, pinOffset);","        }","    }","    return (eepromData);","};","","var defaultEepromFiles = {","    '/sys/bus/i2c/drivers/at24/1-0050/eeprom': {","        type: 'bone'","    },","    '/sys/bus/i2c/drivers/at24/1-0051/eeprom': {","        type: 'bone'","    },","    '/sys/bus/i2c/drivers/at24/3-0054/eeprom': {","        type: 'cape'","    },","    '/sys/bus/i2c/drivers/at24/3-0055/eeprom': {","        type: 'cape'","    },","    '/sys/bus/i2c/drivers/at24/3-0056/eeprom': {","        type: 'cape'","    },","    '/sys/bus/i2c/drivers/at24/3-0057/eeprom': {","        type: 'cape'","    },","    'test-bone.eeprom': {","        type: 'bone'","    },","    'test-cape.eeprom': {","        type: 'cape'","    },","};","module.exports = {","    readEeproms: readEeproms,","    fillCapeEepromData: fillCapeEepromData","}"]);
// Functions derived from https://github.com/joyent/node/blob/master/lib/buffer.js are:
//
// Copyright Joyent, Inc. and other Node contributors. All rights reserved.
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
_$jscmd("src/eeprom.js", "line", 22);

var fs = require("fs");

_$jscmd("src/eeprom.js", "line", 23);

var buffer = require("buffer");

_$jscmd("src/eeprom.js", "line", 24);

var util = require("util");

_$jscmd("src/eeprom.js", "line", 25);

var winston = require("winston");

_$jscmd("src/eeprom.js", "line", 26);

var bone = require("./bone");

_$jscmd("src/eeprom.js", "line", 28);

var debug = process.env.DEBUG ? _$jscmd("src/eeprom.js", "cond", "28_32_4", true) : _$jscmd("src/eeprom.js", "cond", "28_39_5", false);

// Function derived from https://github.com/joyent/node/blob/master/lib/buffer.js
if (_$jscmd("src/eeprom.js", "cond", "31_4_37", !buffer.Buffer.prototype.readUint16BE)) {
    _$jscmd("src/eeprom.js", "line", 32);
    buffer.Buffer.prototype.readUint16BE = function(offset) {
        _$jscmd("src/eeprom.js", "line", 33);
        var val = 0;
        _$jscmd("src/eeprom.js", "line", 34);
        val = this[offset] << 8;
        _$jscmd("src/eeprom.js", "line", 35);
        val |= this[offset + 1];
        _$jscmd("src/eeprom.js", "line", 36);
        return val;
    };
}

// Function derived from https://github.com/joyent/node/blob/master/lib/buffer.js
if (_$jscmd("src/eeprom.js", "cond", "41_4_33", !buffer.Buffer.prototype.hexSlice)) {
    _$jscmd("src/eeprom.js", "line", 42);
    var toHex = function(n) {
        if (_$jscmd("src/eeprom.js", "cond", "43_12_6", n < 16)) return "0" + n.toString(16);
        _$jscmd("src/eeprom.js", "line", 44);
        return n.toString(16);
    };
    _$jscmd("src/eeprom.js", "line", 46);
    buffer.Buffer.prototype.hexSlice = function(start, end) {
        _$jscmd("src/eeprom.js", "line", 47);
        var len = this.length;
        if (_$jscmd("src/eeprom.js", "cond", "48_12_19", _$jscmd("src/eeprom.js", "cond", "48_12_6", !start) || _$jscmd("src/eeprom.js", "cond", "48_22_9", start < 0))) start = 0;
        if (_$jscmd("src/eeprom.js", "cond", "49_12_28", _$jscmd("src/eeprom.js", "cond", "49_12_15", _$jscmd("src/eeprom.js", "cond", "49_12_4", !end) || _$jscmd("src/eeprom.js", "cond", "49_20_7", end < 0)) || _$jscmd("src/eeprom.js", "cond", "49_31_9", end > len))) end = len;
        _$jscmd("src/eeprom.js", "line", 51);
        var out = "";
        for (var i = start; i < end; i++) {
            _$jscmd("src/eeprom.js", "line", 53);
            out += toHex(this[i]);
        }
        _$jscmd("src/eeprom.js", "line", 55);
        return out;
    };
}

// Function derived from https://github.com/joyent/node/blob/master/lib/buffer.js
if (_$jscmd("src/eeprom.js", "cond", "60_4_38", !buffer.Buffer.prototype.writeUint16BE)) {
    _$jscmd("src/eeprom.js", "line", 61);
    buffer.Buffer.prototype.writeUint16BE = function(value, offset) {
        _$jscmd("src/eeprom.js", "line", 62);
        this[offset] = (value & 65280) >>> 8;
        _$jscmd("src/eeprom.js", "line", 63);
        this[offset + 1] = value & 255;
    };
}

// Function derived from https://github.com/joyent/node/blob/master/lib/buffer.js
// fill(value, start=0, end=buffer.length)
if (_$jscmd("src/eeprom.js", "cond", "69_4_29", !buffer.Buffer.prototype.fill)) {
    _$jscmd("src/eeprom.js", "line", 70);
    buffer.Buffer.prototype.fill = function(value, start, end) {
        _$jscmd("src/eeprom.js", "line", 71);
        _$jscmd("src/eeprom.js", "cond", "71_8_5", value) || _$jscmd("src/eeprom.js", "cond", "71_17_11", value = 0);
        _$jscmd("src/eeprom.js", "line", 72);
        _$jscmd("src/eeprom.js", "cond", "72_8_5", start) || _$jscmd("src/eeprom.js", "cond", "72_17_11", start = 0);
        _$jscmd("src/eeprom.js", "line", 73);
        _$jscmd("src/eeprom.js", "cond", "73_8_3", end) || _$jscmd("src/eeprom.js", "cond", "73_15_19", end = this.length);
        for (var i = start; i < end; i++) {
            _$jscmd("src/eeprom.js", "line", 76);
            this[i] = value;
        }
    };
}

// Function derived from https://github.com/joyent/node/blob/master/lib/buffer.js
if (_$jscmd("src/eeprom.js", "cond", "82_4_33", !buffer.Buffer.prototype.hexWrite)) {
    _$jscmd("src/eeprom.js", "line", 83);
    buffer.Buffer.prototype.hexWrite = function(string, offset, length) {
        _$jscmd("src/eeprom.js", "line", 84);
        offset = _$jscmd("src/eeprom.js", "cond", "84_17_7", +offset) || 0;
        _$jscmd("src/eeprom.js", "line", 85);
        var remaining = this.length - offset;
        if (_$jscmd("src/eeprom.js", "cond", "86_12_7", !length)) {
            _$jscmd("src/eeprom.js", "line", 87);
            length = remaining;
        } else {
            _$jscmd("src/eeprom.js", "line", 89);
            length = +length;
            if (_$jscmd("src/eeprom.js", "cond", "90_16_18", length > remaining)) {
                _$jscmd("src/eeprom.js", "line", 91);
                length = remaining;
            }
        }
        _$jscmd("src/eeprom.js", "line", 96);
        // must be an even number of digits
        var strLen = string.length;
        if (_$jscmd("src/eeprom.js", "cond", "97_12_10", strLen % 2)) {
            _$jscmd("src/eeprom.js", "line", 98);
            throw new Error("Invalid hex string");
        }
        if (_$jscmd("src/eeprom.js", "cond", "100_12_19", length > strLen / 2)) {
            _$jscmd("src/eeprom.js", "line", 101);
            length = strLen / 2;
        }
        for (var i = 0; i < length; i++) {
            _$jscmd("src/eeprom.js", "line", 105);
            var byte = parseInt(string.substr(i * 2, 2), 16);
            if (_$jscmd("src/eeprom.js", "cond", "106_16_11", isNaN(byte))) throw new Error("Invalid hex string");
            _$jscmd("src/eeprom.js", "line", 107);
            this[offset + i] = byte;
        }
        _$jscmd("src/eeprom.js", "line", 109);
        return i;
    };
}

_$jscmd("src/eeprom.js", "line", 113);

var eepromData = new buffer.Buffer(244);

_$jscmd("src/eeprom.js", "line", 115);

var readEeproms = function(files) {
    _$jscmd("src/eeprom.js", "line", 116);
    var data = {};
    for (var file in files) {
        _$jscmd("src/eeprom.js", "line", 118);
        var raw = fetchEepromData(file);
        _$jscmd("src/eeprom.js", "line", 119);
        var parsed = null;
        if (_$jscmd("src/eeprom.js", "cond", "120_12_3", raw)) {
            if (_$jscmd("src/eeprom.js", "cond", "121_16_26", files[file].type == "bone")) {
                _$jscmd("src/eeprom.js", "line", 122);
                parsed = parseMainEeprom(raw);
                if (_$jscmd("src/eeprom.js", "cond", "123_20_6", parsed)) parsed.type = "bone";
            } else {
                _$jscmd("src/eeprom.js", "line", 125);
                parsed = parseCapeEeprom(raw);
                if (_$jscmd("src/eeprom.js", "cond", "126_20_6", parsed)) parsed.type = "cape";
            }
            if (_$jscmd("src/eeprom.js", "cond", "128_16_6", parsed)) {
                _$jscmd("src/eeprom.js", "line", 129);
                data[file] = parsed;
            }
        }
    }
    _$jscmd("src/eeprom.js", "line", 133);
    return data;
};

_$jscmd("src/eeprom.js", "line", 136);

var fetchEepromData = function(address) {
    try {
        if (_$jscmd("src/eeprom.js", "cond", "138_12_5", debug)) winston.debug("Reading EEPROM at " + address);
        _$jscmd("src/eeprom.js", "line", 139);
        var eepromFile = fs.openSync(address, "r");
        _$jscmd("src/eeprom.js", "line", 144);
        fs.readSync(eepromFile, eepromData, 0, 244, 0);
        _$jscmd("src/eeprom.js", "line", 145);
        return eepromData;
    } catch (ex) {
        if (_$jscmd("src/eeprom.js", "cond", "147_12_5", debug)) winston.debug("Unable to open EEPROM at " + address + ": " + ex);
        _$jscmd("src/eeprom.js", "line", 148);
        return null;
    }
};

_$jscmd("src/eeprom.js", "line", 152);

var parseMainEeprom = function(x) {
    _$jscmd("src/eeprom.js", "line", 153);
    var data = {};
    _$jscmd("src/eeprom.js", "line", 154);
    data.header = x.hexSlice(0, 4);
    if (_$jscmd("src/eeprom.js", "cond", "155_8_25", data.header != "aa5533ee")) {
        _$jscmd("src/eeprom.js", "line", 156);
        winston.error("Unknown EEPROM format: " + data.header);
        _$jscmd("src/eeprom.js", "line", 157);
        return null;
    }
    _$jscmd("src/eeprom.js", "line", 159);
    data.boardName = x.toString("ascii", 4, 12).trim().replace(/^\x00+|\x00+$/g, "");
    _$jscmd("src/eeprom.js", "line", 160);
    data.version = x.toString("ascii", 12, 16).trim().replace(/^\x00+|\x00+$/g, "");
    _$jscmd("src/eeprom.js", "line", 161);
    data.serialNumber = x.toString("ascii", 16, 28).trim().replace(/^\x00+|\x00+$/g, "");
    _$jscmd("src/eeprom.js", "line", 162);
    data.configOption = x.hexSlice(28, 60);
    _$jscmd("src/eeprom.js", "line", 163);
    return data;
};

_$jscmd("src/eeprom.js", "line", 166);

var parseCapeEeprom = function(x) {
    _$jscmd("src/eeprom.js", "line", 167);
    var data = {};
    _$jscmd("src/eeprom.js", "line", 168);
    data.header = x.hexSlice(0, 4);
    if (_$jscmd("src/eeprom.js", "cond", "169_8_25", data.header != "aa5533ee")) {
        _$jscmd("src/eeprom.js", "line", 170);
        winston.error("Unknown EEPROM format: " + data.header);
        _$jscmd("src/eeprom.js", "line", 171);
        return null;
    }
    _$jscmd("src/eeprom.js", "line", 173);
    data.formatRev = x.toString("ascii", 4, 6);
    if (_$jscmd("src/eeprom.js", "cond", "174_8_22", data.formatRev != "A0")) {
        _$jscmd("src/eeprom.js", "line", 175);
        winston.error("Unknown EEPROM format revision: " + data.formatRev);
        _$jscmd("src/eeprom.js", "line", 176);
        return null;
    }
    _$jscmd("src/eeprom.js", "line", 178);
    data.boardName = x.toString("ascii", 6, 38).trim().replace(/^\x00+|\x00+$/g, "");
    _$jscmd("src/eeprom.js", "line", 179);
    data.version = x.toString("ascii", 38, 42).trim().replace(/^\x00+|\x00+$/g, "");
    _$jscmd("src/eeprom.js", "line", 180);
    data.manufacturer = x.toString("ascii", 42, 58).trim().replace(/^\x00+|\x00+$/g, "");
    _$jscmd("src/eeprom.js", "line", 181);
    data.partNumber = x.toString("ascii", 58, 74).trim().replace(/^\x00+|\x00+$/g, "");
    _$jscmd("src/eeprom.js", "line", 182);
    data.numPins = x.readUint16BE(74);
    _$jscmd("src/eeprom.js", "line", 183);
    data.serialNumber = x.toString("ascii", 76, 88).trim().replace(/^\x00+|\x00+$/g, "");
    _$jscmd("src/eeprom.js", "line", 184);
    data.currentVDD_3V3EXP = x.readUint16BE(236);
    _$jscmd("src/eeprom.js", "line", 185);
    data.currentVDD_5V = x.readUint16BE(238);
    _$jscmd("src/eeprom.js", "line", 186);
    data.currentSYS_5V = x.readUint16BE(240);
    _$jscmd("src/eeprom.js", "line", 187);
    data.DCSupplied = x.readUint16BE(242);
    _$jscmd("src/eeprom.js", "line", 188);
    data.mux = {};
    _$jscmd("src/eeprom.js", "line", 189);
    var pins = bone.getPinKeys("EEPROM");
    for (var i = 0; i < pins.length; i++) {
        _$jscmd("src/eeprom.js", "line", 191);
        var pin = bone.getPinObject(pins[i]);
        if (_$jscmd("src/eeprom.js", "cond", "192_12_32", typeof pin.eeprom != "undefined")) {
            _$jscmd("src/eeprom.js", "line", 193);
            var pinOffset = pin.eeprom * 2 + 88;
            _$jscmd("src/eeprom.js", "line", 194);
            var pinData = x.readUint16BE(pinOffset);
            _$jscmd("src/eeprom.js", "line", 195);
            var pinObject = {};
            _$jscmd("src/eeprom.js", "line", 196);
            var used = (pinData & 32768) >> 15;
            if (_$jscmd("src/eeprom.js", "cond", "197_16_13", _$jscmd("src/eeprom.js", "cond", "197_16_4", used) || _$jscmd("src/eeprom.js", "cond", "197_24_5", debug))) {
                _$jscmd("src/eeprom.js", "line", 198);
                pinObject.used = used ? _$jscmd("src/eeprom.js", "cond", "198_40_6", "used") : _$jscmd("src/eeprom.js", "cond", "198_49_11", "available");
                if (_$jscmd("src/eeprom.js", "cond", "199_20_5", debug)) pinObject.data = x.hexSlice(pinOffset, pinOffset + 2);
                _$jscmd("src/eeprom.js", "line", 200);
                var direction = (pinData & 24576) >> 13;
                switch (direction) {
                  case 1:
                    _$jscmd("src/eeprom.js", "line", 203);
                    pinObject.direction = "in";
                    _$jscmd("src/eeprom.js", "line", 204);
                    break;

                  case 2:
                    _$jscmd("src/eeprom.js", "line", 206);
                    pinObject.direction = "out";
                    _$jscmd("src/eeprom.js", "line", 207);
                    break;

                  case 3:
                    _$jscmd("src/eeprom.js", "line", 209);
                    pinObject.direction = "bidir";
                    _$jscmd("src/eeprom.js", "line", 210);
                    break;

                  default:
                    _$jscmd("src/eeprom.js", "line", 212);
                    winston.error("Unknown direction value: " + direction);
                }
                _$jscmd("src/eeprom.js", "line", 214);
                pinObject.slew = pinData & 64 ? _$jscmd("src/eeprom.js", "cond", "214_52_6", "slow") : _$jscmd("src/eeprom.js", "cond", "214_61_6", "fast");
                _$jscmd("src/eeprom.js", "line", 215);
                pinObject.rx = pinData & 32 ? _$jscmd("src/eeprom.js", "cond", "215_50_9", "enabled") : _$jscmd("src/eeprom.js", "cond", "215_62_10", "disabled");
                _$jscmd("src/eeprom.js", "line", 216);
                var pullup = (pinData & 24) >> 3;
                switch (pullup) {
                  case 1:
                    _$jscmd("src/eeprom.js", "line", 219);
                    pinObject.pullup = "disabled";
                    _$jscmd("src/eeprom.js", "line", 220);
                    break;

                  case 2:
                    _$jscmd("src/eeprom.js", "line", 222);
                    pinObject.pullup = "pullup";
                    _$jscmd("src/eeprom.js", "line", 223);
                    break;

                  case 0:
                    _$jscmd("src/eeprom.js", "line", 225);
                    pinObject.pullup = "pulldown";
                    _$jscmd("src/eeprom.js", "line", 226);
                    break;

                  default:
                    _$jscmd("src/eeprom.js", "line", 228);
                    winston.error("Unknown pullup value: " + pullup);
                }
                _$jscmd("src/eeprom.js", "line", 230);
                pinObject.mode = pinData & 7;
                try {
                    _$jscmd("src/eeprom.js", "line", 233);
                    // read mux from debugfs
                    var muxReadout = fs.readFileSync("/sys/kernel/debug/omap_mux/" + bone[pin].mux, "ascii");
                    _$jscmd("src/eeprom.js", "line", 234);
                    pinObject.function = muxReadout.split("\n")[2].split("|")[pinObject.mode].replace("signals:", "").trim();
                } catch (ex) {
                    if (_$jscmd("src/eeprom.js", "cond", "236_24_5", debug)) winston.debug("Unable to read pin mux function name: " + bone[pin].mux);
                }
                _$jscmd("src/eeprom.js", "line", 238);
                data.mux[pin] = pinObject;
            }
        }
    }
    _$jscmd("src/eeprom.js", "line", 242);
    return data;
};

_$jscmd("src/eeprom.js", "line", 245);

var fillCapeEepromData = function(data) {
    _$jscmd("src/eeprom.js", "line", 246);
    eepromData.fill();
    _$jscmd("src/eeprom.js", "line", 247);
    eepromData.hexWrite("aa5533ee", 0, 4);
    _$jscmd("src/eeprom.js", "line", 248);
    eepromData.write("A0", 4, 2, "ascii");
    if (_$jscmd("src/eeprom.js", "cond", "249_8_26", data.boardName.length > 32)) {
        _$jscmd("src/eeprom.js", "line", 250);
        data.boardName.length = 32;
    }
    _$jscmd("src/eeprom.js", "line", 252);
    eepromData.write(data.boardName, 6, 32, "ascii");
    if (_$jscmd("src/eeprom.js", "cond", "253_8_23", data.version.length > 4)) {
        _$jscmd("src/eeprom.js", "line", 254);
        data.version.length = 4;
    }
    _$jscmd("src/eeprom.js", "line", 256);
    eepromData.write(data.version, 38, 4, "ascii");
    if (_$jscmd("src/eeprom.js", "cond", "257_8_29", data.manufacturer.length > 16)) {
        _$jscmd("src/eeprom.js", "line", 258);
        data.manufacturer.length = 16;
    }
    _$jscmd("src/eeprom.js", "line", 260);
    eepromData.write(data.manufacturer, 42, 16, "ascii");
    if (_$jscmd("src/eeprom.js", "cond", "261_8_27", data.partNumber.length > 16)) {
        _$jscmd("src/eeprom.js", "line", 262);
        data.partNumber.length = 16;
    }
    _$jscmd("src/eeprom.js", "line", 264);
    eepromData.write(data.partNumber, 58, 16, "ascii");
    _$jscmd("src/eeprom.js", "line", 265);
    eepromData.writeUint16BE(data.numPins, 74, "ascii");
    if (_$jscmd("src/eeprom.js", "cond", "266_8_29", data.serialNumber.length > 12)) {
        _$jscmd("src/eeprom.js", "line", 267);
        data.serialNumber.length = 12;
    }
    _$jscmd("src/eeprom.js", "line", 269);
    eepromData.write(data.serialNumber, 76, 12, "ascii");
    _$jscmd("src/eeprom.js", "line", 270);
    eepromData.writeUint16BE(data.currentVDD_3V3EXP, 236);
    _$jscmd("src/eeprom.js", "line", 271);
    eepromData.writeUint16BE(data.currentVDD_5V, 238);
    _$jscmd("src/eeprom.js", "line", 272);
    eepromData.writeUint16BE(data.currentSYS_5V, 240);
    _$jscmd("src/eeprom.js", "line", 273);
    eepromData.writeUint16BE(data.DCSupplied, 242);
    for (var pin in data.mux) {
        if (_$jscmd("src/eeprom.js", "cond", "275_12_38", typeof bone[pin].eeprom != "undefined")) {
            _$jscmd("src/eeprom.js", "line", 276);
            var pinOffset = bone[pin].eeprom * 2 + 88;
            _$jscmd("src/eeprom.js", "line", 277);
            var pinObject = data.mux[pin];
            _$jscmd("src/eeprom.js", "line", 278);
            var pinData = 0;
            if (_$jscmd("src/eeprom.js", "cond", "279_16_24", pinObject.used == "used")) pinData |= 32768;
            switch (pinObject.direction) {
              case "in":
                _$jscmd("src/eeprom.js", "line", 282);
                pinData |= 8192;
                _$jscmd("src/eeprom.js", "line", 283);
                break;

              case "out":
                _$jscmd("src/eeprom.js", "line", 285);
                pinData |= 16384;
                _$jscmd("src/eeprom.js", "line", 286);
                break;

              case "bidir":
                _$jscmd("src/eeprom.js", "line", 288);
                pinData |= 24576;
                _$jscmd("src/eeprom.js", "line", 289);
                break;

              default:
                _$jscmd("src/eeprom.js", "line", 291);
                winston.error("Unknown direction value: " + pinObject.direction);
                _$jscmd("src/eeprom.js", "line", 292);
                pinData |= 8192;
            }
            if (_$jscmd("src/eeprom.js", "cond", "294_16_24", pinObject.slew == "slow")) pinData |= 64;
            if (_$jscmd("src/eeprom.js", "cond", "295_16_25", pinObject.rx == "enabled")) pinData |= 32;
            _$jscmd("src/eeprom.js", "line", 296);
            var pullup = (pinData & 24) >> 3;
            switch (pinObject.pullup) {
              case "disabled":
                _$jscmd("src/eeprom.js", "line", 299);
                pinData |= 8;
                _$jscmd("src/eeprom.js", "line", 300);
                break;

              case "pullup":
                _$jscmd("src/eeprom.js", "line", 302);
                pinData |= 16;
                _$jscmd("src/eeprom.js", "line", 303);
                break;

              case "pulldown":
                _$jscmd("src/eeprom.js", "line", 305);
                break;

              default:
                _$jscmd("src/eeprom.js", "line", 307);
                winston.error("Unknown pullup value: " + pullup);
            }
            _$jscmd("src/eeprom.js", "line", 309);
            pinData |= pinObject.mode & 7;
            _$jscmd("src/eeprom.js", "line", 310);
            eepromData.writeUint16BE(pinData, pinOffset);
        }
    }
    _$jscmd("src/eeprom.js", "line", 313);
    return eepromData;
};

_$jscmd("src/eeprom.js", "line", 316);

var defaultEepromFiles = {
    "/sys/bus/i2c/drivers/at24/1-0050/eeprom": {
        type: "bone"
    },
    "/sys/bus/i2c/drivers/at24/1-0051/eeprom": {
        type: "bone"
    },
    "/sys/bus/i2c/drivers/at24/3-0054/eeprom": {
        type: "cape"
    },
    "/sys/bus/i2c/drivers/at24/3-0055/eeprom": {
        type: "cape"
    },
    "/sys/bus/i2c/drivers/at24/3-0056/eeprom": {
        type: "cape"
    },
    "/sys/bus/i2c/drivers/at24/3-0057/eeprom": {
        type: "cape"
    },
    "test-bone.eeprom": {
        type: "bone"
    },
    "test-cape.eeprom": {
        type: "cape"
    }
};

_$jscmd("src/eeprom.js", "line", 342);

module.exports = {
    readEeproms: readEeproms,
    fillCapeEepromData: fillCapeEepromData
};