
// instrument by jscoverage, do not modifly this file
(function (file, lines, conds, source) {
  var BASE;
  if (typeof global === 'object') {
    BASE = global;
  } else if (typeof window === 'object') {
    BASE = window;
  } else {
    throw new Error('[jscoverage] unknow ENV!');
  }
  if (BASE._$jscoverage) {
    BASE._$jscmd(file, 'init', lines, conds, source);
    return;
  }
  var cov = {};
  /**
   * jsc(file, 'init', lines, condtions)
   * jsc(file, 'line', lineNum)
   * jsc(file, 'cond', lineNum, expr, start, offset)
   */
  function jscmd(file, type, line, express, start, offset) {
    var storage;
    switch (type) {
      case 'init':
        if(cov[file]){
          storage = cov[file];
        } else {
          storage = [];
          for (var i = 0; i < line.length; i ++) {
            storage[line[i]] = 0;
          }
          var condition = express;
          var source = start;
          storage.condition = condition;
          storage.source = source;
        }
        cov[file] = storage;
        break;
      case 'line':
        storage = cov[file];
        storage[line] ++;
        break;
      case 'cond':
        storage = cov[file];
        storage.condition[line] ++;
        return express;
    }
  }

  BASE._$jscoverage = cov;
  BASE._$jscmd = jscmd;
  jscmd(file, 'init', lines, conds, source);
})('src/hw_capemgr.js', [1,2,3,4,6,8,9,10,12,14,25,37,70,182,196,278,301,319,338,365,376,396,410,434,15,22,17,18,19,20,26,27,34,29,30,31,32,38,39,40,49,67,46,47,42,44,51,54,58,61,62,179,74,76,77,80,84,85,88,89,92,94,95,102,103,107,108,109,110,111,113,114,125,122,123,130,131,134,136,146,141,143,144,156,151,153,154,165,166,160,162,163,175,172,183,193,186,188,189,190,198,203,275,200,201,206,211,214,217,218,220,222,229,233,241,251,252,254,258,272,263,265,267,280,282,283,286,291,294,296,302,315,316,304,312,313,309,310,306,307,320,335,322,324,326,331,339,352,357,362,341,349,350,346,347,343,344,354,355,359,360,366,368,369,370,371,373,378,393,380,381,382,388,385,390,391,397,399,401,403,404,405,406,407,411,416,428,431,419,420,422,423,425,426], {"6_32_4":0,"6_39_5":0,"28_8_33":0,"41_12_3":0,"43_16_5":0,"50_12_6":0,"53_16_5":0,"57_8_8":0,"64_16_5":0,"71_8_5":0,"72_8_5":0,"73_8_18":0,"75_12_8":0,"79_12_7":0,"82_15_19":0,"83_12_8":0,"87_12_25":0,"93_12_8":0,"101_8_37":0,"105_8_19":0,"121_12_8":0,"129_12_8":0,"133_12_19":0,"140_16_7":0,"142_20_5":0,"150_16_12":0,"152_20_5":0,"159_20_10":0,"161_24_5":0,"171_16_3":0,"173_20_5":0,"185_8_24":0,"197_8_5":0,"199_8_8":0,"204_8_6":0,"205_12_5":0,"210_16_5":0,"212_16_5":0,"219_16_5":0,"227_12_6":0,"228_16_5":0,"232_16_5":0,"238_12_3":0,"239_12_5":0,"246_12_3":0,"253_12_5":0,"262_12_4":0,"266_20_14":0,"266_20_1":0,"266_25_9":0,"268_24_5":0,"279_8_39":0,"281_12_7":0,"285_12_38":0,"289_8_5":0,"290_8_8":0,"303_8_8":0,"305_16_3":0,"321_8_27":0,"323_12_3":0,"325_16_6":0,"330_8_8":0,"340_8_8":0,"342_16_3":0,"353_8_17":0,"358_8_17":0,"377_8_5":0,"383_12_16":0,"384_16_5":0,"387_12_5":0,"413_8_27":0,"414_8_27":0,"415_8_27":0,"418_8_27":0,"421_15_29":0,"424_15_29":0,"427_15_41":0,"430_8_46":0}, ["var fs = require('fs');","var winston = require('winston');","var my = require('./my');","var parse = require('./parse');","","var debug = process.env.DEBUG ? true : false;","","var gpioFile = {};","var pwmPrefix = {};","var ainPrefix = \"\";","","var logfile = '/var/lib/cloud9/bonescript.log';","","var readPWMFreqAndValue = function (pin, pwm) {","    var mode = {};","    try {","        var period = fs.readFileSync(pwmPrefix[pin.pwm.name] + '/period');","        var duty = fs.readFileSync(pwmPrefix[pin.pwm.name] + '/duty');","        mode.freq = 1.0e9 / period;","        mode.value = duty / period;","    } catch (ex) {}","    return (mode);","};","","var readGPIODirection = function (n, gpio) {","    var mode = {};","    var directionFile = \"/sys/class/gpio/gpio\" + n + \"/direction\";","    if (my.file_existsSync(directionFile)) {","        mode.active = true;","        var direction = fs.readFileSync(directionFile, 'utf-8');","        direction = direction.replace(/^\\s+|\\s+$/g, '');","        mode.direction = direction;","    }","    return (mode);","};","","var readPinMux = function (pin, mode, callback) {","    var pinctrlFile = '/sys/kernel/debug/pinctrl/44e10800.pinmux/pins';","    var muxRegOffset = parseInt(pin.muxRegOffset, 16);","    var readPinctrl = function (err, data) {","        if (err) {","            mode.err = 'readPinctrl error: ' + err;","            if (debug) winston.debug(mode.err);","            callback(mode);","        }","        mode = parse.modeFromPinctrl(data, muxRegOffset, 0x44e10800, mode);","        callback(mode);","    };","    var tryPinctrl = function (exists) {","        if (exists) {","            fs.readFile(pinctrlFile, 'utf8', readPinctrl);","        } else {","            if (debug) winston.debug('getPinMode(' + pin.key + '): no valid mux data');","            callback(mode);","        }","    };","    if (callback) {","        my.file_exists(pinctrlFile, tryPinctrl);","    } else {","        try {","            var data2 = fs.readFileSync(pinctrlFile, 'utf8');","            mode = parse.modeFromPinctrl(data2, muxRegOffset, 0x44e10800, mode);","        } catch (ex) {","            if (debug) winston.debug('getPinMode(' + pin.key + '): ' + ex);","        }","    }","    return (mode);","};","","var setPinMode = function (pin, pinData, template, resp, callback) {","    if (debug) winston.debug('hw.setPinMode(' + [pin.key, pinData, template, JSON.stringify(resp)] + ');');","    if (debug) winston.debug('typeof callack = ' + typeof callback);","    if (template == 'bspm') {","        gpioFile[pin.key] = '/sys/class/gpio/gpio' + pin.gpio + '/value';","        if (callback) {","            doCreateDT(resp);","            return (resp);","        }","        if (pin.led) {","            gpioFile[pin.key] = '/sys/class/leds/beaglebone::' + pin.led + '/brightness';","        }","    } else if (template == 'bspwm') {","        if (callback) {","            my.load_dt('am33xx_pwm', null, resp, doCreateDT);","            return (resp);","        }","        if (!my.load_dt('am33xx_pwm')) {","            resp.err = 'Error loading am33xx_pwm devicetree overlay';","            return (resp);","        }","    } else {","        resp.err = 'Unknown pin mode template';","        if (callback) {","            callback(resp);","            return (resp);","        }","    }","","    // only synchronous stuff at this point","","    if (!my.create_dt(pin, pinData, template)) {","        resp.err = 'Error loading devicetree overlay for ' + pin.key + ' using template ' + template;","        return (resp);","    }","    if (template == 'bspwm') {","        try {","            var ocp = my.is_ocp();","            var p = 'bs_pwm_test_' + pin.key;","            var pwm_test = my.find_sysfsFile(p, ocp, p + '.');","            pwmPrefix[pin.pwm.name] = pwm_test;","            fs.writeFileSync(pwm_test + '/polarity', 0);","        } catch (ex) {","            resp.err = 'Error enabling PWM controls: ' + ex;","            winston.error(resp.err);","        }","    }","","    // now to define the asynchronous calls","","    function doCreateDT(resp) {","        if (resp.err) {","            callback(resp);","            return;","        }","        my.create_dt(pin, pinData, template, true, false, resp, onCreateDT);","    }","","    function onCreateDT(resp) {","        if (resp.err) {","            callback(resp);","            return;","        }","        if (template == 'bspwm') {","            my.file_find('/sys/devices', 'ocp.', 1, onFindOCP);","        } else {","            callback(resp);","        }","","        function onFindOCP(ocp) {","            if (ocp.err) {","                resp.err = \"Error searching for ocp: \" + ocp.err;","                if (debug) winston.debug(resp.err);","                callback(resp);","                return;","            }","            my.file_find(ocp.path, 'bs_pwm_test_' + pin.key + '.', 1, onFindPWM);","        }","","        function onFindPWM(pwm_test) {","            if (pwm_test.err) {","                resp.err = \"Error searching for pwm_test: \" + pwm_test.err;","                if (debug) winston.debug(resp.err);","                callback(resp);","                return;","            }","            my.file_find(pwm_test.path, 'period', 1, onFindPeriod);","","            function onFindPeriod(period) {","                if (period.err) {","                    resp.err = \"Error searching for period: \" + period.err;","                    if (debug) winston.debug(resp.err);","                    callback(resp);","                    return;","                }","                pwmPrefix[pin.pwm.name] = pwm_test.path;","                fs.writeFile(pwm_test.path + '/polarity', 0, 'ascii', onPolarityWrite);","            }","        }","","        function onPolarityWrite(err) {","            if (err) {","                resp.err = \"Error writing PWM polarity: \" + err;","                if (debug) winston.debug(resp.err);","            }","            callback(resp);","        }","    }","","    return (resp);","};","","var setLEDPinToGPIO = function (pin, resp) {","    var path = \"/sys/class/leds/beaglebone:green:\" + pin.led + \"/trigger\";","","    if (my.file_existsSync(path)) {","        fs.writeFileSync(path, \"gpio\");","    } else {","        resp.err = \"Unable to find LED \" + pin.led;","        winston.error(resp.err);","        resp.value = false;","    }","","    return (resp);","};","","var exportGPIOControls = function (pin, direction, resp, callback) {","    if (debug) winston.debug('hw.exportGPIOControls(' + [pin.key, direction, resp] + ');');","    var n = pin.gpio;","    if (callback) {","        my.file_exists(gpioFile[pin.key], onFileExists);","        return;","    }","    var exists = my.file_existsSync(gpioFile[pin.key]);","    if (exists) {","        if (debug) winston.debug(\"gpio: \" + n + \" already exported.\");","        fs.writeFileSync(\"/sys/class/gpio/gpio\" + n + \"/direction\",","            direction, null);","    } else {","        try {","            if (debug) winston.debug(\"exporting gpio: \" + n);","            fs.writeFileSync(\"/sys/class/gpio/export\", \"\" + n, null);","            if (debug) winston.debug(\"setting gpio \" + n +","                \" direction to \" + direction);","            fs.writeFileSync(\"/sys/class/gpio/gpio\" + n + \"/direction\",","                direction, null);","        } catch (ex2) {","            resp.value = false;","            resp.err = 'Unable to export gpio-' + n + ': ' + ex2;","            if (debug) winston.debug(resp.err);","            var gpioUsers =","                fs.readFileSync('/sys/kernel/debug/gpio', 'utf-8');","            gpioUsers = gpioUsers.split('\\n');","        }","    }","","    function onFileExists(exists) {","        if (exists) {","            if (debug) winston.debug(\"gpio: \" + n + \" already exported.\");","            fs.writeFile(\"/sys/class/gpio/gpio\" + n + \"/direction\",","                direction, null, onGPIODirectionSet);","        } else {","            if (debug) winston.debug(\"exporting gpio: \" + n);","            fs.writeFile(\"/sys/class/gpio/export\", \"\" + n, null, onGPIOExport);","        }","    }","","    function onGPIOExport(err) {","        if (err) onError(err);","        if (debug) winston.debug(\"setting gpio \" + n +","            \" direction to \" + direction);","        fs.writeFile(\"/sys/class/gpio/gpio\" + n + \"/direction\",","            direction, null, onGPIODirectionSet);","    }","","    function onGPIODirectionSet(err) {","        if (err) onError(err);","        else callback(resp);","    }","","    function onError(err) {","        resp.err = 'Unable to export gpio-' + n + ': ' + err;","        resp.value = false;","        if (debug) winston.debug(resp.err);","        findOwner();","    }","","    function findOwner() {","        fs.readFile('/sys/kernel/debug/gpio', 'utf-8', onGPIOUsers);","    }","","    function onGPIOUsers(err, data) {","        if (!err) {","            var gpioUsers = data.split('\\n');","            for (var x in gpioUsers) {","                var y = gpioUsers[x].match(/gpio-(\\d+)\\s+\\((\\S+)\\s*\\)/);","                if (y && y[1] == n) {","                    resp.err += '\\nconsumed by ' + y[2];","                    if (debug) winston.debug(resp.err);","                }","            }","        }","        callback(resp);","    }","","    return (resp);","};","","var writeGPIOValue = function (pin, value, callback) {","    if (typeof gpioFile[pin.key] == 'undefined') {","        gpioFile[pin.key] = '/sys/class/gpio/gpio' + pin.gpio + '/value';","        if (pin.led) {","            gpioFile[pin.key] = \"/sys/class/leds/beaglebone:\";","            gpioFile[pin.key] += \"green:\" + pin.led + \"/brightness\";","        }","        if (!my.file_existsSync(gpioFile[pin.key])) {","            winston.error(\"Unable to find gpio: \" + gpioFile[pin.key]);","        }","    }","    if (debug) winston.debug(\"gpioFile = \" + gpioFile[pin.key]);","    if (callback) {","        fs.writeFile(gpioFile[pin.key], '' + value, null, callback);","    } else {","        try {","            fs.writeFileSync(gpioFile[pin.key], '' + value, null);","        } catch (ex) {","            winston.error(\"Unable to write to \" + gpioFile[pin.key]);","        }","    }","};","","var readGPIOValue = function (pin, resp, callback) {","    var gpioFile = '/sys/class/gpio/gpio' + pin.gpio + '/value';","    if (callback) {","        var readFile = function (err, data) {","            if (err) {","                resp.err = 'digitalRead error: ' + err;","                winston.error(resp.err);","            }","            resp.value = parseInt(data, 2);","            callback(resp);","        };","        fs.readFile(gpioFile, readFile);","        return (true);","    }","    resp.value = parseInt(fs.readFileSync(gpioFile), 2);","    return (resp);","};","","var enableAIN = function (callback) {","    var helper = \"\";","    if (my.load_dt('cape-bone-iio')) {","        var ocp = my.is_ocp();","        if (ocp) {","            helper = my.find_sysfsFile('helper', ocp, 'helper.');","            if (helper) {","                ainPrefix = helper + '/AIN';","            }","        }","    }","    if (callback) {","        callback({","            'path': helper","        })","    }","    return (helper.length > 1);","};","","var readAIN = function (pin, resp, callback) {","    var ainFile = ainPrefix + pin.ain.toString();","    if (callback) {","        var readFile = function (err, data) {","            if (err) {","                resp.err = 'analogRead error: ' + err;","                winston.error(resp.err);","            }","            resp.value = parseInt(data, 10) / 1800;","            callback(resp);","        };","        fs.readFile(ainFile, readFile);","        return (resp);","    }","    resp.value = parseInt(fs.readFileSync(ainFile), 10);","    if (isNaN(resp.value)) {","        resp.err = 'analogRead(' + pin.key + ') returned ' + resp.value;","        winston.error(resp.err);","    }","    resp.value = resp.value / 1800;","    if (isNaN(resp.value)) {","        resp.err = 'analogRead(' + pin.key + ') scaled to ' + resp.value;","        winston.error(resp.err);","    }","    return (resp);","};","","var writeGPIOEdge = function (pin, mode) {","    fs.writeFileSync('/sys/class/gpio/gpio' + pin.gpio + '/edge', mode);","","    var resp = {};","    resp.gpioFile = '/sys/class/gpio/gpio' + pin.gpio + '/value';","    resp.valuefd = fs.openSync(resp.gpioFile, 'r');","    resp.value = new Buffer(1);","","    return (resp);","};","","var writePWMFreqAndValue = function (pin, pwm, freq, value, resp, callback) {","    if (debug) winston.debug('hw.writePWMFreqAndValue(' + [pin.key, pwm, freq, value, resp] + ');');","    var path = pwmPrefix[pin.pwm.name];","    try {","        var period = Math.round(1.0e9 / freq); // period in ns","        var duty = Math.round(period * value);","        fs.writeFileSync(path + '/duty', 0);","        if (pwm.freq != freq) {","            if (debug) winston.debug('Updating PWM period: ' + period);","            fs.writeFileSync(path + '/period', period);","        }","        if (debug) winston.debug('Updating PWM duty: ' + duty);","        fs.writeFileSync(path + '/duty', duty);","    } catch (ex) {","        resp.err = 'error updating PWM freq and value: ' + path + ', ' + ex;","        winston.error(resp.err);","    }","    return (resp);","};","","var readEeproms = function (eeproms) {","    var boardName = fs.readFileSync(my.is_capemgr() + '/baseboard/board-name',","        'ascii');","    var version = fs.readFileSync(my.is_capemgr() + '/baseboard/revision',","        'ascii');","    var serialNumber = fs.readFileSync(my.is_capemgr() + '/baseboard/serial-number',","        'ascii');","    eeproms['/sys/bus/i2c/drivers/at24/1-0050/eeprom'] = {};","    eeproms['/sys/bus/i2c/drivers/at24/1-0050/eeprom'].boardName = boardName;","    eeproms['/sys/bus/i2c/drivers/at24/1-0050/eeprom'].version = version;","    eeproms['/sys/bus/i2c/drivers/at24/1-0050/eeprom'].serialNumber = serialNumber;","    return (eeproms);","};","","var readPlatform = function (platform) {","    platform.name = fs.readFileSync(my.is_capemgr() + '/baseboard/board-name',","        'ascii').trim();","    if (platform.name == 'A335BONE') platform.name = 'BeagleBone';","    if (platform.name == 'A335BNLT') platform.name = 'BeagleBone Black';","    if (platform.name == 'A335PBGL') platform.name = 'PocketBeagle';","    platform.version = fs.readFileSync(my.is_capemgr() + '/baseboard/revision',","        'ascii').trim();","    if (platform.version[0] == 0x1A) {","        platform.version = '1A';","        platform.name = 'BeagleBone Green';","    } else if (platform.version.match(/^GR/)) {","        platform.version = platform.version.substr(2);","        platform.name = 'BeagleBone Green';","    } else if (platform.version.match(/^BL/)) {","        platform.version = platform.version.substr(2);","        platform.name = 'BeagleBone Blue';","    } else if (!platform.version.match(/^[\\040-\\176]*$/)) delete platform.version;","    platform.serialNumber = fs.readFileSync(my.is_capemgr() +","        '/baseboard/serial-number', 'ascii').trim();","    if (!platform.serialNumber.match(/^[\\040-\\176]*$/)) delete platform.serialNumber;","    return (platform);","};","","module.exports = {","    logfile: logfile,","    readPWMFreqAndValue: readPWMFreqAndValue,","    readGPIODirection: readGPIODirection,","    readPinMux: readPinMux,","    setPinMode: setPinMode,","    setLEDPinToGPIO: setLEDPinToGPIO,","    exportGPIOControls: exportGPIOControls,","    writeGPIOValue: writeGPIOValue,","    readGPIOValue: readGPIOValue,","    enableAIN: enableAIN,","    readAIN: readAIN,","    writeGPIOEdge: writeGPIOEdge,","    writePWMFreqAndValue: writePWMFreqAndValue,","    readEeproms: readEeproms,","    readPlatform: readPlatform,","}"]);
_$jscmd("src/hw_capemgr.js", "line", 1);

var fs = require("fs");

_$jscmd("src/hw_capemgr.js", "line", 2);

var winston = require("winston");

_$jscmd("src/hw_capemgr.js", "line", 3);

var my = require("./my");

_$jscmd("src/hw_capemgr.js", "line", 4);

var parse = require("./parse");

_$jscmd("src/hw_capemgr.js", "line", 6);

var debug = process.env.DEBUG ? _$jscmd("src/hw_capemgr.js", "cond", "6_32_4", true) : _$jscmd("src/hw_capemgr.js", "cond", "6_39_5", false);

_$jscmd("src/hw_capemgr.js", "line", 8);

var gpioFile = {};

_$jscmd("src/hw_capemgr.js", "line", 9);

var pwmPrefix = {};

_$jscmd("src/hw_capemgr.js", "line", 10);

var ainPrefix = "";

_$jscmd("src/hw_capemgr.js", "line", 12);

var logfile = "/var/lib/cloud9/bonescript.log";

_$jscmd("src/hw_capemgr.js", "line", 14);

var readPWMFreqAndValue = function(pin, pwm) {
    _$jscmd("src/hw_capemgr.js", "line", 15);
    var mode = {};
    try {
        _$jscmd("src/hw_capemgr.js", "line", 17);
        var period = fs.readFileSync(pwmPrefix[pin.pwm.name] + "/period");
        _$jscmd("src/hw_capemgr.js", "line", 18);
        var duty = fs.readFileSync(pwmPrefix[pin.pwm.name] + "/duty");
        _$jscmd("src/hw_capemgr.js", "line", 19);
        mode.freq = 1e9 / period;
        _$jscmd("src/hw_capemgr.js", "line", 20);
        mode.value = duty / period;
    } catch (ex) {}
    _$jscmd("src/hw_capemgr.js", "line", 22);
    return mode;
};

_$jscmd("src/hw_capemgr.js", "line", 25);

var readGPIODirection = function(n, gpio) {
    _$jscmd("src/hw_capemgr.js", "line", 26);
    var mode = {};
    _$jscmd("src/hw_capemgr.js", "line", 27);
    var directionFile = "/sys/class/gpio/gpio" + n + "/direction";
    if (_$jscmd("src/hw_capemgr.js", "cond", "28_8_33", my.file_existsSync(directionFile))) {
        _$jscmd("src/hw_capemgr.js", "line", 29);
        mode.active = true;
        _$jscmd("src/hw_capemgr.js", "line", 30);
        var direction = fs.readFileSync(directionFile, "utf-8");
        _$jscmd("src/hw_capemgr.js", "line", 31);
        direction = direction.replace(/^\s+|\s+$/g, "");
        _$jscmd("src/hw_capemgr.js", "line", 32);
        mode.direction = direction;
    }
    _$jscmd("src/hw_capemgr.js", "line", 34);
    return mode;
};

_$jscmd("src/hw_capemgr.js", "line", 37);

var readPinMux = function(pin, mode, callback) {
    _$jscmd("src/hw_capemgr.js", "line", 38);
    var pinctrlFile = "/sys/kernel/debug/pinctrl/44e10800.pinmux/pins";
    _$jscmd("src/hw_capemgr.js", "line", 39);
    var muxRegOffset = parseInt(pin.muxRegOffset, 16);
    _$jscmd("src/hw_capemgr.js", "line", 40);
    var readPinctrl = function(err, data) {
        if (_$jscmd("src/hw_capemgr.js", "cond", "41_12_3", err)) {
            _$jscmd("src/hw_capemgr.js", "line", 42);
            mode.err = "readPinctrl error: " + err;
            if (_$jscmd("src/hw_capemgr.js", "cond", "43_16_5", debug)) winston.debug(mode.err);
            _$jscmd("src/hw_capemgr.js", "line", 44);
            callback(mode);
        }
        _$jscmd("src/hw_capemgr.js", "line", 46);
        mode = parse.modeFromPinctrl(data, muxRegOffset, 1155598336, mode);
        _$jscmd("src/hw_capemgr.js", "line", 47);
        callback(mode);
    };
    _$jscmd("src/hw_capemgr.js", "line", 49);
    var tryPinctrl = function(exists) {
        if (_$jscmd("src/hw_capemgr.js", "cond", "50_12_6", exists)) {
            _$jscmd("src/hw_capemgr.js", "line", 51);
            fs.readFile(pinctrlFile, "utf8", readPinctrl);
        } else {
            if (_$jscmd("src/hw_capemgr.js", "cond", "53_16_5", debug)) winston.debug("getPinMode(" + pin.key + "): no valid mux data");
            _$jscmd("src/hw_capemgr.js", "line", 54);
            callback(mode);
        }
    };
    if (_$jscmd("src/hw_capemgr.js", "cond", "57_8_8", callback)) {
        _$jscmd("src/hw_capemgr.js", "line", 58);
        my.file_exists(pinctrlFile, tryPinctrl);
    } else {
        try {
            _$jscmd("src/hw_capemgr.js", "line", 61);
            var data2 = fs.readFileSync(pinctrlFile, "utf8");
            _$jscmd("src/hw_capemgr.js", "line", 62);
            mode = parse.modeFromPinctrl(data2, muxRegOffset, 1155598336, mode);
        } catch (ex) {
            if (_$jscmd("src/hw_capemgr.js", "cond", "64_16_5", debug)) winston.debug("getPinMode(" + pin.key + "): " + ex);
        }
    }
    _$jscmd("src/hw_capemgr.js", "line", 67);
    return mode;
};

_$jscmd("src/hw_capemgr.js", "line", 70);

var setPinMode = function(pin, pinData, template, resp, callback) {
    if (_$jscmd("src/hw_capemgr.js", "cond", "71_8_5", debug)) winston.debug("hw.setPinMode(" + [ pin.key, pinData, template, JSON.stringify(resp) ] + ");");
    if (_$jscmd("src/hw_capemgr.js", "cond", "72_8_5", debug)) winston.debug("typeof callack = " + typeof callback);
    if (_$jscmd("src/hw_capemgr.js", "cond", "73_8_18", template == "bspm")) {
        _$jscmd("src/hw_capemgr.js", "line", 74);
        gpioFile[pin.key] = "/sys/class/gpio/gpio" + pin.gpio + "/value";
        if (_$jscmd("src/hw_capemgr.js", "cond", "75_12_8", callback)) {
            _$jscmd("src/hw_capemgr.js", "line", 76);
            doCreateDT(resp);
            _$jscmd("src/hw_capemgr.js", "line", 77);
            return resp;
        }
        if (_$jscmd("src/hw_capemgr.js", "cond", "79_12_7", pin.led)) {
            _$jscmd("src/hw_capemgr.js", "line", 80);
            gpioFile[pin.key] = "/sys/class/leds/beaglebone::" + pin.led + "/brightness";
        }
    } else if (_$jscmd("src/hw_capemgr.js", "cond", "82_15_19", template == "bspwm")) {
        if (_$jscmd("src/hw_capemgr.js", "cond", "83_12_8", callback)) {
            _$jscmd("src/hw_capemgr.js", "line", 84);
            my.load_dt("am33xx_pwm", null, resp, doCreateDT);
            _$jscmd("src/hw_capemgr.js", "line", 85);
            return resp;
        }
        if (_$jscmd("src/hw_capemgr.js", "cond", "87_12_25", !my.load_dt("am33xx_pwm"))) {
            _$jscmd("src/hw_capemgr.js", "line", 88);
            resp.err = "Error loading am33xx_pwm devicetree overlay";
            _$jscmd("src/hw_capemgr.js", "line", 89);
            return resp;
        }
    } else {
        _$jscmd("src/hw_capemgr.js", "line", 92);
        resp.err = "Unknown pin mode template";
        if (_$jscmd("src/hw_capemgr.js", "cond", "93_12_8", callback)) {
            _$jscmd("src/hw_capemgr.js", "line", 94);
            callback(resp);
            _$jscmd("src/hw_capemgr.js", "line", 95);
            return resp;
        }
    }
    // only synchronous stuff at this point
    if (_$jscmd("src/hw_capemgr.js", "cond", "101_8_37", !my.create_dt(pin, pinData, template))) {
        _$jscmd("src/hw_capemgr.js", "line", 102);
        resp.err = "Error loading devicetree overlay for " + pin.key + " using template " + template;
        _$jscmd("src/hw_capemgr.js", "line", 103);
        return resp;
    }
    if (_$jscmd("src/hw_capemgr.js", "cond", "105_8_19", template == "bspwm")) {
        try {
            _$jscmd("src/hw_capemgr.js", "line", 107);
            var ocp = my.is_ocp();
            _$jscmd("src/hw_capemgr.js", "line", 108);
            var p = "bs_pwm_test_" + pin.key;
            _$jscmd("src/hw_capemgr.js", "line", 109);
            var pwm_test = my.find_sysfsFile(p, ocp, p + ".");
            _$jscmd("src/hw_capemgr.js", "line", 110);
            pwmPrefix[pin.pwm.name] = pwm_test;
            _$jscmd("src/hw_capemgr.js", "line", 111);
            fs.writeFileSync(pwm_test + "/polarity", 0);
        } catch (ex) {
            _$jscmd("src/hw_capemgr.js", "line", 113);
            resp.err = "Error enabling PWM controls: " + ex;
            _$jscmd("src/hw_capemgr.js", "line", 114);
            winston.error(resp.err);
        }
    }
    // now to define the asynchronous calls
    function doCreateDT(resp) {
        if (_$jscmd("src/hw_capemgr.js", "cond", "121_12_8", resp.err)) {
            _$jscmd("src/hw_capemgr.js", "line", 122);
            callback(resp);
            _$jscmd("src/hw_capemgr.js", "line", 123);
            return;
        }
        _$jscmd("src/hw_capemgr.js", "line", 125);
        my.create_dt(pin, pinData, template, true, false, resp, onCreateDT);
    }
    function onCreateDT(resp) {
        if (_$jscmd("src/hw_capemgr.js", "cond", "129_12_8", resp.err)) {
            _$jscmd("src/hw_capemgr.js", "line", 130);
            callback(resp);
            _$jscmd("src/hw_capemgr.js", "line", 131);
            return;
        }
        if (_$jscmd("src/hw_capemgr.js", "cond", "133_12_19", template == "bspwm")) {
            _$jscmd("src/hw_capemgr.js", "line", 134);
            my.file_find("/sys/devices", "ocp.", 1, onFindOCP);
        } else {
            _$jscmd("src/hw_capemgr.js", "line", 136);
            callback(resp);
        }
        function onFindOCP(ocp) {
            if (_$jscmd("src/hw_capemgr.js", "cond", "140_16_7", ocp.err)) {
                _$jscmd("src/hw_capemgr.js", "line", 141);
                resp.err = "Error searching for ocp: " + ocp.err;
                if (_$jscmd("src/hw_capemgr.js", "cond", "142_20_5", debug)) winston.debug(resp.err);
                _$jscmd("src/hw_capemgr.js", "line", 143);
                callback(resp);
                _$jscmd("src/hw_capemgr.js", "line", 144);
                return;
            }
            _$jscmd("src/hw_capemgr.js", "line", 146);
            my.file_find(ocp.path, "bs_pwm_test_" + pin.key + ".", 1, onFindPWM);
        }
        function onFindPWM(pwm_test) {
            if (_$jscmd("src/hw_capemgr.js", "cond", "150_16_12", pwm_test.err)) {
                _$jscmd("src/hw_capemgr.js", "line", 151);
                resp.err = "Error searching for pwm_test: " + pwm_test.err;
                if (_$jscmd("src/hw_capemgr.js", "cond", "152_20_5", debug)) winston.debug(resp.err);
                _$jscmd("src/hw_capemgr.js", "line", 153);
                callback(resp);
                _$jscmd("src/hw_capemgr.js", "line", 154);
                return;
            }
            _$jscmd("src/hw_capemgr.js", "line", 156);
            my.file_find(pwm_test.path, "period", 1, onFindPeriod);
            function onFindPeriod(period) {
                if (_$jscmd("src/hw_capemgr.js", "cond", "159_20_10", period.err)) {
                    _$jscmd("src/hw_capemgr.js", "line", 160);
                    resp.err = "Error searching for period: " + period.err;
                    if (_$jscmd("src/hw_capemgr.js", "cond", "161_24_5", debug)) winston.debug(resp.err);
                    _$jscmd("src/hw_capemgr.js", "line", 162);
                    callback(resp);
                    _$jscmd("src/hw_capemgr.js", "line", 163);
                    return;
                }
                _$jscmd("src/hw_capemgr.js", "line", 165);
                pwmPrefix[pin.pwm.name] = pwm_test.path;
                _$jscmd("src/hw_capemgr.js", "line", 166);
                fs.writeFile(pwm_test.path + "/polarity", 0, "ascii", onPolarityWrite);
            }
        }
        function onPolarityWrite(err) {
            if (_$jscmd("src/hw_capemgr.js", "cond", "171_16_3", err)) {
                _$jscmd("src/hw_capemgr.js", "line", 172);
                resp.err = "Error writing PWM polarity: " + err;
                if (_$jscmd("src/hw_capemgr.js", "cond", "173_20_5", debug)) winston.debug(resp.err);
            }
            _$jscmd("src/hw_capemgr.js", "line", 175);
            callback(resp);
        }
    }
    _$jscmd("src/hw_capemgr.js", "line", 179);
    return resp;
};

_$jscmd("src/hw_capemgr.js", "line", 182);

var setLEDPinToGPIO = function(pin, resp) {
    _$jscmd("src/hw_capemgr.js", "line", 183);
    var path = "/sys/class/leds/beaglebone:green:" + pin.led + "/trigger";
    if (_$jscmd("src/hw_capemgr.js", "cond", "185_8_24", my.file_existsSync(path))) {
        _$jscmd("src/hw_capemgr.js", "line", 186);
        fs.writeFileSync(path, "gpio");
    } else {
        _$jscmd("src/hw_capemgr.js", "line", 188);
        resp.err = "Unable to find LED " + pin.led;
        _$jscmd("src/hw_capemgr.js", "line", 189);
        winston.error(resp.err);
        _$jscmd("src/hw_capemgr.js", "line", 190);
        resp.value = false;
    }
    _$jscmd("src/hw_capemgr.js", "line", 193);
    return resp;
};

_$jscmd("src/hw_capemgr.js", "line", 196);

var exportGPIOControls = function(pin, direction, resp, callback) {
    if (_$jscmd("src/hw_capemgr.js", "cond", "197_8_5", debug)) winston.debug("hw.exportGPIOControls(" + [ pin.key, direction, resp ] + ");");
    _$jscmd("src/hw_capemgr.js", "line", 198);
    var n = pin.gpio;
    if (_$jscmd("src/hw_capemgr.js", "cond", "199_8_8", callback)) {
        _$jscmd("src/hw_capemgr.js", "line", 200);
        my.file_exists(gpioFile[pin.key], onFileExists);
        _$jscmd("src/hw_capemgr.js", "line", 201);
        return;
    }
    _$jscmd("src/hw_capemgr.js", "line", 203);
    var exists = my.file_existsSync(gpioFile[pin.key]);
    if (_$jscmd("src/hw_capemgr.js", "cond", "204_8_6", exists)) {
        if (_$jscmd("src/hw_capemgr.js", "cond", "205_12_5", debug)) winston.debug("gpio: " + n + " already exported.");
        _$jscmd("src/hw_capemgr.js", "line", 206);
        fs.writeFileSync("/sys/class/gpio/gpio" + n + "/direction", direction, null);
    } else {
        try {
            if (_$jscmd("src/hw_capemgr.js", "cond", "210_16_5", debug)) winston.debug("exporting gpio: " + n);
            _$jscmd("src/hw_capemgr.js", "line", 211);
            fs.writeFileSync("/sys/class/gpio/export", "" + n, null);
            if (_$jscmd("src/hw_capemgr.js", "cond", "212_16_5", debug)) winston.debug("setting gpio " + n + " direction to " + direction);
            _$jscmd("src/hw_capemgr.js", "line", 214);
            fs.writeFileSync("/sys/class/gpio/gpio" + n + "/direction", direction, null);
        } catch (ex2) {
            _$jscmd("src/hw_capemgr.js", "line", 217);
            resp.value = false;
            _$jscmd("src/hw_capemgr.js", "line", 218);
            resp.err = "Unable to export gpio-" + n + ": " + ex2;
            if (_$jscmd("src/hw_capemgr.js", "cond", "219_16_5", debug)) winston.debug(resp.err);
            _$jscmd("src/hw_capemgr.js", "line", 220);
            var gpioUsers = fs.readFileSync("/sys/kernel/debug/gpio", "utf-8");
            _$jscmd("src/hw_capemgr.js", "line", 222);
            gpioUsers = gpioUsers.split("\n");
        }
    }
    function onFileExists(exists) {
        if (_$jscmd("src/hw_capemgr.js", "cond", "227_12_6", exists)) {
            if (_$jscmd("src/hw_capemgr.js", "cond", "228_16_5", debug)) winston.debug("gpio: " + n + " already exported.");
            _$jscmd("src/hw_capemgr.js", "line", 229);
            fs.writeFile("/sys/class/gpio/gpio" + n + "/direction", direction, null, onGPIODirectionSet);
        } else {
            if (_$jscmd("src/hw_capemgr.js", "cond", "232_16_5", debug)) winston.debug("exporting gpio: " + n);
            _$jscmd("src/hw_capemgr.js", "line", 233);
            fs.writeFile("/sys/class/gpio/export", "" + n, null, onGPIOExport);
        }
    }
    function onGPIOExport(err) {
        if (_$jscmd("src/hw_capemgr.js", "cond", "238_12_3", err)) onError(err);
        if (_$jscmd("src/hw_capemgr.js", "cond", "239_12_5", debug)) winston.debug("setting gpio " + n + " direction to " + direction);
        _$jscmd("src/hw_capemgr.js", "line", 241);
        fs.writeFile("/sys/class/gpio/gpio" + n + "/direction", direction, null, onGPIODirectionSet);
    }
    function onGPIODirectionSet(err) {
        if (_$jscmd("src/hw_capemgr.js", "cond", "246_12_3", err)) onError(err); else callback(resp);
    }
    function onError(err) {
        _$jscmd("src/hw_capemgr.js", "line", 251);
        resp.err = "Unable to export gpio-" + n + ": " + err;
        _$jscmd("src/hw_capemgr.js", "line", 252);
        resp.value = false;
        if (_$jscmd("src/hw_capemgr.js", "cond", "253_12_5", debug)) winston.debug(resp.err);
        _$jscmd("src/hw_capemgr.js", "line", 254);
        findOwner();
    }
    function findOwner() {
        _$jscmd("src/hw_capemgr.js", "line", 258);
        fs.readFile("/sys/kernel/debug/gpio", "utf-8", onGPIOUsers);
    }
    function onGPIOUsers(err, data) {
        if (_$jscmd("src/hw_capemgr.js", "cond", "262_12_4", !err)) {
            _$jscmd("src/hw_capemgr.js", "line", 263);
            var gpioUsers = data.split("\n");
            for (var x in gpioUsers) {
                _$jscmd("src/hw_capemgr.js", "line", 265);
                var y = gpioUsers[x].match(/gpio-(\d+)\s+\((\S+)\s*\)/);
                if (_$jscmd("src/hw_capemgr.js", "cond", "266_20_14", _$jscmd("src/hw_capemgr.js", "cond", "266_20_1", y) && _$jscmd("src/hw_capemgr.js", "cond", "266_25_9", y[1] == n))) {
                    _$jscmd("src/hw_capemgr.js", "line", 267);
                    resp.err += "\nconsumed by " + y[2];
                    if (_$jscmd("src/hw_capemgr.js", "cond", "268_24_5", debug)) winston.debug(resp.err);
                }
            }
        }
        _$jscmd("src/hw_capemgr.js", "line", 272);
        callback(resp);
    }
    _$jscmd("src/hw_capemgr.js", "line", 275);
    return resp;
};

_$jscmd("src/hw_capemgr.js", "line", 278);

var writeGPIOValue = function(pin, value, callback) {
    if (_$jscmd("src/hw_capemgr.js", "cond", "279_8_39", typeof gpioFile[pin.key] == "undefined")) {
        _$jscmd("src/hw_capemgr.js", "line", 280);
        gpioFile[pin.key] = "/sys/class/gpio/gpio" + pin.gpio + "/value";
        if (_$jscmd("src/hw_capemgr.js", "cond", "281_12_7", pin.led)) {
            _$jscmd("src/hw_capemgr.js", "line", 282);
            gpioFile[pin.key] = "/sys/class/leds/beaglebone:";
            _$jscmd("src/hw_capemgr.js", "line", 283);
            gpioFile[pin.key] += "green:" + pin.led + "/brightness";
        }
        if (_$jscmd("src/hw_capemgr.js", "cond", "285_12_38", !my.file_existsSync(gpioFile[pin.key]))) {
            _$jscmd("src/hw_capemgr.js", "line", 286);
            winston.error("Unable to find gpio: " + gpioFile[pin.key]);
        }
    }
    if (_$jscmd("src/hw_capemgr.js", "cond", "289_8_5", debug)) winston.debug("gpioFile = " + gpioFile[pin.key]);
    if (_$jscmd("src/hw_capemgr.js", "cond", "290_8_8", callback)) {
        _$jscmd("src/hw_capemgr.js", "line", 291);
        fs.writeFile(gpioFile[pin.key], "" + value, null, callback);
    } else {
        try {
            _$jscmd("src/hw_capemgr.js", "line", 294);
            fs.writeFileSync(gpioFile[pin.key], "" + value, null);
        } catch (ex) {
            _$jscmd("src/hw_capemgr.js", "line", 296);
            winston.error("Unable to write to " + gpioFile[pin.key]);
        }
    }
};

_$jscmd("src/hw_capemgr.js", "line", 301);

var readGPIOValue = function(pin, resp, callback) {
    _$jscmd("src/hw_capemgr.js", "line", 302);
    var gpioFile = "/sys/class/gpio/gpio" + pin.gpio + "/value";
    if (_$jscmd("src/hw_capemgr.js", "cond", "303_8_8", callback)) {
        _$jscmd("src/hw_capemgr.js", "line", 304);
        var readFile = function(err, data) {
            if (_$jscmd("src/hw_capemgr.js", "cond", "305_16_3", err)) {
                _$jscmd("src/hw_capemgr.js", "line", 306);
                resp.err = "digitalRead error: " + err;
                _$jscmd("src/hw_capemgr.js", "line", 307);
                winston.error(resp.err);
            }
            _$jscmd("src/hw_capemgr.js", "line", 309);
            resp.value = parseInt(data, 2);
            _$jscmd("src/hw_capemgr.js", "line", 310);
            callback(resp);
        };
        _$jscmd("src/hw_capemgr.js", "line", 312);
        fs.readFile(gpioFile, readFile);
        _$jscmd("src/hw_capemgr.js", "line", 313);
        return true;
    }
    _$jscmd("src/hw_capemgr.js", "line", 315);
    resp.value = parseInt(fs.readFileSync(gpioFile), 2);
    _$jscmd("src/hw_capemgr.js", "line", 316);
    return resp;
};

_$jscmd("src/hw_capemgr.js", "line", 319);

var enableAIN = function(callback) {
    _$jscmd("src/hw_capemgr.js", "line", 320);
    var helper = "";
    if (_$jscmd("src/hw_capemgr.js", "cond", "321_8_27", my.load_dt("cape-bone-iio"))) {
        _$jscmd("src/hw_capemgr.js", "line", 322);
        var ocp = my.is_ocp();
        if (_$jscmd("src/hw_capemgr.js", "cond", "323_12_3", ocp)) {
            _$jscmd("src/hw_capemgr.js", "line", 324);
            helper = my.find_sysfsFile("helper", ocp, "helper.");
            if (_$jscmd("src/hw_capemgr.js", "cond", "325_16_6", helper)) {
                _$jscmd("src/hw_capemgr.js", "line", 326);
                ainPrefix = helper + "/AIN";
            }
        }
    }
    if (_$jscmd("src/hw_capemgr.js", "cond", "330_8_8", callback)) {
        _$jscmd("src/hw_capemgr.js", "line", 331);
        callback({
            path: helper
        });
    }
    _$jscmd("src/hw_capemgr.js", "line", 335);
    return helper.length > 1;
};

_$jscmd("src/hw_capemgr.js", "line", 338);

var readAIN = function(pin, resp, callback) {
    _$jscmd("src/hw_capemgr.js", "line", 339);
    var ainFile = ainPrefix + pin.ain.toString();
    if (_$jscmd("src/hw_capemgr.js", "cond", "340_8_8", callback)) {
        _$jscmd("src/hw_capemgr.js", "line", 341);
        var readFile = function(err, data) {
            if (_$jscmd("src/hw_capemgr.js", "cond", "342_16_3", err)) {
                _$jscmd("src/hw_capemgr.js", "line", 343);
                resp.err = "analogRead error: " + err;
                _$jscmd("src/hw_capemgr.js", "line", 344);
                winston.error(resp.err);
            }
            _$jscmd("src/hw_capemgr.js", "line", 346);
            resp.value = parseInt(data, 10) / 1800;
            _$jscmd("src/hw_capemgr.js", "line", 347);
            callback(resp);
        };
        _$jscmd("src/hw_capemgr.js", "line", 349);
        fs.readFile(ainFile, readFile);
        _$jscmd("src/hw_capemgr.js", "line", 350);
        return resp;
    }
    _$jscmd("src/hw_capemgr.js", "line", 352);
    resp.value = parseInt(fs.readFileSync(ainFile), 10);
    if (_$jscmd("src/hw_capemgr.js", "cond", "353_8_17", isNaN(resp.value))) {
        _$jscmd("src/hw_capemgr.js", "line", 354);
        resp.err = "analogRead(" + pin.key + ") returned " + resp.value;
        _$jscmd("src/hw_capemgr.js", "line", 355);
        winston.error(resp.err);
    }
    _$jscmd("src/hw_capemgr.js", "line", 357);
    resp.value = resp.value / 1800;
    if (_$jscmd("src/hw_capemgr.js", "cond", "358_8_17", isNaN(resp.value))) {
        _$jscmd("src/hw_capemgr.js", "line", 359);
        resp.err = "analogRead(" + pin.key + ") scaled to " + resp.value;
        _$jscmd("src/hw_capemgr.js", "line", 360);
        winston.error(resp.err);
    }
    _$jscmd("src/hw_capemgr.js", "line", 362);
    return resp;
};

_$jscmd("src/hw_capemgr.js", "line", 365);

var writeGPIOEdge = function(pin, mode) {
    _$jscmd("src/hw_capemgr.js", "line", 366);
    fs.writeFileSync("/sys/class/gpio/gpio" + pin.gpio + "/edge", mode);
    _$jscmd("src/hw_capemgr.js", "line", 368);
    var resp = {};
    _$jscmd("src/hw_capemgr.js", "line", 369);
    resp.gpioFile = "/sys/class/gpio/gpio" + pin.gpio + "/value";
    _$jscmd("src/hw_capemgr.js", "line", 370);
    resp.valuefd = fs.openSync(resp.gpioFile, "r");
    _$jscmd("src/hw_capemgr.js", "line", 371);
    resp.value = new Buffer(1);
    _$jscmd("src/hw_capemgr.js", "line", 373);
    return resp;
};

_$jscmd("src/hw_capemgr.js", "line", 376);

var writePWMFreqAndValue = function(pin, pwm, freq, value, resp, callback) {
    if (_$jscmd("src/hw_capemgr.js", "cond", "377_8_5", debug)) winston.debug("hw.writePWMFreqAndValue(" + [ pin.key, pwm, freq, value, resp ] + ");");
    _$jscmd("src/hw_capemgr.js", "line", 378);
    var path = pwmPrefix[pin.pwm.name];
    try {
        _$jscmd("src/hw_capemgr.js", "line", 380);
        var period = Math.round(1e9 / freq);
        _$jscmd("src/hw_capemgr.js", "line", 381);
        // period in ns
        var duty = Math.round(period * value);
        _$jscmd("src/hw_capemgr.js", "line", 382);
        fs.writeFileSync(path + "/duty", 0);
        if (_$jscmd("src/hw_capemgr.js", "cond", "383_12_16", pwm.freq != freq)) {
            if (_$jscmd("src/hw_capemgr.js", "cond", "384_16_5", debug)) winston.debug("Updating PWM period: " + period);
            _$jscmd("src/hw_capemgr.js", "line", 385);
            fs.writeFileSync(path + "/period", period);
        }
        if (_$jscmd("src/hw_capemgr.js", "cond", "387_12_5", debug)) winston.debug("Updating PWM duty: " + duty);
        _$jscmd("src/hw_capemgr.js", "line", 388);
        fs.writeFileSync(path + "/duty", duty);
    } catch (ex) {
        _$jscmd("src/hw_capemgr.js", "line", 390);
        resp.err = "error updating PWM freq and value: " + path + ", " + ex;
        _$jscmd("src/hw_capemgr.js", "line", 391);
        winston.error(resp.err);
    }
    _$jscmd("src/hw_capemgr.js", "line", 393);
    return resp;
};

_$jscmd("src/hw_capemgr.js", "line", 396);

var readEeproms = function(eeproms) {
    _$jscmd("src/hw_capemgr.js", "line", 397);
    var boardName = fs.readFileSync(my.is_capemgr() + "/baseboard/board-name", "ascii");
    _$jscmd("src/hw_capemgr.js", "line", 399);
    var version = fs.readFileSync(my.is_capemgr() + "/baseboard/revision", "ascii");
    _$jscmd("src/hw_capemgr.js", "line", 401);
    var serialNumber = fs.readFileSync(my.is_capemgr() + "/baseboard/serial-number", "ascii");
    _$jscmd("src/hw_capemgr.js", "line", 403);
    eeproms["/sys/bus/i2c/drivers/at24/1-0050/eeprom"] = {};
    _$jscmd("src/hw_capemgr.js", "line", 404);
    eeproms["/sys/bus/i2c/drivers/at24/1-0050/eeprom"].boardName = boardName;
    _$jscmd("src/hw_capemgr.js", "line", 405);
    eeproms["/sys/bus/i2c/drivers/at24/1-0050/eeprom"].version = version;
    _$jscmd("src/hw_capemgr.js", "line", 406);
    eeproms["/sys/bus/i2c/drivers/at24/1-0050/eeprom"].serialNumber = serialNumber;
    _$jscmd("src/hw_capemgr.js", "line", 407);
    return eeproms;
};

_$jscmd("src/hw_capemgr.js", "line", 410);

var readPlatform = function(platform) {
    _$jscmd("src/hw_capemgr.js", "line", 411);
    platform.name = fs.readFileSync(my.is_capemgr() + "/baseboard/board-name", "ascii").trim();
    if (_$jscmd("src/hw_capemgr.js", "cond", "413_8_27", platform.name == "A335BONE")) platform.name = "BeagleBone";
    if (_$jscmd("src/hw_capemgr.js", "cond", "414_8_27", platform.name == "A335BNLT")) platform.name = "BeagleBone Black";
    if (_$jscmd("src/hw_capemgr.js", "cond", "415_8_27", platform.name == "A335PBGL")) platform.name = "PocketBeagle";
    _$jscmd("src/hw_capemgr.js", "line", 416);
    platform.version = fs.readFileSync(my.is_capemgr() + "/baseboard/revision", "ascii").trim();
    if (_$jscmd("src/hw_capemgr.js", "cond", "418_8_27", platform.version[0] == 26)) {
        _$jscmd("src/hw_capemgr.js", "line", 419);
        platform.version = "1A";
        _$jscmd("src/hw_capemgr.js", "line", 420);
        platform.name = "BeagleBone Green";
    } else if (_$jscmd("src/hw_capemgr.js", "cond", "421_15_29", platform.version.match(/^GR/))) {
        _$jscmd("src/hw_capemgr.js", "line", 422);
        platform.version = platform.version.substr(2);
        _$jscmd("src/hw_capemgr.js", "line", 423);
        platform.name = "BeagleBone Green";
    } else if (_$jscmd("src/hw_capemgr.js", "cond", "424_15_29", platform.version.match(/^BL/))) {
        _$jscmd("src/hw_capemgr.js", "line", 425);
        platform.version = platform.version.substr(2);
        _$jscmd("src/hw_capemgr.js", "line", 426);
        platform.name = "BeagleBone Blue";
    } else if (_$jscmd("src/hw_capemgr.js", "cond", "427_15_41", !platform.version.match(/^[\040-\176]*$/))) delete platform.version;
    _$jscmd("src/hw_capemgr.js", "line", 428);
    platform.serialNumber = fs.readFileSync(my.is_capemgr() + "/baseboard/serial-number", "ascii").trim();
    if (_$jscmd("src/hw_capemgr.js", "cond", "430_8_46", !platform.serialNumber.match(/^[\040-\176]*$/))) delete platform.serialNumber;
    _$jscmd("src/hw_capemgr.js", "line", 431);
    return platform;
};

_$jscmd("src/hw_capemgr.js", "line", 434);

module.exports = {
    logfile: logfile,
    readPWMFreqAndValue: readPWMFreqAndValue,
    readGPIODirection: readGPIODirection,
    readPinMux: readPinMux,
    setPinMode: setPinMode,
    setLEDPinToGPIO: setLEDPinToGPIO,
    exportGPIOControls: exportGPIOControls,
    writeGPIOValue: writeGPIOValue,
    readGPIOValue: readGPIOValue,
    enableAIN: enableAIN,
    readAIN: readAIN,
    writeGPIOEdge: writeGPIOEdge,
    writePWMFreqAndValue: writePWMFreqAndValue,
    readEeproms: readEeproms,
    readPlatform: readPlatform
};