
// instrument by jscoverage, do not modifly this file
(function (file, lines, conds, source) {
  var BASE;
  if (typeof global === 'object') {
    BASE = global;
  } else if (typeof window === 'object') {
    BASE = window;
  } else {
    throw new Error('[jscoverage] unknow ENV!');
  }
  if (BASE._$jscoverage) {
    BASE._$jscmd(file, 'init', lines, conds, source);
    return;
  }
  var cov = {};
  /**
   * jsc(file, 'init', lines, condtions)
   * jsc(file, 'line', lineNum)
   * jsc(file, 'cond', lineNum, expr, start, offset)
   */
  function jscmd(file, type, line, express, start, offset) {
    var storage;
    switch (type) {
      case 'init':
        if(cov[file]){
          storage = cov[file];
        } else {
          storage = [];
          for (var i = 0; i < line.length; i ++) {
            storage[line[i]] = 0;
          }
          var condition = express;
          var source = start;
          storage.condition = condition;
          storage.source = source;
        }
        cov[file] = storage;
        break;
      case 'line':
        storage = cov[file];
        storage[line] ++;
        break;
      case 'cond':
        storage = cov[file];
        storage.condition[line] ++;
        return express;
    }
  }

  BASE._$jscoverage = cov;
  BASE._$jscmd = jscmd;
  jscmd(file, 'init', lines, conds, source);
})('src/hw_simulator.js', [1,2,4,6,7,15,29,40,46,51,56,63,77,82,94,100,105,117,123,8,9,10,11,12,16,17,26,24,20,22,30,37,41,42,43,47,48,52,53,57,59,64,73,74,66,71,78,79,83,84,91,95,96,97,101,102,106,107,108,109,110,111,112,113,114,118,119,120], {"18_8_29":0,"19_12_14":0,"31_8_8":0,"32_12_20":0,"58_8_8":0,"65_8_8":0,"67_12_20":0,"85_8_8":0,"86_12_20":0}, ["var fs = require('fs');","var winston = require('winston');","","var gpioFile = {};","","var logfile = 'bonescript.log';","var readPWMFreqAndValue = function (pin, pwm) {","    winston.info('readPWMFreqAndValue(' + [pin.key, pwm.key] + ')');","    var mode = {};","    mode.freq = pwm.freq;","    mode.value = pwm.value;","    return (mode);","};","","var readGPIODirection = function (n, gpio) {","    winston.info('readGPIODirection(' + [n] + ')');","    var mode = {};","    if (typeof gpio[n] != 'undefined') {","        if (gpio[n].active) {","            mode.active = true;","        } else {","            mode.active = false;","        }","        mode.direction = gpio[n].direction;","    }","    return (mode);","};","","var readPinMux = function (pin, mode, callback) {","    winston.info('readPinMux(' + [pin.key] + ')');","    if (callback) {","        if (callback.length == 1)","            callback(mode);","        else","            callback(null, mode);","    }","    return (mode);","};","","var setPinMode = function (pin, pinData, template, resp) {","    winston.info('setPinMode(' + [pin.key, pinData, template] + ')');","    gpioFile[pin.key] = true;","    return (resp);","};","","var setLEDPinToGPIO = function (pin, resp) {","    winston.info('setLEDPinToGPIO(' + [pin.key] + ')');","    return (resp);","};","","var exportGPIOControls = function (pin, direction, resp) {","    winston.info('expertGPIOControls(' + [pin.key, direction] + ')');","    return (resp);","};","","var writeGPIOValue = function (pin, value, callback) {","    winston.info('writeGPIOValue(' + [pin.key, value] + ')');","    if (callback) {","        callback();","    }","};","","var readGPIOValue = function (pin, resp, callback) {","    winston.info('readGPIOValue(' + [pin.key] + ')');","    if (callback) {","        resp.value = 0;","        if (callback.length == 1)","            callback(resp);","        else","            callback(null, resp.value);","        return (true);","    }","    resp.value = 0;","    return (resp);","};","","var enableAIN = function () {","    winston.info('enableAIN()');","    return (true);","};","","var readAIN = function (pin, resp, callback) {","    winston.info('readAIN(' + [pin.key] + ')');","    resp.value = 0;","    if (callback) {","        if (callback.length == 1)","            callback(resp);","        else","            callback(null, resp.value);","    }","    return (resp);","};","","var writeGPIOEdge = function (pin, mode) {","    winston.info('writeGPIOEdge(' + [pin.key, mode] + ')');","    var resp = {};","    return (resp);","};","","var writePWMFreqAndValue = function (pin, pwm, freq, value, resp) {","    winston.info('writePWMFreqAndValue(' + [pin.key, pwm.name, freq, value] + ')');","    return (resp);","};","","var readEeproms = function (eeproms) {","    winston.info('readEeproms()');","    var boardName = 'A335BNLT';","    var version = '';","    var serialNumber = '';","    eeproms['/sys/bus/i2c/drivers/at24/1-0050/eeprom'] = {};","    eeproms['/sys/bus/i2c/drivers/at24/1-0050/eeprom'].boardName = boardName;","    eeproms['/sys/bus/i2c/drivers/at24/1-0050/eeprom'].version = version;","    eeproms['/sys/bus/i2c/drivers/at24/1-0050/eeprom'].serialNumber = serialNumber;","    return (eeproms);","};","","var readPlatform = function (platform) {","    winston.info('readPlatform()');","    platform.name = 'BeagleBone Simulator';","    return (platform);","};","","module.exports = {","    logfile: logfile,","    readPWMFreqAndValue: readPWMFreqAndValue,","    readGPIODirection: readGPIODirection,","    readPinMux: readPinMux,","    setPinMode: setPinMode,","    setLEDPinToGPIO: setLEDPinToGPIO,","    exportGPIOControls: exportGPIOControls,","    writeGPIOValue: writeGPIOValue,","    readGPIOValue: readGPIOValue,","    enableAIN: enableAIN,","    readAIN: readAIN,","    writeGPIOEdge: writeGPIOEdge,","    writePWMFreqAndValue: writePWMFreqAndValue,","    readEeproms: readEeproms,","    readPlatform: readPlatform","}"]);
_$jscmd("src/hw_simulator.js", "line", 1);

var fs = require("fs");

_$jscmd("src/hw_simulator.js", "line", 2);

var winston = require("winston");

_$jscmd("src/hw_simulator.js", "line", 4);

var gpioFile = {};

_$jscmd("src/hw_simulator.js", "line", 6);

var logfile = "bonescript.log";

_$jscmd("src/hw_simulator.js", "line", 7);

var readPWMFreqAndValue = function(pin, pwm) {
    _$jscmd("src/hw_simulator.js", "line", 8);
    winston.info("readPWMFreqAndValue(" + [ pin.key, pwm.key ] + ")");
    _$jscmd("src/hw_simulator.js", "line", 9);
    var mode = {};
    _$jscmd("src/hw_simulator.js", "line", 10);
    mode.freq = pwm.freq;
    _$jscmd("src/hw_simulator.js", "line", 11);
    mode.value = pwm.value;
    _$jscmd("src/hw_simulator.js", "line", 12);
    return mode;
};

_$jscmd("src/hw_simulator.js", "line", 15);

var readGPIODirection = function(n, gpio) {
    _$jscmd("src/hw_simulator.js", "line", 16);
    winston.info("readGPIODirection(" + [ n ] + ")");
    _$jscmd("src/hw_simulator.js", "line", 17);
    var mode = {};
    if (_$jscmd("src/hw_simulator.js", "cond", "18_8_29", typeof gpio[n] != "undefined")) {
        if (_$jscmd("src/hw_simulator.js", "cond", "19_12_14", gpio[n].active)) {
            _$jscmd("src/hw_simulator.js", "line", 20);
            mode.active = true;
        } else {
            _$jscmd("src/hw_simulator.js", "line", 22);
            mode.active = false;
        }
        _$jscmd("src/hw_simulator.js", "line", 24);
        mode.direction = gpio[n].direction;
    }
    _$jscmd("src/hw_simulator.js", "line", 26);
    return mode;
};

_$jscmd("src/hw_simulator.js", "line", 29);

var readPinMux = function(pin, mode, callback) {
    _$jscmd("src/hw_simulator.js", "line", 30);
    winston.info("readPinMux(" + [ pin.key ] + ")");
    if (_$jscmd("src/hw_simulator.js", "cond", "31_8_8", callback)) {
        if (_$jscmd("src/hw_simulator.js", "cond", "32_12_20", callback.length == 1)) callback(mode); else callback(null, mode);
    }
    _$jscmd("src/hw_simulator.js", "line", 37);
    return mode;
};

_$jscmd("src/hw_simulator.js", "line", 40);

var setPinMode = function(pin, pinData, template, resp) {
    _$jscmd("src/hw_simulator.js", "line", 41);
    winston.info("setPinMode(" + [ pin.key, pinData, template ] + ")");
    _$jscmd("src/hw_simulator.js", "line", 42);
    gpioFile[pin.key] = true;
    _$jscmd("src/hw_simulator.js", "line", 43);
    return resp;
};

_$jscmd("src/hw_simulator.js", "line", 46);

var setLEDPinToGPIO = function(pin, resp) {
    _$jscmd("src/hw_simulator.js", "line", 47);
    winston.info("setLEDPinToGPIO(" + [ pin.key ] + ")");
    _$jscmd("src/hw_simulator.js", "line", 48);
    return resp;
};

_$jscmd("src/hw_simulator.js", "line", 51);

var exportGPIOControls = function(pin, direction, resp) {
    _$jscmd("src/hw_simulator.js", "line", 52);
    winston.info("expertGPIOControls(" + [ pin.key, direction ] + ")");
    _$jscmd("src/hw_simulator.js", "line", 53);
    return resp;
};

_$jscmd("src/hw_simulator.js", "line", 56);

var writeGPIOValue = function(pin, value, callback) {
    _$jscmd("src/hw_simulator.js", "line", 57);
    winston.info("writeGPIOValue(" + [ pin.key, value ] + ")");
    if (_$jscmd("src/hw_simulator.js", "cond", "58_8_8", callback)) {
        _$jscmd("src/hw_simulator.js", "line", 59);
        callback();
    }
};

_$jscmd("src/hw_simulator.js", "line", 63);

var readGPIOValue = function(pin, resp, callback) {
    _$jscmd("src/hw_simulator.js", "line", 64);
    winston.info("readGPIOValue(" + [ pin.key ] + ")");
    if (_$jscmd("src/hw_simulator.js", "cond", "65_8_8", callback)) {
        _$jscmd("src/hw_simulator.js", "line", 66);
        resp.value = 0;
        if (_$jscmd("src/hw_simulator.js", "cond", "67_12_20", callback.length == 1)) callback(resp); else callback(null, resp.value);
        _$jscmd("src/hw_simulator.js", "line", 71);
        return true;
    }
    _$jscmd("src/hw_simulator.js", "line", 73);
    resp.value = 0;
    _$jscmd("src/hw_simulator.js", "line", 74);
    return resp;
};

_$jscmd("src/hw_simulator.js", "line", 77);

var enableAIN = function() {
    _$jscmd("src/hw_simulator.js", "line", 78);
    winston.info("enableAIN()");
    _$jscmd("src/hw_simulator.js", "line", 79);
    return true;
};

_$jscmd("src/hw_simulator.js", "line", 82);

var readAIN = function(pin, resp, callback) {
    _$jscmd("src/hw_simulator.js", "line", 83);
    winston.info("readAIN(" + [ pin.key ] + ")");
    _$jscmd("src/hw_simulator.js", "line", 84);
    resp.value = 0;
    if (_$jscmd("src/hw_simulator.js", "cond", "85_8_8", callback)) {
        if (_$jscmd("src/hw_simulator.js", "cond", "86_12_20", callback.length == 1)) callback(resp); else callback(null, resp.value);
    }
    _$jscmd("src/hw_simulator.js", "line", 91);
    return resp;
};

_$jscmd("src/hw_simulator.js", "line", 94);

var writeGPIOEdge = function(pin, mode) {
    _$jscmd("src/hw_simulator.js", "line", 95);
    winston.info("writeGPIOEdge(" + [ pin.key, mode ] + ")");
    _$jscmd("src/hw_simulator.js", "line", 96);
    var resp = {};
    _$jscmd("src/hw_simulator.js", "line", 97);
    return resp;
};

_$jscmd("src/hw_simulator.js", "line", 100);

var writePWMFreqAndValue = function(pin, pwm, freq, value, resp) {
    _$jscmd("src/hw_simulator.js", "line", 101);
    winston.info("writePWMFreqAndValue(" + [ pin.key, pwm.name, freq, value ] + ")");
    _$jscmd("src/hw_simulator.js", "line", 102);
    return resp;
};

_$jscmd("src/hw_simulator.js", "line", 105);

var readEeproms = function(eeproms) {
    _$jscmd("src/hw_simulator.js", "line", 106);
    winston.info("readEeproms()");
    _$jscmd("src/hw_simulator.js", "line", 107);
    var boardName = "A335BNLT";
    _$jscmd("src/hw_simulator.js", "line", 108);
    var version = "";
    _$jscmd("src/hw_simulator.js", "line", 109);
    var serialNumber = "";
    _$jscmd("src/hw_simulator.js", "line", 110);
    eeproms["/sys/bus/i2c/drivers/at24/1-0050/eeprom"] = {};
    _$jscmd("src/hw_simulator.js", "line", 111);
    eeproms["/sys/bus/i2c/drivers/at24/1-0050/eeprom"].boardName = boardName;
    _$jscmd("src/hw_simulator.js", "line", 112);
    eeproms["/sys/bus/i2c/drivers/at24/1-0050/eeprom"].version = version;
    _$jscmd("src/hw_simulator.js", "line", 113);
    eeproms["/sys/bus/i2c/drivers/at24/1-0050/eeprom"].serialNumber = serialNumber;
    _$jscmd("src/hw_simulator.js", "line", 114);
    return eeproms;
};

_$jscmd("src/hw_simulator.js", "line", 117);

var readPlatform = function(platform) {
    _$jscmd("src/hw_simulator.js", "line", 118);
    winston.info("readPlatform()");
    _$jscmd("src/hw_simulator.js", "line", 119);
    platform.name = "BeagleBone Simulator";
    _$jscmd("src/hw_simulator.js", "line", 120);
    return platform;
};

_$jscmd("src/hw_simulator.js", "line", 123);

module.exports = {
    logfile: logfile,
    readPWMFreqAndValue: readPWMFreqAndValue,
    readGPIODirection: readGPIODirection,
    readPinMux: readPinMux,
    setPinMode: setPinMode,
    setLEDPinToGPIO: setLEDPinToGPIO,
    exportGPIOControls: exportGPIOControls,
    writeGPIOValue: writeGPIOValue,
    readGPIOValue: readGPIOValue,
    enableAIN: enableAIN,
    readAIN: readAIN,
    writeGPIOEdge: writeGPIOEdge,
    writePWMFreqAndValue: writePWMFreqAndValue,
    readEeproms: readEeproms,
    readPlatform: readPlatform
};