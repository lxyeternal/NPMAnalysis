
// instrument by jscoverage, do not modifly this file
(function (file, lines, conds, source) {
  var BASE;
  if (typeof global === 'object') {
    BASE = global;
  } else if (typeof window === 'object') {
    BASE = window;
  } else {
    throw new Error('[jscoverage] unknow ENV!');
  }
  if (BASE._$jscoverage) {
    BASE._$jscmd(file, 'init', lines, conds, source);
    return;
  }
  var cov = {};
  /**
   * jsc(file, 'init', lines, condtions)
   * jsc(file, 'line', lineNum)
   * jsc(file, 'cond', lineNum, expr, start, offset)
   */
  function jscmd(file, type, line, express, start, offset) {
    var storage;
    switch (type) {
      case 'init':
        if(cov[file]){
          storage = cov[file];
        } else {
          storage = [];
          for (var i = 0; i < line.length; i ++) {
            storage[line[i]] = 0;
          }
          var condition = express;
          var source = start;
          storage.condition = condition;
          storage.source = source;
        }
        cov[file] = storage;
        break;
      case 'line':
        storage = cov[file];
        storage[line] ++;
        break;
      case 'cond':
        storage = cov[file];
        storage.condition[line] ++;
        return express;
    }
  }

  BASE._$jscoverage = cov;
  BASE._$jscmd = jscmd;
  jscmd(file, 'init', lines, conds, source);
})('src/bonescript.js', [1,2,3,4,5,6,7,8,9,10,13,14,15,16,18,11,31,32,33,34,35,36,37,38,20,21,22,29,23,26,27,46,57,58,59,60,61,62,63,64,65,66,67,116,73,112,113,81,84,93,94,107,88,89,90,91,109,137,141], {"19_8_30":0,"24_16_13":0,"43_8_26":0,"44_8_26":0,"45_8_58":0,"45_8_30":0,"45_42_24":0,"47_8_23":0,"50_73_15":0,"50_91_4":0,"70_12_20":0,"70_12_9":0,"70_25_7":0,"75_16_77":0,"75_16_34":0,"75_54_39":0,"75_16_15":0,"75_35_15":0,"77_16_28":0,"79_20_16":0,"86_24_8":0,"87_24_23":0,"120_8_88":0,"120_8_29":0,"120_41_55":0,"122_8_44":0,"126_8_12":0,"133_8_33":0,"135_8_49":0,"140_4_28":0}, ["var _bonescript = {};","_bonescript.modules = {};","_bonescript._callbacks = {};","_bonescript._seqnum = 0;","_bonescript.on = {};","_bonescript.on.connect = function () {};","_bonescript.on.connecting = function () {};","_bonescript.on.disconnect = function () {};","_bonescript.on.connect_failed = function () {};","_bonescript.on.error = function (err) {","    throw (new Error(err))","};","_bonescript.on.reconnect = function () {};","_bonescript.on.reconnect_failed = function () {};","_bonescript.on.reconnecting = function () {};","_bonescript.on.initialized = function () {};","","(function () {","    if (typeof document == 'undefined') {","        var io = require('socket.io-client');","        var crypto = require('crypto');","        module.exports.startClient = function (host, callback) {","            var passphrase_hash;","            if (host.password)","                passphrase_hash = crypto.createHash('sha256').update(host.password).digest(\"hex\"); //generate sha256 hash for supplied password","            _bonescript.on.initialized = callback;","            var socket = _onSocketIOLoaded(host.address, host.port, io, passphrase_hash);","        }","        return;","    }","    require = myrequire;","    var head = document.getElementsByTagName('head')[0];","    var script = document.createElement('script');","    script.type = 'text/javascript';","    script.src = '___INSERT_HOST___/socket.io/socket.io.js';","    script.charset = 'UTF-8';","    var scriptObj = head.appendChild(script);","    scriptObj.onload = _onSocketIOLoaded;","}());","","function _onSocketIOLoaded(host, port, socketio, passphrase_hash) {","    //console.log(\"socket.io loaded\");","    if (typeof host == 'undefined') host = '___INSERT_HOST___';","    if (typeof port == 'undefined') port = 80;","    if (typeof socketio == 'undefined' && typeof io != 'undefined') socketio = io;","    var socket;","    if (typeof host == 'string')","        socket = socketio('http://' + host + ':' + port, {","            extraHeaders: {","                'Authorization': typeof passphrase_hash != 'undefined' ? passphrase_hash : null //send passphrase_has as Authorization extraheader","            }","        });","    else","        socket = socketio('___INSERT_HOST___', {","            port: port","        });","    socket.on('require', getRequireData);","    socket.on('bonescript', _seqcall);","    socket.on('connect', _bonescript.on.connect);","    socket.on('connecting', _bonescript.on.connecting);","    socket.on('disconnect', _bonescript.on.disconnect);","    socket.on('connect_failed', _bonescript.on.connect_failed);","    socket.on('error', _bonescript.on.error);","    socket.on('reconnect', _bonescript.on.reconnect);","    socket.on('reconnect_failed', _bonescript.on.reconnect_failed);","    socket.on('reconnecting', _bonescript.on.reconnecting);","    socket.on('initialized', _bonescript.on.initialized);","","    function getRequireData(m) {","        if (!m.module || !m.data)","            throw ('Invalid \"require\" message sent for \"' + m.module + '\"');","        //console.log('Initialized module: ' + m.module);","        _bonescript.modules[m.module] = {};","        for (var x in m.data) {","            if (!m.data[x].type || !m.data[x].name || (typeof m.data[x].value == 'undefined'))","                throw ('Invalid data in \"require\" message sent for \"' + m.module + '.' + m.data[x] + '\"');","            if (m.data[x].type == 'function') {","                // define the function","                if (!m.data[x].value)","                    throw ('Missing args in \"require\" message sent for \"' + m.module + '.' + m.data[x] + '\"');","                var myargs = m.data[x].value;","","                // eval of objString builds the call data out of arguments passed in","                var objString = '';","                for (var y in myargs) {","                    if (isNaN(y)) continue; // Need to find the source of this bug","                    if (myargs[y] == 'callback') continue;","                    objString += ' if(typeof ' + myargs[y] + ' == \"function\") {\\n';","                    objString += '  ' + myargs[y] + ' = ' + myargs[y] + '.toString();\\n';","                    objString += ' }\\n';","                    objString += ' calldata.' + myargs[y] + ' = ' + myargs[y] + ';\\n';","                }","                var argsString = myargs.join(', ');","                var handyfunc = '_bonescript.modules[\"' + m.module + '\"].' + m.data[x].name +","                    ' = ' +","                    'function (' + argsString + ') {\\n' +","                    ' var calldata = {};\\n' +","                    objString +","                    ' if(callback) {\\n' +","                    '  _bonescript._callbacks[_bonescript._seqnum] = callback;\\n' +","                    '  calldata.seq = _bonescript._seqnum;\\n' +","                    '  calldata.length = callback.length;\\n' +","                    '  _bonescript._seqnum++;\\n' +","                    ' }\\n' +","                    ' socket.emit(\"' + m.module + '$' + m.data[x].name + '\", calldata);\\n' +","                    '};\\n';","                eval(handyfunc);","            } else {","                _bonescript.modules[m.module][m.data[x].name] = m.data[x].value;","            }","        }","        _bonescript.modules[m.module].socket = socket;","        _bonescript.on.initialized();","    }","","    return (socket);","}","","function _seqcall(data) {","    if ((typeof data.seq != 'number') || (typeof _bonescript._callbacks[data.seq] != 'function'))","        throw \"Invalid callback message received: \" + JSON.stringify(data);","    if (_bonescript._callbacks[data.seq].length == 1)","        _bonescript._callbacks[data.seq](data);","    else","        _bonescript._callbacks[data.seq](data.err, data.resp);","    if (data.oneshot) delete _bonescript._callbacks[data.seq];","}","","// Require must be synchronous to be able to return data structures and","// functions and therefore cannot call socket.io. All exported modules must","// be exported ahead of time.","function myrequire(module) {","    if (typeof _bonescript == 'undefined')","        throw 'No BoneScript modules are not currently available';","    if (typeof _bonescript.modules[module] == 'undefined')","        throw 'Module \"' + module + '\" is not currently available';","    return (_bonescript.modules[module]);","}","","if (typeof module != 'undefined') {","    module.exports.require = myrequire;","}"]);
_$jscmd("src/bonescript.js", "line", 1);

var _bonescript = {};

_$jscmd("src/bonescript.js", "line", 2);

_bonescript.modules = {};

_$jscmd("src/bonescript.js", "line", 3);

_bonescript._callbacks = {};

_$jscmd("src/bonescript.js", "line", 4);

_bonescript._seqnum = 0;

_$jscmd("src/bonescript.js", "line", 5);

_bonescript.on = {};

_$jscmd("src/bonescript.js", "line", 6);

_bonescript.on.connect = function() {};

_$jscmd("src/bonescript.js", "line", 7);

_bonescript.on.connecting = function() {};

_$jscmd("src/bonescript.js", "line", 8);

_bonescript.on.disconnect = function() {};

_$jscmd("src/bonescript.js", "line", 9);

_bonescript.on.connect_failed = function() {};

_$jscmd("src/bonescript.js", "line", 10);

_bonescript.on.error = function(err) {
    _$jscmd("src/bonescript.js", "line", 11);
    throw new Error(err);
};

_$jscmd("src/bonescript.js", "line", 13);

_bonescript.on.reconnect = function() {};

_$jscmd("src/bonescript.js", "line", 14);

_bonescript.on.reconnect_failed = function() {};

_$jscmd("src/bonescript.js", "line", 15);

_bonescript.on.reconnecting = function() {};

_$jscmd("src/bonescript.js", "line", 16);

_bonescript.on.initialized = function() {};

_$jscmd("src/bonescript.js", "line", 18);

(function() {
    if (_$jscmd("src/bonescript.js", "cond", "19_8_30", typeof document == "undefined")) {
        _$jscmd("src/bonescript.js", "line", 20);
        var io = require("socket.io-client");
        _$jscmd("src/bonescript.js", "line", 21);
        var crypto = require("crypto");
        _$jscmd("src/bonescript.js", "line", 22);
        module.exports.startClient = function(host, callback) {
            _$jscmd("src/bonescript.js", "line", 23);
            var passphrase_hash;
            if (_$jscmd("src/bonescript.js", "cond", "24_16_13", host.password)) passphrase_hash = crypto.createHash("sha256").update(host.password).digest("hex");
            _$jscmd("src/bonescript.js", "line", 26);
            //generate sha256 hash for supplied password
            _bonescript.on.initialized = callback;
            _$jscmd("src/bonescript.js", "line", 27);
            var socket = _onSocketIOLoaded(host.address, host.port, io, passphrase_hash);
        };
        _$jscmd("src/bonescript.js", "line", 29);
        return;
    }
    _$jscmd("src/bonescript.js", "line", 31);
    require = myrequire;
    _$jscmd("src/bonescript.js", "line", 32);
    var head = document.getElementsByTagName("head")[0];
    _$jscmd("src/bonescript.js", "line", 33);
    var script = document.createElement("script");
    _$jscmd("src/bonescript.js", "line", 34);
    script.type = "text/javascript";
    _$jscmd("src/bonescript.js", "line", 35);
    script.src = "___INSERT_HOST___/socket.io/socket.io.js";
    _$jscmd("src/bonescript.js", "line", 36);
    script.charset = "UTF-8";
    _$jscmd("src/bonescript.js", "line", 37);
    var scriptObj = head.appendChild(script);
    _$jscmd("src/bonescript.js", "line", 38);
    scriptObj.onload = _onSocketIOLoaded;
})();

function _onSocketIOLoaded(host, port, socketio, passphrase_hash) {
    //console.log("socket.io loaded");
    if (_$jscmd("src/bonescript.js", "cond", "43_8_26", typeof host == "undefined")) host = "___INSERT_HOST___";
    if (_$jscmd("src/bonescript.js", "cond", "44_8_26", typeof port == "undefined")) port = 80;
    if (_$jscmd("src/bonescript.js", "cond", "45_8_58", _$jscmd("src/bonescript.js", "cond", "45_8_30", typeof socketio == "undefined") && _$jscmd("src/bonescript.js", "cond", "45_42_24", typeof io != "undefined"))) socketio = io;
    _$jscmd("src/bonescript.js", "line", 46);
    var socket;
    if (_$jscmd("src/bonescript.js", "cond", "47_8_23", typeof host == "string")) socket = socketio("http://" + host + ":" + port, {
        extraHeaders: {
            Authorization: typeof passphrase_hash != "undefined" ? _$jscmd("src/bonescript.js", "cond", "50_73_15", passphrase_hash) : _$jscmd("src/bonescript.js", "cond", "50_91_4", null)
        }
    }); else socket = socketio("___INSERT_HOST___", {
        port: port
    });
    _$jscmd("src/bonescript.js", "line", 57);
    socket.on("require", getRequireData);
    _$jscmd("src/bonescript.js", "line", 58);
    socket.on("bonescript", _seqcall);
    _$jscmd("src/bonescript.js", "line", 59);
    socket.on("connect", _bonescript.on.connect);
    _$jscmd("src/bonescript.js", "line", 60);
    socket.on("connecting", _bonescript.on.connecting);
    _$jscmd("src/bonescript.js", "line", 61);
    socket.on("disconnect", _bonescript.on.disconnect);
    _$jscmd("src/bonescript.js", "line", 62);
    socket.on("connect_failed", _bonescript.on.connect_failed);
    _$jscmd("src/bonescript.js", "line", 63);
    socket.on("error", _bonescript.on.error);
    _$jscmd("src/bonescript.js", "line", 64);
    socket.on("reconnect", _bonescript.on.reconnect);
    _$jscmd("src/bonescript.js", "line", 65);
    socket.on("reconnect_failed", _bonescript.on.reconnect_failed);
    _$jscmd("src/bonescript.js", "line", 66);
    socket.on("reconnecting", _bonescript.on.reconnecting);
    _$jscmd("src/bonescript.js", "line", 67);
    socket.on("initialized", _bonescript.on.initialized);
    function getRequireData(m) {
        if (_$jscmd("src/bonescript.js", "cond", "70_12_20", _$jscmd("src/bonescript.js", "cond", "70_12_9", !m.module) || _$jscmd("src/bonescript.js", "cond", "70_25_7", !m.data))) throw 'Invalid "require" message sent for "' + m.module + '"';
        _$jscmd("src/bonescript.js", "line", 73);
        //console.log('Initialized module: ' + m.module);
        _bonescript.modules[m.module] = {};
        for (var x in m.data) {
            if (_$jscmd("src/bonescript.js", "cond", "75_16_77", _$jscmd("src/bonescript.js", "cond", "75_16_34", _$jscmd("src/bonescript.js", "cond", "75_16_15", !m.data[x].type) || _$jscmd("src/bonescript.js", "cond", "75_35_15", !m.data[x].name)) || _$jscmd("src/bonescript.js", "cond", "75_54_39", typeof m.data[x].value == "undefined"))) throw 'Invalid data in "require" message sent for "' + m.module + "." + m.data[x] + '"';
            if (_$jscmd("src/bonescript.js", "cond", "77_16_28", m.data[x].type == "function")) {
                // define the function
                if (_$jscmd("src/bonescript.js", "cond", "79_20_16", !m.data[x].value)) throw 'Missing args in "require" message sent for "' + m.module + "." + m.data[x] + '"';
                _$jscmd("src/bonescript.js", "line", 81);
                var myargs = m.data[x].value;
                _$jscmd("src/bonescript.js", "line", 84);
                // eval of objString builds the call data out of arguments passed in
                var objString = "";
                for (var y in myargs) {
                    if (_$jscmd("src/bonescript.js", "cond", "86_24_8", isNaN(y))) continue;
                    // Need to find the source of this bug
                    if (_$jscmd("src/bonescript.js", "cond", "87_24_23", myargs[y] == "callback")) continue;
                    _$jscmd("src/bonescript.js", "line", 88);
                    objString += " if(typeof " + myargs[y] + ' == "function") {\n';
                    _$jscmd("src/bonescript.js", "line", 89);
                    objString += "  " + myargs[y] + " = " + myargs[y] + ".toString();\n";
                    _$jscmd("src/bonescript.js", "line", 90);
                    objString += " }\n";
                    _$jscmd("src/bonescript.js", "line", 91);
                    objString += " calldata." + myargs[y] + " = " + myargs[y] + ";\n";
                }
                _$jscmd("src/bonescript.js", "line", 93);
                var argsString = myargs.join(", ");
                _$jscmd("src/bonescript.js", "line", 94);
                var handyfunc = '_bonescript.modules["' + m.module + '"].' + m.data[x].name + " = " + "function (" + argsString + ") {\n" + " var calldata = {};\n" + objString + " if(callback) {\n" + "  _bonescript._callbacks[_bonescript._seqnum] = callback;\n" + "  calldata.seq = _bonescript._seqnum;\n" + "  calldata.length = callback.length;\n" + "  _bonescript._seqnum++;\n" + " }\n" + ' socket.emit("' + m.module + "$" + m.data[x].name + '", calldata);\n' + "};\n";
                _$jscmd("src/bonescript.js", "line", 107);
                eval(handyfunc);
            } else {
                _$jscmd("src/bonescript.js", "line", 109);
                _bonescript.modules[m.module][m.data[x].name] = m.data[x].value;
            }
        }
        _$jscmd("src/bonescript.js", "line", 112);
        _bonescript.modules[m.module].socket = socket;
        _$jscmd("src/bonescript.js", "line", 113);
        _bonescript.on.initialized();
    }
    _$jscmd("src/bonescript.js", "line", 116);
    return socket;
}

function _seqcall(data) {
    if (_$jscmd("src/bonescript.js", "cond", "120_8_88", _$jscmd("src/bonescript.js", "cond", "120_8_29", typeof data.seq != "number") || _$jscmd("src/bonescript.js", "cond", "120_41_55", typeof _bonescript._callbacks[data.seq] != "function"))) throw "Invalid callback message received: " + JSON.stringify(data);
    if (_$jscmd("src/bonescript.js", "cond", "122_8_44", _bonescript._callbacks[data.seq].length == 1)) _bonescript._callbacks[data.seq](data); else _bonescript._callbacks[data.seq](data.err, data.resp);
    if (_$jscmd("src/bonescript.js", "cond", "126_8_12", data.oneshot)) delete _bonescript._callbacks[data.seq];
}

// Require must be synchronous to be able to return data structures and
// functions and therefore cannot call socket.io. All exported modules must
// be exported ahead of time.
function myrequire(module) {
    if (_$jscmd("src/bonescript.js", "cond", "133_8_33", typeof _bonescript == "undefined")) throw "No BoneScript modules are not currently available";
    if (_$jscmd("src/bonescript.js", "cond", "135_8_49", typeof _bonescript.modules[module] == "undefined")) throw 'Module "' + module + '" is not currently available';
    _$jscmd("src/bonescript.js", "line", 137);
    return _bonescript.modules[module];
}

if (_$jscmd("src/bonescript.js", "cond", "140_4_28", typeof module != "undefined")) {
    _$jscmd("src/bonescript.js", "line", 141);
    module.exports.require = myrequire;
}