
// instrument by jscoverage, do not modifly this file
(function (file, lines, conds, source) {
  var BASE;
  if (typeof global === 'object') {
    BASE = global;
  } else if (typeof window === 'object') {
    BASE = window;
  } else {
    throw new Error('[jscoverage] unknow ENV!');
  }
  if (BASE._$jscoverage) {
    BASE._$jscmd(file, 'init', lines, conds, source);
    return;
  }
  var cov = {};
  /**
   * jsc(file, 'init', lines, condtions)
   * jsc(file, 'line', lineNum)
   * jsc(file, 'cond', lineNum, expr, start, offset)
   */
  function jscmd(file, type, line, express, start, offset) {
    var storage;
    switch (type) {
      case 'init':
        if(cov[file]){
          storage = cov[file];
        } else {
          storage = [];
          for (var i = 0; i < line.length; i ++) {
            storage[line[i]] = 0;
          }
          var condition = express;
          var source = start;
          storage.condition = condition;
          storage.source = source;
        }
        cov[file] = storage;
        break;
      case 'line':
        storage = cov[file];
        storage[line] ++;
        break;
      case 'cond':
        storage = cov[file];
        storage.condition[line] ++;
        return express;
    }
  }

  BASE._$jscoverage = cov;
  BASE._$jscmd = jscmd;
  jscmd(file, 'init', lines, conds, source);
})('src/hw_mainline.js', [1,2,3,4,5,6,7,8,10,18,19,20,21,22,24,26,37,49,103,169,191,207,229,251,267,300,311,399,421,451,12,13,27,34,29,30,31,32,38,39,46,41,42,43,44,50,51,61,78,100,55,71,63,66,67,73,74,80,84,85,91,94,95,105,110,111,166,107,113,115,118,119,121,122,124,127,130,131,134,137,146,148,150,152,155,156,160,171,178,188,173,174,175,176,181,183,184,185,193,194,200,203,204,198,209,211,214,219,222,224,230,247,248,232,244,245,237,234,235,239,240,264,254,260,268,269,287,292,297,272,284,285,277,274,275,279,280,289,290,294,295,301,303,304,305,306,308,313,396,315,316,317,318,319,320,328,330,333,335,338,339,341,342,348,349,350,354,359,361,362,373,375,381,393,394,400,417,418,422,427,428,435,436,448,430,433,438,442,446], {"10_32_4":0,"10_39_5":0,"11_4_5":0,"40_8_33":0,"53_8_32":0,"56_12_6":0,"62_12_3":0,"64_16_5":0,"65_16_20":0,"72_12_20":0,"79_12_6":0,"82_16_5":0,"83_16_20":0,"90_8_8":0,"97_16_5":0,"104_8_5":0,"106_8_18":0,"108_12_24":0,"108_12_8":0,"108_24_12":0,"112_8_6":0,"114_12_18":0,"126_19_40":0,"126_19_19":0,"126_42_17":0,"128_16_21":0,"133_12_9":0,"138_12_5":0,"141_8_19":0,"147_12_5":0,"149_12_5":0,"151_12_5":0,"153_12_5":0,"154_12_23":0,"154_12_11":0,"154_27_8":0,"157_16_5":0,"159_12_7":0,"165_8_8":0,"170_8_5":0,"172_8_22":0,"180_8_24":0,"192_8_5":0,"196_8_7":0,"197_12_5":0,"201_8_5":0,"208_8_39":0,"210_12_7":0,"213_12_38":0,"217_8_5":0,"218_8_8":0,"231_8_8":0,"233_16_3":0,"238_16_20":0,"252_8_30":0,"253_12_5":0,"256_8_30":0,"257_12_5":0,"259_8_8":0,"270_8_5":0,"271_8_8":0,"273_16_3":0,"278_16_20":0,"288_8_17":0,"293_8_17":0,"312_8_5":0,"322_12_5":0,"325_12_25":0,"325_12_11":0,"325_27_10":0,"326_16_20":0,"327_20_5":0,"329_20_5":0,"331_23_20":0,"332_20_5":0,"334_20_5":0,"347_24_5":0,"352_24_5":0,"353_24_20":0,"355_28_10":0,"370_20_11":0,"372_28_5":0,"380_28_5":0,"383_28_5":0,"386_20_5":0,"388_20_11":0,"429_8_34":0,"432_8_36":0,"437_8_14":0,"437_8_1":0,"437_13_9":0,"439_12_41":0,"441_8_19":0,"441_8_1":0,"441_13_14":0,"443_12_46":0}, ["var fs = require('fs');","var async = require('async');","var my = require('./my');","var parse = require('./parse');","var eeprom = require('./eeprom');","var util = require('util');","var winston = require('winston');","var shell = require('shelljs');","","var debug = process.env.DEBUG ? true : false;","if (debug) {","    winston.remove(winston.transports.Console);","    winston.add(winston.transports.Console, {","        colorize: true","    });","}","","var gpioFile = {};","var pwmPrefix = {};","var ainPrefix = \"/sys/bus/iio/devices/iio:device0\";","var SLOTS = \"/sys/devices/platform/bone_capemgr/slots\";","var AINdts = \"BB-ADC\";","","var logfile = '/var/lib/cloud9/bonescript.log';","","var readPWMFreqAndValue = function (pin, pwm) {","    var mode = {};","    try {","        var period = fs.readFileSync(pwmPrefix[pin.pwm.name] + '/period_ns');","        var duty = fs.readFileSync(pwmPrefix[pin.pwm.name] + '/duty_ns');","        mode.freq = 1.0e9 / period;","        mode.value = duty / period;","    } catch (ex) {}","    return (mode);","};","","var readGPIODirection = function (n, gpio) {","    var mode = {};","    var directionFile = \"/sys/class/gpio/gpio\" + n + \"/direction\";","    if (my.file_existsSync(directionFile)) {","        mode.active = true;","        var direction = fs.readFileSync(directionFile, 'utf-8');","        direction = direction.replace(/^\\s+|\\s+$/g, '');","        mode.direction = direction;","    }","    return (mode);","};","","var readPinMux = function (pin, mode, callback) {","    var pinctrlFile = '/sys/kernel/debug/pinctrl/44e10800.pinmux/pins';","    var muxRegOffset = parseInt(pin.muxRegOffset, 16);","    //handle the case when debugfs not mounted","    if (!my.file_existsSync(pinctrlFile)) {","        //exit code is 1 if /sys/kernel/debug not mounted","        const umount = shell.exec('mountpoint -q /sys/kernel/debug/').code;","        if (umount)","            shell.exec('mount -t debugfs none /sys/kernel/debug/', {","                silent: true","            });","    }","    var readPinctrl = function (err, data) {","        if (err) {","            mode.err = 'readPinctrl error: ' + err;","            if (debug) winston.debug(mode.err);","            if (callback.length == 1) {","                winston.warning(\"single argument callbacks will be deprecated.please use node-style error-first callbacks: callback(err,response)\");","                callback(mode);","            } else","                callback(mode.err, data);","        }","        mode = parse.modeFromPinctrl(data, muxRegOffset, 0x44e10800, mode);","        if (callback.length == 1) {","            winston.warning(\"single argument callbacks will be deprecated.please use node-style error-first callbacks: callback(err,response)\");","            callback(mode);","        } else","            callback(null, mode);","    };","    var tryPinctrl = function (exists) {","        if (exists) {","            fs.readFile(pinctrlFile, 'utf8', readPinctrl);","        } else {","            if (debug) winston.debug('getPinMode(' + pin.key + '): no valid mux data');","            if (callback.length == 1) {","                winston.warning(\"single argument callbacks will be deprecated.please use node-style error-first callbacks: callback(err,response)\");","                callback(mode);","            } else","                callback('readPinMux error: no valid mux data', mode);","        }","    };","    if (callback) {","        my.file_exists(pinctrlFile, tryPinctrl);","    } else {","        try {","            var data2 = fs.readFileSync(pinctrlFile, 'utf8');","            mode = parse.modeFromPinctrl(data2, muxRegOffset, 0x44e10800, mode);","        } catch (ex) {","            if (debug) winston.debug('getPinMode(' + pin.key + '): ' + ex);","        }","    }","    return (mode);","};","","var setPinMode = function (pin, pinData, template, resp, callback) {","    if (debug) winston.debug('hw.setPinMode(' + [pin.key, pinData, template, JSON.stringify(resp)] + ');');","    var p = \"ocp:\" + pin.key + \"_pinmux\";","    if (!pin.universalName) {","        pin.universalName = [p];","        if (pin.ball && pin.ball.ZCZ) pin.universalName.push(\"ocp:\" + pin.ball.ZCZ + \"_pinmux\");","    }","    var pinmux = my.find_sysfsFile(p, my.is_ocp(), pin.universalName);","    gpioFile[pin.key] = '/sys/class/gpio/gpio' + pin.gpio + '/value';","    if (pinmux) {","        var state = undefined;","        if ((pinData & 7) == 7) {","            state = 'gpio';","            switch (pinData & 0x18) {","            case 0x00:","                state = 'gpio_pd';","                break;","            case 0x10:","                state = 'gpio_pu';","                break;","            default:","                break;","            }","        } else if (template == 'bspwm' || template == 'pwm') {","            state = \"pwm\";","            if (pin.pwm.universalMode) state = pin.pwm.universalMode;","        } else {","            resp.err = 'Unknown pin mode template';","            winston.error(resp.err);","        }","        if (!resp.err) {","            fs.writeFileSync(pinmux + \"/state\", state);","        }","    } else {","        resp.err = 'No pinmux for ' + pin.key;","        if (debug) winston.debug(resp.err);","    }","","    if (template == 'bspwm') {","        // Buld a path like: /sys/devices/platform/ocp/48304000.epwmss/48304200.ehrpwm/pwm/pwmchip5/pwm5-:0","        // pin.pwm.chip looks up the first address and pin.pwm.addr looks up the second","        // file_find figures which pwmchip to use","        // pin.pwm.index tells with half of the PWM to use (0 or 1)","        var chipPath = my.file_find('/sys/devices/platform/ocp', pin.pwm.chip, 1);","        if (debug) winston.debug(\"chipPath = \" + chipPath);","        var addrPath = my.file_find(chipPath, pin.pwm.addr, 1);","        if (debug) winston.debug(\"addrPath = \" + addrPath);","        var pwmchipPath = my.file_find(addrPath + '/pwm', 'pwmchip', 1);","        if (debug) winston.debug(\"pwmchipPath = \" + pwmchipPath);","        var pwmPath = my.file_find(pwmchipPath, \"pwm.*\" + pin.pwm.index + \"$\", 1);","        if (debug) winston.debug(\"pwmPath = \" + pwmPath);","        if (pwmchipPath && !pwmPath) {","            fs.appendFileSync(pwmchipPath + '/export', pin.pwm.index);","            pwmPath = my.file_find(pwmchipPath, \"pwm.*\" + pin.pwm.index + \"$\", 1);","            if (debug) winston.debug(\"pwmPath = \" + pwmPath);","        }","        if (pwmPath) {","            pwmPrefix[pin.pwm.name] = pwmPath;","        }","        //fs.appendFileSync(pwmPrefix[pin.pwm.name]+'/enable', 1);","    }","","    if (callback) callback(resp);","    return (resp);","};","","var setLEDPinToGPIO = function (pin, resp) {","    if (debug) winston.debug('setLEDPinTGPIO: ' + pin.key);","    var path;","    if (Array.isArray(pin.led)) {","        resp.err = \"Unable to handle LED definition as array \" + pin.led;","        winston.error(resp.err);","        resp.value = false;","        return (resp);","    }","    path = \"/sys/class/leds/\" + pin.led + \"/trigger\";","","    if (my.file_existsSync(path)) {","        fs.writeFileSync(path, \"gpio\");","    } else {","        resp.err = \"Unable to find LED \" + pin.led;","        winston.error(resp.err);","        resp.value = false;","    }","","    return (resp);","};","","var exportGPIOControls = function (pin, direction, resp, callback) {","    if (debug) winston.debug('hw.exportGPIOControls(' + [pin.key, direction, resp] + ');');","    var n = pin.gpio;","    var exists = my.file_existsSync(gpioFile[pin.key]);","","    if (!exists) {","        if (debug) winston.debug(\"exporting gpio: \" + n);","        fs.writeFileSync(\"/sys/class/gpio/export\", \"\" + n, null);","    }","    var directionFile = \"/sys/class/gpio/gpio\" + n + \"/direction\";","    if (debug) winston.debug('Writing GPIO direction(' + direction + ') to ' +","        directionFile + ');');","    fs.writeFileSync(directionFile, direction);","    return (resp);","};","","var writeGPIOValue = function (pin, value, callback) {","    if (typeof gpioFile[pin.key] == 'undefined') {","        gpioFile[pin.key] = '/sys/class/gpio/gpio' + pin.gpio + '/value';","        if (pin.led) {","            gpioFile[pin.key] = \"/sys/class/leds/\" + pin.led + \"/brightness\";","        }","        if (!my.file_existsSync(gpioFile[pin.key])) {","            winston.error(\"Unable to find gpio: \" + gpioFile[pin.key]);","        }","    }","    if (debug) winston.debug(\"gpioFile = \" + gpioFile[pin.key]);","    if (callback) {","        fs.writeFile(gpioFile[pin.key], '' + value, null, callback);","    } else {","        try {","            fs.writeFileSync(gpioFile[pin.key], '' + value, null);","        } catch (ex) {","            winston.error(\"Unable to write to \" + gpioFile[pin.key]);","        }","    }","};","","var readGPIOValue = function (pin, resp, callback) {","    var gpioFile = '/sys/class/gpio/gpio' + pin.gpio + '/value';","    if (callback) {","        var readFile = function (err, data) {","            if (err) {","                resp.err = 'digitalRead error: ' + err;","                winston.error(resp.err);","            }","            resp.value = parseInt(data, 2);","            if (callback.length == 1) {","                winston.warning(\"single argument callbacks will be deprecated.please use node-style error-first callbacks: callback(err,response)\");","                callback(resp);","            } else","                callback(resp.err, resp.value);","        };","        fs.readFile(gpioFile, readFile);","        return (true);","    }","    resp.value = parseInt(fs.readFileSync(gpioFile), 2);","    return (resp);","};","","var enableAIN = function (callback) {","    if (!my.file_existsSync(ainPrefix)) {","        if (debug) winston.debug('enableAIN: loading ' + AINdts);","        fs.writeFileSync(SLOTS, AINdts); // Loads AINdts","    }","    if (!my.file_existsSync(ainPrefix)) {","        if (debug) winston.debug('enableAIN: load of ' + AINdts + ' failed');","    }","    if (callback) {","        callback({","            'path': ainPrefix","        });","    }","    return (ainPrefix);","};","","var readAIN = function (pin, resp, callback) {","    var maxValue = 4095;","    var ainFile = ainPrefix + '/in_voltage' + pin.ain.toString() + '_raw';","    if (debug) winston.debug(\"readAIN: ainFile=\" + ainFile);","    if (callback) {","        var readFile = function (err, data) {","            if (err) {","                resp.err = 'analogRead error: ' + err;","                winston.error(resp.err);","            }","            resp.value = parseInt(data, 10) / maxValue;","            if (callback.length == 1) {","                winston.warning(\"single argument callbacks will be deprecated.please use node-style error-first callbacks: callback(err,response)\");","                callback(resp);","            } else","                callback(resp.err, resp.value);","        };","        fs.readFile(ainFile, readFile);","        return (resp);","    }","    resp.value = parseInt(fs.readFileSync(ainFile), 10);","    if (isNaN(resp.value)) {","        resp.err = 'analogRead(' + pin.key + ') returned ' + resp.value;","        winston.error(resp.err);","    }","    resp.value = resp.value / maxValue;","    if (isNaN(resp.value)) {","        resp.err = 'analogRead(' + pin.key + ') scaled to ' + resp.value;","        winston.error(resp.err);","    }","    return (resp);","};","","var writeGPIOEdge = function (pin, mode) {","    fs.writeFileSync('/sys/class/gpio/gpio' + pin.gpio + '/edge', mode);","","    var resp = {};","    resp.gpioFile = '/sys/class/gpio/gpio' + pin.gpio + '/value';","    resp.valuefd = fs.openSync(resp.gpioFile, 'r');","    resp.value = new Buffer(1);","","    return (resp);","};","","var writePWMFreqAndValue = function (pin, pwm, freq, value, resp, callback) {","    if (debug) winston.debug('hw.writePWMFreqAndValue(' + [pin.key, util.inspect(pwm), freq, value, resp] + ');');","    var path = pwmPrefix[pin.pwm.name];","    try {","        var period = Math.round(1.0e9 / freq); // period in ns","        var duty = Math.round(period * value);","        var currentPeriod = fs.readFileSync(path + '/period'); //read Current Period for smooth PWM","        var currentDuty = fs.readFileSync(path + '/duty_cycle'); //read Current Duty for smooth PWM","        var pwmEnabled = Number(fs.readFileSync(path + '/enable')); //check whether PWM is enabled","        var disablePWM = !(duty * freq); //when duty||frequency ==0 , disablePWM to avoid spikes","","        if (debug) winston.debug('hw.writePWMFreqAndValue: pwm.freq=' + pwm.freq +","            ', freq=' + freq + ', period=' + period);","        //smooth PWM Implementation","        if (!disablePWM && pwmEnabled) {","            if (period > currentDuty) {","                if (debug) winston.debug('Updating PWM period: ' + period);","                fs.writeFileSync(path + '/period', period);","                if (debug) winston.debug('Updating PWM duty: ' + duty);","                fs.writeFileSync(path + '/duty_cycle', duty);","            } else if (duty < currentPeriod) {","                if (debug) winston.debug('Updating PWM duty: ' + duty);","                fs.writeFileSync(path + '/duty_cycle', duty);","                if (debug) winston.debug('Updating PWM period: ' + period);","                fs.writeFileSync(path + '/period', period);","            }","        } else {","            var tryAgain = true;","            var tries = 0;","","            async.until(function () { //try accessing 'path/enable' until no EACCES error is thrown (max 10 times)","                return !tryAgain; //to account for udev delay","            }, stopPWM, updatePeriodAndDuty); //async.until(test,iteratee,callback)","","            function stopPWM(callback) {","                try {","                    if (debug) winston.debug('Stopping PWM');","                    fs.writeFileSync(path + '/enable', \"0\\n\");","                    callback(null); //if no error","                    tryAgain = false; //do not try again","                } catch (ex2) {","                    if (debug) winston.debug('Error stopping PWM: ' + ex2);","                    if (ex2.code == 'EACCES') {","                        tries++;","                        if (tries < 10)","                            tryAgain = true; //if EACCES error thrown try again for a maximum of 10 times","                        else","                            tryAgain = false;","                        callback(null); //async.until requires an err first format callback &","                    } else { //if there is an error iteration stops, so neglect the error if EACCES thrown","                        tryAgain = false;","                        callback(ex2);","                    }","                }","            }","","            function updatePeriodAndDuty() {","                // It appears that the first time you set the pwm you have to","                // set the period before you set the duty_cycle","                if (!disablePWM) { //if duty||frequency == 0 do not re-enable PWM (to avoid spikes)","                    try {","                        if (debug) winston.debug('Updating PWM period: ' + period);","                        fs.writeFileSync(path + '/period', period + \"\\n\");","                    } catch (ex2) {","                        winston.info('Unable to update PWM period, period is set to ' +","                            currentPeriod +","                            \"\\tIs other half of PWM enabled?\");","                    }","                    try {","                        if (debug) winston.debug('Starting PWM');","                        fs.writeFileSync(path + '/enable', \"1\\n\");","                    } catch (ex2) {","                        if (debug) winston.debug('Error starting PWM: ' + ex2);","                    }","                }","                if (debug) winston.debug('Updating PWM duty: ' + duty);","                //if(duty == 0) winston.error('Updating PWM duty: ' + duty);","                if (!disablePWM)","                    fs.writeFileSync(path + '/duty_cycle', duty + \"\\n\");","            }","        }","    } catch (ex) {","        resp.err = 'error updating PWM freq and value: ' + path + ', ' + ex;","        winston.error(resp.err);","    }","    return (resp);","};","","var readEeproms = function (eeproms) {","    var EepromFiles = {","        '/sys/bus/i2c/devices/0-0050/0-00500/nvmem': {","            type: 'bone'","        },","        '/sys/bus/i2c/devices/2-0054/2-00540/nvmem': {","            type: 'cape'","        },","        '/sys/bus/i2c/devices/2-0055/2-00550/nvmem': {","            type: 'cape'","        },","        '/sys/bus/i2c/devices/2-0056/2-00560/nvmem': {","            type: 'cape'","        },","        '/sys/bus/i2c/devices/2-0057/2-00570/nvmem': {","            type: 'cape'","        }","    };","    eeproms = eeprom.readEeproms(EepromFiles);","    return (eeproms);","};","","var readPlatform = function (platform) {","    var eeproms = eeprom.readEeproms({","        '/sys/bus/i2c/devices/0-0050/0-00500/nvmem': {","            type: 'bone'","        }","    });","    var x = eeproms['/sys/bus/i2c/devices/0-0050/0-00500/nvmem'];","    platform.name = fs.readFileSync('/proc/device-tree/model', 'ascii').trim().replace(/\\0/g, '');","    if (platform.name.indexOf('Green') > 0) {","        platform.name = platform.name.replace('TI AM335x', 'SeeedStudio')","    }","    if (platform.name.indexOf('Arduino') > 0) {","        platform.name = platform.name.replace('TI AM335x', '')","    }","    platform.name = platform.name.replace('TI AM335x BeagleBone', 'BeagleBoard.org BeagleBone');","    platform.name = platform.name.replace('TI AM5728 BeagleBoard-X15', 'BeagleBoard.org BeagleBoard-X15');","    if (x && x.version) {","        platform.version = x.version;","        if (!platform.version.match(/^[\\040-\\176]*$/)) delete platform.version;","    }","    if (x && x.serialNumber) {","        platform.serialNumber = x.serialNumber;","        if (!platform.serialNumber.match(/^[\\040-\\176]*$/)) delete platform.serialNumber;","    }","    try {","        platform.dogtag = fs.readFileSync('/etc/dogtag', 'ascii');","    } catch (ex) {}","    return (platform);","};","","module.exports = {","    logfile: logfile,","    readPWMFreqAndValue: readPWMFreqAndValue,","    readGPIODirection: readGPIODirection,","    readPinMux: readPinMux,","    setPinMode: setPinMode,","    setLEDPinToGPIO: setLEDPinToGPIO,","    exportGPIOControls: exportGPIOControls,","    writeGPIOValue: writeGPIOValue,","    readGPIOValue: readGPIOValue,","    enableAIN: enableAIN,","    readAIN: readAIN,","    writeGPIOEdge: writeGPIOEdge,","    writePWMFreqAndValue: writePWMFreqAndValue,","    readEeproms: readEeproms,","    readPlatform: readPlatform","}"]);
_$jscmd("src/hw_mainline.js", "line", 1);

var fs = require("fs");

_$jscmd("src/hw_mainline.js", "line", 2);

var async = require("async");

_$jscmd("src/hw_mainline.js", "line", 3);

var my = require("./my");

_$jscmd("src/hw_mainline.js", "line", 4);

var parse = require("./parse");

_$jscmd("src/hw_mainline.js", "line", 5);

var eeprom = require("./eeprom");

_$jscmd("src/hw_mainline.js", "line", 6);

var util = require("util");

_$jscmd("src/hw_mainline.js", "line", 7);

var winston = require("winston");

_$jscmd("src/hw_mainline.js", "line", 8);

var shell = require("shelljs");

_$jscmd("src/hw_mainline.js", "line", 10);

var debug = process.env.DEBUG ? _$jscmd("src/hw_mainline.js", "cond", "10_32_4", true) : _$jscmd("src/hw_mainline.js", "cond", "10_39_5", false);

if (_$jscmd("src/hw_mainline.js", "cond", "11_4_5", debug)) {
    _$jscmd("src/hw_mainline.js", "line", 12);
    winston.remove(winston.transports.Console);
    _$jscmd("src/hw_mainline.js", "line", 13);
    winston.add(winston.transports.Console, {
        colorize: true
    });
}

_$jscmd("src/hw_mainline.js", "line", 18);

var gpioFile = {};

_$jscmd("src/hw_mainline.js", "line", 19);

var pwmPrefix = {};

_$jscmd("src/hw_mainline.js", "line", 20);

var ainPrefix = "/sys/bus/iio/devices/iio:device0";

_$jscmd("src/hw_mainline.js", "line", 21);

var SLOTS = "/sys/devices/platform/bone_capemgr/slots";

_$jscmd("src/hw_mainline.js", "line", 22);

var AINdts = "BB-ADC";

_$jscmd("src/hw_mainline.js", "line", 24);

var logfile = "/var/lib/cloud9/bonescript.log";

_$jscmd("src/hw_mainline.js", "line", 26);

var readPWMFreqAndValue = function(pin, pwm) {
    _$jscmd("src/hw_mainline.js", "line", 27);
    var mode = {};
    try {
        _$jscmd("src/hw_mainline.js", "line", 29);
        var period = fs.readFileSync(pwmPrefix[pin.pwm.name] + "/period_ns");
        _$jscmd("src/hw_mainline.js", "line", 30);
        var duty = fs.readFileSync(pwmPrefix[pin.pwm.name] + "/duty_ns");
        _$jscmd("src/hw_mainline.js", "line", 31);
        mode.freq = 1e9 / period;
        _$jscmd("src/hw_mainline.js", "line", 32);
        mode.value = duty / period;
    } catch (ex) {}
    _$jscmd("src/hw_mainline.js", "line", 34);
    return mode;
};

_$jscmd("src/hw_mainline.js", "line", 37);

var readGPIODirection = function(n, gpio) {
    _$jscmd("src/hw_mainline.js", "line", 38);
    var mode = {};
    _$jscmd("src/hw_mainline.js", "line", 39);
    var directionFile = "/sys/class/gpio/gpio" + n + "/direction";
    if (_$jscmd("src/hw_mainline.js", "cond", "40_8_33", my.file_existsSync(directionFile))) {
        _$jscmd("src/hw_mainline.js", "line", 41);
        mode.active = true;
        _$jscmd("src/hw_mainline.js", "line", 42);
        var direction = fs.readFileSync(directionFile, "utf-8");
        _$jscmd("src/hw_mainline.js", "line", 43);
        direction = direction.replace(/^\s+|\s+$/g, "");
        _$jscmd("src/hw_mainline.js", "line", 44);
        mode.direction = direction;
    }
    _$jscmd("src/hw_mainline.js", "line", 46);
    return mode;
};

_$jscmd("src/hw_mainline.js", "line", 49);

var readPinMux = function(pin, mode, callback) {
    _$jscmd("src/hw_mainline.js", "line", 50);
    var pinctrlFile = "/sys/kernel/debug/pinctrl/44e10800.pinmux/pins";
    _$jscmd("src/hw_mainline.js", "line", 51);
    var muxRegOffset = parseInt(pin.muxRegOffset, 16);
    //handle the case when debugfs not mounted
    if (_$jscmd("src/hw_mainline.js", "cond", "53_8_32", !my.file_existsSync(pinctrlFile))) {
        _$jscmd("src/hw_mainline.js", "line", 55);
        //exit code is 1 if /sys/kernel/debug not mounted
        const umount = shell.exec("mountpoint -q /sys/kernel/debug/").code;
        if (_$jscmd("src/hw_mainline.js", "cond", "56_12_6", umount)) shell.exec("mount -t debugfs none /sys/kernel/debug/", {
            silent: true
        });
    }
    _$jscmd("src/hw_mainline.js", "line", 61);
    var readPinctrl = function(err, data) {
        if (_$jscmd("src/hw_mainline.js", "cond", "62_12_3", err)) {
            _$jscmd("src/hw_mainline.js", "line", 63);
            mode.err = "readPinctrl error: " + err;
            if (_$jscmd("src/hw_mainline.js", "cond", "64_16_5", debug)) winston.debug(mode.err);
            if (_$jscmd("src/hw_mainline.js", "cond", "65_16_20", callback.length == 1)) {
                _$jscmd("src/hw_mainline.js", "line", 66);
                winston.warning("single argument callbacks will be deprecated.please use node-style error-first callbacks: callback(err,response)");
                _$jscmd("src/hw_mainline.js", "line", 67);
                callback(mode);
            } else callback(mode.err, data);
        }
        _$jscmd("src/hw_mainline.js", "line", 71);
        mode = parse.modeFromPinctrl(data, muxRegOffset, 1155598336, mode);
        if (_$jscmd("src/hw_mainline.js", "cond", "72_12_20", callback.length == 1)) {
            _$jscmd("src/hw_mainline.js", "line", 73);
            winston.warning("single argument callbacks will be deprecated.please use node-style error-first callbacks: callback(err,response)");
            _$jscmd("src/hw_mainline.js", "line", 74);
            callback(mode);
        } else callback(null, mode);
    };
    _$jscmd("src/hw_mainline.js", "line", 78);
    var tryPinctrl = function(exists) {
        if (_$jscmd("src/hw_mainline.js", "cond", "79_12_6", exists)) {
            _$jscmd("src/hw_mainline.js", "line", 80);
            fs.readFile(pinctrlFile, "utf8", readPinctrl);
        } else {
            if (_$jscmd("src/hw_mainline.js", "cond", "82_16_5", debug)) winston.debug("getPinMode(" + pin.key + "): no valid mux data");
            if (_$jscmd("src/hw_mainline.js", "cond", "83_16_20", callback.length == 1)) {
                _$jscmd("src/hw_mainline.js", "line", 84);
                winston.warning("single argument callbacks will be deprecated.please use node-style error-first callbacks: callback(err,response)");
                _$jscmd("src/hw_mainline.js", "line", 85);
                callback(mode);
            } else callback("readPinMux error: no valid mux data", mode);
        }
    };
    if (_$jscmd("src/hw_mainline.js", "cond", "90_8_8", callback)) {
        _$jscmd("src/hw_mainline.js", "line", 91);
        my.file_exists(pinctrlFile, tryPinctrl);
    } else {
        try {
            _$jscmd("src/hw_mainline.js", "line", 94);
            var data2 = fs.readFileSync(pinctrlFile, "utf8");
            _$jscmd("src/hw_mainline.js", "line", 95);
            mode = parse.modeFromPinctrl(data2, muxRegOffset, 1155598336, mode);
        } catch (ex) {
            if (_$jscmd("src/hw_mainline.js", "cond", "97_16_5", debug)) winston.debug("getPinMode(" + pin.key + "): " + ex);
        }
    }
    _$jscmd("src/hw_mainline.js", "line", 100);
    return mode;
};

_$jscmd("src/hw_mainline.js", "line", 103);

var setPinMode = function(pin, pinData, template, resp, callback) {
    if (_$jscmd("src/hw_mainline.js", "cond", "104_8_5", debug)) winston.debug("hw.setPinMode(" + [ pin.key, pinData, template, JSON.stringify(resp) ] + ");");
    _$jscmd("src/hw_mainline.js", "line", 105);
    var p = "ocp:" + pin.key + "_pinmux";
    if (_$jscmd("src/hw_mainline.js", "cond", "106_8_18", !pin.universalName)) {
        _$jscmd("src/hw_mainline.js", "line", 107);
        pin.universalName = [ p ];
        if (_$jscmd("src/hw_mainline.js", "cond", "108_12_24", _$jscmd("src/hw_mainline.js", "cond", "108_12_8", pin.ball) && _$jscmd("src/hw_mainline.js", "cond", "108_24_12", pin.ball.ZCZ))) pin.universalName.push("ocp:" + pin.ball.ZCZ + "_pinmux");
    }
    _$jscmd("src/hw_mainline.js", "line", 110);
    var pinmux = my.find_sysfsFile(p, my.is_ocp(), pin.universalName);
    _$jscmd("src/hw_mainline.js", "line", 111);
    gpioFile[pin.key] = "/sys/class/gpio/gpio" + pin.gpio + "/value";
    if (_$jscmd("src/hw_mainline.js", "cond", "112_8_6", pinmux)) {
        _$jscmd("src/hw_mainline.js", "line", 113);
        var state = undefined;
        if (_$jscmd("src/hw_mainline.js", "cond", "114_12_18", (pinData & 7) == 7)) {
            _$jscmd("src/hw_mainline.js", "line", 115);
            state = "gpio";
            switch (pinData & 24) {
              case 0:
                _$jscmd("src/hw_mainline.js", "line", 118);
                state = "gpio_pd";
                _$jscmd("src/hw_mainline.js", "line", 119);
                break;

              case 16:
                _$jscmd("src/hw_mainline.js", "line", 121);
                state = "gpio_pu";
                _$jscmd("src/hw_mainline.js", "line", 122);
                break;

              default:
                _$jscmd("src/hw_mainline.js", "line", 124);
                break;
            }
        } else if (_$jscmd("src/hw_mainline.js", "cond", "126_19_40", _$jscmd("src/hw_mainline.js", "cond", "126_19_19", template == "bspwm") || _$jscmd("src/hw_mainline.js", "cond", "126_42_17", template == "pwm"))) {
            _$jscmd("src/hw_mainline.js", "line", 127);
            state = "pwm";
            if (_$jscmd("src/hw_mainline.js", "cond", "128_16_21", pin.pwm.universalMode)) state = pin.pwm.universalMode;
        } else {
            _$jscmd("src/hw_mainline.js", "line", 130);
            resp.err = "Unknown pin mode template";
            _$jscmd("src/hw_mainline.js", "line", 131);
            winston.error(resp.err);
        }
        if (_$jscmd("src/hw_mainline.js", "cond", "133_12_9", !resp.err)) {
            _$jscmd("src/hw_mainline.js", "line", 134);
            fs.writeFileSync(pinmux + "/state", state);
        }
    } else {
        _$jscmd("src/hw_mainline.js", "line", 137);
        resp.err = "No pinmux for " + pin.key;
        if (_$jscmd("src/hw_mainline.js", "cond", "138_12_5", debug)) winston.debug(resp.err);
    }
    if (_$jscmd("src/hw_mainline.js", "cond", "141_8_19", template == "bspwm")) {
        _$jscmd("src/hw_mainline.js", "line", 146);
        // Buld a path like: /sys/devices/platform/ocp/48304000.epwmss/48304200.ehrpwm/pwm/pwmchip5/pwm5-:0
        // pin.pwm.chip looks up the first address and pin.pwm.addr looks up the second
        // file_find figures which pwmchip to use
        // pin.pwm.index tells with half of the PWM to use (0 or 1)
        var chipPath = my.file_find("/sys/devices/platform/ocp", pin.pwm.chip, 1);
        if (_$jscmd("src/hw_mainline.js", "cond", "147_12_5", debug)) winston.debug("chipPath = " + chipPath);
        _$jscmd("src/hw_mainline.js", "line", 148);
        var addrPath = my.file_find(chipPath, pin.pwm.addr, 1);
        if (_$jscmd("src/hw_mainline.js", "cond", "149_12_5", debug)) winston.debug("addrPath = " + addrPath);
        _$jscmd("src/hw_mainline.js", "line", 150);
        var pwmchipPath = my.file_find(addrPath + "/pwm", "pwmchip", 1);
        if (_$jscmd("src/hw_mainline.js", "cond", "151_12_5", debug)) winston.debug("pwmchipPath = " + pwmchipPath);
        _$jscmd("src/hw_mainline.js", "line", 152);
        var pwmPath = my.file_find(pwmchipPath, "pwm.*" + pin.pwm.index + "$", 1);
        if (_$jscmd("src/hw_mainline.js", "cond", "153_12_5", debug)) winston.debug("pwmPath = " + pwmPath);
        if (_$jscmd("src/hw_mainline.js", "cond", "154_12_23", _$jscmd("src/hw_mainline.js", "cond", "154_12_11", pwmchipPath) && _$jscmd("src/hw_mainline.js", "cond", "154_27_8", !pwmPath))) {
            _$jscmd("src/hw_mainline.js", "line", 155);
            fs.appendFileSync(pwmchipPath + "/export", pin.pwm.index);
            _$jscmd("src/hw_mainline.js", "line", 156);
            pwmPath = my.file_find(pwmchipPath, "pwm.*" + pin.pwm.index + "$", 1);
            if (_$jscmd("src/hw_mainline.js", "cond", "157_16_5", debug)) winston.debug("pwmPath = " + pwmPath);
        }
        if (_$jscmd("src/hw_mainline.js", "cond", "159_12_7", pwmPath)) {
            _$jscmd("src/hw_mainline.js", "line", 160);
            pwmPrefix[pin.pwm.name] = pwmPath;
        }
    }
    if (_$jscmd("src/hw_mainline.js", "cond", "165_8_8", callback)) callback(resp);
    _$jscmd("src/hw_mainline.js", "line", 166);
    return resp;
};

_$jscmd("src/hw_mainline.js", "line", 169);

var setLEDPinToGPIO = function(pin, resp) {
    if (_$jscmd("src/hw_mainline.js", "cond", "170_8_5", debug)) winston.debug("setLEDPinTGPIO: " + pin.key);
    _$jscmd("src/hw_mainline.js", "line", 171);
    var path;
    if (_$jscmd("src/hw_mainline.js", "cond", "172_8_22", Array.isArray(pin.led))) {
        _$jscmd("src/hw_mainline.js", "line", 173);
        resp.err = "Unable to handle LED definition as array " + pin.led;
        _$jscmd("src/hw_mainline.js", "line", 174);
        winston.error(resp.err);
        _$jscmd("src/hw_mainline.js", "line", 175);
        resp.value = false;
        _$jscmd("src/hw_mainline.js", "line", 176);
        return resp;
    }
    _$jscmd("src/hw_mainline.js", "line", 178);
    path = "/sys/class/leds/" + pin.led + "/trigger";
    if (_$jscmd("src/hw_mainline.js", "cond", "180_8_24", my.file_existsSync(path))) {
        _$jscmd("src/hw_mainline.js", "line", 181);
        fs.writeFileSync(path, "gpio");
    } else {
        _$jscmd("src/hw_mainline.js", "line", 183);
        resp.err = "Unable to find LED " + pin.led;
        _$jscmd("src/hw_mainline.js", "line", 184);
        winston.error(resp.err);
        _$jscmd("src/hw_mainline.js", "line", 185);
        resp.value = false;
    }
    _$jscmd("src/hw_mainline.js", "line", 188);
    return resp;
};

_$jscmd("src/hw_mainline.js", "line", 191);

var exportGPIOControls = function(pin, direction, resp, callback) {
    if (_$jscmd("src/hw_mainline.js", "cond", "192_8_5", debug)) winston.debug("hw.exportGPIOControls(" + [ pin.key, direction, resp ] + ");");
    _$jscmd("src/hw_mainline.js", "line", 193);
    var n = pin.gpio;
    _$jscmd("src/hw_mainline.js", "line", 194);
    var exists = my.file_existsSync(gpioFile[pin.key]);
    if (_$jscmd("src/hw_mainline.js", "cond", "196_8_7", !exists)) {
        if (_$jscmd("src/hw_mainline.js", "cond", "197_12_5", debug)) winston.debug("exporting gpio: " + n);
        _$jscmd("src/hw_mainline.js", "line", 198);
        fs.writeFileSync("/sys/class/gpio/export", "" + n, null);
    }
    _$jscmd("src/hw_mainline.js", "line", 200);
    var directionFile = "/sys/class/gpio/gpio" + n + "/direction";
    if (_$jscmd("src/hw_mainline.js", "cond", "201_8_5", debug)) winston.debug("Writing GPIO direction(" + direction + ") to " + directionFile + ");");
    _$jscmd("src/hw_mainline.js", "line", 203);
    fs.writeFileSync(directionFile, direction);
    _$jscmd("src/hw_mainline.js", "line", 204);
    return resp;
};

_$jscmd("src/hw_mainline.js", "line", 207);

var writeGPIOValue = function(pin, value, callback) {
    if (_$jscmd("src/hw_mainline.js", "cond", "208_8_39", typeof gpioFile[pin.key] == "undefined")) {
        _$jscmd("src/hw_mainline.js", "line", 209);
        gpioFile[pin.key] = "/sys/class/gpio/gpio" + pin.gpio + "/value";
        if (_$jscmd("src/hw_mainline.js", "cond", "210_12_7", pin.led)) {
            _$jscmd("src/hw_mainline.js", "line", 211);
            gpioFile[pin.key] = "/sys/class/leds/" + pin.led + "/brightness";
        }
        if (_$jscmd("src/hw_mainline.js", "cond", "213_12_38", !my.file_existsSync(gpioFile[pin.key]))) {
            _$jscmd("src/hw_mainline.js", "line", 214);
            winston.error("Unable to find gpio: " + gpioFile[pin.key]);
        }
    }
    if (_$jscmd("src/hw_mainline.js", "cond", "217_8_5", debug)) winston.debug("gpioFile = " + gpioFile[pin.key]);
    if (_$jscmd("src/hw_mainline.js", "cond", "218_8_8", callback)) {
        _$jscmd("src/hw_mainline.js", "line", 219);
        fs.writeFile(gpioFile[pin.key], "" + value, null, callback);
    } else {
        try {
            _$jscmd("src/hw_mainline.js", "line", 222);
            fs.writeFileSync(gpioFile[pin.key], "" + value, null);
        } catch (ex) {
            _$jscmd("src/hw_mainline.js", "line", 224);
            winston.error("Unable to write to " + gpioFile[pin.key]);
        }
    }
};

_$jscmd("src/hw_mainline.js", "line", 229);

var readGPIOValue = function(pin, resp, callback) {
    _$jscmd("src/hw_mainline.js", "line", 230);
    var gpioFile = "/sys/class/gpio/gpio" + pin.gpio + "/value";
    if (_$jscmd("src/hw_mainline.js", "cond", "231_8_8", callback)) {
        _$jscmd("src/hw_mainline.js", "line", 232);
        var readFile = function(err, data) {
            if (_$jscmd("src/hw_mainline.js", "cond", "233_16_3", err)) {
                _$jscmd("src/hw_mainline.js", "line", 234);
                resp.err = "digitalRead error: " + err;
                _$jscmd("src/hw_mainline.js", "line", 235);
                winston.error(resp.err);
            }
            _$jscmd("src/hw_mainline.js", "line", 237);
            resp.value = parseInt(data, 2);
            if (_$jscmd("src/hw_mainline.js", "cond", "238_16_20", callback.length == 1)) {
                _$jscmd("src/hw_mainline.js", "line", 239);
                winston.warning("single argument callbacks will be deprecated.please use node-style error-first callbacks: callback(err,response)");
                _$jscmd("src/hw_mainline.js", "line", 240);
                callback(resp);
            } else callback(resp.err, resp.value);
        };
        _$jscmd("src/hw_mainline.js", "line", 244);
        fs.readFile(gpioFile, readFile);
        _$jscmd("src/hw_mainline.js", "line", 245);
        return true;
    }
    _$jscmd("src/hw_mainline.js", "line", 247);
    resp.value = parseInt(fs.readFileSync(gpioFile), 2);
    _$jscmd("src/hw_mainline.js", "line", 248);
    return resp;
};

_$jscmd("src/hw_mainline.js", "line", 251);

var enableAIN = function(callback) {
    if (_$jscmd("src/hw_mainline.js", "cond", "252_8_30", !my.file_existsSync(ainPrefix))) {
        if (_$jscmd("src/hw_mainline.js", "cond", "253_12_5", debug)) winston.debug("enableAIN: loading " + AINdts);
        _$jscmd("src/hw_mainline.js", "line", 254);
        fs.writeFileSync(SLOTS, AINdts);
    }
    if (_$jscmd("src/hw_mainline.js", "cond", "256_8_30", !my.file_existsSync(ainPrefix))) {
        if (_$jscmd("src/hw_mainline.js", "cond", "257_12_5", debug)) winston.debug("enableAIN: load of " + AINdts + " failed");
    }
    if (_$jscmd("src/hw_mainline.js", "cond", "259_8_8", callback)) {
        _$jscmd("src/hw_mainline.js", "line", 260);
        callback({
            path: ainPrefix
        });
    }
    _$jscmd("src/hw_mainline.js", "line", 264);
    return ainPrefix;
};

_$jscmd("src/hw_mainline.js", "line", 267);

var readAIN = function(pin, resp, callback) {
    _$jscmd("src/hw_mainline.js", "line", 268);
    var maxValue = 4095;
    _$jscmd("src/hw_mainline.js", "line", 269);
    var ainFile = ainPrefix + "/in_voltage" + pin.ain.toString() + "_raw";
    if (_$jscmd("src/hw_mainline.js", "cond", "270_8_5", debug)) winston.debug("readAIN: ainFile=" + ainFile);
    if (_$jscmd("src/hw_mainline.js", "cond", "271_8_8", callback)) {
        _$jscmd("src/hw_mainline.js", "line", 272);
        var readFile = function(err, data) {
            if (_$jscmd("src/hw_mainline.js", "cond", "273_16_3", err)) {
                _$jscmd("src/hw_mainline.js", "line", 274);
                resp.err = "analogRead error: " + err;
                _$jscmd("src/hw_mainline.js", "line", 275);
                winston.error(resp.err);
            }
            _$jscmd("src/hw_mainline.js", "line", 277);
            resp.value = parseInt(data, 10) / maxValue;
            if (_$jscmd("src/hw_mainline.js", "cond", "278_16_20", callback.length == 1)) {
                _$jscmd("src/hw_mainline.js", "line", 279);
                winston.warning("single argument callbacks will be deprecated.please use node-style error-first callbacks: callback(err,response)");
                _$jscmd("src/hw_mainline.js", "line", 280);
                callback(resp);
            } else callback(resp.err, resp.value);
        };
        _$jscmd("src/hw_mainline.js", "line", 284);
        fs.readFile(ainFile, readFile);
        _$jscmd("src/hw_mainline.js", "line", 285);
        return resp;
    }
    _$jscmd("src/hw_mainline.js", "line", 287);
    resp.value = parseInt(fs.readFileSync(ainFile), 10);
    if (_$jscmd("src/hw_mainline.js", "cond", "288_8_17", isNaN(resp.value))) {
        _$jscmd("src/hw_mainline.js", "line", 289);
        resp.err = "analogRead(" + pin.key + ") returned " + resp.value;
        _$jscmd("src/hw_mainline.js", "line", 290);
        winston.error(resp.err);
    }
    _$jscmd("src/hw_mainline.js", "line", 292);
    resp.value = resp.value / maxValue;
    if (_$jscmd("src/hw_mainline.js", "cond", "293_8_17", isNaN(resp.value))) {
        _$jscmd("src/hw_mainline.js", "line", 294);
        resp.err = "analogRead(" + pin.key + ") scaled to " + resp.value;
        _$jscmd("src/hw_mainline.js", "line", 295);
        winston.error(resp.err);
    }
    _$jscmd("src/hw_mainline.js", "line", 297);
    return resp;
};

_$jscmd("src/hw_mainline.js", "line", 300);

var writeGPIOEdge = function(pin, mode) {
    _$jscmd("src/hw_mainline.js", "line", 301);
    fs.writeFileSync("/sys/class/gpio/gpio" + pin.gpio + "/edge", mode);
    _$jscmd("src/hw_mainline.js", "line", 303);
    var resp = {};
    _$jscmd("src/hw_mainline.js", "line", 304);
    resp.gpioFile = "/sys/class/gpio/gpio" + pin.gpio + "/value";
    _$jscmd("src/hw_mainline.js", "line", 305);
    resp.valuefd = fs.openSync(resp.gpioFile, "r");
    _$jscmd("src/hw_mainline.js", "line", 306);
    resp.value = new Buffer(1);
    _$jscmd("src/hw_mainline.js", "line", 308);
    return resp;
};

_$jscmd("src/hw_mainline.js", "line", 311);

var writePWMFreqAndValue = function(pin, pwm, freq, value, resp, callback) {
    if (_$jscmd("src/hw_mainline.js", "cond", "312_8_5", debug)) winston.debug("hw.writePWMFreqAndValue(" + [ pin.key, util.inspect(pwm), freq, value, resp ] + ");");
    _$jscmd("src/hw_mainline.js", "line", 313);
    var path = pwmPrefix[pin.pwm.name];
    try {
        _$jscmd("src/hw_mainline.js", "line", 315);
        var period = Math.round(1e9 / freq);
        _$jscmd("src/hw_mainline.js", "line", 316);
        // period in ns
        var duty = Math.round(period * value);
        _$jscmd("src/hw_mainline.js", "line", 317);
        var currentPeriod = fs.readFileSync(path + "/period");
        _$jscmd("src/hw_mainline.js", "line", 318);
        //read Current Period for smooth PWM
        var currentDuty = fs.readFileSync(path + "/duty_cycle");
        _$jscmd("src/hw_mainline.js", "line", 319);
        //read Current Duty for smooth PWM
        var pwmEnabled = Number(fs.readFileSync(path + "/enable"));
        _$jscmd("src/hw_mainline.js", "line", 320);
        //check whether PWM is enabled
        var disablePWM = !(duty * freq);
        //when duty||frequency ==0 , disablePWM to avoid spikes
        if (_$jscmd("src/hw_mainline.js", "cond", "322_12_5", debug)) winston.debug("hw.writePWMFreqAndValue: pwm.freq=" + pwm.freq + ", freq=" + freq + ", period=" + period);
        //smooth PWM Implementation
        if (_$jscmd("src/hw_mainline.js", "cond", "325_12_25", _$jscmd("src/hw_mainline.js", "cond", "325_12_11", !disablePWM) && _$jscmd("src/hw_mainline.js", "cond", "325_27_10", pwmEnabled))) {
            if (_$jscmd("src/hw_mainline.js", "cond", "326_16_20", period > currentDuty)) {
                if (_$jscmd("src/hw_mainline.js", "cond", "327_20_5", debug)) winston.debug("Updating PWM period: " + period);
                _$jscmd("src/hw_mainline.js", "line", 328);
                fs.writeFileSync(path + "/period", period);
                if (_$jscmd("src/hw_mainline.js", "cond", "329_20_5", debug)) winston.debug("Updating PWM duty: " + duty);
                _$jscmd("src/hw_mainline.js", "line", 330);
                fs.writeFileSync(path + "/duty_cycle", duty);
            } else if (_$jscmd("src/hw_mainline.js", "cond", "331_23_20", duty < currentPeriod)) {
                if (_$jscmd("src/hw_mainline.js", "cond", "332_20_5", debug)) winston.debug("Updating PWM duty: " + duty);
                _$jscmd("src/hw_mainline.js", "line", 333);
                fs.writeFileSync(path + "/duty_cycle", duty);
                if (_$jscmd("src/hw_mainline.js", "cond", "334_20_5", debug)) winston.debug("Updating PWM period: " + period);
                _$jscmd("src/hw_mainline.js", "line", 335);
                fs.writeFileSync(path + "/period", period);
            }
        } else {
            _$jscmd("src/hw_mainline.js", "line", 338);
            var tryAgain = true;
            _$jscmd("src/hw_mainline.js", "line", 339);
            var tries = 0;
            _$jscmd("src/hw_mainline.js", "line", 341);
            async.until(function() {
                _$jscmd("src/hw_mainline.js", "line", 342);
                //try accessing 'path/enable' until no EACCES error is thrown (max 10 times)
                return !tryAgain;
            }, stopPWM, updatePeriodAndDuty);
            //async.until(test,iteratee,callback)
            function stopPWM(callback) {
                try {
                    if (_$jscmd("src/hw_mainline.js", "cond", "347_24_5", debug)) winston.debug("Stopping PWM");
                    _$jscmd("src/hw_mainline.js", "line", 348);
                    fs.writeFileSync(path + "/enable", "0\n");
                    _$jscmd("src/hw_mainline.js", "line", 349);
                    callback(null);
                    _$jscmd("src/hw_mainline.js", "line", 350);
                    //if no error
                    tryAgain = false;
                } catch (ex2) {
                    if (_$jscmd("src/hw_mainline.js", "cond", "352_24_5", debug)) winston.debug("Error stopping PWM: " + ex2);
                    if (_$jscmd("src/hw_mainline.js", "cond", "353_24_20", ex2.code == "EACCES")) {
                        _$jscmd("src/hw_mainline.js", "line", 354);
                        tries++;
                        if (_$jscmd("src/hw_mainline.js", "cond", "355_28_10", tries < 10)) tryAgain = true; else tryAgain = false;
                        _$jscmd("src/hw_mainline.js", "line", 359);
                        callback(null);
                    } else {
                        _$jscmd("src/hw_mainline.js", "line", 361);
                        //if there is an error iteration stops, so neglect the error if EACCES thrown
                        tryAgain = false;
                        _$jscmd("src/hw_mainline.js", "line", 362);
                        callback(ex2);
                    }
                }
            }
            function updatePeriodAndDuty() {
                // It appears that the first time you set the pwm you have to
                // set the period before you set the duty_cycle
                if (_$jscmd("src/hw_mainline.js", "cond", "370_20_11", !disablePWM)) {
                    //if duty||frequency == 0 do not re-enable PWM (to avoid spikes)
                    try {
                        if (_$jscmd("src/hw_mainline.js", "cond", "372_28_5", debug)) winston.debug("Updating PWM period: " + period);
                        _$jscmd("src/hw_mainline.js", "line", 373);
                        fs.writeFileSync(path + "/period", period + "\n");
                    } catch (ex2) {
                        _$jscmd("src/hw_mainline.js", "line", 375);
                        winston.info("Unable to update PWM period, period is set to " + currentPeriod + "	Is other half of PWM enabled?");
                    }
                    try {
                        if (_$jscmd("src/hw_mainline.js", "cond", "380_28_5", debug)) winston.debug("Starting PWM");
                        _$jscmd("src/hw_mainline.js", "line", 381);
                        fs.writeFileSync(path + "/enable", "1\n");
                    } catch (ex2) {
                        if (_$jscmd("src/hw_mainline.js", "cond", "383_28_5", debug)) winston.debug("Error starting PWM: " + ex2);
                    }
                }
                if (_$jscmd("src/hw_mainline.js", "cond", "386_20_5", debug)) winston.debug("Updating PWM duty: " + duty);
                //if(duty == 0) winston.error('Updating PWM duty: ' + duty);
                if (_$jscmd("src/hw_mainline.js", "cond", "388_20_11", !disablePWM)) fs.writeFileSync(path + "/duty_cycle", duty + "\n");
            }
        }
    } catch (ex) {
        _$jscmd("src/hw_mainline.js", "line", 393);
        resp.err = "error updating PWM freq and value: " + path + ", " + ex;
        _$jscmd("src/hw_mainline.js", "line", 394);
        winston.error(resp.err);
    }
    _$jscmd("src/hw_mainline.js", "line", 396);
    return resp;
};

_$jscmd("src/hw_mainline.js", "line", 399);

var readEeproms = function(eeproms) {
    _$jscmd("src/hw_mainline.js", "line", 400);
    var EepromFiles = {
        "/sys/bus/i2c/devices/0-0050/0-00500/nvmem": {
            type: "bone"
        },
        "/sys/bus/i2c/devices/2-0054/2-00540/nvmem": {
            type: "cape"
        },
        "/sys/bus/i2c/devices/2-0055/2-00550/nvmem": {
            type: "cape"
        },
        "/sys/bus/i2c/devices/2-0056/2-00560/nvmem": {
            type: "cape"
        },
        "/sys/bus/i2c/devices/2-0057/2-00570/nvmem": {
            type: "cape"
        }
    };
    _$jscmd("src/hw_mainline.js", "line", 417);
    eeproms = eeprom.readEeproms(EepromFiles);
    _$jscmd("src/hw_mainline.js", "line", 418);
    return eeproms;
};

_$jscmd("src/hw_mainline.js", "line", 421);

var readPlatform = function(platform) {
    _$jscmd("src/hw_mainline.js", "line", 422);
    var eeproms = eeprom.readEeproms({
        "/sys/bus/i2c/devices/0-0050/0-00500/nvmem": {
            type: "bone"
        }
    });
    _$jscmd("src/hw_mainline.js", "line", 427);
    var x = eeproms["/sys/bus/i2c/devices/0-0050/0-00500/nvmem"];
    _$jscmd("src/hw_mainline.js", "line", 428);
    platform.name = fs.readFileSync("/proc/device-tree/model", "ascii").trim().replace(/\0/g, "");
    if (_$jscmd("src/hw_mainline.js", "cond", "429_8_34", platform.name.indexOf("Green") > 0)) {
        _$jscmd("src/hw_mainline.js", "line", 430);
        platform.name = platform.name.replace("TI AM335x", "SeeedStudio");
    }
    if (_$jscmd("src/hw_mainline.js", "cond", "432_8_36", platform.name.indexOf("Arduino") > 0)) {
        _$jscmd("src/hw_mainline.js", "line", 433);
        platform.name = platform.name.replace("TI AM335x", "");
    }
    _$jscmd("src/hw_mainline.js", "line", 435);
    platform.name = platform.name.replace("TI AM335x BeagleBone", "BeagleBoard.org BeagleBone");
    _$jscmd("src/hw_mainline.js", "line", 436);
    platform.name = platform.name.replace("TI AM5728 BeagleBoard-X15", "BeagleBoard.org BeagleBoard-X15");
    if (_$jscmd("src/hw_mainline.js", "cond", "437_8_14", _$jscmd("src/hw_mainline.js", "cond", "437_8_1", x) && _$jscmd("src/hw_mainline.js", "cond", "437_13_9", x.version))) {
        _$jscmd("src/hw_mainline.js", "line", 438);
        platform.version = x.version;
        if (_$jscmd("src/hw_mainline.js", "cond", "439_12_41", !platform.version.match(/^[\040-\176]*$/))) delete platform.version;
    }
    if (_$jscmd("src/hw_mainline.js", "cond", "441_8_19", _$jscmd("src/hw_mainline.js", "cond", "441_8_1", x) && _$jscmd("src/hw_mainline.js", "cond", "441_13_14", x.serialNumber))) {
        _$jscmd("src/hw_mainline.js", "line", 442);
        platform.serialNumber = x.serialNumber;
        if (_$jscmd("src/hw_mainline.js", "cond", "443_12_46", !platform.serialNumber.match(/^[\040-\176]*$/))) delete platform.serialNumber;
    }
    try {
        _$jscmd("src/hw_mainline.js", "line", 446);
        platform.dogtag = fs.readFileSync("/etc/dogtag", "ascii");
    } catch (ex) {}
    _$jscmd("src/hw_mainline.js", "line", 448);
    return platform;
};

_$jscmd("src/hw_mainline.js", "line", 451);

module.exports = {
    logfile: logfile,
    readPWMFreqAndValue: readPWMFreqAndValue,
    readGPIODirection: readGPIODirection,
    readPinMux: readPinMux,
    setPinMode: setPinMode,
    setLEDPinToGPIO: setLEDPinToGPIO,
    exportGPIOControls: exportGPIOControls,
    writeGPIOValue: writeGPIOValue,
    readGPIOValue: readGPIOValue,
    enableAIN: enableAIN,
    readAIN: readAIN,
    writeGPIOEdge: writeGPIOEdge,
    writePWMFreqAndValue: writePWMFreqAndValue,
    readEeproms: readEeproms,
    readPlatform: readPlatform
};