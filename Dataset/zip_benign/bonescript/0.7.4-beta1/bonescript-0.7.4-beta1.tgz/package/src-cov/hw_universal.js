
// instrument by jscoverage, do not modifly this file
(function (file, lines, conds, source) {
  var BASE;
  if (typeof global === 'object') {
    BASE = global;
  } else if (typeof window === 'object') {
    BASE = window;
  } else {
    throw new Error('[jscoverage] unknow ENV!');
  }
  if (BASE._$jscoverage) {
    BASE._$jscmd(file, 'init', lines, conds, source);
    return;
  }
  var cov = {};
  /**
   * jsc(file, 'init', lines, condtions)
   * jsc(file, 'line', lineNum)
   * jsc(file, 'cond', lineNum, expr, start, offset)
   */
  function jscmd(file, type, line, express, start, offset) {
    var storage;
    switch (type) {
      case 'init':
        if(cov[file]){
          storage = cov[file];
        } else {
          storage = [];
          for (var i = 0; i < line.length; i ++) {
            storage[line[i]] = 0;
          }
          var condition = express;
          var source = start;
          storage.condition = condition;
          storage.source = source;
        }
        cov[file] = storage;
        break;
      case 'line':
        storage = cov[file];
        storage[line] ++;
        break;
      case 'cond':
        storage = cov[file];
        storage.condition[line] ++;
        return express;
    }
  }

  BASE._$jscoverage = cov;
  BASE._$jscmd = jscmd;
  jscmd(file, 'init', lines, conds, source);
})('src/hw_universal.js', [1,2,3,4,5,7,9,10,11,13,15,26,38,71,96,110,126,149,167,188,215,226,257,279,298,16,23,18,19,20,21,27,28,35,30,31,32,33,39,40,41,50,68,47,48,43,45,52,55,59,62,63,73,75,93,77,80,81,83,84,88,86,90,97,107,100,102,103,104,112,113,119,122,123,117,128,130,131,134,139,142,144,150,163,164,152,160,161,157,158,154,155,168,185,170,172,174,181,189,202,207,212,191,199,200,196,197,193,194,204,205,209,210,216,218,219,220,221,223,228,254,230,246,249,233,235,244,238,240,241,251,252,258,275,276,280,285,288,290,295,293], {"7_32_4":0,"7_39_5":0,"29_8_33":0,"42_12_3":0,"44_16_5":0,"51_12_6":0,"54_16_5":0,"58_8_8":0,"65_16_5":0,"72_8_5":0,"74_8_17":0,"76_8_7":0,"79_8_18":0,"82_15_19":0,"85_12_44":0,"92_8_8":0,"99_8_24":0,"111_8_5":0,"115_8_7":0,"116_12_5":0,"120_8_5":0,"127_8_39":0,"129_12_7":0,"133_12_38":0,"137_8_5":0,"138_8_8":0,"151_8_8":0,"153_16_3":0,"169_8_27":0,"171_12_3":0,"173_16_6":0,"178_12_5":0,"180_8_8":0,"190_8_8":0,"192_16_3":0,"203_8_17":0,"208_8_17":0,"227_8_5":0,"231_12_16":0,"232_16_5":0,"234_16_5":0,"237_20_5":0,"243_16_5":0,"247_12_5":0,"286_8_25":0,"287_8_25":0,"289_8_41":0,"291_8_46":0}, ["var fs = require('fs');","var winston = require('winston');","var my = require('./my');","var parse = require('./parse');","var eeprom = require('./eeprom');","","var debug = process.env.DEBUG ? true : false;","","var gpioFile = {};","var pwmPrefix = {};","var ainPrefix = \"\";","","var logfile = '/var/lib/cloud9/bonescript.log';","","var readPWMFreqAndValue = function (pin, pwm) {","    var mode = {};","    try {","        var period = fs.readFileSync(pwmPrefix[pin.pwm.name] + '/period_ns');","        var duty = fs.readFileSync(pwmPrefix[pin.pwm.name] + '/duty_ns');","        mode.freq = 1.0e9 / period;","        mode.value = duty / period;","    } catch (ex) {}","    return (mode);","};","","var readGPIODirection = function (n, gpio) {","    var mode = {};","    var directionFile = \"/sys/class/gpio/gpio\" + n + \"/direction\";","    if (my.file_existsSync(directionFile)) {","        mode.active = true;","        var direction = fs.readFileSync(directionFile, 'utf-8');","        direction = direction.replace(/^\\s+|\\s+$/g, '');","        mode.direction = direction;","    }","    return (mode);","};","","var readPinMux = function (pin, mode, callback) {","    var pinctrlFile = '/sys/kernel/debug/pinctrl/44e10800.pinmux/pins';","    var muxRegOffset = parseInt(pin.muxRegOffset, 16);","    var readPinctrl = function (err, data) {","        if (err) {","            mode.err = 'readPinctrl error: ' + err;","            if (debug) winston.debug(mode.err);","            callback(mode);","        }","        mode = parse.modeFromPinctrl(data, muxRegOffset, 0x44e10800, mode);","        callback(mode);","    };","    var tryPinctrl = function (exists) {","        if (exists) {","            fs.readFile(pinctrlFile, 'utf8', readPinctrl);","        } else {","            if (debug) winston.debug('getPinMode(' + pin.key + '): no valid mux data');","            callback(mode);","        }","    };","    if (callback) {","        my.file_exists(pinctrlFile, tryPinctrl);","    } else {","        try {","            var data2 = fs.readFileSync(pinctrlFile, 'utf8');","            mode = parse.modeFromPinctrl(data2, muxRegOffset, 0x44e10800, mode);","        } catch (ex) {","            if (debug) winston.debug('getPinMode(' + pin.key + '): ' + ex);","        }","    }","    return (mode);","};","","var setPinMode = function (pin, pinData, template, resp, callback) {","    if (debug) winston.debug('hw.setPinMode(' + [pin.key, pinData, template, JSON.stringify(resp)] + ');');","    var p = pin.key + \"_pinmux\";","    if (pin.universalName) p = pin.universalName + \"_pinmux\";","    var pinmux = my.find_sysfsFile(p, my.is_ocp(), p + '.');","    if (!pinmux) {","        throw p + \" was not found under \" + my.is_ocp();","    }","    if ((pinData & 7) == 7) {","        gpioFile[pin.key] = '/sys/class/gpio/gpio' + pin.gpio + '/value';","        fs.writeFileSync(pinmux + \"/state\", 'gpio');","    } else if (template == 'bspwm') {","        fs.writeFileSync(pinmux + \"/state\", 'pwm');","        pwmPrefix[pin.pwm.name] = '/sys/class/pwm/pwm' + pin.pwm.sysfs;","        if (!my.file_existsSync(pwmPrefix[pin.pwm.name])) {","            fs.appendFileSync('/sys/class/pwm/export', pin.pwm.sysfs);","        }","        fs.appendFileSync(pwmPrefix[pin.pwm.name] + '/run', 1);","    } else {","        resp.err = 'Unknown pin mode template';","    }","    if (callback) callback(resp);","    return (resp);","};","","var setLEDPinToGPIO = function (pin, resp) {","    var path = \"/sys/class/leds/beaglebone:green:\" + pin.led + \"/trigger\";","","    if (my.file_existsSync(path)) {","        fs.writeFileSync(path, \"gpio\");","    } else {","        resp.err = \"Unable to find LED \" + pin.led;","        winston.error(resp.err);","        resp.value = false;","    }","","    return (resp);","};","","var exportGPIOControls = function (pin, direction, resp, callback) {","    if (debug) winston.debug('hw.exportGPIOControls(' + [pin.key, direction, resp] + ');');","    var n = pin.gpio;","    var exists = my.file_existsSync(gpioFile[pin.key]);","","    if (!exists) {","        if (debug) winston.debug(\"exporting gpio: \" + n);","        fs.writeFileSync(\"/sys/class/gpio/export\", \"\" + n, null);","    }","    var directionFile = \"/sys/class/gpio/gpio\" + n + \"/direction\";","    if (debug) winston.debug('Writing GPIO direction(' + direction + ') to ' +","        directionFile + ');');","    fs.writeFileSync(directionFile, direction);","    return (resp);","};","","var writeGPIOValue = function (pin, value, callback) {","    if (typeof gpioFile[pin.key] == 'undefined') {","        gpioFile[pin.key] = '/sys/class/gpio/gpio' + pin.gpio + '/value';","        if (pin.led) {","            gpioFile[pin.key] = \"/sys/class/leds/beaglebone:\";","            gpioFile[pin.key] += \"green:\" + pin.led + \"/brightness\";","        }","        if (!my.file_existsSync(gpioFile[pin.key])) {","            winston.error(\"Unable to find gpio: \" + gpioFile[pin.key]);","        }","    }","    if (debug) winston.debug(\"gpioFile = \" + gpioFile[pin.key]);","    if (callback) {","        fs.writeFile(gpioFile[pin.key], '' + value, null, callback);","    } else {","        try {","            fs.writeFileSync(gpioFile[pin.key], '' + value, null);","        } catch (ex) {","            winston.error(\"Unable to write to \" + gpioFile[pin.key]);","        }","    }","};","","var readGPIOValue = function (pin, resp, callback) {","    var gpioFile = '/sys/class/gpio/gpio' + pin.gpio + '/value';","    if (callback) {","        var readFile = function (err, data) {","            if (err) {","                resp.err = 'digitalRead error: ' + err;","                winston.error(resp.err);","            }","            resp.value = parseInt(data, 2);","            callback(resp);","        };","        fs.readFile(gpioFile, readFile);","        return (true);","    }","    resp.value = parseInt(fs.readFileSync(gpioFile), 2);","    return (resp);","};","","var enableAIN = function (callback) {","    var helper = \"\";","    if (my.load_dt('cape-bone-iio')) {","        var ocp = my.is_ocp();","        if (ocp) {","            helper = my.find_sysfsFile('helper', ocp, 'helper.');","            if (helper) {","                ainPrefix = helper + '/AIN';","            }","        }","    } else {","        if (debug) winston.debug('enableAIN: load of cape-bone-iio failed');","    }","    if (callback) {","        callback({","            'path': helper","        })","    }","    return (helper.length > 1);","};","","var readAIN = function (pin, resp, callback) {","    var ainFile = ainPrefix + pin.ain.toString();","    if (callback) {","        var readFile = function (err, data) {","            if (err) {","                resp.err = 'analogRead error: ' + err;","                winston.error(resp.err);","            }","            resp.value = parseInt(data, 10) / 1800;","            callback(resp);","        };","        fs.readFile(ainFile, readFile);","        return (resp);","    }","    resp.value = parseInt(fs.readFileSync(ainFile), 10);","    if (isNaN(resp.value)) {","        resp.err = 'analogRead(' + pin.key + ') returned ' + resp.value;","        winston.error(resp.err);","    }","    resp.value = resp.value / 1800;","    if (isNaN(resp.value)) {","        resp.err = 'analogRead(' + pin.key + ') scaled to ' + resp.value;","        winston.error(resp.err);","    }","    return (resp);","};","","var writeGPIOEdge = function (pin, mode) {","    fs.writeFileSync('/sys/class/gpio/gpio' + pin.gpio + '/edge', mode);","","    var resp = {};","    resp.gpioFile = '/sys/class/gpio/gpio' + pin.gpio + '/value';","    resp.valuefd = fs.openSync(resp.gpioFile, 'r');","    resp.value = new Buffer(1);","","    return (resp);","};","","var writePWMFreqAndValue = function (pin, pwm, freq, value, resp, callback) {","    if (debug) winston.debug('hw.writePWMFreqAndValue(' + [pin.key, pwm, freq, value, resp] + ');');","    var path = pwmPrefix[pin.pwm.name];","    try {","        var period = Math.round(1.0e9 / freq); // period in ns","        if (pwm.freq != freq) {","            if (debug) winston.debug('Stopping PWM');","            fs.writeFileSync(path + '/run', \"0\\n\");","            if (debug) winston.debug('Setting duty to 0');","            fs.writeFileSync(path + '/duty_ns', \"0\\n\");","            try {","                if (debug) winston.debug('Updating PWM period: ' + period);","                fs.writeFileSync(path + '/period_ns', period + \"\\n\");","            } catch (ex2) {","                period = fs.readFileSync(path + '/period_ns');","                winston.info('Unable to update PWM period, period is set to ' + period);","            }","            if (debug) winston.debug('Starting PWM');","            fs.writeFileSync(path + '/run', \"1\\n\");","        }","        var duty = Math.round(period * value);","        if (debug) winston.debug('Updating PWM duty: ' + duty);","        //if(duty == 0) winston.error('Updating PWM duty: ' + duty);","        fs.writeFileSync(path + '/duty_ns', duty + \"\\n\");","    } catch (ex) {","        resp.err = 'error updating PWM freq and value: ' + path + ', ' + ex;","        winston.error(resp.err);","    }","    return (resp);","};","","var readEeproms = function (eeproms) {","    var EepromFiles = {","        '/sys/bus/i2c/drivers/at24/0-0050/eeprom': {","            type: 'bone'","        },","        '/sys/bus/i2c/drivers/at24/2-0054/eeprom': {","            type: 'cape'","        },","        '/sys/bus/i2c/drivers/at24/2-0055/eeprom': {","            type: 'cape'","        },","        '/sys/bus/i2c/drivers/at24/2-0056/eeprom': {","            type: 'cape'","        },","        '/sys/bus/i2c/drivers/at24/2-0057/eeprom': {","            type: 'cape'","        }","    };","    eeproms = eeprom.readEeproms(EepromFiles);","    return (eeproms);","};","","var readPlatform = function (platform) {","    var eeproms = eeprom.readEeproms({","        '/sys/bus/i2c/drivers/at24/0-0050/eeprom': {","            type: 'bone'","        }","    });","    var x = eeproms['/sys/bus/i2c/drivers/at24/0-0050/eeprom'];","    if (x.boardName == 'A335BONE') platform.name = 'BeagleBone';","    if (x.boardName == 'A335BNLT') platform.name = 'BeagleBone Black';","    platform.version = x.version;","    if (!platform.version.match(/^[\\040-\\176]*$/)) delete platform.version;","    platform.serialNumber = x.serialNumber;","    if (!platform.serialNumber.match(/^[\\040-\\176]*$/)) delete platform.serialNumber;","    try {","        platform.dogtag = fs.readFileSync('/etc/dogtag', 'ascii');","    } catch (ex) {}","    return (platform);","};","","module.exports = {","    logfile: logfile,","    readPWMFreqAndValue: readPWMFreqAndValue,","    readGPIODirection: readGPIODirection,","    readPinMux: readPinMux,","    setPinMode: setPinMode,","    setLEDPinToGPIO: setLEDPinToGPIO,","    exportGPIOControls: exportGPIOControls,","    writeGPIOValue: writeGPIOValue,","    readGPIOValue: readGPIOValue,","    enableAIN: enableAIN,","    readAIN: readAIN,","    writeGPIOEdge: writeGPIOEdge,","    writePWMFreqAndValue: writePWMFreqAndValue,","    readEeproms: readEeproms,","    readPlatform: readPlatform","}"]);
_$jscmd("src/hw_universal.js", "line", 1);

var fs = require("fs");

_$jscmd("src/hw_universal.js", "line", 2);

var winston = require("winston");

_$jscmd("src/hw_universal.js", "line", 3);

var my = require("./my");

_$jscmd("src/hw_universal.js", "line", 4);

var parse = require("./parse");

_$jscmd("src/hw_universal.js", "line", 5);

var eeprom = require("./eeprom");

_$jscmd("src/hw_universal.js", "line", 7);

var debug = process.env.DEBUG ? _$jscmd("src/hw_universal.js", "cond", "7_32_4", true) : _$jscmd("src/hw_universal.js", "cond", "7_39_5", false);

_$jscmd("src/hw_universal.js", "line", 9);

var gpioFile = {};

_$jscmd("src/hw_universal.js", "line", 10);

var pwmPrefix = {};

_$jscmd("src/hw_universal.js", "line", 11);

var ainPrefix = "";

_$jscmd("src/hw_universal.js", "line", 13);

var logfile = "/var/lib/cloud9/bonescript.log";

_$jscmd("src/hw_universal.js", "line", 15);

var readPWMFreqAndValue = function(pin, pwm) {
    _$jscmd("src/hw_universal.js", "line", 16);
    var mode = {};
    try {
        _$jscmd("src/hw_universal.js", "line", 18);
        var period = fs.readFileSync(pwmPrefix[pin.pwm.name] + "/period_ns");
        _$jscmd("src/hw_universal.js", "line", 19);
        var duty = fs.readFileSync(pwmPrefix[pin.pwm.name] + "/duty_ns");
        _$jscmd("src/hw_universal.js", "line", 20);
        mode.freq = 1e9 / period;
        _$jscmd("src/hw_universal.js", "line", 21);
        mode.value = duty / period;
    } catch (ex) {}
    _$jscmd("src/hw_universal.js", "line", 23);
    return mode;
};

_$jscmd("src/hw_universal.js", "line", 26);

var readGPIODirection = function(n, gpio) {
    _$jscmd("src/hw_universal.js", "line", 27);
    var mode = {};
    _$jscmd("src/hw_universal.js", "line", 28);
    var directionFile = "/sys/class/gpio/gpio" + n + "/direction";
    if (_$jscmd("src/hw_universal.js", "cond", "29_8_33", my.file_existsSync(directionFile))) {
        _$jscmd("src/hw_universal.js", "line", 30);
        mode.active = true;
        _$jscmd("src/hw_universal.js", "line", 31);
        var direction = fs.readFileSync(directionFile, "utf-8");
        _$jscmd("src/hw_universal.js", "line", 32);
        direction = direction.replace(/^\s+|\s+$/g, "");
        _$jscmd("src/hw_universal.js", "line", 33);
        mode.direction = direction;
    }
    _$jscmd("src/hw_universal.js", "line", 35);
    return mode;
};

_$jscmd("src/hw_universal.js", "line", 38);

var readPinMux = function(pin, mode, callback) {
    _$jscmd("src/hw_universal.js", "line", 39);
    var pinctrlFile = "/sys/kernel/debug/pinctrl/44e10800.pinmux/pins";
    _$jscmd("src/hw_universal.js", "line", 40);
    var muxRegOffset = parseInt(pin.muxRegOffset, 16);
    _$jscmd("src/hw_universal.js", "line", 41);
    var readPinctrl = function(err, data) {
        if (_$jscmd("src/hw_universal.js", "cond", "42_12_3", err)) {
            _$jscmd("src/hw_universal.js", "line", 43);
            mode.err = "readPinctrl error: " + err;
            if (_$jscmd("src/hw_universal.js", "cond", "44_16_5", debug)) winston.debug(mode.err);
            _$jscmd("src/hw_universal.js", "line", 45);
            callback(mode);
        }
        _$jscmd("src/hw_universal.js", "line", 47);
        mode = parse.modeFromPinctrl(data, muxRegOffset, 1155598336, mode);
        _$jscmd("src/hw_universal.js", "line", 48);
        callback(mode);
    };
    _$jscmd("src/hw_universal.js", "line", 50);
    var tryPinctrl = function(exists) {
        if (_$jscmd("src/hw_universal.js", "cond", "51_12_6", exists)) {
            _$jscmd("src/hw_universal.js", "line", 52);
            fs.readFile(pinctrlFile, "utf8", readPinctrl);
        } else {
            if (_$jscmd("src/hw_universal.js", "cond", "54_16_5", debug)) winston.debug("getPinMode(" + pin.key + "): no valid mux data");
            _$jscmd("src/hw_universal.js", "line", 55);
            callback(mode);
        }
    };
    if (_$jscmd("src/hw_universal.js", "cond", "58_8_8", callback)) {
        _$jscmd("src/hw_universal.js", "line", 59);
        my.file_exists(pinctrlFile, tryPinctrl);
    } else {
        try {
            _$jscmd("src/hw_universal.js", "line", 62);
            var data2 = fs.readFileSync(pinctrlFile, "utf8");
            _$jscmd("src/hw_universal.js", "line", 63);
            mode = parse.modeFromPinctrl(data2, muxRegOffset, 1155598336, mode);
        } catch (ex) {
            if (_$jscmd("src/hw_universal.js", "cond", "65_16_5", debug)) winston.debug("getPinMode(" + pin.key + "): " + ex);
        }
    }
    _$jscmd("src/hw_universal.js", "line", 68);
    return mode;
};

_$jscmd("src/hw_universal.js", "line", 71);

var setPinMode = function(pin, pinData, template, resp, callback) {
    if (_$jscmd("src/hw_universal.js", "cond", "72_8_5", debug)) winston.debug("hw.setPinMode(" + [ pin.key, pinData, template, JSON.stringify(resp) ] + ");");
    _$jscmd("src/hw_universal.js", "line", 73);
    var p = pin.key + "_pinmux";
    if (_$jscmd("src/hw_universal.js", "cond", "74_8_17", pin.universalName)) p = pin.universalName + "_pinmux";
    _$jscmd("src/hw_universal.js", "line", 75);
    var pinmux = my.find_sysfsFile(p, my.is_ocp(), p + ".");
    if (_$jscmd("src/hw_universal.js", "cond", "76_8_7", !pinmux)) {
        _$jscmd("src/hw_universal.js", "line", 77);
        throw p + " was not found under " + my.is_ocp();
    }
    if (_$jscmd("src/hw_universal.js", "cond", "79_8_18", (pinData & 7) == 7)) {
        _$jscmd("src/hw_universal.js", "line", 80);
        gpioFile[pin.key] = "/sys/class/gpio/gpio" + pin.gpio + "/value";
        _$jscmd("src/hw_universal.js", "line", 81);
        fs.writeFileSync(pinmux + "/state", "gpio");
    } else if (_$jscmd("src/hw_universal.js", "cond", "82_15_19", template == "bspwm")) {
        _$jscmd("src/hw_universal.js", "line", 83);
        fs.writeFileSync(pinmux + "/state", "pwm");
        _$jscmd("src/hw_universal.js", "line", 84);
        pwmPrefix[pin.pwm.name] = "/sys/class/pwm/pwm" + pin.pwm.sysfs;
        if (_$jscmd("src/hw_universal.js", "cond", "85_12_44", !my.file_existsSync(pwmPrefix[pin.pwm.name]))) {
            _$jscmd("src/hw_universal.js", "line", 86);
            fs.appendFileSync("/sys/class/pwm/export", pin.pwm.sysfs);
        }
        _$jscmd("src/hw_universal.js", "line", 88);
        fs.appendFileSync(pwmPrefix[pin.pwm.name] + "/run", 1);
    } else {
        _$jscmd("src/hw_universal.js", "line", 90);
        resp.err = "Unknown pin mode template";
    }
    if (_$jscmd("src/hw_universal.js", "cond", "92_8_8", callback)) callback(resp);
    _$jscmd("src/hw_universal.js", "line", 93);
    return resp;
};

_$jscmd("src/hw_universal.js", "line", 96);

var setLEDPinToGPIO = function(pin, resp) {
    _$jscmd("src/hw_universal.js", "line", 97);
    var path = "/sys/class/leds/beaglebone:green:" + pin.led + "/trigger";
    if (_$jscmd("src/hw_universal.js", "cond", "99_8_24", my.file_existsSync(path))) {
        _$jscmd("src/hw_universal.js", "line", 100);
        fs.writeFileSync(path, "gpio");
    } else {
        _$jscmd("src/hw_universal.js", "line", 102);
        resp.err = "Unable to find LED " + pin.led;
        _$jscmd("src/hw_universal.js", "line", 103);
        winston.error(resp.err);
        _$jscmd("src/hw_universal.js", "line", 104);
        resp.value = false;
    }
    _$jscmd("src/hw_universal.js", "line", 107);
    return resp;
};

_$jscmd("src/hw_universal.js", "line", 110);

var exportGPIOControls = function(pin, direction, resp, callback) {
    if (_$jscmd("src/hw_universal.js", "cond", "111_8_5", debug)) winston.debug("hw.exportGPIOControls(" + [ pin.key, direction, resp ] + ");");
    _$jscmd("src/hw_universal.js", "line", 112);
    var n = pin.gpio;
    _$jscmd("src/hw_universal.js", "line", 113);
    var exists = my.file_existsSync(gpioFile[pin.key]);
    if (_$jscmd("src/hw_universal.js", "cond", "115_8_7", !exists)) {
        if (_$jscmd("src/hw_universal.js", "cond", "116_12_5", debug)) winston.debug("exporting gpio: " + n);
        _$jscmd("src/hw_universal.js", "line", 117);
        fs.writeFileSync("/sys/class/gpio/export", "" + n, null);
    }
    _$jscmd("src/hw_universal.js", "line", 119);
    var directionFile = "/sys/class/gpio/gpio" + n + "/direction";
    if (_$jscmd("src/hw_universal.js", "cond", "120_8_5", debug)) winston.debug("Writing GPIO direction(" + direction + ") to " + directionFile + ");");
    _$jscmd("src/hw_universal.js", "line", 122);
    fs.writeFileSync(directionFile, direction);
    _$jscmd("src/hw_universal.js", "line", 123);
    return resp;
};

_$jscmd("src/hw_universal.js", "line", 126);

var writeGPIOValue = function(pin, value, callback) {
    if (_$jscmd("src/hw_universal.js", "cond", "127_8_39", typeof gpioFile[pin.key] == "undefined")) {
        _$jscmd("src/hw_universal.js", "line", 128);
        gpioFile[pin.key] = "/sys/class/gpio/gpio" + pin.gpio + "/value";
        if (_$jscmd("src/hw_universal.js", "cond", "129_12_7", pin.led)) {
            _$jscmd("src/hw_universal.js", "line", 130);
            gpioFile[pin.key] = "/sys/class/leds/beaglebone:";
            _$jscmd("src/hw_universal.js", "line", 131);
            gpioFile[pin.key] += "green:" + pin.led + "/brightness";
        }
        if (_$jscmd("src/hw_universal.js", "cond", "133_12_38", !my.file_existsSync(gpioFile[pin.key]))) {
            _$jscmd("src/hw_universal.js", "line", 134);
            winston.error("Unable to find gpio: " + gpioFile[pin.key]);
        }
    }
    if (_$jscmd("src/hw_universal.js", "cond", "137_8_5", debug)) winston.debug("gpioFile = " + gpioFile[pin.key]);
    if (_$jscmd("src/hw_universal.js", "cond", "138_8_8", callback)) {
        _$jscmd("src/hw_universal.js", "line", 139);
        fs.writeFile(gpioFile[pin.key], "" + value, null, callback);
    } else {
        try {
            _$jscmd("src/hw_universal.js", "line", 142);
            fs.writeFileSync(gpioFile[pin.key], "" + value, null);
        } catch (ex) {
            _$jscmd("src/hw_universal.js", "line", 144);
            winston.error("Unable to write to " + gpioFile[pin.key]);
        }
    }
};

_$jscmd("src/hw_universal.js", "line", 149);

var readGPIOValue = function(pin, resp, callback) {
    _$jscmd("src/hw_universal.js", "line", 150);
    var gpioFile = "/sys/class/gpio/gpio" + pin.gpio + "/value";
    if (_$jscmd("src/hw_universal.js", "cond", "151_8_8", callback)) {
        _$jscmd("src/hw_universal.js", "line", 152);
        var readFile = function(err, data) {
            if (_$jscmd("src/hw_universal.js", "cond", "153_16_3", err)) {
                _$jscmd("src/hw_universal.js", "line", 154);
                resp.err = "digitalRead error: " + err;
                _$jscmd("src/hw_universal.js", "line", 155);
                winston.error(resp.err);
            }
            _$jscmd("src/hw_universal.js", "line", 157);
            resp.value = parseInt(data, 2);
            _$jscmd("src/hw_universal.js", "line", 158);
            callback(resp);
        };
        _$jscmd("src/hw_universal.js", "line", 160);
        fs.readFile(gpioFile, readFile);
        _$jscmd("src/hw_universal.js", "line", 161);
        return true;
    }
    _$jscmd("src/hw_universal.js", "line", 163);
    resp.value = parseInt(fs.readFileSync(gpioFile), 2);
    _$jscmd("src/hw_universal.js", "line", 164);
    return resp;
};

_$jscmd("src/hw_universal.js", "line", 167);

var enableAIN = function(callback) {
    _$jscmd("src/hw_universal.js", "line", 168);
    var helper = "";
    if (_$jscmd("src/hw_universal.js", "cond", "169_8_27", my.load_dt("cape-bone-iio"))) {
        _$jscmd("src/hw_universal.js", "line", 170);
        var ocp = my.is_ocp();
        if (_$jscmd("src/hw_universal.js", "cond", "171_12_3", ocp)) {
            _$jscmd("src/hw_universal.js", "line", 172);
            helper = my.find_sysfsFile("helper", ocp, "helper.");
            if (_$jscmd("src/hw_universal.js", "cond", "173_16_6", helper)) {
                _$jscmd("src/hw_universal.js", "line", 174);
                ainPrefix = helper + "/AIN";
            }
        }
    } else {
        if (_$jscmd("src/hw_universal.js", "cond", "178_12_5", debug)) winston.debug("enableAIN: load of cape-bone-iio failed");
    }
    if (_$jscmd("src/hw_universal.js", "cond", "180_8_8", callback)) {
        _$jscmd("src/hw_universal.js", "line", 181);
        callback({
            path: helper
        });
    }
    _$jscmd("src/hw_universal.js", "line", 185);
    return helper.length > 1;
};

_$jscmd("src/hw_universal.js", "line", 188);

var readAIN = function(pin, resp, callback) {
    _$jscmd("src/hw_universal.js", "line", 189);
    var ainFile = ainPrefix + pin.ain.toString();
    if (_$jscmd("src/hw_universal.js", "cond", "190_8_8", callback)) {
        _$jscmd("src/hw_universal.js", "line", 191);
        var readFile = function(err, data) {
            if (_$jscmd("src/hw_universal.js", "cond", "192_16_3", err)) {
                _$jscmd("src/hw_universal.js", "line", 193);
                resp.err = "analogRead error: " + err;
                _$jscmd("src/hw_universal.js", "line", 194);
                winston.error(resp.err);
            }
            _$jscmd("src/hw_universal.js", "line", 196);
            resp.value = parseInt(data, 10) / 1800;
            _$jscmd("src/hw_universal.js", "line", 197);
            callback(resp);
        };
        _$jscmd("src/hw_universal.js", "line", 199);
        fs.readFile(ainFile, readFile);
        _$jscmd("src/hw_universal.js", "line", 200);
        return resp;
    }
    _$jscmd("src/hw_universal.js", "line", 202);
    resp.value = parseInt(fs.readFileSync(ainFile), 10);
    if (_$jscmd("src/hw_universal.js", "cond", "203_8_17", isNaN(resp.value))) {
        _$jscmd("src/hw_universal.js", "line", 204);
        resp.err = "analogRead(" + pin.key + ") returned " + resp.value;
        _$jscmd("src/hw_universal.js", "line", 205);
        winston.error(resp.err);
    }
    _$jscmd("src/hw_universal.js", "line", 207);
    resp.value = resp.value / 1800;
    if (_$jscmd("src/hw_universal.js", "cond", "208_8_17", isNaN(resp.value))) {
        _$jscmd("src/hw_universal.js", "line", 209);
        resp.err = "analogRead(" + pin.key + ") scaled to " + resp.value;
        _$jscmd("src/hw_universal.js", "line", 210);
        winston.error(resp.err);
    }
    _$jscmd("src/hw_universal.js", "line", 212);
    return resp;
};

_$jscmd("src/hw_universal.js", "line", 215);

var writeGPIOEdge = function(pin, mode) {
    _$jscmd("src/hw_universal.js", "line", 216);
    fs.writeFileSync("/sys/class/gpio/gpio" + pin.gpio + "/edge", mode);
    _$jscmd("src/hw_universal.js", "line", 218);
    var resp = {};
    _$jscmd("src/hw_universal.js", "line", 219);
    resp.gpioFile = "/sys/class/gpio/gpio" + pin.gpio + "/value";
    _$jscmd("src/hw_universal.js", "line", 220);
    resp.valuefd = fs.openSync(resp.gpioFile, "r");
    _$jscmd("src/hw_universal.js", "line", 221);
    resp.value = new Buffer(1);
    _$jscmd("src/hw_universal.js", "line", 223);
    return resp;
};

_$jscmd("src/hw_universal.js", "line", 226);

var writePWMFreqAndValue = function(pin, pwm, freq, value, resp, callback) {
    if (_$jscmd("src/hw_universal.js", "cond", "227_8_5", debug)) winston.debug("hw.writePWMFreqAndValue(" + [ pin.key, pwm, freq, value, resp ] + ");");
    _$jscmd("src/hw_universal.js", "line", 228);
    var path = pwmPrefix[pin.pwm.name];
    try {
        _$jscmd("src/hw_universal.js", "line", 230);
        var period = Math.round(1e9 / freq);
        // period in ns
        if (_$jscmd("src/hw_universal.js", "cond", "231_12_16", pwm.freq != freq)) {
            if (_$jscmd("src/hw_universal.js", "cond", "232_16_5", debug)) winston.debug("Stopping PWM");
            _$jscmd("src/hw_universal.js", "line", 233);
            fs.writeFileSync(path + "/run", "0\n");
            if (_$jscmd("src/hw_universal.js", "cond", "234_16_5", debug)) winston.debug("Setting duty to 0");
            _$jscmd("src/hw_universal.js", "line", 235);
            fs.writeFileSync(path + "/duty_ns", "0\n");
            try {
                if (_$jscmd("src/hw_universal.js", "cond", "237_20_5", debug)) winston.debug("Updating PWM period: " + period);
                _$jscmd("src/hw_universal.js", "line", 238);
                fs.writeFileSync(path + "/period_ns", period + "\n");
            } catch (ex2) {
                _$jscmd("src/hw_universal.js", "line", 240);
                period = fs.readFileSync(path + "/period_ns");
                _$jscmd("src/hw_universal.js", "line", 241);
                winston.info("Unable to update PWM period, period is set to " + period);
            }
            if (_$jscmd("src/hw_universal.js", "cond", "243_16_5", debug)) winston.debug("Starting PWM");
            _$jscmd("src/hw_universal.js", "line", 244);
            fs.writeFileSync(path + "/run", "1\n");
        }
        _$jscmd("src/hw_universal.js", "line", 246);
        var duty = Math.round(period * value);
        if (_$jscmd("src/hw_universal.js", "cond", "247_12_5", debug)) winston.debug("Updating PWM duty: " + duty);
        _$jscmd("src/hw_universal.js", "line", 249);
        //if(duty == 0) winston.error('Updating PWM duty: ' + duty);
        fs.writeFileSync(path + "/duty_ns", duty + "\n");
    } catch (ex) {
        _$jscmd("src/hw_universal.js", "line", 251);
        resp.err = "error updating PWM freq and value: " + path + ", " + ex;
        _$jscmd("src/hw_universal.js", "line", 252);
        winston.error(resp.err);
    }
    _$jscmd("src/hw_universal.js", "line", 254);
    return resp;
};

_$jscmd("src/hw_universal.js", "line", 257);

var readEeproms = function(eeproms) {
    _$jscmd("src/hw_universal.js", "line", 258);
    var EepromFiles = {
        "/sys/bus/i2c/drivers/at24/0-0050/eeprom": {
            type: "bone"
        },
        "/sys/bus/i2c/drivers/at24/2-0054/eeprom": {
            type: "cape"
        },
        "/sys/bus/i2c/drivers/at24/2-0055/eeprom": {
            type: "cape"
        },
        "/sys/bus/i2c/drivers/at24/2-0056/eeprom": {
            type: "cape"
        },
        "/sys/bus/i2c/drivers/at24/2-0057/eeprom": {
            type: "cape"
        }
    };
    _$jscmd("src/hw_universal.js", "line", 275);
    eeproms = eeprom.readEeproms(EepromFiles);
    _$jscmd("src/hw_universal.js", "line", 276);
    return eeproms;
};

_$jscmd("src/hw_universal.js", "line", 279);

var readPlatform = function(platform) {
    _$jscmd("src/hw_universal.js", "line", 280);
    var eeproms = eeprom.readEeproms({
        "/sys/bus/i2c/drivers/at24/0-0050/eeprom": {
            type: "bone"
        }
    });
    _$jscmd("src/hw_universal.js", "line", 285);
    var x = eeproms["/sys/bus/i2c/drivers/at24/0-0050/eeprom"];
    if (_$jscmd("src/hw_universal.js", "cond", "286_8_25", x.boardName == "A335BONE")) platform.name = "BeagleBone";
    if (_$jscmd("src/hw_universal.js", "cond", "287_8_25", x.boardName == "A335BNLT")) platform.name = "BeagleBone Black";
    _$jscmd("src/hw_universal.js", "line", 288);
    platform.version = x.version;
    if (_$jscmd("src/hw_universal.js", "cond", "289_8_41", !platform.version.match(/^[\040-\176]*$/))) delete platform.version;
    _$jscmd("src/hw_universal.js", "line", 290);
    platform.serialNumber = x.serialNumber;
    if (_$jscmd("src/hw_universal.js", "cond", "291_8_46", !platform.serialNumber.match(/^[\040-\176]*$/))) delete platform.serialNumber;
    try {
        _$jscmd("src/hw_universal.js", "line", 293);
        platform.dogtag = fs.readFileSync("/etc/dogtag", "ascii");
    } catch (ex) {}
    _$jscmd("src/hw_universal.js", "line", 295);
    return platform;
};

_$jscmd("src/hw_universal.js", "line", 298);

module.exports = {
    logfile: logfile,
    readPWMFreqAndValue: readPWMFreqAndValue,
    readGPIODirection: readGPIODirection,
    readPinMux: readPinMux,
    setPinMode: setPinMode,
    setLEDPinToGPIO: setLEDPinToGPIO,
    exportGPIOControls: exportGPIOControls,
    writeGPIOValue: writeGPIOValue,
    readGPIOValue: readGPIOValue,
    enableAIN: enableAIN,
    readAIN: readAIN,
    writeGPIOEdge: writeGPIOEdge,
    writePWMFreqAndValue: writePWMFreqAndValue,
    readEeproms: readEeproms,
    readPlatform: readPlatform
};