
// instrument by jscoverage, do not modifly this file
(function (file, lines, conds, source) {
  var BASE;
  if (typeof global === 'object') {
    BASE = global;
  } else if (typeof window === 'object') {
    BASE = window;
  } else {
    throw new Error('[jscoverage] unknow ENV!');
  }
  if (BASE._$jscoverage) {
    BASE._$jscmd(file, 'init', lines, conds, source);
    return;
  }
  var cov = {};
  /**
   * jsc(file, 'init', lines, condtions)
   * jsc(file, 'line', lineNum)
   * jsc(file, 'cond', lineNum, expr, start, offset)
   */
  function jscmd(file, type, line, express, start, offset) {
    var storage;
    switch (type) {
      case 'init':
        if(cov[file]){
          storage = cov[file];
        } else {
          storage = [];
          for (var i = 0; i < line.length; i ++) {
            storage[line[i]] = 0;
          }
          var condition = express;
          var source = start;
          storage.condition = condition;
          storage.source = source;
        }
        cov[file] = storage;
        break;
      case 'line':
        storage = cov[file];
        storage[line] ++;
        break;
      case 'cond':
        storage = cov[file];
        storage.condition[line] ++;
        return express;
    }
  }

  BASE._$jscoverage = cov;
  BASE._$jscmd = jscmd;
  jscmd(file, 'init', lines, conds, source);
})('src/autorun.js', [4,5,6,7,8,10,11,12,13,15,178,16,18,20,160,33,34,29,30,31,42,43,44,38,39,53,51,56,61,65,111,70,71,75,76,77,78,79,81,82,83,84,85,87,88,89,90,91,93,94,107,108,109,116,117,118,125,128,129,130,131,135,136,140,141,142,148,152,153,154,156,162,165,169,172], {"10_32_4":0,"10_39_5":0,"16_13_3":0,"23_12_7":0,"28_12_3":0,"37_16_17":0,"41_16_5":0,"49_12_10":0,"50_16_5":0,"68_16_6":0,"69_20_32":0,"74_20_19":0,"80_27_19":0,"86_27_19":0,"92_27_20":0,"124_12_5":0,"146_12_5":0,"151_12_32":0}, ["// Copyright (C) 2013 - Texas Instruments, Jason Kridner","//","//","var fs = require('fs');","var child_process = require('child_process');","var winston = require('winston');","var events = require('events');","var chokidar = require('chokidar');","","var debug = process.env.DEBUG ? true : false;","var apps = {};","var watchers = [];","var emitter = new events.EventEmitter();","","var autorun = function (dir) {","    var ar = dir || '/var/lib/cloud9/autorun';","","    winston.info('Starting bonescript autorun service');","","    fs.exists(ar, arExists);","","    function arExists(exists) {","        if (!exists) fs.mkdir(ar, arWatch);","        else fs.readdir(ar, arFound);","    }","","    function arFound(err, files) {","        if (err) {","            winston.err('Error reading directory: ' + err);","            arWatch();","            return;","        }","        var i = 0;","        arTestNext();","","        function arTestNext() {","            if (i == files.length) {","                arWatch();","                return;","            }","            if (debug) winston.debug(\"arTestNext: files[\" + i + \"] = \" + ar + '/' + files[i]);","            appStart(ar + '/' + files[i]);","            i++;","            arTestNext();","        }","    }","","    function appStart(file) {","        if (apps[file]) {","            if (debug) winston.debug(\"already started: \" + file);","            return;","        }","        appTest();","","        function appTest() {","            fs.exists(file, appExists);","        }","","        function appExists(exists) {","            function onStdout(data) {","                winston.info('stdout (' + file + '): ' + data);","            }","","            function onStderr(data) {","                winston.info('stderr (' + file + '):' + data);","            }","","            if (exists) {","                if (typeof apps[file] != 'undefined') {","                    winston.info('already running: ' + file);","                    return;","                }","","                if (file.match(/\\.js$/)) {","                    winston.info('start: ' + file);","                    apps[file] = child_process.spawn(process.argv[0], [file]);","                    apps[file].on('close', appClosed);","                    apps[file].stdout.on('data', onStdout);","                    apps[file].stderr.on('data', onStderr);","                } else if (file.match(/\\.py$/)) {","                    winston.info('start: ' + file);","                    apps[file] = child_process.spawn('/usr/bin/python', [file]);","                    apps[file].on('close', appClosed);","                    apps[file].stdout.on('data', onStdout);","                    apps[file].stderr.on('data', onStderr);","                } else if (file.match(/\\.sh$/)) {","                    winston.info('start: ' + file);","                    apps[file] = child_process.spawn('/bin/bash', [file]);","                    apps[file].on('close', appClosed);","                    apps[file].stdout.on('data', onStdout);","                    apps[file].stderr.on('data', onStderr);","                } else if (file.match(/\\.ino$/)) {","                    winston.info('start: ' + file);","                    apps[file] = child_process.spawn('/usr/bin/make', [","                        \"-f\",","                        \"/var/lib/cloud9/extras/Userspace-Arduino/Makefile\",","                        \"TARGET=\" + file.replace(/\\.ino$/, ''),","                        \"LOCAL_INO_SRCS=\" + file,","                        \"LOCAL_C_SRCS=\",","                        \"LOCAL_CPP_SRCS=\",","                        \"LOCAL_PDE_SRCS=\",","                        \"LOCAL_AS_SRCS=\",","                        \"COMMON_DEPS=\"","                    ], {","                        'cwd': ar","                    });","                    apps[file].on('close', appClosed);","                    apps[file].stdout.on('data', onStdout);","                    apps[file].stderr.on('data', onStderr);","                }","                emitter.emit('start', file);","            }","        }","","        function appClosed(code, signal) {","            winston.info(\"closed: \" + file);","            delete apps[file];","            emitter.emit('closed', file);","            //setTimeout(appTest, 1000);","        }","    }","","    function arWatch() {","        if (debug) winston.debug(\"arWatch: \" + ar);","        var w = chokidar.watch(ar, {","            persistent: true","        });","        w.on('add', arAdd);","        w.on('change', arChange);","        w.on('unlink', appStop);","        watchers.push(w);","    }","","    function arAdd(filename) {","        winston.info('add: ' + filename);","        appStart(filename);","    }","","    function arChange(filename) {","        winston.info('change: ' + filename);","        appStop(filename);","        appStart(filename);","    }","","    function appStop(file) {","        if (debug) {","            for (var x in apps) {","                winston.debug('running: ' + x);","            }","        }","        if (typeof apps[file] != 'undefined') {","            emitter.emit('stop', file);","            winston.info('stop: ' + file + ' (pid: ' + apps[file].pid + ')');","            apps[file].kill('SIGTERM');","        } else {","            winston.info('already stopped: ' + file);","        }","    }","","    return ({","        getApps: function () {","            return (apps);","        },","        getEmitter: function () {","            return (emitter);","        },","        stop: function () {","            for (var app in apps) {","                appStop(app);","            }","            for (var w in watchers) {","                watchers[w].close();","            }","        }","    });","};","","module.exports = {","    autorun: autorun","};"]);
// Copyright (C) 2013 - Texas Instruments, Jason Kridner
//
//
_$jscmd("src/autorun.js", "line", 4);

var fs = require("fs");

_$jscmd("src/autorun.js", "line", 5);

var child_process = require("child_process");

_$jscmd("src/autorun.js", "line", 6);

var winston = require("winston");

_$jscmd("src/autorun.js", "line", 7);

var events = require("events");

_$jscmd("src/autorun.js", "line", 8);

var chokidar = require("chokidar");

_$jscmd("src/autorun.js", "line", 10);

var debug = process.env.DEBUG ? _$jscmd("src/autorun.js", "cond", "10_32_4", true) : _$jscmd("src/autorun.js", "cond", "10_39_5", false);

_$jscmd("src/autorun.js", "line", 11);

var apps = {};

_$jscmd("src/autorun.js", "line", 12);

var watchers = [];

_$jscmd("src/autorun.js", "line", 13);

var emitter = new events.EventEmitter();

_$jscmd("src/autorun.js", "line", 15);

var autorun = function(dir) {
    _$jscmd("src/autorun.js", "line", 16);
    var ar = _$jscmd("src/autorun.js", "cond", "16_13_3", dir) || "/var/lib/cloud9/autorun";
    _$jscmd("src/autorun.js", "line", 18);
    winston.info("Starting bonescript autorun service");
    _$jscmd("src/autorun.js", "line", 20);
    fs.exists(ar, arExists);
    function arExists(exists) {
        if (_$jscmd("src/autorun.js", "cond", "23_12_7", !exists)) fs.mkdir(ar, arWatch); else fs.readdir(ar, arFound);
    }
    function arFound(err, files) {
        if (_$jscmd("src/autorun.js", "cond", "28_12_3", err)) {
            _$jscmd("src/autorun.js", "line", 29);
            winston.err("Error reading directory: " + err);
            _$jscmd("src/autorun.js", "line", 30);
            arWatch();
            _$jscmd("src/autorun.js", "line", 31);
            return;
        }
        _$jscmd("src/autorun.js", "line", 33);
        var i = 0;
        _$jscmd("src/autorun.js", "line", 34);
        arTestNext();
        function arTestNext() {
            if (_$jscmd("src/autorun.js", "cond", "37_16_17", i == files.length)) {
                _$jscmd("src/autorun.js", "line", 38);
                arWatch();
                _$jscmd("src/autorun.js", "line", 39);
                return;
            }
            if (_$jscmd("src/autorun.js", "cond", "41_16_5", debug)) winston.debug("arTestNext: files[" + i + "] = " + ar + "/" + files[i]);
            _$jscmd("src/autorun.js", "line", 42);
            appStart(ar + "/" + files[i]);
            _$jscmd("src/autorun.js", "line", 43);
            i++;
            _$jscmd("src/autorun.js", "line", 44);
            arTestNext();
        }
    }
    function appStart(file) {
        if (_$jscmd("src/autorun.js", "cond", "49_12_10", apps[file])) {
            if (_$jscmd("src/autorun.js", "cond", "50_16_5", debug)) winston.debug("already started: " + file);
            _$jscmd("src/autorun.js", "line", 51);
            return;
        }
        _$jscmd("src/autorun.js", "line", 53);
        appTest();
        function appTest() {
            _$jscmd("src/autorun.js", "line", 56);
            fs.exists(file, appExists);
        }
        function appExists(exists) {
            function onStdout(data) {
                _$jscmd("src/autorun.js", "line", 61);
                winston.info("stdout (" + file + "): " + data);
            }
            function onStderr(data) {
                _$jscmd("src/autorun.js", "line", 65);
                winston.info("stderr (" + file + "):" + data);
            }
            if (_$jscmd("src/autorun.js", "cond", "68_16_6", exists)) {
                if (_$jscmd("src/autorun.js", "cond", "69_20_32", typeof apps[file] != "undefined")) {
                    _$jscmd("src/autorun.js", "line", 70);
                    winston.info("already running: " + file);
                    _$jscmd("src/autorun.js", "line", 71);
                    return;
                }
                if (_$jscmd("src/autorun.js", "cond", "74_20_19", file.match(/\.js$/))) {
                    _$jscmd("src/autorun.js", "line", 75);
                    winston.info("start: " + file);
                    _$jscmd("src/autorun.js", "line", 76);
                    apps[file] = child_process.spawn(process.argv[0], [ file ]);
                    _$jscmd("src/autorun.js", "line", 77);
                    apps[file].on("close", appClosed);
                    _$jscmd("src/autorun.js", "line", 78);
                    apps[file].stdout.on("data", onStdout);
                    _$jscmd("src/autorun.js", "line", 79);
                    apps[file].stderr.on("data", onStderr);
                } else if (_$jscmd("src/autorun.js", "cond", "80_27_19", file.match(/\.py$/))) {
                    _$jscmd("src/autorun.js", "line", 81);
                    winston.info("start: " + file);
                    _$jscmd("src/autorun.js", "line", 82);
                    apps[file] = child_process.spawn("/usr/bin/python", [ file ]);
                    _$jscmd("src/autorun.js", "line", 83);
                    apps[file].on("close", appClosed);
                    _$jscmd("src/autorun.js", "line", 84);
                    apps[file].stdout.on("data", onStdout);
                    _$jscmd("src/autorun.js", "line", 85);
                    apps[file].stderr.on("data", onStderr);
                } else if (_$jscmd("src/autorun.js", "cond", "86_27_19", file.match(/\.sh$/))) {
                    _$jscmd("src/autorun.js", "line", 87);
                    winston.info("start: " + file);
                    _$jscmd("src/autorun.js", "line", 88);
                    apps[file] = child_process.spawn("/bin/bash", [ file ]);
                    _$jscmd("src/autorun.js", "line", 89);
                    apps[file].on("close", appClosed);
                    _$jscmd("src/autorun.js", "line", 90);
                    apps[file].stdout.on("data", onStdout);
                    _$jscmd("src/autorun.js", "line", 91);
                    apps[file].stderr.on("data", onStderr);
                } else if (_$jscmd("src/autorun.js", "cond", "92_27_20", file.match(/\.ino$/))) {
                    _$jscmd("src/autorun.js", "line", 93);
                    winston.info("start: " + file);
                    _$jscmd("src/autorun.js", "line", 94);
                    apps[file] = child_process.spawn("/usr/bin/make", [ "-f", "/var/lib/cloud9/extras/Userspace-Arduino/Makefile", "TARGET=" + file.replace(/\.ino$/, ""), "LOCAL_INO_SRCS=" + file, "LOCAL_C_SRCS=", "LOCAL_CPP_SRCS=", "LOCAL_PDE_SRCS=", "LOCAL_AS_SRCS=", "COMMON_DEPS=" ], {
                        cwd: ar
                    });
                    _$jscmd("src/autorun.js", "line", 107);
                    apps[file].on("close", appClosed);
                    _$jscmd("src/autorun.js", "line", 108);
                    apps[file].stdout.on("data", onStdout);
                    _$jscmd("src/autorun.js", "line", 109);
                    apps[file].stderr.on("data", onStderr);
                }
                _$jscmd("src/autorun.js", "line", 111);
                emitter.emit("start", file);
            }
        }
        function appClosed(code, signal) {
            _$jscmd("src/autorun.js", "line", 116);
            winston.info("closed: " + file);
            _$jscmd("src/autorun.js", "line", 117);
            delete apps[file];
            _$jscmd("src/autorun.js", "line", 118);
            emitter.emit("closed", file);
        }
    }
    function arWatch() {
        if (_$jscmd("src/autorun.js", "cond", "124_12_5", debug)) winston.debug("arWatch: " + ar);
        _$jscmd("src/autorun.js", "line", 125);
        var w = chokidar.watch(ar, {
            persistent: true
        });
        _$jscmd("src/autorun.js", "line", 128);
        w.on("add", arAdd);
        _$jscmd("src/autorun.js", "line", 129);
        w.on("change", arChange);
        _$jscmd("src/autorun.js", "line", 130);
        w.on("unlink", appStop);
        _$jscmd("src/autorun.js", "line", 131);
        watchers.push(w);
    }
    function arAdd(filename) {
        _$jscmd("src/autorun.js", "line", 135);
        winston.info("add: " + filename);
        _$jscmd("src/autorun.js", "line", 136);
        appStart(filename);
    }
    function arChange(filename) {
        _$jscmd("src/autorun.js", "line", 140);
        winston.info("change: " + filename);
        _$jscmd("src/autorun.js", "line", 141);
        appStop(filename);
        _$jscmd("src/autorun.js", "line", 142);
        appStart(filename);
    }
    function appStop(file) {
        if (_$jscmd("src/autorun.js", "cond", "146_12_5", debug)) {
            for (var x in apps) {
                _$jscmd("src/autorun.js", "line", 148);
                winston.debug("running: " + x);
            }
        }
        if (_$jscmd("src/autorun.js", "cond", "151_12_32", typeof apps[file] != "undefined")) {
            _$jscmd("src/autorun.js", "line", 152);
            emitter.emit("stop", file);
            _$jscmd("src/autorun.js", "line", 153);
            winston.info("stop: " + file + " (pid: " + apps[file].pid + ")");
            _$jscmd("src/autorun.js", "line", 154);
            apps[file].kill("SIGTERM");
        } else {
            _$jscmd("src/autorun.js", "line", 156);
            winston.info("already stopped: " + file);
        }
    }
    _$jscmd("src/autorun.js", "line", 160);
    return {
        getApps: function() {
            _$jscmd("src/autorun.js", "line", 162);
            return apps;
        },
        getEmitter: function() {
            _$jscmd("src/autorun.js", "line", 165);
            return emitter;
        },
        stop: function() {
            for (var app in apps) {
                _$jscmd("src/autorun.js", "line", 169);
                appStop(app);
            }
            for (var w in watchers) {
                _$jscmd("src/autorun.js", "line", 172);
                watchers[w].close();
            }
        }
    };
};

_$jscmd("src/autorun.js", "line", 178);

module.exports = {
    autorun: autorun
};