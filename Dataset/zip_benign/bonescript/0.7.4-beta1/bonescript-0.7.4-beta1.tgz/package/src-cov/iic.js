
// instrument by jscoverage, do not modifly this file
(function (file, lines, conds, source) {
  var BASE;
  if (typeof global === 'object') {
    BASE = global;
  } else if (typeof window === 'object') {
    BASE = window;
  } else {
    throw new Error('[jscoverage] unknow ENV!');
  }
  if (BASE._$jscoverage) {
    BASE._$jscmd(file, 'init', lines, conds, source);
    return;
  }
  var cov = {};
  /**
   * jsc(file, 'init', lines, condtions)
   * jsc(file, 'line', lineNum)
   * jsc(file, 'cond', lineNum, expr, start, offset)
   */
  function jscmd(file, type, line, express, start, offset) {
    var storage;
    switch (type) {
      case 'init':
        if(cov[file]){
          storage = cov[file];
        } else {
          storage = [];
          for (var i = 0; i < line.length; i ++) {
            storage[line[i]] = 0;
          }
          var condition = express;
          var source = start;
          storage.condition = condition;
          storage.source = source;
        }
        cov[file] = storage;
        break;
      case 'line':
        storage = cov[file];
        storage[line] ++;
        break;
      case 'cond':
        storage = cov[file];
        storage.condition[line] ++;
        return express;
    }
  }

  BASE._$jscoverage = cov;
  BASE._$jscmd = jscmd;
  jscmd(file, 'init', lines, conds, source);
})('src/iic.js', [2,3,5,6,7,8,9,12,13,22,14,17,18,19], {"15_8_26":0,"16_8_33":0}, ["// Copyright (C) 2013 - Texas Instruments, Jason Kridner","var bone = require('./bone');","var my = require('./my');","","var m = {};","m.name = 'i2c';","m.module = my.require('i2c');","m.ports = bone.i2c;","m.events = {","    'data': ['data']","};","m.openPorts = {};","m.doOpen = function (args) {","    var path = args.port[0];","    if (m.ports[args.port[0]].path) path = m.ports[args.port[0]].path;","    if (typeof args.options !== typeof {}) args.options = {};","    args.options.device = path;","    var openPort = new m.module(args.port[1], args.options);","    return (openPort);","};","","module.exports = {","    i2cOpen: my.wrapOpen(m, ['options']),","    i2cScan: my.wrapCall(m, 'scan', [], ['err', 'data']),","    i2cWriteByte: my.wrapCall(m, 'writeByte', ['byte'], ['err']),","    i2cWriteBytes: my.wrapCall(m, 'writeBytes', ['command', 'bytes'], ['err']),","    i2cReadByte: my.wrapCall(m, 'readByte', [], ['err', 'res']),","    i2cReadBytes: my.wrapCall(m, 'readBytes', ['command', 'length'], ['err', 'res']),","    i2cStream: my.wrapCall(m, 'stream', ['command', 'length', 'delay'], [])","}"]);
// Copyright (C) 2013 - Texas Instruments, Jason Kridner
_$jscmd("src/iic.js", "line", 2);

var bone = require("./bone");

_$jscmd("src/iic.js", "line", 3);

var my = require("./my");

_$jscmd("src/iic.js", "line", 5);

var m = {};

_$jscmd("src/iic.js", "line", 6);

m.name = "i2c";

_$jscmd("src/iic.js", "line", 7);

m.module = my.require("i2c");

_$jscmd("src/iic.js", "line", 8);

m.ports = bone.i2c;

_$jscmd("src/iic.js", "line", 9);

m.events = {
    data: [ "data" ]
};

_$jscmd("src/iic.js", "line", 12);

m.openPorts = {};

_$jscmd("src/iic.js", "line", 13);

m.doOpen = function(args) {
    _$jscmd("src/iic.js", "line", 14);
    var path = args.port[0];
    if (_$jscmd("src/iic.js", "cond", "15_8_26", m.ports[args.port[0]].path)) path = m.ports[args.port[0]].path;
    if (_$jscmd("src/iic.js", "cond", "16_8_33", typeof args.options !== typeof {})) args.options = {};
    _$jscmd("src/iic.js", "line", 17);
    args.options.device = path;
    _$jscmd("src/iic.js", "line", 18);
    var openPort = new m.module(args.port[1], args.options);
    _$jscmd("src/iic.js", "line", 19);
    return openPort;
};

_$jscmd("src/iic.js", "line", 22);

module.exports = {
    i2cOpen: my.wrapOpen(m, [ "options" ]),
    i2cScan: my.wrapCall(m, "scan", [], [ "err", "data" ]),
    i2cWriteByte: my.wrapCall(m, "writeByte", [ "byte" ], [ "err" ]),
    i2cWriteBytes: my.wrapCall(m, "writeBytes", [ "command", "bytes" ], [ "err" ]),
    i2cReadByte: my.wrapCall(m, "readByte", [], [ "err", "res" ]),
    i2cReadBytes: my.wrapCall(m, "readBytes", [ "command", "length" ], [ "err", "res" ]),
    i2cStream: my.wrapCall(m, "stream", [ "command", "length", "delay" ], [])
};