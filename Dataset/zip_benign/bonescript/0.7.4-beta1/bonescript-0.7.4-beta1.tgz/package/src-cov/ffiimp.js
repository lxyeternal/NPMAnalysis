
// instrument by jscoverage, do not modifly this file
(function (file, lines, conds, source) {
  var BASE;
  if (typeof global === 'object') {
    BASE = global;
  } else if (typeof window === 'object') {
    BASE = window;
  } else {
    throw new Error('[jscoverage] unknow ENV!');
  }
  if (BASE._$jscoverage) {
    BASE._$jscmd(file, 'init', lines, conds, source);
    return;
  }
  var cov = {};
  /**
   * jsc(file, 'init', lines, condtions)
   * jsc(file, 'line', lineNum)
   * jsc(file, 'cond', lineNum, expr, start, offset)
   */
  function jscmd(file, type, line, express, start, offset) {
    var storage;
    switch (type) {
      case 'init':
        if(cov[file]){
          storage = cov[file];
        } else {
          storage = [];
          for (var i = 0; i < line.length; i ++) {
            storage[line[i]] = 0;
          }
          var condition = express;
          var source = start;
          storage.condition = condition;
          storage.source = source;
        }
        cov[file] = storage;
        break;
      case 'line':
        storage = cov[file];
        storage[line] ++;
        break;
      case 'cond':
        storage = cov[file];
        storage.condition[line] ++;
        return express;
    }
  }

  BASE._$jscoverage = cov;
  BASE._$jscmd = jscmd;
  jscmd(file, 'init', lines, conds, source);
})('src/ffiimp.js', [1,2,3,4,5,6,8,10,25,45,66,11,12,22,14,17,19,20,29,34,30,37,39,40,49,50,51,56,61,62], {"8_32_4":0,"8_39_5":0,"13_8_28":0,"16_8_33":0,"18_15_33":0,"26_8_28":0,"28_8_29":0,"47_8_24":0,"49_11_4":0,"52_8_4":0,"53_8_5":0,"58_8_10":0}, ["var bone = require('./bone');","var fs = require('fs');","var shell = require('shelljs');","var winston = require('winston');","var my = require('./my');","var ffi = my.require('ffi');","","var debug = process.env.DEBUG ? true : false;","//function to convert bonescript pin identifier to MRAA's format","var mraaGPIO = function (pin) {","    var pinObject = bone.getPinObject(pin);","    var pinNo;","    if (typeof pinObject != 'object') {","        throw (\"Invalid pin: \" + pin);","    }","    if (pinObject.key.indexOf('P8') != -1) {","        pinNo = Number(pinObject.key.replace('P8_', ''));","    } else if (pinObject.key.indexOf('P9') != -1) {","        pinNo = Number(pinObject.key.replace('P9_', ''));","        pinNo += 46;","    }","    return '0x' + pinNo.toString(16);","};","// function to write a .c file at path , similar to writeTextFile","var writeCModule = function (filename, data, callback) {","    if (filename.indexOf(\".c\") == -1)","        filename += \".c\";","    if (typeof callback == 'function') {","        var cb = function (err) {","            callback({","                'err': err","            });","        };","        fs.writeFile(filename, data, 'utf-8', cb);","    } else {","        try {","            return fs.writeFileSync(filename, data, 'utf-8');","        } catch (ex) {","            winston.error(\"writeCModule error: \" + ex);","            return (false);","        }","    }","};","//load C module from shared object at path","var loadCModule = function (path, args, mraa) {","    //compile at the path if shared object does not exist","    if (path.indexOf('.c') != -1)","        path = path.replace('.c', '');","    mraa = mraa || false; // link mraa","    var inPath = path + '.c';","    var shellCmd = 'gcc -shared -fpic ' + inPath + ' -o ' + path + '.so';","    if (mraa) shellCmd += ' -lmraa';","    if (debug) winston.debug('loadCModule: shellCmd = ' + shellCmd);","","    // Consider not running if .so newer than .c","    shell.exec(shellCmd);","","    if (ffi.exists)","        return ffi.Library(path, args);","    else {","        winston.info(\"loadCModule: Could not load module FFI\");","        return \"ffi not loaded\";","    }","};","","module.exports = {","    mraaGPIO: mraaGPIO,","    loadCModule: loadCModule,","    writeCModule: writeCModule","}"]);
_$jscmd("src/ffiimp.js", "line", 1);

var bone = require("./bone");

_$jscmd("src/ffiimp.js", "line", 2);

var fs = require("fs");

_$jscmd("src/ffiimp.js", "line", 3);

var shell = require("shelljs");

_$jscmd("src/ffiimp.js", "line", 4);

var winston = require("winston");

_$jscmd("src/ffiimp.js", "line", 5);

var my = require("./my");

_$jscmd("src/ffiimp.js", "line", 6);

var ffi = my.require("ffi");

_$jscmd("src/ffiimp.js", "line", 8);

var debug = process.env.DEBUG ? _$jscmd("src/ffiimp.js", "cond", "8_32_4", true) : _$jscmd("src/ffiimp.js", "cond", "8_39_5", false);

_$jscmd("src/ffiimp.js", "line", 10);

//function to convert bonescript pin identifier to MRAA's format
var mraaGPIO = function(pin) {
    _$jscmd("src/ffiimp.js", "line", 11);
    var pinObject = bone.getPinObject(pin);
    _$jscmd("src/ffiimp.js", "line", 12);
    var pinNo;
    if (_$jscmd("src/ffiimp.js", "cond", "13_8_28", typeof pinObject != "object")) {
        _$jscmd("src/ffiimp.js", "line", 14);
        throw "Invalid pin: " + pin;
    }
    if (_$jscmd("src/ffiimp.js", "cond", "16_8_33", pinObject.key.indexOf("P8") != -1)) {
        _$jscmd("src/ffiimp.js", "line", 17);
        pinNo = Number(pinObject.key.replace("P8_", ""));
    } else if (_$jscmd("src/ffiimp.js", "cond", "18_15_33", pinObject.key.indexOf("P9") != -1)) {
        _$jscmd("src/ffiimp.js", "line", 19);
        pinNo = Number(pinObject.key.replace("P9_", ""));
        _$jscmd("src/ffiimp.js", "line", 20);
        pinNo += 46;
    }
    _$jscmd("src/ffiimp.js", "line", 22);
    return "0x" + pinNo.toString(16);
};

_$jscmd("src/ffiimp.js", "line", 25);

// function to write a .c file at path , similar to writeTextFile
var writeCModule = function(filename, data, callback) {
    if (_$jscmd("src/ffiimp.js", "cond", "26_8_28", filename.indexOf(".c") == -1)) filename += ".c";
    if (_$jscmd("src/ffiimp.js", "cond", "28_8_29", typeof callback == "function")) {
        _$jscmd("src/ffiimp.js", "line", 29);
        var cb = function(err) {
            _$jscmd("src/ffiimp.js", "line", 30);
            callback({
                err: err
            });
        };
        _$jscmd("src/ffiimp.js", "line", 34);
        fs.writeFile(filename, data, "utf-8", cb);
    } else {
        try {
            _$jscmd("src/ffiimp.js", "line", 37);
            return fs.writeFileSync(filename, data, "utf-8");
        } catch (ex) {
            _$jscmd("src/ffiimp.js", "line", 39);
            winston.error("writeCModule error: " + ex);
            _$jscmd("src/ffiimp.js", "line", 40);
            return false;
        }
    }
};

_$jscmd("src/ffiimp.js", "line", 45);

//load C module from shared object at path
var loadCModule = function(path, args, mraa) {
    //compile at the path if shared object does not exist
    if (_$jscmd("src/ffiimp.js", "cond", "47_8_24", path.indexOf(".c") != -1)) path = path.replace(".c", "");
    _$jscmd("src/ffiimp.js", "line", 49);
    mraa = _$jscmd("src/ffiimp.js", "cond", "49_11_4", mraa) || false;
    _$jscmd("src/ffiimp.js", "line", 50);
    // link mraa
    var inPath = path + ".c";
    _$jscmd("src/ffiimp.js", "line", 51);
    var shellCmd = "gcc -shared -fpic " + inPath + " -o " + path + ".so";
    if (_$jscmd("src/ffiimp.js", "cond", "52_8_4", mraa)) shellCmd += " -lmraa";
    if (_$jscmd("src/ffiimp.js", "cond", "53_8_5", debug)) winston.debug("loadCModule: shellCmd = " + shellCmd);
    _$jscmd("src/ffiimp.js", "line", 56);
    // Consider not running if .so newer than .c
    shell.exec(shellCmd);
    if (_$jscmd("src/ffiimp.js", "cond", "58_8_10", ffi.exists)) return ffi.Library(path, args); else {
        _$jscmd("src/ffiimp.js", "line", 61);
        winston.info("loadCModule: Could not load module FFI");
        _$jscmd("src/ffiimp.js", "line", 62);
        return "ffi not loaded";
    }
};

_$jscmd("src/ffiimp.js", "line", 66);

module.exports = {
    mraaGPIO: mraaGPIO,
    loadCModule: loadCModule,
    writeCModule: writeCModule
};