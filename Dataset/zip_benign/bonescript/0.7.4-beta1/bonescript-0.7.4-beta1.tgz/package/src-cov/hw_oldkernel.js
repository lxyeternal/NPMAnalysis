
// instrument by jscoverage, do not modifly this file
(function (file, lines, conds, source) {
  var BASE;
  if (typeof global === 'object') {
    BASE = global;
  } else if (typeof window === 'object') {
    BASE = window;
  } else {
    throw new Error('[jscoverage] unknow ENV!');
  }
  if (BASE._$jscoverage) {
    BASE._$jscmd(file, 'init', lines, conds, source);
    return;
  }
  var cov = {};
  /**
   * jsc(file, 'init', lines, condtions)
   * jsc(file, 'line', lineNum)
   * jsc(file, 'cond', lineNum, expr, start, offset)
   */
  function jscmd(file, type, line, express, start, offset) {
    var storage;
    switch (type) {
      case 'init':
        if(cov[file]){
          storage = cov[file];
        } else {
          storage = [];
          for (var i = 0; i < line.length; i ++) {
            storage[line[i]] = 0;
          }
          var condition = express;
          var source = start;
          storage.condition = condition;
          storage.source = source;
        }
        cov[file] = storage;
        break;
      case 'line':
        storage = cov[file];
        storage[line] ++;
        break;
      case 'cond':
        storage = cov[file];
        storage.condition[line] ++;
        return express;
    }
  }

  BASE._$jscoverage = cov;
  BASE._$jscmd = jscmd;
  jscmd(file, 'init', lines, conds, source);
})('src/hw_oldkernel.js', [3,4,5,6,7,8,10,12,13,15,17,29,31,60,94,108,110,133,135,139,165,167,179,201,205,18,26,20,21,22,24,32,33,42,57,39,40,35,37,44,48,51,52,61,62,91,65,66,68,69,73,75,78,79,80,83,86,87,88,89,95,105,98,100,101,102,112,114,115,118,123,126,128,136,140,153,158,162,142,150,151,147,148,144,145,155,156,160,168,175,176,170,171,172,173,180,197,198,202], {"34_12_3":0,"36_16_5":0,"43_12_6":0,"47_8_8":0,"54_16_5":0,"72_8_18":0,"74_12_7":0,"77_15_19":0,"97_8_24":0,"111_8_39":0,"113_12_7":0,"117_12_38":0,"121_8_5":0,"122_8_8":0,"141_8_8":0,"143_16_3":0,"154_8_17":0,"159_8_17":0,"169_8_16":0}, ["// Used for 3.2 kernel using /sys/kernel/debug/omap_mux/","","var fs = require('fs');","var my = require('./my');","var parse = require('./parse');","var eeprom = require('./eeprom');","var hw_capemgr = require('./hw_capemgr');","var winston = require('winston');","","var debug = true;","","var gpioFile = {};","var pwmPrefix = {};","","var logfile = '/var/lib/cloud9/bonescript.log';","","var readPWMFreqAndValue = function (pin, pwm) {","    var mode = {};","    try {","        var duty_percent = fs.readFileSync(pwmPrefix[pin.pwm.name] + '/duty_percent');","        mode.freq = fs.readFileSync(pwmPrefix[pin.pwm.name] + '/period_freq');","        mode.value = duty_percent / 100.0;","    } catch (ex) {","        mode.err = 'cannot set PWM frequency and value: ' + ex;","    }","    return (mode);","};","","var readGPIODirection = hw_capemgr.readGPIODirection;","","var readPinMux = function (pin, mode, callback) {","    var muxFile = '/sys/kernel/debug/omap_mux/' + pin.mux;","    var readOmapMux = function (err, data) {","        if (err) {","            mode.err = 'readOmapMux error: ' + err;","            if (debug) winston.debug(mode.err);","            callback(mode);","        }","        mode = parse.modeFromOmapMux(data, mode);","        callback(mode);","    };","    var tryOmapMux = function (exists) {","        if (exists) {","            fs.readFile(muxFile, 'utf8', readOmapMux);","        }","    };","    if (callback) {","        my.file_exists(muxFile, tryOmapMux);","    } else {","        try {","            var data = fs.readFileSync(muxFile, 'utf8');","            mode = parse.modeFromOmapMux(data, mode);","        } catch (ex) {","            if (debug) winston.debug('getPinMode(' + pin.key + '): ' + ex);","        }","    }","    return (mode);","};","","var setPinMode = function (pin, pinData, template, resp) {","    var muxFile = '/sys/kernel/debug/omap_mux/' + pin.mux;","    var n = pin.gpio;","","    try {","        var fd = fs.openSync(muxFile, 'w');","        fs.writeSync(fd, pinData.toString(16), null);","    } catch (ex) {","        resp.err = 'Error writing to ' + muxFile + ': ' + ex;","        return (resp);","    }","","    if (template == 'bspm') {","        gpioFile[pin.key] = '/sys/class/gpio/gpio' + pin.gpio + '/value';","        if (pin.led) {","            gpioFile[pin.key] = '/sys/class/leds/beaglebone::' + pin.led + '/brightness';","        }","    } else if (template == 'bspwm') {","        resp.path = '/sys/class/pwm/' + pin.pwm.path;","        var path = resp.path;","        pwmPrefix[pin.pwm.name] = path;","","        // Clear up any unmanaged usage","        fs.writeFileSync(path + '/request', '0');","","        // Allocate and configure the PWM","        fs.writeFileSync(path + '/request', '1');","        fs.writeFileSync(path + '/period_freq', '0');","        fs.writeFileSync(path + '/polarity', '0');","        fs.writeFileSync(path + '/run', '1');","    }","    return (resp);","};","","var setLEDPinToGPIO = function (pin, resp) {","    var path = \"/sys/class/leds/beaglebone::\" + pin.led + \"/trigger\";","","    if (my.file_existsSync(path)) {","        fs.writeFileSync(path, \"gpio\");","    } else {","        resp.err = \"Unable to find LED: \" + pin.led;","        winston.error(resp.err);","        resp.value = false;","    }","","    return (resp);","};","","var exportGPIOControls = hw_capemgr.exportGPIOControls;","","var writeGPIOValue = function (pin, value, callback) {","    if (typeof gpioFile[pin.key] == 'undefined') {","        gpioFile[pin.key] = '/sys/class/gpio/gpio' + pin.gpio + '/value';","        if (pin.led) {","            gpioFile[pin.key] = \"/sys/class/leds/beaglebone:\";","            gpioFile[pin.key] += \":\" + pin.led + \"/brightness\";","        }","        if (!my.file_existsSync(gpioFile[pin.key])) {","            winston.error(\"Unable to find gpio: \" + gpioFile[pin.key]);","        }","    }","    if (debug) winston.debug(\"gpioFile = \" + gpioFile[pin.key]);","    if (callback) {","        fs.writeFile(gpioFile[pin.key], '' + value, null, callback);","    } else {","        try {","            fs.writeFileSync(gpioFile[pin.key], '' + value, null);","        } catch (ex) {","            winston.error(\"Unable to write to \" + gpioFile[pin.key]);","        }","    }","};","","var readGPIOValue = hw_capemgr.readGPIOValue;","","var enableAIN = function () {","    return (true);","};","","var readAIN = function (pin, resp, callback) {","    var ainFile = '/sys/bus/platform/devices/tsc/ain' + (pin.ain + 1).toString();","    if (callback) {","        var readFile = function (err, data) {","            if (err) {","                resp.err = 'analogRead error: ' + err;","                winston.error(resp.err);","            }","            resp.value = parseInt(data, 10) / 4096;","            callback(resp);","        };","        fs.readFile(ainFile, readFile);","        return (resp);","    }","    resp.value = parseInt(fs.readFileSync(ainFile), 10);","    if (isNaN(resp.value)) {","        resp.err = 'analogRead(' + pin.key + ') returned ' + resp.value;","        winston.error(resp.err);","    }","    resp.value = resp.value / 4096;","    if (isNaN(resp.value)) {","        resp.err = 'analogRead(' + pin.key + ') scaled to ' + resp.value;","    }","    return (resp);","};","","var writeGPIOEdge = hw_capemgr.writeGPIOEdge;","","var writePWMFreqAndValue = function (pin, pwm, freq, value, resp) {","    var path = pwmPrefix[pin.pwm.name];","    if (pwm.freq != freq) {","        fs.writeFileSync(path + '/run', '0');","        fs.writeFileSync(path + '/duty_percent', '0');","        fs.writeFileSync(path + '/period_freq', Math.round(freq));","        fs.writeFileSync(path + '/run', '1');","    }","    fs.writeFileSync(path + '/duty_percent', Math.round(value * 100));","    return (resp);","};","","var readEeproms = function (eeproms) {","    var EepromFiles = {","        '/sys/bus/i2c/drivers/at24/1-0050/eeprom': {","            type: 'bone'","        },","        '/sys/bus/i2c/drivers/at24/3-0054/eeprom': {","            type: 'cape'","        },","        '/sys/bus/i2c/drivers/at24/3-0055/eeprom': {","            type: 'cape'","        },","        '/sys/bus/i2c/drivers/at24/3-0056/eeprom': {","            type: 'cape'","        },","        '/sys/bus/i2c/drivers/at24/3-0057/eeprom': {","            type: 'cape'","        }","    };","    eeproms = eeprom.readEeproms(EepromFiles);","    return (eeproms);","};","","var readPlatform = function (platform) {","    return (platform);","};","","module.exports = {","    logfile: logfile,","    readPWMFreqAndValue: readPWMFreqAndValue,","    readGPIODirection: readGPIODirection,","    readPinMux: readPinMux,","    setPinMode: setPinMode,","    setLEDPinToGPIO: setLEDPinToGPIO,","    exportGPIOControls: exportGPIOControls,","    writeGPIOValue: writeGPIOValue,","    readGPIOValue: readGPIOValue,","    enableAIN: enableAIN,","    readAIN: readAIN,","    writeGPIOEdge: writeGPIOEdge,","    writePWMFreqAndValue: writePWMFreqAndValue,","    readEeproms: readEeproms,","    readPlatform: readPlatform","}"]);
// Used for 3.2 kernel using /sys/kernel/debug/omap_mux/
_$jscmd("src/hw_oldkernel.js", "line", 3);

var fs = require("fs");

_$jscmd("src/hw_oldkernel.js", "line", 4);

var my = require("./my");

_$jscmd("src/hw_oldkernel.js", "line", 5);

var parse = require("./parse");

_$jscmd("src/hw_oldkernel.js", "line", 6);

var eeprom = require("./eeprom");

_$jscmd("src/hw_oldkernel.js", "line", 7);

var hw_capemgr = require("./hw_capemgr");

_$jscmd("src/hw_oldkernel.js", "line", 8);

var winston = require("winston");

_$jscmd("src/hw_oldkernel.js", "line", 10);

var debug = true;

_$jscmd("src/hw_oldkernel.js", "line", 12);

var gpioFile = {};

_$jscmd("src/hw_oldkernel.js", "line", 13);

var pwmPrefix = {};

_$jscmd("src/hw_oldkernel.js", "line", 15);

var logfile = "/var/lib/cloud9/bonescript.log";

_$jscmd("src/hw_oldkernel.js", "line", 17);

var readPWMFreqAndValue = function(pin, pwm) {
    _$jscmd("src/hw_oldkernel.js", "line", 18);
    var mode = {};
    try {
        _$jscmd("src/hw_oldkernel.js", "line", 20);
        var duty_percent = fs.readFileSync(pwmPrefix[pin.pwm.name] + "/duty_percent");
        _$jscmd("src/hw_oldkernel.js", "line", 21);
        mode.freq = fs.readFileSync(pwmPrefix[pin.pwm.name] + "/period_freq");
        _$jscmd("src/hw_oldkernel.js", "line", 22);
        mode.value = duty_percent / 100;
    } catch (ex) {
        _$jscmd("src/hw_oldkernel.js", "line", 24);
        mode.err = "cannot set PWM frequency and value: " + ex;
    }
    _$jscmd("src/hw_oldkernel.js", "line", 26);
    return mode;
};

_$jscmd("src/hw_oldkernel.js", "line", 29);

var readGPIODirection = hw_capemgr.readGPIODirection;

_$jscmd("src/hw_oldkernel.js", "line", 31);

var readPinMux = function(pin, mode, callback) {
    _$jscmd("src/hw_oldkernel.js", "line", 32);
    var muxFile = "/sys/kernel/debug/omap_mux/" + pin.mux;
    _$jscmd("src/hw_oldkernel.js", "line", 33);
    var readOmapMux = function(err, data) {
        if (_$jscmd("src/hw_oldkernel.js", "cond", "34_12_3", err)) {
            _$jscmd("src/hw_oldkernel.js", "line", 35);
            mode.err = "readOmapMux error: " + err;
            if (_$jscmd("src/hw_oldkernel.js", "cond", "36_16_5", debug)) winston.debug(mode.err);
            _$jscmd("src/hw_oldkernel.js", "line", 37);
            callback(mode);
        }
        _$jscmd("src/hw_oldkernel.js", "line", 39);
        mode = parse.modeFromOmapMux(data, mode);
        _$jscmd("src/hw_oldkernel.js", "line", 40);
        callback(mode);
    };
    _$jscmd("src/hw_oldkernel.js", "line", 42);
    var tryOmapMux = function(exists) {
        if (_$jscmd("src/hw_oldkernel.js", "cond", "43_12_6", exists)) {
            _$jscmd("src/hw_oldkernel.js", "line", 44);
            fs.readFile(muxFile, "utf8", readOmapMux);
        }
    };
    if (_$jscmd("src/hw_oldkernel.js", "cond", "47_8_8", callback)) {
        _$jscmd("src/hw_oldkernel.js", "line", 48);
        my.file_exists(muxFile, tryOmapMux);
    } else {
        try {
            _$jscmd("src/hw_oldkernel.js", "line", 51);
            var data = fs.readFileSync(muxFile, "utf8");
            _$jscmd("src/hw_oldkernel.js", "line", 52);
            mode = parse.modeFromOmapMux(data, mode);
        } catch (ex) {
            if (_$jscmd("src/hw_oldkernel.js", "cond", "54_16_5", debug)) winston.debug("getPinMode(" + pin.key + "): " + ex);
        }
    }
    _$jscmd("src/hw_oldkernel.js", "line", 57);
    return mode;
};

_$jscmd("src/hw_oldkernel.js", "line", 60);

var setPinMode = function(pin, pinData, template, resp) {
    _$jscmd("src/hw_oldkernel.js", "line", 61);
    var muxFile = "/sys/kernel/debug/omap_mux/" + pin.mux;
    _$jscmd("src/hw_oldkernel.js", "line", 62);
    var n = pin.gpio;
    try {
        _$jscmd("src/hw_oldkernel.js", "line", 65);
        var fd = fs.openSync(muxFile, "w");
        _$jscmd("src/hw_oldkernel.js", "line", 66);
        fs.writeSync(fd, pinData.toString(16), null);
    } catch (ex) {
        _$jscmd("src/hw_oldkernel.js", "line", 68);
        resp.err = "Error writing to " + muxFile + ": " + ex;
        _$jscmd("src/hw_oldkernel.js", "line", 69);
        return resp;
    }
    if (_$jscmd("src/hw_oldkernel.js", "cond", "72_8_18", template == "bspm")) {
        _$jscmd("src/hw_oldkernel.js", "line", 73);
        gpioFile[pin.key] = "/sys/class/gpio/gpio" + pin.gpio + "/value";
        if (_$jscmd("src/hw_oldkernel.js", "cond", "74_12_7", pin.led)) {
            _$jscmd("src/hw_oldkernel.js", "line", 75);
            gpioFile[pin.key] = "/sys/class/leds/beaglebone::" + pin.led + "/brightness";
        }
    } else if (_$jscmd("src/hw_oldkernel.js", "cond", "77_15_19", template == "bspwm")) {
        _$jscmd("src/hw_oldkernel.js", "line", 78);
        resp.path = "/sys/class/pwm/" + pin.pwm.path;
        _$jscmd("src/hw_oldkernel.js", "line", 79);
        var path = resp.path;
        _$jscmd("src/hw_oldkernel.js", "line", 80);
        pwmPrefix[pin.pwm.name] = path;
        _$jscmd("src/hw_oldkernel.js", "line", 83);
        // Clear up any unmanaged usage
        fs.writeFileSync(path + "/request", "0");
        _$jscmd("src/hw_oldkernel.js", "line", 86);
        // Allocate and configure the PWM
        fs.writeFileSync(path + "/request", "1");
        _$jscmd("src/hw_oldkernel.js", "line", 87);
        fs.writeFileSync(path + "/period_freq", "0");
        _$jscmd("src/hw_oldkernel.js", "line", 88);
        fs.writeFileSync(path + "/polarity", "0");
        _$jscmd("src/hw_oldkernel.js", "line", 89);
        fs.writeFileSync(path + "/run", "1");
    }
    _$jscmd("src/hw_oldkernel.js", "line", 91);
    return resp;
};

_$jscmd("src/hw_oldkernel.js", "line", 94);

var setLEDPinToGPIO = function(pin, resp) {
    _$jscmd("src/hw_oldkernel.js", "line", 95);
    var path = "/sys/class/leds/beaglebone::" + pin.led + "/trigger";
    if (_$jscmd("src/hw_oldkernel.js", "cond", "97_8_24", my.file_existsSync(path))) {
        _$jscmd("src/hw_oldkernel.js", "line", 98);
        fs.writeFileSync(path, "gpio");
    } else {
        _$jscmd("src/hw_oldkernel.js", "line", 100);
        resp.err = "Unable to find LED: " + pin.led;
        _$jscmd("src/hw_oldkernel.js", "line", 101);
        winston.error(resp.err);
        _$jscmd("src/hw_oldkernel.js", "line", 102);
        resp.value = false;
    }
    _$jscmd("src/hw_oldkernel.js", "line", 105);
    return resp;
};

_$jscmd("src/hw_oldkernel.js", "line", 108);

var exportGPIOControls = hw_capemgr.exportGPIOControls;

_$jscmd("src/hw_oldkernel.js", "line", 110);

var writeGPIOValue = function(pin, value, callback) {
    if (_$jscmd("src/hw_oldkernel.js", "cond", "111_8_39", typeof gpioFile[pin.key] == "undefined")) {
        _$jscmd("src/hw_oldkernel.js", "line", 112);
        gpioFile[pin.key] = "/sys/class/gpio/gpio" + pin.gpio + "/value";
        if (_$jscmd("src/hw_oldkernel.js", "cond", "113_12_7", pin.led)) {
            _$jscmd("src/hw_oldkernel.js", "line", 114);
            gpioFile[pin.key] = "/sys/class/leds/beaglebone:";
            _$jscmd("src/hw_oldkernel.js", "line", 115);
            gpioFile[pin.key] += ":" + pin.led + "/brightness";
        }
        if (_$jscmd("src/hw_oldkernel.js", "cond", "117_12_38", !my.file_existsSync(gpioFile[pin.key]))) {
            _$jscmd("src/hw_oldkernel.js", "line", 118);
            winston.error("Unable to find gpio: " + gpioFile[pin.key]);
        }
    }
    if (_$jscmd("src/hw_oldkernel.js", "cond", "121_8_5", debug)) winston.debug("gpioFile = " + gpioFile[pin.key]);
    if (_$jscmd("src/hw_oldkernel.js", "cond", "122_8_8", callback)) {
        _$jscmd("src/hw_oldkernel.js", "line", 123);
        fs.writeFile(gpioFile[pin.key], "" + value, null, callback);
    } else {
        try {
            _$jscmd("src/hw_oldkernel.js", "line", 126);
            fs.writeFileSync(gpioFile[pin.key], "" + value, null);
        } catch (ex) {
            _$jscmd("src/hw_oldkernel.js", "line", 128);
            winston.error("Unable to write to " + gpioFile[pin.key]);
        }
    }
};

_$jscmd("src/hw_oldkernel.js", "line", 133);

var readGPIOValue = hw_capemgr.readGPIOValue;

_$jscmd("src/hw_oldkernel.js", "line", 135);

var enableAIN = function() {
    _$jscmd("src/hw_oldkernel.js", "line", 136);
    return true;
};

_$jscmd("src/hw_oldkernel.js", "line", 139);

var readAIN = function(pin, resp, callback) {
    _$jscmd("src/hw_oldkernel.js", "line", 140);
    var ainFile = "/sys/bus/platform/devices/tsc/ain" + (pin.ain + 1).toString();
    if (_$jscmd("src/hw_oldkernel.js", "cond", "141_8_8", callback)) {
        _$jscmd("src/hw_oldkernel.js", "line", 142);
        var readFile = function(err, data) {
            if (_$jscmd("src/hw_oldkernel.js", "cond", "143_16_3", err)) {
                _$jscmd("src/hw_oldkernel.js", "line", 144);
                resp.err = "analogRead error: " + err;
                _$jscmd("src/hw_oldkernel.js", "line", 145);
                winston.error(resp.err);
            }
            _$jscmd("src/hw_oldkernel.js", "line", 147);
            resp.value = parseInt(data, 10) / 4096;
            _$jscmd("src/hw_oldkernel.js", "line", 148);
            callback(resp);
        };
        _$jscmd("src/hw_oldkernel.js", "line", 150);
        fs.readFile(ainFile, readFile);
        _$jscmd("src/hw_oldkernel.js", "line", 151);
        return resp;
    }
    _$jscmd("src/hw_oldkernel.js", "line", 153);
    resp.value = parseInt(fs.readFileSync(ainFile), 10);
    if (_$jscmd("src/hw_oldkernel.js", "cond", "154_8_17", isNaN(resp.value))) {
        _$jscmd("src/hw_oldkernel.js", "line", 155);
        resp.err = "analogRead(" + pin.key + ") returned " + resp.value;
        _$jscmd("src/hw_oldkernel.js", "line", 156);
        winston.error(resp.err);
    }
    _$jscmd("src/hw_oldkernel.js", "line", 158);
    resp.value = resp.value / 4096;
    if (_$jscmd("src/hw_oldkernel.js", "cond", "159_8_17", isNaN(resp.value))) {
        _$jscmd("src/hw_oldkernel.js", "line", 160);
        resp.err = "analogRead(" + pin.key + ") scaled to " + resp.value;
    }
    _$jscmd("src/hw_oldkernel.js", "line", 162);
    return resp;
};

_$jscmd("src/hw_oldkernel.js", "line", 165);

var writeGPIOEdge = hw_capemgr.writeGPIOEdge;

_$jscmd("src/hw_oldkernel.js", "line", 167);

var writePWMFreqAndValue = function(pin, pwm, freq, value, resp) {
    _$jscmd("src/hw_oldkernel.js", "line", 168);
    var path = pwmPrefix[pin.pwm.name];
    if (_$jscmd("src/hw_oldkernel.js", "cond", "169_8_16", pwm.freq != freq)) {
        _$jscmd("src/hw_oldkernel.js", "line", 170);
        fs.writeFileSync(path + "/run", "0");
        _$jscmd("src/hw_oldkernel.js", "line", 171);
        fs.writeFileSync(path + "/duty_percent", "0");
        _$jscmd("src/hw_oldkernel.js", "line", 172);
        fs.writeFileSync(path + "/period_freq", Math.round(freq));
        _$jscmd("src/hw_oldkernel.js", "line", 173);
        fs.writeFileSync(path + "/run", "1");
    }
    _$jscmd("src/hw_oldkernel.js", "line", 175);
    fs.writeFileSync(path + "/duty_percent", Math.round(value * 100));
    _$jscmd("src/hw_oldkernel.js", "line", 176);
    return resp;
};

_$jscmd("src/hw_oldkernel.js", "line", 179);

var readEeproms = function(eeproms) {
    _$jscmd("src/hw_oldkernel.js", "line", 180);
    var EepromFiles = {
        "/sys/bus/i2c/drivers/at24/1-0050/eeprom": {
            type: "bone"
        },
        "/sys/bus/i2c/drivers/at24/3-0054/eeprom": {
            type: "cape"
        },
        "/sys/bus/i2c/drivers/at24/3-0055/eeprom": {
            type: "cape"
        },
        "/sys/bus/i2c/drivers/at24/3-0056/eeprom": {
            type: "cape"
        },
        "/sys/bus/i2c/drivers/at24/3-0057/eeprom": {
            type: "cape"
        }
    };
    _$jscmd("src/hw_oldkernel.js", "line", 197);
    eeproms = eeprom.readEeproms(EepromFiles);
    _$jscmd("src/hw_oldkernel.js", "line", 198);
    return eeproms;
};

_$jscmd("src/hw_oldkernel.js", "line", 201);

var readPlatform = function(platform) {
    _$jscmd("src/hw_oldkernel.js", "line", 202);
    return platform;
};

_$jscmd("src/hw_oldkernel.js", "line", 205);

module.exports = {
    logfile: logfile,
    readPWMFreqAndValue: readPWMFreqAndValue,
    readGPIODirection: readGPIODirection,
    readPinMux: readPinMux,
    setPinMode: setPinMode,
    setLEDPinToGPIO: setLEDPinToGPIO,
    exportGPIOControls: exportGPIOControls,
    writeGPIOValue: writeGPIOValue,
    readGPIOValue: readGPIOValue,
    enableAIN: enableAIN,
    readAIN: readAIN,
    writeGPIOEdge: writeGPIOEdge,
    writePWMFreqAndValue: writePWMFreqAndValue,
    readEeproms: readEeproms,
    readPlatform: readPlatform
};