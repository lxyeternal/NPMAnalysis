
// instrument by jscoverage, do not modifly this file
(function (file, lines, conds, source) {
  var BASE;
  if (typeof global === 'object') {
    BASE = global;
  } else if (typeof window === 'object') {
    BASE = window;
  } else {
    throw new Error('[jscoverage] unknow ENV!');
  }
  if (BASE._$jscoverage) {
    BASE._$jscmd(file, 'init', lines, conds, source);
    return;
  }
  var cov = {};
  /**
   * jsc(file, 'init', lines, condtions)
   * jsc(file, 'line', lineNum)
   * jsc(file, 'cond', lineNum, expr, start, offset)
   */
  function jscmd(file, type, line, express, start, offset) {
    var storage;
    switch (type) {
      case 'init':
        if(cov[file]){
          storage = cov[file];
        } else {
          storage = [];
          for (var i = 0; i < line.length; i ++) {
            storage[line[i]] = 0;
          }
          var condition = express;
          var source = start;
          storage.condition = condition;
          storage.source = source;
        }
        cov[file] = storage;
        break;
      case 'line':
        storage = cov[file];
        storage[line] ++;
        break;
      case 'cond':
        storage = cov[file];
        storage.condition[line] ++;
        return express;
    }
  }

  BASE._$jscoverage = cov;
  BASE._$jscmd = jscmd;
  jscmd(file, 'init', lines, conds, source);
})('src/functions.js', [53,58,63,68,75,80,85,90,95,100,105,110,115,123,130,135,140,145,146,154,162,54,59,64,69,70,71,76,81,86,91,96,101,106,111,116,126,131,136,141,148,159,156,157], {"124_8_5":0,"125_13_5":0,"155_8_10":0}, ["//","// Copyright (C) 2012 - Cabin Programs, Ken Keller","//","// Permission is hereby granted, free of charge, to any person obtaining a copy of","// this software and associated documentation files (the \"Software\"), to deal in","// the Software without restriction, including without limitation the rights to","// use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies","// of the Software, and to permit persons to whom the Software is furnished to do","// so, subject to the following conditions:","//","// The above copyright notice and this permission notice shall be included in all","// copies or substantial portions of the Software.","//","// THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR","// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,","// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE","// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER","// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,","// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE","// SOFTWARE.","//","// Bits and Bytes","//    lowByte(value)","//    highByte(value)","//    bitRead(value, bitnum)","//    bitWrite(value, bitnum, bitdata)","//    bitSet(value, bitnum)","//    bitClear(value, bitnum)","//    bit(bitnum)","//","// Trigonometry","//    sin(radians)","//    cos(radians)","//    tan(radians)","//","//  Math","//    min(x,y)","//    max(x,y)","//    abs(x)","//    constrain(x, a, b)","//    map(value, fromLow, fromHigh, toLow, toHigh)","//    pow(x, y)","//    sqrt(x)","//","//  Random Numbers","//    randomSeed(x)","//    random(min, max)","//    random(max)","//","","","// Returns the lower 8 bits of  value","var lowByte = function (value) {","    return (value & 0x0ff);","};","","// Returns the value shifted right by 8 bits","var highByte = function (value) {","    return (lowByte(value >> 8));","};","","// Returns the value of the bit number specified (return:0 or 1)","var bitRead = function (value, bitnum) {","    return ((value >> bitnum) & 0x01);","};","","// Returns value with bit changed to specified data","var bitWrite = function (value, bitnum, bitdata) {","    value = value & ~(0x01 << bitnum);","    bitdata = (bitdata & 0x01) << bitnum;","    return (value | bitdata);","};","","// Returns value with specified bit set","var bitSet = function (value, bitnum) {","    return (value | (0x01 << bitnum));","};","","// Returns value with specified bit clear","var bitClear = function (value, bitnum) {","    return (value & (~(0x01 << bitnum)));","};","","//Returns a value with one specified bit number set","var bit = function (bitnum) {","    return (0x01 << bitnum);","};","","// Returns the sine of an angle (in radians).","var sin = function (radians) {","    return (Math.sin(radians));","};","","// Returns the cos of an angle (in radians).","var cos = function (radians) {","    return (Math.cos(radians));","};","","// Returns the tan of an angle (in radians).","var tan = function (radians) {","    return (Math.tan(radians));","};","","// Returns the the minimum of x or y","var min = function (x, y) {","    return (Math.min(x, y));","};","","// Returns the the maximum of x or y","var max = function (x, y) {","    return (Math.max(x, y));","};","","// Returns the the absolute value of x","var abs = function (x) {","    return (Math.abs(x));","};","","// Returns a value constrained within the range of a to b","// Returns: x if x is between a and b","//          a if x is less than a","//          b if x is greater than b","var constrain = function (x, a, b) {","    if (x > b) x = b;","    else if (x < a) x = a;","    return (x);","};","","// Returns a value re-mapped from one range to another","var map = function (value, fromLow, fromHigh, toLow, toHigh) {","    return (toLow + (((value - fromLow) * (toHigh - toLow)) / (fromHigh - fromLow)));","};","","// Returns x raised to y power","var pow = function (x, y) {","    return (Math.pow(x, y));","};","","// Returns the aquare root of x","var sqrt = function (x) {","    return (Math.sqrt(x));","};","","// Returns nothing","var randomSeedValue;","var randomSeed = function (x) {","    // empty - javascript has no random seed function","    randomSeedValue = x;","};","","// Returns a pseudo-random number","// Valid calls: random(max)","//              random(min, max)","var random = function (min, max) {","    if (isNaN(max)) {","        max = min;","        min = 0;","    }","    return ((Math.random() * (max - min)) + min);","};","","module.exports = {","    lowByte: lowByte,","    highByte: highByte,","    bitRead: bitRead,","    bitWrite: bitWrite,","    bitSet: bitSet,","    bitClear: bitClear,","    bit: bit,","    sin: sin,","    cos: cos,","    tan: tan,","    min: min,","    max: max,","    abs: abs,","    constrain: constrain,","    map: map,","    pow: pow,","    sqrt: sqrt,","    randomSeed: randomSeed,","    random: random","}"]);
//
// Copyright (C) 2012 - Cabin Programs, Ken Keller
//
// Permission is hereby granted, free of charge, to any person obtaining a copy of
// this software and associated documentation files (the "Software"), to deal in
// the Software without restriction, including without limitation the rights to
// use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
// of the Software, and to permit persons to whom the Software is furnished to do
// so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
//
// Bits and Bytes
//    lowByte(value)
//    highByte(value)
//    bitRead(value, bitnum)
//    bitWrite(value, bitnum, bitdata)
//    bitSet(value, bitnum)
//    bitClear(value, bitnum)
//    bit(bitnum)
//
// Trigonometry
//    sin(radians)
//    cos(radians)
//    tan(radians)
//
//  Math
//    min(x,y)
//    max(x,y)
//    abs(x)
//    constrain(x, a, b)
//    map(value, fromLow, fromHigh, toLow, toHigh)
//    pow(x, y)
//    sqrt(x)
//
//  Random Numbers
//    randomSeed(x)
//    random(min, max)
//    random(max)
//
// Returns the lower 8 bits of  value
_$jscmd("src/functions.js", "line", 53);

var lowByte = function(value) {
    _$jscmd("src/functions.js", "line", 54);
    return value & 255;
};

_$jscmd("src/functions.js", "line", 58);

// Returns the value shifted right by 8 bits
var highByte = function(value) {
    _$jscmd("src/functions.js", "line", 59);
    return lowByte(value >> 8);
};

_$jscmd("src/functions.js", "line", 63);

// Returns the value of the bit number specified (return:0 or 1)
var bitRead = function(value, bitnum) {
    _$jscmd("src/functions.js", "line", 64);
    return value >> bitnum & 1;
};

_$jscmd("src/functions.js", "line", 68);

// Returns value with bit changed to specified data
var bitWrite = function(value, bitnum, bitdata) {
    _$jscmd("src/functions.js", "line", 69);
    value = value & ~(1 << bitnum);
    _$jscmd("src/functions.js", "line", 70);
    bitdata = (bitdata & 1) << bitnum;
    _$jscmd("src/functions.js", "line", 71);
    return value | bitdata;
};

_$jscmd("src/functions.js", "line", 75);

// Returns value with specified bit set
var bitSet = function(value, bitnum) {
    _$jscmd("src/functions.js", "line", 76);
    return value | 1 << bitnum;
};

_$jscmd("src/functions.js", "line", 80);

// Returns value with specified bit clear
var bitClear = function(value, bitnum) {
    _$jscmd("src/functions.js", "line", 81);
    return value & ~(1 << bitnum);
};

_$jscmd("src/functions.js", "line", 85);

//Returns a value with one specified bit number set
var bit = function(bitnum) {
    _$jscmd("src/functions.js", "line", 86);
    return 1 << bitnum;
};

_$jscmd("src/functions.js", "line", 90);

// Returns the sine of an angle (in radians).
var sin = function(radians) {
    _$jscmd("src/functions.js", "line", 91);
    return Math.sin(radians);
};

_$jscmd("src/functions.js", "line", 95);

// Returns the cos of an angle (in radians).
var cos = function(radians) {
    _$jscmd("src/functions.js", "line", 96);
    return Math.cos(radians);
};

_$jscmd("src/functions.js", "line", 100);

// Returns the tan of an angle (in radians).
var tan = function(radians) {
    _$jscmd("src/functions.js", "line", 101);
    return Math.tan(radians);
};

_$jscmd("src/functions.js", "line", 105);

// Returns the the minimum of x or y
var min = function(x, y) {
    _$jscmd("src/functions.js", "line", 106);
    return Math.min(x, y);
};

_$jscmd("src/functions.js", "line", 110);

// Returns the the maximum of x or y
var max = function(x, y) {
    _$jscmd("src/functions.js", "line", 111);
    return Math.max(x, y);
};

_$jscmd("src/functions.js", "line", 115);

// Returns the the absolute value of x
var abs = function(x) {
    _$jscmd("src/functions.js", "line", 116);
    return Math.abs(x);
};

_$jscmd("src/functions.js", "line", 123);

// Returns a value constrained within the range of a to b
// Returns: x if x is between a and b
//          a if x is less than a
//          b if x is greater than b
var constrain = function(x, a, b) {
    if (_$jscmd("src/functions.js", "cond", "124_8_5", x > b)) x = b; else if (_$jscmd("src/functions.js", "cond", "125_13_5", x < a)) x = a;
    _$jscmd("src/functions.js", "line", 126);
    return x;
};

_$jscmd("src/functions.js", "line", 130);

// Returns a value re-mapped from one range to another
var map = function(value, fromLow, fromHigh, toLow, toHigh) {
    _$jscmd("src/functions.js", "line", 131);
    return toLow + (value - fromLow) * (toHigh - toLow) / (fromHigh - fromLow);
};

_$jscmd("src/functions.js", "line", 135);

// Returns x raised to y power
var pow = function(x, y) {
    _$jscmd("src/functions.js", "line", 136);
    return Math.pow(x, y);
};

_$jscmd("src/functions.js", "line", 140);

// Returns the aquare root of x
var sqrt = function(x) {
    _$jscmd("src/functions.js", "line", 141);
    return Math.sqrt(x);
};

_$jscmd("src/functions.js", "line", 145);

// Returns nothing
var randomSeedValue;

_$jscmd("src/functions.js", "line", 146);

var randomSeed = function(x) {
    _$jscmd("src/functions.js", "line", 148);
    // empty - javascript has no random seed function
    randomSeedValue = x;
};

_$jscmd("src/functions.js", "line", 154);

// Returns a pseudo-random number
// Valid calls: random(max)
//              random(min, max)
var random = function(min, max) {
    if (_$jscmd("src/functions.js", "cond", "155_8_10", isNaN(max))) {
        _$jscmd("src/functions.js", "line", 156);
        max = min;
        _$jscmd("src/functions.js", "line", 157);
        min = 0;
    }
    _$jscmd("src/functions.js", "line", 159);
    return Math.random() * (max - min) + min;
};

_$jscmd("src/functions.js", "line", 162);

module.exports = {
    lowByte: lowByte,
    highByte: highByte,
    bitRead: bitRead,
    bitWrite: bitWrite,
    bitSet: bitSet,
    bitClear: bitClear,
    bit: bit,
    sin: sin,
    cos: cos,
    tan: tan,
    min: min,
    max: max,
    abs: abs,
    constrain: constrain,
    map: map,
    pow: pow,
    sqrt: sqrt,
    randomSeed: randomSeed,
    random: random
};