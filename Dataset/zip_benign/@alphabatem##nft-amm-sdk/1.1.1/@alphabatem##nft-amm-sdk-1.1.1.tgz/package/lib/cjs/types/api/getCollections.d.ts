import { CollectionResponse } from "../entities";
export declare function getCollections(): Promise<CollectionResponse>;
//# sourceMappingURL=getCollections.d.ts.map