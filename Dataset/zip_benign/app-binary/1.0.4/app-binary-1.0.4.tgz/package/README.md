#  App - Binary
simple code for trading on binary.com | binary.me | deriv.com

## Installation
```bash
npm install app-binary
```
``` javascript
var App = require('app-binary');
var app = new App('YOUR-API-TOKEN');
```
[Create YOUR-API-TOKEN](https://www.binary.com/en/user/security/api_tokenws.html "")

## Simple function
* new App()
* _instance_
   * .spot()
   * .buy()
   * .portfolio()

- spot()
    - Input source: 'R_10' | 'R_100' | 'R_25' | 'R_75' | 'R_50' | 'RDBULL' | 'RDBEAR'
```javascript
   app.spot('R_10')
```

```bash
   { spot: { data: 2693.386, time: '18:42:52', color: 'R', worm: 'R' } }
```

- buy()
    - Parameters:
       - stake       :  amount 
       - currency    :  currency 
       - contract    : 'RISE' | 'FALL'
       - duration    : duration
       - duration_set:  't' | 's' | 'm' 

``` javascript
   app.buy({
      stake   : 0.50,
      currency: 'USD',
      contract: 'RISE',
      duration: '5',
      duration_set: 't'
   })
```
```bash
  { buy: 'success' }
```
- portfolio()
```javascript
   app.portfolio();
```
``` javascript
{
  portfolio: {
    ref: 183215154588,
    potiontial_payout: 0.94,
    contract_details: 'Win payout if Volatility 25 Index after 5 ticks is strictly higher than entry spot.',
    purchase: 0.5,
    indicative: 0.94,
    result: 'won'
  }
}
```
# Simple Code
``` javascript
var App = require('app-binary');
var app = new App('YOUR-API-TOKEN');
var action_buy = false;
var stake = 0.50;
function Play(){
    app.Binary((e)=>{
        console.log(e)
        if(e.profile) app.spot('R_25')
        if(e.spot){
            if(e.spot.worm == 'B' && action_buy == false){
                action_buy = true
                app.buy({
                    stake   : stake,
                    currency: 'USD',
                    contract: 'RISE',
                    duration: '5',
                    duration_set: 't'
                })
            }
        }
        if(e.buy == 'success'){
            app.portfolio()
        }
        if(e.portfolio){
        if(e.portfolio.result == 'won'){
            //if won statement
            stake = 0.5
            action_buy = false
        }
        if(e.portfolio.result == 'lost'){
            //if lost statement
            stake *= 2.1
            action_buy = false
        }
        }
        if(e.reconnect){
            setTimeout(Play, 2000)
        }
    });
}
Play()
```
# Donate
1. LTC : `MQKX75b7jLLYxYFbMKBeJzCG1jkrELMdgW`
1. ETH : `0x8192094D0B489c1ec9eeC8c94c6e9714cF804f95`
1. BCH : `1Eo7Jqs4QPDenwrJhXQf3KAHsJPaRKX1n5`
1. BTC : `3LeipTSieBfM91LqfwYrcEQZJ84QB2cmJc`
1. DASH: `Xu7xVsfwGSJ2oHgeiWo66LaHcgKzaCqatv`
1. XRP : `rw2ciyaNshpHe7bCHo4bRWq6pqqynnWKQg:::ucl:::195522318`