
var App = require('app-binary')

var app = new App('YOUR-API-TOKENS')
var action_buy = false
var stake = 0.50
var Play = () =>{
    app.Binary( ( e ) =>{
        console.log(e)
        if(e.profile) app.spot('R_25')
        if(e.spot){
            if(e.spot.worm == 'B' && action_buy == false){
                action_buy = true
                app.buy({
                    stake   : stake,
                    currency: 'USD',
                    contract: 'RISE',
                    duration: '5',
                    duration_set: 't'
                })
            }
        }
        if(e.buy == 'success'){
            app.portfolio()
        }
        if(e.portfolio){
        if(e.portfolio.result == 'won'){
            //statement
            stake = 0.5
            action_buy = false
        }
        if(e.portfolio.result == 'lost'){
            //statement
            stake *= 2.1
            action_buy = false
        }
        }
        if(e.reconnect){
            setTimeout(Play, 2000)
        }
    });
}
Play()
