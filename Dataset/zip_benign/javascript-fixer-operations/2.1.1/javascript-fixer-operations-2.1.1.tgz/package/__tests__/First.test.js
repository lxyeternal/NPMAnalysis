"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var index_1 = __importDefault(require("../index"));
var operation = new index_1.default();
test('Addition', function () {
    expect(operation.addition(0.3, 0.1)).toBe(0.4);
});
test('Subtraction', function () {
    expect(operation.subtraction(0.3, 0.1)).toBe(0.2);
});
test('Multiplication', function () {
    expect(operation.multiplication(0.07, 100)).toBe(7);
});
test('Division', function () {
    expect(operation.division(5.3, 0.1)).toBe(53);
});
