export { deployHighRiskStrategy } from './core/deploy';
export { HighRiskStrategy } from './core/highRiskStrategies';
export { LowRiskStrategy } from './core/lowRiskStrategies';
