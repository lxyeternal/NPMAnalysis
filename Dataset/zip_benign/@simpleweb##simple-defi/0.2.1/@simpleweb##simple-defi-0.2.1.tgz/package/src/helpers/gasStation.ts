import { BigNumber, providers } from 'ethers';

type Configuration = {
  network: Network;
  provider:
    | providers.JsonRpcProvider
    | providers.BaseProvider
    | providers.Web3Provider;
};

enum Network {
  polygon = 'polygon',

  mumbai = 'mumbai',
}

type transactionType = {
  value?: string;
  from?: string;
  to?: string;
  nonce?: number;
  gasLimit?: BigNumber;
  gasPrice?: BigNumber;
  data?: string;
  chainId?: number;
};

const DEFAULT_SURPLUS = 30; // 30%
// polygon gas estimation is very off for some reason
const POLYGON_SURPLUS = 60; // 60%

export const estimateGas = async (
  tx: transactionType,
  config: Configuration,
  gasSurplus?: number
): Promise<BigNumber> => {
  const estimatedGas = await config.provider.estimateGas(tx);
  return estimatedGas.add(
    estimatedGas.mul(gasSurplus || DEFAULT_SURPLUS).div(100)
  );
};

export const estimateGasByNetwork = async (
  tx: transactionType,
  config: Configuration,
  gasSurplus?: number
): Promise<BigNumber> => {
  const estimatedGas = await config.provider.estimateGas(tx);

  const { network } = config;
  if (network === Network.polygon) {
    return estimatedGas.add(estimatedGas.mul(POLYGON_SURPLUS).div(100));
  }

  return estimatedGas.add(
    estimatedGas.mul(gasSurplus || DEFAULT_SURPLUS).div(100)
  );
};

export const getGasPrice = async (
  config: Configuration
): Promise<BigNumber> => {
  const gasPrice = await config.provider.getGasPrice();
  return gasPrice;
};
