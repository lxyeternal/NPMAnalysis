import { JsonRpcProvider } from '@ethersproject/providers';
import axios from 'axios';
import { Contract, ethers, Signer } from 'ethers';
import {
  ERC20_ABI,
  RPC_URL,
  SIMPLE_DEFI_ABI,
  SIMPLE_DEFI_API_BASE_URL,
  WMATIC_POLYGON,
  WMATIC_USDC_QUICKSWAP_POLYGON,
} from '../constants';

/**
 * Class used to interact with and retrive data from a simple-defi high risk strategy pot.
 */
export class HighRiskStrategy {
  pot: string;
  WMATIC: Contract;
  USDC: Contract;
  LPToken: any;
  signer?: Signer;
  provider: JsonRpcProvider;
  SimpleDefi: Contract;

  /**
   * Creates an instance of the high risk strategy class
   *
   * @remarks
   * If a signer is not provided only read access is possible.
   *
   * @param _pot - The contract address of a deployed simple-defi contract to contribute funds to.
   * @param _WMATIC - The contract address of the Wrapped Matic token.
   * @param _USDC - The contract address of the USD Coin token.
   * @param _signer - Ethers signer used to submit transactions to the chain. This is not required when only reading data from the chain.
   *
   */
  constructor(_pot: string, _WMATIC: string, _USDC: string, _signer?: Signer) {
    this.pot = _pot;
    this.provider = new ethers.providers.JsonRpcProvider(RPC_URL);

    this.signer = _signer;

    this.WMATIC = new ethers.Contract(_WMATIC, ERC20_ABI.abi, this.signer);

    this.USDC = new ethers.Contract(_USDC, ERC20_ABI.abi, this.signer);

    this.SimpleDefi = new ethers.Contract(
      _pot,
      SIMPLE_DEFI_ABI.abi,
      this.signer
    );

    this.LPToken = new ethers.Contract(
      WMATIC_USDC_QUICKSWAP_POLYGON,
      ERC20_ABI.abi,
      this.provider
    );
  }

  /**
   * Deploys the simple-defi contract to the chain and sets the simple-defi contract instance to the new deployment.
   *
   * @returns the receipt of the deployment transaction.
   */
  async deploy() {
    if (!this.signer) return 'signer required';

    const contract = new ethers.ContractFactory(
      SIMPLE_DEFI_ABI.abi,
      SIMPLE_DEFI_ABI.bytecode,
      this.signer
    );

    const tx = await contract.deploy(WMATIC_POLYGON);
    const receipt = await tx.deployTransaction.wait();

    this.pot = receipt.contractAddress;
    this.SimpleDefi = new ethers.Contract(
      this.pot,
      SIMPLE_DEFI_ABI.abi,
      this.signer
    );

    return receipt;
  }

  /**
   * Deposit some funds into a simple-defi pot.
   *
   * @remarks
   * This function requires a signer
   *
   * @param amount - The number amount of funds to be deposited in ether representation. eg 5 = 5 MATIC
   *
   * @returns the receipt of the deposit transaction.
   *
   */
  async deposit(amount: number) {
    if (!this.signer) return 'signer required';
    //zap in
    const zap = await this.SimpleDefi.zapIn(this.USDC.address, {
      value: ethers.utils.parseEther(amount.toString()),
    });
    const receipt = zap.wait();
    return receipt;
  }

  /**
   * Withdraw some funds from a simple-defi pot.
   *
   * @remarks
   * This function requires a signer. To withdraw the entire balance passed through 0 as the amount.
   *
   * @param amount - The amount of funds to be withdrawn in LP tokens. You can get the amount of LP tokens a user owns from the getAccountBalanceLP function.
   *
   * @returns the receipt of the withdraw transaction.
   *
   */
  async withdraw(amount: number, recipient: string) {
    if (!this.signer) return 'signer required';

    //zap out
    const zap = await this.SimpleDefi.zapOut(
      this.USDC.address,
      amount.toString(),
      recipient
    );
    const receipt = zap.wait();
    return receipt;
  }

  /**
   * Set the liquidity pool to interact with
   *
   * @param token - The other token in the pair besides Wrapped Matic, eg. USD Coin.
   *
   */
  async setPairPool(token: string) {
    this.LPToken = new ethers.Contract(
      await this.SimpleDefi.getPair(token),
      ERC20_ABI.abi,
      this.provider
    );
  }

  /**
   * Get the liquidity pool token balance of an account from the simple-defi pot.
   *
   * @param account - The account to get the balance of.
   *
   * @returns the receipt of the withdraw transaction.
   *
   */
  async getAccountBalanceLP(account: string) {
    const accountBalanceLP = await this.SimpleDefi.getBalance(
      account,
      this.LPToken.address
    );
    return accountBalanceLP;
  }

  /**
   * Get data about a simple-defi pot.
   *
   * @param account - The account to get information about. Optional, if no account is provided only information about the whole pot is returned.
   *
   * @returns An object containing; annualised fees, pair symbol, total pot balance in USD and LP tokens, totals fees accumulated in USD and a user total balance in USD.
   *
   */
  async getPoolData(account?: string) {
    let url;
    if (account) {
      url = `/api/v1/high?pot=${
        this.pot
      }&pair=${this.LPToken.address.toLowerCase()}&address=${account}`;
    } else {
      url = `/api/v1/high?pot=${
        this.pot
      }&pair=${this.LPToken.address.toLowerCase()}`;
    }
    const { data }: any = await axios({
      method: 'get',
      url: SIMPLE_DEFI_API_BASE_URL + url,
    })
      .then((res: object) => res)
      .catch((e: Error) => console.log(e));

    return data;
  }
}
