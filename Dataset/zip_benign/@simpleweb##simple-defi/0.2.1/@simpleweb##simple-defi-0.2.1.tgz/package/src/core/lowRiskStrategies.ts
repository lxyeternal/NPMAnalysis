import { JsonRpcProvider } from '@ethersproject/providers';
import axios from 'axios';
import { Contract, ethers, Signer } from 'ethers';
import {
  AMWMATIC_POLYGON,
  ERC20_ABI,
  RPC_URL,
  SIMPLE_DEFI_API_BASE_URL,
  WETH_GATEWAY_AAVE_ABI,
  WETH_GATEWAY_AAVE_POLYGON,
} from '../constants';

/**
 * Class used to interact with and retrive data from a simple-defi low risk strategy pot.
 */
export class LowRiskStrategy {
  pool: string;
  LPToken: Contract;
  signer?: Signer;
  provider: JsonRpcProvider;
  gateway: Contract;
  config: any;

  /**
   * Creates an instance of the low risk strategy class
   *
   * @remarks
   * If a signer is not provided only read access is possible.
   *
   * @param _pool - The liqudity pool to add funds to.
   * @param _signer - Ethers signer used to submit transactions to the chain. This is not required when only reading data from the chain.
   *
   */
  constructor(_pool: string, _signer?: Signer) {
    this.provider = new ethers.providers.JsonRpcProvider(RPC_URL);

    if (_signer) this.signer = _signer;

    this.pool = _pool;

    this.gateway = new ethers.Contract(
      WETH_GATEWAY_AAVE_POLYGON,
      WETH_GATEWAY_AAVE_ABI.abi,
      this.signer
    );

    this.LPToken = new ethers.Contract(
      AMWMATIC_POLYGON,
      ERC20_ABI.abi,
      this.signer
    );
  }

  private async handleReceipt(contract: any) {
    const receipt = await contract.wait();
    if (receipt.status == Status.SUCCESS) {
      return receipt;
    } else {
      return receipt;
    }
  }

  /**
   * Deposit some funds into a simple-defi pot.
   *
   * @remarks
   * This function requires a signer
   *
   * @param amount - The number amount of funds to be deposited in ether representation. eg 5 = 5 MATIC
   *
   * @returns the receipt of the deposit transaction.
   *
   */
  async deposit(amount: number, recipient: string) {
    if (!this.validAddress(recipient)) return 'invalid address';
    try {
      const deposit = await this.gateway.depositETH(this.pool, recipient, 0, {
        value: this.parseEther(amount),
      });

      return await this.handleReceipt(deposit);
    } catch (e) {
      return e;
    }
  }

  /**
   * Withdraw some funds from a simple-defi pot.
   *
   * @remarks
   * This function requires a signer, Also, currently only 0 is accepted as the amount, this will withdraw all of an accounts funds.
   *
   * @param amount - The number amount of funds to be withdrawn in ether representation. eg 5 = 5 MATIC
   *
   * @returns the receipt of the withdraw transaction.
   *
   */
  async withdraw(amount: number, account: string) {
    if (!this.validAddress(account)) return 'invalid addresses';

    if (amount == 0) {
      amount = await this.LPToken.balanceOf(account);
    }
    if (!(await this.isApproved(account, amount))) {
      await this.approve(amount, account);
    }
    if ((await this.getBalanceLPToken(account)) >= amount) {
      try {
        const withdraw = await this.gateway.withdrawETH(
          this.pool,
          this.parseEther(amount),
          account
        );
        return await this.handleReceipt(withdraw);
      } catch (e) {
        return e;
      }
    } else {
      return 'no liquidity provided';
    }
  }

  /**
   * Approves an amount of funds to be withdrawn.
   *
   * @remarks
   * This function requires a signer. Passing 0 approves the balance of the account passed.
   *
   * @param amount - The number amount of funds to be approved in ether representation. eg 5 = 5 MATIC
   *
   * @returns the receipt of the approval transaction.
   *
   */
  async approve(amount: number, account: string) {
    if (!this.validAddress(account)) return 'invalid addresses';
    if (amount == 0) {
      amount = await this.LPToken.balanceOf(account);
    }
    try {
      const approve = await this.LPToken.approve(
        WETH_GATEWAY_AAVE_POLYGON,
        this.parseEther(amount)
      );
      return await this.handleReceipt(approve);
    } catch (e) {
      return e;
    }
  }

  /**
   * Checks if an account has approved a certain amount of funds
   *
   * @param amount - The ether amount of funds to check.
   *
   * @returns false if not approved, true if approved.
   *
   */
  async isApproved(account: string, amount: number) {
    if (!this.validAddress(account)) return 'invalid addresses';
    try {
      const allowance = await this.LPToken.allowance(
        account,
        WETH_GATEWAY_AAVE_POLYGON
      );
      const balance = await this.LPToken.balanceOf(account);
      if (allowance >= amount && amount <= balance) return true;
      else {
        return false;
      }
    } catch (e) {
      console.log(e);
      return false;
    }
  }

  /**
   * Get the liquidity pool token balance of an account from the simple-defi pot.
   *
   * @param account - The account to get the balance of.
   *
   * @returns the receipt of the withdraw transaction.
   *
   */
  async getBalanceLPToken(account: string) {
    if (!this.validAddress(account)) return 'invalid addresses';
    const balance = await this.LPToken.balanceOf(account);

    return balance.toString();
  }

  /**
   * Get data about a simple-defi pot.
   *
   * @param account - The account to get information about. Optional, if no account is provided only information about the whole pot is returned.
   *
   * @returns An object containing; annualised fees, pair symbol, total pot balance in USD and LP tokens, totals fees accumulated in USD and a user total balance in USD.
   *
   */
  async getPoolData(account: any) {
    let url;
    if (account) {
      url = `/api/v1/low?pair=${this.LPToken.address.toLowerCase()}&address=${account}`;
    } else {
      url = `/api/v1/low?pair=${this.LPToken.address.toLowerCase()}`;
    }
    const { data }: any = await axios({
      method: 'get',
      url: SIMPLE_DEFI_API_BASE_URL + url,
    })
      .then((res: object) => res)
      .catch((e: Error) => console.log(e));

    return data;
  }

  private validAddress(address: string) {
    return ethers.utils.isAddress(address);
  }
  private parseEther(amount: number) {
    return ethers.utils.parseEther(amount.toString());
  }
}
