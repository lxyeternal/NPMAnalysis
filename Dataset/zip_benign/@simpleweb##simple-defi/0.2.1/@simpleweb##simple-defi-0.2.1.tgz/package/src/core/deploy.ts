import { TransactionReceipt } from '@ethersproject/abstract-provider';
import { Contract, ContractFactory, ethers, Signer } from 'ethers';
import { SIMPLE_DEFI_ABI, WMATIC_POLYGON } from '../constants';

/**
 * Deploy an instance of the simple-defi HighRiskStrategy contract.
 *
 * This contract acts as a pot of tokens.
 *
 * @param {Signer} signer - signer of the contract
 *
 * @returns the address of the deployed contract.
 *
 */
export async function deployHighRiskStrategy(signer: Signer) {
  if (!signer) return 'signer required';

  const contract: ContractFactory = new ethers.ContractFactory(
    SIMPLE_DEFI_ABI.abi,
    SIMPLE_DEFI_ABI.bytecode,
    signer
  );

  const tx: Contract = await contract.deploy(WMATIC_POLYGON);
  const receipt: TransactionReceipt = await tx.deployTransaction.wait();

  return receipt.contractAddress;
}
