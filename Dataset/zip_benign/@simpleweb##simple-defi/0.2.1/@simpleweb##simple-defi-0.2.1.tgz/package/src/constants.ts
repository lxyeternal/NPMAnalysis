import ERC20_ABI from './abis/ERC20.json';
import SIMPLE_DEFI_ABI from './abis/SimpleDeFi.json';
import WETH_GATEWAY_AAVE_ABI from './abis/WETHGateway.json';

const isDevMode = process.env.NODE_ENV === 'development';

/**
 * SERVICES/KEYS
 */

const RPC_URL = isDevMode ? 'http://127.0.0.1:8545/' : 'http://polygon-rpc.com';
const SIMPLE_DEFI_API_BASE_URL = isDevMode
  ? 'http://localhost:8080'
  : 'https://simple-defi-api.herokuapp.com';

/**
 * Deployed Tokens/Contract - Polygon Mainnet
 */
const USDC_POLYGON = '0x2791bca1f2de4661ed88a30c99a7a9449aa84174';
const WMATIC_POLYGON = '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270';
const AMWMATIC_POLYGON = '0x8dF3aad3a84da6b69A4DA8aeC3eA40d9091B2Ac4';
const WMATIC_USDC_QUICKSWAP_POLYGON =
  '0x6e7a5FAFcec6BB1e78bAE2A1F0B612012BF14827';
const WETH_GATEWAY_AAVE_POLYGON = '0xbEadf48d62aCC944a06EEaE0A9054A90E5A7dc97';
const AAVE_LENDING_POOL = '0x8dFf5E27EA6b7AC08EbFdf9eB090F32ee9a30fcf';

/**
 * Deployed Tokens/Contract - Polygon Mumbai
 */
//SIMPLE_DEFI_TESTNET: 0x2BDFB1ff5de0c59279af7952685139426f103C0c

export {
  WETH_GATEWAY_AAVE_ABI,
  SIMPLE_DEFI_ABI,
  AMWMATIC_POLYGON,
  RPC_URL,
  WETH_GATEWAY_AAVE_POLYGON,
  ERC20_ABI,
  SIMPLE_DEFI_API_BASE_URL,
  WMATIC_USDC_QUICKSWAP_POLYGON,
  USDC_POLYGON,
  WMATIC_POLYGON,
  AAVE_LENDING_POOL,
};
