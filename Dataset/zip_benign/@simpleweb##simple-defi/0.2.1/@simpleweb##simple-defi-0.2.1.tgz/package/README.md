# Simple DeFi SDK

The Simple DeFi SDK provides a quick and easy way to interact with DeFi platforms.

## Installation

You can install the SDK with NPM or Yarn.

```shell
npm install @simpleweb/simple-defi
```

```shell
yarn add @simpleweb/simple-defi
```

## Getting started

```
import { HighRiskStrategy, LowRiskStrategy, deployHighRiskStrategy } from "@simpleweb/simple-defi";
```

### Creating a high risk strategy

The `deployHighRiskStrategy()` function is used to create an instance of the Simple DeFi contract on-chain.

A signer must be passed to the function.

### Creating a signer

Create an ethers `Signer` instance with an ethers `Web3Provider` which you'd typically get from a connected wallet.

```
const provider = new ethers.providers.Web3Provider(wallet?.provider);
signer = provider.getSigner();
```

A private key can also be used to create the signer.

```const signer = new ethers.Wallet(
  '0x...', //private key here.
  new ethers.providers.JsonRpcProvider(
    'https://polygon-rpc.com'
  )
);
```

### Calling the deploy function

```
const address = await deployHighRiskStrategy(signer);
```

The `deployHighRiskStrategy()` function returns the contract address of the deployed strategy. This should be passed as the strategy argument when instanciating a HighRiskStrategy.

## Creating an instance

If the deposit and withdraw functions are required, a `Signer` must be passed when instantiating the strategy object.

```
strategy = new HighRiskStrategy(
"0x1995e722310541B9ef62c2a0B2eF8f90d2dD43ED", //pot
"0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270", //WMATIC
"0x2791bca1f2de4661ed88a30c99a7a9449aa84174", //USDC
signer //signer
);
```

## Interacting with the strategy

### Deposit

Deposit funds by passing the amount of tokens in ether representation. Eg 0.5. The function will handle the conversion to Wei.

```
await strategy.deposit(0.5);
```

### Withdraw

Withdraw funds from the strategy by passing the amount
of LP tokens and the recipient of the withdraw funds.

Passing 0 to the function will withdraw all of an accounts funds.

```
await strategy.withdraw(0, account);
```

#### Getting a users LP token balance

```
const balance = await strategy.getAccountBalanceLP(account);
```

### Getting information about a strategy.

Information can be retrieved about a specific strategy without a wallet being connected.

```strategy = new HighRiskStrategy(
"0x1995e722310541B9ef62c2a0B2eF8f90d2dD43ED", //pot
"0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270", //WMATIC
"0x2791bca1f2de4661ed88a30c99a7a9449aa84174" //USDC
);
```

The `getPoolData()` function will return information about a specific pair in the deployed strategy.

```
const data = await strategy.getPoolData(account);
```

**Response**

```
{
    "apr": 0.7494295629569386,
    "pair": "QLP WMATIC / USDC",
    "totalBalanceUSD": 482.4149351818978,
    "totalBalanceLP": "169634743851095",
    "totalFeesCumulativeUSD": 4.735991426659753,
    "userBalanceUSD": 482.41086462871743
}
```
