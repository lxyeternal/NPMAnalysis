/* tslint:disable */
/* eslint-disable */
/**
* @param {string} raw
* @param {boolean} use_tabs
* @param {number} indent_size
* @returns {string}
*/
export function format_rsx(raw: string, use_tabs: boolean, indent_size: number): string;
/**
* @param {string} raw
* @param {boolean} use_tabs
* @param {number} indent_size
* @param {number} base_indent
* @returns {string}
*/
export function format_selection(raw: string, use_tabs: boolean, indent_size: number, base_indent: number): string;
/**
* @param {string} contents
* @param {boolean} use_tabs
* @param {number} indent_size
* @returns {FormatBlockInstance}
*/
export function format_file(contents: string, use_tabs: boolean, indent_size: number): FormatBlockInstance;
/**
* @param {string} contents
* @param {boolean} _component
* @returns {string}
*/
export function translate_rsx(contents: string, _component: boolean): string;
/**
*/
export class FormatBlockInstance {
  free(): void;
/**
* @returns {string}
*/
  formatted(): string;
/**
* @returns {number}
*/
  length(): number;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly format_rsx: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly format_selection: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
  readonly __wbg_formatblockinstance_free: (a: number) => void;
  readonly formatblockinstance_formatted: (a: number, b: number) => void;
  readonly formatblockinstance_length: (a: number) => number;
  readonly format_file: (a: number, b: number, c: number, d: number) => number;
  readonly translate_rsx: (a: number, b: number, c: number, d: number) => void;
  readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {SyncInitInput} module
*
* @returns {InitOutput}
*/
export function initSync(module: SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {InitInput | Promise<InitInput>} module_or_path
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path: InitInput | Promise<InitInput>): Promise<InitOutput>;
