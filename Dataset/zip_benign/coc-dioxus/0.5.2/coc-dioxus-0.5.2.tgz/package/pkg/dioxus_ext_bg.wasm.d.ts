/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function format_rsx(a: number, b: number, c: number, d: number, e: number): void;
export function format_selection(a: number, b: number, c: number, d: number, e: number, f: number): void;
export function __wbg_formatblockinstance_free(a: number): void;
export function formatblockinstance_formatted(a: number, b: number): void;
export function formatblockinstance_length(a: number): number;
export function format_file(a: number, b: number, c: number, d: number): number;
export function translate_rsx(a: number, b: number, c: number, d: number): void;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_malloc(a: number, b: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number, d: number): number;
export function __wbindgen_free(a: number, b: number, c: number): void;
