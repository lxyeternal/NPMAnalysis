import EventEmitter from "eventemitter3";
import { ButtonTypeData } from ".";
/**
 * A ButtonType represents a single option in the list of generic buttons in
 * the Buttons tab of the UI. You can listen for incoming "pressed" events
 * from the board as well as change the button's indicator.
 *
 * ```
 * const foo = new ButtonType("start-streaming", {
 *   name: "Start Streaming",
 * });
 *
 * foo.active = true;
 *
 * foo.on("pressed", () => {
 *   // ...
 * });
 * ```
 */
export declare class ButtonType extends EventEmitter {
    readonly id: string;
    private _name;
    private _active;
    /**
     * @param data Data to used for MIDI Mixer to set up the button type.
     */
    constructor(id: string, data: ButtonTypeData);
    remove(): void;
    get name(): string;
    set name(name: string);
    get active(): boolean;
    set active(active: boolean);
}
//# sourceMappingURL=ButtonType.d.ts.map