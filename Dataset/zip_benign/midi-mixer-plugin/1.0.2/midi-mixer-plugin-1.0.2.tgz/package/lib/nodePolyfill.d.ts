export interface AssignmentData {
    name: string;
    volume?: number;
    muted?: boolean;
    assigned?: boolean;
    running?: boolean;
    throttle?: number;
}
export interface ButtonTypeData {
    name: string;
    active?: boolean;
}
export declare type Throttles = Record<string, {
    payload: Record<string, unknown>;
    timer?: ReturnType<typeof setTimeout>;
}>;
/**
 * Polyfill the $MM API with a process-based IPC version for use with separate
 * Node.js processes.
 */
export declare const polyfillApi: () => void;
//# sourceMappingURL=nodePolyfill.d.ts.map