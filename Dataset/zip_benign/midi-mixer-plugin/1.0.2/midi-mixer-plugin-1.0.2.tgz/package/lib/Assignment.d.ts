import EventEmitter from "eventemitter3";
import { AssignmentData } from "./";
/**
 * An Assignment represents a single plugin-scoped entry in the MIDI Mixer
 * assignments list. This assignment can send events to MIDI Mixer as well as
 * react to hardware input coming from the board.
 *
 * ```
 * const foo = new Assignment("foo", {
 *   name: "Foo Entry",
 * });
 *
 * foo.volume = 0.5;
 * foo.muted = true;
 * ```
 */
export declare class Assignment extends EventEmitter {
    readonly id: string;
    private _name;
    private _volume;
    private _meter;
    private _muted;
    private _assigned;
    private _running;
    private _throttle;
    private _meterTimer;
    /**
     * @param id A unique ID for this assignment within this plugin.
     * @param data Data used for MIDI Mixer to set up the assignment.
     */
    constructor(id: string, data: AssignmentData);
    /**
     * Remove the assignment from MIDI Mixer.
     */
    remove(): void;
    /**
     * The name of the assignment within MIDI Mixer. Setting this value updates
     * the entry.
     */
    get name(): string;
    set name(name: string);
    /**
     * The current indicator level for volume. Setting this updates the entry's
     * volume level indicator within MIDI Mixer.
     */
    get volume(): number;
    set volume(level: number);
    /**
     * The current indicator level for meters. Setting this updates the entry's
     * meter level for the next 150ms before falling off or being updated again.
     */
    get meter(): number;
    set meter(level: number);
    /**
     * The current "muted" status indicator. Setting this updates the entry's
     * "muted" status within MIDI Mixer.
     */
    get muted(): boolean;
    set muted(muted: boolean);
    /**
     * The current "assigned" status indicator. Setting this updates the entry's
     * "assigned" status within MIDI Mixer.
     */
    get assigned(): boolean;
    set assigned(assigned: boolean);
    /**
     * The current "running" status indicator. Setting this updates the entry's
     * "running" status within MIDI Mixer.
     */
    get running(): boolean;
    set running(running: boolean);
    /**
     * The minimum amount of time in milliseconds between volume change updates
     * from MIDI Mixer. Some faders are very granular, so throttling these updates
     * is sensible to ensure the good performance of plugins.
     *
     * Accepted values are anything between 50 to 1000.
     *
     * Defaults to 50.
     */
    get throttle(): number;
    set throttle(throttle: number);
}
//# sourceMappingURL=Assignment.d.ts.map