/**
 * Is `true` if we can reasonably assume that this is a Node environment.
 */
export declare const isNode: boolean;
/**
 * If we're a Node process, this will calculate and return the percentage CPU
 * usage for this process. If we're not a Node process, calling this function
 * will likely throw an error due to the use of `process`.
 */
export declare const getNodeCpuUsage: () => number;
//# sourceMappingURL=utils.d.ts.map