import EventEmitter from "eventemitter3";
export declare class NodeIpc extends EventEmitter {
    private invokeTimers;
    constructor();
    invoke(channel: string, ...args: any[]): Promise<any>;
    send(channel: string, ...args: any[]): void;
}
//# sourceMappingURL=NodeIpc.d.ts.map