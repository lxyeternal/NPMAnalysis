import * as i0 from '@angular/core';
import { Injectable, Pipe, Component, ViewEncapsulation, Input, NgModule } from '@angular/core';
import * as i1$1 from '@angular/common';
import * as i1 from '@angular/platform-browser';
import { BrowserModule } from '@angular/platform-browser';

class NgxPhotoGalleryService {
    constructor() { }
}
NgxPhotoGalleryService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: NgxPhotoGalleryService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
NgxPhotoGalleryService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: NgxPhotoGalleryService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: NgxPhotoGalleryService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

class SafeUrlPipe {
    constructor(domSanitizer) {
        this.domSanitizer = domSanitizer;
    }
    transform(value, prefix = '') {
        return this.domSanitizer.bypassSecurityTrustUrl(prefix + value);
    }
}
SafeUrlPipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: SafeUrlPipe, deps: [{ token: i1.DomSanitizer }], target: i0.ɵɵFactoryTarget.Pipe });
SafeUrlPipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: SafeUrlPipe, name: "safeUrl" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: SafeUrlPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'safeUrl'
                }]
        }], ctorParameters: function () { return [{ type: i1.DomSanitizer }]; } });

class NgxPhotoGalleryComponent {
    constructor() {
        this.images = [];
        this.albumTitle = '';
        this.searchAlt = '';
        this.brightness = '1';
        this.searchImageBase64 = '';
    }
}
NgxPhotoGalleryComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: NgxPhotoGalleryComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
NgxPhotoGalleryComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.0.5", type: NgxPhotoGalleryComponent, selector: "ngx-photo-gallery", inputs: { images: "images", albumTitle: "albumTitle", searchAlt: "searchAlt", brightness: "brightness", searchImageBase64: "searchImageBase64" }, ngImport: i0, template: "<div class=\"container mt-5 mb-5\">\n  <h3 class=\"text-center text-uppercase font-weight-bold text-white text-muted\">{{albumTitle}}</h3>\n</div>\n<div class=\"container card-columns mb-5\">\n  <div *ngFor=\"let item of images\" class=\"card gallery-box\">\n    <img *ngIf=\"item.type=='photo'\" [src]=\"item.url\"\n         class=\"card-img-top\" width=\"100%\" [style.filter]=\"'brightness(' + brightness + ')'\">\n    <div class=\"gal-overlay\">\n      <img class=\"search\" [src]=\"searchImageBase64|safeUrl\" [alt]=\"searchAlt\">\n    </div>\n  </div>\n</div>\n", styles: ["@import\"~bootstrap/dist/css/bootstrap.css\";.gallery-box{overflow:hidden;margin:2.5px;position:relative}.gallery-box:after{content:\"\";position:absolute;width:100%;height:100%;left:0;top:0;background:rgba(44,52,48,.8);opacity:0;z-index:2;transition:all .2s ease-in-out;cursor:pointer}.gallery-box i{color:#fff;font-size:25px;position:absolute;left:0;top:-3%;bottom:6%;opacity:0;transition:opacity 1.5s .08s,transform .8s;z-index:4;padding:20px;transform:rotate(140deg);cursor:pointer}.gallery-box:hover .gal-overlay{transform:rotate(-135deg) scale(1);opacity:1}.gallery-box:hover:after{opacity:1}.gallery-box:hover i{opacity:1}.gallery-box img{transition:.5s ease-in-out}.gal-overlay{position:absolute;width:75px;height:75px;bottom:0;right:0;left:0;top:0;margin:auto;border:2px solid #fff;transform:scale(.5);z-index:3;opacity:0;transition:all .9s ease-in-out}.search{position:absolute;left:0;right:0;margin:auto;top:0;bottom:0;transform:rotate(135deg)}\n"], directives: [{ type: i1$1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], pipes: { "safeUrl": SafeUrlPipe }, encapsulation: i0.ViewEncapsulation.None });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: NgxPhotoGalleryComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ngx-photo-gallery',
                    templateUrl: './ngx-photo-gallery.component.html',
                    styleUrls: ['./ngx-photo-gallery.component.css'],
                    encapsulation: ViewEncapsulation.None
                }]
        }], ctorParameters: function () { return []; }, propDecorators: { images: [{
                type: Input
            }], albumTitle: [{
                type: Input
            }], searchAlt: [{
                type: Input
            }], brightness: [{
                type: Input
            }], searchImageBase64: [{
                type: Input
            }] } });

class NgxPhotoGalleryModule {
}
NgxPhotoGalleryModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: NgxPhotoGalleryModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
NgxPhotoGalleryModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: NgxPhotoGalleryModule, declarations: [NgxPhotoGalleryComponent,
        SafeUrlPipe], imports: [BrowserModule], exports: [NgxPhotoGalleryComponent] });
NgxPhotoGalleryModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: NgxPhotoGalleryModule, imports: [[
            BrowserModule
        ]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0, type: NgxPhotoGalleryModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        NgxPhotoGalleryComponent,
                        SafeUrlPipe
                    ],
                    imports: [
                        BrowserModule
                    ],
                    exports: [
                        NgxPhotoGalleryComponent
                    ]
                }]
        }] });

/*
 * Public API Surface of ngx-photo-gallery
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgxPhotoGalleryComponent, NgxPhotoGalleryModule, NgxPhotoGalleryService };
//# sourceMappingURL=ngx-photo-gallery.js.map
