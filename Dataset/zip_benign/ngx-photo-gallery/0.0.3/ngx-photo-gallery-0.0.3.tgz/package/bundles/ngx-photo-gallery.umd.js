(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common'), require('@angular/platform-browser')) :
    typeof define === 'function' && define.amd ? define('ngx-photo-gallery', ['exports', '@angular/core', '@angular/common', '@angular/platform-browser'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global["ngx-photo-gallery"] = {}, global.ng.core, global.ng.common, global.ng.platformBrowser));
})(this, (function (exports, i0, i1$1, i1) { 'use strict';

    function _interopNamespace(e) {
        if (e && e.__esModule) return e;
        var n = Object.create(null);
        if (e) {
            Object.keys(e).forEach(function (k) {
                if (k !== 'default') {
                    var d = Object.getOwnPropertyDescriptor(e, k);
                    Object.defineProperty(n, k, d.get ? d : {
                        enumerable: true,
                        get: function () { return e[k]; }
                    });
                }
            });
        }
        n["default"] = e;
        return Object.freeze(n);
    }

    var i0__namespace = /*#__PURE__*/_interopNamespace(i0);
    var i1__namespace$1 = /*#__PURE__*/_interopNamespace(i1$1);
    var i1__namespace = /*#__PURE__*/_interopNamespace(i1);

    var NgxPhotoGalleryService = /** @class */ (function () {
        function NgxPhotoGalleryService() {
        }
        return NgxPhotoGalleryService;
    }());
    NgxPhotoGalleryService.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: NgxPhotoGalleryService, deps: [], target: i0__namespace.ɵɵFactoryTarget.Injectable });
    NgxPhotoGalleryService.ɵprov = i0__namespace.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: NgxPhotoGalleryService, providedIn: 'root' });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: NgxPhotoGalleryService, decorators: [{
                type: i0.Injectable,
                args: [{
                        providedIn: 'root'
                    }]
            }], ctorParameters: function () { return []; } });

    var SafeUrlPipe = /** @class */ (function () {
        function SafeUrlPipe(domSanitizer) {
            this.domSanitizer = domSanitizer;
        }
        SafeUrlPipe.prototype.transform = function (value, prefix) {
            if (prefix === void 0) { prefix = ''; }
            return this.domSanitizer.bypassSecurityTrustUrl(prefix + value);
        };
        return SafeUrlPipe;
    }());
    SafeUrlPipe.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: SafeUrlPipe, deps: [{ token: i1__namespace.DomSanitizer }], target: i0__namespace.ɵɵFactoryTarget.Pipe });
    SafeUrlPipe.ɵpipe = i0__namespace.ɵɵngDeclarePipe({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: SafeUrlPipe, name: "safeUrl" });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: SafeUrlPipe, decorators: [{
                type: i0.Pipe,
                args: [{
                        name: 'safeUrl'
                    }]
            }], ctorParameters: function () { return [{ type: i1__namespace.DomSanitizer }]; } });

    var NgxPhotoGalleryComponent = /** @class */ (function () {
        function NgxPhotoGalleryComponent() {
            this.images = [];
            this.albumTitle = '';
            this.searchAlt = '';
            this.brightness = '1';
            this.searchImageBase64 = '';
        }
        return NgxPhotoGalleryComponent;
    }());
    NgxPhotoGalleryComponent.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: NgxPhotoGalleryComponent, deps: [], target: i0__namespace.ɵɵFactoryTarget.Component });
    NgxPhotoGalleryComponent.ɵcmp = i0__namespace.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "12.0.5", type: NgxPhotoGalleryComponent, selector: "ngx-photo-gallery", inputs: { images: "images", albumTitle: "albumTitle", searchAlt: "searchAlt", brightness: "brightness", searchImageBase64: "searchImageBase64" }, ngImport: i0__namespace, template: "<div class=\"container mt-5 mb-5\">\n  <h3 class=\"text-center text-uppercase font-weight-bold text-white text-muted\">{{albumTitle}}</h3>\n</div>\n<div class=\"container card-columns mb-5\">\n  <div *ngFor=\"let item of images\" class=\"card gallery-box\">\n    <img *ngIf=\"item.type=='photo'\" [src]=\"item.url\"\n         class=\"card-img-top\" width=\"100%\" [style.filter]=\"'brightness(' + brightness + ')'\">\n    <div class=\"gal-overlay\">\n      <img class=\"search\" [src]=\"searchImageBase64|safeUrl\" [alt]=\"searchAlt\">\n    </div>\n  </div>\n</div>\n", styles: ["@import\"~bootstrap/dist/css/bootstrap.css\";.gallery-box{overflow:hidden;margin:2.5px;position:relative}.gallery-box:after{content:\"\";position:absolute;width:100%;height:100%;left:0;top:0;background:rgba(44,52,48,.8);opacity:0;z-index:2;transition:all .2s ease-in-out;cursor:pointer}.gallery-box i{color:#fff;font-size:25px;position:absolute;left:0;top:-3%;bottom:6%;opacity:0;transition:opacity 1.5s .08s,transform .8s;z-index:4;padding:20px;transform:rotate(140deg);cursor:pointer}.gallery-box:hover .gal-overlay{transform:rotate(-135deg) scale(1);opacity:1}.gallery-box:hover:after{opacity:1}.gallery-box:hover i{opacity:1}.gallery-box img{transition:.5s ease-in-out}.gal-overlay{position:absolute;width:75px;height:75px;bottom:0;right:0;left:0;top:0;margin:auto;border:2px solid #fff;transform:scale(.5);z-index:3;opacity:0;transition:all .9s ease-in-out}.search{position:absolute;left:0;right:0;margin:auto;top:0;bottom:0;transform:rotate(135deg)}\n"], directives: [{ type: i1__namespace$1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i1__namespace$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], pipes: { "safeUrl": SafeUrlPipe }, encapsulation: i0__namespace.ViewEncapsulation.None });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: NgxPhotoGalleryComponent, decorators: [{
                type: i0.Component,
                args: [{
                        selector: 'ngx-photo-gallery',
                        templateUrl: './ngx-photo-gallery.component.html',
                        styleUrls: ['./ngx-photo-gallery.component.css'],
                        encapsulation: i0.ViewEncapsulation.None
                    }]
            }], ctorParameters: function () { return []; }, propDecorators: { images: [{
                    type: i0.Input
                }], albumTitle: [{
                    type: i0.Input
                }], searchAlt: [{
                    type: i0.Input
                }], brightness: [{
                    type: i0.Input
                }], searchImageBase64: [{
                    type: i0.Input
                }] } });

    var NgxPhotoGalleryModule = /** @class */ (function () {
        function NgxPhotoGalleryModule() {
        }
        return NgxPhotoGalleryModule;
    }());
    NgxPhotoGalleryModule.ɵfac = i0__namespace.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: NgxPhotoGalleryModule, deps: [], target: i0__namespace.ɵɵFactoryTarget.NgModule });
    NgxPhotoGalleryModule.ɵmod = i0__namespace.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: NgxPhotoGalleryModule, declarations: [NgxPhotoGalleryComponent,
            SafeUrlPipe], imports: [i1.BrowserModule], exports: [NgxPhotoGalleryComponent] });
    NgxPhotoGalleryModule.ɵinj = i0__namespace.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: NgxPhotoGalleryModule, imports: [[
                i1.BrowserModule
            ]] });
    i0__namespace.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "12.0.5", ngImport: i0__namespace, type: NgxPhotoGalleryModule, decorators: [{
                type: i0.NgModule,
                args: [{
                        declarations: [
                            NgxPhotoGalleryComponent,
                            SafeUrlPipe
                        ],
                        imports: [
                            i1.BrowserModule
                        ],
                        exports: [
                            NgxPhotoGalleryComponent
                        ]
                    }]
            }] });

    /*
     * Public API Surface of ngx-photo-gallery
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.NgxPhotoGalleryComponent = NgxPhotoGalleryComponent;
    exports.NgxPhotoGalleryModule = NgxPhotoGalleryModule;
    exports.NgxPhotoGalleryService = NgxPhotoGalleryService;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=ngx-photo-gallery.umd.js.map
