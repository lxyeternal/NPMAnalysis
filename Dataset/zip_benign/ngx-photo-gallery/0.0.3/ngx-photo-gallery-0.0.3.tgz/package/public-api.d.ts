export * from './lib/ngx-photo-gallery.service';
export * from './lib/ngx-photo-gallery.component';
export * from './lib/ngx-photo-gallery.module';
