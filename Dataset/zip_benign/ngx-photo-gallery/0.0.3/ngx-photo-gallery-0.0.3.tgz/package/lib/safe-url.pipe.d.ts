import { PipeTransform } from '@angular/core';
import { DomSanitizer } from "@angular/platform-browser";
import * as i0 from "@angular/core";
export declare class SafeUrlPipe implements PipeTransform {
    private domSanitizer;
    constructor(domSanitizer: DomSanitizer);
    transform(value: any, prefix?: string): import("@angular/platform-browser").SafeUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<SafeUrlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SafeUrlPipe, "safeUrl">;
}
