import * as i0 from "@angular/core";
export declare class NgxPhotoGalleryComponent {
    constructor();
    images: Array<{
        type: string;
        url: string;
    }>;
    albumTitle: string;
    searchAlt: string;
    brightness: string;
    searchImageBase64: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxPhotoGalleryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NgxPhotoGalleryComponent, "ngx-photo-gallery", never, { "images": "images"; "albumTitle": "albumTitle"; "searchAlt": "searchAlt"; "brightness": "brightness"; "searchImageBase64": "searchImageBase64"; }, {}, never, never>;
}
