import * as i0 from "@angular/core";
export declare class NgxPhotoGalleryService {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxPhotoGalleryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NgxPhotoGalleryService>;
}
