import * as i0 from "@angular/core";
import * as i1 from "./ngx-photo-gallery.component";
import * as i2 from "./safe-url.pipe";
import * as i3 from "@angular/platform-browser";
export declare class NgxPhotoGalleryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxPhotoGalleryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NgxPhotoGalleryModule, [typeof i1.NgxPhotoGalleryComponent, typeof i2.SafeUrlPipe], [typeof i3.BrowserModule], [typeof i1.NgxPhotoGalleryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NgxPhotoGalleryModule>;
}
