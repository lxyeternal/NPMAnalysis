/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ngx-photo-gallery" />
export * from './public-api';
