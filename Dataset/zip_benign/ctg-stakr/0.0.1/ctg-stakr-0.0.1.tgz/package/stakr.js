
import { appendFakeData } from './fake';
import TinyAnimate from 'TinyAnimate';

export default class {
  constructor(container, userOptions, callback) {

    // merge user options
    this.options = { ...this.getDefaultOptions(), ...userOptions};

    // Store references so we can remove and cancel;
    this.id = null;
    this.onClicks = [];
    this.onEnters = [];
    this.onLeaves = [];

    this.container = this.getContainer(container);

    this.stackModel = {
      class: '',
      nodes: [],
      count: 0,
    };

    this.staks = {
      all: Object.assign({}, this.stackModel),
      image: Object.assign({}, this.stackModel),
      content: Object.assign({}, this.stackModel),
    };

    this.expandedStak = null;
    this.scrollingStak = null;
    this.staksStats = {};

    this.staks.all.nodes = this.getStaks(this.options.classes.stak);
    this.staks.all.count = this.staks.all.nodes.length;

    if (!this.staks.all.count) {
      console.error('No staks found. Please make sure that the stak elements class matches that defined in the options. ".stak" is the default class.');
      return;
    }

    // images
    this.staks.image.nodes = this.filterStaks(this.options.classes.image);
    this.staks.image.count = this.staks.image.length;

    // content
    this.staks.content.nodes = this.filterStaks(this.options.classes.content);
    this.staks.content.count = this.staks.content.nodes.length;

    this.setInitialHeights('content', this.staks.content.nodes);

    this.unbind = {
      clicks(node){
        console.log('unbindClicks', node);
        node.stak.removeEventListener('click', node.ref, false);
      },
      enters(node){
        console.log('unbindEnters', node);
        node.stak.removeEventListener('mouseenter', node.ref, false);
      },
      leaves(node){
        console.log('unbindLeaves', node);
        node.stak.removeEventListener('mouseleave', node.ref, false);
      }
    };

    // unstakm
    this.unStakm = function() {
      console.log('Unstacking..', this);
      this.onClicks.forEach(this.unbind.clicks);
      this.onEnters.forEach(this.unbind.enters);
      this.onLeaves.forEach(this.unbind.leaves);
    };

    // init / stakm
    this.stakm = function() {
      if(!this.staks.content.count) return console.error('No content staks to stak. Check your class definitions and markup. Good bye.');

      // always start from the top;
      window.onbeforeunload = function () { window.scrollTo(0, 0); };

      console.log('Staking content nodes:', this.staks.content.nodes);

      // Todo: allow images to be expandable too;
      this.staks.content.nodes.forEach(this.bindEvents.bind(this));

      if (callback) callback(this);
    };


    if (this.options.autoStak) { this.stakm(); }

    console.log('this.staks', this.staks);

    // resturn a copy
    return Object.assign({}, this);

  } // end of constructor


  /**
   *
   *  Functions
   */
  getDefaultOptions() {
    return {
      autoStak: false,
      reverseExpand: false,
      heights: {
        contentExpanded: 0.8,
        contentRetracted: 0.4,
      },
      expandableStaks: {
        image: false,
        content: true,
      },
      classes: {
        stak: 'stak',
        image: 'stak__image',
        content: 'stak__content',
        scrollContainer: 'stak__content-items',
        expanded: '--expanded'
      },
      scrollTopOnExpand: true,
      expandDelay: 50,
      expandDuration: 400,
      backToTopSpeed: 300,
      easings: {
        expand: 'easeInSine',
        retract: 'easeOutSine'
      }
    };
  };

  setInitialHeights(type, nodes) {
    if (type !== 'content') return console.error('This type is not yet supported. Images coming soon');
    const targetHeight = this.options.heights.contentRetracted * window.innerHeight;
    nodes.forEach(node => node.style.height = `${targetHeight}px`);
  }
  setInitialPointers(type, nodes){
    if (type !== 'content') return console.error('This type is not yet supported. Images coming soon');
    nodes.forEach(node => node.style.height = `${targetHeight}px`);
  }

  hoverEnterHandler(event) {
    const {target} = event;
    console.log('In', target);
  }
  hoverLeaveHandler(event) {
    const {target} = event;
    console.log('Out of', target);
    console.log('resetting scroll position');
    // target.scrollTop = 0;
    const scrollToTop = (value) => target.scrollTop = value;
    if (target.scrollTop === 0) return;
    TinyAnimate.animate(target.scrollTop, 0, this.options.backToTopSpeed, scrollToTop);
  }

  bindEvents(stak, index){
    // save ref so we can remove
    const stakClickHandler = this.update.bind(this);
    const stakEnterHandler = this.hoverEnterHandler.bind(this);
    const stakLeaveHandler = this.hoverLeaveHandler.bind(this);

    this.onClicks.push({ stak: stak, ref: stakClickHandler });
    this.onEnters.push({ stak: stak, ref: stakEnterHandler });
    this.onLeaves.push({ stak: stak, ref: stakLeaveHandler });

    appendFakeData(stak, index, this.options.classes.scrollContainer);

    stak.addEventListener('click', stakClickHandler, false);
    stak.addEventListener('mouseenter', stakEnterHandler, false);
    stak.addEventListener('mouseleave', stakLeaveHandler, false);
    return stak;
  }



  async update(event) {
    console.log('Updating staks...');
    const { target } = event;
    const clickedTargetIsExpandableStak = target.classList.contains(this.options.classes.content);

    console.log('Clicked expandable stak i.e - content?', clickedTargetIsExpandableStak);
    if (!clickedTargetIsExpandableStak) {
      console.log('Good bye, ignoring click from non-expandable stak', target);
      return;
    }

    /** Content click */
    console.log('Yes, Setting as active..');
    const activeStak = target;
    const stakIsExpanded = activeStak.classList.contains(this.options.classes.expanded);

    console.log('Clicked expandable already expanded?', stakIsExpanded);

    return this.expandContract(activeStak, stakIsExpanded);

  }


  async expandContract(activeStak, stakIsExpanded) {
    const eto = setTimeout(() => {
      if (stakIsExpanded) {
        console.log('Yes, retracting stak....');
        this.retract(activeStak);
      } else {
        console.log('No, Expanding stak....');

        if (this.options.reverseExpand) {
          this.expand(activeStak);
          if (this.expandedStak) this.retract(this.expandedStak);
        } else {
          if (this.expandedStak) this.retract(this.expandedStak);
          this.expand(activeStak);
        }
      }

      return clearTimeout(eto);
    }, this.options.expandDelay);
  }

  async retract(stak) {
    console.warn('Retracting started', stak);
    const expanding = false;
    this.animateHeight({stak, expanding});
    this.setOverflowY({stak, expanding});
    this.setExpanded({stak, expanding});

    // remove scroll listeners on retract
    const scrollable = await this.getScrollable(stak);
    if (!scrollable) {
      console.error('Could not find a scrollable container to reset');
    } else {
      // scroll back to the retracted container
      this.setPointerEvents({scrollable, expanding});
    }
    console.warn('Retracting complete.');
    return stak;
  };


  animateHeight({stak, expanding}) {

    return new Promise((resolve, reject) => {

      const animateFn = height => stak.style.height = height + 'px';
      const expandAnimDone = () => {
        console.log('Expanding animation complete.');
        if (this.options.scrollTopOnExpand) {
          console.log('Positioning on top...');
          this.postionTop();
          resolve();
          return;
        }
        resolve();
      };

      const retractAnimDone = () => {
        console.log('Retracting animation complete.');
        resolve();
        return;
      };

      if (expanding) {
        // set it to expanded height
        const expandToHeight = this.options.heights.contentExpanded * window.innerHeight;
        TinyAnimate.animate(stak.offsetHeight, expandToHeight, this.options.expandDuration, animateFn, this.options.easings.expand, expandAnimDone);

      } else {
      // retracting back to initial height
        const retractToHeight = this.options.heights.contentRetracted * window.innerHeight;
        TinyAnimate.animate(stak.offsetHeight, retractToHeight, this.options.expandDuration, animateFn, this.options.easings.retract, retractAnimDone);
      }

    });
  }

  setOverflowY({stak, expanding}) {
    if (expanding) stak.style.overflowY = 'scroll';
    else {
      if (this.staksStats.isLast) stak.style.overflowY = 'auto';
      else stak.style.overflowY = 'hidden';
    }

    console.log('Overflow set to:', stak.style.overflowY);
  }

  setExpanded({stak, expanding}) {
    if (expanding) {
      stak.classList.add(this.options.classes.expanded);
      this.expandedStak = stak;
    } else {
      stak.classList.remove(this.options.classes.expanded);
      this.expandedStak = null;
    }
  }

  getScrollable(stak) {
    // find scrollable
    const scrollable =  stak.querySelectorAll(`main > .${this.options.classes.scrollContainer}`);
    const haveScrollable = (scrollable && (scrollable.length > 0));

    if(!haveScrollable) {
      console.error('Expanded content doesnt not have a scrollable container');
      return null;
    }

    console.log('Found scrollable stak container:', scrollable[0]);
    return scrollable[0];
  };


  getClosest(elem, selector) {
    for ( ; elem && elem !== document; elem = elem.parentNode ) {
      if ( elem.matches( selector ) ) return elem;
    }
    return null;
  };

  async getStaksStats(stak) {
    // get height to sroll based on above sections heights.
    // They will all be contracted at this point
    let staksData = {toTheTop:0, images:0, contents:0, beforeStak: true, isLast: false};

    const staksStats = this.staks.all.nodes.reduce((acc, node, index) => {
      if (node === stak) {
        acc.beforeStak = false;
        if (index === this.staks.all.nodes.length -1) {
          acc.isLast = true;
        }
      }

      if (!acc.beforeStak) return acc;

      if (node.classList.contains('stak__image')) {
        acc.images++;
        console.log(index, '- adding image of height:', node.offsetHeight);
        acc.toTheTop += node.offsetHeight;
      };

      if (node.classList.contains('stak__content')) {
        acc.contents++;
        const retractedContentH = this.options.heights.contentRetracted * window.innerHeight;

        acc.toTheTop += retractedContentH;
      };

      return acc;
    }, staksData);
    return staksStats;
  }

  async postionTop() {
    if (this.staksStats.isLast) await window.scrollTo(0, document.body.scrollHeight + 500);
    else await window.scrollTo({ top: this.staksStats.toTheTop, behavior: 'smooth' });
  }

  async expand(stak){
    console.warn('Expanding stared..');
    this.staksStats = await this.getStaksStats(stak);
    const expanding = true;
    this.setExpanded({stak, expanding});
    await this.animateHeight({stak, expanding});

    const scrollable = await this.getScrollable(stak);
    if(!scrollable) return console.error('Could not find scrollable container on expanding stak');
    if (scrollable) {
      this.setPointerEvents({scrollable, expanding});
      this.setOverflowY({stak, expanding});
    }
    console.warn('Expanding complete....');
    return stak;
  };


  setPointerEvents({scrollable, expanding}){
    if (expanding) {
      console.log('Activating scrollable stak listerner:', scrollable);
      return scrollable.style.pointerEvents = 'initial';
    }

    console.log('De-activating scrollable stak listerner:', scrollable);
    return scrollable.style.pointerEvents = 'none';
  };


  findPos(obj) {
    let curtop = 0;
    if (obj.offsetParent) {
        do {
            curtop += obj.offsetTop;
        } while (obj = obj.offsetParent);
    return [curtop];
    }
  }

  filterStaks(type){
    console.log(`Filtering ${type} stack..`, this.staks);
    return this.staks.all.nodes.filter((stak) => stak.classList.contains(type));
  }

  getStaks(type) {
    return Array.from(this.container.querySelectorAll(`.${type}`));
  }

  getContainer(container) {
    // Passed a DOM element
    if (this.elementFound(container)) {
      return container;
    }

    // Passed a selector
    const foundContainer = document.querySelector(container);
    if (this.elementFound(foundContainer)) {
      return foundContainer;
    }

    console.error('Could not find target container:', container);
    return false;
  }

  elementFound(element) {
    return this.isElement(element);
  }

  isElement(element) {
    return element instanceof Element || element instanceof HTMLDocument;
  }

}