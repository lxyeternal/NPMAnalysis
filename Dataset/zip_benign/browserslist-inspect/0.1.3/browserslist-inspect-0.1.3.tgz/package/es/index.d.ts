import browserslist from "browserslist";
export declare type BrowserInspectResult = 'MATCHED' | 'BROWSER_NOT_SUPPORTED' | 'VERSION_TOO_LOW' | 'VERSION_TOO_HIGH';
declare const browserInspect: (queries?: string | undefined, opts?: browserslist.Options | undefined) => BrowserInspectResult;
export default browserInspect;
