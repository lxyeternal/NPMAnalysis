'use strict';
// var Bar = require('../../bar');
var Bar = require('dchart-core/bar/bar');
// var _ = require('../../../util');
var _ = require('dchart-core/util');
var textures = require('textures');
var d3 = require('d3');

function BarWithBG(container, options) {
  var opt = {
    margin: {top: 20, right: 20, bottom: 30, left: 20},
    xaxis: {
      type: 'category',
      groupPadding: [0.4, 0],
      dy: 10
    },
    yaxis: {},
    bg: {
      texture: null,
      color: {
        style: 'single',
        value: '#rgba(1,1,1,.2)',
      },
      show: true
    }
  };
  opt = _.deepMerge(opt, options);
  Bar.call(this, container, opt);
}
BarWithBG = Bar.extend(BarWithBG, {
  beforeRender: function () {
    Bar.prototype.beforeRender.call(this);
    this.dealColor(this.options, 'bg.color');
  },
  updateBeforeRender: function () {
    Bar.prototype.updateBeforeRender.call(this);
    BarWithBG.prototype.beforeRender.call(this);
  },
  afterRender: function () {
    Bar.prototype.afterRender.call(this);
    var opt = this.options;
    var svg = this.svg;
    var x = this.getComs('axis', 'xaxis').getX();
    var bars = this.series;

    var xkey = opt.xaxis.key;
    var texture = null;
    if (opt.bg.texture) {
      var tp = opt.bg.texture;
      texture = textures.lines()
        .orientation(tp.orient || 'horizontal')
        .stroke(tp.stroke || 'rgb(245, 245, 245)')
        .size(tp.size || 10)
        .strokeWidth(tp.stokeWidth || 5)
        .shapeRendering(tp.shape || 'crispEdges');
      svg.call(texture);
    }

    var updateSerieAttr = function (d, i) {
      var that = d3.select(this);
      that.attr({
        x: function () {
          return x(d[xkey]);
        },
        y: -1,
        width: x.rangeBand(),
        height: opt.innerHeight + 2
      });
      if (opt.bg.style === 'texture' && texture) {
        that.style('fill', texture.url());
      } else that.style('fill', opt.bg.color && opt.bg.color.res);
    };

    var bgs = bars.selectAll('.serie-bg');
    bgs[0].length && bars.selectAll('.series-group').each(function (d, i) {
      bgs[0][i] && updateSerieAttr.call(bgs[0][i], d, i);
    });

    this.enterSeries.each(function (d, i) {
      let d3this = d3.select(this);
      var bg = d3this.select('.serie-bg')[0][0] ? d3this.select('.serie-bg') : d3this.insert('rect', ':first-child')
        .attr('class', 'serie-bg');
      updateSerieAttr.call(bg[0][0], d, i);
    });

    bars.selectAll('serie-bg').style('show', opt.bg.show && 'block' || 'none');
  },
  updateAfterRender: function () {
    Bar.prototype.updateAfterRender.call(this);
    BarWithBG.prototype.afterRender.call(this);
  }
});

module.exports = BarWithBG;
