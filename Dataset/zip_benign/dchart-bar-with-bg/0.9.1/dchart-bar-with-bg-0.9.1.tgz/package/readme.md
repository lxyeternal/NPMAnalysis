dchart-bar-hori-gradient

符合dchart规范的柱状对比图，柱子背景可以为渐变色

### 安装

```
npm install dchart-bar-hori-gradient
```

### 用法
```
var Bar = require('dchart-bar-hori-gradient');
var bar = new Bar(container, {
  margin: {left:14, top:30, right: 16, bottom: 98},
    yaxis : {
      padding: [0.5, 0.6],
      groupPadding: [0, 0],
      dy : 2
    },
    gradientColors : {
      from: 'rgb(255,255,0)',
      to: 'rgb(255,0,0)',
      orient: 'vertical',
    },
    background: {}
});
bar.render([
        {"x": "山东", "y": 100},
        {"x": "山西", "y": 52},
        {"x": "河北", "y": 49}
      ]);
```

### 案例
```
在根目录下, 启动
cube start
访问路径
http://localhost:9999/demo/test.html
```
