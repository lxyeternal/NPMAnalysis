import type { Audit, Group } from '@code-pushup/models';
import type { AuditSlug } from './models.js';
export declare const PLUGIN_SLUG = "jsdocs";
export declare const AUDITS_MAP: Record<AuditSlug, Audit>;
export declare const groups: Group[];
