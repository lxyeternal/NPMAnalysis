import { SyntaxKind } from 'ts-morph';
import type { CoverageType } from './models.js';
/** Maps the SyntaxKind from the library ts-morph to the coverage type. */
export declare const SYNTAX_COVERAGE_MAP: Map<SyntaxKind, CoverageType>;
