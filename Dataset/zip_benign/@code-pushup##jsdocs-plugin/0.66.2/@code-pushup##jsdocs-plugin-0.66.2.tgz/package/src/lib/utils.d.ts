import type { Audit, Group } from '@code-pushup/models';
import type { JsDocsPluginTransformedConfig } from './config.js';
/**
 * Get audits based on the configuration.
 * If no audits are specified, return all audits.
 * If audits are specified, return only the specified audits.
 * @param config - The configuration object.
 * @returns The audits.
 */
export declare function filterAuditsByPluginConfig(config: Pick<JsDocsPluginTransformedConfig, 'onlyAudits' | 'skipAudits'>): Audit[];
/**
 * Filter groups by the audits that are specified in the configuration.
 * The groups refs are filtered to only include the audits that are specified in the configuration.
 * @param groups - The groups to filter.
 * @param options - The configuration object containing either onlyAudits or skipAudits.
 * @returns The filtered groups.
 */
export declare function filterGroupsByOnlyAudits(groups: Group[], options: Pick<JsDocsPluginTransformedConfig, 'onlyAudits' | 'skipAudits'>): Group[];
