import { SyntaxKind } from 'ts-morph';
import type { CoverageType, DocumentationCoverageReport, DocumentationReport } from './models.js';
/**
 * Creates an empty unprocessed coverage report.
 * @returns The empty unprocessed coverage report.
 */
export declare function createEmptyCoverageData(): DocumentationReport;
/**
 * Converts the coverage type to the audit slug.
 * @param type - The coverage type.
 * @returns The audit slug.
 */
export declare function coverageTypeToAuditSlug(type: CoverageType): string;
/**
 * Calculates the coverage percentage for each coverage type.
 * @param result - The unprocessed coverage result.
 * @returns The processed coverage result.
 */
export declare function calculateCoverage(result: DocumentationReport): DocumentationCoverageReport;
/**
 * Maps the SyntaxKind from the library ts-morph to the coverage type.
 * @param kind - The SyntaxKind from the library ts-morph.
 * @returns The coverage type.
 */
export declare function getCoverageTypeFromKind(kind: SyntaxKind): CoverageType;
