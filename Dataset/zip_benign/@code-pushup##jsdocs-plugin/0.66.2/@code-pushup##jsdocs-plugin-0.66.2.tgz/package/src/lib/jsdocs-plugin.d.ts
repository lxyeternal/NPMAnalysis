import type { PluginConfig } from '@code-pushup/models';
import { type JsDocsPluginConfig } from './config.js';
export declare const PLUGIN_TITLE = "JSDoc coverage";
export declare const PLUGIN_DESCRIPTION = "Official Code PushUp JSDoc coverage plugin.";
export declare const PLUGIN_DOCS_URL = "https://www.npmjs.com/package/@code-pushup/jsdocs-plugin/";
/**
 * Instantiates Code PushUp documentation coverage plugin for core config.
 *
 * @example
 * import jsDocsPlugin from '@code-pushup/jsdocs-plugin'
 *
 * export default {
 *   // ... core config ...
 *   plugins: [
 *     // ... other plugins ...
 *     jsDocsPlugin(['**&#47;*.ts'])
 *   ]
 * }
 *
 * @returns Plugin configuration.
 */
export declare function jsDocsPlugin(config: JsDocsPluginConfig): PluginConfig;
