import { z } from 'zod';
export declare const jsDocsPluginConfigSchema: z.ZodEffects<z.ZodUnion<[z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>, z.ZodEffects<z.ZodObject<{
    skipAudits: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    onlyAudits: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    patterns: z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>;
}, "strip", z.ZodTypeAny, {
    patterns: string | string[];
    skipAudits?: string[] | undefined;
    onlyAudits?: string[] | undefined;
}, {
    patterns: string | string[];
    skipAudits?: string[] | undefined;
    onlyAudits?: string[] | undefined;
}>, {
    patterns: string | string[];
    skipAudits?: string[] | undefined;
    onlyAudits?: string[] | undefined;
}, {
    patterns: string | string[];
    skipAudits?: string[] | undefined;
    onlyAudits?: string[] | undefined;
}>]>, {
    patterns: string | string[];
    skipAudits?: string[] | undefined;
    onlyAudits?: string[] | undefined;
}, string | string[] | {
    patterns: string | string[];
    skipAudits?: string[] | undefined;
    onlyAudits?: string[] | undefined;
}>;
/** Type of the config that is passed to the plugin */
export type JsDocsPluginConfig = z.input<typeof jsDocsPluginConfigSchema>;
/** Same as JsDocsPluginConfig but processed so the config is already an object even if it was passed the array of patterns */
export type JsDocsPluginTransformedConfig = z.infer<typeof jsDocsPluginConfigSchema>;
