import type { AuditOutputs, RunnerFunction } from '@code-pushup/models';
import type { JsDocsPluginTransformedConfig } from '../config.js';
import type { DocumentationCoverageReport } from './models.js';
export declare function createRunnerFunction(config: JsDocsPluginTransformedConfig): RunnerFunction;
/**
 * Transforms the coverage report into audit outputs.
 * @param coverageResult - The coverage result containing undocumented items and coverage statistics
 * @param options - Configuration options specifying which audits to include and exclude
 * @returns Audit outputs with coverage scores and details about undocumented items
 */
export declare function trasformCoverageReportToAuditOutputs(coverageResult: DocumentationCoverageReport, options: Pick<JsDocsPluginTransformedConfig, 'onlyAudits' | 'skipAudits'>): AuditOutputs;
