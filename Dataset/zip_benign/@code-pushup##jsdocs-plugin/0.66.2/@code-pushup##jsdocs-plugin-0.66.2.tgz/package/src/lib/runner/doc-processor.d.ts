import { ClassDeclaration, JSDoc, SourceFile, SyntaxKind, VariableStatement } from 'ts-morph';
import type { JsDocsPluginTransformedConfig } from '../config.js';
import type { DocumentationCoverageReport, DocumentationReport } from './models.js';
/**
 * Gets the variables information from the variable statements
 * @param variableStatements - The variable statements to process
 * @returns The variables information with the right methods to get the information
 */
export declare function getVariablesInformation(variableStatements: VariableStatement[]): {
    getName: () => string;
    getKind: () => SyntaxKind;
    getJsDocs: () => JSDoc[];
    getStartLineNumber: () => number;
}[];
/**
 * Processes documentation coverage for TypeScript files in the specified path
 * @param config - The configuration object containing patterns to include for documentation analysis
 * @returns Object containing coverage statistics and undocumented items
 */
export declare function processJsDocs(config: JsDocsPluginTransformedConfig): DocumentationCoverageReport;
export declare function getAllNodesFromASourceFile(sourceFile: SourceFile): ({
    getName: () => string;
    getKind: () => SyntaxKind;
    getJsDocs: () => JSDoc[];
    getStartLineNumber: () => number;
} | ClassDeclaration | import("ts-morph").FunctionDeclaration | import("ts-morph").MethodDeclaration | import("ts-morph").PropertyDeclaration | import("ts-morph").TypeAliasDeclaration | import("ts-morph").EnumDeclaration | import("ts-morph").InterfaceDeclaration)[];
/**
 * Gets the documentation coverage report from the source files
 * @param sourceFiles - The source files to process
 * @returns The documentation coverage report
 */
export declare function getDocumentationReport(sourceFiles: SourceFile[]): DocumentationCoverageReport;
/**
 * Merges two documentation results
 * @param accumulatedReport - The first empty documentation result
 * @param currentFileReport - The second documentation result
 * @returns The merged documentation result
 */
export declare function mergeDocumentationReports(accumulatedReport: DocumentationReport, currentFileReport: Partial<DocumentationReport>): DocumentationReport;
/**
 * Gets the nodes from a class
 * @param classNodes - The class nodes to process
 * @returns The nodes from the class
 */
export declare function getClassNodes(classNodes: ClassDeclaration[]): (import("ts-morph").MethodDeclaration | import("ts-morph").PropertyDeclaration)[];
