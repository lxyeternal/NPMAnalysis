import { jsDocsPlugin } from './lib/jsdocs-plugin.js';
export default jsDocsPlugin;
//# sourceMappingURL=index.js.map