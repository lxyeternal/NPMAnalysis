# 🎯 react-cursor-lines

**react-cursor-lines** é uma biblioteca leve e personalizável para adicionar efeitos de linhas animadas ao cursor em aplicações React.

## 📦 Instalação

Com **npm**:

```bash
npm install react-cursor-lines
```

Com **yarn**:

```bash
yarn add react-cursor-lines
```

## 🚀 Como Usar

Exemplo básico de utilização no **Next.js** ou em qualquer projeto React:

```tsx
import { CursorLines } from 'react-cursor-lines';

export default function App() {

  return <CursorLines />;
};
```

## 🔧 Propriedades do `CursorLines`

| Propriedade    | Tipo      | Padrão      | Descrição                                      |
|----------------|-----------|-------------|-----------------------------------------------|
| `color`        | `string`  | `#ffffff`   | Define a cor das linhas do cursor.             |
| `lineWidth`    | `number`  | `1`         | Define a espessura das linhas.                 |
| `smoothness`   | `number`  | `0.5`       | Controla a suavidade do movimento das linhas.  |
| `trailLength`  | `number`  | `10`        | Comprimento máximo do rastro das linhas.       |

## 📄 Exemplos

Exemplo com personalização avançada:

```tsx
import { CursorLines } from 'react-cursor-lines';

export const CustomCursor = () => (
  <CursorLines
    color="#ff5733"
    lineWidth={3}
    smoothness={0.9}
    trailLength={20}
  />
);
```

## 📚 Compatibilidade

- React 18+
- Next.js 13+
- Suporte a SSR (Server-Side Rendering)

## 📜 Licença

Este projeto está licenciado sob a licença **MIT**. Consulte o arquivo [LICENSE](./LICENSE) para mais detalhes.

---

💡 **Contribuições são bem-vindas!**

Se você tiver alguma sugestão ou encontrar um bug, fique à vontade para abrir uma issue ou enviar um pull request.

