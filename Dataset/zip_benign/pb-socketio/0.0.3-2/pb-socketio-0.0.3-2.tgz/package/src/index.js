import {pomelo as origin}  from './lib/pomelo-all'

let readyResolve, readyReject

export const pomelo = Object.create(origin)

export const readyPromise = new Promise((resolve, reject) => {
  readyResolve = resolve
  readyReject = reject
})

pomelo.init = (params, next) => {
  try {
    origin.init(params, (websocket) => {
      next && next(websocket)
      readyResolve(websocket)
    })
  } catch(err) {
    readyReject(err)
  }
  return readyPromise
}

pomelo.request = (route, data = {}, next) => {
  return readyPromise.then(() => {
    return new Promise((resolve, reject) => {
      origin.request(route, data, (res) => {
        next && next(res)
        resolve(res)
        if(res && res.code === 500) console.error(`${route} failed: `, res);
      })
    })
  })
}

pomelo.on = (...args) => origin.on(...args)
