export interface ProgressHookResult {
    inProgress?: boolean;
    activeStep?: any;
    completed?: boolean;
    error?: Error;
    setActiveStep: (v: any) => void;
    setCompleted: () => void;
    setError: (e: Error) => void;
    reset: () => void;
}
export declare const useProgress: () => ProgressHookResult;
