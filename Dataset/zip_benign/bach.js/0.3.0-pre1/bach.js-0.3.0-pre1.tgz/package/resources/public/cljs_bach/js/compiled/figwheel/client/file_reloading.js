// Compiled by ClojureScript 1.7.228 {}
goog.provide('figwheel.client.file_reloading');
goog.require('cljs.core');
goog.require('goog.string');
goog.require('goog.Uri');
goog.require('goog.net.jsloader');
goog.require('cljs.core.async');
goog.require('goog.object');
goog.require('clojure.set');
goog.require('clojure.string');
goog.require('figwheel.client.utils');
if(typeof figwheel.client.file_reloading.figwheel_meta_pragmas !== 'undefined'){
} else {
figwheel.client.file_reloading.figwheel_meta_pragmas = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
}
figwheel.client.file_reloading.on_jsload_custom_event = (function figwheel$client$file_reloading$on_jsload_custom_event(url){
return figwheel.client.utils.dispatch_custom_event.call(null,"figwheel.js-reload",url);
});
figwheel.client.file_reloading.before_jsload_custom_event = (function figwheel$client$file_reloading$before_jsload_custom_event(files){
return figwheel.client.utils.dispatch_custom_event.call(null,"figwheel.before-js-reload",files);
});
figwheel.client.file_reloading.namespace_file_map_QMARK_ = (function figwheel$client$file_reloading$namespace_file_map_QMARK_(m){
var or__18298__auto__ = (cljs.core.map_QMARK_.call(null,m)) && (typeof new cljs.core.Keyword(null,"namespace","namespace",-377510372).cljs$core$IFn$_invoke$arity$1(m) === 'string') && (((new cljs.core.Keyword(null,"file","file",-1269645878).cljs$core$IFn$_invoke$arity$1(m) == null)) || (typeof new cljs.core.Keyword(null,"file","file",-1269645878).cljs$core$IFn$_invoke$arity$1(m) === 'string')) && (cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"type","type",1174270348).cljs$core$IFn$_invoke$arity$1(m),new cljs.core.Keyword(null,"namespace","namespace",-377510372)));
if(or__18298__auto__){
return or__18298__auto__;
} else {
cljs.core.println.call(null,"Error not namespace-file-map",cljs.core.pr_str.call(null,m));

return false;
}
});
figwheel.client.file_reloading.add_cache_buster = (function figwheel$client$file_reloading$add_cache_buster(url){

return goog.Uri.parse(url).makeUnique();
});
figwheel.client.file_reloading.name__GT_path = (function figwheel$client$file_reloading$name__GT_path(ns){

return (goog.dependencies_.nameToPath[ns]);
});
figwheel.client.file_reloading.provided_QMARK_ = (function figwheel$client$file_reloading$provided_QMARK_(ns){
return (goog.dependencies_.written[figwheel.client.file_reloading.name__GT_path.call(null,ns)]);
});
figwheel.client.file_reloading.fix_node_request_url = (function figwheel$client$file_reloading$fix_node_request_url(url){

if(cljs.core.truth_(goog.string.startsWith(url,"../"))){
return clojure.string.replace.call(null,url,"../","");
} else {
return [cljs.core.str("goog/"),cljs.core.str(url)].join('');
}
});
figwheel.client.file_reloading.immutable_ns_QMARK_ = (function figwheel$client$file_reloading$immutable_ns_QMARK_(name){
var or__18298__auto__ = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 9, ["svgpan.SvgPan",null,"far.out",null,"testDep.bar",null,"someprotopackage.TestPackageTypes",null,"goog",null,"an.existing.path",null,"cljs.core",null,"ns",null,"dup.base",null], null), null).call(null,name);
if(cljs.core.truth_(or__18298__auto__)){
return or__18298__auto__;
} else {
return cljs.core.some.call(null,cljs.core.partial.call(null,goog.string.startsWith,name),new cljs.core.PersistentVector(null, 5, 5, cljs.core.PersistentVector.EMPTY_NODE, ["goog.","cljs.","clojure.","fake.","proto2."], null));
}
});
figwheel.client.file_reloading.get_requires = (function figwheel$client$file_reloading$get_requires(ns){
return cljs.core.set.call(null,cljs.core.filter.call(null,(function (p1__23514_SHARP_){
return cljs.core.not.call(null,figwheel.client.file_reloading.immutable_ns_QMARK_.call(null,p1__23514_SHARP_));
}),goog.object.getKeys((goog.dependencies_.requires[figwheel.client.file_reloading.name__GT_path.call(null,ns)]))));
});
if(typeof figwheel.client.file_reloading.dependency_data !== 'undefined'){
} else {
figwheel.client.file_reloading.dependency_data = cljs.core.atom.call(null,new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"pathToName","pathToName",-1236616181),cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"dependents","dependents",136812837),cljs.core.PersistentArrayMap.EMPTY], null));
}
figwheel.client.file_reloading.path_to_name_BANG_ = (function figwheel$client$file_reloading$path_to_name_BANG_(path,name){
return cljs.core.swap_BANG_.call(null,figwheel.client.file_reloading.dependency_data,cljs.core.update_in,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"pathToName","pathToName",-1236616181),path], null),cljs.core.fnil.call(null,clojure.set.union,cljs.core.PersistentHashSet.EMPTY),cljs.core.PersistentHashSet.fromArray([name], true));
});
/**
 * Setup a path to name dependencies map.
 * That goes from path -> #{ ns-names }
 */
figwheel.client.file_reloading.setup_path__GT_name_BANG_ = (function figwheel$client$file_reloading$setup_path__GT_name_BANG_(){
var nameToPath = goog.object.filter(goog.dependencies_.nameToPath,(function (v,k,o){
return goog.string.startsWith(v,"../");
}));
return goog.object.forEach(nameToPath,((function (nameToPath){
return (function (v,k,o){
return figwheel.client.file_reloading.path_to_name_BANG_.call(null,v,k);
});})(nameToPath))
);
});
/**
 * returns a set of namespaces defined by a path
 */
figwheel.client.file_reloading.path__GT_name = (function figwheel$client$file_reloading$path__GT_name(path){
return cljs.core.get_in.call(null,cljs.core.deref.call(null,figwheel.client.file_reloading.dependency_data),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"pathToName","pathToName",-1236616181),path], null));
});
figwheel.client.file_reloading.name_to_parent_BANG_ = (function figwheel$client$file_reloading$name_to_parent_BANG_(ns,parent_ns){
return cljs.core.swap_BANG_.call(null,figwheel.client.file_reloading.dependency_data,cljs.core.update_in,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"dependents","dependents",136812837),ns], null),cljs.core.fnil.call(null,clojure.set.union,cljs.core.PersistentHashSet.EMPTY),cljs.core.PersistentHashSet.fromArray([parent_ns], true));
});
/**
 * This reverses the goog.dependencies_.requires for looking up ns-dependents.
 */
figwheel.client.file_reloading.setup_ns__GT_dependents_BANG_ = (function figwheel$client$file_reloading$setup_ns__GT_dependents_BANG_(){
var requires = goog.object.filter(goog.dependencies_.requires,(function (v,k,o){
return goog.string.startsWith(k,"../");
}));
return goog.object.forEach(requires,((function (requires){
return (function (v,k,_){
return goog.object.forEach(v,((function (requires){
return (function (v_SINGLEQUOTE_,k_SINGLEQUOTE_,___$1){
var seq__23519 = cljs.core.seq.call(null,figwheel.client.file_reloading.path__GT_name.call(null,k));
var chunk__23520 = null;
var count__23521 = (0);
var i__23522 = (0);
while(true){
if((i__23522 < count__23521)){
var n = cljs.core._nth.call(null,chunk__23520,i__23522);
figwheel.client.file_reloading.name_to_parent_BANG_.call(null,k_SINGLEQUOTE_,n);

var G__23523 = seq__23519;
var G__23524 = chunk__23520;
var G__23525 = count__23521;
var G__23526 = (i__23522 + (1));
seq__23519 = G__23523;
chunk__23520 = G__23524;
count__23521 = G__23525;
i__23522 = G__23526;
continue;
} else {
var temp__4425__auto__ = cljs.core.seq.call(null,seq__23519);
if(temp__4425__auto__){
var seq__23519__$1 = temp__4425__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__23519__$1)){
var c__19101__auto__ = cljs.core.chunk_first.call(null,seq__23519__$1);
var G__23527 = cljs.core.chunk_rest.call(null,seq__23519__$1);
var G__23528 = c__19101__auto__;
var G__23529 = cljs.core.count.call(null,c__19101__auto__);
var G__23530 = (0);
seq__23519 = G__23527;
chunk__23520 = G__23528;
count__23521 = G__23529;
i__23522 = G__23530;
continue;
} else {
var n = cljs.core.first.call(null,seq__23519__$1);
figwheel.client.file_reloading.name_to_parent_BANG_.call(null,k_SINGLEQUOTE_,n);

var G__23531 = cljs.core.next.call(null,seq__23519__$1);
var G__23532 = null;
var G__23533 = (0);
var G__23534 = (0);
seq__23519 = G__23531;
chunk__23520 = G__23532;
count__23521 = G__23533;
i__23522 = G__23534;
continue;
}
} else {
return null;
}
}
break;
}
});})(requires))
);
});})(requires))
);
});
figwheel.client.file_reloading.ns__GT_dependents = (function figwheel$client$file_reloading$ns__GT_dependents(ns){
return cljs.core.get_in.call(null,cljs.core.deref.call(null,figwheel.client.file_reloading.dependency_data),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"dependents","dependents",136812837),ns], null));
});
figwheel.client.file_reloading.build_topo_sort = (function figwheel$client$file_reloading$build_topo_sort(get_deps){
var get_deps__$1 = cljs.core.memoize.call(null,get_deps);
var topo_sort_helper_STAR_ = ((function (get_deps__$1){
return (function figwheel$client$file_reloading$build_topo_sort_$_topo_sort_helper_STAR_(x,depth,state){
var deps = get_deps__$1.call(null,x);
if(cljs.core.empty_QMARK_.call(null,deps)){
return null;
} else {
return topo_sort_STAR_.call(null,deps,depth,state);
}
});})(get_deps__$1))
;
var topo_sort_STAR_ = ((function (get_deps__$1){
return (function() {
var figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR_ = null;
var figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR___1 = (function (deps){
return figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR_.call(null,deps,(0),cljs.core.atom.call(null,cljs.core.sorted_map.call(null)));
});
var figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR___3 = (function (deps,depth,state){
cljs.core.swap_BANG_.call(null,state,cljs.core.update_in,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [depth], null),cljs.core.fnil.call(null,cljs.core.into,cljs.core.PersistentHashSet.EMPTY),deps);

var seq__23573_23580 = cljs.core.seq.call(null,deps);
var chunk__23574_23581 = null;
var count__23575_23582 = (0);
var i__23576_23583 = (0);
while(true){
if((i__23576_23583 < count__23575_23582)){
var dep_23584 = cljs.core._nth.call(null,chunk__23574_23581,i__23576_23583);
topo_sort_helper_STAR_.call(null,dep_23584,(depth + (1)),state);

var G__23585 = seq__23573_23580;
var G__23586 = chunk__23574_23581;
var G__23587 = count__23575_23582;
var G__23588 = (i__23576_23583 + (1));
seq__23573_23580 = G__23585;
chunk__23574_23581 = G__23586;
count__23575_23582 = G__23587;
i__23576_23583 = G__23588;
continue;
} else {
var temp__4425__auto___23589 = cljs.core.seq.call(null,seq__23573_23580);
if(temp__4425__auto___23589){
var seq__23573_23590__$1 = temp__4425__auto___23589;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__23573_23590__$1)){
var c__19101__auto___23591 = cljs.core.chunk_first.call(null,seq__23573_23590__$1);
var G__23592 = cljs.core.chunk_rest.call(null,seq__23573_23590__$1);
var G__23593 = c__19101__auto___23591;
var G__23594 = cljs.core.count.call(null,c__19101__auto___23591);
var G__23595 = (0);
seq__23573_23580 = G__23592;
chunk__23574_23581 = G__23593;
count__23575_23582 = G__23594;
i__23576_23583 = G__23595;
continue;
} else {
var dep_23596 = cljs.core.first.call(null,seq__23573_23590__$1);
topo_sort_helper_STAR_.call(null,dep_23596,(depth + (1)),state);

var G__23597 = cljs.core.next.call(null,seq__23573_23590__$1);
var G__23598 = null;
var G__23599 = (0);
var G__23600 = (0);
seq__23573_23580 = G__23597;
chunk__23574_23581 = G__23598;
count__23575_23582 = G__23599;
i__23576_23583 = G__23600;
continue;
}
} else {
}
}
break;
}

if(cljs.core._EQ_.call(null,depth,(0))){
return elim_dups_STAR_.call(null,cljs.core.reverse.call(null,cljs.core.vals.call(null,cljs.core.deref.call(null,state))));
} else {
return null;
}
});
figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR_ = function(deps,depth,state){
switch(arguments.length){
case 1:
return figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR___1.call(this,deps);
case 3:
return figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR___3.call(this,deps,depth,state);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR_.cljs$core$IFn$_invoke$arity$1 = figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR___1;
figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR_.cljs$core$IFn$_invoke$arity$3 = figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR___3;
return figwheel$client$file_reloading$build_topo_sort_$_topo_sort_STAR_;
})()
;})(get_deps__$1))
;
var elim_dups_STAR_ = ((function (get_deps__$1){
return (function figwheel$client$file_reloading$build_topo_sort_$_elim_dups_STAR_(p__23577){
var vec__23579 = p__23577;
var x = cljs.core.nth.call(null,vec__23579,(0),null);
var xs = cljs.core.nthnext.call(null,vec__23579,(1));
if((x == null)){
return cljs.core.List.EMPTY;
} else {
return cljs.core.cons.call(null,x,figwheel$client$file_reloading$build_topo_sort_$_elim_dups_STAR_.call(null,cljs.core.map.call(null,((function (vec__23579,x,xs,get_deps__$1){
return (function (p1__23535_SHARP_){
return clojure.set.difference.call(null,p1__23535_SHARP_,x);
});})(vec__23579,x,xs,get_deps__$1))
,xs)));
}
});})(get_deps__$1))
;
return topo_sort_STAR_;
});
figwheel.client.file_reloading.get_all_dependencies = (function figwheel$client$file_reloading$get_all_dependencies(ns){
var topo_sort_SINGLEQUOTE_ = figwheel.client.file_reloading.build_topo_sort.call(null,figwheel.client.file_reloading.get_requires);
return cljs.core.apply.call(null,cljs.core.concat,topo_sort_SINGLEQUOTE_.call(null,cljs.core.set.call(null,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [ns], null))));
});
figwheel.client.file_reloading.get_all_dependents = (function figwheel$client$file_reloading$get_all_dependents(nss){
var topo_sort_SINGLEQUOTE_ = figwheel.client.file_reloading.build_topo_sort.call(null,figwheel.client.file_reloading.ns__GT_dependents);
return cljs.core.reverse.call(null,cljs.core.apply.call(null,cljs.core.concat,topo_sort_SINGLEQUOTE_.call(null,cljs.core.set.call(null,nss))));
});
figwheel.client.file_reloading.unprovide_BANG_ = (function figwheel$client$file_reloading$unprovide_BANG_(ns){
var path = figwheel.client.file_reloading.name__GT_path.call(null,ns);
goog.object.remove(goog.dependencies_.visited,path);

goog.object.remove(goog.dependencies_.written,path);

return goog.object.remove(goog.dependencies_.written,[cljs.core.str(goog.basePath),cljs.core.str(path)].join(''));
});
figwheel.client.file_reloading.resolve_ns = (function figwheel$client$file_reloading$resolve_ns(ns){
return [cljs.core.str(goog.basePath),cljs.core.str(figwheel.client.file_reloading.name__GT_path.call(null,ns))].join('');
});
figwheel.client.file_reloading.addDependency = (function figwheel$client$file_reloading$addDependency(path,provides,requires){
var seq__23613 = cljs.core.seq.call(null,provides);
var chunk__23614 = null;
var count__23615 = (0);
var i__23616 = (0);
while(true){
if((i__23616 < count__23615)){
var prov = cljs.core._nth.call(null,chunk__23614,i__23616);
figwheel.client.file_reloading.path_to_name_BANG_.call(null,path,prov);

var seq__23617_23625 = cljs.core.seq.call(null,requires);
var chunk__23618_23626 = null;
var count__23619_23627 = (0);
var i__23620_23628 = (0);
while(true){
if((i__23620_23628 < count__23619_23627)){
var req_23629 = cljs.core._nth.call(null,chunk__23618_23626,i__23620_23628);
figwheel.client.file_reloading.name_to_parent_BANG_.call(null,req_23629,prov);

var G__23630 = seq__23617_23625;
var G__23631 = chunk__23618_23626;
var G__23632 = count__23619_23627;
var G__23633 = (i__23620_23628 + (1));
seq__23617_23625 = G__23630;
chunk__23618_23626 = G__23631;
count__23619_23627 = G__23632;
i__23620_23628 = G__23633;
continue;
} else {
var temp__4425__auto___23634 = cljs.core.seq.call(null,seq__23617_23625);
if(temp__4425__auto___23634){
var seq__23617_23635__$1 = temp__4425__auto___23634;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__23617_23635__$1)){
var c__19101__auto___23636 = cljs.core.chunk_first.call(null,seq__23617_23635__$1);
var G__23637 = cljs.core.chunk_rest.call(null,seq__23617_23635__$1);
var G__23638 = c__19101__auto___23636;
var G__23639 = cljs.core.count.call(null,c__19101__auto___23636);
var G__23640 = (0);
seq__23617_23625 = G__23637;
chunk__23618_23626 = G__23638;
count__23619_23627 = G__23639;
i__23620_23628 = G__23640;
continue;
} else {
var req_23641 = cljs.core.first.call(null,seq__23617_23635__$1);
figwheel.client.file_reloading.name_to_parent_BANG_.call(null,req_23641,prov);

var G__23642 = cljs.core.next.call(null,seq__23617_23635__$1);
var G__23643 = null;
var G__23644 = (0);
var G__23645 = (0);
seq__23617_23625 = G__23642;
chunk__23618_23626 = G__23643;
count__23619_23627 = G__23644;
i__23620_23628 = G__23645;
continue;
}
} else {
}
}
break;
}

var G__23646 = seq__23613;
var G__23647 = chunk__23614;
var G__23648 = count__23615;
var G__23649 = (i__23616 + (1));
seq__23613 = G__23646;
chunk__23614 = G__23647;
count__23615 = G__23648;
i__23616 = G__23649;
continue;
} else {
var temp__4425__auto__ = cljs.core.seq.call(null,seq__23613);
if(temp__4425__auto__){
var seq__23613__$1 = temp__4425__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__23613__$1)){
var c__19101__auto__ = cljs.core.chunk_first.call(null,seq__23613__$1);
var G__23650 = cljs.core.chunk_rest.call(null,seq__23613__$1);
var G__23651 = c__19101__auto__;
var G__23652 = cljs.core.count.call(null,c__19101__auto__);
var G__23653 = (0);
seq__23613 = G__23650;
chunk__23614 = G__23651;
count__23615 = G__23652;
i__23616 = G__23653;
continue;
} else {
var prov = cljs.core.first.call(null,seq__23613__$1);
figwheel.client.file_reloading.path_to_name_BANG_.call(null,path,prov);

var seq__23621_23654 = cljs.core.seq.call(null,requires);
var chunk__23622_23655 = null;
var count__23623_23656 = (0);
var i__23624_23657 = (0);
while(true){
if((i__23624_23657 < count__23623_23656)){
var req_23658 = cljs.core._nth.call(null,chunk__23622_23655,i__23624_23657);
figwheel.client.file_reloading.name_to_parent_BANG_.call(null,req_23658,prov);

var G__23659 = seq__23621_23654;
var G__23660 = chunk__23622_23655;
var G__23661 = count__23623_23656;
var G__23662 = (i__23624_23657 + (1));
seq__23621_23654 = G__23659;
chunk__23622_23655 = G__23660;
count__23623_23656 = G__23661;
i__23624_23657 = G__23662;
continue;
} else {
var temp__4425__auto___23663__$1 = cljs.core.seq.call(null,seq__23621_23654);
if(temp__4425__auto___23663__$1){
var seq__23621_23664__$1 = temp__4425__auto___23663__$1;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__23621_23664__$1)){
var c__19101__auto___23665 = cljs.core.chunk_first.call(null,seq__23621_23664__$1);
var G__23666 = cljs.core.chunk_rest.call(null,seq__23621_23664__$1);
var G__23667 = c__19101__auto___23665;
var G__23668 = cljs.core.count.call(null,c__19101__auto___23665);
var G__23669 = (0);
seq__23621_23654 = G__23666;
chunk__23622_23655 = G__23667;
count__23623_23656 = G__23668;
i__23624_23657 = G__23669;
continue;
} else {
var req_23670 = cljs.core.first.call(null,seq__23621_23664__$1);
figwheel.client.file_reloading.name_to_parent_BANG_.call(null,req_23670,prov);

var G__23671 = cljs.core.next.call(null,seq__23621_23664__$1);
var G__23672 = null;
var G__23673 = (0);
var G__23674 = (0);
seq__23621_23654 = G__23671;
chunk__23622_23655 = G__23672;
count__23623_23656 = G__23673;
i__23624_23657 = G__23674;
continue;
}
} else {
}
}
break;
}

var G__23675 = cljs.core.next.call(null,seq__23613__$1);
var G__23676 = null;
var G__23677 = (0);
var G__23678 = (0);
seq__23613 = G__23675;
chunk__23614 = G__23676;
count__23615 = G__23677;
i__23616 = G__23678;
continue;
}
} else {
return null;
}
}
break;
}
});
figwheel.client.file_reloading.figwheel_require = (function figwheel$client$file_reloading$figwheel_require(src,reload){
goog.require = figwheel$client$file_reloading$figwheel_require;

if(cljs.core._EQ_.call(null,reload,"reload-all")){
var seq__23683_23687 = cljs.core.seq.call(null,figwheel.client.file_reloading.get_all_dependencies.call(null,src));
var chunk__23684_23688 = null;
var count__23685_23689 = (0);
var i__23686_23690 = (0);
while(true){
if((i__23686_23690 < count__23685_23689)){
var ns_23691 = cljs.core._nth.call(null,chunk__23684_23688,i__23686_23690);
figwheel.client.file_reloading.unprovide_BANG_.call(null,ns_23691);

var G__23692 = seq__23683_23687;
var G__23693 = chunk__23684_23688;
var G__23694 = count__23685_23689;
var G__23695 = (i__23686_23690 + (1));
seq__23683_23687 = G__23692;
chunk__23684_23688 = G__23693;
count__23685_23689 = G__23694;
i__23686_23690 = G__23695;
continue;
} else {
var temp__4425__auto___23696 = cljs.core.seq.call(null,seq__23683_23687);
if(temp__4425__auto___23696){
var seq__23683_23697__$1 = temp__4425__auto___23696;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__23683_23697__$1)){
var c__19101__auto___23698 = cljs.core.chunk_first.call(null,seq__23683_23697__$1);
var G__23699 = cljs.core.chunk_rest.call(null,seq__23683_23697__$1);
var G__23700 = c__19101__auto___23698;
var G__23701 = cljs.core.count.call(null,c__19101__auto___23698);
var G__23702 = (0);
seq__23683_23687 = G__23699;
chunk__23684_23688 = G__23700;
count__23685_23689 = G__23701;
i__23686_23690 = G__23702;
continue;
} else {
var ns_23703 = cljs.core.first.call(null,seq__23683_23697__$1);
figwheel.client.file_reloading.unprovide_BANG_.call(null,ns_23703);

var G__23704 = cljs.core.next.call(null,seq__23683_23697__$1);
var G__23705 = null;
var G__23706 = (0);
var G__23707 = (0);
seq__23683_23687 = G__23704;
chunk__23684_23688 = G__23705;
count__23685_23689 = G__23706;
i__23686_23690 = G__23707;
continue;
}
} else {
}
}
break;
}
} else {
}

if(cljs.core.truth_(reload)){
figwheel.client.file_reloading.unprovide_BANG_.call(null,src);
} else {
}

return goog.require_figwheel_backup_(src);
});
/**
 * Reusable browser REPL bootstrapping. Patches the essential functions
 *   in goog.base to support re-loading of namespaces after page load.
 */
figwheel.client.file_reloading.bootstrap_goog_base = (function figwheel$client$file_reloading$bootstrap_goog_base(){
if(cljs.core.truth_(COMPILED)){
return null;
} else {
goog.require_figwheel_backup_ = (function (){var or__18298__auto__ = goog.require__;
if(cljs.core.truth_(or__18298__auto__)){
return or__18298__auto__;
} else {
return goog.require;
}
})();

goog.isProvided_ = (function (name){
return false;
});

figwheel.client.file_reloading.setup_path__GT_name_BANG_.call(null);

figwheel.client.file_reloading.setup_ns__GT_dependents_BANG_.call(null);

goog.addDependency_figwheel_backup_ = goog.addDependency;

goog.addDependency = (function() { 
var G__23708__delegate = function (args){
cljs.core.apply.call(null,figwheel.client.file_reloading.addDependency,args);

return cljs.core.apply.call(null,goog.addDependency_figwheel_backup_,args);
};
var G__23708 = function (var_args){
var args = null;
if (arguments.length > 0) {
var G__23709__i = 0, G__23709__a = new Array(arguments.length -  0);
while (G__23709__i < G__23709__a.length) {G__23709__a[G__23709__i] = arguments[G__23709__i + 0]; ++G__23709__i;}
  args = new cljs.core.IndexedSeq(G__23709__a,0);
} 
return G__23708__delegate.call(this,args);};
G__23708.cljs$lang$maxFixedArity = 0;
G__23708.cljs$lang$applyTo = (function (arglist__23710){
var args = cljs.core.seq(arglist__23710);
return G__23708__delegate(args);
});
G__23708.cljs$core$IFn$_invoke$arity$variadic = G__23708__delegate;
return G__23708;
})()
;

goog.constructNamespace_("cljs.user");

goog.global.CLOSURE_IMPORT_SCRIPT = figwheel.client.file_reloading.queued_file_reload;

return goog.require = figwheel.client.file_reloading.figwheel_require;
}
});
figwheel.client.file_reloading.patch_goog_base = (function figwheel$client$file_reloading$patch_goog_base(){
if(typeof figwheel.client.file_reloading.bootstrapped_cljs !== 'undefined'){
return null;
} else {
figwheel.client.file_reloading.bootstrapped_cljs = (function (){
figwheel.client.file_reloading.bootstrap_goog_base.call(null);

return true;
})()
;
}
});
figwheel.client.file_reloading.reload_file_STAR_ = (function (){var pred__23712 = cljs.core._EQ_;
var expr__23713 = figwheel.client.utils.host_env_QMARK_.call(null);
if(cljs.core.truth_(pred__23712.call(null,new cljs.core.Keyword(null,"node","node",581201198),expr__23713))){
var path_parts = ((function (pred__23712,expr__23713){
return (function (p1__23711_SHARP_){
return clojure.string.split.call(null,p1__23711_SHARP_,/[\/\\]/);
});})(pred__23712,expr__23713))
;
var sep = (cljs.core.truth_(cljs.core.re_matches.call(null,/win.*/,process.platform))?"\\":"/");
var root = clojure.string.join.call(null,sep,cljs.core.pop.call(null,cljs.core.pop.call(null,path_parts.call(null,__dirname))));
return ((function (path_parts,sep,root,pred__23712,expr__23713){
return (function (request_url,callback){

var cache_path = clojure.string.join.call(null,sep,cljs.core.cons.call(null,root,path_parts.call(null,figwheel.client.file_reloading.fix_node_request_url.call(null,request_url))));
(require.cache[cache_path] = null);

return callback.call(null,(function (){try{return require(cache_path);
}catch (e23715){if((e23715 instanceof Error)){
var e = e23715;
figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"error","error",-978969032),[cljs.core.str("Figwheel: Error loading file "),cljs.core.str(cache_path)].join(''));

figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"error","error",-978969032),e.stack);

return false;
} else {
throw e23715;

}
}})());
});
;})(path_parts,sep,root,pred__23712,expr__23713))
} else {
if(cljs.core.truth_(pred__23712.call(null,new cljs.core.Keyword(null,"html","html",-998796897),expr__23713))){
return ((function (pred__23712,expr__23713){
return (function (request_url,callback){

var deferred = goog.net.jsloader.load(figwheel.client.file_reloading.add_cache_buster.call(null,request_url),{"cleanupWhenDone": true});
deferred.addCallback(((function (deferred,pred__23712,expr__23713){
return (function (){
return cljs.core.apply.call(null,callback,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [true], null));
});})(deferred,pred__23712,expr__23713))
);

return deferred.addErrback(((function (deferred,pred__23712,expr__23713){
return (function (){
return cljs.core.apply.call(null,callback,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [false], null));
});})(deferred,pred__23712,expr__23713))
);
});
;})(pred__23712,expr__23713))
} else {
return ((function (pred__23712,expr__23713){
return (function (a,b){
throw "Reload not defined for this platform";
});
;})(pred__23712,expr__23713))
}
}
})();
figwheel.client.file_reloading.reload_file = (function figwheel$client$file_reloading$reload_file(p__23716,callback){
var map__23719 = p__23716;
var map__23719__$1 = ((((!((map__23719 == null)))?((((map__23719.cljs$lang$protocol_mask$partition0$ & (64))) || (map__23719.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__23719):map__23719);
var file_msg = map__23719__$1;
var request_url = cljs.core.get.call(null,map__23719__$1,new cljs.core.Keyword(null,"request-url","request-url",2100346596));

figwheel.client.utils.debug_prn.call(null,[cljs.core.str("FigWheel: Attempting to load "),cljs.core.str(request_url)].join(''));

return figwheel.client.file_reloading.reload_file_STAR_.call(null,request_url,((function (map__23719,map__23719__$1,file_msg,request_url){
return (function (success_QMARK_){
if(cljs.core.truth_(success_QMARK_)){
figwheel.client.utils.debug_prn.call(null,[cljs.core.str("FigWheel: Successfully loaded "),cljs.core.str(request_url)].join(''));

return cljs.core.apply.call(null,callback,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.assoc.call(null,file_msg,new cljs.core.Keyword(null,"loaded-file","loaded-file",-168399375),true)], null));
} else {
figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"error","error",-978969032),[cljs.core.str("Figwheel: Error loading file "),cljs.core.str(request_url)].join(''));

return cljs.core.apply.call(null,callback,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [file_msg], null));
}
});})(map__23719,map__23719__$1,file_msg,request_url))
);
});
if(typeof figwheel.client.file_reloading.reload_chan !== 'undefined'){
} else {
figwheel.client.file_reloading.reload_chan = cljs.core.async.chan.call(null);
}
if(typeof figwheel.client.file_reloading.on_load_callbacks !== 'undefined'){
} else {
figwheel.client.file_reloading.on_load_callbacks = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
}
if(typeof figwheel.client.file_reloading.dependencies_loaded !== 'undefined'){
} else {
figwheel.client.file_reloading.dependencies_loaded = cljs.core.atom.call(null,cljs.core.PersistentVector.EMPTY);
}
figwheel.client.file_reloading.blocking_load = (function figwheel$client$file_reloading$blocking_load(url){
var out = cljs.core.async.chan.call(null);
figwheel.client.file_reloading.reload_file.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"request-url","request-url",2100346596),url], null),((function (out){
return (function (file_msg){
cljs.core.async.put_BANG_.call(null,out,file_msg);

return cljs.core.async.close_BANG_.call(null,out);
});})(out))
);

return out;
});
if(typeof figwheel.client.file_reloading.reloader_loop !== 'undefined'){
} else {
figwheel.client.file_reloading.reloader_loop = (function (){var c__20620__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto__){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto__){
return (function (state_23743){
var state_val_23744 = (state_23743[(1)]);
if((state_val_23744 === (7))){
var inst_23739 = (state_23743[(2)]);
var state_23743__$1 = state_23743;
var statearr_23745_23765 = state_23743__$1;
(statearr_23745_23765[(2)] = inst_23739);

(statearr_23745_23765[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23744 === (1))){
var state_23743__$1 = state_23743;
var statearr_23746_23766 = state_23743__$1;
(statearr_23746_23766[(2)] = null);

(statearr_23746_23766[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23744 === (4))){
var inst_23723 = (state_23743[(7)]);
var inst_23723__$1 = (state_23743[(2)]);
var state_23743__$1 = (function (){var statearr_23747 = state_23743;
(statearr_23747[(7)] = inst_23723__$1);

return statearr_23747;
})();
if(cljs.core.truth_(inst_23723__$1)){
var statearr_23748_23767 = state_23743__$1;
(statearr_23748_23767[(1)] = (5));

} else {
var statearr_23749_23768 = state_23743__$1;
(statearr_23749_23768[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23744 === (6))){
var state_23743__$1 = state_23743;
var statearr_23750_23769 = state_23743__$1;
(statearr_23750_23769[(2)] = null);

(statearr_23750_23769[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23744 === (3))){
var inst_23741 = (state_23743[(2)]);
var state_23743__$1 = state_23743;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_23743__$1,inst_23741);
} else {
if((state_val_23744 === (2))){
var state_23743__$1 = state_23743;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_23743__$1,(4),figwheel.client.file_reloading.reload_chan);
} else {
if((state_val_23744 === (11))){
var inst_23735 = (state_23743[(2)]);
var state_23743__$1 = (function (){var statearr_23751 = state_23743;
(statearr_23751[(8)] = inst_23735);

return statearr_23751;
})();
var statearr_23752_23770 = state_23743__$1;
(statearr_23752_23770[(2)] = null);

(statearr_23752_23770[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23744 === (9))){
var inst_23729 = (state_23743[(9)]);
var inst_23727 = (state_23743[(10)]);
var inst_23731 = inst_23729.call(null,inst_23727);
var state_23743__$1 = state_23743;
var statearr_23753_23771 = state_23743__$1;
(statearr_23753_23771[(2)] = inst_23731);

(statearr_23753_23771[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23744 === (5))){
var inst_23723 = (state_23743[(7)]);
var inst_23725 = figwheel.client.file_reloading.blocking_load.call(null,inst_23723);
var state_23743__$1 = state_23743;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_23743__$1,(8),inst_23725);
} else {
if((state_val_23744 === (10))){
var inst_23727 = (state_23743[(10)]);
var inst_23733 = cljs.core.swap_BANG_.call(null,figwheel.client.file_reloading.dependencies_loaded,cljs.core.conj,inst_23727);
var state_23743__$1 = state_23743;
var statearr_23754_23772 = state_23743__$1;
(statearr_23754_23772[(2)] = inst_23733);

(statearr_23754_23772[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23744 === (8))){
var inst_23729 = (state_23743[(9)]);
var inst_23723 = (state_23743[(7)]);
var inst_23727 = (state_23743[(2)]);
var inst_23728 = cljs.core.deref.call(null,figwheel.client.file_reloading.on_load_callbacks);
var inst_23729__$1 = cljs.core.get.call(null,inst_23728,inst_23723);
var state_23743__$1 = (function (){var statearr_23755 = state_23743;
(statearr_23755[(9)] = inst_23729__$1);

(statearr_23755[(10)] = inst_23727);

return statearr_23755;
})();
if(cljs.core.truth_(inst_23729__$1)){
var statearr_23756_23773 = state_23743__$1;
(statearr_23756_23773[(1)] = (9));

} else {
var statearr_23757_23774 = state_23743__$1;
(statearr_23757_23774[(1)] = (10));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto__))
;
return ((function (switch__20508__auto__,c__20620__auto__){
return (function() {
var figwheel$client$file_reloading$state_machine__20509__auto__ = null;
var figwheel$client$file_reloading$state_machine__20509__auto____0 = (function (){
var statearr_23761 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_23761[(0)] = figwheel$client$file_reloading$state_machine__20509__auto__);

(statearr_23761[(1)] = (1));

return statearr_23761;
});
var figwheel$client$file_reloading$state_machine__20509__auto____1 = (function (state_23743){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_23743);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e23762){if((e23762 instanceof Object)){
var ex__20512__auto__ = e23762;
var statearr_23763_23775 = state_23743;
(statearr_23763_23775[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_23743);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e23762;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__23776 = state_23743;
state_23743 = G__23776;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
figwheel$client$file_reloading$state_machine__20509__auto__ = function(state_23743){
switch(arguments.length){
case 0:
return figwheel$client$file_reloading$state_machine__20509__auto____0.call(this);
case 1:
return figwheel$client$file_reloading$state_machine__20509__auto____1.call(this,state_23743);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$file_reloading$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = figwheel$client$file_reloading$state_machine__20509__auto____0;
figwheel$client$file_reloading$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = figwheel$client$file_reloading$state_machine__20509__auto____1;
return figwheel$client$file_reloading$state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto__))
})();
var state__20622__auto__ = (function (){var statearr_23764 = f__20621__auto__.call(null);
(statearr_23764[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto__);

return statearr_23764;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto__))
);

return c__20620__auto__;
})();
}
figwheel.client.file_reloading.queued_file_reload = (function figwheel$client$file_reloading$queued_file_reload(url){
return cljs.core.async.put_BANG_.call(null,figwheel.client.file_reloading.reload_chan,url);
});
figwheel.client.file_reloading.require_with_callback = (function figwheel$client$file_reloading$require_with_callback(p__23777,callback){
var map__23780 = p__23777;
var map__23780__$1 = ((((!((map__23780 == null)))?((((map__23780.cljs$lang$protocol_mask$partition0$ & (64))) || (map__23780.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__23780):map__23780);
var file_msg = map__23780__$1;
var namespace = cljs.core.get.call(null,map__23780__$1,new cljs.core.Keyword(null,"namespace","namespace",-377510372));
var request_url = figwheel.client.file_reloading.resolve_ns.call(null,namespace);
cljs.core.swap_BANG_.call(null,figwheel.client.file_reloading.on_load_callbacks,cljs.core.assoc,request_url,((function (request_url,map__23780,map__23780__$1,file_msg,namespace){
return (function (file_msg_SINGLEQUOTE_){
cljs.core.swap_BANG_.call(null,figwheel.client.file_reloading.on_load_callbacks,cljs.core.dissoc,request_url);

return cljs.core.apply.call(null,callback,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.merge.call(null,file_msg,cljs.core.select_keys.call(null,file_msg_SINGLEQUOTE_,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"loaded-file","loaded-file",-168399375)], null)))], null));
});})(request_url,map__23780,map__23780__$1,file_msg,namespace))
);

return figwheel.client.file_reloading.figwheel_require.call(null,cljs.core.name.call(null,namespace),true);
});
figwheel.client.file_reloading.reload_file_QMARK_ = (function figwheel$client$file_reloading$reload_file_QMARK_(p__23782){
var map__23785 = p__23782;
var map__23785__$1 = ((((!((map__23785 == null)))?((((map__23785.cljs$lang$protocol_mask$partition0$ & (64))) || (map__23785.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__23785):map__23785);
var file_msg = map__23785__$1;
var namespace = cljs.core.get.call(null,map__23785__$1,new cljs.core.Keyword(null,"namespace","namespace",-377510372));

var meta_pragmas = cljs.core.get.call(null,cljs.core.deref.call(null,figwheel.client.file_reloading.figwheel_meta_pragmas),cljs.core.name.call(null,namespace));
var and__18286__auto__ = cljs.core.not.call(null,new cljs.core.Keyword(null,"figwheel-no-load","figwheel-no-load",-555840179).cljs$core$IFn$_invoke$arity$1(meta_pragmas));
if(and__18286__auto__){
var or__18298__auto__ = new cljs.core.Keyword(null,"figwheel-always","figwheel-always",799819691).cljs$core$IFn$_invoke$arity$1(meta_pragmas);
if(cljs.core.truth_(or__18298__auto__)){
return or__18298__auto__;
} else {
var or__18298__auto____$1 = new cljs.core.Keyword(null,"figwheel-load","figwheel-load",1316089175).cljs$core$IFn$_invoke$arity$1(meta_pragmas);
if(cljs.core.truth_(or__18298__auto____$1)){
return or__18298__auto____$1;
} else {
return figwheel.client.file_reloading.provided_QMARK_.call(null,cljs.core.name.call(null,namespace));
}
}
} else {
return and__18286__auto__;
}
});
figwheel.client.file_reloading.js_reload = (function figwheel$client$file_reloading$js_reload(p__23787,callback){
var map__23790 = p__23787;
var map__23790__$1 = ((((!((map__23790 == null)))?((((map__23790.cljs$lang$protocol_mask$partition0$ & (64))) || (map__23790.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__23790):map__23790);
var file_msg = map__23790__$1;
var request_url = cljs.core.get.call(null,map__23790__$1,new cljs.core.Keyword(null,"request-url","request-url",2100346596));
var namespace = cljs.core.get.call(null,map__23790__$1,new cljs.core.Keyword(null,"namespace","namespace",-377510372));

if(cljs.core.truth_(figwheel.client.file_reloading.reload_file_QMARK_.call(null,file_msg))){
return figwheel.client.file_reloading.require_with_callback.call(null,file_msg,callback);
} else {
figwheel.client.utils.debug_prn.call(null,[cljs.core.str("Figwheel: Not trying to load file "),cljs.core.str(request_url)].join(''));

return cljs.core.apply.call(null,callback,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [file_msg], null));
}
});
figwheel.client.file_reloading.reload_js_file = (function figwheel$client$file_reloading$reload_js_file(file_msg){
var out = cljs.core.async.chan.call(null);
figwheel.client.file_reloading.js_reload.call(null,file_msg,((function (out){
return (function (url){
cljs.core.async.put_BANG_.call(null,out,url);

return cljs.core.async.close_BANG_.call(null,out);
});})(out))
);

return out;
});
/**
 * Returns a chanel with one collection of loaded filenames on it.
 */
figwheel.client.file_reloading.load_all_js_files = (function figwheel$client$file_reloading$load_all_js_files(files){
var out = cljs.core.async.chan.call(null);
var c__20620__auto___23878 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___23878,out){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___23878,out){
return (function (state_23860){
var state_val_23861 = (state_23860[(1)]);
if((state_val_23861 === (1))){
var inst_23838 = cljs.core.nth.call(null,files,(0),null);
var inst_23839 = cljs.core.nthnext.call(null,files,(1));
var inst_23840 = files;
var state_23860__$1 = (function (){var statearr_23862 = state_23860;
(statearr_23862[(7)] = inst_23839);

(statearr_23862[(8)] = inst_23840);

(statearr_23862[(9)] = inst_23838);

return statearr_23862;
})();
var statearr_23863_23879 = state_23860__$1;
(statearr_23863_23879[(2)] = null);

(statearr_23863_23879[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23861 === (2))){
var inst_23840 = (state_23860[(8)]);
var inst_23843 = (state_23860[(10)]);
var inst_23843__$1 = cljs.core.nth.call(null,inst_23840,(0),null);
var inst_23844 = cljs.core.nthnext.call(null,inst_23840,(1));
var inst_23845 = (inst_23843__$1 == null);
var inst_23846 = cljs.core.not.call(null,inst_23845);
var state_23860__$1 = (function (){var statearr_23864 = state_23860;
(statearr_23864[(10)] = inst_23843__$1);

(statearr_23864[(11)] = inst_23844);

return statearr_23864;
})();
if(inst_23846){
var statearr_23865_23880 = state_23860__$1;
(statearr_23865_23880[(1)] = (4));

} else {
var statearr_23866_23881 = state_23860__$1;
(statearr_23866_23881[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23861 === (3))){
var inst_23858 = (state_23860[(2)]);
var state_23860__$1 = state_23860;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_23860__$1,inst_23858);
} else {
if((state_val_23861 === (4))){
var inst_23843 = (state_23860[(10)]);
var inst_23848 = figwheel.client.file_reloading.reload_js_file.call(null,inst_23843);
var state_23860__$1 = state_23860;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_23860__$1,(7),inst_23848);
} else {
if((state_val_23861 === (5))){
var inst_23854 = cljs.core.async.close_BANG_.call(null,out);
var state_23860__$1 = state_23860;
var statearr_23867_23882 = state_23860__$1;
(statearr_23867_23882[(2)] = inst_23854);

(statearr_23867_23882[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23861 === (6))){
var inst_23856 = (state_23860[(2)]);
var state_23860__$1 = state_23860;
var statearr_23868_23883 = state_23860__$1;
(statearr_23868_23883[(2)] = inst_23856);

(statearr_23868_23883[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23861 === (7))){
var inst_23844 = (state_23860[(11)]);
var inst_23850 = (state_23860[(2)]);
var inst_23851 = cljs.core.async.put_BANG_.call(null,out,inst_23850);
var inst_23840 = inst_23844;
var state_23860__$1 = (function (){var statearr_23869 = state_23860;
(statearr_23869[(12)] = inst_23851);

(statearr_23869[(8)] = inst_23840);

return statearr_23869;
})();
var statearr_23870_23884 = state_23860__$1;
(statearr_23870_23884[(2)] = null);

(statearr_23870_23884[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});})(c__20620__auto___23878,out))
;
return ((function (switch__20508__auto__,c__20620__auto___23878,out){
return (function() {
var figwheel$client$file_reloading$load_all_js_files_$_state_machine__20509__auto__ = null;
var figwheel$client$file_reloading$load_all_js_files_$_state_machine__20509__auto____0 = (function (){
var statearr_23874 = [null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_23874[(0)] = figwheel$client$file_reloading$load_all_js_files_$_state_machine__20509__auto__);

(statearr_23874[(1)] = (1));

return statearr_23874;
});
var figwheel$client$file_reloading$load_all_js_files_$_state_machine__20509__auto____1 = (function (state_23860){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_23860);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e23875){if((e23875 instanceof Object)){
var ex__20512__auto__ = e23875;
var statearr_23876_23885 = state_23860;
(statearr_23876_23885[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_23860);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e23875;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__23886 = state_23860;
state_23860 = G__23886;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
figwheel$client$file_reloading$load_all_js_files_$_state_machine__20509__auto__ = function(state_23860){
switch(arguments.length){
case 0:
return figwheel$client$file_reloading$load_all_js_files_$_state_machine__20509__auto____0.call(this);
case 1:
return figwheel$client$file_reloading$load_all_js_files_$_state_machine__20509__auto____1.call(this,state_23860);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$file_reloading$load_all_js_files_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = figwheel$client$file_reloading$load_all_js_files_$_state_machine__20509__auto____0;
figwheel$client$file_reloading$load_all_js_files_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = figwheel$client$file_reloading$load_all_js_files_$_state_machine__20509__auto____1;
return figwheel$client$file_reloading$load_all_js_files_$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___23878,out))
})();
var state__20622__auto__ = (function (){var statearr_23877 = f__20621__auto__.call(null);
(statearr_23877[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___23878);

return statearr_23877;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___23878,out))
);


return cljs.core.async.into.call(null,cljs.core.PersistentVector.EMPTY,out);
});
figwheel.client.file_reloading.eval_body = (function figwheel$client$file_reloading$eval_body(p__23887,opts){
var map__23891 = p__23887;
var map__23891__$1 = ((((!((map__23891 == null)))?((((map__23891.cljs$lang$protocol_mask$partition0$ & (64))) || (map__23891.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__23891):map__23891);
var eval_body__$1 = cljs.core.get.call(null,map__23891__$1,new cljs.core.Keyword(null,"eval-body","eval-body",-907279883));
var file = cljs.core.get.call(null,map__23891__$1,new cljs.core.Keyword(null,"file","file",-1269645878));
if(cljs.core.truth_((function (){var and__18286__auto__ = eval_body__$1;
if(cljs.core.truth_(and__18286__auto__)){
return typeof eval_body__$1 === 'string';
} else {
return and__18286__auto__;
}
})())){
var code = eval_body__$1;
try{figwheel.client.utils.debug_prn.call(null,[cljs.core.str("Evaling file "),cljs.core.str(file)].join(''));

return figwheel.client.utils.eval_helper.call(null,code,opts);
}catch (e23893){var e = e23893;
return figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"error","error",-978969032),[cljs.core.str("Unable to evaluate "),cljs.core.str(file)].join(''));
}} else {
return null;
}
});
figwheel.client.file_reloading.expand_files = (function figwheel$client$file_reloading$expand_files(files){
var deps = figwheel.client.file_reloading.get_all_dependents.call(null,cljs.core.map.call(null,new cljs.core.Keyword(null,"namespace","namespace",-377510372),files));
return cljs.core.filter.call(null,cljs.core.comp.call(null,cljs.core.not,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 1, ["figwheel.connect",null], null), null),new cljs.core.Keyword(null,"namespace","namespace",-377510372)),cljs.core.map.call(null,((function (deps){
return (function (n){
var temp__4423__auto__ = cljs.core.first.call(null,cljs.core.filter.call(null,((function (deps){
return (function (p1__23894_SHARP_){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"namespace","namespace",-377510372).cljs$core$IFn$_invoke$arity$1(p1__23894_SHARP_),n);
});})(deps))
,files));
if(cljs.core.truth_(temp__4423__auto__)){
var file_msg = temp__4423__auto__;
return file_msg;
} else {
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"namespace","namespace",-377510372),new cljs.core.Keyword(null,"namespace","namespace",-377510372),n], null);
}
});})(deps))
,deps));
});
figwheel.client.file_reloading.sort_files = (function figwheel$client$file_reloading$sort_files(files){
if((cljs.core.count.call(null,files) <= (1))){
return files;
} else {
var keep_files = cljs.core.set.call(null,cljs.core.keep.call(null,new cljs.core.Keyword(null,"namespace","namespace",-377510372),files));
return cljs.core.filter.call(null,cljs.core.comp.call(null,keep_files,new cljs.core.Keyword(null,"namespace","namespace",-377510372)),figwheel.client.file_reloading.expand_files.call(null,files));
}
});
figwheel.client.file_reloading.get_figwheel_always = (function figwheel$client$file_reloading$get_figwheel_always(){
return cljs.core.map.call(null,(function (p__23899){
var vec__23900 = p__23899;
var k = cljs.core.nth.call(null,vec__23900,(0),null);
var v = cljs.core.nth.call(null,vec__23900,(1),null);
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"namespace","namespace",-377510372),k,new cljs.core.Keyword(null,"type","type",1174270348),new cljs.core.Keyword(null,"namespace","namespace",-377510372)], null);
}),cljs.core.filter.call(null,(function (p__23901){
var vec__23902 = p__23901;
var k = cljs.core.nth.call(null,vec__23902,(0),null);
var v = cljs.core.nth.call(null,vec__23902,(1),null);
return new cljs.core.Keyword(null,"figwheel-always","figwheel-always",799819691).cljs$core$IFn$_invoke$arity$1(v);
}),cljs.core.deref.call(null,figwheel.client.file_reloading.figwheel_meta_pragmas)));
});
figwheel.client.file_reloading.reload_js_files = (function figwheel$client$file_reloading$reload_js_files(p__23906,p__23907){
var map__24154 = p__23906;
var map__24154__$1 = ((((!((map__24154 == null)))?((((map__24154.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24154.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24154):map__24154);
var opts = map__24154__$1;
var before_jsload = cljs.core.get.call(null,map__24154__$1,new cljs.core.Keyword(null,"before-jsload","before-jsload",-847513128));
var on_jsload = cljs.core.get.call(null,map__24154__$1,new cljs.core.Keyword(null,"on-jsload","on-jsload",-395756602));
var reload_dependents = cljs.core.get.call(null,map__24154__$1,new cljs.core.Keyword(null,"reload-dependents","reload-dependents",-956865430));
var map__24155 = p__23907;
var map__24155__$1 = ((((!((map__24155 == null)))?((((map__24155.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24155.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24155):map__24155);
var msg = map__24155__$1;
var files = cljs.core.get.call(null,map__24155__$1,new cljs.core.Keyword(null,"files","files",-472457450));
var figwheel_meta = cljs.core.get.call(null,map__24155__$1,new cljs.core.Keyword(null,"figwheel-meta","figwheel-meta",-225970237));
var recompile_dependents = cljs.core.get.call(null,map__24155__$1,new cljs.core.Keyword(null,"recompile-dependents","recompile-dependents",523804171));
if(cljs.core.empty_QMARK_.call(null,figwheel_meta)){
} else {
cljs.core.reset_BANG_.call(null,figwheel.client.file_reloading.figwheel_meta_pragmas,figwheel_meta);
}

var c__20620__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (state_24308){
var state_val_24309 = (state_24308[(1)]);
if((state_val_24309 === (7))){
var inst_24171 = (state_24308[(7)]);
var inst_24169 = (state_24308[(8)]);
var inst_24170 = (state_24308[(9)]);
var inst_24172 = (state_24308[(10)]);
var inst_24177 = cljs.core._nth.call(null,inst_24170,inst_24172);
var inst_24178 = figwheel.client.file_reloading.eval_body.call(null,inst_24177,opts);
var inst_24179 = (inst_24172 + (1));
var tmp24310 = inst_24171;
var tmp24311 = inst_24169;
var tmp24312 = inst_24170;
var inst_24169__$1 = tmp24311;
var inst_24170__$1 = tmp24312;
var inst_24171__$1 = tmp24310;
var inst_24172__$1 = inst_24179;
var state_24308__$1 = (function (){var statearr_24313 = state_24308;
(statearr_24313[(7)] = inst_24171__$1);

(statearr_24313[(11)] = inst_24178);

(statearr_24313[(8)] = inst_24169__$1);

(statearr_24313[(9)] = inst_24170__$1);

(statearr_24313[(10)] = inst_24172__$1);

return statearr_24313;
})();
var statearr_24314_24400 = state_24308__$1;
(statearr_24314_24400[(2)] = null);

(statearr_24314_24400[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (20))){
var inst_24212 = (state_24308[(12)]);
var inst_24220 = figwheel.client.file_reloading.sort_files.call(null,inst_24212);
var state_24308__$1 = state_24308;
var statearr_24315_24401 = state_24308__$1;
(statearr_24315_24401[(2)] = inst_24220);

(statearr_24315_24401[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (27))){
var state_24308__$1 = state_24308;
var statearr_24316_24402 = state_24308__$1;
(statearr_24316_24402[(2)] = null);

(statearr_24316_24402[(1)] = (28));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (1))){
var inst_24161 = (state_24308[(13)]);
var inst_24158 = before_jsload.call(null,files);
var inst_24159 = figwheel.client.file_reloading.before_jsload_custom_event.call(null,files);
var inst_24160 = (function (){return ((function (inst_24161,inst_24158,inst_24159,state_val_24309,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (p1__23903_SHARP_){
return new cljs.core.Keyword(null,"eval-body","eval-body",-907279883).cljs$core$IFn$_invoke$arity$1(p1__23903_SHARP_);
});
;})(inst_24161,inst_24158,inst_24159,state_val_24309,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var inst_24161__$1 = cljs.core.filter.call(null,inst_24160,files);
var inst_24162 = cljs.core.not_empty.call(null,inst_24161__$1);
var state_24308__$1 = (function (){var statearr_24317 = state_24308;
(statearr_24317[(14)] = inst_24159);

(statearr_24317[(13)] = inst_24161__$1);

(statearr_24317[(15)] = inst_24158);

return statearr_24317;
})();
if(cljs.core.truth_(inst_24162)){
var statearr_24318_24403 = state_24308__$1;
(statearr_24318_24403[(1)] = (2));

} else {
var statearr_24319_24404 = state_24308__$1;
(statearr_24319_24404[(1)] = (3));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (24))){
var state_24308__$1 = state_24308;
var statearr_24320_24405 = state_24308__$1;
(statearr_24320_24405[(2)] = null);

(statearr_24320_24405[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (39))){
var inst_24262 = (state_24308[(16)]);
var state_24308__$1 = state_24308;
var statearr_24321_24406 = state_24308__$1;
(statearr_24321_24406[(2)] = inst_24262);

(statearr_24321_24406[(1)] = (40));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (46))){
var inst_24303 = (state_24308[(2)]);
var state_24308__$1 = state_24308;
var statearr_24322_24407 = state_24308__$1;
(statearr_24322_24407[(2)] = inst_24303);

(statearr_24322_24407[(1)] = (31));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (4))){
var inst_24206 = (state_24308[(2)]);
var inst_24207 = cljs.core.List.EMPTY;
var inst_24208 = cljs.core.reset_BANG_.call(null,figwheel.client.file_reloading.dependencies_loaded,inst_24207);
var inst_24209 = (function (){return ((function (inst_24206,inst_24207,inst_24208,state_val_24309,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (p1__23904_SHARP_){
var and__18286__auto__ = new cljs.core.Keyword(null,"namespace","namespace",-377510372).cljs$core$IFn$_invoke$arity$1(p1__23904_SHARP_);
if(cljs.core.truth_(and__18286__auto__)){
return cljs.core.not.call(null,new cljs.core.Keyword(null,"eval-body","eval-body",-907279883).cljs$core$IFn$_invoke$arity$1(p1__23904_SHARP_));
} else {
return and__18286__auto__;
}
});
;})(inst_24206,inst_24207,inst_24208,state_val_24309,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var inst_24210 = cljs.core.filter.call(null,inst_24209,files);
var inst_24211 = figwheel.client.file_reloading.get_figwheel_always.call(null);
var inst_24212 = cljs.core.concat.call(null,inst_24210,inst_24211);
var state_24308__$1 = (function (){var statearr_24323 = state_24308;
(statearr_24323[(17)] = inst_24206);

(statearr_24323[(12)] = inst_24212);

(statearr_24323[(18)] = inst_24208);

return statearr_24323;
})();
if(cljs.core.truth_(reload_dependents)){
var statearr_24324_24408 = state_24308__$1;
(statearr_24324_24408[(1)] = (16));

} else {
var statearr_24325_24409 = state_24308__$1;
(statearr_24325_24409[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (15))){
var inst_24196 = (state_24308[(2)]);
var state_24308__$1 = state_24308;
var statearr_24326_24410 = state_24308__$1;
(statearr_24326_24410[(2)] = inst_24196);

(statearr_24326_24410[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (21))){
var inst_24222 = (state_24308[(19)]);
var inst_24222__$1 = (state_24308[(2)]);
var inst_24223 = figwheel.client.file_reloading.load_all_js_files.call(null,inst_24222__$1);
var state_24308__$1 = (function (){var statearr_24327 = state_24308;
(statearr_24327[(19)] = inst_24222__$1);

return statearr_24327;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_24308__$1,(22),inst_24223);
} else {
if((state_val_24309 === (31))){
var inst_24306 = (state_24308[(2)]);
var state_24308__$1 = state_24308;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_24308__$1,inst_24306);
} else {
if((state_val_24309 === (32))){
var inst_24262 = (state_24308[(16)]);
var inst_24267 = inst_24262.cljs$lang$protocol_mask$partition0$;
var inst_24268 = (inst_24267 & (64));
var inst_24269 = inst_24262.cljs$core$ISeq$;
var inst_24270 = (inst_24268) || (inst_24269);
var state_24308__$1 = state_24308;
if(cljs.core.truth_(inst_24270)){
var statearr_24328_24411 = state_24308__$1;
(statearr_24328_24411[(1)] = (35));

} else {
var statearr_24329_24412 = state_24308__$1;
(statearr_24329_24412[(1)] = (36));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (40))){
var inst_24283 = (state_24308[(20)]);
var inst_24282 = (state_24308[(2)]);
var inst_24283__$1 = cljs.core.get.call(null,inst_24282,new cljs.core.Keyword(null,"figwheel-no-load","figwheel-no-load",-555840179));
var inst_24284 = cljs.core.get.call(null,inst_24282,new cljs.core.Keyword(null,"not-required","not-required",-950359114));
var inst_24285 = cljs.core.not_empty.call(null,inst_24283__$1);
var state_24308__$1 = (function (){var statearr_24330 = state_24308;
(statearr_24330[(21)] = inst_24284);

(statearr_24330[(20)] = inst_24283__$1);

return statearr_24330;
})();
if(cljs.core.truth_(inst_24285)){
var statearr_24331_24413 = state_24308__$1;
(statearr_24331_24413[(1)] = (41));

} else {
var statearr_24332_24414 = state_24308__$1;
(statearr_24332_24414[(1)] = (42));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (33))){
var state_24308__$1 = state_24308;
var statearr_24333_24415 = state_24308__$1;
(statearr_24333_24415[(2)] = false);

(statearr_24333_24415[(1)] = (34));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (13))){
var inst_24182 = (state_24308[(22)]);
var inst_24186 = cljs.core.chunk_first.call(null,inst_24182);
var inst_24187 = cljs.core.chunk_rest.call(null,inst_24182);
var inst_24188 = cljs.core.count.call(null,inst_24186);
var inst_24169 = inst_24187;
var inst_24170 = inst_24186;
var inst_24171 = inst_24188;
var inst_24172 = (0);
var state_24308__$1 = (function (){var statearr_24334 = state_24308;
(statearr_24334[(7)] = inst_24171);

(statearr_24334[(8)] = inst_24169);

(statearr_24334[(9)] = inst_24170);

(statearr_24334[(10)] = inst_24172);

return statearr_24334;
})();
var statearr_24335_24416 = state_24308__$1;
(statearr_24335_24416[(2)] = null);

(statearr_24335_24416[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (22))){
var inst_24226 = (state_24308[(23)]);
var inst_24225 = (state_24308[(24)]);
var inst_24230 = (state_24308[(25)]);
var inst_24222 = (state_24308[(19)]);
var inst_24225__$1 = (state_24308[(2)]);
var inst_24226__$1 = cljs.core.filter.call(null,new cljs.core.Keyword(null,"loaded-file","loaded-file",-168399375),inst_24225__$1);
var inst_24227 = (function (){var all_files = inst_24222;
var res_SINGLEQUOTE_ = inst_24225__$1;
var res = inst_24226__$1;
return ((function (all_files,res_SINGLEQUOTE_,res,inst_24226,inst_24225,inst_24230,inst_24222,inst_24225__$1,inst_24226__$1,state_val_24309,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (p1__23905_SHARP_){
return cljs.core.not.call(null,new cljs.core.Keyword(null,"loaded-file","loaded-file",-168399375).cljs$core$IFn$_invoke$arity$1(p1__23905_SHARP_));
});
;})(all_files,res_SINGLEQUOTE_,res,inst_24226,inst_24225,inst_24230,inst_24222,inst_24225__$1,inst_24226__$1,state_val_24309,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var inst_24228 = cljs.core.filter.call(null,inst_24227,inst_24225__$1);
var inst_24229 = cljs.core.deref.call(null,figwheel.client.file_reloading.dependencies_loaded);
var inst_24230__$1 = cljs.core.filter.call(null,new cljs.core.Keyword(null,"loaded-file","loaded-file",-168399375),inst_24229);
var inst_24231 = cljs.core.not_empty.call(null,inst_24230__$1);
var state_24308__$1 = (function (){var statearr_24336 = state_24308;
(statearr_24336[(23)] = inst_24226__$1);

(statearr_24336[(26)] = inst_24228);

(statearr_24336[(24)] = inst_24225__$1);

(statearr_24336[(25)] = inst_24230__$1);

return statearr_24336;
})();
if(cljs.core.truth_(inst_24231)){
var statearr_24337_24417 = state_24308__$1;
(statearr_24337_24417[(1)] = (23));

} else {
var statearr_24338_24418 = state_24308__$1;
(statearr_24338_24418[(1)] = (24));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (36))){
var state_24308__$1 = state_24308;
var statearr_24339_24419 = state_24308__$1;
(statearr_24339_24419[(2)] = false);

(statearr_24339_24419[(1)] = (37));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (41))){
var inst_24283 = (state_24308[(20)]);
var inst_24287 = cljs.core.comp.call(null,figwheel.client.file_reloading.name__GT_path,new cljs.core.Keyword(null,"namespace","namespace",-377510372));
var inst_24288 = cljs.core.map.call(null,inst_24287,inst_24283);
var inst_24289 = cljs.core.pr_str.call(null,inst_24288);
var inst_24290 = [cljs.core.str("figwheel-no-load meta-data: "),cljs.core.str(inst_24289)].join('');
var inst_24291 = figwheel.client.utils.log.call(null,inst_24290);
var state_24308__$1 = state_24308;
var statearr_24340_24420 = state_24308__$1;
(statearr_24340_24420[(2)] = inst_24291);

(statearr_24340_24420[(1)] = (43));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (43))){
var inst_24284 = (state_24308[(21)]);
var inst_24294 = (state_24308[(2)]);
var inst_24295 = cljs.core.not_empty.call(null,inst_24284);
var state_24308__$1 = (function (){var statearr_24341 = state_24308;
(statearr_24341[(27)] = inst_24294);

return statearr_24341;
})();
if(cljs.core.truth_(inst_24295)){
var statearr_24342_24421 = state_24308__$1;
(statearr_24342_24421[(1)] = (44));

} else {
var statearr_24343_24422 = state_24308__$1;
(statearr_24343_24422[(1)] = (45));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (29))){
var inst_24226 = (state_24308[(23)]);
var inst_24262 = (state_24308[(16)]);
var inst_24228 = (state_24308[(26)]);
var inst_24225 = (state_24308[(24)]);
var inst_24230 = (state_24308[(25)]);
var inst_24222 = (state_24308[(19)]);
var inst_24258 = figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"debug","debug",-1608172596),"Figwheel: NOT loading these files ");
var inst_24261 = (function (){var all_files = inst_24222;
var res_SINGLEQUOTE_ = inst_24225;
var res = inst_24226;
var files_not_loaded = inst_24228;
var dependencies_that_loaded = inst_24230;
return ((function (all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_24226,inst_24262,inst_24228,inst_24225,inst_24230,inst_24222,inst_24258,state_val_24309,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (p__24260){
var map__24344 = p__24260;
var map__24344__$1 = ((((!((map__24344 == null)))?((((map__24344.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24344.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24344):map__24344);
var namespace = cljs.core.get.call(null,map__24344__$1,new cljs.core.Keyword(null,"namespace","namespace",-377510372));
var meta_data = cljs.core.get.call(null,cljs.core.deref.call(null,figwheel.client.file_reloading.figwheel_meta_pragmas),cljs.core.name.call(null,namespace));
if((meta_data == null)){
return new cljs.core.Keyword(null,"not-required","not-required",-950359114);
} else {
if(cljs.core.truth_(meta_data.call(null,new cljs.core.Keyword(null,"figwheel-no-load","figwheel-no-load",-555840179)))){
return new cljs.core.Keyword(null,"figwheel-no-load","figwheel-no-load",-555840179);
} else {
return new cljs.core.Keyword(null,"not-required","not-required",-950359114);

}
}
});
;})(all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_24226,inst_24262,inst_24228,inst_24225,inst_24230,inst_24222,inst_24258,state_val_24309,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var inst_24262__$1 = cljs.core.group_by.call(null,inst_24261,inst_24228);
var inst_24264 = (inst_24262__$1 == null);
var inst_24265 = cljs.core.not.call(null,inst_24264);
var state_24308__$1 = (function (){var statearr_24346 = state_24308;
(statearr_24346[(16)] = inst_24262__$1);

(statearr_24346[(28)] = inst_24258);

return statearr_24346;
})();
if(inst_24265){
var statearr_24347_24423 = state_24308__$1;
(statearr_24347_24423[(1)] = (32));

} else {
var statearr_24348_24424 = state_24308__$1;
(statearr_24348_24424[(1)] = (33));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (44))){
var inst_24284 = (state_24308[(21)]);
var inst_24297 = cljs.core.map.call(null,new cljs.core.Keyword(null,"file","file",-1269645878),inst_24284);
var inst_24298 = cljs.core.pr_str.call(null,inst_24297);
var inst_24299 = [cljs.core.str("not required: "),cljs.core.str(inst_24298)].join('');
var inst_24300 = figwheel.client.utils.log.call(null,inst_24299);
var state_24308__$1 = state_24308;
var statearr_24349_24425 = state_24308__$1;
(statearr_24349_24425[(2)] = inst_24300);

(statearr_24349_24425[(1)] = (46));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (6))){
var inst_24203 = (state_24308[(2)]);
var state_24308__$1 = state_24308;
var statearr_24350_24426 = state_24308__$1;
(statearr_24350_24426[(2)] = inst_24203);

(statearr_24350_24426[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (28))){
var inst_24228 = (state_24308[(26)]);
var inst_24255 = (state_24308[(2)]);
var inst_24256 = cljs.core.not_empty.call(null,inst_24228);
var state_24308__$1 = (function (){var statearr_24351 = state_24308;
(statearr_24351[(29)] = inst_24255);

return statearr_24351;
})();
if(cljs.core.truth_(inst_24256)){
var statearr_24352_24427 = state_24308__$1;
(statearr_24352_24427[(1)] = (29));

} else {
var statearr_24353_24428 = state_24308__$1;
(statearr_24353_24428[(1)] = (30));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (25))){
var inst_24226 = (state_24308[(23)]);
var inst_24242 = (state_24308[(2)]);
var inst_24243 = cljs.core.not_empty.call(null,inst_24226);
var state_24308__$1 = (function (){var statearr_24354 = state_24308;
(statearr_24354[(30)] = inst_24242);

return statearr_24354;
})();
if(cljs.core.truth_(inst_24243)){
var statearr_24355_24429 = state_24308__$1;
(statearr_24355_24429[(1)] = (26));

} else {
var statearr_24356_24430 = state_24308__$1;
(statearr_24356_24430[(1)] = (27));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (34))){
var inst_24277 = (state_24308[(2)]);
var state_24308__$1 = state_24308;
if(cljs.core.truth_(inst_24277)){
var statearr_24357_24431 = state_24308__$1;
(statearr_24357_24431[(1)] = (38));

} else {
var statearr_24358_24432 = state_24308__$1;
(statearr_24358_24432[(1)] = (39));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (17))){
var state_24308__$1 = state_24308;
var statearr_24359_24433 = state_24308__$1;
(statearr_24359_24433[(2)] = recompile_dependents);

(statearr_24359_24433[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (3))){
var state_24308__$1 = state_24308;
var statearr_24360_24434 = state_24308__$1;
(statearr_24360_24434[(2)] = null);

(statearr_24360_24434[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (12))){
var inst_24199 = (state_24308[(2)]);
var state_24308__$1 = state_24308;
var statearr_24361_24435 = state_24308__$1;
(statearr_24361_24435[(2)] = inst_24199);

(statearr_24361_24435[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (2))){
var inst_24161 = (state_24308[(13)]);
var inst_24168 = cljs.core.seq.call(null,inst_24161);
var inst_24169 = inst_24168;
var inst_24170 = null;
var inst_24171 = (0);
var inst_24172 = (0);
var state_24308__$1 = (function (){var statearr_24362 = state_24308;
(statearr_24362[(7)] = inst_24171);

(statearr_24362[(8)] = inst_24169);

(statearr_24362[(9)] = inst_24170);

(statearr_24362[(10)] = inst_24172);

return statearr_24362;
})();
var statearr_24363_24436 = state_24308__$1;
(statearr_24363_24436[(2)] = null);

(statearr_24363_24436[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (23))){
var inst_24226 = (state_24308[(23)]);
var inst_24228 = (state_24308[(26)]);
var inst_24225 = (state_24308[(24)]);
var inst_24230 = (state_24308[(25)]);
var inst_24222 = (state_24308[(19)]);
var inst_24233 = figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"debug","debug",-1608172596),"Figwheel: loaded these dependencies");
var inst_24235 = (function (){var all_files = inst_24222;
var res_SINGLEQUOTE_ = inst_24225;
var res = inst_24226;
var files_not_loaded = inst_24228;
var dependencies_that_loaded = inst_24230;
return ((function (all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_24226,inst_24228,inst_24225,inst_24230,inst_24222,inst_24233,state_val_24309,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (p__24234){
var map__24364 = p__24234;
var map__24364__$1 = ((((!((map__24364 == null)))?((((map__24364.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24364.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24364):map__24364);
var request_url = cljs.core.get.call(null,map__24364__$1,new cljs.core.Keyword(null,"request-url","request-url",2100346596));
return clojure.string.replace.call(null,request_url,goog.basePath,"");
});
;})(all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_24226,inst_24228,inst_24225,inst_24230,inst_24222,inst_24233,state_val_24309,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var inst_24236 = cljs.core.reverse.call(null,inst_24230);
var inst_24237 = cljs.core.map.call(null,inst_24235,inst_24236);
var inst_24238 = cljs.core.pr_str.call(null,inst_24237);
var inst_24239 = figwheel.client.utils.log.call(null,inst_24238);
var state_24308__$1 = (function (){var statearr_24366 = state_24308;
(statearr_24366[(31)] = inst_24233);

return statearr_24366;
})();
var statearr_24367_24437 = state_24308__$1;
(statearr_24367_24437[(2)] = inst_24239);

(statearr_24367_24437[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (35))){
var state_24308__$1 = state_24308;
var statearr_24368_24438 = state_24308__$1;
(statearr_24368_24438[(2)] = true);

(statearr_24368_24438[(1)] = (37));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (19))){
var inst_24212 = (state_24308[(12)]);
var inst_24218 = figwheel.client.file_reloading.expand_files.call(null,inst_24212);
var state_24308__$1 = state_24308;
var statearr_24369_24439 = state_24308__$1;
(statearr_24369_24439[(2)] = inst_24218);

(statearr_24369_24439[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (11))){
var state_24308__$1 = state_24308;
var statearr_24370_24440 = state_24308__$1;
(statearr_24370_24440[(2)] = null);

(statearr_24370_24440[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (9))){
var inst_24201 = (state_24308[(2)]);
var state_24308__$1 = state_24308;
var statearr_24371_24441 = state_24308__$1;
(statearr_24371_24441[(2)] = inst_24201);

(statearr_24371_24441[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (5))){
var inst_24171 = (state_24308[(7)]);
var inst_24172 = (state_24308[(10)]);
var inst_24174 = (inst_24172 < inst_24171);
var inst_24175 = inst_24174;
var state_24308__$1 = state_24308;
if(cljs.core.truth_(inst_24175)){
var statearr_24372_24442 = state_24308__$1;
(statearr_24372_24442[(1)] = (7));

} else {
var statearr_24373_24443 = state_24308__$1;
(statearr_24373_24443[(1)] = (8));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (14))){
var inst_24182 = (state_24308[(22)]);
var inst_24191 = cljs.core.first.call(null,inst_24182);
var inst_24192 = figwheel.client.file_reloading.eval_body.call(null,inst_24191,opts);
var inst_24193 = cljs.core.next.call(null,inst_24182);
var inst_24169 = inst_24193;
var inst_24170 = null;
var inst_24171 = (0);
var inst_24172 = (0);
var state_24308__$1 = (function (){var statearr_24374 = state_24308;
(statearr_24374[(7)] = inst_24171);

(statearr_24374[(8)] = inst_24169);

(statearr_24374[(9)] = inst_24170);

(statearr_24374[(32)] = inst_24192);

(statearr_24374[(10)] = inst_24172);

return statearr_24374;
})();
var statearr_24375_24444 = state_24308__$1;
(statearr_24375_24444[(2)] = null);

(statearr_24375_24444[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (45))){
var state_24308__$1 = state_24308;
var statearr_24376_24445 = state_24308__$1;
(statearr_24376_24445[(2)] = null);

(statearr_24376_24445[(1)] = (46));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (26))){
var inst_24226 = (state_24308[(23)]);
var inst_24228 = (state_24308[(26)]);
var inst_24225 = (state_24308[(24)]);
var inst_24230 = (state_24308[(25)]);
var inst_24222 = (state_24308[(19)]);
var inst_24245 = figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"debug","debug",-1608172596),"Figwheel: loaded these files");
var inst_24247 = (function (){var all_files = inst_24222;
var res_SINGLEQUOTE_ = inst_24225;
var res = inst_24226;
var files_not_loaded = inst_24228;
var dependencies_that_loaded = inst_24230;
return ((function (all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_24226,inst_24228,inst_24225,inst_24230,inst_24222,inst_24245,state_val_24309,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (p__24246){
var map__24377 = p__24246;
var map__24377__$1 = ((((!((map__24377 == null)))?((((map__24377.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24377.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24377):map__24377);
var namespace = cljs.core.get.call(null,map__24377__$1,new cljs.core.Keyword(null,"namespace","namespace",-377510372));
var file = cljs.core.get.call(null,map__24377__$1,new cljs.core.Keyword(null,"file","file",-1269645878));
if(cljs.core.truth_(namespace)){
return figwheel.client.file_reloading.name__GT_path.call(null,cljs.core.name.call(null,namespace));
} else {
return file;
}
});
;})(all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_24226,inst_24228,inst_24225,inst_24230,inst_24222,inst_24245,state_val_24309,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var inst_24248 = cljs.core.map.call(null,inst_24247,inst_24226);
var inst_24249 = cljs.core.pr_str.call(null,inst_24248);
var inst_24250 = figwheel.client.utils.log.call(null,inst_24249);
var inst_24251 = (function (){var all_files = inst_24222;
var res_SINGLEQUOTE_ = inst_24225;
var res = inst_24226;
var files_not_loaded = inst_24228;
var dependencies_that_loaded = inst_24230;
return ((function (all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_24226,inst_24228,inst_24225,inst_24230,inst_24222,inst_24245,inst_24247,inst_24248,inst_24249,inst_24250,state_val_24309,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents){
return (function (){
figwheel.client.file_reloading.on_jsload_custom_event.call(null,res);

return cljs.core.apply.call(null,on_jsload,new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [res], null));
});
;})(all_files,res_SINGLEQUOTE_,res,files_not_loaded,dependencies_that_loaded,inst_24226,inst_24228,inst_24225,inst_24230,inst_24222,inst_24245,inst_24247,inst_24248,inst_24249,inst_24250,state_val_24309,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var inst_24252 = setTimeout(inst_24251,(10));
var state_24308__$1 = (function (){var statearr_24379 = state_24308;
(statearr_24379[(33)] = inst_24245);

(statearr_24379[(34)] = inst_24250);

return statearr_24379;
})();
var statearr_24380_24446 = state_24308__$1;
(statearr_24380_24446[(2)] = inst_24252);

(statearr_24380_24446[(1)] = (28));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (16))){
var state_24308__$1 = state_24308;
var statearr_24381_24447 = state_24308__$1;
(statearr_24381_24447[(2)] = reload_dependents);

(statearr_24381_24447[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (38))){
var inst_24262 = (state_24308[(16)]);
var inst_24279 = cljs.core.apply.call(null,cljs.core.hash_map,inst_24262);
var state_24308__$1 = state_24308;
var statearr_24382_24448 = state_24308__$1;
(statearr_24382_24448[(2)] = inst_24279);

(statearr_24382_24448[(1)] = (40));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (30))){
var state_24308__$1 = state_24308;
var statearr_24383_24449 = state_24308__$1;
(statearr_24383_24449[(2)] = null);

(statearr_24383_24449[(1)] = (31));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (10))){
var inst_24182 = (state_24308[(22)]);
var inst_24184 = cljs.core.chunked_seq_QMARK_.call(null,inst_24182);
var state_24308__$1 = state_24308;
if(inst_24184){
var statearr_24384_24450 = state_24308__$1;
(statearr_24384_24450[(1)] = (13));

} else {
var statearr_24385_24451 = state_24308__$1;
(statearr_24385_24451[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (18))){
var inst_24216 = (state_24308[(2)]);
var state_24308__$1 = state_24308;
if(cljs.core.truth_(inst_24216)){
var statearr_24386_24452 = state_24308__$1;
(statearr_24386_24452[(1)] = (19));

} else {
var statearr_24387_24453 = state_24308__$1;
(statearr_24387_24453[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (42))){
var state_24308__$1 = state_24308;
var statearr_24388_24454 = state_24308__$1;
(statearr_24388_24454[(2)] = null);

(statearr_24388_24454[(1)] = (43));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (37))){
var inst_24274 = (state_24308[(2)]);
var state_24308__$1 = state_24308;
var statearr_24389_24455 = state_24308__$1;
(statearr_24389_24455[(2)] = inst_24274);

(statearr_24389_24455[(1)] = (34));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_24309 === (8))){
var inst_24169 = (state_24308[(8)]);
var inst_24182 = (state_24308[(22)]);
var inst_24182__$1 = cljs.core.seq.call(null,inst_24169);
var state_24308__$1 = (function (){var statearr_24390 = state_24308;
(statearr_24390[(22)] = inst_24182__$1);

return statearr_24390;
})();
if(inst_24182__$1){
var statearr_24391_24456 = state_24308__$1;
(statearr_24391_24456[(1)] = (10));

} else {
var statearr_24392_24457 = state_24308__$1;
(statearr_24392_24457[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents))
;
return ((function (switch__20508__auto__,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents){
return (function() {
var figwheel$client$file_reloading$reload_js_files_$_state_machine__20509__auto__ = null;
var figwheel$client$file_reloading$reload_js_files_$_state_machine__20509__auto____0 = (function (){
var statearr_24396 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_24396[(0)] = figwheel$client$file_reloading$reload_js_files_$_state_machine__20509__auto__);

(statearr_24396[(1)] = (1));

return statearr_24396;
});
var figwheel$client$file_reloading$reload_js_files_$_state_machine__20509__auto____1 = (function (state_24308){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_24308);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e24397){if((e24397 instanceof Object)){
var ex__20512__auto__ = e24397;
var statearr_24398_24458 = state_24308;
(statearr_24398_24458[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_24308);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e24397;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__24459 = state_24308;
state_24308 = G__24459;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
figwheel$client$file_reloading$reload_js_files_$_state_machine__20509__auto__ = function(state_24308){
switch(arguments.length){
case 0:
return figwheel$client$file_reloading$reload_js_files_$_state_machine__20509__auto____0.call(this);
case 1:
return figwheel$client$file_reloading$reload_js_files_$_state_machine__20509__auto____1.call(this,state_24308);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$file_reloading$reload_js_files_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = figwheel$client$file_reloading$reload_js_files_$_state_machine__20509__auto____0;
figwheel$client$file_reloading$reload_js_files_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = figwheel$client$file_reloading$reload_js_files_$_state_machine__20509__auto____1;
return figwheel$client$file_reloading$reload_js_files_$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents))
})();
var state__20622__auto__ = (function (){var statearr_24399 = f__20621__auto__.call(null);
(statearr_24399[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto__);

return statearr_24399;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto__,map__24154,map__24154__$1,opts,before_jsload,on_jsload,reload_dependents,map__24155,map__24155__$1,msg,files,figwheel_meta,recompile_dependents))
);

return c__20620__auto__;
});
figwheel.client.file_reloading.current_links = (function figwheel$client$file_reloading$current_links(){
return Array.prototype.slice.call(document.getElementsByTagName("link"));
});
figwheel.client.file_reloading.truncate_url = (function figwheel$client$file_reloading$truncate_url(url){
return clojure.string.replace_first.call(null,clojure.string.replace_first.call(null,clojure.string.replace_first.call(null,clojure.string.replace_first.call(null,cljs.core.first.call(null,clojure.string.split.call(null,url,/\?/)),[cljs.core.str(location.protocol),cljs.core.str("//")].join(''),""),".*://",""),/^\/\//,""),/[^\\/]*/,"");
});
figwheel.client.file_reloading.matches_file_QMARK_ = (function figwheel$client$file_reloading$matches_file_QMARK_(p__24462,link){
var map__24465 = p__24462;
var map__24465__$1 = ((((!((map__24465 == null)))?((((map__24465.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24465.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24465):map__24465);
var file = cljs.core.get.call(null,map__24465__$1,new cljs.core.Keyword(null,"file","file",-1269645878));
var temp__4425__auto__ = link.href;
if(cljs.core.truth_(temp__4425__auto__)){
var link_href = temp__4425__auto__;
var match = clojure.string.join.call(null,"/",cljs.core.take_while.call(null,cljs.core.identity,cljs.core.map.call(null,((function (link_href,temp__4425__auto__,map__24465,map__24465__$1,file){
return (function (p1__24460_SHARP_,p2__24461_SHARP_){
if(cljs.core._EQ_.call(null,p1__24460_SHARP_,p2__24461_SHARP_)){
return p1__24460_SHARP_;
} else {
return false;
}
});})(link_href,temp__4425__auto__,map__24465,map__24465__$1,file))
,cljs.core.reverse.call(null,clojure.string.split.call(null,file,"/")),cljs.core.reverse.call(null,clojure.string.split.call(null,figwheel.client.file_reloading.truncate_url.call(null,link_href),"/")))));
var match_length = cljs.core.count.call(null,match);
var file_name_length = cljs.core.count.call(null,cljs.core.last.call(null,clojure.string.split.call(null,file,"/")));
if((match_length >= file_name_length)){
return new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"link","link",-1769163468),link,new cljs.core.Keyword(null,"link-href","link-href",-250644450),link_href,new cljs.core.Keyword(null,"match-length","match-length",1101537310),match_length,new cljs.core.Keyword(null,"current-url-length","current-url-length",380404083),cljs.core.count.call(null,figwheel.client.file_reloading.truncate_url.call(null,link_href))], null);
} else {
return null;
}
} else {
return null;
}
});
figwheel.client.file_reloading.get_correct_link = (function figwheel$client$file_reloading$get_correct_link(f_data){
var temp__4425__auto__ = cljs.core.first.call(null,cljs.core.sort_by.call(null,(function (p__24471){
var map__24472 = p__24471;
var map__24472__$1 = ((((!((map__24472 == null)))?((((map__24472.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24472.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24472):map__24472);
var match_length = cljs.core.get.call(null,map__24472__$1,new cljs.core.Keyword(null,"match-length","match-length",1101537310));
var current_url_length = cljs.core.get.call(null,map__24472__$1,new cljs.core.Keyword(null,"current-url-length","current-url-length",380404083));
return (current_url_length - match_length);
}),cljs.core.keep.call(null,(function (p1__24467_SHARP_){
return figwheel.client.file_reloading.matches_file_QMARK_.call(null,f_data,p1__24467_SHARP_);
}),figwheel.client.file_reloading.current_links.call(null))));
if(cljs.core.truth_(temp__4425__auto__)){
var res = temp__4425__auto__;
return new cljs.core.Keyword(null,"link","link",-1769163468).cljs$core$IFn$_invoke$arity$1(res);
} else {
return null;
}
});
figwheel.client.file_reloading.clone_link = (function figwheel$client$file_reloading$clone_link(link,url){
var clone = document.createElement("link");
clone.rel = "stylesheet";

clone.media = link.media;

clone.disabled = link.disabled;

clone.href = figwheel.client.file_reloading.add_cache_buster.call(null,url);

return clone;
});
figwheel.client.file_reloading.create_link = (function figwheel$client$file_reloading$create_link(url){
var link = document.createElement("link");
link.rel = "stylesheet";

link.href = figwheel.client.file_reloading.add_cache_buster.call(null,url);

return link;
});
figwheel.client.file_reloading.add_link_to_doc = (function figwheel$client$file_reloading$add_link_to_doc(var_args){
var args24474 = [];
var len__19356__auto___24477 = arguments.length;
var i__19357__auto___24478 = (0);
while(true){
if((i__19357__auto___24478 < len__19356__auto___24477)){
args24474.push((arguments[i__19357__auto___24478]));

var G__24479 = (i__19357__auto___24478 + (1));
i__19357__auto___24478 = G__24479;
continue;
} else {
}
break;
}

var G__24476 = args24474.length;
switch (G__24476) {
case 1:
return figwheel.client.file_reloading.add_link_to_doc.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return figwheel.client.file_reloading.add_link_to_doc.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args24474.length)].join('')));

}
});

figwheel.client.file_reloading.add_link_to_doc.cljs$core$IFn$_invoke$arity$1 = (function (new_link){
return (document.getElementsByTagName("head")[(0)]).appendChild(new_link);
});

figwheel.client.file_reloading.add_link_to_doc.cljs$core$IFn$_invoke$arity$2 = (function (orig_link,klone){
var parent = orig_link.parentNode;
if(cljs.core._EQ_.call(null,orig_link,parent.lastChild)){
parent.appendChild(klone);
} else {
parent.insertBefore(klone,orig_link.nextSibling);
}

return setTimeout(((function (parent){
return (function (){
return parent.removeChild(orig_link);
});})(parent))
,(300));
});

figwheel.client.file_reloading.add_link_to_doc.cljs$lang$maxFixedArity = 2;
figwheel.client.file_reloading.distictify = (function figwheel$client$file_reloading$distictify(key,seqq){
return cljs.core.vals.call(null,cljs.core.reduce.call(null,(function (p1__24481_SHARP_,p2__24482_SHARP_){
return cljs.core.assoc.call(null,p1__24481_SHARP_,cljs.core.get.call(null,p2__24482_SHARP_,key),p2__24482_SHARP_);
}),cljs.core.PersistentArrayMap.EMPTY,seqq));
});
figwheel.client.file_reloading.reload_css_file = (function figwheel$client$file_reloading$reload_css_file(p__24483){
var map__24486 = p__24483;
var map__24486__$1 = ((((!((map__24486 == null)))?((((map__24486.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24486.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24486):map__24486);
var f_data = map__24486__$1;
var file = cljs.core.get.call(null,map__24486__$1,new cljs.core.Keyword(null,"file","file",-1269645878));
var temp__4425__auto__ = figwheel.client.file_reloading.get_correct_link.call(null,f_data);
if(cljs.core.truth_(temp__4425__auto__)){
var link = temp__4425__auto__;
return figwheel.client.file_reloading.add_link_to_doc.call(null,link,figwheel.client.file_reloading.clone_link.call(null,link,link.href));
} else {
return null;
}
});
figwheel.client.file_reloading.reload_css_files = (function figwheel$client$file_reloading$reload_css_files(p__24488,files_msg){
var map__24495 = p__24488;
var map__24495__$1 = ((((!((map__24495 == null)))?((((map__24495.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24495.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24495):map__24495);
var opts = map__24495__$1;
var on_cssload = cljs.core.get.call(null,map__24495__$1,new cljs.core.Keyword(null,"on-cssload","on-cssload",1825432318));
if(cljs.core.truth_(figwheel.client.utils.html_env_QMARK_.call(null))){
var seq__24497_24501 = cljs.core.seq.call(null,figwheel.client.file_reloading.distictify.call(null,new cljs.core.Keyword(null,"file","file",-1269645878),new cljs.core.Keyword(null,"files","files",-472457450).cljs$core$IFn$_invoke$arity$1(files_msg)));
var chunk__24498_24502 = null;
var count__24499_24503 = (0);
var i__24500_24504 = (0);
while(true){
if((i__24500_24504 < count__24499_24503)){
var f_24505 = cljs.core._nth.call(null,chunk__24498_24502,i__24500_24504);
figwheel.client.file_reloading.reload_css_file.call(null,f_24505);

var G__24506 = seq__24497_24501;
var G__24507 = chunk__24498_24502;
var G__24508 = count__24499_24503;
var G__24509 = (i__24500_24504 + (1));
seq__24497_24501 = G__24506;
chunk__24498_24502 = G__24507;
count__24499_24503 = G__24508;
i__24500_24504 = G__24509;
continue;
} else {
var temp__4425__auto___24510 = cljs.core.seq.call(null,seq__24497_24501);
if(temp__4425__auto___24510){
var seq__24497_24511__$1 = temp__4425__auto___24510;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__24497_24511__$1)){
var c__19101__auto___24512 = cljs.core.chunk_first.call(null,seq__24497_24511__$1);
var G__24513 = cljs.core.chunk_rest.call(null,seq__24497_24511__$1);
var G__24514 = c__19101__auto___24512;
var G__24515 = cljs.core.count.call(null,c__19101__auto___24512);
var G__24516 = (0);
seq__24497_24501 = G__24513;
chunk__24498_24502 = G__24514;
count__24499_24503 = G__24515;
i__24500_24504 = G__24516;
continue;
} else {
var f_24517 = cljs.core.first.call(null,seq__24497_24511__$1);
figwheel.client.file_reloading.reload_css_file.call(null,f_24517);

var G__24518 = cljs.core.next.call(null,seq__24497_24511__$1);
var G__24519 = null;
var G__24520 = (0);
var G__24521 = (0);
seq__24497_24501 = G__24518;
chunk__24498_24502 = G__24519;
count__24499_24503 = G__24520;
i__24500_24504 = G__24521;
continue;
}
} else {
}
}
break;
}

return setTimeout(((function (map__24495,map__24495__$1,opts,on_cssload){
return (function (){
return on_cssload.call(null,new cljs.core.Keyword(null,"files","files",-472457450).cljs$core$IFn$_invoke$arity$1(files_msg));
});})(map__24495,map__24495__$1,opts,on_cssload))
,(100));
} else {
return null;
}
});

//# sourceMappingURL=file_reloading.js.map