var CLOSURE_UNCOMPILED_DEFINES = null;
if(typeof goog == "undefined") document.write('<script src="js/compiled/goog/base.js"></script>');
document.write('<script src="js/compiled/cljs_deps.js"></script>');

document.write("<script>if (typeof goog != \"undefined\") { goog.require(\"figwheel.connect\"); }</script>");
document.write('<script>if (typeof goog != "undefined") { goog.require("cljs_bach.synthesis"); } else { console.warn("ClojureScript could not load :main, did you forget to specify :asset-path?"); };</script>');