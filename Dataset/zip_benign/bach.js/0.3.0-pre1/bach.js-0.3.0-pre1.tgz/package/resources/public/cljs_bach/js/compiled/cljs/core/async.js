// Compiled by ClojureScript 1.7.228 {}
goog.provide('cljs.core.async');
goog.require('cljs.core');
goog.require('cljs.core.async.impl.channels');
goog.require('cljs.core.async.impl.dispatch');
goog.require('cljs.core.async.impl.ioc_helpers');
goog.require('cljs.core.async.impl.protocols');
goog.require('cljs.core.async.impl.buffers');
goog.require('cljs.core.async.impl.timers');
cljs.core.async.fn_handler = (function cljs$core$async$fn_handler(var_args){
var args20665 = [];
var len__19356__auto___20671 = arguments.length;
var i__19357__auto___20672 = (0);
while(true){
if((i__19357__auto___20672 < len__19356__auto___20671)){
args20665.push((arguments[i__19357__auto___20672]));

var G__20673 = (i__19357__auto___20672 + (1));
i__19357__auto___20672 = G__20673;
continue;
} else {
}
break;
}

var G__20667 = args20665.length;
switch (G__20667) {
case 1:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args20665.length)].join('')));

}
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$1 = (function (f){
return cljs.core.async.fn_handler.call(null,f,true);
});

cljs.core.async.fn_handler.cljs$core$IFn$_invoke$arity$2 = (function (f,blockable){
if(typeof cljs.core.async.t_cljs$core$async20668 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async20668 = (function (f,blockable,meta20669){
this.f = f;
this.blockable = blockable;
this.meta20669 = meta20669;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async20668.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_20670,meta20669__$1){
var self__ = this;
var _20670__$1 = this;
return (new cljs.core.async.t_cljs$core$async20668(self__.f,self__.blockable,meta20669__$1));
});

cljs.core.async.t_cljs$core$async20668.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_20670){
var self__ = this;
var _20670__$1 = this;
return self__.meta20669;
});

cljs.core.async.t_cljs$core$async20668.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async20668.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async20668.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.blockable;
});

cljs.core.async.t_cljs$core$async20668.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return self__.f;
});

cljs.core.async.t_cljs$core$async20668.getBasis = (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"blockable","blockable",-28395259,null),new cljs.core.Symbol(null,"meta20669","meta20669",-384570899,null)], null);
});

cljs.core.async.t_cljs$core$async20668.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async20668.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async20668";

cljs.core.async.t_cljs$core$async20668.cljs$lang$ctorPrWriter = (function (this__18896__auto__,writer__18897__auto__,opt__18898__auto__){
return cljs.core._write.call(null,writer__18897__auto__,"cljs.core.async/t_cljs$core$async20668");
});

cljs.core.async.__GT_t_cljs$core$async20668 = (function cljs$core$async$__GT_t_cljs$core$async20668(f__$1,blockable__$1,meta20669){
return (new cljs.core.async.t_cljs$core$async20668(f__$1,blockable__$1,meta20669));
});

}

return (new cljs.core.async.t_cljs$core$async20668(f,blockable,cljs.core.PersistentArrayMap.EMPTY));
});

cljs.core.async.fn_handler.cljs$lang$maxFixedArity = 2;
/**
 * Returns a fixed buffer of size n. When full, puts will block/park.
 */
cljs.core.async.buffer = (function cljs$core$async$buffer(n){
return cljs.core.async.impl.buffers.fixed_buffer.call(null,n);
});
/**
 * Returns a buffer of size n. When full, puts will complete but
 *   val will be dropped (no transfer).
 */
cljs.core.async.dropping_buffer = (function cljs$core$async$dropping_buffer(n){
return cljs.core.async.impl.buffers.dropping_buffer.call(null,n);
});
/**
 * Returns a buffer of size n. When full, puts will complete, and be
 *   buffered, but oldest elements in buffer will be dropped (not
 *   transferred).
 */
cljs.core.async.sliding_buffer = (function cljs$core$async$sliding_buffer(n){
return cljs.core.async.impl.buffers.sliding_buffer.call(null,n);
});
/**
 * Returns true if a channel created with buff will never block. That is to say,
 * puts into this buffer will never cause the buffer to be full. 
 */
cljs.core.async.unblocking_buffer_QMARK_ = (function cljs$core$async$unblocking_buffer_QMARK_(buff){
if(!((buff == null))){
if((false) || (buff.cljs$core$async$impl$protocols$UnblockingBuffer$)){
return true;
} else {
if((!buff.cljs$lang$protocol_mask$partition$)){
return cljs.core.native_satisfies_QMARK_.call(null,cljs.core.async.impl.protocols.UnblockingBuffer,buff);
} else {
return false;
}
}
} else {
return cljs.core.native_satisfies_QMARK_.call(null,cljs.core.async.impl.protocols.UnblockingBuffer,buff);
}
});
/**
 * Creates a channel with an optional buffer, an optional transducer (like (map f),
 *   (filter p) etc or a composition thereof), and an optional exception handler.
 *   If buf-or-n is a number, will create and use a fixed buffer of that size. If a
 *   transducer is supplied a buffer must be specified. ex-handler must be a
 *   fn of one argument - if an exception occurs during transformation it will be called
 *   with the thrown value as an argument, and any non-nil return value will be placed
 *   in the channel.
 */
cljs.core.async.chan = (function cljs$core$async$chan(var_args){
var args20677 = [];
var len__19356__auto___20680 = arguments.length;
var i__19357__auto___20681 = (0);
while(true){
if((i__19357__auto___20681 < len__19356__auto___20680)){
args20677.push((arguments[i__19357__auto___20681]));

var G__20682 = (i__19357__auto___20681 + (1));
i__19357__auto___20681 = G__20682;
continue;
} else {
}
break;
}

var G__20679 = args20677.length;
switch (G__20679) {
case 0:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args20677.length)].join('')));

}
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.chan.call(null,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$1 = (function (buf_or_n){
return cljs.core.async.chan.call(null,buf_or_n,null,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$2 = (function (buf_or_n,xform){
return cljs.core.async.chan.call(null,buf_or_n,xform,null);
});

cljs.core.async.chan.cljs$core$IFn$_invoke$arity$3 = (function (buf_or_n,xform,ex_handler){
var buf_or_n__$1 = ((cljs.core._EQ_.call(null,buf_or_n,(0)))?null:buf_or_n);
if(cljs.core.truth_(xform)){
if(cljs.core.truth_(buf_or_n__$1)){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str("buffer must be supplied when transducer is"),cljs.core.str("\n"),cljs.core.str(cljs.core.pr_str.call(null,new cljs.core.Symbol(null,"buf-or-n","buf-or-n",-1646815050,null)))].join('')));
}
} else {
}

return cljs.core.async.impl.channels.chan.call(null,((typeof buf_or_n__$1 === 'number')?cljs.core.async.buffer.call(null,buf_or_n__$1):buf_or_n__$1),xform,ex_handler);
});

cljs.core.async.chan.cljs$lang$maxFixedArity = 3;
/**
 * Creates a promise channel with an optional transducer, and an optional
 *   exception-handler. A promise channel can take exactly one value that consumers
 *   will receive. Once full, puts complete but val is dropped (no transfer).
 *   Consumers will block until either a value is placed in the channel or the
 *   channel is closed. See chan for the semantics of xform and ex-handler.
 */
cljs.core.async.promise_chan = (function cljs$core$async$promise_chan(var_args){
var args20684 = [];
var len__19356__auto___20687 = arguments.length;
var i__19357__auto___20688 = (0);
while(true){
if((i__19357__auto___20688 < len__19356__auto___20687)){
args20684.push((arguments[i__19357__auto___20688]));

var G__20689 = (i__19357__auto___20688 + (1));
i__19357__auto___20688 = G__20689;
continue;
} else {
}
break;
}

var G__20686 = args20684.length;
switch (G__20686) {
case 0:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0();

break;
case 1:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args20684.length)].join('')));

}
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$0 = (function (){
return cljs.core.async.promise_chan.call(null,null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$1 = (function (xform){
return cljs.core.async.promise_chan.call(null,xform,null);
});

cljs.core.async.promise_chan.cljs$core$IFn$_invoke$arity$2 = (function (xform,ex_handler){
return cljs.core.async.chan.call(null,cljs.core.async.impl.buffers.promise_buffer.call(null),xform,ex_handler);
});

cljs.core.async.promise_chan.cljs$lang$maxFixedArity = 2;
/**
 * Returns a channel that will close after msecs
 */
cljs.core.async.timeout = (function cljs$core$async$timeout(msecs){
return cljs.core.async.impl.timers.timeout.call(null,msecs);
});
/**
 * takes a val from port. Must be called inside a (go ...) block. Will
 *   return nil if closed. Will park if nothing is available.
 *   Returns true unless port is already closed
 */
cljs.core.async._LT__BANG_ = (function cljs$core$async$_LT__BANG_(port){
throw (new Error("<! used not in (go ...) block"));
});
/**
 * Asynchronously takes a val from port, passing to fn1. Will pass nil
 * if closed. If on-caller? (default true) is true, and value is
 * immediately available, will call fn1 on calling thread.
 * Returns nil.
 */
cljs.core.async.take_BANG_ = (function cljs$core$async$take_BANG_(var_args){
var args20691 = [];
var len__19356__auto___20694 = arguments.length;
var i__19357__auto___20695 = (0);
while(true){
if((i__19357__auto___20695 < len__19356__auto___20694)){
args20691.push((arguments[i__19357__auto___20695]));

var G__20696 = (i__19357__auto___20695 + (1));
i__19357__auto___20695 = G__20696;
continue;
} else {
}
break;
}

var G__20693 = args20691.length;
switch (G__20693) {
case 2:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args20691.length)].join('')));

}
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,fn1){
return cljs.core.async.take_BANG_.call(null,port,fn1,true);
});

cljs.core.async.take_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,fn1,on_caller_QMARK_){
var ret = cljs.core.async.impl.protocols.take_BANG_.call(null,port,cljs.core.async.fn_handler.call(null,fn1));
if(cljs.core.truth_(ret)){
var val_20698 = cljs.core.deref.call(null,ret);
if(cljs.core.truth_(on_caller_QMARK_)){
fn1.call(null,val_20698);
} else {
cljs.core.async.impl.dispatch.run.call(null,((function (val_20698,ret){
return (function (){
return fn1.call(null,val_20698);
});})(val_20698,ret))
);
}
} else {
}

return null;
});

cljs.core.async.take_BANG_.cljs$lang$maxFixedArity = 3;
cljs.core.async.nop = (function cljs$core$async$nop(_){
return null;
});
cljs.core.async.fhnop = cljs.core.async.fn_handler.call(null,cljs.core.async.nop);
/**
 * puts a val into port. nil values are not allowed. Must be called
 *   inside a (go ...) block. Will park if no buffer space is available.
 *   Returns true unless port is already closed.
 */
cljs.core.async._GT__BANG_ = (function cljs$core$async$_GT__BANG_(port,val){
throw (new Error(">! used not in (go ...) block"));
});
/**
 * Asynchronously puts a val into port, calling fn0 (if supplied) when
 * complete. nil values are not allowed. Will throw if closed. If
 * on-caller? (default true) is true, and the put is immediately
 * accepted, will call fn0 on calling thread.  Returns nil.
 */
cljs.core.async.put_BANG_ = (function cljs$core$async$put_BANG_(var_args){
var args20699 = [];
var len__19356__auto___20702 = arguments.length;
var i__19357__auto___20703 = (0);
while(true){
if((i__19357__auto___20703 < len__19356__auto___20702)){
args20699.push((arguments[i__19357__auto___20703]));

var G__20704 = (i__19357__auto___20703 + (1));
i__19357__auto___20703 = G__20704;
continue;
} else {
}
break;
}

var G__20701 = args20699.length;
switch (G__20701) {
case 2:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args20699.length)].join('')));

}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$2 = (function (port,val){
var temp__4423__auto__ = cljs.core.async.impl.protocols.put_BANG_.call(null,port,val,cljs.core.async.fhnop);
if(cljs.core.truth_(temp__4423__auto__)){
var ret = temp__4423__auto__;
return cljs.core.deref.call(null,ret);
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$3 = (function (port,val,fn1){
return cljs.core.async.put_BANG_.call(null,port,val,fn1,true);
});

cljs.core.async.put_BANG_.cljs$core$IFn$_invoke$arity$4 = (function (port,val,fn1,on_caller_QMARK_){
var temp__4423__auto__ = cljs.core.async.impl.protocols.put_BANG_.call(null,port,val,cljs.core.async.fn_handler.call(null,fn1));
if(cljs.core.truth_(temp__4423__auto__)){
var retb = temp__4423__auto__;
var ret = cljs.core.deref.call(null,retb);
if(cljs.core.truth_(on_caller_QMARK_)){
fn1.call(null,ret);
} else {
cljs.core.async.impl.dispatch.run.call(null,((function (ret,retb,temp__4423__auto__){
return (function (){
return fn1.call(null,ret);
});})(ret,retb,temp__4423__auto__))
);
}

return ret;
} else {
return true;
}
});

cljs.core.async.put_BANG_.cljs$lang$maxFixedArity = 4;
cljs.core.async.close_BANG_ = (function cljs$core$async$close_BANG_(port){
return cljs.core.async.impl.protocols.close_BANG_.call(null,port);
});
cljs.core.async.random_array = (function cljs$core$async$random_array(n){
var a = (new Array(n));
var n__19201__auto___20706 = n;
var x_20707 = (0);
while(true){
if((x_20707 < n__19201__auto___20706)){
(a[x_20707] = (0));

var G__20708 = (x_20707 + (1));
x_20707 = G__20708;
continue;
} else {
}
break;
}

var i = (1);
while(true){
if(cljs.core._EQ_.call(null,i,n)){
return a;
} else {
var j = cljs.core.rand_int.call(null,i);
(a[i] = (a[j]));

(a[j] = i);

var G__20709 = (i + (1));
i = G__20709;
continue;
}
break;
}
});
cljs.core.async.alt_flag = (function cljs$core$async$alt_flag(){
var flag = cljs.core.atom.call(null,true);
if(typeof cljs.core.async.t_cljs$core$async20713 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async20713 = (function (alt_flag,flag,meta20714){
this.alt_flag = alt_flag;
this.flag = flag;
this.meta20714 = meta20714;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async20713.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (flag){
return (function (_20715,meta20714__$1){
var self__ = this;
var _20715__$1 = this;
return (new cljs.core.async.t_cljs$core$async20713(self__.alt_flag,self__.flag,meta20714__$1));
});})(flag))
;

cljs.core.async.t_cljs$core$async20713.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (flag){
return (function (_20715){
var self__ = this;
var _20715__$1 = this;
return self__.meta20714;
});})(flag))
;

cljs.core.async.t_cljs$core$async20713.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async20713.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.deref.call(null,self__.flag);
});})(flag))
;

cljs.core.async.t_cljs$core$async20713.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async20713.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (flag){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_.call(null,self__.flag,null);

return true;
});})(flag))
;

cljs.core.async.t_cljs$core$async20713.getBasis = ((function (flag){
return (function (){
return new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"alt-flag","alt-flag",-1794972754,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"private","private",-558947994),true,new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(cljs.core.PersistentVector.EMPTY))], null)),new cljs.core.Symbol(null,"flag","flag",-1565787888,null),new cljs.core.Symbol(null,"meta20714","meta20714",330388581,null)], null);
});})(flag))
;

cljs.core.async.t_cljs$core$async20713.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async20713.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async20713";

cljs.core.async.t_cljs$core$async20713.cljs$lang$ctorPrWriter = ((function (flag){
return (function (this__18896__auto__,writer__18897__auto__,opt__18898__auto__){
return cljs.core._write.call(null,writer__18897__auto__,"cljs.core.async/t_cljs$core$async20713");
});})(flag))
;

cljs.core.async.__GT_t_cljs$core$async20713 = ((function (flag){
return (function cljs$core$async$alt_flag_$___GT_t_cljs$core$async20713(alt_flag__$1,flag__$1,meta20714){
return (new cljs.core.async.t_cljs$core$async20713(alt_flag__$1,flag__$1,meta20714));
});})(flag))
;

}

return (new cljs.core.async.t_cljs$core$async20713(cljs$core$async$alt_flag,flag,cljs.core.PersistentArrayMap.EMPTY));
});
cljs.core.async.alt_handler = (function cljs$core$async$alt_handler(flag,cb){
if(typeof cljs.core.async.t_cljs$core$async20719 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async20719 = (function (alt_handler,flag,cb,meta20720){
this.alt_handler = alt_handler;
this.flag = flag;
this.cb = cb;
this.meta20720 = meta20720;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async20719.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_20721,meta20720__$1){
var self__ = this;
var _20721__$1 = this;
return (new cljs.core.async.t_cljs$core$async20719(self__.alt_handler,self__.flag,self__.cb,meta20720__$1));
});

cljs.core.async.t_cljs$core$async20719.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_20721){
var self__ = this;
var _20721__$1 = this;
return self__.meta20720;
});

cljs.core.async.t_cljs$core$async20719.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async20719.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.active_QMARK_.call(null,self__.flag);
});

cljs.core.async.t_cljs$core$async20719.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return true;
});

cljs.core.async.t_cljs$core$async20719.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.async.impl.protocols.commit.call(null,self__.flag);

return self__.cb;
});

cljs.core.async.t_cljs$core$async20719.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"alt-handler","alt-handler",963786170,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"private","private",-558947994),true,new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"flag","flag",-1565787888,null),new cljs.core.Symbol(null,"cb","cb",-2064487928,null)], null)))], null)),new cljs.core.Symbol(null,"flag","flag",-1565787888,null),new cljs.core.Symbol(null,"cb","cb",-2064487928,null),new cljs.core.Symbol(null,"meta20720","meta20720",-891761703,null)], null);
});

cljs.core.async.t_cljs$core$async20719.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async20719.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async20719";

cljs.core.async.t_cljs$core$async20719.cljs$lang$ctorPrWriter = (function (this__18896__auto__,writer__18897__auto__,opt__18898__auto__){
return cljs.core._write.call(null,writer__18897__auto__,"cljs.core.async/t_cljs$core$async20719");
});

cljs.core.async.__GT_t_cljs$core$async20719 = (function cljs$core$async$alt_handler_$___GT_t_cljs$core$async20719(alt_handler__$1,flag__$1,cb__$1,meta20720){
return (new cljs.core.async.t_cljs$core$async20719(alt_handler__$1,flag__$1,cb__$1,meta20720));
});

}

return (new cljs.core.async.t_cljs$core$async20719(cljs$core$async$alt_handler,flag,cb,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * returns derefable [val port] if immediate, nil if enqueued
 */
cljs.core.async.do_alts = (function cljs$core$async$do_alts(fret,ports,opts){
var flag = cljs.core.async.alt_flag.call(null);
var n = cljs.core.count.call(null,ports);
var idxs = cljs.core.async.random_array.call(null,n);
var priority = new cljs.core.Keyword(null,"priority","priority",1431093715).cljs$core$IFn$_invoke$arity$1(opts);
var ret = (function (){var i = (0);
while(true){
if((i < n)){
var idx = (cljs.core.truth_(priority)?i:(idxs[i]));
var port = cljs.core.nth.call(null,ports,idx);
var wport = ((cljs.core.vector_QMARK_.call(null,port))?port.call(null,(0)):null);
var vbox = (cljs.core.truth_(wport)?(function (){var val = port.call(null,(1));
return cljs.core.async.impl.protocols.put_BANG_.call(null,wport,val,cljs.core.async.alt_handler.call(null,flag,((function (i,val,idx,port,wport,flag,n,idxs,priority){
return (function (p1__20722_SHARP_){
return fret.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__20722_SHARP_,wport], null));
});})(i,val,idx,port,wport,flag,n,idxs,priority))
));
})():cljs.core.async.impl.protocols.take_BANG_.call(null,port,cljs.core.async.alt_handler.call(null,flag,((function (i,idx,port,wport,flag,n,idxs,priority){
return (function (p1__20723_SHARP_){
return fret.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [p1__20723_SHARP_,port], null));
});})(i,idx,port,wport,flag,n,idxs,priority))
)));
if(cljs.core.truth_(vbox)){
return cljs.core.async.impl.channels.box.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.deref.call(null,vbox),(function (){var or__18298__auto__ = wport;
if(cljs.core.truth_(or__18298__auto__)){
return or__18298__auto__;
} else {
return port;
}
})()], null));
} else {
var G__20724 = (i + (1));
i = G__20724;
continue;
}
} else {
return null;
}
break;
}
})();
var or__18298__auto__ = ret;
if(cljs.core.truth_(or__18298__auto__)){
return or__18298__auto__;
} else {
if(cljs.core.contains_QMARK_.call(null,opts,new cljs.core.Keyword(null,"default","default",-1987822328))){
var temp__4425__auto__ = (function (){var and__18286__auto__ = cljs.core.async.impl.protocols.active_QMARK_.call(null,flag);
if(cljs.core.truth_(and__18286__auto__)){
return cljs.core.async.impl.protocols.commit.call(null,flag);
} else {
return and__18286__auto__;
}
})();
if(cljs.core.truth_(temp__4425__auto__)){
var got = temp__4425__auto__;
return cljs.core.async.impl.channels.box.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"default","default",-1987822328).cljs$core$IFn$_invoke$arity$1(opts),new cljs.core.Keyword(null,"default","default",-1987822328)], null));
} else {
return null;
}
} else {
return null;
}
}
});
/**
 * Completes at most one of several channel operations. Must be called
 * inside a (go ...) block. ports is a vector of channel endpoints,
 * which can be either a channel to take from or a vector of
 *   [channel-to-put-to val-to-put], in any combination. Takes will be
 *   made as if by <!, and puts will be made as if by >!. Unless
 *   the :priority option is true, if more than one port operation is
 *   ready a non-deterministic choice will be made. If no operation is
 *   ready and a :default value is supplied, [default-val :default] will
 *   be returned, otherwise alts! will park until the first operation to
 *   become ready completes. Returns [val port] of the completed
 *   operation, where val is the value taken for takes, and a
 *   boolean (true unless already closed, as per put!) for puts.
 * 
 *   opts are passed as :key val ... Supported options:
 * 
 *   :default val - the value to use if none of the operations are immediately ready
 *   :priority true - (default nil) when true, the operations will be tried in order.
 * 
 *   Note: there is no guarantee that the port exps or val exprs will be
 *   used, nor in what order should they be, so they should not be
 *   depended upon for side effects.
 */
cljs.core.async.alts_BANG_ = (function cljs$core$async$alts_BANG_(var_args){
var args__19363__auto__ = [];
var len__19356__auto___20730 = arguments.length;
var i__19357__auto___20731 = (0);
while(true){
if((i__19357__auto___20731 < len__19356__auto___20730)){
args__19363__auto__.push((arguments[i__19357__auto___20731]));

var G__20732 = (i__19357__auto___20731 + (1));
i__19357__auto___20731 = G__20732;
continue;
} else {
}
break;
}

var argseq__19364__auto__ = ((((1) < args__19363__auto__.length))?(new cljs.core.IndexedSeq(args__19363__auto__.slice((1)),(0))):null);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__19364__auto__);
});

cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (ports,p__20727){
var map__20728 = p__20727;
var map__20728__$1 = ((((!((map__20728 == null)))?((((map__20728.cljs$lang$protocol_mask$partition0$ & (64))) || (map__20728.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__20728):map__20728);
var opts = map__20728__$1;
throw (new Error("alts! used not in (go ...) block"));
});

cljs.core.async.alts_BANG_.cljs$lang$maxFixedArity = (1);

cljs.core.async.alts_BANG_.cljs$lang$applyTo = (function (seq20725){
var G__20726 = cljs.core.first.call(null,seq20725);
var seq20725__$1 = cljs.core.next.call(null,seq20725);
return cljs.core.async.alts_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__20726,seq20725__$1);
});
/**
 * Puts a val into port if it's possible to do so immediately.
 *   nil values are not allowed. Never blocks. Returns true if offer succeeds.
 */
cljs.core.async.offer_BANG_ = (function cljs$core$async$offer_BANG_(port,val){
var ret = cljs.core.async.impl.protocols.put_BANG_.call(null,port,val,cljs.core.async.fn_handler.call(null,cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref.call(null,ret);
} else {
return null;
}
});
/**
 * Takes a val from port if it's possible to do so immediately.
 *   Never blocks. Returns value if successful, nil otherwise.
 */
cljs.core.async.poll_BANG_ = (function cljs$core$async$poll_BANG_(port){
var ret = cljs.core.async.impl.protocols.take_BANG_.call(null,port,cljs.core.async.fn_handler.call(null,cljs.core.async.nop,false));
if(cljs.core.truth_(ret)){
return cljs.core.deref.call(null,ret);
} else {
return null;
}
});
/**
 * Takes elements from the from channel and supplies them to the to
 * channel. By default, the to channel will be closed when the from
 * channel closes, but can be determined by the close?  parameter. Will
 * stop consuming the from channel if the to channel closes
 */
cljs.core.async.pipe = (function cljs$core$async$pipe(var_args){
var args20733 = [];
var len__19356__auto___20783 = arguments.length;
var i__19357__auto___20784 = (0);
while(true){
if((i__19357__auto___20784 < len__19356__auto___20783)){
args20733.push((arguments[i__19357__auto___20784]));

var G__20785 = (i__19357__auto___20784 + (1));
i__19357__auto___20784 = G__20785;
continue;
} else {
}
break;
}

var G__20735 = args20733.length;
switch (G__20735) {
case 2:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args20733.length)].join('')));

}
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$2 = (function (from,to){
return cljs.core.async.pipe.call(null,from,to,true);
});

cljs.core.async.pipe.cljs$core$IFn$_invoke$arity$3 = (function (from,to,close_QMARK_){
var c__20620__auto___20787 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___20787){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___20787){
return (function (state_20759){
var state_val_20760 = (state_20759[(1)]);
if((state_val_20760 === (7))){
var inst_20755 = (state_20759[(2)]);
var state_20759__$1 = state_20759;
var statearr_20761_20788 = state_20759__$1;
(statearr_20761_20788[(2)] = inst_20755);

(statearr_20761_20788[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_20760 === (1))){
var state_20759__$1 = state_20759;
var statearr_20762_20789 = state_20759__$1;
(statearr_20762_20789[(2)] = null);

(statearr_20762_20789[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_20760 === (4))){
var inst_20738 = (state_20759[(7)]);
var inst_20738__$1 = (state_20759[(2)]);
var inst_20739 = (inst_20738__$1 == null);
var state_20759__$1 = (function (){var statearr_20763 = state_20759;
(statearr_20763[(7)] = inst_20738__$1);

return statearr_20763;
})();
if(cljs.core.truth_(inst_20739)){
var statearr_20764_20790 = state_20759__$1;
(statearr_20764_20790[(1)] = (5));

} else {
var statearr_20765_20791 = state_20759__$1;
(statearr_20765_20791[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_20760 === (13))){
var state_20759__$1 = state_20759;
var statearr_20766_20792 = state_20759__$1;
(statearr_20766_20792[(2)] = null);

(statearr_20766_20792[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_20760 === (6))){
var inst_20738 = (state_20759[(7)]);
var state_20759__$1 = state_20759;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_20759__$1,(11),to,inst_20738);
} else {
if((state_val_20760 === (3))){
var inst_20757 = (state_20759[(2)]);
var state_20759__$1 = state_20759;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_20759__$1,inst_20757);
} else {
if((state_val_20760 === (12))){
var state_20759__$1 = state_20759;
var statearr_20767_20793 = state_20759__$1;
(statearr_20767_20793[(2)] = null);

(statearr_20767_20793[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_20760 === (2))){
var state_20759__$1 = state_20759;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_20759__$1,(4),from);
} else {
if((state_val_20760 === (11))){
var inst_20748 = (state_20759[(2)]);
var state_20759__$1 = state_20759;
if(cljs.core.truth_(inst_20748)){
var statearr_20768_20794 = state_20759__$1;
(statearr_20768_20794[(1)] = (12));

} else {
var statearr_20769_20795 = state_20759__$1;
(statearr_20769_20795[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_20760 === (9))){
var state_20759__$1 = state_20759;
var statearr_20770_20796 = state_20759__$1;
(statearr_20770_20796[(2)] = null);

(statearr_20770_20796[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_20760 === (5))){
var state_20759__$1 = state_20759;
if(cljs.core.truth_(close_QMARK_)){
var statearr_20771_20797 = state_20759__$1;
(statearr_20771_20797[(1)] = (8));

} else {
var statearr_20772_20798 = state_20759__$1;
(statearr_20772_20798[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_20760 === (14))){
var inst_20753 = (state_20759[(2)]);
var state_20759__$1 = state_20759;
var statearr_20773_20799 = state_20759__$1;
(statearr_20773_20799[(2)] = inst_20753);

(statearr_20773_20799[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_20760 === (10))){
var inst_20745 = (state_20759[(2)]);
var state_20759__$1 = state_20759;
var statearr_20774_20800 = state_20759__$1;
(statearr_20774_20800[(2)] = inst_20745);

(statearr_20774_20800[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_20760 === (8))){
var inst_20742 = cljs.core.async.close_BANG_.call(null,to);
var state_20759__$1 = state_20759;
var statearr_20775_20801 = state_20759__$1;
(statearr_20775_20801[(2)] = inst_20742);

(statearr_20775_20801[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto___20787))
;
return ((function (switch__20508__auto__,c__20620__auto___20787){
return (function() {
var cljs$core$async$state_machine__20509__auto__ = null;
var cljs$core$async$state_machine__20509__auto____0 = (function (){
var statearr_20779 = [null,null,null,null,null,null,null,null];
(statearr_20779[(0)] = cljs$core$async$state_machine__20509__auto__);

(statearr_20779[(1)] = (1));

return statearr_20779;
});
var cljs$core$async$state_machine__20509__auto____1 = (function (state_20759){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_20759);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e20780){if((e20780 instanceof Object)){
var ex__20512__auto__ = e20780;
var statearr_20781_20802 = state_20759;
(statearr_20781_20802[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_20759);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e20780;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__20803 = state_20759;
state_20759 = G__20803;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$state_machine__20509__auto__ = function(state_20759){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__20509__auto____1.call(this,state_20759);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__20509__auto____0;
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__20509__auto____1;
return cljs$core$async$state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___20787))
})();
var state__20622__auto__ = (function (){var statearr_20782 = f__20621__auto__.call(null);
(statearr_20782[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___20787);

return statearr_20782;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___20787))
);


return to;
});

cljs.core.async.pipe.cljs$lang$maxFixedArity = 3;
cljs.core.async.pipeline_STAR_ = (function cljs$core$async$pipeline_STAR_(n,to,xf,from,close_QMARK_,ex_handler,type){
if((n > (0))){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str(cljs.core.pr_str.call(null,cljs.core.list(new cljs.core.Symbol(null,"pos?","pos?",-244377722,null),new cljs.core.Symbol(null,"n","n",-2092305744,null))))].join('')));
}

var jobs = cljs.core.async.chan.call(null,n);
var results = cljs.core.async.chan.call(null,n);
var process = ((function (jobs,results){
return (function (p__20987){
var vec__20988 = p__20987;
var v = cljs.core.nth.call(null,vec__20988,(0),null);
var p = cljs.core.nth.call(null,vec__20988,(1),null);
var job = vec__20988;
if((job == null)){
cljs.core.async.close_BANG_.call(null,results);

return null;
} else {
var res = cljs.core.async.chan.call(null,(1),xf,ex_handler);
var c__20620__auto___21170 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___21170,res,vec__20988,v,p,job,jobs,results){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___21170,res,vec__20988,v,p,job,jobs,results){
return (function (state_20993){
var state_val_20994 = (state_20993[(1)]);
if((state_val_20994 === (1))){
var state_20993__$1 = state_20993;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_20993__$1,(2),res,v);
} else {
if((state_val_20994 === (2))){
var inst_20990 = (state_20993[(2)]);
var inst_20991 = cljs.core.async.close_BANG_.call(null,res);
var state_20993__$1 = (function (){var statearr_20995 = state_20993;
(statearr_20995[(7)] = inst_20990);

return statearr_20995;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_20993__$1,inst_20991);
} else {
return null;
}
}
});})(c__20620__auto___21170,res,vec__20988,v,p,job,jobs,results))
;
return ((function (switch__20508__auto__,c__20620__auto___21170,res,vec__20988,v,p,job,jobs,results){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0 = (function (){
var statearr_20999 = [null,null,null,null,null,null,null,null];
(statearr_20999[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__);

(statearr_20999[(1)] = (1));

return statearr_20999;
});
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1 = (function (state_20993){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_20993);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e21000){if((e21000 instanceof Object)){
var ex__20512__auto__ = e21000;
var statearr_21001_21171 = state_20993;
(statearr_21001_21171[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_20993);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e21000;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__21172 = state_20993;
state_20993 = G__21172;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__ = function(state_20993){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1.call(this,state_20993);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___21170,res,vec__20988,v,p,job,jobs,results))
})();
var state__20622__auto__ = (function (){var statearr_21002 = f__20621__auto__.call(null);
(statearr_21002[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___21170);

return statearr_21002;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___21170,res,vec__20988,v,p,job,jobs,results))
);


cljs.core.async.put_BANG_.call(null,p,res);

return true;
}
});})(jobs,results))
;
var async = ((function (jobs,results,process){
return (function (p__21003){
var vec__21004 = p__21003;
var v = cljs.core.nth.call(null,vec__21004,(0),null);
var p = cljs.core.nth.call(null,vec__21004,(1),null);
var job = vec__21004;
if((job == null)){
cljs.core.async.close_BANG_.call(null,results);

return null;
} else {
var res = cljs.core.async.chan.call(null,(1));
xf.call(null,v,res);

cljs.core.async.put_BANG_.call(null,p,res);

return true;
}
});})(jobs,results,process))
;
var n__19201__auto___21173 = n;
var __21174 = (0);
while(true){
if((__21174 < n__19201__auto___21173)){
var G__21005_21175 = (((type instanceof cljs.core.Keyword))?type.fqn:null);
switch (G__21005_21175) {
case "compute":
var c__20620__auto___21177 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (__21174,c__20620__auto___21177,G__21005_21175,n__19201__auto___21173,jobs,results,process,async){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (__21174,c__20620__auto___21177,G__21005_21175,n__19201__auto___21173,jobs,results,process,async){
return (function (state_21018){
var state_val_21019 = (state_21018[(1)]);
if((state_val_21019 === (1))){
var state_21018__$1 = state_21018;
var statearr_21020_21178 = state_21018__$1;
(statearr_21020_21178[(2)] = null);

(statearr_21020_21178[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21019 === (2))){
var state_21018__$1 = state_21018;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_21018__$1,(4),jobs);
} else {
if((state_val_21019 === (3))){
var inst_21016 = (state_21018[(2)]);
var state_21018__$1 = state_21018;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_21018__$1,inst_21016);
} else {
if((state_val_21019 === (4))){
var inst_21008 = (state_21018[(2)]);
var inst_21009 = process.call(null,inst_21008);
var state_21018__$1 = state_21018;
if(cljs.core.truth_(inst_21009)){
var statearr_21021_21179 = state_21018__$1;
(statearr_21021_21179[(1)] = (5));

} else {
var statearr_21022_21180 = state_21018__$1;
(statearr_21022_21180[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21019 === (5))){
var state_21018__$1 = state_21018;
var statearr_21023_21181 = state_21018__$1;
(statearr_21023_21181[(2)] = null);

(statearr_21023_21181[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21019 === (6))){
var state_21018__$1 = state_21018;
var statearr_21024_21182 = state_21018__$1;
(statearr_21024_21182[(2)] = null);

(statearr_21024_21182[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21019 === (7))){
var inst_21014 = (state_21018[(2)]);
var state_21018__$1 = state_21018;
var statearr_21025_21183 = state_21018__$1;
(statearr_21025_21183[(2)] = inst_21014);

(statearr_21025_21183[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});})(__21174,c__20620__auto___21177,G__21005_21175,n__19201__auto___21173,jobs,results,process,async))
;
return ((function (__21174,switch__20508__auto__,c__20620__auto___21177,G__21005_21175,n__19201__auto___21173,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0 = (function (){
var statearr_21029 = [null,null,null,null,null,null,null];
(statearr_21029[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__);

(statearr_21029[(1)] = (1));

return statearr_21029;
});
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1 = (function (state_21018){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_21018);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e21030){if((e21030 instanceof Object)){
var ex__20512__auto__ = e21030;
var statearr_21031_21184 = state_21018;
(statearr_21031_21184[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_21018);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e21030;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__21185 = state_21018;
state_21018 = G__21185;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__ = function(state_21018){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1.call(this,state_21018);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__;
})()
;})(__21174,switch__20508__auto__,c__20620__auto___21177,G__21005_21175,n__19201__auto___21173,jobs,results,process,async))
})();
var state__20622__auto__ = (function (){var statearr_21032 = f__20621__auto__.call(null);
(statearr_21032[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___21177);

return statearr_21032;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(__21174,c__20620__auto___21177,G__21005_21175,n__19201__auto___21173,jobs,results,process,async))
);


break;
case "async":
var c__20620__auto___21186 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (__21174,c__20620__auto___21186,G__21005_21175,n__19201__auto___21173,jobs,results,process,async){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (__21174,c__20620__auto___21186,G__21005_21175,n__19201__auto___21173,jobs,results,process,async){
return (function (state_21045){
var state_val_21046 = (state_21045[(1)]);
if((state_val_21046 === (1))){
var state_21045__$1 = state_21045;
var statearr_21047_21187 = state_21045__$1;
(statearr_21047_21187[(2)] = null);

(statearr_21047_21187[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21046 === (2))){
var state_21045__$1 = state_21045;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_21045__$1,(4),jobs);
} else {
if((state_val_21046 === (3))){
var inst_21043 = (state_21045[(2)]);
var state_21045__$1 = state_21045;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_21045__$1,inst_21043);
} else {
if((state_val_21046 === (4))){
var inst_21035 = (state_21045[(2)]);
var inst_21036 = async.call(null,inst_21035);
var state_21045__$1 = state_21045;
if(cljs.core.truth_(inst_21036)){
var statearr_21048_21188 = state_21045__$1;
(statearr_21048_21188[(1)] = (5));

} else {
var statearr_21049_21189 = state_21045__$1;
(statearr_21049_21189[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21046 === (5))){
var state_21045__$1 = state_21045;
var statearr_21050_21190 = state_21045__$1;
(statearr_21050_21190[(2)] = null);

(statearr_21050_21190[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21046 === (6))){
var state_21045__$1 = state_21045;
var statearr_21051_21191 = state_21045__$1;
(statearr_21051_21191[(2)] = null);

(statearr_21051_21191[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21046 === (7))){
var inst_21041 = (state_21045[(2)]);
var state_21045__$1 = state_21045;
var statearr_21052_21192 = state_21045__$1;
(statearr_21052_21192[(2)] = inst_21041);

(statearr_21052_21192[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
});})(__21174,c__20620__auto___21186,G__21005_21175,n__19201__auto___21173,jobs,results,process,async))
;
return ((function (__21174,switch__20508__auto__,c__20620__auto___21186,G__21005_21175,n__19201__auto___21173,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0 = (function (){
var statearr_21056 = [null,null,null,null,null,null,null];
(statearr_21056[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__);

(statearr_21056[(1)] = (1));

return statearr_21056;
});
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1 = (function (state_21045){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_21045);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e21057){if((e21057 instanceof Object)){
var ex__20512__auto__ = e21057;
var statearr_21058_21193 = state_21045;
(statearr_21058_21193[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_21045);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e21057;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__21194 = state_21045;
state_21045 = G__21194;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__ = function(state_21045){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1.call(this,state_21045);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__;
})()
;})(__21174,switch__20508__auto__,c__20620__auto___21186,G__21005_21175,n__19201__auto___21173,jobs,results,process,async))
})();
var state__20622__auto__ = (function (){var statearr_21059 = f__20621__auto__.call(null);
(statearr_21059[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___21186);

return statearr_21059;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(__21174,c__20620__auto___21186,G__21005_21175,n__19201__auto___21173,jobs,results,process,async))
);


break;
default:
throw (new Error([cljs.core.str("No matching clause: "),cljs.core.str(type)].join('')));

}

var G__21195 = (__21174 + (1));
__21174 = G__21195;
continue;
} else {
}
break;
}

var c__20620__auto___21196 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___21196,jobs,results,process,async){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___21196,jobs,results,process,async){
return (function (state_21081){
var state_val_21082 = (state_21081[(1)]);
if((state_val_21082 === (1))){
var state_21081__$1 = state_21081;
var statearr_21083_21197 = state_21081__$1;
(statearr_21083_21197[(2)] = null);

(statearr_21083_21197[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21082 === (2))){
var state_21081__$1 = state_21081;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_21081__$1,(4),from);
} else {
if((state_val_21082 === (3))){
var inst_21079 = (state_21081[(2)]);
var state_21081__$1 = state_21081;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_21081__$1,inst_21079);
} else {
if((state_val_21082 === (4))){
var inst_21062 = (state_21081[(7)]);
var inst_21062__$1 = (state_21081[(2)]);
var inst_21063 = (inst_21062__$1 == null);
var state_21081__$1 = (function (){var statearr_21084 = state_21081;
(statearr_21084[(7)] = inst_21062__$1);

return statearr_21084;
})();
if(cljs.core.truth_(inst_21063)){
var statearr_21085_21198 = state_21081__$1;
(statearr_21085_21198[(1)] = (5));

} else {
var statearr_21086_21199 = state_21081__$1;
(statearr_21086_21199[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21082 === (5))){
var inst_21065 = cljs.core.async.close_BANG_.call(null,jobs);
var state_21081__$1 = state_21081;
var statearr_21087_21200 = state_21081__$1;
(statearr_21087_21200[(2)] = inst_21065);

(statearr_21087_21200[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21082 === (6))){
var inst_21062 = (state_21081[(7)]);
var inst_21067 = (state_21081[(8)]);
var inst_21067__$1 = cljs.core.async.chan.call(null,(1));
var inst_21068 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_21069 = [inst_21062,inst_21067__$1];
var inst_21070 = (new cljs.core.PersistentVector(null,2,(5),inst_21068,inst_21069,null));
var state_21081__$1 = (function (){var statearr_21088 = state_21081;
(statearr_21088[(8)] = inst_21067__$1);

return statearr_21088;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_21081__$1,(8),jobs,inst_21070);
} else {
if((state_val_21082 === (7))){
var inst_21077 = (state_21081[(2)]);
var state_21081__$1 = state_21081;
var statearr_21089_21201 = state_21081__$1;
(statearr_21089_21201[(2)] = inst_21077);

(statearr_21089_21201[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21082 === (8))){
var inst_21067 = (state_21081[(8)]);
var inst_21072 = (state_21081[(2)]);
var state_21081__$1 = (function (){var statearr_21090 = state_21081;
(statearr_21090[(9)] = inst_21072);

return statearr_21090;
})();
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_21081__$1,(9),results,inst_21067);
} else {
if((state_val_21082 === (9))){
var inst_21074 = (state_21081[(2)]);
var state_21081__$1 = (function (){var statearr_21091 = state_21081;
(statearr_21091[(10)] = inst_21074);

return statearr_21091;
})();
var statearr_21092_21202 = state_21081__$1;
(statearr_21092_21202[(2)] = null);

(statearr_21092_21202[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
});})(c__20620__auto___21196,jobs,results,process,async))
;
return ((function (switch__20508__auto__,c__20620__auto___21196,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0 = (function (){
var statearr_21096 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_21096[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__);

(statearr_21096[(1)] = (1));

return statearr_21096;
});
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1 = (function (state_21081){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_21081);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e21097){if((e21097 instanceof Object)){
var ex__20512__auto__ = e21097;
var statearr_21098_21203 = state_21081;
(statearr_21098_21203[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_21081);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e21097;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__21204 = state_21081;
state_21081 = G__21204;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__ = function(state_21081){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1.call(this,state_21081);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___21196,jobs,results,process,async))
})();
var state__20622__auto__ = (function (){var statearr_21099 = f__20621__auto__.call(null);
(statearr_21099[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___21196);

return statearr_21099;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___21196,jobs,results,process,async))
);


var c__20620__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto__,jobs,results,process,async){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto__,jobs,results,process,async){
return (function (state_21137){
var state_val_21138 = (state_21137[(1)]);
if((state_val_21138 === (7))){
var inst_21133 = (state_21137[(2)]);
var state_21137__$1 = state_21137;
var statearr_21139_21205 = state_21137__$1;
(statearr_21139_21205[(2)] = inst_21133);

(statearr_21139_21205[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (20))){
var state_21137__$1 = state_21137;
var statearr_21140_21206 = state_21137__$1;
(statearr_21140_21206[(2)] = null);

(statearr_21140_21206[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (1))){
var state_21137__$1 = state_21137;
var statearr_21141_21207 = state_21137__$1;
(statearr_21141_21207[(2)] = null);

(statearr_21141_21207[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (4))){
var inst_21102 = (state_21137[(7)]);
var inst_21102__$1 = (state_21137[(2)]);
var inst_21103 = (inst_21102__$1 == null);
var state_21137__$1 = (function (){var statearr_21142 = state_21137;
(statearr_21142[(7)] = inst_21102__$1);

return statearr_21142;
})();
if(cljs.core.truth_(inst_21103)){
var statearr_21143_21208 = state_21137__$1;
(statearr_21143_21208[(1)] = (5));

} else {
var statearr_21144_21209 = state_21137__$1;
(statearr_21144_21209[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (15))){
var inst_21115 = (state_21137[(8)]);
var state_21137__$1 = state_21137;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_21137__$1,(18),to,inst_21115);
} else {
if((state_val_21138 === (21))){
var inst_21128 = (state_21137[(2)]);
var state_21137__$1 = state_21137;
var statearr_21145_21210 = state_21137__$1;
(statearr_21145_21210[(2)] = inst_21128);

(statearr_21145_21210[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (13))){
var inst_21130 = (state_21137[(2)]);
var state_21137__$1 = (function (){var statearr_21146 = state_21137;
(statearr_21146[(9)] = inst_21130);

return statearr_21146;
})();
var statearr_21147_21211 = state_21137__$1;
(statearr_21147_21211[(2)] = null);

(statearr_21147_21211[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (6))){
var inst_21102 = (state_21137[(7)]);
var state_21137__$1 = state_21137;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_21137__$1,(11),inst_21102);
} else {
if((state_val_21138 === (17))){
var inst_21123 = (state_21137[(2)]);
var state_21137__$1 = state_21137;
if(cljs.core.truth_(inst_21123)){
var statearr_21148_21212 = state_21137__$1;
(statearr_21148_21212[(1)] = (19));

} else {
var statearr_21149_21213 = state_21137__$1;
(statearr_21149_21213[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (3))){
var inst_21135 = (state_21137[(2)]);
var state_21137__$1 = state_21137;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_21137__$1,inst_21135);
} else {
if((state_val_21138 === (12))){
var inst_21112 = (state_21137[(10)]);
var state_21137__$1 = state_21137;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_21137__$1,(14),inst_21112);
} else {
if((state_val_21138 === (2))){
var state_21137__$1 = state_21137;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_21137__$1,(4),results);
} else {
if((state_val_21138 === (19))){
var state_21137__$1 = state_21137;
var statearr_21150_21214 = state_21137__$1;
(statearr_21150_21214[(2)] = null);

(statearr_21150_21214[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (11))){
var inst_21112 = (state_21137[(2)]);
var state_21137__$1 = (function (){var statearr_21151 = state_21137;
(statearr_21151[(10)] = inst_21112);

return statearr_21151;
})();
var statearr_21152_21215 = state_21137__$1;
(statearr_21152_21215[(2)] = null);

(statearr_21152_21215[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (9))){
var state_21137__$1 = state_21137;
var statearr_21153_21216 = state_21137__$1;
(statearr_21153_21216[(2)] = null);

(statearr_21153_21216[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (5))){
var state_21137__$1 = state_21137;
if(cljs.core.truth_(close_QMARK_)){
var statearr_21154_21217 = state_21137__$1;
(statearr_21154_21217[(1)] = (8));

} else {
var statearr_21155_21218 = state_21137__$1;
(statearr_21155_21218[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (14))){
var inst_21115 = (state_21137[(8)]);
var inst_21117 = (state_21137[(11)]);
var inst_21115__$1 = (state_21137[(2)]);
var inst_21116 = (inst_21115__$1 == null);
var inst_21117__$1 = cljs.core.not.call(null,inst_21116);
var state_21137__$1 = (function (){var statearr_21156 = state_21137;
(statearr_21156[(8)] = inst_21115__$1);

(statearr_21156[(11)] = inst_21117__$1);

return statearr_21156;
})();
if(inst_21117__$1){
var statearr_21157_21219 = state_21137__$1;
(statearr_21157_21219[(1)] = (15));

} else {
var statearr_21158_21220 = state_21137__$1;
(statearr_21158_21220[(1)] = (16));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (16))){
var inst_21117 = (state_21137[(11)]);
var state_21137__$1 = state_21137;
var statearr_21159_21221 = state_21137__$1;
(statearr_21159_21221[(2)] = inst_21117);

(statearr_21159_21221[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (10))){
var inst_21109 = (state_21137[(2)]);
var state_21137__$1 = state_21137;
var statearr_21160_21222 = state_21137__$1;
(statearr_21160_21222[(2)] = inst_21109);

(statearr_21160_21222[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (18))){
var inst_21120 = (state_21137[(2)]);
var state_21137__$1 = state_21137;
var statearr_21161_21223 = state_21137__$1;
(statearr_21161_21223[(2)] = inst_21120);

(statearr_21161_21223[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21138 === (8))){
var inst_21106 = cljs.core.async.close_BANG_.call(null,to);
var state_21137__$1 = state_21137;
var statearr_21162_21224 = state_21137__$1;
(statearr_21162_21224[(2)] = inst_21106);

(statearr_21162_21224[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto__,jobs,results,process,async))
;
return ((function (switch__20508__auto__,c__20620__auto__,jobs,results,process,async){
return (function() {
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__ = null;
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0 = (function (){
var statearr_21166 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_21166[(0)] = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__);

(statearr_21166[(1)] = (1));

return statearr_21166;
});
var cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1 = (function (state_21137){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_21137);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e21167){if((e21167 instanceof Object)){
var ex__20512__auto__ = e21167;
var statearr_21168_21225 = state_21137;
(statearr_21168_21225[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_21137);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e21167;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__21226 = state_21137;
state_21137 = G__21226;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__ = function(state_21137){
switch(arguments.length){
case 0:
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1.call(this,state_21137);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____0;
cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$pipeline_STAR__$_state_machine__20509__auto____1;
return cljs$core$async$pipeline_STAR__$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto__,jobs,results,process,async))
})();
var state__20622__auto__ = (function (){var statearr_21169 = f__20621__auto__.call(null);
(statearr_21169[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto__);

return statearr_21169;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto__,jobs,results,process,async))
);

return c__20620__auto__;
});
/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the async function af, with parallelism n. af
 *   must be a function of two arguments, the first an input value and
 *   the second a channel on which to place the result(s). af must close!
 *   the channel before returning.  The presumption is that af will
 *   return immediately, having launched some asynchronous operation
 *   whose completion/callback will manipulate the result channel. Outputs
 *   will be returned in order relative to  the inputs. By default, the to
 *   channel will be closed when the from channel closes, but can be
 *   determined by the close?  parameter. Will stop consuming the from
 *   channel if the to channel closes.
 */
cljs.core.async.pipeline_async = (function cljs$core$async$pipeline_async(var_args){
var args21227 = [];
var len__19356__auto___21230 = arguments.length;
var i__19357__auto___21231 = (0);
while(true){
if((i__19357__auto___21231 < len__19356__auto___21230)){
args21227.push((arguments[i__19357__auto___21231]));

var G__21232 = (i__19357__auto___21231 + (1));
i__19357__auto___21231 = G__21232;
continue;
} else {
}
break;
}

var G__21229 = args21227.length;
switch (G__21229) {
case 4:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args21227.length)].join('')));

}
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$4 = (function (n,to,af,from){
return cljs.core.async.pipeline_async.call(null,n,to,af,from,true);
});

cljs.core.async.pipeline_async.cljs$core$IFn$_invoke$arity$5 = (function (n,to,af,from,close_QMARK_){
return cljs.core.async.pipeline_STAR_.call(null,n,to,af,from,close_QMARK_,null,new cljs.core.Keyword(null,"async","async",1050769601));
});

cljs.core.async.pipeline_async.cljs$lang$maxFixedArity = 5;
/**
 * Takes elements from the from channel and supplies them to the to
 *   channel, subject to the transducer xf, with parallelism n. Because
 *   it is parallel, the transducer will be applied independently to each
 *   element, not across elements, and may produce zero or more outputs
 *   per input.  Outputs will be returned in order relative to the
 *   inputs. By default, the to channel will be closed when the from
 *   channel closes, but can be determined by the close?  parameter. Will
 *   stop consuming the from channel if the to channel closes.
 * 
 *   Note this is supplied for API compatibility with the Clojure version.
 *   Values of N > 1 will not result in actual concurrency in a
 *   single-threaded runtime.
 */
cljs.core.async.pipeline = (function cljs$core$async$pipeline(var_args){
var args21234 = [];
var len__19356__auto___21237 = arguments.length;
var i__19357__auto___21238 = (0);
while(true){
if((i__19357__auto___21238 < len__19356__auto___21237)){
args21234.push((arguments[i__19357__auto___21238]));

var G__21239 = (i__19357__auto___21238 + (1));
i__19357__auto___21238 = G__21239;
continue;
} else {
}
break;
}

var G__21236 = args21234.length;
switch (G__21236) {
case 4:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
case 5:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]));

break;
case 6:
return cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]),(arguments[(4)]),(arguments[(5)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args21234.length)].join('')));

}
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$4 = (function (n,to,xf,from){
return cljs.core.async.pipeline.call(null,n,to,xf,from,true);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$5 = (function (n,to,xf,from,close_QMARK_){
return cljs.core.async.pipeline.call(null,n,to,xf,from,close_QMARK_,null);
});

cljs.core.async.pipeline.cljs$core$IFn$_invoke$arity$6 = (function (n,to,xf,from,close_QMARK_,ex_handler){
return cljs.core.async.pipeline_STAR_.call(null,n,to,xf,from,close_QMARK_,ex_handler,new cljs.core.Keyword(null,"compute","compute",1555393130));
});

cljs.core.async.pipeline.cljs$lang$maxFixedArity = 6;
/**
 * Takes a predicate and a source channel and returns a vector of two
 *   channels, the first of which will contain the values for which the
 *   predicate returned true, the second those for which it returned
 *   false.
 * 
 *   The out channels will be unbuffered by default, or two buf-or-ns can
 *   be supplied. The channels will close after the source channel has
 *   closed.
 */
cljs.core.async.split = (function cljs$core$async$split(var_args){
var args21241 = [];
var len__19356__auto___21294 = arguments.length;
var i__19357__auto___21295 = (0);
while(true){
if((i__19357__auto___21295 < len__19356__auto___21294)){
args21241.push((arguments[i__19357__auto___21295]));

var G__21296 = (i__19357__auto___21295 + (1));
i__19357__auto___21295 = G__21296;
continue;
} else {
}
break;
}

var G__21243 = args21241.length;
switch (G__21243) {
case 2:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 4:
return cljs.core.async.split.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args21241.length)].join('')));

}
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.split.call(null,p,ch,null,null);
});

cljs.core.async.split.cljs$core$IFn$_invoke$arity$4 = (function (p,ch,t_buf_or_n,f_buf_or_n){
var tc = cljs.core.async.chan.call(null,t_buf_or_n);
var fc = cljs.core.async.chan.call(null,f_buf_or_n);
var c__20620__auto___21298 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___21298,tc,fc){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___21298,tc,fc){
return (function (state_21269){
var state_val_21270 = (state_21269[(1)]);
if((state_val_21270 === (7))){
var inst_21265 = (state_21269[(2)]);
var state_21269__$1 = state_21269;
var statearr_21271_21299 = state_21269__$1;
(statearr_21271_21299[(2)] = inst_21265);

(statearr_21271_21299[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21270 === (1))){
var state_21269__$1 = state_21269;
var statearr_21272_21300 = state_21269__$1;
(statearr_21272_21300[(2)] = null);

(statearr_21272_21300[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21270 === (4))){
var inst_21246 = (state_21269[(7)]);
var inst_21246__$1 = (state_21269[(2)]);
var inst_21247 = (inst_21246__$1 == null);
var state_21269__$1 = (function (){var statearr_21273 = state_21269;
(statearr_21273[(7)] = inst_21246__$1);

return statearr_21273;
})();
if(cljs.core.truth_(inst_21247)){
var statearr_21274_21301 = state_21269__$1;
(statearr_21274_21301[(1)] = (5));

} else {
var statearr_21275_21302 = state_21269__$1;
(statearr_21275_21302[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21270 === (13))){
var state_21269__$1 = state_21269;
var statearr_21276_21303 = state_21269__$1;
(statearr_21276_21303[(2)] = null);

(statearr_21276_21303[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21270 === (6))){
var inst_21246 = (state_21269[(7)]);
var inst_21252 = p.call(null,inst_21246);
var state_21269__$1 = state_21269;
if(cljs.core.truth_(inst_21252)){
var statearr_21277_21304 = state_21269__$1;
(statearr_21277_21304[(1)] = (9));

} else {
var statearr_21278_21305 = state_21269__$1;
(statearr_21278_21305[(1)] = (10));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21270 === (3))){
var inst_21267 = (state_21269[(2)]);
var state_21269__$1 = state_21269;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_21269__$1,inst_21267);
} else {
if((state_val_21270 === (12))){
var state_21269__$1 = state_21269;
var statearr_21279_21306 = state_21269__$1;
(statearr_21279_21306[(2)] = null);

(statearr_21279_21306[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21270 === (2))){
var state_21269__$1 = state_21269;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_21269__$1,(4),ch);
} else {
if((state_val_21270 === (11))){
var inst_21246 = (state_21269[(7)]);
var inst_21256 = (state_21269[(2)]);
var state_21269__$1 = state_21269;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_21269__$1,(8),inst_21256,inst_21246);
} else {
if((state_val_21270 === (9))){
var state_21269__$1 = state_21269;
var statearr_21280_21307 = state_21269__$1;
(statearr_21280_21307[(2)] = tc);

(statearr_21280_21307[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21270 === (5))){
var inst_21249 = cljs.core.async.close_BANG_.call(null,tc);
var inst_21250 = cljs.core.async.close_BANG_.call(null,fc);
var state_21269__$1 = (function (){var statearr_21281 = state_21269;
(statearr_21281[(8)] = inst_21249);

return statearr_21281;
})();
var statearr_21282_21308 = state_21269__$1;
(statearr_21282_21308[(2)] = inst_21250);

(statearr_21282_21308[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21270 === (14))){
var inst_21263 = (state_21269[(2)]);
var state_21269__$1 = state_21269;
var statearr_21283_21309 = state_21269__$1;
(statearr_21283_21309[(2)] = inst_21263);

(statearr_21283_21309[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21270 === (10))){
var state_21269__$1 = state_21269;
var statearr_21284_21310 = state_21269__$1;
(statearr_21284_21310[(2)] = fc);

(statearr_21284_21310[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21270 === (8))){
var inst_21258 = (state_21269[(2)]);
var state_21269__$1 = state_21269;
if(cljs.core.truth_(inst_21258)){
var statearr_21285_21311 = state_21269__$1;
(statearr_21285_21311[(1)] = (12));

} else {
var statearr_21286_21312 = state_21269__$1;
(statearr_21286_21312[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto___21298,tc,fc))
;
return ((function (switch__20508__auto__,c__20620__auto___21298,tc,fc){
return (function() {
var cljs$core$async$state_machine__20509__auto__ = null;
var cljs$core$async$state_machine__20509__auto____0 = (function (){
var statearr_21290 = [null,null,null,null,null,null,null,null,null];
(statearr_21290[(0)] = cljs$core$async$state_machine__20509__auto__);

(statearr_21290[(1)] = (1));

return statearr_21290;
});
var cljs$core$async$state_machine__20509__auto____1 = (function (state_21269){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_21269);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e21291){if((e21291 instanceof Object)){
var ex__20512__auto__ = e21291;
var statearr_21292_21313 = state_21269;
(statearr_21292_21313[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_21269);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e21291;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__21314 = state_21269;
state_21269 = G__21314;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$state_machine__20509__auto__ = function(state_21269){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__20509__auto____1.call(this,state_21269);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__20509__auto____0;
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__20509__auto____1;
return cljs$core$async$state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___21298,tc,fc))
})();
var state__20622__auto__ = (function (){var statearr_21293 = f__20621__auto__.call(null);
(statearr_21293[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___21298);

return statearr_21293;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___21298,tc,fc))
);


return new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [tc,fc], null);
});

cljs.core.async.split.cljs$lang$maxFixedArity = 4;
/**
 * f should be a function of 2 arguments. Returns a channel containing
 *   the single result of applying f to init and the first item from the
 *   channel, then applying f to that result and the 2nd item, etc. If
 *   the channel closes without yielding items, returns init and f is not
 *   called. ch must close before reduce produces a result.
 */
cljs.core.async.reduce = (function cljs$core$async$reduce(f,init,ch){
var c__20620__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto__){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto__){
return (function (state_21378){
var state_val_21379 = (state_21378[(1)]);
if((state_val_21379 === (7))){
var inst_21374 = (state_21378[(2)]);
var state_21378__$1 = state_21378;
var statearr_21380_21401 = state_21378__$1;
(statearr_21380_21401[(2)] = inst_21374);

(statearr_21380_21401[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21379 === (1))){
var inst_21358 = init;
var state_21378__$1 = (function (){var statearr_21381 = state_21378;
(statearr_21381[(7)] = inst_21358);

return statearr_21381;
})();
var statearr_21382_21402 = state_21378__$1;
(statearr_21382_21402[(2)] = null);

(statearr_21382_21402[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21379 === (4))){
var inst_21361 = (state_21378[(8)]);
var inst_21361__$1 = (state_21378[(2)]);
var inst_21362 = (inst_21361__$1 == null);
var state_21378__$1 = (function (){var statearr_21383 = state_21378;
(statearr_21383[(8)] = inst_21361__$1);

return statearr_21383;
})();
if(cljs.core.truth_(inst_21362)){
var statearr_21384_21403 = state_21378__$1;
(statearr_21384_21403[(1)] = (5));

} else {
var statearr_21385_21404 = state_21378__$1;
(statearr_21385_21404[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21379 === (6))){
var inst_21358 = (state_21378[(7)]);
var inst_21365 = (state_21378[(9)]);
var inst_21361 = (state_21378[(8)]);
var inst_21365__$1 = f.call(null,inst_21358,inst_21361);
var inst_21366 = cljs.core.reduced_QMARK_.call(null,inst_21365__$1);
var state_21378__$1 = (function (){var statearr_21386 = state_21378;
(statearr_21386[(9)] = inst_21365__$1);

return statearr_21386;
})();
if(inst_21366){
var statearr_21387_21405 = state_21378__$1;
(statearr_21387_21405[(1)] = (8));

} else {
var statearr_21388_21406 = state_21378__$1;
(statearr_21388_21406[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21379 === (3))){
var inst_21376 = (state_21378[(2)]);
var state_21378__$1 = state_21378;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_21378__$1,inst_21376);
} else {
if((state_val_21379 === (2))){
var state_21378__$1 = state_21378;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_21378__$1,(4),ch);
} else {
if((state_val_21379 === (9))){
var inst_21365 = (state_21378[(9)]);
var inst_21358 = inst_21365;
var state_21378__$1 = (function (){var statearr_21389 = state_21378;
(statearr_21389[(7)] = inst_21358);

return statearr_21389;
})();
var statearr_21390_21407 = state_21378__$1;
(statearr_21390_21407[(2)] = null);

(statearr_21390_21407[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21379 === (5))){
var inst_21358 = (state_21378[(7)]);
var state_21378__$1 = state_21378;
var statearr_21391_21408 = state_21378__$1;
(statearr_21391_21408[(2)] = inst_21358);

(statearr_21391_21408[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21379 === (10))){
var inst_21372 = (state_21378[(2)]);
var state_21378__$1 = state_21378;
var statearr_21392_21409 = state_21378__$1;
(statearr_21392_21409[(2)] = inst_21372);

(statearr_21392_21409[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21379 === (8))){
var inst_21365 = (state_21378[(9)]);
var inst_21368 = cljs.core.deref.call(null,inst_21365);
var state_21378__$1 = state_21378;
var statearr_21393_21410 = state_21378__$1;
(statearr_21393_21410[(2)] = inst_21368);

(statearr_21393_21410[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto__))
;
return ((function (switch__20508__auto__,c__20620__auto__){
return (function() {
var cljs$core$async$reduce_$_state_machine__20509__auto__ = null;
var cljs$core$async$reduce_$_state_machine__20509__auto____0 = (function (){
var statearr_21397 = [null,null,null,null,null,null,null,null,null,null];
(statearr_21397[(0)] = cljs$core$async$reduce_$_state_machine__20509__auto__);

(statearr_21397[(1)] = (1));

return statearr_21397;
});
var cljs$core$async$reduce_$_state_machine__20509__auto____1 = (function (state_21378){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_21378);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e21398){if((e21398 instanceof Object)){
var ex__20512__auto__ = e21398;
var statearr_21399_21411 = state_21378;
(statearr_21399_21411[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_21378);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e21398;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__21412 = state_21378;
state_21378 = G__21412;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$reduce_$_state_machine__20509__auto__ = function(state_21378){
switch(arguments.length){
case 0:
return cljs$core$async$reduce_$_state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$reduce_$_state_machine__20509__auto____1.call(this,state_21378);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$reduce_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$reduce_$_state_machine__20509__auto____0;
cljs$core$async$reduce_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$reduce_$_state_machine__20509__auto____1;
return cljs$core$async$reduce_$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto__))
})();
var state__20622__auto__ = (function (){var statearr_21400 = f__20621__auto__.call(null);
(statearr_21400[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto__);

return statearr_21400;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto__))
);

return c__20620__auto__;
});
/**
 * Puts the contents of coll into the supplied channel.
 * 
 *   By default the channel will be closed after the items are copied,
 *   but can be determined by the close? parameter.
 * 
 *   Returns a channel which will close after the items are copied.
 */
cljs.core.async.onto_chan = (function cljs$core$async$onto_chan(var_args){
var args21413 = [];
var len__19356__auto___21465 = arguments.length;
var i__19357__auto___21466 = (0);
while(true){
if((i__19357__auto___21466 < len__19356__auto___21465)){
args21413.push((arguments[i__19357__auto___21466]));

var G__21467 = (i__19357__auto___21466 + (1));
i__19357__auto___21466 = G__21467;
continue;
} else {
}
break;
}

var G__21415 = args21413.length;
switch (G__21415) {
case 2:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args21413.length)].join('')));

}
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$2 = (function (ch,coll){
return cljs.core.async.onto_chan.call(null,ch,coll,true);
});

cljs.core.async.onto_chan.cljs$core$IFn$_invoke$arity$3 = (function (ch,coll,close_QMARK_){
var c__20620__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto__){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto__){
return (function (state_21440){
var state_val_21441 = (state_21440[(1)]);
if((state_val_21441 === (7))){
var inst_21422 = (state_21440[(2)]);
var state_21440__$1 = state_21440;
var statearr_21442_21469 = state_21440__$1;
(statearr_21442_21469[(2)] = inst_21422);

(statearr_21442_21469[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21441 === (1))){
var inst_21416 = cljs.core.seq.call(null,coll);
var inst_21417 = inst_21416;
var state_21440__$1 = (function (){var statearr_21443 = state_21440;
(statearr_21443[(7)] = inst_21417);

return statearr_21443;
})();
var statearr_21444_21470 = state_21440__$1;
(statearr_21444_21470[(2)] = null);

(statearr_21444_21470[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21441 === (4))){
var inst_21417 = (state_21440[(7)]);
var inst_21420 = cljs.core.first.call(null,inst_21417);
var state_21440__$1 = state_21440;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_21440__$1,(7),ch,inst_21420);
} else {
if((state_val_21441 === (13))){
var inst_21434 = (state_21440[(2)]);
var state_21440__$1 = state_21440;
var statearr_21445_21471 = state_21440__$1;
(statearr_21445_21471[(2)] = inst_21434);

(statearr_21445_21471[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21441 === (6))){
var inst_21425 = (state_21440[(2)]);
var state_21440__$1 = state_21440;
if(cljs.core.truth_(inst_21425)){
var statearr_21446_21472 = state_21440__$1;
(statearr_21446_21472[(1)] = (8));

} else {
var statearr_21447_21473 = state_21440__$1;
(statearr_21447_21473[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21441 === (3))){
var inst_21438 = (state_21440[(2)]);
var state_21440__$1 = state_21440;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_21440__$1,inst_21438);
} else {
if((state_val_21441 === (12))){
var state_21440__$1 = state_21440;
var statearr_21448_21474 = state_21440__$1;
(statearr_21448_21474[(2)] = null);

(statearr_21448_21474[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21441 === (2))){
var inst_21417 = (state_21440[(7)]);
var state_21440__$1 = state_21440;
if(cljs.core.truth_(inst_21417)){
var statearr_21449_21475 = state_21440__$1;
(statearr_21449_21475[(1)] = (4));

} else {
var statearr_21450_21476 = state_21440__$1;
(statearr_21450_21476[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21441 === (11))){
var inst_21431 = cljs.core.async.close_BANG_.call(null,ch);
var state_21440__$1 = state_21440;
var statearr_21451_21477 = state_21440__$1;
(statearr_21451_21477[(2)] = inst_21431);

(statearr_21451_21477[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21441 === (9))){
var state_21440__$1 = state_21440;
if(cljs.core.truth_(close_QMARK_)){
var statearr_21452_21478 = state_21440__$1;
(statearr_21452_21478[(1)] = (11));

} else {
var statearr_21453_21479 = state_21440__$1;
(statearr_21453_21479[(1)] = (12));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21441 === (5))){
var inst_21417 = (state_21440[(7)]);
var state_21440__$1 = state_21440;
var statearr_21454_21480 = state_21440__$1;
(statearr_21454_21480[(2)] = inst_21417);

(statearr_21454_21480[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21441 === (10))){
var inst_21436 = (state_21440[(2)]);
var state_21440__$1 = state_21440;
var statearr_21455_21481 = state_21440__$1;
(statearr_21455_21481[(2)] = inst_21436);

(statearr_21455_21481[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21441 === (8))){
var inst_21417 = (state_21440[(7)]);
var inst_21427 = cljs.core.next.call(null,inst_21417);
var inst_21417__$1 = inst_21427;
var state_21440__$1 = (function (){var statearr_21456 = state_21440;
(statearr_21456[(7)] = inst_21417__$1);

return statearr_21456;
})();
var statearr_21457_21482 = state_21440__$1;
(statearr_21457_21482[(2)] = null);

(statearr_21457_21482[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto__))
;
return ((function (switch__20508__auto__,c__20620__auto__){
return (function() {
var cljs$core$async$state_machine__20509__auto__ = null;
var cljs$core$async$state_machine__20509__auto____0 = (function (){
var statearr_21461 = [null,null,null,null,null,null,null,null];
(statearr_21461[(0)] = cljs$core$async$state_machine__20509__auto__);

(statearr_21461[(1)] = (1));

return statearr_21461;
});
var cljs$core$async$state_machine__20509__auto____1 = (function (state_21440){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_21440);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e21462){if((e21462 instanceof Object)){
var ex__20512__auto__ = e21462;
var statearr_21463_21483 = state_21440;
(statearr_21463_21483[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_21440);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e21462;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__21484 = state_21440;
state_21440 = G__21484;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$state_machine__20509__auto__ = function(state_21440){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__20509__auto____1.call(this,state_21440);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__20509__auto____0;
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__20509__auto____1;
return cljs$core$async$state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto__))
})();
var state__20622__auto__ = (function (){var statearr_21464 = f__20621__auto__.call(null);
(statearr_21464[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto__);

return statearr_21464;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto__))
);

return c__20620__auto__;
});

cljs.core.async.onto_chan.cljs$lang$maxFixedArity = 3;
/**
 * Creates and returns a channel which contains the contents of coll,
 *   closing when exhausted.
 */
cljs.core.async.to_chan = (function cljs$core$async$to_chan(coll){
var ch = cljs.core.async.chan.call(null,cljs.core.bounded_count.call(null,(100),coll));
cljs.core.async.onto_chan.call(null,ch,coll);

return ch;
});

/**
 * @interface
 */
cljs.core.async.Mux = function(){};

cljs.core.async.muxch_STAR_ = (function cljs$core$async$muxch_STAR_(_){
if((!((_ == null))) && (!((_.cljs$core$async$Mux$muxch_STAR_$arity$1 == null)))){
return _.cljs$core$async$Mux$muxch_STAR_$arity$1(_);
} else {
var x__18953__auto__ = (((_ == null))?null:_);
var m__18954__auto__ = (cljs.core.async.muxch_STAR_[goog.typeOf(x__18953__auto__)]);
if(!((m__18954__auto__ == null))){
return m__18954__auto__.call(null,_);
} else {
var m__18954__auto____$1 = (cljs.core.async.muxch_STAR_["_"]);
if(!((m__18954__auto____$1 == null))){
return m__18954__auto____$1.call(null,_);
} else {
throw cljs.core.missing_protocol.call(null,"Mux.muxch*",_);
}
}
}
});


/**
 * @interface
 */
cljs.core.async.Mult = function(){};

cljs.core.async.tap_STAR_ = (function cljs$core$async$tap_STAR_(m,ch,close_QMARK_){
if((!((m == null))) && (!((m.cljs$core$async$Mult$tap_STAR_$arity$3 == null)))){
return m.cljs$core$async$Mult$tap_STAR_$arity$3(m,ch,close_QMARK_);
} else {
var x__18953__auto__ = (((m == null))?null:m);
var m__18954__auto__ = (cljs.core.async.tap_STAR_[goog.typeOf(x__18953__auto__)]);
if(!((m__18954__auto__ == null))){
return m__18954__auto__.call(null,m,ch,close_QMARK_);
} else {
var m__18954__auto____$1 = (cljs.core.async.tap_STAR_["_"]);
if(!((m__18954__auto____$1 == null))){
return m__18954__auto____$1.call(null,m,ch,close_QMARK_);
} else {
throw cljs.core.missing_protocol.call(null,"Mult.tap*",m);
}
}
}
});

cljs.core.async.untap_STAR_ = (function cljs$core$async$untap_STAR_(m,ch){
if((!((m == null))) && (!((m.cljs$core$async$Mult$untap_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mult$untap_STAR_$arity$2(m,ch);
} else {
var x__18953__auto__ = (((m == null))?null:m);
var m__18954__auto__ = (cljs.core.async.untap_STAR_[goog.typeOf(x__18953__auto__)]);
if(!((m__18954__auto__ == null))){
return m__18954__auto__.call(null,m,ch);
} else {
var m__18954__auto____$1 = (cljs.core.async.untap_STAR_["_"]);
if(!((m__18954__auto____$1 == null))){
return m__18954__auto____$1.call(null,m,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Mult.untap*",m);
}
}
}
});

cljs.core.async.untap_all_STAR_ = (function cljs$core$async$untap_all_STAR_(m){
if((!((m == null))) && (!((m.cljs$core$async$Mult$untap_all_STAR_$arity$1 == null)))){
return m.cljs$core$async$Mult$untap_all_STAR_$arity$1(m);
} else {
var x__18953__auto__ = (((m == null))?null:m);
var m__18954__auto__ = (cljs.core.async.untap_all_STAR_[goog.typeOf(x__18953__auto__)]);
if(!((m__18954__auto__ == null))){
return m__18954__auto__.call(null,m);
} else {
var m__18954__auto____$1 = (cljs.core.async.untap_all_STAR_["_"]);
if(!((m__18954__auto____$1 == null))){
return m__18954__auto____$1.call(null,m);
} else {
throw cljs.core.missing_protocol.call(null,"Mult.untap-all*",m);
}
}
}
});

/**
 * Creates and returns a mult(iple) of the supplied channel. Channels
 *   containing copies of the channel can be created with 'tap', and
 *   detached with 'untap'.
 * 
 *   Each item is distributed to all taps in parallel and synchronously,
 *   i.e. each tap must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow taps from holding up the mult.
 * 
 *   Items received when there are no taps get dropped.
 * 
 *   If a tap puts to a closed channel, it will be removed from the mult.
 */
cljs.core.async.mult = (function cljs$core$async$mult(ch){
var cs = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var m = (function (){
if(typeof cljs.core.async.t_cljs$core$async21706 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Mult}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async21706 = (function (mult,ch,cs,meta21707){
this.mult = mult;
this.ch = ch;
this.cs = cs;
this.meta21707 = meta21707;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async21706.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs){
return (function (_21708,meta21707__$1){
var self__ = this;
var _21708__$1 = this;
return (new cljs.core.async.t_cljs$core$async21706(self__.mult,self__.ch,self__.cs,meta21707__$1));
});})(cs))
;

cljs.core.async.t_cljs$core$async21706.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs){
return (function (_21708){
var self__ = this;
var _21708__$1 = this;
return self__.meta21707;
});})(cs))
;

cljs.core.async.t_cljs$core$async21706.prototype.cljs$core$async$Mux$ = true;

cljs.core.async.t_cljs$core$async21706.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(cs))
;

cljs.core.async.t_cljs$core$async21706.prototype.cljs$core$async$Mult$ = true;

cljs.core.async.t_cljs$core$async21706.prototype.cljs$core$async$Mult$tap_STAR_$arity$3 = ((function (cs){
return (function (_,ch__$1,close_QMARK_){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.assoc,ch__$1,close_QMARK_);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async21706.prototype.cljs$core$async$Mult$untap_STAR_$arity$2 = ((function (cs){
return (function (_,ch__$1){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.dissoc,ch__$1);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async21706.prototype.cljs$core$async$Mult$untap_all_STAR_$arity$1 = ((function (cs){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_.call(null,self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return null;
});})(cs))
;

cljs.core.async.t_cljs$core$async21706.getBasis = ((function (cs){
return (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"mult","mult",-1187640995,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"ch","ch",1085813622,null)], null))),new cljs.core.Keyword(null,"doc","doc",1913296891),"Creates and returns a mult(iple) of the supplied channel. Channels\n  containing copies of the channel can be created with 'tap', and\n  detached with 'untap'.\n\n  Each item is distributed to all taps in parallel and synchronously,\n  i.e. each tap must accept before the next item is distributed. Use\n  buffering/windowing to prevent slow taps from holding up the mult.\n\n  Items received when there are no taps get dropped.\n\n  If a tap puts to a closed channel, it will be removed from the mult."], null)),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"cs","cs",-117024463,null),new cljs.core.Symbol(null,"meta21707","meta21707",1324571014,null)], null);
});})(cs))
;

cljs.core.async.t_cljs$core$async21706.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async21706.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async21706";

cljs.core.async.t_cljs$core$async21706.cljs$lang$ctorPrWriter = ((function (cs){
return (function (this__18896__auto__,writer__18897__auto__,opt__18898__auto__){
return cljs.core._write.call(null,writer__18897__auto__,"cljs.core.async/t_cljs$core$async21706");
});})(cs))
;

cljs.core.async.__GT_t_cljs$core$async21706 = ((function (cs){
return (function cljs$core$async$mult_$___GT_t_cljs$core$async21706(mult__$1,ch__$1,cs__$1,meta21707){
return (new cljs.core.async.t_cljs$core$async21706(mult__$1,ch__$1,cs__$1,meta21707));
});})(cs))
;

}

return (new cljs.core.async.t_cljs$core$async21706(cljs$core$async$mult,ch,cs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var dchan = cljs.core.async.chan.call(null,(1));
var dctr = cljs.core.atom.call(null,null);
var done = ((function (cs,m,dchan,dctr){
return (function (_){
if((cljs.core.swap_BANG_.call(null,dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.call(null,dchan,true);
} else {
return null;
}
});})(cs,m,dchan,dctr))
;
var c__20620__auto___21927 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___21927,cs,m,dchan,dctr,done){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___21927,cs,m,dchan,dctr,done){
return (function (state_21839){
var state_val_21840 = (state_21839[(1)]);
if((state_val_21840 === (7))){
var inst_21835 = (state_21839[(2)]);
var state_21839__$1 = state_21839;
var statearr_21841_21928 = state_21839__$1;
(statearr_21841_21928[(2)] = inst_21835);

(statearr_21841_21928[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (20))){
var inst_21740 = (state_21839[(7)]);
var inst_21750 = cljs.core.first.call(null,inst_21740);
var inst_21751 = cljs.core.nth.call(null,inst_21750,(0),null);
var inst_21752 = cljs.core.nth.call(null,inst_21750,(1),null);
var state_21839__$1 = (function (){var statearr_21842 = state_21839;
(statearr_21842[(8)] = inst_21751);

return statearr_21842;
})();
if(cljs.core.truth_(inst_21752)){
var statearr_21843_21929 = state_21839__$1;
(statearr_21843_21929[(1)] = (22));

} else {
var statearr_21844_21930 = state_21839__$1;
(statearr_21844_21930[(1)] = (23));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (27))){
var inst_21780 = (state_21839[(9)]);
var inst_21787 = (state_21839[(10)]);
var inst_21782 = (state_21839[(11)]);
var inst_21711 = (state_21839[(12)]);
var inst_21787__$1 = cljs.core._nth.call(null,inst_21780,inst_21782);
var inst_21788 = cljs.core.async.put_BANG_.call(null,inst_21787__$1,inst_21711,done);
var state_21839__$1 = (function (){var statearr_21845 = state_21839;
(statearr_21845[(10)] = inst_21787__$1);

return statearr_21845;
})();
if(cljs.core.truth_(inst_21788)){
var statearr_21846_21931 = state_21839__$1;
(statearr_21846_21931[(1)] = (30));

} else {
var statearr_21847_21932 = state_21839__$1;
(statearr_21847_21932[(1)] = (31));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (1))){
var state_21839__$1 = state_21839;
var statearr_21848_21933 = state_21839__$1;
(statearr_21848_21933[(2)] = null);

(statearr_21848_21933[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (24))){
var inst_21740 = (state_21839[(7)]);
var inst_21757 = (state_21839[(2)]);
var inst_21758 = cljs.core.next.call(null,inst_21740);
var inst_21720 = inst_21758;
var inst_21721 = null;
var inst_21722 = (0);
var inst_21723 = (0);
var state_21839__$1 = (function (){var statearr_21849 = state_21839;
(statearr_21849[(13)] = inst_21757);

(statearr_21849[(14)] = inst_21722);

(statearr_21849[(15)] = inst_21723);

(statearr_21849[(16)] = inst_21721);

(statearr_21849[(17)] = inst_21720);

return statearr_21849;
})();
var statearr_21850_21934 = state_21839__$1;
(statearr_21850_21934[(2)] = null);

(statearr_21850_21934[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (39))){
var state_21839__$1 = state_21839;
var statearr_21854_21935 = state_21839__$1;
(statearr_21854_21935[(2)] = null);

(statearr_21854_21935[(1)] = (41));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (4))){
var inst_21711 = (state_21839[(12)]);
var inst_21711__$1 = (state_21839[(2)]);
var inst_21712 = (inst_21711__$1 == null);
var state_21839__$1 = (function (){var statearr_21855 = state_21839;
(statearr_21855[(12)] = inst_21711__$1);

return statearr_21855;
})();
if(cljs.core.truth_(inst_21712)){
var statearr_21856_21936 = state_21839__$1;
(statearr_21856_21936[(1)] = (5));

} else {
var statearr_21857_21937 = state_21839__$1;
(statearr_21857_21937[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (15))){
var inst_21722 = (state_21839[(14)]);
var inst_21723 = (state_21839[(15)]);
var inst_21721 = (state_21839[(16)]);
var inst_21720 = (state_21839[(17)]);
var inst_21736 = (state_21839[(2)]);
var inst_21737 = (inst_21723 + (1));
var tmp21851 = inst_21722;
var tmp21852 = inst_21721;
var tmp21853 = inst_21720;
var inst_21720__$1 = tmp21853;
var inst_21721__$1 = tmp21852;
var inst_21722__$1 = tmp21851;
var inst_21723__$1 = inst_21737;
var state_21839__$1 = (function (){var statearr_21858 = state_21839;
(statearr_21858[(14)] = inst_21722__$1);

(statearr_21858[(15)] = inst_21723__$1);

(statearr_21858[(18)] = inst_21736);

(statearr_21858[(16)] = inst_21721__$1);

(statearr_21858[(17)] = inst_21720__$1);

return statearr_21858;
})();
var statearr_21859_21938 = state_21839__$1;
(statearr_21859_21938[(2)] = null);

(statearr_21859_21938[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (21))){
var inst_21761 = (state_21839[(2)]);
var state_21839__$1 = state_21839;
var statearr_21863_21939 = state_21839__$1;
(statearr_21863_21939[(2)] = inst_21761);

(statearr_21863_21939[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (31))){
var inst_21787 = (state_21839[(10)]);
var inst_21791 = done.call(null,null);
var inst_21792 = cljs.core.async.untap_STAR_.call(null,m,inst_21787);
var state_21839__$1 = (function (){var statearr_21864 = state_21839;
(statearr_21864[(19)] = inst_21791);

return statearr_21864;
})();
var statearr_21865_21940 = state_21839__$1;
(statearr_21865_21940[(2)] = inst_21792);

(statearr_21865_21940[(1)] = (32));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (32))){
var inst_21780 = (state_21839[(9)]);
var inst_21781 = (state_21839[(20)]);
var inst_21779 = (state_21839[(21)]);
var inst_21782 = (state_21839[(11)]);
var inst_21794 = (state_21839[(2)]);
var inst_21795 = (inst_21782 + (1));
var tmp21860 = inst_21780;
var tmp21861 = inst_21781;
var tmp21862 = inst_21779;
var inst_21779__$1 = tmp21862;
var inst_21780__$1 = tmp21860;
var inst_21781__$1 = tmp21861;
var inst_21782__$1 = inst_21795;
var state_21839__$1 = (function (){var statearr_21866 = state_21839;
(statearr_21866[(9)] = inst_21780__$1);

(statearr_21866[(22)] = inst_21794);

(statearr_21866[(20)] = inst_21781__$1);

(statearr_21866[(21)] = inst_21779__$1);

(statearr_21866[(11)] = inst_21782__$1);

return statearr_21866;
})();
var statearr_21867_21941 = state_21839__$1;
(statearr_21867_21941[(2)] = null);

(statearr_21867_21941[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (40))){
var inst_21807 = (state_21839[(23)]);
var inst_21811 = done.call(null,null);
var inst_21812 = cljs.core.async.untap_STAR_.call(null,m,inst_21807);
var state_21839__$1 = (function (){var statearr_21868 = state_21839;
(statearr_21868[(24)] = inst_21811);

return statearr_21868;
})();
var statearr_21869_21942 = state_21839__$1;
(statearr_21869_21942[(2)] = inst_21812);

(statearr_21869_21942[(1)] = (41));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (33))){
var inst_21798 = (state_21839[(25)]);
var inst_21800 = cljs.core.chunked_seq_QMARK_.call(null,inst_21798);
var state_21839__$1 = state_21839;
if(inst_21800){
var statearr_21870_21943 = state_21839__$1;
(statearr_21870_21943[(1)] = (36));

} else {
var statearr_21871_21944 = state_21839__$1;
(statearr_21871_21944[(1)] = (37));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (13))){
var inst_21730 = (state_21839[(26)]);
var inst_21733 = cljs.core.async.close_BANG_.call(null,inst_21730);
var state_21839__$1 = state_21839;
var statearr_21872_21945 = state_21839__$1;
(statearr_21872_21945[(2)] = inst_21733);

(statearr_21872_21945[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (22))){
var inst_21751 = (state_21839[(8)]);
var inst_21754 = cljs.core.async.close_BANG_.call(null,inst_21751);
var state_21839__$1 = state_21839;
var statearr_21873_21946 = state_21839__$1;
(statearr_21873_21946[(2)] = inst_21754);

(statearr_21873_21946[(1)] = (24));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (36))){
var inst_21798 = (state_21839[(25)]);
var inst_21802 = cljs.core.chunk_first.call(null,inst_21798);
var inst_21803 = cljs.core.chunk_rest.call(null,inst_21798);
var inst_21804 = cljs.core.count.call(null,inst_21802);
var inst_21779 = inst_21803;
var inst_21780 = inst_21802;
var inst_21781 = inst_21804;
var inst_21782 = (0);
var state_21839__$1 = (function (){var statearr_21874 = state_21839;
(statearr_21874[(9)] = inst_21780);

(statearr_21874[(20)] = inst_21781);

(statearr_21874[(21)] = inst_21779);

(statearr_21874[(11)] = inst_21782);

return statearr_21874;
})();
var statearr_21875_21947 = state_21839__$1;
(statearr_21875_21947[(2)] = null);

(statearr_21875_21947[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (41))){
var inst_21798 = (state_21839[(25)]);
var inst_21814 = (state_21839[(2)]);
var inst_21815 = cljs.core.next.call(null,inst_21798);
var inst_21779 = inst_21815;
var inst_21780 = null;
var inst_21781 = (0);
var inst_21782 = (0);
var state_21839__$1 = (function (){var statearr_21876 = state_21839;
(statearr_21876[(9)] = inst_21780);

(statearr_21876[(20)] = inst_21781);

(statearr_21876[(21)] = inst_21779);

(statearr_21876[(11)] = inst_21782);

(statearr_21876[(27)] = inst_21814);

return statearr_21876;
})();
var statearr_21877_21948 = state_21839__$1;
(statearr_21877_21948[(2)] = null);

(statearr_21877_21948[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (43))){
var state_21839__$1 = state_21839;
var statearr_21878_21949 = state_21839__$1;
(statearr_21878_21949[(2)] = null);

(statearr_21878_21949[(1)] = (44));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (29))){
var inst_21823 = (state_21839[(2)]);
var state_21839__$1 = state_21839;
var statearr_21879_21950 = state_21839__$1;
(statearr_21879_21950[(2)] = inst_21823);

(statearr_21879_21950[(1)] = (26));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (44))){
var inst_21832 = (state_21839[(2)]);
var state_21839__$1 = (function (){var statearr_21880 = state_21839;
(statearr_21880[(28)] = inst_21832);

return statearr_21880;
})();
var statearr_21881_21951 = state_21839__$1;
(statearr_21881_21951[(2)] = null);

(statearr_21881_21951[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (6))){
var inst_21771 = (state_21839[(29)]);
var inst_21770 = cljs.core.deref.call(null,cs);
var inst_21771__$1 = cljs.core.keys.call(null,inst_21770);
var inst_21772 = cljs.core.count.call(null,inst_21771__$1);
var inst_21773 = cljs.core.reset_BANG_.call(null,dctr,inst_21772);
var inst_21778 = cljs.core.seq.call(null,inst_21771__$1);
var inst_21779 = inst_21778;
var inst_21780 = null;
var inst_21781 = (0);
var inst_21782 = (0);
var state_21839__$1 = (function (){var statearr_21882 = state_21839;
(statearr_21882[(9)] = inst_21780);

(statearr_21882[(29)] = inst_21771__$1);

(statearr_21882[(20)] = inst_21781);

(statearr_21882[(21)] = inst_21779);

(statearr_21882[(11)] = inst_21782);

(statearr_21882[(30)] = inst_21773);

return statearr_21882;
})();
var statearr_21883_21952 = state_21839__$1;
(statearr_21883_21952[(2)] = null);

(statearr_21883_21952[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (28))){
var inst_21798 = (state_21839[(25)]);
var inst_21779 = (state_21839[(21)]);
var inst_21798__$1 = cljs.core.seq.call(null,inst_21779);
var state_21839__$1 = (function (){var statearr_21884 = state_21839;
(statearr_21884[(25)] = inst_21798__$1);

return statearr_21884;
})();
if(inst_21798__$1){
var statearr_21885_21953 = state_21839__$1;
(statearr_21885_21953[(1)] = (33));

} else {
var statearr_21886_21954 = state_21839__$1;
(statearr_21886_21954[(1)] = (34));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (25))){
var inst_21781 = (state_21839[(20)]);
var inst_21782 = (state_21839[(11)]);
var inst_21784 = (inst_21782 < inst_21781);
var inst_21785 = inst_21784;
var state_21839__$1 = state_21839;
if(cljs.core.truth_(inst_21785)){
var statearr_21887_21955 = state_21839__$1;
(statearr_21887_21955[(1)] = (27));

} else {
var statearr_21888_21956 = state_21839__$1;
(statearr_21888_21956[(1)] = (28));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (34))){
var state_21839__$1 = state_21839;
var statearr_21889_21957 = state_21839__$1;
(statearr_21889_21957[(2)] = null);

(statearr_21889_21957[(1)] = (35));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (17))){
var state_21839__$1 = state_21839;
var statearr_21890_21958 = state_21839__$1;
(statearr_21890_21958[(2)] = null);

(statearr_21890_21958[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (3))){
var inst_21837 = (state_21839[(2)]);
var state_21839__$1 = state_21839;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_21839__$1,inst_21837);
} else {
if((state_val_21840 === (12))){
var inst_21766 = (state_21839[(2)]);
var state_21839__$1 = state_21839;
var statearr_21891_21959 = state_21839__$1;
(statearr_21891_21959[(2)] = inst_21766);

(statearr_21891_21959[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (2))){
var state_21839__$1 = state_21839;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_21839__$1,(4),ch);
} else {
if((state_val_21840 === (23))){
var state_21839__$1 = state_21839;
var statearr_21892_21960 = state_21839__$1;
(statearr_21892_21960[(2)] = null);

(statearr_21892_21960[(1)] = (24));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (35))){
var inst_21821 = (state_21839[(2)]);
var state_21839__$1 = state_21839;
var statearr_21893_21961 = state_21839__$1;
(statearr_21893_21961[(2)] = inst_21821);

(statearr_21893_21961[(1)] = (29));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (19))){
var inst_21740 = (state_21839[(7)]);
var inst_21744 = cljs.core.chunk_first.call(null,inst_21740);
var inst_21745 = cljs.core.chunk_rest.call(null,inst_21740);
var inst_21746 = cljs.core.count.call(null,inst_21744);
var inst_21720 = inst_21745;
var inst_21721 = inst_21744;
var inst_21722 = inst_21746;
var inst_21723 = (0);
var state_21839__$1 = (function (){var statearr_21894 = state_21839;
(statearr_21894[(14)] = inst_21722);

(statearr_21894[(15)] = inst_21723);

(statearr_21894[(16)] = inst_21721);

(statearr_21894[(17)] = inst_21720);

return statearr_21894;
})();
var statearr_21895_21962 = state_21839__$1;
(statearr_21895_21962[(2)] = null);

(statearr_21895_21962[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (11))){
var inst_21720 = (state_21839[(17)]);
var inst_21740 = (state_21839[(7)]);
var inst_21740__$1 = cljs.core.seq.call(null,inst_21720);
var state_21839__$1 = (function (){var statearr_21896 = state_21839;
(statearr_21896[(7)] = inst_21740__$1);

return statearr_21896;
})();
if(inst_21740__$1){
var statearr_21897_21963 = state_21839__$1;
(statearr_21897_21963[(1)] = (16));

} else {
var statearr_21898_21964 = state_21839__$1;
(statearr_21898_21964[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (9))){
var inst_21768 = (state_21839[(2)]);
var state_21839__$1 = state_21839;
var statearr_21899_21965 = state_21839__$1;
(statearr_21899_21965[(2)] = inst_21768);

(statearr_21899_21965[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (5))){
var inst_21718 = cljs.core.deref.call(null,cs);
var inst_21719 = cljs.core.seq.call(null,inst_21718);
var inst_21720 = inst_21719;
var inst_21721 = null;
var inst_21722 = (0);
var inst_21723 = (0);
var state_21839__$1 = (function (){var statearr_21900 = state_21839;
(statearr_21900[(14)] = inst_21722);

(statearr_21900[(15)] = inst_21723);

(statearr_21900[(16)] = inst_21721);

(statearr_21900[(17)] = inst_21720);

return statearr_21900;
})();
var statearr_21901_21966 = state_21839__$1;
(statearr_21901_21966[(2)] = null);

(statearr_21901_21966[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (14))){
var state_21839__$1 = state_21839;
var statearr_21902_21967 = state_21839__$1;
(statearr_21902_21967[(2)] = null);

(statearr_21902_21967[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (45))){
var inst_21829 = (state_21839[(2)]);
var state_21839__$1 = state_21839;
var statearr_21903_21968 = state_21839__$1;
(statearr_21903_21968[(2)] = inst_21829);

(statearr_21903_21968[(1)] = (44));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (26))){
var inst_21771 = (state_21839[(29)]);
var inst_21825 = (state_21839[(2)]);
var inst_21826 = cljs.core.seq.call(null,inst_21771);
var state_21839__$1 = (function (){var statearr_21904 = state_21839;
(statearr_21904[(31)] = inst_21825);

return statearr_21904;
})();
if(inst_21826){
var statearr_21905_21969 = state_21839__$1;
(statearr_21905_21969[(1)] = (42));

} else {
var statearr_21906_21970 = state_21839__$1;
(statearr_21906_21970[(1)] = (43));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (16))){
var inst_21740 = (state_21839[(7)]);
var inst_21742 = cljs.core.chunked_seq_QMARK_.call(null,inst_21740);
var state_21839__$1 = state_21839;
if(inst_21742){
var statearr_21907_21971 = state_21839__$1;
(statearr_21907_21971[(1)] = (19));

} else {
var statearr_21908_21972 = state_21839__$1;
(statearr_21908_21972[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (38))){
var inst_21818 = (state_21839[(2)]);
var state_21839__$1 = state_21839;
var statearr_21909_21973 = state_21839__$1;
(statearr_21909_21973[(2)] = inst_21818);

(statearr_21909_21973[(1)] = (35));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (30))){
var state_21839__$1 = state_21839;
var statearr_21910_21974 = state_21839__$1;
(statearr_21910_21974[(2)] = null);

(statearr_21910_21974[(1)] = (32));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (10))){
var inst_21723 = (state_21839[(15)]);
var inst_21721 = (state_21839[(16)]);
var inst_21729 = cljs.core._nth.call(null,inst_21721,inst_21723);
var inst_21730 = cljs.core.nth.call(null,inst_21729,(0),null);
var inst_21731 = cljs.core.nth.call(null,inst_21729,(1),null);
var state_21839__$1 = (function (){var statearr_21911 = state_21839;
(statearr_21911[(26)] = inst_21730);

return statearr_21911;
})();
if(cljs.core.truth_(inst_21731)){
var statearr_21912_21975 = state_21839__$1;
(statearr_21912_21975[(1)] = (13));

} else {
var statearr_21913_21976 = state_21839__$1;
(statearr_21913_21976[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (18))){
var inst_21764 = (state_21839[(2)]);
var state_21839__$1 = state_21839;
var statearr_21914_21977 = state_21839__$1;
(statearr_21914_21977[(2)] = inst_21764);

(statearr_21914_21977[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (42))){
var state_21839__$1 = state_21839;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_21839__$1,(45),dchan);
} else {
if((state_val_21840 === (37))){
var inst_21807 = (state_21839[(23)]);
var inst_21798 = (state_21839[(25)]);
var inst_21711 = (state_21839[(12)]);
var inst_21807__$1 = cljs.core.first.call(null,inst_21798);
var inst_21808 = cljs.core.async.put_BANG_.call(null,inst_21807__$1,inst_21711,done);
var state_21839__$1 = (function (){var statearr_21915 = state_21839;
(statearr_21915[(23)] = inst_21807__$1);

return statearr_21915;
})();
if(cljs.core.truth_(inst_21808)){
var statearr_21916_21978 = state_21839__$1;
(statearr_21916_21978[(1)] = (39));

} else {
var statearr_21917_21979 = state_21839__$1;
(statearr_21917_21979[(1)] = (40));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_21840 === (8))){
var inst_21722 = (state_21839[(14)]);
var inst_21723 = (state_21839[(15)]);
var inst_21725 = (inst_21723 < inst_21722);
var inst_21726 = inst_21725;
var state_21839__$1 = state_21839;
if(cljs.core.truth_(inst_21726)){
var statearr_21918_21980 = state_21839__$1;
(statearr_21918_21980[(1)] = (10));

} else {
var statearr_21919_21981 = state_21839__$1;
(statearr_21919_21981[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto___21927,cs,m,dchan,dctr,done))
;
return ((function (switch__20508__auto__,c__20620__auto___21927,cs,m,dchan,dctr,done){
return (function() {
var cljs$core$async$mult_$_state_machine__20509__auto__ = null;
var cljs$core$async$mult_$_state_machine__20509__auto____0 = (function (){
var statearr_21923 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_21923[(0)] = cljs$core$async$mult_$_state_machine__20509__auto__);

(statearr_21923[(1)] = (1));

return statearr_21923;
});
var cljs$core$async$mult_$_state_machine__20509__auto____1 = (function (state_21839){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_21839);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e21924){if((e21924 instanceof Object)){
var ex__20512__auto__ = e21924;
var statearr_21925_21982 = state_21839;
(statearr_21925_21982[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_21839);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e21924;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__21983 = state_21839;
state_21839 = G__21983;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$mult_$_state_machine__20509__auto__ = function(state_21839){
switch(arguments.length){
case 0:
return cljs$core$async$mult_$_state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$mult_$_state_machine__20509__auto____1.call(this,state_21839);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mult_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mult_$_state_machine__20509__auto____0;
cljs$core$async$mult_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mult_$_state_machine__20509__auto____1;
return cljs$core$async$mult_$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___21927,cs,m,dchan,dctr,done))
})();
var state__20622__auto__ = (function (){var statearr_21926 = f__20621__auto__.call(null);
(statearr_21926[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___21927);

return statearr_21926;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___21927,cs,m,dchan,dctr,done))
);


return m;
});
/**
 * Copies the mult source onto the supplied channel.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.tap = (function cljs$core$async$tap(var_args){
var args21984 = [];
var len__19356__auto___21987 = arguments.length;
var i__19357__auto___21988 = (0);
while(true){
if((i__19357__auto___21988 < len__19356__auto___21987)){
args21984.push((arguments[i__19357__auto___21988]));

var G__21989 = (i__19357__auto___21988 + (1));
i__19357__auto___21988 = G__21989;
continue;
} else {
}
break;
}

var G__21986 = args21984.length;
switch (G__21986) {
case 2:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args21984.length)].join('')));

}
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$2 = (function (mult,ch){
return cljs.core.async.tap.call(null,mult,ch,true);
});

cljs.core.async.tap.cljs$core$IFn$_invoke$arity$3 = (function (mult,ch,close_QMARK_){
cljs.core.async.tap_STAR_.call(null,mult,ch,close_QMARK_);

return ch;
});

cljs.core.async.tap.cljs$lang$maxFixedArity = 3;
/**
 * Disconnects a target channel from a mult
 */
cljs.core.async.untap = (function cljs$core$async$untap(mult,ch){
return cljs.core.async.untap_STAR_.call(null,mult,ch);
});
/**
 * Disconnects all target channels from a mult
 */
cljs.core.async.untap_all = (function cljs$core$async$untap_all(mult){
return cljs.core.async.untap_all_STAR_.call(null,mult);
});

/**
 * @interface
 */
cljs.core.async.Mix = function(){};

cljs.core.async.admix_STAR_ = (function cljs$core$async$admix_STAR_(m,ch){
if((!((m == null))) && (!((m.cljs$core$async$Mix$admix_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$admix_STAR_$arity$2(m,ch);
} else {
var x__18953__auto__ = (((m == null))?null:m);
var m__18954__auto__ = (cljs.core.async.admix_STAR_[goog.typeOf(x__18953__auto__)]);
if(!((m__18954__auto__ == null))){
return m__18954__auto__.call(null,m,ch);
} else {
var m__18954__auto____$1 = (cljs.core.async.admix_STAR_["_"]);
if(!((m__18954__auto____$1 == null))){
return m__18954__auto____$1.call(null,m,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.admix*",m);
}
}
}
});

cljs.core.async.unmix_STAR_ = (function cljs$core$async$unmix_STAR_(m,ch){
if((!((m == null))) && (!((m.cljs$core$async$Mix$unmix_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$unmix_STAR_$arity$2(m,ch);
} else {
var x__18953__auto__ = (((m == null))?null:m);
var m__18954__auto__ = (cljs.core.async.unmix_STAR_[goog.typeOf(x__18953__auto__)]);
if(!((m__18954__auto__ == null))){
return m__18954__auto__.call(null,m,ch);
} else {
var m__18954__auto____$1 = (cljs.core.async.unmix_STAR_["_"]);
if(!((m__18954__auto____$1 == null))){
return m__18954__auto____$1.call(null,m,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.unmix*",m);
}
}
}
});

cljs.core.async.unmix_all_STAR_ = (function cljs$core$async$unmix_all_STAR_(m){
if((!((m == null))) && (!((m.cljs$core$async$Mix$unmix_all_STAR_$arity$1 == null)))){
return m.cljs$core$async$Mix$unmix_all_STAR_$arity$1(m);
} else {
var x__18953__auto__ = (((m == null))?null:m);
var m__18954__auto__ = (cljs.core.async.unmix_all_STAR_[goog.typeOf(x__18953__auto__)]);
if(!((m__18954__auto__ == null))){
return m__18954__auto__.call(null,m);
} else {
var m__18954__auto____$1 = (cljs.core.async.unmix_all_STAR_["_"]);
if(!((m__18954__auto____$1 == null))){
return m__18954__auto____$1.call(null,m);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.unmix-all*",m);
}
}
}
});

cljs.core.async.toggle_STAR_ = (function cljs$core$async$toggle_STAR_(m,state_map){
if((!((m == null))) && (!((m.cljs$core$async$Mix$toggle_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$toggle_STAR_$arity$2(m,state_map);
} else {
var x__18953__auto__ = (((m == null))?null:m);
var m__18954__auto__ = (cljs.core.async.toggle_STAR_[goog.typeOf(x__18953__auto__)]);
if(!((m__18954__auto__ == null))){
return m__18954__auto__.call(null,m,state_map);
} else {
var m__18954__auto____$1 = (cljs.core.async.toggle_STAR_["_"]);
if(!((m__18954__auto____$1 == null))){
return m__18954__auto____$1.call(null,m,state_map);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.toggle*",m);
}
}
}
});

cljs.core.async.solo_mode_STAR_ = (function cljs$core$async$solo_mode_STAR_(m,mode){
if((!((m == null))) && (!((m.cljs$core$async$Mix$solo_mode_STAR_$arity$2 == null)))){
return m.cljs$core$async$Mix$solo_mode_STAR_$arity$2(m,mode);
} else {
var x__18953__auto__ = (((m == null))?null:m);
var m__18954__auto__ = (cljs.core.async.solo_mode_STAR_[goog.typeOf(x__18953__auto__)]);
if(!((m__18954__auto__ == null))){
return m__18954__auto__.call(null,m,mode);
} else {
var m__18954__auto____$1 = (cljs.core.async.solo_mode_STAR_["_"]);
if(!((m__18954__auto____$1 == null))){
return m__18954__auto____$1.call(null,m,mode);
} else {
throw cljs.core.missing_protocol.call(null,"Mix.solo-mode*",m);
}
}
}
});

cljs.core.async.ioc_alts_BANG_ = (function cljs$core$async$ioc_alts_BANG_(var_args){
var args__19363__auto__ = [];
var len__19356__auto___22001 = arguments.length;
var i__19357__auto___22002 = (0);
while(true){
if((i__19357__auto___22002 < len__19356__auto___22001)){
args__19363__auto__.push((arguments[i__19357__auto___22002]));

var G__22003 = (i__19357__auto___22002 + (1));
i__19357__auto___22002 = G__22003;
continue;
} else {
}
break;
}

var argseq__19364__auto__ = ((((3) < args__19363__auto__.length))?(new cljs.core.IndexedSeq(args__19363__auto__.slice((3)),(0))):null);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),argseq__19364__auto__);
});

cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic = (function (state,cont_block,ports,p__21995){
var map__21996 = p__21995;
var map__21996__$1 = ((((!((map__21996 == null)))?((((map__21996.cljs$lang$protocol_mask$partition0$ & (64))) || (map__21996.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__21996):map__21996);
var opts = map__21996__$1;
var statearr_21998_22004 = state;
(statearr_21998_22004[cljs.core.async.impl.ioc_helpers.STATE_IDX] = cont_block);


var temp__4425__auto__ = cljs.core.async.do_alts.call(null,((function (map__21996,map__21996__$1,opts){
return (function (val){
var statearr_21999_22005 = state;
(statearr_21999_22005[cljs.core.async.impl.ioc_helpers.VALUE_IDX] = val);


return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state);
});})(map__21996,map__21996__$1,opts))
,ports,opts);
if(cljs.core.truth_(temp__4425__auto__)){
var cb = temp__4425__auto__;
var statearr_22000_22006 = state;
(statearr_22000_22006[cljs.core.async.impl.ioc_helpers.VALUE_IDX] = cljs.core.deref.call(null,cb));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
});

cljs.core.async.ioc_alts_BANG_.cljs$lang$maxFixedArity = (3);

cljs.core.async.ioc_alts_BANG_.cljs$lang$applyTo = (function (seq21991){
var G__21992 = cljs.core.first.call(null,seq21991);
var seq21991__$1 = cljs.core.next.call(null,seq21991);
var G__21993 = cljs.core.first.call(null,seq21991__$1);
var seq21991__$2 = cljs.core.next.call(null,seq21991__$1);
var G__21994 = cljs.core.first.call(null,seq21991__$2);
var seq21991__$3 = cljs.core.next.call(null,seq21991__$2);
return cljs.core.async.ioc_alts_BANG_.cljs$core$IFn$_invoke$arity$variadic(G__21992,G__21993,G__21994,seq21991__$3);
});
/**
 * Creates and returns a mix of one or more input channels which will
 *   be put on the supplied out channel. Input sources can be added to
 *   the mix with 'admix', and removed with 'unmix'. A mix supports
 *   soloing, muting and pausing multiple inputs atomically using
 *   'toggle', and can solo using either muting or pausing as determined
 *   by 'solo-mode'.
 * 
 *   Each channel can have zero or more boolean modes set via 'toggle':
 * 
 *   :solo - when true, only this (ond other soloed) channel(s) will appear
 *        in the mix output channel. :mute and :pause states of soloed
 *        channels are ignored. If solo-mode is :mute, non-soloed
 *        channels are muted, if :pause, non-soloed channels are
 *        paused.
 * 
 *   :mute - muted channels will have their contents consumed but not included in the mix
 *   :pause - paused channels will not have their contents consumed (and thus also not included in the mix)
 */
cljs.core.async.mix = (function cljs$core$async$mix(out){
var cs = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var solo_modes = new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"pause","pause",-2095325672),null,new cljs.core.Keyword(null,"mute","mute",1151223646),null], null), null);
var attrs = cljs.core.conj.call(null,solo_modes,new cljs.core.Keyword(null,"solo","solo",-316350075));
var solo_mode = cljs.core.atom.call(null,new cljs.core.Keyword(null,"mute","mute",1151223646));
var change = cljs.core.async.chan.call(null);
var changed = ((function (cs,solo_modes,attrs,solo_mode,change){
return (function (){
return cljs.core.async.put_BANG_.call(null,change,true);
});})(cs,solo_modes,attrs,solo_mode,change))
;
var pick = ((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (attr,chs){
return cljs.core.reduce_kv.call(null,((function (cs,solo_modes,attrs,solo_mode,change,changed){
return (function (ret,c,v){
if(cljs.core.truth_(attr.call(null,v))){
return cljs.core.conj.call(null,ret,c);
} else {
return ret;
}
});})(cs,solo_modes,attrs,solo_mode,change,changed))
,cljs.core.PersistentHashSet.EMPTY,chs);
});})(cs,solo_modes,attrs,solo_mode,change,changed))
;
var calc_state = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick){
return (function (){
var chs = cljs.core.deref.call(null,cs);
var mode = cljs.core.deref.call(null,solo_mode);
var solos = pick.call(null,new cljs.core.Keyword(null,"solo","solo",-316350075),chs);
var pauses = pick.call(null,new cljs.core.Keyword(null,"pause","pause",-2095325672),chs);
return new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"solos","solos",1441458643),solos,new cljs.core.Keyword(null,"mutes","mutes",1068806309),pick.call(null,new cljs.core.Keyword(null,"mute","mute",1151223646),chs),new cljs.core.Keyword(null,"reads","reads",-1215067361),cljs.core.conj.call(null,(((cljs.core._EQ_.call(null,mode,new cljs.core.Keyword(null,"pause","pause",-2095325672))) && (!(cljs.core.empty_QMARK_.call(null,solos))))?cljs.core.vec.call(null,solos):cljs.core.vec.call(null,cljs.core.remove.call(null,pauses,cljs.core.keys.call(null,chs)))),change)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick))
;
var m = (function (){
if(typeof cljs.core.async.t_cljs$core$async22170 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mix}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async22170 = (function (change,mix,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,meta22171){
this.change = change;
this.mix = mix;
this.solo_mode = solo_mode;
this.pick = pick;
this.cs = cs;
this.calc_state = calc_state;
this.out = out;
this.changed = changed;
this.solo_modes = solo_modes;
this.attrs = attrs;
this.meta22171 = meta22171;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async22170.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_22172,meta22171__$1){
var self__ = this;
var _22172__$1 = this;
return (new cljs.core.async.t_cljs$core$async22170(self__.change,self__.mix,self__.solo_mode,self__.pick,self__.cs,self__.calc_state,self__.out,self__.changed,self__.solo_modes,self__.attrs,meta22171__$1));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async22170.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_22172){
var self__ = this;
var _22172__$1 = this;
return self__.meta22171;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async22170.prototype.cljs$core$async$Mux$ = true;

cljs.core.async.t_cljs$core$async22170.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.out;
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async22170.prototype.cljs$core$async$Mix$ = true;

cljs.core.async.t_cljs$core$async22170.prototype.cljs$core$async$Mix$admix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.assoc,ch,cljs.core.PersistentArrayMap.EMPTY);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async22170.prototype.cljs$core$async$Mix$unmix_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,ch){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.dissoc,ch);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async22170.prototype.cljs$core$async$Mix$unmix_all_STAR_$arity$1 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_){
var self__ = this;
var ___$1 = this;
cljs.core.reset_BANG_.call(null,self__.cs,cljs.core.PersistentArrayMap.EMPTY);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async22170.prototype.cljs$core$async$Mix$toggle_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,state_map){
var self__ = this;
var ___$1 = this;
cljs.core.swap_BANG_.call(null,self__.cs,cljs.core.partial.call(null,cljs.core.merge_with,cljs.core.merge),state_map);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async22170.prototype.cljs$core$async$Mix$solo_mode_STAR_$arity$2 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (_,mode){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_(self__.solo_modes.call(null,mode))){
} else {
throw (new Error([cljs.core.str("Assert failed: "),cljs.core.str([cljs.core.str("mode must be one of: "),cljs.core.str(self__.solo_modes)].join('')),cljs.core.str("\n"),cljs.core.str(cljs.core.pr_str.call(null,cljs.core.list(new cljs.core.Symbol(null,"solo-modes","solo-modes",882180540,null),new cljs.core.Symbol(null,"mode","mode",-2000032078,null))))].join('')));
}

cljs.core.reset_BANG_.call(null,self__.solo_mode,mode);

return self__.changed.call(null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async22170.getBasis = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (){
return new cljs.core.PersistentVector(null, 11, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"change","change",477485025,null),cljs.core.with_meta(new cljs.core.Symbol(null,"mix","mix",2121373763,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(new cljs.core.PersistentVector(null, 1, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"out","out",729986010,null)], null))),new cljs.core.Keyword(null,"doc","doc",1913296891),"Creates and returns a mix of one or more input channels which will\n  be put on the supplied out channel. Input sources can be added to\n  the mix with 'admix', and removed with 'unmix'. A mix supports\n  soloing, muting and pausing multiple inputs atomically using\n  'toggle', and can solo using either muting or pausing as determined\n  by 'solo-mode'.\n\n  Each channel can have zero or more boolean modes set via 'toggle':\n\n  :solo - when true, only this (ond other soloed) channel(s) will appear\n          in the mix output channel. :mute and :pause states of soloed\n          channels are ignored. If solo-mode is :mute, non-soloed\n          channels are muted, if :pause, non-soloed channels are\n          paused.\n\n  :mute - muted channels will have their contents consumed but not included in the mix\n  :pause - paused channels will not have their contents consumed (and thus also not included in the mix)\n"], null)),new cljs.core.Symbol(null,"solo-mode","solo-mode",2031788074,null),new cljs.core.Symbol(null,"pick","pick",1300068175,null),new cljs.core.Symbol(null,"cs","cs",-117024463,null),new cljs.core.Symbol(null,"calc-state","calc-state",-349968968,null),new cljs.core.Symbol(null,"out","out",729986010,null),new cljs.core.Symbol(null,"changed","changed",-2083710852,null),new cljs.core.Symbol(null,"solo-modes","solo-modes",882180540,null),new cljs.core.Symbol(null,"attrs","attrs",-450137186,null),new cljs.core.Symbol(null,"meta22171","meta22171",-199727993,null)], null);
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.t_cljs$core$async22170.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async22170.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async22170";

cljs.core.async.t_cljs$core$async22170.cljs$lang$ctorPrWriter = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function (this__18896__auto__,writer__18897__auto__,opt__18898__auto__){
return cljs.core._write.call(null,writer__18897__auto__,"cljs.core.async/t_cljs$core$async22170");
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

cljs.core.async.__GT_t_cljs$core$async22170 = ((function (cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state){
return (function cljs$core$async$mix_$___GT_t_cljs$core$async22170(change__$1,mix__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta22171){
return (new cljs.core.async.t_cljs$core$async22170(change__$1,mix__$1,solo_mode__$1,pick__$1,cs__$1,calc_state__$1,out__$1,changed__$1,solo_modes__$1,attrs__$1,meta22171));
});})(cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state))
;

}

return (new cljs.core.async.t_cljs$core$async22170(change,cljs$core$async$mix,solo_mode,pick,cs,calc_state,out,changed,solo_modes,attrs,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__20620__auto___22333 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___22333,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___22333,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function (state_22270){
var state_val_22271 = (state_22270[(1)]);
if((state_val_22271 === (7))){
var inst_22188 = (state_22270[(2)]);
var state_22270__$1 = state_22270;
var statearr_22272_22334 = state_22270__$1;
(statearr_22272_22334[(2)] = inst_22188);

(statearr_22272_22334[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (20))){
var inst_22200 = (state_22270[(7)]);
var state_22270__$1 = state_22270;
var statearr_22273_22335 = state_22270__$1;
(statearr_22273_22335[(2)] = inst_22200);

(statearr_22273_22335[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (27))){
var state_22270__$1 = state_22270;
var statearr_22274_22336 = state_22270__$1;
(statearr_22274_22336[(2)] = null);

(statearr_22274_22336[(1)] = (28));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (1))){
var inst_22176 = (state_22270[(8)]);
var inst_22176__$1 = calc_state.call(null);
var inst_22178 = (inst_22176__$1 == null);
var inst_22179 = cljs.core.not.call(null,inst_22178);
var state_22270__$1 = (function (){var statearr_22275 = state_22270;
(statearr_22275[(8)] = inst_22176__$1);

return statearr_22275;
})();
if(inst_22179){
var statearr_22276_22337 = state_22270__$1;
(statearr_22276_22337[(1)] = (2));

} else {
var statearr_22277_22338 = state_22270__$1;
(statearr_22277_22338[(1)] = (3));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (24))){
var inst_22230 = (state_22270[(9)]);
var inst_22244 = (state_22270[(10)]);
var inst_22223 = (state_22270[(11)]);
var inst_22244__$1 = inst_22223.call(null,inst_22230);
var state_22270__$1 = (function (){var statearr_22278 = state_22270;
(statearr_22278[(10)] = inst_22244__$1);

return statearr_22278;
})();
if(cljs.core.truth_(inst_22244__$1)){
var statearr_22279_22339 = state_22270__$1;
(statearr_22279_22339[(1)] = (29));

} else {
var statearr_22280_22340 = state_22270__$1;
(statearr_22280_22340[(1)] = (30));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (4))){
var inst_22191 = (state_22270[(2)]);
var state_22270__$1 = state_22270;
if(cljs.core.truth_(inst_22191)){
var statearr_22281_22341 = state_22270__$1;
(statearr_22281_22341[(1)] = (8));

} else {
var statearr_22282_22342 = state_22270__$1;
(statearr_22282_22342[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (15))){
var inst_22217 = (state_22270[(2)]);
var state_22270__$1 = state_22270;
if(cljs.core.truth_(inst_22217)){
var statearr_22283_22343 = state_22270__$1;
(statearr_22283_22343[(1)] = (19));

} else {
var statearr_22284_22344 = state_22270__$1;
(statearr_22284_22344[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (21))){
var inst_22222 = (state_22270[(12)]);
var inst_22222__$1 = (state_22270[(2)]);
var inst_22223 = cljs.core.get.call(null,inst_22222__$1,new cljs.core.Keyword(null,"solos","solos",1441458643));
var inst_22224 = cljs.core.get.call(null,inst_22222__$1,new cljs.core.Keyword(null,"mutes","mutes",1068806309));
var inst_22225 = cljs.core.get.call(null,inst_22222__$1,new cljs.core.Keyword(null,"reads","reads",-1215067361));
var state_22270__$1 = (function (){var statearr_22285 = state_22270;
(statearr_22285[(11)] = inst_22223);

(statearr_22285[(12)] = inst_22222__$1);

(statearr_22285[(13)] = inst_22224);

return statearr_22285;
})();
return cljs.core.async.ioc_alts_BANG_.call(null,state_22270__$1,(22),inst_22225);
} else {
if((state_val_22271 === (31))){
var inst_22252 = (state_22270[(2)]);
var state_22270__$1 = state_22270;
if(cljs.core.truth_(inst_22252)){
var statearr_22286_22345 = state_22270__$1;
(statearr_22286_22345[(1)] = (32));

} else {
var statearr_22287_22346 = state_22270__$1;
(statearr_22287_22346[(1)] = (33));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (32))){
var inst_22229 = (state_22270[(14)]);
var state_22270__$1 = state_22270;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_22270__$1,(35),out,inst_22229);
} else {
if((state_val_22271 === (33))){
var inst_22222 = (state_22270[(12)]);
var inst_22200 = inst_22222;
var state_22270__$1 = (function (){var statearr_22288 = state_22270;
(statearr_22288[(7)] = inst_22200);

return statearr_22288;
})();
var statearr_22289_22347 = state_22270__$1;
(statearr_22289_22347[(2)] = null);

(statearr_22289_22347[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (13))){
var inst_22200 = (state_22270[(7)]);
var inst_22207 = inst_22200.cljs$lang$protocol_mask$partition0$;
var inst_22208 = (inst_22207 & (64));
var inst_22209 = inst_22200.cljs$core$ISeq$;
var inst_22210 = (inst_22208) || (inst_22209);
var state_22270__$1 = state_22270;
if(cljs.core.truth_(inst_22210)){
var statearr_22290_22348 = state_22270__$1;
(statearr_22290_22348[(1)] = (16));

} else {
var statearr_22291_22349 = state_22270__$1;
(statearr_22291_22349[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (22))){
var inst_22230 = (state_22270[(9)]);
var inst_22229 = (state_22270[(14)]);
var inst_22228 = (state_22270[(2)]);
var inst_22229__$1 = cljs.core.nth.call(null,inst_22228,(0),null);
var inst_22230__$1 = cljs.core.nth.call(null,inst_22228,(1),null);
var inst_22231 = (inst_22229__$1 == null);
var inst_22232 = cljs.core._EQ_.call(null,inst_22230__$1,change);
var inst_22233 = (inst_22231) || (inst_22232);
var state_22270__$1 = (function (){var statearr_22292 = state_22270;
(statearr_22292[(9)] = inst_22230__$1);

(statearr_22292[(14)] = inst_22229__$1);

return statearr_22292;
})();
if(cljs.core.truth_(inst_22233)){
var statearr_22293_22350 = state_22270__$1;
(statearr_22293_22350[(1)] = (23));

} else {
var statearr_22294_22351 = state_22270__$1;
(statearr_22294_22351[(1)] = (24));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (36))){
var inst_22222 = (state_22270[(12)]);
var inst_22200 = inst_22222;
var state_22270__$1 = (function (){var statearr_22295 = state_22270;
(statearr_22295[(7)] = inst_22200);

return statearr_22295;
})();
var statearr_22296_22352 = state_22270__$1;
(statearr_22296_22352[(2)] = null);

(statearr_22296_22352[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (29))){
var inst_22244 = (state_22270[(10)]);
var state_22270__$1 = state_22270;
var statearr_22297_22353 = state_22270__$1;
(statearr_22297_22353[(2)] = inst_22244);

(statearr_22297_22353[(1)] = (31));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (6))){
var state_22270__$1 = state_22270;
var statearr_22298_22354 = state_22270__$1;
(statearr_22298_22354[(2)] = false);

(statearr_22298_22354[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (28))){
var inst_22240 = (state_22270[(2)]);
var inst_22241 = calc_state.call(null);
var inst_22200 = inst_22241;
var state_22270__$1 = (function (){var statearr_22299 = state_22270;
(statearr_22299[(7)] = inst_22200);

(statearr_22299[(15)] = inst_22240);

return statearr_22299;
})();
var statearr_22300_22355 = state_22270__$1;
(statearr_22300_22355[(2)] = null);

(statearr_22300_22355[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (25))){
var inst_22266 = (state_22270[(2)]);
var state_22270__$1 = state_22270;
var statearr_22301_22356 = state_22270__$1;
(statearr_22301_22356[(2)] = inst_22266);

(statearr_22301_22356[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (34))){
var inst_22264 = (state_22270[(2)]);
var state_22270__$1 = state_22270;
var statearr_22302_22357 = state_22270__$1;
(statearr_22302_22357[(2)] = inst_22264);

(statearr_22302_22357[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (17))){
var state_22270__$1 = state_22270;
var statearr_22303_22358 = state_22270__$1;
(statearr_22303_22358[(2)] = false);

(statearr_22303_22358[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (3))){
var state_22270__$1 = state_22270;
var statearr_22304_22359 = state_22270__$1;
(statearr_22304_22359[(2)] = false);

(statearr_22304_22359[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (12))){
var inst_22268 = (state_22270[(2)]);
var state_22270__$1 = state_22270;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_22270__$1,inst_22268);
} else {
if((state_val_22271 === (2))){
var inst_22176 = (state_22270[(8)]);
var inst_22181 = inst_22176.cljs$lang$protocol_mask$partition0$;
var inst_22182 = (inst_22181 & (64));
var inst_22183 = inst_22176.cljs$core$ISeq$;
var inst_22184 = (inst_22182) || (inst_22183);
var state_22270__$1 = state_22270;
if(cljs.core.truth_(inst_22184)){
var statearr_22305_22360 = state_22270__$1;
(statearr_22305_22360[(1)] = (5));

} else {
var statearr_22306_22361 = state_22270__$1;
(statearr_22306_22361[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (23))){
var inst_22229 = (state_22270[(14)]);
var inst_22235 = (inst_22229 == null);
var state_22270__$1 = state_22270;
if(cljs.core.truth_(inst_22235)){
var statearr_22307_22362 = state_22270__$1;
(statearr_22307_22362[(1)] = (26));

} else {
var statearr_22308_22363 = state_22270__$1;
(statearr_22308_22363[(1)] = (27));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (35))){
var inst_22255 = (state_22270[(2)]);
var state_22270__$1 = state_22270;
if(cljs.core.truth_(inst_22255)){
var statearr_22309_22364 = state_22270__$1;
(statearr_22309_22364[(1)] = (36));

} else {
var statearr_22310_22365 = state_22270__$1;
(statearr_22310_22365[(1)] = (37));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (19))){
var inst_22200 = (state_22270[(7)]);
var inst_22219 = cljs.core.apply.call(null,cljs.core.hash_map,inst_22200);
var state_22270__$1 = state_22270;
var statearr_22311_22366 = state_22270__$1;
(statearr_22311_22366[(2)] = inst_22219);

(statearr_22311_22366[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (11))){
var inst_22200 = (state_22270[(7)]);
var inst_22204 = (inst_22200 == null);
var inst_22205 = cljs.core.not.call(null,inst_22204);
var state_22270__$1 = state_22270;
if(inst_22205){
var statearr_22312_22367 = state_22270__$1;
(statearr_22312_22367[(1)] = (13));

} else {
var statearr_22313_22368 = state_22270__$1;
(statearr_22313_22368[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (9))){
var inst_22176 = (state_22270[(8)]);
var state_22270__$1 = state_22270;
var statearr_22314_22369 = state_22270__$1;
(statearr_22314_22369[(2)] = inst_22176);

(statearr_22314_22369[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (5))){
var state_22270__$1 = state_22270;
var statearr_22315_22370 = state_22270__$1;
(statearr_22315_22370[(2)] = true);

(statearr_22315_22370[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (14))){
var state_22270__$1 = state_22270;
var statearr_22316_22371 = state_22270__$1;
(statearr_22316_22371[(2)] = false);

(statearr_22316_22371[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (26))){
var inst_22230 = (state_22270[(9)]);
var inst_22237 = cljs.core.swap_BANG_.call(null,cs,cljs.core.dissoc,inst_22230);
var state_22270__$1 = state_22270;
var statearr_22317_22372 = state_22270__$1;
(statearr_22317_22372[(2)] = inst_22237);

(statearr_22317_22372[(1)] = (28));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (16))){
var state_22270__$1 = state_22270;
var statearr_22318_22373 = state_22270__$1;
(statearr_22318_22373[(2)] = true);

(statearr_22318_22373[(1)] = (18));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (38))){
var inst_22260 = (state_22270[(2)]);
var state_22270__$1 = state_22270;
var statearr_22319_22374 = state_22270__$1;
(statearr_22319_22374[(2)] = inst_22260);

(statearr_22319_22374[(1)] = (34));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (30))){
var inst_22230 = (state_22270[(9)]);
var inst_22223 = (state_22270[(11)]);
var inst_22224 = (state_22270[(13)]);
var inst_22247 = cljs.core.empty_QMARK_.call(null,inst_22223);
var inst_22248 = inst_22224.call(null,inst_22230);
var inst_22249 = cljs.core.not.call(null,inst_22248);
var inst_22250 = (inst_22247) && (inst_22249);
var state_22270__$1 = state_22270;
var statearr_22320_22375 = state_22270__$1;
(statearr_22320_22375[(2)] = inst_22250);

(statearr_22320_22375[(1)] = (31));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (10))){
var inst_22176 = (state_22270[(8)]);
var inst_22196 = (state_22270[(2)]);
var inst_22197 = cljs.core.get.call(null,inst_22196,new cljs.core.Keyword(null,"solos","solos",1441458643));
var inst_22198 = cljs.core.get.call(null,inst_22196,new cljs.core.Keyword(null,"mutes","mutes",1068806309));
var inst_22199 = cljs.core.get.call(null,inst_22196,new cljs.core.Keyword(null,"reads","reads",-1215067361));
var inst_22200 = inst_22176;
var state_22270__$1 = (function (){var statearr_22321 = state_22270;
(statearr_22321[(7)] = inst_22200);

(statearr_22321[(16)] = inst_22199);

(statearr_22321[(17)] = inst_22197);

(statearr_22321[(18)] = inst_22198);

return statearr_22321;
})();
var statearr_22322_22376 = state_22270__$1;
(statearr_22322_22376[(2)] = null);

(statearr_22322_22376[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (18))){
var inst_22214 = (state_22270[(2)]);
var state_22270__$1 = state_22270;
var statearr_22323_22377 = state_22270__$1;
(statearr_22323_22377[(2)] = inst_22214);

(statearr_22323_22377[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (37))){
var state_22270__$1 = state_22270;
var statearr_22324_22378 = state_22270__$1;
(statearr_22324_22378[(2)] = null);

(statearr_22324_22378[(1)] = (38));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22271 === (8))){
var inst_22176 = (state_22270[(8)]);
var inst_22193 = cljs.core.apply.call(null,cljs.core.hash_map,inst_22176);
var state_22270__$1 = state_22270;
var statearr_22325_22379 = state_22270__$1;
(statearr_22325_22379[(2)] = inst_22193);

(statearr_22325_22379[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto___22333,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
;
return ((function (switch__20508__auto__,c__20620__auto___22333,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m){
return (function() {
var cljs$core$async$mix_$_state_machine__20509__auto__ = null;
var cljs$core$async$mix_$_state_machine__20509__auto____0 = (function (){
var statearr_22329 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_22329[(0)] = cljs$core$async$mix_$_state_machine__20509__auto__);

(statearr_22329[(1)] = (1));

return statearr_22329;
});
var cljs$core$async$mix_$_state_machine__20509__auto____1 = (function (state_22270){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_22270);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e22330){if((e22330 instanceof Object)){
var ex__20512__auto__ = e22330;
var statearr_22331_22380 = state_22270;
(statearr_22331_22380[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_22270);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e22330;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__22381 = state_22270;
state_22270 = G__22381;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$mix_$_state_machine__20509__auto__ = function(state_22270){
switch(arguments.length){
case 0:
return cljs$core$async$mix_$_state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$mix_$_state_machine__20509__auto____1.call(this,state_22270);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mix_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mix_$_state_machine__20509__auto____0;
cljs$core$async$mix_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mix_$_state_machine__20509__auto____1;
return cljs$core$async$mix_$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___22333,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
})();
var state__20622__auto__ = (function (){var statearr_22332 = f__20621__auto__.call(null);
(statearr_22332[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___22333);

return statearr_22332;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___22333,cs,solo_modes,attrs,solo_mode,change,changed,pick,calc_state,m))
);


return m;
});
/**
 * Adds ch as an input to the mix
 */
cljs.core.async.admix = (function cljs$core$async$admix(mix,ch){
return cljs.core.async.admix_STAR_.call(null,mix,ch);
});
/**
 * Removes ch as an input to the mix
 */
cljs.core.async.unmix = (function cljs$core$async$unmix(mix,ch){
return cljs.core.async.unmix_STAR_.call(null,mix,ch);
});
/**
 * removes all inputs from the mix
 */
cljs.core.async.unmix_all = (function cljs$core$async$unmix_all(mix){
return cljs.core.async.unmix_all_STAR_.call(null,mix);
});
/**
 * Atomically sets the state(s) of one or more channels in a mix. The
 *   state map is a map of channels -> channel-state-map. A
 *   channel-state-map is a map of attrs -> boolean, where attr is one or
 *   more of :mute, :pause or :solo. Any states supplied are merged with
 *   the current state.
 * 
 *   Note that channels can be added to a mix via toggle, which can be
 *   used to add channels in a particular (e.g. paused) state.
 */
cljs.core.async.toggle = (function cljs$core$async$toggle(mix,state_map){
return cljs.core.async.toggle_STAR_.call(null,mix,state_map);
});
/**
 * Sets the solo mode of the mix. mode must be one of :mute or :pause
 */
cljs.core.async.solo_mode = (function cljs$core$async$solo_mode(mix,mode){
return cljs.core.async.solo_mode_STAR_.call(null,mix,mode);
});

/**
 * @interface
 */
cljs.core.async.Pub = function(){};

cljs.core.async.sub_STAR_ = (function cljs$core$async$sub_STAR_(p,v,ch,close_QMARK_){
if((!((p == null))) && (!((p.cljs$core$async$Pub$sub_STAR_$arity$4 == null)))){
return p.cljs$core$async$Pub$sub_STAR_$arity$4(p,v,ch,close_QMARK_);
} else {
var x__18953__auto__ = (((p == null))?null:p);
var m__18954__auto__ = (cljs.core.async.sub_STAR_[goog.typeOf(x__18953__auto__)]);
if(!((m__18954__auto__ == null))){
return m__18954__auto__.call(null,p,v,ch,close_QMARK_);
} else {
var m__18954__auto____$1 = (cljs.core.async.sub_STAR_["_"]);
if(!((m__18954__auto____$1 == null))){
return m__18954__auto____$1.call(null,p,v,ch,close_QMARK_);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.sub*",p);
}
}
}
});

cljs.core.async.unsub_STAR_ = (function cljs$core$async$unsub_STAR_(p,v,ch){
if((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_STAR_$arity$3 == null)))){
return p.cljs$core$async$Pub$unsub_STAR_$arity$3(p,v,ch);
} else {
var x__18953__auto__ = (((p == null))?null:p);
var m__18954__auto__ = (cljs.core.async.unsub_STAR_[goog.typeOf(x__18953__auto__)]);
if(!((m__18954__auto__ == null))){
return m__18954__auto__.call(null,p,v,ch);
} else {
var m__18954__auto____$1 = (cljs.core.async.unsub_STAR_["_"]);
if(!((m__18954__auto____$1 == null))){
return m__18954__auto____$1.call(null,p,v,ch);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.unsub*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_ = (function cljs$core$async$unsub_all_STAR_(var_args){
var args22382 = [];
var len__19356__auto___22385 = arguments.length;
var i__19357__auto___22386 = (0);
while(true){
if((i__19357__auto___22386 < len__19356__auto___22385)){
args22382.push((arguments[i__19357__auto___22386]));

var G__22387 = (i__19357__auto___22386 + (1));
i__19357__auto___22386 = G__22387;
continue;
} else {
}
break;
}

var G__22384 = args22382.length;
switch (G__22384) {
case 1:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args22382.length)].join('')));

}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$1 = (function (p){
if((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$1 == null)))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$1(p);
} else {
var x__18953__auto__ = (((p == null))?null:p);
var m__18954__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__18953__auto__)]);
if(!((m__18954__auto__ == null))){
return m__18954__auto__.call(null,p);
} else {
var m__18954__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if(!((m__18954__auto____$1 == null))){
return m__18954__auto____$1.call(null,p);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$core$IFn$_invoke$arity$2 = (function (p,v){
if((!((p == null))) && (!((p.cljs$core$async$Pub$unsub_all_STAR_$arity$2 == null)))){
return p.cljs$core$async$Pub$unsub_all_STAR_$arity$2(p,v);
} else {
var x__18953__auto__ = (((p == null))?null:p);
var m__18954__auto__ = (cljs.core.async.unsub_all_STAR_[goog.typeOf(x__18953__auto__)]);
if(!((m__18954__auto__ == null))){
return m__18954__auto__.call(null,p,v);
} else {
var m__18954__auto____$1 = (cljs.core.async.unsub_all_STAR_["_"]);
if(!((m__18954__auto____$1 == null))){
return m__18954__auto____$1.call(null,p,v);
} else {
throw cljs.core.missing_protocol.call(null,"Pub.unsub-all*",p);
}
}
}
});

cljs.core.async.unsub_all_STAR_.cljs$lang$maxFixedArity = 2;

/**
 * Creates and returns a pub(lication) of the supplied channel,
 *   partitioned into topics by the topic-fn. topic-fn will be applied to
 *   each value on the channel and the result will determine the 'topic'
 *   on which that value will be put. Channels can be subscribed to
 *   receive copies of topics using 'sub', and unsubscribed using
 *   'unsub'. Each topic will be handled by an internal mult on a
 *   dedicated channel. By default these internal channels are
 *   unbuffered, but a buf-fn can be supplied which, given a topic,
 *   creates a buffer with desired properties.
 * 
 *   Each item is distributed to all subs in parallel and synchronously,
 *   i.e. each sub must accept before the next item is distributed. Use
 *   buffering/windowing to prevent slow subs from holding up the pub.
 * 
 *   Items received when there are no matching subs get dropped.
 * 
 *   Note that if buf-fns are used then each topic is handled
 *   asynchronously, i.e. if a channel is subscribed to more than one
 *   topic it should not expect them to be interleaved identically with
 *   the source.
 */
cljs.core.async.pub = (function cljs$core$async$pub(var_args){
var args22390 = [];
var len__19356__auto___22515 = arguments.length;
var i__19357__auto___22516 = (0);
while(true){
if((i__19357__auto___22516 < len__19356__auto___22515)){
args22390.push((arguments[i__19357__auto___22516]));

var G__22517 = (i__19357__auto___22516 + (1));
i__19357__auto___22516 = G__22517;
continue;
} else {
}
break;
}

var G__22392 = args22390.length;
switch (G__22392) {
case 2:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args22390.length)].join('')));

}
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$2 = (function (ch,topic_fn){
return cljs.core.async.pub.call(null,ch,topic_fn,cljs.core.constantly.call(null,null));
});

cljs.core.async.pub.cljs$core$IFn$_invoke$arity$3 = (function (ch,topic_fn,buf_fn){
var mults = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var ensure_mult = ((function (mults){
return (function (topic){
var or__18298__auto__ = cljs.core.get.call(null,cljs.core.deref.call(null,mults),topic);
if(cljs.core.truth_(or__18298__auto__)){
return or__18298__auto__;
} else {
return cljs.core.get.call(null,cljs.core.swap_BANG_.call(null,mults,((function (or__18298__auto__,mults){
return (function (p1__22389_SHARP_){
if(cljs.core.truth_(p1__22389_SHARP_.call(null,topic))){
return p1__22389_SHARP_;
} else {
return cljs.core.assoc.call(null,p1__22389_SHARP_,topic,cljs.core.async.mult.call(null,cljs.core.async.chan.call(null,buf_fn.call(null,topic))));
}
});})(or__18298__auto__,mults))
),topic);
}
});})(mults))
;
var p = (function (){
if(typeof cljs.core.async.t_cljs$core$async22393 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.Pub}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.async.Mux}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async22393 = (function (ch,topic_fn,buf_fn,mults,ensure_mult,meta22394){
this.ch = ch;
this.topic_fn = topic_fn;
this.buf_fn = buf_fn;
this.mults = mults;
this.ensure_mult = ensure_mult;
this.meta22394 = meta22394;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async22393.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (mults,ensure_mult){
return (function (_22395,meta22394__$1){
var self__ = this;
var _22395__$1 = this;
return (new cljs.core.async.t_cljs$core$async22393(self__.ch,self__.topic_fn,self__.buf_fn,self__.mults,self__.ensure_mult,meta22394__$1));
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async22393.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (mults,ensure_mult){
return (function (_22395){
var self__ = this;
var _22395__$1 = this;
return self__.meta22394;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async22393.prototype.cljs$core$async$Mux$ = true;

cljs.core.async.t_cljs$core$async22393.prototype.cljs$core$async$Mux$muxch_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return self__.ch;
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async22393.prototype.cljs$core$async$Pub$ = true;

cljs.core.async.t_cljs$core$async22393.prototype.cljs$core$async$Pub$sub_STAR_$arity$4 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1,close_QMARK_){
var self__ = this;
var p__$1 = this;
var m = self__.ensure_mult.call(null,topic);
return cljs.core.async.tap.call(null,m,ch__$1,close_QMARK_);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async22393.prototype.cljs$core$async$Pub$unsub_STAR_$arity$3 = ((function (mults,ensure_mult){
return (function (p,topic,ch__$1){
var self__ = this;
var p__$1 = this;
var temp__4425__auto__ = cljs.core.get.call(null,cljs.core.deref.call(null,self__.mults),topic);
if(cljs.core.truth_(temp__4425__auto__)){
var m = temp__4425__auto__;
return cljs.core.async.untap.call(null,m,ch__$1);
} else {
return null;
}
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async22393.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$1 = ((function (mults,ensure_mult){
return (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.reset_BANG_.call(null,self__.mults,cljs.core.PersistentArrayMap.EMPTY);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async22393.prototype.cljs$core$async$Pub$unsub_all_STAR_$arity$2 = ((function (mults,ensure_mult){
return (function (_,topic){
var self__ = this;
var ___$1 = this;
return cljs.core.swap_BANG_.call(null,self__.mults,cljs.core.dissoc,topic);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async22393.getBasis = ((function (mults,ensure_mult){
return (function (){
return new cljs.core.PersistentVector(null, 6, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"topic-fn","topic-fn",-862449736,null),new cljs.core.Symbol(null,"buf-fn","buf-fn",-1200281591,null),new cljs.core.Symbol(null,"mults","mults",-461114485,null),new cljs.core.Symbol(null,"ensure-mult","ensure-mult",1796584816,null),new cljs.core.Symbol(null,"meta22394","meta22394",-1099110224,null)], null);
});})(mults,ensure_mult))
;

cljs.core.async.t_cljs$core$async22393.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async22393.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async22393";

cljs.core.async.t_cljs$core$async22393.cljs$lang$ctorPrWriter = ((function (mults,ensure_mult){
return (function (this__18896__auto__,writer__18897__auto__,opt__18898__auto__){
return cljs.core._write.call(null,writer__18897__auto__,"cljs.core.async/t_cljs$core$async22393");
});})(mults,ensure_mult))
;

cljs.core.async.__GT_t_cljs$core$async22393 = ((function (mults,ensure_mult){
return (function cljs$core$async$__GT_t_cljs$core$async22393(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta22394){
return (new cljs.core.async.t_cljs$core$async22393(ch__$1,topic_fn__$1,buf_fn__$1,mults__$1,ensure_mult__$1,meta22394));
});})(mults,ensure_mult))
;

}

return (new cljs.core.async.t_cljs$core$async22393(ch,topic_fn,buf_fn,mults,ensure_mult,cljs.core.PersistentArrayMap.EMPTY));
})()
;
var c__20620__auto___22519 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___22519,mults,ensure_mult,p){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___22519,mults,ensure_mult,p){
return (function (state_22467){
var state_val_22468 = (state_22467[(1)]);
if((state_val_22468 === (7))){
var inst_22463 = (state_22467[(2)]);
var state_22467__$1 = state_22467;
var statearr_22469_22520 = state_22467__$1;
(statearr_22469_22520[(2)] = inst_22463);

(statearr_22469_22520[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (20))){
var state_22467__$1 = state_22467;
var statearr_22470_22521 = state_22467__$1;
(statearr_22470_22521[(2)] = null);

(statearr_22470_22521[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (1))){
var state_22467__$1 = state_22467;
var statearr_22471_22522 = state_22467__$1;
(statearr_22471_22522[(2)] = null);

(statearr_22471_22522[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (24))){
var inst_22446 = (state_22467[(7)]);
var inst_22455 = cljs.core.swap_BANG_.call(null,mults,cljs.core.dissoc,inst_22446);
var state_22467__$1 = state_22467;
var statearr_22472_22523 = state_22467__$1;
(statearr_22472_22523[(2)] = inst_22455);

(statearr_22472_22523[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (4))){
var inst_22398 = (state_22467[(8)]);
var inst_22398__$1 = (state_22467[(2)]);
var inst_22399 = (inst_22398__$1 == null);
var state_22467__$1 = (function (){var statearr_22473 = state_22467;
(statearr_22473[(8)] = inst_22398__$1);

return statearr_22473;
})();
if(cljs.core.truth_(inst_22399)){
var statearr_22474_22524 = state_22467__$1;
(statearr_22474_22524[(1)] = (5));

} else {
var statearr_22475_22525 = state_22467__$1;
(statearr_22475_22525[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (15))){
var inst_22440 = (state_22467[(2)]);
var state_22467__$1 = state_22467;
var statearr_22476_22526 = state_22467__$1;
(statearr_22476_22526[(2)] = inst_22440);

(statearr_22476_22526[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (21))){
var inst_22460 = (state_22467[(2)]);
var state_22467__$1 = (function (){var statearr_22477 = state_22467;
(statearr_22477[(9)] = inst_22460);

return statearr_22477;
})();
var statearr_22478_22527 = state_22467__$1;
(statearr_22478_22527[(2)] = null);

(statearr_22478_22527[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (13))){
var inst_22422 = (state_22467[(10)]);
var inst_22424 = cljs.core.chunked_seq_QMARK_.call(null,inst_22422);
var state_22467__$1 = state_22467;
if(inst_22424){
var statearr_22479_22528 = state_22467__$1;
(statearr_22479_22528[(1)] = (16));

} else {
var statearr_22480_22529 = state_22467__$1;
(statearr_22480_22529[(1)] = (17));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (22))){
var inst_22452 = (state_22467[(2)]);
var state_22467__$1 = state_22467;
if(cljs.core.truth_(inst_22452)){
var statearr_22481_22530 = state_22467__$1;
(statearr_22481_22530[(1)] = (23));

} else {
var statearr_22482_22531 = state_22467__$1;
(statearr_22482_22531[(1)] = (24));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (6))){
var inst_22448 = (state_22467[(11)]);
var inst_22446 = (state_22467[(7)]);
var inst_22398 = (state_22467[(8)]);
var inst_22446__$1 = topic_fn.call(null,inst_22398);
var inst_22447 = cljs.core.deref.call(null,mults);
var inst_22448__$1 = cljs.core.get.call(null,inst_22447,inst_22446__$1);
var state_22467__$1 = (function (){var statearr_22483 = state_22467;
(statearr_22483[(11)] = inst_22448__$1);

(statearr_22483[(7)] = inst_22446__$1);

return statearr_22483;
})();
if(cljs.core.truth_(inst_22448__$1)){
var statearr_22484_22532 = state_22467__$1;
(statearr_22484_22532[(1)] = (19));

} else {
var statearr_22485_22533 = state_22467__$1;
(statearr_22485_22533[(1)] = (20));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (25))){
var inst_22457 = (state_22467[(2)]);
var state_22467__$1 = state_22467;
var statearr_22486_22534 = state_22467__$1;
(statearr_22486_22534[(2)] = inst_22457);

(statearr_22486_22534[(1)] = (21));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (17))){
var inst_22422 = (state_22467[(10)]);
var inst_22431 = cljs.core.first.call(null,inst_22422);
var inst_22432 = cljs.core.async.muxch_STAR_.call(null,inst_22431);
var inst_22433 = cljs.core.async.close_BANG_.call(null,inst_22432);
var inst_22434 = cljs.core.next.call(null,inst_22422);
var inst_22408 = inst_22434;
var inst_22409 = null;
var inst_22410 = (0);
var inst_22411 = (0);
var state_22467__$1 = (function (){var statearr_22487 = state_22467;
(statearr_22487[(12)] = inst_22408);

(statearr_22487[(13)] = inst_22411);

(statearr_22487[(14)] = inst_22409);

(statearr_22487[(15)] = inst_22410);

(statearr_22487[(16)] = inst_22433);

return statearr_22487;
})();
var statearr_22488_22535 = state_22467__$1;
(statearr_22488_22535[(2)] = null);

(statearr_22488_22535[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (3))){
var inst_22465 = (state_22467[(2)]);
var state_22467__$1 = state_22467;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_22467__$1,inst_22465);
} else {
if((state_val_22468 === (12))){
var inst_22442 = (state_22467[(2)]);
var state_22467__$1 = state_22467;
var statearr_22489_22536 = state_22467__$1;
(statearr_22489_22536[(2)] = inst_22442);

(statearr_22489_22536[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (2))){
var state_22467__$1 = state_22467;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_22467__$1,(4),ch);
} else {
if((state_val_22468 === (23))){
var state_22467__$1 = state_22467;
var statearr_22490_22537 = state_22467__$1;
(statearr_22490_22537[(2)] = null);

(statearr_22490_22537[(1)] = (25));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (19))){
var inst_22448 = (state_22467[(11)]);
var inst_22398 = (state_22467[(8)]);
var inst_22450 = cljs.core.async.muxch_STAR_.call(null,inst_22448);
var state_22467__$1 = state_22467;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_22467__$1,(22),inst_22450,inst_22398);
} else {
if((state_val_22468 === (11))){
var inst_22422 = (state_22467[(10)]);
var inst_22408 = (state_22467[(12)]);
var inst_22422__$1 = cljs.core.seq.call(null,inst_22408);
var state_22467__$1 = (function (){var statearr_22491 = state_22467;
(statearr_22491[(10)] = inst_22422__$1);

return statearr_22491;
})();
if(inst_22422__$1){
var statearr_22492_22538 = state_22467__$1;
(statearr_22492_22538[(1)] = (13));

} else {
var statearr_22493_22539 = state_22467__$1;
(statearr_22493_22539[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (9))){
var inst_22444 = (state_22467[(2)]);
var state_22467__$1 = state_22467;
var statearr_22494_22540 = state_22467__$1;
(statearr_22494_22540[(2)] = inst_22444);

(statearr_22494_22540[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (5))){
var inst_22405 = cljs.core.deref.call(null,mults);
var inst_22406 = cljs.core.vals.call(null,inst_22405);
var inst_22407 = cljs.core.seq.call(null,inst_22406);
var inst_22408 = inst_22407;
var inst_22409 = null;
var inst_22410 = (0);
var inst_22411 = (0);
var state_22467__$1 = (function (){var statearr_22495 = state_22467;
(statearr_22495[(12)] = inst_22408);

(statearr_22495[(13)] = inst_22411);

(statearr_22495[(14)] = inst_22409);

(statearr_22495[(15)] = inst_22410);

return statearr_22495;
})();
var statearr_22496_22541 = state_22467__$1;
(statearr_22496_22541[(2)] = null);

(statearr_22496_22541[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (14))){
var state_22467__$1 = state_22467;
var statearr_22500_22542 = state_22467__$1;
(statearr_22500_22542[(2)] = null);

(statearr_22500_22542[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (16))){
var inst_22422 = (state_22467[(10)]);
var inst_22426 = cljs.core.chunk_first.call(null,inst_22422);
var inst_22427 = cljs.core.chunk_rest.call(null,inst_22422);
var inst_22428 = cljs.core.count.call(null,inst_22426);
var inst_22408 = inst_22427;
var inst_22409 = inst_22426;
var inst_22410 = inst_22428;
var inst_22411 = (0);
var state_22467__$1 = (function (){var statearr_22501 = state_22467;
(statearr_22501[(12)] = inst_22408);

(statearr_22501[(13)] = inst_22411);

(statearr_22501[(14)] = inst_22409);

(statearr_22501[(15)] = inst_22410);

return statearr_22501;
})();
var statearr_22502_22543 = state_22467__$1;
(statearr_22502_22543[(2)] = null);

(statearr_22502_22543[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (10))){
var inst_22408 = (state_22467[(12)]);
var inst_22411 = (state_22467[(13)]);
var inst_22409 = (state_22467[(14)]);
var inst_22410 = (state_22467[(15)]);
var inst_22416 = cljs.core._nth.call(null,inst_22409,inst_22411);
var inst_22417 = cljs.core.async.muxch_STAR_.call(null,inst_22416);
var inst_22418 = cljs.core.async.close_BANG_.call(null,inst_22417);
var inst_22419 = (inst_22411 + (1));
var tmp22497 = inst_22408;
var tmp22498 = inst_22409;
var tmp22499 = inst_22410;
var inst_22408__$1 = tmp22497;
var inst_22409__$1 = tmp22498;
var inst_22410__$1 = tmp22499;
var inst_22411__$1 = inst_22419;
var state_22467__$1 = (function (){var statearr_22503 = state_22467;
(statearr_22503[(12)] = inst_22408__$1);

(statearr_22503[(13)] = inst_22411__$1);

(statearr_22503[(14)] = inst_22409__$1);

(statearr_22503[(15)] = inst_22410__$1);

(statearr_22503[(17)] = inst_22418);

return statearr_22503;
})();
var statearr_22504_22544 = state_22467__$1;
(statearr_22504_22544[(2)] = null);

(statearr_22504_22544[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (18))){
var inst_22437 = (state_22467[(2)]);
var state_22467__$1 = state_22467;
var statearr_22505_22545 = state_22467__$1;
(statearr_22505_22545[(2)] = inst_22437);

(statearr_22505_22545[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22468 === (8))){
var inst_22411 = (state_22467[(13)]);
var inst_22410 = (state_22467[(15)]);
var inst_22413 = (inst_22411 < inst_22410);
var inst_22414 = inst_22413;
var state_22467__$1 = state_22467;
if(cljs.core.truth_(inst_22414)){
var statearr_22506_22546 = state_22467__$1;
(statearr_22506_22546[(1)] = (10));

} else {
var statearr_22507_22547 = state_22467__$1;
(statearr_22507_22547[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto___22519,mults,ensure_mult,p))
;
return ((function (switch__20508__auto__,c__20620__auto___22519,mults,ensure_mult,p){
return (function() {
var cljs$core$async$state_machine__20509__auto__ = null;
var cljs$core$async$state_machine__20509__auto____0 = (function (){
var statearr_22511 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_22511[(0)] = cljs$core$async$state_machine__20509__auto__);

(statearr_22511[(1)] = (1));

return statearr_22511;
});
var cljs$core$async$state_machine__20509__auto____1 = (function (state_22467){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_22467);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e22512){if((e22512 instanceof Object)){
var ex__20512__auto__ = e22512;
var statearr_22513_22548 = state_22467;
(statearr_22513_22548[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_22467);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e22512;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__22549 = state_22467;
state_22467 = G__22549;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$state_machine__20509__auto__ = function(state_22467){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__20509__auto____1.call(this,state_22467);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__20509__auto____0;
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__20509__auto____1;
return cljs$core$async$state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___22519,mults,ensure_mult,p))
})();
var state__20622__auto__ = (function (){var statearr_22514 = f__20621__auto__.call(null);
(statearr_22514[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___22519);

return statearr_22514;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___22519,mults,ensure_mult,p))
);


return p;
});

cljs.core.async.pub.cljs$lang$maxFixedArity = 3;
/**
 * Subscribes a channel to a topic of a pub.
 * 
 *   By default the channel will be closed when the source closes,
 *   but can be determined by the close? parameter.
 */
cljs.core.async.sub = (function cljs$core$async$sub(var_args){
var args22550 = [];
var len__19356__auto___22553 = arguments.length;
var i__19357__auto___22554 = (0);
while(true){
if((i__19357__auto___22554 < len__19356__auto___22553)){
args22550.push((arguments[i__19357__auto___22554]));

var G__22555 = (i__19357__auto___22554 + (1));
i__19357__auto___22554 = G__22555;
continue;
} else {
}
break;
}

var G__22552 = args22550.length;
switch (G__22552) {
case 3:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 4:
return cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4((arguments[(0)]),(arguments[(1)]),(arguments[(2)]),(arguments[(3)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args22550.length)].join('')));

}
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$3 = (function (p,topic,ch){
return cljs.core.async.sub.call(null,p,topic,ch,true);
});

cljs.core.async.sub.cljs$core$IFn$_invoke$arity$4 = (function (p,topic,ch,close_QMARK_){
return cljs.core.async.sub_STAR_.call(null,p,topic,ch,close_QMARK_);
});

cljs.core.async.sub.cljs$lang$maxFixedArity = 4;
/**
 * Unsubscribes a channel from a topic of a pub
 */
cljs.core.async.unsub = (function cljs$core$async$unsub(p,topic,ch){
return cljs.core.async.unsub_STAR_.call(null,p,topic,ch);
});
/**
 * Unsubscribes all channels from a pub, or a topic of a pub
 */
cljs.core.async.unsub_all = (function cljs$core$async$unsub_all(var_args){
var args22557 = [];
var len__19356__auto___22560 = arguments.length;
var i__19357__auto___22561 = (0);
while(true){
if((i__19357__auto___22561 < len__19356__auto___22560)){
args22557.push((arguments[i__19357__auto___22561]));

var G__22562 = (i__19357__auto___22561 + (1));
i__19357__auto___22561 = G__22562;
continue;
} else {
}
break;
}

var G__22559 = args22557.length;
switch (G__22559) {
case 1:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args22557.length)].join('')));

}
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$1 = (function (p){
return cljs.core.async.unsub_all_STAR_.call(null,p);
});

cljs.core.async.unsub_all.cljs$core$IFn$_invoke$arity$2 = (function (p,topic){
return cljs.core.async.unsub_all_STAR_.call(null,p,topic);
});

cljs.core.async.unsub_all.cljs$lang$maxFixedArity = 2;
/**
 * Takes a function and a collection of source channels, and returns a
 *   channel which contains the values produced by applying f to the set
 *   of first items taken from each source channel, followed by applying
 *   f to the set of second items from each channel, until any one of the
 *   channels is closed, at which point the output channel will be
 *   closed. The returned channel will be unbuffered by default, or a
 *   buf-or-n can be supplied
 */
cljs.core.async.map = (function cljs$core$async$map(var_args){
var args22564 = [];
var len__19356__auto___22635 = arguments.length;
var i__19357__auto___22636 = (0);
while(true){
if((i__19357__auto___22636 < len__19356__auto___22635)){
args22564.push((arguments[i__19357__auto___22636]));

var G__22637 = (i__19357__auto___22636 + (1));
i__19357__auto___22636 = G__22637;
continue;
} else {
}
break;
}

var G__22566 = args22564.length;
switch (G__22566) {
case 2:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.map.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args22564.length)].join('')));

}
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$2 = (function (f,chs){
return cljs.core.async.map.call(null,f,chs,null);
});

cljs.core.async.map.cljs$core$IFn$_invoke$arity$3 = (function (f,chs,buf_or_n){
var chs__$1 = cljs.core.vec.call(null,chs);
var out = cljs.core.async.chan.call(null,buf_or_n);
var cnt = cljs.core.count.call(null,chs__$1);
var rets = cljs.core.object_array.call(null,cnt);
var dchan = cljs.core.async.chan.call(null,(1));
var dctr = cljs.core.atom.call(null,null);
var done = cljs.core.mapv.call(null,((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (i){
return ((function (chs__$1,out,cnt,rets,dchan,dctr){
return (function (ret){
(rets[i] = ret);

if((cljs.core.swap_BANG_.call(null,dctr,cljs.core.dec) === (0))){
return cljs.core.async.put_BANG_.call(null,dchan,rets.slice((0)));
} else {
return null;
}
});
;})(chs__$1,out,cnt,rets,dchan,dctr))
});})(chs__$1,out,cnt,rets,dchan,dctr))
,cljs.core.range.call(null,cnt));
var c__20620__auto___22639 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___22639,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___22639,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function (state_22605){
var state_val_22606 = (state_22605[(1)]);
if((state_val_22606 === (7))){
var state_22605__$1 = state_22605;
var statearr_22607_22640 = state_22605__$1;
(statearr_22607_22640[(2)] = null);

(statearr_22607_22640[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22606 === (1))){
var state_22605__$1 = state_22605;
var statearr_22608_22641 = state_22605__$1;
(statearr_22608_22641[(2)] = null);

(statearr_22608_22641[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22606 === (4))){
var inst_22569 = (state_22605[(7)]);
var inst_22571 = (inst_22569 < cnt);
var state_22605__$1 = state_22605;
if(cljs.core.truth_(inst_22571)){
var statearr_22609_22642 = state_22605__$1;
(statearr_22609_22642[(1)] = (6));

} else {
var statearr_22610_22643 = state_22605__$1;
(statearr_22610_22643[(1)] = (7));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22606 === (15))){
var inst_22601 = (state_22605[(2)]);
var state_22605__$1 = state_22605;
var statearr_22611_22644 = state_22605__$1;
(statearr_22611_22644[(2)] = inst_22601);

(statearr_22611_22644[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22606 === (13))){
var inst_22594 = cljs.core.async.close_BANG_.call(null,out);
var state_22605__$1 = state_22605;
var statearr_22612_22645 = state_22605__$1;
(statearr_22612_22645[(2)] = inst_22594);

(statearr_22612_22645[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22606 === (6))){
var state_22605__$1 = state_22605;
var statearr_22613_22646 = state_22605__$1;
(statearr_22613_22646[(2)] = null);

(statearr_22613_22646[(1)] = (11));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22606 === (3))){
var inst_22603 = (state_22605[(2)]);
var state_22605__$1 = state_22605;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_22605__$1,inst_22603);
} else {
if((state_val_22606 === (12))){
var inst_22591 = (state_22605[(8)]);
var inst_22591__$1 = (state_22605[(2)]);
var inst_22592 = cljs.core.some.call(null,cljs.core.nil_QMARK_,inst_22591__$1);
var state_22605__$1 = (function (){var statearr_22614 = state_22605;
(statearr_22614[(8)] = inst_22591__$1);

return statearr_22614;
})();
if(cljs.core.truth_(inst_22592)){
var statearr_22615_22647 = state_22605__$1;
(statearr_22615_22647[(1)] = (13));

} else {
var statearr_22616_22648 = state_22605__$1;
(statearr_22616_22648[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22606 === (2))){
var inst_22568 = cljs.core.reset_BANG_.call(null,dctr,cnt);
var inst_22569 = (0);
var state_22605__$1 = (function (){var statearr_22617 = state_22605;
(statearr_22617[(7)] = inst_22569);

(statearr_22617[(9)] = inst_22568);

return statearr_22617;
})();
var statearr_22618_22649 = state_22605__$1;
(statearr_22618_22649[(2)] = null);

(statearr_22618_22649[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22606 === (11))){
var inst_22569 = (state_22605[(7)]);
var _ = cljs.core.async.impl.ioc_helpers.add_exception_frame.call(null,state_22605,(10),Object,null,(9));
var inst_22578 = chs__$1.call(null,inst_22569);
var inst_22579 = done.call(null,inst_22569);
var inst_22580 = cljs.core.async.take_BANG_.call(null,inst_22578,inst_22579);
var state_22605__$1 = state_22605;
var statearr_22619_22650 = state_22605__$1;
(statearr_22619_22650[(2)] = inst_22580);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_22605__$1);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22606 === (9))){
var inst_22569 = (state_22605[(7)]);
var inst_22582 = (state_22605[(2)]);
var inst_22583 = (inst_22569 + (1));
var inst_22569__$1 = inst_22583;
var state_22605__$1 = (function (){var statearr_22620 = state_22605;
(statearr_22620[(10)] = inst_22582);

(statearr_22620[(7)] = inst_22569__$1);

return statearr_22620;
})();
var statearr_22621_22651 = state_22605__$1;
(statearr_22621_22651[(2)] = null);

(statearr_22621_22651[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22606 === (5))){
var inst_22589 = (state_22605[(2)]);
var state_22605__$1 = (function (){var statearr_22622 = state_22605;
(statearr_22622[(11)] = inst_22589);

return statearr_22622;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_22605__$1,(12),dchan);
} else {
if((state_val_22606 === (14))){
var inst_22591 = (state_22605[(8)]);
var inst_22596 = cljs.core.apply.call(null,f,inst_22591);
var state_22605__$1 = state_22605;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_22605__$1,(16),out,inst_22596);
} else {
if((state_val_22606 === (16))){
var inst_22598 = (state_22605[(2)]);
var state_22605__$1 = (function (){var statearr_22623 = state_22605;
(statearr_22623[(12)] = inst_22598);

return statearr_22623;
})();
var statearr_22624_22652 = state_22605__$1;
(statearr_22624_22652[(2)] = null);

(statearr_22624_22652[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22606 === (10))){
var inst_22573 = (state_22605[(2)]);
var inst_22574 = cljs.core.swap_BANG_.call(null,dctr,cljs.core.dec);
var state_22605__$1 = (function (){var statearr_22625 = state_22605;
(statearr_22625[(13)] = inst_22573);

return statearr_22625;
})();
var statearr_22626_22653 = state_22605__$1;
(statearr_22626_22653[(2)] = inst_22574);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_22605__$1);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22606 === (8))){
var inst_22587 = (state_22605[(2)]);
var state_22605__$1 = state_22605;
var statearr_22627_22654 = state_22605__$1;
(statearr_22627_22654[(2)] = inst_22587);

(statearr_22627_22654[(1)] = (5));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto___22639,chs__$1,out,cnt,rets,dchan,dctr,done))
;
return ((function (switch__20508__auto__,c__20620__auto___22639,chs__$1,out,cnt,rets,dchan,dctr,done){
return (function() {
var cljs$core$async$state_machine__20509__auto__ = null;
var cljs$core$async$state_machine__20509__auto____0 = (function (){
var statearr_22631 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_22631[(0)] = cljs$core$async$state_machine__20509__auto__);

(statearr_22631[(1)] = (1));

return statearr_22631;
});
var cljs$core$async$state_machine__20509__auto____1 = (function (state_22605){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_22605);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e22632){if((e22632 instanceof Object)){
var ex__20512__auto__ = e22632;
var statearr_22633_22655 = state_22605;
(statearr_22633_22655[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_22605);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e22632;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__22656 = state_22605;
state_22605 = G__22656;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$state_machine__20509__auto__ = function(state_22605){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__20509__auto____1.call(this,state_22605);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__20509__auto____0;
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__20509__auto____1;
return cljs$core$async$state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___22639,chs__$1,out,cnt,rets,dchan,dctr,done))
})();
var state__20622__auto__ = (function (){var statearr_22634 = f__20621__auto__.call(null);
(statearr_22634[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___22639);

return statearr_22634;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___22639,chs__$1,out,cnt,rets,dchan,dctr,done))
);


return out;
});

cljs.core.async.map.cljs$lang$maxFixedArity = 3;
/**
 * Takes a collection of source channels and returns a channel which
 *   contains all values taken from them. The returned channel will be
 *   unbuffered by default, or a buf-or-n can be supplied. The channel
 *   will close after all the source channels have closed.
 */
cljs.core.async.merge = (function cljs$core$async$merge(var_args){
var args22658 = [];
var len__19356__auto___22714 = arguments.length;
var i__19357__auto___22715 = (0);
while(true){
if((i__19357__auto___22715 < len__19356__auto___22714)){
args22658.push((arguments[i__19357__auto___22715]));

var G__22716 = (i__19357__auto___22715 + (1));
i__19357__auto___22715 = G__22716;
continue;
} else {
}
break;
}

var G__22660 = args22658.length;
switch (G__22660) {
case 1:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args22658.length)].join('')));

}
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$1 = (function (chs){
return cljs.core.async.merge.call(null,chs,null);
});

cljs.core.async.merge.cljs$core$IFn$_invoke$arity$2 = (function (chs,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__20620__auto___22718 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___22718,out){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___22718,out){
return (function (state_22690){
var state_val_22691 = (state_22690[(1)]);
if((state_val_22691 === (7))){
var inst_22670 = (state_22690[(7)]);
var inst_22669 = (state_22690[(8)]);
var inst_22669__$1 = (state_22690[(2)]);
var inst_22670__$1 = cljs.core.nth.call(null,inst_22669__$1,(0),null);
var inst_22671 = cljs.core.nth.call(null,inst_22669__$1,(1),null);
var inst_22672 = (inst_22670__$1 == null);
var state_22690__$1 = (function (){var statearr_22692 = state_22690;
(statearr_22692[(7)] = inst_22670__$1);

(statearr_22692[(9)] = inst_22671);

(statearr_22692[(8)] = inst_22669__$1);

return statearr_22692;
})();
if(cljs.core.truth_(inst_22672)){
var statearr_22693_22719 = state_22690__$1;
(statearr_22693_22719[(1)] = (8));

} else {
var statearr_22694_22720 = state_22690__$1;
(statearr_22694_22720[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22691 === (1))){
var inst_22661 = cljs.core.vec.call(null,chs);
var inst_22662 = inst_22661;
var state_22690__$1 = (function (){var statearr_22695 = state_22690;
(statearr_22695[(10)] = inst_22662);

return statearr_22695;
})();
var statearr_22696_22721 = state_22690__$1;
(statearr_22696_22721[(2)] = null);

(statearr_22696_22721[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22691 === (4))){
var inst_22662 = (state_22690[(10)]);
var state_22690__$1 = state_22690;
return cljs.core.async.ioc_alts_BANG_.call(null,state_22690__$1,(7),inst_22662);
} else {
if((state_val_22691 === (6))){
var inst_22686 = (state_22690[(2)]);
var state_22690__$1 = state_22690;
var statearr_22697_22722 = state_22690__$1;
(statearr_22697_22722[(2)] = inst_22686);

(statearr_22697_22722[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22691 === (3))){
var inst_22688 = (state_22690[(2)]);
var state_22690__$1 = state_22690;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_22690__$1,inst_22688);
} else {
if((state_val_22691 === (2))){
var inst_22662 = (state_22690[(10)]);
var inst_22664 = cljs.core.count.call(null,inst_22662);
var inst_22665 = (inst_22664 > (0));
var state_22690__$1 = state_22690;
if(cljs.core.truth_(inst_22665)){
var statearr_22699_22723 = state_22690__$1;
(statearr_22699_22723[(1)] = (4));

} else {
var statearr_22700_22724 = state_22690__$1;
(statearr_22700_22724[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22691 === (11))){
var inst_22662 = (state_22690[(10)]);
var inst_22679 = (state_22690[(2)]);
var tmp22698 = inst_22662;
var inst_22662__$1 = tmp22698;
var state_22690__$1 = (function (){var statearr_22701 = state_22690;
(statearr_22701[(11)] = inst_22679);

(statearr_22701[(10)] = inst_22662__$1);

return statearr_22701;
})();
var statearr_22702_22725 = state_22690__$1;
(statearr_22702_22725[(2)] = null);

(statearr_22702_22725[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22691 === (9))){
var inst_22670 = (state_22690[(7)]);
var state_22690__$1 = state_22690;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_22690__$1,(11),out,inst_22670);
} else {
if((state_val_22691 === (5))){
var inst_22684 = cljs.core.async.close_BANG_.call(null,out);
var state_22690__$1 = state_22690;
var statearr_22703_22726 = state_22690__$1;
(statearr_22703_22726[(2)] = inst_22684);

(statearr_22703_22726[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22691 === (10))){
var inst_22682 = (state_22690[(2)]);
var state_22690__$1 = state_22690;
var statearr_22704_22727 = state_22690__$1;
(statearr_22704_22727[(2)] = inst_22682);

(statearr_22704_22727[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22691 === (8))){
var inst_22670 = (state_22690[(7)]);
var inst_22671 = (state_22690[(9)]);
var inst_22669 = (state_22690[(8)]);
var inst_22662 = (state_22690[(10)]);
var inst_22674 = (function (){var cs = inst_22662;
var vec__22667 = inst_22669;
var v = inst_22670;
var c = inst_22671;
return ((function (cs,vec__22667,v,c,inst_22670,inst_22671,inst_22669,inst_22662,state_val_22691,c__20620__auto___22718,out){
return (function (p1__22657_SHARP_){
return cljs.core.not_EQ_.call(null,c,p1__22657_SHARP_);
});
;})(cs,vec__22667,v,c,inst_22670,inst_22671,inst_22669,inst_22662,state_val_22691,c__20620__auto___22718,out))
})();
var inst_22675 = cljs.core.filterv.call(null,inst_22674,inst_22662);
var inst_22662__$1 = inst_22675;
var state_22690__$1 = (function (){var statearr_22705 = state_22690;
(statearr_22705[(10)] = inst_22662__$1);

return statearr_22705;
})();
var statearr_22706_22728 = state_22690__$1;
(statearr_22706_22728[(2)] = null);

(statearr_22706_22728[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto___22718,out))
;
return ((function (switch__20508__auto__,c__20620__auto___22718,out){
return (function() {
var cljs$core$async$state_machine__20509__auto__ = null;
var cljs$core$async$state_machine__20509__auto____0 = (function (){
var statearr_22710 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_22710[(0)] = cljs$core$async$state_machine__20509__auto__);

(statearr_22710[(1)] = (1));

return statearr_22710;
});
var cljs$core$async$state_machine__20509__auto____1 = (function (state_22690){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_22690);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e22711){if((e22711 instanceof Object)){
var ex__20512__auto__ = e22711;
var statearr_22712_22729 = state_22690;
(statearr_22712_22729[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_22690);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e22711;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__22730 = state_22690;
state_22690 = G__22730;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$state_machine__20509__auto__ = function(state_22690){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__20509__auto____1.call(this,state_22690);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__20509__auto____0;
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__20509__auto____1;
return cljs$core$async$state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___22718,out))
})();
var state__20622__auto__ = (function (){var statearr_22713 = f__20621__auto__.call(null);
(statearr_22713[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___22718);

return statearr_22713;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___22718,out))
);


return out;
});

cljs.core.async.merge.cljs$lang$maxFixedArity = 2;
/**
 * Returns a channel containing the single (collection) result of the
 *   items taken from the channel conjoined to the supplied
 *   collection. ch must close before into produces a result.
 */
cljs.core.async.into = (function cljs$core$async$into(coll,ch){
return cljs.core.async.reduce.call(null,cljs.core.conj,coll,ch);
});
/**
 * Returns a channel that will return, at most, n items from ch. After n items
 * have been returned, or ch has been closed, the return chanel will close.
 * 
 *   The output channel is unbuffered by default, unless buf-or-n is given.
 */
cljs.core.async.take = (function cljs$core$async$take(var_args){
var args22731 = [];
var len__19356__auto___22780 = arguments.length;
var i__19357__auto___22781 = (0);
while(true){
if((i__19357__auto___22781 < len__19356__auto___22780)){
args22731.push((arguments[i__19357__auto___22781]));

var G__22782 = (i__19357__auto___22781 + (1));
i__19357__auto___22781 = G__22782;
continue;
} else {
}
break;
}

var G__22733 = args22731.length;
switch (G__22733) {
case 2:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.take.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args22731.length)].join('')));

}
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.take.call(null,n,ch,null);
});

cljs.core.async.take.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__20620__auto___22784 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___22784,out){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___22784,out){
return (function (state_22757){
var state_val_22758 = (state_22757[(1)]);
if((state_val_22758 === (7))){
var inst_22739 = (state_22757[(7)]);
var inst_22739__$1 = (state_22757[(2)]);
var inst_22740 = (inst_22739__$1 == null);
var inst_22741 = cljs.core.not.call(null,inst_22740);
var state_22757__$1 = (function (){var statearr_22759 = state_22757;
(statearr_22759[(7)] = inst_22739__$1);

return statearr_22759;
})();
if(inst_22741){
var statearr_22760_22785 = state_22757__$1;
(statearr_22760_22785[(1)] = (8));

} else {
var statearr_22761_22786 = state_22757__$1;
(statearr_22761_22786[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22758 === (1))){
var inst_22734 = (0);
var state_22757__$1 = (function (){var statearr_22762 = state_22757;
(statearr_22762[(8)] = inst_22734);

return statearr_22762;
})();
var statearr_22763_22787 = state_22757__$1;
(statearr_22763_22787[(2)] = null);

(statearr_22763_22787[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22758 === (4))){
var state_22757__$1 = state_22757;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_22757__$1,(7),ch);
} else {
if((state_val_22758 === (6))){
var inst_22752 = (state_22757[(2)]);
var state_22757__$1 = state_22757;
var statearr_22764_22788 = state_22757__$1;
(statearr_22764_22788[(2)] = inst_22752);

(statearr_22764_22788[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22758 === (3))){
var inst_22754 = (state_22757[(2)]);
var inst_22755 = cljs.core.async.close_BANG_.call(null,out);
var state_22757__$1 = (function (){var statearr_22765 = state_22757;
(statearr_22765[(9)] = inst_22754);

return statearr_22765;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_22757__$1,inst_22755);
} else {
if((state_val_22758 === (2))){
var inst_22734 = (state_22757[(8)]);
var inst_22736 = (inst_22734 < n);
var state_22757__$1 = state_22757;
if(cljs.core.truth_(inst_22736)){
var statearr_22766_22789 = state_22757__$1;
(statearr_22766_22789[(1)] = (4));

} else {
var statearr_22767_22790 = state_22757__$1;
(statearr_22767_22790[(1)] = (5));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22758 === (11))){
var inst_22734 = (state_22757[(8)]);
var inst_22744 = (state_22757[(2)]);
var inst_22745 = (inst_22734 + (1));
var inst_22734__$1 = inst_22745;
var state_22757__$1 = (function (){var statearr_22768 = state_22757;
(statearr_22768[(10)] = inst_22744);

(statearr_22768[(8)] = inst_22734__$1);

return statearr_22768;
})();
var statearr_22769_22791 = state_22757__$1;
(statearr_22769_22791[(2)] = null);

(statearr_22769_22791[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22758 === (9))){
var state_22757__$1 = state_22757;
var statearr_22770_22792 = state_22757__$1;
(statearr_22770_22792[(2)] = null);

(statearr_22770_22792[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22758 === (5))){
var state_22757__$1 = state_22757;
var statearr_22771_22793 = state_22757__$1;
(statearr_22771_22793[(2)] = null);

(statearr_22771_22793[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22758 === (10))){
var inst_22749 = (state_22757[(2)]);
var state_22757__$1 = state_22757;
var statearr_22772_22794 = state_22757__$1;
(statearr_22772_22794[(2)] = inst_22749);

(statearr_22772_22794[(1)] = (6));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22758 === (8))){
var inst_22739 = (state_22757[(7)]);
var state_22757__$1 = state_22757;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_22757__$1,(11),out,inst_22739);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto___22784,out))
;
return ((function (switch__20508__auto__,c__20620__auto___22784,out){
return (function() {
var cljs$core$async$state_machine__20509__auto__ = null;
var cljs$core$async$state_machine__20509__auto____0 = (function (){
var statearr_22776 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_22776[(0)] = cljs$core$async$state_machine__20509__auto__);

(statearr_22776[(1)] = (1));

return statearr_22776;
});
var cljs$core$async$state_machine__20509__auto____1 = (function (state_22757){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_22757);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e22777){if((e22777 instanceof Object)){
var ex__20512__auto__ = e22777;
var statearr_22778_22795 = state_22757;
(statearr_22778_22795[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_22757);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e22777;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__22796 = state_22757;
state_22757 = G__22796;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$state_machine__20509__auto__ = function(state_22757){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__20509__auto____1.call(this,state_22757);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__20509__auto____0;
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__20509__auto____1;
return cljs$core$async$state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___22784,out))
})();
var state__20622__auto__ = (function (){var statearr_22779 = f__20621__auto__.call(null);
(statearr_22779[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___22784);

return statearr_22779;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___22784,out))
);


return out;
});

cljs.core.async.take.cljs$lang$maxFixedArity = 3;
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_LT_ = (function cljs$core$async$map_LT_(f,ch){
if(typeof cljs.core.async.t_cljs$core$async22804 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async22804 = (function (map_LT_,f,ch,meta22805){
this.map_LT_ = map_LT_;
this.f = f;
this.ch = ch;
this.meta22805 = meta22805;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async22804.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_22806,meta22805__$1){
var self__ = this;
var _22806__$1 = this;
return (new cljs.core.async.t_cljs$core$async22804(self__.map_LT_,self__.f,self__.ch,meta22805__$1));
});

cljs.core.async.t_cljs$core$async22804.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_22806){
var self__ = this;
var _22806__$1 = this;
return self__.meta22805;
});

cljs.core.async.t_cljs$core$async22804.prototype.cljs$core$async$impl$protocols$Channel$ = true;

cljs.core.async.t_cljs$core$async22804.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async22804.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async22804.prototype.cljs$core$async$impl$protocols$ReadPort$ = true;

cljs.core.async.t_cljs$core$async22804.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
var ret = cljs.core.async.impl.protocols.take_BANG_.call(null,self__.ch,(function (){
if(typeof cljs.core.async.t_cljs$core$async22807 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Handler}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async22807 = (function (map_LT_,f,ch,meta22805,_,fn1,meta22808){
this.map_LT_ = map_LT_;
this.f = f;
this.ch = ch;
this.meta22805 = meta22805;
this._ = _;
this.fn1 = fn1;
this.meta22808 = meta22808;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async22807.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = ((function (___$1){
return (function (_22809,meta22808__$1){
var self__ = this;
var _22809__$1 = this;
return (new cljs.core.async.t_cljs$core$async22807(self__.map_LT_,self__.f,self__.ch,self__.meta22805,self__._,self__.fn1,meta22808__$1));
});})(___$1))
;

cljs.core.async.t_cljs$core$async22807.prototype.cljs$core$IMeta$_meta$arity$1 = ((function (___$1){
return (function (_22809){
var self__ = this;
var _22809__$1 = this;
return self__.meta22808;
});})(___$1))
;

cljs.core.async.t_cljs$core$async22807.prototype.cljs$core$async$impl$protocols$Handler$ = true;

cljs.core.async.t_cljs$core$async22807.prototype.cljs$core$async$impl$protocols$Handler$active_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return cljs.core.async.impl.protocols.active_QMARK_.call(null,self__.fn1);
});})(___$1))
;

cljs.core.async.t_cljs$core$async22807.prototype.cljs$core$async$impl$protocols$Handler$blockable_QMARK_$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
return true;
});})(___$1))
;

cljs.core.async.t_cljs$core$async22807.prototype.cljs$core$async$impl$protocols$Handler$commit$arity$1 = ((function (___$1){
return (function (___$1){
var self__ = this;
var ___$2 = this;
var f1 = cljs.core.async.impl.protocols.commit.call(null,self__.fn1);
return ((function (f1,___$2,___$1){
return (function (p1__22797_SHARP_){
return f1.call(null,(((p1__22797_SHARP_ == null))?null:self__.f.call(null,p1__22797_SHARP_)));
});
;})(f1,___$2,___$1))
});})(___$1))
;

cljs.core.async.t_cljs$core$async22807.getBasis = ((function (___$1){
return (function (){
return new cljs.core.PersistentVector(null, 7, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"map<","map<",-1235808357,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null)], null))),new cljs.core.Keyword(null,"doc","doc",1913296891),"Deprecated - this function will be removed. Use transducer instead"], null)),new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta22805","meta22805",-1851527099,null),cljs.core.with_meta(new cljs.core.Symbol(null,"_","_",-1201019570,null),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"tag","tag",-1290361223),new cljs.core.Symbol("cljs.core.async","t_cljs$core$async22804","cljs.core.async/t_cljs$core$async22804",-1478842766,null)], null)),new cljs.core.Symbol(null,"fn1","fn1",895834444,null),new cljs.core.Symbol(null,"meta22808","meta22808",-1129604796,null)], null);
});})(___$1))
;

cljs.core.async.t_cljs$core$async22807.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async22807.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async22807";

cljs.core.async.t_cljs$core$async22807.cljs$lang$ctorPrWriter = ((function (___$1){
return (function (this__18896__auto__,writer__18897__auto__,opt__18898__auto__){
return cljs.core._write.call(null,writer__18897__auto__,"cljs.core.async/t_cljs$core$async22807");
});})(___$1))
;

cljs.core.async.__GT_t_cljs$core$async22807 = ((function (___$1){
return (function cljs$core$async$map_LT__$___GT_t_cljs$core$async22807(map_LT___$1,f__$1,ch__$1,meta22805__$1,___$2,fn1__$1,meta22808){
return (new cljs.core.async.t_cljs$core$async22807(map_LT___$1,f__$1,ch__$1,meta22805__$1,___$2,fn1__$1,meta22808));
});})(___$1))
;

}

return (new cljs.core.async.t_cljs$core$async22807(self__.map_LT_,self__.f,self__.ch,self__.meta22805,___$1,fn1,cljs.core.PersistentArrayMap.EMPTY));
})()
);
if(cljs.core.truth_((function (){var and__18286__auto__ = ret;
if(cljs.core.truth_(and__18286__auto__)){
return !((cljs.core.deref.call(null,ret) == null));
} else {
return and__18286__auto__;
}
})())){
return cljs.core.async.impl.channels.box.call(null,self__.f.call(null,cljs.core.deref.call(null,ret)));
} else {
return ret;
}
});

cljs.core.async.t_cljs$core$async22804.prototype.cljs$core$async$impl$protocols$WritePort$ = true;

cljs.core.async.t_cljs$core$async22804.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_.call(null,self__.ch,val,fn1);
});

cljs.core.async.t_cljs$core$async22804.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"map<","map<",-1235808357,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null)], null))),new cljs.core.Keyword(null,"doc","doc",1913296891),"Deprecated - this function will be removed. Use transducer instead"], null)),new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta22805","meta22805",-1851527099,null)], null);
});

cljs.core.async.t_cljs$core$async22804.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async22804.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async22804";

cljs.core.async.t_cljs$core$async22804.cljs$lang$ctorPrWriter = (function (this__18896__auto__,writer__18897__auto__,opt__18898__auto__){
return cljs.core._write.call(null,writer__18897__auto__,"cljs.core.async/t_cljs$core$async22804");
});

cljs.core.async.__GT_t_cljs$core$async22804 = (function cljs$core$async$map_LT__$___GT_t_cljs$core$async22804(map_LT___$1,f__$1,ch__$1,meta22805){
return (new cljs.core.async.t_cljs$core$async22804(map_LT___$1,f__$1,ch__$1,meta22805));
});

}

return (new cljs.core.async.t_cljs$core$async22804(cljs$core$async$map_LT_,f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.map_GT_ = (function cljs$core$async$map_GT_(f,ch){
if(typeof cljs.core.async.t_cljs$core$async22813 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async22813 = (function (map_GT_,f,ch,meta22814){
this.map_GT_ = map_GT_;
this.f = f;
this.ch = ch;
this.meta22814 = meta22814;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async22813.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_22815,meta22814__$1){
var self__ = this;
var _22815__$1 = this;
return (new cljs.core.async.t_cljs$core$async22813(self__.map_GT_,self__.f,self__.ch,meta22814__$1));
});

cljs.core.async.t_cljs$core$async22813.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_22815){
var self__ = this;
var _22815__$1 = this;
return self__.meta22814;
});

cljs.core.async.t_cljs$core$async22813.prototype.cljs$core$async$impl$protocols$Channel$ = true;

cljs.core.async.t_cljs$core$async22813.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async22813.prototype.cljs$core$async$impl$protocols$ReadPort$ = true;

cljs.core.async.t_cljs$core$async22813.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_.call(null,self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async22813.prototype.cljs$core$async$impl$protocols$WritePort$ = true;

cljs.core.async.t_cljs$core$async22813.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.put_BANG_.call(null,self__.ch,self__.f.call(null,val),fn1);
});

cljs.core.async.t_cljs$core$async22813.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"map>","map>",1676369295,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null)], null))),new cljs.core.Keyword(null,"doc","doc",1913296891),"Deprecated - this function will be removed. Use transducer instead"], null)),new cljs.core.Symbol(null,"f","f",43394975,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta22814","meta22814",-907029476,null)], null);
});

cljs.core.async.t_cljs$core$async22813.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async22813.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async22813";

cljs.core.async.t_cljs$core$async22813.cljs$lang$ctorPrWriter = (function (this__18896__auto__,writer__18897__auto__,opt__18898__auto__){
return cljs.core._write.call(null,writer__18897__auto__,"cljs.core.async/t_cljs$core$async22813");
});

cljs.core.async.__GT_t_cljs$core$async22813 = (function cljs$core$async$map_GT__$___GT_t_cljs$core$async22813(map_GT___$1,f__$1,ch__$1,meta22814){
return (new cljs.core.async.t_cljs$core$async22813(map_GT___$1,f__$1,ch__$1,meta22814));
});

}

return (new cljs.core.async.t_cljs$core$async22813(cljs$core$async$map_GT_,f,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_GT_ = (function cljs$core$async$filter_GT_(p,ch){
if(typeof cljs.core.async.t_cljs$core$async22819 !== 'undefined'){
} else {

/**
* @constructor
 * @implements {cljs.core.async.impl.protocols.Channel}
 * @implements {cljs.core.async.impl.protocols.WritePort}
 * @implements {cljs.core.async.impl.protocols.ReadPort}
 * @implements {cljs.core.IMeta}
 * @implements {cljs.core.IWithMeta}
*/
cljs.core.async.t_cljs$core$async22819 = (function (filter_GT_,p,ch,meta22820){
this.filter_GT_ = filter_GT_;
this.p = p;
this.ch = ch;
this.meta22820 = meta22820;
this.cljs$lang$protocol_mask$partition0$ = 393216;
this.cljs$lang$protocol_mask$partition1$ = 0;
})
cljs.core.async.t_cljs$core$async22819.prototype.cljs$core$IWithMeta$_with_meta$arity$2 = (function (_22821,meta22820__$1){
var self__ = this;
var _22821__$1 = this;
return (new cljs.core.async.t_cljs$core$async22819(self__.filter_GT_,self__.p,self__.ch,meta22820__$1));
});

cljs.core.async.t_cljs$core$async22819.prototype.cljs$core$IMeta$_meta$arity$1 = (function (_22821){
var self__ = this;
var _22821__$1 = this;
return self__.meta22820;
});

cljs.core.async.t_cljs$core$async22819.prototype.cljs$core$async$impl$protocols$Channel$ = true;

cljs.core.async.t_cljs$core$async22819.prototype.cljs$core$async$impl$protocols$Channel$close_BANG_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.close_BANG_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async22819.prototype.cljs$core$async$impl$protocols$Channel$closed_QMARK_$arity$1 = (function (_){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.closed_QMARK_.call(null,self__.ch);
});

cljs.core.async.t_cljs$core$async22819.prototype.cljs$core$async$impl$protocols$ReadPort$ = true;

cljs.core.async.t_cljs$core$async22819.prototype.cljs$core$async$impl$protocols$ReadPort$take_BANG_$arity$2 = (function (_,fn1){
var self__ = this;
var ___$1 = this;
return cljs.core.async.impl.protocols.take_BANG_.call(null,self__.ch,fn1);
});

cljs.core.async.t_cljs$core$async22819.prototype.cljs$core$async$impl$protocols$WritePort$ = true;

cljs.core.async.t_cljs$core$async22819.prototype.cljs$core$async$impl$protocols$WritePort$put_BANG_$arity$3 = (function (_,val,fn1){
var self__ = this;
var ___$1 = this;
if(cljs.core.truth_(self__.p.call(null,val))){
return cljs.core.async.impl.protocols.put_BANG_.call(null,self__.ch,val,fn1);
} else {
return cljs.core.async.impl.channels.box.call(null,cljs.core.not.call(null,cljs.core.async.impl.protocols.closed_QMARK_.call(null,self__.ch)));
}
});

cljs.core.async.t_cljs$core$async22819.getBasis = (function (){
return new cljs.core.PersistentVector(null, 4, 5, cljs.core.PersistentVector.EMPTY_NODE, [cljs.core.with_meta(new cljs.core.Symbol(null,"filter>","filter>",-37644455,null),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"arglists","arglists",1661989754),cljs.core.list(new cljs.core.Symbol(null,"quote","quote",1377916282,null),cljs.core.list(new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Symbol(null,"p","p",1791580836,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null)], null))),new cljs.core.Keyword(null,"doc","doc",1913296891),"Deprecated - this function will be removed. Use transducer instead"], null)),new cljs.core.Symbol(null,"p","p",1791580836,null),new cljs.core.Symbol(null,"ch","ch",1085813622,null),new cljs.core.Symbol(null,"meta22820","meta22820",975728311,null)], null);
});

cljs.core.async.t_cljs$core$async22819.cljs$lang$type = true;

cljs.core.async.t_cljs$core$async22819.cljs$lang$ctorStr = "cljs.core.async/t_cljs$core$async22819";

cljs.core.async.t_cljs$core$async22819.cljs$lang$ctorPrWriter = (function (this__18896__auto__,writer__18897__auto__,opt__18898__auto__){
return cljs.core._write.call(null,writer__18897__auto__,"cljs.core.async/t_cljs$core$async22819");
});

cljs.core.async.__GT_t_cljs$core$async22819 = (function cljs$core$async$filter_GT__$___GT_t_cljs$core$async22819(filter_GT___$1,p__$1,ch__$1,meta22820){
return (new cljs.core.async.t_cljs$core$async22819(filter_GT___$1,p__$1,ch__$1,meta22820));
});

}

return (new cljs.core.async.t_cljs$core$async22819(cljs$core$async$filter_GT_,p,ch,cljs.core.PersistentArrayMap.EMPTY));
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_GT_ = (function cljs$core$async$remove_GT_(p,ch){
return cljs.core.async.filter_GT_.call(null,cljs.core.complement.call(null,p),ch);
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.filter_LT_ = (function cljs$core$async$filter_LT_(var_args){
var args22822 = [];
var len__19356__auto___22866 = arguments.length;
var i__19357__auto___22867 = (0);
while(true){
if((i__19357__auto___22867 < len__19356__auto___22866)){
args22822.push((arguments[i__19357__auto___22867]));

var G__22868 = (i__19357__auto___22867 + (1));
i__19357__auto___22867 = G__22868;
continue;
} else {
}
break;
}

var G__22824 = args22822.length;
switch (G__22824) {
case 2:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args22822.length)].join('')));

}
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.filter_LT_.call(null,p,ch,null);
});

cljs.core.async.filter_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__20620__auto___22870 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___22870,out){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___22870,out){
return (function (state_22845){
var state_val_22846 = (state_22845[(1)]);
if((state_val_22846 === (7))){
var inst_22841 = (state_22845[(2)]);
var state_22845__$1 = state_22845;
var statearr_22847_22871 = state_22845__$1;
(statearr_22847_22871[(2)] = inst_22841);

(statearr_22847_22871[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22846 === (1))){
var state_22845__$1 = state_22845;
var statearr_22848_22872 = state_22845__$1;
(statearr_22848_22872[(2)] = null);

(statearr_22848_22872[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22846 === (4))){
var inst_22827 = (state_22845[(7)]);
var inst_22827__$1 = (state_22845[(2)]);
var inst_22828 = (inst_22827__$1 == null);
var state_22845__$1 = (function (){var statearr_22849 = state_22845;
(statearr_22849[(7)] = inst_22827__$1);

return statearr_22849;
})();
if(cljs.core.truth_(inst_22828)){
var statearr_22850_22873 = state_22845__$1;
(statearr_22850_22873[(1)] = (5));

} else {
var statearr_22851_22874 = state_22845__$1;
(statearr_22851_22874[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22846 === (6))){
var inst_22827 = (state_22845[(7)]);
var inst_22832 = p.call(null,inst_22827);
var state_22845__$1 = state_22845;
if(cljs.core.truth_(inst_22832)){
var statearr_22852_22875 = state_22845__$1;
(statearr_22852_22875[(1)] = (8));

} else {
var statearr_22853_22876 = state_22845__$1;
(statearr_22853_22876[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22846 === (3))){
var inst_22843 = (state_22845[(2)]);
var state_22845__$1 = state_22845;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_22845__$1,inst_22843);
} else {
if((state_val_22846 === (2))){
var state_22845__$1 = state_22845;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_22845__$1,(4),ch);
} else {
if((state_val_22846 === (11))){
var inst_22835 = (state_22845[(2)]);
var state_22845__$1 = state_22845;
var statearr_22854_22877 = state_22845__$1;
(statearr_22854_22877[(2)] = inst_22835);

(statearr_22854_22877[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22846 === (9))){
var state_22845__$1 = state_22845;
var statearr_22855_22878 = state_22845__$1;
(statearr_22855_22878[(2)] = null);

(statearr_22855_22878[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22846 === (5))){
var inst_22830 = cljs.core.async.close_BANG_.call(null,out);
var state_22845__$1 = state_22845;
var statearr_22856_22879 = state_22845__$1;
(statearr_22856_22879[(2)] = inst_22830);

(statearr_22856_22879[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22846 === (10))){
var inst_22838 = (state_22845[(2)]);
var state_22845__$1 = (function (){var statearr_22857 = state_22845;
(statearr_22857[(8)] = inst_22838);

return statearr_22857;
})();
var statearr_22858_22880 = state_22845__$1;
(statearr_22858_22880[(2)] = null);

(statearr_22858_22880[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_22846 === (8))){
var inst_22827 = (state_22845[(7)]);
var state_22845__$1 = state_22845;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_22845__$1,(11),out,inst_22827);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto___22870,out))
;
return ((function (switch__20508__auto__,c__20620__auto___22870,out){
return (function() {
var cljs$core$async$state_machine__20509__auto__ = null;
var cljs$core$async$state_machine__20509__auto____0 = (function (){
var statearr_22862 = [null,null,null,null,null,null,null,null,null];
(statearr_22862[(0)] = cljs$core$async$state_machine__20509__auto__);

(statearr_22862[(1)] = (1));

return statearr_22862;
});
var cljs$core$async$state_machine__20509__auto____1 = (function (state_22845){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_22845);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e22863){if((e22863 instanceof Object)){
var ex__20512__auto__ = e22863;
var statearr_22864_22881 = state_22845;
(statearr_22864_22881[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_22845);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e22863;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__22882 = state_22845;
state_22845 = G__22882;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$state_machine__20509__auto__ = function(state_22845){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__20509__auto____1.call(this,state_22845);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__20509__auto____0;
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__20509__auto____1;
return cljs$core$async$state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___22870,out))
})();
var state__20622__auto__ = (function (){var statearr_22865 = f__20621__auto__.call(null);
(statearr_22865[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___22870);

return statearr_22865;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___22870,out))
);


return out;
});

cljs.core.async.filter_LT_.cljs$lang$maxFixedArity = 3;
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.remove_LT_ = (function cljs$core$async$remove_LT_(var_args){
var args22883 = [];
var len__19356__auto___22886 = arguments.length;
var i__19357__auto___22887 = (0);
while(true){
if((i__19357__auto___22887 < len__19356__auto___22886)){
args22883.push((arguments[i__19357__auto___22887]));

var G__22888 = (i__19357__auto___22887 + (1));
i__19357__auto___22887 = G__22888;
continue;
} else {
}
break;
}

var G__22885 = args22883.length;
switch (G__22885) {
case 2:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args22883.length)].join('')));

}
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$2 = (function (p,ch){
return cljs.core.async.remove_LT_.call(null,p,ch,null);
});

cljs.core.async.remove_LT_.cljs$core$IFn$_invoke$arity$3 = (function (p,ch,buf_or_n){
return cljs.core.async.filter_LT_.call(null,cljs.core.complement.call(null,p),ch,buf_or_n);
});

cljs.core.async.remove_LT_.cljs$lang$maxFixedArity = 3;
cljs.core.async.mapcat_STAR_ = (function cljs$core$async$mapcat_STAR_(f,in$,out){
var c__20620__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto__){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto__){
return (function (state_23055){
var state_val_23056 = (state_23055[(1)]);
if((state_val_23056 === (7))){
var inst_23051 = (state_23055[(2)]);
var state_23055__$1 = state_23055;
var statearr_23057_23098 = state_23055__$1;
(statearr_23057_23098[(2)] = inst_23051);

(statearr_23057_23098[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (20))){
var inst_23021 = (state_23055[(7)]);
var inst_23032 = (state_23055[(2)]);
var inst_23033 = cljs.core.next.call(null,inst_23021);
var inst_23007 = inst_23033;
var inst_23008 = null;
var inst_23009 = (0);
var inst_23010 = (0);
var state_23055__$1 = (function (){var statearr_23058 = state_23055;
(statearr_23058[(8)] = inst_23008);

(statearr_23058[(9)] = inst_23032);

(statearr_23058[(10)] = inst_23007);

(statearr_23058[(11)] = inst_23009);

(statearr_23058[(12)] = inst_23010);

return statearr_23058;
})();
var statearr_23059_23099 = state_23055__$1;
(statearr_23059_23099[(2)] = null);

(statearr_23059_23099[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (1))){
var state_23055__$1 = state_23055;
var statearr_23060_23100 = state_23055__$1;
(statearr_23060_23100[(2)] = null);

(statearr_23060_23100[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (4))){
var inst_22996 = (state_23055[(13)]);
var inst_22996__$1 = (state_23055[(2)]);
var inst_22997 = (inst_22996__$1 == null);
var state_23055__$1 = (function (){var statearr_23061 = state_23055;
(statearr_23061[(13)] = inst_22996__$1);

return statearr_23061;
})();
if(cljs.core.truth_(inst_22997)){
var statearr_23062_23101 = state_23055__$1;
(statearr_23062_23101[(1)] = (5));

} else {
var statearr_23063_23102 = state_23055__$1;
(statearr_23063_23102[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (15))){
var state_23055__$1 = state_23055;
var statearr_23067_23103 = state_23055__$1;
(statearr_23067_23103[(2)] = null);

(statearr_23067_23103[(1)] = (16));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (21))){
var state_23055__$1 = state_23055;
var statearr_23068_23104 = state_23055__$1;
(statearr_23068_23104[(2)] = null);

(statearr_23068_23104[(1)] = (23));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (13))){
var inst_23008 = (state_23055[(8)]);
var inst_23007 = (state_23055[(10)]);
var inst_23009 = (state_23055[(11)]);
var inst_23010 = (state_23055[(12)]);
var inst_23017 = (state_23055[(2)]);
var inst_23018 = (inst_23010 + (1));
var tmp23064 = inst_23008;
var tmp23065 = inst_23007;
var tmp23066 = inst_23009;
var inst_23007__$1 = tmp23065;
var inst_23008__$1 = tmp23064;
var inst_23009__$1 = tmp23066;
var inst_23010__$1 = inst_23018;
var state_23055__$1 = (function (){var statearr_23069 = state_23055;
(statearr_23069[(14)] = inst_23017);

(statearr_23069[(8)] = inst_23008__$1);

(statearr_23069[(10)] = inst_23007__$1);

(statearr_23069[(11)] = inst_23009__$1);

(statearr_23069[(12)] = inst_23010__$1);

return statearr_23069;
})();
var statearr_23070_23105 = state_23055__$1;
(statearr_23070_23105[(2)] = null);

(statearr_23070_23105[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (22))){
var state_23055__$1 = state_23055;
var statearr_23071_23106 = state_23055__$1;
(statearr_23071_23106[(2)] = null);

(statearr_23071_23106[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (6))){
var inst_22996 = (state_23055[(13)]);
var inst_23005 = f.call(null,inst_22996);
var inst_23006 = cljs.core.seq.call(null,inst_23005);
var inst_23007 = inst_23006;
var inst_23008 = null;
var inst_23009 = (0);
var inst_23010 = (0);
var state_23055__$1 = (function (){var statearr_23072 = state_23055;
(statearr_23072[(8)] = inst_23008);

(statearr_23072[(10)] = inst_23007);

(statearr_23072[(11)] = inst_23009);

(statearr_23072[(12)] = inst_23010);

return statearr_23072;
})();
var statearr_23073_23107 = state_23055__$1;
(statearr_23073_23107[(2)] = null);

(statearr_23073_23107[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (17))){
var inst_23021 = (state_23055[(7)]);
var inst_23025 = cljs.core.chunk_first.call(null,inst_23021);
var inst_23026 = cljs.core.chunk_rest.call(null,inst_23021);
var inst_23027 = cljs.core.count.call(null,inst_23025);
var inst_23007 = inst_23026;
var inst_23008 = inst_23025;
var inst_23009 = inst_23027;
var inst_23010 = (0);
var state_23055__$1 = (function (){var statearr_23074 = state_23055;
(statearr_23074[(8)] = inst_23008);

(statearr_23074[(10)] = inst_23007);

(statearr_23074[(11)] = inst_23009);

(statearr_23074[(12)] = inst_23010);

return statearr_23074;
})();
var statearr_23075_23108 = state_23055__$1;
(statearr_23075_23108[(2)] = null);

(statearr_23075_23108[(1)] = (8));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (3))){
var inst_23053 = (state_23055[(2)]);
var state_23055__$1 = state_23055;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_23055__$1,inst_23053);
} else {
if((state_val_23056 === (12))){
var inst_23041 = (state_23055[(2)]);
var state_23055__$1 = state_23055;
var statearr_23076_23109 = state_23055__$1;
(statearr_23076_23109[(2)] = inst_23041);

(statearr_23076_23109[(1)] = (9));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (2))){
var state_23055__$1 = state_23055;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_23055__$1,(4),in$);
} else {
if((state_val_23056 === (23))){
var inst_23049 = (state_23055[(2)]);
var state_23055__$1 = state_23055;
var statearr_23077_23110 = state_23055__$1;
(statearr_23077_23110[(2)] = inst_23049);

(statearr_23077_23110[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (19))){
var inst_23036 = (state_23055[(2)]);
var state_23055__$1 = state_23055;
var statearr_23078_23111 = state_23055__$1;
(statearr_23078_23111[(2)] = inst_23036);

(statearr_23078_23111[(1)] = (16));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (11))){
var inst_23007 = (state_23055[(10)]);
var inst_23021 = (state_23055[(7)]);
var inst_23021__$1 = cljs.core.seq.call(null,inst_23007);
var state_23055__$1 = (function (){var statearr_23079 = state_23055;
(statearr_23079[(7)] = inst_23021__$1);

return statearr_23079;
})();
if(inst_23021__$1){
var statearr_23080_23112 = state_23055__$1;
(statearr_23080_23112[(1)] = (14));

} else {
var statearr_23081_23113 = state_23055__$1;
(statearr_23081_23113[(1)] = (15));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (9))){
var inst_23043 = (state_23055[(2)]);
var inst_23044 = cljs.core.async.impl.protocols.closed_QMARK_.call(null,out);
var state_23055__$1 = (function (){var statearr_23082 = state_23055;
(statearr_23082[(15)] = inst_23043);

return statearr_23082;
})();
if(cljs.core.truth_(inst_23044)){
var statearr_23083_23114 = state_23055__$1;
(statearr_23083_23114[(1)] = (21));

} else {
var statearr_23084_23115 = state_23055__$1;
(statearr_23084_23115[(1)] = (22));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (5))){
var inst_22999 = cljs.core.async.close_BANG_.call(null,out);
var state_23055__$1 = state_23055;
var statearr_23085_23116 = state_23055__$1;
(statearr_23085_23116[(2)] = inst_22999);

(statearr_23085_23116[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (14))){
var inst_23021 = (state_23055[(7)]);
var inst_23023 = cljs.core.chunked_seq_QMARK_.call(null,inst_23021);
var state_23055__$1 = state_23055;
if(inst_23023){
var statearr_23086_23117 = state_23055__$1;
(statearr_23086_23117[(1)] = (17));

} else {
var statearr_23087_23118 = state_23055__$1;
(statearr_23087_23118[(1)] = (18));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (16))){
var inst_23039 = (state_23055[(2)]);
var state_23055__$1 = state_23055;
var statearr_23088_23119 = state_23055__$1;
(statearr_23088_23119[(2)] = inst_23039);

(statearr_23088_23119[(1)] = (12));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23056 === (10))){
var inst_23008 = (state_23055[(8)]);
var inst_23010 = (state_23055[(12)]);
var inst_23015 = cljs.core._nth.call(null,inst_23008,inst_23010);
var state_23055__$1 = state_23055;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_23055__$1,(13),out,inst_23015);
} else {
if((state_val_23056 === (18))){
var inst_23021 = (state_23055[(7)]);
var inst_23030 = cljs.core.first.call(null,inst_23021);
var state_23055__$1 = state_23055;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_23055__$1,(20),out,inst_23030);
} else {
if((state_val_23056 === (8))){
var inst_23009 = (state_23055[(11)]);
var inst_23010 = (state_23055[(12)]);
var inst_23012 = (inst_23010 < inst_23009);
var inst_23013 = inst_23012;
var state_23055__$1 = state_23055;
if(cljs.core.truth_(inst_23013)){
var statearr_23089_23120 = state_23055__$1;
(statearr_23089_23120[(1)] = (10));

} else {
var statearr_23090_23121 = state_23055__$1;
(statearr_23090_23121[(1)] = (11));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto__))
;
return ((function (switch__20508__auto__,c__20620__auto__){
return (function() {
var cljs$core$async$mapcat_STAR__$_state_machine__20509__auto__ = null;
var cljs$core$async$mapcat_STAR__$_state_machine__20509__auto____0 = (function (){
var statearr_23094 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_23094[(0)] = cljs$core$async$mapcat_STAR__$_state_machine__20509__auto__);

(statearr_23094[(1)] = (1));

return statearr_23094;
});
var cljs$core$async$mapcat_STAR__$_state_machine__20509__auto____1 = (function (state_23055){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_23055);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e23095){if((e23095 instanceof Object)){
var ex__20512__auto__ = e23095;
var statearr_23096_23122 = state_23055;
(statearr_23096_23122[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_23055);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e23095;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__23123 = state_23055;
state_23055 = G__23123;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$mapcat_STAR__$_state_machine__20509__auto__ = function(state_23055){
switch(arguments.length){
case 0:
return cljs$core$async$mapcat_STAR__$_state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$mapcat_STAR__$_state_machine__20509__auto____1.call(this,state_23055);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$mapcat_STAR__$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$mapcat_STAR__$_state_machine__20509__auto____0;
cljs$core$async$mapcat_STAR__$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$mapcat_STAR__$_state_machine__20509__auto____1;
return cljs$core$async$mapcat_STAR__$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto__))
})();
var state__20622__auto__ = (function (){var statearr_23097 = f__20621__auto__.call(null);
(statearr_23097[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto__);

return statearr_23097;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto__))
);

return c__20620__auto__;
});
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_LT_ = (function cljs$core$async$mapcat_LT_(var_args){
var args23124 = [];
var len__19356__auto___23127 = arguments.length;
var i__19357__auto___23128 = (0);
while(true){
if((i__19357__auto___23128 < len__19356__auto___23127)){
args23124.push((arguments[i__19357__auto___23128]));

var G__23129 = (i__19357__auto___23128 + (1));
i__19357__auto___23128 = G__23129;
continue;
} else {
}
break;
}

var G__23126 = args23124.length;
switch (G__23126) {
case 2:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args23124.length)].join('')));

}
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$2 = (function (f,in$){
return cljs.core.async.mapcat_LT_.call(null,f,in$,null);
});

cljs.core.async.mapcat_LT_.cljs$core$IFn$_invoke$arity$3 = (function (f,in$,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
cljs.core.async.mapcat_STAR_.call(null,f,in$,out);

return out;
});

cljs.core.async.mapcat_LT_.cljs$lang$maxFixedArity = 3;
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.mapcat_GT_ = (function cljs$core$async$mapcat_GT_(var_args){
var args23131 = [];
var len__19356__auto___23134 = arguments.length;
var i__19357__auto___23135 = (0);
while(true){
if((i__19357__auto___23135 < len__19356__auto___23134)){
args23131.push((arguments[i__19357__auto___23135]));

var G__23136 = (i__19357__auto___23135 + (1));
i__19357__auto___23135 = G__23136;
continue;
} else {
}
break;
}

var G__23133 = args23131.length;
switch (G__23133) {
case 2:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args23131.length)].join('')));

}
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$2 = (function (f,out){
return cljs.core.async.mapcat_GT_.call(null,f,out,null);
});

cljs.core.async.mapcat_GT_.cljs$core$IFn$_invoke$arity$3 = (function (f,out,buf_or_n){
var in$ = cljs.core.async.chan.call(null,buf_or_n);
cljs.core.async.mapcat_STAR_.call(null,f,in$,out);

return in$;
});

cljs.core.async.mapcat_GT_.cljs$lang$maxFixedArity = 3;
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.unique = (function cljs$core$async$unique(var_args){
var args23138 = [];
var len__19356__auto___23189 = arguments.length;
var i__19357__auto___23190 = (0);
while(true){
if((i__19357__auto___23190 < len__19356__auto___23189)){
args23138.push((arguments[i__19357__auto___23190]));

var G__23191 = (i__19357__auto___23190 + (1));
i__19357__auto___23190 = G__23191;
continue;
} else {
}
break;
}

var G__23140 = args23138.length;
switch (G__23140) {
case 1:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 2:
return cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args23138.length)].join('')));

}
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$1 = (function (ch){
return cljs.core.async.unique.call(null,ch,null);
});

cljs.core.async.unique.cljs$core$IFn$_invoke$arity$2 = (function (ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__20620__auto___23193 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___23193,out){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___23193,out){
return (function (state_23164){
var state_val_23165 = (state_23164[(1)]);
if((state_val_23165 === (7))){
var inst_23159 = (state_23164[(2)]);
var state_23164__$1 = state_23164;
var statearr_23166_23194 = state_23164__$1;
(statearr_23166_23194[(2)] = inst_23159);

(statearr_23166_23194[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23165 === (1))){
var inst_23141 = null;
var state_23164__$1 = (function (){var statearr_23167 = state_23164;
(statearr_23167[(7)] = inst_23141);

return statearr_23167;
})();
var statearr_23168_23195 = state_23164__$1;
(statearr_23168_23195[(2)] = null);

(statearr_23168_23195[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23165 === (4))){
var inst_23144 = (state_23164[(8)]);
var inst_23144__$1 = (state_23164[(2)]);
var inst_23145 = (inst_23144__$1 == null);
var inst_23146 = cljs.core.not.call(null,inst_23145);
var state_23164__$1 = (function (){var statearr_23169 = state_23164;
(statearr_23169[(8)] = inst_23144__$1);

return statearr_23169;
})();
if(inst_23146){
var statearr_23170_23196 = state_23164__$1;
(statearr_23170_23196[(1)] = (5));

} else {
var statearr_23171_23197 = state_23164__$1;
(statearr_23171_23197[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23165 === (6))){
var state_23164__$1 = state_23164;
var statearr_23172_23198 = state_23164__$1;
(statearr_23172_23198[(2)] = null);

(statearr_23172_23198[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23165 === (3))){
var inst_23161 = (state_23164[(2)]);
var inst_23162 = cljs.core.async.close_BANG_.call(null,out);
var state_23164__$1 = (function (){var statearr_23173 = state_23164;
(statearr_23173[(9)] = inst_23161);

return statearr_23173;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_23164__$1,inst_23162);
} else {
if((state_val_23165 === (2))){
var state_23164__$1 = state_23164;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_23164__$1,(4),ch);
} else {
if((state_val_23165 === (11))){
var inst_23144 = (state_23164[(8)]);
var inst_23153 = (state_23164[(2)]);
var inst_23141 = inst_23144;
var state_23164__$1 = (function (){var statearr_23174 = state_23164;
(statearr_23174[(10)] = inst_23153);

(statearr_23174[(7)] = inst_23141);

return statearr_23174;
})();
var statearr_23175_23199 = state_23164__$1;
(statearr_23175_23199[(2)] = null);

(statearr_23175_23199[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23165 === (9))){
var inst_23144 = (state_23164[(8)]);
var state_23164__$1 = state_23164;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_23164__$1,(11),out,inst_23144);
} else {
if((state_val_23165 === (5))){
var inst_23144 = (state_23164[(8)]);
var inst_23141 = (state_23164[(7)]);
var inst_23148 = cljs.core._EQ_.call(null,inst_23144,inst_23141);
var state_23164__$1 = state_23164;
if(inst_23148){
var statearr_23177_23200 = state_23164__$1;
(statearr_23177_23200[(1)] = (8));

} else {
var statearr_23178_23201 = state_23164__$1;
(statearr_23178_23201[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23165 === (10))){
var inst_23156 = (state_23164[(2)]);
var state_23164__$1 = state_23164;
var statearr_23179_23202 = state_23164__$1;
(statearr_23179_23202[(2)] = inst_23156);

(statearr_23179_23202[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23165 === (8))){
var inst_23141 = (state_23164[(7)]);
var tmp23176 = inst_23141;
var inst_23141__$1 = tmp23176;
var state_23164__$1 = (function (){var statearr_23180 = state_23164;
(statearr_23180[(7)] = inst_23141__$1);

return statearr_23180;
})();
var statearr_23181_23203 = state_23164__$1;
(statearr_23181_23203[(2)] = null);

(statearr_23181_23203[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto___23193,out))
;
return ((function (switch__20508__auto__,c__20620__auto___23193,out){
return (function() {
var cljs$core$async$state_machine__20509__auto__ = null;
var cljs$core$async$state_machine__20509__auto____0 = (function (){
var statearr_23185 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_23185[(0)] = cljs$core$async$state_machine__20509__auto__);

(statearr_23185[(1)] = (1));

return statearr_23185;
});
var cljs$core$async$state_machine__20509__auto____1 = (function (state_23164){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_23164);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e23186){if((e23186 instanceof Object)){
var ex__20512__auto__ = e23186;
var statearr_23187_23204 = state_23164;
(statearr_23187_23204[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_23164);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e23186;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__23205 = state_23164;
state_23164 = G__23205;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$state_machine__20509__auto__ = function(state_23164){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__20509__auto____1.call(this,state_23164);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__20509__auto____0;
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__20509__auto____1;
return cljs$core$async$state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___23193,out))
})();
var state__20622__auto__ = (function (){var statearr_23188 = f__20621__auto__.call(null);
(statearr_23188[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___23193);

return statearr_23188;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___23193,out))
);


return out;
});

cljs.core.async.unique.cljs$lang$maxFixedArity = 2;
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition = (function cljs$core$async$partition(var_args){
var args23206 = [];
var len__19356__auto___23276 = arguments.length;
var i__19357__auto___23277 = (0);
while(true){
if((i__19357__auto___23277 < len__19356__auto___23276)){
args23206.push((arguments[i__19357__auto___23277]));

var G__23278 = (i__19357__auto___23277 + (1));
i__19357__auto___23277 = G__23278;
continue;
} else {
}
break;
}

var G__23208 = args23206.length;
switch (G__23208) {
case 2:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args23206.length)].join('')));

}
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$2 = (function (n,ch){
return cljs.core.async.partition.call(null,n,ch,null);
});

cljs.core.async.partition.cljs$core$IFn$_invoke$arity$3 = (function (n,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__20620__auto___23280 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___23280,out){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___23280,out){
return (function (state_23246){
var state_val_23247 = (state_23246[(1)]);
if((state_val_23247 === (7))){
var inst_23242 = (state_23246[(2)]);
var state_23246__$1 = state_23246;
var statearr_23248_23281 = state_23246__$1;
(statearr_23248_23281[(2)] = inst_23242);

(statearr_23248_23281[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23247 === (1))){
var inst_23209 = (new Array(n));
var inst_23210 = inst_23209;
var inst_23211 = (0);
var state_23246__$1 = (function (){var statearr_23249 = state_23246;
(statearr_23249[(7)] = inst_23210);

(statearr_23249[(8)] = inst_23211);

return statearr_23249;
})();
var statearr_23250_23282 = state_23246__$1;
(statearr_23250_23282[(2)] = null);

(statearr_23250_23282[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23247 === (4))){
var inst_23214 = (state_23246[(9)]);
var inst_23214__$1 = (state_23246[(2)]);
var inst_23215 = (inst_23214__$1 == null);
var inst_23216 = cljs.core.not.call(null,inst_23215);
var state_23246__$1 = (function (){var statearr_23251 = state_23246;
(statearr_23251[(9)] = inst_23214__$1);

return statearr_23251;
})();
if(inst_23216){
var statearr_23252_23283 = state_23246__$1;
(statearr_23252_23283[(1)] = (5));

} else {
var statearr_23253_23284 = state_23246__$1;
(statearr_23253_23284[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23247 === (15))){
var inst_23236 = (state_23246[(2)]);
var state_23246__$1 = state_23246;
var statearr_23254_23285 = state_23246__$1;
(statearr_23254_23285[(2)] = inst_23236);

(statearr_23254_23285[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23247 === (13))){
var state_23246__$1 = state_23246;
var statearr_23255_23286 = state_23246__$1;
(statearr_23255_23286[(2)] = null);

(statearr_23255_23286[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23247 === (6))){
var inst_23211 = (state_23246[(8)]);
var inst_23232 = (inst_23211 > (0));
var state_23246__$1 = state_23246;
if(cljs.core.truth_(inst_23232)){
var statearr_23256_23287 = state_23246__$1;
(statearr_23256_23287[(1)] = (12));

} else {
var statearr_23257_23288 = state_23246__$1;
(statearr_23257_23288[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23247 === (3))){
var inst_23244 = (state_23246[(2)]);
var state_23246__$1 = state_23246;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_23246__$1,inst_23244);
} else {
if((state_val_23247 === (12))){
var inst_23210 = (state_23246[(7)]);
var inst_23234 = cljs.core.vec.call(null,inst_23210);
var state_23246__$1 = state_23246;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_23246__$1,(15),out,inst_23234);
} else {
if((state_val_23247 === (2))){
var state_23246__$1 = state_23246;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_23246__$1,(4),ch);
} else {
if((state_val_23247 === (11))){
var inst_23226 = (state_23246[(2)]);
var inst_23227 = (new Array(n));
var inst_23210 = inst_23227;
var inst_23211 = (0);
var state_23246__$1 = (function (){var statearr_23258 = state_23246;
(statearr_23258[(10)] = inst_23226);

(statearr_23258[(7)] = inst_23210);

(statearr_23258[(8)] = inst_23211);

return statearr_23258;
})();
var statearr_23259_23289 = state_23246__$1;
(statearr_23259_23289[(2)] = null);

(statearr_23259_23289[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23247 === (9))){
var inst_23210 = (state_23246[(7)]);
var inst_23224 = cljs.core.vec.call(null,inst_23210);
var state_23246__$1 = state_23246;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_23246__$1,(11),out,inst_23224);
} else {
if((state_val_23247 === (5))){
var inst_23219 = (state_23246[(11)]);
var inst_23210 = (state_23246[(7)]);
var inst_23211 = (state_23246[(8)]);
var inst_23214 = (state_23246[(9)]);
var inst_23218 = (inst_23210[inst_23211] = inst_23214);
var inst_23219__$1 = (inst_23211 + (1));
var inst_23220 = (inst_23219__$1 < n);
var state_23246__$1 = (function (){var statearr_23260 = state_23246;
(statearr_23260[(11)] = inst_23219__$1);

(statearr_23260[(12)] = inst_23218);

return statearr_23260;
})();
if(cljs.core.truth_(inst_23220)){
var statearr_23261_23290 = state_23246__$1;
(statearr_23261_23290[(1)] = (8));

} else {
var statearr_23262_23291 = state_23246__$1;
(statearr_23262_23291[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23247 === (14))){
var inst_23239 = (state_23246[(2)]);
var inst_23240 = cljs.core.async.close_BANG_.call(null,out);
var state_23246__$1 = (function (){var statearr_23264 = state_23246;
(statearr_23264[(13)] = inst_23239);

return statearr_23264;
})();
var statearr_23265_23292 = state_23246__$1;
(statearr_23265_23292[(2)] = inst_23240);

(statearr_23265_23292[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23247 === (10))){
var inst_23230 = (state_23246[(2)]);
var state_23246__$1 = state_23246;
var statearr_23266_23293 = state_23246__$1;
(statearr_23266_23293[(2)] = inst_23230);

(statearr_23266_23293[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23247 === (8))){
var inst_23219 = (state_23246[(11)]);
var inst_23210 = (state_23246[(7)]);
var tmp23263 = inst_23210;
var inst_23210__$1 = tmp23263;
var inst_23211 = inst_23219;
var state_23246__$1 = (function (){var statearr_23267 = state_23246;
(statearr_23267[(7)] = inst_23210__$1);

(statearr_23267[(8)] = inst_23211);

return statearr_23267;
})();
var statearr_23268_23294 = state_23246__$1;
(statearr_23268_23294[(2)] = null);

(statearr_23268_23294[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto___23280,out))
;
return ((function (switch__20508__auto__,c__20620__auto___23280,out){
return (function() {
var cljs$core$async$state_machine__20509__auto__ = null;
var cljs$core$async$state_machine__20509__auto____0 = (function (){
var statearr_23272 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_23272[(0)] = cljs$core$async$state_machine__20509__auto__);

(statearr_23272[(1)] = (1));

return statearr_23272;
});
var cljs$core$async$state_machine__20509__auto____1 = (function (state_23246){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_23246);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e23273){if((e23273 instanceof Object)){
var ex__20512__auto__ = e23273;
var statearr_23274_23295 = state_23246;
(statearr_23274_23295[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_23246);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e23273;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__23296 = state_23246;
state_23246 = G__23296;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$state_machine__20509__auto__ = function(state_23246){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__20509__auto____1.call(this,state_23246);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__20509__auto____0;
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__20509__auto____1;
return cljs$core$async$state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___23280,out))
})();
var state__20622__auto__ = (function (){var statearr_23275 = f__20621__auto__.call(null);
(statearr_23275[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___23280);

return statearr_23275;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___23280,out))
);


return out;
});

cljs.core.async.partition.cljs$lang$maxFixedArity = 3;
/**
 * Deprecated - this function will be removed. Use transducer instead
 */
cljs.core.async.partition_by = (function cljs$core$async$partition_by(var_args){
var args23297 = [];
var len__19356__auto___23371 = arguments.length;
var i__19357__auto___23372 = (0);
while(true){
if((i__19357__auto___23372 < len__19356__auto___23371)){
args23297.push((arguments[i__19357__auto___23372]));

var G__23373 = (i__19357__auto___23372 + (1));
i__19357__auto___23372 = G__23373;
continue;
} else {
}
break;
}

var G__23299 = args23297.length;
switch (G__23299) {
case 2:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 3:
return cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args23297.length)].join('')));

}
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$2 = (function (f,ch){
return cljs.core.async.partition_by.call(null,f,ch,null);
});

cljs.core.async.partition_by.cljs$core$IFn$_invoke$arity$3 = (function (f,ch,buf_or_n){
var out = cljs.core.async.chan.call(null,buf_or_n);
var c__20620__auto___23375 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___23375,out){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___23375,out){
return (function (state_23341){
var state_val_23342 = (state_23341[(1)]);
if((state_val_23342 === (7))){
var inst_23337 = (state_23341[(2)]);
var state_23341__$1 = state_23341;
var statearr_23343_23376 = state_23341__$1;
(statearr_23343_23376[(2)] = inst_23337);

(statearr_23343_23376[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23342 === (1))){
var inst_23300 = [];
var inst_23301 = inst_23300;
var inst_23302 = new cljs.core.Keyword("cljs.core.async","nothing","cljs.core.async/nothing",-69252123);
var state_23341__$1 = (function (){var statearr_23344 = state_23341;
(statearr_23344[(7)] = inst_23302);

(statearr_23344[(8)] = inst_23301);

return statearr_23344;
})();
var statearr_23345_23377 = state_23341__$1;
(statearr_23345_23377[(2)] = null);

(statearr_23345_23377[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23342 === (4))){
var inst_23305 = (state_23341[(9)]);
var inst_23305__$1 = (state_23341[(2)]);
var inst_23306 = (inst_23305__$1 == null);
var inst_23307 = cljs.core.not.call(null,inst_23306);
var state_23341__$1 = (function (){var statearr_23346 = state_23341;
(statearr_23346[(9)] = inst_23305__$1);

return statearr_23346;
})();
if(inst_23307){
var statearr_23347_23378 = state_23341__$1;
(statearr_23347_23378[(1)] = (5));

} else {
var statearr_23348_23379 = state_23341__$1;
(statearr_23348_23379[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23342 === (15))){
var inst_23331 = (state_23341[(2)]);
var state_23341__$1 = state_23341;
var statearr_23349_23380 = state_23341__$1;
(statearr_23349_23380[(2)] = inst_23331);

(statearr_23349_23380[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23342 === (13))){
var state_23341__$1 = state_23341;
var statearr_23350_23381 = state_23341__$1;
(statearr_23350_23381[(2)] = null);

(statearr_23350_23381[(1)] = (14));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23342 === (6))){
var inst_23301 = (state_23341[(8)]);
var inst_23326 = inst_23301.length;
var inst_23327 = (inst_23326 > (0));
var state_23341__$1 = state_23341;
if(cljs.core.truth_(inst_23327)){
var statearr_23351_23382 = state_23341__$1;
(statearr_23351_23382[(1)] = (12));

} else {
var statearr_23352_23383 = state_23341__$1;
(statearr_23352_23383[(1)] = (13));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23342 === (3))){
var inst_23339 = (state_23341[(2)]);
var state_23341__$1 = state_23341;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_23341__$1,inst_23339);
} else {
if((state_val_23342 === (12))){
var inst_23301 = (state_23341[(8)]);
var inst_23329 = cljs.core.vec.call(null,inst_23301);
var state_23341__$1 = state_23341;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_23341__$1,(15),out,inst_23329);
} else {
if((state_val_23342 === (2))){
var state_23341__$1 = state_23341;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_23341__$1,(4),ch);
} else {
if((state_val_23342 === (11))){
var inst_23305 = (state_23341[(9)]);
var inst_23309 = (state_23341[(10)]);
var inst_23319 = (state_23341[(2)]);
var inst_23320 = [];
var inst_23321 = inst_23320.push(inst_23305);
var inst_23301 = inst_23320;
var inst_23302 = inst_23309;
var state_23341__$1 = (function (){var statearr_23353 = state_23341;
(statearr_23353[(11)] = inst_23321);

(statearr_23353[(7)] = inst_23302);

(statearr_23353[(12)] = inst_23319);

(statearr_23353[(8)] = inst_23301);

return statearr_23353;
})();
var statearr_23354_23384 = state_23341__$1;
(statearr_23354_23384[(2)] = null);

(statearr_23354_23384[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23342 === (9))){
var inst_23301 = (state_23341[(8)]);
var inst_23317 = cljs.core.vec.call(null,inst_23301);
var state_23341__$1 = state_23341;
return cljs.core.async.impl.ioc_helpers.put_BANG_.call(null,state_23341__$1,(11),out,inst_23317);
} else {
if((state_val_23342 === (5))){
var inst_23302 = (state_23341[(7)]);
var inst_23305 = (state_23341[(9)]);
var inst_23309 = (state_23341[(10)]);
var inst_23309__$1 = f.call(null,inst_23305);
var inst_23310 = cljs.core._EQ_.call(null,inst_23309__$1,inst_23302);
var inst_23311 = cljs.core.keyword_identical_QMARK_.call(null,inst_23302,new cljs.core.Keyword("cljs.core.async","nothing","cljs.core.async/nothing",-69252123));
var inst_23312 = (inst_23310) || (inst_23311);
var state_23341__$1 = (function (){var statearr_23355 = state_23341;
(statearr_23355[(10)] = inst_23309__$1);

return statearr_23355;
})();
if(cljs.core.truth_(inst_23312)){
var statearr_23356_23385 = state_23341__$1;
(statearr_23356_23385[(1)] = (8));

} else {
var statearr_23357_23386 = state_23341__$1;
(statearr_23357_23386[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23342 === (14))){
var inst_23334 = (state_23341[(2)]);
var inst_23335 = cljs.core.async.close_BANG_.call(null,out);
var state_23341__$1 = (function (){var statearr_23359 = state_23341;
(statearr_23359[(13)] = inst_23334);

return statearr_23359;
})();
var statearr_23360_23387 = state_23341__$1;
(statearr_23360_23387[(2)] = inst_23335);

(statearr_23360_23387[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23342 === (10))){
var inst_23324 = (state_23341[(2)]);
var state_23341__$1 = state_23341;
var statearr_23361_23388 = state_23341__$1;
(statearr_23361_23388[(2)] = inst_23324);

(statearr_23361_23388[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_23342 === (8))){
var inst_23305 = (state_23341[(9)]);
var inst_23309 = (state_23341[(10)]);
var inst_23301 = (state_23341[(8)]);
var inst_23314 = inst_23301.push(inst_23305);
var tmp23358 = inst_23301;
var inst_23301__$1 = tmp23358;
var inst_23302 = inst_23309;
var state_23341__$1 = (function (){var statearr_23362 = state_23341;
(statearr_23362[(7)] = inst_23302);

(statearr_23362[(14)] = inst_23314);

(statearr_23362[(8)] = inst_23301__$1);

return statearr_23362;
})();
var statearr_23363_23389 = state_23341__$1;
(statearr_23363_23389[(2)] = null);

(statearr_23363_23389[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto___23375,out))
;
return ((function (switch__20508__auto__,c__20620__auto___23375,out){
return (function() {
var cljs$core$async$state_machine__20509__auto__ = null;
var cljs$core$async$state_machine__20509__auto____0 = (function (){
var statearr_23367 = [null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_23367[(0)] = cljs$core$async$state_machine__20509__auto__);

(statearr_23367[(1)] = (1));

return statearr_23367;
});
var cljs$core$async$state_machine__20509__auto____1 = (function (state_23341){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_23341);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e23368){if((e23368 instanceof Object)){
var ex__20512__auto__ = e23368;
var statearr_23369_23390 = state_23341;
(statearr_23369_23390[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_23341);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e23368;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__23391 = state_23341;
state_23341 = G__23391;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
cljs$core$async$state_machine__20509__auto__ = function(state_23341){
switch(arguments.length){
case 0:
return cljs$core$async$state_machine__20509__auto____0.call(this);
case 1:
return cljs$core$async$state_machine__20509__auto____1.call(this,state_23341);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = cljs$core$async$state_machine__20509__auto____0;
cljs$core$async$state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = cljs$core$async$state_machine__20509__auto____1;
return cljs$core$async$state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___23375,out))
})();
var state__20622__auto__ = (function (){var statearr_23370 = f__20621__auto__.call(null);
(statearr_23370[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___23375);

return statearr_23370;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___23375,out))
);


return out;
});

cljs.core.async.partition_by.cljs$lang$maxFixedArity = 3;

//# sourceMappingURL=async.js.map