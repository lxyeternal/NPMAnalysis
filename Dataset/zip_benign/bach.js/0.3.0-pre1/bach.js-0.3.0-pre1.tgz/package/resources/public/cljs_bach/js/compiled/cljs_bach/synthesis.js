// Compiled by ClojureScript 1.7.228 {}
goog.provide('cljs_bach.synthesis');
goog.require('cljs.core');
/**
 * Construct an audio context in a way that works even if it's prefixed.
 */
cljs_bach.synthesis.audio_context = (function cljs_bach$synthesis$audio_context(){
if(cljs.core.truth_(window.AudioContext)){
return (new window.AudioContext());
} else {
return (new window.webkitAudioContext());
}
});
/**
 * Return the current time as recorded by the audio context.
 */
cljs_bach.synthesis.current_time = (function cljs_bach$synthesis$current_time(context){
return context.currentTime;
});
cljs_bach.synthesis.subgraph = (function cljs_bach$synthesis$subgraph(var_args){
var args19508 = [];
var len__19356__auto___19511 = arguments.length;
var i__19357__auto___19512 = (0);
while(true){
if((i__19357__auto___19512 < len__19356__auto___19511)){
args19508.push((arguments[i__19357__auto___19512]));

var G__19513 = (i__19357__auto___19512 + (1));
i__19357__auto___19512 = G__19513;
continue;
} else {
}
break;
}

var G__19510 = args19508.length;
switch (G__19510) {
case 2:
return cljs_bach.synthesis.subgraph.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
case 1:
return cljs_bach.synthesis.subgraph.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args19508.length)].join('')));

}
});

cljs_bach.synthesis.subgraph.cljs$core$IFn$_invoke$arity$2 = (function (input,output){
return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"input","input",556931961),input,new cljs.core.Keyword(null,"output","output",-1105869043),output], null);
});

cljs_bach.synthesis.subgraph.cljs$core$IFn$_invoke$arity$1 = (function (singleton){
return cljs_bach.synthesis.subgraph.call(null,singleton,singleton);
});

cljs_bach.synthesis.subgraph.cljs$lang$maxFixedArity = 2;
/**
 * A graph of synthesis nodes without an input, so another graph can't connect to it.
 */
cljs_bach.synthesis.source = (function cljs_bach$synthesis$source(node){
return cljs_bach.synthesis.subgraph.call(null,null,node);
});
/**
 * A graph of synthesis nodes without an output, so it can't connect to another graph.
 */
cljs_bach.synthesis.sink = (function cljs_bach$synthesis$sink(node){
return cljs_bach.synthesis.subgraph.call(null,node,null);
});
/**
 * Convert a synth (actually a reader fn) into a concrete subgraph by supplying context and timing.
 */
cljs_bach.synthesis.run_with = (function cljs_bach$synthesis$run_with(synth,context,at,duration){
return synth.call(null,context,at,duration);
});
cljs_bach.synthesis.destination = (function cljs_bach$synthesis$destination(context,at,duration){
return cljs_bach.synthesis.sink.call(null,context.destination);
});
cljs_bach.synthesis.plug = (function cljs_bach$synthesis$plug(param,input,context,at,duration){

if(typeof input === 'number'){
return param.setValueAtTime(input,at);
} else {
return new cljs.core.Keyword(null,"output","output",-1105869043).cljs$core$IFn$_invoke$arity$1(cljs_bach.synthesis.run_with.call(null,input,context,at,duration)).connect(param);
}
});
cljs_bach.synthesis.gain = (function cljs_bach$synthesis$gain(level){
return (function (context,at,duration){
return cljs_bach.synthesis.subgraph.call(null,(function (){var G__19516 = context.createGain();
cljs_bach.synthesis.plug.call(null,G__19516.gain,level,context,at,duration);

return G__19516;
})());
});
});
cljs_bach.synthesis.pass_through = cljs_bach.synthesis.gain.call(null,1.0);
/**
 * Build an envelope out of [segment-duration final-level] coordinates.
 */
cljs_bach.synthesis.envelope = (function cljs_bach$synthesis$envelope(var_args){
var args__19363__auto__ = [];
var len__19356__auto___19520 = arguments.length;
var i__19357__auto___19521 = (0);
while(true){
if((i__19357__auto___19521 < len__19356__auto___19520)){
args__19363__auto__.push((arguments[i__19357__auto___19521]));

var G__19522 = (i__19357__auto___19521 + (1));
i__19357__auto___19521 = G__19522;
continue;
} else {
}
break;
}

var argseq__19364__auto__ = ((((0) < args__19363__auto__.length))?(new cljs.core.IndexedSeq(args__19363__auto__.slice((0)),(0))):null);
return cljs_bach.synthesis.envelope.cljs$core$IFn$_invoke$arity$variadic(argseq__19364__auto__);
});

cljs_bach.synthesis.envelope.cljs$core$IFn$_invoke$arity$variadic = (function (corners){
return (function (context,at,duration){
var audio_node = context.createGain();
audio_node.gain.setValueAtTime((0),at);

cljs.core.reduce.call(null,((function (audio_node){
return (function (x,p__19518){
var vec__19519 = p__19518;
var dx = cljs.core.nth.call(null,vec__19519,(0),null);
var y = cljs.core.nth.call(null,vec__19519,(1),null);
audio_node.gain.linearRampToValueAtTime(y,(x + dx));

return (dx + x);
});})(audio_node))
,at,corners);

return cljs_bach.synthesis.subgraph.call(null,audio_node);
});
});

cljs_bach.synthesis.envelope.cljs$lang$maxFixedArity = (0);

cljs_bach.synthesis.envelope.cljs$lang$applyTo = (function (seq19517){
return cljs_bach.synthesis.envelope.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq19517));
});
cljs_bach.synthesis.adshr = (function cljs_bach$synthesis$adshr(attack,decay,sustain,hold,release){
return cljs_bach.synthesis.envelope.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [attack,1.0], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [decay,sustain], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [hold,sustain], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [release,(0)], null));
});
cljs_bach.synthesis.adsr = (function cljs_bach$synthesis$adsr(attack,decay,sustain,release){
return (function (context,at,duration){
var remainder = (((duration - attack) - decay) - sustain);
var hold = (function (){var x__18629__auto__ = 0.0;
var y__18630__auto__ = remainder;
return ((x__18629__auto__ > y__18630__auto__) ? x__18629__auto__ : y__18630__auto__);
})();
var node = cljs_bach.synthesis.adshr.call(null,attack,decay,sustain,hold,release);
return cljs_bach.synthesis.run_with.call(null,node,context,at,duration);
});
});
cljs_bach.synthesis.percussive = (function cljs_bach$synthesis$percussive(attack,decay){
return cljs_bach.synthesis.envelope.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [attack,1.0], null),new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [decay,0.0], null));
});
/**
 * Apply a function within the (applicative) context of a synth.
 */
cljs_bach.synthesis.fapply = (function cljs_bach$synthesis$fapply(var_args){
var args__19363__auto__ = [];
var len__19356__auto___19526 = arguments.length;
var i__19357__auto___19527 = (0);
while(true){
if((i__19357__auto___19527 < len__19356__auto___19526)){
args__19363__auto__.push((arguments[i__19357__auto___19527]));

var G__19528 = (i__19357__auto___19527 + (1));
i__19357__auto___19527 = G__19528;
continue;
} else {
}
break;
}

var argseq__19364__auto__ = ((((1) < args__19363__auto__.length))?(new cljs.core.IndexedSeq(args__19363__auto__.slice((1)),(0))):null);
return cljs_bach.synthesis.fapply.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),argseq__19364__auto__);
});

cljs_bach.synthesis.fapply.cljs$core$IFn$_invoke$arity$variadic = (function (f,synths){
return (function (context,at,duration){
return cljs.core.apply.call(null,f,cljs.core.map.call(null,(function (p1__19523_SHARP_){
return cljs_bach.synthesis.run_with.call(null,p1__19523_SHARP_,context,at,duration);
}),synths));
});
});

cljs_bach.synthesis.fapply.cljs$lang$maxFixedArity = (1);

cljs_bach.synthesis.fapply.cljs$lang$applyTo = (function (seq19524){
var G__19525 = cljs.core.first.call(null,seq19524);
var seq19524__$1 = cljs.core.next.call(null,seq19524);
return cljs_bach.synthesis.fapply.cljs$core$IFn$_invoke$arity$variadic(G__19525,seq19524__$1);
});
/**
 * Use the output of one synth as the input to another.
 */
cljs_bach.synthesis.connect = (function cljs_bach$synthesis$connect(upstream_synth,downstream_synth){
return cljs_bach.synthesis.fapply.call(null,(function (graph1,graph2){
new cljs.core.Keyword(null,"output","output",-1105869043).cljs$core$IFn$_invoke$arity$1(graph1).connect(new cljs.core.Keyword(null,"input","input",556931961).cljs$core$IFn$_invoke$arity$1(graph2));

return cljs_bach.synthesis.subgraph.call(null,new cljs.core.Keyword(null,"input","input",556931961).cljs$core$IFn$_invoke$arity$1(graph1),new cljs.core.Keyword(null,"output","output",-1105869043).cljs$core$IFn$_invoke$arity$1(graph2));
}),upstream_synth,downstream_synth);
});
/**
 * Connect synths in series.
 */
cljs_bach.synthesis.connect__GT_ = (function cljs_bach$synthesis$connect__GT_(var_args){
var args__19363__auto__ = [];
var len__19356__auto___19530 = arguments.length;
var i__19357__auto___19531 = (0);
while(true){
if((i__19357__auto___19531 < len__19356__auto___19530)){
args__19363__auto__.push((arguments[i__19357__auto___19531]));

var G__19532 = (i__19357__auto___19531 + (1));
i__19357__auto___19531 = G__19532;
continue;
} else {
}
break;
}

var argseq__19364__auto__ = ((((0) < args__19363__auto__.length))?(new cljs.core.IndexedSeq(args__19363__auto__.slice((0)),(0))):null);
return cljs_bach.synthesis.connect__GT_.cljs$core$IFn$_invoke$arity$variadic(argseq__19364__auto__);
});

cljs_bach.synthesis.connect__GT_.cljs$core$IFn$_invoke$arity$variadic = (function (nodes){
return cljs.core.reduce.call(null,cljs_bach.synthesis.connect,nodes);
});

cljs_bach.synthesis.connect__GT_.cljs$lang$maxFixedArity = (0);

cljs_bach.synthesis.connect__GT_.cljs$lang$applyTo = (function (seq19529){
return cljs_bach.synthesis.connect__GT_.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq19529));
});
/**
 * Add together synths by connecting them all to the same upstream and downstream gains.
 */
cljs_bach.synthesis.add = (function cljs_bach$synthesis$add(var_args){
var args__19363__auto__ = [];
var len__19356__auto___19538 = arguments.length;
var i__19357__auto___19539 = (0);
while(true){
if((i__19357__auto___19539 < len__19356__auto___19538)){
args__19363__auto__.push((arguments[i__19357__auto___19539]));

var G__19540 = (i__19357__auto___19539 + (1));
i__19357__auto___19539 = G__19540;
continue;
} else {
}
break;
}

var argseq__19364__auto__ = ((((0) < args__19363__auto__.length))?(new cljs.core.IndexedSeq(args__19363__auto__.slice((0)),(0))):null);
return cljs_bach.synthesis.add.cljs$core$IFn$_invoke$arity$variadic(argseq__19364__auto__);
});

cljs_bach.synthesis.add.cljs$core$IFn$_invoke$arity$variadic = (function (synths){
return (function (context,at,duration){
var upstream = cljs_bach.synthesis.run_with.call(null,cljs_bach.synthesis.pass_through,context,at,duration);
var downstream = cljs_bach.synthesis.run_with.call(null,cljs_bach.synthesis.pass_through,context,at,duration);
var seq__19534_19541 = cljs.core.seq.call(null,synths);
var chunk__19535_19542 = null;
var count__19536_19543 = (0);
var i__19537_19544 = (0);
while(true){
if((i__19537_19544 < count__19536_19543)){
var synth_19545 = cljs.core._nth.call(null,chunk__19535_19542,i__19537_19544);
var graph_19546 = cljs_bach.synthesis.run_with.call(null,synth_19545,context,at,duration);
new cljs.core.Keyword(null,"output","output",-1105869043).cljs$core$IFn$_invoke$arity$1(graph_19546).connect(new cljs.core.Keyword(null,"input","input",556931961).cljs$core$IFn$_invoke$arity$1(downstream));

if(cljs.core.truth_(new cljs.core.Keyword(null,"input","input",556931961).cljs$core$IFn$_invoke$arity$1(graph_19546))){
new cljs.core.Keyword(null,"output","output",-1105869043).cljs$core$IFn$_invoke$arity$1(upstream).connect(new cljs.core.Keyword(null,"input","input",556931961).cljs$core$IFn$_invoke$arity$1(graph_19546));
} else {
}

var G__19547 = seq__19534_19541;
var G__19548 = chunk__19535_19542;
var G__19549 = count__19536_19543;
var G__19550 = (i__19537_19544 + (1));
seq__19534_19541 = G__19547;
chunk__19535_19542 = G__19548;
count__19536_19543 = G__19549;
i__19537_19544 = G__19550;
continue;
} else {
var temp__4425__auto___19551 = cljs.core.seq.call(null,seq__19534_19541);
if(temp__4425__auto___19551){
var seq__19534_19552__$1 = temp__4425__auto___19551;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__19534_19552__$1)){
var c__19101__auto___19553 = cljs.core.chunk_first.call(null,seq__19534_19552__$1);
var G__19554 = cljs.core.chunk_rest.call(null,seq__19534_19552__$1);
var G__19555 = c__19101__auto___19553;
var G__19556 = cljs.core.count.call(null,c__19101__auto___19553);
var G__19557 = (0);
seq__19534_19541 = G__19554;
chunk__19535_19542 = G__19555;
count__19536_19543 = G__19556;
i__19537_19544 = G__19557;
continue;
} else {
var synth_19558 = cljs.core.first.call(null,seq__19534_19552__$1);
var graph_19559 = cljs_bach.synthesis.run_with.call(null,synth_19558,context,at,duration);
new cljs.core.Keyword(null,"output","output",-1105869043).cljs$core$IFn$_invoke$arity$1(graph_19559).connect(new cljs.core.Keyword(null,"input","input",556931961).cljs$core$IFn$_invoke$arity$1(downstream));

if(cljs.core.truth_(new cljs.core.Keyword(null,"input","input",556931961).cljs$core$IFn$_invoke$arity$1(graph_19559))){
new cljs.core.Keyword(null,"output","output",-1105869043).cljs$core$IFn$_invoke$arity$1(upstream).connect(new cljs.core.Keyword(null,"input","input",556931961).cljs$core$IFn$_invoke$arity$1(graph_19559));
} else {
}

var G__19560 = cljs.core.next.call(null,seq__19534_19552__$1);
var G__19561 = null;
var G__19562 = (0);
var G__19563 = (0);
seq__19534_19541 = G__19560;
chunk__19535_19542 = G__19561;
count__19536_19543 = G__19562;
i__19537_19544 = G__19563;
continue;
}
} else {
}
}
break;
}

return cljs_bach.synthesis.subgraph.call(null,new cljs.core.Keyword(null,"input","input",556931961).cljs$core$IFn$_invoke$arity$1(upstream),new cljs.core.Keyword(null,"output","output",-1105869043).cljs$core$IFn$_invoke$arity$1(downstream));
});
});

cljs_bach.synthesis.add.cljs$lang$maxFixedArity = (0);

cljs_bach.synthesis.add.cljs$lang$applyTo = (function (seq19533){
return cljs_bach.synthesis.add.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq19533));
});
cljs_bach.synthesis.buffer = (function cljs_bach$synthesis$buffer(generate_bit_BANG_,context,duration){
var sample_rate = (44100);
var frame_count = (sample_rate * duration);
var buffer__$1 = context.createBuffer((1),frame_count,sample_rate);
var data = buffer__$1.getChannelData((0));
var seq__19568_19572 = cljs.core.seq.call(null,cljs.core.range.call(null,sample_rate));
var chunk__19569_19573 = null;
var count__19570_19574 = (0);
var i__19571_19575 = (0);
while(true){
if((i__19571_19575 < count__19570_19574)){
var i_19576 = cljs.core._nth.call(null,chunk__19569_19573,i__19571_19575);
(data[i_19576] = generate_bit_BANG_.call(null,i_19576));

var G__19577 = seq__19568_19572;
var G__19578 = chunk__19569_19573;
var G__19579 = count__19570_19574;
var G__19580 = (i__19571_19575 + (1));
seq__19568_19572 = G__19577;
chunk__19569_19573 = G__19578;
count__19570_19574 = G__19579;
i__19571_19575 = G__19580;
continue;
} else {
var temp__4425__auto___19581 = cljs.core.seq.call(null,seq__19568_19572);
if(temp__4425__auto___19581){
var seq__19568_19582__$1 = temp__4425__auto___19581;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__19568_19582__$1)){
var c__19101__auto___19583 = cljs.core.chunk_first.call(null,seq__19568_19582__$1);
var G__19584 = cljs.core.chunk_rest.call(null,seq__19568_19582__$1);
var G__19585 = c__19101__auto___19583;
var G__19586 = cljs.core.count.call(null,c__19101__auto___19583);
var G__19587 = (0);
seq__19568_19572 = G__19584;
chunk__19569_19573 = G__19585;
count__19570_19574 = G__19586;
i__19571_19575 = G__19587;
continue;
} else {
var i_19588 = cljs.core.first.call(null,seq__19568_19582__$1);
(data[i_19588] = generate_bit_BANG_.call(null,i_19588));

var G__19589 = cljs.core.next.call(null,seq__19568_19582__$1);
var G__19590 = null;
var G__19591 = (0);
var G__19592 = (0);
seq__19568_19572 = G__19589;
chunk__19569_19573 = G__19590;
count__19570_19574 = G__19591;
i__19571_19575 = G__19592;
continue;
}
} else {
}
}
break;
}

return buffer__$1;
});
/**
 * Make noise according to the supplied strategy for creating bits.
 */
cljs_bach.synthesis.noise = (function cljs_bach$synthesis$noise(generate_bit_BANG_){
return (function (context,at,duration){
return cljs_bach.synthesis.source.call(null,(function (){var G__19594 = context.createBufferSource();
G__19594.buffer = cljs_bach.synthesis.buffer.call(null,generate_bit_BANG_,context,(duration + 1.0));

G__19594.start(at);

return G__19594;
})());
});
});
cljs_bach.synthesis.white_noise = (function (){var white = (function (_){
return ((Math.random() * 2.0) - 1.0);
});
return cljs_bach.synthesis.noise.call(null,white);
})();
/**
 * Make a constant value by creating noise with a fixed value.
 */
cljs_bach.synthesis.constant = (function cljs_bach$synthesis$constant(x){
return cljs_bach.synthesis.noise.call(null,cljs.core.constantly.call(null,x));
});
cljs_bach.synthesis.oscillator = (function cljs_bach$synthesis$oscillator(type,freq){
return (function (context,at,duration){
return cljs_bach.synthesis.source.call(null,(function (){var G__19596 = context.createOscillator();
G__19596.frequency.value = (0);

cljs_bach.synthesis.plug.call(null,G__19596.frequency,freq,context,at,duration);

G__19596.type = type;

G__19596.start(at);

G__19596.stop(((at + duration) + 1.0));

return G__19596;
})());
});
});
cljs_bach.synthesis.sine = cljs.core.partial.call(null,cljs_bach.synthesis.oscillator,"sine");
cljs_bach.synthesis.sawtooth = cljs.core.partial.call(null,cljs_bach.synthesis.oscillator,"sawtooth");
cljs_bach.synthesis.square = cljs.core.partial.call(null,cljs_bach.synthesis.oscillator,"square");
cljs_bach.synthesis.triangle = cljs.core.partial.call(null,cljs_bach.synthesis.oscillator,"triangle");
cljs_bach.synthesis.biquad_filter = (function cljs_bach$synthesis$biquad_filter(var_args){
var args19597 = [];
var len__19356__auto___19602 = arguments.length;
var i__19357__auto___19603 = (0);
while(true){
if((i__19357__auto___19603 < len__19356__auto___19602)){
args19597.push((arguments[i__19357__auto___19603]));

var G__19604 = (i__19357__auto___19603 + (1));
i__19357__auto___19603 = G__19604;
continue;
} else {
}
break;
}

var G__19599 = args19597.length;
switch (G__19599) {
case 3:
return cljs_bach.synthesis.biquad_filter.cljs$core$IFn$_invoke$arity$3((arguments[(0)]),(arguments[(1)]),(arguments[(2)]));

break;
case 2:
return cljs_bach.synthesis.biquad_filter.cljs$core$IFn$_invoke$arity$2((arguments[(0)]),(arguments[(1)]));

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args19597.length)].join('')));

}
});

cljs_bach.synthesis.biquad_filter.cljs$core$IFn$_invoke$arity$3 = (function (type,freq,q){
return (function (context,at,duration){
return cljs_bach.synthesis.subgraph.call(null,(function (){var G__19600 = new cljs.core.Keyword(null,"output","output",-1105869043).cljs$core$IFn$_invoke$arity$1(cljs_bach.synthesis.run_with.call(null,cljs_bach.synthesis.biquad_filter.call(null,type,freq),context,at,duration));
cljs_bach.synthesis.plug.call(null,G__19600.Q,q,context,at,duration);

return G__19600;
})());
});
});

cljs_bach.synthesis.biquad_filter.cljs$core$IFn$_invoke$arity$2 = (function (type,freq){
return (function (context,at,duration){
return cljs_bach.synthesis.subgraph.call(null,(function (){var G__19601 = context.createBiquadFilter();
G__19601.frequency.value = (0);

cljs_bach.synthesis.plug.call(null,G__19601.frequency,freq,context,at,duration);

G__19601.type = type;

return G__19601;
})());
});
});

cljs_bach.synthesis.biquad_filter.cljs$lang$maxFixedArity = 3;
cljs_bach.synthesis.low_pass = cljs.core.partial.call(null,cljs_bach.synthesis.biquad_filter,"lowpass");
cljs_bach.synthesis.high_pass = cljs.core.partial.call(null,cljs_bach.synthesis.biquad_filter,"highpass");
cljs_bach.synthesis.stereo_panner = (function cljs_bach$synthesis$stereo_panner(pan){
return (function (context,at,duration){
return cljs_bach.synthesis.subgraph.call(null,(function (){var G__19607 = context.createStereoPanner();
cljs_bach.synthesis.plug.call(null,G__19607.pan,pan,context,at,duration);

return G__19607;
})());
});
});
cljs_bach.synthesis.delay_line = (function cljs_bach$synthesis$delay_line(time){
return (function (context,at,duration){
return cljs_bach.synthesis.subgraph.call(null,(function (){var maximum = (5);
var G__19609 = context.createDelay(maximum);
cljs_bach.synthesis.plug.call(null,G__19609.delayTime,time,context,at,duration);

return G__19609;
})());
});
});
cljs_bach.synthesis.convolver = (function cljs_bach$synthesis$convolver(generate_bit_BANG_){
return (function (context,at,duration){
return cljs_bach.synthesis.subgraph.call(null,(function (){var G__19611 = context.createConvolver();
G__19611.buffer = cljs_bach.synthesis.buffer.call(null,generate_bit_BANG_,context,(duration + 1.0));

return G__19611;
})());
});
});
cljs_bach.synthesis.reverb = (function (){var duration = (5);
var decay = (3);
var sample_rate = (44100);
var length = (sample_rate * (duration + 1.0));
var logarithmic_decay = ((function (duration,decay,sample_rate,length){
return (function (i){
return (((Math.random(i) * 2.0) - 1.0) * Math.pow(((1) - (i / length)),decay));
});})(duration,decay,sample_rate,length))
;
return cljs_bach.synthesis.convolver.call(null,logarithmic_decay);
})();
/**
 * Mix the original signal with one with the effect applied.
 */
cljs_bach.synthesis.enhance = (function cljs_bach$synthesis$enhance(effect,level){
return cljs_bach.synthesis.add.call(null,cljs_bach.synthesis.pass_through,cljs_bach.synthesis.connect__GT_.call(null,effect,cljs_bach.synthesis.gain.call(null,level)));
});

//# sourceMappingURL=synthesis.js.map