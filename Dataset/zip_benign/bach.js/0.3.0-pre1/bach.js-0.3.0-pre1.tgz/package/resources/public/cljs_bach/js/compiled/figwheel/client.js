// Compiled by ClojureScript 1.7.228 {}
goog.provide('figwheel.client');
goog.require('cljs.core');
goog.require('goog.userAgent.product');
goog.require('goog.Uri');
goog.require('cljs.core.async');
goog.require('figwheel.client.socket');
goog.require('figwheel.client.file_reloading');
goog.require('clojure.string');
goog.require('figwheel.client.utils');
goog.require('cljs.repl');
goog.require('figwheel.client.heads_up');
figwheel.client.figwheel_repl_print = (function figwheel$client$figwheel_repl_print(args){
figwheel.client.socket.send_BANG_.call(null,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"figwheel-event","figwheel-event",519570592),"callback",new cljs.core.Keyword(null,"callback-name","callback-name",336964714),"figwheel-repl-print",new cljs.core.Keyword(null,"content","content",15833224),args], null));

return args;
});
figwheel.client.autoload_QMARK_ = (cljs.core.truth_(figwheel.client.utils.html_env_QMARK_.call(null))?(function (){
var pred__24957 = cljs.core._EQ_;
var expr__24958 = (function (){var or__18298__auto__ = localStorage.getItem("figwheel_autoload");
if(cljs.core.truth_(or__18298__auto__)){
return or__18298__auto__;
} else {
return "true";
}
})();
if(cljs.core.truth_(pred__24957.call(null,"true",expr__24958))){
return true;
} else {
if(cljs.core.truth_(pred__24957.call(null,"false",expr__24958))){
return false;
} else {
throw (new Error([cljs.core.str("No matching clause: "),cljs.core.str(expr__24958)].join('')));
}
}
}):(function (){
return true;
}));
figwheel.client.toggle_autoload = (function figwheel$client$toggle_autoload(){
if(cljs.core.truth_(figwheel.client.utils.html_env_QMARK_.call(null))){
localStorage.setItem("figwheel_autoload",cljs.core.not.call(null,figwheel.client.autoload_QMARK_.call(null)));

return figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"info","info",-317069002),[cljs.core.str("Figwheel autoloading "),cljs.core.str((cljs.core.truth_(figwheel.client.autoload_QMARK_.call(null))?"ON":"OFF"))].join(''));
} else {
return null;
}
});
goog.exportSymbol('figwheel.client.toggle_autoload', figwheel.client.toggle_autoload);
figwheel.client.console_print = (function figwheel$client$console_print(args){
console.log.apply(console,cljs.core.into_array.call(null,args));

return args;
});
figwheel.client.repl_print_fn = (function figwheel$client$repl_print_fn(var_args){
var args__19363__auto__ = [];
var len__19356__auto___24961 = arguments.length;
var i__19357__auto___24962 = (0);
while(true){
if((i__19357__auto___24962 < len__19356__auto___24961)){
args__19363__auto__.push((arguments[i__19357__auto___24962]));

var G__24963 = (i__19357__auto___24962 + (1));
i__19357__auto___24962 = G__24963;
continue;
} else {
}
break;
}

var argseq__19364__auto__ = ((((0) < args__19363__auto__.length))?(new cljs.core.IndexedSeq(args__19363__auto__.slice((0)),(0))):null);
return figwheel.client.repl_print_fn.cljs$core$IFn$_invoke$arity$variadic(argseq__19364__auto__);
});

figwheel.client.repl_print_fn.cljs$core$IFn$_invoke$arity$variadic = (function (args){
figwheel.client.figwheel_repl_print.call(null,figwheel.client.console_print.call(null,args));

return null;
});

figwheel.client.repl_print_fn.cljs$lang$maxFixedArity = (0);

figwheel.client.repl_print_fn.cljs$lang$applyTo = (function (seq24960){
return figwheel.client.repl_print_fn.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq24960));
});
figwheel.client.enable_repl_print_BANG_ = (function figwheel$client$enable_repl_print_BANG_(){
cljs.core._STAR_print_newline_STAR_ = false;

return cljs.core._STAR_print_fn_STAR_ = figwheel.client.repl_print_fn;
});
figwheel.client.get_essential_messages = (function figwheel$client$get_essential_messages(ed){
if(cljs.core.truth_(ed)){
return cljs.core.cons.call(null,cljs.core.select_keys.call(null,ed,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"message","message",-406056002),new cljs.core.Keyword(null,"class","class",-2030961996)], null)),figwheel$client$get_essential_messages.call(null,new cljs.core.Keyword(null,"cause","cause",231901252).cljs$core$IFn$_invoke$arity$1(ed)));
} else {
return null;
}
});
figwheel.client.error_msg_format = (function figwheel$client$error_msg_format(p__24964){
var map__24967 = p__24964;
var map__24967__$1 = ((((!((map__24967 == null)))?((((map__24967.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24967.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24967):map__24967);
var message = cljs.core.get.call(null,map__24967__$1,new cljs.core.Keyword(null,"message","message",-406056002));
var class$ = cljs.core.get.call(null,map__24967__$1,new cljs.core.Keyword(null,"class","class",-2030961996));
return [cljs.core.str(class$),cljs.core.str(" : "),cljs.core.str(message)].join('');
});
figwheel.client.format_messages = cljs.core.comp.call(null,cljs.core.partial.call(null,cljs.core.map,figwheel.client.error_msg_format),figwheel.client.get_essential_messages);
figwheel.client.focus_msgs = (function figwheel$client$focus_msgs(name_set,msg_hist){
return cljs.core.cons.call(null,cljs.core.first.call(null,msg_hist),cljs.core.filter.call(null,cljs.core.comp.call(null,name_set,new cljs.core.Keyword(null,"msg-name","msg-name",-353709863)),cljs.core.rest.call(null,msg_hist)));
});
figwheel.client.reload_file_QMARK__STAR_ = (function figwheel$client$reload_file_QMARK__STAR_(msg_name,opts){
var or__18298__auto__ = new cljs.core.Keyword(null,"load-warninged-code","load-warninged-code",-2030345223).cljs$core$IFn$_invoke$arity$1(opts);
if(cljs.core.truth_(or__18298__auto__)){
return or__18298__auto__;
} else {
return cljs.core.not_EQ_.call(null,msg_name,new cljs.core.Keyword(null,"compile-warning","compile-warning",43425356));
}
});
figwheel.client.reload_file_state_QMARK_ = (function figwheel$client$reload_file_state_QMARK_(msg_names,opts){
var and__18286__auto__ = cljs.core._EQ_.call(null,cljs.core.first.call(null,msg_names),new cljs.core.Keyword(null,"files-changed","files-changed",-1418200563));
if(and__18286__auto__){
return figwheel.client.reload_file_QMARK__STAR_.call(null,cljs.core.second.call(null,msg_names),opts);
} else {
return and__18286__auto__;
}
});
figwheel.client.block_reload_file_state_QMARK_ = (function figwheel$client$block_reload_file_state_QMARK_(msg_names,opts){
return (cljs.core._EQ_.call(null,cljs.core.first.call(null,msg_names),new cljs.core.Keyword(null,"files-changed","files-changed",-1418200563))) && (cljs.core.not.call(null,figwheel.client.reload_file_QMARK__STAR_.call(null,cljs.core.second.call(null,msg_names),opts)));
});
figwheel.client.warning_append_state_QMARK_ = (function figwheel$client$warning_append_state_QMARK_(msg_names){
return cljs.core._EQ_.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"compile-warning","compile-warning",43425356),new cljs.core.Keyword(null,"compile-warning","compile-warning",43425356)], null),cljs.core.take.call(null,(2),msg_names));
});
figwheel.client.warning_state_QMARK_ = (function figwheel$client$warning_state_QMARK_(msg_names){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"compile-warning","compile-warning",43425356),cljs.core.first.call(null,msg_names));
});
figwheel.client.rewarning_state_QMARK_ = (function figwheel$client$rewarning_state_QMARK_(msg_names){
return cljs.core._EQ_.call(null,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"compile-warning","compile-warning",43425356),new cljs.core.Keyword(null,"files-changed","files-changed",-1418200563),new cljs.core.Keyword(null,"compile-warning","compile-warning",43425356)], null),cljs.core.take.call(null,(3),msg_names));
});
figwheel.client.compile_fail_state_QMARK_ = (function figwheel$client$compile_fail_state_QMARK_(msg_names){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"compile-failed","compile-failed",-477639289),cljs.core.first.call(null,msg_names));
});
figwheel.client.compile_refail_state_QMARK_ = (function figwheel$client$compile_refail_state_QMARK_(msg_names){
return cljs.core._EQ_.call(null,new cljs.core.PersistentVector(null, 2, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"compile-failed","compile-failed",-477639289),new cljs.core.Keyword(null,"compile-failed","compile-failed",-477639289)], null),cljs.core.take.call(null,(2),msg_names));
});
figwheel.client.css_loaded_state_QMARK_ = (function figwheel$client$css_loaded_state_QMARK_(msg_names){
return cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"css-files-changed","css-files-changed",720773874),cljs.core.first.call(null,msg_names));
});
figwheel.client.file_reloader_plugin = (function figwheel$client$file_reloader_plugin(opts){
var ch = cljs.core.async.chan.call(null);
var c__20620__auto___25129 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___25129,ch){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___25129,ch){
return (function (state_25098){
var state_val_25099 = (state_25098[(1)]);
if((state_val_25099 === (7))){
var inst_25094 = (state_25098[(2)]);
var state_25098__$1 = state_25098;
var statearr_25100_25130 = state_25098__$1;
(statearr_25100_25130[(2)] = inst_25094);

(statearr_25100_25130[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25099 === (1))){
var state_25098__$1 = state_25098;
var statearr_25101_25131 = state_25098__$1;
(statearr_25101_25131[(2)] = null);

(statearr_25101_25131[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25099 === (4))){
var inst_25051 = (state_25098[(7)]);
var inst_25051__$1 = (state_25098[(2)]);
var state_25098__$1 = (function (){var statearr_25102 = state_25098;
(statearr_25102[(7)] = inst_25051__$1);

return statearr_25102;
})();
if(cljs.core.truth_(inst_25051__$1)){
var statearr_25103_25132 = state_25098__$1;
(statearr_25103_25132[(1)] = (5));

} else {
var statearr_25104_25133 = state_25098__$1;
(statearr_25104_25133[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25099 === (15))){
var inst_25058 = (state_25098[(8)]);
var inst_25073 = new cljs.core.Keyword(null,"files","files",-472457450).cljs$core$IFn$_invoke$arity$1(inst_25058);
var inst_25074 = cljs.core.first.call(null,inst_25073);
var inst_25075 = new cljs.core.Keyword(null,"file","file",-1269645878).cljs$core$IFn$_invoke$arity$1(inst_25074);
var inst_25076 = [cljs.core.str("Figwheel: Not loading code with warnings - "),cljs.core.str(inst_25075)].join('');
var inst_25077 = figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"warn","warn",-436710552),inst_25076);
var state_25098__$1 = state_25098;
var statearr_25105_25134 = state_25098__$1;
(statearr_25105_25134[(2)] = inst_25077);

(statearr_25105_25134[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25099 === (13))){
var inst_25082 = (state_25098[(2)]);
var state_25098__$1 = state_25098;
var statearr_25106_25135 = state_25098__$1;
(statearr_25106_25135[(2)] = inst_25082);

(statearr_25106_25135[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25099 === (6))){
var state_25098__$1 = state_25098;
var statearr_25107_25136 = state_25098__$1;
(statearr_25107_25136[(2)] = null);

(statearr_25107_25136[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25099 === (17))){
var inst_25080 = (state_25098[(2)]);
var state_25098__$1 = state_25098;
var statearr_25108_25137 = state_25098__$1;
(statearr_25108_25137[(2)] = inst_25080);

(statearr_25108_25137[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25099 === (3))){
var inst_25096 = (state_25098[(2)]);
var state_25098__$1 = state_25098;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_25098__$1,inst_25096);
} else {
if((state_val_25099 === (12))){
var inst_25057 = (state_25098[(9)]);
var inst_25071 = figwheel.client.block_reload_file_state_QMARK_.call(null,inst_25057,opts);
var state_25098__$1 = state_25098;
if(cljs.core.truth_(inst_25071)){
var statearr_25109_25138 = state_25098__$1;
(statearr_25109_25138[(1)] = (15));

} else {
var statearr_25110_25139 = state_25098__$1;
(statearr_25110_25139[(1)] = (16));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25099 === (2))){
var state_25098__$1 = state_25098;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_25098__$1,(4),ch);
} else {
if((state_val_25099 === (11))){
var inst_25058 = (state_25098[(8)]);
var inst_25063 = cljs.core.PersistentVector.EMPTY_NODE;
var inst_25064 = figwheel.client.file_reloading.reload_js_files.call(null,opts,inst_25058);
var inst_25065 = cljs.core.async.timeout.call(null,(1000));
var inst_25066 = [inst_25064,inst_25065];
var inst_25067 = (new cljs.core.PersistentVector(null,2,(5),inst_25063,inst_25066,null));
var state_25098__$1 = state_25098;
return cljs.core.async.ioc_alts_BANG_.call(null,state_25098__$1,(14),inst_25067);
} else {
if((state_val_25099 === (9))){
var inst_25058 = (state_25098[(8)]);
var inst_25084 = figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"warn","warn",-436710552),"Figwheel: code autoloading is OFF");
var inst_25085 = new cljs.core.Keyword(null,"files","files",-472457450).cljs$core$IFn$_invoke$arity$1(inst_25058);
var inst_25086 = cljs.core.map.call(null,new cljs.core.Keyword(null,"file","file",-1269645878),inst_25085);
var inst_25087 = [cljs.core.str("Not loading: "),cljs.core.str(inst_25086)].join('');
var inst_25088 = figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"info","info",-317069002),inst_25087);
var state_25098__$1 = (function (){var statearr_25111 = state_25098;
(statearr_25111[(10)] = inst_25084);

return statearr_25111;
})();
var statearr_25112_25140 = state_25098__$1;
(statearr_25112_25140[(2)] = inst_25088);

(statearr_25112_25140[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25099 === (5))){
var inst_25051 = (state_25098[(7)]);
var inst_25053 = [new cljs.core.Keyword(null,"compile-warning","compile-warning",43425356),null,new cljs.core.Keyword(null,"files-changed","files-changed",-1418200563),null];
var inst_25054 = (new cljs.core.PersistentArrayMap(null,2,inst_25053,null));
var inst_25055 = (new cljs.core.PersistentHashSet(null,inst_25054,null));
var inst_25056 = figwheel.client.focus_msgs.call(null,inst_25055,inst_25051);
var inst_25057 = cljs.core.map.call(null,new cljs.core.Keyword(null,"msg-name","msg-name",-353709863),inst_25056);
var inst_25058 = cljs.core.first.call(null,inst_25056);
var inst_25059 = figwheel.client.autoload_QMARK_.call(null);
var state_25098__$1 = (function (){var statearr_25113 = state_25098;
(statearr_25113[(9)] = inst_25057);

(statearr_25113[(8)] = inst_25058);

return statearr_25113;
})();
if(cljs.core.truth_(inst_25059)){
var statearr_25114_25141 = state_25098__$1;
(statearr_25114_25141[(1)] = (8));

} else {
var statearr_25115_25142 = state_25098__$1;
(statearr_25115_25142[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25099 === (14))){
var inst_25069 = (state_25098[(2)]);
var state_25098__$1 = state_25098;
var statearr_25116_25143 = state_25098__$1;
(statearr_25116_25143[(2)] = inst_25069);

(statearr_25116_25143[(1)] = (13));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25099 === (16))){
var state_25098__$1 = state_25098;
var statearr_25117_25144 = state_25098__$1;
(statearr_25117_25144[(2)] = null);

(statearr_25117_25144[(1)] = (17));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25099 === (10))){
var inst_25090 = (state_25098[(2)]);
var state_25098__$1 = (function (){var statearr_25118 = state_25098;
(statearr_25118[(11)] = inst_25090);

return statearr_25118;
})();
var statearr_25119_25145 = state_25098__$1;
(statearr_25119_25145[(2)] = null);

(statearr_25119_25145[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25099 === (8))){
var inst_25057 = (state_25098[(9)]);
var inst_25061 = figwheel.client.reload_file_state_QMARK_.call(null,inst_25057,opts);
var state_25098__$1 = state_25098;
if(cljs.core.truth_(inst_25061)){
var statearr_25120_25146 = state_25098__$1;
(statearr_25120_25146[(1)] = (11));

} else {
var statearr_25121_25147 = state_25098__$1;
(statearr_25121_25147[(1)] = (12));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto___25129,ch))
;
return ((function (switch__20508__auto__,c__20620__auto___25129,ch){
return (function() {
var figwheel$client$file_reloader_plugin_$_state_machine__20509__auto__ = null;
var figwheel$client$file_reloader_plugin_$_state_machine__20509__auto____0 = (function (){
var statearr_25125 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_25125[(0)] = figwheel$client$file_reloader_plugin_$_state_machine__20509__auto__);

(statearr_25125[(1)] = (1));

return statearr_25125;
});
var figwheel$client$file_reloader_plugin_$_state_machine__20509__auto____1 = (function (state_25098){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_25098);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e25126){if((e25126 instanceof Object)){
var ex__20512__auto__ = e25126;
var statearr_25127_25148 = state_25098;
(statearr_25127_25148[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_25098);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e25126;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__25149 = state_25098;
state_25098 = G__25149;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
figwheel$client$file_reloader_plugin_$_state_machine__20509__auto__ = function(state_25098){
switch(arguments.length){
case 0:
return figwheel$client$file_reloader_plugin_$_state_machine__20509__auto____0.call(this);
case 1:
return figwheel$client$file_reloader_plugin_$_state_machine__20509__auto____1.call(this,state_25098);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$file_reloader_plugin_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = figwheel$client$file_reloader_plugin_$_state_machine__20509__auto____0;
figwheel$client$file_reloader_plugin_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = figwheel$client$file_reloader_plugin_$_state_machine__20509__auto____1;
return figwheel$client$file_reloader_plugin_$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___25129,ch))
})();
var state__20622__auto__ = (function (){var statearr_25128 = f__20621__auto__.call(null);
(statearr_25128[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___25129);

return statearr_25128;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___25129,ch))
);


return ((function (ch){
return (function (msg_hist){
cljs.core.async.put_BANG_.call(null,ch,msg_hist);

return msg_hist;
});
;})(ch))
});
figwheel.client.truncate_stack_trace = (function figwheel$client$truncate_stack_trace(stack_str){
return cljs.core.take_while.call(null,(function (p1__25150_SHARP_){
return cljs.core.not.call(null,cljs.core.re_matches.call(null,/.*eval_javascript_STAR__STAR_.*/,p1__25150_SHARP_));
}),clojure.string.split_lines.call(null,stack_str));
});
figwheel.client.get_ua_product = (function figwheel$client$get_ua_product(){
if(cljs.core.truth_(figwheel.client.utils.node_env_QMARK_.call(null))){
return new cljs.core.Keyword(null,"chrome","chrome",1718738387);
} else {
if(cljs.core.truth_(goog.userAgent.product.SAFARI)){
return new cljs.core.Keyword(null,"safari","safari",497115653);
} else {
if(cljs.core.truth_(goog.userAgent.product.CHROME)){
return new cljs.core.Keyword(null,"chrome","chrome",1718738387);
} else {
if(cljs.core.truth_(goog.userAgent.product.FIREFOX)){
return new cljs.core.Keyword(null,"firefox","firefox",1283768880);
} else {
if(cljs.core.truth_(goog.userAgent.product.IE)){
return new cljs.core.Keyword(null,"ie","ie",2038473780);
} else {
return null;
}
}
}
}
}
});
var base_path_25157 = figwheel.client.utils.base_url_path.call(null);
figwheel.client.eval_javascript_STAR__STAR_ = ((function (base_path_25157){
return (function figwheel$client$eval_javascript_STAR__STAR_(code,opts,result_handler){
try{var _STAR_print_fn_STAR_25155 = cljs.core._STAR_print_fn_STAR_;
var _STAR_print_newline_STAR_25156 = cljs.core._STAR_print_newline_STAR_;
cljs.core._STAR_print_fn_STAR_ = figwheel.client.repl_print_fn;

cljs.core._STAR_print_newline_STAR_ = false;

try{return result_handler.call(null,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"status","status",-1997798413),new cljs.core.Keyword(null,"success","success",1890645906),new cljs.core.Keyword(null,"ua-product","ua-product",938384227),figwheel.client.get_ua_product.call(null),new cljs.core.Keyword(null,"value","value",305978217),figwheel.client.utils.eval_helper.call(null,code,opts)], null));
}finally {cljs.core._STAR_print_newline_STAR_ = _STAR_print_newline_STAR_25156;

cljs.core._STAR_print_fn_STAR_ = _STAR_print_fn_STAR_25155;
}}catch (e25154){if((e25154 instanceof Error)){
var e = e25154;
return result_handler.call(null,new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"status","status",-1997798413),new cljs.core.Keyword(null,"exception","exception",-335277064),new cljs.core.Keyword(null,"value","value",305978217),cljs.core.pr_str.call(null,e),new cljs.core.Keyword(null,"ua-product","ua-product",938384227),figwheel.client.get_ua_product.call(null),new cljs.core.Keyword(null,"stacktrace","stacktrace",-95588394),clojure.string.join.call(null,"\n",figwheel.client.truncate_stack_trace.call(null,e.stack)),new cljs.core.Keyword(null,"base-path","base-path",495760020),base_path_25157], null));
} else {
var e = e25154;
return result_handler.call(null,new cljs.core.PersistentArrayMap(null, 4, [new cljs.core.Keyword(null,"status","status",-1997798413),new cljs.core.Keyword(null,"exception","exception",-335277064),new cljs.core.Keyword(null,"ua-product","ua-product",938384227),figwheel.client.get_ua_product.call(null),new cljs.core.Keyword(null,"value","value",305978217),cljs.core.pr_str.call(null,e),new cljs.core.Keyword(null,"stacktrace","stacktrace",-95588394),"No stacktrace available."], null));

}
}});})(base_path_25157))
;
/**
 * The REPL can disconnect and reconnect lets ensure cljs.user exists at least.
 */
figwheel.client.ensure_cljs_user = (function figwheel$client$ensure_cljs_user(){
if(cljs.core.truth_(cljs.user)){
return null;
} else {
return cljs.user = {};
}
});
figwheel.client.repl_plugin = (function figwheel$client$repl_plugin(p__25158){
var map__25165 = p__25158;
var map__25165__$1 = ((((!((map__25165 == null)))?((((map__25165.cljs$lang$protocol_mask$partition0$ & (64))) || (map__25165.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__25165):map__25165);
var opts = map__25165__$1;
var build_id = cljs.core.get.call(null,map__25165__$1,new cljs.core.Keyword(null,"build-id","build-id",1642831089));
return ((function (map__25165,map__25165__$1,opts,build_id){
return (function (p__25167){
var vec__25168 = p__25167;
var map__25169 = cljs.core.nth.call(null,vec__25168,(0),null);
var map__25169__$1 = ((((!((map__25169 == null)))?((((map__25169.cljs$lang$protocol_mask$partition0$ & (64))) || (map__25169.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__25169):map__25169);
var msg = map__25169__$1;
var msg_name = cljs.core.get.call(null,map__25169__$1,new cljs.core.Keyword(null,"msg-name","msg-name",-353709863));
var _ = cljs.core.nthnext.call(null,vec__25168,(1));
if(cljs.core._EQ_.call(null,new cljs.core.Keyword(null,"repl-eval","repl-eval",-1784727398),msg_name)){
figwheel.client.ensure_cljs_user.call(null);

return figwheel.client.eval_javascript_STAR__STAR_.call(null,new cljs.core.Keyword(null,"code","code",1586293142).cljs$core$IFn$_invoke$arity$1(msg),opts,((function (vec__25168,map__25169,map__25169__$1,msg,msg_name,_,map__25165,map__25165__$1,opts,build_id){
return (function (res){
return figwheel.client.socket.send_BANG_.call(null,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"figwheel-event","figwheel-event",519570592),"callback",new cljs.core.Keyword(null,"callback-name","callback-name",336964714),new cljs.core.Keyword(null,"callback-name","callback-name",336964714).cljs$core$IFn$_invoke$arity$1(msg),new cljs.core.Keyword(null,"content","content",15833224),res], null));
});})(vec__25168,map__25169,map__25169__$1,msg,msg_name,_,map__25165,map__25165__$1,opts,build_id))
);
} else {
return null;
}
});
;})(map__25165,map__25165__$1,opts,build_id))
});
figwheel.client.css_reloader_plugin = (function figwheel$client$css_reloader_plugin(opts){
return (function (p__25175){
var vec__25176 = p__25175;
var map__25177 = cljs.core.nth.call(null,vec__25176,(0),null);
var map__25177__$1 = ((((!((map__25177 == null)))?((((map__25177.cljs$lang$protocol_mask$partition0$ & (64))) || (map__25177.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__25177):map__25177);
var msg = map__25177__$1;
var msg_name = cljs.core.get.call(null,map__25177__$1,new cljs.core.Keyword(null,"msg-name","msg-name",-353709863));
var _ = cljs.core.nthnext.call(null,vec__25176,(1));
if(cljs.core._EQ_.call(null,msg_name,new cljs.core.Keyword(null,"css-files-changed","css-files-changed",720773874))){
return figwheel.client.file_reloading.reload_css_files.call(null,opts,msg);
} else {
return null;
}
});
});
figwheel.client.compile_fail_warning_plugin = (function figwheel$client$compile_fail_warning_plugin(p__25179){
var map__25189 = p__25179;
var map__25189__$1 = ((((!((map__25189 == null)))?((((map__25189.cljs$lang$protocol_mask$partition0$ & (64))) || (map__25189.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__25189):map__25189);
var on_compile_warning = cljs.core.get.call(null,map__25189__$1,new cljs.core.Keyword(null,"on-compile-warning","on-compile-warning",-1195585947));
var on_compile_fail = cljs.core.get.call(null,map__25189__$1,new cljs.core.Keyword(null,"on-compile-fail","on-compile-fail",728013036));
return ((function (map__25189,map__25189__$1,on_compile_warning,on_compile_fail){
return (function (p__25191){
var vec__25192 = p__25191;
var map__25193 = cljs.core.nth.call(null,vec__25192,(0),null);
var map__25193__$1 = ((((!((map__25193 == null)))?((((map__25193.cljs$lang$protocol_mask$partition0$ & (64))) || (map__25193.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__25193):map__25193);
var msg = map__25193__$1;
var msg_name = cljs.core.get.call(null,map__25193__$1,new cljs.core.Keyword(null,"msg-name","msg-name",-353709863));
var _ = cljs.core.nthnext.call(null,vec__25192,(1));
var pred__25195 = cljs.core._EQ_;
var expr__25196 = msg_name;
if(cljs.core.truth_(pred__25195.call(null,new cljs.core.Keyword(null,"compile-warning","compile-warning",43425356),expr__25196))){
return on_compile_warning.call(null,msg);
} else {
if(cljs.core.truth_(pred__25195.call(null,new cljs.core.Keyword(null,"compile-failed","compile-failed",-477639289),expr__25196))){
return on_compile_fail.call(null,msg);
} else {
return null;
}
}
});
;})(map__25189,map__25189__$1,on_compile_warning,on_compile_fail))
});
figwheel.client.heads_up_plugin_msg_handler = (function figwheel$client$heads_up_plugin_msg_handler(opts,msg_hist_SINGLEQUOTE_){
var msg_hist = figwheel.client.focus_msgs.call(null,new cljs.core.PersistentHashSet(null, new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"compile-failed","compile-failed",-477639289),null,new cljs.core.Keyword(null,"compile-warning","compile-warning",43425356),null,new cljs.core.Keyword(null,"files-changed","files-changed",-1418200563),null], null), null),msg_hist_SINGLEQUOTE_);
var msg_names = cljs.core.map.call(null,new cljs.core.Keyword(null,"msg-name","msg-name",-353709863),msg_hist);
var msg = cljs.core.first.call(null,msg_hist);
var c__20620__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto__,msg_hist,msg_names,msg){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto__,msg_hist,msg_names,msg){
return (function (state_25412){
var state_val_25413 = (state_25412[(1)]);
if((state_val_25413 === (7))){
var inst_25336 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
if(cljs.core.truth_(inst_25336)){
var statearr_25414_25460 = state_25412__$1;
(statearr_25414_25460[(1)] = (8));

} else {
var statearr_25415_25461 = state_25412__$1;
(statearr_25415_25461[(1)] = (9));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (20))){
var inst_25406 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
var statearr_25416_25462 = state_25412__$1;
(statearr_25416_25462[(2)] = inst_25406);

(statearr_25416_25462[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (27))){
var inst_25402 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
var statearr_25417_25463 = state_25412__$1;
(statearr_25417_25463[(2)] = inst_25402);

(statearr_25417_25463[(1)] = (24));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (1))){
var inst_25329 = figwheel.client.reload_file_state_QMARK_.call(null,msg_names,opts);
var state_25412__$1 = state_25412;
if(cljs.core.truth_(inst_25329)){
var statearr_25418_25464 = state_25412__$1;
(statearr_25418_25464[(1)] = (2));

} else {
var statearr_25419_25465 = state_25412__$1;
(statearr_25419_25465[(1)] = (3));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (24))){
var inst_25404 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
var statearr_25420_25466 = state_25412__$1;
(statearr_25420_25466[(2)] = inst_25404);

(statearr_25420_25466[(1)] = (20));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (4))){
var inst_25410 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_25412__$1,inst_25410);
} else {
if((state_val_25413 === (15))){
var inst_25408 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
var statearr_25421_25467 = state_25412__$1;
(statearr_25421_25467[(2)] = inst_25408);

(statearr_25421_25467[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (21))){
var inst_25367 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
var statearr_25422_25468 = state_25412__$1;
(statearr_25422_25468[(2)] = inst_25367);

(statearr_25422_25468[(1)] = (20));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (31))){
var inst_25391 = figwheel.client.css_loaded_state_QMARK_.call(null,msg_names);
var state_25412__$1 = state_25412;
if(cljs.core.truth_(inst_25391)){
var statearr_25423_25469 = state_25412__$1;
(statearr_25423_25469[(1)] = (34));

} else {
var statearr_25424_25470 = state_25412__$1;
(statearr_25424_25470[(1)] = (35));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (32))){
var inst_25400 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
var statearr_25425_25471 = state_25412__$1;
(statearr_25425_25471[(2)] = inst_25400);

(statearr_25425_25471[(1)] = (27));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (33))){
var inst_25389 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
var statearr_25426_25472 = state_25412__$1;
(statearr_25426_25472[(2)] = inst_25389);

(statearr_25426_25472[(1)] = (32));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (13))){
var inst_25350 = figwheel.client.heads_up.clear.call(null);
var state_25412__$1 = state_25412;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_25412__$1,(16),inst_25350);
} else {
if((state_val_25413 === (22))){
var inst_25371 = new cljs.core.Keyword(null,"message","message",-406056002).cljs$core$IFn$_invoke$arity$1(msg);
var inst_25372 = figwheel.client.heads_up.append_message.call(null,inst_25371);
var state_25412__$1 = state_25412;
var statearr_25427_25473 = state_25412__$1;
(statearr_25427_25473[(2)] = inst_25372);

(statearr_25427_25473[(1)] = (24));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (36))){
var inst_25398 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
var statearr_25428_25474 = state_25412__$1;
(statearr_25428_25474[(2)] = inst_25398);

(statearr_25428_25474[(1)] = (32));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (29))){
var inst_25382 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
var statearr_25429_25475 = state_25412__$1;
(statearr_25429_25475[(2)] = inst_25382);

(statearr_25429_25475[(1)] = (27));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (6))){
var inst_25331 = (state_25412[(7)]);
var state_25412__$1 = state_25412;
var statearr_25430_25476 = state_25412__$1;
(statearr_25430_25476[(2)] = inst_25331);

(statearr_25430_25476[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (28))){
var inst_25378 = (state_25412[(2)]);
var inst_25379 = new cljs.core.Keyword(null,"message","message",-406056002).cljs$core$IFn$_invoke$arity$1(msg);
var inst_25380 = figwheel.client.heads_up.display_warning.call(null,inst_25379);
var state_25412__$1 = (function (){var statearr_25431 = state_25412;
(statearr_25431[(8)] = inst_25378);

return statearr_25431;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_25412__$1,(29),inst_25380);
} else {
if((state_val_25413 === (25))){
var inst_25376 = figwheel.client.heads_up.clear.call(null);
var state_25412__$1 = state_25412;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_25412__$1,(28),inst_25376);
} else {
if((state_val_25413 === (34))){
var inst_25393 = figwheel.client.heads_up.flash_loaded.call(null);
var state_25412__$1 = state_25412;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_25412__$1,(37),inst_25393);
} else {
if((state_val_25413 === (17))){
var inst_25358 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
var statearr_25432_25477 = state_25412__$1;
(statearr_25432_25477[(2)] = inst_25358);

(statearr_25432_25477[(1)] = (15));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (3))){
var inst_25348 = figwheel.client.compile_refail_state_QMARK_.call(null,msg_names);
var state_25412__$1 = state_25412;
if(cljs.core.truth_(inst_25348)){
var statearr_25433_25478 = state_25412__$1;
(statearr_25433_25478[(1)] = (13));

} else {
var statearr_25434_25479 = state_25412__$1;
(statearr_25434_25479[(1)] = (14));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (12))){
var inst_25344 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
var statearr_25435_25480 = state_25412__$1;
(statearr_25435_25480[(2)] = inst_25344);

(statearr_25435_25480[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (2))){
var inst_25331 = (state_25412[(7)]);
var inst_25331__$1 = figwheel.client.autoload_QMARK_.call(null);
var state_25412__$1 = (function (){var statearr_25436 = state_25412;
(statearr_25436[(7)] = inst_25331__$1);

return statearr_25436;
})();
if(cljs.core.truth_(inst_25331__$1)){
var statearr_25437_25481 = state_25412__$1;
(statearr_25437_25481[(1)] = (5));

} else {
var statearr_25438_25482 = state_25412__$1;
(statearr_25438_25482[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (23))){
var inst_25374 = figwheel.client.rewarning_state_QMARK_.call(null,msg_names);
var state_25412__$1 = state_25412;
if(cljs.core.truth_(inst_25374)){
var statearr_25439_25483 = state_25412__$1;
(statearr_25439_25483[(1)] = (25));

} else {
var statearr_25440_25484 = state_25412__$1;
(statearr_25440_25484[(1)] = (26));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (35))){
var state_25412__$1 = state_25412;
var statearr_25441_25485 = state_25412__$1;
(statearr_25441_25485[(2)] = null);

(statearr_25441_25485[(1)] = (36));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (19))){
var inst_25369 = figwheel.client.warning_append_state_QMARK_.call(null,msg_names);
var state_25412__$1 = state_25412;
if(cljs.core.truth_(inst_25369)){
var statearr_25442_25486 = state_25412__$1;
(statearr_25442_25486[(1)] = (22));

} else {
var statearr_25443_25487 = state_25412__$1;
(statearr_25443_25487[(1)] = (23));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (11))){
var inst_25340 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
var statearr_25444_25488 = state_25412__$1;
(statearr_25444_25488[(2)] = inst_25340);

(statearr_25444_25488[(1)] = (10));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (9))){
var inst_25342 = figwheel.client.heads_up.clear.call(null);
var state_25412__$1 = state_25412;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_25412__$1,(12),inst_25342);
} else {
if((state_val_25413 === (5))){
var inst_25333 = new cljs.core.Keyword(null,"autoload","autoload",-354122500).cljs$core$IFn$_invoke$arity$1(opts);
var state_25412__$1 = state_25412;
var statearr_25445_25489 = state_25412__$1;
(statearr_25445_25489[(2)] = inst_25333);

(statearr_25445_25489[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (14))){
var inst_25360 = figwheel.client.compile_fail_state_QMARK_.call(null,msg_names);
var state_25412__$1 = state_25412;
if(cljs.core.truth_(inst_25360)){
var statearr_25446_25490 = state_25412__$1;
(statearr_25446_25490[(1)] = (18));

} else {
var statearr_25447_25491 = state_25412__$1;
(statearr_25447_25491[(1)] = (19));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (26))){
var inst_25384 = figwheel.client.warning_state_QMARK_.call(null,msg_names);
var state_25412__$1 = state_25412;
if(cljs.core.truth_(inst_25384)){
var statearr_25448_25492 = state_25412__$1;
(statearr_25448_25492[(1)] = (30));

} else {
var statearr_25449_25493 = state_25412__$1;
(statearr_25449_25493[(1)] = (31));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (16))){
var inst_25352 = (state_25412[(2)]);
var inst_25353 = new cljs.core.Keyword(null,"exception-data","exception-data",-512474886).cljs$core$IFn$_invoke$arity$1(msg);
var inst_25354 = figwheel.client.format_messages.call(null,inst_25353);
var inst_25355 = new cljs.core.Keyword(null,"cause","cause",231901252).cljs$core$IFn$_invoke$arity$1(msg);
var inst_25356 = figwheel.client.heads_up.display_error.call(null,inst_25354,inst_25355);
var state_25412__$1 = (function (){var statearr_25450 = state_25412;
(statearr_25450[(9)] = inst_25352);

return statearr_25450;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_25412__$1,(17),inst_25356);
} else {
if((state_val_25413 === (30))){
var inst_25386 = new cljs.core.Keyword(null,"message","message",-406056002).cljs$core$IFn$_invoke$arity$1(msg);
var inst_25387 = figwheel.client.heads_up.display_warning.call(null,inst_25386);
var state_25412__$1 = state_25412;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_25412__$1,(33),inst_25387);
} else {
if((state_val_25413 === (10))){
var inst_25346 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
var statearr_25451_25494 = state_25412__$1;
(statearr_25451_25494[(2)] = inst_25346);

(statearr_25451_25494[(1)] = (4));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (18))){
var inst_25362 = new cljs.core.Keyword(null,"exception-data","exception-data",-512474886).cljs$core$IFn$_invoke$arity$1(msg);
var inst_25363 = figwheel.client.format_messages.call(null,inst_25362);
var inst_25364 = new cljs.core.Keyword(null,"cause","cause",231901252).cljs$core$IFn$_invoke$arity$1(msg);
var inst_25365 = figwheel.client.heads_up.display_error.call(null,inst_25363,inst_25364);
var state_25412__$1 = state_25412;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_25412__$1,(21),inst_25365);
} else {
if((state_val_25413 === (37))){
var inst_25395 = (state_25412[(2)]);
var state_25412__$1 = state_25412;
var statearr_25452_25495 = state_25412__$1;
(statearr_25452_25495[(2)] = inst_25395);

(statearr_25452_25495[(1)] = (36));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25413 === (8))){
var inst_25338 = figwheel.client.heads_up.flash_loaded.call(null);
var state_25412__$1 = state_25412;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_25412__$1,(11),inst_25338);
} else {
return null;
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
});})(c__20620__auto__,msg_hist,msg_names,msg))
;
return ((function (switch__20508__auto__,c__20620__auto__,msg_hist,msg_names,msg){
return (function() {
var figwheel$client$heads_up_plugin_msg_handler_$_state_machine__20509__auto__ = null;
var figwheel$client$heads_up_plugin_msg_handler_$_state_machine__20509__auto____0 = (function (){
var statearr_25456 = [null,null,null,null,null,null,null,null,null,null];
(statearr_25456[(0)] = figwheel$client$heads_up_plugin_msg_handler_$_state_machine__20509__auto__);

(statearr_25456[(1)] = (1));

return statearr_25456;
});
var figwheel$client$heads_up_plugin_msg_handler_$_state_machine__20509__auto____1 = (function (state_25412){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_25412);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e25457){if((e25457 instanceof Object)){
var ex__20512__auto__ = e25457;
var statearr_25458_25496 = state_25412;
(statearr_25458_25496[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_25412);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e25457;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__25497 = state_25412;
state_25412 = G__25497;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
figwheel$client$heads_up_plugin_msg_handler_$_state_machine__20509__auto__ = function(state_25412){
switch(arguments.length){
case 0:
return figwheel$client$heads_up_plugin_msg_handler_$_state_machine__20509__auto____0.call(this);
case 1:
return figwheel$client$heads_up_plugin_msg_handler_$_state_machine__20509__auto____1.call(this,state_25412);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$heads_up_plugin_msg_handler_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = figwheel$client$heads_up_plugin_msg_handler_$_state_machine__20509__auto____0;
figwheel$client$heads_up_plugin_msg_handler_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = figwheel$client$heads_up_plugin_msg_handler_$_state_machine__20509__auto____1;
return figwheel$client$heads_up_plugin_msg_handler_$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto__,msg_hist,msg_names,msg))
})();
var state__20622__auto__ = (function (){var statearr_25459 = f__20621__auto__.call(null);
(statearr_25459[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto__);

return statearr_25459;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto__,msg_hist,msg_names,msg))
);

return c__20620__auto__;
});
figwheel.client.heads_up_plugin = (function figwheel$client$heads_up_plugin(opts){
var ch = cljs.core.async.chan.call(null);
figwheel.client.heads_up_config_options_STAR__STAR_ = opts;

var c__20620__auto___25560 = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto___25560,ch){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto___25560,ch){
return (function (state_25543){
var state_val_25544 = (state_25543[(1)]);
if((state_val_25544 === (1))){
var state_25543__$1 = state_25543;
var statearr_25545_25561 = state_25543__$1;
(statearr_25545_25561[(2)] = null);

(statearr_25545_25561[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25544 === (2))){
var state_25543__$1 = state_25543;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_25543__$1,(4),ch);
} else {
if((state_val_25544 === (3))){
var inst_25541 = (state_25543[(2)]);
var state_25543__$1 = state_25543;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_25543__$1,inst_25541);
} else {
if((state_val_25544 === (4))){
var inst_25531 = (state_25543[(7)]);
var inst_25531__$1 = (state_25543[(2)]);
var state_25543__$1 = (function (){var statearr_25546 = state_25543;
(statearr_25546[(7)] = inst_25531__$1);

return statearr_25546;
})();
if(cljs.core.truth_(inst_25531__$1)){
var statearr_25547_25562 = state_25543__$1;
(statearr_25547_25562[(1)] = (5));

} else {
var statearr_25548_25563 = state_25543__$1;
(statearr_25548_25563[(1)] = (6));

}

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25544 === (5))){
var inst_25531 = (state_25543[(7)]);
var inst_25533 = figwheel.client.heads_up_plugin_msg_handler.call(null,opts,inst_25531);
var state_25543__$1 = state_25543;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_25543__$1,(8),inst_25533);
} else {
if((state_val_25544 === (6))){
var state_25543__$1 = state_25543;
var statearr_25549_25564 = state_25543__$1;
(statearr_25549_25564[(2)] = null);

(statearr_25549_25564[(1)] = (7));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25544 === (7))){
var inst_25539 = (state_25543[(2)]);
var state_25543__$1 = state_25543;
var statearr_25550_25565 = state_25543__$1;
(statearr_25550_25565[(2)] = inst_25539);

(statearr_25550_25565[(1)] = (3));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
if((state_val_25544 === (8))){
var inst_25535 = (state_25543[(2)]);
var state_25543__$1 = (function (){var statearr_25551 = state_25543;
(statearr_25551[(8)] = inst_25535);

return statearr_25551;
})();
var statearr_25552_25566 = state_25543__$1;
(statearr_25552_25566[(2)] = null);

(statearr_25552_25566[(1)] = (2));


return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
return null;
}
}
}
}
}
}
}
}
});})(c__20620__auto___25560,ch))
;
return ((function (switch__20508__auto__,c__20620__auto___25560,ch){
return (function() {
var figwheel$client$heads_up_plugin_$_state_machine__20509__auto__ = null;
var figwheel$client$heads_up_plugin_$_state_machine__20509__auto____0 = (function (){
var statearr_25556 = [null,null,null,null,null,null,null,null,null];
(statearr_25556[(0)] = figwheel$client$heads_up_plugin_$_state_machine__20509__auto__);

(statearr_25556[(1)] = (1));

return statearr_25556;
});
var figwheel$client$heads_up_plugin_$_state_machine__20509__auto____1 = (function (state_25543){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_25543);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e25557){if((e25557 instanceof Object)){
var ex__20512__auto__ = e25557;
var statearr_25558_25567 = state_25543;
(statearr_25558_25567[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_25543);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e25557;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__25568 = state_25543;
state_25543 = G__25568;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
figwheel$client$heads_up_plugin_$_state_machine__20509__auto__ = function(state_25543){
switch(arguments.length){
case 0:
return figwheel$client$heads_up_plugin_$_state_machine__20509__auto____0.call(this);
case 1:
return figwheel$client$heads_up_plugin_$_state_machine__20509__auto____1.call(this,state_25543);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$heads_up_plugin_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = figwheel$client$heads_up_plugin_$_state_machine__20509__auto____0;
figwheel$client$heads_up_plugin_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = figwheel$client$heads_up_plugin_$_state_machine__20509__auto____1;
return figwheel$client$heads_up_plugin_$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto___25560,ch))
})();
var state__20622__auto__ = (function (){var statearr_25559 = f__20621__auto__.call(null);
(statearr_25559[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto___25560);

return statearr_25559;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto___25560,ch))
);


figwheel.client.heads_up.ensure_container.call(null);

return ((function (ch){
return (function (msg_hist){
cljs.core.async.put_BANG_.call(null,ch,msg_hist);

return msg_hist;
});
;})(ch))
});
figwheel.client.enforce_project_plugin = (function figwheel$client$enforce_project_plugin(opts){
return (function (msg_hist){
if(((1) < cljs.core.count.call(null,cljs.core.set.call(null,cljs.core.keep.call(null,new cljs.core.Keyword(null,"project-id","project-id",206449307),cljs.core.take.call(null,(5),msg_hist)))))){
figwheel.client.socket.close_BANG_.call(null);

console.error("Figwheel: message received from different project. Shutting socket down.");

if(cljs.core.truth_(new cljs.core.Keyword(null,"heads-up-display","heads-up-display",-896577202).cljs$core$IFn$_invoke$arity$1(opts))){
var c__20620__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto__){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto__){
return (function (state_25589){
var state_val_25590 = (state_25589[(1)]);
if((state_val_25590 === (1))){
var inst_25584 = cljs.core.async.timeout.call(null,(3000));
var state_25589__$1 = state_25589;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_25589__$1,(2),inst_25584);
} else {
if((state_val_25590 === (2))){
var inst_25586 = (state_25589[(2)]);
var inst_25587 = figwheel.client.heads_up.display_system_warning.call(null,"Connection from different project","Shutting connection down!!!!!");
var state_25589__$1 = (function (){var statearr_25591 = state_25589;
(statearr_25591[(7)] = inst_25586);

return statearr_25591;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_25589__$1,inst_25587);
} else {
return null;
}
}
});})(c__20620__auto__))
;
return ((function (switch__20508__auto__,c__20620__auto__){
return (function() {
var figwheel$client$enforce_project_plugin_$_state_machine__20509__auto__ = null;
var figwheel$client$enforce_project_plugin_$_state_machine__20509__auto____0 = (function (){
var statearr_25595 = [null,null,null,null,null,null,null,null];
(statearr_25595[(0)] = figwheel$client$enforce_project_plugin_$_state_machine__20509__auto__);

(statearr_25595[(1)] = (1));

return statearr_25595;
});
var figwheel$client$enforce_project_plugin_$_state_machine__20509__auto____1 = (function (state_25589){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_25589);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e25596){if((e25596 instanceof Object)){
var ex__20512__auto__ = e25596;
var statearr_25597_25599 = state_25589;
(statearr_25597_25599[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_25589);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e25596;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__25600 = state_25589;
state_25589 = G__25600;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
figwheel$client$enforce_project_plugin_$_state_machine__20509__auto__ = function(state_25589){
switch(arguments.length){
case 0:
return figwheel$client$enforce_project_plugin_$_state_machine__20509__auto____0.call(this);
case 1:
return figwheel$client$enforce_project_plugin_$_state_machine__20509__auto____1.call(this,state_25589);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$enforce_project_plugin_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = figwheel$client$enforce_project_plugin_$_state_machine__20509__auto____0;
figwheel$client$enforce_project_plugin_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = figwheel$client$enforce_project_plugin_$_state_machine__20509__auto____1;
return figwheel$client$enforce_project_plugin_$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto__))
})();
var state__20622__auto__ = (function (){var statearr_25598 = f__20621__auto__.call(null);
(statearr_25598[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto__);

return statearr_25598;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto__))
);

return c__20620__auto__;
} else {
return null;
}
} else {
return null;
}
});
});
figwheel.client.default_on_jsload = cljs.core.identity;
figwheel.client.default_on_compile_fail = (function figwheel$client$default_on_compile_fail(p__25601){
var map__25608 = p__25601;
var map__25608__$1 = ((((!((map__25608 == null)))?((((map__25608.cljs$lang$protocol_mask$partition0$ & (64))) || (map__25608.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__25608):map__25608);
var ed = map__25608__$1;
var formatted_exception = cljs.core.get.call(null,map__25608__$1,new cljs.core.Keyword(null,"formatted-exception","formatted-exception",-116489026));
var exception_data = cljs.core.get.call(null,map__25608__$1,new cljs.core.Keyword(null,"exception-data","exception-data",-512474886));
var cause = cljs.core.get.call(null,map__25608__$1,new cljs.core.Keyword(null,"cause","cause",231901252));
figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"debug","debug",-1608172596),"Figwheel: Compile Exception");

var seq__25610_25614 = cljs.core.seq.call(null,figwheel.client.format_messages.call(null,exception_data));
var chunk__25611_25615 = null;
var count__25612_25616 = (0);
var i__25613_25617 = (0);
while(true){
if((i__25613_25617 < count__25612_25616)){
var msg_25618 = cljs.core._nth.call(null,chunk__25611_25615,i__25613_25617);
figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"info","info",-317069002),msg_25618);

var G__25619 = seq__25610_25614;
var G__25620 = chunk__25611_25615;
var G__25621 = count__25612_25616;
var G__25622 = (i__25613_25617 + (1));
seq__25610_25614 = G__25619;
chunk__25611_25615 = G__25620;
count__25612_25616 = G__25621;
i__25613_25617 = G__25622;
continue;
} else {
var temp__4425__auto___25623 = cljs.core.seq.call(null,seq__25610_25614);
if(temp__4425__auto___25623){
var seq__25610_25624__$1 = temp__4425__auto___25623;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__25610_25624__$1)){
var c__19101__auto___25625 = cljs.core.chunk_first.call(null,seq__25610_25624__$1);
var G__25626 = cljs.core.chunk_rest.call(null,seq__25610_25624__$1);
var G__25627 = c__19101__auto___25625;
var G__25628 = cljs.core.count.call(null,c__19101__auto___25625);
var G__25629 = (0);
seq__25610_25614 = G__25626;
chunk__25611_25615 = G__25627;
count__25612_25616 = G__25628;
i__25613_25617 = G__25629;
continue;
} else {
var msg_25630 = cljs.core.first.call(null,seq__25610_25624__$1);
figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"info","info",-317069002),msg_25630);

var G__25631 = cljs.core.next.call(null,seq__25610_25624__$1);
var G__25632 = null;
var G__25633 = (0);
var G__25634 = (0);
seq__25610_25614 = G__25631;
chunk__25611_25615 = G__25632;
count__25612_25616 = G__25633;
i__25613_25617 = G__25634;
continue;
}
} else {
}
}
break;
}

if(cljs.core.truth_(cause)){
figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"info","info",-317069002),[cljs.core.str("Error on file "),cljs.core.str(new cljs.core.Keyword(null,"file","file",-1269645878).cljs$core$IFn$_invoke$arity$1(cause)),cljs.core.str(", line "),cljs.core.str(new cljs.core.Keyword(null,"line","line",212345235).cljs$core$IFn$_invoke$arity$1(cause)),cljs.core.str(", column "),cljs.core.str(new cljs.core.Keyword(null,"column","column",2078222095).cljs$core$IFn$_invoke$arity$1(cause))].join(''));
} else {
}

return ed;
});
figwheel.client.default_on_compile_warning = (function figwheel$client$default_on_compile_warning(p__25635){
var map__25638 = p__25635;
var map__25638__$1 = ((((!((map__25638 == null)))?((((map__25638.cljs$lang$protocol_mask$partition0$ & (64))) || (map__25638.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__25638):map__25638);
var w = map__25638__$1;
var message = cljs.core.get.call(null,map__25638__$1,new cljs.core.Keyword(null,"message","message",-406056002));
figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"warn","warn",-436710552),[cljs.core.str("Figwheel: Compile Warning - "),cljs.core.str(message)].join(''));

return w;
});
figwheel.client.default_before_load = (function figwheel$client$default_before_load(files){
figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"debug","debug",-1608172596),"Figwheel: notified of file changes");

return files;
});
figwheel.client.default_on_cssload = (function figwheel$client$default_on_cssload(files){
figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"debug","debug",-1608172596),"Figwheel: loaded CSS files");

figwheel.client.utils.log.call(null,new cljs.core.Keyword(null,"info","info",-317069002),cljs.core.pr_str.call(null,cljs.core.map.call(null,new cljs.core.Keyword(null,"file","file",-1269645878),files)));

return files;
});
if(typeof figwheel.client.config_defaults !== 'undefined'){
} else {
figwheel.client.config_defaults = cljs.core.PersistentHashMap.fromArrays([new cljs.core.Keyword(null,"on-compile-warning","on-compile-warning",-1195585947),new cljs.core.Keyword(null,"on-jsload","on-jsload",-395756602),new cljs.core.Keyword(null,"reload-dependents","reload-dependents",-956865430),new cljs.core.Keyword(null,"on-compile-fail","on-compile-fail",728013036),new cljs.core.Keyword(null,"debug","debug",-1608172596),new cljs.core.Keyword(null,"heads-up-display","heads-up-display",-896577202),new cljs.core.Keyword(null,"websocket-url","websocket-url",-490444938),new cljs.core.Keyword(null,"before-jsload","before-jsload",-847513128),new cljs.core.Keyword(null,"load-warninged-code","load-warninged-code",-2030345223),new cljs.core.Keyword(null,"eval-fn","eval-fn",-1111644294),new cljs.core.Keyword(null,"retry-count","retry-count",1936122875),new cljs.core.Keyword(null,"autoload","autoload",-354122500),new cljs.core.Keyword(null,"on-cssload","on-cssload",1825432318)],[figwheel.client.default_on_compile_warning,figwheel.client.default_on_jsload,true,figwheel.client.default_on_compile_fail,false,true,[cljs.core.str("ws://"),cljs.core.str((cljs.core.truth_(figwheel.client.utils.html_env_QMARK_.call(null))?location.host:"localhost:3449")),cljs.core.str("/figwheel-ws")].join(''),figwheel.client.default_before_load,false,false,(100),true,figwheel.client.default_on_cssload]);
}
figwheel.client.handle_deprecated_jsload_callback = (function figwheel$client$handle_deprecated_jsload_callback(config){
if(cljs.core.truth_(new cljs.core.Keyword(null,"jsload-callback","jsload-callback",-1949628369).cljs$core$IFn$_invoke$arity$1(config))){
return cljs.core.dissoc.call(null,cljs.core.assoc.call(null,config,new cljs.core.Keyword(null,"on-jsload","on-jsload",-395756602),new cljs.core.Keyword(null,"jsload-callback","jsload-callback",-1949628369).cljs$core$IFn$_invoke$arity$1(config)),new cljs.core.Keyword(null,"jsload-callback","jsload-callback",-1949628369));
} else {
return config;
}
});
figwheel.client.base_plugins = (function figwheel$client$base_plugins(system_options){
var base = new cljs.core.PersistentArrayMap(null, 5, [new cljs.core.Keyword(null,"enforce-project-plugin","enforce-project-plugin",959402899),figwheel.client.enforce_project_plugin,new cljs.core.Keyword(null,"file-reloader-plugin","file-reloader-plugin",-1792964733),figwheel.client.file_reloader_plugin,new cljs.core.Keyword(null,"comp-fail-warning-plugin","comp-fail-warning-plugin",634311),figwheel.client.compile_fail_warning_plugin,new cljs.core.Keyword(null,"css-reloader-plugin","css-reloader-plugin",2002032904),figwheel.client.css_reloader_plugin,new cljs.core.Keyword(null,"repl-plugin","repl-plugin",-1138952371),figwheel.client.repl_plugin], null);
var base__$1 = ((cljs.core.not.call(null,figwheel.client.utils.html_env_QMARK_.call(null)))?cljs.core.select_keys.call(null,base,new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"file-reloader-plugin","file-reloader-plugin",-1792964733),new cljs.core.Keyword(null,"comp-fail-warning-plugin","comp-fail-warning-plugin",634311),new cljs.core.Keyword(null,"repl-plugin","repl-plugin",-1138952371)], null)):base);
var base__$2 = ((new cljs.core.Keyword(null,"autoload","autoload",-354122500).cljs$core$IFn$_invoke$arity$1(system_options) === false)?cljs.core.dissoc.call(null,base__$1,new cljs.core.Keyword(null,"file-reloader-plugin","file-reloader-plugin",-1792964733)):base__$1);
if(cljs.core.truth_((function (){var and__18286__auto__ = new cljs.core.Keyword(null,"heads-up-display","heads-up-display",-896577202).cljs$core$IFn$_invoke$arity$1(system_options);
if(cljs.core.truth_(and__18286__auto__)){
return figwheel.client.utils.html_env_QMARK_.call(null);
} else {
return and__18286__auto__;
}
})())){
return cljs.core.assoc.call(null,base__$2,new cljs.core.Keyword(null,"heads-up-display-plugin","heads-up-display-plugin",1745207501),figwheel.client.heads_up_plugin);
} else {
return base__$2;
}
});
figwheel.client.add_message_watch = (function figwheel$client$add_message_watch(key,callback){
return cljs.core.add_watch.call(null,figwheel.client.socket.message_history_atom,key,(function (_,___$1,___$2,msg_hist){
return callback.call(null,cljs.core.first.call(null,msg_hist));
}));
});
figwheel.client.add_plugins = (function figwheel$client$add_plugins(plugins,system_options){
var seq__25646 = cljs.core.seq.call(null,plugins);
var chunk__25647 = null;
var count__25648 = (0);
var i__25649 = (0);
while(true){
if((i__25649 < count__25648)){
var vec__25650 = cljs.core._nth.call(null,chunk__25647,i__25649);
var k = cljs.core.nth.call(null,vec__25650,(0),null);
var plugin = cljs.core.nth.call(null,vec__25650,(1),null);
if(cljs.core.truth_(plugin)){
var pl_25652 = plugin.call(null,system_options);
cljs.core.add_watch.call(null,figwheel.client.socket.message_history_atom,k,((function (seq__25646,chunk__25647,count__25648,i__25649,pl_25652,vec__25650,k,plugin){
return (function (_,___$1,___$2,msg_hist){
return pl_25652.call(null,msg_hist);
});})(seq__25646,chunk__25647,count__25648,i__25649,pl_25652,vec__25650,k,plugin))
);
} else {
}

var G__25653 = seq__25646;
var G__25654 = chunk__25647;
var G__25655 = count__25648;
var G__25656 = (i__25649 + (1));
seq__25646 = G__25653;
chunk__25647 = G__25654;
count__25648 = G__25655;
i__25649 = G__25656;
continue;
} else {
var temp__4425__auto__ = cljs.core.seq.call(null,seq__25646);
if(temp__4425__auto__){
var seq__25646__$1 = temp__4425__auto__;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__25646__$1)){
var c__19101__auto__ = cljs.core.chunk_first.call(null,seq__25646__$1);
var G__25657 = cljs.core.chunk_rest.call(null,seq__25646__$1);
var G__25658 = c__19101__auto__;
var G__25659 = cljs.core.count.call(null,c__19101__auto__);
var G__25660 = (0);
seq__25646 = G__25657;
chunk__25647 = G__25658;
count__25648 = G__25659;
i__25649 = G__25660;
continue;
} else {
var vec__25651 = cljs.core.first.call(null,seq__25646__$1);
var k = cljs.core.nth.call(null,vec__25651,(0),null);
var plugin = cljs.core.nth.call(null,vec__25651,(1),null);
if(cljs.core.truth_(plugin)){
var pl_25661 = plugin.call(null,system_options);
cljs.core.add_watch.call(null,figwheel.client.socket.message_history_atom,k,((function (seq__25646,chunk__25647,count__25648,i__25649,pl_25661,vec__25651,k,plugin,seq__25646__$1,temp__4425__auto__){
return (function (_,___$1,___$2,msg_hist){
return pl_25661.call(null,msg_hist);
});})(seq__25646,chunk__25647,count__25648,i__25649,pl_25661,vec__25651,k,plugin,seq__25646__$1,temp__4425__auto__))
);
} else {
}

var G__25662 = cljs.core.next.call(null,seq__25646__$1);
var G__25663 = null;
var G__25664 = (0);
var G__25665 = (0);
seq__25646 = G__25662;
chunk__25647 = G__25663;
count__25648 = G__25664;
i__25649 = G__25665;
continue;
}
} else {
return null;
}
}
break;
}
});
figwheel.client.start = (function figwheel$client$start(var_args){
var args25666 = [];
var len__19356__auto___25669 = arguments.length;
var i__19357__auto___25670 = (0);
while(true){
if((i__19357__auto___25670 < len__19356__auto___25669)){
args25666.push((arguments[i__19357__auto___25670]));

var G__25671 = (i__19357__auto___25670 + (1));
i__19357__auto___25670 = G__25671;
continue;
} else {
}
break;
}

var G__25668 = args25666.length;
switch (G__25668) {
case 1:
return figwheel.client.start.cljs$core$IFn$_invoke$arity$1((arguments[(0)]));

break;
case 0:
return figwheel.client.start.cljs$core$IFn$_invoke$arity$0();

break;
default:
throw (new Error([cljs.core.str("Invalid arity: "),cljs.core.str(args25666.length)].join('')));

}
});

figwheel.client.start.cljs$core$IFn$_invoke$arity$1 = (function (opts){
if((goog.dependencies_ == null)){
return null;
} else {
if(typeof figwheel.client.__figwheel_start_once__ !== 'undefined'){
return null;
} else {
figwheel.client.__figwheel_start_once__ = setTimeout((function (){
var plugins_SINGLEQUOTE_ = new cljs.core.Keyword(null,"plugins","plugins",1900073717).cljs$core$IFn$_invoke$arity$1(opts);
var merge_plugins = new cljs.core.Keyword(null,"merge-plugins","merge-plugins",-1193912370).cljs$core$IFn$_invoke$arity$1(opts);
var system_options = figwheel.client.handle_deprecated_jsload_callback.call(null,cljs.core.merge.call(null,figwheel.client.config_defaults,cljs.core.dissoc.call(null,opts,new cljs.core.Keyword(null,"plugins","plugins",1900073717),new cljs.core.Keyword(null,"merge-plugins","merge-plugins",-1193912370))));
var plugins = (cljs.core.truth_(plugins_SINGLEQUOTE_)?plugins_SINGLEQUOTE_:cljs.core.merge.call(null,figwheel.client.base_plugins.call(null,system_options),merge_plugins));
figwheel.client.utils._STAR_print_debug_STAR_ = new cljs.core.Keyword(null,"debug","debug",-1608172596).cljs$core$IFn$_invoke$arity$1(opts);

figwheel.client.add_plugins.call(null,plugins,system_options);

figwheel.client.file_reloading.patch_goog_base.call(null);

return figwheel.client.socket.open.call(null,system_options);
}));
}
}
});

figwheel.client.start.cljs$core$IFn$_invoke$arity$0 = (function (){
return figwheel.client.start.call(null,cljs.core.PersistentArrayMap.EMPTY);
});

figwheel.client.start.cljs$lang$maxFixedArity = 1;
figwheel.client.watch_and_reload_with_opts = figwheel.client.start;
figwheel.client.watch_and_reload = (function figwheel$client$watch_and_reload(var_args){
var args__19363__auto__ = [];
var len__19356__auto___25677 = arguments.length;
var i__19357__auto___25678 = (0);
while(true){
if((i__19357__auto___25678 < len__19356__auto___25677)){
args__19363__auto__.push((arguments[i__19357__auto___25678]));

var G__25679 = (i__19357__auto___25678 + (1));
i__19357__auto___25678 = G__25679;
continue;
} else {
}
break;
}

var argseq__19364__auto__ = ((((0) < args__19363__auto__.length))?(new cljs.core.IndexedSeq(args__19363__auto__.slice((0)),(0))):null);
return figwheel.client.watch_and_reload.cljs$core$IFn$_invoke$arity$variadic(argseq__19364__auto__);
});

figwheel.client.watch_and_reload.cljs$core$IFn$_invoke$arity$variadic = (function (p__25674){
var map__25675 = p__25674;
var map__25675__$1 = ((((!((map__25675 == null)))?((((map__25675.cljs$lang$protocol_mask$partition0$ & (64))) || (map__25675.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__25675):map__25675);
var opts = map__25675__$1;
return figwheel.client.start.call(null,opts);
});

figwheel.client.watch_and_reload.cljs$lang$maxFixedArity = (0);

figwheel.client.watch_and_reload.cljs$lang$applyTo = (function (seq25673){
return figwheel.client.watch_and_reload.cljs$core$IFn$_invoke$arity$variadic(cljs.core.seq.call(null,seq25673));
});

//# sourceMappingURL=client.js.map