// Compiled by ClojureScript 1.7.228 {}
goog.provide('figwheel.client.heads_up');
goog.require('cljs.core');
goog.require('clojure.string');
goog.require('figwheel.client.socket');
goog.require('cljs.core.async');
goog.require('goog.string');

figwheel.client.heads_up.node = (function figwheel$client$heads_up$node(var_args){
var args__19363__auto__ = [];
var len__19356__auto___24723 = arguments.length;
var i__19357__auto___24724 = (0);
while(true){
if((i__19357__auto___24724 < len__19356__auto___24723)){
args__19363__auto__.push((arguments[i__19357__auto___24724]));

var G__24725 = (i__19357__auto___24724 + (1));
i__19357__auto___24724 = G__24725;
continue;
} else {
}
break;
}

var argseq__19364__auto__ = ((((2) < args__19363__auto__.length))?(new cljs.core.IndexedSeq(args__19363__auto__.slice((2)),(0))):null);
return figwheel.client.heads_up.node.cljs$core$IFn$_invoke$arity$variadic((arguments[(0)]),(arguments[(1)]),argseq__19364__auto__);
});

figwheel.client.heads_up.node.cljs$core$IFn$_invoke$arity$variadic = (function (t,attrs,children){
var e = document.createElement(cljs.core.name.call(null,t));
var seq__24715_24726 = cljs.core.seq.call(null,cljs.core.keys.call(null,attrs));
var chunk__24716_24727 = null;
var count__24717_24728 = (0);
var i__24718_24729 = (0);
while(true){
if((i__24718_24729 < count__24717_24728)){
var k_24730 = cljs.core._nth.call(null,chunk__24716_24727,i__24718_24729);
e.setAttribute(cljs.core.name.call(null,k_24730),cljs.core.get.call(null,attrs,k_24730));

var G__24731 = seq__24715_24726;
var G__24732 = chunk__24716_24727;
var G__24733 = count__24717_24728;
var G__24734 = (i__24718_24729 + (1));
seq__24715_24726 = G__24731;
chunk__24716_24727 = G__24732;
count__24717_24728 = G__24733;
i__24718_24729 = G__24734;
continue;
} else {
var temp__4425__auto___24735 = cljs.core.seq.call(null,seq__24715_24726);
if(temp__4425__auto___24735){
var seq__24715_24736__$1 = temp__4425__auto___24735;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__24715_24736__$1)){
var c__19101__auto___24737 = cljs.core.chunk_first.call(null,seq__24715_24736__$1);
var G__24738 = cljs.core.chunk_rest.call(null,seq__24715_24736__$1);
var G__24739 = c__19101__auto___24737;
var G__24740 = cljs.core.count.call(null,c__19101__auto___24737);
var G__24741 = (0);
seq__24715_24726 = G__24738;
chunk__24716_24727 = G__24739;
count__24717_24728 = G__24740;
i__24718_24729 = G__24741;
continue;
} else {
var k_24742 = cljs.core.first.call(null,seq__24715_24736__$1);
e.setAttribute(cljs.core.name.call(null,k_24742),cljs.core.get.call(null,attrs,k_24742));

var G__24743 = cljs.core.next.call(null,seq__24715_24736__$1);
var G__24744 = null;
var G__24745 = (0);
var G__24746 = (0);
seq__24715_24726 = G__24743;
chunk__24716_24727 = G__24744;
count__24717_24728 = G__24745;
i__24718_24729 = G__24746;
continue;
}
} else {
}
}
break;
}

var seq__24719_24747 = cljs.core.seq.call(null,children);
var chunk__24720_24748 = null;
var count__24721_24749 = (0);
var i__24722_24750 = (0);
while(true){
if((i__24722_24750 < count__24721_24749)){
var ch_24751 = cljs.core._nth.call(null,chunk__24720_24748,i__24722_24750);
e.appendChild(ch_24751);

var G__24752 = seq__24719_24747;
var G__24753 = chunk__24720_24748;
var G__24754 = count__24721_24749;
var G__24755 = (i__24722_24750 + (1));
seq__24719_24747 = G__24752;
chunk__24720_24748 = G__24753;
count__24721_24749 = G__24754;
i__24722_24750 = G__24755;
continue;
} else {
var temp__4425__auto___24756 = cljs.core.seq.call(null,seq__24719_24747);
if(temp__4425__auto___24756){
var seq__24719_24757__$1 = temp__4425__auto___24756;
if(cljs.core.chunked_seq_QMARK_.call(null,seq__24719_24757__$1)){
var c__19101__auto___24758 = cljs.core.chunk_first.call(null,seq__24719_24757__$1);
var G__24759 = cljs.core.chunk_rest.call(null,seq__24719_24757__$1);
var G__24760 = c__19101__auto___24758;
var G__24761 = cljs.core.count.call(null,c__19101__auto___24758);
var G__24762 = (0);
seq__24719_24747 = G__24759;
chunk__24720_24748 = G__24760;
count__24721_24749 = G__24761;
i__24722_24750 = G__24762;
continue;
} else {
var ch_24763 = cljs.core.first.call(null,seq__24719_24757__$1);
e.appendChild(ch_24763);

var G__24764 = cljs.core.next.call(null,seq__24719_24757__$1);
var G__24765 = null;
var G__24766 = (0);
var G__24767 = (0);
seq__24719_24747 = G__24764;
chunk__24720_24748 = G__24765;
count__24721_24749 = G__24766;
i__24722_24750 = G__24767;
continue;
}
} else {
}
}
break;
}

return e;
});

figwheel.client.heads_up.node.cljs$lang$maxFixedArity = (2);

figwheel.client.heads_up.node.cljs$lang$applyTo = (function (seq24712){
var G__24713 = cljs.core.first.call(null,seq24712);
var seq24712__$1 = cljs.core.next.call(null,seq24712);
var G__24714 = cljs.core.first.call(null,seq24712__$1);
var seq24712__$2 = cljs.core.next.call(null,seq24712__$1);
return figwheel.client.heads_up.node.cljs$core$IFn$_invoke$arity$variadic(G__24713,G__24714,seq24712__$2);
});
if(typeof figwheel.client.heads_up.heads_up_event_dispatch !== 'undefined'){
} else {
figwheel.client.heads_up.heads_up_event_dispatch = (function (){var method_table__19211__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var prefer_table__19212__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var method_cache__19213__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var cached_hierarchy__19214__auto__ = cljs.core.atom.call(null,cljs.core.PersistentArrayMap.EMPTY);
var hierarchy__19215__auto__ = cljs.core.get.call(null,cljs.core.PersistentArrayMap.EMPTY,new cljs.core.Keyword(null,"hierarchy","hierarchy",-1053470341),cljs.core.get_global_hierarchy.call(null));
return (new cljs.core.MultiFn(cljs.core.symbol.call(null,"figwheel.client.heads-up","heads-up-event-dispatch"),((function (method_table__19211__auto__,prefer_table__19212__auto__,method_cache__19213__auto__,cached_hierarchy__19214__auto__,hierarchy__19215__auto__){
return (function (dataset){
return dataset.figwheelEvent;
});})(method_table__19211__auto__,prefer_table__19212__auto__,method_cache__19213__auto__,cached_hierarchy__19214__auto__,hierarchy__19215__auto__))
,new cljs.core.Keyword(null,"default","default",-1987822328),hierarchy__19215__auto__,method_table__19211__auto__,prefer_table__19212__auto__,method_cache__19213__auto__,cached_hierarchy__19214__auto__));
})();
}
cljs.core._add_method.call(null,figwheel.client.heads_up.heads_up_event_dispatch,new cljs.core.Keyword(null,"default","default",-1987822328),(function (_){
return cljs.core.PersistentArrayMap.EMPTY;
}));
cljs.core._add_method.call(null,figwheel.client.heads_up.heads_up_event_dispatch,"file-selected",(function (dataset){
return figwheel.client.socket.send_BANG_.call(null,new cljs.core.PersistentArrayMap(null, 3, [new cljs.core.Keyword(null,"figwheel-event","figwheel-event",519570592),"file-selected",new cljs.core.Keyword(null,"file-name","file-name",-1654217259),dataset.fileName,new cljs.core.Keyword(null,"file-line","file-line",-1228823138),dataset.fileLine], null));
}));
cljs.core._add_method.call(null,figwheel.client.heads_up.heads_up_event_dispatch,"close-heads-up",(function (dataset){
return figwheel.client.heads_up.clear.call(null);
}));
figwheel.client.heads_up.ancestor_nodes = (function figwheel$client$heads_up$ancestor_nodes(el){
return cljs.core.iterate.call(null,(function (e){
return e.parentNode;
}),el);
});
figwheel.client.heads_up.get_dataset = (function figwheel$client$heads_up$get_dataset(el){
return cljs.core.first.call(null,cljs.core.keep.call(null,(function (x){
if(cljs.core.truth_(x.dataset.figwheelEvent)){
return x.dataset;
} else {
return null;
}
}),cljs.core.take.call(null,(4),figwheel.client.heads_up.ancestor_nodes.call(null,el))));
});
figwheel.client.heads_up.heads_up_onclick_handler = (function figwheel$client$heads_up$heads_up_onclick_handler(event){
var dataset = figwheel.client.heads_up.get_dataset.call(null,event.target);
event.preventDefault();

if(cljs.core.truth_(dataset)){
return figwheel.client.heads_up.heads_up_event_dispatch.call(null,dataset);
} else {
return null;
}
});
figwheel.client.heads_up.ensure_container = (function figwheel$client$heads_up$ensure_container(){
var cont_id = "figwheel-heads-up-container";
var content_id = "figwheel-heads-up-content-area";
if(cljs.core.not.call(null,document.querySelector([cljs.core.str("#"),cljs.core.str(cont_id)].join('')))){
var el_24768 = figwheel.client.heads_up.node.call(null,new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"id","id",-1388402092),cont_id,new cljs.core.Keyword(null,"style","style",-496642736),[cljs.core.str("-webkit-transition: all 0.2s ease-in-out;"),cljs.core.str("-moz-transition: all 0.2s ease-in-out;"),cljs.core.str("-o-transition: all 0.2s ease-in-out;"),cljs.core.str("transition: all 0.2s ease-in-out;"),cljs.core.str("font-size: 13px;"),cljs.core.str("border-top: 1px solid #f5f5f5;"),cljs.core.str("box-shadow: 0px 0px 1px #aaaaaa;"),cljs.core.str("line-height: 18px;"),cljs.core.str("color: #333;"),cljs.core.str("font-family: monospace;"),cljs.core.str("padding: 0px 10px 0px 70px;"),cljs.core.str("position: fixed;"),cljs.core.str("bottom: 0px;"),cljs.core.str("left: 0px;"),cljs.core.str("height: 0px;"),cljs.core.str("opacity: 0.0;"),cljs.core.str("box-sizing: border-box;"),cljs.core.str("z-index: 10000;")].join('')], null));
el_24768.onclick = figwheel.client.heads_up.heads_up_onclick_handler;

el_24768.innerHTML = figwheel.client.heads_up.cljs_logo_svg;

el_24768.appendChild(figwheel.client.heads_up.node.call(null,new cljs.core.Keyword(null,"div","div",1057191632),new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"id","id",-1388402092),content_id], null)));

document.body.appendChild(el_24768);
} else {
}

return new cljs.core.PersistentArrayMap(null, 2, [new cljs.core.Keyword(null,"container-el","container-el",109664205),document.getElementById(cont_id),new cljs.core.Keyword(null,"content-area-el","content-area-el",742757187),document.getElementById(content_id)], null);
});
figwheel.client.heads_up.set_style_BANG_ = (function figwheel$client$heads_up$set_style_BANG_(p__24769,st_map){
var map__24774 = p__24769;
var map__24774__$1 = ((((!((map__24774 == null)))?((((map__24774.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24774.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24774):map__24774);
var container_el = cljs.core.get.call(null,map__24774__$1,new cljs.core.Keyword(null,"container-el","container-el",109664205));
return cljs.core.mapv.call(null,((function (map__24774,map__24774__$1,container_el){
return (function (p__24776){
var vec__24777 = p__24776;
var k = cljs.core.nth.call(null,vec__24777,(0),null);
var v = cljs.core.nth.call(null,vec__24777,(1),null);
return (container_el.style[cljs.core.name.call(null,k)] = v);
});})(map__24774,map__24774__$1,container_el))
,st_map);
});
figwheel.client.heads_up.set_content_BANG_ = (function figwheel$client$heads_up$set_content_BANG_(p__24778,dom_str){
var map__24781 = p__24778;
var map__24781__$1 = ((((!((map__24781 == null)))?((((map__24781.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24781.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24781):map__24781);
var c = map__24781__$1;
var content_area_el = cljs.core.get.call(null,map__24781__$1,new cljs.core.Keyword(null,"content-area-el","content-area-el",742757187));
return content_area_el.innerHTML = dom_str;
});
figwheel.client.heads_up.get_content = (function figwheel$client$heads_up$get_content(p__24783){
var map__24786 = p__24783;
var map__24786__$1 = ((((!((map__24786 == null)))?((((map__24786.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24786.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24786):map__24786);
var content_area_el = cljs.core.get.call(null,map__24786__$1,new cljs.core.Keyword(null,"content-area-el","content-area-el",742757187));
return content_area_el.innerHTML;
});
figwheel.client.heads_up.close_link = (function figwheel$client$heads_up$close_link(){
return [cljs.core.str("<a style=\""),cljs.core.str("float: right;"),cljs.core.str("font-size: 18px;"),cljs.core.str("text-decoration: none;"),cljs.core.str("text-align: right;"),cljs.core.str("width: 30px;"),cljs.core.str("height: 30px;"),cljs.core.str("color: rgba(84,84,84, 0.5);"),cljs.core.str("\" href=\"#\"  data-figwheel-event=\"close-heads-up\">"),cljs.core.str("x"),cljs.core.str("</a>")].join('');
});
figwheel.client.heads_up.display_heads_up = (function figwheel$client$heads_up$display_heads_up(style,msg){
var c__20620__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto__){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto__){
return (function (state_24829){
var state_val_24830 = (state_24829[(1)]);
if((state_val_24830 === (1))){
var inst_24814 = (state_24829[(7)]);
var inst_24814__$1 = figwheel.client.heads_up.ensure_container.call(null);
var inst_24815 = [new cljs.core.Keyword(null,"paddingTop","paddingTop",-1088692345),new cljs.core.Keyword(null,"paddingBottom","paddingBottom",-916694489),new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"minHeight","minHeight",-1635998980),new cljs.core.Keyword(null,"opacity","opacity",397153780)];
var inst_24816 = ["10px","10px","100%","68px","1.0"];
var inst_24817 = cljs.core.PersistentHashMap.fromArrays(inst_24815,inst_24816);
var inst_24818 = cljs.core.merge.call(null,inst_24817,style);
var inst_24819 = figwheel.client.heads_up.set_style_BANG_.call(null,inst_24814__$1,inst_24818);
var inst_24820 = figwheel.client.heads_up.set_content_BANG_.call(null,inst_24814__$1,msg);
var inst_24821 = cljs.core.async.timeout.call(null,(300));
var state_24829__$1 = (function (){var statearr_24831 = state_24829;
(statearr_24831[(7)] = inst_24814__$1);

(statearr_24831[(8)] = inst_24819);

(statearr_24831[(9)] = inst_24820);

return statearr_24831;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_24829__$1,(2),inst_24821);
} else {
if((state_val_24830 === (2))){
var inst_24814 = (state_24829[(7)]);
var inst_24823 = (state_24829[(2)]);
var inst_24824 = [new cljs.core.Keyword(null,"height","height",1025178622)];
var inst_24825 = ["auto"];
var inst_24826 = cljs.core.PersistentHashMap.fromArrays(inst_24824,inst_24825);
var inst_24827 = figwheel.client.heads_up.set_style_BANG_.call(null,inst_24814,inst_24826);
var state_24829__$1 = (function (){var statearr_24832 = state_24829;
(statearr_24832[(10)] = inst_24823);

return statearr_24832;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_24829__$1,inst_24827);
} else {
return null;
}
}
});})(c__20620__auto__))
;
return ((function (switch__20508__auto__,c__20620__auto__){
return (function() {
var figwheel$client$heads_up$display_heads_up_$_state_machine__20509__auto__ = null;
var figwheel$client$heads_up$display_heads_up_$_state_machine__20509__auto____0 = (function (){
var statearr_24836 = [null,null,null,null,null,null,null,null,null,null,null];
(statearr_24836[(0)] = figwheel$client$heads_up$display_heads_up_$_state_machine__20509__auto__);

(statearr_24836[(1)] = (1));

return statearr_24836;
});
var figwheel$client$heads_up$display_heads_up_$_state_machine__20509__auto____1 = (function (state_24829){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_24829);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e24837){if((e24837 instanceof Object)){
var ex__20512__auto__ = e24837;
var statearr_24838_24840 = state_24829;
(statearr_24838_24840[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_24829);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e24837;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__24841 = state_24829;
state_24829 = G__24841;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
figwheel$client$heads_up$display_heads_up_$_state_machine__20509__auto__ = function(state_24829){
switch(arguments.length){
case 0:
return figwheel$client$heads_up$display_heads_up_$_state_machine__20509__auto____0.call(this);
case 1:
return figwheel$client$heads_up$display_heads_up_$_state_machine__20509__auto____1.call(this,state_24829);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$heads_up$display_heads_up_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = figwheel$client$heads_up$display_heads_up_$_state_machine__20509__auto____0;
figwheel$client$heads_up$display_heads_up_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = figwheel$client$heads_up$display_heads_up_$_state_machine__20509__auto____1;
return figwheel$client$heads_up$display_heads_up_$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto__))
})();
var state__20622__auto__ = (function (){var statearr_24839 = f__20621__auto__.call(null);
(statearr_24839[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto__);

return statearr_24839;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto__))
);

return c__20620__auto__;
});
figwheel.client.heads_up.heading = (function figwheel$client$heads_up$heading(s){
return [cljs.core.str("<div style=\""),cljs.core.str("font-size: 26px;"),cljs.core.str("line-height: 26px;"),cljs.core.str("margin-bottom: 2px;"),cljs.core.str("padding-top: 1px;"),cljs.core.str("\">"),cljs.core.str(s),cljs.core.str("</div>")].join('');
});
figwheel.client.heads_up.file_and_line_number = (function figwheel$client$heads_up$file_and_line_number(msg){
if(cljs.core.truth_(cljs.core.re_matches.call(null,/.*at\sline.*/,msg))){
return cljs.core.take.call(null,(2),cljs.core.reverse.call(null,clojure.string.split.call(null,msg," ")));
} else {
return null;
}
});
figwheel.client.heads_up.file_selector_div = (function figwheel$client$heads_up$file_selector_div(file_name,line_number,msg){
return [cljs.core.str("<div data-figwheel-event=\"file-selected\" data-file-name=\""),cljs.core.str(file_name),cljs.core.str("\" data-file-line=\""),cljs.core.str(line_number),cljs.core.str("\">"),cljs.core.str(msg),cljs.core.str("</div>")].join('');
});
figwheel.client.heads_up.format_line = (function figwheel$client$heads_up$format_line(msg){
var msg__$1 = goog.string.htmlEscape(msg);
var temp__4423__auto__ = figwheel.client.heads_up.file_and_line_number.call(null,msg__$1);
if(cljs.core.truth_(temp__4423__auto__)){
var vec__24843 = temp__4423__auto__;
var f = cljs.core.nth.call(null,vec__24843,(0),null);
var ln = cljs.core.nth.call(null,vec__24843,(1),null);
return figwheel.client.heads_up.file_selector_div.call(null,f,ln,msg__$1);
} else {
return [cljs.core.str("<div>"),cljs.core.str(msg__$1),cljs.core.str("</div>")].join('');
}
});
figwheel.client.heads_up.display_error = (function figwheel$client$heads_up$display_error(formatted_messages,cause){
var vec__24846 = (cljs.core.truth_(cause)?new cljs.core.PersistentVector(null, 3, 5, cljs.core.PersistentVector.EMPTY_NODE, [new cljs.core.Keyword(null,"file","file",-1269645878).cljs$core$IFn$_invoke$arity$1(cause),new cljs.core.Keyword(null,"line","line",212345235).cljs$core$IFn$_invoke$arity$1(cause),new cljs.core.Keyword(null,"column","column",2078222095).cljs$core$IFn$_invoke$arity$1(cause)], null):cljs.core.first.call(null,cljs.core.keep.call(null,figwheel.client.heads_up.file_and_line_number,formatted_messages)));
var file_name = cljs.core.nth.call(null,vec__24846,(0),null);
var file_line = cljs.core.nth.call(null,vec__24846,(1),null);
var file_column = cljs.core.nth.call(null,vec__24846,(2),null);
var msg = cljs.core.apply.call(null,cljs.core.str,cljs.core.map.call(null,((function (vec__24846,file_name,file_line,file_column){
return (function (p1__24844_SHARP_){
return [cljs.core.str("<div>"),cljs.core.str(goog.string.htmlEscape(p1__24844_SHARP_)),cljs.core.str("</div>")].join('');
});})(vec__24846,file_name,file_line,file_column))
,formatted_messages));
return figwheel.client.heads_up.display_heads_up.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"backgroundColor","backgroundColor",1738438491),"rgba(255, 161, 161, 0.95)"], null),[cljs.core.str(figwheel.client.heads_up.close_link.call(null)),cljs.core.str(figwheel.client.heads_up.heading.call(null,"Compile Error")),cljs.core.str(figwheel.client.heads_up.file_selector_div.call(null,file_name,(function (){var or__18298__auto__ = file_line;
if(cljs.core.truth_(or__18298__auto__)){
return or__18298__auto__;
} else {
var and__18286__auto__ = cause;
if(cljs.core.truth_(and__18286__auto__)){
return new cljs.core.Keyword(null,"line","line",212345235).cljs$core$IFn$_invoke$arity$1(cause);
} else {
return and__18286__auto__;
}
}
})(),[cljs.core.str(msg),cljs.core.str((cljs.core.truth_(cause)?[cljs.core.str("Error on file "),cljs.core.str(goog.string.htmlEscape(new cljs.core.Keyword(null,"file","file",-1269645878).cljs$core$IFn$_invoke$arity$1(cause))),cljs.core.str(", line "),cljs.core.str(new cljs.core.Keyword(null,"line","line",212345235).cljs$core$IFn$_invoke$arity$1(cause)),cljs.core.str(", column "),cljs.core.str(new cljs.core.Keyword(null,"column","column",2078222095).cljs$core$IFn$_invoke$arity$1(cause))].join(''):""))].join('')))].join(''));
});
figwheel.client.heads_up.display_system_warning = (function figwheel$client$heads_up$display_system_warning(header,msg){
return figwheel.client.heads_up.display_heads_up.call(null,new cljs.core.PersistentArrayMap(null, 1, [new cljs.core.Keyword(null,"backgroundColor","backgroundColor",1738438491),"rgba(255, 220, 110, 0.95)"], null),[cljs.core.str(figwheel.client.heads_up.close_link.call(null)),cljs.core.str(figwheel.client.heads_up.heading.call(null,header)),cljs.core.str(figwheel.client.heads_up.format_line.call(null,msg))].join(''));
});
figwheel.client.heads_up.display_warning = (function figwheel$client$heads_up$display_warning(msg){
return figwheel.client.heads_up.display_system_warning.call(null,"Compile Warning",msg);
});
figwheel.client.heads_up.append_message = (function figwheel$client$heads_up$append_message(message){
var map__24849 = figwheel.client.heads_up.ensure_container.call(null);
var map__24849__$1 = ((((!((map__24849 == null)))?((((map__24849.cljs$lang$protocol_mask$partition0$ & (64))) || (map__24849.cljs$core$ISeq$))?true:false):false))?cljs.core.apply.call(null,cljs.core.hash_map,map__24849):map__24849);
var content_area_el = cljs.core.get.call(null,map__24849__$1,new cljs.core.Keyword(null,"content-area-el","content-area-el",742757187));
var el = document.createElement("div");
el.innerHTML = figwheel.client.heads_up.format_line.call(null,message);

return content_area_el.appendChild(el);
});
figwheel.client.heads_up.clear = (function figwheel$client$heads_up$clear(){
var c__20620__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto__){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto__){
return (function (state_24897){
var state_val_24898 = (state_24897[(1)]);
if((state_val_24898 === (1))){
var inst_24880 = (state_24897[(7)]);
var inst_24880__$1 = figwheel.client.heads_up.ensure_container.call(null);
var inst_24881 = [new cljs.core.Keyword(null,"opacity","opacity",397153780)];
var inst_24882 = ["0.0"];
var inst_24883 = cljs.core.PersistentHashMap.fromArrays(inst_24881,inst_24882);
var inst_24884 = figwheel.client.heads_up.set_style_BANG_.call(null,inst_24880__$1,inst_24883);
var inst_24885 = cljs.core.async.timeout.call(null,(300));
var state_24897__$1 = (function (){var statearr_24899 = state_24897;
(statearr_24899[(7)] = inst_24880__$1);

(statearr_24899[(8)] = inst_24884);

return statearr_24899;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_24897__$1,(2),inst_24885);
} else {
if((state_val_24898 === (2))){
var inst_24880 = (state_24897[(7)]);
var inst_24887 = (state_24897[(2)]);
var inst_24888 = [new cljs.core.Keyword(null,"width","width",-384071477),new cljs.core.Keyword(null,"height","height",1025178622),new cljs.core.Keyword(null,"minHeight","minHeight",-1635998980),new cljs.core.Keyword(null,"padding","padding",1660304693),new cljs.core.Keyword(null,"borderRadius","borderRadius",-1505621083),new cljs.core.Keyword(null,"backgroundColor","backgroundColor",1738438491)];
var inst_24889 = ["auto","0px","0px","0px 10px 0px 70px","0px","transparent"];
var inst_24890 = cljs.core.PersistentHashMap.fromArrays(inst_24888,inst_24889);
var inst_24891 = figwheel.client.heads_up.set_style_BANG_.call(null,inst_24880,inst_24890);
var inst_24892 = cljs.core.async.timeout.call(null,(200));
var state_24897__$1 = (function (){var statearr_24900 = state_24897;
(statearr_24900[(9)] = inst_24887);

(statearr_24900[(10)] = inst_24891);

return statearr_24900;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_24897__$1,(3),inst_24892);
} else {
if((state_val_24898 === (3))){
var inst_24880 = (state_24897[(7)]);
var inst_24894 = (state_24897[(2)]);
var inst_24895 = figwheel.client.heads_up.set_content_BANG_.call(null,inst_24880,"");
var state_24897__$1 = (function (){var statearr_24901 = state_24897;
(statearr_24901[(11)] = inst_24894);

return statearr_24901;
})();
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_24897__$1,inst_24895);
} else {
return null;
}
}
}
});})(c__20620__auto__))
;
return ((function (switch__20508__auto__,c__20620__auto__){
return (function() {
var figwheel$client$heads_up$clear_$_state_machine__20509__auto__ = null;
var figwheel$client$heads_up$clear_$_state_machine__20509__auto____0 = (function (){
var statearr_24905 = [null,null,null,null,null,null,null,null,null,null,null,null];
(statearr_24905[(0)] = figwheel$client$heads_up$clear_$_state_machine__20509__auto__);

(statearr_24905[(1)] = (1));

return statearr_24905;
});
var figwheel$client$heads_up$clear_$_state_machine__20509__auto____1 = (function (state_24897){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_24897);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e24906){if((e24906 instanceof Object)){
var ex__20512__auto__ = e24906;
var statearr_24907_24909 = state_24897;
(statearr_24907_24909[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_24897);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e24906;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__24910 = state_24897;
state_24897 = G__24910;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
figwheel$client$heads_up$clear_$_state_machine__20509__auto__ = function(state_24897){
switch(arguments.length){
case 0:
return figwheel$client$heads_up$clear_$_state_machine__20509__auto____0.call(this);
case 1:
return figwheel$client$heads_up$clear_$_state_machine__20509__auto____1.call(this,state_24897);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$heads_up$clear_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = figwheel$client$heads_up$clear_$_state_machine__20509__auto____0;
figwheel$client$heads_up$clear_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = figwheel$client$heads_up$clear_$_state_machine__20509__auto____1;
return figwheel$client$heads_up$clear_$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto__))
})();
var state__20622__auto__ = (function (){var statearr_24908 = f__20621__auto__.call(null);
(statearr_24908[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto__);

return statearr_24908;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto__))
);

return c__20620__auto__;
});
figwheel.client.heads_up.display_loaded_start = (function figwheel$client$heads_up$display_loaded_start(){
return figwheel.client.heads_up.display_heads_up.call(null,new cljs.core.PersistentArrayMap(null, 6, [new cljs.core.Keyword(null,"backgroundColor","backgroundColor",1738438491),"rgba(211,234,172,1.0)",new cljs.core.Keyword(null,"width","width",-384071477),"68px",new cljs.core.Keyword(null,"height","height",1025178622),"68px",new cljs.core.Keyword(null,"paddingLeft","paddingLeft",262720813),"0px",new cljs.core.Keyword(null,"paddingRight","paddingRight",-1642313463),"0px",new cljs.core.Keyword(null,"borderRadius","borderRadius",-1505621083),"35px"], null),"");
});
figwheel.client.heads_up.flash_loaded = (function figwheel$client$heads_up$flash_loaded(){
var c__20620__auto__ = cljs.core.async.chan.call(null,(1));
cljs.core.async.impl.dispatch.run.call(null,((function (c__20620__auto__){
return (function (){
var f__20621__auto__ = (function (){var switch__20508__auto__ = ((function (c__20620__auto__){
return (function (state_24942){
var state_val_24943 = (state_24942[(1)]);
if((state_val_24943 === (1))){
var inst_24932 = figwheel.client.heads_up.display_loaded_start.call(null);
var state_24942__$1 = state_24942;
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_24942__$1,(2),inst_24932);
} else {
if((state_val_24943 === (2))){
var inst_24934 = (state_24942[(2)]);
var inst_24935 = cljs.core.async.timeout.call(null,(400));
var state_24942__$1 = (function (){var statearr_24944 = state_24942;
(statearr_24944[(7)] = inst_24934);

return statearr_24944;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_24942__$1,(3),inst_24935);
} else {
if((state_val_24943 === (3))){
var inst_24937 = (state_24942[(2)]);
var inst_24938 = figwheel.client.heads_up.clear.call(null);
var state_24942__$1 = (function (){var statearr_24945 = state_24942;
(statearr_24945[(8)] = inst_24937);

return statearr_24945;
})();
return cljs.core.async.impl.ioc_helpers.take_BANG_.call(null,state_24942__$1,(4),inst_24938);
} else {
if((state_val_24943 === (4))){
var inst_24940 = (state_24942[(2)]);
var state_24942__$1 = state_24942;
return cljs.core.async.impl.ioc_helpers.return_chan.call(null,state_24942__$1,inst_24940);
} else {
return null;
}
}
}
}
});})(c__20620__auto__))
;
return ((function (switch__20508__auto__,c__20620__auto__){
return (function() {
var figwheel$client$heads_up$flash_loaded_$_state_machine__20509__auto__ = null;
var figwheel$client$heads_up$flash_loaded_$_state_machine__20509__auto____0 = (function (){
var statearr_24949 = [null,null,null,null,null,null,null,null,null];
(statearr_24949[(0)] = figwheel$client$heads_up$flash_loaded_$_state_machine__20509__auto__);

(statearr_24949[(1)] = (1));

return statearr_24949;
});
var figwheel$client$heads_up$flash_loaded_$_state_machine__20509__auto____1 = (function (state_24942){
while(true){
var ret_value__20510__auto__ = (function (){try{while(true){
var result__20511__auto__ = switch__20508__auto__.call(null,state_24942);
if(cljs.core.keyword_identical_QMARK_.call(null,result__20511__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
continue;
} else {
return result__20511__auto__;
}
break;
}
}catch (e24950){if((e24950 instanceof Object)){
var ex__20512__auto__ = e24950;
var statearr_24951_24953 = state_24942;
(statearr_24951_24953[(5)] = ex__20512__auto__);


cljs.core.async.impl.ioc_helpers.process_exception.call(null,state_24942);

return new cljs.core.Keyword(null,"recur","recur",-437573268);
} else {
throw e24950;

}
}})();
if(cljs.core.keyword_identical_QMARK_.call(null,ret_value__20510__auto__,new cljs.core.Keyword(null,"recur","recur",-437573268))){
var G__24954 = state_24942;
state_24942 = G__24954;
continue;
} else {
return ret_value__20510__auto__;
}
break;
}
});
figwheel$client$heads_up$flash_loaded_$_state_machine__20509__auto__ = function(state_24942){
switch(arguments.length){
case 0:
return figwheel$client$heads_up$flash_loaded_$_state_machine__20509__auto____0.call(this);
case 1:
return figwheel$client$heads_up$flash_loaded_$_state_machine__20509__auto____1.call(this,state_24942);
}
throw(new Error('Invalid arity: ' + arguments.length));
};
figwheel$client$heads_up$flash_loaded_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$0 = figwheel$client$heads_up$flash_loaded_$_state_machine__20509__auto____0;
figwheel$client$heads_up$flash_loaded_$_state_machine__20509__auto__.cljs$core$IFn$_invoke$arity$1 = figwheel$client$heads_up$flash_loaded_$_state_machine__20509__auto____1;
return figwheel$client$heads_up$flash_loaded_$_state_machine__20509__auto__;
})()
;})(switch__20508__auto__,c__20620__auto__))
})();
var state__20622__auto__ = (function (){var statearr_24952 = f__20621__auto__.call(null);
(statearr_24952[cljs.core.async.impl.ioc_helpers.USER_START_IDX] = c__20620__auto__);

return statearr_24952;
})();
return cljs.core.async.impl.ioc_helpers.run_state_machine_wrapped.call(null,state__20622__auto__);
});})(c__20620__auto__))
);

return c__20620__auto__;
});
figwheel.client.heads_up.cljs_logo_svg = "<?xml version='1.0' encoding='utf-8'?>\n<!DOCTYPE svg PUBLIC '-//W3C//DTD SVG 1.1//EN' 'http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd'>\n<svg width='49px' height='49px' style='position:absolute; top:9px; left: 10px;' version='1.1'\n  xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px'\n  viewBox='0 0 428 428' enable-background='new 0 0 428 428' xml:space='preserve'>\n<circle fill='#fff' cx='213' cy='214' r='213' />\n<g>\n<path fill='#96CA4B' d='M122,266.6c-12.7,0-22.3-3.7-28.9-11.1c-6.6-7.4-9.9-18-9.9-31.8c0-14.1,3.4-24.9,10.3-32.5\n  s16.8-11.4,29.9-11.4c8.8,0,16.8,1.6,23.8,4.9l-5.4,14.3c-7.5-2.9-13.7-4.4-18.6-4.4c-14.5,0-21.7,9.6-21.7,28.8\n  c0,9.4,1.8,16.4,5.4,21.2c3.6,4.7,8.9,7.1,15.9,7.1c7.9,0,15.4-2,22.5-5.9v15.5c-3.2,1.9-6.6,3.2-10.2,4\n  C131.5,266.2,127.1,266.6,122,266.6z'/>\n<path fill='#96CA4B' d='M194.4,265.1h-17.8V147.3h17.8V265.1z'/>\n<path fill='#5F7FBF' d='M222.9,302.3c-5.3,0-9.8-0.6-13.3-1.9v-14.1c3.4,0.9,6.9,1.4,10.5,1.4c7.6,0,11.4-4.3,11.4-12.9v-93.5h17.8\n  v94.7c0,8.6-2.3,15.2-6.8,19.6C237.9,300.1,231.4,302.3,222.9,302.3z M230.4,159.2c0-3.2,0.9-5.6,2.6-7.3c1.7-1.7,4.2-2.6,7.5-2.6\n  c3.1,0,5.6,0.9,7.3,2.6c1.7,1.7,2.6,4.2,2.6,7.3c0,3-0.9,5.4-2.6,7.2c-1.7,1.7-4.2,2.6-7.3,2.6c-3.2,0-5.7-0.9-7.5-2.6\n  C231.2,164.6,230.4,162.2,230.4,159.2z'/>\n<path fill='#5F7FBF' d='M342.5,241.3c0,8.2-3,14.4-8.9,18.8c-6,4.4-14.5,6.5-25.6,6.5c-11.2,0-20.1-1.7-26.9-5.1v-15.4\n  c9.8,4.5,19,6.8,27.5,6.8c10.9,0,16.4-3.3,16.4-9.9c0-2.1-0.6-3.9-1.8-5.3c-1.2-1.4-3.2-2.9-6-4.4c-2.8-1.5-6.6-3.2-11.6-5.1\n  c-9.6-3.7-16.2-7.5-19.6-11.2c-3.4-3.7-5.1-8.6-5.1-14.5c0-7.2,2.9-12.7,8.7-16.7c5.8-4,13.6-5.9,23.6-5.9c9.8,0,19.1,2,27.9,6\n  l-5.8,13.4c-9-3.7-16.6-5.6-22.8-5.6c-9.4,0-14.1,2.7-14.1,8c0,2.6,1.2,4.8,3.7,6.7c2.4,1.8,7.8,4.3,16,7.5\n  c6.9,2.7,11.9,5.1,15.1,7.3c3.1,2.2,5.4,4.8,7,7.7C341.7,233.7,342.5,237.2,342.5,241.3z'/>\n</g>\n<path fill='#96CA4B' stroke='#96CA4B' stroke-width='6' stroke-miterlimit='10' d='M197,392.7c-91.2-8.1-163-85-163-178.3\n  S105.8,44.3,197,36.2V16.1c-102.3,8.2-183,94-183,198.4s80.7,190.2,183,198.4V392.7z'/>\n<path fill='#5F7FBF' stroke='#5F7FBF' stroke-width='6' stroke-miterlimit='10' d='M229,16.1v20.1c91.2,8.1,163,85,163,178.3\n  s-71.8,170.2-163,178.3v20.1c102.3-8.2,183-94,183-198.4S331.3,24.3,229,16.1z'/>\n</svg>";

//# sourceMappingURL=heads_up.js.map