import * as React from 'react';
import PropTypes from 'prop-types';
import type hljs from 'highlight.js';
interface Props {
    children: string;
    className?: string;
    highlightjs: typeof hljs;
    languages?: Array<string>;
    worker?: Worker;
}
interface State {
    highlightedCode?: string;
    language?: string;
}
export default class BareHighlight extends React.PureComponent<Props, State> {
    static defaultProps: {
        className: string;
        languages: never[];
        worker: null;
    };
    static propTypes: {
        children: PropTypes.Validator<string>;
        className: PropTypes.Requireable<string>;
        highlightjs: PropTypes.Validator<object>;
        languages: PropTypes.Requireable<(string | null | undefined)[]>;
        worker: PropTypes.Requireable<object>;
    };
    state: State;
    componentDidMount(): void;
    componentDidUpdate(prevProps: Props): void;
    getInitialCode(): string | (string & {}) | (string & React.ReactElement<any, string | ((props: any) => React.ReactElement<any, string | any | (new (props: any) => React.Component<any, any, any>)> | null) | (new (props: any) => React.Component<any, any, any>)>) | (string & React.ReactNodeArray) | (string & React.ReactPortal);
    getHighlightPromise(): Promise<ReturnType<typeof hljs.highlight>>;
    highlightCode(): void;
    render(): JSX.Element;
}
export {};
