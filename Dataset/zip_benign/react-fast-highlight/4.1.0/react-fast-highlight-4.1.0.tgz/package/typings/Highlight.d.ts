/// <reference types="react" />
import PropTypes from 'prop-types';
interface Props {
    children: string;
    className?: string;
    languages?: Array<string>;
    worker?: Worker;
}
declare const Highlight: {
    (props: Props): JSX.Element;
    defaultProps: {
        className: string;
        languages: never[];
        worker: null;
    };
    propTypes: {
        children: PropTypes.Validator<string>;
        className: PropTypes.Requireable<string>;
        languages: PropTypes.Requireable<(string | null | undefined)[]>;
        worker: PropTypes.Requireable<object>;
    };
};
export default Highlight;
