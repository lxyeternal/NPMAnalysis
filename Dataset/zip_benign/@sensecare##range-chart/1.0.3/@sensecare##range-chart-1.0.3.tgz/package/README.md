# 离散图

```js
/**
 * 名称：离散图
 * @param {*} id 当前选中容器
 * @param {*} seriesData 当前数据
 * @param {*} chartMap 当前图表实例组合
 **/

 import { initRangeCharts } from 'xxx'

    // mock数据
  let seriesData = [
    [5.2, 1.6],
    [7.5, 0.5],
    [1.5, 4.2],
    [7.0, 3.0],
    [5.8, 3.6],
    [1.0, 6.0],
    [1.1, 4.6],
    [6.0, 2.8],
    [6.2, 1.8],
    [2.2, 0.2]
  ]
  // 生成离散图实例
  initRangeCharts({
    seriesData,
    id: 'rangeChart',
    chartMap
  })
```
