import { type ConfigureOptions, LogLevel } from './types';
declare class TurboLoggerStatic {
    private logToFile;
    configure(options?: ConfigureOptions): Promise<void>;
    deleteLogs(): Promise<boolean>;
    getLogPaths(): Promise<string[]>;
    setLogToFile(enabled: boolean): void;
    debug(...args: any): void;
    info(...args: any): void;
    warn(...args: any): void;
    error(...args: any): void;
    log(level: LogLevel, ...args: any): void;
}
declare const turboLogger: TurboLoggerStatic;
export default turboLogger;
//# sourceMappingURL=logger.d.ts.map