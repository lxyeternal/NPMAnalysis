import TurboLogger from './logger';
export * from './types';
export default TurboLogger;
//# sourceMappingURL=index.d.ts.map