import type { ConfigureOptions } from './types';
export declare function configure(options?: ConfigureOptions): Promise<void>;
export declare function deleteLogFiles(): Promise<boolean>;
export declare function getLogFilePaths(): Promise<string[]>;
export declare function write(logLevel: number, message: Array<any>): void;
//# sourceMappingURL=native.d.ts.map