import { Camera } from "@galacean/engine";
export declare function screenshotSchema(schema: string, width: number, height: number, isPNG?: boolean, jpgQuality?: number, download?: boolean): Promise<Blob>;
export declare function screenshotCurrentCamera(camera: Camera, width: number, height: number, isPNG?: boolean, jpgQuality?: number, flipY?: boolean, download?: boolean): Promise<unknown>;
