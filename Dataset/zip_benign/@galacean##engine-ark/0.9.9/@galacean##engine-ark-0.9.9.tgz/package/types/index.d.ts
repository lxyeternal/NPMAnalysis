export { ArkComponent, Mouth } from "./ArkComponent";
export { screenshotSchema, screenshotCurrentCamera } from "./screenshot";
export declare const version = "__buildVersion";
