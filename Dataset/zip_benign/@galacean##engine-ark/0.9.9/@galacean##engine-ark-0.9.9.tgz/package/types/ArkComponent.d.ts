import { Animator, AnimatorLayerBlendingMode, AnimatorState, Component, WrapMode } from "@galacean/engine";
export declare enum Mouth {
    A = "a",
    E = "e",
    I = "i",
    O = "o",
    U = "u"
}
interface IAnimatorStateInfo {
    layerIndex: number;
    state: AnimatorState;
}
export declare class ArkComponent extends Component {
    private static _defaultName;
    private _setModelPromise;
    private _setAnimationPromise;
    private _setHairPromise;
    private _setEyePromise;
    private _setEyebrowPromise;
    private _setClothPromise;
    private _modelUrl;
    private _hairUrl;
    private _eyeUrl;
    private _eyebrowUrl;
    private _clothUrl;
    private _hairEntity;
    private _eyeEntity;
    private _eyebrowEntity;
    private _faceMaterial;
    private _bodyMaterial;
    private _clothEntity;
    private _originalFaceTexture;
    private _animationIndex;
    private _bsRenderers;
    private _animationInfo;
    private _mouthInfo;
    /**
     * ------------- begin: editor config -------------
     */
    get eyeUrl(): string;
    set eyeUrl(url: string);
    get eyebrowUrl(): string;
    set eyebrowUrl(url: string);
    get hairUrl(): string;
    set hairUrl(url: string);
    get clothUrl(): string;
    set clothUrl(url: string);
    get modelUrl(): string;
    set modelUrl(url: string);
    /**
     * ------------- end: editor config -------------
     */
    /**
     * The controller of the animation system.
     */
    get animator(): Animator;
    /**
     * All animation name list in current 3D model.
     */
    get animationNameList(): string[];
    /**
     * A hook to call back when loading is complete
     */
    get onReady(): Promise<void[]>;
    /**
     * Replace 3D Model by glTF url.
     * @param url - The url of 3D glTF file.
     */
    replaceModel(url: string): Promise<void>;
    /**
     * Replace hair by glTF url.
     * @param url - The url of glTF file.
     */
    replaceHair(url: string): Promise<void>;
    /**
     * Replace eye by glTF url.
     * @param url - The url of glTF file.
     */
    replaceEye(url: string): Promise<void>;
    /**
     * Replace eyebrow by glTF url.
     * @param url - The url of glTF file.
     */
    replaceEyebrow(url: string): Promise<void>;
    /**
     * Replace cloth by glTF url.
     * @param url - The url of glTF file.
     */
    replaceCloth(url: string): Promise<void>;
    /**
     * Add animation by glTF url which includes animation information.
     * @param animationUrl - The url of animation glTF file.
     * @param name - The name of animation, default is clip's name
     * @param wrapMode - The wrap mode of animation, default is Loop
     * @param newLayer - Whether to add a new layer, default is false
     * @param layerBlendingMode - The blending mode of layer if newLayer=true, default is Additive
     * @returns The animator state info.
     */
    addAnimation(animationUrl: string, name?: string, wrapMode?: WrapMode, newLayer?: boolean, layerBlendingMode?: AnimatorLayerBlendingMode): Promise<IAnimatorStateInfo>;
    addMouth(animationUrl: string, mouth: Mouth): Promise<IAnimatorStateInfo>;
    /**
     * Play or close mouth animation.
     * @remarks playMouth(Mouth.A, 0) can be used to reset mouth animation.
     * @param mouth - The mouth name.
     * @param weight - The weight of animation, range [0,1].
     */
    playMouth(mouth: Mouth, weight: number): Promise<void>;
    /**
     * Edit blend shapes.
     * @param bsList - The blend shape list
     */
    editBlendShapes(bsList: Record<string, number>): void;
    /**
     * Reset all blend shapes.
     */
    resetBlendShapes(): void;
    /**
     * @override
     */
    _onDestroy(): void;
    private _replaceModel;
    private _loadModel;
    private _destroyLastGLTF;
}
export {};
