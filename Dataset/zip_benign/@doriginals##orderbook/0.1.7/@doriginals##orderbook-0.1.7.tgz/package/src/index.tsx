import React from 'react';
import ReactDOM from 'react-dom';
//import { store } from './store';
//import { Provider } from 'react-redux';

//import App from "./App";

/*
ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}>
      <App />
    </Provider>
  </React.StrictMode>,
  document.getElementById('root')
);
*/

import Button from "./components/Button";
import DepthVisualizer from "./components/DepthVisualizer";
import Footer from "./components/Footer";
import GroupingSelectBox from "./components/GroupingSelectBox";
import Header from "./components/Header";
import Loader from "./components/Loader";
import OrderBook from "./components/OrderBook";
import Spread from "./components/Spread";
import StatusMessage from "./components/StatusMessage";


const modules =  {Button, DepthVisualizer, Footer, GroupingSelectBox, Header, Loader, OrderBook, Spread, StatusMessage};

export default modules;
