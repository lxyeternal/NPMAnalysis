export * from "./lib/ngx-map.component";
export * from "./lib/ngx-map.types";
