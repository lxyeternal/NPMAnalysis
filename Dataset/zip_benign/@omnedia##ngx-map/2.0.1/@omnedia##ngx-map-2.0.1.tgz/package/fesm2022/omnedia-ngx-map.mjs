import * as i0 from '@angular/core';
import { PLATFORM_ID, Component, Inject, ViewChild, ViewChildren, Input } from '@angular/core';
import * as i2 from '@angular/common';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import DottedMapImport from 'dotted-map';
import * as i1 from '@angular/platform-browser';

const DottedMap = DottedMapImport.default || DottedMapImport;

class NgxMapComponent {
    platformId;
    cdr;
    sanitizer;
    container;
    animatedPaths;
    animations;
    styleClass;
    set updateDots(dots) {
        dots = dots.map((dot, index) => {
            dot.animationStart = `${this.getRandomDelay()}; omMapPathAnimation${index}.end+${this.getRandomDelay()}`;
            return dot;
        });
        this.dots = dots;
    }
    dots = [];
    lineColor = "#0ea5e9";
    set updateBackgroundColor(color) {
        this.backgroundColor = color;
        this.generateSvgMap();
    }
    backgroundColor;
    set updateMapColor(color) {
        this.mapColor = color;
        this.generateSvgMap();
    }
    mapColor = "rgba(0,0,0,0.40)";
    set updateMapDotsShape(shape) {
        this.mapDotsShape = shape;
        this.generateSvgMap();
    }
    mapDotsShape = "circle";
    set updateMapDotsRadius(radius) {
        this.mapDotsRadius = radius;
        this.generateSvgMap();
    }
    mapDotsRadius = 0.22;
    animated = false;
    svgMap;
    pathLengths = new Map();
    intersectionObserver;
    hasInitializedObserver = false;
    isInView = false;
    constructor(platformId, cdr, sanitizer) {
        this.platformId = platformId;
        this.cdr = cdr;
        this.sanitizer = sanitizer;
    }
    ngAfterViewInit() {
        if (isPlatformBrowser(this.platformId) && !this.hasInitializedObserver) {
            this.hasInitializedObserver = true;
            this.intersectionObserver = new IntersectionObserver(([entry]) => {
                const wasInView = this.isInView;
                this.isInView = entry.isIntersecting;
                if (wasInView !== this.isInView) {
                    this.cdr.detectChanges();
                }
                if (this.isInView && !wasInView) {
                    this.triggerAnimations();
                }
            });
            this.intersectionObserver.observe(this.container.nativeElement);
        }
        this.generateSvgMap();
    }
    generateSvgMap() {
        const map = new DottedMap({ height: 100, grid: "diagonal" });
        const rawSvg = map.getSVG({
            radius: this.mapDotsRadius,
            color: this.mapColor,
            shape: this.mapDotsShape,
            backgroundColor: this.backgroundColor,
        });
        this.svgMap = this.sanitizer.bypassSecurityTrustHtml(rawSvg);
        this.cdr.detectChanges();
    }
    ngOnDestroy() {
        this.intersectionObserver?.disconnect();
    }
    projectPoint(lat, lng) {
        const x = (lng + 180) * (800 / 360);
        const y = (90 - lat) * (400 / 180);
        return { x, y };
    }
    createCurvedPath(start, end) {
        const midX = (start.x + end.x) / 2;
        const midY = Math.min(start.y, end.y) - 50;
        return `M ${start.x} ${start.y} Q ${midX} ${midY} ${end.x} ${end.y}`;
    }
    getPathLength(index) {
        if (!this.pathLengths.has(index)) {
            const pathElement = this.animatedPaths?.toArray()[index]?.nativeElement;
            if (pathElement) {
                this.pathLengths.set(index, pathElement.getTotalLength());
            }
        }
        return this.pathLengths.get(index);
    }
    getRandomDelay() {
        return `${((Math.random() + 1) * 2).toFixed(2)}s`;
    }
    triggerAnimations() {
        this.animations.forEach((animation, index) => {
            const element = animation.nativeElement;
            element.setAttribute("fill", "remove");
            setTimeout(() => {
                element.setAttribute("fill", "freeze");
                element.beginElement();
            }, index * 500);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.0", ngImport: i0, type: NgxMapComponent, deps: [{ token: PLATFORM_ID }, { token: i0.ChangeDetectorRef }, { token: i1.DomSanitizer }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.0", type: NgxMapComponent, isStandalone: true, selector: "om-map", inputs: { styleClass: "styleClass", updateDots: ["dots", "updateDots"], lineColor: "lineColor", updateBackgroundColor: ["backgroundColor", "updateBackgroundColor"], updateMapColor: ["mapColor", "updateMapColor"], updateMapDotsShape: ["mapDotsShape", "updateMapDotsShape"], updateMapDotsRadius: ["mapDotsRadius", "updateMapDotsRadius"], animated: "animated" }, viewQueries: [{ propertyName: "container", first: true, predicate: ["OmMap"], descendants: true, static: true }, { propertyName: "animatedPaths", predicate: ["animatedPath"], descendants: true }, { propertyName: "animations", predicate: ["animatedPathAnimation"], descendants: true }], ngImport: i0, template: "<div class=\"om-map\" [ngClass]=\"styleClass\" #OmMap>\r\n  <div class=\"om-map-svg\" [innerHTML]=\"svgMap\"></div>\r\n  <svg class=\"om-map-overlay\" viewBox=\"0 0 800 400\">\r\n    <ng-container *ngFor=\"let dot of dots; let i = index\">\r\n      <g>\r\n        <path\r\n          #animatedPath\r\n          [attr.d]=\"createCurvedPath(projectPoint(dot.start.lat, dot.start.lng), projectPoint(dot.end.lat, dot.end.lng))\"\r\n          fill=\"none\"\r\n          [attr.stroke]=\"lineColor\"\r\n          stroke-width=\"1\"\r\n          [attr.stroke-dasharray]=\"getPathLength(i)\"\r\n          [attr.stroke-dashoffset]=\"getPathLength(i)\"\r\n        >\r\n          <ng-container *ngIf=\"animated && isInView\">\r\n            <animate\r\n              [id]=\"'omMapPathAnimation' + i\"\r\n              attributeName=\"stroke-dashoffset\"\r\n              [attr.from]=\"getPathLength(i)\"\r\n              [attr.to]=\"-1 * getPathLength(i)\"\r\n              dur=\"2s\"\r\n              [attr.begin]=\"dot.animationStart\"\r\n            />\r\n          </ng-container>\r\n          <ng-container *ngIf=\"!animated && isInView\">\r\n            <animate\r\n              #animatedPathAnimation\r\n              [id]=\"'omMapPathAnimation' + i\"\r\n              attributeName=\"stroke-dashoffset\"\r\n              [attr.from]=\"getPathLength(i)\"\r\n              [attr.to]=\"0\"\r\n              dur=\"1s\"\r\n              [attr.begin]=\"0.5 * i+'s'\"\r\n              fill=\"freeze\"\r\n            />\r\n          </ng-container>\r\n        </path>\r\n      </g>\r\n      <g>\r\n        <circle\r\n          [attr.cx]=\"projectPoint(dot.start.lat, dot.start.lng).x\"\r\n          [attr.cy]=\"projectPoint(dot.start.lat, dot.start.lng).y\"\r\n          r=\"2\"\r\n          [attr.fill]=\"lineColor\"\r\n        />\r\n        <circle\r\n          [attr.cx]=\"projectPoint(dot.start.lat, dot.start.lng).x\"\r\n          [attr.cy]=\"projectPoint(dot.start.lat, dot.start.lng).y\"\r\n          r=\"2\"\r\n          [attr.fill]=\"lineColor\"\r\n          opacity=\"0.5\"\r\n        >\r\n          <ng-container *ngIf=\"isInView\">\r\n            <animate attributeName=\"r\" from=\"2\" to=\"8\" dur=\"1.5s\" repeatCount=\"indefinite\" />\r\n            <animate attributeName=\"opacity\" from=\"0.5\" to=\"0\" dur=\"1.5s\" repeatCount=\"indefinite\" />\r\n          </ng-container>\r\n        </circle>\r\n      </g>\r\n      <g>\r\n        <circle\r\n          [attr.cx]=\"projectPoint(dot.end.lat, dot.end.lng).x\"\r\n          [attr.cy]=\"projectPoint(dot.end.lat, dot.end.lng).y\"\r\n          r=\"2\"\r\n          [attr.fill]=\"lineColor\"\r\n        />\r\n        <circle\r\n          [attr.cx]=\"projectPoint(dot.end.lat, dot.end.lng).x\"\r\n          [attr.cy]=\"projectPoint(dot.end.lat, dot.end.lng).y\"\r\n          r=\"2\"\r\n          [attr.fill]=\"lineColor\"\r\n          opacity=\"0.5\"\r\n        >\r\n          <ng-container *ngIf=\"isInView\">\r\n            <animate attributeName=\"r\" from=\"2\" to=\"8\" dur=\"1.5s\" repeatCount=\"indefinite\" />\r\n            <animate attributeName=\"opacity\" from=\"0.5\" to=\"0\" dur=\"1.5s\" repeatCount=\"indefinite\" />\r\n          </ng-container>\r\n        </circle>\r\n      </g>\r\n    </ng-container>\r\n  </svg>\r\n</div>\r\n", styles: [".om-map{position:relative;width:100%;aspect-ratio:2/1;border-radius:.5rem}.om-map-svg{width:100%;height:100%;pointer-events:none;-webkit-user-select:none;user-select:none}.om-map-overlay{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;-webkit-user-select:none;user-select:none}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.0", ngImport: i0, type: NgxMapComponent, decorators: [{
            type: Component,
            args: [{ selector: "om-map", standalone: true, imports: [CommonModule], template: "<div class=\"om-map\" [ngClass]=\"styleClass\" #OmMap>\r\n  <div class=\"om-map-svg\" [innerHTML]=\"svgMap\"></div>\r\n  <svg class=\"om-map-overlay\" viewBox=\"0 0 800 400\">\r\n    <ng-container *ngFor=\"let dot of dots; let i = index\">\r\n      <g>\r\n        <path\r\n          #animatedPath\r\n          [attr.d]=\"createCurvedPath(projectPoint(dot.start.lat, dot.start.lng), projectPoint(dot.end.lat, dot.end.lng))\"\r\n          fill=\"none\"\r\n          [attr.stroke]=\"lineColor\"\r\n          stroke-width=\"1\"\r\n          [attr.stroke-dasharray]=\"getPathLength(i)\"\r\n          [attr.stroke-dashoffset]=\"getPathLength(i)\"\r\n        >\r\n          <ng-container *ngIf=\"animated && isInView\">\r\n            <animate\r\n              [id]=\"'omMapPathAnimation' + i\"\r\n              attributeName=\"stroke-dashoffset\"\r\n              [attr.from]=\"getPathLength(i)\"\r\n              [attr.to]=\"-1 * getPathLength(i)\"\r\n              dur=\"2s\"\r\n              [attr.begin]=\"dot.animationStart\"\r\n            />\r\n          </ng-container>\r\n          <ng-container *ngIf=\"!animated && isInView\">\r\n            <animate\r\n              #animatedPathAnimation\r\n              [id]=\"'omMapPathAnimation' + i\"\r\n              attributeName=\"stroke-dashoffset\"\r\n              [attr.from]=\"getPathLength(i)\"\r\n              [attr.to]=\"0\"\r\n              dur=\"1s\"\r\n              [attr.begin]=\"0.5 * i+'s'\"\r\n              fill=\"freeze\"\r\n            />\r\n          </ng-container>\r\n        </path>\r\n      </g>\r\n      <g>\r\n        <circle\r\n          [attr.cx]=\"projectPoint(dot.start.lat, dot.start.lng).x\"\r\n          [attr.cy]=\"projectPoint(dot.start.lat, dot.start.lng).y\"\r\n          r=\"2\"\r\n          [attr.fill]=\"lineColor\"\r\n        />\r\n        <circle\r\n          [attr.cx]=\"projectPoint(dot.start.lat, dot.start.lng).x\"\r\n          [attr.cy]=\"projectPoint(dot.start.lat, dot.start.lng).y\"\r\n          r=\"2\"\r\n          [attr.fill]=\"lineColor\"\r\n          opacity=\"0.5\"\r\n        >\r\n          <ng-container *ngIf=\"isInView\">\r\n            <animate attributeName=\"r\" from=\"2\" to=\"8\" dur=\"1.5s\" repeatCount=\"indefinite\" />\r\n            <animate attributeName=\"opacity\" from=\"0.5\" to=\"0\" dur=\"1.5s\" repeatCount=\"indefinite\" />\r\n          </ng-container>\r\n        </circle>\r\n      </g>\r\n      <g>\r\n        <circle\r\n          [attr.cx]=\"projectPoint(dot.end.lat, dot.end.lng).x\"\r\n          [attr.cy]=\"projectPoint(dot.end.lat, dot.end.lng).y\"\r\n          r=\"2\"\r\n          [attr.fill]=\"lineColor\"\r\n        />\r\n        <circle\r\n          [attr.cx]=\"projectPoint(dot.end.lat, dot.end.lng).x\"\r\n          [attr.cy]=\"projectPoint(dot.end.lat, dot.end.lng).y\"\r\n          r=\"2\"\r\n          [attr.fill]=\"lineColor\"\r\n          opacity=\"0.5\"\r\n        >\r\n          <ng-container *ngIf=\"isInView\">\r\n            <animate attributeName=\"r\" from=\"2\" to=\"8\" dur=\"1.5s\" repeatCount=\"indefinite\" />\r\n            <animate attributeName=\"opacity\" from=\"0.5\" to=\"0\" dur=\"1.5s\" repeatCount=\"indefinite\" />\r\n          </ng-container>\r\n        </circle>\r\n      </g>\r\n    </ng-container>\r\n  </svg>\r\n</div>\r\n", styles: [".om-map{position:relative;width:100%;aspect-ratio:2/1;border-radius:.5rem}.om-map-svg{width:100%;height:100%;pointer-events:none;-webkit-user-select:none;user-select:none}.om-map-overlay{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;-webkit-user-select:none;user-select:none}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }, { type: i0.ChangeDetectorRef }, { type: i1.DomSanitizer }], propDecorators: { container: [{
                type: ViewChild,
                args: ["OmMap", { static: true }]
            }], animatedPaths: [{
                type: ViewChildren,
                args: ["animatedPath"]
            }], animations: [{
                type: ViewChildren,
                args: ["animatedPathAnimation"]
            }], styleClass: [{
                type: Input
            }], updateDots: [{
                type: Input,
                args: ["dots"]
            }], lineColor: [{
                type: Input
            }], updateBackgroundColor: [{
                type: Input,
                args: ["backgroundColor"]
            }], updateMapColor: [{
                type: Input,
                args: ["mapColor"]
            }], updateMapDotsShape: [{
                type: Input,
                args: ["mapDotsShape"]
            }], updateMapDotsRadius: [{
                type: Input,
                args: ["mapDotsRadius"]
            }], animated: [{
                type: Input
            }] } });

/*
 * Public API Surface of ngx-map
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgxMapComponent };
//# sourceMappingURL=omnedia-ngx-map.mjs.map
