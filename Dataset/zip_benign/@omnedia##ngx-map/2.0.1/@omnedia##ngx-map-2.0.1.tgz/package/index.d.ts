/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@omnedia/ngx-map" />
export * from './public-api';
