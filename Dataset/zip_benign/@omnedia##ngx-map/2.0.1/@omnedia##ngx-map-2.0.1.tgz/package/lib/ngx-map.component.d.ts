import { AfterViewInit, ChangeDetectorRef, ElementRef, OnDestroy, QueryList } from "@angular/core";
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import { Dot } from "./ngx-map.types";
import * as i0 from "@angular/core";
export declare class NgxMapComponent implements AfterViewInit, OnDestroy {
    private platformId;
    private readonly cdr;
    private readonly sanitizer;
    container: ElementRef<HTMLDivElement>;
    animatedPaths: QueryList<ElementRef<SVGPathElement>>;
    animations: QueryList<ElementRef<SVGAnimationElement>>;
    styleClass: string | undefined;
    set updateDots(dots: Dot[]);
    dots: Dot[];
    lineColor: string;
    set updateBackgroundColor(color: string);
    backgroundColor?: string;
    set updateMapColor(color: string);
    mapColor: string;
    set updateMapDotsShape(shape: "circle" | "hexagon");
    mapDotsShape: "circle" | "hexagon";
    set updateMapDotsRadius(radius: number);
    mapDotsRadius: number;
    animated: boolean;
    svgMap: SafeHtml;
    private pathLengths;
    private intersectionObserver?;
    private hasInitializedObserver;
    isInView: boolean;
    constructor(platformId: object, cdr: ChangeDetectorRef, sanitizer: DomSanitizer);
    ngAfterViewInit(): void;
    private generateSvgMap;
    ngOnDestroy(): void;
    projectPoint(lat: number, lng: number): {
        x: number;
        y: number;
    };
    createCurvedPath(start: {
        x: number;
        y: number;
    }, end: {
        x: number;
        y: number;
    }): string;
    getPathLength(index: number): number;
    getRandomDelay(): string;
    private triggerAnimations;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxMapComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NgxMapComponent, "om-map", never, { "styleClass": { "alias": "styleClass"; "required": false; }; "updateDots": { "alias": "dots"; "required": false; }; "lineColor": { "alias": "lineColor"; "required": false; }; "updateBackgroundColor": { "alias": "backgroundColor"; "required": false; }; "updateMapColor": { "alias": "mapColor"; "required": false; }; "updateMapDotsShape": { "alias": "mapDotsShape"; "required": false; }; "updateMapDotsRadius": { "alias": "mapDotsRadius"; "required": false; }; "animated": { "alias": "animated"; "required": false; }; }, {}, never, never, true, never>;
}
