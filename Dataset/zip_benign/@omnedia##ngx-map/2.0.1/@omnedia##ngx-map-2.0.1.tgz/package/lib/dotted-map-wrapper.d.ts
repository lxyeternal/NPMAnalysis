declare const DottedMap: any;
export default DottedMap;
