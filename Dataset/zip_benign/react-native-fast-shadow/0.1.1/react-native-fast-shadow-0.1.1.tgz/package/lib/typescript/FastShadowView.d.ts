import { ViewProps } from 'react-native';
export declare type FastShadowViewProps = ViewProps & {
    cornerRadii: {
        topLeft: number;
        topRight: number;
        bottomLeft: number;
        bottomRight: number;
    };
};
export declare const FastShadowView: import("react-native").HostComponent<FastShadowViewProps>;
//# sourceMappingURL=FastShadowView.d.ts.map