import { View } from 'react-native';
export declare const ShadowedView: typeof View;
//# sourceMappingURL=ShadowedView.d.ts.map