import React from 'react';
import { ViewProps } from 'react-native';
export declare class ShadowedView extends React.Component<ViewProps> {
    render(): React.ReactNode;
}
//# sourceMappingURL=ShadowedView.android.d.ts.map