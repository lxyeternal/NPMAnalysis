var div = document.createElement('div'),

    prefixes = ' -webkit- -moz- -o- -ms- '.split(' ');

var setCss = function(str) {
    div.style.cssText = str;
};

var contains = function(str, substr) {
    return !!~('' + str).indexOf(substr);
};

var supports_gradients = function() {
    /**
     * For CSS Gradients syntax, please see:
     * webkit.org/blog/175/introducing-css-gradients/
     * developer.mozilla.org/en/CSS/-moz-linear-gradient
     * developer.mozilla.org/en/CSS/-moz-radial-gradient
     * dev.w3.org/csswg/css3-images/#gradients-
     */
    var str1 = 'background-image:',
        str2 = 'gradient(linear,left top,right bottom,from(#9f9),to(white));',
        str3 = 'linear-gradient(left top,#9f9, white);';

    setCss(
         // legacy webkit syntax (FIXME: remove when syntax not in use anymore)
          (str1 + '-webkit- '.split(' ').join(str2 + str1)
         // standard syntax             // trailing 'background-image:'
          + prefixes.join(str3 + str1)).slice(0, -str1.length)
    );

    return contains(div.style.backgroundImage, 'gradient');
};

module.exports = supports_gradients();

div = null;