# DOWNLOAD EBOOK 1984 by George Orwell PDF EPUB MOBI (ii12n)

### Download Ebook + 1984 by George Orwell in pdf - mobi - epub format



➡️ ➡️ <b>CLICK HERE:</b> <a href="http://tinybit.cc/7901a497">http://tinybit.cc/7901a497</a> ⬅️ ⬅️

<img src="https://is2-ssl.mzstatic.com/image/thumb/Publication118/v4/ad/8d/74/ad8d7436-a09b-5c7e-829f-a59ec4501e05/source/600x600bb.jpg" style="width:300px;" />

George Orwell’s 1984 takes on new life with extraordinary relevance and renewed popularity. “Orwell saw, to his credit, that the act of falsifying reality is only secondarily a way of changing perceptions. It is, above all, a way of asserting power.”— The New Yorker   In 1984, London is a grim city in the totalitarian state of Oceania where Big Brother is always watching you and the Thought Police can practically read your mind. Winston Smith is a man in grave danger for the simple reason that his memory still functions. Drawn into a forbidden love affair, Winston finds the courage to join a secret revolutionary organization called The Brotherhood, dedicated to the destruction of the Party. Together with his beloved Julia, he hazards his life in a deadly match against the powers that be. Lionel Trilling said of Orwell’s masterpiece, “ 1984 is a profound, terrifying, and wholly fascinating book. It is a fantasy of the political future, and like any such fantasy, serves its author as a magnifying device for an examination of the present.” Though the year 1984 now exists in the past, Orwell’s novel remains an urgent call for the individual willing to speak truth to power.

Now you can download 1984 epub by George Orwell from this link:

👉👉👉 <b>DOWNLOAD EBOOK HERE: <a href="http://tinybit.cc/7901a497">http://tinybit.cc/7901a497</a></b>

