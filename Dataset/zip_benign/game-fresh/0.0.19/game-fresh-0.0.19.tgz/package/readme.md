# fresh

# 游戏

##### 安装

```
npm install game-fresh
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game": "game-fresh/fresh"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "common-game"
  ]
}
```

- js

```
Page({
  data: {
    gameSource: {
      game1: {
        baseOps: {
          speed: 3,//速度,值越大速度越块
          speedXS: 3,//速度系数
          minBottomY: 1015,//从底部开始计算 元素最小状态时的Y坐标
          minWidth: 170,//最小状态位置的宽度
          maxBottomY: 320,//从底部开始计算 元素最大状态时的Y坐标
          maxWidth: 750,//最大状态位置的宽度
          xzMaxScale: true,//是否限制最大缩放比例 true:当超过maxBottomY位置之后,不再继续放大
          stepH: 200,//两个物品之间的间距
          isNotIdx: 1,//不生成到指定赛道
          moveSpeed: 10,//点击按钮移动速度
        },
        audioObj: {
          default: { sourceType: "audio", audioSrc: "http://isv-vod.alibabausercontent.com/RGjZJMdpNgKGVQeEyw8/GVKpnZalUAGraWkOd73?auth_key=1626078260-0-0-b4fdf53dc70f9dcf1a6721bbe1b252f0&w=0&h=0&e=sd&t=2106e04516258190605127434ee9d8" }, //音效
          bomb1: { sourceType: "audio", audioSrc: "http://isv-vod.alibabausercontent.com/RGjZJMdpNgKGVQeEyw8/qzi1JhFmjUlr04cwc9U?auth_key=1626078273-0-0-a162c814b1825e77adcfca03d01bdee5&w=0&h=0&e=sd&t=2106e04516258190734098411ee9d8" }, //音效
        },
        items: [
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01ZNkTW51EUdMv8FugV_!!2185320355.png", audioName: "default", val: 0, bound: { left: 0, top: 0, right: 0, bottom: 17 }, probability: 1, scaleOps: { min: 0.5, max: 3 }, flyPos: { x: 700, y: 100, scale: 0, duration: 0.5 } },
          {
            "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01SZhiFR1EUdMtYkzPm_!!2185320355.png", audioName: "bomb1", val: 5, bound: { left: 0, top: 0, right: 0, bottom: 17 }, probability: 1, scaleOps: { min: 0.8, max: 2 },
            tipScore: { src: "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01mTEhBf1EUdMzTBp9h_!!2185320355.png", offset: { x: 0, y: 0 }, scale: { x: 2.5, y: 2.5 } },
            boom: {
              srcArr: [
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01k33zXb1EUdMzStUxF_!!2185320355.png", "name": "元素爆炸_00000.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01TTHEMk1EUdMsrfyeS_!!2185320355.png", "name": "元素爆炸_00001.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01yewC1h1EUdMzSu2EG_!!2185320355.png", "name": "元素爆炸_00002.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01qkvbFR1EUdMv9TqB4_!!2185320355.png", "name": "元素爆炸_00003.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01pc8Zaq1EUdMskoHBS_!!2185320355.png", "name": "元素爆炸_00004.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01tA3RaE1EUdMzStA8G_!!2185320355.png", "name": "元素爆炸_00005.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01TzTphu1EUdMo9MyBv_!!2185320355.png", "name": "元素爆炸_00006.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN014LfiI81EUdMtZwu7D_!!2185320355.png", "name": "元素爆炸_00007.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01wjgDHV1EUdMqQX9Xe_!!2185320355.png", "name": "元素爆炸_00008.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01NtRvdJ1EUdN0FHrxP_!!2185320355.png", "name": "元素爆炸_00009.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01Ynijia1EUdMzSx7U8_!!2185320355.png", "name": "元素爆炸_00010.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01t7K4981EUdMyEmLmT_!!2185320355.png", "name": "元素爆炸_00011.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN010dh4gG1EUdMphMAU1_!!2185320355.png", "name": "元素爆炸_00012.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01dOWHOc1EUdMsrdhGv_!!2185320355.png", "name": "元素爆炸_00013.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01YSMvhC1EUdMsre6D1_!!2185320355.png", "name": "元素爆炸_00014.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01vVaOZg1EUdMtZvtjc_!!2185320355.png", "name": "元素爆炸_00015.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01bR0UcX1EUdMsrfJ4t_!!2185320355.png", "name": "元素爆炸_00016.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01sno98q1EUdMv9UAzF_!!2185320355.png", "name": "元素爆炸_00017.png", "width": "730", "height": "400" },
              ],
              type: "animate",
              imgType: "max",
              width: 730 * 18,
              height: 400,
              fWidth: 730,
              fHeight: 400,
              count: 18,
              boomSpeed: 0.5,
              offset: {
                x: 0,
                y: 0
              },
              loop: !true,
            }
          },
          {
            "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01UHLLLC1EUdN0E8N2R_!!2185320355.png", audioName: "bomb1", val: 5, bound: { left: 0, top: 0, right: 0, bottom: 17 }, probability: 1, scaleOps: { min: 0.5, max: 1.5 },
            tipScore: { src: "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01mTEhBf1EUdMzTBp9h_!!2185320355.png", offset: { x: 0, y: 0 }, scale: { x: 2.5, y: 2.5 } },
            boom: {
              srcArr: [
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01k33zXb1EUdMzStUxF_!!2185320355.png", "name": "元素爆炸_00000.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01TTHEMk1EUdMsrfyeS_!!2185320355.png", "name": "元素爆炸_00001.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01yewC1h1EUdMzSu2EG_!!2185320355.png", "name": "元素爆炸_00002.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01qkvbFR1EUdMv9TqB4_!!2185320355.png", "name": "元素爆炸_00003.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01pc8Zaq1EUdMskoHBS_!!2185320355.png", "name": "元素爆炸_00004.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01tA3RaE1EUdMzStA8G_!!2185320355.png", "name": "元素爆炸_00005.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01TzTphu1EUdMo9MyBv_!!2185320355.png", "name": "元素爆炸_00006.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN014LfiI81EUdMtZwu7D_!!2185320355.png", "name": "元素爆炸_00007.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01wjgDHV1EUdMqQX9Xe_!!2185320355.png", "name": "元素爆炸_00008.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01NtRvdJ1EUdN0FHrxP_!!2185320355.png", "name": "元素爆炸_00009.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01Ynijia1EUdMzSx7U8_!!2185320355.png", "name": "元素爆炸_00010.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01t7K4981EUdMyEmLmT_!!2185320355.png", "name": "元素爆炸_00011.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN010dh4gG1EUdMphMAU1_!!2185320355.png", "name": "元素爆炸_00012.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01dOWHOc1EUdMsrdhGv_!!2185320355.png", "name": "元素爆炸_00013.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01YSMvhC1EUdMsre6D1_!!2185320355.png", "name": "元素爆炸_00014.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01vVaOZg1EUdMtZvtjc_!!2185320355.png", "name": "元素爆炸_00015.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01bR0UcX1EUdMsrfJ4t_!!2185320355.png", "name": "元素爆炸_00016.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01sno98q1EUdMv9UAzF_!!2185320355.png", "name": "元素爆炸_00017.png", "width": "730", "height": "400" },
              ],
              type: "animate",
              imgType: "max",
              width: 730 * 18,
              height: 400,
              fWidth: 730,
              fHeight: 400,
              count: 18,
              boomSpeed: 0.5,
              offset: {
                x: 0,
                y: 0
              },
              loop: !true,
            }
          },
          {
            "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01Lj81o41EUdMsjacKX_!!2185320355.png", audioName: "bomb1", val: 10, bound: { left: 0, top: 0, right: 0, bottom: 17 }, probability: 1, scaleOps: { min: 0.5, max: 2 },
            tipScore: { src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01bFEXlu1EUdMxPcZym_!!2185320355.png", offset: { x: 0, y: 0 }, scale: { x: 2.5, y: 2.5 } },
            boom: {
              srcArr: [
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01k33zXb1EUdMzStUxF_!!2185320355.png", "name": "元素爆炸_00000.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01TTHEMk1EUdMsrfyeS_!!2185320355.png", "name": "元素爆炸_00001.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01yewC1h1EUdMzSu2EG_!!2185320355.png", "name": "元素爆炸_00002.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01qkvbFR1EUdMv9TqB4_!!2185320355.png", "name": "元素爆炸_00003.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01pc8Zaq1EUdMskoHBS_!!2185320355.png", "name": "元素爆炸_00004.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01tA3RaE1EUdMzStA8G_!!2185320355.png", "name": "元素爆炸_00005.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01TzTphu1EUdMo9MyBv_!!2185320355.png", "name": "元素爆炸_00006.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN014LfiI81EUdMtZwu7D_!!2185320355.png", "name": "元素爆炸_00007.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01wjgDHV1EUdMqQX9Xe_!!2185320355.png", "name": "元素爆炸_00008.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01NtRvdJ1EUdN0FHrxP_!!2185320355.png", "name": "元素爆炸_00009.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01Ynijia1EUdMzSx7U8_!!2185320355.png", "name": "元素爆炸_00010.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01t7K4981EUdMyEmLmT_!!2185320355.png", "name": "元素爆炸_00011.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN010dh4gG1EUdMphMAU1_!!2185320355.png", "name": "元素爆炸_00012.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01dOWHOc1EUdMsrdhGv_!!2185320355.png", "name": "元素爆炸_00013.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01YSMvhC1EUdMsre6D1_!!2185320355.png", "name": "元素爆炸_00014.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01vVaOZg1EUdMtZvtjc_!!2185320355.png", "name": "元素爆炸_00015.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01bR0UcX1EUdMsrfJ4t_!!2185320355.png", "name": "元素爆炸_00016.png", "width": "730", "height": "400" },
                { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01sno98q1EUdMv9UAzF_!!2185320355.png", "name": "元素爆炸_00017.png", "width": "730", "height": "400" },
              ],
              type: "animate",
              imgType: "max",
              width: 730 * 18,
              height: 400,
              fWidth: 730,
              fHeight: 400,
              count: 18,
              boomSpeed: 0.5,
              offset: {
                x: 0,
                y: 0
              },
              loop: !true,
            }
          },
        ],
        btns: [
          { src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01zEBQaW1EUdMjEk7bS_!!2185320355.png", x: 74, y: 1250, direction: -1 },
          { src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01AW0dW01EUdMsqQRJ2_!!2185320355.png", x: 590, y: 1250, direction: 1 },
        ],
        playerInfo: {
          src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01cIcHTC1EUdMo8ABU7_!!2185320355.png", offset: {
            x: 0,
            y: -52
          },
          playerAniScore: 10,//达到300分显示动画
        },
        playerAni: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN0112R2bz1EUdN0EcNlX_!!2185320355.png", "name": "元素加速球_00000.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN013Mne5x1EUdMjFGDMT_!!2185320355.png", "name": "元素加速球_00001.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01Op8h5i1EUdMo8dahJ_!!2185320355.png", "name": "元素加速球_00002.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01nH3Jl81EUdMzSEkKU_!!2185320355.png", "name": "元素加速球_00003.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01QitNOJ1EUdMzSEkKY_!!2185320355.png", "name": "元素加速球_00004.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01hqrFRp1EUdMqPqvQ0_!!2185320355.png", "name": "元素加速球_00005.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01R09dbo1EUdMpgjEKg_!!2185320355.png", "name": "元素加速球_00006.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01W3RwkG1EUdMyE5mrx_!!2185320355.png", "name": "元素加速球_00007.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01xaYtl81EUdMjFFkCX_!!2185320355.png", "name": "元素加速球_00008.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01DXzad51EUdN0EbArr_!!2185320355.png", "name": "元素加速球_00009.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN0133XfrN1EUdMv8oHiV_!!2185320355.png", "name": "元素加速球_00010.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01JbQsiV1EUdMsk6Isl_!!2185320355.png", "name": "元素加速球_00011.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01WxP05J1EUdMtZEKU7_!!2185320355.png", "name": "元素加速球_00012.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN017BXi9Q1EUdMtZGXkY_!!2185320355.png", "name": "元素加速球_00013.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01kYIl0j1EUdMo8eOUv_!!2185320355.png", "name": "元素加速球_00014.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01vKIdFW1EUdMzSCw0g_!!2185320355.png", "name": "元素加速球_00015.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01YUaNtI1EUdN0EcaBB_!!2185320355.png", "name": "元素加速球_00016.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01xhKztZ1EUdMqPoF7U_!!2185320355.png", "name": "元素加速球_00017.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01h6EVUk1EUdMv8pcsj_!!2185320355.png", "name": "元素加速球_00018.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01P3EDrw1EUdMxOeINi_!!2185320355.png", "name": "元素加速球_00019.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN011JMUpi1EUdN2JFY9z_!!2185320355.png", "name": "元素加速球_00020.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01VKmA8T1EUdMtZECB7_!!2185320355.png", "name": "元素加速球_00021.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01ZcxPAY1EUdMzSDTHB_!!2185320355.png", "name": "元素加速球_00022.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01bXdQsG1EUdMpgiYgz_!!2185320355.png", "name": "元素加速球_00023.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01RtT4PB1EUdMzSGHuG_!!2185320355.png", "name": "元素加速球_00024.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01LBnwcd1EUdN2JGQEf_!!2185320355.png", "name": "元素加速球_00025.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN014T73F01EUdMyE8s8V_!!2185320355.png", "name": "元素加速球_00026.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01qwQJKB1EUdMyE7Wxu_!!2185320355.png", "name": "元素加速球_00027.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01kTPJ131EUdMug3ORX_!!2185320355.png", "name": "元素加速球_00028.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01Ux8YnW1EUdMsk9aen_!!2185320355.png", "name": "元素加速球_00029.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01foY9cN1EUdMqPqac7_!!2185320355.png", "name": "元素加速球_00030.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01Xru2Mj1EUdMsqz0tP_!!2185320355.png", "name": "元素加速球_00031.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01vNI7fO1EUdN2JG1IP_!!2185320355.png", "name": "元素加速球_00032.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01BwGMlA1EUdMxOeIPB_!!2185320355.png", "name": "元素加速球_00033.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN012vkpHL1EUdMxOdpIy_!!2185320355.png", "name": "元素加速球_00034.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01lC0ENS1EUdMzSFx9Z_!!2185320355.png", "name": "元素加速球_00035.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01zvzowL1EUdMjFG9Bv_!!2185320355.png", "name": "元素加速球_00036.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN017SYcD11EUdMqPq7Xq_!!2185320355.png", "name": "元素加速球_00037.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN011fTgsO1EUdMsk93P8_!!2185320355.png", "name": "元素加速球_00038.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01CKJ4Zw1EUdN2JHE7f_!!2185320355.png", "name": "元素加速球_00039.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01ooYtqc1EUdMzSETew_!!2185320355.png", "name": "元素加速球_00040.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01bymR9j1EUdN0EenOA_!!2185320355.png", "name": "元素加速球_00041.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN0183APGN1EUdN0EeG7Q_!!2185320355.png", "name": "元素加速球_00042.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN013vzqby1EUdMxOg6ej_!!2185320355.png", "name": "元素加速球_00043.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01V3s4So1EUdMsr1E8c_!!2185320355.png", "name": "元素加速球_00044.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01PLcLGD1EUdN1SdLkI_!!2185320355.png", "name": "元素加速球_00045.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01UzjMZf1EUdMsk8zFO_!!2185320355.png", "name": "元素加速球_00046.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01brEGKa1EUdMug37rS_!!2185320355.png", "name": "元素加速球_00047.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01W39FLZ1EUdMzSFPsf_!!2185320355.png", "name": "元素加速球_00048.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01hrCvZu1EUdMxOf276_!!2185320355.png", "name": "元素加速球_00049.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN0132d9qB1EUdMpggHO6_!!2185320355.png", "name": "元素加速球_00050.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01G0cKGv1EUdMqPoyrj_!!2185320355.png", "name": "元素加速球_00051.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01n9fe201EUdMqPqWUV_!!2185320355.png", "name": "元素加速球_00052.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01seGf3x1EUdMtZI5Q7_!!2185320355.png", "name": "元素加速球_00053.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01Ulodib1EUdN2JFPu0_!!2185320355.png", "name": "元素加速球_00054.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01kOdmSY1EUdMo8gL8M_!!2185320355.png", "name": "元素加速球_00055.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01PW74v41EUdMpghp0S_!!2185320355.png", "name": "元素加速球_00056.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01z3yAy81EUdMpghxKz_!!2185320355.png", "name": "元素加速球_00057.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01d13IYV1EUdMsqykIb_!!2185320355.png", "name": "元素加速球_00058.png", "width": "460", "height": "450" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01UlUvGw1EUdMtZH9Fb_!!2185320355.png", "name": "元素加速球_00059.png", "width": "460", "height": "450" },
          ],
          type: "animate",
          imgType: "max",
          width: 460 * 60,
          height: 450,
          fWidth: 460,
          fHeight: 450,
          count: 60,
          boomSpeed: 1,
          offset: {
            x: 0,
            y: 0
          },
          loop: true,
          alpha: 0,
        }
      },
    }
  },
  onLoad() {
  },
  // 组件主动公开方法----------
  beginFun() {
    // 开始游戏
    this.gameComponent.onEvent("start");
  },
  stopFun() {
    // 结束游戏
    this.gameComponent.onEvent("stop");
  },
  resetFun(e) {
    let { currentTarget: { dataset: { type } } } = e;
    // 重置游戏
    this.gameComponent.onEvent("reset", type || "game1");
  },
  pauseFun() {
    // 暂停游戏
    this.gameComponent.onEvent("pause");
  },
  muteFun() {
    // 静音
    this.gameComponent.onEvent("mute");
  },
  playFun() {
    // 播放
    this.gameComponent.onEvent("play");
  },
  noFlyFun() {
    // 能量满了不在生成可以飞的球了
    this.gameComponent.onEvent("noFly");
  },

  // 组件回调方法------------------
  onRef(game) {
    this.gameComponent = game;
    console.log("进入游戏")
  },
  onInitDone() {
    // my.alert({
    //   content: "游戏初始化完成"
    // })
    // 初始化game1
    this.gameComponent.onEvent("reset", "game1");
  },
  onUpdate(ops) {
    // { totalScore: 0, imgObj: { } }
    console.log(ops)
  },
  onGameOver(totalScore) {
    console.log(totalScore)
  },
});
```

- xaml

```
  <view class="pageBox">
    <view class="gameBox">
      <game gameSource="{{gameSource}}" 
        onRef="onRef"
        onInitDone="onInitDone" 
        onUpdate="onUpdate" 
        onGameOver="onGameOver"
      />
    </view>

    <view style="position:absolute;left:0;top:200rpx;">
      <view onTap="beginFun" style="position:relative;z-index: 10;">开始</view>
      <view onTap="pauseFun" style="position:relative;z-index: 10;">暂停</view>
      <view onTap="stopFun" style="position:relative;z-index: 10;">结束</view>
      <view onTap="noFlyFun" style="position:relative;z-index: 10;">满能量</view>
      <view onTap="resetFun" data-type="game1" style="position:relative;z-index: 10;">重置游戏1</view>
      <view onTap="resetFun" data-type="game2" style="position:relative;z-index: 10;">重置游戏2</view>
      <view onTap="muteFun" style="position:relative;z-index: 10;">静音</view>
      <view onTap="playFun" style="position:relative;z-index: 10;">播放</view>
    </view>
  </view>
```
- acss
```
.pageBox{
  position: absolute;
  width: 750rpx;
  height: 100vh;
  left: 50%;
  top: 50%;
  transform: translateX(-50%) translateY(-50%);
}
.gameBox{
  position: relative;
  width: 750rpx;
  height: 1500rpx;
  /* background: #ccc; */
  background: url("https://img.alicdn.com/imgextra/i3/1080040467/O1CN01xjUcHF1FJveSn3Q1w_!!1080040467.png") no-repeat center bottom;
  background-image: url("https://img.alicdn.com/imgextra/i1/2185320355/O1CN01f8NVGW1EUdN2HXg3R_!!2185320355.png");
  background-size: 100% auto;
}
```