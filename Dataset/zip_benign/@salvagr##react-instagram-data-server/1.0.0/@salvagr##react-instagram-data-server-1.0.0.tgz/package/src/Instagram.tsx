// import { testData } from './utils/data'
import React from 'react';
import { TiHeartFullOutline } from 'react-icons/ti'
import './style.css';

type styleData = {
   profileContainer: any,
   profileImage: any,
   profileDataContainer: any,
   profileFollowsContainer: any,
   mediaContainer: any,
   mediaBox: any,
   overlay: any
}

export interface InstagramProps {
   username: string,
   style?: styleData,
   limit?: number
}

const graph_url = "https://graph.facebook.com"
const graph_version = 'v14.0'

const default_style = {
   profileContainer: {
      backgroundColor: '#F5F5F5',
      display: 'flex',
      alignItems: 'center',
      maxWidth: '300px',
      justifyContent: 'space-evenly',
      padding: '10px',
      borderRadius: '20px',
      // fontFamily: "Poppins",
      color: "black",
      gap: '1rem'
   },
   profileImage: {
      borderRadius: '100vh',
      maxWidth: '80px'
   },
   profileDataContainer: {
      h2: {
         margin: '0.5rem 0',
         fontSize: '21px'
      }
   },
   profileFollowsContainer: {
      p: {
         margin: '0.4rem 0',
         fontSize: '14px'
      }
   },
   mediaContainer: {
      backgroundColor: '#F5F5F5',
      gap: '1rem',
      marginTop: '1rem',
      padding: '1rem',
      borderRadius: '20px',
      flexWrap: 'wrap',
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit , minmax(300px , 1fr))',
      gridAutoRows: '300px',
      gridAutoFlow: 'dense',
   },
   mediaBox: {
      backgroundColor: '#fff',
      width: '100%',
      borderRadius: '20px',
      position: 'relative',
      zIndex: '1',
      a: {
         textDecoration: 'none',
         color: '#121212'
      },
      image: {
         borderRadius: '20px',
         objectFit: 'cover',
         width: '100%',
         height: '100%',
      }
   },
   overlay: {
      backgroundColor: 'rgba(0,0,0,0.0)',
      transform: 'scale(0)',
      transition: 'background .25s cubic-bezier(0.4, 0.0, 0.2, 1), visibility 0s linear .25s',
      position: 'absolute',
      width: '100%',
      height: '100%',
      top: 0,
      borderRadius: '20px',
      // fontFamily: 'Poppins',
      content: {
         color: 'white',
         position: 'absolute',
         top: '50%',
         left: '50%',
         transform: 'translate(-50%, -50%)',
         infoRows: {
            display: 'flex',
            alignItems: 'center',
            gap: '0.3rem'
         }
      }
   }
}

const getDataFromFacebookApi = async (username: string) => {
   const request = `${graph_url}/${graph_version}/${process.env.NEXT_PUBLIC_IG_BUSINESS_ID || process.env.REACT_APP_IG_BUSINESS_ID}?fields=business_discovery.username(${username})%7Busername%2Cwebsite%2Cname%2Cig_id%2Cid%2Cprofile_picture_url%2Cbiography%2Cfollows_count%2Cfollowers_count%2Cmedia_count%2Cmedia%7Bid%2Ccaption%2Clike_count%2Ccomments_count%2Ctimestamp%2Cusername%2Cmedia_product_type%2Cmedia_type%2Cowner%2Cpermalink%2Cmedia_url%2Cchildren%7Bmedia_url%7D%7D%7D`

   let myHeaders = new Headers({
      Authorization: `Bearer ${process.env.NEXT_PUBLIC_IG_ACCESS_TOKEN || process.env.REACT_APP_IG_ACCESS_TOKEN}`
   });
   let requestOptions = {
      method: 'GET',
      headers: myHeaders,
   };

   return await fetch(request, requestOptions)
      .then(response => response.json())
}


export const Instagram = async ({ username, style = default_style, limit = 12 }: InstagramProps) => {

   const insta = await getDataFromFacebookApi(username);

   const handleMouseEnter = (e: any) => {
      const id = e.target.id;
      const media_id = id.split('-')[2];
      const overlay = document.querySelector<HTMLElement>(`#overlay-ref-${media_id}`);
      if (overlay) {
         overlay.style.backgroundColor = 'rgba(0,0,0,0.5)';
         overlay.style.transform = 'scale(1)';
      }
   };

   const handleMouseLeave = (e: any) => {
      const id = e.target.id;
      const media_id = id.split('-')[2];
      const overlay = document.querySelector<HTMLElement>(`#overlay-ref-${media_id}`);
      if (overlay) {
         overlay.style.backgroundColor = default_style.overlay.backgroundColor;
         overlay.style.transform = 'scale(0)';
      }
   };

   return <>
      {insta ? (
         <>
            <div
               style={{ ...default_style.profileContainer, ...style.profileContainer }}
            >
               {/* Account profile image */}
               <img
                  style={{ ...default_style.profileImage, ...style.profileImage }} src={insta.business_discovery?.profile_picture_url} alt="profile_picture" />

               <div style={{ ...default_style.profileDataContainer, ...style.profileDataContainer }}>
                  {/* Account name */}
                  <h2 style={{ ...default_style.profileDataContainer.h2, ...style.profileDataContainer?.h2 }}>{insta.business_discovery?.name}</h2>
                  <div style={{ ...default_style.profileFollowsContainer, ...style.profileFollowsContainer }}>
                     {/* Follows and followers */}
                     <p style={{ ...default_style.profileFollowsContainer.p, ...style.profileFollowsContainer?.p }}>Followers: {insta.business_discovery?.followers_count}</p>
                     <p style={{ ...default_style.profileFollowsContainer.p, ...style.profileFollowsContainer?.p }}>Follows: {insta.business_discovery?.follows_count}</p>
                  </div>
               </div>
            </div>
            <div
               style={{ ...default_style.mediaContainer, ...style.mediaContainer }}
            >
               {insta.business_discovery.media.data?.filter((item: any) => item.media_product_type === 'FEED').filter((item: any, idx: number) => idx < limit).map((media: any) => (
                  <div
                     id={`mediaRef-${media?.id}`}
                     key={media?.id}
                     style={{ ...default_style.mediaBox, ...style.mediaBox }}
                     // onMouseEnter={handleMouseEnter}
                     // onMouseLeave={handleMouseLeave}
                  >
                     <a
                        href={media?.permalink}
                        target="_blank"
                        style={{ ...default_style.mediaBox.a, ...style.mediaBox?.a }}
                     >
                        <img id={`media-img-${media?.id}`} src={media?.media_url} alt=""
                           style={{ ...default_style.mediaBox.image, ...style.mediaBox?.image }}
                        />
                        <div id={`overlay-ref-${media?.id}`} style={{ ...default_style.overlay, ...style.overlay }}>
                           <div style={{ ...default_style.overlay.content, ...style.overlay?.content }}>
                              <span style={{ ...default_style.overlay.content.infoRows, ...style.overlay?.content?.infoRows }}>
                                 <TiHeartFullOutline style={{ verticalAlign: 'bottom', fontSize: '25px' }} /> {media?.like_count}
                              </span>
                           </div>
                        </div>
                        {/* <p style={{ margin: '15px', whiteSpace: 'break-spaces' }}>{media?.caption}</p> */}
                     </a>
                  </div>
               ))}
            </div>
         </>
      ) : (
         <p>Loading...</p>
      )}
   </>
}