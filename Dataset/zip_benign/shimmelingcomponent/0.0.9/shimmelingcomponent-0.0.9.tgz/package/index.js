import Shimmering from './src/shimmering';
export default Shimmering;