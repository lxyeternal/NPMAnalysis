/**
 * An immutable canvas pool allowing more efficient use of canvas resources
 *
 * @typedef {Object} CanvasPool
 * @property {Function} pop - return a promise that will evaluate to a canvas
 * @property {Number} length - the number of available canvas elements
 * @property {HTMLCanvasElement[]} elements - the canvas elements used by the pool
 * @property {Function} clear - empty the pool of canvas elements
 * @property {Function} release - free a pool up for release and return the data url
 */
/**
 * Create a CanvasPool with the given size
 *
 * @return {CanvasPool}
 */
export function CanvasPool(): CanvasPool;
/**
 * An immutable canvas pool allowing more efficient use of canvas resources
 */
export type CanvasPool = {
    /**
     * - return a promise that will evaluate to a canvas
     */
    pop: Function;
    /**
     * - the number of available canvas elements
     */
    length: number;
    /**
     * - the canvas elements used by the pool
     */
    elements: HTMLCanvasElement[];
    /**
     * - empty the pool of canvas elements
     */
    clear: Function;
    /**
     * - free a pool up for release and return the data url
     */
    release: Function;
};
export default shared;
declare namespace shared {
    const pop: Function;
    const length: number;
    const elements: HTMLCanvasElement[];
    const clear: Function;
    const release: Function;
}
