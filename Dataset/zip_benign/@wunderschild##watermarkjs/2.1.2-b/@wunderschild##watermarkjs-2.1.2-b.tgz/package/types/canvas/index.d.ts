/**
 * Parameters object for {dataUrl} function.
 *
 * @typedef {Object} DataUrlParameters
 * @property {string | undefined} type Image MIME type
 * @property {any | undefined} quality Image quality
 */
/**
 * Get the data url of a canvas
 *
 * @param {HTMLCanvasElement} canvas
 * @param {DataUrlParameters} parameters
 * @return {String}
 */
export function dataUrl(canvas: HTMLCanvasElement, parameters?: DataUrlParameters): string;
/**
 * Parameters object for {dataUrl} function.
 */
export type DataUrlParameters = {
    /**
     * Image MIME type
     */
    type: string | undefined;
    /**
     * Image quality
     */
    quality: any | undefined;
};
