/**
 * @typedef {(...canvases: HTMLCanvasElement[]) => number} CoordinateGetter
 * @typedef {(...canvases: HTMLCanvasElement[]) => HTMLCanvasElement} ImageDrawer
 */
/**
 * Return a function for positioning a watermark on a target canvas
 *
 * @param {CoordinateGetter} xFn - a function to determine an x value
 * @param {CoordinateGetter} yFn - a function to determine a y value
 * @param {Number} alpha
 * @return {ImageDrawer}
 */
export function atPos(xFn: CoordinateGetter, yFn: CoordinateGetter, alpha: number): ImageDrawer;
/**
 * Place the watermark in the lower right corner of the target
 * image
 *
 * @param {Number} alpha
 * @return {ImageDrawer}
 */
export function lowerRight(alpha: number): ImageDrawer;
/**
 * Place the watermark in the upper right corner of the target
 * image
 *
 * @param {Number} alpha
 * @return {ImageDrawer}
 */
export function upperRight(alpha: number): ImageDrawer;
/**
 * Place the watermark in the lower left corner of the target
 * image
 *
 * @param {Number} alpha
 * @return {ImageDrawer}
 */
export function lowerLeft(alpha: number): ImageDrawer;
/**
 * Place the watermark in the upper left corner of the target
 * image
 *
 * @param {Number} alpha
 * @return {ImageDrawer}
 */
export function upperLeft(alpha: number): ImageDrawer;
/**
 * Place the watermark in the center of the target
 * image
 *
 * @param {Number} alpha
 * @return {ImageDrawer}
 */
export function center(alpha: number): ImageDrawer;
export type CoordinateGetter = (...canvases: HTMLCanvasElement[]) => number;
export type ImageDrawer = (...canvases: HTMLCanvasElement[]) => HTMLCanvasElement;
