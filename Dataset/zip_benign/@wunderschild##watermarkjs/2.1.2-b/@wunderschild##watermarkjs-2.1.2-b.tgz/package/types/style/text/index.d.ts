/**
 * @typedef {(canvas: HTMLCanvasElement, metrics: TextMetrics, context: CanvasRenderingContext2D) => number} CoordinateGetter
 * @typedef {(...canvases: HTMLCanvasElement[]) => HTMLCanvasElement} TextDrawer
 */
/**
 * Return a function for positioning a watermark on a target canvas
 *
 * @param {CoordinateGetter} xFn - a function to determine an x value
 * @param {CoordinateGetter} yFn - a function to determine a y value
 * @param {String} text - the text to write
 * @param {String} font - same as the CSS font property
 * @param {String} fillStyle
 * @param {Number} alpha
 * @return {TextDrawer}
 */
export function atPos(xFn: CoordinateGetter, yFn: CoordinateGetter, text: string, font: string, fillStyle: string, alpha: number): TextDrawer;
/**
 * Write text to the lower right corner of the target canvas
 *
 * @param {String} text - the text to write
 * @param {String} font - same as the CSS font property
 * @param {String} fillStyle
 * @param {Number} alpha - control text transparency
 * @param {Number} y - height in text metrics is not very well supported. This is a manual value
 * @return {TextDrawer}
 */
export function lowerRight(text: string, font: string, fillStyle: string, alpha: number, y: number): TextDrawer;
/**
 * Write text to the lower left corner of the target canvas
 *
 * @param {String} text - the text to write
 * @param {String} font - same as the CSS font property
 * @param {String} fillStyle
 * @param {Number} alpha - control text transparency
 * @param {Number} y - height in text metrics is not very well supported. This is a manual value
 * @return {TextDrawer}
 */
export function lowerLeft(text: string, font: string, fillStyle: string, alpha: number, y: number): TextDrawer;
/**
 * Write text to the upper right corner of the target canvas
 *
 * @param {String} text - the text to write
 * @param {String} font - same as the CSS font property
 * @param {String} fillStyle
 * @param {Number} alpha - control text transparency
 * @param {Number} y - height in text metrics is not very well supported. This is a manual value
 * @return {TextDrawer}
 */
export function upperRight(text: string, font: string, fillStyle: string, alpha: number, y: number): TextDrawer;
/**
 * Write text to the upper left corner of the target canvas
 *
 * @param {String} text - the text to write
 * @param {String} font - same as the CSS font property
 * @param {String} fillStyle
 * @param {Number} alpha - control text transparency
 * @param {Number} y - height in text metrics is not very well supported. This is a manual value
 * @return {TextDrawer}
 */
export function upperLeft(text: string, font: string, fillStyle: string, alpha: number, y: number): TextDrawer;
/**
 * Write text to the center of the target canvas
 *
 * @param {String} text - the text to write
 * @param {String} font - same as the CSS font property
 * @param {String} fillStyle
 * @param {Number} alpha - control text transparency
 * @param {Number} y - height in text metrics is not very well supported. This is a manual value
 * @return {TextDrawer}
 */
export function center(text: string, font: string, fillStyle: string, alpha: number, y: number): TextDrawer;
export type CoordinateGetter = (canvas: HTMLCanvasElement, metrics: TextMetrics, context: CanvasRenderingContext2D) => number;
export type TextDrawer = (...canvases: HTMLCanvasElement[]) => HTMLCanvasElement;
