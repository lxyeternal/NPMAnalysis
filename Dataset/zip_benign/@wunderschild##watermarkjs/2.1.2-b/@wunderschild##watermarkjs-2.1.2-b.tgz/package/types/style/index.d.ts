/**
 * Create a DrawResult by apply a list of canvas elements to a draw function
 *
 * @param {Function} draw - the draw function used to create a DrawResult
 * @param {HTMLCanvasElement[]} sources - the canvases used by the draw function
 * @return {DrawResult}
 */
export function result(draw: Function, sources: HTMLCanvasElement[]): DrawResult;
/**
 * @typedef {Object} DrawResult
 * @property {HTMLCanvasElement} canvas - the end result of a draw
 * @property {HTMLCanvasElement[]} sources - the sources used in the draw
 */
export const image: typeof img;
export const text: typeof txt;
export type DrawResult = {
    /**
     * - the end result of a draw
     */
    canvas: HTMLCanvasElement;
    /**
     * - the sources used in the draw
     */
    sources: HTMLCanvasElement[];
};
import * as img from "./image";
import * as txt from "./text";
