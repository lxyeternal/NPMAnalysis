/**
 * @template T
 * @typedef {Pick<Promise<T>, 'then'>} Thenable
 */
/**
 * @typedef {(...canvases: HTMLCanvasElement[]) => HTMLCanvasElement} Drawer
 */
/**
 * @template T
 * @typedef {Object} Watermark
 * @property {Thenable<T>['then']} then
 * @property {(draw: Drawer) => Thenable<String>} dataUrl
 * @property {(draw: Drawer) => Thenable<Blob>} blob
 * @property {(draw: Drawer) => Thenable<HTMLImageElement>} image
 * @property {(resources: Resource[], init?: Initializer) => Watermark<HTMLImageElement[]>} load
 * @property {() => Watermark<HTMLImageElement[]>} render
 */
/**
 * Return a watermark object
 *
 * @template T
 * @param {Array<Resource>} resources - a collection of urls, File objects, or Image objects
 * @param {Partial<Options>} options - a configuration object for watermark
 * @param {Promise<T> | null} promise - optional
 * @return {Watermark<T>}
 */
declare function watermark<T>(resources: Array<Resource>, options?: Partial<Options>, promise?: Promise<T>): Watermark<T>;
declare namespace watermark {
    const image: typeof import("./style/image");
    const text: typeof import("./style/text");
    /**
     * Clean up all canvas references
     */
    function destroy(): any;
}
export default watermark;
export type Thenable<T> = Pick<Promise<T>, 'then'>;
export type Drawer = (...canvases: HTMLCanvasElement[]) => HTMLCanvasElement;
export type Watermark<T> = {
    then: Thenable<T>['then'];
    dataUrl: (draw: Drawer) => Thenable<string>;
    blob: (draw: Drawer) => Thenable<Blob>;
    image: (draw: Drawer) => Thenable<HTMLImageElement>;
    load: (resources: Resource[], init?: Initializer) => Watermark<HTMLImageElement[]>;
    render: () => Watermark<HTMLImageElement[]>;
};
export type CanvasPool = import('./canvas/pool').CanvasPool;
export type ImageFormat = 'image/png' | 'image/jpeg';
export type Resource = import('./image').Resource;
export type Initializer = import('./image').Initializer;
/**
 * A configuration type for the watermark function
 */
export type Options = {
    /**
     * - an initialization function that is given Image objects before loading (only applies if resources is a collection of urls)
     */
    init: Initializer;
    /**
     * - specify the image format to be used when retrieving result (only supports "image/png" or "image/jpeg", default "image/png")
     */
    type: ImageFormat;
    /**
     * - specify the image compression quality from 0 to 1 (default 0.92)
     */
    encoderOptions: number;
    /**
     * - number of canvas elements available for drawing,
     */
    poolSize?: number | undefined;
    /**
     * - the pool used. If provided, poolSize will be ignored
     */
    pool?: CanvasPool | undefined;
};
