/**
 * @typedef {(res: Resource, init?: Initializer) => Promise<HTMLImageElement>} Loader
 */
/**
 * Given a resource, return an appropriate loading function for it's type
 *
 * @param {Resource} resource
 * @return {Loader}
 */
export function getLoader(resource: Resource): Loader;
/**
 * Used for loading image resources asynchronously and maintaining
 * the supplied order of arguments
 *
 * @param {Array<Resource>} resources - a mixed array of urls, File objects, or Image objects
 * @param {Initializer=} init - called at the beginning of resource initialization
 * @return {Promise<HTMLImageElement[]>}
 */
export function load(resources: Array<Resource>, init?: Initializer | undefined): Promise<HTMLImageElement[]>;
/**
 * Load an image by its url
 *
 * @param {String} url
 * @param {Function} init - an optional image initializer
 * @return {Promise<HTMLImageElement>}
 */
export function loadUrl(url: string, init: Function): Promise<HTMLImageElement>;
/**
 * Return a collection of images from an
 * array of File objects
 *
 * @param {File} file
 * @return {Promise<HTMLImageElement>}
 */
export function loadFile(file: File): Promise<HTMLImageElement>;
/**
 * Create a new image, optionally configuring its onload behavior
 *
 * @param {String} url
 * @param {((...args: any[]) => any)=} onload
 * @return {HTMLImageElement}
 */
export function createImage(url: string, onload?: (...args: any[]) => any): HTMLImageElement;
/**
 * Convert an Image object to a canvas
 *
 * @param {HTMLImageElement} img
 * @param {CanvasPool} pool
 * @return {HTMLCanvasElement}
 */
export function imageToCanvas(img: HTMLImageElement, pool: CanvasPool): HTMLCanvasElement;
/**
 * Convert an array of image objects
 * to canvas elements
 *
 * @param {HTMLImageElement[]} images
 * @param {CanvasPool} pool
 * @return {HTMLCanvasElement[]}
 */
export function mapToCanvas(images: HTMLImageElement[], pool: CanvasPool): HTMLCanvasElement[];
export type Resource = string | Blob | HTMLImageElement;
export type CanvasPool = import('../canvas/pool').CanvasPool;
export type Initializer = (img: HTMLImageElement) => unknown;
export type Loader = (res: Resource, init?: Initializer) => Promise<HTMLImageElement>;
