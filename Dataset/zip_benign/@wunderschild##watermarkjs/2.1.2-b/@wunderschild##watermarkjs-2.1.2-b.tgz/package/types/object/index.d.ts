/**
 * Extend one object with the properties of another
 *
 * @template {{}} T
 * @template {{}} K
 * @param {T} first
 * @param {K} second
 * @return {T & K}
 */
export function extend<T extends {}, K extends {}>(first: T, second: K): T & K;
/**
 * Create a shallow copy of the object
 *
 * @param {Object} obj
 * @return {Object}
 */
export function clone(obj: any): any;
