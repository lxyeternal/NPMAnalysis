/**
 * Split a data url into a content type and raw data
 *
 * @param {String} dataUrl
 * @return {Array<String> | null}
 */
export function split(dataUrl: string): Array<string> | null;
/**
 * Decode a base64 string
 *
 * @param {String} base64
 * @return {String}
 */
export function decode(base64: string): string;
/**
 * Return a string of raw data as a Uint8Array
 *
 * @param {String} data
 * @return {Uint8Array}
 */
export function uint8(data: string): Uint8Array;
export function blob(str: string): Blob;
