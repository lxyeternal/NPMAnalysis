import * as $internal from "@winglang/sdk/lib/core/types"
import { std } from "@winglang/sdk"
import * as b from "./preflight.api-1.cjs";
import { aws } from "@winglang/sdk"
export class Model_tfaws extends std.Resource implements b.IModel
{
  constructor(scope: $internal.Construct, id: string, modelId: string);
  [$internal.INFLIGHT_SYMBOL]?: Model_tfaws$Inflight;
  modelId: string;
  onLift: (host: std.IInflightHost, ops: (readonly (string)[])) => void;
}
export class Model_tfaws$Inflight implements b.IModel$Inflight
{
  constructor(modelId: string);
  invoke: (body: Readonly<$internal.Json>) => Promise<Readonly<$internal.Json>>;
}