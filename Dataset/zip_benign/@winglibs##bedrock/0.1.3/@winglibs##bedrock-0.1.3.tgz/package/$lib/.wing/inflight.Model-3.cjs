"use strict";
const $helpers = require("@winglang/sdk/lib/helpers");
const $macros = require("@winglang/sdk/lib/macros");
module.exports = function({  }) {
  class Model {
    constructor($args) {
      const { $this_inner } = $args;
      this.$this_inner = $this_inner;
    }
    async invoke(body) {
      return (await this.$this_inner.invoke(body));
    }
  }
  return Model;
}
//# sourceMappingURL=inflight.Model-3.cjs.map