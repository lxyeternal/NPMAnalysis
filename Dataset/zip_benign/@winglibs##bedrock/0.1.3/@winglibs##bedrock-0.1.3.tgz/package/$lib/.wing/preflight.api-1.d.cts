import * as $internal from "@winglang/sdk/lib/core/types"
import { std } from "@winglang/sdk"
export interface IModel
{
}
export interface IModel$Inflight
{
  readonly invoke: (body: Readonly<$internal.Json>) => Promise<Readonly<$internal.Json>>;
}