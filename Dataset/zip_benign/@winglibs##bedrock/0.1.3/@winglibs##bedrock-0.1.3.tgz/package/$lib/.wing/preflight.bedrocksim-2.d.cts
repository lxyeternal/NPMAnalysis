import * as $internal from "@winglang/sdk/lib/core/types"
import { std } from "@winglang/sdk"
import * as b from "./preflight.api-1.cjs";
export class Model_sim extends std.Resource implements b.IModel
{
  constructor(scope: $internal.Construct, id: string, modelId: string);
  [$internal.INFLIGHT_SYMBOL]?: Model_sim$Inflight;
  setMockResponse: (fn: $internal.Inflight<(arg0: Readonly<$internal.Json>) => Promise<Readonly<$internal.Json>>>) => void;
}
export class Model_sim$Inflight implements b.IModel$Inflight
{
  constructor(modelId: string);
  invoke: (body: Readonly<$internal.Json>) => Promise<Readonly<$internal.Json>>;
}