"use strict";
const $stdlib = require('@winglang/sdk');
const $macros = require("@winglang/sdk/lib/macros");
const std = $stdlib.std;
const $helpers = $stdlib.helpers;
const $extern = $helpers.createExternRequire(__dirname);
const $types = require("./types.cjs");
let $preflightTypesMap = {};
const bedrock = $helpers.bringJs(`${__dirname}/preflight.bedrock-4.cjs`, $preflightTypesMap);
class JokeMaker extends $stdlib.std.Resource {
  constructor($scope, $id, ) {
    super($scope, $id);
    this.claud = globalThis.$ClassFactory.new("@winglibs/bedrock.Model", bedrock.Model, this, "claude", "anthropic.claude-v2");
  }
  static _toInflightType() {
    return `
      require("${$helpers.normalPath(__dirname)}/inflight.JokeMaker-4.cjs")({
      })
    `;
  }
  _liftedState() {
    return {
      ...(super._liftedState?.() ?? {}),
      $this_claud: $stdlib.core.liftObject(this.claud),
    };
  }
  get _liftMap() {
    return ({
      "makeJoke": [
        [this.claud, ["invoke"]],
      ],
      "$inflight_init": [
        [this.claud, []],
      ],
    });
  }
}
module.exports = { $preflightTypesMap, JokeMaker };
//# sourceMappingURL=preflight.joke-5.cjs.map