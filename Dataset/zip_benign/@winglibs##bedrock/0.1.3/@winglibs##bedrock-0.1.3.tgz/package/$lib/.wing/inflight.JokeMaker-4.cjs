"use strict";
const $helpers = require("@winglang/sdk/lib/helpers");
const $macros = require("@winglang/sdk/lib/macros");
module.exports = function({  }) {
  class JokeMaker {
    constructor($args) {
      const { $this_claud } = $args;
      this.$this_claud = $this_claud;
    }
    async makeJoke(topic) {
      const res = (await this.$this_claud.invoke(({"prompt": String.raw({ raw: ["\n\nHuman: Tell me a joke about ", "\n\nAssistant:"] }, topic), "max_tokens_to_sample": 300, "temperature": 0.5, "top_k": 250, "top_p": 1, "stop_sequences": ["\n\nHuman:"], "anthropic_version": "bedrock-2023-05-31"})));
      return $macros.__Json_asStr(false, $helpers.lookup(res, "completion"), );
    }
  }
  return JokeMaker;
}
//# sourceMappingURL=inflight.JokeMaker-4.cjs.map