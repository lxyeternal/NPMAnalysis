"use strict";
const $stdlib = require('@winglang/sdk');
const $macros = require("@winglang/sdk/lib/macros");
const std = $stdlib.std;
const $helpers = $stdlib.helpers;
const $extern = $helpers.createExternRequire(__dirname);
const $types = require("./types.cjs");
let $preflightTypesMap = {};
const b = $helpers.bringJs(`${__dirname}/preflight.api-1.cjs`, $preflightTypesMap);
class Model_sim extends $stdlib.std.Resource {
  constructor($scope, $id, modelId) {
    super($scope, $id);
    this.modelId = modelId;
    const __parent_this_1 = this;
    class $Closure1 extends $stdlib.std.AutoIdResource {
      _id = $stdlib.core.closureId();
      constructor($scope, $id, ) {
        super($scope, $id);
        $helpers.nodeof(this).hidden = true;
      }
      static _toInflightType() {
        return `
          require("${$helpers.normalPath(__dirname)}/inflight.$Closure1-1.cjs")({
            $__parent_this_1_modelId: ${$stdlib.core.liftObject(__parent_this_1.modelId)},
          })
        `;
      }
      get _liftMap() {
        return ({
          "handle": [
            [__parent_this_1.modelId, []],
          ],
          "$inflight_init": [
            [__parent_this_1.modelId, []],
          ],
        });
      }
    }
    this.mockResponse = new $Closure1(this, "$Closure1");
  }
  setMockResponse(fn) {
    this.mockResponse = fn;
  }
  static _toInflightType() {
    return `
      require("${$helpers.normalPath(__dirname)}/inflight.Model_sim-1.cjs")({
      })
    `;
  }
  _liftedState() {
    return {
      ...(super._liftedState?.() ?? {}),
      $this_mockResponse: $stdlib.core.liftObject(this.mockResponse),
    };
  }
  get _liftMap() {
    return ({
      "invoke": [
        [this.mockResponse, ["handle"]],
      ],
      "$inflight_init": [
        [this.mockResponse, []],
      ],
    });
  }
}
module.exports = { $preflightTypesMap, Model_sim };
//# sourceMappingURL=preflight.bedrocksim-2.cjs.map