"use strict";
const $helpers = require("@winglang/sdk/lib/helpers");
const $macros = require("@winglang/sdk/lib/macros");
module.exports = function({  }) {
  class Model_tfaws {
    constructor($args) {
      const { $this_modelId } = $args;
      this.$this_modelId = $this_modelId;
    }
    async invoke(body) {
      return (await Model_tfaws._invokeModel(({"modelId": this.$this_modelId, "body": body})));
    }
    static async _invokeModel(req) {
      return (require("../../bedrock.js")["_invokeModel"])(req)
    }
  }
  return Model_tfaws;
}
//# sourceMappingURL=inflight.Model_tfaws-2.cjs.map