import * as $internal from "@winglang/sdk/lib/core/types"
import { std } from "@winglang/sdk"
import { aws } from "@winglang/sdk"
import { util } from "@winglang/sdk"
import * as a from "./preflight.api-1.cjs";
import * as s from "./preflight.bedrocksim-2.cjs";
import * as t from "./preflight.bedrocktfaws-3.cjs";
export class Model extends std.Resource implements a.IModel
{
  constructor(scope: $internal.Construct, id: string, modelId: string);
  [$internal.INFLIGHT_SYMBOL]?: Model$Inflight;
  modelId: string;
}
export class Model$Inflight implements a.IModel$Inflight
{
  constructor(modelId: string);
  invoke: (body: Readonly<$internal.Json>) => Promise<Readonly<$internal.Json>>;
}