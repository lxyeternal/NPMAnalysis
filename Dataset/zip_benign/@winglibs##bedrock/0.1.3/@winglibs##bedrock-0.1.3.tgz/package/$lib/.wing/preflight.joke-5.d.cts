import * as $internal from "@winglang/sdk/lib/core/types"
import { std } from "@winglang/sdk"
import * as bedrock from "./preflight.bedrock-4.cjs";
export class JokeMaker extends std.Resource
{
  constructor(scope: $internal.Construct, id: string);
  [$internal.INFLIGHT_SYMBOL]?: JokeMaker$Inflight;
}
export class JokeMaker$Inflight
{
  constructor();
  makeJoke: (topic: string) => Promise<string>;
}