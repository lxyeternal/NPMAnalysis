"use strict";
const $stdlib = require('@winglang/sdk');
const $macros = require("@winglang/sdk/lib/macros");
const std = $stdlib.std;
const $helpers = $stdlib.helpers;
const $extern = $helpers.createExternRequire(__dirname);
const $types = require("./types.cjs");
let $preflightTypesMap = {};
const b = $helpers.bringJs(`${__dirname}/preflight.api-1.cjs`, $preflightTypesMap);
const aws = $stdlib.aws;
class Model_tfaws extends $stdlib.std.Resource {
  constructor($scope, $id, modelId) {
    super($scope, $id);
    this.modelId = modelId;
  }
  onLift(host, ops) {
    {
      const $if_let_value = (aws.Function.from(host));
      if ($if_let_value != undefined) {
        const lambda = $if_let_value;
        (lambda.addPolicyStatements(({"actions": ["bedrock:InvokeModel"], "effect": aws.Effect.ALLOW, "resources": [String.raw({ raw: ["arn:aws:bedrock:*::foundation-model/", ""] }, this.modelId)]})));
      }
    }
  }
  static _toInflightType() {
    return `
      require("${$helpers.normalPath(__dirname)}/inflight.Model_tfaws-2.cjs")({
      })
    `;
  }
  _liftedState() {
    return {
      ...(super._liftedState?.() ?? {}),
      $this_modelId: $stdlib.core.liftObject(this.modelId),
    };
  }
  get _liftMap() {
    return ({
      "invoke": [
        [Model_tfaws, ["_invokeModel"]],
        [this.modelId, []],
      ],
      "$inflight_init": [
        [Model_tfaws, []],
        [this.modelId, []],
      ],
    });
  }
  static get _liftTypeMap() {
    return ({
      "_invokeModel": [
      ],
    });
  }
}
module.exports = { $preflightTypesMap, Model_tfaws };
//# sourceMappingURL=preflight.bedrocktfaws-3.cjs.map