"use strict";
const $helpers = require("@winglang/sdk/lib/helpers");
const $macros = require("@winglang/sdk/lib/macros");
module.exports = function({  }) {
  class Model_sim {
    constructor($args) {
      const { $this_mockResponse } = $args;
      this.$this_mockResponse = $this_mockResponse;
    }
    async invoke(body) {
      return (await this.$this_mockResponse(body));
    }
  }
  return Model_sim;
}
//# sourceMappingURL=inflight.Model_sim-1.cjs.map