"use strict";
const $stdlib = require('@winglang/sdk');
const $macros = require("@winglang/sdk/lib/macros");
const std = $stdlib.std;
const $helpers = $stdlib.helpers;
const $extern = $helpers.createExternRequire(__dirname);
const $types = require("./types.cjs");
let $preflightTypesMap = {};
const aws = $stdlib.aws;
const util = $stdlib.util;
const a = $helpers.bringJs(`${__dirname}/preflight.api-1.cjs`, $preflightTypesMap);
const s = $helpers.bringJs(`${__dirname}/preflight.bedrocksim-2.cjs`, $preflightTypesMap);
const t = $helpers.bringJs(`${__dirname}/preflight.bedrocktfaws-3.cjs`, $preflightTypesMap);
class Model extends $stdlib.std.Resource {
  constructor($scope, $id, modelId) {
    super($scope, $id);
    this.modelId = modelId;
    const target = (util.Util.env("WING_TARGET"));
    if ($helpers.eq(target, "sim")) {
      if ($helpers.nodeof(this).app.isTestEnvironment) {
        this.inner = new s.Model_sim(this, "sim", modelId);
      }
      else {
        this.inner = new t.Model_tfaws(this, "tf-aws", modelId);
      }
    }
    else if ($helpers.eq(target, "tf-aws")) {
      this.inner = new t.Model_tfaws(this, "tf-aws", modelId);
    }
    else {
      throw new Error(String.raw({ raw: ["Unsupported target ", ""] }, target));
    }
  }
  static _toInflightType() {
    return `
      require("${$helpers.normalPath(__dirname)}/inflight.Model-3.cjs")({
      })
    `;
  }
  _liftedState() {
    return {
      ...(super._liftedState?.() ?? {}),
      $this_inner: $stdlib.core.liftObject(this.inner),
    };
  }
  get _liftMap() {
    return ({
      "invoke": [
        [this.inner, ["invoke"]],
      ],
      "$inflight_init": [
        [this.inner, []],
      ],
    });
  }
}
module.exports = { $preflightTypesMap, Model };
//# sourceMappingURL=preflight.bedrock-4.cjs.map