import {readyPromise, pomelo} from '../src/index'

describe('pomelo', () => {
  const host = '182.92.5.50'
  const port = 13331

  describe('init', () => {
    let loading = false
    let loadingInCallback = false
    before(() => {
      return pomelo.init({host, port}, () => loadingInCallback = true)
        .then(() => loading = true)
    })

    it('the promise of pomelo.init should work', () => {
      expect(loading).toBe(true)
    })

    it('the callback of pomelo.init should also work', () => {
      expect(loadingInCallback).toBe(true)
    })
  })

  describe('request', () => {
    let response
    let requestedInCallback = false
    before(() => {
      return pomelo.request('connector.entryHandler.hello', {uid: 'cress'}, () => requestedInCallback = true)
        .then(res => response = res)
    })

    it('the request method should work', () => {
      expect(response).toInclude({"dataFromClient":{"uid":"cress"},"dataFromServer":"world"})
    })

    it('the callback of pomelo.request should also work', () => {
      expect(requestedInCallback).toBe(true)
    })

  })

})
