/**
 * replace localized number to Arabic numerals
 * @param text
 */
declare function replaceNumber(text: string): string;
/**
 * extract number from text
 * @param text raw text
 * @param convert whether convert Arabic numerals to localize number
 */
declare function extractNumber(text: string, convert?: boolean): Array<number>;
export { extractNumber, replaceNumber };
export * from "./src/extract";
export * from "./src/localize";
