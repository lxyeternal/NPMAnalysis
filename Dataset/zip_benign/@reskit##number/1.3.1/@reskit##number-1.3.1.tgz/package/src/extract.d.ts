interface ILocalizedRegexp {
    localRegexp: RegExp;
    unitRegexp: RegExp;
    numberRegexp: RegExp;
    mixedNumberRegexp: RegExp;
    localNumberRegexp: RegExp;
    localDecimalRegexp: RegExp;
    localFractionRegexp: RegExp;
    localNegativeRegexp: RegExp;
    mixedRegexp: RegExp;
}
interface ILocalizedData {
    unit: Record<string, number>;
    localNumber: Record<string, number>;
    numberLocal: Record<number, string>;
    decimalFlag: string;
    regexp: ILocalizedRegexp;
}
interface ILocalizedAlgorithm {
    toNumber: (text: string) => number;
    toLocalized: (num: number | string) => string;
}
declare function updateLocalizedData(_data: ILocalizedData): void;
declare function updateLocalizedAlgorithm(_algorithm: ILocalizedAlgorithm): void;
declare function updateLocalized(_data?: ILocalizedData, _algorithm?: ILocalizedAlgorithm): void;
declare function replaceLocalDecimal(text: string): string;
declare function replaceLocalFraction(text: string): string;
declare function replaceMixed(text: string): string;
declare function toFullNumber(text: string): string;
declare function toFullLocalized(text: string): string;
export { toFullNumber, replaceLocalDecimal, replaceLocalFraction, replaceMixed, toFullLocalized, updateLocalized, updateLocalizedData, updateLocalizedAlgorithm, };
