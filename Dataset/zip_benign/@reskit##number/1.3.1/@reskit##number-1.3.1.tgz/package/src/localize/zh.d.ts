declare const zhLocalize: {
    localNumber: Record<string, number>;
    numberLocal: Record<number, string>;
    unit: Record<string, number>;
    decimalFlag: string;
};
declare function createZhRegexp(): {
    localRegexp: RegExp;
    unitRegexp: RegExp;
    numberRegexp: RegExp;
    mixedNumberRegexp: RegExp;
    localNumberRegexp: RegExp;
    localDecimalRegexp: RegExp;
    localFractionRegexp: RegExp;
    localNegativeRegexp: RegExp;
    mixedRegexp: RegExp;
};
/**
 * convert number-text to text
 * @param text raw text
 * @returns number
 */
declare function toNumber(text: string): number;
declare function toLocalized(num: number | string): string;
declare const zhAlgorithm: {
    toNumber: typeof toNumber;
    toLocalized: typeof toLocalized;
};
export { zhLocalize, zhAlgorithm };
export { createZhRegexp };
