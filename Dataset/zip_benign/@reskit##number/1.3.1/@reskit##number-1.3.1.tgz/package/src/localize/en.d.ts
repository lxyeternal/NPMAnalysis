declare const enLocalize: {
    num: {
        One: number;
        Two: number;
        Three: number;
        Four: number;
        Five: number;
        Six: number;
        Seven: number;
        Eight: number;
        Nine: number;
        Zero: number;
        Half: number;
    };
    unit: {
        Ten: number;
        Hundred: number;
        Thousand: number;
        Million: number;
        Billion: number;
    };
    flag: string;
};
export { enLocalize };
