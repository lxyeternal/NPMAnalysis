var gulp = require('gulp');
var uglify = require('gulp-uglify');
var concat = require('gulp-concat');
var jshint = require('gulp-jshint');
var jslint = require('gulp-jslint');
var watch = require('gulp-watch');
var tape = require('gulp-tape');
var prettify = require('gulp-jsbeautifier');

var tapColorize = require('tap-colorize');
var exec = require('child_process').exec;
var map = require('map-stream');
var browserify = require('browserify');
var source = require('vinyl-source-stream');
var buffer = require('vinyl-buffer');


gulp.task('beautify', function() {
  return gulp.src('./src/js/*.js')
    .pipe(prettify({config: '.jsbeautifyrc', mode: 'VERIFY_AND_WRITE'}))
    .pipe(gulp.dest('./src/js/'));
});

gulp.task('lint', function() {
  return gulp.src('./src/js/*.js')
    .pipe(jshint())
    .pipe(jshint.reporter('jshint-stylish'))
});

gulp.task('test', function() {
  return gulp.src('tests/*.js')
    .pipe(tape({
      reporter: tapColorize()
    }));
});

gulp.task('compile-templates', function (cb) {
  exec('./node_modules/.bin/dottojs  -s src/js/views/ -d src/js/views/', function (err, stdout, stderr) {
    console.log(stdout);
    console.log(stderr);
    cb(err);
  });
})


gulp.task('website', gulp.series('compile-templates', 'test', 'lint'), function() {
    return browserify('./src/js/website.js')
        .bundle().on('error', function(e){
            console.log(e);
         })
        .pipe(source('website.js')).on('error', function(e){
            console.log(e);
         })
        .pipe(jshint()).on('error', function(e){
            console.log(e);
         })
        .pipe(jshint.reporter('default')).on('error', function(e){
            console.log(e);
         })
        .pipe(gulp.dest('./dist/'));
});

gulp.task('compress-website', gulp.series('compile-templates', 'test'), function() {
    return browserify('./src/js/website.js')
        .bundle()
        .pipe(source('website.min.js'))
        .pipe(buffer()) 
        .pipe(uglify({output: {ascii_only:true}}))
        .pipe(gulp.dest('./dist/'));
});


gulp.task('default', gulp.series('compile-templates', 'website', 'compress-website'));

gulp.task("watch", gulp.series('beautify'), function() {
    watch(['src/js/*', 'tests/*'], function() {
        gulp.start("default");
    });
});
