

/*
 *  Make sure array keys are unique
 */
function uniq_fast(a) {
    var seen = {};
    var out = [];
    var len = a.length;
    for(var i = len-1; i > 0; i--) {
         var item = a[i];
         if(seen[item] !== 1) {
               seen[item] = 1;
               out.unshift(item);
         }
    }
    return out;
}

module.exports = uniq_fast;