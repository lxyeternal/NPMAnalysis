var Base64 = require('js-base64').Base64;

/**
 * Encoder constructor
 */
function encoder(options) {
	options = options || {};
	for (var o in options) {
		this[o] = options[o];
	}
	
}

/**
 * Encoder prototype methods
 */
encoder.prototype = {

	encode : function(obj) {
		var d = JSON.stringify(obj);
		var e = Base64.encode(d);
		return e;
	},

	decode : function(str) {
		var d = Base64.decode(str);
		var e = JSON.parse(d);
		return e;
	}

}

module.exports = encoder;