
var unique = require("../src/js/utils/unique");
var test = require('tape');

var arr = ["one", "two", "three", "one"];


// Run tests
// Note: New objects are pushed on to the end of the array
// so we want the most unique element towards the end, not the start
test('Unique function', function (t) {
    
	var uArr = unique(arr);

    t.equal(uArr[0], "two");
    t.equal(uArr[1], "three");
    t.equal(uArr[2], "one");
    t.equal(uArr.length, 3);

    t.end();
});
