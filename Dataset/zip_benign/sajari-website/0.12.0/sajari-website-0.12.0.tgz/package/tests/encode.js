
var encoder = require("../src/js/utils/encode");
var e = new encoder();
var test = require('tape');

var query = {
	'q': 'whatever',
    't': 'that'
}


// Run tests
test('Encode - decode', function (t) {
    var enc = e.encode(query);
    var dec = e.decode(enc);

    t.equal(query.q, dec.q);
    t.equal(query.t, dec.t);
    
    t.end();
});


