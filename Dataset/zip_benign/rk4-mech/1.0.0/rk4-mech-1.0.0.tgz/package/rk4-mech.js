// p0: [Number], v0: [Number], aFunc: function (p,v) { ... return [Number] }, dt: Number
let rk4 = function (p0, v0, aFunc, dt, p = p0, v = v0) {
  function vecAdd (a1, a2, aRes = []) {
    for (let i = 0; i < a1.length; i++) aRes[i] = a1[i] + a2[i]
    return aRes
  }
  function vecMul (a, n, aRes = []) {
    for (let i = 0; i < a.length; i++) aRes[i] = a[i] * n
    return aRes
  }
  function eul (v, a, dt_, vNew) { // Euler method for given v and a
    let p = vecMul(v, dt_); vecAdd(p0, p, p)     // p=p0+v*dt
    vecMul(a, dt_, vNew); vecAdd(v0, vNew, vNew) // v=v0+a*dt
    return aFunc(p, v)                           // a=f(p, v)
  }

  let v1 = []; let v2 = []; let v3 = []
  let a0 = aFunc(p0, v0)
  let a1 = eul(v0, a0, dt / 2, v1)  // call Euler method 3 times
  let a2 = eul(v1, a1, dt / 2, v2)
  let a3 = eul(v2, a2, dt, v3)

  vecAdd(v1, v2, v1); vecMul(v1, 2, v1)
  vecAdd(v0, v3, v3); vecAdd(v1, v3, v3)
  vecMul(v3, 1 / 6, v3) // v=(v0+2*v1+2*v2+v3)/(1+2+2+1)
  vecAdd(a1, a2, a1); vecMul(a1, 2, a1)
  vecAdd(a0, a3, a3); vecAdd(a1, a3, a3)
  vecMul(a3, 1 / 6, a3) // a=(a0+2*a1+2*a2+a3)/(1+2+2+1)

  vecMul(v3, dt, v2); vecAdd(p0, v2, p) // p=p0+v*dt
  vecMul(a3, dt, a2); vecAdd(v0, a2, v) // v=v0+a*dt
}

if (this.window && this === window) this.rk4 = rk4
else module.exports = rk4
