/* global describe, it */
const chai = require('chai')
const expect = chai.expect

const path = require('path')
const rk4 = require('..')

describe('Single iteration', () => {
  it('rk4([0], [0], (v,p) => [1], 1, p, v), resulting v is [1]', () => {
    let p = []
    let v = []
    let a  = (p, v) => [1]
    rk4([0], [0], a, 1, p, v)
    expect(v).to.deep.equal([1])
  })
  it('rk4([0], [0], (v,p) => [1], 1, p, v), resulting p is [1/2]', () => {
    let p = []
    let v = []
    let a  = (p, v) => [1]
    rk4([0], [0], a, 1, p, v)
    expect(p).to.deep.equal([1/2])
  })
})

describe('Mass spring system', () => {
  it('Oscillation period T ~= 2*pi*sqrt(m/k)', () => {
    let t = 0
    let dt = 0.01
    let m = 10
    let l0 = 1
    let k = 2
    let p = [0.5]
    let v = [0]
    let a = (p, v) => [(l0 - p[0])*k / m]
    while (v[0] >= 0) {
      t += dt
      rk4(p, v, a, dt)
    }
    console.log('    expected T/2: ' + (Math.PI * Math.sqrt(m/k)) + ', actual: ' + t)
    expect(t * 2).to.be.closeTo(2 * Math.PI * Math.sqrt(m/k), dt*2)
  })
})
