# `@lucia-auth/adapter-supabase`

[Supabase](https://supabase.com) adapter for Lucia

**[Documentation](https://lucia-auth.vercel.app/learn/adapters/supabase)**

**[Lucia documentation](https://lucia-auth.vercel.app)**

**[Changelog](https://github.com/pilcrowOnPaper/lucia-auth/blob/main/packages/adapter-supabase/CHANGELOG.md)**

## Installation

```
npm install @lucia-auth/adapter-supabase
```

## Lucia version compatibility

| Supabase adapter version | Lucia version |
| ------------------------ | ------------- |
| 0.1.x                    | 0.1.x ~ 0.3.x |
| 0.2.x                    | 0.4.x         |
| 0.3.x                    | 0.5.x         |

## Testing

Add a postgresql database url to `.env`.

```
npm run test
```
