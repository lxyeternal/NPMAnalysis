import type { Adapter, AdapterFunction } from "lucia-auth";
declare const adapter: (url: string, secret: string) => AdapterFunction<Adapter>;
export default adapter;
