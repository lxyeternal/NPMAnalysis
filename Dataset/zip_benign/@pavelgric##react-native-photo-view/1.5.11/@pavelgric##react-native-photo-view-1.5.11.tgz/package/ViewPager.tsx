import React from 'react';
import {requireNativeComponent} from 'react-native';
import ViewPager from 'react-native-pager-view';
const VIEWPAGER_REF = 'viewPager';

export class ViewPagerZoom extends ViewPager {
  render() {
    return (
      <NativeAndroidViewPager
        {...this.props}
        ref={VIEWPAGER_REF}
        // style={this.props.style}
        // onPageScroll={this._onPageScroll}
        // onPageScrollStateChanged={this._onPageScrollStateChanged}
        // onPageSelected={this._onPageSelected}
        // children={this._childrenWithOverridenStyle()}
      />
    );
  }
}

const NativeAndroidViewPager = requireNativeComponent('ViewPagerZoom');
