import React, { Component } from 'react';
import { Animated, StyleProp, ViewStyle, ScrollView, NativeSyntheticEvent, NativeScrollEvent, LayoutChangeEvent, TextStyle, ScrollViewProps } from 'react-native';
import { ViewPagerZoom } from '../ViewPager';
import { PagerViewProps, PagerViewOnPageScrollEvent, PagerViewOnPageSelectedEvent } from 'react-native-pager-view';
import { TabBarProps } from './DefaultTabBar';
import { ScrollableTabBar } from './ScrollableTabBar';
type Child = React.ReactElement<{
    tabLabel: string;
}>;
type Props = {
    tabBarPosition: 'top' | 'bottom' | 'overlayTop' | 'overlayBottom';
    initialPage: number;
    page: number;
    onChangeTab: (p: {
        i: number;
        ref: any;
        from: number;
    }) => void;
    onScroll: (v: number) => void;
    renderTabBar: ((p: TabBarProps) => React.ReactElement) | false;
    style: StyleProp<ViewStyle>;
    contentProps: Omit<ScrollViewProps, 'children'> & Omit<PagerViewProps, 'children'>;
    scrollWithoutAnimation: boolean;
    locked: boolean;
    prerenderingSiblingsNumber: number;
    children: Child;
    tabBarBackgroundColor?: string;
    tabBarActiveTextColor?: string;
    tabBarInactiveTextColor?: string;
    tabBarTextStyle?: StyleProp<TextStyle>;
    tabBarUnderlineStyle?: StyleProp<ViewStyle>;
};
type State = {
    currentPage: number;
    containerWidth: number;
    scrollXIOS: Animated.Value;
    positionAndroid: Animated.Value;
    offsetAndroid: Animated.Value;
    scrollValue: Animated.AnimatedDivision<string | number> | Animated.AnimatedAddition<string | number>;
    sceneKeys: string[];
};
export declare class ScrollableTabView extends Component<Props, State> {
    statics: {
        DefaultTabBar: (props: TabBarProps) => React.JSX.Element;
        ScrollableTabBar: typeof ScrollableTabBar;
    };
    scrollOnMountCalled: boolean;
    static defaultProps: Partial<Props>;
    scrollView: React.RefObject<ScrollView>;
    viewPager: React.RefObject<ViewPagerZoom>;
    constructor(props: Props);
    getInitialState(): State;
    UNSAFE_componentWillReceiveProps(props: Props): void;
    componentWillUnmount(): void;
    goToPage: (pageNumber: number) => void;
    renderTabBar: (props: TabBarProps) => React.JSX.Element | null;
    updateSceneKeys: ({ page, children, callback, }: {
        page: number;
        children?: Child | undefined;
        callback?: (() => void) | undefined;
    }) => void;
    newSceneKeys: ({ previousKeys, currentPage, children, }: {
        previousKeys?: string[] | undefined;
        currentPage?: number | undefined;
        children?: Child | undefined;
    }) => string[];
    _polyfillAnimatedValue: (animatedValue: Animated.Value | Animated.AnimatedDivision<string | number>) => (value: any) => void;
    _shouldRenderSceneKey: (idx: number, currentPageKey: number) => boolean;
    _keyExists: (sceneKeys: string[], key: string) => string | undefined;
    _makeSceneKey: (child: any, idx: number) => string;
    renderScrollableContent: () => React.JSX.Element | undefined;
    _composeScenes: () => React.JSX.Element[];
    _onMomentumScrollBeginAndEnd: (e: NativeSyntheticEvent<NativeScrollEvent>) => void;
    _updateSelectedPage: (nextPage: number | PagerViewOnPageSelectedEvent) => void;
    _onChangeTab: (prevPage: number, currentPage: number) => void;
    _onScroll: (e: NativeSyntheticEvent<NativeScrollEvent> | PagerViewOnPageScrollEvent) => void;
    _handleLayout: (e: LayoutChangeEvent) => void;
    _children: (children?: Child) => Child[];
    render(): React.JSX.Element;
}
export {};
