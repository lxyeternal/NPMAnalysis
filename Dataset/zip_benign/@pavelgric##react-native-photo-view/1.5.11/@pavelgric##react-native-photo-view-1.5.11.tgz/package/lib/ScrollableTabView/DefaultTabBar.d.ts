import React from 'react';
import { Animated, StyleProp, TextStyle, ViewStyle } from 'react-native';
export type TabBarProps = {
    goToPage: (pageNumber: number) => void;
    activeTab: number;
    tabs: Array<string>;
    containerWidth: number;
    scrollValue: Animated.Value | Animated.AnimatedDivision<string | number> | Animated.AnimatedAddition<string | number>;
    backgroundColor?: string;
    activeTextColor?: string;
    inactiveTextColor?: string;
    style?: StyleProp<ViewStyle>;
    textStyle?: StyleProp<TextStyle>;
    tabStyle?: StyleProp<ViewStyle>;
    renderTab?: (name: string, page: number, isTabActive: boolean, onPressHandler: (page: number) => void) => React.ReactNode;
    underlineStyle?: StyleProp<ViewStyle>;
};
export declare const DefaultTabBar: (props: TabBarProps) => React.JSX.Element;
