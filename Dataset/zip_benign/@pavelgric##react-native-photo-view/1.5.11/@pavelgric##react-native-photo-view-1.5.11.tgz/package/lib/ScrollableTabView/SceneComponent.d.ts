import { ViewProps } from 'react-native';
import React from 'react';
type Props = {
    shouldUpdated: boolean;
} & ViewProps;
export declare const SceneComponent: (Props: Props) => React.JSX.Element;
export {};
