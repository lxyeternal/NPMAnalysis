import React, { Component } from 'react';
type Props = {
    children: React.ReactNode | boolean;
    shouldUpdate: boolean;
};
export declare class StaticContainer extends Component<Props> {
    shouldComponentUpdate(nextProps: Props): boolean;
    render(): string | number | React.ReactElement<any, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | null | undefined;
}
export {};
