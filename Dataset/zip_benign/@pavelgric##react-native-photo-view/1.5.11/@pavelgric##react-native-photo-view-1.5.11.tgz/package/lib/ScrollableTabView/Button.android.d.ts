import React from 'react';
import { TouchableNativeFeedbackProps } from 'react-native';
export declare const Button: (props: TouchableNativeFeedbackProps) => React.JSX.Element;
