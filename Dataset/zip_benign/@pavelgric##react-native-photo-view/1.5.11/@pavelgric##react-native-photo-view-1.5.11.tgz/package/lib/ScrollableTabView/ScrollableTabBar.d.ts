import React, { Component } from 'react';
import { ScrollView, StyleProp, ViewStyle, TextStyle, LayoutChangeEvent, LayoutRectangle } from 'react-native';
type Props = {
    goToPage: (page: number) => void;
    activeTab: number;
    tabs: Array<string>;
    backgroundColor?: string;
    activeTextColor: string;
    inactiveTextColor: string;
    scrollOffset: number;
    style: StyleProp<ViewStyle>;
    tabStyle: StyleProp<ViewStyle>;
    tabsContainerStyle: StyleProp<ViewStyle>;
    textStyle: StyleProp<TextStyle>;
    renderTab: (name: string, page: number, isTabActive: boolean, onPressHandler: (page: number) => void, onLayoutHandler: (e: LayoutChangeEvent) => void) => React.ReactNode;
    underlineStyle: StyleProp<ViewStyle>;
    onScroll: () => void;
    scrollValue: any;
};
type State = {
    _leftTabUnderline: any;
    _widthTabUnderline: any;
    _containerWidth: number | null;
};
export declare class ScrollableTabBar extends Component<Props, State> {
    _tabsMeasurements: any;
    _tabContainerMeasurements: LayoutRectangle;
    _containerMeasurements: LayoutRectangle;
    _scrollView: React.RefObject<ScrollView>;
    static defaultProps: Partial<Props>;
    constructor(props: Props);
    componentDidMount(): void;
    updateView(offset: {
        value: number;
    }): void;
    necessarilyMeasurementsCompleted(position: number, isLastTab: boolean): any;
    updateTabPanel(position: number, pageOffset: number): void;
    updateTabUnderline(position: number, pageOffset: number, tabCount: number): void;
    renderTab(name: string, page: number, isTabActive: boolean, onPressHandler: (page: number) => void, onLayoutHandler: (e: LayoutChangeEvent) => void): React.JSX.Element;
    measureTab(page: number, event: LayoutChangeEvent): void;
    render(): React.JSX.Element;
    UNSAFE_componentWillReceiveProps(nextProps: Props): void;
    onTabContainerLayout(e: LayoutChangeEvent): void;
    onContainerLayout(e: LayoutChangeEvent): void;
}
export {};
