import React from 'react';
import { ViewProps } from 'react-native';
type Props = {
    tabLabel: string;
} & ViewProps;
export declare function SceneView(props: Props): React.JSX.Element;
export {};
