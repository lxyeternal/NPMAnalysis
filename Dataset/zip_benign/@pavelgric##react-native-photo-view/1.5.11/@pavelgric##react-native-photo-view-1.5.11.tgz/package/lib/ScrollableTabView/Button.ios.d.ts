import React from 'react';
import { TouchableOpacityProps } from 'react-native';
export declare const Button: (props: TouchableOpacityProps) => React.JSX.Element;
