import React from 'react';
import ViewPager from 'react-native-pager-view';
export declare class ViewPagerZoom extends ViewPager {
    render(): React.JSX.Element;
}
