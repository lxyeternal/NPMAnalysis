import React, { Component } from 'react';
import { PhotoViewProps } from './PhotoView.props';
export default class PhotoView extends Component<PhotoViewProps> {
    _photoRef: any;
    _photoHandle: any;
    resetScale(): void;
    _setReference: (ref: any) => void;
    render(): React.JSX.Element | null;
}
