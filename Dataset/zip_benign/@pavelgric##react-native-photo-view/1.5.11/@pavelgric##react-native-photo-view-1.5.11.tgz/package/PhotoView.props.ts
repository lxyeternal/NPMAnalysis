import {ImageSourcePropType, ViewProps} from 'react-native';

export type PhotoViewProps = {
  source: ImageSourcePropType;
  loadingIndicatorSource?: ImageSourcePropType;
  fadeDuration?: number;
  minimumZoomScale?: number;
  maximumZoomScale?: number;
  scale?: number;
  androidZoomTransitionDuration?: number;
  androidScaleType?:
    | 'center'
    | 'centerCrop'
    | 'centerInside'
    | 'fitCenter'
    | 'fitStart'
    | 'fitEnd'
    | 'fitXY'
    | 'matrix';
  /* FIXME: find out function params */
  onLoadStart?: () => void;
  onProgress?: (e?: any) => void;
  onLoad?: () => void;
  onLoadEnd?: () => void;
  onTap?: (p: {point: {x: number; y: number}; target: number}) => void;
  onViewTap?: (p: {point: {x: number; y: number}; target: number}) => void;
  onScale?: (p: {
    focusX: number;
    focusY: number;
    scale: number;
    scaleFactor: number;
  }) => void;
  onError?: (e?: any) => void;
  showsHorizontalScrollIndicator: boolean;
  showsVerticalScrollIndicator: boolean;
} & ViewProps;
