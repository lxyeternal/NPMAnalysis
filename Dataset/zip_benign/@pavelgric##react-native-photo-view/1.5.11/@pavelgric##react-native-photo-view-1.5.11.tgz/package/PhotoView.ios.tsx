import React, {Component} from 'react';
import {
  requireNativeComponent,
  findNodeHandle,
  NativeModules,
} from 'react-native';
import {PhotoViewProps} from './PhotoView.props';

const resolveAssetSource = require('react-native/Libraries/Image/resolveAssetSource');

export default class PhotoView extends Component<PhotoViewProps> {
  _photoRef: any = null;
  _photoHandle: any = null;

  resetScale() {
    if (!this._photoHandle) {
      console.warn('no handle');
      return;
    }
    const PhotoViewManager = NativeModules.RNPhotoViewManager;
    PhotoViewManager.resetScale &&
      PhotoViewManager.resetScale(this._photoHandle);
  }

  _setReference = (ref: any) => {
    if (ref) {
      this._photoRef = ref;
      this._photoHandle = findNodeHandle(ref);
    } else {
      this._photoRef = null;
      this._photoHandle = null;
    }
  };

  render() {
    const source = resolveAssetSource(this.props.source);
    var loadingIndicatorSource = resolveAssetSource(
      this.props.loadingIndicatorSource,
    );

    if (source && source.uri === '') {
      console.warn('source.uri should not be an empty string');
    }

    // @ts-expect-error
    if (this.props.src) {
      console.warn(
        'The <PhotoView> component requires a `source` property rather than `src`.',
      );
    }

    if (source && source.uri) {
      var {
        onLoadStart,
        onLoad,
        onLoadEnd,
        onProgress,
        onTap,
        onViewTap,
        onScale,
        onError,
        ...props
      } = this.props;

      var nativeProps = {
        onPhotoViewerError: onError,
        onPhotoViewerLoadStart: onLoadStart,
        onPhotoViewerLoad: onLoad,
        onPhotoViewerLoadEnd: onLoadEnd,
        onPhotoViewerProgress: onProgress,
        onPhotoViewerTap: onTap,
        onPhotoViewerViewTap: onViewTap,
        onPhotoViewerScale: onScale,
        ...props,
        src: source,
        loadingIndicatorSrc: loadingIndicatorSource
          ? loadingIndicatorSource.uri
          : null,
      };

      return <RNPhotoView ref={this._setReference} {...nativeProps} />;
    }
    return null;
  }
}

const RNPhotoView = requireNativeComponent('RNPhotoView');
