import React, {Component} from 'react';

import {
  View,
  Animated,
  StyleSheet,
  ScrollView,
  Text,
  Platform,
  Dimensions,
  StyleProp,
  ViewStyle,
  TextStyle,
  LayoutChangeEvent,
  LayoutRectangle,
} from 'react-native';
import {Button} from './Button';

const WINDOW_WIDTH = Dimensions.get('window').width;

type Props = {
  goToPage: (page: number) => void;
  activeTab: number;
  tabs: Array<string>;
  backgroundColor?: string;
  activeTextColor: string;
  inactiveTextColor: string;
  scrollOffset: number;
  style: StyleProp<ViewStyle>;
  tabStyle: StyleProp<ViewStyle>;
  tabsContainerStyle: StyleProp<ViewStyle>;
  textStyle: StyleProp<TextStyle>;
  renderTab: (
    name: string,
    page: number,
    isTabActive: boolean,
    onPressHandler: (page: number) => void,
    onLayoutHandler: (e: LayoutChangeEvent) => void,
  ) => React.ReactNode;
  underlineStyle: StyleProp<ViewStyle>;
  onScroll: () => void;
  scrollValue: any;
};

type State = {
  _leftTabUnderline: any;
  _widthTabUnderline: any;
  _containerWidth: number | null;
};

export class ScrollableTabBar extends Component<Props, State> {
  _tabsMeasurements: any = [];
  _tabContainerMeasurements: LayoutRectangle = {
    width: 0,
    height: 0,
    x: 0,
    y: 0,
  };
  _containerMeasurements: LayoutRectangle = {
    width: 0,
    height: 0,
    x: 0,
    y: 0,
  };
  _scrollView: React.RefObject<ScrollView> = React.createRef();

  static defaultProps: Partial<Props> = {
    scrollOffset: 52,
    activeTextColor: 'navy',
    inactiveTextColor: 'black',
    style: {},
    tabStyle: {},
    tabsContainerStyle: {},
    underlineStyle: {},
  };

  constructor(props: Props) {
    super(props);

    this.state = {
      _leftTabUnderline: new Animated.Value(0),
      _widthTabUnderline: new Animated.Value(0),
      _containerWidth: null,
    };
  }

  componentDidMount() {
    this.props.scrollValue.addListener(this.updateView);
  }

  updateView(offset: {value: number}) {
    const position = Math.floor(offset.value);
    const pageOffset = offset.value % 1;
    const tabCount = this.props.tabs.length;
    const lastTabPosition = tabCount - 1;

    if (tabCount === 0 || offset.value < 0 || offset.value > lastTabPosition) {
      return;
    }

    if (
      this.necessarilyMeasurementsCompleted(
        position,
        position === lastTabPosition,
      )
    ) {
      this.updateTabPanel(position, pageOffset);
      this.updateTabUnderline(position, pageOffset, tabCount);
    }
  }

  necessarilyMeasurementsCompleted(position: number, isLastTab: boolean) {
    return (
      this._tabsMeasurements[position] &&
      (isLastTab || this._tabsMeasurements[position + 1]) &&
      this._tabContainerMeasurements &&
      this._containerMeasurements
    );
  }

  updateTabPanel(position: number, pageOffset: number) {
    const containerWidth = this._containerMeasurements.width;
    const tabWidth = this._tabsMeasurements[position].width;
    const nextTabMeasurements = this._tabsMeasurements[position + 1];
    const nextTabWidth =
      (nextTabMeasurements && nextTabMeasurements.width) || 0;
    const tabOffset = this._tabsMeasurements[position].left;
    const absolutePageOffset = pageOffset * tabWidth;
    let newScrollX = tabOffset + absolutePageOffset;

    // center tab and smooth tab change (for when tabWidth changes a lot between two tabs)
    newScrollX -=
      (containerWidth -
        (1 - pageOffset) * tabWidth -
        pageOffset * nextTabWidth) /
      2;
    newScrollX = newScrollX >= 0 ? newScrollX : 0;

    if (Platform.OS === 'android') {
      this._scrollView.current?.scrollTo({
        x: newScrollX,
        y: 0,
        animated: false,
      });
    } else {
      const rightBoundScroll =
        this._tabContainerMeasurements.width -
        this._containerMeasurements.width;
      newScrollX =
        newScrollX > rightBoundScroll ? rightBoundScroll : newScrollX;
      this._scrollView.current?.scrollTo({
        x: newScrollX,
        y: 0,
        animated: false,
      });
    }
  }

  updateTabUnderline(position: number, pageOffset: number, tabCount: number) {
    const lineLeft = this._tabsMeasurements[position].left;
    const lineRight = this._tabsMeasurements[position].right;

    if (position < tabCount - 1) {
      const nextTabLeft = this._tabsMeasurements[position + 1].left;
      const nextTabRight = this._tabsMeasurements[position + 1].right;

      const newLineLeft =
        pageOffset * nextTabLeft + (1 - pageOffset) * lineLeft;
      const newLineRight =
        pageOffset * nextTabRight + (1 - pageOffset) * lineRight;

      this.state._leftTabUnderline.setValue(newLineLeft);
      this.state._widthTabUnderline.setValue(newLineRight - newLineLeft);
    } else {
      this.state._leftTabUnderline.setValue(lineLeft);
      this.state._widthTabUnderline.setValue(lineRight - lineLeft);
    }
  }

  renderTab(
    name: string,
    page: number,
    isTabActive: boolean,
    onPressHandler: (page: number) => void,
    onLayoutHandler: (e: LayoutChangeEvent) => void,
  ) {
    const {activeTextColor, inactiveTextColor, textStyle} = this.props;
    const textColor = isTabActive ? activeTextColor : inactiveTextColor;
    const fontWeight = isTabActive ? 'bold' : 'normal';

    return (
      <Button
        key={`${name}_${page}`}
        accessible={true}
        accessibilityLabel={name}
        accessibilityRole="button"
        onPress={() => onPressHandler(page)}
        onLayout={onLayoutHandler}>
        <View style={[styles.tab, this.props.tabStyle]}>
          <Text style={[{color: textColor, fontWeight}, textStyle]}>
            {name}
          </Text>
        </View>
      </Button>
    );
  }

  measureTab(page: number, event: LayoutChangeEvent) {
    const {x, width, height} = event.nativeEvent.layout;
    this._tabsMeasurements[page] = {left: x, right: x + width, width, height};
    this.updateView({value: this.props.scrollValue.__getValue()});
  }

  render() {
    const tabUnderlineStyle: ViewStyle = {
      position: 'absolute',
      height: 4,
      backgroundColor: 'navy',
      bottom: 0,
    };

    const dynamicTabUnderline = {
      left: this.state._leftTabUnderline,
      width: this.state._widthTabUnderline,
    };

    return (
      <View
        style={[
          styles.container,
          {backgroundColor: this.props.backgroundColor},
          this.props.style,
        ]}
        onLayout={this.onContainerLayout}>
        <ScrollView
          ref={this._scrollView}
          horizontal={true}
          showsHorizontalScrollIndicator={false}
          showsVerticalScrollIndicator={false}
          directionalLockEnabled={true}
          bounces={false}
          scrollsToTop={false}>
          <View
            style={[
              styles.tabs,
              {width: this.state._containerWidth},
              this.props.tabsContainerStyle,
            ]}
            onLayout={this.onTabContainerLayout}>
            {this.props.tabs.map((name, page) => {
              const isTabActive = this.props.activeTab === page;
              const renderTab = this.props.renderTab || this.renderTab;
              return renderTab(
                name,
                page,
                isTabActive,
                this.props.goToPage,
                this.measureTab.bind(this, page),
              );
            })}
            <Animated.View
              style={[
                tabUnderlineStyle,
                dynamicTabUnderline,
                this.props.underlineStyle,
              ]}
            />
          </View>
        </ScrollView>
      </View>
    );
  }

  UNSAFE_componentWillReceiveProps(nextProps: Props) {
    // If the tabs change, force the width of the tabs container to be recalculated
    if (
      JSON.stringify(this.props.tabs) !== JSON.stringify(nextProps.tabs) &&
      this.state._containerWidth
    ) {
      this.setState({_containerWidth: null});
    }
  }

  onTabContainerLayout(e: LayoutChangeEvent) {
    this._tabContainerMeasurements = e.nativeEvent.layout;
    let width = this._tabContainerMeasurements.width;
    if (width < WINDOW_WIDTH) {
      width = WINDOW_WIDTH;
    }
    this.setState({_containerWidth: width});
    this.updateView({value: this.props.scrollValue.__getValue()});
  }

  onContainerLayout(e: LayoutChangeEvent) {
    this._containerMeasurements = e.nativeEvent.layout;
    this.updateView({value: this.props.scrollValue.__getValue()});
  }
}

const styles = StyleSheet.create({
  tab: {
    height: 49,
    alignItems: 'center',
    justifyContent: 'center',
    paddingLeft: 20,
    paddingRight: 20,
  },
  container: {
    height: 50,
    borderWidth: 1,
    borderTopWidth: 0,
    borderLeftWidth: 0,
    borderRightWidth: 0,
    borderColor: '#ccc',
  },
  tabs: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
});
