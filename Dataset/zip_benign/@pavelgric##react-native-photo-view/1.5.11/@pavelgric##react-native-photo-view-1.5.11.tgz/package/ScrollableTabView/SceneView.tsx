import React from 'react';
import {View, ViewProps} from 'react-native';

type Props = {
  tabLabel: string;
} & ViewProps;

export function SceneView(props: Props) {
  return <View {...props}>{props.children}</View>;
}
