import React, {useCallback} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Animated,
  StyleProp,
  TextStyle,
  ViewStyle,
} from 'react-native';
import {Button} from './Button';

export type TabBarProps = {
  goToPage: (pageNumber: number) => void;
  activeTab: number;
  tabs: Array<string>;
  containerWidth: number;
  scrollValue:
    | Animated.Value
    | Animated.AnimatedDivision<string | number>
    | Animated.AnimatedAddition<string | number>;
  backgroundColor?: string;
  activeTextColor?: string;
  inactiveTextColor?: string;
  style?: StyleProp<ViewStyle>;
  textStyle?: StyleProp<TextStyle>;
  tabStyle?: StyleProp<ViewStyle>;
  renderTab?: (
    name: string,
    page: number,
    isTabActive: boolean,
    onPressHandler: (page: number) => void,
  ) => React.ReactNode;
  underlineStyle?: StyleProp<ViewStyle>;
};
export const DefaultTabBar = (props: TabBarProps) => {
  const {activeTextColor, inactiveTextColor, textStyle} = props;

  const _renderTab = useCallback(
    (
      name: string,
      page: number,
      isTabActive: boolean,
      onPressHandler: (page: number) => void,
    ) => {
      const textColor = isTabActive ? activeTextColor : inactiveTextColor;
      const fontWeight = isTabActive ? 'bold' : 'normal';

      return (
        <Button
          style={styles.flex}
          key={name}
          accessible={true}
          accessibilityLabel={name}
          accessibilityRole="button"
          onPress={() => onPressHandler(page)}>
          <View style={[styles.tab, props.tabStyle]}>
            <Text style={[{color: textColor, fontWeight}, textStyle]}>
              {name}
            </Text>
          </View>
        </Button>
      );
    },
    [activeTextColor, inactiveTextColor, props.tabStyle, textStyle],
  );

  const containerWidth = props.containerWidth;
  const numberOfTabs = props.tabs.length;
  const tabUnderlineStyle: ViewStyle = {
    position: 'absolute',
    width: containerWidth / numberOfTabs,
    height: 4,
    backgroundColor: 'navy',
    bottom: 0,
  };

  const translateX = props.scrollValue.interpolate({
    inputRange: [0, 1],
    outputRange: [0, containerWidth / numberOfTabs],
  });
  return (
    <View
      style={[
        styles.tabs,
        {backgroundColor: props.backgroundColor},
        props.style,
      ]}>
      {props.tabs.map((name, page) => {
        const isTabActive = props.activeTab === page;
        const renderTab = props.renderTab || _renderTab;
        return renderTab(name, page, isTabActive, props.goToPage);
      })}
      <Animated.View
        style={[
          tabUnderlineStyle,
          {
            transform: [{translateX}],
          },
          props.underlineStyle,
        ]}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: 10,
  },
  tabs: {
    height: 50,
    flexDirection: 'row',
    justifyContent: 'space-around',
    borderWidth: 1,
    borderTopWidth: 0,
    borderLeftWidth: 0,
    borderRightWidth: 0,
    borderColor: '#ccc',
  },
});
