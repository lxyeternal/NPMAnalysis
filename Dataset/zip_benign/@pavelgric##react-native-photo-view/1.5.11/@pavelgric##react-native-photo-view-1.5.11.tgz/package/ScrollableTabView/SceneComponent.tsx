import {View, ViewProps} from 'react-native';
import React from 'react';

import {StaticContainer} from './StaticContainer';

type Props = {
  shouldUpdated: boolean;
} & ViewProps;

export const SceneComponent = (Props: Props) => {
  const {shouldUpdated, ...props} = Props;
  return (
    <View {...props}>
      <StaticContainer shouldUpdate={shouldUpdated}>
        {props.children}
      </StaticContainer>
    </View>
  );
};
