import React from 'react';
import {
  TouchableNativeFeedback,
  TouchableNativeFeedbackProps,
} from 'react-native';

export const Button = (props: TouchableNativeFeedbackProps) => {
  return (
    <TouchableNativeFeedback
      delayPressIn={0}
      background={TouchableNativeFeedback.SelectableBackground()}
      {...props}>
      {props.children}
    </TouchableNativeFeedback>
  );
};
