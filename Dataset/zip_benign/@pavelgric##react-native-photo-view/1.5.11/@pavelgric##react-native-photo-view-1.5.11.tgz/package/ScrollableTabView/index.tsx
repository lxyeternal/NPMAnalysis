import React, {Component} from 'react';
import {
  Dimensions,
  View,
  Animated,
  Platform,
  StyleSheet,
  StyleProp,
  ViewStyle,
  ScrollView,
  NativeSyntheticEvent,
  NativeScrollEvent,
  LayoutChangeEvent,
  TextStyle,
  ScrollViewProps,
} from 'react-native';
import {ViewPagerZoom} from '../ViewPager';
import {
  PagerViewProps,
  PagerViewOnPageScrollEvent,
  PagerViewOnPageSelectedEvent,
} from 'react-native-pager-view';

import {SceneComponent} from './SceneComponent';
import {DefaultTabBar, TabBarProps} from './DefaultTabBar';
import {ScrollableTabBar} from './ScrollableTabBar';
import {SceneView} from './SceneView';

const AnimatedViewPagerAndroid =
  Platform.OS === 'android'
    ? Animated.createAnimatedComponent(ViewPagerZoom)
    : undefined;

type Child = React.ReactElement<{tabLabel: string}>;
type Props = {
  tabBarPosition: 'top' | 'bottom' | 'overlayTop' | 'overlayBottom';
  initialPage: number;
  page: number;
  onChangeTab: (p: {i: number; ref: any; from: number}) => void;
  onScroll: (v: number) => void;
  renderTabBar: ((p: TabBarProps) => React.ReactElement) | false;
  style: StyleProp<ViewStyle>;
  contentProps: Omit<ScrollViewProps, 'children'> &
    Omit<PagerViewProps, 'children'>;
  scrollWithoutAnimation: boolean;
  locked: boolean;
  prerenderingSiblingsNumber: number;
  children: Child;
  tabBarBackgroundColor?: string;
  tabBarActiveTextColor?: string;
  tabBarInactiveTextColor?: string;
  tabBarTextStyle?: StyleProp<TextStyle>;
  tabBarUnderlineStyle?: StyleProp<ViewStyle>;
};

type State = {
  currentPage: number;
  containerWidth: number;
  scrollXIOS: Animated.Value;
  positionAndroid: Animated.Value;
  offsetAndroid: Animated.Value;
  scrollValue:
    | Animated.AnimatedDivision<string | number>
    | Animated.AnimatedAddition<string | number>;
  sceneKeys: string[];
};

export class ScrollableTabView extends Component<Props, State> {
  statics = {
    DefaultTabBar,
    ScrollableTabBar,
  };
  scrollOnMountCalled = false;
  static defaultProps: Partial<Props> = {
    tabBarPosition: 'top',
    initialPage: 0,
    page: -1,
    onChangeTab: () => {},
    onScroll: () => {},
    contentProps: {},
    scrollWithoutAnimation: false,
    locked: false,
    prerenderingSiblingsNumber: 0,
  };
  scrollView: React.RefObject<ScrollView> = React.createRef();
  viewPager: React.RefObject<ViewPagerZoom> = React.createRef();

  constructor(props: Props) {
    super(props);

    this.state = this.getInitialState();
  }

  getInitialState(): State {
    const containerWidth = Dimensions.get('window').width;
    let scrollValue;
    let scrollXIOS = new Animated.Value(0);
    let positionAndroid = new Animated.Value(0);
    let offsetAndroid = new Animated.Value(0);

    if (Platform.OS === 'ios') {
      scrollXIOS = new Animated.Value(this.props.initialPage * containerWidth);
      const containerWidthAnimatedValue = new Animated.Value(containerWidth);
      scrollValue = Animated.divide(scrollXIOS, containerWidthAnimatedValue);

      const callListeners = this._polyfillAnimatedValue(scrollValue);
      scrollXIOS.addListener(({value}) =>
        callListeners(value / this.state.containerWidth),
      );
    } else {
      positionAndroid = new Animated.Value(this.props.initialPage);
      scrollValue = Animated.add(positionAndroid, offsetAndroid);

      const callListeners = this._polyfillAnimatedValue(scrollValue);
      let positionAndroidValue = this.props.initialPage;
      let offsetAndroidValue = 0;
      positionAndroid.addListener(({value}) => {
        positionAndroidValue = value;
        callListeners(positionAndroidValue + offsetAndroidValue);
      });
      offsetAndroid.addListener(({value}) => {
        offsetAndroidValue = value;
        callListeners(positionAndroidValue + offsetAndroidValue);
      });
    }

    return {
      currentPage: this.props.initialPage,
      scrollValue,
      scrollXIOS,
      positionAndroid,
      offsetAndroid,
      containerWidth,
      sceneKeys: this.newSceneKeys({currentPage: this.props.initialPage}),
    };
  }

  UNSAFE_componentWillReceiveProps(props: Props) {
    if (props.children !== this.props.children) {
      this.updateSceneKeys({
        page: this.state.currentPage,
        children: props.children,
      });
    }

    if (props.page >= 0 && props.page !== this.state.currentPage) {
      this.goToPage(props.page);
    }
  }

  componentWillUnmount() {
    if (Platform.OS === 'ios') {
      this.state.scrollXIOS?.removeAllListeners();
    } else {
      this.state.positionAndroid?.removeAllListeners();
      this.state.offsetAndroid?.removeAllListeners();
    }
  }

  goToPage = (pageNumber: number) => {
    if (Platform.OS === 'ios') {
      const offset = pageNumber * this.state.containerWidth;
      if (this.scrollView) {
        this.scrollView.current?.scrollTo({
          x: offset,
          y: 0,
          animated: !this.props.scrollWithoutAnimation,
        });
      }
    } else {
      if (this.viewPager) {
        if (this.props.scrollWithoutAnimation) {
          this.viewPager.current?.setPageWithoutAnimation(pageNumber);
        } else {
          this.viewPager.current?.setPage(pageNumber);
        }
      }
    }

    const currentPage = this.state.currentPage;
    this.updateSceneKeys({
      page: pageNumber,
      callback: this._onChangeTab.bind(this, currentPage, pageNumber),
    });
  };

  renderTabBar = (props: TabBarProps) => {
    if (this.props.renderTabBar === false) {
      return null;
    } else if (this.props.renderTabBar) {
      return React.cloneElement(this.props.renderTabBar(props), props);
    } else {
      return <DefaultTabBar {...props} />;
    }
  };

  updateSceneKeys = ({
    page,
    children = this.props.children,
    callback = () => {},
  }: {
    page: number;
    children?: Child;
    callback?: () => void;
  }) => {
    let newKeys = this.newSceneKeys({
      previousKeys: this.state.sceneKeys,
      currentPage: page,
      children,
    });
    this.setState({currentPage: page, sceneKeys: newKeys}, callback);
  };

  newSceneKeys = ({
    previousKeys = [],
    currentPage = 0,
    children = this.props.children,
  }: {
    previousKeys?: string[];
    currentPage?: number;
    children?: Child;
  }) => {
    let newKeys: string[] = [];
    this._children(children).forEach((child, idx) => {
      let key = this._makeSceneKey(child, idx);
      if (
        this._keyExists(previousKeys, key) ||
        this._shouldRenderSceneKey(idx, currentPage)
      ) {
        newKeys.push(key);
      }
    });
    return newKeys;
  };

  // Animated.add and Animated.divide do not currently support listeners so
  // we have to polyfill it here since a lot of code depends on being able
  // to add a listener to `scrollValue`. See https://github.com/facebook/react-native/pull/12620.
  _polyfillAnimatedValue = (
    animatedValue: Animated.Value | Animated.AnimatedDivision<string | number>,
  ) => {
    const listeners = new Set();
    const addListener = (listener: any) => {
      return listeners.add(listener);
    };

    const removeListener = (listener: any) => {
      listeners.delete(listener);
    };

    const removeAllListeners = () => {
      listeners.clear();
    };

    // @ts-ignore
    animatedValue.addListener = addListener;
    animatedValue.removeListener = removeListener;
    animatedValue.removeAllListeners = removeAllListeners;

    // @ts-ignore
    return value => listeners.forEach(listener => listener({value}));
  };

  _shouldRenderSceneKey = (idx: number, currentPageKey: number) => {
    let numOfSibling = this.props.prerenderingSiblingsNumber;
    return (
      idx < currentPageKey + numOfSibling + 1 &&
      idx > currentPageKey - numOfSibling - 1
    );
  };

  _keyExists = (sceneKeys: string[], key: string) => {
    return sceneKeys.find(sceneKey => key === sceneKey);
  };

  _makeSceneKey = (child: any, idx: number) => {
    return child.props.tabLabel + '_' + idx;
  };

  renderScrollableContent = () => {
    if (Platform.OS === 'ios') {
      const scenes = this._composeScenes();
      return (
        <Animated.ScrollView
          horizontal
          pagingEnabled
          automaticallyAdjustContentInsets={false}
          contentOffset={{
            x: this.props.initialPage * this.state.containerWidth,
            y: 0,
          }}
          ref={this.scrollView}
          onScroll={Animated.event(
            [{nativeEvent: {contentOffset: {x: this.state.scrollXIOS}}}],
            {useNativeDriver: true, listener: this._onScroll},
          )}
          onMomentumScrollBegin={this._onMomentumScrollBeginAndEnd}
          onMomentumScrollEnd={this._onMomentumScrollBeginAndEnd}
          scrollEventThrottle={16}
          scrollsToTop={false}
          showsHorizontalScrollIndicator={false}
          scrollEnabled={!this.props.locked}
          directionalLockEnabled
          alwaysBounceVertical={false}
          keyboardDismissMode="on-drag"
          {...this.props.contentProps}>
          {scenes}
        </Animated.ScrollView>
      );
    } else if (AnimatedViewPagerAndroid) {
      const scenes = this._composeScenes();
      return (
        <AnimatedViewPagerAndroid
          key={this._children().length}
          style={styles.scrollableContentAndroid}
          initialPage={this.props.initialPage}
          onPageSelected={this._updateSelectedPage}
          keyboardDismissMode="on-drag"
          scrollEnabled={!this.props.locked}
          onPageScroll={Animated.event(
            [
              {
                nativeEvent: {
                  position: this.state.positionAndroid,
                  offset: this.state.offsetAndroid,
                },
              },
            ],
            {
              useNativeDriver: true,
              listener: this._onScroll,
            },
          )}
          ref={this.viewPager}
          {...this.props.contentProps}>
          {scenes}
        </AnimatedViewPagerAndroid>
      );
    }
  };

  _composeScenes = () => {
    return this._children().map((child, idx) => {
      let key = this._makeSceneKey(child, idx);
      return (
        <SceneComponent
          key={child.key}
          shouldUpdated={this._shouldRenderSceneKey(
            idx,
            this.state.currentPage,
          )}
          style={{width: this.state.containerWidth}}>
          {Platform.OS === 'android' ||
          this._keyExists(this.state.sceneKeys, key) ? (
            child
          ) : (
            <SceneView tabLabel={child.props.tabLabel} />
          )}
        </SceneComponent>
      );
    });
  };

  _onMomentumScrollBeginAndEnd = (
    e: NativeSyntheticEvent<NativeScrollEvent>,
  ) => {
    const offsetX = e.nativeEvent.contentOffset.x;
    const page = Math.round(offsetX / this.state.containerWidth);
    if (this.state.currentPage !== page) {
      this._updateSelectedPage(page);
    }
  };

  _updateSelectedPage = (nextPage: number | PagerViewOnPageSelectedEvent) => {
    let localNextPage: number;
    if (typeof nextPage === 'object') {
      localNextPage = nextPage.nativeEvent.position;
    } else {
      localNextPage = nextPage;
    }

    const currentPage = this.state.currentPage;
    this.updateSceneKeys({
      page: localNextPage,
      callback: this._onChangeTab.bind(this, currentPage, localNextPage),
    });
  };

  _onChangeTab = (prevPage: number, currentPage: number) => {
    this.props.onChangeTab({
      i: currentPage,
      ref: this._children()[currentPage],
      from: prevPage,
    });
  };

  _onScroll = (
    e: NativeSyntheticEvent<NativeScrollEvent> | PagerViewOnPageScrollEvent,
  ) => {
    if (Platform.OS === 'ios') {
      const offsetX = (e as NativeSyntheticEvent<NativeScrollEvent>).nativeEvent
        .contentOffset.x;
      if (offsetX === 0 && !this.scrollOnMountCalled) {
        this.scrollOnMountCalled = true;
      } else {
        this.props.onScroll(offsetX / this.state.containerWidth);
      }
    } else {
      const {position, offset} = (e as PagerViewOnPageScrollEvent).nativeEvent;
      this.props.onScroll(position + offset);
    }
  };

  _handleLayout = (e: LayoutChangeEvent) => {
    const {width} = e.nativeEvent.layout;

    if (
      !width ||
      width <= 0 ||
      Math.round(width) === Math.round(this.state.containerWidth)
    ) {
      return;
    }

    if (Platform.OS === 'ios') {
      const containerWidthAnimatedValue = new Animated.Value(width);
      const scrollValue = Animated.divide(
        this.state.scrollXIOS,
        containerWidthAnimatedValue,
      );
      this.setState({containerWidth: width, scrollValue});
    } else {
      this.setState({containerWidth: width});
    }
    requestAnimationFrame(() => {
      this.goToPage(this.state.currentPage);
    });
  };

  _children = (children = this.props.children) => {
    return React.Children.map(children, child => child);
  };

  render() {
    let overlayTabs =
      this.props.tabBarPosition === 'overlayTop' ||
      this.props.tabBarPosition === 'overlayBottom';
    let tabBarProps: TabBarProps = {
      goToPage: this.goToPage,
      tabs: this._children().map(child => child.props.tabLabel),
      activeTab: this.state.currentPage,
      scrollValue: this.state.scrollValue,
      containerWidth: this.state.containerWidth,
    };

    if (this.props.tabBarBackgroundColor) {
      tabBarProps.backgroundColor = this.props.tabBarBackgroundColor;
    }
    if (this.props.tabBarActiveTextColor) {
      tabBarProps.activeTextColor = this.props.tabBarActiveTextColor;
    }
    if (this.props.tabBarInactiveTextColor) {
      tabBarProps.inactiveTextColor = this.props.tabBarInactiveTextColor;
    }
    if (this.props.tabBarTextStyle) {
      tabBarProps.textStyle = this.props.tabBarTextStyle;
    }
    if (this.props.tabBarUnderlineStyle) {
      tabBarProps.underlineStyle = this.props.tabBarUnderlineStyle;
    }
    if (overlayTabs) {
      tabBarProps.style = {
        position: 'absolute',
        left: 0,
        right: 0,
        [this.props.tabBarPosition === 'overlayTop' ? 'top' : 'bottom']: 0,
      };
    }

    return (
      <View
        style={[styles.container, this.props.style]}
        onLayout={this._handleLayout}>
        {this.props.tabBarPosition === 'top' && this.renderTabBar(tabBarProps)}
        {this.renderScrollableContent()}
        {(this.props.tabBarPosition === 'bottom' || overlayTabs) &&
          this.renderTabBar(tabBarProps)}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollableContentAndroid: {
    flex: 1,
  },
});
