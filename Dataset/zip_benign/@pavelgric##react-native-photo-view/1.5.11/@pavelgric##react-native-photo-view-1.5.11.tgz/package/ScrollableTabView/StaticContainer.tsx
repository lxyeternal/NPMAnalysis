import React, {Component} from 'react';

type Props = {
  children: React.ReactNode | boolean;
  shouldUpdate: boolean;
};

export class StaticContainer extends Component<Props> {
  shouldComponentUpdate(nextProps: Props): boolean {
    return !!nextProps.shouldUpdate;
  }

  render() {
    var child = this.props.children;
    if (child === null || typeof child === 'boolean') {
      return null;
    }
    return React.Children.only(child);
  }
}
