/**
 * 模拟数据服务
 */
declare const mockServer: (template: (...arg: any[]) => any) => any;
export default mockServer;
