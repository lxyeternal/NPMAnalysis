/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { BonesList as ɵa } from './lib/classes/bones-list.class';
