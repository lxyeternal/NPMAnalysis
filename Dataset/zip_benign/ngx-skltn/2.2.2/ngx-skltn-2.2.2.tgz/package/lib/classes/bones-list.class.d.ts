import { BehaviorSubject } from 'rxjs';
import { SkltnBoneDirective } from '../directives/skltn-bone.directive';
export declare class BonesList {
    changes: BehaviorSubject<SkltnBoneDirective[]>;
    private map;
    constructor();
    add(bone: SkltnBoneDirective): string;
    remove(id: string): void;
    private emit;
    private getList;
}
