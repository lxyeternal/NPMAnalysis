import { SkltnConfig } from '../interfaces/skltn-config';
export declare class SkltnService {
    ids: string[];
    config: SkltnConfig;
    private defaultConfig;
    constructor(config: SkltnConfig);
}
