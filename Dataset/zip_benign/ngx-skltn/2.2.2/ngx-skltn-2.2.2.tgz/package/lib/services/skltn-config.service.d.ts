import { InjectionToken } from '@angular/core';
import { SkltnConfig } from '../interfaces/skltn-config';
export declare const SKLTN_CONFIG_TOKEN: InjectionToken<SkltnConfig>;
