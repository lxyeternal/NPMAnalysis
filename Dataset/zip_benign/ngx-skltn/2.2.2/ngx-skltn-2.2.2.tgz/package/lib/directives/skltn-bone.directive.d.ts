import { ElementRef, TemplateRef, OnInit, OnDestroy } from '@angular/core';
import { BonesList } from '../classes/bones-list.class';
export declare class SkltnBoneDirective implements OnInit, OnDestroy {
    element: ElementRef;
    private bonesList;
    type: 'rect' | 'circle' | 'path';
    rectRadius: number;
    pathWidth: number;
    pathHeight: number;
    template: TemplateRef<any>;
    private id;
    constructor(element: ElementRef, bonesList: BonesList);
    ngOnInit(): void;
    ngOnDestroy(): void;
}
