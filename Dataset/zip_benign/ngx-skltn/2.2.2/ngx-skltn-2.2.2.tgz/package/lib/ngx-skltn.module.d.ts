import { ModuleWithProviders } from '@angular/core';
import { SkltnConfig } from './interfaces/skltn-config';
export declare class NgxSkltnModule {
    static forRoot(config?: Partial<SkltnConfig>): ModuleWithProviders<NgxSkltnModule>;
}
