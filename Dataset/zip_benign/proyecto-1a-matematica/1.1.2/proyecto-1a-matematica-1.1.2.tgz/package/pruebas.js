const m = require('.')

console.log(m.suma(true, 2))
console.log(m.suma(1, 2))

console.log(m.resta(11, 24))
console.log(m.resta('asd', 2))

console.log(m.multiplicacion(Boolean, 24))
console.log(m.multiplicacion(1, 2))

console.log(m.division("as", 2))
console.log(m.division(10, 2))