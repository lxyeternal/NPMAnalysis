# Operaciones matemáticas

Módulo para realizar operaciones matemáticas basicas

## Instalación 
Seguir las siguientes instrucciones

```
npm install proyecto-1a-matematica
```

# Uso
Seguir las siguientes instrucciones

```
// Importar el Módulo
const m = require('.')

// Sumas
console.log(m.suma(1,2)) => 3
console.log(m.suma(1,34)) => 35

// Restas
console.log(m.resta(11,24)) => -13
console.log(m.resta(1,2)) => -1

// Multiplicación
console.log(m.multiplicacion(1,24)) => 24
console.log(m.multiplicacion(1,2)) => 2

// División
console.log(m.division(1,2)) => 0.5
console.log(m.division(10,2)) = 5
```

