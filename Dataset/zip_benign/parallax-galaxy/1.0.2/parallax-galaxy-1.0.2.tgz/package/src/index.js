// src/index.js
import ParallaxGalaxy from './ParallaxGalaxy';

export default ParallaxGalaxy;