// src/ParallaxGalaxy.js
import React, { useEffect } from 'react';

const ParallaxGalaxy = ({ children }) => {
  useEffect(() => {
    const parallaxElements = [];
    const selectors = {
      parallaxContainer: '.parallax-container',
      parallaxElement: 'div[data-ease]',
    };

    const applyParallax = (elements) => {
      window.addEventListener('scroll', () => {
        const scrollY = window.scrollY;
        const maxScroll = document.body.scrollHeight - window.innerHeight;
        elements.forEach((items) => {
          items.forEach((ele) => {
            const opacity = ele?.dataset?.opacity - scrollY / maxScroll;
            ele.style.transform = `translate(${ele?.dataset?.diagonally ? scrollY * ele?.dataset?.diagonally + 'px' : '0'} , ${scrollY * ele?.dataset?.ease}px) scale(${ele?.dataset?.scale ? 1 + scrollY * ele?.dataset?.scale : '1'}) rotate(${ele?.dataset?.rotate ? 1 + scrollY * ele?.dataset?.rotate + 'deg' : '0deg'})`; 
            if (ele?.dataset?.opacity) {
              ele.style.opacity = opacity;
            }
          });
        });
      });
    };

    const init = () => {
      const $mainParallaxElements = document.querySelectorAll(selectors.parallaxContainer);
      $mainParallaxElements.forEach((ele) => {
        parallaxElements.push(ele.querySelectorAll(selectors.parallaxElement));
      });

      applyParallax(parallaxElements);
    };

    init();
  }, []);

  return <div className="parallax-container">{children}</div>;
};

export default ParallaxGalaxy;
