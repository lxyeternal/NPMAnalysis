import * as i0 from '@angular/core';
import { Injectable, EventEmitter, Output, Input, Component, ChangeDetectionStrategy, NgModule } from '@angular/core';
import { first } from 'rxjs';
import { cloneDeep as cloneDeep$1 } from 'lodash-es';
import * as Highcharts from 'highcharts';
import { Axis } from 'highcharts';
import * as Highmaps from 'highcharts/highmaps';
import HighchartsAccessibility from 'highcharts/modules/accessibility';
import HighchartsExporting from 'highcharts/modules/exporting';
import HighchartsOfflineExporting from 'highcharts/modules/offline-exporting';
import * as i1$1 from '@angular/common';
import { formatDate, CommonModule } from '@angular/common';
import cloneDeep from 'lodash-es/cloneDeep';
import merge from 'lodash-es/merge';
import { isValid, parseISO } from 'date-fns';
import * as i1 from '@angular/common/http';
import * as i8 from 'highcharts-angular';
import { HighchartsChartModule } from 'highcharts-angular';
import * as i2 from '@ng-bootstrap/ng-bootstrap';
import { NgbDropdownModule, NgbPopoverModule } from '@ng-bootstrap/ng-bootstrap';
import * as i10 from '@folkehelseinstituttet/angular-components';
import { FhiModalComponent, FhiPopoverMenuComponent } from '@folkehelseinstituttet/angular-components';
import { FormsModule } from '@angular/forms';

var DiagramTypeIds;
(function (DiagramTypeIds) {
    DiagramTypeIds[DiagramTypeIds["bar"] = 0] = "bar";
    DiagramTypeIds[DiagramTypeIds["barStacked"] = 1] = "barStacked";
    DiagramTypeIds[DiagramTypeIds["column"] = 2] = "column";
    DiagramTypeIds[DiagramTypeIds["columnAndLine"] = 3] = "columnAndLine";
    DiagramTypeIds[DiagramTypeIds["columnStacked"] = 4] = "columnStacked";
    DiagramTypeIds[DiagramTypeIds["line"] = 5] = "line";
    DiagramTypeIds[DiagramTypeIds["mapFylker"] = 6] = "mapFylker";
    DiagramTypeIds[DiagramTypeIds["mapFylker2019"] = 7] = "mapFylker2019";
    DiagramTypeIds[DiagramTypeIds["mapFylker2023"] = 8] = "mapFylker2023";
    DiagramTypeIds[DiagramTypeIds["pie"] = 9] = "pie";
    DiagramTypeIds[DiagramTypeIds["table"] = 10] = "table";
})(DiagramTypeIds || (DiagramTypeIds = {}));
const DiagramTypeIdValues = {
    bar: DiagramTypeIds[DiagramTypeIds.bar],
    barStacked: DiagramTypeIds[DiagramTypeIds.barStacked],
    column: DiagramTypeIds[DiagramTypeIds.column],
    columnAndLine: DiagramTypeIds[DiagramTypeIds.columnAndLine],
    columnStacked: DiagramTypeIds[DiagramTypeIds.columnStacked],
    line: DiagramTypeIds[DiagramTypeIds.line],
    mapFylker: DiagramTypeIds[DiagramTypeIds.mapFylker],
    mapFylker2019: DiagramTypeIds[DiagramTypeIds.mapFylker2019],
    mapFylker2023: DiagramTypeIds[DiagramTypeIds.mapFylker2023],
    pie: DiagramTypeIds[DiagramTypeIds.pie],
    table: DiagramTypeIds[DiagramTypeIds.table],
};
var ChartTypeIds;
(function (ChartTypeIds) {
    ChartTypeIds[ChartTypeIds["bar"] = 0] = "bar";
    ChartTypeIds[ChartTypeIds["barStacked"] = 1] = "barStacked";
    ChartTypeIds[ChartTypeIds["column"] = 2] = "column";
    ChartTypeIds[ChartTypeIds["columnAndLine"] = 3] = "columnAndLine";
    ChartTypeIds[ChartTypeIds["columnStacked"] = 4] = "columnStacked";
    ChartTypeIds[ChartTypeIds["line"] = 5] = "line";
    ChartTypeIds[ChartTypeIds["pie"] = 6] = "pie";
})(ChartTypeIds || (ChartTypeIds = {}));
// MapTypeIds represents the different topo.json maps currently supported,
var MapTypeIds;
(function (MapTypeIds) {
    MapTypeIds[MapTypeIds["mapFylker"] = 0] = "mapFylker";
    MapTypeIds[MapTypeIds["mapFylker2019"] = 1] = "mapFylker2019";
    MapTypeIds[MapTypeIds["mapFylker2023"] = 2] = "mapFylker2023";
})(MapTypeIds || (MapTypeIds = {}));
const MapTypeIdValues = {
    mapFylker: MapTypeIds[MapTypeIds.mapFylker],
    mapFylker2019: MapTypeIds[MapTypeIds.mapFylker2019],
    mapFylker2023: MapTypeIds[MapTypeIds.mapFylker2023],
};

var DiagramSerieNameSeperator;
(function (DiagramSerieNameSeperator) {
    DiagramSerieNameSeperator["input"] = "|";
    DiagramSerieNameSeperator["output"] = " | ";
})(DiagramSerieNameSeperator || (DiagramSerieNameSeperator = {}));

const OptionsChartTypeBar = {
    chart: {
        type: 'bar',
    },
    plotOptions: {
        bar: {
            dataLabels: {
                enabled: false,
            },
        },
    },
};

const stackingValue$1 = 'normal';
const OptionsChartTypeBarStacked = {
    chart: {
        type: 'bar',
    },
    plotOptions: {
        series: {
            stacking: stackingValue$1,
        },
    },
};

const OptionsChartTypeColumn = {
    chart: {
        type: 'column',
    },
    plotOptions: {
        column: {
            dataLabels: {
                enabled: false,
            },
        },
    },
};

const tickmarkPlacement$1 = 'on';
const OptionsChartTypeColumnAndLine = {
    chart: {},
    plotOptions: {
        column: {
            dataLabels: {
                enabled: false,
            },
        },
        line: {
            marker: {
                symbol: 'circle',
                radius: 2.5,
            },
        },
    },
    xAxis: {
        tickLength: 7,
        tickmarkPlacement: tickmarkPlacement$1,
        tickWidth: 1,
    },
};

const stackingValue = 'normal';
const OptionsChartTypeColumnStacked = {
    chart: {
        type: 'column',
    },
    plotOptions: {
        series: {
            stacking: stackingValue,
        },
    },
};

const tickmarkPlacement = 'on';
const OptionsChartTypeLine = {
    chart: {
        type: 'line',
    },
    plotOptions: {
        line: {
            marker: {
                symbol: 'circle',
                radius: 2.5,
            },
        },
    },
    xAxis: {
        tickLength: 7,
        tickmarkPlacement: tickmarkPlacement,
        tickWidth: 1,
    },
};

const alignValueCenter = 'center';
const alignValueLeft = 'left';
const layoutValueVertical = 'vertical';
const verticalAlignValueTop = 'top';
const OptionsChartTypePie = {
    chart: {
        type: 'pie',
    },
    plotOptions: {
        pie: {
            dataLabels: {
                enabled: false,
            },
            showInLegend: true,
            size: '80%',
            innerSize: '0%',
        },
    },
    legend: {
        align: alignValueLeft,
        maxHeight: 350,
        itemMarginBottom: 3,
        itemMarginTop: 3,
        layout: layoutValueVertical,
        title: {
            text: undefined,
        },
        verticalAlign: verticalAlignValueTop,
    },
    responsive: {
        rules: [
            {
                chartOptions: {
                    legend: {
                        align: alignValueCenter,
                        margin: 0,
                        maxHeight: 120,
                    },
                },
                condition: {
                    maxWidth: 400,
                },
            },
        ],
    },
};

// Charts
const bar = {
    id: DiagramTypeIdValues.bar,
    icon: 'bar-chart-line-horizontal',
    name: 'Liggende søylediagram',
    options: OptionsChartTypeBar,
};
const barStacked = {
    id: DiagramTypeIdValues.barStacked,
    icon: 'bar-chart-line-stacked-horizontal',
    name: 'Stablet liggende søylediagram',
    options: OptionsChartTypeBarStacked,
};
const column = {
    id: DiagramTypeIdValues.column,
    icon: 'bar-chart-line',
    name: 'Søylediagram',
    options: OptionsChartTypeColumn,
};
const columnAndLine = {
    id: DiagramTypeIdValues.columnAndLine,
    name: 'Dobbel akse, linje og søyle',
    options: OptionsChartTypeColumnAndLine,
};
const columnStacked = {
    id: DiagramTypeIdValues.columnStacked,
    icon: 'bar-chart-line-stacked',
    name: 'Stablet søylediagram',
    options: OptionsChartTypeColumnStacked,
};
const line = {
    id: DiagramTypeIdValues.line,
    icon: 'graph-up',
    name: 'Linjediagram',
    options: OptionsChartTypeLine,
};
const pie = {
    id: DiagramTypeIdValues.pie,
    icon: 'pie-chart',
    name: 'Kakediagram',
    options: OptionsChartTypePie,
};
// Maps
const mapShared = {
    icon: 'geo-alt',
    options: {
        chart: {
            map: undefined,
        },
    },
};
const mapFylker = {
    id: DiagramTypeIdValues.mapFylker,
    name: 'Kart (fylker)',
    ...mapShared,
};
const mapFylker2019 = {
    id: DiagramTypeIdValues.mapFylker2019,
    name: 'Kart (fylker 2019)',
    ...mapShared,
};
const mapFylker2023 = {
    id: DiagramTypeIdValues.mapFylker2023,
    name: 'Kart (fylker 2023)',
    ...mapShared,
};
// Table
const table = {
    id: DiagramTypeIdValues.table,
    icon: 'table',
    name: 'Tabell',
};
// All diagram types
class DiagramTypes {
    static { this.bar = bar; }
    static { this.barStacked = barStacked; }
    static { this.column = column; }
    static { this.columnAndLine = columnAndLine; }
    static { this.columnStacked = columnStacked; }
    static { this.line = line; }
    static { this.mapFylker = mapFylker; }
    static { this.mapFylker2019 = mapFylker2019; }
    static { this.mapFylker2023 = mapFylker2023; }
    static { this.pie = pie; }
    static { this.table = table; }
}
const AllDiagramTypes = [
    bar,
    barStacked,
    column,
    columnAndLine,
    columnStacked,
    line,
    mapFylker,
    mapFylker2019,
    mapFylker2023,
    pie,
    table,
];
const ChartTypes = [line, column, bar, columnStacked, barStacked, pie, columnAndLine];
const MapTypes = [mapFylker, mapFylker2019, mapFylker2023];
// For the public API Surface
class FhiDiagramTypes {
    static { this.bar = {
        id: bar.id,
        name: bar.name,
    }; }
    static { this.barStacked = {
        id: barStacked.id,
        name: barStacked.name,
    }; }
    static { this.column = {
        id: column.id,
        name: column.name,
    }; }
    static { this.columnAndLine = {
        id: columnAndLine.id,
        name: columnAndLine.name,
    }; }
    static { this.columnStacked = {
        id: columnStacked.id,
        name: columnStacked.name,
    }; }
    static { this.line = {
        id: line.id,
        name: line.name,
    }; }
    static { this.mapFylker = {
        id: mapFylker.id,
        name: mapFylker.name,
    }; }
    static { this.mapFylker2019 = {
        id: mapFylker2019.id,
        name: mapFylker2019.name,
    }; }
    static { this.mapFylker2023 = {
        id: mapFylker2023.id,
        name: mapFylker2023.name,
    }; }
    static { this.pie = {
        id: pie.id,
        name: pie.name,
    }; }
    static { this.table = {
        id: table.id,
        name: table.name,
    }; }
}

const DiagramTypeGroupNames = {
    chart: 'Graf',
    map: 'Kart',
    table: 'Tabell',
};
const DiagramTypeGroups = [
    {
        children: [DiagramTypes.table],
        diagramType: DiagramTypes.table,
        name: DiagramTypeGroupNames.table,
    },
    {
        children: MapTypes,
        diagramType: DiagramTypes.mapFylker,
        name: DiagramTypeGroupNames.map,
    },
    {
        children: ChartTypes,
        diagramType: DiagramTypes.line,
        name: DiagramTypeGroupNames.chart,
    },
];

class DownloadService {
    downloadImage(chartInstance, MIMEtype, title) {
        if (!chartInstance) {
            console.warn(`No "chartInstance", can't download chart.`);
            return;
        }
        const exportingOptions = {
            type: MIMEtype,
            sourceWidth: 1200,
            sourceHeight: 800,
            filename: this.getFilename(title),
        };
        chartInstance.exportChartLocal(exportingOptions);
    }
    getFilename(title) {
        const formattedTitle = title.replace(/ /gi, '-').replace(/,/gi, '').replace(/---/gi, '-');
        const today = formatDate(new Date(), 'yyyy-MM-dd', 'nb-NO');
        const filename = today.concat('.', formattedTitle.toLowerCase());
        return filename;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: DownloadService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: DownloadService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: DownloadService, decorators: [{
            type: Injectable
        }] });

const OptionsChartsAndMaps = {
    chart: {
        styledMode: true,
        spacingBottom: 35,
    },
    caption: {
        useHTML: true,
        y: 25,
    },
    credits: {
        enabled: true,
        position: {
            align: 'left',
            verticalAlign: 'bottom',
            x: 10,
        },
    },
    series: [],
    title: {
        text: undefined,
    },
    exporting: {
        allowHTML: true,
        buttons: {
            contextButton: {
                enabled: false,
            },
        },
        csv: {
            itemDelimiter: ';',
            columnHeaderFormatter: (item) => {
                if (!item || item instanceof Axis) {
                    return '';
                }
                else {
                    return item.name;
                }
            },
        },
        fallbackToExportServer: false,
    },
};

const OptionsCharts = {
    chart: {
        colorCount: 20,
    },
    legend: {
        align: 'left',
        verticalAlign: 'top',
        margin: 25,
        maxHeight: 150,
        symbolPadding: 10,
        symbolWidth: 1,
    },
    xAxis: {
        allowDecimals: false,
        type: 'category',
        title: {
            text: undefined,
        },
    },
    yAxis: {
        allowDecimals: false,
        title: {
            text: undefined,
        },
    },
};

const legendAlignValue = 'center';
const legendVerticalAlignValue = 'bottom';
const legendOptionsLayoutValue = 'horizontal';
const buttonOptionsVerticalAlignValue = 'top';
const OptionsMaps = {
    chart: {
        marginTop: 50,
    },
    credits: {
        mapText: '. <a href="{geojson.copyrightUrl}">Kartdata fra \u00a9 {geojson.copyrightShort}</a>',
        mapTextFull: undefined,
    },
    legend: {
        align: legendAlignValue,
        borderWidth: 0,
        layout: legendOptionsLayoutValue,
        verticalAlign: legendVerticalAlignValue,
    },
    mapNavigation: {
        enabled: true,
        buttonOptions: {
            verticalAlign: buttonOptionsVerticalAlignValue,
        },
    },
};

class TopoJsonService {
    constructor(httpClient) {
        this.httpClient = httpClient;
        this.topoJsonMaps = {};
    }
    setCurrentMapTypeId(mapTypeId) {
        this.currentMapTypeId = mapTypeId;
    }
    getMapCopyright() {
        return {
            text: this.topoJsonMaps[this.currentMapTypeId]['copyrightShort'],
            url: this.topoJsonMaps[this.currentMapTypeId]['copyrightUrl'],
        };
    }
    getMap(mapTypeId) {
        const maps = this.getMapUrls();
        const map = maps.find((map) => map.id === mapTypeId);
        if (map !== undefined) {
            return this.httpClient.get(map.url);
        }
        throw new Error(`No supported map matches given mapTypeId, can't get map!`);
    }
    addMap(map, mapTypeId) {
        this.topoJsonMaps[mapTypeId] = map;
    }
    getHighmapsSerie(serie) {
        let mapSerie;
        serie.data.forEach((dataPoint, index) => {
            if (index === 0) {
                mapSerie = {
                    data: [this.getMapSerieDataPoint(dataPoint)],
                    name: serie.name,
                    type: 'map',
                };
            }
            else if (mapSerie.data !== undefined) {
                mapSerie.data.push(this.getMapSerieDataPoint(dataPoint));
            }
        });
        return mapSerie;
    }
    getMapSerieDataPoint(dataPoint) {
        const id = this.currentMapTypeId;
        const geometries = this.topoJsonMaps[id]['objects'].default.geometries;
        const geometry = geometries.find((geometry) => geometry['properties'].name === dataPoint.name);
        if (geometry !== undefined) {
            return [geometry['properties']['hc-key'], dataPoint.y];
        }
        console.warn(`Data point name "${dataPoint.name}" doesn't match any geo names in given TopoJson file.`);
    }
    getMapUrls() {
        const baseUrl = 'https://code.highcharts.com/mapdata/';
        const maps = [
            {
                id: MapTypeIdValues.mapFylker,
                url: baseUrl + 'countries/no/no-all.topo.json',
            },
            {
                id: MapTypeIdValues.mapFylker2019,
                url: baseUrl + 'historical/countries/no-2019/no-all-2019.topo.json',
            },
            {
                id: MapTypeIdValues.mapFylker2023,
                url: baseUrl + 'historical/countries/no-2023/no-all-2023.topo.json',
            },
        ];
        return maps;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: TopoJsonService, deps: [{ token: i1.HttpClient }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: TopoJsonService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: TopoJsonService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.HttpClient }] });

class MetadataForSeriesService {
    resetMetadataForSeries() {
        this.metadataForSeries = [];
    }
    get hasPositiveData() {
        return !!this.metadataForSeries.find((serie) => serie.hasPositiveData);
    }
    get hasNegativeData() {
        return !!this.metadataForSeries.find((serie) => serie.hasNegativeData);
    }
    get hasDecimalData() {
        return !!this.metadataForSeries.find((serie) => serie.hasDecimalData);
    }
    getMaxDecimals(serieName) {
        const metadataForSerie = this.metadataForSeries.find((serie) => serie.name === serieName);
        return metadataForSerie.maxDecimals;
    }
    getDecimalCount(value) {
        if (typeof value !== 'number')
            return 0;
        if (Math.floor(value) === value)
            return 0;
        return value.toString().split('.')[1].length || 0;
    }
    getIsDecimalNumber(value) {
        return typeof value === 'number' && !Number.isInteger(value);
    }
    updateMetadataForSeries(serie, units) {
        this.metadataForSeries.push({
            name: serie.name,
            hasDecimalData: this.serieHasDecimalDataPoints(serie),
            hasNegativeData: this.serieHasNegativeDataPoints(serie),
            hasPositiveData: this.serieHasPositiveDataPoints(serie),
            maxDecimals: this.getVerifiedMaxDecimalCount(serie, units),
        });
    }
    getVerifiedMaxDecimalCount(serie, units) {
        let unit = units?.find((unit) => unit.id === serie.unitId);
        if (!unit && units?.length === 1) {
            unit = units[0];
        }
        if (unit?.decimals !== undefined &&
            unit?.decimals !== null &&
            unit?.decimals >= 0 &&
            unit?.decimals <= 9) {
            return unit.decimals;
        }
        if (unit?.decimals > 9) {
            console.warn('Max decimal places is 9 because Highcharts tooltips fails if 10 decimals or more.');
        }
        if (unit?.decimals === null) {
            throw new Error('"null" is not a supported type for "unit.decimals"');
        }
        return 9;
    }
    serieHasDecimalDataPoints(serie) {
        const decimalData = serie.data.filter((dataPoint) => this.getIsDecimalNumber(dataPoint.y));
        return decimalData.length !== 0;
    }
    serieHasNegativeDataPoints(serie) {
        const negativeData = serie.data.filter((dataPoint) => typeof dataPoint.y === 'number' && dataPoint.y < 0);
        return negativeData.length > 0;
    }
    serieHasPositiveDataPoints(serie) {
        const positiveData = serie.data.filter((dataPoint) => typeof dataPoint.y === 'number' && dataPoint.y >= 0);
        return positiveData.length > 0;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: MetadataForSeriesService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: MetadataForSeriesService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: MetadataForSeriesService, decorators: [{
            type: Injectable
        }] });

class OptionsService {
    constructor(topoJsonService, metadataForSeriesService) {
        this.topoJsonService = topoJsonService;
        this.metadataForSeriesService = metadataForSeriesService;
        this.allStaticOptions = new Map();
        this.setAllStaticOptions();
    }
    updateOptions(diagramOptions) {
        let options = cloneDeep(this.allStaticOptions.get(diagramOptions.activeDiagramType));
        this.diagramOptions = diagramOptions;
        this.isMap = this.getIsMap(options);
        options = this.updateChartAndMapOptions(options);
        options = this.isMap ? this.updateMapOptions(options) : this.updateChartOptions(options);
        return this.updateOptionsForCurrentDiagramType(options);
    }
    getIsMap(options) {
        return !!(options?.chart && 'map' in options.chart);
    }
    setAllStaticOptions() {
        AllDiagramTypes.forEach((FhiDiagramType) => {
            const options = FhiDiagramType.options;
            const staticOptions = this.setStaticOptions(options);
            this.allStaticOptions.set(FhiDiagramType.id, staticOptions);
        });
    }
    setStaticOptions(options) {
        const chartsAndMaps = cloneDeep(OptionsChartsAndMaps);
        const current = this.getIsMap(options) ? cloneDeep(OptionsMaps) : cloneDeep(OptionsCharts);
        return merge(chartsAndMaps, current, options);
    }
    updateChartAndMapOptions(options) {
        this.diagramOptions.series.forEach((serie, i) => {
            options.series[i] = {
                name: serie.name,
                data: this.updateSerieData(serie.data),
            };
        });
        if (!this.diagramOptions.openSource) {
            options.credits = { enabled: false };
        }
        options.tooltip = {
            formatter: this.getTooltipFormatterCallbackFunction(),
        };
        return options;
    }
    updateSerieData(data) {
        if (this.diagramOptions.activeDiagramType === DiagramTypeIdValues.line) {
            return this.getDataWithoutStringDataPoints(data);
        }
        return this.getDataWithoutFlaggedDataPoints(data);
    }
    getDataWithoutStringDataPoints(data) {
        const dataWithoutStrings = cloneDeep(data);
        dataWithoutStrings.forEach((dataPoint) => {
            if (typeof dataPoint.y === 'string') {
                dataPoint.y = null;
            }
        });
        return dataWithoutStrings;
    }
    getDataWithoutFlaggedDataPoints(data) {
        return cloneDeep(data).filter((dataPoint) => typeof dataPoint.y !== 'string');
    }
    updateChartOptions(options) {
        options.xAxis = this.getXAxis(options.xAxis, this.diagramOptions);
        if (this.diagramOptions.units?.length === 1) {
            options.yAxis = this.getYAxis(options.yAxis, this.diagramOptions.units[0]);
        }
        else {
            options.yAxis = this.getYAxis(options.yAxis);
        }
        return options;
    }
    updateMapOptions(options) {
        const colorAxis = options.colorAxis;
        const stopsPositive = [
            [0, '#ffffff'],
            [0.17, '#c8e1ec'], // B2-90
            [0.33, '#8fc5dc'], // B2-80
            [0.5, '#65a9c5'], // B2-70
            [0.67, '#4089a7'], // B2-60
            [0.83, '#2a6a82'], // B2-50
            [1, '#234e5f'], // B2-40
        ];
        const stopsNegative = [
            [0, '#7b2623'], // R1-40
            [0.17, '#a93c38'], // R1-50
            [0.33, '#d74b46'], // R1-60
            [0.5, '#ec7c73'], // R1-70
            [0.67, '#fda49b'], // R1-80
            [0.83, '#ffd2cc'], // R1-90
            [1, '#ffffff'],
        ];
        const stopsNegativeAndPositive = [
            [0, '#7b2623'], // R1-40
            [0.08, '#a93c38'], // R1-50
            [0.17, '#d74b46'], // R1-60
            [0.25, '#ec7c73'], // R1-70
            [0.33, '#fda49b'], // R1-80
            [0.42, '#ffd2cc'], // R1-90
            [0.5, '#ffffff'],
            [0.58, '#c8e1ec'], // B2-90
            [0.67, '#8fc5dc'], // B2-80
            [0.75, '#65a9c5'], // B2-70
            [0.83, '#4089a7'], // B2-60
            [0.92, '#2a6a82'], // B2-50
            [1, '#234e5f'], // B2-40
        ];
        if (this.metadataForSeriesService.hasNegativeData &&
            this.metadataForSeriesService.hasPositiveData) {
            options.colorAxis = { ...colorAxis, stops: stopsNegativeAndPositive };
        }
        else if (this.metadataForSeriesService.hasNegativeData) {
            options.colorAxis = { ...colorAxis, stops: stopsNegative };
        }
        else {
            options.colorAxis = { ...colorAxis, stops: stopsPositive };
        }
        options.chart.map = this.diagramOptions.activeDiagramType;
        options.series = [this.topoJsonService.getHighmapsSerie(options.series[0])];
        return options;
    }
    updateOptionsForCurrentDiagramType(options) {
        switch (this.diagramOptions.activeDiagramType) {
            case DiagramTypeIdValues.pie:
                if (options.legend && options.legend.title) {
                    options.legend.title.text = options.series[0].name;
                }
                break;
            case DiagramTypeIdValues.columnAndLine:
                if (this.diagramOptions.units?.length === 2) {
                    options = this.updateOptionsForDiagramTypeColumnAndLine(options);
                }
                break;
        }
        return options;
    }
    updateOptionsForDiagramTypeColumnAndLine(options) {
        const units = this.diagramOptions.units;
        this.diagramOptions.series.forEach((serie, i) => {
            if (units[0].id === serie.unitId) {
                options.series[i] = {
                    ...options.series[i],
                    tooltip: this.getTooltip(units[0]),
                    yAxis: 0,
                    type: 'column',
                    zIndex: 0,
                };
            }
            else if (units[1].id === serie.unitId) {
                options.series[i] = {
                    ...options.series[i],
                    tooltip: this.getTooltip(units[1]),
                    yAxis: 1,
                    type: 'line',
                    zIndex: 1,
                };
            }
        });
        options.yAxis = [
            this.getYAxis({}, units[0]),
            {
                ...this.getYAxis({}, units[1]),
                opposite: true,
            },
        ];
        return options;
    }
    getTooltipFormatterCallbackFunction() {
        const service = this.metadataForSeriesService;
        const isMap = this.isMap;
        return function (tooltip) {
            const value = isMap ? this.point.value : this.point.y;
            const maxDecimals = service.getMaxDecimals(this.series.name);
            const isDecimalNumber = service.getIsDecimalNumber(value);
            const decimalCount = service.getDecimalCount(value);
            let valueDecimals;
            if (isDecimalNumber && decimalCount > maxDecimals) {
                valueDecimals = maxDecimals;
            }
            else {
                valueDecimals = decimalCount;
            }
            this.point.series['tooltipOptions'].valueDecimals = valueDecimals;
            return tooltip.defaultFormatter.call(this, tooltip);
        };
    }
    getTooltip(unit) {
        const tooltip = {};
        if (unit.symbol) {
            if (unit.position === 'start') {
                tooltip.valuePrefix = unit.symbol + ' ';
            }
            else {
                tooltip.valueSuffix = ' ' + unit.symbol;
            }
        }
        return tooltip;
    }
    getXAxis(xAxis, diagramOptions) {
        xAxis = xAxis ? xAxis : {};
        xAxis.title.text = diagramOptions.categoryAxis?.title;
        return xAxis;
    }
    getYAxis(yAxis, unit) {
        yAxis = yAxis ? yAxis : {};
        if (this.metadataForSeriesService.hasDecimalData) {
            yAxis.allowDecimals = true;
        }
        if (this.metadataForSeriesService.hasNegativeData) {
            yAxis.min = undefined;
        }
        if (unit !== undefined) {
            yAxis.title = {
                text: unit.label,
            };
            if (unit.symbol && unit.position) {
                yAxis.labels = {
                    format: unit.position === 'start' ? `${unit.symbol} {value}` : `{value} ${unit.symbol}`,
                };
            }
            else {
                yAxis.labels = {
                    format: '{value}',
                };
            }
            if (unit.yAxisMax !== undefined) {
                yAxis.max = unit.yAxisMax;
            }
            if (unit.yAxisMin !== undefined) {
                yAxis.min = unit.yAxisMin;
            }
        }
        return yAxis;
    }
    /**
     * The following date formatting methods are currently not in use,
     * but they are kept around since they probably will be reintroduced.
     */
    getFormattedLabels(series) {
        const isDayLabels = isValid(parseISO(this.getISO8601DataFromNorwegianDate(series[0].data[0].name)));
        if (isDayLabels) {
            if (series[0].data.length > 60) {
                return this.formatDayLabelsForFirstDayInMonthsAsLLL();
            }
            else {
                return this.formatDayLabelsAsDaySlashMonth();
            }
        }
        return {};
    }
    formatDayLabelsForFirstDayInMonthsAsLLL() {
        return {
            step: 1,
            formatter: (that) => {
                const value = that.value.toString();
                if (value.substring(0, 2) === '01') {
                    return formatDate(this.getISO8601DataFromNorwegianDate(value), 'LLL', 'nb-NO');
                }
                else {
                    return value;
                }
            },
        };
    }
    formatDayLabelsAsDaySlashMonth() {
        return {
            formatter: (that) => {
                const value = that.value.toString();
                return formatDate(this.getISO8601DataFromNorwegianDate(value), 'd/M', 'nb-NO');
            },
        };
    }
    getISO8601DataFromNorwegianDate(nbNODate) {
        const dateList = nbNODate.split('.');
        return `${dateList[2]}-${dateList[1]}-${dateList[0]}`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: OptionsService, deps: [{ token: TopoJsonService }, { token: MetadataForSeriesService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: OptionsService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: OptionsService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: TopoJsonService }, { type: MetadataForSeriesService }] });

var msgId;
(function (msgId) {
    msgId[msgId["hasFlaggedData"] = 0] = "hasFlaggedData";
    msgId[msgId["moreThanOneSeries"] = 1] = "moreThanOneSeries";
    msgId[msgId["notAllUnitsFoundInSeries"] = 2] = "notAllUnitsFoundInSeries";
    msgId[msgId["notGeo"] = 3] = "notGeo";
    msgId[msgId["notMaxOneUnitInSeries"] = 4] = "notMaxOneUnitInSeries";
    msgId[msgId["notTwoUnitsInSeries"] = 5] = "notTwoUnitsInSeries";
    msgId[msgId["notTwoUnits"] = 6] = "notTwoUnits";
    msgId[msgId["onlyOneSerieAndAllDataAreFlagged"] = 7] = "onlyOneSerieAndAllDataAreFlagged";
})(msgId || (msgId = {}));
class DiagramTypeGroupService {
    constructor() {
        this.diagramTypeDisabledWarnings = {};
        this.diagramTypeDisabledWarningMessages = {
            [msgId.hasFlaggedData]: 'series.length > 1 && flaggedSeries?.length !== 0',
            [msgId.moreThanOneSeries]: 'series.length > 1',
            [msgId.notAllUnitsFoundInSeries]: 'notAllUnitsFoundInSeries',
            [msgId.notGeo]: 'series.length === 1 && serieNotGeo(this.series[0])',
            [msgId.notMaxOneUnitInSeries]: 'this.uniqueUnitIdCountInSeries() > 1',
            [msgId.notTwoUnitsInSeries]: 'this.uniqueUnitIdCountInSeries() !== 2',
            [msgId.notTwoUnits]: 'diagramOptions.units?.length !== 2',
            [msgId.onlyOneSerieAndAllDataAreFlagged]: 'onlyOneSerieAndAllDataAreFlagged',
        };
    }
    getDiagramTypeDisabledWarningMsg(activeDiagramType) {
        return this.diagramTypeDisabledWarnings[activeDiagramType];
    }
    getActiveDiagramTypeGroup(groups) {
        return groups.find((group) => group.diagramType.active);
    }
    getDiagramTypeGroups(diagramOptions, flaggedSeries, previousDiagramTypeGroups) {
        this.diagramOptions = diagramOptions;
        this.series = diagramOptions.series;
        this.flaggedSeries = flaggedSeries;
        this.activeDiagramType = undefined;
        return this.createGroups(previousDiagramTypeGroups);
    }
    getDiagramTypeIsDisabled(groups, diagramTypeId) {
        let disabled = false;
        groups.forEach((group) => {
            group.children.forEach((diagramType) => {
                if (diagramTypeId === diagramType.id && diagramType.disabled) {
                    disabled = true;
                }
            });
        });
        if (disabled) {
            return true;
        }
        return false;
    }
    createGroups(previousGroups) {
        const groups = [];
        cloneDeep$1(DiagramTypeGroups).forEach((group) => {
            groups.push(this.removeOrAddDiagramTypes(group));
        });
        this.updateChildrenDiagramTypeStates(groups);
        this.updateActiveDiagramType(groups);
        this.updateGroupDiagramTypeStates(groups, previousGroups);
        return groups.filter((group) => group.children?.length > 0);
    }
    updateChildrenDiagramTypeStates(groups) {
        groups.forEach((group) => {
            group.children.forEach((diagramType) => {
                diagramType.disabled = this.diagramTypeIsDisabled(diagramType);
                diagramType.active = this.diagramTypeIsActive(diagramType, groups);
            });
        });
    }
    updateActiveDiagramType(groups) {
        groups.forEach((group) => {
            const activeChild = group.children.find((diagramType) => diagramType.active);
            if (activeChild !== undefined) {
                this.activeDiagramType = activeChild;
            }
        });
    }
    updateGroupDiagramTypeStates(groups, previousGroups) {
        groups.forEach((group, index) => {
            const activeChild = group.children.find((diagramType) => diagramType.id === this.activeDiagramType.id);
            const previousActiveChild = group.children.find((diagramType) => {
                if (previousGroups !== undefined) {
                    return diagramType.id === previousGroups[index]?.diagramType.id;
                }
            });
            if (activeChild !== undefined) {
                group.diagramType = activeChild;
            }
            else if (previousActiveChild !== undefined) {
                group.diagramType = previousActiveChild;
            }
            else {
                group.diagramType = group.children[0];
            }
        });
    }
    removeOrAddDiagramTypes(group) {
        if (group.name === DiagramTypeGroupNames.table) {
            return group;
        }
        const navigation = this.diagramOptions.controls?.navigation;
        const items = navigation?.items;
        const isChart = group.name === DiagramTypeGroupNames.chart;
        const isMap = group.name === DiagramTypeGroupNames.map;
        if (!navigation || !navigation.show) {
            return group;
        }
        group.children = [];
        if ((isChart && !items?.chartTypes) || (isMap && !items?.mapTypes)) {
            return group;
        }
        if (isChart) {
            items.chartTypes.forEach((id) => {
                this.updateDiagramTypeGroup(id, group, ChartTypes, 'Chart');
            });
        }
        if (isMap) {
            items.mapTypes.forEach((id) => {
                this.updateDiagramTypeGroup(id, group, MapTypes, 'Map');
            });
        }
        return group;
    }
    updateDiagramTypeGroup(id, group, Types, typeName) {
        const type = Types.find((type) => type.id === id);
        const typeExist = group.children.find((type) => type.id === id);
        if (type !== undefined && typeExist === undefined) {
            group.children.push(type);
        }
        else if (typeExist) {
            console.warn(typeName + ' type id: "' + id + '" is listed more than once.');
        }
        else {
            console.warn(typeName + ' type id: "' + id + '" is not valid.');
        }
    }
    diagramTypeIsActive(diagramType, groups) {
        const activeFromOptionsNotFoundInGrops = (() => groups.every((group) => group.children.find((diagramType) => diagramType.id === this.diagramOptions.activeDiagramType) === undefined))();
        const fallbackToTable = diagramType.id === DiagramTypes.table.id && activeFromOptionsNotFoundInGrops;
        return diagramType.id === this.diagramOptions.activeDiagramType || fallbackToTable;
    }
    diagramTypeIsDisabled(diagramType) {
        if (this.isAnyTypeButTable(diagramType)) {
            if (this.onlyOneSerieAndAllDataAreFlagged(diagramType))
                return true;
        }
        if (this.isAnyTypeButTableOrColumnAndLine(diagramType)) {
            if (this.notMaxOneUnitInSeries(diagramType))
                return true;
        }
        if (this.isBarOrColumnType(diagramType)) {
            if (this.hasFlaggedData(diagramType))
                return true;
        }
        if (this.isMapOrPieType(diagramType)) {
            if (this.moreThanOneSeries(diagramType))
                return true;
        }
        if (this.isMapType(diagramType)) {
            if (this.notGeo(diagramType))
                return true;
        }
        if (diagramType.id === DiagramTypes.columnAndLine.id) {
            if (this.notTwoUnits(diagramType))
                return true;
            if (this.notTwoUnitsInSeries(diagramType))
                return true;
            if (this.notAllUnitsFoundInSeries(diagramType))
                return true;
        }
        return false;
    }
    isBarOrColumnType(diagramType) {
        return (diagramType.id === DiagramTypes.bar.id ||
            diagramType.id === DiagramTypes.barStacked.id ||
            diagramType.id === DiagramTypes.column.id ||
            diagramType.id === DiagramTypes.columnAndLine.id ||
            diagramType.id === DiagramTypes.columnStacked.id);
    }
    isMapType(diagramType) {
        return (diagramType.id === DiagramTypes.mapFylker.id ||
            diagramType.id === DiagramTypes.mapFylker2019.id ||
            diagramType.id === DiagramTypes.mapFylker2023.id);
    }
    isMapOrPieType(diagramType) {
        return this.isMapType(diagramType) || diagramType === DiagramTypes.pie;
    }
    isAnyTypeButTable(diagramType) {
        return diagramType.id !== DiagramTypes.table.id;
    }
    isAnyTypeButTableOrColumnAndLine(diagramType) {
        return !(diagramType.id === DiagramTypes.table.id || diagramType.id === DiagramTypes.columnAndLine.id);
    }
    hasFlaggedData(diagramType) {
        if (this.series.length > 1 && this.flaggedSeries?.length !== 0) {
            this.updateDisabledWarnings(diagramType.id, msgId.hasFlaggedData);
            return true;
        }
        return false;
    }
    moreThanOneSeries(diagramType) {
        if (this.series.length > 1) {
            this.updateDisabledWarnings(diagramType.id, msgId.moreThanOneSeries);
            return true;
        }
        return false;
    }
    notAllUnitsFoundInSeries(diagramType) {
        const allUnitsFoundInSeries = this.diagramOptions.units.every((unit) => this.series.some((serie) => serie.unitId === unit.id));
        if (!allUnitsFoundInSeries) {
            this.updateDisabledWarnings(diagramType.id, msgId.notAllUnitsFoundInSeries);
            return true;
        }
        return false;
    }
    notGeo(diagramType) {
        if (this.series.length === 1 && this.serieNotGeo(this.series[0])) {
            this.updateDisabledWarnings(diagramType.id, msgId.notGeo);
            return true;
        }
        return false;
    }
    notMaxOneUnitInSeries(diagramType) {
        if (this.uniqueUnitIdCountInSeries() > 1) {
            this.updateDisabledWarnings(diagramType.id, msgId.notMaxOneUnitInSeries);
            return true;
        }
        return false;
    }
    notTwoUnitsInSeries(diagramType) {
        if (this.uniqueUnitIdCountInSeries() !== 2) {
            this.updateDisabledWarnings(diagramType.id, msgId.notTwoUnitsInSeries);
            return true;
        }
        return false;
    }
    notTwoUnits(diagramType) {
        if (this.diagramOptions.units?.length !== 2) {
            this.updateDisabledWarnings(diagramType.id, msgId.notTwoUnits);
            return true;
        }
        return false;
    }
    onlyOneSerieAndAllDataAreFlagged(diagramType) {
        if (this.series.length === 1 &&
            this.series[0].data.every((dataPoint) => !(typeof dataPoint.y.valueOf() === 'number'))) {
            this.updateDisabledWarnings(diagramType.id, msgId.onlyOneSerieAndAllDataAreFlagged);
            return true;
        }
        return false;
    }
    updateDisabledWarnings(diagramTypeId, messageId) {
        const messages = this.diagramTypeDisabledWarningMessages;
        this.diagramTypeDisabledWarnings[diagramTypeId] = messages[messageId];
    }
    serieNotGeo(serie) {
        const validGeoNames = this.getValidGeoNames();
        // Only testing first data point in serie since all data points should be valid geo
        if (validGeoNames.find((name) => name === serie.data[0].name) === undefined) {
            return true;
        }
        return false;
    }
    uniqueUnitIdCountInSeries() {
        const uniqueIds = new Set();
        this.series.filter((serie) => serie.unitId).forEach((serie) => uniqueIds.add(serie.unitId));
        return uniqueIds.size;
    }
    /**
     * Returns a list of leagal geo names for all maps
     *
     * PS. This gives 1 fact in 2 places, but the the maps will not change
     *     that often, and the benefit of being able to do a "disable map test"
     *     before the maps are loaded makes it worth it.
     */
    getValidGeoNames() {
        const mapFylkerNames = [
            'Akershus',
            'Oslo',
            'Vestland',
            'Rogaland',
            'Trøndelag',
            'Innlandet',
            'Agder',
            'Østfold',
            'Møre og Romsdal',
            'Buskerud',
            'Vestfold',
            'Nordland',
            'Telemark',
            'Troms',
            'Finnmark',
        ];
        const mapFylker2019Names = [
            'Romsdal',
            'Sør-Trøndelag',
            'Hordaland',
            'Sogn og Fjordane',
            'Vest-Agder',
            'Østfold',
            'Nord-Trøndelag',
            'Rogaland',
            'Buskerud',
            'Vestfold',
            'Finnmark',
            'Nordland',
            'Troms',
            'Akershus',
            'Oppland',
            'Hedmark',
            'Oslo',
            'Telemark',
            'Aust-Agder',
        ];
        const mapFylker2023Names = [
            'Vestland',
            'Møre og Romsdal',
            'Agder',
            'Nordland',
            'Viken',
            'Rogaland',
            'Troms og Finnmark',
            'Trøndelag',
            'Oslo',
            'Vestfold og Telemark',
            'Innlandet',
        ];
        return mapFylkerNames.concat(mapFylker2019Names, mapFylker2023Names);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: DiagramTypeGroupService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: DiagramTypeGroupService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: DiagramTypeGroupService, decorators: [{
            type: Injectable
        }] });

var TableOrientations;
(function (TableOrientations) {
    TableOrientations[TableOrientations["seriesAsRows"] = 0] = "seriesAsRows";
    TableOrientations[TableOrientations["seriesAsColumns"] = 1] = "seriesAsColumns";
})(TableOrientations || (TableOrientations = {}));
const TableOrientationValues = {
    seriesAsRows: TableOrientations[TableOrientations.seriesAsRows],
    seriesAsColumns: TableOrientations[TableOrientations.seriesAsColumns],
};

class TableService {
    constructor(metadataForSeriesService) {
        this.metadataForSeriesService = metadataForSeriesService;
    }
    getTable(series, orientation) {
        if (orientation === TableOrientationValues.seriesAsColumns) {
            return {
                theadRows: this.getTableHeaderRows_OrientationColumns(series),
                tbodyRows: this.getTableBodyRows_OrientationColumns(series),
            };
        }
        return {
            theadRows: [this.getTableHeaderRow_OrientationRows(series)],
            tbodyRows: this.getTableBodyRows_OrientationRows(series),
        };
    }
    // -----------------------------
    //  Use series as table columns
    // -----------------------------
    getTableHeaderRows_OrientationColumns(series) {
        const tableHeaderRows = [];
        const dimentionsCount = this.getSerieNameDimentionsCount(series[0].name);
        const colspanCounts = this.getColspanOrRowspanCounts(dimentionsCount, series);
        for (let i = 0; i < dimentionsCount; i++) {
            // Create extra table column for row headers by adding 1
            tableHeaderRows[i] = new Array(series.length + 1);
            for (let j = 0; j < tableHeaderRows[i].length; j++) {
                if (j > 0) {
                    const hasColspan = this.hasColspan(j, colspanCounts[i]);
                    tableHeaderRows[i][j] = {
                        colspan: hasColspan ? colspanCounts[i] : undefined,
                        name: hasColspan ? this.getColumnHeaderName(series[j - 1], i) : undefined,
                        isHeading: true,
                    };
                }
                else if (i === 0) {
                    tableHeaderRows[i][j] = { isHeading: false, rowspan: dimentionsCount };
                }
            }
        }
        return tableHeaderRows;
    }
    getTableBodyRows_OrientationColumns(series) {
        const tbodyRows = new Array(series[0].data.length);
        for (let i = 0; i < tbodyRows.length; i++) {
            // Create extra table column for row headers by adding 1
            tbodyRows[i] = new Array(series.length + 1);
            for (let j = 0; j < tbodyRows[i].length; j++) {
                if (j === 0) {
                    // Table row headings
                    tbodyRows[i][j] = {
                        name: series[j].data[i].name,
                        isHeading: true,
                    };
                }
                else {
                    // Table row data
                    tbodyRows[i][j] = {
                        isHeading: false,
                        data: this.getRoundedData(series[j - 1].name, series[j - 1].data[i].y),
                    };
                }
            }
        }
        return tbodyRows;
    }
    hasColspan(columnIndex, colspanValue) {
        let isColspan = false;
        if (columnIndex === 1 || (columnIndex - 1) % colspanValue === 0) {
            isColspan = true;
        }
        return isColspan;
    }
    getColumnHeaderName(serie, rowIndex) {
        return this.getSerieNameArray(serie.name)[rowIndex];
    }
    // --------------------------
    //  Use series as table rows
    // --------------------------
    getTableHeaderRow_OrientationRows(series) {
        const tableHeaderRow = [];
        series[0].data.forEach((data, i) => {
            if (i === 0) {
                tableHeaderRow[i] = {
                    isHeading: false,
                    colspan: this.getSerieNameDimentionsCount(series[0].name),
                };
            }
            tableHeaderRow[i + 1] = { isHeading: true, name: data.name };
        });
        return tableHeaderRow;
    }
    getTableBodyRows_OrientationRows(series) {
        const dimentionsCount = this.getSerieNameDimentionsCount(series[0].name);
        const rowspanCounts = this.getColspanOrRowspanCounts(dimentionsCount, series);
        const tbodyRows = new Array(series.length);
        for (let i = 0; i < series.length; i++) {
            // Create extra table columns for row headers by adding "SerieNameDimentionsCount"
            tbodyRows[i] = new Array(series[0].data.length + dimentionsCount);
            for (let j = 0; j < tbodyRows[i].length; j++) {
                if (j < dimentionsCount) {
                    // Table row headings
                    const hasRowspan = this.hasRowspan(i, rowspanCounts[j]);
                    tbodyRows[i][j] = {
                        rowspan: hasRowspan && rowspanCounts[j] > 1 ? rowspanCounts[j] : undefined,
                        name: hasRowspan ? this.getRowHeaderName(series[i], j) : undefined,
                        isHeading: true,
                    };
                }
                else {
                    // Table row data
                    tbodyRows[i][j] = {
                        isHeading: false,
                        data: this.getRoundedData(series[i].name, series[i].data[j - dimentionsCount].y),
                    };
                }
            }
        }
        return tbodyRows;
    }
    hasRowspan(rowIndex, rowspanValue) {
        let isRowspan = false;
        if (rowIndex === 0 || rowIndex % rowspanValue === 0) {
            isRowspan = true;
        }
        return isRowspan;
    }
    getRowHeaderName(serie, coloumIndex) {
        return this.getSerieNameArray(serie.name)[coloumIndex];
    }
    // ------------------------------
    //  Shared for both orientations
    // ------------------------------
    getSerieNameArray(name) {
        if (typeof name === 'string') {
            const trimmedNames = [];
            name.split(DiagramSerieNameSeperator.input).forEach((name) => {
                trimmedNames.push(name.trim());
            });
            return trimmedNames;
        }
        return name;
    }
    getSerieNameDimentionsCount(name) {
        if (typeof name === 'string') {
            return name.split(DiagramSerieNameSeperator.input).length;
        }
        return name.length;
    }
    getColspanOrRowspanCounts(dimentionsCount, series) {
        const counts = [];
        let previousCount;
        for (let i = 0; i < dimentionsCount; i++) {
            const names = series.map((serie) => this.getSerieNameArray(serie.name)[i]);
            const uniqueNameCount = new Set(names).size;
            let count;
            if (!previousCount) {
                count = names.length / uniqueNameCount;
            }
            else {
                count = previousCount / uniqueNameCount;
            }
            counts.push(count);
            previousCount = count;
        }
        return counts;
    }
    getRoundedData(serieName, data) {
        const maxDecimals = this.metadataForSeriesService.getMaxDecimals(serieName);
        const decimalCount = this.metadataForSeriesService.getDecimalCount(data);
        if (typeof data === 'number' && decimalCount > maxDecimals) {
            // Fix for rounding errors in toFixed()
            // - based on https://www.sitepoint.com/number-tofixed-rounding-errors-broken-but-fixable
            const split = data.toString().split('.');
            data = +(split.join('.') + '1');
            return data.toFixed(maxDecimals);
        }
        else {
            return data;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: TableService, deps: [{ token: MetadataForSeriesService }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: TableService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: TableService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: MetadataForSeriesService }] });

class FhiDiagramTypeNavDefaultComponent {
    constructor() {
        this.diagramTypeNavigation = new EventEmitter();
    }
    navigate(diagramType) {
        this.diagramTypeNavigation.emit(diagramType);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: FhiDiagramTypeNavDefaultComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.6", type: FhiDiagramTypeNavDefaultComponent, isStandalone: true, selector: "fhi-diagram-type-nav-default", inputs: { diagramTypeGroups: "diagramTypeGroups" }, outputs: { diagramTypeNavigation: "diagramTypeNavigation" }, ngImport: i0, template: "<div class=\"btn-group fhi-btn-group\" role=\"group\">\n  @for (group of diagramTypeGroups; track group.diagramType) {\n    @if (group.children.length === 1) {\n      <button\n        type=\"button\"\n        class=\"btn fhi-btn-group__btn\"\n        [ngClass]=\"{ active: group.diagramType?.active }\"\n        (click)=\"navigate(group.diagramType)\"\n      >\n        <ng-container\n          [ngTemplateOutlet]=\"icon\"\n          [ngTemplateOutletContext]=\"{ icon: group.diagramType?.icon, active: group.diagramType?.active }\"\n        />\n        {{ group.name }}\n      </button>\n    } @else {\n      <div class=\"btn-group\" role=\"group\">\n        <button\n          type=\"button\"\n          class=\"btn fhi-btn-group__btn fhi-btn-group__split-btn\"\n          [ngClass]=\"{ active: group.diagramType?.active }\"\n          (click)=\"navigate(group.diagramType)\"\n        >\n          <span>\n            <ng-container\n              [ngTemplateOutlet]=\"icon\"\n              [ngTemplateOutletContext]=\"{ icon: group.diagramType?.icon, active: group.diagramType?.active }\"\n            />\n            {{ group.name }}\n          </span>\n        </button>\n        <div class=\"btn-group fhi-dropdown\" ngbDropdown role=\"group\" aria-label=\"Button group with nested dropdown\">\n          <button\n            type=\"button\"\n            class=\"btn fhi-btn-group__btn fhi-dropdown__btn fhi-btn-group__split-btn-toggler\"\n            [ngClass]=\"{ active: group.diagramType?.active }\"\n            aria-label=\"Velg noe...\"\n            ngbDropdownToggle\n          ></button>\n          <div class=\"dropdown-menu\" ngbDropdownMenu>\n            @for (diagramType of group.children; track diagramType.id) {\n              <button\n                class=\"text-nowrap\"\n                [ngClass]=\"{ active: diagramType?.active }\"\n                ngbDropdownItem\n                (click)=\"navigate(diagramType)\"\n              >\n                <ng-container\n                  [ngTemplateOutlet]=\"icon\"\n                  [ngTemplateOutletContext]=\"{ icon: diagramType.icon, active: false }\"\n                />\n                {{ diagramType?.name }}\n              </button>\n            }\n          </div>\n        </div>\n      </div>\n    }\n  }\n</div>\n\n<ng-template #icon let-icon=\"icon\" let-active=\"active\">\n  @if (icon) {\n    <i [class]=\"'icon-' + icon\" [ngClass]=\"{ 'icon-white': active }\"></i>\n  }\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: NgbDropdownModule }, { kind: "directive", type: i2.NgbDropdown, selector: "[ngbDropdown]", inputs: ["autoClose", "dropdownClass", "open", "placement", "popperOptions", "container", "display"], outputs: ["openChange"], exportAs: ["ngbDropdown"] }, { kind: "directive", type: i2.NgbDropdownToggle, selector: "[ngbDropdownToggle]" }, { kind: "directive", type: i2.NgbDropdownMenu, selector: "[ngbDropdownMenu]" }, { kind: "directive", type: i2.NgbDropdownItem, selector: "[ngbDropdownItem]", inputs: ["tabindex", "disabled"] }, { kind: "directive", type: i2.NgbDropdownButtonItem, selector: "button[ngbDropdownItem]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: FhiDiagramTypeNavDefaultComponent, decorators: [{
            type: Component,
            args: [{ selector: 'fhi-diagram-type-nav-default', imports: [CommonModule, NgbDropdownModule], template: "<div class=\"btn-group fhi-btn-group\" role=\"group\">\n  @for (group of diagramTypeGroups; track group.diagramType) {\n    @if (group.children.length === 1) {\n      <button\n        type=\"button\"\n        class=\"btn fhi-btn-group__btn\"\n        [ngClass]=\"{ active: group.diagramType?.active }\"\n        (click)=\"navigate(group.diagramType)\"\n      >\n        <ng-container\n          [ngTemplateOutlet]=\"icon\"\n          [ngTemplateOutletContext]=\"{ icon: group.diagramType?.icon, active: group.diagramType?.active }\"\n        />\n        {{ group.name }}\n      </button>\n    } @else {\n      <div class=\"btn-group\" role=\"group\">\n        <button\n          type=\"button\"\n          class=\"btn fhi-btn-group__btn fhi-btn-group__split-btn\"\n          [ngClass]=\"{ active: group.diagramType?.active }\"\n          (click)=\"navigate(group.diagramType)\"\n        >\n          <span>\n            <ng-container\n              [ngTemplateOutlet]=\"icon\"\n              [ngTemplateOutletContext]=\"{ icon: group.diagramType?.icon, active: group.diagramType?.active }\"\n            />\n            {{ group.name }}\n          </span>\n        </button>\n        <div class=\"btn-group fhi-dropdown\" ngbDropdown role=\"group\" aria-label=\"Button group with nested dropdown\">\n          <button\n            type=\"button\"\n            class=\"btn fhi-btn-group__btn fhi-dropdown__btn fhi-btn-group__split-btn-toggler\"\n            [ngClass]=\"{ active: group.diagramType?.active }\"\n            aria-label=\"Velg noe...\"\n            ngbDropdownToggle\n          ></button>\n          <div class=\"dropdown-menu\" ngbDropdownMenu>\n            @for (diagramType of group.children; track diagramType.id) {\n              <button\n                class=\"text-nowrap\"\n                [ngClass]=\"{ active: diagramType?.active }\"\n                ngbDropdownItem\n                (click)=\"navigate(diagramType)\"\n              >\n                <ng-container\n                  [ngTemplateOutlet]=\"icon\"\n                  [ngTemplateOutletContext]=\"{ icon: diagramType.icon, active: false }\"\n                />\n                {{ diagramType?.name }}\n              </button>\n            }\n          </div>\n        </div>\n      </div>\n    }\n  }\n</div>\n\n<ng-template #icon let-icon=\"icon\" let-active=\"active\">\n  @if (icon) {\n    <i [class]=\"'icon-' + icon\" [ngClass]=\"{ 'icon-white': active }\"></i>\n  }\n</ng-template>\n" }]
        }], propDecorators: { diagramTypeGroups: [{
                type: Input
            }], diagramTypeNavigation: [{
                type: Output
            }] } });

var ControlsPopoverMenuActions;
(function (ControlsPopoverMenuActions) {
    ControlsPopoverMenuActions["downloadSvg"] = "downloadSvg";
})(ControlsPopoverMenuActions || (ControlsPopoverMenuActions = {}));
class FhiAngularHighchartsComponent {
    constructor(changeDetector, downloadService, optionsService, diagramTypeGroupService, tableService, topoJsonService, metadataForSeriesService) {
        this.changeDetector = changeDetector;
        this.downloadService = downloadService;
        this.optionsService = optionsService;
        this.diagramTypeGroupService = diagramTypeGroupService;
        this.tableService = tableService;
        this.topoJsonService = topoJsonService;
        this.metadataForSeriesService = metadataForSeriesService;
        this.allSerieNames = [];
        this.diagramTypeNavigation = new EventEmitter();
        this.metadataButtonClick = new EventEmitter();
        this.highcharts = Highcharts;
        this.highmaps = Highmaps;
        this.diagramTypeGroupNames = DiagramTypeGroupNames;
        HighchartsAccessibility(Highcharts);
        HighchartsExporting(Highcharts);
        HighchartsOfflineExporting(Highcharts);
        HighchartsAccessibility(Highmaps);
        HighchartsExporting(Highmaps);
        HighchartsOfflineExporting(Highmaps);
        this.highcharts.setOptions({
            lang: {
                decimalPoint: ',',
            },
        });
    }
    ngOnChanges() {
        this.diagramOptionsInternal = cloneDeep$1(this.diagramOptions);
        this.resetDiagramState();
        try {
            this.diagramOptionsInternal.series.forEach((serie) => {
                serie.name = this.formatSerieName(serie.name);
                this.findDuplicateSerieNames(serie.name);
                this.testForFlaggedDataAndUpdateFlaggedSeries(serie);
                this.metadataForSeriesService.updateMetadataForSeries(serie, this.diagramOptionsInternal.units);
            });
            this.updateDiagramTypeGroups();
            this.updateDiagramOptions();
            this.updateDiagramState();
        }
        catch (error) {
            console.error(this.getErrorMsg(error));
        }
    }
    onChartInstance(chartInstance) {
        this.chartInstance = chartInstance;
    }
    onControlsPopoverMenuAction(actionName) {
        if (actionName === ControlsPopoverMenuActions.downloadSvg) {
            this.downloadService.downloadImage(this.chartInstance, 'image/svg+xml', this.diagramOptionsInternal.title);
        }
    }
    onDiagramTypeNavigation(diagramType) {
        this.diagramTypeNavigation.emit(diagramType.id);
    }
    onMetadataButtonClick() {
        this.metadataButtonClick.emit();
    }
    setDiagramTypeGroupToTable() {
        this.diagramTypeNavigation.emit(DiagramTypeIdValues.table);
    }
    isNumber(data) {
        return typeof data === 'number';
    }
    getFlaggedDataPoints() {
        const flagged = [];
        let n = 0;
        this.flaggedSeries.forEach((serie) => {
            serie.flaggedDataPoints.forEach((dataPoint) => {
                flagged[n++] = serie.name.concat(DiagramSerieNameSeperator.output, dataPoint.name);
            });
        });
        return flagged;
    }
    getMapCopyright() {
        return this.topoJsonService.getMapCopyright();
    }
    resetDiagramState() {
        this.showDiagramTypeNav = false;
        this.showDuplicateSerieNameError = false;
        this.showFullScreenButton = false;
        this.showDiagramTypeDisabledWarning = false;
        this.showFooter = false;
        this.showMap = false;
        this.showMetadataButton = false;
        this.allSerieNames = [];
        this.flaggedSeries = [];
        this.metadataForSeriesService.resetMetadataForSeries();
    }
    formatSerieName(name) {
        if (typeof name === 'string') {
            return name.split(DiagramSerieNameSeperator.input).join(DiagramSerieNameSeperator.output);
        }
        return name.join(DiagramSerieNameSeperator.output);
    }
    findDuplicateSerieNames(serieName) {
        if (this.allSerieNames.find((name) => name === serieName)) {
            this.showDuplicateSerieNameError = true;
        }
        this.allSerieNames.push(serieName);
    }
    testForFlaggedDataAndUpdateFlaggedSeries(serie) {
        const flaggedData = serie.data.filter((dataPoint) => typeof dataPoint.y === 'string');
        if (flaggedData.length !== 0) {
            this.updateFlaggedSeries(serie, flaggedData);
        }
    }
    updateFlaggedSeries(serie, flaggedData) {
        this.flaggedSeries.push({
            name: serie.name,
            flaggedDataPoints: this.getFlaggedDataPointsForCurrentSerie(flaggedData),
        });
    }
    getFlaggedDataPointsForCurrentSerie(data) {
        const flaggedDataPoints = [];
        let n = 0;
        data.forEach((category) => {
            flaggedDataPoints[n++] = {
                name: category.name,
                symbol: category.y,
                label: 'N/A',
            };
        });
        return flaggedDataPoints;
    }
    updateDiagramTypeGroups() {
        this.diagramTypeGroups = this.diagramTypeGroupService.getDiagramTypeGroups(this.diagramOptionsInternal, this.flaggedSeries, this.diagramTypeGroups);
        this.activeDiagramTypeGroup = this.diagramTypeGroupService.getActiveDiagramTypeGroup(this.diagramTypeGroups);
    }
    updateDiagramOptions() {
        const footer = this.diagramOptionsInternal.footer;
        const openSource = this.diagramOptionsInternal.openSource;
        this.diagramOptionsInternal = {
            ...this.diagramOptionsInternal,
            activeDiagramType: this.activeDiagramTypeGroup.diagramType.id,
            footer: footer ? footer : undefined,
            openSource: openSource === undefined || openSource ? true : false,
        };
    }
    updateDiagramState() {
        const diagramTypeIsDisabled = this.diagramTypeGroupService.getDiagramTypeIsDisabled(this.diagramTypeGroups, this.diagramOptionsInternal.activeDiagramType);
        this.showDiagramTypeDisabledWarning = diagramTypeIsDisabled;
        this.showDownloadButton = diagramTypeIsDisabled ? false : this.canShowDownloadButton();
        this.showFooter = diagramTypeIsDisabled ? false : this.canShowFooter();
        this.showFullScreenButton = !!this.diagramOptionsInternal.controls?.fullScreenButton?.show;
        this.showMetadataButton = !!this.diagramOptionsInternal.controls?.metadataButton?.show;
        this.showDiagramTypeNav = !!this.diagramOptionsInternal.controls?.navigation?.show;
        if (!diagramTypeIsDisabled) {
            this.updateDiagram();
        }
        else {
            const activeDiagramType = this.diagramOptionsInternal.activeDiagramType;
            const msg = this.diagramTypeGroupService.getDiagramTypeDisabledWarningMsg(this.diagramOptionsInternal.activeDiagramType);
            console.warn(`Kan ikke vise diagramtype "${activeDiagramType}" fordi "${msg}"`);
        }
    }
    updateDiagram() {
        if (this.activeDiagramTypeGroup.name === DiagramTypeGroupNames.table) {
            this.updateTable();
        }
        else if (this.activeDiagramTypeGroup.name === DiagramTypeGroupNames.map) {
            this.updateMap();
        }
        else {
            this.updateChart();
        }
    }
    updateChart() {
        this.showDefaultChartTemplate = !this.showDefaultChartTemplate;
        this.highchartsOptions = this.optionsService.updateOptions(this.diagramOptionsInternal);
    }
    updateTable() {
        const series = this.diagramOptionsInternal.series;
        this.tableData = this.tableService.getTable(series, this.diagramOptionsInternal.tableOrientation);
    }
    updateMap() {
        const mapTypeId = this.diagramOptionsInternal.activeDiagramType;
        if (this.highmaps.maps && this.highmaps.maps[mapTypeId]) {
            this.topoJsonService.setCurrentMapTypeId(mapTypeId);
            this.highchartsOptions = this.optionsService.updateOptions(this.diagramOptionsInternal);
            this.showMap = true;
            this.changeDetector.detectChanges();
        }
        else {
            this.loadMap(mapTypeId);
        }
    }
    loadMap(mapTypeId) {
        if (this.highmaps.maps === undefined) {
            this.highmaps.maps = [];
        }
        this.topoJsonService
            .getMap(mapTypeId)
            .pipe(first())
            .subscribe({
            next: (map) => {
                if (map !== undefined) {
                    this.highmaps.maps[mapTypeId] = map;
                    this.topoJsonService.addMap(map, mapTypeId);
                    this.updateMap();
                }
            },
            error: (error) => {
                console.error('TopoJson map loading error:', error);
            },
        });
    }
    canShowDownloadButton() {
        return (!!this.diagramOptionsInternal.controls?.downloadButton?.show &&
            this.diagramOptionsInternal.activeDiagramType !== 'table');
    }
    canShowFooter() {
        if (this.showMap && !this.diagramOptionsInternal.openSource) {
            return true;
        }
        if (this.diagramOptionsInternal.footer?.flags) {
            return true;
        }
        if (this.diagramOptionsInternal.footer?.lastUpdated) {
            return true;
        }
        if (this.diagramOptionsInternal.footer?.disclaimer) {
            return true;
        }
        if (this.diagramOptionsInternal.footer?.credits) {
            return true;
        }
        if (this.diagramOptionsInternal.units?.length > 0) {
            return true;
        }
        return false;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    getErrorMsg(error) {
        return `${error}

    To avoid this error message:
    Make sure [yourOptions] are valid before calling template:
    <fhi-angular-highcharts [diagramOptions]="yourOptions"></fhi-angular-highcharts>

    If [yourOptions] are in accordance with specification, contact maintainer of package:
    https://www.npmjs.com/package/@folkehelseinstituttet/angular-highcharts

    API documentation:
    https://github.com/folkehelseinstituttet/Fhi.Frontend.Demo/blob/main/projects/fhi-angular-highcharts/README.md#api`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: FhiAngularHighchartsComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: DownloadService }, { token: OptionsService }, { token: DiagramTypeGroupService }, { token: TableService }, { token: TopoJsonService }, { token: MetadataForSeriesService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.6", type: FhiAngularHighchartsComponent, isStandalone: false, selector: "fhi-angular-highcharts", inputs: { diagramOptions: "diagramOptions" }, outputs: { diagramTypeNavigation: "diagramTypeNavigation", metadataButtonClick: "metadataButtonClick" }, usesOnChanges: true, ngImport: i0, template: "@if (diagramOptionsInternal) {\n  <article>\n    <h1 class=\"h3 mb-3\">{{ diagramOptionsInternal.title }}</h1>\n\n    @if (diagramOptionsInternal.description) {\n      <p class=\"mb-4\">{{ diagramOptionsInternal.description }}</p>\n    }\n\n    @if (showDiagramTypeNav || showDownloadButton || showFullScreenButton || showMetadataButton) {\n      <ng-container *ngTemplateOutlet=\"diagramControls\" />\n    }\n    @if (showDiagramTypeDisabledWarning) {\n      <ng-container *ngTemplateOutlet=\"diagramTypeDisabledWarning\" />\n    } @else if (showDuplicateSerieNameError) {\n      <ng-container *ngTemplateOutlet=\"duplicateSerieNameError\" />\n    } @else {\n      <ng-container *ngTemplateOutlet=\"diagramAndFooter\" />\n    }\n  </article>\n\n  <ng-template #diagramAndFooter>\n    @switch (activeDiagramTypeGroup?.name) {\n      @case (diagramTypeGroupNames?.table) {\n        <ng-container *ngTemplateOutlet=\"table\" />\n      }\n      @case (diagramTypeGroupNames?.map) {\n        @if (showMap) {\n          <ng-container *ngTemplateOutlet=\"map\" />\n        }\n      }\n      @case (diagramTypeGroupNames?.chart) {\n        @if (showDefaultChartTemplate) {\n          <ng-container *ngTemplateOutlet=\"chart\" />\n        } @else {\n          <!-- chartAnimationHack: to get correct chart animation when switching from one chart type to another -->\n          <ng-container *ngTemplateOutlet=\"chart\" />\n        }\n      }\n    }\n    @if (showFooter) {\n      <ng-container *ngTemplateOutlet=\"diagramFooter\" />\n    }\n  </ng-template>\n\n  <ng-template #diagramControls>\n    <div class=\"fhi-diagram-controls\">\n      <div class=\"d-flex flex-wrap\">\n        @if (showDiagramTypeNav) {\n          <div class=\"fhi-diagram-controls__navigation\">\n            <fhi-diagram-type-nav-default\n              [diagramTypeGroups]=\"diagramTypeGroups\"\n              (diagramTypeNavigation)=\"onDiagramTypeNavigation($event)\"\n            ></fhi-diagram-type-nav-default>\n          </div>\n        }\n        <div class=\"flex-fill mb-3 d-flex\">\n          @if (showMetadataButton) {\n            <button class=\"btn fhi-btn-icon fhi-diagram-controls__metadata\" (click)=\"onMetadataButtonClick()\">\n              <i class=\"icon-info-circle\"></i>\n              <span class=\"btn__text\">Om dataene</span>\n            </button>\n          }\n          @if (showFullScreenButton && !showDiagramTypeDisabledWarning) {\n            <ng-container *ngTemplateOutlet=\"diagramModal\" />\n          }\n          @if (showDownloadButton) {\n            <div class=\"ms-auto\">\n              <fhi-popover-menu\n                [items]=\"[{ name: 'Last ned SVG', action: 'downloadSvg', icon: 'download' }]\"\n                (actionEvent)=\"onControlsPopoverMenuAction($event)\"\n              ></fhi-popover-menu>\n            </div>\n          }\n        </div>\n      </div>\n    </div>\n  </ng-template>\n\n  <ng-template #diagramModal>\n    <fhi-modal\n      [openModalButtonClass]=\"'fhi-btn-icon fhi-btn-icon--circular'\"\n      [modalTitle]=\"diagramOptionsInternal.title\"\n      [size]=\"'fullscreen'\"\n    >\n      <ng-container fhi-modal.button>\n        <i class=\"icon-arrows-fullscreen\"></i>\n        <span class=\"visually-hidden\">Fullskjerm </span>\n      </ng-container>\n      <ng-container fhi-modal.body>\n        @if (diagramOptionsInternal.description) {\n          <p>{{ diagramOptionsInternal.description }}</p>\n        }\n        <ng-container *ngTemplateOutlet=\"diagramAndFooter\" />\n      </ng-container>\n    </fhi-modal>\n  </ng-template>\n\n  <ng-template #chart>\n    <div class=\"fhi-highcharts-chart\">\n      <highcharts-chart\n        [Highcharts]=\"highcharts\"\n        [options]=\"highchartsOptions\"\n        (chartInstance)=\"onChartInstance($event)\"\n      ></highcharts-chart>\n    </div>\n  </ng-template>\n\n  <ng-template #map>\n    <div class=\"fhi-highcharts-chart fhi-highcharts-chart--map\">\n      <highcharts-chart\n        [Highcharts]=\"highmaps\"\n        [constructorType]=\"'mapChart'\"\n        [options]=\"highchartsOptions\"\n        (chartInstance)=\"onChartInstance($event)\"\n      ></highcharts-chart>\n    </div>\n  </ng-template>\n\n  <ng-template #table>\n    <div class=\"table-responsive pt-3\">\n      <table class=\"table table-striped table-sm\">\n        <thead>\n          @for (headerRow of tableData.theadRows; track $index) {\n            <tr>\n              @for (tableCell of headerRow; track $index) {\n                @if (tableCell?.isHeading && tableCell?.name !== undefined) {\n                  <th class=\"text-center\" [attr.colspan]=\"tableCell.colspan ? tableCell.colspan : null\" scope=\"col\">\n                    {{ tableCell.name }}\n                  </th>\n                } @else if (tableCell && !tableCell.isHeading) {\n                  <td\n                    class=\"text-center\"\n                    [attr.colspan]=\"tableCell.colspan ? tableCell.colspan : null\"\n                    [attr.rowspan]=\"tableCell.rowspan ? tableCell.rowspan : null\"\n                  ></td>\n                }\n              }\n            </tr>\n          }\n        </thead>\n        <tbody>\n          @for (bodyRow of tableData.tbodyRows; track $index) {\n            <tr>\n              @for (tableCell of bodyRow; track $index) {\n                @if (tableCell?.isHeading && tableCell?.name !== undefined) {\n                  <th\n                    class=\"text-nowrap text-start\"\n                    [attr.rowspan]=\"tableCell.rowspan ? tableCell.rowspan : null\"\n                    scope=\"row\"\n                  >\n                    {{ tableCell.name }}\n                  </th>\n                } @else if (tableCell && !tableCell.isHeading) {\n                  <td class=\"text-end\">\n                    {{ tableCell.data }}\n                  </td>\n                }\n              }\n            </tr>\n          }\n        </tbody>\n      </table>\n    </div>\n  </ng-template>\n\n  <ng-template #diagramFooter>\n    <footer class=\"mt-3\">\n      @if (diagramOptionsInternal.units?.length > 0 && activeDiagramTypeGroup?.name === diagramTypeGroupNames?.table) {\n        <p>\n          <strong>M\u00E5ltall </strong>\n          <span>\n            @for (unit of diagramOptionsInternal.units; track $index) {\n              <!-- Need *ngIf here, see https://github.com/prettier/prettier/issues/16577 -->\n              <ng-container *ngIf=\"$index === 0\">{{ unit.label }}</ng-container>\n              <ng-container *ngIf=\"$index > 0\">, {{ unit.label }}</ng-container>\n            }\n          </span>\n        </p>\n      }\n      @if (diagramOptionsInternal.footer?.lastUpdated) {\n        <p><strong>Sist oppdatert </strong>{{ diagramOptionsInternal.footer?.lastUpdated }}</p>\n      }\n      @if (diagramOptionsInternal.footer?.credits) {\n        <p>\n          <strong>Kilde </strong>\n          <a href=\"{{ diagramOptionsInternal.footer.credits.href }}\">{{\n            diagramOptionsInternal.footer.credits.text\n          }}</a>\n        </p>\n      }\n      @if (diagramOptionsInternal.footer?.flags && activeDiagramTypeGroup?.name === diagramTypeGroupNames?.table) {\n        <div class=\"mb-3\">\n          <strong>Tegnforklaringer</strong><br />\n          <table>\n            <tbody>\n              @for (flag of diagramOptionsInternal.footer?.flags; track $index) {\n                <tr>\n                  <td class=\"pe-2\">{{ flag.symbol }}</td>\n                  <td>{{ flag.label }}</td>\n                </tr>\n              }\n            </tbody>\n          </table>\n        </div>\n      }\n      @if (\n        flaggedSeries.length > 0 &&\n        diagramOptionsInternal.footer?.flags &&\n        activeDiagramTypeGroup?.name !== diagramTypeGroupNames?.table\n      ) {\n        <div class=\"mb-3\">\n          <p>\n            <a\n              role=\"button\"\n              class=\"fhi-popover-trigger\"\n              tabindex=\"0\"\n              triggers=\"manual\"\n              #p=\"ngbPopover\"\n              aria-haspopup=\"true\"\n              (click)=\"p.toggle()\"\n              (keydown.enter)=\"p.toggle()\"\n              [autoClose]=\"'outside'\"\n              [ngbPopover]=\"popContent\"\n            >\n              Diagrammet inneholder data som ikke kan vises\n            </a>\n          </p>\n          <ng-template #popContent>\n            <p>F\u00F8lgende data vises ikke i diagrammet</p>\n            <ul>\n              @for (dataPoint of getFlaggedDataPoints(); track $index) {\n                <li>{{ dataPoint }} <br /></li>\n              }\n            </ul>\n          </ng-template>\n          <a role=\"button\" class=\"fhi-link\" tabindex=\"0\" (click)=\"setDiagramTypeGroupToTable()\">Vis som tabell</a>\n          for \u00E5 se flere detaljer.\n        </div>\n      }\n      @if (diagramOptionsInternal.footer?.disclaimer) {\n        <p class=\"fst-italic small\">\n          {{ diagramOptionsInternal.footer?.disclaimer }}\n        </p>\n      }\n      @if (!diagramOptionsInternal.openSource && showMap) {\n        <p>\n          <a class=\"highcharts-credits\" href=\"{{ getMapCopyright()['url'] }}\">\n            Kartdata fra &#169; {{ getMapCopyright()['text'] }}\n          </a>\n        </p>\n      }\n    </footer>\n  </ng-template>\n\n  <ng-template #diagramTypeDisabledWarning>\n    <div class=\"mt-3\" id=\"om-dataene\">\n      <div class=\"alert alert-warning\" role=\"alert\">\n        <i class=\"icon-bell\"></i>\n        <p class=\"mb-0\">\n          Diagramtypen kan ikke vises med dette filtervalget.<br />\n          Velg en annen diagramtype eller gj\u00F8r et annet filtervalg.\n        </p>\n      </div>\n    </div>\n  </ng-template>\n\n  <ng-template #duplicateSerieNameError>\n    <div class=\"mt-3\" id=\"om-dataene\">\n      <div class=\"alert alert-error\" role=\"alert\">\n        <i class=\"icon-exclamation-circle\"></i>\n        <p class=\"mb-0\">Det finnes duplikate serienavn, diagrammet kan ikke vises.</p>\n      </div>\n    </div>\n  </ng-template>\n}\n", dependencies: [{ kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i8.HighchartsChartComponent, selector: "highcharts-chart", inputs: ["Highcharts", "constructorType", "callbackFunction", "oneToOne", "runOutsideAngular", "options", "update"], outputs: ["updateChange", "chartInstance"] }, { kind: "directive", type: i2.NgbPopover, selector: "[ngbPopover]", inputs: ["animation", "autoClose", "ngbPopover", "popoverTitle", "placement", "popperOptions", "triggers", "positionTarget", "container", "disablePopover", "popoverClass", "popoverContext", "openDelay", "closeDelay"], outputs: ["shown", "hidden"], exportAs: ["ngbPopover"] }, { kind: "component", type: i10.FhiModalComponent, selector: "fhi-modal", inputs: ["actionButtons", "modalTitle", "openModalButtonClass", "openModalFromParent", "closeModalFromParent", "disableCloseOnAction", "scrollable", "size"], outputs: ["dismissModal", "modalAction", "openModal"] }, { kind: "component", type: i10.FhiPopoverMenuComponent, selector: "fhi-popover-menu", inputs: ["items", "triggerIcon"], outputs: ["actionEvent"] }, { kind: "component", type: FhiDiagramTypeNavDefaultComponent, selector: "fhi-diagram-type-nav-default", inputs: ["diagramTypeGroups"], outputs: ["diagramTypeNavigation"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: FhiAngularHighchartsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'fhi-angular-highcharts', changeDetection: ChangeDetectionStrategy.OnPush, standalone: false, template: "@if (diagramOptionsInternal) {\n  <article>\n    <h1 class=\"h3 mb-3\">{{ diagramOptionsInternal.title }}</h1>\n\n    @if (diagramOptionsInternal.description) {\n      <p class=\"mb-4\">{{ diagramOptionsInternal.description }}</p>\n    }\n\n    @if (showDiagramTypeNav || showDownloadButton || showFullScreenButton || showMetadataButton) {\n      <ng-container *ngTemplateOutlet=\"diagramControls\" />\n    }\n    @if (showDiagramTypeDisabledWarning) {\n      <ng-container *ngTemplateOutlet=\"diagramTypeDisabledWarning\" />\n    } @else if (showDuplicateSerieNameError) {\n      <ng-container *ngTemplateOutlet=\"duplicateSerieNameError\" />\n    } @else {\n      <ng-container *ngTemplateOutlet=\"diagramAndFooter\" />\n    }\n  </article>\n\n  <ng-template #diagramAndFooter>\n    @switch (activeDiagramTypeGroup?.name) {\n      @case (diagramTypeGroupNames?.table) {\n        <ng-container *ngTemplateOutlet=\"table\" />\n      }\n      @case (diagramTypeGroupNames?.map) {\n        @if (showMap) {\n          <ng-container *ngTemplateOutlet=\"map\" />\n        }\n      }\n      @case (diagramTypeGroupNames?.chart) {\n        @if (showDefaultChartTemplate) {\n          <ng-container *ngTemplateOutlet=\"chart\" />\n        } @else {\n          <!-- chartAnimationHack: to get correct chart animation when switching from one chart type to another -->\n          <ng-container *ngTemplateOutlet=\"chart\" />\n        }\n      }\n    }\n    @if (showFooter) {\n      <ng-container *ngTemplateOutlet=\"diagramFooter\" />\n    }\n  </ng-template>\n\n  <ng-template #diagramControls>\n    <div class=\"fhi-diagram-controls\">\n      <div class=\"d-flex flex-wrap\">\n        @if (showDiagramTypeNav) {\n          <div class=\"fhi-diagram-controls__navigation\">\n            <fhi-diagram-type-nav-default\n              [diagramTypeGroups]=\"diagramTypeGroups\"\n              (diagramTypeNavigation)=\"onDiagramTypeNavigation($event)\"\n            ></fhi-diagram-type-nav-default>\n          </div>\n        }\n        <div class=\"flex-fill mb-3 d-flex\">\n          @if (showMetadataButton) {\n            <button class=\"btn fhi-btn-icon fhi-diagram-controls__metadata\" (click)=\"onMetadataButtonClick()\">\n              <i class=\"icon-info-circle\"></i>\n              <span class=\"btn__text\">Om dataene</span>\n            </button>\n          }\n          @if (showFullScreenButton && !showDiagramTypeDisabledWarning) {\n            <ng-container *ngTemplateOutlet=\"diagramModal\" />\n          }\n          @if (showDownloadButton) {\n            <div class=\"ms-auto\">\n              <fhi-popover-menu\n                [items]=\"[{ name: 'Last ned SVG', action: 'downloadSvg', icon: 'download' }]\"\n                (actionEvent)=\"onControlsPopoverMenuAction($event)\"\n              ></fhi-popover-menu>\n            </div>\n          }\n        </div>\n      </div>\n    </div>\n  </ng-template>\n\n  <ng-template #diagramModal>\n    <fhi-modal\n      [openModalButtonClass]=\"'fhi-btn-icon fhi-btn-icon--circular'\"\n      [modalTitle]=\"diagramOptionsInternal.title\"\n      [size]=\"'fullscreen'\"\n    >\n      <ng-container fhi-modal.button>\n        <i class=\"icon-arrows-fullscreen\"></i>\n        <span class=\"visually-hidden\">Fullskjerm </span>\n      </ng-container>\n      <ng-container fhi-modal.body>\n        @if (diagramOptionsInternal.description) {\n          <p>{{ diagramOptionsInternal.description }}</p>\n        }\n        <ng-container *ngTemplateOutlet=\"diagramAndFooter\" />\n      </ng-container>\n    </fhi-modal>\n  </ng-template>\n\n  <ng-template #chart>\n    <div class=\"fhi-highcharts-chart\">\n      <highcharts-chart\n        [Highcharts]=\"highcharts\"\n        [options]=\"highchartsOptions\"\n        (chartInstance)=\"onChartInstance($event)\"\n      ></highcharts-chart>\n    </div>\n  </ng-template>\n\n  <ng-template #map>\n    <div class=\"fhi-highcharts-chart fhi-highcharts-chart--map\">\n      <highcharts-chart\n        [Highcharts]=\"highmaps\"\n        [constructorType]=\"'mapChart'\"\n        [options]=\"highchartsOptions\"\n        (chartInstance)=\"onChartInstance($event)\"\n      ></highcharts-chart>\n    </div>\n  </ng-template>\n\n  <ng-template #table>\n    <div class=\"table-responsive pt-3\">\n      <table class=\"table table-striped table-sm\">\n        <thead>\n          @for (headerRow of tableData.theadRows; track $index) {\n            <tr>\n              @for (tableCell of headerRow; track $index) {\n                @if (tableCell?.isHeading && tableCell?.name !== undefined) {\n                  <th class=\"text-center\" [attr.colspan]=\"tableCell.colspan ? tableCell.colspan : null\" scope=\"col\">\n                    {{ tableCell.name }}\n                  </th>\n                } @else if (tableCell && !tableCell.isHeading) {\n                  <td\n                    class=\"text-center\"\n                    [attr.colspan]=\"tableCell.colspan ? tableCell.colspan : null\"\n                    [attr.rowspan]=\"tableCell.rowspan ? tableCell.rowspan : null\"\n                  ></td>\n                }\n              }\n            </tr>\n          }\n        </thead>\n        <tbody>\n          @for (bodyRow of tableData.tbodyRows; track $index) {\n            <tr>\n              @for (tableCell of bodyRow; track $index) {\n                @if (tableCell?.isHeading && tableCell?.name !== undefined) {\n                  <th\n                    class=\"text-nowrap text-start\"\n                    [attr.rowspan]=\"tableCell.rowspan ? tableCell.rowspan : null\"\n                    scope=\"row\"\n                  >\n                    {{ tableCell.name }}\n                  </th>\n                } @else if (tableCell && !tableCell.isHeading) {\n                  <td class=\"text-end\">\n                    {{ tableCell.data }}\n                  </td>\n                }\n              }\n            </tr>\n          }\n        </tbody>\n      </table>\n    </div>\n  </ng-template>\n\n  <ng-template #diagramFooter>\n    <footer class=\"mt-3\">\n      @if (diagramOptionsInternal.units?.length > 0 && activeDiagramTypeGroup?.name === diagramTypeGroupNames?.table) {\n        <p>\n          <strong>M\u00E5ltall </strong>\n          <span>\n            @for (unit of diagramOptionsInternal.units; track $index) {\n              <!-- Need *ngIf here, see https://github.com/prettier/prettier/issues/16577 -->\n              <ng-container *ngIf=\"$index === 0\">{{ unit.label }}</ng-container>\n              <ng-container *ngIf=\"$index > 0\">, {{ unit.label }}</ng-container>\n            }\n          </span>\n        </p>\n      }\n      @if (diagramOptionsInternal.footer?.lastUpdated) {\n        <p><strong>Sist oppdatert </strong>{{ diagramOptionsInternal.footer?.lastUpdated }}</p>\n      }\n      @if (diagramOptionsInternal.footer?.credits) {\n        <p>\n          <strong>Kilde </strong>\n          <a href=\"{{ diagramOptionsInternal.footer.credits.href }}\">{{\n            diagramOptionsInternal.footer.credits.text\n          }}</a>\n        </p>\n      }\n      @if (diagramOptionsInternal.footer?.flags && activeDiagramTypeGroup?.name === diagramTypeGroupNames?.table) {\n        <div class=\"mb-3\">\n          <strong>Tegnforklaringer</strong><br />\n          <table>\n            <tbody>\n              @for (flag of diagramOptionsInternal.footer?.flags; track $index) {\n                <tr>\n                  <td class=\"pe-2\">{{ flag.symbol }}</td>\n                  <td>{{ flag.label }}</td>\n                </tr>\n              }\n            </tbody>\n          </table>\n        </div>\n      }\n      @if (\n        flaggedSeries.length > 0 &&\n        diagramOptionsInternal.footer?.flags &&\n        activeDiagramTypeGroup?.name !== diagramTypeGroupNames?.table\n      ) {\n        <div class=\"mb-3\">\n          <p>\n            <a\n              role=\"button\"\n              class=\"fhi-popover-trigger\"\n              tabindex=\"0\"\n              triggers=\"manual\"\n              #p=\"ngbPopover\"\n              aria-haspopup=\"true\"\n              (click)=\"p.toggle()\"\n              (keydown.enter)=\"p.toggle()\"\n              [autoClose]=\"'outside'\"\n              [ngbPopover]=\"popContent\"\n            >\n              Diagrammet inneholder data som ikke kan vises\n            </a>\n          </p>\n          <ng-template #popContent>\n            <p>F\u00F8lgende data vises ikke i diagrammet</p>\n            <ul>\n              @for (dataPoint of getFlaggedDataPoints(); track $index) {\n                <li>{{ dataPoint }} <br /></li>\n              }\n            </ul>\n          </ng-template>\n          <a role=\"button\" class=\"fhi-link\" tabindex=\"0\" (click)=\"setDiagramTypeGroupToTable()\">Vis som tabell</a>\n          for \u00E5 se flere detaljer.\n        </div>\n      }\n      @if (diagramOptionsInternal.footer?.disclaimer) {\n        <p class=\"fst-italic small\">\n          {{ diagramOptionsInternal.footer?.disclaimer }}\n        </p>\n      }\n      @if (!diagramOptionsInternal.openSource && showMap) {\n        <p>\n          <a class=\"highcharts-credits\" href=\"{{ getMapCopyright()['url'] }}\">\n            Kartdata fra &#169; {{ getMapCopyright()['text'] }}\n          </a>\n        </p>\n      }\n    </footer>\n  </ng-template>\n\n  <ng-template #diagramTypeDisabledWarning>\n    <div class=\"mt-3\" id=\"om-dataene\">\n      <div class=\"alert alert-warning\" role=\"alert\">\n        <i class=\"icon-bell\"></i>\n        <p class=\"mb-0\">\n          Diagramtypen kan ikke vises med dette filtervalget.<br />\n          Velg en annen diagramtype eller gj\u00F8r et annet filtervalg.\n        </p>\n      </div>\n    </div>\n  </ng-template>\n\n  <ng-template #duplicateSerieNameError>\n    <div class=\"mt-3\" id=\"om-dataene\">\n      <div class=\"alert alert-error\" role=\"alert\">\n        <i class=\"icon-exclamation-circle\"></i>\n        <p class=\"mb-0\">Det finnes duplikate serienavn, diagrammet kan ikke vises.</p>\n      </div>\n    </div>\n  </ng-template>\n}\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: DownloadService }, { type: OptionsService }, { type: DiagramTypeGroupService }, { type: TableService }, { type: TopoJsonService }, { type: MetadataForSeriesService }], propDecorators: { diagramOptions: [{
                type: Input,
                args: [{ required: true }]
            }], diagramTypeNavigation: [{
                type: Output
            }], metadataButtonClick: [{
                type: Output
            }] } });

class FhiAngularHighchartsModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: FhiAngularHighchartsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.6", ngImport: i0, type: FhiAngularHighchartsModule, declarations: [FhiAngularHighchartsComponent], imports: [CommonModule,
            FormsModule,
            HighchartsChartModule,
            NgbPopoverModule,
            FhiModalComponent,
            FhiPopoverMenuComponent,
            FhiDiagramTypeNavDefaultComponent], exports: [FhiAngularHighchartsComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: FhiAngularHighchartsModule, providers: [
            TopoJsonService,
            DiagramTypeGroupService,
            DownloadService,
            OptionsService,
            TableService,
            MetadataForSeriesService,
        ], imports: [CommonModule,
            FormsModule,
            HighchartsChartModule,
            NgbPopoverModule,
            FhiModalComponent,
            FhiPopoverMenuComponent,
            FhiDiagramTypeNavDefaultComponent] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.6", ngImport: i0, type: FhiAngularHighchartsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [FhiAngularHighchartsComponent],
                    imports: [
                        CommonModule,
                        FormsModule,
                        HighchartsChartModule,
                        NgbPopoverModule,
                        FhiModalComponent,
                        FhiPopoverMenuComponent,
                        FhiDiagramTypeNavDefaultComponent,
                    ],
                    exports: [FhiAngularHighchartsComponent],
                    providers: [
                        TopoJsonService,
                        DiagramTypeGroupService,
                        DownloadService,
                        OptionsService,
                        TableService,
                        MetadataForSeriesService,
                    ],
                }]
        }] });

/*
 * Public API Surface of fhi-angular-highcharts
 */

/**
 * Generated bundle index. Do not edit.
 */

export { FhiAngularHighchartsComponent, FhiAngularHighchartsModule, FhiDiagramTypes };
//# sourceMappingURL=folkehelseinstituttet-angular-highcharts.mjs.map
