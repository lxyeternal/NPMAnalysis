/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@folkehelseinstituttet/angular-highcharts" />
export * from './public-api';
