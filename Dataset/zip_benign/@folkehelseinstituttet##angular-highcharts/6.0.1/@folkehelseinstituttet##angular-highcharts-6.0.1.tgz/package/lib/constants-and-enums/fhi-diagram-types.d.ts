import { DiagramType } from '../models/diagram-type.model';
export declare class DiagramTypes {
    static bar: DiagramType;
    static barStacked: DiagramType;
    static column: DiagramType;
    static columnAndLine: DiagramType;
    static columnStacked: DiagramType;
    static line: DiagramType;
    static mapFylker: DiagramType;
    static mapFylker2019: DiagramType;
    static mapFylker2023: DiagramType;
    static pie: DiagramType;
    static table: DiagramType;
}
export declare const AllDiagramTypes: DiagramType[];
export declare const ChartTypes: DiagramType[];
export declare const MapTypes: DiagramType[];
export declare class FhiDiagramTypes {
    static bar: {
        id: string;
        name: string;
    };
    static barStacked: {
        id: string;
        name: string;
    };
    static column: {
        id: string;
        name: string;
    };
    static columnAndLine: {
        id: string;
        name: string;
    };
    static columnStacked: {
        id: string;
        name: string;
    };
    static line: {
        id: string;
        name: string;
    };
    static mapFylker: {
        id: string;
        name: string;
    };
    static mapFylker2019: {
        id: string;
        name: string;
    };
    static mapFylker2023: {
        id: string;
        name: string;
    };
    static pie: {
        id: string;
        name: string;
    };
    static table: {
        id: string;
        name: string;
    };
}
