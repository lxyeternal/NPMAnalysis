export declare enum DiagramTypeNavIds {
    default = 0
}
