import { DiagramTypeGroup } from '../models/diagram-type-group.model';
export declare const DiagramTypeGroupNames: {
    chart: string;
    map: string;
    table: string;
};
export declare const DiagramTypeGroups: DiagramTypeGroup[];
