export declare enum DiagramTypeIds {
    bar = 0,
    barStacked = 1,
    column = 2,
    columnAndLine = 3,
    columnStacked = 4,
    line = 5,
    mapFylker = 6,
    mapFylker2019 = 7,
    mapFylker2023 = 8,
    pie = 9,
    table = 10
}
export declare const DiagramTypeIdValues: {
    bar: string;
    barStacked: string;
    column: string;
    columnAndLine: string;
    columnStacked: string;
    line: string;
    mapFylker: string;
    mapFylker2019: string;
    mapFylker2023: string;
    pie: string;
    table: string;
};
export declare enum ChartTypeIds {
    bar = 0,
    barStacked = 1,
    column = 2,
    columnAndLine = 3,
    columnStacked = 4,
    line = 5,
    pie = 6
}
export declare enum MapTypeIds {
    mapFylker = 0,
    mapFylker2019 = 1,
    mapFylker2023 = 2
}
export declare const MapTypeIdValues: {
    mapFylker: string;
    mapFylker2019: string;
    mapFylker2023: string;
};
