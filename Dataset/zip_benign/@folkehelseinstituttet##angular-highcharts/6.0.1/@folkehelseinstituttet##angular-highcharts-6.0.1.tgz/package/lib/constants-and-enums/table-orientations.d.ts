export declare enum TableOrientations {
    seriesAsRows = 0,
    seriesAsColumns = 1
}
export declare const TableOrientationValues: {
    seriesAsRows: string;
    seriesAsColumns: string;
};
