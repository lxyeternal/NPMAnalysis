export declare enum DiagramSerieNameSeperator {
    input = "|",
    output = " | "
}
