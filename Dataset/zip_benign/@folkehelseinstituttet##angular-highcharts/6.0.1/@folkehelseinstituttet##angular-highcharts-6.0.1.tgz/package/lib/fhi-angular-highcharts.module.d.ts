import * as i0 from "@angular/core";
import * as i1 from "./fhi-angular-highcharts.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "highcharts-angular";
import * as i5 from "@ng-bootstrap/ng-bootstrap";
import * as i6 from "@folkehelseinstituttet/angular-components";
import * as i7 from "./fhi-diagram-type-navs/fhi-diagram-type-nav-default/fhi-diagram-type-nav-default.component";
export declare class FhiAngularHighchartsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FhiAngularHighchartsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FhiAngularHighchartsModule, [typeof i1.FhiAngularHighchartsComponent], [typeof i2.CommonModule, typeof i3.FormsModule, typeof i4.HighchartsChartModule, typeof i5.NgbPopoverModule, typeof i6.FhiModalComponent, typeof i6.FhiPopoverMenuComponent, typeof i7.FhiDiagramTypeNavDefaultComponent], [typeof i1.FhiAngularHighchartsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FhiAngularHighchartsModule>;
}
