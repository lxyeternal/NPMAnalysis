import { SeriesOptionsType } from 'highcharts';
export declare const OptionsChartsAndMaps: {
    chart: {
        styledMode: boolean;
        spacingBottom: number;
    };
    caption: {
        useHTML: boolean;
        y: number;
    };
    credits: {
        enabled: boolean;
        position: {
            align: string;
            verticalAlign: string;
            x: number;
        };
    };
    series: any[];
    title: {
        text: any;
    };
    exporting: {
        allowHTML: boolean;
        buttons: {
            contextButton: {
                enabled: boolean;
            };
        };
        csv: {
            itemDelimiter: string;
            columnHeaderFormatter: (item: SeriesOptionsType) => string;
        };
        fallbackToExportServer: boolean;
    };
};
