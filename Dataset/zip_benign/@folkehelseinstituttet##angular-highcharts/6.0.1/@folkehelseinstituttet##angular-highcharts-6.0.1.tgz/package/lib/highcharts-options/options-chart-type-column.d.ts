export declare const OptionsChartTypeColumn: {
    chart: {
        type: string;
    };
    plotOptions: {
        column: {
            dataLabels: {
                enabled: boolean;
            };
        };
    };
};
