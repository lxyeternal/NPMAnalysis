export declare const OptionsCharts: {
    chart: {
        colorCount: number;
    };
    legend: {
        align: string;
        verticalAlign: string;
        margin: number;
        maxHeight: number;
        symbolPadding: number;
        symbolWidth: number;
    };
    xAxis: {
        allowDecimals: boolean;
        type: string;
        title: {
            text: any;
        };
    };
    yAxis: {
        allowDecimals: boolean;
        title: {
            text: any;
        };
    };
};
