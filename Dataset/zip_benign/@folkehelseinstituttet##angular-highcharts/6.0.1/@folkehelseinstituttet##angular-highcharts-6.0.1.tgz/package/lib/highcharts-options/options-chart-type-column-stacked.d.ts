export declare const OptionsChartTypeColumnStacked: {
    chart: {
        type: string;
    };
    plotOptions: {
        series: {
            stacking: "normal";
        };
    };
};
