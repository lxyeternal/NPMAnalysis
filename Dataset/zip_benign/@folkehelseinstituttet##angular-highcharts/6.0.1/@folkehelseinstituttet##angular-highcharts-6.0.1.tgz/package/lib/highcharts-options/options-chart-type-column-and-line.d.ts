export declare const OptionsChartTypeColumnAndLine: {
    chart: {};
    plotOptions: {
        column: {
            dataLabels: {
                enabled: boolean;
            };
        };
        line: {
            marker: {
                symbol: string;
                radius: number;
            };
        };
    };
    xAxis: {
        tickLength: number;
        tickmarkPlacement: "on";
        tickWidth: number;
    };
};
