export declare const OptionsChartTypePie: {
    chart: {
        type: string;
    };
    plotOptions: {
        pie: {
            dataLabels: {
                enabled: boolean;
            };
            showInLegend: boolean;
            size: string;
            innerSize: string;
        };
    };
    legend: {
        align: "left";
        maxHeight: number;
        itemMarginBottom: number;
        itemMarginTop: number;
        layout: "vertical";
        title: {
            text: any;
        };
        verticalAlign: "top";
    };
    responsive: {
        rules: {
            chartOptions: {
                legend: {
                    align: "center";
                    margin: number;
                    maxHeight: number;
                };
            };
            condition: {
                maxWidth: number;
            };
        }[];
    };
};
