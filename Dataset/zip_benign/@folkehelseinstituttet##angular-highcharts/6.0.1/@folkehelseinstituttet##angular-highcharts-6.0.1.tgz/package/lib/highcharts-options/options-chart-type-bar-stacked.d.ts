export declare const OptionsChartTypeBarStacked: {
    chart: {
        type: string;
    };
    plotOptions: {
        series: {
            stacking: "normal";
        };
    };
};
