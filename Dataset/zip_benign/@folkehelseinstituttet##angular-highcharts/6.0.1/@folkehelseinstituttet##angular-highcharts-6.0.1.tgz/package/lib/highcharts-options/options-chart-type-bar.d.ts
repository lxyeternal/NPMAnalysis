export declare const OptionsChartTypeBar: {
    chart: {
        type: string;
    };
    plotOptions: {
        bar: {
            dataLabels: {
                enabled: boolean;
            };
        };
    };
};
