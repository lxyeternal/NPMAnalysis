export declare const OptionsMaps: {
    chart: {
        marginTop: number;
    };
    credits: {
        mapText: string;
        mapTextFull: any;
    };
    legend: {
        align: "center";
        borderWidth: number;
        layout: "horizontal";
        verticalAlign: "bottom";
    };
    mapNavigation: {
        enabled: boolean;
        buttonOptions: {
            verticalAlign: "top";
        };
    };
};
