export declare const OptionsChartTypeLine: {
    chart: {
        type: string;
    };
    plotOptions: {
        line: {
            marker: {
                symbol: string;
                radius: number;
            };
        };
    };
    xAxis: {
        tickLength: number;
        tickmarkPlacement: "on";
        tickWidth: number;
    };
};
