import { FhiDiagramSerie } from '../models/fhi-diagram-serie.model';
import { TableData } from '../models/table-data.model';
import { MetadataForSeriesService } from './metadata-for-series.service';
import * as i0 from "@angular/core";
export declare class TableService {
    private metadataForSeriesService;
    constructor(metadataForSeriesService: MetadataForSeriesService);
    getTable(series: FhiDiagramSerie[], orientation: string): TableData;
    private getTableHeaderRows_OrientationColumns;
    private getTableBodyRows_OrientationColumns;
    private hasColspan;
    private getColumnHeaderName;
    private getTableHeaderRow_OrientationRows;
    private getTableBodyRows_OrientationRows;
    private hasRowspan;
    private getRowHeaderName;
    private getSerieNameArray;
    private getSerieNameDimentionsCount;
    private getColspanOrRowspanCounts;
    private getRoundedData;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TableService>;
}
