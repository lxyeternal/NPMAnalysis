import { Options } from 'highcharts';
import { FhiDiagramOptions } from '../models/fhi-diagram-options.model';
import { TopoJsonService } from './topo-json.service';
import { MetadataForSeriesService } from './metadata-for-series.service';
import * as i0 from "@angular/core";
export declare class OptionsService {
    private topoJsonService;
    private metadataForSeriesService;
    private allStaticOptions;
    private diagramOptions;
    private isMap;
    constructor(topoJsonService: TopoJsonService, metadataForSeriesService: MetadataForSeriesService);
    updateOptions(diagramOptions: FhiDiagramOptions): Options;
    private getIsMap;
    private setAllStaticOptions;
    private setStaticOptions;
    private updateChartAndMapOptions;
    private updateSerieData;
    private getDataWithoutStringDataPoints;
    private getDataWithoutFlaggedDataPoints;
    private updateChartOptions;
    private updateMapOptions;
    private updateOptionsForCurrentDiagramType;
    private updateOptionsForDiagramTypeColumnAndLine;
    private getTooltipFormatterCallbackFunction;
    private getTooltip;
    private getXAxis;
    private getYAxis;
    /**
     * The following date formatting methods are currently not in use,
     * but they are kept around since they probably will be reintroduced.
     */
    private getFormattedLabels;
    private formatDayLabelsForFirstDayInMonthsAsLLL;
    private formatDayLabelsAsDaySlashMonth;
    private getISO8601DataFromNorwegianDate;
    static ɵfac: i0.ɵɵFactoryDeclaration<OptionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OptionsService>;
}
