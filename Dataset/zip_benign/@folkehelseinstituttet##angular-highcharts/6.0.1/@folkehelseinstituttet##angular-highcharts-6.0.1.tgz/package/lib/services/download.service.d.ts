import { Chart, ExportingMimeTypeValue } from 'highcharts';
import * as i0 from "@angular/core";
export declare class DownloadService {
    downloadImage(chartInstance: Chart, MIMEtype: ExportingMimeTypeValue, title: string): void;
    private getFilename;
    static ɵfac: i0.ɵɵFactoryDeclaration<DownloadService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DownloadService>;
}
