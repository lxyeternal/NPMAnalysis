import { FhiDiagramSerie } from '../models/fhi-diagram-serie.model';
import { FhiDiagramUnit } from '../models/fhi-diagram-unit.model';
import * as i0 from "@angular/core";
export declare class MetadataForSeriesService {
    private metadataForSeries;
    resetMetadataForSeries(): void;
    get hasPositiveData(): boolean;
    get hasNegativeData(): boolean;
    get hasDecimalData(): boolean;
    getMaxDecimals(serieName: string | string[]): number;
    getDecimalCount(value: number | string): number;
    getIsDecimalNumber(value: number | string): boolean;
    updateMetadataForSeries(serie: FhiDiagramSerie, units: FhiDiagramUnit[]): void;
    private getVerifiedMaxDecimalCount;
    private serieHasDecimalDataPoints;
    private serieHasNegativeDataPoints;
    private serieHasPositiveDataPoints;
    static ɵfac: i0.ɵɵFactoryDeclaration<MetadataForSeriesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MetadataForSeriesService>;
}
