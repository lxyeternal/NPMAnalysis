import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SeriesMapOptions } from 'highcharts';
import { FhiDiagramSerie } from '../models/fhi-diagram-serie.model';
import * as i0 from "@angular/core";
export declare class TopoJsonService {
    private httpClient;
    private topoJsonMaps;
    private currentMapTypeId;
    constructor(httpClient: HttpClient);
    setCurrentMapTypeId(mapTypeId: string): void;
    getMapCopyright(): object;
    getMap(mapTypeId: string | undefined): Observable<object>;
    addMap(map: object, mapTypeId: string): void;
    getHighmapsSerie(serie: FhiDiagramSerie): SeriesMapOptions;
    private getMapSerieDataPoint;
    private getMapUrls;
    static ɵfac: i0.ɵɵFactoryDeclaration<TopoJsonService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TopoJsonService>;
}
