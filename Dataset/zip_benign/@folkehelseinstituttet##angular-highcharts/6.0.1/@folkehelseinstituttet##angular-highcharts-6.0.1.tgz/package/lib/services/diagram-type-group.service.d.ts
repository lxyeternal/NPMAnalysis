import { DiagramTypeGroup } from '../models/diagram-type-group.model';
import { FlaggedSerie } from '../models/flagged-serie.model';
import { FhiDiagramOptions } from '../models/fhi-diagram-options.model';
import * as i0 from "@angular/core";
export declare class DiagramTypeGroupService {
    private activeDiagramType;
    private flaggedSeries;
    private diagramOptions;
    private series;
    private diagramTypeDisabledWarnings;
    private diagramTypeDisabledWarningMessages;
    getDiagramTypeDisabledWarningMsg(activeDiagramType: string): string;
    getActiveDiagramTypeGroup(groups: DiagramTypeGroup[]): DiagramTypeGroup;
    getDiagramTypeGroups(diagramOptions: FhiDiagramOptions, flaggedSeries: FlaggedSerie[], previousDiagramTypeGroups: DiagramTypeGroup[]): DiagramTypeGroup[];
    getDiagramTypeIsDisabled(groups: DiagramTypeGroup[], diagramTypeId: string): boolean;
    private createGroups;
    private updateChildrenDiagramTypeStates;
    private updateActiveDiagramType;
    private updateGroupDiagramTypeStates;
    private removeOrAddDiagramTypes;
    private updateDiagramTypeGroup;
    private diagramTypeIsActive;
    private diagramTypeIsDisabled;
    private isBarOrColumnType;
    private isMapType;
    private isMapOrPieType;
    private isAnyTypeButTable;
    private isAnyTypeButTableOrColumnAndLine;
    private hasFlaggedData;
    private moreThanOneSeries;
    private notAllUnitsFoundInSeries;
    private notGeo;
    private notMaxOneUnitInSeries;
    private notTwoUnitsInSeries;
    private notTwoUnits;
    private onlyOneSerieAndAllDataAreFlagged;
    private updateDisabledWarnings;
    private serieNotGeo;
    private uniqueUnitIdCountInSeries;
    /**
     * Returns a list of leagal geo names for all maps
     *
     * PS. This gives 1 fact in 2 places, but the the maps will not change
     *     that often, and the benefit of being able to do a "disable map test"
     *     before the maps are loaded makes it worth it.
     */
    private getValidGeoNames;
    static ɵfac: i0.ɵɵFactoryDeclaration<DiagramTypeGroupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DiagramTypeGroupService>;
}
