import { EventEmitter } from '@angular/core';
import { DiagramTypeGroup } from '../../models/diagram-type-group.model';
import { DiagramType } from '../../models/diagram-type.model';
import * as i0 from "@angular/core";
export declare class FhiDiagramTypeNavDefaultComponent {
    diagramTypeGroups: DiagramTypeGroup[];
    diagramTypeNavigation: EventEmitter<DiagramType>;
    navigate(diagramType: DiagramType): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FhiDiagramTypeNavDefaultComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FhiDiagramTypeNavDefaultComponent, "fhi-diagram-type-nav-default", never, { "diagramTypeGroups": { "alias": "diagramTypeGroups"; "required": false; }; }, { "diagramTypeNavigation": "diagramTypeNavigation"; }, never, never, true, never>;
}
