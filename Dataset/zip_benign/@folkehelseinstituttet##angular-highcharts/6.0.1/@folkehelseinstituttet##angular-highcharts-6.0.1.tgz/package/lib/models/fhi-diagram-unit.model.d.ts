export declare enum UnitSymbolPosition {
    start = 0,
    end = 1
}
export declare const UnitSymbolPositionValues: {
    start: string;
    end: string;
};
export interface FhiDiagramUnit {
    id?: number | string;
    decimals?: number;
    label: string;
    symbol?: string;
    position?: keyof typeof UnitSymbolPosition;
    yAxisMax?: number;
    yAxisMin?: number;
}
