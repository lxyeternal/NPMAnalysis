import * as React from 'react';
export interface ModalDialogProps {
    children: () => React.ReactNode;
    onClose: () => any;
}
export default function ModalDialog(props: ModalDialogProps): JSX.Element;
