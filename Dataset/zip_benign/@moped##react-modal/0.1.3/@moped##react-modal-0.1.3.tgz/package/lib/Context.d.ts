import * as React from 'react';
export default interface Context {
    open: (children: () => React.ReactNode, onClose: () => any) => void;
    updateContent: (children: () => React.ReactNode) => void;
    close: () => void;
}
export declare const Broadcast: (props: {
    value: Context;
}) => JSX.Element;
export declare const Subscriber: (props: {
    children: (value: Context) => React.ReactNode;
}) => JSX.Element;
