/// <reference types="react" />
import * as React from 'react';
declare const Dialog: React.ComponentType<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDialogElement>, HTMLDialogElement> & {
    open?: boolean;
}>;
export default Dialog;
