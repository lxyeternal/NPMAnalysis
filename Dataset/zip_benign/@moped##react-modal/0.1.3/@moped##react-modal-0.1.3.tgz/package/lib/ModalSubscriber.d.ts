import * as React from 'react';
import ModalRenderProps, { ModalState } from './ModalRenderProps';
export interface ModalSubscriberProps {
    render: (props: ModalRenderProps) => React.ReactNode;
    getState: () => ModalState;
    subscribe: (fn: () => void) => () => void;
}
export default class ModalSubscriber extends React.Component<ModalSubscriberProps, ModalState> {
    state: ModalState;
    _unsubscribe: () => void;
    _key: number;
    componentDidMount(): void;
    _onUpdate: () => void;
    componentWillUnmount(): void;
    render(): React.ReactNode;
}
