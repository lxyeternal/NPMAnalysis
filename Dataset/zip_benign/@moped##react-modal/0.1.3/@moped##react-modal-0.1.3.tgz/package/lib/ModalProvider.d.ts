/// <reference types="node" />
import * as React from 'react';
import ModalRenderProps, { ModalState } from './ModalRenderProps';
import Context from './Context';
export { ModalRenderProps };
export interface ModalProviderProps {
    animationDuration?: number;
    children: React.ReactNode;
    renderModal?: (props: ModalRenderProps) => React.ReactNode;
}
export default class ModalProvider extends React.Component<ModalProviderProps> {
    _handlers: (() => void)[];
    _st: ModalState;
    _update(st: ModalState): void;
    _getState: () => ModalState;
    _subscribe: (fn: () => void) => () => void;
    _animationEndTimeout: NodeJS.Timer | undefined;
    _api: Context;
    render(): JSX.Element;
}
