/// <reference types="react" />
import ModalRenderProps from './ModalRenderProps';
export default function ModalDialogView(props: ModalRenderProps): JSX.Element;
