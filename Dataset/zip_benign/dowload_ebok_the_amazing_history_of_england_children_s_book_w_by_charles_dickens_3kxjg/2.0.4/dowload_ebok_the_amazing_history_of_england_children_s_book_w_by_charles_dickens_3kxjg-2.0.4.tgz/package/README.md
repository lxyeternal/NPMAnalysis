# DOWNLOAD EBOOK The Amazing History of England - Children's Book w by Charles Dickens PDF EPUB MOBI (dbvf1)

### Download Ebook + The Amazing History of England - Children's Book w by Charles Dickens in pdf - mobi - epub format



➡️ ➡️ <b>CLICK HERE:</b> <a href="http://tinybit.cc/7e8282db">http://tinybit.cc/7e8282db</a> ⬅️ ⬅️

<img src="https://is4-ssl.mzstatic.com/image/thumb/Publication111/v4/1d/e1/bb/1de1bbb6-6f79-59f8-a868-6851417c3d38/1018223618.jpg/600x600bb.jpg" style="width:300px;" />

This carefully crafted ebook: &#34;The Amazing History of England - Children&#39;s Book with Original Illustrations&#34; is formatted for your eReader with a functional and detailed table of contents.<br/>
A Child&#39;s History of England is a history book written for children. Dickens dedicated the book to &#34;My own dear children, whom I hope it may help, bye and bye, to read with interest larger and better books on the same subject&#34;. The history covers the period between 50 BC and 1689, ending with a chapter summarizing events from then until the accession of Queen Victoria.<br/>
Charles Dickens (1812-1870) was an English writer and social critic. He created some of the world&#39;s best-known fictional characters and is regarded as the greatest novelist of the Victorian era. His works enjoyed unprecedented popularity during his lifetime, and by the twentieth century critics and scholars had recognized him as a literary genius. His novels and short stories enjoy lasting popularity.

Now you can download The Amazing History of England - Children's Book w epub by Charles Dickens from this link:

👉👉👉 <b>DOWNLOAD EBOOK HERE: <a href="http://tinybit.cc/7e8282db">http://tinybit.cc/7e8282db</a></b>

