
var converter = require("./src/index");

console.log(converter.toWords(-13.02,
    {
        currency: 'USD', // опции -> валюта -> select [KGS, USD, RUB]
        convertMinusSignToWord: false, // опции -> toggle -> Конвертировать знак минус в слово
        showNumberParts: {
            integer: false,
            fractional: true
        },
    }
));