## 用于精确计算组件


### 使用方法
```javascript
import SafeNumber from '@sbc-fe/safe-number'

const a = new SafeNumber(0.4)

// 加法
a.add(0.3).toNumber() // => 0.7
// 减法
a.minus(0.1).toNumber() // => 0.3
// 乘法
a.multiple(0.7).toNumber() // => 0.28

// 四舍五入保留n位小数
const b = new SafeNumber(0.15972)
b.round(3) // => 0.160

// 向上取整按n位小数
b.ceil(2) // => 0.16

// 向下取整按n位小数
b.floor(2) // => 0.15

```