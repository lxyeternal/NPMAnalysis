module.exports = function (grunt) {
	grunt.initConfig({
		'sprite': {
			'example': {
				'src': 'assets/images/*.png',
				'dest': 'assets/demo-sprites.png',
				'destCss': 'assets/_demo-sprites.scss',
				'cssFormat': 'scss',
				'algorithm': 'top-down',
				'cssTemplate': '../src/grunt-spritesmith/sprites.handlebars',
				'padding': 4,
				'cssVarMap': function (sprite) {
					sprite.spriteName = 'demo-sprites';
				}
			},
		}
	});

	grunt.loadNpmTasks('grunt-spritesmith');

	grunt.registerTask('default', ['sprite']);
}