# openai-text-completions

A Node.js module for interacting with the OpenAI text completion API.

## Installation

```
npm install openai-text-completions
```

## Usage

First, you'll need to [obtain an API key from OpenAI](https://openai.com/). Once you have your key, you can set it using the `key` command:

```
openai-text-completions key <your-api-key>
```

You can then check that your key is valid using the `check-key` command:

```
openai-text-completions check-key
```

To generate text, you can use the `generate` or `generate-from-file` commands. The `generate` command takes a string prompt as its first argument, and the `generate-from-file` command takes a path to a file containing the prompt as its first argument. Both commands also accept an optional `model` argument (default: `text-davinci-002`) and an optional `temperature` argument (default: `0.5`).

Here's an example of using the `generate` command:

```
openai-text-completions generate "The quick brown fox jumps over the lazy dog."
```

And here's an example of using the `generate-from-file` command:

```
openai-text-completions generate-from-file prompt.txt
```

## License

MIT