"use strict";exports.TinyFloat = void 0; /**
 * A decimal class that uses BigInt to store the number.
 *
 * In the implementation, the precision is the number of digits after
 * the decimal point to keep. It adds one digit to handle rounding. The number
 * is rounded using the round half-up method.
 */
class TinyFloat {
  /**
   * The BigInt representation of the number. It's multiplied by 10^precision.
   *
   * @private
   */


  /**
   * The number of digits after decimal point to keep.
   *
   * @private
   */


  /**
   * Creates a TinyFloat instance from a string and given precision.
   *
   * @param tf - The number to create
   * @param precision - The number of digits after decimal point to keep
   */
  constructor(tf, precision) {
    const isTF = tf instanceof TinyFloat;
    this.precision = isTF ? tf.precision : precision ?? 16;
    this.int = isTF ? tf.int : tf ? this.parse(tf) : BigInt(0);
  }

  /**
   * Returns the number as a string. It keeps the zero padding according to
   * the precision settings.
   *
   * @param precision - The precision to use
   *
   * @returns The number string.
   */
  toString(precision) {
    const precisionToUse = precision ?? this.precision;
    const int = this.transpose(precisionToUse);
    const absInt = int < 0 ? -int : int;
    const pow = BigInt(10 ** (precisionToUse + 1));
    const paddedFloatPart = absInt % pow;
    const rounding =
    paddedFloatPart % 10n >= 5n + (int < 0 ? 1n : 0n) ? 10n : 0n;
    const roundedInt = absInt + rounding;

    return (
      // Sign
      (int < 0 ? "-" : "") +
      // Int part
      (roundedInt / pow).toString() +
      "." +
      // Float part
      (roundedInt % pow).
      toString().
      padStart(precisionToUse + 1, "0").
      slice(0, precisionToUse));

  }

  /**
   * Returns the number type.
   *
   * @param precision - The precision to use
   *
   * @returns The number
   */
  toNumber(precision) {
    return parseFloat(this.toString(precision));
  }

  /**
   * Adds two numbers.
   *
   * @param tf - The number to add
   *
   * @returns Sum of the two numbers
   */
  add(tf) {
    return this.fromBigInt(this.int + this.argument(tf));
  }

  /**
   * Subtracts two numbers.
   *
   * @param tf - The number to subtract
   *
   * @returns Difference of the two numbers
   */
  sub(tf) {
    return this.fromBigInt(this.int - this.argument(tf));
  }

  /**
   * Multiplies two numbers.
   *
   * @param tf - The number to multiply
   *
   * @returns Product of the two numbers
   */
  mul(tf) {
    return this.fromBigInt(
      this.int * this.argument(tf) / BigInt(10 ** (this.precision + 1))
    );
  }

  /**
   * Divides two numbers.
   *
   * @param tf - The number to divide
   *
   * @returns Quotient of the two numbers
   */
  div(tf) {
    return this.fromBigInt(
      this.int * BigInt(10 ** (this.precision + 1)) / this.argument(tf)
    );
  }

  /**
   * Returns the remainder of the division of two numbers.
   *
   * @param tf - The number to divide
   *
   * @returns The remainder of the division
   */
  mod(tf) {
    return this.fromBigInt(this.int % this.argument(tf));
  }

  /**
   * Returns a new TinyFloat with the new precision.
   *
   * @param precision - The new precision
   *
   * @returns A new TinyFloat with the new precision
   */
  withPrecision(precision) {
    if (this.precision === precision) return this;
    return this.fromBigInt(this.transpose(precision), precision);
  }

  /**
   * Normalizes the string or TinyFloat to a BigInt
   *
   * @param tf - The instance or string to normalize
   *
   * @returns The BigInt representation of the number
   *
   * @private
   */
  argument(tf) {
    return tf instanceof TinyFloat ?
    tf.withPrecision(this.precision).int :
    this.parse(tf);
  }

  /**
   * Transposes the BigInt representation to given precision.
   *
   * @param precision - The precision to transpose to
   *
   * @returns Transposed BigInt representation
   */
  transpose(precision) {
    const pow = BigInt(10 ** Math.abs(this.precision - precision));
    return this.precision > precision ? this.int / pow : this.int * pow;
  }

  /**
   * Parses the number or its string representation to BigInt.
   *
   * @param num - The number or string representation
   * @param precision - The precision
   *
   * @returns The BigInt representation of the number
   *
   * @private
   */
  parse(num) {
    let str = num.toString();
    const digits = this.precision + 1;
    const point = str.indexOf(".");

    const exponentIdx = str.indexOf("e");
    if (exponentIdx === -1) {
      if (point === -1) {
        return BigInt(str + "0".repeat(digits));
      } else {
        const floatPart = str.slice(point + 1, point + 1 + digits);
        return BigInt(
          str.slice(0, point) +
          floatPart +
          "0".repeat(digits - floatPart.length)
        );
      }
    } else {
      // Scientific notation (typically ≤ 1e-7, ≥ 1e+21)
      const mantissa = str.slice(0, exponentIdx);
      const exponent = Number.parseInt(str.slice(exponentIdx + 1));

      if (point === -1) {
        return BigInt(mantissa + "0".repeat(digits + exponent));
      } else {
        const mantissaFloat = mantissa.slice(point + 1);
        return BigInt(
          mantissa.slice(0, point) +
          mantissaFloat +
          "0".repeat(digits + exponent - mantissaFloat.length)
        );
      }
    }
  }

  /**
   * Creates a TinyFloat instance from a BigInt and precision.
   *
   * @param int - The BigInt to create
   * @param precision - The precision
   *
   * @returns The TinyFloat instance
   *
   * @private
   */
  fromBigInt(int, precision) {
    const tf = new TinyFloat();
    tf.int = int;
    tf.precision = precision ?? this.precision;
    return tf;
  }
}exports.TinyFloat = TinyFloat;