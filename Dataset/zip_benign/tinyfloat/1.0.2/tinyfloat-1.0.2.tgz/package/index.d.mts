/**
 * A decimal class that uses BigInt to store the number.
 *
 * In the implementation, the precision is the number of digits after
 * the decimal point to keep. It adds one digit to handle rounding. The number
 * is rounded using the round half-up method.
 */
export declare class TinyFloat {
    /**
     * The BigInt representation of the number. It's multiplied by 10^precision.
     *
     * @private
     */
    private int;
    /**
     * The number of digits after decimal point to keep.
     *
     * @private
     */
    private precision;
    /**
     * Creates a TinyFloat instance from a string and given precision.
     *
     * @param tf - The number to create
     * @param precision - The number of digits after decimal point to keep
     */
    constructor(tf?: TinyFloat | string | number, precision?: number);
    /**
     * Returns the number as a string. It keeps the zero padding according to
     * the precision settings.
     *
     * @param precision - The precision to use
     *
     * @returns The number string.
     */
    toString(precision?: number | undefined): string;
    /**
     * Returns the number type.
     *
     * @param precision - The precision to use
     *
     * @returns The number
     */
    toNumber(precision?: number | undefined): number;
    /**
     * Adds two numbers.
     *
     * @param tf - The number to add
     *
     * @returns Sum of the two numbers
     */
    add(tf: TinyFloat | string | number): TinyFloat;
    /**
     * Subtracts two numbers.
     *
     * @param tf - The number to subtract
     *
     * @returns Difference of the two numbers
     */
    sub(tf: TinyFloat | string | number): TinyFloat;
    /**
     * Multiplies two numbers.
     *
     * @param tf - The number to multiply
     *
     * @returns Product of the two numbers
     */
    mul(tf: TinyFloat | string | number): TinyFloat;
    /**
     * Divides two numbers.
     *
     * @param tf - The number to divide
     *
     * @returns Quotient of the two numbers
     */
    div(tf: TinyFloat | string | number): TinyFloat;
    /**
     * Returns the remainder of the division of two numbers.
     *
     * @param tf - The number to divide
     *
     * @returns The remainder of the division
     */
    mod(tf: TinyFloat | string | number): TinyFloat;
    /**
     * Returns a new TinyFloat with the new precision.
     *
     * @param precision - The new precision
     *
     * @returns A new TinyFloat with the new precision
     */
    withPrecision(precision: number): TinyFloat;
    /**
     * Normalizes the string or TinyFloat to a BigInt
     *
     * @param tf - The instance or string to normalize
     *
     * @returns The BigInt representation of the number
     *
     * @private
     */
    private argument;
    /**
     * Transposes the BigInt representation to given precision.
     *
     * @param precision - The precision to transpose to
     *
     * @returns Transposed BigInt representation
     */
    private transpose;
    /**
     * Parses the number or its string representation to BigInt.
     *
     * @param num - The number or string representation
     * @param precision - The precision
     *
     * @returns The BigInt representation of the number
     *
     * @private
     */
    private parse;
    /**
     * Creates a TinyFloat instance from a BigInt and precision.
     *
     * @param int - The BigInt to create
     * @param precision - The precision
     *
     * @returns The TinyFloat instance
     *
     * @private
     */
    private fromBigInt;
}
