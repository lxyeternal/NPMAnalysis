<div align="center">
  <sub>Cooked by <a href="https://www.linkedin.com/in/shehabul-islam-0/">Shehabul Islam</a> 👨‍🍳</sub>
</div>

<br />

## Features

- 🔥 **Hot by default**

## Installation

#### With yarn

```sh
yarn add bp-utils
```

#### With NPM

```sh
npm install bp-utils
```

## Getting Started

collection of utility functions designed to simplify common programming tasks.

## Documentation

List of functions:

- [hexToRgba](#hextorgba)
- [isValidDate](#isvaliddate)
- [htmlToElement / htmlToNode](#htmltoelement--htmltonode)
- [strToCapitalize](#strtocapitalize)
- [jsonParse](#jsonparse)
- [rgbaToHex](#rgbaToHex)

List of classes:

- [GenerateThumbnailFromVideo](#generatethumbnailfromvideo)

### hexToRgba

```js
import { hexToRgba } from 'bp-utils';

// Example usage:
const hexColor = '#ff00ff'; // Magenta
const alphaValue = 0.5; // 50% opacity

const rgbaColor = hexToRgba(hexColor, alphaValue);
console.log(rgbaColor); // Output: "rgba(255, 0, 255, 0.5)"
```

### isValidDate

```js
import { isValidDate } from 'bp-utils';

// Example usage:
const date = isValidDate('2023-11-30');
console.log(date); // Output: true
```

### htmlToElement / htmlToNode

```js
// Import
import { htmlToNode, htmlToElement } from 'bp-utils';

// Example usage:
const simpleHtml = '<div>Hello, World!</div>';
const element1 = htmlToElement(simpleHtml);

// Append the element to the document body
document.body.appendChild(element1);
```

### strToCapitalize

```js
import { strToCapitalize } from 'bp-utils';

//Example usage: Capitalize sentences with punctuation
const string = 'hello! this is a sentence. another sentence here.';
const result = strToCapitalize(string);

console.log(result);
// Output: "Hello! This is a sentence. Another sentence here."
```

### jsonParse

```js
import { jsonParse } from 'bp-utils';

// Example: Parsing a valid JSON string
const validJson = '{"name": "John", "age": 30, "city": "New York"}';
const result = jsonParse(validJson);
console.log(result);
// Output: { name: 'John', age: 30, city: 'New York' }
```

### jsonParse

```js
import { rgbaToHex } from 'bp-utils';

// Example: Convert RGBA color to HEX color
const rgba = 'rgba(255, 0, 0, 1)';
const result = rgbaToHex(validJson);
console.log(result);
// Output: #ff0000
```

### GenerateThumbnailFromVideo

```js
// Import the GenerateThumbnailFromVideo class
import { GenerateThumbnailFromVideo } from 'bp-utils';

// Example 1: Basic usage with default configuration
const videoSource1 = 'path/to/video1.mp4';
const thumbnailGenerator1 = new GenerateThumbnailFromVideo(videoSource1);

thumbnailGenerator1.addEventListener('ready', () => {
  const thumbnailBlob = thumbnailGenerator1.getBlob();
  const thumbnailURL = thumbnailGenerator1.getBlobURL();
  console.log('Thumbnail Blob:', thumbnailBlob);
  console.log('Thumbnail URL:', thumbnailURL);
});

// Example 2: Custom configuration
const videoSource2 = 'path/to/video2.mp4';
const customConfig = { time: 30, width: 640, height: 360, quality: 0.8 };
const thumbnailGenerator2 = new GenerateThumbnailFromVideo(
  videoSource2,
  customConfig
);

thumbnailGenerator2.addEventListener('ready', () => {
  const thumbnailBlob = thumbnailGenerator2.getBlob();
  const thumbnailURL = thumbnailGenerator2.getBlobURL();
  console.log('Thumbnail Blob:', thumbnailBlob);
  console.log('Thumbnail URL:', thumbnailURL);
});
```

<!-- Find the full API reference on [official documentation](https://react-hot-toast.com/docs). -->
