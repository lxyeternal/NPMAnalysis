/**
 * Converts an HTML string into a DOM element.
 * @param {string} html - The HTML string to convert.
 * @returns {Node} - The resulting DOM element.
 * @example
 * // Example 1: Convert a simple HTML string to an element
 * const simpleHtml = '<div>Hello, World!</div>';
 * const element1 = htmlToElement(simpleHtml);
 * document.body.appendChild(element1);
 *
 * // Example 2: Convert an HTML string with multiple elements to a fragment
 * const complexHtml = '<div><p>Paragraph 1</p><p>Paragraph 2</p></div>';
 * const fragment = htmlToElement(complexHtml);
 * document.body.appendChild(fragment);
 */
export function htmlToElement(html: string): Node | null  {
    // Create a temporary template element
    let temp = document.createElement("template");
  
    // Set the inner HTML of the template
    temp.innerHTML = html;
  
    // Return the first child of the template's content (the resulting element)
    return temp.content.firstChild;
  }
  
  export default htmlToElement;
  