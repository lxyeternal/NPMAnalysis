/**
 * Generates a unique alphanumeric string of a specified length.
 * @param {number} length - The desired length of the generated unique ID.
 * @returns {string} - The generated unique ID.
 * @example
 * // Example 1: Generating a unique ID with a length of 8 characters
 * const result1 = generateUniqueID(8);
 * console.log(result1);
 * // Output: "aBcDeFgH"
 *
 * // Example 2: Generating a unique ID with a length of 12 characters
 * const result2 = generateUniqueID(12);
 * console.log(result2);
 * // Output: "xYzAbCdEfGh"
 */
function generateUniqueID(length: number): string {
  const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'; // You can customize the characters here
  let randomString = '';

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    randomString += charset.charAt(randomIndex);
  }

  return randomString;
}

export default generateUniqueID;
