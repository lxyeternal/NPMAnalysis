function rgbaToHex(rgba: String) {
  // Extract the RGBA values from the string
  const rgbaValues = rgba.match(
    /rgba?\((\d+),\s*(\d+),\s*(\d+),?\s*([0-9.]+)?\)/
  );

  if (!rgbaValues) {
    throw new Error('Invalid RGBA color string');
  }

  // Parse the R, G, B values
  const r = parseInt(rgbaValues[1]);
  const g = parseInt(rgbaValues[2]);
  const b = parseInt(rgbaValues[3]);

  // Parse the alpha value, default to 1 if not provided
  const a = rgbaValues[4] !== undefined ? parseFloat(rgbaValues[4]) : 1;

  // Convert to hex
  const toHex = (n: Number) => n.toString(16).padStart(2, '0').toUpperCase();

  // Convert alpha to hex (if needed)
  const alphaHex = toHex(Math.round(a * 255));

  // Return hex with or without alpha
  return `#${toHex(r)}${toHex(g)}${toHex(b)}${a < 1 ? alphaHex : ''}`;
}

export default rgbaToHex;