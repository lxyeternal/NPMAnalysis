import { strToCapitalize } from './strToCapitalize';

import { hexToRGB } from './hexToRGB';
import { htmlToElement } from './htmlToElement';
import { hexToRgba } from './hexToRgba';
import isValidDate from './isValidDate';
import rgbaToHex from './rgbToHex';

export { jsonParse } from './jsonParse';
import generateUniqueID from './generateUniqueID';

export {
  hexToRGB,
  htmlToElement,
  generateUniqueID,
  htmlToElement as htmlToNode,
  isValidDate,
  strToCapitalize,
  hexToRgba,
  rgbaToHex
};
