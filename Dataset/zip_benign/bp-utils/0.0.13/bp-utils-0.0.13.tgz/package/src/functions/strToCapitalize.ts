/**
 * Capitalizes the first letter of each sentence in a given text.
 * @param {string} text - The input text containing sentences.
 * @returns {string} - The text with the first letter of each sentence capitalized.
 * @example
 * // Example 1: Capitalize sentences in a simple text
 * const simpleText = "this is a sample sentence. this is another one.";
 * const result1 = capitalizeSentence(simpleText);
 * console.log(result1);
 * // Output: "This is a sample sentence. This is another one."
 *
 * // Example 2: Capitalize sentences with punctuation
 * const textWithPunctuation = "hello! this is a sentence. another sentence here.";
 * const result2 = capitalizeSentence(textWithPunctuation);
 * console.log(result2);
 * // Output: "Hello! This is a sentence. Another sentence here."
 */
export const strToCapitalize = (text:string):string => {
    return text.replace(/(^\w)|(\.\s+\w)/g, function(match) {
      return match.toUpperCase();
    });
  }
  
  