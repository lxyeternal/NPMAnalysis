/**
 * Converts a hexadecimal color code to its corresponding RGBA format.
 * @param {string} hex - The hexadecimal color code (e.g., "#RRGGBB").
 * @param {number} [alpha=1] - The alpha (opacity) value, ranging from 0 to 1 (default is 1).
 * @returns {string} - The RGBA color string.
 * @throws {Error} - Throws an error if the input hex color format is invalid.
 * @example
 * // Example 1: Converting a hex color code to RGBA with default alpha (1)
 * const result1 = hexToRgba("#3498db");
 * console.log(result1);
 * // Output: "rgba(52, 152, 219, 1)"
 *
 * // Example 2: Converting a hex color code to RGBA with custom alpha (0.5)
 * const result2 = hexToRgba("#e74c3c", 0.5);
 * console.log(result2);
 * // Output: "rgba(231, 76, 60, 0.5)"
 */
export function hexToRgba(hex: string, alpha: number = 1): string {
  // Ensure the hex string has a hash prefix and is either 3 or 6 characters long
  if (!/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)) {
    throw new Error('Invalid hex color format');
  }

  // If the hex code is in the shorthand format (3 characters), expand it
  if (hex.length === 4) {
    hex = '#' + hex[1] + hex[1] + hex[2] + hex[2] + hex[3] + hex[3];
  }

  // Extract the red, green, and blue values
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);

  // Ensure the alpha value is within the range [0, 1]
  const a = Math.max(0, Math.min(1, alpha));

  // Return the RGBA color string
  return `rgba(${r}, ${g}, ${b}, ${a})`;
}
