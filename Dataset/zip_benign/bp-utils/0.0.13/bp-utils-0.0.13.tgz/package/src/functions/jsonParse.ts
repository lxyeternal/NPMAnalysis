/**
 * Parses a JSON string into a JavaScript object.
 * @param {string} json - The JSON string to be parsed.
 * @returns {object | null} - The parsed JavaScript object if the JSON is valid; otherwise, null.
 * @example
 * // Example 1: Parsing a valid JSON string
 * const validJson = '{"name": "John", "age": 30, "city": "New York"}';
 * const result1 = jsonParse(validJson);
 * console.log(result1);
 * // Output: { name: 'John', age: 30, city: 'New York' }
 *
 * // Example 2: Handling parsing error for an invalid JSON string
 * const invalidJson = '{"name": "John", "age": 30, "city": "New York"';
 * const result2 = jsonParse(invalidJson);
 * console.log(result2);
 * // Output: null
 */
export const jsonParse = (json: string): object | null => {
  let parsedJson = null;
  try {
    parsedJson = JSON.parse(json);
  } catch (error: any) {
    console.warn(error.message);
  }
  return parsedJson;
};
