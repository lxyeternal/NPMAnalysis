/* eslint-disable no-var */

declare global {
    var wp: {
        ajax: {
            post: function
        }
    }
  }
  
  export {};
  