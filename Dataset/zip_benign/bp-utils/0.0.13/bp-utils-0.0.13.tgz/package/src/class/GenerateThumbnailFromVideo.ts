import { EventEmitter } from './EventEmitter';

/**
 * Configuration interface for thumbnail generation.
 */
interface ConfigInterface {
  time: number;
  height: number;
  width: number;
  quality: number;
}
const defaultConfig = {
  time: 22,
  height: 405,
  width: 720,
  quality: 0.7,
};
/**
 * Generates a thumbnail from a video source using HTML5 Canvas.
 * @extends EventEmitter
 * @example
 * //Example 1: Basic usage with default configuration
 * const videoSource1 = 'path/to/video1.mp4';
 * const thumbnailGenerator1 = new GenerateThumbnailFromVideo(videoSource1);
 *
 * thumbnailGenerator1.addEventListener('ready', () => {
 *  const thumbnailBlob = thumbnailGenerator1.getBlob();
 *  const thumbnailURL = thumbnailGenerator1.getBlobURL();
 *  console.log('Thumbnail Blob:', thumbnailBlob);
 *  console.log('Thumbnail URL:', thumbnailURL);
 * });
 *
 * // Example 2: Custom configuration
 * const videoSource2 = 'path/to/video2.mp4';
 * const customConfig = { time: 30, width: 640, height: 360, quality: 0.8 };
 * const thumbnailGenerator2 = new GenerateThumbnailFromVideo(videoSource2, customConfig);
 *
 * thumbnailGenerator2.addEventListener('ready', () => {
 *  const thumbnailBlob = thumbnailGenerator2.getBlob();
 *  const thumbnailURL = thumbnailGenerator2.getBlobURL();
 *  console.log('Thumbnail Blob:', thumbnailBlob);
 *  console.log('Thumbnail URL:', thumbnailURL);
 * });
 */
export class GenerateThumbnailFromVideo extends EventEmitter {
  /**
   * Thumbnail generation configuration.
   */
  config: ConfigInterface;

  /**
   * Base64-encoded data URL of the generated thumbnail.
   */
  dataURL: string;

  /**
   * Constructor for GenerateThumbnailFromVideo class.
   * @param {URL} src - The video source.
   * @param {ConfigInterface} config - Thumbnail configuration (optional).
   * Defaults:
   *   - time: 22
   *   - height: 405
   *   - width: 720
   *   - quality: 0.7
   */

  constructor(src: string, config: ConfigInterface = defaultConfig) {
    super();

    if (typeof config !== 'object') throw new Error('Invalid config');

    this.config = {
      ...defaultConfig,
      ...config,
    };

    this.dataURL = '';

    const { width, height, time, quality } = this.config;
    const canvas = document.createElement('canvas');
    const canvasVideo = document.createElement('video');
    canvasVideo.crossOrigin = 'Anonymous';
    const ctx = canvas.getContext('2d');

    canvasVideo.src = src;
    canvasVideo.currentTime = parseFloat(String(time));
    canvasVideo.load();

    canvas.width = width;
    canvas.height = height;

    let maxTried = 0;
    let imageData = null;

    /**
     * Interval function for generating thumbnail.
     * Fires 'ready' event when thumbnail is ready.
     */
    const interval = setInterval(() => {
      try {
        ctx?.drawImage(canvasVideo, 0, 0, width, height);
        imageData = canvas.toDataURL('image/webp', quality);

        if (imageData?.length > 3000) {
          this.dataURL = imageData;
          this.dispatchEvent('ready', {});
          clearInterval(interval);
        }
      } catch (error: any) {
        console.log(error.message);
        clearInterval(interval);
      }
    }, 100);
  }

  /**
   * Gets the Blob object representing the thumbnail.
   * @returns {Blob} - The Blob object.
   */
  getBlob() {
    // Convert base64 to raw binary data held in a string
    var byteString = atob(this.dataURL.split(',')[1]);

    // Separate out the mime component
    var mimeString = this.dataURL.split(',')[0].split(':')[1].split(';')[0];

    // Write the bytes of the string to an ArrayBuffer
    var ab = new ArrayBuffer(byteString.length);

    // Create a view into the buffer
    var ia = new Uint8Array(ab);

    // Set the bytes of the buffer to the correct values
    for (var i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }

    // Write the ArrayBuffer to a blob, and you're done
    var blob = new Blob([ab], { type: mimeString });

    return blob;
  }

  /**
   * Gets the Blob URL representing the thumbnail.
   * @returns {string} - The Blob URL.
   */
  getBlobURL() {
    return URL.createObjectURL(this.getBlob());
  }
}
