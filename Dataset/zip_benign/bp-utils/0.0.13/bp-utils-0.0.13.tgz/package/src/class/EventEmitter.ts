/**
 * Interface representing callbacks for various events.
 */
interface CallbackInterface {
  [name: string]: Array<Function | undefined>;
}

/**
 * A simple event emitter class for managing and dispatching events.
 */
export class EventEmitter {
  /**
   * Collection of callbacks for different event types.
   */
  callbacks: CallbackInterface = {};

  constructor() {}

  /**
   * Inner class representing an event.
   */
  static Event = class {
    type = '';
    target: Object = {};
    data: Object = {};
  };

  /**
   * Adds an event listener for a specific event type.
   * @param {string} eventType - The type of the event.
   * @param {Function} callback - The callback function to be executed when the event occurs.
   */
  addEventListener(eventType: string, callback: Function): void {
    if (typeof callback !== 'function') return;

    if (this.callbacks[eventType] === undefined) {
      this.callbacks[eventType] = [undefined];
    }

    this.callbacks[eventType].push(callback);
  }

  on(eventType: string, callback: Function): void {
    this.addEventListener(eventType, callback);
  }

  /**
   * Dispatches an event of a specific type with optional data.
   * @param {string} eventType - The type of the event to be dispatched.
   * @param {object} data - Optional data to be passed along with the event.
   */
  dispatchEvent(eventType: string, data: object): void {
    if (this.callbacks[eventType] === undefined) return;

    const event = new EventEmitter.Event();
    event.type = eventType;
    event.target = this;
    event.data = data;

    this.callbacks[eventType].forEach((callback) => {
      if (typeof callback === 'function') {
        callback(event);
      }
    });
  }
}
