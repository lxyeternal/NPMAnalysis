import { EventEmitter } from './EventEmitter';
import { GenerateThumbnailFromVideo } from './GenerateThumbnailFromVideo';

export { GenerateThumbnailFromVideo, EventEmitter };
