import React from 'react'
import {Card} from './Card'

export const Cards = () => {
  return (
    <Card>
        <h2>Nothing to hide</h2>
    </Card>
  )
}
