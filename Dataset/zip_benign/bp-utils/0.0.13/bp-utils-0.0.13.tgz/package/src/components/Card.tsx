import React from 'react'

export const Card = ({children}: any): any => {
  return (
    <div>{children}</div>
  )
}

