export const sayHello = () => {
    console.log("Hello")
}
export const sayGoodMorning = () => {
    console.log("Hello")
}

export * from './components/'
export * from './functions/'
export * from './class/'
