import { Counter, Gauge } from "prom-client";
import { PriceInfo } from "./interface";
import { Logger } from "pino";
import { UpdateCondition } from "./price-config";
export declare class PricePusherMetrics {
    private registry;
    private server;
    private logger;
    lastPublishedTime: Gauge<string>;
    priceUpdateAttempts: Counter<string>;
    priceFeedsTotal: Gauge<string>;
    walletBalance: Gauge<string>;
    constructor(logger: Logger);
    start(port: number): void;
    updateLastPublishedTime(priceId: string, alias: string, priceInfo: PriceInfo): void;
    recordPriceUpdate(priceId: string, alias: string, trigger?: string): void;
    recordUpdateCondition(priceId: string, alias: string, condition: UpdateCondition): void;
    recordPriceUpdateError(priceId: string, alias: string, trigger?: string): void;
    setPriceFeedsTotal(count: number): void;
    updateWalletBalance(walletAddress: string, network: string, balance: bigint | number): void;
}
//# sourceMappingURL=metrics.d.ts.map