import { Options } from "yargs";
import { SearcherClient } from "jito-ts/dist/sdk/block-engine/searcher";
import { Logger } from "pino";
declare const _default: {
    command: string;
    describe: string;
    builder: {
        "metrics-port": Options;
        "enable-metrics": Options;
        "controller-log-level": Options;
        "log-level": Options;
        "pushing-frequency": Options;
        "polling-frequency": Options;
        "pyth-contract-address": Options;
        "price-service-endpoint": Options;
        "price-config-file": Options;
        endpoint: Options;
        "keypair-file": Options;
        "shard-id": Options;
        "compute-unit-price-micro-lamports": Options;
        "jito-endpoint": Options;
        "jito-keypair-file": Options;
        "jito-tip-lamports": Options;
        "dynamic-jito-tips": Options;
        "max-jito-tip-lamports": Options;
        "jito-bundle-size": Options;
        "updates-per-jito-bundle": Options;
        "address-lookup-table-account": Options;
        "treasury-id": Options;
    };
    handler: (argv: any) => Promise<void>;
};
export default _default;
export declare const onBundleResult: (c: SearcherClient, logger: Logger) => void;
//# sourceMappingURL=command.d.ts.map