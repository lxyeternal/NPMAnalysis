import { Connection, PublicKey } from "@solana/web3.js";
import { BaseBalanceTracker, BaseBalanceTrackerConfig, IBalanceTracker } from "../interface";
import { DurationInSeconds } from "../utils";
import { PricePusherMetrics } from "../metrics";
import { Logger } from "pino";
/**
 * Solana-specific configuration for balance tracker
 */
export interface SolanaBalanceTrackerConfig extends BaseBalanceTrackerConfig {
    /** Solana connection instance */
    connection: Connection;
    /** Solana public key */
    publicKey: PublicKey;
}
/**
 * Solana-specific implementation of the balance tracker
 */
export declare class SolanaBalanceTracker extends BaseBalanceTracker {
    private connection;
    private publicKey;
    constructor(config: SolanaBalanceTrackerConfig);
    /**
     * Solana-specific implementation of balance update
     */
    protected updateBalance(): Promise<void>;
}
/**
 * Parameters for creating a Solana balance tracker
 */
export interface CreateSolanaBalanceTrackerParams {
    connection: Connection;
    publicKey: PublicKey;
    network: string;
    updateInterval: DurationInSeconds;
    metrics: PricePusherMetrics;
    logger: Logger;
}
/**
 * Factory function to create a balance tracker for Solana
 */
export declare function createSolanaBalanceTracker(params: CreateSolanaBalanceTrackerParams): IBalanceTracker;
//# sourceMappingURL=balance-tracker.d.ts.map