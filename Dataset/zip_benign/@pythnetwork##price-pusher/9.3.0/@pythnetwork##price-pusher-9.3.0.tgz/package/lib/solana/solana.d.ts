import { PythSolanaReceiver } from "@pythnetwork/pyth-solana-receiver";
import { ChainPriceListener, IPricePusher, PriceInfo, PriceItem } from "../interface";
import { DurationInSeconds } from "../utils";
import { HermesClient } from "@pythnetwork/hermes-client";
import { SearcherClient } from "jito-ts/dist/sdk/block-engine/searcher";
import { Logger } from "pino";
import { AddressLookupTableAccount } from "@solana/web3.js";
export declare class SolanaPriceListener extends ChainPriceListener {
    private pythSolanaReceiver;
    private shardId;
    private logger;
    constructor(pythSolanaReceiver: PythSolanaReceiver, shardId: number, priceItems: PriceItem[], logger: Logger, config: {
        pollingFrequency: DurationInSeconds;
    });
    private checkHealth;
    start(): Promise<void>;
    getOnChainPriceInfo(priceId: string): Promise<PriceInfo | undefined>;
}
export declare class SolanaPricePusher implements IPricePusher {
    private pythSolanaReceiver;
    private hermesClient;
    private logger;
    private shardId;
    private computeUnitPriceMicroLamports;
    private addressLookupTableAccount?;
    constructor(pythSolanaReceiver: PythSolanaReceiver, hermesClient: HermesClient, logger: Logger, shardId: number, computeUnitPriceMicroLamports: number, addressLookupTableAccount?: AddressLookupTableAccount | undefined);
    updatePriceFeed(priceIds: string[]): Promise<void>;
}
export declare class SolanaPricePusherJito implements IPricePusher {
    private pythSolanaReceiver;
    private hermesClient;
    private logger;
    private shardId;
    private defaultJitoTipLamports;
    private dynamicJitoTips;
    private maxJitoTipLamports;
    private searcherClient;
    private jitoBundleSize;
    private updatesPerJitoBundle;
    private addressLookupTableAccount?;
    constructor(pythSolanaReceiver: PythSolanaReceiver, hermesClient: HermesClient, logger: Logger, shardId: number, defaultJitoTipLamports: number, dynamicJitoTips: boolean, maxJitoTipLamports: number, searcherClient: SearcherClient, jitoBundleSize: number, updatesPerJitoBundle: number, addressLookupTableAccount?: AddressLookupTableAccount | undefined);
    getRecentJitoTipLamports(): Promise<number | undefined>;
    private sleep;
    updatePriceFeed(priceIds: string[]): Promise<void>;
}
//# sourceMappingURL=solana.d.ts.map