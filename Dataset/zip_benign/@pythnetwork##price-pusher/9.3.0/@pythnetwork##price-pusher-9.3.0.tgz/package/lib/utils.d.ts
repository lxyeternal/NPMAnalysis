import { HermesClient, HexString } from "@pythnetwork/hermes-client";
import { PriceItem } from "./interface";
export type PctNumber = number;
export type DurationInSeconds = number;
export declare const txSpeeds: readonly ["slow", "standard", "fast"];
export type TxSpeed = (typeof txSpeeds)[number];
export declare const customGasChainIds: readonly [137];
export type CustomGasChainId = (typeof customGasChainIds)[number];
export declare function sleep(ms: number): Promise<void>;
export declare function removeLeading0x(id: HexString): HexString;
export declare const addLeading0x: (id: HexString) => `0x${string}`;
export declare function isWsEndpoint(endpoint: string): boolean;
export declare function verifyValidOption<options extends Readonly<Array<any>>, validOption extends options[number]>(option: any, validOptions: options): validOption;
export declare const assertDefined: <T>(value: T | undefined) => T;
export declare function filterInvalidPriceItems(hermesClient: HermesClient, priceItems: PriceItem[]): Promise<{
    existingPriceItems: PriceItem[];
    invalidPriceItems: PriceItem[];
}>;
//# sourceMappingURL=utils.d.ts.map