import { HermesClient } from "@pythnetwork/hermes-client";
import { ChainPriceListener, IPricePusher, PriceInfo, PriceItem } from "../interface";
import { DurationInSeconds } from "../utils";
import { Logger } from "pino";
import { Provider, Wallet } from "fuels";
export declare class FuelPriceListener extends ChainPriceListener {
    private provider;
    private pythContractId;
    private logger;
    private contract;
    constructor(provider: Provider, pythContractId: string, priceItems: PriceItem[], logger: Logger, config: {
        pollingFrequency: DurationInSeconds;
    });
    getOnChainPriceInfo(priceId: string): Promise<PriceInfo | undefined>;
}
export declare class FuelPricePusher implements IPricePusher {
    private wallet;
    private pythContractId;
    private hermesClient;
    private logger;
    private contract;
    constructor(wallet: Wallet, pythContractId: string, hermesClient: HermesClient, logger: Logger);
    updatePriceFeed(priceIds: string[], pubTimesToPush: number[]): Promise<void>;
}
//# sourceMappingURL=fuel.d.ts.map