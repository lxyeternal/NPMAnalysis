import { Options } from "yargs";
declare const _default: {
    command: string;
    describe: string;
    builder: {
        "controller-log-level": Options;
        "log-level": Options;
        "polling-frequency": Options;
        "pushing-frequency": Options;
        "price-service-endpoint": Options;
        "price-config-file": Options;
        endpoint: Options;
        "private-key-file": Options;
        "pyth-contract-address": Options;
    };
    handler: (argv: any) => Promise<void>;
};
export default _default;
//# sourceMappingURL=command.d.ts.map