export type PushAttempt = {
    nonce: number;
    gasPrice: number;
};
//# sourceMappingURL=common.d.ts.map