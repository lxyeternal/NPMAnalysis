import { DurationInSeconds } from "./utils";
import { IPriceListener, IPricePusher } from "./interface";
import { PriceConfig } from "./price-config";
import { Logger } from "pino";
import { PricePusherMetrics } from "./metrics";
export declare class Controller {
    private priceConfigs;
    private sourcePriceListener;
    private targetPriceListener;
    private targetChainPricePusher;
    private logger;
    private pushingFrequency;
    private metrics?;
    constructor(priceConfigs: PriceConfig[], sourcePriceListener: IPriceListener, targetPriceListener: IPriceListener, targetChainPricePusher: IPricePusher, logger: Logger, config: {
        pushingFrequency: DurationInSeconds;
        metrics?: PricePusherMetrics;
    });
    start(): Promise<void>;
}
//# sourceMappingURL=controller.d.ts.map