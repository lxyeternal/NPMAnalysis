import { Options } from "yargs";
declare const _default: {
    command: string;
    describe: string;
    builder: {
        "controller-log-level": Options;
        "log-level": Options;
        "pushing-frequency": Options;
        "polling-frequency": Options;
        "pyth-contract-address": Options;
        "mnemonic-file": Options;
        "price-service-endpoint": Options;
        "price-config-file": Options;
        "grpc-endpoint": Options;
        network: Options;
        "gas-price": Options;
        "gas-multiplier": Options;
        "price-ids-process-chunk-size": Options;
    };
    handler: (argv: any) => Promise<void>;
};
export default _default;
//# sourceMappingURL=command.d.ts.map