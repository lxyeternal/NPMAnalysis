import { HexString, HermesClient } from "@pythnetwork/hermes-client";
import { PriceItem, PriceInfo, IPricePusher, ChainPriceListener } from "../interface";
import { DurationInSeconds } from "../utils";
import { Logger } from "pino";
type InjectiveConfig = {
    chainId: string;
    gasMultiplier: number;
    gasPrice: number;
    priceIdsProcessChunkSize: number;
};
export declare class InjectivePriceListener extends ChainPriceListener {
    private pythContractAddress;
    private grpcEndpoint;
    private logger;
    constructor(pythContractAddress: string, grpcEndpoint: string, priceItems: PriceItem[], logger: Logger, config: {
        pollingFrequency: DurationInSeconds;
    });
    getOnChainPriceInfo(priceId: HexString): Promise<PriceInfo | undefined>;
}
export declare class InjectivePricePusher implements IPricePusher {
    private hermesClient;
    private pythContractAddress;
    private grpcEndpoint;
    private logger;
    private mnemonic;
    private chainConfig;
    private accounts; /** { address: Account } */
    constructor(hermesClient: HermesClient, pythContractAddress: string, grpcEndpoint: string, logger: Logger, mnemonic: string, chainConfig?: Partial<InjectiveConfig>);
    private getWallet;
    private signAndBroadcastMsg;
    updatePriceFeed(priceIds: string[], pubTimesToPush: number[]): Promise<void>;
    private updatePriceFeedChunk;
    /**
     * Get the fee for the transaction (using simulation).
     *
     * We also apply a multiplier to the gas used to apply a small
     * buffer to the gas that'll be used.
     */
    private getStdFee;
    /**
     * Get the latest VAAs for updatePriceFeed and then push them
     */
    private getPriceFeedUpdateObject;
    /**
     * Get the update fee for the given VAAs (i.e the fee that is paid to the pyth contract)
     */
    private getUpdateFee;
}
export {};
//# sourceMappingURL=injective.d.ts.map