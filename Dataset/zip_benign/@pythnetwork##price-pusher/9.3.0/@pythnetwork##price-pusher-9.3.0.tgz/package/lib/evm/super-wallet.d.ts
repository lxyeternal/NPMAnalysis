import { Account, Chain, Client, RpcSchema, WalletActions, PublicActions, Transport } from "viem";
export type SuperWalletClient = Client<Transport, Chain, Account, RpcSchema, PublicActions<Transport, Chain, Account> & WalletActions<Chain, Account>>;
export declare const createClient: (endpoint: string, mnemonic: string) => Promise<SuperWalletClient>;
//# sourceMappingURL=super-wallet.d.ts.map