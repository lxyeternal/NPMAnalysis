import { Logger } from "pino";
export declare class CustomGasStation {
    private chain;
    private speed;
    private chainMethods;
    private logger;
    constructor(logger: Logger, chain: number, speed: string);
    getCustomGasPrice(): Promise<bigint | undefined>;
    private fetchMaticMainnetGasPrice;
}
export declare function getCustomGasStation(logger: Logger, customGasStation?: number, txSpeed?: string): CustomGasStation | undefined;
//# sourceMappingURL=custom-gas-station.d.ts.map