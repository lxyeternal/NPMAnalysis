import { SuperWalletClient } from "./super-wallet";
import { BaseBalanceTracker, BaseBalanceTrackerConfig, IBalanceTracker } from "../interface";
import { DurationInSeconds } from "../utils";
import { PricePusherMetrics } from "../metrics";
import { Logger } from "pino";
/**
 * EVM-specific configuration for balance tracker
 */
export interface EvmBalanceTrackerConfig extends BaseBalanceTrackerConfig {
    /** EVM wallet client */
    client: SuperWalletClient;
    /** EVM address with 0x prefix */
    address: `0x${string}`;
}
/**
 * EVM-specific implementation of the balance tracker
 */
export declare class EvmBalanceTracker extends BaseBalanceTracker {
    private client;
    private evmAddress;
    constructor(config: EvmBalanceTrackerConfig);
    /**
     * EVM-specific implementation of balance update
     */
    protected updateBalance(): Promise<void>;
}
/**
 * Parameters for creating an EVM balance tracker
 */
export interface CreateEvmBalanceTrackerParams {
    client: SuperWalletClient;
    address: `0x${string}`;
    network: string;
    updateInterval: DurationInSeconds;
    metrics: PricePusherMetrics;
    logger: Logger;
}
/**
 * Factory function to create a balance tracker for EVM chains
 */
export declare function createEvmBalanceTracker(params: CreateEvmBalanceTrackerParams): IBalanceTracker;
//# sourceMappingURL=balance-tracker.d.ts.map