import { Address, GetContractReturnType } from "viem";
import { PythAbi } from "./pyth-abi";
import { SuperWalletClient } from "./super-wallet";
export type PythContract = GetContractReturnType<typeof PythAbi, SuperWalletClient>;
export declare const createPythContract: (client: SuperWalletClient, address: Address) => PythContract;
//# sourceMappingURL=pyth-contract.d.ts.map