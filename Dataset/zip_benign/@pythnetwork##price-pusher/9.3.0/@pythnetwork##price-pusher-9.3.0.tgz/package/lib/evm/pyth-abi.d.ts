export declare const IPythAbi: readonly [{
    readonly anonymous: false;
    readonly inputs: readonly [{
        readonly indexed: true;
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }, {
        readonly indexed: false;
        readonly internalType: "uint64";
        readonly name: "publishTime";
        readonly type: "uint64";
    }, {
        readonly indexed: false;
        readonly internalType: "int64";
        readonly name: "price";
        readonly type: "int64";
    }, {
        readonly indexed: false;
        readonly internalType: "uint64";
        readonly name: "conf";
        readonly type: "uint64";
    }];
    readonly name: "PriceFeedUpdate";
    readonly type: "event";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }];
    readonly name: "getEmaPrice";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "int64";
            readonly name: "price";
            readonly type: "int64";
        }, {
            readonly internalType: "uint64";
            readonly name: "conf";
            readonly type: "uint64";
        }, {
            readonly internalType: "int32";
            readonly name: "expo";
            readonly type: "int32";
        }, {
            readonly internalType: "uint256";
            readonly name: "publishTime";
            readonly type: "uint256";
        }];
        readonly internalType: "struct PythStructs.Price";
        readonly name: "price";
        readonly type: "tuple";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }, {
        readonly internalType: "uint256";
        readonly name: "age";
        readonly type: "uint256";
    }];
    readonly name: "getEmaPriceNoOlderThan";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "int64";
            readonly name: "price";
            readonly type: "int64";
        }, {
            readonly internalType: "uint64";
            readonly name: "conf";
            readonly type: "uint64";
        }, {
            readonly internalType: "int32";
            readonly name: "expo";
            readonly type: "int32";
        }, {
            readonly internalType: "uint256";
            readonly name: "publishTime";
            readonly type: "uint256";
        }];
        readonly internalType: "struct PythStructs.Price";
        readonly name: "price";
        readonly type: "tuple";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }];
    readonly name: "getEmaPriceUnsafe";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "int64";
            readonly name: "price";
            readonly type: "int64";
        }, {
            readonly internalType: "uint64";
            readonly name: "conf";
            readonly type: "uint64";
        }, {
            readonly internalType: "int32";
            readonly name: "expo";
            readonly type: "int32";
        }, {
            readonly internalType: "uint256";
            readonly name: "publishTime";
            readonly type: "uint256";
        }];
        readonly internalType: "struct PythStructs.Price";
        readonly name: "price";
        readonly type: "tuple";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }];
    readonly name: "getPrice";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "int64";
            readonly name: "price";
            readonly type: "int64";
        }, {
            readonly internalType: "uint64";
            readonly name: "conf";
            readonly type: "uint64";
        }, {
            readonly internalType: "int32";
            readonly name: "expo";
            readonly type: "int32";
        }, {
            readonly internalType: "uint256";
            readonly name: "publishTime";
            readonly type: "uint256";
        }];
        readonly internalType: "struct PythStructs.Price";
        readonly name: "price";
        readonly type: "tuple";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }, {
        readonly internalType: "uint256";
        readonly name: "age";
        readonly type: "uint256";
    }];
    readonly name: "getPriceNoOlderThan";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "int64";
            readonly name: "price";
            readonly type: "int64";
        }, {
            readonly internalType: "uint64";
            readonly name: "conf";
            readonly type: "uint64";
        }, {
            readonly internalType: "int32";
            readonly name: "expo";
            readonly type: "int32";
        }, {
            readonly internalType: "uint256";
            readonly name: "publishTime";
            readonly type: "uint256";
        }];
        readonly internalType: "struct PythStructs.Price";
        readonly name: "price";
        readonly type: "tuple";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }];
    readonly name: "getPriceUnsafe";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "int64";
            readonly name: "price";
            readonly type: "int64";
        }, {
            readonly internalType: "uint64";
            readonly name: "conf";
            readonly type: "uint64";
        }, {
            readonly internalType: "int32";
            readonly name: "expo";
            readonly type: "int32";
        }, {
            readonly internalType: "uint256";
            readonly name: "publishTime";
            readonly type: "uint256";
        }];
        readonly internalType: "struct PythStructs.Price";
        readonly name: "price";
        readonly type: "tuple";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes[]";
        readonly name: "updateData";
        readonly type: "bytes[]";
    }];
    readonly name: "getUpdateFee";
    readonly outputs: readonly [{
        readonly internalType: "uint256";
        readonly name: "feeAmount";
        readonly type: "uint256";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [];
    readonly name: "getValidTimePeriod";
    readonly outputs: readonly [{
        readonly internalType: "uint256";
        readonly name: "validTimePeriod";
        readonly type: "uint256";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes[]";
        readonly name: "updateData";
        readonly type: "bytes[]";
    }, {
        readonly internalType: "bytes32[]";
        readonly name: "priceIds";
        readonly type: "bytes32[]";
    }, {
        readonly internalType: "uint64";
        readonly name: "minPublishTime";
        readonly type: "uint64";
    }, {
        readonly internalType: "uint64";
        readonly name: "maxPublishTime";
        readonly type: "uint64";
    }];
    readonly name: "parsePriceFeedUpdates";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "bytes32";
            readonly name: "id";
            readonly type: "bytes32";
        }, {
            readonly components: readonly [{
                readonly internalType: "int64";
                readonly name: "price";
                readonly type: "int64";
            }, {
                readonly internalType: "uint64";
                readonly name: "conf";
                readonly type: "uint64";
            }, {
                readonly internalType: "int32";
                readonly name: "expo";
                readonly type: "int32";
            }, {
                readonly internalType: "uint256";
                readonly name: "publishTime";
                readonly type: "uint256";
            }];
            readonly internalType: "struct PythStructs.Price";
            readonly name: "price";
            readonly type: "tuple";
        }, {
            readonly components: readonly [{
                readonly internalType: "int64";
                readonly name: "price";
                readonly type: "int64";
            }, {
                readonly internalType: "uint64";
                readonly name: "conf";
                readonly type: "uint64";
            }, {
                readonly internalType: "int32";
                readonly name: "expo";
                readonly type: "int32";
            }, {
                readonly internalType: "uint256";
                readonly name: "publishTime";
                readonly type: "uint256";
            }];
            readonly internalType: "struct PythStructs.Price";
            readonly name: "emaPrice";
            readonly type: "tuple";
        }];
        readonly internalType: "struct PythStructs.PriceFeed[]";
        readonly name: "priceFeeds";
        readonly type: "tuple[]";
    }];
    readonly stateMutability: "payable";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes[]";
        readonly name: "updateData";
        readonly type: "bytes[]";
    }, {
        readonly internalType: "bytes32[]";
        readonly name: "priceIds";
        readonly type: "bytes32[]";
    }, {
        readonly internalType: "uint64";
        readonly name: "minPublishTime";
        readonly type: "uint64";
    }, {
        readonly internalType: "uint64";
        readonly name: "maxPublishTime";
        readonly type: "uint64";
    }];
    readonly name: "parsePriceFeedUpdatesUnique";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "bytes32";
            readonly name: "id";
            readonly type: "bytes32";
        }, {
            readonly components: readonly [{
                readonly internalType: "int64";
                readonly name: "price";
                readonly type: "int64";
            }, {
                readonly internalType: "uint64";
                readonly name: "conf";
                readonly type: "uint64";
            }, {
                readonly internalType: "int32";
                readonly name: "expo";
                readonly type: "int32";
            }, {
                readonly internalType: "uint256";
                readonly name: "publishTime";
                readonly type: "uint256";
            }];
            readonly internalType: "struct PythStructs.Price";
            readonly name: "price";
            readonly type: "tuple";
        }, {
            readonly components: readonly [{
                readonly internalType: "int64";
                readonly name: "price";
                readonly type: "int64";
            }, {
                readonly internalType: "uint64";
                readonly name: "conf";
                readonly type: "uint64";
            }, {
                readonly internalType: "int32";
                readonly name: "expo";
                readonly type: "int32";
            }, {
                readonly internalType: "uint256";
                readonly name: "publishTime";
                readonly type: "uint256";
            }];
            readonly internalType: "struct PythStructs.Price";
            readonly name: "emaPrice";
            readonly type: "tuple";
        }];
        readonly internalType: "struct PythStructs.PriceFeed[]";
        readonly name: "priceFeeds";
        readonly type: "tuple[]";
    }];
    readonly stateMutability: "payable";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes[]";
        readonly name: "updateData";
        readonly type: "bytes[]";
    }];
    readonly name: "updatePriceFeeds";
    readonly outputs: readonly [];
    readonly stateMutability: "payable";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes[]";
        readonly name: "updateData";
        readonly type: "bytes[]";
    }, {
        readonly internalType: "bytes32[]";
        readonly name: "priceIds";
        readonly type: "bytes32[]";
    }, {
        readonly internalType: "uint64[]";
        readonly name: "publishTimes";
        readonly type: "uint64[]";
    }];
    readonly name: "updatePriceFeedsIfNecessary";
    readonly outputs: readonly [];
    readonly stateMutability: "payable";
    readonly type: "function";
}];
export declare const IPythEventsAbi: readonly [{
    readonly anonymous: false;
    readonly inputs: readonly [{
        readonly indexed: true;
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }, {
        readonly indexed: false;
        readonly internalType: "uint64";
        readonly name: "publishTime";
        readonly type: "uint64";
    }, {
        readonly indexed: false;
        readonly internalType: "int64";
        readonly name: "price";
        readonly type: "int64";
    }, {
        readonly indexed: false;
        readonly internalType: "uint64";
        readonly name: "conf";
        readonly type: "uint64";
    }];
    readonly name: "PriceFeedUpdate";
    readonly type: "event";
}];
export declare const PythErrorsAbi: readonly [{
    readonly inputs: readonly [];
    readonly name: "InsufficientFee";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidArgument";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidGovernanceDataSource";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidGovernanceMessage";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidGovernanceTarget";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidUpdateData";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidUpdateDataSource";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidWormholeAddressToSet";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidWormholeVaa";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "NoFreshUpdate";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "OldGovernanceMessage";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "PriceFeedNotFound";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "PriceFeedNotFoundWithinRange";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "StalePrice";
    readonly type: "error";
}];
export declare const PythAbi: readonly [{
    readonly anonymous: false;
    readonly inputs: readonly [{
        readonly indexed: true;
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }, {
        readonly indexed: false;
        readonly internalType: "uint64";
        readonly name: "publishTime";
        readonly type: "uint64";
    }, {
        readonly indexed: false;
        readonly internalType: "int64";
        readonly name: "price";
        readonly type: "int64";
    }, {
        readonly indexed: false;
        readonly internalType: "uint64";
        readonly name: "conf";
        readonly type: "uint64";
    }];
    readonly name: "PriceFeedUpdate";
    readonly type: "event";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }];
    readonly name: "getEmaPrice";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "int64";
            readonly name: "price";
            readonly type: "int64";
        }, {
            readonly internalType: "uint64";
            readonly name: "conf";
            readonly type: "uint64";
        }, {
            readonly internalType: "int32";
            readonly name: "expo";
            readonly type: "int32";
        }, {
            readonly internalType: "uint256";
            readonly name: "publishTime";
            readonly type: "uint256";
        }];
        readonly internalType: "struct PythStructs.Price";
        readonly name: "price";
        readonly type: "tuple";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }, {
        readonly internalType: "uint256";
        readonly name: "age";
        readonly type: "uint256";
    }];
    readonly name: "getEmaPriceNoOlderThan";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "int64";
            readonly name: "price";
            readonly type: "int64";
        }, {
            readonly internalType: "uint64";
            readonly name: "conf";
            readonly type: "uint64";
        }, {
            readonly internalType: "int32";
            readonly name: "expo";
            readonly type: "int32";
        }, {
            readonly internalType: "uint256";
            readonly name: "publishTime";
            readonly type: "uint256";
        }];
        readonly internalType: "struct PythStructs.Price";
        readonly name: "price";
        readonly type: "tuple";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }];
    readonly name: "getEmaPriceUnsafe";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "int64";
            readonly name: "price";
            readonly type: "int64";
        }, {
            readonly internalType: "uint64";
            readonly name: "conf";
            readonly type: "uint64";
        }, {
            readonly internalType: "int32";
            readonly name: "expo";
            readonly type: "int32";
        }, {
            readonly internalType: "uint256";
            readonly name: "publishTime";
            readonly type: "uint256";
        }];
        readonly internalType: "struct PythStructs.Price";
        readonly name: "price";
        readonly type: "tuple";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }];
    readonly name: "getPrice";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "int64";
            readonly name: "price";
            readonly type: "int64";
        }, {
            readonly internalType: "uint64";
            readonly name: "conf";
            readonly type: "uint64";
        }, {
            readonly internalType: "int32";
            readonly name: "expo";
            readonly type: "int32";
        }, {
            readonly internalType: "uint256";
            readonly name: "publishTime";
            readonly type: "uint256";
        }];
        readonly internalType: "struct PythStructs.Price";
        readonly name: "price";
        readonly type: "tuple";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }, {
        readonly internalType: "uint256";
        readonly name: "age";
        readonly type: "uint256";
    }];
    readonly name: "getPriceNoOlderThan";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "int64";
            readonly name: "price";
            readonly type: "int64";
        }, {
            readonly internalType: "uint64";
            readonly name: "conf";
            readonly type: "uint64";
        }, {
            readonly internalType: "int32";
            readonly name: "expo";
            readonly type: "int32";
        }, {
            readonly internalType: "uint256";
            readonly name: "publishTime";
            readonly type: "uint256";
        }];
        readonly internalType: "struct PythStructs.Price";
        readonly name: "price";
        readonly type: "tuple";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }];
    readonly name: "getPriceUnsafe";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "int64";
            readonly name: "price";
            readonly type: "int64";
        }, {
            readonly internalType: "uint64";
            readonly name: "conf";
            readonly type: "uint64";
        }, {
            readonly internalType: "int32";
            readonly name: "expo";
            readonly type: "int32";
        }, {
            readonly internalType: "uint256";
            readonly name: "publishTime";
            readonly type: "uint256";
        }];
        readonly internalType: "struct PythStructs.Price";
        readonly name: "price";
        readonly type: "tuple";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes[]";
        readonly name: "updateData";
        readonly type: "bytes[]";
    }];
    readonly name: "getUpdateFee";
    readonly outputs: readonly [{
        readonly internalType: "uint256";
        readonly name: "feeAmount";
        readonly type: "uint256";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [];
    readonly name: "getValidTimePeriod";
    readonly outputs: readonly [{
        readonly internalType: "uint256";
        readonly name: "validTimePeriod";
        readonly type: "uint256";
    }];
    readonly stateMutability: "view";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes[]";
        readonly name: "updateData";
        readonly type: "bytes[]";
    }, {
        readonly internalType: "bytes32[]";
        readonly name: "priceIds";
        readonly type: "bytes32[]";
    }, {
        readonly internalType: "uint64";
        readonly name: "minPublishTime";
        readonly type: "uint64";
    }, {
        readonly internalType: "uint64";
        readonly name: "maxPublishTime";
        readonly type: "uint64";
    }];
    readonly name: "parsePriceFeedUpdates";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "bytes32";
            readonly name: "id";
            readonly type: "bytes32";
        }, {
            readonly components: readonly [{
                readonly internalType: "int64";
                readonly name: "price";
                readonly type: "int64";
            }, {
                readonly internalType: "uint64";
                readonly name: "conf";
                readonly type: "uint64";
            }, {
                readonly internalType: "int32";
                readonly name: "expo";
                readonly type: "int32";
            }, {
                readonly internalType: "uint256";
                readonly name: "publishTime";
                readonly type: "uint256";
            }];
            readonly internalType: "struct PythStructs.Price";
            readonly name: "price";
            readonly type: "tuple";
        }, {
            readonly components: readonly [{
                readonly internalType: "int64";
                readonly name: "price";
                readonly type: "int64";
            }, {
                readonly internalType: "uint64";
                readonly name: "conf";
                readonly type: "uint64";
            }, {
                readonly internalType: "int32";
                readonly name: "expo";
                readonly type: "int32";
            }, {
                readonly internalType: "uint256";
                readonly name: "publishTime";
                readonly type: "uint256";
            }];
            readonly internalType: "struct PythStructs.Price";
            readonly name: "emaPrice";
            readonly type: "tuple";
        }];
        readonly internalType: "struct PythStructs.PriceFeed[]";
        readonly name: "priceFeeds";
        readonly type: "tuple[]";
    }];
    readonly stateMutability: "payable";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes[]";
        readonly name: "updateData";
        readonly type: "bytes[]";
    }, {
        readonly internalType: "bytes32[]";
        readonly name: "priceIds";
        readonly type: "bytes32[]";
    }, {
        readonly internalType: "uint64";
        readonly name: "minPublishTime";
        readonly type: "uint64";
    }, {
        readonly internalType: "uint64";
        readonly name: "maxPublishTime";
        readonly type: "uint64";
    }];
    readonly name: "parsePriceFeedUpdatesUnique";
    readonly outputs: readonly [{
        readonly components: readonly [{
            readonly internalType: "bytes32";
            readonly name: "id";
            readonly type: "bytes32";
        }, {
            readonly components: readonly [{
                readonly internalType: "int64";
                readonly name: "price";
                readonly type: "int64";
            }, {
                readonly internalType: "uint64";
                readonly name: "conf";
                readonly type: "uint64";
            }, {
                readonly internalType: "int32";
                readonly name: "expo";
                readonly type: "int32";
            }, {
                readonly internalType: "uint256";
                readonly name: "publishTime";
                readonly type: "uint256";
            }];
            readonly internalType: "struct PythStructs.Price";
            readonly name: "price";
            readonly type: "tuple";
        }, {
            readonly components: readonly [{
                readonly internalType: "int64";
                readonly name: "price";
                readonly type: "int64";
            }, {
                readonly internalType: "uint64";
                readonly name: "conf";
                readonly type: "uint64";
            }, {
                readonly internalType: "int32";
                readonly name: "expo";
                readonly type: "int32";
            }, {
                readonly internalType: "uint256";
                readonly name: "publishTime";
                readonly type: "uint256";
            }];
            readonly internalType: "struct PythStructs.Price";
            readonly name: "emaPrice";
            readonly type: "tuple";
        }];
        readonly internalType: "struct PythStructs.PriceFeed[]";
        readonly name: "priceFeeds";
        readonly type: "tuple[]";
    }];
    readonly stateMutability: "payable";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes[]";
        readonly name: "updateData";
        readonly type: "bytes[]";
    }];
    readonly name: "updatePriceFeeds";
    readonly outputs: readonly [];
    readonly stateMutability: "payable";
    readonly type: "function";
}, {
    readonly inputs: readonly [{
        readonly internalType: "bytes[]";
        readonly name: "updateData";
        readonly type: "bytes[]";
    }, {
        readonly internalType: "bytes32[]";
        readonly name: "priceIds";
        readonly type: "bytes32[]";
    }, {
        readonly internalType: "uint64[]";
        readonly name: "publishTimes";
        readonly type: "uint64[]";
    }];
    readonly name: "updatePriceFeedsIfNecessary";
    readonly outputs: readonly [];
    readonly stateMutability: "payable";
    readonly type: "function";
}, {
    readonly anonymous: false;
    readonly inputs: readonly [{
        readonly indexed: true;
        readonly internalType: "bytes32";
        readonly name: "id";
        readonly type: "bytes32";
    }, {
        readonly indexed: false;
        readonly internalType: "uint64";
        readonly name: "publishTime";
        readonly type: "uint64";
    }, {
        readonly indexed: false;
        readonly internalType: "int64";
        readonly name: "price";
        readonly type: "int64";
    }, {
        readonly indexed: false;
        readonly internalType: "uint64";
        readonly name: "conf";
        readonly type: "uint64";
    }];
    readonly name: "PriceFeedUpdate";
    readonly type: "event";
}, {
    readonly inputs: readonly [];
    readonly name: "InsufficientFee";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidArgument";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidGovernanceDataSource";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidGovernanceMessage";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidGovernanceTarget";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidUpdateData";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidUpdateDataSource";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidWormholeAddressToSet";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "InvalidWormholeVaa";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "NoFreshUpdate";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "OldGovernanceMessage";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "PriceFeedNotFound";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "PriceFeedNotFoundWithinRange";
    readonly type: "error";
}, {
    readonly inputs: readonly [];
    readonly name: "StalePrice";
    readonly type: "error";
}];
//# sourceMappingURL=pyth-abi.d.ts.map