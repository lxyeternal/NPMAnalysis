import { Options } from "yargs";
declare const _default: {
    command: string;
    describe: string;
    builder: {
        "metrics-port": Options;
        "enable-metrics": Options;
        "controller-log-level": Options;
        "log-level": Options;
        "pushing-frequency": Options;
        "polling-frequency": Options;
        "pyth-contract-address": Options;
        "mnemonic-file": Options;
        "price-service-endpoint": Options;
        "price-config-file": Options;
        endpoint: Options;
        "custom-gas-station": Options;
        "tx-speed": Options;
        "override-gas-price-multiplier": Options;
        "override-gas-price-multiplier-cap": Options;
        "gas-limit": Options;
        "gas-price": Options;
        "update-fee-multiplier": Options;
    };
    handler: (argv: any) => Promise<void>;
};
export default _default;
//# sourceMappingURL=command.d.ts.map