import { IPricePusher, PriceInfo, ChainPriceListener, PriceItem } from "../interface";
import { DurationInSeconds } from "../utils";
import { Logger } from "pino";
import { HermesClient, HexString, UnixTimestamp } from "@pythnetwork/hermes-client";
import { CustomGasStation } from "./custom-gas-station";
import { PythContract } from "./pyth-contract";
import { SuperWalletClient } from "./super-wallet";
export declare class EvmPriceListener extends ChainPriceListener {
    private pythContract;
    private watchEvents;
    private logger;
    constructor(pythContract: PythContract, priceItems: PriceItem[], watchEvents: boolean, logger: Logger, config: {
        pollingFrequency: DurationInSeconds;
    });
    start(): Promise<void>;
    private startWatching;
    private onPriceFeedUpdate;
    getOnChainPriceInfo(priceId: HexString): Promise<PriceInfo | undefined>;
}
export declare class EvmPricePusher implements IPricePusher {
    private hermesClient;
    private client;
    private pythContract;
    private logger;
    private overrideGasPriceMultiplier;
    private overrideGasPriceMultiplierCap;
    private updateFeeMultiplier;
    private gasLimit?;
    private customGasStation?;
    private gasPrice?;
    private pusherAddress;
    private lastPushAttempt;
    constructor(hermesClient: HermesClient, client: SuperWalletClient, pythContract: PythContract, logger: Logger, overrideGasPriceMultiplier: number, overrideGasPriceMultiplierCap: number, updateFeeMultiplier: number, gasLimit?: number | undefined, customGasStation?: CustomGasStation | undefined, gasPrice?: number | undefined);
    updatePriceFeed(priceIds: string[], pubTimesToPush: UnixTimestamp[]): Promise<void>;
    private waitForTransactionReceipt;
    private getPriceFeedsUpdateData;
}
//# sourceMappingURL=evm.d.ts.map