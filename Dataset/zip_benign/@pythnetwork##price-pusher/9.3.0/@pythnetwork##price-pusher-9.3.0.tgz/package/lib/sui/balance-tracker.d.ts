import { SuiClient } from "@mysten/sui/client";
import { BaseBalanceTracker, BaseBalanceTrackerConfig, IBalanceTracker } from "../interface";
import { DurationInSeconds } from "../utils";
import { PricePusherMetrics } from "../metrics";
import { Logger } from "pino";
/**
 * Sui-specific configuration for balance tracker
 */
export interface SuiBalanceTrackerConfig extends BaseBalanceTrackerConfig {
    /** Sui client instance */
    client: SuiClient;
}
/**
 * Sui-specific implementation of the balance tracker
 */
export declare class SuiBalanceTracker extends BaseBalanceTracker {
    private client;
    constructor(config: SuiBalanceTrackerConfig);
    /**
     * Sui-specific implementation of balance update
     */
    protected updateBalance(): Promise<void>;
}
/**
 * Parameters for creating a Sui balance tracker
 */
export interface CreateSuiBalanceTrackerParams {
    client: SuiClient;
    address: string;
    network: string;
    updateInterval: DurationInSeconds;
    metrics: PricePusherMetrics;
    logger: Logger;
}
/**
 * Factory function to create a balance tracker for Sui chain
 */
export declare function createSuiBalanceTracker(params: CreateSuiBalanceTrackerParams): IBalanceTracker;
//# sourceMappingURL=balance-tracker.d.ts.map