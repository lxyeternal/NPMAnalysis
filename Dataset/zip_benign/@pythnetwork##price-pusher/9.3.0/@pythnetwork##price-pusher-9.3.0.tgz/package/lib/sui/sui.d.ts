import { ChainPriceListener, IPricePusher, PriceInfo, PriceItem } from "../interface";
import { DurationInSeconds } from "../utils";
import { SuiPythClient } from "@pythnetwork/pyth-sui-js";
import { Ed25519Keypair } from "@mysten/sui/keypairs/ed25519";
import { SuiClient, SuiObjectRef } from "@mysten/sui/client";
import { Logger } from "pino";
import { HermesClient } from "@pythnetwork/hermes-client";
type ObjectId = string;
export declare class SuiPriceListener extends ChainPriceListener {
    private pythClient;
    private provider;
    private logger;
    constructor(pythStateId: ObjectId, wormholeStateId: ObjectId, endpoint: string, priceItems: PriceItem[], logger: Logger, config: {
        pollingFrequency: DurationInSeconds;
    });
    getOnChainPriceInfo(priceId: string): Promise<PriceInfo | undefined>;
}
/**
 * The `SuiPricePusher` is designed for high-throughput of price updates.
 * Achieving this property requires sacrificing some nice-to-have features of other
 * pusher implementations that can reduce cost when running multiple pushers. It also requires
 * jumping through some Sui-specific hoops in order to maximize parallelism.
 *
 * The two main design features are:
 * 1. This implementation does not use `update_price_feeds_if_necssary` and simulate the transaction
 *    before submission. If multiple instances of this pusher are running in parallel, all of them will
 *    land all of their pushed updates on-chain.
 * 2. The pusher will split the Coin balance in the provided account into a pool of different Coin objects.
 *    Each transaction will be allocated a Coin object from this pool as needed. This process enables the
 *    transactions to avoid referencing the same owned objects, which allows them to be processed in parallel.
 */
export declare class SuiPricePusher implements IPricePusher {
    private readonly signer;
    private readonly provider;
    private logger;
    private hermesClient;
    private gasBudget;
    private gasPool;
    private pythClient;
    constructor(signer: Ed25519Keypair, provider: SuiClient, logger: Logger, hermesClient: HermesClient, gasBudget: number, gasPool: SuiObjectRef[], pythClient: SuiPythClient);
    /**
     * getPackageId returns the latest package id that the object belongs to. Use this to
     * fetch the latest package id for a given object id and handle package upgrades automatically.
     * @param provider
     * @param objectId
     * @returns package id
     */
    static getPackageId(provider: SuiClient, objectId: ObjectId): Promise<ObjectId>;
    /**
     * Create a price pusher with a pool of `numGasObjects` gas coins that will be used to send transactions.
     * The gas coins of the wallet for the provided keypair will be merged and then evenly split into `numGasObjects`.
     */
    static createWithAutomaticGasPool(hermesClient: HermesClient, logger: Logger, pythStateId: string, wormholeStateId: string, endpoint: string, keypair: Ed25519Keypair, gasBudget: number, numGasObjects: number, ignoreGasObjects: string[]): Promise<SuiPricePusher>;
    updatePriceFeed(priceIds: string[], pubTimesToPush: number[]): Promise<void>;
    /** Send every transaction in txs in parallel, returning when all transactions have completed. */
    private sendTransactionBlocks;
    /** Send a single transaction block using a gas coin from the pool. */
    private sendTransactionBlock;
    private static initializeGasPool;
    private static tryRefreshObjectReference;
    private static getAllGasCoins;
    private static splitGasCoinEqually;
    private static mergeGasCoinsIntoOne;
}
export {};
//# sourceMappingURL=sui.d.ts.map