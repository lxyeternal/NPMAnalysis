import { Options } from "yargs";
declare const _default: {
    command: string;
    describe: string;
    builder: {
        "metrics-port": Options;
        "enable-metrics": Options;
        "controller-log-level": Options;
        "log-level": Options;
        "pushing-frequency": Options;
        "polling-frequency": Options;
        "mnemonic-file": Options;
        "price-service-endpoint": Options;
        "price-config-file": Options;
        endpoint: Options;
        "pyth-state-id": Options;
        "wormhole-state-id": Options;
        "num-gas-objects": Options;
        "ignore-gas-objects": Options;
        "gas-budget": Options;
        "account-index": Options;
    };
    handler: (argv: any) => Promise<void>;
};
export default _default;
//# sourceMappingURL=command.d.ts.map