import { HexString, UnixTimestamp } from "@pythnetwork/hermes-client";
import { DurationInSeconds } from "./utils";
import { Logger } from "pino";
import { PricePusherMetrics } from "./metrics";
export type PriceItem = {
    id: HexString;
    alias: string;
};
export type PriceInfo = {
    price: string;
    conf: string;
    publishTime: UnixTimestamp;
};
export interface IPriceListener {
    start(): Promise<void>;
    getLatestPriceInfo(priceId: string): PriceInfo | undefined;
}
export declare abstract class ChainPriceListener implements IPriceListener {
    private pollingFrequency;
    protected priceItems: PriceItem[];
    private latestPriceInfo;
    protected priceIdToAlias: Map<HexString, string>;
    constructor(pollingFrequency: DurationInSeconds, priceItems: PriceItem[]);
    start(): Promise<void>;
    private pollPrices;
    protected updateLatestPriceInfo(priceId: HexString, observedPrice: PriceInfo): void;
    getLatestPriceInfo(priceId: string): PriceInfo | undefined;
    abstract getOnChainPriceInfo(priceId: HexString): Promise<PriceInfo | undefined>;
}
export interface IPricePusher {
    updatePriceFeed(priceIds: string[], pubTimesToPush: UnixTimestamp[]): Promise<void>;
}
/**
 * Common configuration properties for all balance trackers
 */
export interface BaseBalanceTrackerConfig {
    /** Address of the wallet to track */
    address: string;
    /** Name/ID of the network/chain */
    network: string;
    /** How often to update the balance */
    updateInterval: DurationInSeconds;
    /** Metrics instance to report balance updates */
    metrics: PricePusherMetrics;
    /** Logger instance */
    logger: Logger;
}
/**
 * Interface for all balance trackers to implement
 * Each chain will have its own implementation of this interface
 */
export interface IBalanceTracker {
    /**
     * Start tracking the wallet balance
     */
    start(): Promise<void>;
    /**
     * Stop tracking the wallet balance
     */
    stop(): void;
}
/**
 * Abstract base class that implements common functionality for all balance trackers
 */
export declare abstract class BaseBalanceTracker implements IBalanceTracker {
    protected address: string;
    protected network: string;
    protected updateInterval: DurationInSeconds;
    protected metrics: PricePusherMetrics;
    protected logger: Logger;
    protected isRunning: boolean;
    constructor(config: BaseBalanceTrackerConfig);
    start(): Promise<void>;
    private startUpdateLoop;
    /**
     * Chain-specific balance update implementation
     * Each chain will implement this method differently
     */
    protected abstract updateBalance(): Promise<void>;
    stop(): void;
}
//# sourceMappingURL=interface.d.ts.map