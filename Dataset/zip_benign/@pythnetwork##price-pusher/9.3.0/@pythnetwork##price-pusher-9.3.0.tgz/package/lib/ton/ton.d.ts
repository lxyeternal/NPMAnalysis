import { HermesClient } from "@pythnetwork/hermes-client";
import { ChainPriceListener, IPricePusher, PriceInfo, PriceItem } from "../interface";
import { DurationInSeconds } from "../utils";
import { Logger } from "pino";
import { Address, ContractProvider, TonClient } from "@ton/ton";
export declare class TonPriceListener extends ChainPriceListener {
    private provider;
    private contractAddress;
    private logger;
    private contract;
    constructor(provider: ContractProvider, contractAddress: Address, priceItems: PriceItem[], logger: Logger, config: {
        pollingFrequency: DurationInSeconds;
    });
    getOnChainPriceInfo(priceId: string): Promise<PriceInfo | undefined>;
}
export declare class TonPricePusher implements IPricePusher {
    private client;
    private privateKey;
    private contractAddress;
    private hermesClient;
    private logger;
    private contract;
    private sender;
    constructor(client: TonClient, privateKey: string, contractAddress: Address, hermesClient: HermesClient, logger: Logger);
    updatePriceFeed(priceIds: string[], pubTimesToPush: number[]): Promise<void>;
}
//# sourceMappingURL=ton.d.ts.map