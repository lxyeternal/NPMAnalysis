import { HexString } from "@pythnetwork/hermes-client";
import { Logger } from "pino";
import { DurationInSeconds, PctNumber } from "./utils";
import { PriceInfo } from "./interface";
export type PriceConfig = {
    alias: string;
    id: HexString;
    timeDifference: DurationInSeconds;
    priceDeviation: PctNumber;
    confidenceRatio: PctNumber;
    customEarlyUpdate: boolean | undefined;
    earlyUpdateTimeDifference: DurationInSeconds | undefined;
    earlyUpdatePriceDeviation: PctNumber | undefined;
    earlyUpdateConfidenceRatio: PctNumber | undefined;
};
export declare function readPriceConfigFile(path: string): PriceConfig[];
export declare enum UpdateCondition {
    YES = 0,
    EARLY = 1,
    NO = 2
}
/**
 * Checks whether on-chain price needs to be updated with the latest pyth price information.
 *
 * @param priceConfig Config of the price feed to check
 * @returns True if the on-chain price needs to be updated.
 */
export declare function shouldUpdate(priceConfig: PriceConfig, sourceLatestPrice: PriceInfo | undefined, targetLatestPrice: PriceInfo | undefined, logger: Logger): UpdateCondition;
//# sourceMappingURL=price-config.d.ts.map