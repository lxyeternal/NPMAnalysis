import { IPricePusher, PriceInfo, ChainPriceListener, PriceItem } from "../interface";
import { HermesClient } from "@pythnetwork/hermes-client";
import { DurationInSeconds } from "../utils";
import { FinalExecutionOutcome } from "near-api-js/lib/providers/provider";
import { Logger } from "pino";
export declare class NearPriceListener extends ChainPriceListener {
    private account;
    private logger;
    constructor(account: NearAccount, priceItems: PriceItem[], logger: Logger, config: {
        pollingFrequency: DurationInSeconds;
    });
    getOnChainPriceInfo(priceId: string): Promise<PriceInfo | undefined>;
}
export declare class NearPricePusher implements IPricePusher {
    private account;
    private hermesClient;
    private logger;
    constructor(account: NearAccount, hermesClient: HermesClient, logger: Logger);
    updatePriceFeed(priceIds: string[], pubTimesToPush: number[]): Promise<void>;
    private getPriceFeedsUpdateData;
}
export declare class NearAccount {
    private pythAccountId;
    private account;
    constructor(network: string, accountId: string, nodeUrl: string, privateKeyPath: string | undefined, pythAccountId: string);
    getPriceUnsafe(priceId: string): Promise<any>;
    getUpdateFeeEstimate(data: string): Promise<any>;
    updatePriceFeeds(data: string, updateFee: any): Promise<FinalExecutionOutcome>;
    private getConnection;
}
//# sourceMappingURL=near.d.ts.map