import { Options } from "yargs";
declare const _default: {
    command: string;
    describe: string;
    builder: {
        "controller-log-level": Options;
        "log-level": Options;
        "pushing-frequency": Options;
        "polling-frequency": Options;
        "pyth-contract-address": Options;
        "price-service-endpoint": Options;
        "price-config-file": Options;
        "node-url": Options;
        network: Options;
        "account-id": Options;
        "private-key-path": Options;
    };
    handler: (argv: any) => Promise<void>;
};
export default _default;
//# sourceMappingURL=command.d.ts.map