import { Options } from "yargs";
export declare const priceServiceEndpoint: {
    "price-service-endpoint": Options;
};
export declare const pythContractAddress: {
    "pyth-contract-address": Options;
};
export declare const priceConfigFile: {
    "price-config-file": Options;
};
export declare const pollingFrequency: {
    "polling-frequency": Options;
};
export declare const pushingFrequency: {
    "pushing-frequency": Options;
};
export declare const mnemonicFile: {
    "mnemonic-file": Options;
};
export declare const logLevel: {
    "log-level": Options;
};
export declare const controllerLogLevel: {
    "controller-log-level": Options;
};
export declare const enableMetrics: {
    "enable-metrics": Options;
};
export declare const metricsPort: {
    "metrics-port": Options;
};
//# sourceMappingURL=options.d.ts.map