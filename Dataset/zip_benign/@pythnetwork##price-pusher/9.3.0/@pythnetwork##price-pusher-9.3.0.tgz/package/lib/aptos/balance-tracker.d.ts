import { BaseBalanceTracker, BaseBalanceTrackerConfig, IBalanceTracker } from "../interface";
import { DurationInSeconds } from "../utils";
import { PricePusherMetrics } from "../metrics";
import { Logger } from "pino";
/**
 * Aptos-specific configuration for balance tracker
 */
export interface AptosBalanceTrackerConfig extends BaseBalanceTrackerConfig {
    /** Aptos node endpoint URL */
    endpoint: string;
    /** Aptos account address */
    address: string;
    /** Optional decimal places for APT token (default: 8) */
    decimals?: number;
}
/**
 * Aptos-specific implementation of the balance tracker
 */
export declare class AptosBalanceTracker extends BaseBalanceTracker {
    private client;
    private aptosAddress;
    private decimals;
    constructor(config: AptosBalanceTrackerConfig);
    /**
     * Aptos-specific implementation of balance update
     * Fetches the native APT balance for the configured address
     */
    protected updateBalance(): Promise<void>;
}
/**
 * Parameters for creating an Aptos balance tracker
 */
export interface CreateAptosBalanceTrackerParams {
    endpoint: string;
    address: string;
    network: string;
    updateInterval: DurationInSeconds;
    metrics: PricePusherMetrics;
    logger: Logger;
    decimals?: number;
}
/**
 * Factory function to create a balance tracker for Aptos chain
 */
export declare function createAptosBalanceTracker(params: CreateAptosBalanceTrackerParams): IBalanceTracker;
//# sourceMappingURL=balance-tracker.d.ts.map