import { ChainPriceListener, IPricePusher, PriceInfo, PriceItem } from "../interface";
import { DurationInSeconds } from "../utils";
import { HermesClient } from "@pythnetwork/hermes-client";
import { Logger } from "pino";
export declare class AptosPriceListener extends ChainPriceListener {
    private pythModule;
    private endpoint;
    private logger;
    constructor(pythModule: string, endpoint: string, priceItems: PriceItem[], logger: Logger, config: {
        pollingFrequency: DurationInSeconds;
    });
    getOnChainPriceInfo(priceId: string): Promise<PriceInfo | undefined>;
}
export declare const APTOS_ACCOUNT_HD_PATH = "m/44'/637'/0'/0'/0'";
/**
 * The `AptosPricePusher` is designed for high-throughput of price updates.
 * Achieving this property requires sacrificing some nice-to-have features of other
 * pusher implementations that can reduce cost when running multiple pushers. Specifically,
 * this implementation does not use `update_price_feeds_if_necssary` and simulate the transaction
 * before submission.
 *
 * If multiple instances of this pusher are running in parallel, both of them will
 * land all of their pushed updates on-chain.
 */
export declare class AptosPricePusher implements IPricePusher {
    private hermesClient;
    private logger;
    private pythContractAddress;
    private endpoint;
    private mnemonic;
    private overrideGasPriceMultiplier;
    private lastSequenceNumber;
    private sequenceNumberLocked;
    constructor(hermesClient: HermesClient, logger: Logger, pythContractAddress: string, endpoint: string, mnemonic: string, overrideGasPriceMultiplier: number);
    /**
     * Gets price update data which then can be submitted to the Pyth contract to update the prices.
     * This will throw an axios error if there is a network problem or the price service returns a non-ok response (e.g: Invalid price ids)
     *
     * @param priceIds Array of hex-encoded price ids.
     * @returns Array of price update data.
     */
    getPriceFeedsUpdateData(priceIds: string[]): Promise<number[][]>;
    updatePriceFeed(priceIds: string[], pubTimesToPush: number[]): Promise<void>;
    private waitForTransactionConfirmation;
    private tryGetNextSequenceNumber;
}
//# sourceMappingURL=aptos.d.ts.map