import { HexString, HermesClient } from "@pythnetwork/hermes-client";
import { PriceInfo, IPriceListener, PriceItem } from "./interface";
import { Logger } from "pino";
export declare class PythPriceListener implements IPriceListener {
    private hermesClient;
    private priceIds;
    private priceIdToAlias;
    private latestPriceInfo;
    private logger;
    private lastUpdated;
    private healthCheckInterval?;
    constructor(hermesClient: HermesClient, priceItems: PriceItem[], logger: Logger);
    start(): Promise<void>;
    getLatestPriceInfo(priceId: HexString): PriceInfo | undefined;
    cleanup(): void;
}
//# sourceMappingURL=pyth-price-listener.d.ts.map