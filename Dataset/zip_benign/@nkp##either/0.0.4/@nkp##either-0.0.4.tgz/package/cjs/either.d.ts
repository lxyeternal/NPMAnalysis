export declare type LEFT = 'left';
export declare const LEFT: LEFT;
export declare type RIGHT = 'right';
export declare const RIGHT: RIGHT;
export interface EitherKindLike<R, L> {
    readonly value: L | R;
    readonly tag: LEFT | RIGHT;
    isLeft(): this is DefiniteLeftLike<L>;
    isRight(): this is DefiniteRightLike<R>;
    readonly zL: L;
    readonly zR: R;
}
export declare type LeftValue<T extends EitherKindLike<unknown, unknown>> = T['zL'];
export declare type RightValue<T extends EitherKindLike<unknown, unknown>> = T['zR'];
export declare type TagValue<T extends EitherKindLike<unknown, unknown>> = T['tag'];
export interface LeftLike<L> extends EitherKindLike<never, L> {
    readonly tag: LEFT;
    readonly value: L;
}
export interface RightLike<R> extends EitherKindLike<R, never> {
    readonly tag: RIGHT;
    readonly value: R;
}
export declare type MaybeEitherLike<R, L> = LeftLike<L> | RightLike<R>;
export declare type DefiniteLeftLike<L> = L extends never ? never : LeftLike<L>;
export declare type DefiniteRightLike<R> = R extends never ? never : RightLike<R>;
export declare type EitherLike<R, L> = DefiniteRightLike<R> | DefiniteLeftLike<L>;
export interface Left<L> extends EitherKind<never, L> {
    readonly tag: LEFT;
    readonly value: L;
}
export interface Right<R> extends EitherKind<R, never> {
    readonly tag: RIGHT;
    readonly value: R;
}
export declare type MaybeEither<R, L> = Left<L> | Right<R>;
export declare type DefiniteLeft<L> = L extends never ? never : Left<L>;
export declare type DefiniteRight<R> = R extends never ? never : Right<R>;
export declare type Either<R, L> = DefiniteRight<R> | DefiniteLeft<L>;
export declare class EitherKind<R, L> implements EitherKindLike<R, L> {
    readonly tag: LEFT | RIGHT;
    readonly value: L | R;
    readonly zR: R;
    readonly zL: L;
    constructor(tag: LEFT, value: L);
    constructor(tag: RIGHT, value: R);
    /**
     * Get the value
     *
     * @returns
     */
    unwrapLeft(): L;
    /**
     * Get the value
     *
     * @returns
     */
    unwrap(): R;
    /**
     * Is this Either a Left?
     *
     * @returns
     */
    isLeft(): this is DefiniteLeft<L>;
    /**
     * is this Either a Right?
     *
     * @returns
     */
    isRight(): this is DefiniteRight<R>;
    /**
     * Map both-sides of the either
     *
     * @param onRight
     * @param onLeft
     * @returns
     */
    bimap<NR, NL>(onRight: (rval: R) => NR, onLeft: (lval: L) => NL): this extends RightLike<R> ? DefiniteRight<NR> : this extends LeftLike<L> ? DefiniteLeft<NL> : Either<NR, NL>;
    /**
     * Map the right-side of the either
     *
     * @param onRight
     * @returns
     */
    map<NR>(onRight: (rval: R) => NR): this extends RightLike<R> ? DefiniteRight<NR> : this extends LeftLike<L> ? DefiniteLeft<L> : Either<NR, L>;
    /**
     * Map the left-side of the either
     *
     * @param onLeft
     * @returns
     */
    mapLeft<NL>(onLeft: (lval: L) => NL): this extends RightLike<R> ? DefiniteRight<R> : this extends LeftLike<L> ? DefiniteLeft<NL> : Either<R, NL>;
    /**
     * Flat-map the right-side of the either
     *
     * @param onRight
     * @returns
     */
    flatMap<E extends EitherLike<unknown, unknown>>(onRight: (rval: R) => E): this extends RightLike<R> ? Either<RightValue<E>, LeftValue<E>> : this extends LeftLike<L> ? DefiniteLeft<L> : Either<RightValue<E>, LeftValue<E> | L>;
    /**
     * Flat-map the left-side of the either
     *
     * @param onLeft
     * @returns
     */
    flatMapLeft<E extends EitherLike<unknown, unknown>>(onLeft: (lval: L) => E): this extends RightLike<R> ? DefiniteRight<R> : this extends LeftLike<L> ? Either<RightValue<E>, LeftValue<E>> : Either<RightValue<E> | R, LeftValue<E>>;
    /**
     * Map left-values to the right
     *
     * @param onLeft
     * @returns
     */
    orElse<NR>(onLeft: (lval: L) => NR): Right<NR | R>;
    /**
     * Flatten the right-side of the either
     *
     * @param this
     * @returns
     */
    flat(): this extends RightLike<RightLike<any>> ? DefiniteRight<RightValue<RightValue<this>>> : this extends RightLike<LeftLike<any>> ? DefiniteLeft<LeftValue<RightValue<this>>> : this extends RightLike<EitherLike<any, any>> ? Either<RightValue<RightValue<this>>, LeftValue<RightValue<this>>> : this extends LeftLike<L> ? DefiniteLeft<L> : Either<R, L>;
    /**
     * Fire a side-effect on the right-value
     *
     * @param onRight
     * @returns
     */
    tap(onRight: (value: R) => unknown): this;
    /**
     * Fire a side-effect on the left-value
     *
     * @param onLeft
     * @returns
     */
    tapLeft(onLeft: (value: L) => unknown): this;
    /**
     * Fire a side-effect on both sides
     *
     * @param onRight
     * @param onLeft
     * @returns
     */
    bitap(onRight: (value: R) => unknown, onLeft: (value: L) => unknown): this;
    /**
     * Fire a side-effect on the Either
     *
     * @param callbackfn
     * @returns
     */
    tapSelf(callbackfn: (self: this) => unknown): this;
    /**
     * Map the Either to some other value
     *
     * @param callbackfn
     * @returns
     */
    mapSelf<R>(callbackfn: (self: this) => R): R;
    /**
     * If isLeft, throw on the value
     *
     * @returns
     */
    throwLeft(): DefiniteRight<R>;
    /**
     * If isLeft, throw on the value
     *
     * @returns
     */
    throwRight(): DefiniteLeft<L>;
    /**
     * Swap right-to-left and left-to-right
     *
     * @returns
     */
    swap(): Either<L, R>;
}
export declare const Either: {
    /**
     * Is the Either a Left?
     *
     * @param either
     * @returns
     */
    isLeft<R, L>(either: Either<R, L>): either is DefiniteLeft<L>;
    /**
     * Is the Either a Right?
     *
     * @param either
     * @returns
     */
    isRight<R_1, L_1>(either: Either<R_1, L_1>): either is DefiniteRight<R_1>;
    /**
     * Create an Either from the value
     *
     * Right if not null
     * Left if null
     *
     * @param value
     * @returns
     */
    fromNull<R_2>(value: R_2 | null): Either<R_2, null>;
    /**
     * Create an Either from the value
     *
     * Right if not null and not undefined
     * Left if null or undefined
     *
     * @param value
     * @returns
     */
    fromNullable<R_3>(value: R_3 | null | undefined): Either<R_3, null | undefined>;
    /**
     * Create an Either from the value
     * Right if truthy
     * Left if falsy
     *
     * @param value
     * @returns
     */
    fromTruthy<R_4>(value: R_4): Either<R_4, R_4>;
    /**
     * Create an Either (Right) from the value
     *
     * @param rval
     * @returns
     */
    fromRight<R_5, L_2>(rval: R_5): Either<R_5, L_2>;
    /**
     * Create an Either (Left) from the value
     *
     * @param lval
     * @returns
     */
    fromLeft<R_6, L_3>(lval: L_3): Either<R_6, L_3>;
    /**
     * Create a Right from the value
     *
     * @param rval
     * @returns
     */
    right<R_7>(rval: R_7): Right<R_7>;
    /**
     * Create a Left from the value
     *
     * @param lval
     * @returns
     */
    left<L_4>(lval: L_4): Left<L_4>;
};
export declare const isLeft: <R, L>(either: Either<R, L>) => either is DefiniteLeft<L>;
export declare const isRight: <R, L>(either: Either<R, L>) => either is DefiniteRight<R>;
export declare const left: <L>(lval: L) => Left<L>;
export declare const right: <R>(rval: R) => Right<R>;
export declare const fromLeft: <R, L>(lval: L) => Either<R, L>;
export declare const fromRight: <R, L>(rval: R) => Either<R, L>;
