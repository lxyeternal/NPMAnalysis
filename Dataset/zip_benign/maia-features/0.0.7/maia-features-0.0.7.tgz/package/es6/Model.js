// Imports
// import fs
const fs = require('fs')
// const pa = require('path')
// const { Midi } = require('@tonejs/midi')
const mu = require('maia-util')
import CompObj from './CompObj'
import ProdObj from './ProdObj'
// import InstrObj from './InstrObj'

// Constructor for Model object
export default function Model(_co, _po, _io){
  // Workaround for JS context peculiarities.
  // var self = this;
  this.compObj = new CompObj(_co)
  this.prodObj = new ProdObj(_po, _co)
  // console.log("this.prodObj.finalNodes:", this.prodObj.finalNodes)
  // this.instrObj = new InstrObj(_io)

  // Possible to return something.
  // return sth;
}
// Methods for Model object
Model.prototype = {
  constructor: Model,

  get_linear_combination: function(objA, objB){
    let estimate = 0
    Object.keys(objA).forEach(function(k){
      estimate += objA[k]*objB[k]
    })
    return estimate
  },

  get_model: function(str, objExtraInfo){
    const self = this
    let means, rCoeffsByExpr, pcEstimates, returnObj
    switch (str){
      case "MCEC 2020 mel means":
      return {
        "anger": self.get_anger("MCEC 2020 mel means"),
        "calm": self.get_calm("MCEC 2020 mel means"),
        "epic-ness": self.get_epicness("MCEC 2020 mel means"),
        "excitement": self.get_excitement("MCEC 2020 mel means"),
        "fear": self.get_fear("MCEC 2020 mel means"),
        "happiness": self.get_happiness("MCEC 2020 mel means"),
        "love": self.get_love("MCEC 2020 mel means"),
        "mystery": self.get_mystery("MCEC 2020 mel means"),
        "sadness": self.get_sadness("MCEC 2020 mel means"),
        "tension": self.get_tension("MCEC 2020 mel means")
      }
      break

      case "MCEC 2020 PCA 2 var":
      // Rotation coefficients from principal component analysis for "MCEC 2020 PCA 2 var"
      means = {
        "anger": 1.789109,
        "calm": 2.289025,
        "epic-ness": 1.926204,
        "excitement": 2.182596,
        "fear": 2.220028,
        "happiness": 2.170933,
        "love": 2.024443,
        "mystery": 2.993755,
        "sadness": 2.495565,
        "tension": 2.848701
      }
      rCoeffsByExpr = {
        "anger": [0.2251766, -0.1543038],
        "calm": [-0.285443855, 0.40081295],
        "epic-ness": [0.054941502, -0.11635890],
        "excitement": [-0.002135978, -0.46230108],
        "fear": [0.407750878, -0.03577127],
        "happiness": [-0.383210093, -0.31251890],
        "love": [-0.256740033, 0.11309193],
        "mystery": [0.451491647, 0.15496094],
        "sadness": [0.125123721, 0.65732668],
        "tension": [0.516010985, -0.14299978]
      }
      pcEstimates = [
        self.get_pc_1("MCEC 2020 PCA"),
        self.get_pc_2("MCEC 2020 PCA")
      ]
      returnObj = {}
      Object.keys(rCoeffsByExpr).forEach(function(expr){
        const estimates = pcEstimates.map(function(pce){ return pce.estimate })
        returnObj[expr] = {
          "coeffs": rCoeffsByExpr[expr],
          "varVals": estimates,
          "estimate": means[expr] + self.get_linear_combination(
            rCoeffsByExpr[expr], estimates
          )
        }
      })
      return returnObj
      break

      case "MCEC 2020 PCA 3 var":
      // Rotation coefficients from principal component analysis for "MCEC 2020 PCA 3 var"
      means = {
        "anger": 1.789109,
        "calm": 2.289025,
        "epic-ness": 1.926204,
        "excitement": 2.182596,
        "fear": 2.220028,
        "happiness": 2.170933,
        "love": 2.024443,
        "mystery": 2.993755,
        "sadness": 2.495565,
        "tension": 2.848701
      }
      rCoeffsByExpr = {
        "anger": [0.2251766, -0.1543038, 0.0796661],
        "calm": [-0.285443855, 0.40081295, 0.3187015],
        "epic-ness": [0.054941502, -0.11635890, 0.3732359],
        "excitement": [-0.002135978, -0.46230108, 0.3941108],
        "fear": [0.407750878, -0.03577127, 0.1642048],
        "happiness": [-0.383210093, -0.31251890, 0.4211145],
        "love": [-0.256740033, 0.11309193, 0.4415214],
        "mystery": [0.451491647, 0.15496094, 0.3267878],
        "sadness": [0.125123721, 0.65732668, 0.2580496],
        "tension": [0.516010985, -0.14299978, 0.1575837]
      }
      pcEstimates = [
        self.get_pc_1("MCEC 2020 PCA"),
        self.get_pc_2("MCEC 2020 PCA"),
        self.get_pc_3("MCEC 2020 PCA")
      ]
      returnObj = {}
      Object.keys(rCoeffsByExpr).forEach(function(expr){
        const estimates = pcEstimates.map(function(pce){ return pce.estimate })
        returnObj[expr] = {
          "coeffs": rCoeffsByExpr[expr],
          "varVals": estimates,
          "estimate": means[expr] + self.get_linear_combination(
            rCoeffsByExpr[expr], estimates
          )
        }
      })
      return returnObj
      break

      case "Music Perception 2011":
      return self.get_noticeability_importance(
        str, objExtraInfo["pOcc"], objExtraInfo["occSet"],
        objExtraInfo["mode"], objExtraInfo["projDSet"], objExtraInfo["tfPitch"]
      )

      default:
      console.log("Should not get here in get_model() switch!")
    }
  },

  get_anger: function(str){
    let coeffs, varVals, estimate
    switch (str){
      case "MCEC 2020 mel means":
      coeffs = {
        "Intercept": 2.171800,
        "Vol max": 1.205798,
        "Tonal ambiguity": 0.704788,
        "Mean pitch": -0.027710,
        "Melodic interval 2": -0.985078,
        "Nos notes": 0.029890,
        "Melodic interval 6": 1.583219,
        "Stepwise motion": 0.421074
      }
      varVals = {
        "Intercept": 1,
        "Vol max": this.prodObj.max("volume"),
        "Tonal ambiguity": this.compObj.tonal_ambiguity(),
        "Mean pitch": this.compObj.mean_pitch(),
        "Melodic interval 2": this.compObj.semitone_interval(2),
        "Nos notes": this.compObj.finalNotes.length,
        "Melodic interval 6": this.compObj.semitone_interval(6),
        "Stepwise motion": this.compObj.stepwise_motion("MNN")
      }
      return {
        "coeffs": coeffs,
        "varVals": varVals,
        "estimate": this.get_linear_combination(coeffs, varVals)
      }
      break

      default:
      console.log("Should not get here in get_anger() switch!")
    }
  },

  get_calm: function(str){
    let coeffs, varVals, estimate
    switch (str){
      case "MCEC 2020 mel means":
      coeffs = {
        "Intercept": 4.185992,
        "Tonal ambiguity": -2.321802,
        "Vol mean": -1.683964,
        "Melodic interval 2": 0.995594,
        "Tempo max": -0.006490,
        "Mean note duration": 0.289221,
        "Interval between most prevalent pitch classes": -0.035938
      }
      varVals = {
        "Intercept": 1,
        "Tonal ambiguity": this.compObj.tonal_ambiguity(),
        "Vol mean": this.prodObj.mean("volume"),
        "Melodic interval 2": this.compObj.semitone_interval(2),
        "Tempo max": this.prodObj.max("tempo"),
        "Mean note duration": this.compObj.mean_note_duration("120 bpm seconds"),
        "Interval between most prevalent pitch classes": this.compObj.interval_most_prevalent_pcs()
      }
      return {
        "coeffs": coeffs,
        "varVals": varVals,
        "estimate": this.get_linear_combination(coeffs, varVals)
      }
      break

      default:
      console.log("Should not get here in get_calm() switch!")
    }
  },

  get_epicness: function(str){
    let coeffs, varVals, estimate
    switch (str){
      case "MCEC 2020 mel means":
      coeffs = {
        "Intercept": 1.170138,
        "Vol max": 0.614704,
        "Nos notes": 0.066608,
        "Most common pitch": -0.015508,
        "Relative note density of highest line": 0.093754
      }
      varVals = {
        "Intercept": 1,
        "Vol max": this.prodObj.max("volume"),
        "Nos notes": this.compObj.finalNotes.length,
        "Most common pitch": this.compObj.most_common_pitch(),
        "Relative note density of highest line": this.compObj.rel_note_density_highest_line("MNN")
      }
      return {
        "coeffs": coeffs,
        "varVals": varVals,
        "estimate": this.get_linear_combination(coeffs, varVals)
      }
      break

      default:
      console.log("Should not get here in get_calm() switch!")
    }
  },

  get_excitement: function(str){
    let coeffs, varVals, estimate
    switch (str){
      case "MCEC 2020 mel means":
      coeffs = {
        "Intercept": 0.081536,
        "Note density per quarter note": 2.188148,
        "Tempo mean": 0.011070
      }
      varVals = {
        "Intercept": 1,
        "Note density per quarter note": this.compObj.note_density("overall", 0.5),
        "Tempo mean": this.prodObj.mean("tempo")
      }
      return {
        "coeffs": coeffs,
        "varVals": varVals,
        "estimate": this.get_linear_combination(coeffs, varVals)
      }
      break

      default:
      console.log("Should not get here in get_excitement() switch!")
    }
  },

  get_fear: function(str){
    let coeffs, varVals, estimate
    switch (str){
      case "MCEC 2020 mel means":
      coeffs = {
        "Intercept": 2.688893,
        "Tonal ambiguity": 1.473050,
        "Melodic interval 2": -1.797602,
        "Major key clarity": -0.355564,
        "Melodic interval 6": 2.947358,
        "Stepwise motion": 0.845380,
        "Importantce of middle register": -0.545738,
        "Tempo min": -0.005788,
        "Vol max": 0.696912,
        "Melodic interval 22": 9.456105,
        "Number of common melodic intervals": -0.073228
      }
      varVals = {
        "Intercept": 1,
        "Tonal ambiguity": this.compObj.tonal_ambiguity(),
        "Melodic interval 2": this.compObj.semitone_interval(2),
        "Major key clarity": this.compObj.major_key_clarity(),
        "Melodic interval 6": this.compObj.semitone_interval(6),
        "Stepwise motion": this.compObj.stepwise_motion("MNN"),
        "Importantce of middle register": this.compObj.proportion_of_notes_in_interval(55, 72, "MNN"),
        "Tempo min": this.prodObj.min("tempo"),
        "Vol max": this.prodObj.max("volume"),
        "Melodic interval 22": this.compObj.semitone_interval(22),
        "Number of common melodic intervals": this.compObj.number_of_common_melodic_intervals(0.09),
      }
      return {
        "coeffs": coeffs,
        "varVals": varVals,
        "estimate": this.get_linear_combination(coeffs, varVals)
      }
      break

      default:
      console.log("Should not get here in get_fear() switch!")
    }
  },

  get_happiness: function(str){
    let coeffs, varVals, estimate
    switch (str){
      case "MCEC 2020 mel means":
      coeffs = {
        "Intercept": -0.683056,
        "Tonal ambiguity": -2.394471,
        "Tempo min": 0.013177,
        "Major key clarity": 0.557891,
        "Melodic interval 2": 1.205729,
        "Note density per quarter note": 1.621685,
        "Tempo std": 0.012251,
        "Mean pitch": 0.017796
      }
      varVals = {
        "Intercept": 1,
        "Tonal ambiguity": this.compObj.tonal_ambiguity(),
        "Tempo min": this.prodObj.min("tempo"),
        "Major key clarity": this.compObj.major_key_clarity(),
        "Melodic interval 2": this.compObj.semitone_interval(2),
        "Note density per quarter note": this.compObj.note_density("overall", 0.5),
        "Tempo std": this.prodObj.std("tempo"),
        "Mean pitch": this.compObj.mean_pitch()
      }
      return {
        "coeffs": coeffs,
        "varVals": varVals,
        "estimate": this.get_linear_combination(coeffs, varVals)
      }
      break

      default:
      console.log("Should not get here in get_happiness() switch!")
    }
  },

  get_love: function(str){
    let coeffs, varVals, estimate
    switch (str){
      case "MCEC 2020 mel means":
      coeffs = {
        "Intercept": 0.689927,
        "Tonal ambiguity": -1.804094,
        "Melodic interval 2": 0.888822,
        "Mean pitch": 0.022910,
        "Vol mean": -0.863850,
        "Pitch class kurtosis": 0.043741,
        "Melodic pitch variety": 0.076339,
        "Rhythmic value median run lengths": -0.016583,
        "Direction of melodic motion": 0.521616
      }
      varVals = {
        "Intercept": 1,
        "Tonal ambiguity": this.compObj.tonal_ambiguity(),
        "Melodic interval 2": this.compObj.semitone_interval(2),
        "Mean pitch": this.compObj.mean_pitch(),
        "Vol mean": this.prodObj.mean("volume"),
        "Pitch class kurtosis": this.compObj.pitch_class_kurtosis(),
        "Melodic pitch variety": this.compObj.melodic_pitch_variety("MNN", 16),
        "Rhythmic value median run lengths": this.compObj.rhythmic_value_median_run_lengths_histogram(2),
        "Direction of melodic motion": this.compObj.direction_of_melodic_motion("MNN")
      }
      return {
        "coeffs": coeffs,
        "varVals": varVals,
        "estimate": this.get_linear_combination(coeffs, varVals)
      }
      break

      default:
      console.log("Should not get here in get_love() switch!")
    }
  },

  get_mystery: function(str){
    let coeffs, varVals, estimate
    switch (str){
      case "MCEC 2020 mel means":
      coeffs = {
        "Intercept": 3.621302,
        "Tonal ambiguity": 2.643699,
        "Melodic interval 2": -1.596088,
        "Reverb wet max": 0.784310,
        "Major key clarity": -0.529417,
        "Tempo mean": -0.009374
      }
      varVals = {
        "Intercept": 1,
        "Tonal ambiguity": this.compObj.tonal_ambiguity(),
        "Melodic interval 2": this.compObj.semitone_interval(2),
        "Reverb wet max": this.prodObj.max(["reverb", "wet"]),
        "Major key clarity": this.compObj.major_key_clarity(),
        "Tempo mean": this.prodObj.mean("tempo")
      }
      return {
        "coeffs": coeffs,
        "varVals": varVals,
        "estimate": this.get_linear_combination(coeffs, varVals)
      }
      break

      default:
      console.log("Should not get here in get_mystery() switch!")
    }
  },

  get_sadness: function(str){
    let coeffs, varVals, estimate
    switch (str){
      case "MCEC 2020 mel means":
      coeffs = {
        "Intercept": 4.168684,
        "Tempo mean": -0.016278,
        "Major key clarity": -0.535303,
        "Vol mean": -1.346115,
        "Reverb wet slope abs": 0.171942,
        "Most common melodic interval": -0.044914,
        "Average time between attacks": 0.791346
      }
      varVals = {
        "Intercept": 1,
        "Tempo mean": this.prodObj.mean("tempo"),
        "Major key clarity": this.compObj.major_key_clarity(),
        "Vol mean": this.prodObj.mean("volume"),
        "Reverb wet slope abs": this.prodObj.slope_abs(["reverb", "wet"]),
        "Most common melodic interval": this.compObj.most_common_melodic_interval(),
        "Average time between attacks": this.compObj.average_time_between_attacks("all channels")
      }
      return {
        "coeffs": coeffs,
        "varVals": varVals,
        "estimate": this.get_linear_combination(coeffs, varVals)
      }
      break

      default:
      console.log("Should not get here in get_sadness() switch!")
    }
  },

  get_tension: function(str){
    let coeffs, varVals, estimate
    switch (str){
      case "MCEC 2020 mel means":
      coeffs = {
        "Intercept": 2.553166,
        "Tonal ambiguity": 2.495053,
        "Melodic interval 2": -2.400520,
        "Vol max": 1.280912,
        "Importance of middle register": -0.697475,
        "Stepwise motion": 1.125714,
        "Melodic interval 6": 2.885573,
        "Tempo min": -0.006872,
        "Rhythmic value skewness": -0.106179
      }
      varVals = {
        "Intercept": 1,
        "Tonal ambiguity": this.compObj.tonal_ambiguity(),
        "Melodic interval 2": this.compObj.semitone_interval(2),
        "Vol max": this.prodObj.max("volume"),
        "Importance of middle register": this.compObj.proportion_of_notes_in_interval(55, 72, "MNN"),
        "Stepwise motion": this.compObj.stepwise_motion("MNN"),
        "Melodic interval 6": this.compObj.semitone_interval(6),
        "Tempo min": this.prodObj.min("tempo"),
        "Rhythmic value skewness": this.compObj.duration_median_skewness(1)
      }
      return {
        "coeffs": coeffs,
        "varVals": varVals,
        "estimate": this.get_linear_combination(coeffs, varVals)
      }
      break

      default:
      console.log("Should not get here in get_tension() switch!")
    }
  },

  get_pc_1: function(str){
    let coeffs, varVals, estimate
    switch (str){
      case "MCEC 2020 PCA":
      coeffs = {
        "Intercept": 0.689927,
        "Tonal ambiguity": -1.804094,
        "Melodic interval 2": 0.888822,
        "Mean pitch": 0.022910,
        "Vol mean": -0.863850,
        "Pitch class kurtosis": 0.043741,
        "Melodic pitch variety": 0.076339,
        "Rhythmic value median run lengths": -0.016583,
        "Direction of melodic motion": 0.521616
      }
      varVals = {
        "Intercept": 1,
        "Tonal ambiguity": this.compObj.tonal_ambiguity(),
        "Melodic interval 2": this.compObj.semitone_interval(2),
        "Mean pitch": this.compObj.mean_pitch(),
        "Vol mean": this.prodObj.mean("volume"),
        "Pitch class kurtosis": this.compObj.pitch_class_kurtosis(),
        "Melodic pitch variety": this.compObj.melodic_pitch_variety("MNN", 16),
        "Rhythmic value median run lengths": this.compObj.rhythmic_value_median_run_lengths_histogram(2),
        "Direction of melodic motion": this.compObj.direction_of_melodic_motion("MNN")
      }
      return {
        "coeffs": coeffs,
        "varVals": varVals,
        "estimate": this.get_linear_combination(coeffs, varVals)
      }
      break

      default:
      console.log("Should not get here in pc_1() switch!")
    }
  },

  get_pc_2: function(str){
    let coeffs, varVals, estimate
    switch (str){
      case "MCEC 2020 PCA":
      coeffs = {
        "Intercept": 5.755274,
        "Tempo mean": -0.019332,
        "Note density per quarter note": -4.068881,
        "Vol mean": -2.148572,
        "Minor key clarity": 0.505087,
        "Most common melodic interval": -0.052825,
        "Direction of melodic motion": -0.733934,
        "Vol max": -0.739628,
        "Pitch class skewness": 0.105818,
        "Complete rests fraction": -0.961648,
        "Note density per quarter note variability": -1.194297
      }
      varVals = {
        "Intercept": 1,
        "Tempo mean": this.prodObj.mean("tempo"),
        "Note density per quarter note": this.compObj.note_density("overall", 0.5),
        "Vol mean": this.prodObj.mean("volume"),
        "Minor key clarity": this.compObj.minor_key_clarity(),
        "Most common melodic interval": this.compObj.most_common_melodic_interval(),
        "Direction of melodic motion": this.compObj.direction_of_melodic_motion("MNN"),
        "Vol max": this.prodObj.max("volume"),
        "Pitch class skewness": this.compObj.pitch_class_median_skewness("MNN"),
        "Complete rests fraction": this.compObj.complete_rests_fraction(),
        "Note density per quarter note variability": this.compObj.note_density_std(4, 4)
      }
      return {
        "coeffs": coeffs,
        "varVals": varVals,
        "estimate": this.get_linear_combination(coeffs, varVals)
      }
      break

      default:
      console.log("Should not get here in pc_2() switch!")
    }
  },

  get_pc_3: function(str){
    let coeffs, varVals, estimate
    switch (str){
      case "MCEC 2020 PCA":
      coeffs = {
        "Intercept": -0.04034,
        "Vol min": -0.75472,
        "Pitch range": 0.08319,
        "Melodic interval 10": -3.11077,
        "Pitch variability": -0.15474
      }
      varVals = {
        "Intercept": 1,
        "Vol min": this.prodObj.min("volume"),
        "Pitch range": this.compObj.pitch_range("MNN"),
        "Melodic interval 10": this.compObj.semitone_interval(10),
        "Pitch variability": this.compObj.pitch_std("MNN")
      }
      return {
        "coeffs": coeffs,
        "varVals": varVals,
        "estimate": this.get_linear_combination(coeffs, varVals)
      }
      break

      default:
      console.log("Should not get here in pc_3() switch!")
    }
  },

  get_noticeability_importance: function(str, pOcc, occSet, mode, projDSet, tfPitch){
    // pOcc is the query or archetypal pattern occurrence.
    // occSet is the occurrence set, including the query/archetypal occurrence.
    let coeffs, varVals, estimate
    switch (str){
      case "Music Perception 2011":
      const a = 73.5383283152 // Coefficient for normalising expectedOccurrences.
      const b = 0.02114878519   // Exponent for normalising expectedOccurrences.
      coeffs = {
        "Intercept": 4.277867,
        "Compactness": 3.422478734,
        "Norm expected occurrences": -0.038536808,
        "Compression ratio": 0.651073171
      }
      varVals = {
        "Intercept": 1,
        "Compactness": this.compObj.compactness(pOcc, projDSet, mode),
        "Norm expected occurrences": a*Math.pow(
          this.compObj.expected_occurrences(pOcc, tfPitch, mode, projDSet), b
        ),
        "Compression ratio": this.compObj.compression_ratio(occSet)
      }
      return {
        "coeffs": coeffs,
        "varVals": varVals,
        "estimate": this.get_linear_combination(coeffs, varVals)
      }
      break

      default:
      console.log("Should not get here in get_noticeability_importance() switch!")
    }
  }

}
