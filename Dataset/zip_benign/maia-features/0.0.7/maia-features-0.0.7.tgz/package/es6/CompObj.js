// Imports
// import fs
const fs = require('fs')
const pa = require('path')
const { Midi } = require('@tonejs/midi')
const mu = require('maia-util')
// import PointSet from './PointSet'

// Constructor for CompObj object
export default function CompObj(_data, _melodyMode = "top new MNN"){
  // Workaround for JS context peculiarities.
  // var self = this;
  this.data = _data
  this.melodyMode = _melodyMode

  // Constants
  this.ontimeIdx = 0
  this.mnnIdx = 1
  this.mpnIdx = 2
  this.durIdx = 3
  this.staffIdx = 4
  this.velIdx = 5
  this.maxInterval = 24 // For melodic interval histogram
  this.targetDurations = [
    "0.125", // thirty-second notes (or less)
    "0.25",  // sixteenth notes
    "0.5",   // eighth notes
    "0.75",  // dotted eighth notes
    "1",     // quarter notes
    "1.5",   // dotted quarter notes
    "2",     // half notes
    "3",     // dotted half notes
    "4",     // whole notes
    "6",     // dotted whole notes
    "8",     // double whole notes
    "12",    // dotted double whole notes (or more)
  ]

  // Calculations
  this.finalNotes = this.data.notes.filter(function(n){
    return n.stampDelete == null
  })
  .sort(mu.sort_points_asc)
  this.points = mu.sort_rows(
    mu.comp_obj2note_point_set({ "notes": this.finalNotes })
  )[0]
  this.pointsByStaff = this.points_by_staff()
  // console.log("this.pointsByStaff:", this.pointsByStaff)

  this.segments = mu.segment(this.points, true, this.ontimeIdx, this.durIdx)

  this.fifthStepsMode = mu.fifth_steps_mode(
    this.points,
    mu.krumhansl_and_kessler_key_profiles,
    this.mnnIdx, this.durIdx
  )

  this.melodyPoints = this.melody_points(this.melodyMode)
  // console.log("this.melodyPoints.length:", this.melodyPoints.length)
  this.intervalHistogram = this.interval_histogram()
  // console.log("this.intervalHistogram:", this.intervalHistogram)

  this.empiricalDistribution = this.empirical_distribution()

  // Possible to return something.
  // return sth;
}

// Methods for CompObj object
CompObj.prototype = {
  constructor: CompObj,

  // average_ioi: use ioi then mu.mean().

  average_pitch_interval: function(maxInterval = this.maxInterval){
    // Yang and Lerch (2020) feature
    const hist = this.interval_histogram(maxInterval)
    // Calculate and return the weighted sum.
    return hist.reduce(function(a, b, i){
      return a + i*b
    }, 0)
  },

  average_time_between_attacks: function(mode = "all channels"){
    const self = this
    let m = 0
    switch (mode){
      case "all channels":
      if (self.points.length > 1){
        m = mu.mean(
          self.points
          .map(function(p, idx){
            if (idx > 0){
              return p[self.ontimeIdx] - self.points[idx - 1][self.ontimeIdx]
            }
          })
          .filter(function(p, idx){
            return idx > 0
          })
        )
      }
      break
      case "per channel":
      // UNTESTED!
      const staveNos = Object.key(self.pointsByStaff)
      const avgTimesPerChannel = staveNos.map(function(stv){
        if (self.pointsByStaff[stv].length > 1){
          return mu.mean(
            self.pointsByStaff[stv]
            .map(function(p, idx){
              if (idx > 0){
                return p[self.ontimeIdx] - self.pointsByStaff[stv][idx - 1][self.ontimeIdx]
              }
            })
            .filter(function(p, idx){
              return idx > 0
            })
          )
        }
      })
      .filter(function(avgTime, idx){
        return avgTime !== undefined
      })
      if (avgTimesPerChannel.length > 0){
        m = mu.mean(avgTimesPerChannel)
      }
      break
      default:
      console.log("Should not get here in average_time_between_attacks() switch!")
    }
    return m
  },

  compactness: function(
    pOcc, projDSet = this.points, mode = "points", regionType = "temporal"
  ){
    // This method is written to allow some flexibility in the dataset used as
    // the comparison. For example, if we are operating on a reduced set of
    // dimensions (reduced from ontime, MNN, MPN, duration, channel, velocity),
    // and calculating compactness for multiple pattern occurrences, then it is
    // more efficient to calculate the projection of the comparison dataset
    // once, outside of this method, then pass in the projection as the projDSet
    // argument.

    // The most efficient way to calculate compactness is to leave everything as
    // indices rather than points. This method offers this most efficient
    // calculation, called by setting mode to indices. But it also offers the
    // less efficient way of locating the first and last pattern occurrence
    // points in the dataset, and basing the calculation on the indices of
    // these.

    // At present, more complex approaches to compactness calculations, e.g.,
    // involving convex hulls, are not implemented.
    if (mode === "indices" && regionType === "temporal"){
      // pOcc[0] is the index of the first pattern occurrence point in the
      // dataset;
      // pOcc[pOcc.length - 1] is the index of the last pattern occurrence point
      // in the datset.
      return pOcc.length/(pOcc[pOcc.length - 1] - pOcc[0] + 1)
    }
    else if (mode === "points" && regionType === "temporal"){
      const tol = 0.00002
      // Find indices of first and last pattern occurrence points in the
      // dataset.
      const i0 = projDSet.findIndex(function(pt){
        return pt.approx_equals(pOcc[0], tol)
      })
      // console.log("i0:", i0)
      const i1 = projDSet.findIndex(function(pt){
        return pt.approx_equals(pOcc[pOcc.length - 1], tol)
      })
      // console.log("i1:", i1)
      if (i0 < 0 || i1 < 0){
        console.log(
          "Could not find first or last pattern occurrence point. " +
          "Returning early!"
        )
        return
      }
      else {
        return pOcc.length/(i1 - i0 + 1)
      }
    }
  },

  complete_rests_fraction: function(){
    let restsDur = 0
    this.segments.forEach(function(seg){
      if (seg.points.length == 0){
        restsDur += seg.offtime - seg.ontime
      }
    })
    return restsDur/(
      this.segments[this.segments.length - 1].offtime - this.segments[0].ontime
    )
  },

  compression_ratio: function(occSet){
    // Assumes non-overlapping occurrences.
    const cardinalities = occSet.map(function(occ){
      return occ.length
    })
    const numerator = mu.array_sum(cardinalities)
    // console.log("numerator:", numerator)
    const denominator = mu.mean(cardinalities) + occSet.length - 1
    // console.log("denominator:", denominator)
    return numerator/denominator
  },

  direction_of_melodic_motion: function(str = "MNN"){
    let self = this
    let ups = 0
    let downs = 0
    if (str == "MPN"){
      self.melodyPoints.forEach(function(p, idx){
        if (idx > 0){
          const diff = p[self.mpnIdx] - self.melodyPoints[idx - 1][self.mpnIdx]
          if (diff > 0){ ups++ }
          else if (diff < 0){ downs++ }
        }
      })
    }
    else {
      self.melodyPoints.forEach(function(p, idx){
        if (idx > 0){
          const diff = p[self.mnnIdx] - self.melodyPoints[idx - 1][self.mnnIdx]
          if (diff > 0){ ups++ }
          else if (diff < 0){ downs++ }
        }
      })
    }
    return ups/(ups + downs)
  },

  duration_median_skewness: function(sf = 1){
    const self = this
    return mu.median_skewness(this.points.map(function(p){ return sf*p[self.durIdx] }))
  },

  empirical_distribution: function(){
    // The calculation assumes that we want to work just with the MNN dimension
    // when calculating the empirical distribution.
    const self = this
    let indicator = new Array(this.mnnIdx + 1).fill(0)
    indicator[self.mnnIdx] = 1
    const theCount = mu.count_rows(
      mu.orthogonal_projection_not_unique_equalp(this.points, indicator)
    )
    // Append the relative frequencies.
    const relFreq = theCount[1].map(function(c){
      return c/self.points.length
    })
    theCount.push(relFreq)
    return theCount
  },

  empirical_probability: function(pOcc, tfPitch){
    // This method takes a pattern occurrence pOcc and an already-calculated
    // empirical distribution. The sum of the probabilities of all permissible
    // translations of pOcc is returned. As durational patterns are not thought
    // to have any permissible translations, the second argument tfPitch = true
    // if pOcc includes a dimension for pitch, and tfPitch = false otherwise.
    const self = this
    const eDistbn = self.empiricalDistribution
    // Strip pattern of its ontime values.
    const s = pOcc.map(function(pt){
      const pt2 = pt.slice()
      pt2.splice(self.ontimeIdx, 1)
      return pt2
    })
    // console.log("s:", s)

    let p = 0
    if (tfPitch){
      // Determine permissible translations of s.
      const minPatternPitch = mu.min_argmin(s.map(pt => pt[self.mnnIdx - 1]))[0]
      const maxPatternPitch = mu.max_argmax(s.map(pt => pt[self.mnnIdx - 1]))[0]
      // console.log("minPatternPitch:", minPatternPitch)
      // console.log("maxPatternPitch:", maxPatternPitch)
      const minDatasetPitch = eDistbn[0][0][self.mnnIdx - 1]
      const maxDatasetPitch = eDistbn[0][eDistbn[0].length - 1][self.mnnIdx - 1]
      // console.log("minDatasetPitch:", minDatasetPitch)
      // console.log("maxDatasetPitch:", maxDatasetPitch)

      // Iterate over them.
      const k = minDatasetPitch - minPatternPitch
      const K = maxDatasetPitch - maxPatternPitch
      for (let i = k; i <= K; i++){
        // Translate s by i.
        const sTrans = mu.copy_point_set(s)
        .map(function(pt){
          pt[self.mnnIdx - 1] += i
          return pt
        })
        // console.log("i", i, "sTrans:", sTrans)
        const lp = self.empirical_log_probability(sTrans)
        // console.log("lp:", lp)
        p += Math.exp(self.empirical_log_probability(sTrans))
      }
    }
    else {
      p = Math.exp(self.empirical_log_probability(s))
    }
    return p
  },

  empirical_log_probability: function(s){
    // This method takes an array s consisting of "row vectors", which is the
    // result of stripping some pattern occurrence of its ontime values. The
    // other (built-into-the-class) argument is an empirical distribution in
    // which rows of s appear with relative frequencies p1, p2,..., pn. The sum
    // of the natural logarithms of these probabilities is returned.

    // const s = [[60], [60], [63], [61]]
    // const eMass = [
    //   [[ 60 ], [ 61 ], [ 63 ], [ 66 ]],
    //   [ 6, 3, 1, 3 ],
    //   [
    //     0.46153846153846156,
    //     0.23076923076923078,
    //     0.07692307692307693,
    //     0.23076923076923078
    //   ]
    // ]

    const tol = 0.00002
    let logp = 0
    for (let i = 0; i < s.length; i++){
      const relIdx = this.empiricalDistribution[0].findIndex(function(e){
        return e.approx_equals(s[i], tol)
      })
      // console.log("relIdx:", relIdx)
      if (relIdx < 0){
        return -Infinity
      }
      else {
        logp += Math.log(this.empiricalDistribution[2][relIdx])
      }
    }
    return logp
  },

  expected_occurrences: function(
    pOcc, tfPitch, mode = "points", projDSet = this.points
  ){
    const tol = 0.00002
    let span
    if (mode === "indices"){
      span = pOcc[pOcc.length - 1] - pOcc[0] + 1
      pOcc = pOcc.map(function(idx){
        return projDSet[idx]
      })
    }
    else {
      // Find indices of first and last pattern occurrence points in the
      // dataset.
      const i0 = projDSet.findIndex(function(pt){
        return pt.approx_equals(pOcc[0], tol)
      })
      const i1 = projDSet.findIndex(function(pt){
        return pt.approx_equals(pOcc[pOcc.length - 1], tol)
      })
      if (i0 < 0 || i1 < 0){
        console.log(
          "Could not find first or last pattern occurrence point. " +
          "Returning early!"
        )
        return
      }
      span = i1 - i0 + 1
    }
    const p = this.empirical_probability(pOcc, tfPitch)
    const K = mu.binomial_coefficient(span, pOcc.length) +
    (projDSet.length - span)*mu.binomial_coefficient(span - 1, pOcc.length - 1)
    return K*p
  },

  get_integer_points: function(multiplier = 24, dimensions = ["ontimeIdx", "mnnIdx"]){
    const self = this
    const pts2 = self.points.map(function(pt){
      const pt2 = []
      dimensions.forEach(function(dim){
        if (dim === "ontimeIdx" || dim === "durationIdx"){
          pt2.push(Math.round(multiplier*pt[self[dim]]))
        }
        else {
          pt2.push(pt[self[dim]])
        }
      })
      return pt2
    })

    return mu.unique_rows(pts2)[0]
  },

  ioi: function(removeZeros = true){
    const tol = 0.00002
    const self = this
    let D = self.points.slice(1).map(function(pt, idx){
      return pt[self.ontimeIdx] - self.points[idx][self.ontimeIdx]
    })
    if (removeZeros){
      D = D.filter(function(val){
        return Math.abs(val) > tol
      })
    }
    return D
  },

  interval_most_prevalent_pcs: function(prop = "MNN"){
    let c
    switch(prop){
      case "MNN":
      c = mu.count_rows(this.finalNotes.map(function(n){
        return [n.MNN % 12]
      }))
      if (c[0].length > 1){
        let diff = mu.mod(c[0][0] - c[1][0], 12)
        if (diff > 6){
          diff = 12 - diff
        }
        return diff
      }
      break
      case "MPN":
      c = mu.count_rows(this.finalNotes.map(function(n){
        return [n.MPN % 7]
      }))
      if (c[0].length > 1){
        let diff = mu.mod(c[0][0] - c[1][0], 7)
        if (diff > 3){
          diff = 7 - diff
        }
        return diff
      }
      break
      default:
      console.log("Should not get here in interval_most_prevalent_pcs() switch!")
    }

  },

  interval_histogram: function(maxInterval = this.maxInterval){
    let self = this
    // Set up bins to count intervals.
    let bins = new Array(maxInterval + 1)
    for (let i = 0; i <= maxInterval; i++){
      bins[i] = 0
    }
    self.melodyPoints.forEach(function(p, idx){
      if (idx > 0){
        const mnnInterval = Math.abs(p[self.mnnIdx] - self.melodyPoints[idx - 1][self.mnnIdx])
        if (mnnInterval <= maxInterval){
          bins[mnnInterval]++
        }
      }
    })
    return bins.map(function(b){
      return b/(self.melodyPoints.length - 1)
    })
  },

  major_key_clarity: function(){
    let majorKeyClarity = 0
    if (this.fifthStepsMode[0].indexOf("major") >= 0){
      majorKeyClarity = this.fifthStepsMode[1]
    }
    return majorKeyClarity
  },

  mean_note_duration: function(mode = "crotchets"){
    let m
    switch (mode){
      case "crotchets":
      m = mu.mean(this.finalNotes.map(function(n){ return n.duration }))
      break
      case "120 bpm seconds":
      m = mu.mean(this.finalNotes.map(function(n){ return n.duration }))/2
      break
      default:
      console.log("Should not get here in mean_note_duration() switch!")
    }
    return m
  },

  mean_pitch: function(prop = "MNN", staffNo = null){
    let relPropArr
    if (staffNo == null){
      relPropArr = this.finalNotes.map(function(n){ return n[prop] })
    }
    else {
      relPropArr = this.finalNotes.filter(function(n){
        return n.staffNo == staffNo
      })
      .map(function(n){ return n[prop] })
    }
    // Compliance with another feature library:
    return Math.floor(mu.mean(relPropArr))
    // Would prefer:
    // return mu.mean(relPropArr)
  },

  // This is a channel- or staff-based feature, and there is no use of
  // melody_points().
  melodic_pitch_variety: function(prop = "MNN", giveUp = 16){
    const self = this
    let relIdx
    if (prop == "MNN"){
      relIdx = 1
    }
    else {
      relIdx = 2
    }
    const nosTargetsFoundAndCounts = Object.keys(self.pointsByStaff).map(function(sn){
      return self.melodic_pitch_variety_helper(self.pointsByStaff[sn], relIdx, giveUp)
    })
    // console.log("nosTargetsFoundAndCounts:", nosTargetsFoundAndCounts)
    let nosTargetsFound = 0, countsTotal = 0
    nosTargetsFoundAndCounts.forEach(function(ntfc){
      nosTargetsFound += ntfc.nosTargetsFound
      countsTotal += ntfc.countsTotal
    })
    // console.log("nosTargetsFound:", nosTargetsFound)
    // console.log("countsTotal:", countsTotal)
    if (nosTargetsFound == 0){
      return 0
    }
    return countsTotal/nosTargetsFound
  },

  melodic_pitch_variety_helper: function(points, idx, giveUp){
    const counts = points.map(function(p, jdx){
      let target = p[idx]
      let targetFoundIn = 0
      let kdx = jdx + 1
      let count = 1
      while (kdx < points.length && count <= giveUp){
        if (points[kdx][idx] == target){
          targetFoundIn = count
          kdx = points.length - 1
        }
        kdx++
        count++
      }
      return targetFoundIn

    })
    // console.log("counts:", counts)
    let nosTargetsFound = 0, countsTotal = 0
    counts.forEach(function(c){
      if (c > 0){
        nosTargetsFound++
        countsTotal += c
      }
    })
    return {
      "nosTargetsFound": nosTargetsFound,
      "countsTotal": countsTotal
    }
  },

  melody_points: function(mode = "top new MNN"){
    let self = this
    let points = []
    switch (mode){
      case "top new MNN":
      self.segments.forEach(function(seg){
        // Get the points that begin at this segment ontime.
        let newPoints = seg.points.filter(function(p){
          return Math.abs(p[self.ontimeIdx] - seg.ontime) < .00002
        })
        if (newPoints.length > 0){
          const pointWithMaxMnn = newPoints.sort(function(a, b){
            return b[self.mnnIdx] - a[self.mnnIdx]
          })[0]
          points.push(pointWithMaxMnn)
        }
      })
      break

      default:
      console.log("Should not get here in interval_histogram() switch!")
    }
    return points
  },

  minor_key_clarity: function(){
    let minorKeyClarity = 0
    if (this.fifthStepsMode[0].indexOf("minor") >= 0){
      minorKeyClarity = this.fifthStepsMode[1]
    }
    return minorKeyClarity
  },

  most_common_pitch: function(prop = "MNN"){
    let c
    switch(prop){
      case "MNN":
      c = mu.count_rows(this.finalNotes.map(function(n){ return [n.MNN] }))
      break
      case "MPN":
      c = mu.count_rows(this.finalNotes.map(function(n){ return [n.MPN] }))
      break
      default:
      console.log("Should not get here in most_common_pitch() switch!")
    }
    if (c[0].length > 0){ return c[0][0] }
  },

  most_common_melodic_interval: function(){
    return mu.max_argmax(this.intervalHistogram)[1]
  },

  // note_count: use this.finalNotes.length.

  note_density: function(mode = "windowed", sf = 1, windowSize = 4, step = 2){
    switch (mode){
      case "overall":
      const minOn = this.segments[0].ontime
      const maxOff = this.segments[this.segments.length - 1].offtime
      if (maxOff !== minOn){
        return sf*this.finalNotes.length/(maxOff - minOn)
      }
      break
      case "windowed":
      console.log("HAVEN'T WRITTEN THIS.")
      break
      default:
      console.log("Should not get here in note_density() switch!")
    }


  },

  note_density_std: function(windowSize = 4, step = 2){
    // Form windows of points.
    const self = this
    const minOn = 0 // this.segments[0].ontime
    const maxOff = this.segments[this.segments.length - 1].offtime
    // Start at a multiple of windowSize far enough back to capture the first
    // ontime.
    let currOn = windowSize*Math.floor(minOn/windowSize)
    let windowDensities = []
    while (currOn < maxOff){
      const currCount = self.points.filter(function(p){
        return p[self.ontimeIdx] >= currOn && p[self.ontimeIdx] < currOn + step
      }).length
      windowDensities.push(currCount)
      // windowDensities.push(
      //   mu.points_belonging_to_interval(
      //     this.points, currOn, currOn + windowSize
      //   // Compliance with another feature library:
      //   // ).length/windowSize/2
      //   // Would prefer:
      //   ).length//windowSize
      // ),
      currOn += step
    }
    // console.log("windowDensities:", windowDensities)
    if (windowDensities.length >= 2){
      // Compliance with another feature library:
      // return 2*mu.std(windowDensities)
      // Would prefer:
      return mu.std(windowDensities)
    }
    else {
      return 0
    }

  },

  // note_length_histogram: use pitch_class_histogram("duration").

  // note_length_transition_matrix: use pitch_class_transition_matrix("duration").

  // Number of different melodic intervals that each account individually for at
  // least 9% of all melodic intervals.
  number_of_common_melodic_intervals: function(proportion){
    const self = this
    let count = 0
    if (self.melodyPoints.length > 1){
      self.intervalHistogram.forEach(function(bin){
        if (bin/(self.melodyPoints.length - 1) >= proportion){
          count++
        }
      })
      return count
    }
  },

  pitch_class_histogram: function(prop = "MNN"){
    // Yang and Lerch (2020) feature
    let pcs, bins
    switch(prop){
      case "MNN":
      pcs = this.finalNotes.map(function(n){ return n.MNN % 12 })
      bins = new Array(12)
      break
      case "MPN":
      pcs = this.finalNotes.map(function(n){ return n.MPN % 7 })
      bins = new Array(7)
      break
      case "duration":
      const vals = [4, 2, 1, 1/4, 1/8, 3, 3/2, 3/4, 3/8, 4/3, 2/3, 1/3]
      pcs = this.finalNotes.map(function(n){
        return mu.min_argmin(
          vals.map(function(v){
            return Math.abs(v - n.duration)
          })
        )[1]
      })
      break
      default:
      console.log("Should not get here in pitch_class_histogram() switch!")
    }
    // Count pcs.
    for (let i = 0; i < bins.length; i++){
      bins[i] = 0
    }
    console.log("bins before:", bins)
    pcs.forEach(function(pc){
      bins[pc]++
    })
    console.log("bins after:", bins)
    // Normalise and return.
    return bins.map(function(b){ return b/pcs.length })
  },

  pitch_class_kurtosis: function(prop = "MNN"){
    let pcs
    switch(prop){
      case "MNN":
      pcs = this.finalNotes.map(function(n){ return n.MNN % 12 })
      // bins = new Array(12)
      break
      case "MPN":
      pcs = this.finalNotes.map(function(n){ return n.MPN % 7 })
      // bins = new Array(7)
      break
      default:
      console.log("Should not get here in pitch_class_kurtosis() switch!")
    }
    // Try throwing in the histogram instead!
    // Set up bins to count pcs.
    let bins = new Array(12)
    for (let i = 0; i < bins.length; i++){
      bins[i] = 0
    }
    console.log("bins before:", bins)
    pcs.forEach(function(pc){
      bins[pc]++
    })
    console.log("bins after:", bins)
    return mu.excess_kurtosis(pcs)
  },

  pitch_class_median_skewness: function(prop = "MNN"){
    let pcs
    switch(prop){
      case "MNN":
      pcs = this.finalNotes.map(function(n){ return n.MNN % 12 })
      break
      case "MPN":
      pcs = this.finalNotes.map(function(n){ return n.MPN % 7 })
      break
      default:
      console.log("Should not get here in pitch_class_median_skewness() switch!")
    }
    return mu.median_skewness(pcs)
  },

  pitch_class_transition_matrix: function(prop = "MNN"){
    // Yang and Lerch (2020) feature
    let bins, rowTotals
    switch(prop){
      case "MNN":
      pcs = this.finalNotes.map(function(n){ return n.MNN % 12 })
      bins = new Array(12)
      rowTotals = new Array(12)
      break
      case "MPN":
      pcs = this.finalNotes.map(function(n){ return n.MPN % 7 })
      bins = new Array(7)
      rowTotals = new Array(7)
      break
      case "duration":
      const vals = [4, 2, 1, 1/4, 1/8, 3, 3/2, 3/4, 3/8, 4/3, 2/3, 1/3]
      pcs = this.finalNotes.map(function(n){
        return mu.min_argmin(
          vals.map(function(v){
            return Math.abs(v - n.duration)
          })
        )[1]
      })
      break
      default:
      console.log("Should not get here in pitch_class_transition_matrix() switch!")
    }
    // Count pcs transitions.
    for (let i = 0; i < bins.length; i++){
      bins[i] = []
      rowTotals[i] = 0
      for (let j = 0; j < bins.length; j++){
        bins[i][j] = 0
      }
    }
    console.log("bins before:", bins)
    pcs.forEach(function(pc, idx){
      if (idx < pc.length - 1){
        bins[pc][pcs[idx + 1]]++
        rowTotals[pc]++
      }
    })
    console.log("bins after:", bins)
    // Normalise and return.
    return bins.map(function(row, idx){
      return row.map(function(b){
        b/rowTotals[idx].length
      })
    })
  },

  pitch_count: function(prop = "MNN"){
    // Yang and Lerch (2020) feature
    let pcs
    switch(prop){
      case "MNN":
      pcs = this.finalNotes.map(function(n){ return n.MNN % 12 })
      break
      case "MPN":
      pcs = this.finalNotes.map(function(n){ return n.MPN % 7 })
      break
      default:
      console.log("Should not get here in pitch_count() switch!")
    }
    return mu.get_unique(pcs).length
  },

  pitch_range: function(prop = "MNN", staffNo = null){
    let relPropArr
    if (staffNo == null){
      relPropArr = this.finalNotes.map(function(n){ return n[prop] })
    }
    else {
      relPropArr = this.finalNotes.filter(function(n){
        return n.staffNo == staffNo
      })
      .map(function(n){ return n[prop] })
    }
    return mu.max_argmax(relPropArr)[0] - mu.min_argmin(relPropArr)[0]
  },

  pitch_std: function(prop = "MNN", staffNo = null){
    let relPropArr
    if (staffNo == null){
      relPropArr = this.finalNotes.map(function(n){ return n[prop] })
    }
    else {
      relPropArr = this.finalNotes.filter(function(n){
        return n.staffNo == staffNo
      })
      .map(function(n){ return n[prop] })
    }
    return mu.std(relPropArr)
  },

  points_by_staff: function(){
    const self = this
    let pointsByStaff = {}
    self.points.forEach(function(p){
      if (pointsByStaff[p[self.staffIdx]] == undefined){
        pointsByStaff[p[self.staffIdx]] = [p]
      }
      else {
        pointsByStaff[p[self.staffIdx]].push(p)
      }
    })
    return pointsByStaff
  },

  proportion_of_notes_in_interval: function(low = 55, high = 72, property = "MNN"){
    let count = 0
    this.finalNotes.forEach(function(n){
      if (n[property] >= low && n[property] <= high){
        count++
      }
    })
    return count/this.finalNotes.length
  },

  range: function(){
    const maxArgMax = mu.max_argmax(this.finalNotes.map(function(n){
      return n.MNN
    }))
    const minArgMin = mu.min_argmin(this.finalNotes.map(function(n){
      return n.MNN
    }))
    return maxArgMax[0] - minArgMin[0]
  },

  rel_note_density_highest_line: function(prop = "MNN"){
    const self = this
    const staffCount = mu.count_rows(self.finalNotes.map(function(n){
      return [n.staffNo]
    }))
    // Find highest line.
    const meanPitches = staffCount[0].map(function(sn){
      return self.mean_pitch(prop, sn)
    })
    const ma = mu.max_argmax(meanPitches)
    // Average number of notes in each line that has at least one note.
    const avg = mu.mean(staffCount[1].filter(function(c){
      return c >= 1
    }))
    if (avg > 0){
      return staffCount[1][ma[1]]/avg
    }
  },

  rhythmic_value_median_run_lengths_histogram: function(sf = 1){
    const self = this

    // Go over notes in each staff.
    let staffConcatRuns = []
    Object.keys(self.pointsByStaff).forEach(function(sn){
      // Quantize durations.
      const quantDurs = self.pointsByStaff[sn].map(function(p){
        let diffArr = self.targetDurations.map(function(td){
          return Math.abs(sf*p[self.durIdx] - parseFloat(td))
        })
        const ma = mu.min_argmin(
          diffArr
        )
        return self.targetDurations[ma[1]]
      })
      // console.log("quantDurs:", quantDurs)

      // Store run lengths on a per-duration basis.
      let durConcatRuns = []
      let runLengths = {}
      self.targetDurations.forEach(function(k){
        runLengths[k] = []
      })
      let runLength = 1
      let lastValue = null

      // Count the run lengths.
      quantDurs.forEach(function(qd, idx){
        if (idx > 0){
          if (lastValue == null){
            // New run.
            lastValue = qd
          }
          if (qd === quantDurs[idx - 1]){
            // Consecutive notes are of the same quantized duration.
            runLength++
          }
          else {
            // Not close enough. Update runLengths and end the run.
            runLengths[lastValue].push(runLength)
            lastValue = null
            runLength = 1
          }
        }
        if (idx == quantDurs.length - 1 && lastValue !== null){
          // Collect last run length.
          runLengths[lastValue].push(runLength)
        }
      })
      // console.log("runLengths:", runLengths)
      // Now we have all the run lengths for different durations.
      // Concatenate them.
      self.targetDurations.forEach(function(td){
        durConcatRuns = durConcatRuns.concat(runLengths[td])
      })
      // console.log("durConcatRuns:", durConcatRuns)
      // Concatenate them on to the staff-collapsed runs.
      staffConcatRuns = staffConcatRuns.concat(durConcatRuns)
    })
    // Calculate stats.
    // console.log("staffConcatRuns:", staffConcatRuns)
    return mu.median(staffConcatRuns)
  },

  semitone_interval: function(interval){
    if (interval == undefined){
      console.log("interval must be specified.")
      return
    }
    if (Math.floor(interval) !== interval){
      console.log("interval must be an integer.")
      return
    }
    if (interval < 0 || interval > this.maxInterval){
      console.log("interval must be between 0 and " + this.maxInteger + ".")
      return
    }
    return this.intervalHistogram[interval]
  },

  // To accord with music theory, this ought to return the number of minor and
  // major seconds. For compatibility with other MIDI-based packages, optionally
  // it will count the number of semitone and whole-tone intervals instead.
  stepwise_motion: function(str = "MPN"){
    let self = this
    let count = 0
    if (str == "MNN"){
      self.melodyPoints.forEach(function(p, idx){
        if (idx > 0){
          const interval = Math.abs(p[self.mnnIdx] - self.melodyPoints[idx - 1][self.mnnIdx])
          if (interval == 1 || interval == 2){
            count++
          }
        }
      })
    }
    else {
      self.melodyPoints.forEach(function(p, idx){
        if (idx > 0 && Math.abs(p[self.mpnIdx] - self.melodyPoints[idx - 1][self.mpnIdx]) == 1){
          count++
        }
      })
    }
    return count/self.melodyPoints.length
  },

  tonal_ambiguity: function(){
    return 1 - Math.abs(this.fifthStepsMode[1])
  },

  translational_coefficient: function(
    dim = [this.ontimeIdx, this.mnnIdx],
    r = this.finalNotes.length - 1 // Number of superdiagonals to use
  ){
    const n = this.finalNotes.length
    // Get the correct projection of D.
    const D = this.points.map(function(pt){
      return dim.map(function(idx){
        return pt[idx]
      })
    })
    // Calculate difference array.
    const V = {}
    for (let i = 0; i < r; i++){
      for (let j = i + 1; j < n; j++){
        // console.log("j:", j, "j - i - 1:", j - i - 1)
        const hash = D[j].map(function(djk, k){
          // Calculate difference rounded to 5 d.p. and convert to string.
          return (Math.round(100000*(djk - D[j - i - 1][k]))/100000).toString()
        }).toString()
        if (V[hash] === undefined){
          V[hash] = [j - i - 1]
        }
        else {
          V[hash].push(j - i - 1)
        }
      }
    }
    // console.log("V:", V)
    const minVal = r
    const maxVal = r*(2*n - r - 1)/2
    return (Object.keys(V).length - minVal)/(maxVal - minVal)
  },

  unique_ioi: function(removeZeros = true){
    // Make iois a point set for ease of use of unique_rows().
    const D = this.ioi(removeZeros).map(function(val){
      return [val]
    })
    return mu.unique_rows(D, true)[0].map(function(pt){ return pt[0] })
  }

}
