/**
 * @file Welcome to the API for MAIA Features!
 *
 * MAIA Markov is a JavaScript package used by Music Artificial Intelligence
 * Algorithms, Inc. in various applications that we have produced or are
 * developing currently.
 *
 * If you already know about JavaScript app development and music computing,
 * then probably the best starting point is the
 * [NPM package](https://npmjs.com/package/maia-features/).
 *
 * If you have a music computing background but know little about JavaScript,
 * then the tutorials menu is a good place to start. There are also some
 * fancier-looking demos available
 * [here](http://tomcollinsresearch.net/mc/ex/),
 * some of which involve MAIA Markov methods to some degree.
 *
 * If you don't know much about music or music computing, then the
 * [fancier-looking demos](http://tomcollinsresearch.net/mc/ex/) are still the
 * best place to start, to get hooked on exploring web-based, interactive music
 * interfaces.
 *
 * This documentation is in the process of being completed. Some functions have
 * not had their existing documentation converted to JSDoc format yet.
 *
 * @version 0.0.7
 * @author Tom Collins
 * @copyright 2020-2023
 *
 */

// import './util_array'
// import append_ontimes_to_time_signatures_default from './append_ontimes_to_time_signatures'
// import {
//   fifth_steps_mode as fifth_steps_mode_default,
//   aarden_key_profiles as aarden_key_profiles_default,
//   krumhansl_and_kessler_key_profiles as krumhansl_and_kessler_key_profiles_default
// } from './util_key'
import CompObj_default from './CompObj'
import ProdObj_default from './ProdObj'
import Model_default from './Model'
// import PointSet_default from './PointSet'

export const CompObj = CompObj_default
export const ProdObj = ProdObj_default
export const Model = Model_default
// export const PointSet = PointSet_default

export default {
  CompObj,
  ProdObj,
  Model
}
