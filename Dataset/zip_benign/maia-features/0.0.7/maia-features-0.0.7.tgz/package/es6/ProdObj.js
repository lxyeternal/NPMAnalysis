// Imports
// import fs
const fs = require('fs')
const pa = require('path')
const { Midi } = require('@tonejs/midi')
const mu = require('maia-util')
// import PointSet from './PointSet'

// Constructor for ProdObjImport object
export default function ProdObj(_po, _co){
  // Workaround for JS context peculiarities.
  // var self = this;
  if (_po === undefined){
    console.log("Production object undefined. Returning early.")
    return
  }
  this.data = _po
  this.dataCompObj = _co
  this.finalNodes = {}
  this.finalNodes["volume"] = this.data.volume.filter(function(n){
    return n.stampDelete == null
  })
  this.finalNodes["tempo"] = this.dataCompObj.tempi.filter(function(n){
    return n.stampDelete == null
  })
  this.finalNodes["reverb"] = {}
  this.finalNodes["reverb"]["roomSize"] =
  this.data.reverb.roomSize.filter(function(n){
    return n.stampDelete == null
  })
  this.finalNodes["reverb"]["wet"] =
  this.data.reverb.wet.filter(function(n){ return n.stampDelete == null })


  // Possible to return something.
  // return sth;
}
// Methods for ProdObj object
ProdObj.prototype = {
  constructor: ProdObj,

  get_node_vals: function(param){
    let nodeVals
    if (Array.isArray(param)){
      // Unpack the param entries.
      nodeVals = this.finalNodes[param[0]]
      let i = 1
      while (i < param.length){
        nodeVals = nodeVals[param[i]]
        i++
      }
    }
    else {
      nodeVals = this.finalNodes[param]
    }
    return nodeVals.map(function(node){
      if (param === "tempo"){
        return node.bpm
      }
      else {
        return node.val
      }
    })
  },

  max: function(param){ return mu.max_argmax(this.get_node_vals(param))[0] },

  mean: function(param){ return mu.mean(this.get_node_vals(param)) },

  min: function(param){ return mu.min_argmin(this.get_node_vals(param))[0] },

  // Returns a large positive value for a mostly increasing slope; returns a
  // large negative value for a mostly decreasing slope; returns a near-zero
  // value for no slope or an alternating slope.
  slope: function(param){
    let self = this
    const nodeVals = self.get_node_vals(param)
    let slopeCount = 0
    if (nodeVals.length > 1){
      nodeVals.forEach(function(v, i){
        if (i > 0){
          slopeCount += Math.sign(v - nodeVals[i - 1])
        }
      })
    }
    return slopeCount
  },

  // Returns a large positive value for a mostly increasing or mostly decreasing
  // slope; returns a returns a near-zero value for no slope or an alternating
  // slope.
  slope_abs: function(param){
    return Math.abs(this.slope(param))
  },

  // Returns a large positive value if the slope alternates a lot, and a near-
  // zero value otherwise.
  slope_jagged: function(param){
    let self = this
    const nodeVals = self.get_node_vals(param)
    let slopeJaggedCount = 0
    if (nodeVals.length > 1){
      nodeVals.forEach(function(v, i){
        if (i > 1){
          slopeJaggedCount +=
          (Math.sign(v - nodeVals[i - 1]) == -Math.sign(nodeVals[i - 1] - nodeVals[i - 2]))
        }
      })
    }
    return slopeJaggedCount
  },

  std: function(param){
    const nodeVals = this.get_node_vals(param)
    let std = 0
    if (nodeVals.length > 1){
      std = mu.std(nodeVals)
    }
    return std
  },

  usage_binary: function(param){
    return this.get_node_vals(param).length > 1
  },



}
