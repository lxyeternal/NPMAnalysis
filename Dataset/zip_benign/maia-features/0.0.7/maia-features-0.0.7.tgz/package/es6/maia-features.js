import maiaFeatures from "./index"


export default maiaFeatures
