// import commonjs from 'rollup-plugin-commonjs'

export default {
  input: './es6/maia-features.js',
  output: {
    file: './maia-features.js',
    format: 'iife',
    name: 'mf'
  }
  // ,plugins :[ commonjs() ]
}
