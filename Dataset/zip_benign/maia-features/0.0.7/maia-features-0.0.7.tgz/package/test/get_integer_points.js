// Copyright Tom Collins, 20.8.2020
// ..

// Example Composition object. id 740, target tension.
const co = {
  "id": "nothing_much_comp",
  "name": "Nothing much Composition object",
  "remarks": "A mostly empty song for experimentation",
  "copyright": [
    {
      "id": "c41094e1-787a-4d3c-ab2f-92de22ed3c7c",
      "name": "tom_collins",
      "displayName": "Tom Collins"
    }
  ],
  "composers": [
    {
      "id": "c41094e1-787a-4d3c-ab2f-92de22ed3c7c",
      "name": "tom_collins",
      "displayName": "Tom Collins"
    }
  ],
  "lyricists": [
    {
      "id": "c41094e1-787a-4d3c-ab2f-92de22ed3c7c",
      "name": "tom_collins",
      "displayName": "Tom Collins"
    }
  ],
  "metadata": {},
  "layer": [
    {
      "type": "instrument",
      "idInstrument": "acoustic_grand_piano",
      "vexflow": {
        "name": "",
        "abbreviation": "",
        "clef": "treble clef",
        "clefSign": "G",
        "clefLine": 2
      },
      "staffNo": 0
    }
  ],
  "keySignatures": [
    {
      "barNo": 1,
      "keyName": "Db major",
      "fifthSteps": -5,
      "mode": 0,
      "staffNo": 0,
      "ontime": 0
    }
  ],
  "timeSignatures": [
    {
      "barNo": 1,
      "topNo": 4,
      "bottomNo": 4,
      "ontime": 0
    }
  ],
  "tempi": [
    {
      "id": "dfgkdfgdfgk",
      "ontime": 0,
      "barNo": 1,
      "bpm": 108,
      "stampDelete": null
    }
  ],
  "clefChanges": [
    {
      "barNo": 1,
      "ontime": 0,
      "clef": "treble clef",
      "clefSign": "G",
      "clefLine": 2,
      "staffNo": 0
    }
  ],
  "notes": [
    {
      "id": "28b98e78-3833-492c-97be-a8c5bbf4c337",
      "ontime": 0.000001,
      "MNN": 60,
      "duration": 1,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 0
      },
      "barOn": 1,
      "beatOn": 1,
      "offtime": 1,
      "barOff": 1,
      "beatOff": 2,
      "MPN": 60,
      "pitch": "C4",
      "stampCreate": 1583938362043,
      "stampDelete": null
    },
    {
      "id": "eef380b0-dac8-4ac1-a32c-40a2b3dbf966",
      "ontime": 0,
      "MNN": 60,
      "duration": 1,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 1
      },
      "barOn": 1,
      "beatOn": 2,
      "offtime": 2,
      "barOff": 1,
      "beatOff": 3,
      "MPN": 63,
      "pitch": "F#4",
      "stampCreate": 1583938365344,
      "stampDelete": null
    },
    {
      "id": "2c03eaa6-e677-4a79-bdbd-66de01683009",
      "ontime": 2,
      "MNN": 66,
      "duration": 1,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 2
      },
      "barOn": 1,
      "beatOn": 3,
      "offtime": 3,
      "barOff": 1,
      "beatOff": 4,
      "MPN": 63,
      "pitch": "F#4",
      "stampCreate": 1583938366479,
      "stampDelete": null
    },
    {
      "id": "406ca7d8-95d4-43a6-ab71-d7aef8d39347",
      "ontime": 3,
      "MNN": 60,
      "duration": 1,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 3
      },
      "barOn": 1,
      "beatOn": 4,
      "offtime": 4,
      "barOff": 2,
      "beatOff": 1,
      "MPN": 59,
      "pitch": "B#3",
      "stampCreate": 1583938368294,
      "stampDelete": null
    },
    {
      "id": "45c81978-3a33-4ed5-92be-9199ee2c3c1c",
      "ontime": 4,
      "MNN": 61,
      "duration": 1,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 4
      },
      "barOn": 2,
      "beatOn": 1,
      "offtime": 5,
      "barOff": 2,
      "beatOff": 2,
      "MPN": 60,
      "pitch": "C#4",
      "stampCreate": 1583938371677,
      "stampDelete": 1583938382196
    },
    {
      "id": "3c42c9a7-b975-4047-a1c6-8e6ca8d357f2",
      "ontime": 4,
      "MNN": 61,
      "duration": 3,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 4
      },
      "barOn": 2,
      "beatOn": 1,
      "offtime": 7,
      "barOff": 2,
      "beatOff": 4,
      "MPN": 60,
      "pitch": "C#4",
      "stampCreate": 1583938389771,
      "stampDelete": 1583938394202
    },
    {
      "id": "8d392f19-700f-4ee0-956e-d814b68fb7f1",
      "ontime": 4,
      "MNN": 61,
      "duration": 2,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 4
      },
      "barOn": 2,
      "beatOn": 1,
      "offtime": 6,
      "barOff": 2,
      "beatOff": 3,
      "MPN": 60,
      "pitch": "C#4",
      "stampCreate": 1583938400462,
      "stampDelete": null
    },
    {
      "id": "21b1f0a0-3569-42c7-8abf-a3802820410b",
      "ontime": 6,
      "MNN": 60,
      "duration": 1,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 6
      },
      "barOn": 2,
      "beatOn": 3,
      "offtime": 7,
      "barOff": 2,
      "beatOff": 4,
      "MPN": 59,
      "pitch": "B#3",
      "stampCreate": 1583938403022,
      "stampDelete": null
    },
    {
      "id": "5c0b4f37-e832-4d21-b0e1-19ae9e027b99",
      "ontime": 7,
      "MNN": 63,
      "duration": 2,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 7
      },
      "barOn": 2,
      "beatOn": 4,
      "offtime": 9,
      "barOff": 3,
      "beatOff": 2,
      "MPN": 61,
      "pitch": "D#4",
      "stampCreate": 1583938408702,
      "stampDelete": null
    },
    {
      "id": "fbf72eab-a591-4e2c-9066-47bc615d47b1",
      "ontime": 9,
      "MNN": 60,
      "duration": 1,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 9
      },
      "barOn": 3,
      "beatOn": 2,
      "offtime": 10,
      "barOff": 3,
      "beatOff": 3,
      "MPN": 59,
      "pitch": "B#3",
      "stampCreate": 1583938412600,
      "stampDelete": null
    },
    {
      "id": "ead51289-2984-4698-8795-e1636b54801e",
      "ontime": 10,
      "MNN": 61,
      "duration": 2,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 10
      },
      "barOn": 3,
      "beatOn": 3,
      "offtime": 12,
      "barOff": 4,
      "beatOff": 1,
      "MPN": 60,
      "pitch": "C#4",
      "stampCreate": 1583938415007,
      "stampDelete": null
    },
    {
      "id": "cecf2a67-05ef-4d70-bee9-c3c00bc4021a",
      "ontime": 12,
      "MNN": 61,
      "duration": 1,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 12
      },
      "barOn": 4,
      "beatOn": 1,
      "offtime": 13,
      "barOff": 4,
      "beatOff": 2,
      "MPN": 61,
      "pitch": "Db4",
      "stampCreate": 1583938420873,
      "stampDelete": null
    },
    {
      "id": "4a132516-516b-4435-8c16-ee5ea4d011e6",
      "ontime": 13,
      "MNN": 66,
      "duration": 1,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 13
      },
      "barOn": 4,
      "beatOn": 2,
      "offtime": 14,
      "barOff": 4,
      "beatOff": 3,
      "MPN": 64,
      "pitch": "Gb4",
      "stampCreate": 1583938424072,
      "stampDelete": null
    },
    {
      "id": "1408ae8d-1069-490a-b5ce-a311aab5ef26",
      "ontime": 14,
      "MNN": 60,
      "duration": 1,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 14
      },
      "barOn": 4,
      "beatOn": 3,
      "offtime": 15,
      "barOff": 4,
      "beatOff": 4,
      "MPN": 59,
      "pitch": "B#3",
      "stampCreate": 1583938427223,
      "stampDelete": null
    },
    {
      "id": "d32dab17-4adc-4333-85b6-14f633b9d77c",
      "ontime": 15,
      "MNN": 60,
      "duration": 1,
      "velocity": 0.5,
      "staffNo": 0,
      "voiceNo": 0,
      "oblongEntry": {
        "granularity": "1",
        "colNo": 15
      },
      "barOn": 4,
      "beatOn": 4,
      "offtime": 16,
      "barOff": 5,
      "beatOff": 1,
      "MPN": 60,
      "pitch": "C4",
      "stampCreate": 1583938428330,
      "stampDelete": null
    }
  ],
  "rests": [
    {
      "id": "0",
      "barOn": 1,
      "beatOn": 2,
      "ontime": 1,
      "duration": 1.5,
      "barOff": 2,
      "beatOff": 3.5,
      "offtime": 2.5,
      "staffNo": 3,
      "voiceNo": 0
    }
  ],
  "expressions": [
    {
      "id": "3",
      "barOn": 1,
      "beatOn": 1,
      "ontime": 0,
      "type": {
        "dynamics": "mf"
      },
      "xShift": -10,
      "yLine": 0,
      "staffNo": 3
    }
  ],
  "sequencing": [
    {
      "barNo": 8,
      "type": "barline",
      "location": "right",
      "ontime": 28
    }
  ],
  "pageLayout": {
    "pageBreaks": [],
    "systemBreaks": [
      5
    ]
  },
  "miscXML": {
    "anacrusis": 0
  }
}


// Requires.
const fs = require("fs")
const sr = require('seed-random')
// const gn = require("./generate")
// const an = require("./analyze")
const mu = require('maia-util')
const mf = require("./../dist/index")


// Load a Composition object.
const mo = new mf.Model(co)
const intPoints = mo.compObj.get_integer_points()
console.log("intPoints:", intPoints)
