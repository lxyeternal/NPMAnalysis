// Copyright Tom Collins, 3.9.2020
// ..

// Individual user paths.
const mainPaths = {
  "tom": {
    "csvFile": "/Users/tomthecollins/Shizz/York/Projects/MCEC/analyses/20200903/extracted_features.csv",
    "json": "/Users/tomthecollins/Shizz/repos/mcec/public/comp_study/",
    "jsonDirs": [ "sub" ],
    "outputDir": "/Users/tomthecollins/Shizz/York/Projects/MCEC/analyses/?/",
    "outputFileName": "features.csv"
  },
  "liam": {
    "json": __dirname + "/../../public/comp_study/",
    "jsonDirs": [ "sub" ],
    "outputDir": "/Users/liammaloney/Documents/MCEC/Analyses/?/",
    "outputFileName": "features.csv"
    // ...
  }
}
const lookupConversion = {
  "Range": { "modelProp": "pc3", "featProp": "Pitch range" },
  "Mean_Pitch": { "modelProp": "pc1", "featProp": "Mean pitch" },
  "Pitch_Variability": { "modelProp": "pc3", "featProp": "Pitch variability" },
  "Pitch_Class_Skewness": { "modelProp": "pc2", "featProp": "Pitch class skewness" },
  "Pitch_Class_Kurtosis": { "modelProp": "pc1", "featProp": "Pitch class kurtosis" },
  "Melodic_Interval_Histogram_2": { "modelProp": "pc1", "featProp": "Melodic interval 2" },
  "Melodic_Interval_Histogram_10": { "modelProp": "pc3", "featProp": "Melodic interval 10" },
  "Most_Common_Melodic_Interval": { "modelProp": "pc2", "featProp": "Most common melodic interval" },
  "Direction_of_Melodic_Motion": { "modelProp": "pc1", "featProp": "Direction of melodic motion" },
  "Melodic_Pitch_Variety": { "modelProp": "pc1", "featProp": "Melodic pitch variety" },
  "Note_Density_per_Quarter_Note": { "modelProp": "pc2", "featProp": "Note density per quarter note" },
  "Note_Density_per_Quarter_Note_Variability": { "modelProp": "pc2", "featProp": "Note density per quarter note variability" },
  "Median_Rhythmic_Value_Run_Length": { "modelProp": "pc1", "featProp": "Rhythmic value median run lengths" },
  "Complete_Rests_Fraction": { "modelProp": "pc2", "featProp": "Complete rests fraction" }
}

// Requires.
const fs = require("fs")
const sr = require('seed-random')
const { Midi } = require('@tonejs/midi')
// const gn = require("./generate")
// const an = require("./analyze")
const mu = require('maia-util')
const mf = require("./../dist/index")

// Grab user name from command line to set path to data.
let nextU = false
let mainPath
process.argv.forEach(function(arg, ind){
  if (arg === "-u"){
    nextU = true
  }
  else if (nextU){
    mainPath = mainPaths[arg]
    nextU = false
  }
})
// fs.mkdir(outdir)

// Import the feature values for checking against MAIA Features-calculated
// values.
let importedFeatureVals = []
const csvStr = fs.readFileSync(mainPath["csvFile"], "utf8")
// console.log("csvStr:", csvStr)
const lines = csvStr.split("\r\n")
// console.log("lines.slice(0, 5):", lines.slice(0, 5))
const colHeadings = lines[0].split(",").slice(1)
console.log("colHeadings:", colHeadings)
lines
// .slice(0, 5)
.forEach(function(line, idx){
  if (idx > 0){
    let obj = {}
    const idAndVals = line.split(",")
    obj.id = idAndVals[0]
    const vals = idAndVals.slice(1).map(function(str){
      return parseFloat(str)
    })
    colHeadings.forEach(function(h, jdx){
      obj[h] = vals[jdx]
    })
    importedFeatureVals.push(obj)
  }
})
console.log("importedFeatureVals.slice(0, 2):", importedFeatureVals.slice(0, 2))

// Import and analyse the files from the composition experiment.
let mfFeatureVals = []
let jsonDirs = fs.readdirSync(mainPath["json"])
jsonDirs = jsonDirs.filter(function(jsonDir){
  return mainPath["jsonDirs"].indexOf(jsonDir) >= 0
})
console.log("jsonDirs:", jsonDirs)
jsonDirs.forEach(function(jsonDir, jDir){
  console.log("Working on jsonDir:", jsonDir, "jDir:", jDir)
  let comps = []
  let prods = []
  let files = fs.readdirSync(mainPath["json"] + jsonDir)
  files = files.filter(function(file){
    const fsplit = file.split(".")
    return fsplit[1] == "txt" && fsplit[0].indexOf("v2") >= 0
  })
  console.log("files.length:", files.length)

  files
  // .slice(0, 5)
  .forEach(function(file, iFile){
    console.log("file:", file)
    if (iFile % 10 == 0){
      console.log("!!! FILE " + (iFile + 1) + " OF " + files.length + " !!!")
    }
    try {
      const dataStr = fs.readFileSync(mainPath["json"] + jsonDir + "/" + file)
      const data = JSON.parse("[" + dataStr + "]")

      data.forEach(function(d){

        // Construct entry of mfFeatureVals.
        let obj = {}
        obj.id = file.split("v2")[0] + "_" + d.targetExpression
        console.log("obj.id:", obj.id)

        // if (obj.id === "742_fear"){

          // console.log("expr", d.targetExpression)
          const co = d.compObj
          const po = d.prodObj
          let model = new mf.Model(co, po)
          let res = {}
          res.pc1 = model.get_pc_1("MCEC 2020 PCA")
          res.pc2 = model.get_pc_2("MCEC 2020 PCA")
          res.pc3 = model.get_pc_3("MCEC 2020 PCA")

          colHeadings.forEach(function(h){
            const currRes = res[lookupConversion[h]["modelProp"]]
            obj[h] = currRes["varVals"][lookupConversion[h]["featProp"]]
          })
          mfFeatureVals.push(obj)

        // }

      })



    }
    catch (e) {
      console.log(e)
    }
  })
})

// console.log("mfFeatureVals.slice(0, 5):", mfFeatureVals.slice(0, 5))


// For each entry in importedFeatureVals, find the corresponding id in
// mfFeatureVals, and report any feature value differences greater than 0.001.
importedFeatureVals
.slice(0, 10)
.forEach(function(row1, idx){
  // Find corresponding id in mfFeatureVals
  const row2 = mfFeatureVals.find(function(row){
    return row1.id === row.id
  })
  if (row2 === undefined){
    console.log("Could not find the corresponding melody in mfFeatureVals.")
    console.log("id in importedFeatureVals:", row1.id)
  }
  else {

    // if (row1.id === "742_fear"){

      console.log("Working on melody " + row1.id + ". " + (idx + 1) + " of " + importedFeatureVals.length)
      // Report any feature value differences greater than 0.001.
      colHeadings.forEach(function(h){
        if (
          row1[h] === undefined ||
          row2[h] === undefined ||
          Math.abs(row1[h] - row2[h]) > 0.001
        ){
          console.log(
            "Too big of a difference for feature = " + h + ":"
          )
          console.log("row1[h]:", row1[h])
          console.log("row2[h]:", row2[h])

        }

      })

    // }

  }
})


// console.log("featureData:", featureData)
// fs.writeFileSync(
//   mainPath["outputDir"] + mainPath["outputFileName"],
//   featureData
// )



// Go!
