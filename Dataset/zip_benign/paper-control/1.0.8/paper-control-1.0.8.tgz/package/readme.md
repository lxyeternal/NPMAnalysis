# paper 操作控制器

以实现平移、缩放、旋转、重置

可配置缩放 max 和 min

支持 reset

支持多图层操作

examples:

```js
new paperControl(paper, {
	minScale: 0.5,
	maxScale: 2,
});
```

多画布操作

```js
new paperControl(paper, {
	minScale: 0.5,
	maxScale: 2,
	isAsyncTransform: true,
	projects: [], // 可选的，如果传了，那么就以传递的某些project同时移动，如果不传但是开了同时移动，则会选择所有project同时变换
});
```
