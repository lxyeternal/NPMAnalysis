return require(script.Parent._Index["boatbomber_editableimageblur@0.3.1"]["editableimageblur"])
