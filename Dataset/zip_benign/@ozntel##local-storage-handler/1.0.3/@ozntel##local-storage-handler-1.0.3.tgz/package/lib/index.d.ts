export declare class LocalStorageHandler {
    cacheHours: number;
    /**
     * @param cacheHours: Default is 24 Hours, specify if you need less or more
     */
    constructor(params: {
        cacheHours?: number;
    });
    private getTimeStampKey;
    /**
     * Checks the key and returns the value from LocalStorage if data saved in last cachedHours.
     * If no data within last cacheHours, returns null.
     * If data, returns String value from the Storage.
     * @param key the key to check
     * @param checkCacheHours specify if you want to check the cachehours or return the value no matter when set
     * @param cacheHours specify if you want to overwrite the cacheHours of the Local Storage Handler and check with the new value
     * @returns Value from Local Storage as String or null
     */
    getFromLocalStorage: (params: {
        key: string;
        checkCacheHours?: boolean | undefined;
        cacheHours?: number | undefined;
    }) => string | null;
    /**
     * Sets the LocalStorage Value with provided key
     * Sets also a timestamp in LocalStorage for the provided key
     * You need to return the LocalStorage value by utilizing the getFromLocalStorage() function
     * @param key
     * @param value
     */
    setLocalStorage: (params: {
        key: string;
        value: string;
    }) => 'success';
    /**
     * @param key - key to remove from local storage
     */
    removeFromLocalStorage: (params: {
        key: string;
    }) => 'success' | 'not-found';
}
