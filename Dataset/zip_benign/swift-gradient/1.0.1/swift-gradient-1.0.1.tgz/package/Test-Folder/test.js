const helloWorld = require('swift-gradient') 

helloWorld()