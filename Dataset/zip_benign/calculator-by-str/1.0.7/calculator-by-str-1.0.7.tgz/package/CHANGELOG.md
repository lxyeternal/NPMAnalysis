
e854e44 整理  1.0.5
b00f7d8 有异常 返回 NaN
dbc02af 进度条
0a51ff6 适配 round 函数 max min 参数定为2个 增加注释
9ac9237 1.0.2
01a442b 声明修改
56cb7ef 公式 bug 前面是两个符号 会有问题 测试 增加json格式 去掉%取余数  使用 math.mod 自定义的方法 常量只用 Math.PI
f5a65e2 公式 工具更新 支持 函数参数数量 检查 除0检查 测试 脚本优化 生成 公式函数 优化
245860b 加入 Mod 函数
9e54782 生成公式文件
bc7e79e 代码 严格模式
73be743 优化 强制模式
acdde2e 生成公式的库 独立出来
3da9c6a 加个进度条插件
891bb4c 公式 ok
d35cb1e 提交  更新
76e8058 优化 测试 修复 bug
2d9cac9 ok
7b7ad7a 测试代码 +  代码健壮
41fecd0 readme
5237da8 健壮