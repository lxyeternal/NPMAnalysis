export declare class ReCaptchaV3Exception extends Error {
    readonly statusCode: number;
    constructor(message: string, statusCode?: number);
}
