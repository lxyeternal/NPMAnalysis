/**
 * Default score threshold for reCAPTCHA verification.
 */
declare const THRESHOLD: number;
/**
 * Google reCAPTCHA verification API endpoint.
 */
declare const reCAPTCHA_API: string;
export { THRESHOLD, reCAPTCHA_API };
