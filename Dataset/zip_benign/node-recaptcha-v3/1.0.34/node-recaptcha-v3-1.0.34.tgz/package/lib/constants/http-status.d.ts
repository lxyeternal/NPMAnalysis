/**
 * Default status code for v3 middleware.
 */
declare const FORBIDDEN: number;
export { FORBIDDEN };
