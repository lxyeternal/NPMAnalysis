import { ReCaptchaV3Configuration } from './interfaces';
declare class ReCaptchaV3 {
    private secretKey;
    private scoreThreshold;
    private apiEndPoint;
    private statusCode;
    private errorMessage;
    constructor(config: ReCaptchaV3Configuration);
    /**
     * Validate that a string is non-empty.
     */
    private validateNonEmptyString;
    /**
     * Ensure the score is within 0 and 1.
     */
    private validateScoreRange;
    /**
     * Send a validation request to Google's reCAPTCHA API.
     */
    private validateReCaptchaToken;
    /**
     * Helper to handle error responses.
     */
    private respondWithError;
    /**
     * Middleware to validate reCAPTCHA tokens.
     */
    verify(customThreshold?: number, customStatusCode?: number, customMessage?: string): (req: any, res: any, next: any) => Promise<void>;
}
export default ReCaptchaV3;
