const prettifyJson = require("../util");
const {
  getProfile,
  getPackage,
  getUsedDependencies,
  getMostDependedPackages
} = require("../src");
const assert = require("assert");

const mockProfile = {
  user_name: "rocktimsaikia",
  profile_name: "Rocktim Saikia",
  avatar_url:
    "https://s.gravatar.com/avatar/931a0183b833ad57c0de40a8f4af2f9f?size=496&default=retro",
  social_links: [
    "https://github.com/RocktimSaikia",
    "https://twitter.com/RocktimSaikia10"
  ],
  num_packages: "3",
  num_org: "0",
  packages: [
    {
      title: "qod",
      description: "",
      version: "0.0.1",
      link: "https://npmjs.com/package/qod",
      last_update: "9 months ago"
    },
    {
      title: "gitjob",
      description: "A cli tool to search for github jobs near you or anywhere",
      version: "1.0.0",
      link: "https://npmjs.com/package/gitjob",
      last_update: "9 months ago"
    },
    {
      title: "dependency-fetcher",
      description: "Get all the dependencies of a github repository",
      version: "2.0.1",
      link: "https://npmjs.com/package/dependency-fetcher",
      last_update: "a month ago"
    }
  ]
};

const mockPackage = {
  Title: "dependency-fetcher",
  Description:
    "Get all the dependencies and dev-dependencies of a github repository.",
  Version: "2.0.1",
  License: "MIT",
  "Unpacked Size": "8.13 kB",
  "Total Files": "8",
  "Last publish": "a month ago",
  Homepage: "https://github.com/RocktimSaikia/dependency-fetcher#readme",
  Repository: "https://github.com/RocktimSaikia/dependency-fetcher",
  Collaborators: ["rocktimsaikia"]
};

const mockDependencies = {
  dependencies: ["isomorphic-unfetch"],
  dev_dependencies: ["mocha"]
};

describe("Get Profile Info", () => {
  it(`should return the profile info.`, async () => {
    const data = await getProfile("rocktimsaikia");
    assert.deepEqual(data, prettifyJson(mockProfile));
  });
});

describe("Get Package Info", () => {
  it("should return all the package info.", async () => {
    const data = await getPackage("dependency-fetcher");
    assert.deepEqual(data, prettifyJson(mockPackage));
  });
});

describe("Get used dependencies", () => {
  it("should return all the used dependencies of the package", async () => {
    const data = await getUsedDependencies("dependency-fetcher");
    assert.deepEqual(data, prettifyJson(mockDependencies));
  });
});

describe("Get Most Depended packages", () => {
  it("should return top 10 current most depended packages", () => {
    return getMostDependedPackages();
  });
});
