const {
  getProfile,
  getPackage,
  getUsedDependencies,
  getMostDependedPackages
} = require("../src");

// getProfile("rocktimsaikia").then(res => console.log(res));

// getPackage("dependency-fetcher").then(res => console.log(res));

// getUsedDependencies("dependency-fetcher").then(res => console.log(res));

getMostDependedPackages().then(res => console.log(res));
