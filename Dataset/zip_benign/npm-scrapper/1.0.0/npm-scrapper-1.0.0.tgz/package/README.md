# npm-scrapper

![Travis (.org) branch](https://img.shields.io/travis/rocktimsaikia/npm-scrapper/master?style=for-the-badge) ![GitHub](https://img.shields.io/github/license/rocktimsaikia/npm-scrapper?style=for-the-badge) ![David](https://img.shields.io/david/rocktimsaikia/npm-scrapper?style=for-the-badge) ![GitHub package.json version](https://img.shields.io/github/package-json/v/rocktimsaikia/npm-scrapper?style=for-the-badge)

> a simple node script that scraps npm's official website.

<a href="https://www.buymeacoffee.com/7BdaxfI" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: 41px !important;width: 174px !important;box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;-webkit-box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;" ></a>

## Install

```bash

$ npm install npm-scrapper

```

## Usage

```javascript
const {
  getProfile,
  getPackage,
  getUsedDependencies,
  getMostDependedPackages
} = require("npm-scrapper");

// get a user's npm profile
getProfile("rocktimsaikia").then(res => {
  console.log(res);
});

// get details of a specified npm package
getPackage("dependency-fetcher").then(res => {
  console.log(res);
});

// get all the used dependencies of a npm package
getUsedDependencies("dependency-fetcher").then(res => {
  console.log(res);
});

// get the top 10 most used/depended npm packages.
getMostDependedPackages().then(res => {
  console.log(res);
});
```
