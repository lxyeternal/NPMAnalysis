"use strict";

const fetch = require("isomorphic-unfetch");
const profileParser = require("../lib/parser.profile");
const packageParser = require("../lib/parser.package");
const dependencyParser = require("../lib/parser.dependency");
const dependedPackageParser = require("../lib/parser.depended");

/**
 * Get user profile
 */
const getProfile = async name => {
  const data = await fetch(`https://www.npmjs.com/~${name}`);
  const html = await data.text();
  return profileParser(html);
};

/**
 * Get a package info
 */
const getPackage = async title => {
  const data = await fetch(`https://www.npmjs.com/package/${title}`);
  const html = await data.text();
  return packageParser(html);
};

/**
 * Get used dependencies of a package
 */
const getUsedDependencies = async title => {
  const data = await fetch(
    `https://www.npmjs.com/package/${title}?activeTab=dependencies`
  );
  const html = await data.text();
  return dependencyParser(html);
};

/**
 * Get the most depended/downloaded packages
 */
const getMostDependedPackages = async () => {
  const data = await fetch("https://www.npmjs.com/browse/depended");
  const html = await data.text();
  return dependedPackageParser(html);
};

module.exports = {
  getProfile,
  getPackage,
  getUsedDependencies,
  getMostDependedPackages
};
