/**
 * json.stringify made prettify
 */
const prettifyJson = json => {
  return JSON.stringify(json, null, 2);
};

module.exports = prettifyJson;
