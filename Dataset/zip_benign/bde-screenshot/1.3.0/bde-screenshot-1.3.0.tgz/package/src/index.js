import puppeteer from "puppeteer";
import normalizeUrl from "normalize-url";
import makeDir from "make-dir";
import chalk from "chalk";
import { isWooEnabled, addProductsToCart } from "./woocommerce.js";

async function getDesignSet(url) {
  const formData = new FormData();
  formData.append("action", "breakdance_get_design_set");

  const response = await fetch(`${url}/wp-admin/admin-ajax.php`, {
    method: "POST",
    body: formData,
  });

  return response.json();
}

async function getAllDesignSets() {
  const url =
    "https://breakdance.com/wp-content/uploads/breakdance/design_sets/design_library_providers.json";

  const response = await fetch(url);
  return response.json();
}

async function screenshot({ browser, page, post, options, baseDir }) {
  await page.goto(post.url);

  const sel = post.name.includes("Home")
    ? ".bde-header-builder, .bde-section, body"
    : ".bde-section, body";

  const elements = await page.$$(sel);
  const directory = `${baseDir}/${post.name}`;

  await makeDir(directory);

  console.log(
    chalk.green(`Screenshotting ${elements.length} elements in ${post.name}.`)
  );

  for (const el of elements) {
    const className = await el.evaluate((el) => el.className);

    console.log(chalk.gray(`Screenshotting ${className}`));

    await el.screenshot({
      path: `${directory}/${className}.${options.type}`,
      type: options.type,
      quality: options.type === "png" ? undefined : options.quality * 100,
    });
  }
}

export async function run(rawUrl, options) {
  if (!rawUrl) {
    console.error("Please specify a Design Set URL.");
    process.exit(1);
  }

  const url = normalizeUrl(rawUrl);
  const data = await getDesignSet(url);

  console.log(chalk.gray(`Fetching ${url}...`));

  if (!data) {
    console.error("No design set found.");
    process.exit(1);
  }

  console.log(chalk.green(`Loaded ${data.name} design set.`));
  console.log(chalk.gray(`Fetching ${data.posts.length} pages.`));

  const baseDir = `${process.cwd()}/screenshots/${data.name}`;

  // Launch browser
  const browser = await puppeteer.launch({
    headless: "new",
  });
  const page = await browser.newPage();

  await page.setViewport({
    width: options.width,
    height: 720,
    deviceScaleFactor: options.scale,
  });

  // Add a few products to the cart so we are able to better screenshot the e-commerce pages.
  if (isWooEnabled(data)) {
    console.log(
      chalk.yellow(
        `This is Design Set is using WooCommerce, adding a few products to the cart first.`
      )
    );

    await addProductsToCart({ url, browser, page });

    console.log(
      chalk.yellow(`Adding a Shop page to the list of pages to screenshot`)
    );

    data.posts = [
      ...data.posts,
      {
        name: "Shop",
        url: `${url}/shop/`,
      },
    ];
  }

  // Loop through posts and screenshot them
  for (const [index, post] of data.posts.entries()) {
    console.log(" ");
    console.log(
      chalk.green(`${post.name} (${index + 1}/${data.posts.length})`)
    );

    await screenshot({
      // Puppeteer
      browser,
      page,
      // Data
      post,
      options,
      baseDir,
    });
  }

  console.log(" ");
  console.log(chalk.green(`Done! Screenshotted ${data.posts.length} pages.`));
}

export async function runMany(options) {
  console.log(chalk.gray(`This may take a while...`));

  const designSets = await getAllDesignSets();

  console.log(chalk.green(`Loaded ${designSets.length} design sets.`));

  for (const [index, designSet] of designSets.entries()) {
    console.log(
      chalk.yellow(
        `Fetching ${designSet.name} (${index + 1}/${designSets.length})`
      )
    );
    await run(designSet.url, options);
  }
}
