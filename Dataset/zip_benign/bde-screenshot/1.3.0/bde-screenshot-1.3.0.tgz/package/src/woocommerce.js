import chalk from "chalk";

export async function isWooEnabled(data) {
  return data.posts.find((post) => ["Cart", "Checkout"].includes(post.name));
}

export async function addProductsToCart({ url, browser, page }) {
  await page.goto(`${url}/shop`);

  const limit = 3;
  const buttons = (await page.$$(".add_to_cart_button")).slice(0, limit);

  console.log(chalk.gray(`Adding ${buttons.length} products to cart.`));

  for (const button of buttons) {
    await Promise.all([
      button.click(),
      page.waitForResponse((response) => response.status() === 200),
    ]);
  }
}
