#!/usr/bin/env node
import meow from "meow";
import { run, runMany } from "./src/index.js";

const cli = meow(
  `
    Usage
      $ bde-screenshot <url>

    Options
      --width, -w  Page width  [default: 1280]
      --type       Image type: png|jpeg|webp  [default: png]
      --quality    Image quality: 0...1 (Only for JPEG and WebP)  [default: 1]
      --scale      Device scale factor  [default: 2]
      --all        Screenshot all Design Libraries (very slow)  [default: false]

    Examples
      $ bde-screenshot https://breakdancelibrary.com/tiny-clothes --width 800
      $ bde-screenshot https://breakdancelibrary.com/tiny-clothes --type webp --quality 0.5
      $ bde-screenshot --all --type webp --quality 0.5
`,
  {
    importMeta: import.meta,
    flags: {
      width: {
        type: "number",
        shortFlag: "w",
        default: 1280,
      },
      type: {
        type: "string",
        choices: ["png", "jpeg", "webp"],
        default: "png",
      },
      quality: {
        type: "number",
        default: 1,
      },
      scale: {
        type: "number",
        default: 2,
      },
      all: {
        type: "boolean",
        default: false,
      },
    },
  }
);

if (cli.flags.all) {
  await runMany(cli.flags);
} else {
  await run(cli.input[0], cli.flags);
}

process.exit(0);
