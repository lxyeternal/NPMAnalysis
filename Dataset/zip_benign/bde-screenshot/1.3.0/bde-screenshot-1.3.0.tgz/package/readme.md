# bde-screenshot-cli

> Capture screenshots of Breakdance Design Libraries from the command-line

It uses [Puppeteer](https://github.com/GoogleChrome/puppeteer) (Chrome) under the hood.

## Install

```sh
npm install --global bde-screenshot
```

## Usage

```
$ bde-screenshot --help

    Usage
      $ bde-screenshot <url>

    Options
      --width, -w  Page width  [default: 1280]
      --type       Image type: png|jpeg|webp  [default: png]
      --quality    Image quality: 0...1 (Only for JPEG and WebP)  [default: 1]
      --scale      Device scale factor  [default: 2]
      --all        Screenshot all Design Libraries (very slow)  [default: false]

    Examples
      $ bde-screenshot https://breakdancelibrary.com/tiny-clothes --width 800
      $ bde-screenshot https://breakdancelibrary.com/tiny-clothes --type webp --quality 0.5
      $ bde-screenshot --all --type webp --quality 0.5
```
