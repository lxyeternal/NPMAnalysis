var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/schema.zod.ts
var schema_zod_exports = {};
__export(schema_zod_exports, {
  zAttribute: () => zAttribute,
  zCollectionIdOrAddress: () => zCollectionIdOrAddress,
  zCollectionSchema: () => zCollectionSchema,
  zCustomizing: () => zCustomizing,
  zCustomizingFileInfo: () => zCustomizingFileInfo,
  zCustomizingImageOverlaySpecs: () => zCustomizingImageOverlaySpecs,
  zCustomizingMutatorReaction: () => zCustomizingMutatorReaction,
  zCustomizingOverrides: () => zCustomizingOverrides,
  zCustomizingSlot: () => zCustomizingSlot,
  zImageDetails: () => zImageDetails,
  zImageWithDetails: () => zImageWithDetails,
  zImageWithDetailsAndThumbnail: () => zImageWithDetailsAndThumbnail,
  zMedia: () => zMedia,
  zMediaDetails: () => zMediaDetails,
  zMediaType: () => zMediaType,
  zRoyalty: () => zRoyalty,
  zSemverString: () => zSemverString,
  zSemverString2xx: () => zSemverString2xx,
  zTokenSchema: () => zTokenSchema
});
import "zod-openapi/extend";
import { z } from "zod";

// src/constants.ts
var PERMISSION = {
  REWRITEABLE_FOR_BOTH: { mutable: true, collectionAdmin: true, tokenOwner: true },
  REWRITEABLE_FOR_COLLECTION_ADMIN: { mutable: true, collectionAdmin: true, tokenOwner: false },
  REWRITEABLE_FOR_TOKEN_OWNER: { mutable: true, collectionAdmin: false, tokenOwner: true },
  WRITABLE_ONCE_FOR_BOTH: { mutable: false, collectionAdmin: true, tokenOwner: true },
  WRITABLE_ONCE_FOR_COLLECTION_ADMIN: { mutable: false, collectionAdmin: true, tokenOwner: false },
  WRITABLE_ONCE_FOR_TOKEN_OWNER: { mutable: false, collectionAdmin: false, tokenOwner: true }
};
var DEFAULT_PERMISSION = PERMISSION.REWRITEABLE_FOR_COLLECTION_ADMIN;
var SCHEMA_NAME = "unique";
var SCHEMA_VERSION = "2.0.0";

// src/schema.zod.ts
var zCollectionIdOrAddress = z.union([
  z.number().min(1).max(2 ** 32 - 1),
  z.string().regex(/^0x[a-fA-F0-9]{40}$/)
]);
var zSemverString = z.string().regex(/^\d+\.\d+\.\d+$/);
var zMediaType = z.enum([
  "image",
  "animation",
  "video",
  "audio",
  "spatial",
  "pdf",
  "document",
  "other"
]);
var zSemverString2xx = zSemverString.refine(
  (version) => {
    if (typeof version === "string") {
      const [major, minor, patch] = version.split(".").map(Number);
      if (major !== 2)
        return false;
      if (minor < 0)
        return false;
      if (patch < 0)
        return false;
    }
    return true;
  },
  "version must be in semver format: 2.x.x"
);
var zImageDetails = z.object({
  name: z.string().optional(),
  type: zMediaType.optional(),
  bytes: z.number().optional(),
  format: z.string().optional(),
  sha256: z.string().optional(),
  width: z.number().optional(),
  height: z.number().optional(),
  order: z.number().optional()
});
var zImageWithDetails = z.object({
  url: z.string(),
  details: zImageDetails.optional()
});
var zImageWithDetailsAndThumbnail = zImageWithDetails.extend({
  thumbnail: zImageWithDetails.optional()
});
var zMediaDetails = zImageDetails.extend({
  duration: z.number().optional(),
  codecs: z.array(z.string()).optional(),
  loop: z.boolean().optional()
});
var zMedia = z.object({
  type: zMediaType,
  url: z.string(),
  name: z.string().optional(),
  details: zMediaDetails.optional(),
  thumbnail: zImageWithDetails.optional(),
  poster: zImageWithDetails.optional()
});
var zAttribute = z.object({
  trait_type: z.string(),
  value: z.union([z.string(), z.number()]),
  display_type: z.string().optional()
});
var zRoyalty = z.object({
  address: z.string(),
  percent: z.number().min(0).max(100),
  isPrimaryOnly: z.boolean().optional()
});
var zCustomizingImageOverlaySpecs = z.object({
  layer: z.number(),
  order_in_layer: z.number(),
  offset: z.object({ x: z.number(), y: z.number() }).partial(),
  opacity: z.number(),
  rotation: z.number(),
  scale: z.object({
    x: z.number().optional(),
    y: z.number().optional(),
    unit: z.enum(["px", "%"]).default("%").optional()
  }),
  anchor_point: z.object({ x: z.number(), y: z.number() }),
  parent_anchor_point: z.object({ x: z.number(), y: z.number() })
}).partial();
var zCustomizingMutatorReaction = zCustomizingImageOverlaySpecs.extend({
  url: z.string(),
  details: zImageDetails
}).partial();
var zCustomizingFileInfo = z.object({
  type: zMediaType,
  url: z.string(),
  name: z.string().optional(),
  details: zMediaDetails.optional(),
  image_overlay_specs: zCustomizingImageOverlaySpecs.optional(),
  placeholder: zImageWithDetails.optional()
});
var zCustomizingSlot = z.object({
  type: zMediaType,
  collections: zCollectionIdOrAddress.array().optional(),
  name: z.string().optional(),
  image_overlay_specs: zCustomizingImageOverlaySpecs.optional()
});
var zCustomizing = z.object({
  self: zCustomizingFileInfo.extend({ tag: z.string() }),
  slots: z.record(zCustomizingSlot).optional(),
  mutator_reactions: z.record(zCustomizingMutatorReaction).optional(),
  mutators: z.array(z.string()).optional()
});
var zCustomizingOverrides = z.object({
  self: zCustomizingFileInfo.extend({ tag: z.string() }).partial().optional(),
  slots: z.record(zCustomizingSlot.partial()).optional(),
  mutator_reactions: z.record(zCustomizingMutatorReaction.partial()).optional(),
  mutators: z.array(z.string()).optional()
});
var zTokenSchema = z.object({
  // base stuff
  schemaName: z.string().optional().default(SCHEMA_NAME),
  schemaVersion: zSemverString2xx.optional().default(SCHEMA_VERSION),
  originalSchemaVersion: zSemverString.optional(),
  name: z.string().optional(),
  description: z.string().optional(),
  image: z.string().optional(),
  image_details: zImageDetails.optional(),
  attributes: z.array(zAttribute).optional(),
  // Unique-specific stuff
  media: z.record(zMedia).optional(),
  royalties: z.array(zRoyalty).optional(),
  customizing: zCustomizing.optional(),
  customizing_overrides: zCustomizingOverrides.optional(),
  // OpenSea-compatibility stuff
  animation_url: z.string().optional(),
  animation_details: zImageDetails.optional(),
  youtube_url: z.string().optional(),
  created_by: z.string().optional(),
  background_color: z.string().optional(),
  external_url: z.string().optional(),
  locale: z.string().optional()
});
var zPotentialAttributeValues = z.array(z.object({
  trait_type: z.string(),
  display_type: z.string().optional(),
  values: z.array(z.union([z.string(), z.number()])).optional()
}));
var zCollectionSchema = z.object({
  schemaName: z.string().optional().refine((v) => v === SCHEMA_NAME, { message: `schemaName must be "${SCHEMA_NAME}"` }).default(SCHEMA_NAME),
  schemaVersion: zSemverString2xx.optional().default(SCHEMA_VERSION),
  originalSchemaVersion: zSemverString.optional(),
  cover_image: zImageWithDetailsAndThumbnail.optional(),
  default_token_image: zImageWithDetailsAndThumbnail.optional(),
  potential_attributes: zPotentialAttributeValues.optional(),
  customizing: z.object({
    slots: z.record(zCustomizingSlot).optional(),
    customizes: zCollectionIdOrAddress.array().optional()
  }).optional(),
  royalties: z.array(zRoyalty).optional()
});

// src/types.ts
var COLLECTION_SCHEMA_FAMILY = /* @__PURE__ */ ((COLLECTION_SCHEMA_FAMILY2) => {
  COLLECTION_SCHEMA_FAMILY2["V0"] = "V0";
  COLLECTION_SCHEMA_FAMILY2["V1"] = "V1";
  COLLECTION_SCHEMA_FAMILY2["V2"] = "V2";
  COLLECTION_SCHEMA_FAMILY2["OTHER_ERC721"] = "ERC721";
  COLLECTION_SCHEMA_FAMILY2["UNKNOWN"] = "UNKNOWN";
  return COLLECTION_SCHEMA_FAMILY2;
})(COLLECTION_SCHEMA_FAMILY || {});

// src/pure.ts
var SCHEMAS_CONSTANTS = {
  defaultSchemaName: SCHEMA_NAME,
  defaultSchemaVersion: SCHEMA_VERSION,
  defaultPermission: DEFAULT_PERMISSION,
  permissions: PERMISSION
};
export {
  COLLECTION_SCHEMA_FAMILY,
  schema_zod_exports as SCHEMAS,
  SCHEMAS_CONSTANTS,
  zAttribute,
  zCollectionIdOrAddress,
  zCollectionSchema,
  zCustomizing,
  zCustomizingFileInfo,
  zCustomizingImageOverlaySpecs,
  zCustomizingMutatorReaction,
  zCustomizingOverrides,
  zCustomizingSlot,
  zImageDetails,
  zImageWithDetails,
  zImageWithDetailsAndThumbnail,
  zMedia,
  zMediaDetails,
  zMediaType,
  zRoyalty,
  zSemverString,
  zSemverString2xx,
  zTokenSchema
};
//# sourceMappingURL=pure.mjs.map