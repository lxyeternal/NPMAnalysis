var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/types.ts
var COLLECTION_SCHEMA_FAMILY = /* @__PURE__ */ ((COLLECTION_SCHEMA_FAMILY2) => {
  COLLECTION_SCHEMA_FAMILY2["V0"] = "V0";
  COLLECTION_SCHEMA_FAMILY2["V1"] = "V1";
  COLLECTION_SCHEMA_FAMILY2["V2"] = "V2";
  COLLECTION_SCHEMA_FAMILY2["OTHER_ERC721"] = "ERC721";
  COLLECTION_SCHEMA_FAMILY2["UNKNOWN"] = "UNKNOWN";
  return COLLECTION_SCHEMA_FAMILY2;
})(COLLECTION_SCHEMA_FAMILY || {});

// src/utils.ts
import { Utf8 } from "@unique-nft/utils/string";
import { StringUtils } from "@unique-nft/utils";
var safeJSONParseWithPossibleEmptyInput = (str) => {
  if (typeof str !== "string")
    return null;
  try {
    return JSON.parse(str);
  } catch (e) {
    return str;
  }
};
var safelyDecodeUTF8String = (hex) => {
  try {
    return Utf8.hexStringToString(hex);
  } catch (e) {
    return null;
  }
};
var decodeHexAndParseJSONOrReturnNull = (hexString) => {
  try {
    return JSON.parse(StringUtils.Utf8.hexStringToString(hexString));
  } catch {
    return null;
  }
};
var safeJSONParse = (str) => {
  try {
    return JSON.parse(str);
  } catch {
    return str;
  }
};
var buildDictionaryFromPropertiesArray = (properties) => {
  if (!properties)
    return {};
  return properties.reduce((acc, property) => {
    acc[property.key] = {
      valueHex: property.valueHex,
      value: property.value || safelyDecodeUTF8String(property.valueHex)
    };
    return acc;
  }, {});
};
var getTokenURI = (tokenProperties, collectionProperties) => {
  const tokenURI = tokenProperties.URI?.value || (collectionProperties?.baseURI?.value || "") + (tokenProperties.URISuffix?.value || "");
  return tokenURI || null;
};
var zipTwoArraysByKey = (src1, src2) => {
  if (src2.length === 0)
    return src1;
  const result = [...src1];
  for (const property of src2) {
    const index = result.findIndex((p) => p.key === property.key);
    if (index === -1) {
      result.push(property);
    } else {
      result[index] = property;
    }
  }
  return result;
};
var hexifyProperties = (properties) => {
  return properties.map((p) => ({
    key: p.key,
    valueHex: p.valueHex ?? Utf8.stringToHexString(p.value)
  }));
};
var mergeRoyalties = (a, b) => {
  const result = [...a.map((r) => ({ ...r }))];
  for (const royalty of b) {
    const index = result.findIndex((r) => r.address === royalty.address);
    if (index === -1) {
      result.push(royalty);
    } else {
      result[index] = royalty;
    }
  }
  return result;
};

// src/tools/semver.ts
var Semver = class _Semver {
  constructor(semver) {
    this._major = semver[0];
    this._minor = semver[1];
    this._patch = semver[2];
  }
  get major() {
    return this._major;
  }
  get minor() {
    return this._minor;
  }
  get patch() {
    return this._patch;
  }
  toString() {
    return `${this.major}.${this.minor}.${this.patch}`;
  }
  static parseToArray(version) {
    if (typeof version !== "string")
      return null;
    const [main] = version.split("+")[0].split("-").map((i) => i.split("."));
    const major = parseInt(main[0]);
    if (isNaN(major))
      return null;
    const minor = parseInt(main[1]);
    const patch = parseInt(main[2]);
    return [major, isNaN(minor) ? 0 : minor, isNaN(patch) ? 0 : patch];
  }
  static fromString(version) {
    const parsed = _Semver.parseToArray(version);
    if (!parsed)
      throw new Error(`Semver.fromString: wrong version string value: "${version}"`);
    return new _Semver(parsed);
  }
  static isValid(version) {
    return typeof version === "string" && _Semver.parseToArray(version) !== null;
  }
  isGteThan(version) {
    const parsed = _Semver.parseToArray(version);
    if (!parsed)
      return false;
    if (this._major > parsed[0])
      return true;
    if (this._major < parsed[0])
      return false;
    if (this._minor > parsed[1])
      return true;
    if (this._minor < parsed[1])
      return false;
    return this._patch >= parsed[2];
  }
  isLessThan(version) {
    const parsed = _Semver.parseToArray(version);
    if (!parsed)
      return false;
    if (this._major < parsed[0])
      return true;
    if (this._major > parsed[0])
      return false;
    if (this._minor < parsed[1])
      return true;
    if (this._minor > parsed[1])
      return false;
    return this._patch < parsed[2];
  }
  isEqual(version) {
    const parsed = _Semver.parseToArray(version);
    if (!parsed)
      return false;
    return this._major === parsed[0] && this._minor === parsed[1] && this._patch === parsed[2];
  }
};

// src/decoding/tokenDecoding.ts
import { Royalties as Royalties2 } from "@unique-nft/utils/royalties";

// src/tools/old_to_intermediate/intermediate_types.ts
var ValidationError = class extends TypeError {
  constructor(message) {
    super(message);
    this.name = "ValidationError";
  }
};
var URL_TEMPLATE_INFIX = "{infix}";

// src/tools/old_to_intermediate/v0_to_intermediate.ts
import protobufjs from "protobufjs";
import { StringUtils as StringUtils2 } from "@unique-nft/utils";
var isOffchainSchemaAValidUrl = (offchainSchema) => {
  return typeof offchainSchema === "string" && offchainSchema.indexOf("{id}") >= 0;
};
var decodeOldSchemaCollection = (properties, decodingImageLinkOptions) => {
  const { imageUrlTemplate, dummyImageFullUrl } = parseImageLinkOptions(decodingImageLinkOptions);
  const propObj = properties.reduce((acc, { key, value, valueHex }) => {
    acc[key] = value ?? StringUtils2.Utf8.hexStringToString(valueHex);
    return acc;
  }, {});
  const offchainSchema = propObj._old_offchainSchema;
  const constOnchainSchema = propObj._old_constOnChainSchema;
  const schemaVersion = propObj._old_schemaVersion;
  const variableOnchainSchema = propObj._old_variableOnChainSchema;
  const offchainSchemaIsValidUrl = isOffchainSchemaAValidUrl(offchainSchema);
  const schema = {
    schemaName: "unique",
    schemaVersion: "0.0.1",
    schemaFamily: "V0" /* V0 */,
    coverPicture: {
      url: dummyImageFullUrl,
      fullUrl: null
    },
    image: {
      urlTemplate: offchainSchemaIsValidUrl ? offchainSchema.replace("{id}", "{infix}") : imageUrlTemplate
    },
    attributesSchema: {},
    attributesSchemaVersion: "1.0.0"
  };
  let parsedVariableOnchainSchema = null;
  try {
    parsedVariableOnchainSchema = JSON.parse(variableOnchainSchema);
  } catch {
  }
  if (parsedVariableOnchainSchema && typeof parsedVariableOnchainSchema === "object" && typeof parsedVariableOnchainSchema.collectionCover === "string") {
    schema.coverPicture.ipfsCid = parsedVariableOnchainSchema.collectionCover;
    delete schema.coverPicture.url;
    schema.coverPicture.fullUrl = imageUrlTemplate.replace("{infix}", parsedVariableOnchainSchema.collectionCover);
  } else if (offchainSchemaIsValidUrl) {
    const coverUrl = offchainSchema.replace("{id}", "1");
    schema.coverPicture.url = coverUrl;
    schema.coverPicture.fullUrl = coverUrl;
  }
  let root = {};
  let NFTMeta = {};
  root = protobufjs.Root.fromJSON(JSON.parse(constOnchainSchema));
  NFTMeta = root.lookupType("onChainMetaData.NFTMeta");
  const attributesSchema = {};
  let i = 0;
  for (const field of NFTMeta.fieldsArray) {
    if (field.name === "ipfsJson") {
      continue;
    }
    const options = !["string", "number"].includes(field.type) && root.lookupEnum(field.type).options || {};
    const values = !["string", "number"].includes(field.type) && root.lookupEnum(field.type).values || {};
    const rawValueToDecodedValueDict = {};
    for (const [innerKey, realJSONStr] of Object.entries(options || {})) {
      const numberedKey = values[innerKey];
      if (typeof numberedKey !== "number")
        continue;
      const realJSON = safeJSONParseWithPossibleEmptyInput(realJSONStr);
      if (typeof realJSON === "string")
        continue;
      realJSON._ = realJSON._ || realJSON.en || realJSON[Object.keys(realJSON)[0]] || null;
      if (typeof realJSON._ !== "string")
        continue;
      rawValueToDecodedValueDict[numberedKey] = realJSON;
    }
    const attr = {
      type: "string" /* string */,
      name: { _: field.name },
      isArray: field.repeated,
      optional: !field.required
    };
    if (Object.keys(rawValueToDecodedValueDict).length > 0) {
      attr.enumValues = rawValueToDecodedValueDict;
    }
    attributesSchema[i++] = attr;
  }
  schema.attributesSchema = attributesSchema;
  schema.attributesSchemaVersion = "1.0.0";
  schema.oldProperties = {
    _old_schemaVersion: schemaVersion,
    _old_offchainSchema: offchainSchema,
    _old_constOnChainSchema: constOnchainSchema,
    _old_variableOnChainSchema: variableOnchainSchema
  };
  return schema;
};
var decodeOldSchemaToken = (propertiesArray, schema, decodingImageLinkOptions, options) => {
  const constOnchainSchema = schema.oldProperties?._old_constOnChainSchema;
  if (!constOnchainSchema) {
    throw new ValidationError(`collection doesn't contain _old_constOnChainSchema field`);
  }
  const root = protobufjs.Root.fromJSON(JSON.parse(constOnchainSchema));
  const NFTMeta = root.lookupType("onChainMetaData.NFTMeta");
  if (!propertiesArray) {
    throw new ValidationError(`parsing token with old schema: no token properties passed`);
  }
  const props = buildDictionaryFromPropertiesArray(propertiesArray);
  const constDataProp = props._old_constData;
  if (!constDataProp) {
    throw new ValidationError("no _old_constData property found");
  }
  const u8aToken = StringUtils2.HexString.toU8a(constDataProp.valueHex);
  let tokenDecoded = {};
  let tokenDecodedHuman = {};
  let tokenDecodedWithRawValues = [];
  try {
    tokenDecoded = NFTMeta.decode(u8aToken);
    tokenDecodedHuman = tokenDecoded.toJSON();
    tokenDecodedWithRawValues = Object.entries(tokenDecoded).map(([name, rawValue], index) => ({
      name,
      rawValue,
      toJSONValue: tokenDecodedHuman[name]
    }));
  } catch (err) {
    throw new ValidationError(`Unable to parse token with old schema, error on decoding Protobuf: ${err.message}`);
  }
  const tokenAttributesResult = {};
  let i = 0;
  for (const entry of tokenDecodedWithRawValues) {
    let { name, rawValue, toJSONValue } = entry;
    if (name === "ipfsJson") {
      continue;
    }
    let value = toJSONValue;
    let isArray = false;
    let isEnum = false;
    const field = tokenDecoded.$type.fields[name];
    if (!["string", "number"].includes(field.type)) {
      const enumOptions = root.lookupEnum(field.type).options;
      isEnum = !!enumOptions;
      if (field.repeated && Array.isArray(rawValue) && toJSONValue) {
        const parsedValues = toJSONValue.map((v) => {
          const parsed = safeJSONParse(enumOptions?.[v] || v);
          if (typeof parsed !== "string") {
            parsed._ = parsed.en;
            return parsed;
          } else {
            return null;
          }
        }).filter((v) => typeof v?._ === "string");
        value = parsedValues;
        isArray = true;
      } else {
        value = safeJSONParse(enumOptions?.[toJSONValue] || rawValue);
        if (typeof value !== "string") {
          value._ = value.en || Object.values(value)[0];
        }
      }
    }
    if (field.type === "string")
      value = { _: value };
    const schemaAttr = Object.entries(schema.attributesSchema).find(([attrId, attrValue]) => {
      return attrValue.name._ === name;
    });
    const index = schemaAttr ? schemaAttr[0] : i;
    i += 1;
    tokenAttributesResult[index] = {
      name: { _: name },
      type: field.type === "number" ? "float" /* float */ : "string" /* string */,
      value,
      isArray,
      isEnum,
      rawValue: isEnum ? rawValue : { _: rawValue }
    };
  }
  const schemaVersion = schema.oldProperties?._old_schemaVersion;
  const offchainSchema = schema.oldProperties?._old_offchainSchema;
  const { imageUrlTemplate, dummyImageFullUrl } = parseImageLinkOptions(decodingImageLinkOptions);
  let image = {
    url: dummyImageFullUrl,
    fullUrl: null
  };
  let ipfsImageIsSet = false;
  if (schemaVersion === "Unique") {
    try {
      const ipfsCid = JSON.parse(tokenDecodedHuman.ipfsJson).ipfs;
      image = {
        ipfsCid,
        fullUrl: imageUrlTemplate.replace("{infix}", ipfsCid)
      };
      ipfsImageIsSet = true;
    } catch {
    }
  }
  if (!ipfsImageIsSet && isOffchainSchemaAValidUrl(offchainSchema)) {
    const tokenId = options?.tokenId?.toString();
    if (!tokenId) {
      throw new ValidationError(`Decoding token in Unique schema v0: tokenId is required to parse this token and it is not provided. Please pass it inside options param.`);
    }
    image = {
      urlInfix: tokenId,
      fullUrl: offchainSchema.replace("{id}", tokenId)
    };
  }
  const decodedToken = {
    image,
    attributes: tokenAttributesResult
  };
  return decodedToken;
};

// src/tools/old_to_intermediate/v1_to_intermediate.ts
import { StringUtils as StringUtils3 } from "@unique-nft/utils";
var decodeTokenUrlOrInfixOrCidWithHashField = (obj, urlTemplateObj) => {
  const result = {
    ...obj,
    fullUrl: null
  };
  if (typeof obj.url === "string") {
    result.fullUrl = obj.url;
    return result;
  }
  const urlTemplate = urlTemplateObj?.urlTemplate;
  if (typeof urlTemplate !== "string" || urlTemplate.indexOf(URL_TEMPLATE_INFIX) < 0) {
    if (typeof obj.ipfsCid === "string") {
      result.fullUrl = `ipfs://${obj.ipfsCid}`;
    }
  } else {
    if (typeof obj.urlInfix === "string") {
      result.fullUrl = urlTemplate.replace(URL_TEMPLATE_INFIX, obj.urlInfix);
    } else if (typeof obj.ipfsCid === "string") {
      result.fullUrl = urlTemplate.replace(URL_TEMPLATE_INFIX, obj.ipfsCid);
    }
  }
  return result;
};
var convertPropertyArrayTo2layerObject = (properties, separator) => {
  const obj = {};
  for (let { key, valueHex } of properties) {
    const keyParts = key.split(separator);
    const length = keyParts.length;
    if (length === 1) {
      obj[key] = decodeHexAndParseJSONOrReturnNull(valueHex);
    } else {
      const [key2, innerKey] = keyParts;
      if (typeof obj[key2] !== "object") {
        obj[key2] = {};
      }
      obj[key2][innerKey] = decodeHexAndParseJSONOrReturnNull(valueHex);
    }
  }
  return obj;
};
var decodeUniqueCollectionFromProperties = (properties) => {
  const unpackedSchema = convertPropertyArrayTo2layerObject(properties, ".");
  if (unpackedSchema.coverPicture) {
    unpackedSchema.coverPicture = decodeTokenUrlOrInfixOrCidWithHashField(unpackedSchema.coverPicture, unpackedSchema.image);
  }
  if (unpackedSchema.coverPicturePreview) {
    unpackedSchema.coverPicturePreview = decodeTokenUrlOrInfixOrCidWithHashField(unpackedSchema.coverPicturePreview, unpackedSchema.image);
  }
  unpackedSchema.schemaFamily = "V1" /* V1 */;
  return unpackedSchema;
};
var fillTokenFieldByKeyPrefix = (token, properties, prefix, tokenField) => {
  const keysMatchingPrefix = [`${prefix}.i`, `${prefix}.u`, `${prefix}.c`, `${prefix}.h`];
  if (properties.some(({ key }) => keysMatchingPrefix.includes(key)))
    token[tokenField] = {};
  const field = token[tokenField];
  const urlInfixProperty = properties.find(({ key }) => key === keysMatchingPrefix[0]);
  if (urlInfixProperty)
    field.urlInfix = StringUtils3.Utf8.hexStringToString(urlInfixProperty.valueHex);
  const urlProperty = properties.find(({ key }) => key === keysMatchingPrefix[1]);
  if (urlProperty)
    field.url = StringUtils3.Utf8.hexStringToString(urlProperty.valueHex);
  const ipfsCidProperty = properties.find(({ key }) => key === keysMatchingPrefix[2]);
  if (ipfsCidProperty)
    field.ipfsCid = StringUtils3.Utf8.hexStringToString(ipfsCidProperty.valueHex);
  const hashProperty = properties.find(({ key }) => key === keysMatchingPrefix[3]);
  if (hashProperty)
    field.hash = StringUtils3.Utf8.hexStringToString(hashProperty.valueHex);
};
var unpackEncodedTokenFromProperties = (properties, schema) => {
  const token = {};
  const nameProperty = properties.find(({ key }) => key === "n");
  if (nameProperty) {
    const parsedName = decodeHexAndParseJSONOrReturnNull(nameProperty.valueHex);
    if (parsedName)
      token.name = parsedName;
  }
  const descriptionProperty = properties.find(({ key }) => key === "d");
  if (descriptionProperty) {
    const parsedDescription = decodeHexAndParseJSONOrReturnNull(descriptionProperty.valueHex);
    if (parsedDescription)
      token.description = parsedDescription;
  }
  fillTokenFieldByKeyPrefix(token, properties, "i", "image");
  fillTokenFieldByKeyPrefix(token, properties, "p", "imagePreview");
  fillTokenFieldByKeyPrefix(token, properties, "v", "video");
  fillTokenFieldByKeyPrefix(token, properties, "au", "audio");
  fillTokenFieldByKeyPrefix(token, properties, "so", "spatialObject");
  const attributeProperties = properties.filter(({ key }) => key.startsWith("a."));
  if (attributeProperties.length) {
    const attrs = {};
    for (const attrProp of attributeProperties) {
      const { key, valueHex } = attrProp;
      const parsed = decodeHexAndParseJSONOrReturnNull(valueHex);
      const attributeKey = parseInt(key.split(".")[1] || "");
      if (!isNaN(attributeKey) && schema.attributesSchema?.hasOwnProperty(attributeKey)) {
        attrs[attributeKey] = parsed;
      }
    }
    token.encodedAttributes = attrs;
  }
  return token;
};
var decodeTokenFromProperties = (propertiesArray, schema, options) => {
  const unpackedToken = unpackEncodedTokenFromProperties(propertiesArray, schema);
  const token = {
    attributes: fullDecodeTokenAttributes(unpackedToken, schema),
    image: decodeTokenUrlOrInfixOrCidWithHashField(unpackedToken.image, schema.image)
  };
  if (unpackedToken.name)
    token.name = unpackedToken.name;
  if (unpackedToken.description)
    token.description = unpackedToken.description;
  if (unpackedToken.imagePreview) {
    token.imagePreview = decodeTokenUrlOrInfixOrCidWithHashField(unpackedToken.imagePreview, schema.imagePreview);
  }
  if (unpackedToken.video) {
    token.video = decodeTokenUrlOrInfixOrCidWithHashField(unpackedToken.video, schema.video);
  }
  if (unpackedToken.audio) {
    token.audio = decodeTokenUrlOrInfixOrCidWithHashField(unpackedToken.audio, schema.audio);
  }
  if (unpackedToken.spatialObject) {
    token.spatialObject = decodeTokenUrlOrInfixOrCidWithHashField(unpackedToken.spatialObject, schema.spatialObject);
  }
  if (unpackedToken.file) {
    token.file = decodeTokenUrlOrInfixOrCidWithHashField(unpackedToken.file, schema.file);
  }
  return token;
};
var fullDecodeTokenAttributes = (token, collectionSchema) => {
  const attributes = {};
  if (!token.encodedAttributes)
    return {};
  const entries = Object.entries(token.encodedAttributes);
  for (const entry of entries) {
    const [key, rawValue] = entry;
    const schema = collectionSchema.attributesSchema?.[key];
    if (!schema)
      continue;
    let value = rawValue;
    if (schema.enumValues) {
      if (schema.isArray && Array.isArray(rawValue)) {
        value = rawValue.map((v) => typeof v === "number" ? schema.enumValues?.[v] : null).filter((v) => !!v);
      } else {
        if (typeof rawValue === "number") {
          value = schema.enumValues[rawValue];
        }
      }
    }
    attributes[key] = {
      name: schema.name,
      value,
      isArray: schema.isArray || false,
      type: schema.type,
      rawValue,
      isEnum: !!schema.enumValues
    };
  }
  return attributes;
};

// src/tools/old_to_intermediate/index.ts
import { Address } from "@unique-nft/utils";
import { Royalties } from "@unique-nft/utils/royalties";
var DEFAULT_IMAGE_URL_TEMPLATE = `https://ipfs.unique.network/ipfs/{infix}`;
var DEFAULT_DUMMY_IMAGE_FULL_URL = `https://ipfs.unique.network/ipfs/QmPCqY7Lmxerm8cLKmB18kT1RxkwnpasPVksA8XLhViVT7`;
var parseImageLinkOptions = (options) => {
  let imageUrlTemplate = DEFAULT_IMAGE_URL_TEMPLATE;
  if (typeof options?.imageUrlTemplate === "string") {
    imageUrlTemplate = options.imageUrlTemplate;
  }
  const dummyImageFullUrl = typeof options?.dummyImageFullUrl === "string" ? options.dummyImageFullUrl : DEFAULT_DUMMY_IMAGE_FULL_URL;
  return {
    imageUrlTemplate,
    dummyImageFullUrl
  };
};
var decodeV0OrV1CollectionSchemaToIntermediate = (properties, schemaFamily, options) => {
  if (!properties || !properties.length) {
    throw new ValidationError(`Unable to parse: collection properties are empty`);
  }
  const result = schemaFamily === "V0" /* V0 */ ? decodeOldSchemaCollection(properties, options) : schemaFamily === "V1" /* V1 */ ? decodeUniqueCollectionFromProperties(properties) : null;
  if (!result)
    throw new ValidationError(`Unknown collection schema: "${schemaFamily}"`);
  const royaltyEncoded = properties.find((p) => p.key === "royalties")?.valueHex;
  const royalties = royaltyEncoded ? Royalties.uniqueV2.decode(royaltyEncoded) : [];
  if (royalties.length)
    result.royalties = royalties;
  return result;
};
var decodeV0OrV1TokenToIntermediate = (propertyArray, schema, options, imageLinkOptions) => {
  if (!schema) {
    throw new ValidationError("unable to parse: collection schema was not provided");
  }
  if (!propertyArray || !propertyArray.length) {
    throw new ValidationError(`unable to parse: token properties are empty`);
  }
  const decodedToken = schema.schemaFamily === "V0" /* V0 */ ? decodeOldSchemaToken(propertyArray, schema, imageLinkOptions, options) : schema.schemaFamily === "V1" /* V1 */ ? decodeTokenFromProperties(propertyArray, schema, options) : null;
  if (!decodedToken) {
    throw new ValidationError(`Unknown token schema`);
  }
  const owner = options?.tokenOwner;
  if (owner && Address.is.nestingAddress(owner)) {
    decodedToken.nestingParentToken = Address.nesting.addressToIds(owner);
  }
  return decodedToken;
};

// src/decoding/tokenDecoding.ts
var detectCollectionSchemaFamily = (tokenPropsDict, collectionPropsDict, schemaV1) => {
  if (schemaV1?.schemaFamily && ["V0" /* V0 */, "V1" /* V1 */].includes(schemaV1?.schemaFamily)) {
    return { schemaFamily: schemaV1.schemaFamily, tokenURI: null };
  }
  const isUniqueSchema = tokenPropsDict.schemaName?.value === "unique" || collectionPropsDict.schemaName?.value === "unique" || collectionPropsDict.schemaName?.value === '"unique"';
  let uniqueVersionString = isUniqueSchema ? tokenPropsDict.schemaVersion?.value || collectionPropsDict.schemaVersion?.value : null;
  if (uniqueVersionString && uniqueVersionString.startsWith('"')) {
    uniqueVersionString = uniqueVersionString.slice(1, -1);
  }
  const uniqueVersion = Semver.fromString(uniqueVersionString || "0.0.0");
  const tokenURI = getTokenURI(tokenPropsDict, collectionPropsDict);
  const isUniqueV2 = uniqueVersion.major === 2;
  const isOtherErc721 = !!tokenURI && !isUniqueV2;
  const schemaFamily = isUniqueV2 ? "V2" /* V2 */ : uniqueVersion.major === 1 ? "V1" /* V1 */ : "_old_schemaVersion" in collectionPropsDict ? "V0" /* V0 */ : isOtherErc721 ? "ERC721" /* OTHER_ERC721 */ : "UNKNOWN" /* UNKNOWN */;
  return {
    schemaFamily,
    tokenURI
  };
};
var decodeTokenToV2 = async (tokenProperties, options) => {
  const tokenPropsDict = buildDictionaryFromPropertiesArray(tokenProperties);
  const collectionPropsDict = buildDictionaryFromPropertiesArray(options?.collectionProperties);
  const {
    schemaFamily,
    tokenURI
  } = detectCollectionSchemaFamily(tokenPropsDict, collectionPropsDict, options?.collectionDecodedSchemaV1);
  if (["V2" /* V2 */, "ERC721" /* OTHER_ERC721 */].includes(schemaFamily)) {
    return await decodeTokenUniqueV2(tokenPropsDict, collectionPropsDict, tokenURI, options);
  }
  if (["V0" /* V0 */, "V1" /* V1 */].includes(schemaFamily)) {
    return await decodeTokenUniqueV0OrV1(
      tokenProperties,
      schemaFamily,
      options
    );
  }
  throw new Error("Unknown token schema version - not Unique v2, v1 or v0 and not ERC721Metadata-compatible");
};
var decodeTokenUniqueV0OrV1 = async (tokenProperties, schemaFamily, options) => {
  const collectionProperties = options?.collectionProperties;
  let collectionSchema = options?.collectionDecodedSchemaV1;
  if (!collectionSchema) {
    if (!Array.isArray(collectionProperties)) {
      throw new Error("Collection properties are required for decoding tokens in Unique schema for versions less than v2 and no pre-decoded schema have been provided");
    }
    const collectionDecodedSchemaV1 = options?.collectionDecodedSchemaV1;
    collectionSchema = collectionDecodedSchemaV1 ? collectionDecodedSchemaV1 : decodeV0OrV1CollectionSchemaToIntermediate(
      collectionProperties,
      schemaFamily
    );
  }
  const tokenIntermediateRepresentation = decodeV0OrV1TokenToIntermediate(
    tokenProperties,
    collectionSchema,
    options
  );
  const attributesArray = Object.values(tokenIntermediateRepresentation.attributes);
  const tokenName = tokenIntermediateRepresentation.name?._ ?? attributesArray.find((attribute) => attribute.name._ === "name")?.value?._ ?? null;
  const tokenDescription = tokenIntermediateRepresentation.description?._ ?? attributesArray.find((attribute) => attribute.name._ === "description")?.value?._ ?? null;
  const attributesInV2Style = [];
  attributesArray.forEach((attribute) => {
    const trait_type = attribute.name._;
    if (attribute.isArray && Array.isArray(attribute.value)) {
      attribute.value.forEach((value) => {
        attributesInV2Style.push({ trait_type, value: value._ });
      });
    } else {
      const value = attribute.value?._;
      if (["string", "number"].includes(typeof value)) {
        attributesInV2Style.push({ trait_type: attribute.name._, value });
      }
    }
  });
  const media = {};
  if (tokenIntermediateRepresentation.video && tokenIntermediateRepresentation.video.fullUrl)
    media.video = { type: "video", url: tokenIntermediateRepresentation.video.fullUrl };
  if (tokenIntermediateRepresentation.audio && tokenIntermediateRepresentation.audio.fullUrl)
    media.audio = { type: "audio", url: tokenIntermediateRepresentation.audio.fullUrl };
  if (tokenIntermediateRepresentation.spatialObject && tokenIntermediateRepresentation.spatialObject.fullUrl)
    media.spatial = { type: "spatial", url: tokenIntermediateRepresentation.spatialObject.fullUrl };
  if (tokenIntermediateRepresentation.file && tokenIntermediateRepresentation.file.fullUrl)
    media.file = { type: "document", url: tokenIntermediateRepresentation.file.fullUrl };
  const tokenRoyaltyEncoded = tokenProperties.find((prop) => prop.key === "royalties")?.valueHex;
  const tokenRoyalties = tokenRoyaltyEncoded ? Royalties2.uniqueV2.decode(tokenRoyaltyEncoded) : [];
  const collectionRoyaltiesEncoded = collectionProperties?.find((prop) => prop.key === "royalties")?.valueHex;
  const collectionRoyalties = collectionSchema.royalties ? collectionSchema.royalties : collectionRoyaltiesEncoded ? Royalties2.uniqueV2.decode(collectionRoyaltiesEncoded) : [];
  const royalties = mergeRoyalties(collectionRoyalties, tokenRoyalties);
  const isUniqueV0 = schemaFamily === "V0" /* V0 */;
  const tokenV2 = {
    schemaName: "unique",
    schemaVersion: "2.0.0",
    originalSchemaVersion: isUniqueV0 ? "0.0.1" : collectionSchema.schemaVersion || "1.0.0"
  };
  if (tokenIntermediateRepresentation.image && tokenIntermediateRepresentation.image.fullUrl) {
    tokenV2.image = tokenIntermediateRepresentation.image.fullUrl;
  }
  if (tokenName)
    tokenV2.name = tokenName;
  if (tokenDescription)
    tokenV2.description = tokenDescription;
  if (attributesInV2Style.length > 0)
    tokenV2.attributes = attributesInV2Style;
  if (Object.keys(media).length > 0)
    tokenV2.media = media;
  if (royalties.length > 0)
    tokenV2.royalties = royalties;
  return tokenV2;
};
var decodeTokenUniqueV2 = async (tokenProperties, collectionProps, tokenURI, options) => {
  let tokenDataString = tokenProperties.tokenData?.value || null;
  if (!tokenDataString && options?.tryRequestForTokenURI && tokenURI) {
    tokenDataString = await fetch(tokenURI).then((r) => r.text());
  }
  const tokenData = safeJSONParseWithPossibleEmptyInput(tokenDataString);
  if (typeof tokenData === "string" || tokenData === null) {
    throw new Error("Unable to parse tokenData JSON");
  }
  const tokenRoyaltiesHexString = tokenProperties.royalties?.valueHex;
  const collectionRoyaltiesHexString = collectionProps?.royalties?.valueHex;
  return tokenData;
};

// src/decoding/collectionDecoding.ts
var decodeCollectionToV2 = async (collectionProperties, options) => {
  const properties = buildDictionaryFromPropertiesArray(collectionProperties);
  const { schemaFamily } = detectCollectionSchemaFamily(properties, properties);
  const isUniqueV2 = schemaFamily === "V2" /* V2 */;
  const isUniqueV0 = schemaFamily === "V0" /* V0 */;
  if (isUniqueV2) {
    const collectionInfo = decodeHexAndParseJSONOrReturnNull(properties.collectionInfo?.valueHex);
    return {
      ...collectionInfo
    };
  }
  const collectionSchema = decodeV0OrV1CollectionSchemaToIntermediate(
    collectionProperties,
    schemaFamily
  );
  const collectionData = {
    schemaName: "unique",
    schemaVersion: !isUniqueV2 ? "2.0.0" : collectionSchema.schemaVersion || "2.0.0",
    originalSchemaVersion: isUniqueV0 ? "0.0.1" : collectionSchema.schemaVersion || "1.0.0"
    // name: options.collectionName as string, //todo: parse UTF16
    // description: options.collectionDescription as string, //todo: parse UTF16
    // symbol: options.collectionSymbol as string, //todo: parse UTF16
    // tokenPrefix: options.collectionSymbol as string, //todo: parse UTF16
  };
  const { royalties } = collectionSchema;
  if (Array.isArray(royalties) && royalties.length)
    collectionData.royalties = royalties;
  if (collectionSchema.attributesSchema) {
    collectionData.potential_attributes = Object.values(collectionSchema.attributesSchema).map((oldAttribute) => {
      const newAttribute = {
        trait_type: oldAttribute.name._,
        display_type: oldAttribute.type
      };
      if (oldAttribute.enumValues) {
        newAttribute.values = Object.values(oldAttribute.enumValues).map((enumValue) => enumValue._);
      }
      return newAttribute;
    });
  }
  if (collectionSchema.coverPicture.fullUrl) {
    collectionData.cover_image = {
      url: collectionSchema.coverPicture.fullUrl
    };
    if (options?.tryRequestForMediaDetails) {
    }
  }
  return collectionData;
};

// src/constants.ts
var PERMISSION = {
  REWRITEABLE_FOR_BOTH: { mutable: true, collectionAdmin: true, tokenOwner: true },
  REWRITEABLE_FOR_COLLECTION_ADMIN: { mutable: true, collectionAdmin: true, tokenOwner: false },
  REWRITEABLE_FOR_TOKEN_OWNER: { mutable: true, collectionAdmin: false, tokenOwner: true },
  WRITABLE_ONCE_FOR_BOTH: { mutable: false, collectionAdmin: true, tokenOwner: true },
  WRITABLE_ONCE_FOR_COLLECTION_ADMIN: { mutable: false, collectionAdmin: true, tokenOwner: false },
  WRITABLE_ONCE_FOR_TOKEN_OWNER: { mutable: false, collectionAdmin: false, tokenOwner: true }
};
var DEFAULT_PERMISSION = PERMISSION.REWRITEABLE_FOR_COLLECTION_ADMIN;
var SCHEMA_NAME = "unique";
var SCHEMA_VERSION = "2.0.0";
var DEFAULT_COLLECTION_FLAGS_VALUE = 64;

// src/schema.zod.ts
var schema_zod_exports = {};
__export(schema_zod_exports, {
  zAttribute: () => zAttribute,
  zCollectionIdOrAddress: () => zCollectionIdOrAddress,
  zCollectionSchema: () => zCollectionSchema,
  zCustomizing: () => zCustomizing,
  zCustomizingFileInfo: () => zCustomizingFileInfo,
  zCustomizingImageOverlaySpecs: () => zCustomizingImageOverlaySpecs,
  zCustomizingMutatorReaction: () => zCustomizingMutatorReaction,
  zCustomizingOverrides: () => zCustomizingOverrides,
  zCustomizingSlot: () => zCustomizingSlot,
  zImageDetails: () => zImageDetails,
  zImageWithDetails: () => zImageWithDetails,
  zImageWithDetailsAndThumbnail: () => zImageWithDetailsAndThumbnail,
  zMedia: () => zMedia,
  zMediaDetails: () => zMediaDetails,
  zMediaType: () => zMediaType,
  zRoyalty: () => zRoyalty,
  zSemverString: () => zSemverString,
  zSemverString2xx: () => zSemverString2xx,
  zTokenSchema: () => zTokenSchema
});
import "zod-openapi/extend";
import { z } from "zod";
var zCollectionIdOrAddress = z.union([
  z.number().min(1).max(2 ** 32 - 1),
  z.string().regex(/^0x[a-fA-F0-9]{40}$/)
]);
var zSemverString = z.string().regex(/^\d+\.\d+\.\d+$/);
var zMediaType = z.enum([
  "image",
  "animation",
  "video",
  "audio",
  "spatial",
  "pdf",
  "document",
  "other"
]);
var zSemverString2xx = zSemverString.refine(
  (version) => {
    if (typeof version === "string") {
      const [major, minor, patch] = version.split(".").map(Number);
      if (major !== 2)
        return false;
      if (minor < 0)
        return false;
      if (patch < 0)
        return false;
    }
    return true;
  },
  "version must be in semver format: 2.x.x"
);
var zImageDetails = z.object({
  name: z.string().optional(),
  type: zMediaType.optional(),
  bytes: z.number().optional(),
  format: z.string().optional(),
  sha256: z.string().optional(),
  width: z.number().optional(),
  height: z.number().optional(),
  order: z.number().optional()
});
var zImageWithDetails = z.object({
  url: z.string(),
  details: zImageDetails.optional()
});
var zImageWithDetailsAndThumbnail = zImageWithDetails.extend({
  thumbnail: zImageWithDetails.optional()
});
var zMediaDetails = zImageDetails.extend({
  duration: z.number().optional(),
  codecs: z.array(z.string()).optional(),
  loop: z.boolean().optional()
});
var zMedia = z.object({
  type: zMediaType,
  url: z.string(),
  name: z.string().optional(),
  details: zMediaDetails.optional(),
  thumbnail: zImageWithDetails.optional(),
  poster: zImageWithDetails.optional()
});
var zAttribute = z.object({
  trait_type: z.string(),
  value: z.union([z.string(), z.number()]),
  display_type: z.string().optional()
});
var zRoyalty = z.object({
  address: z.string(),
  percent: z.number().min(0).max(100),
  isPrimaryOnly: z.boolean().optional()
});
var zCustomizingImageOverlaySpecs = z.object({
  layer: z.number(),
  order_in_layer: z.number(),
  offset: z.object({ x: z.number(), y: z.number() }).partial(),
  opacity: z.number(),
  rotation: z.number(),
  scale: z.object({
    x: z.number().optional(),
    y: z.number().optional(),
    unit: z.enum(["px", "%"]).default("%").optional()
  }),
  anchor_point: z.object({ x: z.number(), y: z.number() }),
  parent_anchor_point: z.object({ x: z.number(), y: z.number() })
}).partial();
var zCustomizingMutatorReaction = zCustomizingImageOverlaySpecs.extend({
  url: z.string(),
  details: zImageDetails
}).partial();
var zCustomizingFileInfo = z.object({
  type: zMediaType,
  url: z.string(),
  name: z.string().optional(),
  details: zMediaDetails.optional(),
  image_overlay_specs: zCustomizingImageOverlaySpecs.optional(),
  placeholder: zImageWithDetails.optional()
});
var zCustomizingSlot = z.object({
  type: zMediaType,
  collections: zCollectionIdOrAddress.array().optional(),
  name: z.string().optional(),
  image_overlay_specs: zCustomizingImageOverlaySpecs.optional()
});
var zCustomizing = z.object({
  self: zCustomizingFileInfo.extend({ tag: z.string() }),
  slots: z.record(zCustomizingSlot).optional(),
  mutator_reactions: z.record(zCustomizingMutatorReaction).optional(),
  mutators: z.array(z.string()).optional()
});
var zCustomizingOverrides = z.object({
  self: zCustomizingFileInfo.extend({ tag: z.string() }).partial().optional(),
  slots: z.record(zCustomizingSlot.partial()).optional(),
  mutator_reactions: z.record(zCustomizingMutatorReaction.partial()).optional(),
  mutators: z.array(z.string()).optional()
});
var zTokenSchema = z.object({
  // base stuff
  schemaName: z.string().optional().default(SCHEMA_NAME),
  schemaVersion: zSemverString2xx.optional().default(SCHEMA_VERSION),
  originalSchemaVersion: zSemverString.optional(),
  name: z.string().optional(),
  description: z.string().optional(),
  image: z.string().optional(),
  image_details: zImageDetails.optional(),
  attributes: z.array(zAttribute).optional(),
  // Unique-specific stuff
  media: z.record(zMedia).optional(),
  royalties: z.array(zRoyalty).optional(),
  customizing: zCustomizing.optional(),
  customizing_overrides: zCustomizingOverrides.optional(),
  // OpenSea-compatibility stuff
  animation_url: z.string().optional(),
  animation_details: zImageDetails.optional(),
  youtube_url: z.string().optional(),
  created_by: z.string().optional(),
  background_color: z.string().optional(),
  external_url: z.string().optional(),
  locale: z.string().optional()
});
var zPotentialAttributeValues = z.array(z.object({
  trait_type: z.string(),
  display_type: z.string().optional(),
  values: z.array(z.union([z.string(), z.number()])).optional()
}));
var zCollectionSchema = z.object({
  schemaName: z.string().optional().refine((v) => v === SCHEMA_NAME, { message: `schemaName must be "${SCHEMA_NAME}"` }).default(SCHEMA_NAME),
  schemaVersion: zSemverString2xx.optional().default(SCHEMA_VERSION),
  originalSchemaVersion: zSemverString.optional(),
  cover_image: zImageWithDetailsAndThumbnail.optional(),
  default_token_image: zImageWithDetailsAndThumbnail.optional(),
  potential_attributes: zPotentialAttributeValues.optional(),
  customizing: z.object({
    slots: z.record(zCustomizingSlot).optional(),
    customizes: zCollectionIdOrAddress.array().optional()
  }).optional(),
  royalties: z.array(zRoyalty).optional()
});

// src/encoding.ts
import { Royalties as Royalties3 } from "@unique-nft/utils/royalties";
var encodeCollection = (data, options) => {
  const collectionInfo = zCollectionSchema.parse(data);
  const permission = options?.defaultPermission ?? { ...DEFAULT_PERMISSION };
  const properties = [
    { key: "schemaName", value: collectionInfo.schemaName || SCHEMA_NAME },
    { key: "schemaVersion", value: collectionInfo.schemaVersion || SCHEMA_VERSION },
    { key: "collectionInfo", value: JSON.stringify(collectionInfo) }
  ];
  if (collectionInfo.royalties) {
    throw new Error("Royalties are not supported in collections in v2, please use the token level royalties");
  }
  const TPPs = [
    "schemaName",
    "schemaVersion",
    "tokenData",
    "URI",
    "URISuffix",
    "overrides",
    "customizing_overrides",
    "royalties"
  ].map((key) => ({ key, permission }));
  return {
    collectionProperties: hexifyProperties(zipTwoArraysByKey(properties, options?.overwriteProperties ?? [])),
    tokenPropertyPermissions: zipTwoArraysByKey(TPPs, options?.overwriteTPPs ?? []),
    flags: DEFAULT_COLLECTION_FLAGS_VALUE
  };
};
var encodeToken = (data, options) => {
  const token = zTokenSchema.parse(data);
  const properties = [
    { key: "schemaName", value: token.schemaName || SCHEMA_NAME },
    { key: "schemaVersion", value: token.schemaVersion || SCHEMA_VERSION },
    { key: "tokenData", value: JSON.stringify(token) }
  ];
  token.royalties && properties.push({ key: "royalties", valueHex: Royalties3.uniqueV2.encode(token.royalties) });
  options?.URI && properties.push({ key: "URI", value: options.URI });
  return {
    tokenProperties: hexifyProperties(zipTwoArraysByKey(properties, options?.overwriteProperties ?? []))
  };
};

// src/index.ts
var SchemaTools = {
  decode: {
    collection: decodeCollectionToV2,
    token: decodeTokenToV2
  },
  encode: {
    collection: encodeCollection,
    token: encodeToken
  },
  tools: {
    schemas: schema_zod_exports,
    decodeOld: {
      collection: decodeV0OrV1CollectionSchemaToIntermediate,
      token: decodeV0OrV1TokenToIntermediate,
      utils: {
        parseImageLinkOptions
      }
    },
    constants: {
      DEFAULT_SCHEMA_NAME: SCHEMA_NAME,
      DEFAULT_SCHEMA_VERSION: SCHEMA_VERSION,
      DEFAULT_PERMISSION,
      PERMISSIONS: PERMISSION
    }
  }
};
export {
  COLLECTION_SCHEMA_FAMILY,
  SchemaTools
};
//# sourceMappingURL=index.mjs.map