import { IV2Royalty as IV2Royalty$1 } from '@unique-nft/utils/royalties';
import { z } from 'zod';

type ProbablyDecodedProperty = {
    key: string;
    valueHex: string;
    value?: string | null;
};
type PropertyForEncoding = {
    key: string;
    valueHex?: undefined;
    value: string;
} | {
    key: string;
    valueHex: string;
    value?: undefined;
};
type PropertyWithHex = {
    key: string;
    valueHex: string;
    value?: string;
};
type ProbablyDecodedPropsDict = Record<string, {
    value: string | null;
    valueHex: string;
}>;
type DecodeCollectionOptions = {
    tryRequestForMediaDetails?: boolean;
    decodingImageLinkOptions?: DecodingImageLinkOptions;
};
type DecodeTokenOptions = {
    tokenId?: number;
    collectionProperties?: ProbablyDecodedProperty[];
    tokenOwner?: string;
    collectionDecodedSchemaV1?: UniqueCollectionSchemaIntermediate;
    tryRequestForTokenURI?: boolean;
    tryRequestForMediaDetails?: boolean;
    decodingImageLinkOptions?: DecodingImageLinkOptions;
};
type CrossAccountId = {
    Substrate: string;
} & {
    Ethereum?: never;
} | {
    Ethereum: string;
} & {
    Substrate?: never;
};
interface TokenPropertyPermission {
    mutable: boolean;
    collectionAdmin: boolean;
    tokenOwner: boolean;
}
interface TokenPropertyPermissionObject {
    key: string;
    permission: TokenPropertyPermission;
}
type CollectionTokenPropertyPermissions = Array<TokenPropertyPermissionObject>;
type EncodeCollectionOptions = {
    defaultPermission?: TokenPropertyPermission;
    overwriteTPPs?: CollectionTokenPropertyPermissions;
    overwriteProperties?: PropertyForEncoding[];
};
type EncodeCollectionResult = {
    collectionProperties: PropertyWithHex[];
    tokenPropertyPermissions: CollectionTokenPropertyPermissions;
    flags: number;
};
type EncodeTokenOptions = {
    URI?: string;
    overwriteProperties?: PropertyForEncoding[];
};
declare enum COLLECTION_SCHEMA_FAMILY {
    V0 = "V0",
    V1 = "V1",
    V2 = "V2",
    OTHER_ERC721 = "ERC721",
    UNKNOWN = "UNKNOWN"
}

type InfixOrUrlOrCidAndHash = {
    url?: string | undefined;
    urlInfix?: string | undefined;
    ipfsCid?: string | undefined;
    hash?: string | undefined;
};
declare enum AttributeType {
    integer = "integer",
    float = "float",
    boolean = "boolean",
    timestamp = "timestamp",
    string = "string",
    url = "url",
    isoDate = "isoDate",
    time = "time",
    colorRgba = "colorRgba"
}
type BoxedNumberWithDefault = {
    _: number;
};
type LocalizedStringWithDefault = {
    _: string;
    [K: string]: string;
};
type LocalizedStringOrBoxedNumberWithDefault = BoxedNumberWithDefault | LocalizedStringWithDefault;
interface AttributeSchema {
    name: LocalizedStringWithDefault;
    optional?: boolean;
    isArray?: boolean;
    type: AttributeType;
    enumValues?: {
        [K: number]: LocalizedStringOrBoxedNumberWithDefault;
    };
}
type EncodedTokenAttributeValue = number | Array<number> | LocalizedStringOrBoxedNumberWithDefault | LocalizedStringOrBoxedNumberWithDefault[];
interface EncodedTokenAttributes {
    [K: number]: EncodedTokenAttributeValue;
}
type CollectionAttributesSchema = {
    [K: number]: AttributeSchema;
};
type UniqueCollectionSchemaIntermediate = {
    schemaName: string;
    schemaVersion: string;
    schemaFamily: COLLECTION_SCHEMA_FAMILY | `${COLLECTION_SCHEMA_FAMILY}`;
    attributesSchemaVersion?: string;
    attributesSchema?: CollectionAttributesSchema;
    image: {
        urlTemplate: string;
    };
    imagePreview?: {
        urlTemplate?: string;
    };
    video?: {
        urlTemplate?: string;
    };
    audio?: {
        urlTemplate?: string;
        format?: string;
        isLossless?: boolean;
    };
    spatialObject?: {
        urlTemplate?: string;
        format?: string;
    };
    file?: {
        urlTemplate?: string;
    };
    coverPicture: DecodedInfixOrUrlOrCidAndHash;
    coverPicturePreview?: DecodedInfixOrUrlOrCidAndHash;
    oldProperties?: {
        _old_schemaVersion?: string;
        _old_offchainSchema?: string;
        _old_constOnChainSchema?: string;
        _old_variableOnChainSchema?: string;
    };
    royalties?: IV2Royalty$1[];
};
type DecodedAttributes = {
    [K: number]: {
        name: LocalizedStringWithDefault;
        value: LocalizedStringOrBoxedNumberWithDefault | Array<LocalizedStringOrBoxedNumberWithDefault>;
        type: AttributeType;
        isArray: boolean;
        rawValue: EncodedTokenAttributeValue | string | Array<string>;
        isEnum: boolean;
    };
};
type DecodedInfixOrUrlOrCidAndHash = InfixOrUrlOrCidAndHash & {
    fullUrl: string | null;
};
interface UniqueTokenIntermediate {
    encodedAttributes?: EncodedTokenAttributes;
    name?: LocalizedStringWithDefault;
    description?: LocalizedStringWithDefault;
    image: DecodedInfixOrUrlOrCidAndHash;
    imagePreview?: DecodedInfixOrUrlOrCidAndHash;
    video?: DecodedInfixOrUrlOrCidAndHash;
    audio?: DecodedInfixOrUrlOrCidAndHash;
    file?: DecodedInfixOrUrlOrCidAndHash;
    spatialObject?: DecodedInfixOrUrlOrCidAndHash;
    nestingParentToken?: {
        collectionId: number;
        tokenId: number;
    };
    attributes: DecodedAttributes;
}
type DecodingImageLinkOptions = {
    imageUrlTemplate?: string;
    dummyImageFullUrl?: string;
};

declare const zCollectionIdOrAddress: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
type ICollectionIdOrAddress = z.infer<typeof zCollectionIdOrAddress>;
declare const zSemverString: z.ZodString;
type ISemverString = z.infer<typeof zSemverString>;
declare const zMediaType: z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>;
type IV2MediaType = z.infer<typeof zMediaType>;
declare const zSemverString2xx: z.ZodEffects<z.ZodString, string, string>;
type IV2SemverString2xx = z.infer<typeof zSemverString2xx>;
declare const zImageDetails: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
    bytes: z.ZodOptional<z.ZodNumber>;
    format: z.ZodOptional<z.ZodString>;
    sha256: z.ZodOptional<z.ZodString>;
    width: z.ZodOptional<z.ZodNumber>;
    height: z.ZodOptional<z.ZodNumber>;
    order: z.ZodOptional<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    name?: string | undefined;
    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
    bytes?: number | undefined;
    format?: string | undefined;
    sha256?: string | undefined;
    width?: number | undefined;
    height?: number | undefined;
    order?: number | undefined;
}, {
    name?: string | undefined;
    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
    bytes?: number | undefined;
    format?: string | undefined;
    sha256?: string | undefined;
    width?: number | undefined;
    height?: number | undefined;
    order?: number | undefined;
}>;
type IV2ImageDetails = z.infer<typeof zImageDetails>;
declare const zImageWithDetails: z.ZodObject<{
    url: z.ZodString;
    details: z.ZodOptional<z.ZodObject<{
        name: z.ZodOptional<z.ZodString>;
        type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
        bytes: z.ZodOptional<z.ZodNumber>;
        format: z.ZodOptional<z.ZodString>;
        sha256: z.ZodOptional<z.ZodString>;
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
        order: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    }, {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    }>>;
}, "strip", z.ZodTypeAny, {
    url: string;
    details?: {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    } | undefined;
}, {
    url: string;
    details?: {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    } | undefined;
}>;
type IV2ImageWithDetails = z.infer<typeof zImageWithDetails>;
declare const zImageWithDetailsAndThumbnail: z.ZodObject<{
    url: z.ZodString;
    details: z.ZodOptional<z.ZodObject<{
        name: z.ZodOptional<z.ZodString>;
        type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
        bytes: z.ZodOptional<z.ZodNumber>;
        format: z.ZodOptional<z.ZodString>;
        sha256: z.ZodOptional<z.ZodString>;
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
        order: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    }, {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    }>>;
    thumbnail: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        details: z.ZodOptional<z.ZodObject<{
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
            bytes: z.ZodOptional<z.ZodNumber>;
            format: z.ZodOptional<z.ZodString>;
            sha256: z.ZodOptional<z.ZodString>;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
            order: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }>>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }, {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }>>;
}, "strip", z.ZodTypeAny, {
    url: string;
    details?: {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    } | undefined;
    thumbnail?: {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    } | undefined;
}, {
    url: string;
    details?: {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    } | undefined;
    thumbnail?: {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    } | undefined;
}>;
type IV2ImageWithDetailsAndThumbnail = z.infer<typeof zImageWithDetailsAndThumbnail>;
declare const zMediaDetails: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
    bytes: z.ZodOptional<z.ZodNumber>;
    format: z.ZodOptional<z.ZodString>;
    sha256: z.ZodOptional<z.ZodString>;
    width: z.ZodOptional<z.ZodNumber>;
    height: z.ZodOptional<z.ZodNumber>;
    order: z.ZodOptional<z.ZodNumber>;
    duration: z.ZodOptional<z.ZodNumber>;
    codecs: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    loop: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    name?: string | undefined;
    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
    bytes?: number | undefined;
    format?: string | undefined;
    sha256?: string | undefined;
    width?: number | undefined;
    height?: number | undefined;
    order?: number | undefined;
    duration?: number | undefined;
    codecs?: string[] | undefined;
    loop?: boolean | undefined;
}, {
    name?: string | undefined;
    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
    bytes?: number | undefined;
    format?: string | undefined;
    sha256?: string | undefined;
    width?: number | undefined;
    height?: number | undefined;
    order?: number | undefined;
    duration?: number | undefined;
    codecs?: string[] | undefined;
    loop?: boolean | undefined;
}>;
type IV2MediaDetails = z.infer<typeof zMediaDetails>;
declare const zMedia: z.ZodObject<{
    type: z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>;
    url: z.ZodString;
    name: z.ZodOptional<z.ZodString>;
    details: z.ZodOptional<z.ZodObject<{
        name: z.ZodOptional<z.ZodString>;
        type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
        bytes: z.ZodOptional<z.ZodNumber>;
        format: z.ZodOptional<z.ZodString>;
        sha256: z.ZodOptional<z.ZodString>;
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
        order: z.ZodOptional<z.ZodNumber>;
        duration: z.ZodOptional<z.ZodNumber>;
        codecs: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
        loop: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
        duration?: number | undefined;
        codecs?: string[] | undefined;
        loop?: boolean | undefined;
    }, {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
        duration?: number | undefined;
        codecs?: string[] | undefined;
        loop?: boolean | undefined;
    }>>;
    thumbnail: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        details: z.ZodOptional<z.ZodObject<{
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
            bytes: z.ZodOptional<z.ZodNumber>;
            format: z.ZodOptional<z.ZodString>;
            sha256: z.ZodOptional<z.ZodString>;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
            order: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }>>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }, {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }>>;
    poster: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        details: z.ZodOptional<z.ZodObject<{
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
            bytes: z.ZodOptional<z.ZodNumber>;
            format: z.ZodOptional<z.ZodString>;
            sha256: z.ZodOptional<z.ZodString>;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
            order: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }>>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }, {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }>>;
}, "strip", z.ZodTypeAny, {
    url: string;
    type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
    name?: string | undefined;
    details?: {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
        duration?: number | undefined;
        codecs?: string[] | undefined;
        loop?: boolean | undefined;
    } | undefined;
    thumbnail?: {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    } | undefined;
    poster?: {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    } | undefined;
}, {
    url: string;
    type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
    name?: string | undefined;
    details?: {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
        duration?: number | undefined;
        codecs?: string[] | undefined;
        loop?: boolean | undefined;
    } | undefined;
    thumbnail?: {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    } | undefined;
    poster?: {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    } | undefined;
}>;
type IV2Media = z.infer<typeof zMedia>;
declare const zAttribute: z.ZodObject<{
    trait_type: z.ZodString;
    value: z.ZodUnion<[z.ZodString, z.ZodNumber]>;
    display_type: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    value: string | number;
    trait_type: string;
    display_type?: string | undefined;
}, {
    value: string | number;
    trait_type: string;
    display_type?: string | undefined;
}>;
type IV2Attribute = z.infer<typeof zAttribute>;
declare const zRoyalty: z.ZodObject<{
    address: z.ZodString;
    percent: z.ZodNumber;
    isPrimaryOnly: z.ZodOptional<z.ZodBoolean>;
}, "strip", z.ZodTypeAny, {
    address: string;
    percent: number;
    isPrimaryOnly?: boolean | undefined;
}, {
    address: string;
    percent: number;
    isPrimaryOnly?: boolean | undefined;
}>;
type IV2Royalty = z.infer<typeof zRoyalty>;
declare const zCustomizingImageOverlaySpecs: z.ZodObject<{
    layer: z.ZodOptional<z.ZodNumber>;
    order_in_layer: z.ZodOptional<z.ZodNumber>;
    offset: z.ZodOptional<z.ZodObject<{
        x: z.ZodOptional<z.ZodNumber>;
        y: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        x?: number | undefined;
        y?: number | undefined;
    }, {
        x?: number | undefined;
        y?: number | undefined;
    }>>;
    opacity: z.ZodOptional<z.ZodNumber>;
    rotation: z.ZodOptional<z.ZodNumber>;
    scale: z.ZodOptional<z.ZodObject<{
        x: z.ZodOptional<z.ZodNumber>;
        y: z.ZodOptional<z.ZodNumber>;
        unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
    }, "strip", z.ZodTypeAny, {
        x?: number | undefined;
        y?: number | undefined;
        unit?: "px" | "%" | undefined;
    }, {
        x?: number | undefined;
        y?: number | undefined;
        unit?: "px" | "%" | undefined;
    }>>;
    anchor_point: z.ZodOptional<z.ZodObject<{
        x: z.ZodNumber;
        y: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        x: number;
        y: number;
    }, {
        x: number;
        y: number;
    }>>;
    parent_anchor_point: z.ZodOptional<z.ZodObject<{
        x: z.ZodNumber;
        y: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        x: number;
        y: number;
    }, {
        x: number;
        y: number;
    }>>;
}, "strip", z.ZodTypeAny, {
    layer?: number | undefined;
    order_in_layer?: number | undefined;
    offset?: {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
    opacity?: number | undefined;
    rotation?: number | undefined;
    scale?: {
        x?: number | undefined;
        y?: number | undefined;
        unit?: "px" | "%" | undefined;
    } | undefined;
    anchor_point?: {
        x: number;
        y: number;
    } | undefined;
    parent_anchor_point?: {
        x: number;
        y: number;
    } | undefined;
}, {
    layer?: number | undefined;
    order_in_layer?: number | undefined;
    offset?: {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
    opacity?: number | undefined;
    rotation?: number | undefined;
    scale?: {
        x?: number | undefined;
        y?: number | undefined;
        unit?: "px" | "%" | undefined;
    } | undefined;
    anchor_point?: {
        x: number;
        y: number;
    } | undefined;
    parent_anchor_point?: {
        x: number;
        y: number;
    } | undefined;
}>;
type IV2CustomizingImageOverlaySpecs = z.infer<typeof zCustomizingImageOverlaySpecs>;
declare const zCustomizingMutatorReaction: z.ZodObject<{
    layer: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    order_in_layer: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    offset: z.ZodOptional<z.ZodOptional<z.ZodObject<{
        x: z.ZodOptional<z.ZodNumber>;
        y: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        x?: number | undefined;
        y?: number | undefined;
    }, {
        x?: number | undefined;
        y?: number | undefined;
    }>>>;
    opacity: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    rotation: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
    scale: z.ZodOptional<z.ZodOptional<z.ZodObject<{
        x: z.ZodOptional<z.ZodNumber>;
        y: z.ZodOptional<z.ZodNumber>;
        unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
    }, "strip", z.ZodTypeAny, {
        x?: number | undefined;
        y?: number | undefined;
        unit?: "px" | "%" | undefined;
    }, {
        x?: number | undefined;
        y?: number | undefined;
        unit?: "px" | "%" | undefined;
    }>>>;
    anchor_point: z.ZodOptional<z.ZodOptional<z.ZodObject<{
        x: z.ZodNumber;
        y: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        x: number;
        y: number;
    }, {
        x: number;
        y: number;
    }>>>;
    parent_anchor_point: z.ZodOptional<z.ZodOptional<z.ZodObject<{
        x: z.ZodNumber;
        y: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        x: number;
        y: number;
    }, {
        x: number;
        y: number;
    }>>>;
    url: z.ZodOptional<z.ZodString>;
    details: z.ZodOptional<z.ZodObject<{
        name: z.ZodOptional<z.ZodString>;
        type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
        bytes: z.ZodOptional<z.ZodNumber>;
        format: z.ZodOptional<z.ZodString>;
        sha256: z.ZodOptional<z.ZodString>;
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
        order: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    }, {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    }>>;
}, "strip", z.ZodTypeAny, {
    layer?: number | undefined;
    order_in_layer?: number | undefined;
    offset?: {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
    opacity?: number | undefined;
    rotation?: number | undefined;
    scale?: {
        x?: number | undefined;
        y?: number | undefined;
        unit?: "px" | "%" | undefined;
    } | undefined;
    anchor_point?: {
        x: number;
        y: number;
    } | undefined;
    parent_anchor_point?: {
        x: number;
        y: number;
    } | undefined;
    url?: string | undefined;
    details?: {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    } | undefined;
}, {
    layer?: number | undefined;
    order_in_layer?: number | undefined;
    offset?: {
        x?: number | undefined;
        y?: number | undefined;
    } | undefined;
    opacity?: number | undefined;
    rotation?: number | undefined;
    scale?: {
        x?: number | undefined;
        y?: number | undefined;
        unit?: "px" | "%" | undefined;
    } | undefined;
    anchor_point?: {
        x: number;
        y: number;
    } | undefined;
    parent_anchor_point?: {
        x: number;
        y: number;
    } | undefined;
    url?: string | undefined;
    details?: {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    } | undefined;
}>;
type IV2CustomizingMutatorReaction = z.infer<typeof zCustomizingMutatorReaction>;
declare const zCustomizingFileInfo: z.ZodObject<{
    type: z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>;
    url: z.ZodString;
    name: z.ZodOptional<z.ZodString>;
    details: z.ZodOptional<z.ZodObject<{
        name: z.ZodOptional<z.ZodString>;
        type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
        bytes: z.ZodOptional<z.ZodNumber>;
        format: z.ZodOptional<z.ZodString>;
        sha256: z.ZodOptional<z.ZodString>;
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
        order: z.ZodOptional<z.ZodNumber>;
        duration: z.ZodOptional<z.ZodNumber>;
        codecs: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
        loop: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
        duration?: number | undefined;
        codecs?: string[] | undefined;
        loop?: boolean | undefined;
    }, {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
        duration?: number | undefined;
        codecs?: string[] | undefined;
        loop?: boolean | undefined;
    }>>;
    image_overlay_specs: z.ZodOptional<z.ZodObject<{
        layer: z.ZodOptional<z.ZodNumber>;
        order_in_layer: z.ZodOptional<z.ZodNumber>;
        offset: z.ZodOptional<z.ZodObject<{
            x: z.ZodOptional<z.ZodNumber>;
            y: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            x?: number | undefined;
            y?: number | undefined;
        }, {
            x?: number | undefined;
            y?: number | undefined;
        }>>;
        opacity: z.ZodOptional<z.ZodNumber>;
        rotation: z.ZodOptional<z.ZodNumber>;
        scale: z.ZodOptional<z.ZodObject<{
            x: z.ZodOptional<z.ZodNumber>;
            y: z.ZodOptional<z.ZodNumber>;
            unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
        }, "strip", z.ZodTypeAny, {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        }, {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        }>>;
        anchor_point: z.ZodOptional<z.ZodObject<{
            x: z.ZodNumber;
            y: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            x: number;
            y: number;
        }, {
            x: number;
            y: number;
        }>>;
        parent_anchor_point: z.ZodOptional<z.ZodObject<{
            x: z.ZodNumber;
            y: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            x: number;
            y: number;
        }, {
            x: number;
            y: number;
        }>>;
    }, "strip", z.ZodTypeAny, {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
    }, {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
    }>>;
    placeholder: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        details: z.ZodOptional<z.ZodObject<{
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
            bytes: z.ZodOptional<z.ZodNumber>;
            format: z.ZodOptional<z.ZodString>;
            sha256: z.ZodOptional<z.ZodString>;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
            order: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }>>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }, {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }>>;
}, "strip", z.ZodTypeAny, {
    url: string;
    type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
    name?: string | undefined;
    details?: {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
        duration?: number | undefined;
        codecs?: string[] | undefined;
        loop?: boolean | undefined;
    } | undefined;
    image_overlay_specs?: {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
    } | undefined;
    placeholder?: {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    } | undefined;
}, {
    url: string;
    type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
    name?: string | undefined;
    details?: {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
        duration?: number | undefined;
        codecs?: string[] | undefined;
        loop?: boolean | undefined;
    } | undefined;
    image_overlay_specs?: {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
    } | undefined;
    placeholder?: {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    } | undefined;
}>;
type IV2CustomizingFileInfo = z.infer<typeof zCustomizingFileInfo>;
declare const zCustomizingSlot: z.ZodObject<{
    type: z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>;
    collections: z.ZodOptional<z.ZodArray<z.ZodUnion<[z.ZodNumber, z.ZodString]>, "many">>;
    name: z.ZodOptional<z.ZodString>;
    image_overlay_specs: z.ZodOptional<z.ZodObject<{
        layer: z.ZodOptional<z.ZodNumber>;
        order_in_layer: z.ZodOptional<z.ZodNumber>;
        offset: z.ZodOptional<z.ZodObject<{
            x: z.ZodOptional<z.ZodNumber>;
            y: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            x?: number | undefined;
            y?: number | undefined;
        }, {
            x?: number | undefined;
            y?: number | undefined;
        }>>;
        opacity: z.ZodOptional<z.ZodNumber>;
        rotation: z.ZodOptional<z.ZodNumber>;
        scale: z.ZodOptional<z.ZodObject<{
            x: z.ZodOptional<z.ZodNumber>;
            y: z.ZodOptional<z.ZodNumber>;
            unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
        }, "strip", z.ZodTypeAny, {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        }, {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        }>>;
        anchor_point: z.ZodOptional<z.ZodObject<{
            x: z.ZodNumber;
            y: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            x: number;
            y: number;
        }, {
            x: number;
            y: number;
        }>>;
        parent_anchor_point: z.ZodOptional<z.ZodObject<{
            x: z.ZodNumber;
            y: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            x: number;
            y: number;
        }, {
            x: number;
            y: number;
        }>>;
    }, "strip", z.ZodTypeAny, {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
    }, {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
    }>>;
}, "strip", z.ZodTypeAny, {
    type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
    collections?: (string | number)[] | undefined;
    name?: string | undefined;
    image_overlay_specs?: {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
    } | undefined;
}, {
    type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
    collections?: (string | number)[] | undefined;
    name?: string | undefined;
    image_overlay_specs?: {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
    } | undefined;
}>;
type IV2CustomizingSlot = z.infer<typeof zCustomizingSlot>;
declare const zCustomizing: z.ZodObject<{
    self: z.ZodObject<{
        url: z.ZodString;
        name: z.ZodOptional<z.ZodString>;
        type: z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>;
        details: z.ZodOptional<z.ZodObject<{
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
            bytes: z.ZodOptional<z.ZodNumber>;
            format: z.ZodOptional<z.ZodString>;
            sha256: z.ZodOptional<z.ZodString>;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
            order: z.ZodOptional<z.ZodNumber>;
            duration: z.ZodOptional<z.ZodNumber>;
            codecs: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            loop: z.ZodOptional<z.ZodBoolean>;
        }, "strip", z.ZodTypeAny, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        }, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        }>>;
        image_overlay_specs: z.ZodOptional<z.ZodObject<{
            layer: z.ZodOptional<z.ZodNumber>;
            order_in_layer: z.ZodOptional<z.ZodNumber>;
            offset: z.ZodOptional<z.ZodObject<{
                x: z.ZodOptional<z.ZodNumber>;
                y: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                x?: number | undefined;
                y?: number | undefined;
            }, {
                x?: number | undefined;
                y?: number | undefined;
            }>>;
            opacity: z.ZodOptional<z.ZodNumber>;
            rotation: z.ZodOptional<z.ZodNumber>;
            scale: z.ZodOptional<z.ZodObject<{
                x: z.ZodOptional<z.ZodNumber>;
                y: z.ZodOptional<z.ZodNumber>;
                unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
            }, "strip", z.ZodTypeAny, {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            }, {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            }>>;
            anchor_point: z.ZodOptional<z.ZodObject<{
                x: z.ZodNumber;
                y: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                x: number;
                y: number;
            }, {
                x: number;
                y: number;
            }>>;
            parent_anchor_point: z.ZodOptional<z.ZodObject<{
                x: z.ZodNumber;
                y: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                x: number;
                y: number;
            }, {
                x: number;
                y: number;
            }>>;
        }, "strip", z.ZodTypeAny, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        }, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        }>>;
        placeholder: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            details: z.ZodOptional<z.ZodObject<{
                name: z.ZodOptional<z.ZodString>;
                type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
                bytes: z.ZodOptional<z.ZodNumber>;
                format: z.ZodOptional<z.ZodString>;
                sha256: z.ZodOptional<z.ZodString>;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
                order: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }>>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }, {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }>>;
        tag: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        url: string;
        type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
        tag: string;
        name?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        } | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
        placeholder?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    }, {
        url: string;
        type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
        tag: string;
        name?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        } | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
        placeholder?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    }>;
    slots: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
        type: z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>;
        collections: z.ZodOptional<z.ZodArray<z.ZodUnion<[z.ZodNumber, z.ZodString]>, "many">>;
        name: z.ZodOptional<z.ZodString>;
        image_overlay_specs: z.ZodOptional<z.ZodObject<{
            layer: z.ZodOptional<z.ZodNumber>;
            order_in_layer: z.ZodOptional<z.ZodNumber>;
            offset: z.ZodOptional<z.ZodObject<{
                x: z.ZodOptional<z.ZodNumber>;
                y: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                x?: number | undefined;
                y?: number | undefined;
            }, {
                x?: number | undefined;
                y?: number | undefined;
            }>>;
            opacity: z.ZodOptional<z.ZodNumber>;
            rotation: z.ZodOptional<z.ZodNumber>;
            scale: z.ZodOptional<z.ZodObject<{
                x: z.ZodOptional<z.ZodNumber>;
                y: z.ZodOptional<z.ZodNumber>;
                unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
            }, "strip", z.ZodTypeAny, {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            }, {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            }>>;
            anchor_point: z.ZodOptional<z.ZodObject<{
                x: z.ZodNumber;
                y: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                x: number;
                y: number;
            }, {
                x: number;
                y: number;
            }>>;
            parent_anchor_point: z.ZodOptional<z.ZodObject<{
                x: z.ZodNumber;
                y: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                x: number;
                y: number;
            }, {
                x: number;
                y: number;
            }>>;
        }, "strip", z.ZodTypeAny, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        }, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        }>>;
    }, "strip", z.ZodTypeAny, {
        type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
        collections?: (string | number)[] | undefined;
        name?: string | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
    }, {
        type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
        collections?: (string | number)[] | undefined;
        name?: string | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
    }>>>;
    mutator_reactions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
        layer: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
        order_in_layer: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
        offset: z.ZodOptional<z.ZodOptional<z.ZodObject<{
            x: z.ZodOptional<z.ZodNumber>;
            y: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            x?: number | undefined;
            y?: number | undefined;
        }, {
            x?: number | undefined;
            y?: number | undefined;
        }>>>;
        opacity: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
        rotation: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
        scale: z.ZodOptional<z.ZodOptional<z.ZodObject<{
            x: z.ZodOptional<z.ZodNumber>;
            y: z.ZodOptional<z.ZodNumber>;
            unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
        }, "strip", z.ZodTypeAny, {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        }, {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        }>>>;
        anchor_point: z.ZodOptional<z.ZodOptional<z.ZodObject<{
            x: z.ZodNumber;
            y: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            x: number;
            y: number;
        }, {
            x: number;
            y: number;
        }>>>;
        parent_anchor_point: z.ZodOptional<z.ZodOptional<z.ZodObject<{
            x: z.ZodNumber;
            y: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            x: number;
            y: number;
        }, {
            x: number;
            y: number;
        }>>>;
        url: z.ZodOptional<z.ZodString>;
        details: z.ZodOptional<z.ZodObject<{
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
            bytes: z.ZodOptional<z.ZodNumber>;
            format: z.ZodOptional<z.ZodString>;
            sha256: z.ZodOptional<z.ZodString>;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
            order: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }>>;
    }, "strip", z.ZodTypeAny, {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        url?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }, {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        url?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }>>>;
    mutators: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
}, "strip", z.ZodTypeAny, {
    self: {
        url: string;
        type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
        tag: string;
        name?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        } | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
        placeholder?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    };
    slots?: Record<string, {
        type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
        collections?: (string | number)[] | undefined;
        name?: string | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
    }> | undefined;
    mutator_reactions?: Record<string, {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        url?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }> | undefined;
    mutators?: string[] | undefined;
}, {
    self: {
        url: string;
        type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
        tag: string;
        name?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        } | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
        placeholder?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    };
    slots?: Record<string, {
        type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
        collections?: (string | number)[] | undefined;
        name?: string | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
    }> | undefined;
    mutator_reactions?: Record<string, {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        url?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }> | undefined;
    mutators?: string[] | undefined;
}>;
type IV2Customizing = z.infer<typeof zCustomizing>;
declare const zCustomizingOverrides: z.ZodObject<{
    self: z.ZodOptional<z.ZodObject<{
        url: z.ZodOptional<z.ZodString>;
        name: z.ZodOptional<z.ZodOptional<z.ZodString>>;
        type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
        details: z.ZodOptional<z.ZodOptional<z.ZodObject<{
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
            bytes: z.ZodOptional<z.ZodNumber>;
            format: z.ZodOptional<z.ZodString>;
            sha256: z.ZodOptional<z.ZodString>;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
            order: z.ZodOptional<z.ZodNumber>;
            duration: z.ZodOptional<z.ZodNumber>;
            codecs: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            loop: z.ZodOptional<z.ZodBoolean>;
        }, "strip", z.ZodTypeAny, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        }, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        }>>>;
        image_overlay_specs: z.ZodOptional<z.ZodOptional<z.ZodObject<{
            layer: z.ZodOptional<z.ZodNumber>;
            order_in_layer: z.ZodOptional<z.ZodNumber>;
            offset: z.ZodOptional<z.ZodObject<{
                x: z.ZodOptional<z.ZodNumber>;
                y: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                x?: number | undefined;
                y?: number | undefined;
            }, {
                x?: number | undefined;
                y?: number | undefined;
            }>>;
            opacity: z.ZodOptional<z.ZodNumber>;
            rotation: z.ZodOptional<z.ZodNumber>;
            scale: z.ZodOptional<z.ZodObject<{
                x: z.ZodOptional<z.ZodNumber>;
                y: z.ZodOptional<z.ZodNumber>;
                unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
            }, "strip", z.ZodTypeAny, {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            }, {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            }>>;
            anchor_point: z.ZodOptional<z.ZodObject<{
                x: z.ZodNumber;
                y: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                x: number;
                y: number;
            }, {
                x: number;
                y: number;
            }>>;
            parent_anchor_point: z.ZodOptional<z.ZodObject<{
                x: z.ZodNumber;
                y: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                x: number;
                y: number;
            }, {
                x: number;
                y: number;
            }>>;
        }, "strip", z.ZodTypeAny, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        }, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        }>>>;
        placeholder: z.ZodOptional<z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            details: z.ZodOptional<z.ZodObject<{
                name: z.ZodOptional<z.ZodString>;
                type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
                bytes: z.ZodOptional<z.ZodNumber>;
                format: z.ZodOptional<z.ZodString>;
                sha256: z.ZodOptional<z.ZodString>;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
                order: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }>>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }, {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }>>>;
        tag: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        url?: string | undefined;
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        } | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
        placeholder?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
        tag?: string | undefined;
    }, {
        url?: string | undefined;
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        } | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
        placeholder?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
        tag?: string | undefined;
    }>>;
    slots: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
        type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
        collections: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodUnion<[z.ZodNumber, z.ZodString]>, "many">>>;
        name: z.ZodOptional<z.ZodOptional<z.ZodString>>;
        image_overlay_specs: z.ZodOptional<z.ZodOptional<z.ZodObject<{
            layer: z.ZodOptional<z.ZodNumber>;
            order_in_layer: z.ZodOptional<z.ZodNumber>;
            offset: z.ZodOptional<z.ZodObject<{
                x: z.ZodOptional<z.ZodNumber>;
                y: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                x?: number | undefined;
                y?: number | undefined;
            }, {
                x?: number | undefined;
                y?: number | undefined;
            }>>;
            opacity: z.ZodOptional<z.ZodNumber>;
            rotation: z.ZodOptional<z.ZodNumber>;
            scale: z.ZodOptional<z.ZodObject<{
                x: z.ZodOptional<z.ZodNumber>;
                y: z.ZodOptional<z.ZodNumber>;
                unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
            }, "strip", z.ZodTypeAny, {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            }, {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            }>>;
            anchor_point: z.ZodOptional<z.ZodObject<{
                x: z.ZodNumber;
                y: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                x: number;
                y: number;
            }, {
                x: number;
                y: number;
            }>>;
            parent_anchor_point: z.ZodOptional<z.ZodObject<{
                x: z.ZodNumber;
                y: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                x: number;
                y: number;
            }, {
                x: number;
                y: number;
            }>>;
        }, "strip", z.ZodTypeAny, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        }, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        }>>>;
    }, "strip", z.ZodTypeAny, {
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        collections?: (string | number)[] | undefined;
        name?: string | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
    }, {
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        collections?: (string | number)[] | undefined;
        name?: string | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
    }>>>;
    mutator_reactions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
        layer: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodNumber>>>;
        order_in_layer: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodNumber>>>;
        offset: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodObject<{
            x: z.ZodOptional<z.ZodNumber>;
            y: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            x?: number | undefined;
            y?: number | undefined;
        }, {
            x?: number | undefined;
            y?: number | undefined;
        }>>>>;
        opacity: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodNumber>>>;
        rotation: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodNumber>>>;
        scale: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodObject<{
            x: z.ZodOptional<z.ZodNumber>;
            y: z.ZodOptional<z.ZodNumber>;
            unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
        }, "strip", z.ZodTypeAny, {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        }, {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        }>>>>;
        anchor_point: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodObject<{
            x: z.ZodNumber;
            y: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            x: number;
            y: number;
        }, {
            x: number;
            y: number;
        }>>>>;
        parent_anchor_point: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodObject<{
            x: z.ZodNumber;
            y: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            x: number;
            y: number;
        }, {
            x: number;
            y: number;
        }>>>>;
        url: z.ZodOptional<z.ZodOptional<z.ZodString>>;
        details: z.ZodOptional<z.ZodOptional<z.ZodObject<{
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
            bytes: z.ZodOptional<z.ZodNumber>;
            format: z.ZodOptional<z.ZodString>;
            sha256: z.ZodOptional<z.ZodString>;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
            order: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }>>>;
    }, "strip", z.ZodTypeAny, {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        url?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }, {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        url?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }>>>;
    mutators: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
}, "strip", z.ZodTypeAny, {
    self?: {
        url?: string | undefined;
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        } | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
        placeholder?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
        tag?: string | undefined;
    } | undefined;
    slots?: Record<string, {
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        collections?: (string | number)[] | undefined;
        name?: string | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
    }> | undefined;
    mutator_reactions?: Record<string, {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        url?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }> | undefined;
    mutators?: string[] | undefined;
}, {
    self?: {
        url?: string | undefined;
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        } | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
        placeholder?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
        tag?: string | undefined;
    } | undefined;
    slots?: Record<string, {
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        collections?: (string | number)[] | undefined;
        name?: string | undefined;
        image_overlay_specs?: {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
        } | undefined;
    }> | undefined;
    mutator_reactions?: Record<string, {
        layer?: number | undefined;
        order_in_layer?: number | undefined;
        offset?: {
            x?: number | undefined;
            y?: number | undefined;
        } | undefined;
        opacity?: number | undefined;
        rotation?: number | undefined;
        scale?: {
            x?: number | undefined;
            y?: number | undefined;
            unit?: "px" | "%" | undefined;
        } | undefined;
        anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        parent_anchor_point?: {
            x: number;
            y: number;
        } | undefined;
        url?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
    }> | undefined;
    mutators?: string[] | undefined;
}>;
type IV2CustomizingOverrides = z.infer<typeof zCustomizingOverrides>;
declare const zTokenSchema: z.ZodObject<{
    schemaName: z.ZodDefault<z.ZodOptional<z.ZodString>>;
    schemaVersion: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>>;
    originalSchemaVersion: z.ZodOptional<z.ZodString>;
    name: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodString>;
    image_details: z.ZodOptional<z.ZodObject<{
        name: z.ZodOptional<z.ZodString>;
        type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
        bytes: z.ZodOptional<z.ZodNumber>;
        format: z.ZodOptional<z.ZodString>;
        sha256: z.ZodOptional<z.ZodString>;
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
        order: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    }, {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    }>>;
    attributes: z.ZodOptional<z.ZodArray<z.ZodObject<{
        trait_type: z.ZodString;
        value: z.ZodUnion<[z.ZodString, z.ZodNumber]>;
        display_type: z.ZodOptional<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        value: string | number;
        trait_type: string;
        display_type?: string | undefined;
    }, {
        value: string | number;
        trait_type: string;
        display_type?: string | undefined;
    }>, "many">>;
    media: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
        type: z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>;
        url: z.ZodString;
        name: z.ZodOptional<z.ZodString>;
        details: z.ZodOptional<z.ZodObject<{
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
            bytes: z.ZodOptional<z.ZodNumber>;
            format: z.ZodOptional<z.ZodString>;
            sha256: z.ZodOptional<z.ZodString>;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
            order: z.ZodOptional<z.ZodNumber>;
            duration: z.ZodOptional<z.ZodNumber>;
            codecs: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
            loop: z.ZodOptional<z.ZodBoolean>;
        }, "strip", z.ZodTypeAny, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        }, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        }>>;
        thumbnail: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            details: z.ZodOptional<z.ZodObject<{
                name: z.ZodOptional<z.ZodString>;
                type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
                bytes: z.ZodOptional<z.ZodNumber>;
                format: z.ZodOptional<z.ZodString>;
                sha256: z.ZodOptional<z.ZodString>;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
                order: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }>>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }, {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }>>;
        poster: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            details: z.ZodOptional<z.ZodObject<{
                name: z.ZodOptional<z.ZodString>;
                type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
                bytes: z.ZodOptional<z.ZodNumber>;
                format: z.ZodOptional<z.ZodString>;
                sha256: z.ZodOptional<z.ZodString>;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
                order: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }>>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }, {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }>>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
        name?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        } | undefined;
        thumbnail?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
        poster?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    }, {
        url: string;
        type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
        name?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        } | undefined;
        thumbnail?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
        poster?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    }>>>;
    royalties: z.ZodOptional<z.ZodArray<z.ZodObject<{
        address: z.ZodString;
        percent: z.ZodNumber;
        isPrimaryOnly: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        address: string;
        percent: number;
        isPrimaryOnly?: boolean | undefined;
    }, {
        address: string;
        percent: number;
        isPrimaryOnly?: boolean | undefined;
    }>, "many">>;
    customizing: z.ZodOptional<z.ZodObject<{
        self: z.ZodObject<{
            url: z.ZodString;
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>;
            details: z.ZodOptional<z.ZodObject<{
                name: z.ZodOptional<z.ZodString>;
                type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
                bytes: z.ZodOptional<z.ZodNumber>;
                format: z.ZodOptional<z.ZodString>;
                sha256: z.ZodOptional<z.ZodString>;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
                order: z.ZodOptional<z.ZodNumber>;
                duration: z.ZodOptional<z.ZodNumber>;
                codecs: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
                loop: z.ZodOptional<z.ZodBoolean>;
            }, "strip", z.ZodTypeAny, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            }, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            }>>;
            image_overlay_specs: z.ZodOptional<z.ZodObject<{
                layer: z.ZodOptional<z.ZodNumber>;
                order_in_layer: z.ZodOptional<z.ZodNumber>;
                offset: z.ZodOptional<z.ZodObject<{
                    x: z.ZodOptional<z.ZodNumber>;
                    y: z.ZodOptional<z.ZodNumber>;
                }, "strip", z.ZodTypeAny, {
                    x?: number | undefined;
                    y?: number | undefined;
                }, {
                    x?: number | undefined;
                    y?: number | undefined;
                }>>;
                opacity: z.ZodOptional<z.ZodNumber>;
                rotation: z.ZodOptional<z.ZodNumber>;
                scale: z.ZodOptional<z.ZodObject<{
                    x: z.ZodOptional<z.ZodNumber>;
                    y: z.ZodOptional<z.ZodNumber>;
                    unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
                }, "strip", z.ZodTypeAny, {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                }, {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                }>>;
                anchor_point: z.ZodOptional<z.ZodObject<{
                    x: z.ZodNumber;
                    y: z.ZodNumber;
                }, "strip", z.ZodTypeAny, {
                    x: number;
                    y: number;
                }, {
                    x: number;
                    y: number;
                }>>;
                parent_anchor_point: z.ZodOptional<z.ZodObject<{
                    x: z.ZodNumber;
                    y: z.ZodNumber;
                }, "strip", z.ZodTypeAny, {
                    x: number;
                    y: number;
                }, {
                    x: number;
                    y: number;
                }>>;
            }, "strip", z.ZodTypeAny, {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            }, {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            }>>;
            placeholder: z.ZodOptional<z.ZodObject<{
                url: z.ZodString;
                details: z.ZodOptional<z.ZodObject<{
                    name: z.ZodOptional<z.ZodString>;
                    type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
                    bytes: z.ZodOptional<z.ZodNumber>;
                    format: z.ZodOptional<z.ZodString>;
                    sha256: z.ZodOptional<z.ZodString>;
                    width: z.ZodOptional<z.ZodNumber>;
                    height: z.ZodOptional<z.ZodNumber>;
                    order: z.ZodOptional<z.ZodNumber>;
                }, "strip", z.ZodTypeAny, {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                }, {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                }>>;
            }, "strip", z.ZodTypeAny, {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            }, {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            }>>;
            tag: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            url: string;
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            tag: string;
            name?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            } | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
            placeholder?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            } | undefined;
        }, {
            url: string;
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            tag: string;
            name?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            } | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
            placeholder?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            } | undefined;
        }>;
        slots: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            type: z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>;
            collections: z.ZodOptional<z.ZodArray<z.ZodUnion<[z.ZodNumber, z.ZodString]>, "many">>;
            name: z.ZodOptional<z.ZodString>;
            image_overlay_specs: z.ZodOptional<z.ZodObject<{
                layer: z.ZodOptional<z.ZodNumber>;
                order_in_layer: z.ZodOptional<z.ZodNumber>;
                offset: z.ZodOptional<z.ZodObject<{
                    x: z.ZodOptional<z.ZodNumber>;
                    y: z.ZodOptional<z.ZodNumber>;
                }, "strip", z.ZodTypeAny, {
                    x?: number | undefined;
                    y?: number | undefined;
                }, {
                    x?: number | undefined;
                    y?: number | undefined;
                }>>;
                opacity: z.ZodOptional<z.ZodNumber>;
                rotation: z.ZodOptional<z.ZodNumber>;
                scale: z.ZodOptional<z.ZodObject<{
                    x: z.ZodOptional<z.ZodNumber>;
                    y: z.ZodOptional<z.ZodNumber>;
                    unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
                }, "strip", z.ZodTypeAny, {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                }, {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                }>>;
                anchor_point: z.ZodOptional<z.ZodObject<{
                    x: z.ZodNumber;
                    y: z.ZodNumber;
                }, "strip", z.ZodTypeAny, {
                    x: number;
                    y: number;
                }, {
                    x: number;
                    y: number;
                }>>;
                parent_anchor_point: z.ZodOptional<z.ZodObject<{
                    x: z.ZodNumber;
                    y: z.ZodNumber;
                }, "strip", z.ZodTypeAny, {
                    x: number;
                    y: number;
                }, {
                    x: number;
                    y: number;
                }>>;
            }, "strip", z.ZodTypeAny, {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            }, {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            }>>;
        }, "strip", z.ZodTypeAny, {
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }, {
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }>>>;
        mutator_reactions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            layer: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
            order_in_layer: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
            offset: z.ZodOptional<z.ZodOptional<z.ZodObject<{
                x: z.ZodOptional<z.ZodNumber>;
                y: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                x?: number | undefined;
                y?: number | undefined;
            }, {
                x?: number | undefined;
                y?: number | undefined;
            }>>>;
            opacity: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
            rotation: z.ZodOptional<z.ZodOptional<z.ZodNumber>>;
            scale: z.ZodOptional<z.ZodOptional<z.ZodObject<{
                x: z.ZodOptional<z.ZodNumber>;
                y: z.ZodOptional<z.ZodNumber>;
                unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
            }, "strip", z.ZodTypeAny, {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            }, {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            }>>>;
            anchor_point: z.ZodOptional<z.ZodOptional<z.ZodObject<{
                x: z.ZodNumber;
                y: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                x: number;
                y: number;
            }, {
                x: number;
                y: number;
            }>>>;
            parent_anchor_point: z.ZodOptional<z.ZodOptional<z.ZodObject<{
                x: z.ZodNumber;
                y: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                x: number;
                y: number;
            }, {
                x: number;
                y: number;
            }>>>;
            url: z.ZodOptional<z.ZodString>;
            details: z.ZodOptional<z.ZodObject<{
                name: z.ZodOptional<z.ZodString>;
                type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
                bytes: z.ZodOptional<z.ZodNumber>;
                format: z.ZodOptional<z.ZodString>;
                sha256: z.ZodOptional<z.ZodString>;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
                order: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }>>;
        }, "strip", z.ZodTypeAny, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            url?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            url?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }>>>;
        mutators: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    }, "strip", z.ZodTypeAny, {
        self: {
            url: string;
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            tag: string;
            name?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            } | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
            placeholder?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            } | undefined;
        };
        slots?: Record<string, {
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }> | undefined;
        mutator_reactions?: Record<string, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            url?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }> | undefined;
        mutators?: string[] | undefined;
    }, {
        self: {
            url: string;
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            tag: string;
            name?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            } | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
            placeholder?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            } | undefined;
        };
        slots?: Record<string, {
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }> | undefined;
        mutator_reactions?: Record<string, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            url?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }> | undefined;
        mutators?: string[] | undefined;
    }>>;
    customizing_overrides: z.ZodOptional<z.ZodObject<{
        self: z.ZodOptional<z.ZodObject<{
            url: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodOptional<z.ZodString>>;
            type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
            details: z.ZodOptional<z.ZodOptional<z.ZodObject<{
                name: z.ZodOptional<z.ZodString>;
                type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
                bytes: z.ZodOptional<z.ZodNumber>;
                format: z.ZodOptional<z.ZodString>;
                sha256: z.ZodOptional<z.ZodString>;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
                order: z.ZodOptional<z.ZodNumber>;
                duration: z.ZodOptional<z.ZodNumber>;
                codecs: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
                loop: z.ZodOptional<z.ZodBoolean>;
            }, "strip", z.ZodTypeAny, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            }, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            }>>>;
            image_overlay_specs: z.ZodOptional<z.ZodOptional<z.ZodObject<{
                layer: z.ZodOptional<z.ZodNumber>;
                order_in_layer: z.ZodOptional<z.ZodNumber>;
                offset: z.ZodOptional<z.ZodObject<{
                    x: z.ZodOptional<z.ZodNumber>;
                    y: z.ZodOptional<z.ZodNumber>;
                }, "strip", z.ZodTypeAny, {
                    x?: number | undefined;
                    y?: number | undefined;
                }, {
                    x?: number | undefined;
                    y?: number | undefined;
                }>>;
                opacity: z.ZodOptional<z.ZodNumber>;
                rotation: z.ZodOptional<z.ZodNumber>;
                scale: z.ZodOptional<z.ZodObject<{
                    x: z.ZodOptional<z.ZodNumber>;
                    y: z.ZodOptional<z.ZodNumber>;
                    unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
                }, "strip", z.ZodTypeAny, {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                }, {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                }>>;
                anchor_point: z.ZodOptional<z.ZodObject<{
                    x: z.ZodNumber;
                    y: z.ZodNumber;
                }, "strip", z.ZodTypeAny, {
                    x: number;
                    y: number;
                }, {
                    x: number;
                    y: number;
                }>>;
                parent_anchor_point: z.ZodOptional<z.ZodObject<{
                    x: z.ZodNumber;
                    y: z.ZodNumber;
                }, "strip", z.ZodTypeAny, {
                    x: number;
                    y: number;
                }, {
                    x: number;
                    y: number;
                }>>;
            }, "strip", z.ZodTypeAny, {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            }, {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            }>>>;
            placeholder: z.ZodOptional<z.ZodOptional<z.ZodObject<{
                url: z.ZodString;
                details: z.ZodOptional<z.ZodObject<{
                    name: z.ZodOptional<z.ZodString>;
                    type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
                    bytes: z.ZodOptional<z.ZodNumber>;
                    format: z.ZodOptional<z.ZodString>;
                    sha256: z.ZodOptional<z.ZodString>;
                    width: z.ZodOptional<z.ZodNumber>;
                    height: z.ZodOptional<z.ZodNumber>;
                    order: z.ZodOptional<z.ZodNumber>;
                }, "strip", z.ZodTypeAny, {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                }, {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                }>>;
            }, "strip", z.ZodTypeAny, {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            }, {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            }>>>;
            tag: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            url?: string | undefined;
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            } | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
            placeholder?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            } | undefined;
            tag?: string | undefined;
        }, {
            url?: string | undefined;
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            } | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
            placeholder?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            } | undefined;
            tag?: string | undefined;
        }>>;
        slots: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
            collections: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodUnion<[z.ZodNumber, z.ZodString]>, "many">>>;
            name: z.ZodOptional<z.ZodOptional<z.ZodString>>;
            image_overlay_specs: z.ZodOptional<z.ZodOptional<z.ZodObject<{
                layer: z.ZodOptional<z.ZodNumber>;
                order_in_layer: z.ZodOptional<z.ZodNumber>;
                offset: z.ZodOptional<z.ZodObject<{
                    x: z.ZodOptional<z.ZodNumber>;
                    y: z.ZodOptional<z.ZodNumber>;
                }, "strip", z.ZodTypeAny, {
                    x?: number | undefined;
                    y?: number | undefined;
                }, {
                    x?: number | undefined;
                    y?: number | undefined;
                }>>;
                opacity: z.ZodOptional<z.ZodNumber>;
                rotation: z.ZodOptional<z.ZodNumber>;
                scale: z.ZodOptional<z.ZodObject<{
                    x: z.ZodOptional<z.ZodNumber>;
                    y: z.ZodOptional<z.ZodNumber>;
                    unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
                }, "strip", z.ZodTypeAny, {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                }, {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                }>>;
                anchor_point: z.ZodOptional<z.ZodObject<{
                    x: z.ZodNumber;
                    y: z.ZodNumber;
                }, "strip", z.ZodTypeAny, {
                    x: number;
                    y: number;
                }, {
                    x: number;
                    y: number;
                }>>;
                parent_anchor_point: z.ZodOptional<z.ZodObject<{
                    x: z.ZodNumber;
                    y: z.ZodNumber;
                }, "strip", z.ZodTypeAny, {
                    x: number;
                    y: number;
                }, {
                    x: number;
                    y: number;
                }>>;
            }, "strip", z.ZodTypeAny, {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            }, {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            }>>>;
        }, "strip", z.ZodTypeAny, {
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }, {
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }>>>;
        mutator_reactions: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            layer: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodNumber>>>;
            order_in_layer: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodNumber>>>;
            offset: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodObject<{
                x: z.ZodOptional<z.ZodNumber>;
                y: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                x?: number | undefined;
                y?: number | undefined;
            }, {
                x?: number | undefined;
                y?: number | undefined;
            }>>>>;
            opacity: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodNumber>>>;
            rotation: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodNumber>>>;
            scale: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodObject<{
                x: z.ZodOptional<z.ZodNumber>;
                y: z.ZodOptional<z.ZodNumber>;
                unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
            }, "strip", z.ZodTypeAny, {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            }, {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            }>>>>;
            anchor_point: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodObject<{
                x: z.ZodNumber;
                y: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                x: number;
                y: number;
            }, {
                x: number;
                y: number;
            }>>>>;
            parent_anchor_point: z.ZodOptional<z.ZodOptional<z.ZodOptional<z.ZodObject<{
                x: z.ZodNumber;
                y: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                x: number;
                y: number;
            }, {
                x: number;
                y: number;
            }>>>>;
            url: z.ZodOptional<z.ZodOptional<z.ZodString>>;
            details: z.ZodOptional<z.ZodOptional<z.ZodObject<{
                name: z.ZodOptional<z.ZodString>;
                type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
                bytes: z.ZodOptional<z.ZodNumber>;
                format: z.ZodOptional<z.ZodString>;
                sha256: z.ZodOptional<z.ZodString>;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
                order: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }>>>;
        }, "strip", z.ZodTypeAny, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            url?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            url?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }>>>;
        mutators: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    }, "strip", z.ZodTypeAny, {
        self?: {
            url?: string | undefined;
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            } | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
            placeholder?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            } | undefined;
            tag?: string | undefined;
        } | undefined;
        slots?: Record<string, {
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }> | undefined;
        mutator_reactions?: Record<string, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            url?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }> | undefined;
        mutators?: string[] | undefined;
    }, {
        self?: {
            url?: string | undefined;
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            } | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
            placeholder?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            } | undefined;
            tag?: string | undefined;
        } | undefined;
        slots?: Record<string, {
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }> | undefined;
        mutator_reactions?: Record<string, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            url?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }> | undefined;
        mutators?: string[] | undefined;
    }>>;
    animation_url: z.ZodOptional<z.ZodString>;
    animation_details: z.ZodOptional<z.ZodObject<{
        name: z.ZodOptional<z.ZodString>;
        type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
        bytes: z.ZodOptional<z.ZodNumber>;
        format: z.ZodOptional<z.ZodString>;
        sha256: z.ZodOptional<z.ZodString>;
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
        order: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    }, {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    }>>;
    youtube_url: z.ZodOptional<z.ZodString>;
    created_by: z.ZodOptional<z.ZodString>;
    background_color: z.ZodOptional<z.ZodString>;
    external_url: z.ZodOptional<z.ZodString>;
    locale: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    schemaName: string;
    schemaVersion: string;
    originalSchemaVersion?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    image?: string | undefined;
    image_details?: {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    } | undefined;
    attributes?: {
        value: string | number;
        trait_type: string;
        display_type?: string | undefined;
    }[] | undefined;
    media?: Record<string, {
        url: string;
        type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
        name?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        } | undefined;
        thumbnail?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
        poster?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    }> | undefined;
    royalties?: {
        address: string;
        percent: number;
        isPrimaryOnly?: boolean | undefined;
    }[] | undefined;
    customizing?: {
        self: {
            url: string;
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            tag: string;
            name?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            } | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
            placeholder?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            } | undefined;
        };
        slots?: Record<string, {
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }> | undefined;
        mutator_reactions?: Record<string, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            url?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }> | undefined;
        mutators?: string[] | undefined;
    } | undefined;
    customizing_overrides?: {
        self?: {
            url?: string | undefined;
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            } | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
            placeholder?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            } | undefined;
            tag?: string | undefined;
        } | undefined;
        slots?: Record<string, {
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }> | undefined;
        mutator_reactions?: Record<string, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            url?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }> | undefined;
        mutators?: string[] | undefined;
    } | undefined;
    animation_url?: string | undefined;
    animation_details?: {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    } | undefined;
    youtube_url?: string | undefined;
    created_by?: string | undefined;
    background_color?: string | undefined;
    external_url?: string | undefined;
    locale?: string | undefined;
}, {
    schemaName?: string | undefined;
    schemaVersion?: string | undefined;
    originalSchemaVersion?: string | undefined;
    name?: string | undefined;
    description?: string | undefined;
    image?: string | undefined;
    image_details?: {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    } | undefined;
    attributes?: {
        value: string | number;
        trait_type: string;
        display_type?: string | undefined;
    }[] | undefined;
    media?: Record<string, {
        url: string;
        type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
        name?: string | undefined;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
            duration?: number | undefined;
            codecs?: string[] | undefined;
            loop?: boolean | undefined;
        } | undefined;
        thumbnail?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
        poster?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    }> | undefined;
    royalties?: {
        address: string;
        percent: number;
        isPrimaryOnly?: boolean | undefined;
    }[] | undefined;
    customizing?: {
        self: {
            url: string;
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            tag: string;
            name?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            } | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
            placeholder?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            } | undefined;
        };
        slots?: Record<string, {
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }> | undefined;
        mutator_reactions?: Record<string, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            url?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }> | undefined;
        mutators?: string[] | undefined;
    } | undefined;
    customizing_overrides?: {
        self?: {
            url?: string | undefined;
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
                duration?: number | undefined;
                codecs?: string[] | undefined;
                loop?: boolean | undefined;
            } | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
            placeholder?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
            } | undefined;
            tag?: string | undefined;
        } | undefined;
        slots?: Record<string, {
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }> | undefined;
        mutator_reactions?: Record<string, {
            layer?: number | undefined;
            order_in_layer?: number | undefined;
            offset?: {
                x?: number | undefined;
                y?: number | undefined;
            } | undefined;
            opacity?: number | undefined;
            rotation?: number | undefined;
            scale?: {
                x?: number | undefined;
                y?: number | undefined;
                unit?: "px" | "%" | undefined;
            } | undefined;
            anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            parent_anchor_point?: {
                x: number;
                y: number;
            } | undefined;
            url?: string | undefined;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }> | undefined;
        mutators?: string[] | undefined;
    } | undefined;
    animation_url?: string | undefined;
    animation_details?: {
        name?: string | undefined;
        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
        bytes?: number | undefined;
        format?: string | undefined;
        sha256?: string | undefined;
        width?: number | undefined;
        height?: number | undefined;
        order?: number | undefined;
    } | undefined;
    youtube_url?: string | undefined;
    created_by?: string | undefined;
    background_color?: string | undefined;
    external_url?: string | undefined;
    locale?: string | undefined;
}>;
type IV2Token = z.infer<typeof zTokenSchema>;
type IV2TokenForEncoding = z.input<typeof zTokenSchema>;
declare const zPotentialAttributeValues: z.ZodArray<z.ZodObject<{
    trait_type: z.ZodString;
    display_type: z.ZodOptional<z.ZodString>;
    values: z.ZodOptional<z.ZodArray<z.ZodUnion<[z.ZodString, z.ZodNumber]>, "many">>;
}, "strip", z.ZodTypeAny, {
    trait_type: string;
    display_type?: string | undefined;
    values?: (string | number)[] | undefined;
}, {
    trait_type: string;
    display_type?: string | undefined;
    values?: (string | number)[] | undefined;
}>, "many">;
type IV2PotentialAttributeValues = z.infer<typeof zPotentialAttributeValues>;
declare const zCollectionSchema: z.ZodObject<{
    schemaName: z.ZodDefault<z.ZodEffects<z.ZodOptional<z.ZodString>, string | undefined, string | undefined>>;
    schemaVersion: z.ZodDefault<z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>>;
    originalSchemaVersion: z.ZodOptional<z.ZodString>;
    cover_image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        details: z.ZodOptional<z.ZodObject<{
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
            bytes: z.ZodOptional<z.ZodNumber>;
            format: z.ZodOptional<z.ZodString>;
            sha256: z.ZodOptional<z.ZodString>;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
            order: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }>>;
        thumbnail: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            details: z.ZodOptional<z.ZodObject<{
                name: z.ZodOptional<z.ZodString>;
                type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
                bytes: z.ZodOptional<z.ZodNumber>;
                format: z.ZodOptional<z.ZodString>;
                sha256: z.ZodOptional<z.ZodString>;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
                order: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }>>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }, {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }>>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
        thumbnail?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    }, {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
        thumbnail?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    }>>;
    default_token_image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        details: z.ZodOptional<z.ZodObject<{
            name: z.ZodOptional<z.ZodString>;
            type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
            bytes: z.ZodOptional<z.ZodNumber>;
            format: z.ZodOptional<z.ZodString>;
            sha256: z.ZodOptional<z.ZodString>;
            width: z.ZodOptional<z.ZodNumber>;
            height: z.ZodOptional<z.ZodNumber>;
            order: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }, {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        }>>;
        thumbnail: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            details: z.ZodOptional<z.ZodObject<{
                name: z.ZodOptional<z.ZodString>;
                type: z.ZodOptional<z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>>;
                bytes: z.ZodOptional<z.ZodNumber>;
                format: z.ZodOptional<z.ZodString>;
                sha256: z.ZodOptional<z.ZodString>;
                width: z.ZodOptional<z.ZodNumber>;
                height: z.ZodOptional<z.ZodNumber>;
                order: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }, {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            }>>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }, {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        }>>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
        thumbnail?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    }, {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
        thumbnail?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    }>>;
    potential_attributes: z.ZodOptional<z.ZodArray<z.ZodObject<{
        trait_type: z.ZodString;
        display_type: z.ZodOptional<z.ZodString>;
        values: z.ZodOptional<z.ZodArray<z.ZodUnion<[z.ZodString, z.ZodNumber]>, "many">>;
    }, "strip", z.ZodTypeAny, {
        trait_type: string;
        display_type?: string | undefined;
        values?: (string | number)[] | undefined;
    }, {
        trait_type: string;
        display_type?: string | undefined;
        values?: (string | number)[] | undefined;
    }>, "many">>;
    customizing: z.ZodOptional<z.ZodObject<{
        slots: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            type: z.ZodEnum<["image", "animation", "video", "audio", "spatial", "pdf", "document", "other"]>;
            collections: z.ZodOptional<z.ZodArray<z.ZodUnion<[z.ZodNumber, z.ZodString]>, "many">>;
            name: z.ZodOptional<z.ZodString>;
            image_overlay_specs: z.ZodOptional<z.ZodObject<{
                layer: z.ZodOptional<z.ZodNumber>;
                order_in_layer: z.ZodOptional<z.ZodNumber>;
                offset: z.ZodOptional<z.ZodObject<{
                    x: z.ZodOptional<z.ZodNumber>;
                    y: z.ZodOptional<z.ZodNumber>;
                }, "strip", z.ZodTypeAny, {
                    x?: number | undefined;
                    y?: number | undefined;
                }, {
                    x?: number | undefined;
                    y?: number | undefined;
                }>>;
                opacity: z.ZodOptional<z.ZodNumber>;
                rotation: z.ZodOptional<z.ZodNumber>;
                scale: z.ZodOptional<z.ZodObject<{
                    x: z.ZodOptional<z.ZodNumber>;
                    y: z.ZodOptional<z.ZodNumber>;
                    unit: z.ZodOptional<z.ZodDefault<z.ZodEnum<["px", "%"]>>>;
                }, "strip", z.ZodTypeAny, {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                }, {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                }>>;
                anchor_point: z.ZodOptional<z.ZodObject<{
                    x: z.ZodNumber;
                    y: z.ZodNumber;
                }, "strip", z.ZodTypeAny, {
                    x: number;
                    y: number;
                }, {
                    x: number;
                    y: number;
                }>>;
                parent_anchor_point: z.ZodOptional<z.ZodObject<{
                    x: z.ZodNumber;
                    y: z.ZodNumber;
                }, "strip", z.ZodTypeAny, {
                    x: number;
                    y: number;
                }, {
                    x: number;
                    y: number;
                }>>;
            }, "strip", z.ZodTypeAny, {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            }, {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            }>>;
        }, "strip", z.ZodTypeAny, {
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }, {
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }>>>;
        customizes: z.ZodOptional<z.ZodArray<z.ZodUnion<[z.ZodNumber, z.ZodString]>, "many">>;
    }, "strip", z.ZodTypeAny, {
        slots?: Record<string, {
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }> | undefined;
        customizes?: (string | number)[] | undefined;
    }, {
        slots?: Record<string, {
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }> | undefined;
        customizes?: (string | number)[] | undefined;
    }>>;
    royalties: z.ZodOptional<z.ZodArray<z.ZodObject<{
        address: z.ZodString;
        percent: z.ZodNumber;
        isPrimaryOnly: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        address: string;
        percent: number;
        isPrimaryOnly?: boolean | undefined;
    }, {
        address: string;
        percent: number;
        isPrimaryOnly?: boolean | undefined;
    }>, "many">>;
}, "strip", z.ZodTypeAny, {
    schemaName: string;
    schemaVersion: string;
    originalSchemaVersion?: string | undefined;
    cover_image?: {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
        thumbnail?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    } | undefined;
    default_token_image?: {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
        thumbnail?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    } | undefined;
    potential_attributes?: {
        trait_type: string;
        display_type?: string | undefined;
        values?: (string | number)[] | undefined;
    }[] | undefined;
    customizing?: {
        slots?: Record<string, {
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }> | undefined;
        customizes?: (string | number)[] | undefined;
    } | undefined;
    royalties?: {
        address: string;
        percent: number;
        isPrimaryOnly?: boolean | undefined;
    }[] | undefined;
}, {
    schemaName?: string | undefined;
    schemaVersion?: string | undefined;
    originalSchemaVersion?: string | undefined;
    cover_image?: {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
        thumbnail?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    } | undefined;
    default_token_image?: {
        url: string;
        details?: {
            name?: string | undefined;
            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
            bytes?: number | undefined;
            format?: string | undefined;
            sha256?: string | undefined;
            width?: number | undefined;
            height?: number | undefined;
            order?: number | undefined;
        } | undefined;
        thumbnail?: {
            url: string;
            details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
        } | undefined;
    } | undefined;
    potential_attributes?: {
        trait_type: string;
        display_type?: string | undefined;
        values?: (string | number)[] | undefined;
    }[] | undefined;
    customizing?: {
        slots?: Record<string, {
            type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
            collections?: (string | number)[] | undefined;
            name?: string | undefined;
            image_overlay_specs?: {
                layer?: number | undefined;
                order_in_layer?: number | undefined;
                offset?: {
                    x?: number | undefined;
                    y?: number | undefined;
                } | undefined;
                opacity?: number | undefined;
                rotation?: number | undefined;
                scale?: {
                    x?: number | undefined;
                    y?: number | undefined;
                    unit?: "px" | "%" | undefined;
                } | undefined;
                anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
                parent_anchor_point?: {
                    x: number;
                    y: number;
                } | undefined;
            } | undefined;
        }> | undefined;
        customizes?: (string | number)[] | undefined;
    } | undefined;
    royalties?: {
        address: string;
        percent: number;
        isPrimaryOnly?: boolean | undefined;
    }[] | undefined;
}>;
type IV2Collection = z.infer<typeof zCollectionSchema>;
type IV2CollectionForEncoding = z.input<typeof zCollectionSchema>;

type schemas_ICollectionIdOrAddress = ICollectionIdOrAddress;
type schemas_ISemverString = ISemverString;
type schemas_IV2Attribute = IV2Attribute;
type schemas_IV2Collection = IV2Collection;
type schemas_IV2CollectionForEncoding = IV2CollectionForEncoding;
type schemas_IV2Customizing = IV2Customizing;
type schemas_IV2CustomizingFileInfo = IV2CustomizingFileInfo;
type schemas_IV2CustomizingImageOverlaySpecs = IV2CustomizingImageOverlaySpecs;
type schemas_IV2CustomizingMutatorReaction = IV2CustomizingMutatorReaction;
type schemas_IV2CustomizingOverrides = IV2CustomizingOverrides;
type schemas_IV2CustomizingSlot = IV2CustomizingSlot;
type schemas_IV2ImageDetails = IV2ImageDetails;
type schemas_IV2ImageWithDetails = IV2ImageWithDetails;
type schemas_IV2ImageWithDetailsAndThumbnail = IV2ImageWithDetailsAndThumbnail;
type schemas_IV2Media = IV2Media;
type schemas_IV2MediaDetails = IV2MediaDetails;
type schemas_IV2MediaType = IV2MediaType;
type schemas_IV2PotentialAttributeValues = IV2PotentialAttributeValues;
type schemas_IV2Royalty = IV2Royalty;
type schemas_IV2SemverString2xx = IV2SemverString2xx;
type schemas_IV2Token = IV2Token;
type schemas_IV2TokenForEncoding = IV2TokenForEncoding;
declare const schemas_zAttribute: typeof zAttribute;
declare const schemas_zCollectionIdOrAddress: typeof zCollectionIdOrAddress;
declare const schemas_zCollectionSchema: typeof zCollectionSchema;
declare const schemas_zCustomizing: typeof zCustomizing;
declare const schemas_zCustomizingFileInfo: typeof zCustomizingFileInfo;
declare const schemas_zCustomizingImageOverlaySpecs: typeof zCustomizingImageOverlaySpecs;
declare const schemas_zCustomizingMutatorReaction: typeof zCustomizingMutatorReaction;
declare const schemas_zCustomizingOverrides: typeof zCustomizingOverrides;
declare const schemas_zCustomizingSlot: typeof zCustomizingSlot;
declare const schemas_zImageDetails: typeof zImageDetails;
declare const schemas_zImageWithDetails: typeof zImageWithDetails;
declare const schemas_zImageWithDetailsAndThumbnail: typeof zImageWithDetailsAndThumbnail;
declare const schemas_zMedia: typeof zMedia;
declare const schemas_zMediaDetails: typeof zMediaDetails;
declare const schemas_zMediaType: typeof zMediaType;
declare const schemas_zRoyalty: typeof zRoyalty;
declare const schemas_zSemverString: typeof zSemverString;
declare const schemas_zSemverString2xx: typeof zSemverString2xx;
declare const schemas_zTokenSchema: typeof zTokenSchema;
declare namespace schemas {
  export { type schemas_ICollectionIdOrAddress as ICollectionIdOrAddress, type schemas_ISemverString as ISemverString, type schemas_IV2Attribute as IV2Attribute, type schemas_IV2Collection as IV2Collection, type schemas_IV2CollectionForEncoding as IV2CollectionForEncoding, type schemas_IV2Customizing as IV2Customizing, type schemas_IV2CustomizingFileInfo as IV2CustomizingFileInfo, type schemas_IV2CustomizingImageOverlaySpecs as IV2CustomizingImageOverlaySpecs, type schemas_IV2CustomizingMutatorReaction as IV2CustomizingMutatorReaction, type schemas_IV2CustomizingOverrides as IV2CustomizingOverrides, type schemas_IV2CustomizingSlot as IV2CustomizingSlot, type schemas_IV2ImageDetails as IV2ImageDetails, type schemas_IV2ImageWithDetails as IV2ImageWithDetails, type schemas_IV2ImageWithDetailsAndThumbnail as IV2ImageWithDetailsAndThumbnail, type schemas_IV2Media as IV2Media, type schemas_IV2MediaDetails as IV2MediaDetails, type schemas_IV2MediaType as IV2MediaType, type schemas_IV2PotentialAttributeValues as IV2PotentialAttributeValues, type schemas_IV2Royalty as IV2Royalty, type schemas_IV2SemverString2xx as IV2SemverString2xx, type schemas_IV2Token as IV2Token, type schemas_IV2TokenForEncoding as IV2TokenForEncoding, schemas_zAttribute as zAttribute, schemas_zCollectionIdOrAddress as zCollectionIdOrAddress, schemas_zCollectionSchema as zCollectionSchema, schemas_zCustomizing as zCustomizing, schemas_zCustomizingFileInfo as zCustomizingFileInfo, schemas_zCustomizingImageOverlaySpecs as zCustomizingImageOverlaySpecs, schemas_zCustomizingMutatorReaction as zCustomizingMutatorReaction, schemas_zCustomizingOverrides as zCustomizingOverrides, schemas_zCustomizingSlot as zCustomizingSlot, schemas_zImageDetails as zImageDetails, schemas_zImageWithDetails as zImageWithDetails, schemas_zImageWithDetailsAndThumbnail as zImageWithDetailsAndThumbnail, schemas_zMedia as zMedia, schemas_zMediaDetails as zMediaDetails, schemas_zMediaType as zMediaType, schemas_zRoyalty as zRoyalty, schemas_zSemverString as zSemverString, schemas_zSemverString2xx as zSemverString2xx, schemas_zTokenSchema as zTokenSchema };
}

declare const SchemaTools: {
    decode: {
        collection: (collectionProperties: ProbablyDecodedProperty[], options?: DecodeCollectionOptions | undefined) => Promise<{
            schemaName: string;
            schemaVersion: string;
            originalSchemaVersion?: string | undefined;
            cover_image?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
                thumbnail?: {
                    url: string;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                    } | undefined;
                } | undefined;
            } | undefined;
            default_token_image?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
                thumbnail?: {
                    url: string;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                    } | undefined;
                } | undefined;
            } | undefined;
            potential_attributes?: {
                trait_type: string;
                display_type?: string | undefined;
                values?: (string | number)[] | undefined;
            }[] | undefined;
            customizing?: {
                slots?: Record<string, {
                    type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
                    collections?: (string | number)[] | undefined;
                    name?: string | undefined;
                    image_overlay_specs?: {
                        layer?: number | undefined;
                        order_in_layer?: number | undefined;
                        offset?: {
                            x?: number | undefined;
                            y?: number | undefined;
                        } | undefined;
                        opacity?: number | undefined;
                        rotation?: number | undefined;
                        scale?: {
                            x?: number | undefined;
                            y?: number | undefined;
                            unit?: "px" | "%" | undefined;
                        } | undefined;
                        anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                        parent_anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                    } | undefined;
                }> | undefined;
                customizes?: (string | number)[] | undefined;
            } | undefined;
            royalties?: {
                address: string;
                percent: number;
                isPrimaryOnly?: boolean | undefined;
            }[] | undefined;
        }>;
        token: (tokenProperties: ProbablyDecodedProperty[], options?: DecodeTokenOptions | undefined) => Promise<{
            schemaName: string;
            schemaVersion: string;
            originalSchemaVersion?: string | undefined;
            name?: string | undefined;
            description?: string | undefined;
            image?: string | undefined;
            image_details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
            attributes?: {
                value: string | number;
                trait_type: string;
                display_type?: string | undefined;
            }[] | undefined;
            media?: Record<string, {
                url: string;
                type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
                name?: string | undefined;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                    duration?: number | undefined;
                    codecs?: string[] | undefined;
                    loop?: boolean | undefined;
                } | undefined;
                thumbnail?: {
                    url: string;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                    } | undefined;
                } | undefined;
                poster?: {
                    url: string;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                    } | undefined;
                } | undefined;
            }> | undefined;
            royalties?: {
                address: string;
                percent: number;
                isPrimaryOnly?: boolean | undefined;
            }[] | undefined;
            customizing?: {
                self: {
                    url: string;
                    type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
                    tag: string;
                    name?: string | undefined;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                        duration?: number | undefined;
                        codecs?: string[] | undefined;
                        loop?: boolean | undefined;
                    } | undefined;
                    image_overlay_specs?: {
                        layer?: number | undefined;
                        order_in_layer?: number | undefined;
                        offset?: {
                            x?: number | undefined;
                            y?: number | undefined;
                        } | undefined;
                        opacity?: number | undefined;
                        rotation?: number | undefined;
                        scale?: {
                            x?: number | undefined;
                            y?: number | undefined;
                            unit?: "px" | "%" | undefined;
                        } | undefined;
                        anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                        parent_anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                    } | undefined;
                    placeholder?: {
                        url: string;
                        details?: {
                            name?: string | undefined;
                            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                            bytes?: number | undefined;
                            format?: string | undefined;
                            sha256?: string | undefined;
                            width?: number | undefined;
                            height?: number | undefined;
                            order?: number | undefined;
                        } | undefined;
                    } | undefined;
                };
                slots?: Record<string, {
                    type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
                    collections?: (string | number)[] | undefined;
                    name?: string | undefined;
                    image_overlay_specs?: {
                        layer?: number | undefined;
                        order_in_layer?: number | undefined;
                        offset?: {
                            x?: number | undefined;
                            y?: number | undefined;
                        } | undefined;
                        opacity?: number | undefined;
                        rotation?: number | undefined;
                        scale?: {
                            x?: number | undefined;
                            y?: number | undefined;
                            unit?: "px" | "%" | undefined;
                        } | undefined;
                        anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                        parent_anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                    } | undefined;
                }> | undefined;
                mutator_reactions?: Record<string, {
                    layer?: number | undefined;
                    order_in_layer?: number | undefined;
                    offset?: {
                        x?: number | undefined;
                        y?: number | undefined;
                    } | undefined;
                    opacity?: number | undefined;
                    rotation?: number | undefined;
                    scale?: {
                        x?: number | undefined;
                        y?: number | undefined;
                        unit?: "px" | "%" | undefined;
                    } | undefined;
                    anchor_point?: {
                        x: number;
                        y: number;
                    } | undefined;
                    parent_anchor_point?: {
                        x: number;
                        y: number;
                    } | undefined;
                    url?: string | undefined;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                    } | undefined;
                }> | undefined;
                mutators?: string[] | undefined;
            } | undefined;
            customizing_overrides?: {
                self?: {
                    url?: string | undefined;
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                        duration?: number | undefined;
                        codecs?: string[] | undefined;
                        loop?: boolean | undefined;
                    } | undefined;
                    image_overlay_specs?: {
                        layer?: number | undefined;
                        order_in_layer?: number | undefined;
                        offset?: {
                            x?: number | undefined;
                            y?: number | undefined;
                        } | undefined;
                        opacity?: number | undefined;
                        rotation?: number | undefined;
                        scale?: {
                            x?: number | undefined;
                            y?: number | undefined;
                            unit?: "px" | "%" | undefined;
                        } | undefined;
                        anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                        parent_anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                    } | undefined;
                    placeholder?: {
                        url: string;
                        details?: {
                            name?: string | undefined;
                            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                            bytes?: number | undefined;
                            format?: string | undefined;
                            sha256?: string | undefined;
                            width?: number | undefined;
                            height?: number | undefined;
                            order?: number | undefined;
                        } | undefined;
                    } | undefined;
                    tag?: string | undefined;
                } | undefined;
                slots?: Record<string, {
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    collections?: (string | number)[] | undefined;
                    name?: string | undefined;
                    image_overlay_specs?: {
                        layer?: number | undefined;
                        order_in_layer?: number | undefined;
                        offset?: {
                            x?: number | undefined;
                            y?: number | undefined;
                        } | undefined;
                        opacity?: number | undefined;
                        rotation?: number | undefined;
                        scale?: {
                            x?: number | undefined;
                            y?: number | undefined;
                            unit?: "px" | "%" | undefined;
                        } | undefined;
                        anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                        parent_anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                    } | undefined;
                }> | undefined;
                mutator_reactions?: Record<string, {
                    layer?: number | undefined;
                    order_in_layer?: number | undefined;
                    offset?: {
                        x?: number | undefined;
                        y?: number | undefined;
                    } | undefined;
                    opacity?: number | undefined;
                    rotation?: number | undefined;
                    scale?: {
                        x?: number | undefined;
                        y?: number | undefined;
                        unit?: "px" | "%" | undefined;
                    } | undefined;
                    anchor_point?: {
                        x: number;
                        y: number;
                    } | undefined;
                    parent_anchor_point?: {
                        x: number;
                        y: number;
                    } | undefined;
                    url?: string | undefined;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                    } | undefined;
                }> | undefined;
                mutators?: string[] | undefined;
            } | undefined;
            animation_url?: string | undefined;
            animation_details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
            youtube_url?: string | undefined;
            created_by?: string | undefined;
            background_color?: string | undefined;
            external_url?: string | undefined;
            locale?: string | undefined;
        }>;
    };
    encode: {
        collection: (data: {
            schemaName?: string | undefined;
            schemaVersion?: string | undefined;
            originalSchemaVersion?: string | undefined;
            cover_image?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
                thumbnail?: {
                    url: string;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                    } | undefined;
                } | undefined;
            } | undefined;
            default_token_image?: {
                url: string;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                } | undefined;
                thumbnail?: {
                    url: string;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                    } | undefined;
                } | undefined;
            } | undefined;
            potential_attributes?: {
                trait_type: string;
                display_type?: string | undefined;
                values?: (string | number)[] | undefined;
            }[] | undefined;
            customizing?: {
                slots?: Record<string, {
                    type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
                    collections?: (string | number)[] | undefined;
                    name?: string | undefined;
                    image_overlay_specs?: {
                        layer?: number | undefined;
                        order_in_layer?: number | undefined;
                        offset?: {
                            x?: number | undefined;
                            y?: number | undefined;
                        } | undefined;
                        opacity?: number | undefined;
                        rotation?: number | undefined;
                        scale?: {
                            x?: number | undefined;
                            y?: number | undefined;
                            unit?: "px" | "%" | undefined;
                        } | undefined;
                        anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                        parent_anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                    } | undefined;
                }> | undefined;
                customizes?: (string | number)[] | undefined;
            } | undefined;
            royalties?: {
                address: string;
                percent: number;
                isPrimaryOnly?: boolean | undefined;
            }[] | undefined;
        }, options?: EncodeCollectionOptions | undefined) => EncodeCollectionResult;
        token: (data: {
            schemaName?: string | undefined;
            schemaVersion?: string | undefined;
            originalSchemaVersion?: string | undefined;
            name?: string | undefined;
            description?: string | undefined;
            image?: string | undefined;
            image_details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
            attributes?: {
                value: string | number;
                trait_type: string;
                display_type?: string | undefined;
            }[] | undefined;
            media?: Record<string, {
                url: string;
                type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
                name?: string | undefined;
                details?: {
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    bytes?: number | undefined;
                    format?: string | undefined;
                    sha256?: string | undefined;
                    width?: number | undefined;
                    height?: number | undefined;
                    order?: number | undefined;
                    duration?: number | undefined;
                    codecs?: string[] | undefined;
                    loop?: boolean | undefined;
                } | undefined;
                thumbnail?: {
                    url: string;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                    } | undefined;
                } | undefined;
                poster?: {
                    url: string;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                    } | undefined;
                } | undefined;
            }> | undefined;
            royalties?: {
                address: string;
                percent: number;
                isPrimaryOnly?: boolean | undefined;
            }[] | undefined;
            customizing?: {
                self: {
                    url: string;
                    type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
                    tag: string;
                    name?: string | undefined;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                        duration?: number | undefined;
                        codecs?: string[] | undefined;
                        loop?: boolean | undefined;
                    } | undefined;
                    image_overlay_specs?: {
                        layer?: number | undefined;
                        order_in_layer?: number | undefined;
                        offset?: {
                            x?: number | undefined;
                            y?: number | undefined;
                        } | undefined;
                        opacity?: number | undefined;
                        rotation?: number | undefined;
                        scale?: {
                            x?: number | undefined;
                            y?: number | undefined;
                            unit?: "px" | "%" | undefined;
                        } | undefined;
                        anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                        parent_anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                    } | undefined;
                    placeholder?: {
                        url: string;
                        details?: {
                            name?: string | undefined;
                            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                            bytes?: number | undefined;
                            format?: string | undefined;
                            sha256?: string | undefined;
                            width?: number | undefined;
                            height?: number | undefined;
                            order?: number | undefined;
                        } | undefined;
                    } | undefined;
                };
                slots?: Record<string, {
                    type: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other";
                    collections?: (string | number)[] | undefined;
                    name?: string | undefined;
                    image_overlay_specs?: {
                        layer?: number | undefined;
                        order_in_layer?: number | undefined;
                        offset?: {
                            x?: number | undefined;
                            y?: number | undefined;
                        } | undefined;
                        opacity?: number | undefined;
                        rotation?: number | undefined;
                        scale?: {
                            x?: number | undefined;
                            y?: number | undefined;
                            unit?: "px" | "%" | undefined;
                        } | undefined;
                        anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                        parent_anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                    } | undefined;
                }> | undefined;
                mutator_reactions?: Record<string, {
                    layer?: number | undefined;
                    order_in_layer?: number | undefined;
                    offset?: {
                        x?: number | undefined;
                        y?: number | undefined;
                    } | undefined;
                    opacity?: number | undefined;
                    rotation?: number | undefined;
                    scale?: {
                        x?: number | undefined;
                        y?: number | undefined;
                        unit?: "px" | "%" | undefined;
                    } | undefined;
                    anchor_point?: {
                        x: number;
                        y: number;
                    } | undefined;
                    parent_anchor_point?: {
                        x: number;
                        y: number;
                    } | undefined;
                    url?: string | undefined;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                    } | undefined;
                }> | undefined;
                mutators?: string[] | undefined;
            } | undefined;
            customizing_overrides?: {
                self?: {
                    url?: string | undefined;
                    name?: string | undefined;
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                        duration?: number | undefined;
                        codecs?: string[] | undefined;
                        loop?: boolean | undefined;
                    } | undefined;
                    image_overlay_specs?: {
                        layer?: number | undefined;
                        order_in_layer?: number | undefined;
                        offset?: {
                            x?: number | undefined;
                            y?: number | undefined;
                        } | undefined;
                        opacity?: number | undefined;
                        rotation?: number | undefined;
                        scale?: {
                            x?: number | undefined;
                            y?: number | undefined;
                            unit?: "px" | "%" | undefined;
                        } | undefined;
                        anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                        parent_anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                    } | undefined;
                    placeholder?: {
                        url: string;
                        details?: {
                            name?: string | undefined;
                            type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                            bytes?: number | undefined;
                            format?: string | undefined;
                            sha256?: string | undefined;
                            width?: number | undefined;
                            height?: number | undefined;
                            order?: number | undefined;
                        } | undefined;
                    } | undefined;
                    tag?: string | undefined;
                } | undefined;
                slots?: Record<string, {
                    type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                    collections?: (string | number)[] | undefined;
                    name?: string | undefined;
                    image_overlay_specs?: {
                        layer?: number | undefined;
                        order_in_layer?: number | undefined;
                        offset?: {
                            x?: number | undefined;
                            y?: number | undefined;
                        } | undefined;
                        opacity?: number | undefined;
                        rotation?: number | undefined;
                        scale?: {
                            x?: number | undefined;
                            y?: number | undefined;
                            unit?: "px" | "%" | undefined;
                        } | undefined;
                        anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                        parent_anchor_point?: {
                            x: number;
                            y: number;
                        } | undefined;
                    } | undefined;
                }> | undefined;
                mutator_reactions?: Record<string, {
                    layer?: number | undefined;
                    order_in_layer?: number | undefined;
                    offset?: {
                        x?: number | undefined;
                        y?: number | undefined;
                    } | undefined;
                    opacity?: number | undefined;
                    rotation?: number | undefined;
                    scale?: {
                        x?: number | undefined;
                        y?: number | undefined;
                        unit?: "px" | "%" | undefined;
                    } | undefined;
                    anchor_point?: {
                        x: number;
                        y: number;
                    } | undefined;
                    parent_anchor_point?: {
                        x: number;
                        y: number;
                    } | undefined;
                    url?: string | undefined;
                    details?: {
                        name?: string | undefined;
                        type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                        bytes?: number | undefined;
                        format?: string | undefined;
                        sha256?: string | undefined;
                        width?: number | undefined;
                        height?: number | undefined;
                        order?: number | undefined;
                    } | undefined;
                }> | undefined;
                mutators?: string[] | undefined;
            } | undefined;
            animation_url?: string | undefined;
            animation_details?: {
                name?: string | undefined;
                type?: "image" | "animation" | "video" | "audio" | "spatial" | "pdf" | "document" | "other" | undefined;
                bytes?: number | undefined;
                format?: string | undefined;
                sha256?: string | undefined;
                width?: number | undefined;
                height?: number | undefined;
                order?: number | undefined;
            } | undefined;
            youtube_url?: string | undefined;
            created_by?: string | undefined;
            background_color?: string | undefined;
            external_url?: string | undefined;
            locale?: string | undefined;
        }, options?: EncodeTokenOptions | undefined) => {
            tokenProperties: PropertyWithHex[];
        };
    };
    tools: {
        schemas: typeof schemas;
        decodeOld: {
            collection: (properties: ProbablyDecodedProperty[] | null | undefined, schemaFamily: COLLECTION_SCHEMA_FAMILY, options?: DecodingImageLinkOptions | undefined) => UniqueCollectionSchemaIntermediate;
            token: (propertyArray: ProbablyDecodedProperty[] | null | undefined, schema: UniqueCollectionSchemaIntermediate, options?: DecodeTokenOptions | undefined, imageLinkOptions?: DecodingImageLinkOptions | undefined) => UniqueTokenIntermediate;
            utils: {
                parseImageLinkOptions: (options?: DecodingImageLinkOptions | undefined) => Required<DecodingImageLinkOptions>;
            };
        };
        constants: {
            DEFAULT_SCHEMA_NAME: string;
            DEFAULT_SCHEMA_VERSION: string;
            DEFAULT_PERMISSION: {
                readonly mutable: true;
                readonly collectionAdmin: true;
                readonly tokenOwner: false;
            };
            PERMISSIONS: {
                readonly REWRITEABLE_FOR_BOTH: {
                    readonly mutable: true;
                    readonly collectionAdmin: true;
                    readonly tokenOwner: true;
                };
                readonly REWRITEABLE_FOR_COLLECTION_ADMIN: {
                    readonly mutable: true;
                    readonly collectionAdmin: true;
                    readonly tokenOwner: false;
                };
                readonly REWRITEABLE_FOR_TOKEN_OWNER: {
                    readonly mutable: true;
                    readonly collectionAdmin: false;
                    readonly tokenOwner: true;
                };
                readonly WRITABLE_ONCE_FOR_BOTH: {
                    readonly mutable: false;
                    readonly collectionAdmin: true;
                    readonly tokenOwner: true;
                };
                readonly WRITABLE_ONCE_FOR_COLLECTION_ADMIN: {
                    readonly mutable: false;
                    readonly collectionAdmin: true;
                    readonly tokenOwner: false;
                };
                readonly WRITABLE_ONCE_FOR_TOKEN_OWNER: {
                    readonly mutable: false;
                    readonly collectionAdmin: false;
                    readonly tokenOwner: true;
                };
            };
        };
    };
};

export { COLLECTION_SCHEMA_FAMILY, type CollectionTokenPropertyPermissions, type CrossAccountId, type DecodeCollectionOptions, type DecodeTokenOptions, type EncodeCollectionOptions, type EncodeCollectionResult, type EncodeTokenOptions, type ICollectionIdOrAddress, type ISemverString, type IV2Attribute, type IV2Collection, type IV2CollectionForEncoding, type IV2Customizing, type IV2CustomizingFileInfo, type IV2CustomizingImageOverlaySpecs, type IV2CustomizingMutatorReaction, type IV2CustomizingOverrides, type IV2CustomizingSlot, type IV2ImageDetails, type IV2ImageWithDetails, type IV2ImageWithDetailsAndThumbnail, type IV2Media, type IV2MediaDetails, type IV2MediaType, type IV2PotentialAttributeValues, type IV2Royalty, type IV2SemverString2xx, type IV2Token, type IV2TokenForEncoding, type ProbablyDecodedProperty, type ProbablyDecodedPropsDict, type PropertyForEncoding, type PropertyWithHex, SchemaTools, type TokenPropertyPermission, type TokenPropertyPermissionObject, zAttribute, zCollectionIdOrAddress, zCollectionSchema, zCustomizing, zCustomizingFileInfo, zCustomizingImageOverlaySpecs, zCustomizingMutatorReaction, zCustomizingOverrides, zCustomizingSlot, zImageDetails, zImageWithDetails, zImageWithDetailsAndThumbnail, zMedia, zMediaDetails, zMediaType, zRoyalty, zSemverString, zSemverString2xx, zTokenSchema };
