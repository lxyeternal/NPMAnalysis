"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/pure.ts
var pure_exports = {};
__export(pure_exports, {
  COLLECTION_SCHEMA_FAMILY: () => COLLECTION_SCHEMA_FAMILY,
  SCHEMAS: () => schema_zod_exports,
  SCHEMAS_CONSTANTS: () => SCHEMAS_CONSTANTS,
  zAttribute: () => zAttribute,
  zCollectionIdOrAddress: () => zCollectionIdOrAddress,
  zCollectionSchema: () => zCollectionSchema,
  zCustomizing: () => zCustomizing,
  zCustomizingFileInfo: () => zCustomizingFileInfo,
  zCustomizingImageOverlaySpecs: () => zCustomizingImageOverlaySpecs,
  zCustomizingMutatorReaction: () => zCustomizingMutatorReaction,
  zCustomizingOverrides: () => zCustomizingOverrides,
  zCustomizingSlot: () => zCustomizingSlot,
  zImageDetails: () => zImageDetails,
  zImageWithDetails: () => zImageWithDetails,
  zImageWithDetailsAndThumbnail: () => zImageWithDetailsAndThumbnail,
  zMedia: () => zMedia,
  zMediaDetails: () => zMediaDetails,
  zMediaType: () => zMediaType,
  zRoyalty: () => zRoyalty,
  zSemverString: () => zSemverString,
  zSemverString2xx: () => zSemverString2xx,
  zTokenSchema: () => zTokenSchema
});
module.exports = __toCommonJS(pure_exports);

// src/schema.zod.ts
var schema_zod_exports = {};
__export(schema_zod_exports, {
  zAttribute: () => zAttribute,
  zCollectionIdOrAddress: () => zCollectionIdOrAddress,
  zCollectionSchema: () => zCollectionSchema,
  zCustomizing: () => zCustomizing,
  zCustomizingFileInfo: () => zCustomizingFileInfo,
  zCustomizingImageOverlaySpecs: () => zCustomizingImageOverlaySpecs,
  zCustomizingMutatorReaction: () => zCustomizingMutatorReaction,
  zCustomizingOverrides: () => zCustomizingOverrides,
  zCustomizingSlot: () => zCustomizingSlot,
  zImageDetails: () => zImageDetails,
  zImageWithDetails: () => zImageWithDetails,
  zImageWithDetailsAndThumbnail: () => zImageWithDetailsAndThumbnail,
  zMedia: () => zMedia,
  zMediaDetails: () => zMediaDetails,
  zMediaType: () => zMediaType,
  zRoyalty: () => zRoyalty,
  zSemverString: () => zSemverString,
  zSemverString2xx: () => zSemverString2xx,
  zTokenSchema: () => zTokenSchema
});
var import_extend = require("zod-openapi/extend");
var import_zod = require("zod");

// src/constants.ts
var PERMISSION = {
  REWRITEABLE_FOR_BOTH: { mutable: true, collectionAdmin: true, tokenOwner: true },
  REWRITEABLE_FOR_COLLECTION_ADMIN: { mutable: true, collectionAdmin: true, tokenOwner: false },
  REWRITEABLE_FOR_TOKEN_OWNER: { mutable: true, collectionAdmin: false, tokenOwner: true },
  WRITABLE_ONCE_FOR_BOTH: { mutable: false, collectionAdmin: true, tokenOwner: true },
  WRITABLE_ONCE_FOR_COLLECTION_ADMIN: { mutable: false, collectionAdmin: true, tokenOwner: false },
  WRITABLE_ONCE_FOR_TOKEN_OWNER: { mutable: false, collectionAdmin: false, tokenOwner: true }
};
var DEFAULT_PERMISSION = PERMISSION.REWRITEABLE_FOR_COLLECTION_ADMIN;
var SCHEMA_NAME = "unique";
var SCHEMA_VERSION = "2.0.0";

// src/schema.zod.ts
var zCollectionIdOrAddress = import_zod.z.union([
  import_zod.z.number().min(1).max(2 ** 32 - 1),
  import_zod.z.string().regex(/^0x[a-fA-F0-9]{40}$/)
]);
var zSemverString = import_zod.z.string().regex(/^\d+\.\d+\.\d+$/);
var zMediaType = import_zod.z.enum([
  "image",
  "animation",
  "video",
  "audio",
  "spatial",
  "pdf",
  "document",
  "other"
]);
var zSemverString2xx = zSemverString.refine(
  (version) => {
    if (typeof version === "string") {
      const [major, minor, patch] = version.split(".").map(Number);
      if (major !== 2)
        return false;
      if (minor < 0)
        return false;
      if (patch < 0)
        return false;
    }
    return true;
  },
  "version must be in semver format: 2.x.x"
);
var zImageDetails = import_zod.z.object({
  name: import_zod.z.string().optional(),
  type: zMediaType.optional(),
  bytes: import_zod.z.number().optional(),
  format: import_zod.z.string().optional(),
  sha256: import_zod.z.string().optional(),
  width: import_zod.z.number().optional(),
  height: import_zod.z.number().optional(),
  order: import_zod.z.number().optional()
});
var zImageWithDetails = import_zod.z.object({
  url: import_zod.z.string(),
  details: zImageDetails.optional()
});
var zImageWithDetailsAndThumbnail = zImageWithDetails.extend({
  thumbnail: zImageWithDetails.optional()
});
var zMediaDetails = zImageDetails.extend({
  duration: import_zod.z.number().optional(),
  codecs: import_zod.z.array(import_zod.z.string()).optional(),
  loop: import_zod.z.boolean().optional()
});
var zMedia = import_zod.z.object({
  type: zMediaType,
  url: import_zod.z.string(),
  name: import_zod.z.string().optional(),
  details: zMediaDetails.optional(),
  thumbnail: zImageWithDetails.optional(),
  poster: zImageWithDetails.optional()
});
var zAttribute = import_zod.z.object({
  trait_type: import_zod.z.string(),
  value: import_zod.z.union([import_zod.z.string(), import_zod.z.number()]),
  display_type: import_zod.z.string().optional()
});
var zRoyalty = import_zod.z.object({
  address: import_zod.z.string(),
  percent: import_zod.z.number().min(0).max(100),
  isPrimaryOnly: import_zod.z.boolean().optional()
});
var zCustomizingImageOverlaySpecs = import_zod.z.object({
  layer: import_zod.z.number(),
  order_in_layer: import_zod.z.number(),
  offset: import_zod.z.object({ x: import_zod.z.number(), y: import_zod.z.number() }).partial(),
  opacity: import_zod.z.number(),
  rotation: import_zod.z.number(),
  scale: import_zod.z.object({
    x: import_zod.z.number().optional(),
    y: import_zod.z.number().optional(),
    unit: import_zod.z.enum(["px", "%"]).default("%").optional()
  }),
  anchor_point: import_zod.z.object({ x: import_zod.z.number(), y: import_zod.z.number() }),
  parent_anchor_point: import_zod.z.object({ x: import_zod.z.number(), y: import_zod.z.number() })
}).partial();
var zCustomizingMutatorReaction = zCustomizingImageOverlaySpecs.extend({
  url: import_zod.z.string(),
  details: zImageDetails
}).partial();
var zCustomizingFileInfo = import_zod.z.object({
  type: zMediaType,
  url: import_zod.z.string(),
  name: import_zod.z.string().optional(),
  details: zMediaDetails.optional(),
  image_overlay_specs: zCustomizingImageOverlaySpecs.optional(),
  placeholder: zImageWithDetails.optional()
});
var zCustomizingSlot = import_zod.z.object({
  type: zMediaType,
  collections: zCollectionIdOrAddress.array().optional(),
  name: import_zod.z.string().optional(),
  image_overlay_specs: zCustomizingImageOverlaySpecs.optional()
});
var zCustomizing = import_zod.z.object({
  self: zCustomizingFileInfo.extend({ tag: import_zod.z.string() }),
  slots: import_zod.z.record(zCustomizingSlot).optional(),
  mutator_reactions: import_zod.z.record(zCustomizingMutatorReaction).optional(),
  mutators: import_zod.z.array(import_zod.z.string()).optional()
});
var zCustomizingOverrides = import_zod.z.object({
  self: zCustomizingFileInfo.extend({ tag: import_zod.z.string() }).partial().optional(),
  slots: import_zod.z.record(zCustomizingSlot.partial()).optional(),
  mutator_reactions: import_zod.z.record(zCustomizingMutatorReaction.partial()).optional(),
  mutators: import_zod.z.array(import_zod.z.string()).optional()
});
var zTokenSchema = import_zod.z.object({
  // base stuff
  schemaName: import_zod.z.string().optional().default(SCHEMA_NAME),
  schemaVersion: zSemverString2xx.optional().default(SCHEMA_VERSION),
  originalSchemaVersion: zSemverString.optional(),
  name: import_zod.z.string().optional(),
  description: import_zod.z.string().optional(),
  image: import_zod.z.string().optional(),
  image_details: zImageDetails.optional(),
  attributes: import_zod.z.array(zAttribute).optional(),
  // Unique-specific stuff
  media: import_zod.z.record(zMedia).optional(),
  royalties: import_zod.z.array(zRoyalty).optional(),
  customizing: zCustomizing.optional(),
  customizing_overrides: zCustomizingOverrides.optional(),
  // OpenSea-compatibility stuff
  animation_url: import_zod.z.string().optional(),
  animation_details: zImageDetails.optional(),
  youtube_url: import_zod.z.string().optional(),
  created_by: import_zod.z.string().optional(),
  background_color: import_zod.z.string().optional(),
  external_url: import_zod.z.string().optional(),
  locale: import_zod.z.string().optional()
});
var zPotentialAttributeValues = import_zod.z.array(import_zod.z.object({
  trait_type: import_zod.z.string(),
  display_type: import_zod.z.string().optional(),
  values: import_zod.z.array(import_zod.z.union([import_zod.z.string(), import_zod.z.number()])).optional()
}));
var zCollectionSchema = import_zod.z.object({
  schemaName: import_zod.z.string().optional().refine((v) => v === SCHEMA_NAME, { message: `schemaName must be "${SCHEMA_NAME}"` }).default(SCHEMA_NAME),
  schemaVersion: zSemverString2xx.optional().default(SCHEMA_VERSION),
  originalSchemaVersion: zSemverString.optional(),
  cover_image: zImageWithDetailsAndThumbnail.optional(),
  default_token_image: zImageWithDetailsAndThumbnail.optional(),
  potential_attributes: zPotentialAttributeValues.optional(),
  customizing: import_zod.z.object({
    slots: import_zod.z.record(zCustomizingSlot).optional(),
    customizes: zCollectionIdOrAddress.array().optional()
  }).optional(),
  royalties: import_zod.z.array(zRoyalty).optional()
});

// src/types.ts
var COLLECTION_SCHEMA_FAMILY = /* @__PURE__ */ ((COLLECTION_SCHEMA_FAMILY2) => {
  COLLECTION_SCHEMA_FAMILY2["V0"] = "V0";
  COLLECTION_SCHEMA_FAMILY2["V1"] = "V1";
  COLLECTION_SCHEMA_FAMILY2["V2"] = "V2";
  COLLECTION_SCHEMA_FAMILY2["OTHER_ERC721"] = "ERC721";
  COLLECTION_SCHEMA_FAMILY2["UNKNOWN"] = "UNKNOWN";
  return COLLECTION_SCHEMA_FAMILY2;
})(COLLECTION_SCHEMA_FAMILY || {});

// src/pure.ts
var SCHEMAS_CONSTANTS = {
  defaultSchemaName: SCHEMA_NAME,
  defaultSchemaVersion: SCHEMA_VERSION,
  defaultPermission: DEFAULT_PERMISSION,
  permissions: PERMISSION
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  COLLECTION_SCHEMA_FAMILY,
  SCHEMAS,
  SCHEMAS_CONSTANTS,
  zAttribute,
  zCollectionIdOrAddress,
  zCollectionSchema,
  zCustomizing,
  zCustomizingFileInfo,
  zCustomizingImageOverlaySpecs,
  zCustomizingMutatorReaction,
  zCustomizingOverrides,
  zCustomizingSlot,
  zImageDetails,
  zImageWithDetails,
  zImageWithDetailsAndThumbnail,
  zMedia,
  zMediaDetails,
  zMediaType,
  zRoyalty,
  zSemverString,
  zSemverString2xx,
  zTokenSchema
});
//# sourceMappingURL=pure.js.map