# easy-scrollspy-npm

## desc
Very easy scrollspy based on IntersectionObserver

## usage
```
import { easyScrollspy } from 'easy-scrollspy'

easyScrollspy()
```

## options
```
let intSettings = {
    navLinks: '.spy-nav-link',
    section: '.spy-section',
    rootMargin: '0px',
    threshold: 0.5,
    activeClass: 'active'
}
```
