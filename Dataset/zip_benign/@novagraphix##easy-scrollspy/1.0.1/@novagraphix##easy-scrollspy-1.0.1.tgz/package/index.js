let activeSection = null
let navLinks = null
let sections = null
let observer = null
let settings = null

export function easyScrollspy(extSettings) {
    if (extSettings == null) extSettings = {}

    let intSettings = {
        navLinks: '.spy-nav-link',
        section: '.spy-section',
        rootMargin: '0px',
        threshold: 0.5,
        activeClass: 'active'
    }

    settings = { ...intSettings, ...extSettings }

    navLinks = document.querySelectorAll(settings.navLinks);
    sections = document.querySelectorAll(settings.section);

    let options = {
        root: null,
        rootMargin: settings.rootMargin,
        threshold: settings.threshold,
    };

    activeSection = null; // Variable to store the active section
    observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                activeSection = entry.target;
            }
        });

        updateActiveNavLink();
    }, options);

    window.addEventListener("load", function () {
        sections.forEach(section => {
            observer.observe(section);
        });
    });
}

function updateActiveSectionByScroll() {
    let maxVisibleRatio = 0;
    let visibleSection = null;

    sections.forEach(section => {
        const rect = section.getBoundingClientRect();
        const visibleRatio = rect.height > 0 ? (rect.height - Math.abs(rect.top)) / rect.height : 0;

        if (visibleRatio > maxVisibleRatio) {
            maxVisibleRatio = visibleRatio;
            visibleSection = section;
        }
    });

    if (visibleSection !== activeSection) {
        activeSection = visibleSection;
        updateActiveNavLink();
    }
}

function updateActiveNavLink() {
    const targetLinkId = activeSection ? activeSection.getAttribute('id') : null;

    navLinks.forEach(navLink => {
        const href = navLink.getAttribute('href');
        const linkId = href.substring(1);

        if (linkId === targetLinkId) {
            navLink.classList.add(settings.activeClass);
        } else {
            navLink.classList.remove(settings.activeClass);
        }
    });
}

// Handle scroll event to update active section when using scroll
window.addEventListener('scroll', () => {
    updateActiveSectionByScroll();
});
