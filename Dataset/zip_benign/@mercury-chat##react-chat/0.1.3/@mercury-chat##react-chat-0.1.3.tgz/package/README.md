# Mercury Chat - React Chat

Welcome To Mercury Chat! This library is used to seamlessly embed Cardano Wallet to Wallet communication into any Cardano Application!

This library supports React / NextJS. We have other libraries that support [Vue3](https://www.npmjs.com/package/@mercury-chat/vue-chat) and [Vue2](https://www.npmjs.com/package/@mercury-chat/vue-chat-previous)

1: Installation:

```
npm install @mercury-chat/react-chat
```

2: Usage:

The aim of Mercury Chat is to be able to embed a chat system into your application as seamlessly as possible (ideally with only 1 line of code).

Import MercuryChat into a component like this:

```
import { MercuryChat } from '@mercury-chat/react-chat';
```

And use it inside a component like this:

```
<MercuryChat />
```

The default MercuryChat implementation has a chat button appear the bottom right of the component (you can place <MercuryChat /> such that the chat bubble appears in the bottom right section of the screen)

3: Optional Parameters

MercuryChat has several optional props that can be used to customize functionality

```
<MercuryChat position={'bottom-right'} hasFullscreen={true} showBackground={true} />
```

-   <b>position</b>: 'bottom-right' | 'standard' - defaults to 'bottom-right'.
    The position prop determines where on the screen the chat bubble will appear. If the position is 'bottom-right' than the chat bubble will appear on the bottom right of the component. If the position is 'standard' the chat bubble can be moved around the component at will.

-   <b>positionValues</b>: { top: number, bottom: number, left: number, right number } - defaults to { top: 0.5, bottom: 0.5, left: 1, right: 1 }
    The positionValues prop determines the absolute position of the chat system when using the 'bottom-right' position prop. This is useful if you have something like Google ReCaptcha in the bottom right of your screen and you want to move the chat system so it is not covering the other content.

-   <b>hasFullscreen</b>: boolean - defaults to true.
    The hasFullscreen prop determines if the chat will open up in a large screen or not. Some dapps may want fullscreen chat, while others such as NFT marketplaces may want to turn hasFullscreen to false to allow users to browse the marketplace while chatting

-   <b>showBackground</b>: boolean - defaults to true.
    The showBackground tag determines if there will be a black transparent background behind the chat that will be clickable to close the chat

-   <b>triggerMercury</b>: number - defaults to 0.
    This allows the client application to control the opening and closing of Mercury with their own system. Pass 1 into this prop to open Mercury, and pass 2 into this prop to close Mercury. Passing 0 into this prop will have control be given over to the standard component button.

-   <b>showNotifications</b>: boolean - defaults to true.
    This prop determines if the user will see a red notification circle in the top left of their image when Mercury is closed.

-   <b>showNotificationNumbers</b>: boolean - defaults to true.
    This prop determines if a user will see numbers in the red notification circle.

-   <b>onOpen</b>: function - defaults to () => void 0.
    A callback function you can use to trigger functionality when Mercury is opened.

-   <b>onClose</b>: function - defaults to () => void 0.
    A callback function you can use to trigger functionality when Mercury is closed.

-   <b>onSignIn</b>: function - defaults to () => void 0.
    A callback function you can use to trigger functionality when a user signs into Mercury.

-   <b>onSignOut</b>: function - defaults to () => void 0.
    A callback function you can use to trigger functionality when a user signs out of Mercury.

-   <b>chatImage</b>: string - defaults to "https://saturn-production.nyc3.digitaloceanspaces.com/Assets/chat-ocean-500.png".
    The URL of a hosted chat image. This image will be the chat image that is seen by your users.

-   <b>hoverChatImage</b>: string - defaults to "https://saturn-production.nyc3.digitaloceanspaces.com/Assets/chat-ocean-900.png".
    The URL of a hosted hover chat image. This image will be the chat image that is seen by your users when they are hovering over the chat image.

-   <b>branding</b>: strings - defaults to ''.
    This is used to adjust the branding inside Mercury and is a payed feature from the [Mercury integration page](https://mercurychat.io/integrate)

-   <b>user</b>: string - defaults to ''.
    This user can be a Cardano address or ADAHandle that will directly go to chat between the logged in user and the user that is set as this prop. Useful for buttons on a profile or sale page where you want users to quickly and directly chat.

-   <b>message</b>: string - defaults to ''.
    This will be a pre-written message that is loaded into the users message bar when they open Mercury. The user does not have to send this message.

-   <b>community</b>: string - defaults to ''.
    This is the community that will open up when the user opens Mercury. Useful for giving users visibility into your community.

-   <b>dappCommunity</b>: string - defaults to ''.
    This is the community that will exist at the top of the community panel while Mercury is open. Useful for giving users visibility into your community.

If you have any feedback or suggestions you can message them in the Town Square on [Mercury Chat](https://mercurychat.io/) or ask on our [Twitter](https://twitter.com/MercuryChatio) or Discord (http://discord.gg/NvVNfQmPjp)

I hope you all enjoy chatting!
