import { WindowE } from "./widget";
/**
 * ウインドウマネージャ。
 *
 * GUIクラスにウインドウの前後関係を管理する機能を提供する。
 */
export declare class WindowManager {
    root: g.E;
    private newWindowEs;
    private windowEsToBeMovedFront;
    constructor(scene: g.Scene);
    /**
     * ウインドウの並べ替え。
     */
    sortWindows(): void;
    /**
     * 新規ウインドウの追加。
     *
     * @param windowE ウインドウ。
     */
    addNewWindow(windowE: WindowE): void;
    /**
     * ウインドウを最前面に移動する。
     *
     * @param windowE ウインドウ。
     */
    moveFront(windowE: WindowE): void;
}
