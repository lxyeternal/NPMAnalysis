import type { AABB, Vec2Like } from "@akashic-extension/collision-js";
/**
 * スクロールバーシェイプ。
 *
 * スクロールバーの形状とスクロール量を操作する機能を提供する。
 */
export interface ScrollBarShape {
    min: number;
    max: number;
    bar: AABB;
    thumb: AABB;
    addScroll: (v: number) => number;
}
/**
 * スクロールされる領域。
 */
export interface ScrollArea {
    /**
     * コンテンツの表示領域。
     */
    visibleArea: AABB;
    /**
     * コンテンツ全体の領域。
     */
    contentBounds: AABB;
}
/**
 * スクロールバーコンストラクタパラメータオブジェクト。
 */
export interface ScrollBarParameterObject {
    avoidsResizeThumb?: boolean;
}
/**
 * スクロールバー。
 *
 * widget にスクロールバーのUIを提供するためのユーティティ。
 *
 * スクロールバーの形状（バーそのものやサムの大きさ、位置など）は widget のレイアウトから
 * 求められる。
 *
 * スクロールバー自体は widget ではない。
 *
 * 縦スクロールのみサポートする。
 */
export declare class ScrollBar {
    /**
     * スクロール位置。
     */
    scroll: number;
    /**
     * 真の時、ウインドウなどのリサイズつまみを避ける。
     */
    avoidsResizeThumb: boolean;
    constructor(param?: ScrollBarParameterObject);
    /**
     * スクロール位置を変更する。
     *
     * @param layout レイアウト。
     * @param v スクロール量。
     */
    scrollBy(scrollArea: ScrollArea, v: number): void;
    scrollTo(scrollArea: ScrollArea, v: number): void;
    scrollToBottom(scrollArea: ScrollArea): void;
    /**
     * スクロール操作が必要なレイアウトか調べる。
     *
     * @param layout レイアウト。
     * @returns スクロール操作が必要な時、真。
     */
    inspectArea(scrollArea: ScrollArea): boolean;
    /**
     * サム(スクロール操作のためのつまみ)と点との交差判定。
     *
     * @param layout スクロールバーの形状を求めるためのレイアウト。
     * @param pos 点の座標。
     * @returns 交差している時、真。
     */
    intersectThumb(scrollArea: ScrollArea, pos: Vec2Like): boolean;
    /**
     * スクロールバー(thumbを含む)と点との交差判定。
     *
     * @param layout スクロールバーの形状を求めるためのレイアウト。
     * @param pos 点の座標。
     * @returns 交差している時、真。
     */
    intersectBar(scrollArea: ScrollArea, pos: Vec2Like): boolean;
    /**
     * スクロールバーの形状の取得。
     *
     * @param layout 形状を決めるためのレイアウト。
     * @returns 形状。
     */
    getShape(scrollArea: ScrollArea): ScrollBarShape | null;
    /**
     * スクロールバーの描画。
     *
     * @param renderer レンダラー。
     * @param layout レイアウト。
     */
    draw(renderer: g.Renderer, scrollArea: ScrollArea): void;
}
