import type { ValueObject } from "../generics";
import type { WidgetEParameterObject } from "./WidgetE";
import { WidgetE } from "./WidgetE";
/**
 * SliderE コンストラクタパラメータオブジェクト。
 */
export interface SliderEParameterObject extends WidgetEParameterObject {
    height: number;
    valueObject: ValueObject;
    key: string;
    min: number;
    max: number;
    font: g.Font;
}
/**
 * Slider E。
 */
export declare class SliderE extends WidgetE {
    valueObject: ValueObject;
    key: string;
    min: number;
    max: number;
    changed: boolean;
    get value(): number;
    set value(v: number);
    private font;
    constructor(param: SliderEParameterObject);
    renderSelf(renderer: g.Renderer, _camera?: g.Camera): boolean;
    postRun(): void;
    private drawSliderBackAndTitle;
    private drawNumber;
    private drawSliderFrameAndCursor;
    private handlePointDown;
    private handlePointMove;
}
