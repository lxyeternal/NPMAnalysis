import type { Gui } from "..";
import type { WidgetEParameterObject } from "./WidgetE";
import { WidgetE } from "./WidgetE";
/**
 * HorizonE コンストラクタパラメータオブジェクト。
 */
export interface HorizonEParameterObject extends WidgetEParameterObject {
}
/**
 * Horizon E。
 *
 * 子ウィジェットを水平に配置するウィジェット。
 */
export declare class HorizonE extends WidgetE {
    constructor(param: HorizonEParameterObject);
    place(ui: Gui, addContents: (ui: Gui) => void): void;
    renderSelf(_renderer: g.Renderer, _camera?: g.Camera): boolean;
}
