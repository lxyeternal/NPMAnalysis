import type { Gui } from "..";
import type { WidgetEParameterObject } from "./WidgetE";
import { WidgetE } from "./WidgetE";
/**
 * スタイル。
 */
interface CollapsingStyle {
    isOpen: boolean;
}
/**
 * CollapsingE コンストラクタパラメータオブジェクト。
 */
export interface CollapsingEParameterObject extends WidgetEParameterObject {
    height: number;
    font: g.Font;
}
/**
 * Collapsing E。
 *
 * 子ウィジェットを折り畳んで表示・非表示を行うウィジェット。
 */
export declare class CollapsingE extends WidgetE {
    isOpen: boolean;
    private font;
    constructor(param: CollapsingEParameterObject);
    place(ui: Gui, addContents: (ui: Gui) => void): void;
    postRun(): void;
    renderSelf(renderer: g.Renderer, _camera?: g.Camera): boolean;
    protected getMemory(): CollapsingStyle;
    private handlePointDown;
}
export {};
