import type { WidgetEParameterObject } from "./WidgetE";
import { WidgetE } from "./WidgetE";
/**
 * ButtonE コンストラクタパラメータオブジェクト。
 */
export interface ButtonEParameterObject extends WidgetEParameterObject {
    height: number;
    font: g.Font;
}
/**
 * Button E。
 */
export declare class ButtonE extends WidgetE {
    isClicked: boolean;
    private pressed;
    private font;
    constructor(param: ButtonEParameterObject);
    postRun(): void;
    renderSelf(renderer: g.Renderer, _camera?: g.Camera): true;
    private handlePointDown;
    private handlePointUp;
    private drawLabel;
}
