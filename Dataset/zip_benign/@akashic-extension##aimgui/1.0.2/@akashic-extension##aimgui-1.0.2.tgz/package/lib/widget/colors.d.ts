/**
 * カラースキーム。
 */
export declare const colors: {
    button: string;
    buttonHighlight: string;
    buttonFrame: string;
    checkBox: string;
    checkMark: string;
    sliderBg: string;
    sliderFrame: string;
    textBoxBg: string;
    scrollBarBg: string;
    scrollBarThumb: string;
    windowBg: string;
    windowFrame: string;
    windowTitleBarBg: string;
    windowResizeThumb: string;
};
