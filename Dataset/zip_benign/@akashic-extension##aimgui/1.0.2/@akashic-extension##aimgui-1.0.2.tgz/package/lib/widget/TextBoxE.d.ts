import type { AABB } from "@akashic-extension/collision-js";
import type { Gui } from "..";
import type { WidgetEParameterObject } from "./WidgetE";
import { WidgetE } from "./WidgetE";
/**
 * テキストボックスメモリ。
 */
export interface TextBoxMemory {
    scroll: number;
}
/**
 * TextBoxE コンストラクタパラメータオブジェクト。
 */
export interface TextBoxEParameterObject extends WidgetEParameterObject {
    text: string;
    font: g.Font;
}
/**
 * TextBox E。
 *
 * テキストを複数行にわたって表示するE。
 *
 * 子に widget を持つことはできない。子 widget を与えた時の動作は未定義。
 */
export declare class TextBoxE extends WidgetE {
    text: string;
    get contentArea(): AABB;
    private font;
    private padding;
    private textBounds;
    private textCursorPosition;
    private prevText;
    private scrollBar;
    private tracking;
    constructor(param: TextBoxEParameterObject);
    place(ui: Gui): void;
    postRun(): void;
    renderSelf(renderer: g.Renderer, _camera?: g.Camera): boolean;
    shouldFindChildrenByPoint(point: g.CommonOffset): boolean;
    scrollToBottom(): void;
    private prepare;
    protected getMemory(): TextBoxMemory;
    protected drawLayout(renderer: g.Renderer): void;
    private getScrollArea;
    private handlePointDown;
    private handlePointMove;
    private handlePointUp;
    private handleThumbMove;
}
