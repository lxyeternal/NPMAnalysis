/**
 * テキストの長さ[px]を制限する。
 *
 * @param font フォント
 * @param text テキスト
 * @param maxWidth 最大幅[ix]。
 * @param replaceStr 代替文字列。長さを制限された文字列の末尾に加えられる。省略時 "..." 。
 * @returns 長さを制限された文字列。
 */
export declare function limitText(font: g.Font, text: string, maxWidth: number, replaceStr?: string): string;
/**
 * テキストを描画する。
 *
 * @param renderer レンダラー。
 * @param font フォント。
 * @param text テキスト。
 * @param x 描画X位置。
 * @param y 描画Y位置。
 * @param maxWidth テキストの最大の長さ[px]。省略時、無制限。
 */
export declare function drawText(renderer: g.Renderer, font: g.Font, text: string, startX: number, startY: number, maxWidth?: number): void;
