import type { AABB, Vec2Like } from "@akashic-extension/collision-js";
import type { WidgetEParameterObject } from "./WidgetE";
import { WidgetE } from "./WidgetE";
/**
 * ウインドウスタイル。
 */
export interface WindowStyle {
    position?: Vec2Like;
    size?: Vec2Like;
    titleBar?: boolean;
    resizable?: boolean;
    scrollable?: boolean;
}
/**
 * WindowE コンストラクタパラメータオブジェクト。
 */
export interface WindowEParameterObject extends WidgetEParameterObject {
    font: g.Font;
    margin?: number;
    showTitleBar?: boolean;
    resizable?: boolean;
    scrollable?: boolean;
}
/**
 * Window E。
 */
export declare class WindowE extends WidgetE {
    resizable: boolean;
    scrollable: boolean;
    /**
     * ウインドウ描画順位。
     *
     * 0から始まり、画面奥に配置されるほど大きくなる整数。
     *
     * 読み取り専用。値はウインドウマネージャによって設定される。
     */
    zOrder: number;
    get cursorPosition(): Vec2Like;
    get contentArea(): AABB;
    /**
     * 子ウィジェット全体の領域。
     */
    bounds: AABB;
    private font;
    private cache;
    private margin;
    private tracking;
    private startWidth;
    private startHeight;
    private scrollBar;
    /**
     * タイトルバーの高さ。サーフェスの大きさに関係するため、整数でなければならない。
     */
    private titleBarHeight;
    constructor(param: WindowEParameterObject);
    postRun(): void;
    renderSelf(renderer: g.Renderer, _camera?: g.Camera): boolean;
    shouldFindChildrenByPoint(point: g.CommonOffset): boolean;
    protected getMemory(): WindowStyle;
    /**
     * 現在のウインドウのスタイルを取得する。
     *
     * @param style 現在のスタイルを反映されるオブジェクト。
     * @returns スタイル。 引数 style と同一のオブジェクト。
     */
    private getStyle;
    private getScrollArea;
    private drawTitleBar;
    private drawResizeThumb;
    private renderChildren;
    private renderCache;
    private getResizeAABB;
    private handlePointDown;
    private handlePointMove;
    private handlePointUp;
    private handleWindowMove;
    private handleThumbMove;
    private handleResize;
}
