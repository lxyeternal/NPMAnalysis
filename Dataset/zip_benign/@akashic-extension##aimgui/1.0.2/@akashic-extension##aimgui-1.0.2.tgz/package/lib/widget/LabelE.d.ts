import type { WidgetEParameterObject } from "./WidgetE";
import { WidgetE } from "./WidgetE";
/**
 * StaticTextE コンストラクタパラメータオブジェクト。
 */
export interface LabelEParameterObject extends WidgetEParameterObject {
    font: g.Font;
}
/**
 * StaticText E。
 */
export declare class LabelE extends WidgetE {
    private font;
    constructor(param: LabelEParameterObject);
    renderSelf(renderer: g.Renderer, _camera?: g.Camera): true;
}
