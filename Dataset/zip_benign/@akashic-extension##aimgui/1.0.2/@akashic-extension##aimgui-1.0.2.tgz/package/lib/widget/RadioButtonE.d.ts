import type { ValueObject } from "../generics";
import type { WidgetEParameterObject } from "./WidgetE";
import { WidgetE } from "./WidgetE";
/**
 * RadioButtonE コンストラクタパラメータオブジェクト。
 */
export interface RadioButtonEParameterObject extends WidgetEParameterObject {
    height: number;
    valueObject: ValueObject;
    key: string;
    buttonValue: unknown;
    font: g.Font;
}
/**
 * RadioButton E。
 */
export declare class RadioButtonE extends WidgetE {
    valueObject: ValueObject;
    key: string;
    buttonValue: unknown;
    get checked(): boolean;
    set checked(v: boolean);
    pressed: boolean;
    private font;
    constructor(param: RadioButtonEParameterObject);
    postRun(): void;
    renderSelf(renderer: g.Renderer, _camera?: g.Camera): true;
    private handlePointDown;
    private handlePointUp;
}
