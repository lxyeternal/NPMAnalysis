import type { ExtractPropertyNames, ValueObject } from "../generics";
import type { WidgetEParameterObject } from "./WidgetE";
import { WidgetE } from "./WidgetE";
/**
 * CheckBoxE コンストラクタパラメータオブジェクト。
 */
export interface CheckboxEParameterObject<T extends ValueObject> extends WidgetEParameterObject {
    height: number;
    valueObject: T;
    key: ExtractPropertyNames<T, boolean>;
    font: g.Font;
}
/**
 * CheckBox E。
 */
export declare class CheckboxE extends WidgetE {
    valueObject: ValueObject;
    key: string;
    get checked(): boolean;
    set checked(v: boolean);
    pressed: boolean;
    private font;
    constructor(param: CheckboxEParameterObject<any>);
    postRun(): void;
    renderSelf(renderer: g.Renderer, _camera?: g.Camera): true;
    private handlePointDown;
    private handlePointUp;
}
