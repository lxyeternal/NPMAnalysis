/**
 * ウィジェットの位置・大きさに関する定数。
 */
export declare const sizes: {
    scrollBarW: number;
    scrollBarH: number;
    resizeThumbW: number;
    resizeThumbH: number;
    margin: number;
};
