import type { AABB } from "@akashic-extension/collision-js";
import type { Gui } from "..";
import type { Memory } from "../Memory";
import type { Placer } from "../Placer";
/**
 * WidgetE コンストラクタパラメータオブジェクト。
 */
export interface WidgetEParameterObject extends g.EParameterObject {
    /**
     * タイトル。
     */
    title: string;
    /**
     * グローバルウィジェットID。
     */
    gwid: string;
    /**
     * ウィジェットの状態を保持するためのメモリ。
     */
    memory: Memory;
    /**
     * 望ましいウィジェットの幅。
     */
    desiredWidth?: number;
    /**
     * 望ましいウィジェットの高さ。
     */
    desiredHeight?: number;
    /**
     * ウィジェットの最小の幅。
     */
    minWidth?: number;
    /**
     * ウィジェットの最小の高さ。
     */
    minHeight?: number;
}
/**
 * Widget E。
 *
 * ウィジェット(ボタンやラベルといったGUI要素)の基底クラス。
 */
export declare class WidgetE extends g.E {
    /**
     * null でない時、WidgetEおよびその派生クラスの生成時のローカルフラグをこの値で上書きする。
     *
     */
    static local: boolean | null;
    /**
     * タイトル。
     *
     * タイトルはボタンのラベルやウインドウのタイトルなどに用いられるとともに、
     * ウィジェットのID(WID)としても利用される。
     */
    title: string;
    /**
     * グローバルウィジェットID。
     *
     * グローバルウィジェットIDは Gui インスタンス内で一意の識別子である。
     */
    gwid: string;
    protected desiredWidth?: number;
    protected desiredHeight?: number;
    protected minWidth?: number;
    protected minHeight?: number;
    private memory;
    constructor(param: WidgetEParameterObject);
    /**
     * 後処理。
     *
     * Gui#run() 実行後に呼び出される。
     */
    postRun(): void;
    /**
     * 自身を Gui に配置する。
     *
     * 処理の実体は placeSelf() で実装する。
     *
     * @param ui 配置先の Gui 。
     * @param addContents 自身に子ウィジェットを配置する処理。WidgetE はこれを利用しない。
     */
    place(ui: Gui, addContents?: (ui: Gui) => void): void;
    drawFrame(renderer: g.Renderer, cssColor: string, width?: number, height?: number): void;
    protected placeSelf(placer: Placer, _addContents?: (ui: Gui) => void): void;
    /**
     * このウィジェットインスタンスのフレームを跨ぐ情報の設定。
     *
     * @param memory メモリ。
     */
    protected setMemory(memory: unknown): void;
    /**
     * このウィジェットインスタンスのフレームを跨ぐ情報の取得。
     *
     * @param memory メモリ。
     */
    protected getMemory(): unknown;
    protected drawLayout(_renderer: g.Renderer): void;
    protected drawAABB(renderer: g.Renderer, aabb: AABB, cssColor: string): void;
}
