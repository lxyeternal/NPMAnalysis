import type { Constructor, ExtractPropertyNames, ValueObject } from "./generics";
import type { Memory } from "./Memory";
import { Placer } from "./Placer";
import type { WindowStyle } from "./widget";
import { WidgetE } from "./widget";
/**
 * WindowCreator
 *
 * ウインドウスタイルを設定し、ウインドウを生成する役。
 */
export declare class WindowCreator {
    private create;
    private style;
    constructor(create: (addContents: (ui: Gui) => void, style: WindowStyle) => void);
    /**
     * ウインドウを表示する。
     *
     * @param addContents ウインドウにウィジェットを追加する関数。
     */
    show(addContents: (ui: Gui) => void): void;
    /**
     * タイトルバーの表示・非表示を設定する。
     *
     * @param v 真の時、表示する。
     * @returns this
     */
    titleBar(v: boolean): this;
    /**
     * リサイズの可否を設定する。
     *
     * @param v 真の時、リサイズ可能になる。
     * @returns this
     */
    resizable(v: boolean): this;
    /**
     * スクロールバーの利用可否を設定する。
     *
     * @param v 真の時、スクロールバーを利用可能にする。
     * @returns this
     */
    scrollable(v: boolean): this;
    /**
     * ウインドウの位置を設定する。
     *
     * @param x X座標。
     * @param y Y座標。
     * @returns this
     */
    position(x: number, y: number): this;
    /**
     * ウインドウの大きさを設定する。
     *
     * @param width 横幅[px]。
     * @param height 縦幅[px]。
     * @returns this
     */
    size(width: number, height: number): this;
}
/**
 * GUI。
 */
export declare class Gui {
    /**
     * GUIを描画するシーン。
     *
     * 読み取り専用。
     */
    scene: g.Scene;
    /**
     * GUIで使用されるフォント。
     *
     * 読み取り専用。
     */
    font: g.Font;
    /**
     * ウィジェットの状態を保持するためのメモリ。
     */
    memory: Memory;
    /**
     * 現在のウィジェット。
     *
     * ウィジェットの追加はこのウィジェットに対して行う。
     */
    get currentWidget(): WidgetE | null;
    /**
     * 現在のプレイサー。
     *
     * ウィジェットの追加はこのプレイサーと交渉して位置と場所を決める。
     */
    get currentPlacer(): Placer | null;
    aliveWidgets: WidgetE[];
    private root;
    private coverE;
    private windowManager;
    private modalWindowManager;
    private idStack;
    private widgetStack;
    private placerStack;
    /**
     * コンストラクタ。
     *
     * @param scene シーン。
     * @param root ウインドウを接続する E 。画面の原点（左上隅）に配置する。
     * @param font ウィジェットの利用するフォント。
     * @param memory ウィジェットの状態を保存するメモリ。
     */
    constructor(scene: g.Scene, root: g.E, font: g.Font, memory: Memory);
    /**
     * ウィジェット ID をスタックにプッシュする。
     *
     * 通常、ウィジェットのタイトルをウィジェット ID に用いる。
     *
     * @param wid ウィジェット ID 。
     */
    pushWid(wid: number | string): void;
    /**
     * ウィジェット ID をスタックからポップする。
     */
    popWid(): void;
    /**
     * ウィジェットタイトル(ID)からグローバルウィジェット ID を得る。
     *
     * @param title ウィジェットのタイトル。
     * @returns グローバルウィジェット ID 。
     */
    titleToGwid(title: string): string;
    /**
     * グローバルウィジェットIDとウィジェットの型に一致するウィジェットを返す。
     *
     * @param gwid グローバルウィジェット ID 。
     * @param ctor ウィジェットのコンストラクタ。
     * @returns ウィジェット。見つからなかった時 null 。
     */
    findWidgetByGwidAndType<T extends WidgetE>(gwid: string, ctor: Constructor<T>): T | null;
    /**
     * run() 実行前に実行するメソッド。
     */
    preRun(): void;
    /**
     * run() 実行後に実行するメソッド。
     */
    postRun(): void;
    /**
     * ウインドウを準備する。
     *
     * @param title ウインドウのタイトル。
     * @param addContents ウインドウにウィジェットを配置する関数。
     * @returns ウインドウクリエータ。これに対して show() を呼ぶことでウインドウが表示される。
     */
    window(title: string): WindowCreator;
    /**
     * モーダルウインドウを準備する。
     *
     * @param title モーダルウインドウのタイトル。
     * @param addContents モーダルウインドウにウィジェットを配置する関数。
     * @returns ウインドウクリエータ。これに対して show() を呼ぶことでウインドウが表示される。
     */
    modalWindow(title: string): WindowCreator;
    /**
     * 現在の親ウィジェットにウィジェットを配置する。
     *
     * @param widgetE ウィジェット。
     */
    attach(widgetE: WidgetE): void;
    /**
     * ウィジェットの取得。
     *
     * @param title ウィジェットのタイトル。
     * @returns ウィジェット。
     */
    getWidget(title: string): WidgetE | null;
    /**
     * ウィジェットをスタックにプッシュする。
     *
     * プッシュされたウィジェットは、以降アタッチされるウィジェットの親になる。
     *
     * @param widgetE プッシュされるウィジェット。
     */
    pushWidget(widgetE: WidgetE): void;
    /**
     * ウィジェットをスタックからポップする。
     *
     * @returns ポップされたウィジェット。
     */
    popWidget(): WidgetE | undefined;
    /**
     * プレイサーをスタックにプッシュする。
     *
     * @param placer プレイサー。
     */
    pushPlacer(placer: Placer): void;
    /**
     * プレイサーをスタックからポップする。
     *
     * @returns ポップされたプレイサー。
     */
    popPlacer(): Placer | undefined;
    /**
     * ファクトリでウィジェットを生成し配置する。
     *
     * @param factory ウィジェット生成するファクトリ。
     * @returns ウィジェットが操作された時、真。
     */
    add(factory: (ui: Gui) => boolean): boolean;
    /**
     * ラベルを配置する。
     *
     * @param title タイトル。
     */
    label(title: string): void;
    /**
     * マージンを配置する。
     *
     * 何も描画しないウィジェットを配置します。
     *
     * @param title マージンのタイトル。
     */
    margin(title: string): void;
    /**
     * ボタンを配置する。
     *
     * @param title のタイトル。
     * @returns ボタンが押下された時、真。
     */
    button(title: string): boolean;
    /**
     * チェックボックスを配置する。
     *
     * @param title チェックボックスのタイトル。
     * @param valueObject チェックボックスのオン・オフの真偽値を持つオブジェクト。
     * @param key チェックボックスのオン・オフの真偽値のプロパティ名。
     * @returns チェックボックスが押下された時、真。
     */
    checkbox<T extends ValueObject>(title: string, valueObject: T, key: ExtractPropertyNames<T, boolean>): boolean;
    /**
     * ラジオボタンを配置する。
     *
     * @param title ラジオボタンのタイトル。
     * @param valueObject ラジオボタンのオン・オフの真偽値を持つオブジェクト。
     * @param key ラジオボタンのオン・オフの真偽値のプロパティ名。
     * @param buttonValue ラジオボタンがオンの時 valueObject に設定される値。
     * @returns ラジオボタンが押下された時、真。
     */
    radioButton<T extends ValueObject, U>(title: string, valueObject: T, key: ExtractPropertyNames<T, U>, buttonValue: U): boolean;
    /**
     * スライダーを配置する。
     *
     * @param title
     * @param valueObject スライダーの値を持つオブジェクト。
     * @param key スライダーのオン・オフの値のプロパティ名。
     * @param min 最小値。
     * @param max 最大値。
     * @returns スライダーによって値が変更された時、真。
     */
    slider<T extends ValueObject>(title: string, valueObject: T, key: ExtractPropertyNames<T, number>, min: number, max: number): boolean;
    /**
     * 折りたたみを配置する。
     *
     * @param title 折りたたみのタイトル。
     * @param addContents 折りたたみにウィジェットを配置する関数。
     * @returns 折りたたみを開閉した時、真。
     */
    collapsing(title: string, addContents: (ui: Gui) => void): boolean;
    /**
     * テキストボックスを配置する。
     *
     * @param title テキストボックスのタイトル。
     * @param height 高さ。
     * @param text テキストボックスに表示する文字列。
     */
    textBox(title: string, height: number, text: string): void;
    /**
     * 水平配置を開始する。
     *
     * @param title 水平配置のタイトル
     * @param addContents 水平に配置されるウィジェットを配置する関数。
     */
    horizontal(title: string, addContents: (ui: Gui) => void): void;
    private setupLayer;
}
