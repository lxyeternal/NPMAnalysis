var color = new RGB('rgba(255, 242, 233, 1)');

console.log(color.toString());

color = temperature(color, 5000);

console.log(color);

color = color.toRGBA();

console.log(color.toString());