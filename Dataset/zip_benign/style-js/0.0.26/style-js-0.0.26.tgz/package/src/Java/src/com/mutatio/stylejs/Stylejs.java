package com.mutatio.stylejs;

import java.io.File;
import java.io.IOException;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.ScriptableObject;
import org.apache.commons.io.FileUtils;

public class Stylejs {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String TypeJS, UtilJS, StyleJS;

		try {
			// Style.js JavaScript library & dependencies
			TypeJS = FileUtils.readFileToString(new File(
					"/projects/Mutatio/Type.js/src/Type.js"));
			UtilJS = FileUtils.readFileToString(new File(
					"/projects/Mutatio/Util.js/src/Util.js"));
			StyleJS = FileUtils.readFileToString(new File(
					"/projects/Mutatio/Style.js/src/Style.js"));

			// JavaScript context
			Context context = Context.enter();

			try {
				ScriptableObject scope = context.initStandardObjects();
				Object out = Context.javaToJS(System.out, scope);

				ScriptableObject.putProperty(scope, "out", out);
				context.evaluateString(scope, TypeJS, "<1>", 1, null);
				context.evaluateString(scope, UtilJS, "<2>", 1, null);
				context.evaluateString(scope, StyleJS, "<3>", 1, null);
				context.evaluateString(scope,
						"new Style({body: {color: Hex.random()}}); out.println(toCSS());", "<4>", 1,
						null);
			} finally {
				Context.exit();
			}
		} catch (IOException e) {
			System.err.println("Unable to read one or more required files.");
		}
	}

}