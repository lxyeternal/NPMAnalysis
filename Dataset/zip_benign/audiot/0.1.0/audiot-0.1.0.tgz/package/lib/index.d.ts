export interface Section {
    file: string;
    start?: number;
    speed?: number;
}
export type Timeline = Section[];
export declare const compile: (timeline: Timeline, output: string, { ffmpegPath, overwrite, normalizeVolume }?: {
    ffmpegPath?: string;
    overwrite?: boolean;
    normalizeVolume?: boolean;
}) => Promise<unknown>;
