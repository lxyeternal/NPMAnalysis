import Konva from 'konva';
import Konvalabel from './types';
/**
 * 已知等腰三角形的底边长度、底边和腰的夹角，求顶点到底边的高。
 *
 * @param {number} baseLength 底边长度
 * @param {number} angle 夹角（角度制）
 * @returns {number} 顶点到底边的高
 */
export declare function calculateHeightFromBase(baseLength: number, angle: number): number;
export declare const getRelativePointerPosition: (node: any) => any;
export declare function getStageAbsoluteDimensions(stage: Konva.Stage): Konvalabel.XYWH;
export declare function fitBBoxToScaledStage(box: Konvalabel.XYWH, stage: Konvalabel.XYWH): {
    x: number;
    y: number;
    width: number;
    height: number;
};
export declare function getBoundingBoxAfterChanges(rect: Konvalabel.XYWH, shiftPoint: {
    x: number;
    y: number;
}, radRotation?: number): Konvalabel.XYWH;
export declare function getBoundingBoxAfterTransform(rect: Konvalabel.XYWH, transform: Konva.Transform): Konvalabel.XYWH;
/**
 * 创建图片缓存
 * @param {string} url 图片地址
 */
export declare function imageOnLoad(url: string): Promise<HTMLImageElement>;
export declare const toRgba: (color: string, alpha?: number) => string;
export declare function debounce(fn: any, delay: any): (...args: any[]) => void;
