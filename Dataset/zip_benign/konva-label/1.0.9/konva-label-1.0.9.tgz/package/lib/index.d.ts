import Konva from 'konva';
import Konvalabel from './types';
import type { Shape, ShapeConfig } from 'konva/lib/Shape';
import type { Stage } from 'konva/lib/Stage';
export default class KonvaLabel {
    stage: Konva.Stage;
    layer: Konva.Layer;
    stageContainer: string;
    image: HTMLImageElement | null;
    zoomRatio: number;
    imageNode: Konva.Image | null;
    bboxes: Konvalabel.BboxesItem[];
    labelConfig: Konvalabel.LabelConfig;
    private currentShape;
    private labelInfo;
    private transformer;
    private onChange;
    constructor({ el, onChange, labelConfig }: Konvalabel.KonvaConstructor);
    private bindEvents;
    /**
     * 限制画布活动范围不超过图片
     */
    private dragmove;
    /**
     * 鼠标滚轮事件，控制舞台缩放
     */
    private wheel;
    private getStageContainerNode;
    /**
     * 清除layer图层中的所有元素，并还原舞台的缩放和位置
     */
    private destroyChildren;
    private fitStageToContainer;
    private createLabel;
    /**
     * 更新所有标注框和标签的尺寸和位置(窗口尺寸发生变化时调用)
     */
    private updateLable;
    /**
     * 鼠标左键按下事件(开始绘制)
     */
    private mousedown;
    /**
     * 鼠标移动事件(绘制中)
     */
    private mousemove;
    /**
     * 鼠标左键抬起(绘制结束)
     */
    private mouseup;
    /**
     * 限制选中标注框的活动范围不超过图片
     * @param {Konva.Rect} rect konva.Rect实列
     */
    private dragBoundFunc;
    /**
     * 限制标注框的变换范围不超过图片
     */
    private constrainSizes;
    /**
     * 更新标注框标签的位置
     * @param {Konva.Rect} rect konva.Rect的实列
     */
    private updateText;
    private emitChange;
    /**
     * # 获取缩放比
     */
    getZoomRatio(): number;
    /**
     * # 加载图片
     */
    loadImage(img: HTMLImageElement | string, bboxes?: Konvalabel.BboxesItem[]): Promise<string>;
    /**
     * 获取所有文本
     */
    getAllText(): Array<Konva.Text>;
    /**
     * 获取所有标注框
     */
    getAllRect(): Array<Konva.Rect>;
    getTransformerNodes(): Array<Konva.Rect>;
    cancelDraw(): void;
    draw(labelInfo: Konvalabel.LabelInfo): void;
    /**
     * 删除选中的标注
     */
    deleteSelected(): void;
    /**
     * 通过id删除标注
     * @param {string} id 标注id
     */
    deleteById(id: string): void;
    /**
     * 选中标注框进行编辑
     * @param {Konva.Rect} rect konva.Rect的实列
     */
    createTransformer(rect: Shape<ShapeConfig> | Stage): void;
    /**
     * 修改选中透明度
     * @param {number} opacity 透明度
     */
    updateSelectOpacity(number: number): void;
    /**
     * 更新填充透明度
     */
    updateFillOpacity(number: number): void;
    /**
     * 更新标注框的名称
     */
    updateLabelName(id: string | number, data: Konvalabel.LabelInfo): void;
    /**
     * 重置缩放工具
     */
    resetZoom(): void;
    /**
     * # 绘制已经存在的标注框
     * @param {Array} data 标注框的原始数据
     */
    drawBox(data: Konvalabel.BboxesItem): void;
    destroy(): void;
}
