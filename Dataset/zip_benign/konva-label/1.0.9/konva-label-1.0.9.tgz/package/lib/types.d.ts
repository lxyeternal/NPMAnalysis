import Konva from 'konva';
declare namespace Konvalabel {
    interface LabelInfo {
        label?: string;
        color?: string;
        [key: string]: any;
    }
    interface BboxesItem {
        id?: number | string;
        label: string;
        box: BoxType;
        [key: string]: any;
    }
    type BoxType = [number, number, number, number];
    interface KonvaConstructor {
        el: string;
        onChange?: OnChange;
        labelConfig?: LabelConfig;
    }
    interface LabelConfig {
        color?: string;
        fillOpacity?: number;
        selectOpacity?: number;
        strokeWidth?: number;
        fontSize?: number;
        textGap?: number;
    }
    interface EmitData {
        id: number | string;
        label: string;
        box: BoxType;
        rect: Konva.Rect;
        text: Konva.Text;
        [key: string]: any;
    }
    type OnChange = (ChangeParams: any) => void | null;
    interface ChangeParams {
        type: ChangeType;
        data: EmitData[];
    }
    type ChangeType = 'update' | 'add' | 'delete' | 'init';
    interface XYWH {
        width: number;
        height: number;
        x: number;
        y: number;
    }
}
export default Konvalabel;
