import Konvalabel from './types';
export declare const LABEL_CONFIG: Konvalabel.LabelConfig;
