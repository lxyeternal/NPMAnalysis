# Quotely

A simple and easy to use quotes package that provides you with over `120 thousand` different quotes from various authors ranked by popularity and divided into `32` different categories and `910` tags listed in the [stats file](https://github.com/Crysthamus/Quotely/blob/main/assets/stats.txt).<br>
[![MIT License](https://img.shields.io/badge/License-MIT-green.svg)](https://choosealicense.com/licenses/mit/)

## Installation

Quotely can be installed via npm

```bash
npm install quotely
```

## Usage/Examples

The following code returns a quote(string) between 50-200 characters long by Oscar Wilde.

```typescript
import { getRandomQuote } from "quotely";
getRandomQuote({
  minLength: 50,
  maxLength: 200,
  minRank: 1,
  maxRank: 3,
  author: "Oscar Wilde",
  tags: ["Honesty"],
  categories: ["inspiration"],
});
```

All the parameters are optional and running:

```
getRandomQuote({})
```

returns a random quote from the json file.
