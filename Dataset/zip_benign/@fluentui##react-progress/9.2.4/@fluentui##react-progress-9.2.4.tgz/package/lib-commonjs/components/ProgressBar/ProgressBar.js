"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ProgressBar", {
    enumerable: true,
    get: function() {
        return ProgressBar;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _react = /*#__PURE__*/ _interop_require_wildcard._(require("react"));
const _useProgressBar = require("./useProgressBar");
const _renderProgressBar = require("./renderProgressBar");
const _useProgressBarStylesstyles = require("./useProgressBarStyles.styles");
const _reactsharedcontexts = require("@fluentui/react-shared-contexts");
const ProgressBar = /*#__PURE__*/ _react.forwardRef((props, ref)=>{
    const state = (0, _useProgressBar.useProgressBar_unstable)(props, ref);
    (0, _useProgressBarStylesstyles.useProgressBarStyles_unstable)(state);
    (0, _reactsharedcontexts.useCustomStyleHook_unstable)('useProgressBarStyles_unstable')(state);
    return (0, _renderProgressBar.renderProgressBar_unstable)(state);
});
ProgressBar.displayName = 'ProgressBar';
