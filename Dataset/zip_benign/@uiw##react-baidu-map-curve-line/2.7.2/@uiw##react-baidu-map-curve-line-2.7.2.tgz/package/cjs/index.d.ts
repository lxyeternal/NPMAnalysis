import React from 'react';
import { OverlayProps } from '@uiw/react-baidu-map-map';
export * from './useCurveLine';
export interface CurveLineProps extends BMapLib.CurveLineOptions, BMapLib.CurveLineEvents, OverlayProps {
    /**
     * 设置弧线的点数组
     */
    path: BMap.Point[];
}
declare const _default: React.ForwardRefExoticComponent<CurveLineProps & React.RefAttributes<CurveLineProps & {
    curveLine?: BMapLib.CurveLine;
}>>;
export default _default;
