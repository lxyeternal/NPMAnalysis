import { CurveLineProps } from '.';
export interface UseCurveLine extends CurveLineProps {
}
export declare function useCurveLine(props?: UseCurveLine): {
    curveLine: BMapLib.CurveLine | undefined;
    setCurveLine: import("react").Dispatch<import("react").SetStateAction<BMapLib.CurveLine | undefined>>;
    BMapLib: typeof BMapLib;
    path: BMap.Point[];
    setPath: import("react").Dispatch<import("react").SetStateAction<BMap.Point[]>>;
};
