"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const chalk_1 = __importDefault(require("chalk"));
const read_config_1 = __importDefault(require("./lib/utils/read-config"));
const review_project_1 = __importDefault(require("./lib/utils/review-project"));
const dependents_to_string_1 = __importDefault(require("./lib/utils/dependents-to-string"));
const namespace_addon_1 = __importDefault(require("./lib/utils/namespace-addon"));
const silent_error_1 = __importDefault(require("silent-error"));
module.exports = {
    name: require('./package').name,
    init() {
        this._super.init && this._super.init.apply(this, arguments);
        this.addonGuardConfig = read_config_1.default(this.project);
    },
    included() {
        this._super.included && this._super.included.apply(this, arguments);
        const config = this.addonGuardConfig;
        if (config.skipBuildChecks) {
            this.ui.writeLine(chalk_1.default.yellow('WARNING: ember-cli-addon-guard is configured to skip all checks during builds. To override this, set `skipBuildChecks: false` in `config/addon-guard.js`.'));
            return;
        }
        // TODO: { browser-runtime: true }
        const namespaceAddons = config.namespaceAddons || [];
        const ignoreAddons = config.ignoreAddons || [];
        const options = {
            ignoreAddons,
            namespaceAddons,
            runtimeOnly: true,
            conflictsOnly: true,
            skipCacheKeyDependencyChecks: config.skipCacheKeyDependencyChecks
        };
        const summary = review_project_1.default(this.project, options);
        const addons = summary.addons;
        const addonNames = Object.keys(addons);
        // Namespace addons if possible (i.e. if there are no other errors or conflicts)
        if (summary.errors.length === 0 && addonNames.length > 0 && namespaceAddons.length > 0) {
            const namesOfAddonsToNamespace = addonNames.filter(name => namespaceAddons.includes(name));
            if (namesOfAddonsToNamespace.length === addonNames.length) {
                this.ui.writeLine(chalk_1.default.yellow(`ATTENTION: ember-cli-addon-guard will namespace the following addons: ${namesOfAddonsToNamespace.join(', ')}`));
                for (let name of namesOfAddonsToNamespace) {
                    const addonSummaries = addons[name];
                    const keys = Object.keys(addonSummaries);
                    this.ui.writeLine(chalk_1.default.yellow(`\n${name} has ${keys.length} different versions.`));
                    for (let key in addonSummaries) {
                        let addonSummary = addonSummaries[key];
                        this.ui.writeLine(chalk_1.default.yellow(`${addonSummary.version} (${key}) - ${addonSummary.instances.length} different instances.`));
                        namespace_addon_1.default(addonSummary);
                    }
                }
                return;
            }
        }
        if (summary.errors.length > 0 || addonNames.length > 0) {
            // TODO: clean up formatting of this message
            let description = `\nATTENTION: ember-cli-addon-guard has prevented your application from building!\n\n`;
            description += `Please correct the following errors:\n\n`;
            if (summary.errors.length > 0) {
                description += summary.errors.join('\n\n') + '\n\n';
            }
            if (addonNames.length > 0) {
                description += `Your application is dependent on multiple versions of the following run-time ${addonNames.length > 1 ? 'addons' : 'addon'}:\n`;
                for (const name in addons) {
                    const addonSummaries = addons[name];
                    description += `\n${name}\n----------------------------------------\n`;
                    description += dependents_to_string_1.default(name, addonSummaries);
                }
            }
            throw new silent_error_1.default(description);
        }
    },
    includedCommands() {
        return {
            'addon-guard': require('./lib/commands/addon-guard'),
        };
    }
};
//# sourceMappingURL=index.js.map