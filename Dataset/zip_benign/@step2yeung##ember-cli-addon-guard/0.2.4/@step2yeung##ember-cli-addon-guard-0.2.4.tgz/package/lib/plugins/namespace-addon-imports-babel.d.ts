export default function buildNamespaceAddonImportsPlugin(): any;
