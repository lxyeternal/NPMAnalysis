export interface NamespaceAddonInTemplatesOptions {
    namespace: string;
    names: string[];
}
export default function buildNamespaceAddonInTemplatesPlugin(options: NamespaceAddonInTemplatesOptions): any;
