/**
 * Checks if an addon has non-empty `app` or `addon` trees to determine if it
 * is a "runtime addon", and thus worth tracking.
 *
 * Note that dot-files (e.g. `.gitignore`) will be ignored when scanning files
 * in these directories.
 */
export default function isRuntimeAddon(addon: any): boolean;
