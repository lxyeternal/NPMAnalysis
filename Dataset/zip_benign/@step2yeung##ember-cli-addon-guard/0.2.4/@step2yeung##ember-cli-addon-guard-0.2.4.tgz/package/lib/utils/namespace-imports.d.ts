/**
 * Add a babel plugin to the parent registry for transforming import statements.
 *
 * Note: "user plugins" are referenced here: https://github.com/babel/ember-cli-babel/blob/03324217d4ec9b783362d943a31916538ca36510/index.js#L292
 */
export declare function namespaceImports(appOrAddon: any, name: string, cacheKey: string): void;
