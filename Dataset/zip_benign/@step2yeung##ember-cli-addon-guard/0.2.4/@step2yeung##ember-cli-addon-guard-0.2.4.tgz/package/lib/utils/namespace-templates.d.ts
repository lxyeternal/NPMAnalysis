import { NamespaceAddonInTemplatesOptions } from '../plugins/namespace-addon-in-templates-babel';
export declare function namespaceTemplates(appOrAddon: any, options: NamespaceAddonInTemplatesOptions): void;
