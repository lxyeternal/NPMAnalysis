import { ProjectSummary } from '../interfaces';
export interface ReviewProjectOptions {
    /**
     * An array of addon names to ignore
     */
    ignoreAddons?: string[];
    /**
     * An array of addon names to namespace (if multiple versions are identified)
     */
    namespaceAddons?: string[];
    /**
     * Only return addons with > 1 version?
     */
    conflictsOnly?: boolean;
    /**
     * Only return runtime addons?
     */
    runtimeOnly?: boolean;
    /**
     * By default, any `calculate-cache-key-for-tree` dependencies in use by this
     * project and its addons will be checked to ensure that they're updated.
     *
     * See https://github.com/ember-cli/calculate-cache-key-for-tree/pull/14
     *
     * Pass `true` to skip this check.
     */
    skipCacheKeyDependencyChecks?: boolean;
}
/**
 * Given a Project instance, traverses the addon inclusion tree to discover all
 * included versions of all addons in the build, producing a structure in the
 * format:
 *
 *  {
 *    "addon-name": {
 *      "addon.version": [
 *        ["project", "immediate-dependent"],
 *        ["project", "path-to", "nested-dependent"]
 *      ]
 *    }
 *  }
 */
export default function reviewProject(project: any, options?: ReviewProjectOptions): ProjectSummary;
