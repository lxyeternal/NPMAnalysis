export declare function cacheKeyDependencyVersion(dependencies: object, basedir: string): string;
export declare function validateCacheKeyDependency(version: string): boolean;
