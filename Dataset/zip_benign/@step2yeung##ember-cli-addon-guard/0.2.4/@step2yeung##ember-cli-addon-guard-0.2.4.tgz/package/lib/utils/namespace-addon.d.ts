import { AddonVersionSummary } from "../interfaces";
/**
 * Discover template resolvable names by walking through folders that
 * contain resolvable modules.
 */
export declare function templateResolvableNames(rootPath: string): string[];
export default function namespaceAddon(addonVersionSummary: AddonVersionSummary): void;
