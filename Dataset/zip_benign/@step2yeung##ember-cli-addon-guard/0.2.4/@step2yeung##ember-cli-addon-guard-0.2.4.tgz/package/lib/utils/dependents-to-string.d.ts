import { Dict, AddonVersionSummary } from '../interfaces';
export declare type Printer = (version: string, cacheKey: string, runtime: boolean) => string;
/**
 * Given an addon name, a hash of dependents by version (as returned by discoverAddonVersions),
 * and optionally a function to determine how the addon itself is printed, returns a string
 * containing a printable version of the structure.
 */
export default function dependentsToString(name: string, instances: Dict<AddonVersionSummary>, printer?: Printer): string;
