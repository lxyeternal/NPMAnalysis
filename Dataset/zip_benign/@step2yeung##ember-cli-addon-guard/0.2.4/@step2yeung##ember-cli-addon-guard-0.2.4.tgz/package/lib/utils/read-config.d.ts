import { AddonGuardConfig } from '../interfaces';
/**
 * Given a Project instance, returns the custom addon-guard config
 * for that project (if any).
 */
export default function (project: any): AddonGuardConfig;
