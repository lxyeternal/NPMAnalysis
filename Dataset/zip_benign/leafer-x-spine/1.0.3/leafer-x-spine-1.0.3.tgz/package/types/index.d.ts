import { UI, LeaferCanvasBase } from '@leafer-ui/core';
import * as spineCanvas from '@esotericsoftware/spine-canvas';

declare class Spine extends UI {
    skeleton: spineCanvas.Skeleton;
    spineScale: number;
    skeletonData: spineCanvas.SkeletonData;
    skeletonRenderer: spineCanvas.SkeletonRenderer;
    animationState: spineCanvas.AnimationState;
    lastFrameTime: number;
    get __tag(): string;
    constructor(props: any);
    initSpine: (canvas: HTMLCanvasElement) => Promise<void>;
    __updateBoxBounds: () => void;
    __draw: (canvas: LeaferCanvasBase) => void;
    render: () => void;
}
declare const loadAsset: ({ baseUrl, skelName, atlasName, }: {
    baseUrl: string;
    skelName: string;
    atlasName: string;
}) => Promise<spineCanvas.SkeletonData>;

export { Spine, loadAsset };
