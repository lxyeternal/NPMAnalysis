import * as ET from 'fp-ts/EitherT';
import { chainEitherK as chainEitherK_, chainOptionK as chainOptionK_, fromEitherK as fromEitherK_, fromOptionK as fromOptionK_, } from 'fp-ts/FromEither';
import { chainFirstIOK as chainFirstIOK_, chainIOK as chainIOK_, fromIOK as fromIOK_ } from 'fp-ts/FromIO';
import { chainFirstReaderK as chainFirstReaderK_, chainReaderK as chainReaderK_, fromReaderK as fromReaderK_, } from 'fp-ts/FromReader';
import { chainFirstTaskK as chainFirstTaskK_, chainTaskK as chainTaskK_, fromTaskK as fromTaskK_, } from 'fp-ts/FromTask';
import * as R from 'fp-ts/Reader';
import * as TE from 'fp-ts/TaskEither';
import { flow, identity } from 'fp-ts/function';
import { pipe } from 'fp-ts/function';
import { chainFirstObservableK as chainFirstObservableK_, chainObservableK as chainObservableK_, fromObservableK as fromObservableK_, } from './FromObservable';
import * as OE from './ObservableEither';
import * as RO from './ReaderObservable';
// -------------------------------------------------------------------------------------
// constructors
// -------------------------------------------------------------------------------------
/**
 * @category constructors
 * @since 0.6.10
 */
export const fromObservableEither = R.of;
/**
 * @category constructors
 * @since 0.6.12
 */
export const right = 
/*#__PURE__*/
flow(OE.right, fromObservableEither);
/**
 * @category constructors
 * @since 0.6.12
 */
export const left = 
/*#__PURE__*/
flow(OE.left, fromObservableEither);
/**
 * @category constructors
 * @since 0.6.10
 */
export const ask = () => OE.right;
/**
 * @category constructors
 * @since 0.6.10
 */
export const asks = f => flow(OE.right, OE.map(f));
/**
 * @category constructors
 * @since 0.6.10
 */
export const fromReader = ma => flow(ma, OE.right);
/**
 * @category constructors
 * @since 0.6.10
 */
export const fromIO = ma => () => OE.rightIO(ma);
/**
 * @category constructors
 * @since 0.6.10
 */
export const fromTask = ma => () => OE.fromTask(ma);
/**
 * @category conversions
 * @since 0.6.12
 */
export const fromTaskEither = RO.fromTask;
/**
 * @category conversions
 * @since 0.6.12
 */
export const fromReaderEither = ma => flow(ma, OE.fromEither);
/**
 * @category constructors
 * @since 0.6.10
 */
export const fromObservable = ma => () => OE.rightObservable(ma);
/**
 * @category constructors
 * @since 0.6.12
 */
export const rightTask = /*#__PURE__*/ flow(TE.rightTask, fromTaskEither);
/**
 * @category constructors
 * @since 0.6.12
 */
export const leftTask = /*#__PURE__*/ flow(TE.leftTask, fromTaskEither);
/**
 * @category constructors
 * @since 0.6.12
 */
export const rightReader = ma => flow(ma, OE.right);
/**
 * @category constructors
 * @since 0.6.12
 */
export const leftReader = me => flow(me, OE.left);
/**
 * @category constructors
 * @since 0.6.12
 */
export const rightReaderObservable = /*#__PURE__*/ ET.rightF(RO.Functor);
/**
 * @category constructors
 * @since 0.6.12
 */
export const leftReaderObservable = /*#__PURE__*/ ET.leftF(RO.Functor);
/**
 * @category constructors
 * @since 0.6.12
 */
export const rightIO = /*#__PURE__*/ flow(TE.rightIO, fromTaskEither);
/**
 * @category constructors
 * @since 0.6.12
 */
export const leftIO = /*#__PURE__*/ flow(TE.leftIO, fromTaskEither);
/**
 * @category lifting
 * @since 0.6.12
 */
export const fromObservableEitherK = (f) => flow(f, fromObservableEither);
/**
 * Less strict version of [`chainObservableEitherK`](#chainobservableeitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export const chainObservableEitherKW = f => chainW(fromObservableEitherK(f));
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainObservableEitherK = chainObservableEitherKW;
/**
 * Less strict version of [`chainFirstObservableEitherK`](#chainfirstobservableeitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstObservableEitherKW = f => chainFirstW(fromObservableEitherK(f));
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstObservableEitherK = chainFirstObservableEitherKW;
/**
 * @category lifting
 * @since 0.6.12
 */
export const fromTaskEitherK = (f) => flow(f, fromTaskEither);
/**
 * Less strict version of [`chainTaskEitherK`](#chaintaskeitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export const chainTaskEitherKW = f => chainW(fromTaskEitherK(f));
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainTaskEitherK = chainTaskEitherKW;
/**
 * Less strict version of [`chainFirstTaskEitherK`](#chainfirsttaskeitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstTaskEitherKW = f => chainFirstW(fromTaskEitherK(f));
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstTaskEitherK = chainFirstTaskEitherKW;
/**
 * @category lifting
 * @since 0.6.12
 */
export const fromReaderEitherK = (f) => flow(f, fromReaderEither);
/**
 * Less strict version of [`chainReaderEitherK`](#chainreadereitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export const chainReaderEitherKW = f => chainW(fromReaderEitherK(f));
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainReaderEitherK = chainReaderEitherKW;
/**
 * Less strict version of [`chainFirstReaderEitherK`](#chainfirstreadereitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstReaderEitherKW = f => chainFirstW(fromReaderEitherK(f));
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstReaderEitherK = chainFirstReaderEitherKW;
// -------------------------------------------------------------------------------------
// combinators
// -------------------------------------------------------------------------------------
/**
 * @category combinators
 * @since 0.6.10
 */
export const local = R.local;
// -------------------------------------------------------------------------------------
// destructors
// -------------------------------------------------------------------------------------
/**
 * @category pattern matching
 * @since 0.6.12
 */
export const match = /*#__PURE__*/ ET.match(RO.Functor);
/**
 * Less strict version of [`match`](#match).
 *
 * The `W` suffix (short for **W**idening) means that the handler return types will be merged.
 *
 * @category pattern matching
 * @since 0.6.12
 */
export const matchW = match;
/**
 * @category pattern matching
 * @since 0.6.12
 */
export const fold = /*#__PURE__*/ ET.matchE(RO.Chain);
/**
 * @category pattern matching
 * @since 0.6.12
 */
export const foldW = fold;
/**
 * @category error handling
 * @since 0.6.12
 */
export const getOrElse = /*#__PURE__*/ ET.getOrElse(RO.Monad);
/**
 * Less strict version of [`getOrElse`](#getorelse).
 *
 * The `W` suffix (short for **W**idening) means that the handler return type will be merged.
 *
 * @category error handling
 * @since 0.6.12
 */
export const getOrElseW = getOrElse;
/**
 * @category error handling
 * @since 0.6.12
 */
export const orElse = /*#__PURE__*/ ET.orElse(RO.Monad);
/**
 * Less strict version of [`orElse`](#orelse).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the return types will be merged.
 *
 * @category error handling
 * @since 0.6.12
 */
export const orElseW = orElse;
// -------------------------------------------------------------------------------------
// type class members
// -------------------------------------------------------------------------------------
/**
 * @category MonadThrow
 * @since 0.6.10
 */
export const throwError = e => () => OE.left(e);
/**
 * `map` can be used to turn functions `(a: A) => B` into functions `(fa: F<A>) => F<B>` whose argument and return types
 * use the type constructor `F` to represent some computational context.
 *
 * @category Functor
 * @since 0.6.10
 */
export const map = f => fa => flow(fa, OE.map(f));
/**
 * Apply a function to an argument under a type constructor.
 *
 * @category Apply
 * @since 0.6.10
 */
export const ap = fa => fab => r => pipe(fab(r), OE.ap(fa(r)));
/**
 * Less strict version of [`ap`](#ap).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @since 0.6.12
 */
export const apW = ap;
/**
 * Combine two effectful actions, keeping only the result of the first.
 *
 * Derivable from `Apply`.
 *
 * @category combinators
 * @since 0.6.10
 */
export const apFirst = fb => flow(map(a => () => a), ap(fb));
/**
 * Combine two effectful actions, keeping only the result of the second.
 *
 * Derivable from `Apply`.
 *
 * @category combinators
 * @since 0.6.10
 */
export const apSecond = (fb) => flow(map(() => (b) => b), ap(fb));
/**
 * @category Applicative
 * @since 0.6.10
 */
export const of = right;
/**
 * @category Bifunctor
 * @since 0.6.10
 */
export const bimap = (f, g) => fea => r => OE.bimap(f, g)(fea(r));
/**
 * @category Bifunctor
 * @since 0.6.10
 */
export const mapLeft = f => fea => r => OE.mapLeft(f)(fea(r));
/**
 * Less strict version of [`chain`](#chain).
 *
 * @category Monad
 * @since 0.6.12
 */
export const chainW = (f) => (ma) => r => pipe(ma(r), OE.chainW(a => f(a)(r)));
/**
 * @category Monad
 * @since 0.6.10
 */
export const chain = chainW;
/**
 * Less strict version of [`flatten`](#flatten).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export const flattenW = /*#__PURE__*/ chainW(identity);
/**
 * Derivable from `Monad`.
 *
 * @category combinators
 * @since 0.6.10
 */
export const flatten = flattenW;
/**
 * Identifies an associative operation on a type constructor. It is similar to `Semigroup`, except that it applies to
 * types of kind `* -> *`.
 *
 * @category error handling
 * @since 0.6.12
 */
export const alt = /*#__PURE__*/ ET.alt(RO.Monad);
/**
 * Less strict version of [`alt`](#alt).
 *
 * The `W` suffix (short for **W**idening) means that the environment, the error and the return types will be merged.
 *
 * @category error handling
 * @since 0.6.12
 */
export const altW = alt;
/**
 * Composes computations in sequence, using the return value of one computation to determine the next computation and
 * keeping only the result of the first.
 *
 * Derivable from `Monad`.
 *
 * @category combinators
 * @since 0.6.10
 */
export const chainFirst = f => chain(a => pipe(f(a), map(() => a)));
/**
 * Less strict version of [`chainFirst`](#chainfirst)
 *
 * @category combinators
 * @since 0.6.12
 */
export const chainFirstW = chainFirst;
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export const filterOrElse = (predicate, onFalse) => chain(a => (predicate(a) ? of(a) : throwError(onFalse(a))));
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.12
 */
export const filterOrElseW = filterOrElse;
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export const fromEither = ma => ma._tag === 'Left' ? throwError(ma.left) : of(ma.right);
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export const fromOption = (onNone) => (ma) => ma._tag === 'None' ? throwError(onNone()) : of(ma.value);
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export const fromPredicate = (predicate, onFalse) => (a) => predicate(a) ? of(a) : throwError(onFalse(a));
// -------------------------------------------------------------------------------------
// instances
// -------------------------------------------------------------------------------------
/* istanbul ignore next */
const map_ = (fa, f) => pipe(fa, map(f));
/* istanbul ignore next */
const ap_ = (fab, fa) => pipe(fab, ap(fa));
/* istanbul ignore next */
const chain_ = (ma, f) => pipe(ma, chain(f));
/* istanbul ignore next */
const alt_ = (fa, that) => pipe(fa, alt(that));
/* istanbul ignore next */
const bimap_ = (fea, f, g) => pipe(fea, bimap(f, g));
/* istanbul ignore next */
const mapLeft_ = (fea, f) => pipe(fea, mapLeft(f));
/**
 * @category instances
 * @since 0.6.10
 */
export const URI = 'ReaderObservableEither';
/**
 * @category instances
 * @since 0.6.12
 */
export const Functor = {
    URI,
    map: map_,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const Apply = {
    URI,
    map: map_,
    ap: ap_,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const Applicative = {
    URI,
    map: map_,
    ap: ap_,
    of,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const Chain = {
    URI,
    map: map_,
    ap: ap_,
    chain: chain_,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const Monad = {
    URI,
    map: map_,
    ap: ap_,
    of,
    chain: chain_,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const Bifunctor = {
    URI,
    bimap: bimap_,
    mapLeft: mapLeft_,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const Alt = {
    URI,
    map: map_,
    alt: alt_,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const MonadIO = {
    URI,
    map: map_,
    ap: ap_,
    of,
    chain: chain_,
    fromIO,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const MonadTask = {
    URI,
    map: map_,
    of,
    ap: ap_,
    chain: chain_,
    fromIO,
    fromTask,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const MonadObservable = {
    URI,
    map: map_,
    of,
    ap: ap_,
    chain: chain_,
    fromIO,
    fromObservable,
    fromTask,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const MonadThrow = {
    URI,
    map: map_,
    of,
    ap: ap_,
    chain: chain_,
    throwError,
};
/**
 * @category instances
 * @since 0.6.10
 * @deprecated
 */
export const readerObservableEither = {
    URI,
    ap: ap_,
    map: map_,
    of,
    chain: chain_,
    fromIO,
    fromObservable,
    fromTask,
    throwError,
    bimap: bimap_,
    mapLeft: mapLeft_,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const FromEither = {
    URI,
    fromEither,
};
/**
 * @category lifting
 * @since 0.6.12
 */
export const fromOptionK = /*#__PURE__*/ fromOptionK_(FromEither);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainOptionK = 
/*#__PURE__*/ chainOptionK_(FromEither, Chain);
/**
 * @category lifting
 * @since 0.6.12
 */
export const fromEitherK = /*#__PURE__*/ fromEitherK_(FromEither);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainEitherK = /*#__PURE__*/ chainEitherK_(FromEither, Chain);
/**
 * Less strict version of [`chainEitherK`](#chaineitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export const chainEitherKW = chainEitherK;
/**
 * Less strict version of [`chainFirstEitherK`](#chainfirsteitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstEitherKW = flow(fromEitherK, chainFirstW);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstEitherK = chainFirstEitherKW;
/**
 * @category instances
 * @since 0.6.12
 */
export const FromIO = {
    URI,
    fromIO,
};
/**
 * @category lifting
 * @since 0.6.12
 */
export const fromIOK = /*#__PURE__*/ fromIOK_(FromIO);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainIOK = /*#__PURE__*/ chainIOK_(FromIO, Chain);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstIOK = /*#__PURE__*/ chainFirstIOK_(FromIO, Chain);
/**
 * @category instances
 * @since 0.6.12
 */
export const FromTask = {
    URI,
    fromIO,
    fromTask,
};
/**
 * @category lifting
 * @since 0.6.12
 */
export const fromTaskK = /*#__PURE__*/ fromTaskK_(FromTask);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainTaskK = /*#__PURE__*/ chainTaskK_(FromTask, Chain);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstTaskK = /*#__PURE__*/ chainFirstTaskK_(FromTask, Chain);
/**
 * @category instances
 * @since 0.6.12
 */
export const FromObservable = {
    URI,
    fromIO,
    fromTask,
    fromObservable,
};
/**
 * @category lifting
 * @since 0.6.12
 */
export const fromObservableK = 
/*#__PURE__*/ fromObservableK_(FromObservable);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainObservableK = 
/*#__PURE__*/ chainObservableK_(FromObservable, Chain);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstObservableK = 
/*#__PURE__*/ chainFirstObservableK_(FromObservable, Chain);
/**
 * @category instances
 * @since 0.6.12
 */
export const FromReader = {
    URI,
    fromReader,
};
/**
 * @category lifting
 * @since 0.6.12
 */
export const fromReaderK = /*#__PURE__*/ fromReaderK_(FromReader);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainReaderK = /*#__PURE__*/ chainReaderK_(FromReader, Chain);
/**
 * Less strict version of [`chainReaderK`](#chainreaderk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export const chainReaderKW = chainReaderK;
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstReaderK = /*#__PURE__*/ chainFirstReaderK_(FromReader, Chain);
/**
 * Less strict version of [`chainFirstReaderK`](#chainfirstreaderk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstReaderKW = chainFirstReaderK;
// -------------------------------------------------------------------------------------
// utils
// -------------------------------------------------------------------------------------
/**
 * @since 0.6.12
 */
export const Do = 
/*#__PURE__*/
of({});
/**
 * @since 0.6.11
 */
export const bindTo = (name) => map(a => ({ [name]: a }));
/**
 * @since 0.6.11
 */
export const bind = (name, f) => chain(a => pipe(f(a), map(b => (Object.assign(Object.assign({}, a), { [name]: b })))));
/**
 * @since 0.6.12
 */
export const bindW = bind;
