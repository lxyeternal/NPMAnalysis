/**
 * Lift a computation from the `Observable` monad
 *
 * @since 0.6.12
 */
import { chainFirst } from 'fp-ts/Chain';
import { flow } from 'fp-ts/function';
export function fromObservableK(F) {
    return f => flow(f, F.fromObservable);
}
export function chainObservableK(F, M) {
    return f => {
        const g = flow(f, F.fromObservable);
        return first => M.chain(first, g);
    };
}
export function chainFirstObservableK(F, M) {
    const chainFirstM = chainFirst(M);
    return f => chainFirstM(flow(f, F.fromObservable));
}
