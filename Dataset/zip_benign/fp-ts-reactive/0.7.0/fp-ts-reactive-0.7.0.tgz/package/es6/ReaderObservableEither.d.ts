/**
 * @since 0.6.10
 */
import type { Alt3 } from 'fp-ts/Alt'
import type { Applicative3 } from 'fp-ts/Applicative'
import type { Apply3 } from 'fp-ts/Apply'
import type { Bifunctor3 } from 'fp-ts/Bifunctor'
import type { Chain3 } from 'fp-ts/Chain'
import type { Either } from 'fp-ts/Either'
import { FromEither3 } from 'fp-ts/FromEither'
import { FromIO3 } from 'fp-ts/FromIO'
import { FromReader3 } from 'fp-ts/FromReader'
import { FromTask3 } from 'fp-ts/FromTask'
import type { Functor3 } from 'fp-ts/Functor'
import type { IO } from 'fp-ts/IO'
import type { Monad3 } from 'fp-ts/Monad'
import type { MonadIO3 } from 'fp-ts/MonadIO'
import type { MonadTask3 } from 'fp-ts/MonadTask'
import type { MonadThrow3 } from 'fp-ts/MonadThrow'
import type { Option } from 'fp-ts/Option'
import * as R from 'fp-ts/Reader'
import type * as RE from 'fp-ts/ReaderEither'
import type { Task } from 'fp-ts/Task'
import * as TE from 'fp-ts/TaskEither'
import { Lazy, Predicate, Refinement } from 'fp-ts/function'
import type { Observable } from 'rxjs'
import { FromObservable3 } from './FromObservable'
import type { MonadObservable3 } from './MonadObservable'
import * as OE from './ObservableEither'
import * as RO from './ReaderObservable'
import ReaderObservable = RO.ReaderObservable
/**
 * @category model
 * @since 0.6.10
 */
export interface ReaderObservableEither<R, E, A> {
    (r: R): OE.ObservableEither<E, A>
}
/**
 * @category constructors
 * @since 0.6.10
 */
export declare const fromObservableEither: <R, E, A>(ma: OE.ObservableEither<E, A>) => ReaderObservableEither<R, E, A>
/**
 * @category constructors
 * @since 0.6.12
 */
export declare const right: <R, E = never, A = never>(a: A) => ReaderObservableEither<R, E, A>
/**
 * @category constructors
 * @since 0.6.12
 */
export declare const left: <R, E = never, A = never>(e: E) => ReaderObservableEither<R, E, A>
/**
 * @category constructors
 * @since 0.6.10
 */
export declare const ask: <R, E>() => ReaderObservableEither<R, E, R>
/**
 * @category constructors
 * @since 0.6.10
 */
export declare const asks: <R, E, A>(f: (r: R) => A) => ReaderObservableEither<R, E, A>
/**
 * @category constructors
 * @since 0.6.10
 */
export declare const fromReader: <R, E, A>(ma: R.Reader<R, A>) => ReaderObservableEither<R, E, A>
/**
 * @category constructors
 * @since 0.6.10
 */
export declare const fromIO: MonadIO3<URI>['fromIO']
/**
 * @category constructors
 * @since 0.6.10
 */
export declare const fromTask: MonadTask3<URI>['fromTask']
/**
 * @category conversions
 * @since 0.6.12
 */
export declare const fromTaskEither: <E, A, R = unknown>(fa: TE.TaskEither<E, A>) => ReaderObservableEither<R, E, A>
/**
 * @category conversions
 * @since 0.6.12
 */
export declare const fromReaderEither: <R, E, A>(fa: RE.ReaderEither<R, E, A>) => ReaderObservableEither<R, E, A>
/**
 * @category constructors
 * @since 0.6.10
 */
export declare const fromObservable: MonadObservable3<URI>['fromObservable']
/**
 * @category constructors
 * @since 0.6.12
 */
export declare const rightTask: <R, E = never, A = never>(ma: Task<A>) => ReaderObservableEither<R, E, A>
/**
 * @category constructors
 * @since 0.6.12
 */
export declare const leftTask: <R, E = never, A = never>(me: Task<E>) => ReaderObservableEither<R, E, A>
/**
 * @category constructors
 * @since 0.6.12
 */
export declare const rightReader: <R, E = never, A = never>(ma: R.Reader<R, A>) => ReaderObservableEither<R, E, A>
/**
 * @category constructors
 * @since 0.6.12
 */
export declare const leftReader: <R, E = never, A = never>(me: R.Reader<R, E>) => ReaderObservableEither<R, E, A>
/**
 * @category constructors
 * @since 0.6.12
 */
export declare const rightReaderObservable: <R, E = never, A = never>(
    ma: RO.ReaderObservable<R, A>
) => ReaderObservableEither<R, E, A>
/**
 * @category constructors
 * @since 0.6.12
 */
export declare const leftReaderObservable: <R, E = never, A = never>(
    me: RO.ReaderObservable<R, E>
) => ReaderObservableEither<R, E, A>
/**
 * @category constructors
 * @since 0.6.12
 */
export declare const rightIO: <R, E = never, A = never>(ma: IO<A>) => ReaderObservableEither<R, E, A>
/**
 * @category constructors
 * @since 0.6.12
 */
export declare const leftIO: <R, E = never, A = never>(me: IO<E>) => ReaderObservableEither<R, E, A>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromObservableEitherK: <E, A extends readonly unknown[], B>(
    f: (...a: A) => OE.ObservableEither<E, B>
) => <R = unknown>(...a: A) => ReaderObservableEither<R, E, B>
/**
 * Less strict version of [`chainObservableEitherK`](#chainobservableeitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainObservableEitherKW: <E2, A, B>(
    f: (a: A) => OE.ObservableEither<E2, B>
) => <R, E1>(ma: ReaderObservableEither<R, E1, A>) => ReaderObservableEither<R, E1 | E2, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainObservableEitherK: <E, A, B>(
    f: (a: A) => OE.ObservableEither<E, B>
) => <R>(ma: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, B>
/**
 * Less strict version of [`chainFirstObservableEitherK`](#chainfirstobservableeitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstObservableEitherKW: <E2, A, B>(
    f: (a: A) => OE.ObservableEither<E2, B>
) => <R, E1>(ma: ReaderObservableEither<R, E1, A>) => ReaderObservableEither<R, E1 | E2, A>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstObservableEitherK: <E, A, B>(
    f: (a: A) => OE.ObservableEither<E, B>
) => <R>(ma: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, A>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromTaskEitherK: <E, A extends readonly unknown[], B>(
    f: (...a: A) => TE.TaskEither<E, B>
) => <R = unknown>(...a: A) => ReaderObservableEither<R, E, B>
/**
 * Less strict version of [`chainTaskEitherK`](#chaintaskeitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainTaskEitherKW: <E2, A, B>(
    f: (a: A) => TE.TaskEither<E2, B>
) => <R, E1>(ma: ReaderObservableEither<R, E1, A>) => ReaderObservableEither<R, E1 | E2, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainTaskEitherK: <E, A, B>(
    f: (a: A) => TE.TaskEither<E, B>
) => <R>(ma: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, B>
/**
 * Less strict version of [`chainFirstTaskEitherK`](#chainfirsttaskeitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstTaskEitherKW: <E2, A, B>(
    f: (a: A) => TE.TaskEither<E2, B>
) => <R, E1>(ma: ReaderObservableEither<R, E1, A>) => ReaderObservableEither<R, E1 | E2, A>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstTaskEitherK: <E, A, B>(
    f: (a: A) => TE.TaskEither<E, B>
) => <R>(ma: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, A>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromReaderEitherK: <R, E, A extends readonly unknown[], B>(
    f: (...a: A) => RE.ReaderEither<R, E, B>
) => (...a: A) => ReaderObservableEither<R, E, B>
/**
 * Less strict version of [`chainReaderEitherK`](#chainreadereitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainReaderEitherKW: <R2, E2, A, B>(
    f: (a: A) => RE.ReaderEither<R2, E2, B>
) => <R1, E1>(ma: ReaderObservableEither<R1, E1, A>) => ReaderObservableEither<R1 & R2, E1 | E2, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainReaderEitherK: <R, E, A, B>(
    f: (a: A) => RE.ReaderEither<R, E, B>
) => (ma: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, B>
/**
 * Less strict version of [`chainFirstReaderEitherK`](#chainfirstreadereitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstReaderEitherKW: <R2, E2, A, B>(
    f: (a: A) => RE.ReaderEither<R2, E2, B>
) => <R1, E1>(ma: ReaderObservableEither<R1, E1, A>) => ReaderObservableEither<R1 & R2, E1 | E2, A>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstReaderEitherK: <R, E, A, B>(
    f: (a: A) => RE.ReaderEither<R, E, B>
) => (ma: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, A>
/**
 * @category combinators
 * @since 0.6.10
 */
export declare const local: <R2, R1>(
    f: (d: R2) => R1
) => <E, A>(ma: ReaderObservableEither<R1, E, A>) => ReaderObservableEither<R2, E, A>
/**
 * @category pattern matching
 * @since 0.6.12
 */
export declare const match: <E, B, A>(
    onLeft: (e: E) => B,
    onRight: (a: A) => B
) => <R>(ma: ReaderObservableEither<R, E, A>) => ReaderObservable<R, B>
/**
 * Less strict version of [`match`](#match).
 *
 * The `W` suffix (short for **W**idening) means that the handler return types will be merged.
 *
 * @category pattern matching
 * @since 0.6.12
 */
export declare const matchW: <E, B, A, C>(
    onLeft: (e: E) => B,
    onRight: (a: A) => C
) => <R>(ma: ReaderObservableEither<R, E, A>) => ReaderObservable<R, B | C>
/**
 * @category pattern matching
 * @since 0.6.12
 */
export declare const fold: <R, E, A, B>(
    onLeft: (e: E) => ReaderObservable<R, B>,
    onRight: (a: A) => ReaderObservable<R, B>
) => (ma: ReaderObservableEither<R, E, A>) => ReaderObservable<R, B>
/**
 * @category pattern matching
 * @since 0.6.12
 */
export declare const foldW: <E, R2, B, A, R3, C>(
    onLeft: (e: E) => ReaderObservable<R2, B>,
    onRight: (a: A) => ReaderObservable<R3, C>
) => <R1>(ma: ReaderObservableEither<R1, E, A>) => ReaderObservable<R1 & R2 & R3, B | C>
/**
 * @category error handling
 * @since 0.6.12
 */
export declare const getOrElse: <R, E, A>(
    onLeft: (e: E) => ReaderObservable<R, A>
) => (ma: ReaderObservableEither<R, E, A>) => ReaderObservable<R, A>
/**
 * Less strict version of [`getOrElse`](#getorelse).
 *
 * The `W` suffix (short for **W**idening) means that the handler return type will be merged.
 *
 * @category error handling
 * @since 0.6.12
 */
export declare const getOrElseW: <R2, E, B>(
    onLeft: (e: E) => ReaderObservable<R2, B>
) => <R1, A>(ma: ReaderObservableEither<R1, E, A>) => ReaderObservable<R1 & R2, A | B>
/**
 * @category error handling
 * @since 0.6.12
 */
export declare const orElse: <R, E1, A, E2>(
    onLeft: (e: E1) => ReaderObservableEither<R, E2, A>
) => (ma: ReaderObservableEither<R, E1, A>) => ReaderObservableEither<R, E2, A>
/**
 * Less strict version of [`orElse`](#orelse).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the return types will be merged.
 *
 * @category error handling
 * @since 0.6.12
 */
export declare const orElseW: <E1, R1, E2, B>(
    onLeft: (e: E1) => ReaderObservableEither<R1, E2, B>
) => <R2, A>(ma: ReaderObservableEither<R2, E1, A>) => ReaderObservableEither<R1 & R2, E2, A | B>
/**
 * @category MonadThrow
 * @since 0.6.10
 */
export declare const throwError: MonadThrow3<URI>['throwError']
/**
 * `map` can be used to turn functions `(a: A) => B` into functions `(fa: F<A>) => F<B>` whose argument and return types
 * use the type constructor `F` to represent some computational context.
 *
 * @category Functor
 * @since 0.6.10
 */
export declare const map: <A, B>(
    f: (a: A) => B
) => <R, E>(fa: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, B>
/**
 * Apply a function to an argument under a type constructor.
 *
 * @category Apply
 * @since 0.6.10
 */
export declare const ap: <R, E, A>(
    fa: ReaderObservableEither<R, E, A>
) => <B>(fab: ReaderObservableEither<R, E, (a: A) => B>) => ReaderObservableEither<R, E, B>
/**
 * Less strict version of [`ap`](#ap).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @since 0.6.12
 */
export declare const apW: <R2, E2, A>(
    fa: ReaderObservableEither<R2, E2, A>
) => <R1, E1, B>(fab: ReaderObservableEither<R1, E1, (a: A) => B>) => ReaderObservableEither<R1 & R2, E1 | E2, B>
/**
 * Combine two effectful actions, keeping only the result of the first.
 *
 * Derivable from `Apply`.
 *
 * @category combinators
 * @since 0.6.10
 */
export declare const apFirst: <R, E, B>(
    fb: ReaderObservableEither<R, E, B>
) => <A>(fa: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, A>
/**
 * Combine two effectful actions, keeping only the result of the second.
 *
 * Derivable from `Apply`.
 *
 * @category combinators
 * @since 0.6.10
 */
export declare const apSecond: <R, E, B>(
    fb: ReaderObservableEither<R, E, B>
) => <A>(fa: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, B>
/**
 * @category Applicative
 * @since 0.6.10
 */
export declare const of: Applicative3<URI>['of']
/**
 * @category Bifunctor
 * @since 0.6.10
 */
export declare const bimap: <E, G, A, B>(
    f: (e: E) => G,
    g: (a: A) => B
) => <R>(fa: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, G, B>
/**
 * @category Bifunctor
 * @since 0.6.10
 */
export declare const mapLeft: <E, G>(
    f: (e: E) => G
) => <R, A>(fa: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, G, A>
/**
 * Less strict version of [`chain`](#chain).
 *
 * @category Monad
 * @since 0.6.12
 */
export declare const chainW: <A, R2, E2, B>(
    f: (a: A) => ReaderObservableEither<R2, E2, B>
) => <R1, E1>(ma: ReaderObservableEither<R1, E1, A>) => ReaderObservableEither<R1 & R2, E2 | E1, B>
/**
 * @category Monad
 * @since 0.6.10
 */
export declare const chain: <R, E, A, B>(
    f: (a: A) => ReaderObservableEither<R, E, B>
) => (ma: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, B>
/**
 * Less strict version of [`flatten`](#flatten).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const flattenW: <R1, E1, R2, E2, A>(
    mma: ReaderObservableEither<R1, E1, ReaderObservableEither<R2, E2, A>>
) => ReaderObservableEither<R1 & R2, E1 | E2, A>
/**
 * Derivable from `Monad`.
 *
 * @category combinators
 * @since 0.6.10
 */
export declare const flatten: <R, E, A>(
    mma: ReaderObservableEither<R, E, ReaderObservableEither<R, E, A>>
) => ReaderObservableEither<R, E, A>
/**
 * Identifies an associative operation on a type constructor. It is similar to `Semigroup`, except that it applies to
 * types of kind `* -> *`.
 *
 * @category error handling
 * @since 0.6.12
 */
export declare const alt: <R, E, A>(
    that: () => ReaderObservableEither<R, E, A>
) => (fa: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, A>
/**
 * Less strict version of [`alt`](#alt).
 *
 * The `W` suffix (short for **W**idening) means that the environment, the error and the return types will be merged.
 *
 * @category error handling
 * @since 0.6.12
 */
export declare const altW: <R2, E2, B>(
    that: () => ReaderObservableEither<R2, E2, B>
) => <R1, E1, A>(fa: ReaderObservableEither<R1, E1, A>) => ReaderObservableEither<R1 & R2, E2, A | B>
/**
 * Composes computations in sequence, using the return value of one computation to determine the next computation and
 * keeping only the result of the first.
 *
 * Derivable from `Monad`.
 *
 * @category combinators
 * @since 0.6.10
 */
export declare const chainFirst: <R, E, A, B>(
    f: (a: A) => ReaderObservableEither<R, E, B>
) => (ma: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, A>
/**
 * Less strict version of [`chainFirst`](#chainfirst)
 *
 * @category combinators
 * @since 0.6.12
 */
export declare const chainFirstW: <R2, E2, A, B>(
    f: (a: A) => ReaderObservableEither<R2, E2, B>
) => <R1, E1>(ma: ReaderObservableEither<R1, E1, A>) => ReaderObservableEither<R1 & R2, E1 | E2, A>
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export declare const filterOrElse: {
    <E, A, B extends A>(refinement: Refinement<A, B>, onFalse: (a: A) => E): <R>(
        ma: ReaderObservableEither<R, E, A>
    ) => ReaderObservableEither<R, E, B>
    <E, A>(predicate: Predicate<A>, onFalse: (a: A) => E): <R>(
        ma: ReaderObservableEither<R, E, A>
    ) => ReaderObservableEither<R, E, A>
}
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.12
 */
export declare const filterOrElseW: {
    <E2, E1, A, B extends A>(refinement: Refinement<A, B>, onFalse: (a: A) => E2): <R>(
        ma: ReaderObservableEither<R, E1, A>
    ) => ReaderObservableEither<R, E1 | E2, B>
    <E2, E1, A>(predicate: Predicate<A>, onFalse: (a: A) => E2): <R>(
        ma: ReaderObservableEither<R, E1, A>
    ) => ReaderObservableEither<R, E1 | E2, A>
}
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export declare const fromEither: <R, E, A>(ma: Either<E, A>) => ReaderObservableEither<R, E, A>
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export declare const fromOption: <E>(onNone: () => E) => <R, A>(ma: Option<A>) => ReaderObservableEither<R, E, A>
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export declare const fromPredicate: {
    <E, A, B extends A>(refinement: Refinement<A, B>, onFalse: (a: A) => E): <R>(
        a: A
    ) => ReaderObservableEither<R, E, B>
    <E, A>(predicate: Predicate<A>, onFalse: (a: A) => E): <R>(a: A) => ReaderObservableEither<R, E, A>
}
/**
 * @category instances
 * @since 0.6.10
 */
export declare const URI = 'ReaderObservableEither'
/**
 * @category instances
 * @since 0.6.10
 */
export type URI = typeof URI
declare module 'fp-ts/es6/HKT' {
    interface URItoKind3<R, E, A> {
        readonly [URI]: ReaderObservableEither<R, E, A>
    }
}
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Functor: Functor3<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Apply: Apply3<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Applicative: Applicative3<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Chain: Chain3<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Monad: Monad3<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Bifunctor: Bifunctor3<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Alt: Alt3<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const MonadIO: MonadIO3<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const MonadTask: MonadTask3<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const MonadObservable: MonadObservable3<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const MonadThrow: MonadThrow3<URI>
/**
 * @category instances
 * @since 0.6.10
 * @deprecated
 */
export declare const readerObservableEither: MonadObservable3<URI> & MonadThrow3<URI> & Bifunctor3<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromEither: FromEither3<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromOptionK: <E>(
    onNone: Lazy<E>
) => <A extends ReadonlyArray<unknown>, B>(
    f: (...a: A) => Option<B>
) => <R = unknown>(...a: A) => ReaderObservableEither<R, E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainOptionK: <E>(
    onNone: Lazy<E>
) => <A, B>(f: (a: A) => Option<B>) => <R>(ma: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, B>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromEitherK: <E, A extends ReadonlyArray<unknown>, B>(
    f: (...a: A) => Either<E, B>
) => <R = unknown>(...a: A) => ReaderObservableEither<R, E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainEitherK: <E, A, B>(
    f: (a: A) => Either<E, B>
) => <R>(ma: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, B>
/**
 * Less strict version of [`chainEitherK`](#chaineitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainEitherKW: <E2, A, B>(
    f: (a: A) => Either<E2, B>
) => <R, E1>(ma: ReaderObservableEither<R, E1, A>) => ReaderObservableEither<R, E1 | E2, B>
/**
 * Less strict version of [`chainFirstEitherK`](#chainfirsteitherk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstEitherKW: <A, E2, B>(
    f: (a: A) => Either<E2, B>
) => <R, E1>(ma: ReaderObservableEither<R, E1, A>) => ReaderObservableEither<R, E1 | E2, A>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstEitherK: <A, E, B>(
    f: (a: A) => Either<E, B>
) => <R>(ma: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, A>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromIO: FromIO3<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromIOK: <A extends ReadonlyArray<unknown>, B>(
    f: (...a: A) => IO<B>
) => <R = unknown, E = never>(...a: A) => ReaderObservableEither<R, E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainIOK: <A, B>(
    f: (a: A) => IO<B>
) => <R, E>(first: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstIOK: <A, B>(
    f: (a: A) => IO<B>
) => <R, E>(first: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, A>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromTask: FromTask3<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromTaskK: <A extends ReadonlyArray<unknown>, B>(
    f: (...a: A) => Task<B>
) => <R = unknown, E = never>(...a: A) => ReaderObservableEither<R, E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainTaskK: <A, B>(
    f: (a: A) => Task<B>
) => <R, E>(first: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstTaskK: <A, B>(
    f: (a: A) => Task<B>
) => <R, E>(first: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, A>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromObservable: FromObservable3<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromObservableK: <A extends ReadonlyArray<unknown>, B>(
    f: (...a: A) => Observable<B>
) => <R = unknown, E = never>(...a: A) => ReaderObservableEither<R, E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainObservableK: <A, B>(
    f: (a: A) => Observable<B>
) => <R, E>(first: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstObservableK: <A, B>(
    f: (a: A) => Observable<B>
) => <R, E>(first: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, A>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromReader: FromReader3<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromReaderK: <A extends ReadonlyArray<unknown>, R, B>(
    f: (...a: A) => R.Reader<R, B>
) => <E = never>(...a: A) => ReaderObservableEither<R, E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainReaderK: <A, R, B>(
    f: (a: A) => R.Reader<R, B>
) => <E>(ma: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, B>
/**
 * Less strict version of [`chainReaderK`](#chainreaderk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainReaderKW: <A, R1, B>(
    f: (a: A) => R.Reader<R1, B>
) => <R2, E>(ma: ReaderObservableEither<R2, E, A>) => ReaderObservableEither<R1 & R2, E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstReaderK: <A, R, B>(
    f: (a: A) => R.Reader<R, B>
) => <E>(ma: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, A>
/**
 * Less strict version of [`chainFirstReaderK`](#chainfirstreaderk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types and the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstReaderKW: <A, R1, B>(
    f: (a: A) => R.Reader<R1, B>
) => <R2, E>(ma: ReaderObservableEither<R2, E, A>) => ReaderObservableEither<R1 & R2, E, A>
/**
 * @since 0.6.12
 */
export declare const Do: ReaderObservableEither<unknown, never, Record<string, never>>
/**
 * @since 0.6.11
 */
export declare const bindTo: <K extends string, R, E, A>(
    name: K
) => (fa: ReaderObservableEither<R, E, A>) => ReaderObservableEither<R, E, { [P in K]: A }>
/**
 * @since 0.6.11
 */
export declare const bind: <K extends string, R, E, A, B>(
    name: Exclude<K, keyof A>,
    f: (a: A) => ReaderObservableEither<R, E, B>
) => (
    fa: ReaderObservableEither<R, E, A>
) => ReaderObservableEither<R, E, { [P in K | keyof A]: P extends keyof A ? A[P] : B }>
/**
 * @since 0.6.12
 */
export declare const bindW: <K extends string, R2, E2, A, B>(
    name: Exclude<K, keyof A>,
    f: (a: A) => ReaderObservableEither<R2, E2, B>
) => <R1, E1>(
    fa: ReaderObservableEither<R1, E1, A>
) => ReaderObservableEither<
    R1 & R2,
    E1 | E2,
    {
        [P in keyof A | K]: P extends keyof A ? A[P] : B
    }
>
