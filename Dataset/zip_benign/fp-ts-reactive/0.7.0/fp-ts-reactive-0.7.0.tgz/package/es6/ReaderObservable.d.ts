/**
 * @since 0.6.6
 */
import type { Alt2 } from 'fp-ts/Alt'
import type { Alternative2 } from 'fp-ts/Alternative'
import type { Applicative2 } from 'fp-ts/Applicative'
import type { Apply2 } from 'fp-ts/Apply'
import type { Chain2 } from 'fp-ts/Chain'
import type { Compactable2, Separated } from 'fp-ts/Compactable'
import * as E from 'fp-ts/Either'
import type { Filterable2 } from 'fp-ts/Filterable'
import { FromIO2 } from 'fp-ts/FromIO'
import { FromReader2 } from 'fp-ts/FromReader'
import { FromTask2 } from 'fp-ts/FromTask'
import type { Functor2 } from 'fp-ts/Functor'
import type { IO } from 'fp-ts/IO'
import type { Monad2 } from 'fp-ts/Monad'
import type { MonadIO2 } from 'fp-ts/MonadIO'
import type { MonadTask2 } from 'fp-ts/MonadTask'
import type { Monoid } from 'fp-ts/Monoid'
import * as O from 'fp-ts/Option'
import * as R from 'fp-ts/Reader'
import type { ReaderTask } from 'fp-ts/ReaderTask'
import type { Task } from 'fp-ts/Task'
import { Predicate, Refinement } from 'fp-ts/function'
import type { Observable } from 'rxjs'
import { FromObservable2 } from './FromObservable'
import type { MonadObservable2 } from './MonadObservable'
/**
 * @category model
 * @since 0.6.6
 */
export interface ReaderObservable<R, A> {
    (r: R): Observable<A>
}
/**
 * @category constructors
 * @since 0.6.6
 */
export declare const fromObservable: MonadObservable2<URI>['fromObservable']
/**
 * @category constructors
 * @since 0.6.6
 */
export declare const fromReader: <R, A = never>(ma: R.Reader<R, A>) => ReaderObservable<R, A>
/**
 * @category constructors
 * @since 0.6.6
 */
export declare const fromOption: <R, A>(o: O.Option<A>) => ReaderObservable<R, A>
/**
 * @category constructors
 * @since 0.6.6
 */
export declare const fromIO: MonadIO2<URI>['fromIO']
/**
 * @category constructors
 * @since 0.6.6
 */
export declare const fromTask: MonadTask2<URI>['fromTask']
/**
 * @category constructors
 * @since 0.6.9
 */
export declare const fromReaderTask: <R, A>(ma: ReaderTask<R, A>) => ReaderObservable<R, A>
/**
 * @category constructors
 * @since 0.6.6
 */
export declare const ask: <R>() => ReaderObservable<R, R>
/**
 * @category constructors
 * @since 0.6.6
 */
export declare const asks: <R, A = never>(f: (r: R) => A) => ReaderObservable<R, A>
/**
 * @category combinators
 * @since 0.6.6
 */
export declare const local: <R2, R1>(f: (f: R2) => R1) => <A>(ma: ReaderObservable<R1, A>) => ReaderObservable<R2, A>
/**
 * @category combinators
 * @since 0.6.6
 */
export declare const fromIOK: <A extends unknown[], B>(f: (...a: A) => IO<B>) => <R>(...a: A) => ReaderObservable<R, B>
/**
 * @category combinators
 * @since 0.6.6
 */
export declare const chainIOK: <A, B>(f: (a: A) => IO<B>) => <R>(ma: ReaderObservable<R, A>) => ReaderObservable<R, B>
/**
 * @category combinators
 * @since 0.6.6
 */
export declare const fromObservableK: <A extends unknown[], B>(
    f: (...a: A) => Observable<B>
) => <R>(...a: A) => ReaderObservable<R, B>
/**
 * @category combinators
 * @since 0.6.6
 */
export declare const chainTaskK: <A, B>(
    f: (a: A) => Observable<B>
) => <R>(ma: ReaderObservable<R, A>) => ReaderObservable<R, B>
/**
 * `map` can be used to turn functions `(a: A) => B` into functions `(fa: F<A>) => F<B>` whose argument and return types
 * use the type constructor `F` to represent some computational context.
 *
 * @category Functor
 * @since 0.6.6
 */
export declare const map: <A, B>(f: (a: A) => B) => <R>(fa: ReaderObservable<R, A>) => ReaderObservable<R, B>
/**
 * Apply a function to an argument under a type constructor.
 *
 * @category Apply
 * @since 0.6.6
 */
export declare const ap: <R, A>(
    fa: ReaderObservable<R, A>
) => <B>(fab: ReaderObservable<R, (a: A) => B>) => ReaderObservable<R, B>
/**
 * Less strict version of [`ap`](#ap).
 *
 * The `W` suffix (short for **W**idening) means that the environment types will be merged.
 *
 * @since 0.6.12
 */
export declare const apW: <R2, A>(
    fa: ReaderObservable<R2, A>
) => <R1, B>(fab: ReaderObservable<R1, (a: A) => B>) => ReaderObservable<R1 & R2, B>
/**
 * Combine two effectful actions, keeping only the result of the first.
 *
 * Derivable from `Apply`.
 *
 * @category combinators
 * @since 0.6.6
 */
export declare const apFirst: <R, B>(
    fb: ReaderObservable<R, B>
) => <A>(fa: ReaderObservable<R, A>) => ReaderObservable<R, A>
/**
 * Combine two effectful actions, keeping only the result of the second.
 *
 * Derivable from `Apply`.
 *
 * @category combinators
 * @since 0.6.6
 */
export declare const apSecond: <R, B>(
    fb: ReaderObservable<R, B>
) => <A>(fa: ReaderObservable<R, A>) => ReaderObservable<R, B>
/**
 * @category Applicative
 * @since 0.6.6
 */
export declare const of: <R, A>(a: A) => ReaderObservable<R, A>
/**
 * Less strict version of [`chain`](#chain).
 *
 * @category Monad
 * @since 0.6.12
 */
export declare const chainW: <A, R2, B>(
    f: (a: A) => ReaderObservable<R2, B>
) => <R1>(ma: ReaderObservable<R1, A>) => ReaderObservable<R1 & R2, B>
/**
 * @category Monad
 * @since 0.6.6
 */
export declare const chain: <R, A, B>(
    f: (a: A) => ReaderObservable<R, B>
) => (ma: ReaderObservable<R, A>) => ReaderObservable<R, B>
/**
 * Less strict version of [`flatten`](#flatten).
 *
 * The `W` suffix (short for **W**idening) means that the environment types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const flattenW: <R1, R2, A>(
    mma: ReaderObservable<R1, ReaderObservable<R2, A>>
) => ReaderObservable<R1 & R2, A>
/**
 * Derivable from `Monad`.
 *
 * @category combinators
 * @since 0.6.6
 */
export declare const flatten: <R, A>(mma: ReaderObservable<R, ReaderObservable<R, A>>) => ReaderObservable<R, A>
/**
 * Composes computations in sequence, using the return value of one computation to determine the next computation and
 * keeping only the result of the first.
 *
 * Derivable from `Monad`.
 *
 * @category combinators
 * @since 0.6.6
 */
export declare const chainFirst: <R, A, B>(
    f: (a: A) => ReaderObservable<R, B>
) => (ma: ReaderObservable<R, A>) => ReaderObservable<R, A>
/**
 * Less strict version of [`chainFirst`](#chainfirst)
 *
 * @category combinators
 * @since 0.6.12
 */
export declare const chainFirstW: <R2, A, B>(
    f: (a: A) => ReaderObservable<R2, B>
) => <R1>(ma: ReaderObservable<R1, A>) => ReaderObservable<R1 & R2, A>
/**
 * Identifies an associative operation on a type constructor. It is similar to `Semigroup`, except that it applies to
 * types of kind `* -> *`.
 *
 * @category Alt
 * @since 0.6.7
 */
export declare const alt: <R, A>(
    that: () => ReaderObservable<R, A>
) => (fa: ReaderObservable<R, A>) => ReaderObservable<R, A>
/**
 * @since 0.6.12
 */
export declare const zero: Alternative2<URI>['zero']
/**
 * @category Filterable
 * @since 0.6.7
 */
export declare const filterMap: <A, B>(
    f: (a: A) => O.Option<B>
) => <R>(fa: ReaderObservable<R, A>) => ReaderObservable<R, B>
/**
 * @category Compactable
 * @since 0.6.7
 */
export declare const compact: <R, A>(fa: ReaderObservable<R, O.Option<A>>) => ReaderObservable<R, A>
/**
 * @category Filterable
 * @since 0.6.7
 */
export declare const partitionMap: <A, B, C>(
    f: (a: A) => E.Either<B, C>
) => <R>(fa: ReaderObservable<R, A>) => Separated<ReaderObservable<R, B>, ReaderObservable<R, C>>
/**
 * @category Compactable
 * @since 0.6.7
 */
export declare const separate: <R, A, B>(
    fa: ReaderObservable<R, E.Either<A, B>>
) => Separated<ReaderObservable<R, A>, ReaderObservable<R, B>>
/**
 * @category Filterable
 * @since 0.6.7
 */
export declare const filter: {
    <A, B extends A>(refinement: Refinement<A, B>): <R>(fa: ReaderObservable<R, A>) => ReaderObservable<R, B>
    <A>(predicate: Predicate<A>): <R>(fa: ReaderObservable<R, A>) => ReaderObservable<R, A>
}
/**
 * @category Filterable
 * @since 0.6.7
 */
export declare const partition: {
    <A, B extends A>(refinement: Refinement<A, B>): <R>(
        fa: ReaderObservable<R, A>
    ) => Separated<ReaderObservable<R, A>, ReaderObservable<R, B>>
    <A>(predicate: Predicate<A>): <R>(
        fa: ReaderObservable<R, A>
    ) => Separated<ReaderObservable<R, A>, ReaderObservable<R, A>>
}
/**
 * @category instances
 * @since 0.6.6
 */
export declare const URI = 'ReaderObservable'
/**
 * @category instances
 * @since 0.6.6
 */
export type URI = typeof URI
declare module 'fp-ts/es6/HKT' {
    interface URItoKind2<E, A> {
        readonly [URI]: ReaderObservable<E, A>
    }
}
/**
 * @category instances
 * @since 0.6.6
 */
export declare const getMonoid: <R, A>() => Monoid<ReaderObservable<R, A>>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Functor: Functor2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Apply: Apply2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Applicative: Applicative2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Chain: Chain2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Monad: Monad2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Alt: Alt2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Alternative: Alternative2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Compactable: Compactable2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Filterable: Filterable2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const MonadIO: MonadIO2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const MonadTask: MonadTask2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const MonadObservable: MonadObservable2<URI>
/**
 * @category instances
 * @since 0.6.6
 * @deprecated
 */
export declare const readerObservable: Monad2<URI> & Alternative2<URI> & Filterable2<URI> & MonadObservable2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromIO: FromIO2<URI>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstIOK: <A, B>(
    f: (a: A) => IO<B>
) => <R>(first: ReaderObservable<R, A>) => ReaderObservable<R, A>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromReader: FromReader2<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromReaderK: <A extends ReadonlyArray<unknown>, R, B>(
    f: (...a: A) => R.Reader<R, B>
) => (...a: A) => ReaderObservable<R, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainReaderK: <A, R, B>(
    f: (a: A) => R.Reader<R, B>
) => (ma: ReaderObservable<R, A>) => ReaderObservable<R, B>
/**
 * Less strict version of [`chainReaderK`](#chainreaderk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainReaderKW: <A, R1, B>(
    f: (a: A) => R.Reader<R1, B>
) => <R2>(ma: ReaderObservable<R2, A>) => ReaderObservable<R1 & R2, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstReaderK: <A, R, B>(
    f: (a: A) => R.Reader<R, B>
) => (ma: ReaderObservable<R, A>) => ReaderObservable<R, A>
/**
 * Less strict version of [`chainFirstReaderK`](#chainfirstreaderk).
 *
 * The `W` suffix (short for **W**idening) means that the environment types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstReaderKW: <A, R1, B>(
    f: (a: A) => R.Reader<R1, B>
) => <R2>(ma: ReaderObservable<R2, A>) => ReaderObservable<R1 & R2, A>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromTask: FromTask2<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromTaskK: <A extends ReadonlyArray<unknown>, B>(
    f: (...a: A) => Task<B>
) => <R = unknown>(...a: A) => ReaderObservable<R, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstTaskK: <A, B>(
    f: (a: A) => Task<B>
) => <R>(first: ReaderObservable<R, A>) => ReaderObservable<R, A>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromObservable: FromObservable2<URI>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainObservableK: <A, B>(
    f: (a: A) => Observable<B>
) => <R>(first: ReaderObservable<R, A>) => ReaderObservable<R, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstObservableK: <A, B>(
    f: (a: A) => Observable<B>
) => <R>(first: ReaderObservable<R, A>) => ReaderObservable<R, A>
/**
 * @since 0.6.12
 */
export declare const Do: ReaderObservable<unknown, Record<string, never>>
/**
 * @since 0.6.11
 */
export declare const bindTo: <K extends string, R, A>(
    name: K
) => (fa: ReaderObservable<R, A>) => ReaderObservable<R, { [P in K]: A }>
/**
 * @since 0.6.11
 */
export declare const bind: <K extends string, R, A, B>(
    name: Exclude<K, keyof A>,
    f: (a: A) => ReaderObservable<R, B>
) => (fa: ReaderObservable<R, A>) => ReaderObservable<R, { [P in K | keyof A]: P extends keyof A ? A[P] : B }>
/**
 * @since 0.6.12
 */
export declare const bindW: <K extends string, R2, A, B>(
    name: Exclude<K, keyof A>,
    f: (a: A) => ReaderObservable<R2, B>
) => <R1>(fa: ReaderObservable<R1, A>) => ReaderObservable<
    R1 & R2,
    {
        [P in keyof A | K]: P extends keyof A ? A[P] : B
    }
>
/**
 * @since 0.6.6
 */
export declare const run: <R, A>(ma: ReaderObservable<R, A>, r: R) => Promise<A>
/**
 * @since 0.6.6
 */
export declare const toReaderTask: <R, A>(ma: ReaderObservable<R, A>) => ReaderTask<R, A>
/**
 * @since 0.6.15
 */
export declare const toReaderTaskOption: <R, A>(ma: ReaderObservable<R, A>) => ReaderTask<R, O.Option<A>>
