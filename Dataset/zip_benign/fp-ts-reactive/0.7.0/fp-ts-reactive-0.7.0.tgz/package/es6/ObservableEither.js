import * as E from 'fp-ts/Either';
import * as ET from 'fp-ts/EitherT';
import { chainEitherK as chainEitherK_, chainOptionK as chainOptionK_, fromEitherK as fromEitherK_, fromOptionK as fromOptionK_, } from 'fp-ts/FromEither';
import { chainFirstIOK as chainFirstIOK_, chainIOK as chainIOK_, fromIOK as fromIOK_ } from 'fp-ts/FromIO';
import { chainFirstTaskK as chainFirstTaskK_, chainTaskK as chainTaskK_, fromTaskK as fromTaskK_, } from 'fp-ts/FromTask';
import { flow, identity } from 'fp-ts/function';
import { pipe } from 'fp-ts/function';
import { catchError } from 'rxjs/operators';
import { chainFirstObservableK as chainFirstObservableK_, chainObservableK as chainObservableK_, fromObservableK as fromObservableK_, } from './FromObservable';
import * as R from './Observable';
// -------------------------------------------------------------------------------------
// constructors
// -------------------------------------------------------------------------------------
/**
 * @category constructors
 * @since 0.6.8
 */
export const left = 
/*#__PURE__*/
flow(E.left, R.of);
/**
 * @category constructors
 * @since 0.6.8
 */
export const right = 
/*#__PURE__*/
flow(E.right, R.of);
/**
 * @category constructors
 * @since 0.6.8
 */
export const rightObservable = 
/*#__PURE__*/
R.map(E.right);
/**
 * @category constructors
 * @since 0.6.8
 */
export const leftObservable = 
/*#__PURE__*/
R.map(E.left);
/**
 * @category constructors
 * @since 0.6.8
 */
export const fromIOEither = R.fromIO;
/**
 * @category constructors
 * @since 0.6.8
 */
export const rightIO = 
/*#__PURE__*/
flow(R.fromIO, rightObservable);
/**
 * @category constructors
 * @since 0.6.8
 */
export const leftIO = 
/*#__PURE__*/
flow(R.fromIO, leftObservable);
/**
 * @category constructors
 * @since 0.6.8
 */
export const fromTaskEither = R.fromTask;
/**
 * @category constructors
 * @since 0.6.12
 */
export const fromIO = rightIO;
/**
 * @category constructors
 * @since 0.6.8
 */
export const fromTask = 
/*#__PURE__*/
flow(R.fromTask, rightObservable);
/**
 * @category constructors
 * @since 0.6.12
 */
export const fromObservable = rightObservable;
/**
 * @category constructors
 * @since 0.6.12
 */
export const tryCatch = 
/*#__PURE__*/
flow(R.map(E.right), catchError(flow(E.left, R.of)));
// -------------------------------------------------------------------------------------
// destructors
// -------------------------------------------------------------------------------------
/**
 * @category pattern matching
 * @since 0.6.12
 */
export const match = /*#__PURE__*/ ET.match(R.Functor);
/**
 * @category pattern matching
 * @since 0.6.12
 */
export const matchW = match;
/**
 * @category destructors
 * @since 0.6.8
 */
export const fold = 
/*#__PURE__*/
flow(E.fold, R.chain);
/**
 * @category destructors
 * @since 0.6.12
 */
export const foldW = fold;
/**
 * @category destructors
 * @since 0.6.8
 */
export const getOrElse = (onLeft) => (ma) => pipe(ma, R.chain(E.fold(onLeft, R.of)));
/**
 * @category destructors
 * @since 0.6.12
 */
export const getOrElseW = getOrElse;
// -------------------------------------------------------------------------------------
// combinators
// -------------------------------------------------------------------------------------
/**
 * @category combinators
 * @since 0.6.8
 */
export const orElse = f => R.chain(E.fold(f, right));
/**
 * @category combinators
 * @since 0.6.12
 */
export const orElseW = orElse;
/**
 * @category combinators
 * @since 0.6.8
 */
export const swap = 
/*#__PURE__*/
R.map(E.swap);
// -------------------------------------------------------------------------------------
// type class members
// -------------------------------------------------------------------------------------
/**
 * `map` can be used to turn functions `(a: A) => B` into functions `(fa: F<A>) => F<B>` whose argument and return types
 * use the type constructor `F` to represent some computational context.
 *
 * @category Functor
 * @since 0.6.8
 */
export const map = f => R.map(E.map(f));
/**
 * Apply a function to an argument under a type constructor.
 *
 * @category Apply
 * @since 0.6.0
 */
export const ap = (fa) => flow(R.map(gab => (ga) => E.ap(ga)(gab)), R.ap(fa));
/**
 * Less strict version of [`ap`](#ap).
 *
 * The `W` suffix (short for **W**idening) means that the error types will be merged.
 *
 * @since 0.6.12
 */
export const apW = ap;
/**
 * Combine two effectful actions, keeping only the result of the first.
 *
 * Derivable from `Apply`.
 *
 * @category combinators
 * @since 0.6.8
 */
export const apFirst = fb => flow(map(a => () => a), ap(fb));
/**
 * Combine two effectful actions, keeping only the result of the second.
 *
 * Derivable from `Apply`.
 *
 * @category combinators
 * @since 0.6.8
 */
export const apSecond = (fb) => flow(map(() => (b) => b), ap(fb));
/**
 * Identifies an associative operation on a type constructor. It is similar to `Semigroup`, except that it applies to
 * types of kind `* -> *`.
 *
 * @category Alt
 * @since 0.6.8
 */
export const alt = (that) => R.chain(E.fold(that, right));
/**
 * Less strict version of [`alt`](#alt).
 *
 * The `W` suffix (short for **W**idening) means that the error and the return types will be merged.
 *
 * @category error handling
 * @since 0.6.8
 */
export const altW = alt;
/**
 * @category Bifunctor
 * @since 0.6.8
 */
export const bimap = 
/*#__PURE__*/
flow(E.bimap, R.map);
/**
 * @category Bifunctor
 * @since 0.6.8
 */
export const mapLeft = f => R.map(E.mapLeft(f));
/**
 * Less strict version of [`chain`](#chain).
 *
 * @category Monad
 * @since 0.6.12
 */
export const chainW = (f) => (ma) => pipe(ma, R.chain(E.fold(a => left(a), f)));
/**
 * @category Monad
 * @since 0.6.8
 */
export const chain = chainW;
/**
 * Less strict version of [`flatten`](#flatten).
 *
 * The `W` suffix (short for **W**idening) means that the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export const flattenW = 
/*#__PURE__*/ chainW(identity);
/**
 * Derivable from `Monad`.
 *
 * @category combinators
 * @since 0.6.0
 */
export const flatten = flattenW;
/**
 * Composes computations in sequence, using the return value of one computation to determine the next computation and
 * keeping only the result of the first.
 *
 * Derivable from `Monad`.
 *
 * @category combinators
 * @since 0.6.8
 */
export const chainFirst = f => chain(a => pipe(f(a), map(() => a)));
/**
 * Less strict version of [`chainFirst`](#chainfirst)
 *
 * @category combinators
 * @since 0.6.12
 */
export const chainFirstW = chainFirst;
/**
 * @since 0.6.12
 */
export const of = right;
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export const filterOrElse = (predicate, onFalse) => chain(a => (predicate(a) ? of(a) : throwError(onFalse(a))));
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.12
 */
export const filterOrElseW = filterOrElse;
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export const fromEither = ma => ma._tag === 'Left' ? throwError(ma.left) : of(ma.right);
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export const fromOption = (onNone) => (ma) => ma._tag === 'None' ? throwError(onNone()) : of(ma.value);
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export const fromPredicate = (predicate, onFalse) => (a) => predicate(a) ? of(a) : throwError(onFalse(a));
/**
 * @category MonadThrow
 * @since 0.6.12
 */
export const throwError = left;
// -------------------------------------------------------------------------------------
// instances
// -------------------------------------------------------------------------------------
/* istanbul ignore next */
const map_ = (fa, f) => pipe(fa, map(f));
/* istanbul ignore next */
const ap_ = (fab, fa) => pipe(fab, ap(fa));
/* istanbul ignore next */
const chain_ = (ma, f) => pipe(ma, chain(f));
/* istanbul ignore next */
const bimap_ = (fea, f, g) => pipe(fea, bimap(f, g));
/* istanbul ignore next */
const mapLeft_ = (fea, f) => pipe(fea, mapLeft(f));
/* istanbul ignore next */
const alt_ = (fx, fy) => pipe(fx, alt(fy));
/**
 * @category instances
 * @since 0.6.8
 */
export const URI = 'ObservableEither';
/**
 * @category instances
 * @since 0.6.12
 */
export const Functor = {
    URI,
    map: map_,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const Apply = {
    URI,
    map: map_,
    ap: ap_,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const Applicative = {
    URI,
    map: map_,
    ap: ap_,
    of,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const Chain = {
    URI,
    map: map_,
    ap: ap_,
    chain: chain_,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const Monad = {
    URI,
    map: map_,
    ap: ap_,
    of,
    chain: chain_,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const Bifunctor = {
    URI,
    bimap: bimap_,
    mapLeft: mapLeft_,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const Alt = {
    URI,
    map: map_,
    alt: alt_,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const MonadIO = {
    URI,
    map: map_,
    ap: ap_,
    of,
    chain: chain_,
    fromIO,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const MonadTask = {
    URI,
    map: map_,
    ap: ap_,
    of,
    chain: chain_,
    fromIO,
    fromTask,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const MonadObservable = {
    URI,
    map: map_,
    ap: ap_,
    of,
    chain: chain_,
    fromIO,
    fromTask,
    fromObservable,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const MonadThrow = {
    URI,
    map: map_,
    ap: ap_,
    of,
    chain: chain_,
    throwError,
};
/**
 * @category instances
 * @deprecated
 * @since 0.6.8
 */
export const observableEither = {
    URI,
    map: map_,
    of,
    ap: ap_,
    chain: chain_,
    bimap: bimap_,
    mapLeft: mapLeft_,
    alt: alt_,
    fromIO: rightIO,
    fromTask,
    fromObservable,
    throwError,
};
/**
 * @category instances
 * @since 0.6.12
 */
export const FromEither = {
    URI,
    fromEither,
};
/**
 * @category lifting
 * @since 0.6.12
 */
export const fromEitherK = /*#__PURE__*/ fromEitherK_(FromEither);
/**
 * @category lifting
 * @since 0.6.12
 */
export const fromOptionK = 
/*#__PURE__*/ fromOptionK_(FromEither);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainOptionK = 
/*#__PURE__*/ chainOptionK_(FromEither, Chain);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainEitherK = /*#__PURE__*/ chainEitherK_(FromEither, Chain);
/**
 * Less strict version of [`chainEitherK`](#chaineitherk).
 *
 * The `W` suffix (short for **W**idening) means that the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export const chainEitherKW = chainEitherK;
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstEitherK = flow(fromEitherK, chainFirst);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstEitherKW = chainFirstEitherK;
/**
 * @category instances
 * @since 0.6.12
 */
export const FromTask = {
    URI,
    fromIO,
    fromTask,
};
/**
 * @category lifting
 * @since 0.6.12
 */
export const fromTaskK = /*#__PURE__*/ fromTaskK_(FromTask);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainTaskK = /*#__PURE__*/ chainTaskK_(FromTask, Chain);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstTaskK = /*#__PURE__*/ chainFirstTaskK_(FromTask, Chain);
/**
 * @category instances
 * @since 0.6.12
 */
export const FromIO = {
    URI,
    fromIO,
};
/**
 * @category lifting
 * @since 0.6.12
 */
export const fromIOK = /*#__PURE__*/ fromIOK_(FromIO);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainIOK = 
/*#__PURE__*/ chainIOK_(FromIO, Chain);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstIOK = 
/*#__PURE__*/ chainFirstIOK_(FromIO, Chain);
/**
 * @category instances
 * @since 0.6.12
 */
export const FromObservable = {
    URI,
    fromIO,
    fromTask,
    fromObservable,
};
/**
 * @category lifting
 * @since 0.6.12
 */
export const fromObservableK = /*#__PURE__*/ fromObservableK_(FromObservable);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainObservableK = /*#__PURE__*/ chainObservableK_(FromObservable, Chain);
/**
 * @category sequencing
 * @since 0.6.12
 */
export const chainFirstObservableK = /*#__PURE__*/ chainFirstObservableK_(FromObservable, Chain);
// -------------------------------------------------------------------------------------
// utils
// -------------------------------------------------------------------------------------
/**
 * @since 0.6.12
 */
export const Do = 
/*#__PURE__*/
of({});
/**
 * @since 0.6.11
 */
export const bindTo = (name) => map(a => ({ [name]: a }));
/**
 * @since 0.6.11
 */
export const bind = (name, f) => chain(a => pipe(f(a), map(b => (Object.assign(Object.assign({}, a), { [name]: b })))));
/**
 * @since 0.6.12
 */
export const bindW = bind;
/**
 * @since 0.6.8
 */
export const toTaskEither = R.toTask;
