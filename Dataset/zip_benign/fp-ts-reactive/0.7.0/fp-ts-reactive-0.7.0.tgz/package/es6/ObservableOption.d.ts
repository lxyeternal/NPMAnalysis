/**
 * @since 0.6.14
 */
import type { Alt1 } from 'fp-ts/Alt'
import type { Applicative1 } from 'fp-ts/Applicative'
import type { Apply1 } from 'fp-ts/Apply'
import type { Chain1 } from 'fp-ts/Chain'
import type { Either } from 'fp-ts/Either'
import { FromEither1 } from 'fp-ts/FromEither'
import { FromIO1 } from 'fp-ts/FromIO'
import { FromTask1 } from 'fp-ts/FromTask'
import type { Functor1 } from 'fp-ts/Functor'
import type { IO } from 'fp-ts/IO'
import type { Monad1 } from 'fp-ts/Monad'
import type { MonadIO1 } from 'fp-ts/MonadIO'
import type { MonadTask1 } from 'fp-ts/MonadTask'
import * as O from 'fp-ts/Option'
import type * as T from 'fp-ts/Task'
import { Lazy, Predicate, Refinement } from 'fp-ts/function'
import type { Observable } from 'rxjs'
import { FromObservable1 } from './FromObservable'
import type { MonadObservable1 } from './MonadObservable'
/**
 * @category model
 * @since 0.6.14
 */
export interface ObservableOption<A> extends Observable<O.Option<A>> {}
/**
 * @category constructors
 * @since 0.6.14
 */
export declare const none: ObservableOption<never>
/**
 * @category constructors
 * @since 0.6.14
 */
export declare const some: <A>(a: A) => ObservableOption<A>
/**
 * @category constructors
 * @since 0.6.14
 */
export declare const fromObservable: <A = never>(ma: Observable<A>) => ObservableOption<A>
/**
 * @category constructors
 * @since 0.6.12
 */
export declare const fromEither: <A>(fa: Either<unknown, A>) => ObservableOption<A>
/**
 * @category constructors
 * @since 0.6.14
 */
export declare const fromIO: <A = never>(ma: IO<A>) => ObservableOption<A>
/**
 * @category constructors
 * @since 0.6.14
 */
export declare const fromTask: MonadTask1<URI>['fromTask']
/**
 * @category constructors
 * @since 0.6.14
 */
export declare const tryCatch: <A>(a: Observable<A>) => ObservableOption<A>
/**
 * @category pattern matching
 * @since 0.6.12
 */
export declare const match: <B, A>(onNone: () => B, onSome: (a: A) => B) => (ma: ObservableOption<A>) => Observable<B>
/**
 * Less strict version of [`match`](#match).
 *
 * The `W` suffix (short for **W**idening) means that the handler return types will be merged.
 *
 * @category pattern matching
 * @since 0.6.12
 */
export declare const matchW: <B, A, C>(
    onNone: () => B,
    onSome: (a: A) => C
) => (ma: ObservableOption<A>) => Observable<B | C>
/**
 * @category destructors
 * @since 0.6.14
 */
export declare const fold: <A, B>(
    onNone: () => Observable<B>,
    onSome: (a: A) => Observable<B>
) => (ma: ObservableOption<A>) => Observable<B>
/**
 * @category destructors
 * @since 0.6.12
 */
export declare const foldW: <B, C, A>(
    onNone: () => Observable<B>,
    onSome: (a: A) => Observable<C>
) => (ma: ObservableOption<A>) => Observable<B | C>
/**
 * @category destructors
 * @since 0.6.14
 */
export declare const getOrElse: <A>(onNone: () => Observable<A>) => (ma: ObservableOption<A>) => Observable<A>
/**
 * @category destructors
 * @since 0.6.12
 */
export declare const getOrElseW: <B>(onNone: () => Observable<B>) => <A>(ma: ObservableOption<A>) => Observable<A | B>
/**
 * Identifies an associative operation on a type constructor. It is similar to `Semigroup`, except that it applies to
 * types of kind `* -> *`.
 *
 * @category combinators
 * @since 0.6.14
 */
export declare const alt: <A>(onNone: () => ObservableOption<A>) => (ma: ObservableOption<A>) => ObservableOption<A>
/**
 * Less strict version of [`alt`](#alt).
 *
 * The `W` suffix (short for **W**idening) means that the return types will be merged.
 *
 * @category error handling
 * @since 0.6.12
 */
export declare const altW: <B>(
    second: Lazy<ObservableOption<B>>
) => <A>(first: ObservableOption<A>) => ObservableOption<A | B>
/**
 * `map` can be used to turn functions `(a: A) => B` into functions `(fa: F<A>) => F<B>` whose argument and return types
 * use the type constructor `F` to represent some computational context.
 *
 * @category Functor
 * @since 0.6.14
 */
export declare const map: <A, B>(f: (a: A) => B) => (fa: ObservableOption<A>) => ObservableOption<B>
/**
 * Apply a function to an argument under a type constructor.
 *
 * @category Apply
 * @since 0.6.14
 */
export declare const ap: <A>(fa: ObservableOption<A>) => <B>(fab: ObservableOption<(a: A) => B>) => ObservableOption<B>
/**
 * Combine two effectful actions, keeping only the result of the first.
 *
 * Derivable from `Apply`.
 *
 * @category combinators
 * @since 0.6.14
 */
export declare const apFirst: <B>(fb: ObservableOption<B>) => <A>(fa: ObservableOption<A>) => ObservableOption<A>
/**
 * Combine two effectful actions, keeping only the result of the second.
 *
 * Derivable from `Apply`.
 *
 * @category combinators
 * @since 0.6.14
 */
export declare const apSecond: <B>(fb: ObservableOption<B>) => <A>(fa: ObservableOption<A>) => ObservableOption<B>
/**
 * @category Monad
 * @since 0.6.14
 */
export declare const chain: <A, B>(f: (a: A) => ObservableOption<B>) => (ma: ObservableOption<A>) => ObservableOption<B>
/**
 * Derivable from `Monad`.
 *
 * @category combinators
 * @since 0.6.14
 */
export declare const flatten: <A>(mma: ObservableOption<ObservableOption<A>>) => ObservableOption<A>
/**
 * Composes computations in sequence, using the return value of one computation to determine the next computation and
 * keeping only the result of the first.
 *
 * Derivable from `Monad`.
 *
 * @category combinators
 * @since 0.6.14
 */
export declare const chainFirst: <A, B>(
    f: (a: A) => ObservableOption<B>
) => (ma: ObservableOption<A>) => ObservableOption<A>
/**
 * @since 0.6.14
 */
export declare const of: Applicative1<URI>['of']
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.14
 */
export declare const filterOrElse: {
    <A, B extends A>(refinement: Refinement<A, B>): (ma: ObservableOption<A>) => ObservableOption<B>
    <A>(predicate: Predicate<A>): (ma: ObservableOption<A>) => ObservableOption<A>
}
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.14
 */
export declare const fromOption: <A>(ma: O.Option<A>) => ObservableOption<A>
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.14
 */
export declare const fromPredicate: {
    <A, B extends A>(refinement: Refinement<A, B>): (a: A) => ObservableOption<B>
    <A>(predicate: Predicate<A>): (a: A) => ObservableOption<A>
}
/**
 * @category instances
 * @since 0.6.14
 */
export declare const URI = 'ObservableOption'
/**
 * @category instances
 * @since 0.6.14
 */
export type URI = typeof URI
declare module 'fp-ts/es6/HKT' {
    interface URItoKind<A> {
        readonly [URI]: ObservableOption<A>
    }
}
/**
 * @category instances
 * @since 0.6.14
 */
export declare const Functor: Functor1<URI>
/**
 * @category instances
 * @since 0.6.14
 */
export declare const Apply: Apply1<URI>
/**
 * @category instances
 * @since 0.6.14
 */
export declare const Applicative: Applicative1<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Chain: Chain1<URI>
/**
 * @category instances
 * @since 0.6.14
 */
export declare const Monad: Monad1<URI>
/**
 * @category instances
 * @since 0.6.14
 */
export declare const Alt: Alt1<URI>
/**
 * @category instances
 * @since 0.6.14
 */
export declare const MonadIO: MonadIO1<URI>
/**
 * @category instances
 * @since 0.6.14
 */
export declare const MonadTask: MonadTask1<URI>
/**
 * @category instances
 * @since 0.6.14
 */
export declare const MonadObservable: MonadObservable1<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromIO: FromIO1<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromIOK: <A extends ReadonlyArray<unknown>, B>(
    f: (...a: A) => IO<B>
) => (...a: A) => ObservableOption<B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainIOK: <A, B>(f: (a: A) => IO<B>) => (first: ObservableOption<A>) => ObservableOption<B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstIOK: <A, B>(f: (a: A) => IO<B>) => (first: ObservableOption<A>) => ObservableOption<A>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromEither: FromEither1<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromEitherK: <E, A extends ReadonlyArray<unknown>, B>(
    f: (...a: A) => Either<E, B>
) => (...a: A) => ObservableOption<B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainEitherK: <E, A, B>(
    f: (a: A) => Either<E, B>
) => (ma: ObservableOption<A>) => ObservableOption<B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstEitherK: <E, A, B>(
    f: (a: A) => Either<E, B>
) => (ma: ObservableOption<A>) => ObservableOption<A>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromTask: FromTask1<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromTaskK: <A extends ReadonlyArray<unknown>, B>(
    f: (...a: A) => T.Task<B>
) => (...a: A) => ObservableOption<B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainTaskK: <A, B>(f: (a: A) => T.Task<B>) => (first: ObservableOption<A>) => ObservableOption<B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstTaskK: <A, B>(
    f: (a: A) => T.Task<B>
) => (first: ObservableOption<A>) => ObservableOption<A>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromObservable: FromObservable1<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromObservableK: <A extends ReadonlyArray<unknown>, B>(
    f: (...a: A) => Observable<B>
) => (...a: A) => ObservableOption<B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainObservableK: <A, B>(
    f: (a: A) => Observable<B>
) => (first: ObservableOption<A>) => ObservableOption<B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstObservableK: <A, B>(
    f: (a: A) => Observable<B>
) => (first: ObservableOption<A>) => ObservableOption<A>
/**
 * @since 0.6.14
 */
export declare const Do: ObservableOption<Record<string, never>>
/**
 * @since 0.6.14
 */
export declare const bindTo: <K extends string, A>(
    name: K
) => (fa: ObservableOption<A>) => ObservableOption<{ [P in K]: A }>
/**
 * @since 0.6.14
 */
export declare const bind: <K extends string, A, B>(
    name: Exclude<K, keyof A>,
    f: (a: A) => ObservableOption<B>
) => (fa: ObservableOption<A>) => ObservableOption<{ [P in K | keyof A]: P extends keyof A ? A[P] : B }>
