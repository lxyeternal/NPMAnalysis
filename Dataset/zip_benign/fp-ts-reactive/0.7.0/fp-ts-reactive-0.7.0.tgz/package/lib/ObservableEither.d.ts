/**
 * @since 0.6.8
 */
import type { Alt2 } from 'fp-ts/Alt'
import type { Applicative2 } from 'fp-ts/Applicative'
import type { Apply2 } from 'fp-ts/Apply'
import type { Bifunctor2 } from 'fp-ts/Bifunctor'
import type { Chain2 } from 'fp-ts/Chain'
import * as E from 'fp-ts/Either'
import { FromEither2 } from 'fp-ts/FromEither'
import { FromIO2 } from 'fp-ts/FromIO'
import { FromTask2 } from 'fp-ts/FromTask'
import type { Functor2 } from 'fp-ts/Functor'
import type { IO } from 'fp-ts/IO'
import type { IOEither } from 'fp-ts/IOEither'
import type { Monad2 } from 'fp-ts/Monad'
import type { MonadIO2 } from 'fp-ts/MonadIO'
import type { MonadTask2 } from 'fp-ts/MonadTask'
import type { MonadThrow2 } from 'fp-ts/MonadThrow'
import type { Option } from 'fp-ts/Option'
import type * as T from 'fp-ts/Task'
import type * as TE from 'fp-ts/TaskEither'
import { Lazy, Predicate, Refinement } from 'fp-ts/function'
import type { Observable } from 'rxjs'
import { FromObservable2 } from './FromObservable'
import type { MonadObservable2 } from './MonadObservable'
/**
 * @category model
 * @since 0.6.8
 */
export interface ObservableEither<E, A> extends Observable<E.Either<E, A>> {}
/**
 * @category constructors
 * @since 0.6.8
 */
export declare const left: <E = never, A = never>(e: E) => ObservableEither<E, A>
/**
 * @category constructors
 * @since 0.6.8
 */
export declare const right: <E = never, A = never>(a: A) => ObservableEither<E, A>
/**
 * @category constructors
 * @since 0.6.8
 */
export declare const rightObservable: <E = never, A = never>(ma: Observable<A>) => ObservableEither<E, A>
/**
 * @category constructors
 * @since 0.6.8
 */
export declare const leftObservable: <E = never, A = never>(ma: Observable<E>) => ObservableEither<E, A>
/**
 * @category constructors
 * @since 0.6.8
 */
export declare const fromIOEither: <E, A>(fa: IOEither<E, A>) => ObservableEither<E, A>
/**
 * @category constructors
 * @since 0.6.8
 */
export declare const rightIO: <E = never, A = never>(ma: IO<A>) => ObservableEither<E, A>
/**
 * @category constructors
 * @since 0.6.8
 */
export declare const leftIO: <E = never, A = never>(me: IO<E>) => ObservableEither<E, A>
/**
 * @category constructors
 * @since 0.6.8
 */
export declare const fromTaskEither: <E, A>(t: TE.TaskEither<E, A>) => ObservableEither<E, A>
/**
 * @category constructors
 * @since 0.6.12
 */
export declare const fromIO: MonadIO2<URI>['fromIO']
/**
 * @category constructors
 * @since 0.6.8
 */
export declare const fromTask: MonadTask2<URI>['fromTask']
/**
 * @category constructors
 * @since 0.6.12
 */
export declare const fromObservable: MonadObservable2<URI>['fromObservable']
/**
 * @category constructors
 * @since 0.6.12
 */
export declare const tryCatch: <A>(a: Observable<A>) => ObservableEither<unknown, A>
/**
 * @category pattern matching
 * @since 0.6.12
 */
export declare const match: <E, B, A>(
    onLeft: (e: E) => B,
    onRight: (a: A) => B
) => (ma: ObservableEither<E, A>) => Observable<B>
/**
 * @category pattern matching
 * @since 0.6.12
 */
export declare const matchW: <E, B, A, C>(
    onLeft: (e: E) => B,
    onRight: (a: A) => C
) => (ma: ObservableEither<E, A>) => Observable<B | C>
/**
 * @category destructors
 * @since 0.6.8
 */
export declare const fold: <E, A, B>(
    onLeft: (e: E) => Observable<B>,
    onRight: (a: A) => Observable<B>
) => (ma: ObservableEither<E, A>) => Observable<B>
/**
 * @category destructors
 * @since 0.6.12
 */
export declare const foldW: <E, A, B, C>(
    onLeft: (e: E) => Observable<B>,
    onRight: (a: A) => Observable<C>
) => (ma: ObservableEither<E, A>) => Observable<B | C>
/**
 * @category destructors
 * @since 0.6.8
 */
export declare const getOrElse: <E, A>(onLeft: (e: E) => Observable<A>) => (ma: ObservableEither<E, A>) => Observable<A>
/**
 * @category destructors
 * @since 0.6.12
 */
export declare const getOrElseW: <E, B>(
    onLeft: (e: E) => Observable<B>
) => <A>(ma: ObservableEither<E, A>) => Observable<A | B>
/**
 * @category combinators
 * @since 0.6.8
 */
export declare const orElse: <E, A, M>(
    onLeft: (e: E) => ObservableEither<M, A>
) => (ma: ObservableEither<E, A>) => ObservableEither<M, A>
/**
 * @category combinators
 * @since 0.6.12
 */
export declare const orElseW: <E1, E2, B>(
    onLeft: (e: E1) => ObservableEither<E2, B>
) => <A>(ma: ObservableEither<E1, A>) => ObservableEither<E2, A | B>
/**
 * @category combinators
 * @since 0.6.8
 */
export declare const swap: <E, A>(ma: ObservableEither<E, A>) => ObservableEither<A, E>
/**
 * `map` can be used to turn functions `(a: A) => B` into functions `(fa: F<A>) => F<B>` whose argument and return types
 * use the type constructor `F` to represent some computational context.
 *
 * @category Functor
 * @since 0.6.8
 */
export declare const map: <A, B>(f: (a: A) => B) => <E>(fa: ObservableEither<E, A>) => ObservableEither<E, B>
/**
 * Apply a function to an argument under a type constructor.
 *
 * @category Apply
 * @since 0.6.0
 */
export declare const ap: <E, A>(
    fa: ObservableEither<E, A>
) => <B>(fab: ObservableEither<E, (a: A) => B>) => ObservableEither<E, B>
/**
 * Less strict version of [`ap`](#ap).
 *
 * The `W` suffix (short for **W**idening) means that the error types will be merged.
 *
 * @since 0.6.12
 */
export declare const apW: <E2, A>(
    fa: ObservableEither<E2, A>
) => <E1, B>(fab: ObservableEither<E1, (a: A) => B>) => ObservableEither<E1 | E2, B>
/**
 * Combine two effectful actions, keeping only the result of the first.
 *
 * Derivable from `Apply`.
 *
 * @category combinators
 * @since 0.6.8
 */
export declare const apFirst: <E, B>(
    fb: ObservableEither<E, B>
) => <A>(fa: ObservableEither<E, A>) => ObservableEither<E, A>
/**
 * Combine two effectful actions, keeping only the result of the second.
 *
 * Derivable from `Apply`.
 *
 * @category combinators
 * @since 0.6.8
 */
export declare const apSecond: <E, B>(
    fb: ObservableEither<E, B>
) => <A>(fa: ObservableEither<E, A>) => ObservableEither<E, B>
/**
 * Identifies an associative operation on a type constructor. It is similar to `Semigroup`, except that it applies to
 * types of kind `* -> *`.
 *
 * @category Alt
 * @since 0.6.8
 */
export declare const alt: <E, A>(
    that: () => ObservableEither<E, A>
) => (fa: ObservableEither<E, A>) => ObservableEither<E, A>
/**
 * Less strict version of [`alt`](#alt).
 *
 * The `W` suffix (short for **W**idening) means that the error and the return types will be merged.
 *
 * @category error handling
 * @since 0.6.8
 */
export declare const altW: <E2, B>(
    that: Lazy<ObservableEither<E2, B>>
) => <E1, A>(fa: ObservableEither<E1, A>) => ObservableEither<E2, A | B>
/**
 * @category Bifunctor
 * @since 0.6.8
 */
export declare const bimap: <E, G, A, B>(
    f: (e: E) => G,
    g: (a: A) => B
) => (fa: ObservableEither<E, A>) => ObservableEither<G, B>
/**
 * @category Bifunctor
 * @since 0.6.8
 */
export declare const mapLeft: <E, G>(f: (e: E) => G) => <A>(fa: ObservableEither<E, A>) => ObservableEither<G, A>
/**
 * Less strict version of [`chain`](#chain).
 *
 * @category Monad
 * @since 0.6.12
 */
export declare const chainW: <A, E2, B>(
    f: (a: A) => ObservableEither<E2, B>
) => <E1>(ma: ObservableEither<E1, A>) => ObservableEither<E2 | E1, B>
/**
 * @category Monad
 * @since 0.6.8
 */
export declare const chain: <A, E, B>(
    f: (a: A) => ObservableEither<E, B>
) => (ma: ObservableEither<E, A>) => ObservableEither<E, B>
/**
 * Less strict version of [`flatten`](#flatten).
 *
 * The `W` suffix (short for **W**idening) means that the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const flattenW: <E1, E2, A>(
    mma: ObservableEither<E1, ObservableEither<E2, A>>
) => ObservableEither<E1 | E2, A>
/**
 * Derivable from `Monad`.
 *
 * @category combinators
 * @since 0.6.0
 */
export declare const flatten: <E, A>(mma: ObservableEither<E, ObservableEither<E, A>>) => ObservableEither<E, A>
/**
 * Composes computations in sequence, using the return value of one computation to determine the next computation and
 * keeping only the result of the first.
 *
 * Derivable from `Monad`.
 *
 * @category combinators
 * @since 0.6.8
 */
export declare const chainFirst: <E, A, B>(
    f: (a: A) => ObservableEither<E, B>
) => (ma: ObservableEither<E, A>) => ObservableEither<E, A>
/**
 * Less strict version of [`chainFirst`](#chainfirst)
 *
 * @category combinators
 * @since 0.6.12
 */
export declare const chainFirstW: <E2, A, B>(
    f: (a: A) => ObservableEither<E2, B>
) => <E1>(ma: ObservableEither<E1, A>) => ObservableEither<E1 | E2, A>
/**
 * @since 0.6.12
 */
export declare const of: Applicative2<URI>['of']
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export declare const filterOrElse: {
    <E, A, B extends A>(refinement: Refinement<A, B>, onFalse: (a: A) => E): (
        ma: ObservableEither<E, A>
    ) => ObservableEither<E, B>
    <E, A>(predicate: Predicate<A>, onFalse: (a: A) => E): (ma: ObservableEither<E, A>) => ObservableEither<E, A>
}
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.12
 */
export declare const filterOrElseW: {
    <E2, E1, A, B extends A>(refinement: Refinement<A, B>, onFalse: (a: A) => E2): (
        ma: ObservableEither<E1, A>
    ) => ObservableEither<E1 | E2, B>
    <E2, E1, A>(predicate: Predicate<A>, onFalse: (a: A) => E2): (
        ma: ObservableEither<E1, A>
    ) => ObservableEither<E1 | E2, A>
}
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export declare const fromEither: <E, A>(ma: E.Either<E, A>) => ObservableEither<E, A>
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export declare const fromOption: <E>(onNone: () => E) => <A>(ma: Option<A>) => ObservableEither<E, A>
/**
 * Derivable from `MonadThrow`.
 *
 * @since 0.6.10
 */
export declare const fromPredicate: {
    <E, A, B extends A>(refinement: Refinement<A, B>, onFalse: (a: A) => E): (a: A) => ObservableEither<E, B>
    <E, A>(predicate: Predicate<A>, onFalse: (a: A) => E): (a: A) => ObservableEither<E, A>
}
/**
 * @category MonadThrow
 * @since 0.6.12
 */
export declare const throwError: MonadThrow2<URI>['throwError']
/**
 * @category instances
 * @since 0.6.8
 */
export declare const URI = 'ObservableEither'
/**
 * @category instances
 * @since 0.6.8
 */
export type URI = typeof URI
declare module 'fp-ts/lib/HKT' {
    interface URItoKind2<E, A> {
        readonly [URI]: ObservableEither<E, A>
    }
}
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Functor: Functor2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Apply: Apply2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Applicative: Applicative2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Chain: Chain2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Monad: Monad2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Bifunctor: Bifunctor2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const Alt: Alt2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const MonadIO: MonadIO2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const MonadTask: MonadTask2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const MonadObservable: MonadObservable2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const MonadThrow: MonadThrow2<URI>
/**
 * @category instances
 * @deprecated
 * @since 0.6.8
 */
export declare const observableEither: Monad2<URI> &
    Bifunctor2<URI> &
    Alt2<URI> &
    MonadObservable2<URI> &
    MonadThrow2<URI>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromEither: FromEither2<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromEitherK: <E, A extends ReadonlyArray<unknown>, B>(
    f: (...a: A) => E.Either<E, B>
) => (...a: A) => ObservableEither<E, B>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromOptionK: <E>(
    onNone: Lazy<E>
) => <A extends ReadonlyArray<unknown>, B>(f: (...a: A) => Option<B>) => (...a: A) => ObservableEither<E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainOptionK: <E>(
    onNone: Lazy<E>
) => <A, B>(f: (a: A) => Option<B>) => (ma: ObservableEither<E, A>) => ObservableEither<E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainEitherK: <E, A, B>(
    f: (a: A) => E.Either<E, B>
) => (ma: ObservableEither<E, A>) => ObservableEither<E, B>
/**
 * Less strict version of [`chainEitherK`](#chaineitherk).
 *
 * The `W` suffix (short for **W**idening) means that the error types will be merged.
 *
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainEitherKW: <E2, A, B>(
    f: (a: A) => E.Either<E2, B>
) => <E1>(ma: ObservableEither<E1, A>) => ObservableEither<E1 | E2, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstEitherK: <E, A, B>(
    f: (a: A) => E.Either<E, B>
) => (ma: ObservableEither<E, A>) => ObservableEither<E, A>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstEitherKW: <E2, A, B>(
    f: (a: A) => E.Either<E2, B>
) => <E1>(ma: ObservableEither<E1, A>) => ObservableEither<E1 | E2, A>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromTask: FromTask2<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromTaskK: <A extends ReadonlyArray<unknown>, B>(
    f: (...a: A) => T.Task<B>
) => <E = never>(...a: A) => ObservableEither<E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainTaskK: <A, B>(
    f: (a: A) => T.Task<B>
) => <E>(first: ObservableEither<E, A>) => ObservableEither<E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstTaskK: <A, B>(
    f: (a: A) => T.Task<B>
) => <E>(first: ObservableEither<E, A>) => ObservableEither<E, A>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromIO: FromIO2<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromIOK: <A extends ReadonlyArray<unknown>, B>(
    f: (...a: A) => IO<B>
) => <E = never>(...a: A) => ObservableEither<E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainIOK: <A, B>(
    f: (a: A) => IO<B>
) => <E>(first: ObservableEither<E, A>) => ObservableEither<E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstIOK: <A, B>(
    f: (a: A) => IO<B>
) => <E>(first: ObservableEither<E, A>) => ObservableEither<E, A>
/**
 * @category instances
 * @since 0.6.12
 */
export declare const FromObservable: FromObservable2<URI>
/**
 * @category lifting
 * @since 0.6.12
 */
export declare const fromObservableK: <A extends ReadonlyArray<unknown>, B>(
    f: (...a: A) => Observable<B>
) => <E = never>(...a: A) => ObservableEither<E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainObservableK: <A, B>(
    f: (a: A) => Observable<B>
) => <E>(first: ObservableEither<E, A>) => ObservableEither<E, B>
/**
 * @category sequencing
 * @since 0.6.12
 */
export declare const chainFirstObservableK: <A, B>(
    f: (a: A) => Observable<B>
) => <E>(first: ObservableEither<E, A>) => ObservableEither<E, A>
/**
 * @since 0.6.12
 */
export declare const Do: ObservableEither<never, Record<string, never>>
/**
 * @since 0.6.11
 */
export declare const bindTo: <K extends string, E, A>(
    name: K
) => (fa: ObservableEither<E, A>) => ObservableEither<E, { [P in K]: A }>
/**
 * @since 0.6.11
 */
export declare const bind: <K extends string, E, A, B>(
    name: Exclude<K, keyof A>,
    f: (a: A) => ObservableEither<E, B>
) => (fa: ObservableEither<E, A>) => ObservableEither<E, { [P in K | keyof A]: P extends keyof A ? A[P] : B }>
/**
 * @since 0.6.12
 */
export declare const bindW: <K extends string, E2, A, B>(
    name: Exclude<K, keyof A>,
    f: (a: A) => ObservableEither<E2, B>
) => <E1>(fa: ObservableEither<E1, A>) => ObservableEither<
    E1 | E2,
    {
        [P in keyof A | K]: P extends keyof A ? A[P] : B
    }
>
/**
 * @since 0.6.8
 */
export declare const toTaskEither: <E, A>(o: ObservableEither<E, A>) => TE.TaskEither<E, A>
