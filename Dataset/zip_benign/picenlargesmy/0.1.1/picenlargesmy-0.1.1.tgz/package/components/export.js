import picEnlarge from './picEnlarge.vue';
export default picEnlarge;
if (typeof window !== 'undefined' && window.Vue) {
	window.Vue.component('picEnlarge', picEnlarge);
}
