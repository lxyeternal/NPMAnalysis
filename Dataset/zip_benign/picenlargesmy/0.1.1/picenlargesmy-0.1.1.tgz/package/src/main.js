import Vue from 'vue'
import App from './App.vue'
import picEnlarge from '../components/export.js'
Vue.component('picEnlarge', picEnlarge)
Vue.config.productionTip = false
new Vue({
	render: h => h(App),
}).$mount('#app')
