Gulp JSCS Custom Reporter
=========================

Information
-----------

<table>
<tr>
<td>Package</td><td>gulp-jscs-custom</td>
</tr>
<tr>
<td>Description</td>
<td>Gulp plugin for JSCS with custimizable reporters, including Jenkins-friendly Checkstyle. You can output files too.</td>
</tr>
<tr>
<td>Node Version</td>
<td>>= 0.4</td>
</tr>
</table>

Install
-------

`npm install gulp-jscs-custom --save-dev`

Usage
-----

```javascript
var gulp = require('gulp'),
    jscs = require('gulp-jscs-custom');

gulp.task('checkstyle', function () {
    return gulp.src('./**/*.js')
        .pipe(jscs({
            esnext: false,
            configPath: '.jscsrc',
            reporter: 'checkstyle',
            filePath: './jscs.xml',
            failOnError: false
        }));
});

```

Options
-------

<table>
    <tr>
        <th>Option</th>
        <th>Type</th>
        <th>Description</th>
        <th>Default value</th>
    </tr>
    <tr>
        <td>esnext</td>
        <td>Boolean</td>
        <td>JSCS's option to parse esnext</td>
        <td>```javascript
false
```</td>
    <tr>
        <td>configPath</td>
        <td>String</td>
        <td>Path to JSCS Config</td>
        <td>```javascript
'.jscsrc'
```</td>
    </tr>
    <tr>
        <td>reporter</td>
        <td>String</td>
        <td>
            Which reporter JSCS will use. Options include:<br>
 **JSCS Reporters**:
'console'
* * 'inline'
* * 'junit'
* * 'text'
* You can also set the file path to a custom reporter.
         </td>
        <td>```javascript
'console'
```</td>
    </tr>
    <tr>
        <td>filePath</td>
        <td>String</td>
        <td>Output file path. If set to `null` will print to stdout</td>
        <td>```javascript
null
```</td>
    </tr>
    <tr>
        <td>failOnError</td>
        <td>Boolean</td>
        <td>If true, gulp task will break if JSCS finds any linting error</td>
        <td>```javascript
false
```</td>
    </tr>
    <tr>
        <td>alwaysCreateReport</td>
        <td>Boolean</td>
        <td>Create the report even if no errors were found</td>
        <td>```javascript
false
```</td>
    </tr>
</table>
