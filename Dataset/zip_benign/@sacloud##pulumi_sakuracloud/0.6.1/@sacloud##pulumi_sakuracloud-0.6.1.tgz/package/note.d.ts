import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud Note.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 * import * from "fs";
 *
 * const foobar = new sakuracloud.Note("foobar", {content: fs.readFileSync("startup-script.sh")});
 * ```
 */
export declare class Note extends pulumi.CustomResource {
    /**
     * Get an existing Note resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: NoteState, opts?: pulumi.CustomResourceOptions): Note;
    /**
     * Returns true if the given object is an instance of Note.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is Note;
    /**
     * The class of the Note. This must be one of `shell`/`yamlCloudConfig`. Default:`shell`.
     */
    readonly class: pulumi.Output<string | undefined>;
    /**
     * The content of the Note. This must be specified as a shell script or as a cloud-config.
     */
    readonly content: pulumi.Output<string>;
    /**
     * The description of the Note. This will be computed from special tags within body of `content`.
     */
    readonly description: pulumi.Output<string>;
    /**
     * The icon id to attach to the Note.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The name of the Note. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * Any tags to assign to the Note.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * Create a Note resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: NoteArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering Note resources.
 */
export interface NoteState {
    /**
     * The class of the Note. This must be one of `shell`/`yamlCloudConfig`. Default:`shell`.
     */
    class?: pulumi.Input<string>;
    /**
     * The content of the Note. This must be specified as a shell script or as a cloud-config.
     */
    content?: pulumi.Input<string>;
    /**
     * The description of the Note. This will be computed from special tags within body of `content`.
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the Note.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the Note. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * Any tags to assign to the Note.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
}
/**
 * The set of arguments for constructing a Note resource.
 */
export interface NoteArgs {
    /**
     * The class of the Note. This must be one of `shell`/`yamlCloudConfig`. Default:`shell`.
     */
    class?: pulumi.Input<string>;
    /**
     * The content of the Note. This must be specified as a shell script or as a cloud-config.
     */
    content: pulumi.Input<string>;
    /**
     * The icon id to attach to the Note.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the Note. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * Any tags to assign to the Note.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
}
