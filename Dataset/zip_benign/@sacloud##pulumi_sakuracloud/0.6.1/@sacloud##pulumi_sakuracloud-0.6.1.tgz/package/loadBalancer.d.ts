import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Manages a SakuraCloud Load Balancer.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobarSwitch = new sakuracloud.Switch("foobarSwitch", {});
 * const foobarLoadBalancer = new sakuracloud.LoadBalancer("foobarLoadBalancer", {
 *     plan: "standard",
 *     networkInterface: {
 *         switchId: foobarSwitch.id,
 *         vrid: 1,
 *         ipAddresses: ["192.168.11.101"],
 *         netmask: 24,
 *         gateway: "192.168.11.1",
 *     },
 *     description: "description",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 *     vips: [{
 *         vip: "192.168.11.201",
 *         port: 80,
 *         delayLoop: 10,
 *         sorryServer: "192.168.11.21",
 *         servers: [
 *             {
 *                 ipAddress: "192.168.11.51",
 *                 protocol: "http",
 *                 path: "/health",
 *                 status: 200,
 *             },
 *             {
 *                 ipAddress: "192.168.11.52",
 *                 protocol: "http",
 *                 path: "/health",
 *                 status: 200,
 *             },
 *         ],
 *     }],
 * });
 * ```
 */
export declare class LoadBalancer extends pulumi.CustomResource {
    /**
     * Get an existing LoadBalancer resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: LoadBalancerState, opts?: pulumi.CustomResourceOptions): LoadBalancer;
    /**
     * Returns true if the given object is an instance of LoadBalancer.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is LoadBalancer;
    /**
     * The description of the VIP. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The icon id to attach to the LoadBalancer.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The name of the LoadBalancer. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * An `networkInterface` block as defined below.
     */
    readonly networkInterface: pulumi.Output<outputs.LoadBalancerNetworkInterface>;
    /**
     * The plan name of the LoadBalancer. This must be one of [`standard`/`highspec`]. Changing this forces a new resource to be created. Default:`standard`.
     */
    readonly plan: pulumi.Output<string | undefined>;
    /**
     * Any tags to assign to the LoadBalancer.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * One or more `vip` blocks as defined below.
     */
    readonly vips: pulumi.Output<outputs.LoadBalancerVip[] | undefined>;
    /**
     * The name of zone that the LoadBalancer will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    readonly zone: pulumi.Output<string>;
    /**
     * Create a LoadBalancer resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: LoadBalancerArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering LoadBalancer resources.
 */
export interface LoadBalancerState {
    /**
     * The description of the VIP. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the LoadBalancer.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the LoadBalancer. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * An `networkInterface` block as defined below.
     */
    networkInterface?: pulumi.Input<inputs.LoadBalancerNetworkInterface>;
    /**
     * The plan name of the LoadBalancer. This must be one of [`standard`/`highspec`]. Changing this forces a new resource to be created. Default:`standard`.
     */
    plan?: pulumi.Input<string>;
    /**
     * Any tags to assign to the LoadBalancer.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * One or more `vip` blocks as defined below.
     */
    vips?: pulumi.Input<pulumi.Input<inputs.LoadBalancerVip>[]>;
    /**
     * The name of zone that the LoadBalancer will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a LoadBalancer resource.
 */
export interface LoadBalancerArgs {
    /**
     * The description of the VIP. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the LoadBalancer.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the LoadBalancer. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * An `networkInterface` block as defined below.
     */
    networkInterface: pulumi.Input<inputs.LoadBalancerNetworkInterface>;
    /**
     * The plan name of the LoadBalancer. This must be one of [`standard`/`highspec`]. Changing this forces a new resource to be created. Default:`standard`.
     */
    plan?: pulumi.Input<string>;
    /**
     * Any tags to assign to the LoadBalancer.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * One or more `vip` blocks as defined below.
     */
    vips?: pulumi.Input<pulumi.Input<inputs.LoadBalancerVip>[]>;
    /**
     * The name of zone that the LoadBalancer will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
