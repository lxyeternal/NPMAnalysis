import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud Private Host.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = new sakuracloud.PrivateHost("foobar", {
 *     description: "description",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 * });
 * ```
 */
export declare class PrivateHost extends pulumi.CustomResource {
    /**
     * Get an existing PrivateHost resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: PrivateHostState, opts?: pulumi.CustomResourceOptions): PrivateHost;
    /**
     * Returns true if the given object is an instance of PrivateHost.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is PrivateHost;
    /**
     * The total number of CPUs assigned to servers on the private host.
     */
    readonly assignedCore: pulumi.Output<number>;
    /**
     * The total size of memory assigned to servers on the private host.
     */
    readonly assignedMemory: pulumi.Output<number>;
    /**
     * The class of the PrivateHost. This will be one of [`dynamic`/`msWindows`]. Default:`dynamic`.
     */
    readonly class: pulumi.Output<string | undefined>;
    /**
     * The description of the PrivateHost. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The hostname of the private host.
     */
    readonly hostname: pulumi.Output<string>;
    /**
     * The icon id to attach to the PrivateHost.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The name of the PrivateHost. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * Any tags to assign to the PrivateHost.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * The name of zone that the PrivateHost will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    readonly zone: pulumi.Output<string>;
    /**
     * Create a PrivateHost resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args?: PrivateHostArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering PrivateHost resources.
 */
export interface PrivateHostState {
    /**
     * The total number of CPUs assigned to servers on the private host.
     */
    assignedCore?: pulumi.Input<number>;
    /**
     * The total size of memory assigned to servers on the private host.
     */
    assignedMemory?: pulumi.Input<number>;
    /**
     * The class of the PrivateHost. This will be one of [`dynamic`/`msWindows`]. Default:`dynamic`.
     */
    class?: pulumi.Input<string>;
    /**
     * The description of the PrivateHost. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The hostname of the private host.
     */
    hostname?: pulumi.Input<string>;
    /**
     * The icon id to attach to the PrivateHost.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the PrivateHost. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * Any tags to assign to the PrivateHost.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of zone that the PrivateHost will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a PrivateHost resource.
 */
export interface PrivateHostArgs {
    /**
     * The class of the PrivateHost. This will be one of [`dynamic`/`msWindows`]. Default:`dynamic`.
     */
    class?: pulumi.Input<string>;
    /**
     * The description of the PrivateHost. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the PrivateHost.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the PrivateHost. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * Any tags to assign to the PrivateHost.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of zone that the PrivateHost will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
