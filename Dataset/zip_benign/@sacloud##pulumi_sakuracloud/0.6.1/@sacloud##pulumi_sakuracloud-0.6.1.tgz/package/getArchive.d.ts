import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing Archive.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getArchive({
 *     osType: "centos8",
 * }));
 * ```
 */
export declare function getArchive(args?: GetArchiveArgs, opts?: pulumi.InvokeOptions): Promise<GetArchiveResult>;
/**
 * A collection of arguments for invoking getArchive.
 */
export interface GetArchiveArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetArchiveFilter;
    /**
     * The criteria used to filter SakuraCloud archives. This must be one of following:
     * - **CentOS**: [`centos`/`centos8`/`centos8stream`/`centos7`]
     * - **Alt RHEL/CentOS**: [`almalinux`/`rockylinux`/`miracle`/`miraclelinux`]
     * - **Ubuntu**: [`ubuntu`/`ubuntu2004`/`ubuntu1804`]
     * - **Debian**: [`debian`/`debian10`/`debian11`]
     * - **CoreOS/ContainerLinux**: `coreos`
     * - **RancherOS**: `rancheros`
     * - **k3OS**: `k3os`
     * - **FreeBSD**: `freebsd`
     * - **Kusanagi**: `kusanagi`
     * - **Windows2016**: [`windows2016`/`windows2016-rds`/`windows2016-rds-office`]
     * - **Windows2016+SQLServer**:  [`windows2016-sql-web`/`windows2016-sql-standard`/`windows2016-sql-standard-all`]
     * - **Windows2016+SQLServer2017**: [`windows2016-sql2017-standard`/`windows2016-sql2017-enterprise`/`windows2016-sql2017-standard-all`]
     * - **Windows2019**: [`windows2019`/`windows2019-rds`/`windows2019-rds-office2016`/`windows2019-rds-office2019`]
     * - **Windows2019+SQLServer2017**: [`windows2019-sql2017-web`/`windows2019-sql2017-standard`/`windows2019-sql2017-enterprise`/`windows2019-sql2017-standard-all`]
     * - **Windows2019+SQLServer2019**: [`windows2019-sql2019-web`/`windows2019-sql2019-standard`/`windows2019-sql2019-enterprise`/`windows2019-sql2019-standard-all`]
     */
    osType?: string;
    /**
     * The name of zone that the Archive is in (e.g. `is1a`, `tk1a`).
     */
    zone?: string;
}
/**
 * A collection of values returned by getArchive.
 */
export interface GetArchiveResult {
    /**
     * The description of the Archive.
     */
    readonly description: string;
    readonly filter?: outputs.GetArchiveFilter;
    /**
     * The icon id attached to the Archive.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the Archive.
     */
    readonly name: string;
    readonly osType?: string;
    /**
     * The size of Archive in GiB.
     */
    readonly size: number;
    /**
     * Any tags assigned to the Archive.
     */
    readonly tags: string[];
    readonly zone: string;
}
export declare function getArchiveOutput(args?: GetArchiveOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetArchiveResult>;
/**
 * A collection of arguments for invoking getArchive.
 */
export interface GetArchiveOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetArchiveFilterArgs>;
    /**
     * The criteria used to filter SakuraCloud archives. This must be one of following:
     * - **CentOS**: [`centos`/`centos8`/`centos8stream`/`centos7`]
     * - **Alt RHEL/CentOS**: [`almalinux`/`rockylinux`/`miracle`/`miraclelinux`]
     * - **Ubuntu**: [`ubuntu`/`ubuntu2004`/`ubuntu1804`]
     * - **Debian**: [`debian`/`debian10`/`debian11`]
     * - **CoreOS/ContainerLinux**: `coreos`
     * - **RancherOS**: `rancheros`
     * - **k3OS**: `k3os`
     * - **FreeBSD**: `freebsd`
     * - **Kusanagi**: `kusanagi`
     * - **Windows2016**: [`windows2016`/`windows2016-rds`/`windows2016-rds-office`]
     * - **Windows2016+SQLServer**:  [`windows2016-sql-web`/`windows2016-sql-standard`/`windows2016-sql-standard-all`]
     * - **Windows2016+SQLServer2017**: [`windows2016-sql2017-standard`/`windows2016-sql2017-enterprise`/`windows2016-sql2017-standard-all`]
     * - **Windows2019**: [`windows2019`/`windows2019-rds`/`windows2019-rds-office2016`/`windows2019-rds-office2019`]
     * - **Windows2019+SQLServer2017**: [`windows2019-sql2017-web`/`windows2019-sql2017-standard`/`windows2019-sql2017-enterprise`/`windows2019-sql2017-standard-all`]
     * - **Windows2019+SQLServer2019**: [`windows2019-sql2019-web`/`windows2019-sql2019-standard`/`windows2019-sql2019-enterprise`/`windows2019-sql2019-standard-all`]
     */
    osType?: pulumi.Input<string>;
    /**
     * The name of zone that the Archive is in (e.g. `is1a`, `tk1a`).
     */
    zone?: pulumi.Input<string>;
}
