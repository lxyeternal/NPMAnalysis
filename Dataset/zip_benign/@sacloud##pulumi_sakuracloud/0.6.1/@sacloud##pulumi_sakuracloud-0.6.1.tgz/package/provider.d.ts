import * as pulumi from "@pulumi/pulumi";
/**
 * The provider type for the sakuracloud package. By default, resources use package-wide configuration
 * settings, however an explicit `Provider` instance may be created and passed during resource
 * construction to achieve fine-grained programmatic control over provider settings. See the
 * [documentation](https://www.pulumi.com/docs/reference/programming-model/#providers) for more information.
 */
export declare class Provider extends pulumi.ProviderResource {
    /**
     * Returns true if the given object is an instance of Provider.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is Provider;
    /**
     * The value of AcceptLanguage header used when calling SakuraCloud API. It can also be sourced from the
     * `SAKURACLOUD_ACCEPT_LANGUAGE` environment variables, or via a shared credentials file if `profile` is specified
     */
    readonly acceptLanguage: pulumi.Output<string | undefined>;
    /**
     * The root URL of SakuraCloud API. It can also be sourced from the `SAKURACLOUD_API_ROOT_URL` environment variables, or
     * via a shared credentials file if `profile` is specified. Default:`https://secure.sakura.ad.jp/cloud/zone`
     */
    readonly apiRootUrl: pulumi.Output<string | undefined>;
    /**
     * The name of zone to use as default for global resources. It must be provided, but it can also be sourced from the
     * `SAKURACLOUD_DEFAULT_ZONE` environment variables, or via a shared credentials file if `profile` is specified
     */
    readonly defaultZone: pulumi.Output<string | undefined>;
    /**
     * The flag to enable fake of SakuraCloud API call. It is for debugging or developping the provider. It can also be sourced
     * from the `FAKE_MODE` environment variables, or via a shared credentials file if `profile` is specified
     */
    readonly fakeMode: pulumi.Output<string | undefined>;
    /**
     * The file path used by SakuraCloud API fake driver for storing fake data. It is for debugging or developping the
     * provider. It can also be sourced from the `FAKE_STORE_PATH` environment variables, or via a shared credentials file if
     * `profile` is specified
     */
    readonly fakeStorePath: pulumi.Output<string | undefined>;
    /**
     * The profile name of your SakuraCloud account. Default:`default`
     */
    readonly profile: pulumi.Output<string | undefined>;
    /**
     * The API secret of your SakuraCloud account. It must be provided, but it can also be sourced from the
     * `SAKURACLOUD_ACCESS_TOKEN_SECRET` environment variables, or via a shared credentials file if `profile` is specified
     */
    readonly secret: pulumi.Output<string | undefined>;
    /**
     * The API token of your SakuraCloud account. It must be provided, but it can also be sourced from the
     * `SAKURACLOUD_ACCESS_TOKEN` environment variables, or via a shared credentials file if `profile` is specified
     */
    readonly token: pulumi.Output<string | undefined>;
    /**
     * The flag to enable output trace log. It can also be sourced from the `SAKURACLOUD_TRACE` environment variables, or via a
     * shared credentials file if `profile` is specified
     */
    readonly trace: pulumi.Output<string | undefined>;
    /**
     * The name of zone to use as default. It must be provided, but it can also be sourced from the `SAKURACLOUD_ZONE`
     * environment variables, or via a shared credentials file if `profile` is specified
     */
    readonly zone: pulumi.Output<string | undefined>;
    /**
     * Create a Provider resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args?: ProviderArgs, opts?: pulumi.ResourceOptions);
}
/**
 * The set of arguments for constructing a Provider resource.
 */
export interface ProviderArgs {
    /**
     * The value of AcceptLanguage header used when calling SakuraCloud API. It can also be sourced from the
     * `SAKURACLOUD_ACCEPT_LANGUAGE` environment variables, or via a shared credentials file if `profile` is specified
     */
    acceptLanguage?: pulumi.Input<string>;
    /**
     * The maximum number of SakuraCloud API calls per second. It can also be sourced from the `SAKURACLOUD_RATE_LIMIT`
     * environment variables, or via a shared credentials file if `profile` is specified. Default:`10`
     */
    apiRequestRateLimit?: pulumi.Input<number>;
    /**
     * The timeout seconds for each SakuraCloud API call. It can also be sourced from the `SAKURACLOUD_API_REQUEST_TIMEOUT`
     * environment variables, or via a shared credentials file if `profile` is specified. Default:`300`
     */
    apiRequestTimeout?: pulumi.Input<number>;
    /**
     * The root URL of SakuraCloud API. It can also be sourced from the `SAKURACLOUD_API_ROOT_URL` environment variables, or
     * via a shared credentials file if `profile` is specified. Default:`https://secure.sakura.ad.jp/cloud/zone`
     */
    apiRootUrl?: pulumi.Input<string>;
    /**
     * The name of zone to use as default for global resources. It must be provided, but it can also be sourced from the
     * `SAKURACLOUD_DEFAULT_ZONE` environment variables, or via a shared credentials file if `profile` is specified
     */
    defaultZone?: pulumi.Input<string>;
    /**
     * The flag to enable fake of SakuraCloud API call. It is for debugging or developping the provider. It can also be sourced
     * from the `FAKE_MODE` environment variables, or via a shared credentials file if `profile` is specified
     */
    fakeMode?: pulumi.Input<string>;
    /**
     * The file path used by SakuraCloud API fake driver for storing fake data. It is for debugging or developping the
     * provider. It can also be sourced from the `FAKE_STORE_PATH` environment variables, or via a shared credentials file if
     * `profile` is specified
     */
    fakeStorePath?: pulumi.Input<string>;
    /**
     * The profile name of your SakuraCloud account. Default:`default`
     */
    profile?: pulumi.Input<string>;
    /**
     * The maximum number of API call retries used when SakuraCloud API returns status code `423` or `503`. It can also be
     * sourced from the `SAKURACLOUD_RETRY_MAX` environment variables, or via a shared credentials file if `profile` is
     * specified. Default:`100`
     */
    retryMax?: pulumi.Input<number>;
    /**
     * The maximum wait interval(in seconds) for retrying API call used when SakuraCloud API returns status code `423` or
     * `503`. It can also be sourced from the `SAKURACLOUD_RETRY_WAIT_MAX` environment variables, or via a shared credentials
     * file if `profile` is specified
     */
    retryWaitMax?: pulumi.Input<number>;
    /**
     * The minimum wait interval(in seconds) for retrying API call used when SakuraCloud API returns status code `423` or
     * `503`. It can also be sourced from the `SAKURACLOUD_RETRY_WAIT_MIN` environment variables, or via a shared credentials
     * file if `profile` is specified
     */
    retryWaitMin?: pulumi.Input<number>;
    /**
     * The API secret of your SakuraCloud account. It must be provided, but it can also be sourced from the
     * `SAKURACLOUD_ACCESS_TOKEN_SECRET` environment variables, or via a shared credentials file if `profile` is specified
     */
    secret?: pulumi.Input<string>;
    /**
     * The API token of your SakuraCloud account. It must be provided, but it can also be sourced from the
     * `SAKURACLOUD_ACCESS_TOKEN` environment variables, or via a shared credentials file if `profile` is specified
     */
    token?: pulumi.Input<string>;
    /**
     * The flag to enable output trace log. It can also be sourced from the `SAKURACLOUD_TRACE` environment variables, or via a
     * shared credentials file if `profile` is specified
     */
    trace?: pulumi.Input<string>;
    /**
     * The name of zone to use as default. It must be provided, but it can also be sourced from the `SAKURACLOUD_ZONE`
     * environment variables, or via a shared credentials file if `profile` is specified
     */
    zone?: pulumi.Input<string>;
    /**
     * A list of available SakuraCloud zone name. It can also be sourced via a shared credentials file if `profile` is
     * specified. Default:[`is1a`, `is1b`, `tk1a`, `tk1v`]
     */
    zones?: pulumi.Input<pulumi.Input<string>[]>;
}
