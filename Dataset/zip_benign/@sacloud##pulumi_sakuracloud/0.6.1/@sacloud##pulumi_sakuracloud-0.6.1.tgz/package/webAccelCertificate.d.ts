import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud sakuracloud_webaccel_certificate.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 * import * from "fs";
 *
 * const site = sakuracloud.getWebAccel({
 *     name: "your-site-name",
 * });
 * const foobar = new sakuracloud.WebAccelCertificate("foobar", {
 *     siteId: site.then(site => site.id),
 *     certificateChain: fs.readFileSync("path/to/your/certificate/chain"),
 *     privateKey: fs.readFileSync("path/to/your/private/key"),
 * });
 * ```
 */
export declare class WebAccelCertificate extends pulumi.CustomResource {
    /**
     * Get an existing WebAccelCertificate resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: WebAccelCertificateState, opts?: pulumi.CustomResourceOptions): WebAccelCertificate;
    /**
     * Returns true if the given object is an instance of WebAccelCertificate.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is WebAccelCertificate;
    /**
     * .
     */
    readonly certificateChain: pulumi.Output<string>;
    /**
     * .
     */
    readonly dnsNames: pulumi.Output<string[]>;
    /**
     * .
     */
    readonly issuerCommonName: pulumi.Output<string>;
    /**
     * .
     */
    readonly notAfter: pulumi.Output<string>;
    /**
     * .
     */
    readonly notBefore: pulumi.Output<string>;
    /**
     * .
     */
    readonly privateKey: pulumi.Output<string>;
    /**
     * .
     */
    readonly serialNumber: pulumi.Output<string>;
    /**
     * .
     */
    readonly sha256Fingerprint: pulumi.Output<string>;
    /**
     * .
     */
    readonly siteId: pulumi.Output<string>;
    /**
     * .
     */
    readonly subjectCommonName: pulumi.Output<string>;
    /**
     * Create a WebAccelCertificate resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: WebAccelCertificateArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering WebAccelCertificate resources.
 */
export interface WebAccelCertificateState {
    /**
     * .
     */
    certificateChain?: pulumi.Input<string>;
    /**
     * .
     */
    dnsNames?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * .
     */
    issuerCommonName?: pulumi.Input<string>;
    /**
     * .
     */
    notAfter?: pulumi.Input<string>;
    /**
     * .
     */
    notBefore?: pulumi.Input<string>;
    /**
     * .
     */
    privateKey?: pulumi.Input<string>;
    /**
     * .
     */
    serialNumber?: pulumi.Input<string>;
    /**
     * .
     */
    sha256Fingerprint?: pulumi.Input<string>;
    /**
     * .
     */
    siteId?: pulumi.Input<string>;
    /**
     * .
     */
    subjectCommonName?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a WebAccelCertificate resource.
 */
export interface WebAccelCertificateArgs {
    /**
     * .
     */
    certificateChain: pulumi.Input<string>;
    /**
     * .
     */
    privateKey: pulumi.Input<string>;
    /**
     * .
     */
    siteId: pulumi.Input<string>;
}
