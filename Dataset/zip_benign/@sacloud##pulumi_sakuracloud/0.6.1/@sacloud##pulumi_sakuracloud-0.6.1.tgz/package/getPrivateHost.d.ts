import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing Private Host.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getPrivateHost({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getPrivateHost(args?: GetPrivateHostArgs, opts?: pulumi.InvokeOptions): Promise<GetPrivateHostResult>;
/**
 * A collection of arguments for invoking getPrivateHost.
 */
export interface GetPrivateHostArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetPrivateHostFilter;
    /**
     * The name of zone that the PrivateHost is in (e.g. `is1a`, `tk1a`).
     */
    zone?: string;
}
/**
 * A collection of values returned by getPrivateHost.
 */
export interface GetPrivateHostResult {
    /**
     * The total number of CPUs assigned to servers on the private host.
     */
    readonly assignedCore: number;
    /**
     * The total size of memory assigned to servers on the private host.
     */
    readonly assignedMemory: number;
    /**
     * The class of the PrivateHost. This will be one of [`dynamic`/`msWindows`].
     */
    readonly class: string;
    /**
     * The description of the PrivateHost.
     */
    readonly description: string;
    readonly filter?: outputs.GetPrivateHostFilter;
    /**
     * The hostname of the private host.
     */
    readonly hostname: string;
    /**
     * The icon id attached to the PrivateHost.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the PrivateHost.
     */
    readonly name: string;
    /**
     * Any tags assigned to the PrivateHost.
     */
    readonly tags: string[];
    readonly zone: string;
}
export declare function getPrivateHostOutput(args?: GetPrivateHostOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetPrivateHostResult>;
/**
 * A collection of arguments for invoking getPrivateHost.
 */
export interface GetPrivateHostOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetPrivateHostFilterArgs>;
    /**
     * The name of zone that the PrivateHost is in (e.g. `is1a`, `tk1a`).
     */
    zone?: pulumi.Input<string>;
}
