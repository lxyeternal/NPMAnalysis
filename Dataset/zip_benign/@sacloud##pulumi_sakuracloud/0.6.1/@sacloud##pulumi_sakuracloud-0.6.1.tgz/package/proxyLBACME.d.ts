import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Manages a SakuraCloud ProxyLB ACME Setting.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobarProxyLBACME = new sakuracloud.ProxyLBACME("foobarProxyLBACME", {
 *     proxylbId: sakuracloud_proxylb.foobar.id,
 *     acceptTos: true,
 *     commonName: "www.example.com",
 *     subjectAltNames: ["www1.example.com"],
 *     updateDelaySec: 120,
 * });
 * const foobarProxyLB = sakuracloud.getProxyLB({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * });
 * ```
 */
export declare class ProxyLBACME extends pulumi.CustomResource {
    /**
     * Get an existing ProxyLBACME resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: ProxyLBACMEState, opts?: pulumi.CustomResourceOptions): ProxyLBACME;
    /**
     * Returns true if the given object is an instance of ProxyLBACME.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is ProxyLBACME;
    /**
     * The flag to accept the current Let's Encrypt terms of service(see: https://letsencrypt.org/repository/). This must be set `true` explicitly. Changing this forces a new resource to be created.
     */
    readonly acceptTos: pulumi.Output<boolean>;
    /**
     * A list of `certificate` blocks as defined below.
     */
    readonly certificates: pulumi.Output<outputs.ProxyLBACMECertificate[]>;
    /**
     * The FQDN used by ACME. This must set resolvable value. Changing this forces a new resource to be created.
     */
    readonly commonName: pulumi.Output<string>;
    /**
     * The id of the ProxyLB that set ACME settings to. Changing this forces a new resource to be created.
     */
    readonly proxylbId: pulumi.Output<string>;
    /**
     * The Subject alternative names used by ACME. Changing this forces a new resource to be created.
     */
    readonly subjectAltNames: pulumi.Output<string[] | undefined>;
    /**
     * The wait time in seconds. This typically used for waiting for a DNS propagation. Changing this forces a new resource to be created.
     */
    readonly updateDelaySec: pulumi.Output<number | undefined>;
    /**
     * Create a ProxyLBACME resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: ProxyLBACMEArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering ProxyLBACME resources.
 */
export interface ProxyLBACMEState {
    /**
     * The flag to accept the current Let's Encrypt terms of service(see: https://letsencrypt.org/repository/). This must be set `true` explicitly. Changing this forces a new resource to be created.
     */
    acceptTos?: pulumi.Input<boolean>;
    /**
     * A list of `certificate` blocks as defined below.
     */
    certificates?: pulumi.Input<pulumi.Input<inputs.ProxyLBACMECertificate>[]>;
    /**
     * The FQDN used by ACME. This must set resolvable value. Changing this forces a new resource to be created.
     */
    commonName?: pulumi.Input<string>;
    /**
     * The id of the ProxyLB that set ACME settings to. Changing this forces a new resource to be created.
     */
    proxylbId?: pulumi.Input<string>;
    /**
     * The Subject alternative names used by ACME. Changing this forces a new resource to be created.
     */
    subjectAltNames?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The wait time in seconds. This typically used for waiting for a DNS propagation. Changing this forces a new resource to be created.
     */
    updateDelaySec?: pulumi.Input<number>;
}
/**
 * The set of arguments for constructing a ProxyLBACME resource.
 */
export interface ProxyLBACMEArgs {
    /**
     * The flag to accept the current Let's Encrypt terms of service(see: https://letsencrypt.org/repository/). This must be set `true` explicitly. Changing this forces a new resource to be created.
     */
    acceptTos: pulumi.Input<boolean>;
    /**
     * The FQDN used by ACME. This must set resolvable value. Changing this forces a new resource to be created.
     */
    commonName: pulumi.Input<string>;
    /**
     * The id of the ProxyLB that set ACME settings to. Changing this forces a new resource to be created.
     */
    proxylbId: pulumi.Input<string>;
    /**
     * The Subject alternative names used by ACME. Changing this forces a new resource to be created.
     */
    subjectAltNames?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The wait time in seconds. This typically used for waiting for a DNS propagation. Changing this forces a new resource to be created.
     */
    updateDelaySec?: pulumi.Input<number>;
}
