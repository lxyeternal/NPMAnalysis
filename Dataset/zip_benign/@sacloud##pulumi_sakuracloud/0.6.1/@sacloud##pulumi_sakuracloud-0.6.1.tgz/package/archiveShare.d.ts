import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud Archive Sharing.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const source = new sakuracloud.Archive("source", {
 *     size: 20,
 *     archiveFile: "test/dummy.raw",
 * });
 * const shareInfo = new sakuracloud.ArchiveShare("shareInfo", {archiveId: source.id});
 * ```
 */
export declare class ArchiveShare extends pulumi.CustomResource {
    /**
     * Get an existing ArchiveShare resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: ArchiveShareState, opts?: pulumi.CustomResourceOptions): ArchiveShare;
    /**
     * Returns true if the given object is an instance of ArchiveShare.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is ArchiveShare;
    /**
     * The id of the archive. Changing this forces a new resource to be created.
     */
    readonly archiveId: pulumi.Output<string>;
    /**
     * The key to use sharing the Archive.
     */
    readonly shareKey: pulumi.Output<string>;
    /**
     * The name of zone that the ArchiveShare will be created (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    readonly zone: pulumi.Output<string>;
    /**
     * Create a ArchiveShare resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: ArchiveShareArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering ArchiveShare resources.
 */
export interface ArchiveShareState {
    /**
     * The id of the archive. Changing this forces a new resource to be created.
     */
    archiveId?: pulumi.Input<string>;
    /**
     * The key to use sharing the Archive.
     */
    shareKey?: pulumi.Input<string>;
    /**
     * The name of zone that the ArchiveShare will be created (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a ArchiveShare resource.
 */
export interface ArchiveShareArgs {
    /**
     * The id of the archive. Changing this forces a new resource to be created.
     */
    archiveId: pulumi.Input<string>;
    /**
     * The name of zone that the ArchiveShare will be created (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
