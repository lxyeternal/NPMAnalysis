import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Manages a SakuraCloud Simple Monitor.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = new sakuracloud.SimpleMonitor("foobar", {
 *     delayLoop: 60,
 *     description: "description",
 *     healthCheck: {
 *         containsString: "ok",
 *         hostHeader: "example.com",
 *         http2: true,
 *         path: "/",
 *         port: 443,
 *         protocol: "https",
 *         sni: true,
 *         status: 200,
 *     },
 *     notifyEmailEnabled: true,
 *     notifyEmailHtml: true,
 *     notifySlackEnabled: true,
 *     notifySlackWebhook: "https://hooks.slack.com/services/xxx/xxx/xxx",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 *     target: "www.example.com",
 *     timeout: 10,
 * });
 * ```
 */
export declare class SimpleMonitor extends pulumi.CustomResource {
    /**
     * Get an existing SimpleMonitor resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: SimpleMonitorState, opts?: pulumi.CustomResourceOptions): SimpleMonitor;
    /**
     * Returns true if the given object is an instance of SimpleMonitor.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is SimpleMonitor;
    /**
     * The interval in seconds between checks. This must be in the range [`60`-`3600`]. Default:`60`.
     */
    readonly delayLoop: pulumi.Output<number | undefined>;
    /**
     * The description of the SimpleMonitor. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The flag to enable monitoring by the simple monitor. Default:`true`.
     */
    readonly enabled: pulumi.Output<boolean | undefined>;
    /**
     * A `healthCheck` block as defined below.
     */
    readonly healthCheck: pulumi.Output<outputs.SimpleMonitorHealthCheck>;
    /**
     * The icon id to attach to the SimpleMonitor.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The flag to enable notification by email. Default:`true`.
     */
    readonly notifyEmailEnabled: pulumi.Output<boolean | undefined>;
    /**
     * The flag to enable HTML format instead of text format.
     */
    readonly notifyEmailHtml: pulumi.Output<boolean | undefined>;
    /**
     * The interval in hours between notification. This must be in the range [`1`-`72`]. Default:`2`.
     */
    readonly notifyInterval: pulumi.Output<number | undefined>;
    /**
     * The flag to enable notification by slack/discord.
     */
    readonly notifySlackEnabled: pulumi.Output<boolean | undefined>;
    /**
     * The webhook URL for sending notification by slack/discord.
     */
    readonly notifySlackWebhook: pulumi.Output<string | undefined>;
    /**
     * Any tags to assign to the SimpleMonitor.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * The monitoring target of the simple monitor. This must be IP address or FQDN. Changing this forces a new resource to be created.
     */
    readonly target: pulumi.Output<string>;
    /**
     * The timeout in seconds for monitoring. This must be in the range [`10`-`30`].
     */
    readonly timeout: pulumi.Output<number>;
    /**
     * Create a SimpleMonitor resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: SimpleMonitorArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering SimpleMonitor resources.
 */
export interface SimpleMonitorState {
    /**
     * The interval in seconds between checks. This must be in the range [`60`-`3600`]. Default:`60`.
     */
    delayLoop?: pulumi.Input<number>;
    /**
     * The description of the SimpleMonitor. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The flag to enable monitoring by the simple monitor. Default:`true`.
     */
    enabled?: pulumi.Input<boolean>;
    /**
     * A `healthCheck` block as defined below.
     */
    healthCheck?: pulumi.Input<inputs.SimpleMonitorHealthCheck>;
    /**
     * The icon id to attach to the SimpleMonitor.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The flag to enable notification by email. Default:`true`.
     */
    notifyEmailEnabled?: pulumi.Input<boolean>;
    /**
     * The flag to enable HTML format instead of text format.
     */
    notifyEmailHtml?: pulumi.Input<boolean>;
    /**
     * The interval in hours between notification. This must be in the range [`1`-`72`]. Default:`2`.
     */
    notifyInterval?: pulumi.Input<number>;
    /**
     * The flag to enable notification by slack/discord.
     */
    notifySlackEnabled?: pulumi.Input<boolean>;
    /**
     * The webhook URL for sending notification by slack/discord.
     */
    notifySlackWebhook?: pulumi.Input<string>;
    /**
     * Any tags to assign to the SimpleMonitor.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The monitoring target of the simple monitor. This must be IP address or FQDN. Changing this forces a new resource to be created.
     */
    target?: pulumi.Input<string>;
    /**
     * The timeout in seconds for monitoring. This must be in the range [`10`-`30`].
     */
    timeout?: pulumi.Input<number>;
}
/**
 * The set of arguments for constructing a SimpleMonitor resource.
 */
export interface SimpleMonitorArgs {
    /**
     * The interval in seconds between checks. This must be in the range [`60`-`3600`]. Default:`60`.
     */
    delayLoop?: pulumi.Input<number>;
    /**
     * The description of the SimpleMonitor. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The flag to enable monitoring by the simple monitor. Default:`true`.
     */
    enabled?: pulumi.Input<boolean>;
    /**
     * A `healthCheck` block as defined below.
     */
    healthCheck: pulumi.Input<inputs.SimpleMonitorHealthCheck>;
    /**
     * The icon id to attach to the SimpleMonitor.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The flag to enable notification by email. Default:`true`.
     */
    notifyEmailEnabled?: pulumi.Input<boolean>;
    /**
     * The flag to enable HTML format instead of text format.
     */
    notifyEmailHtml?: pulumi.Input<boolean>;
    /**
     * The interval in hours between notification. This must be in the range [`1`-`72`]. Default:`2`.
     */
    notifyInterval?: pulumi.Input<number>;
    /**
     * The flag to enable notification by slack/discord.
     */
    notifySlackEnabled?: pulumi.Input<boolean>;
    /**
     * The webhook URL for sending notification by slack/discord.
     */
    notifySlackWebhook?: pulumi.Input<string>;
    /**
     * Any tags to assign to the SimpleMonitor.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The monitoring target of the simple monitor. This must be IP address or FQDN. Changing this forces a new resource to be created.
     */
    target: pulumi.Input<string>;
    /**
     * The timeout in seconds for monitoring. This must be in the range [`10`-`30`].
     */
    timeout?: pulumi.Input<number>;
}
