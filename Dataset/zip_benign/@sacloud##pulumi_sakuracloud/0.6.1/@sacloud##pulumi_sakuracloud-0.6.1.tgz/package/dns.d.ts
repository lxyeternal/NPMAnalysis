import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Manages a SakuraCloud DNS.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = new sakuracloud.DNS("foobar", {
 *     description: "description",
 *     records: [
 *         {
 *             name: "www",
 *             type: "A",
 *             value: "192.168.11.1",
 *         },
 *         {
 *             name: "www",
 *             type: "A",
 *             value: "192.168.11.2",
 *         },
 *     ],
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 *     zone: "example.com",
 * });
 * ```
 */
export declare class DNS extends pulumi.CustomResource {
    /**
     * Get an existing DNS resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: DNSState, opts?: pulumi.CustomResourceOptions): DNS;
    /**
     * Returns true if the given object is an instance of DNS.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is DNS;
    /**
     * The description of the DNS. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * A list of IP address of DNS server that manage this zone.
     */
    readonly dnsServers: pulumi.Output<string[]>;
    /**
     * The icon id to attach to the DNS.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * One or more `record` blocks as defined below.
     */
    readonly records: pulumi.Output<outputs.DNSRecord[]>;
    /**
     * Any tags to assign to the DNS.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * The target zone. (e.g. `example.com`). Changing this forces a new resource to be created.
     */
    readonly zone: pulumi.Output<string>;
    /**
     * Create a DNS resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: DNSArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering DNS resources.
 */
export interface DNSState {
    /**
     * The description of the DNS. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * A list of IP address of DNS server that manage this zone.
     */
    dnsServers?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The icon id to attach to the DNS.
     */
    iconId?: pulumi.Input<string>;
    /**
     * One or more `record` blocks as defined below.
     */
    records?: pulumi.Input<pulumi.Input<inputs.DNSRecord>[]>;
    /**
     * Any tags to assign to the DNS.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The target zone. (e.g. `example.com`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a DNS resource.
 */
export interface DNSArgs {
    /**
     * The description of the DNS. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the DNS.
     */
    iconId?: pulumi.Input<string>;
    /**
     * One or more `record` blocks as defined below.
     */
    records?: pulumi.Input<pulumi.Input<inputs.DNSRecord>[]>;
    /**
     * Any tags to assign to the DNS.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The target zone. (e.g. `example.com`). Changing this forces a new resource to be created.
     */
    zone: pulumi.Input<string>;
}
