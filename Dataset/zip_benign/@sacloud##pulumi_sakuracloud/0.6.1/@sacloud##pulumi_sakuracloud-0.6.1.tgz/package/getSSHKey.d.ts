import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing SSH Key.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getSSHKey({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getSSHKey(args?: GetSSHKeyArgs, opts?: pulumi.InvokeOptions): Promise<GetSSHKeyResult>;
/**
 * A collection of arguments for invoking getSSHKey.
 */
export interface GetSSHKeyArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetSSHKeyFilter;
}
/**
 * A collection of values returned by getSSHKey.
 */
export interface GetSSHKeyResult {
    /**
     * The description of the SSHKey.
     */
    readonly description: string;
    readonly filter?: outputs.GetSSHKeyFilter;
    /**
     * The fingerprint of public key.
     */
    readonly fingerprint: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the SSHKey.
     */
    readonly name: string;
    /**
     * The value of public key.
     */
    readonly publicKey: string;
}
export declare function getSSHKeyOutput(args?: GetSSHKeyOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetSSHKeyResult>;
/**
 * A collection of arguments for invoking getSSHKey.
 */
export interface GetSSHKeyOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetSSHKeyFilterArgs>;
}
