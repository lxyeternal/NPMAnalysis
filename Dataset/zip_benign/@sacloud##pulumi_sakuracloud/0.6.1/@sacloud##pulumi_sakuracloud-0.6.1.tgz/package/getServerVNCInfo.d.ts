import * as pulumi from "@pulumi/pulumi";
/**
 * Get information about VNC for connecting to an existing Server.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = sakuracloud.getServerVNCInfo({
 *     serverId: sakuracloud_server.foobar.id,
 * });
 * ```
 */
export declare function getServerVNCInfo(args: GetServerVNCInfoArgs, opts?: pulumi.InvokeOptions): Promise<GetServerVNCInfoResult>;
/**
 * A collection of arguments for invoking getServerVNCInfo.
 */
export interface GetServerVNCInfoArgs {
    /**
     * The id of the Server.
     */
    serverId: string;
    /**
     * The name of zone that the Server is in (e.g. `is1a`, `tk1a`).
     */
    zone?: string;
}
/**
 * A collection of values returned by getServerVNCInfo.
 */
export interface GetServerVNCInfoResult {
    /**
     * The host name for connecting by VNC.
     */
    readonly host: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The password for connecting by VNC.
     */
    readonly password: string;
    /**
     * The port number for connecting by VNC.
     */
    readonly port: number;
    readonly serverId: string;
    readonly zone: string;
}
export declare function getServerVNCInfoOutput(args: GetServerVNCInfoOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetServerVNCInfoResult>;
/**
 * A collection of arguments for invoking getServerVNCInfo.
 */
export interface GetServerVNCInfoOutputArgs {
    /**
     * The id of the Server.
     */
    serverId: pulumi.Input<string>;
    /**
     * The name of zone that the Server is in (e.g. `is1a`, `tk1a`).
     */
    zone?: pulumi.Input<string>;
}
