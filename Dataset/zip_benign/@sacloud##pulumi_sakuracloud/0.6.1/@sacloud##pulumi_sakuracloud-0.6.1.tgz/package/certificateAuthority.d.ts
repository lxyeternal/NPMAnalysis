import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Manages a SakuraCloud sakuracloud_certificate_authority.
 */
export declare class CertificateAuthority extends pulumi.CustomResource {
    /**
     * Get an existing CertificateAuthority resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: CertificateAuthorityState, opts?: pulumi.CustomResourceOptions): CertificateAuthority;
    /**
     * Returns true if the given object is an instance of CertificateAuthority.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is CertificateAuthority;
    /**
     * The body of the CA's certificate in PEM format.
     */
    readonly certificate: pulumi.Output<string>;
    /**
     * One or more `client` blocks as defined below.
     */
    readonly clients: pulumi.Output<outputs.CertificateAuthorityClient[] | undefined>;
    /**
     * The URL of the CRL.
     */
    readonly crlUrl: pulumi.Output<string>;
    /**
     * The description of the Certificate Authority. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The icon id to attach to the Certificate Authority.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The name of the Certificate Authority. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * The date on which the certificate validity period ends, in RFC3339 format.
     */
    readonly notAfter: pulumi.Output<string>;
    /**
     * The date on which the certificate validity period begins, in RFC3339 format.
     */
    readonly notBefore: pulumi.Output<string>;
    /**
     * The body of the CA's certificate in PEM format.
     */
    readonly serialNumber: pulumi.Output<string>;
    /**
     * One or more `server` blocks as defined below.
     */
    readonly servers: pulumi.Output<outputs.CertificateAuthorityServer[] | undefined>;
    /**
     * A `subject` block as defined below. Changing this forces a new resource to be created.
     */
    readonly subject: pulumi.Output<outputs.CertificateAuthoritySubject>;
    /**
     * Any tags to assign to the Certificate Authority.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * The number of hours after initial issuing that the certificate will become invalid. Changing this forces a new resource to be created.
     */
    readonly validityPeriodHours: pulumi.Output<number>;
    /**
     * Create a CertificateAuthority resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: CertificateAuthorityArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering CertificateAuthority resources.
 */
export interface CertificateAuthorityState {
    /**
     * The body of the CA's certificate in PEM format.
     */
    certificate?: pulumi.Input<string>;
    /**
     * One or more `client` blocks as defined below.
     */
    clients?: pulumi.Input<pulumi.Input<inputs.CertificateAuthorityClient>[]>;
    /**
     * The URL of the CRL.
     */
    crlUrl?: pulumi.Input<string>;
    /**
     * The description of the Certificate Authority. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the Certificate Authority.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the Certificate Authority. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The date on which the certificate validity period ends, in RFC3339 format.
     */
    notAfter?: pulumi.Input<string>;
    /**
     * The date on which the certificate validity period begins, in RFC3339 format.
     */
    notBefore?: pulumi.Input<string>;
    /**
     * The body of the CA's certificate in PEM format.
     */
    serialNumber?: pulumi.Input<string>;
    /**
     * One or more `server` blocks as defined below.
     */
    servers?: pulumi.Input<pulumi.Input<inputs.CertificateAuthorityServer>[]>;
    /**
     * A `subject` block as defined below. Changing this forces a new resource to be created.
     */
    subject?: pulumi.Input<inputs.CertificateAuthoritySubject>;
    /**
     * Any tags to assign to the Certificate Authority.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The number of hours after initial issuing that the certificate will become invalid. Changing this forces a new resource to be created.
     */
    validityPeriodHours?: pulumi.Input<number>;
}
/**
 * The set of arguments for constructing a CertificateAuthority resource.
 */
export interface CertificateAuthorityArgs {
    /**
     * One or more `client` blocks as defined below.
     */
    clients?: pulumi.Input<pulumi.Input<inputs.CertificateAuthorityClient>[]>;
    /**
     * The description of the Certificate Authority. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the Certificate Authority.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the Certificate Authority. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * One or more `server` blocks as defined below.
     */
    servers?: pulumi.Input<pulumi.Input<inputs.CertificateAuthorityServer>[]>;
    /**
     * A `subject` block as defined below. Changing this forces a new resource to be created.
     */
    subject: pulumi.Input<inputs.CertificateAuthoritySubject>;
    /**
     * Any tags to assign to the Certificate Authority.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The number of hours after initial issuing that the certificate will become invalid. Changing this forces a new resource to be created.
     */
    validityPeriodHours: pulumi.Input<number>;
}
