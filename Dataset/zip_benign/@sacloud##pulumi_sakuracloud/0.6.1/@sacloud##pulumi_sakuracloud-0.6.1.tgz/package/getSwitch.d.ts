import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing Switch.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getSwitch({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getSwitch(args?: GetSwitchArgs, opts?: pulumi.InvokeOptions): Promise<GetSwitchResult>;
/**
 * A collection of arguments for invoking getSwitch.
 */
export interface GetSwitchArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetSwitchFilter;
    /**
     * The name of zone that the Switch is in (e.g. `is1a`, `tk1a`).
     */
    zone?: string;
}
/**
 * A collection of values returned by getSwitch.
 */
export interface GetSwitchResult {
    /**
     * The bridge id attached to the Switch.
     */
    readonly bridgeId: string;
    /**
     * The description of the Switch.
     */
    readonly description: string;
    readonly filter?: outputs.GetSwitchFilter;
    /**
     * The icon id attached to the Switch.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the Switch.
     */
    readonly name: string;
    /**
     * A list of server id connected to the Switch.
     */
    readonly serverIds: string[];
    /**
     * Any tags assigned to the Switch.
     */
    readonly tags: string[];
    readonly zone: string;
}
export declare function getSwitchOutput(args?: GetSwitchOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetSwitchResult>;
/**
 * A collection of arguments for invoking getSwitch.
 */
export interface GetSwitchOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetSwitchFilterArgs>;
    /**
     * The name of zone that the Switch is in (e.g. `is1a`, `tk1a`).
     */
    zone?: pulumi.Input<string>;
}
