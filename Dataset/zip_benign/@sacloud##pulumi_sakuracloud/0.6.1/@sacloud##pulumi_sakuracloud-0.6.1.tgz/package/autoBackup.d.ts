import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud Auto Backup.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobarDisk = new sakuracloud.Disk("foobarDisk", {});
 * const foobarAutoBackup = new sakuracloud.AutoBackup("foobarAutoBackup", {
 *     diskId: foobarDisk.id,
 *     weekdays: [
 *         "mon",
 *         "tue",
 *         "wed",
 *         "thu",
 *         "fri",
 *         "sat",
 *         "sun",
 *     ],
 *     maxBackupNum: 5,
 *     description: "description",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 * });
 * ```
 */
export declare class AutoBackup extends pulumi.CustomResource {
    /**
     * Get an existing AutoBackup resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: AutoBackupState, opts?: pulumi.CustomResourceOptions): AutoBackup;
    /**
     * Returns true if the given object is an instance of AutoBackup.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is AutoBackup;
    /**
     * The description of the AutoBackup. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The disk id to backed up. Changing this forces a new resource to be created.
     */
    readonly diskId: pulumi.Output<string>;
    /**
     * The icon id to attach to the AutoBackup.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The number backup files to keep. This must be in the range [`1`-`10`]. Default:`1`.
     */
    readonly maxBackupNum: pulumi.Output<number | undefined>;
    /**
     * The name of the AutoBackup. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * Any tags to assign to the AutoBackup.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * A list of weekdays to backed up. The values in the list must be in [`sun`/`mon`/`tue`/`wed`/`thu`/`fri`/`sat`].
     */
    readonly weekdays: pulumi.Output<string[]>;
    /**
     * The name of zone that the AutoBackup will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    readonly zone: pulumi.Output<string>;
    /**
     * Create a AutoBackup resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: AutoBackupArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering AutoBackup resources.
 */
export interface AutoBackupState {
    /**
     * The description of the AutoBackup. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The disk id to backed up. Changing this forces a new resource to be created.
     */
    diskId?: pulumi.Input<string>;
    /**
     * The icon id to attach to the AutoBackup.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The number backup files to keep. This must be in the range [`1`-`10`]. Default:`1`.
     */
    maxBackupNum?: pulumi.Input<number>;
    /**
     * The name of the AutoBackup. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * Any tags to assign to the AutoBackup.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * A list of weekdays to backed up. The values in the list must be in [`sun`/`mon`/`tue`/`wed`/`thu`/`fri`/`sat`].
     */
    weekdays?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of zone that the AutoBackup will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a AutoBackup resource.
 */
export interface AutoBackupArgs {
    /**
     * The description of the AutoBackup. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The disk id to backed up. Changing this forces a new resource to be created.
     */
    diskId: pulumi.Input<string>;
    /**
     * The icon id to attach to the AutoBackup.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The number backup files to keep. This must be in the range [`1`-`10`]. Default:`1`.
     */
    maxBackupNum?: pulumi.Input<number>;
    /**
     * The name of the AutoBackup. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * Any tags to assign to the AutoBackup.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * A list of weekdays to backed up. The values in the list must be in [`sun`/`mon`/`tue`/`wed`/`thu`/`fri`/`sat`].
     */
    weekdays: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of zone that the AutoBackup will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
