import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing DNS.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getDNS({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getDNS(args?: GetDNSArgs, opts?: pulumi.InvokeOptions): Promise<GetDNSResult>;
/**
 * A collection of arguments for invoking getDNS.
 */
export interface GetDNSArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetDNSFilter;
}
/**
 * A collection of values returned by getDNS.
 */
export interface GetDNSResult {
    /**
     * The description of the DNS.
     */
    readonly description: string;
    /**
     * A list of IP address of DNS server that manage this zone.
     */
    readonly dnsServers: string[];
    readonly filter?: outputs.GetDNSFilter;
    /**
     * The icon id attached to the DNS.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * A list of `record` blocks as defined below.
     */
    readonly records: outputs.GetDNSRecord[];
    /**
     * Any tags assigned to the DNS.
     */
    readonly tags: string[];
    /**
     * The name of managed domain.
     */
    readonly zone: string;
}
export declare function getDNSOutput(args?: GetDNSOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetDNSResult>;
/**
 * A collection of arguments for invoking getDNS.
 */
export interface GetDNSOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetDNSFilterArgs>;
}
