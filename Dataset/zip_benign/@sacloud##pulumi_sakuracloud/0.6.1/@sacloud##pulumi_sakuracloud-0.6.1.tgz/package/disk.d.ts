import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud Disk.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const ubuntu = sakuracloud.getArchive({
 *     osType: "ubuntu2004",
 * });
 * const foobar = new sakuracloud.Disk("foobar", {
 *     plan: "ssd",
 *     connector: "virtio",
 *     size: 20,
 *     sourceArchiveId: ubuntu.then(ubuntu => ubuntu.id),
 *     description: "description",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 * });
 * ```
 */
export declare class Disk extends pulumi.CustomResource {
    /**
     * Get an existing Disk resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: DiskState, opts?: pulumi.CustomResourceOptions): Disk;
    /**
     * Returns true if the given object is an instance of Disk.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is Disk;
    /**
     * The name of the disk connector. This must be one of [`virtio`/`ide`]. Changing this forces a new resource to be created. Default:`virtio`.
     */
    readonly connector: pulumi.Output<string | undefined>;
    /**
     * The description of the disk. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * A list of disk id. The disk will be located to different storage from these disks. Changing this forces a new resource to be created.
     */
    readonly distantFroms: pulumi.Output<string[] | undefined>;
    /**
     * The icon id to attach to the disk.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The name of the disk. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * The plan name of the disk. This must be one of [`ssd`/`hdd`]. Changing this forces a new resource to be created. Default:`ssd`.
     */
    readonly plan: pulumi.Output<string | undefined>;
    /**
     * The id of the Server connected to the disk.
     */
    readonly serverId: pulumi.Output<string>;
    /**
     * The size of disk in GiB. Changing this forces a new resource to be created. Default:`20`.
     */
    readonly size: pulumi.Output<number | undefined>;
    /**
     * The id of the source archive. This conflicts with [`sourceDiskId`]. Changing this forces a new resource to be created.
     */
    readonly sourceArchiveId: pulumi.Output<string | undefined>;
    /**
     * The id of the source disk. This conflicts with [`sourceArchiveId`]. Changing this forces a new resource to be created.
     */
    readonly sourceDiskId: pulumi.Output<string | undefined>;
    /**
     * Any tags to assign to the disk.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * The name of zone that the disk will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    readonly zone: pulumi.Output<string>;
    /**
     * Create a Disk resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args?: DiskArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering Disk resources.
 */
export interface DiskState {
    /**
     * The name of the disk connector. This must be one of [`virtio`/`ide`]. Changing this forces a new resource to be created. Default:`virtio`.
     */
    connector?: pulumi.Input<string>;
    /**
     * The description of the disk. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * A list of disk id. The disk will be located to different storage from these disks. Changing this forces a new resource to be created.
     */
    distantFroms?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The icon id to attach to the disk.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the disk. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The plan name of the disk. This must be one of [`ssd`/`hdd`]. Changing this forces a new resource to be created. Default:`ssd`.
     */
    plan?: pulumi.Input<string>;
    /**
     * The id of the Server connected to the disk.
     */
    serverId?: pulumi.Input<string>;
    /**
     * The size of disk in GiB. Changing this forces a new resource to be created. Default:`20`.
     */
    size?: pulumi.Input<number>;
    /**
     * The id of the source archive. This conflicts with [`sourceDiskId`]. Changing this forces a new resource to be created.
     */
    sourceArchiveId?: pulumi.Input<string>;
    /**
     * The id of the source disk. This conflicts with [`sourceArchiveId`]. Changing this forces a new resource to be created.
     */
    sourceDiskId?: pulumi.Input<string>;
    /**
     * Any tags to assign to the disk.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of zone that the disk will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a Disk resource.
 */
export interface DiskArgs {
    /**
     * The name of the disk connector. This must be one of [`virtio`/`ide`]. Changing this forces a new resource to be created. Default:`virtio`.
     */
    connector?: pulumi.Input<string>;
    /**
     * The description of the disk. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * A list of disk id. The disk will be located to different storage from these disks. Changing this forces a new resource to be created.
     */
    distantFroms?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The icon id to attach to the disk.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the disk. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The plan name of the disk. This must be one of [`ssd`/`hdd`]. Changing this forces a new resource to be created. Default:`ssd`.
     */
    plan?: pulumi.Input<string>;
    /**
     * The size of disk in GiB. Changing this forces a new resource to be created. Default:`20`.
     */
    size?: pulumi.Input<number>;
    /**
     * The id of the source archive. This conflicts with [`sourceDiskId`]. Changing this forces a new resource to be created.
     */
    sourceArchiveId?: pulumi.Input<string>;
    /**
     * The id of the source disk. This conflicts with [`sourceArchiveId`]. Changing this forces a new resource to be created.
     */
    sourceDiskId?: pulumi.Input<string>;
    /**
     * Any tags to assign to the disk.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of zone that the disk will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
