import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing Container Registry.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getContainerRegistry({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getContainerRegistry(args?: GetContainerRegistryArgs, opts?: pulumi.InvokeOptions): Promise<GetContainerRegistryResult>;
/**
 * A collection of arguments for invoking getContainerRegistry.
 */
export interface GetContainerRegistryArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetContainerRegistryFilter;
}
/**
 * A collection of values returned by getContainerRegistry.
 */
export interface GetContainerRegistryResult {
    /**
     * The level of access that allow to users. This will be one of [`readwrite`/`readonly`/`none`].
     */
    readonly accessLevel: string;
    /**
     * The description of the ContainerRegistry.
     */
    readonly description: string;
    readonly filter?: outputs.GetContainerRegistryFilter;
    /**
     * The FQDN for accessing the container registry. FQDN is built from `subdomainLabel` + `.sakuracr.jp`.
     */
    readonly fqdn: string;
    /**
     * The icon id attached to the ContainerRegistry.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The user name used to authenticate remote access.
     */
    readonly name: string;
    /**
     * The label at the lowest of the FQDN used when be accessed from users.
     */
    readonly subdomainLabel: string;
    /**
     * Any tags assigned to the ContainerRegistry.
     */
    readonly tags: string[];
    /**
     * A list of `user` blocks as defined below.
     */
    readonly users: outputs.GetContainerRegistryUser[];
    /**
     * The alias for accessing the container registry.
     */
    readonly virtualDomain: string;
}
export declare function getContainerRegistryOutput(args?: GetContainerRegistryOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetContainerRegistryResult>;
/**
 * A collection of arguments for invoking getContainerRegistry.
 */
export interface GetContainerRegistryOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetContainerRegistryFilterArgs>;
}
