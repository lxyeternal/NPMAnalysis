import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud Switch+Router.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = new sakuracloud.Internet("foobar", {
 *     bandWidth: 100,
 *     description: "description",
 *     enableIpv6: false,
 *     netmask: 28,
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 * });
 * ```
 */
export declare class Internet extends pulumi.CustomResource {
    /**
     * Get an existing Internet resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: InternetState, opts?: pulumi.CustomResourceOptions): Internet;
    /**
     * Returns true if the given object is an instance of Internet.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is Internet;
    /**
     * The bandwidth of the network connected to the Internet in Mbps. This must be one of [`100`/`250`/`500`/`1000`/`1500`/`2000`/`2500`/`3000`/`3500`/`4000`/`4500`/`5000`].
     * If zone is `tk1b`, the following values can also be specified [`5500`/`6000`/`6500`/`7000`/`7500`/`8000`/`8500`/`9000`/`9500`/`10000`]. Default:`100`.
     */
    readonly bandWidth: pulumi.Output<number | undefined>;
    /**
     * The description of the Switch+Router. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The flag to enable IPv6.
     */
    readonly enableIpv6: pulumi.Output<boolean | undefined>;
    /**
     * The IP address of the gateway used by the Switch+Router.
     */
    readonly gateway: pulumi.Output<string>;
    /**
     * The icon id to attach to the Switch+Router.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * A list of assigned global address to the Switch+Router.
     */
    readonly ipAddresses: pulumi.Output<string[]>;
    /**
     * The IPv6 network address assigned to the Switch+Router.
     */
    readonly ipv6NetworkAddress: pulumi.Output<string>;
    /**
     * The network prefix of assigned IPv6 addresses to the Switch+Router.
     */
    readonly ipv6Prefix: pulumi.Output<string>;
    /**
     * The bit length of IPv6 network prefix.
     */
    readonly ipv6PrefixLen: pulumi.Output<number>;
    /**
     * Maximum IP address in assigned global addresses to the Switch+Router.
     */
    readonly maxIpAddress: pulumi.Output<string>;
    /**
     * Minimum IP address in assigned global addresses to the Switch+Router.
     */
    readonly minIpAddress: pulumi.Output<string>;
    /**
     * The name of the Switch+Router. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * The bit length of the subnet assigned to the Switch+Router. `26`/`27`/`28`. Changing this forces a new resource to be created. Default:`28`.
     */
    readonly netmask: pulumi.Output<number | undefined>;
    /**
     * The IPv4 network address assigned to the Switch+Router.
     */
    readonly networkAddress: pulumi.Output<string>;
    /**
     * A list of the ID of Servers connected to the Switch+Router.
     */
    readonly serverIds: pulumi.Output<string[]>;
    /**
     * The id of the switch.
     */
    readonly switchId: pulumi.Output<string>;
    /**
     * Any tags to assign to the Switch+Router.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * The name of zone that the Switch+Router will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    readonly zone: pulumi.Output<string>;
    /**
     * Create a Internet resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args?: InternetArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering Internet resources.
 */
export interface InternetState {
    /**
     * The bandwidth of the network connected to the Internet in Mbps. This must be one of [`100`/`250`/`500`/`1000`/`1500`/`2000`/`2500`/`3000`/`3500`/`4000`/`4500`/`5000`].
     * If zone is `tk1b`, the following values can also be specified [`5500`/`6000`/`6500`/`7000`/`7500`/`8000`/`8500`/`9000`/`9500`/`10000`]. Default:`100`.
     */
    bandWidth?: pulumi.Input<number>;
    /**
     * The description of the Switch+Router. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The flag to enable IPv6.
     */
    enableIpv6?: pulumi.Input<boolean>;
    /**
     * The IP address of the gateway used by the Switch+Router.
     */
    gateway?: pulumi.Input<string>;
    /**
     * The icon id to attach to the Switch+Router.
     */
    iconId?: pulumi.Input<string>;
    /**
     * A list of assigned global address to the Switch+Router.
     */
    ipAddresses?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The IPv6 network address assigned to the Switch+Router.
     */
    ipv6NetworkAddress?: pulumi.Input<string>;
    /**
     * The network prefix of assigned IPv6 addresses to the Switch+Router.
     */
    ipv6Prefix?: pulumi.Input<string>;
    /**
     * The bit length of IPv6 network prefix.
     */
    ipv6PrefixLen?: pulumi.Input<number>;
    /**
     * Maximum IP address in assigned global addresses to the Switch+Router.
     */
    maxIpAddress?: pulumi.Input<string>;
    /**
     * Minimum IP address in assigned global addresses to the Switch+Router.
     */
    minIpAddress?: pulumi.Input<string>;
    /**
     * The name of the Switch+Router. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The bit length of the subnet assigned to the Switch+Router. `26`/`27`/`28`. Changing this forces a new resource to be created. Default:`28`.
     */
    netmask?: pulumi.Input<number>;
    /**
     * The IPv4 network address assigned to the Switch+Router.
     */
    networkAddress?: pulumi.Input<string>;
    /**
     * A list of the ID of Servers connected to the Switch+Router.
     */
    serverIds?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The id of the switch.
     */
    switchId?: pulumi.Input<string>;
    /**
     * Any tags to assign to the Switch+Router.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of zone that the Switch+Router will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a Internet resource.
 */
export interface InternetArgs {
    /**
     * The bandwidth of the network connected to the Internet in Mbps. This must be one of [`100`/`250`/`500`/`1000`/`1500`/`2000`/`2500`/`3000`/`3500`/`4000`/`4500`/`5000`].
     * If zone is `tk1b`, the following values can also be specified [`5500`/`6000`/`6500`/`7000`/`7500`/`8000`/`8500`/`9000`/`9500`/`10000`]. Default:`100`.
     */
    bandWidth?: pulumi.Input<number>;
    /**
     * The description of the Switch+Router. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The flag to enable IPv6.
     */
    enableIpv6?: pulumi.Input<boolean>;
    /**
     * The icon id to attach to the Switch+Router.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the Switch+Router. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The bit length of the subnet assigned to the Switch+Router. `26`/`27`/`28`. Changing this forces a new resource to be created. Default:`28`.
     */
    netmask?: pulumi.Input<number>;
    /**
     * Any tags to assign to the Switch+Router.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of zone that the Switch+Router will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
