import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Manages a SakuraCloud Database.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const config = new pulumi.Config();
 * const username = config.requireObject("username");
 * const password = config.requireObject("password");
 * const replicaPassword = config.requireObject("replicaPassword");
 * const foobarSwitch = new sakuracloud.Switch("foobarSwitch", {});
 * const foobarDatabase = new sakuracloud.Database("foobarDatabase", {
 *     databaseType: "mariadb",
 *     plan: "30g",
 *     username: username,
 *     password: password,
 *     replicaPassword: replicaPassword,
 *     networkInterface: {
 *         switchId: foobarSwitch.id,
 *         ipAddress: "192.168.11.11",
 *         netmask: 24,
 *         gateway: "192.168.11.1",
 *         port: 3306,
 *         sourceRanges: [
 *             "192.168.11.0/24",
 *             "192.168.12.0/24",
 *         ],
 *     },
 *     backup: {
 *         time: "00:00",
 *         weekdays: [
 *             "mon",
 *             "tue",
 *         ],
 *     },
 *     parameters: {
 *         max_connections: 100,
 *     },
 *     description: "description",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 * });
 * ```
 */
export declare class Database extends pulumi.CustomResource {
    /**
     * Get an existing Database resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: DatabaseState, opts?: pulumi.CustomResourceOptions): Database;
    /**
     * Returns true if the given object is an instance of Database.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is Database;
    /**
     * A `backup` block as defined below.
     */
    readonly backup: pulumi.Output<outputs.DatabaseBackup | undefined>;
    /**
     * The type of the database. This must be one of [`mariadb`/`postgres`]. Changing this forces a new resource to be created. Default:`postgres`.
     */
    readonly databaseType: pulumi.Output<string | undefined>;
    /**
     * The description of the Database. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The icon id to attach to the Database.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The name of the Database. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * An `networkInterface` block as defined below.
     */
    readonly networkInterface: pulumi.Output<outputs.DatabaseNetworkInterface>;
    /**
     * The map for setting RDBMS-specific parameters. Valid keys can be found with the `usacloud database list-parameters` command.
     */
    readonly parameters: pulumi.Output<{
        [key: string]: string;
    } | undefined>;
    /**
     * The password of default user on the database.
     */
    readonly password: pulumi.Output<string>;
    /**
     * The plan name of the Database. This must be one of [`10g`/`30g`/`90g`/`240g`/`500g`/`1t`]. Changing this forces a new resource to be created. Default:`10g`.
     */
    readonly plan: pulumi.Output<string | undefined>;
    /**
     * The password of user that processing a replication.
     */
    readonly replicaPassword: pulumi.Output<string | undefined>;
    /**
     * The name of user that processing a replication. Default:`replica`.
     */
    readonly replicaUser: pulumi.Output<string | undefined>;
    /**
     * Any tags to assign to the Database.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * The name of default user on the database. The length of this value must be in the range [`3`-`20`]. Changing this forces a new resource to be created.
     */
    readonly username: pulumi.Output<string>;
    /**
     * The name of zone that the Database will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    readonly zone: pulumi.Output<string>;
    /**
     * Create a Database resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: DatabaseArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering Database resources.
 */
export interface DatabaseState {
    /**
     * A `backup` block as defined below.
     */
    backup?: pulumi.Input<inputs.DatabaseBackup>;
    /**
     * The type of the database. This must be one of [`mariadb`/`postgres`]. Changing this forces a new resource to be created. Default:`postgres`.
     */
    databaseType?: pulumi.Input<string>;
    /**
     * The description of the Database. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the Database.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the Database. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * An `networkInterface` block as defined below.
     */
    networkInterface?: pulumi.Input<inputs.DatabaseNetworkInterface>;
    /**
     * The map for setting RDBMS-specific parameters. Valid keys can be found with the `usacloud database list-parameters` command.
     */
    parameters?: pulumi.Input<{
        [key: string]: pulumi.Input<string>;
    }>;
    /**
     * The password of default user on the database.
     */
    password?: pulumi.Input<string>;
    /**
     * The plan name of the Database. This must be one of [`10g`/`30g`/`90g`/`240g`/`500g`/`1t`]. Changing this forces a new resource to be created. Default:`10g`.
     */
    plan?: pulumi.Input<string>;
    /**
     * The password of user that processing a replication.
     */
    replicaPassword?: pulumi.Input<string>;
    /**
     * The name of user that processing a replication. Default:`replica`.
     */
    replicaUser?: pulumi.Input<string>;
    /**
     * Any tags to assign to the Database.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of default user on the database. The length of this value must be in the range [`3`-`20`]. Changing this forces a new resource to be created.
     */
    username?: pulumi.Input<string>;
    /**
     * The name of zone that the Database will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a Database resource.
 */
export interface DatabaseArgs {
    /**
     * A `backup` block as defined below.
     */
    backup?: pulumi.Input<inputs.DatabaseBackup>;
    /**
     * The type of the database. This must be one of [`mariadb`/`postgres`]. Changing this forces a new resource to be created. Default:`postgres`.
     */
    databaseType?: pulumi.Input<string>;
    /**
     * The description of the Database. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the Database.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the Database. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * An `networkInterface` block as defined below.
     */
    networkInterface: pulumi.Input<inputs.DatabaseNetworkInterface>;
    /**
     * The map for setting RDBMS-specific parameters. Valid keys can be found with the `usacloud database list-parameters` command.
     */
    parameters?: pulumi.Input<{
        [key: string]: pulumi.Input<string>;
    }>;
    /**
     * The password of default user on the database.
     */
    password: pulumi.Input<string>;
    /**
     * The plan name of the Database. This must be one of [`10g`/`30g`/`90g`/`240g`/`500g`/`1t`]. Changing this forces a new resource to be created. Default:`10g`.
     */
    plan?: pulumi.Input<string>;
    /**
     * The password of user that processing a replication.
     */
    replicaPassword?: pulumi.Input<string>;
    /**
     * The name of user that processing a replication. Default:`replica`.
     */
    replicaUser?: pulumi.Input<string>;
    /**
     * Any tags to assign to the Database.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of default user on the database. The length of this value must be in the range [`3`-`20`]. Changing this forces a new resource to be created.
     */
    username: pulumi.Input<string>;
    /**
     * The name of zone that the Database will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
