import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Manages a SakuraCloud GSLB.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = new sakuracloud.GSLB("foobar", {
 *     description: "description",
 *     healthCheck: {
 *         delayLoop: 10,
 *         hostHeader: "example.com",
 *         path: "/",
 *         protocol: "http",
 *         status: "200",
 *     },
 *     servers: [
 *         {
 *             enabled: true,
 *             ipAddress: "192.2.0.11",
 *             weight: 1,
 *         },
 *         {
 *             enabled: true,
 *             ipAddress: "192.2.0.12",
 *             weight: 1,
 *         },
 *     ],
 *     sorryServer: "192.2.0.1",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 * });
 * ```
 */
export declare class GSLB extends pulumi.CustomResource {
    /**
     * Get an existing GSLB resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: GSLBState, opts?: pulumi.CustomResourceOptions): GSLB;
    /**
     * Returns true if the given object is an instance of GSLB.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is GSLB;
    /**
     * The description of the GSLB. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The FQDN for accessing to the GSLB. This is typically used as value of CNAME record.
     */
    readonly fqdn: pulumi.Output<string>;
    /**
     * A `healthCheck` block as defined below.
     */
    readonly healthCheck: pulumi.Output<outputs.GSLBHealthCheck>;
    /**
     * The icon id to attach to the GSLB.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The name of the GSLB. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * One or more `server` blocks as defined below.
     */
    readonly servers: pulumi.Output<outputs.GSLBServer[] | undefined>;
    /**
     * The IP address of the SorryServer. This will be used when all servers are down.
     */
    readonly sorryServer: pulumi.Output<string | undefined>;
    /**
     * Any tags to assign to the GSLB.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * The flag to enable weighted load-balancing.
     */
    readonly weighted: pulumi.Output<boolean | undefined>;
    /**
     * Create a GSLB resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: GSLBArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering GSLB resources.
 */
export interface GSLBState {
    /**
     * The description of the GSLB. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The FQDN for accessing to the GSLB. This is typically used as value of CNAME record.
     */
    fqdn?: pulumi.Input<string>;
    /**
     * A `healthCheck` block as defined below.
     */
    healthCheck?: pulumi.Input<inputs.GSLBHealthCheck>;
    /**
     * The icon id to attach to the GSLB.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the GSLB. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * One or more `server` blocks as defined below.
     */
    servers?: pulumi.Input<pulumi.Input<inputs.GSLBServer>[]>;
    /**
     * The IP address of the SorryServer. This will be used when all servers are down.
     */
    sorryServer?: pulumi.Input<string>;
    /**
     * Any tags to assign to the GSLB.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The flag to enable weighted load-balancing.
     */
    weighted?: pulumi.Input<boolean>;
}
/**
 * The set of arguments for constructing a GSLB resource.
 */
export interface GSLBArgs {
    /**
     * The description of the GSLB. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * A `healthCheck` block as defined below.
     */
    healthCheck: pulumi.Input<inputs.GSLBHealthCheck>;
    /**
     * The icon id to attach to the GSLB.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the GSLB. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * One or more `server` blocks as defined below.
     */
    servers?: pulumi.Input<pulumi.Input<inputs.GSLBServer>[]>;
    /**
     * The IP address of the SorryServer. This will be used when all servers are down.
     */
    sorryServer?: pulumi.Input<string>;
    /**
     * Any tags to assign to the GSLB.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The flag to enable weighted load-balancing.
     */
    weighted?: pulumi.Input<boolean>;
}
