import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Manages a SakuraCloud Container Registry.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const config = new pulumi.Config();
 * const users = config.getObject("users") || [
 *     {
 *         name: "user1",
 *         password: "password1",
 *         permission: "all",
 *     },
 *     {
 *         name: "user2",
 *         password: "password2",
 *         permission: "readwrite",
 *     },
 * ];
 * const foobar = new sakuracloud.ContainerRegistry("foobar", {
 *     subdomainLabel: "your-subdomain-label",
 *     accessLevel: "readwrite",
 *     description: "description",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 *     dynamic: [{
 *         forEach: users,
 *         content: [{
 *             name: user.value.name,
 *             password: user.value.password,
 *             permission: user.value.permission,
 *         }],
 *     }],
 * });
 * ```
 */
export declare class ContainerRegistry extends pulumi.CustomResource {
    /**
     * Get an existing ContainerRegistry resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: ContainerRegistryState, opts?: pulumi.CustomResourceOptions): ContainerRegistry;
    /**
     * Returns true if the given object is an instance of ContainerRegistry.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is ContainerRegistry;
    /**
     * The level of access that allow to users. This must be one of [`readwrite`/`readonly`/`none`].
     */
    readonly accessLevel: pulumi.Output<string>;
    /**
     * The description of the Container Registry. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The FQDN for accessing the Container Registry. FQDN is built from `subdomainLabel` + `.sakuracr.jp`.
     */
    readonly fqdn: pulumi.Output<string>;
    /**
     * The icon id to attach to the Container Registry.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The name of the Container Registry. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * The label at the lowest of the FQDN used when be accessed from users. The length of this value must be in the range [`1`-`64`]. Changing this forces a new resource to be created.
     */
    readonly subdomainLabel: pulumi.Output<string>;
    /**
     * Any tags to assign to the Container Registry.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * One or more `user` blocks as defined below.
     */
    readonly users: pulumi.Output<outputs.ContainerRegistryUser[] | undefined>;
    /**
     * The alias for accessing the container registry.
     */
    readonly virtualDomain: pulumi.Output<string | undefined>;
    /**
     * Create a ContainerRegistry resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: ContainerRegistryArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering ContainerRegistry resources.
 */
export interface ContainerRegistryState {
    /**
     * The level of access that allow to users. This must be one of [`readwrite`/`readonly`/`none`].
     */
    accessLevel?: pulumi.Input<string>;
    /**
     * The description of the Container Registry. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The FQDN for accessing the Container Registry. FQDN is built from `subdomainLabel` + `.sakuracr.jp`.
     */
    fqdn?: pulumi.Input<string>;
    /**
     * The icon id to attach to the Container Registry.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the Container Registry. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The label at the lowest of the FQDN used when be accessed from users. The length of this value must be in the range [`1`-`64`]. Changing this forces a new resource to be created.
     */
    subdomainLabel?: pulumi.Input<string>;
    /**
     * Any tags to assign to the Container Registry.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * One or more `user` blocks as defined below.
     */
    users?: pulumi.Input<pulumi.Input<inputs.ContainerRegistryUser>[]>;
    /**
     * The alias for accessing the container registry.
     */
    virtualDomain?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a ContainerRegistry resource.
 */
export interface ContainerRegistryArgs {
    /**
     * The level of access that allow to users. This must be one of [`readwrite`/`readonly`/`none`].
     */
    accessLevel: pulumi.Input<string>;
    /**
     * The description of the Container Registry. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the Container Registry.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the Container Registry. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The label at the lowest of the FQDN used when be accessed from users. The length of this value must be in the range [`1`-`64`]. Changing this forces a new resource to be created.
     */
    subdomainLabel: pulumi.Input<string>;
    /**
     * Any tags to assign to the Container Registry.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * One or more `user` blocks as defined below.
     */
    users?: pulumi.Input<pulumi.Input<inputs.ContainerRegistryUser>[]>;
    /**
     * The alias for accessing the container registry.
     */
    virtualDomain?: pulumi.Input<string>;
}
