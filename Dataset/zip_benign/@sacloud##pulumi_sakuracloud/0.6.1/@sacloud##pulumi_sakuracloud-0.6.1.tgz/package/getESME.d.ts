import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing ESME.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getESME({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getESME(args?: GetESMEArgs, opts?: pulumi.InvokeOptions): Promise<GetESMEResult>;
/**
 * A collection of arguments for invoking getESME.
 */
export interface GetESMEArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetESMEFilter;
}
/**
 * A collection of values returned by getESME.
 */
export interface GetESMEResult {
    /**
     * The description of the ESME.
     */
    readonly description: string;
    readonly filter?: outputs.GetESMEFilter;
    /**
     * The icon id attached to the ESME.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the ESME.
     */
    readonly name: string;
    /**
     * The API URL for send SMS with generated OTP.
     */
    readonly sendMessageWithGeneratedOtpApiUrl: string;
    /**
     * The API URL for send SMS with inputted OTP.
     */
    readonly sendMessageWithInputtedOtpApiUrl: string;
    /**
     * Any tags assigned to the ESME.
     */
    readonly tags: string[];
}
export declare function getESMEOutput(args?: GetESMEOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetESMEResult>;
/**
 * A collection of arguments for invoking getESME.
 */
export interface GetESMEOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetESMEFilterArgs>;
}
