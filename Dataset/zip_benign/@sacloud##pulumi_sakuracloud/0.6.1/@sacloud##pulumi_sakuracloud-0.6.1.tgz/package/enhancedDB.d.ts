import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud sakuracloud_enhanced_db.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = new sakuracloud.EnhancedDB("foobar", {
 *     databaseName: "example",
 *     description: "...",
 *     password: "your-password",
 *     tags: [
 *         "...",
 *         "...",
 *     ],
 * });
 * ```
 */
export declare class EnhancedDB extends pulumi.CustomResource {
    /**
     * Get an existing EnhancedDB resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: EnhancedDBState, opts?: pulumi.CustomResourceOptions): EnhancedDB;
    /**
     * Returns true if the given object is an instance of EnhancedDB.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is EnhancedDB;
    /**
     * The name of database. Changing this forces a new resource to be created.
     */
    readonly databaseName: pulumi.Output<string>;
    /**
     * The type of database.
     */
    readonly databaseType: pulumi.Output<string>;
    /**
     * The description of the Enhanced Database. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The name of database host. This will be built from `databaseName` + `tidb-is1.db.sakurausercontent.com`.
     */
    readonly hostname: pulumi.Output<string>;
    /**
     * The icon id to attach to the Enhanced Database.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The value of max connections setting.
     */
    readonly maxConnections: pulumi.Output<number>;
    /**
     * The name of the Enhanced Database. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * The password of database.
     */
    readonly password: pulumi.Output<string>;
    /**
     * The region name.
     */
    readonly region: pulumi.Output<string>;
    /**
     * Any tags to assign to the Enhanced Database.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * Create a EnhancedDB resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: EnhancedDBArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering EnhancedDB resources.
 */
export interface EnhancedDBState {
    /**
     * The name of database. Changing this forces a new resource to be created.
     */
    databaseName?: pulumi.Input<string>;
    /**
     * The type of database.
     */
    databaseType?: pulumi.Input<string>;
    /**
     * The description of the Enhanced Database. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The name of database host. This will be built from `databaseName` + `tidb-is1.db.sakurausercontent.com`.
     */
    hostname?: pulumi.Input<string>;
    /**
     * The icon id to attach to the Enhanced Database.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The value of max connections setting.
     */
    maxConnections?: pulumi.Input<number>;
    /**
     * The name of the Enhanced Database. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The password of database.
     */
    password?: pulumi.Input<string>;
    /**
     * The region name.
     */
    region?: pulumi.Input<string>;
    /**
     * Any tags to assign to the Enhanced Database.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
}
/**
 * The set of arguments for constructing a EnhancedDB resource.
 */
export interface EnhancedDBArgs {
    /**
     * The name of database. Changing this forces a new resource to be created.
     */
    databaseName: pulumi.Input<string>;
    /**
     * The description of the Enhanced Database. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the Enhanced Database.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the Enhanced Database. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The password of database.
     */
    password: pulumi.Input<string>;
    /**
     * Any tags to assign to the Enhanced Database.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
}
