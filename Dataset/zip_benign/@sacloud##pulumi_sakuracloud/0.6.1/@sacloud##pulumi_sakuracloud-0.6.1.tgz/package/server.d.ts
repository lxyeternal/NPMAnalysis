import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Manages a SakuraCloud Server.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobarPacketFilter = sakuracloud.getPacketFilter({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * });
 * const ubuntu = sakuracloud.getArchive({
 *     osType: "ubuntu2004",
 * });
 * const foobarDisk = new sakuracloud.Disk("foobarDisk", {sourceArchiveId: ubuntu.then(ubuntu => ubuntu.id)});
 * const foobarServer = new sakuracloud.Server("foobarServer", {
 *     disks: [foobarDisk.id],
 *     description: "description",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 *     networkInterfaces: [{
 *         upstream: "shared",
 *         packetFilterId: foobarPacketFilter.then(foobarPacketFilter => foobarPacketFilter.id),
 *     }],
 *     diskEditParameter: {
 *         hostname: "hostname",
 *         password: "password",
 *         disablePwAuth: true,
 *     },
 * });
 * // user_data = join("\n", [
 * //   "#cloud-config",
 * //   yamlencode({
 * //     hostname: "hostname",
 * //     password: "password",
 * //     chpasswd: {
 * //       expire: false,
 * //     }
 * //     ssh_pwauth: false,
 * //     ssh_authorized_keys: [
 * //       file("~/.ssh/id_rsa.pub"),
 * //     ],
 * //   }),
 * // ])
 * ```
 */
export declare class Server extends pulumi.CustomResource {
    /**
     * Get an existing Server resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: ServerState, opts?: pulumi.CustomResourceOptions): Server;
    /**
     * Returns true if the given object is an instance of Server.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is Server;
    /**
     * The id of the CD-ROM to attach to the Server.
     */
    readonly cdromId: pulumi.Output<string | undefined>;
    /**
     * The policy of how to allocate virtual CPUs to the server. This must be one of [`standard`/`dedicatedcpu`]. Default:`standard`.
     */
    readonly commitment: pulumi.Output<string | undefined>;
    /**
     * The number of virtual CPUs. Default:`1`.
     */
    readonly core: pulumi.Output<number | undefined>;
    /**
     * The description of the Server. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * A `diskEditParameter` block as defined below. This parameter conflicts with [`userData`].
     */
    readonly diskEditParameter: pulumi.Output<outputs.ServerDiskEditParameter | undefined>;
    /**
     * A list of disk id connected to the server.
     */
    readonly disks: pulumi.Output<string[] | undefined>;
    /**
     * A list of IP address of DNS server in the zone.
     */
    readonly dnsServers: pulumi.Output<string[]>;
    /**
     * The flag to use force shutdown when need to reboot/shutdown while applying.
     */
    readonly forceShutdown: pulumi.Output<boolean | undefined>;
    /**
     * The gateway address used by the Server.
     */
    readonly gateway: pulumi.Output<string>;
    /**
     * The number of GPUs.
     */
    readonly gpu: pulumi.Output<number | undefined>;
    /**
     * The hostname of the Server. The length of this value must be in the range [`1`-`64`].
     */
    readonly hostname: pulumi.Output<string>;
    /**
     * The icon id to attach to the Server.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The driver name of network interface. This must be one of [`virtio`/`e1000`]. Default:`virtio`.
     */
    readonly interfaceDriver: pulumi.Output<string | undefined>;
    /**
     * The IP address to assign to the Server.
     */
    readonly ipAddress: pulumi.Output<string>;
    /**
     * The size of memory in GiB. Default:`1`.
     */
    readonly memory: pulumi.Output<number | undefined>;
    /**
     * The name of the Server. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * The bit length of the subnet to assign to the Server.
     */
    readonly netmask: pulumi.Output<number>;
    /**
     * The network address which the `ipAddress` belongs.
     */
    readonly networkAddress: pulumi.Output<string>;
    /**
     * One or more `networkInterface` blocks as defined below.
     */
    readonly networkInterfaces: pulumi.Output<outputs.ServerNetworkInterface[] | undefined>;
    /**
     * The id of the PrivateHost which the Server is assigned.
     */
    readonly privateHostId: pulumi.Output<string | undefined>;
    /**
     * The id of the PrivateHost which the Server is assigned.
     */
    readonly privateHostName: pulumi.Output<string>;
    /**
     * Any tags to assign to the Server.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * A string representing the user data used by cloud-init. This parameter conflicts with [`diskEditParameter`].
     */
    readonly userData: pulumi.Output<string | undefined>;
    /**
     * The name of zone that the Server will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    readonly zone: pulumi.Output<string>;
    /**
     * Create a Server resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args?: ServerArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering Server resources.
 */
export interface ServerState {
    /**
     * The id of the CD-ROM to attach to the Server.
     */
    cdromId?: pulumi.Input<string>;
    /**
     * The policy of how to allocate virtual CPUs to the server. This must be one of [`standard`/`dedicatedcpu`]. Default:`standard`.
     */
    commitment?: pulumi.Input<string>;
    /**
     * The number of virtual CPUs. Default:`1`.
     */
    core?: pulumi.Input<number>;
    /**
     * The description of the Server. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * A `diskEditParameter` block as defined below. This parameter conflicts with [`userData`].
     */
    diskEditParameter?: pulumi.Input<inputs.ServerDiskEditParameter>;
    /**
     * A list of disk id connected to the server.
     */
    disks?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * A list of IP address of DNS server in the zone.
     */
    dnsServers?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The flag to use force shutdown when need to reboot/shutdown while applying.
     */
    forceShutdown?: pulumi.Input<boolean>;
    /**
     * The gateway address used by the Server.
     */
    gateway?: pulumi.Input<string>;
    /**
     * The number of GPUs.
     */
    gpu?: pulumi.Input<number>;
    /**
     * The hostname of the Server. The length of this value must be in the range [`1`-`64`].
     */
    hostname?: pulumi.Input<string>;
    /**
     * The icon id to attach to the Server.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The driver name of network interface. This must be one of [`virtio`/`e1000`]. Default:`virtio`.
     */
    interfaceDriver?: pulumi.Input<string>;
    /**
     * The IP address to assign to the Server.
     */
    ipAddress?: pulumi.Input<string>;
    /**
     * The size of memory in GiB. Default:`1`.
     */
    memory?: pulumi.Input<number>;
    /**
     * The name of the Server. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The bit length of the subnet to assign to the Server.
     */
    netmask?: pulumi.Input<number>;
    /**
     * The network address which the `ipAddress` belongs.
     */
    networkAddress?: pulumi.Input<string>;
    /**
     * One or more `networkInterface` blocks as defined below.
     */
    networkInterfaces?: pulumi.Input<pulumi.Input<inputs.ServerNetworkInterface>[]>;
    /**
     * The id of the PrivateHost which the Server is assigned.
     */
    privateHostId?: pulumi.Input<string>;
    /**
     * The id of the PrivateHost which the Server is assigned.
     */
    privateHostName?: pulumi.Input<string>;
    /**
     * Any tags to assign to the Server.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * A string representing the user data used by cloud-init. This parameter conflicts with [`diskEditParameter`].
     */
    userData?: pulumi.Input<string>;
    /**
     * The name of zone that the Server will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a Server resource.
 */
export interface ServerArgs {
    /**
     * The id of the CD-ROM to attach to the Server.
     */
    cdromId?: pulumi.Input<string>;
    /**
     * The policy of how to allocate virtual CPUs to the server. This must be one of [`standard`/`dedicatedcpu`]. Default:`standard`.
     */
    commitment?: pulumi.Input<string>;
    /**
     * The number of virtual CPUs. Default:`1`.
     */
    core?: pulumi.Input<number>;
    /**
     * The description of the Server. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * A `diskEditParameter` block as defined below. This parameter conflicts with [`userData`].
     */
    diskEditParameter?: pulumi.Input<inputs.ServerDiskEditParameter>;
    /**
     * A list of disk id connected to the server.
     */
    disks?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The flag to use force shutdown when need to reboot/shutdown while applying.
     */
    forceShutdown?: pulumi.Input<boolean>;
    /**
     * The number of GPUs.
     */
    gpu?: pulumi.Input<number>;
    /**
     * The icon id to attach to the Server.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The driver name of network interface. This must be one of [`virtio`/`e1000`]. Default:`virtio`.
     */
    interfaceDriver?: pulumi.Input<string>;
    /**
     * The size of memory in GiB. Default:`1`.
     */
    memory?: pulumi.Input<number>;
    /**
     * The name of the Server. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * One or more `networkInterface` blocks as defined below.
     */
    networkInterfaces?: pulumi.Input<pulumi.Input<inputs.ServerNetworkInterface>[]>;
    /**
     * The id of the PrivateHost which the Server is assigned.
     */
    privateHostId?: pulumi.Input<string>;
    /**
     * Any tags to assign to the Server.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * A string representing the user data used by cloud-init. This parameter conflicts with [`diskEditParameter`].
     */
    userData?: pulumi.Input<string>;
    /**
     * The name of zone that the Server will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
