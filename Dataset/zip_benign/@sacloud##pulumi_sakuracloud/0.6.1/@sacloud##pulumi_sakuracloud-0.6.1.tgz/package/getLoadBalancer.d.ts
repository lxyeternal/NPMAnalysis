import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing Load Balancer.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getLoadBalancer({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getLoadBalancer(args?: GetLoadBalancerArgs, opts?: pulumi.InvokeOptions): Promise<GetLoadBalancerResult>;
/**
 * A collection of arguments for invoking getLoadBalancer.
 */
export interface GetLoadBalancerArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetLoadBalancerFilter;
    /**
     * The name of zone that the LoadBalancer is in (e.g. `is1a`, `tk1a`).
     */
    zone?: string;
}
/**
 * A collection of values returned by getLoadBalancer.
 */
export interface GetLoadBalancerResult {
    /**
     * The description of the VIP.
     */
    readonly description: string;
    readonly filter?: outputs.GetLoadBalancerFilter;
    /**
     * The icon id attached to the LoadBalancer.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the LoadBalancer.
     */
    readonly name: string;
    /**
     * A list of `networkInterface` blocks as defined below.
     */
    readonly networkInterfaces: outputs.GetLoadBalancerNetworkInterface[];
    /**
     * The plan name of the LoadBalancer. This will be one of [`standard`/`highspec`].
     */
    readonly plan: string;
    /**
     * Any tags assigned to the LoadBalancer.
     */
    readonly tags: string[];
    /**
     * The virtual IP address.
     */
    readonly vips: outputs.GetLoadBalancerVip[];
    readonly zone: string;
}
export declare function getLoadBalancerOutput(args?: GetLoadBalancerOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetLoadBalancerResult>;
/**
 * A collection of arguments for invoking getLoadBalancer.
 */
export interface GetLoadBalancerOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetLoadBalancerFilterArgs>;
    /**
     * The name of zone that the LoadBalancer is in (e.g. `is1a`, `tk1a`).
     */
    zone?: pulumi.Input<string>;
}
