import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud CD-ROM.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = new sakuracloud.CDROM("foobar", {
 *     description: "description",
 *     isoImageFile: "example.iso",
 *     size: 5,
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 * });
 * ```
 */
export declare class CDROM extends pulumi.CustomResource {
    /**
     * Get an existing CDROM resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: CDROMState, opts?: pulumi.CustomResourceOptions): CDROM;
    /**
     * Returns true if the given object is an instance of CDROM.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is CDROM;
    /**
     * The content to upload to as the CD-ROM. This conflicts with [`isoImageFile`].
     */
    readonly content: pulumi.Output<string | undefined>;
    /**
     * The name of content file to upload to as the CD-ROM. This is only used when `content` is specified. This conflicts with [`isoImageFile`]. Default:`config`.
     */
    readonly contentFileName: pulumi.Output<string | undefined>;
    /**
     * The description of the CD-ROM. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The md5 checksum calculated from the base64 encoded file body.
     */
    readonly hash: pulumi.Output<string>;
    /**
     * The icon id to attach to the CD-ROM.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The file path to upload to as the CD-ROM. This conflicts with [`content`].
     */
    readonly isoImageFile: pulumi.Output<string | undefined>;
    /**
     * The name of the CD-ROM. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * The size of CD-ROM in GiB. This must be one of [`5`/`10`]. Changing this forces a new resource to be created. Default:`5`.
     */
    readonly size: pulumi.Output<number | undefined>;
    /**
     * Any tags to assign to the CD-ROM.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * The name of zone that the CD-ROM will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    readonly zone: pulumi.Output<string>;
    /**
     * Create a CDROM resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args?: CDROMArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering CDROM resources.
 */
export interface CDROMState {
    /**
     * The content to upload to as the CD-ROM. This conflicts with [`isoImageFile`].
     */
    content?: pulumi.Input<string>;
    /**
     * The name of content file to upload to as the CD-ROM. This is only used when `content` is specified. This conflicts with [`isoImageFile`]. Default:`config`.
     */
    contentFileName?: pulumi.Input<string>;
    /**
     * The description of the CD-ROM. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The md5 checksum calculated from the base64 encoded file body.
     */
    hash?: pulumi.Input<string>;
    /**
     * The icon id to attach to the CD-ROM.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The file path to upload to as the CD-ROM. This conflicts with [`content`].
     */
    isoImageFile?: pulumi.Input<string>;
    /**
     * The name of the CD-ROM. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The size of CD-ROM in GiB. This must be one of [`5`/`10`]. Changing this forces a new resource to be created. Default:`5`.
     */
    size?: pulumi.Input<number>;
    /**
     * Any tags to assign to the CD-ROM.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of zone that the CD-ROM will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a CDROM resource.
 */
export interface CDROMArgs {
    /**
     * The content to upload to as the CD-ROM. This conflicts with [`isoImageFile`].
     */
    content?: pulumi.Input<string>;
    /**
     * The name of content file to upload to as the CD-ROM. This is only used when `content` is specified. This conflicts with [`isoImageFile`]. Default:`config`.
     */
    contentFileName?: pulumi.Input<string>;
    /**
     * The description of the CD-ROM. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The md5 checksum calculated from the base64 encoded file body.
     */
    hash?: pulumi.Input<string>;
    /**
     * The icon id to attach to the CD-ROM.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The file path to upload to as the CD-ROM. This conflicts with [`content`].
     */
    isoImageFile?: pulumi.Input<string>;
    /**
     * The name of the CD-ROM. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The size of CD-ROM in GiB. This must be one of [`5`/`10`]. Changing this forces a new resource to be created. Default:`5`.
     */
    size?: pulumi.Input<number>;
    /**
     * Any tags to assign to the CD-ROM.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of zone that the CD-ROM will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
