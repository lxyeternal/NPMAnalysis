import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing Icon.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getIcon({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getIcon(args?: GetIconArgs, opts?: pulumi.InvokeOptions): Promise<GetIconResult>;
/**
 * A collection of arguments for invoking getIcon.
 */
export interface GetIconArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetIconFilter;
}
/**
 * A collection of values returned by getIcon.
 */
export interface GetIconResult {
    readonly filter?: outputs.GetIconFilter;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the Icon.
     */
    readonly name: string;
    /**
     * Any tags assigned to the Icon.
     */
    readonly tags: string[];
    /**
     * The URL for getting the icon's raw data.
     */
    readonly url: string;
}
export declare function getIconOutput(args?: GetIconOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetIconResult>;
/**
 * A collection of arguments for invoking getIcon.
 */
export interface GetIconOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetIconFilterArgs>;
}
