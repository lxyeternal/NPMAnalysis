import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing Packet Filter.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getPacketFilter({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getPacketFilter(args?: GetPacketFilterArgs, opts?: pulumi.InvokeOptions): Promise<GetPacketFilterResult>;
/**
 * A collection of arguments for invoking getPacketFilter.
 */
export interface GetPacketFilterArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetPacketFilterFilter;
    /**
     * The name of zone that the PacketFilter is in (e.g. `is1a`, `tk1a`).
     */
    zone?: string;
}
/**
 * A collection of values returned by getPacketFilter.
 */
export interface GetPacketFilterResult {
    /**
     * The description of the expression.
     */
    readonly description: string;
    /**
     * One or more `expression` blocks as defined below.
     */
    readonly expressions: outputs.GetPacketFilterExpression[];
    readonly filter?: outputs.GetPacketFilterFilter;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the PacketFilter.
     */
    readonly name: string;
    readonly zone: string;
}
export declare function getPacketFilterOutput(args?: GetPacketFilterOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetPacketFilterResult>;
/**
 * A collection of arguments for invoking getPacketFilter.
 */
export interface GetPacketFilterOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetPacketFilterFilterArgs>;
    /**
     * The name of zone that the PacketFilter is in (e.g. `is1a`, `tk1a`).
     */
    zone?: pulumi.Input<string>;
}
