import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing CD-ROM.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getCDROM({
 *     filter: {
 *         conditions: [{
 *             name: "Name",
 *             values: ["Parted Magic 2013_08_01"],
 *         }],
 *     },
 * }));
 * ```
 */
export declare function getCDROM(args?: GetCDROMArgs, opts?: pulumi.InvokeOptions): Promise<GetCDROMResult>;
/**
 * A collection of arguments for invoking getCDROM.
 */
export interface GetCDROMArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetCDROMFilter;
    /**
     * The name of zone that the CD-ROM is in (e.g. `is1a`, `tk1a`).
     */
    zone?: string;
}
/**
 * A collection of values returned by getCDROM.
 */
export interface GetCDROMResult {
    /**
     * The description of the CD-ROM.
     */
    readonly description: string;
    readonly filter?: outputs.GetCDROMFilter;
    /**
     * The icon id attached to the CD-ROM.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the CD-ROM.
     */
    readonly name: string;
    /**
     * The size of CD-ROM in GiB.
     */
    readonly size: number;
    /**
     * Any tags assigned to the CD-ROM.
     */
    readonly tags: string[];
    readonly zone: string;
}
export declare function getCDROMOutput(args?: GetCDROMOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetCDROMResult>;
/**
 * A collection of arguments for invoking getCDROM.
 */
export interface GetCDROMOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetCDROMFilterArgs>;
    /**
     * The name of zone that the CD-ROM is in (e.g. `is1a`, `tk1a`).
     */
    zone?: pulumi.Input<string>;
}
