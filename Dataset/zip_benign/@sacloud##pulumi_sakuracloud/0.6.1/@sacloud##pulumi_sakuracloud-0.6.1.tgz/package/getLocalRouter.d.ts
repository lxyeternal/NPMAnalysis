import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing Local Router.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getLocalRouter({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getLocalRouter(args?: GetLocalRouterArgs, opts?: pulumi.InvokeOptions): Promise<GetLocalRouterResult>;
/**
 * A collection of arguments for invoking getLocalRouter.
 */
export interface GetLocalRouterArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetLocalRouterFilter;
}
/**
 * A collection of values returned by getLocalRouter.
 */
export interface GetLocalRouterResult {
    /**
     * The description of the LocalRouter.
     */
    readonly description: string;
    readonly filter?: outputs.GetLocalRouterFilter;
    /**
     * The icon id attached to the LocalRouter.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the LocalRouter.
     */
    readonly name: string;
    /**
     * A list of `networkInterface` blocks as defined below.
     */
    readonly networkInterfaces: outputs.GetLocalRouterNetworkInterface[];
    /**
     * A list of `peer` blocks as defined below.
     */
    readonly peers: outputs.GetLocalRouterPeer[];
    /**
     * A list of secret key used for peering from other LocalRouters.
     */
    readonly secretKeys: string[];
    /**
     * A list of `staticRoute` blocks as defined below.
     */
    readonly staticRoutes: outputs.GetLocalRouterStaticRoute[];
    /**
     * A list of `switch` blocks as defined below.
     */
    readonly switches: outputs.GetLocalRouterSwitch[];
    /**
     * Any tags assigned to the LocalRouter.
     */
    readonly tags: string[];
}
export declare function getLocalRouterOutput(args?: GetLocalRouterOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetLocalRouterResult>;
/**
 * A collection of arguments for invoking getLocalRouter.
 */
export interface GetLocalRouterOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetLocalRouterFilterArgs>;
}
