import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing Note.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getNote({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getNote(args?: GetNoteArgs, opts?: pulumi.InvokeOptions): Promise<GetNoteResult>;
/**
 * A collection of arguments for invoking getNote.
 */
export interface GetNoteArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetNoteFilter;
}
/**
 * A collection of values returned by getNote.
 */
export interface GetNoteResult {
    /**
     * The class of the Note. This will be one of [`shell`/`yamlCloudConfig`].
     */
    readonly class: string;
    /**
     * The content of the Note.
     */
    readonly content: string;
    /**
     * The description of the Note.
     */
    readonly description: string;
    readonly filter?: outputs.GetNoteFilter;
    /**
     * The icon id attached to the Note.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the Note.
     */
    readonly name: string;
    /**
     * Any tags assigned to the Note.
     */
    readonly tags: string[];
}
export declare function getNoteOutput(args?: GetNoteOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetNoteResult>;
/**
 * A collection of arguments for invoking getNote.
 */
export interface GetNoteOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetNoteFilterArgs>;
}
