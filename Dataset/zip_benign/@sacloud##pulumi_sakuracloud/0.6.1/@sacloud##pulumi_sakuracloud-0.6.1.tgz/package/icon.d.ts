import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud Icon.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 * import * from "fs";
 *
 * const foobar = new sakuracloud.Icon("foobar", {
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 *     base64content: Buffer.from(fs.readFileSync("example.icon"), 'binary').toString('base64'),
 * });
 * ```
 */
export declare class Icon extends pulumi.CustomResource {
    /**
     * Get an existing Icon resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: IconState, opts?: pulumi.CustomResourceOptions): Icon;
    /**
     * Returns true if the given object is an instance of Icon.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is Icon;
    /**
     * The base64 encoded content to upload to as the Icon. This conflicts with [`source`]. Changing this forces a new resource to be created.
     */
    readonly base64content: pulumi.Output<string | undefined>;
    /**
     * The name of the Icon. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * The file path to upload to as the Icon. This conflicts with [`base64content`]. Changing this forces a new resource to be created.
     */
    readonly source: pulumi.Output<string | undefined>;
    /**
     * Any tags to assign to the Icon.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * The URL for getting the icon's raw data.
     */
    readonly url: pulumi.Output<string>;
    /**
     * Create a Icon resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args?: IconArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering Icon resources.
 */
export interface IconState {
    /**
     * The base64 encoded content to upload to as the Icon. This conflicts with [`source`]. Changing this forces a new resource to be created.
     */
    base64content?: pulumi.Input<string>;
    /**
     * The name of the Icon. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The file path to upload to as the Icon. This conflicts with [`base64content`]. Changing this forces a new resource to be created.
     */
    source?: pulumi.Input<string>;
    /**
     * Any tags to assign to the Icon.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The URL for getting the icon's raw data.
     */
    url?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a Icon resource.
 */
export interface IconArgs {
    /**
     * The base64 encoded content to upload to as the Icon. This conflicts with [`source`]. Changing this forces a new resource to be created.
     */
    base64content?: pulumi.Input<string>;
    /**
     * The name of the Icon. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The file path to upload to as the Icon. This conflicts with [`base64content`]. Changing this forces a new resource to be created.
     */
    source?: pulumi.Input<string>;
    /**
     * Any tags to assign to the Icon.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
}
