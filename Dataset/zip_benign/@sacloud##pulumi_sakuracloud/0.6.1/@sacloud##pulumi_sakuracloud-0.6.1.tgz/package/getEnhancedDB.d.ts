import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing Enhanced Database.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getEnhancedDB({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getEnhancedDB(args?: GetEnhancedDBArgs, opts?: pulumi.InvokeOptions): Promise<GetEnhancedDBResult>;
/**
 * A collection of arguments for invoking getEnhancedDB.
 */
export interface GetEnhancedDBArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetEnhancedDBFilter;
}
/**
 * A collection of values returned by getEnhancedDB.
 */
export interface GetEnhancedDBResult {
    /**
     * The name of database.
     */
    readonly databaseName: string;
    /**
     * The type of database.
     */
    readonly databaseType: string;
    /**
     * The description of the EnhancedDB.
     */
    readonly description: string;
    readonly filter?: outputs.GetEnhancedDBFilter;
    /**
     * The name of database host. This will be built from `databaseName` + `tidb-is1.db.sakurausercontent.com`.
     */
    readonly hostname: string;
    /**
     * The icon id attached to the EnhancedDB.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The value of max connections setting.
     */
    readonly maxConnections: number;
    /**
     * The name of the EnhancedDB.
     */
    readonly name: string;
    /**
     * The region name.
     */
    readonly region: string;
    /**
     * Any tags assigned to the EnhancedDB.
     */
    readonly tags: string[];
}
export declare function getEnhancedDBOutput(args?: GetEnhancedDBOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetEnhancedDBResult>;
/**
 * A collection of arguments for invoking getEnhancedDB.
 */
export interface GetEnhancedDBOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetEnhancedDBFilterArgs>;
}
