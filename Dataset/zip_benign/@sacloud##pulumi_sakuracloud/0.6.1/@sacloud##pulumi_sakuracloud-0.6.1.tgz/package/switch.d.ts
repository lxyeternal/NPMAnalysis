import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud Switch.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = new sakuracloud.Switch("foobar", {
 *     description: "description",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 * });
 * ```
 */
export declare class Switch extends pulumi.CustomResource {
    /**
     * Get an existing Switch resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: SwitchState, opts?: pulumi.CustomResourceOptions): Switch;
    /**
     * Returns true if the given object is an instance of Switch.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is Switch;
    /**
     * The bridge id attached to the Switch.
     */
    readonly bridgeId: pulumi.Output<string | undefined>;
    /**
     * The description of the Switch. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The icon id to attach to the Switch.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The name of the Switch. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * A list of server id connected to the switch.
     */
    readonly serverIds: pulumi.Output<string[]>;
    /**
     * Any tags to assign to the Switch.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * The name of zone that the Switch will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    readonly zone: pulumi.Output<string>;
    /**
     * Create a Switch resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args?: SwitchArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering Switch resources.
 */
export interface SwitchState {
    /**
     * The bridge id attached to the Switch.
     */
    bridgeId?: pulumi.Input<string>;
    /**
     * The description of the Switch. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the Switch.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the Switch. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * A list of server id connected to the switch.
     */
    serverIds?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * Any tags to assign to the Switch.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of zone that the Switch will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a Switch resource.
 */
export interface SwitchArgs {
    /**
     * The bridge id attached to the Switch.
     */
    bridgeId?: pulumi.Input<string>;
    /**
     * The description of the Switch. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the Switch.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the Switch. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * Any tags to assign to the Switch.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of zone that the Switch will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
