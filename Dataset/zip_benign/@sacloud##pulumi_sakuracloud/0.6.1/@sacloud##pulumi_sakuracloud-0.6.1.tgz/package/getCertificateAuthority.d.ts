import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing sakuracloud_certificate_authority.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getCertificateAuthority({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getCertificateAuthority(args?: GetCertificateAuthorityArgs, opts?: pulumi.InvokeOptions): Promise<GetCertificateAuthorityResult>;
/**
 * A collection of arguments for invoking getCertificateAuthority.
 */
export interface GetCertificateAuthorityArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetCertificateAuthorityFilter;
}
/**
 * A collection of values returned by getCertificateAuthority.
 */
export interface GetCertificateAuthorityResult {
    /**
     * The body of the CA's certificate in PEM format.
     */
    readonly certificate: string;
    /**
     * A list of `client` blocks as defined below.
     */
    readonly clients: outputs.GetCertificateAuthorityClient[];
    /**
     * The URL of the CRL.
     */
    readonly crlUrl: string;
    /**
     * The description of the CertificateAuthority.
     */
    readonly description: string;
    readonly filter?: outputs.GetCertificateAuthorityFilter;
    /**
     * The icon id attached to the CertificateAuthority.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the CertificateAuthority.
     */
    readonly name: string;
    /**
     * The date on which the certificate validity period ends, in RFC3339 format.
     */
    readonly notAfter: string;
    /**
     * The date on which the certificate validity period begins, in RFC3339 format.
     */
    readonly notBefore: string;
    /**
     * The body of the CA's certificate in PEM format.
     */
    readonly serialNumber: string;
    /**
     * A list of `server` blocks as defined below.
     */
    readonly servers: outputs.GetCertificateAuthorityServer[];
    /**
     * .
     */
    readonly subjectString: string;
    /**
     * Any tags assigned to the CertificateAuthority.
     */
    readonly tags: string[];
}
export declare function getCertificateAuthorityOutput(args?: GetCertificateAuthorityOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetCertificateAuthorityResult>;
/**
 * A collection of arguments for invoking getCertificateAuthority.
 */
export interface GetCertificateAuthorityOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetCertificateAuthorityFilterArgs>;
}
