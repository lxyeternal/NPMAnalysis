import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing Switch+Router.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getInternet({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getInternet(args?: GetInternetArgs, opts?: pulumi.InvokeOptions): Promise<GetInternetResult>;
/**
 * A collection of arguments for invoking getInternet.
 */
export interface GetInternetArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetInternetFilter;
    /**
     * The name of zone that the Switch+Router is in (e.g. `is1a`, `tk1a`).
     */
    zone?: string;
}
/**
 * A collection of values returned by getInternet.
 */
export interface GetInternetResult {
    /**
     * The bandwidth of the network connected to the Internet in Mbps.
     */
    readonly bandWidth: number;
    /**
     * The description of the Switch+Router.
     */
    readonly description: string;
    /**
     * The flag to enable IPv6.
     */
    readonly enableIpv6: boolean;
    readonly filter?: outputs.GetInternetFilter;
    /**
     * The IP address of the gateway used by Switch+Router.
     */
    readonly gateway: string;
    /**
     * The icon id attached to the Switch+Router.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * A list of assigned global address to the Switch+Router.
     */
    readonly ipAddresses: string[];
    /**
     * The IPv6 network address assigned to the Switch+Router.
     */
    readonly ipv6NetworkAddress: string;
    /**
     * The network prefix of assigned IPv6 addresses to the Switch+Router.
     */
    readonly ipv6Prefix: string;
    /**
     * The bit length of IPv6 network prefix.
     */
    readonly ipv6PrefixLen: number;
    /**
     * Maximum IP address in assigned global addresses to the Switch+Router.
     */
    readonly maxIpAddress: string;
    /**
     * Minimum IP address in assigned global addresses to the Switch+Router.
     */
    readonly minIpAddress: string;
    /**
     * The name of the Switch+Router.
     */
    readonly name: string;
    /**
     * The bit length of the subnet assigned to the Switch+Router.
     */
    readonly netmask: number;
    /**
     * The IPv4 network address assigned to the Switch+Router.
     */
    readonly networkAddress: string;
    /**
     * A list of the ID of Servers connected to the Switch+Router.
     */
    readonly serverIds: string[];
    /**
     * The id of the switch connected from the Switch+Router.
     */
    readonly switchId: string;
    /**
     * Any tags assigned to the Switch+Router.
     */
    readonly tags: string[];
    readonly zone: string;
}
export declare function getInternetOutput(args?: GetInternetOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetInternetResult>;
/**
 * A collection of arguments for invoking getInternet.
 */
export interface GetInternetOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetInternetFilterArgs>;
    /**
     * The name of zone that the Switch+Router is in (e.g. `is1a`, `tk1a`).
     */
    zone?: pulumi.Input<string>;
}
