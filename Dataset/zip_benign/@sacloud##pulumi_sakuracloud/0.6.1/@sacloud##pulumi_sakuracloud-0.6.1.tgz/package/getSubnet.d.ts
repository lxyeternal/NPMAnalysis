import * as pulumi from "@pulumi/pulumi";
/**
 * Get information about an existing Subnet.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const config = new pulumi.Config();
 * const internetId = config.requireObject("internetId");
 * const foobar = sakuracloud.getSubnet({
 *     internetId: internetId,
 *     index: 1,
 * });
 * ```
 */
export declare function getSubnet(args: GetSubnetArgs, opts?: pulumi.InvokeOptions): Promise<GetSubnetResult>;
/**
 * A collection of arguments for invoking getSubnet.
 */
export interface GetSubnetArgs {
    /**
     * The index of the subnet in assigned to the Switch+Router. Changing this forces a new resource to be created.
     */
    index: number;
    /**
     * The id of the switch+router resource that the Subnet belongs. Changing this forces a new resource to be created.
     */
    internetId: string;
    /**
     * The name of zone that the Subnet is in (e.g. `is1a`, `tk1a`).
     */
    zone?: string;
}
/**
 * A collection of values returned by getSubnet.
 */
export interface GetSubnetResult {
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    readonly index: number;
    readonly internetId: string;
    /**
     * A list of assigned global address to the Subnet.
     */
    readonly ipAddresses: string[];
    /**
     * Maximum IP address in assigned global addresses to the Subnet.
     */
    readonly maxIpAddress: string;
    /**
     * Minimum IP address in assigned global addresses to the Subnet.
     */
    readonly minIpAddress: string;
    /**
     * The bit length of the subnet assigned to the Subnet.
     */
    readonly netmask: number;
    /**
     * The IPv4 network address assigned to the Subnet.
     */
    readonly networkAddress: string;
    /**
     * The ip address of the next-hop at the Subnet.
     */
    readonly nextHop: string;
    /**
     * The id of the switch connected from the Subnet.
     */
    readonly switchId: string;
    readonly zone: string;
}
export declare function getSubnetOutput(args: GetSubnetOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetSubnetResult>;
/**
 * A collection of arguments for invoking getSubnet.
 */
export interface GetSubnetOutputArgs {
    /**
     * The index of the subnet in assigned to the Switch+Router. Changing this forces a new resource to be created.
     */
    index: pulumi.Input<number>;
    /**
     * The id of the switch+router resource that the Subnet belongs. Changing this forces a new resource to be created.
     */
    internetId: pulumi.Input<string>;
    /**
     * The name of zone that the Subnet is in (e.g. `is1a`, `tk1a`).
     */
    zone?: pulumi.Input<string>;
}
