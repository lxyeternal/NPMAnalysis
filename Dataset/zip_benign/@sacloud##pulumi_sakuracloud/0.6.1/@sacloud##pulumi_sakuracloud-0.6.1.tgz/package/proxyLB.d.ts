import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Manages a SakuraCloud ProxyLB.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobarServer = new sakuracloud.Server("foobarServer", {networkInterfaces: [{
 *     upstream: "shared",
 * }]});
 * const foobarProxyLB = new sakuracloud.ProxyLB("foobarProxyLB", {
 *     plan: 100,
 *     vipFailover: true,
 *     stickySession: true,
 *     gzip: true,
 *     proxyProtocol: true,
 *     timeout: 10,
 *     region: "is1",
 *     healthCheck: {
 *         protocol: "http",
 *         delayLoop: 10,
 *         hostHeader: "example.com",
 *         path: "/",
 *     },
 *     sorryServer: {
 *         ipAddress: "192.0.2.1",
 *         port: 80,
 *     },
 *     syslog: {
 *         server: "192.0.2.1",
 *         port: 514,
 *     },
 *     bindPorts: [{
 *         proxyMode: "http",
 *         port: 80,
 *         responseHeaders: [{
 *             header: "Cache-Control",
 *             value: "public, max-age=10",
 *         }],
 *     }],
 *     servers: [{
 *         ipAddress: foobarServer.ipAddress,
 *         port: 80,
 *         group: "group1",
 *     }],
 *     rules: [
 *         {
 *             action: "forward",
 *             host: "www.example.com",
 *             path: "/",
 *             group: "group1",
 *         },
 *         {
 *             action: "redirect",
 *             host: "www2.example.com",
 *             path: "/",
 *             group: "group1",
 *             redirectLocation: "https://redirect.example.com",
 *             redirectStatusCode: "301",
 *         },
 *         {
 *             action: "fixed",
 *             host: "www3.example.com",
 *             path: "/",
 *             group: "group1",
 *             fixedStatusCode: "200",
 *             fixedContentType: "text/plain",
 *             fixedMessageBody: "body",
 *         },
 *     ],
 *     description: "description",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 * });
 * ```
 */
export declare class ProxyLB extends pulumi.CustomResource {
    /**
     * Get an existing ProxyLB resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: ProxyLBState, opts?: pulumi.CustomResourceOptions): ProxyLB;
    /**
     * Returns true if the given object is an instance of ProxyLB.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is ProxyLB;
    /**
     * One or more `bindPort` blocks as defined below.
     */
    readonly bindPorts: pulumi.Output<outputs.ProxyLBBindPort[]>;
    /**
     * An `certificate` block as defined below.
     */
    readonly certificate: pulumi.Output<outputs.ProxyLBCertificate>;
    /**
     * The description of the ProxyLB. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The FQDN for accessing to the ProxyLB. This is typically used as value of CNAME record.
     */
    readonly fqdn: pulumi.Output<string>;
    /**
     * The flag to enable gzip compression.
     */
    readonly gzip: pulumi.Output<boolean | undefined>;
    /**
     * A `healthCheck` block as defined below.
     */
    readonly healthCheck: pulumi.Output<outputs.ProxyLBHealthCheck>;
    /**
     * The icon id to attach to the ProxyLB.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The name of the ProxyLB. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * The plan name of the ProxyLB. This must be one of [`100`/`500`/`1000`/`5000`/`10000`/`50000`/`100000`]. Default:`100`.
     */
    readonly plan: pulumi.Output<number | undefined>;
    /**
     * A list of CIDR block used by the ProxyLB to access the server.
     */
    readonly proxyNetworks: pulumi.Output<string[]>;
    /**
     * The flag to enable proxy protocol v2.
     */
    readonly proxyProtocol: pulumi.Output<boolean | undefined>;
    /**
     * The name of region that the proxy LB is in. This must be one of [`tk1`/`is1`/`anycast`]. Changing this forces a new resource to be created. Default:`is1`.
     */
    readonly region: pulumi.Output<string | undefined>;
    /**
     * One or more `rule` blocks as defined below.
     */
    readonly rules: pulumi.Output<outputs.ProxyLBRule[] | undefined>;
    /**
     * One or more `server` blocks as defined below.
     */
    readonly servers: pulumi.Output<outputs.ProxyLBServer[] | undefined>;
    /**
     * A `sorryServer` block as defined below.
     */
    readonly sorryServer: pulumi.Output<outputs.ProxyLBSorryServer | undefined>;
    /**
     * The flag to enable sticky session.
     */
    readonly stickySession: pulumi.Output<boolean | undefined>;
    /**
     * A `syslog` block as defined below.
     */
    readonly syslog: pulumi.Output<outputs.ProxyLBSyslog>;
    /**
     * Any tags to assign to the ProxyLB.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * The timeout duration in seconds. Default:`10`.
     */
    readonly timeout: pulumi.Output<number | undefined>;
    /**
     * The virtual IP address assigned to the ProxyLB.
     */
    readonly vip: pulumi.Output<string>;
    /**
     * The flag to enable VIP fail-over. Changing this forces a new resource to be created.
     */
    readonly vipFailover: pulumi.Output<boolean | undefined>;
    /**
     * Create a ProxyLB resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: ProxyLBArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering ProxyLB resources.
 */
export interface ProxyLBState {
    /**
     * One or more `bindPort` blocks as defined below.
     */
    bindPorts?: pulumi.Input<pulumi.Input<inputs.ProxyLBBindPort>[]>;
    /**
     * An `certificate` block as defined below.
     */
    certificate?: pulumi.Input<inputs.ProxyLBCertificate>;
    /**
     * The description of the ProxyLB. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The FQDN for accessing to the ProxyLB. This is typically used as value of CNAME record.
     */
    fqdn?: pulumi.Input<string>;
    /**
     * The flag to enable gzip compression.
     */
    gzip?: pulumi.Input<boolean>;
    /**
     * A `healthCheck` block as defined below.
     */
    healthCheck?: pulumi.Input<inputs.ProxyLBHealthCheck>;
    /**
     * The icon id to attach to the ProxyLB.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the ProxyLB. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The plan name of the ProxyLB. This must be one of [`100`/`500`/`1000`/`5000`/`10000`/`50000`/`100000`]. Default:`100`.
     */
    plan?: pulumi.Input<number>;
    /**
     * A list of CIDR block used by the ProxyLB to access the server.
     */
    proxyNetworks?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The flag to enable proxy protocol v2.
     */
    proxyProtocol?: pulumi.Input<boolean>;
    /**
     * The name of region that the proxy LB is in. This must be one of [`tk1`/`is1`/`anycast`]. Changing this forces a new resource to be created. Default:`is1`.
     */
    region?: pulumi.Input<string>;
    /**
     * One or more `rule` blocks as defined below.
     */
    rules?: pulumi.Input<pulumi.Input<inputs.ProxyLBRule>[]>;
    /**
     * One or more `server` blocks as defined below.
     */
    servers?: pulumi.Input<pulumi.Input<inputs.ProxyLBServer>[]>;
    /**
     * A `sorryServer` block as defined below.
     */
    sorryServer?: pulumi.Input<inputs.ProxyLBSorryServer>;
    /**
     * The flag to enable sticky session.
     */
    stickySession?: pulumi.Input<boolean>;
    /**
     * A `syslog` block as defined below.
     */
    syslog?: pulumi.Input<inputs.ProxyLBSyslog>;
    /**
     * Any tags to assign to the ProxyLB.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The timeout duration in seconds. Default:`10`.
     */
    timeout?: pulumi.Input<number>;
    /**
     * The virtual IP address assigned to the ProxyLB.
     */
    vip?: pulumi.Input<string>;
    /**
     * The flag to enable VIP fail-over. Changing this forces a new resource to be created.
     */
    vipFailover?: pulumi.Input<boolean>;
}
/**
 * The set of arguments for constructing a ProxyLB resource.
 */
export interface ProxyLBArgs {
    /**
     * One or more `bindPort` blocks as defined below.
     */
    bindPorts: pulumi.Input<pulumi.Input<inputs.ProxyLBBindPort>[]>;
    /**
     * An `certificate` block as defined below.
     */
    certificate?: pulumi.Input<inputs.ProxyLBCertificate>;
    /**
     * The description of the ProxyLB. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The flag to enable gzip compression.
     */
    gzip?: pulumi.Input<boolean>;
    /**
     * A `healthCheck` block as defined below.
     */
    healthCheck: pulumi.Input<inputs.ProxyLBHealthCheck>;
    /**
     * The icon id to attach to the ProxyLB.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the ProxyLB. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The plan name of the ProxyLB. This must be one of [`100`/`500`/`1000`/`5000`/`10000`/`50000`/`100000`]. Default:`100`.
     */
    plan?: pulumi.Input<number>;
    /**
     * The flag to enable proxy protocol v2.
     */
    proxyProtocol?: pulumi.Input<boolean>;
    /**
     * The name of region that the proxy LB is in. This must be one of [`tk1`/`is1`/`anycast`]. Changing this forces a new resource to be created. Default:`is1`.
     */
    region?: pulumi.Input<string>;
    /**
     * One or more `rule` blocks as defined below.
     */
    rules?: pulumi.Input<pulumi.Input<inputs.ProxyLBRule>[]>;
    /**
     * One or more `server` blocks as defined below.
     */
    servers?: pulumi.Input<pulumi.Input<inputs.ProxyLBServer>[]>;
    /**
     * A `sorryServer` block as defined below.
     */
    sorryServer?: pulumi.Input<inputs.ProxyLBSorryServer>;
    /**
     * The flag to enable sticky session.
     */
    stickySession?: pulumi.Input<boolean>;
    /**
     * A `syslog` block as defined below.
     */
    syslog?: pulumi.Input<inputs.ProxyLBSyslog>;
    /**
     * Any tags to assign to the ProxyLB.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The timeout duration in seconds. Default:`10`.
     */
    timeout?: pulumi.Input<number>;
    /**
     * The flag to enable VIP fail-over. Changing this forces a new resource to be created.
     */
    vipFailover?: pulumi.Input<boolean>;
}
