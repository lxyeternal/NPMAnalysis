import * as pulumi from "@pulumi/pulumi";
/**
 * Get information about an existing Zone.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const current = pulumi.output(sakuracloud.getZone());
 * const is1a = pulumi.output(sakuracloud.getZone({
 *     name: "is1a",
 * }));
 * ```
 */
export declare function getZone(args?: GetZoneArgs, opts?: pulumi.InvokeOptions): Promise<GetZoneResult>;
/**
 * A collection of arguments for invoking getZone.
 */
export interface GetZoneArgs {
    /**
     * The name of the zone (e.g. `is1a`,`tk1a`).
     */
    name?: string;
}
/**
 * A collection of values returned by getZone.
 */
export interface GetZoneResult {
    /**
     * The description of the zone.
     */
    readonly description: string;
    /**
     * A list of IP address of DNS server in the zone.
     */
    readonly dnsServers: string[];
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    readonly name: string;
    /**
     * The id of the region that the zone belongs.
     */
    readonly regionId: string;
    /**
     * The name of the region that the zone belongs.
     */
    readonly regionName: string;
    /**
     * The id of the zone.
     */
    readonly zoneId: string;
}
export declare function getZoneOutput(args?: GetZoneOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetZoneResult>;
/**
 * A collection of arguments for invoking getZone.
 */
export interface GetZoneOutputArgs {
    /**
     * The name of the zone (e.g. `is1a`,`tk1a`).
     */
    name?: pulumi.Input<string>;
}
