import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Manages a SakuraCloud Packet Filter.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = new sakuracloud.PacketFilter("foobar", {
 *     description: "description",
 *     expressions: [
 *         {
 *             destinationPort: "22",
 *             protocol: "tcp",
 *         },
 *         {
 *             destinationPort: "80",
 *             protocol: "tcp",
 *         },
 *         {
 *             destinationPort: "443",
 *             protocol: "tcp",
 *         },
 *         {
 *             protocol: "icmp",
 *         },
 *         {
 *             protocol: "fragment",
 *         },
 *         {
 *             protocol: "udp",
 *             sourcePort: "123",
 *         },
 *         {
 *             destinationPort: "32768-61000",
 *             protocol: "tcp",
 *         },
 *         {
 *             destinationPort: "32768-61000",
 *             protocol: "udp",
 *         },
 *         {
 *             allow: false,
 *             description: "Deny ALL",
 *             protocol: "ip",
 *         },
 *     ],
 * });
 * ```
 */
export declare class PacketFilter extends pulumi.CustomResource {
    /**
     * Get an existing PacketFilter resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: PacketFilterState, opts?: pulumi.CustomResourceOptions): PacketFilter;
    /**
     * Returns true if the given object is an instance of PacketFilter.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is PacketFilter;
    /**
     * The description of the expression.
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * One or more `expression` blocks as defined below.
     */
    readonly expressions: pulumi.Output<outputs.PacketFilterExpression[]>;
    /**
     * The name of the packetFilter. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * The name of zone that the packetFilter will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    readonly zone: pulumi.Output<string>;
    /**
     * Create a PacketFilter resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args?: PacketFilterArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering PacketFilter resources.
 */
export interface PacketFilterState {
    /**
     * The description of the expression.
     */
    description?: pulumi.Input<string>;
    /**
     * One or more `expression` blocks as defined below.
     */
    expressions?: pulumi.Input<pulumi.Input<inputs.PacketFilterExpression>[]>;
    /**
     * The name of the packetFilter. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The name of zone that the packetFilter will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a PacketFilter resource.
 */
export interface PacketFilterArgs {
    /**
     * The description of the expression.
     */
    description?: pulumi.Input<string>;
    /**
     * One or more `expression` blocks as defined below.
     */
    expressions?: pulumi.Input<pulumi.Input<inputs.PacketFilterExpression>[]>;
    /**
     * The name of the packetFilter. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The name of zone that the packetFilter will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
