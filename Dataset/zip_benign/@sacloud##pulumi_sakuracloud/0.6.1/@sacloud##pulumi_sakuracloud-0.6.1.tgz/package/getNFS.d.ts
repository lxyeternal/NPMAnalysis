import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing NFS.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getNFS({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getNFS(args?: GetNFSArgs, opts?: pulumi.InvokeOptions): Promise<GetNFSResult>;
/**
 * A collection of arguments for invoking getNFS.
 */
export interface GetNFSArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetNFSFilter;
    /**
     * The name of zone that the NFS is in (e.g. `is1a`, `tk1a`).
     */
    zone?: string;
}
/**
 * A collection of values returned by getNFS.
 */
export interface GetNFSResult {
    /**
     * The description of the NFS.
     */
    readonly description: string;
    readonly filter?: outputs.GetNFSFilter;
    /**
     * The icon id attached to the NFS.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the NFS.
     */
    readonly name: string;
    /**
     * A list of `networkInterface` blocks as defined below.
     */
    readonly networkInterfaces: outputs.GetNFSNetworkInterface[];
    /**
     * The plan name of the NFS. This will be one of [`hdd`/`ssd`].
     */
    readonly plan: string;
    /**
     * The size of NFS in GiB.
     */
    readonly size: number;
    /**
     * Any tags assigned to the NFS.
     */
    readonly tags: string[];
    readonly zone: string;
}
export declare function getNFSOutput(args?: GetNFSOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetNFSResult>;
/**
 * A collection of arguments for invoking getNFS.
 */
export interface GetNFSOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetNFSFilterArgs>;
    /**
     * The name of zone that the NFS is in (e.g. `is1a`, `tk1a`).
     */
    zone?: pulumi.Input<string>;
}
