import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing GSLB.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getGSLB({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getGSLB(args?: GetGSLBArgs, opts?: pulumi.InvokeOptions): Promise<GetGSLBResult>;
/**
 * A collection of arguments for invoking getGSLB.
 */
export interface GetGSLBArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetGSLBFilter;
}
/**
 * A collection of values returned by getGSLB.
 */
export interface GetGSLBResult {
    /**
     * The description of the GSLB.
     */
    readonly description: string;
    readonly filter?: outputs.GetGSLBFilter;
    /**
     * The FQDN for accessing to the GSLB. This is typically used as value of CNAME record.
     */
    readonly fqdn: string;
    /**
     * A list of `healthCheck` blocks as defined below.
     */
    readonly healthChecks: outputs.GetGSLBHealthCheck[];
    /**
     * The icon id attached to the GSLB.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the GSLB.
     */
    readonly name: string;
    /**
     * A list of `server` blocks as defined below.
     */
    readonly servers: outputs.GetGSLBServer[];
    /**
     * The IP address of the SorryServer. This will be used when all servers are down.
     */
    readonly sorryServer: string;
    /**
     * Any tags assigned to the GSLB.
     */
    readonly tags: string[];
    /**
     * The flag to enable weighted load-balancing.
     */
    readonly weighted: boolean;
}
export declare function getGSLBOutput(args?: GetGSLBOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetGSLBResult>;
/**
 * A collection of arguments for invoking getGSLB.
 */
export interface GetGSLBOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetGSLBFilterArgs>;
}
