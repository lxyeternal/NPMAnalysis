import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud Subnet.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobarInternet = new sakuracloud.Internet("foobarInternet", {});
 * const foobarSubnet = new sakuracloud.Subnet("foobarSubnet", {
 *     internetId: foobarInternet.id,
 *     nextHop: foobarInternet.minIpAddress,
 * });
 * ```
 */
export declare class Subnet extends pulumi.CustomResource {
    /**
     * Get an existing Subnet resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: SubnetState, opts?: pulumi.CustomResourceOptions): Subnet;
    /**
     * Returns true if the given object is an instance of Subnet.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is Subnet;
    /**
     * The id of the switch+router resource that the subnet belongs. Changing this forces a new resource to be created.
     */
    readonly internetId: pulumi.Output<string>;
    /**
     * A list of assigned global address to the subnet.
     */
    readonly ipAddresses: pulumi.Output<string[]>;
    /**
     * Maximum IP address in assigned global addresses to the subnet.
     */
    readonly maxIpAddress: pulumi.Output<string>;
    /**
     * Minimum IP address in assigned global addresses to the subnet.
     */
    readonly minIpAddress: pulumi.Output<string>;
    /**
     * The bit length of the subnet to assign to the Subnet. This must be in the range [`26`-`28`]. Changing this forces a new resource to be created. Default:`28`.
     */
    readonly netmask: pulumi.Output<number | undefined>;
    /**
     * The IPv4 network address assigned to the Subnet.
     */
    readonly networkAddress: pulumi.Output<string>;
    /**
     * The ip address of the next-hop at the subnet.
     */
    readonly nextHop: pulumi.Output<string>;
    /**
     * The id of the switch connected from the Subnet.
     */
    readonly switchId: pulumi.Output<string>;
    /**
     * The name of zone that the Subnet will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    readonly zone: pulumi.Output<string>;
    /**
     * Create a Subnet resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: SubnetArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering Subnet resources.
 */
export interface SubnetState {
    /**
     * The id of the switch+router resource that the subnet belongs. Changing this forces a new resource to be created.
     */
    internetId?: pulumi.Input<string>;
    /**
     * A list of assigned global address to the subnet.
     */
    ipAddresses?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * Maximum IP address in assigned global addresses to the subnet.
     */
    maxIpAddress?: pulumi.Input<string>;
    /**
     * Minimum IP address in assigned global addresses to the subnet.
     */
    minIpAddress?: pulumi.Input<string>;
    /**
     * The bit length of the subnet to assign to the Subnet. This must be in the range [`26`-`28`]. Changing this forces a new resource to be created. Default:`28`.
     */
    netmask?: pulumi.Input<number>;
    /**
     * The IPv4 network address assigned to the Subnet.
     */
    networkAddress?: pulumi.Input<string>;
    /**
     * The ip address of the next-hop at the subnet.
     */
    nextHop?: pulumi.Input<string>;
    /**
     * The id of the switch connected from the Subnet.
     */
    switchId?: pulumi.Input<string>;
    /**
     * The name of zone that the Subnet will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a Subnet resource.
 */
export interface SubnetArgs {
    /**
     * The id of the switch+router resource that the subnet belongs. Changing this forces a new resource to be created.
     */
    internetId: pulumi.Input<string>;
    /**
     * The bit length of the subnet to assign to the Subnet. This must be in the range [`26`-`28`]. Changing this forces a new resource to be created. Default:`28`.
     */
    netmask?: pulumi.Input<number>;
    /**
     * The ip address of the next-hop at the subnet.
     */
    nextHop: pulumi.Input<string>;
    /**
     * The name of zone that the Subnet will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
