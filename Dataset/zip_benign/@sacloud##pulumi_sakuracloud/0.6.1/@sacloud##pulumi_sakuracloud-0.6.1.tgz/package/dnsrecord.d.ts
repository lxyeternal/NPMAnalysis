import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud DNS Record.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = new sakuracloud.DNS("foobar", {zone: "example.com"});
 * const record1 = new sakuracloud.DNSRecord("record1", {
 *     dnsId: foobar.id,
 *     type: "A",
 *     value: "192.168.0.1",
 * });
 * const record2 = new sakuracloud.DNSRecord("record2", {
 *     dnsId: foobar.id,
 *     type: "A",
 *     value: "192.168.0.2",
 * });
 * ```
 */
export declare class DNSRecord extends pulumi.CustomResource {
    /**
     * Get an existing DNSRecord resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: DNSRecordState, opts?: pulumi.CustomResourceOptions): DNSRecord;
    /**
     * Returns true if the given object is an instance of DNSRecord.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is DNSRecord;
    /**
     * The id of the DNS resource. Changing this forces a new resource to be created.
     */
    readonly dnsId: pulumi.Output<string>;
    /**
     * The name of the DNS Record resource. Changing this forces a new resource to be created.
     */
    readonly name: pulumi.Output<string>;
    /**
     * The number of port. This must be in the range [`1`-`65535`]. Changing this forces a new resource to be created.
     */
    readonly port: pulumi.Output<number | undefined>;
    /**
     * The priority of target DNS Record. This must be in the range [`0`-`65535`]. Changing this forces a new resource to be created.
     */
    readonly priority: pulumi.Output<number | undefined>;
    /**
     * The number of the TTL. Changing this forces a new resource to be created. Default:`3600`.
     */
    readonly ttl: pulumi.Output<number | undefined>;
    /**
     * The type of DNS Record. This must be one of [`A`/`AAAA`/`ALIAS`/`CNAME`/`NS`/`MX`/`TXT`/`SRV`/`CAA`/`PTR`]. Changing this forces a new resource to be created.
     */
    readonly type: pulumi.Output<string>;
    /**
     * The value of the DNS Record. Changing this forces a new resource to be created.
     */
    readonly value: pulumi.Output<string>;
    /**
     * The weight of target DNS Record. This must be in the range [`0`-`65535`]. Changing this forces a new resource to be created.
     */
    readonly weight: pulumi.Output<number | undefined>;
    /**
     * Create a DNSRecord resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: DNSRecordArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering DNSRecord resources.
 */
export interface DNSRecordState {
    /**
     * The id of the DNS resource. Changing this forces a new resource to be created.
     */
    dnsId?: pulumi.Input<string>;
    /**
     * The name of the DNS Record resource. Changing this forces a new resource to be created.
     */
    name?: pulumi.Input<string>;
    /**
     * The number of port. This must be in the range [`1`-`65535`]. Changing this forces a new resource to be created.
     */
    port?: pulumi.Input<number>;
    /**
     * The priority of target DNS Record. This must be in the range [`0`-`65535`]. Changing this forces a new resource to be created.
     */
    priority?: pulumi.Input<number>;
    /**
     * The number of the TTL. Changing this forces a new resource to be created. Default:`3600`.
     */
    ttl?: pulumi.Input<number>;
    /**
     * The type of DNS Record. This must be one of [`A`/`AAAA`/`ALIAS`/`CNAME`/`NS`/`MX`/`TXT`/`SRV`/`CAA`/`PTR`]. Changing this forces a new resource to be created.
     */
    type?: pulumi.Input<string>;
    /**
     * The value of the DNS Record. Changing this forces a new resource to be created.
     */
    value?: pulumi.Input<string>;
    /**
     * The weight of target DNS Record. This must be in the range [`0`-`65535`]. Changing this forces a new resource to be created.
     */
    weight?: pulumi.Input<number>;
}
/**
 * The set of arguments for constructing a DNSRecord resource.
 */
export interface DNSRecordArgs {
    /**
     * The id of the DNS resource. Changing this forces a new resource to be created.
     */
    dnsId: pulumi.Input<string>;
    /**
     * The name of the DNS Record resource. Changing this forces a new resource to be created.
     */
    name?: pulumi.Input<string>;
    /**
     * The number of port. This must be in the range [`1`-`65535`]. Changing this forces a new resource to be created.
     */
    port?: pulumi.Input<number>;
    /**
     * The priority of target DNS Record. This must be in the range [`0`-`65535`]. Changing this forces a new resource to be created.
     */
    priority?: pulumi.Input<number>;
    /**
     * The number of the TTL. Changing this forces a new resource to be created. Default:`3600`.
     */
    ttl?: pulumi.Input<number>;
    /**
     * The type of DNS Record. This must be one of [`A`/`AAAA`/`ALIAS`/`CNAME`/`NS`/`MX`/`TXT`/`SRV`/`CAA`/`PTR`]. Changing this forces a new resource to be created.
     */
    type: pulumi.Input<string>;
    /**
     * The value of the DNS Record. Changing this forces a new resource to be created.
     */
    value: pulumi.Input<string>;
    /**
     * The weight of target DNS Record. This must be in the range [`0`-`65535`]. Changing this forces a new resource to be created.
     */
    weight?: pulumi.Input<number>;
}
