import * as pulumi from "@pulumi/pulumi";
/**
 * Get information about an existing sakuracloud_webaccel.
 */
export declare function getWebAccel(args?: GetWebAccelArgs, opts?: pulumi.InvokeOptions): Promise<GetWebAccelResult>;
/**
 * A collection of arguments for invoking getWebAccel.
 */
export interface GetWebAccelArgs {
    /**
     * .
     */
    domain?: string;
    /**
     * .
     */
    name?: string;
}
/**
 * A collection of values returned by getWebAccel.
 */
export interface GetWebAccelResult {
    /**
     * .
     */
    readonly cnameRecordValue: string;
    readonly domain: string;
    /**
     * .
     */
    readonly domainType: string;
    /**
     * .
     */
    readonly hasCertificate: boolean;
    /**
     * .
     */
    readonly hostHeader: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    readonly name: string;
    /**
     * .
     */
    readonly origin: string;
    /**
     * .
     */
    readonly siteId: string;
    /**
     * .
     */
    readonly status: string;
    /**
     * .
     */
    readonly subdomain: string;
    /**
     * .
     */
    readonly txtRecordValue: string;
}
export declare function getWebAccelOutput(args?: GetWebAccelOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetWebAccelResult>;
/**
 * A collection of arguments for invoking getWebAccel.
 */
export interface GetWebAccelOutputArgs {
    /**
     * .
     */
    domain?: pulumi.Input<string>;
    /**
     * .
     */
    name?: pulumi.Input<string>;
}
