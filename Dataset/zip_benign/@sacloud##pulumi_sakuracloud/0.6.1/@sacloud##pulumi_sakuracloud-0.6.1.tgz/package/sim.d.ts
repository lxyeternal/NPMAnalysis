import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud SIM.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = new sakuracloud.SIM("foobar", {
 *     //imei     = "your-imei"
 *     carriers: [
 *         "softbank",
 *         "docomo",
 *         "kddi",
 *     ],
 *     description: "description",
 *     enabled: true,
 *     iccid: "your-iccid",
 *     passcode: "your-password",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 * });
 * ```
 */
export declare class SIM extends pulumi.CustomResource {
    /**
     * Get an existing SIM resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: SIMState, opts?: pulumi.CustomResourceOptions): SIM;
    /**
     * Returns true if the given object is an instance of SIM.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is SIM;
    /**
     * A list of a communication company. Each element must be one of `kddi`/`docomo`/`softbank`.
     */
    readonly carriers: pulumi.Output<string[]>;
    /**
     * The description of the SIM. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The flag to enable the SIM. Default:`true`.
     */
    readonly enabled: pulumi.Output<boolean | undefined>;
    /**
     * ICCID(Integrated Circuit Card ID) assigned to the SIM. Changing this forces a new resource to be created.
     */
    readonly iccid: pulumi.Output<string>;
    /**
     * The icon id to attach to the SIM.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The id of the device to restrict devices that can use the SIM.
     */
    readonly imei: pulumi.Output<string | undefined>;
    /**
     * The IP address assigned to the SIM.
     */
    readonly ipAddress: pulumi.Output<string>;
    /**
     * The id of the MobileGateway which the SIM is assigned.
     */
    readonly mobileGatewayId: pulumi.Output<string>;
    /**
     * The name of the SIM. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * The passcord to authenticate the SIM. Changing this forces a new resource to be created.
     */
    readonly passcode: pulumi.Output<string>;
    /**
     * Any tags to assign to the SIM.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * Create a SIM resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: SIMArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering SIM resources.
 */
export interface SIMState {
    /**
     * A list of a communication company. Each element must be one of `kddi`/`docomo`/`softbank`.
     */
    carriers?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The description of the SIM. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The flag to enable the SIM. Default:`true`.
     */
    enabled?: pulumi.Input<boolean>;
    /**
     * ICCID(Integrated Circuit Card ID) assigned to the SIM. Changing this forces a new resource to be created.
     */
    iccid?: pulumi.Input<string>;
    /**
     * The icon id to attach to the SIM.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The id of the device to restrict devices that can use the SIM.
     */
    imei?: pulumi.Input<string>;
    /**
     * The IP address assigned to the SIM.
     */
    ipAddress?: pulumi.Input<string>;
    /**
     * The id of the MobileGateway which the SIM is assigned.
     */
    mobileGatewayId?: pulumi.Input<string>;
    /**
     * The name of the SIM. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The passcord to authenticate the SIM. Changing this forces a new resource to be created.
     */
    passcode?: pulumi.Input<string>;
    /**
     * Any tags to assign to the SIM.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
}
/**
 * The set of arguments for constructing a SIM resource.
 */
export interface SIMArgs {
    /**
     * A list of a communication company. Each element must be one of `kddi`/`docomo`/`softbank`.
     */
    carriers: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The description of the SIM. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The flag to enable the SIM. Default:`true`.
     */
    enabled?: pulumi.Input<boolean>;
    /**
     * ICCID(Integrated Circuit Card ID) assigned to the SIM. Changing this forces a new resource to be created.
     */
    iccid: pulumi.Input<string>;
    /**
     * The icon id to attach to the SIM.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The id of the device to restrict devices that can use the SIM.
     */
    imei?: pulumi.Input<string>;
    /**
     * The name of the SIM. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The passcord to authenticate the SIM. Changing this forces a new resource to be created.
     */
    passcode: pulumi.Input<string>;
    /**
     * Any tags to assign to the SIM.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
}
