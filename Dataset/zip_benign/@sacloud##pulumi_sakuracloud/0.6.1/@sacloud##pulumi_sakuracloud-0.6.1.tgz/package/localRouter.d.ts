import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Manages a SakuraCloud Local Router.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobarSwitch = new sakuracloud.Switch("foobarSwitch", {});
 * const peer = sakuracloud.getLocalRouter({
 *     filter: {
 *         names: ["peer"],
 *     },
 * });
 * const foobarLocalRouter = new sakuracloud.LocalRouter("foobarLocalRouter", {
 *     description: "descriptio",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 *     "switch": {
 *         code: foobarSwitch.id,
 *         category: "cloud",
 *         zoneId: "is1a",
 *     },
 *     networkInterface: {
 *         vip: "192.168.11.1",
 *         ipAddresses: [
 *             "192.168.11.11",
 *             "192.168.11.12",
 *         ],
 *         netmask: 24,
 *         vrid: 101,
 *     },
 *     staticRoutes: [
 *         {
 *             prefix: "10.0.0.0/24",
 *             nextHop: "192.168.11.2",
 *         },
 *         {
 *             prefix: "172.16.0.0/16",
 *             nextHop: "192.168.11.3",
 *         },
 *     ],
 *     peers: [{
 *         peerId: peer.then(peer => peer.id),
 *         secretKey: peer.then(peer => peer.secretKeys?[0]),
 *         description: "description",
 *     }],
 * });
 * ```
 */
export declare class LocalRouter extends pulumi.CustomResource {
    /**
     * Get an existing LocalRouter resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: LocalRouterState, opts?: pulumi.CustomResourceOptions): LocalRouter;
    /**
     * Returns true if the given object is an instance of LocalRouter.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is LocalRouter;
    /**
     * The description of the LocalRouter. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The icon id to attach to the LoadBalancer.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The name of the LocalRouter. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * An `networkInterface` block as defined below.
     */
    readonly networkInterface: pulumi.Output<outputs.LocalRouterNetworkInterface>;
    /**
     * One or more `peer` blocks as defined below.
     */
    readonly peers: pulumi.Output<outputs.LocalRouterPeer[] | undefined>;
    /**
     * A list of secret key used for peering from other LocalRouters.
     */
    readonly secretKeys: pulumi.Output<string[]>;
    /**
     * One or more `staticRoute` blocks as defined below.
     */
    readonly staticRoutes: pulumi.Output<outputs.LocalRouterStaticRoute[] | undefined>;
    /**
     * A `switch` block as defined below.
     */
    readonly switch: pulumi.Output<outputs.LocalRouterSwitch>;
    /**
     * Any tags to assign to the LoadBalancer.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * Create a LocalRouter resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: LocalRouterArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering LocalRouter resources.
 */
export interface LocalRouterState {
    /**
     * The description of the LocalRouter. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the LoadBalancer.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the LocalRouter. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * An `networkInterface` block as defined below.
     */
    networkInterface?: pulumi.Input<inputs.LocalRouterNetworkInterface>;
    /**
     * One or more `peer` blocks as defined below.
     */
    peers?: pulumi.Input<pulumi.Input<inputs.LocalRouterPeer>[]>;
    /**
     * A list of secret key used for peering from other LocalRouters.
     */
    secretKeys?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * One or more `staticRoute` blocks as defined below.
     */
    staticRoutes?: pulumi.Input<pulumi.Input<inputs.LocalRouterStaticRoute>[]>;
    /**
     * A `switch` block as defined below.
     */
    switch?: pulumi.Input<inputs.LocalRouterSwitch>;
    /**
     * Any tags to assign to the LoadBalancer.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
}
/**
 * The set of arguments for constructing a LocalRouter resource.
 */
export interface LocalRouterArgs {
    /**
     * The description of the LocalRouter. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the LoadBalancer.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the LocalRouter. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * An `networkInterface` block as defined below.
     */
    networkInterface: pulumi.Input<inputs.LocalRouterNetworkInterface>;
    /**
     * One or more `peer` blocks as defined below.
     */
    peers?: pulumi.Input<pulumi.Input<inputs.LocalRouterPeer>[]>;
    /**
     * One or more `staticRoute` blocks as defined below.
     */
    staticRoutes?: pulumi.Input<pulumi.Input<inputs.LocalRouterStaticRoute>[]>;
    /**
     * A `switch` block as defined below.
     */
    switch: pulumi.Input<inputs.LocalRouterSwitch>;
    /**
     * Any tags to assign to the LoadBalancer.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
}
