import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Manages a SakuraCloud NFS.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobarSwitch = new sakuracloud.Switch("foobarSwitch", {});
 * const foobarNFS = new sakuracloud.NFS("foobarNFS", {
 *     plan: "ssd",
 *     size: "500",
 *     networkInterface: {
 *         switchId: foobarSwitch.id,
 *         ipAddress: "192.168.11.101",
 *         netmask: 24,
 *         gateway: "192.168.11.1",
 *     },
 *     description: "description",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 * });
 * ```
 */
export declare class NFS extends pulumi.CustomResource {
    /**
     * Get an existing NFS resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: NFSState, opts?: pulumi.CustomResourceOptions): NFS;
    /**
     * Returns true if the given object is an instance of NFS.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is NFS;
    /**
     * The description of the NFS. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The icon id to attach to the NFS.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The name of the NFS. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * An `networkInterface` block as defined below.
     */
    readonly networkInterface: pulumi.Output<outputs.NFSNetworkInterface>;
    /**
     * The plan name of the NFS. This must be one of [`hdd`/`ssd`]. Changing this forces a new resource to be created. Default:`hdd`.
     */
    readonly plan: pulumi.Output<string | undefined>;
    /**
     * The size of NFS in GiB. Changing this forces a new resource to be created. Default:`100`.
     */
    readonly size: pulumi.Output<number | undefined>;
    /**
     * Any tags to assign to the NFS.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * The name of zone that the NFS will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    readonly zone: pulumi.Output<string>;
    /**
     * Create a NFS resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args: NFSArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering NFS resources.
 */
export interface NFSState {
    /**
     * The description of the NFS. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the NFS.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the NFS. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * An `networkInterface` block as defined below.
     */
    networkInterface?: pulumi.Input<inputs.NFSNetworkInterface>;
    /**
     * The plan name of the NFS. This must be one of [`hdd`/`ssd`]. Changing this forces a new resource to be created. Default:`hdd`.
     */
    plan?: pulumi.Input<string>;
    /**
     * The size of NFS in GiB. Changing this forces a new resource to be created. Default:`100`.
     */
    size?: pulumi.Input<number>;
    /**
     * Any tags to assign to the NFS.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of zone that the NFS will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a NFS resource.
 */
export interface NFSArgs {
    /**
     * The description of the NFS. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the NFS.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the NFS. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * An `networkInterface` block as defined below.
     */
    networkInterface: pulumi.Input<inputs.NFSNetworkInterface>;
    /**
     * The plan name of the NFS. This must be one of [`hdd`/`ssd`]. Changing this forces a new resource to be created. Default:`hdd`.
     */
    plan?: pulumi.Input<string>;
    /**
     * The size of NFS in GiB. Changing this forces a new resource to be created. Default:`100`.
     */
    size?: pulumi.Input<number>;
    /**
     * Any tags to assign to the NFS.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
    /**
     * The name of zone that the NFS will be created. (e.g. `is1a`, `tk1a`). Changing this forces a new resource to be created.
     */
    zone?: pulumi.Input<string>;
}
