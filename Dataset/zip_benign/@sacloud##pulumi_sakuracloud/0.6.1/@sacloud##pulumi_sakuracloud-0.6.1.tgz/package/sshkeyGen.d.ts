import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud SSH Key Gen.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = new sakuracloud.SSHKeyGen("foobar", {
 *     //pass_phrase = "your-pass-phrase"
 *     description: "description",
 * });
 * ```
 */
export declare class SSHKeyGen extends pulumi.CustomResource {
    /**
     * Get an existing SSHKeyGen resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: SSHKeyGenState, opts?: pulumi.CustomResourceOptions): SSHKeyGen;
    /**
     * Returns true if the given object is an instance of SSHKeyGen.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is SSHKeyGen;
    /**
     * The description of the SSHKey. The length of this value must be in the range [`1`-`512`]. Changing this forces a new resource to be created.
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The fingerprint of the public key.
     */
    readonly fingerprint: pulumi.Output<string>;
    /**
     * The name of the SSHKey. The length of this value must be in the range [`1`-`64`]. Changing this forces a new resource to be created.
     */
    readonly name: pulumi.Output<string>;
    /**
     * The pass phrase of the private key. The length of this value must be in the range [`8`-`64`]. Changing this forces a new resource to be created.
     */
    readonly passPhrase: pulumi.Output<string | undefined>;
    /**
     * The body of the private key.
     */
    readonly privateKey: pulumi.Output<string>;
    /**
     * The body of the public key.
     */
    readonly publicKey: pulumi.Output<string>;
    /**
     * Create a SSHKeyGen resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args?: SSHKeyGenArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering SSHKeyGen resources.
 */
export interface SSHKeyGenState {
    /**
     * The description of the SSHKey. The length of this value must be in the range [`1`-`512`]. Changing this forces a new resource to be created.
     */
    description?: pulumi.Input<string>;
    /**
     * The fingerprint of the public key.
     */
    fingerprint?: pulumi.Input<string>;
    /**
     * The name of the SSHKey. The length of this value must be in the range [`1`-`64`]. Changing this forces a new resource to be created.
     */
    name?: pulumi.Input<string>;
    /**
     * The pass phrase of the private key. The length of this value must be in the range [`8`-`64`]. Changing this forces a new resource to be created.
     */
    passPhrase?: pulumi.Input<string>;
    /**
     * The body of the private key.
     */
    privateKey?: pulumi.Input<string>;
    /**
     * The body of the public key.
     */
    publicKey?: pulumi.Input<string>;
}
/**
 * The set of arguments for constructing a SSHKeyGen resource.
 */
export interface SSHKeyGenArgs {
    /**
     * The description of the SSHKey. The length of this value must be in the range [`1`-`512`]. Changing this forces a new resource to be created.
     */
    description?: pulumi.Input<string>;
    /**
     * The name of the SSHKey. The length of this value must be in the range [`1`-`64`]. Changing this forces a new resource to be created.
     */
    name?: pulumi.Input<string>;
    /**
     * The pass phrase of the private key. The length of this value must be in the range [`8`-`64`]. Changing this forces a new resource to be created.
     */
    passPhrase?: pulumi.Input<string>;
}
