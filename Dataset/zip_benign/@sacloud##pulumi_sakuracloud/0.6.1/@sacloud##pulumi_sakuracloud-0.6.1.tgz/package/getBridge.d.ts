import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing Bridge.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getBridge({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getBridge(args?: GetBridgeArgs, opts?: pulumi.InvokeOptions): Promise<GetBridgeResult>;
/**
 * A collection of arguments for invoking getBridge.
 */
export interface GetBridgeArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetBridgeFilter;
    /**
     * The name of zone that the Bridge is in (e.g. `is1a`, `tk1a`).
     */
    zone?: string;
}
/**
 * A collection of values returned by getBridge.
 */
export interface GetBridgeResult {
    /**
     * The description of the Bridge.
     */
    readonly description: string;
    readonly filter?: outputs.GetBridgeFilter;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The name of the Bridge.
     */
    readonly name: string;
    readonly zone: string;
}
export declare function getBridgeOutput(args?: GetBridgeOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetBridgeResult>;
/**
 * A collection of arguments for invoking getBridge.
 */
export interface GetBridgeOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetBridgeFilterArgs>;
    /**
     * The name of zone that the Bridge is in (e.g. `is1a`, `tk1a`).
     */
    zone?: pulumi.Input<string>;
}
