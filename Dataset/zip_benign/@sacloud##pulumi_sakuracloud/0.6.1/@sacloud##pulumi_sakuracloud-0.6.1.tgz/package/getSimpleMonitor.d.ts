import * as pulumi from "@pulumi/pulumi";
import { input as inputs, output as outputs } from "./types";
/**
 * Get information about an existing Simple Monitor.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = pulumi.output(sakuracloud.getSimpleMonitor({
 *     filter: {
 *         names: ["foobar"],
 *     },
 * }));
 * ```
 */
export declare function getSimpleMonitor(args?: GetSimpleMonitorArgs, opts?: pulumi.InvokeOptions): Promise<GetSimpleMonitorResult>;
/**
 * A collection of arguments for invoking getSimpleMonitor.
 */
export interface GetSimpleMonitorArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: inputs.GetSimpleMonitorFilter;
}
/**
 * A collection of values returned by getSimpleMonitor.
 */
export interface GetSimpleMonitorResult {
    /**
     * The interval in seconds between checks.
     */
    readonly delayLoop: number;
    /**
     * The description of the SimpleMonitor.
     */
    readonly description: string;
    /**
     * The flag to enable monitoring by the simple monitor.
     */
    readonly enabled: boolean;
    readonly filter?: outputs.GetSimpleMonitorFilter;
    /**
     * A list of `healthCheck` blocks as defined below.
     */
    readonly healthChecks: outputs.GetSimpleMonitorHealthCheck[];
    /**
     * The icon id attached to the SimpleMonitor.
     */
    readonly iconId: string;
    /**
     * The provider-assigned unique ID for this managed resource.
     */
    readonly id: string;
    /**
     * The flag to enable notification by email.
     */
    readonly notifyEmailEnabled: boolean;
    /**
     * The flag to enable HTML format instead of text format.
     */
    readonly notifyEmailHtml: boolean;
    /**
     * The interval in hours between notification.
     */
    readonly notifyInterval: number;
    /**
     * The flag to enable notification by slack/discord.
     */
    readonly notifySlackEnabled: boolean;
    /**
     * The webhook URL for sending notification by slack/discord.
     */
    readonly notifySlackWebhook: string;
    /**
     * Any tags assigned to the SimpleMonitor.
     */
    readonly tags: string[];
    /**
     * The monitoring target of the simple monitor. This will be IP address or FQDN.
     */
    readonly target: string;
    /**
     * The timeout in seconds for monitoring.
     */
    readonly timeout: number;
}
export declare function getSimpleMonitorOutput(args?: GetSimpleMonitorOutputArgs, opts?: pulumi.InvokeOptions): pulumi.Output<GetSimpleMonitorResult>;
/**
 * A collection of arguments for invoking getSimpleMonitor.
 */
export interface GetSimpleMonitorOutputArgs {
    /**
     * One or more values used for filtering, as defined below.
     */
    filter?: pulumi.Input<inputs.GetSimpleMonitorFilterArgs>;
}
