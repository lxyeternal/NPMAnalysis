import * as pulumi from "@pulumi/pulumi";
/**
 * Manages a SakuraCloud ESME resource.
 *
 * ## Example Usage
 *
 * ```typescript
 * import * as pulumi from "@pulumi/pulumi";
 * import * as sakuracloud from "@pulumi/sakuracloud";
 *
 * const foobar = new sakuracloud.ESME("foobar", {
 *     description: "description",
 *     tags: [
 *         "tag1",
 *         "tag2",
 *     ],
 * });
 * ```
 */
export declare class ESME extends pulumi.CustomResource {
    /**
     * Get an existing ESME resource's state with the given name, ID, and optional extra
     * properties used to qualify the lookup.
     *
     * @param name The _unique_ name of the resulting resource.
     * @param id The _unique_ provider ID of the resource to lookup.
     * @param state Any extra arguments used during the lookup.
     * @param opts Optional settings to control the behavior of the CustomResource.
     */
    static get(name: string, id: pulumi.Input<pulumi.ID>, state?: ESMEState, opts?: pulumi.CustomResourceOptions): ESME;
    /**
     * Returns true if the given object is an instance of ESME.  This is designed to work even
     * when multiple copies of the Pulumi SDK have been loaded into the same process.
     */
    static isInstance(obj: any): obj is ESME;
    /**
     * The description of the ESME. The length of this value must be in the range [`1`-`512`].
     */
    readonly description: pulumi.Output<string | undefined>;
    /**
     * The icon id to attach to the ESME.
     */
    readonly iconId: pulumi.Output<string | undefined>;
    /**
     * The name of the ESME. The length of this value must be in the range [`1`-`64`].
     */
    readonly name: pulumi.Output<string>;
    /**
     * The API URL for send SMS with generated OTP.
     */
    readonly sendMessageWithGeneratedOtpApiUrl: pulumi.Output<string>;
    /**
     * The API URL for send SMS with inputted OTP.
     */
    readonly sendMessageWithInputtedOtpApiUrl: pulumi.Output<string>;
    /**
     * Any tags to assign to the ESME.
     */
    readonly tags: pulumi.Output<string[] | undefined>;
    /**
     * Create a ESME resource with the given unique name, arguments, and options.
     *
     * @param name The _unique_ name of the resource.
     * @param args The arguments to use to populate this resource's properties.
     * @param opts A bag of options that control this resource's behavior.
     */
    constructor(name: string, args?: ESMEArgs, opts?: pulumi.CustomResourceOptions);
}
/**
 * Input properties used for looking up and filtering ESME resources.
 */
export interface ESMEState {
    /**
     * The description of the ESME. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the ESME.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the ESME. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * The API URL for send SMS with generated OTP.
     */
    sendMessageWithGeneratedOtpApiUrl?: pulumi.Input<string>;
    /**
     * The API URL for send SMS with inputted OTP.
     */
    sendMessageWithInputtedOtpApiUrl?: pulumi.Input<string>;
    /**
     * Any tags to assign to the ESME.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
}
/**
 * The set of arguments for constructing a ESME resource.
 */
export interface ESMEArgs {
    /**
     * The description of the ESME. The length of this value must be in the range [`1`-`512`].
     */
    description?: pulumi.Input<string>;
    /**
     * The icon id to attach to the ESME.
     */
    iconId?: pulumi.Input<string>;
    /**
     * The name of the ESME. The length of this value must be in the range [`1`-`64`].
     */
    name?: pulumi.Input<string>;
    /**
     * Any tags to assign to the ESME.
     */
    tags?: pulumi.Input<pulumi.Input<string>[]>;
}
