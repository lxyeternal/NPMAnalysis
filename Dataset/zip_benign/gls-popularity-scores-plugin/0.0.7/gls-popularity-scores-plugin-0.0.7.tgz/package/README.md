# Plugin de `PopularityScoresPlugin` Vendure

Este é um plugin para o [framework de e-commerce Vendure](https://www.vendure.io/)
O plugin calcula e atribui pontuações de popularidade a produtos e coleções com base nas vendas. Ele retorna os produtos mais vendidos do seus projetos [Gseller](https://gseller.com.br/).




Após configurar o seu projeto Vendure, você pode usar este plugin via npm install:

```npm install gls-popularity-scores-plugin```

e inclua-o no arquivo vendure-config conforme abaixo:

```

import { PopularityScoresPlugin } from "gls-popularity-scores-plugin";
...
export const config: VendureConfig = {
  ...
  plugins: [
    ...,
	        PopularityScoresPlugin.init({
            popularity_scores_endpoint_secret: ""
        })
  ]
}

```

# SortService (sort.service.ts):
```
* Implementa um serviço chamado SortService.

* Contém métodos para calcular a pontuação de popularidade de produtos e coleções com base nas vendas.

* Utiliza um sistema de fila de trabalhos assíncronos para processar o cálculo de pontuações em segundo plano.

* Fornece um método addScoreCalculatingJobToQueue para adicionar trabalhos de cálculo à fila.

```

# OrderByPopularityController (controller.ts):

```
* Implementa um controlador chamado OrderByPopularityController.

* Oferece um endpoint calculate-scores que dispara o cálculo de pontuações de popularidade para um canal específico.

```

# PopularityScoresPlugin (plugin.ts):

```
* Implementa um plugin chamado PopularityScoresPlugin.

* Configuração personalizada para adicionar campos de pontuação de popularidade aos produtos e coleções no sistema.

* Inicializa o serviço SortService e configurações do plugin.
* Fornece um controlador para lidar com solicitações relacionadas ao cálculo de pontuações de popularidade.

* Escuta eventos de transição de estado do pedido e, quando um pedido atinge o estado "PaymentSettled", aciona o cálculo de pontuações de popularidade.

```
