export declare const loggerCtx = "PopularityScoresPlugin";
export declare const PLUGIN_INIT_OPTIONS: unique symbol;
export declare const POPULARITY_SCORES_PLUGIN_INIT_OPTIONS: unique symbol;
