import { RequestContext } from "@vendure/core";
import { PopularityScoresPluginOptions } from "../common/types";
import { SortService } from "../services/sort.service";
export declare class OrderByPopularityController {
    private options;
    private sortService;
    constructor(options: PopularityScoresPluginOptions, sortService: SortService);
    calculateScores(ctx: RequestContext, token: string, secret: string): Promise<void>;
}
