import { OnModuleInit } from "@nestjs/common";
import { ChannelService, CollectionService, JobQueueService, RequestContext, SerializedRequestContext, TransactionalConnection } from "@vendure/core";
export declare class SortService implements OnModuleInit {
    private connection;
    private jobQueueService;
    private channelService;
    private collectionService;
    private jobQueue;
    constructor(connection: TransactionalConnection, jobQueueService: JobQueueService, channelService: ChannelService, collectionService: CollectionService);
    onModuleInit(): Promise<void>;
    private setProductPopularity;
    private assignScoreValuesToCollections;
    /**
     * This calculates the score of a collection based on its products.
     * Does not include scores of subcollections yet
     * @param ctx
     * @returns Array of collection ids and their corresponding popularity scores not including subcollections
     */
    private getEachCollectionsScore;
    /**
     *
     * @param input Array of collection ids and their corresponding popularity scores not including subcollections
     * @param ctx The current RequestContext
     */
    private addUpTheTreeAndSave;
    addScoreCalculatingJobToQueue(channelToken: string, ctx: RequestContext): Promise<import("@vendure/core/dist/job-queue/subscribable-job").SubscribableJob<{
        channelToken: string;
        ctx: SerializedRequestContext;
    }>>;
}
