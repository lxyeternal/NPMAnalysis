import { ChannelService, EventBus, RequestContextService, TransactionalConnection, Type } from "@vendure/core";
import { OnApplicationBootstrap } from "@nestjs/common";
import { PopularityScoresPluginOptions } from "./common/types";
import { SortService } from "./services/sort.service";
export declare class PopularityScoresPlugin implements OnApplicationBootstrap {
    private sortService;
    private eventBus;
    private connection;
    private requestContextService;
    private channelService;
    constructor(sortService: SortService, eventBus: EventBus, connection: TransactionalConnection, requestContextService: RequestContextService, channelService: ChannelService);
    private static options;
    static init(options: PopularityScoresPluginOptions): Type<PopularityScoresPlugin>;
    /**
     *  Listens to the CustomerEvent and publishes a message to the exchange-commerce exchange
     * @memberof EventBusListenersPlugin
     *
     * @internal
     * */
    onApplicationBootstrap(): Promise<void>;
    /**
     *  This method is responsible for listening to the CustomerEvent and publishing a message to the exchange-commerce exchange
     *  when a order is created
     *  @memberof EventBusListenersPlugin
     *  @internal
     */
    private orderEvent;
    /**
     * This method is responsible for creating a request context.
     * @internal
     * */
    private createRequestContext;
}
