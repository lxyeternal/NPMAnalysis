
const { 获取内容 } = require('..');

describe('获取内容', () => {

    describe('获取内容', () => {

        it('获取内容 字符串', () => {
            expect(获取内容('abc')).toBe('abc');
        });

        it('获取内容 对象', () => {
            let o = {a:'b'};
            expect(获取内容(o)).toBe(JSON.stringify(o));
        });

        it('获取内容 Buffer', () => {
            let o = Buffer.from('hello world', 'utf8');
            expect(获取内容(o)).toBe(o);
        });
        it('获取内容 String', () => {
            let o = new String('hello');
            expect(获取内容(o)).toBe('hello');
        });
        it('获取内容 undefined', () => {
            let o = undefined;
            expect(获取内容(o)).toBe(undefined);
        });
        it('获取内容 null', () => {
            let o = null;
            expect(获取内容(o)).toBe(null);
        });
    });
});

