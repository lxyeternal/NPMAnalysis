export class AbstractHeaders {
  constructor(...args: any[]);

  toRiffHeaders(...args: any[]): void;

  static fromRiffHeaders(...args: any[]): void;

}

export class AbstractMessage {
  constructor(...args: any[]);

  toRiffMessage(...args: any[]): void;

  static fromRiffMessage(...args: any[]): void;

}

// https://cloud.tencent.com/developer/chapter/13542
type IHttpHeadersName = "Authorization"
  | 'Accept'
  | 'Accept-Charset'
  | 'Accept-Encoding'
  | 'Accept-Language'
  | 'Accept-Ranges'
  | 'Access-Control-Allow-Credentials'
  | 'Access-Control-Allow-Headers'
  | 'Access-Control-Allow-Methods'
  | 'Access-Control-Allow-Origin'
  | 'Access-Control-Expose-Headers'
  | 'Access-Control-Max-Age'
  | 'Access-Control-Request-Headers'
  | 'Access-Control-Request-Method'
  | 'Age'
  | 'Allow'
  | 'Authorization'
  | 'Cache-Control'
  | 'Connection'
  | 'Content-Disposition'
  | 'Content-Encoding'
  | 'Content-Language'
  | 'Content-Length'
  | 'Content-Location'
  | 'Content-Range'
  | 'Content-Type'
  | 'Cookie'
  | 'Cookie2'
  | 'Date'
  | 'DNT'
  | 'ETag'
  | 'Expect'
  | 'Expires'
  | 'Forwarded'
  | 'From'
  | 'Headers'
  | 'Host'
  | 'If-Match'
  | 'If-Modified-Since'
  | 'If-None-Match'
  | 'If-Range'
  | 'If-Unmodified-Since'
  | 'Keep-Alive'
  | 'Large-Allocation'
  | 'Last-Modified'
  | 'Location'
  | 'Origin'
  | 'Pragma'
  | 'Proxy-Authenticate'
  | 'Proxy-Authorization'
  | 'Public-Key-Pins'
  | 'Public-Key-Pins-Report-Only'
  | 'Range'
  | 'Referer'
  | 'Referrer-Policy'
  | 'Retry-After'
  | 'Server'
  | 'Set-Cookie'
  | 'Set-Cookie2'
  | 'SourceMap'
  | 'Strict-Transport-Security'
  | 'TE'
  | 'Tk'
  | 'Trailer'
  | 'Transfer-Encoding'
  | 'Upgrade-Insecure-Requests'
  | 'User-Agent'
  | 'User-Agent: Firefox'
  | 'Vary'
  | 'Via'
  | 'Warning'
  | 'WWW-Authenticate'
  | 'X-Content-Type-Options'
  | 'X-DNS-Prefetch-Control'
  | 'X-Forwarded-For'
  | 'X-Forwarded-Host'
  | 'X-Forwarded-Proto'
  | 'X-Frame-Options'
  | 'X-XSS-Protection'
  | string;

export class Headers {
  constructor(...args: any[]);

  addHeader(...args: any[]): void;

  getValue(name: IHttpHeadersName): string | null;

  getValues(name: string): string[];

  replaceHeader(...args: any[]): void;

  toRiffHeaders(...args: any[]): void;

  static fromRiffHeaders(...args: any[]): void;

  static install(...args: any[]): void;

}

export class Message {
  headers: Headers;

  payload: any;

  toRiffMessage(...args: any[]): void;

  static builder(...args: any[]): void;

  static fromRiffMessage(...args: any[]): void;

  static install(...args: any[]): void;

}

export interface 型君土主题消息 {
  主题: string;
  接收名字空间: string;
  时间: string;
  内容: string;
  签名?: string;
}

export function 生成签名(消息: 型君土主题消息, 密钥: string): string;

export function 验证签名(消息: 型君土主题消息): boolean;
