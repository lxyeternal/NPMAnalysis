"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * This is only for local test
 */
var platform_browser_1 = require("@angular/platform-browser");
var core_1 = require("@angular/core");
var core_2 = require("@angular/core");
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
var angular_drag_bounce_1 = require("angular-drag-bounce");
var AppComponent = (function () {
    function AppComponent() {
    }
    AppComponent = __decorate([
        core_2.Component({
            selector: 'app',
            template: "\n<div class=\"app\">\n  <div class=\"header\"></div>\n  <div class=\"body\">\n    <div class=\"side\"></div>\n    <div class=\"main\"></div>\n  </div>\n</div>\n\n<as-bounceable\n  [position]=\"{ x: 20, y: 20 }\"\n  style=\"position: absolute; background: #fff;\">\n  <h1>Drag me, yo!</h1>\n  <p>Lorem ispum dolor sit amet</p>\n</as-bounceable>\n\n<as-bounceable\n  [position]=\"{ x: 50, y: 250 }\"\n  style=\"position: absolute; background: #fff;\">\n  You reckon?\n  <hr>\n  <button>Yeah</button>\n  <button>Nah</button>\n</as-bounceable>\n"
        })
    ], AppComponent);
    return AppComponent;
}());
var AppModule = (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            bootstrap: [AppComponent],
            declarations: [AppComponent],
            imports: [platform_browser_1.BrowserModule, angular_drag_bounce_1.BounceableModule.initialize()]
        })
    ], AppModule);
    return AppModule;
}());
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(AppModule);
//# sourceMappingURL=index.js.map