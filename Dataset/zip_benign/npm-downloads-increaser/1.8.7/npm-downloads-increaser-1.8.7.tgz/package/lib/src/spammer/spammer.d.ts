import { NpmjsResponse } from "../models/npmjs-response.model";
import { Stats } from "../models/stats.model";
export declare const queryNpms: () => Promise<NpmjsResponse>;
export declare const downloadPackage: (version: string, stats: Stats) => Promise<unknown>;
export declare const run: () => Promise<void>;
//# sourceMappingURL=spammer.d.ts.map