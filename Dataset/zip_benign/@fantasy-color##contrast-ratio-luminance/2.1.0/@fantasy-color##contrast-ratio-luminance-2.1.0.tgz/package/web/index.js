export default (function (luminance1, luminance2) {
  return luminance1 >= luminance2 ? (luminance1 + 0.05) / (luminance2 + 0.05) : (luminance2 + 0.05) / (luminance1 + 0.05);
});
//# sourceMappingURL=index.js.map