declare const _default: (luminance1: number, luminance2: number) => number;
export default _default;
