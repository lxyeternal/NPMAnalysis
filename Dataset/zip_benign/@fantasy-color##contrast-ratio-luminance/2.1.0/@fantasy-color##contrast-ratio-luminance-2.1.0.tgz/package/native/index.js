Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _default = function _default(luminance1, luminance2) {
  return luminance1 >= luminance2 ? (luminance1 + 0.05) / (luminance2 + 0.05) : (luminance2 + 0.05) / (luminance1 + 0.05);
};

exports.default = _default;
//# sourceMappingURL=index.js.map