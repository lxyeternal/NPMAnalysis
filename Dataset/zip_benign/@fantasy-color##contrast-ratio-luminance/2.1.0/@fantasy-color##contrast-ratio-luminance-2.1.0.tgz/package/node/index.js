Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _default = (luminance1, luminance2) => luminance1 >= luminance2 ? (luminance1 + 0.05) / (luminance2 + 0.05) : (luminance2 + 0.05) / (luminance1 + 0.05);

exports.default = _default;