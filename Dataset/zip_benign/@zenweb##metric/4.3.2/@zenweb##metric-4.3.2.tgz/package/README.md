# ZenWeb Metric module

zenweb 健康检测模块，用于生产环境的实例运行信息收集

[ZenWeb](https://www.npmjs.com/package/zenweb)

## 快速使用

安装模块
```bash
$ npm i @zenweb/metric
```

配置模块： 编辑项目启动文件
```ts
// 导入模块
import metric from "@zenweb/metric";
// 安装模块
app.setup(metric(/* 可选配置项 */));
```

## 配置项
| 项 | 值类型 | 默认值 | 说明 |
|----|-------|-------|-----|
| dir | `string` | `process.env.LOG_DIR \|\| '/tmp'` | 日志输出目录 |
| filename | `string` | `zenweb-metric.{yyyy}-{mm}-{dd}.log` | 日志文件名 |
| sampleInterval | `int` | `process.env.ZENWEB_METRIC_SAMPLE_INTERVAL \|\| 10000` | 取样间隔(毫秒) |
| slowTime | `int` | `100` | 慢请求时间 (毫秒) |

## 日志输出项
| 项 | 值类型 | 说明 |
|----|-------|-------|-----|
| timestamp | `int` | 本次采样记录时间戳 (秒) |
| interval | `int` | 本次记录采样范围 (毫秒) |
| cpu_time | `int` | 本次记录 CPU 用量 (毫秒) |
| mem_rss | `int` | 内存占用 RSS (字节) |
| mem_heap_total | `int` | 内存堆总大小 (字节) |
| mem_heap_used | `int` | 内存堆已使用 (字节) |
| mem_os_free | `int` | 内存操作系统空闲 (字节) |
| os_load | `float` | 操作系统负载 % |
| requests | `int` | 本次记录请求数 |
| requests_slow | `int` | 本次记录的慢请求 |
| requests_time | `int` | 本次记录请求总用时 |

## 如何计算

### Apdex %

```ts
apdex = (requests - requests_slow) + requests_slow * 0.5) / requests
```
### QPS

```ts
qps = requests / interval * 1000
```

### CPU 用量 %

```ts
cpu_usage = cpu_time / interval
```

### 循环延迟

```ts
event_delay = interval - option.sampleInterval
```
