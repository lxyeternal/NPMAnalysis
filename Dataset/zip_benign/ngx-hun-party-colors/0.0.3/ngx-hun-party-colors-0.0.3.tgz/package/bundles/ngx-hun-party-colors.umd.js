(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common')) :
    typeof define === 'function' && define.amd ? define('ngx-hun-party-colors', ['exports', '@angular/core', '@angular/common'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global['ngx-hun-party-colors'] = {}, global.ng.core, global.ng.common));
}(this, (function (exports, core, common) { 'use strict';

    var partyColors = [
        { color: '#FFCA99', name: ['Agrárszövetség', 'Agrárszövetség – Nemzeti Agrár Párt'] },
        { color: '#c6adb3', name: ['Centrum', 'Centrum Párt'] },
        { color: '#007FFF', name: ['DK', 'Demokratikus Koalíció'] },
        { color: '#00daff', name: ['Együtt', 'Együtt – a Korszakváltók Pártja'] },
        { color: '#9acd32', name: ['EKGP', 'Egyesült Kisgazda Párt'] },
        { color: '#fd8100', name: ['Fidesz', 'Fidesz – Magyar Polgári Szövetség'] },
        { color: '#445F2B', name: ['FKGP', 'Független Kisgazda-, Földmunkás- és Polgári Párt'] },
        { color: '#BF3F3F', name: ['horvátok', 'Magyarországi Horvátok Szövetsége'] },
        { color: '#008371', name: ['Jobbik', 'Jobbik Magyarországért Mozgalom'] },
        { color: '#cd9a01', name: ['KDNP', 'Kereszténydemokrata Néppárt'] },
        { color: '#9ED144', name: ['KPE', 'Kisgazda Polgári Egyesület'] },
        { color: '#91A4D5', name: ['Köztársaság', 'Köztársaság Párt'] },
        { color: '#73c92d', name: ['LMP', 'Lehet Más a Politika'] },
        { color: '#3C8A5A', name: ['MDF', 'Magyar Demokrata Fórum'] },
        { color: '#046731', name: ['MDNP', 'Magyar Demokrata Néppárt'] },
        { color: '#9E863E', name: ['MIÉP', 'Magyar Igazság és Élet Pártja'] },
        { color: '#688d1b', name: ['Mi Hazánk', 'Mi Hazánk Mozgalom'] },
        { color: '#62A26A', name: ['MKDSZ', 'Magyar Kereszténydemokrata Szövetség'] },
        { color: '#CD5C5C', name: ['MSZDP', 'Magyarországi Szociáldemokrata Párt'] },
        { color: '#E71A29', name: ['MSZP', 'Magyar Szocialista Párt'] },
        { color: '#8b0000', name: ['Munkáspárt', 'Magyar Munkáspárt', 'MSZMP'] },
        { color: '#97a6a6', name: ['németek', 'Magyarországi Németek Szövetsége'] },
        { color: '#74c6c3', name: ['NOE', 'Nagycsaládosok Országos Egyesülete'] },
        { color: '#37B34A', name: ['PM', 'Párbeszéd Magyarországért'] },
        { color: '#0783C7', name: ['SZDSZ', 'Szabad Demokraták Szövetsége'] },
        { color: '#C8A52C', name: ['VP', 'Vállalkozók Pártja'] },
        { color: '#0080bd', name: ['MoMa', 'Modern Magyarország Mozgalom'] },
        { color: '#808080', name: ['MKKP', 'Magyar Kétfarkú Kutya Párt'] },
        { color: '#001166', name: ['MMM', 'Mindenki Magyarországa'] },
        { color: '#8e6fcd', name: ['Momentum', 'Momentum mozgalom'] },
    ];

    /**
     * Converts a hex to RGB
     *
     * @export
     */
    function hexToRgb(value) {
        if (value.indexOf('#') === 0) {
            value = value.slice(1);
            var r = parseInt(value.slice(0, 2), 16);
            var g = parseInt(value.slice(2, 4), 16);
            var b = parseInt(value.slice(4, 6), 16);
            return { r: r, g: g, b: b };
        }
    }
    /**
     * Converts a hex to RGB
     *
     * @export
     */
    function hexToHsl(value) {
        var _a, _b, _c;
        var r = (_a = hexToRgb(value)) === null || _a === void 0 ? void 0 : _a.r;
        var g = (_b = hexToRgb(value)) === null || _b === void 0 ? void 0 : _b.g;
        var b = (_c = hexToRgb(value)) === null || _c === void 0 ? void 0 : _c.b;
        r /= 255;
        g /= 255;
        b /= 255;
        var cmin = Math.min(r, g, b);
        var cmax = Math.max(r, g, b);
        var delta = cmax - cmin;
        var h = 0;
        var s = 0;
        var l = 0;
        if (delta === 0) {
            h = 0;
        }
        else if (cmax === r) {
            h = ((g - b) / delta) % 6;
        }
        else if (cmax === g) {
            h = (b - r) / delta + 2;
        }
        else {
            h = (r - g) / delta + 4;
        }
        h = Math.round(h * 60);
        if (h < 0) {
            h += 360;
        }
        l = (cmax + cmin) / 2;
        s = delta === 0 ? 0 : delta / (1 - Math.abs(2 * l - 1));
        s = +(s * 100).toFixed(1);
        l = +(l * 100).toFixed(1);
        return { h: h, s: s, l: l };
    }

    var HUNPartyColorsService = /** @class */ (function () {
        function HUNPartyColorsService() {
            this.colors = partyColors;
        }
        HUNPartyColorsService.prototype.getPartyColorHex = function (partyName) {
            return this.getColor(partyName);
        };
        HUNPartyColorsService.prototype.getPartyColorRgb = function (partyName) {
            var color = hexToRgb(this.getColor(partyName));
            return "rgb(" + (color === null || color === void 0 ? void 0 : color.r) + ", " + (color === null || color === void 0 ? void 0 : color.g) + ", " + (color === null || color === void 0 ? void 0 : color.b) + ")";
        };
        HUNPartyColorsService.prototype.getPartyColorHsl = function (partyName) {
            var color = hexToHsl(this.getColor(partyName));
            return "hsl(" + (color === null || color === void 0 ? void 0 : color.h) + ", " + (color === null || color === void 0 ? void 0 : color.s) + ", " + (color === null || color === void 0 ? void 0 : color.l) + ")";
        };
        HUNPartyColorsService.prototype.getColor = function (partyName) {
            var partyColor = '';
            this.colors.map(function (color) {
                if (color.name.toLocaleString().toLowerCase().indexOf(partyName.toLowerCase()) !== -1) {
                    partyColor = color.color;
                }
            });
            return partyColor;
        };
        return HUNPartyColorsService;
    }());
    HUNPartyColorsService.decorators = [
        { type: core.Injectable }
    ];

    var HUNPartyColorsModule = /** @class */ (function () {
        function HUNPartyColorsModule() {
        }
        return HUNPartyColorsModule;
    }());
    HUNPartyColorsModule.decorators = [
        { type: core.NgModule, args: [{
                    imports: [
                        common.CommonModule
                    ],
                    declarations: [],
                    exports: [],
                    providers: [
                        HUNPartyColorsService
                    ]
                },] }
    ];

    /*
     * Public API Surface of ngx-hun-party-colors
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.HUNPartyColorsModule = HUNPartyColorsModule;
    exports.HUNPartyColorsService = HUNPartyColorsService;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ngx-hun-party-colors.umd.js.map
