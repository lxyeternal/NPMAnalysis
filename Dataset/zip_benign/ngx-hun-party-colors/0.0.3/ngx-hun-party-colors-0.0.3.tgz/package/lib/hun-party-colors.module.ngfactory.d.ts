import * as i0 from '@angular/core';
import * as i1 from './hun-party-colors.module';
export declare const HUNPartyColorsModuleNgFactory: i0.NgModuleFactory<i1.HUNPartyColorsModule>;
