export declare class HUNPartyColorsService {
    private colors;
    getPartyColorHex(partyName: string): string;
    getPartyColorRgb(partyName: string): string;
    getPartyColorHsl(partyName: string): string;
    private getColor;
}
