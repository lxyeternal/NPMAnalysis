export declare class HUNPartyColorsModule {
}
