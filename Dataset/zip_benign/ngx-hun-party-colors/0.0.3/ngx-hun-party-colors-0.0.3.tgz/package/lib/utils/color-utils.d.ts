/**
 * Converts a hex to RGB
 *
 * @export
 */
export declare function hexToRgb(value: string): any;
/**
 * Converts a hex to RGB
 *
 * @export
 */
export declare function hexToHsl(value: string): any;
