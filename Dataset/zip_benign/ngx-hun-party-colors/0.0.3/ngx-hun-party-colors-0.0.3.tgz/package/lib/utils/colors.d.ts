export declare let partyColors: {
    color: string;
    name: string[];
}[];
