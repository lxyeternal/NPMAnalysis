/* eslint-disable @typescript-eslint/no-unused-vars */
ymaps3.import.loaders.unshift(async (pkg) => {
    if (!pkg.includes('@yandex/ymaps3-web-mercator-projection')) return;

    if (location.href.includes('localhost')) {
        await ymaps3.import.script(`/dist/index.js`);
    } else {
        await ymaps3.import.script(`https://unpkg.com/${pkg}/dist/index.js`);
    }

    return window['@yandex/ymaps3-web-mercator-projection'];
})


const BOUNDS = [
    [37.61022, 55.76450],
    [37.62687, 55.75556]
];

const LOCATION = {bounds: BOUNDS};
const SOURCE = {
    id: 'osmSource',
    zoomRange: {min: 0, max: 19},
    clampMapZoom: true,
    raster: {
        type: 'ground',
        fetchTile: 'https://tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png'
    },
    copyrights: ['© OpenStreetMap contributors']
};
const LAYER = {
    id: 'osm',
    source: 'osmSource',
    type: 'ground',
};
const MARKER = {title: 'Большой театр', coordinates: [37.618536, 55.760257]};
