"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var white="#fff";exports.default=white;
