"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var black="#242424";exports.default=black;
