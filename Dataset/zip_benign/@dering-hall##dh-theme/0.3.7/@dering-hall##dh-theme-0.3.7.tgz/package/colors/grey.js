"use strict";Object.defineProperty(exports,"__esModule",{value:!0});const grey={default:"#7d8087",light:"#ece9e4",dark:"#6d6d6a"};var grey$1=grey.default;exports.grey=grey,exports.default=grey$1;
