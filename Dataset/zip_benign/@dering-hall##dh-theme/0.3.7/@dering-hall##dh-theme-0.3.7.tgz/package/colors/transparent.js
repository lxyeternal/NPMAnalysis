"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var transparent="transparent";exports.default=transparent;
