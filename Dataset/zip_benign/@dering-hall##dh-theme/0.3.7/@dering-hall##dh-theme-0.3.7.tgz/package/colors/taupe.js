"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var taupe="#cdcbc5";exports.default=taupe;
