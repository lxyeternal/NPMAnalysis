"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var red="#b33232";exports.default=red;
