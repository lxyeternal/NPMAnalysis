"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var beige="#f5f3eb";exports.default=beige;
