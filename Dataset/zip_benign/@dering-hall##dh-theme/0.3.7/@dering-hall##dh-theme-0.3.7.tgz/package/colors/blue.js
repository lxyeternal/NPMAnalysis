"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var blue="#273050";exports.default=blue;
