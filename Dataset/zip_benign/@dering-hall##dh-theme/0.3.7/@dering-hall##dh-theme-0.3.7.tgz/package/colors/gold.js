"use strict";Object.defineProperty(exports,"__esModule",{value:!0});const gold={default:"#af9b79",light:"#b8a98b"};var gold$1=gold.default;exports.gold=gold,exports.default=gold$1;
