"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var blueGreen="#d6d9d5";exports.default=blueGreen;
