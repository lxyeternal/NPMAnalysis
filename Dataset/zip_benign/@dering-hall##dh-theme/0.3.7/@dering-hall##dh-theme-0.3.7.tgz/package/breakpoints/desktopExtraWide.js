"use strict";Object.defineProperty(exports,"__esModule",{value:!0});const desktopExtraWide=2200;exports.default=2200;
