"use strict";Object.defineProperty(exports,"__esModule",{value:!0});const mobile=320;exports.default=320;
