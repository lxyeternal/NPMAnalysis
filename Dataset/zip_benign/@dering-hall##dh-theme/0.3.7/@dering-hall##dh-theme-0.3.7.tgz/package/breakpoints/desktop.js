"use strict";Object.defineProperty(exports,"__esModule",{value:!0});const desktop=1024;exports.default=1024;
