"use strict";Object.defineProperty(exports,"__esModule",{value:!0});const tablet=768;exports.default=768;
