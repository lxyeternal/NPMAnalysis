"use strict";Object.defineProperty(exports,"__esModule",{value:!0});const desktopWide=1440;exports.default=1440;
