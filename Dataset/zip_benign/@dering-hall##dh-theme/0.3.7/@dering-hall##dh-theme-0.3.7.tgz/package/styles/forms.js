"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var taupe="#cdcbc5",forms={input:{borderColor:taupe,bgColor:"#f9f8f7"},placeholder:{color:"#d4d4d4"}};exports.default=forms;
