# tm-image-compress
+ new ImageCompress(file, quality)
+ file: 图片文件
+ quality: 压缩比例0.1-1 不传默认0.4
+ 内嵌lrz
