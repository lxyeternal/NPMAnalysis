class Foobar implements IWhatever {
}
