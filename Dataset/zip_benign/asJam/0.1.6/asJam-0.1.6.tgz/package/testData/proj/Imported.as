package {
        public class Imported {
        }
}
