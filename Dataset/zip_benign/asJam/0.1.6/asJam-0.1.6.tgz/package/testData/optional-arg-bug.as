function foobar(x:*={}) {
}
