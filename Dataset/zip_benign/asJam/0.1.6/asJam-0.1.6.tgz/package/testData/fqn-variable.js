var foo=new Rectangle()
