export declare class Options {
    private options;
    setAudioCodec(codec: string): this;
    setAudioBitrate(bitrate: string | number): this;
    setAudioChannels(channels: number): this;
    setAudioFilter(...filters: string[]): this;
    setAudioSamplingRate(sampleRate: number): this;
    setAudioQuality(quality: number): this;
    setFilterComplex(...filters: string[]): this;
    setCodecOptions(...codecOptions: (string | number)[]): this;
    setFormat(format: string): this;
    setVideoFilter(...filters: string[]): this;
    setVideoCodec(codec: string): this;
    setVideoBitrate(bitrate: number | string): this;
    private _baseFilters;
    setOthers(...options: (string | number)[]): this;
    setNoAudio(): this;
    setNoVideo(): this;
    ok(): (string | number)[];
}
