/// <reference types="node" />
/// <reference types="node" />
import { ChildProcessWithoutNullStreams } from "child_process";
import { Writable, Readable } from "stream";
export declare class FFmpeg {
    private inputStream;
    private outputStream;
    private ffmpegBinaryPath;
    private ffmpegArgs;
    private stdioArgs;
    constructor(ffmpegBinaryPath?: string);
    setOutputOptions(outputOptions: (string | number)[]): this;
    setInputOptions(inputOptions: (string | number)[]): this;
    setFFmpegOptions(ffmpegOptions: (string | number)[]): this;
    setInput(input: string | Readable): this;
    setOutput(output: string | Writable): this;
    run(): ChildProcessWithoutNullStreams;
}
