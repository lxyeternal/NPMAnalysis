# electron-custom-updater
[![NPM](https://nodei.co/npm/electron-custom-updater.png)](https://nodei.co/npm/electron-custom-updater/)

## Installation
```bash

$ npm install --save electron-custom-updater
```

```js
const { app, dialog } = require('electron');
const EAU = require('electron-custom-updater');

app.on('ready', function () {
  // Initiate the module
  EAU.init({
    'api': 'http://...', // The API EAU will talk to
    'server': false // Where to check. true: server side, false: client side, default: true.
  });

  EAU.check(function (error, last, body) {
    if (error) {
      if (error === 'no_update_available') { return false; }
      console.log(error)
      return false
    }

    EAU.progress(function (state) {
      // The state is an object that looks like this:
      // {
      //     percent: 0.5,               
      //     speed: 554732,              
      //     size: {
      //         total: 90044871,        
      //         transferred: 27610959   
      //     },
      //     time: {
      //         elapsed: 36.235,        
      //         remaining: 81.403       
      //     }
      // }
    })

    EAU.download(function (error) {
      if (error) {
        console.log(error)
        return false
      }
      console.log('App updated successfully! Restart it please.');
    })

  })
})
```

## License

:smiley: if you have any comments or wish to contribute to this project, you are welcome to submit Issues or PR.