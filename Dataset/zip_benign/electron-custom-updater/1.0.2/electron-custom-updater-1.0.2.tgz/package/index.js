const { app } = require('electron').remote
const FileSystem = require('original-fs')
const Utils = require('util')
const request = require('request')
const progress = require('request-progress')
const admZip = require('adm-zip')
const fs = require('fs');
const { shell } = require('electron')

// Yes, it's weird, but we need the trailing slash after the .asar
// so we can read paths "inside" it, e.g. the package.json, where we look
// for our current version


const AppPath = app.getAppPath() + '/'
const AppPathFolder = AppPath.slice(0, AppPath.indexOf('app.asar'))
const AppAsar = AppPath.slice(0, -1)
const WindowsUpdater =
  AppPath.slice(0, AppPath.indexOf('resources')) + 'updater.exe'

const errors = [
  'version_not_specified',
  'cannot_connect_to_api',
  'no_update_available',
  'api_response_not_valid',
  'update_file_not_found',
  'failed_to_download_update',
  'failed_to_apply_update'
]

/**
 * */
var Updater = {
  /**
   * The setup
   * */
  setup: {
    api: null,
    token: null,
    server: true,
    logFile: 'updater-log.txt',
    requestOptions: {},
    callback: false,
    progresscallback: false
  },

  /**
   * The new update information
   * */
  update: {
    last: null,
    source: null,
    file: null
  },

  /**
   * Init the module
   * */
  init: function (setup) {
    this.setup = Utils._extend(this.setup, setup)
  },

  /**
   * Logging
   * */
  log: function (line) {
    // Log it
    //console.log('Updater: ', line)

    // Put it into a file
    if (this.setup.logFile) {
      //console.log('%s + %s + %s', AppPathFolder, this.setup.logFile, line)
      FileSystem.appendFileSync(AppPathFolder + this.setup.logFile, line + '\n')
    }
  },

  /**
   * Triggers the callback you set to receive the result of the update
   * */
  end: function (error, body) {
    if (typeof this.setup.callback !== 'function') return false
    this.setup.callback.call(
      this,
      error != 'undefined' ? errors[error] : false,
      this.update.last,
      body
    )
  },

  /**
   * Make the check for the update
   * */
  check: function (callback) {
    if (callback) {
      this.setup.callback = callback
    }

    // Get the current version
    //debugger
    
    var packageInfo = {};
    packageInfo.version = localStorage.bot_version;

    
    //var packageInfo = require('C:\\Telegram\\package.json');
    // If the version property not specified
    if (!packageInfo.version) {
      
      this.log(
        'The "version" property not specified inside the application package.json'
      )
      this.end(0)

      return false
    }

    request(
      {
        url: this.setup.api,
        method: 'post',
        json: true,
        headers: this.setup.headers || {}
      },
      function (error, res, body) {
        

        if (!error) {
          try {
            let response = {}
            //console.log('Updater',Updater);
            if (Updater.setup.server) {
              response = { last: body.version, bluebotname: body.bluebotname}
              if (body.version > packageInfo.version) {
                response.source = body.source
              }

              //console.log("bodies",body.version,packageInfo.version,body);
              

              //console.log('true123');
            } else {
              response = { last: body.version, bluebotname: body.bluebotname }
              if (body.version > packageInfo.version) {
                response.source = body.asar
              }
             // console.log('false123');
            }

            //console.log("fgsdfgsdfgdsf",response.last);
            // If the "last" property is not defined
            if (!response.last) {
              throw false
            }

            // Update available
            //console.log("thisis",response);
            if (response.source) {
              Updater.log('Update available: ' + response.last)

              // Store the response
              Updater.update = response

              // Ask user for confirmation
              Updater.end(undefined, body)
            } else {
              Updater.log('No updates available')
              Updater.end(2)

              return false
            }
          } catch (error) {
            Updater.log(error, res, body)
            Updater.log('API response is not valid')
            Updater.end(3)
          }
        } else {
          Updater.log(error)
          Updater.log('Could not connect')
          Updater.end(1)
        }
      }
    )
  },

  /**
   * Download the update file
   * */
  download(downloadpath,callback) {
    if (callback) {
      this.setup.callback = callback
    }

    var url = this.update.source, fileName =  this.update.bluebotname

    //console.log('Downloading ' + url,fileName)

    Updater.downloadFile({ 
          remoteFile: url,
          localFile: app.getPath(downloadpath)+"/"+fileName,
          onProgress: (received,total)=>{
              var state = (received * 100) / total;

              if (Updater.setup.progresscallback) {
                Updater.setup.progresscallback(state)
              }
              
              
              //console.log(percentage + "% | " + received + " bytes out of " + total + " bytes.");
          }
      }).then(()=>{ 
          console.log("File succesfully downloaded");
          if (callback && typeof(callback) === "function") {
              callback(false)
          }
      });
  },
  downloadFile(configuration){
      return new Promise(function(resolve, reject){
          // Save variable to know progress
          var received_bytes = 0;
          var total_bytes = 0;

          var req = request({
              method: 'GET',
              uri: configuration.remoteFile
          });

          var out = fs.createWriteStream(configuration.localFile);
          req.pipe(out);

          req.on('response', function ( data ) {
              // Change the total bytes value to get progress later.
              total_bytes = parseInt(data.headers['content-length' ]);
          });

          // Get progress if callback exists
          if(configuration.hasOwnProperty("onProgress")){
              req.on('data', function(chunk) {
                  // Update the received bytes
                  received_bytes += chunk.length;

                  configuration.onProgress(received_bytes, total_bytes);
              });
          }else{
              req.on('data', function(chunk) {
                  // Update the received bytes
                  received_bytes += chunk.length;
              });
          }

          req.on('end', function() {
              resolve();
          });
      });
  } , 
  progress: function (callback) {
    if (callback) {
      this.setup.progresscallback = callback
    }
  },
}

module.exports = Updater
