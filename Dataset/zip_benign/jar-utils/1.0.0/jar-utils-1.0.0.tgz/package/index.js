const dateFormat=require('./src/dateFormat')
const number=require('./src/number')



module.exports ={
  ...dateFormat,
  ...number
}
