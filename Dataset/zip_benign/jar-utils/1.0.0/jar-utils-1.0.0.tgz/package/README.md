## 安装

、、、

npm install  jar-utils

、、、


## 导入

、、、js

const jarUtils=require('jar-utils')

、、、

## 格式化时间
、、、js

new Date().format('yyyy-MM-dd hh:mm')

、、、


## 加法
、、、js

//调用accAdd进行两数相加（确保精度）

let num=jarUtils.accAdd(0.1,0.2)

//结果 0.3

console.log(num)

、、、


## 减法
、、、js

//调用subtr进行两数相减（确保精度）

let num=jarUtils.subtr(0.3,0.1)

//结果 0.2

console.log(num)

、、、


## 乘法
、、、js

//调用accMul进行两数相乘（确保精度）

let num=jarUtils.accMul(0.1,0.2)

//结果 0.02

console.log(num)

、、、

