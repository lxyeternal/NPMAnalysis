import ast = require("./AST");
import ct = require("chevrotain");
export interface ITomlException {
    message: string;
    token: ct.IToken;
}
export declare const table: "table";
export interface TomlTable {
    type: typeof table;
    content: {
        [key: string]: any;
    };
}
export declare function tomlTable(content: object): TomlTable;
export declare type TomlError = ct.ILexingError | ct.IRecognitionException | ITomlException;
export declare class TomlReader {
    result: any;
    entries: ast.TopLevelTomlDocumentEntry[];
    errors: TomlError[];
    /**
     * Read a TOML document
     *
     * @param input the TOML document string
     * @param fullValue wheter the full typing information will be returned or not
     */
    readToml(input: string, fullValue?: boolean): void;
}
