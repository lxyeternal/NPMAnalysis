import ct = require("chevrotain");
export declare class TomlParser extends ct.Parser {
    documentRule: (idxInCallingRule?: number, ...args: any[]) => any;
    keysValueRule: (idxInCallingRule?: number, ...args: any[]) => any;
    valueRule: (idxInCallingRule?: number, ...args: any[]) => any;
    arrayRule: (idxInCallingRule?: number, ...args: any[]) => any;
    inlineTableRule: (idxInCallingRule?: number, ...args: any[]) => any;
    tableHeaderRule: (idxInCallingRule?: number, ...args: any[]) => any;
    tableArrayEntryHeaderRule: (idxInCallingRule?: number, ...args: any[]) => any;
    basicStringRule: (idxInCallingRule?: number, ...args: any[]) => any;
    literalStringRule: (idxInCallingRule?: number, ...args: any[]) => any;
    multiLineBasicStringRule: (idxInCallingRule?: number, ...args: any[]) => any;
    multiLineLiteralStringRule: (idxInCallingRule?: number, ...args: any[]) => any;
    identifierRule: (idxInCallingRule?: number, ...args: any[]) => any;
    constructor(tokenTypes: ct.TokenVocabulary);
}
