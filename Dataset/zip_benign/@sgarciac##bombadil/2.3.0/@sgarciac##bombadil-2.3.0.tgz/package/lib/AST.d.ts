import ct = require("chevrotain");
/**
 * The code in this file follows a general pattern.  First, I introduce a string literal
 * to use as the "tag" in the tagged unions.  I assign that literal to a variable so that
 * we don't actually use string literals in the code.  Forcing the use of the variable
 * allows us to catch potential errors.
 *
 * In addition, an interface for each node type is then defined.  Generally speaking, this
 * interface, while exported, isn't actually that useful outside this file.  But there are
 * some cases where they are used (hence the export).  The main reason to include the
 * interface definition is just to explicitly state the contents of the node.
 *
 * Finally, I include a "constructor" function for each interface.  Since these are interfaces
 * and not classes, we need to define our constructor function separately.  Now, a reasonable
 * question would be "why not uses classes and a constructor defined in the class?".  The
 * reason is because once you have a class, you can use `instanceof` on the instances and
 * this is dangerous because classes are values and if classes and instances are imported
 * from different packages, things will not line up and you'll get very confusing results.
 * Using these tagged unions and interfaces avoids this but still gives a type safe way
 * to "switch" on different node types.
 */
export declare const tableHeader: "tableHeader";
export interface TomlTableHeader {
    type: typeof tableHeader;
    headers: string[];
    token: ct.IToken;
}
export declare function tomlTableHeader(headers: string[], token: ct.IToken): TomlTableHeader;
export declare const tableArrayEntryHeader: "tableArrayEntryHeader";
export interface TomlTableArrayEntryHeader {
    type: typeof tableArrayEntryHeader;
    headers: string[];
    token: ct.IToken;
}
export declare function tomlTableArrayEntryHeader(headers: string[], token: ct.IToken): TomlTableArrayEntryHeader;
export declare const keysValue: "keysValue";
export interface TomlKeysValue {
    type: typeof keysValue;
    keys: string[];
    value: any;
    token: ct.IToken;
}
export declare function tomlKeysValue(keys: string[], value: any, token: ct.IToken): TomlKeysValue;
export declare const inlineTable: "inlineTable";
export interface TomlInlineTable {
    type: typeof inlineTable;
    bindings: TomlKeysValue[];
}
export declare function tomlInlineTable(bindings: TomlKeysValue[]): TomlInlineTable;
export declare const arrayType: "tomlArray";
export interface TomlArray {
    type: typeof arrayType;
    contents: TomlValue[];
    token: ct.IToken;
}
export declare function tomlArray(contents: TomlValue[], token: ct.IToken): {
    type: "tomlArray";
    contents: TomlValue[];
    token: ct.IToken;
};
export declare enum TomlAtomicValueType {
    OffsetDateTime = 0,
    LocalDateTime = 1,
    LocalDate = 2,
    LocalTime = 3,
    String = 4,
    Integer = 5,
    Float = 6,
    Boolean = 7
}
export interface TomlAtomicGeneric<T> {
    image: string;
    value: T;
}
export declare const offsetDateTime: "offsetDateTime";
export declare const localDateTime: "localDateTime";
export declare const localDate: "localDate";
export declare const localTime: "localTime";
export interface TomlAtomicDateTime extends TomlAtomicGeneric<Date> {
    type: typeof offsetDateTime | typeof localDateTime | typeof localDate | typeof localTime;
}
export declare function tomlAtomicOffsetDateTime(image: string, value: Date): TomlAtomicDateTime;
export declare function tomlAtomicLocalDateTime(image: string, value: Date): TomlAtomicDateTime;
export declare function tomlAtomicLocalDate(image: string, value: Date): TomlAtomicDateTime;
export declare function tomlAtomicLocalTime(image: string, value: Date): TomlAtomicDateTime;
export declare const atomicString: "atomicString";
export interface TomlAtomicString extends TomlAtomicGeneric<string> {
    type: typeof atomicString;
}
export declare function tomlAtomicString(image: string, value: string): TomlAtomicString;
export declare const atomicInteger: "atomicInteger";
export interface TomlAtomicInteger extends TomlAtomicGeneric<number> {
    type: typeof atomicInteger;
}
export declare function tomlAtomicInteger(image: string, value: number): TomlAtomicInteger;
export declare const atomicFloat: "atomicFloat";
export interface TomlAtomicFloat extends TomlAtomicGeneric<number> {
    type: typeof atomicFloat;
}
export declare function tomlAtomicFloat(image: string, value: number): TomlAtomicFloat;
export declare const atomicNotANumber: "atomicNotANumber";
export interface TomlAtomicNotANumber extends TomlAtomicGeneric<number> {
    type: typeof atomicNotANumber;
}
export declare function tomlAtomicNotANumber(image: string, value: number): TomlAtomicNotANumber;
export declare const atomicInfinity: "atomicInfinity";
export interface TomlAtomicInfinity extends TomlAtomicGeneric<number> {
    type: typeof atomicInfinity;
}
export declare function tomlAtomicInfinity(image: string, value: number): TomlAtomicInfinity;
export declare const atomicBoolean: "atomicBoolean";
export interface TomlAtomicBoolean extends TomlAtomicGeneric<boolean> {
    type: typeof atomicBoolean;
}
export declare function tomlAtomicBoolean(image: string, value: boolean): TomlAtomicBoolean;
export declare type TomlAtomicValue = TomlAtomicDateTime | TomlAtomicString | TomlAtomicInteger | TomlAtomicFloat | TomlAtomicBoolean | TomlAtomicInfinity | TomlAtomicNotANumber;
export declare type TopLevelTomlDocumentEntry = TomlKeysValue | TomlTableHeader | TomlTableArrayEntryHeader;
export declare type TomlValue = TomlAtomicValue | TomlInlineTable | TomlArray;
