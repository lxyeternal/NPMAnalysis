const ThrowFun=require('./lib/kk-throw.js')

module.exports ={
    throw:ThrowFun.Throw
}