/*
Unspam by Flarp

A quick little module that keeps track of how fast and how many times a user accesses something. 
If the user goes too fast, buh-bye :D
*/

let arr = [];
const obj = {};
const defaults = {
    maxRequestRate:0.5, 
    banTime:5,
    cacheInterval:30000
}
let opts = {};
const empty = [];
module.exports.bans = []; // Where are the trouble makers go. It's exported so you can store it in a database if you would like.

module.exports.init = function(options) {
    opts = Object.assign(options, defaults) // Will set opts to defaults, but if a key in defaults is present in options, it will replace the default key with the options key
}

module.exports.ban = function(ip) {
    const d = new Date()
    module.exports.bans.unshift({ip:ip,time:d.getTime()}) 
    /*
    Unshifting (to the front) is a lot better then pushing (to the back) because
    if the user is attacking the system, the user will probably reconnect plenty of times.
    When you push something, you're putting it at the bottom of the array, so the program will
    have to loop to the end of the array to know he's banned. However, the program will not have to go too far
    with unshifting, because all new bans are put at the front. Newer bans are in the front,
    older bans are in the back.
    */
    
}

module.exports.attachSocket = function(socket, callback) {
    module.exports.register(socket._socket.remoteAddress, function(error) {
        if (!error) {
            callback()
        } else {
            return
        }
        socket.on('message', function unspamListener() {
            module.exports.rateLimit(socket._socket.remoteAddress, function(error) {
                if (error) {
                    socket.removeAllListeners('message')
                }
            })
        })
    })
}

const check = function(ip) {
    return !module.exports.bans.some(obj => obj.ip === ip)
    /*
    Pretty much just a trivial standard search. Array.prototype.some() will terminate the second it
    finds a match, so it will not have to go through the entire array. It inverts the result because it should
    return true if nothing is found, and false if something is.
    */
}

let RSU = false;
let REB = false;

const removeStaleUsers = function() {
    setInterval(function() {
        const d = new Date()
        arr = arr.filter(obj => d.getTime() < (obj.time + (opts.banTime * 60000)))
    }, opts.cacheInterval * 60000)
}

const removeExpiredBans = function() {
    setInterval(function() {
        const d = new Date()
        module.exports.bans = module.exports.bans.filter(obj => d.getTime() < (obj.time + (opts.banTime * 60000)))
    }, opts.cacheInterval * 60000)
}

module.exports.expressMiddleware = function(req, res, next) {
    if (!RSU) { // if the removal of stale users hasn't started
        removeStaleUsers() // start it
        RSU = true
    }
    if (!REB) { // if the removal of expired bans hasn't started
        removeExpiredBans() // start it
        REB = true
    }
    
    const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress; // I bummed this from SO, sorry :P
    if (check(ip)) {
        if (obj[ip]) {
            module.exports.rateLimit(ip, next)
        } else {
            module.exports.register(ip, next)
        }
    } else {
        res.sendStatus(403).end() // tell the user they're done for and end the response process
    }
}

module.exports.register = function(ip, callback) {
    console.log(module.exports.bans)
        if (check(ip)) {
            const d = new Date() // get the time of the last access, which in this case is the first one.
                    if (empty.length) { // If there are no empty spots in the storage array where each session is stored.
                        obj[ip] = empty.shift() // remove something off the front of the empty array, and use it as the place in the array for the session storage.
                        arr[obj[ip]] = {lastAccessed:d.getTime(),totalAccesses:1}
                    } else {
                        obj[ip] = arr.push({lastAccessed:d.getTime(),totalAccesses:1}) - 1
                        
                    }
                    callback(false)
    
                
        } else {
            callback(true)
        }
                    
}

module.exports.rateLimit = function (ip, callback) {
                    const d = new Date()
                    const current = arr[obj[ip]]
                    const last = current.lastAccessed
                    current.lastAccessed = d.getTime()
                    if(current.average) { // if there is a pre-existing average
                        current.totalAccesses++
                        const average = ((current.lastAccessed - last))/(current.totalAccesses) 
                        /*
                        This is where the magic happens. The formula is above, but to put it in English, it
                        pretty much just divides the amount of times the client has accessed something
                        by the average of the times in between each access. So, let's give an example.
                        
                        Bob has accessed the system 5 times (and is accessing it again, so add one), with an average of 10ms in between.
                        
                        10/(6) = 1.6666...
                        
                        Alice, on the other hand, is being evil. She has accessed the system
                        100 times, with an average of 2ms in between. Yikes, let's do the math.
                        
                        2/100 = 0.02
                        
                        No good, but every time someone accesses the system, this number will be stored in their own object
                        assigned to their IP, along with all other necessary information.
                        
                        */
                        
                        current.average = average
                    } else { // if not
                        current.average = current.lastAccessed-last // make one c:
                    }
                    if ((current.average) < opts.maxRequestRate) {
                        /*
                        If the number stated above goes below the number you entered in the options,
                        the user is considered to be spamming, and will be banned.
                        */
                        module.exports.ban(ip)
                        callback([new Error('Client has exceeded request rate'), ip])
                    } else {
                        callback(false)
                    }
                
            
    
}

module.exports.remove = function(ip) {
    empty.push(obj[ip]) // tell the register function there is a gap in the array
    arr[obj[ip]] = null // make the gap
    delete obj[ip] // Delete the reference to the IP object
}

