/// <reference types="react" />
import { Animated } from 'react-native';
import type { Trigger } from './types';
export declare const useDoubleSlider: (triggers: Trigger[]) => {
    panResponder: import("react-native").PanResponderInstance;
    sliderWidth: number;
    constrainedDx: Animated.AnimatedInterpolation;
    increasingInterpolatePositive: Animated.AnimatedInterpolation;
    decreasingInterpolatePositive: Animated.AnimatedInterpolation;
    increasingInterpolateNegative: Animated.AnimatedInterpolation;
    decreasingInterpolateNegative: Animated.AnimatedInterpolation;
    idleTextOpacity: Animated.Value;
    setSliderWidth: import("react").Dispatch<import("react").SetStateAction<number>>;
    calculateTargetPosition: (percentPosition: number) => number;
};
