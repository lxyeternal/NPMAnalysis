export { DoubleSlider } from './DoubleSlider';
