import React from 'react';
import { Animated, StyleProp, TextStyle, ViewStyle } from 'react-native';
interface Props {
    children: React.ReactNode;
    opacity: Animated.AnimatedInterpolation;
    textStyle?: Animated.WithAnimatedValue<StyleProp<TextStyle>>;
    containerStyle?: StyleProp<ViewStyle>;
}
export declare const AnimatedText: React.FC<Props>;
export {};
