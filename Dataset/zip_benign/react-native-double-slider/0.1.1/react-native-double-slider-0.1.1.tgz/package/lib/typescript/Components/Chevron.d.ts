import React from 'react';
import { Animated, TextStyle } from 'react-native';
export declare const Chevron: {
    Left: React.FC<{
        opacity: Animated.AnimatedInterpolation;
        arrowStyle?: TextStyle | undefined;
    }>;
    Right: React.FC<{
        opacity: Animated.AnimatedInterpolation;
        arrowStyle?: TextStyle | undefined;
    }>;
};
export default Chevron;
