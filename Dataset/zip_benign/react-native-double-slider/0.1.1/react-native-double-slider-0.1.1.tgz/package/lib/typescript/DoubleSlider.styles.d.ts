export declare const styles: {
    beam: {
        width: string;
        backgroundColor: string;
        height: number;
        borderWidth: number;
        borderColor: string;
        borderRadius: number;
    };
    beamFixedStyle: {
        alignItems: "center";
        justifyContent: "center";
    };
    handle: {
        height: number;
        width: number;
        backgroundColor: string;
        borderRadius: number;
        borderWidth: number;
        borderColor: string;
    };
    handleContainer: {
        justifyContent: "center";
        alignItems: "center";
        position: "absolute";
        flexDirection: "row";
    };
    textContainer: {
        position: "absolute";
    };
    text: {
        color: string;
        alignSelf: "center";
    };
    leftText: {
        left: string;
    };
    rightText: {
        right: string;
    };
    targetContainer: {
        alignItems: "center";
        justifyContent: "center";
        position: "absolute";
    };
};
