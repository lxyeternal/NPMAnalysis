import React from 'react';
import type { DoubleSliderProps } from './types';
export declare const DoubleSlider: React.FC<DoubleSliderProps>;
