export declare const constrainXBetweenMinAndMax: (x: number, min: number, max: number) => number;
