# @logo-elements/progress-bar

A web component for showing the completion status of a task or process.


[![npm version](https://badgen.net/npm/v/@logo-elements/progress-bar)](https://www.npmjs.com/package/@logo-elements/progress-bar)

```html
<logo-elements-progress-bar></logo-elements-progress-bar>
<logo-elements-progress-bar value="0.3"></logo-elements-progress-bar>
<logo-elements-progress-bar indeterminate></logo-elements-progress-bar>
```

## Installation

Install the component:

```sh
npm i @logo-elements/progress-bar -s
```

Once installed, import the component in your application:

```js
import '@logo-elements/progress-bar';
```

### For more detailed information, please visit:
[Logo Elements Documentation ↗](http://elements.logo.com.tr)
