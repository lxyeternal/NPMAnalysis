# Slider

- category: UI
- chinese: 轮播
- type: UI组件

---


## 何时使用

图片轮播组件

## API

### Slider

属性 | 说明 | 类型 | 默认值
-----|-----|-----|------
width | 宽度  | string | '750rem'
height | 高度 | string | '352rem'
autoplay | 是否自动播放 | boolean | false
showsPagination | 是否展示分页 | boolean | true
loop | 是否循环播放 | boolean | true
autoplayTimeout | 循环播放间隔 | boolean | true
paginationStyle| 分页样式 | array | 无
onChange| change 事件 | function | 无
index| 默认初始化第几个 | string | 0

### slideTo 实例方法

`this.refs.Slider.slideTo(index)` 从外部切换slider


### paginationStyle 特殊字段解释

属性 | 说明 | 类型 | 默认值
-----|-----|-----|------
itemSize | dot的大小  | number | 8
itemColor | 未选中dot的颜色 | string，rgb 或 rgba | rgba(255, 255, 255, 0.5)
itemSelectedColor | 选中dot的颜色 | string，rgb 或 rgba | rgb(255, 80, 0)


### 实验特性，暂不稳定

属性 | 说明 | 类型 | 默认值
-----|-----|-----|------
accuracy | 滑动触发事件精度  | string | 1
onScroll | 滑动触发事件回调，回调的触发频率与事件精度有关 | function | {}


## 其他
- bug、建议联系 <a href="dingtalk://dingtalkclient/action/sendmsg?dingtalk_id=kjwo3w5">@翊晨</a>
- 钉钉交流群

<img src="https://img.alicdn.com/tfs/TB101EESpXXXXXFXpXXXXXXXXXX-1122-1362.jpg" width="260" /> 
