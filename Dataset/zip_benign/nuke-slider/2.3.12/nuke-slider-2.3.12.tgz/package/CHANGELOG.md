# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.3.12](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.3.11...v2.3.12) (2019-09-26)

**Note:** Version bump only for package nuke-slider





## [2.3.11](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.3.10...v2.3.11) (2019-09-26)

**Note:** Version bump only for package nuke-slider





## [2.3.10](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.3.9...v2.3.10) (2019-09-26)

**Note:** Version bump only for package nuke-slider





## [2.3.9](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.3.8...v2.3.9) (2019-09-26)

**Note:** Version bump only for package nuke-slider





## [2.3.8](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.3.7...v2.3.8) (2019-09-25)

**Note:** Version bump only for package nuke-slider





## [2.3.7](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.3.6...v2.3.7) (2019-07-24)

**Note:** Version bump only for package nuke-slider





## [2.3.6](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.3.5...v2.3.6) (2019-07-19)

**Note:** Version bump only for package nuke-slider





## [2.3.5](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.3.4...v2.3.5) (2019-07-02)

**Note:** Version bump only for package nuke-slider





## [2.3.4](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.3.3...v2.3.4) (2019-05-10)

**Note:** Version bump only for package nuke-slider





## [2.3.3](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.3.2...v2.3.3) (2019-04-28)

**Note:** Version bump only for package nuke-slider





## [2.3.2](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.3.1...v2.3.2) (2019-01-15)

**Note:** Version bump only for package nuke-slider





## [2.3.1](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.3.0...v2.3.1) (2019-01-15)

**Note:** Version bump only for package nuke-slider





# [2.3.0](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.29...v2.3.0) (2018-11-14)


### Features

* mutiple-platform module done ([3f12afb](https://gitlab.alibaba-inc.com/nuke/slider/commit/3f12afb))
* 将UI组件与功能库拆分 ([f5d0a2c](https://gitlab.alibaba-inc.com/nuke/slider/commit/f5d0a2c))





## [2.2.29](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.28...v2.2.29) (2018-10-09)


### Bug Fixes

* fix en.md api ([75eec59](https://gitlab.alibaba-inc.com/nuke/slider/commit/75eec59))





## [2.2.28](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.27...v2.2.28) (2018-10-09)

**Note:** Version bump only for package nuke-slider





## [2.2.27](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.26...v2.2.27) (2018-10-08)

**Note:** Version bump only for package nuke-slider





<a name="2.2.26"></a>
## [2.2.26](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.25...v2.2.26) (2018-10-08)

**Note:** Version bump only for package nuke-slider





<a name="2.2.25"></a>
## [2.2.25](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.24...v2.2.25) (2018-10-08)

**Note:** Version bump only for package nuke-slider





<a name="2.2.24"></a>
## [2.2.24](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.23...v2.2.24) (2018-10-08)

**Note:** Version bump only for package nuke-slider





<a name="2.2.23"></a>
## [2.2.23](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.22...v2.2.23) (2018-10-08)

**Note:** Version bump only for package nuke-slider





<a name="2.2.22"></a>
## [2.2.22](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.21...v2.2.22) (2018-10-08)

**Note:** Version bump only for package nuke-slider





<a name="2.2.21"></a>
## [2.2.21](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.19...v2.2.21) (2018-10-08)

**Note:** Version bump only for package nuke-slider





<a name="2.2.20"></a>
## [2.2.20](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.19...v2.2.20) (2018-10-08)

**Note:** Version bump only for package nuke-slider





<a name="2.2.19"></a>
## [2.2.19](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.18...v2.2.19) (2018-10-08)

**Note:** Version bump only for package nuke-slider





<a name="2.2.18"></a>
## [2.2.18](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.17...v2.2.18) (2018-09-30)

**Note:** Version bump only for package nuke-slider





<a name="2.2.17"></a>
## [2.2.17](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.16...v2.2.17) (2018-09-26)

**Note:** Version bump only for package nuke-slider





<a name="2.2.16"></a>
## [2.2.16](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.15...v2.2.16) (2018-09-19)

**Note:** Version bump only for package nuke-slider





<a name="2.2.15"></a>
## [2.2.15](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.14...v2.2.15) (2018-09-19)

**Note:** Version bump only for package nuke-slider





<a name="2.2.14"></a>
## [2.2.14](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.13...v2.2.14) (2018-09-11)

**Note:** Version bump only for package nuke-slider





<a name="2.2.13"></a>
## [2.2.13](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.12...v2.2.13) (2018-09-11)

**Note:** Version bump only for package nuke-slider





<a name="2.2.12"></a>
## [2.2.12](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.11...v2.2.12) (2018-09-11)

**Note:** Version bump only for package nuke-slider





<a name="2.2.11"></a>
## [2.2.11](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.10...v2.2.11) (2018-09-06)

**Note:** Version bump only for package nuke-slider





<a name="2.2.10"></a>
## [2.2.10](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.9...v2.2.10) (2018-09-06)

**Note:** Version bump only for package nuke-slider





<a name="2.2.9"></a>
## [2.2.9](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.8...v2.2.9) (2018-09-06)

**Note:** Version bump only for package nuke-slider





<a name="2.2.8"></a>
## [2.2.8](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.7...v2.2.8) (2018-09-05)

**Note:** Version bump only for package nuke-slider





<a name="2.2.7"></a>
## [2.2.7](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.6...v2.2.7) (2018-09-05)

**Note:** Version bump only for package nuke-slider





<a name="2.2.6"></a>
## [2.2.6](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.5...v2.2.6) (2018-09-04)

**Note:** Version bump only for package nuke-slider





<a name="2.2.5"></a>
## [2.2.5](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.4...v2.2.5) (2018-09-04)

**Note:** Version bump only for package nuke-slider





<a name="2.2.4"></a>
## [2.2.4](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.3...v2.2.4) (2018-09-04)

**Note:** Version bump only for package nuke-slider





<a name="2.2.3"></a>
## [2.2.3](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.2...v2.2.3) (2018-08-24)

**Note:** Version bump only for package nuke-slider





<a name="2.2.2"></a>
## [2.2.2](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.1...v2.2.2) (2018-08-23)

**Note:** Version bump only for package nuke-slider





<a name="2.2.1"></a>
## [2.2.1](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.2.0...v2.2.1) (2018-08-23)

**Note:** Version bump only for package nuke-slider





<a name="2.2.0"></a>
# [2.2.0](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.1.10...v2.2.0) (2018-08-23)


### Bug Fixes

* merge conflict ([7a4e427](https://gitlab.alibaba-inc.com/nuke/slider/commit/7a4e427))


### Features

* add jest test suite ([ebe6aba](https://gitlab.alibaba-inc.com/nuke/slider/commit/ebe6aba))





<a name="2.1.10"></a>
## [2.1.10](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.1.9...v2.1.10) (2018-08-20)

**Note:** Version bump only for package nuke-slider





<a name="2.1.9"></a>
## [2.1.9](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.1.8...v2.1.9) (2018-08-20)

**Note:** Version bump only for package nuke-slider





<a name="2.1.8"></a>
## [2.1.8](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.1.6...v2.1.8) (2018-08-20)

**Note:** Version bump only for package nuke-slider





<a name="2.1.6"></a>
## [2.1.6](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.1.4...v2.1.6) (2018-08-15)

**Note:** Version bump only for package nuke-slider





<a name="2.1.3"></a>
## [2.1.3](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.1.2...v2.1.3) (2018-08-15)

**Note:** Version bump only for package nuke-slider





<a name="2.1.1"></a>
## [2.1.1](https://gitlab.alibaba-inc.com/nuke/slider/compare/v2.1.1-4.3...v2.1.1) (2018-08-15)

**Note:** Version bump only for package nuke-slider
