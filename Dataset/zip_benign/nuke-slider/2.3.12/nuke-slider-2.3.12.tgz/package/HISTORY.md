# Changelog 


## 2.0.1 / 2018-07-23 

  * [[ded5f16](http://gitlab.alibaba-inc.com/nuke/slider/commit/ded5f163700cc7c8f542f1f6e74f3e5918f9d890)] - `fix` fix slider data change issue in web 

## 2.0.0 / 2018-03-26 

  * [[6991ddc](http://gitlab.alibaba-inc.com/nuke/slider/commit/6991ddc724fd6619a294a05d9f9149f388ae94e0)] - `feat` update dependencies 

## 1.0.0 / 2017-11-04 

  * [[fe1e56a](http://gitlab.alibaba-inc.com/nuke/slider/commit/fe1e56a0913999d6b4601439a2b8836bc3e6ab03)] - `feat` update dependency 

## 0.3.12 / 2017-10-21 

  * [[8a24f32](http://gitlab.alibaba-inc.com/nuke/slider/commit/8a24f32b1ea279d0c0e50d0a25b86d993075720f)] - `fix` demo autoPlayautoPlay 

## 0.3.10 / 2017-08-18 

  * [[ceb0abc](http://gitlab.alibaba-inc.com/nuke/slider/commit/ceb0abcd99787fe247a066dd20ea67241f96b5aa)] - `fix` 小圆点样式合并逻辑更新 

## 0.3.9 / 2017-08-18 

  * [[5599d85](http://gitlab.alibaba-inc.com/nuke/slider/commit/5599d856b9682eb2548dd6c72a126e211e8f14cc)] - `fix` 尝试修复 slider 切换不能触发的问题 

## 0.3.8 / 2017-08-17 

  * [[5118384](http://gitlab.alibaba-inc.com/nuke/slider/commit/5118384c010db9e1ab652d3773adc48b122860e7)] - `fix` native 端 overflow hidden,美化demo 

## 0.3.7 / 2017-08-09 

  * [[06ba0aa](http://gitlab.alibaba-inc.com/nuke/slider/commit/06ba0aac98876da71591d813958a6f59ce0c5963)] - `fix` fix onchange onsrcoll 

## 0.3.6 / 2017-07-31 

  * [[87fdbb3](http://gitlab.alibaba-inc.com/nuke/slider/commit/87fdbb355a47106cd09a90afcc9026f90f2ffe01)] - `fix` bizpage to page 

## 0.3.5 / 2017-06-14 

  * [[4d1cd80](http://gitlab.alibaba-inc.com/nuke/slider/commit/4d1cd807d4e25333d43aaec7dbf866994d23e3ba)] - `docs` update docs 

## 0.3.4 / 2017-06-07 

  * [[2b07bff](http://gitlab.alibaba-inc.com/nuke/slider/commit/2b07bff5a65a0d56712fe12db2083206a25bc933)] - `fix` update docs order 

## 0.3.3 / 2017-06-05 

  * [[6862e6b](http://gitlab.alibaba-inc.com/nuke/slider/commit/6862e6b31ae6610f756575c561fe19ee3a39565e)] - `docs` update dependencies && demos 
  * [[9bee278](http://gitlab.alibaba-inc.com/nuke/slider/commit/9bee278558198f56036b976f5c59bd562225eb75)] - `docs` update docs 

## 0.3.2 / 2017-03-15 

  * [[41d79e4](http://gitlab.alibaba-inc.com/nuke/slider/commit/41d79e41edb689ca2aed2c0a977d3212c75c8be3)] - `fix` demo无法展示 

## 0.3.1 / 2017-03-15 

  * [[78a1a1b](http://gitlab.alibaba-inc.com/nuke/slider/commit/78a1a1b2b25be674a34da90c4f6c009f9a6da51d)] - `fix` android index参数无效 
  * [[1c5887e](http://gitlab.alibaba-inc.com/nuke/slider/commit/1c5887e68db3df8e1b5149cb3c88a2c047ed4e09)] - `fix` android index参数无效 
  * [[58e994c](http://gitlab.alibaba-inc.com/nuke/slider/commit/58e994ceb77a43770f752a61d9bd5bce5b32b93a)] - `feat` update docs && readme 
  * [[b45be04](http://gitlab.alibaba-inc.com/nuke/slider/commit/b45be0472b80062606672ab589fb02c3fb62d1a7)] - `feat` 更新slideTo文档 

## 0.3.0 / 2017-02-17 

  * [[fba0868](http://gitlab.alibaba-inc.com/nuke/slider/commit/fba08685363079a9918dcbd0e1f0a7f384894357)] - `feat` rax升级 

## 0.2.2 / 2017-02-13 

  * [[2dcbecf](http://gitlab.alibaba-inc.com/nuke/slider/commit/2dcbecfde77d6c15a1f93bedaf2dfb39eb0e72dc)] - `feat` 开放itemColor、size等定义属性 

## 0.2.0 / 2017-01-11 

  * [[43b6815](http://gitlab.alibaba-inc.com/nuke/slider/commit/43b681533ffc9bf3a57895df8a6e19e901380898)] - `feat` native新增滚动精度及事件API 
  * [[9c9e7c7](http://gitlab.alibaba-inc.com/nuke/slider/commit/9c9e7c7d3afef5825d5b276baa9caf2175550268)] - `feat` 新增accuracy&&onScroll API 
  * [[ac9093e](http://gitlab.alibaba-inc.com/nuke/slider/commit/ac9093e14a23dfb06a90d09022b5bacc6a6b2eec)] - `feat` 拆包&&bugfix 
