#!/bin/bash
svgs=./svgs

html='<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="../node_modules/@fortawesome/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="../css/main.min.css">
  <link rel="stylesheet" href="../css/test.css">
</head>
<body>
  <table>
    <thead>
      <tr>
        <th>Name</th>
        <th>Font-Awesome</th>
        <th>Icons LK</th>
      </tr>
    <thead>
    <tbody>
'

echo "$html" > ./test/icons.html

echo -e "// Icons Libre Kiwi" > ./scss/icons-custom.scss
echo -e "// Icons Libre Kiwi" > ./scss/icons-all.scss

for i in $svgs/*/; do
  folder=$(echo $i | cut -d '/' -f 3) # brand, regular, solid, etc
  mkdir -p ./scss/icons/$folder

  if [[ $(ls ./svgs/$folder/*.svg 2>/dev/null) ]]; then
    echo -e "
/* $folder ------------------------------------------------------------------ */
.#{\$lk-css-prefix}, .#{\$lk-css-prefix}${folder:0:1} {" >> ./scss/icons-custom.scss
   echo -e "
/* $folder ------------------------------------------------------------------ */
.#{\$lk-css-prefix}, .#{\$lk-css-prefix}${folder:0:1} {" >> ./scss/icons-all.scss

    for j in $svgs/$folder/*.svg; do
      filename=$(echo $j | cut -d '/' -f 4 | cut -d '.' -f 1)

      echo "
      <tr>
        <td>$filename</td>
        <td><i class=\"fa${folder:0:1} fa-$filename\"></i></td>
        <td><i class=\"lk${folder:0:1} lk-$filename\"></i></td>
      <tr>" >> ./test/icons.html

      # Add filename to folder.scss
      echo "//  @import '~fs-iconslk/scss/icons/$folder/$filename';" >> ./scss/icons-custom.scss
      echo "  @import 'icons/$folder/$filename';" >> ./scss/icons-all.scss

      # Make lk-<filename>.scss
      credits=$(sed -e 's/.*<!--! \(.*\) -->.*/\1/' $j) # Font Awesome credits
      svg=$(sed -r 's/<!--! .* -->//' $j) # Get SVG without credits
      size=$(sed -e 's/.*viewBox="0 0 \([0-9 ]*\)".*/\1/' $j);
      width=$(echo "scale=3; ${size% *} / ${size#* }" | bc)
      max=$(( ${size% *} > ${size#* } ? ${size% *} : ${size#* } ))
      square=$(echo "scale=3; ${max} / ${size#* }" | bc)

      echo "// $credits" > ./scss/icons/$folder/$filename.scss
      echo "&.#{\$lk-css-prefix}-$filename {--icon: url('data:image/svg+xml,$svg');--width: ${width}em;--square: ${square}em;&::before{content: '';}}" >> ./scss/icons/$folder/$filename.scss

      echo -e "✔️  $folder/$filename"
   done

    echo -e "}" >> ./scss/icons-custom.scss
    echo -e "}" >> ./scss/icons-all.scss
  fi
done

echo "
    </tbody>
  </table>
</bdoy>
</html>" >> ./test/icons.html
