Icons Libre Kiwi License
-------------------------

Icons Libre Kiwi is free, open source, and GPL friendly. You can use it for
commercial projects, open source projects, or really almost whatever you want.

## Icons: CC BY 4.0 License (https://creativecommons.org/licenses/by/4.0/)
In the Icons Libre Kiwi download, the CC BY 4.0 license applies to all icons
(*.svg.scss files) and comes from Font Awesome.
https://github.com/FortAwesome/Font-Awesome

## Code: MIT License (https://opensource.org/licenses/MIT)
In the Icons Libre Kiwi download, the MIT license applies to all non-icon files.

## Attribution
Attribution is required by MIT and CC BY licenses. Downloaded Icons Libre Kiwi
files already contain embedded comments with sufficient
attribution, so you shouldn't need to do anything additional when using these
files normally.

We've kept attribution comments terse, so we ask that you do not actively work
to remove them from files, especially code. They're a great way for folks to
learn about Icons Libre Kiwi.

## Brand Icons
All brand icons are trademarks of their respective owners. The use of these
trademarks does not indicate endorsement of the trademark holder by Icons Libre Kiwi,
nor vice versa.
**Please do not use brand logos for any purpose except
to represent the company, product, or service to which they refer.**