<template>
  <view class="image-box class" :style="style || myStyle">
    <canvas
      class="canvas"
      :style="customStyle"
      canvas-id="main-canvas"
      id="main-canvas"
      type="webgl"
    ></canvas>
  </view>
</template>

<script>
const { ArSdk } = requirePlugin("webarPlugin"); //引入插件

export default {
  externalClasses: ["class"],
  props: {
    licenseKey: {
      type: String,
      default: "",
    },
    appId: {
      type: String,
      default: "",
    },
    authFunc: {
      type: Function,
    },
    plugin3d: {
      type: Function,
    },
    beautify: { type: Object },
    style: {
      // 定义 style 属性可以拿到 style 属性上设置的值
      type: String,
    },
    url: {
      type: String,
      default: "",
    },
    myStyle: {
      type: String,
      default: "",
    },
  },
  emits: ["created", "ready", "error"],
  data() {
    return {
      status: "init",
      customStyle: "",
      width: 0,
    };
  },
  computed: {
    combined() {
      return {
        licenseKey: this.licenseKey,
        appId: this.appId,
        authFunc: this.authFunc,
      };
    },
    authResolve: {
      get() {
        return this._r;
      },
      set(resolve) {
        this._r = resolve;
        if (resolve) {
          const authFunc = this.authFunc || this.$parent.authFunc;
          if (!authFunc) return resolve();
          Promise.resolve(authFunc()).then((res) => resolve(res));
        }
      },
    },
  },
  watch: {
    combined: {
      handler() {
        this.start();
      },
      immediate: true,
    },
    status() {
      this.getImageInfo();
    },
    url() {
      this.getImageInfo();
    },
  },
  methods: {
    async getImageInfo() {
      if (!this.url || this.status !== "created") return;
      wx.getImageInfo({
        src: this.url,
        success: (res) => {
          const input = {
            src: res.path,
            ...res,
          };
          this.customStyle = `width:100%;height:${
            (this.width / res.width) * res.height
          }px;`;
          this.sdk.setInput(input);
        },
      });
    },
    async auth() {
      return new Promise((resolve) => {
        this.authResolve = resolve;
      });
    },
    onError(e) {
      this.$emit("error", e.detail);
    },
    onInitdone(e) {
      this.$emit("initdone", e.detail);
    },
    onStop(e) {
      this.$emit("stop", e.detail);
    },
    async getCanvasNode(id) {
      return new Promise((resolve) => {
        this.createSelectorQuery()
          .select(`.${id}`)
          .node()
          .exec((res) => {
            const canvasNode = res[0].node;
            resolve(canvasNode);
          });
      });
    },
    async getNodeSize(id) {
      return new Promise((resolve) => {
        setTimeout(() => {
          this.createSelectorQuery()
            .select(`.${id}`)
            .boundingClientRect((res) => resolve(res))
            .exec();
        }, 300);
      });
    },
    async start() {
      const authFunc = this.authFunc || this.$parent.authFunc;
      if (this.sdk) return;
      if (!this.appId) {
        throw new Error("appId is required");
      }
      if (!this.licenseKey) {
        throw new Error("licenseKey is required");
      }
      if (!authFunc && +this.appId !== 102) {
        throw new Error("authFunc is required");
      }
      const { width, height } = await this.getNodeSize("image-box");
      this.width = width;
      const output = await this.getCanvasNode("canvas");
      const sdk = new ArSdk({
        input: {
          width,
          height,
        },
        loading: {
          enable: false,
        },
        output,
        auth: {
          appId: this.appId,
          authFunc: this.auth,
          licenseKey: this.licenseKey,
        },
        beautify: this.beautify,
        plugin3d: this.plugin3d,
      });
      const sdkEvent = {
        setBeautify: sdk.setBeautify.bind(sdk),
        setEffect: sdk.setEffect.bind(sdk),
        setFilter: sdk.setFilter.bind(sdk),
        getEffectList: sdk.getEffectList.bind(sdk),
        getEffect: sdk.getEffect.bind(sdk),
        getCommonFilter: sdk.getCommonFilter.bind(sdk),
        disable: sdk.disable.bind(sdk),
        enable: sdk.enable.bind(sdk),
        start: sdk.start.bind(sdk),
        stop: sdk.stop.bind(sdk),
        startRecord: sdk.startRecord.bind(sdk),
        stopRecord: sdk.stopRecord.bind(sdk),
        takePhoto: sdk.takePhoto.bind(sdk),
        destroy: sdk.destroy.bind(sdk),
        setInput: sdk.setInput.bind(sdk),
        download: (save = false) => {
          let base64 = output.toDataURL();
          const time = new Date().getTime();
          const imgPath =
            wx.env.USER_DATA_PATH + "/poster" + time + "share" + ".png";
          //如果图片字符串不含要清空的前缀,可以不执行下行代码.
          const imageData = base64.replace(/^data:image\/\w+;base64,/, "");
          const fs = wx.getFileSystemManager();
          fs.writeFileSync(imgPath, imageData, "base64");
          if (save) {
            wx.saveImageToPhotosAlbum({
              filePath: imgPath,
            });
          }
          return imgPath;
        },
      };
      this.sdk = sdkEvent;
      sdk.on("created", async (_) => {
        console.log("sdk created");
        this.status = "created";
        this.$emit("created", sdkEvent);
      });
      sdk.on("ready", async (_) => {
        console.log("sdk ready");
        this.$emit("ready", sdkEvent);
      });
      sdk.on("error", (error) => {
        console.log("sdk error", error);
        this.$emit("error", error);
      });
    },
    destroy() {
      if (this.sdk) {
        this.sdk.destroy();
        this.sdk = null;
      }
    },
  },
  destroyed() {
    this.destroy();
  },
  unmounted() {
    this.destroy();
  },
};
</script>

<style>
.image-box {
  position: relative;
  overflow: hidden;
  width: 100%;
}
.canvas {
  width: 100%;
  height: 100%;
}
</style>
