const { ArSdk } = requirePlugin("webarPlugin"); //引入插件
export default ArSdk;
