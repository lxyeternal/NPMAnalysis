<template>
  <view class="camera-box class" :style="style || myStyle">
    <camera
      class="camera"
      :device-position="devicePosition"
      :frame-size="frameSize"
      :flash="flash"
      :resolution="resolution"
      @initdone="onInitdone"
      @stop="onStop"
      @error="onError"
    >
      <slot></slot>
    </camera>
    <canvas
      class="canvas"
      canvas-id="main-canvas"
      id="main-canvas"
      type="webgl"
    ></canvas>
  </view>
</template>

<script>
const { ArSdk } = requirePlugin("webarPlugin"); //引入插件

export default {
  externalClasses: ["class"],
  props: {
    licenseKey: {
      type: String,
      default: "",
    },
    appId: {
      type: String,
      default: "",
    },
    authFunc: {
      type: Function,
    },
    plugin3d: {
      type: Function,
    },
    beautify: { type: Object },
    style: {
      // 定义 style 属性可以拿到 style 属性上设置的值
      type: String,
    },
    myStyle: {
      type: String,
      default: "",
    },
    devicePosition: {
      type: String,
      default: "front",
    },
    flash: {
      type: String,
      default: "off",
    },
    resolution: {
      type: String,
      default: "medium",
    },
    frameSize: {
      type: String,
      default: "large",
    },
  },
  emits: ["created", "ready", "error", "initdone", "stop"],
  data() {
    return {
      status: "init",
    };
  },
  computed: {
    combined() {
      return {
        licenseKey: this.licenseKey,
        appId: this.appId,
        authFunc: this.authFunc,
      };
    },
    authResolve: {
      get() {
        return this._r;
      },
      set(resolve) {
        this._r = resolve;
        if (resolve) {
          const authFunc = this.authFunc || this.$parent.authFunc;
          if (!authFunc) return resolve();
          Promise.resolve(authFunc()).then((res) => resolve(res));
        }
      },
    },
  },
  watch: {
    combined: {
      handler() {
        this.start();
      },
      immediate: true,
    },
  },
  methods: {
    async getImageInfo(url) {
      return new Promise((resolve, reject) => {
        wx.getImageInfo({
          src: url,
          success: (res) => {
            resolve(res.path);
          },
          fail: reject,
        });
      });
    },
    async auth() {
      return new Promise((resolve) => {
        this.authResolve = resolve;
      });
    },
    onError(e) {
      this.$emit("error", e.detail);
    },
    onInitdone(e) {
      this.$emit("initdone", e.detail);
    },
    onStop(e) {
      this.$emit("stop", e.detail);
    },
    async getCanvasNode(id) {
      return new Promise((resolve) => {
        this.createSelectorQuery()
          .select(`.${id}`)
          .node()
          .exec((res) => {
            const canvasNode = res[0].node;
            resolve(canvasNode);
          });
      });
    },
    async getNodeSize(id) {
      return new Promise((resolve) => {
        setTimeout(() => {
          this.createSelectorQuery()
            .select(`.${id}`)
            .boundingClientRect((res) => resolve(res))
            .exec();
        }, 300);
      });
    },
    async start() {
      const authFunc = this.authFunc || this.$parent.authFunc;
      if (this.sdk) return;
      if (!this.appId) {
        throw new Error("appId is required");
      }
      if (!this.licenseKey) {
        throw new Error("licenseKey is required");
      }
      if (!authFunc && +this.appId !== 102) {
        throw new Error("authFunc is required");
      }
      const { width, height } = await this.getNodeSize("camera-box");
      const realHeight = Math.round(720 * (height / width));
      const output = await this.getCanvasNode("canvas");
      const cameraContext = wx.createCameraContext();
      const sdk = new ArSdk({
        camera: {
          width: 720,
          height: realHeight,
          cameraContext,
        },
        loading: {
          enable: false,
        },
        output,
        auth: {
          appId: this.appId,
          authFunc: this.auth,
          licenseKey: this.licenseKey,
        },
        beautify: this.beautify,
        plugin3d: this.plugin3d,
      });
      const sdkEvent = {
        setBeautify: sdk.setBeautify.bind(sdk),
        setEffect: sdk.setEffect.bind(sdk),
        setFilter: sdk.setFilter.bind(sdk),
        getEffectList: sdk.getEffectList.bind(sdk),
        getEffect: sdk.getEffect.bind(sdk),
        getCommonFilter: sdk.getCommonFilter.bind(sdk),
        disable: sdk.disable.bind(sdk),
        enable: sdk.enable.bind(sdk),
        start: sdk.start.bind(sdk),
        stop: sdk.stop.bind(sdk),
        startRecord: sdk.startRecord.bind(sdk),
        stopRecord: sdk.stopRecord.bind(sdk),
        takePhoto: sdk.takePhoto.bind(sdk),
        destroy: sdk.destroy.bind(sdk),
        setForeground: async (config, callback) => {
          if (config) {
            if (Array.isArray(config)) {
              config = await Promise.all(
                config.map((item) =>
                  this.getImageInfo(item.src).then((res) => {
                    item.id = item.src;
                    item.src = res;
                    return item;
                  })
                )
              );
            } else {
              config.id = config.src;
              config.src = await this.getImageInfo(config.src);
            }
          }
          return sdk.setForeground(config, callback);
        },
        cameraContext,
      };
      this.sdk = sdkEvent;
      sdk.on("created", async (_) => {
        console.log("sdk created");
        this.$emit("created", sdkEvent);
      });
      sdk.on("ready", async (_) => {
        console.log("sdk ready");
        this.$emit("ready", sdkEvent);
      });
      sdk.on("error", (error) => {
        console.log("sdk error", error);
        this.$emit("error", error);
      });
    },
    destroy() {
      if (this.sdk) {
        this.sdk.destroy();
        this.sdk = null;
      }
    },
  },
  destroyed() {
    this.destroy();
  },
  unmounted() {
    this.destroy();
  },
};
</script>

<style>
.camera-box {
  position: relative;
  overflow: hidden;
}
.camera {
  width: 100%;
  height: 100%;
  position: absolute;
  left: 0;
  top: -9999px;
}
.canvas {
  width: 100%;
  height: 100%;
}
</style>
