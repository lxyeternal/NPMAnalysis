<template>
  <view :class="customClass" :style="style || myStyle">
    <live-pusher
      class="pusher"
      :style="customStyle"
      :url="url"
      :mode="mode"
      :autopush="autopush"
      :enableVideoCustomRender="enableVideoCustomRender"
      :muted="muted"
      :enable-camera="enableCamera"
      :auto-focus="autoFocus"
      :orientation="orientation"
      :beauty="beauty"
      :whiteness="whiteness"
      :aspect="aspect"
      :min-bitrate="minBitrate"
      :max-bitrate="maxBitrate"
      :audio-quality="audioQuality"
      :waiting-image="waitingImage"
      :waiting-image-hash="waitingImageHash"
      :zoom="zoom"
      :device-position="devicePosition"
      :background-mute="backgroundMute"
      :mirror="mirror"
      :remote-mirror="remoteMirror"
      :local-mirror="localMirror"
      :audio-reverb-type="audioReverbType"
      :enable-mic="enableMic"
      :enable-agc="enableAgc"
      :enable-ans="enableAns"
      :audio-volume-type="audioReverbType"
      :video-width="videoWidth"
      :video-height="videoHeight"
      :beauty-style="beautyStyle"
      :filter="filter"
      :picture-in-picture-mode="pictureInPictureMode"
      :voice-changer-type="voiceChangerType"
      :custom-effect="customEffect"
      :skin-whiteness="skinWhiteness"
      :skin-smoothness="skinSmoothness"
      :face-thinness="faceThinness"
      :eye-bigness="eyeBigness"
      :fps="fps"
      :debug="debug"
      @statechange="onPushEvent"
      @netstatus="onNetStatus"
      @error="onError"
      @bgmstart="onBgmStart"
      @bgmprogress="onBgmProgress"
      @bgmcomplete="onBgmComplete"
      @audiovolumenotify="onAudiovolumenotify"
      @enterpictureinpicture="onEnterpictureinpicture"
      @leavepictureinpicture="onLeavepictureinpicture"
    >
      <slot></slot>
    </live-pusher>
    <canvas
      v-if="enableVideoCustomRender"
      :style="canvasStyle"
      class="canvas"
      type="webgl"
    ></canvas>
  </view>
</template>

<script>
const { ArSdk } = requirePlugin("webarPlugin"); //引入插件

export default {
  externalClasses: ["class"],
  props: {
    licenseKey: {
      type: String,
      default: "",
    },
    appId: {
      type: String,
      default: "",
    },
    authFunc: {
      type: Function,
    },
    plugin3d: {
      type: Function,
    },
    beautify: { type: Object },
    background: {
      type: String,
      default: "",
    },
    style: {
      // 定义 style 属性可以拿到 style 属性上设置的值
      type: String,
    },
    myStyle: {
      type: String,
      default: "",
    },
    url: {
      type: String,
      default: "",
    },
    mode: {
      type: String,
      default: "SD",
    },
    autopush: {
      type: Boolean,
      default: false,
    },
    enableVideoCustomRender: {
      type: Boolean,
      default: false,
    },
    muted: {
      type: Boolean,
      default: false,
    },
    enableCamera: {
      type: Boolean,
      default: true,
    },
    autoFocus: {
      type: Boolean,
      default: true,
    },
    orientation: {
      type: String,
      default: "vertical",
    },
    beauty: {
      type: Number,
      default: 0,
    },
    whiteness: {
      type: Number,
      default: 0,
    },
    aspect: {
      type: String,
      default: "9:16",
    },
    minBitrate: {
      type: Number,
      default: 200,
    },
    maxBitrate: {
      type: Number,
      default: 1000,
    },
    audioQuality: {
      type: String,
      default: "high",
    },
    waitingImage: {
      type: String,
      default: "",
    },
    waitingImageHash: {
      type: String,
      default: "",
    },
    zoom: {
      type: Boolean,
      default: false,
    },
    devicePosition: {
      type: String,
      default: "front",
    },
    backgroundMute: {
      type: Boolean,
      default: false,
    },
    mirror: {
      type: Boolean,
      default: false,
    },
    remoteMirror: {
      type: Boolean,
      default: false,
    },
    localMirror: {
      type: String,
      default: "auto",
    },
    audioReverbType: {
      type: Number,
      default: 0,
    },
    videoWidth: {
      type: Number,
      default: 360,
    },
    videoHeight: {
      type: Number,
      default: 640,
    },
    beautyStyle: {
      type: String,
      default: "smooth",
    },
    filter: {
      type: String,
      default: "standard",
    },
    pictureInPictureMode: [],
    voiceChangerType: {
      type: Number,
      default: 0,
    },
    customEffect: {
      type: Boolean,
      default: false,
    },
    skinWhiteness: {
      type: Number,
      default: 0,
    },
    skinSmoothness: {
      type: Number,
      default: 0,
    },
    faceThinness: {
      type: Number,
      default: 0,
    },
    eyeBigness: {
      type: Number,
      default: 0,
    },
    fps: {
      type: Number,
      default: 15,
    },
    enableMic: {
      type: Boolean,
      default: true,
    },
    enableAgc: {
      type: Boolean,
      default: false,
    },
    enableAns: {
      type: Boolean,
      default: false,
    },
    enableEarMonitor: {
      type: Boolean,
      default: false,
    },
  },
  emits: [
    "created",
    "ready",
    "error",
    "statechange",
    "netstatus",
    "error",
    "bgmstart",
    "bgmprogress",
    "bgmcomplete",
    "audiovolumenotify",
    "enterpictureinpicture",
    "leavepictureinpicture",
  ],
  data() {
    return {
      status: "init",
      customStyle: "",
      canvasStyle: `transform: translate(-50%, -50%) scale(1);`,
    };
  },
  computed: {
    customClass() {
      return `pusher-box class ${
        this.enableVideoCustomRender ? "custom" : "native"
      }`;
    },
    combined() {
      return {
        licenseKey: this.licenseKey,
        appId: this.appId,
        authFunc: this.authFunc,
      };
    },
    backStatus() {
      return this.background + this.status;
    },

    authResolve: {
      get() {
        return this._r;
      },
      set(resolve) {
        this._r = resolve;
        if (resolve) {
          const authFunc = this.authFunc || this.$parent.authFunc;
          if (!authFunc) return resolve();
          Promise.resolve(authFunc()).then((res) => resolve(res));
        }
      },
    },
  },
  watch: {
    combined: {
      handler() {
        this.start();
      },
      immediate: true,
    },
    backStatus: {
      handler() {
        this.status === "ready" && this.setBackground(this.background);
      },
      immediate: true,
    },
  },
  methods: {
    async auth() {
      return new Promise((resolve) => {
        this.authResolve = resolve;
      });
    },
    onPushEvent(e) {
      this.$emit("statechange", e);
    },
    onNetStatus(e) {
      this.$emit("netstatus", e);
    },
    onError(e) {
      this.$emit("error", e);
    },
    onBgmStart(e) {
      this.$emit("bgmstart", e);
    },
    onBgmProgress(e) {
      this.$emit("bgmprogress", e);
    },
    onBgmComplete(e) {
      this.$emit("bgmcomplete", e);
    },
    onAudiovolumenotify(e) {
      this.$emit("audiovolumenotify", e);
    },
    onEnterpictureinpicture(e) {
      this.$emit("enterpictureinpicture", e);
    },
    onLeavepictureinpicture(e) {
      this.$emit("leavepictureinpicture", e);
    },
    async download(url) {
      if (url instanceof ArrayBuffer) return url;
      return new Promise((resolve, reject) => {
        wx.request({
          url: url,
          responseType: "arrayBuffer",
          success: (res) => {
            const { data } = res;
            resolve(data);
          },
          fail: (res) => {
            reject(res);
          },
        });
      });
    },
    async getCanvasNode(id) {
      return new Promise((resolve) => {
        this.createSelectorQuery()
          .select(`.${id}`)
          .node()
          .exec((res) => {
            const canvasNode = res[0].node;
            resolve(canvasNode);
          });
      });
    },
    async setBackground(url) {
      if (!this.customEffect) return;
      if (url) {
        const buffer = await this.download(url);
        this.sdk.setBackground({ type: "image", src: buffer });
      } else {
        this.sdk.setBackground({ type: "image", src: "" });
      }
    },
    async start() {
      const authFunc = this.authFunc || this.$parent.authFunc;
      if (this.sdk || (!this.enableVideoCustomRender && !this.customEffect))
        return;
      if (!this.appId) {
        throw new Error("appId is required");
      }
      if (!this.licenseKey) {
        throw new Error("licenseKey is required");
      }
      if (!authFunc && +this.appId !== 102) {
        throw new Error("authFunc is required");
      }
      let output;
      const pusherContext = wx.createLivePusherContext();
      let live = {
        mode: this.enableVideoCustomRender ? "custom" : "native",
        pusherContext,
      };
      if (this.enableVideoCustomRender) {
        output = await this.getCanvasNode("canvas");
        const size = ArSdk.getRealSize();
        this.customStyle = `width:${size.width};height:${size.height};`;
        live.pusherSize = size;
      }
      const sdk = new ArSdk({
        live,
        loading: {
          enable: false,
        },
        output,
        auth: {
          appId: this.appId,
          authFunc: this.auth,
          licenseKey: this.licenseKey,
        },
        beautify: this.beautify,
        plugin3d: this.plugin3d,
      });
      let sdkEvent = this.enableVideoCustomRender
        ? {
            setBeautify: sdk.setBeautify.bind(sdk),
            setEffect: sdk.setEffect.bind(sdk),
            setFilter: sdk.setFilter.bind(sdk),
            getEffectList: sdk.getEffectList.bind(sdk),
            getEffect: sdk.getEffect.bind(sdk),
            getCommonFilter: sdk.getCommonFilter.bind(sdk),
            disable: sdk.disable.bind(sdk),
            enable: sdk.enable.bind(sdk),
            start: sdk.start.bind(sdk),
            stop: sdk.stop.bind(sdk),
            startRecord: sdk.startRecord.bind(sdk),
            stopRecord: sdk.stopRecord.bind(sdk),
            takePhoto: sdk.takePhoto.bind(sdk),
            destroy: sdk.destroy.bind(sdk),
            pusherContext,
          }
        : {
            setBackground: sdk.setBackground.bind(sdk),
            disable: sdk.disable.bind(sdk),
            enable: sdk.enable.bind(sdk),
            destroy: sdk.destroy.bind(sdk),
            pusherContext,
          };
      this.sdk = sdkEvent;
      sdk.on("created", async (_) => {
        console.log("sdk created");
        this.status = "created";
        this.$emit("created", sdkEvent);
      });
      sdk.on("ready", async (_) => {
        console.log("sdk ready");
        this.status = "ready";
        this.$emit("ready", sdkEvent);
      });
      sdk.on("error", (error) => {
        console.log("sdk error", error);
        this.$emit("error", error);
      });
    },
    destroy() {
      if (this.observer) {
        this.observer.disconnect();
      }
      if (this.sdk) {
        this.sdk.destroy();
        this.sdk = null;
      }
    },
  },
  mounted() {
    if (!this.enableVideoCustomRender) return;
    this.observer = uni.createIntersectionObserver(this);
    this.observer.relativeToViewport();
    this.observer.observe(".pusher-box", ({ boundingClientRect }) => {
      const { width, height } = boundingClientRect;
      console.log("obserbeSize:", width, height);
      let scale = width / height / (9 / 16);
      scale = scale >= 1 ? scale : 1 / scale;
      this.canvasStyle = `width: ${width}px;height: ${
        (width / 9) * 16
      }px;transform: translate(-50%, -50%) scale(${scale});`;
    });
  },
  destroyed() {
    this.destroy();
  },
  unmounted() {
    this.destroy();
  },
};
</script>

<style>
.pusher-box {
  position: relative;
  overflow: hidden;
}
.pusher {
  width: 100%;
  height: 100%;
  position: absolute;
  left: 0;
  top: 0;
  z-index: 1;
}
.custom .pusher {
  visibility: hidden;
}
.canvas {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 2;
}
</style>
