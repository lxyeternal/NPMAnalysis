使用方法

`import { getNodeInfo } from "uninodeinfo";`

提供三个api

**getNodeInfo**

**getComponentNodeInfo**

**generateTimeSlots**

案例

```javascript
getComponentNodeInfo(this,'.cart-detail').then(res=>{
      // xxx
 })
```
```javascript
getNodeInfo（'.container'）.then(res=>{
 //xx
 })
```

```javascript
/**
 * 生成时段
 * @param {step} number 步长 例如：0.5就是间隔30分钟，1就是间隔一个小时
 * @param {start} string 开始时间
 * @param {end} string 结束时间
 */
generateTimeSlots(0.5,'08:00','20:00')

// 返回值是对象，对象包含两个字段times，timeFrame,其中times是未处理后的原数据，timeFrame是已经处理好的数据，例如:08:00-08:30

```