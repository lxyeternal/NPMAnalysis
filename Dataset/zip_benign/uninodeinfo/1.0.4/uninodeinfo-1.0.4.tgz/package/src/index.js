
/**
 * 获取节点信息
 * @param {String} el
 */
export function getNodeInfo(el){
	return new Promise((resolve,reject)=>{
		let node = uni.createSelectorQuery().select(el)
		node.boundingClientRect((data)=>{
			resolve(data)
		}).exec()
	})
}
/**
 * 在组件内获取节点信息
 * @param {String} el
 */
export function  getComponentNodeInfo(context,el){
	return new Promise((resolve,reject)=>{
		let node = uni.createSelectorQuery().in(context).select(el)
		node.boundingClientRect((data)=>{
			resolve(data)
		}).exec()
	})
}

/**
 * 生成时段
 * @param {step} number 步长
 * @param {start} string 开始时间
 * @param {end} string 结束时间
 */

export function generateTimeSlots(step,start, end) {
	let timeSlots = {
			times: [],
			timeFrame: []
	};
	let startTime = new Date(`2023-03-18T${start}:00.000Z`);
	let endTime = new Date(`2023-03-18T${end}:00.000Z`);
	while (startTime < endTime) {
		let startTimeString = startTime.toISOString().slice(11, 16);
		startTime.setMinutes(startTime.getMinutes() + step * 60);
		let endTimeString = startTime.toISOString().slice(11, 16);
		timeSlots.times.push(startTimeString);
		timeSlots.times.push(endTimeString);
		timeSlots.timeFrame.push(`${startTimeString}-${endTimeString}`);
	}
	return timeSlots;
}