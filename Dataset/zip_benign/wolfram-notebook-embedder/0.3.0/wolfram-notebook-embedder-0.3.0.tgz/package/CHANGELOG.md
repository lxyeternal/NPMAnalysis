## 0.3

* Embedding of external notebooks at a given URL (`{url: ...}`) or with a given `Notebook` expression (`{expr: ...}`)
* New option `showBorder` to control whether to show a border around the embedded notebook
* Officially dropped support for IE11
* Add a default export, but encourage named imports

## 0.2.2

* Pass through extra data from the initial server call to the cloud JS code, for better forward-compatibility 

## 0.2.1

* Fix issues with `useShadowDOM` when there are existing notebook-related style definitions on the page  

## 0.2.0

* New option `useShadowDOM` for better encapsulation of styling (still experimental and off by default)

## 0.1.5

* First official release
* Change the default for `allowInteract` from `false` to `true`
* Improve documentation
* Add website, built with [Docusaurus](https://docusaurus.io)

## 0.1.4

* First proper release

## 0.1.0

* Initial release
