# wolfram-notebook-embedder

A library to embed [Wolfram Cloud](https://www.wolframcloud.com/) notebooks on websites. It does *not* use an `<iframe>`, but renders a notebook directly into a given DOM node for a more seamless experience.

## Installation

If you are using a package manager such as [npm](https://www.npmjs.com/get-npm) or [Yarn](https://yarnpkg.com/en/), you can install this package from the npm repository:

    npm install wolfram-notebook-embedder
    
and then import it in your JavaScript code like so:

    import * as WolframNotebookEmbedder from 'wolfram-notebook-embedder';    
    
You can also import this library as a `<script>` tag from a CDN:

    <script crossorigin src="https://unpkg.com/wolfram-notebook-embedder@0.3/dist/wolfram-notebook-embedder.min.js"></script>
    
and then use the global variable `WolframNotebookEmbedder`.

## Usage & Documentation

* [**Getting Started**](./docs/GettingStarted.md)
* [Library Interface](./docs/LibraryInterface.md)
* [Notebook API](./docs/NotebookAPI.md)
* [Server-Side Rendering](./docs/ServerSideRendering.md)
* [Notebook Loading Phases](./docs/NotebookLoadingPhases.md)
* [Troubleshooting](./docs/Troubleshooting.md)

## Examples

* [Basic Example](./examples/basic.html)
* [Manipulate Example](./examples/manipulate.html)
* [Dimensions Examples](./examples/dimensions.html)
* [Server-Side Rendering](./examples/ssr.html)

## Browser Support

We support all modern browsers (the last two major versions of Chrome, Firefox, Edge, Safari). Internet Explorer is *not* supported anymore.

## Contributing

Everyone is welcome to contribute. Please read the [Contributing agreement](CONTRIBUTING.md) and the [Development guide](./docs/Development.md) for more information, including how to run the tests.

## Versioning

We use [semantic versioning](https://semver.org/) for this library and its API.

See the [changelog](CHANGELOG.md) for details about the changes in each release.

Each version of this library is compatible with a certain range of versions of the Wolfram Cloud. Currently, the requirement is Wolfram Cloud 1.50 or higher. We try hard not to make any backward-incompatible changes on the Wolfram Cloud side, which would require an update of this library to keep embeddings working.

| Library version | Minimum Wolfram Cloud version |
|-----------------|-------------------------------|
|           0.1.x |                          1.50 |
|           0.2.x |                          1.55 |
|           0.3.x |                          1.59 |

## License

This project is licensed under the [MIT license](./LICENSE).
