import './chart.css';
export interface IProps {
    className?: string;
    data: any[];
    width?: string;
    height?: string;
    padding?: number[];
    children: JSX.Element[];
}
declare const Chart: (props: IProps) => JSX.Element;
export default Chart;
