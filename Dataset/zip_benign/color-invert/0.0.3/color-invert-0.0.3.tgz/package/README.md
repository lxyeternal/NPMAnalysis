# color-invert

[![npm version](https://badge.fury.io/js/color-invert.svg)](https://badge.fury.io/js/color-invert)

# Installation

`yarn add color-invert`

# Usage

```javascript
import { invert } from 'color-invert';
// or import invert from 'color-invert/lib/invert';

invert('#ff0000'); // #00ffff, works without # too

// available methods

// fade(hex: string, opacity: number = 0.4): string
fade('#ff0000'); // 'rgba(255, 0, 0, 0.4)'
fade('#ff0000', 0.75); // 'rgba(255, 0, 0, 0.75)'

// hexToComponents(hex: string): string[]
hexToComponents('#ff0000'); // ['ff', '00', '00']

// hexToRgb(hex: string, asStr = false): { r: number, g: number, b: number } | string
hexToRgb('#ff0000'); // { r: 255, g: 0, b: 0 }
hexToRgb('#ff0000', true); // 'rgb(255, 0, 0)'

// intToHex(int: number): string
intToHex(255); // 'ff'

// invert(hex: string, asObj = false): string | { r: number, g: number, b: number }
invert('#ff0000'); // #00ffff
invert('ff0000'); // #00ffff
invert('#ff0000', true); // { r: 0, g: 255, b: 255 }

// rgbToHex(r: number, g: number, b: number): string
rgbToHex(255, 0, 0); // '#ff0000'
```
