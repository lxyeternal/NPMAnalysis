import shapes from './shapes/shapes'
import { Displayable, Group, Line, Rect as ZrRect } from 'zrender'
import {
  rotate,
  scale as scaleM,
  applyTransform,
  mul,
  flip,
  identity,
} from '../utils/matrix'
import { VectorArray } from 'zrender/lib/core/vector'
import { Engine } from '../engine'
import * as storage from '../storage/storage'
import config from '../config'
import { ShapeData } from './shapes/commonConfig'
import { deepAssign, gridding } from '../utils/util'

export enum FlipDirection {
  HORIZONTAL = 'horizontal',
  VERTICAL = 'vertical',
}

export class GroupPtr extends Group {
  _model: Model
}
class Model {
  _selectRectStyle: object = config.modelSelectStyle
  group: GroupPtr
  name: string
  version: string
  type: string
  modelId: string
  private selectRect: Displayable
  selected: boolean = false
  shapeList: ShapeData[]
  shapeInstaceList: Displayable[] = []
  floatingElements: Displayable[] = []
  horzontalFlipped: boolean = false
  verticalFlipped: boolean = false

  constructor(modelData: ModelData) {
    this.group = new GroupPtr()
    this.group._model = this
    this.name = modelData.name
    this.version = modelData.version
    this.type = modelData.type
    this.modelId =
      modelData.id ??
      `model-${modelData.type}${Math.random().toString().slice(2, 8)}`
    if (modelData.selectRectStyle) {
      this.selectRectStyle = modelData.selectRectStyle
    }
    this.transform = identity
    this.shapeList = modelData.shapeList
    modelData.shapeList.forEach((shape: ShapeData) => {
      const type = shape.type
      const shapeIns = shapes[type].load(shape)
      this.group.add(shapeIns)
      if (type.toLowerCase() === 'text') {
        this.floatingElements.push(shapeIns)
      } else {
        this.shapeInstaceList.push(shapeIns)
      }
    })
  }

  get flipped(): boolean {
    return this.horzontalFlipped !== this.verticalFlipped
  }

  set selectRectStyle(style: object) {
    this._selectRectStyle = {
      ...this._selectRectStyle,
      ...style,
    }
  }
  get selectRectStyle(): object {
    return this._selectRectStyle
  }

  get transform() {
    return this.group.getLocalTransform()
  }

  protected set transform(transform) {
    this.group.setLocalTransform(transform)
    this.group.dirty()
  }

  private br: ZrRect
  private axis1: Line
  private axis2: Line

  get position(): VectorArray {
    const rect = this.group.getBoundingRect([...this.shapeInstaceList])
    if (config.debugMode.showModelOrigin) {
      if (!this.br) {
        this.br = new ZrRect({
          shape: rect,
          style: { lineWidth: 0, fill: '#00ff0033' },
          z: -1,
        })
        this.group.add(this.br)
      } else {
        this.br.attr({ shape: rect })
      }
      if (!this.axis1) {
        this.axis1 = new Line({
          shape: {
            x1: rect.x,
            y1: rect.y + rect.height / 2,
            x2: rect.x + rect.width,
            y2: rect.y + rect.height / 2,
          },
          style: { stroke: '#f00', strokeNoScale: true },
        })
        this.group.add(this.axis1)
      } else {
        this.axis1.attr({
          shape: {
            x1: rect.x,
            y1: rect.y + rect.height / 2,
            x2: rect.x + rect.width,
            y2: rect.y + rect.height / 2,
          },
        })
      }
      if (!this.axis2) {
        this.axis2 = new Line({
          shape: {
            x1: rect.x + rect.width / 2,
            y1: rect.y,
            x2: rect.x + rect.width / 2,
            y2: rect.y + rect.height,
          },
          style: { stroke: '#f00', strokeNoScale: true },
        })
        this.group.add(this.axis2)
      } else {
        this.axis2.attr({
          shape: {
            x1: rect.x + rect.width / 2,
            y1: rect.y,
            x2: rect.x + rect.width / 2,
            y2: rect.y + rect.height,
          },
        })
      }
    }
    const origin = applyTransform(this.transform, [
      rect.x + rect.width / 2,
      rect.y + rect.height / 2,
    ])
    return origin
  }

  protected set position(position: VectorArray) {
    const [x, y] = position
    const [lx, ly] = this.position
    this.transform = mul([1, 0, 0, 1, x - lx, y - ly], this.transform)
  }

  flip(
    direction: FlipDirection = FlipDirection.HORIZONTAL,
    state: boolean = false
  ): void {
    if (direction === FlipDirection.HORIZONTAL) {
      if (state === this.horzontalFlipped) return
      this.horzontalFlipped = state
    } else {
      if (state === this.verticalFlipped) return
      this.verticalFlipped = state
    }
    const { x, y, width, height } = this.group.getBoundingRect(
      this.shapeInstaceList
    )
    const { transform, rotation } = this
    const origin = applyTransform(transform, [x + width / 2, y + height / 2])
    this.transform = mul(
      rotate(origin, rotation),
      flip(origin, direction),
      rotate(origin, -rotation),
      transform
    )
    this.fixFloatingElementTransform()
  }

  get rotation(): number {
    const { rotation } = this.group
    let res: number
    if (this.verticalFlipped) {
      res = -(rotation / Math.PI) * 180 + 180
      if (res > 180) res -= 360
    } else {
      res = -(rotation / Math.PI) * 180
    }
    return Math.round(res)
  }
  protected set rotation(rotation: number) {
    const rect = this.group.getBoundingRect(this.shapeInstaceList)
    const transform = this.transform
    const origin = applyTransform(transform, [
      rect.x + rect.width / 2,
      rect.y + rect.height / 2,
    ])
    const lastRotation = this.rotation
    this.transform = mul(
      rotate(origin, rotation),
      rotate(origin, -lastRotation),
      transform
    )
    this.fixFloatingElementTransform()
  }

  get scale(): number {
    return this.group.scaleX || 1
  }

  protected set scale(scale: number) {
    const rect = this.group.getBoundingRect(this.shapeInstaceList)
    const transform = this.transform
    const lastScale = this.scale
    const origin = applyTransform(transform, [
      rect.x + rect.width / 2,
      rect.y + rect.height / 2,
    ])
    this.transform = mul(scaleM(origin, scale / lastScale), this.transform)
  }

  //TODO
  get level(): number {
    return NaN
  }
  protected set level(level: number) {}

  addTo(engine: Engine, position = [0, 0]): Model {
    this.position = config.dragGrid ? position : gridding(position)
    engine._paintArea.add(this.group)
    storage.addModel(this)
    return this
  }

  removeFrom(engine: Engine): Model {
    engine._paintArea.remove(this.group)
    storage.removeModel(this)
    return this
  }

  /**
   * 此处属性应用顺序为传入对象的key顺序
   */
  attr(attrObj: ModelAttr): Model {
    Object.keys(attrObj).forEach(key => {
      if (attrObj[key] !== undefined && attrObj[key] !== null) {
        this[key] = attrObj[key]
      }
    })
    return this
  }

  /**
   * 更新模型的子元素属性
   * @param childName 子模型名称
   * @param attr 属性对象
   */
  setChildAttr(childName: string, attr: ShapeData) {
    const positionCopy = [...this.position]
    const target = this.shapeList.find(e => e.name === childName)
    deepAssign(target, attr)
    const oldIns = this.group.childOfName(childName) as Displayable
    const ins = shapes[target.type].load(target)
    const list =
      this[
        ins.type.toLowerCase() === 'text'
          ? 'floatingElements'
          : 'shapeInstaceList'
      ]
    const idx = list.indexOf(oldIns)
    list[idx] = ins
    this.group.remove(oldIns)
    this.group.add(ins)
    if (this.selected) {
      this.unselect()
      this.select()
    }
    //TODO
    this.position = positionCopy
    let a = this.position
    this.rotation = this.rotation
  }

  private fixFloatingElementTransform(): void {
    const { rotation, flipped, horzontalFlipped, verticalFlipped } = this
    this.floatingElements.forEach(child => {
      const { x, y, width, height } = child.getBoundingRect()
      const origin = [x + width / 2, y + height / 2]
      const originalRotation = this.shapeList.find(e => e.name === child.name)
        .basic.rotation
      const targetRotation = -originalRotation + rotation
      const rotMat = rotate(origin, flipped ? targetRotation : -targetRotation)
      const flipMat = mul(
        horzontalFlipped ? flip(origin, FlipDirection.HORIZONTAL) : identity,
        verticalFlipped ? flip(origin, FlipDirection.VERTICAL) : identity
      )
      child.setLocalTransform(mul(rotMat, flipMat))
    })
  }

  select(): Model {
    if (!this.selected) {
      this.selectRect = new ZrRect({
        shape: {
          ...this.group.getBoundingRect(),
        },
        style: { ...this.selectRectStyle },
        cursor: 'default',
      })
      this.group.add(this.selectRect)
      storage.addSelect(this)
      this.selected = true
    }
    return this
  }

  unselect(): Model {
    if (this.selected) {
      this.group.remove(this.selectRect)
      storage.removeSelect(this)
      this.selectRect = null
      this.selected = false
    }
    return this
  }
  highlight() {
    this.select()
  }
  unhighlight() {
    this.unselect()
  }
}

export { Model }

export declare interface ModelAttr {
  position?: VectorArray
  rotation?: number
  scale?: number
  level?: number
}
export declare interface ModelData {
  name: string
  shapeList: ShapeData[]
  selectRectStyle?: object
  id?: string
  version: string
  type: string
}
