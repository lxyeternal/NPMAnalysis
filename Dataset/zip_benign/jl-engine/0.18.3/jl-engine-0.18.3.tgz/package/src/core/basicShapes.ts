const BasicShapes = [
    {
        name: '直线',
        version: '0.1',
        shapeList: [
            {
                type: 'Line',
                name: '直线',
                basic: {
                    points: [
                        [0,0],
                        [100, 0]
                    ]
                },
                style:{
                    fill: '#ffffffff',
                    stroke: '#ffffffff',
                    opacity: 1,
                    lineWidth: 2
                },
                common: {
                    z: 0,
                    hidden: false
                }
            }
        ],
        stateAttrList: []
    },
    {
        name: '折线',
        version: '0.1',
        shapeList: [
            {
                type: 'Polyline',
                name: '折线',
                basic: {
                    points: [
                        [0,0],
                        [50,50],
                        [100,0]
                    ],
                    rotation: 0
                },
                style: {
                    fill: '#ffffff00',
                    stroke: '#ffffffff',
                    opacity: 1,
                    lineWidth: 1
                },
                common: {
                    z: 0,
                    hidden: false
                }
            }
        ],
        stateAttrList: []
    },
    {
        name: '椭圆',
        version: '0.1',
        shapeList: [
            {
                type: 'Ellipse',
                name: '椭圆',
                basic: {
                    position: [120, 50],
                    rx: 120,
                    ry: 50,
                    rotation: 0
                },
                style: {
                    fill: '#ffffffff',
                    stroke: '#ffffffff',
                    opacity: 1,
                    lineWidth: 1
                },
                common: {
                    z: 0,
                    hidden: false
                }
            }
        ]
    },
    {
        name: '矩形',
        version: '0.1',
        shapeList: [
            {
                type: 'Rect',
                name: '矩形',
                basic: {
                    position: [0, 0],
                    width: 100,
                    height: 50,
                    rotation: 0
                },
                style: {
                    fill: '#ffffffff',
                    stoke: '#ffffffff',
                    opacity: 1,
                    lineWidth: 1
                },
                common: {
                    z: 0,
                    hidden: false
                }
            }
        ]
    },
    {
        name: '曲线',
        version: '0.1',
        shapeList: [
            {
                type: 'Curve',
                name: '曲线',
                basic: {
                    p1: [0, 100],
                    p2: [100, 100],
                    cp1: [0, 0],
                    cp2: [100, 0],
                    percent: 1
                },
                style: {
                    stroke: '#ffffffff',
                    opacity: 1,
                    lineWidth: 1
                },
                common: {
                    z: 0,
                    hidden: false
                }
            }
        ]
    },
    {
        name: '文字',
        version: '0.1',
        shapeList: [
            {
                type: 'Text',
                name: '文字',
                basic: {
                    position: [0,0],
                    text: '内容',
                    fontSize: 20,
                    rotation: 0
                },
                style: {
                    fill: '#ffffffff',
                    stroke: null,
                    opacity: 1,
                    lineWidth: 1
                },
                common: {
                    z: 0,
                    hidden: false
                }
            }
        ]
    }
];

export { BasicShapes };
