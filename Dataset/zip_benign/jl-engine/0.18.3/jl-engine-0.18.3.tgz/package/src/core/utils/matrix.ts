import {
  applyTransform as ZrApplyTransform,
  VectorArray,
} from 'zrender/lib/core/vector'
import { invert as ZrInvert, MatrixArray } from 'zrender/lib/core/matrix'
import { FlipDirection } from '../model/model'

export function mul(a: MatrixArray, b?: MatrixArray, ...rest: MatrixArray[]) {
  if (!b) return a
  let r = [
    a[0] * b[0] + a[2] * b[1],
    a[1] * b[0] + a[3] * b[1],
    a[0] * b[2] + a[2] * b[3],
    a[1] * b[2] + a[3] * b[3],
    a[0] * b[4] + a[2] * b[5] + a[4],
    a[1] * b[4] + a[3] * b[5] + a[5],
  ]
  return rest.length ? mul(r, ...rest) : r
}

export function invert(m: MatrixArray): MatrixArray {
  return ZrInvert([], m)
}

export function rotate([x, y]: VectorArray, angle: number): MatrixArray {
  const rad = (angle * Math.PI) / 180
  const cos = Math.cos(rad)
  const sin = Math.sin(rad)
  return mul([cos, sin, -sin, cos, x, y], [1, 0, 0, 1, -x, -y])
}

export function scale([x, y]: VectorArray, ratio: number): MatrixArray {
  return mul([ratio, 0, 0, ratio, x, y], [1, 0, 0, 1, -x, -y])
}

export function flip(
  [x, y]: VectorArray,
  direction: FlipDirection
): MatrixArray {
  const isHorizontal = direction === FlipDirection.HORIZONTAL
  const [dx, dy] = isHorizontal ? [0, y] : [x, 0]
  return mul(
    [isHorizontal ? 1 : -1, 0, 0, isHorizontal ? -1 : 1, dx, dy],
    [1, 0, 0, 1, -dx, -dy]
  )
}

export function applyTransform(
  matrix: MatrixArray,
  vector: VectorArray
): VectorArray {
  return ZrApplyTransform([], vector, matrix)
}

export const identity = [1, 0, 0, 1, 0, 0]
