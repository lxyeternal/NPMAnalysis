export default {
  cursor: 'default',
}
export interface ShapeData {
  type?: any
  basic?: any
  common?: any
  style?: any
  name?: string
}
