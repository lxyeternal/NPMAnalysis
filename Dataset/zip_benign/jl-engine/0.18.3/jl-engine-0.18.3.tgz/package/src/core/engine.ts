import * as zrender from 'zrender'
import { Group, Line, Rect, ZRenderType } from 'zrender'
import 'zrender/lib/canvas/canvas'
import { VectorArray } from 'zrender/lib/core/vector'
import { mixin } from 'zrender/lib/core/util'
import { Model, ModelData } from './model/model'
import { Eventful } from './events/eventful'
import Config from './config'
import storage, { Storage } from './storage/storage'
import { TransformHandler } from './transform/transformHandler'

interface Engine extends Eventful {}

class Engine {
  _zr: ZRenderType
  _paintArea: Group
  globalModelScale: number
  storage: Storage
  transformHandler: TransformHandler
  static modelSelectStyle: object
  static imageBaseUrl: string
  private resizeObserver: ResizeObserver

  constructor(dom: HTMLElement | null) {
    if (!dom) throw new Error('Engine: dom is null')
    this._zr = zrender.init(dom)
    this._paintArea = new Group()
    this._zr.add(this._paintArea)

    const xAxis = new Line({
      shape: {
        x1: -10000,
        y1: 0,
        x2: 10000,
        y2: 0,
      },
      style: {
        stroke: '#111',
        strokeNoScale: true,
      },
      cursor: 'default',
      silent: true,
    })

    const yAxis = new Line({
      shape: {
        x1: 0,
        y1: -10000,
        x2: 0,
        y2: 10000,
      },
      style: {
        stroke: '#111',
        strokeNoScale: true,
      },
      cursor: 'default',
      silent: true,
    })

    this._paintArea.add(xAxis)
    this._paintArea.add(yAxis)

    this.resizeObserver = new ResizeObserver(entries => {
      const { width, height } = entries[0].contentRect
      this._zr.resize({ width, height })
    })
    this.resizeObserver.observe(dom)

    this.storage = storage
    const r = new Rect()
    this._zr.add(r)
    setTimeout(() => {
      this._zr.remove(r)
    }, 10)
  }

  dispose() {
    this.resizeObserver.disconnect()
    this._zr.dispose()
  }

  add(model: Model, position?: VectorArray) {
    model.addTo(this, position)
  }

  removeAll() {
    this.storage.traverse(model => {
      model.removeFrom(this)
    })
  }

  setBackgroundColor(color: string) {
    this._zr.setBackgroundColor(color)
    const r = new Rect()
    this._zr.add(r)
    setTimeout(() => {
      this._zr.remove(r)
    }, 10)
  }

  loadMapData(data: MapData) {
    data.modelList.forEach(modelData => {
      const model = new Model(modelData.model)
      model.attr({
        rotation: modelData.rotation,
        scale: modelData.scale,
      })
      this.add(model, modelData.position)
    })
  }
}

interface MapDataItem {
  model: ModelData
  position?: VectorArray
  rotation?: number
  scale?: number
}
interface MapData {
  modelList: MapDataItem[]
}

interface ModuleInitOpts {
  globalModelScale?: number
  imageBaseUrl?: string
  backgroundColor?: string
  modelSelectStyle?: object
  editMode?: boolean
  dragGrid?: boolean
  gridSize?: number
  debugMode?: {
    showModelOrigin: boolean
  }
}

mixin(Engine, Eventful)

export { Engine }

export function init(dom: HTMLElement | null, opts?: ModuleInitOpts): Engine {
  const engine = new Engine(dom)
  const {
    imageBaseUrl,
    globalModelScale,
    backgroundColor,
    modelSelectStyle,
    editMode,
    dragGrid,
    gridSize,
    debugMode,
  } = opts || {}
  Config.imageBaseUrl = imageBaseUrl
  Config.modelSelectStyle = Object.assign(
    Config.modelSelectStyle,
    modelSelectStyle
  )
  Config.editMode = editMode
  Config.dragGrid = dragGrid
  gridSize && (Config.gridSize = gridSize)
  debugMode && (Config.debugMode = debugMode)
  engine.transformHandler = new TransformHandler(engine)
  engine.globalModelScale = globalModelScale
  backgroundColor && engine.setBackgroundColor(backgroundColor)
  return engine
}
