import { Polyline as ZrPolyline } from 'zrender'
import cfg, { ShapeData } from './commonConfig'

const Polyline = {
  load(opt: ShapeData) {
    const { basic, common, style } = opt
    const polyline = new ZrPolyline({
      shape: basic,
      style,
      ...common,
      invisible: common.hidden,
      ...cfg,
    })
    polyline.name = opt.name
    return polyline
  },
}
export default Polyline
