import { VectorArray } from 'zrender/lib/core/vector'
import config from '../config'

export function deepAssign(target: object, source: object): object {
  for (const key in source) {
    const elem = target[key]
    if (typeof elem === 'object') {
      if (target[key] instanceof Array) {
        target[key] = source[key].slice()
      } else {
        target[key] = deepAssign(elem, source[key])
      }
    } else {
      target[key] = source[key]
    }
  }
  return target
}

export function deepClone(obj: object): object {
  const res = {}
  for (const key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      const elm = obj[key]
      if (elm instanceof Object) {
        if (elm instanceof Array) {
          res[key] = elm.slice()
        } else {
          res[key] = deepClone(elm)
        }
      } else {
        res[key] = elm
      }
    }
  }
  return res
}

export function gridding(v: VectorArray): VectorArray {
  return v.map(e => Math.round(e / config.gridSize) * config.gridSize)
}
