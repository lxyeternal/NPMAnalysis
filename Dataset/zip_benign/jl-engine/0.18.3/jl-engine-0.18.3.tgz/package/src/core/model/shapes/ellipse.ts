import { Ellipse as ZrEllipse } from 'zrender'
import cfg, { ShapeData } from './commonConfig'
const Ellipse = {
  load(opt: ShapeData) {
    const { basic, common, style } = opt
    const { rx, ry, rotation } = basic
    const [cx, cy] = basic.position
    let ellipse = new ZrEllipse({
      shape: { cx, cy, rx, ry },
      style,
      ...common,
      invisible: common.hidden,
      ...cfg,
    })
    ellipse.name = opt.name
    const origin = basic.position
    ellipse.setOrigin(origin)
    ellipse.attr({ rotation })
    return ellipse
  },
}
export default Ellipse
