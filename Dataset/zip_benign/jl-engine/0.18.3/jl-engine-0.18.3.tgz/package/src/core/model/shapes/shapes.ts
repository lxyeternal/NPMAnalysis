import Rect from './rect'
import Line from './line'
import Ellipse from './ellipse'
import Polyline from './polyline'
import Curve from './curve'
import Image from './image'
import Text from './text'

export default {
  Rect,
  Line,
  Ellipse,
  Polyline,
  Curve,
  Image,
  Text,
}
