import { ElementEvent, Rect, vector } from 'zrender'
import { MatrixArray } from 'zrender/lib/core/matrix'
import { VectorArray } from 'zrender/lib/core/vector'
import config from '../config'
import { Engine } from '../engine'
import { GroupPtr, Model } from '../model/model'
import storage from '../storage/storage'
import {
  mul,
  scale as scaleM,
  invert,
  applyTransform,
  identity,
} from '../utils/matrix'
import { gridding } from '../utils/util'

const { abs } = Math

const scaleStep = 0.1

export class TransformHandler {
  scaleRatio: number = 1
  get viewportOffset(): VectorArray {
    return applyTransform(invert(this.getViewportTransform()), [0, 0])
  }

  constructor(private engine: Engine) {
    this.initScaleHandler()

    this.initPanHandler()

    if (config.editMode) {
      this.initModelDragHandler()
    }
  }

  private initModelDragHandler() {
    let lastPoint: VectorArray,
      targets: Array<Model> = [],
      dragging: boolean = false
    this.engine._zr.on('mousedown', e => {
      if (e.which === 1 && e.target) {
        queueMicrotask(() => {
          let tmpTarget = e.target
          do {
            tmpTarget = tmpTarget.parent
          } while (!(tmpTarget instanceof GroupPtr))
          if (tmpTarget._model.selected) {
            targets = Array.from(storage.selectedModelList.values())
          } else {
            targets = [tmpTarget._model]
          }
          lastPoint = applyTransform(invert(this.getViewportTransform()), [
            e.offsetX,
            e.offsetY,
          ])
          dragging = true
        })
      }
    })
    this.engine._zr.on('mousemove', e => {
      if (dragging) {
        this.engine._zr.setCursorStyle('move')
        const lastPositions = targets.map(target => target.position)
        const currentPoint = applyTransform(
          invert(this.getViewportTransform()),
          [e.offsetX, e.offsetY]
        )
        const delta = [
          currentPoint[0] - lastPoint[0],
          currentPoint[1] - lastPoint[1],
        ]
        if (abs(delta[0]) > 0 || abs(delta[1]) > 0) {
          targets.forEach((target, i) => {
            target.attr({
              position: gridding([
                lastPositions[i][0] + delta[0],
                lastPositions[i][1] + delta[1],
              ]),
            })
          })
          lastPoint = gridding([...currentPoint])
        }
        console.log(targets[0].position)
      }
    })
    this.engine._zr.on('mouseup', e => {
      if (dragging) {
        this.engine._zr.setCursorStyle('default')
        dragging = false
        targets = []
      }
    })
  }

  private initScaleHandler() {
    const execScale = (origin: VectorArray, scale: number) => {
      const transform = this.engine._paintArea.transform ?? identity

      this.engine._paintArea.transform = mul(scaleM(origin, scale), transform)
      this.engine._paintArea.decomposeTransform()
      this.engine._paintArea.dirty()
    }

    const scaleHandler = (e: ElementEvent) => {
      const origin = [e.offsetX, e.offsetY]
      if (e.wheelDelta < 0) {
        this.scaleRatio *= 1 - scaleStep
        execScale(origin, 1 - scaleStep)
      } else {
        this.scaleRatio *= 1 + scaleStep
        execScale(origin, 1 + scaleStep)
      }
    }

    this.engine._zr.on('mousewheel', scaleHandler)
  }

  private initPanHandler() {
    let dragging: boolean = false
    let lastPos: VectorArray

    this.engine._zr.on('contextmenu', e => e.event.preventDefault())

    this.engine._zr.on('mousemove', e => {
      const currentPos = [e.offsetX, e.offsetY]
      if (dragging) {
        this.engine._zr.setCursorStyle('grabbing')
        const transform = this.engine._paintArea.transform ?? identity
        const offset = [currentPos[0] - lastPos[0], currentPos[1] - lastPos[1]]
        this.engine._paintArea.transform = mul(
          [1, 0, 0, 1, ...offset],
          transform
        )
        this.engine._paintArea.decomposeTransform()
        this.engine._paintArea.dirty()
        lastPos = currentPos
      }
    })

    this.engine._zr.on('mousedown', e => {
      if (e.which === 3 && !e.target) {
        dragging = true
        this.engine._zr.setCursorStyle('grab')
        lastPos = [e.offsetX, e.offsetY]
      }
    })
    this.engine._zr.on('mouseup', e => {
      if (e.which === 3) {
        dragging = false
        this.engine._zr.setCursorStyle('default')
      }
    })
  }

  public getViewportTransform(): MatrixArray {
    return this.engine._paintArea.transform ?? identity
  }

  public resetViewport(): void {
    this.engine._paintArea.transform = identity
    this.engine._paintArea.decomposeTransform()
    this.engine._paintArea.dirty()
    this.scaleRatio = 1
  }
}
