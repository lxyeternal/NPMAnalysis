import { Model } from '../model/model'

const modelList: ModelMap = {}
const selectedModelList: Set<Model> = new Set()

interface ModelMap {
  [key: string]: Model
}
export interface Storage {
  modelList: ModelMap
  selectedModelList: Set<Model>
  getModelsByType(type: string): Model[] | null
  getModelById(id: string): Model | null
  traverse(cb: (model: Model) => void): void
}

function getModelsByType(type: string): Model[] | null {
  return Object.values(modelList).filter(model => model.type === type)
}

function getModelById(id: string): Model | null {
  return modelList[id]
}
function traverse(cb: (model: Model) => void) {
  Object.values(modelList).forEach(cb)
}

function createStorage(): Storage {
  return {
    modelList,
    selectedModelList,
    getModelsByType,
    getModelById,
    traverse,
  }
}

const storage: Storage = createStorage()

export default storage

export function addModel(model: Model) {
  if (!model.modelId) {
    throw new Error('Model id is null')
  }
  if (modelList[model.modelId]) {
    throw new Error('Model already exists')
  }
  modelList[model.modelId] = model
}
export function removeModel(model: Model) {
  if (modelList[model.modelId]) {
    delete modelList[model.modelId]
  }
}
export function addSelect(model: Model) {
  selectedModelList.add(model)
}
export function removeSelect(model: Model) {
  selectedModelList.delete(model)
}
