import { deepClone } from './utils/util'
const CommonProperties = {
  length: {
    label: '长度：',
    value: 'length',
    domType: 'inputNumber',
    isShow: () => {
      return true
    },
    defaultValue: shapeList => {
      const line = shapeList[0]
      const length = Math.sqrt(
        Math.pow(line.basic.points[0][0] - line.basic.points[1][0], 2) +
          Math.pow(line.basic.points[0][1] - line.basic.points[1][1], 2)
      )
      return length
    },
    min: 0,
    handleFun: (shapeMap, length, renderSet, name) => {
      const line = shapeMap[name]
      const points = line.basic.points
      points[1][0] = points[0][0] + length
      renderSet.add(name)
    },
  },
  lineWidth: {
    label: '线宽：',
    value: 'lineWidth',
    domType: 'inputNumber',
    isShow: () => {
      return true
    },
    defaultValue: shapeList => {
      const line = shapeList[0]
      return line.style.lineWidth
    },
    min: 1,
    precision: 0,
    handleFun: (shapeMap, lineWidth, renderSet, name) => {
      const line = shapeMap[name]
      line.style.lineWidth = lineWidth
      renderSet.add(name)
    },
  },
  stroke: {
    label: '描边色：',
    value: 'stroke',
    domType: 'colorPicker',
    isShow: () => {
      return true
    },
    defaultValue: shapeList => {
      const childElem = shapeList[0]
      return childElem.style.stroke
    },
    handleFun: (shapeMap, stroke, renderSet, name) => {
      const childElem = shapeMap[name]
      childElem.style.stroke = stroke
      renderSet.add(name)
    },
  },
  fill: {
    label: '填充色：',
    value: 'fill',
    domType: 'colorPicker',
    isShow: () => {
      return true
    },
    defaultValue: shapeList => {
      const childElem = shapeList[0]
      return childElem.style.fill
    },
    handleFun: (shapeMap, fill, renderSet, name) => {
      const childElem = shapeMap[name]
      childElem.style.fill = fill
      renderSet.add(name)
    },
  },
  points: {
    label: '折线点：',
    value: 'points',
    domType: 'polylinePoints',
    isShow: () => {
      return true
    },
    defaultValue: shapeList => {
      const points = [];
      shapeList[0].basic.points.forEach(item => {
          points.push({x: item[0], y:item[1]})
      })
      return points;
    },
    handleFun: (shapeMap, points, renderSet, name) => {
      const childElem = shapeMap[name]
      childElem.basic.points = points
      renderSet.add(name)
    },
  },
  rx: {
    label: '横向半径：',
    value: 'rx',
    domType: 'inputNumber',
    min: 0,
    precision: 2,
    isShow: () => {
      return true
    },
    defaultValue: shapeList => {
      return shapeList[0].basic.rx
    },
    handleFun: (shapeMap, rx, renderSet, name) => {
      const childElem = shapeMap[name]
      childElem.basic.rx = rx
      renderSet.add(name)
    },
  },
  ry: {
    label: '纵向半径：',
    value: 'ry',
    domType: 'inputNumber',
    min: 0,
    precision: 2,
    isShow: () => {
      return true
    },
    defaultValue: shapeList => {
      return shapeList[0].basic.ry
    },
    handleFun: (shapeMap, ry, renderSet, name) => {
      const childElem = shapeMap[name]
      childElem.basic.ry = ry
      renderSet.add(name)
    },
  },
  width: {
    label: '宽：',
    value: 'width',
    domType: 'inputNumber',
    min: 0,
    precision: 2,
    isShow: () => {
      return true
    },
    defaultValue: shapeList => {
      return shapeList[0].basic.width
    },
    handleFun: (shapeMap, width, renderSet, name) => {
      const childElem = shapeMap[name]
      childElem.basic.width = width
      renderSet.add(name)
    },
  },
  height: {
    label: '高：',
    value: 'height',
    domType: 'inputNumber',
    min: 0,
    precision: 2,
    isShow: () => {
      return true
    },
    defaultValue: shapeList => {
      return shapeList[0].basic.height
    },
    handleFun: (shapeMap, height, renderSet, name) => {
      const childElem = shapeMap[name]
      childElem.basic.height = height
      renderSet.add(name)
    },
  },
  text: {
    label: '内容：',
    value: 'text',
    domType: 'input',
    isShow: () => {
      return true
    },
    defaultValue: shapeList => {
      return shapeList[0].basic.text
    },
    handleFun: (shapeMap, text, renderSet, name) => {
      const childElem = shapeMap[name]
      childElem.basic.text = text
      renderSet.add(name)
    },
  },
  fontSize: {
    label: '文字大小：',
    value: 'fontSize',
    domType: 'inputNumber',
    min: 0,
    precision: 0,
    isShow: () => {
      return true
    },
    defaultValue: shapeList => {
      return shapeList[0].basic.fontSize
    },
    handleFun: (shapeMap, fontSize, renderSet, name) => {
      const childElem = shapeMap[name]
      childElem.basic.fontSize = fontSize
      renderSet.add(name)
    },
  },
  curvePoints: {
    label: '坐标点：',
    value: 'points',
    domType: 'curvePoints',
    isShow: () => {
      return true
    },
    defaultValue: shapeList => {
      if (
        shapeList[0].basic.p1 &&
        shapeList[0].basic.cp1 &&
        shapeList[0].basic.cp2 &&
        shapeList[0].basic.p2
      ) {
        return [
          [...shapeList[0].basic.p1],
          [...shapeList[0].basic.cp1],
          [...shapeList[0].basic.cp2],
          [...shapeList[0].basic.p2],
        ]
      } else {
        return [
          [0, 0],
          [0, 0],
          [0, 0],
          [0, 0],
        ]
      }
    },
    handleFun: (shapeMap, points, renderSet, name) => {
      const childElem = shapeMap[name]
      childElem.basic.p1 = points[0]
      childElem.basic.cp1 = points[1]
      childElem.basic.cp2 = points[2]
      childElem.basic.p2 = points[3]
      renderSet.add(name)
    },
  },
}

const CommonModelDefine = {
  直线: {
    type: 'Line',
    editableProperties: {
      length: {
        property: 'length',
        defaultValueParams: [],
        handleFunParams: ['直线'],
      },
      lineWidth: {
        property: 'lineWidth',
        defaultValueParams: [],
        handleFunParams: ['直线'],
      },
      stroke: {
        property: 'stroke',
        defaultValueParams: [],
        handleFunParams: ['直线'],
      },
    },
    businessProperties: {
      type: 'Line',
    },
  },
  折线: {
    type: 'Polyline',
    editableProperties: {
      points: {
        property: 'points',
        defaultValueParams: [],
        handleFunParams: ['折线'],
      },
      lineWidth: {
        property: 'lineWidth',
        defaultValueParams: [],
        handleFunParams: ['折线'],
      },
      stroke: {
        property: 'stroke',
        defaultValueParams: [],
        handleFunParams: ['折线'],
      },
      fill: {
        property: 'fill',
        defaultValueParams: [],
        handleFunParams: ['折线'],
      }
    },
    businessProperties: {
      type: 'Polyline',
    },
  },
  椭圆: {
    type: 'Ellipse',
    editableProperties: {
      rx: { property: 'rx', defaultValueParams: [], handleFunParams: ['椭圆'] },
      ry: { property: 'ry', defaultValueParams: [], handleFunParams: ['椭圆'] },
      lineWidth: {
        property: 'lineWidth',
        defaultValueParams: [],
        handleFunParams: ['椭圆'],
      },
      stroke: {
        property: 'stroke',
        defaultValueParams: [],
        handleFunParams: ['椭圆'],
      },
      fill: {
        property: 'fill',
        defaultValueParams: [],
        handleFunParams: ['椭圆'],
      },
    },
    businessProperties: {
      type: 'Ellipse',
    },
  },
  矩形: {
    type: 'Rect',
    editableProperties: {
      width: {
        property: 'width',
        defaultValueParams: [],
        handleFunParams: ['矩形'],
      },
      height: {
        property: 'height',
        defaultValueParams: [],
        handleFunParams: ['矩形'],
      },
      lineWidth: {
        property: 'lineWidth',
        defaultValueParams: [],
        handleFunParams: ['矩形'],
      },
      stroke: {
        property: 'stroke',
        defaultValueParams: [],
        handleFunParams: ['矩形'],
      },
      fill: {
        property: 'fill',
        defaultValueParams: [],
        handleFunParams: ['矩形'],
      },
    },
    businessProperties: {
      type: 'Rect',
    },
  },
  曲线: {
    type: 'Curve',
    editableProperties: {
      curvePoints: {
        property: 'curvePoints',
        defaultValueParams: [],
        handleFunParams: ['曲线'],
      },
      lineWidth: {
        property: 'lineWidth',
        defaultValueParams: [],
        handleFunParams: ['曲线'],
      },
      stroke: {
        property: 'stroke',
        defaultValueParams: [],
        handleFunParams: ['曲线'],
      },
    },
    businessProperties: {
      type: 'Curve',
    },
  },
  文字: {
    type: 'Text',
    editableProperties: {
      text: {
        property: 'text',
        defaultValueParams: [],
        handleFunParams: ['文字'],
      },
      fontSize: {
        property: 'fontSize',
        defaultValueParams: [],
        handleFunParams: ['文字'],
      },
      fill: {
        property: 'fill',
        defaultValueParams: [],
        handleFunParams: ['文字'],
      },
    },
    businessProperties: {
      type: 'Text',
    },
  },
}
export { CommonModelDefine, CommonProperties }
