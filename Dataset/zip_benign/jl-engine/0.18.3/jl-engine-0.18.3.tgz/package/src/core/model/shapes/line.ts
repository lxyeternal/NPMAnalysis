import { Line as ZrLine } from 'zrender'
import cfg, { ShapeData } from './commonConfig'
const Line = {
  load(opt: ShapeData) {
    const { basic, common, style } = opt
    const [[x1, y1], [x2, y2]] = basic.points
    let line = new ZrLine({
      shape: { x1, y1, x2, y2 },
      style,
      ...common,
      invisible: common.hidden,
      ...cfg,
    })
    line.name = opt.name
    return line
  },
}
export default Line
