import config from '../../config'
import { Image as ZrImage } from 'zrender'
import shapeCfg, { ShapeData } from './commonConfig'
const Image = {
  load(opt: ShapeData) {
    if (!config.imageBaseUrl) {
      throw new Error('imageBaseUrl is not set')
    }
    const { basic, common, style } = opt
    const [x, y] = basic.position
    const { width, height, rotation, image } = basic
    let imageShape = new ZrImage({
      style: {
        x,
        y,
        width,
        height,
        image: `${config.imageBaseUrl}${image}`,
        ...style,
      },
      ...common,
      invisible: common.hidden,
      ...shapeCfg,
    })
    imageShape.name = opt.name
    const origin = [x + width / 2, y + height / 2]
    imageShape.setOrigin(origin)
    imageShape.attr({ rotation })
    return imageShape
  },
}
export default Image
