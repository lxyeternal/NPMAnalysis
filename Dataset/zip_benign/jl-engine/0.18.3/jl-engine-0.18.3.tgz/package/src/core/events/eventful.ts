import { Displayable, ZRenderType } from 'zrender'
import { GroupPtr, Model } from '../model/model'
import { TransformHandler } from '../transform/transformHandler'
import { applyTransform, invert } from '../utils/matrix'

export interface EventObject {
  type: string
  element: Displayable
  target: Model | null
  viewportX: number
  viewportY: number
  painterX: number
  painterY: number
  which: number
  shiftKey?: boolean
  controlKey?: boolean
  altKey?: boolean
  metakey?: boolean
}

export enum EventName {
  Click = 'click',
  MouseMove = 'mousemove',
  MouseDown = 'mousedown',
  MouseUp = 'mouseup',
  ContextMenu = 'contextmenu',
}

export class Eventful {
  _zr: ZRenderType
  transformHandler: TransformHandler
  on(
    eventName: EventName,
    handler: (e: EventObject) => void,
    filter: (target: Model) => boolean = () => true
  ): void {
    this._zr.on(eventName, e => {
      e.event.preventDefault()
      let target: Model | null = null
      let tmp: any
      if (e.target) {
        tmp = e.target
        while (tmp && !(tmp instanceof GroupPtr)) {
          tmp = tmp.parent
        }
        target = tmp._model as Model
      }
      if (!filter(target)) {
        return
      }
      const [painterX, painterY] = applyTransform(
        invert(this.transformHandler.getViewportTransform()),
        [e.offsetX, e.offsetY]
      )
      const obj: EventObject = {
        type: e.type,
        target: target,
        element: e.target as Displayable,
        viewportX: e.offsetX,
        viewportY: e.offsetY,
        painterX,
        painterY,
        which: e.which,
        controlKey: e.event.ctrlKey,
        altKey: e.event.altKey,
        shiftKey: e.event.shiftKey,
        metakey: e.event.metaKey,
      }
      handler(obj)
    })
  }
}
