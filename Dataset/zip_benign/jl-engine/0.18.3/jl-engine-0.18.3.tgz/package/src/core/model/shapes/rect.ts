import { Rect as ZrRect } from 'zrender'
import cfg, { ShapeData } from './commonConfig'
const Rect = {
  load(opt: ShapeData) {
    const { basic, common, style } = opt
    const { width, height, rotation } = basic
    const [x, y] = basic.position
    let rect = new ZrRect({
      shape: { x, y, width, height },
      style,
      ...common,
      invisible: common.hidden,
      ...cfg,
    })
    rect.name = opt.name
    const origin = [x + width / 2, y + height / 2]
    rect.setOrigin(origin)
    rect.attr({ rotation })
    return rect
  },
}
export default Rect
