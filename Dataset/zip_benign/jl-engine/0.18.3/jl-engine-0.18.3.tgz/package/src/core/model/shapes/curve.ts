import { BezierCurve } from 'zrender'
import cfg, { ShapeData } from './commonConfig'
export interface CurveData extends ShapeData {
  percent?: number
}
const Curve = {
  load(opt: CurveData) {
    const { basic, common, style, percent } = opt
    const {
      p1: [x1, y1],
      p2: [x2, y2],
      cp1: [cpx1, cpy1],
      cp2: [cpx2, cpy2],
    } = basic
    let line = new BezierCurve({
      shape: { x1, y1, x2, y2, cpx1, cpx2, cpy1, cpy2, percent },
      style,
      ...common,
      invisible: common.hidden,
      ...cfg,
    })

    line.name = opt.name
    return line
  },
}
export default Curve
