export default {
  imageBaseUrl: '',
  modelSelectStyle: {
    fill: 'transparent',
    stroke: '#f00',
    lineWidth: 1,
    lineDash: [5, 5],
    strokeNoScale: true,
  },
  editMode: false,
  dragGrid: false,
  gridSize: 10,
  debugMode: {
    showModelOrigin: false,
  },
}
