import { Text as ZrText } from 'zrender'
import cfg from './commonConfig'

const Text = {
  load(opt: { basic: any; common: any; style: any; name: string }) {
    const { basic, common, style } = opt
    let text = new ZrText({
      style: {
        ...style,
        text: basic.text,
        x: basic.position[0],
        y: basic.position[1],
        fontSize: basic.fontSize,
        borderColor: basic.borderColor,
        borderWidth: basic.borderWidth,
        padding: basic.padding,
        backgroundColor: basic.backgroundColor,
      },
      ...common,
      invisible: common.hidden,
      ...cfg,
    })
    text.name = opt.name
    const br = text.getBoundingRect()
    const { x, y, width, height } = br
    text.setOrigin([x + width / 2, y + height / 2])
    text.attr('rotation', -(basic.rotation / 180) * Math.PI)
    return text
  },
}
export default Text
