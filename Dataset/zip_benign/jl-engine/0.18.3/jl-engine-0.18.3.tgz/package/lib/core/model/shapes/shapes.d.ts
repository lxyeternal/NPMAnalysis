declare const _default: {
    Rect: {
        load(opt: import("./commonConfig").ShapeData): import("zrender/lib/graphic/shape/Rect").default;
    };
    Line: {
        load(opt: import("./commonConfig").ShapeData): import("zrender/lib/graphic/shape/Line").default;
    };
    Ellipse: {
        load(opt: import("./commonConfig").ShapeData): import("zrender/lib/graphic/shape/Ellipse").default;
    };
    Polyline: {
        load(opt: import("./commonConfig").ShapeData): import("zrender/lib/graphic/shape/Polyline").default;
    };
    Curve: {
        load(opt: import("./curve").CurveData): import("zrender/lib/graphic/shape/BezierCurve").default;
    };
    Image: {
        load(opt: import("./commonConfig").ShapeData): import("zrender/lib/graphic/Image").default;
    };
    Text: {
        load(opt: {
            basic: any;
            common: any;
            style: any;
            name: string;
        }): import("zrender/lib/graphic/Text").default;
    };
};
export default _default;
