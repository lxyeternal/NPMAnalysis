declare const BasicShapes: ({
    name: string;
    version: string;
    shapeList: {
        type: string;
        name: string;
        basic: {
            points: number[][];
        };
        style: {
            fill: string;
            stroke: string;
            opacity: number;
            lineWidth: number;
        };
        common: {
            z: number;
            hidden: boolean;
        };
    }[];
    stateAttrList: any[];
} | {
    name: string;
    version: string;
    shapeList: {
        type: string;
        name: string;
        basic: {
            points: number[][];
            rotation: number;
        };
        style: {
            fill: string;
            stroke: string;
            opacity: number;
            lineWidth: number;
        };
        common: {
            z: number;
            hidden: boolean;
        };
    }[];
    stateAttrList: any[];
} | {
    name: string;
    version: string;
    shapeList: {
        type: string;
        name: string;
        basic: {
            position: number[];
            rx: number;
            ry: number;
            rotation: number;
        };
        style: {
            fill: string;
            stroke: string;
            opacity: number;
            lineWidth: number;
        };
        common: {
            z: number;
            hidden: boolean;
        };
    }[];
    stateAttrList?: undefined;
} | {
    name: string;
    version: string;
    shapeList: {
        type: string;
        name: string;
        basic: {
            position: number[];
            width: number;
            height: number;
            rotation: number;
        };
        style: {
            fill: string;
            stoke: string;
            opacity: number;
            lineWidth: number;
        };
        common: {
            z: number;
            hidden: boolean;
        };
    }[];
    stateAttrList?: undefined;
} | {
    name: string;
    version: string;
    shapeList: {
        type: string;
        name: string;
        basic: {
            p1: number[];
            p2: number[];
            cp1: number[];
            cp2: number[];
            percent: number;
        };
        style: {
            stroke: string;
            opacity: number;
            lineWidth: number;
        };
        common: {
            z: number;
            hidden: boolean;
        };
    }[];
    stateAttrList?: undefined;
} | {
    name: string;
    version: string;
    shapeList: {
        type: string;
        name: string;
        basic: {
            position: number[];
            text: string;
            fontSize: number;
            rotation: number;
        };
        style: {
            fill: string;
            stroke: any;
            opacity: number;
            lineWidth: number;
        };
        common: {
            z: number;
            hidden: boolean;
        };
    }[];
    stateAttrList?: undefined;
})[];
export { BasicShapes };
