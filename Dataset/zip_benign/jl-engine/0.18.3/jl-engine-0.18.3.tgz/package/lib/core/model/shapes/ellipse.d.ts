import { Ellipse as ZrEllipse } from 'zrender';
import { ShapeData } from './commonConfig';
declare const Ellipse: {
    load(opt: ShapeData): ZrEllipse;
};
export default Ellipse;
