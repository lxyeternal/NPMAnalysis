import { Model } from '../model/model';
interface ModelMap {
    [key: string]: Model;
}
export interface Storage {
    modelList: ModelMap;
    selectedModelList: Set<Model>;
    getModelsByType(type: string): Model[] | null;
    getModelById(id: string): Model | null;
    traverse(cb: (model: Model) => void): void;
}
declare const storage: Storage;
export default storage;
export declare function addModel(model: Model): void;
export declare function removeModel(model: Model): void;
export declare function addSelect(model: Model): void;
export declare function removeSelect(model: Model): void;
