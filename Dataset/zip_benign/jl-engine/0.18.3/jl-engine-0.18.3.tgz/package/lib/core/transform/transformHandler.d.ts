import { MatrixArray } from 'zrender/lib/core/matrix';
import { VectorArray } from 'zrender/lib/core/vector';
import { Engine } from '../engine';
export declare class TransformHandler {
    private engine;
    scaleRatio: number;
    get viewportOffset(): VectorArray;
    constructor(engine: Engine);
    private initModelDragHandler;
    private initScaleHandler;
    private initPanHandler;
    getViewportTransform(): MatrixArray;
    resetViewport(): void;
}
