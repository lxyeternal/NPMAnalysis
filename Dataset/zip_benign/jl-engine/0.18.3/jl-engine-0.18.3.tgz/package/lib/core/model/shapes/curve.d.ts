import { BezierCurve } from 'zrender';
import { ShapeData } from './commonConfig';
export interface CurveData extends ShapeData {
    percent?: number;
}
declare const Curve: {
    load(opt: CurveData): BezierCurve;
};
export default Curve;
