import { Group, ZRenderType } from 'zrender';
import 'zrender/lib/canvas/canvas';
import { VectorArray } from 'zrender/lib/core/vector';
import { Model, ModelData } from './model/model';
import { Eventful } from './events/eventful';
import { Storage } from './storage/storage';
import { TransformHandler } from './transform/transformHandler';
interface Engine extends Eventful {
}
declare class Engine {
    _zr: ZRenderType;
    _paintArea: Group;
    globalModelScale: number;
    storage: Storage;
    transformHandler: TransformHandler;
    static modelSelectStyle: object;
    static imageBaseUrl: string;
    private resizeObserver;
    constructor(dom: HTMLElement | null);
    dispose(): void;
    add(model: Model, position?: VectorArray): void;
    removeAll(): void;
    setBackgroundColor(color: string): void;
    loadMapData(data: MapData): void;
}
interface MapDataItem {
    model: ModelData;
    position?: VectorArray;
    rotation?: number;
    scale?: number;
}
interface MapData {
    modelList: MapDataItem[];
}
interface ModuleInitOpts {
    globalModelScale?: number;
    imageBaseUrl?: string;
    backgroundColor?: string;
    modelSelectStyle?: object;
    editMode?: boolean;
    dragGrid?: boolean;
    gridSize?: number;
    debugMode?: {
        showModelOrigin: boolean;
    };
}
export { Engine };
export declare function init(dom: HTMLElement | null, opts?: ModuleInitOpts): Engine;
