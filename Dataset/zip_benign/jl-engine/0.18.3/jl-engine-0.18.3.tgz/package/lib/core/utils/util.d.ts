import { VectorArray } from 'zrender/lib/core/vector';
export declare function deepAssign(target: object, source: object): object;
export declare function deepClone(obj: object): object;
export declare function gridding(v: VectorArray): VectorArray;
