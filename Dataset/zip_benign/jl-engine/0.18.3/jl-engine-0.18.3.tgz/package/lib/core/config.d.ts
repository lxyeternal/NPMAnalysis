declare const _default: {
    imageBaseUrl: string;
    modelSelectStyle: {
        fill: string;
        stroke: string;
        lineWidth: number;
        lineDash: number[];
        strokeNoScale: boolean;
    };
    editMode: boolean;
    dragGrid: boolean;
    gridSize: number;
    debugMode: {
        showModelOrigin: boolean;
    };
};
export default _default;
