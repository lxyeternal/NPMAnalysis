declare const CommonProperties: {
    length: {
        label: string;
        value: string;
        domType: string;
        isShow: () => boolean;
        defaultValue: (shapeList: any) => number;
        min: number;
        handleFun: (shapeMap: any, length: any, renderSet: any, name: any) => void;
    };
    lineWidth: {
        label: string;
        value: string;
        domType: string;
        isShow: () => boolean;
        defaultValue: (shapeList: any) => any;
        min: number;
        precision: number;
        handleFun: (shapeMap: any, lineWidth: any, renderSet: any, name: any) => void;
    };
    stroke: {
        label: string;
        value: string;
        domType: string;
        isShow: () => boolean;
        defaultValue: (shapeList: any) => any;
        handleFun: (shapeMap: any, stroke: any, renderSet: any, name: any) => void;
    };
    fill: {
        label: string;
        value: string;
        domType: string;
        isShow: () => boolean;
        defaultValue: (shapeList: any) => any;
        handleFun: (shapeMap: any, fill: any, renderSet: any, name: any) => void;
    };
    points: {
        label: string;
        value: string;
        domType: string;
        isShow: () => boolean;
        defaultValue: (shapeList: any) => any[];
        handleFun: (shapeMap: any, points: any, renderSet: any, name: any) => void;
    };
    rx: {
        label: string;
        value: string;
        domType: string;
        min: number;
        precision: number;
        isShow: () => boolean;
        defaultValue: (shapeList: any) => any;
        handleFun: (shapeMap: any, rx: any, renderSet: any, name: any) => void;
    };
    ry: {
        label: string;
        value: string;
        domType: string;
        min: number;
        precision: number;
        isShow: () => boolean;
        defaultValue: (shapeList: any) => any;
        handleFun: (shapeMap: any, ry: any, renderSet: any, name: any) => void;
    };
    width: {
        label: string;
        value: string;
        domType: string;
        min: number;
        precision: number;
        isShow: () => boolean;
        defaultValue: (shapeList: any) => any;
        handleFun: (shapeMap: any, width: any, renderSet: any, name: any) => void;
    };
    height: {
        label: string;
        value: string;
        domType: string;
        min: number;
        precision: number;
        isShow: () => boolean;
        defaultValue: (shapeList: any) => any;
        handleFun: (shapeMap: any, height: any, renderSet: any, name: any) => void;
    };
    text: {
        label: string;
        value: string;
        domType: string;
        isShow: () => boolean;
        defaultValue: (shapeList: any) => any;
        handleFun: (shapeMap: any, text: any, renderSet: any, name: any) => void;
    };
    fontSize: {
        label: string;
        value: string;
        domType: string;
        min: number;
        precision: number;
        isShow: () => boolean;
        defaultValue: (shapeList: any) => any;
        handleFun: (shapeMap: any, fontSize: any, renderSet: any, name: any) => void;
    };
    curvePoints: {
        label: string;
        value: string;
        domType: string;
        isShow: () => boolean;
        defaultValue: (shapeList: any) => any[][];
        handleFun: (shapeMap: any, points: any, renderSet: any, name: any) => void;
    };
};
declare const CommonModelDefine: {
    直线: {
        type: string;
        editableProperties: {
            length: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            lineWidth: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            stroke: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
        };
        businessProperties: {
            type: string;
        };
    };
    折线: {
        type: string;
        editableProperties: {
            points: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            lineWidth: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            stroke: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            fill: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
        };
        businessProperties: {
            type: string;
        };
    };
    椭圆: {
        type: string;
        editableProperties: {
            rx: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            ry: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            lineWidth: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            stroke: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            fill: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
        };
        businessProperties: {
            type: string;
        };
    };
    矩形: {
        type: string;
        editableProperties: {
            width: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            height: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            lineWidth: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            stroke: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            fill: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
        };
        businessProperties: {
            type: string;
        };
    };
    曲线: {
        type: string;
        editableProperties: {
            curvePoints: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            lineWidth: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            stroke: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
        };
        businessProperties: {
            type: string;
        };
    };
    文字: {
        type: string;
        editableProperties: {
            text: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            fontSize: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
            fill: {
                property: string;
                defaultValueParams: any[];
                handleFunParams: string[];
            };
        };
        businessProperties: {
            type: string;
        };
    };
};
export { CommonModelDefine, CommonProperties };
