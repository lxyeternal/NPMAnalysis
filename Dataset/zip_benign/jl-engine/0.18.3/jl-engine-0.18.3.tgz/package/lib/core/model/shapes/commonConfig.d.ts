declare const _default: {
    cursor: string;
};
export default _default;
export interface ShapeData {
    type?: any;
    basic?: any;
    common?: any;
    style?: any;
    name?: string;
}
