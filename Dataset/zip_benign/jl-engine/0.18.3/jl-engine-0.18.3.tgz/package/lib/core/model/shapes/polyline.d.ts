import { Polyline as ZrPolyline } from 'zrender';
import { ShapeData } from './commonConfig';
declare const Polyline: {
    load(opt: ShapeData): ZrPolyline;
};
export default Polyline;
