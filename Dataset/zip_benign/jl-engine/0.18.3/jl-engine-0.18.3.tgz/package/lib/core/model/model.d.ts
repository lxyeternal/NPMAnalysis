import { Displayable, Group } from 'zrender';
import { VectorArray } from 'zrender/lib/core/vector';
import { Engine } from '../engine';
import { ShapeData } from './shapes/commonConfig';
export declare enum FlipDirection {
    HORIZONTAL = "horizontal",
    VERTICAL = "vertical"
}
export declare class GroupPtr extends Group {
    _model: Model;
}
declare class Model {
    _selectRectStyle: object;
    group: GroupPtr;
    name: string;
    version: string;
    type: string;
    modelId: string;
    private selectRect;
    selected: boolean;
    shapeList: ShapeData[];
    shapeInstaceList: Displayable[];
    floatingElements: Displayable[];
    horzontalFlipped: boolean;
    verticalFlipped: boolean;
    constructor(modelData: ModelData);
    get flipped(): boolean;
    set selectRectStyle(style: object);
    get selectRectStyle(): object;
    get transform(): import("zrender/lib/core/matrix").MatrixArray;
    protected set transform(transform: import("zrender/lib/core/matrix").MatrixArray);
    private br;
    private axis1;
    private axis2;
    get position(): VectorArray;
    protected set position(position: VectorArray);
    flip(direction?: FlipDirection, state?: boolean): void;
    get rotation(): number;
    protected set rotation(rotation: number);
    get scale(): number;
    protected set scale(scale: number);
    get level(): number;
    protected set level(level: number);
    addTo(engine: Engine, position?: number[]): Model;
    removeFrom(engine: Engine): Model;
    /**
     * 此处属性应用顺序为传入对象的key顺序
     */
    attr(attrObj: ModelAttr): Model;
    /**
     * 更新模型的子元素属性
     * @param childName 子模型名称
     * @param attr 属性对象
     */
    setChildAttr(childName: string, attr: ShapeData): void;
    private fixFloatingElementTransform;
    select(): Model;
    unselect(): Model;
    highlight(): void;
    unhighlight(): void;
}
export { Model };
export declare interface ModelAttr {
    position?: VectorArray;
    rotation?: number;
    scale?: number;
    level?: number;
}
export declare interface ModelData {
    name: string;
    shapeList: ShapeData[];
    selectRectStyle?: object;
    id?: string;
    version: string;
    type: string;
}
