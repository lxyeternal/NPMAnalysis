import { Rect as ZrRect } from 'zrender';
import { ShapeData } from './commonConfig';
declare const Rect: {
    load(opt: ShapeData): ZrRect;
};
export default Rect;
