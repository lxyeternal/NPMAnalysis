import { Image as ZrImage } from 'zrender';
import { ShapeData } from './commonConfig';
declare const Image: {
    load(opt: ShapeData): ZrImage;
};
export default Image;
