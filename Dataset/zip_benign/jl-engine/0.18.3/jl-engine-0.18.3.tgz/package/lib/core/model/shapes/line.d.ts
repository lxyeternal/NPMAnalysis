import { Line as ZrLine } from 'zrender';
import { ShapeData } from './commonConfig';
declare const Line: {
    load(opt: ShapeData): ZrLine;
};
export default Line;
