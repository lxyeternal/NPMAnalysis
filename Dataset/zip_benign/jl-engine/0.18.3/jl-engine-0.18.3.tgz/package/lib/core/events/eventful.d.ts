import { Displayable, ZRenderType } from 'zrender';
import { Model } from '../model/model';
import { TransformHandler } from '../transform/transformHandler';
export interface EventObject {
    type: string;
    element: Displayable;
    target: Model | null;
    viewportX: number;
    viewportY: number;
    painterX: number;
    painterY: number;
    which: number;
    shiftKey?: boolean;
    controlKey?: boolean;
    altKey?: boolean;
    metakey?: boolean;
}
export declare enum EventName {
    Click = "click",
    MouseMove = "mousemove",
    MouseDown = "mousedown",
    MouseUp = "mouseup",
    ContextMenu = "contextmenu"
}
export declare class Eventful {
    _zr: ZRenderType;
    transformHandler: TransformHandler;
    on(eventName: EventName, handler: (e: EventObject) => void, filter?: (target: Model) => boolean): void;
}
