import { Text as ZrText } from 'zrender';
declare const Text: {
    load(opt: {
        basic: any;
        common: any;
        style: any;
        name: string;
    }): ZrText;
};
export default Text;
