export declare enum DataType {
    UNDEFINED = "attribute",
    NULL = "null",
    ACTIONS = "actions",
    ANY = "any",
    ARRAY = "array",
    BOOLEAN = "boolean",
    BOUNDS = "bounds",
    COLLECTION = "collection",
    COLOR = "color",
    DATE_TIME = "date_time",
    FUNCTION = "function",
    OBJECT = "object",
    NUMBER = "number",
    NUMBER_DOUBLE = "number_double",
    NUMBER_INT = "number_int",
    NUMBER_BYTE = "number_byte",
    NUMBERS = "numbers",
    POINT = "point",
    POINT_3D = "point_3d",
    RANGE = "range",
    RECTANGLE = "rectangle",
    REG_EXP = "reg_exp",
    SELECT = "select",
    SIZE = "size",
    SIZE_3D = "size_3d",
    STRING = "string",
    STRING_BASE64 = "string_base_64",
    STRING_BINARY = "string_binary",
    STRING_DATA_URL = "string_data_url",
    STRING_HEX_VALUE = "string_hex_value",
    STRING_HTML = "string_html",
    STRING_JAVASCRIPT = "string_javascript",
    STRING_JSON = "string_json",
    STRING_REG_EXP = "string_reg_exp",
    STRING_SVG = "string_svg",
    STRING_URI = "string_uri",
    STRING_XML = "string_xml",
    VECTOR = "vector"
}
export declare enum AttributesWrapType {
    OVERWRITE_BASE = 0,
    CLEAR_BASE = 1,
    OVERWRITE_WRAPPED = 2,
    CLEAR_WRAPPED = 3
}
export declare enum ModelUpdateHandlerSequence {
    BEFORE_UPDATE = 0,
    AFTER_UPDATE = 1
}
export declare enum IdAutoGenerationType {
    NONE = 0,
    GLOBALLY_UNIQUE = 1,
    SESSION_UNIQUE = 2
}
export declare enum AttributeChangeActions {
    NONE = 0,
    SIGNAL_CHANGE = 1,
    SAVE = 2
}
