"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=iAttributesFactory.js.map