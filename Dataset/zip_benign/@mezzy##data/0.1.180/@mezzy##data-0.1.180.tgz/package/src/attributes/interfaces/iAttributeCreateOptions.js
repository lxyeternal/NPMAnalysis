"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=iAttributeCreateOptions.js.map