"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=iAttributeFactory.js.map