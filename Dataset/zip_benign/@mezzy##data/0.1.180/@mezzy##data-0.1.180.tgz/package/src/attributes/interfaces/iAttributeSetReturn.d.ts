import { IAnimationBatch } from '@mezzy/animation';
import IAttribute from './iAttribute';
import IAttributeUpdateTracker from './iAttributeUpdateTracker';
export interface IAttributeSetReturn {
    attribute: IAttribute;
    isChanged: boolean;
    animation: IAnimationBatch;
    updateTracker: IAttributeUpdateTracker;
}
export default IAttributeSetReturn;
