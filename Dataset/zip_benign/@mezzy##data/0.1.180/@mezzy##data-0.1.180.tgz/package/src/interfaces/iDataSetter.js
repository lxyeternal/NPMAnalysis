"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=iDataSetter.js.map