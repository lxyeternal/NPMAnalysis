"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=iDataOwner.js.map