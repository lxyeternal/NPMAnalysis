import React from 'react';
import { useGSAP } from '@gsap/react';
import { useRef } from 'react';
import SplitType from 'split-type';
import gsap from 'gsap';

type StaggerTextTypes = {
  text: string;
  state?: boolean;
  from: gsap.TweenVars;
  to?: gsap.TweenVars;
  staggerAmt?: number;
  duration?: number;
  delay?: number;
  styles?: {
    size?: number;
    color?: string;
    overflow?: 'hidden' | 'scroll' | 'visible';
  };
  scroller?: string; // Should be the identifier of the scroller
  scrollTrigger?: string; // Should be the container where the text is contained
  staggerOnScroll?: boolean; // True if letter stagger is required 
  markers?: boolean;
};
export const StaggerText = ({
  text,
  state,
  styles,
  from,
  to,
  staggerAmt,
  duration,
  delay,
  scroller,
  scrollTrigger,
  staggerOnScroll,
  markers,
}: StaggerTextTypes) => {
  const ref = useRef<HTMLDivElement>(null);
  const { color, size = 30, overflow = 'hidden' } = styles!;
  useGSAP(
    () => {
      const splitText = new SplitType(ref.current!);
      const chars = splitText.chars;
      const elem = document.querySelector(`.${scrollTrigger}`);
      const scrollerElem = document.querySelector(`.${scroller}`);
      console.log(elem, scrollerElem)
      gsap.fromTo(
        chars,
        {
          translateY: from.translateY,
          translateX: from.translateX,
          filter: from.filter,
          skewY: from.skewY ?? '0deg',
          skewX: from.skewX ?? '0deg',
          opacity: from.opacity,
          ease: from.ease,
        },
        {
          translateY: to?.translateY ?? 0,
          translateX: to?.translateX ?? 0,
          filter: to?.filter ?? 'blur(0px)',
          opacity: to?.opacity ?? 1,
          skewX: to?.skewX ?? '0deg',
          skewY: to?.skewY ?? '0deg',
          ease: to?.ease ?? from.ease,
          stagger: {
            amount: staggerAmt,
          },
          scrollTrigger: {
            scroller: scrollerElem,
            trigger: elem,
            start: staggerOnScroll ? 0 : 'top center',
            scrub: staggerOnScroll,
            markers: markers ?? false,
          },
          duration: duration,
          delay: delay ?? 0,
        }
      );
    },
    {
      dependencies: [ref],
      scope: ref,
      revertOnUpdate: true,
    }
  );

  return (
    <div ref={ref} className="stagger-container">
      <p
        className={`stagger`}
        style={{
          color: color,
          fontSize: `${size}px`,
          overflow: overflow,
        }}
      >
        {text}
      </p>
    </div>
  );
};
