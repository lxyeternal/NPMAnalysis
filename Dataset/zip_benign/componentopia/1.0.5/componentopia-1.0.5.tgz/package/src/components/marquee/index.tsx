import React from 'react';
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { useEffect, useRef } from 'react';
import { mergeClassNames } from '../mergeClass';

interface BaseMarqueeProps {
  baseVelocity: number;
  classes?: string;
  texts: string[];
  direction?: 'right' | 'left';
  styles?: {
    color?: string;
    subColor?: string;
    size?: number;
    height?: number;
  };
  variants?: 'outlined' | 'none';
}
interface DirectionalMarqueeProps extends BaseMarqueeProps {
  directional: true;
  parentClassName: string;
}
interface NonDirectionalMarqueeProps extends BaseMarqueeProps {
  directional: false;
  parentClassName?: never;
}
type MarqueeProps = DirectionalMarqueeProps | NonDirectionalMarqueeProps;
export const Marquee = ({
  texts,
  classes = '',
  baseVelocity = 0.5,
  directional = false,
  parentClassName,
  styles,
  direction = 'right',
  variants = 'none',
}: MarqueeProps) => {
  let x = 0,
    animateFrameId: number;

  var directionPos = direction === 'right' ? 1 : -1;
  const { color, size = 30, height = 50 } = styles!;
  const marquee__Ref = useRef<HTMLDivElement | null>(null);
  const { contextSafe } = useGSAP({
    scope: marquee__Ref,
    revertOnUpdate: true,
  });

  var textValue;

  if (texts.length < 3) {
    textValue = Array.from({ length: 6 }, () => texts)
      .flat()
      .slice(0, 6);
  } else {
    textValue = texts.slice(0, 6);
  }

  useEffect(() => {
    const elem = document.querySelector(`.${parentClassName}`);

    start(elem);

    return () => {
      cancelAnimationFrame(animateFrameId);
    };
  }, []);

  const start = contextSafe((elem: Element | null) => {
    gsap.set('.text__container__1', {
      left: marquee__Ref
        .current!.querySelector('.text__container__1')!
        .getBoundingClientRect().width,
    });
    // gsap.set(elem, {
    //   height: elem?.getBoundingClientRect().height,
    // });
    if (directional) {
      gsap.to('.slider', {
        scrollTrigger: {
          trigger: elem,
          start: 'top 0',
          end: `bottom bottom`,
          scrub: true,
          markers: true,
          onUpdate: (e) => {
            console.log(e);
            directionPos = e.direction * -1;
          },
        },
      });
    }
    animateFrameId = requestAnimationFrame(animate);
  });

  const animate = contextSafe(() => {
    if (x > 0) {
      x = -100;
    } else if (x < -100) {
      x = 0;
    }

    gsap.set('.text__container__1', {
      xPercent: x,
    });
    gsap.set('.text__container__2', {
      xPercent: x,
    });
    animateFrameId = requestAnimationFrame(animate);

    x += baseVelocity * directionPos;
  });

  return (
    <div
      className="w-full overflow-hidden marquee-container"
      ref={marquee__Ref}
    >
      <div
        className={mergeClassNames(`slider w-full relative`, classes)}
        style={{
          height: `${height}px`,
        }}
      >
        <div className={`text__container__1 whitespace-nowrap absolute top-0`}>
          {textValue.map((text, index) => {
            return (
              <span
                key={index}
                className={`m-0 ml-10`}
                style={{
                  color: color,
                  fontSize: `${size}px`,
                }}
              >
                {text}
              </span>
            );
          })}
        </div>
        <div className={`text__container__2 whitespace-nowrap absolute top-0`}>
          {textValue.map((text, index) => {
            return (
              <span
                key={index}
                className={`m-0 ml-10`}
                style={{
                  color: color,
                  fontSize: `${size}px`,
                }}
              >
                {text}
              </span>
            );
          })}
        </div>
      </div>
    </div>
  );
};
