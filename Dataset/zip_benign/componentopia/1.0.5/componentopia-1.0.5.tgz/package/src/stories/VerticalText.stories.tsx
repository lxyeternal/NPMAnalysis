import type { Meta, StoryObj } from '@storybook/react';
import { TextLoopVertical } from '../index';

const meta = {
  title: 'Vertical Text Loop',
  component: TextLoopVertical,
  tags: ['autodocs'],
  parameters: {
    layout: 'fullscreen',
  },
  args: {},
} satisfies Meta<typeof TextLoopVertical>;

export default meta;
type Story = StoryObj<typeof meta>;

export const TextLoopVerticalTest: Story = {
  args: {
    wordList: ['Cloud Engineer', 'DevOps Engineer', 'Cloud Analyst'],
    fontSize: 50,
    height: 70,
    color: 'black',
  },
};
