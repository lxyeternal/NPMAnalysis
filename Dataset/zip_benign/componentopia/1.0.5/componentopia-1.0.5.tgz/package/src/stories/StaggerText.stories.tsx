import type { Meta, StoryObj } from '@storybook/react';
import React from 'react';
import { StaggerText } from '../index';

const meta = {
  title: 'StaggerText',
  component: StaggerText,
  tags: ['autodocs'],
  parameters: {
    layout: 'fullscreen',
  },
  args: {
    text: 'A Full-Stack Developer',
    styles: {
      color: 'black',
      size: 30,
    },
    from: {
      translateY: 100,
      opacity: 0,
    },
    staggerAmt: 0.5,
    delay: 0.4,
    duration: 0.5,
    staggerOnScroll: true,
    markers: true,
  },
} satisfies Meta<typeof StaggerText>;

export default meta;

const ParentDecorator = (StoryComponent: React.ComponentType) => (
  <div className="stagger_parent h-[150vh]">
    <div className='stagger_container h-[100px]'>
      <StoryComponent />
    </div>
    <div className='stagger_container h-[100px]'>
      <StoryComponent />
    </div>
    <div className='stagger_container h-[100px]'>
      <StoryComponent />
    </div>
    <div className='stagger_container h-[100px]'>
      <StoryComponent />
    </div>
    <div className='stagger_container h-[100px]'>
      <StoryComponent />
    </div>
    <div className='stagger_container h-[100px]'>
      <StoryComponent />
    </div>
    <div className='stagger_container h-[100px]'>
      <StoryComponent />
    </div>
    <div className='stagger_container h-[100px]'>
      <StoryComponent />
    </div>
    <div className='stagger_container h-[100px]'>
      <StoryComponent />
    </div>
  </div>
);
const ParentDecorator1 = (StoryComponent: React.ComponentType) => (
  <div className="stagger_parent h-[150vh]">
    <div className='stagger_container h-[100px]'>
      <StoryComponent />
    </div>
  </div>
);
export const StaggerLettersOnScroll: Story = {
  decorators: [ParentDecorator],
  args: {
    staggerOnScroll: true,
    scroller: 'sb-show-main',
    scrollTrigger: 'stagger_container',
  },
};
export const StaggerOnScroll: Story = {
  decorators: [ParentDecorator1],
  args: {
    staggerOnScroll: false,
    scroller: 'sb-show-main',
    scrollTrigger: 'stagger_container',
  },
};
type Story = StoryObj<typeof meta>;

export const StaggerTextDefault: Story = {
  args: {
    staggerOnScroll: false
  }
};
