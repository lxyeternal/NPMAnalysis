# Correct Operations

A simple module to fix decimal operations errors in javascript

## How to use

```typescript
import {sum} from "correct-operations"

console.log(0.1 + 0.2)
//Output: 0.30000000000000004

console.log(sum(0.1, 0.2))
//Output: 0.3
```