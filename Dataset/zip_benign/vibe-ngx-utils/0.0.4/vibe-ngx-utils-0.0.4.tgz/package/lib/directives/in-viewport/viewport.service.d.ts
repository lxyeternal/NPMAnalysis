import { Observable } from 'rxjs';
export declare class ViewportService {
    private readonly options;
    private observer;
    private callback$;
    constructor();
    observe(element: Element): Observable<IntersectionObserverEntry>;
    private handler;
}
