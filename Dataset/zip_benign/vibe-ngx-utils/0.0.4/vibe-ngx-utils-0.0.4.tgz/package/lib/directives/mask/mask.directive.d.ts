import { ElementRef, EventEmitter, OnInit, PipeTransform } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
export declare function isIE(): boolean;
export declare class MaskDirective implements OnInit, ControlValueAccessor {
    private elementRef;
    mask: string;
    promptChar: string;
    includeLiterals: boolean;
    placeholder: string;
    displayValuePipe: PipeTransform;
    focusedValuePipe: PipeTransform;
    private dataValue;
    onValueChange: EventEmitter<IMaskEventArgs>;
    private value;
    private readonly nativeElement;
    private readonly selectionStart;
    private readonly selectionEnd;
    private ctrlDown;
    private paste;
    private selection;
    private maskOptions;
    private key;
    private cursorOnPaste;
    private valOnPaste;
    private stopPropagation;
    private maskHelper;
    private onTouchedCallback;
    private onChangeCallback;
    constructor(elementRef: ElementRef);
    ngOnInit(): void;
    onKeydown(event: any): void;
    onKeyup(event: any): void;
    onPaste(event: any): void;
    onInputChanged(event: any): void;
    onFocus(value: any): void;
    onBlur(value: any): void;
    private getCursorPosition;
    private setCursorPosition;
    writeValue(value: any): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
}
export interface IMaskEventArgs {
    rawValue: string;
    formattedValue: string;
}
