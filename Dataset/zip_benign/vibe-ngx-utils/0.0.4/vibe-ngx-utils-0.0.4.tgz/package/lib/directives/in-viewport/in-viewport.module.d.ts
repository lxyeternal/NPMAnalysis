export declare class InViewportModule {
}
