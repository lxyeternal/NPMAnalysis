export declare class RouterLinkMatchModule {
}
