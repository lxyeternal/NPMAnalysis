export declare class MaskModule {
}
