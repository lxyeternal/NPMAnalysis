export declare class ClickOutsideModule {
}
