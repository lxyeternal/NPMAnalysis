import { ElementRef, EventEmitter } from '@angular/core';
export declare class ClickOutsideDirective {
    private _elementRef;
    ngxClickOutside: EventEmitter<MouseEvent>;
    constructor(_elementRef: ElementRef);
    onClick(event: MouseEvent, targetElement: HTMLElement): void;
}
