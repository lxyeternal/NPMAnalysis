export declare class MinModule {
}
