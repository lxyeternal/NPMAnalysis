export declare class NgLetModule {
}
