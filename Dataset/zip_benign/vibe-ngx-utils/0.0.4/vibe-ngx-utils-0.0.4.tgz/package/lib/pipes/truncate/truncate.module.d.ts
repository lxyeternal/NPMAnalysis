export declare class TruncateModule {
}
