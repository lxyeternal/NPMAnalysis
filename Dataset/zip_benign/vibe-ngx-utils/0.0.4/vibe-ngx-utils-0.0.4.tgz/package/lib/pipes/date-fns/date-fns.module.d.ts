export declare class DateFnsModule {
}
