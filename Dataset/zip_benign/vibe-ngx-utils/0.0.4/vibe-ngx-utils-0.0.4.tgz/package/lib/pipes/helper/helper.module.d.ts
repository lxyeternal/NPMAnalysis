export declare class HelperModule {
}
