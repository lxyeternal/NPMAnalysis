import { PipeTransform } from '@angular/core';
export declare class WordsPipe implements PipeTransform {
    transform(value: string, limit?: number, trail?: String): string;
}
