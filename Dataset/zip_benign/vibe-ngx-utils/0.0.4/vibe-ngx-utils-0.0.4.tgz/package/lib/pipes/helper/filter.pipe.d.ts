import { PipeTransform } from '@angular/core';
export declare class FilterPipe implements PipeTransform {
    transform(itemList: any[], filterTerm?: string, filterBy?: any): any[];
}
