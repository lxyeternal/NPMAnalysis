import { Directive, ViewContainerRef, TemplateRef, Input, NgModule, Renderer2, ElementRef, Injectable, ɵɵdefineInjectable, Inject, PLATFORM_ID, Output, EventEmitter, HostListener, Pipe, ChangeDetectorRef } from '@angular/core';
import { CommonModule, isPlatformBrowser, AsyncPipe } from '@angular/common';
import { __spread, __read, __values, __assign } from 'tslib';
import { Router, NavigationEnd } from '@angular/router';
import { Observable, Subject, combineLatest, of, interval } from 'rxjs';
import { takeUntil, pluck as pluck$1, map, filter, finalize, take, repeatWhen, delayWhen, takeWhile, tap } from 'rxjs/operators';
import { Validators, NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { formatDistance, differenceInMinutes, parseISO } from 'date-fns/esm';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var NgLetContext = /** @class */ (function () {
    function NgLetContext() {
        this.$implicit = null;
        this.ngLet = null;
    }
    return NgLetContext;
}());
var NgLetDirective = /** @class */ (function () {
    function NgLetDirective(_vcr, _templateRef) {
        this._vcr = _vcr;
        this._templateRef = _templateRef;
        this._context = new NgLetContext();
    }
    Object.defineProperty(NgLetDirective.prototype, "ngLet", {
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this._context.$implicit = this._context.ngLet = value;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    NgLetDirective.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        this._vcr.createEmbeddedView(this._templateRef, this._context);
    };
    NgLetDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ngLet]',
                },] }
    ];
    /** @nocollapse */
    NgLetDirective.ctorParameters = function () { return [
        { type: ViewContainerRef },
        { type: TemplateRef }
    ]; };
    NgLetDirective.propDecorators = {
        ngLet: [{ type: Input }]
    };
    return NgLetDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var NgLetModule = /** @class */ (function () {
    function NgLetModule() {
    }
    NgLetModule.decorators = [
        { type: NgModule, args: [{
                    imports: [CommonModule],
                    declarations: [NgLetDirective],
                    exports: [NgLetDirective],
                },] }
    ];
    return NgLetModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
// create a symbol identify the observable I add to
// the component so it doesn't conflict with anything.
// I need this so I'm able to add the desired behaviour to the component.
/** @type {?} */
var destroy$ = Symbol('destroy$');
/**
 * An operator that takes until destroy it takes a components this a parameter
 * returns a pipeable RxJS operator.
 * @type {?}
 */
var untilDestroy = (/**
 * @template T
 * @param {?} component
 * @return {?}
 */
function (component) {
    if (component[destroy$] === undefined) {
        // only hookup each component once.
        addDestroyObservableToComponent(component);
    }
    // pipe in the takeUntil destroy$ and return the source unaltered
    return takeUntil(component[destroy$]);
});
/**
 * \@internal
 * @param {?} component
 * @return {?}
 */
function addDestroyObservableToComponent(component) {
    component[destroy$] = new Observable((/**
     * @param {?} observer
     * @return {?}
     */
    function (observer) {
        // keep track of the original destroy function,
        // the user might do something in there
        /** @type {?} */
        var orignalDestroy = component.ngOnDestroy;
        if (orignalDestroy == null) {
            // Angular does not support dynamic added destroy methods
            // so make sure there is one.
            throw new Error('untilDestroy operator needs the component to have an ngOnDestroy method');
        }
        // replace the ngOndestroy
        component.ngOnDestroy = (/**
         * @return {?}
         */
        function () {
            // fire off the destroy observable
            observer.next();
            // complete the observable
            observer.complete();
            // and at last, call the original destroy
            orignalDestroy.call(component);
        });
        // return cleanup function.
        return (/**
         * @param {?} _
         * @return {?}
         */
        function (_) { return (component[destroy$] = undefined); });
    }));
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @template T, V
 * @param {...?} props
 * @return {?}
 */
function pluck() {
    var props = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        props[_i] = arguments[_i];
    }
    return pluck$1.apply(void 0, __spread(props));
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var RouterLinkMatchDirective = /** @class */ (function () {
    function RouterLinkMatchDirective(router, _renderer, _ngEl) {
        var _this = this;
        this._renderer = _renderer;
        this._ngEl = _ngEl;
        this._onChangesHook = new Subject();
        combineLatest(router.events, this._onChangesHook)
            .pipe(map((/**
         * @param {?} __0
         * @return {?}
         */
        function (_a) {
            var _b = __read(_a, 1), e = _b[0];
            return e;
        })), filter((/**
         * @param {?} e
         * @return {?}
         */
        function (e) { return e instanceof NavigationEnd; })), untilDestroy(this))
            .subscribe((/**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            _this._curRoute = ((/** @type {?} */ (e))).urlAfterRedirects;
            _this._updateClass(_this._matchExp);
        }));
    }
    Object.defineProperty(RouterLinkMatchDirective.prototype, "routerLinkMatch", {
        set: /**
         * @param {?} v
         * @return {?}
         */
        function (v) {
            if (v && typeof v === 'object') {
                this._matchExp = v;
            }
            else {
                throw new TypeError("Unexpected type '" + typeof v + "' of value for " + "input of routerLinkMatch directive, expected 'object'");
            }
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @param {?} changes
     * @return {?}
     */
    RouterLinkMatchDirective.prototype.ngOnChanges = /**
     * @param {?} changes
     * @return {?}
     */
    function (changes) {
        if (changes['routerLinkMatch']) {
            this._onChangesHook.next(changes['routerLinkMatch'].currentValue);
        }
    };
    /**
     * @private
     * @param {?} v
     * @return {?}
     */
    RouterLinkMatchDirective.prototype._updateClass = /**
     * @private
     * @param {?} v
     * @return {?}
     */
    function (v) {
        var _this = this;
        Object.keys(v).forEach((/**
         * @param {?} cls
         * @return {?}
         */
        function (cls) {
            if (v[cls] && typeof v[cls] === 'string') {
                /** @type {?} */
                var regexp = new RegExp(v[cls]);
                if (_this._curRoute.match(regexp)) {
                    _this._toggleClass(cls, true);
                }
                else {
                    _this._toggleClass(cls, false);
                }
            }
            else {
                throw new TypeError("Could not convert match value to Regular Expression. " +
                    ("Unexpected type '" + typeof v[cls] + "' for value of key '" + cls + "' ") +
                    "in routerLinkMatch directive match expression, expected 'non-empty string'");
            }
        }));
    };
    /**
     * @private
     * @param {?} classes
     * @param {?} enabled
     * @return {?}
     */
    RouterLinkMatchDirective.prototype._toggleClass = /**
     * @private
     * @param {?} classes
     * @param {?} enabled
     * @return {?}
     */
    function (classes, enabled) {
        var _this = this;
        classes = classes.trim();
        classes.split(/\s+/g).forEach((/**
         * @param {?} cls
         * @return {?}
         */
        function (cls) {
            if (enabled) {
                _this._renderer.addClass(_this._ngEl.nativeElement, cls);
            }
            else {
                _this._renderer.removeClass(_this._ngEl.nativeElement, cls);
            }
        }));
    };
    /**
     * @return {?}
     */
    RouterLinkMatchDirective.prototype.ngOnDestroy = /**
     * @return {?}
     */
    function () { };
    RouterLinkMatchDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[routerLinkMatch]',
                },] }
    ];
    /** @nocollapse */
    RouterLinkMatchDirective.ctorParameters = function () { return [
        { type: Router },
        { type: Renderer2 },
        { type: ElementRef }
    ]; };
    RouterLinkMatchDirective.propDecorators = {
        routerLinkMatch: [{ type: Input, args: ['routerLinkMatch',] }]
    };
    return RouterLinkMatchDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var RouterLinkMatchModule = /** @class */ (function () {
    function RouterLinkMatchModule() {
    }
    RouterLinkMatchModule.decorators = [
        { type: NgModule, args: [{
                    imports: [CommonModule],
                    declarations: [RouterLinkMatchDirective],
                    exports: [RouterLinkMatchDirective],
                },] }
    ];
    return RouterLinkMatchModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ViewportService = /** @class */ (function () {
    function ViewportService() {
        this.options = {
            rootMargin: '0px 0px 0px 0px',
            threshold: [0.5],
        };
        this.callback$ = new Subject();
        this.observer = new IntersectionObserver(this.handler.bind(this), this.options);
    }
    /**
     * @param {?} element
     * @return {?}
     */
    ViewportService.prototype.observe = /**
     * @param {?} element
     * @return {?}
     */
    function (element) {
        var _this = this;
        this.observer.observe(element);
        return this.callback$.asObservable().pipe(filter((/**
         * @param {?} entry
         * @return {?}
         */
        function (entry) { return entry.target === element; })), finalize((/**
         * @return {?}
         */
        function () { return _this.observer.unobserve(element); })));
    };
    /**
     * @private
     * @param {?} entries
     * @return {?}
     */
    ViewportService.prototype.handler = /**
     * @private
     * @param {?} entries
     * @return {?}
     */
    function (entries) {
        var _this = this;
        entries.forEach((/**
         * @param {?} entry
         * @return {?}
         */
        function (entry) { return _this.callback$.next(entry); }));
    };
    ViewportService.decorators = [
        { type: Injectable, args: [{
                    providedIn: 'root',
                },] }
    ];
    /** @nocollapse */
    ViewportService.ctorParameters = function () { return []; };
    /** @nocollapse */ ViewportService.ngInjectableDef = ɵɵdefineInjectable({ factory: function ViewportService_Factory() { return new ViewportService(); }, token: ViewportService, providedIn: "root" });
    return ViewportService;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var InViewportDirective = /** @class */ (function () {
    function InViewportDirective(elementRef, viewportService, platformId) {
        this.elementRef = elementRef;
        this.viewportService = viewportService;
        this.platformId = platformId;
        this.preRender = true;
        this.oneTime = false;
        this.inViewport = new EventEmitter();
    }
    /**
     * @return {?}
     */
    InViewportDirective.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        var _this = this;
        if (isPlatformBrowser(this.platformId)) {
            if (this.oneTime) {
                this.viewportService
                    .observe(this.elementRef.nativeElement)
                    .pipe(untilDestroy(this), filter((/**
                 * @param {?} entry
                 * @return {?}
                 */
                function (entry) { return entry.intersectionRatio >= 0.5; })), take(1))
                    .subscribe((/**
                 * @param {?} entry
                 * @return {?}
                 */
                function (entry) {
                    _this.inViewport.emit(entry);
                }));
            }
            else {
                this.viewportService
                    .observe(this.elementRef.nativeElement)
                    .pipe(untilDestroy(this))
                    .subscribe((/**
                 * @param {?} entry
                 * @return {?}
                 */
                function (entry) {
                    _this.inViewport.emit(entry);
                }));
            }
        }
        else {
            if (this.preRender) {
                this.inViewport.emit({ isIntersecting: true, intersectionRatio: 1 });
            }
        }
    };
    /**
     * @return {?}
     */
    InViewportDirective.prototype.ngOnDestroy = /**
     * @return {?}
     */
    function () { };
    InViewportDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[inViewport]',
                },] }
    ];
    /** @nocollapse */
    InViewportDirective.ctorParameters = function () { return [
        { type: ElementRef },
        { type: ViewportService },
        { type: Object, decorators: [{ type: Inject, args: [PLATFORM_ID,] }] }
    ]; };
    InViewportDirective.propDecorators = {
        preRender: [{ type: Input }],
        oneTime: [{ type: Input }],
        inViewport: [{ type: Output }]
    };
    return InViewportDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var InViewportModule = /** @class */ (function () {
    function InViewportModule() {
    }
    InViewportModule.decorators = [
        { type: NgModule, args: [{
                    imports: [CommonModule],
                    declarations: [InViewportDirective],
                    exports: [InViewportDirective],
                },] }
    ];
    return InViewportModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ClickOutsideDirective = /** @class */ (function () {
    function ClickOutsideDirective(_elementRef) {
        this._elementRef = _elementRef;
        this.ngxClickOutside = new EventEmitter();
    }
    /**
     * @param {?} event
     * @param {?} targetElement
     * @return {?}
     */
    ClickOutsideDirective.prototype.onClick = /**
     * @param {?} event
     * @param {?} targetElement
     * @return {?}
     */
    function (event, targetElement) {
        if (!targetElement) {
            return;
        }
        /** @type {?} */
        var clickedInside = this._elementRef.nativeElement.contains(targetElement);
        if (!clickedInside) {
            this.ngxClickOutside.emit(event);
        }
    };
    ClickOutsideDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[ngxClickOutside]',
                },] }
    ];
    /** @nocollapse */
    ClickOutsideDirective.ctorParameters = function () { return [
        { type: ElementRef }
    ]; };
    ClickOutsideDirective.propDecorators = {
        ngxClickOutside: [{ type: Output }],
        onClick: [{ type: HostListener, args: ['document:click', ['$event', '$event.target'],] }]
    };
    return ClickOutsideDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ClickOutsideModule = /** @class */ (function () {
    function ClickOutsideModule() {
    }
    ClickOutsideModule.decorators = [
        { type: NgModule, args: [{
                    declarations: [ClickOutsideDirective],
                    imports: [
                        CommonModule
                    ],
                    exports: [ClickOutsideDirective]
                },] }
    ];
    return ClickOutsideModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var MinValidatorDirective = /** @class */ (function () {
    function MinValidatorDirective() {
    }
    /**
     * @param {?} control
     * @return {?}
     */
    MinValidatorDirective.prototype.validate = /**
     * @param {?} control
     * @return {?}
     */
    function (control) {
        return this.min ? Validators.min(this.min)(control) : null;
    };
    MinValidatorDirective.decorators = [
        { type: Directive, args: [{
                    selector: '[appMin],[formControlName],[formControl],[ngModel]',
                    providers: [{ provide: NG_VALIDATORS, useExisting: MinValidatorDirective, multi: true }],
                    exportAs: 'min',
                },] }
    ];
    MinValidatorDirective.propDecorators = {
        min: [{ type: Input }]
    };
    return MinValidatorDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var MinModule = /** @class */ (function () {
    function MinModule() {
    }
    MinModule.decorators = [
        { type: NgModule, args: [{
                    declarations: [MinValidatorDirective],
                    imports: [
                        CommonModule
                    ],
                    exports: [MinValidatorDirective]
                },] }
    ];
    return MinModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
var MASK_FLAGS = ['C', '&', 'a', 'A', '?', 'L', '9', '0', '#'];
/** @type {?} */
var KEYS = {
    Ctrl: 17,
    Z: 90,
    Y: 89,
    X: 88,
    BACKSPACE: 8,
    DELETE: 46
};
var MaskHelper = /** @class */ (function () {
    function MaskHelper() {
    }
    Object.defineProperty(MaskHelper.prototype, "cursor", {
        get: /**
         * @return {?}
         */
        function () {
            return this.cursorPrivate;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @param {?} value
     * @param {?} maskOptions
     * @param {?} cursor
     * @return {?}
     */
    MaskHelper.prototype.parseValueByMask = /**
     * @param {?} value
     * @param {?} maskOptions
     * @param {?} cursor
     * @return {?}
     */
    function (value, maskOptions, cursor) {
        /** @type {?} */
        var inputValue = value;
        /** @type {?} */
        var mask = maskOptions.format;
        /** @type {?} */
        var literals = this.getMaskLiterals(mask);
        /** @type {?} */
        var literalKeys = Array.from(literals.keys());
        /** @type {?} */
        var nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        if (inputValue.length < mask.length) { // BACKSPACE, DELETE
            if (inputValue === '' && cursor === -1) {
                this.cursorPrivate = 0;
                return this.parseValueByMaskOnInit(value, maskOptions);
            } // workaround for IE 'x' button
            if (nonLiteralIndeces.indexOf(cursor + 1) !== -1) {
                inputValue = this.insertCharAt(inputValue, cursor + 1, maskOptions.promptChar);
                this.cursorPrivate = cursor + 1;
            }
            else {
                inputValue = this.insertCharAt(inputValue, cursor + 1, mask[cursor + 1]);
                this.cursorPrivate = cursor + 1;
                for (var i = this.cursorPrivate; i < 0; i--) {
                    if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                        this.cursorPrivate--;
                    }
                    else {
                        break;
                    }
                }
            }
        }
        else {
            /** @type {?} */
            var char = inputValue[cursor];
            /** @type {?} */
            var isCharValid = this.validateCharOnPostion(char, cursor, mask);
            if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                inputValue = this.replaceCharAt(inputValue, cursor, '');
                if (isCharValid) {
                    inputValue = this.replaceCharAt(inputValue, cursor, char);
                    this.cursorPrivate = cursor + 1;
                }
                else {
                    this.cursorPrivate = cursor;
                }
            }
            else {
                inputValue = this.replaceCharAt(inputValue, cursor, '');
                this.cursorPrivate = ++cursor;
                for (var i = cursor; i < mask.length; i++) {
                    if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                        this.cursorPrivate = ++cursor;
                    }
                    else {
                        isCharValid = this.validateCharOnPostion(char, cursor, mask);
                        if (isCharValid) {
                            inputValue = this.replaceCharAt(inputValue, cursor, char);
                            this.cursorPrivate = ++cursor;
                            break;
                        }
                        else {
                            break;
                        }
                    }
                }
            }
        }
        return inputValue;
    };
    /**
     * @param {?} maskOptions
     * @return {?}
     */
    MaskHelper.prototype.parseMask = /**
     * @param {?} maskOptions
     * @return {?}
     */
    function (maskOptions) {
        var _this = this;
        var e_1, _a;
        /** @type {?} */
        var outputVal = '';
        /** @type {?} */
        var mask = maskOptions.format;
        /** @type {?} */
        var literals = this.getMaskLiterals(mask);
        try {
            for (var mask_1 = __values(mask), mask_1_1 = mask_1.next(); !mask_1_1.done; mask_1_1 = mask_1.next()) {
                var maskSym = mask_1_1.value;
                outputVal += maskOptions.promptChar;
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (mask_1_1 && !mask_1_1.done && (_a = mask_1.return)) _a.call(mask_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
        literals.forEach((/**
         * @param {?} val
         * @param {?} key
         * @return {?}
         */
        function (val, key) {
            outputVal = _this.replaceCharAt(outputVal, key, val);
        }));
        return outputVal;
    };
    /**
     * @param {?} inputVal
     * @param {?} maskOptions
     * @return {?}
     */
    MaskHelper.prototype.parseValueByMaskOnInit = /**
     * @param {?} inputVal
     * @param {?} maskOptions
     * @return {?}
     */
    function (inputVal, maskOptions) {
        var _this = this;
        var e_2, _a, e_3, _b;
        /** @type {?} */
        var outputVal = '';
        /** @type {?} */
        var value = '';
        /** @type {?} */
        var mask = maskOptions.format;
        /** @type {?} */
        var literals = this.getMaskLiterals(mask);
        /** @type {?} */
        var literalKeys = Array.from(literals.keys());
        /** @type {?} */
        var nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        /** @type {?} */
        var literalValues = Array.from(literals.values());
        if (inputVal != null) {
            value = inputVal.toString();
        }
        try {
            for (var mask_2 = __values(mask), mask_2_1 = mask_2.next(); !mask_2_1.done; mask_2_1 = mask_2.next()) {
                var maskSym = mask_2_1.value;
                outputVal += maskOptions.promptChar;
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (mask_2_1 && !mask_2_1.done && (_a = mask_2.return)) _a.call(mask_2);
            }
            finally { if (e_2) throw e_2.error; }
        }
        literals.forEach((/**
         * @param {?} val
         * @param {?} key
         * @return {?}
         */
        function (val, key) {
            outputVal = _this.replaceCharAt(outputVal, key, val);
        }));
        if (!value) {
            return outputVal;
        }
        /** @type {?} */
        var nonLiteralValues = this.getNonLiteralValues(value, literalValues);
        for (var i = 0; i < nonLiteralValues.length; i++) {
            /** @type {?} */
            var char = nonLiteralValues[i];
            /** @type {?} */
            var isCharValid = this.validateCharOnPostion(char, nonLiteralIndeces[i], mask);
            if (!isCharValid && char !== maskOptions.promptChar) {
                nonLiteralValues[i] = maskOptions.promptChar;
            }
        }
        if (nonLiteralValues.length > nonLiteralIndeces.length) {
            nonLiteralValues.splice(nonLiteralIndeces.length);
        }
        /** @type {?} */
        var pos = 0;
        try {
            for (var nonLiteralValues_1 = __values(nonLiteralValues), nonLiteralValues_1_1 = nonLiteralValues_1.next(); !nonLiteralValues_1_1.done; nonLiteralValues_1_1 = nonLiteralValues_1.next()) {
                var nonLiteralValue = nonLiteralValues_1_1.value;
                /** @type {?} */
                var char = nonLiteralValue;
                outputVal = this.replaceCharAt(outputVal, nonLiteralIndeces[pos++], char);
            }
        }
        catch (e_3_1) { e_3 = { error: e_3_1 }; }
        finally {
            try {
                if (nonLiteralValues_1_1 && !nonLiteralValues_1_1.done && (_b = nonLiteralValues_1.return)) _b.call(nonLiteralValues_1);
            }
            finally { if (e_3) throw e_3.error; }
        }
        return outputVal;
    };
    /**
     * @param {?} value
     * @param {?} maskOptions
     * @return {?}
     */
    MaskHelper.prototype.restoreValueFromMask = /**
     * @param {?} value
     * @param {?} maskOptions
     * @return {?}
     */
    function (value, maskOptions) {
        var e_4, _a;
        /** @type {?} */
        var outputVal = '';
        /** @type {?} */
        var mask = maskOptions.format;
        /** @type {?} */
        var literals = this.getMaskLiterals(mask);
        /** @type {?} */
        var literalValues = Array.from(literals.values());
        try {
            for (var value_1 = __values(value), value_1_1 = value_1.next(); !value_1_1.done; value_1_1 = value_1.next()) {
                var val = value_1_1.value;
                if (literalValues.indexOf(val) === -1) {
                    if (val !== maskOptions.promptChar) {
                        outputVal += val;
                    }
                }
            }
        }
        catch (e_4_1) { e_4 = { error: e_4_1 }; }
        finally {
            try {
                if (value_1_1 && !value_1_1.done && (_a = value_1.return)) _a.call(value_1);
            }
            finally { if (e_4) throw e_4.error; }
        }
        return outputVal;
    };
    /**
     * @param {?} value
     * @param {?} maskOptions
     * @param {?} cursor
     * @param {?} selection
     * @return {?}
     */
    MaskHelper.prototype.parseValueByMaskUponSelection = /**
     * @param {?} value
     * @param {?} maskOptions
     * @param {?} cursor
     * @param {?} selection
     * @return {?}
     */
    function (value, maskOptions, cursor, selection) {
        /** @type {?} */
        var isCharValid;
        /** @type {?} */
        var inputValue = value;
        /** @type {?} */
        var char = inputValue[cursor];
        /** @type {?} */
        var mask = maskOptions.format;
        /** @type {?} */
        var literals = this.getMaskLiterals(mask);
        /** @type {?} */
        var literalKeys = Array.from(literals.keys());
        /** @type {?} */
        var nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        if (!this.data) {
            this.cursorPrivate = cursor < 0 ? ++cursor : cursor;
            if (nonLiteralIndeces.indexOf(this.cursorPrivate) !== -1) {
                isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                inputValue = isCharValid ? this.replaceCharAt(inputValue, this.cursorPrivate++, char) :
                    inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, maskOptions.promptChar);
                selection--;
                if (selection > 0) {
                    for (var i = 0; i < selection; i++) {
                        cursor++;
                        inputValue = nonLiteralIndeces.indexOf(cursor) !== -1 ?
                            this.insertCharAt(inputValue, cursor, maskOptions.promptChar) :
                            this.insertCharAt(inputValue, cursor, mask[cursor]);
                    }
                }
            }
            else {
                inputValue = this.replaceCharAt(inputValue, this.cursorPrivate, mask[this.cursorPrivate]);
                this.cursorPrivate++;
                selection--;
                /** @type {?} */
                var isMarked = false;
                if (selection > 0) {
                    cursor = this.cursorPrivate;
                    for (var i = 0; i < selection; i++) {
                        if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                            isCharValid = this.validateCharOnPostion(char, cursor, mask);
                            if (isCharValid && !isMarked) {
                                inputValue = this.insertCharAt(inputValue, cursor, char);
                                cursor++;
                                this.cursorPrivate++;
                                isMarked = true;
                            }
                            else {
                                inputValue = this.insertCharAt(inputValue, cursor, maskOptions.promptChar);
                                cursor++;
                            }
                        }
                        else {
                            inputValue = this.insertCharAt(inputValue, cursor, mask[cursor]);
                            if (cursor === this.cursorPrivate) {
                                this.cursorPrivate++;
                            }
                            cursor++;
                        }
                    }
                }
            }
        }
        else {
            if (inputValue === '' && cursor === -1) {
                this.cursorPrivate = 0;
                return this.parseValueByMaskOnInit(value, maskOptions);
            } // workaround for IE 'x' button
            if (this.cursorPrivate < 0) {
                this.cursorPrivate++;
                cursor++;
            }
            cursor++;
            this.cursorPrivate = cursor;
            for (var i = 0; i < selection; i++) {
                if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                    inputValue = this.insertCharAt(inputValue, cursor, maskOptions.promptChar);
                    cursor++;
                }
                else {
                    inputValue = this.insertCharAt(inputValue, cursor, mask[cursor]);
                    cursor++;
                }
            }
        }
        return inputValue;
    };
    /**
     * @param {?} value
     * @param {?} maskOptions
     * @param {?} cursor
     * @param {?} clipboardData
     * @param {?} selection
     * @return {?}
     */
    MaskHelper.prototype.parseValueByMaskUponCopyPaste = /**
     * @param {?} value
     * @param {?} maskOptions
     * @param {?} cursor
     * @param {?} clipboardData
     * @param {?} selection
     * @return {?}
     */
    function (value, maskOptions, cursor, clipboardData, selection) {
        var e_5, _a;
        /** @type {?} */
        var inputValue = value;
        /** @type {?} */
        var mask = maskOptions.format;
        /** @type {?} */
        var literals = this.getMaskLiterals(mask);
        /** @type {?} */
        var literalKeys = Array.from(literals.keys());
        /** @type {?} */
        var nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        /** @type {?} */
        var selectionEnd = cursor + selection;
        this.cursorPrivate = cursor;
        try {
            for (var clipboardData_1 = __values(clipboardData), clipboardData_1_1 = clipboardData_1.next(); !clipboardData_1_1.done; clipboardData_1_1 = clipboardData_1.next()) {
                var clipboardSym = clipboardData_1_1.value;
                /** @type {?} */
                var char = clipboardSym;
                if (this.cursorPrivate > mask.length) {
                    return inputValue;
                }
                if (nonLiteralIndeces.indexOf(this.cursorPrivate) !== -1) {
                    /** @type {?} */
                    var isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                    if (isCharValid) {
                        inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, char);
                    }
                }
                else {
                    for (var i = cursor; i < mask.length; i++) {
                        if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                            this.cursorPrivate++;
                        }
                        else {
                            /** @type {?} */
                            var isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                            if (isCharValid) {
                                inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, char);
                            }
                            break;
                        }
                    }
                }
                selection--;
            }
        }
        catch (e_5_1) { e_5 = { error: e_5_1 }; }
        finally {
            try {
                if (clipboardData_1_1 && !clipboardData_1_1.done && (_a = clipboardData_1.return)) _a.call(clipboardData_1);
            }
            finally { if (e_5) throw e_5.error; }
        }
        if (selection > 0) {
            for (var i = this.cursorPrivate; i < selectionEnd; i++) {
                if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                    this.cursorPrivate++;
                }
                else {
                    inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, maskOptions.promptChar);
                }
            }
        }
        return inputValue;
    };
    /**
     * @private
     * @param {?} inputChar
     * @param {?} position
     * @param {?} mask
     * @return {?}
     */
    MaskHelper.prototype.validateCharOnPostion = /**
     * @private
     * @param {?} inputChar
     * @param {?} position
     * @param {?} mask
     * @return {?}
     */
    function (inputChar, position, mask) {
        /** @type {?} */
        var regex;
        /** @type {?} */
        var isValid;
        /** @type {?} */
        var letterOrDigitRegEx = '[\\d\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z]';
        /** @type {?} */
        var letterDigitOrSpaceRegEx = '[\\d\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z\\u0020]';
        /** @type {?} */
        var letterRegEx = '[\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z]';
        /** @type {?} */
        var letteSpaceRegEx = '[\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z\\u0020]';
        /** @type {?} */
        var digitRegEx = '[\\d]';
        /** @type {?} */
        var digitSpaceRegEx = '[\\d\\u0020]';
        /** @type {?} */
        var digitSpecialRegEx = '[\\d-\\+]';
        switch (mask.charAt(position)) {
            case 'C':
                isValid = inputChar !== '';
                break;
            case '&':
                regex = new RegExp('[\\u0020]');
                isValid = !regex.test(inputChar);
                break;
            case 'a':
                regex = new RegExp(letterDigitOrSpaceRegEx);
                isValid = regex.test(inputChar);
                break;
            case 'A':
                regex = new RegExp(letterOrDigitRegEx);
                isValid = regex.test(inputChar);
                break;
            case '?':
                regex = new RegExp(letteSpaceRegEx);
                isValid = regex.test(inputChar);
                break;
            case 'L':
                regex = new RegExp(letterRegEx);
                isValid = regex.test(inputChar);
                break;
            case '0':
                regex = new RegExp(digitRegEx);
                isValid = regex.test(inputChar);
                break;
            case '9':
                regex = new RegExp(digitSpaceRegEx);
                isValid = regex.test(inputChar);
                break;
            case '#':
                regex = new RegExp(digitSpecialRegEx);
                isValid = regex.test(inputChar);
                break;
            default: {
                isValid = null;
            }
        }
        return isValid;
    };
    /**
     * @private
     * @param {?} strValue
     * @param {?} index
     * @param {?} char
     * @return {?}
     */
    MaskHelper.prototype.replaceCharAt = /**
     * @private
     * @param {?} strValue
     * @param {?} index
     * @param {?} char
     * @return {?}
     */
    function (strValue, index, char) {
        if (strValue !== undefined) {
            return strValue.substring(0, index) + char + strValue.substring(index + 1);
        }
    };
    /**
     * @private
     * @param {?} strValue
     * @param {?} index
     * @param {?} char
     * @return {?}
     */
    MaskHelper.prototype.insertCharAt = /**
     * @private
     * @param {?} strValue
     * @param {?} index
     * @param {?} char
     * @return {?}
     */
    function (strValue, index, char) {
        if (strValue !== undefined) {
            return strValue.substring(0, index) + char + strValue.substring(index);
        }
    };
    /**
     * @private
     * @param {?} mask
     * @return {?}
     */
    MaskHelper.prototype.getMaskLiterals = /**
     * @private
     * @param {?} mask
     * @return {?}
     */
    function (mask) {
        /** @type {?} */
        var literals = new Map();
        for (var i = 0; i < mask.length; i++) {
            /** @type {?} */
            var char = mask.charAt(i);
            if (MASK_FLAGS.indexOf(char) === -1) {
                literals.set(i, char);
            }
        }
        return literals;
    };
    /**
     * @private
     * @param {?} mask
     * @param {?} literalKeys
     * @return {?}
     */
    MaskHelper.prototype.getNonLiteralIndeces = /**
     * @private
     * @param {?} mask
     * @param {?} literalKeys
     * @return {?}
     */
    function (mask, literalKeys) {
        /** @type {?} */
        var nonLiteralsIndeces = new Array();
        for (var i = 0; i < mask.length; i++) {
            if (literalKeys.indexOf(i) === -1) {
                nonLiteralsIndeces.push(i);
            }
        }
        return nonLiteralsIndeces;
    };
    /**
     * @private
     * @param {?} value
     * @param {?} literalValues
     * @return {?}
     */
    MaskHelper.prototype.getNonLiteralValues = /**
     * @private
     * @param {?} value
     * @param {?} literalValues
     * @return {?}
     */
    function (value, literalValues) {
        var e_6, _a;
        /** @type {?} */
        var nonLiteralValues = new Array();
        try {
            for (var value_2 = __values(value), value_2_1 = value_2.next(); !value_2_1.done; value_2_1 = value_2.next()) {
                var val = value_2_1.value;
                if (literalValues.indexOf(val) === -1) {
                    nonLiteralValues.push(val);
                }
            }
        }
        catch (e_6_1) { e_6 = { error: e_6_1 }; }
        finally {
            try {
                if (value_2_1 && !value_2_1.done && (_a = value_2.return)) _a.call(value_2);
            }
            finally { if (e_6) throw e_6.error; }
        }
        return nonLiteralValues;
    };
    return MaskHelper;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @return {?}
 */
function isIE() {
    return navigator.appVersion.indexOf('Trident/') > 0;
}
/** @type {?} */
var noop = (/**
 * @return {?}
 */
function () { });
var MaskDirective = /** @class */ (function () {
    function MaskDirective(elementRef) {
        this.elementRef = elementRef;
        this.onValueChange = new EventEmitter();
        this.maskOptions = {
            format: '',
            promptChar: '',
        };
        this.onTouchedCallback = noop;
        this.onChangeCallback = noop;
        this.maskHelper = new MaskHelper();
    }
    Object.defineProperty(MaskDirective.prototype, "value", {
        get: /**
         * @private
         * @return {?}
         */
        function () {
            return this.nativeElement.value;
        },
        set: /**
         * @private
         * @param {?} val
         * @return {?}
         */
        function (val) {
            this.nativeElement.value = val;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MaskDirective.prototype, "nativeElement", {
        get: /**
         * @private
         * @return {?}
         */
        function () {
            return this.elementRef.nativeElement;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MaskDirective.prototype, "selectionStart", {
        get: /**
         * @private
         * @return {?}
         */
        function () {
            return this.nativeElement.selectionStart;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MaskDirective.prototype, "selectionEnd", {
        get: /**
         * @private
         * @return {?}
         */
        function () {
            return this.nativeElement.selectionEnd;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    MaskDirective.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        if (this.promptChar && this.promptChar.length > 1) {
            this.maskOptions.promptChar = this.promptChar = this.promptChar.substring(0, 1);
        }
        this.maskOptions.format = this.mask ? this.mask : 'CCCCCCCCCC';
        this.maskOptions.promptChar = this.promptChar ? this.promptChar : '_';
        this.nativeElement.setAttribute('placeholder', this.placeholder ? this.placeholder : this.maskOptions.format);
    };
    /**
     * @param {?} event
     * @return {?}
     */
    MaskDirective.prototype.onKeydown = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        /** @type {?} */
        var key = event.keyCode || event.charCode;
        if (isIE() && this.stopPropagation) {
            this.stopPropagation = false;
        }
        if (key === KEYS.Ctrl) {
            this.ctrlDown = true;
        }
        if ((this.ctrlDown && key === KEYS.Z) || (this.ctrlDown && key === KEYS.Y)) {
            event.preventDefault();
        }
        this.key = key;
        this.selection = Math.abs(this.selectionEnd - this.selectionStart);
    };
    /**
     * @param {?} event
     * @return {?}
     */
    MaskDirective.prototype.onKeyup = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        /** @type {?} */
        var key = event.keyCode || event.charCode;
        if (key === KEYS.Ctrl) {
            this.ctrlDown = false;
        }
    };
    /**
     * @param {?} event
     * @return {?}
     */
    MaskDirective.prototype.onPaste = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        this.paste = true;
        this.valOnPaste = this.value;
        this.cursorOnPaste = this.getCursorPosition();
    };
    /**
     * @param {?} event
     * @return {?}
     */
    MaskDirective.prototype.onInputChanged = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        if (isIE() && this.stopPropagation) {
            this.stopPropagation = false;
            return;
        }
        if (this.paste) {
            this.paste = false;
            /** @type {?} */
            var clipboardData = this.value.substring(this.cursorOnPaste, this.getCursorPosition());
            this.value = this.maskHelper.parseValueByMaskUponCopyPaste(this.valOnPaste, this.maskOptions, this.cursorOnPaste, clipboardData, this.selection);
            this.setCursorPosition(this.maskHelper.cursor);
        }
        else {
            /** @type {?} */
            var currentCursorPos = this.getCursorPosition();
            this.maskHelper.data = this.key === KEYS.BACKSPACE || this.key === KEYS.DELETE;
            this.value =
                this.selection && this.selection !== 0
                    ? this.maskHelper.parseValueByMaskUponSelection(this.value, this.maskOptions, currentCursorPos - 1, this.selection)
                    : this.maskHelper.parseValueByMask(this.value, this.maskOptions, currentCursorPos - 1);
            this.setCursorPosition(this.maskHelper.cursor);
        }
        /** @type {?} */
        var rawVal = this.maskHelper.restoreValueFromMask(this.value, this.maskOptions);
        this.dataValue = this.includeLiterals ? this.value : rawVal;
        this.onChangeCallback(this.dataValue);
        this.onValueChange.emit({ rawValue: rawVal, formattedValue: this.value });
    };
    /**
     * @param {?} value
     * @return {?}
     */
    MaskDirective.prototype.onFocus = /**
     * @param {?} value
     * @return {?}
     */
    function (value) {
        if (this.focusedValuePipe) {
            if (isIE()) {
                this.stopPropagation = true;
            }
            this.value = this.focusedValuePipe.transform(value);
        }
        else {
            this.value = this.maskHelper.parseValueByMaskOnInit(this.value, this.maskOptions);
        }
    };
    /**
     * @param {?} value
     * @return {?}
     */
    MaskDirective.prototype.onBlur = /**
     * @param {?} value
     * @return {?}
     */
    function (value) {
        if (this.displayValuePipe) {
            this.value = this.displayValuePipe.transform(value);
        }
        else if (value === this.maskHelper.parseMask(this.maskOptions)) {
            this.value = '';
        }
    };
    /**
     * @private
     * @return {?}
     */
    MaskDirective.prototype.getCursorPosition = /**
     * @private
     * @return {?}
     */
    function () {
        return this.nativeElement.selectionStart;
    };
    /**
     * @private
     * @param {?} start
     * @param {?=} end
     * @return {?}
     */
    MaskDirective.prototype.setCursorPosition = /**
     * @private
     * @param {?} start
     * @param {?=} end
     * @return {?}
     */
    function (start, end) {
        if (end === void 0) { end = start; }
        this.nativeElement.setSelectionRange(start, end);
    };
    /**
     * @param {?} value
     * @return {?}
     */
    MaskDirective.prototype.writeValue = /**
     * @param {?} value
     * @return {?}
     */
    function (value) {
        if (this.promptChar && this.promptChar.length > 1) {
            this.maskOptions.promptChar = this.promptChar.substring(0, 1);
        }
        this.value = value ? this.maskHelper.parseValueByMaskOnInit(value, this.maskOptions) : '';
        if (this.displayValuePipe) {
            this.value = this.displayValuePipe.transform(this.value);
        }
        this.dataValue = this.includeLiterals ? this.value : value;
        this.onChangeCallback(this.dataValue);
        this.onValueChange.emit({ rawValue: value, formattedValue: this.value });
    };
    /**
     * @param {?} fn
     * @return {?}
     */
    MaskDirective.prototype.registerOnChange = /**
     * @param {?} fn
     * @return {?}
     */
    function (fn) {
        this.onChangeCallback = fn;
    };
    /**
     * @param {?} fn
     * @return {?}
     */
    MaskDirective.prototype.registerOnTouched = /**
     * @param {?} fn
     * @return {?}
     */
    function (fn) {
        this.onTouchedCallback = fn;
    };
    MaskDirective.decorators = [
        { type: Directive, args: [{
                    providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: MaskDirective, multi: true }],
                    selector: '[ngxMask]',
                },] }
    ];
    /** @nocollapse */
    MaskDirective.ctorParameters = function () { return [
        { type: ElementRef }
    ]; };
    MaskDirective.propDecorators = {
        mask: [{ type: Input, args: ['ngxMask',] }],
        promptChar: [{ type: Input }],
        includeLiterals: [{ type: Input }],
        placeholder: [{ type: Input }],
        displayValuePipe: [{ type: Input }],
        focusedValuePipe: [{ type: Input }],
        dataValue: [{ type: Input }],
        onValueChange: [{ type: Output }],
        onKeydown: [{ type: HostListener, args: ['keydown', ['$event'],] }],
        onKeyup: [{ type: HostListener, args: ['keyup', ['$event'],] }],
        onPaste: [{ type: HostListener, args: ['paste', ['$event'],] }],
        onInputChanged: [{ type: HostListener, args: ['input', ['$event'],] }],
        onFocus: [{ type: HostListener, args: ['focus', ['$event.target.value'],] }],
        onBlur: [{ type: HostListener, args: ['blur', ['$event.target.value'],] }]
    };
    return MaskDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var MaskModule = /** @class */ (function () {
    function MaskModule() {
    }
    MaskModule.decorators = [
        { type: NgModule, args: [{
                    declarations: [MaskDirective],
                    imports: [
                        CommonModule
                    ],
                    exports: [MaskDirective]
                },] }
    ];
    return MaskModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var FilterPipe = /** @class */ (function () {
    function FilterPipe() {
    }
    /**
     * @param {?} itemList
     * @param {?=} filterTerm
     * @param {?=} filterBy
     * @return {?}
     */
    FilterPipe.prototype.transform = /**
     * @param {?} itemList
     * @param {?=} filterTerm
     * @param {?=} filterBy
     * @return {?}
     */
    function (itemList, filterTerm, filterBy) {
        if (!filterBy) {
            return itemList;
        }
        if (filterTerm === '') {
            return itemList;
        }
        filterBy = filterBy.toString();
        return itemList.filter((/**
         * @param {?} item
         * @return {?}
         */
        function (item) {
            if (item[filterBy]) {
                return item[filterBy]
                    .toString()
                    .toLowerCase()
                    .includes(filterTerm.toLowerCase());
            }
        }));
    };
    FilterPipe.decorators = [
        { type: Pipe, args: [{ name: 'filter' },] }
    ];
    return FilterPipe;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * <ul>
 *   <li *ngFor="let object of myArray | groupBy:'color'"></li>
 * </ul>
 * @template T
 */
var GroupByPipe = /** @class */ (function () {
    function GroupByPipe() {
    }
    /**
     * @param {?} collection
     * @param {?} property
     * @return {?}
     */
    GroupByPipe.prototype.transform = /**
     * @param {?} collection
     * @param {?} property
     * @return {?}
     */
    function (collection, property) {
        // prevents the application from breaking if the array of objects doesn't exist yet
        if (!collection) {
            return null;
        }
        /** @type {?} */
        var groupedCollection = collection.reduce((/**
         * @param {?} previous
         * @param {?} current
         * @return {?}
         */
        function (previous, current) {
            if (!previous[current[property]]) {
                previous[current[property]] = [current];
            }
            else {
                previous[current[property]].push(current);
            }
            return previous;
        }), {});
        // this will return an array of objects, each object containing a group of objects
        return Object.keys(groupedCollection).map((/**
         * @param {?} key
         * @return {?}
         */
        function (key) { return ({
            key: key,
            value: groupedCollection[key],
        }); }));
    };
    GroupByPipe.decorators = [
        { type: Pipe, args: [{ name: 'groupBy' },] }
    ];
    return GroupByPipe;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var SafeHtmlPipe = /** @class */ (function () {
    function SafeHtmlPipe(sanitizer) {
        this.sanitizer = sanitizer;
    }
    /**
     * @param {?} value
     * @param {?=} args
     * @return {?}
     */
    SafeHtmlPipe.prototype.transform = /**
     * @param {?} value
     * @param {?=} args
     * @return {?}
     */
    function (value, args) {
        return this.sanitizer.bypassSecurityTrustHtml(value);
    };
    SafeHtmlPipe.decorators = [
        { type: Pipe, args: [{ name: 'safeHtml' },] }
    ];
    /** @nocollapse */
    SafeHtmlPipe.ctorParameters = function () { return [
        { type: DomSanitizer }
    ]; };
    return SafeHtmlPipe;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var HelperModule = /** @class */ (function () {
    function HelperModule() {
    }
    HelperModule.decorators = [
        { type: NgModule, args: [{
                    imports: [CommonModule],
                    declarations: [FilterPipe, GroupByPipe, SafeHtmlPipe],
                    exports: [FilterPipe, GroupByPipe, SafeHtmlPipe],
                },] }
    ];
    return HelperModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var CharactersPipe = /** @class */ (function () {
    function CharactersPipe() {
    }
    /**
     * @param {?} value
     * @param {?=} limit
     * @param {?=} trail
     * @return {?}
     */
    CharactersPipe.prototype.transform = /**
     * @param {?} value
     * @param {?=} limit
     * @param {?=} trail
     * @return {?}
     */
    function (value, limit, trail) {
        if (limit === void 0) { limit = 40; }
        if (trail === void 0) { trail = '…'; }
        if (!value) {
            value = '';
        }
        if (limit < 0) {
            limit *= -1;
            return value.length > limit ? trail + value.substring(value.length - limit, value.length) : value;
        }
        else {
            return value.length > limit ? value.substring(0, limit) + trail : value;
        }
    };
    CharactersPipe.decorators = [
        { type: Pipe, args: [{
                    pure: true,
                    name: 'characters',
                },] }
    ];
    return CharactersPipe;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var WordsPipe = /** @class */ (function () {
    function WordsPipe() {
    }
    /**
     * @param {?} value
     * @param {?=} limit
     * @param {?=} trail
     * @return {?}
     */
    WordsPipe.prototype.transform = /**
     * @param {?} value
     * @param {?=} limit
     * @param {?=} trail
     * @return {?}
     */
    function (value, limit, trail) {
        if (limit === void 0) { limit = 40; }
        if (trail === void 0) { trail = '…'; }
        /** @type {?} */
        var result = value || '';
        if (value) {
            /** @type {?} */
            var words = value.split(/\s+/);
            if (words.length > Math.abs(limit)) {
                if (limit < 0) {
                    limit *= -1;
                    result = trail + words.slice(words.length - limit, words.length).join(' ');
                }
                else {
                    result = words.slice(0, limit).join(' ') + trail;
                }
            }
        }
        return result;
    };
    WordsPipe.decorators = [
        { type: Pipe, args: [{
                    pure: true,
                    name: 'words',
                },] }
    ];
    return WordsPipe;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TruncateModule = /** @class */ (function () {
    function TruncateModule() {
    }
    TruncateModule.decorators = [
        { type: NgModule, args: [{
                    imports: [CommonModule],
                    declarations: [CharactersPipe, WordsPipe],
                    exports: [CharactersPipe, WordsPipe],
                },] }
    ];
    return TruncateModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
var defaultConfig = { addSuffix: true };
/**
 * impure pipe, which in general can lead to bad performance
 * but the backoff function limits the frequency the pipe checks for updates
 * so the performance is close to that of a pure pipe
 * the downside of this is that if you change the value of the input, the pipe might not notice for a while
 * so this pipe is intended for static data
 *
 * expected input is a time (number, string or Date)
 * output is a string expressing distance from that time to now, plus the suffix 'ago'
 * output refreshes at dynamic intervals, with refresh rate slowing down as the input time gets further away from now
 */
var FormatTimeInWordsPipe = /** @class */ (function () {
    function FormatTimeInWordsPipe(cdr) {
        this.cdr = cdr;
        this.isDestroyed = false;
        this.async = new AsyncPipe(this.cdr);
    }
    /**
     * @return {?}
     */
    FormatTimeInWordsPipe.prototype.ngOnDestroy = /**
     * @return {?}
     */
    function () {
        this.isDestroyed = true; // pipe will stop executing after next iteration
    };
    /**
     * @param {?} date
     * @param {?=} options
     * @return {?}
     */
    FormatTimeInWordsPipe.prototype.transform = /**
     * @param {?} date
     * @param {?=} options
     * @return {?}
     */
    function (date, options) {
        if (date == null) {
            throw new Error(FormatTimeInWordsPipe.NO_ARGS_ERROR);
        }
        // set the pipe to the Observable if not yet done, and return an async pipe
        if (!this.agoExpression) {
            this.agoExpression = this.timeAgo(date, __assign({}, defaultConfig, options));
        }
        return this.async.transform(this.agoExpression);
    };
    /**
     * @private
     * @param {?} date
     * @param {?=} options
     * @return {?}
     */
    FormatTimeInWordsPipe.prototype.timeAgo = /**
     * @private
     * @param {?} date
     * @param {?=} options
     * @return {?}
     */
    function (date, options) {
        var _this = this;
        /** @type {?} */
        var nextBackoff = this.backoff(date);
        return of(true).pipe(
        // will not recheck input until delay completes
        repeatWhen((/**
         * @param {?} notify
         * @return {?}
         */
        function (notify) { return notify.pipe(delayWhen((/**
         * @return {?}
         */
        function () { return interval(nextBackoff); }))); })), takeWhile((/**
         * @param {?} _
         * @return {?}
         */
        function (_) { return !_this.isDestroyed; })), map((/**
         * @param {?} _
         * @return {?}
         */
        function (_) { return formatDistance(_this.stringToDate(date), new Date(), options); })), tap((/**
         * @param {?} _
         * @return {?}
         */
        function (_) { return (nextBackoff = _this.backoff(date)); })));
    };
    /**
     * @private
     * @param {?} date
     * @return {?}
     */
    FormatTimeInWordsPipe.prototype.backoff = /**
     * @private
     * @param {?} date
     * @return {?}
     */
    function (date) {
        /** @type {?} */
        var minutesElapsed = Math.abs(differenceInMinutes(new Date(), this.stringToDate(date)));
        // this will always be positive
        /** @type {?} */
        var backoffAmountInSeconds;
        if (minutesElapsed < 2) {
            backoffAmountInSeconds = 5;
        }
        else if (minutesElapsed >= 2 && minutesElapsed < 5) {
            backoffAmountInSeconds = 15;
        }
        else if (minutesElapsed >= 5 && minutesElapsed < 60) {
            backoffAmountInSeconds = 30;
        }
        else if (minutesElapsed >= 60) {
            backoffAmountInSeconds = 300; // 5 minutes
        }
        return backoffAmountInSeconds * 1000; // return an amount of milliseconds
    };
    /**
     * @private
     * @param {?} date
     * @return {?}
     */
    FormatTimeInWordsPipe.prototype.stringToDate = /**
     * @private
     * @param {?} date
     * @return {?}
     */
    function (date) {
        /** @type {?} */
        var isString = (/**
         * @param {?} s
         * @return {?}
         */
        function (s) { return typeof (s) === 'string' || s instanceof String; });
        return isString(date) ? parseISO(date) : date;
    };
    FormatTimeInWordsPipe.NO_ARGS_ERROR = 'formatTimeInWords: missing required arguments';
    FormatTimeInWordsPipe.decorators = [
        { type: Pipe, args: [{ name: 'formatTimeInWords', pure: false },] }
    ];
    /** @nocollapse */
    FormatTimeInWordsPipe.ctorParameters = function () { return [
        { type: ChangeDetectorRef }
    ]; };
    return FormatTimeInWordsPipe;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
var PIPES = [FormatTimeInWordsPipe];
var DateFnsModule = /** @class */ (function () {
    function DateFnsModule() {
    }
    DateFnsModule.decorators = [
        { type: NgModule, args: [{
                    declarations: [PIPES],
                    imports: [CommonModule],
                    exports: [PIPES],
                },] }
    ];
    return DateFnsModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { ClickOutsideModule, DateFnsModule, HelperModule, InViewportModule, MaskModule, MinModule, NgLetModule, RouterLinkMatchModule, TruncateModule, ViewportService, pluck, untilDestroy, NgLetContext as ɵa, NgLetDirective as ɵb, RouterLinkMatchDirective as ɵc, InViewportDirective as ɵd, destroy$ as ɵdestroy$, ClickOutsideDirective as ɵe, MinValidatorDirective as ɵf, MaskDirective as ɵg, FilterPipe as ɵh, GroupByPipe as ɵi, SafeHtmlPipe as ɵj, CharactersPipe as ɵk, WordsPipe as ɵl, FormatTimeInWordsPipe as ɵm };
//# sourceMappingURL=vibe-ngx-utils.js.map
