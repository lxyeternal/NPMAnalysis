import { Directive, ViewContainerRef, TemplateRef, Input, NgModule, Renderer2, ElementRef, Injectable, ɵɵdefineInjectable, EventEmitter, Inject, PLATFORM_ID, Output, HostListener, Pipe, ChangeDetectorRef } from '@angular/core';
import { CommonModule, isPlatformBrowser, AsyncPipe } from '@angular/common';
import { NavigationEnd, Router } from '@angular/router';
import { Observable, Subject, combineLatest, of, interval } from 'rxjs';
import { takeUntil, pluck as pluck$1, map, filter, finalize, take, repeatWhen, delayWhen, takeWhile, tap } from 'rxjs/operators';
import { Validators, NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { formatDistance, differenceInMinutes, parseISO } from 'date-fns/esm';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgLetContext {
    constructor() {
        this.$implicit = null;
        this.ngLet = null;
    }
}
class NgLetDirective {
    /**
     * @param {?} _vcr
     * @param {?} _templateRef
     */
    constructor(_vcr, _templateRef) {
        this._vcr = _vcr;
        this._templateRef = _templateRef;
        this._context = new NgLetContext();
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set ngLet(value) {
        this._context.$implicit = this._context.ngLet = value;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this._vcr.createEmbeddedView(this._templateRef, this._context);
    }
}
NgLetDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ngLet]',
            },] }
];
/** @nocollapse */
NgLetDirective.ctorParameters = () => [
    { type: ViewContainerRef },
    { type: TemplateRef }
];
NgLetDirective.propDecorators = {
    ngLet: [{ type: Input }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgLetModule {
}
NgLetModule.decorators = [
    { type: NgModule, args: [{
                imports: [CommonModule],
                declarations: [NgLetDirective],
                exports: [NgLetDirective],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
// create a symbol identify the observable I add to
// the component so it doesn't conflict with anything.
// I need this so I'm able to add the desired behaviour to the component.
/** @type {?} */
const destroy$ = Symbol('destroy$');
/**
 * An operator that takes until destroy it takes a components this a parameter
 * returns a pipeable RxJS operator.
 * @type {?}
 */
const untilDestroy = (/**
 * @template T
 * @param {?} component
 * @return {?}
 */
(component) => {
    if (component[destroy$] === undefined) {
        // only hookup each component once.
        addDestroyObservableToComponent(component);
    }
    // pipe in the takeUntil destroy$ and return the source unaltered
    return takeUntil(component[destroy$]);
});
/**
 * \@internal
 * @param {?} component
 * @return {?}
 */
function addDestroyObservableToComponent(component) {
    component[destroy$] = new Observable((/**
     * @param {?} observer
     * @return {?}
     */
    observer => {
        // keep track of the original destroy function,
        // the user might do something in there
        /** @type {?} */
        const orignalDestroy = component.ngOnDestroy;
        if (orignalDestroy == null) {
            // Angular does not support dynamic added destroy methods
            // so make sure there is one.
            throw new Error('untilDestroy operator needs the component to have an ngOnDestroy method');
        }
        // replace the ngOndestroy
        component.ngOnDestroy = (/**
         * @return {?}
         */
        () => {
            // fire off the destroy observable
            observer.next();
            // complete the observable
            observer.complete();
            // and at last, call the original destroy
            orignalDestroy.call(component);
        });
        // return cleanup function.
        return (/**
         * @param {?} _
         * @return {?}
         */
        (_) => (component[destroy$] = undefined));
    }));
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @template T, V
 * @param {...?} props
 * @return {?}
 */
function pluck(...props) {
    return pluck$1(...props);
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class RouterLinkMatchDirective {
    /**
     * @param {?} router
     * @param {?} _renderer
     * @param {?} _ngEl
     */
    constructor(router, _renderer, _ngEl) {
        this._renderer = _renderer;
        this._ngEl = _ngEl;
        this._onChangesHook = new Subject();
        combineLatest(router.events, this._onChangesHook)
            .pipe(map((/**
         * @param {?} __0
         * @return {?}
         */
        ([e]) => e)), filter((/**
         * @param {?} e
         * @return {?}
         */
        e => e instanceof NavigationEnd)), untilDestroy(this))
            .subscribe((/**
         * @param {?} e
         * @return {?}
         */
        e => {
            this._curRoute = ((/** @type {?} */ (e))).urlAfterRedirects;
            this._updateClass(this._matchExp);
        }));
    }
    /**
     * @param {?} v
     * @return {?}
     */
    set routerLinkMatch(v) {
        if (v && typeof v === 'object') {
            this._matchExp = v;
        }
        else {
            throw new TypeError(`Unexpected type '${typeof v}' of value for ` + `input of routerLinkMatch directive, expected 'object'`);
        }
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes['routerLinkMatch']) {
            this._onChangesHook.next(changes['routerLinkMatch'].currentValue);
        }
    }
    /**
     * @private
     * @param {?} v
     * @return {?}
     */
    _updateClass(v) {
        Object.keys(v).forEach((/**
         * @param {?} cls
         * @return {?}
         */
        cls => {
            if (v[cls] && typeof v[cls] === 'string') {
                /** @type {?} */
                const regexp = new RegExp(v[cls]);
                if (this._curRoute.match(regexp)) {
                    this._toggleClass(cls, true);
                }
                else {
                    this._toggleClass(cls, false);
                }
            }
            else {
                throw new TypeError(`Could not convert match value to Regular Expression. ` +
                    `Unexpected type '${typeof v[cls]}' for value of key '${cls}' ` +
                    `in routerLinkMatch directive match expression, expected 'non-empty string'`);
            }
        }));
    }
    /**
     * @private
     * @param {?} classes
     * @param {?} enabled
     * @return {?}
     */
    _toggleClass(classes, enabled) {
        classes = classes.trim();
        classes.split(/\s+/g).forEach((/**
         * @param {?} cls
         * @return {?}
         */
        cls => {
            if (enabled) {
                this._renderer.addClass(this._ngEl.nativeElement, cls);
            }
            else {
                this._renderer.removeClass(this._ngEl.nativeElement, cls);
            }
        }));
    }
    /**
     * @return {?}
     */
    ngOnDestroy() { }
}
RouterLinkMatchDirective.decorators = [
    { type: Directive, args: [{
                selector: '[routerLinkMatch]',
            },] }
];
/** @nocollapse */
RouterLinkMatchDirective.ctorParameters = () => [
    { type: Router },
    { type: Renderer2 },
    { type: ElementRef }
];
RouterLinkMatchDirective.propDecorators = {
    routerLinkMatch: [{ type: Input, args: ['routerLinkMatch',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class RouterLinkMatchModule {
}
RouterLinkMatchModule.decorators = [
    { type: NgModule, args: [{
                imports: [CommonModule],
                declarations: [RouterLinkMatchDirective],
                exports: [RouterLinkMatchDirective],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class ViewportService {
    constructor() {
        this.options = {
            rootMargin: '0px 0px 0px 0px',
            threshold: [0.5],
        };
        this.callback$ = new Subject();
        this.observer = new IntersectionObserver(this.handler.bind(this), this.options);
    }
    /**
     * @param {?} element
     * @return {?}
     */
    observe(element) {
        this.observer.observe(element);
        return this.callback$.asObservable().pipe(filter((/**
         * @param {?} entry
         * @return {?}
         */
        (entry) => entry.target === element)), finalize((/**
         * @return {?}
         */
        () => this.observer.unobserve(element))));
    }
    /**
     * @private
     * @param {?} entries
     * @return {?}
     */
    handler(entries) {
        entries.forEach((/**
         * @param {?} entry
         * @return {?}
         */
        entry => this.callback$.next(entry)));
    }
}
ViewportService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root',
            },] }
];
/** @nocollapse */
ViewportService.ctorParameters = () => [];
/** @nocollapse */ ViewportService.ngInjectableDef = ɵɵdefineInjectable({ factory: function ViewportService_Factory() { return new ViewportService(); }, token: ViewportService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class InViewportDirective {
    /**
     * @param {?} elementRef
     * @param {?} viewportService
     * @param {?} platformId
     */
    constructor(elementRef, viewportService, platformId) {
        this.elementRef = elementRef;
        this.viewportService = viewportService;
        this.platformId = platformId;
        this.preRender = true;
        this.oneTime = false;
        this.inViewport = new EventEmitter();
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        if (isPlatformBrowser(this.platformId)) {
            if (this.oneTime) {
                this.viewportService
                    .observe(this.elementRef.nativeElement)
                    .pipe(untilDestroy(this), filter((/**
                 * @param {?} entry
                 * @return {?}
                 */
                entry => entry.intersectionRatio >= 0.5)), take(1))
                    .subscribe((/**
                 * @param {?} entry
                 * @return {?}
                 */
                (entry) => {
                    this.inViewport.emit(entry);
                }));
            }
            else {
                this.viewportService
                    .observe(this.elementRef.nativeElement)
                    .pipe(untilDestroy(this))
                    .subscribe((/**
                 * @param {?} entry
                 * @return {?}
                 */
                (entry) => {
                    this.inViewport.emit(entry);
                }));
            }
        }
        else {
            if (this.preRender) {
                this.inViewport.emit({ isIntersecting: true, intersectionRatio: 1 });
            }
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() { }
}
InViewportDirective.decorators = [
    { type: Directive, args: [{
                selector: '[inViewport]',
            },] }
];
/** @nocollapse */
InViewportDirective.ctorParameters = () => [
    { type: ElementRef },
    { type: ViewportService },
    { type: Object, decorators: [{ type: Inject, args: [PLATFORM_ID,] }] }
];
InViewportDirective.propDecorators = {
    preRender: [{ type: Input }],
    oneTime: [{ type: Input }],
    inViewport: [{ type: Output }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class InViewportModule {
}
InViewportModule.decorators = [
    { type: NgModule, args: [{
                imports: [CommonModule],
                declarations: [InViewportDirective],
                exports: [InViewportDirective],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class ClickOutsideDirective {
    /**
     * @param {?} _elementRef
     */
    constructor(_elementRef) {
        this._elementRef = _elementRef;
        this.ngxClickOutside = new EventEmitter();
    }
    /**
     * @param {?} event
     * @param {?} targetElement
     * @return {?}
     */
    onClick(event, targetElement) {
        if (!targetElement) {
            return;
        }
        /** @type {?} */
        const clickedInside = this._elementRef.nativeElement.contains(targetElement);
        if (!clickedInside) {
            this.ngxClickOutside.emit(event);
        }
    }
}
ClickOutsideDirective.decorators = [
    { type: Directive, args: [{
                selector: '[ngxClickOutside]',
            },] }
];
/** @nocollapse */
ClickOutsideDirective.ctorParameters = () => [
    { type: ElementRef }
];
ClickOutsideDirective.propDecorators = {
    ngxClickOutside: [{ type: Output }],
    onClick: [{ type: HostListener, args: ['document:click', ['$event', '$event.target'],] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class ClickOutsideModule {
}
ClickOutsideModule.decorators = [
    { type: NgModule, args: [{
                declarations: [ClickOutsideDirective],
                imports: [
                    CommonModule
                ],
                exports: [ClickOutsideDirective]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class MinValidatorDirective {
    /**
     * @param {?} control
     * @return {?}
     */
    validate(control) {
        return this.min ? Validators.min(this.min)(control) : null;
    }
}
MinValidatorDirective.decorators = [
    { type: Directive, args: [{
                selector: '[appMin],[formControlName],[formControl],[ngModel]',
                providers: [{ provide: NG_VALIDATORS, useExisting: MinValidatorDirective, multi: true }],
                exportAs: 'min',
            },] }
];
MinValidatorDirective.propDecorators = {
    min: [{ type: Input }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class MinModule {
}
MinModule.decorators = [
    { type: NgModule, args: [{
                declarations: [MinValidatorDirective],
                imports: [
                    CommonModule
                ],
                exports: [MinValidatorDirective]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const MASK_FLAGS = ['C', '&', 'a', 'A', '?', 'L', '9', '0', '#'];
/** @type {?} */
const KEYS = {
    Ctrl: 17,
    Z: 90,
    Y: 89,
    X: 88,
    BACKSPACE: 8,
    DELETE: 46
};
class MaskHelper {
    /**
     * @return {?}
     */
    get cursor() {
        return this.cursorPrivate;
    }
    /**
     * @param {?} value
     * @param {?} maskOptions
     * @param {?} cursor
     * @return {?}
     */
    parseValueByMask(value, maskOptions, cursor) {
        /** @type {?} */
        let inputValue = value;
        /** @type {?} */
        const mask = maskOptions.format;
        /** @type {?} */
        const literals = this.getMaskLiterals(mask);
        /** @type {?} */
        const literalKeys = Array.from(literals.keys());
        /** @type {?} */
        const nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        if (inputValue.length < mask.length) { // BACKSPACE, DELETE
            if (inputValue === '' && cursor === -1) {
                this.cursorPrivate = 0;
                return this.parseValueByMaskOnInit(value, maskOptions);
            } // workaround for IE 'x' button
            if (nonLiteralIndeces.indexOf(cursor + 1) !== -1) {
                inputValue = this.insertCharAt(inputValue, cursor + 1, maskOptions.promptChar);
                this.cursorPrivate = cursor + 1;
            }
            else {
                inputValue = this.insertCharAt(inputValue, cursor + 1, mask[cursor + 1]);
                this.cursorPrivate = cursor + 1;
                for (let i = this.cursorPrivate; i < 0; i--) {
                    if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                        this.cursorPrivate--;
                    }
                    else {
                        break;
                    }
                }
            }
        }
        else {
            /** @type {?} */
            const char = inputValue[cursor];
            /** @type {?} */
            let isCharValid = this.validateCharOnPostion(char, cursor, mask);
            if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                inputValue = this.replaceCharAt(inputValue, cursor, '');
                if (isCharValid) {
                    inputValue = this.replaceCharAt(inputValue, cursor, char);
                    this.cursorPrivate = cursor + 1;
                }
                else {
                    this.cursorPrivate = cursor;
                }
            }
            else {
                inputValue = this.replaceCharAt(inputValue, cursor, '');
                this.cursorPrivate = ++cursor;
                for (let i = cursor; i < mask.length; i++) {
                    if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                        this.cursorPrivate = ++cursor;
                    }
                    else {
                        isCharValid = this.validateCharOnPostion(char, cursor, mask);
                        if (isCharValid) {
                            inputValue = this.replaceCharAt(inputValue, cursor, char);
                            this.cursorPrivate = ++cursor;
                            break;
                        }
                        else {
                            break;
                        }
                    }
                }
            }
        }
        return inputValue;
    }
    /**
     * @param {?} maskOptions
     * @return {?}
     */
    parseMask(maskOptions) {
        /** @type {?} */
        let outputVal = '';
        /** @type {?} */
        const mask = maskOptions.format;
        /** @type {?} */
        const literals = this.getMaskLiterals(mask);
        for (const maskSym of mask) {
            outputVal += maskOptions.promptChar;
        }
        literals.forEach((/**
         * @param {?} val
         * @param {?} key
         * @return {?}
         */
        (val, key) => {
            outputVal = this.replaceCharAt(outputVal, key, val);
        }));
        return outputVal;
    }
    /**
     * @param {?} inputVal
     * @param {?} maskOptions
     * @return {?}
     */
    parseValueByMaskOnInit(inputVal, maskOptions) {
        /** @type {?} */
        let outputVal = '';
        /** @type {?} */
        let value = '';
        /** @type {?} */
        const mask = maskOptions.format;
        /** @type {?} */
        const literals = this.getMaskLiterals(mask);
        /** @type {?} */
        const literalKeys = Array.from(literals.keys());
        /** @type {?} */
        const nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        /** @type {?} */
        const literalValues = Array.from(literals.values());
        if (inputVal != null) {
            value = inputVal.toString();
        }
        for (const maskSym of mask) {
            outputVal += maskOptions.promptChar;
        }
        literals.forEach((/**
         * @param {?} val
         * @param {?} key
         * @return {?}
         */
        (val, key) => {
            outputVal = this.replaceCharAt(outputVal, key, val);
        }));
        if (!value) {
            return outputVal;
        }
        /** @type {?} */
        const nonLiteralValues = this.getNonLiteralValues(value, literalValues);
        for (let i = 0; i < nonLiteralValues.length; i++) {
            /** @type {?} */
            const char = nonLiteralValues[i];
            /** @type {?} */
            const isCharValid = this.validateCharOnPostion(char, nonLiteralIndeces[i], mask);
            if (!isCharValid && char !== maskOptions.promptChar) {
                nonLiteralValues[i] = maskOptions.promptChar;
            }
        }
        if (nonLiteralValues.length > nonLiteralIndeces.length) {
            nonLiteralValues.splice(nonLiteralIndeces.length);
        }
        /** @type {?} */
        let pos = 0;
        for (const nonLiteralValue of nonLiteralValues) {
            /** @type {?} */
            const char = nonLiteralValue;
            outputVal = this.replaceCharAt(outputVal, nonLiteralIndeces[pos++], char);
        }
        return outputVal;
    }
    /**
     * @param {?} value
     * @param {?} maskOptions
     * @return {?}
     */
    restoreValueFromMask(value, maskOptions) {
        /** @type {?} */
        let outputVal = '';
        /** @type {?} */
        const mask = maskOptions.format;
        /** @type {?} */
        const literals = this.getMaskLiterals(mask);
        /** @type {?} */
        const literalValues = Array.from(literals.values());
        for (const val of value) {
            if (literalValues.indexOf(val) === -1) {
                if (val !== maskOptions.promptChar) {
                    outputVal += val;
                }
            }
        }
        return outputVal;
    }
    /**
     * @param {?} value
     * @param {?} maskOptions
     * @param {?} cursor
     * @param {?} selection
     * @return {?}
     */
    parseValueByMaskUponSelection(value, maskOptions, cursor, selection) {
        /** @type {?} */
        let isCharValid;
        /** @type {?} */
        let inputValue = value;
        /** @type {?} */
        const char = inputValue[cursor];
        /** @type {?} */
        const mask = maskOptions.format;
        /** @type {?} */
        const literals = this.getMaskLiterals(mask);
        /** @type {?} */
        const literalKeys = Array.from(literals.keys());
        /** @type {?} */
        const nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        if (!this.data) {
            this.cursorPrivate = cursor < 0 ? ++cursor : cursor;
            if (nonLiteralIndeces.indexOf(this.cursorPrivate) !== -1) {
                isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                inputValue = isCharValid ? this.replaceCharAt(inputValue, this.cursorPrivate++, char) :
                    inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, maskOptions.promptChar);
                selection--;
                if (selection > 0) {
                    for (let i = 0; i < selection; i++) {
                        cursor++;
                        inputValue = nonLiteralIndeces.indexOf(cursor) !== -1 ?
                            this.insertCharAt(inputValue, cursor, maskOptions.promptChar) :
                            this.insertCharAt(inputValue, cursor, mask[cursor]);
                    }
                }
            }
            else {
                inputValue = this.replaceCharAt(inputValue, this.cursorPrivate, mask[this.cursorPrivate]);
                this.cursorPrivate++;
                selection--;
                /** @type {?} */
                let isMarked = false;
                if (selection > 0) {
                    cursor = this.cursorPrivate;
                    for (let i = 0; i < selection; i++) {
                        if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                            isCharValid = this.validateCharOnPostion(char, cursor, mask);
                            if (isCharValid && !isMarked) {
                                inputValue = this.insertCharAt(inputValue, cursor, char);
                                cursor++;
                                this.cursorPrivate++;
                                isMarked = true;
                            }
                            else {
                                inputValue = this.insertCharAt(inputValue, cursor, maskOptions.promptChar);
                                cursor++;
                            }
                        }
                        else {
                            inputValue = this.insertCharAt(inputValue, cursor, mask[cursor]);
                            if (cursor === this.cursorPrivate) {
                                this.cursorPrivate++;
                            }
                            cursor++;
                        }
                    }
                }
            }
        }
        else {
            if (inputValue === '' && cursor === -1) {
                this.cursorPrivate = 0;
                return this.parseValueByMaskOnInit(value, maskOptions);
            } // workaround for IE 'x' button
            if (this.cursorPrivate < 0) {
                this.cursorPrivate++;
                cursor++;
            }
            cursor++;
            this.cursorPrivate = cursor;
            for (let i = 0; i < selection; i++) {
                if (nonLiteralIndeces.indexOf(cursor) !== -1) {
                    inputValue = this.insertCharAt(inputValue, cursor, maskOptions.promptChar);
                    cursor++;
                }
                else {
                    inputValue = this.insertCharAt(inputValue, cursor, mask[cursor]);
                    cursor++;
                }
            }
        }
        return inputValue;
    }
    /**
     * @param {?} value
     * @param {?} maskOptions
     * @param {?} cursor
     * @param {?} clipboardData
     * @param {?} selection
     * @return {?}
     */
    parseValueByMaskUponCopyPaste(value, maskOptions, cursor, clipboardData, selection) {
        /** @type {?} */
        let inputValue = value;
        /** @type {?} */
        const mask = maskOptions.format;
        /** @type {?} */
        const literals = this.getMaskLiterals(mask);
        /** @type {?} */
        const literalKeys = Array.from(literals.keys());
        /** @type {?} */
        const nonLiteralIndeces = this.getNonLiteralIndeces(mask, literalKeys);
        /** @type {?} */
        const selectionEnd = cursor + selection;
        this.cursorPrivate = cursor;
        for (const clipboardSym of clipboardData) {
            /** @type {?} */
            const char = clipboardSym;
            if (this.cursorPrivate > mask.length) {
                return inputValue;
            }
            if (nonLiteralIndeces.indexOf(this.cursorPrivate) !== -1) {
                /** @type {?} */
                const isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                if (isCharValid) {
                    inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, char);
                }
            }
            else {
                for (let i = cursor; i < mask.length; i++) {
                    if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                        this.cursorPrivate++;
                    }
                    else {
                        /** @type {?} */
                        const isCharValid = this.validateCharOnPostion(char, this.cursorPrivate, mask);
                        if (isCharValid) {
                            inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, char);
                        }
                        break;
                    }
                }
            }
            selection--;
        }
        if (selection > 0) {
            for (let i = this.cursorPrivate; i < selectionEnd; i++) {
                if (literalKeys.indexOf(this.cursorPrivate) !== -1) {
                    this.cursorPrivate++;
                }
                else {
                    inputValue = this.replaceCharAt(inputValue, this.cursorPrivate++, maskOptions.promptChar);
                }
            }
        }
        return inputValue;
    }
    /**
     * @private
     * @param {?} inputChar
     * @param {?} position
     * @param {?} mask
     * @return {?}
     */
    validateCharOnPostion(inputChar, position, mask) {
        /** @type {?} */
        let regex;
        /** @type {?} */
        let isValid;
        /** @type {?} */
        const letterOrDigitRegEx = '[\\d\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z]';
        /** @type {?} */
        const letterDigitOrSpaceRegEx = '[\\d\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z\\u0020]';
        /** @type {?} */
        const letterRegEx = '[\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z]';
        /** @type {?} */
        const letteSpaceRegEx = '[\\u00C0-\\u1FFF\\u2C00-\\uD7FFa-zA-Z\\u0020]';
        /** @type {?} */
        const digitRegEx = '[\\d]';
        /** @type {?} */
        const digitSpaceRegEx = '[\\d\\u0020]';
        /** @type {?} */
        const digitSpecialRegEx = '[\\d-\\+]';
        switch (mask.charAt(position)) {
            case 'C':
                isValid = inputChar !== '';
                break;
            case '&':
                regex = new RegExp('[\\u0020]');
                isValid = !regex.test(inputChar);
                break;
            case 'a':
                regex = new RegExp(letterDigitOrSpaceRegEx);
                isValid = regex.test(inputChar);
                break;
            case 'A':
                regex = new RegExp(letterOrDigitRegEx);
                isValid = regex.test(inputChar);
                break;
            case '?':
                regex = new RegExp(letteSpaceRegEx);
                isValid = regex.test(inputChar);
                break;
            case 'L':
                regex = new RegExp(letterRegEx);
                isValid = regex.test(inputChar);
                break;
            case '0':
                regex = new RegExp(digitRegEx);
                isValid = regex.test(inputChar);
                break;
            case '9':
                regex = new RegExp(digitSpaceRegEx);
                isValid = regex.test(inputChar);
                break;
            case '#':
                regex = new RegExp(digitSpecialRegEx);
                isValid = regex.test(inputChar);
                break;
            default: {
                isValid = null;
            }
        }
        return isValid;
    }
    /**
     * @private
     * @param {?} strValue
     * @param {?} index
     * @param {?} char
     * @return {?}
     */
    replaceCharAt(strValue, index, char) {
        if (strValue !== undefined) {
            return strValue.substring(0, index) + char + strValue.substring(index + 1);
        }
    }
    /**
     * @private
     * @param {?} strValue
     * @param {?} index
     * @param {?} char
     * @return {?}
     */
    insertCharAt(strValue, index, char) {
        if (strValue !== undefined) {
            return strValue.substring(0, index) + char + strValue.substring(index);
        }
    }
    /**
     * @private
     * @param {?} mask
     * @return {?}
     */
    getMaskLiterals(mask) {
        /** @type {?} */
        const literals = new Map();
        for (let i = 0; i < mask.length; i++) {
            /** @type {?} */
            const char = mask.charAt(i);
            if (MASK_FLAGS.indexOf(char) === -1) {
                literals.set(i, char);
            }
        }
        return literals;
    }
    /**
     * @private
     * @param {?} mask
     * @param {?} literalKeys
     * @return {?}
     */
    getNonLiteralIndeces(mask, literalKeys) {
        /** @type {?} */
        const nonLiteralsIndeces = new Array();
        for (let i = 0; i < mask.length; i++) {
            if (literalKeys.indexOf(i) === -1) {
                nonLiteralsIndeces.push(i);
            }
        }
        return nonLiteralsIndeces;
    }
    /**
     * @private
     * @param {?} value
     * @param {?} literalValues
     * @return {?}
     */
    getNonLiteralValues(value, literalValues) {
        /** @type {?} */
        const nonLiteralValues = new Array();
        for (const val of value) {
            if (literalValues.indexOf(val) === -1) {
                nonLiteralValues.push(val);
            }
        }
        return nonLiteralValues;
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @return {?}
 */
function isIE() {
    return navigator.appVersion.indexOf('Trident/') > 0;
}
/** @type {?} */
const noop = (/**
 * @return {?}
 */
() => { });
class MaskDirective {
    /**
     * @param {?} elementRef
     */
    constructor(elementRef) {
        this.elementRef = elementRef;
        this.onValueChange = new EventEmitter();
        this.maskOptions = {
            format: '',
            promptChar: '',
        };
        this.onTouchedCallback = noop;
        this.onChangeCallback = noop;
        this.maskHelper = new MaskHelper();
    }
    /**
     * @private
     * @return {?}
     */
    get value() {
        return this.nativeElement.value;
    }
    /**
     * @private
     * @param {?} val
     * @return {?}
     */
    set value(val) {
        this.nativeElement.value = val;
    }
    /**
     * @private
     * @return {?}
     */
    get nativeElement() {
        return this.elementRef.nativeElement;
    }
    /**
     * @private
     * @return {?}
     */
    get selectionStart() {
        return this.nativeElement.selectionStart;
    }
    /**
     * @private
     * @return {?}
     */
    get selectionEnd() {
        return this.nativeElement.selectionEnd;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        if (this.promptChar && this.promptChar.length > 1) {
            this.maskOptions.promptChar = this.promptChar = this.promptChar.substring(0, 1);
        }
        this.maskOptions.format = this.mask ? this.mask : 'CCCCCCCCCC';
        this.maskOptions.promptChar = this.promptChar ? this.promptChar : '_';
        this.nativeElement.setAttribute('placeholder', this.placeholder ? this.placeholder : this.maskOptions.format);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onKeydown(event) {
        /** @type {?} */
        const key = event.keyCode || event.charCode;
        if (isIE() && this.stopPropagation) {
            this.stopPropagation = false;
        }
        if (key === KEYS.Ctrl) {
            this.ctrlDown = true;
        }
        if ((this.ctrlDown && key === KEYS.Z) || (this.ctrlDown && key === KEYS.Y)) {
            event.preventDefault();
        }
        this.key = key;
        this.selection = Math.abs(this.selectionEnd - this.selectionStart);
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onKeyup(event) {
        /** @type {?} */
        const key = event.keyCode || event.charCode;
        if (key === KEYS.Ctrl) {
            this.ctrlDown = false;
        }
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onPaste(event) {
        this.paste = true;
        this.valOnPaste = this.value;
        this.cursorOnPaste = this.getCursorPosition();
    }
    /**
     * @param {?} event
     * @return {?}
     */
    onInputChanged(event) {
        if (isIE() && this.stopPropagation) {
            this.stopPropagation = false;
            return;
        }
        if (this.paste) {
            this.paste = false;
            /** @type {?} */
            const clipboardData = this.value.substring(this.cursorOnPaste, this.getCursorPosition());
            this.value = this.maskHelper.parseValueByMaskUponCopyPaste(this.valOnPaste, this.maskOptions, this.cursorOnPaste, clipboardData, this.selection);
            this.setCursorPosition(this.maskHelper.cursor);
        }
        else {
            /** @type {?} */
            const currentCursorPos = this.getCursorPosition();
            this.maskHelper.data = this.key === KEYS.BACKSPACE || this.key === KEYS.DELETE;
            this.value =
                this.selection && this.selection !== 0
                    ? this.maskHelper.parseValueByMaskUponSelection(this.value, this.maskOptions, currentCursorPos - 1, this.selection)
                    : this.maskHelper.parseValueByMask(this.value, this.maskOptions, currentCursorPos - 1);
            this.setCursorPosition(this.maskHelper.cursor);
        }
        /** @type {?} */
        const rawVal = this.maskHelper.restoreValueFromMask(this.value, this.maskOptions);
        this.dataValue = this.includeLiterals ? this.value : rawVal;
        this.onChangeCallback(this.dataValue);
        this.onValueChange.emit({ rawValue: rawVal, formattedValue: this.value });
    }
    /**
     * @param {?} value
     * @return {?}
     */
    onFocus(value) {
        if (this.focusedValuePipe) {
            if (isIE()) {
                this.stopPropagation = true;
            }
            this.value = this.focusedValuePipe.transform(value);
        }
        else {
            this.value = this.maskHelper.parseValueByMaskOnInit(this.value, this.maskOptions);
        }
    }
    /**
     * @param {?} value
     * @return {?}
     */
    onBlur(value) {
        if (this.displayValuePipe) {
            this.value = this.displayValuePipe.transform(value);
        }
        else if (value === this.maskHelper.parseMask(this.maskOptions)) {
            this.value = '';
        }
    }
    /**
     * @private
     * @return {?}
     */
    getCursorPosition() {
        return this.nativeElement.selectionStart;
    }
    /**
     * @private
     * @param {?} start
     * @param {?=} end
     * @return {?}
     */
    setCursorPosition(start, end = start) {
        this.nativeElement.setSelectionRange(start, end);
    }
    /**
     * @param {?} value
     * @return {?}
     */
    writeValue(value) {
        if (this.promptChar && this.promptChar.length > 1) {
            this.maskOptions.promptChar = this.promptChar.substring(0, 1);
        }
        this.value = value ? this.maskHelper.parseValueByMaskOnInit(value, this.maskOptions) : '';
        if (this.displayValuePipe) {
            this.value = this.displayValuePipe.transform(this.value);
        }
        this.dataValue = this.includeLiterals ? this.value : value;
        this.onChangeCallback(this.dataValue);
        this.onValueChange.emit({ rawValue: value, formattedValue: this.value });
    }
    /**
     * @param {?} fn
     * @return {?}
     */
    registerOnChange(fn) {
        this.onChangeCallback = fn;
    }
    /**
     * @param {?} fn
     * @return {?}
     */
    registerOnTouched(fn) {
        this.onTouchedCallback = fn;
    }
}
MaskDirective.decorators = [
    { type: Directive, args: [{
                providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: MaskDirective, multi: true }],
                selector: '[ngxMask]',
            },] }
];
/** @nocollapse */
MaskDirective.ctorParameters = () => [
    { type: ElementRef }
];
MaskDirective.propDecorators = {
    mask: [{ type: Input, args: ['ngxMask',] }],
    promptChar: [{ type: Input }],
    includeLiterals: [{ type: Input }],
    placeholder: [{ type: Input }],
    displayValuePipe: [{ type: Input }],
    focusedValuePipe: [{ type: Input }],
    dataValue: [{ type: Input }],
    onValueChange: [{ type: Output }],
    onKeydown: [{ type: HostListener, args: ['keydown', ['$event'],] }],
    onKeyup: [{ type: HostListener, args: ['keyup', ['$event'],] }],
    onPaste: [{ type: HostListener, args: ['paste', ['$event'],] }],
    onInputChanged: [{ type: HostListener, args: ['input', ['$event'],] }],
    onFocus: [{ type: HostListener, args: ['focus', ['$event.target.value'],] }],
    onBlur: [{ type: HostListener, args: ['blur', ['$event.target.value'],] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class MaskModule {
}
MaskModule.decorators = [
    { type: NgModule, args: [{
                declarations: [MaskDirective],
                imports: [
                    CommonModule
                ],
                exports: [MaskDirective]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class FilterPipe {
    /**
     * @param {?} itemList
     * @param {?=} filterTerm
     * @param {?=} filterBy
     * @return {?}
     */
    transform(itemList, filterTerm, filterBy) {
        if (!filterBy) {
            return itemList;
        }
        if (filterTerm === '') {
            return itemList;
        }
        filterBy = filterBy.toString();
        return itemList.filter((/**
         * @param {?} item
         * @return {?}
         */
        (item) => {
            if (item[filterBy]) {
                return item[filterBy]
                    .toString()
                    .toLowerCase()
                    .includes(filterTerm.toLowerCase());
            }
        }));
    }
}
FilterPipe.decorators = [
    { type: Pipe, args: [{ name: 'filter' },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * <ul>
 *   <li *ngFor="let object of myArray | groupBy:'color'"></li>
 * </ul>
 * @template T
 */
class GroupByPipe {
    /**
     * @param {?} collection
     * @param {?} property
     * @return {?}
     */
    transform(collection, property) {
        // prevents the application from breaking if the array of objects doesn't exist yet
        if (!collection) {
            return null;
        }
        /** @type {?} */
        const groupedCollection = collection.reduce((/**
         * @param {?} previous
         * @param {?} current
         * @return {?}
         */
        (previous, current) => {
            if (!previous[current[property]]) {
                previous[current[property]] = [current];
            }
            else {
                previous[current[property]].push(current);
            }
            return previous;
        }), {});
        // this will return an array of objects, each object containing a group of objects
        return Object.keys(groupedCollection).map((/**
         * @param {?} key
         * @return {?}
         */
        key => ({
            key,
            value: groupedCollection[key],
        })));
    }
}
GroupByPipe.decorators = [
    { type: Pipe, args: [{ name: 'groupBy' },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class SafeHtmlPipe {
    /**
     * @param {?} sanitizer
     */
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    /**
     * @param {?} value
     * @param {?=} args
     * @return {?}
     */
    transform(value, args) {
        return this.sanitizer.bypassSecurityTrustHtml(value);
    }
}
SafeHtmlPipe.decorators = [
    { type: Pipe, args: [{ name: 'safeHtml' },] }
];
/** @nocollapse */
SafeHtmlPipe.ctorParameters = () => [
    { type: DomSanitizer }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class HelperModule {
}
HelperModule.decorators = [
    { type: NgModule, args: [{
                imports: [CommonModule],
                declarations: [FilterPipe, GroupByPipe, SafeHtmlPipe],
                exports: [FilterPipe, GroupByPipe, SafeHtmlPipe],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class CharactersPipe {
    /**
     * @param {?} value
     * @param {?=} limit
     * @param {?=} trail
     * @return {?}
     */
    transform(value, limit = 40, trail = '…') {
        if (!value) {
            value = '';
        }
        if (limit < 0) {
            limit *= -1;
            return value.length > limit ? trail + value.substring(value.length - limit, value.length) : value;
        }
        else {
            return value.length > limit ? value.substring(0, limit) + trail : value;
        }
    }
}
CharactersPipe.decorators = [
    { type: Pipe, args: [{
                pure: true,
                name: 'characters',
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class WordsPipe {
    /**
     * @param {?} value
     * @param {?=} limit
     * @param {?=} trail
     * @return {?}
     */
    transform(value, limit = 40, trail = '…') {
        /** @type {?} */
        let result = value || '';
        if (value) {
            /** @type {?} */
            const words = value.split(/\s+/);
            if (words.length > Math.abs(limit)) {
                if (limit < 0) {
                    limit *= -1;
                    result = trail + words.slice(words.length - limit, words.length).join(' ');
                }
                else {
                    result = words.slice(0, limit).join(' ') + trail;
                }
            }
        }
        return result;
    }
}
WordsPipe.decorators = [
    { type: Pipe, args: [{
                pure: true,
                name: 'words',
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class TruncateModule {
}
TruncateModule.decorators = [
    { type: NgModule, args: [{
                imports: [CommonModule],
                declarations: [CharactersPipe, WordsPipe],
                exports: [CharactersPipe, WordsPipe],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const defaultConfig = { addSuffix: true };
/**
 * impure pipe, which in general can lead to bad performance
 * but the backoff function limits the frequency the pipe checks for updates
 * so the performance is close to that of a pure pipe
 * the downside of this is that if you change the value of the input, the pipe might not notice for a while
 * so this pipe is intended for static data
 *
 * expected input is a time (number, string or Date)
 * output is a string expressing distance from that time to now, plus the suffix 'ago'
 * output refreshes at dynamic intervals, with refresh rate slowing down as the input time gets further away from now
 */
class FormatTimeInWordsPipe {
    /**
     * @param {?} cdr
     */
    constructor(cdr) {
        this.cdr = cdr;
        this.isDestroyed = false;
        this.async = new AsyncPipe(this.cdr);
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.isDestroyed = true; // pipe will stop executing after next iteration
    }
    /**
     * @param {?} date
     * @param {?=} options
     * @return {?}
     */
    transform(date, options) {
        if (date == null) {
            throw new Error(FormatTimeInWordsPipe.NO_ARGS_ERROR);
        }
        // set the pipe to the Observable if not yet done, and return an async pipe
        if (!this.agoExpression) {
            this.agoExpression = this.timeAgo(date, Object.assign({}, defaultConfig, options));
        }
        return this.async.transform(this.agoExpression);
    }
    /**
     * @private
     * @param {?} date
     * @param {?=} options
     * @return {?}
     */
    timeAgo(date, options) {
        /** @type {?} */
        let nextBackoff = this.backoff(date);
        return of(true).pipe(
        // will not recheck input until delay completes
        repeatWhen((/**
         * @param {?} notify
         * @return {?}
         */
        notify => notify.pipe(delayWhen((/**
         * @return {?}
         */
        () => interval(nextBackoff)))))), takeWhile((/**
         * @param {?} _
         * @return {?}
         */
        _ => !this.isDestroyed)), map((/**
         * @param {?} _
         * @return {?}
         */
        _ => formatDistance(this.stringToDate(date), new Date(), options))), tap((/**
         * @param {?} _
         * @return {?}
         */
        _ => (nextBackoff = this.backoff(date)))));
    }
    /**
     * @private
     * @param {?} date
     * @return {?}
     */
    backoff(date) {
        /** @type {?} */
        const minutesElapsed = Math.abs(differenceInMinutes(new Date(), this.stringToDate(date)));
        // this will always be positive
        /** @type {?} */
        let backoffAmountInSeconds;
        if (minutesElapsed < 2) {
            backoffAmountInSeconds = 5;
        }
        else if (minutesElapsed >= 2 && minutesElapsed < 5) {
            backoffAmountInSeconds = 15;
        }
        else if (minutesElapsed >= 5 && minutesElapsed < 60) {
            backoffAmountInSeconds = 30;
        }
        else if (minutesElapsed >= 60) {
            backoffAmountInSeconds = 300; // 5 minutes
        }
        return backoffAmountInSeconds * 1000; // return an amount of milliseconds
    }
    /**
     * @private
     * @param {?} date
     * @return {?}
     */
    stringToDate(date) {
        /** @type {?} */
        const isString = (/**
         * @param {?} s
         * @return {?}
         */
        s => typeof (s) === 'string' || s instanceof String);
        return isString(date) ? parseISO(date) : date;
    }
}
FormatTimeInWordsPipe.NO_ARGS_ERROR = 'formatTimeInWords: missing required arguments';
FormatTimeInWordsPipe.decorators = [
    { type: Pipe, args: [{ name: 'formatTimeInWords', pure: false },] }
];
/** @nocollapse */
FormatTimeInWordsPipe.ctorParameters = () => [
    { type: ChangeDetectorRef }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const PIPES = [FormatTimeInWordsPipe];
class DateFnsModule {
}
DateFnsModule.decorators = [
    { type: NgModule, args: [{
                declarations: [PIPES],
                imports: [CommonModule],
                exports: [PIPES],
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { ClickOutsideModule, DateFnsModule, HelperModule, InViewportModule, MaskModule, MinModule, NgLetModule, RouterLinkMatchModule, TruncateModule, ViewportService, pluck, untilDestroy, NgLetContext as ɵa, NgLetDirective as ɵb, RouterLinkMatchDirective as ɵc, InViewportDirective as ɵd, destroy$ as ɵdestroy$, ClickOutsideDirective as ɵe, MinValidatorDirective as ɵf, MaskDirective as ɵg, FilterPipe as ɵh, GroupByPipe as ɵi, SafeHtmlPipe as ɵj, CharactersPipe as ɵk, WordsPipe as ɵl, FormatTimeInWordsPipe as ɵm };
//# sourceMappingURL=vibe-ngx-utils.js.map
