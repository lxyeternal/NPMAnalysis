const ModelsNames = {
  linkedDevice: 'LinkedDevice',
  deviceRewardHistory: 'DeviceRewardHistory',
  deviceRewardSetting: 'DeviceRewardSetting',
};

const DeviceStatus = {};

module.exports = {
  ModelsNames,
  DeviceStatus,
};
