require('dotenv/config');
const lfiDeviceRewards = require('./app');

describe('Device reward history setting service', () => {
  test('Setting service should be defined', () => {
    expect(
      lfiDeviceRewards.deviceRewardHistorySettingService
        .getDeviceRewardHistorySetting,
    ).toBeTruthy();
  });
});

describe('Linked device service', () => {
  let connection;
  const userMinterId = '650985cae83ca8a28e661444';
  const userLicenseId = '650985cae83ca8a28e661446';

  beforeAll(async () => {
    connection = await lfiDeviceRewards.setDatabaseUrl(
      process.env.MONGO_DB_URI,
    );
  });

  const data = {
    userMinterId,
    userLicenseId,
    userId: '65097de0e83ca8a28e65c030',
    licenseName: 'LFI-110',
    licenseNft: 40,
    nftCount: 4,
    percentage: 30,
    deviceType: 'minter',
  };

  test('Should create new linked device', async () => {
    const linkedDevice =
      await lfiDeviceRewards.linkedDeviceService.addLinkedDevice(data);

    expect(linkedDevice).toBeTruthy();
    expect(linkedDevice._id).toBeDefined();
  });

  test('Should get linked device', async () => {
    const linkedDevice =
      await lfiDeviceRewards.linkedDeviceService.getLinkedDevice({
        userLicenseId,
        userMinterId,
      });

    expect(linkedDevice).toBeTruthy();
    expect(linkedDevice._id).toBeDefined();
  });

  test('Should activate linked devices', async () => {
    const linkedDevice =
      await lfiDeviceRewards.linkedDeviceService.activateLinkedDevices(
        userMinterId,
      );

    expect(linkedDevice).toBeTruthy();
  });

  test('Should deactivate linked devices', async () => {
    const linkedDevice =
      await lfiDeviceRewards.linkedDeviceService.deactivateLinkedDevices(
        userMinterId,
      );

    expect(linkedDevice).toBeTruthy();
  });

  afterAll(() => {
    if (connection) connection.disconnect();
  });
});

describe('Device reward history service', () => {
  let connection;

  beforeAll(async () => {
    connection = await lfiDeviceRewards.setDatabaseUrl(
      process.env.MONGO_DB_URI,
    );
  });

  test('Should return list of reward histories', async () => {
    const rewardHistories =
      await lfiDeviceRewards.deviceRewardHistoryService.getDeviceRewardHistories();

    expect(rewardHistories).toBeTruthy();
    expect(rewardHistories).toHaveProperty('docs');
  });

  afterAll(() => {
    if (connection) connection.disconnect();
  });
});
