const DeviceRewardHistorySetting = require('./deviceRewardHistorySettings.model');

async function getDeviceRewardHistorySetting() {
  return DeviceRewardHistorySetting.findOne({ deleted: { $ne: true } });
}

async function createDeviceRewardHistorySetting({
  reBuyPercentage,
  withdrawPercentage,
}) {
  const rewardSetting = await getDeviceRewardHistorySetting();

  if (rewardSetting) throw new Error('Reward setting already exists');

  const data = { reBuyPercentage, withdrawPercentage };

  return new DeviceRewardHistorySetting(data).save();
}

async function updateDeviceRewardHistorySetting({
  reBuyPercentage,
  withdrawPercentage,
}) {
  const filter = { deleted: { $ne: true } };
  const update = { $set: { reBuyPercentage, withdrawPercentage } };
  const options = { new: true };

  const rewardSetting = await DeviceRewardHistorySetting.findOneAndUpdate(
    filter,
    update,
    options,
  );

  if (!rewardSetting) throw new Error('reward setting not exists');

  return rewardSetting;
}

async function deleteDeviceRewardHistorySetting() {
  const filter = { deleted: { $ne: true } };

  const rewardSetting =
    await DeviceRewardHistorySetting.findOneAndDelete(filter);

  if (!rewardSetting) throw new Error('reward setting not exists');

  return rewardSetting;
}

module.exports = {
  getDeviceRewardHistorySetting,
  createDeviceRewardHistorySetting,
  updateDeviceRewardHistorySetting,
  deleteDeviceRewardHistorySetting,
};
