const { Schema, model } = require('mongoose');

const { ModelsNames } = require('../constants');

const LinkedDevicesSchema = new Schema(
  {
    reBuyPercentage: {
      type: Number,
      required: true,
      min: 0,
      max: 100,
    },
    withdrawPercentage: {
      type: Number,
      required: true,
      min: 0,
      max: 100,
    },
    deleted: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  },
);

module.exports = model(ModelsNames.deviceRewardSetting, LinkedDevicesSchema);
