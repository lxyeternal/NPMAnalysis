const LinkedDevice = require('./linkedDevices.model');

async function addLinkedDevice(data) {
  const {
    userMinterId,
    userId,
    userLicenseId,
    licenseName,
    licenseNft,
    nftCount,
    percentage,
    deviceType,
  } = data;

  const existingDevice = await LinkedDevice.findOne({
    userMinter: userMinterId,
    userLicense: userLicenseId,
  });

  if (existingDevice) return existingDevice;

  const device = new LinkedDevice();

  device.userMinter = userMinterId;
  device.user = userId;
  device.userLicense = userLicenseId;
  device.licenseName = licenseName;
  device.licenseNft = licenseNft;
  device.nftCount = nftCount;
  device.deviceType = deviceType;
  device.percentage = percentage;

  return device.save();
}

async function getLinkedDevice({ userLicenseId, userMinterId }) {
  return LinkedDevice.findOne({
    userLicense: userLicenseId,
    userMinter: userMinterId,
  });
}

async function updateLinkedDevice({ userLicenseId, userMinterId, ...data }) {
  const filter = { userLicense: userLicenseId, userMinter: userMinterId };
  const update = { $set: data };
  const options = { new: true };
  return LinkedDevice.findOneAndUpdate(filter, update, options);
}

async function activateLinkedDevices(userMinterId) {
  const filter = { userMinter: userMinterId };
  const update = { $set: { active: true } };

  return LinkedDevice.updateMany(filter, update);
}

async function deactivateLinkedDevices(userMinterId) {
  const filter = { userMinter: userMinterId };
  const update = { $set: { active: false } };

  return LinkedDevice.updateMany(filter, update);
}

module.exports = {
  addLinkedDevice,
  getLinkedDevice,
  updateLinkedDevice,
  activateLinkedDevices,
  deactivateLinkedDevices,
};
