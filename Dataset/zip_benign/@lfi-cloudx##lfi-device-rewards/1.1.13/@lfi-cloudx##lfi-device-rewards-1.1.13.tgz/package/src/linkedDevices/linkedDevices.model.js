const { Schema, model, models } = require('mongoose');

const { ModelsNames } = require('../constants');

const LinkedDevicesSchema = new Schema(
  {
    userMinter: {
      type: Schema.Types.ObjectId,
      required: true,
    },
    user: {
      type: Schema.Types.ObjectId,
      required: true,
    },
    userLicense: {
      type: Schema.Types.ObjectId,
      required: true,
    },
    licenseName: {
      type: String,
      required: true,
    },
    licenseId: {
      type: String,
    },
    licenseNft: {
      type: Number,
      default: 0,
    },
    nftCount: {
      type: Number,
      default: 0,
    },
    deviceType: {
      type: String,
      required: true,
    },
    totalRebuyReward: {
      type: String,
      default: '0',
    },
    totalWithdrawReward: {
      type: String,
      default: '0',
    },
    percentage: {
      type: Number,
      required: true,
    },
    active: {
      type: Boolean,
      default: false,
    },
    deleted: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  },
);

module.exports =
  models[ModelsNames.linkedDevice] ||
  model(ModelsNames.linkedDevice, LinkedDevicesSchema);
