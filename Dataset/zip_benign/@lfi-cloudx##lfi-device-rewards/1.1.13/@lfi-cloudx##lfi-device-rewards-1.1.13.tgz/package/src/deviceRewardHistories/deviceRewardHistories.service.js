const LinkedDevice = require('../linkedDevices/linkedDevices.model');
const DeviceRewardSetting = require('../deviceRewardHistorySettings/deviceRewardHistorySettings.model');
const DeviceRewardHistory = require('./deviceRewardHistories.model');

const linkedDevicePopulateOptions = {
  path: 'device',
};

async function addDeviceRewardHistories({
  licenseId,
  licenseReward,
  userMinters,
  licenseReBuyReward,
  licenseWithdrawReward,
  autoCompounded,
  createdAt,
  days,
}) {
  let rewardSetting = await DeviceRewardSetting.findOne({
    deleted: { $ne: true },
  });

  if (!rewardSetting) {
    //
    rewardSetting = await DeviceRewardSetting.create({
      withdrawPercentage: 60,
      reBuyPercentage: 40,
    });

    if (!rewardSetting) throw new Error('Reward setting not found');
  }

  const promises = [];

  for (let userMinter of userMinters) {
    const linkedDevice = await LinkedDevice.findOne({
      userLicense: licenseId,
      userMinter: userMinter.id,
      active: true,
      deleted: false,
      // licenseReBuyReward,
      // licenseWithdrawReward,
      // autoCompounded,
    });

    if (linkedDevice) {
      const deviceReward =
        (linkedDevice.nftCount / linkedDevice.licenseNft) * licenseReward;

      const currentTotalRebuy = linkedDevice?.totalRebuyReward
        ? +linkedDevice?.totalRebuyReward
        : 0;
      const currentTotalWithdraw = linkedDevice?.totalWithdrawReward
        ? +linkedDevice?.totalWithdrawReward
        : 0;

      const percentageReward = deviceReward * userMinter.percentage * 0.01;
      const rebuy = rewardSetting.reBuyPercentage * percentageReward * 0.01;
      const withdraw =
        rewardSetting.withdrawPercentage * percentageReward * 0.01;
      const totalRebuy = currentTotalRebuy + rebuy;
      const totalWithdraw = currentTotalWithdraw + withdraw;

      const promise = new DeviceRewardHistory({
        device: linkedDevice._id,
        totalReward: percentageReward,
        reBuyReward: rebuy,
        withdrawReward: withdraw,
        deviceNft: linkedDevice.nftCount,
        percentage: userMinter.percentage,
        reBuyPercentage: rewardSetting.reBuyPercentage,
        withdrawPercentage: rewardSetting.withdrawPercentage,
        totalRebuyReward: totalRebuy,
        totalWithdrawReward: totalWithdraw,
        licenseReBuyReward,
        licenseWithdrawReward,
        autoCompounded,
        createdAt,
        days,
      })
        .save()
        .then(history => history.populate(linkedDevicePopulateOptions));

      linkedDevice.totalRebuyReward = totalRebuy;
      linkedDevice.totalWithdrawReward = totalWithdraw;
      await linkedDevice.save();

      promises.push(promise);
    }
  }

  return Promise.all(promises);
}

async function getDeviceRewardHistories({
  deviceIds,
  limit = 10,
  page,
  filterBy = {},
  sort = {},
} = {}) {
  const filter = {};

  const sortExpression = { [sort?.key ?? 'createdAt']: sort?.order ?? -1 };

  if (filterBy.fromDate && filterBy.toDate) {
    const fromDate = new Date(filterBy.fromDate);
    fromDate.setHours(0, 0, 0);
    const toDate = new Date(filterBy.toDate);
    toDate.setHours(23, 59, 59);

    filter.createdAt = {
      $gte: fromDate,
      $lte: toDate,
    };
  }

  let basePaginationOptions = {
    limit: limit,
    sort: sortExpression,
  };

  if (page) {
    basePaginationOptions = {
      ...basePaginationOptions,
      page: page,
    };
  }

  if (Array.isArray(deviceIds)) {
    filter.device = { $in: deviceIds };
  }

  return DeviceRewardHistory.paginate(filter, {
    ...basePaginationOptions,
    populate: [linkedDevicePopulateOptions],
  });
}

const getDeviceRewardHistoriesGroupByDate = async (
  {
    deviceIds,
    licenseIds,
    //filterBy = {},
  },
  options,
) => {
  let pipeline = [];

  try {
    if (Array.isArray(deviceIds)) {
      const linkedDevices = await LinkedDevice.find({
        userMinter: { $in: deviceIds },
      }).distinct('_id');

      pipeline.push({
        $match: {
          device: { $in: linkedDevices },
        },
      });
    } else {
      if (Array.isArray(licenseIds)) {
        const linkedDevices = await LinkedDevice.find({
          userMinter: { $in: licenseIds },
          deleted: false,
        }).distinct('_id');

        pipeline.push({
          $match: {
            device: { $in: linkedDevices },
          },
        });
      }
    }

    pipeline.push({
      $project: {
        days: 1,
        createdAt: 1,
        reBuyReward: {
          $toDouble: '$reBuyReward',
        },
        withdrawReward: {
          $toDouble: '$withdrawReward',
        },
        accumulativeReBuyReward: {
          $toDouble: '$totalRebuyReward',
        },
        accumulativeWithdrawReward: {
          $toDouble: '$totalWithdrawReward',
        },
        licenseReBuyReward: {
          $toDouble: '$licenseReBuyReward',
        },
        licenseWithdrawReward: {
          $toDouble: '$licenseWithdrawReward',
        },
        totalReward: '$totalReward',
      },
    });

    const groupId = options?.groupByDays
      ? '$days'
      : {
          $dateToString: { format: '%Y-%m-%d', date: '$createdAt' },
        };

    pipeline.push({
      $group: {
        _id: groupId,
        reBuyReward: { $sum: '$reBuyReward' },
        withdrawReward: { $sum: '$withdrawReward' },
        accumulativeReBuyReward: { $sum: '$accumulativeReBuyReward' },
        accumulativeWithdrawReward: { $sum: '$accumulativeWithdrawReward' },
        licenseReBuyReward: { $sum: '$licenseReBuyReward' },
        licenseWithdrawReward: { $sum: '$licenseWithdrawReward' },
        totalReward: { $sum: '$totalReward' },
      },
    });

    pipeline.push({
      $sort: { _id: 1 },
    });

    return await DeviceRewardHistory.aggregate(pipeline);
  } catch (error) {
    console.log(
      '🚀 ~ file: deviceRewardHistories.service.js:154 ~ error:',
      error,
    );
    return null;
  }
};

module.exports = {
  addDeviceRewardHistories,
  getDeviceRewardHistories,
  getDeviceRewardHistoriesGroupByDate,
};
