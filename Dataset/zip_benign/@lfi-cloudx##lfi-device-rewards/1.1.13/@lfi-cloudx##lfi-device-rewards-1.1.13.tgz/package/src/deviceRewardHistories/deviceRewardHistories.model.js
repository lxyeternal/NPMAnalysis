const { Schema, model } = require('mongoose');
const paginatePlugin = require('mongoose-paginate-v2');

const { ModelsNames } = require('../constants');

const DeviceRewardHistorySchema = new Schema(
  {
    device: {
      type: Schema.Types.ObjectId,
      ref: ModelsNames.linkedDevice,
      required: true,
    },
    totalReward: {
      type: String,
      required: true,
    },
    deviceNft: {
      type: Number,
      required: true,
    },
    percentage: {
      type: Number,
      required: true,
    },
    reBuyReward: {
      type: String,
      required: true,
    },
    withdrawReward: {
      type: String,
      required: true,
    },
    totalRebuyReward: {
      type: String,
      default: '0',
    },
    totalWithdrawReward: {
      type: String,
      default: '0',
    },
    reBuyPercentage: {
      type: Number,
      required: true,
    },
    withdrawPercentage: {
      type: Number,
      required: true,
    },
    licenseReBuyReward: {
      type: String,
      required: true,
    },
    licenseWithdrawReward: {
      type: String,
      required: true,
    },
    autoCompounded: {
      type: Boolean,
      default: false,
    },
    days: {
      type: Number,
    },
  },
  {
    timestamps: true,
  },
);

DeviceRewardHistorySchema.plugin(paginatePlugin);

module.exports = model(
  ModelsNames.deviceRewardHistory,
  DeviceRewardHistorySchema,
);
