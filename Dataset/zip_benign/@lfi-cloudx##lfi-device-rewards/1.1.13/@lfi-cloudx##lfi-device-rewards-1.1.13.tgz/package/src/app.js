const mongoose = require('mongoose');

const linkedDevicesService = require('./linkedDevices/linkedDevices.service');
const deviceRewardHistoriesService = require('./deviceRewardHistories/deviceRewardHistories.service');
const deviceRewardHistorySettingsService = require('./deviceRewardHistorySettings/deviceRewardHistorySettings.service');

class App {
  linkedDeviceService = linkedDevicesService;
  deviceRewardHistoryService = deviceRewardHistoriesService;
  deviceRewardHistorySettingService = deviceRewardHistorySettingsService;

  async setDatabaseUrl(dbUrl) {
    this.dbUrl = dbUrl;
    return mongoose.connect(this.dbUrl);
  }
}

module.exports = new App();
