import { MongooseError, Types } from 'mongoose';

declare module 'lfi-device-rewards' {
  interface PaginateResult<T> {
    docs: Array<T>;
    totalDocs: number;
    limit: number;
    hasPrevPage: boolean;
    hasNextPage: boolean;
    page?: number | undefined;
    totalPages: number;
    offset: number;
    prevPage?: number | null | undefined;
    nextPage?: number | null | undefined;
    pagingCounter: number;
  }

  export interface LinkedDevice {
    _id: string;
    userMinter: string;
    user: string;
    userLicense: string;
    licenseName: string;
    licenseNft: number;
    nftCount: number;
    deviceType: string;
    percentage: number;
    active?: boolean;
    createdAt: string;
    updatedAt: string;
  }

  export interface DeviceRewardHistory {
    _id: string;
    device: Partial<LinkedDevice>;
    totalReward: string;
    reBuyReward: string;
    withdrawReward: string;
    deviceNft: number;
    percentage: number;
    reBuyPercentage: number;
    withdrawPercentage: number;
    createdAt: string;
    updatedAt: string;
  }

  export interface RewardSetting {
    _id: string;
    reBuyPercentage: number;
    withdrawPercentage: number;
    createdAt: string;
    updatedAt: string;
  }

  export interface CreateLinkedDeviceData {
    userMinterId: string;
    userId: string;
    userLicenseId: string;
    licenseName: string;
    licenseNft: number;
    nftCount: number;
    percentage: number;
    deviceType: string;
  }

  export interface UpdateLinkedDeviceData
    extends Partial<CreateLinkedDeviceData> {}

  export interface CreateDeviceRewardData {
    deviceId: Types.ObjectId;
    deviceNft: number;
    percentage: number;
    reward: number;
  }

  export interface UpdateRewardSettingData {
    reBuyPercentage?: number;
    withdrawPercentage?: number;
  }

  export interface ListDeviceRewardHistoryParams {
    limit?: number;
    first?: number;
    pagination?: boolean;
  }

  interface LinkedDeviceService {
    getDevice: (
      id: Types.ObjectId,
    ) => Promise<LinkedDevice | MongooseError | null>;
    addDevice: (
      data: CreateLinkedDeviceData,
    ) => Promise<LinkedDevice | MongooseError>;
    updateDevice: (
      data: UpdateLinkedDeviceData,
    ) => Promise<LinkedDevice | MongooseError>;
    activateDevice: (
      deviceId: Types.ObjectId,
    ) => Promise<LinkedDevice | MongooseError>;
    deactivateDevice: (
      deviceId: Types.ObjectId,
    ) => Promise<LinkedDevice | MongooseError>;
  }

  interface DeviceRewardHistoryService {
    addReward: (
      data: CreateDeviceRewardData,
    ) => Promise<DeviceRewardHistory | MongooseError>;
    getDeviceRewardHistory: (
      deviceId: Types.ObjectId,
    ) => Promise<DeviceRewardHistory | null | MongooseError>;
    getDevicesRewardHistory: (
      params: ListDeviceRewardHistoryParams,
    ) => Promise<PaginateResult<DeviceRewardHistory> | MongooseError>;
  }

  interface RewardSettingService {
    getRewardSetting: () => Promise<RewardSetting | null | MongooseError>;
    updateRewardSetting: (
      params: UpdateRewardSettingData,
    ) => Promise<RewardSetting | MongooseError>;
  }

  export const linkedDeviceService: LinkedDeviceService;
  export const deviceRewardHistoryService: DeviceRewardHistoryService;
  export const rewardSettingService: RewardSettingService;
}
