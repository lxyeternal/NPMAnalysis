# Device Reward History

API extension for managing linked devices, device reward history and reward settings using mongoose.

## Installation

    npm i @lfi-cloudx/lfi-device-rewards

## Initialize module

    const lfiDeviceRewards = require('@lfi-cloudx/lfi-device-rewards');

    lfiDeviceRewards.setDatabaseUrl("YOUR_MONGODB_URI");

## Usage

The following lines are an examples of how to use the available services:

### Linked device service

- Created a new linked devices

```
const data = {
    userMinterId: "xxxxxxxxx",
    userId: "xxxxxxxxx",
    userLicenseId: "xxxxxxxxx",
    licenseName: "LFI-110",
    licenseNft: 12,
    nftCount: 4,
    percentage: 30,
    deviceType: "minter",
}

lfiDeviceRewards.linkedDeviceService.addLinkedDevice(data);
```

- Get linked device

```
const params = { userLicenseId, userMinterId }

lfiDeviceRewards.linkedDeviceService.getLinkedDevice(params);
```

- Update existing linked device

```
const data = {
    userMinterId: "xxxxxxxxx",
    userId: "xxxxxxxxx",
    userLicenseId: "xxxxxxxxx",
    licenseName: "LFI-110",
    licenseNft: 12,
    nftCount: 4,
    percentage: 30,
    deviceType: "minter",
}

lfiDeviceRewards.linkedDeviceService.updateLinkedDevice(data);
```

- Activate devices

```
lfiDeviceRewards.linkedDeviceService.activateLinkedDevices("user_minter_id")
```

- Deactivate devices

```
lfiDeviceRewards.linkedDeviceService.deactivateLinkedDevices("user_minter_id")
```

### Device reward history service

- Add device reward histories

```
const data = {
    userMinters: [{ id: "user_minter_id_1", percentage: 12 }, { id: "user_minter_id_2", percentage: 5 } ],
    licenseId: "user_license_id",
    licenseReward: 11,
    licenseReBuyReward: 0.7,
    licenseWithdrawReward: 0.4,
    createdAt: "create_at_date"
};

lfiDeviceRewards.deviceRewardHistoryService.addDeviceRewardHistories(data);
```

- Get device reward histories

```
const params = {
    pagination: true,
    page: 1,
    limit: 10,
    deviceIds: [ "device1_id", "device2_id", ...],
    filter: {
        fromDate: "2023-11-01T00:00:00.465Z",
        toDate: "2023-11-22T23:59:59.465Z"
    }
}

lfiDeviceRewards.deviceRewardHistoryService.getDeviceRewardHistories(params);
```

### Device Reward History Setting service

- Get reward setting

```
lfiDeviceRewards.deviceRewardHistorySettingService.getDeviceRewardHistorySetting()
```

- Create new reward setting

```
const data = {
    reBuyPercentage:60,
    withdrawPercentage: 40
};

lfiDeviceRewards.deviceRewardHistorySettingService.createDeviceRewardHistorySetting(data)
```

- Update existing reward setting

```
const data = {
    reBuyPercentage:60,
    withdrawPercentage: 40
};

lfiDeviceRewards.deviceRewardHistorySettingService.updateDeviceRewardHistorySetting(data)
```

- Delete existing reward setting

```
lfiDeviceRewards.deviceRewardHistorySettingService.deleteDeviceRewardHistorySetting()
```
