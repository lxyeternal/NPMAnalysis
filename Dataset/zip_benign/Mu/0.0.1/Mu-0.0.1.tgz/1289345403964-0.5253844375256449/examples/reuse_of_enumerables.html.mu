{{#terms}}
  {{name}}
  {{index}}
{{/terms}}
{{#terms}}
  {{name}}
  {{index}}
{{/terms}}