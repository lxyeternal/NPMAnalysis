{
  name: "Joe",
  greeting: "Welcome"
}
