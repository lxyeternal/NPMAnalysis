{{#person}}
  Name: {{name}}
{{/person}}