{{=<% %>=}}* <% first %>
* <% second %>
<%=| |=%>
* | third |
|={{ }}=|
* {{ fourth }}