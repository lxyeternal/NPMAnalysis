import { Decimal, DecimalArg } from '@phensley/decimal';
import { NumberOperands } from './operands';
import { Expr, Rule } from './types';
export type RuleMap = {
    [x: string]: Rule[];
};
export type RangeMap = number | {
    [x: number]: number;
};
export type Operand = 'n' | 'i' | 'v' | 'w' | 'f' | 't' | 'c';
/**
 * Plural operations for a given language.
 *
 * @public
 */
export interface PluralRules {
    operands(d: Decimal): NumberOperands;
    cardinal(n: DecimalArg, c?: number): string;
    ordinal(n: DecimalArg): string;
    range(start: DecimalArg, end: DecimalArg): string;
}
/**
 * Set of all cardinal and ordinal plural rules, and the array of expression
 * fragments the rules reference.
 *
 * @internal
 */
export declare class PluralRulesImpl implements PluralRules {
    private expressions;
    private cardinals;
    private ordinals;
    private ranges;
    constructor(expressions: Expr[], cardinals: Rule[], ordinals: Rule[], ranges: RangeMap);
    operands(d: Decimal): NumberOperands;
    cardinal(n: DecimalArg, c?: number): string;
    ordinal(n: DecimalArg): string;
    range(start: DecimalArg, end: DecimalArg): string;
    private evaluate;
    private execute;
}
export declare const evaluateExpr: (operands: NumberOperands, expr: Expr) => boolean;
