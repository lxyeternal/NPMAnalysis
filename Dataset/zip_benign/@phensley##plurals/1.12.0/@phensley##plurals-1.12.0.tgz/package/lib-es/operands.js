/**
 * Returns the number of digits in w, where w < RADIX.
 */
export var digitCount = function (w) {
    if (w < 10000 /* Constants.P4 */) {
        if (w < 100 /* Constants.P2 */) {
            return w < 10 /* Constants.P1 */ ? 1 : 2;
        }
        return w < 1000 /* Constants.P3 */ ? 3 : 4;
    }
    if (w < 1000000 /* Constants.P6 */) {
        return w < 100000 /* Constants.P5 */ ? 5 : 6;
    }
    return w < 10000000 /* Constants.P7 */ ? 7 : 8;
};
var POWERS10 = [
    1 /* Constants.P0 */,
    10 /* Constants.P1 */,
    100 /* Constants.P2 */,
    1000 /* Constants.P3 */,
    10000 /* Constants.P4 */,
    100000 /* Constants.P5 */,
    1000000 /* Constants.P6 */,
    10000000 /* Constants.P7 */,
    100000000 /* Constants.P8 */,
];
// When a number crosses this limit we reduce it to avoid overflow.
// This limit is chosen so that a number <= this limit multipled
// by 10 will still be < MAX_SAFE_INTEGER.
var LIMIT = 10000000000000;
var FIELDS = ['n', 'i', 'v', 'w', 'f', 't', 'c'];
/**
 * Operands for use in evaluating localized plural rules:
 * See: http://www.unicode.org/reports/tr35/tr35-numbers.html#Plural_Operand_Meanings
 *
 * symbol    value
 * ----------------
 *   n       absolute value of the source number (integer and decimals)
 *   i       integer digits of n
 *   v       number of visible fraction digits in n, with trailing zeros
 *   w       number of visible fraction digits in n, without trailing zeros
 *   f       visible fractional digits in n, with trailing zeros
 *   t       visible fractional digits in n, without trailing zeros
 *   c       compact decimal exponent value
 *   e       synonym for 'c', may be redefined in the future
 *
 * @public
 */
var NumberOperands = /** @class */ (function () {
    /**
     * Compute the plural operands for the Decimal `d` with optional compact
     * exponent `c`.
     */
    function NumberOperands(d, c) {
        if (c === void 0) { c = 0; }
        this.n = 0;
        this.i = 0;
        this.v = 0;
        this.w = 0;
        this.f = 0;
        this.t = 0;
        this.c = 0;
        var props = d.properties();
        var flag = props[3];
        if (flag) {
            return;
        }
        var data = props[0];
        var exp = props[2];
        var len = data.length;
        var last = len - 1;
        var precision = last * 7 /* Constants.RDIGITS */ + digitCount(data[last]);
        // Local operands
        var n = 0;
        var v = exp < 0 ? -exp : 0;
        var w = 0;
        var f = 0;
        var t = 0;
        // Compact decimal exponent value
        // See https://www.unicode.org/reports/tr35/tr35-numbers.html#Operands
        if (c < 0) {
            c = 0;
        }
        // Count trailing zeros
        var trail = 0;
        // Index of radix digit
        var x = last;
        // Index of decimal digit in radix digit
        var y = 0;
        var intdigits = precision + exp;
        // Leading decimal zeros aren't part of the operands.
        if (intdigits < 0) {
            intdigits = 0;
        }
        // Start at most-significant digit to least
        outer: while (x >= 0) {
            var r = data[x];
            var count = x !== last ? 7 /* Constants.RDIGITS */ : digitCount(r);
            y = count - 1;
            // Scan each decimal digit of the radix number from
            // most- to least- significant.
            while (y >= 0) {
                var p = POWERS10[y];
                var q = (r / POWERS10[y]) | 0;
                if (intdigits > 0) {
                    // Integer part
                    n = n * 10 + q;
                    // If the integer digits exceed the limit we apply modulus.
                    if (n > LIMIT) {
                        // Stay below the limit but preserve (a) the magnitude and (b) as
                        // many of the least-significant digits as possible
                        n = (n % LIMIT) + LIMIT;
                    }
                    intdigits--;
                }
                else {
                    // Decimal part
                    if (q === 0) {
                        trail++;
                    }
                    else {
                        trail = 0;
                    }
                    f = f * 10 + q;
                }
                // If the decimal digits exceed our limit we bail out early.
                if (f > LIMIT) {
                    break outer;
                }
                r %= p;
                y--;
            }
            x--;
        }
        // Trailing integer zeros
        while (exp > 0) {
            n *= 10;
            if (n > LIMIT) {
                // Stay below the limit but preserve (a) the magnitude and (b) as
                // many of the least-significant digits as possible
                n = (n % LIMIT) + LIMIT;
            }
            exp--;
        }
        // Special case for zero with exponent, e.g. '0.00'.
        if (len === 1 && data[0] === 0 && exp < 0) {
            w = 0;
        }
        else {
            w = v - trail;
            t = f;
            while (trail > 0) {
                t /= 10;
                trail--;
            }
        }
        this.n = n;
        this.i = n;
        this.v = v;
        this.w = w;
        this.f = f;
        this.t = t;
        this.c = c;
    }
    NumberOperands.prototype.toString = function () {
        var _this = this;
        return FIELDS.map(function (f) { return "".concat(f, ": ").concat(_this[f]); }).join(', ');
    };
    return NumberOperands;
}());
export { NumberOperands };
//# sourceMappingURL=operands.js.map