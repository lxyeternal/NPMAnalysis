import { Expr, Rule } from './types';
export declare const cardinalRules: {
    [x: string]: Rule[];
};
export declare const ordinalRules: {
    [x: string]: Rule[];
};
export declare const expressions: Expr[];
