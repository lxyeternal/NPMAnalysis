export { Decimal } from '@phensley/decimal';
export { pluralRules, Plurals } from './api';
export { NumberOperands } from './operands';
//# sourceMappingURL=index.js.map