import { Decimal } from '@phensley/decimal';
/**
 * Returns the number of digits in w, where w < RADIX.
 */
export declare const digitCount: (w: number) => number;
export type Operand = 'n' | 'i' | 'v' | 'w' | 'f' | 't' | 'c';
/**
 * Operands for use in evaluating localized plural rules:
 * See: http://www.unicode.org/reports/tr35/tr35-numbers.html#Plural_Operand_Meanings
 *
 * symbol    value
 * ----------------
 *   n       absolute value of the source number (integer and decimals)
 *   i       integer digits of n
 *   v       number of visible fraction digits in n, with trailing zeros
 *   w       number of visible fraction digits in n, without trailing zeros
 *   f       visible fractional digits in n, with trailing zeros
 *   t       visible fractional digits in n, without trailing zeros
 *   c       compact decimal exponent value
 *   e       synonym for 'c', may be redefined in the future
 *
 * @public
 */
export declare class NumberOperands {
    n: number;
    i: number;
    v: number;
    w: number;
    f: number;
    t: number;
    c: number;
    /**
     * Compute the plural operands for the Decimal `d` with optional compact
     * exponent `c`.
     */
    constructor(d: Decimal, c?: number);
    toString(): string;
}
