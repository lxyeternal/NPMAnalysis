export declare const pluralRanges: any;
