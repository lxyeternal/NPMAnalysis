import { coerceDecimal } from '@phensley/decimal';
import { NumberOperands } from './operands';
// Notation for categories in compact plural rules
var CATEGORIES = ['zero', 'one', 'two', 'few', 'many', 'other'];
var arg = function (n, c) {
    if (c === void 0) { c = 0; }
    return new NumberOperands(coerceDecimal(n), c);
};
/**
 * Set of all cardinal and ordinal plural rules, and the array of expression
 * fragments the rules reference.
 *
 * @internal
 */
var PluralRulesImpl = /** @class */ (function () {
    function PluralRulesImpl(expressions, cardinals, ordinals, ranges) {
        this.expressions = expressions;
        this.cardinals = cardinals;
        this.ordinals = ordinals;
        this.ranges = ranges;
    }
    PluralRulesImpl.prototype.operands = function (d) {
        return new NumberOperands(d);
    };
    PluralRulesImpl.prototype.cardinal = function (n, c) {
        if (c === void 0) { c = 0; }
        return CATEGORIES[this.evaluate(arg(n, c), this.cardinals)];
    };
    PluralRulesImpl.prototype.ordinal = function (n) {
        return CATEGORIES[this.evaluate(arg(n), this.ordinals)];
    };
    PluralRulesImpl.prototype.range = function (start, end) {
        if (typeof this.ranges === 'number') {
            return CATEGORIES[this.ranges];
        }
        var s = this.evaluate(arg(start), this.cardinals);
        var e = this.evaluate(arg(end), this.cardinals);
        var cat = this.ranges[((1 << s) << 5) + (1 << e)];
        return CATEGORIES[cat] || 'other';
    };
    PluralRulesImpl.prototype.evaluate = function (operands, rules) {
        if (rules) {
            for (var _i = 0, rules_1 = rules; _i < rules_1.length; _i++) {
                var rule = rules_1[_i];
                if (this.execute(operands, rule[1])) {
                    return rule[0];
                }
            }
        }
        return 5;
    };
    PluralRulesImpl.prototype.execute = function (operands, conditions) {
        // Evaluate each condition and OR them together.
        var len = conditions.length;
        for (var i = 0; i < len; i++) {
            var cond = conditions[i];
            // Evaluate the inner expressions and AND them together.
            var res = true;
            for (var j = 0; j < cond.length; j++) {
                var expr = this.expressions[cond[j]];
                res = res && evaluateExpr(operands, expr);
                if (!res) {
                    break;
                }
            }
            if (res) {
                return true;
            }
        }
        return false;
    };
    return PluralRulesImpl;
}());
export { PluralRulesImpl };
export var evaluateExpr = function (operands, expr) {
    var operand = expr[0];
    var n = operands[operand];
    // The N = X..Y syntax means N matches an integer from X to Y inclusive
    // Operand 'n' must always be compared as an integer, so if it has any non-zero decimal
    // parts we must set integer = false.
    var integer = operand === 'n' ? operands.w === 0 : true;
    var mod = expr[1];
    if (mod) {
        n = n % mod;
    }
    var ranges = expr[3];
    var res = false;
    for (var i = 0; i < ranges.length; i++) {
        var elem = ranges[i];
        if (typeof elem === 'number') {
            res = res || (integer && n === elem);
        }
        else {
            res = res || (integer && elem[0] <= n && n <= elem[1]);
        }
    }
    return expr[2] ? res : !res;
};
//# sourceMappingURL=rules.js.map