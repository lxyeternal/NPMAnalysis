import { PluralRules } from './rules';
/**
 * Global instance for fetching plural rules by language and region.
 *
 * @public
 */
export declare class Plurals {
    /**
     * Get the plural rules for a given language and optional region.
     */
    get(language: string, region?: string): PluralRules;
}
/**
 * Global instance for fetching plural rules by language and region.
 *
 * @public
 */
export declare const pluralRules: Plurals;
