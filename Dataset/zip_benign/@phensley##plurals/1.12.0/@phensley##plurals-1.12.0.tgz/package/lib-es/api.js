import { cardinalRules, expressions, ordinalRules } from './autogen.rules';
import { pluralRanges } from './autogen.ranges';
import { PluralRulesImpl } from './rules';
var resolve = function (r, language, region) {
    return (region ? r["".concat(language, "-").concat(region)] : undefined) || r[language] || r.root;
};
/**
 * Global instance for fetching plural rules by language and region.
 *
 * @public
 */
var Plurals = /** @class */ (function () {
    function Plurals() {
    }
    /**
     * Get the plural rules for a given language and optional region.
     */
    Plurals.prototype.get = function (language, region) {
        var cardinals = resolve(cardinalRules, language, region);
        var ordinals = resolve(ordinalRules, language, region);
        var ranges = pluralRanges[language] || pluralRanges.en;
        return new PluralRulesImpl(expressions, cardinals, ordinals, ranges);
    };
    return Plurals;
}());
export { Plurals };
/**
 * Global instance for fetching plural rules by language and region.
 *
 * @public
 */
export var pluralRules = new Plurals();
//# sourceMappingURL=api.js.map