import { accessor } from './accessor.js';
import { bin1d } from './bin1d.js';
import { dericheConfig, dericheConv1d } from './deriche.js';
import { extent as densityExtent } from './extent.js';
import { nrd } from './nrd.js';

export function density1d(data, options = {}) {
  const { adjust = 1, pad = 3, size = 512 } = options;
  const x = accessor(options.x, x => x);
  const w = accessor(options.weight, () => 1 / data.length);

  let bandwidth = options.bandwidth ?? adjust * nrd(data, x);

  const [lo, hi] = options.extent ?? densityExtent(data, x, pad * bandwidth);
  const grid = bin1d(data, x, w, lo, hi, size);
  const delta = (hi - lo) / (size - 1);

  let config = dericheConfig(bandwidth / delta);
  let result;

  function* points(x = 'x', y = 'y') {
    const result = estimator.grid();
    const scale = 1 / delta;
    for (let i = 0; i < size; ++i) {
      yield {
        [x]: lo + i * delta,
        [y]: result[i] * scale
      };
    }
  }

  const estimator = {
    [Symbol.iterator]: points,
    points,
    grid: () => result || (result = dericheConv1d(config, grid, size)),
    bandwidth(_) {
      if (arguments.length) {
        if (_ !== bandwidth) {
          bandwidth = _;
          result = null;
          config = dericheConfig(bandwidth / delta);
        }
        return estimator;
      } else {
        return bandwidth;
      }
    }
  };

  return estimator;
}
