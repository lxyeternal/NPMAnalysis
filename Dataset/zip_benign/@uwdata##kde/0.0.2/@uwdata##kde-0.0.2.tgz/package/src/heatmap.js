export function heatmap(
  grid,
  w,
  h,
  color = defaultColormap,
  [lo, hi] = [0, max(grid)],
  canvas = createCanvas(w, h)
) {
  const norm = 1 / (hi - lo);
  const ctx = canvas.getContext('2d');
  const img = ctx.getImageData(0, 0, w, h);
  const pix = img.data;

  for (let j = 0, k = 0; j < h; ++j) {
    for (let i = 0, row = (h - j - 1) * w; i < w; ++i, k += 4) {
      const v = Math.min(1, Math.max(grid[i + row] - lo, 0) * norm);
      const c = color(v);
      pix[k + 0] = c.r;
      pix[k + 1] = c.g;
      pix[k + 2] = c.b;
      pix[k + 3] = (255 * c.opacity) | 0;
    }
  }

  ctx.putImageData(img, 0, 0);
  return canvas;
}

function createCanvas(w, h) {
  if (typeof document !== 'undefined') {
    // eslint-disable-next-line no-undef
    const c = document.createElement('canvas');
    c.setAttribute('width', w);
    c.setAttribute('height', h);
    return c;
  }
  throw 'Can not create canvas instance.';
}

function max(array) {
  const n = array.length;
  let v = -Infinity;
  for (let i = 0; i < n; ++i) {
    if (array[i] > v) v = array[i];
  }
  return v;
}

function defaultColormap(f) {
  return {
    r: 70,
    g: 130,
    b: 180,
    opacity: f
  };
}
