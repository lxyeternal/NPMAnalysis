const { Transform } = require('stream');

class Filter extends Transform
{
	length = 0;
	sample_rate = false;
	constructor(stream_type, sample_rate = undefined)
	{
		super();
		switch(stream_type)
		{
			case 's8':
				this._readPacket = (buf, offset) => buf.readInt8(offset);
				this._writePacket = (buf, offset, value) => buf.writeInt8(value, offset);
				this._bytes = 1;
				this._signed = true;
				break;
			case 'u8':
				this._readPacket = (buf, offset) => buf.readUInt8(offset);
				this._writePacket = (buf, offset, value) => buf.writeUInt8(value, offset);
				this._bytes = 1;
				this._signed = false;
				break;
			case 's16le':
				this._readPacket = (buf, offset) => buf.readInt16LE(offset);
				this._writePacket = (buf, offset, value) => buf.writeInt16LE(value, offset);
				this._bytes = 2;
				this._signed = true;
				break;
			case 's16be':
			case 'u16le':
			case 'u16be':
			case 's32le':
			case 's32be':
			case 'u32le':
			case 'u32be':
			default:
				throw new Error("This PCM format is not supported (" + stream_type + ")");
		}

		this._min = this._signed ? -Math.pow(2, this._bytes*8-1) : 0;
		this._max = Math.pow(2, this._bytes*8-(this._signed ? 1 : 0))-1;
		this._borne = (x) => Math.min(this._max, Math.max(this._min, x));
		if(!isNaN(sample_rate)) this.sample_rate = sample_rate;
	}

	_transform(chunk, encoding, callback)
	{
		if(this.sample_rate !== false)
		{
			this.length += chunk.length / (this.sample_rate * 2 * this._bytes);
		}
		if(this._backwardBufferEnabled)
		{
			this._backwardBuffer = Buffer.concat([this._backwardBuffer, chunk]);
			if(this._backwardLength > 0)
			{
				const start_pos = this._backwardLength * 2 * this.sample_rate * this._bytes;
				chunk = this._backwardBuffer.subarray(start_pos);
				this._backwardLength = 0;
			}
		}
		if(this._forwardFrames > 0)
		{
			if(this._forwardFrames >= chunk.length) return;
			else {
				chunk = chunk.subarray(0, this._forwardFrames);
			}
		}
		chunk = this._f_volume(chunk);
		chunk = this._f_distortion(chunk);

		callback(null, chunk);
	}

	_volume_level = 1;
	setVolume(level)
	{
		if(isNaN(level)) this._volume_level = 1;
		else this._volume_level = level;
		return this._volume_level;
	}
	_f_volume(chunk)
	{
		if(this._volume_level === 1) return chunk;
		let new_buffer = Buffer.alloc(chunk.length, 0);
		for(let i = 0; i <= chunk.length-this._bytes; i+=this._bytes)
		{
			this._writePacket(new_buffer, i, this._borne(this._readPacket(chunk, i)*this._volume_level));
		}
		return new_buffer;
	}

	_speed = 1;
	setSpeed(level)
	{
		if(isNaN(level)) this._speed = 1;
		else this._speed = level;
		return this._speed;
	}
	_f_speed(chunk)
	{
		if(this._speed === 1) return chunk;
		const inverted_speed = (1/this._speed);
		let new_buffer = Buffer.alloc(Math.ceil((chunk.length*inverted_speed)/4)*4, 0);
		console.log(new_buffer.length / chunk.length);

		if(inverted_speed < 1)
		{
			let frame_count = 1000;
			let offset = 0;
			for(let i = 0; i < chunk.length-this._bytes*2; i+=this._bytes*2)
			{
				if(Math.floor(1000/frame_count) > Math.ceil(1000*(1-inverted_speed)))
				{
					if(offset+4 < new_buffer.length)
					{
						this._writePacket(new_buffer, offset, this._readPacket(chunk, i));
						this._writePacket(new_buffer, offset+this._bytes, this._readPacket(chunk, i+this._bytes));
						frame_count++;
						offset+=this._bytes*2;
					}
				}
				else frame_count = 1;
			}
		}
		else if(inverted_speed > 1)
		{
			let frame_count = 1000;
			let offset = 0;
			for(let i = 0; i < chunk.length-this._bytes*2; i+=this._bytes*2)
			{
				if(Math.ceil(1000/frame_count) < Math.floor(1000*(1-inverted_speed)))
				{
					this._writePacket(new_buffer, offset, this._readPacket(chunk, i));
					this._writePacket(new_buffer, offset+this._bytes, this._readPacket(chunk, i+this._bytes));
				}
				this._writePacket(new_buffer, offset, this._readPacket(chunk, i));
				this._writePacket(new_buffer, offset+this._bytes, this._readPacket(chunk, i+this._bytes));
				offset+=this._bytes*2;
				frame_count++;
			}
		}
			
		return new_buffer;
	}

	_distortion_level = 100;
	setDistortion(level)
	{
		if(isNaN(level)) this._distortion_level = 100;
		else this._distortion_level = level;
		return this._distortion_level;
	}
	_f_distortion(chunk)
	{
		if(this._distortion_level === 100) return chunk;
		const bytes_level_max = this._distortion_level * this._max / 100;
		const bytes_level_min = this._distortion_level * this._min / 100;
		//const work_zone = bytes_level*0.2;

		for(let i = 0; i < chunk.length-this._bytes*2; i+=this._bytes*2)
		{
			for(let j = 0; j < this._bytes*2; j+=this._bytes)
			{
				const x = this._readPacket(chunk, i+j);
				let x2;
				if(x > bytes_level_max)
				{
					x2 = bytes_level_max;
				}
				/*else if(x > bytes_level*0.8)
				{
					x2 = bytes_level*0.8 + work_zone*Math.log10(x*(9/work_zone));
				}*/
				else if(x < bytes_level_min)
				{
					x2 = bytes_level_min;
				}
				else x2 = x;
				this._writePacket(chunk, i+j, x2);
			}
			
		}
			
		return chunk;
	}

	_merge_streams = [];
	addStream(stream)
	{
		if(stream instanceof Filter)
		{
			this._merge_streams.push(stream);
		}
	}
	removeStream(stream)
	{
		this._merge_streams.splice(this._merge_streams.indexOf(stream), 1);
	}
	_f_merge(chunk)
	{
		if(this._merge_streams.length === 0) return chunk;
		for(let i = 0; i < chunk.length - this._bytes; i+= this._bytes)
		{
			let stream_values = this._merge_streams.slice(1).map(((e) => {
				const read_bytes = e.read(this._bytes);
				if(read_bytes === null) return null;
				return e._readPacket(read_bytes, 0);
			}).bind(this));

			stream_values = stream_values.filter(e => e !== null);
			stream_values.push(this._readPacket(chunk, i));
			const stream_sum = stream_values.reduce((acc, x) => acc + x, 0);
			this._writePacket(chunk, i, stream_sum / stream_values.length);
		}

		return chunk;
	}

	_backwardBufferEnabled = false;
	_backwardBuffer = Buffer.alloc(0);
	_backwardFrames = 0;
	_forwardFrames = 0;
	setBackwardBuffer(state)
	{
		this._backwardBufferEnabled = (state == true ? true : false);
	}
	backward(sec)
	{
		this.length -= Math.min(this.length, sec);
		this._backwardLength = this.length;
	}
	forward(sec)
	{
		this.length += sec;
		this._forwardFrames = sec * 2 * this.sample_rate * this._bytes;
	}
	//SHIT//
	static Merge(type, ...streams)
	{
		const new_stream = new Filter(type)
		streams[0].on('data', (chunk) => {
			for(let i = 0; i < chunk.length - new_stream._bytes; i+= new_stream._bytes)
			{
				let stream_values = streams.slice(1).map((e) => {
					const read_bytes = e.read(new_stream._bytes);
					if(read_bytes === null) return null;
					return e._readPacket(read_bytes, 0);
				});
				stream_values = stream_values.filter(e => e !== null);
				stream_values.push(new_stream._readPacket(chunk, i));
				let stream_sum = stream_values.reduce((acc, x) => acc + x, 0);
				new_stream._writePacket(chunk, i, stream_sum / stream_values.length);
			}
			new_stream.write(chunk);
		});
		return new_stream;
	}


	
	_fraction_resolve(x)
	{
		let result = Math.round(x*1000)
		let denom = 1000;
		let divisible = true;
		while(divisible)
		{
			if(result % 10 === 0 && denom % 10 === 0)
			{
				result /= 10;
				denom /= 10;
			}
			else if(result % 5 === 0 && denom % 5 === 0)
			{
				result /= 5;
				denom /= 5;
			}
			else if(result % 2 === 0 && denom % 2 === 0)
			{
				result /= 2;
				denom /= 2;
			}
			else divisible = false;
			
		}
		return [result, denom];
	}
}
module.exports = Filter;