(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
  typeof define === 'function' && define.amd ? define(factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, global.FlyImage = factory());
}(this, (function () { 'use strict';

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }

  var defaults = {
    modal: true,
    zIndex: 10000,
    size: 0,
    offset: 20,
    speed: 250,
    hide: true
  };

  /**
   * 获取视口大小
   */
  /**
   * 设置元素样式
   * @param {HtmlElement} el 元素
   * @param {Object} styles 样式信息
   */

  function css(el, styles) {
    Object.keys(styles).forEach(function (name) {
      el.style[name] = styles[name];
    });
  }
  /**
   * 获取元素的边界信息
   * @param {HtmlElement} el 元素
   */

  function getBounds(el) {
    var rect = el.getBoundingClientRect();
    return {
      x: rect.left,
      y: rect.top,
      w: rect.width,
      h: rect.height
    };
  }
  /**
   * 加载图片
   * @param {String} src 图片地址
   */

  function loadImage(src) {
    return new Promise(function (resolve, reject) {
      var img = new Image();

      img.onload = function () {
        setTimeout(function () {
          resolve(img);
        }, 3000);
      };

      img.onerror = function (err) {
        reject(err);
      };

      img.src = src;
      if (img.complete) return resolve(img);
    });
  }
  /**
   * 锁定/解锁页面滚动
   * @param {Boolean} lock 是否锁定
   */

  function lockBodyScroll(lock) {
    css(document.body, {
      overflow: lock ? 'hidden' : null
    });
  }
  /**
   * 获取下一个绘制帧
   * @param {Function} cb 回调
   */

  function requestAnimationFrame(cb) {
    if (window.requestAnimationFrame) {
      window.requestAnimationFrame(cb);
    } else {
      setTimeout(function () {
        cb();
      }, 16);
    }
  }
  /**
   * 获取图片的原始大小
   * @param {HtmlImageElement} img 图片
   */

  function getImageNaturalSize(img) {
    return new Promise(function (resolve, reject) {
      if (!img) return reject();
      var w = img.naturalWidth;
      var h = img.naturalHeight;

      if (w || h) {
        resolve({
          w: w,
          h: h
        });
      } else {
        loadImage(img.src).then(function (img) {
          resolve({
            w: img.width,
            h: img.height
          });
        })["catch"](function (err) {
          reject(err);
        });
      }
    });
  }

  var FlyImage = /*#__PURE__*/function () {
    function FlyImage(el, options) {
      _classCallCheck(this, FlyImage);

      if (!el || !(el instanceof HTMLImageElement)) throw new DOMError();
      this.el = el;
      this.options = Object.assign({}, defaults, options);
      this.init();
    }

    _createClass(FlyImage, [{
      key: "init",
      value: function init() {
        this.size = this.options.size < 0 ? 0 : this.options.size;
        this.handlers = {};
        this.session = null;
        this.handlers.open = this.open.bind(this);
        css(this.el, {
          cursor: 'zoom-in'
        });
        this.el.addEventListener('click', this.handlers.open);
      }
    }, {
      key: "open",
      value: function open() {
        var _this = this;

        this.opened = true;
        this.session = {}; // 锁定页面滚动

        lockBodyScroll(true); // 第一个渲染帧：遮罩层、查看层、图片初始化

        var doc = document.createDocumentFragment();

        var modalEl = this._createModal();

        var viewerEl = this._createViewer();

        var imgEl = this._createFlyImage(this.el.src);

        var bounds = getBounds(this.el);
        var sourceStyle = {
          width: "".concat(bounds.w, "px"),
          height: "".concat(bounds.h, "px"),
          transform: "translate(".concat(bounds.x, "px, ").concat(bounds.y, "px)")
        };
        css(imgEl, sourceStyle);
        viewerEl.appendChild(imgEl);
        modalEl.appendChild(viewerEl);
        doc.appendChild(modalEl);
        document.body.appendChild(doc);

        if (this.options.hide) {
          this.el.style.visibility = 'hidden';
        }

        var containerBounds = {
          x: modalEl.offsetLeft,
          y: modalEl.offsetTop,
          w: modalEl.clientWidth,
          h: modalEl.clientHeight
        };
        Object.assign(this.session, {
          modalEl: modalEl,
          viewerEl: viewerEl,
          imgEl: imgEl,
          bounds: bounds,
          sourceStyle: sourceStyle,
          containerBounds: containerBounds
        }); // 下一个渲染帧：将图片动画至屏幕中央，设置合适的大小

        requestAnimationFrame(function () {
          _this._getOriginalSize().then(function (originalSize) {
            var tw = Math.max(bounds.w, originalSize.w); // 目标宽度取展示宽度与原图宽度的较大值(可处理小图被放大展示的情况)

            var overflow = tw > containerBounds.w; // 是否超出容器

            var scale = overflow ? (containerBounds.w - _this.options.offset * 2) / bounds.w : tw / bounds.w;

            if (_this.size > 0) {
              scale = containerBounds.w * _this.size / bounds.w;
            }

            var targetSize = {
              w: bounds.w * scale,
              h: bounds.h * scale
            };
            var translate = {
              x: (containerBounds.w - bounds.w) / 2,
              y: (Math.max(containerBounds.h, targetSize.h) - bounds.h) / 2 + _this.options.offset // 注：当展示图过高时，容器实际大小为容器宽度和展示图宽度构成的区域

            };
            var targetStyle = {
              transform: "translate(".concat(translate.x, "px, ").concat(translate.y, "px) scale(").concat(scale, ")")
            };
            css(imgEl, targetStyle);
            Object.assign(_this.session, {
              originalSize: originalSize,
              targetSize: targetSize,
              targetStyle: targetStyle
            });

            _this._onOpen();
          })["catch"](function (err) {
            _this._close();
          });
        });
      }
    }, {
      key: "close",
      value: function close() {
        var _this2 = this;

        css(this.session.imgEl, this.session.sourceStyle);
        this.session.modalEl.addEventListener('transitionend', function () {
          _this2._close();
        });
      }
    }, {
      key: "destroy",
      value: function destroy() {// 资源清理
        // ...
      } // 获取原图的尺寸

    }, {
      key: "_getOriginalSize",
      value: function _getOriginalSize() {
        var _this3 = this;

        if (this.originalSize) return Promise.resolve(this.originalSize);
        return getImageNaturalSize(this.el).then(function (size) {
          _this3.originalSize = size;
          return size;
        });
      }
    }, {
      key: "_createModal",
      value: function _createModal() {
        var _this4 = this;

        var el = document.createElement('div');
        css(el, {
          position: 'fixed',
          left: 0,
          right: 0,
          top: 0,
          bottom: 0,
          zIndex: this.options.zIndex,
          backgroundColor: this.options.modal ? 'rgba(100, 100, 100, .5)' : null
        });
        el.addEventListener('click', function () {
          _this4.close();
        });
        return el;
      }
    }, {
      key: "_createViewer",
      value: function _createViewer() {
        var el = document.createElement('div');
        css(el, {
          width: '100%',
          height: '100%',
          overflow: 'auto'
        });
        return el;
      }
    }, {
      key: "_createFlyImage",
      value: function _createFlyImage() {
        var img = new Image();
        img.src = this.el.src;
        css(img, {
          cursor: 'zoom-out',
          transition: "transform ".concat(this.options.speed, "ms ease-out")
        });
        return img;
      }
    }, {
      key: "_onOpen",
      value: function _onOpen() {
        var cb = this.options.onOpen;

        if (cb) {
          cb.call(this);
        }
      }
    }, {
      key: "_close",
      value: function _close() {
        this.el.style.visibility = null;
        document.body.removeChild(this.session.modalEl);
        lockBodyScroll(false);
        this.session = null;
        this.opened = false;
      }
    }]);

    return FlyImage;
  }();

  return FlyImage;

})));
