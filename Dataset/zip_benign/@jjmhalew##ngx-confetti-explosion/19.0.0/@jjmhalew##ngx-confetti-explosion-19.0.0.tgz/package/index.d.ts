/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@jjmhalew/ngx-confetti-explosion" />
export * from './public-api';
