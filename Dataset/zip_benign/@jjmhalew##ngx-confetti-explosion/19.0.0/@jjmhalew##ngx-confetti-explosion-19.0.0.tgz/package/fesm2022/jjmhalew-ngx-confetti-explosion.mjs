import * as i0 from '@angular/core';
import { output, inject, ChangeDetectorRef, numberAttribute, Component, ChangeDetectionStrategy, Input } from '@angular/core';

const DEFAULT_COLORS = ['#FFC700', '#FF0000', '#2E3191', '#41BBC7'];
// We can use the first three bits to flag which axis to rotate on.
// x = binary 100 = decimal 4
// y = binary 010 = decimal 2
// z = binary 001 = decimal 1
// We can use dual axis rotations (a bit more realistic) by combining the above bits.
// x & y = binary 110 = decimal 6
// x & z = binary 101 = decimal 5
// y & z = binary 011 = decimal 3
const POSSIBLE_ROTATION_TRANSFORMS = 6;
const coinFlip = () => random() > 0.5;
const ROTATION_SPEED_MIN = 200; // minimum possible duration of single particle full rotation
const ROTATION_SPEED_MAX = 800; // maximum possible duration of single particle full rotation
const CRAZY_PARTICLES_FREQUENCY = 0.1; // 0-1 frequency of crazy curvy unpredictable particles
const CRAZY_PARTICLE_CRAZINESS = 0.3; // 0-1 how crazy these crazy particles are
const BEZIER_MEDIAN = 0.5; // utility for mid-point bezier curves, to ensure smooth motion paths
const abs = Math.abs, random = Math.random, mathRound = Math.round, max = Math.max;
// avoid rotation on z axis (001 = 1) for circles as it has no visual effect.
const shouldBeCircle = (rotationTransform) => rotationTransform !== 1 && coinFlip();
const round = (num, precision = 2) => mathRound((num + Number.EPSILON) * 10 ** precision) / 10 ** precision;
/**
 * The purpose of the function is to transform a value from the original range (x1 to y1) to the corresponding value in the new range (x2 to y2).
 * Example:
      const value = 50;
      const x1 = 0;
      const y1 = 100;
      const x2 = 0;
      const y2 = 1;
      const mappedValue = mapRange(value, x1, y1, x2, y2);
      console.log(mappedValue); // Output: 0.5
 * @param value
 * @param x1
 * @param y1
 * @param x2
 * @param y2
 * @returns
 */
const mapRange = (value, x1, y1, x2, y2) => ((value - x1) * (y2 - x2)) / (y1 - x1) + x2;
const rotate = (degree, amount) => degree + amount > 360 ? degree + amount - 360 : degree + amount;

class NgxConfettiExplosionComponent {
    colors = DEFAULT_COLORS;
    force = 0.5;
    duration = 3500;
    particleCount = 150;
    particleSize = 12;
    stageHeight = 800;
    stageHeightUnit = 'px';
    stageWidth = 1600;
    stageWidthUnit = 'px';
    particleShape = 'mix';
    explosionDone = output();
    particles;
    #timer;
    cdr = inject(ChangeDetectorRef);
    ngOnInit() {
        const { particleCount, colors } = this;
        this.particles = this.createParticles(particleCount, colors);
        this.#clearTimerIfExist();
        this.#timer = setTimeout(() => {
            this.particles = [];
            this.cdr.markForCheck();
            this.explosionDone.emit();
        }, this.duration);
    }
    #clearTimerIfExist() {
        if (this.#timer) {
            clearTimeout(this.#timer);
        }
    }
    ngOnDestroy() {
        this.#clearTimerIfExist();
        this.particles = [];
    }
    createParticles(count, colors) {
        return Array.from({ length: count }, (_, i) => this.createConfettiStyles((i * 360) / count, colors[i % colors.length]));
    }
    createConfettiStyles(degree, color) {
        // Crazy calculations for generating styles
        const rotationTransform = Math.round(random() * (POSSIBLE_ROTATION_TRANSFORMS - 1));
        let { duration = 3500, force = 0.5, particleShape = 'mix', particleSize = 12, stageWidth = 1600, stageWidthUnit = 'px', } = this;
        const rotation = rotationTransform.toString(2).padStart(3, '0').split('');
        const isParticleShapeNotRectangle = particleShape !== 'rectangles';
        const isParticleShapeCircles = particleShape === 'circles';
        const x1 = random() < CRAZY_PARTICLES_FREQUENCY
            ? round(random() * CRAZY_PARTICLE_CRAZINESS, 2)
            : 0;
        const isCircle = isParticleShapeNotRectangle &&
            isParticleShapeCircles || shouldBeCircle(rotationTransform);
        const styleMap = {
            '--bg-color': color,
            '--x-landing-point': mapRange(abs(rotate(degree, 90) - 180), 0, 180, -stageWidth / 2, stageWidth / 2) + stageWidthUnit,
            '--duration-chaos': duration - mathRound(random() * 1e3) + 'ms',
            '--x1': x1,
            '--x2': x1 * -1,
            '--x3': x1,
            '--x4': round(abs(mapRange(abs(rotate(degree, 90) - 180), 0, 180, -1, 1)), 4),
            // roughly how fast particle reaches end of its explosion curve
            '--y1': round(random() * BEZIER_MEDIAN, 4),
            // roughly maps to the distance particle goes before reaching free-fall
            '--y2': round(random() * force * (coinFlip() ? 1 : -1), 4),
            // roughly how soon the particle transitions from explosion to free-fall
            '--y3': BEZIER_MEDIAN,
            // roughly the ease of free-fall
            '--y4': round(max(mapRange(abs(degree - 180), 0, 180, force, -force), 0), 4),
            '--height': (isCircle ? particleSize : mathRound(random() * 2) + particleSize) +
                'px',
            '--width': (isCircle ? particleSize : mathRound(random() * 4) + particleSize / 2) +
                'px',
            '--half-rotation': rotation.map((n) => +n / 2 + ''),
            '--rotation': rotation,
            '--rotation-duration': round(random() * (ROTATION_SPEED_MAX - ROTATION_SPEED_MIN) +
                ROTATION_SPEED_MIN) + 'ms',
            '--border-radius': isCircle ? '50%' : 0,
        };
        return styleMap;
    }
    static render() {
        return `
    <div class="confetti-explosion-container" [style.--stage-height]="stageHeight + stageHeightUnit">
      @for (particle of particles; track particle) {
        <div
          class="particle"
          [style]="particle"
        >
          <div></div>
        </div>
      }
    </div>
    `;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.0", ngImport: i0, type: NgxConfettiExplosionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.0", type: NgxConfettiExplosionComponent, isStandalone: true, selector: "ngx-confetti-explosion", inputs: { colors: "colors", force: ["force", "force", numberAttribute], duration: ["duration", "duration", numberAttribute], particleCount: ["particleCount", "particleCount", numberAttribute], particleSize: ["particleSize", "particleSize", numberAttribute], stageHeight: ["stageHeight", "stageHeight", numberAttribute], stageHeightUnit: "stageHeightUnit", stageWidth: ["stageWidth", "stageWidth", numberAttribute], stageWidthUnit: "stageWidthUnit", particleShape: "particleShape" }, outputs: { explosionDone: "explosionDone" }, ngImport: i0, template: "\n    <div class=\"confetti-explosion-container\" [style.--stage-height]=\"stageHeight + stageHeightUnit\">\n      @for (particle of particles; track particle) {\n        <div\n          class=\"particle\"\n          [style]=\"particle\"\n        >\n          <div></div>\n        </div>\n      }\n    </div>\n    ", isInline: true, styles: ["@keyframes y-axis{to{transform:translate3d(0,var(--stage-height),0)}}@keyframes x-axis{to{transform:translate3d(var(--x-landing-point),0,0)}}@keyframes rotation{50%{transform:rotate3d(var(--half-rotation),180deg)}to{transform:rotate3d(var(--rotation),360deg)}}.confetti-explosion-container{width:0;height:0;overflow:visible;position:relative;z-index:1200}.particle{animation:x-axis var(--duration-chaos) forwards cubic-bezier(var(--x1),var(--x2),var(--x3),var(--x4));animation-name:x-axis}.particle>div{position:absolute;top:0;left:0;animation:y-axis var(--duration-chaos) forwards cubic-bezier(var(--y1),var(--y2),var(--y3),var(--y4));animation-name:y-axis;width:var(--width);height:var(--height)}.particle>div:before{display:block;height:100%;width:100%;content:\"\";background-color:var(--bg-color);animation:rotation var(--rotation-duration) infinite linear;animation-name:rotation;border-radius:var(--border-radius)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.0", ngImport: i0, type: NgxConfettiExplosionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ngx-confetti-explosion', template: NgxConfettiExplosionComponent.render(), standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, styles: ["@keyframes y-axis{to{transform:translate3d(0,var(--stage-height),0)}}@keyframes x-axis{to{transform:translate3d(var(--x-landing-point),0,0)}}@keyframes rotation{50%{transform:rotate3d(var(--half-rotation),180deg)}to{transform:rotate3d(var(--rotation),360deg)}}.confetti-explosion-container{width:0;height:0;overflow:visible;position:relative;z-index:1200}.particle{animation:x-axis var(--duration-chaos) forwards cubic-bezier(var(--x1),var(--x2),var(--x3),var(--x4));animation-name:x-axis}.particle>div{position:absolute;top:0;left:0;animation:y-axis var(--duration-chaos) forwards cubic-bezier(var(--y1),var(--y2),var(--y3),var(--y4));animation-name:y-axis;width:var(--width);height:var(--height)}.particle>div:before{display:block;height:100%;width:100%;content:\"\";background-color:var(--bg-color);animation:rotation var(--rotation-duration) infinite linear;animation-name:rotation;border-radius:var(--border-radius)}\n"] }]
        }], propDecorators: { colors: [{
                type: Input
            }], force: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], duration: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], particleCount: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], particleSize: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], stageHeight: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], stageHeightUnit: [{
                type: Input
            }], stageWidth: [{
                type: Input,
                args: [{ transform: numberAttribute }]
            }], stageWidthUnit: [{
                type: Input
            }], particleShape: [{
                type: Input
            }] } });

/*
 * Public API Surface of ngx-confetti-explosion
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgxConfettiExplosionComponent };
//# sourceMappingURL=jjmhalew-ngx-confetti-explosion.mjs.map
