export * from './lib/ngx-confetti-explosion.component';
