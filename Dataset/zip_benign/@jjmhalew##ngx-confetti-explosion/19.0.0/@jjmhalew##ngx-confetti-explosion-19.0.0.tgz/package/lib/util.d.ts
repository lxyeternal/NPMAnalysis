export type ParticleShape = 'mix' | 'circles' | 'rectangles';
type CssAbsoluteUnit = "cm" | "mm" | "in" | "px" | "pt" | "pc";
type CssRelativeUnit = "em" | "ex" | "ch" | "rem" | "vw" | "vh" | "vmin" | "vmax" | "%";
export type CssUnit = CssAbsoluteUnit | CssRelativeUnit;
export declare const DEFAULT_COLORS: string[];
export type Particle = {
    '--bg-color': string;
    '--x-landing-point': string;
    '--duration-chaos': string;
    '--x1': number;
    '--x2': number;
    '--x3': number;
    '--x4': number;
    '--y1': number;
    '--y2': number;
    '--y3': number;
    '--y4': number;
    '--height': string;
    '--width': string;
    '--half-rotation': string[];
    '--rotation': string[];
    '--rotation-duration': string;
    '--border-radius': string | number;
};
export declare const POSSIBLE_ROTATION_TRANSFORMS = 6;
export declare const coinFlip: () => boolean;
export declare const ROTATION_SPEED_MIN = 200;
export declare const ROTATION_SPEED_MAX = 800;
export declare const CRAZY_PARTICLES_FREQUENCY = 0.1;
export declare const CRAZY_PARTICLE_CRAZINESS = 0.3;
export declare const BEZIER_MEDIAN = 0.5;
export declare const abs: (x: number) => number, random: () => number, mathRound: (x: number) => number, max: (...values: number[]) => number;
export declare const shouldBeCircle: (rotationTransform: number) => boolean;
export declare const round: (num: number, precision?: number) => number;
/**
 * The purpose of the function is to transform a value from the original range (x1 to y1) to the corresponding value in the new range (x2 to y2).
 * Example:
      const value = 50;
      const x1 = 0;
      const y1 = 100;
      const x2 = 0;
      const y2 = 1;
      const mappedValue = mapRange(value, x1, y1, x2, y2);
      console.log(mappedValue); // Output: 0.5
 * @param value
 * @param x1
 * @param y1
 * @param x2
 * @param y2
 * @returns
 */
export declare const mapRange: (value: number, x1: number, y1: number, x2: number, y2: number) => number;
export declare const rotate: (degree: number, amount: number) => number;
export {};
