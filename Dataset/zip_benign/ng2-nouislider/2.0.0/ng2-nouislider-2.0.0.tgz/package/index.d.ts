/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ng2-nouislider" />
export * from './public-api';
