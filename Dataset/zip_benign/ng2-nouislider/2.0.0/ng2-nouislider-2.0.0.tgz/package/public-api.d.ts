export * from './lib/ng2-nouislider.component';
export * from './lib/ng2-nouislider.module';
