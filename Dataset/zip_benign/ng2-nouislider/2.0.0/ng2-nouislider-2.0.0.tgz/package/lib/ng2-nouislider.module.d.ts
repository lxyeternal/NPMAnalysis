import * as i0 from "@angular/core";
import * as i1 from "./ng2-nouislider.component";
export declare class NouisliderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NouisliderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NouisliderModule, never, [typeof i1.NouisliderComponent], [typeof i1.NouisliderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NouisliderModule>;
}
