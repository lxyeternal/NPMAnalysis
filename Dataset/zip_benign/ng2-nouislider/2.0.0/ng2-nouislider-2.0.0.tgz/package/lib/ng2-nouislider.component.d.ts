import { ElementRef, EventEmitter, OnChanges, Renderer2, NgZone, OnDestroy, SimpleChanges } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
export interface NouiFormatter {
    to(value: number): string;
    from(value: string): number;
}
export declare class DefaultFormatter implements NouiFormatter {
    to(value: number): string;
    from(value: string): number;
}
export declare class NouisliderComponent implements ControlValueAccessor, OnChanges, OnDestroy {
    private ngZone;
    private el;
    private renderer;
    slider: any;
    handles: any[];
    disabled: boolean;
    behaviour: string;
    connect: boolean[] | boolean;
    limit: number;
    min: number;
    max: number;
    snap: boolean;
    animate: boolean | boolean[];
    range: any;
    step: number;
    format: NouiFormatter;
    pageSteps: number;
    config: any;
    keyboard: boolean;
    onKeydown: any;
    tooltips: Array<any>;
    change: EventEmitter<any>;
    update: EventEmitter<any>;
    slide: EventEmitter<any>;
    set: EventEmitter<any>;
    start: EventEmitter<any>;
    end: EventEmitter<any>;
    private value;
    private onChange;
    private cleanups;
    constructor(ngZone: NgZone, el: ElementRef, renderer: Renderer2);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    toValues(values: string[]): any | any[];
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => {}): void;
    setDisabledState(isDisabled: boolean): void;
    private eventHandler;
    private defaultKeyHandler;
    private createSlider;
    static ɵfac: i0.ɵɵFactoryDeclaration<NouisliderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NouisliderComponent, "nouislider", never, { "disabled": "disabled"; "behaviour": "behaviour"; "connect": "connect"; "limit": "limit"; "min": "min"; "max": "max"; "snap": "snap"; "animate": "animate"; "range": "range"; "step": "step"; "format": "format"; "pageSteps": "pageSteps"; "config": "config"; "keyboard": "keyboard"; "onKeydown": "onKeydown"; "tooltips": "tooltips"; }, { "change": "change"; "update": "update"; "slide": "slide"; "set": "set"; "start": "start"; "end": "end"; }, never, never, true>;
}
