# void-config 1.0.4
void-config is an easy to use config creator, it let you create a INI like config with a custom separator, comments deliminator and file type.
## installation
`npm install void-config`
## why use this over JSON?
void-config is faster than traditional JSON because it does not use `JSON.parse`.
## how to use it?
```js
const Config = require('void-config');

// create a config with a seaerator, comment deliminator and file type
let config = new Config('=', '#', '.abc')

// add values then write to a file
// the first parameter is the name, the second is the value
config
    .add('numb', 10)
    // add a space between numb and comment1
    .addSpace()
    .addComment('True or false')
    .addCategory('Home')
    .add('test', true)
    .add('pog', [0, '1a', 0.5])
    .addEncryptedCategory('user')
    .addEncrypted('encrypted', 'SuckIt!')
    .write('./test.abc')

// read a config.
// return a object => {
//  numb: 10,
//  Home: { test: 'true', pog: [ 0, '1a', 0.5 ] },
//  user: { encrypted: 'SuckIt!' }
//}
let conf = config.read('./test.abc')
console.log(conf)
```