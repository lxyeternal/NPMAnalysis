export = class Config {
    constructor(seperator:string, commentSeparator:string, file_ext:string): Config

    /**
     * Add a data
     * @param key 
     * @param value 
     */
    add(key:string, value:any): Config;

    /**
     * Add a category as inner object
     * @param category 
     */
    addCategory(category: string): Config;

    /**
     * Add a encrypted category as inner object
     * @param category 
     */
    addEncryptedCategory(category: string): Config;

    /**
     * Add a line break
     */
    addSpace(): Config

    /**
     * Add an encrypted data
     * @param key 
     * @param value 
     */
    addEncrypted(key:string, value:any): Config;

    /**
     * add a comment
     * @param value 
     */
    addComment(value:any): Config;

    read(filePath:string): any;
    write(filePath:string): void;
}