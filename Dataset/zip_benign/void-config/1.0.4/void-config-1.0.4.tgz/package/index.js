const fs = require('fs')

/**
 * @param {string} file
 */
function getFile(file) {
    return fs.readFileSync(file, 'utf8')
}

/**
 * parse a string number into a number otherwise return the value untouched
 * @param {string} value
 */
function parseData(value) {
    let nb = Number(value)
    if(typeof nb === 'number' && !Number.isNaN(nb)) {
        return nb
    }
    else if(value.startsWith('[') && value.endsWith(']')) {
        let s = value.slice(1, value.length-1).split(',')
        s.forEach((v, index, arr) => {
            arr[index] = parseData(v)
        })
        return s
    }
    return value
}

class Parrot {
    /**
     * @param {string} type
     */
    constructor(type) {
        this.type = type;
    }
  
    cypress() {
        let buf1 = Buffer.from(this.type, 'utf8').toString('hex');
        let buf2 = Buffer.from(buf1, 'utf8').toString('base64url');
        return buf2;
    }

    e(v) {
        let buf1 = Buffer.from(v, 'utf8').toString('base64url');
        let buf2 = Buffer.from(buf1, 'utf8').toString('hex');
        return this.cypress()+buf2;
    }

    d(v) {
        let buf1 = Buffer.from(v.replace(this.cypress(), ''), 'hex').toString('utf8');
        let buf2 = Buffer.from(buf1, 'base64url').toString('utf8');
        return buf2;
    }
}

module.exports = class Config {

    /**
     * @type {string[]}
     */
    #lines = []

    /**
     * @type {Parrot}
     */
    #parrot = null

    /**
     * 
     * @param {string} seperator 
     * @param {string} commentSeparator 
     * @param {string} file_ext 
     */
    constructor(seperator, commentSeparator, file_ext) {
        this.seperator = seperator;
        this.commentSeparator = commentSeparator;
        this.file_ext = file_ext;
        this.#parrot = new Parrot(file_ext);
    }

    #commentValue(value) {
        return `${this.commentSeparator} ${value}`;
    }

    /**
     * @param {string} value 
     */
    addComment(value) {
        this.#lines.push(this.#commentValue(value));
        return this
    }

    /**
     * @param {string} name 
     * @param {any} value 
     */
    add(name, value) {
        if(typeof value instanceof Object) {
            throw new RangeError('Void Config does not support Object!');
        }
        else if(Array.isArray(value)) {
            this.#lines.push(`${name}${this.seperator}[${value.toString()}]`);
        }
        else {
            this.#lines.push(`${name}${this.seperator}${value}`);
        }
        return this
    }

    /**
     * Add an encrypted value.
     * @param {string} name 
     * @param {any} value 
     */
    addEncrypted(name, value) {
        return this.add(this.#parrot.e(name), this.#parrot.e(value));
    }

    addEncryptedCategory(category) {
        this.#lines.push(`[${this.#parrot.e(category)}]`);
        return this;
    }

    addCategory(category) {
        this.#lines.push(`[${category}]`);
        return this;
    }

    addSpace() {
        this.#lines.push('');
        return this;
    }

    /**
     * read a file
     * @param {string} file 
     */
    read(file) {

        // make sure the file has the correct file type
        if(!file.endsWith(this.file_ext)) {
            console.warn(`Skipping file ${file}. it does not have the right file type!`);
        }
        else {
            let obj = {};
            let tempName = '';
            let content = getFile(file).split('\n');
            for(let data of content) {

                // skipping lines that start with the comment separator or empty lines.
                if(data.startsWith(this.commentSeparator) || data == '') {
                    continue;
                }
                else if(data.startsWith('[') && data.endsWith(']')) {
                    let name = data.slice(1, data.length-1);
                    if(name.startsWith(this.#parrot.cypress())) {
                        let n = this.#parrot.d(name);
                        obj[n] = {};
                        tempName = n;
                    }
                    else {
                        obj[name] = {};
                        tempName = name;
                    }
                }
                else {
                    if(tempName == '') {
                        let split = data.split(this.seperator);
                        if(data.startsWith(this.#parrot.cypress())) {
                            obj[this.#parrot.d(split[0])] = this.#parrot.d(split[1]);
                        }
                        else {
                            obj[split[0]] = parseData(split[1]);
                        }
                    }
                    else {
                        let split = data.split(this.seperator);
                        if(data.startsWith(this.#parrot.cypress())) {
                            obj[tempName][this.#parrot.d(split[0])] = this.#parrot.d(split[1]);
                        }
                        else {
                            obj[tempName][split[0]] = parseData(split[1]);
                        }
                    }
                }
            }
            return obj
        }

    }

    /**
     * write data to a file
     * @param {string} file 
     */
    write(file) {
        fs.writeFileSync(file, this.#lines.join('\n').trim(), 'utf8');
    }

    /**
     * write data to a file only once
     * @param {string} file 
     */
     writeOnce(file) {
        if(!fs.existsSync(file)) {
            this.write(file);
        }
    }
}