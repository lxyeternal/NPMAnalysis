// import the package
const Config = require('./index')

// create a config with a seaerator, comment deliminator and file type
let config = new Config('=', '#', '.abc')

// add values then write to a file
// the first parameter is the name, the second is the value
config
    .add('numb', 10)
    // add a space between numb and comment1
    .addSpace()
    .addComment('True or false')
    .addCategory('Home')
    .add('test', true)
    .add('pog', [0, '1a', 0.5])
    .addEncryptedCategory('user')
    .addEncrypted('encrypted', 'SuckIt!')
    .write('./test.abc')

// read a config.
// return a object => { numb: 10, test: 'true', pog: [ 0, '1a', 0.5 ] } in our case
let conf = config.read('./test.abc')
console.log(conf)