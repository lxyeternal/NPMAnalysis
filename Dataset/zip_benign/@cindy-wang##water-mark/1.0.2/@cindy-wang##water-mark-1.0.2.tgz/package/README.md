# waterMark

添加水印

## NPM install
```
npm install @cindy-wang/water-mark
```

## Params config
```
{
  container = document.body,
  width = '150px',
  height = '150px',
  textAlign = 'left',
  textBaseline = 'middle',
  font = '14px Microsoft Yahei',
  fillStyle = 'rgba(184, 184, 184, 0.4)',
  content = '水印',
  rotate = '25',
  zIndex = 10000,
}
```

## Example
```Vue and React
import __canvasWM from '@cindy-wang/water-mark';

__canvasWM({
  content: "测试"
});
```