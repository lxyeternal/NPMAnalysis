export declare const isRunnerFile: (value: string) => boolean;
