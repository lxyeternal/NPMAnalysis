"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});

var child_process = require("child_process");

var path = require("path");

var fs = require("fs");

var commander = require("commander");

function _interopDefaultLegacy(e) {
    return e && typeof e === "object" && "default" in e ? e : {
        default: e
    };
}

var path__default = _interopDefaultLegacy(path);

var fs__default = _interopDefaultLegacy(fs);

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P((function(resolve) {
            resolve(value);
        }));
    }
    return new (P || (P = Promise))((function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    }));
}

function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function() {
            if (o && i >= o.length) o = void 0;
            return {
                value: o && o[i++],
                done: !o
            };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i;
    function verb(n) {
        if (g[n]) i[n] = function(v) {
            return new Promise((function(a, b) {
                q.push([ n, v, a, b ]) > 1 || resume(n, v);
            }));
        };
    }
    function resume(n, v) {
        try {
            step(g[n](v));
        } catch (e) {
            settle(q[0][3], e);
        }
    }
    function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }
    function fulfill(value) {
        resume("next", value);
    }
    function reject(value) {
        resume("throw", value);
    }
    function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
    }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", (function(e) {
        throw e;
    })), verb("return"), i[Symbol.iterator] = function() {
        return this;
    }, i;
    function verb(n, f) {
        i[n] = o[n] ? function(v) {
            return (p = !p) ? {
                value: __await(o[n](v)),
                done: n === "return"
            } : f ? f(v) : v;
        } : f;
    }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), 
    i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i);
    function verb(n) {
        i[n] = o[n] && function(v) {
            return new Promise((function(resolve, reject) {
                v = o[n](v), settle(resolve, reject, v.done, v.value);
            }));
        };
    }
    function settle(resolve, reject, d, v) {
        Promise.resolve(v).then((function(v) {
            resolve({
                value: v,
                done: d
            });
        }), reject);
    }
}

var _a, _b, _c, _d, _e, _f;

const VERSION = "0.0.0-9";

const esrunPath = path__default["default"].join(__dirname, "../node_modules/.bin/esrun");

const fileExtensions = [ ".ts", ".js" ];

const runnerExtensions = [ ".runner", ".run", ".test" ];

const SILENT_PASS = process.env.RUNNER_SILENT_PASS === "true";

const MAGENTA_BACKGROUND = "[45m%s[0m";

const RED_BACKGROUND = "[41m%s[0m";

({
    instant: (_a = parseInt(process.env.RUNNER_TIME_BENCHMARK_INSTANT || "")) !== null && _a !== void 0 ? _a : 0,
    fast: (_b = parseInt(process.env.RUNNER_TIME_BENCHMARK_FAST || "")) !== null && _b !== void 0 ? _b : 15e3,
    network: (_c = parseInt(process.env.RUNNER_TIME_BENCHMARK_NETWORK || "")) !== null && _c !== void 0 ? _c : 5e5,
    "network-slow": (_d = parseInt(process.env.RUNNER_TIME_BENCHMARK_NETWORK_SLOW || "")) !== null && _d !== void 0 ? _d : 15e5,
    "network-fast": (_e = parseInt(process.env.RUNNER_TIME_BENCHMARK_NETWORK_FAST || "")) !== null && _e !== void 0 ? _e : 3e5
});

(_f = parseInt(process.env.RUNNER_TIME_BENCHMARK_TOLERANCE || "")) !== null && _f !== void 0 ? _f : 5e3;

const isRunnerFile = value => {
    const extension = path__default["default"].extname(value);
    if (!fileExtensions.includes(extension)) {
        return false;
    }
    for (const runnerExtension of runnerExtensions) {
        const combinedExtension = runnerExtension + extension;
        const runnerRegExp = new RegExp(`${combinedExtension}$`);
        if (value.match(runnerRegExp)) {
            return true;
        }
    }
    return false;
};

function getFiles(dir) {
    return __asyncGenerator(this, arguments, (function* getFiles_1() {
        const dirents = yield __await(fs.promises.readdir(dir, {
            withFileTypes: true
        }));
        for (const dirent of dirents) {
            const res = path__default["default"].resolve(dir, dirent.name);
            if (dirent.isDirectory()) {
                yield __await(yield* __asyncDelegator(__asyncValues(getFiles(res))));
            } else {
                yield yield __await(res);
            }
        }
    }));
}

class Collector {
    constructor(runnersPath) {
        const pathValue = path__default["default"].isAbsolute(runnersPath) ? runnersPath : path__default["default"].join(process.cwd(), runnersPath);
        this.runnersPath = pathValue;
    }
    collect() {
        var e_1, _a;
        return __awaiter(this, void 0, void 0, (function*() {
            const runnersStats = fs__default["default"].statSync(this.runnersPath);
            if (runnersStats.isFile()) {
                if (isRunnerFile(this.runnersPath)) {
                    return [ this.runnersPath ];
                }
                return [];
            }
            const runnerFiles = [];
            try {
                for (var _b = __asyncValues(getFiles(this.runnersPath)), _c; _c = yield _b.next(), 
                !_c.done; ) {
                    const file = _c.value;
                    if (isRunnerFile(file)) {
                        runnerFiles.push(file);
                    }
                }
            } catch (e_1_1) {
                e_1 = {
                    error: e_1_1
                };
            } finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) yield _a.call(_b);
                } finally {
                    if (e_1) throw e_1.error;
                }
            }
            return runnerFiles;
        }));
    }
}

const collectAndRun = runPath => __awaiter(void 0, void 0, void 0, (function*() {
    var _a, _b;
    try {
        const collector = new Collector(runPath || process.cwd());
        const runners = yield collector.collect();
        for (const runner of runners) {
            try {
                if (runner.endsWith(".ts")) {
                    const esrun = child_process.exec(`${esrunPath} ${runner}`);
                    (_a = esrun.stdout) === null || _a === void 0 ? void 0 : _a.on("data", (data => {
                        console.log(data);
                    }));
                    (_b = esrun.stderr) === null || _b === void 0 ? void 0 : _b.on("data", (data => {
                        console.log(data);
                    }));
                } else {
                    require(runner);
                }
            } catch (error) {
                console.log(`\n\tcould not evaluate run in '${runner}'\n`, error);
                continue;
            }
        }
        return;
    } catch (error) {
        console.log(`\n\tcould not read runs in '${runPath}'\n`, error);
        return;
    }
}));

const run = runPaths => __awaiter(void 0, void 0, void 0, (function*() {
    if (runPaths.length === 0) {
        collectAndRun();
        return;
    }
    for (const runPath of runPaths) {
        collectAndRun(runPath);
    }
}));

var index = Object.freeze({
    __proto__: null,
    run: run
});

const main = program => __awaiter(void 0, void 0, void 0, (function*() {
    program.storeOptionsAsProperties(true);
    program.name("runner").usage("[...path]").version(VERSION, "-v, --version").action(((_, options) => __awaiter(void 0, void 0, void 0, (function*() {
        yield run(options.args || []);
    }))));
    program.parseAsync(process.argv);
}));

const cli = () => {
    main(commander.program);
};

const command = (cmd, args) => __awaiter(void 0, void 0, void 0, (function*() {
    try {
        const commandText = [ cmd, ...args ].join(" ");
        const result = child_process.execSync(commandText).toString();
        try {
            return JSON.parse(result);
        } catch (error) {
            return result;
        }
    } catch (error) {
        console.log("curl error", error);
        return;
    }
}));

const curl = args => __awaiter(void 0, void 0, void 0, (function*() {
    return command("curl", args);
}));

const runner = (prepareOrRun, run, postpare, options) => __awaiter(void 0, void 0, void 0, (function*() {
    try {
        let checks = [];
        const check = mode => (message = "", testValue, expectedValue, relationship = "==") => {
            let passed = false;
            switch (relationship) {
              case "==":
                if (testValue === expectedValue) {
                    passed = true;
                }
                break;

              case "<":
                if (testValue < expectedValue) {
                    passed = true;
                }
                break;

              case "<=":
                if (testValue <= expectedValue) {
                    passed = true;
                }
                break;

              case ">":
                if (testValue > expectedValue) {
                    passed = true;
                }
                break;

              case ">=":
                if (testValue >= expectedValue) {
                    passed = true;
                }
                break;

              default:
                break;
            }
            checks.push({
                testValue: testValue,
                expectedValue: expectedValue,
                relationship: relationship,
                passed: passed,
                message: message,
                mode: mode
            });
            return passed;
        };
        if (!run) {
            const run = prepareOrRun;
            yield run(check("run"));
        } else {
            const prepare = prepareOrRun;
            const prepared = yield prepare(check("prepare"));
            const runned = yield run(check("run"), prepared);
            if (postpare) {
                yield postpare(check("postpare"), prepared, runned);
            }
        }
        for (const check of checks) {
            const {testValue: testValue, expectedValue: expectedValue, relationship: relationship, passed: passed, message: message, mode: mode} = check;
            if (((options === null || options === void 0 ? void 0 : options.silentPass) || SILENT_PASS) && passed) {
                return;
            }
            const passedString = passed ? "passed" : "failed";
            const notString = passed ? "" : "not ";
            const testValueString = typeof testValue === "string" ? `'${testValue}'` : testValue.toString();
            const expectedValueString = typeof expectedValue === "string" ? `'${expectedValue}'` : expectedValue.toString();
            const messageString = message ? `:: ${message.toString()} ` : "";
            const colors = passed ? MAGENTA_BACKGROUND : RED_BACKGROUND;
            const modeString = `${mode} ${passedString}`;
            const logString = `${messageString}:: ${testValueString} ${notString}${relationship} ${expectedValueString}`;
            console.log(colors, modeString, logString);
        }
    } catch (error) {
        console.log("run error", error);
        return;
    }
}));

exports.cli = cli;

exports.command = command;

exports.commands = index;

exports.curl = curl;

exports["default"] = runner;
