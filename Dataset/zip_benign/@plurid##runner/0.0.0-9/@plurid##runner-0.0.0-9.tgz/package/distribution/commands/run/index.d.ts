declare const run: (runPaths: string[]) => Promise<void>;
export default run;
