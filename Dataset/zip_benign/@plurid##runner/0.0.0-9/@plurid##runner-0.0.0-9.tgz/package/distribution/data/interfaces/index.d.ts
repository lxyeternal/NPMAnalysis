export declare type Runner = <P = any, R = any>(prepareOrRun: RunnerPrepare<P> | RunnerRun<P, R>, run?: RunnerRun<P, R>, postpare?: RunnerPostpare<P, R>, options?: RunnerOptions) => Promise<void>;
export declare type RunnerPrepare<P = any> = (check: Check) => Promise<P>;
export declare type RunnerRun<P = any, R = any> = (check: Check, prepared?: P) => Promise<R>;
export declare type RunnerPostpare<P = any, R = any> = (check: Check, prepared: P, runned: R) => Promise<void>;
export interface RunnerOptions {
    silentPass?: boolean;
}
export declare type Check = (message: string, testValue: any, expectedValue: any, relationship?: CheckRelationship) => boolean;
export declare type CheckRecord = {
    testValue: any;
    expectedValue: any;
    relationship: CheckRelationship;
    passed: boolean;
    message: string | undefined;
    mode: string;
};
export declare type CheckRelationship = '==' | '<' | '<=' | '>' | '>=';
export declare type RunnerTime = 'instant' | 'fast' | 'network' | 'network-slow' | 'network-fast';
