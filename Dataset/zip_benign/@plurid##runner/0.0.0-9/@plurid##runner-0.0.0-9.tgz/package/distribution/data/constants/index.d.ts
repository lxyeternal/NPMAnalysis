export declare const VERSION = "0.0.0-9";
export declare const esrunPath: string;
export declare const fileExtensions: string[];
export declare const runnerExtensions: string[];
export declare const SILENT_PASS: boolean;
export declare const MAGENTA_BACKGROUND = "\u001B[45m%s\u001B[0m";
export declare const RED_BACKGROUND = "\u001B[41m%s\u001B[0m";
export declare const timeBenchmarkValues: {
    instant: number;
    fast: number;
    network: number;
    'network-slow': number;
    'network-fast': number;
};
export declare const timeTolerance: number;
