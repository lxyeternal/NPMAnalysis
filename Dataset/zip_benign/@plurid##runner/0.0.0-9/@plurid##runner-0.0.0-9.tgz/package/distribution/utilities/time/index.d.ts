declare const time: () => number;
export { time, };
