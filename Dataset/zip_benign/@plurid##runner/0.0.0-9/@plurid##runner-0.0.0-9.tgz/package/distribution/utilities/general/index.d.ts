declare function getFiles(dir: string): AsyncGenerator<string>;
export { getFiles, };
