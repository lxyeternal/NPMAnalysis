declare class Collector {
    private runnersPath;
    constructor(runnersPath: string);
    collect(): Promise<string[]>;
}
export default Collector;
