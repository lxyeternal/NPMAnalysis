import { Runner } from "../../data/interfaces";
declare const runner: Runner;
export default runner;
