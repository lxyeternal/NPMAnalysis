declare const command: (cmd: string, args: string[]) => Promise<any>;
export default command;
