declare const curl: (args: string[]) => Promise<any>;
export default curl;
