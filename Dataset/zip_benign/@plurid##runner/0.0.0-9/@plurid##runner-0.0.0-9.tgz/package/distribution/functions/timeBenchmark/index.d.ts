import { RunnerTime } from "../../data/interfaces";
declare const timeBenchmark: (start: number, end: number, kind?: RunnerTime, id?: string | undefined) => void;
export default timeBenchmark;
