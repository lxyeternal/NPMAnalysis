'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TextGround = undefined;

var _TextGround = require('./lib/TextGround');

var _TextGround2 = _interopRequireDefault(_TextGround);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.TextGround = _TextGround2.default;
exports.default = {
    TextGround: _TextGround2.default
};