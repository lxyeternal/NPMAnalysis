import { FactoryProvider } from '@nestjs/common';
import { StaticErrorHandlerConfiguration } from '@teamhive/node-common';
export declare type ErrorHandlerConfigurationOptions = StaticErrorHandlerConfiguration;
export declare const ErrorHandlerConfigurationToken = "teamhive:nestjs:ErrorHandlerConfigurationToken";
export declare function getErrorHandlerConfigurationProvider(optionsFactory?: () => ErrorHandlerConfigurationOptions): FactoryProvider;
