"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Pagination = void 0;
const class_validator_1 = require("class-validator");
const decorators_1 = require("../decorators");
const validators_1 = require("../validators");
class Pagination {
    constructor(defaultSortBy, options) {
        this.defaultSort = defaultSortBy;
        options.page = (options.page === undefined) ? 0 : +options.page;
        options.size = (options.size === undefined) ? 10 : +options.size;
        options.shift = (options.shift === undefined) ? 0 : +options.shift;
        if (Number(options.size) >= 0 && Number(options.page) >= 0) {
            this.page = options.page;
            this.size = options.size;
            this.shift = options.shift;
            this.offset = (this.page * this.size) + this.shift;
            if (this.offset < 0) {
                this.offset = 0;
            }
        }
        this.sortBy = options.sortBy || defaultSortBy;
        this.sortDir = options.sortDir || Pagination.defaultSortDir;
    }
    getOrderBy(options = {}) {
        const sortBy = [];
        if (this.sortByModel) {
            if (Array.isArray(this.sortByModel)) {
                sortBy.push([...this.sortByModel, this.sortBy, this.sortDir]);
            }
            else {
                sortBy.push([this.sortByModel, this.sortBy, this.sortDir]);
            }
        }
        else {
            sortBy.push([this.sortBy, this.sortDir]);
        }
        if (this.secondarySort) {
            sortBy.push(this.secondarySort);
        }
        if (options.sortById !== false) {
            const sortByKey = options.sortBy || 'id';
            sortBy.push([sortByKey, 'asc']);
        }
        return sortBy;
    }
}
Pagination.defaultSortDir = 'DESC';
__decorate([
    (0, decorators_1.HiveApiModelProperty)(`The number of page to fetch`),
    (0, validators_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], Pagination.prototype, "page", void 0);
__decorate([
    (0, decorators_1.HiveApiModelProperty)(`The number of results to fetch`),
    (0, validators_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], Pagination.prototype, "size", void 0);
__decorate([
    (0, decorators_1.HiveApiModelProperty)(`The number of results to shift the offset by`),
    (0, validators_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], Pagination.prototype, "shift", void 0);
__decorate([
    (0, decorators_1.HiveApiModelProperty)(`Property to sort by`),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], Pagination.prototype, "sortBy", void 0);
__decorate([
    (0, decorators_1.HiveApiModelProperty)(`sort direction: ASC, DESC`),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(['ASC', 'DESC']),
    __metadata("design:type", String)
], Pagination.prototype, "sortDir", void 0);
exports.Pagination = Pagination;
