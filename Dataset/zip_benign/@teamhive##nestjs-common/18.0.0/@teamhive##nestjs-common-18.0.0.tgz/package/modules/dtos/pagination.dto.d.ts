import { PaginationOptions } from '../interfaces';
import { SortDirection } from '../types';
export declare class Pagination {
    page: number;
    size: number;
    shift: number;
    sortBy: string;
    sortDir: SortDirection;
    offset: number;
    sortByModel: any;
    defaultSort: string;
    secondarySort?: any;
    static defaultSortDir: SortDirection;
    constructor(defaultSortBy: string, options: PaginationOptions);
    getOrderBy(options?: OrderBy): any[];
}
interface OrderBy {
    sortById?: boolean;
    sortBy?: string;
}
export {};
