import { Pagination } from './pagination.dto';
import { PaginationOptions } from '../interfaces';
export declare class PaginationSearch extends Pagination {
    search: string | any;
    searchTerm: string;
    constructor(defaultSortBy: string, options: PaginationOptions);
}
