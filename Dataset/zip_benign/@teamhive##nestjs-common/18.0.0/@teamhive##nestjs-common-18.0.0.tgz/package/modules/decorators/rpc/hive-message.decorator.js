"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HiveMessage = exports.RPC_OPTIONS_KEY = exports.RPC_PATTERN_KEY = void 0;
exports.RPC_PATTERN_KEY = 'loop:rpc-pattern-key';
exports.RPC_OPTIONS_KEY = 'teamhive:rpc-message-options';
function HiveMessage(messagePattern, options = {}) {
    return (target) => {
        Reflect.defineMetadata(exports.RPC_PATTERN_KEY, messagePattern, target);
        Reflect.defineMetadata(exports.RPC_OPTIONS_KEY, options, target);
    };
}
exports.HiveMessage = HiveMessage;
