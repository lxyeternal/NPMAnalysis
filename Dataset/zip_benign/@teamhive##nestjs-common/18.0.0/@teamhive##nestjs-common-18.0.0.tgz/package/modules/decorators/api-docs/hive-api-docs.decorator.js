"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HiveApiDocs = void 0;
const common_1 = require("@nestjs/common");
const constants_1 = require("@nestjs/common/constants");
const request_method_enum_1 = require("@nestjs/common/enums/request-method.enum");
const nestjs_swagger_1 = require("@teamhive/nestjs-swagger");
function HiveApiDocs(options) {
    return (target, propertyKey, descriptor) => {
        var _a;
        const method = request_method_enum_1.RequestMethod[Reflect.getMetadata(constants_1.METHOD_METADATA, descriptor.value)];
        const requiresAuth = !Reflect.getMetadata('isUnauthenticated', descriptor.value);
        (0, nestjs_swagger_1.ApiOperation)({
            summary: options.summary,
            description: options.description,
            deprecated: options.deprecated || false
        })(target, propertyKey, descriptor);
        (0, nestjs_swagger_1.ApiResponse)(Object.assign({}, options.response))(target, propertyKey, descriptor);
        (0, common_1.HttpCode)(options.response.status)(target, propertyKey, descriptor);
        (0, nestjs_swagger_1.ApiNotFoundResponse)({
            description: 'Entity Not Found'
        })(target, propertyKey, descriptor);
        (0, nestjs_swagger_1.ApiInternalServerErrorResponse)({
            description: 'Internal Server Error'
        })(target, propertyKey, descriptor);
        if (['POST', 'PUT'].includes(method)) {
            (0, nestjs_swagger_1.ApiBadRequestResponse)({
                description: 'Bad Request'
            })(target, propertyKey, descriptor);
        }
        if (requiresAuth) {
            (0, nestjs_swagger_1.ApiBearerAuth)()(target, propertyKey, descriptor);
        }
        if (((_a = options.headers) === null || _a === void 0 ? void 0 : _a.length) > 0) {
            (0, nestjs_swagger_1.ApiHeaders)(options.headers)(target, propertyKey, descriptor);
        }
    };
}
exports.HiveApiDocs = HiveApiDocs;
