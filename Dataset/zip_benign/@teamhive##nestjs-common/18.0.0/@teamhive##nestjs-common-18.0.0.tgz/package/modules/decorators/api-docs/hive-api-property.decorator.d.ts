import { ApiPropertyOptions } from "@teamhive/nestjs-swagger";
export declare function HiveApiModelProperty(description: string, metadata?: ApiPropertyOptions): PropertyDecorator;
