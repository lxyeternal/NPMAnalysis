import { ValidationError } from 'class-validator';
export declare const throwValidationErrors: (errors: ValidationError[]) => void;
