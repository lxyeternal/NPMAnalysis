import MediaPlayerWrapper from './pc/MediaPlayerWrapper'
import MMediaPlayerWrapper from './m/MMediaPlayerWrapper'
import exportUtils from './utils/ExportUtils'

const media = {
  install: function (Vue) {
    if (typeof window !== 'undefined' && window.Vue) {
      Vue = window.Vue
    }
    Vue.component('MediaPlayer', MediaPlayerWrapper)
    Vue.component('MMediaPlayer', MMediaPlayerWrapper)
  }
}
export const mediaUtils = exportUtils
export const mediaPlayer = media
