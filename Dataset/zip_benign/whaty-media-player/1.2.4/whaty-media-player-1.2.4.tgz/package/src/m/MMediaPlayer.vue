<template>
  <div :class="['m-media-player-container', {'media-pv-full-wrap': fullScreen}]"
       :style="{'--primary-color': primaryColor, 'width': width, 'height': height}"
       :ref="'mediaPlayerCon' + uniqueKey">
    <!--视频状态审核成功-->
    <div class="play-video-content-success"
         v-show="vid && playInfo.basicInfo && playInfo.basicInfo.status === '60' && !mediaPlayErrorMsg">
      <div class="pv-video-wrap" :ref="'pvVideoWrap' + uniqueKey">
        <video
          :key="vid"
          :id="'video' + uniqueKey"
          :ref="'video' + uniqueKey"
          data-setup='{}'
          class="video-js">
        </video>
        <div class="video-click-cover"
             @click="toggleControls">
          <div v-show="isAudio || (!isAudio && !played)"
               :style="`background-image: url(${poster || (playInfo.basicInfo ? playInfo.basicInfo.thumbnail : '')})`"></div>
        </div>
        <div class="pv-log-error" v-if="videoPlayError">
          <div class="pv-log-errorIcon">&#xe656;</div>
          <div class="pv-log-errormsg">{{videoPlayError}}</div>
        </div>
        <div class="pv-cover"
             v-show="showCover"
             :class="{'small': isSmallSize}"
             @click="changePlayStatus()">
          <span>&#xe80f;</span>
        </div>
      </div>
      <div class="pv-video-bottom">
        <!--操作控制按钮-->
        <div v-show="played"
             :class="['pv-controls', {'pv-controls-focus': !isPlaying || videoHoverFocus, 'small': isSmallSize}]">
          <div class="pv-controls-left">
            <button type="button"
                    v-show="isLargeSize || played"
                    class="pv-iconfont pv-iconfont-hover"
                    @click="changePlayStatus">{{isPlaying ? '&#xe619;' : '&#xe87c;'}}</button>
            <div class="pv-time-wrap" v-show="isLargeSize">
              <span class="pv-time-current">{{currentDuration | toHourMinuteSecond}}</span>
              <span class="pv-time-separator">/</span>
              <span class="pv-time-duration">{{duration | toHourMinuteSecond}}</span>
            </div>
          </div>
          <div class="pv-progress-wrap"
               :ref="'pvProgress' + uniqueKey"
               v-show="isLargeSize"
               :style="{'cursor': ban_seek === 'on' ? 'unset' : 'pointer'}">
            <!--帧信息展示-->
            <div class="pv-progress-touch-time"></div>
            <div class="pv-progress-bg">
              <!--进度条缓冲-->
              <div class="pv-progress-buffer" :style="{'width': bufferProgress + '%'}"></div>
              <!--进度条-->
              <div class="pv-progress-current">
                <div class="pv-progress-current-bg" :ref="'currentProgress' + uniqueKey"></div>
                <span class="pv-progress-target"></span>
              </div>
            </div>
          </div>
          <div class="pv-controls-right">
            <div class="pv-component-wrap"
                 v-if="isLargeSize && ((speed && speedArray && speedArray.length) || (showHd && definitionArray.length))">
              <button type="button"
                      class="pv-iconfont"
                      @click="toggleSettingDetail">&#xe608;</button>
            </div>
            <!--全屏/退出全屏按钮-->
            <div class="pv-component-wrap" v-show="played">
              <button type="button"
                      class="pv-iconfont"
                      @click="fullScreenChange">{{fullScreen ? '&#xe792;' : '&#xe7cf;'}}</button>
            </div>
          </div>
        </div>
      </div>
      <div class="play-video-controls-fixed"
           v-show="showSetting && ((speed && speedArray && speedArray.length) || (showHd && definitionArray.length))"
           @click="toggleSettingDetail">
        <!--倍速-->
        <div class="play-video-controls-fixed-item"
             v-if="speed && speedArray && speedArray.length">
          <div class="play-video-controls-fixed-item-name">{{ getLangMsg('speed') }}</div>
          <div class="play-video-controls-fixed-item-options">
            <div class="play-video-controls-fixed-item-option-value"
                 v-for="speedItem in speedArray"
                 :key="speedItem"
                 :class="{'play-video-controls-fixed-item-option-value-selected': speedNum === speedItem}"
                 @click.stop="updateVideoSpeed(speedItem)">{{speedItem}}x</div>
          </div>
        </div>
        <!--清晰度-->
        <div class="play-video-controls-fixed-item"
             v-if="showHd && definitionArray.length">
          <div class="play-video-controls-fixed-item-name">{{ getLangMsg('definition') }}</div>
          <div class="play-video-controls-fixed-item-options">
            <div class="play-video-controls-fixed-item-option-value"
                 v-for="definitionItem in definitionArray"
                 :key="definitionItem.id"
                 :class="{'play-video-controls-fixed-item-option-value-selected': definitionObj.id === definitionItem.id}"
                 @click.stop="updateVideoDefinition(definitionItem)">{{getDefinitionName(definitionItem.definition)}}</div>
          </div>
        </div>
      </div>
    </div>
    <div v-show="mediaPlayErrorMsg" class="error-hint-content">{{mediaPlayErrorMsg}}</div>
  </div>
</template>

<script>
import videoJs from 'video.js'
import videojsHlsjsSourceHandler from '@streamroot/videojs-hlsjs-plugin'
import $ajax from '../utils/ajax'
import 'video.js/dist/video-js.css'
import toHourMinuteSecond from '../filters/toHourMinuteSecond'
import RecordType from '../constants/RecordType'
import media from '../mixins/media'
import lang from '../mixins/lang'
import record from '../mixins/record'
import marquee from '../mixins/m/marquee'
import size from '../mixins/m/size'
videojsHlsjsSourceHandler.register(videoJs)
export default {
  name: 'MMediaPlayer',
  mixins: [media, lang, record, marquee, size],
  props: {
    // 音视频Id
    vid: String,
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '100%'
    },
    // 播放器语种 中文ZH 英语EN
    lang: {
      type: String,
      default: 'zh-CN'
    },
    // 播放器主题色
    primaryColor: {
      type: String,
      default: 'rgba(102,153,0,1)'
    },
    // 播放器初始音量
    initVolume: {
      type: Number,
      default: 50,
      validator: (val) => {
        return val >= 0 && val <= 100
      }
    },
    // 当speed参数值为boolean类型时，代表是否显示倍速切换的按钮
    speed: {
      type: Boolean | Array,
      default: true
    },
    // 播放器封面
    poster: String,
    // 是否自动播放
    autoplay: Boolean,
    // 是否循环播放
    loop: {
      type: Boolean,
      default: false
    },
    // 是否禁止拖拽进度至视频未播放到的位置
    ban_seek_by_limit_time: {
      type: String,
      default: 'off'
    },
    // 是否禁止拖拽进度条
    ban_seek: {
      type: String,
      default: 'off'
    },
    // 播放开始时间
    watchStartTime: Number,
    // 是否显示清晰度选择按钮
    showHd: {
      type: Boolean,
      default: true
    },
    // 默认清晰度,LD: 普清,SD: 标清,HD: 高清
    df: {
      type: String,
      default: 'SD'
    },
    viewerInfo: {
      type: Object,
      default: () => {
        return {
          id: 'userId',
          name: '用户'
        }
      }
    },
    code: {
      type: String,
      default: '欢迎观看视频'
    }
  },
  filters: {toHourMinuteSecond},
  data () {
    return {
      player: null,
      playInfo: {},
      // 是否已经点过播放，如果为false，全屏按钮不展示
      played: false,
      isPlaying: false,
      showCover: true,
      mouseFocusProgress: false,
      videoPlayError: '',
      // 缓冲进度
      bufferProgress: 0,
      // 视频总时长
      duration: 0,
      // 视频观看时长
      currentDuration: 0,
      // 视频最长观看时长
      maxWatchDuration: 0,
      // 音量
      volume: 0,
      // 倍速
      speedArray: [],
      speedNum: 1,
      // 清晰度
      definitionObj: {},
      definitionArray: [],
      // 全屏
      fullScreen: false,
      heartbeat: 60,
      playDuration: 0,
      startPosition: 0,
      // 控制操作按钮是否显示
      videoHoverFocus: false,
      videoHoverFocusTimer: null,
      showSetting: false
    }
  },
  computed: {
    uniqueKey () {
      return `_${this.vid}_${this['_uid']}`
    },
    isAudio () {
      if (this.playInfo && this.playInfo.basicInfo) {
        return this.playInfo.basicInfo.type === 'AUDIO'
      }
      return false
    }
  },
  methods: {
    progressWidth () {
      if (this.$refs['pvProgress' + this.uniqueKey]) {
        return this.$refs['pvProgress' + this.uniqueKey].clientWidth
      }
      return 0
    },
    maxWatchProgress () {
      return this.maxWatchDuration / this.duration * this.progressWidth()
    },
    toggleSettingDetail () {
      this.showSetting = !this.showSetting
    },
    initPlayVideo () {
      if (!this.player && this.videoRef) {
        this.player = videoJs(this.videoRef, {
          bigPlayButton: true,
          autoplay: this.autoplay,
          controls: false,
          loop: this.loop,
          language: this.lang,
          preload: 'auto',
          playbackRates: this.speedArray
        }, () => {
          this.player.src({
            src: this.videoUrl,
            type: 'application/x-mpegURL'
          })
          if (this.watchStartTime) {
            this.seekVideo(this.watchStartTime)
          }
          this.addVideoListener()
        })
      }
    },
    addVideoListener () {
      if (this.player) {
        this.player.on('loadeddata', (e) => {
          this.$emit('wpv-init-over')
        })
        this.player.on('durationchange', (e) => {
          this.duration = this.getDuration()
        })
        this.player.on('progress', (e) => {
          this.bufferProgress = this.player.bufferedPercent() * 100
        })
        this.player.on('firstplay', (e) => {
          this.$emit('wpv-first-play', this.vid)
        })
        // 监听播放
        this.player.on('play', () => {
          this.isPlaying = true
          this.showCover = false
          this.startPosition = this.getCurrentTime()
          // 开始播放前重新定位进度条位置
          this.setProgressWidth(this.startPosition / this.duration * 100)
          this.sendRecord(RecordType.Play)
          this.startMarqueeCodeRun()
          this.$emit('wpv-play')
        })
        // 播放中
        this.player.on('playing', () => {
        })
        // 暂停
        this.player.on('pause', () => {
          this.isPlaying = false
          this.showCover = false
          this.sendRecord(RecordType.Pause)
          this.hideMarquee()
          this.$emit('wpv-pause')
        })
        // 监听播放结束
        this.player.on('ended', () => {
          this.isPlaying = false
          this.showCover = true
          this.clearMarquee()
          this.$emit('wpv-ended')
        })
        // 监听音量修改
        this.player.on('volumechange', () => {
          this.sendRecord(RecordType.Volume)
          this.$emit('wpv-volume-change', this.volume)
        })
        // 视频跳转中
        this.player.on('seeking', () => {
        })
        // 视频跳转结束
        this.player.on('seeked', () => {
          this.sendRecord(RecordType.Progress)
          this.$emit('wpv-seeked', this.getCurrentTime())
        })
        // 监听全屏状态
        document.addEventListener('fullscreenchange', () => {
          this.fullScreen = !!document.fullscreenElement
          this.sendRecord(RecordType.Fullscreen)
          this.$emit('wpv-full-screen-change', this.fullScreen)
        })
        // 加载错误
        this.player.on('error', (e) => {
          this.isPlaying = false
          this.clearPlayRecordTimer()
          this.clearMarquee()
          this.hideMarquee()
          this.$emit('wpv-error')
        })
        // 等待数据
        this.player.on('waiting', () => {
        })
        // 视频源数据加载完成
        this.player.on('canplaythrough', () => {
        })
        // 播放时长改变
        this.player.on('timeupdate', (e) => {
          this.currentDuration = this.getCurrentTime()
          this.maxWatchDuration = Math.max(this.currentDuration, this.maxWatchDuration)
        })
      }
    },
    // 获取视频总时长（s）
    getDuration () {
      if (this.player) {
        // return this.player.duration() || 0
        if (this.playInfo.basicInfo) {
          return this.playInfo.basicInfo.duration || 0
        }
        return 0
      }
      return 0
    },
    // 获取视频播放时长（s）
    getCurrentTime () {
      if (this.player) {
        return this.player.currentTime() || 0
      }
      return 0
    },
    // 开始/暂停播放
    changePlayStatus () {
      if (this.isPlaying) {
        this.pauseVideo()
      } else {
        this.playVideo(true)
      }
    },
    // 播放
    playVideo (setAttribute) {
      if (this.player) {
        if (setAttribute) {
          const videoDom = document.querySelector(`#video${this.uniqueKey} video`)
          if (videoDom && !videoDom.hasAttribute('webkit-playsinline')) {
            videoDom.setAttribute('webkit-playsinline', 'true')
          }
          if (videoDom && !videoDom.hasAttribute('playsinline')) {
            videoDom.setAttribute('playsinline', 'true')
          }
          if (videoDom && !videoDom.hasAttribute('x-webkit-airplay')) {
            videoDom.setAttribute('x-webkit-airplay', 'true')
          }
        }
        if (!this.played) {
          this.played = true
        }
        this.player.play()
      }
    },
    // 暂停
    pauseVideo () {
      if (this.player) {
        this.player.pause()
      }
    },
    // 跳转到（s）
    seekVideo (second = 0, wrapper) {
      second = parseFloat(second)
      if (this.player && !isNaN(second)) {
        this.player.currentTime(second)
      }
    },
    // 设置视频播放音量
    setVolume (volume) {
      volume = parseFloat(volume)
      if (this.player && !isNaN(volume)) {
        // 0-1
        this.player.volume(volume / 100)
      }
    },
    // 修改视频倍速
    updateVideoSpeed (speed) {
      if (this.speedNum !== speed) {
        this.speedNum = speed
        this.player.playbackRate(speed)
        // 倍速修改，不使用videojs倍速监听原因是切换视频/修改清晰度（重新修改视频src时）需要重置播放器倍速 导致重复倍速监听回调
        this.sendRecord(RecordType.Speed)
        this.$emit('wpv-rate-change', this.speedNum)
      }
    },
    // 修改清晰度
    updateVideoDefinition (val) {
      if (!this.definitionArray.length) {
        this.definitionObj = {}
        return
      }
      if (typeof val === 'object') {
        this.definitionObj = val
      }
      if (typeof val === 'string') {
        let definitionIndex
        definitionIndex = this.definitionArray.findIndex(item => item.definition === val)
        this.definitionObj = definitionIndex === -1 ? this.definitionArray[0] : this.definitionArray[definitionIndex]
      }
      let current = this.getCurrentTime()
      this.player.src({
        src: this.videoUrl,
        type: 'application/x-mpegURL'
      })
      this.player.on('loadedmetadata', () => {
        this.seekVideo(current)
        if (this.isPlaying) {
          this.playVideo(true)
        }
        this.player.playbackRate(this.speedNum)
      })
    },
    // 全屏状态修改
    fullScreenChange () {
      if (this.fullScreen) {
        this.exitFullscreen()
      } else {
        this.enterFullScreen()
      }
    },
    // 全屏
    enterFullScreen () {
      const ele = this.$refs['mediaPlayerCon' + this.uniqueKey]
      if (ele) {
        if (ele.requestFullscreen) {
          ele.requestFullscreen()
        } else if (ele.mozRequestFullScreen) {
          ele.mozRequestFullScreen()
        } else if (ele.webkitRequestFullscreen) {
          ele.webkitRequestFullscreen()
        } else if (ele.msRequestFullscreen) {
          ele.msRequestFullscreen()
        }
      }
      const videoDom = document.querySelector(`#video${this.uniqueKey} video`)
      if (videoDom) {
        videoDom.removeAttribute('webkit-playsinline')
        videoDom.removeAttribute('playsinline')
        videoDom.removeAttribute('x-webkit-airplay')
        if (this.isPlaying) {
          this.pauseVideo()
          this.playVideo(false)
        } else {
          this.playVideo(false)
          this.pauseVideo()
        }
      }
      return true
    },
    // 退出全屏
    exitFullscreen () {
      if (document.exitFullScreen) {
        document.exitFullScreen()
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen()
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen()
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen()
      } else if (document.oRequestFullscreen) {
        document.oCancelFullScreen()
      } else {
        const videoDom = document.querySelector(`#video${this.uniqueKey} video`)
        if (videoDom && !videoDom.hasAttribute('webkit-playsinline')) {
          videoDom.setAttribute('webkit-playsinline', 'true')
        }
        if (videoDom && !videoDom.hasAttribute('playsinline')) {
          videoDom.setAttribute('playsinline', 'true')
        }
        if (videoDom && !videoDom.hasAttribute('x-webkit-airplay')) {
          videoDom.setAttribute('x-webkit-airplay', 'true')
        }
      }
      return true
    },
    videoHoverShowControls () {
      if (this.videoHoverFocusTimer) {
        clearInterval(this.videoHoverFocusTimer)
        this.videoHoverFocusTimer = null
      }
      this.videoHoverFocus = true
      this.videoHoverFocusTimer = setTimeout(() => {
        this.videoHoverFocus = false
      }, 3000)
    },
    videoHoverHideControls () {
      this.videoHoverFocus = false
    },
    toggleControls () {
      if (this.videoHoverFocus) {
        this.videoHoverHideControls()
      } else {
        this.videoHoverShowControls()
      }
    },
    // 切换播放视频，vid/options对象
    changeVid (val) {
      if (val) {
        let vid = typeof val === 'string' ? val : val.vid
        this.initData()
        this.loadPlayInfo(vid).then(() => {
          if (this.player) {
            this.player.src({
              src: this.videoUrl,
              type: 'application/x-mpegURL'
            })
            if (typeof val === 'object') {
              this.player.options = val
              this.seekVideo(val.watchStartTime)
            }
            this.player.playbackRate(typeof val === 'object' && val.speed ? val.speed : this.speedNum)
          }
        }).catch(errorMsg => {
          this.mediaPlayErrorMsg = errorMsg
        })
      }
    },
    initData () {
      this.playInfo = {}
      this.isPlaying = false
      this.showCover = true
      this.bufferProgress = 0
      this.duration = 0
      this.currentDuration = 0
      this.maxWatchDuration = 0
      this.videoPlayError = ''
      this.mediaPlayErrorMsg = ''
      this.startPosition = 0
      this.playDuration = 0
      this.marqueeInfo = null
      this.definitionObj = {}
      this.setProgressWidth(0)
      this.clearMarquee()
      this.clearPlayRecordTimer()
    },
    setProgressWidth (width = 0) {
      if (this.$refs['currentProgress' + this.uniqueKey]) {
        this.$refs['currentProgress' + this.uniqueKey].style.width = `${width.toFixed(4)}%`
      }
    },
    initPvProgress () {
      let progress = this.$refs['pvProgress' + this.uniqueKey]
      if (progress) {
        const doTouchMove = (clientX) => {
          const rightX = Math.min(Math.max(0, (clientX - progress.getBoundingClientRect().left)), this.progressWidth())
          if (this.ban_seek === 'off' &&
            (this.ban_seek_by_limit_time === 'off' || (this.ban_seek_by_limit_time === 'on' && rightX < this.maxWatchProgress()))) {
            this.setProgressWidth(rightX / this.progressWidth() * 100)
            this.seekVideo(rightX / this.progressWidth() * this.duration)
          }
        }
        progress.ontouchstart = (e) => {
          this.mouseFocusProgress = true
          const startClientX = e.touches[0].clientX
          doTouchMove(startClientX)
          progress.ontouchmove = (ev) => {
            doTouchMove(ev.touches[0].clientX)
            this.mouseFocusProgress = false
          }
          progress.ontouchcancel = (ev) => {
            doTouchMove(startClientX)
          }
        }
      }
    },
    async loadPlayInfo (vid) {
      // 获取视频信息
      return $ajax({
        url: '/api/video/play/info',
        data: {vid}
      }).then(response => {
        this.playInfo = response.data || {}
        // 设置清晰度，有默认值时显示默认清晰度 否则展示清晰度列表第一条
        if (this.playInfo.transcodeInfos && this.playInfo.transcodeInfos.length) {
          let arr = this.playInfo.transcodeInfos.filter(item => item.status === 'normal')
          if (arr.length) {
            let defaultIndex = 0
            if (this.df && arr.findIndex(item => item.definition === this.df) !== -1) {
              defaultIndex = arr.findIndex(item => item.definition === this.df)
            }
            this.definitionObj = arr[defaultIndex]
            this.definitionArray = arr.reverse()
          }
        }
        if (this.playInfo['basicInfo'] && this.playInfo['basicInfo']['status'] === '60') {
          // 如果是音频类型，修改默认封面图
          if (this.isAudio) {
            this.playInfo.basicInfo.thumbnail = 'https://app-learning.oss-cn-shanghai.aliyuncs.com/static/audio-poster.jpg'
          }
          // 准备视频跑马灯验证
          if (this.playInfo['config'] && this.playInfo['config']['marqueeUrl']) {
            this.getMarqueeInfo(vid, this.playInfo.timeStamp)
          }
        }
      }).catch(() => {
        this.setErrorCode('##004')
      })
    },
    disposePlay () {
      if (this.player) {
        this.player.dispose()
        this.player = null
      }
    }
  },
  mounted () {
    this.loadPlayInfo(this.vid).then(() => {
      this.initPlayVideo()
    })
    this.volume = this.initVolume
    if (this.speed) {
      this.speedArray = typeof this.speed === 'boolean' ? [2, 1.5, 1.2, 1, 0.5] : this.speedArray
    }
    this.$nextTick(() => {
      this.initPvProgress()
      // 监听浏览器小窗口播放
      let observer = new MutationObserver((mutations) => {
        let attributesChange = false
        mutations.forEach(mutation => {
          if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
            attributesChange = true
          }
        })
        if (attributesChange) {
          this.disposePlay()
          this.videoPlayError = this.getLangMsg('##001')
        }
      })
      observer.observe(document.querySelector('script'), {attributes: true})
    })
  },
  destroyed () {
    this.disposePlay()
    this.clearMarquee()
    this.clearPlayRecordTimer()
  },
  watch: {
    currentDuration (val) {
      if (val && !this.mouseFocusProgress && this.$refs['currentProgress' + this.uniqueKey]) {
        this.$refs['currentProgress' + this.uniqueKey].style.width = `${(this.currentDuration / this.duration * 100).toFixed(4)}%`
      }
    },
    isPlaying () {
      if (this.isPlaying) {
        if (this.isAudio) {
          this.playInfo.basicInfo.thumbnail = 'https://app-learning.oss-cn-shanghai.aliyuncs.com/static/audio-poster-dynamic.gif'
        }
      } else {
        if (this.isAudio) {
          this.playInfo.basicInfo.thumbnail = 'https://app-learning.oss-cn-shanghai.aliyuncs.com/static/audio-poster.jpg'
        }
      }
    }
  }
}
</script>

<style lang="scss">
 @import "./index.scss";
</style>
