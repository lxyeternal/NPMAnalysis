<template>
  <m-media-player :key="uniqueKey"
                  :ref="uniqueKey"
                  v-bind="$attrs"
                  v-on="$listeners"></m-media-player>
</template>

<script>

import MMediaPlayer from './MMediaPlayer'
export default {
  name: 'MMediaPlayerWrapper',
  components: {MMediaPlayer},
  computed: {
    uniqueKey () {
      return `mediaPlayerWrapper_${this.$attrs.vid}_${this['_uid']}`
    }
  },
  methods: {
    changeVid (val) {
      const wrapper = this.$refs[this.uniqueKey]
      if (wrapper) {
        wrapper.changeVid(val)
      }
    },
    getCurrentTime () {
      const wrapper = this.$refs[this.uniqueKey]
      if (wrapper) {
        return wrapper.getCurrentTime()
      }
      return 0
    },
    getDuration () {
      const wrapper = this.$refs[this.uniqueKey]
      if (wrapper) {
        return wrapper.getDuration()
      }
      return 0
    },
    pauseVideo () {
      const wrapper = this.$refs[this.uniqueKey]
      if (wrapper) {
        wrapper.pauseVideo()
      }
    },
    seekVideo (position) {
      const wrapper = this.$refs[this.uniqueKey]
      if (wrapper) {
        wrapper.seekVideo(position, true)
      }
    },
    playVideo () {
      const wrapper = this.$refs[this.uniqueKey]
      if (wrapper) {
        wrapper.playVideo(true)
      }
    },
    setVolume (val) {
      const wrapper = this.$refs[this.uniqueKey]
      if (wrapper) {
        wrapper.setVolume(val)
      }
    },
    updateVideoDefinition (val) {
      const wrapper = this.$refs[this.uniqueKey]
      if (wrapper) {
        wrapper.updateVideoDefinition(val)
      }
    },
    fullScreenChange () {
      const wrapper = this.$refs[this.uniqueKey]
      if (wrapper) {
        wrapper.fullScreenChange()
      }
    }
  }
}
</script>
