import $ajax from '../utils/ajax'
import RecordType from '../constants/RecordType'
/**
 * 播放器日志
 */
export default {
  props: {
    // 播放器语种 中文ZH 英语EN
    lang: {
      type: String,
      default: 'zh-CN'
    }
  },
  data () {
    return {
      playRecordTimer: null,
      heartbeat: 60
    }
  },
  methods: {
    clearPlayRecordTimer () {
      if (this.playRecordTimer) {
        clearInterval(this.playRecordTimer)
        this.playRecordTimer = null
      }
    },
    sendRecord (eventType) {
      try {
        if (this.player) {
          $ajax({
            url: '/api/video/play/record',
            data: {
              playId: this.tokenMap ? this.tokenMap.get(this.definitionObj.id) : '',
              vid: this.vid,
              viewerId: this.viewerInfo.id,
              viewerName: this.viewerInfo.name,
              definition: this.definitionObj.definition || '',
              speed: this.speedNum,
              playDuration: this.playDuration,
              volume: parseInt(this.volume),
              eventType,
              eventSource: 'user',
              fullscreen: this.fullScreen,
              startPosition: this.startPosition.toFixed(0),
              endPosition: this.getCurrentTime().toFixed(0)
            }
          })
          this.playDuration = 0
          this.startPosition = this.getCurrentTime()
          switch (eventType) {
            case RecordType.Play: {
              this.clearPlayRecordTimer()
              this.playRecordTimer = setInterval(() => {
                this.playDuration++
                if (this.playDuration >= this.heartbeat) {
                  this.sendRecord(RecordType.Heartbeat)
                }
              }, 1000)
              break
            }
            case RecordType.Pause: {
              this.clearPlayRecordTimer()
              break
            }
          }
        }
      } catch (error){
      }
    }
  }
}
