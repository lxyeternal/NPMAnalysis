import ResizeObserver from 'resize-observer-polyfill'
/**
 * 播放器尺寸
 */
export default {
  data () {
    return {
      isLargeSize: true,
      isSmallSize: false
    }
  },
  methods: {
    initMediaSize () {
      this.$nextTick(() => {
        const mediaRef = this.$refs['mediaPlayerCon' + this.uniqueKey]
        if (mediaRef) {
          const clientWidth = mediaRef.clientWidth
          if (clientWidth >= 300) {
            this.isLargeSize = true
            this.isSmallSize = false
          } else {
            this.isLargeSize = false
            this.isSmallSize = true
          }
        }
      })
    }
  },
  mounted () {
    this.initMediaSize()
    this.$nextTick(() => {
      // 监听播放器大小变化
      const mediaRef = this.$refs['mediaPlayerCon' + this.uniqueKey]
      new ResizeObserver(entries => {
        for (const entry of entries) {
          switch (entry.target) {
            case mediaRef :
              this.initMediaSize()
              break
          }
        }
      }).observe(mediaRef)
    })
  }
}
