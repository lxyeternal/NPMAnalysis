import $ajax from '../../utils/ajax'
import qs from 'qs'
import ElementUtils from '../../utils/ElementUtils'

/**
 * 播放器跑马灯
 */
export default {
  data () {
    return {
      marquee: null,
      marqueeTimer: null,
      marqueeInfo: null
    }
  },
  methods: {
    async getMarqueeInfo (vid, timeStamp) {
      let requestBody = `t=${timeStamp}&vid=${vid}&code=${this.code}`
      await $ajax({
        url: this.playInfo['config']['marqueeUrl'],
        data: requestBody
      }).then(marqueeRes => {
        let sign = marqueeRes.sign
        delete marqueeRes.sign
        this.marqueeInfo = marqueeRes
        // 校验跑马灯验签是否合法
        $ajax({
          url: `/api/video/play/sign?${requestBody + '&' + qs.stringify(marqueeRes)}`,
          method: 'GET'
        }).then(res => {
          if (!res.data || res.data !== sign) {
            this.marqueeInfo = null
            this.setErrorCode('##003')
          }
        })
      })
    },
    startMarqueeCodeRun () {
      if (!this.marqueeInfo) {
        this.getMarqueeInfo().then(() => {
          this.marqueeCodeRun()
        })
      } else {
        this.marqueeCodeRun()
      }
    },
    marqueeCodeRun () {
      const wrapperRef = this.$refs[`pvVideoWrap${this.uniqueKey}`]
      if (!this.marquee && wrapperRef) {
        let left = wrapperRef.clientWidth
        let top = Math.random() * wrapperRef.clientHeight
        let sign = document.createElement('o-span')
        // 从右往左所需时间ms
        let speedDuration = this.marqueeInfo.speed / 10 * 1000 / 3
        sign.setAttribute('class', 'pv-opa-tk')
        sign.innerText = this.marqueeInfo.username
        this.marquee = ElementUtils.createRandomElement(4)
        this.marquee.innerText = this.code
        this.marquee.style.cssText = `font-size:${this.marqueeInfo.fontSize || 14}px;color:${this.marqueeInfo.fontColor || '#fff'}opacity: ${this.marqueeInfo.alpha || 1};;position:absolute;white-space: nowrap;top:${top}px;left:${left}px;display: ${this.marqueeInfo.show === 'on' && this.isPlaying ? 'block' : 'none'}`
        this.marquee.animate([{
          left: `${left}px`
        }, {
          left: 0
        }], {duration: speedDuration, fill: 'forwards', easing: 'linear'})
        wrapperRef.appendChild(this.marquee)
        this.marqueeTimer = setTimeout(() => {
          this.marquee.remove()
          this.marquee = null
          this.marqueeCodeRun()
        }, speedDuration)
      } else {
        if (this.marqueeInfo.show === 'on') {
          this.marquee.style.display = 'block'
        }
      }
    },
    clearMarquee () {
      if (this.marquee) {
        this.marquee.remove()
        this.marquee = null
      }
      if (this.marqueeTimer) {
        clearInterval(this.marqueeTimer)
        this.marqueeTimer = null
      }
    },
    hideMarquee () {
      if (this.marquee) {
        this.marquee.style.display = 'none'
      }
    }
  }
}
