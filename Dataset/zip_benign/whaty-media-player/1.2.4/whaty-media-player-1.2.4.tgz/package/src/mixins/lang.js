import langObj from '../lang'
/**
 * 播放器语言
 */
export default {
  props: {
    // 播放器语种 中文ZH 英语EN
    lang: {
      type: String,
      default: 'zh-CN'
    }
  },
  data () {
    return {
      mediaPlayErrorMsg: ''
    }
  },
  methods: {
    setErrorCode (errorCode) {
      this.mediaPlayErrorMsg = this.getLangMsg(errorCode)
    },
    getLangMsg (errorCode) {
      if (langObj && langObj.hasOwnProperty(this.lang) && errorCode) {
        return langObj[this.lang][errorCode]
      }
      return ''
    }
  }
}
