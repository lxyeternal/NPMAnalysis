import ResizeObserver from 'resize-observer-polyfill'
/**
 * 播放器尺寸
 */
export default {
  data () {
    return {
      isLargeSize: true,
      isMediumSize: false,
      isSmallSize: false
    }
  },
  methods: {
    initMediaSize () {
      this.$nextTick(() => {
        const mediaRef = this.$refs['mediaPlayerCon' + this.uniqueKey]
        if (mediaRef) {
          const clientWidth = mediaRef.clientWidth
          if (clientWidth >= 450) {
            this.isLargeSize = true
            this.isMediumSize = false
            this.isSmallSize = false
          } else if (clientWidth < 450 && clientWidth >= 200) {
            this.isLargeSize = false
            this.isMediumSize = true
            this.isSmallSize = false
          } else if (clientWidth < 200) {
            this.isLargeSize = false
            this.isMediumSize = false
            this.isSmallSize = true
          }
        }
      })
    }
  },
  mounted () {
    this.initMediaSize()
    this.$nextTick(() => {
      // 监听播放器大小变化
      const mediaRef = this.$refs['mediaPlayerCon' + this.uniqueKey]
      new ResizeObserver(entries => {
        for (const entry of entries) {
          switch (entry.target) {
            case mediaRef :
              this.initMediaSize()
              break
          }
        }
      }).observe(mediaRef)
    })
  }
}
