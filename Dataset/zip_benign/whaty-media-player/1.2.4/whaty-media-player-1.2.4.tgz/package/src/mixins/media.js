import config from '../config'

export default {
  computed: {
    videoRef () {
      return this.$refs['video' + this.uniqueKey]
    },
    videoUrl () {
      return `${config.hostUrl()}/api/video/play/m3u8/${this.definitionObj.id || this.vid}.m3u8`
    }
  },
  methods: {
    getDefinitionName (definition = '') {
      switch (definition) {
        case 'LD' :
          return '普清'
        case 'SD' :
          return '标清'
        case 'HD' :
          return '高清'
        default :
          return '自动'
      }
    }
  }
}
