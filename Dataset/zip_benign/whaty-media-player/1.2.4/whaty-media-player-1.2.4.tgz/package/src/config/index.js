export default {
  hostUrl: function () {
    if (process.env.NODE_ENV === 'production') {
      // 生产环境
      return 'https://media.o-learn.cn'
    } else {
      // 测试环境
      return 'https://shc03.frp.o-learn.cn'
    }
  }
}
