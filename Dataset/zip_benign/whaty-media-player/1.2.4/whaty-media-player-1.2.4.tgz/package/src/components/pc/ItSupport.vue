<template>
  <div class="it-support-wrapper" :ref="'currentRef_' + _uid" v-show="showITSupport">
    <div>Version：v{{version}}</div>
    <div v-if="ItSupport">
      <a v-if="ItSupport.link" :href="ItSupport.link" target="_blank">{{ItSupport.text}}</a>
      <span v-else>{{ItSupport.text}}</span>
    </div>
  </div>
</template>

<script>
import {version} from '../../../package.json'

export default {
  name: 'ItSupport',
  props: {
    ItSupport: Object,
    listenerDom: HTMLDivElement
  },
  data () {
    return {
      // 是否显示版本号，技术支持等内容
      showITSupport: false
    }
  },
  computed: {
    version () {
      return version || '1.0.0'
    }
  },
  methods: {
    // 点击右键显示播放器信息
    itSupportMouseDown (e) {
      if (e.button === 2) {
        let dom = this.$refs['currentRef_' + this._uid]
        if (dom) {
          this.showITSupport = true
          dom.style.left = e.clientX + 'px'
          dom.style.top = e.clientY + 'px'
        }
      }
    }
  },
  mounted () {
    this.$nextTick(() => {
      if (this.listenerDom) {
        this.listenerDom.onclick = () => {
          this.showITSupport = false
        }
      }
    })
  }
}
</script>
