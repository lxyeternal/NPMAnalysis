export default {
  Play: 'play',
  Pause: 'pause',
  Volume: 'volume',
  Progress: 'progress',
  Fullscreen: 'fullscreen',
  Speed: 'speed',
  Heartbeat: 'heartbeat'
}
