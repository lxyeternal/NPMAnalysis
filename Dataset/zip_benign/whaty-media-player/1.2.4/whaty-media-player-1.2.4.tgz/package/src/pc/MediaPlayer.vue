<template>
  <div :class="['media-player-container', {'media-pv-full-wrap': fullScreen}]"
       :style="{'--primary-color': primaryColor, 'width': width, 'height': height}"
       :ref="'mediaPlayerCon' + uniqueKey">
    <!--视频状态审核成功-->
    <div class="play-video-content-success"
         v-show="vid && playInfo.basicInfo && playInfo.basicInfo.status === '60' && !mediaPlayErrorMsg"
         @contextmenu="(e) => e.preventDefault()"
         @mousedown="(e) => this.$refs['ITSupportRef' + this.uniqueKey].itSupportMouseDown(e)">
      <div class="pv-video-wrap"
           :ref="'pvVideoWrap' + uniqueKey"
           @mousemove="videoHoverShowControls"
           @mouseout="videoHoverHideControls">
        <video
          :ref="`video` + uniqueKey"
          :key="vid"
          class="video-js"
          data-setup='{}'
          @click="changePlayStatus">
        </video>
        <div class="pv-log-error" v-if="videoPlayError">
          <div class="pv-log-errorIcon">&#xe656;</div>
          <div class="pv-log-errormsg">{{videoPlayError}}</div>
        </div>
        <div class="pv-cover"
             v-show="showCover || isAudio"
             :style="`background-image: url(${poster || (playInfo.basicInfo ? playInfo.basicInfo.thumbnail : '')})`">
          <span v-show="showCover" @click="changePlayStatus()">&#xe87c;</span>
        </div>
      </div>
      <div class="pv-video-bottom">
        <!--进度条-->
        <div class="pv-progress-wrap"
             v-show="isLargeSize || isMediumSize"
             :style="{'cursor': ban_seek === 'on' ? 'unset' : 'pointer'}">
          <!--帧信息展示-->
          <div class="pv-progress-touch-time"></div>
          <div class="pv-progress-bg" :ref="'pvProgress' + uniqueKey">
            <!--进度条缓冲-->
            <div class="pv-progress-buffer" :style="{'width': bufferProgress + '%'}"></div>
            <!--进度条-->
            <div class="pv-progress-current">
              <div class="pv-progress-current-bg" :ref="'currentProgress' + uniqueKey"></div>
              <span class="pv-progress-target"></span>
            </div>
          </div>
        </div>
        <!--操作控制按钮-->
        <div :class="['pv-controls', {'pv-controls-focus': (!isPlaying || videoHoverFocus), 'medium': isMediumSize}]">
          <div class="pv-controls-left">
            <button type="button"
                    class="pv-iconfont pv-iconfont-hover"
                    @click="changePlayStatus">{{isPlaying ? '&#xe619;' : '&#xe87c;'}}</button>
            <div class="pv-time-wrap" v-show="!isSmallSize">
              <span class="pv-time-current">{{currentDuration | toHourMinuteSecond}}</span>
              <span class="pv-time-separator">/</span>
              <span class="pv-time-duration" v-show="duration">{{duration | toHourMinuteSecond}}</span>
            </div>
          </div>
          <div class="pv-controls-right">
            <!--倍速-->
            <div class="pv-component-wrap" v-show="isLargeSize && speedArray && speedArray.length">
              <button type="button" class="pv-iconfont text-sm" style="width: 40px">{{speedNum}}x</button>
              <div class="pv-control-wrap-style">
                <div class="pv-control-wrap-style-content">
                  <div v-for="speedItem in speedArray"
                       :key="speedItem"
                       :data-rate="speedItem"
                       :class="['pv-select-option', {'pv-select-option-active': speedNum === speedItem}]"
                       @click="updateVideoSpeed(speedItem)">
                    {{speedItem}}x
                  </div>
                </div>
              </div>
            </div>
            <!--清晰度-->
            <div class="pv-component-wrap" v-show="isLargeSize">
              <button type="button" class="pv-iconfont text-sm">{{getDefinitionName(definitionObj.definition)}}</button>
              <div class="pv-control-wrap-style" v-if="showHd && definitionArray.length">
                <div class="pv-control-wrap-style-content">
                  <div v-for="definitionItem in definitionArray"
                       :key="definitionItem.id"
                       :class="['pv-select-option', {'pv-select-option-active': definitionObj.id === definitionItem.id}]"
                       @click="updateVideoDefinition(definitionItem)">
                    {{getDefinitionName(definitionItem.definition)}}
                  </div>
                </div>
              </div>
            </div>
            <!--音量-->
            <div class="pv-component-wrap" v-show="isLargeSize">
              <button type="button" class="pv-iconfont">{{volume ? '&#xe657;' : '&#xe650;'}}</button>
              <div class="pv-control-wrap-style">
                <div class="pv-control-wrap-style-content pv-volume-slider">
                  <div class="pv-volume-rail" :ref="'volumeProgress' + uniqueKey">
                    <div class="pv-volume-current" :style="[{'height': `${volume}%`}]">
                      <span class="pv-volume-target"></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!--全屏/退出全屏按钮-->
            <div class="pv-component-wrap">
              <button type="button"
                      class="pv-iconfont full-screen-icon"
                      @click="fullScreenChange">{{fullScreen ? '&#xe792;' : '&#xe7cf;'}}</button>
              <div class="pv-control-wrap-style">
                <div class="pv-control-wrap-style-content pv-fullscreen-tip">
                  {{fullScreen ? '退出全屏' : '全屏'}}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <ItSupport v-bind="$attrs"
                 :key="uniqueKey"
                 :listener-dom="$refs['mediaPlayerCon' + uniqueKey]"
                 :ref="'ITSupportRef' + uniqueKey"></ItSupport>
    </div>
    <div v-show="mediaPlayErrorMsg" class="error-hint-content">{{mediaPlayErrorMsg}}</div>
  </div>
</template>

<script>
import videoJs from 'video.js'
import videojsHlsjsSourceHandler from '@streamroot/videojs-hlsjs-plugin'
import $ajax from '../utils/ajax'
import 'video.js/dist/video-js.css'
import toHourMinuteSecond from '../filters/toHourMinuteSecond'
import RecordType from '../constants/RecordType'
import media from '../mixins/media'
import lang from '../mixins/lang'
import record from '../mixins/record'
import marquee from '../mixins/pc/marquee'
import size from '../mixins/pc/size'
import ItSupport from '../components/pc/ItSupport'
videojsHlsjsSourceHandler.register(videoJs)
export default {
  name: 'MediaPlayer',
  components: {ItSupport},
  mixins: [media, lang, record, marquee, size],
  props: {
    // 音视频Id
    vid: String,
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '100%'
    },
    // 播放器主题色
    primaryColor: {
      type: String,
      default: 'rgba(102,153,0,1)'
    },
    // 播放器初始音量
    initVolume: {
      type: Number,
      default: 50,
      validator: (val) => {
        return val >= 0 && val <= 100
      }
    },
    // 当speed参数值为boolean类型时，代表是否显示倍速切换的按钮
    speed: {
      type: Boolean | Array,
      default: true
    },
    // 播放器封面
    poster: String,
    // 是否自动播放
    autoplay: Boolean,
    // 是否循环播放
    loop: {
      type: Boolean,
      default: false
    },
    // 是否禁止拖拽进度至视频未播放到的位置
    ban_seek_by_limit_time: {
      type: String,
      default: 'off'
    },
    // 是否禁止拖拽进度条
    ban_seek: {
      type: String,
      default: 'off'
    },
    // 播放开始时间
    watchStartTime: Number,
    // 是否显示清晰度选择按钮
    showHd: {
      type: Boolean,
      default: true
    },
    // 默认清晰度,LD: 普清,SD: 标清,HD: 高清
    df: {
      type: String,
      default: 'SD'
    },
    viewerInfo: {
      type: Object,
      default: () => {
        return {
          id: 'userId',
          name: '用户'
        }
      }
    },
    playSafeUrl: {
      type: String,
      required: true
    },
    playSafeData: Object,
    code: {
      type: String,
      default: '欢迎观看本视频'
    }
  },
  filters: {toHourMinuteSecond},
  data () {
    return {
      player: null,
      playInfo: {},
      isPlaying: false,
      showCover: true,
      mouseFocusProgress: false,
      videoPlayError: '',
      // 缓冲进度
      bufferProgress: 0,
      // 视频总时长
      duration: 0,
      // 视频观看时长
      currentDuration: 0,
      // 视频最长观看时长
      maxWatchDuration: 0,
      // 音量
      volume: 0,
      // 倍速
      speedArray: [],
      speedNum: 1,
      // 清晰度
      definitionObj: {},
      definitionArray: [],
      // 全屏
      fullScreen: false,
      playDuration: 0,
      startPosition: 0,
      // 控制操作按钮是否显示
      videoHoverFocus: false,
      videoHoverFocusTimer: null,
      tokenMap: new Map()
    }
  },
  computed: {
    uniqueKey () {
      return `_${this.vid}_${this['_uid']}`
    },
    isAudio () {
      if (this.playInfo && this.playInfo.basicInfo) {
        return this.playInfo.basicInfo.type === 'AUDIO'
      }
      return false
    }
  },
  methods: {
    progressWidth () {
      if (this.$refs['pvProgress' + this.uniqueKey]) {
        return this.$refs['pvProgress' + this.uniqueKey].clientWidth
      }
      return 0
    },
    maxWatchProgress () {
      return this.maxWatchDuration / this.duration * this.progressWidth()
    },
    initPlayVideo () {
      if (!this.player && this.videoRef) {
        this.player = videoJs(this.videoRef, {
          bigPlayButton: true,
          autoplay: this.autoplay,
          controls: false,
          loop: this.loop,
          language: this.lang,
          preload: 'auto',
          playbackRates: this.speedArray,
          html5: {
            hlsjsConfig: {
              xhrSetup: (xhr, url) => {
                if (url.includes('/api/video/play/m3u8')) {
                  // 请求m3u8文件，带上设备类型
                  url = `${url}?deviceType=pc`
                } else if (url.includes('/api/video/play/key')) {
                  // 请求解锁ts文件密钥，需要带上token
                  const id = url.substring(url.lastIndexOf('/') + 1)
                  url = `${url}?deviceType=pc&token=${this.tokenMap.get(id)}`
                }
                xhr.open('GET', url, true)
              }
            }
          }
        }, () => {
          this.player.src({
            token: this.tokenMap.get(this.definitionObj.id),
            src: this.videoUrl,
            type: 'application/x-mpegURL'
          })
          if (this.watchStartTime) {
            this.seekVideo(this.watchStartTime)
          }
          this.addVideoListener()
        })
      }
    },
    addVideoListener () {
      if (this.player) {
        this.player.on('loadeddata', (e) => {
          this.$emit('wpv-init-over')
        })
        this.player.on('durationchange', (e) => {
          this.duration = this.getDuration()
        })
        this.player.on('progress', (e) => {
          this.bufferProgress = this.player.bufferedPercent() * 100
        })
        this.player.on('firstplay', (e) => {
          this.$emit('wpv-first-play', this.vid)
        })
        // 监听播放
        this.player.on('play', () => {
          this.isPlaying = true
          this.showCover = false
          this.startPosition = this.getCurrentTime()
          this.sendRecord(RecordType.Play)
          this.startMarqueeCodeRun()
          this.$emit('wpv-play')
        })
        // 监听暂停
        this.player.on('pause', () => {
          this.isPlaying = false
          this.showCover = false
          this.sendRecord(RecordType.Pause)
          this.hideMarquee()
          this.$emit('wpv-pause')
        })
        // 监听播放结束
        this.player.on('ended', () => {
          this.isPlaying = false
          this.showCover = true
          this.clearMarquee()
          this.clearPlayRecordTimer()
          this.$emit('wpv-ended')
        })
        // 监听音量修改
        this.player.on('volumechange', () => {
          this.sendRecord(RecordType.Volume)
          this.$emit('wpv-volume-change', this.volume)
        })
        // 监听用户拖动进度修改
        this.player.on('seeked', () => {
          this.sendRecord(RecordType.Progress)
          this.$emit('wpv-seeked', this.getCurrentTime())
        })
        // 监听全屏状态
        document.addEventListener('fullscreenchange', () => {
          this.fullScreen = !!document.fullscreenElement
          this.sendRecord(RecordType.Fullscreen)
          this.$emit('wpv-full-screen-change', this.fullScreen)
        })
        // 播放器加载错误
        this.player.on('error', (e) => {
          this.isPlaying = false
          this.clearPlayRecordTimer()
          this.clearMarquee()
          this.hideMarquee()
          this.$emit('wpv-error')
        })
        this.player.on('timeupdate', (e) => {
          this.currentDuration = this.getCurrentTime()
          this.maxWatchDuration = Math.max(this.currentDuration, this.maxWatchDuration)
        })
      }
    },
    // 获取视频总时长（s）
    getDuration () {
      if (this.player) {
        // return this.player.duration() || 0
        if (this.playInfo.basicInfo) {
          return this.playInfo.basicInfo.duration || 0
        }
        return 0
      }
      return 0
    },
    // 获取视频播放时长（s）
    getCurrentTime () {
      if (this.player) {
        return this.player.currentTime() || 0
      }
      return 0
    },
    // 开始/暂停播放
    changePlayStatus () {
      if (this.isPlaying) {
        this.pauseVideo()
      } else {
        this.playVideo()
      }
    },
    // 播放
    playVideo () {
      if (this.player) {
        this.player.play()
      }
    },
    // 暂停
    pauseVideo () {
      if (this.player) {
        this.player.pause()
      }
    },
    // 跳转到（s）
    seekVideo (second = 0) {
      second = parseFloat(second)
      if (this.player && !isNaN(second)) {
        this.player.currentTime(second)
      }
    },
    // 设置视频播放音量
    setVolume (volume) {
      volume = parseFloat(volume)
      if (this.player && !isNaN(volume)) {
        this.player.volume(volume / 100)
      }
    },
    // 修改视频倍速
    updateVideoSpeed (speed) {
      if (this.speedNum !== speed) {
        this.speedNum = speed
        this.player.playbackRate(speed)
        // 倍速修改，不使用videojs倍速监听原因是切换视频/修改清晰度（重新修改视频src时）需要重置播放器倍速 导致重复倍速监听回调
        this.sendRecord(RecordType.Speed)
        this.$emit('wpv-rate-change', this.speedNum)
      }
    },
    // 修改清晰度
    updateVideoDefinition (val) {
      if (!this.definitionArray.length) {
        this.definitionObj = {}
        return
      }
      const preId = this.definitionObj.id
      this.definitionObj = val
      this.tokenMap.set(this.definitionObj.id, this.tokenMap.get(preId))
      let current = this.getCurrentTime()
      this.player.src({
        src: this.videoUrl,
        type: 'application/x-mpegURL'
      })
      this.player.on('loadedmetadata', () => {
        this.seekVideo(current)
        if (this.isPlaying) {
          this.playVideo()
        }
        this.player.playbackRate(this.speedNum)
      })
    },
    // 全屏状态修改
    fullScreenChange () {
      if (this.fullScreen) {
        this.exitFullscreen()
      } else {
        this.enterFullScreen()
      }
    },
    // 全屏
    enterFullScreen () {
      const ele = this.$refs['mediaPlayerCon' + this.uniqueKey]
      if (ele) {
        let callback
        if (ele.requestFullscreen) {
          callback = ele.requestFullscreen()
        } else if (ele.mozRequestFullScreen) {
          callback = ele.mozRequestFullScreen()
        } else if (ele.webkitRequestFullscreen) {
          callback = ele.webkitRequestFullscreen()
        } else if (ele.msRequestFullscreen) {
          callback = ele.msRequestFullscreen()
        }
        // 进入全屏后的回调，有兼容问题
        if (callback && typeof callback === 'object' && callback.then) {
          callback.then(() => {
          })
        }
      }
      return true
    },
    // 退出全屏
    exitFullscreen () {
      let callback
      if (document.exitFullScreen) {
        callback = document.exitFullScreen()
      } else if (document.mozCancelFullScreen) {
        callback = document.mozCancelFullScreen()
      } else if (document.webkitExitFullscreen) {
        callback = document.webkitExitFullscreen()
      } else if (document.msExitFullscreen) {
        callback = document.msExitFullscreen()
      } else if (document.oRequestFullscreen) {
        callback = document.oCancelFullScreen()
      }
      // 退出全屏后的回调，有兼容问题
      if (callback && typeof callback === 'object' && callback.then) {
        callback.then(() => {
        })
      }
      return true
    },
    videoHoverShowControls () {
      if (this.videoHoverFocusTimer) {
        clearInterval(this.videoHoverFocusTimer)
        this.videoHoverFocusTimer = null
      }
      this.videoHoverFocus = true
      this.videoHoverFocusTimer = setTimeout(() => {
        this.videoHoverFocus = false
      }, 3000)
    },
    videoHoverHideControls () {
      this.videoHoverFocus = false
    },
    // 切换播放视频，vid/options对象
    changeVid (val) {
      if (val) {
        let vid = typeof val === 'string' ? val : val.vid
        this.initData()
        this.loadPlayInfo(vid).then(() => {
          if (this.player) {
            this.player.src({
              src: this.videoUrl,
              type: 'application/x-mpegURL'
            })
            if (typeof val === 'object') {
              this.player.options = val
              this.seekVideo(val.watchStartTime)
            }
            this.player.playbackRate(typeof val === 'object' && val.speed ? val.speed : this.speedNum)
          }
        }).catch(() => {
          this.setErrorCode('60')
        })
      }
    },
    initData () {
      this.playInfo = {}
      this.isPlaying = false
      this.showCover = true
      this.bufferProgress = 0
      this.duration = 0
      this.currentDuration = 0
      this.maxWatchDuration = 0
      this.videoPlayError = ''
      this.mediaPlayErrorMsg = ''
      this.startPosition = 0
      this.playDuration = 0
      this.definitionObj = {}
      this.setProgressWidth(0)
      this.clearMarquee()
      this.clearPlayRecordTimer()
    },
    setProgressWidth (width = 0) {
      if (this.$refs['currentProgress' + this.uniqueKey]) {
        this.$refs['currentProgress' + this.uniqueKey].style.width = `${width.toFixed(4)}%`
      }
    },
    initPvProgress () {
      let progress = this.$refs['pvProgress' + this.uniqueKey]
      if (progress) {
        let startX = 0
        const getRightX = (x = 0) => {
          x = x - startX
          return Math.min(Math.max(0, x), this.progressWidth())
        }
        const isSeek = (x) => {
          return this.ban_seek === 'off' && (this.ban_seek_by_limit_time === 'off' || (this.ban_seek_by_limit_time === 'on' && getRightX(x) < this.maxWatchProgress()))
        }
        progress.onmousedown = (e) => {
          this.mouseFocusProgress = true
          startX = progress.getBoundingClientRect().left
          if (isSeek(e.clientX)) {
            this.setProgressWidth((getRightX(e.clientX) / this.progressWidth()) * 100)
          }
          document.onmousemove = (ev) => {
            ev.preventDefault()
            ev.stopPropagation()
            if (isSeek(ev.clientX)) {
              this.setProgressWidth((getRightX(ev.clientX) / this.progressWidth()) * 100)
            }
          }
          document.onmouseup = (eu) => {
            this.mouseFocusProgress = false
            document.onmousemove = null
            document.onmouseup = null
            if (isSeek(eu.clientX) && this.player) {
              let changeWatchTime = getRightX(eu.clientX) / this.progressWidth() * this.duration
              this.seekVideo(changeWatchTime)
            }
          }
        }
      }
    },
    initPvVolumeProgress () {
      let volumeProgress = this.$refs['volumeProgress' + this.uniqueKey]
      if (volumeProgress) {
        let startY = 0
        const getRightY = (x = 0) => {
          x = x - startY
          return Math.max(Math.min(100 - x, 100), 0)
        }
        volumeProgress.onmousedown = (e) => {
          startY = volumeProgress.getBoundingClientRect().top
          this.volume = getRightY(e.clientY)
          document.onmousemove = (ev) => {
            ev.preventDefault()
            ev.stopPropagation()
            this.volume = getRightY(ev.clientY)
          }
          document.onmouseup = (eu) => {
            document.onmousemove = null
            document.onmouseup = null
            this.volume = getRightY(eu.clientY)
            this.setVolume(this.volume)
          }
        }
      }
    },
    async loadPlayInfo (vid) {
      return $ajax({
        url: '/api/video/play/info',
        data: {vid}
      }).then(response => {
        this.playInfo = response.data || {}
        // 设置清晰度，有默认值时显示默认清晰度 否则展示清晰度列表第一条
        if (this.playInfo.transcodeInfos && this.playInfo.transcodeInfos.length) {
          let arr = this.playInfo.transcodeInfos.filter(item => item.status === 'normal')
          if (arr.length) {
            let defaultIndex = 0
            if (this.df && arr.findIndex(item => item.definition === this.df) !== -1) {
              defaultIndex = arr.findIndex(item => item.definition === this.df)
            }
            this.definitionObj = arr[defaultIndex]
            this.definitionArray = arr.reverse()
          }
        }
        if (this.playInfo['basicInfo'] && this.playInfo['basicInfo']['status'] === '60') {
          if (this.isAudio) {
            this.playInfo.basicInfo.thumbnail = 'https://app-learning.oss-cn-shanghai.aliyuncs.com/static/audio-poster.jpg'
          }
          // 准备视频跑马灯验证
          if (this.playInfo['config'] && this.playInfo['config']['marqueeUrl']) {
            this.getMarqueeInfo(vid, this.playInfo.timeStamp)
          }
          // 从业务平台获取视频播放token
          return this.getVideoToken(vid)
        }
      }).catch(() => {
        this.setErrorCode('##004')
      })
    },
    async getVideoToken (vid) {
      return $ajax({
        url: this.playSafeUrl,
        data: Object.assign({vid}, this.playSafeData || {})
      }).then(playSafeRes => {
        if (playSafeRes.token) {
          this.tokenMap.set(this.definitionObj.id, playSafeRes.token)
        } else {
          this.setErrorCode('##004')
        }
      }).catch(() => {
        this.setErrorCode('##004')
      })
    },
    disposePlay () {
      if (this.player) {
        this.player.dispose()
        this.player = null
      }
    }
  },
  mounted () {
    this.loadPlayInfo(this.vid).then(() => {
      this.initPlayVideo()
    })
    this.volume = this.initVolume
    if (this.speed) {
      this.speedArray = typeof this.speed === 'boolean' ? [2, 1.5, 1.2, 1, 0.5] : this.speedArray
    }
    this.$nextTick(() => {
      this.initPvProgress()
      this.initPvVolumeProgress()
      // 监听浏览器小窗口播放
      let observer = new MutationObserver((mutations) => {
        let attributesChange = false
        mutations.forEach(mutation => {
          if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
            attributesChange = true
          }
        })
        if (attributesChange) {
          this.disposePlay()
          this.videoPlayError = this.getLangMsg('##001')
        }
      })
      observer.observe(document.querySelector('script'), {attributes: true})
    })
  },
  destroyed () {
    this.disposePlay()
    this.clearMarquee()
    this.clearPlayRecordTimer()
  },
  watch: {
    currentDuration (val) {
      if (val && !this.mouseFocusProgress) {
        this.$refs['currentProgress' + this.uniqueKey].style.width = `${(this.currentDuration / this.duration * 100).toFixed(4)}%`
      }
    },
    isPlaying () {
      if (this.isPlaying) {
        if (this.isAudio) {
          this.playInfo.basicInfo.thumbnail = 'https://app-learning.oss-cn-shanghai.aliyuncs.com/static/audio-poster-dynamic.gif'
        }
      } else {
        if (this.isAudio) {
          this.playInfo.basicInfo.thumbnail = 'https://app-learning.oss-cn-shanghai.aliyuncs.com/static/audio-poster.jpg'
        }
      }
    }
  }
}
</script>

<style lang="scss">
  @import "./index.scss";
</style>
