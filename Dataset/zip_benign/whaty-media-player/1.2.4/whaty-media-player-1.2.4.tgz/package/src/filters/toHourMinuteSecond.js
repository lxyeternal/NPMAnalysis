import moment from 'moment/moment'

export default (val = '00:00') => {
  if (val) {
    let time = moment.duration(val * 1000)
    let timeArr = []
    if (time.hours()) {
      timeArr.push(`${time.hours()}`.padStart(2, '0'))
    }
    return [...timeArr, `${time.minutes()}`.padStart(2, '0'), `${time.seconds()}`.padStart(2, '0')].join(':')
  }
  return '00:00'
}
