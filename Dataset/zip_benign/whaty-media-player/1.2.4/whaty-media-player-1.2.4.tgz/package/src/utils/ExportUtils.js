/**
 * 对外抛出的工具方法
 */
export default {
  /**
   * 是否是媒体平台vid
   */
  isMediaVid (vid) {
    if (vid) {
      return vid.startsWith('whaty_')
    }
    return false
  }
}
