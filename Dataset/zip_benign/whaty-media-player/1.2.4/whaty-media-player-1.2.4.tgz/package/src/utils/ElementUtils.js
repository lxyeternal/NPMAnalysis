import StringUtils from './StringUtils'

export default {
  // 生成随机标签
  createRandomElement (num) {
    return document.createElement(StringUtils.randomString(num))
  }
}
