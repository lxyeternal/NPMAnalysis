export default {
  randomString (num) {
    let e = ''
    for (let i = 0; i < num; i++) {
      e += String.fromCharCode(122 - Math.floor(26 * Math.random()))
    }
    return e
  }
}
