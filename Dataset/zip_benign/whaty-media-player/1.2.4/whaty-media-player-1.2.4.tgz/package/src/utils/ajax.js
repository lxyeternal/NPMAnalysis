import qs from 'qs'
import globalConfig from '../config'
export default function (config) {
  return new Promise((resolve, reject) => {
    if (!config.url) {
      return
    }
    const url = config.url.startsWith('http') ? config.url : (globalConfig.hostUrl() + config.url)
    const data = config.data || ''
    const method = config.method ? config.method.toUpperCase() : 'POST'
    const xhr = new XMLHttpRequest()
    xhr.open(method, url, true)
    if (method === 'POST' || method === 'PUT') {
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded')
    }
    xhr.send((typeof data === 'object') ? qs.stringify(data) : data)
    // 监听响应结果
    xhr.onreadystatechange = function () {
      if (xhr.readyState === 4) {
        if (xhr.status === 200) {
          let response
          try {
            response = JSON.parse(xhr.response)
          } catch (e) {
            response = xhr.response
          }
          resolve(response)
        } else {
          reject(new Error(xhr.statusText))
        }
      }
    }
  })
}
