/*
 * grunt-directory-security
 *
 * Copyright (c) 2019 Bert Meermans, contributors
 * Licensed under the MIT license.
 */

module.exports = function (grunt) {
  'use strict';
  const fs = require('fs');
  const path = require('path');

  grunt.registerMultiTask('preventFolderBrowsing', 'Copy an blank index.html file into each folder to prevent folder browsing on a webserver.', function () {
    var options = this.options({
      root: this.data.options[0].root || './dist/',
      includeSubFolders: (this.data.options[0].includeSubFolders == undefined || this.data.options[0].includeSubFolders === true) ? true : false,
      blankHtmlPage: this.data.options[0].blankHtmlPage || path.join(__dirname, 'index.html')
    });

    var directoryList = (options.includeSubFolders) ? getRecursiveDirectories(options.root) : [options.root];
    directoryList.forEach((folder) =>
      copyBlankHtmlInToTheDirectory(options.blankHtmlPage, folder)
    );
    grunt.log.writeln(">> " + directoryList.length + " times the " + path.basename(options.blankHtmlPage) + " added in the subfolders of " + options.root);
  });

  const getDirectories = source =>
    fs.readdirSync(source, {
      withFileTypes: true
    })
    .filter(d => d.isDirectory())
    .map(d => d.name)

  const getRecursiveDirectories = function (source) {
    var result = []
    try {
      var folders = getDirectories(source);
      if (folders.length !== 0) {
        folders.forEach(function (subFolder) {
          var fullFolderName = path.join(source, subFolder);
          result.push(fullFolderName);
          result = result.concat(getRecursiveDirectories(fullFolderName));
        });
      }
    } catch (e) {
      //continue
    } finally {
      return result;
    }
  }

  const copyBlankHtmlInToTheDirectory = (page, folder) =>
    fs.copyFileSync(page, path.join(folder, path.basename(page)), (err) => {
      if (err) throw err;
      grunt.log.writeln(page + ' was copied to ' + path.join(folder, path.basename(page)));
    });

};
