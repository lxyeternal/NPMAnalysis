# grunt-directory-security v0.2.1 

> Copy an empty index.html into all the existing folders except the root. This prevents directory browsing.

## Getting Started
This plugin requires Grunt `~0.4.0`

If you haven't used [Grunt](http://gruntjs.com/) before, be sure to check out the [Getting Started](http://gruntjs.com/getting-started) guide, as it explains how to create a [Gruntfile](http://gruntjs.com/sample-gruntfile) as well as install and use Grunt plugins. Once you're familiar with that process, you may install this plugin with this command:

```shell
npm install grunt-directory-security --save-dev
```

Once the plugin has been installed, it may be enabled inside your Gruntfile with this line of JavaScript:

```js
grunt.loadNpmTasks('grunt-directory-security');
```
*This plugin was designed to work with Grunt 0.4.x. If you're still using grunt v0.3.x it's strongly recommended that [you upgrade](http://gruntjs.com/upgrading-from-0.3-to-0.4), but in case you can't please use [v0.3.2](https://github.com/gruntjs/grunt-contrib-copy/tree/grunt-0.3-stable).*

## Copy task
_Run this task with the `grunt preventFolderBrowsing` command._

Task targets, files and options may be specified according to the grunt [Configuring tasks](http://gruntjs.com/configuring-tasks) guide.
### Options

#### root
Type: `String`  
Default: `dist`

Location that needs to be protected against folder browsing. 

#### includeSubFolders
Type: `Boolean`  
Default: `true`

Wheter to copy the blankHtmlPage the subfolders of the root. When this is set to 'true' the blankHtmlPage will NOT be copied to the root folder. When this is set to 'false' the blankHtmlPage will ONLY be copied into the root folder.

#### blankHtmlFile
Type: `String`  
Default: `index.html`

The file that is copied to the subfolders to prevent folder browsing. This file can be customized to fit the need of the users.

### Usage Examples
```js
preventFolderBrowsing: {
    all: {
        options: [{
            root: 'dist/',
            includeSubFolders: true,
            blankHtmlPage: 'index.html'
        }]	
    }			
},
```