export declare class CuepointMediaModule {
}
