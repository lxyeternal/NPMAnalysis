import { ElementRef, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CuepointMediaData } from './typings';
export declare class CuepointMediaDirective implements OnChanges {
    private el;
    /**
     * Emits cuepoint data when the media's currentTime matches the cuepoints time and cpListen is set to true.
     * The cuepoint's optional function will execute at the same time as the event.
     */
    cuepointEvent: EventEmitter<CuepointMediaData>;
    /**
     * CuepointMediaData: { time: number,  kind: 'event' | 'nav' | 'both',  name: string,  func?: () => void }
     * Cuepoints are automatically sorted by thier time property.
     */
    cuepoints: CuepointMediaData[];
    /**
     * EventListeners are added when set to true,  and eventListeners are removed when set to false.
     */
    cpListen: boolean;
    /**
     * Time in seconds that is used to specify a range of time when a cuepoint can be detected and cuepointEvent emitted.
     *
     * The timing of detecting cuepoints or navigating to a cuepoints specific time is not perfect.
     * Seeking can only happen on the media's comperssion key frames, and a key frame's time may not exacly match the cuepoint's time.
     * Also, device playback capabilities can play a role.
     * The default, 0.3, creates a large enough spread to work for most devices.
     * If cuepoints are missed, increase this number.
     * Distance between cuepoint times must be more than the defined tolerance.
     */
    tolerance: number;
    /**
     * A cuepoint is searched for who's name matches this value when set, then, if found,
     * the media's currentTime will seek the cuepoint's time and a cuepointEvent will emit.
     * This will only work for cuepoints that have the kind property value is 'nav' or 'both'.
     */
    goToName: string;
    /**
     * If a cuepoint at the index exists the media's currentTime will seek the cuepoint's time and a cuepointEvent will emit.
     * This will work for all cuepoints regardless of thier kind property's value.
     */
    goToIndex: number;
    /**
     * The media's currentTime will seek this number when set.
     * Does not look for a cuepoint's time to match.
     */
    goToTime: number;
    private media;
    private hasListeners;
    private rafID;
    private length;
    private index;
    private navTimer;
    private mode;
    private curCuepoint;
    private eventCuepoint;
    private navCuepoint;
    private seekedCallback;
    private playingCallback;
    private updateCallback;
    private isAndroid;
    constructor(el: ElementRef);
    ngOnChanges(changes: SimpleChanges): void;
    private onCuepoint;
    private seekCuepoint;
    /**
     *  "seeked" event unreliable on Android add "seeking" listener to help out
     */
    private addListeners;
    private removeListeners;
    private onMediaSeeked;
    private onNavTimer;
    private onMediaPlaying;
    private update;
}
