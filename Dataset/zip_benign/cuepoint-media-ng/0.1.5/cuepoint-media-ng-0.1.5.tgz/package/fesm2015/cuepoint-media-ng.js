import { EventEmitter, Directive, ElementRef, Output, Input, NgModule } from '@angular/core';

class CuepointMediaDirective {
    constructor(el) {
        this.el = el;
        /**
         * Emits cuepoint data when the media's currentTime matches the cuepoints time and cpListen is set to true.
         * The cuepoint's optional function will execute at the same time as the event.
         */
        this.cuepointEvent = new EventEmitter();
        /**
         * Time in seconds that is used to specify a range of time when a cuepoint can be detected and cuepointEvent emitted.
         *
         * The timing of detecting cuepoints or navigating to a cuepoints specific time is not perfect.
         * Seeking can only happen on the media's comperssion key frames, and a key frame's time may not exacly match the cuepoint's time.
         * Also, device playback capabilities can play a role.
         * The default, 0.3, creates a large enough spread to work for most devices.
         * If cuepoints are missed, increase this number.
         * Distance between cuepoint times must be more than the defined tolerance.
         */
        this.tolerance = 0.3;
        this.hasListeners = false;
        this.mode = 'event';
        this.isAndroid = (() => {
            if (window.navigator.platform && window.navigator.platform === 'Android')
                return true;
            else if (window.navigator.userAgent.toLowerCase().search('android') !== -1)
                return true;
            else if (window.navigator.appVersion.toLowerCase().search('android') !== -1)
                return true;
            else
                return false;
        })();
        this.media = this.el.nativeElement;
        this.seekedCallback = () => this.onMediaSeeked();
        this.playingCallback = () => this.onMediaPlaying();
        this.updateCallback = () => this.update();
    }
    ngOnChanges(changes) {
        var _a, _b, _c, _d;
        //console.log('CuepointMediaDirective.ngOnChanges)', changes);
        if ((_a = changes.cuepoints) === null || _a === void 0 ? void 0 : _a.currentValue) {
            this.cuepoints.sort((a, b) => a.time - b.time);
            this.length = this.cuepoints.length;
        }
        //
        if (changes.cpListen) {
            if (this.cpListen && !this.hasListeners)
                this.addListeners();
            else if (!this.cpListen && this.hasListeners)
                this.removeListeners();
        }
        //
        if ((_b = changes.goToName) === null || _b === void 0 ? void 0 : _b.currentValue) {
            this.seekCuepoint(this.goToName);
        }
        // string | number
        if (((_c = changes.goToIndex) === null || _c === void 0 ? void 0 : _c.currentValue) !== undefined) {
            this.seekCuepoint(this.goToIndex);
        }
        // number
        if (((_d = changes.goToTime) === null || _d === void 0 ? void 0 : _d.currentValue) !== undefined) {
            this.media.currentTime = this.goToTime;
        }
    }
    onCuepoint(cuepoint) {
        //console.log('CuepointMediaDirective.onCuepoint()', cuepoint);
        this.curCuepoint = cuepoint;
        this.cuepointEvent.emit(cuepoint);
        if (cuepoint.func)
            cuepoint.func.apply(window, []);
        this.mode = 'event';
        if (this.hasListeners)
            this.rafID = requestAnimationFrame(this.updateCallback);
    }
    seekCuepoint(nameOrIndex) {
        var _a, _b;
        //console.log('CuepointMediaDirective.seekCuepoint()', nameOrIndex);
        this.navCuepoint = typeof nameOrIndex === 'string'
            ? this.cuepoints.find(cp => cp.name === nameOrIndex)
            : this.cuepoints[nameOrIndex];
        if (this.navCuepoint && (((_a = this.navCuepoint) === null || _a === void 0 ? void 0 : _a.kind) === 'nav' || ((_b = this.navCuepoint) === null || _b === void 0 ? void 0 : _b.kind) === 'both' || typeof nameOrIndex === 'number')) {
            this.mode = 'nav';
            this.media.currentTime = this.navCuepoint.time;
        }
        else {
            this.navCuepoint = undefined;
        }
    }
    /**
     *  "seeked" event unreliable on Android add "seeking" listener to help out
     */
    addListeners() {
        //console.log('CuepointMediaDirective.addListeners()');
        this.hasListeners = true;
        this.media.addEventListener('seeked', this.seekedCallback, false);
        if (this.isAndroid)
            this.media.addEventListener('seeking', this.seekedCallback, false);
        this.media.addEventListener('playing', this.playingCallback, false);
        if (!this.media.paused)
            this.rafID = requestAnimationFrame(this.updateCallback);
    }
    removeListeners() {
        //console.log('CuepointMediaDirective.removeListeners()');
        this.hasListeners = false;
        this.media.removeEventListener('seeked', this.seekedCallback);
        this.media.removeEventListener('seeking', this.seekedCallback);
        this.media.removeEventListener('playing', this.playingCallback);
        cancelAnimationFrame(this.rafID);
    }
    onMediaSeeked() {
        //console.log('CuepointMediaDirective.onMediaSeeked()');
        if (this.mode === 'nav' && this.navCuepoint)
            this.navTimer = window.setInterval(() => this.onNavTimer(), 17);
    }
    onNavTimer() {
        if (this.navCuepoint) {
            if (this.media.currentTime >= (this.navCuepoint.time - this.tolerance) && this.media.currentTime < (this.navCuepoint.time + this.tolerance)) {
                this.onCuepoint(this.navCuepoint);
                this.navCuepoint = undefined;
            }
        }
        else {
            clearInterval(this.navTimer);
        }
    }
    onMediaPlaying() {
        //console.log('CuepointMediaDirective.onMediaPlaying()');
        if (this.curCuepoint && this.curCuepoint.time > (this.media.currentTime + this.tolerance))
            this.curCuepoint = undefined;
        if (this.hasListeners)
            this.rafID = requestAnimationFrame(this.updateCallback);
    }
    update() {
        //console.log('update', this.mode);
        if (this.media.paused || this.media.ended)
            return;
        //
        if (this.length && this.mode === 'event') {
            //
            for (this.index = 0; this.length > this.index; this.index++) {
                this.eventCuepoint = this.cuepoints[this.index];
                //
                if (this.eventCuepoint !== this.curCuepoint && (this.eventCuepoint.kind === 'event' || this.eventCuepoint.kind === 'both')) {
                    //
                    if (this.media.currentTime >= this.eventCuepoint.time && this.media.currentTime < (this.eventCuepoint.time + this.tolerance)) {
                        this.onCuepoint(this.eventCuepoint);
                        break;
                    }
                }
            }
        }
        if (this.hasListeners)
            this.rafID = requestAnimationFrame(this.updateCallback);
    }
}
CuepointMediaDirective.decorators = [
    { type: Directive, args: [{
                selector: '[a13CuepointMedia]'
            },] }
];
CuepointMediaDirective.ctorParameters = () => [
    { type: ElementRef }
];
CuepointMediaDirective.propDecorators = {
    cuepointEvent: [{ type: Output }],
    cuepoints: [{ type: Input }],
    cpListen: [{ type: Input }],
    tolerance: [{ type: Input }],
    goToName: [{ type: Input }],
    goToIndex: [{ type: Input }],
    goToTime: [{ type: Input }]
};

class CuepointMediaModule {
}
CuepointMediaModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    CuepointMediaDirective
                ],
                imports: [],
                exports: [
                    CuepointMediaDirective
                ]
            },] }
];

/*
 * Public API Surface of cuepoint-media
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CuepointMediaDirective, CuepointMediaModule };
//# sourceMappingURL=cuepoint-media-ng.js.map
