(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core')) :
    typeof define === 'function' && define.amd ? define('cuepoint-media-ng', ['exports', '@angular/core'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global['cuepoint-media-ng'] = {}, global.ng.core));
}(this, (function (exports, core) { 'use strict';

    var CuepointMediaDirective = /** @class */ (function () {
        function CuepointMediaDirective(el) {
            var _this = this;
            this.el = el;
            /**
             * Emits cuepoint data when the media's currentTime matches the cuepoints time and cpListen is set to true.
             * The cuepoint's optional function will execute at the same time as the event.
             */
            this.cuepointEvent = new core.EventEmitter();
            /**
             * Time in seconds that is used to specify a range of time when a cuepoint can be detected and cuepointEvent emitted.
             *
             * The timing of detecting cuepoints or navigating to a cuepoints specific time is not perfect.
             * Seeking can only happen on the media's comperssion key frames, and a key frame's time may not exacly match the cuepoint's time.
             * Also, device playback capabilities can play a role.
             * The default, 0.3, creates a large enough spread to work for most devices.
             * If cuepoints are missed, increase this number.
             * Distance between cuepoint times must be more than the defined tolerance.
             */
            this.tolerance = 0.3;
            this.hasListeners = false;
            this.mode = 'event';
            this.isAndroid = (function () {
                if (window.navigator.platform && window.navigator.platform === 'Android')
                    return true;
                else if (window.navigator.userAgent.toLowerCase().search('android') !== -1)
                    return true;
                else if (window.navigator.appVersion.toLowerCase().search('android') !== -1)
                    return true;
                else
                    return false;
            })();
            this.media = this.el.nativeElement;
            this.seekedCallback = function () { return _this.onMediaSeeked(); };
            this.playingCallback = function () { return _this.onMediaPlaying(); };
            this.updateCallback = function () { return _this.update(); };
        }
        CuepointMediaDirective.prototype.ngOnChanges = function (changes) {
            var _a, _b, _c, _d;
            //console.log('CuepointMediaDirective.ngOnChanges)', changes);
            if ((_a = changes.cuepoints) === null || _a === void 0 ? void 0 : _a.currentValue) {
                this.cuepoints.sort(function (a, b) { return a.time - b.time; });
                this.length = this.cuepoints.length;
            }
            //
            if (changes.cpListen) {
                if (this.cpListen && !this.hasListeners)
                    this.addListeners();
                else if (!this.cpListen && this.hasListeners)
                    this.removeListeners();
            }
            //
            if ((_b = changes.goToName) === null || _b === void 0 ? void 0 : _b.currentValue) {
                this.seekCuepoint(this.goToName);
            }
            // string | number
            if (((_c = changes.goToIndex) === null || _c === void 0 ? void 0 : _c.currentValue) !== undefined) {
                this.seekCuepoint(this.goToIndex);
            }
            // number
            if (((_d = changes.goToTime) === null || _d === void 0 ? void 0 : _d.currentValue) !== undefined) {
                this.media.currentTime = this.goToTime;
            }
        };
        CuepointMediaDirective.prototype.onCuepoint = function (cuepoint) {
            //console.log('CuepointMediaDirective.onCuepoint()', cuepoint);
            this.curCuepoint = cuepoint;
            this.cuepointEvent.emit(cuepoint);
            if (cuepoint.func)
                cuepoint.func.apply(window, []);
            this.mode = 'event';
            if (this.hasListeners)
                this.rafID = requestAnimationFrame(this.updateCallback);
        };
        CuepointMediaDirective.prototype.seekCuepoint = function (nameOrIndex) {
            var _a, _b;
            //console.log('CuepointMediaDirective.seekCuepoint()', nameOrIndex);
            this.navCuepoint = typeof nameOrIndex === 'string'
                ? this.cuepoints.find(function (cp) { return cp.name === nameOrIndex; })
                : this.cuepoints[nameOrIndex];
            if (this.navCuepoint && (((_a = this.navCuepoint) === null || _a === void 0 ? void 0 : _a.kind) === 'nav' || ((_b = this.navCuepoint) === null || _b === void 0 ? void 0 : _b.kind) === 'both' || typeof nameOrIndex === 'number')) {
                this.mode = 'nav';
                this.media.currentTime = this.navCuepoint.time;
            }
            else {
                this.navCuepoint = undefined;
            }
        };
        /**
         *  "seeked" event unreliable on Android add "seeking" listener to help out
         */
        CuepointMediaDirective.prototype.addListeners = function () {
            //console.log('CuepointMediaDirective.addListeners()');
            this.hasListeners = true;
            this.media.addEventListener('seeked', this.seekedCallback, false);
            if (this.isAndroid)
                this.media.addEventListener('seeking', this.seekedCallback, false);
            this.media.addEventListener('playing', this.playingCallback, false);
            if (!this.media.paused)
                this.rafID = requestAnimationFrame(this.updateCallback);
        };
        CuepointMediaDirective.prototype.removeListeners = function () {
            //console.log('CuepointMediaDirective.removeListeners()');
            this.hasListeners = false;
            this.media.removeEventListener('seeked', this.seekedCallback);
            this.media.removeEventListener('seeking', this.seekedCallback);
            this.media.removeEventListener('playing', this.playingCallback);
            cancelAnimationFrame(this.rafID);
        };
        CuepointMediaDirective.prototype.onMediaSeeked = function () {
            var _this = this;
            //console.log('CuepointMediaDirective.onMediaSeeked()');
            if (this.mode === 'nav' && this.navCuepoint)
                this.navTimer = window.setInterval(function () { return _this.onNavTimer(); }, 17);
        };
        CuepointMediaDirective.prototype.onNavTimer = function () {
            if (this.navCuepoint) {
                if (this.media.currentTime >= (this.navCuepoint.time - this.tolerance) && this.media.currentTime < (this.navCuepoint.time + this.tolerance)) {
                    this.onCuepoint(this.navCuepoint);
                    this.navCuepoint = undefined;
                }
            }
            else {
                clearInterval(this.navTimer);
            }
        };
        CuepointMediaDirective.prototype.onMediaPlaying = function () {
            //console.log('CuepointMediaDirective.onMediaPlaying()');
            if (this.curCuepoint && this.curCuepoint.time > (this.media.currentTime + this.tolerance))
                this.curCuepoint = undefined;
            if (this.hasListeners)
                this.rafID = requestAnimationFrame(this.updateCallback);
        };
        CuepointMediaDirective.prototype.update = function () {
            //console.log('update', this.mode);
            if (this.media.paused || this.media.ended)
                return;
            //
            if (this.length && this.mode === 'event') {
                //
                for (this.index = 0; this.length > this.index; this.index++) {
                    this.eventCuepoint = this.cuepoints[this.index];
                    //
                    if (this.eventCuepoint !== this.curCuepoint && (this.eventCuepoint.kind === 'event' || this.eventCuepoint.kind === 'both')) {
                        //
                        if (this.media.currentTime >= this.eventCuepoint.time && this.media.currentTime < (this.eventCuepoint.time + this.tolerance)) {
                            this.onCuepoint(this.eventCuepoint);
                            break;
                        }
                    }
                }
            }
            if (this.hasListeners)
                this.rafID = requestAnimationFrame(this.updateCallback);
        };
        return CuepointMediaDirective;
    }());
    CuepointMediaDirective.decorators = [
        { type: core.Directive, args: [{
                    selector: '[a13CuepointMedia]'
                },] }
    ];
    CuepointMediaDirective.ctorParameters = function () { return [
        { type: core.ElementRef }
    ]; };
    CuepointMediaDirective.propDecorators = {
        cuepointEvent: [{ type: core.Output }],
        cuepoints: [{ type: core.Input }],
        cpListen: [{ type: core.Input }],
        tolerance: [{ type: core.Input }],
        goToName: [{ type: core.Input }],
        goToIndex: [{ type: core.Input }],
        goToTime: [{ type: core.Input }]
    };

    var CuepointMediaModule = /** @class */ (function () {
        function CuepointMediaModule() {
        }
        return CuepointMediaModule;
    }());
    CuepointMediaModule.decorators = [
        { type: core.NgModule, args: [{
                    declarations: [
                        CuepointMediaDirective
                    ],
                    imports: [],
                    exports: [
                        CuepointMediaDirective
                    ]
                },] }
    ];

    /*
     * Public API Surface of cuepoint-media
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.CuepointMediaDirective = CuepointMediaDirective;
    exports.CuepointMediaModule = CuepointMediaModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=cuepoint-media-ng.umd.js.map
