export function readLinesSync(reader: any, decoderOpts: any, bufferSize?: number): Generator<string, void, unknown>;
