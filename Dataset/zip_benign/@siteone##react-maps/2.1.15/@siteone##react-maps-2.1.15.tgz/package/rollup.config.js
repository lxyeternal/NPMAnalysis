const path = require('path')
const builtin = require('builtin-modules')
const flow = require('rollup-plugin-flow')
const resolve = require('rollup-plugin-node-resolve')
const commonjs = require('rollup-plugin-commonjs')
const json = require('rollup-plugin-json')
const babel = require('rollup-plugin-babel')
const builtins = require('rollup-plugin-node-builtins')
const externalPeers = require('rollup-plugin-peer-deps-external')
const url = require('rollup-plugin-url')
const minify = require('rollup-plugin-babel-minify')

const pkg = require(path.join(process.cwd(), 'package.json'))
const dependencies = pkg.dependencies ? Object.keys(pkg.dependencies) : []
const peerDependencies = pkg.peerDependencies ? Object.keys(pkg.peerDependencies) : []
const external = [...dependencies, ...peerDependencies, ...builtin]

console.log('location: ', process.cwd())
console.log('external:', external)

const createBundler = inputFile => ({
  input: inputFile,
  output: [
    {
      // file: pkg.main,
      dir: pkg.mainDir,
      format: 'cjs',
      sourcemap: true,
    },
    {
      // file: pkg.browser,
      dir: pkg.browserDir,
      format: 'esm',
      sourcemapPathTransform: (relativePath) => 
        // will transform e.g. "src/main.js" -> "main.js"
         path.relative('src', relativePath)
      ,
      sourcemap: true,
    },
  ],
  external,
  plugins: [
    // minify(),
    externalPeers(),
    flow(),
    // builtins(),
    json(),
    url(),
    babel({
      // Don't try to find .babelrc because we want to force this configuration.
      babelrc: false,
      // Nobody needs the original comments when having source maps
      comments: false,
      sourcemap: true,
      presets: [
        // 'flow',
        '@babel/preset-react',
        [
          '@babel/preset-env',
          {
            targets: {
              node: 10,
              browsers: ['last 2 versions', '> 1%', 'IE 11'],
            },
            loose: true,
            modules: false,
          },
        ],
      ],
      plugins: [
        '@babel/plugin-proposal-class-properties',
        '@babel/plugin-proposal-do-expressions',
        '@babel/plugin-proposal-export-default-from',
        '@babel/plugin-proposal-export-namespace-from',
        '@babel/plugin-proposal-function-bind',
        '@babel/plugin-proposal-function-sent',
        '@babel/plugin-proposal-json-strings',
        '@babel/plugin-proposal-logical-assignment-operators',
        '@babel/plugin-proposal-nullish-coalescing-operator',
        '@babel/plugin-proposal-numeric-separator',
        '@babel/plugin-proposal-optional-chaining',
        ['@babel/plugin-proposal-pipeline-operator', { proposal: 'minimal' }],
        '@babel/plugin-proposal-throw-expressions',
        '@babel/plugin-syntax-dynamic-import',
        '@babel/plugin-syntax-import-meta',
      ],
    }),
    commonjs({
      include: ['node_modules/**'],
    }),

    resolve({
      main: true,
      jsnext: true,
      extensions: ['.mjs', '.js', '.jsx', '.json'],
    }),
  ],
})

module.exports = [
  createBundler(['src/index.js', 'src/BasicMap.jsx', 'src/Map.jsx']),
]
