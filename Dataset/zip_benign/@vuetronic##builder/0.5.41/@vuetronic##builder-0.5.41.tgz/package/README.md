# @vuetronic/builder

This package contains dependencies that should be available during development process. 

It must be included as a `devDependencies`. If not bundled application size will be to big. 

```json
"devDependencies": {
    "@vuetronic/builder": "0.5.*"
},
```