**Buddy Guy Discography Torrent**


 Click Here >> [https://urllie.com/2tjaZW](https://urllie.com/2tjaZW)


```


Buddy Guy You know you Are a legend. Im not at all surprised that there are so many Buddy Guy fans here. To me that says it all. I have been a fan of Guy for some time now and have been trying to convince people that Guy is a legend. You are living up to your reputation Mr. Guy. I will definitely buy this record. I highly recommend this to all Buddy Guy fans. The word used most often when describing Guy is soulful. The energy on this record is incredible. Buddy Guy this is the greatest blues record ever made.


I have seen Buddy Guy in concert several times and I can honestly tell you he is quite simply one of the best live musicians I have ever seen. His voice, his guitar and his attitude all come together and it is indescribable. You must have this record if you are a fan of the blues.


Never before have the words "same old blues" seemed so utterly offensive. Buddy Guy continues to make the most exciting music Chicago has ever produced. Way, way out on the borders, he stands alone, a musician living at the incredible speed of light. I wish our government would quit buying every record he produces. If the Federal Bureau of Investigation had a record catalogue it would have to buy his.


A great CD by the true hard-blues king! A true bluesman with a lot of soul and passion - Buddy Guy. There are 5 sessions recorded here, some more than 30 years ago. Produced by Quincy Jones. But it didnt stop his popularity or the impact he had on other musicians! This CD is a definite must for hard blues fans, that are in short supply in today's world. In my opinion, Buddy Guy is one of the greatest guitar players of all time. Pure class and talent! If you dont know Buddy Guy, get some real blues now and youll probably add this CD to your collection. 84d34552a1


```