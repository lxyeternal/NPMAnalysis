/* tslint:disable */
/* eslint-disable */
/**
* @param {string} source
* @returns {any}
*/
export function ream2ast(source: string): any;
/**
* @param {string} source
* @returns {any}
*/
export function ream2csv(source: string): any;
/**
* @param {string} source
* @returns {any}
*/
export function ream2html(source: string): any;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly ream2ast: (a: number, b: number) => number;
  readonly ream2csv: (a: number, b: number) => number;
  readonly ream2html: (a: number, b: number) => number;
  readonly __wbindgen_malloc: (a: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number) => number;
}

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {InitInput | Promise<InitInput>} module_or_path
*
* @returns {Promise<InitOutput>}
*/
export default function init (module_or_path?: InitInput | Promise<InitInput>): Promise<InitOutput>;
