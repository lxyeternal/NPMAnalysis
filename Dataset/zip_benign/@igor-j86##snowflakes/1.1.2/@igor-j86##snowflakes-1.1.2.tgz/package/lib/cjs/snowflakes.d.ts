import * as React from "react";
export interface SnowflakesProps {
    /** Container id */
    id?: string;
    /** Number of snowflakes */
    snowflakes?: number;
    /** Max snowflakes size */
    maxSize?: number;
    /** Max snowflakes speed */
    maxSpeed?: number;
    /** Snowflakes color */
    color?: string;
}
export declare const Snowflakes: React.FC<SnowflakesProps>;
