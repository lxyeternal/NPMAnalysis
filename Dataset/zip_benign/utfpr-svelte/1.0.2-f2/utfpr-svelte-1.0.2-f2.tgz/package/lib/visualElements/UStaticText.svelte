<script context="module">
  let counter = 0;
</script>

<script lang="ts">
  import type { TextAlign } from "../defs/UTypeDefs";
  import tooltip from "../tooltip/tooltip";

  const eltId = "stInput_" + counter++;

  export let align: TextAlign = "left";
  export let hint: string | null = null;
  export let label: string | null = "label";

  export let value: string = "";
  export let width: number = 13;

  let ref = null;
  export let validationMessage: string | null = null;

  $: size = !value ? "" : " " + value.length + " ";
</script>

<div class="ui-container">
  <span class="ui-lbl" aria-label={hint} data-size={size}>
    <span
      id={eltId}
      type="readonly"
      placeholder={" "}
      bind:this={ref}
      class="ui-widget ui-corner-all ui-input"
      class:text-left={align == "left"}
      class:text-center={align == "center"}
      class:text-right={align == "right"}
      style="width: {2 + width}em"
      data-isvalid={!validationMessage}
      use:tooltip
      role="textbox"
    >
      {value}
    </span>

    {#if label}
      <span class="ui-material-label">{label}</span>
    {/if}

    {#if !!validationMessage}
      <span>{validationMessage}</span>
    {/if}
  </span>
</div>
