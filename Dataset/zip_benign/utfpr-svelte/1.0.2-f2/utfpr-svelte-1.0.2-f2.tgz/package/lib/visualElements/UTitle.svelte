<script lang="ts">
  import UButton from "../buttons/UButton.svelte";
  import tooltip from "../tooltip/tooltip";

  export let title: string = "Title";
  export let hint: string | null = null;
  // export let kind: "header" | "section" = "header";
  export let printButton: boolean = true;
</script>

<header class="shadow" aria-label={hint} use:tooltip>
  {title}
  {#if /* kind == "header" && */ printButton}
    <span class="pull-left">
      <UButton kind="Imprimir" on:click={() => window.print()} />
    </span>
  {/if}
</header>

<style>
  header {
    min-height: 2rem;
    max-height: 3rem;
    color: var(--border-highlight);
    border-radius: 0.35em;
    border: 1px solid var(--border-default);
    background: var(--bg-aside);
    font-weight: bold;
    padding: 2px;
  }
</style>
