<script context="module">
  let counter = 0;
</script>

<script lang="ts">
  export let label: string | null = "label";
  export let hint: string | null = null;
  export let type: string = "text";
  export let validation: string | null = null;
  export let dataSize: string | null = null;
  const idElm = "bfe_" + counter++;
  const idLbl = idElm + "_lb";
</script>

<div class="ui-container">
  <label
    class="ui-lbl"
    data-type={type}
    data-size={dataSize || ""}
    aria-label={hint || label}
    id={idLbl}
  >
    <slot {idElm} {idLbl}>
      <input id={idElm} aria-labelledby={idLbl} />
    </slot>
    {#if label}
      <label class="ui-material-label" for={idElm}>{label}</label>
    {/if}

    {#if !!validation}
      <span>{validation}</span>
    {/if}
  </label>
</div>
