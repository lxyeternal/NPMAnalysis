<script lang="ts">
  import { onMount } from "svelte";
  import type { TextAlign } from "../defs/UTypeDefs";
  import tooltip from "../tooltip/tooltip";
  import { formatters } from "../defs/UTypeDefs";

  export let simple: boolean = true;
  export let ref = null;
  export let labelledby: string | null = null;
  export let validation: string | null = null;

  onMount(() => setTimeout((e) => validate(e), 100));

  export let id: string | null = null;
  export let align: TextAlign = "right";
  export let name: string;
  export let readonly: boolean = false;
  export let optional: boolean = false;
  export let value: Date | null = null;
  export let width: number = 10;

  let internalValue: string | null;

  const input = (x) => (internalValue = formatters.dateTimeLocal(x));
  const output = (x) => (value = new Date(x));

  $: input(value);
  $: output(internalValue);

  function validate(evt): void {
    //  console.log( "value:", internalValue, "ref:", ref.value, typeof internalValue );

    if (ref != null && internalValue != ref.value) internalValue = ref.value;

    if (!optional && !internalValue) validation = "Campo obrigatório!";
    /*    
    else if (value < minValue)
      validation =
        "Informe um valor acima de " + formatters.toMoney(minValue, 0);
    else if (value > maxValue)
      validation =
        "Informe um valor abaixo de " + formatters.toMoney(maxValue, 0);
*/ else validation = null;

    if (!!ref) ref.setCustomValidity(validation || "");
  }
</script>

<input
  {id}
  {name}
  {readonly}
  placeholder=" "
  required={!optional && !readonly}
  type="datetime-local"
  bind:value={internalValue}
  bind:this={ref}
  class="ui-widget ui-corner-all ui-input"
  class:ui-default={simple}
  class:text-left={align == "left"}
  class:text-center={align == "center"}
  class:text-right={align == "right"}
  style="width: {0.5 + width}em"
  data-isvalid={!validation}
  aria-labelledby={labelledby}
  use:tooltip
  on:change={validate}
  on:focus={validate}
  on:blur={validate}
  on:keyup={validate}
  on:keydown={validate}
/>
