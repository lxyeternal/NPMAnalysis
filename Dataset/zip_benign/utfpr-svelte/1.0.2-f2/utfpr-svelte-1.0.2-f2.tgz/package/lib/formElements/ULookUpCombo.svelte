<script lang="ts">
  import Select from "svelte-select";

  export let label: string = "Search";
  export let LookupItem: any;
  export let name: string;
  export let placeholder: string = "Texto to search";
  export let width: number = 50;
  export let optValue: string = "id";
  export let optLabel: string = "label";

  export let loadOptions = (filter) =>
    alert("Requires create an loading for :" + filter);

  export let getSelectedLabel = (option) => option[optLabel] || "";

  let getSelectionLabel = (option) => {
    if (input) input.value = option[optValue] || -1;
    return getSelectedLabel(option);
  };

  let isHover: boolean = false;
  let input = null;
</script>

<div
  class="ui-corner-all shadow-lt select-themed"
  on:mouseenter={() => (isHover = true)}
  on:mouseleave={() => (isHover = false)}
  style="width: {2 + width}em"
>
  <label>
    <span class:isHover>{label}</span>
    <input bind:this={input} type="hidden" {name} />
    <Select
      {loadOptions}
      optionIdentifier={optValue}
      {getSelectionLabel}
      Item={LookupItem}
      {placeholder}
      showChevron={true}
    />
  </label>
</div>

<style>
  div {
    border: 1px solid var(--border-default);
    margin: 3px;
    padding: 0.65rem 3px 2px 3px;
    position: relative;
    display: inline-block;
  }

  span {
    position: absolute;
    font-size: 0.9rem;
    left: 0;
    top: -0.9rem;
    padding: 0 0.1rem;
    margin: 0 0.5rem;
    background: linear-gradient(
      to top,
      transparent 11px,
      var(--bg-content) 11px,
      var(--bg-content) 14px,
      transparent 14px
    );
  }

  span.isHover {
    color: var(--font-active);
  }
</style>
