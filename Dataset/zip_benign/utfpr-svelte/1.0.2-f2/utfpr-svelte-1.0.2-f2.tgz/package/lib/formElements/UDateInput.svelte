<script lang="ts">
  import { onMount } from "svelte";
  import type { TextAlign } from "../defs/UTypeDefs";
  import tooltip from "../tooltip/tooltip";
  import BaseFormElement from "./BaseFormElement.svelte";

  let ref = null;
  let validation: string | null = null;

  onMount(() => setTimeout((e) => validate(e), 100));

  export let align: TextAlign = "right";
  export let hint: string | null = null;
  export let label: string | null = "label";
  export let name: string;
  export let optional: boolean = false;
  // export let placeholder: string = " ";
  export let value: Date | null = null;
  export let width: number = 10;

  // export let minValue: number = Number.NEGATIVE_INFINITY;
  // export let maxValue: number = Number.POSITIVE_INFINITY;

  function validate(evt): void {
    if (ref != null && value != ref.value) value = ref.value;
    if (!optional && !value) validation = "Campo obrigatório!";
    /*    
    else if (value < minValue) validation = "Informe um valor acima de " + formatters.toMoney(minValue, 0);
    else if (value > maxValue) validation = "Informe um valor abaixo de " + formatters.toMoney(maxValue, 0);
*/ else validation = null;

    if (!!ref) ref.setCustomValidity(validation || "");
  }
</script>

<BaseFormElement {label} {hint} {validation} type={"date"} let:idElm let:idLbl>
  <input
    id={idElm}
    {name}
    placeholder=" "
    required={!optional}
    type="date"
    bind:value
    bind:this={ref}
    class="ui-widget ui-corner-all ui-input"
    class:text-left={align == "left"}
    class:text-center={align == "center"}
    class:text-right={align == "right"}
    style="width: {2 + width}em"
    data-isvalid={!validation}
    aria-labelledby={idLbl}
    use:tooltip
    on:change={validate}
    on:focus={validate}
    on:blur={validate}
    on:keyup={validate}
    on:keydown={validate}
  />
</BaseFormElement>
