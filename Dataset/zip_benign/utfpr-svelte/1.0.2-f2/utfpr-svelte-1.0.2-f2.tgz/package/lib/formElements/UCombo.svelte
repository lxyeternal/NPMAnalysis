<script lang="ts">
  import tooltip from "../tooltip/tooltip";
  import BaseFormElement from "./BaseFormElement.svelte";

  export let hint: string | null = null;
  export let label: string | null = "label";
  export let name: string;
  export let value: string | number = "";
  export let width: number = 13;

  export let options = [];
  export let optValue: string = "id";
  export let optLabel: string = "label";
  export let optHint: string = "hint";

  export let autoSelectFirst: boolean = true;

  $: if (
    autoSelectFirst &&
    (options || []).length &&
    (!value || !(options || []).find((f) => f[optValue] == value))
  )
    value = options[0][optValue];
</script>

<BaseFormElement {label} {hint} type={"combo"} let:idElm let:idLbl>
  <select
    id={idElm}
    {name}
    class="ui-input ui-default ui-corner-all"
    bind:value
    on:change
    aria-label={hint}
    style="width: {2 + width}em"
    use:tooltip
  >
    <!--bind:this={ref} -->
    {#each options || [] as opt}
      {#if !opt}
        <option>invalid option</option>
      {:else}
        <option
          value={opt[optValue]}
          title={opt[optHint]}
          aria-label={opt[optHint]}
          use:tooltip
        >
          {opt[optLabel] || opt[optHint] || opt[optValue] || "option"}
        </option>
      {/if}
    {/each}
  </select>
</BaseFormElement>
