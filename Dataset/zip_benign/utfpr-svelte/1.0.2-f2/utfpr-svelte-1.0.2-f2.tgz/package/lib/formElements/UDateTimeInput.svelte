<script lang="ts">
  import type { TextAlign } from "../defs/UTypeDefs";
  import BaseFormElement from "./BaseFormElement.svelte";
  // import tooltip from "../tooltip/tooltip";
  import USimpleDateTimeInput from "./USimpleDateTimeInput.svelte";

  let validation: string | null = null;

  export let align: TextAlign = "right";
  export let hint: string | null = null;
  export let label: string | null = "label";
  export let name: string;
  export let optional: boolean = false;
  // export let placeholder: string = " ";
  export let value: Date | null = null;
  export let width: number = 11;
</script>

<BaseFormElement
  {label}
  {hint}
  {validation}
  type={"datetime"}
  let:idElm
  let:idLbl
>
  <USimpleDateTimeInput
    id={idElm}
    bind:name
    bind:optional
    bind:value
    bind:align
    labelledby={idLbl}
    bind:width
    simple={false}
  />
</BaseFormElement>
