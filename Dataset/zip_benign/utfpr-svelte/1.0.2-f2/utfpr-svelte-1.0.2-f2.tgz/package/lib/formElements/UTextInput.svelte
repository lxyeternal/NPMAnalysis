<script lang="ts">
  import { onMount } from "svelte";
  import type { TextAlign } from "../defs/UTypeDefs";
  import tooltip from "../tooltip/tooltip";
  import UStaticText from "../visualElements/UStaticText.svelte";
  import BaseFormElement from "./BaseFormElement.svelte";

  let ref = null;
  let validation: string | null = null;

  onMount(() => setTimeout((e) => validate(e), 100));

  export let align: TextAlign = "left";
  export let hint: string | null = null;
  export let label: string | null = "label";
  export let name: string;
  export let placeholder: string = " ";
  export let optional: boolean = false;
  export let readonly: boolean = false;
  export let value: string = "";
  export let width: number = 13;

  export let maxSize: number = 120;
  export let minSize: number = 0;

  $: required = !readonly && !optional;

  $: size = !value ? 0 : value.length;

  function validate(evt): void {
    if (ref != null && value != ref.value) value = ref.value;

    if (readonly) validation = null;
    else if (optional && size == 0) validation = null;
    else if (!optional && !value) validation = "Campo obrigatório!";
    else if (minSize > size)
      validation = "informe pelo menos " + minSize + " caracteres";
    else if (maxSize < size)
      validation = "informe até " + maxSize + " caracteres";
    else validation = null;

    if (ref?.setCustomValidity) ref.setCustomValidity(validation || "");
  }
</script>

{#if readonly}
  <UStaticText
    {value}
    {label}
    {align}
    {hint}
    {width}
    validationMessage={validation}
  />
{:else}
  <BaseFormElement
    {label}
    {hint}
    {validation}
    dataSize={size + "/" + maxSize}
    type={"text"}
    let:idElm
    let:idLbl
  >
    <input
      id={idElm}
      {name}
      placeholder={placeholder + " "}
      {required}
      {readonly}
      type="text"
      bind:value
      bind:this={ref}
      class="ui-widget ui-corner-all ui-input"
      class:text-left={align == "left"}
      class:text-center={align == "center"}
      class:text-right={align == "right"}
      style="width: {2 + width}em"
      data-isvalid={!validation}
      aria-labelledby={idLbl}
      use:tooltip
      on:change={validate}
      on:focus={validate}
      on:blur={validate}
      on:keyup={validate}
      on:keydown={validate}
    />
  </BaseFormElement>
{/if}
