<script context="module">
  let counter = 0;
</script>

<script lang="ts">
  // import { onMount, onDestroy, tick, createEventDispatcher } from "svelte";
  import tooltip from "../tooltip/tooltip";
  import { httpHandler } from "../services/HttpHandler";

  const eltId: string = "searchCombo_" + counter++;

  // DOM elements
  let input, dropDown;

  let showDropDown: boolean = false;
  let inputValue: string = "";
  let isHoveringDropDown: boolean = false;

  export let items = [];
  export let label: string = "";
  export let placeholder: string = "";
  export let dataPromise: Promise<[]> | null = null;
  export let displayName: string = "name";
  export let width: number = 10;

  let selectedIndex: number = -1;

  let displayField = (item) => item[displayName];

  function selectCurrentItem(index) {
    selectedIndex = index;
    if (index > -1) inputValue = displayField(items[index]);
    console.log("selectCurrentItem", index, inputValue);
  }

  $: if (items && items.length) dataPromise = httpHandler.futureData(items);
  // onMount(() => if (items && items.length) dataPromise = httpHandler.futureData(items) );

  // $: console.log("isHoveringDropDown:", isHoveringDropDown);

  function openDropDown() {
    // console.log("opening drop down");
    showDropDown = true;
  }

  function closeDropDown() {
    // console.log("closing drop down");
    showDropDown = false;
    isHoveringDropDown = false;
  }

  function blur(ev) {
    /*
    setTimeout(
      () => console.log("blur", ev?.target, document.activeElement),
      10
    );
    */
    if (!isHoveringDropDown) closeDropDown();
    // value = "";
  }

  async function keydown(e) {
    switch (e.key) {
      case "Enter":
      case "Tab":
        isHoveringDropDown = false;
        selectCurrentItem(selectedIndex);
        closeDropDown();
        break;

      case "Escape":
        // value = "";
        closeDropDown();
        break;

      case "ArrowDown":
        openDropDown();
        if (selectedIndex < items.length - 1) selectedIndex++;
        break;

      case "ArrowUp":
        openDropDown();
        if (selectedIndex > 0) selectedIndex--;
        break;

      case "Backspace":
        if (inputValue.length === 0 && selectedIndex > -1) selectedIndex = -1;
        openDropDown();
        break;

      default:
        if (e.key.length === 1) {
          inputValue = inputValue + e.key;
          console.log("default key", e.key);
          // selectedIndex = -1;
          if (dropDown) dropDown.scrollTop = 0;
          openDropDown();
        }
        break;
    }
  }
</script>

<div class="ui-container">
  <div class="combo" style="width: {2 + width}em">
    <label
      class="ui-lbl input"
      id={eltId + "_lb"}
      aria-label={label || placeholder}
    >
      <input
        id={eltId + "_tf"}
        placeholder={placeholder + " "}
        type="search"
        bind:this={input}
        bind:value={inputValue}
        on:keydown|preventDefault={keydown}
        on:blur={blur}
        on:focus={(ev) => {
          console.log("focus!", ev);
          openDropDown();
        }}
        class="ui-widget ui-corner-tl ui-input"
        class:ui-default={true}
        class:ui-corner-bl={!showDropDown}
        class:shadow={!showDropDown}
        aria-labelledby={eltId + "_lb"}
        autocomplete="off"
      />

      {#if placeholder}
        <label class="ui-material-label" for={eltId + "_tf"}
          >{placeholder}
        </label>
      {/if}

      <button
        class="pull-right fa ui-corner-tr ui-input"
        class:fa-chevron-up={showDropDown}
        class:fa-chevron-down={!showDropDown}
        class:ui-corner-br={!showDropDown}
        class:shadow={!showDropDown}
        on:click={() => (showDropDown = !showDropDown)}
      />
    </label>

    <div
      bind:this={dropDown}
      class:hide={!showDropDown}
      class="drop-down ui-corner-bottom shadow"
      on:mouseenter={() => (isHoveringDropDown = true)}
      on:mouseleave={() => (isHoveringDropDown = false)}
    >
      {#await dataPromise}
        <p>...carregando</p>
      {:then data}
        {#each data as item, idx}
          <label class:choiced={selectedIndex == idx} class="item">
            <input
              type="checkbox"
              on:click|preventDefault={() => selectCurrentItem(idx)}
              on:keydown|preventDefault={keydown}
              on:blur={blur}
              use:tooltip
            />
            {displayField(item)}
          </label>
        {/each}
      {:catch error}
        <p style="color: red">{error.message}</p>
      {/await}
    </div>
  </div>
</div>

<style>
  div.combo {
    display: block;
    position: relative;
    width: max-content;
  }
  /*
  ul {
    margin-block: 2px;
    padding-inline: 2px;
  }

  li {
    border: 1px solid transparent;
    padding: 3px;
    cursor: pointer;
    display: block;
    border-radius: 4px;
  }

  li:hover {
    padding: 3px;
    border: 1px solid var(--border-active);
    background-color: var(--bg-hover);
  }

  li.choiced {
    font-weight: bold;
    color: var(--font-active);
  }
*/

  label.item {
    border: 1px solid transparent;
    padding: 3px;
    cursor: pointer;
    display: block;
    border-radius: 4px;
  }

  label.item:hover {
    padding: 3px;
    border: 1px solid var(--border-active);
    background-color: var(--bg-hover);
  }

  label.item.choiced {
    font-weight: bold;
    color: var(--font-active);
    background-color: var(--bg-active);
    border-color: var(--border-active);
  }

  label.item input[type="checkbox"] {
    opacity: 0;
    position: absolute;
    left: -1rem;
  }

  .drop-down {
    position: absolute;
    z-index: 1;
    top: calc(2rem + 3px);
    border: #dddddd 1px solid;
    width: calc(100% + 3.5rem - 2px);
    height: max-content;
    overflow: auto;
    background: var(--bg-primary);
    box-sizing: border-box;
    outline: 0;
    text-align: left;
  }

  .input {
    display: flex;
    width: 100%;
    outline: 0;
  }

  input {
    flex: 1;
    margin: 0;
    outline: 0;
    padding: 6px 0;
    border: none;
    line-height: 24px;
  }

  input[type="search"] {
    height: 2.2rem;
    font-size: 14px;
  }
</style>
