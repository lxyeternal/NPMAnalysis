<script lang="ts">
  import { getContext, onMount, onDestroy } from "svelte";
  import type { IRouterContext, IRouterLink } from "../defs/UTypeDefs";
  const { register, unRegister } = getContext<IRouterContext>("URouter");

  export let label: string;
  export let group: string = "Geral";
  export let hint: string | null = null;
  export let route: string;
  export let component: any;

  let link: IRouterLink = {
    label,
    group,
    hint,
    route,
    component,
  };

  onMount(() => register(link));
  onDestroy(() => unRegister(link));
</script>
