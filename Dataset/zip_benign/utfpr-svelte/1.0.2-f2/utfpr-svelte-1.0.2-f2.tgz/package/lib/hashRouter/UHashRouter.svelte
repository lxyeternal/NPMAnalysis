<script lang="ts">
  import { setContext } from "svelte/internal";
  import UPanel from "../container/UPanel.svelte";
  import type { IRouterContext, IRouterLink } from "../defs/UTypeDefs";
  import tooltip from "../tooltip/tooltip";

  // the default route (when don't have any 'know' route in routingMap)
  export let defaultRoute: string = "#";

  // all router itens
  let itens: IRouterLink[] = null;

  // the active route (current Location)
  let currentLocation: string = getLocation();

  // a map "group" and routes
  let routingGroups = new Map<string, IRouterLink[]>();

  // the map "groups"
  let groupKeys: string[] = [];

  let open = "General";

  // the Active Link
  $: activeRouterLink = (
    (itens || []) //
      .find((i) => i.route == currentLocation) || { route: defaultRoute }
  ).route;

  $: activeElement =
    activeRouterLink == "#"
      ? null
      : itens.find((i) => activeRouterLink == i.route);

  /**
   * Get current Hash Location or the default
   */
  function getLocation(): string {
    // If the SPA was load inside an IFRAME get de 'parent' location.
    return (window.parent?.location || location).hash || defaultRoute;
  }

  /**
   * listen the changes of the location hash
   */
  let onHashchange = () => {
    // If the SPA was load inside an IFRAME set de 'parent' location.
    if (window.parent?.location?.hash != location.hash)
      window.parent.location.hash = location.hash;
    //set the current route
    currentLocation = getLocation();
  };

  // context is usen in childs "onMount" / "onDestroy"
  setContext<IRouterContext>("URouter", {
    // child routers need registry himself in Router.
    register: (link: IRouterLink): void => {
      itens = (itens || []).concat(link);

      if (!routingGroups.has(link.group)) routingGroups.set(link.group, [link]);
      else routingGroups.get(link.group).push(link);

      if (currentLocation == link.route) open = link.group;

      const keys = routingGroups.keys();
      groupKeys = Array.from(keys);
      // console.log(keys, routingKeys);
    },
    // in destroy/clean-up process, child routers need unregister himself in Router.
    unRegister: (link: IRouterLink): void => {
      itens = (itens || []).filter((f) => f != link);
    },
  });
</script>

<svelte:window on:hashchange={onHashchange} />

<aside class="shadow">
  {#each groupKeys as group}
    <UPanel
      title={group}
      open={open == group}
      joinned="vertical"
      on:collapse={() => (open = open != group ? group : "#")}
    >
      <!-- routing options-->
      {#each routingGroups.get(group) as lnk}
        <a
          use:tooltip
          href={lnk.route}
          aria-label={lnk.hint}
          class="ui-button ui-corner-all"
          class:ui-active={activeRouterLink == lnk.route}
        >
          {lnk.label}
        </a>
      {/each}
    </UPanel>
  {/each}
</aside>

<!-- target of the router-->
{#if itens != null}
  <main class="shadow">
    {#if activeElement?.component}
      <svelte:component this={activeElement.component} />
    {:else}
      <h1>Selecione uma opção no menu ao lado!</h1>
    {/if}
  </main>
{/if}

<div class="hide"><slot /></div>

<style>
  aside {
    overflow: hidden;
  }

  main,
  aside {
    min-height: 70%;
    height: calc(100vh - 5rem);
    margin: 5px 2px 2px 0px;
    border: 1px solid var(--border-default);
    border-radius: 0.35em;
    padding: 4px;
  }

  aside {
    width: calc(15em - 14px);
    float: left;
    background-color: var(--bg-aside);
    /* background-color: aquamarine; */
  }

  main {
    width: calc(100% - 15em - 14px);
    float: right;
    overflow: auto;
  }

  a {
    display: block;
    padding: 4px;
    margin: 0px 2px 2px 2px;
    text-align: left;
  }

  a.ui-active {
    border-color: var(--border-active);
    background: var(--bg-secondary);
    color: var(--font-active);
  }
</style>
