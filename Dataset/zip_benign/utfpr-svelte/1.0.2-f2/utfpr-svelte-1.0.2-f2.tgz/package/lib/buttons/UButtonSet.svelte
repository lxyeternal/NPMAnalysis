<script lang="ts">
  import { createEventDispatcher } from "svelte/internal";
  import tooltip from "../tooltip/tooltip";

  export let options = [];
  export let optValue: string = "id";
  export let optLabel: string = "label";
  export let optHint: string = "hint";
  export let name: string;
  export let value = null;
  export let label: string = "ButtonSet";
  $: last = options.length - 1;

  let isHover: boolean = false;

  const dispatch = createEventDispatcher();
</script>

<div
  role="toolbar"
  class="ui-corner-all shadow-lt"
  on:mouseenter={() => (isHover = true)}
  on:mouseleave={() => (isHover = false)}
>
  <span class:isHover>{label}</span>

  {#each options as opt, idx}
    <label
      class="ui-button ui-widget"
      class:ui-corner-left={idx == 0}
      class:ui-corner-right={idx == last}
      class:ui-active={value == opt[optValue]}
      aria-label={opt[optHint]}
      use:tooltip
    >
      <input
        type="radio"
        {name}
        value={opt[optValue]}
        checked={value == opt[optValue]}
        on:click={(e) => {
          const old = value;
          value = opt[optValue];
          dispatch("change", { selected: opt });
        }}
      />
      {opt[optLabel]}
    </label>
  {/each}
</div>

<style>
  div {
    display: inline-flex;
    border: 1px solid var(--border-default);
    width: fit-content;
    margin: 3px;
    padding: 0.65rem 3px 2px 3px;
    position: relative;
  }

  label.ui-button:not(.ui-active) {
    font-weight: normal;
  }

  label.ui-button {
    margin-left: 0px;
    margin-right: 0px;
  }

  input[type="radio"] {
    display: none;
  }

  span {
    position: absolute;
    font-size: 0.9rem;
    left: 0;
    top: -0.9rem;
    padding: 0 0.1rem;
    margin: 0 0.5rem;
    background: linear-gradient(
      to top,
      transparent 11px,
      var(--bg-content) 11px,
      var(--bg-content) 14px,
      transparent 14px
    );
  }

  span.isHover {
    color: var(--font-active);
  }
</style>
