<script lang="ts">
  import tooltip from "../tooltip/tooltip";

  export let kind:
    | "Cancelar"
    | "Confirmar"
    | "Imprimir"
    | "Limpar"
    | "Pesquisa"
    | "Voltar"
    | "Avançar";
  export let hint: string | null = null;

  let _hint: string;
  $: {
    if (kind == "Cancelar") _hint = "Cancela/Descarta as informações";
    else if (kind == "Confirmar") _hint = "Confirma as informações";
    else if (kind == "Imprimir") _hint = "Imprime esta página";
    else if (kind == "Limpar") _hint = "Limpa os parâmetros de procura";
    else if (kind == "Voltar") _hint = "Retorna para a etapa anterior";
    else if (kind == "Avançar") _hint = "Avança para a próxima etapa";
    else if (kind == "Pesquisa")
      _hint = "Efetuar a pesquisa com os parâmetros selecionados acima";
    else _hint = hint;
  }
</script>

<button
  type={kind == "Limpar"
    ? "reset"
    : ["Pesquisa", "Confirmar"].includes(kind)
    ? "submit"
    : "button"}
  class="ui-button ui-corner-all"
  aria-label={_hint}
  data-kind={kind}
  on:click
  use:tooltip
>
  <span
    class:bt-avancar={kind == "Avançar"}
    class:bt-cancelar={["Cancelar", "Não"].includes(kind)}
    class:bt-confirmar={["Confirmar", "Sim"].includes(kind)}
    class:bt-imprimir={kind == "Imprimir"}
    class:bt-limpar={kind == "Limpar"}
    class:bt-pesquisa={kind == "Pesquisa"}
    class:bt-voltar={kind == "Voltar"}
  />
  {kind}
</button>

<style>
  .ui-button span {
    width: 24px;
    height: 24px;
    background-repeat: no-repeat; /* make the background image appear only once */
    background-position: -2px -2px;
    padding-left: 20px; /* make text start to the right of the image */
    vertical-align: middle; /* align the text vertically centered */
    background-size: 18px 18px;
  }

  .bt-avancar {
    background-image: url(https://sistemas2.utfpr.edu.br/imagem/avancar.png);
  }
  .bt-cancelar {
    background-image: url(https://sistemas2.utfpr.edu.br/imagem/cancelar.png);
  }

  .bt-confirmar {
    background-image: url(https://sistemas2.utfpr.edu.br/imagem/confirmar.png);
  }

  .bt-limpar {
    background-image: url(https://sistemas2.utfpr.edu.br/imagem/limpar.png);
  }

  .bt-imprimir {
    background-image: url(https://sistemas2.utfpr.edu.br/imagem/print.png);
  }

  .bt-pesquisa {
    background-image: url(https://sistemas2.utfpr.edu.br/imagem/procurar.png);
  }
  .bt-voltar {
    background-image: url(https://sistemas2.utfpr.edu.br/imagem/voltar.png);
  }
</style>
