<script lang="ts">
  import { getContext, onMount, onDestroy } from "svelte";

  import type { ITableCol, ITableContext } from "../../defs/UTypeDefs";
  import { formatters, sorters } from "../../defs/UTypeDefs";
  import type { TableColAlign } from "../../defs/UTypeDefs";

  const { register, unRegister } = getContext<ITableContext>("UTable");

  // let value: number;

  let styleClass: string | null = null;
  export { styleClass as class };

  export let key: string | null = null;
  export let title: string | null = null;
  export let show: boolean = true;
  export let hintKey: string | null = null;
  export let align: TableColAlign = "default";
  export let isStrong: boolean = false;
  export let filterable: boolean = true;
  export let sortable: boolean = true;
  export let exportable: boolean = true;
  export let defaultValue: string = "";

  export let format: "none" | "CPF" = "none";

  const col: ITableCol = {
    key,
    title: title || key,
    show,
    hintKey,
    styleClass,
    align,
    isStrong,
    filterable,
    sortable,
    exportable,
    formatter:
      format == "CPF"
        ? formatters.cpf
        : (data: any): string =>
            data == null || data == undefined || data === ""
              ? defaultValue
              : data,
    sorter: sorters.string,
  };

  onMount(() => register(col));
  onDestroy(() => unRegister(col));
</script>
