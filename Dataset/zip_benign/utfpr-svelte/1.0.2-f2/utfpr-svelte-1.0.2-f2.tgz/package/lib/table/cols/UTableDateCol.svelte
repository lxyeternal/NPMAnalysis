<script lang="ts">
  import { getContext, onMount, onDestroy } from "svelte";
  import type { ITableCol, ITableContext } from "../../defs/UTypeDefs";
  import { formatters, sorters } from "../../defs/UTypeDefs";
  import type { TableColAlign } from "../../defs/UTypeDefs";

  const { register, unRegister } = getContext<ITableContext>("UTable");

  let styleClass: string | null = null;
  export { styleClass as class };

  type dateFormats =
    | "DMY"
    | "YMD"
    | "localDateTime"
    | "time"
    | "localTime"
    | "dateTime";

  export let key: string | null = null;
  export let title: string | null = null;
  export let show: boolean = true;
  export let hintKey: string | null = null;
  export let align: TableColAlign = "right";
  export let isStrong: boolean = false;
  export let format: dateFormats = "DMY";
  export let filterable: boolean = true;
  export let sortable: boolean = true;
  export let exportable: boolean = true;

  let formats = {
    DMY: formatters.date,
    YMD: formatters.dateYMD,
    localDateTime: formatters.dateTimeLocal,
    time: formatters.time,
    localTime: formatters.timeLocal,
    dateTime: formatters.dateTime,
  };

  const col: ITableCol = {
    key,
    title: title || key,
    show,
    hintKey,
    styleClass,
    align,
    isStrong,
    filterable,
    sortable,
    exportable,
    formatter: formats[format] || formatters.date,
    sorter: sorters.date,
  };

  onMount(() => register(col));
  onDestroy(() => unRegister(col));
</script>
