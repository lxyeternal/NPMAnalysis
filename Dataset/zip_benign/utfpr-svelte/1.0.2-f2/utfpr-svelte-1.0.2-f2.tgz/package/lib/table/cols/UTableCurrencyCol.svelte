<script lang="ts">
  import { getContext, onMount, onDestroy } from "svelte";

  import type { ITableCol, ITableContext } from "../../defs/UTypeDefs";
  import { formatters, sorters } from "../../defs/UTypeDefs";
  import type { TableColAlign } from "../../defs/UTypeDefs";

  const { register, unRegister } = getContext<ITableContext>("UTable");

  let styleClass: string | null = null;
  export { styleClass as class };

  export let key: string | null = null;
  export let title: string | null = null;
  export let show: boolean = true;
  export let hintKey: string | null = null;
  export let align: TableColAlign = "right";
  export let isStrong: boolean = false;

  export let thousandsSeparator: "," | "." | " " | "" = ".";

  export let symbol: string = "";
  export let decimals: number = 2;
  export let decimalSeparator: "," | "." = ",";
  export let filterable: boolean = true;
  export let sortable: boolean = true;
  export let exportable: boolean = true;

  const col: ITableCol = {
    key,
    title: title || key,
    show,
    hintKey,
    styleClass,
    align,
    isStrong,
    filterable,
    sortable,
    exportable,
    formatter: function (data: string | number | null) {
      return (
        symbol +
        " " +
        formatters.toMoney(
          data || "0",
          decimals,
          decimalSeparator,
          thousandsSeparator
        )
      ).trim();
    },
    sorter: sorters.number,
  };

  onMount(() => register(col));
  onDestroy(() => unRegister(col));
</script>
