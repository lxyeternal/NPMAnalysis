<script lang="ts">
  import {
    getContext,
    onMount,
    onDestroy,
    createEventDispatcher,
  } from "svelte";

  import type { ITableButton, ITableContext } from "../../defs/UTypeDefs";
  const { registerButton, unregisterButton } =
    getContext<ITableContext>("UTable");

  const dispatch = createEventDispatcher();

  export let title: string = "btn";
  export let hint: string | null = null;
  export let visible: boolean = true;

  const col: ITableButton = {
    title,
    hint,
    visible,
    onClick(row: any /*, data: []*/) {
      dispatch("click", row);
    },
  };

  onMount(() => registerButton(col));
  onDestroy(() => unregisterButton(col));
</script>
