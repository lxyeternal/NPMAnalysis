<script lang="ts">
  import { setContext } from "svelte";
  import type {
    ITableCol,
    ITableContext,
    ITableButton,
  } from "../defs/UTypeDefs";
  import { formatters } from "../defs/UTypeDefs";
  import tooltip from "../tooltip/tooltip";
  import { httpHandler } from "../services/HttpHandler";

  export let csvFileName: string | null = "arquivo.csv";
  export let caption = null; //: string | null = null;
  export let data = [];
  export let id = null; //: string | null = null;
  export let sorter: number[] | number = [];
  export let rowKey: string | null = null;

  let startIndex = -1;
  // let found = "";
  let cols: ITableCol[] = null;

  let lastSort = [-999999];
  let sortedData;
  let rowButtons: ITableButton[] = [];

  $: sort = [].concat(sorter);
  $: currentSort = !sort.length ? 0 : sort[0];
  $: if (sort.join("_") != lastSort.join("_"))
    sortedData =
      cols == null
        ? [] //
        : (data || []) //
            .filter(doFilter)
            .sort(doSort);

  // $: console.log("data changed!", data);

  function doFilter(r: any): boolean {
    for (let index = 0; index < cols.length; index++) {
      const title = cols[index];
      if (!!title.key && title.filter != "") {
        const text: string = (r[title.key] || "")?.toString().toUpperCase();
        const exist: number = text.indexOf(title.filter.trim().toUpperCase());
        // console.log(title.filter, text, exist);
        if (exist < 0) return false;
      }
    }
    return true;
  }

  function doSort(a: any, b: any): number {
    if (sort.length == 0) return 0;
    for (let idx = 0; idx <= sort.length; idx++) {
      const elem = sort[idx],
        pos = Math.abs(elem),
        col: ITableCol = cols[pos - 1] || null;
      if (pos > 0 && !!col) {
        const key: string = col.key;

        //console.log(idx, elem, pos, col, key);
        if (!!key) {
          const order =
            elem < 0 ? col.sorter(b[key], a[key]) : col.sorter(a[key], b[key]);
          if (order != 0) return order;
        }
      }
    }
    return 0;
  }

  function exportToCSV(charset: string = "utf-8"): void {
    const mime = "data:text/csv" + (!charset ? "" : ";charset=" + charset);
    const csv = [];
    if (caption)
      csv.push('"' + caption.replace(/"/g, "'").replace("<br>", "\n") + '";');

    let _row = [];

    // título das Colunas...
    const _columns = {};
    cols.forEach((c) => {
      if (c.exportable) {
        _row.push('"' + (c.title || " ").replace(/"/g, "'") + '"');
        _columns[c.key] = c.formatter || formatters.none;
      }
    });
    csv.push(_row.join(";"));

    // dados
    data.forEach((d) => {
      _row = [];
      for (var key in _columns) {
        const _val = d[key];
        const _formatter = _columns[key] || formatters.none;
        _row.push(
          '"' +
            ("" + _formatter(_val))
              .trim()
              .replace("<br>", "\n")
              .replace(/<[^>]*>/g, "")
              .replace(";", "*") +
            '"'
        );
      }
      csv.push(_row.join(";"));
    });
    httpHandler.fsDoDownload(csvFileName, mime, csv.join("\r\n"));
  }

  setContext<ITableContext>("UTable", {
    register: (col: ITableCol): void => {
      if (!col) return;
      startIndex += 1;
      if (col.filter == undefined) col.filter = "";
      cols = (cols || []).concat([col]);
    },
    unRegister: (col: ITableCol): void => {
      // remove da lista
      cols = (cols || []).filter((o) => o != col);
    },
    registerButton: (btn: ITableButton): void => {
      rowButtons = rowButtons.concat(btn);
    },
    unregisterButton: (btn: ITableButton): void => {
      rowButtons = rowButtons.filter((o) => o != btn);
    },
  });
</script>

<center>
  <slot>
    <em>No UTableCol was provided!</em>
  </slot>

  <table {id} cellspacing="0">
    {#if !!caption || (!!data && data.length)}
      <caption class="ui-corner-tl ui-corner-tr shadow">
        <span>{caption || ""}</span>
        <span class="pull-right">
          <button
            class="ui-button ui-corner-all"
            aria-label="Exporta a tabela abaixo no formato CSV (para uso no Excel, LibreOffice)"
            on:click={() => exportToCSV()}
            use:tooltip
          >
            Download <i class="fa fa-file-excel-o" />
          </button>
        </span>
      </caption>
    {/if}
    {#if cols && cols.length}
      <thead class="shadow">
        <tr>
          {#each cols as title, idx}
            {#if title.show}
              <th
                class:colRight={title.align == "right"}
                class:colCenter={title.align == "center"}
                rowspan={!title.filterable ? 2 : 1}
              >
                {title.title}
                {#if title.sortable}
                  <button
                    class="ui-button ui-corner-all pull-right fa"
                    class:fa-sort={idx + 1 != Math.abs(currentSort)}
                    class:fa-sort-amount-asc={idx + 1 == currentSort}
                    class:fa-sort-amount-desc={idx + 1 == 0 - currentSort}
                    on:click={() =>
                      (sorter =
                        Math.abs(currentSort) == idx + 1
                          ? [0 - currentSort]
                          : [idx + 1])}
                  />
                {/if}
              </th>
            {/if}
          {/each}
          {#if rowButtons.length}
            <th rowspan={2}>Ação</th>
          {/if}
        </tr>
        <tr>
          {#each cols as title}
            {#if title.show && title.filterable}
              <th>
                <input
                  class="ui-widget ui-corner-all ui-default"
                  type="search"
                  bind:value={title.filter}
                />
              </th>
            {/if}
          {/each}
        </tr>
      </thead>

      {#if !!data && data.length}
        <tbody class="shadow">
          {#key sortedData}
            {#each sortedData as row, line}
              <tr data-row={!!rowKey ? row[rowKey] || line : line}>
                {#each cols.filter((f) => f.show) as title}
                  <td
                    class:colLeft={title.align == "left"}
                    class:colCenter={title.align == "center"}
                    class:colRight={title.align == "right"}
                    class:colStrong={title.isStrong}
                    aria-label={!!title.hintKey ? row[title.hintKey] : null}
                    use:tooltip
                  >
                    {#if title.styleClass}
                      <span class={title.styleClass}>
                        {(title.formatter || formatters.none)(
                          title.key == "#" ? line + 1 : row[title.key] || ""
                        )}
                      </span>
                    {:else}
                      {(title.formatter || formatters.none)(
                        title.key == "#" ? line + 1 : row[title.key] || ""
                      )}
                    {/if}
                  </td>
                {/each}

                {#if rowButtons.length}
                  <td>
                    {#each rowButtons as btn}
                      <button
                        type="button"
                        aria-label={btn.hint}
                        class="ui-button ui-corner-all"
                        use:tooltip
                        on:click={() => btn.onClick(row)}
                      >
                        {btn.title}
                      </button>
                    {/each}
                  </td>
                {/if}
              </tr>
            {/each}
          {/key}
        </tbody>
      {/if}
    {/if}

    <tfoot>
      <tr>
        <th
          class:colCenter={true}
          colspan={(cols || [{}]).length + (rowButtons.length ? 1 : 0)}
          class="ui-corner-bl ui-corner-br shadow"
        >
          {(data || []).length} rows
        </th>
      </tr>
    </tfoot>
  </table>
</center>

<style>
  table {
    line-height: 1.2rem;
    border-collapse: separate;
    width: calc(100% - 4px);
    margin: 1px;
    padding: 0px;
    font-family: "Oracle Sans";
  }

  caption {
    font-weight: bold;
    background-color: var(--bg-active);
    color: var(--font-active);
    border: 1px solid var(--border-focus);
    text-shadow: 1px 1px 1px var(--shadow);
  }

  caption,
  caption span {
    vertical-align: middle;
    vertical-align: -webkit-baseline-middle;
  }

  tbody tr td {
    padding: 2px;
    font-size: 12px;
  }

  tbody tr td,
  tfoot tr th {
    border-top: 1px solid var(--border-focus);
  }

  tfoot tr:last-child th {
    border-bottom: 1px solid var(--border-focus);
  }

  thead tr th,
  tbody tr td,
  tfoot tr th {
    border-left: 1px solid var(--border-focus);
  }

  thead tr th:last-child,
  tbody tr td:last-child,
  tfoot tr th {
    border-right: 1px solid var(--border-focus);
  }

  th {
    margin: 4px;
  }

  thead,
  tfoot {
    background-color: var(--bg-aside);
  }

  caption .pull-right {
    margin: 2px;
  }

  tbody tr:not(:hover):nth-child(odd) {
    background-color: var(--bg-primary);
  }

  tbody tr:hover {
    background-color: var(--cell-hover);
  }

  thead input.ui-default {
    font-size: 1rem;
    height: 1.5rem;
    outline: none;
    transition: 0.1s ease-out;
    -webkit-appearance: none;
    background-color: var(--bg-primary);
    width: calc(95% - 4px);
    padding: 2px 4px;
    margin: 2px 0px;
    border: 1px solid var(--border-highlight);
  }

  thead input:hover {
    background-color: var(--bg-hover);
  }

  thead input:focus {
    border: 2px solid var(--border-focus);
    padding: 1px 3px;
  }

  thead :global(span.fa) {
    min-width: 1rem;
    margin: 2px 2px 0 2px;
  }

  button.fa.pull-right {
    min-width: 1.5rem;
  }
</style>
