import { notifications } from "../tooltip/notifications";

const ahh = 'app_http_handler';
const decoder = new TextDecoder('iso-8859-1');

export interface DMLError {
  type: string,
  code?: string | number,
  msg: string,
};
export interface DMLResult {
  status: "---" | "INSERT" | "DELETE" | "UPDATE" | "IMPORT",
  ok?: boolean,
  errors?: DMLError[],
  attrs?: { [key: string]: string | number },
  indicadores?: { [key: string]: number },
  mensagens?: string[],
  data?: any | any[],
};

const serialize = (form: HTMLFormElement): string | null => {
  if (!form || form.nodeName !== 'FORM') return null;

  const q: string[] = [];
  for (let i: number = form.elements.length - 1; i >= 0; i--) {
    let element = form.elements[i];
    if (element.name === '') continue;
    let value: string = encodeURIComponent(element.value);

    switch (element.nodeName) {
      case 'INPUT':
        switch (element.type) {
          case 'text':
          case 'date':
          case 'time':
          case 'number':
          case 'hidden':
          case 'password':
            q.push(element.name + '=' + value);
            break;
          case 'checkbox':
          case 'radio':
            if (element.checked) {
              q.push(element.name + '=' + value)
            }
            break;
        }
        break;
      case 'TEXTAREA':
        q.push(element.name + '=' + value);
        break;
      case 'SELECT':
        switch (element.type) {
          case 'select-one':
            q.push(element.name + '=' + encodeURIComponent(element.value));
            break;
          case 'select-multiple':
            for (let j = element.options.length - 1; j >= 0; j--)
              if (element.options[j].selected)
                q.push(
                  element.name + '=' +
                  encodeURIComponent(element.options[j].value));
            break;
        }
        break;
    }
  }
  return q.join('&');
};

async function futureData(data): Promise<any> {
  return new Promise(function (resolve, reject) {
    if (data instanceof Error) {
      httpHandler.debug && console.log('FutureData: error', data);
      reject(data);
    } else
      resolve(data);
  });
}

const saveForm = (url: string, form: HTMLFormElement, success: (data: DMLResult) => void, fail: (data: DMLResult) => void = defaultDMLFail): boolean => {
  if (!form || !form.reportValidity()) return false;

  const serialized = serialize(form);
  if (!serialized) return false;

  save(url, serialized, success, fail);
  return true;
};

const defaultDMLFail = (data: DMLResult) => {
  if (data.errors?.forEach) data.errors.forEach(err => notifications.danger(err.msg));
}

const save = (url: string, serialized: any, success: (data: DMLResult) => void, fail: (data: DMLResult) => void = defaultDMLFail): void => {
  _load(url, httpHandler.url, serialized)
    .then((result: Error | DMLResult) => {
      if (result instanceof Error) throw result;

      if (result?.errors?.length) fail(result)
      else success(result);
    })
    .catch(err => {
      if (!fail) throw err;
      const error: DMLError = { type: err.name, msg: err.message };
      const dml: DMLResult = { status: '---', errors: [error] };
      fail(dml);
    });
};

async function _load(url: string, prefix: string = httpHandler.url, body: string | null = null) {
  const attr = {
    method: !body ? "GET" : "POST",
    // mode: 'no-cors',
    // redirect: 'manual',
    body: (body != null) ? new URLSearchParams(body) : null,
  };

  return fetch(prefix + url, attr)  //
    .then((res) => {
      const urlPrefix = location.origin;
      const rUrl = res.url.replace(urlPrefix, '').split('?')[0];
      const type = res.headers.get('Content-Type') || '';
      const contentCharSet = type.split('=').slice(-1)[0].trim();
      const error = res.headers.get('Error');
      if (!!error) return new Error(error);

      if (rUrl == '/login')
        location.href = '/login?returnUrl=' +
          encodeURIComponent(location.pathname + location.hash);

      httpHandler.debug &&
        console.log(
          res.status, res.statusText,
          // (redir ? 'Redirect ' : res.type == 'error' ? 'Error ' : '') +
          'Loading:', url, contentCharSet, rUrl, res);

      if (res.status > 400)
        return res
          .text()  //
          .then(
            text => new Error(
              res.status + ' - ' + res.statusText + ' ' +
              (text ||
                '\n[' +
                url.replace(/\?/g, '\n?')  //
                  .replace(/\&/g, '\n&') +
                ']')));

      if (contentCharSet != 'iso-8859-1') return res.json();

      return res
        .arrayBuffer()  //
        .then(buffer => JSON.parse(decoder.decode(buffer)));
    });
}

async function load(url, prefix = httpHandler.url) {
  return _load(url, prefix)  //
    .then(data => {
      if (data instanceof Error) notifications.danger(data.message);
      httpHandler._lastSearch = data;
      return data;
    });
}

async function getInit(addr: string = httpHandler.initUrl): Promise<any> {
  if (addr != httpHandler.initUrl) {
    httpHandler.initUrl = addr;
    httpHandler.initData = null;
  } else if (httpHandler.initData != null)
    return new Promise(function (resolve, reject) {
      httpHandler.debug && console.log('Init: <from cache>', httpHandler.initData);
      resolve(httpHandler.initData);
    });

  return _load(httpHandler.initUrl)  //
    .then(data => {
      httpHandler.initData = data.push ?  // is an array ?
        data[0] :
        data;
      httpHandler.initied = true;
      return httpHandler.initData;
    });
}

export const httpHandler = window[ahh] || {
  url: '/',
  initData: null,
  initied: false,
  debug: false,
  init: 'init.json',
  _lastSearch: null,
  getInit,
  load,
  save,
  saveForm,
  futureData,
  serialize,
  defaultDMLFail,
  fsDoDownload: function (fileName, mime, arq): void {
    if (!arq || arq.length > 0) {
      const link = document.createElement('a');
      link.classList.add('hide');
      link.download = fileName;
      link.target = '_blank';
      document.body.appendChild(link);

      try {
        // o chrome corta urls com mais de 2 MB, então primeiro tenta como blob,
        // se falhar, entra em modo de compatibilidade.
        var blob = new Blob([arq], { type: mime });
        link.href = window.URL.createObjectURL(blob);
        setTimeout(() => {
          link.click();
          document.body.removeChild(link);
        }, 25);
        setTimeout(() => window.URL.revokeObjectURL(link.href), 1500);
      } catch (err) {
        var dados = encodeURIComponent(arq);
        // console.log(dados);
        setTimeout(() => {
          link.href = mime + ',' + dados;
          link.click();
          document.body.removeChild(link);
        }, 25);
      }
    } else
      alert('não foi possível exportar os dados');
  }
};

if (!window[ahh]) window[ahh] = httpHandler;
