export type TableColType = 'text'|'integer'|'date'|'currency';

export type TextAlign = 'left'|'right'|'center';
export type TableColAlign = 'left'|'right'|'center'|'default';

export interface IChildContext<T> {
  register(child: T): void,        //
      unRegister(child: T): void,  //
}

export interface ITabsTab {
  label: string,                       //
      tabIndex?: number,               //
      id?: string,                     //
      hint?: string,                   //
      setActive(index: number): void,  //
      visible: boolean,                //
}
export type ITabContext = IChildContext<ITabsTab>;

export interface IRouterLink {
  label: string,       //
      group: string,   //
      hint?: string,   //
      route: string,   //
      component: any,  // setState(active: boolean): void,
}
export type IRouterContext = IChildContext<IRouterLink>;

export interface ITableCol {           //
  key: string|null,                    //
      title: string,                   //
      hintKey?: string,                //
      styleClass?: string,             //
      align: TableColAlign,            //
      show: boolean,                   //
      filterable: boolean,             //
      sortable: boolean,               //
      exportable: boolean,             //
      filter?: string,                 //
      isStrong: boolean,               //
      render?: object,                 //
      formatter(data: any): string,    //
      sorter(a: any, b: any): number,  //
}

export interface ITableButton {
  title: string,                                   //
      hint?: string,                               //
      visible: boolean,                            //
      onClick(row: any /* , data: any[]*/): void,  //
}

export interface ITableContext extends IChildContext<ITableCol> {
  registerButton(bt: ITableButton),        //
      unregisterButton(bt: ITableButton),  //
}


export interface IFormElement {
  notify(): void
}
export type IFormContext = IChildContext<IFormElement>;

export let i18n = {
  YES: 'Sim',
  NO: 'Não',
  GENDER: {'M': 'Masculino', 'F': 'Feminino'}
}

export interface IDate {
  day: string,         //
      month: string,   //
      year: string,    //
      hour: string,    //
      minute: string,  //
      second: string,  //
}

function dateSplit(data: any): IDate|null {
  if (!data) return null;
  // if param is a date, keep it, otherwise.. convert
  let d = (!data.getDate ? new Date(data) : data);

  return {
    day: ('00' + d.getDate()).slice(-2),
    month: ('00' + (d.getMonth() + 1)).slice(-2),
    year: d.getFullYear(),
    hour: ('00' + d.getHours()).slice(-2),
    minute: ('00' + d.getMinutes()).slice(-2),
    second: ('00' + d.getSeconds()).slice(-2),
  };
}

const intlCollator = new Intl.Collator('pt');

export const sorters = {
  object: function(
      a: object, b: object, key: string = 'id', _default: string = ''): number {
    return (a[key] || _default) - (b[key] || _default);
  },

  bool: function(x: boolean, y: boolean): number {
    return (x === y) ? 0 : x ? -1 : 1;  // true values first
  },

  date: function(a: Date, b: Date): number {
    if (a == null && b == null) return 0;
    return a.getTime() - b.getTime();
  },

  number: function(a: number, b: number): number {
    return a - b;
  },
  /*
    string: function(a: string, b: string): number {
      const a1 = (a || '').trim();
      const b1 = (b || '').trim();
      return a1 == b1 ? 0 : a1 < b1 ? -1 : +1;
    }
  */
  string: function(a: string, b: string): number {
    return intlCollator.compare((a || '').trim(), (b || '').trim());
  }
};

export const formatters = {
  toMoney: function(
      number: string|number,       //
      decimals: number = 2,        //
      decimal_sep: string = ',',   //
      thousands_sep: string = '.'  //
      ): string {
    // if decimal is zero we must take it, it means
    // user does not want to show any decimal
    let c = Math.abs(decimals);
    let n: number = parseFloat(number.toString());
    let sign = n < 0 ? '-' : '';
    // extracting the absolute value of the integer part of the number and
    // converting to string
    const val = Math.abs(n).toFixed(c);
    let i: string = parseInt(val) + '';
    n = parseFloat(val);
    let j = i.length;
    j = j > 3 ? j % 3 : 0;
    return (
        sign + (j ? i.substr(0, j) + thousands_sep : '') +
        i.substr(j).replace(/(\d{3})(?=\d)/g, '$1' + thousands_sep) +
        (c ? decimal_sep + Math.abs(n - parseFloat(i)).toFixed(c).slice(2) :
             ''));
  },

  none: function(data: any): string {
    return data;
  },

  lpad4: function(num: number): string |
      number {
        return num <= 9999 ? ('0000' + num).slice(-4) : num;
      },

  boolean: function(value: string): string {
    let _val = ('' + value).replace(/^0+/, '').toUpperCase();
    return ['S', 'SIM', 'Y', 'YES', 'T', 'TRUE', '1'].includes(_val) ?
        i18n.YES :
        i18n.NO;
  },

  cnpj: function(cnpj: string): string {
    if (!cnpj) return '';
    if (cnpj.length > 14) return cnpj;
    let temp = cnpj.padStart(14, '0');
    return formatters.toMoney(temp.slice(0, 8), 0) + '/' + temp.slice(8, 12) +
        '-' + temp.slice(-2);
  },

  cpf: function(cpf: string): string {
    if (!cpf) return '';
    if (cpf.length > 11) return cpf;
    // return formatters.toMoney(cpf.slice(-11, -2), 0) + '-' +
    // cpf.slice(-2);
    let temp = cpf.padStart(11, '0');
    return temp.slice(0, 3) + '.' + temp.slice(3, 6) + '.' + temp.slice(6, 9) +
        '-' + temp.slice(-2);
  },

  date: function(data: any): string {
    if (!data) return '';
    const d = dateSplit(data);
    if (d == null) return '';
    const {day, month, year} = d;
    return [day, month, year].join('/');
  },

  dateYMD: function(data: any): string {
    if (!data) return '';
    const d = dateSplit(data);
    if (d == null) return '';
    const {day, month, year} = d;
    return [year, month, day].join('-');
  },

  dateTime: function(data: any): string {
    if (!data) return '';
    const d = dateSplit(data);
    if (d == null) return '';
    const {day, month, year, hour, minute, second} = d;
    return [day, month, year].join('/') + ' ' +
        [hour, minute, second].join(':');
  },

  dateTimeLocal: function(data: any): string {
    if (!data) return '';
    const d = dateSplit(data);
    if (d == null) return '';
    const {day, month, year, hour, minute} = d;
    return [year, month, day].join('-') + 'T' + [hour, minute].join(':');
  },

  time: function(data) {
    if (!data) return '';
    const d = dateSplit(data);
    if (d == null) return '';
    const {hour, minute, second} = d;
    return [hour, minute, second].join(':');
  },

  timeLocal: function(data: any): string {
    if (!data) return '';
    const d = dateSplit(data);
    if (d == null) return '';
    const {hour, minute} = d;
    return [hour, minute].join(':');
  },

  gender: function(data: any): string {
    if (!data) return '';
    return i18n.GENDER[data.substring(0, 1).toUpperCase()];
  }
};
