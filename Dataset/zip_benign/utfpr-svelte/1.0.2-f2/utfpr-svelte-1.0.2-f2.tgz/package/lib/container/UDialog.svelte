<script context="module" lang="ts">
  /*** based on:

  https://svelte.dev/repl/514f1335749a4eae9d34ad74dc277f20?version=3.37.0
  **/

  export interface IDialog {
    open(callback?): void;
    close(retVal?): void;
    setTitle(title): void;
  }

  let counter: number = 1;
  let onTop; //keeping track of which open modal is on top

  const modals = new Map<String, IDialog>(); //all modals get registered here for easy future access

  // function listModals(msg:string) { console.log("UDialog", msg, modals); }

  function dropModal(id: string) {
    modals.delete(id);
    // listModals("deleting: " + id );
  }

  function addModal(id: string, open, close, setTitle) {
    modals.set(id, { open, close, setTitle });
    // listModals( "adding: " + id );
  }

  // 	returns an object for the modal specified by `id`, which contains the API functions (`open` and `close` )
  export function getModal(id: string): IDialog {
    // listModals( "finding: " + id );
    return modals.get(id);
  }
</script>

<script lang="ts">
  import { onDestroy, onMount } from "svelte";
  import tooltip from "../tooltip/tooltip";

  let topDiv;
  let visible: boolean = false;
  let prevOnTop;
  let closeCallback;

  export let id = "pnl_" + ++counter;
  export let title: string = "Dialog";
  export let hint: string | null = null;

  function keyPress(ev) {
    //only respond if the current modal is the top one
    if (ev.key == "Escape" && onTop == topDiv) close(null); //ESC
  }

  /**  API **/
  function open(callback?): void {
    closeCallback = callback;
    if (visible) return;
    prevOnTop = onTop;
    onTop = topDiv;
    window.addEventListener("keydown", keyPress);

    //this prevents scrolling of the main window on larger screens
    document.body.style.overflow = "hidden";

    visible = true;
    //Move the modal in the DOM to be the last child of <BODY> so that it can be on top of everything
    document.body.appendChild(topDiv);
  }

  function setTitle(newTitle: string): void {
    title = newTitle;
  }

  function close(retVal?): void {
    if (!visible) return;
    window.removeEventListener("keydown", keyPress);
    onTop = prevOnTop;
    if (onTop == null) document.body.style.overflow = "";
    visible = false;
    if (closeCallback) closeCallback(retVal);
  }

  //expose the API
  onMount(() => addModal(id, open, close, setTitle));

  onDestroy(() => {
    dropModal(id);
    window.removeEventListener("keydown", keyPress);
  });
</script>

<div
  class="topModal"
  class:visible
  bind:this={topDiv}
  on:click={() => close(null)}
  on:keypress={keyPress}
>
  <div
    role="dialog"
    class="modal"
    aria-labelledby={id}
    on:click|stopPropagation={() => {}}
    on:keypress={() => {}}
    data-id={id}
  >
    <h3
      class="ui-default ui-helper-clearfix ui-corner-tl ui-corner-tr"
      aria-label={hint}
      use:tooltip
    >
      <span {id} class="pull-left">{title}</span>
    </h3>
    <svg
      class="close"
      on:click={() => close(null)}
      on:keypress={() => {}}
      viewBox="0 0 12 12"
      aria-label="pressione para fechar a janela!"
      use:tooltip
    >
      <circle cx="6" cy="6" r="6" />
      <line x1="3" y1="3" x2="9" y2="9" />
      <line x1="9" y1="3" x2="3" y2="9" />
    </svg>

    <div class="modal-content">
      <slot />
    </div>
  </div>
</div>

<style>
  div.topModal {
    visibility: hidden;
    z-index: 999;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(64, 64, 64, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
  }
  div.modal {
    position: relative;
    border-radius: 6px;
    background: white;
    border: 1px solid var(--border-default);
    filter: drop-shadow(6px 6px 6px #555);
    padding: 0px /*1em*/;
    text-align: center;
  }

  .visible {
    visibility: visible !important;
  }

  svg.close {
    position: absolute;
    top: -12px;
    right: -12px;
    width: 24px;
    height: 24px;
    cursor: pointer;
    fill: #c00;
    transition: transform 0.3s;
  }

  svg.close:hover {
    transform: scale(2);
    filter: drop-shadow(2px 2px 2px #555);
  }

  svg.close line {
    stroke: #fff;
    stroke-width: 2;
  }

  div.modal-content {
    max-width: calc(100vw - 4rem);
    max-height: calc(100vh - 4rem);
    overflow: auto;
    margin: 1em;
  }

  h3 {
    margin: 0px;
  }
  h3 span {
    margin: 4px 0.7em;
  }
</style>
