<script lang="ts">
  export let id:string | null = null;
</script>

<div style="text-align: center;" data-id={id}>
  <slot />
</div>
