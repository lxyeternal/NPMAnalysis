<script context="module" lang="ts">
  let counter: number = 1;
</script>

<script lang="ts">
  import { createEventDispatcher } from "svelte";
  import { slide } from "svelte/transition";
  import tooltip from "../tooltip/tooltip";

  // dispatcher for "onCollapse" event
  const dispatch = createEventDispatcher();

  // title of the Panel
  export let title: string = "panel";

  // the hint (when mouse is moving over)
  export let hint: string | null = null;

  // show the button for 'open/close' ?
  export let collapsable: boolean = true;

  // is opened ?
  export let open: boolean = true;

  // this panel panel can be joinned with prior panel ?
  export let joinned: "none" | "vertical" = "none";

  // id for Aria Purposes
  export let id = "pnl_" + ++counter;

  function doChange() {
    open = !open;
    dispatch("collapse", { open });
  }
</script>

<section
  class="ui-panel shadow"
  aria-labelledby={id}
  class:margin={joinned == "none"}
  aria-expanded={open}
  data-id={id}
>
  <h3
    class="ui-default ui-helper-clearfix ui-corner-tl ui-corner-tr"
    class:ui-corner-all={!open}
    aria-label={hint}
    use:tooltip
  >
    <span {id} class="pull-left">{title}</span>
    {#if collapsable}
      <button
        type="button"
        class="ui-button pull-right fa"
        class:fa-chevron-up={open}
        class:fa-chevron-down={!open}
        aria-label="clique para abrir/fechar o conteúdo abaixo"
        on:click={doChange}
        use:tooltip
      />
    {/if}
  </h3>
  {#if open}
    <div
      class="ui-content ui-helper-clearfix ui-corner-bl ui-corner-br "
      in:slide={{ duration: 300 }}
      out:slide={{ duration: 300 }}
      role="region"
    >
      <div style="flex-direction:row">
        <slot><br /></slot>
      </div>
    </div>
  {/if}
</section>

<style>
  .ui-panel .ui-default span.pull-left {
    font-weight: bold;
  }

  .ui-panel h3.ui-default {
    color: var(--border-highlight);
    background-color: var(--bg-primary);
    margin: 0px;
  }

  .ui-panel h3.ui-default,
  .ui-panel div.ui-content {
    padding: 2px 4px;
  }

  .ui-panel {
    border-radius: 0.35em;
  }

  .ui-panel.margin {
    margin: 5px 0px;
  }

  .ui-panel h3.ui-default.ui-corner-tl.ui-corner-tr {
    padding: 0.2rem 0.3em;
  }

  .ui-panel button.pull-right,
  .ui-panel h3.ui-default,
  .ui-panel div.ui-content:not(.ui-tabs-panel) {
    border: 1px solid var(--border-default);
  }

  .ui-panel div.ui-content {
    border-top: 0px;
  }

  .ui-panel button.pull-right {
    border-radius: 0.35em;
  }

  .ui-panel div.ui-content {
    padding: 6px 8px 8px 4px;
    border-top: 0px;
  }

  .ui-panel button.pull-right:hover:not(:focus),
  .ui-panel button.pull-right:hover:not(:focus):not(:active) {
    border: 1px solid var(--border-active);
    color: var(--text-active);
    box-shadow: 1px 1px 6px var(--shadow);
    transition: box-shadow 0.35s, border 0.5s;
  }
</style>
