export default function tooltip(node, params = {}) {
  const tipNameSpaceURI = 'http://www.w3.org/1999/xhtml';

  const tooltip = window['tooltip'] || {
    id: 'qTip',
    offsetX: -40,
    offsetY: 25,
    tip: null,
    container: null,
    init: (node, param) => {
      // console.log('Init', node, param);
      node.addEventListener('mouseover', tooltip.showNode);
      node.addEventListener('mouseout', tooltip.hide);
      node.addEventListener('mousemove', tooltip.move);
    },
    update: (node , param? ) => {
      // console.log('update:', node, param);
      tooltip.showNode({target: node});
    },
    destroy: (node) => {/*console.log('destroy:', node) */},

    move: function(evt) {
      const x = evt.pageX;
      const y = evt.pageY;

      const tip = tooltip.getContainer();
      if (!tip) return;
      tip.style.top = (y + tooltip.offsetY) + 'px';
      if (x + 250 > window.innerWidth) {
        tip.style.left = null;
        tip.style.right = '2px';
      } else {
        tip.style.left = (x + tooltip.offsetX) + 'px';
        tip.style.right = null;
      }
      // console.log('move', y, x, evt);
    },
    showNode: function(evt) {
      let target = evt.target;
      // console.log('showNode: ', target);

      let text = target.getAttribute('aria-label')  //
          || target.getAttribute('tiptitle')        //
          //  || target.getAttribute('placeholder')     //
          || target.getAttribute('title')  //
          || target.data?.hint;

      if (!!text) return tooltip.show(text, evt.pageX || -1, evt.pageY || -1);

      if (target.parentElement) {
        target = target.parentElement;
        let text = target.getAttribute('aria-label') ||
            target.getAttribute('tiptitle') || target.getAttribute('title');

        if (!!text) return tooltip.show(text);
      }
    },
    show: function(text, x = -1, y = -1) {
      // console.log('show', text);
      if (!!text) tooltip.hide();

      const tip = tooltip.getContainer();
      if (!tip) return;
      if (x > 0) tip.style.left = x + 'px';
      if (y > 0) tip.style.top = y + 'px';
      tip.innerHTML = text;
      tip.classList.add('show');
    },
    hide: function(evt) {
      // console.log('hide');
      const tip = tooltip.getContainer();
      if (!tip) return;
      tip.classList.remove('show');
      tip.innerHTML = '';
    },
    getContainer: function() {
      if (!tooltip.container) {
        tooltip.container = document.getElementById(tooltip.id);

        if (!tooltip.container) {
          const tipContainer = document.createElementNS ?
              document.createElementNS(tipNameSpaceURI, 'div') :
              document.createElement('div');
          tipContainer.setAttribute('id', tooltip.id);

          window.document.body.appendChild(tipContainer);
          tooltip.container = tipContainer;
        }
      }
      return tooltip.container;
    }
  };

  if (!window['tooltip']) window['tooltip'] = tooltip;

  // module.exports = function tooltip(node, params = {}) {
  tooltip.init(node, params);

  return {
    // If the props change, let's update the Tippy instance:
    update: (newParams?) => window['tooltip'].update(node, newParams),

    // Clean up the Tippy instance on unmount:
    destroy: () => window['tooltip'].destroy(node)
  };
};
