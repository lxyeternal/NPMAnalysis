import { writable, derived, Readable } from "svelte/store"

const TIMEOUT = 3000;

type INotificationType = "default" | "danger" | "warning" | "info" | "success";
interface INotification {
  id: string,
  type: INotificationType,
  message: string,
  timeout: number,
};

function createNotificationStore(defaultTimeout: number = 3000) {
  const _notifications = writable<INotification[]>([]);

  function send(message: string, type: INotificationType = "default", timeout: number = defaultTimeout) {
    _notifications.update(state => {
      return [...state, { id: id(), type, message, timeout }]
    })
  }

  // let timers = [];

  const notifications: Readable<INotification[]> = derived(_notifications, ($_notifications, set) => {
    set($_notifications)
    if ($_notifications.length > 0) {
      const timer = setTimeout(() => {
        _notifications.update(state => {
          state.shift()
          return state
        })
      }, $_notifications[0].timeout)
      return () => {
        clearTimeout(timer)
      }
    }
  })
  const { subscribe } = notifications;

  return {
    subscribe,
    send,
    default: (msg = "default", timeout = 3000) => send(msg, "default", timeout),
    danger: (msg = "Danger!", timeout = 5000) => send(msg, "danger", timeout),
    warning: (msg = "Warning!", timeout = 4000) => send(msg, "warning", timeout),
    info: (msg = "Info!", timeout = 3000) => send(msg, "info", timeout),
    success: (msg = "Success!", timeout = 3000) => send(msg, "success", timeout),
  }
}

function id() {
  return '_' + Math.random().toString(36).substr(2, 9);
};

export const notifications = createNotificationStore();