<script lang="ts">
  import { getContext, onMount, onDestroy } from "svelte";
  import type { ITabContext, ITabsTab } from "../defs/UTypeDefs";

  const { register, unRegister } = getContext<ITabContext>("UTabs");

  export let label: string;
  export let hint: string | null = null;
  let visible: boolean = true;

  let isHide: boolean = false;
  let _id: string;

  const tab: ITabsTab = {
    label,
    hint,
    visible,
    setActive: (index: number): void => {
      isHide = tab.tabIndex != index;
    },
  };

  onMount(() => register(tab));
  onDestroy(() => unRegister(tab));
</script>

<div
  role="tabpanel"
  class:hide={isHide}
  aria-hidden={isHide}
  aria-labelledby={_id}
>
  <slot />
</div>

<style>
  div {
    border-width: 0;
    padding: 0.7em;
  }

  div.hide {
    display: none;
  }
</style>
