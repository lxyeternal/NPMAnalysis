<script context="module">
  let tabCounter = 0;
</script>

<script lang="ts">
  import { setContext } from "svelte";
  import type { ITabContext, ITabsTab } from "../defs/UTypeDefs";
  import tooltip from "../tooltip/tooltip";

  export let activeTab: number = 1;

  let startIndex: number = 0;
  let items: ITabsTab[] = null;

  const _id = "Tab_" + ++tabCounter;

  // Notify child tab
  $: (items || []).forEach((i: ITabsTab) => i.setActive(activeTab));

  setContext<ITabContext>("UTabs", {
    register: function (tab: ITabsTab): void {
      const idx = ++startIndex;
      tab.tabIndex = idx;
      tab.id = _id + "_" + idx;
      // console.log("register:", tab);
      items = (items || []).concat([tab]);
      tab.setActive(activeTab);
    },
    unRegister: function (tab: ITabsTab): void {
      // remove da lista
      tab.setActive(-1);
      items = (items || []).filter((o) => o != tab);
      if (activeTab == tab.tabIndex)
        activeTab = items.length ? items[0].tabIndex : 0;
    },
  });
</script>

<section class="ui-corner-all shadow">
  <ul class="ui-corner-top" role="tablist" id={_id}>
    {#if !!items && items.length}
      {#each items as i}
        <li
          class="ui-corner-top"
          class:active={i.tabIndex == activeTab}
          aria-selected={i.tabIndex == activeTab}
          aria-expanded={i.tabIndex == activeTab}
          role="tab"
          id={i.id}
          aria-label={i.hint}
          use:tooltip
        >
          <span
            role="presentation"
            tabindex="-1"
            on:click={() => (activeTab = i.tabIndex)}
          >
            {i.label}
          </span>
        </li>
      {/each}
    {/if}
  </ul>
  <slot />
</section>

<style>
  section {
    padding: 0;
    border: 1px solid var(--border-focus);
  }

  ul {
    border-bottom: 1px solid var(--border-focus);
    display: flex;
    margin: 0;
    padding: 0.2em 0 0 0.2em;
    font-size: 12px;
    background-color: var(--bg-primary);
    /* border: 1px solid var(--border-focus);     color: #fff;
*/
    font-weight: bold;
  }

  .active {
    border: 1px solid var(--border-active);
    background-color: var(--bg-active);
    font-weight: bold;
    color: var(--font-active);
    margin-bottom: -1px;
    border-bottom: 0px;
  }

  li {
    list-style: none;
    float: left;
    /* position: relative; */
    top: 0;
    margin: 1px 0.2em 0 0;
    padding: 0;
    white-space: nowrap;
    padding-bottom: 1px;
    box-shadow: inset 1px 1px 1px var(--shadow);
    font-weight: bold;
    border: 1px solid var(--bg-primary);
  }

  span {
    float: left;
    padding: 0.08em 1em;
    text-decoration: none;
  }

  li:hover:not(.active) {
    cursor: pointer;
    transition: box-shadow 0.35s, border 0.5s;
    box-shadow: 1px 1px 6px var(--shadow);
    background: var(--bg-hover);
    border-color: var(--border-active);
    text-shadow: 1px 1px 3px var(--shadow);
  }

  li:not(.active) {
    border-color: var(--bg-disabled);
    background-color: var(--bg-primary);
    color: var(--border-focus);
  }
</style>
