<script context="module" lang="ts">
  
  let counter: number = 1;

  export interface IFormServices {
    reset(evt?: any): Promise<any>;
    submit(pesquisa?: boolean, evt?: any): Promise<any>;
    post(
      success: (data: DMLResult) => void,
      fail?: (data: DMLResult) => void
    ): boolean;
    validity(): boolean;
  }
</script>

<script lang="ts">
  import { createEventDispatcher, setContext } from "svelte";

  import type { IFormElement, IFormContext } from "../defs/UTypeDefs";
  import UFormButtons from "./UFormButtons.svelte";
  import UPanel from "../container/UPanel.svelte";
  import { notifications } from "../tooltip/notifications";
  import EmptySlot from "../container/EmptySlot.svelte";
  import UDialog from "../container/UDialog.svelte";
  import { type DMLResult, httpHandler } from "../services/HttpHandler";

  export let resetButton: boolean = false;
  export let searchButton: boolean = false;
  export let cancelButton: boolean = false;
  export let confirmButton: boolean = false;

  export let kind: "simple" | "collapsable" | "dialog" = "collapsable";

  export let title: string = "Form";
  export let hint: string | null = null;

  export let action: string | null = null;

  export let name: string = "frm" + counter++;

  export let dataPromisse: Promise<any> | undefined = undefined;

  let startIndex = -1;
  let elements: IFormElement[] = [];
  let formElement;

  const dispatch = createEventDispatcher();

  const formReset = async (evt = {}): Promise<any> => {
    const frm = evt?.target || formElement;
    // console.log("form reset", frm);
    Array.from(frm.elements)
      .filter(
        (elem: HTMLInputElement) =>
          elem.nodeName == "SELECT" ||
          (elem.nodeName == "INPUT" && elem.type != "BUTTON")
      )
      .reverse()
      .forEach((elem: HTMLInputElement) => {
        elem.focus();
        // console.log("elem", elem);
        // setTimeout(() => elem.focus(), 150);
      });

    dispatch("afterReset", { ...evt, data: null });
    return null;
  };

  const formSubmit = async (
    pesquisa: boolean = false,
    evt = {}
  ): Promise<any> =>
    httpHandler
      .load(formElement.action + "?" + httpHandler.serialize(formElement), "") //
      .then((d) => {
        if (pesquisa && !(d instanceof Error))
          notifications.success("Registros encontrados: " + d.length);

        dispatch("afterSubmit", { ...evt, data: d });
        return d;
      });

  const formValidity = (): boolean =>
    !formElement ? false : formElement.reportValidity();

  const formPost = (
    success: (data: DMLResult) => void,
    fail: (data: DMLResult) => void = httpHandler.defaultDMLFail
  ): boolean => httpHandler.saveForm(action, formElement, success, fail);

  export const services: IFormServices = {
    reset: formReset,
    submit: formSubmit,
    post: formPost,
    validity: formValidity,
  };

  $: console.log("UForm:", name, services, formElement);

  setContext<IFormContext>("UForm", {
    register: function (elem: IFormElement): number {
      startIndex++;
      elements.push(elem);
      return startIndex;
    },
    unRegister: function (elem: IFormElement): boolean {
      const size = elements.length;
      elements = elements.filter((e) => e != elem);
      return elements.length == size - 1;
    },
  });

  function onReset(evt = {}): null {
    dataPromisse = formReset(evt);
    return null;
  }

  function onSubmit(evt): boolean {
    const pesquisa = evt?.submitter?.dataset
      ? evt.submitter.dataset.kind == "Pesquisa"
      : false;
    // const frm = evt.target;
    // console.log("form action: ", frm.action);

    dataPromisse = formSubmit(pesquisa, evt);
    return false;
  }
</script>

<form
  on:submit|preventDefault={onSubmit}
  on:reset={onReset}
  {action}
  data-id={name}
  bind:this={formElement}
>
  <svelte:component
    this={kind == "collapsable"
      ? UPanel
      : kind == "dialog"
      ? UDialog
      : EmptySlot}
    id={name}
    bind:title
    bind:hint
  >
    <slot />

    <UFormButtons
      search={searchButton}
      reset={resetButton}
      cancelar={cancelButton}
      confirmar={confirmButton}
      dialogName={kind == "dialog" ? name : null}
    >
      <slot name="buttons" slot="buttons" />
      <slot name="lastButtons" slot="lastButtons" />
    </UFormButtons>
  </svelte:component>
</form>
