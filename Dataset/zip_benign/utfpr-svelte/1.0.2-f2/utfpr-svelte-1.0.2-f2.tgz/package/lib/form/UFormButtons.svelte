<script lang="ts">
  import Button from "../buttons/UButton.svelte";
  import { getModal } from "../container/UDialog.svelte";

  export let dialogName: string | null = null;

  export let reset: boolean = false;
  export let search: boolean = false;
  export let confirmar: boolean = false;
  export let cancelar: boolean = false;

  let closeDialog = () => {
    if (dialogName != null) getModal(dialogName).close();
  };
</script>

<div>
  {#if cancelar}
    <Button kind="Cancelar" on:click={closeDialog} />
  {/if}

  {#if reset}
    <Button kind="Limpar" />
  {/if}

  <slot name="buttons" />

  {#if search}
    <Button kind="Pesquisa" />
  {/if}

  {#if confirmar}
    <Button kind="Confirmar" on:click={closeDialog} />
  {/if}

  <slot name="lastButtons" />
</div>
