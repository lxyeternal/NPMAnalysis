
使用方法：
```
usage:
  node index.js --dir=../img/
  node index.js --dir=../img/ --base=200 --scale=[0.5, 0.25]
```
--idr表示图片目录，--base=200表示原图为2倍图，--scale=[0.5, 0.25]表示，需要压成1倍图和0.5倍图  
--dir为必选参数，--base和scale默认值为上面所示
结果就会生成1倍图和0.5倍图：
```
incentive_light_amazing.png     # 原图
incentive_light_amazing-100.png # 一倍图
incentive_light_amazing-50.png  # 0.5倍图
```
原图和生成的图片会使用imagemin进行压缩
