#! /usr/bin/env node

const fs = require('fs');
const path = require('path');
const imagemin = require('imagemin');
const imageminJpegtran = require('imagemin-jpegtran');
const imageminPngquant = require('imagemin-pngquant');


const sizeOf = require('image-size');
const sharp = require('sharp');

let args = require("args-parser")(process.argv)

function fileExist(filePath) {
  try {
    if (fs.existsSync(filePath)) {
      return true;
    }
  } catch(err) {
    console.error(err)
  }
  return false;
}

function imgSuffix(fileName) {
  let matches = fileName.match(/\.(png|jpg|jpeg)$/i);
  return matches ? matches[0] : '';
}

function getOutputPath(imgPath, scale, base) {
  let suffix = imgSuffix(imgPath);
  let outputPath = imgPath.replace(/\.(png|jpg|jpeg)$/i, '')
    + '-' + (scale * base >> 0) + suffix;
  return outputPath;
}

function resize(imgPath, scale, base, outputPath) {

  dimensions = sizeOf(imgPath); 
  return new Promise((resolve, reject) => {
    sharp(imgPath)
      .resize(dimensions.width * scale >> 0)
      .toFile(outputPath)
      .then(() => {
        console.log('resized ' + imgPath + ' to ' + outputPath); 
        resolve();
      })
      .catch(err => {
        console.error('resized ' + imgPath + ' failed');
        console.error(err);
        reject(err);
      });
  });
}

if (Object.keys(args).length === 1) {
  args.dir = Object.keys(args)[0];
}

if (!args.dir || args.dir === true) {
  console.log('usage:\n'
    + '\tresizer ../img/'
    + '\tresizer --dir=../img/\n'
    + '\tresizer --dir=../img/ --base=200 --scale=[0.5, 0.25]\n'
    + '\tresizer --dir=../img/ --base=200 --scale=[0.5, 0.25] --keep-origin # 保留原图\n');
  return;
}

if (args.scale) {
  args.scale = JSON.parse(args.scale);
}

args = Object.assign({
  base: 200, // 默认是两倍图
  scale: [0.5, 0.25], // 改成1倍图和低清图
}, args);

let allImgs = [];

let jobs = [];
let allOriginFiles = [];
fs.readdirSync(args.dir).forEach(fileName => {
  if (!imgSuffix(fileName)) {
    return;
  }
  if (/-(200|100|50)\.(png|jpg|jpeg)$/i.test(fileName)) {
    return;
  }
  let imgPath = path.join(args.dir, fileName);
  let needProcess = false;
  args.scale.forEach(scale => {
    let outputPath = getOutputPath(imgPath, scale, args.base);
    if (fileExist(outputPath)) {
      console.warn('跳过，文件已存在：' + outputPath);
      return;
    }
    allImgs.push(outputPath);
    needProcess = true;
    let job = resize(imgPath, scale, args.base, outputPath);
    jobs.push(job);
  });
  if (needProcess) {
    let originOutPath = getOutputPath(imgPath, 1, args.base);
    fs.createReadStream(imgPath).pipe(fs.createWriteStream(originOutPath));
    allImgs.push(originOutPath);
    allOriginFiles.push(imgPath);
  }
});

function deleteAllOrigin() {
  allOriginFiles.forEach(file => {
    console.log('删除' + file);
    fs.unlinkSync(file); 
  });
}

if (jobs.length) {
  // 开始压缩
  Promise.all(jobs).then(data => {
    console.log('resize完成，开始压缩以下图片');
    console.log(allImgs.join('\r\n'));
    imagemin(allImgs, {
  	  destination: args.dir,
  	  plugins: [
  		  imageminJpegtran(),
  		  imageminPngquant({
  			  quality: [0.6, 0.8]
  		  })
  	  ]
    }).then(() => {
      console.log('压缩完成！'); 
      console.log('开始删除原图');
      deleteAllOrigin();
      console.log('删除完成！');
    }); 
  });
}

// const imgPath = '../img/homework-check-inactive.png';
// resize(imgPath, 0.5);
