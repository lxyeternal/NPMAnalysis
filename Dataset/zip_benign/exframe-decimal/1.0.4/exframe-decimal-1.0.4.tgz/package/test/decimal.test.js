'use strict';

import { expect } from 'chai';

import Decimal from '../lib/decimal.js';

context('Decimal', () => {
  function validate(decimal, number) {
    expect(decimal.toNumber()).to.equal(number);
  }

  function multiply(a, b) {
    return new Decimal(a).multiply(b);
  }

  function divide(a, b) {
    return new Decimal(a).divide(b);
  }

  function add(a, b) {
    return new Decimal(a).add(b);
  }

  function subtract(a, b) {
    return new Decimal(a).subtract(b);
  }

  function testSet(op, testData) {
    for (const [operands, result] of testData) {
      const value = operands.slice(1).reduce((v, o) => op(v, o), operands[0]);
      validate(value, result);
    }
  }

  describe('Rounding Validation', () => {
    it('rounds the last digit to the nearest even', function () {
      validate(new Decimal(123.45678), 123.4568);
      validate(new Decimal(-123.45678), -123.4568);
      validate(new Decimal(123.45675), 123.4568);
      validate(new Decimal(-123.45675), -123.4568);
      validate(new Decimal(123.45665), 123.4566);
      validate(new Decimal(-123.45665), -123.4566);
      validate(new Decimal(123.45673), 123.4567);
      validate(new Decimal(-123.45673), -123.4567);
      validate(new Decimal('54.12345'), 54.1234);
      validate(new Decimal('54.12355'), 54.1236);
    });

    it('rounds to the desired precision', function () {
      validate(new Decimal(1.2345).toDecimalPlaces(4), 1.2345);
      validate(new Decimal(1.234).toDecimalPlaces(0), 1);
      validate(new Decimal(1.5).toDecimalPlaces(0), 2);
      validate(new Decimal(1.678).toDecimalPlaces(0), 2);
      validate(new Decimal(1.234).toDecimalPlaces(2), 1.23);
      validate(new Decimal(1.2345).toDecimalPlaces(3), 1.234);
      validate(new Decimal(1.2346).toDecimalPlaces(3), 1.235);
      validate(new Decimal(1.23, { precision: 2 }).toDecimalPlaces(4), 1.2300);
    });

    it('truncates to the desired precision', function () {
      validate(new Decimal(1.2345).toDecimalPlaces(4, { truncate: true }), 1.2345);
      validate(new Decimal(1.234).toDecimalPlaces(0, { truncate: true }), 1);
      validate(new Decimal(1.234).truncate(), 1);
      validate(new Decimal(1.5).toDecimalPlaces(0, { truncate: true }), 1);
      validate(new Decimal(1.678).toDecimalPlaces(0, { truncate: true }), 1);
      validate(new Decimal(1.234).toDecimalPlaces(2, { truncate: true }), 1.23);
      validate(new Decimal(1.2345).toDecimalPlaces(3, { truncate: true }), 1.234);
      validate(new Decimal(1.2346).toDecimalPlaces(3, { truncate: true }), 1.234);
      validate(new Decimal(1.23, { precision: 2 }).toDecimalPlaces(4, { truncate: true }), 1.2300);
    });

    it('rounds the results of operations correctly', function () {
      validate(new Decimal(-1.5, { precision: 1 }).multiply(1.5, { precision: 1 }), -2.2);
      validate(new Decimal(1.5, { precision: 1 }).multiply(1.5, { precision: 1 }), 2.2);
      validate(new Decimal(1.3, { precision: 1 }).multiply(3.5, { precision: 1 }), 4.6);
      validate(new Decimal(-2.5, { precision: 1 }).multiply(3.5, { precision: 1 }), -8.8);
      validate(new Decimal(1.2, { precision: 1 }).multiply(1.4, { precision: 1 }), 1.7);
      validate(new Decimal(-1.2, { precision: 1 }).multiply(1.4, { precision: 1 }), -1.7);
    });
  });

  describe('Decimal Precision', () => {
    it('supports arithmetic across multiple precisions', function () {
      validate(multiply(new Decimal(1.23, { precision: 2 }), new Decimal(0.2346)), 0.2886);
      validate(multiply(new Decimal(1.2345), new Decimal(0.23, { precision: 2 })), 0.2839);
      validate(divide(new Decimal(1.2, { precision: 2 }), new Decimal(0.234)), 5.1282);
      validate(divide(new Decimal(1.2, { precision: 2 }), new Decimal(0.234, { precision: 3 })), 5.128);
      validate(divide(new Decimal(1.2, { precision: 2 }), new Decimal(0.2, { precision: 1 })), 6);
      validate(divide(new Decimal(131535.05, { precision: 4 }), new Decimal(37, { precision: 0 })).toDecimalPlaces(2), 3555);
      validate(add(new Decimal(1.23, { precision: 2 }), new Decimal(1.2345)), 2.4645);
      validate(subtract(1.2345, new Decimal(1.23, { precision: 2 })), 0.0045);
    });

    it('it defaults to the current decimal\'s precision if the operand is a Number type', function () {
      validate(multiply(new Decimal(1.23, { precision: 2 }), 0.2346), 0.28);
      validate(divide(new Decimal(1.2, { precision: 2 }), 0.234), 5.22);
      validate(add(new Decimal(1.23, { precision: 2 }), 1.2345), 2.46);
    });
  });

  describe('Arithmetic', () => {
    it('multiplies', function () {
      validate(new Decimal(1.2).multiply(0.1), 0.12);
      validate(new Decimal(0.2).multiply(0.1), 0.02);
      validate(new Decimal(-1).multiply(1), -1);
      validate(new Decimal(-1).multiply(-1), 1);
      validate(new Decimal(0).multiply(1), 0);
    });

    it('divides', function () {
      validate(new Decimal(0.2).divide(0.1), 2);
      validate(new Decimal(1.2).divide(0.1), 12);
      validate(new Decimal(-1).divide(1), -1);
      validate(new Decimal(-1).divide(-1), 1);
      validate(new Decimal(0).divide(1), 0);
    });

    it('cannot divide by zero', function () {
      expect(() => new Decimal(1).divide(0)).throws(RangeError);
    });

    it('adds', function () {
      validate(new Decimal(0.2).add(0.1), 0.3);
      validate(new Decimal(1.2).add(0.1), 1.3);
      validate(new Decimal(0).add(-0.1), -0.1);
    });

    it('subtracts', function () {
      validate(new Decimal(0.2).subtract(0.1), 0.1);
      validate(new Decimal(1.2).subtract(0.1), 1.1);
      validate(new Decimal(0).subtract(0.1), -0.1);
    });

    it('finds the power of a decimal to a given exponent', function () {
      validate(new Decimal(2).power(2), 4);
      validate(new Decimal(2.2).power(2), 4.84);
      validate(new Decimal(0).power(2), 0);
      validate(new Decimal(2.2).power(1), 2.2);
      validate(new Decimal(2).power(3), 8);
      validate(new Decimal(1.23).power(3), 1.8609);
    });

    it('cannot use a negative exponent', function () {
      expect(() => new Decimal(2).power(-1)).to.throw('Negative exponents not supported');
    });

    it('cannot use a fractional exponent', function () {
      expect(() => new Decimal(2).power(0.5)).to.throw('Fractional exponents not supported');
    });

    it('can perform the modulo of two numbers', function () {
      validate(new Decimal(3).modulo(2), 1);
      validate(new Decimal(3.5).modulo(2), 1.5);
      validate(new Decimal(3.5555).modulo(2.2345), 1.321);
      validate(new Decimal(1.23456, { precision: 5 }).modulo(1.2345), 0.00006);
      // rounding for the final digit is implemented but I was unable to come up with an example value that utilizes it.
    });

    it('finds the absolute value', function () {
      validate(new Decimal(-1).absolute(), 1);
      validate(new Decimal(1).absolute(), 1);
    });

    it('finds the inverse value', function () {
      validate(new Decimal(-1).negative(), 1);
      validate(new Decimal(1).negative(), -1);
    });
  });

  describe('Comparisons', () => {
    it('can find the greater of two numbers', function () {
      expect(new Decimal(2.5).greaterThan(3)).to.equal(false);
      expect(new Decimal(2).greaterThan(2.5)).to.equal(false);
      expect(new Decimal(2.5).greaterThan(2)).to.equal(true);
      expect(new Decimal(2).greaterThan(2)).to.equal(false);
      expect(new Decimal(2).greaterThan(1)).to.equal(true);
      expect(new Decimal(2).greaterThan(1.5)).to.equal(true);
      expect(new Decimal(2).greaterThan(0)).to.equal(true);
      expect(new Decimal(2).greaterThan(-1)).to.equal(true);
      expect(new Decimal(-2).greaterThan(-3)).to.equal(true);
    });

    it('can find the greater or equal of two numbers', function () {
      expect(new Decimal(2.5).greaterThanOrEqualTo(3)).to.equal(false);
      expect(new Decimal(2).greaterThanOrEqualTo(2.5)).to.equal(false);
      expect(new Decimal(2.5).greaterThanOrEqualTo(2)).to.equal(true);
      expect(new Decimal(2).greaterThanOrEqualTo(2)).to.equal(true);
      expect(new Decimal(2).greaterThanOrEqualTo(1)).to.equal(true);
      expect(new Decimal(2).greaterThanOrEqualTo(1.5)).to.equal(true);
      expect(new Decimal(2).greaterThanOrEqualTo(0)).to.equal(true);
      expect(new Decimal(2).greaterThanOrEqualTo(-1)).to.equal(true);
      expect(new Decimal(-2).greaterThanOrEqualTo(-3)).to.equal(true);
    });

    it('can find the lesser of two numbers', function () {
      expect(new Decimal(2.5).lessThan(3)).to.equal(true);
      expect(new Decimal(2).lessThan(2.5)).to.equal(true);
      expect(new Decimal(2.5).lessThan(2)).to.equal(false);
      expect(new Decimal(2).lessThan(2)).to.equal(false);
      expect(new Decimal(2).lessThan(1)).to.equal(false);
      expect(new Decimal(2).lessThan(1.5)).to.equal(false);
      expect(new Decimal(2).lessThan(0)).to.equal(false);
      expect(new Decimal(2).lessThan(-1)).to.equal(false);
      expect(new Decimal(-2).lessThan(-3)).to.equal(false);
    });

    it('can find the greater or equal of two numbers', function () {
      expect(new Decimal(2.5).lessThanOrEqualTo(3)).to.equal(true);
      expect(new Decimal(2).lessThanOrEqualTo(2.5)).to.equal(true);
      expect(new Decimal(2.5).lessThanOrEqualTo(2)).to.equal(false);
      expect(new Decimal(2).lessThanOrEqualTo(2)).to.equal(true);
      expect(new Decimal(2).lessThanOrEqualTo(1)).to.equal(false);
      expect(new Decimal(2).lessThanOrEqualTo(1.5)).to.equal(false);
      expect(new Decimal(2).lessThanOrEqualTo(0)).to.equal(false);
      expect(new Decimal(2).lessThanOrEqualTo(-1)).to.equal(false);
      expect(new Decimal(-2).lessThanOrEqualTo(-3)).to.equal(false);
    });

    it('can find if two numbers are equal', function () {
      expect(new Decimal(1).equals(1)).to.equal(true);
      expect(new Decimal(1.5).equals(1)).to.equal(false);
      expect(new Decimal(-1).equals(1)).to.equal(false);
      expect(new Decimal(-1.5).equals(1)).to.equal(false);
      expect(new Decimal(-1).equals(-1)).to.equal(true);
      expect(new Decimal(-1.5).equals(-1)).to.equal(false);
    });
  });

  // test data found from https://ellenaua.medium.com/floating-point-errors-in-javascript-node-js-21aadd897bf8
  describe('Floating Point Edge Cases', () => {
    it('multiplies better than Number', function () {
      testSet(multiply, [
        [[8.38, 0.3], 2.514],
        [[9.16, 8.22], 75.2952],
        [[3.37, 3.33], 11.2221],
        [[9.68, 8.22], 79.5696],
        [[89.86, 9.46], 850.0756],
        [[73.85, 7.81], 576.7685],
        [[21.39, 1.27], 27.1653],
        [[80.04, 8.66], 693.1464],
        [[71.64, 4.64], 332.4096]
      ]);
    });
    it('divides better than Number', function () {
      testSet(divide, [
        [[99.27, 3], 33.09],
        [[57.3, 3], 19.1],
        [[73.15, 7], 10.45],
        [[58.2, 3], 19.4],
        [[69.96, 3], 23.32],
        [[32.76, 9], 3.64],
        [[28.62, 3], 9.54]
      ]);
    });

    it('adds better than Number', function () {
      testSet(add, [
        [[5.33, 5.2], 10.53],
        [[7.84, 4.28], 12.12],
        [[11.92, 207.85], 219.77],
        [[99.52, 6.27], 105.79],
        [[939.92, 153.49], 1093.41],
        [[843.32, 131.47], 974.79],
        [[36067.29, 3920.23], 39987.52],
        [[85.13, 5.96, 8.44], 99.53],
        [[8.44, 5.96, 85.13], 99.53],
        [[94.4, 7.12, 4.67], 106.19],
        [[4.67, 7.12, 94.4], 106.19],
        [[43.57, 5.33, 3.05], 51.95],
        [[3.05, 5.33, 43.57], 51.95]
      ]);
    });

    it('subtracts better than Number', function () {
      testSet(subtract, [
        [[8.13, 5.75], 2.38],
        [[8.93, 4.4], 4.53],
        [[6.09, 3.43], 2.66],
        [[4.95, 2.82], 2.13],
        [[986.83, 93.44], 893.39],
        [[119.93, 43.35], 76.58],
        [[490.01, 10.91], 479.10],
        [[122.72, 6.43], 116.29]
      ]);
    });
  });

  describe('Conversions', () => {
    it('converts to Numbers', function () {
      const value = new Decimal(1.23).toNumber();
      expect(value).to.be.a('Number');
      expect(value).to.equal(1.23);
    });

    it('converts to Strings', function () {
      const value = new Decimal(1.23).toString();
      expect(value).to.be.a('String');
      expect(value).to.equal('1.2300');
    });

    it('converts to JSON', function () {
      const value = JSON.parse(JSON.stringify(new Decimal(1.23)));
      expect(value).to.be.an('object');
      expect(value).to.deep.equal({
        $decimal: '1.2300'
      });
    });

    it('parses strings appropriately', function () {
      validate(new Decimal('0'), 0);
      validate(new Decimal('2'), 2);
      validate(new Decimal('2.0'), 2);
      validate(new Decimal('-2.0'), -2);
      validate(new Decimal('1.23456'), 1.2346);
      validate(new Decimal('-1.23456'), -1.2346);
    });
  });

  describe('Compatibility', () => {
    it('works with Math', function () {
      expect(Math.min(new Decimal(10), new Decimal(1))).to.equal(1);
      expect(Math.cos(new Decimal(0))).to.equal(1);
      expect(Math.abs(new Decimal(-1))).to.equal(1);
    });
  });

  describe('Large Numbers', () => {
    it('loads the number correctly', function () {
      validate(new Decimal(4294967297.444444), 4294967297.4444);
    });
  });
});
