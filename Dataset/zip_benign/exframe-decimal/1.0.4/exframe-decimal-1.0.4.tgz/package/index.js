/* eslint-disable import/prefer-default-export */

'use strict';

import Decimal from './lib/decimal.js';

export { Decimal };
