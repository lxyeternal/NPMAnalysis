import exzeoBaseConfig from 'eslint-config-exzeo/base';
import exzeoMochaConfig from 'eslint-config-exzeo/mocha';

export default [
  exzeoBaseConfig,
  { rules: { 'no-bitwise': 'off' } },
  exzeoMochaConfig
];
