import * as React from 'react';
type ColorItem = {
    stop: number;
    color: string;
};
type ComponentProps = {
    id: string;
    width?: number;
    height?: number;
    audioId?: string;
    audioEle?: HTMLElement;
    capColor?: string;
    capHeight?: number;
    meterWidth?: number;
    meterColor?: string | ColorItem[];
    meterCount?: number;
    gap?: number;
    silent?: boolean;
};
export default function ReactAudioSpectrum(props: ComponentProps): React.JSX.Element;
export {};
