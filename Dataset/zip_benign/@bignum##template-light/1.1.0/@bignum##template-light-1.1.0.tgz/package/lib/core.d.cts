/** Get a Frac from the given value */
declare function valueOf(value: string | number | bigint | boolean): Frac;
/** Internal Fraction type */
type Frac = {
    /** numerator */
    n: bigint;
    /** denominator */
    d: bigint;
};
/**
 * Add two Frac
 */
declare function add(a: Frac, b: Frac): Frac;
/**
 * Subtract two Frac
 */
declare function sub(a: Frac, b: Frac): Frac;
/**
 * Multiply two Frac
 */
declare function mul(a: Frac, b: Frac): Frac;
/**
 * Divide two Frac
 */
declare function div(a: Frac, b: Frac): Frac;
/**
 * Modulo two Frac
 */
declare function mod(a: Frac, b: Frac): Frac;

/**
 * Execute a compiled template with operands.
 */
declare function execCompiled<OPERAND extends string | number | bigint>(operands: OPERAND[], compiled: (args: Frac[]) => Frac): number;

export { add, div, execCompiled, mod, mul, sub, valueOf };
