/** Formula Literal Engine */
declare function f<OPERAND extends string | number | bigint>(template: TemplateStringsArray, ...substitutions: OPERAND[]): number;

export { f };
