## About

Make a list of elements to scroll infinitely

## Installation

1. Install the package
    ```bash
    npm install react-infinite-slides
    ```

1. Import in a project
    ```typescrypt
    import React from 'react';
    import 'react-infinite-slides/styles/infinite-slides.css';
    import { InfiniteSlides } from 'react-infinite-slides';

    const App = () => {
      return (
        <>
          <InfiniteSlides containerHeight='200px' itemWidth={0.5} speed={5000}>
            <div style={{ backgroundColor: 'red' }}>1</div>
            <div style={{ backgroundColor: 'green' }}>2</div>
            <div style={{ backgroundColor: 'blue' }}>3</div>
          </InfiniteSlides>
        </>
      )
    }
    ```

## Development

1. Run an example app

    ```bash
    npm run dev
    ```