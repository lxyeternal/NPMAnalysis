import React from 'react';
import '../src/infinite-slides/index.css';
import { InfiniteSlides } from '../src';

const App = () => {
  return (
    <div>
      <h1>React Infinite Slides</h1>
      <InfiniteSlides containerHeight='200px' itemWidth={0.5}>
        <div style={{ backgroundColor: 'red' }}>1</div>
        <div style={{ backgroundColor: 'green' }}>2</div>
        <div style={{ backgroundColor: 'blue' }}>3</div>
      </InfiniteSlides>
    </div>
  )
}

export default App;