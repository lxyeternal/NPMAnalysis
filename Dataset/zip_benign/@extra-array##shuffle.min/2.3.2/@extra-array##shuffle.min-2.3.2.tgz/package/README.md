Rearranges values in arbitrary order.<br>
> This is part of package [extra-array].

[extra-array]: https://www.npmjs.com/package/extra-array<br>
> This is browserified, minified version of [@extra-array/shuffle].<br>
> It is exported as global variable **array_shuffle**.<br>
> CDN: [unpkg], [jsDelivr].

[@extra-array/shuffle]: https://www.npmjs.com/package/@extra-array/shuffle
[unpkg]: https://unpkg.com/@extra-array/shuffle.min
[jsDelivr]: https://cdn.jsdelivr.net/npm/@extra-array/shuffle.min

```javascript
array.shuffle(x, [n]);
// x: an array
// n: random seed 0->1
```

```javascript
const array = require('extra-array');

var x = [1, 2, 3, 4, 5];
array.shuffle(x);
// [ 1, 5, 4, 3, 2 ]

array.shuffle(x, 0.3);
// [ 4, 5, 2, 3, 1 ]

array.shuffle(x, 0.3);
// [ 4, 5, 2, 3, 1 ]
```

### references

- [shuffle-seed: @webcaetano](https://www.npmjs.com/package/shuffle-seed)
- [shuffle-array: @pazguille](https://www.npmjs.com/package/shuffle-array)
- [shuffle(): PHP](https://www.php.net/manual/en/function.shuffle.php)
- [Seeding the random number generator in Javascript](https://stackoverflow.com/a/47593316/1413259)
