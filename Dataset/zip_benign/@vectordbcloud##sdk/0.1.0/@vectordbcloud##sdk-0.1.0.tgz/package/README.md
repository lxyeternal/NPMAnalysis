# VectorDBCloud JavaScript SDK

The official JavaScript SDK for VectorDBCloud, providing easy access to the VectorDBCloud platform for vector database management, embeddings, and context management with ECP (Ephemeral Context Protocol).

## Installation

```bash
npm install vectordbcloud
```

## Quick Start

```javascript
import { VectorDBCloud } from 'vectordbcloud';

// Initialize the client with your API key
const client = new VectorDBCloud({ apiKey: 'your_api_key' });

// Create a context
const context = await client.createContext({
  metadata: { userId: 'user123', sessionId: 'session456' }
});

// Store vectors with context
const vectors = [
  [0.1, 0.2, 0.3],
  [0.4, 0.5, 0.6],
];
const metadata = [
  { text: 'Document 1', source: 'source1' },
  { text: 'Document 2', source: 'source2' },
];
await client.storeVectors({
  vectors,
  metadata,
  contextId: context.id
});

// Query vectors
const results = await client.queryVectors({
  queryVector: [0.2, 0.3, 0.4],
  contextId: context.id,
  topK: 5
});

// Print results
results.forEach(result => {
  console.log(`Score: ${result.score}, Metadata:`, result.metadata);
});

// Use ECP for context management
await client.withContext({ metadata: { task: 'recommendation' } }, async () => {
  // All operations within this block will use this context
  await client.storeVectors({ vectors, metadata });
  const results = await client.queryVectors({ queryVector: [0.2, 0.3, 0.4], topK: 5 });
});
```

## Features

- Simple, intuitive API for vector database operations
- Built-in support for ECP (Ephemeral Context Protocol)
- Automatic handling of authentication and API key management
- Comprehensive error handling and retries
- Support for all VectorDBCloud features:
  - Vector storage and retrieval
  - Context management
  - Subscription and plan management
  - Cloud deployment

## Documentation

For complete documentation, visit [https://docs.vectordbcloud.com/javascript-sdk](https://docs.vectordbcloud.com/javascript-sdk).

## Examples

### Managing Subscriptions

```javascript
// Get current subscription
const subscription = await client.getSubscription();
console.log(`Current plan: ${subscription.planId}`);
console.log(`Status: ${subscription.status}`);

// Check usage limits
const limits = await client.checkLimits();
if (limits.approachingLimit) {
  console.log(`Warning: Approaching limit for ${limits.approachingLimitType}`);
}
```

### Cloud Deployment

```javascript
// Deploy to AWS
const result = await client.deployToAws({
  accountId: '123456789012',
  region: 'us-east-1',
  resources: [
    {
      type: 's3_bucket',
      name: 'my-vector-storage'
    },
    {
      type: 'dynamodb_table',
      name: 'my-metadata-table'
    }
  ]
});
console.log(`Deployment ID: ${result.deploymentId}`);
```

## License

This SDK is distributed under the MIT license. See the LICENSE file for more information.
