import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { v4 as uuidv4 } from 'uuid';

/**
 * SingleAPI error class
 */
export class SingleAPIError extends Error {
  status?: number;
  response?: any;

  constructor(message: string, status?: number, response?: any) {
    super(message);
    this.name = 'SingleAPIError';
    this.status = status;
    this.response = response;
  }
}

/**
 * Authentication error class
 */
export class AuthenticationError extends SingleAPIError {
  constructor(message: string, status?: number, response?: any) {
    super(message, status, response);
    this.name = 'AuthenticationError';
  }
}

/**
 * Rate limit error class
 */
export class RateLimitError extends SingleAPIError {
  constructor(message: string, status?: number, response?: any) {
    super(message, status, response);
    this.name = 'RateLimitError';
  }
}

/**
 * Resource not found error class
 */
export class ResourceNotFoundError extends SingleAPIError {
  constructor(message: string, status?: number, response?: any) {
    super(message, status, response);
    this.name = 'ResourceNotFoundError';
  }
}

/**
 * Validation error class
 */
export class ValidationError extends SingleAPIError {
  constructor(message: string, status?: number, response?: any) {
    super(message, status, response);
    this.name = 'ValidationError';
  }
}

/**
 * Context interface
 */
export interface Context {
  id: string;
  metadata?: Record<string, any>;
}

/**
 * Query result interface
 */
export interface QueryResult {
  id: string;
  score: number;
  vector?: number[];
  metadata: Record<string, any>;
}

/**
 * Subscription interface
 */
export interface Subscription {
  subscriptionId: string;
  planId: string;
  status: string;
  trialEnd?: string;
  currentPeriodStart?: string;
  currentPeriodEnd?: string;
  usage?: Record<string, any>;
}

/**
 * Limits interface
 */
export interface Limits {
  limits: Record<string, any>;
  approachingLimit: boolean;
  approachingLimitType?: string;
  limitsExceeded: boolean;
  exceededLimitTypes?: string[];
}

/**
 * Deployment result interface
 */
export interface DeploymentResult {
  deploymentId: string;
  success: boolean;
  resources: Record<string, any>[];
  error?: string;
}

/**
 * SingleAPI client options
 */
export interface SingleAPIOptions {
  apiKey?: string;
  baseUrl?: string;
  timeout?: number;
  maxRetries?: number;
  retryDelay?: number;
}

/**
 * SingleAPI client class
 */
export class SingleAPI {
  private apiKey: string;
  private baseUrl: string;
  private timeout: number;
  private maxRetries: number;
  private retryDelay: number;
  private client: AxiosInstance;
  private currentContextId?: string;

  /**
   * Create a new SingleAPI client
   * @param options Client options
   */
  constructor(options: SingleAPIOptions = {}) {
    this.apiKey = options.apiKey || process.env.SINGLEAPI_API_KEY || '';
    if (!this.apiKey) {
      throw new AuthenticationError('API key is required');
    }

    this.baseUrl = options.baseUrl || 'https://api.singleapi.com/v1';
    this.timeout = options.timeout || 30000;
    this.maxRetries = options.maxRetries || 3;
    this.retryDelay = options.retryDelay || 1000;

    this.client = axios.create({
      baseURL: this.baseUrl,
      timeout: this.timeout,
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
        'User-Agent': `singleapi-js/0.1.0`
      }
    });
  }

  /**
   * Make a request to the SingleAPI API
   * @param method HTTP method
   * @param path API path
   * @param params Query parameters
   * @param data Request body
   * @param contextId Context ID
   * @returns Response data
   */
  private async request<T>(
    method: string,
    path: string,
    params?: Record<string, any>,
    data?: Record<string, any>,
    contextId?: string
  ): Promise<T> {
    const config: AxiosRequestConfig = {
      method,
      url: path,
      params,
      data
    };

    // Add context ID if provided or if there's a current context
    if (contextId || this.currentContextId) {
      config.headers = {
        // Fix: Add type assertion to ensure string type
        'X-Context-ID': (contextId || this.currentContextId) as string
      };
    }

    let retries = 0;
    while (retries <= this.maxRetries) {
      try {
        const response = await this.client.request<T>(config);
        return response.data;
      } catch (error: any) {
        if (axios.isAxiosError(error) && error.response) {
          const { status, data } = error.response;

          if (status === 429 && retries < this.maxRetries) {
            // Rate limit exceeded, retry after delay
            const retryAfter = parseInt(error.response.headers['retry-after'] || `${this.retryDelay}`, 10);
            console.warn(`Rate limit exceeded, retrying after ${retryAfter} ms`);
            await new Promise(resolve => setTimeout(resolve, retryAfter));
            retries++;
            continue;
          }

          // Handle error based on status code
          this.handleErrorResponse(error.response);
        }

        if (retries === this.maxRetries) {
          throw new SingleAPIError(`Request failed: ${error.message}`);
        }

        console.warn(`Request failed, retrying (${retries + 1}/${this.maxRetries}): ${error.message}`);
        await new Promise(resolve => setTimeout(resolve, this.retryDelay * Math.pow(2, retries)));
        retries++;
      }
    }

    // This should never be reached due to the throw in the catch block
    throw new SingleAPIError('Request failed after maximum retries');
  }

  /**
   * Handle error responses from the API
   * @param response Error response
   */
  private handleErrorResponse(response: AxiosResponse): never {
    const { status, data } = response;
    const message = data?.error?.message || 'Unknown error';

    if (status === 401) {
      throw new AuthenticationError(message, status, data);
    } else if (status === 404) {
      throw new ResourceNotFoundError(message, status, data);
    } else if (status === 422) {
      throw new ValidationError(message, status, data);
    } else if (status === 429) {
      throw new RateLimitError(message, status, data);
    } else {
      throw new SingleAPIError(message, status, data);
    }
  }

  /**
   * Execute a function with a context
   * @param metadata Context metadata
   * @param fn Function to execute
   * @returns Function result
   */
  async withContext<T>(
    metadata: Record<string, any>,
    fn: () => Promise<T>
  ): Promise<T> {
    const context = await this.createContext({ metadata });
    const previousContextId = this.currentContextId;
    this.currentContextId = context.id;

    try {
      return await fn();
    } finally {
      this.currentContextId = previousContextId;
    }
  }

  /**
   * Create a new context
   * @param options Context options
   * @returns Created context
   */
  async createContext(options: { metadata?: Record<string, any> } = {}): Promise<Context> {
    const data = { metadata: options.metadata || {} };
    const response = await this.request<{ context_id: string }>(
      'POST',
      '/contexts',
      undefined,
      data
    );

    return {
      id: response.context_id,
      metadata: options.metadata
    };
  }

  /**
   * Get a context by ID
   * @param contextId Context ID
   * @returns Context
   */
  async getContext(contextId: string): Promise<Context> {
    const response = await this.request<{ context_id: string; metadata: Record<string, any> }>(
      'GET',
      `/contexts/${contextId}`
    );

    return {
      id: response.context_id,
      metadata: response.metadata
    };
  }

  /**
   * Update a context's metadata
   * @param contextId Context ID
   * @param metadata New metadata
   * @returns Updated context
   */
  async updateContext(
    contextId: string,
    metadata: Record<string, any>
  ): Promise<Context> {
    const data = { metadata };
    const response = await this.request<{ context_id: string; metadata: Record<string, any> }>(
      'PUT',
      `/contexts/${contextId}`,
      undefined,
      data
    );

    return {
      id: response.context_id,
      metadata: response.metadata
    };
  }

  /**
   * Delete a context
   * @param contextId Context ID
   * @returns Success status
   */
  async deleteContext(contextId: string): Promise<boolean> {
    await this.request<void>('DELETE', `/contexts/${contextId}`);
    return true;
  }

  /**
   * Store vectors in the vector database
   * @param options Store vectors options
   * @returns Vector IDs
   */
  async storeVectors(options: {
    vectors: number[][];
    metadata?: Record<string, any>[];
    ids?: string[];
    contextId?: string;
  }): Promise<string[]> {
    const { vectors, metadata, ids, contextId } = options;

    if (metadata && vectors.length !== metadata.length) {
      throw new ValidationError('Number of vectors and metadata must match');
    }

    if (ids && vectors.length !== ids.length) {
      throw new ValidationError('Number of vectors and IDs must match');
    }

    const data = {
      vectors,
      metadata: metadata || Array(vectors.length).fill({}),
      ids: ids || Array(vectors.length).fill(0).map(() => uuidv4())
    };

    const response = await this.request<{ ids: string[] }>(
      'POST',
      '/vectors',
      undefined,
      data,
      contextId
    );

    return response.ids;
  }

  /**
   * Query vectors from the vector database
   * @param options Query vectors options
   * @returns Query results
   */
  async queryVectors(options: {
    queryVector: number[];
    topK?: number;
    filterMetadata?: Record<string, any>;
    includeVectors?: boolean;
    contextId?: string;
  }): Promise<QueryResult[]> {
    const { queryVector, topK = 10, filterMetadata, includeVectors = false, contextId } = options;

    const data = {
      query_vector: queryVector,
      top_k: topK,
      filter: filterMetadata,
      include_vectors: includeVectors
    };

    const response = await this.request<{ results: any[] }>(
      'POST',
      '/vectors/query',
      undefined,
      data,
      contextId
    );

    return response.results.map(result => ({
      id: result.id,
      score: result.score,
      vector: result.vector,
      metadata: result.metadata
    }));
  }

  /**
   * Get current subscription
   * @returns Subscription
   */
  async getSubscription(): Promise<Subscription> {
    const response = await this.request<any>('GET', '/subscription');

    return {
      subscriptionId: response.subscription_id,
      planId: response.plan_id,
      status: response.status,
      trialEnd: response.trial_end,
      currentPeriodStart: response.current_period_start,
      currentPeriodEnd: response.current_period_end,
      usage: response.usage
    };
  }

  /**
   * Check usage limits
   * @returns Limits
   */
  async checkLimits(): Promise<Limits> {
    const response = await this.request<any>('GET', '/limits');

    return {
      limits: response.limits,
      approachingLimit: response.approaching_limit,
      approachingLimitType: response.approaching_limit_type,
      limitsExceeded: response.limits_exceeded,
      exceededLimitTypes: response.exceeded_limit_types
    };
  }

  /**
   * Deploy to AWS
   * @param options AWS deployment options
   * @returns Deployment result
   */
  async deployToAws(options: {
    accountId: string;
    region: string;
    resources: Record<string, any>[];
  }): Promise<DeploymentResult> {
    const { accountId, region, resources } = options;

    const data = {
      account_id: accountId,
      region,
      resources
    };

    const response = await this.request<any>('POST', '/deploy/aws', undefined, data);

    return {
      deploymentId: response.deployment_id,
      success: response.success,
      resources: response.resources,
      error: response.error
    };
  }

  /**
   * Deploy to GCP
   * @param options GCP deployment options
   * @returns Deployment result
   */
  async deployToGcp(options: {
    projectId: string;
    region: string;
    resources: Record<string, any>[];
  }): Promise<DeploymentResult> {
    const { projectId, region, resources } = options;

    const data = {
      project_id: projectId,
      region,
      resources
    };

    const response = await this.request<any>('POST', '/deploy/gcp', undefined, data);

    return {
      deploymentId: response.deployment_id,
      success: response.success,
      resources: response.resources,
      error: response.error
    };
  }

  /**
   * Deploy to Azure
   * @param options Azure deployment options
   * @returns Deployment result
   */
  async deployToAzure(options: {
    subscriptionId: string;
    resourceGroup: string;
    region: string;
    resources: Record<string, any>[];
  }): Promise<DeploymentResult> {
    const { subscriptionId, resourceGroup, region, resources } = options;

    const data = {
      subscription_id: subscriptionId,
      resource_group: resourceGroup,
      region,
      resources
    };

    const response = await this.request<any>('POST', '/deploy/azure', undefined, data);

    return {
      deploymentId: response.deployment_id,
      success: response.success,
      resources: response.resources,
      error: response.error
    };
  }
}
