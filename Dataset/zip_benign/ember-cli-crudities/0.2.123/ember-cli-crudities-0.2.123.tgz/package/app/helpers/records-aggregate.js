export { default, recordsAggregate } from 'ember-cli-crudities/helpers/records-aggregate';
