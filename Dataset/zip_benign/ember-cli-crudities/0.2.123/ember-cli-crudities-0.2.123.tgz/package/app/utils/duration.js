export { default } from 'ember-cli-crudities/utils/duration';
