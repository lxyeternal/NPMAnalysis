export { default } from 'ember-cli-crudities/utils/records-aggregates';
