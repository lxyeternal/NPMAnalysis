export { default } from 'ember-cli-crudities/services/filter-memory';
