export { default } from 'ember-cli-crudities/transforms/duration';
