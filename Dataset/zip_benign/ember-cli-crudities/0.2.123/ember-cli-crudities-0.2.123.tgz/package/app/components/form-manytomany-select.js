export { default } from 'ember-cli-crudities/components/form-manytomany-select';
