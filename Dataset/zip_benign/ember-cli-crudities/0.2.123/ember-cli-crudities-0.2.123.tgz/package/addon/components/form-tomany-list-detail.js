import Ember from 'ember';
import Component from './form-tomany-slide';
import layout from '../templates/components/form-tomany-list-detail';

export default Component.extend({
  layout,

  record: null,

  _list_class: 'col-xs-12',
  _detail_class: 'col-xs-12',

  listClass: Ember.computed.or('field.extra.listClass', '_list_class'),
  detailClass: Ember.computed.or('field.extra.detailClass', '_detail_class'),

  actions: {
    select(record) {
      this.set('record', record);
    },
  },
});
