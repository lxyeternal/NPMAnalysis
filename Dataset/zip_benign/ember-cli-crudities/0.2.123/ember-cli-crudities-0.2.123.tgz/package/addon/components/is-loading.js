import Ember from 'ember';
import layout from '../templates/components/is-loading';

export default Ember.Component.extend({
  layout
});
