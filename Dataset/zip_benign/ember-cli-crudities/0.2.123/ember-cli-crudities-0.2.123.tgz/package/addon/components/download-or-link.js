import Ember from 'ember';
import layout from '../templates/components/download-or-link';

export default Ember.Component.extend({
  layout
});
