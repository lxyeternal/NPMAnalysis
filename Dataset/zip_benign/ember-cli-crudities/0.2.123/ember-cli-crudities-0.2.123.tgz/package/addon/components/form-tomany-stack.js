import Ember from 'ember';
import ToManyBase from './tomany-base';
import layout from '../templates/components/form-tomany-stack';
import withCustomActionsMixin from '../mixins/with-custom-actions';

export default ToManyBase.extend(withCustomActionsMixin, {
  layout,
  classNames: ['tomany-stack'],

  sortBy: ['id'],

  actionColumns: Ember.computed('field.extra.customActions', 'field.extra.customActions.length', 'field.extra.allowOpen', function() {
    const rv = parseInt(this.get('custom_actions.length') ? this.get('custom_actions.length') : 0) +
      parseInt(this.get('field.extra.allowOpen') ? 1 : 0);
    return rv > 0 ? 1 : 0;
  }),

  column_count: Ember.computed('field.fields.length', 'actionColumns', 'field.extra.sortableBy', 'field.extra.preventDelete', function() {
    const readonly = this.get('readonly');
    const preventDelete = this.get('field.extra.preventDelete');
    return parseInt((readonly || preventDelete) !== true ? 2 : 1) +
      parseInt(this.get('field.extra.sortableBy') ? 1 : 0) +
      parseInt(this.get('actionColumns') ? this.get('actionColumns') : 0);
  }),

  padderColspan: Ember.computed('field.fields.length', 'column_count', 'actionColumns', function() {
    return this.get('column_count') - parseInt(this.get('field.fields.length'))
      - this.get('actionColumns') - parseInt(this.get('field.extra.preventDelete')?1:0);
  }),

  sorted: Ember.computed.sort('related', 'sortBy'),

  didReceiveAttrs() {
    this._super();
    const sortBy = this.get('field.extra.sortableBy');
    if (sortBy !== undefined) {
      this.set('sortBy', [sortBy]);
    }
  },

  actions: {
    reorderItems(items) {
      items.forEach((item, index) => {
        item.set(this.get('field.extra.sortableBy'), index+1);
        this.saveMe();
      });
    }
  },
});
