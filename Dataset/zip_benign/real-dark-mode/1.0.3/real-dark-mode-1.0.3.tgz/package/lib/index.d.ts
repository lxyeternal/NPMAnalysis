interface RealDarkModeOptions {
    /**
     * The color of the spotlight
     * @default "#000000"
     * */
    color?: string;
    /**
     * The size of the spotlight in pixels
     * @default 100
     * */
    size?: number;
    /**
     * The opacity of the spotlight
     * @default 0.95
     * */
    opacity?: number;
}
declare const realDarkMode: (options?: RealDarkModeOptions) => void;
export default realDarkMode;
export { realDarkMode, RealDarkModeOptions };
//# sourceMappingURL=index.d.ts.map