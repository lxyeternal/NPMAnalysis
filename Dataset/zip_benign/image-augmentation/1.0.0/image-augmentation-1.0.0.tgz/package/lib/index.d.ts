/// <reference types="node" />
export interface DefaultInterface {
    probability?: number;
    image: Buffer | string;
    output?: string;
}
export interface CropInterface extends DefaultInterface {
    width: number;
    height: number;
}
export interface RotationInterface extends DefaultInterface {
    rotationDegree: number;
}
export interface PaddingInterface extends DefaultInterface {
    padding: "left" | "right" | "top" | "bottom";
    amount: number;
    background: {
        r: number;
        g: number;
        b: number;
    };
}
export interface MultipleInterface {
    execute: () => Promise<void>;
    outputNumber: number;
    output?: string;
}
export declare class ImageAugmentation {
    private __ctr;
    private __amount;
    private multiple;
    private __utils;
    private templateFunc;
    /**
     * @param {number} [probability = 0.5] The probability of the function occuring.
     * @param {string | Buffer} image The path or the Buffer of the image. If the given path is a directory, all images in that directory will be augmenated.
     * @param {string} [output = "./output"] The output folder in the current directory.
     * @description Select a probability and the image or directory. The grey images will be saved to the output directory.
     */
    makeGrey: ({ probability, image, output }: DefaultInterface) => Promise<void>;
    /**
     * @param {number} [probability = 0.5] The probability of the function occuring
     * @param {number} rotationDegree The degree of rotation.
     * @param {string | Buffer} image The path or the Buffer of the image. If the given path is a directory, all images in that directory will be augmenated.
     * @param {string} [output = "./output"] The output folder in the current directory.
     * @description Select a probability and the image or directory. The rotated images will be saved to the output directory.
     * @example Rotation degree 90 will rotate the image right.
     */
    rotate: ({ rotationDegree, probability, image, output }: RotationInterface) => Promise<void>;
    /**
     * @param {number} [probability = 0.5] The probability of the function occuring.
     * @param {number} rotationDegree The degree of rotation.
     * @param {string | Buffer} image The path or the Buffer of the image. If the given path is a directory, all images in that directory will be augmenated.
     * @param {string} [output = "./output"] The output folder in the current directory.
     * @description Select a probability and the image or directory. The rotated images will be saved to the output directory.
     * @example Rotation degree 90 will rotate the image right.
     */
    rotateRight: ({ rotationDegree, probability, image, output }: RotationInterface) => Promise<void>;
    /**
     * @param {number} [probability = 0.5] The probability of the function occuring.
     * @param {number} rotationDegree The degree of rotation.
     * @param {string | Buffer} image The path or the Buffer of the image. If the given path is a directory, all images in that directory will be augmenated.
     * @param {string} [output = "./output"] The output folder in the current directory.
     * @description Select a probability and the image or directory. The rotated images will be saved to the output directory.
     * @example Rotation degree 90 will rotate the image left.
     */
    rotateLeft: ({ rotationDegree, probability, image, output }: RotationInterface) => Promise<void>;
    /**
     * @param {number} [probability = 0.5] The probability of the function occuring.
     * @param {"left" | "top" | "right" | "bottom"} padding The direction of where the padding should be applied.
     * @param {number} amount The amount of padding.
     * @param {{r: number, g: number, b: number}} background The color of the padded pixels.
     * @param {string | Buffer} image The path or the Buffer of the image. If the given path is a directory, all images in that directory will be augmenated.
     * @param {string} [output = "./output"] The output folder in the current directory.
     * @description Select a probability and the image or directory. The modified images will be saved to the output directory.
     * @example padding="top", amount=10, background={r: 255, g: 255, b: 255} will add 10 white pixels to the top of the image.
     */
    addPadding: ({ padding, amount, background, probability, image, output }: PaddingInterface) => Promise<void>;
    /**
     * @param {number} [probability = 0.5] The probability of the function occuring.
     * @param {string | Buffer} image The path or the Buffer of the image. If the given path is a directory, all images in that directory will be augmenated.
     * @param {string} [output = "./output"] The output folder in the current directory.
     * @description Select a probability and the image or directory. The flipped images will be saved to the output directory.
     */
    flipX: ({ probability, image, output }: DefaultInterface) => Promise<void>;
    /**
     * @param {number} [probability = 0.5] The probability of the function occuring.
     * @param {string | Buffer} image The path or the Buffer of the image. If the given path is a directory, all images in that directory will be augmenated.
     * @param {string} [output = "./output"] The output folder in the current directory.
     * @description Select a probability and the image or directory. The flipped images will be saved to the output directory.
     */
    flipY: ({ probability, image, output }: DefaultInterface) => Promise<void>;
    /**
     * @param {number} width The new width of the image.
     * @param {number} height The new height of the image.
     * @param {number} [probability = 0.5] The probability of the function occuring.
     * @param {string | Buffer} image The path or the Buffer of the image. If the given path is a directory, all images in that directory will be augmenated.
     * @param {string} [output = "./output"] The output folder in the current directory.
     * @description Select a probability and the image or directory. The resized images will be saved to the output directory.
     */
    resize: ({ width, height, probability, image, output }: CropInterface) => Promise<void>;
    /**
     * @param {number} [probability = 0.5] The probability of the function occuring.
     * @param {string | Buffer} image The path or the Buffer of the image. If the given path is a directory, all images in that directory will be augmenated.
     * @param {string} [output = "./output"] The output folder in the current directory.
     * @description Select a probability and the image or directory. The sharpened images will be saved to the output directory.
     */
    sharpen: ({ probability, image, output }: DefaultInterface) => Promise<void>;
    /**
     * @param {number} [probability = 0.5] The probability of the function occuring.
     * @param {string | Buffer} image The path or the Buffer of the image. If the given path is a directory, all images in that directory will be augmenated.
     * @param {string} [output = "./output"] The output folder in the current directory.
     * @description Select a probability and the image or directory. The blurred images will be saved to the output directory.
     */
    blur: ({ probability, image, output }: DefaultInterface) => Promise<void>;
    /**
     * @param {number} [probability = 0.5] The probability of the function occuring.
     * @param {string | Buffer} image The path or the Buffer of the image. If the given path is a directory, all images in that directory will be augmenated.
     * @param {string} [output = "./output"] The output folder in the current directory.
     * @description Select a probability and the image or directory. The negated images will be saved to the output directory.
     */
    negate: ({ probability, image, output }: DefaultInterface) => Promise<void>;
    /**
     * @callback execute
     * @async
     */
    /**
     * @param {execute} execute The async function in which the member functions of the class should be called.
     * @param {string} outputNumber The number of images desired.
     * @description Select the member functions and the amount of images desired. The functions will be executed until there is the output is equal to the amount of desired images.
     */
    executeMultiple: ({ execute, outputNumber }: MultipleInterface) => Promise<void>;
}
