/**
 * @param {number} n The probability.
 * @returns {boolean} The true or false value of the probability.
 */
export declare const probabilityFunc: (n: number) => boolean;
/**
 * @param {string} dir The directory.
 * @description Check if a directory exists. If it does not, create the directory.
 */
export declare const createDir: (dir: string) => void;
/**
 * @param {string} dir The directory.
 * @returns {boolean} Returns true if the path is a directory.
 * @description Check if the path is a directory.
 */
export declare const checkIfDir: (dir: string) => Promise<boolean>;
/**
 * @param {string} dir The directory.
 * @returns All the file paths of the image files in the given directory.
 */
export declare const allImagesInDir: (dir: string) => Promise<string[]>;
