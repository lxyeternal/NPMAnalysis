const { exec } = require('child_process')
const execPromise = require('util').promisify(exec)

/* MAC PLAY COMMAND */
const macPlayCommand = (path, volume) => `afplay \"${path}\" -v ${volume}`
const macStopCommand = `pkill afplay`; // afplay를 중지하는 명령어

/* WINDOW PLAY COMMANDS */
const addPresentationCore = `Add-Type -AssemblyName presentationCore;`
const createMediaPlayer = `$player = New-Object system.windows.media.mediaplayer;`
const loadAudioFile = path => `$player.open('${path}');`
const playAudio = `$player.Play();`
const stopAudio = `Start-Sleep 1; Start-Sleep -s $player.NaturalDuration.TimeSpan.TotalSeconds;Exit;`
const stopAudioWindows = `$player.Stop();`; // MediaPlayer에서 중지 명령

const windowPlayCommand = (path, volume) =>
  `powershell -c ${addPresentationCore} ${createMediaPlayer} ${loadAudioFile(
    path,
  )} $player.Volume = ${volume}; ${playAudio} ${stopAudio}`

module.exports = {
  play: async (path, volume=0.5) => {
    /**
     * Window: mediaplayer's volume is from 0 to 1, default is 0.5
     * Mac: afplay's volume is from 0 to 255, default is 1. However, volume > 2 usually result in distortion.
     * Therefore, it is better to limit the volume on Mac, and set a common scale of 0 to 1 for simplicity
     */
    const volumeAdjustedByOS = process.platform === 'darwin' ? Math.min(2, volume * 2) : volume

    const playCommand =
      process.platform === 'darwin' ? macPlayCommand(path, volumeAdjustedByOS) : windowPlayCommand(path, volumeAdjustedByOS)
    try {
      await execPromise(playCommand, {windowsHide: true})
    } catch (err) {
      throw err
    }
  },
  stop: async () => {
    try {
      if (process.platform === 'darwin') {
        // Mac의 경우 afplay 프로세스 중지
        await execPromise(macStopCommand);
      } else {
        // Windows의 경우 MediaPlayer 중지 명령 실행
        const stopCommand = `powershell -c ${stopAudioWindows}`;
        await execPromise(stopCommand);
      }
    } catch (err) {
      throw err;
    }
  }
}
