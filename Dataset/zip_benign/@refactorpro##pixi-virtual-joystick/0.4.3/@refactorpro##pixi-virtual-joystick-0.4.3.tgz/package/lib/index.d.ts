import * as PIXI from "pixi.js";
export interface JoystickChangeEvent {
    angle: number;
    direction: Direction;
    power: number;
}
export declare enum Direction {
    LEFT = "left",
    TOP = "top",
    BOTTOM = "bottom",
    RIGHT = "right",
    TOP_LEFT = "top_left",
    TOP_RIGHT = "top_right",
    BOTTOM_LEFT = "bottom_left",
    BOTTOM_RIGHT = "bottom_right"
}
export interface JoystickSettings {
    outer?: PIXI.Sprite | PIXI.Graphics | PIXI.Container;
    inner?: PIXI.Sprite | PIXI.Graphics | PIXI.Container;
    outerScale?: {
        x: number;
        y: number;
    };
    innerScale?: {
        x: number;
        y: number;
    };
    onChange?: (data: JoystickChangeEvent) => void;
    onStart?: () => void;
    onEnd?: () => void;
}
export declare class Joystick extends PIXI.Container {
    settings: JoystickSettings;
    outerRadius: number;
    innerRadius: number;
    outer: PIXI.Sprite | PIXI.Graphics | PIXI.Container;
    inner: PIXI.Sprite | PIXI.Graphics | PIXI.Container;
    innerAlphaStandby: number;
    constructor(opts: JoystickSettings);
    initialize(): void;
    protected bindEvents(): void;
    protected getPower(centerPoint: PIXI.Point): number;
    protected getDirection(center: PIXI.Point): Direction;
}
