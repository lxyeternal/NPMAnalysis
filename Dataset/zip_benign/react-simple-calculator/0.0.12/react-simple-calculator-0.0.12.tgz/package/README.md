# REACT-SIMPLE-CALCULATOR
A simple calculator, was made as a test task for one company.
Some details:
1) Real numbers can be written as 0.5 and .5
2) Operation % is the remainder of division (mod)
3) Calculation accuracy - 14 characters (You can change the precision in the src/components/Calculator.js)  
  
The calculator looks like this:  
![DEMO IMAGE #1](https://github.com/d9rs/react-simple-calculator/raw/master/public/images/demo1.PNG)
![DEMO IMAGE #2](https://github.com/d9rs/react-simple-calculator/raw/master/public/images/demo2.PNG)
  
You can watch a demo here - [calculator demo](https://d9rs.github.io/calculator/).
# Installation
1) npm install react-simple-calculator
2) npm start
3) go to localhost:8505 
# MIT Licence
