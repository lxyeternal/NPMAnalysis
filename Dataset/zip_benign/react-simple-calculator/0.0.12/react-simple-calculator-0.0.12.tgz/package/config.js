module.exports = {
    env: 'production',
    enableLinter: false,
    port: 8505
};