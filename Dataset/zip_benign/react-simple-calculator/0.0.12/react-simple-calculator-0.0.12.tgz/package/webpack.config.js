const path = require("path");
const config = require("./config");
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const TerserPlugin = require('terser-webpack-plugin');
const {CleanWebpackPlugin} = require('clean-webpack-plugin');

const extractSASS = new ExtractTextPlugin({
    filename: '[name].css',
});

const extractCSS = new ExtractTextPlugin({
    filename: '[name]-original.css',
});

let optimization = {};

let eslint = config.enableLinter ? {
    enforce: "pre",
    test: /\.js$/,
    exclude: /node_modules/,
    loader: "eslint-loader"
} : {};

if (config.env == 'production') {
    optimization = {
        minimizer: [new TerserPlugin()]
    };
}

module.exports = {
    mode: config.env,
    optimization,
    entry: {
        app: './src/App.js'
    },
    output: {
        filename: '[name].js',
        path: path.resolve(__dirname, './public/build'),
    },
    module: {
	  rules: [
		eslint,
	    	{ 
		    test: /\.(js|jsx)$/, 
		    exclude: /node_modules/, 
		    use: {
			loader: "babel-loader",
			options: {
			    presets: ["@babel/preset-env", "@babel/preset-react"],
			    plugins: ["@babel/plugin-proposal-class-properties"]
			}
		    } 
		},
		{
		    test: /\.scss$/,
		    use: extractSASS.extract([ 'css-loader', 'sass-loader' ])
		},
		{
		    test: /\.css$/,
		    use: extractCSS.extract([ 'css-loader' ])
		}
	  ]
    },
    plugins: [
        new CleanWebpackPlugin(),
        extractCSS,
        extractSASS
    ]
};
