const express = require('express');
const config = require('./config');
const path = require('path');
const app = express();

app.set('env', config.env || 'development');
app.set('views', './views');

app.use(express.static(path.resolve(__dirname, 'public')));

app.get('*', (req, res) => res.sendFile(path.resolve(__dirname, 'views/index.html')));

app.listen(config.port, () => console.log(`Server has been started on port ${config.port}!`));