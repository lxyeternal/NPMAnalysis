import React from 'react';
import ReactDOM from 'react-dom';
import ErrorBoundary from './ErrorBoundary';

import './css/styles.scss';

import Calculator from './components/Calculator';

ReactDOM.render(
    <ErrorBoundary>
        <Calculator />
    </ErrorBoundary>, 
    document.getElementById('wrapper')
);