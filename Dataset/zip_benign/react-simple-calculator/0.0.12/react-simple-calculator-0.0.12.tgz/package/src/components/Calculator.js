import React, { Component } from 'react';
import { create, all } from 'mathjs';
import buttons from './CalculatorButtons';

const { evaluate } = create(all, { number: 'BigNumber', precision: 14 });

export default class Calculator extends Component {

    state = {
        expression: '',
        error: null
    };
    
    // Реакт-реф, связанный с input-ом, хранящим мат. выражение
    input = React.createRef();
    // Последняя позиция курсора в input-е при вводе символов с помощью клавиш или клавиатуры
    lastCursorPosition = 0;

    /*
     * Метод обработчик нажатия мышкой кнопки в калькуляторе.
     * @param {String} value - это свойство value нажатой кнопки (buttons), либо свойство label, если отсутствует value.
     */
    onButtonClick = (value) => {
        switch (value) {
            case 'CE':
                this.setState({ expression: '', error: null });
                break;
            case '=':
                this.calculate();
                break;
            default:
                if (this.state.error || this.state.expression.includes('Infinity')) {
                    this.setState({ expression: value, error: null });
                } else {
                    const cursorPosition = this.input.current.selectionStart;
                    this.lastCursorPosition = cursorPosition + 1;
                    this.setState({ expression: this.state.expression.slice(0, cursorPosition) + value + this.state.expression.slice(cursorPosition) });
                }
        }
    }

    /*
     * Обработчик события ввода в input
     * При наличии ошибки или исключительного значения Infinity/-Infinity в выражении поле ввода отчищается.
     * При вводе нового символа в input вызывается метод inputNewSymbol.
     * При удалении символа из input-а происходит обычное удаление символа из выражения.
     * @param {SyntheticEvent} e - react обёртка над нативным экземпляром события
     */
    onInputChange = (e) => {
        if (this.state.error) {
            if (e.target.value.length > this.state.error.length) {
                this.inputNewSymbol(e);
            } else {
                this.lastCursorPosition = 0;
                this.setState({ expression: '', error: null });
            }
        } else if (e.target.value.length > this.state.expression.length) {
            this.inputNewSymbol(e);
        } else if (this.state.expression.includes('Infinity')) {
            this.setState({ expression: '' });
        } else {
            this.lastCursorPosition = e.target.selectionStart;
            this.setState({ expression: e.target.value });
        }
    }

    // Метод, проверяющий валидность введённого символа с клавиатуры. Если символ корректен, то он добавляется в выражение.
    inputNewSymbol = (e) => {
        const symbol = e.target.value[e.target.selectionStart - 1];
        const isValidSymbol = buttons.some(btn => !btn.isAction && (btn.value ? symbol === btn.value : symbol === btn.label));
        if (isValidSymbol) {
            this.lastCursorPosition = e.target.selectionStart;
            if (this.state.error || this.state.expression.includes('Infinity')) {
                this.setState({ expression: symbol, error: null });
            } else {
                this.setState({ expression: e.target.value });
            }
        }
    }

    // Метод, выполняющий вычисления введённого в input выражения.
    calculate = () => {
        try {
            const result = evaluate(this.state.expression);
            const value = result === undefined ? '' : result.toString();
            this.setState({ expression: value });
            this.lastCursorPosition = value.length;
        } catch (e) {
            console.error(e.message);
            this.setState({ expression: '', error: 'Ошибка вычисления!' });
        }
    }

    // Обработчик события нажатия клавиши, при нажатии кнопки "enter" вызывает метод вычисления выражения.
    onKeyDown = (e) => {
        if (e.key === 'Enter') {
            this.calculate();
        }
    }
    
    componentDidUpdate() {
        // При обновлении компонента устанавливаем позицию курсора в input-e на последнее записанное в момент ввода
        this.input.current.setSelectionRange(this.lastCursorPosition, this.lastCursorPosition);
        this.input.current.focus();
    }

    render() {
        return (
            <div className="calculator" onKeyDown={this.onKeyDown}>
                <div className="input-wrapper">
                    <input type="text" ref={this.input} value={this.state.error || this.state.expression} onChange={this.onInputChange}/>
                </div>
                <div className="calculator-buttons">
                    {buttons.map(btn => {
                        return (
                            <button 
                                key={btn.label} 
                                onClick={this.onButtonClick.bind(this, btn.value || btn.label)}
                                className={btn.classes || null}
                            >{btn.label}</button>
                        );
                    })}
                </div>
            </div>
        );
    }
}