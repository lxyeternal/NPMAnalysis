import React from 'react';

export default class ErrorBoundary extends React.Component {
    
    state = { hasError: false };

    static getDerivedStateFromError(error) {
        return { hasError: true };
    }

    componentDidCatch(error, info) {
        console.error(error, info);
    }

    render() {
        if (this.state.hasError) {
            return (
                <div className="global-error">
                    <h1>Возникла непредвиденная ошибка, мы в скором времени всё исправим.</h1>
                </div>
            );
        }
        return this.props.children;
    }
}