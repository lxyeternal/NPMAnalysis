import { BTEngine, BTContext } from '@bignum/shared';
export { BTBinaryOperation, BTBinaryOperator, BTCompiled, BTContext, BTEngine, BTFunction, BTUnaryOperation, BTUnaryOperator } from '@bignum/shared';

declare function setupEngine(): BTEngine<string | number | bigint, number | string>;
declare function setupEngine<OPERAND = unknown, RESULT = unknown, NORMALIZED = OPERAND | RESULT | string>(context: BTContext<OPERAND, RESULT, NORMALIZED>): BTEngine<OPERAND, NORMALIZED>;
declare const f: BTEngine<string | number | bigint, string | number>;

export { f, setupEngine };
