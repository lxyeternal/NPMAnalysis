import { BigNum } from '@bignum/core';
export { BigNum } from '@bignum/core';
import { BTBinaryOperation, BTFunction } from '@bignum/shared';

/**
 * Normalize result value
 */
declare function toResult(value: BigNum | string | number | bigint): string | number;
/** Normalize value */
declare function normalize(value: BigNum | string | number | bigint): bigint | BigNum;
declare const add: BTBinaryOperation<string | number | bigint, bigint | BigNum>;
declare const multiply: BTBinaryOperation<string | number | bigint, bigint | BigNum>;
declare const subtract: BTBinaryOperation<string | number | bigint, bigint | BigNum>;
declare const divide: BTBinaryOperation<string | number | bigint, bigint | BigNum>;
declare const modulo: BTBinaryOperation<string | number | bigint, bigint | BigNum>;
declare const pow: BTBinaryOperation<string | number | bigint, bigint | BigNum>;
declare const equal: BTBinaryOperation<string | number | bigint, bigint | BigNum>;
declare const notEqual: BTBinaryOperation<string | number | bigint, bigint | BigNum>;
declare const lte: BTBinaryOperation<string | number | bigint, bigint | BigNum>;
declare const lt: BTBinaryOperation<string | number | bigint, bigint | BigNum>;
declare const gte: BTBinaryOperation<string | number | bigint, bigint | BigNum>;
declare const gt: BTBinaryOperation<string | number | bigint, bigint | BigNum>;
declare const negate: BTFunction<string | number | bigint, bigint | BigNum>;
declare const sqrt: BTFunction<string | number | bigint, bigint | BigNum>;
declare const abs: BTFunction<string | number | bigint, bigint | BigNum>;
declare const trunc: BTFunction<string | number | bigint, bigint | BigNum>;
declare const round: BTFunction<string | number | bigint, bigint | BigNum>;
declare const floor: BTFunction<string | number | bigint, bigint | BigNum>;
declare const ceil: BTFunction<string | number | bigint, bigint | BigNum>;

export { abs, add, ceil, divide, equal, floor, gt, gte, lt, lte, modulo, multiply, negate, normalize, notEqual, pow, round, sqrt, subtract, toResult, trunc };
