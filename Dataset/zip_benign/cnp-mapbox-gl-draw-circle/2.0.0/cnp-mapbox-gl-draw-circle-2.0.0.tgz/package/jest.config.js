const transformIgnoreModules = [
    '@ngrx',
    '@mapbox/mapbox-gl-draw',
    'mapbox-gl-draw-geodesic',
    'mapbox-gl-draw-circle'
  ];
  const transformIgnoreModulesPattern = `/node_modules/(?!${transformIgnoreModules.join(
    '|'
  )})`;
module.exports = {
    transformIgnorePatterns: [transformIgnoreModulesPattern],
}