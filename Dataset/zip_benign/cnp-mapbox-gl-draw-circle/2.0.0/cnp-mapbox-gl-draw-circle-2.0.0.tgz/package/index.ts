export const CircleMode: object = require('./lib/modes/CircleMode');
export const DragCircleMode: object = require('./lib/modes/DragCircleMode');
export const DirectMode: object = require('./lib/modes/DirectModeOverride');
export const SimpleSelectMode: object = require('./lib/modes/SimpleSelectModeOverride');
