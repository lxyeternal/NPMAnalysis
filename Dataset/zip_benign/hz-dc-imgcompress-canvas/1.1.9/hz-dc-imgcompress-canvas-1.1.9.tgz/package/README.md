     //使用img标签使用 id 属性 大小自己控制
    <img id="imgControl" src="" alt="">
    //图片大小 默认设置为 容器的大小 background-size：100% 100%
    <div id="imgControl" ></div>
    //上传文件 默认是id 属性，也可自由配置
    <input type="file" id="fileControl">
    <script type="module">
        // 模块导入
        import cim from "./compressImageModule.js"
        // 配置项 这是默认配置，  可自行配置 
       var  option={
           //获取文件
            fileControl:"fileControl",
            //展示图片 容器 
            imgControl:"imgControl",
            //上后台url地址
             uploadUrl:"uploadUrl",
             //开启压缩的临界像素
            maxSize:1024*1024,
            //图片压缩比率 默认 0.4，可根据实际情况设置
            imgCompressRatio:.4,
            //默认压缩 超过100万 压缩在一百万下
            compressSize:10000000,
            //图片 大于240万 执行 分片压缩 ，可自用配置
            clipCompressSize:2400000
        }
        //创建实例 传递自定义参数
        new cim(option) 
    </script>