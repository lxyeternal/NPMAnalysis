class compressImage {

    constructor(option){
        this.option={
            fileControl:"fileControl",
            imgControl:"imgControl",
            uploadUrl:"/uploadUrl",
            maxSize:1024*1024,
            imgCompressRatio:.4,
            compressSize:10000000,
            clipCompressSize:2400000
        }

        this.option = Object.assign({},this.option,option)
        this.fileControl= document.getElementById(this.option.fileControl)
        this.imgControl = document.getElementById(this.option.imgControl)
        this.maxSize= this.option.maxSize
        this.compressSize=this.option.compressSize
        this.clipCompressSize=this.option.clipCompressSize
        this.ratio=this.option.imgCompressRatio
        this.uploadUrl= this.option.uploadUrl
        this.imgContent=null
        this.canvas=null
        this.ctx=null
        this.tcavas=null
        this.tctx=null
        this.init()
    }
    init(){ 
        this.canvas=document.createElement("canvas")
        this.ctx=this.canvas.getContext("2d")
        this.tcanvas=document.createElement("canvas")
        this.tctx=this.tcanvas.getContext("2d")  
        this.getChange= this.getChange.bind(this)
        this.fileControl.addEventListener("change",this.getChange)
    }
     getChange(){
        var files = Array.prototype.slice.call(this.fileControl.files)

        var file = files[0]
        if(files.length ===0){
            alert("请选择图片")
            return
        }else if(files.length>1){
            alert("只能选择一张图片")
            return 
        }

        //图片是否压缩 处理
        var _this = this
        var reader = new FileReader()
        reader.onload=function(){
            var result = this.result
         
            var img = new Image()
            img.src=result
            //图片是否压缩，不压缩直接上传，否则 读取完成压缩图片
            
            if(result.length <= _this.maxSize){
               
                img =null
                _this.upload(result,file.type)
                return 
            }else if(img.complete){//图片加载完成 处理图片 否则 继续加载
                callback()
            }else{
                img.onload=callback
            }
            function callback(){
                var data = _this.compress(img)
                _this.upload(data,file.type)
            }

        }
        reader.readAsDataURL(file)
    }
    compress(objImg){
        var initSize =objImg.src.length
        var width = objImg.width
        var height = objImg.height
        //如果图片大于100万像素 压缩在100万的标准
        var ratio 
        if((ratio = width*height/this.compressSize)>1){
            ratio = Math.sqrt(ratio)
            width /= ratio
            height /= ratio
        }else{
            ratio =1
        }

        this.canvas.width = width
        this.canvas.height = height
        this.ctx.fillStye = "#fff"
        this.ctx.fillRect(0,0,this.canvas.width,this.canvas.height)
        // 如果图片大于240万 则使用瓦片绘制
        var count
        if((count = width*height/this.clipCompressSize)>1){
            //计算分片数  并压缩后 拼接
            count = ~~(Math.sqrt(count)+1)
            var nw = ~~(width/count)
            var nh= ~~(height/count)
        
            this.tcanvas.width = nw
            this.tcanvas.height = nh
            for(var i = 0;i<count;i++){
                 for(var j =0;j<count;j++){
                    this.tctx.drawImage(objImg,i*ratio*nw,j*ratio*nh,nw*ratio,nh*ratio,0,0,nw,nh)
                    this.ctx.drawImage(this.tcanvas,i*nw,j*nh)
                 }
            }
        }else{
            this.ctx.drawImage(objImg,0,0,width,height)
        }
        //进行最小压缩
        var nData = this.canvas.toDataURL("image/jpeg",this.ratio)
        this.tcanvas.width=this.tcanvas.height=this.canvas.width=this.canvas.height=0
        // this.imgControl.style.backgroundSize=
        console.log("压缩前"+objImg.src.length)
        console.log("压缩后:" +nData.length)
        console.log("压缩率："+ ~~(100*(initSize-nData.length)/initSize)+"%")
        return nData
    }
    upload(basestr,type){
        
        
        this.imgControl.src = basestr
        this.imgControl.style.backgroundImage=`url(${basestr})`
        this.imgControl.style.backgroundSize="100% 100%"
            
  
        //去除 mime type ,atob 函数已经被base-64编码过的数据
        var text = window.atob(basestr.split(",")[1])
        var buffer = new Uint8Array(text.length)
        var loop = null
        for(var i =0 ,len=text.length;i<len;i++){
            buffer[i] = text.charCodeAt(i)
        }
        var blob = this._getBlob([buffer],type)
        var _this =this
        var  formData = this._getFormdata()
        var xhr =new XMLHttpRequest()
        formData.append('imagefile',blob)

        //上传指定图片地址
        xhr.open("post",_this.uploadUrl)
        xhr.onreadystatechange = function(){
            if(xhr.readyState===4&&xhr.status===200){
                var jsonData = JSON.parse(xhr.responseText)
                var imageData = jsonData[0] || {}
                var text = imageData.path? "上传成功":"上传失败"
                clearInterval(loop)
                
            }
        }
        xhr.send(formData)
        
    }
    //对blob 对象 增加兼容
    _getBlob(buffer,format){
       try {
        return new Blob(buffer,{type:format})
       }catch(e){
           var bb = new (window.BlobBuilder||window.WebKitBlobBuilder||window .MSBlobBuilder)
           buffer.forEach(function(buf){
               bb.append(buf)
           })
           return bb.getBlob()

       }
    }
    //获取getFormData
    _getFormdata(){
        var isNeedShim =   navigator.userAgent.indexOf('Android') &&
        ~navigator.vendor.indexOf('Google') &&
        ~navigator.userAgent.indexOf('Chrome') &&
        navigator.userAgent.match(/AppleWebKit\/(\d+)/).pop() <= 534
      return isNeedShim ? new this._FormDataShim() : new FormData()
    }
    // formData 给android  补丁
    _FormDataShim(){
        var o = this,
        parts = [],
        boundary = new Array(21).join('-') + (+new Data() * (1e6 * Math.random())).toString(36),
        oldSend = XMLHttpRequest.prototype.send
        // 构造出的子实例  添加文件属性
        this.append = function (name, value, fileName) {
            parts.push('--' + boundary + '\r\nContent-Disposition: form-data; name="' + name + '"')
            if (value instanceof Blob) {
              parts.push('; filename="' + (fileName || 'blob') + '"\r\nContent-Type: ' + value.type + '\r\n\r\n')
              parts.push(value)
            } else {
              parts.push('\r\n\r\n' + value)
            }
            parts.push('\r\n')
          }
          //重写xhr send 方法
          var _this = this
        XMLHttpRequest.prototype.send = function (val) {
            var fr,
              data,
              oXHR = this;
            if (val === o) {
              // Append the final boundary string
              parts.push('--' + boundary + '--\r\n');
              // Create the blob
              data = _this.getBlob(parts);
              // Set up and read the blob into an array to be sent
              fr = new FileReader();
              fr.onload = function() {
                oldSend.call(oXHR, fr.result);
              };
              fr.onerror = function(err) {
                throw err;
              };
              fr.readAsArrayBuffer(data);
              // Set the multipart content type and boudary
              this.setRequestHeader('Content-Type', 'multipart/form-data; boundary=' + boundary);
              XMLHttpRequest.prototype.send = oldSend;
            }
            else {
              oldSend.call(this, val);
            }
        }
    }
}

export default compressImage