# @free-transform/core

## 1.1.0

### Minor Changes

- d780cc5: pump
