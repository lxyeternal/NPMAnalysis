/**
 * Type of options of {@link Randomizer}.
 */
export declare type RandomizerOptions = Partial<{
    /**
     * Randomization seed.
     * @default Date.now()
     */
    seed: number;
    /**
     * Initial position in the random sequence.
     * (Starts from zero.)
     * @default 0
     */
    cursor: number;
    /**
     * Randomization coefficient.
     * (next = (a * prev + b) % m)
     * @default 1 << 20
     */
    m: number;
    /**
     * Randomization coefficient.
     * (next = (a * prev + b) % m)
     * @default 9
     */
    a: number;
    /**
     * Randomization coefficient.
     * (next = (a * prev + b) % m)
     * @default 7
     */
    b: number;
}>;
/** dts2md break */
/**
 * Class of seedable randomizers.
 */
export declare class Randomizer {
    /** dts2md break */
    /**
     * Constructor of {@link Randomizer}.
     */
    constructor(options?: RandomizerOptions);
    /** dts2md break */
    /**
     * Randomization seed.
     */
    seed: number;
    /** dts2md break */
    /**
     * Current position in the random sequence.
     */
    cursor: number;
    /** dts2md break */
    /**
     * Randomization coefficient.
     * (next = (a * prev + b) % m)
     */
    m: number;
    /** dts2md break */
    /**
     * Randomization coefficient.
     * (next = (a * prev + b) % m)
     */
    a: number;
    /** dts2md break */
    /**
     * Randomization coefficient.
     * (next = (a * prev + b) % m)
     */
    b: number;
    private _current;
    private _next;
    /** dts2md break */
    /**
     * Get a random float in range [min, max).
     * By default, `min === 0` and `max === 1`.
     */
    float(): number;
    /** dts2md break */
    /**
     * Get a random float in range [min, max).
     * By default, `min === 0` and `max === 1`.
     */
    float(min: number, max: number): number;
    /** dts2md break */
    /**
     * Get a random integer in range [min, max).
     * By default, `min === 0` and `max === 100`.
     */
    integer(): number;
    /** dts2md break */
    /**
     * Get a random integer in range [min, max).
     * By default, `min === 0` and `max === 100`.
     */
    integer(min: number, max: number): number;
    /** dts2md break */
    /**
     * Get a random boolean,
     * where the probability of `true` is 0.5 by default.
     * (Returns `this.float() < trueProbability`.)
     */
    boolean(trueProbability?: number): boolean;
    /** dts2md break */
    /**
     * Get a random string.
     * (Returns `this.float().toString(radix).slice(2)`.)
     */
    string(radix?: number): string;
    /** dts2md break */
    /**
     * Get a random element in the given array.
     */
    choice<T>(choices: ArrayLike<T>): T;
    /** dts2md break */
    /**
     * Reset the randomizer.
     */
    reset(seed?: number, cursor?: number): this;
}
