console.log "Hello, world!"
