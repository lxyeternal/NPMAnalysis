# Fuzzy_time
Will return the current time in a humanly readable format. 23:45 => 'a quarter to twelve'

1. Require it
```javascript
var ft = require('fuzzy_time');
```
2. Use it 
```javascript
var time = ft.getFuzzy();
```
Or... 
```javascript
var time = ft.getFuzzy('en');
```
As of version 0.3, an argument for language can now be provided. It isn't required and defaults to english. There is only english as of right now, more languages will be added in the future. 