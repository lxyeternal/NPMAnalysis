var en_minutes = ['five past', 'ten past', 'a quarter past', 'twenty past',
  'twenty-five past', 'half past', 'twenty-five to', 'twenty to', 'a quarter to',
  'ten to', 'five to', ''];

var en_hours = ['twelve', 'one', 'two', 'three', 'four', 'five', 'six', 
  'seven', 'eight', 'nine', 'ten', 'eleven'];

var se_minutes = ['fem över', 'tio över', 'kvart över', 'tjugo över', 'fem i halv',
  'halv', 'fem över halv', 'tjugo i', 'kvart i', 'tio i', 'fem i', ''];

var se_hours = ['tolv', 'ett', 'två', 'tre', 'fyra', 'fem', 'sex', 'sju', 'åtta', 
  'nio', 'tio', 'elva', 'tolv'];

var getFuzzyMin = (min, lang='en') => {
  var mns;
  switch(lang) {
  case 'en':
    mns = en_minutes;
    break;
  case 'se':
    mns = se_minutes;
    break;
  default:
    mns = en_minutes;
    break;
  }
  if(min > 2 && min < 7) return mns[0];
  else if(min > 6 && min < 12) return mns[1];
  else if(min > 11 && min < 17) return mns[2];
  else if(min > 16 && min < 22) return mns[3];
  else if(min > 21 && min < 27) return mns[4];
  else if(min > 26 && min < 32) return mns[5];
  else if(min > 31 && min < 37) return mns[6];
  else if(min > 36 && min < 42) return mns[7];
  else if(min > 41 && min < 47) return mns[8];
  else if(min > 46 && min < 52) return mns[9];
  else if(min > 51 && min < 57) return mns[10];
  else return mns[11];
};

var getFuzzyHour = (hour, lang='en') => {
  var hrs;
  switch(lang) {
  case 'en':
    hrs = en_hours;
    break;
  case 'se':
    hrs = se_hours;
    break;
  default:
    hrs = en_hours;
    break;
  }
  switch(hour) {
  case 0:
  case 12:
    return hrs[0];
  case 1:
  case 13:
    return hrs[1];
  case 2:
  case 14:
    return hrs[2];
  case 3:
  case 15:
    return hrs[3];
  case 4:
  case 16:
    return hrs[4];
  case 5:
  case 17:
    return hrs[5];
  case 6:
  case 18:
    return hrs[6];
  case 7:
  case 19:
    return hrs[7];
  case 8:
  case 20:
    return hrs[8];
  case 9:
  case 21:
    return hrs[9];
  case 10:
  case 22:
    return hrs[10];
  case 11:
  case 23:
    return hrs[11];
  }
};

var getFuzzy = (lang = 'en') => {
  var now = new Date();
  var h = now.getHours();
  var m = now.getMinutes();
  var fuzzytime = '';
  if(m > 2 && m < 57)
    fuzzytime = getFuzzyMin(m, lang) + ' ' + getFuzzyHour(h, lang);
  else
    fuzzytime = getFuzzyHour(h);
  return fuzzytime;
};

module.exports = {
  getFuzzy
};