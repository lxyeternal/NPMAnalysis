const io = require('socket.io-client');

module.exports = (...params) => (

    params.reduce((sum, param)=>(sum += param), 0)

)

