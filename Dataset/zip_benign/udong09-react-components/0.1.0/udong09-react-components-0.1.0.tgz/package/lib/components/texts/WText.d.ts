import { ReactElement } from "react";
import { WTextProps } from "..";
declare const WText: ({ text, size, color, theme, }: WTextProps) => ReactElement;
export default WText;
