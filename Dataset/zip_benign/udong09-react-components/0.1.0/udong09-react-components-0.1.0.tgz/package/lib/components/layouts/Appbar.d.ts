/// <reference types="react" />
import { AppbarProps } from "../types";
declare const Appbar: ({ title, action, enableBack, leading }: AppbarProps) => JSX.Element;
export default Appbar;
