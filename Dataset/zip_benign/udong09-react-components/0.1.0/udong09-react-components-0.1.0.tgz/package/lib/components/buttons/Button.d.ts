/// <reference types="react" />
import { ButtonProps } from "../types";
declare const WButton: ({ size, text, color, fontColor, radius, leftIcon, onClick, variant, }: ButtonProps) => JSX.Element;
export default WButton;
