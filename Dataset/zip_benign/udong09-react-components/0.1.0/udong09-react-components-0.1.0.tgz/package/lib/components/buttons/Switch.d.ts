/// <reference types="react" />
import { SwitchProps } from "../types";
declare const SwitchButton: ({ size, color, checked, onClick, }: SwitchProps) => JSX.Element;
export default SwitchButton;
