/// <reference types="react" />
import { ScaffoldProps, ScaffoldType } from "../types";
declare const Scaffold: import("react").ForwardRefExoticComponent<ScaffoldProps & import("react").RefAttributes<ScaffoldType>>;
export default Scaffold;
