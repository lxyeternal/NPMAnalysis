import { DialogProps, DialogType } from "../types";
import React from "react";
declare const Dialog: React.ForwardRefExoticComponent<DialogProps & React.RefAttributes<DialogType>>;
export default Dialog;
