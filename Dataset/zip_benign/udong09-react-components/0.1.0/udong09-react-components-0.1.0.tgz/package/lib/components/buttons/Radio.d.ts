/// <reference types="react" />
import { RadioProps } from "..";
declare function WRadio<T>({ onClick, value, size, checked, label, color, }: RadioProps<T>): JSX.Element;
export default WRadio;
