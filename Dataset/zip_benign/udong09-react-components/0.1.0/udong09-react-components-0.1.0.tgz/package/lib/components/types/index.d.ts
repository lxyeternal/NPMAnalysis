import { ReactElement } from "react";
import { WIcon } from "../../utils/IconUtil";
export declare enum WColors {
    white = "#FFFFFF",
    white08 = "#F8F7F5",
    black20 = "#110501",
    black = "#2c0e02",
    black07 = "#2c0e02b3",
    black06 = "#2c0e0299",
    black05 = "#2c0e0280",
    black04 = "#2c0e0266",
    black03 = "#2c0e024d",
    black01 = "#2c0e021a",
    gossamer20 = "#30997D",
    gossamer = "#36B190",
    gossamer08 = "#36b190cc",
    gossamer06 = "#36b19099",
    gossamer04 = "#36b19066",
    gossamer02 = "#36b19033",
    sunglow20 = "#E39702",
    sunglow = "#FFB801",
    sunglow08 = "#ffb801cc",
    sunglow06 = "#ffb80199",
    sunglow04 = "#ffb80166",
    sunglow02 = "#ffb80133",
    sunglow01 = "#ffb8011a",
    sunglow005 = "#ffb8010d",
    amaranth = "#D9D2F4",
    amaranth20 = "#E93C3C",
    amaranth08 = "#FF6262",
    pointBlue20 = "#4D5B9D",
    pointBlue = "#6374C5",
    pointBlue08 = "#6374C5cc",
    pointBlue06 = "#6374C599",
    pointBlue04 = "#6374C566",
    pointBlue02 = "#6374C533",
    pointBlue01 = "#6374C51a",
    pointBlue005 = "#6374C50d"
}
export declare type ThemeColors = "green" | (string & {}) | "blue" | "cyan" | "gray" | "orange" | "pink" | "purple" | "red" | "teal" | "yellow" | "whiteAlpha" | "blackAlpha" | "linkedin" | "facebook" | "messenger" | "whatsapp" | "twitter" | "telegram" | undefined;
export declare type ThemeBorderRadius = "none" | "sm" | "md" | "lg" | "full";
export interface WProviderProps {
    children: ReactElement | ReactElement[];
}
export interface ButtonProps {
    size: "sm" | "md" | "lg";
    radius?: ThemeBorderRadius;
    text?: string;
    fontColor?: WColors;
    color?: ThemeColors;
    onClick?: () => void;
    leftIcon?: ReactElement;
    variant?: "ghost" | "outline" | "solid";
}
export interface IconProps {
    size: "sm" | "md" | "lg";
    name: WIcon;
}
export interface CheckboxProps {
    size: "sm" | "md" | "lg";
    label?: string;
    color?: ThemeColors;
    onClick: (value: boolean) => void;
    value: any;
    checked: boolean;
}
export interface RadioProps<T> {
    size: "sm" | "md" | "lg";
    color?: ThemeColors;
    label?: string;
    onClick: (checked: boolean, value: T) => void;
    value: T;
    checked: boolean;
}
export interface WTextProps {
    size?: "xs" | "sm" | "md" | "lg" | "xl" | "xxl";
    text: string;
    color?: ThemeColors;
    theme?: "text1" | "text2" | "text3" | "text4" | "text5" | "text6" | "title1" | "title2" | "title3" | "title4" | "title5" | "title6";
}
export interface ScaffoldType {
}
export interface ScaffoldProps {
    appbar: ReactElement;
    body: ReactElement;
}
export interface AppbarProps {
    title: string;
    enableBack: boolean;
    leading?: ReactElement | ReactElement[];
    action?: ReactElement | ReactElement[];
}
export interface DialogProps {
    text: string;
    onConfirm?: () => void;
    children: ReactElement;
    leftButtonColor?: ThemeColors;
    leftButtonText?: string;
    rightButtonColor?: ThemeColors;
    rightButtonText?: string;
}
export interface DialogType {
    openDialog: () => void;
}
export interface SwitchProps {
    color?: ThemeColors;
    size?: "sm" | "md" | "lg";
    checked: boolean;
    onClick: () => void;
}
export interface ExpansionTileProps<T> {
    title: string;
    children?: ReactElement;
    items: T[];
    label: (item: T) => string;
    checkedIndex?: number;
    onClickItem?: (item: T, index: number) => void;
}
export interface ToastProps {
    text: string;
}
export interface TabViewProps {
    tabs: string[];
    panels: ReactElement[];
    tabColors?: ThemeColors[];
    isFitted?: boolean;
    currentIndex?: number;
    onChangeTab: (tab: number) => void;
}
export interface BottomSheetProps {
    children: ReactElement | ReactElement[];
    isOpen: boolean;
    onClose: () => void;
}
export interface AvatarProps {
    src?: string;
    size: 'sm' | 'md' | 'lg';
}
