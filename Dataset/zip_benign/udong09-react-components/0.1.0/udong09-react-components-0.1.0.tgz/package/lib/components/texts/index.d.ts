import Text from "./WText";
export { Text };
