/// <reference types="react" />
import { TabViewProps } from "../types";
declare const TabView: ({ tabs, panels, tabColors, isFitted, currentIndex, onChangeTab, }: TabViewProps) => JSX.Element;
export default TabView;
