/// <reference types="react" />
import { AvatarProps } from "../types";
declare const WAvatar: ({ src, size }: AvatarProps) => JSX.Element;
export default WAvatar;
