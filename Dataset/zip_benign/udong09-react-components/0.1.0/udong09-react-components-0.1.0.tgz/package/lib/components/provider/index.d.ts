/// <reference types="react" />
import { WProviderProps } from "../types";
declare const theme: import("@chakra-ui/utils").Dict<any>;
declare const WProvider: ({ children }: WProviderProps) => JSX.Element;
export { WProvider, theme };
