/// <reference types="react" />
import { CheckboxProps } from "../types";
declare const WCheckbox: ({ size, checked, color, value, onClick, label, }: CheckboxProps) => JSX.Element;
export default WCheckbox;
