declare function useWToast(): {
    sendToast: (text: string) => void;
};
export default useWToast;
