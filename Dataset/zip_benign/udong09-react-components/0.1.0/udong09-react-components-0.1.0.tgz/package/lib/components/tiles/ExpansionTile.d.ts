/// <reference types="react" />
import { ExpansionTileProps } from "../types";
declare function ExpansionTile<T>({ title, children, items, label, checkedIndex, onClickItem, }: ExpansionTileProps<T>): JSX.Element;
export default ExpansionTile;
