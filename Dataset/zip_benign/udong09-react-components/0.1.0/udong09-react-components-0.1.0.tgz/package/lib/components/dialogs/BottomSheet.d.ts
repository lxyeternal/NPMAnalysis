/// <reference types="react" />
import { BottomSheetProps } from "../types";
declare const BottomSheet: ({ children, isOpen, onClose }: BottomSheetProps) => JSX.Element;
export default BottomSheet;
