/// <reference types="react" />
import { IconProps } from "../types";
declare const Icon: ({ size, name }: IconProps) => JSX.Element;
export default Icon;
