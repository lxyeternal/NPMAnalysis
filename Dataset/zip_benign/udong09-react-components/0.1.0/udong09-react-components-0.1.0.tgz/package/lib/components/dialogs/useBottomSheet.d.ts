declare function useBottomSheet(): {
    isOpen: boolean;
    onOpen: () => void;
    onClose: () => void;
};
export default useBottomSheet;
