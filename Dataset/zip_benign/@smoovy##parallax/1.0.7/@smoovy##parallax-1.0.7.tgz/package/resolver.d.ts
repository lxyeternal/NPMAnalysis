export interface ParallaxResolverState {
    pos: number;
    size: number;
    speed: number;
    maxSize: number;
    shiftEnd: number;
    shiftStart: number;
    viewSize: number;
    scrollPos: number;
}
export interface ParallaxResolverConfig {
    normalize?: boolean;
}
export declare class ParallaxResolver {
    private config;
    state: ParallaxResolverState;
    constructor(config?: ParallaxResolverConfig, state?: Partial<ParallaxResolverState>);
    get mid(): number;
    get midView(): number;
    get progress(): number;
    get norm(): number;
    get maskShift(): number;
    update(newState: Partial<ParallaxResolverState>): void;
    shift(clampShift?: boolean, scrollPos?: number): number;
    shiftStart(): number;
    shiftEnd(): number;
    private isEntry;
    private isOutro;
}
