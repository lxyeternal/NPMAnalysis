import { Observable } from '@smoovy/observer';
import { Coordinate } from '@smoovy/utils';
import { ParallaxResolver } from './resolver';
import { ParallaxState } from './state';
export interface ParallaxElementConfig {
    target: HTMLElement;
    transform?: boolean;
}
export interface ParallaxConfig {
    /**
     * Context to tell tell which updates to
     * listen to and which state to use
     *
     * @default default
     */
    context?: string;
    /**
     * Whether to enable "out-of-viewport" detection and stop updating
     * once the coordinates aren't visible to the user anymore
     *
     * @default true
     */
    culling?: boolean;
    /**
     * This enabled a special mode where the parallax item moves inside a
     * container. Usually an element with `overflow: hidden`. This applies
     * a scale to the item, so it won't show a gap when the user scrolls
     * by this item. It's as simple as: 1 + (gap * 2) / size. If there's
     * an element available it will be transformed.
     *
     * @default false
     */
    masking?: boolean;
    /**
     * Whether to normalize the shift value. If this is enabled, a value
     * for compensating starting and ending positions will be added to the
     * shift value. So if you have an item at the first section of your
     * viewport the starting position will be adjusted, so the shift will
     * be 0 if the scroll position is 0.
     *
     * @default true
     */
    normalize?: boolean;
    /**
     * The speed tells how fast the item should move in relation to the
     * scroll position. The initial position will always be reached when
     * the center position of the item and the viewport match. This means
     * if the item is in the center of the viewport the shift is 0.
     * A speed value of 0 means no shift, 1 means basicall fixed and everthing
     * in between, below and above will generate parallax effect
     *
     * @default { x: 0, y: 0 }
     */
    speed?: Partial<Coordinate>;
    /**
     * This will be used as a target, so the shift will be applied as
     * translate3d and the mask (if enabled) with `scale`
     *
     * @default null
     */
    element?: HTMLElement | ParallaxElementConfig;
    /**
     * Determines the clamp mode of the element. This can be useful as an
     * alternative to css-sticky, in cases where you need more flexibility.
     * Hovever it's recommended to use "position: sticky" wherever possible.
     *
     * Note: clamping ignores paddings and margins int the parent container.
     * If you want to have spacings, you need to wrap the parent container
     * accordingly. This is to simplify the position calculations
     *
     * 'parent' -> It uses the parent box to termine, how far to move the pos
     */
    clamp?: 'parent' | false;
    /**
     * Simply notifies you about the current state of the item and only will
     * be triggered if the item position has changed. You can make modifications
     * to the state here. For example remap the y value to x so it moves
     * horizontally when the user scrolls vertically
     */
    onUpdate?: (state: ParallaxState, progress: Coordinate) => void;
}
export declare function parallax(config: ParallaxConfig): Parallax;
export declare class Parallax {
    protected config: ParallaxConfig;
    private static registry;
    private static locks;
    protected target?: Observable<HTMLElement>;
    protected parent?: Observable<HTMLElement>;
    protected resolvers: Coordinate<ParallaxResolver>;
    protected state: ParallaxState;
    constructor(config: ParallaxConfig);
    static update(state?: Partial<ParallaxState>, ctx?: string): void;
    static lock(ctx?: string, scope?: HTMLElement): void;
    static unlock(ctx?: string, scope?: HTMLElement): void;
    get context(): string;
    get speed(): {
        x: number;
        y: number;
    };
    get progress(): {
        x: number;
        y: number;
    };
    get scale(): number;
    private updateResolvers;
    private isLocked;
    private updateTarget;
    private updateObservable;
    update(newState: Partial<ParallaxState>): void;
    destroy(): boolean;
}
