"use strict";
import { observe, unobserve } from "@smoovy/observer";
import { between, clamp, isFunc } from "@smoovy/utils";
import { ParallaxResolver } from "./resolver";
import { createState } from "./state";
export function parallax(config) {
  return new Parallax(config);
}
const _Parallax = class {
  constructor(config) {
    this.config = config;
    this.state = createState();
    const entries = _Parallax.registry.get(this.context);
    this.resolvers = {
      x: new ParallaxResolver(config),
      y: new ParallaxResolver(config)
    };
    if (entries) {
      entries.push(this);
    } else {
      _Parallax.registry.set(this.context, [this]);
    }
    if (config.element) {
      const element = config.element instanceof HTMLElement ? config.element : config.element.target;
      this.target = observe(element, {
        resizeDetection: true,
        visibilityDetection: true
      });
      if ((config.masking || config.clamp == "parent") && element.parentElement instanceof HTMLElement) {
        this.parent = observe(element.parentElement, {
          visibilityDetection: true
        });
      }
      this.target.onDimChange(() => this.updateTarget());
      [0, 10, 50, 100].forEach((ms) => setTimeout(() => this.updateTarget(), ms));
    }
  }
  static update(state = {}, ctx = "default") {
    const entries = _Parallax.registry.get(ctx);
    if (entries && entries.length > 0) {
      for (const entry of entries) {
        entry.update(state);
      }
    }
  }
  static lock(ctx = "default", scope) {
    if (!this.locks.find((lock) => lock.ctx === ctx && lock.scope === scope)) {
      this.locks.push({ ctx, scope });
    }
  }
  static unlock(ctx = "default", scope) {
    const index = this.locks.findIndex((lock) => lock.ctx === ctx && lock.scope === scope);
    if (index > -1) {
      this.locks.splice(index, 1);
    }
  }
  get context() {
    return this.config.context || "default";
  }
  get speed() {
    return { x: 0, y: 0, ...this.config.speed || {} };
  }
  get progress() {
    return { x: this.resolvers.x.progress, y: this.resolvers.y.progress };
  }
  get scale() {
    if (this.config.masking) {
      const state = this.state;
      const mX = this.resolvers.x.maskShift;
      const mY = this.resolvers.y.maskShift;
      return 1 + (mX > mY ? mX / state.width : mY / state.height);
    }
    return 1;
  }
  updateResolvers() {
    const state = this.state;
    const config = this.config;
    const speed = this.speed;
    const culling = this.config.culling !== false && !this.config.masking;
    this.resolvers.x.update({
      pos: state.x,
      size: state.width,
      speed: speed.x,
      maxSize: state.maxWidth,
      scrollPos: state.scrollX,
      viewSize: state.viewWidth
    });
    this.resolvers.y.update({
      pos: state.y,
      size: state.height,
      speed: speed.y,
      maxSize: state.maxHeight,
      scrollPos: state.scrollY,
      viewSize: state.viewHeight
    });
    state.shiftX = this.resolvers.x.shift(culling);
    state.shiftY = this.resolvers.y.shift(culling);
    state.startX = this.resolvers.x.state.shiftStart;
    state.startY = this.resolvers.y.state.shiftStart;
    state.endX = this.resolvers.x.state.shiftEnd;
    state.endY = this.resolvers.y.state.shiftEnd;
    if (config.clamp === "parent" && this.parent && this.target) {
      const minY = this.parent.y - this.target.y;
      const maxY = this.parent.height - this.target.height + minY;
      const minX = this.parent.x - this.target.x;
      const maxX = this.parent.width - this.target.width + minX;
      state.shiftX = clamp(state.shiftX, minX, maxX);
      state.shiftY = clamp(state.shiftY, minY, maxY);
      state.startX = clamp(state.startX, minX, maxX);
      state.startY = clamp(state.startY, minY, maxY);
      state.endX = clamp(state.endX, minX, maxX);
      state.endY = clamp(state.endY, minY, maxY);
    }
  }
  isLocked() {
    return !!_Parallax.locks.find((lock) => {
      const contextMatch = lock.ctx === this.context;
      if (lock.scope && this.target) {
        return contextMatch && lock.scope.contains(this.target.ref);
      }
      return contextMatch;
    });
  }
  updateTarget() {
    const target = this.target;
    if (target) {
      this.state.x = target.left;
      this.state.y = target.top;
      this.state.width = target.width;
      this.state.height = target.height;
      this.update(this.state);
    }
  }
  updateObservable() {
    if (!this.target) {
      return;
    }
    const state = this.state;
    const config = this.config;
    const scale = this.scale;
    const maskingTarget = this.parent || this.target;
    const elementConfig = this.config.element;
    const visible = config.masking ? maskingTarget.visible : between(state.shiftY, state.startY, state.endY, true) || between(state.shiftX, state.startX, state.endX, true);
    if (config.culling !== false && visible || config.culling === false) {
      let transform = "";
      if (elementConfig.transform !== false) {
        transform += `translate3d(${state.shiftX.toFixed(3)}px,${state.shiftY.toFixed(3)}px,0)`;
      }
      if (scale !== 1) {
        transform += ` scale(${scale})`;
      }
      if (transform) {
        this.target.ref.style.transform = transform;
      }
    }
  }
  update(newState) {
    if (this.isLocked()) {
      return;
    }
    const state = this.state = { ...this.state, ...newState };
    this.updateResolvers();
    if (isFunc(this.config.onUpdate)) {
      this.config.onUpdate(state, this.progress);
    }
    this.updateObservable();
  }
  destroy() {
    const entries = _Parallax.registry.get(this.context);
    if (entries) {
      const index = entries.indexOf(this);
      if (index > -1) {
        entries.slice(index, 1);
        return true;
      }
    }
    if (this.target) {
      unobserve(this.target);
    }
    return false;
  }
};
export let Parallax = _Parallax;
Parallax.registry = /* @__PURE__ */ new Map();
Parallax.locks = [];
