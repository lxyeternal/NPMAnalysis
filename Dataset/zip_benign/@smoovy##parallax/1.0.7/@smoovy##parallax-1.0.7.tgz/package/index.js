"use strict";
export * from "./parallax";
