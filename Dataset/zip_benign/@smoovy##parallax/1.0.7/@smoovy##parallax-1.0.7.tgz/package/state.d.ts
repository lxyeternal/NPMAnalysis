export interface ParallaxState {
    x: number;
    y: number;
    width: number;
    height: number;
    shiftX: number;
    shiftY: number;
    startX: number;
    startY: number;
    endX: number;
    endY: number;
    scrollX: number;
    scrollY: number;
    viewWidth: number;
    viewHeight: number;
    maxWidth: number;
    maxHeight: number;
}
export declare const createState: () => ParallaxState;
