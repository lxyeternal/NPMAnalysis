# ErasableLayer

## what's?

It is a erasable cover that based is canvas,and you can simple to use it.

## features

✨️ Friendly TypeScript

✨️ Vue3 Scripe Setup

✨️ Thin Size (6kb)

## props & emits & instance

| props       | type     | default    | desc                                                                                                                       |
|-------------|----------|------------|----------------------------------------------------------------------------------------------------------------------------|
| layerColor  | string   | gray       | color of cover                                                                                                             |
| over        | number   | 0.5        | clear cover when over. max value is 0.7                                                                                    |
| renderLayer | function | /          | custom cover render function.and <br/>you need set `ctx.value.globalCompositeOperation = "destination-out";` <br/> in last |
| canvasId    | string   | __erasable | support from version `1.0.3`                                                                                               |

it emit a event entitle `done` ,example:

> **it will be called when your erased area more than `over` value**

you can use component instance to reset canvas, example:

```vue

<script setup lang="ts">
import { ErasableLayer, type ErasableInstanceRef } from 'erasable-pkg'
import { ref } from 'vue';

const erasableRef = ref<ErasableInstanceRef | null>(null)


function onReset() {
  erasableRef.value?.reset();
}

</script>
<template>
  <div>
    <ErasableLayer ref="erasableRef">
      <div style="width: 360px; height: 180px;background-color: blue;">
        <span>???</span>
      </div>
    </ErasableLayer>

    <button @click="onReset">reset</button>
  </div>
</template>
```

aursordev：😊 Enjoy it.