// myComponent.d.ts
declare module "erasable-pkg" {
  import { App, DefineComponent } from "vue";
  export type ErasableInstanceRef = {
    reset: () => void;
  };

  export const ErasableLayer: DefineComponent<{
    layerColor?: string;
    renderLayer?: (ctx: CanvasRenderingContext2D, w: number, h: number) => void;
    over?:number
    canvasId?:string
  }, {}, {
    done: () => void;
  }>;

  export default {
    install(app: App) {
      app.component("ErasableLayer", ErasableLayer);
    }
  };
}
