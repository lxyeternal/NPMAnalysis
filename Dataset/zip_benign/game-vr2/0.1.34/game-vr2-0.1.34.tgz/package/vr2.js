import * as THREE from "./lib/three";
import "./lib/OrbitControls";
import "./lib/DeviceOrientationControls";
import { single } from "./lib/single";
import { gsap, Linear } from './lib/gsap';
import { Frame } from "./lib/frame";

Component({
  mixins: [],
  data: {
    beiShu: 1,
    canvasId: "",
    showCanvas: false,
    platform: my.getSystemInfoSync().platform.toLowerCase()
  },
  props: {
    gameSource: null,
    onRef: Function,
    onInitDone: Function,
    onSceneRenderDone: Function,
    onEvent: Function,
  },
  async didMount() {
    /* console.log = (function (oriLogFunc) {
      return function () {
        oriLogFunc.call(console, ...arguments);
      }
    })(console.log);
    console.log = function () { };
    console.warn = function () { }; */
    this._gameSource = this.props.gameSource;
    let { windowWidth, windowHeight, pixelRatio, titleBarHeight, statusBarHeight } = my.getSystemInfoSync();
    this.screenW = windowWidth;
    this.screenH = windowHeight;
    // showCanvas
    let boxRect;
    if (this._gameSource.dom) {
      boxRect = {
        data: Object.assign({ left: 0, top: 0, right: 0, bottom: 0, width: 750, height: 1000 }, this._gameSource.dom)
      };
    } else {
      boxRect = await this.dom(".tempRectBox");
    }
    if (this._gameSource.isRotate) {
      this.windowWidth = boxRect.data.height;
      this.windowHeight = boxRect.data.width;
      this.offsetLeft = boxRect.data.top;
      this.offsetTop = this.screenW - boxRect.data.right;
    } else {
      this.windowWidth = boxRect.data.width;
      this.windowHeight = boxRect.data.height;
      this.offsetLeft = boxRect.data.left;
      this.offsetTop = boxRect.data.top;
    }
    // let { windowWidth, windowHeight, pixelRatio, titleBarHeight, statusBarHeight } = my.getSystemInfoSync();
    // this.windowWidth = windowWidth;
    // this.windowHeight = windowHeight;

    this.pixelRatio = pixelRatio;

    let canvasId = "canvas" + this.uniId();
    let changeAniTime = parseFloat(this._gameSource.sceneAniTime) || 0;
    this.setData({
      marginLeft: this._gameSource.isRotate ? this.windowHeight : 0,
      rotate: this._gameSource.isRotate ? 90 : 0,
      canRotate: this._gameSource.isRotate && this.data.platform == 'android' ? 2.167 : 1,
      canOrigin: this._gameSource.isRotate && this.data.platform == 'android' ? '50% 100%' : '0% 0%',
      changeAniTime,
      showCanvas: true,
      boxW: this.windowWidth,
      boxH: this.windowHeight,
      canvasWidth: this.windowWidth * this.pixelRatio * this.data.beiShu,
      canvasHeight: this.windowHeight * this.pixelRatio * this.data.beiShu,
      canvasId: canvasId
    }, () => {
      this.parFun("onRef", this);
    });
  },
  didUpdate() { },
  didUnmount() {
    if (this.dControls) {
      this.dControls.dispose();
    }
    (this.materials || []).forEach(material => {
      if (material.map) {
        material.map.dispose();
      }
    })
    console.error("didUnmount:", this._gameSource.name)
    try {
      for (let i in this) {
        this[i] = null;
      }
    } catch (e) { }
    this[`canvas_${this.data.canvasId}`] = null;
  },
  methods: {
    randomRange(t, i) {
      return Math.random() * (i - t) + t
    },
    particleFun() {
      var TO_RADIANS = Math.PI / 180;
      THREE.Vector3.prototype.rotateY = function (t) {
        let cosRY = Math.cos(t * TO_RADIANS);
        let sinRY = Math.sin(t * TO_RADIANS);
        var i = this.z, o = this.x;
        this.x = o * cosRY + i * sinRY, this.z = o * -sinRY + i * cosRY;
      };
      THREE.Vector3.prototype.rotateX = function (t) {
        let cosRY = Math.cos(t * TO_RADIANS);
        let sinRY = Math.sin(t * TO_RADIANS);
        var i = this.z, o = this.y;
        this.y = o * cosRY + i * sinRY, this.z = o * -sinRY + i * cosRY;
      };
      THREE.Vector3.prototype.rotateZ = function (t) {
        let cosRY = Math.cos(t * TO_RADIANS);
        let sinRY = Math.sin(t * TO_RADIANS);
        var i = this.x, o = this.y;
        this.y = o * cosRY + i * sinRY, this.x = o * -sinRY + i * cosRY;
      };

      // 粒子配置
      let particleObj = this._gameSource.scenes[this._idx].particles || {};

      if (Object.keys(particleObj).length > 0) {
        const material = new THREE.SpriteMaterial({
          color: 0xffffff,
          map: single.loadTexture(this[`canvas_${this.data.canvasId}`], (particleObj.src || "https://img.alicdn.com/imgextra/i3/2185320355/O1CN016RiE6n1EUdNXsLaQM_!!2185320355.png"), () => { })
          // map: single.loadTexture(this[`canvas_${this.data.canvasId}`], "./images/snow.png", () => { })
        });
        let snowGroup = new THREE.Group();
        this.scene.add(snowGroup)

        let maxRandom = particleObj.maxV || Math.abs(my.camera.position.z) || 50;
        this.maxRandom = parseFloat(maxRandom);
        this.particlesArr = [];
        for (let i = 0; i < (particleObj.count || 200); i++) {
          let particle = new THREE.Sprite(material);
          particle.noClick = true;
          particle.name = "snow";
          particle.position.x = Math.random() * this.maxRandom - this.maxRandom / 2;
          particle.position.y = Math.random() * this.maxRandom - this.maxRandom / 2;
          particle.position.z = Math.random() * this.maxRandom - this.maxRandom / 2;
          particle.scale.x = particle.scale.y = 1;

          let velocity = new THREE.Vector3(0, -(particleObj.speed || 0.02), 0);
          velocity.rotateX(this.randomRange(-45, 45));
          velocity.rotateY(this.randomRange(0, 360));
          particle.tempObj = {
            velocity,
            gravity: new THREE.Vector3(0, 0, 0),
            drag: 1
          };
          particle.updatePhysics = function () {
            this.tempObj.velocity.multiplyScalar(this.tempObj.drag);
            this.tempObj.velocity.addSelf(this.tempObj.gravity);
            this.position.addSelf(this.tempObj.velocity);
          };

          snowGroup.add(particle);
          this.particlesArr.push(particle);
        }
      }
    },
    //读取节点信息
    dom(className) {
      return new Promise(function (resolve, reject) {
        let result = {};
        my.createSelectorQuery()
          .select(className)
          .boundingClientRect()
          .exec(([ret]) => {
            if (ret) {
              result.success = true;
              result.data = ret;
            } else {
              result.success = false;
            }
            resolve(result);
          });
      });
    },
    uniId() {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0,
          v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    },
    parFun(funName, options) {
      try {
        // 判断组件是否有传入事件，如果没有，则再判断页面上是否有指定事件
        this.props[funName](options);
      } catch (e) { }
    },
    onWindowTouchStart(e) {
      this.touchStartFun();
      if (my.emit) {
        my.emit('windowTouchStart', e);
      } else {
        my._windowTouchStart(e);
      }
      this.startE = e;
    },
    onWindowTouchMove(e) {
      if (my.emit) {
        my.emit('windowTouchMove', e);
      } else {
        my._windowTouchMove(e);
      }
    },
    onWindowTouchEnd(e) {
      this.touchEndCheckClickFun(e);
      if (my.emit) {
        my.emit('windowTouchEnd', e);
      } else {
        my._windowTouchEnd(e);
      }
    },
    onWindowTouchCancel(e) {
      this.touchEndCheckClickFun(e);
      if (my.emit) {
        my.emit('windowTouchCancel', e);
      } else {
        my._windowTouchCancel && my._windowTouchCancel(e);
      }
    },
    touchEndCheckClickFun(e) {
      if (this.sceneObj) {
        if (this.sceneObj.cameraControls._autoRotate) {
          // 自动旋转
          const now = +new Date();
          const clickStopTime = this.sceneObj.cameraControls.clickStopTime || 0;
          if (clickStopTime === -1) {
            // 停止，不需要自动旋转了
            this.rotatePauseTime = 0;
          } else {
            this.rotatePauseTime = now + clickStopTime;
          }
        }
        this.cameraControls && (this.cameraControls.autoRotate = false);
      }
      if (!this.startE) { return false; }
      let x0 = this.startE.changedTouches[0].pageX || this.startE.changedTouches[0].x || this.startE.changedTouches[0].clientX || 0;
      let y0 = this.startE.changedTouches[0].pageY || this.startE.changedTouches[0].y || this.startE.changedTouches[0].clientY || 0;
      let startX = x0;
      let startY = y0;
      let page0X = e.changedTouches[0].pageX || e.changedTouches[0].x || e.changedTouches[0].clientX || 0;
      let page0Y = e.changedTouches[0].pageY || e.changedTouches[0].y || e.changedTouches[0].clientY || 0;
      let endX = page0X;
      let endY = page0Y;
      let moveX = Math.abs(endX - startX);
      let moveY = Math.abs(endY - startY);

      let moveLMD = 10;
      if (moveX <= moveLMD && moveY <= moveLMD) {
        this.clickFun(e);
      }
      this.startE = false;
    },
    getCanvasImg(ops) {
      let _this = this;
      // clearTimeout(_this.getCanvasImgTimer);
      let rpxW = 750;
      let rpxH = rpxW / (this.data.boxW / this.data.boxH);
      let scaleX = this.data.canvasWidth / rpxW,
        scaleY = this.data.canvasHeight / rpxH;
      let options = Object.assign(
        {
          x: 0,
          y: 0,
          width: rpxW,
          height: rpxH,
          saveToPhotosAlbum: false
        },
        ops
      );
      let x = Math.min(Math.max(0, options.x), rpxW) * scaleX;
      let y = Math.min(Math.max(0, options.y), rpxH) * scaleY;
      let width = Math.min(rpxW - x, options.width) * scaleX;
      let height = Math.min(rpxH - y, options.height) * scaleY;
      return new Promise(function (resolve, reject) {
        // _this.getCanvasImgTimer = setTimeout(() => {
        if (!!my.fCanvas.toTempFilePath) {
          my.fCanvas.toTempFilePath({
            x,
            y,
            width,
            destWidth: width,
            height,
            destHeight: height,
            saveToPhotosAlbum: !!options.saveToPhotosAlbum, //false:不保存到相册 true:自动保存到相册
            fileType: 'png',
            success: (res) => {
              if (options.base64) {
                my.getFileSystemManager().readFile({
                  filePath: res.apFilePath,
                  encoding: 'base64',
                  success: (res1) => {
                    resolve('data:image/jpg;base64,' + res1.data);
                  },
                  fail(e) {
                    reject(e);
                  }
                });
              } else {
                resolve(res.apFilePath);
              }
            },
            fail: (res) => {
              // my.alert({ content: JSON.stringify(res) });
              reject(res);
            }
          });
        } else {
          let src = my.fCanvas.toDataURL();
          resolve("");
        }
        // }, 200);
      });
    },
    threeCanvasReady() {
      my.createCanvas({
        id: this.data.canvasId,
        success: (c) => {
          // 此处必写，传入全局begin
          my.fCanvas = c;
          // 此处必写，传入全局end
          this[`canvas_${this.data.canvasId}`] = c;

          const w = this.windowWidth;
          const h = this.windowHeight;
          this.renderSize = { width: w, height: h };
          this.scene = new THREE.Scene()
          my.scene = this.scene;
          this.camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 1000)
          my.camera = this.camera;
          // 默认位置 0 2.5 40
          this.camera.position.set(0, 0, 0.01);
          // this.camera.lookAt(0, 0, 0);
          // this.camera.updateProjectionMatrix();
          try {
            this.renderer = new THREE.WebGLRenderer({
              canvas: this[`canvas_${this.data.canvasId}`],
              alpha: true,
              antialias: true,
            })
          } catch (e) {
            my.alert({ content: 'error:' + e });
          }
          let bl = false;
          try {
            this.renderer.setPixelRatio(this.pixelRatio);
            this.renderer.setSize(w, h);
          } catch (e) {
            bl = true;
          }
          if (bl) { return false; }

          // this.initBackground();
          // 图片周边动画
          // this.createAnimation();

          if (!this._gameSource.noControls) {
            this.cameraControls = new THREE.OrbitControls(this.camera, { width: this.windowWidth, height: this.windowHeight, camera: this.camera, isRotate: this.data.platform == 'android' || my.isIDE ? !!this._gameSource.isRotate : false });
            my.cameraControls = this.cameraControls;
          }

          if (this._gameSource.deviceControls) {
            this.dControls = new THREE.DeviceOrientationControls(this.camera);
          }

          this.render();

          this.parFun("onInitDone", this);
        }
      });
    },
    dispose(parent, child) {
      if (child.children.length) {
        let arr = child.children.filter(x => x);
        arr.forEach(a => {
          this.dispose(child, a)
        })
      }
      if (child instanceof THREE.Mesh) {
        if (child.material.map && !!child.material.map.dispose) child.material.map.dispose();
        if (child.material.length) {
          let len = child.material.length;
          for (let i = len - 1; i >= 0; i--) {
            if (child.material[i].map && !!child.material[i].map.dispose) {
              child.material[i].map.dispose();
              child.material[i].dispose();
              child.material[i] = null;
            }
          }
        }
        if (!!child.material.dispose) {
          child.material.dispose();
          child.material = null;
        }
        if (!!child.geometry.dispose) {
          child.geometry.dispose();
          child.geometry = null;
        }
      } else if (child.material) {
        if (!!child.material.dispose) {
          child.material.dispose();
          child.material = null;
        }
      }
      child.remove();
      parent.remove(child);
    },
    cameraControlsSetting(cameraControls, camera) {
      let controlObj = Object.assign({
        leftRightDirection: -1,
        enablePan: false,
        autoRotate: false,
        autoRotateSpeed: 2.0,
        enableDamping: true,
        dampingFactor: 0.45,
        screenSpacePanning: false,
        enableZoom: false, //双指放大缩小
        // isPerspectiveCamera----
        minCameraFov: 30,
        maxCameraFov: 60,
        // isPerspectiveCamera----
        // isOrthographicCamera---
        minZoom: 0,
        maxZoom: 100,
        // isOrthographicCamera---
        // minDistance: 40,
        // maxDistance: 80,
        enableRotate: true,
        rotateSpeed: 1.0,
        maxPolarAngle: Math.PI / 180 * 100,
        minPolarAngle: Math.PI / 180 * 70,
        lastPhiAngle: 0,
      }, cameraControls);

      let cameraObj = Object.assign({
        fov: 45,
        near: 0.1,
        far: 1000
      }, camera);

      for (let i in cameraObj) {
        if (i == "position") {
          this.camera.position.set(cameraObj[i].x, cameraObj[i].y, cameraObj[i].z);
        } else if (i == "lookAt") {
          this.camera.lookAt(cameraObj[i].x, cameraObj[i].y, cameraObj[i].z);
        } else {
          this.camera[i] = cameraObj[i];
        }
      }
      this.camera.updateProjectionMatrix();

      for (let i in controlObj) {
        if (parseFloat(controlObj[i]) == controlObj[i]) {
          controlObj[i] = parseFloat(controlObj[i]);
        }
        this.cameraControls[i] = controlObj[i];
      }
      /* //this.cameraControls.target = new THREE.Vector3(0,0,0);
      this.cameraControls.leftRightDirection = -1;
      this.cameraControls.enablePan = false;//是否可以平移 默认速度keyPanSpeed:7
      this.cameraControls.autoRotate = false;//是否自动旋转
      this.cameraControls.autoRotateSpeed = 2.0;
      // // controls.addEventListener( 'change', render ); // call this only in static scenes (i.e., if there is no animation loop)
      this.cameraControls.enableDamping = true; // an animation loop is required when either damping or auto-rotation are enabled
      this.cameraControls.dampingFactor = 0.45;
      this.cameraControls.screenSpacePanning = false;
      this.cameraControls.enableZoom = false;//是否启用双指放大缩小
      this.cameraControls.minDistance = 40;//双指缩放值
      this.cameraControls.maxDistance = 80;
      this.cameraControls.enableRotate = !false;//是否可以旋转
      this.cameraControls.rotateSpeed = 1.0;//旋转速度 */
      // 上下角度，最大值和最小值
      /* 上下不移动 */
      /* this.cameraControls.maxPolarAngle = Math.PI / 180 * 90;
      this.cameraControls.minPolarAngle = Math.PI / 180 * 90; */

      /* this.cameraControls.maxPolarAngle = Math.PI / 180 * 100;//上下移动值
      this.cameraControls.minPolarAngle = Math.PI / 180 * 70;
      //this.cameraControls.update();

      //this.cameraControls.rotateUp(-0.033);
      this.cameraControls.lastPhiAngle = 0; */
    },
    startRotate() {
      this.sceneObj.cameraControls._autoRotate = true;
      this.cameraControls.autoRotate = true;
    },
    stopRotate() {
      this.sceneObj.cameraControls._autoRotate = false;
      this.cameraControls.autoRotate = false;
    },
    cameraAni(ops) {
      const _this = this;
      const options = Object.assign(
        {
          ani: this.sceneObj.camera.ani,
        },
        ops,
      );
      if (this.sceneObj) {
        gsap.to(this.camera, {
          duration: options.ani.duration || 1,
          fov: options.ani.fov,
          onUpdate() {
            _this.camera.updateProjectionMatrix();
          },
          onComplete() {
            _this.camera.updateProjectionMatrix();
            if (options.callback) {
              options.callback();
            }
          },
        });
      }
    },
    rotateScene(num1, callback) {
      let _this = this;
      let num = parseFloat(num1) || 1;
      let obj = my.camera.position;
      obj = this.scene.rotation;
      obj = { y: this.scene.rotation.y };
      let endY = obj.y + Math.PI * 2 * num;
      this.gsapObj = obj;

      gsap.to(obj, {
        duration: (this.sceneObj.rotateSceneDuration || 1) * Math.abs(num),
        ease: Linear.easeNone,
        y: endY,
        onUpdate: function () {
          _this.scene.rotation.y = obj.y;
        },
        onComplete: function () {
          _this.scene.rotation.y = obj.y;
          if (!!callback) {
            callback();
          }
        }
      })
    },
    toPos(pos, callback) {
      let _this = this;
      gsap.to(this.scene.rotation, {
        duration: this.sceneObj.toPosDuration || 1,
        ease: Linear.easeNone,
        x: 0,
        y: 0,
        z: 0,
      });
      let obj = { x: this.camera.position.x, y: this.camera.position.y, z: this.camera.position.z, };
      if (typeof pos.fov != "undefined") {
        obj.fov = parseFloat(this.camera.fov);
        // my.camera.fov = 46;
        // my.camera.updateProjectionMatrix();
      }
      let endObj = {
        duration: pos.duration || this.sceneObj.toPosDuration || 1,
        ease: Linear.easeNone,
        x: pos.x,
        y: pos.y,
        z: pos.z,
        onUpdate: function () {
          // console.log(obj)
          _this.camera.position.set(obj.x, obj.y, obj.z);
          if (typeof pos.fov != "undefined") {
            _this.camera.fov = obj.fov;
            _this.camera.updateProjectionMatrix();
          }
        },
        onComplete: function () {
          _this.camera.position.set(obj.x, obj.y, obj.z);
          if (typeof pos.fov != "undefined") {
            _this.camera.fov = obj.fov;
            _this.camera.updateProjectionMatrix();
          }
          if (!!callback) {
            callback();
          }
        }
      };
      if (typeof pos.fov != "undefined") {
        endObj.fov = parseFloat(pos.fov);
      }

      gsap.to(obj, endObj)
    },
    disposeFun() {
      let _this = this;
      if (!_this.scene) { return false; }
      for (let i = _this.scene.children.length - 1; i >= 0; i--) {
        _this.dispose(_this.scene, _this.scene.children[i]);
      }
      _this._frames = [];
      if (_this.gsapObj) {
        gsap.killTweensOf(_this.gsapObj);
        _this.gsapObj = null;
      }
      _this.particlesArr = [];
    },
    async renderScene(idx) {
      let _this = this;
      if (!_this.scene) { return false; }
      if (!_this._gameSource) { return false; }
      this._idx = idx || 0;
      if (_this.isNotFristRender) {
        // 已经渲染过至少一个场景了
        this.outAni(async () => {
          // 生成上一张图
          let preImg = await this.getCanvasImg({ base64: true });
          // 显示图片=======
          if (!preImg) {
            this.tempRender();
          } else {
            this.setData({
              preClass: "",
              preImg
            })
          }
        })
      } else {
        // 第一次渲染场景
        this.tempRender();
      }
      _this.isNotFristRender = true;
    },
    preImgDoneFun() {
      // 图片加载完成
      this.runTempRenderTime = (+new Date()) + 100;
    },
    tempRender() {
      let _this = this;

      _this.disposeFun();

      gsap.to(_this.scene.rotation, {
        duration: 0.01,
        ease: Linear.easeNone,
        x: 0,
        y: 0,
        z: 0,
        onComplete: () => {
          let scene = _this._gameSource.scenes[_this._idx];
          _this.sceneObj = scene;

          // 1.初始化相机配置
          if (!_this._gameSource.noControls) {
            _this.cameraControlsSetting(scene.cameraControls, scene.camera);
          }
          _this._renderTime = +new Date();
          _this._renderBgObj = { backgrounds: scene.backgrounds, idx: _this._idx };
        }
      });
    },
    addFrame(hots) {
      this._frames = this._frames || [];
      hots.forEach((hot, idx) => {
        if (!!hot.img && !!hot.frame) {
          let keyFrame = new Frame(THREE, this.scene, this[`canvas_${this.data.canvasId}`], hot);
          // let keyFrame = new Frame(THREE, { src: 'https://img.alicdn.com/imgextra/i1/1080040467/O1CN01FhfFgn1FJvg0fJn46_!!1080040467.png', width: 1200, height: 750, fWidth: 150, fHeight: 150, count: 37 },
          //   { width: 10 * 1.5 * 5 / 138 * 150, height: 10 * 1.5 * 5 / 138 * 150, duration: 1.33333, loop: true, position: { x: 98.82, y: 28.86, z: -600, } });

          // keyFrame.faceTo(new THREE.Vector3(), new THREE.Vector3(0, 0, 1));
          keyFrame.play();
          my[`tt${idx}`] = keyFrame.mesh;
          this._frames.push(keyFrame);
        }
      })
    },
    onAnimationEnd() {
      this.setData({
        preClass: "",
        preImg: ""
      })
    },
    sceneRenderDone() {
      // 渐隐上一个场景图片
      this.setData({
        preClass: "fani1",
      })
    },
    enterAni(callback) {
      if (this.sceneObj.enterAni) {
        this.cameraAni({
          callback: () => {
            !!callback && callback();
          },
          ani: this.sceneObj.enterAni
        })
      } else {
        !!callback && callback();
      }
    },
    outAni(callback) {
      this.stopRotate();
      if (this.sceneObj.outAni) {
        this.cameraAni({
          callback: () => {
            !!callback && callback();
          },
          ani: this.sceneObj.outAni
        })
      } else {
        !!callback && callback();
      }
    },
    initBackground(backgrounds, idx) {
      this._renderTime = 0;

      let doneNum = 0;
      let callback = () => {
        doneNum++;
        if (doneNum == 6) {
          this.addFrame(this.sceneObj.hots);
          this.particleFun();
          this.enterAni(() => {
            if (this.sceneObj.initDoneAutoRotate) {
              // 渲染完成后自动旋转
              const now = +new Date();
              let delayTime = 0;
              if (this.sceneObj.rotateDelayTime) {
                delayTime = parseFloat(this.sceneObj.rotateDelayTime);
              }
              this.startRotateTime = now + delayTime;
            }
            this.parFun("onSceneRenderDone", idx);
          });
          this.sceneRenderDone();
        }
      };

      var createSkyBox = function () {
        var materials = [
          new THREE.MeshBasicMaterial({ transparent: false, opacity: 1, side: THREE.DoubleSide, map: single.loadTexture(this[`canvas_${this.data.canvasId}`], backgrounds.right, () => { callback("right"); }), depthWrite: false, }), // right
          new THREE.MeshBasicMaterial({ transparent: false, opacity: 1, side: THREE.DoubleSide, map: single.loadTexture(this[`canvas_${this.data.canvasId}`], backgrounds.left, () => { callback("left"); }), depthWrite: false }), // left
          new THREE.MeshBasicMaterial({ transparent: false, opacity: 1, side: THREE.DoubleSide, map: single.loadTexture(this[`canvas_${this.data.canvasId}`], backgrounds.top, () => { callback("top"); }), depthWrite: false }), // top
          new THREE.MeshBasicMaterial({ transparent: false, opacity: 1, side: THREE.DoubleSide, map: single.loadTexture(this[`canvas_${this.data.canvasId}`], backgrounds.bottom, () => { callback("bottom"); }), depthWrite: false }), // bottom
          new THREE.MeshBasicMaterial({ transparent: false, opacity: 1, side: THREE.DoubleSide, map: single.loadTexture(this[`canvas_${this.data.canvasId}`], backgrounds.front, () => { callback("front"); }), depthWrite: false }), // front
          new THREE.MeshBasicMaterial({ transparent: false, opacity: 1, side: THREE.DoubleSide, map: single.loadTexture(this[`canvas_${this.data.canvasId}`], backgrounds.back, () => { callback("back"); }), depthWrite: false }), // back
        ];

        var skyBox = new THREE.Mesh(new THREE.BoxBufferGeometry(150, 150, 150), materials);
        skyBox.position.y = 0;
        skyBox.geometry.scale(6, 6, -6);
        this.skyBox = skyBox;
        my.THREE = THREE;
        my.t = skyBox;
        my._t = this;
        // my._t.scene.rotation.z = -90*Math.PI/180
        // skyBox.name = "bgScene";
        this.outsideSkybox = skyBox;
        this.scene.add(skyBox);

        let rotation = Object.assign({ x: 0, y: 0, z: 0 }, backgrounds.rotation)
        skyBox.rotation.x = parseFloat(rotation.x) * Math.PI / 180;
        skyBox.rotation.y = parseFloat(rotation.y) * Math.PI / 180;
        skyBox.rotation.z = parseFloat(rotation.z) * Math.PI / 180;
      }.bind(this);

      createSkyBox();
    },
    touchStartFun(e) {
      // 停止转动
      if (this.gsapObj) {
        gsap.killTweensOf(this.gsapObj);
        this.gsapObj = null;
      }
    },
    clickFun(e) {
      let event = e;
      if (!event.detail) {
        event = {
          detail: {
            clientX: e.changedTouches[0].pageX || e.changedTouches[0].x || e.changedTouches[0].clientX || 0,
            clientY: e.changedTouches[0].pageY || e.changedTouches[0].y || e.changedTouches[0].clientY || 0,
          }
        }
      }
      let raycaster = new THREE.Raycaster();
      let mouse = new THREE.Vector2();
      if (this.clickStatus) { return false; }
      this.clickStatus = true;

      // 通过鼠标点击位置,计算出 raycaster 所需点的位置,以屏幕为中心点,范围 -1 到 1
      let x = event.detail.clientX, y = event.detail.clientY;
      if (this._gameSource.isRotate && (this.data.platform == 'android' || my.isIDE)) {
        // this.screenW
        x = event.detail.clientY;
        y = this.screenW - event.detail.clientX;
      }
      mouse.x = (x - this.offsetLeft) / this.windowWidth * 2 - 1;
      mouse.y = -((y - this.offsetTop) / this.windowHeight) * 2 + 1;

      //通过鼠标点击的位置(二维坐标)和当前相机的矩阵计算出射线位置
      raycaster.setFromCamera(mouse, this.camera);

      // this.scene.children
      /* let clickArr = new THREE.Group();
      this.scene.children.forEach(item => {
        if (item.type == "Sprite") {
          clickArr.add(item.clone());
        }
      }) */
      // clickArr = this.scene;
      // 获取与射线相交的对象数组，其中的元素按照距离排序，越近的越靠前
      // var intersects = raycaster.intersectObjects(clickArr.children, true);
      var intersects = raycaster.intersectObjects(this.scene.children, true);
      this.tempStatusObj = this.tempStatusObj || {};
      if (intersects.length > 0) {
        // 点击到了元素
        let names = [];
        let delayTime = 0;
        intersects.forEach(item => {
          if (!!item.object.name && !item.object.noClick) {
            let hotImg = item.object._fframe.hot.img;
            let frame = item.object._fframe.hot.frame;
            if (hotImg.count2) {
              item.object._fframe.count = hotImg.count2;
              item.object._fframe.loop = !!hotImg.loop2;
            }
            if (frame.delayTime) {
              delayTime = frame.delayTime;
            }
            if (!this.tempStatusObj[item.object.name]) {
              this.tempStatusObj[item.object.name] = true;
              names.push(item.object._data);
              // names.push(item.object.name);
            }
          }
        })
        if (names.length > 0) {
          // 点击到了热点区域
          let now = +new Date();
          this.tempTime = now + (delayTime * 1000);
          this.names = names;
        } else {
          this.clickStatus = false;
        }
      } else {
        this.clickStatus = false;
      }
    },
    tempClickFun() {
      this.parFun("onEvent", this.names);
      let jumpIdx = -1;
      this.names.forEach(obj => {
        const name = obj.name;
        this.tempStatusObj[name] = false;
        if (this._gameSource.changeScene) {
          // 自动跳转场景
          const s = name.split('_scene_');
          if (s.length > 1) {
            jumpIdx = parseInt(s[s.length - 1]);
          }
        }
      })
      if (jumpIdx != -1) {
        this.renderScene(jumpIdx);
      }
      this.clickStatus = false;
      this.names = [];
      this.tempTime = 0;
    },
    render() {
      let now = +new Date();
      if (!!this._renderTime) {
        // 渲染背景
        if (now - this._renderTime > 50) {
          this.initBackground(this._renderBgObj.backgrounds, this._renderBgObj.idx);
        }
      }
      if (this.tempTime) {
        if (now >= this.tempTime) {
          this.tempTime = 0;
          this.tempClickFun();
        }
      }
      if (!this[`canvas_${this.data.canvasId}`]) { return false; }

      if (this.rotatePauseTime) {
        if (now >= this.rotatePauseTime) {
          this.rotatePauseTime = 0;
          this.cameraControls && (this.cameraControls.autoRotate = true);
        }
      }
      if (this.startRotateTime) {
        if (now >= this.startRotateTime) {
          this.startRotateTime = 0;
          this.startRotate();
        }
      }

      if (this.particlesArr) {
        this.particlesArr.forEach(particle => {
          particle.updatePhysics();

          if (particle.position.y < -this.maxRandom / 2) {
            particle.position.y += this.maxRandom
          }
          if (particle.position.x > this.maxRandom / 2) {
            particle.position.x -= this.maxRandom
          } else {
            if (particle.position.x < -this.maxRandom / 2) {
              particle.position.x += this.maxRandom
            }
          }
          if (particle.position.z > this.maxRandom / 2) {
            particle.position.z -= this.maxRandom
          } else {
            if (particle.position.z < -this.maxRandom / 2) {
              particle.position.z += this.maxRandom
            }
          }
        })
      }

      if (this.cameraControls) {
        this.cameraControls.update();
      }

      if (this.dControls) {
        this.dControls.update();
      }

      if (!!this._frames && this._frames.length > 0) {
        this._frames.forEach(frame => {
          frame.update();
        })
      }
      try {
        this.renderer.render(this.scene, this.camera);
      } catch (e) {
        my.alert({ content: 'error:' + e });
      }

      if (this.runTempRenderTime) {
        let now = +new Date();
        if (now >= this.runTempRenderTime) {
          this.runTempRenderTime = 0;
          this.tempRender();
        }
      }

      if (this[`canvas_${this.data.canvasId}`].requestAnimationFrame) {
        this[`canvas_${this.data.canvasId}`].requestAnimationFrame(this.render.bind(this));
      } else {
        clearTimeout(this.__timer1);
        this.__timer1 = setTimeout(() => {
          this.render.bind(this)();
        }, 16)
      }
    }
  },
});