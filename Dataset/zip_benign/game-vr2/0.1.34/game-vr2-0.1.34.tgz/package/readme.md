# game-vr2

# vr全景图

##### 安装

```
npm install game-vr2
```

##### 使用
- json

```
{
    "usingComponents": {
        "game-vr2": "game-vr2/vr2"
    }
}
```

- js

```
Page({
  data: {
    gameSource: {
      isRotate: !true,//是否旋转
      scenes: [
        {
          "name": "floor1_0",
          "rotateSceneDuration": "12",
          "toPosDuration": "1",
          "camera": {
            "fov": "65",
            "position": {
              "x": "-12.021901048260778",
              "y": "1.912303315824677",
              "z": "38.13419058029282"
            }
          },
          "cameraControls": {
            "enableZoom": true,
            "minCameraFov": "40",
            "maxCameraFov": "90",
            "rotateSpeed": "0.5",
            "minPolarAngle": "0",
            "maxPolarAngle": "3.141592653589793"
          },
          "backgrounds": {
            "front": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01uvk6HE1EUdNFBCjO4_!!2185320355.jpg",
            "right": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN010YDz4K1EUdNEImcJe_!!2185320355.jpg",
            "left": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01eVGDkV1EUdNC6OAG3_!!2185320355.jpg",
            "back": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN019qcuve1EUdNDOxhkI_!!2185320355.jpg",
            "bottom": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01UWISpB1EUdNIMnxO3_!!2185320355.jpg",
            "top": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01nBzWTv1EUdN9jUA5H_!!2185320355.jpg",
          },
          "hots": [
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN014e4mqr1EUdNDsfcMX_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "247.5",
                "height": "33.75",
                "duration": "1.5"
              },
              "name": "floor2Name",
              "noClick": true,
              "position": {
                "x": "-652.39",
                "y": "-244.09",
                "z": "-179.69"
              },
              "rotation": {
                "x": "-0.56",
                "y": "0.75",
                "z": "0"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "95.2",
                "height": "200.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor2",
              "position": {
                "x": "-531.9",
                "y": "-110.72",
                "z": "-205.03"
              },
              "rotation": {
                "x": "-0.61",
                "y": "1.21",
                "z": "0"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "width": "60",
                "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point1",
              "position": {
                "x": "29.67",
                "y": "11.13",
                "z": "-622.02"
              },
              "rotation": {
                "x": "0",
                "y": "0",
                "z": "0"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "width": "50",
                "height": "50",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point2",
              "position": {
                "x": "528.38",
                "y": "-68.95",
                "z": "-379.08"
              },
              "rotation": {
                "x": "0",
                "y": "-0.49",
                "z": "0"
              }
            },
          ]
        },
        {
          "name": "floor1_1",
          "rotateSceneDuration": "12",
          "toPosDuration": "1",
          "camera": {
            "fov": "75",
            "position": {
              "x": "-10.335301756532257",
              "y": "-0.769756309326125",
              "z": "-38.665081311509326"
            }
          },
          "cameraControls": {
            "enableZoom": true,
            "minCameraFov": "40",
            "maxCameraFov": "90",
            "rotateSpeed": "0.5",
            "minPolarAngle": "0",
            "maxPolarAngle": "3.141592653589793"
          },
          "backgrounds": {
            "back": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01KxaVix1EUdNFBIuBr_!!2185320355.jpg",
            "bottom": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN015bOoSK1EUdN0JPBye_!!2185320355.jpg",
            "left": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN017a647D1EUdN5BBHGN_!!2185320355.jpg",
            "front": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01bHVJSH1EUdNC6V906_!!2185320355.jpg",
            "right": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01KLJ5FE1EUdN6gXk5v_!!2185320355.jpg",
            "top": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01Wml5ff1EUdNJBiYW6_!!2185320355.jpg",
          },
          "hots": [
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01vGOhcA1EUdNA8jDhb_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "330",
                "height": "45",
                "duration": "1.5"
              },
              "name": "floor3Name",
              "noClick": true,
              "position": {
                "x": "260.21",
                "y": "-225.95",
                "z": "-552.18"
              },
              "rotation": {
                "x": "-0.29",
                "y": "-0.35",
                "z": "-0.43"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "95.2",
                "height": "200.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor3",
              "position": {
                "x": "310.32",
                "y": "-117.12",
                "z": "-574.98"
              },
              "rotation": {
                "x": "-0.29",
                "y": "-0.35",
                "z": "-0.43"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01JP4Hoy1EUdNBvxP3H_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "280",
                "height": "38.18181818181818",
                "duration": "1.5"
              },
              "name": "floor1Name",
              "noClick": true,
              "position": {
                "x": "-676.86",
                "y": "-263.29",
                "z": "98.25"
              },
              "rotation": {
                "x": "0.59",
                "y": "1.77",
                "z": "0"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "95.2",
                "height": "200.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor1",
              "position": {
                "x": "-547.98",
                "y": "-116.06",
                "z": "139.94"
              },
              "rotation": {
                "x": "0.65",
                "y": "1.75",
                "z": "0"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "width": "60",
                "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point1",
              "position": {
                "x": "-577.51",
                "y": "11.13",
                "z": "428.09"
              },
              "rotation": {
                "x": "0",
                "y": "2.27",
                "z": "0"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "width": "50",
                "height": "50",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point2",
              "position": {
                "x": "109.88",
                "y": "11.13",
                "z": "428.09"
              },
              "rotation": {
                "x": "0",
                "y": "-2.97",
                "z": "0"
              }
            },
          ]
        },
        {
          "name": "floor1_2",
          "rotateSceneDuration": "12",
          "toPosDuration": "1",
          "camera": {
            "fov": "80",
            "position": {
              "x": "-36.16598292511157",
              "y": "-0.2481397714800171",
              "z": "-17.156911310439753"
            }
          },
          "cameraControls": {
            "enableZoom": true,
            "minCameraFov": "40",
            "maxCameraFov": "90",
            "rotateSpeed": "0.5",
            "minPolarAngle": "0",
            "maxPolarAngle": "3.141592653589793"
          },
          "backgrounds": {
            "left": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01v9ULR91EUdNJBpjhy_!!2185320355.jpg",
            "right": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01maffna1EUdNIMtSrz_!!2185320355.jpg",
            "front": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01X9Hjet1EUdNH66MQt_!!2185320355.jpg",
            "back": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN0188KQer1EUdN6gbMtX_!!2185320355.jpg",
            "bottom": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01nGSdrE1EUdN7RPBgl_!!2185320355.jpg",
            "top": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01U9xo2O1EUdN5BEId5_!!2185320355.jpg",
          },
          "hots": [
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN014e4mqr1EUdNDsfcMX_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "400",
                "height": "54.54545454545455",
                "duration": "1.5"
              },
              "name": "floor2Name",
              "noClick": true,
              "position": {
                "x": "-433.08",
                "y": "-383.85",
                "z": "513.28"
              },
              "rotation": {
                "x": "0.16",
                "y": "2.23",
                "z": "0"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "190.4",
                "height": "400.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor2",
              "position": {
                "x": "-526.6",
                "y": "-236.62",
                "z": "596.36"
              },
              "rotation": {
                "x": "-0.18",
                "y": "2.56",
                "z": "0"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01LcOsl51EUdN3QpYBw_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "330",
                "height": "45",
                "duration": "1.5"
              },
              "name": "floor4Name",
              "noClick": true,
              "position": {
                "x": "260.21",
                "y": "-225.95",
                "z": "-433.08"
              },
              "rotation": {
                "x": "-0.29",
                "y": "-0.35",
                "z": "-0.43"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "95.2",
                "height": "200.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor4",
              "position": {
                "x": "310.32",
                "y": "-117.12",
                "z": "-458.42"
              },
              "rotation": {
                "x": "-0.29",
                "y": "-0.35",
                "z": "-0.43"
              }
            },

            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "width": "60",
                "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point1",
              "position": {
                "x": "490.73",
                "y": "41.45",
                "z": "-281.05"
              },
              "rotation": {
                "x": "-0.49",
                "y": "-1.86",
                "z": "0"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "width": "100",
                "height": "100",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point2",
              "position": {
                "x": "435.61",
                "y": "58.15",
                "z": "515.78"
              },
              "rotation": {
                "x": "0",
                "y": "-1.99",
                "z": "0"
              }
            },
          ]
        },
        {
          "name": "floor1_3",
          "rotateSceneDuration": "12",
          "toPosDuration": "1",
          "camera": {
            "fov": "85",
            "position": {
              "x": "35.95933740448389",
              "y": "-2.7796913586313545",
              "z": "-17.366602125378197"
            }
          },
          "cameraControls": {
            "enableZoom": true,
            "minCameraFov": "40",
            "maxCameraFov": "90",
            "rotateSpeed": "0.5",
            "minPolarAngle": "0",
            "maxPolarAngle": "3.141592653589793"
          },
          "backgrounds": {
            "left": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN018GGHfF1EUdNJBrorp_!!2185320355.jpg",
            "right": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN014Lg3qc1EUdNAXnhVc_!!2185320355.jpg",
            "bottom": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01bGqQeF1EUdNFBPotO_!!2185320355.jpg",
            "front": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01GghVB41EUdNDP9vD9_!!2185320355.jpg",
            "back": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN010PM1nU1EUdNEItwEa_!!2185320355.jpg",
            "top": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01poADbN1EUdN7RRo3Y_!!2185320355.jpg",
          },
          "hots": [
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "1.2",
                // "width": "60",
                // "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point1",
              "position": {
                "x": "-506.57",
                "y": "41.45",
                "z": "-281.05"
              },
              "rotation": {
                "x": "0.11",
                "y": "0.52",
                "z": "0"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "2.2",
                // "width": "100",
                // "height": "100",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point2",
              "position": {
                "x": "-564.85",
                "y": "58.15",
                "z": "331.2"
              },
              "rotation": {
                "x": "0.15",
                "y": "2.05",
                "z": "0"
              }
            },

            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01FgFHTa1EUdNDsdo8s_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "450",
                "height": "61.36363636363636",
                "duration": "1.5"
              },
              "name": "floor5Name",
              "noClick": true,
              "position": {
                "x": "-400.14",
                "y": "-344.38",
                "z": "-554.71"
              },
              "rotation": {
                "x": "-0.43",
                "y": "0.43",
                "z": "0.47"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "110",
                "height": "231.09243697478993",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor5",
              "position": {
                "x": "-415.34",
                "y": "-180.07",
                "z": "-521.5"
              },
              "rotation": {
                "x": "-0.43",
                "y": "0.43",
                "z": "0.47"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01vGOhcA1EUdNA8jDhb_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "400",
                "height": "54.5",
                "duration": "1.5"
              },
              "name": "floor3Name",
              "noClick": true,
              "position": {
                "x": "277.75",
                "y": "-308.65",
                "z": "335.38"
              },
              "rotation": {
                "x": "0.63",
                "y": "-2.67",
                "z": "0.76"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "190.4",
                "height": "400.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor3",
              "position": {
                "x": "510.77",
                "y": "-232.35",
                "z": "485.72"
              },
              "rotation": {
                "x": "0.63",
                "y": "-2.67",
                "z": "0.76"
              }
            },

          ]
        },
        {
          "name": "floor1_4",
          "rotateSceneDuration": "12",
          "toPosDuration": "1",
          "camera": {
            "fov": "70",
            "position": {
              "x": "-1.122445011425609",
              "y": "-2.8540298075210204",
              "z": "39.912330564051295"
            }
          },
          "cameraControls": {
            "enableZoom": true,
            "minCameraFov": "40",
            "maxCameraFov": "90",
            "rotateSpeed": "0.5",
            "minPolarAngle": "0",
            "maxPolarAngle": "3.141592653589793"
          },
          "backgrounds": {
            "right": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01F3hpms1EUdNJBvJEh_!!2185320355.jpg",
            "front": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01tQjNDW1EUdNAXpNhP_!!2185320355.jpg",
            "bottom": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN014aCfZw1EUdN9qVKRk_!!2185320355.jpg",
            "left": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01q4uTiZ1EUdN5BKH8A_!!2185320355.jpg",
            "top": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01xroC1J1EUdNH6D4fj_!!2185320355.jpg",
            "back": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN012Hzogt1EUdNGKuAex_!!2185320355.jpg",
          },
          "hots": [
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "1.0",
                // "width": "60",
                // "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point1",
              "position": {
                "x": "-192.36",
                "y": "41.45",
                "z": "-281.05"
              },
              "rotation": {
                "x": "0.11",
                "y": "0.52",
                "z": "0"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "1.5",
                // "width": "100",
                // "height": "100",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point2",
              "position": {
                "x": "280.26",
                "y": "24.76",
                "z": "-410.28"
              },
              "rotation": {
                "x": "0.15",
                "y": "-0.54",
                "z": "0"
              }
            },

            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01LcOsl51EUdN3QpYBw_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "450",
                "height": "61.36363636363636",
                "duration": "1.5"
              },
              "name": "floor4Name",
              "noClick": true,
              "position": {
                "x": "-106.21",
                "y": "-271.83",
                "z": "448.13"
              },
              "rotation": {
                "x": "0.33",
                "y": "-3.06",
                "z": "-0.37"
              }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "110",
                "height": "231.09243697478993",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor4",
              "position": { "x": "-123.94", "y": "-105.39", "z": "418.07" },
              "rotation": { "x": "0.25", "y": "2.84", "z": "-0.29" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01RHAC3o1EUdN3QpPtt_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "400",
                "height": "54.5",
                "duration": "1.5"
              },
              "name": "floor6Name",
              "noClick": true,
              "position": { "x": "83.39", "y": "-211.01", "z": "350.41" },
              "rotation": { "x": "0.72", "y": "-2.67", "z": "0.02" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "190.4",
                "height": "400.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor6",
              "position": { "x": "107.37", "y": "-139.8", "z": "673.64" },
              "rotation": { "x": "0.63", "y": "-2.67", "z": "-0.07" }
            },

          ]
        },
        {
          "name": "floor1_5",
          "rotateSceneDuration": "12",
          "toPosDuration": "1",
          "camera": {
            "fov": "75",
            "position": { "x": "7.773129224397831", "y": "0.04995142396860289", "z": "39.267995453244346" }
          },
          "cameraControls": {
            "enableZoom": true,
            "minCameraFov": "40",
            "maxCameraFov": "90",
            "rotateSpeed": "0.5",
            "minPolarAngle": "0",
            "maxPolarAngle": "3.141592653589793"
          },
          "backgrounds": {
            "left": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01xxCDIp1EUdNBbzd4B_!!2185320355.jpg",
            "right": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01Otswe81EUdN9jnZ1T_!!2185320355.jpg",
            "front": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01EN1IXQ1EUdN5BN5xf_!!2185320355.jpg",
            "back": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01C4Rqzf1EUdNC6jyqG_!!2185320355.jpg",
            "bottom": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01GaOQIv1EUdN9jpygy_!!2185320355.jpg",
            "top": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN012EXZOi1EUdNDPHhwo_!!2185320355.jpg",
          },
          "hots": [
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "2.0",
                // "width": "60",
                // "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point1",
              "position": { "x": "-184.76", "y": "-356.11", "z": "488.22" },
              "rotation": { "x": "0.07", "y": "2.56", "z": "0" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "2",
                // "width": "100",
                // "height": "100",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point2",
              "position": { "x": "68.52", "y": "-350.78", "z": "468.18" },
              "rotation": { "x": "0.76", "y": "3.28", "z": "1.09" }
            },

            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01t2U7ZW1EUdN6TyBVg_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "450",
                "height": "61.36363636363636",
                "duration": "1.5"
              },
              "name": "floor7Name",
              "noClick": true,
              "position": { "x": "-260.78", "y": "-217.41", "z": "448.13" },
              "rotation": { "x": "0.33", "y": "-3.06", "z": "-0.37" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "110",
                "height": "231.09243697478993",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor7",
              "position": { "x": "-263.31", "y": "-64.89", "z": "418.07" },
              "rotation": { "x": "0.25", "y": "2.84", "z": "-0.29" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01FgFHTa1EUdNDsdo8s_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "scale": "1.5",
                "width": "400",
                "height": "54.5",
                "duration": "1.5"
              },
              "name": "floor5Name",
              "noClick": true,
              "position": { "x": "16.48", "y": "-139.53", "z": "350.41" },
              "rotation": { "x": "0.36", "y": "-2.67", "z": "-0.33" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "190.4",
                "height": "400.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor5",
              "position": { "x": "-47.89", "y": "-65.94", "z": "673.64" },
              "rotation": { "x": "-0.02", "y": "-3.35", "z": "-0.35" }
            },

          ]
        },
        {
          "name": "floor1_6",
          "rotateSceneDuration": "12",
          "toPosDuration": "1",
          "camera": {
            "fov": "65",
            "position": { "x": "20.986921471316407", "y": "-1.36572426088799", "z": "34.05999742219556" }
          },
          "cameraControls": {
            "enableZoom": true,
            "minCameraFov": "40",
            "maxCameraFov": "90",
            "rotateSpeed": "0.5",
            "minPolarAngle": "0",
            "maxPolarAngle": "3.141592653589793"
          },
          "backgrounds": {
            "left": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN012aU4Lm1EUdNFBZ164_!!2185320355.jpg",
            "right": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN015Xl8HU1EUdNAXv1OF_!!2185320355.jpg",
            "bottom": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01YvNYE41EUdN9qYUBh_!!2185320355.jpg",
            "front": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01vZe0ik1EUdN9jrBi4_!!2185320355.jpg",
            "back": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01sPHoCK1EUdN9qaA9a_!!2185320355.jpg",
            "top": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01VbJB4a1EUdNC6kvF3_!!2185320355.jpg",
          },
          "hots": [
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "1.0",
                // "width": "60",
                // "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point1",
              "position": { "x": "-513.98", "y": "31.02", "z": "-177.16" },
              "rotation": { "x": "0.07", "y": "1.09", "z": "0" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "1",
                // "width": "100",
                // "height": "100",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point2",
              "position": { "x": "129.92", "y": "-19.52", "z": "-595.25" },
              "rotation": { "x": "-0.09", "y": "0.12", "z": "1.09" }
            },

            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01RHAC3o1EUdN3QpPtt_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "450",
                "height": "61.36363636363636",
                "duration": "1.5"
              },
              "name": "floor6Name",
              "noClick": true,
              "position": { "x": "-417.88", "y": "-309.17", "z": "505.76" },
              "rotation": { "x": "0.33", "y": "2.44", "z": "-0.32" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "110",
                "height": "231.09243697478993",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor6",
              "position": { "x": "-334.26", "y": "-191.81", "z": "498.25" },
              "rotation": { "x": "0.25", "y": "2.17", "z": "1.36" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01GU9KRz1EUdMx2SCYI_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "scale": "1.5",
                "width": "400",
                "height": "54.5",
                "duration": "1.5"
              },
              "name": "floor8Name",
              "noClick": true,
              "position": { "x": "420.57", "y": "-303.83", "z": "-210.77" },
              "rotation": { "x": "-0.61", "y": "-1.09", "z": "-0.45" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "scale": "0.3",
                "width": "190.4",
                "height": "400.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor8",
              "position": { "x": "580.93", "y": "-221.68", "z": "-316.52" },
              "rotation": { "x": "-0.94", "y": "-1.02", "z": "-0.73" }
            },

          ]
        },
        {
          "name": "floor1_7",
          "rotateSceneDuration": "12",
          "toPosDuration": "1",
          "camera": {
            "fov": "75",
            "position": { "x": "-5.746283549612884", "y": "-1.7380587859157461", "z": "39.57725201456139" }
          },
          "cameraControls": {
            "enableZoom": true,
            "minCameraFov": "40",
            "maxCameraFov": "90",
            "rotateSpeed": "0.5",
            "minPolarAngle": "0",
            "maxPolarAngle": "3.141592653589793"
          },
          "backgrounds": {
            "right": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01puL5601EUdNAXzqxn_!!2185320355.jpg",
            "front": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01TDp35t1EUdN9juLNm_!!2185320355.jpg",
            "left": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01BaaXVq1EUdN9jtGsL_!!2185320355.jpg",
            "bottom": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01zkXdEw1EUdNAXzS0T_!!2185320355.jpg",
            "back": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01MoOzSq1EUdNBc5XQ8_!!2185320355.jpg",
            "top": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01wtIzKV1EUdNAXz359_!!2185320355.jpg",
          },
          "hots": [
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "1.0",
                // "width": "60",
                // "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point1",
              "position": { "x": "-374.84", "y": "-3.09", "z": "-341.86" },
              "rotation": { "x": "0.07", "y": "0.55", "z": "0" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "1",
                // "width": "100",
                // "height": "100",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point2",
              "position": { "x": "108.17", "y": "20.59", "z": "-268.38" },
              "rotation": { "x": "-0.09", "y": "-0.31", "z": "1.09" }
            },

            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01t2U7ZW1EUdN6TyBVg_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "450",
                "height": "61.36363636363636",
                "duration": "1.5"
              },
              "name": "floor7Name",
              "noClick": true,
              "position": { "x": "-585.12", "y": "-271.83", "z": "-92.99" },
              "rotation": { "x": "0.58", "y": "1.64", "z": "-0.24" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "110",
                "height": "231.09243697478993",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor7",
              "position": { "x": "-549.64", "y": "-121.39", "z": "-40.39" },
              "rotation": { "x": "0.25", "y": "1.86", "z": "0.03" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01BFbxok1EUdN6TvVDx_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "scale": "1.5",
                "width": "400",
                "height": "54.5",
                "duration": "1.5"
              },
              "name": "floor9Name",
              "noClick": true,
              "position": { "x": "400.53", "y": "-409.46", "z": "415.56" },
              "rotation": { "x": "-1.92", "y": "-0.71", "z": "-2.32" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "scale": "0.3",
                "width": "190.4",
                "height": "400.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor9",
              "position": { "x": "403.03", "y": "-237.68", "z": "455.65" },
              "rotation": { "x": "-0.01", "y": "-2.32", "z": "-0.12" }
            },

          ]
        },
        {
          "name": "floor1_8",
          "rotateSceneDuration": "12",
          "toPosDuration": "1",
          "camera": {
            "fov": "75",
            "position": { "x": "-29.46181871784057", "y": "-1.291242123158773", "z": "27.069049329750086" }
          },
          "cameraControls": {
            "enableZoom": true,
            "minCameraFov": "40",
            "maxCameraFov": "90",
            "rotateSpeed": "0.5",
            "minPolarAngle": "0",
            "maxPolarAngle": "3.141592653589793"
          },
          "backgrounds": {
            "front": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN015WTvmv1EUdNFBen7o_!!2185320355.jpg",
            "right": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01CPWmQ31EUdNDPOxaR_!!2185320355.jpg",
            "left": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01LSRywX1EUdN6guloD_!!2185320355.jpg",
            "bottom": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01D3oaH21EUdN7RfdbX_!!2185320355.jpg",
            "back": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01LakzkL1EUdNAY0atK_!!2185320355.jpg",
            "top": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01JB9M8g1EUdNC6sm7n_!!2185320355.jpg",
          },
          "hots": [
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "1.0",
                // "width": "60",
                // "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point1",
              "position": { "x": "292.79", "y": "57.11", "z": "-82.97" },
              "rotation": { "x": "0.07", "y": "-0.72", "z": "0" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "1",
                // "width": "100",
                // "height": "100",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point2",
              "position": { "x": "172.52", "y": "61.28", "z": "-192.36" },
              "rotation": { "x": "0.28", "y": "-1.07", "z": "-0.53" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "1",
                // "width": "100",
                // "height": "100",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point3",
              "position": { "x": "104.86", "y": "53.98", "z": "-311.45" },
              "rotation": { "x": "0.08", "y": "-1.07", "z": "-0.53" }
            },

            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01GU9KRz1EUdMx2SCYI_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "450",
                "height": "61.36363636363636",
                "duration": "1.5"
              },
              "name": "floor8Name",
              "noClick": true,
              "position": { "x": "-319.06", "y": "-271.83", "z": "-534.44" },
              "rotation": { "x": "-0.54", "y": "0.47", "z": "0.38" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "110",
                "height": "231.09243697478993",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor8",
              "position": { "x": "-281.05", "y": "-94.43", "z": "-417.88" },
              "rotation": { "x": "0.25", "y": "0.53", "z": "-0.06" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01aXm3pi1EUdN8r6QJr_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "scale": "1.5",
                "width": "400",
                "height": "54.5",
                "duration": "1.5"
              },
              "name": "floor10Name",
              "noClick": true,
              "position": { "x": "322.85", "y": "-312.37", "z": "475.69" },
              "rotation": { "x": "-1.92", "y": "-0.71", "z": "-2.23" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "scale": "0.3",
                "width": "190.4",
                "height": "400.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor10",
              "position": { "x": "375.47", "y": "-163.01", "z": "498.09" },
              "rotation": { "x": "-0.01", "y": "-2.32", "z": "0.11" }
            },

          ]
        },
        {
          "name": "floor1_9",
          "rotateSceneDuration": "12",
          "toPosDuration": "1",
          "camera": {
            "fov": "90",
            "position": { "x": "16.493539765797973", "y": "1.2421232112219938", "z": "-36.452980343480036" }
          },
          "cameraControls": {
            "enableZoom": true,
            "minCameraFov": "40",
            "maxCameraFov": "90",
            "rotateSpeed": "0.5",
            "minPolarAngle": "0",
            "maxPolarAngle": "3.141592653589793"
          },
          "backgrounds": {
            "left": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN018EloHa1EUdN9qgkGx_!!2185320355.jpg",
            "right": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01CwfQpu1EUdN5BZ73h_!!2185320355.jpg",
            "front": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN018lSn4v1EUdNAY4Hkr_!!2185320355.jpg",
            "bottom": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN0125cjcA1EUdN7RkCX2_!!2185320355.jpg",
            "back": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN0135loiM1EUdNFBgbay_!!2185320355.jpg",
            "top": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01HULMGz1EUdNC6sJDN_!!2185320355.jpg",
          },
          "hots": [
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "3.0",
                // "width": "60",
                // "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point1",
              "position": { "x": "533.32", "y": "-312.37", "z": "-572.45" },
              "rotation": { "x": "-0.54", "y": "-0.68", "z": "0" }
            },

            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01BFbxok1EUdN6TvVDx_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "450",
                "height": "61.36363636363636",
                "duration": "1.5"
              },
              "name": "floor9Name",
              "noClick": true,
              "position": { "x": "410.55", "y": "-309.17", "z": "227.64" },
              "rotation": { "x": "1.22", "y": "-2.36", "z": "1.03" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "110",
                "height": "231.09243697478993",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor9",
              "position": { "x": "328.72", "y": "-90.21", "z": "197.57" },
              "rotation": { "x": "-1.39", "y": "-1.09", "z": "-1.71" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01oohUu91EUdNFxmriN_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "scale": "1.5",
                "width": "400",
                "height": "54.5",
                "duration": "1.5"
              },
              "name": "floor11Name",
              "noClick": true,
              "position": { "x": "355.43", "y": "-173.67", "z": "-91" },
              "rotation": { "x": "-1.92", "y": "-1.17", "z": "-1.77" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "scale": "0.3",
                "width": "190.4",
                "height": "400.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor11",
              "position": { "x": "590.95", "y": "-111.79", "z": "-167.02" },
              "rotation": { "x": "-0.21", "y": "-1.29", "z": "-0.17" }
            },
          ]
        },
        {
          "name": "floor1_10",
          "rotateSceneDuration": "12",
          "toPosDuration": "1",
          "camera": {
            "fov": "90",
            "position": { "x": "26.588036401888743", "y": "-4.560563028152934", "z": "-29.574940154766477" }
          },
          "cameraControls": {
            "enableZoom": true,
            "minCameraFov": "40",
            "maxCameraFov": "90",
            "rotateSpeed": "0.5",
            "minPolarAngle": "0",
            "maxPolarAngle": "3.141592653589793"
          },
          "backgrounds": {
            "left": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN013ik2vK1EUdNH6Vjex_!!2185320355.jpg",
            "right": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01fKx1Ka1EUdNC6vSpw_!!2185320355.jpg",
            "front": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01192srb1EUdNGLF33C_!!2185320355.jpg",
            "bottom": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01CyPkmP1EUdN0Jpi9L_!!2185320355.jpg",
            "back": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01GzW4dx1EUdNC6vrmm_!!2185320355.jpg",
            "top": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01vsGMSl1EUdN9qjdC8_!!2185320355.jpg",
          },
          "hots": [
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "2.0",
                // "width": "60",
                // "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point1",
              "position": { "x": "220.12", "y": "-87.04", "z": "-587.65" },
              "rotation": { "x": "-0.32", "y": "-0.68", "z": "-0.74" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "2.0",
                // "width": "60",
                // "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point2",
              "position": { "x": "-260.78", "y": "-69.11", "z": "590.95" },
              "rotation": { "x": "-2.76", "y": "0.53", "z": "0" }
            },

            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01aXm3pi1EUdN8r6QJr_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "450",
                "height": "61.36363636363636",
                "duration": "1.5"
              },
              "name": "floor10Name",
              "noClick": true,
              "position": { "x": "-625.66", "y": "-264.36", "z": "-212.63" },
              "rotation": { "x": "-0.29", "y": "0.99", "z": "-0.33" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "110",
                "height": "231.09243697478993",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor10",
              "position": { "x": "-478.69", "y": "-90.21", "z": "-220.23" },
              "rotation": { "x": "0.04", "y": "1.15", "z": "-0.55" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01iL7OGl1EUdN8r92T9_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "scale": "1.5",
                "width": "400",
                "height": "54.5",
                "duration": "1.5"
              },
              "name": "floor12Name",
              "noClick": true,
              "position": { "x": "28.87", "y": "-169.34", "z": "-478.69" },
              "rotation": { "x": "-0.91", "y": "0.16", "z": "0.16" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "scale": "0.3",
                "width": "190.4",
                "height": "400.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor12",
              "position": { "x": "9.14", "y": "-45.89", "z": "-595.25" },
              "rotation": { "x": "-0.66", "y": "0.33", "z": "0.16" }
            },
          ]
        },
        {
          "name": "floor1_11",
          "rotateSceneDuration": "12",
          "toPosDuration": "1",
          "camera": {
            "fov": "90",
            "position": { "x": "39.612063267741874", "y": "5.694332922784335", "z": "0.9265615127136396" }
          },
          "cameraControls": {
            "enableZoom": true,
            "minCameraFov": "40",
            "maxCameraFov": "90",
            "rotateSpeed": "0.5",
            "minPolarAngle": "0",
            "maxPolarAngle": "3.141592653589793"
          },
          "backgrounds": {
            "left": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN011Pn9Qy1EUdNAYCsN5_!!2185320355.jpg",
            "right": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01ZO9uEo1EUdN6h4Ebm_!!2185320355.jpg",
            "bottom": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01rJTa6q1EUdNJCGK06_!!2185320355.jpg",
            "front": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01sNHY4B1EUdNAYC0IP_!!2185320355.jpg",
            "back": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01z19BS51EUdN7Rp2JB_!!2185320355.jpg",
            "top": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01eRVVHM1EUdN5Bfp8C_!!2185320355.jpg",
          },
          "hots": [
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "2.0",
                // "width": "60",
                // "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point1",
              "position": { "x": "-544.57", "y": "-345.44", "z": "-144.22" },
              "rotation": { "x": "-0.93", "y": "0.89", "z": "-0.68" }
            },

            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01oohUu91EUdNFxmriN_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "450",
                "height": "61.36363636363636",
                "duration": "1.5"
              },
              "name": "floor11Name",
              "noClick": true,
              "position": { "x": "285.27", "y": "-321.97", "z": "322.85" },
              "rotation": { "x": "0.62", "y": "-2.23", "z": "0.46" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "110",
                "height": "231.09243697478993",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor11",
              "position": { "x": "305.31", "y": "-201.41", "z": "236.92" },
              "rotation": { "x": "1.11", "y": "-2.71", "z": "2.32" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01jFfZ8J1EUdNBvyPQJ_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "scale": "1.5",
                "width": "400",
                "height": "54.5",
                "duration": "1.5"
              },
              "name": "floor13Name",
              "noClick": true,
              "position": { "x": "367.95", "y": "-200.34", "z": "488.22" },
              "rotation": { "x": "0.57", "y": "-2.48", "z": "0.29" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "scale": "0.2",
                "width": "190.4",
                "height": "400.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor13",
              "position": { "x": "265.22", "y": "-40.93", "z": "362.94" },
              "rotation": { "x": "1.05", "y": "-2.45", "z": "0.55" }
            },
          ]
        },
        {
          "name": "floor1_12",
          "rotateSceneDuration": "12",
          "toPosDuration": "1",
          "camera": {
            "fov": "82",
            "position": { "x": "32.645764248298086", "y": "2.2100000000001523", "z": "-23.06012742038731" }
          },
          "cameraControls": {
            "enableZoom": true,
            "minCameraFov": "40",
            "maxCameraFov": "90",
            "rotateSpeed": "0.5",
            "minPolarAngle": "0",
            "maxPolarAngle": "3.141592653589793"
          },
          "backgrounds": {
            "right": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN0153HU4C1EUdNGLLDvT_!!2185320355.jpg",
            "left": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01QQO4bA1EUdN7Rrin9_!!2185320355.jpg",
            "back": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01evgurU1EUdN0Jsw4x_!!2185320355.jpg",
            "front": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN015TYFHc1EUdNDPb2kS_!!2185320355.jpg",
            "bottom": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01KCn6801EUdN0JuTh5_!!2185320355.jpg",
            "top": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01zpjSH21EUdNBcJQym_!!2185320355.jpg",
          },
          "hots": [
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "1.2",
                // "width": "60",
                // "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point1",
              "position": { "x": "-580.05", "y": "20.59", "z": "-159.42" },
              "rotation": { "x": "0.35", "y": "1.61", "z": "1.48" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "2.6",
                // "width": "60",
                // "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point2",
              "position": { "x": "-567.38", "y": "20.59", "z": "335.38" },
              "rotation": { "x": "0.08", "y": "2.42", "z": "1.48" }
            },

            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01iL7OGl1EUdN8r92T9_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "450",
                "height": "61.36363636363636",
                "duration": "1.5"
              },
              "name": "floor12Name",
              "noClick": true,
              "position": { "x": "-336.79", "y": "-299.57", "z": "-577.51" },
              "rotation": { "x": "-0.44", "y": "-0.27", "z": "0.17" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "110",
                "height": "231.09243697478993",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor12",
              "position": { "x": "-245.57", "y": "-76.49", "z": "-422.95" },
              "rotation": { "x": "-0.83", "y": "0.52", "z": "0.37" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01b2V2Hg1EUdN4BtoeE_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "scale": "1.5",
                "width": "400",
                "height": "54.5",
                "duration": "1.5"
              },
              "name": "floor14Name",
              "noClick": true,
              "position": { "x": "428.09", "y": "-271.83", "z": "-415.34" },
              "rotation": { "x": "2.53", "y": "3.49", "z": "-3.76" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "scale": "0.2",
                "width": "190.4",
                "height": "400.0",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor14",
              "position": { "x": "325.32", "y": "-77.55", "z": "-258.24" },
              "rotation": { "x": "-0.21", "y": "-0.67", "z": "-0.43" }
            },
          ]
        },
        {
          "name": "floor1_13",
          "rotateSceneDuration": "12",
          "toPosDuration": "1",
          "camera": {
            "fov": "70",
            "position": { "x": "-0.26487098247423563", "y": "-1.4402016651970142", "z": "40.00318940442599" }
          },
          "cameraControls": {
            "enableZoom": true,
            "minCameraFov": "40",
            "maxCameraFov": "90",
            "rotateSpeed": "0.5",
            "minPolarAngle": "0",
            "maxPolarAngle": "3.141592653589793"
          },
          "backgrounds": {
            "right": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01tl8FKA1EUdNH6eGJM_!!2185320355.jpg",
            "left": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01WjtpyQ1EUdN0JxIVi_!!2185320355.jpg",
            "front": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01gsJcjL1EUdNINQUgK_!!2185320355.jpg",
            "bottom": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01rKboBp1EUdNAYHZmg_!!2185320355.jpg",
            "top": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01m2cfzJ1EUdNAYFIOV_!!2185320355.jpg",
            "back": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01pN6LGC1EUdN7RvkQ3_!!2185320355.jpg",
          },
          "hots": [
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "1.8",
                // "width": "60",
                // "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point1",
              "position": { "x": "533.32", "y": "18.48", "z": "-511.63" },
              "rotation": { "x": "-0.18", "y": "-0.31", "z": "-0.86" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O8RjtI1EUdNDt9IB0_!!2185320355.png",
                "width": "50",
                "height": "3800",
                "fWidth": "50",
                "fHeight": "50",
                "count": "76",
                // "count2": "76",//点击之后使用此值
                // "loop2": false,//点击之后使用此值
              },
              "frame": {
                // "loop": false,
                "scale": "2.0",
                // "width": "60",
                // "height": "60",
                "duration": "1.5",
                // "delayTime": "1.5"
              },
              "name": "point2",
              "position": { "x": "-564.85", "y": "20.59", "z": "-592.72" },
              "rotation": { "x": "0.09", "y": "0.53", "z": "1.48" }
            },

            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01jFfZ8J1EUdNBvyPQJ_!!2185320355.png",
                "width": "220",
                "height": "30",
                "fWidth": "220",
                "fHeight": "30",
                "count": "1"
              },
              "frame": {
                "width": "450",
                "height": "61.36363636363636",
                "duration": "1.5"
              },
              "name": "floor13Name",
              "noClick": true,
              "position": { "x": "-592.72", "y": "-340.11", "z": "-199.96" },
              "rotation": { "x": "-0.24", "y": "0.78", "z": "0.16" }
            },
            {
              "img": {
                "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN014ndfKH1EUdN5Dokh0_!!2185320355.png",
                "width": "4760",
                "height": "3000",
                "fWidth": "476",
                "fHeight": "1000",
                "count": "1",
                "count2": "30",//点击之后使用此值
                "loop2": false,//点击之后使用此值
              },
              "frame": {
                "width": "110",
                "height": "231.09243697478993",
                "duration": "1.0",
                "delayTime": "1.0"
              },
              "name": "floor13",
              "position": { "x": "-592.72", "y": "-204.61", "z": "-123.94" },
              "rotation": { "x": "-0.83", "y": "1.06", "z": "2.17" }
            }
          ]
        },
      ],
    }
  },

  //跳转到指定场景,下标为scenes对应数组下标
  renderScene(idx) {
    this.vrComponent.renderScene(idx || 0);
  },
  onRef(ref) {
    this.vrComponent = ref;
  },
  onInitDone() {
    // 组件初始化完成
    this.renderScene(0);
  },
  onSceneRenderDone(idx) {
    // 场景初始化完成（渲染成功回调）
    console.log("场景渲染完成，下标为：", idx)
  },
  onEvent(names) {
    console.log(names)
    console.log("点击到了热点：", names[0])
  }
})

```

- xaml

```
  <view class="box1">
    <vr gameSource="{{gameSource}}" onRef="onRef" onInitDone="onInitDone" onSceneRenderDone="onSceneRenderDone" onEvent="onEvent" />
  </view>
```

-acss

```
.box1{
  position:absolute;
  width: 100vw;
  height: 100vh;
}
```