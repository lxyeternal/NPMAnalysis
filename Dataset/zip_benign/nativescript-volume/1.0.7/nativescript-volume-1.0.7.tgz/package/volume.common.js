"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var observable_1 = require("tns-core-modules/data/observable");
var Common = (function (_super) {
    __extends(Common, _super);
    function Common() {
        return _super.call(this) || this;
    }
    Common.prototype.getVolume = function () { return null; };
    Common.prototype.mute = function () { };
    Common.prototype.setVolume = function (value) { };
    Common.prototype.unmute = function () { };
    Common.prototype.volumeDown = function () { };
    Common.prototype.volumeUp = function () { };
    return Common;
}(observable_1.Observable));
exports.Common = Common;
//# sourceMappingURL=volume.common.js.map