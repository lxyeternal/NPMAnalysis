"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var volume_common_1 = require("./volume.common");
var Volume = (function (_super) {
    __extends(Volume, _super);
    function Volume() {
        return _super.call(this) || this;
    }
    Volume.prototype.mute = function () {
        LxVolumeManager.mute();
    };
    Volume.prototype.unmute = function () {
        LxVolumeManager.unmute();
    };
    Volume.prototype.volumeDown = function () {
        this.setVolume(LxVolumeManager.currentVolume() - (1 / 16));
    };
    Volume.prototype.volumeUp = function () {
        this.setVolume(LxVolumeManager.currentVolume() + (1 / 16));
    };
    Volume.prototype.getVolume = function () {
        return LxVolumeManager.currentVolume();
    };
    Volume.prototype.setVolume = function (value) {
        LxVolumeManager.setVolume(value);
    };
    return Volume;
}(volume_common_1.Common));
exports.Volume = Volume;
//# sourceMappingURL=volume.ios.js.map