import { Common } from './volume.common';
export declare class Volume extends Common {
    private _audioManager;
    AudioManager: typeof android.media.AudioManager;
    constructor();
    mute(): void;
    unmute(): void;
    volumeDown(): void;
    volumeUp(): void;
    getVolume(): number;
    setVolume(value: number): void;
}
