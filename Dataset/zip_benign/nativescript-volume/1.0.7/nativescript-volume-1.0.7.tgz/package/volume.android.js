"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var app = require("tns-core-modules/application");
var volume_common_1 = require("./volume.common");
var Volume = (function (_super) {
    __extends(Volume, _super);
    function Volume() {
        var _this = _super.call(this) || this;
        _this.AudioManager = android.media.AudioManager;
        _this._audioManager = app.android.context.getSystemService(android.content.Context.AUDIO_SERVICE);
        return _this;
    }
    Volume.prototype.mute = function () {
        this._audioManager.adjustVolume(-100, this.AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE & this.AudioManager.FLAG_SHOW_UI);
    };
    Volume.prototype.unmute = function () {
        this._audioManager.adjustVolume(100, this.AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE & this.AudioManager.FLAG_SHOW_UI);
    };
    Volume.prototype.volumeDown = function () {
        this._audioManager.adjustVolume(this.AudioManager.ADJUST_LOWER, this.AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE & this.AudioManager.FLAG_SHOW_UI);
    };
    Volume.prototype.volumeUp = function () {
        this._audioManager.adjustVolume(this.AudioManager.ADJUST_RAISE, this.AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE & this.AudioManager.FLAG_SHOW_UI);
    };
    Volume.prototype.getVolume = function () {
        return this._audioManager.getStreamVolume(this.AudioManager.STREAM_MUSIC);
    };
    Volume.prototype.setVolume = function (value) {
        this._audioManager.setStreamVolume(this.AudioManager.STREAM_MUSIC, value, this.AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE & this.AudioManager.FLAG_SHOW_UI);
    };
    return Volume;
}(volume_common_1.Common));
exports.Volume = Volume;
//# sourceMappingURL=volume.android.js.map