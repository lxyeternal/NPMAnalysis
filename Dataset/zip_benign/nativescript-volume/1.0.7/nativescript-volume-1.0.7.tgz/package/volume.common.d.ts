import { Observable } from 'tns-core-modules/data/observable';
export declare class Common extends Observable {
    constructor();
    getVolume(): number;
    mute(): void;
    setVolume(value: number): void;
    unmute(): void;
    volumeDown(): void;
    volumeUp(): void;
}
