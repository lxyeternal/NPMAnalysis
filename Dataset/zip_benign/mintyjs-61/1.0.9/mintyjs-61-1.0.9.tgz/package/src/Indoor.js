import fabric from 'pure-61';

import packageInfo from '../package.json';

console.log('fabricJS ', fabric.version || window.fabric.version);
console.log('IndoorJS ', packageInfo.version);

const version = packageInfo.version;

export { version };
export {fabric};

// constants
export * from './core/index';

// geometry
export * from './geometry/index';

// map
export * from './map/index';

// floorplan
export * from './floorplan/index';

// layer
export * from './layer/index';

// Free Drawing Canvas
export * from './paint/index';
