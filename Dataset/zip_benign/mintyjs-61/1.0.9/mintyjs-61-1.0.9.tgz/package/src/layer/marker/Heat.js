import { Layer } from '../Layer';
import { Group } from '../Group';
import { Point } from '../../geometry/Point';
import { Connector } from '../Connector';

export class Heat extends Layer {
  constructor(position, options) {
    options = options || {};
    options.zIndex = options.zIndex || 100;
    options.keepOnZoom = options.keepOnZoom === undefined ? true : options.keepOnZoom;
    options.position = new Point(position);
    options.rotation = options.rotation || 0;
    options.yaw = options.yaw || 0;
    options.clickable = options.clickable !== undefined ? options.clickable : true;
    options.class = 'marker';
    super(options);

    const vm = this;

    this.text = this.text || '';
    this.size = this.size || 10;
    this.textColor = this.textColor || 'black';
    this.fill = this.fill || 'white';
    this.stroke = this.stroke || 'red';

    Object.assign(this.style, {
      left: this.position.x,
      top: this.position.y,
      // selectionBackgroundColor: false,
      angle: this.rotation,
      yaw: this.yaw,
      clickable: this.clickable
    });


      this.circle = new fabric.Circle({radius: 200})
  
      this.shape = this.circle
     
     
    
  }

}

export const heat = (position, options) => new Heat(position, options);
