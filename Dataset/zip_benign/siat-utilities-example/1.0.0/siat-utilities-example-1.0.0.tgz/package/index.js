
const { SiatValidations } = require("./src/siatValidations")

module.exports = { SiatValidations }