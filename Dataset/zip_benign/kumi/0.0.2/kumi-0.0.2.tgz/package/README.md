# Kumi

## Summary

Kumi takes style values described in a YAML document and translates them into platform-specific code.

Here's an example.

Using this command:

`kumi --company "Prolific Interactive" --project "Test Project" --swift ./ styles.yaml`

We can take this file:

```
meta:
  version: 0.1

definitions:
  colors:
    caribbeanGreen:
      red: 0.5
      green: 0.5
      blue: 0.5
      alpha: 0.5
    razzmatazz:
      red: 0.5
      green: 0.5
      blue: 0.5
      alpha: 0.5
    monza:
      red: 0.5
      green: 0.5
      blue: 0.5
      alpha: 0.5
    pirateGold:
      red: 0.5
      green: 0.5
      blue: 0.5
      alpha: 0.5
```

...and generate this Swift file:

```
//
//  Colors.swift
//  Test Project
//
//  Generated on 4/12/17.
//  Copyright © 2017 Prolific Interactive. All rights reserved.
//

import UIKit

internal struct TestProjectColors {

    // MARK: - Color Palette

    static let caribbeanGreen = UIColor(red: 0.5, green: 0.5, blue: 0.5, alpha: 0.5)

    static let razzmatazz = UIColor(red: 0.5, green: 0.5, blue: 0.5, alpha: 0.5)

    static let monza = UIColor(red: 0.5, green: 0.5, blue: 0.5, alpha: 0.5)

    static let pirateGold = UIColor(red: 0.5, green: 0.5, blue: 0.5, alpha: 0.5)


}
```
