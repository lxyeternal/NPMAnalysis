<%=boilerplate%>
import UIKit

internal struct <%=pascalCase(project)%>Colors {

    // MARK: - Color Palette
    <% each(colors, (c, name) => { %>
    static let <%=name%> = UIColor(red: <%=c.red%>, green: <%=c.green%>, blue: <%=c.blue%>, alpha: <%=c.alpha%>)
    <% }) %>

}
