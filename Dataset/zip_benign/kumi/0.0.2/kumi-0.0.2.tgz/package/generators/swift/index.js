'use strict';

const path = require('path');
const bluebird = require('bluebird');
const fs = bluebird.promisifyAll(require('fs'));
const _ = require('lodash');
const helpers = require('../../lib/helpers');
const moment = require('moment');
const abs = path.resolve.bind(path, __dirname);

module.exports = ({ styles, config }) => {
  const projectPascal = helpers.pascalCase(config.project);
  const time = moment();
  const globalInputs = Object.assign({}, _, helpers, config, { time });

  const generateAll = () => bluebird.props({
    [`Theme/${projectPascal}Colors.swift`]: generateColorFile()
  });

  const render = (tpl, _inputs={}) => {
    return mixInputs(_inputs).then(inputs => {
      return fs
        .readFileAsync(abs(tpl), 'utf8')
        .then(raw => _.template(raw)(inputs));
    });
  };

  const mixInputs = _inputs => {
    const inputs = Object.assign({}, globalInputs, _inputs);

    return getBoilerplate(inputs).then(boilerplate => {
      return Object.assign({}, inputs, { boilerplate });
    });
  };

  const getBoilerplate = (() => {
    const loaded = fs
      .readFileAsync(abs('Boilerplate.tpl'), 'utf8')
      .then(_.template);

    return inputs => loaded.then(compiled => {
      return compiled(inputs);
    });
  })();

  const generateColorFile = () => {
    return render('Colors.swift.tpl', {
      filename: 'Colors.swift',
      colors: styles.definitions.colors
    });
  };

  return generateAll();
};
