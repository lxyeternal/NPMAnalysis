#!/usr/bin/env node

'use strict';

const path = require('path');
const bluebird = require('bluebird');
const fs = bluebird.promisifyAll(require('fs-extra'));
const refParser = require('json-schema-ref-parser');
const yaml = require('js-yaml');
const program = require('commander');
const generateSwiftFiles = require('./generators/swift');

program
  .version('0.0.1')
  .usage('<filename>')
  .option('--company <company>', 'Sets the company name. Used within generated files.')
  .option('--project <project>', 'Sets the project name. Used within generated files.')
  .option('--swift <swiftDir>', 'Generates Swift files to target directory.')
  .option('--json <jsonDest>', 'Generates JSON file to target file.')
  .parse(process.argv);

const { args: [filename], swift, json, company, project } = program;
const absPath = path.resolve.bind(path, process.cwd());

const config = {
  company: company || 'Untitled Company',
  project: project || 'Untitled Project'
};

const saveTo = (dest, dict) => {
  return bluebird.map(Object.keys(dict), pathname => {
    const fullPath = absPath(dest, pathname);
    const { dir } = path.parse(fullPath);
    const contents = dict[pathname];

    return fs
      .mkdirpAsync(dir)
      .then(() => {
        return fs.writeFileAsync(fullPath, contents);
      });
  });
};

fs
  .readFileAsync(absPath(filename), 'utf8')
  .then(yaml.safeLoad)
  .then(styles => {
    return refParser.dereference(styles).then(flattenedStyles => ({
      styles,
      flattenedStyles
    }));
  })
  .then(({ styles, flattenedStyles }) => {
    const context = { styles, flattenedStyles, config };
    let promises = [];

    if (json) {
      const str = JSON.stringify(flattenedStyles, null, 2);
      const promise = fs.writeFileAsync(absPath(json), str);
      promises.push(promise);
    }

    if (swift) {
      const promise = generateSwiftFiles(context).then(files => saveTo(swift, files));
      promises.push(promise);
    }

    return bluebird.all(promises);
  })
  .done();
