require( "coffee-script/register" )
module.exports = require( "../src/tasks/dust" )