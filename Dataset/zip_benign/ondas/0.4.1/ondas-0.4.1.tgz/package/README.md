# Ondas

> `ondas` is a collection of web audio instruments ready to be used with no setup.

Example:

```js
import { SplendidGrandPiano, Soundfont } from "ondas";

const context = new AudioContext();
const piano = new SplendidGrandPiano(context);
piano.start({ note: "C4" });

const marimba = new Soundfont(context, { instrument: "marimba" });
marimba.start({ note: 60, velocity: 80 });
```

See demo: https://danigb.github.io/samples/

Install with npm or your favourite package manager:

```
npm i ondas
```

## Documentation

### Create an instrument

All instruments follows the same pattern: `new Instrument(context, options)`. For example:

```js
import { SplendidGrandPiano, Soundfont } from "ondas";

const piano = new SplendidGrandPiano(context, { decayTime: 0.5 });

const marimba = new Soundfont(context, { instrument: "marimba" });
```

### Wait for audio loading

You can start playing notes as soon as one audio is loaded. But if you want to wait for all of them, you can use `loaded()` function that returns a promise:

```js
piano.loaded().then(() => {
  // now the piano is fully loaded
});
```

Since the promise returns the instrument instance, you can create and wait in a single line:

```js
const piano = await new SplendidGrandPiano(context).loaded();
```

### Start and stop notes

The `start` function accepts a bunch of options:

```js
piano.start({ note: "C4", velocity: 80, time: 5, duration: 1 });
```

The `velocity` is a number between 0 and 128 the represents at which velocity the key is pressed. The bigger the number, louder the sound. But `velocity` not only controls the loudness. In some instruments, it also affects the timbre.

The `start` function returns a `stop` function for the given note:

```js
const stopNote = piano.start({ note: 60 });
stopNote({ time: 10 });
```

Bear in mind that you may need to call [`context.resume()` before playing a note](https://developer.mozilla.org/en-US/docs/Web/API/Web_Audio_API/Best_practices#autoplay_policy)

### Schedule notes

You can schedule notes using `time` and `duration` properties:

```js
const now = context.currentTime;
[60, 62, 64, 65, 67].forEach((midi, i) => {
  piano.start({ midi, time: now + i, duration: 0.5 });
});
```

### Stop all notes

Instruments have a global `stop` function that stops all notes:

```js
button.onclick = () => piano.stop();
```

### Change volume

`setVolume` uses a scale where 0 means no volume, and 128 is max volume without amplification:

```js
piano.setVolume(80);
```

Bear in mind that `volume` is global to the instrument, but `velocity` is specific for each note.

### Add effects

Use `output.addSend(name, effect, mix)` to create connect an effect using a send bus:

```js
import { DattorroReverb, SplendidGrandPiano } from "ondas";
const reverb = new DatorroReverb(context);
const piano = new SplendidGrandPiano(context, { volume });
piano.output.addSend("reverb", reverb, 0.2);
```

### Change effects send

Use `output.setSend(name, mix)` to change the mix level:

```js
piano.output.setSend("reverb", 0.5);
```

## Instruments

### Sampler

An audio buffer sampler.

```js
import { Sampler } from "ondas";

const samples = {
  kick: "https://danigb.github.io/samples/drum-machines/808-mini/kick.m4a",
  snare: "https://danigb.github.io/samples/drum-machines/808-mini/snare-1.m4a",
};
const sampler = new Sampler(new AudioContext(), { samples });
sampler.start({ note: "kick" });
```

### Soundfont

A Soundfont player.

```js
import { Soundfont } from "ondas";

const marimba = new Soundfont(new AudioContext(), "marimba");
marimba.start({ note: "C4" });
```

### Piano

A sampled acoustic piano. It uses Steinway samples with 4 velocity layers from
[SplendidGrandPiano](https://github.com/sfzinstruments/SplendidGrandPiano)

```js
import { SplendidGrandPiano } from "ondas";

const piano = new SplendidGrandPiano(new AudioContext());

piano.start({ note: "C4" });
```

## Effects

### Dattorro Reverb

An algorithmic reverb. It uses a modified version of [DatorroReverbNode](https://github.com/khoin/DattorroReverbNode).

```js
import { DattorroReverb } from "ondas";

const reverb = new DattorroReverb(new AudioContext());
const oscillator = context.createOscillator();
oscillator.connect(reverb);
```
