# Installation
> `npm install --save-dev @ryancavanaugh/jquery.ui.datetimepicker`

# Summary
This package contains type definitions for jQuery UI DateTimePicker 0.3.

The project URL or description is http://trentrichardson.com/examples/timepicker/

# Credits

These definitions were written by dougajmcdonald <https://github.com/dougajmcdonald>.

# Details
Typings were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped in the jquery.ui.datetimepicker directory.

Additional Details
 * Last updated: Tue, 17 May 2016 00:18:23 GMT
 * Typings kind: Global
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: none
