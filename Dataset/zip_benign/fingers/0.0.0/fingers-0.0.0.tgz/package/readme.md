[![Size](http://img.shields.io/badge/size-0.4%20kB-blue.svg)](https://raw2.github.com/ngryman/jquery.finger/master/dist/jquery.finger.min.js)
