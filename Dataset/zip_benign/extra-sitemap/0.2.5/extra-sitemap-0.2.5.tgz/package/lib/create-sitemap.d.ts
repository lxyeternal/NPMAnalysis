import { IURLItem } from './types';
export declare function createSitemap(urlItems: Iterable<IURLItem>): Iterable<string>;
