import { IURLItem } from './types';
export declare function createSitemapAsync(urlItems: AsyncIterable<IURLItem>): AsyncIterable<string>;
