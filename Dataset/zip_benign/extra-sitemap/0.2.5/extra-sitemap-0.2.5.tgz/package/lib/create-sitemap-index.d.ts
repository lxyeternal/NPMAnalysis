import { ISitemapItem } from './types';
export declare function createSitemapIndex(sitemapItems: Iterable<ISitemapItem>): Iterable<string>;
