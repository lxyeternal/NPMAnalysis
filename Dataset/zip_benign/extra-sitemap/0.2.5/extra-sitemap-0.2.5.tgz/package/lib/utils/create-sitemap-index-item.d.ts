import { ISitemapItem } from '../types';
export declare function createSitemapIndexItem(sitemapItem: ISitemapItem): string;
