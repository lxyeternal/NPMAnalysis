import { Falsy } from '@blackglory/prelude';
export declare function xml(strings: TemplateStringsArray, ...values: Array<string | Falsy>): string;
