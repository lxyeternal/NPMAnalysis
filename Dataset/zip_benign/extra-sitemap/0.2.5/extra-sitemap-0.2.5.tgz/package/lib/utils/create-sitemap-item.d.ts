import { IURLItem } from '../types';
export declare function createSitemapItem(urlItem: IURLItem): string;
