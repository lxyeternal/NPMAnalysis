export declare function addIndents(indent: string, text: string): string;
