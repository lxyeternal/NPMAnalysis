import { ISitemapItem } from './types';
export declare function createSitemapIndexAsync(sitemapItems: AsyncIterable<ISitemapItem>): AsyncIterable<string>;
