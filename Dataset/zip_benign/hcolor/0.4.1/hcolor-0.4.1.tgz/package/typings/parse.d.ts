import { RGB, RGBA } from "./RGB";
import { HSL, HSLA } from "./HSL";
export declare function parse(str: string, preferRGB?: boolean): RGB | RGBA | HSL | HSLA;
