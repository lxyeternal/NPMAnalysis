import { Vector } from "./Vector";
import { RGB } from "./RGB";
export declare class HSL extends Vector {
    constructor(h?: number, s?: number, l?: number);
    static fromHEX(hex: string, round?: boolean): HSL;
    static pattern: RegExp;
    static fromString(hsl: string): HSL;
    h: number;
    s: number;
    l: number;
    toString(round?: boolean): string;
    toHSL(round?: boolean): HSL;
    toHSLA(alpha?: number): HSLA;
    toHEX(upperCase?: boolean): string;
    toRGB(round?: boolean): RGB;
    toRGBA(alpha?: number, round?: boolean): import("./RGB").RGBA;
}
export declare class HSLA extends HSL {
    constructor(h?: number, s?: number, l?: number, a?: number);
    static fromHEX(hex: string, alpha?: number, round?: boolean): HSLA;
    static pattern: RegExp;
    static fromString(hsla: string): HSLA;
    a: number;
    toString(round?: boolean): string;
    toRGBA(round?: boolean): import("./RGB").RGBA;
}
