export declare class Vector {
    components: [number, number, number, number];
    constructor(components?: [number, number, number, number]);
    toArray(Constructor?: ArrayConstructor): [number, number, number, number][];
    toString(): string;
}
