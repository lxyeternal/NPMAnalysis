import { Vector } from "./Vector";
import { HSL } from "./HSL";
export declare class RGB extends Vector {
    constructor(r?: number, g?: number, b?: number);
    static fromHEX(hex: string): RGB;
    static pattern: RegExp;
    static fromString(rgb: string): RGB;
    r: number;
    g: number;
    b: number;
    toString(round?: boolean): string;
    toRGB(round?: boolean): RGB;
    toRGBA(alpha?: number): RGBA;
    toHEX(upperCase?: boolean): string;
    toHSL(round?: boolean): HSL;
    toHSLA(alpha?: number, round?: boolean): import("./HSL").HSLA;
}
export declare class RGBA extends RGB {
    constructor(r?: number, g?: number, b?: number, a?: number);
    static fromHEX(hex: string, alpha?: number): RGBA;
    static pattern: RegExp;
    static fromString(rgba: string): RGBA;
    a: number;
    toString(round?: boolean): string;
    toHSLA(round?: boolean): import("./HSL").HSLA;
}
