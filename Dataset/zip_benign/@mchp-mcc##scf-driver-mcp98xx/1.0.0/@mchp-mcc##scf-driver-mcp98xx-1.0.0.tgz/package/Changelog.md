# Changelog
All notable changes to this project will be documented in this file.

## [1.0.0] - 2022-10-27

### New Features
- **CC8SCRIP-9822** :- MCP98xx Initial Release
