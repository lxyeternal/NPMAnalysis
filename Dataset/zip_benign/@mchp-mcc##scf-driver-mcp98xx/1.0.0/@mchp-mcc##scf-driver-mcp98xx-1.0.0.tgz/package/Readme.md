# I2C Temp Sensor MCP98xx

## Overview
The I2C Temp Sensor MCP98xx Driver enables interfacing between the MCU and the MCP98xx Temperature Sensor family using the I2C protocol.

## Features
* Currently supports the following device/s:
    * MCP9808
* Converts temperatures between -40°C and +125°C to a digital word with ±0.0625°C to ±0.5°C accuracy
* Allows user-selectable Client Address
    * This provides a selection of assignable I2C client addresses for the sensor. The client address depends on the sensor's pin termination
* Allows user-selectable setting such as Shutdown or Low-Power modes and the specification of temperature Alert window limits and critical output limits
* Allows user-configurable Alert output signal polarity that can be set as an active-low or active-high comparator output, or as a temperature Alert interrupt output

## Related Documentation
* For more detailed information, refer to the device datasheet at https://ww1.microchip.com/downloads/aemDocuments/documents/OTH/ProductDocuments/DataSheets/MCP9808-0.5C-Maximum-Accuracy-Digital-Temperature-Sensor-Data-Sheet-DS20005095B.pdf

# Changelog
All notable changes to this project will be documented in this file.

## [1.0.0] - 2022-10-27

### New Features
- **CC8SCRIP-9822** :- MCP98xx Initial Release
