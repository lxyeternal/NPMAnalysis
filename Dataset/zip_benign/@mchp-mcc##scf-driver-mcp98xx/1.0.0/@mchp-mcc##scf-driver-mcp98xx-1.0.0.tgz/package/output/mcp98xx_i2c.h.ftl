/**
 * ${device} Generated Driver I2C Interface API Header File.
 * 
 * @file ${deviceNameLowerCase}_i2c.h
 * 
 * @defgroup ${deviceNameLowerCase}_i2c ${device}_I2C
 * 
 * @brief This contains the API prototypes for the ${device} I2C Protocol
 * 
 * To ensure that the C driver runs properly, it is not advised to modify the I2C API prototypes. Refer to ${deviceNameLowerCase}_i2c.c to configure the I2C interface implementation.
 * 
 * @version MCP98xx Driver Version 1.0.0
 */
 ${disclaimer}

 #ifndef ${device}_I2C_H
 #define ${device}_I2C_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/**  
 * @name ${device} I2C Status Codes
 * Macros for the I2C status codes.
 */
///@{
#define ${componentNameUpperCase}_I2C_NO_ERROR          (0U)
#define ${componentNameUpperCase}_I2C_ERROR             (1U)
#define ${componentNameUpperCase}_INVALID_I2C_PARAMETER (2U)
///@}

/**
 * @ingroup ${deviceNameLowerCase}_i2c
 * @brief Writes data to the ${device} Temperature Sensor using the I2C protocol.
 * @param uint16_t address  - 7-bit/10-bit Client address.
 * @param uint8_t *data     - Pointer to source data buffer that contains the data to be transmitted.
 * @param size_t dataLength - Length of data buffer in number of bytes. Also the number of bytes to be written.
 * @return ${componentName} I2C status code.
 */
uint8_t ${componentName}_Write(uint16_t address, uint8_t *data, size_t dataLength);

/**
 * @ingroup ${deviceNameLowerCase}_i2c
 * @brief Writes the register address pointer from the registerAddress to the bus and reads data from the ${device} Temperature Sensor using
 *        the I2C protocol, and then stores the received data in the readData.
 * @param  uint16_t address    - 7-bit/10-bit Client address.
 * @param uint8_t *registerAddress  - Pointer to write data buffer.
 * @param  size_t addressLength  - Write data length in bytes.
 * @param  uint8_t *readData   - Pointer to read data buffer.
 * @param  size_t readLength   - Read data length in bytes.
 * @return ${componentName} I2C status code.
 */
uint8_t ${componentName}_Read(uint16_t address, uint8_t *registerAddress, size_t addressLength, uint8_t *readData, size_t readLength);

#endif /* ${device}_I2C_H */
