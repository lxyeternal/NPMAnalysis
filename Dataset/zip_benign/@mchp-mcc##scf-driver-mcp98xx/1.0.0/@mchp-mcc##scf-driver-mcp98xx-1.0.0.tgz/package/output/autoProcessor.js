var autoProcessor =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./generated_module/src/autoProcessor.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./generated_module/src/Utils.ts":
/*!***************************************!*\
  !*** ./generated_module/src/Utils.ts ***!
  \***************************************/
/*! exports provided: getKeys, values, forEach, map, assertNotNull, toDictionary */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getKeys", function() { return getKeys; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "values", function() { return values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "forEach", function() { return forEach; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "map", function() { return map; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "assertNotNull", function() { return assertNotNull; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toDictionary", function() { return toDictionary; });
/** @returns the non-prototype keys of the given object */
var getKeys = function getKeys(obj) {
  /* eslint-disable-line */
  return Object.getOwnPropertyNames(obj);
};
var values = function values(obj) {
  return getKeys(obj).map(function (key) {
    return obj[key];
  });
};
var forEach = function forEach(obj, action) {
  getKeys(obj).forEach(function (key) {
    return action(key, obj[key]);
  });
};
var map = function map(obj, mapper) {
  return getKeys(obj).map(function (key) {
    return mapper(key, obj[key]);
  });
};
var assertNotNull = function assertNotNull(val, msg) {
  if (val == null) {
    throw new Error(msg);
  }
};
var toDictionary = function toDictionary(arr, keyMapper, valueMapper) {
  var result = {};
  arr.forEach(function (entry) {
    result[keyMapper(entry)] = valueMapper(entry);
  });
  return result;
};

/***/ }),

/***/ "./generated_module/src/autoProcessor.ts":
/*!***********************************************!*\
  !*** ./generated_module/src/autoProcessor.ts ***!
  \***********************************************/
/*! exports provided: getDerivedData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDerivedData", function() { return getDerivedData; });
/* harmony import */ var _getUserData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./getUserData */ "./generated_module/src/getUserData.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



function createAutoProcessor(getDerivedData) {
  var derivedDataGetter = function derivedDataGetter(dataModel) {
    return _objectSpread({
      getModuleConfig: _getUserData__WEBPACK_IMPORTED_MODULE_0__["getModuleConfigFromFile"]
    }, getDerivedData(dataModel));
  };

  return derivedDataGetter;
}

var getDerivedData = createAutoProcessor(_getUserData__WEBPACK_IMPORTED_MODULE_0__["getDerivedData"]);

/***/ }),

/***/ "./generated_module/src/getUserData.ts":
/*!*********************************************!*\
  !*** ./generated_module/src/getUserData.ts ***!
  \*********************************************/
/*! exports provided: getCreatorFunctions, getDerivedData, getPinsDataFromFile, getPinsLogicFromFile, getModuleConfigFromFile */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPinsDataFromFile", function() { return getPinsDataFromFile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPinsLogicFromFile", function() { return getPinsLogicFromFile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getModuleConfigFromFile", function() { return getModuleConfigFromFile; });
/* harmony import */ var _src_CreatorFunctions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../src/CreatorFunctions */ "./src/CreatorFunctions.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getCreatorFunctions", function() { return _src_CreatorFunctions__WEBPACK_IMPORTED_MODULE_0__["getCreatorFunctions"]; });

/* harmony import */ var _src_DerivedData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../src/DerivedData */ "./src/DerivedData.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getDerivedData", function() { return _src_DerivedData__WEBPACK_IMPORTED_MODULE_1__["getDerivedData"]; });



var getPinsDataFromFile = function getPinsDataFromFile() {
  try {
    return __webpack_require__(/*! ../../src/pinsdata.json */ "./src/pinsdata.json");
  } catch (_unused) {
    return undefined;
  }
};
var getPinsLogicFromFile = function getPinsLogicFromFile() {
  try {
    return __webpack_require__(/*! ../../src/PinsLogic.ts */ "./src/PinsLogic.ts");
  } catch (_unused2) {
    return undefined;
  }
};
var getModuleConfigFromFile = function getModuleConfigFromFile() {
  try {
    return __webpack_require__(/*! ../../src/moduleConfig.json */ "./src/moduleConfig.json");
  } catch (_unused3) {
    return undefined;
  }
};

/***/ }),

/***/ "./generated_module/src/pins/PCPHelper.ts":
/*!************************************************!*\
  !*** ./generated_module/src/pins/PCPHelper.ts ***!
  \************************************************/
/*! exports provided: getPinsData, getPinsLogic */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPinsData", function() { return getPinsData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPinsLogic", function() { return getPinsLogic; });
/* harmony import */ var _getUserData__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../getUserData */ "./generated_module/src/getUserData.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



var mockPinsLogic = function mockPinsLogic(getPinsData) {
  var getCompletePinData = function getCompletePinData(appModel) {
    return {};
  };

  var getRowData = function getRowData(appModel, rowData) {
    return rowData;
  };

  return {
    getCompletePinData: getCompletePinData,
    getRowData: getRowData,
    getPinsData: getPinsData
  };
};

var getPinsData = function getPinsData() {
  var _getPinsDataFromFile;

  return (_getPinsDataFromFile = Object(_getUserData__WEBPACK_IMPORTED_MODULE_0__["getPinsDataFromFile"])()) !== null && _getPinsDataFromFile !== void 0 ? _getPinsDataFromFile : {
    rows: []
  };
};
var getPinsLogic = function getPinsLogic() {
  var pinsLogic = Object(_getUserData__WEBPACK_IMPORTED_MODULE_0__["getPinsLogicFromFile"])();

  if (pinsLogic) {
    return _objectSpread(_objectSpread({}, pinsLogic), {}, {
      getPinsData: getPinsData
    });
  } else {
    return mockPinsLogic(getPinsData);
  }
};

/***/ }),

/***/ "./node_modules/@microchip/i2c-host-basic/lib/package.json":
/*!*****************************************************************!*\
  !*** ./node_modules/@microchip/i2c-host-basic/lib/package.json ***!
  \*****************************************************************/
/*! exports provided: name, version, license, main, typings, scripts, husky, lint-staged, bitBucketRepository, repository, publishConfig, jest, dependencies, devDependencies, files, notificationEmail, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"name\":\"@microchip/i2c-host-basic\",\"version\":\"1.0.0\",\"license\":\"SEE LICENSE IN LICENSE.txt\",\"main\":\"lib/src/index.js\",\"typings\":\"./lib/src/index.d.ts\",\"scripts\":{\"build\":\"tsc\",\"test\":\"jest\",\"lint:nofix\":\"eslint \\\"./src/**/*.{ts,tsx}\\\" --quiet\",\"lint\":\"tsc --noEmit && yarn lint:nofix --fix\"},\"husky\":{\"hooks\":{\"pre-commit\":\"tsc --noEmit && lint-staged\"}},\"lint-staged\":{\"./src/**/*.{ts,tsx}\":[\"eslint --fix\"]},\"bitBucketRepository\":\"https://bitbucket.microchip.com/projects/SCF/repos/i2c-host-basic-interface/browse\",\"repository\":{\"type\":\"git\",\"url\":\"git+ssh://git@https://bitbucket.microchip.com/scm/scf/i2c-host-basic-interface.git\"},\"publishConfig\":{\"registry\":\"https://artifacts.microchip.com/artifactory/api/npm/npm/\"},\"jest\":{\"testPathIgnorePatterns\":[\"/node_modules/\",\"/run/\",\"/lib/\"],\"modulePathIgnorePatterns\":[\"<rootDir>/run\"],\"preset\":\"ts-jest\",\"collectCoverage\":true},\"dependencies\":{\"@microchip/scf-common\":\"^3.5.0\",\"@microchip/scf-interface\":\"^1.4.0\"},\"devDependencies\":{\"@types/jest\":\"^24.0.14\",\"@types/node\":\"^12.0.10\",\"@typescript-eslint/eslint-plugin\":\"^2.27.0\",\"@typescript-eslint/parser\":\"^2.27.0\",\"eslint\":\"^6.8.0\",\"eslint-config-prettier\":\"^6.10.1\",\"eslint-plugin-prettier\":\"^3.1.2\",\"husky\":\"^4.2.4\",\"jest\":\"^24.8.0\",\"lint-staged\":\"^10.2.0\",\"prettier\":\"^2.0.4\",\"ts-jest\":\"^24.0.2\",\"typescript\":\"^3.8.3\"},\"files\":[\"lib/**/*\"],\"notificationEmail\":\"1d0dd98b.microchiptechnology.onmicrosoft.com@amer.teams.ms\"}");

/***/ }),

/***/ "./node_modules/@microchip/i2c-host-basic/lib/src/i2c-host-basic.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@microchip/i2c-host-basic/lib/src/i2c-host-basic.js ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
var InterfaceTypes = __importStar(__webpack_require__(/*! @microchip/scf-interface */ "./node_modules/@microchip/scf-interface/lib/index.js"));
var pkgJson = __importStar(__webpack_require__(/*! ../package.json */ "./node_modules/@microchip/i2c-host-basic/lib/package.json"));
var getInterfaceId = function () {
    return {
        name: InterfaceTypes.getInterfaceName(pkgJson),
        version: InterfaceTypes.getInterfaceVersion(pkgJson),
    };
};
var createMock = function () {
    return {
        interfaceId: exports.Interface.getInterfaceId(),
        payload: {
            moduleInstance: 1,
            moduleName: "I2C1",
            calculatedSpeed_Hz: "100000",
            hasInterrupts: true,
            interruptDriven: true,
            i2cHostCallbackEvent: {
                name: "i2cHostCallback",
                header: "./header/header.h",
            },
            interfaceApi: exports.Interface.createFirmwareApi("I2C_Host", [
                { name: "I2C.h", path: "include/" },
            ]),
        },
        args: {
            requestId: {
                requestedSpeed_Hz: "100000",
                interruptDriven: true,
                i2cHostCallbackEvent: {
                    name: "i2cHostCallback",
                    header: "./header/header.h",
                },
            },
        },
    };
};
exports.createApi = function (prefix) {
    return {
        Initialize: {
            name: prefix + "_Initialize",
            returns: "void",
        },
        Deinitialize: {
            name: prefix + "_Deinitialize",
            returns: "void",
        },
        Write: {
            name: prefix + "_Write",
            returns: "bool",
            arguments: [
                { type: "uint16_t", name: "address" },
                { type: "uint8_t", name: "data" },
                { type: "size_t", name: "dataLength" },
            ],
        },
        Read: {
            name: prefix + "_Read",
            returns: "bool",
            arguments: [
                { type: "uint16_t", name: "address" },
                { type: "uint8_t", name: "data" },
                { type: "size_t", name: "dataLength" },
            ],
        },
        WriteRead: {
            name: prefix + "_WriteRead",
            returns: "bool",
            arguments: [
                { type: "uint16_t", name: "address" },
                { type: "uint8_t *", name: "writeData" },
                { type: "size_t", name: "writeLength" },
                { type: "uint8_t *", name: "readData" },
                { type: "size_t", name: "readLength" },
            ],
        },
        TransferSetup: {
            name: prefix + "_TransferSetup",
            returns: "bool",
            arguments: [
                { type: "I2C_TRANSFER_SETUP *", name: "setup" },
                { type: "uint32_t", name: "srcClkFreq" },
            ],
        },
        ErrorGet: {
            name: prefix + "_ErrorGet",
            returns: "I2C_HOST_ERROR",
        },
        IsBusy: {
            name: prefix + "_IsBusy",
            returns: "bool",
        },
        CallbackRegister: {
            name: prefix + "_CallbackRegister",
            returns: "void",
            arguments: [{ type: "void (*callback)", name: "void" }],
        },
        Tasks: {
            name: prefix + "_Tasks",
            returns: "void",
        },
    };
};
var createPrototypeImport = function () {
    return {
        interfaceId: getInterfaceId(),
    };
};
var createPrototypeExport = function () {
    return {
        interfaces: [{ interfaceId: getInterfaceId() }],
    };
};
var createFirmwareApi = function (moduleName, headerFiles, createCustomApi) {
    var prefix = moduleName ? moduleName : "undefined";
    var api = createCustomApi ? createCustomApi() : exports.createApi(prefix);
    return {
        api: api,
        simpleApi: InterfaceTypes.buildSimpleApi(api),
        headerFiles: headerFiles
            ? headerFiles
            : [{ name: (moduleName === null || moduleName === void 0 ? void 0 : moduleName.toLowerCase()) + "_interface.h", path: "include/" }],
    };
};
exports.Interface = {
    createPrototypeExport: createPrototypeExport,
    createPrototypeImport: createPrototypeImport,
    getInterfaceId: getInterfaceId,
    createMock: createMock,
    createFirmwareApi: createFirmwareApi,
};
//# sourceMappingURL=i2c-host-basic.js.map

/***/ }),

/***/ "./node_modules/@microchip/i2c-host-basic/lib/src/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@microchip/i2c-host-basic/lib/src/index.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var i2c_host_basic_1 = __webpack_require__(/*! ./i2c-host-basic */ "./node_modules/@microchip/i2c-host-basic/lib/src/i2c-host-basic.js");
exports.Interface = i2c_host_basic_1.Interface;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@microchip/pin-standard/lib/pin-standard.js":
/*!******************************************************************!*\
  !*** ./node_modules/@microchip/pin-standard/lib/pin-standard.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.pin_standard = function () {
    return {
        interfaceId: {
            name: "pin-standard",
            version: "0.1.0",
        },
    };
};
var QueryAdapterKey;
(function (QueryAdapterKey) {
    QueryAdapterKey["ALLPINS"] = "allpins";
    QueryAdapterKey["PPS"] = "pps";
    QueryAdapterKey["PORTMUX"] = "portmux";
    QueryAdapterKey["HASPPS"] = "hasPPS";
})(QueryAdapterKey = exports.QueryAdapterKey || (exports.QueryAdapterKey = {}));
var pin_state;
(function (pin_state) {
    pin_state["EMPTY"] = "E";
    pin_state["LOCKED"] = "L";
    pin_state["UNLOCK"] = "UL";
    pin_state["DiSABLE_LOCK"] = "DL";
    pin_state["UNLOCKED_DISABLED"] = "DUL";
    pin_state["LOCKED_LINK"] = "LL";
    pin_state["UNLOCKED_MUX"] = "MUL";
    pin_state["LOCKED_CONFLICT"] = "CL";
})(pin_state = exports.pin_state || (exports.pin_state = {}));
var pin_interrupts_enum;
(function (pin_interrupts_enum) {
    pin_interrupts_enum["INTDIS_BUFFEN"] = "INTDIS_BUFFEN";
    pin_interrupts_enum["BOTH_EDGES"] = "BOTH_EDGES";
    pin_interrupts_enum["RISING_EDGE"] = "RISING_EDGE";
    pin_interrupts_enum["FALLING_EDGE"] = "FALLING_EDGE";
    pin_interrupts_enum["NONE"] = "NONE";
    pin_interrupts_enum["LOW_LEVEL"] = "LOW_LEVEL";
})(pin_interrupts_enum = exports.pin_interrupts_enum || (exports.pin_interrupts_enum = {}));
var pin_attribs_enum;
(function (pin_attribs_enum) {
    pin_attribs_enum["aliasReEx"] = "aliasReEx";
    pin_attribs_enum["cname"] = "cname";
    pin_attribs_enum["high"] = "high";
    pin_attribs_enum["inv"] = "inv";
    pin_attribs_enum["wpu"] = "wpu";
    pin_attribs_enum["wpd"] = "wpd";
    pin_attribs_enum["od"] = "od";
    pin_attribs_enum["analog"] = "analog";
    pin_attribs_enum["ioc"] = "ioc";
    pin_attribs_enum["intcallback"] = "intcallback";
    pin_attribs_enum["alias"] = "alias";
})(pin_attribs_enum = exports.pin_attribs_enum || (exports.pin_attribs_enum = {}));
var actiontype;
(function (actiontype) {
    actiontype["SETACTION"] = "SETACTION";
    actiontype["ATTRIBACTION"] = "ATTRIBACTION";
})(actiontype = exports.actiontype || (exports.actiontype = {}));
var direction;
(function (direction) {
    direction["output"] = "output";
    direction["input"] = "input";
    direction["bidirectional"] = "bidirectional";
})(direction = exports.direction || (exports.direction = {}));
var behaviour;
(function (behaviour) {
    behaviour["LOCK_UNLOCK"] = "LOCK_UNLOCK";
    behaviour["ALWAYS_LOCKED"] = "ALWAYS_LOCKED";
    behaviour["SINGLE_PIN_MUX"] = "SINGLE_PIN_MUX";
    behaviour["OPTIONAL_PIN_MUX"] = "OPTIONAL_PIN_MUX";
    behaviour["PPS"] = "PPS";
    behaviour["PORTMUX"] = "PORTMUX";
    behaviour["EXCLUSIVE_LOCK"] = "EXCLUSIVE_LOCK";
})(behaviour = exports.behaviour || (exports.behaviour = {}));
//------------------------------------ schema ------------------------------------//
exports.data_schema = {
    $schema: "http://json-schema.org/draft-07/schema#",
    $ref: "#/definitions/intf_data",
    definitions: {
        intf_data: {
            type: "object",
            properties: {
                rows: {
                    type: "array",
                    items: {
                        $ref: "#/definitions/pin_row",
                    },
                },
            },
            required: ["rows"],
            additionalProperties: false,
        },
        pin_row: {
            type: "object",
            properties: {
                name: {
                    type: "string",
                },
                module: {
                    type: "string",
                },
                function: {
                    type: "string",
                },
                direction: {
                    $ref: "#/definitions/direction",
                },
                filter: {
                    $ref: "#/definitions/filter",
                },
                behaviour: {
                    $ref: "#/definitions/behaviour",
                },
                behaviourMeta: {
                    $ref: "#/definitions/behaviourMeta",
                },
                attribs: {
                    type: "array",
                    items: {
                        $ref: "#/definitions/pin_attribs",
                    },
                },
                groupsdata: {
                    $ref: "#/definitions/pingroups_data",
                },
                actions: {},
            },
            required: ["name", "module", "function", "direction", "filter", "behaviour"],
            additionalProperties: false,
        },
        direction: {
            type: "string",
            enum: ["output", "input", "bidirectional"],
        },
        filter: {
            type: "object",
            properties: {
                module: {
                    type: "string",
                },
                aliasReEx: {
                    type: "string",
                },
            },
            required: ["module", "aliasReEx"],
            additionalProperties: false,
        },
        behaviour: {
            type: "string",
            enum: [
                "LOCK_UNLOCK",
                "ALWAYS_LOCKED",
                "SINGLE_PIN_MUX",
                "OPTIONAL_PIN_MUX",
                "PPS",
                "PORTMUX",
                "EXCLUSIVE_LOCK",
            ],
        },
        behaviourMeta: {
            type: "object",
            properties: {
                lockPinRegEx: {
                    type: "string",
                },
            },
            required: ["lockPinRegEx"],
            additionalProperties: false,
        },
        pin_attribs: {
            type: "object",
            properties: {
                aliasReEx: {
                    type: "string",
                },
                cname: {
                    type: "string",
                },
                high: {
                    type: "boolean",
                },
                inv: {
                    type: "boolean",
                },
                wpu: {
                    type: "boolean",
                },
                wpd: {
                    type: "boolean",
                },
                od: {
                    type: "boolean",
                },
                analog: {
                    type: "boolean",
                },
                ioc: {
                    $ref: "#/definitions/pin_interrupts_enum",
                },
                bidirection_out: {
                    type: "boolean",
                },
            },
            required: ["aliasReEx"],
            additionalProperties: false,
        },
        pin_interrupts_enum: {
            type: "string",
            enum: [
                "INTDIS_BUFFEN",
                "BOTH_EDGES",
                "RISING_EDGE",
                "FALLING_EDGE",
                "NONE",
                "LOW_LEVEL",
            ],
        },
        pingroups_data: {
            type: "object",
            properties: {
                groups: {
                    type: "array",
                    items: {
                        $ref: "#/definitions/pins_group",
                    },
                },
            },
            required: ["groups"],
            additionalProperties: false,
        },
        pins_group: {
            type: "object",
            properties: {
                name: {
                    type: "string",
                },
                filter: {
                    $ref: "#/definitions/grpfilter",
                },
                datapath: {
                    type: "string",
                },
            },
            required: ["name", "filter"],
            additionalProperties: false,
        },
        grpfilter: {
            type: "object",
            properties: {
                aliasReEx: {
                    type: "string",
                },
            },
            required: ["aliasReEx"],
            additionalProperties: false,
        },
    },
};
//# sourceMappingURL=pin-standard.js.map

/***/ }),

/***/ "./node_modules/@microchip/scf-common/lib/Processor.js":
/*!*************************************************************!*\
  !*** ./node_modules/@microchip/scf-common/lib/Processor.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapOptionLabels = exports.filterOptions = exports.isSingleton = exports.isUnassigned = exports.isAssigned = exports.hasOptions = exports.AlertTypes = void 0;
var AlertTypes;
(function (AlertTypes) {
    AlertTypes["Error"] = "error";
    AlertTypes["Warning"] = "warning";
    AlertTypes["Hint"] = "hint";
})(AlertTypes = exports.AlertTypes || (exports.AlertTypes = {}));
/**
 * See User-Defined Type Guards in the Typescript Handbook on Advanced Types
 * @see https://www.typescriptlang.org/docs/handbook/advanced-types.html
 */
function hasOptions(dep) {
    return dep.options !== undefined;
}
exports.hasOptions = hasOptions;
/**
 * See User-Defined Type Guards in the Typescript Handbook on Advanced Types
 * @see https://www.typescriptlang.org/docs/handbook/advanced-types.html
 */
function isAssigned(dep) {
    return typeof dep.handle !== "undefined";
}
exports.isAssigned = isAssigned;
/**
 * See User-Defined Type Guards in the Typescript Handbook on Advanced Types
 * @see https://www.typescriptlang.org/docs/handbook/advanced-types.html
 */
function isUnassigned(dep) {
    return typeof dep.handle === "undefined";
}
exports.isUnassigned = isUnassigned;
/**
 * Type guard function for SingletonExport
 * See User-Defined Type Guards in the Typescript Handbook on Advanced Types
 * @see https://www.typescriptlang.org/docs/handbook/advanced-types.html
 * @param resource the export to check on being a singleton
 * @deprecated No longer used. Replaced with dynamic singleton identification
 * at runtime.
 */
function isSingleton(resource) {
    return typeof resource.isSingleton !== "undefined" && resource.isSingleton;
}
exports.isSingleton = isSingleton;
/**
 * Returns a copy of `populatedImport` with all options removed which
 * cause `optionFilter` to return false.
 */
function filterOptions(populatedImport, optionFilter) {
    if (populatedImport.options) {
        return __assign(__assign({}, populatedImport), { options: populatedImport.options.filter(optionFilter) });
    }
    return populatedImport;
}
exports.filterOptions = filterOptions;
/**
 * Returns a copy of `populatedImport` with the options' handle labels
 * mapped according to `labelFactory`.
 */
function mapOptionLabels(populatedImport, labelFactory) {
    if (populatedImport.options) {
        return __assign(__assign({}, populatedImport), { options: populatedImport.options.map(function (option) {
                return __assign(__assign({}, option), { handle: __assign(__assign({}, option.handle), { label: labelFactory(option) }) });
            }) });
    }
    return populatedImport;
}
exports.mapOptionLabels = mapOptionLabels;
//# sourceMappingURL=Processor.js.map

/***/ }),

/***/ "./node_modules/@microchip/scf-interface/lib/c-function-types.js":
/*!***********************************************************************!*\
  !*** ./node_modules/@microchip/scf-interface/lib/c-function-types.js ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.buildSimpleApi = function (functions) {
    var api = {};
    for (var key in functions) {
        api[key] = buildFunction(functions[key]);
    }
    return api;
};
var buildFunction = function (cFunction) {
    return cFunction.returns + " " + cFunction.name + "(" + buildArguments(cFunction.arguments) + ")";
};
var buildArguments = function (args) {
    if (args) {
        return args.map(function (arg) { return arg.type + " " + arg.name; }).join(", ");
    }
    else {
        return "void";
    }
};


/***/ }),

/***/ "./node_modules/@microchip/scf-interface/lib/helpers.js":
/*!**************************************************************!*\
  !*** ./node_modules/@microchip/scf-interface/lib/helpers.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.getInterfaceName = function (pkgJson) {
    var strReplace = "@microchip/";
    var interfaceName;
    if (pkgJson) {
        interfaceName = pkgJson["name"];
        if (interfaceName) {
            interfaceName = interfaceName.replace(strReplace, "");
        }
    }
    if (!interfaceName) {
        throw new Error("Invalid Interface Name...!");
    }
    return interfaceName;
};
exports.getInterfaceVersion = function (pkgJson) {
    var versionRegex = new RegExp("\\d+.\\d+.\\d+");
    var version;
    if (pkgJson) {
        version = pkgJson["version"];
    }
    if (!version && !versionRegex.test(version)) {
        throw new Error("Invalid Interface Version...!");
    }
    return version;
};


/***/ }),

/***/ "./node_modules/@microchip/scf-interface/lib/index.js":
/*!************************************************************!*\
  !*** ./node_modules/@microchip/scf-interface/lib/index.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var c_function_types_1 = __webpack_require__(/*! ./c-function-types */ "./node_modules/@microchip/scf-interface/lib/c-function-types.js");
exports.buildSimpleApi = c_function_types_1.buildSimpleApi;
var helpers_1 = __webpack_require__(/*! ./helpers */ "./node_modules/@microchip/scf-interface/lib/helpers.js");
exports.getInterfaceName = helpers_1.getInterfaceName;
exports.getInterfaceVersion = helpers_1.getInterfaceVersion;


/***/ }),

/***/ "./node_modules/@microchip/scf-validators/lib/Validators/CFunctionValidator.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/@microchip/scf-validators/lib/Validators/CFunctionValidator.js ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.getCFunctionValidator = void 0;
var cKeywords = [
    "auto",
    "const",
    "double",
    "float",
    "int",
    "short",
    "struct",
    "unsigned",
    "break",
    "continue",
    "else",
    "for",
    "long",
    "signed",
    "switch",
    "void",
    "case",
    "default",
    "enum",
    "goto",
    "register",
    "sizeof",
    "typedef",
    "volatile",
    "char",
    "do",
    "extern",
    "if",
    "return",
    "static",
    "union",
    "while",
];
var functionPattern = "(?=^([A-Za-z]\\S|_)\\w+$)";
var errorMessage = "Must be valid C function syntax.";
var doNotMatchKeywordsRegex = function () {
    return "(^(?!" + cKeywords.join("|") + ")).*";
};
var result = doNotMatchKeywordsRegex();
var pattern = {
    pattern: functionPattern + result,
};
exports.getCFunctionValidator = function () { return ({
    getRjsfValidation: function () { return pattern; },
    getCustomErrorMessage: function () { return errorMessage; },
}); };


/***/ }),

/***/ "./node_modules/@microchip/scf-validators/lib/Validators/HeaderPathValidator.js":
/*!**************************************************************************************!*\
  !*** ./node_modules/@microchip/scf-validators/lib/Validators/HeaderPathValidator.js ***!
  \**************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.getHeaderPathValidator = void 0;
//Matches file paths to any valid format. Matches both "\" and "/" as valid separators in file path.
//Extension ("[h]+") checks specifically for '.h' and can be extende to any if required.
//Does NOT match relative file paths.
var pathRegex = "^(([a-zA-Z]:)|((?:\\\\|.\\/?){1,2}\\w+)\\$?)((\\\\|\\/)(\\w[\\w ]*.*))+\\.([h]+)$";
var errorMessage = "Must be valid header path.";
var pathPattern = {
    pattern: pathRegex,
};
exports.getHeaderPathValidator = function () { return ({
    getRjsfValidation: function () { return pathPattern; },
    getCustomErrorMessage: function () { return errorMessage; },
}); };


/***/ }),

/***/ "./node_modules/@microchip/scf-validators/lib/Validators/HexValidator.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/@microchip/scf-validators/lib/Validators/HexValidator.js ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.getHexValidator = void 0;
var regexFormat = /^0x[\da-f]/i;
var errorMessage = "Must be valid hexadecimal number.";
var format = {
    hex: regexFormat,
};
exports.getHexValidator = function () { return ({
    getRjsfValidation: function () { return format; },
    getCustomErrorMessage: function () { return errorMessage; },
}); };


/***/ }),

/***/ "./node_modules/@microchip/scf-validators/lib/index.js":
/*!*************************************************************!*\
  !*** ./node_modules/@microchip/scf-validators/lib/index.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var CFunctionValidator_1 = __webpack_require__(/*! ./Validators/CFunctionValidator */ "./node_modules/@microchip/scf-validators/lib/Validators/CFunctionValidator.js");
Object.defineProperty(exports, "getCFunctionValidator", { enumerable: true, get: function () { return CFunctionValidator_1.getCFunctionValidator; } });
var HexValidator_1 = __webpack_require__(/*! ./Validators/HexValidator */ "./node_modules/@microchip/scf-validators/lib/Validators/HexValidator.js");
Object.defineProperty(exports, "getHexValidator", { enumerable: true, get: function () { return HexValidator_1.getHexValidator; } });
var HeaderPathValidator_1 = __webpack_require__(/*! ./Validators/HeaderPathValidator */ "./node_modules/@microchip/scf-validators/lib/Validators/HeaderPathValidator.js");
Object.defineProperty(exports, "getHeaderPathValidator", { enumerable: true, get: function () { return HeaderPathValidator_1.getHeaderPathValidator; } });


/***/ }),

/***/ "./node_modules/@microchip/temp-sensor/lib/package.json":
/*!**************************************************************!*\
  !*** ./node_modules/@microchip/temp-sensor/lib/package.json ***!
  \**************************************************************/
/*! exports provided: name, version, license, main, typings, scripts, husky, lint-staged, bitBucketRepository, repository, publishConfig, jest, dependencies, devDependencies, files, notificationEmail, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"name\":\"@microchip/temp-sensor\",\"version\":\"1.0.1\",\"license\":\"SEE LICENSE IN LICENSE.txt\",\"main\":\"lib/src/index.js\",\"typings\":\"./lib/src/index.d.ts\",\"scripts\":{\"build\":\"tsc\",\"test\":\"jest\",\"lint:nofix\":\"eslint \\\"./src/**/*.{ts,tsx}\\\" --quiet\",\"lint\":\"tsc --noEmit && yarn lint:nofix --fix\"},\"husky\":{\"hooks\":{\"pre-commit\":\"tsc --noEmit && lint-staged\"}},\"lint-staged\":{\"./src/**/*.{ts,tsx}\":[\"eslint --fix\"]},\"bitBucketRepository\":\"https://bitbucket.microchip.com/projects/SCF/repos/temp-sensor-interface/browse\",\"repository\":{\"type\":\"git\",\"url\":\"git+ssh://git@https://bitbucket.microchip.com/scm/scf/temp-sensor-interface.git\"},\"publishConfig\":{\"registry\":\"https://artifacts.microchip.com/artifactory/api/npm/npm/\"},\"jest\":{\"testPathIgnorePatterns\":[\"/node_modules/\",\"/run/\",\"/lib/\"],\"modulePathIgnorePatterns\":[\"<rootDir>/run\"],\"preset\":\"ts-jest\",\"collectCoverage\":true},\"dependencies\":{\"@microchip/scf-common\":\"^3.5.0\",\"@microchip/scf-interface\":\"^1.4.0\"},\"devDependencies\":{\"@types/jest\":\"^24.0.14\",\"@types/node\":\"^12.0.10\",\"@typescript-eslint/eslint-plugin\":\"^2.27.0\",\"@typescript-eslint/parser\":\"^2.27.0\",\"eslint\":\"^6.8.0\",\"eslint-config-prettier\":\"^6.10.1\",\"eslint-plugin-prettier\":\"^3.1.2\",\"husky\":\"^4.2.4\",\"jest\":\"^24.8.0\",\"lint-staged\":\"^10.2.0\",\"prettier\":\"^2.0.4\",\"ts-jest\":\"^24.0.2\",\"typescript\":\"^3.8.3\"},\"files\":[\"lib/**/*\"],\"notificationEmail\":\"1d0dd98b.microchiptechnology.onmicrosoft.com@amer.teams.ms\"}");

/***/ }),

/***/ "./node_modules/@microchip/temp-sensor/lib/src/api.js":
/*!************************************************************!*\
  !*** ./node_modules/@microchip/temp-sensor/lib/src/api.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.getTEMPSENSORAPI = function () {
    return {
        Initialize: {
            name: "Initialize",
            returns: "temperature_sensor_status_t",
        },
        Temperature_Read: {
            name: "Temperature_Read",
            returns: "temperature_sensor_status_t",
        },
        LowPower_Enable: {
            name: "LowPower_Enable",
            returns: "temperature_sensor_status_t",
        },
        LowPower_Disable: {
            name: "LowPower_Disable",
            returns: "temperature_sensor_status_t",
        },
        Celsius_To_Fahrenheit: {
            name: "Celsius_To_Fahrenheit",
            returns: "float",
            arguments: [{ type: "float", name: "tempVal" }],
        },
        Fahrenheit_To_Celsius: {
            name: "Fahrenheit_To_Celsius",
            returns: "float",
            arguments: [{ type: "float", name: "tempVal" }],
        },
    };
};
exports.getHeaderFileData = function (moduleName) {
    return [
        { name: "temp_sensor" + ".h", path: "mcc_generated_files/temperature-generic/" },
    ];
};
//# sourceMappingURL=api.js.map

/***/ }),

/***/ "./node_modules/@microchip/temp-sensor/lib/src/index.js":
/*!**************************************************************!*\
  !*** ./node_modules/@microchip/temp-sensor/lib/src/index.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var temp_sensor_1 = __webpack_require__(/*! ./temp-sensor */ "./node_modules/@microchip/temp-sensor/lib/src/temp-sensor.js");
exports.Interface = temp_sensor_1.Interface;
exports.getInterfaceApiStructure = temp_sensor_1.getInterfaceApiStructure;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@microchip/temp-sensor/lib/src/temp-sensor.js":
/*!********************************************************************!*\
  !*** ./node_modules/@microchip/temp-sensor/lib/src/temp-sensor.js ***!
  \********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
var InterfaceTypes = __importStar(__webpack_require__(/*! @microchip/scf-interface */ "./node_modules/@microchip/scf-interface/lib/index.js"));
var pkgJson = __importStar(__webpack_require__(/*! ../package.json */ "./node_modules/@microchip/temp-sensor/lib/package.json"));
var api_1 = __webpack_require__(/*! ./api */ "./node_modules/@microchip/temp-sensor/lib/src/api.js");
exports.getInterfaceApiStructure = function (moduleName) {
    return {
        api: api_1.getTEMPSENSORAPI(),
        headerFiles: api_1.getHeaderFileData(moduleName),
    };
};
var getInterfaceId = function () {
    return {
        name: InterfaceTypes.getInterfaceName(pkgJson),
        version: InterfaceTypes.getInterfaceVersion(pkgJson),
    };
};
var createMock = function () {
    return {
        interfaceId: exports.Interface.getInterfaceId(),
        payload: {
            moduleName: "TempSensor",
            customName: "TempSensor",
            lowPowerMode: true,
            protocol: "I2C",
            interfaceApi: { api: {}, headerFiles: [] },
        },
        args: {
            requestId: {
                customName: "TempSensorX",
                lowPowerMode: true,
            },
        },
    };
};
var createPrototypeImport = function () {
    return {
        interfaceId: getInterfaceId(),
    };
};
var createPrototypeExport = function () {
    return {
        interfaces: [{ interfaceId: getInterfaceId() }],
    };
};
exports.Interface = {
    createPrototypeExport: createPrototypeExport,
    createPrototypeImport: createPrototypeImport,
    getInterfaceId: getInterfaceId,
    createMock: createMock,
};
//# sourceMappingURL=temp-sensor.js.map

/***/ }),

/***/ "./src/CreatorFunctions.ts":
/*!*********************************!*\
  !*** ./src/CreatorFunctions.ts ***!
  \*********************************/
/*! exports provided: getCreatorFunctions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCreatorFunctions", function() { return getCreatorFunctions; });
var getCreatorFunctions = function getCreatorFunctions() {
  return {
    shouldImport: shouldImport,
    getCreatorImportArgs: getCreatorImportArgs
  };
};

var shouldImport = function shouldImport(importKey, state) {
  return true;
};

var getCreatorImportArgs = function getCreatorImportArgs(importKey, state) {
  return undefined;
};

/***/ }),

/***/ "./src/DerivedData.ts":
/*!****************************!*\
  !*** ./src/DerivedData.ts ***!
  \****************************/
/*! exports provided: getDerivedData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDerivedData", function() { return getDerivedData; });
/* harmony import */ var _features_helpers_GuiHelper__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./features/helpers/GuiHelper */ "./src/features/helpers/GuiHelper.ts");
/* harmony import */ var _microchip_scf_validators_lib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microchip/scf-validators/lib */ "./node_modules/@microchip/scf-validators/lib/index.js");
/* harmony import */ var _microchip_scf_validators_lib__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microchip_scf_validators_lib__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _features_helpers_AlertsHelper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./features/helpers/AlertsHelper */ "./src/features/helpers/AlertsHelper.ts");
/* harmony import */ var _microchip_scf_common_lib_Processor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microchip/scf-common/lib/Processor */ "./node_modules/@microchip/scf-common/lib/Processor.js");
/* harmony import */ var _microchip_scf_common_lib_Processor__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microchip_scf_common_lib_Processor__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _features_helpers_TemplateHelper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./features/helpers/TemplateHelper */ "./src/features/helpers/TemplateHelper.ts");
/* harmony import */ var _OptionValues__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./OptionValues */ "./src/OptionValues.ts");
/* harmony import */ var _interfaces_mcp98xx_basic__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./interfaces/mcp98xx-basic */ "./src/interfaces/mcp98xx-basic.ts");
/* harmony import */ var _generated_module_src_pins_PCPHelper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../generated_module/src/pins/PCPHelper */ "./generated_module/src/pins/PCPHelper.ts");
/* harmony import */ var _generated_module_src_Utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../generated_module/src/Utils */ "./generated_module/src/Utils.ts");
/* harmony import */ var _features_helpers_ImportsHelpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./features/helpers/ImportsHelpers */ "./src/features/helpers/ImportsHelpers.ts");
/* harmony import */ var _microchip_temp_sensor__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @microchip/temp-sensor */ "./node_modules/@microchip/temp-sensor/lib/src/index.js");
/* harmony import */ var _microchip_temp_sensor__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_microchip_temp_sensor__WEBPACK_IMPORTED_MODULE_10__);
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }












var getDerivedData = function getDerivedData(dataModel) {
  if (dataModel) {
    return new MyDerivedData(dataModel);
  }

  return new EmptyDerivedData();
}; //This data will be used at the creator stage and relies on only the state

var EmptyDerivedData = function EmptyDerivedData() {
  _classCallCheck(this, EmptyDerivedData);

  _defineProperty(this, "getMyFunctions", function () {
    return {};
  });

  _defineProperty(this, "getModel", function () {
    return undefined;
  });
}; //This data will be used at the processor stage


var MyDerivedData = function MyDerivedData(dataModel) {
  var _this = this;

  _classCallCheck(this, MyDerivedData);

  _defineProperty(this, "dataModel", void 0);

  _defineProperty(this, "cValidator", Object(_microchip_scf_validators_lib__WEBPACK_IMPORTED_MODULE_1__["getCFunctionValidator"])());

  _defineProperty(this, "getMyFunctions", function () {
    return {
      templateData: _this.getMyTemplateData,
      alerts: _this.getMyAlerts,
      calculatedFunction: _this.calculatedFunction,
      moduleName: function moduleName() {
        return "I2C Temp Sensor MCP98xx";
      },
      getActiveName: function getActiveName() {
        return "I2C Temp Sensor MCP98xx";
      },
      templateName: _this.getTemplateName,
      overrideDefaultValues: _this.overrideDefaultValue,
      tempUpperBoundaryValidator: _this.getTempBoundaryValidator,
      tempLowerBoundaryValidator: _this.getTempBoundaryValidator,
      tempCritBoundaryValidator: _this.getTempBoundaryValidator,
      componentNameValidator: _this.componentNameValidator,
      getCustomUiErrors: _this.getCustomUiErrors,
      overrideOptions: _this.overrideOptions,
      i2cClientAdd: _this.i2cClientAddrssConfig,
      overrideTitle: _this.getTempDesc,
      isEnabled: _this.isComponentEnabled,
      "temp-sensor_payload": _this.getExportedGenericTempSensorPayload,
      "mcp98xx-basic_payload": _this.getExportedMcp98xxInterfacePayload,
      operation: _this.getOperationMode,
      componentName: _this.getComponentNameArgs,
      device: _this.getDeviceArgs,
      getPinsLogic: _generated_module_src_pins_PCPHelper__WEBPACK_IMPORTED_MODULE_7__["getPinsLogic"],
      tempResolution: _this.overrideResolution,
      tempHysteresis: _this.overrideHysteresis,
      showPin: function showPin() {
        return false;
      },
      generateFile: function generateFile() {
        return _this.getModel().getComponentValue("device") === "MCP9808";
      },
      alertMode: function alertMode() {
        return _features_helpers_GuiHelper__WEBPACK_IMPORTED_MODULE_0__["GuiHelper"].createCalculatedValueBuilder().addConditionalValue(_this.getModel().getComponentValue("alertTrigger"), "Crit Only", "Comparator Mode").buildCalculatedValue();
      },
      isHostSelectable: function isHostSelectable() {
        return _this.dataModel.getImports().i2c_host_basic.options !== undefined;
      },
      i2c_host_basic_results: function i2c_host_basic_results() {
        var _this$getModel$getImp, _this$getModel$getImp2;

        return _features_helpers_ImportsHelpers__WEBPACK_IMPORTED_MODULE_9__["ImportsHelpers"]["i2c_host_basic"].createResultsBuilder().addCustomName("I2C".concat((_this$getModel$getImp = (_this$getModel$getImp2 = _this.getModel().getImports().i2c_host_basic.payload) === null || _this$getModel$getImp2 === void 0 ? void 0 : _this$getModel$getImp2.moduleInstance.toString()) !== null && _this$getModel$getImp !== void 0 ? _this$getModel$getImp : "1", "_Host")).buildResults();
      },
      i2c_host_basic_args: function i2c_host_basic_args() {
        var _ImportsHelpers$i2c_h;

        return (_ImportsHelpers$i2c_h = _features_helpers_ImportsHelpers__WEBPACK_IMPORTED_MODULE_9__["ImportsHelpers"]["i2c_host_basic"].createArgumentsBuilder().addRequestedSpeed_Hz("400000")) === null || _ImportsHelpers$i2c_h === void 0 ? void 0 : _ImportsHelpers$i2c_h.buildArguments();
      }
    };
  });

  _defineProperty(this, "overrideDefaultValue", function (componentName) {
    switch (componentName) {
      case "componentName":
        return _this.getModel().getComponentValue("device");

      case "tempHysteresis":
        if (_this.getModel().getComponentValue("unit") === "Fahrenheit") {
          return "32";
        } else {
          return "0";
        }

      case "tempResolution":
        if (_this.getModel().getComponentValue("unit") === "Fahrenheit") {
          return "+32.1125";
        } else {
          return "+0.0625";
        }

    }
  });

  _defineProperty(this, "getHeaderFiles", function () {
    var _this$getModel$getCom, _this$getModel$getCom2, _this$getModel$getCom3;

    return [{
      name: "".concat((_this$getModel$getCom = _this.getModel().getComponentValue("device")) !== null && _this$getModel$getCom !== void 0 ? _this$getModel$getCom : "MCP98xx").toLowerCase() + ".h",
      path: "temperature-mcp98xx/"
    }, {
      name: "".concat((_this$getModel$getCom2 = _this.getModel().getComponentValue("device")) !== null && _this$getModel$getCom2 !== void 0 ? _this$getModel$getCom2 : "MCP98xx").toLowerCase() + "_config.h",
      path: "temperature-mcp98xx/"
    }, {
      name: "".concat((_this$getModel$getCom3 = _this.getModel().getComponentValue("device")) !== null && _this$getModel$getCom3 !== void 0 ? _this$getModel$getCom3 : "MCP98xx").toLowerCase() + "_i2c.h",
      path: "temperature-mcp98xx/"
    }, {
      name: "mcp98xx_types.h",
      path: "temperature-mcp98xx/"
    }, {
      name: "mcp98xx_interface.h",
      path: "temperature-mcp98xx/"
    }];
  });

  _defineProperty(this, "getModuleName", function () {
    var _this$dataModel$getNa;

    return (_this$dataModel$getNa = _this.dataModel.getName()) !== null && _this$dataModel$getNa !== void 0 ? _this$dataModel$getNa : "MCP98xx";
  });

  _defineProperty(this, "getExportedGenericTempSensorPayload", function () {
    var _this$getModel$getCom4, _this$getModel$getCom5;

    var Api = _microchip_temp_sensor__WEBPACK_IMPORTED_MODULE_10__["getInterfaceApiStructure"](_this.getModuleName());
    Api.api.Initialize = _interfaces_mcp98xx_basic__WEBPACK_IMPORTED_MODULE_6__["createApi"]("".concat(_this.getModel().getComponentValue("componentName"))).Initialize;
    Api.api.Temperature_Read = _interfaces_mcp98xx_basic__WEBPACK_IMPORTED_MODULE_6__["createApi"]("".concat(_this.getModel().getComponentValue("componentName"))).TemperatureRead;
    Api.api.LowPower_Enable = _interfaces_mcp98xx_basic__WEBPACK_IMPORTED_MODULE_6__["createApi"]("".concat(_this.getModel().getComponentValue("componentName"))).shdnModeEnable;
    Api.api.LowPower_Disable = _interfaces_mcp98xx_basic__WEBPACK_IMPORTED_MODULE_6__["createApi"]("".concat(_this.getModel().getComponentValue("componentName"))).shdnModeDisable;
    Api.api.Celsius_To_Fahrenheit = _interfaces_mcp98xx_basic__WEBPACK_IMPORTED_MODULE_6__["createApi"]("".concat(_this.getModel().getComponentValue("componentName"))).celsiusToFahrenheit;
    Api.api.Fahrenheit_To_Celsius = _interfaces_mcp98xx_basic__WEBPACK_IMPORTED_MODULE_6__["createApi"]("".concat(_this.getModel().getComponentValue("componentName"))).fahrenheitToCelsius;
    Api.headerFiles = [{
      name: "".concat((_this$getModel$getCom4 = _this.getModel().getComponentValue("device")) === null || _this$getModel$getCom4 === void 0 ? void 0 : _this$getModel$getCom4.toLowerCase(), ".h"),
      path: "temperature-mcp98xx/"
    }];
    return {
      customName: String(_this.getModel().getComponentValue("componentName")),
      moduleName: "Off-chip: " + _this.getModel().getActiveName(),
      lowPowerMode: (_this$getModel$getCom5 = _this.getModel().getComponentValue("operation")) !== null && _this$getModel$getCom5 !== void 0 ? _this$getModel$getCom5 : false,
      interfaceApi: Api,
      protocol: "I2C"
    };
  });

  _defineProperty(this, "getExportedMcp98xxInterfacePayload", function () {
    var _this$getModel$getCom6;

    return {
      interfaceApi: _interfaces_mcp98xx_basic__WEBPACK_IMPORTED_MODULE_6__["createFirmwareApi"]((_this$getModel$getCom6 = _this.getModel().getComponentValue("componentName")) !== null && _this$getModel$getCom6 !== void 0 ? _this$getModel$getCom6 : "MCP98xx", _this.getHeaderFiles()),
      componentName: _this.getModel().getComponentValue("componentName"),
      device: _this.getModel().getComponentValue("device"),
      shutdownMode: _this.getModel().getComponentValue("operation"),
      tempUnit: _this.getModel().getComponentValue("unit"),
      i2cClientAddress: _this.getModel().getComponentValue("i2cClientAdd"),
      tempWinLock: _this.getModel().getComponentValue("tempWinLock"),
      tempCritLock: _this.getModel().getComponentValue("tempCritLock"),
      tempResolution: _this.getModel().getComponentValue("tempResolution"),
      tempHysteresis: _this.getModel().getComponentValue("tempHysteresis"),
      tempLowerBoundary: _this.getModel().getComponentValue("tempLowerBoundary"),
      tempUpperBoundary: _this.getModel().getComponentValue("tempUpperBoundary"),
      tempCritBoundary: _this.getModel().getComponentValue("tempCritBoundary"),
      alertCtrl: _this.getModel().getComponentValue("alertControl"),
      alertSlct: _this.getModel().getComponentValue("alertTrigger"),
      alertMd: _this.getModel().getComponentValue("alertMode"),
      alertPol: _this.getModel().getComponentValue("alertPolarity")
    };
  });

  _defineProperty(this, "getRequestedArgFrom", function (interfaceId, argName) {
    var tempSensorExport = _this.getModel().getExportInterfaces().getInterface("temp_sensor_interface", interfaceId);

    if (tempSensorExport && tempSensorExport.args) {
      var chosen = Object.keys(tempSensorExport.args)[0];
      var args = tempSensorExport.args[chosen];

      if (args && args[argName] !== undefined) {
        return args[argName];
      }
    }
  });

  _defineProperty(this, "getRequestedArg", function (argName) {
    var arg = _this.getRequestedArgFrom(_microchip_temp_sensor__WEBPACK_IMPORTED_MODULE_10__["Interface"].getInterfaceId(), argName);

    if (arg !== undefined) {
      return arg;
    }
  });

  _defineProperty(this, "getComponentNameArgs", function () {
    return _this.getRequestedArg("componentName");
  });

  _defineProperty(this, "getDeviceArgs", function () {
    return _this.getRequestedArg("device");
  });

  _defineProperty(this, "getOperationMode", function () {
    return _this.getRequestedArg("lowPowerMode");
  });

  _defineProperty(this, "getModel", function () {
    return _this.dataModel;
  });

  _defineProperty(this, "getTemplateName", function (src) {
    var _this$getModel$getCom7, _this$getModel$getCom8;

    var device = (_this$getModel$getCom7 = (_this$getModel$getCom8 = _this.getModel().getComponentValue("device")) === null || _this$getModel$getCom8 === void 0 ? void 0 : _this$getModel$getCom8.toLowerCase()) !== null && _this$getModel$getCom7 !== void 0 ? _this$getModel$getCom7 : "mcp98xx";

    if (src === "output/mcp98xx_i2c.c.ftl") {
      return "temperature-mcp98xx/src/".concat(device, "_i2c.c");
    } else if (src === "output/mcp98xx_i2c.h.ftl") {
      return "temperature-mcp98xx/".concat(device, "_i2c.h");
    } else if (src === "output/submodules/mcp98xx_c_driver/src/mcp9808.c.ftl") {
      return "temperature-mcp98xx/src/".concat(device, ".c");
    } else if (src === "output/submodules/mcp98xx_c_driver/mcp9808.h.ftl") {
      return "temperature-mcp98xx/".concat(device, ".h");
    } else {
      return undefined;
    }
  });

  _defineProperty(this, "getMyTemplateData", function () {
    var _this$getModel$getCom9, _this$getModel$getCom10, _this$getModel$getCom11, _this$getModel$getCom12, _this$getModel$getCom13, _ImportsHelpers$i2c_h2, _ImportsHelpers$i2c_h3, _ImportsHelpers$i2c_h4, _ImportsHelpers$i2c_h5, _ImportsHelpers$i2c_h6, _ImportsHelpers$i2c_h7;

    return _features_helpers_TemplateHelper__WEBPACK_IMPORTED_MODULE_4__["TemplateHelper"].createTemplateDataBuilder(_this.getModel()).addGuiData("componentName").addGenericData("componentNameLowerCase", (_this$getModel$getCom9 = _this.getModel().getComponentValue("componentName")) === null || _this$getModel$getCom9 === void 0 ? void 0 : _this$getModel$getCom9.toLowerCase()).addGenericData("componentNameUpperCase", (_this$getModel$getCom10 = _this.getModel().getComponentValue("componentName")) === null || _this$getModel$getCom10 === void 0 ? void 0 : _this$getModel$getCom10.toUpperCase()).addGenericData("deviceNameLowerCase", (_this$getModel$getCom11 = _this.getModel().getComponentValue("device")) === null || _this$getModel$getCom11 === void 0 ? void 0 : _this$getModel$getCom11.toLowerCase()).addGenericData("isRedundant", _this.isRedundant()).addGuiData("device").addGenericData("i2cHostModuleName", _this.getModel().getComponentValue("i2c_host_basic")).addGuiData("i2cClientAdd").addGenericData("tempLower", _this.lowerBoundaryGet()).addGenericData("tempUpper", _this.upperBoundaryGet()).addGenericData("tempCrit", _this.critBoundaryGet()).addGenericData("shdnMode", _this.opMode()).addGenericData("tempResolutionVal", _this.tempResolutionGet()).addGenericData("tempHysteresisVal", _this.tempHysteresisGet()).addGenericData("tempWinLock", _this.winLock()).addGenericData("tempCritLock", _this.critLock()).addGenericData("alertCtrl", _this.alertControl()).addGenericData("alertSelect", _this.alertSelect()).addGenericData("alertMode", _this.alertMode()).addGenericData("alertPol", _this.alertPolarity()).addHeaderFileData("mcp9808", {
      path: "temperature-mcp98xx/",
      name: "mcp9808.h"
    }).addHeaderFileData("mcp9808_config", {
      path: "temperature-mcp98xx/",
      name: "mcp9808_config.h"
    }).addHeaderFileData("mcp98xx_i2c", {
      path: "temperature-mcp98xx/",
      name: "".concat((_this$getModel$getCom12 = (_this$getModel$getCom13 = _this.getModel().getComponentValue("device")) === null || _this$getModel$getCom13 === void 0 ? void 0 : _this$getModel$getCom13.toLocaleLowerCase()) !== null && _this$getModel$getCom12 !== void 0 ? _this$getModel$getCom12 : "mcp98xx", "_i2c.h")
    }).addHeaderFileData("mcp98xx_types", {
      path: "temperature-mcp98xx/",
      name: "mcp98xx_types.h"
    }).addHeaderFileData("mcp98xx_interface", {
      path: "temperature-mcp98xx/",
      name: "mcp98xx_interface.h"
    }).addHeaderFileData("mcc", {
      path: "system/",
      name: "system.h"
    }).addHeaderFileData("i2c", {
      path: "i2c_host/",
      name: "".concat((_ImportsHelpers$i2c_h2 = (_ImportsHelpers$i2c_h3 = _features_helpers_ImportsHelpers__WEBPACK_IMPORTED_MODULE_9__["ImportsHelpers"]["i2c_host_basic"].getPayload(_this.getModel())) === null || _ImportsHelpers$i2c_h3 === void 0 ? void 0 : _ImportsHelpers$i2c_h3.moduleName.toLocaleLowerCase()) !== null && _ImportsHelpers$i2c_h2 !== void 0 ? _ImportsHelpers$i2c_h2 : "i2c", ".h")
    }).addResolvePath("mcp98xx_src", "temperature-mcp98xx/src/").addResolvePath("mcp98xx_h", "/").addFirmwareApiData("i2cInterface", (_ImportsHelpers$i2c_h4 = _features_helpers_ImportsHelpers__WEBPACK_IMPORTED_MODULE_9__["ImportsHelpers"]["i2c_host_basic"].getFirmwareApi(_this.getModel())) !== null && _ImportsHelpers$i2c_h4 !== void 0 ? _ImportsHelpers$i2c_h4 : {}).addGenericData("isI2cInterruptDriven", (_ImportsHelpers$i2c_h5 = (_ImportsHelpers$i2c_h6 = _features_helpers_ImportsHelpers__WEBPACK_IMPORTED_MODULE_9__["ImportsHelpers"]["i2c_host_basic"].getPayload(_this.getModel())) === null || _ImportsHelpers$i2c_h6 === void 0 ? void 0 : _ImportsHelpers$i2c_h6.interruptDriven) !== null && _ImportsHelpers$i2c_h5 !== void 0 ? _ImportsHelpers$i2c_h5 : false).addGenericData("modInstance", (_ImportsHelpers$i2c_h7 = _features_helpers_ImportsHelpers__WEBPACK_IMPORTED_MODULE_9__["ImportsHelpers"]["i2c_host_basic"].getPayload(_this.getModel())) === null || _ImportsHelpers$i2c_h7 === void 0 ? void 0 : _ImportsHelpers$i2c_h7.moduleInstance).addGenericData("hasI2C", _this.getModel().getImportValue("i2c_host_basic") ? true : false).addGenericData("isMssp", _this.isMSSP()).buildTemplateData();
  });

  _defineProperty(this, "getMyAlerts", function () {
    var _getKeys$length, _getKeys, _values$0$ioc, _values, _values$, _values$0$ioc2, _values2, _values2$, _getKeys$length2, _getKeys2, _this$getModel$getCom14, _this$getModel$getCom15;

    var intPinAttribs = _this.getModel().getComponentValue("ioOutPin");

    if (typeof intPinAttribs === "string") {
      intPinAttribs = JSON.parse(intPinAttribs);
    }

    return _features_helpers_AlertsHelper__WEBPACK_IMPORTED_MODULE_2__["AlertHelper"].createAlertBuilder().addConditionalAlert(((_getKeys$length = (_getKeys = Object(_generated_module_src_Utils__WEBPACK_IMPORTED_MODULE_8__["getKeys"])(intPinAttribs)) === null || _getKeys === void 0 ? void 0 : _getKeys.length) !== null && _getKeys$length !== void 0 ? _getKeys$length : 0).toString(), "0", _microchip_scf_common_lib_Processor__WEBPACK_IMPORTED_MODULE_3__["AlertTypes"].Warning, "Select an ALERT Pin for ".concat(_this.getModel().getComponentValue("device"))).addConditionalAlert((_values$0$ioc = (_values = Object(_generated_module_src_Utils__WEBPACK_IMPORTED_MODULE_8__["values"])(intPinAttribs)) === null || _values === void 0 ? void 0 : (_values$ = _values[0]) === null || _values$ === void 0 ? void 0 : _values$.ioc) !== null && _values$0$ioc !== void 0 ? _values$0$ioc : "ANY", "NONE", _microchip_scf_common_lib_Processor__WEBPACK_IMPORTED_MODULE_3__["AlertTypes"].Warning, "Configure the ALERT Pin's Interrupt on Change in the Pins module.").addConditionalAlert((_values$0$ioc2 = (_values2 = Object(_generated_module_src_Utils__WEBPACK_IMPORTED_MODULE_8__["values"])(intPinAttribs)) === null || _values2 === void 0 ? void 0 : (_values2$ = _values2[0]) === null || _values2$ === void 0 ? void 0 : _values2$.ioc) !== null && _values$0$ioc2 !== void 0 ? _values$0$ioc2 : "ANY", "INTDIS_BUFFEN", _microchip_scf_common_lib_Processor__WEBPACK_IMPORTED_MODULE_3__["AlertTypes"].Warning, "Configure the ALERT Pin's Interrupt on Change in the Pins module.").addConditionalAlert(((_getKeys$length2 = (_getKeys2 = Object(_generated_module_src_Utils__WEBPACK_IMPORTED_MODULE_8__["getKeys"])(intPinAttribs)) === null || _getKeys2 === void 0 ? void 0 : _getKeys2.length) !== null && _getKeys$length2 !== void 0 ? _getKeys$length2 : 0) > 0, "true", _microchip_scf_common_lib_Processor__WEBPACK_IMPORTED_MODULE_3__["AlertTypes"].Hint, "An ALERT pin is selected. Connect the ".concat((_this$getModel$getCom14 = _this.getModel().getComponentValue("device")) !== null && _this$getModel$getCom14 !== void 0 ? _this$getModel$getCom14 : "MCP98XX", "'s ALERT pin to the selected GPIO.")).addConditionalAlert(_this.getModel().getComponentValue("i2c_host_basic"), "None", _microchip_scf_common_lib_Processor__WEBPACK_IMPORTED_MODULE_3__["AlertTypes"].Warning, "Select I2C Dependency. If no I2C Host modules are available, modify the generated ".concat((_this$getModel$getCom15 = _this.getModel().getComponentValue("device")) === null || _this$getModel$getCom15 === void 0 ? void 0 : _this$getModel$getCom15.toLowerCase(), "_i2c.c file and assign APIs to the i2c_host_interface.")).addStaticAlert(_microchip_scf_common_lib_Processor__WEBPACK_IMPORTED_MODULE_3__["AlertTypes"].Hint, "The A2, A1, and A0 address pins are set externally. Make sure that the address pins are configured correctly on the hardware setup.").addConditionalAlert(_this.getModel().isComponentValue("tempWinLock") || _this.getModel().isComponentValue("tempCritLock"), "true", _microchip_scf_common_lib_Processor__WEBPACK_IMPORTED_MODULE_3__["AlertTypes"].Hint, "Enabled lock bits can only be cleared by an internal reset").addConditionalAlert(_this.getModel().getComponentValue("ioc"), "true", _microchip_scf_common_lib_Processor__WEBPACK_IMPORTED_MODULE_3__["AlertTypes"].Hint, "Select Interrupt On Change on the Pins Manager").buildAlerts();
  });

  _defineProperty(this, "calculatedFunction", function () {
    return;
  });

  _defineProperty(this, "componentNameValidator", function () {
    return {
      pattern: _this.cValidator.getRjsfValidation().pattern
    };
  });

  _defineProperty(this, "getCustomUiErrors", function (componentName) {
    switch (componentName) {
      case "componentName":
        return [{
          name: "pattern",
          message: _this.cValidator.getCustomErrorMessage()
        }];

      default:
        return undefined;
    }
  });

  _defineProperty(this, "getTempBoundaryValidator", function () {
    var unit = _this.getModel().getComponentValue("unit");

    if (unit === "Fahrenheit") {
      return {
        minimum: -40,
        maximum: 257
      };
    } else {
      return {
        minimum: -40,
        maximum: 125
      };
    }
  });

  _defineProperty(this, "overrideOptions", function (componentName) {
    var options;
    var optionVal = [];

    switch (componentName) {
      case "tempResolution":
        if (_this.getModel().getComponentValue("unit") === "Fahrenheit") {
          for (var i = 0; i < _OptionValues__WEBPACK_IMPORTED_MODULE_5__["resolutionOptions"].length; i++) {
            optionVal[i] = "+" + _this.celciusToFahrenheit(_OptionValues__WEBPACK_IMPORTED_MODULE_5__["resolutionOptions"][i]).toString();
          }

          options = optionVal;
        } else {
          for (var _i = 0; _i < _OptionValues__WEBPACK_IMPORTED_MODULE_5__["resolutionOptions"].length; _i++) {
            optionVal[_i] = "+" + _OptionValues__WEBPACK_IMPORTED_MODULE_5__["resolutionOptions"][_i].toString();
          }

          options = optionVal;
        }

        break;

      case "tempHysteresis":
        if (_this.getModel().getComponentValue("unit") === "Fahrenheit") {
          for (var _i2 = 0; _i2 < _OptionValues__WEBPACK_IMPORTED_MODULE_5__["hysteresisOptions"].length; _i2++) {
            optionVal[_i2] = _this.celciusToFahrenheit(_OptionValues__WEBPACK_IMPORTED_MODULE_5__["hysteresisOptions"][_i2]).toString();
          }

          options = optionVal;
        } else {
          for (var _i3 = 0; _i3 < _OptionValues__WEBPACK_IMPORTED_MODULE_5__["hysteresisOptions"].length; _i3++) {
            optionVal[_i3] = _OptionValues__WEBPACK_IMPORTED_MODULE_5__["hysteresisOptions"][_i3].toString();
          }

          options = optionVal;
        }

        break;
    }

    return options;
  });

  _defineProperty(this, "i2cClientAddrssConfig", function () {
    var _this$getModel$getSta, _this$getModel$getSta2, _this$getModel$getSta3;

    var initAddress = 0x18;
    var val = (_this$getModel$getSta = _this.getModel().getState()) === null || _this$getModel$getSta === void 0 ? void 0 : (_this$getModel$getSta2 = _this$getModel$getSta.main) === null || _this$getModel$getSta2 === void 0 ? void 0 : (_this$getModel$getSta3 = _this$getModel$getSta2.communication) === null || _this$getModel$getSta3 === void 0 ? void 0 : _this$getModel$getSta3.addPinConfig;

    if (val) {
      if (val[0]["pinA0"] === "VCC") {
        initAddress = initAddress | 0x01;
      }

      if (val[0]["pinA1"] === "VCC") {
        initAddress = initAddress | 0x02;
      }

      if (val[0]["pinA2"] === "VCC") {
        initAddress = initAddress | 0x04;
      }
    }

    return "0x" + Number(initAddress).toString(16).toUpperCase();
  });

  _defineProperty(this, "getTempDesc", function (componentName) {
    var changeDesc;

    switch (componentName) {
      case "tempUpperBoundary":
        if (_this.getModel().getComponentValue("unit") === "Fahrenheit") {
          changeDesc = "Temperature Upper Boundary (F)";
        }

        break;

      case "tempLowerBoundary":
        if (_this.getModel().getComponentValue("unit") === "Fahrenheit") {
          changeDesc = "Temperature Lower Boundary (F)";
        }

        break;

      case "tempCritBoundary":
        if (_this.getModel().getComponentValue("unit") === "Fahrenheit") {
          changeDesc = "Temperature Critical Boundary (F)";
        }

        break;

      case "tempResolution":
        if (_this.getModel().getComponentValue("unit") === "Fahrenheit") {
          changeDesc = "Temperature Resolution (F)";
        }

        break;

      case "tempHysteresis":
        if (_this.getModel().getComponentValue("unit") === "Fahrenheit") {
          changeDesc = "Temperature Hysteresis (F)";
        }

        break;
    }

    return changeDesc;
  });

  _defineProperty(this, "isComponentEnabled", function (componentName) {
    var isEnabled;

    switch (componentName) {
      case "tempHysteresis":
        {
          if (_this.getModel().isComponentValue("tempCritLock") === true || _this.getModel().isComponentValue("tempWinLock") === true) {
            isEnabled = false;
          }
        }
        break;

      case "tempUpperBoundary":
        if (_this.getModel().isComponentValue("tempWinLock") === true) {
          isEnabled = false;
        }

        break;

      case "tempLowerBoundary":
        if (_this.getModel().isComponentValue("tempWinLock") === true) {
          isEnabled = false;
        }

        break;

      case "tempCritBoundary":
        if (_this.getModel().isComponentValue("tempCritLock") === true) {
          isEnabled = false;
        }

        break;

      case "alertTrigger":
        if (_this.getModel().isComponentValue("alertControl") === false || _this.getModel().isComponentValue("tempWinLock") === true) {
          isEnabled = false;
        }

        break;

      case "alertMode":
        if (_this.getModel().isComponentValue("alertControl") === false || _this.getModel().getComponentValue("alertTrigger") === "Crit Only" || _this.getModel().isComponentValue("tempWinLock") === true || _this.getModel().isComponentValue("tempCritLock") === true) {
          isEnabled = false;
        }

        break;

      case "alertPolarity":
        if (_this.getModel().getComponentValue("alertControl") === false || _this.getModel().getComponentValue("tempWinLock") === true || _this.getModel().getComponentValue("tempCritLock") === true) {
          isEnabled = false;
        }

        break;

      case "alertControl":
        if (_this.getModel().getComponentValue("tempWinLock") === true || _this.getModel().getComponentValue("tempCritLock") === true) {
          isEnabled = false;
        }

        break;

      case "operation":
        isEnabled = _this.hasArgsForShutdown();
        break;

      default:
        break;
    }

    return isEnabled;
  });

  _defineProperty(this, "upperBoundaryGet", function () {
    var val = _this.getModel().getComponentValue("tempUpperBoundary");

    if (val) {
      if (_this.getModel().getComponentValue("unit") === "Fahrenheit") {
        val = _this.fahrenheitToCelsius(val);
      }
    }

    return val;
  });

  _defineProperty(this, "lowerBoundaryGet", function () {
    var val = _this.getModel().getComponentValue("tempLowerBoundary");

    if (val) {
      if (_this.getModel().getComponentValue("unit") === "Fahrenheit") {
        val = _this.fahrenheitToCelsius(val);
      }
    }

    return val;
  });

  _defineProperty(this, "critBoundaryGet", function () {
    var val = _this.getModel().getComponentValue("tempCritBoundary");

    if (val) {
      if (_this.getModel().getComponentValue("unit") === "Fahrenheit") {
        val = _this.fahrenheitToCelsius(val);
      }
    }

    return val;
  });

  _defineProperty(this, "fahrenheitToCelsius", function (tempVal) {
    tempVal = (tempVal - 32) * 5 / 9;
    return tempVal;
  });

  _defineProperty(this, "celciusToFahrenheit", function (tempVal) {
    tempVal = tempVal * 9 / 5 + 32;
    return tempVal;
  });

  _defineProperty(this, "opMode", function () {
    var state;

    if (_this.getModel().isComponentValue("operation") === true) {
      state = 1;
    } else {
      state = 0;
    }

    return state;
  });

  _defineProperty(this, "tempResolutionGet", function () {
    var val = _this.getModel().getComponentValue("tempResolution");

    var resolution;

    if (val) {
      if (_this.getModel().getComponentValue("unit") === "Fahrenheit") {
        if (val === "+32.1125") {
          val = "+" + _this.fahrenheitToCelsius(+val).toFixed(4).toString();
        } else if (val === "+32.225") {
          val = "+" + _this.fahrenheitToCelsius(+val).toFixed(3).toString();
        } else if (val === "+32.45") {
          val = "+" + _this.fahrenheitToCelsius(+val).toFixed(2).toString();
        } else {
          val = "+" + _this.fahrenheitToCelsius(+val).toFixed(1).toString();
        }
      }

      if (val === "+0.5") {
        resolution = "RESOLUTION_0_5";
      } else if (val === "+0.25") {
        resolution = "RESOLUTION_0_25";
      } else if (val === "+0.125") {
        resolution = "RESOLUTION_0_125";
      } else {
        resolution = "RESOLUTION_0_0625";
      }
    }

    return resolution;
  });

  _defineProperty(this, "tempHysteresisGet", function () {
    var val = _this.getModel().getComponentValue("tempHysteresis");

    var hysteresis;

    if (val) {
      if (_this.getModel().getComponentValue("unit") === "Fahrenheit") {
        if (val === "34.7") {
          val = _this.fahrenheitToCelsius(+val).toFixed(1).toString();
        } else {
          val = _this.fahrenheitToCelsius(+val).toFixed(0).toString();
        }
      }

      if (val === "1.5") {
        hysteresis = "HYSTERESIS_1_5";
      } else if (val === "3") {
        hysteresis = "HYSTERESIS_3";
      } else if (val === "6") {
        hysteresis = "HYSTERESIS_6";
      } else {
        hysteresis = "HYSTERESIS_0";
      }
    }

    return hysteresis;
  });

  _defineProperty(this, "winLock", function () {
    var state;

    if (_this.getModel().isComponentValue("tempWinLock") === true) {
      state = 1;
    } else {
      state = 0;
    }

    return state;
  });

  _defineProperty(this, "critLock", function () {
    var state;

    if (_this.getModel().isComponentValue("tempCritLock") === true) {
      state = 1;
    } else {
      state = 0;
    }

    return state;
  });

  _defineProperty(this, "alertControl", function () {
    var state;

    if (_this.getModel().isComponentValue("alertControl") === true) {
      state = 1;
    } else {
      state = 0;
    }

    return state;
  });

  _defineProperty(this, "alertSelect", function () {
    var state;

    if (_this.getModel().getComponentValue("alertTrigger") === "Crit Only") {
      state = 1;
    } else {
      state = 0;
    }

    return state;
  });

  _defineProperty(this, "alertMode", function () {
    var state;

    if (_this.getModel().getComponentValue("alertMode") === "Interrupt Mode") {
      state = 1;
    } else {
      state = 0;
    }

    return state;
  });

  _defineProperty(this, "alertPolarity", function () {
    var state;

    if (_this.getModel().getComponentValue("alertPolarity") === "Active-High") {
      state = 1;
    } else {
      state = 0;
    }

    return state;
  });

  _defineProperty(this, "overrideResolution", function () {
    var _this$getModel$getSta4, _this$getModel$getSta5, _this$getModel$getSta6;

    var val = (_this$getModel$getSta4 = _this.getModel().getState()) === null || _this$getModel$getSta4 === void 0 ? void 0 : (_this$getModel$getSta5 = _this$getModel$getSta4.main) === null || _this$getModel$getSta5 === void 0 ? void 0 : (_this$getModel$getSta6 = _this$getModel$getSta5.temperature) === null || _this$getModel$getSta6 === void 0 ? void 0 : _this$getModel$getSta6.tempResolution;

    var countDecimals = function countDecimals(value) {
      return value.toString().split(".")[1].length || 0;
    };

    if (val) {
      if (_this.getModel().getComponentValue("unit") === "Fahrenheit" && +val < 32.1125) {
        val = "+" + _this.celciusToFahrenheit(+val).toString();
      } else if (_this.getModel().getComponentValue("unit") === "Celsius" && +val > 0.5) {
        val = "+" + _this.fahrenheitToCelsius(+val).toFixed(countDecimals(+val)).toString();
      }
    }

    return val;
  });

  _defineProperty(this, "overrideHysteresis", function () {
    var _this$getModel$getSta7, _this$getModel$getSta8, _this$getModel$getSta9;

    var val = (_this$getModel$getSta7 = _this.getModel().getState()) === null || _this$getModel$getSta7 === void 0 ? void 0 : (_this$getModel$getSta8 = _this$getModel$getSta7.main) === null || _this$getModel$getSta8 === void 0 ? void 0 : (_this$getModel$getSta9 = _this$getModel$getSta8.temperature) === null || _this$getModel$getSta9 === void 0 ? void 0 : _this$getModel$getSta9.tempHysteresis;

    if (val) {
      if (_this.getModel().getComponentValue("unit") === "Fahrenheit" && +val < 32) {
        val = _this.celciusToFahrenheit(+val).toString();
      } else if (_this.getModel().getComponentValue("unit") === "Celsius" && +val > 6) {
        var _this$getModel$getSta10, _this$getModel$getSta11, _this$getModel$getSta12;

        if (((_this$getModel$getSta10 = _this.getModel().getState()) === null || _this$getModel$getSta10 === void 0 ? void 0 : (_this$getModel$getSta11 = _this$getModel$getSta10.main) === null || _this$getModel$getSta11 === void 0 ? void 0 : (_this$getModel$getSta12 = _this$getModel$getSta11.temperature) === null || _this$getModel$getSta12 === void 0 ? void 0 : _this$getModel$getSta12.tempHysteresis) === "34.7") {
          val = _this.fahrenheitToCelsius(+val).toFixed(1).toString();
        } else {
          val = _this.fahrenheitToCelsius(+val).toFixed(0).toString();
        }
      } else {
        val = undefined;
      }
    }

    return val;
  });

  _defineProperty(this, "isRedundant", function () {
    var _this$getModel$getCom16;

    var defName = "MCP98XX";
    var cName = (_this$getModel$getCom16 = _this.getModel().getComponentValue("componentName")) !== null && _this$getModel$getCom16 !== void 0 ? _this$getModel$getCom16 : "";
    return defName === cName;
  });

  _defineProperty(this, "isMSSP", function () {
    var _this$getModel$getImp3, _this$getModel$getImp4;

    var isMssp = false;
    var modName = (_this$getModel$getImp3 = _this.getModel().getImportValue("i2c_host_basic")) === null || _this$getModel$getImp3 === void 0 ? void 0 : _this$getModel$getImp3.moduleName;
    var modIns = (_this$getModel$getImp4 = _this.getModel().getImportValue("i2c_host_basic")) === null || _this$getModel$getImp4 === void 0 ? void 0 : _this$getModel$getImp4.moduleInstance.toString();

    if (modName === "MSSP".concat(modIns)) {
      isMssp = true;
    } else {
      isMssp = false;
    }

    return isMssp;
  });

  _defineProperty(this, "hasArgsForShutdown", function () {
    var defArgs = true;

    if (_this.getRequestedArg("lowPowerMode") !== undefined) {
      defArgs = false;
    } else {
      defArgs = true;
    }

    return defArgs;
  });

  this.dataModel = dataModel;
};

/***/ }),

/***/ "./src/OptionValues.ts":
/*!*****************************!*\
  !*** ./src/OptionValues.ts ***!
  \*****************************/
/*! exports provided: resolutionOptions, hysteresisOptions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resolutionOptions", function() { return resolutionOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hysteresisOptions", function() { return hysteresisOptions; });
var resolutionOptions = [0.0625, 0.125, 0.25, 0.5];
var hysteresisOptions = [0, 1.5, 3, 6];

/***/ }),

/***/ "./src/PinsLogic.ts":
/*!**************************!*\
  !*** ./src/PinsLogic.ts ***!
  \**************************/
/*! exports provided: getCompletePinData, getRowData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCompletePinData", function() { return getCompletePinData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRowData", function() { return getRowData; });
/* harmony import */ var _microchip_pin_standard_lib_pin_standard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microchip/pin-standard/lib/pin-standard */ "./node_modules/@microchip/pin-standard/lib/pin-standard.js");
/* harmony import */ var _microchip_pin_standard_lib_pin_standard__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microchip_pin_standard_lib_pin_standard__WEBPACK_IMPORTED_MODULE_0__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


// provide complete dynamic data for all pin rows. It overrides static pindata.json
var getCompletePinData = function getCompletePinData(appModel) {
  // way to programatically override the json data
  return {};
}; // overrides pin data for a particular row based on model.

function getRowData(appModel, rowData) {
  var _appModel$getComponen3;

  // Modify the rowData
  var returnRowData = rowData;

  if (rowData.name === "AlertPin") {
    var _appModel$getComponen, _appModel$getComponen2;

    returnRowData = _objectSpread(_objectSpread({}, returnRowData), {}, {
      module: (_appModel$getComponen = appModel.getComponentValue("device")) !== null && _appModel$getComponen !== void 0 ? _appModel$getComponen : "MCP98xx",
      attribs: [{
        aliasReEx: ".*",
        cname: "".concat((_appModel$getComponen2 = appModel.getComponentValue("componentName")) !== null && _appModel$getComponen2 !== void 0 ? _appModel$getComponen2 : "MCP98xx", "_ALERT"),
        analog: false
      }]
    });
  } // Get the action builder for the pin module


  var indicatorPinComponent = (_appModel$getComponen3 = appModel.getComponent("ioOutPin")) === null || _appModel$getComponen3 === void 0 ? void 0 : _appModel$getComponen3.component;
  var PCP = appModel.getPCPHelper;
  var neededAttribs = [_microchip_pin_standard_lib_pin_standard__WEBPACK_IMPORTED_MODULE_0__["pin_attribs_enum"].cname, _microchip_pin_standard_lib_pin_standard__WEBPACK_IMPORTED_MODULE_0__["pin_attribs_enum"].ioc];
  var returnRowActions = [];

  if (rowData.name === "AlertPin" && indicatorPinComponent) {
    returnRowActions = returnRowActions.concat(PCP === null || PCP === void 0 ? void 0 : PCP().stateActionBuilder(rowData).rowWithName(rowData.name).forComponent(indicatorPinComponent).addIfLockedProvideAttribs(".*", neededAttribs).addIfUnlockedProvideAttribs(".*", neededAttribs).build());
  }

  return _objectSpread(_objectSpread({}, returnRowData), {}, {
    actions: returnRowActions
  });
}

/***/ }),

/***/ "./src/features/helpers/AlertsHelper.ts":
/*!**********************************************!*\
  !*** ./src/features/helpers/AlertsHelper.ts ***!
  \**********************************************/
/*! exports provided: AlertHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertHelper", function() { return AlertHelper; });
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var AlertHelper = function AlertHelper() {
  _classCallCheck(this, AlertHelper);
};

_defineProperty(AlertHelper, "createAlertBuilder", function () {
  return new AlertBuilder();
});

var AlertBuilder = function AlertBuilder() {
  var _this = this;

  _classCallCheck(this, AlertBuilder);

  _defineProperty(this, "alerts", []);

  _defineProperty(this, "addConditionalAlert", function (value, matchRegEx, alertType, alertText) {
    var _value$toString;

    if (value === null || value === void 0 ? void 0 : (_value$toString = value.toString()) === null || _value$toString === void 0 ? void 0 : _value$toString.match(matchRegEx)) {
      _this.alerts.push({
        type: alertType,
        text: alertText
      });
    }

    return _this;
  });

  _defineProperty(this, "addStaticAlert", function (alertType, alertText) {
    _this.alerts.push({
      type: alertType,
      text: alertText
    });

    return _this;
  });

  _defineProperty(this, "buildAlerts", function () {
    return _this.alerts;
  });
};

/***/ }),

/***/ "./src/features/helpers/GuiHelper.ts":
/*!*******************************************!*\
  !*** ./src/features/helpers/GuiHelper.ts ***!
  \*******************************************/
/*! exports provided: GuiHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GuiHelper", function() { return GuiHelper; });
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var GuiHelper = function GuiHelper() {
  _classCallCheck(this, GuiHelper);
};

_defineProperty(GuiHelper, "createDefaultValueBuilder", function () {
  return new DefaultValueBuilder();
});

_defineProperty(GuiHelper, "createCalculatedValueBuilder", function () {
  return new CalculatedValueBuilder();
});

_defineProperty(GuiHelper, "createCustomUiErrorBuilder", function (componentName) {
  return new CustomUiErrorBuilder(componentName);
});

var DefaultValueBuilder = function DefaultValueBuilder() {
  var _this = this;

  _classCallCheck(this, DefaultValueBuilder);

  _defineProperty(this, "defaultValues", {});

  _defineProperty(this, "addDefaultValue", function (componentName, value) {
    _this.defaultValues[componentName] = value;
    return _this;
  });

  _defineProperty(this, "buildDefaultValues", function () {
    return _this.defaultValues;
  });
};

var CalculatedValueBuilder = function CalculatedValueBuilder() {
  var _this2 = this;

  _classCallCheck(this, CalculatedValueBuilder);

  _defineProperty(this, "value", void 0);

  _defineProperty(this, "addConditionalValue", function (matchValue, matchRegEx, value) {
    var _matchValue$toString;

    if (matchValue === null || matchValue === void 0 ? void 0 : (_matchValue$toString = matchValue.toString()) === null || _matchValue$toString === void 0 ? void 0 : _matchValue$toString.match(matchRegEx)) {
      _this2.value = value;
    }

    return _this2;
  });

  _defineProperty(this, "addUnconditionalValue", function (value) {
    _this2.value = value;
    return _this2;
  });

  _defineProperty(this, "buildCalculatedValue", function () {
    return _this2.value;
  });
};

var CustomUiErrorBuilder = function CustomUiErrorBuilder(_componentName) {
  var _this3 = this;

  _classCallCheck(this, CustomUiErrorBuilder);

  _defineProperty(this, "customError", void 0);

  _defineProperty(this, "componentName", "");

  _defineProperty(this, "addCustomError", function (componentName, errorName, errorMessage) {
    if (_this3.componentName.match(componentName)) {
      var _this3$customError;

      _this3.customError = ((_this3$customError = _this3.customError) !== null && _this3$customError !== void 0 ? _this3$customError : []).concat({
        name: errorName,
        message: errorMessage
      });
    }

    return _this3;
  });

  _defineProperty(this, "buildCustomUiError", function () {
    return _this3.customError;
  });

  this.componentName = _componentName;
};

/***/ }),

/***/ "./src/features/helpers/ImportHelperTemplate.ts":
/*!******************************************************!*\
  !*** ./src/features/helpers/ImportHelperTemplate.ts ***!
  \******************************************************/
/*! exports provided: ArgumentsBuilder, ResultssBuilder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ArgumentsBuilder", function() { return ArgumentsBuilder; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResultssBuilder", function() { return ResultssBuilder; });
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var ArgumentsBuilder = /*#__PURE__*/function () {
  function ArgumentsBuilder() {
    var _this = this;

    _classCallCheck(this, ArgumentsBuilder);

    _defineProperty(this, "args", {});

    _defineProperty(this, "buildArguments", function () {
      return _this.args;
    });
  }

  _createClass(ArgumentsBuilder, [{
    key: "addArgument",
    value: function addArgument(key, value) {
      this.args[key] = value;
      return this;
    }
  }]);

  return ArgumentsBuilder;
}();
var ResultssBuilder = /*#__PURE__*/function () {
  function ResultssBuilder() {
    var _this2 = this;

    _classCallCheck(this, ResultssBuilder);

    _defineProperty(this, "results", {});

    _defineProperty(this, "buildResults", function () {
      return _this2.results;
    });
  }

  _createClass(ResultssBuilder, [{
    key: "addResult",
    value: function addResult(key, value) {
      this.results[key] = value;
      return this;
    }
  }]);

  return ResultssBuilder;
}();

/***/ }),

/***/ "./src/features/helpers/ImportsHelpers.ts":
/*!************************************************!*\
  !*** ./src/features/helpers/ImportsHelpers.ts ***!
  \************************************************/
/*! exports provided: ImportsHelpers */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImportsHelpers", function() { return ImportsHelpers; });
/* harmony import */ var _imports_i2c_host_basic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../imports/i2c_host_basic */ "./src/features/imports/i2c_host_basic.ts");

var ImportsHelpers = {
  i2c_host_basic: _imports_i2c_host_basic__WEBPACK_IMPORTED_MODULE_0__["MyImportHelper"]
};

/***/ }),

/***/ "./src/features/helpers/TemplateHelper.ts":
/*!************************************************!*\
  !*** ./src/features/helpers/TemplateHelper.ts ***!
  \************************************************/
/*! exports provided: TemplateHelper */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TemplateHelper", function() { return TemplateHelper; });
/* harmony import */ var _microchip_scf_interface__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microchip/scf-interface */ "./node_modules/@microchip/scf-interface/lib/index.js");
/* harmony import */ var _microchip_scf_interface__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microchip_scf_interface__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _generated_module_src_Utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../generated_module/src/Utils */ "./generated_module/src/Utils.ts");
var _temp;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



var TemplateHelper = function TemplateHelper() {
  _classCallCheck(this, TemplateHelper);
};

_defineProperty(TemplateHelper, "createTemplateDataBuilder", function (model) {
  return new TemplateDataBuilder(model);
});

_defineProperty(TemplateHelper, "createTemplateApisBuilder", function () {
  return new TemplateApisBuilder();
});

_defineProperty(TemplateHelper, "createTemplateFileBuilder", function (src) {
  return new TemplateFileBuilder(src);
});

var TemplateDataBuilder = function TemplateDataBuilder(model) {
  var _this = this;

  _classCallCheck(this, TemplateDataBuilder);

  _defineProperty(this, "data", {});

  _defineProperty(this, "model", void 0);

  _defineProperty(this, "buildTemplateData", function () {
    return _this.data;
  });

  _defineProperty(this, "addGenericData", function (key, value) {
    _this.data[key] = value;
    return _this;
  });

  _defineProperty(this, "addGuiData", function () {
    for (var _len = arguments.length, componentNames = new Array(_len), _key = 0; _key < _len; _key++) {
      componentNames[_key] = arguments[_key];
    }

    componentNames.forEach(function (key) {
      _this.data[key] = _this.model.getComponentValue(key);
    });
    return _this;
  });

  _defineProperty(this, "addAllImportData", function () {
    Object(_generated_module_src_Utils__WEBPACK_IMPORTED_MODULE_1__["getKeys"])(_this.model.getImports()).forEach(function (key) {
      return _this.data[key] = _this.model.getImportValue(key);
    });
    return _this;
  });

  _defineProperty(this, "addImportData", function (importName) {
    _this.data[importName] = _this.model.getImportValue(importName);
    return _this;
  });

  _defineProperty(this, "addAllRegisterData", function () {
    var _this$data$register, _this$model$getRegist;

    _this.data["register"] = _objectSpread(_objectSpread({}, (_this$data$register = _this.data["register"]) !== null && _this$data$register !== void 0 ? _this$data$register : {}), (_this$model$getRegist = _this.model.getRegisterValues()) !== null && _this$model$getRegist !== void 0 ? _this$model$getRegist : {});
    return _this;
  });

  _defineProperty(this, "addRegisterData", function (registerName) {
    var _this$data$register2, _this$model$getRegist2;

    _this.data["register"] = _objectSpread(_objectSpread({}, (_this$data$register2 = _this.data["register"]) !== null && _this$data$register2 !== void 0 ? _this$data$register2 : {}), {}, _defineProperty({}, registerName, (_this$model$getRegist2 = _this.model.getRegisterValues()) === null || _this$model$getRegist2 === void 0 ? void 0 : _this$model$getRegist2[registerName]));
    return _this;
  });

  _defineProperty(this, "addAllInterruptData", function () {
    var _this$data$interrupt, _this$model$getInterr;

    _this.data["interrupt"] = _objectSpread(_objectSpread({}, (_this$data$interrupt = _this.data["interrupt"]) !== null && _this$data$interrupt !== void 0 ? _this$data$interrupt : {}), (_this$model$getInterr = _this.model.getInterrupts()) !== null && _this$model$getInterr !== void 0 ? _this$model$getInterr : {});
    return _this;
  });

  _defineProperty(this, "addInterruptData", function (interruptName) {
    var _this$data$interrupt2, _this$model$getInterr2;

    _this.data["interrupt"] = _objectSpread(_objectSpread({}, (_this$data$interrupt2 = _this.data["interrupt"]) !== null && _this$data$interrupt2 !== void 0 ? _this$data$interrupt2 : {}), {}, _defineProperty({}, interruptName, (_this$model$getInterr2 = _this.model.getInterrupts()) === null || _this$model$getInterr2 === void 0 ? void 0 : _this$model$getInterr2[interruptName]));
    return _this;
  });

  _defineProperty(this, "addHeaderFileData", function (key, header, condition) {
    var _this$data$headers;

    if (condition) {
      var _condition$value, _condition$value$toSt;

      if (!((_condition$value = condition.value) === null || _condition$value === void 0 ? void 0 : (_condition$value$toSt = _condition$value.toString()) === null || _condition$value$toSt === void 0 ? void 0 : _condition$value$toSt.match(condition.matchRegEx))) return _this;
    }

    _this.data["headers"] = _objectSpread(_objectSpread({}, (_this$data$headers = _this.data["headers"]) !== null && _this$data$headers !== void 0 ? _this$data$headers : {}), {}, _defineProperty({}, key, "".concat(header.path).concat(header.name)));
    return _this;
  });

  _defineProperty(this, "addResolvePath", function (key, relativePath) {
    var _this$data$resolvePat;

    _this.data["resolvePath"] = _objectSpread(_objectSpread({}, (_this$data$resolvePat = _this.data["resolvePath"]) !== null && _this$data$resolvePat !== void 0 ? _this$data$resolvePat : {}), {}, _defineProperty({}, key, relativePath.replace(/([^/]*\/)/g, "../")));
    return _this;
  });

  _defineProperty(this, "addFirmwareApiData", function (key, firmwareApis) {
    var _this$data$api, _this$data$simpleApi;

    _this.data = _objectSpread(_objectSpread({}, _this.data), {}, {
      api: _objectSpread(_objectSpread({}, (_this$data$api = _this.data["api"]) !== null && _this$data$api !== void 0 ? _this$data$api : {}), {}, _defineProperty({}, key, firmwareApis.api)),
      simpleApi: _objectSpread(_objectSpread({}, (_this$data$simpleApi = _this.data["simpleApi"]) !== null && _this$data$simpleApi !== void 0 ? _this$data$simpleApi : {}), {}, _defineProperty({}, key, firmwareApis.simpleApi))
    });
    return _this;
  });

  this.model = model;
};

var TemplateApisBuilder = function TemplateApisBuilder() {
  var _this2 = this;

  _classCallCheck(this, TemplateApisBuilder);

  _defineProperty(this, "apis", {});

  _defineProperty(this, "headerFiles", []);

  _defineProperty(this, "prefix", "");

  _defineProperty(this, "addApiPrefix", function () {
    var prefix = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";
    _this2.prefix = prefix;
    return _this2;
  });

  _defineProperty(this, "addApisData", function (apis) {
    _this2.apis = _objectSpread(_objectSpread({}, _this2.apis), apis);
    return _this2;
  });

  _defineProperty(this, "addApiDataFor", function (key) {
    return new TemplateApisBuilder.createApiBuilder(_this2, key);
  });

  _defineProperty(this, "addHeaderFile", function (path, name) {
    _this2.headerFiles.push({
      path: path,
      name: name
    });

    return _this2;
  });

  _defineProperty(this, "buildFirmwareApiPayload", function () {
    return {
      api: _this2.apis,
      simpleApi: _this2.buildSimpleApis(),
      headerFiles: _this2.headerFiles
    };
  });

  _defineProperty(this, "buildApis", function () {
    return _this2.apis;
  });

  _defineProperty(this, "buildSimpleApis", function () {
    return Object(_microchip_scf_interface__WEBPACK_IMPORTED_MODULE_0__["buildSimpleApi"])(_this2.apis);
  });

  _defineProperty(this, "buildHeaderFiles", function () {
    return _this2.headerFiles;
  });
};

_defineProperty(TemplateApisBuilder, "createApiBuilder", (_temp = function ApiBuilder(superThis, apiFor) {
  var _this4 = this;

  _classCallCheck(this, ApiBuilder);

  _defineProperty(this, "apiFor", "");

  _defineProperty(this, "superThis", void 0);

  _defineProperty(this, "apis", {});

  _defineProperty(this, "addApiDataFor", function (key) {
    _this4.apiFor = key;
    _this4.apis[key] = {
      name: "".concat(_this4.superThis.prefix, "_").concat(key),
      returns: "void"
    };
    return _this4;
  });

  _defineProperty(this, "addName", function (name) {
    _this4.apis[_this4.apiFor]["name"] = "".concat(_this4.superThis.prefix, "_").concat(name);
    return _this4;
  });

  _defineProperty(this, "addReturns", function (returns) {
    _this4.apis[_this4.apiFor]["returns"] = returns;
    return _this4;
  });

  _defineProperty(this, "addArgument", function (type, name) {
    var _this4$apis$_this4$ap, _this4$apis$_this4$ap2;

    _this4.apis[_this4.apiFor]["arguments"] = ((_this4$apis$_this4$ap = (_this4$apis$_this4$ap2 = _this4.apis[_this4.apiFor]) === null || _this4$apis$_this4$ap2 === void 0 ? void 0 : _this4$apis$_this4$ap2.arguments) !== null && _this4$apis$_this4$ap !== void 0 ? _this4$apis$_this4$ap : []).concat({
      type: type,
      name: name
    });
    return _this4;
  });

  _defineProperty(this, "addDocumentation", function (documentations) {
    _this4.apis[_this4.apiFor]["documentation"] = documentations;
    return _this4;
  });

  _defineProperty(this, "buildAllAddedApiData", function () {
    _this4.superThis.apis = _objectSpread(_objectSpread({}, _this4.superThis.apis), _this4.apis);
    return _this4.superThis;
  });

  this.superThis = superThis;
  this.apiFor = apiFor;
  this.apis[apiFor] = {
    name: "".concat(this.superThis.prefix, "_").concat(apiFor),
    returns: "void"
  };
}, _temp));

var TemplateFileBuilder = function TemplateFileBuilder(src) {
  var _this3 = this;

  _classCallCheck(this, TemplateFileBuilder);

  _defineProperty(this, "src", "");

  _defineProperty(this, "dest", void 0);

  _defineProperty(this, "addTemplateFileInfo", function (srcMatchRegEx, path, fileName) {
    if (_this3.src.match(srcMatchRegEx)) {
      _this3.dest = "".concat(path()).concat(fileName());
    }

    return _this3;
  });

  _defineProperty(this, "buildTemplateFile", function () {
    var _this3$dest;

    return (_this3$dest = _this3.dest) !== null && _this3$dest !== void 0 ? _this3$dest : "";
  });

  this.src = src;
};

/***/ }),

/***/ "./src/features/imports/i2c_host_basic.ts":
/*!************************************************!*\
  !*** ./src/features/imports/i2c_host_basic.ts ***!
  \************************************************/
/*! exports provided: getImportName, createArgumentsBuilder, createResultsBuilder, getFirmwareApi, getPayload, MyImportHelper, MyArgumentsBuilder, MyResultsBuilder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getImportName", function() { return getImportName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createArgumentsBuilder", function() { return createArgumentsBuilder; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createResultsBuilder", function() { return createResultsBuilder; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFirmwareApi", function() { return getFirmwareApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPayload", function() { return getPayload; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyImportHelper", function() { return MyImportHelper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyArgumentsBuilder", function() { return MyArgumentsBuilder; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyResultsBuilder", function() { return MyResultsBuilder; });
/* harmony import */ var _helpers_ImportHelperTemplate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../helpers/ImportHelperTemplate */ "./src/features/helpers/ImportHelperTemplate.ts");
/* harmony import */ var _microchip_i2c_host_basic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microchip/i2c-host-basic */ "./node_modules/@microchip/i2c-host-basic/lib/src/index.js");
/* harmony import */ var _microchip_i2c_host_basic__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microchip_i2c_host_basic__WEBPACK_IMPORTED_MODULE_1__);
function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function () { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



var getImportName = function getImportName() {
  return "i2c_host_basic";
};
var createArgumentsBuilder = function createArgumentsBuilder() {
  return new MyArgumentsBuilder();
};
var createResultsBuilder = function createResultsBuilder() {
  return new MyResultsBuilder();
};
var getFirmwareApi = function getFirmwareApi(model) {
  var _getPayload$interface, _getPayload;

  return (_getPayload$interface = (_getPayload = getPayload(model)) === null || _getPayload === void 0 ? void 0 : _getPayload.interfaceApi) !== null && _getPayload$interface !== void 0 ? _getPayload$interface : _microchip_i2c_host_basic__WEBPACK_IMPORTED_MODULE_1__["Interface"].createFirmwareApi();
};
var getPayload = function getPayload(model) {
  return model.getImportValue(getImportName());
};
var MyImportHelper = {
  getImportName: getImportName,
  getFirmwareApi: getFirmwareApi,
  getPayload: getPayload,
  createArgumentsBuilder: createArgumentsBuilder,
  createResultsBuilder: createResultsBuilder
};
var MyArgumentsBuilder = /*#__PURE__*/function (_ArgumentsBuilder) {
  _inherits(MyArgumentsBuilder, _ArgumentsBuilder);

  var _super = _createSuper(MyArgumentsBuilder);

  function MyArgumentsBuilder() {
    var _this;

    _classCallCheck(this, MyArgumentsBuilder);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));

    _defineProperty(_assertThisInitialized(_this), "addRequestedSpeed_Hz", function (value) {
      var _this$args;

      _this.args = _objectSpread(_objectSpread({}, (_this$args = _this.args) !== null && _this$args !== void 0 ? _this$args : {}), {}, {
        requestedSpeed_Hz: value
      });
      return _assertThisInitialized(_this);
    });

    _defineProperty(_assertThisInitialized(_this), "addInterruptDriven", function (value) {
      var _this$args2;

      _this.args = _objectSpread(_objectSpread({}, (_this$args2 = _this.args) !== null && _this$args2 !== void 0 ? _this$args2 : {}), {}, {
        interruptDriven: value
      });
      return _assertThisInitialized(_this);
    });

    _defineProperty(_assertThisInitialized(_this), "addI2cHostCallbackEvent", function (name, header) {
      var _this$args3;

      _this.args = _objectSpread(_objectSpread({}, (_this$args3 = _this.args) !== null && _this$args3 !== void 0 ? _this$args3 : {}), {}, {
        i2cHostCallbackEvent: {
          name: name,
          header: header
        }
      });
      return _assertThisInitialized(_this);
    });

    return _this;
  }

  return MyArgumentsBuilder;
}(_helpers_ImportHelperTemplate__WEBPACK_IMPORTED_MODULE_0__["ArgumentsBuilder"]);
var MyResultsBuilder = /*#__PURE__*/function (_ResultssBuilder) {
  _inherits(MyResultsBuilder, _ResultssBuilder);

  var _super2 = _createSuper(MyResultsBuilder);

  function MyResultsBuilder() {
    var _this2;

    _classCallCheck(this, MyResultsBuilder);

    for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      args[_key3] = arguments[_key3];
    }

    _this2 = _super2.call.apply(_super2, [this].concat(args));

    _defineProperty(_assertThisInitialized(_this2), "addCustomName", function (value) {
      var _this2$results;

      _this2.results = _objectSpread(_objectSpread({}, (_this2$results = _this2.results) !== null && _this2$results !== void 0 ? _this2$results : {}), {}, {
        customName: value
      });
      return _assertThisInitialized(_this2);
    });

    return _this2;
  }

  return MyResultsBuilder;
}(_helpers_ImportHelperTemplate__WEBPACK_IMPORTED_MODULE_0__["ResultssBuilder"]);

/***/ }),

/***/ "./src/interfaces/mcp98xx-basic.ts":
/*!*****************************************!*\
  !*** ./src/interfaces/mcp98xx-basic.ts ***!
  \*****************************************/
/*! exports provided: getInterfaceId, createMock, createApi, createFirmwareApi, Interface */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getInterfaceId", function() { return getInterfaceId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createMock", function() { return createMock; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createApi", function() { return createApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createFirmwareApi", function() { return createFirmwareApi; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Interface", function() { return Interface; });
/* harmony import */ var _microchip_scf_interface__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microchip/scf-interface */ "./node_modules/@microchip/scf-interface/lib/index.js");
/* harmony import */ var _microchip_scf_interface__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microchip_scf_interface__WEBPACK_IMPORTED_MODULE_0__);

var getInterfaceId = function getInterfaceId() {
  return {
    name: "mcp98xx-basic",
    version: "0.1.0"
  };
};

var createPrototypeImport = function createPrototypeImport() {
  return {
    interfaceId: getInterfaceId()
  };
};

var createPrototypeExport = function createPrototypeExport() {
  return {
    interfaces: [{
      interfaceId: getInterfaceId()
    }]
  };
};

var createMock = function createMock() {
  return {
    interfaceId: getInterfaceId(),
    payload: {
      componentName: "mcp98xx",
      device: "MCP9808",
      shutdownMode: false,
      tempUnit: "Celsius",
      i2cClientAddress: "0x18",
      tempWinLock: false,
      tempCritLock: false,
      tempResolution: "+0.0625",
      tempHysteresis: "0",
      tempLowerBoundary: -40,
      tempUpperBoundary: 0,
      tempCritBoundary: 125,
      alertCtrl: false,
      alertSlct: "Upper/Lower/Crit",
      alertMd: "Comparator Mode",
      alertPol: "Active-High"
    },
    args: {
      requestId: {
        componentName: "mcp98xx",
        device: "MCP9808",
        shutdownMode: false,
        tempUnit: "Celsius",
        i2cClientAddress: "0x19",
        tempWinLock: false,
        tempCritLock: false,
        tempResolution: "+0.0625",
        tempHysteresis: "0",
        tempLowerBoundary: -40,
        tempUpperBoundary: 0,
        tempCritBoundary: 125,
        alertCtrl: false,
        alertSlct: "Upper/Lower/Crit",
        alertMd: "Comparator Mode",
        alertPol: "Active-High"
      }
    }
  };
};
var createApi = function createApi(prefix) {
  return {
    Initialize: {
      name: prefix + "_Initialize",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }, {
        name: "deviceInit",
        type: prefix.toUpperCase() + "_DEVICE_INIT_t"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    TemperatureRead: {
      name: prefix + "_TemperatureRawValueRead",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }, {
        name: "tempRawVal",
        type: "uint16_t*"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    shdnModeEnable: {
      name: prefix + "_ShutdownModeEnable",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    shdnModeDisable: {
      name: prefix + "_ShutdownModeDisable",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    sensorConfigSet: {
      name: prefix + "_SensorConfigSet",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }, {
        name: "sensorConfigReg",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    sensorConfigGet: {
      name: prefix + "_SensorConfigGet",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }, {
        name: "sensorConfigVal",
        type: prefix.toUpperCase() + "_CONFIG_REG_PTR"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    hysteresisSet: {
      name: prefix + "_TemperatureHysteresisSet",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }, {
        name: "tempHysteresisVal",
        type: prefix.toUpperCase() + "_HYSTERESIS_VALUE_t"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    tempCritLock: {
      name: prefix + "_TemperatureCriticalLockEnable",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    tempWinLock: {
      name: prefix + "_TemperatureWindowLockEnable",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    alertClr: {
      name: prefix + "_AlertOutputClear",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    alertStat: {
      name: prefix + "_AlertOutputStatusRead",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }, {
        name: "alertStat",
        type: "bool*"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    alertConfigSet: {
      name: prefix + "_AlertConfigurationSet",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }, {
        name: "alertConfig",
        type: prefix.toUpperCase() + "_ALERT_CONFIG_t"
      }, {
        name: "alertSet",
        type: "uint8_t"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    tempBoundarySet: {
      name: prefix + "_TemperatureBoundarySet",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }, {
        name: "boundary",
        type: prefix.toUpperCase() + "_TEMP_BOUNDARY_t"
      }, {
        name: "tempVal",
        type: "float"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    tempBoundaryGet: {
      name: prefix + "_TemperatureBoundaryGet",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }, {
        name: "boundary",
        type: prefix.toUpperCase() + "_TEMP_BOUNDARY_t"
      }, {
        name: "tempVal",
        type: "float*"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    tempRawToCelsius: {
      name: prefix + "_TemperatureRawToCelsius",
      arguments: [{
        name: "rawVal",
        type: "uint16_t"
      }],
      returns: "float"
    },
    tempRawToFahrenheit: {
      name: prefix + "_TemperatureRawToFahrenheit",
      arguments: [{
        name: "rawVal",
        type: "uint16_t"
      }],
      returns: "float"
    },
    ambientTempCelsius: {
      name: prefix + "_AmbientTemperatureCelsiusRead",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }, {
        name: "ambientTemp",
        type: "float*"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    ambientTempFahrenheit: {
      name: prefix + "_AmbientTemperatureFahrenheitRead",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }, {
        name: "ambientTemp",
        type: "float*"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    tempResolutionSet: {
      name: prefix + "_TempResolutionSet",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }, {
        name: "tempResolution",
        type: prefix.toUpperCase() + "_RESOLUTION_VALUE_t"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    tempResolutionGet: {
      name: prefix + "_TempResolutionGet",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }, {
        name: "tempResolutionVal",
        type: "uint8_t*"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    deviceInfoGet: {
      name: prefix + "_DeviceInfoGet",
      arguments: [{
        name: "devicePtr",
        type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR"
      }, {
        name: "deviceInfo",
        type: prefix.toUpperCase() + "_DEVICE_INFORMATION_t"
      }, {
        name: "deviceInfoVal",
        type: "uint16_t*"
      }],
      returns: prefix.toUpperCase() + "_STATUS_t"
    },
    celsiusToFahrenheit: {
      name: prefix + "_CelsiusToFahrenheit",
      arguments: [{
        name: "tempVal",
        type: "float"
      }],
      returns: "float"
    },
    fahrenheitToCelsius: {
      name: prefix + "_FahrenheitToCelsius",
      arguments: [{
        name: "tempVal",
        type: "float"
      }],
      returns: "float"
    }
  };
};
var createFirmwareApi = function createFirmwareApi(moduleName, headerFiles, createCustomApi) {
  var prefix = moduleName ? moduleName : "undefined";
  var api = createCustomApi ? createCustomApi() : createApi(prefix);
  return {
    api: api,
    simpleApi: _microchip_scf_interface__WEBPACK_IMPORTED_MODULE_0__["buildSimpleApi"](api),
    headerFiles: headerFiles ? headerFiles : [{
      name: prefix.toLowerCase() + ".h",
      path: "temperature-mcp98xx/"
    }, {
      name: prefix.toLowerCase() + "_i2c.h",
      path: "temperature-mcp98xx/"
    }, {
      name: prefix.toLowerCase() + "_config.h",
      path: "temperature-mcp98xx/"
    }, {
      name: "mcp98xx_types.h",
      path: "temperature-mcp98xx/"
    }, {
      name: "mcp98xx_interface.h",
      path: "temperature-mcp98xx/"
    }]
  };
};
var Interface = {
  createPrototypeExport: createPrototypeExport,
  createPrototypeImport: createPrototypeImport,
  getInterfaceId: getInterfaceId,
  createMock: createMock,
  createFirmwareApi: createFirmwareApi
};

/***/ }),

/***/ "./src/moduleConfig.json":
/*!*******************************!*\
  !*** ./src/moduleConfig.json ***!
  \*******************************/
/*! exports provided: moduleName, deviceType, isSingletonPerDevice, hasPins, booleanValues, help, UIGroups, UIOrder, tabs, templates, imports, exports, softwareData, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"moduleName\":\"I2C Temp Sensor MCP98xx\",\"deviceType\":\"PIC\",\"isSingletonPerDevice\":true,\"hasPins\":true,\"booleanValues\":{\"true\":\"enabled\",\"false\":\"disabled\"},\"help\":{\"url\":\"v2/keyword-lookup?keyword=scf-driver-mcp98xx&redirect=true\",\"tooltip\":\"Click here to open documentation.\"},\"UIGroups\":{\"software\":\"Software Settings\",\"hardware\":\"Hardware Settings\",\"general\":\"General Settings\",\"communication\":\"Communication Settings\",\"temperature\":\"Temperature Settings\",\"alert\":\"Alert Settings\"},\"UIOrder\":{\"temperature\":[\"*\"],\"software\":[\"*\"],\"communication\":[\"*\"],\"general\":[\"*\"],\"alert\":[\"*\"]},\"tabs\":{\"main\":\"Easy View\"},\"templates\":[{\"src\":\"output/mcp98xx_i2c.c.ftl\",\"dest\":\"temperature-mcp98xx/src/${sourceFileName}\"},{\"src\":\"output/mcp98xx_i2c.h.ftl\",\"dest\":\"temperature-mcp98xx/${headerFileName}\"},{\"src\":\"output/mcp98xx_types.h.ftl\",\"dest\":\"temperature-mcp98xx/mcp98xx_types.h\"},{\"src\":\"output/mcp98xx_interface.h.ftl\",\"dest\":\"temperature-mcp98xx/mcp98xx_interface.h\"},{\"src\":\"output/submodules/mcp98xx_c_driver/src/mcp9808.c.ftl\",\"dest\":\"temperature-mcp98xx/src/${sourceFileName}\"},{\"src\":\"output/submodules/mcp98xx_c_driver/mcp9808.h.ftl\",\"dest\":\"temperature-mcp98xx/${headerFileName}\"},{\"src\":\"output/submodules/mcp98xx_c_driver/mcp9808_config.h.ftl\",\"dest\":\"temperature-mcp98xx/mcp9808_config.h\",\"isGeneratableProperty\":\"generateFile\"}],\"imports\":{\"i2c_host_basic\":{\"import\":{\"interfaceId\":{\"name\":\"i2c-host-basic\",\"version\":\"^1.*\"},\"isAutoAssignable\":false},\"fullyTyped\":true,\"nodeModule\":{\"importName\":\"i2c_host_basic\",\"node\":\"@microchip/i2c-host-basic\"}},\"pin_standard\":{\"import\":{\"interfaceId\":{\"name\":\"pin-standard\",\"version\":\"^0.*\"}}},\"device_meta\":{\"import\":{\"interfaceId\":{\"name\":\"device-meta\",\"version\":\"1.*\"}}}},\"exports\":{\"mcp98xx_interface\":{\"interfaces\":[{\"interfaceId\":{\"name\":\"mcp98xx-basic\",\"version\":\"0.1.0\"}}]},\"temp_sensor_interface\":{\"interfaces\":[{\"interfaceId\":{\"name\":\"temp-sensor\",\"version\":\"1.0.1\"},\"nodeModule\":{\"importName\":\"temp_sensor\",\"node\":\"@microchip/temp-sensor\"}}],\"handleLimit\":1}},\"softwareData\":{\"componentName\":{\"name\":\"componentName\",\"category\":\"software\",\"description\":\"Custom Name\",\"type\":\"string\",\"defaultValue\":\"MCP9808\",\"group\":\"software\",\"tabs\":[\"main\"],\"validation\":true},\"device\":{\"name\":\"device\",\"category\":\"software\",\"description\":\"Select Device\",\"type\":\"ComboBox\",\"defaultValue\":{\"value\":\"MCP9808\",\"options\":[\"MCP9808\"]},\"group\":\"hardware\",\"tabs\":[\"main\"]},\"tempResolution\":{\"name\":\"tempResolution\",\"category\":\"software\",\"description\":\"Temperature Resolution (C)\",\"type\":\"ComboBox\",\"defaultValue\":{\"value\":\"+0.0625\",\"options\":[]},\"group\":\"temperature\",\"tabs\":[\"main\"]},\"tempHysteresis\":{\"name\":\"tempHysteresis\",\"category\":\"software\",\"description\":\"Temperature Hysteresis (C)\",\"type\":\"ComboBox\",\"defaultValue\":{\"value\":\"0\",\"options\":[]},\"group\":\"temperature\",\"tabs\":[\"main\"]},\"tempUpperBoundary\":{\"name\":\"tempUpperBoundary\",\"category\":\"software\",\"description\":\"Temperature Upper Boundary (C)\",\"type\":\"number\",\"defaultValue\":0,\"validation\":true,\"group\":\"temperature\",\"tabs\":[\"main\"]},\"tempLowerBoundary\":{\"name\":\"tempLowerBoundary\",\"category\":\"software\",\"description\":\"Temperature Lower Boundary (C)\",\"type\":\"number\",\"defaultValue\":0,\"validation\":true,\"group\":\"temperature\",\"tabs\":[\"main\"]},\"tempCritBoundary\":{\"name\":\"tempCritBoundary\",\"category\":\"software\",\"description\":\"Temperature Critical Boundary (C)\",\"type\":\"number\",\"defaultValue\":0,\"validation\":true,\"group\":\"temperature\",\"tabs\":[\"main\"]},\"tempWinLock\":{\"name\":\"tempWinLock\",\"category\":\"software\",\"description\":\"Temperature Window Lock\",\"type\":\"boolean\",\"defaultValue\":false,\"group\":\"temperature\",\"tabs\":[\"main\"]},\"tempCritLock\":{\"name\":\"tempCritLock\",\"category\":\"software\",\"description\":\"Temperature Critical Lock\",\"type\":\"boolean\",\"defaultValue\":false,\"group\":\"temperature\",\"tabs\":[\"main\"]},\"i2c_host_basic\":{\"name\":\"i2c_host_basic\",\"category\":\"import\",\"description\":\"I2C Host Dependency\",\"type\":\"ComboBox\",\"importId\":\"i2c_host_basic\",\"group\":\"communication\",\"isVisibleProperty\":\"isHostSelectable\",\"tabs\":[\"main\"]},\"i2cClientAdd\":{\"name\":\"i2cClientAdd\",\"category\":\"software\",\"description\":\"I2C Client Address\",\"type\":\"string\",\"defaultValue\":\"0x18\",\"group\":\"communication\",\"tabs\":[\"main\"],\"uiBehavior\":{\"readonly\":true}},\"addPinConfig\":{\"name\":\"addPinConfig\",\"category\":\"table\",\"type\":\"object\",\"description\":\"Address Pin Configuration\",\"group\":\"communication\",\"tabs\":[\"main\"],\"displayHeadersHorizontally\":true,\"columns\":{\"pinA2\":{\"title\":\"A2\",\"type\":\"ComboBox\",\"defaultValue\":{\"value\":\"GND\",\"options\":[\"GND\",\"VCC\"]}},\"pinA1\":{\"title\":\"A1\",\"type\":\"ComboBox\",\"defaultValue\":{\"value\":\"GND\",\"options\":[\"GND\",\"VCC\"]}},\"pinA0\":{\"title\":\"A0\",\"type\":\"ComboBox\",\"defaultValue\":{\"value\":\"GND\",\"options\":[\"GND\",\"VCC\"]}}}},\"alertControl\":{\"name\":\"alertControl\",\"category\":\"software\",\"description\":\"Alert Output Control\",\"type\":\"boolean\",\"defaultValue\":false,\"group\":\"alert\",\"tabs\":[\"main\"]},\"alertTrigger\":{\"name\":\"alertTrigger\",\"category\":\"software\",\"description\":\"Alert Output Select\",\"type\":\"ComboBox\",\"defaultValue\":{\"value\":\"Upper/Lower/Crit\",\"options\":[\"Upper/Lower/Crit\",\"Crit Only\"]},\"group\":\"alert\",\"tabs\":[\"main\"]},\"alertMode\":{\"name\":\"alertMode\",\"category\":\"software\",\"description\":\"Alert Output Mode\",\"type\":\"ComboBox\",\"defaultValue\":{\"value\":\"Comparator Mode\",\"options\":[\"Comparator Mode\",\"Interrupt Mode\"]},\"group\":\"alert\",\"tabs\":[\"main\"]},\"alertPolarity\":{\"name\":\"alertPolarity\",\"category\":\"software\",\"description\":\"Alert Output Polarity\",\"type\":\"ComboBox\",\"defaultValue\":{\"value\":\"Active-Low\",\"options\":[\"Active-High\",\"Active-Low\"]},\"group\":\"alert\",\"tabs\":[\"main\"]},\"ioc\":{\"name\":\"ioc\",\"category\":\"software\",\"description\":\"Alert Pin Interrupt-on-Change\",\"type\":\"boolean\",\"defaultValue\":false,\"group\":\"alert\",\"tabs\":[\"main\"]},\"operation\":{\"name\":\"operation\",\"category\":\"software\",\"description\":\"Shutdown Mode\",\"type\":\"boolean\",\"defaultValue\":false,\"group\":\"general\",\"tabs\":[\"main\"]},\"unit\":{\"name\":\"unit\",\"category\":\"software\",\"description\":\"Temperature Unit\",\"type\":\"ComboBox\",\"defaultValue\":{\"value\":\"Celsius\",\"options\":[\"Celsius\",\"Fahrenheit\"]},\"group\":\"general\",\"tabs\":[\"main\"]},\"ioOutPin\":{\"name\":\"ioOutPin\",\"description\":\"IO Indicator Pin Data Component\",\"type\":\"string\",\"defaultValue\":\"{}\",\"group\":\"alert\",\"tabs\":[\"main\"],\"isVisibleProperty\":\"showPin\",\"category\":\"software\"}}}");

/***/ }),

/***/ "./src/pinsdata.json":
/*!***************************!*\
  !*** ./src/pinsdata.json ***!
  \***************************/
/*! exports provided: rows, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"rows\":[{\"name\":\"AlertPin\",\"module\":\"MCP98xx\",\"function\":\"ALERT\",\"direction\":\"input\",\"filter\":{\"module\":\"GPIO\",\"aliasReEx\":\".*\"},\"attribs\":[{\"aliasReEx\":\".*\",\"cname\":\"MCP98XX_ALERT\",\"analog\":false}],\"behaviour\":\"OPTIONAL_PIN_MUX\"}]}");

/***/ })

/******/ });
//# sourceMappingURL=autoProcessor.js.map