/**
 * MCP98XX Generated Driver Types Header File.
 * 
 * @file mcp98xx_types.h
 * 
 * @ingroup mcp98xx
 * 
 * @brief This contains the MCP98xx driver types
 * 
 * @version MCP98xx Driver Version 1.0.0
 */
${disclaimer}

 #ifndef MCP98XX_TYPES_H
 #define MCP98XX_TYPES_H

/**
 * @ingroup mcp98xx
 * @enum MCP98XX_STATUS 
 * @brief Enumeration of the MCP98xx driver status codes.
 */
typedef enum MCP98XX_STATUS
{
    MCP98XX_NO_ERROR = 0U,                     /**<Returned value when there is no error encountered.*/     
    MCP98XX_ERROR = 1U,                        /**<Returned value when there is an error encountered.*/
    MCP98XX_COMMUNICATION_ERROR = 16U,         /**<Returned value when there is an error on the serial interface communication.*/
    MCP98XX_INVALID_DEVICE_INFO = 100U,        /**<Returned value for invalid parameter in getting the device information.*/
    MCP98XX_INVALID_RESOLUTION_VALUE = 101U,   /**<Returned value for invalid parameter in setting the Temperature Conversion Resolution.*/
    MCP98XX_INVALID_TEMP_VALUE = 102U,         /**<Returned value for invalid temperature boundary inputs.*/
    MCP98XX_INVALID_ALERT_CONFIG = 103U,       /**<Returned value for invalid parameter in setting the alert configuration.*/
    MCP98XX_INVALID_PARAMETER = 104U,          /**<Returned value for invalid parameter.*/
    MCP98XX_NULL_POINTER = 105U,               /**<Returned value for Null pointer.*/
    MCP98XX_NOT_ASSERTED = 10U,                /**<Returned value in the Ambient Temperature reading when an Alert output is not asserted by the device.*/
    MCP98XX_LOWER_TEMP_ASSERTED = 2U,          /**<Returned value in the Ambient Temperature reading when an Alert output is triggered by the Lower temperature boundary.*/
    MCP98XX_UPPER_TEMP_ASSERTED = 4U,          /**<Returned value in the Ambient Temperature reading when an Alert output is triggered by the Upper temperature boundary.*/
    MCP98XX_CRIT_TEMP_ASSERTED = 8U,           /**<Returned value in the Ambient Temperature reading when an Alert output is triggered by the Critical temperature boundary.*/
} MCP98XX_STATUS_t;

/**
 * @ingroup mcp98xx
 * @enum MCP98XX_TEMP_BOUNDARY 
 * @brief Enumeration of the user-configurable temperature boundaries that is used as a parameter for setting the boundaries.
 */
typedef enum MCP98XX_TEMP_BOUNDARY {
    LOWER_BOUNDARY = 1U,
    UPPER_BOUNDARY = 2U,
    CRITICAL_BOUNDARY = 3U
} MCP98XX_TEMP_BOUNDARY_t;

/**
 * @ingroup mcp98xx
 * @enum MCP98XX_ALERT_CONFIG 
 * @brief Enumeration of the user-configurable Alert output setting that is used as a parameter for setting the Alert configuration.
 */
typedef enum MCP98XX_ALERT_CONFIG {
    ALERT_OUTPUT_CLEAR = 1U,
    ALERT_CONTROL = 2U,
    ALERT_SELECT = 3U,
    ALERT_POLARITY = 4U,
    ALERT_MODE = 5U,
} MCP98XX_ALERT_CONFIG_t;

/**
 * @ingroup mcp98xx
 * @enum MCP98XX_HYSTERESIS_VALUE 
 * @brief Enumeration of the possible Temperature Hysteresis values.
 */
typedef enum MCP98XX_HYSTERESIS_VALUE {
    HYSTERESIS_0,                       /**<Used as a parameter when setting the Temperature Hysteresis to 0 C*/
    HYSTERESIS_1_5,                     /**<Used as a parameter when setting the Temperature Hysteresis to 1.5 C*/
    HYSTERESIS_3,                       /**<Used as a parameter when setting the Temperature Hysteresis to 3 C*/
    HYSTERESIS_6,                       /**<Used as a parameter when setting the Temperature Hysteresis to 6 C*/
} MCP98XX_HYSTERESIS_VALUE_t;

/**
 * @ingroup mcp98xx
 * @enum MCP98XX_RESOLUTION_VALUE 
 * @brief Enumeration of the possible Temperature Resolution values.
 */
typedef enum MCP98XX_RESOLUTION_VALUE 
{
    RESOLUTION_0_5,                     /**<Used as a parameter when setting the Temperature Conversion Resolution to +0.5 C*/    
    RESOLUTION_0_25,                    /**<Used as a parameter when setting the Temperature Conversion Resolution to +0.25 C*/
    RESOLUTION_0_125,                   /**<Used as a parameter when setting the Temperature Conversion Resolution to +0.125 C*/
    RESOLUTION_0_0625,                  /**<Used as a parameter when setting the Temperature Conversion Resolution to +0.0625 C*/
} MCP98XX_RESOLUTION_VALUE_t;

/**
 * @ingroup mcp98xx
 * @struct MCP98XX_DEVICE_INIT 
 * @brief Structure containing the MCP98xx driver registers to be initialized.
 */
typedef struct MCP98XX_DEVICE_INIT
{
    uint16_t i2cAddress;
    bool shutdownMode;
    uint8_t tempResolution;
    uint8_t tempHysteresis;
    float tempUpperBoundary;
    float tempLowerBoundary;
    float tempCritBoundary;
    bool critLock;
    bool winLock;
    bool alertClear;
    bool alertControl;
    bool alertSelect;
    bool alertMode;
    bool alertPolarity;
} MCP98XX_DEVICE_INIT_t;

/**
 * @ingroup mcp98xx
 * @struct MCP98XX_DEVICE_INFO 
 * @brief Structure containing the MCP98xx driver information.
 */
typedef struct MCP98XX_DEVICE_INFO
{
    uint16_t manufacturerId;
    uint8_t deviceId;
    uint8_t deviceRevision;
} MCP98XX_DEVICE_INFO_t;

/**
 * @ingroup mcp98xx
 * @struct MCP98XX_SENSOR_CONFIG_REG 
 * @brief Structure containing the MCP98xx driver Sensor Configuration bit register settings.
 */
typedef struct MCP98XX_SENSOR_CONFIG_REG
{
    uint8_t tempHysteresis;
    bool shutdownMode;
    bool critLock;
    bool winLock;
    bool alertClear;
    bool alertStat;
    bool alertControl;
    bool alertSelect;
    bool alertPolarity;
    bool alertMode;
} MCP98XX_CONFIG_REG_t, *MCP98XX_CONFIG_REG_PTR;

/**
 * @ingroup mcp98xx
 * @struct MCP98XX_DEVICE_CONTEXT
 * @brief Structure containing the MCP98xx driver context that can be used in the processes.
 */
typedef struct MCP98XX_DEVICE_CONTEXT
{
    uint16_t i2cAddress;
    MCP98XX_DEVICE_INFO_t deviceInfo;
    MCP98XX_CONFIG_REG_t sensorConfigReg;
    float tempUpperLimit;
    float tempLowerLimit;
    float tempCritLimit;
    uint8_t rxBuffer[2];
    uint8_t tempResolution;
    uint8_t txBuffer[3];
} MCP98XX_DEVICE_CONTEXT_t, *MCP98XX_DEVICE_CONTEXT_PTR;

#endif /* MCP98XX_TYPES_H */
