/**
 * ${device} Generated Driver I2C Interface File.
 * 
 * @file ${deviceNameLowerCase}_i2c.c
 * 
 * @ingroup ${deviceNameLowerCase}_i2c
 * 
 * @brief This contains the I2C API implementation for the ${device} driver, which the user can edit based on the specific I2C hardware used.
 * 
 * @version MCP98xx Driver Version 1.0.0
 */
 ${disclaimer}

<#if hasI2C>
#include "${resolvePath.mcp98xx_src}${headers.i2c}"
</#if>
#include "${resolvePath.mcp98xx_src}${headers.mcp98xx_i2c}"

const i2c_host_interface_t ${componentName}_I2C_Host = {
    .Write = <#if hasI2C><#if isMssp>I2C${modInstance}_Write<#else>${api.i2cInterface.Write.name}</#if>,<#else>NULL,//assign an I2C_Write API from a generated I2C driver and include the i2c PLib header file</#if>
    .WriteRead = <#if hasI2C><#if isMssp>I2C${modInstance}_WriteRead<#else>${api.i2cInterface.WriteRead.name}</#if>,<#else>NULL,//assign an I2C_WriteRead API from a generated I2C driver and include the i2c PLib header file</#if>
    .IsBusy = <#if hasI2C><#if isMssp>I2C${modInstance}_IsBusy<#else>${api.i2cInterface.IsBusy.name}</#if>,<#else>NULL,//assign an I2C_IsBusy API from a generated I2C driver and include the i2c PLib header file</#if>
    <#if !isI2cInterruptDriven>
    .Tasks = <#if hasI2C><#if isMssp>I2C${modInstance}_Tasks<#else>${api.i2cInterface.Tasks.name}</#if>,<#else>NULL,//assign an I2C_IsBusy API from a generated I2C driver and include the i2c PLib header file</#if>
    </#if>
};

uint8_t ${componentName}_Write(uint16_t address, uint8_t *data, size_t dataLength)
{
    uint8_t returnStat = ${componentNameUpperCase}_I2C_ERROR;
    if (address == 0 || data == NULL || dataLength == 0)
    {
        returnStat = ${componentNameUpperCase}_INVALID_I2C_PARAMETER;
    }
    else
    {
        if (${componentName}_I2C_Host.Write(address, data, dataLength))
        {
            <#if isI2cInterruptDriven>
            while(${componentName}_I2C_Host.IsBusy());
            <#else>
            while (${componentName}_I2C_Host.IsBusy())
            {
                ${componentName}_I2C_Host.Tasks();
            }
            </#if>
            returnStat = ${componentNameUpperCase}_I2C_NO_ERROR;
        }
        else
        {
            returnStat = ${componentNameUpperCase}_I2C_ERROR;
        }
    }
    return returnStat;
}

uint8_t ${componentName}_Read(uint16_t address, uint8_t *registerAddress, size_t addressLength, uint8_t *readData, size_t readLength)
{

    uint8_t returnStat = ${componentNameUpperCase}_I2C_ERROR;
    if (address == 0 || registerAddress == NULL || addressLength == 0 || readData == NULL || readLength == 0)
    {
        returnStat = ${componentNameUpperCase}_INVALID_I2C_PARAMETER;
    }
    else
    {
        if (${componentName}_I2C_Host.WriteRead(address, registerAddress, addressLength, readData, readLength))
        {
            <#if isI2cInterruptDriven>
            while(${componentName}_I2C_Host.IsBusy());
            <#else>
            while (${componentName}_I2C_Host.IsBusy())
            {
                ${componentName}_I2C_Host.Tasks();
            }
            </#if>
            returnStat = ${componentNameUpperCase}_I2C_NO_ERROR;
        }
        else
        {
            returnStat = ${componentNameUpperCase}_I2C_ERROR;
        }
    }
    return returnStat;
}
