/**
 * ${device} Generated Driver File.
 * 
 * @file ${deviceNameLowerCase}.c
 * 
 * @ingroup ${deviceNameLowerCase}
 * 
 * @brief This contains the API implementation for the ${device} driver.
 * 
 * @version MCP98xx Driver Version 1.0.0
 */
 ${disclaimer}

#include "${resolvePath.mcp98xx_src}${headers.mcp9808}"
#include "${resolvePath.mcp98xx_src}${headers.mcp9808_config}"

const MCP98XX_INTERFACE_t ${componentName} = {
    .Initialize = ${componentName}_Initialize,
    .TempRead = ${componentName}_TemperatureRawValueRead,
};

const ${componentNameUpperCase}_DEVICE_INIT_t ${componentNameUpperCase}_INITIAL_CONFIG = {
    .i2cAddress = ${componentNameUpperCase}_DEVICE_ADDRESS,
    .tempResolution = ${componentNameUpperCase}_RESOLUTION_INIT,
    .tempUpperBoundary = ${componentNameUpperCase}_UPPER_TEMP_BOUNDARY_INIT,
    .tempLowerBoundary = ${componentNameUpperCase}_LOWER_TEMP_BOUNDARY_INIT,
    .tempCritBoundary = ${componentNameUpperCase}_CRITICAL_TEMP_BOUNDARY_INIT,
    .tempHysteresis = ${componentNameUpperCase}_HYSTERESIS_INIT,
    .shutdownMode = ${componentNameUpperCase}_SHDN_MODE_INIT,
    .critLock = ${componentNameUpperCase}_CRIT_LOCK_INIT,
    .winLock = ${componentNameUpperCase}_WIN_LOCK_INIT,
    .alertClear = ${componentNameUpperCase}_INT_CLEAR_INIT,
    .alertControl = ${componentNameUpperCase}_ALERT_CNTRL_INIT,
    .alertSelect = ${componentNameUpperCase}_ALERT_SEL_INIT,
    .alertMode = ${componentNameUpperCase}_ALERT_MOD_INIT,
    .alertPolarity = ${componentNameUpperCase}_ALERT_POL_INIT,
};

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Converts the temperature value from Celsius to raw value.
 * @param float tempVal - Temperature value in Celsius to be converted.
 * @return Signed temperature raw value.
 */
int16_t ${componentName}_TemperatureCelsiusToRawValue(float tempVal);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Performs byte arrangements for the Sensor Configuration register of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @return None.
 */
void ${componentName}_SensorConfigBufferSet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr);

${componentNameUpperCase}_STATUS_t ${componentName}_Initialize(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_DEVICE_INIT_t deviceInit)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;
    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else if (deviceInit.i2cAddress == 0)
    {
        errorCode = MCP98XX_INVALID_PARAMETER;
    }
    else
    {
        devicePtr->i2cAddress = deviceInit.i2cAddress;
        devicePtr->sensorConfigReg.shutdownMode = deviceInit.shutdownMode;
        devicePtr->tempResolution = deviceInit.tempResolution;
        devicePtr->sensorConfigReg.tempHysteresis = deviceInit.tempHysteresis;
        devicePtr->tempCritLimit = deviceInit.tempCritBoundary;
        devicePtr->tempUpperLimit = deviceInit.tempUpperBoundary;
        devicePtr->tempLowerLimit = deviceInit.tempLowerBoundary;
        devicePtr->sensorConfigReg.critLock = deviceInit.critLock;
        devicePtr->sensorConfigReg.winLock = deviceInit.winLock;
        devicePtr->sensorConfigReg.alertClear = deviceInit.alertClear;
        devicePtr->sensorConfigReg.alertControl = deviceInit.alertControl;
        devicePtr->sensorConfigReg.alertSelect = deviceInit.alertSelect;
        devicePtr->sensorConfigReg.alertMode = deviceInit.alertMode;
        devicePtr->sensorConfigReg.alertPolarity = deviceInit.alertPolarity;
        ${componentName}_SensorConfigSet(devicePtr, devicePtr->sensorConfigReg);
        ${componentName}_TempResolutionSet(devicePtr, devicePtr->tempResolution);
        ${componentName}_TemperatureBoundarySet(devicePtr, LOWER_BOUNDARY, devicePtr->tempLowerLimit);
        ${componentName}_TemperatureBoundarySet(devicePtr, UPPER_BOUNDARY, devicePtr->tempUpperLimit);
        ${componentName}_TemperatureBoundarySet(devicePtr, CRITICAL_BOUNDARY, devicePtr->tempCritLimit);
        ${componentName}_TemperatureHysteresisSet(devicePtr, devicePtr->sensorConfigReg.tempHysteresis);
        errorCode = MCP98XX_NO_ERROR;
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_SensorConfigSet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_CONFIG_REG_t sensorConfigReg)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;

    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        devicePtr->sensorConfigReg = sensorConfigReg;
        devicePtr->txBuffer[0] = ${device}_SENSOR_CONFIG_REG_PTR;
        ${componentName}_SensorConfigBufferSet(devicePtr);
        errorCode = ${componentName}_Write(devicePtr->i2cAddress, devicePtr->txBuffer, 3);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            errorCode = MCP98XX_NO_ERROR;
        }
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_SensorConfigGet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_CONFIG_REG_PTR sensorConfigVal)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;
    uint8_t sensorConfigRegPtr = ${device}_SENSOR_CONFIG_REG_PTR;

    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        errorCode = ${componentName}_Read(devicePtr->i2cAddress, &sensorConfigRegPtr, ${device}_REGISTER_ADDRESS_LENGTH, devicePtr->rxBuffer, 2);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            sensorConfigVal->tempHysteresis = (devicePtr->rxBuffer[0] & ${device}_TEMP_HYSTERESIS_MASK) >> ${device}_TEMP_HYSTERESIS_POSITION;
            sensorConfigVal->shutdownMode = devicePtr->rxBuffer[0] & ${device}_SHDN_MODE_MASK;
            sensorConfigVal->critLock = (devicePtr->rxBuffer[1] & ${device}_CRIT_LOCK_MASK) >> ${device}_CRIT_LOCK_POSITION;
            sensorConfigVal->winLock = (devicePtr->rxBuffer[1] & ${device}_WIN_LOCK_MASK) >> ${device}_WIN_LOCK_POSITION;
            sensorConfigVal->alertClear = (devicePtr->rxBuffer[1] & ${device}_INT_CLEAR_MASK) >> ${device}_INT_CLEAR_POSITION;
            sensorConfigVal->alertStat = (devicePtr->rxBuffer[1] & ${device}_ALERT_STAT_MASK) >> ${device}_ALERT_STAT_POSITION;
            sensorConfigVal->alertControl = (devicePtr->rxBuffer[1] & ${device}_ALERT_CNTRL_MASK) >> ${device}_ALERT_CNTRL_POSITION;
            sensorConfigVal->alertSelect = (devicePtr->rxBuffer[1] & ${device}_ALERT_SEL_MASK) >> ${device}_ALERT_SEL_POSITION;
            sensorConfigVal->alertPolarity = (devicePtr->rxBuffer[1] & ${device}_ALERT_POL_MASK) >> ${device}_ALERT_POL_POSITION;
            sensorConfigVal->alertMode = devicePtr->rxBuffer[1] & ${device}_ALERT_MOD_MASK;
        }
        errorCode = MCP98XX_NO_ERROR;
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_TemperatureHysteresisSet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_HYSTERESIS_VALUE_t tempHysteresisVal)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;

    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        devicePtr->sensorConfigReg.tempHysteresis = tempHysteresisVal;
        errorCode = ${componentName}_SensorConfigSet(devicePtr, devicePtr->sensorConfigReg);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            errorCode = MCP98XX_NO_ERROR;
        }
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_ShutdownModeEnable(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;

    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        devicePtr->sensorConfigReg.shutdownMode = ${device}_ENABLE_BIT;
        errorCode = ${componentName}_SensorConfigSet(devicePtr, devicePtr->sensorConfigReg);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            errorCode = MCP98XX_NO_ERROR;
        }
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_ShutdownModeDisable(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;

    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        devicePtr->sensorConfigReg.shutdownMode = false;
        errorCode = ${componentName}_SensorConfigSet(devicePtr, devicePtr->sensorConfigReg);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            errorCode = MCP98XX_NO_ERROR;
        }
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_TemperatureCriticalLockEnable(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;

    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        devicePtr->sensorConfigReg.critLock = ${device}_ENABLE_BIT;
        errorCode = ${componentName}_SensorConfigSet(devicePtr, devicePtr->sensorConfigReg);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            errorCode = MCP98XX_NO_ERROR;
        }
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_TemperatureWindowLockEnable(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;

    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        devicePtr->sensorConfigReg.winLock = ${device}_ENABLE_BIT;
        errorCode = ${componentName}_SensorConfigSet(devicePtr, devicePtr->sensorConfigReg);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            errorCode = MCP98XX_NO_ERROR;
        }
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_AlertOutputClear(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;

    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        devicePtr->sensorConfigReg.alertClear = ${device}_ENABLE_BIT;
        errorCode = ${componentName}_SensorConfigSet(devicePtr, devicePtr->sensorConfigReg);
        if (errorCode != ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            errorCode = MCP98XX_NO_ERROR;
        }
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_AlertOutputStatusRead(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, bool* alertStat)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;
    uint8_t sensorConfigRegPtr = ${device}_SENSOR_CONFIG_REG_PTR;

    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        errorCode = ${componentName}_Read(devicePtr->i2cAddress, &sensorConfigRegPtr, ${device}_REGISTER_ADDRESS_LENGTH, devicePtr->rxBuffer, 2);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            devicePtr->sensorConfigReg.alertStat = devicePtr->rxBuffer[1] >> 4;
            *alertStat = devicePtr->sensorConfigReg.alertStat;
        }
        errorCode = MCP98XX_NO_ERROR;
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_AlertConfigurationSet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_ALERT_CONFIG_t alertConfig, uint8_t alertSet)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;
    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        switch (alertConfig)
        {
        case ALERT_OUTPUT_CLEAR:
            devicePtr->sensorConfigReg.alertClear = alertSet;
            break;
        case ALERT_CONTROL:
            devicePtr->sensorConfigReg.alertControl = alertSet;
            break;
        case ALERT_SELECT:
            devicePtr->sensorConfigReg.alertSelect = alertSet;
            break;
        case ALERT_POLARITY:
            devicePtr->sensorConfigReg.alertPolarity = alertSet;
            break;
        case ALERT_MODE:
            devicePtr->sensorConfigReg.alertMode = alertSet;
            break;
        default:
            break;
        }
        errorCode = ${componentName}_SensorConfigSet(devicePtr, devicePtr->sensorConfigReg);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            errorCode = MCP98XX_NO_ERROR;
        }
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_TemperatureBoundarySet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_TEMP_BOUNDARY_t boundary, float tempVal)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;
    int16_t convertedTempVal;

    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        switch (boundary)
        {
        case LOWER_BOUNDARY:
            devicePtr->txBuffer[0] = ${device}_LOWER_BOUNDARY_REG_PTR;
            break;
        case UPPER_BOUNDARY:
            devicePtr->txBuffer[0] = ${device}_UPPER_BOUNDARY_REG_PTR;
            break;
        case CRITICAL_BOUNDARY:
            devicePtr->txBuffer[0] = ${device}_CRITICAL_BOUNDARY_REG_PTR;
            break;
        default:
            break;
        }
        convertedTempVal = ${componentName}_TemperatureCelsiusToRawValue(tempVal);
        devicePtr->txBuffer[1] = (uint8_t)(convertedTempVal >> 8);
        devicePtr->txBuffer[2] = (uint8_t)convertedTempVal;
        errorCode = ${componentName}_Write(devicePtr->i2cAddress, devicePtr->txBuffer, 3);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            errorCode = MCP98XX_NO_ERROR;
        }
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_TemperatureBoundaryGet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_TEMP_BOUNDARY_t boundary, float* tempVal)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;
    uint16_t tempRawVal;
    uint8_t tempBoundaryPtr;

    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        switch (boundary)
        {
        case LOWER_BOUNDARY:
            tempBoundaryPtr = ${device}_LOWER_BOUNDARY_REG_PTR;
            break;
        case UPPER_BOUNDARY:
            tempBoundaryPtr = ${device}_UPPER_BOUNDARY_REG_PTR;
            break;
        case CRITICAL_BOUNDARY:
            tempBoundaryPtr = ${device}_CRITICAL_BOUNDARY_REG_PTR;
            break;
        default:
            break;
        }
        errorCode = ${componentName}_Read(devicePtr->i2cAddress, &tempBoundaryPtr, ${device}_REGISTER_ADDRESS_LENGTH, devicePtr->rxBuffer, 2);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            tempRawVal = ((uint16_t) devicePtr->rxBuffer[0] << 8) + devicePtr->rxBuffer[1];
            switch (boundary)
            {
            case LOWER_BOUNDARY:
                devicePtr->tempLowerLimit = ${componentName}_TemperatureRawToCelsius(tempRawVal);
                *tempVal = devicePtr->tempLowerLimit;
                break;
            case UPPER_BOUNDARY:
                devicePtr->tempUpperLimit = ${componentName}_TemperatureRawToCelsius(tempRawVal);
                *tempVal = devicePtr->tempUpperLimit;
                break;
            case CRITICAL_BOUNDARY:
                devicePtr->tempCritLimit = ${componentName}_TemperatureRawToCelsius(tempRawVal);
                *tempVal = devicePtr->tempCritLimit;
                break;
            default:
                break;
            }
        }
        errorCode = MCP98XX_NO_ERROR;
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_TemperatureRawValueRead(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, uint16_t* tempRawVal)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;
    uint8_t tempReg = ${device}_AMBIENT_TEMP_REG_PTR;
    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        errorCode = ${componentName}_Read(devicePtr->i2cAddress, &tempReg, ${device}_REGISTER_ADDRESS_LENGTH, devicePtr->rxBuffer, 2);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            *tempRawVal = (uint16_t)((devicePtr->rxBuffer[0] << 8) + devicePtr->rxBuffer[1]);
        }
        errorCode = MCP98XX_NO_ERROR;
    }
    return errorCode;
}

float ${componentName}_TemperatureRawToCelsius(uint16_t rawVal)
{
    float tempCelsius;
    uint16_t regVal;
    int16_t signedVal;

    regVal = rawVal;
    if ((regVal & ${device}_AMBIENT_TEMP_BIT_12) == ${device}_AMBIENT_TEMP_BIT_12)
    {
        regVal = regVal | ${device}_BOUNDARY_MASK;
    }
    else
    {
        regVal = regVal & ~${device}_BOUNDARY_MASK;
    }
    signedVal = (int16_t) regVal;
    tempCelsius = (float) signedVal;
    tempCelsius = tempCelsius / 16;
    return tempCelsius;
}

float ${componentName}_TemperatureRawToFahrenheit(uint16_t rawVal)
{
    float tempFahrenheit;
    uint16_t regVal;
    int16_t signedVal;
    regVal = rawVal;
    if ((regVal & ${device}_AMBIENT_TEMP_BIT_12) == ${device}_AMBIENT_TEMP_BIT_12)
    {
        regVal = regVal | ${device}_BOUNDARY_MASK;
    }
    else
    {
        regVal = regVal & ~${device}_BOUNDARY_MASK;
    }
    signedVal = (int16_t) regVal;
    tempFahrenheit = (float) signedVal;
    tempFahrenheit = (tempFahrenheit / 16)*9/5 + 32;
    return tempFahrenheit;
}

${componentNameUpperCase}_STATUS_t ${componentName}_AmbientTemperatureCelsiusRead(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, float* ambientTemp)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;
    uint16_t tempRawVal;

    errorCode = ${componentName}_TemperatureRawValueRead(devicePtr, &tempRawVal);
    if (errorCode == MCP98XX_NO_ERROR)
    {
        *ambientTemp = ${componentName}_TemperatureRawToCelsius(tempRawVal);
        if ((tempRawVal & ${device}_CRIT_TEMP_VS_AMBIENT_TEMP) == ${device}_CRIT_TEMP_VS_AMBIENT_TEMP)
        {
            errorCode = MCP98XX_CRIT_TEMP_ASSERTED;
        }
        else if ((tempRawVal & ${device}_UPPER_TEMP_VS_AMBIENT_TEMP) == ${device}_UPPER_TEMP_VS_AMBIENT_TEMP)
        {
            errorCode = MCP98XX_UPPER_TEMP_ASSERTED;
        }
        else if ((tempRawVal & ${device}_LOWER_TEMP_VS_AMBIENT_TEMP) == ${device}_LOWER_TEMP_VS_AMBIENT_TEMP)
        {
            errorCode = MCP98XX_LOWER_TEMP_ASSERTED;
        }
        else
        {
            errorCode = MCP98XX_NOT_ASSERTED;
        }
    }
    else
    {
        errorCode = MCP98XX_ERROR;
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_AmbientTemperatureFahrenheitRead(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, float* ambientTemp)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;
    uint16_t tempRawVal;

    errorCode = ${componentName}_TemperatureRawValueRead(devicePtr, &tempRawVal);
    if (errorCode == MCP98XX_NO_ERROR)
    {
        *ambientTemp = ${componentName}_TemperatureRawToFahrenheit(tempRawVal);
        if ((tempRawVal & ${device}_CRIT_TEMP_VS_AMBIENT_TEMP) == ${device}_CRIT_TEMP_VS_AMBIENT_TEMP)
        {
            errorCode = MCP98XX_CRIT_TEMP_ASSERTED;
        }
        else if ((tempRawVal & ${device}_UPPER_TEMP_VS_AMBIENT_TEMP) == ${device}_UPPER_TEMP_VS_AMBIENT_TEMP)
        {
            errorCode = MCP98XX_UPPER_TEMP_ASSERTED;
        }
        else if ((tempRawVal & ${device}_LOWER_TEMP_VS_AMBIENT_TEMP) == ${device}_LOWER_TEMP_VS_AMBIENT_TEMP)
        {
            errorCode = MCP98XX_LOWER_TEMP_ASSERTED;
        }
        else
        {
            errorCode = MCP98XX_NOT_ASSERTED;
        }
    }
    else
    {
        errorCode = MCP98XX_ERROR;
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_TempResolutionSet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_RESOLUTION_VALUE_t tempResolution)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;
    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        devicePtr->txBuffer[0] = ${device}_RESOLUTION_REG_PTR;
        devicePtr->txBuffer[1] = tempResolution;
        errorCode = ${componentName}_Write(devicePtr->i2cAddress, devicePtr->txBuffer, 2);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            errorCode = MCP98XX_NO_ERROR;
        }
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_TempResolutionGet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, uint8_t* tempResolutionVal)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;
    uint8_t resolutionRegPtr = ${device}_RESOLUTION_REG_PTR;

    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        errorCode = ${componentName}_Read(devicePtr->i2cAddress, &resolutionRegPtr, ${device}_REGISTER_ADDRESS_LENGTH, &(devicePtr->tempResolution), 1);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            *tempResolutionVal = devicePtr->tempResolution;
            errorCode = MCP98XX_NO_ERROR;
        }
    }
    return errorCode;
}

${componentNameUpperCase}_STATUS_t ${componentName}_DeviceInfoGet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_DEVICE_INFORMATION_t deviceInfo, uint16_t* deviceInfoVal)
{
    ${componentNameUpperCase}_STATUS_t errorCode = MCP98XX_NO_ERROR;
    uint8_t deviceInfoRegPtr;

    if (devicePtr == NULL)
    {
        errorCode = MCP98XX_NULL_POINTER;
    }
    else
    {
        if (deviceInfo == MANUFACTURER_ID)
        {
            deviceInfoRegPtr = ${device}_MANUFACTURERID_REG_PTR;
        }
        else if (deviceInfo == DEVICE_ID || deviceInfo == DEVICE_REVISION)
        {
            deviceInfoRegPtr = ${device}_DEVICE_ID_AND_REVISION_REG_PTR;
        }
        else
        {
            errorCode = MCP98XX_INVALID_DEVICE_INFO;
        }
        errorCode = ${componentName}_Read(devicePtr->i2cAddress, &deviceInfoRegPtr, ${device}_REGISTER_ADDRESS_LENGTH, devicePtr->rxBuffer, 2);
        if (errorCode == ${componentNameUpperCase}_I2C_ERROR)
        {
            errorCode = MCP98XX_COMMUNICATION_ERROR;
        }
        else
        {
            switch (deviceInfo)
            {
            case MANUFACTURER_ID:
                devicePtr->deviceInfo.manufacturerId = ((uint16_t) devicePtr->rxBuffer[0] << 8) + devicePtr->rxBuffer[1];
                *deviceInfoVal = devicePtr->deviceInfo.manufacturerId;
                break;
            case DEVICE_ID:
                devicePtr->deviceInfo.deviceId = devicePtr->rxBuffer[0];
                *deviceInfoVal = devicePtr->deviceInfo.deviceId;
                break;
            case DEVICE_REVISION:
                devicePtr->deviceInfo.deviceRevision = devicePtr->rxBuffer[1];
                *deviceInfoVal = devicePtr->deviceInfo.deviceRevision;
                break;
            default:
                break;
            }
            errorCode = MCP98XX_NO_ERROR;
        }
    }
    return errorCode;
}

float ${componentName}_CelsiusToFahrenheit(float tempVal)
{
    tempVal = (tempVal * 9/5) + 32;
    return tempVal;
}

float ${componentName}_FahrenheitToCelsius(float tempVal)
{
    tempVal = (tempVal - 32)*5 / 9;
    return tempVal;
}

int16_t ${componentName}_TemperatureCelsiusToRawValue(float tempVal)
{

    int16_t writeValue;
    uint16_t regValue;

    if (tempVal <= -40 || tempVal >= 125)
    {
        return MCP98XX_INVALID_TEMP_VALUE;
    }
    else
    {
        writeValue = (int16_t) ((float) tempVal * 16);
        regValue = (uint16_t) writeValue & ${device}_UNUSED_BIT_MASK;
        return (int16_t)regValue;
    }
}

void ${componentName}_SensorConfigBufferSet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr)
{
    devicePtr->txBuffer[1] = (uint8_t)((devicePtr->sensorConfigReg.tempHysteresis << 1) |
            (devicePtr->sensorConfigReg.shutdownMode));

    devicePtr->txBuffer[2] = (uint8_t)((devicePtr->sensorConfigReg.critLock << 7) |
            (devicePtr->sensorConfigReg.winLock << 6) |
            (devicePtr->sensorConfigReg.alertClear << 5) |
            (devicePtr->sensorConfigReg.alertControl << 3) |
            (devicePtr->sensorConfigReg.alertSelect << 2) |
            (devicePtr->sensorConfigReg.alertPolarity << 1) |
            (devicePtr->sensorConfigReg.alertMode));
}
