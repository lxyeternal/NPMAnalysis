/**
 * ${device} Generated Driver API Header File.
 * 
 * @file ${deviceNameLowerCase}.h
 * 
 * @defgroup ${deviceNameLowerCase} ${device}
 * 
 * @brief This contains the MCP9808 API prototypes and other data types for the ${device} driver.
 * 
 * @version MCP98xx Driver Version 1.0.0
 */
 ${disclaimer}

 #ifndef ${device}_H
 #define ${device}_H

#include <stdint.h>
#include "${resolvePath.mcp98xx_h}${headers.mcp98xx_i2c}"
#include "${resolvePath.mcp98xx_h}${headers.mcp98xx_interface}"

<#if !isRedundant>
/**
 * @name Custom Driver Type Macros
 * Macros that are used to redefine the driver types:
 */
///@{
#define ${componentNameUpperCase}_DEVICE_INIT_t                  MCP98XX_DEVICE_INIT_t
#define ${componentNameUpperCase}_DEVICE_CONTEXT_t               MCP98XX_DEVICE_CONTEXT_t
#define ${componentNameUpperCase}_DEVICE_CONTEXT_PTR             MCP98XX_DEVICE_CONTEXT_PTR
#define ${componentNameUpperCase}_CONFIG_REG_t                   MCP98XX_CONFIG_REG_t
#define ${componentNameUpperCase}_CONFIG_REG_PTR                 MCP98XX_CONFIG_REG_PTR
#define ${componentNameUpperCase}_DEVICE_INFO_t                  MCP98XX_DEVICE_INFO_t
#define ${componentNameUpperCase}_TEMP_BOUNDARY_t                MCP98XX_TEMP_BOUNDARY_t
#define ${componentNameUpperCase}_ALERT_CONFIG_t                 MCP98XX_ALERT_CONFIG_t
#define ${componentNameUpperCase}_HYSTERESIS_VALUE_t             MCP98XX_HYSTERESIS_VALUE_t
#define ${componentNameUpperCase}_RESOLUTION_VALUE_t             MCP98XX_RESOLUTION_VALUE_t
#define ${componentNameUpperCase}_STATUS_t                       MCP98XX_STATUS_t
///@}

</#if>
/**
 * @name MCC-Generated Macros
 * Macros used to initialize the MCP9808 driver:
 */
///@{
#define ${componentNameUpperCase}_DEVICE_ADDRESS               (${i2cClientAdd}U)
#define ${componentNameUpperCase}_RESOLUTION_INIT              ${tempResolutionVal}
#define ${componentNameUpperCase}_HYSTERESIS_INIT              ${tempHysteresisVal}
#define ${componentNameUpperCase}_UPPER_TEMP_BOUNDARY_INIT     (${tempUpper})
#define ${componentNameUpperCase}_LOWER_TEMP_BOUNDARY_INIT     (${tempLower})
#define ${componentNameUpperCase}_CRITICAL_TEMP_BOUNDARY_INIT  (${tempCrit})
#define ${componentNameUpperCase}_ALERT_CNTRL_INIT             (${alertCtrl}U)
#define ${componentNameUpperCase}_ALERT_SEL_INIT               (${alertSelect}U)
#define ${componentNameUpperCase}_ALERT_POL_INIT               (${alertPol}U)
#define ${componentNameUpperCase}_ALERT_MOD_INIT               (${alertMode}U)
#define ${componentNameUpperCase}_WIN_LOCK_INIT                (${tempWinLock}U)
#define ${componentNameUpperCase}_CRIT_LOCK_INIT               (${tempCritLock}U)
#define ${componentNameUpperCase}_INT_CLEAR_INIT               (1U)
#define ${componentNameUpperCase}_SHDN_MODE_INIT               (${shdnMode}U)
///@}

/**
 @ingroup ${deviceNameLowerCase}
 @struct ${componentName}
 @brief An instance of MCP98XX_INTERFACE_t for the MCP98xx driver
 */
extern const MCP98XX_INTERFACE_t ${componentName};

/**
 @ingroup ${deviceNameLowerCase}
 @struct ${componentNameUpperCase}_INITIAL_CONFIG
 @brief An instance of ${componentNameUpperCase}_DEVICE_INIT_t for the MCP98xx driver
 */
extern const ${componentNameUpperCase}_DEVICE_INIT_t ${componentNameUpperCase}_INITIAL_CONFIG;

/**
 * @ingroup ${deviceNameLowerCase}
 * @enum _${componentNameUpperCase}_DEVICE_INFORMATION_t 
 * @brief Enumeration of the ${device} device information.
 */
typedef enum _${componentNameUpperCase}_DEVICE_INFORMATION_t {
    MANUFACTURER_ID = 1U,
    DEVICE_ID = 2U,
    DEVICE_REVISION = 3U,
} ${componentNameUpperCase}_DEVICE_INFORMATION_t;

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Initializes the ${device} Temperature Sensor driver.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @param ${componentNameUpperCase}_DEVICE_INIT_t deviceInit - An instance of ${componentNameUpperCase}_DEVICE_INIT_t.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_Initialize(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_DEVICE_INIT_t deviceInit);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Sets the configuration of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of MCP9808_DEVICE_CONTEXT.
 * @param ${componentNameUpperCase}_CONFIG_REG_t sensorConfigReg - An instance of ${componentNameUpperCase}_CONFIG_REG_t.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_SensorConfigSet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_CONFIG_REG_t sensorConfigReg);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Gets the configuration of the ${device} Temperature Sensor and updates the structure containing the Sensor Configuration register settings.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @param ${componentNameUpperCase}_CONFIG_REG_PTR sensorConfigVal - Pointer to an instance of ${componentNameUpperCase}_CONFIG_REG_t.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_SensorConfigGet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_CONFIG_REG_PTR sensorConfigVal);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Sets the Temperature Hysteresis of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @param ${componentNameUpperCase}_HYSTERESIS_VALUE_t tempHysteresisVal - One of the enumerated hysteresis values from MCP98XX_HYSTERESIS_VALUE_t.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_TemperatureHysteresisSet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_HYSTERESIS_VALUE_t tempHysteresisVal);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Enables the Shutdown mode feature of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_ShutdownModeEnable(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Disables the Shutdown mode feature of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_ShutdownModeDisable(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Enables the Critical Lock bit of the Sensor Configuration register of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_TemperatureCriticalLockEnable(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Enables the Window Lock bit of the Sensor Configuration register of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_TemperatureWindowLockEnable(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Clears the Alert output interrupt of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_AlertOutputClear(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Reads the Alert output status from the Sensor Configuration register of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @param bool* alertStat - Pointer to a user-defined variable where the Alert output data is to be stored.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_AlertOutputStatusRead(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, bool* alertStat);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Sets the Alert configuration of the Sensor Configuration register of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @param ${componentNameUpperCase}_ALERT_CONFIG_t alertConfig - One of the enumerated Alert Configuration from MCP98XX_ALERT_CONFIG_t.
 * @param uint8_t alertSet - Desired state of the Alert setting.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_AlertConfigurationSet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_ALERT_CONFIG_t alertConfig, uint8_t alertSet);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Sets the user-specified temperature boundary for the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @param ${componentNameUpperCase}_TEMP_BOUNDARY_t boundary - One of the enumerated Temperature Boundary registers from MCP98XX_TEMP_BOUNDARY_t.
 * @param uint8_t alertSet - Temperature value in Celsius.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_TemperatureBoundarySet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_TEMP_BOUNDARY_t boundary, float tempVal);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Gets the temperature boundary value from the Temperature Boundary registers of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @param ${componentNameUpperCase}_TEMP_BOUNDARY_t boundary - One of the enumerated Temperature Boundary registers from MCP98XX_TEMP_BOUNDARY_t.
 * @param float* tempVal - Pointer to a user-defined variable where the Temperature Boundary data is to be stored.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_TemperatureBoundaryGet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_TEMP_BOUNDARY_t boundary, float* tempVal);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Reads the temperature sensor value from the Ambient Temperature register of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @param uint16_t* tempRawVal - Pointer to a user-defined variable where the raw value data is to be stored.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_TemperatureRawValueRead(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, uint16_t* tempRawVal);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Converts the temperature raw value to Celsius.
 * @param uint16_t rawVal - Raw value to be converted.
 * @return Temperature value in Celsius.
 */
float ${componentName}_TemperatureRawToCelsius(uint16_t rawVal);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Converts the temperature raw value to Fahrenheit.
 * @param uint16_t rawVal - Raw value to be converted.
 * @return Temperature value in Fahrenheit.
 */
float ${componentName}_TemperatureRawToFahrenheit(uint16_t rawVal);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Reads the temperature sensor value in Celsius from the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @param float* ambientTemp - Pointer to a user-defined variable where the Ambient Temperature in Celsius is to be stored.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_AmbientTemperatureCelsiusRead(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, float* ambientTemp);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Reads the temperature sensor value in Fahrenheit from the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @param float* ambientTemp - Pointer to a user-defined variable where the Ambient Temperature in Fahrenheit is to be stored.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_AmbientTemperatureFahrenheitRead(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, float* ambientTemp);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Sets the temperature conversion resolution of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @param ${componentNameUpperCase}_RESOLUTION_VALUE_t tempResolution - One of the enumerated Temperature Resolution value from MCP98XX_RESOLUTION_VALUE_t.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_TempResolutionSet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_RESOLUTION_VALUE_t tempResolution);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Gets the temperature conversion resolution of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @param uint8_t* tempResolutionVal - Pointer to a user-defined variable where the Temperature Resolution data is to be stored.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_TempResolutionGet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, uint8_t* tempResolutionVal);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Sets the temperature conversion resolution of the ${device} Temperature Sensor.
 * @param ${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr - Pointer to an instance of ${componentNameUpperCase}_DEVICE_CONTEXT_t.
 * @param ${componentNameUpperCase}_DEVICE_INFORMATION_t deviceInfo - One of the enumerated value.
 * @param uint16_t* deviceInfoVal - Pointer to a user-defined variable where the device information is to be stored.
 * @return MCP98XX status code.
 */
${componentNameUpperCase}_STATUS_t ${componentName}_DeviceInfoGet(${componentNameUpperCase}_DEVICE_CONTEXT_PTR devicePtr, ${componentNameUpperCase}_DEVICE_INFORMATION_t deviceInfo, uint16_t* deviceInfoVal);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Converts the temperature value from Celsius to Fahrenheit.
 * @param float tempVal - Temperature value to be converted.
 * @return Converted value.
 */
float ${componentName}_CelsiusToFahrenheit(float tempVal);

/**
 * @ingroup ${deviceNameLowerCase}
 * @brief Converts the temperature value from Fahrenheit to Celsius.
 * @param float tempVal - Temperature value to be converted.
 * @return Converted value.
 */
float ${componentName}_FahrenheitToCelsius(float tempVal);

#endif /* ${device}_H */
