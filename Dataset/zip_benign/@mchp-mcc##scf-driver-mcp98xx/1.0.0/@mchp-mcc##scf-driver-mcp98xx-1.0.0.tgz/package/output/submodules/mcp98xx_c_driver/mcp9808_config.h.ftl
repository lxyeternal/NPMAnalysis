/**
 * ${device} Generated Driver Header File.
 * 
 * @file ${deviceNameLowerCase}_config.h
 * 
 * @ingroup ${deviceNameLowerCase}
 * 
 * @brief This contains macros for device-specific configuration
 * 
 * @version MCP98xx Driver Version 1.0.0
 */
 ${disclaimer}

 #ifndef ${device}_CONFIG_H
 #define ${device}_CONFIG_H

/**  
 * @name Register Pointer Macros
 * ${device} Register Address pointers:
 */
///@{
#define ${device}_SENSOR_CONFIG_REG_PTR           (0x01U)
#define ${device}_UPPER_BOUNDARY_REG_PTR          (0x02U)
#define ${device}_LOWER_BOUNDARY_REG_PTR          (0x03U)
#define ${device}_CRITICAL_BOUNDARY_REG_PTR       (0x04U)
#define ${device}_AMBIENT_TEMP_REG_PTR            (0x05U)
#define ${device}_MANUFACTURERID_REG_PTR          (0x06U)
#define ${device}_DEVICE_ID_AND_REVISION_REG_PTR  (0x07U)
#define ${device}_RESOLUTION_REG_PTR              (0x08U)
///@}

/** 
 * @name Ambient Temperature register Macros
 * Macros used for the Ambient Temperature reading process:
 */
///@{
#define ${device}_AMBIENT_TEMP_BIT_12             (0x1000U)
#define ${device}_CRIT_TEMP_VS_AMBIENT_TEMP       (0x8000U)
#define ${device}_UPPER_TEMP_VS_AMBIENT_TEMP      (0x4000U)
#define ${device}_LOWER_TEMP_VS_AMBIENT_TEMP      (0x2000U)
///@}

/** 
 * @name Mask Macros
 * Macros used in masking the ${device} registers:
 */
///@{
#define ${device}_SIGN_BIT_MASK                   (0x10U)
#define ${device}_BOUNDARY_MASK                   (0xE000U)
#define ${device}_UNUSED_BIT_MASK                 (0x1FFCU)
#define ${device}_TEMP_HYSTERESIS_MASK            (0x06U)
#define ${device}_SHDN_MODE_MASK                  (0x01U)
#define ${device}_CRIT_LOCK_MASK                  (0x80U)
#define ${device}_WIN_LOCK_MASK                   (0x40U)
#define ${device}_INT_CLEAR_MASK                  (0x20U)
#define ${device}_ALERT_STAT_MASK                 (0x10U)
#define ${device}_ALERT_CNTRL_MASK                (0x08U)
#define ${device}_ALERT_SEL_MASK                  (0x04U)
#define ${device}_ALERT_POL_MASK                  (0x02U)
#define ${device}_ALERT_MOD_MASK                  (0x01U)
///@}

/** 
 * @name Bit Position Macros
 * Macros that indicate the ${device} register bit positions:
 */
///@{
#define ${device}_TEMP_HYSTERESIS_POSITION          (1U)
#define ${device}_CRIT_LOCK_POSITION                (7U)
#define ${device}_WIN_LOCK_POSITION                 (6U)
#define ${device}_INT_CLEAR_POSITION                (5U)
#define ${device}_ALERT_STAT_POSITION               (4U)
#define ${device}_ALERT_CNTRL_POSITION              (3U)
#define ${device}_ALERT_SEL_POSITION                (2U)
#define ${device}_ALERT_POL_POSITION                (1U)
///@}

/** 
 * @name Generic Macros
 * Macros used in driver operation:
 */
///@{
#define ${device}_ENABLE_BIT                        (1U)
#define ${device}_REGISTER_ADDRESS_LENGTH           (1U)
///@}

#endif /* ${device}_CONFIG_H */
