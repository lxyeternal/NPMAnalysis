/**
 * MCP98XX Generated Driver Interface API Header File.
 * 
 * @file mcp98xx_interface.h
 * 
 * @defgroup mcp98xx MCP98XX
 * 
 * @brief This contains the APIs for the MCP98xx driver interface
 * 
 * @version MCP98xx Driver Version 1.0.0
 */
 ${disclaimer}

 #ifndef MCP98XX_INTERFACE_H
 #define MCP98XX_INTERFACE_H

#include <stdint.h>
#include "${resolvePath.mcp98xx_h}${headers.mcp98xx_types}"

/**
 * @ingroup mcp98xx
 * @struct MCP98XX_INTERFACE_t 
 * @brief Structure containing the function pointers to the MCP98xx driver APIs.
 */
typedef struct
{
    MCP98XX_STATUS_t(*Initialize)(MCP98XX_DEVICE_CONTEXT_PTR devicePtr, MCP98XX_DEVICE_INIT_t deviceInit);        /**<This is a pointer to the driver initializer function.*/
    MCP98XX_STATUS_t(*TempRead)(MCP98XX_DEVICE_CONTEXT_PTR devicePtr, uint16_t* tempRawVal);                    /**<This is a pointer to the function that reads the Ambient Temperature data.*/

} MCP98XX_INTERFACE_t;

#endif /* MCP98XX_INTERFACE_H */
