export const resolutionOptions: number[] = [0.0625, 0.125, 0.25, 0.5];
export const hysteresisOptions: number[] = [0, 1.5, 3, 6];
