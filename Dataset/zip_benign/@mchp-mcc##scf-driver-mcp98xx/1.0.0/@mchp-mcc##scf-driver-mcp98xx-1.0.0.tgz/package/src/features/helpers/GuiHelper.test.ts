import { GuiHelper } from "./GuiHelper";

describe("GUI Helper Test", () => {
    test("Default Value Builder Test", () => {
        const defaultValues = {
            component1: "defaultVal1",
            component2: "defaultVal2",
            component3: "defaultVal3",
            component4: "defaultVal4",
        };

        expect(
            GuiHelper.createDefaultValueBuilder()
                .addDefaultValue("component1", "defaultVal1")
                .addDefaultValue("component2", "defaultVal2")
                .addDefaultValue("component3", "defaultVal3")
                .addDefaultValue("component4", "defaultVal4")
                .buildDefaultValues(),
        ).toStrictEqual(defaultValues);
    });

    test("Calculated Value Builder Test", () => {
        const calculatedVal1 = "val1";
        const calculatedVal2 = "val2";

        expect(
            GuiHelper.createCalculatedValueBuilder()
                .addConditionalValue("hello", "(hi|world)", "val" + 0)
                .addConditionalValue("world", "(hi|world)", "val" + 1)
                .buildCalculatedValue(),
        ).toStrictEqual(calculatedVal1);

        expect(
            GuiHelper.createCalculatedValueBuilder()
                .addUnconditionalValue("val" + 2)
                .buildCalculatedValue(),
        ).toStrictEqual(calculatedVal2);
    });

    test("Custom UI Error Builder Test", () => {
        const customUIError: Error[] = [
            {
                name: "pattern",
                message: "This is an error",
            },
        ];

        expect(
            GuiHelper.createCustomUiErrorBuilder("component1")
                .addCustomError("component2", "pattern", "This is a mistake")
                .addCustomError("component1", "pattern", "This is an error")
                .buildCustomUiError(),
        ).toStrictEqual(customUIError);
    });
});
