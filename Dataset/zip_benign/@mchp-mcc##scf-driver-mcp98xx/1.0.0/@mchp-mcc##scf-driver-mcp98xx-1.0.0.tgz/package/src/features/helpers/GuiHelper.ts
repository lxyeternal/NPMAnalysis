import { Dictionary } from "../../../generated_module/src/Utils";

export class GuiHelper {
    public static createDefaultValueBuilder = (): DefaultValueBuilder =>
        new DefaultValueBuilder();

    public static createCalculatedValueBuilder = (): CalculatedValueBuilder =>
        new CalculatedValueBuilder();

    public static createCustomUiErrorBuilder = (
        componentName: string,
    ): CustomUiErrorBuilder => new CustomUiErrorBuilder(componentName);
}

class DefaultValueBuilder {
    private defaultValues: Dictionary<any> = {};

    public addDefaultValue = (componentName: string, value: any): DefaultValueBuilder => {
        this.defaultValues[componentName] = value;

        return this;
    };

    public buildDefaultValues = (): Dictionary<any> => {
        return this.defaultValues;
    };
}

class CalculatedValueBuilder<T extends any = any> {
    private value: T;

    public addConditionalValue = (
        matchValue: any,
        matchRegEx: string,
        value: T,
    ): CalculatedValueBuilder<T> => {
        if (matchValue?.toString()?.match(matchRegEx)) {
            this.value = value;
        }
        return this;
    };

    public addUnconditionalValue = (value: T): CalculatedValueBuilder<T> => {
        this.value = value;

        return this;
    };

    public buildCalculatedValue = (): T => {
        return this.value;
    };
}

class CustomUiErrorBuilder {
    private customError: Error[] | undefined;
    private componentName = "";

    constructor(componentName: string) {
        this.componentName = componentName;
    }

    public addCustomError = (
        componentName: string,
        errorName: string,
        errorMessage: string,
    ): CustomUiErrorBuilder => {
        if (this.componentName.match(componentName)) {
            this.customError = (this.customError ?? []).concat({
                name: errorName,
                message: errorMessage,
            });
        }
        return this;
    };

    public buildCustomUiError = (): Error[] | undefined => this.customError;
}
