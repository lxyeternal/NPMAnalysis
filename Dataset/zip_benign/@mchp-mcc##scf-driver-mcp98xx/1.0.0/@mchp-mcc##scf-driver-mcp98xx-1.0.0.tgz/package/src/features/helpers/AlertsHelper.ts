import { Alert, AlertTypes } from "@microchip/scf-common/lib/Processor";

export class AlertHelper {
    public static createAlertBuilder = (): AlertBuilder => new AlertBuilder();
}

class AlertBuilder {
    private alerts: Alert[] = [];

    public addConditionalAlert = (
        value: string | boolean | number | undefined,
        matchRegEx: string,
        alertType: AlertTypes,
        alertText: string,
    ): AlertBuilder => {
        if (value?.toString()?.match(matchRegEx)) {
            this.alerts.push({ type: alertType, text: alertText });
        }
        return this;
    };

    public addStaticAlert = (alertType: AlertTypes, alertText: string): AlertBuilder => {
        this.alerts.push({ type: alertType, text: alertText });

        return this;
    };

    public buildAlerts = (): Alert[] => this.alerts;
}
