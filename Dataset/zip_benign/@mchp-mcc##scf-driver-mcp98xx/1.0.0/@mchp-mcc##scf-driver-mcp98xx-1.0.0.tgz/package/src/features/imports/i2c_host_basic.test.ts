import * as i2c_host_basic from "@microchip/i2c-host-basic";
import * as Handle from "@microchip/scf-common/lib/Handle.spec";
import { Module } from "@microchip/scf-common/lib/Processor";
import { getModel } from "../../../generated_module/tests/AppModel.test";
import { AppModel, MyModule } from "../../../generated_module/src/types/AutoModuleTypes";
import { mockDerivedData } from "../../../generated_module/tests/AppModel.test";
import { MyImportHelper } from "./i2c_host_basic";

const mockAssignedModule = (state?: any): Module => {
    return {
        scriptId: "",
        payload: {},
        exports: {},
        imports: {
            i2c_host_basic: {
                handle: Handle.createMock(),
                ...((i2c_host_basic.Interface.createMock() as unknown) as i2c_host_basic.Types["Import"]),
            },
        },
        state: {
            ...(state ?? {}),
        },
    };
};
const mockDataModel = getModel(
    mockAssignedModule() as MyModule,
    mockDerivedData,
) as AppModel;
const mockPayload = i2c_host_basic.Interface.createMock().payload;
const mockFirmwareApi = mockPayload?.interfaceApi;

describe("I2C Host Basic Interface Helper Test", () => {
    test("Get Import name Test", () => {
        expect(MyImportHelper.getImportName()).toStrictEqual("i2c_host_basic");
    });

    test("Get Firmware API Test", () => {
        expect(MyImportHelper.getFirmwareApi(mockDataModel)).toStrictEqual(
            mockFirmwareApi,
        );
    });

    test("Get Payload Test", () => {
        expect(MyImportHelper.getPayload(mockDataModel)).toStrictEqual(mockPayload);
    });

    test("Arguments Builder Test", () => {
        const args: i2c_host_basic.Arguments = {
            requestedSpeed_Hz: "100000",
            i2cHostCallbackEvent: {
                name: "MyModule_I2CHostCallbackEvent",
                header: "myModule/myModule.h",
            },
            interruptDriven: true,
        };

        expect(
            MyImportHelper.createArgumentsBuilder()
                .addRequestedSpeed_Hz("100000")
                .addI2cHostCallbackEvent(
                    "MyModule_I2CHostCallbackEvent",
                    "myModule/myModule.h",
                )
                .addInterruptDriven(true)
                .buildArguments(),
        ).toStrictEqual(args);
    });

    test("Results Builder Test", () => {
        const results: i2c_host_basic.Results = {
            customName: "myModule",
        };

        expect(
            MyImportHelper.createResultsBuilder()
                .addCustomName("myModule")
                .buildResults(),
        ).toStrictEqual(results);
    });
});
