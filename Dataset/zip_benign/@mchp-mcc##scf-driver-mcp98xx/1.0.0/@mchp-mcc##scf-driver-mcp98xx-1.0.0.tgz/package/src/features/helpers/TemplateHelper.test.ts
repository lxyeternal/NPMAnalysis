import { Module } from "@microchip/scf-common/lib/Processor";
import { CFunctions } from "@microchip/scf-interface";
import { FirmwareAPIPayload } from "@microchip/scf-interface";
import { getModel } from "../../../generated_module/tests/AppModel.test";
import { AppModel, MyModule } from "../../../generated_module/src/types/AutoModuleTypes";
import { mockDerivedData } from "../../../generated_module/tests/AppModel.test";
import { TemplateHelper } from "./TemplateHelper";

const mockAssignedModule = (state?: any): Module => {
    return {
        scriptId: "",
        exports: {},
        imports: {
            import1: {
                interfaceId: {
                    name: "import1",
                    version: "0.1.0",
                },
                handle: {
                    exportId: "",
                    providerId: "",
                },
                payload: {},
            },
            import2: {
                interfaceId: {
                    name: "import2",
                    version: "0.1.0",
                },
                handle: {
                    exportId: "",
                    providerId: "",
                },
                payload: {},
            },
        },
        state: {
            ...(state ?? {}),
        },
    };
};
const mockDataModel = getModel(mockAssignedModule() as MyModule, mockDerivedData);

describe("Template Helper Test", () => {
    test("Template Data Builder Test", () => {
        const templateData = {
            genericData: "genericData",
            headers: {
                header1: "header1Path/header1Filename",
                header2: "header2Path/header2Filename",
            },
            resolvePath: {
                src: "../../",
            },
            api: {
                myApi: {
                    api1: {
                        name: "Prefix_Api1",
                        returns: "void",
                        arguments: [{ type: "uint8_t", name: "arg" }],
                    },
                    api2: {
                        name: "Prefix_Api2",
                        returns: "void",
                    },
                },
            },
            simpleApi: {
                myApi: {
                    api1: "void Prefix_Api1(uint8_t arg)",
                    api2: "void Prefix_Api2(void)",
                },
            },
            component1: undefined,
            component2: undefined,
            import1: {},
            import2: {},
            register: {
                REG1: undefined,
            },
            interrupt: {
                INT1: undefined,
            },
        };
        const firmwareApi: FirmwareAPIPayload<CFunctions> = {
            api: {
                api1: {
                    name: "Prefix_Api1",
                    returns: "void",
                    arguments: [{ type: "uint8_t", name: "arg" }],
                },
                api2: {
                    name: "Prefix_Api2",
                    returns: "void",
                },
            },
            simpleApi: {
                api1: "void Prefix_Api1(uint8_t arg)",
                api2: "void Prefix_Api2(void)",
            },
            headerFiles: [{ path: "header1Path", name: "header1Filename" }],
        };

        expect(
            TemplateHelper.createTemplateDataBuilder(mockDataModel as AppModel)
                .addGenericData("genericData", "genericData")
                .addHeaderFileData("header1", {
                    path: "header1Path/",
                    name: "header1Filename",
                })
                .addHeaderFileData(
                    "header2",
                    {
                        path: "header2Path/",
                        name: "header2Filename",
                    },
                    { value: "true", matchRegEx: "true" },
                )
                .addHeaderFileData(
                    "header3",
                    {
                        path: "header3Path/",
                        name: "header3Filename",
                    },
                    { value: "false", matchRegEx: "true" },
                )
                .addHeaderFileData(
                    "header4",
                    { path: "header4Path/", name: "header4Filename" },
                    { value: undefined, matchRegEx: "true" },
                )
                .addResolvePath("src", "header1Path/src/")
                .addFirmwareApiData("myApi", firmwareApi)
                .addGuiData("component1", "component2")
                .addImportData("import1")
                .addAllImportData()
                .addRegisterData("REG1")
                .addAllRegisterData()
                .addInterruptData("INT1")
                .addAllInterruptData()
                .buildTemplateData(),
        ).toStrictEqual(templateData);
    });

    test("Template API Builder Test", () => {
        const defaultApis: CFunctions = {
            api1: {
                name: "DefaultPrefix_Api1",
                returns: "void",
                arguments: [{ type: "uint8_t", name: "arg" }],
            },
            api2: {
                name: "DefaultPrefix_Api2",
                returns: "int8_t",
            },
        };
        const firmwareApi: FirmwareAPIPayload<CFunctions> = {
            api: {
                api1: {
                    name: "DefaultPrefix_Api1",
                    returns: "void",
                    arguments: [{ type: "uint8_t", name: "arg" }],
                },
                api2: {
                    name: "DefaultPrefix_Api2",
                    returns: "int8_t",
                },
                api3: {
                    name: "NewPrefix_Api3",
                    returns: "uint8_t",
                    documentation: "API3 Documentation",
                },
                api4: {
                    name: "NewPrefix_Api4",
                    returns: "void",
                    arguments: [
                        { type: "float", name: "arg1" },
                        { type: "int", name: "arg2" },
                    ],
                },
            },
            simpleApi: {
                api1: "void DefaultPrefix_Api1(uint8_t arg)",
                api2: "int8_t DefaultPrefix_Api2(void)",
                api3: "uint8_t NewPrefix_Api3(void)",
                api4: "void NewPrefix_Api4(float arg1, int arg2)",
            },
            headerFiles: [{ path: "headerPath/", name: "headerFilename" }],
        };

        expect(
            TemplateHelper.createTemplateApisBuilder()
                .addApisData(defaultApis)
                .addApiPrefix("NewPrefix")
                .addApiDataFor("api3")
                .addName("Api3")
                .addReturns("uint8_t")
                .addDocumentation("API3 Documentation")
                .addApiDataFor("api4")
                .addName("Api4")
                .addReturns("void")
                .addArgument("float", "arg1")
                .addArgument("int", "arg2")
                .buildAllAddedApiData()
                .addHeaderFile("headerPath/", "headerFilename")
                .buildFirmwareApiPayload(),
        ).toStrictEqual(firmwareApi);

        expect(
            TemplateHelper.createTemplateApisBuilder()
                .addApisData(defaultApis)
                .addApiPrefix("NewPrefix")
                .addApiDataFor("api3")
                .addName("Api3")
                .addReturns("uint8_t")
                .addDocumentation("API3 Documentation")
                .addApiDataFor("api4")
                .addName("Api4")
                .addReturns("void")
                .addArgument("float", "arg1")
                .addArgument("int", "arg2")
                .buildAllAddedApiData()
                .addHeaderFile("headerPath/", "headerFilename")
                .buildApis(),
        ).toStrictEqual(firmwareApi.api);

        expect(
            TemplateHelper.createTemplateApisBuilder()
                .addApisData(defaultApis)
                .addApiPrefix("NewPrefix")
                .addApiDataFor("api3")
                .addName("Api3")
                .addReturns("uint8_t")
                .addDocumentation("API3 Documentation")
                .addApiDataFor("api4")
                .addName("Api4")
                .addReturns("void")
                .addArgument("float", "arg1")
                .addArgument("int", "arg2")
                .buildAllAddedApiData()
                .addHeaderFile("headerPath/", "headerFilename")
                .buildSimpleApis(),
        ).toStrictEqual(firmwareApi.simpleApi);

        expect(
            TemplateHelper.createTemplateApisBuilder()
                .addApisData(defaultApis)
                .addApiPrefix("NewPrefix")
                .addApiDataFor("api3")
                .addName("Api3")
                .addReturns("uint8_t")
                .addDocumentation("API3 Documentation")
                .addApiDataFor("api4")
                .addName("Api4")
                .addReturns("void")
                .addArgument("float", "arg1")
                .addArgument("int", "arg2")
                .buildAllAddedApiData()
                .addHeaderFile("headerPath/", "headerFilename")
                .buildHeaderFiles(),
        ).toStrictEqual(firmwareApi.headerFiles);
    });

    test("Template File Builder Test", () => {
        expect(
            TemplateHelper.createTemplateFileBuilder("output/src1.h.ftl")
                .addTemplateFileInfo(
                    "output/src1.h.ftl",
                    () => "src1Path/",
                    () => "src1Filename",
                )
                .addTemplateFileInfo(
                    "output/src2.h.ftl",
                    () => "src2Path/",
                    () => "src2Filename",
                )
                .buildTemplateFile(),
        ).toStrictEqual("src1Path/src1Filename");

        expect(
            TemplateHelper.createTemplateFileBuilder("output/src2.h.ftl")
                .addTemplateFileInfo(
                    "output/src1.h.ftl",
                    () => "src1Path/",
                    () => "src1Filename",
                )
                .addTemplateFileInfo(
                    "output/src2.h.ftl",
                    () => "src2Path/",
                    () => "src2Filename",
                )
                .buildTemplateFile(),
        ).toStrictEqual("src2Path/src2Filename");
    });
});
