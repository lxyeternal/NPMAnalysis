import {
    ArgumentsBuilder,
    ImportHelper,
    ResultssBuilder,
} from "../helpers/ImportHelperTemplate";
import {
    API,
    Interface,
    ProcessedPayload,
    Arguments,
    Results,
} from "@microchip/i2c-host-basic";
import { AppModel } from "../../../generated_module/src/types/AutoModuleTypes";
import { FirmwareAPIPayload } from "@microchip/scf-interface";

export const getImportName = (): string => "i2c_host_basic";

export const createArgumentsBuilder = (): MyArgumentsBuilder => new MyArgumentsBuilder();

export const createResultsBuilder = (): MyResultsBuilder => new MyResultsBuilder();

export const getFirmwareApi = (model: AppModel): FirmwareAPIPayload<API> =>
    getPayload(model)?.interfaceApi ?? Interface.createFirmwareApi();

export const getPayload = (model: AppModel): ProcessedPayload =>
    model.getImportValue(getImportName());

export const MyImportHelper: ImportHelper<
    MyArgumentsBuilder,
    MyResultsBuilder,
    ProcessedPayload,
    API
> = {
    getImportName: getImportName,
    getFirmwareApi: getFirmwareApi,
    getPayload: getPayload,
    createArgumentsBuilder: createArgumentsBuilder,
    createResultsBuilder: createResultsBuilder,
};

export class MyArgumentsBuilder extends ArgumentsBuilder<Arguments> {
    public addRequestedSpeed_Hz = (value: string): MyArgumentsBuilder => {
        this.args = {
            ...(this.args ?? {}),
            requestedSpeed_Hz: value,
        };

        return this;
    };

    public addInterruptDriven = (value: boolean): MyArgumentsBuilder => {
        this.args = {
            ...(this.args ?? {}),
            interruptDriven: value,
        };

        return this;
    };

    public addI2cHostCallbackEvent = (
        name: string,
        header: string,
    ): MyArgumentsBuilder => {
        this.args = {
            ...(this.args ?? {}),
            i2cHostCallbackEvent: {
                name: name,
                header: header,
            },
        };

        return this;
    };
}

export class MyResultsBuilder extends ResultssBuilder<Results> {
    public addCustomName = (value: string): MyResultsBuilder => {
        this.results = {
            ...(this.results ?? {}),
            customName: value,
        };

        return this;
    };
}
