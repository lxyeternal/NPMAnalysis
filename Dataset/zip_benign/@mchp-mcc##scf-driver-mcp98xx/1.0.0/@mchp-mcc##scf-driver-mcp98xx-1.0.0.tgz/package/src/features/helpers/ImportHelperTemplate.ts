import { Dictionary } from "@microchip/scf-common/lib/Processor";
import { CFunctions, FirmwareAPIPayload } from "@microchip/scf-interface";
import { AppModel } from "../../../generated_module/src/types/AutoModuleTypes";

export interface ImportHelper<
    ArgsBuilder extends ArgumentsBuilder<Dictionary<any>> = ArgumentsBuilder<
        Dictionary<any>
    >,
    ResBuilder extends ResultssBuilder<Dictionary<any>> = ResultssBuilder<
        Dictionary<any>
    >,
    Payload extends Dictionary<any> = Dictionary<any>,
    API extends CFunctions = CFunctions
> {
    getImportName: () => string;
    getFirmwareApi: (model: AppModel) => FirmwareAPIPayload<API>;
    getPayload: (model: AppModel) => Payload;
    createArgumentsBuilder: () => ArgsBuilder;
    createResultsBuilder: () => ResBuilder;
}

export class ArgumentsBuilder<Args extends Dictionary<any>> {
    protected args: Args = {} as Args;

    public addArgument<T extends keyof Args>(
        key: T,
        value: Args[T],
    ): ArgumentsBuilder<Args> {
        this.args[key] = value;

        return this;
    }

    public buildArguments = (): Args => this.args;
}

export class ResultssBuilder<Results extends Dictionary<any>> {
    protected results: Results = {} as Results;

    public addResult<T extends keyof Results>(
        key: T,
        value: Results[T],
    ): ResultssBuilder<Results> {
        this.results[key] = value;

        return this;
    }

    public buildResults = (): Results => this.results;
}
