import { MyImportHelper as i2c_host_basic } from "../imports/i2c_host_basic";

export const ImportsHelpers = { i2c_host_basic };
