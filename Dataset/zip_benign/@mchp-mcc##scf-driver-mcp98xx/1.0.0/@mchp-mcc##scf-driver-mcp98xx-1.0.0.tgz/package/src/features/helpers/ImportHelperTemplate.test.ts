import { ArgumentsBuilder, ResultssBuilder } from "./ImportHelperTemplate";

describe("Import Template Helper Test", () => {
    test("Arguments Builder Test", () => {
        const argumentsBuilder = new ArgumentsBuilder();
        const args = {
            arg1: "string",
            arg2: false,
            arg3: 25,
            arg4: {
                prop1: "prop1",
                prop2: "prop2",
            },
            arg5: ["prop1", "prop2"],
        };

        expect(
            argumentsBuilder
                .addArgument("arg1", "string")
                .addArgument("arg2", false)
                .addArgument("arg3", 25)
                .addArgument("arg4", { prop1: "prop1", prop2: "prop2" })
                .addArgument("arg5", ["prop1", "prop2"])
                .buildArguments(),
        ).toStrictEqual(args);
    });

    test("Results Builder Test", () => {
        const resultsBuilder = new ResultssBuilder();
        const results = {
            res1: "string",
            res2: false,
            res3: 25,
            res4: {
                prop1: "prop1",
                prop2: "prop2",
            },
            res5: ["prop1", "prop2"],
        };

        expect(
            resultsBuilder
                .addResult("res1", "string")
                .addResult("res2", false)
                .addResult("res3", 25)
                .addResult("res4", { prop1: "prop1", prop2: "prop2" })
                .addResult("res5", ["prop1", "prop2"])
                .buildResults(),
        ).toStrictEqual(results);
    });
});
