import {
    FirmwareAPIPayload,
    CFunctions,
    CFunction,
    buildSimpleApi,
    SimpleApi,
    HeaderFile,
} from "@microchip/scf-interface";
import { AppModel } from "../../../generated_module/src/types/AutoModuleTypes";
import { Dictionary, getKeys } from "../../../generated_module/src/Utils";

export class TemplateHelper {
    public static createTemplateDataBuilder = (model: AppModel): TemplateDataBuilder =>
        new TemplateDataBuilder(model);

    public static createTemplateApisBuilder = (): TemplateApisBuilder =>
        new TemplateApisBuilder();

    public static createTemplateFileBuilder = (src: string): TemplateFileBuilder =>
        new TemplateFileBuilder(src);
}

class TemplateDataBuilder {
    private data: Dictionary<any> = {};
    private model: AppModel;

    constructor(model: AppModel) {
        this.model = model;
    }

    public buildTemplateData = (): Dictionary<any> => this.data;

    public addGenericData = (key: string, value: any): TemplateDataBuilder => {
        this.data[key] = value;

        return this;
    };

    public addGuiData = (...componentNames: string[]): TemplateDataBuilder => {
        componentNames.forEach((key) => {
            this.data[key] = this.model.getComponentValue(key);
        });

        return this;
    };

    public addAllImportData = (): TemplateDataBuilder => {
        getKeys(this.model.getImports()).forEach(
            (key) => (this.data[key] = this.model.getImportValue(key)),
        );

        return this;
    };

    public addImportData = (importName: string): TemplateDataBuilder => {
        this.data[importName] = this.model.getImportValue(importName);

        return this;
    };

    public addAllRegisterData = (): TemplateDataBuilder => {
        this.data["register"] = {
            ...(this.data["register"] ?? {}),
            ...(this.model.getRegisterValues() ?? {}),
        };

        return this;
    };

    public addRegisterData = (registerName: string): TemplateDataBuilder => {
        this.data["register"] = {
            ...(this.data["register"] ?? {}),
            [registerName]: this.model.getRegisterValues()?.[registerName],
        };

        return this;
    };

    public addAllInterruptData = (): TemplateDataBuilder => {
        this.data["interrupt"] = {
            ...(this.data["interrupt"] ?? {}),
            ...(this.model.getInterrupts() ?? {}),
        };

        return this;
    };

    public addInterruptData = (interruptName: string): TemplateDataBuilder => {
        this.data["interrupt"] = {
            ...(this.data["interrupt"] ?? {}),
            [interruptName]: this.model.getInterrupts()?.[interruptName],
        };

        return this;
    };

    public addHeaderFileData = (
        key: string,
        header: HeaderFile,
        condition?: { value: string | boolean | number | undefined; matchRegEx: string },
    ): TemplateDataBuilder => {
        if (condition) {
            if (!condition.value?.toString()?.match(condition.matchRegEx)) return this;
        }

        this.data["headers"] = {
            ...(this.data["headers"] ?? {}),
            [key]: `${header.path}${header.name}`,
        };

        return this;
    };

    public addResolvePath = (key: string, relativePath: string): TemplateDataBuilder => {
        this.data["resolvePath"] = {
            ...(this.data["resolvePath"] ?? {}),
            [key]: relativePath.replace(/([^/]*\/)/g, "../"),
        };

        return this;
    };

    public addFirmwareApiData = (
        key: string,
        firmwareApis: FirmwareAPIPayload<CFunctions>,
    ): TemplateDataBuilder => {
        this.data = {
            ...this.data,
            api: {
                ...(this.data["api"] ?? {}),
                [key]: firmwareApis.api,
            },
            simpleApi: {
                ...(this.data["simpleApi"] ?? {}),
                [key]: firmwareApis.simpleApi,
            },
        };

        return this;
    };
}

class TemplateApisBuilder {
    private apis: CFunctions = {};
    private headerFiles: HeaderFile[] = [];
    private prefix = "";

    public addApiPrefix = (prefix = ""): TemplateApisBuilder => {
        this.prefix = prefix;
        return this;
    };

    public addApisData = (apis: CFunctions): TemplateApisBuilder => {
        this.apis = {
            ...this.apis,
            ...apis,
        };

        return this;
    };

    public addApiDataFor = (
        key: string,
    ): typeof TemplateApisBuilder.createApiBuilder.prototype =>
        new TemplateApisBuilder.createApiBuilder(this, key);

    private static createApiBuilder = class ApiBuilder {
        private apiFor = "";
        private superThis: TemplateApisBuilder;
        private apis: CFunctions = {};

        constructor(superThis: TemplateApisBuilder, apiFor: string) {
            this.superThis = superThis;
            this.apiFor = apiFor;

            this.apis[apiFor] = {
                name: `${this.superThis.prefix}_${apiFor}`,
                returns: "void",
            };
        }

        public addApiDataFor = (key: string): ApiBuilder => {
            this.apiFor = key;
            this.apis[key] = {
                name: `${this.superThis.prefix}_${key}`,
                returns: "void",
            };

            return this;
        };

        public addName = (name: string): ApiBuilder => {
            this.apis[this.apiFor]["name"] = `${this.superThis.prefix}_${name}`;
            return this;
        };

        public addReturns = (returns: string): ApiBuilder => {
            this.apis[this.apiFor]["returns"] = returns;
            return this;
        };

        public addArgument = (type: string, name: string): ApiBuilder => {
            this.apis[this.apiFor]["arguments"] = (
                this.apis[this.apiFor]?.arguments ?? []
            ).concat({ type: type, name: name });
            return this;
        };

        public addDocumentation = (
            documentations: CFunction["documentation"],
        ): ApiBuilder => {
            this.apis[this.apiFor]["documentation"] = documentations;
            return this;
        };

        public buildAllAddedApiData = (): TemplateApisBuilder => {
            this.superThis.apis = {
                ...this.superThis.apis,
                ...this.apis,
            };

            return this.superThis;
        };
    };

    public addHeaderFile = (path: string, name: string): TemplateApisBuilder => {
        this.headerFiles.push({ path: path, name: name });
        return this;
    };

    public buildFirmwareApiPayload = (): FirmwareAPIPayload<CFunctions> => {
        return {
            api: this.apis,
            simpleApi: this.buildSimpleApis(),
            headerFiles: this.headerFiles,
        };
    };

    public buildApis = (): CFunctions => this.apis;

    public buildSimpleApis = (): SimpleApi => buildSimpleApi(this.apis);

    public buildHeaderFiles = (): HeaderFile[] => this.headerFiles;
}

class TemplateFileBuilder {
    private src = "";
    private dest: string | undefined;

    constructor(src: string) {
        this.src = src;
    }

    public addTemplateFileInfo = (
        srcMatchRegEx: string,
        path: () => string,
        fileName: () => string,
    ): TemplateFileBuilder => {
        if (this.src.match(srcMatchRegEx)) {
            this.dest = `${path()}${fileName()}`;
        }
        return this;
    };

    public buildTemplateFile = (): string => this.dest ?? "";
}
