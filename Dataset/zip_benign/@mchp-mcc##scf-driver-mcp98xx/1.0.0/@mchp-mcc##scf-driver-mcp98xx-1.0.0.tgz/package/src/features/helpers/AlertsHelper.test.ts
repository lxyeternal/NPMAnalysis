import { Alert, AlertTypes } from "@microchip/scf-common/lib/Processor";
import { AlertHelper } from "./AlertsHelper";

describe("Alert Helper Test", () => {
    test("Alert Builder Test", () => {
        const alerts1: Alert[] = [
            {
                type: AlertTypes.Warning,
                text: "This is a warning",
            },
            {
                type: AlertTypes.Hint,
                text: "This is a hint",
            },
            {
                type: AlertTypes.Error,
                text: "This is an error",
            },
        ];
        const alerts2: Alert[] = [
            {
                type: AlertTypes.Warning,
                text: "This is a warning",
            },
            {
                type: AlertTypes.Hint,
                text: "This is a hint",
            },
        ];

        expect(
            AlertHelper.createAlertBuilder()
                .addConditionalAlert(
                    "Warning",
                    "Warning",
                    AlertTypes.Warning,
                    "This is a warning",
                )
                .addStaticAlert(AlertTypes.Hint, "This is a hint")
                .addConditionalAlert(
                    "Error",
                    "(Warning|Hint|Error)",
                    AlertTypes.Error,
                    "This is an error",
                )
                .buildAlerts(),
        ).toStrictEqual(alerts1);

        expect(
            AlertHelper.createAlertBuilder()
                .addConditionalAlert(
                    "Warning",
                    "Warning",
                    AlertTypes.Warning,
                    "This is a warning",
                )
                .addStaticAlert(AlertTypes.Hint, "This is a hint")
                .addConditionalAlert(
                    "Error",
                    "(Warning|Hint)",
                    AlertTypes.Error,
                    "This is an error",
                )
                .buildAlerts(),
        ).toStrictEqual(alerts2);
    });
});
