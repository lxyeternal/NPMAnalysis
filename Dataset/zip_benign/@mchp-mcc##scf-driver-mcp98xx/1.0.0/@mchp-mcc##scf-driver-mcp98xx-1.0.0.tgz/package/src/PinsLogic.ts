import { pin_attribs_enum, pin_row } from "@microchip/pin-standard/lib/pin-standard";
import { AppModel } from "@microchip/melody-automodule-interface";

// provide complete dynamic data for all pin rows. It overrides static pindata.json
export const getCompletePinData = (appModel: AppModel): any => {
    // way to programatically override the json data
    return {};
};

// overrides pin data for a particular row based on model.
export function getRowData(appModel: AppModel, rowData: pin_row): pin_row {
    // Modify the rowData
    let returnRowData: pin_row = rowData;
    if (rowData.name === "AlertPin") {
        returnRowData = {
            ...returnRowData,
            module: appModel.getComponentValue("device") ?? "MCP98xx",
            attribs: [
                {
                    aliasReEx: ".*",
                    cname: `${
                        appModel.getComponentValue("componentName") ?? "MCP98xx"
                    }_ALERT`,
                    analog: false,
                },
            ],
        };
    }

    // Get the action builder for the pin module
    const indicatorPinComponent = appModel.getComponent("ioOutPin")?.component;
    const PCP: any = appModel.getPCPHelper;
    const neededAttribs: pin_attribs_enum[] = [
        pin_attribs_enum.cname,
        pin_attribs_enum.ioc,
    ];
    let returnRowActions = [];
    if (rowData.name === "AlertPin" && indicatorPinComponent) {
        returnRowActions = returnRowActions.concat(
            PCP?.()
                .stateActionBuilder(rowData)
                .rowWithName(rowData.name)
                .forComponent(indicatorPinComponent)
                .addIfLockedProvideAttribs(".*", neededAttribs)
                .addIfUnlockedProvideAttribs(".*", neededAttribs)
                .build(),
        );
    }
    return { ...returnRowData, actions: returnRowActions };
}
