import * as Processor from "@microchip/scf-common/lib/Processor";
import { GuiHelper } from "./features/helpers/GuiHelper";
import {
    AppModel,
    DerivedData,
    DerivedFunctions,
} from "../generated_module/src/types/AutoModuleTypes";
import { getCFunctionValidator, PatternValidator } from "@microchip/scf-validators/lib";
import { AlertHelper } from "./features/helpers/AlertsHelper";
import { AlertTypes } from "@microchip/scf-common/lib/Processor";
import { TemplateHelper } from "./features/helpers/TemplateHelper";
import { resolutionOptions, hysteresisOptions } from "./OptionValues";
import * as mcp98xx_interface from "./interfaces/mcp98xx-basic";
import * as InterfaceTypes from "@microchip/scf-interface";
import { InterfaceId } from "@microchip/scf-common/lib/InterfaceId";
import { getPinsLogic } from "../generated_module/src/pins/PCPHelper";
import { pin_attribs } from "@microchip/pin-standard";
import { getKeys, values } from "../generated_module/src/Utils";
import { ImportsHelpers } from "./features/helpers/ImportsHelpers";
import * as temp_sensor from "@microchip/temp-sensor";
export const getDerivedData = (dataModel: AppModel): DerivedData => {
    if (dataModel) {
        return new MyDerivedData(dataModel);
    }
    return new EmptyDerivedData();
};

//This data will be used at the creator stage and relies on only the state
class EmptyDerivedData implements DerivedData {
    getMyFunctions = (): DerivedFunctions => {
        return {};
    };
    getModel = (): AppModel | undefined => {
        return undefined;
    };
}

//This data will be used at the processor stage
class MyDerivedData implements DerivedData {
    private dataModel: AppModel;
    private cValidator: PatternValidator = getCFunctionValidator();

    constructor(dataModel: AppModel) {
        this.dataModel = dataModel;
    }

    getMyFunctions = (): DerivedFunctions => {
        return {
            templateData: this.getMyTemplateData,
            alerts: this.getMyAlerts,
            calculatedFunction: this.calculatedFunction,
            moduleName: (): string => "I2C Temp Sensor MCP98xx",
            getActiveName: (): string => "I2C Temp Sensor MCP98xx",
            templateName: this.getTemplateName,
            overrideDefaultValues: this.overrideDefaultValue,
            tempUpperBoundaryValidator: this.getTempBoundaryValidator,
            tempLowerBoundaryValidator: this.getTempBoundaryValidator,
            tempCritBoundaryValidator: this.getTempBoundaryValidator,
            componentNameValidator: this.componentNameValidator,
            getCustomUiErrors: this.getCustomUiErrors,
            overrideOptions: this.overrideOptions,
            i2cClientAdd: this.i2cClientAddrssConfig,
            overrideTitle: this.getTempDesc,
            isEnabled: this.isComponentEnabled,
            "temp-sensor_payload": this.getExportedGenericTempSensorPayload,
            "mcp98xx-basic_payload": this.getExportedMcp98xxInterfacePayload,
            operation: this.getOperationMode,
            componentName: this.getComponentNameArgs,
            device: this.getDeviceArgs,
            getPinsLogic: getPinsLogic,
            tempResolution: this.overrideResolution,
            tempHysteresis: this.overrideHysteresis,
            showPin: (): boolean => false,
            generateFile: (): boolean =>
                this.getModel().getComponentValue("device") === "MCP9808",
            alertMode: (): string =>
                GuiHelper.createCalculatedValueBuilder()
                    .addConditionalValue(
                        this.getModel().getComponentValue("alertTrigger"),
                        "Crit Only",
                        "Comparator Mode",
                    )
                    .buildCalculatedValue(),
            isHostSelectable: (): boolean => {
                return this.dataModel.getImports().i2c_host_basic.options !== undefined;
            },
            i2c_host_basic_results: (): any =>
                ImportsHelpers["i2c_host_basic"]
                    .createResultsBuilder()
                    .addCustomName(
                        `I2C${
                            this.getModel()
                                .getImports()
                                .i2c_host_basic.payload?.moduleInstance.toString() ?? "1"
                        }_Host`,
                    )
                    .buildResults(),
            i2c_host_basic_args: (): any =>
                ImportsHelpers["i2c_host_basic"]
                    .createArgumentsBuilder()
                    .addRequestedSpeed_Hz("400000")
                    ?.buildArguments(),
        };
    };
    private overrideDefaultValue = (componentName: string): any => {
        switch (componentName) {
            case "componentName":
                return this.getModel().getComponentValue("device");
            case "tempHysteresis":
                if (this.getModel().getComponentValue("unit") === "Fahrenheit") {
                    return "32";
                } else {
                    return "0";
                }

            case "tempResolution":
                if (this.getModel().getComponentValue("unit") === "Fahrenheit") {
                    return "+32.1125";
                } else {
                    return "+0.0625";
                }
        }
    };

    private readonly getHeaderFiles = (): InterfaceTypes.HeaderFile[] => {
        return [
            {
                name:
                    `${
                        this.getModel().getComponentValue("device") ?? "MCP98xx"
                    }`.toLowerCase() + ".h",
                path: "temperature-mcp98xx/",
            },
            {
                name:
                    `${
                        this.getModel().getComponentValue("device") ?? "MCP98xx"
                    }`.toLowerCase() + "_config.h",
                path: "temperature-mcp98xx/",
            },
            {
                name:
                    `${
                        this.getModel().getComponentValue("device") ?? "MCP98xx"
                    }`.toLowerCase() + "_i2c.h",
                path: "temperature-mcp98xx/",
            },
            {
                name: "mcp98xx_types.h",
                path: "temperature-mcp98xx/",
            },
            {
                name: "mcp98xx_interface.h",
                path: "temperature-mcp98xx/",
            },
        ];
    };

    public getModuleName = (): string => {
        return this.dataModel.getName() ?? "MCP98xx";
    };

    private readonly getExportedGenericTempSensorPayload = (): temp_sensor.ProcessedPayload => {
        const Api = temp_sensor.getInterfaceApiStructure(this.getModuleName());
        Api.api.Initialize = mcp98xx_interface.createApi(
            `${this.getModel().getComponentValue("componentName")}`,
        ).Initialize;
        Api.api.Temperature_Read = mcp98xx_interface.createApi(
            `${this.getModel().getComponentValue("componentName")}`,
        ).TemperatureRead;
        Api.api.LowPower_Enable = mcp98xx_interface.createApi(
            `${this.getModel().getComponentValue("componentName")}`,
        ).shdnModeEnable;
        Api.api.LowPower_Disable = mcp98xx_interface.createApi(
            `${this.getModel().getComponentValue("componentName")}`,
        ).shdnModeDisable;
        Api.api.Celsius_To_Fahrenheit = mcp98xx_interface.createApi(
            `${this.getModel().getComponentValue("componentName")}`,
        ).celsiusToFahrenheit;
        Api.api.Fahrenheit_To_Celsius = mcp98xx_interface.createApi(
            `${this.getModel().getComponentValue("componentName")}`,
        ).fahrenheitToCelsius;
        Api.headerFiles = [
            {
                name: `${this.getModel().getComponentValue("device")?.toLowerCase()}.h`,
                path: "temperature-mcp98xx/",
            },
        ];

        return {
            customName: String(this.getModel().getComponentValue("componentName")),
            moduleName: "Off-chip: " + this.getModel().getActiveName(),
            lowPowerMode: this.getModel().getComponentValue("operation") ?? false,
            interfaceApi: Api,
            protocol: "I2C",
        };
    };

    private readonly getExportedMcp98xxInterfacePayload = (): mcp98xx_interface.ProcessedPayload => {
        return {
            interfaceApi: mcp98xx_interface.createFirmwareApi(
                this.getModel().getComponentValue("componentName") ?? "MCP98xx",
                this.getHeaderFiles(),
            ),
            componentName: this.getModel().getComponentValue("componentName"),
            device: this.getModel().getComponentValue("device"),
            shutdownMode: this.getModel().getComponentValue("operation"),
            tempUnit: this.getModel().getComponentValue("unit"),
            i2cClientAddress: this.getModel().getComponentValue("i2cClientAdd"),
            tempWinLock: this.getModel().getComponentValue("tempWinLock"),
            tempCritLock: this.getModel().getComponentValue("tempCritLock"),
            tempResolution: this.getModel().getComponentValue("tempResolution"),
            tempHysteresis: this.getModel().getComponentValue("tempHysteresis"),
            tempLowerBoundary: this.getModel().getComponentValue("tempLowerBoundary"),
            tempUpperBoundary: this.getModel().getComponentValue("tempUpperBoundary"),
            tempCritBoundary: this.getModel().getComponentValue("tempCritBoundary"),
            alertCtrl: this.getModel().getComponentValue("alertControl"),
            alertSlct: this.getModel().getComponentValue("alertTrigger"),
            alertMd: this.getModel().getComponentValue("alertMode"),
            alertPol: this.getModel().getComponentValue("alertPolarity"),
        };
    };

    private readonly getRequestedArgFrom = (
        interfaceId: InterfaceId,
        argName: string,
    ): any => {
        const tempSensorExport = this.getModel()
            .getExportInterfaces()
            .getInterface("temp_sensor_interface", interfaceId);
        if (tempSensorExport && tempSensorExport.args) {
            const chosen = Object.keys(tempSensorExport.args)[0];
            const args = tempSensorExport.args[chosen];
            if (args && args[argName] !== undefined) {
                return args[argName];
            }
        }
    };

    private readonly getRequestedArg = (argName: string): any => {
        const arg = this.getRequestedArgFrom(
            temp_sensor.Interface.getInterfaceId(),
            argName,
        );
        if (arg !== undefined) {
            return arg;
        }
    };

    private readonly getComponentNameArgs = (): string => {
        return this.getRequestedArg("componentName");
    };

    private readonly getDeviceArgs = (): string => {
        return this.getRequestedArg("device");
    };

    private readonly getOperationMode = (): boolean => {
        return this.getRequestedArg("lowPowerMode");
    };

    public getModel = (): AppModel => {
        return this.dataModel;
    };

    private readonly getTemplateName = (src: string): any => {
        const device =
            this.getModel().getComponentValue("device")?.toLowerCase() ?? "mcp98xx";
        if (src === "output/mcp98xx_i2c.c.ftl") {
            return `temperature-mcp98xx/src/${device}_i2c.c`;
        } else if (src === "output/mcp98xx_i2c.h.ftl") {
            return `temperature-mcp98xx/${device}_i2c.h`;
        } else if (src === "output/submodules/mcp98xx_c_driver/src/mcp9808.c.ftl") {
            return `temperature-mcp98xx/src/${device}.c`;
        } else if (src === "output/submodules/mcp98xx_c_driver/mcp9808.h.ftl") {
            return `temperature-mcp98xx/${device}.h`;
        } else {
            return undefined;
        }
    };

    private getMyTemplateData = (): any => {
        return TemplateHelper.createTemplateDataBuilder(this.getModel())
            .addGuiData("componentName")
            .addGenericData(
                "componentNameLowerCase",
                this.getModel().getComponentValue("componentName")?.toLowerCase(),
            )
            .addGenericData(
                "componentNameUpperCase",
                this.getModel().getComponentValue("componentName")?.toUpperCase(),
            )
            .addGenericData(
                "deviceNameLowerCase",
                this.getModel().getComponentValue("device")?.toLowerCase(),
            )
            .addGenericData("isRedundant", this.isRedundant())
            .addGuiData("device")
            .addGenericData(
                "i2cHostModuleName",
                this.getModel().getComponentValue("i2c_host_basic"),
            )
            .addGuiData("i2cClientAdd")
            .addGenericData("tempLower", this.lowerBoundaryGet())
            .addGenericData("tempUpper", this.upperBoundaryGet())
            .addGenericData("tempCrit", this.critBoundaryGet())
            .addGenericData("shdnMode", this.opMode())
            .addGenericData("tempResolutionVal", this.tempResolutionGet())
            .addGenericData("tempHysteresisVal", this.tempHysteresisGet())
            .addGenericData("tempWinLock", this.winLock())
            .addGenericData("tempCritLock", this.critLock())
            .addGenericData("alertCtrl", this.alertControl())
            .addGenericData("alertSelect", this.alertSelect())
            .addGenericData("alertMode", this.alertMode())
            .addGenericData("alertPol", this.alertPolarity())
            .addHeaderFileData("mcp9808", {
                path: "temperature-mcp98xx/",
                name: "mcp9808.h",
            })
            .addHeaderFileData("mcp9808_config", {
                path: "temperature-mcp98xx/",
                name: "mcp9808_config.h",
            })
            .addHeaderFileData("mcp98xx_i2c", {
                path: "temperature-mcp98xx/",
                name: `${
                    this.getModel().getComponentValue("device")?.toLocaleLowerCase() ??
                    "mcp98xx"
                }_i2c.h`,
            })
            .addHeaderFileData("mcp98xx_types", {
                path: "temperature-mcp98xx/",
                name: "mcp98xx_types.h",
            })
            .addHeaderFileData("mcp98xx_interface", {
                path: "temperature-mcp98xx/",
                name: "mcp98xx_interface.h",
            })
            .addHeaderFileData("mcc", {
                path: "system/",
                name: "system.h",
            })
            .addHeaderFileData("i2c", {
                path: "i2c_host/",
                name: `${
                    ImportsHelpers["i2c_host_basic"]
                        .getPayload(this.getModel())
                        ?.moduleName.toLocaleLowerCase() ?? "i2c"
                }.h`,
            })
            .addResolvePath("mcp98xx_src", "temperature-mcp98xx/src/")
            .addResolvePath("mcp98xx_h", "/")
            .addFirmwareApiData(
                "i2cInterface",
                ImportsHelpers["i2c_host_basic"].getFirmwareApi(this.getModel()) ?? {},
            )
            .addGenericData(
                "isI2cInterruptDriven",
                ImportsHelpers["i2c_host_basic"].getPayload(this.getModel())
                    ?.interruptDriven ?? false,
            )
            .addGenericData(
                "modInstance",
                ImportsHelpers["i2c_host_basic"].getPayload(this.getModel())
                    ?.moduleInstance,
            )
            .addGenericData(
                "hasI2C",
                this.getModel().getImportValue("i2c_host_basic") ? true : false,
            )
            .addGenericData("isMssp", this.isMSSP())
            .buildTemplateData();
    };

    private getMyAlerts = (): Processor.Alert[] => {
        let intPinAttribs: any = this.getModel().getComponentValue("ioOutPin");
        if (typeof intPinAttribs === "string") {
            intPinAttribs = JSON.parse(intPinAttribs) as Record<string, pin_attribs>;
        }

        return AlertHelper.createAlertBuilder()
            .addConditionalAlert(
                (getKeys(intPinAttribs)?.length ?? 0).toString(),
                "0",
                AlertTypes.Warning,
                `Select an ALERT Pin for ${this.getModel().getComponentValue("device")}`,
            )
            .addConditionalAlert(
                values(intPinAttribs)?.[0]?.ioc ?? "ANY",
                "NONE",
                AlertTypes.Warning,
                "Configure the ALERT Pin's Interrupt on Change in the Pins module.",
            )
            .addConditionalAlert(
                values(intPinAttribs)?.[0]?.ioc ?? "ANY",
                "INTDIS_BUFFEN",
                AlertTypes.Warning,
                "Configure the ALERT Pin's Interrupt on Change in the Pins module.",
            )
            .addConditionalAlert(
                (getKeys(intPinAttribs)?.length ?? 0) > 0,
                "true",
                AlertTypes.Hint,
                `An ALERT pin is selected. Connect the ${
                    this.getModel().getComponentValue("device") ?? "MCP98XX"
                }'s ALERT pin to the selected GPIO.`,
            )
            .addConditionalAlert(
                this.getModel().getComponentValue("i2c_host_basic"),
                "None",
                AlertTypes.Warning,
                `Select I2C Dependency. If no I2C Host modules are available, modify the generated ${this.getModel()
                    .getComponentValue("device")
                    ?.toLowerCase()}_i2c.c file and assign APIs to the i2c_host_interface.`,
            )
            .addStaticAlert(
                AlertTypes.Hint,
                "The A2, A1, and A0 address pins are set externally. Make sure that the address pins are configured correctly on the hardware setup.",
            )
            .addConditionalAlert(
                this.getModel().isComponentValue("tempWinLock") ||
                    this.getModel().isComponentValue("tempCritLock"),
                "true",
                AlertTypes.Hint,
                "Enabled lock bits can only be cleared by an internal reset",
            )
            .addConditionalAlert(
                this.getModel().getComponentValue("ioc"),
                "true",
                AlertTypes.Hint,
                "Select Interrupt On Change on the Pins Manager",
            )
            .buildAlerts();
    };

    private calculatedFunction = (): any => {
        return;
    };

    private componentNameValidator = (): any => {
        return {
            pattern: this.cValidator.getRjsfValidation().pattern,
        };
    };

    private getCustomUiErrors = (componentName: string): Error[] | undefined => {
        switch (componentName) {
            case "componentName":
                return [
                    {
                        name: "pattern",
                        message: this.cValidator.getCustomErrorMessage(),
                    },
                ];
            default:
                return undefined;
        }
    };

    private getTempBoundaryValidator = (): any => {
        const unit = this.getModel().getComponentValue("unit");
        if (unit === "Fahrenheit") {
            return {
                minimum: -40,
                maximum: 257,
            };
        } else {
            return {
                minimum: -40,
                maximum: 125,
            };
        }
    };

    private overrideOptions = (componentName: string): any => {
        let options: any;
        const optionVal: string[] = [];

        switch (componentName) {
            case "tempResolution":
                if (this.getModel().getComponentValue("unit") === "Fahrenheit") {
                    for (let i = 0; i < resolutionOptions.length; i++) {
                        optionVal[i] =
                            "+" +
                            this.celciusToFahrenheit(resolutionOptions[i]).toString();
                    }
                    options = optionVal;
                } else {
                    for (let i = 0; i < resolutionOptions.length; i++) {
                        optionVal[i] = "+" + resolutionOptions[i].toString();
                    }
                    options = optionVal;
                }
                break;

            case "tempHysteresis":
                if (this.getModel().getComponentValue("unit") === "Fahrenheit") {
                    for (let i = 0; i < hysteresisOptions.length; i++) {
                        optionVal[i] = this.celciusToFahrenheit(
                            hysteresisOptions[i],
                        ).toString();
                    }
                    options = optionVal;
                } else {
                    for (let i = 0; i < hysteresisOptions.length; i++) {
                        optionVal[i] = hysteresisOptions[i].toString();
                    }
                    options = optionVal;
                }
                break;
        }
        return options;
    };

    private readonly i2cClientAddrssConfig = (): any => {
        let initAddress = 0x18;
        const val = this.getModel().getState()?.main?.communication?.addPinConfig;
        if (val) {
            if (val[0]["pinA0"] === "VCC") {
                initAddress = initAddress | 0x01;
            }
            if (val[0]["pinA1"] === "VCC") {
                initAddress = initAddress | 0x02;
            }
            if (val[0]["pinA2"] === "VCC") {
                initAddress = initAddress | 0x04;
            }
        }
        return "0x" + Number(initAddress).toString(16).toUpperCase();
    };

    private readonly getTempDesc = (componentName: string): string | undefined => {
        let changeDesc: string | undefined;
        switch (componentName) {
            case "tempUpperBoundary":
                if (this.getModel().getComponentValue("unit") === "Fahrenheit") {
                    changeDesc = "Temperature Upper Boundary (F)";
                }
                break;
            case "tempLowerBoundary":
                if (this.getModel().getComponentValue("unit") === "Fahrenheit") {
                    changeDesc = "Temperature Lower Boundary (F)";
                }
                break;
            case "tempCritBoundary":
                if (this.getModel().getComponentValue("unit") === "Fahrenheit") {
                    changeDesc = "Temperature Critical Boundary (F)";
                }
                break;
            case "tempResolution":
                if (this.getModel().getComponentValue("unit") === "Fahrenheit") {
                    changeDesc = "Temperature Resolution (F)";
                }
                break;
            case "tempHysteresis":
                if (this.getModel().getComponentValue("unit") === "Fahrenheit") {
                    changeDesc = "Temperature Hysteresis (F)";
                }
                break;
        }
        return changeDesc;
    };

    private readonly isComponentEnabled = (
        componentName: string,
    ): boolean | undefined => {
        let isEnabled: boolean | undefined;
        switch (componentName) {
            case "tempHysteresis":
                {
                    if (
                        this.getModel().isComponentValue("tempCritLock") === true ||
                        this.getModel().isComponentValue("tempWinLock") === true
                    ) {
                        isEnabled = false;
                    }
                }
                break;
            case "tempUpperBoundary":
                if (this.getModel().isComponentValue("tempWinLock") === true) {
                    isEnabled = false;
                }
                break;
            case "tempLowerBoundary":
                if (this.getModel().isComponentValue("tempWinLock") === true) {
                    isEnabled = false;
                }
                break;
            case "tempCritBoundary":
                if (this.getModel().isComponentValue("tempCritLock") === true) {
                    isEnabled = false;
                }
                break;
            case "alertTrigger":
                if (
                    this.getModel().isComponentValue("alertControl") === false ||
                    this.getModel().isComponentValue("tempWinLock") === true
                ) {
                    isEnabled = false;
                }
                break;
            case "alertMode":
                if (
                    this.getModel().isComponentValue("alertControl") === false ||
                    this.getModel().getComponentValue("alertTrigger") === "Crit Only" ||
                    this.getModel().isComponentValue("tempWinLock") === true ||
                    this.getModel().isComponentValue("tempCritLock") === true
                ) {
                    isEnabled = false;
                }
                break;
            case "alertPolarity":
                if (
                    this.getModel().getComponentValue("alertControl") === false ||
                    this.getModel().getComponentValue("tempWinLock") === true ||
                    this.getModel().getComponentValue("tempCritLock") === true
                ) {
                    isEnabled = false;
                }
                break;
            case "alertControl":
                if (
                    this.getModel().getComponentValue("tempWinLock") === true ||
                    this.getModel().getComponentValue("tempCritLock") === true
                ) {
                    isEnabled = false;
                }
                break;
            case "operation":
                isEnabled = this.hasArgsForShutdown();
                break;
            default:
                break;
        }
        return isEnabled;
    };

    private readonly upperBoundaryGet = (): number | undefined => {
        let val = this.getModel().getComponentValue("tempUpperBoundary");

        if (val) {
            if (this.getModel().getComponentValue("unit") === "Fahrenheit") {
                val = this.fahrenheitToCelsius(val);
            }
        }
        return val;
    };

    private readonly lowerBoundaryGet = (): number | undefined => {
        let val = this.getModel().getComponentValue("tempLowerBoundary");
        if (val) {
            if (this.getModel().getComponentValue("unit") === "Fahrenheit") {
                val = this.fahrenheitToCelsius(val);
            }
        }
        return val;
    };

    private readonly critBoundaryGet = (): number | undefined => {
        let val = this.getModel().getComponentValue("tempCritBoundary");
        if (val) {
            if (this.getModel().getComponentValue("unit") === "Fahrenheit") {
                val = this.fahrenheitToCelsius(val);
            }
        }
        return val;
    };

    private fahrenheitToCelsius = (tempVal: number): number => {
        tempVal = ((tempVal - 32) * 5) / 9;
        return tempVal;
    };

    private celciusToFahrenheit = (tempVal: number): number => {
        tempVal = (tempVal * 9) / 5 + 32;
        return tempVal;
    };

    private readonly opMode = (): number => {
        let state: number;
        if (this.getModel().isComponentValue("operation") === true) {
            state = 1;
        } else {
            state = 0;
        }
        return state;
    };

    private readonly tempResolutionGet = (): string | undefined => {
        let val = this.getModel().getComponentValue("tempResolution");
        let resolution: string | undefined;
        if (val) {
            if (this.getModel().getComponentValue("unit") === "Fahrenheit") {
                if (val === "+32.1125") {
                    val =
                        "+" +
                        this.fahrenheitToCelsius(+val)
                            .toFixed(4)
                            .toString();
                } else if (val === "+32.225") {
                    val =
                        "+" +
                        this.fahrenheitToCelsius(+val)
                            .toFixed(3)
                            .toString();
                } else if (val === "+32.45") {
                    val =
                        "+" +
                        this.fahrenheitToCelsius(+val)
                            .toFixed(2)
                            .toString();
                } else {
                    val =
                        "+" +
                        this.fahrenheitToCelsius(+val)
                            .toFixed(1)
                            .toString();
                }
            }
            if (val === "+0.5") {
                resolution = "RESOLUTION_0_5";
            } else if (val === "+0.25") {
                resolution = "RESOLUTION_0_25";
            } else if (val === "+0.125") {
                resolution = "RESOLUTION_0_125";
            } else {
                resolution = "RESOLUTION_0_0625";
            }
        }
        return resolution;
    };

    private readonly tempHysteresisGet = (): string | undefined => {
        let val = this.getModel().getComponentValue("tempHysteresis");
        let hysteresis: string | undefined;

        if (val) {
            if (this.getModel().getComponentValue("unit") === "Fahrenheit") {
                if (val === "34.7") {
                    val = this.fahrenheitToCelsius(+val)
                        .toFixed(1)
                        .toString();
                } else {
                    val = this.fahrenheitToCelsius(+val)
                        .toFixed(0)
                        .toString();
                }
            }
            if (val === "1.5") {
                hysteresis = "HYSTERESIS_1_5";
            } else if (val === "3") {
                hysteresis = "HYSTERESIS_3";
            } else if (val === "6") {
                hysteresis = "HYSTERESIS_6";
            } else {
                hysteresis = "HYSTERESIS_0";
            }
        }
        return hysteresis;
    };

    private readonly winLock = (): number => {
        let state: number;
        if (this.getModel().isComponentValue("tempWinLock") === true) {
            state = 1;
        } else {
            state = 0;
        }
        return state;
    };

    private readonly critLock = (): number => {
        let state: number;
        if (this.getModel().isComponentValue("tempCritLock") === true) {
            state = 1;
        } else {
            state = 0;
        }
        return state;
    };

    private readonly alertControl = (): number => {
        let state: number;
        if (this.getModel().isComponentValue("alertControl") === true) {
            state = 1;
        } else {
            state = 0;
        }
        return state;
    };

    private readonly alertSelect = (): number => {
        let state: number;
        if (this.getModel().getComponentValue("alertTrigger") === "Crit Only") {
            state = 1;
        } else {
            state = 0;
        }
        return state;
    };

    private readonly alertMode = (): number => {
        let state: number;
        if (this.getModel().getComponentValue("alertMode") === "Interrupt Mode") {
            state = 1;
        } else {
            state = 0;
        }
        return state;
    };

    private readonly alertPolarity = (): number => {
        let state: number;
        if (this.getModel().getComponentValue("alertPolarity") === "Active-High") {
            state = 1;
        } else {
            state = 0;
        }
        return state;
    };

    private readonly overrideResolution = (): string | undefined => {
        let val = this.getModel().getState()?.main?.temperature?.tempResolution;
        const countDecimals = (value: number): number => {
            return value.toString().split(".")[1].length || 0;
        };
        if (val) {
            if (
                this.getModel().getComponentValue("unit") === "Fahrenheit" &&
                +val < 32.1125
            ) {
                val = "+" + this.celciusToFahrenheit(+val).toString();
            } else if (
                this.getModel().getComponentValue("unit") === "Celsius" &&
                +val > 0.5
            ) {
                val =
                    "+" +
                    this.fahrenheitToCelsius(+val)
                        .toFixed(countDecimals(+val))
                        .toString();
            }
        }
        return val;
    };

    private readonly overrideHysteresis = (): string | undefined => {
        let val = this.getModel().getState()?.main?.temperature?.tempHysteresis;
        if (val) {
            if (this.getModel().getComponentValue("unit") === "Fahrenheit" && +val < 32) {
                val = this.celciusToFahrenheit(+val).toString();
            } else if (
                this.getModel().getComponentValue("unit") === "Celsius" &&
                +val > 6
            ) {
                if (
                    this.getModel().getState()?.main?.temperature?.tempHysteresis ===
                    "34.7"
                ) {
                    val = this.fahrenheitToCelsius(+val)
                        .toFixed(1)
                        .toString();
                } else {
                    val = this.fahrenheitToCelsius(+val)
                        .toFixed(0)
                        .toString();
                }
            } else {
                val = undefined;
            }
        }
        return val;
    };

    private readonly isRedundant = (): boolean => {
        const defName = "MCP98XX";
        const cName = this.getModel().getComponentValue("componentName") ?? "";
        return defName === cName;
    };

    private readonly isMSSP = (): boolean => {
        let isMssp = false;
        const modName = this.getModel().getImportValue("i2c_host_basic")?.moduleName;
        const modIns = this.getModel()
            .getImportValue("i2c_host_basic")
            ?.moduleInstance.toString();
        if (modName === `MSSP${modIns}`) {
            isMssp = true;
        } else {
            isMssp = false;
        }
        return isMssp;
    };

    private readonly hasArgsForShutdown = (): boolean => {
        let defArgs = true;
        if (this.getRequestedArg("lowPowerMode") !== undefined) {
            defArgs = false;
        } else {
            defArgs = true;
        }
        return defArgs;
    };
}
