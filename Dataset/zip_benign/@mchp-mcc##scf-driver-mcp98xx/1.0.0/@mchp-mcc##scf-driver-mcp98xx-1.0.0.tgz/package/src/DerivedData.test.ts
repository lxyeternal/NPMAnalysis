import { mockAssignedModule } from "../generated_module/tests/processor.test";
import { mockState } from "../generated_module/tests/AppModel.test";
import * as MyDerivedData from "./DerivedData";
import { getModel } from "../generated_module/tests/AppModel.test";
import { DerivedData } from "../generated_module/src/types/AutoModuleTypes";
import { AppModel, MyState } from "../generated_module/src/types/AutoModuleTypes";

const getMyEnableState = (
    shtdwnMd: boolean | undefined,
    windowLock: boolean | undefined,
    criticalLock: boolean | undefined,
    alertOutCon: boolean | undefined,
    alertOutSel: string | undefined,
    alertOutMod: string | undefined,
    alertOutPol: string | undefined,
): MyState => {
    return {
        main: {
            general: {
                operation: shtdwnMd,
            },
            temperature: {
                tempWinLock: windowLock,
                tempCritLock: criticalLock,
            },
            alert: {
                alertControl: alertOutCon,
                alertTrigger: alertOutSel,
                alertMode: alertOutMod,
                alertPolarity: alertOutPol,
            },
        },
    };
};

const getMyUnitState = (temperatureUnit: string | undefined): MyState => {
    return {
        main: {
            general: {
                unit: temperatureUnit,
            },
        },
    };
};

const getMyAddressState = (
    A2: string | undefined,
    A1: string | undefined,
    A0: string | undefined,
): MyState => {
    return {
        main: {
            communication: {
                addPinConfig: {
                    0: {
                        pinA2: A2,
                        pinA1: A1,
                        pinA0: A0,
                        rowId: 0,
                        uid: "defaultRow_0",
                    },
                },
            },
        },
    };
};

const getMyTempValState = (
    temperatureUnit: string | undefined,
    upperTemp: number | undefined,
    lowerTemp: number | undefined,
    critTemp: number | undefined,
): MyState => {
    return {
        main: {
            general: {
                unit: temperatureUnit,
            },
            temperature: {
                tempUpperBoundary: upperTemp,
                tempLowerBoundary: lowerTemp,
                tempCritBoundary: critTemp,
            },
        },
    };
};

const getMyInterfaceState = (apiPrefix: string | undefined): MyState => {
    return {
        main: {
            software: {
                componentName: apiPrefix,
            },
        },
    };
};

const getMyResolutionHysteresisState = (
    temperatureUnit: string | undefined,
    tempReso: string | undefined,
    tempHyst: string | undefined,
): MyState => {
    return {
        main: {
            general: {
                unit: temperatureUnit,
            },
            temperature: {
                tempResolution: tempReso,
                tempHysteresis: tempHyst,
            },
        },
    };
};

describe("Derived Data", () => {
    describe("C custom name validator", () => {
        it("invalid Custom name", () => {
            const mockModule = mockAssignedModule(mockState());
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            const cName = new RegExp(derivedFunctions.componentNameValidator().pattern);
            expect(cName.test("custom-Name")).toBe(false);
        });
    });
    describe("Dynamic UI Values", () => {
        it("Fahrenheit Unit", () => {
            let mockState: MyState = {};
            mockState = getMyUnitState("Fahrenheit");
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.overrideTitle?.("tempUpperBoundary")).toBe(
                "Temperature Upper Boundary (F)",
            );
            expect(derivedFunctions?.overrideTitle?.("tempLowerBoundary")).toBe(
                "Temperature Lower Boundary (F)",
            );
            expect(derivedFunctions?.overrideTitle?.("tempCritBoundary")).toBe(
                "Temperature Critical Boundary (F)",
            );
            expect(derivedFunctions?.overrideTitle?.("tempResolution")).toBe(
                "Temperature Resolution (F)",
            );
            expect(derivedFunctions?.overrideTitle?.("tempHysteresis")).toBe(
                "Temperature Hysteresis (F)",
            );
            expect(derivedFunctions?.overrideDefaultValues?.("tempHysteresis")).toBe(
                "32",
            );
            expect(derivedFunctions?.overrideDefaultValues?.("tempResolution")).toBe(
                "+32.1125",
            );
            expect(derivedFunctions?.tempUpperBoundaryValidator().maximum).toBe(257);
            expect(derivedFunctions?.overrideOptions?.("tempResolution")).toBeDefined();
            expect(derivedFunctions?.overrideOptions?.("tempHysteresis")).toBeDefined();
        });
    });
    describe("I2C device address", () => {
        it("Test Case 1 - Client Address Config", () => {
            let mockState: MyState = {};
            mockState = getMyAddressState("VCC", "GND", "VCC");
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.i2cClientAdd?.()).toBe("0x1D");
        });
        it("Test Case 2 - Client Address Config", () => {
            let mockState: MyState = {};
            mockState = getMyAddressState("GND", "VCC", "GND");
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.i2cClientAdd?.()).toBe("0x1A");
        });
    });

    describe("Is Enabled", () => {
        it("Test case 1 - Is Component Enabled?", () => {
            let mockState: MyState = {};
            mockState = getMyEnableState(
                true,
                true,
                true,
                true,
                "Crit Only",
                "Interrupt Mode",
                "Active-High",
            );
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.isEnabled?.("tempHysteresis")).toBe(false);
            expect(derivedFunctions?.isEnabled?.("tempUpperBoundary")).toBe(false);
            expect(derivedFunctions?.isEnabled?.("tempLowerBoundary")).toBe(false);
            expect(derivedFunctions?.isEnabled?.("tempCritBoundary")).toBe(false);
            expect(derivedFunctions?.isEnabled?.("alertTrigger")).toBe(false);
            expect(derivedFunctions?.isEnabled?.("alertMode")).toBe(false);
            expect(derivedFunctions?.isEnabled?.("alertPolarity")).toBe(false);
            expect(derivedFunctions?.isEnabled?.("alertControl")).toBe(false);
        });
        it("Test case 2 - Is Component Enabled?", () => {
            let mockState: MyState = {};
            mockState = getMyEnableState(
                true,
                false,
                true,
                true,
                "Upper/Lower/Crit",
                "Interrupt Mode",
                "Active-High",
            );
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.isEnabled?.("alertMode")).toBe(false);
            expect(derivedFunctions?.isEnabled?.("alertPolarity")).toBe(false);
        });
        it("Test case 3 - Is Component Enabled?", () => {
            let mockState: MyState = {};
            mockState = getMyEnableState(
                true,
                false,
                false,
                true,
                "Upper/Lower/Crit",
                "Interrupt Mode",
                "Active-High",
            );
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.isEnabled?.("alertTrigger")).toBeUndefined();
            expect(derivedFunctions?.isEnabled?.("alertMode")).toBeUndefined();
            expect(derivedFunctions?.isEnabled?.("alertPolarity")).toBeUndefined();
        });

        it("Test case 4 - Get Values", () => {
            let mockState: MyState = {};
            mockState = getMyEnableState(
                true,
                true,
                true,
                true,
                "Upper/Lower/Crit",
                "Interrupt Mode",
                "Active-High",
            );
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.templateData?.()?.tempWinLock).toBe(1);
        });

        it("Test case 5 - Get Values", () => {
            let mockState: MyState = {};
            mockState = getMyEnableState(
                true,
                false,
                false,
                true,
                "Upper/Lower/Crit",
                "Interrupt Mode",
                "Active-High",
            );
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.templateData?.()?.alertMode).toBe(1);
        });

        it("Test case 6 - Get Values", () => {
            let mockState: MyState = {};
            mockState = getMyEnableState(
                true,
                false,
                false,
                true,
                "Crit Only",
                "Comparator Mode",
                "Active-High",
            );
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.templateData?.()?.alertSelect).toBe(1);
        });
    });

    describe("Get Temperature boundary Values", () => {
        it("Temperature Values in Fahrenheit", () => {
            let mockState: MyState = {};
            mockState = getMyTempValState("Fahrenheit", 50, -40, 257);
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.templateData?.()?.tempLower).toBe(-40);
            expect(derivedFunctions?.templateData?.()?.tempUpper).toBe(10);
            expect(derivedFunctions?.templateData?.()?.tempCrit).toBe(125);
        });

        it("Temperature Values in Celsius", () => {
            let mockState: MyState = {};
            mockState = getMyTempValState("Celsius", 80, -8, 100);
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.templateData?.()?.tempLower).toBe(-8);
            expect(derivedFunctions?.templateData?.()?.tempUpper).toBe(80);
            expect(derivedFunctions?.templateData?.()?.tempCrit).toBe(100);
        });
    });

    describe("Temperature Resolution and Hysteresis", () => {
        it("Test Case 1 - Temperature Resolution and Hysteresis values", () => {
            let mockState: MyState = {};
            mockState = getMyResolutionHysteresisState("Fahrenheit", "+32.1125", "34.7");
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.templateData?.()?.tempResolutionVal).toBe(
                "RESOLUTION_0_0625",
            );
            expect(derivedFunctions?.templateData?.()?.tempHysteresisVal).toBe(
                "HYSTERESIS_1_5",
            );
        });

        it("Test Case 2 - Temperature Resolution and Hysteresis values", () => {
            let mockState: MyState = {};
            mockState = getMyResolutionHysteresisState("Fahrenheit", "+32.225", "37.4");
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.templateData?.()?.tempResolutionVal).toBe(
                "RESOLUTION_0_125",
            );
            expect(derivedFunctions?.templateData?.()?.tempHysteresisVal).toBe(
                "HYSTERESIS_3",
            );
        });

        it("Test Case 3 - Temperature Resolution and Hysteresis values", () => {
            let mockState: MyState = {};
            mockState = getMyResolutionHysteresisState("Fahrenheit", "+32.45", "42.8");
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.templateData?.()?.tempResolutionVal).toBe(
                "RESOLUTION_0_25",
            );
            expect(derivedFunctions?.templateData?.()?.tempHysteresisVal).toBe(
                "HYSTERESIS_6",
            );
        });

        it("Test Case 4 - Temperature Resolution value", () => {
            let mockState: MyState = {};
            mockState = getMyResolutionHysteresisState("Fahrenheit", "+32.9", "42.8");
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.templateData?.()?.tempResolutionVal).toBe(
                "RESOLUTION_0_5",
            );
        });

        it("Test Case 5 - Temperature Resolution and Hysteresis values", () => {
            let mockState: MyState = {};
            mockState = getMyResolutionHysteresisState(
                "Fahrenheit",
                undefined,
                undefined,
            );
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.templateData?.()?.tempResolutionVal).toBe(
                "RESOLUTION_0_0625",
            );
            expect(derivedFunctions?.templateData?.()?.tempHysteresisVal).toBe(
                "HYSTERESIS_0",
            );
        });

        it("Test Case 6 - Override Temperature Resolution and Hysteresis values", () => {
            let mockState: MyState = {};
            mockState = getMyResolutionHysteresisState("Fahrenheit", "+0.25", "3");
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.tempResolution?.()).toBe("+32.45");
            expect(derivedFunctions?.tempHysteresis?.()).toBe("37.4");
        });

        it("Test Case 7 - Override Temperature Resolution and Hysteresis values", () => {
            let mockState: MyState = {};
            mockState = getMyResolutionHysteresisState("Celsius", "+32.225", "34.7");
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.tempResolution?.()).toBe("+0.125");
            expect(derivedFunctions?.tempHysteresis?.()).toBe("1.5");
        });

        it("Test Case 8 - Override Temperature Resolution and Hysteresis values", () => {
            let mockState: MyState = {};
            mockState = getMyResolutionHysteresisState("Celsius", "+32.225", "42.8");
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(derivedFunctions?.tempResolution?.()).toBe("+0.125");
            expect(derivedFunctions?.tempHysteresis?.()).toBe("6");
        });
    });
    describe("calculatedFunction test case", () => {
        const mockModule = mockAssignedModule(mockState(true));
        const mockModel = getModel(mockModule, MyDerivedData.getDerivedData);
        const derivedData = mockModel?.getDerivedData() as DerivedData;
        const derivedFunctions = derivedData?.getMyFunctions();
        test("Test for getModel", () => {
            expect(derivedFunctions?.calculatedFunction()).toBeUndefined();
        });
    });

    describe("Empty DerivedData Test Case", () => {
        let emptyModel: AppModel | undefined;
        const emptyDerivedData = MyDerivedData?.getDerivedData(
            emptyModel as AppModel,
        ) as DerivedData;
        const emptyDerivedFunctions = emptyDerivedData?.getMyFunctions();
        test("Test for EmptyDerivedData", () => {
            expect(emptyDerivedFunctions).toEqual({});
            expect(emptyDerivedData?.getModel()).toBeUndefined();
        });
    });

    describe("Interface Payload", () => {
        test("mcp98xx-basic_payload", () => {
            let mockState: MyState = {};
            mockState = getMyInterfaceState("TempSensor");
            const mockModule = mockAssignedModule(mockState);
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            expect(
                derivedFunctions?.["mcp98xx-basic_payload"]?.()?.interfaceApi,
            ).toBeDefined();
            expect(
                derivedFunctions?.["mcp98xx-basic_payload"]?.()?.interfaceApi.simpleApi,
            ).toBeDefined();
        });
    });

    describe("MCP98xx Interface ", () => {
        it("MCP98xx Interface Argument", () => {
            let mockModule = mockAssignedModule(mockState(true));
            mockModule = {
                ...(mockModule ?? {}),
                exports: {
                    ...(mockModule?.exports ?? {}),
                    mcp98xx_interface: {
                        ...(mockModule?.exports?.mcp98xx_interface ?? {}),
                        interfaces: [
                            {
                                ...(mockModule?.exports?.mcp98xx_interface
                                    ?.interfaces?.[0] ?? {}),
                                interfaceId: {
                                    ...(mockModule?.exports?.mcp98xx_interface
                                        ?.interfaces?.[0]?.interfaceId ?? {}),
                                    name: "mcp98xx-basic",
                                    version: "0.1.0",
                                },
                                args: {
                                    ...(mockModule?.exports?.mcp98xx_interface
                                        ?.interfaces?.[0]?.args ?? {}),
                                    requestId: {
                                        componentName: "TempSensor",
                                    },
                                },
                            },
                        ],
                    },
                },
            };
            const model = getModel(mockModule, MyDerivedData.getDerivedData);
            const derivedData = model?.getDerivedData() as DerivedData;
            const derivedFunctions = derivedData?.getMyFunctions();
            const mcp98xx_interface_payload = derivedFunctions?.[
                "mcp98xx-basic_payload"
            ]?.();
            expect(mcp98xx_interface_payload).toBeDefined();
        });
    });
});
