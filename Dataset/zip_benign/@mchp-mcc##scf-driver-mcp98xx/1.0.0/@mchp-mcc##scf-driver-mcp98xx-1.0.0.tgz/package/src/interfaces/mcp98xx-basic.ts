import { InterfaceId } from "@microchip/scf-common/lib/InterfaceId";
import * as Creator from "@microchip/scf-common/lib/Creator";
import * as Processor from "@microchip/scf-common/lib/Processor";
import * as InterfaceTypes from "@microchip/scf-interface";

export interface Arguments extends InterfaceTypes.Arguments {
    componentName?: string;
    device?: string;
    lowPowerMode?: boolean;
}

export interface API extends InterfaceTypes.CFunctions {
    Initialize: InterfaceTypes.CFunction;
}

export interface ProcessedPayload extends InterfaceTypes.ProcessedPayload {
    interfaceApi?: InterfaceTypes.FirmwareAPIPayload<API>;
    componentName?: string;
    device?: string;
    shutdownMode?: boolean;
    tempUnit?: string;
    i2cClientAddress: string | undefined;
    tempWinLock?: boolean;
    tempCritLock?: boolean;
    tempResolution?: string;
    tempHysteresis?: string;
    tempLowerBoundary?: number;
    tempUpperBoundary?: number;
    tempCritBoundary?: number;
    alertCtrl?: boolean;
    alertSlct?: string;
    alertMd?: string;
    alertPol?: string;
}

export type ProcessedExportInterface = Processor.ProcessedInterface<
    ProcessedPayload,
    Arguments
>;

type CreatorExportInterface = Creator.Interface<ProcessedPayload>;
export interface API extends InterfaceTypes.CFunctions {
    Initialize: InterfaceTypes.CFunction;
    TemperatureRead: InterfaceTypes.CFunction;
    shdnModeEnable: InterfaceTypes.CFunction;
    shdnModeDisable: InterfaceTypes.CFunction;
    celsiusToFahrenheit: InterfaceTypes.CFunction;
    fahrenheitToCelsius: InterfaceTypes.CFunction;
}

export const getInterfaceId = (): InterfaceId => {
    return {
        name: "mcp98xx-basic",
        version: "0.1.0",
    };
};

const createPrototypeImport = (): Creator.Import => {
    return {
        interfaceId: getInterfaceId(),
    };
};

const createPrototypeExport = (): Creator.Export<CreatorExportInterface[]> => {
    return {
        interfaces: [{ interfaceId: getInterfaceId() }],
    };
};

export const createMock = (): ProcessedExportInterface => {
    return {
        interfaceId: getInterfaceId(),
        payload: {
            componentName: "mcp98xx",
            device: "MCP9808",
            shutdownMode: false,
            tempUnit: "Celsius",
            i2cClientAddress: "0x18",
            tempWinLock: false,
            tempCritLock: false,
            tempResolution: "+0.0625",
            tempHysteresis: "0",
            tempLowerBoundary: -40,
            tempUpperBoundary: 0,
            tempCritBoundary: 125,
            alertCtrl: false,
            alertSlct: "Upper/Lower/Crit",
            alertMd: "Comparator Mode",
            alertPol: "Active-High",
        },
        args: {
            requestId: {
                componentName: "mcp98xx",
                device: "MCP9808",
                shutdownMode: false,
                tempUnit: "Celsius",
                i2cClientAddress: "0x19",
                tempWinLock: false,
                tempCritLock: false,
                tempResolution: "+0.0625",
                tempHysteresis: "0",
                tempLowerBoundary: -40,
                tempUpperBoundary: 0,
                tempCritBoundary: 125,
                alertCtrl: false,
                alertSlct: "Upper/Lower/Crit",
                alertMd: "Comparator Mode",
                alertPol: "Active-High",
            },
        },
    };
};

export const createApi = (prefix: string): API => {
    return {
        Initialize: {
            name: prefix + "_Initialize",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
                {
                    name: "deviceInit",
                    type: prefix.toUpperCase() + "_DEVICE_INIT_t",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        TemperatureRead: {
            name: prefix + "_TemperatureRawValueRead",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
                {
                    name: "tempRawVal",
                    type: "uint16_t*",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        shdnModeEnable: {
            name: prefix + "_ShutdownModeEnable",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        shdnModeDisable: {
            name: prefix + "_ShutdownModeDisable",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        sensorConfigSet: {
            name: prefix + "_SensorConfigSet",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
                {
                    name: "sensorConfigReg",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        sensorConfigGet: {
            name: prefix + "_SensorConfigGet",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
                {
                    name: "sensorConfigVal",
                    type: prefix.toUpperCase() + "_CONFIG_REG_PTR",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        hysteresisSet: {
            name: prefix + "_TemperatureHysteresisSet",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
                {
                    name: "tempHysteresisVal",
                    type: prefix.toUpperCase() + "_HYSTERESIS_VALUE_t",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        tempCritLock: {
            name: prefix + "_TemperatureCriticalLockEnable",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        tempWinLock: {
            name: prefix + "_TemperatureWindowLockEnable",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        alertClr: {
            name: prefix + "_AlertOutputClear",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        alertStat: {
            name: prefix + "_AlertOutputStatusRead",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
                {
                    name: "alertStat",
                    type: "bool*",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        alertConfigSet: {
            name: prefix + "_AlertConfigurationSet",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
                {
                    name: "alertConfig",
                    type: prefix.toUpperCase() + "_ALERT_CONFIG_t",
                },
                {
                    name: "alertSet",
                    type: "uint8_t",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        tempBoundarySet: {
            name: prefix + "_TemperatureBoundarySet",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
                {
                    name: "boundary",
                    type: prefix.toUpperCase() + "_TEMP_BOUNDARY_t",
                },
                {
                    name: "tempVal",
                    type: "float",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        tempBoundaryGet: {
            name: prefix + "_TemperatureBoundaryGet",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
                {
                    name: "boundary",
                    type: prefix.toUpperCase() + "_TEMP_BOUNDARY_t",
                },
                {
                    name: "tempVal",
                    type: "float*",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        tempRawToCelsius: {
            name: prefix + "_TemperatureRawToCelsius",
            arguments: [
                {
                    name: "rawVal",
                    type: "uint16_t",
                },
            ],
            returns: "float",
        },
        tempRawToFahrenheit: {
            name: prefix + "_TemperatureRawToFahrenheit",
            arguments: [
                {
                    name: "rawVal",
                    type: "uint16_t",
                },
            ],
            returns: "float",
        },
        ambientTempCelsius: {
            name: prefix + "_AmbientTemperatureCelsiusRead",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
                {
                    name: "ambientTemp",
                    type: "float*",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        ambientTempFahrenheit: {
            name: prefix + "_AmbientTemperatureFahrenheitRead",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
                {
                    name: "ambientTemp",
                    type: "float*",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        tempResolutionSet: {
            name: prefix + "_TempResolutionSet",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
                {
                    name: "tempResolution",
                    type: prefix.toUpperCase() + "_RESOLUTION_VALUE_t",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        tempResolutionGet: {
            name: prefix + "_TempResolutionGet",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
                {
                    name: "tempResolutionVal",
                    type: "uint8_t*",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        deviceInfoGet: {
            name: prefix + "_DeviceInfoGet",
            arguments: [
                {
                    name: "devicePtr",
                    type: prefix.toUpperCase() + "_DEVICE_CONTEXT_PTR",
                },
                {
                    name: "deviceInfo",
                    type: prefix.toUpperCase() + "_DEVICE_INFORMATION_t",
                },
                {
                    name: "deviceInfoVal",
                    type: "uint16_t*",
                },
            ],
            returns: prefix.toUpperCase() + "_STATUS_t",
        },
        celsiusToFahrenheit: {
            name: prefix + "_CelsiusToFahrenheit",
            arguments: [
                {
                    name: "tempVal",
                    type: "float",
                },
            ],
            returns: "float",
        },
        fahrenheitToCelsius: {
            name: prefix + "_FahrenheitToCelsius",
            arguments: [
                {
                    name: "tempVal",
                    type: "float",
                },
            ],
            returns: "float",
        },
    };
};

export const createFirmwareApi = (
    moduleName?: string,
    headerFiles?: InterfaceTypes.HeaderFile[],
    createCustomApi?: () => API,
): InterfaceTypes.FirmwareAPIPayload<API> => {
    const prefix: string = moduleName ? moduleName : "undefined";
    const api = createCustomApi ? createCustomApi() : createApi(prefix);

    return {
        api: api,
        simpleApi: InterfaceTypes.buildSimpleApi(api),
        headerFiles: headerFiles
            ? headerFiles
            : [
                  { name: prefix.toLowerCase() + ".h", path: "temperature-mcp98xx/" },
                  { name: prefix.toLowerCase() + "_i2c.h", path: "temperature-mcp98xx/" },
                  {
                      name: prefix.toLowerCase() + "_config.h",
                      path: "temperature-mcp98xx/",
                  },
                  { name: "mcp98xx_types.h", path: "temperature-mcp98xx/" },
                  { name: "mcp98xx_interface.h", path: "temperature-mcp98xx/" },
              ],
    };
};

interface Interface extends InterfaceTypes.Interface {
    createPrototypeImport: () => Creator.Import<Arguments>;
    createMock: () => ProcessedExportInterface;
    createFirmwareApi: (
        moduleName?: string,
        headerFiles?: InterfaceTypes.HeaderFile[],
        createCustomApi?: () => API,
    ) => InterfaceTypes.FirmwareAPIPayload<API>;
}

export const Interface: Interface = {
    createPrototypeExport: createPrototypeExport,
    createPrototypeImport: createPrototypeImport,
    getInterfaceId: getInterfaceId,
    createMock: createMock,
    createFirmwareApi: createFirmwareApi,
};
