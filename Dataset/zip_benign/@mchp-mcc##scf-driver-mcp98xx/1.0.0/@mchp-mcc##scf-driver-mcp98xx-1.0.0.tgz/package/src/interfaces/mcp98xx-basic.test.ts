import { Interface, createApi } from "./mcp98xx-basic";

describe("The mcp98xx-basic interface", () => {
    it("Get interfaceId", () => {
        const expectedResult = {
            name: "mcp98xx-basic",
            version: "0.1.0",
        };
        expect(Interface.getInterfaceId()).toMatchObject(expectedResult);
    });
    it("Test Case for Interface", () => {
        expect(Interface.createMock()).toBeDefined();
        expect(Interface.createPrototypeImport()).toBeDefined;
        expect(Interface.createPrototypeExport()).toBeDefined;
        expect(
            Interface.createFirmwareApi(
                "mcp98xx",
                [{ name: "mcp98xx.h", path: "temperature-mcp98xx/" }],
                () => createApi("MCP9808"),
            ),
        ).toBeDefined();
    });

    it("Create's api without name, headers, or custom API", () => {
        expect(Interface.createFirmwareApi()).toBeDefined();
    });
});
