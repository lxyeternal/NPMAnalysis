import { behaviour, direction, pin_row } from "@microchip/pin-standard";
import { getModel } from "../generated_module/tests/AppModel.test";
import { mockState } from "../generated_module/tests/AppModel.test";
import { mockAssignedModule } from "../generated_module/tests/processor.test";
import { getDerivedData } from "./DerivedData";
import { getRowData } from "./PinsLogic";

describe("PinsLogic --> Test Cases ", () => {
    describe("getRowData() test case: ", () => {
        const mockModule = mockAssignedModule(mockState());
        const model = getModel(mockModule, getDerivedData);

        const pinsData: pin_row = {
            name: "AlertPinTest",
            module: "MCP9808",
            function: "ALERT",
            direction: direction.input,
            filter: {
                module: "GPIO",
                aliasReEx: ".*",
            },
            attribs: [
                {
                    aliasReEx: ".*",
                    cname: "MCP9808_ALERT",
                    analog: false,
                },
            ],
            behaviour: behaviour.OPTIONAL_PIN_MUX,
        };

        it("Test for dummy pin data", () => {
            if (model) {
                expect(getRowData(model, pinsData)).toMatchObject(pinsData);
            }
        });
    });
});
