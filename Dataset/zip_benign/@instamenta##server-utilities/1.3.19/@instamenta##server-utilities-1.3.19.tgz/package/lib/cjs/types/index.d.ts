import { StrictAuthProp } from '@clerk/clerk-sdk-node';
import { Db, MongoClient, MongoClientOptions } from 'mongodb';
import express, { NextFunction, Request, Response } from 'express';
import StatusCode from '@instamenta/http-status-codes';
import Vlogger from "@instamenta/vlogger";
import 'dotenv/config';
export declare function useHttpServer(): express.Express;
export declare function startHttpServer(_server: express.Express): void;
export declare function useMongoDB(config?: MongoClientOptions | null): {
    database: Db;
    db_client: MongoClient;
};
export declare class GracefulShutdown {
    static process_on(_cases_?: string[]): void;
    static process_once(_cases_?: string[]): void;
}
export declare class ErrorMiddleware {
    static _errorHandler(e: Error, r: Request, w: Response, n: NextFunction): void;
    static _404Handler(r: Request, w: Response, n: NextFunction): void;
}
declare const Exports: {
    GracefulShutdown: typeof GracefulShutdown;
    ErrorMiddleware: typeof ErrorMiddleware;
    useHttpServer: typeof useHttpServer;
    useMongoDB: typeof useMongoDB;
    StatusCode: typeof StatusCode;
    Vlogger: typeof Vlogger;
};
export default Exports;
declare global {
    namespace Express {
        interface Request extends StrictAuthProp {
        }
    }
}
//# sourceMappingURL=index.d.ts.map