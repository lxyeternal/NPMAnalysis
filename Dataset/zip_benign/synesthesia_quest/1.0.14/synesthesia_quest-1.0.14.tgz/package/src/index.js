import {Quest} from './Quest';
import {ProcessQuestData} from './QuestAnalysis';

// check if window exists
window.Quest = Quest;
window.ProcessQuestData = ProcessQuestData;

export {
	Quest,
	ProcessQuestData
}
