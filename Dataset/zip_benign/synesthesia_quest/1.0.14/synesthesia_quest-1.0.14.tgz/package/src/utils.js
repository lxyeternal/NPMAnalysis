const _ = require('lodash');

export function subarrayIndex(arr, indices) {
  return _.map(indices, (index) => arr[index]);
}

export function findZero(arr) {
  var nonzeroIndices = _.map(arr, (v, k) => v > 0 ? k : -1);
  return _.filter(nonzeroIndices, (k) => k >= 0);
}

export function diff(arr) {
  const deltas = _.map(arr, (v, k) => k > 0 ? arr[k] - arr[k-1] : 0);
  deltas.shift();
  return deltas;
}

export function cumsum(arr) {
  var new_array = [];
  arr.reduce((a,b,i) => new_array[i] = a + b, 0);
  return new_array;
}

export function multiplyVector(a,b){
  return a.map((e,i) => e * b[i]);
}

export function indexOfMax(arr) {
  if (arr.length === 0) {
      return -1;
  }
  const maxVal = _.max(arr);
  return arr.indexOf(maxVal);
}

export function isReal(x){
  return !isNaN(x);
}

export function normalize(arr) {
  const sum = _.sum(arr);
  return _.map(arr, (x) => x / sum);
}
