import {isArray} from 'util';
import _ from "lodash";

var fzero = require("fzero");
const math = require('mathjs');

//   To be used within context of QUEST-like program.  Defines intensities at
//   which participants are likely to detect tone in noise at 75%
//   (threshold), 50%, 25% probabilities.  First row of returned matrix are
//   these labels.  The second gives the intensities in decibels, the third
//   in scale units (coefficient used to scale full-scaled tone).  Required
//   inputs are the QUEST structures produced by the CH QUEST procedure via
//   ch_auditory_quest. q_1 and q_2 variables are the structures produced by
//   the QUEST procedure.  t_mean is the arithmetic mean of the two threshold
//   estimates produced by the two interleaved staircases.

export function ProcessQuestData(q1, q2) {
  //Statistics
  var t1 = q1.mean();		// Recommended by Pelli (1989) and King-Smith et al. (1994) as the best way to ascertain threshold.
  var t2 = q2.mean()	// Recommended by Pelli (1989) and King-Smith et al. (1994) as the best way to ascertain threshold.

  // Take the arithmetic mean of these two threshold (75%) estimates.
  var tmean = math.mean([t1, t2]);

  var lambda = 0; // normally in config file//////////////////////
  var gamma = 0; // normally in config file//////////////////////

  return gumbelIntensities(q1, q2, tmean, lambda, gamma);
}

// changed 3/25/2019. Trying fixed beta at 3.5 (suggested generic beta value by Quest documentation) instead of individually estimating
function gumbelIntensities(q1, q2, tmean, lambda, gamma) {
  var returnStruct = {
    intensities: {},
    parameters: {},
    beta: 0,
  };

  const parameters = returnStruct.parameters;
  parameters.q1 = q1.betaAnalysis();
  parameters.q2 = q2.betaAnalysis();
  returnStruct.parameters = parameters;

  if (tmean < 0.027){
    var alpha = 0.027;
  } else {
    var alpha = tmean;
  }
  
  
  var beta = math.mean(q1.params.beta, q2.params.beta);
  returnStruct.beta = beta;

  // Override beta value
  // changed 3/25/2019. Trying fixed beta at 3.5 (suggested generic beta value by Quest documentation) instead of individually estimating
  // beta = 3.5;  THIS REMOVED 9/10/19 TO ALLOW BETA TO VARY BY TASK, DEFINED IN SETUP.

  const makeFn = (val) => {
    return (x) => {
      return (PAL_Gumbel(alpha, beta, gamma, lambda, x) - val).toString();
    }
  }

  const intensities = returnStruct.intensities;
  intensities.c25 = parseFloat(fzero(makeFn(0.25), tmean).solution);
  intensities.c50 = parseFloat(fzero(makeFn(0.50), tmean).solution);
  intensities.c75 = parseFloat(fzero(makeFn(0.75), tmean).solution);
  intensities.c90 = parseFloat(fzero(makeFn(0.90), tmean).solution);

  return returnStruct;
}

// varargin is optional
export function PAL_Gumbel(alpha, beta, gamma, lambda, x, varargin) {
  if (_.isUndefined(varargin)) {
    const f = (t) => {
      return math.eval(gamma + "+ ( 1 - " + gamma + " - " + lambda + ") * ( 1 - e^(-1 * 10^(" + beta + "* (" + t + "-" + alpha + "))))");
    };
    return isArray(x) ? x.map(f) : f(x);
  } else if (varargin === 'Inverse') {
    const f = (t) => {
      var c = math.eval( "(" + t + "-" + gamma + " ) / (1 - " + gamma + "-" + lambda + ") - 1");
      c = math.eval("-1 * log( -1 * " + c + ")");
      c = math.eval( "log10( " + c + ")");
      c = math.divide(c, 2);
      return math.add(alpha, c);
    };
    return isArray(x) ? x.map(f) : f(x);
  } else if (varargin === 'Derivative') {
    const f = (t) => {
      return math.eval("( 1 - " + gamma + " - " + lambda + ") * e^(-1 * 10^(" + beta + "* (" + x + "-" + alpha + "))) * log(10) * 10^( " + beta + "*(" + x + "-" + alpha + "))*" + beta);
    };
    return isArray(x) ? x.map(f) : f(x);
  } else {
    throw new Error("Invalid varargin: ", varargin);
  }
}

export default ProcessQuestData;
