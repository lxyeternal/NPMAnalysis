module.exports = require('./dist/synesthesia_quest.js');
