import Quest from "../src/Quest.js";
import {ProcessQuestData, PAL_Gumbel} from "../src/QuestAnalysis.js";
var assert = require('assert');

// Test parameters
const tActual = -2;
const tGuess = -1,
  tGuessSd = 2,
  pThreshold = 0.82,
  beta = 3.5,
  delta = 0.01,
  gamma = 0.5;

describe('QuestAnalysis', () => {
  describe('PAL_Gumbel', () => {
    it ('passes unit test', () => {
      const alpha = 1,
        beta = 2,
        gamma = 0,
        lambda = 0,
        x = 1;
      const result = PAL_Gumbel(alpha, beta, gamma, lambda, x);
      const expectedVal = 0.6321;
      assert(round(result, 4), expectedVal);
    });
  });
  describe('ProcessQuestData', () => {
    it('returns expected results after 10 trials', () => {
      // Hard codeded set of responses
      const responses = [1,1,1,0,1,1,0,0,1,1];
      const responses2 = [0,1,1,0,0,0,0,1,1,0];
      const q1 = new Quest(
        tGuess - 0.3,
        tGuessSd,
        pThreshold,
        beta,
        delta,
        gamma
      );
      const q2 = new Quest(
        tGuess + 0.3,
        tGuessSd,
        pThreshold,
        beta,
        delta,
        gamma
      );

      for (let i = 0; i < responses.length; i++) {
        const tTest = q1.quantile();
        q1.update(tTest, responses[i]);

        const tTest2 = q2.quantile();
        q2.update(tTest2, responses2[i]);
      }

      const intensities = ProcessQuestData(q1, q2).intensities;
      assert.equal(round(intensities.c25, 4), 0.3497);
      assert.equal(round(intensities.c50, 4), 0.4588);
      assert.equal(round(intensities.c75, 4), 0.5448);
      assert.equal(round(intensities.c90, 4), 0.6078);
    });
    it('returns expected results after 20 trials', () => {
      // Hard codeded set of responses
      const responses = [1,1,1,0,1,1,0,0,1,1,1,1,1,0,1,0,1,1,1,1];
      const responses2 = [0,1,1,0,0,0,0,1,1,0,1,1,1,0,1,0,1,0,0,0];
      const q1 = new Quest(
        tGuess - 0.3,
        tGuessSd,
        pThreshold,
        beta,
        delta,
        gamma
      );
      const q2 = new Quest(
        tGuess + 0.3,
        tGuessSd,
        pThreshold,
        beta,
        delta,
        gamma
      );

      for (let i = 0; i < responses.length; i++) {
        const tTest = q1.quantile();
        q1.update(tTest, responses[i]);

        const tTest2 = q2.quantile();
        q2.update(tTest2, responses2[i]);
      }

      const intensities = ProcessQuestData(q1, q2).intensities;
      assert.equal(round(intensities.c25, 4), 0.3214);
      assert.equal(round(intensities.c50, 4), 0.4305);
      assert.equal(round(intensities.c75, 4), 0.5165);
      assert.equal(round(intensities.c90, 4), 0.5795);
    });
  });
});

// Test helpers
function round(x, decimalPlaces) {
  const c = Math.pow(10, decimalPlaces);
  return Math.round(x * c) / c;
}
