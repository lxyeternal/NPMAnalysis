export declare class KakaoMapsModule {
}
