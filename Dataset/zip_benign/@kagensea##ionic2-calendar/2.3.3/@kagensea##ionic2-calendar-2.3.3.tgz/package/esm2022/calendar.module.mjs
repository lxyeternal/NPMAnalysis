import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { MonthViewComponent } from './monthview';
import { WeekViewComponent } from './weekview';
import { DayViewComponent } from './dayview';
import { CalendarComponent } from './calendar';
import { initPositionScrollComponent } from './init-position-scroll';
import * as i0 from "@angular/core";
class NgCalendarModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.1.1", ngImport: i0, type: NgCalendarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.1.1", ngImport: i0, type: NgCalendarModule, declarations: [MonthViewComponent, WeekViewComponent, DayViewComponent, CalendarComponent, initPositionScrollComponent], imports: [IonicModule, CommonModule], exports: [CalendarComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.1.1", ngImport: i0, type: NgCalendarModule, imports: [IonicModule, CommonModule] }); }
}
export { NgCalendarModule };
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.1.1", ngImport: i0, type: NgCalendarModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        MonthViewComponent, WeekViewComponent, DayViewComponent, CalendarComponent, initPositionScrollComponent
                    ],
                    imports: [IonicModule, CommonModule],
                    exports: [CalendarComponent]
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FsZW5kYXIubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL2NhbGVuZGFyLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3pDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMvQyxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDN0MsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sYUFBYSxDQUFDO0FBQ2pELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLFlBQVksQ0FBQztBQUMvQyxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFDN0MsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sWUFBWSxDQUFDO0FBQy9DLE9BQU8sRUFBRSwyQkFBMkIsRUFBRSxNQUFNLHdCQUF3QixDQUFDOztBQUVyRSxNQU9hLGdCQUFnQjs4R0FBaEIsZ0JBQWdCOytHQUFoQixnQkFBZ0IsaUJBTHJCLGtCQUFrQixFQUFFLGlCQUFpQixFQUFFLGdCQUFnQixFQUFFLGlCQUFpQixFQUFFLDJCQUEyQixhQUVqRyxXQUFXLEVBQUUsWUFBWSxhQUN6QixpQkFBaUI7K0dBRWxCLGdCQUFnQixZQUhmLFdBQVcsRUFBRSxZQUFZOztTQUcxQixnQkFBZ0I7MkZBQWhCLGdCQUFnQjtrQkFQNUIsUUFBUTttQkFBQztvQkFDTixZQUFZLEVBQUU7d0JBQ1Ysa0JBQWtCLEVBQUUsaUJBQWlCLEVBQUUsZ0JBQWdCLEVBQUUsaUJBQWlCLEVBQUUsMkJBQTJCO3FCQUMxRztvQkFDRCxPQUFPLEVBQUUsQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDO29CQUNwQyxPQUFPLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQztpQkFDL0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IElvbmljTW9kdWxlIH0gZnJvbSAnQGlvbmljL2FuZ3VsYXInO1xuaW1wb3J0IHsgTW9udGhWaWV3Q29tcG9uZW50IH0gZnJvbSAnLi9tb250aHZpZXcnO1xuaW1wb3J0IHsgV2Vla1ZpZXdDb21wb25lbnQgfSBmcm9tICcuL3dlZWt2aWV3JztcbmltcG9ydCB7IERheVZpZXdDb21wb25lbnQgfSBmcm9tICcuL2RheXZpZXcnO1xuaW1wb3J0IHsgQ2FsZW5kYXJDb21wb25lbnQgfSBmcm9tICcuL2NhbGVuZGFyJztcbmltcG9ydCB7IGluaXRQb3NpdGlvblNjcm9sbENvbXBvbmVudCB9IGZyb20gJy4vaW5pdC1wb3NpdGlvbi1zY3JvbGwnO1xuXG5ATmdNb2R1bGUoe1xuICAgIGRlY2xhcmF0aW9uczogW1xuICAgICAgICBNb250aFZpZXdDb21wb25lbnQsIFdlZWtWaWV3Q29tcG9uZW50LCBEYXlWaWV3Q29tcG9uZW50LCBDYWxlbmRhckNvbXBvbmVudCwgaW5pdFBvc2l0aW9uU2Nyb2xsQ29tcG9uZW50XG4gICAgXSxcbiAgICBpbXBvcnRzOiBbSW9uaWNNb2R1bGUsIENvbW1vbk1vZHVsZV0sXG4gICAgZXhwb3J0czogW0NhbGVuZGFyQ29tcG9uZW50XVxufSlcbmV4cG9ydCBjbGFzcyBOZ0NhbGVuZGFyTW9kdWxlIHt9XG4iXX0=