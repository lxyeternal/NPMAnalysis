import { Component, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import * as i0 from "@angular/core";
class initPositionScrollComponent {
    constructor(el, ngZone) {
        this.ngZone = ngZone;
        this.onScroll = new EventEmitter();
        this.listenerAttached = false;
        this.element = el;
    }
    ngOnChanges(changes) {
        let initPosition = changes['initPosition'];
        if (initPosition && initPosition.currentValue !== undefined && this.scrollContent && initPosition.currentValue != this.scrollContent.scrollTop) {
            const me = this;
            this.ngZone.run(() => {
                me.scrollContent.scrollTop = initPosition.currentValue;
            });
        }
    }
    ngAfterViewInit() {
        const scrollContent = this.scrollContent = this.element.nativeElement.querySelector('.scroll-content');
        if (this.initPosition !== undefined) {
            scrollContent.scrollTop = this.initPosition;
        }
        if (this.emitEvent && !this.listenerAttached) {
            let onScroll = this.onScroll;
            let me = this;
            this.handler = function () {
                if (me.initPosition != scrollContent.scrollTop) {
                    onScroll.emit(scrollContent.scrollTop);
                }
            };
            this.listenerAttached = true;
            scrollContent.addEventListener('scroll', this.handler);
        }
    }
    ngOnDestroy() {
        if (this.listenerAttached) {
            this.scrollContent.removeEventListener('scroll', this.handler);
            this.listenerAttached = false;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.1.1", ngImport: i0, type: initPositionScrollComponent, deps: [{ token: i0.ElementRef }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.1.1", type: initPositionScrollComponent, selector: "init-position-scroll", inputs: { initPosition: "initPosition", emitEvent: "emitEvent" }, outputs: { onScroll: "onScroll" }, usesOnChanges: true, ngImport: i0, template: `
        <div class="scroll-content" style="height:100%">
            <ng-content></ng-content>
        </div>
    `, isInline: true, styles: [".scroll-content{overflow-y:auto;overflow-x:hidden}\n"], encapsulation: i0.ViewEncapsulation.None }); }
}
export { initPositionScrollComponent };
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.1.1", ngImport: i0, type: initPositionScrollComponent, decorators: [{
            type: Component,
            args: [{ selector: 'init-position-scroll', template: `
        <div class="scroll-content" style="height:100%">
            <ng-content></ng-content>
        </div>
    `, encapsulation: ViewEncapsulation.None, styles: [".scroll-content{overflow-y:auto;overflow-x:hidden}\n"] }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: i0.NgZone }]; }, propDecorators: { initPosition: [{
                type: Input
            }], emitEvent: [{
                type: Input
            }], onScroll: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5pdC1wb3NpdGlvbi1zY3JvbGwuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvaW5pdC1wb3NpdGlvbi1zY3JvbGwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUNILFNBQVMsRUFDVCxLQUFLLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFNWixpQkFBaUIsRUFFcEIsTUFBTSxlQUFlLENBQUM7O0FBRXZCLE1BZWEsMkJBQTJCO0lBVXBDLFlBQVksRUFBYSxFQUFVLE1BQWM7UUFBZCxXQUFNLEdBQU4sTUFBTSxDQUFRO1FBUHZDLGFBQVEsR0FBRyxJQUFJLFlBQVksRUFBVSxDQUFDO1FBS3hDLHFCQUFnQixHQUFXLEtBQUssQ0FBQztRQUdyQyxJQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQXFCO1FBQzdCLElBQUksWUFBWSxHQUFHLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUMzQyxJQUFJLFlBQVksSUFBSSxZQUFZLENBQUMsWUFBWSxLQUFLLFNBQVMsSUFBSSxJQUFJLENBQUMsYUFBYSxJQUFJLFlBQVksQ0FBQyxZQUFZLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUU7WUFDNUksTUFBTSxFQUFFLEdBQUUsSUFBSSxDQUFDO1lBQ2YsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFO2dCQUNqQixFQUFFLENBQUMsYUFBYSxDQUFDLFNBQVMsR0FBRyxZQUFZLENBQUMsWUFBWSxDQUFDO1lBQzNELENBQUMsQ0FBQyxDQUFDO1NBQ047SUFDTCxDQUFDO0lBRUQsZUFBZTtRQUNYLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFDdkcsSUFBSSxJQUFJLENBQUMsWUFBWSxLQUFLLFNBQVMsRUFBRTtZQUNqQyxhQUFhLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7U0FDL0M7UUFFRCxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUU7WUFDMUMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztZQUM3QixJQUFJLEVBQUUsR0FBRyxJQUFJLENBQUM7WUFDZCxJQUFJLENBQUMsT0FBTyxHQUFHO2dCQUNYLElBQUcsRUFBRSxDQUFDLFlBQVksSUFBSSxhQUFhLENBQUMsU0FBUyxFQUFFO29CQUMzQyxRQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBQztpQkFDMUM7WUFDTCxDQUFDLENBQUM7WUFDRixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1lBQzdCLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQzFEO0lBQ0wsQ0FBQztJQUVELFdBQVc7UUFDUCxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUN2QixJQUFJLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDL0QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztTQUNqQztJQUNMLENBQUM7OEdBaERRLDJCQUEyQjtrR0FBM0IsMkJBQTJCLHNMQWIxQjs7OztLQUlUOztTQVNRLDJCQUEyQjsyRkFBM0IsMkJBQTJCO2tCQWZ2QyxTQUFTOytCQUNJLHNCQUFzQixZQUN0Qjs7OztLQUlULGlCQU9jLGlCQUFpQixDQUFDLElBQUk7c0hBRzVCLFlBQVk7c0JBQXBCLEtBQUs7Z0JBQ0csU0FBUztzQkFBakIsS0FBSztnQkFDSSxRQUFRO3NCQUFqQixNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgICBDb21wb25lbnQsXG4gICAgSW5wdXQsXG4gICAgT3V0cHV0LFxuICAgIEV2ZW50RW1pdHRlcixcbiAgICBFbGVtZW50UmVmLFxuICAgIFNpbXBsZUNoYW5nZXMsXG4gICAgT25DaGFuZ2VzLFxuICAgIEFmdGVyVmlld0luaXQsXG4gICAgT25EZXN0cm95LFxuICAgIFZpZXdFbmNhcHN1bGF0aW9uLFxuICAgIE5nWm9uZVxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6ICdpbml0LXBvc2l0aW9uLXNjcm9sbCcsXG4gICAgdGVtcGxhdGU6IGBcbiAgICAgICAgPGRpdiBjbGFzcz1cInNjcm9sbC1jb250ZW50XCIgc3R5bGU9XCJoZWlnaHQ6MTAwJVwiPlxuICAgICAgICAgICAgPG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50PlxuICAgICAgICA8L2Rpdj5cbiAgICBgLFxuICAgIHN0eWxlczogW2BcbiAgICAgICAgLnNjcm9sbC1jb250ZW50IHtcbiAgICAgICAgICAgIG92ZXJmbG93LXk6IGF1dG87XG4gICAgICAgICAgICBvdmVyZmxvdy14OiBoaWRkZW47XG4gICAgICAgIH0gICAgICAgIFxuICAgIGBdLFxuICAgIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmVcbn0pXG5leHBvcnQgY2xhc3MgaW5pdFBvc2l0aW9uU2Nyb2xsQ29tcG9uZW50IGltcGxlbWVudHMgT25DaGFuZ2VzLCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xuICAgIEBJbnB1dCgpIGluaXRQb3NpdGlvbiE6bnVtYmVyO1xuICAgIEBJbnB1dCgpIGVtaXRFdmVudD86Ym9vbGVhbjtcbiAgICBAT3V0cHV0KCkgb25TY3JvbGwgPSBuZXcgRXZlbnRFbWl0dGVyPG51bWJlcj4oKTtcblxuICAgIHByaXZhdGUgZWxlbWVudDpFbGVtZW50UmVmO1xuICAgIHByaXZhdGUgc2Nyb2xsQ29udGVudCE6SFRNTEVsZW1lbnQ7XG4gICAgcHJpdmF0ZSBoYW5kbGVyITooKT0+dm9pZDtcbiAgICBwcml2YXRlIGxpc3RlbmVyQXR0YWNoZWQ6Ym9vbGVhbiA9IGZhbHNlO1xuXG4gICAgY29uc3RydWN0b3IoZWw6RWxlbWVudFJlZiwgcHJpdmF0ZSBuZ1pvbmU6IE5nWm9uZSkge1xuICAgICAgICB0aGlzLmVsZW1lbnQgPSBlbDtcbiAgICB9XG5cbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOlNpbXBsZUNoYW5nZXMpIHtcbiAgICAgICAgbGV0IGluaXRQb3NpdGlvbiA9IGNoYW5nZXNbJ2luaXRQb3NpdGlvbiddO1xuICAgICAgICBpZiAoaW5pdFBvc2l0aW9uICYmIGluaXRQb3NpdGlvbi5jdXJyZW50VmFsdWUgIT09IHVuZGVmaW5lZCAmJiB0aGlzLnNjcm9sbENvbnRlbnQgJiYgaW5pdFBvc2l0aW9uLmN1cnJlbnRWYWx1ZSAhPSB0aGlzLnNjcm9sbENvbnRlbnQuc2Nyb2xsVG9wKSB7XG4gICAgICAgICAgICBjb25zdCBtZSA9dGhpcztcbiAgICAgICAgICAgIHRoaXMubmdab25lLnJ1bigoKSA9PiB7XG4gICAgICAgICAgICAgICAgbWUuc2Nyb2xsQ29udGVudC5zY3JvbGxUb3AgPSBpbml0UG9zaXRpb24uY3VycmVudFZhbHVlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgICAgIGNvbnN0IHNjcm9sbENvbnRlbnQgPSB0aGlzLnNjcm9sbENvbnRlbnQgPSB0aGlzLmVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcuc2Nyb2xsLWNvbnRlbnQnKTtcbiAgICAgICAgaWYgKHRoaXMuaW5pdFBvc2l0aW9uICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHNjcm9sbENvbnRlbnQuc2Nyb2xsVG9wID0gdGhpcy5pbml0UG9zaXRpb247XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodGhpcy5lbWl0RXZlbnQgJiYgIXRoaXMubGlzdGVuZXJBdHRhY2hlZCkge1xuICAgICAgICAgICAgbGV0IG9uU2Nyb2xsID0gdGhpcy5vblNjcm9sbDtcbiAgICAgICAgICAgIGxldCBtZSA9IHRoaXM7XG4gICAgICAgICAgICB0aGlzLmhhbmRsZXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgaWYobWUuaW5pdFBvc2l0aW9uICE9IHNjcm9sbENvbnRlbnQuc2Nyb2xsVG9wKSB7XG4gICAgICAgICAgICAgICAgICAgIG9uU2Nyb2xsLmVtaXQoc2Nyb2xsQ29udGVudC5zY3JvbGxUb3ApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB0aGlzLmxpc3RlbmVyQXR0YWNoZWQgPSB0cnVlO1xuICAgICAgICAgICAgc2Nyb2xsQ29udGVudC5hZGRFdmVudExpc3RlbmVyKCdzY3JvbGwnLCB0aGlzLmhhbmRsZXIpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIGlmICh0aGlzLmxpc3RlbmVyQXR0YWNoZWQpIHtcbiAgICAgICAgICAgIHRoaXMuc2Nyb2xsQ29udGVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdzY3JvbGwnLCB0aGlzLmhhbmRsZXIpO1xuICAgICAgICAgICAgdGhpcy5saXN0ZW5lckF0dGFjaGVkID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0=