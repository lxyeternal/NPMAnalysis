export const options = {
  baseScale: 1,
  thumbScale: 0.04,
  thumbBlur: 8,
  thumbQuality: 40,
  useBase64Webp: true,
};
