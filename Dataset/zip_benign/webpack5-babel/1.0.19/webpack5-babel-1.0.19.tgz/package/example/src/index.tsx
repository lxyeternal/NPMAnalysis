import React from "react";
import * as ReactDOM from "react-dom";
import { message, DatePicker, Carousel, Button } from "antd";
import 'antd/dist/antd.less';

function App() {
  function onBtnClick() {
    message.error("click", 3);
  }
  return (
    <div>
      <Button onClick={onBtnClick}>点击</Button>
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));
