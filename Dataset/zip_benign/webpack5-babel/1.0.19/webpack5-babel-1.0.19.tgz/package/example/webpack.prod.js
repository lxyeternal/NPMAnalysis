const { prodConfig, merge } = require("webpack5-babel");
module.exports = prodConfig;
