const { devConfig, merge } = require("webpack5-babel");
const path = require("path");

module.exports = merge(devConfig, {
  resolve: {
    extensions: [".less", ".css"],
    alias: {
      "@ossOptions": path.resolve(__dirname, "./ossOptions.js"),
    },
  },
});
