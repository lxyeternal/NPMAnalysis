<template>
  <div class="paint" id="paint" :style="canvasWarpStyle">
    <canvas
      id="canvas"
      :style="canvasStyle"
      :class="isOver ? 'zIndex1' : 'zIndex10'"
    ></canvas>
     <div v-show="isStart" class="prizeWarp" :class="isOver ? 'zIndex10' : 'zIndex1'">
      <slot  />
    </div>
  </div>
</template>
<script>
export default {
  props: {
    coverDomId: {
      type: String,
      default: 'warp'
    },
    coverImg: {
      // 覆盖图片
      type: String,
      default: ''
    },
    prizeImg: {
      // 奖品图片
      type: String,
      default: ''
    },
    coverRatio: {
      // 刮奖区域
      type: Number,
      default: 0.5
    },
    canvasStyle: {
      // canvas的css样式
    },
    canvasWarpStyle: {
      // canvas外层样式
    },
    touchArea: {
      type: Number,
      default: 15
    },
    again: {
      // 再来一次状态
      type: Boolean
    }
  },
  watch: {
    again (val) {
      if (val === true) {
        this.isOver = false
        this.onceMore()
      }
    }
  },
  data () {
    return {
      scroollDom: '',
      isOver: false,
      canvas: '',
      ctx: '',
      dpr: '',
      isStart: false // 一开始不显示奖品，当手指触发到刮刮乐时才显示奖品
    }
  },
  mounted () {
    this.painting()
  },
  methods: {
    onceMore () {
      this.canvas.width = this.canvas.width
      this.canvas.height = this.canvas.height
      this.ctx.scale(this.dpr, this.dpr)
      this.ctx.translate(-0.5, -0.5)
      var img = new Image()
      img.src = this.coverImg
      img.onload = () => {
        this.ctx.drawImage(
          img,
          0,
          0,
          this.canvas.offsetWidth,
          this.canvas.offsetHeight
        )
        this.ctx.globalCompositeOperation = 'destination-out'
      }
    },
    painting () {
      this.scroollDom = document.getElementById(this.coverDomId)
      this.canvas = document.getElementById('canvas')
      const paint = document.getElementById('paint')
      this.ctx = this.canvas.getContext('2d')
      let cssWidth = this.canvas.offsetWidth
      let cssHeight = this.canvas.offsetHeight
      let devRatio = window.devicePixelRatio || 1 // 获取设备像素比
      // this.ctx的像素比
      let backingStore =
          this.ctx.backingStorePixelRatio ||
          this.ctx.webkitBackingStorePixelRatio ||
          this.ctx.mozBackingStorePixelRatio ||
          this.ctx.msBackingStorePixelRatio ||
          this.ctx.oBackingStorePixelRatio ||
          this.ctx.backingStorePixelRatio ||
          1
      this.dpr = devRatio / backingStore
      this.canvas.width = cssWidth * this.dpr
      this.canvas.height = cssHeight * this.dpr
      this.ctx.scale(this.dpr, this.dpr)
      this.ctx.translate(-0.5, -0.5)
      var img = new Image()
      img.src = this.coverImg
      img.onload = () => {
        this.ctx.drawImage(img, 0, 0, cssWidth, cssHeight)
        this.ctx.globalCompositeOperation = 'destination-out'
      }
      let startX = 0
      let startY = 0
      let moveX = 0
      let moveY = 0
      let bodyScroll = function (e) {
        e.preventDefault()
      }
      let that = this
      paint.ontouchstart = e => {
        this.isStart = true
        e = e.targetTouches[0] || e
        startX = e.pageX
        startY = e.pageY
        console.log(startX, paint.offsetLeft, that.scroollDom.scrollLeft)
        this.ctx.moveTo(
          startX - paint.offsetLeft + that.scroollDom.scrollLeft,
          startY - paint.offsetTop + that.scroollDom.scrollTop
        )
        document
          .getElementById(this.coverDomId)
          .addEventListener('touchmove', bodyScroll, false)
      }
      paint.ontouchmove = e => {
        this.isStart = true
        e = e.targetTouches[0] || e
        moveX = e.pageX
        moveY = e.pageY
        this.ctx.beginPath()
        this.ctx.fillStyle = '#FFFFFF'
        this.ctx.arc(
          moveX - paint.offsetLeft - that.canvas.offsetLeft - that.scroollDom.scrollLeft,
          moveY + that.scroollDom.scrollTop - paint.offsetTop - that.canvas.offsetTop,
          that.touchArea,
          0,
          2 * Math.PI
        )
        this.ctx.fill()
        this.ctx.stroke()
      }
      this.scroollDom.ontouchend = () => {
        document
          .getElementById(this.coverDomId)
          .removeEventListener('touchmove', bodyScroll, false)
        let transPixels = []
        let pixels = this.ctx.getImageData(
          0,
          0,
          this.canvas.width,
          this.canvas.height
        )
        pixels.data.map((item, i) => {
          const pixel = pixels.data[i + 3]
          if (pixel === 0) {
            transPixels.push(pixel)
          }
        })
        let ratio = transPixels.length / pixels.data.length
        if (ratio > that.coverRatio) {
          that.isOver = true
          that.$emit('successFn')
        }
      }
    }
  }
}
</script>
<style scoped>
.paint {
  position: absolute;
}
#canvas {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  margin: auto;
  z-index: 3;
}
.prizeImg {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 2;
}
.zIndex1 {
  z-index: 1;
}
.zIndex10 {
  z-index: 10;
}
.prizeWarp{
  height: 100%;
  width: 100%;
  position: relative;
}
</style>
