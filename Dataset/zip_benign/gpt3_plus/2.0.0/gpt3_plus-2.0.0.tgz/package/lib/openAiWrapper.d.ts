export declare function createEmbeddings(content: string): Promise<any>;
export declare function createCompletation(content: string): Promise<string>;
export declare function init(openAIKey: string, maxTokensOnCompletation: number, completationModelName: string): Promise<void>;
