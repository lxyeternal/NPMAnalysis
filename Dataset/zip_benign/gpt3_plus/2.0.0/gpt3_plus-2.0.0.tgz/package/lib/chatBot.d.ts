type ModifyTalkContentCallback = (orignalContent: string, relatedContext: string[], relatedConversations: string[][]) => string;
export declare function talk(content: string, callbackOfModifyContent: ModifyTalkContentCallback): Promise<string>;
export {};
