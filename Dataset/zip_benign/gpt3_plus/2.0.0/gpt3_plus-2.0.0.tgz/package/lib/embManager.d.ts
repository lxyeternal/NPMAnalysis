export declare function getRelatedContext(content: string): Promise<string[]>;
export declare function getRelatedConversations(content: string): Promise<string[][]>;
export declare function storeTheNewConversation(question: string, answer: string): Promise<void>;
type ModelArgs = {
    maxTokens: number;
    outputMaxTokens: number;
};
type ContextEmbArgs = {
    contextSentenceSplitor: string;
    precentOfUsingContextInCompleation: number;
    useContextOnlySimilarityGreaterThanOrEqualTo: number;
};
type ConversationsEmbArgs = {
    precentOfUsingConversationsInCompletaion: number;
};
export declare function init(modelArgs: ModelArgs, contextEmbArgs: ContextEmbArgs, conversationsEmbArgs: ConversationsEmbArgs): Promise<void>;
export {};
