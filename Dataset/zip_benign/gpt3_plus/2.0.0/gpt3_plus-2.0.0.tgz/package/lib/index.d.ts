export type Template = (orginalContext: string, relatedContext: string[], relatedConversations: string[][]) => string;
export declare const Templates: {
    default: (originalContext: string, relatedContext: string[], relatedConversations: string[][]) => string;
};
export type setUpConfig = {
    completationModelName: string;
    apiKey: string;
    precentForContext: number;
    precentForConversations: number;
    promptOutputTokens: number;
    contextSentenceSplitor: string;
    completationMOdelMaxTokens: number;
    useEmbeddingsOnlyTheCorrelationGreaterThanOrEqualTo: number;
};
export declare class Gpt3Plus {
    init(config: setUpConfig): Promise<void>;
    talk(content: string, template: Template): Promise<string>;
}
