import { ethers } from 'ethers';
export declare function getNewProvider(chainId: number, customRPC: string | undefined | null): ethers.providers.JsonRpcProvider;
