import { EIP712Parameter } from './model/eip712.model';
export declare const EIP_2612_PERMIT_SELECTOR = "0xd505accf";
export declare const DAI_PERMIT_SELECTOR = "0x8fcbaf0c";
export declare const DOMAINS_WITHOUT_VERSION: string[];
/**
 * @signature EIP712Domain(string name,string version,address verifyingContract,bytes32 salt)
 * */
export declare const DOMAIN_WITH_SALT_ADN_WITHOUT_CHAIN_ID = "0x36c25de3e541d5d970f66e4210d728721220fff5c077cc6cd008b3a0c62adab7";
/**
 * @signature Permit(address holder,address spender,uint256 nonce,uint256 expiry,bool allowed)
 * */
export declare const DAI_LIKE_PERMIT_TYPEHASH = "0xea2aa0a1be11a07ed86d755c93467f4f82362b452371d1ba94d1715123511acb";
/**
 * @example `${tokenAddress}:${chainId}.toLowerCase()`
 * @warning Only toLowerCase string
 * */
export declare const TOKEN_ADDRESSES_WITH_SALT: string[];
export declare const eip2612PermitModelFields: EIP712Parameter[];
export declare const daiPermitModelFields: EIP712Parameter[];
export declare const ERC_20_NONCES_ABI: {
    constant: boolean;
    inputs: {
        name: string;
        type: string;
    }[];
    name: string;
    outputs: {
        name: string;
        type: string;
    }[];
    payable: boolean;
    stateMutability: string;
    type: string;
}[];
export declare const EIP_2612_PERMIT_ABI: {
    constant: boolean;
    inputs: {
        name: string;
        type: string;
    }[];
    name: string;
    outputs: never[];
    payable: boolean;
    stateMutability: string;
    type: string;
}[];
export declare const EIP_2612_PERMIT_INPUTS: {
    name: string;
    type: string;
}[];
export declare const DAI_EIP_2612_PERMIT_ABI: {
    constant: boolean;
    inputs: {
        internalType: string;
        name: string;
        type: string;
    }[];
    name: string;
    outputs: never[];
    payable: boolean;
    stateMutability: string;
    type: string;
}[];
export declare const DAI_EIP_2612_PERMIT_INPUTS: {
    internalType: string;
    name: string;
    type: string;
}[];
export declare const DOMAIN_TYPEHASH_ABI: {
    constant: boolean;
    inputs: never[];
    name: string;
    outputs: {
        internalType: string;
        name: string;
        type: string;
    }[];
    payable: boolean;
    stateMutability: string;
    type: string;
}[];
export declare const PERMIT_TYPEHASH_ABI: {
    constant: boolean;
    inputs: never[];
    name: string;
    outputs: {
        internalType: string;
        name: string;
        type: string;
    }[];
    payable: boolean;
    stateMutability: string;
    type: string;
}[];
export declare const DOMAIN_SEPARATOR_ABI: {
    inputs: never[];
    name: string;
    outputs: {
        internalType: string;
        name: string;
        type: string;
    }[];
    stateMutability: string;
    type: string;
}[];
export declare const VERSIONS_ABI: {
    constant: boolean;
    inputs: never[];
    name: string;
    outputs: {
        name: string;
        type: string;
    }[];
    payable: boolean;
    stateMutability: string;
    type: string;
}[];
