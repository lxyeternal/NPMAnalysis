import { ChainId } from './model/chain.model';
import { DaiPermitParams, PermitParams } from './model/permit.model';
interface Eip2612PermitUtilsOptions {
    enabledCheckSalt: boolean;
}
export declare class Eip2612PermitUtils {
    protected connector: any;
    protected options?: Eip2612PermitUtilsOptions | undefined;
    private readonly domainTypeHashStorage;
    constructor(connector: any, options?: Eip2612PermitUtilsOptions | undefined);
    buildPermitSignature(permitParams: PermitParams, chainId: ChainId, tokenName: string, tokenAddress: string, version?: string): Promise<string>;
    buildDaiLikePermitSignature(params: DaiPermitParams, chainId: ChainId, tokenName: string, tokenAddress: string, version?: string): Promise<string>;
    getTokenNonce(tokenAddress: string, walletAddress: string): Promise<number>;
    getTokenVersion(tokenAddress: string): Promise<string>;
    getDomainTypeHash(tokenAddress: string): Promise<string | null>;
    getPermitTypeHash(tokenAddress: string): Promise<string | null>;
    getDomainSeparator(tokenAddress: string): Promise<string>;
    isDomainWithoutVersion(tokenAddress: string): Promise<boolean>;
    isSaltInsteadOfChainId(tokenAddress: string, chainId: number): boolean;
    private getTokenNonceByMethod;
    private getTokenVersionByMethod;
}
export {};
