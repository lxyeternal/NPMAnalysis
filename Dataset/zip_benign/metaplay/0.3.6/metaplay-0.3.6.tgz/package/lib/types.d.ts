import { BigNumber } from 'ethers';
export type SignerData = {
    allowedAddress: string;
    validUntilTime: number;
};
export type RequestStatus = 'pending' | 'sending' | 'processed' | 'error' | 'rejected';
export type RequestStatusResponse = {
    id: number;
    status: RequestStatus;
    txHash?: string;
    errorReasonValidation?: string;
    errorReasonForwarder?: string;
    externalCallReturnData?: string;
};
export type RelayData = {
    name: string;
    version: string;
    address: string;
    minimumGas: number;
    feeCollectorAddress: string;
};
export type ForwardRequest = {
    from: string;
    to: string;
    feeToken: string;
    value: BigNumber;
    gas: BigNumber;
    nonce: BigNumber;
    validUntilTime: BigNumber;
    data: string;
};
export type SignerRequest = {
    user: string;
    signer: string;
    target: string;
    nonce: BigNumber;
    deadline: BigNumber;
    validUntilTime: BigNumber;
};
export type Permit = {
    owner: string;
    spender: string;
    value: BigNumber;
    nonce: BigNumber;
    deadline: BigNumber;
};
export type PermitContract = {
    spender: string;
    value: BigNumber;
    nonce: BigNumber;
    deadline: BigNumber;
    v: string;
    r: string;
    s: string;
};
export type ForwardRequestBody = {
    from: string;
    to: string;
    feeToken: string;
    value: string;
    gas: string;
    nonce: string;
    validUntilTime: string;
    data: string;
    signer: {
        signerData: SignerRequest | null;
        signature: string | null;
    };
    permits: PermitContract[];
};
