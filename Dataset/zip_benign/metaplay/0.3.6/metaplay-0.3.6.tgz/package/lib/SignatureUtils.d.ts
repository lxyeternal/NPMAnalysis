import { ForwardRequest, SignerRequest } from './types';
export declare function signReq(wallet: any, req: ForwardRequest, chainId: number, contractData: {
    name: string;
    version: string;
    address: string;
}): Promise<any>;
export declare function signPermitForwarder(wallet: any, req: SignerRequest, chainId: number, contractData: {
    name: string;
    version: string;
    address: string;
}): Promise<string>;
