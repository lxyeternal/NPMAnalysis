import { BigNumber, ethers } from 'ethers';
import { RelayData, ForwardRequest, SignerData, RequestStatusResponse, SignerRequest, Permit, PermitContract } from './types';
export declare class MetaPlayProvider {
    chainId: number;
    userAddress: string;
    relayData: RelayData | null;
    sessionSigner: ethers.Wallet;
    provider: ethers.providers.BaseProvider;
    relayContract: ethers.Contract | null;
    targetInterface: {
        [keys: string]: ethers.utils.Interface;
    };
    nonce: number | undefined;
    pendingReqeust: number | null;
    constructor({ userAddress, chainId, customRPC, privateKey, provider }?: {
        userAddress?: string | null;
        chainId?: number | null;
        customRPC?: string | null;
        privateKey?: string | null;
        provider?: ethers.providers.BaseProvider | null;
    });
    getChainId(): number;
    getTargets(): string[];
    getPrivateKeySessionWallet(): string;
    getAddressSessionWallet(): string;
    getSessionWallet(): ethers.Wallet;
    addNewTargetFromAbi(address: string, abi: ethers.ContractInterface): void;
    addNewTargetFromContract(contract: ethers.Contract): void;
    isFeeToken(address: string): Promise<boolean>;
    getFeeTokenController(feeTokenAddress: string): Promise<string>;
    isApprovedCachedResult: {
        [key: string]: boolean;
    };
    isApproved(targetAddress?: string): Promise<boolean>;
    isFeeTokenApproved(tokenAddress: string, minAmount?: ethers.BigNumber): Promise<boolean>;
    getFeeTokenAllowance(tokenAddress: string): Promise<ethers.BigNumber>;
    getSignerData(targetAddress?: string): Promise<SignerData>;
    approveSigner(wallet: ethers.Wallet, validUntilTime?: number, targetAddresses?: string[]): Promise<void>;
    approveSignerCalldata(validUntilTime?: number, targetAddresses?: string[]): Promise<ethers.PopulatedTransaction | null>;
    approveSignerPermit(signer: ethers.Signer, userAddress: string, targetAddresses: string, deadline?: number, validUntilTime?: number): Promise<{
        signerRequest: SignerRequest;
        signature: string;
    } | null>;
    getNonceSignerPermit(address: string): Promise<ethers.BigNumber>;
    approveFeeToken(wallet: ethers.Wallet, tokenAddress: string, amount?: ethers.BigNumber): Promise<void>;
    approveFeeTokenCalldate(tokenAddress: string, amount?: ethers.BigNumber): Promise<ethers.PopulatedTransaction>;
    approveFeeTokenPermit(signer: ethers.Signer, userAddress: string, tokenAddress: string, value: BigNumber, deadline?: number): Promise<{
        permit: Permit;
        signature: {
            r: string;
            s: string;
            v: number;
        };
    } | null>;
    approveTokenPermit(signer: ethers.Signer, userAddress: string, tokenAddress: string, spenderAddresses: string, value: BigNumber, deadline?: number, nonce?: number): Promise<{
        permit: Permit;
        signature: {
            r: string;
            s: string;
            v: number;
        };
    } | null>;
    getTokenNonce(tokenAddress: string, userAddress: string): Promise<ethers.BigNumber>;
    getTokenName(tokenAddress: string): Promise<string>;
    getNonce(): Promise<number | undefined>;
    getRelayData(): Promise<RelayData | null>;
    getExclusiveTarget(): string;
    getCalldata(functionName: string, parameters: any[], targetAddress: string): string;
    parseReturnData(targetAddress: string, retrunData: string): any;
    getNewRequest(functionName: string, parameters: any[], { targetAddress, msgValue, feeToken, nonce, validUntilTime, gasLimit, gasPrice }?: {
        targetAddress?: string;
        msgValue?: ethers.BigNumber;
        feeToken?: string;
        nonce?: number | undefined | null;
        validUntilTime?: number | undefined | null;
        gasLimit?: ethers.BigNumber | undefined | null;
        gasPrice?: ethers.BigNumber | undefined | null;
    }): Promise<MetaPlayRequest>;
    getNewRequestCalldata(calldata: string, { targetAddress, msgValue, feeToken, nonce, validUntilTime, gasLimit, gasPrice }?: {
        targetAddress?: string;
        msgValue?: ethers.BigNumber;
        feeToken?: string;
        nonce?: number | undefined | null;
        validUntilTime?: number | undefined | null;
        gasLimit?: ethers.BigNumber | undefined | null;
        gasPrice?: ethers.BigNumber | undefined | null;
    }): Promise<MetaPlayRequest>;
    getVerificationError(request: ForwardRequest, signature?: string): Promise<string | null>;
    verifyRequest(request: ForwardRequest, signature?: string): Promise<boolean>;
    getSignature(request: ForwardRequest): Promise<string>;
    getGasFeePaidInToken(txHash: string): Promise<ethers.BigNumber>;
    estimateGasFeeInToken(functionName: string, parameters: any[], msgValue?: BigNumber, feeToken?: string, targetAddress?: string): Promise<ethers.BigNumber>;
    estimateGasFeeInTokenCalldata(calldata: string, msgValue?: BigNumber, feeToken?: string, targetAddress?: string): Promise<ethers.BigNumber>;
    estimateGasFeeInTokenGasUsed(feeTokenAddress: string, estimateGasUsed: ethers.BigNumber, msgValue?: ethers.BigNumber): Promise<ethers.BigNumber>;
    estimateGasFeeInTokenRequest(request: ForwardRequest): Promise<ethers.BigNumber>;
    estimateGasUsed(functionName: string, parameters: any[], msgValue?: ethers.BigNumber, targetAddress?: string): Promise<ethers.BigNumber>;
    estimateGasUsedCalldata(calldata: string, msgValue?: ethers.BigNumber, targetAddress?: string): Promise<ethers.BigNumber>;
    sendRequestToForwarder(functionName: string, parameters: any[], { targetAddress, msgValue, feeToken, nonce, validUntilTime, gasLimit, gasPrice }?: {
        targetAddress?: string;
        msgValue?: ethers.BigNumber;
        feeToken?: string;
        nonce?: number | undefined | null;
        validUntilTime?: number | undefined | null;
        gasLimit?: ethers.BigNumber | undefined | null;
        gasPrice?: ethers.BigNumber | undefined | null;
    }): Promise<RequestStatusResponse>;
    sendRequestToForwarderCalldata(calldata: string, { targetAddress, msgValue, feeToken, nonce, validUntilTime, gasLimit, gasPrice }?: {
        targetAddress?: string;
        msgValue?: ethers.BigNumber;
        feeToken?: string;
        nonce?: number | undefined | null;
        validUntilTime?: number | undefined | null;
        gasLimit?: ethers.BigNumber | undefined | null;
        gasPrice?: ethers.BigNumber | undefined | null;
    }): Promise<RequestStatusResponse>;
    sendRequestToForwarderRequest(request: ForwardRequest, permits: PermitContract[], signerData: SignerRequest | null, signerSignature: string | null, gasPrice?: ethers.BigNumber | undefined | null): Promise<RequestStatusResponse>;
    getStatus(id: number): Promise<RequestStatusResponse | null>;
    sendRequestV1(route: string, body?: any): Promise<any>;
}
export declare class MetaPlayRequest {
    metaPlayProvider: MetaPlayProvider;
    request: ForwardRequest;
    errorMsg: string | undefined | null;
    gasPrice: ethers.BigNumber | undefined | null;
    id: number | undefined;
    txHash: string | undefined;
    signerReq: SignerRequest | null;
    signerSignature: string;
    permits: PermitContract[];
    constructor(_metaPlayProvider: MetaPlayProvider, _request: ForwardRequest, _gasPrice: ethers.BigNumber | undefined | null);
    setSignerRequest(_signerReq: SignerRequest, _signerSignature: string): Promise<void>;
    addPermit(permit: Permit, signatureParts: {
        r: string;
        s: string;
        v: number;
    }): Promise<void>;
    valid(): Promise<boolean>;
    error(): Promise<string | undefined>;
    send(): Promise<RequestStatusResponse>;
    status(): Promise<RequestStatusResponse>;
    wait(wantedStatus?: 'sending' | 'processed'): Promise<RequestStatusResponse>;
    fee(decimals?: number): Promise<number | ethers.BigNumber>;
    estimatedFee(decimals?: number, gasPrice?: ethers.BigNumber): Promise<number | ethers.BigNumber>;
    getFeeUsed(decimals?: number): Promise<number | ethers.BigNumber>;
}
