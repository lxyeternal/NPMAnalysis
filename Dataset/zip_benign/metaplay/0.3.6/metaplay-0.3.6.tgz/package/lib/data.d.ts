import { ethers } from 'ethers';
export declare const publicRPCList: {
    [keys: number]: string;
};
export declare const WrappedToken: {
    [keys: number]: string;
};
export declare const relayAddressHardcoded: {
    [keys: number]: string;
};
export declare const feeCollectorAddressHardcoded: {
    [keys: number]: {
        [keys: string]: string;
    };
};
export declare const gasFallback: {
    [keys: number]: ethers.BigNumber;
};
