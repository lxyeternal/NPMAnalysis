export type ColorPalette = string[];
