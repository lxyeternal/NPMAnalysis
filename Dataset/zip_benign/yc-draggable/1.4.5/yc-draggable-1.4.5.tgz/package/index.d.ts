import { IDraggable } from "./interface";
declare class Utils {
    BrowserInfo: {
        IE11OrLess: boolean;
        Edge: boolean;
        FireFox: boolean;
        Safari: boolean;
        IOS: boolean;
        ChromeForAndroid: boolean;
    };
    captureMode: {
        capture: boolean;
        passive: boolean;
    };
    constructor();
    $on<K extends keyof HTMLElementEventMap>(el: HTMLElement, event: K, fn: ((event: HTMLElementEventMap[K]) => void)): void;
    $off<K extends keyof HTMLElementEventMap>(el: HTMLElement, event: K, fn: ((event: HTMLElementEventMap[K]) => void)): void;
    isNotMouseLeft(event: MouseEvent): boolean;
    getChildrenIndex(el: HTMLElement, selector?: string): number;
    closest(el: HTMLElement, selector?: string, ctx?: HTMLElement, includeCTX?: boolean): HTMLElement | null;
    init(): void;
    userAgent(pattern: RegExp): boolean;
    css(el: HTMLElement, prop?: string, val?: any): any;
    getWindowScrollingElement(): HTMLElement;
    matrix(el: HTMLElement, selfOnly?: boolean): {
        a: number;
        b: number;
        c: number;
        d: number;
        e: number;
        f: number;
    };
    /**
     * Returns the "bounding client rect" of given element
     * @param  {HTMLElement} el                       The element whose boundingClientRect is wanted
     * @param  {[Boolean]} relativeToContainingBlock  Whether the rect should be relative to the containing block of (including) the container
     * @param  {[Boolean]} relativeToNonStaticParent  Whether the rect should be relative to the relative parent of (including) the contaienr
     * @param  {[Boolean]} undoScale                  Whether the container's scale() should be undone
     * @param  {[HTMLElement]} container              The parent the element will be placed in
     * @return {Object}                               The boundingClientRect of el, with specified adjustments
     */
    getRect(el: HTMLElement, relativeToContainingBlock?: Boolean, relativeToNonStaticParent?: Boolean, undoScale?: Boolean, container?: HTMLElement | null): {
        top: number;
        left: number;
        bottom: number;
        right: number;
        width: number;
        height: number;
    } | undefined;
    isCoordinateInArea(area: IDraggable.RectInfo, left: number, top: number): boolean;
    matches(el: HTMLElement, selector: string): any;
    toggleClass(el: HTMLElement, name?: string, state?: boolean): void;
    clone(el: HTMLElement): HTMLElement;
    getRelativeScrollOffset(el: HTMLElement): number[];
    isRectEqual(rect1: IDraggable.RectInfo, rect2: IDraggable.RectInfo): boolean;
    calculateRealTime(animatingRect: IDraggable.RectInfo, fromRect: IDraggable.RectInfo, toRect: IDraggable.RectInfo, options: IDraggable.Options): number;
}
export default class YcDraggable {
    utils: Utils;
    draggableInfos: Array<IDraggable.DraggableInfoItem>;
    isDown: boolean;
    dragEl: HTMLElement | null;
    cloneEl: HTMLElement | null;
    ghostEl: HTMLElement | null;
    ghostRelativeParent: HTMLElement | null;
    tapEvt: {
        target: HTMLElement;
        clientX: number;
        clientY: number;
    } | null;
    ghostRelativeParentInitialScroll: Array<number>;
    tapDistanceLeft: number;
    tapDistanceTop: number;
    lastDx: number;
    lastDy: number;
    curOptions: IDraggable.Options;
    childrenInfo: IDraggable.EnterChildrenInfo | null;
    childrenInfoAll: Array<IDraggable.EnterChildrenInfo>;
    animateStates: Array<IDraggable.AnimateState>;
    lastChild: null | HTMLElement;
    hoverEl: null | HTMLElement;
    hoverCloneEl: null | HTMLElement;
    hoverElOption: IDraggable.Options;
    baseMask: null | HTMLElement;
    oldIndex: number;
    newIndex: number;
    constructor();
    setMask(mask: HTMLElement): this;
    clearMask(): this;
    getProxyEl(proxyInfo: IDraggable.Options['proxy']): HTMLElement | null;
    getContainerRects(): {
        rect: {
            top: number;
            left: number;
            bottom: number;
            right: number;
            width: number;
            height: number;
        };
        rightRect: {
            top: number;
            left: number;
            bottom: number;
            right: number;
            width: number;
            height: number;
        };
        el: HTMLElement;
        options: IDraggable.Options;
    }[];
    enterContainersSort(list: ReturnType<typeof this.getNearestContainerList>): {
        rect: {
            top: number;
            left: number;
            bottom: number;
            right: number;
            width: number;
            height: number;
        };
        rightRect: {
            top: number;
            left: number;
            bottom: number;
            right: number;
            width: number;
            height: number;
        };
        el: HTMLElement;
        options: IDraggable.Options;
    }[];
    getNearestContainerList(x: number, y: number): {
        rect: {
            top: number;
            left: number;
            bottom: number;
            right: number;
            width: number;
            height: number;
        };
        rightRect: {
            top: number;
            left: number;
            bottom: number;
            right: number;
            width: number;
            height: number;
        };
        el: HTMLElement;
        options: IDraggable.Options;
    }[];
    getNearestContainer(x: number, y: number): {
        rect: {
            top: number;
            left: number;
            bottom: number;
            right: number;
            width: number;
            height: number;
        };
        rightRect: {
            top: number;
            left: number;
            bottom: number;
            right: number;
            width: number;
            height: number;
        };
        el: HTMLElement;
        options: IDraggable.Options;
    };
    init(container: HTMLElement, options?: IDraggable.Options): void;
    destroy(container: HTMLElement): void;
    _findDraggableInfoByEl(container: HTMLElement): IDraggable.DraggableInfoItem | null;
    _getWindowScrollingElement(): Element;
    getContainerRectGap(container: HTMLElement): {
        top: number;
        bottom: number;
        left: number;
        right: number;
    } | null;
    _getNearestChild(container: HTMLElement, x: number, y: number): IDraggable.EnterChildrenInfo | null;
    _getChildrenInfoAll(container: HTMLElement): {
        child: HTMLElement;
        rect: {
            top: number;
            left: number;
            bottom: number;
            right: number;
            width: number;
            height: number;
        };
        container: HTMLElement;
        options: IDraggable.Options;
    }[];
    _getEnterChildren: (x: number, y: number) => IDraggable.EnterChildrenInfo | null;
    _setClass(target: HTMLElement, classes: string | ((event: MouseEvent, el: HTMLElement) => string) | undefined, evt: MouseEvent, state?: boolean): "" | undefined;
    _dragStart(evt: MouseEvent): void;
    _dragStarted(fallback: boolean, evt: MouseEvent): false | undefined;
    _appendGhost(evt: MouseEvent): false | undefined;
    _onMouseMove: (evt: MouseEvent) => false | undefined;
    _getLastChild(el: HTMLElement, selector?: string): Element | null;
    _isOriginGroup(firstOptions: IDraggable.Options, secondOptions: IDraggable.Options): boolean;
    _canToEnter(firstOptions: IDraggable.Options, secondOptions: IDraggable.Options): boolean | undefined;
    _getAppendChild(options: IDraggable.Options): HTMLElement | null;
    _changePosition(evt: MouseEvent, force?: boolean, callBack?: Function): false | undefined;
    _onMouseUp: (evt: MouseEvent) => void;
    _offEvents(): void;
    _triggerDragStart(evt: MouseEvent): void;
    _tapStart(evt: MouseEvent): false | undefined;
    _addDraggableInfo(container: HTMLElement, options?: IDraggable.Options): void;
    hoverMoveHandler: (evt: MouseEvent) => void;
    hoverHandler(): void;
    _addEvents(container: HTMLElement): false | undefined;
    _nextTick(fn: Function): number;
    repaint(target: HTMLElement): number;
    _findElAnimateState(el: HTMLElement): IDraggable.AnimateState | null;
    _addElAnimateState(el: HTMLElement, animateState: IDraggable.AnimateState, filterKeys?: Array<keyof IDraggable.AnimateState>): void;
    _setElAnimateState(el: HTMLElement, animateState: Partial<IDraggable.AnimateState>, filterKeys?: Array<keyof IDraggable.AnimateState>): void;
    _initContainerChildrenAnimateStates(filterKeys?: Array<keyof IDraggable.AnimateState>): void;
    animateAll(container: HTMLElement): null | undefined;
    animate(target: HTMLElement, currentRect: IDraggable.RectInfo, toRect: IDraggable.RectInfo, duration: number): false | undefined;
}
export {};
