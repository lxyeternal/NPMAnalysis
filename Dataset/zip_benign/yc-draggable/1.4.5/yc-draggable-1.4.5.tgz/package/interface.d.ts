export declare namespace IDraggable {
    interface GroupOptions {
        name: string;
        put?: boolean;
        pull?: boolean | 'clone' | 'array' | (() => boolean | 'clone' | 'array');
    }
    interface Options {
        proxy?: HTMLElement | null | {
            $el?: HTMLElement;
            onClick?: (childrenInfo: EnterChildrenInfo) => HTMLElement | void;
            onContextmenu?: (childrenInfo: EnterChildrenInfo | null, evt: MouseEvent) => HTMLElement | void;
            showChildRect?: boolean;
        };
        name?: string;
        attrName?: string;
        penetration?: boolean;
        group?: GroupOptions | string;
        exchangeArea?: string | number | Array<string | number>;
        to?: string[];
        from?: string[];
        swap?: boolean;
        swapClass?: string;
        selectedClass?: string;
        easing?: string;
        clone?: (dom: HTMLElement) => HTMLElement;
        sort?: boolean;
        appendByDragDom?: boolean;
        multiDrag?: boolean;
        animation?: number;
        handle?: string;
        delay?: number;
        filter?: string | ((event: MouseEvent, el: HTMLElement) => boolean);
        hoverClass?: string | ((event: MouseEvent, el: HTMLElement) => string);
        ghostClass?: string | ((event: MouseEvent, el: HTMLElement) => string);
        draggable?: string;
        chosenClass?: string | ((event: MouseEvent, el: HTMLElement) => string);
        dragClass?: string | ((event: MouseEvent, el: HTMLElement) => string);
        appendClass?: string | ((event: MouseEvent, el: HTMLElement) => string);
        fallbackClass?: string | ((event: MouseEvent, el: HTMLElement) => string);
        opacity?: number;
        lockTime?: number;
        onSelect?: (params: CallBackParams) => void;
        onStart?: (params: CallBackParams) => void;
        onEnd?: (params: {
            item: HTMLElement;
            event: MouseEvent;
            newIndex: number;
            oldIndex: number;
        }) => void;
        onAddBefore?: (params: CallBackParams) => boolean;
        onAdd?: (params: any) => void;
        onRemove?: (params: CallBackParams) => void;
        onMove?: (params: OptionalRequired<CallBackParams, 'item' | 'event'>) => void;
        onExchangeBefore?: (params: CallBackParams) => boolean;
        onExchangeEnd?: (params: {
            type: 'before' | 'after' | 'append';
            item: HTMLElement;
            node: HTMLElement | null;
            event: MouseEvent;
        }) => void;
        onLeave?: (params: CallBackParams) => void;
        onEntry?: (params: CallBackParams) => void;
        onClone?: (info: {
            item: HTMLElement;
            clone: HTMLElement;
        }) => void;
        onClick?: (childrenInfo: EnterChildrenInfo) => HTMLElement | void;
        dragDom?: (dom: HTMLElement, params: {
            offset: {
                x: number;
                y: number;
            };
        }) => HTMLElement;
        mask?: OptionsMask;
        fallbackOnBody?: boolean;
        fallbackTolerance?: number;
        fallbackOffset?: {
            x: number;
            y: number;
        };
        onChangeBefore?: (params: CallBackParams & {
            type: 'before' | 'after' | 'append';
            container: HTMLElement;
        }) => boolean;
        onInsertBefore?: () => boolean;
    }
    interface DraggableInfoItem {
        options: Options;
        container: HTMLElement;
        start: () => void;
        click: (evt: MouseEvent) => void;
        mousedown: (evt: MouseEvent) => void;
        contextmenu: (evt: MouseEvent) => void;
        curRect: RectInfo;
    }
    interface RectInfo {
        top: number;
        left: number;
        bottom: number;
        right: number;
        width: number;
        height: number;
    }
    interface EnterChildrenInfo {
        child: HTMLElement;
        rect: RectInfo;
        container: HTMLElement;
        options: Options;
    }
    interface AnimateState {
        $el: HTMLElement;
        animatingX: boolean;
        animatingY: boolean;
        animated: number | boolean | ReturnType<typeof setTimeout>;
        rect: RectInfo;
        toRect: RectInfo | null;
        fromRect: RectInfo | null;
        thisAnimationDuration: null | number;
        prevFromRect: RectInfo | null;
        prevToRect: RectInfo | null;
        animationTime: number;
        animationResetTimer: number | ReturnType<typeof setTimeout>;
    }
    type MaskHandler = (maskInfo: MaskInfo, trigger: "click" | "hover") => void;
    interface OptionsMask {
        trigger?: "click" | "hover";
        onlyOne?: boolean;
        createElement?(dom: HTMLElement): HTMLElement | undefined;
        handler?: MaskHandler;
    }
    interface DragInfo {
        dom: HTMLElement;
        x: number;
        y: number;
    }
    interface SpaceInfo {
        index: number;
        top: number;
        left: number;
        width: number;
        height: number;
        originIndex: number;
        dom: HTMLElement;
        exchangeArea: {
            top: number;
            left: number;
            width: number;
            height: number;
        };
    }
    type Entry = (x: number, y: number) => void;
    type Leave = (x: number, y: number) => void;
    interface ExchangeOptions extends EventOptions {
        exchangeSpaceInfo: SpaceInfo;
        dragSpaceInfo: SpaceInfo;
        exchangeDom: HTMLElement;
        dragDom: HTMLElement;
    }
    interface DraggableInfoResult {
        container: HTMLElement;
        options: Options;
        addItem(item: HTMLElement, position: Offset, options: Options, event: MouseEvent): AddResult | undefined;
        addItemByIndex(dom: HTMLElement, index: number, filter?: (node: HTMLElement) => boolean): AddResult;
        appendItem(dom: HTMLElement, filter?: (node: HTMLElement) => boolean): AddResult;
        removeItem(item: HTMLElement): void;
        isEntry(x: number, y: number): boolean;
        isLeave(x: number, y: number): boolean;
        setOptions(config?: Options): void;
        getOptions(): Options;
        updateSpaceArray: (params?: {
            rect?: boolean;
            filter?: (node: HTMLElement) => boolean;
        }) => void;
        getSpaceArray: (rect?: boolean) => SpaceInfo[];
        getContainerOffset(): {
            top: number;
            left: number;
            width: number;
            height: number;
            maxTop: number;
            maxLeft: number;
        };
    }
    interface ContainerOffset {
        top: number;
        left: number;
        maxTop: number;
        maxLeft: number;
    }
    interface AddResult {
        dom: HTMLElement;
        container: HTMLElement;
        spaceInfo: SpaceInfo;
        options: Options;
    }
    interface addItemStart extends Offset {
        width: string;
        height: string;
    }
    interface Offset {
        top: number;
        left: number;
    }
    interface EventOptions {
        container: HTMLElement;
        currentDom: HTMLElement;
        options: Options;
        event: MouseEvent;
    }
    interface EventManage {
        eventMap: {
            dom: HTMLElement;
            list: {
                name: string;
                listener: EventListener[];
            }[];
        }[];
        register(dom: HTMLElement, eventName: string, event: EventListener): void;
        unBind(dom: HTMLElement, eventName: string): void;
        bind(dom: HTMLElement, eventName: string, event: EventListener, again?: boolean): void;
    }
    interface MaskInfo {
        container: HTMLElement;
        from: HTMLElement;
        mask: HTMLElement;
    }
    interface DataManage {
        data: DataInfo[];
        getContainerSort: (container: HTMLElement, attrName?: string) => string[];
        getContainerData: (container: HTMLElement) => unknown[];
        getItemByKey(key: string, attrName?: string): DataInfo | null;
        addData(dom: HTMLElement, container: HTMLElement): DataManage;
        removeData(dom: HTMLElement): DataManage;
        removeDataByContainer(container: HTMLElement): DataManage;
        dataTo(dom: HTMLElement, container: HTMLElement): DataManage;
    }
    interface DataInfo {
        container: HTMLElement;
        dom: HTMLElement;
        name: string;
        data?: any;
    }
    interface SizeInfo {
        top: number;
        left: number;
        width: number;
        height: number;
        clinetWidth: string;
        clientHeight: string;
        transform: string;
    }
    interface StyleInfo {
        dom: HTMLElement;
        style: {
            width: string;
            height: string;
            transform: {
                x: number;
                y: number;
                z: number;
                s: number;
                r: number;
            };
            attr: string;
        };
    }
    interface StyleManage {
        styles: StyleInfo[];
        getAttr: (dom: HTMLElement) => string;
        getStyle: (dom: HTMLElement) => {
            width: string;
            height: string;
            transform: {
                x: number;
                y: number;
                z: number;
            };
            attr: string;
        } | null;
        addStyle: (dom: HTMLElement) => StyleManage;
        strToObj: (styleStr: string) => Record<string, string>;
        conputedTransform3D(dom: HTMLElement, x: number, y: number, z: number): string;
    }
    interface AddAnimationParams {
        addResult: AddResult;
        sizeInfo: SizeInfo;
        options: Options;
        container: HTMLElement;
        lastSpaceInfos: SpaceInfo[];
    }
    interface RemoveAnimation {
        container: HTMLElement;
        maskManage: MaskInfo[];
        lastIndex: number;
        lastSpaceInfos: SpaceInfo[];
        options: Options;
    }
    interface BuildResult<T> {
        getMasks(): Array<MaskInfo>;
        getChildren(): HTMLElement[];
        getDraggableInfo(container?: HTMLElement): DraggableInfoResult | undefined;
        addItem(dom: HTMLElement, index: number): T;
        appendItem(dom: HTMLElement): T;
        removeItem(dom: HTMLElement): T;
        getData(): Array<unknown>;
        getSort(): Array<string>;
        getContainer(): HTMLElement | null;
        getOptions(): Options;
        getAllDraggableInfos(): DraggableInfoResult[];
        domToContainer(dom: HTMLElement, container: HTMLElement): T;
        setOptions(options: Options): T;
        setSort(sorts: string[]): T;
        setDomData(dom: HTMLElement, data: any): T;
        getDomData(dom: HTMLElement): string | null;
        setData(callback: (dom: HTMLElement) => any): T;
        getCurrentDom(): HTMLElement;
        getDataInfos: () => DataInfo[];
        getRandomStr: (len?: number) => string | null;
        replaceDom: (newDom: HTMLElement, dom: HTMLElement) => T;
        refresh(): T;
        removeDom(dom: HTMLElement): T;
        destroy(): null;
        getMask(dom: HTMLElement): HTMLElement | null;
        getCurrentDomMask(): HTMLElement | null;
        addClass(dom: HTMLElement, className: string): T;
        removeClass(dom: HTMLElement, className: string): T;
        refreshMask(dom?: HTMLElement): T;
    }
    type DraggableInfo = BuildResult<DraggableInfo>;
    type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;
    type OptionalRequired<T, K extends keyof T> = Required<Pick<T, K>> & Partial<Omit<T, K>>;
    interface CallBackParams {
        item: HTMLElement;
        node?: HTMLElement | null;
        event: MouseEvent;
        rect?: {
            bottom: number;
            height: number;
            left: number;
            right: number;
            top: number;
            width: number;
        } | null;
    }
    interface CreateResultParams {
        getDraggableInfos: () => DraggableInfoResult[];
        removeDraggableInfo: (container: HTMLElement) => DraggableInfoResult[];
        getAllMask: () => Array<MaskInfo>;
        container: HTMLElement;
        removeMask: RemoveMask;
        getDataManage: () => DataManage;
        createMousedownHandler({ dom }: {
            dom: HTMLElement;
        }): EventListener;
        eventManage: EventManage;
        getCurrentDom: () => HTMLElement;
        maskHandle: (dom: HTMLElement, entryDraggbleInfo: DraggableInfoResult, isRefresh?: boolean) => false | undefined;
    }
    interface RemoveMask {
        remove(list: MaskInfo[]): void;
        clearMask(container: HTMLElement): void;
        byContainer(container: HTMLElement): void;
        byFrom(from: HTMLElement): void;
    }
    interface XY {
        x: number;
        y: number;
    }
    interface CoordinateInfo {
        start: XY;
        end: XY;
        absolute: {
            start: XY;
            end: XY;
        };
    }
}
