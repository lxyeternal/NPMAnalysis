const path = require("path");
const fs = require("fs");

/**
 *
 * @name skp-dsl-parser
 * @description
 * json으로 정리된 SKP DSL 토큰명을 값으로 파싱해주는 도구입니다.
 *
 * @example
 * color: $globel-blue-100 -> color: #00f0ff
 */

module.exports = function (source) {
  const dstJson = path.resolve(__dirname, "tokens.json");
  const dstInfo = JSON.parse(fs.readFileSync(dstJson, "utf8"));

  const splittedCode = source.split("\n");
  const parsedDSTCode = splittedCode.map((line) => {
    if (line.includes(".json")) {
      return null;
    }
    if (line.includes("$")) {
      trimmedline = String(line).trim().replace(";", "");
      const tokenSeperator = "-";
      const dstStyleStartIndex = trimmedline.indexOf("$");
      const dstStyleText = trimmedline.substr(dstStyleStartIndex);
      const dstStyleToken = dstStyleText.replace("$", "").split(tokenSeperator);
      const dstStyle = dstStyleToken.reduce(
        (acc, dstStyle) => acc[dstStyle],
        dstInfo
      );
      const { value, type } = dstStyle;

      if (
        type === "color" ||
        type === "letterSpacing" ||
        type === "paragraphSpacing"
      ) {
        return line.replace(dstStyleText, value);
      }
      if (type === "boxShadow") {
        const { x, y, blur, spread, color } = value;
        const shorthandedShadow = `${pixelToRem({ pixel: x })}rem ${pixelToRem({
          pixel: y,
        })}rem ${pixelToRem({ pixel: blur })}rem ${pixelToRem({
          pixel: spread,
        })}rem ${color}`;
        return line.replace(dstStyleText, shorthandedShadow);
      }
      if (type === "typography") {
        const fontStyle = {};
        const fontStyleEntries = Object.entries(value);
        const trimmedFontStyleValues = fontStyleEntries.map((entry) => {
          const [key, value] = entry;
          const trimmedValue = getBracketTrimmedValue(value);
          const style = trimmedValue
            .split(".")
            .reduce((acc, fontStyleKey) => acc[fontStyleKey], dstInfo.global);
          return { ...style, type: key };
        });

        trimmedFontStyleValues.forEach(
          (trimmedValue) => (fontStyle[trimmedValue.type] = trimmedValue.value)
        );

        const combinedFontStyle = `
          font-family: ${fontStyle.fontFamily};
          font-weight: ${fontStyle.fontWeight};
          font-size: ${pixelToRem({
            pixel: fontStyle.fontSize,
          })}rem;
          line-height: ${pixelToRem({ pixel: fontStyle.lineHeight })}rem;
          text-decoration: ${fontStyle.textDecoration};
          letter-spacing: ${pixelToRem({ pixel: fontStyle.letterSpacing })}rem;
        `;

        return combinedFontStyle;
      }
    }
    return line;
  });

  return parsedDSTCode.join("\n").trim();
};

const pixelToRem = ({ pixel, basePixel = 10 }) => {
  return Number(pixel / basePixel);
};

const getBracketTrimmedValue = (key) => {
  let trimmedKey = key;
  if (trimmedKey.includes("{")) {
    trimmedKey = trimmedKey.replace("{", "");
  }
  if (trimmedKey.includes("}")) {
    trimmedKey = trimmedKey.replace("}", "");
  }
  return trimmedKey;
};

const getValueByPropertyType = (target, key) => {
  Object.keys(target).find(key);
};
