import { Tree } from './createTree';
export interface TreeSimilarityOptions {
    alpha?: number;
    beta?: number;
    gamma?: number;
}
/**
 * Similarity between two nodes
 * @return similarity measure between tree nodes
 */
export declare function treeSimilarity(treeA: Tree | null, treeB: Tree | null, options?: TreeSimilarityOptions): number;
//# sourceMappingURL=treeSimilarity.d.ts.map