import { Tree } from './createTree';
/**
 * Destructive compression in which we reduce the number of decimals
 */
export declare function compressTree(tree: Tree, options?: {
    fixed?: number;
}): Tree;
//# sourceMappingURL=compressTree.d.ts.map