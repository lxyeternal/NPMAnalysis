export * from './treeSimilarity';
export * from './createTree';
export { compressTree } from './compressTree';
//# sourceMappingURL=index.js.map