
## Installation

```bash
npm i ls-compressimage --save
```
## Use
```javascript
import compressImage from 'ls-compressimage'
new compressImage({
        res: data.imgTime, // 必选 资源
        justConversion: true, // 可选 声明了此字段说明只进行格式转换 res requestType responseType callback必填，其他随意
        width: 500, // 可选(justConversion存在可不选) (默认图片自身宽度,建议自定义) 压缩后图片宽度
        // height: image.height,//可选 (默认 自定义图片宽度/原生图片宽度*原生图片高度) 压缩后图片高度
        quality: 0.2, // 可选 (默认0.3) 压缩层级质量（0<quality<1）越大压缩越快 图片质量跨度相对低 越小则相反
        size: 200, // 必选(justConversion存在可不选) 压缩后图片大小 单位k
        requestType: 'base64', // 必选 传入文件类别 base64 | file | blob
        responseType: 'base64', // 必选 返回文件类别 base64 | file | blob
        imgType: 'image/jpeg', // 可选 (默认原生文件类型) 返回文件对象的文件类型
        fileName: 'ysl', // 如果responseType的类型为file和非justConversion 此选项可选 返回文件对象的文件名
        callback: (result) => {
          if (result === null) {
            alert('图片处理异常')
            return
          }
          this.params.mainImagePath = result
        } // 回调函数 返回处理后文件 如果为null 表示文件处理不了(原因 少了参数 参数不合法))
      })
```
###Tip
参数requestType 必须对应 参数res的形态，否则处理可能异常
size结果为 <= size 
如quality过小，则至多压缩25次，建议0.1~0.3 当然这个自己把握
width建议设置 手机拍照宽度都好几千 按比例压缩效果反而没自定义width好
####---end

