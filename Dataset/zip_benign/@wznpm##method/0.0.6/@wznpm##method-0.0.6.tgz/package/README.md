## 千分符（数字分割）

    qianFenFu(x)
    x： string || number   必填
    例：qianFenFu(1355223.3424)   // 1,355,223.3424

## 千分符国际版（数字分割）

    注意： 此函数保留小数点后三位，多余的小数四升五入
    qianFenFuAll(x,locales, options)
    x：         string || number  必填
    locales：   string 选填
    options：   {}  选填
    例：new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY' }).format(number)     // ￥123,457
    (详情可看：http://web.h3399.cn/NumberFormat.htm)

## 时间戳、日期互相转换

    shiJianZhuan(x)   //  默认格式  2000-01-01 00:00:00
    x：         {}  选填   // 不填写时返回当前现在时间
    {
        setTime: 时间戳   // 传入后解析setTime时间
        ymd:     Boolean    // 传入后只展示日期 2000-01-01
        ms:      Boolean    // 传入后添加毫秒 2000-01-01 00:00:00:000
        fuhao1:  string  // 日期分割符 自定义（不可为空字符串）
        fuhao2:  string  // 时间分割符 自定义（不可为空字符串）
        type: string    //值为 year｜mont｜nowDay｜hour｜mins｜ seco 会返回相应的 时间数字
    }

## js 加减乘除精确计算（解决 0.1+0.2 = 0.3）

    jingzhun(fun, arg)
    fun: string   ('+' 、'-'、'*'、'/') 计算方式   必填
    arg:  number || Array [number] 可以分开传也可以放到数组中传（确保计算的值为number类型）  必填

## 数字金额转为大写

    huoBiZhuan(x)
    x: string || number   需转换数字   必填
    例: huoBiZhuan(34524.43)   // 叁万肆仟伍佰贰拾肆元肆角叁分

## 数组去重

    quchong(x,key)
    x: Array   去重数组   必填
    key: string   重复属性  选填   填是数组对象去重，不填是基本数据类型去重
    例: quchong([{name: '12'},{name:12},{name:23},{name: 12}],'name')   // [{"name": "12"},{"name": 12},{"name": 23}]

## 深拷贝

    shenKaoBei(x,all)
    x： 被拷贝的数据   必填
    all： Boolean   选填
    不传all是Josn深拷贝，传all是递归深拷贝

## 数据判断

    istype(x,t)
    x:  判断数据                   必填
    t:  String   对比的数据类型     选填 可填写（'Object'==='O','Array'=='A'等）按首字母大写匹配也可以， Number和Null需要全拼
    不传t返回数据类型，传t返回比较结果

## 防抖

    debounce(fn, delay)
    fn:   function  执行函数        必填
    delay:  number  防抖时间        选填
    实例：
    const a = debounce(function () {})   // 这里一定要使用匿名函数，尖头函数无法改变this
    a(this)   //调用函数时记得传入this

## 截流

    throttle(fn, delay)
    fn:  function  执行函数        必填
    delay:  number  防抖时间       选填
    实例：同上

## 数组分组

    arrayGroup(arr, key) (此方法已经废弃，0.0.5版本的使用方式)
    arr:  array   被分组的原始数组        必填
    key:  string  数组的值为对象时，被分组的表示       选填
    实例:
    arrayGroup([{name: 'test1',},{  name: 'test1',},{  name: 'test',},{  name: 'test2',},{  name: 'test2',},{  name: 'test',},{  name: 'test',}],'name')
      [
        {
          name: 'test1',
        },
        {
          name: 'test1',
        },
      ],
      [
        {
          name: 'test',
        },
        {
          name: 'test',
        },
        {
          name: 'test',
        },
      ],
      [
        {
          name: 'test2',
        },
        {
          name: 'test2',
        },
      ]
    arrayGroup(fun) (0.0.5版本以后的使用方式)
    方法1. Array.prototype.arrayGroup = arrayGroup 绑定带数组原型链上
    方法2. arr 传参

    fun:  function   函数           必填  返回值为分组的key
    arr:  array   被分组的原始数组    默认为 undefined    选填
    type: string  '0'或'1' 返回数据的类型  0 为对象  1为数组   默认为 0     选填

    实例:
    [{name: 'test1',},{  name: 'test1',},{  name: 'test',},{  name: 'test2',},{  name: 'test2',},{  name: 'test',},{  name: 'test',}].arrayGroup((next,item) => item.name)

     [
        {
          name: 'test1',
        },
        {
          name: 'test1',
        },
      ],
      [
        {
          name: 'test',
        },
        {
          name: 'test',
        },
        {
          name: 'test',
        },
      ],
      [
        {
          name: 'test2',
        },
        {
          name: 'test2',
        },
      ]

## 数组和树结构转换

    changeTorA(type, parentId = 'parentId', id = 'id', data = [])
    type: string| array  直接传数组就是默认 树结构偏平化(type为需要转化的数组,  data不用传) 传字符串扁平数组转树结构    必填
    parentId: string   为子数组添加和父级数组的关联标识                                                          选填
    id: string     子数组添加父级数组的关联标识时，父级数组的key                                                   选填
    data: array   扁平数组转树结构时，需要转化的数组                                                              选填
    实例：树结构偏平化
    const arr = [
      {
        ids: 2,
        name: '父亲2',
        children: [
          {
            ids: 21,
            name: '儿子1',
            children: [],
          },
          {
            ids: 22,
            name: '儿子2',
            children: [],
          },
        ],
      },
    ]
    changeTorA(arr, 'parentId', 'ids')   // 根据父级key为 第三行参（ids） 的值，给子级添加对应key为 第二行参（parentId） 的值
    [
      {
        ids: 2,
        name: '父亲2'
      },
      {
        ids: 21,
        name: '儿子1',
        parentId: 2
      },
      {
        ids: 22,
        name: '儿子2',
        parentId: 2
      }
    ]
    实例：数组转树结构
    const arr =
    [
      {
        ids: 2,
        name: '父亲2'
      },
      {
        ids: 21,
        name: '儿子1',
        parentId: 2
      },
      {
        ids: 22,
        name: '儿子2',
        parentId: 2
      }
    ]
    changeTorA('array', 'parentId', 'ids', arr) // 数组之间key为 第二行参（parentId） 与key为 第三行参（ids） 值的对比
    [
      {
        ids: 2,
        name: '父亲2',
        children: [
          {
              ids: 21,
              name: '儿子1',
              parentId: 2,
              children: []
          },
          {
              ids: 22,
              name: '儿子2',
              parentId: 2,
              children: []
          },
        ],
      }
    ]

## Project setup

```
npm install @wznpm/method
```

## 引入方式

// 按需引入

import {shenKaoBei} from '@wz/method' // 示例
