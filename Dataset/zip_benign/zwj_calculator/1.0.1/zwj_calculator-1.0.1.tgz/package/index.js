const myMathTools = require('./mathTools');



function simple_cal(input){
    const {data} = input;
    let {formula} = input;
    formula = formula.split(/[\t\r\f\n\s]/g).join('');
    formula = myMathTools.verifyStr(formula, data);
    if(!formula){
        console.log('无效的字符串');
        return;
    }
    let res = myMathTools.parseFormula(formula);
    return res;
}

module.exports = {
    simple_cal
}