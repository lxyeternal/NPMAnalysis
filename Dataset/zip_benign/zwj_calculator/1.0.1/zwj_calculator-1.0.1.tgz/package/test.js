const {simple_cal} = require('./index');

const test_1 = {
    formula: '(x+y)*z',
    data: {
        x: 0.1,
        y: 0.2,
        z: 1
    }
};
const test_2 = {
    formula: 'x-y/x+1',
    data: {
        x: 0.1,
        y: 0.2,
    }
};;
const test_3 = {
    formula: '(x+y)*(z-1)+y/z',
    data: {
        x: 0.1,
        y: 0.2,
        z: 2
    }
};;

const list = [test_1, test_2, test_3];
let res;
for(let i=0;i<list.length;i++){
    res = simple_cal(list[i]);
    if(!res){
        console.log('测试案例'+i+1+': \''+JSON.stringify(list[i])+'\'计算失败');
    }else{
        console.log('测试案例'+i+1+': \''+JSON.stringify(list[i])+'\'结果为: '+res);
    }
}