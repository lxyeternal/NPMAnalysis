# zwj_calculator 简介

zwj_calculator。是一款由周文杰开发的简单四则运算器，支持带括号和变量的公式计算。

## 安装

``` 
npm install zwj_calculator
```
## 使用
**测试代码**
```
const cal = require('zwj_calculator');
const input = {
    formula: '(x+y)*z',
    data: {
        x: 0.1,
        y: 0.2,
        z: 1
    }
};
console.log(cal.simple_cal(input));
```
**控制台打印的测试结果**
```
0.3
```
## 详细代码
代码详细内容被我公布在了 Bitbucket 仓库: [exam_project6](https://code.fineres.com/users/warren.zhou/repos/exam_project6)。
在根目录下使用下列指令进行代码测试：
```
npm run test
```
目前使用`3个测试用例`，测试通过率为`100%`。