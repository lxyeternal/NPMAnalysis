const calPriority = new Map([
    ['+', 1], ['-', 1], ['*', 2], ['/', 2], ['(', 0]
]);
const calSigs = ['+', '-', '*', '/'];

//验证字符串是否合法
function verifyStr(str, data){
    const params = str.split(/[\+\-*/()]/);
    //字符是否合法
    for(let val in params){
        if(isNaN(params[val]) && params[val] in data === false) return null;
    }
    //是否存在连续符号
    for(let i = 0;i<str.length-1;i++){
        if(calSigs.includes(str[i]) && calSigs.includes(str[i+1])) return null;
    }
    //语法是否合法
    try {
        for(key in data){
            str = str.replace(new RegExp(key, 'gm'), data[key].toString());
        }
        new Function(`return ${str};`)();
        return str;
    } catch (e) {
        return null;
    }
}

//解析公式的各个数字和符号
//利用运算符优先级，使用数字栈和符号栈进行计算
function parseFormula(formula){
    let numStack=[], sigStack=[], temp='';
    for(let i=0;i<formula.length;i++){
        let c = formula[i];
        if(c == '+' || c == '-' || c == '*' || c == '/'){
            if(temp!='') numStack.push(temp);
            temp='';
            //加入运算符前，先计算栈中可以计算的数字
            calByStack(numStack, sigStack, c);
        }else if(c == '('){
            sigStack.push(c);
        }
        else if(c == ')'){
            if(temp!='') numStack.push(temp);
            temp='';
            //计算'('符号前的所有数字
            calByStack(numStack, sigStack, c);
        }
        else if(!isNaN(c) || c == '.'){
            temp += c;
        }
    }
    //计算剩余数字
    if(temp!='') numStack.push(temp);
    while(sigStack.length>0){
        let sig = sigStack.pop();
        let b = numStack.pop(), a = numStack.pop();
        numStack.push(calNum(sig, a, b));
    }
    return numStack.pop();
}

//取出符号和数值进行计算
function calByStack(numStack, sigStack, sig){
    if(sig == ')'){
        while( sigStack[sigStack.length-1] != '('){
            let sig = sigStack.pop();
            let b = numStack.pop(), a = numStack.pop();
            const res = calNum(sig, a, b);
            numStack.push(res);
        }
        //移出')'
        sigStack.pop();
    }else{
        const priority = calPriority.get(sig);
        while( sigStack.length>0 && calPriority.get(sigStack[sigStack.length-1]) >= priority){
            let sig = sigStack.pop();
            let b = numStack.pop(), a = numStack.pop();
            const res = calNum(sig, a, b);
            numStack.push(res);
        }
        //运算符入栈
        sigStack.push(sig);
    }
}


//获取实际放大值，使用Number.EPSILON判断是否实际为整数
function compare(power, num){
    const result = num*power;
    const similar = Math.round(result);
    return result - similar < Number.EPSILON ? similar:result;
}

//两数计算
function calNum(sig, a, b){
    //获取放大倍数
    const aLen = a.split('.')[1]?.length || 0;
    const bLen = b.split('.')[1]?.length || 0;
    const power = Math.pow(10, Math.max(aLen, bLen));

    a = compare(power, a);
    b = compare(power, b);
    let res;
    switch(sig){
        case '+':
            res = (a+b)/power;
            break;
        case '-':
            res = (a-b)/power;
            break;
        case '*':
            res = (a*b)/(power*power);
            break;
        case '/':
            res = a/b;
            break;
        default:
            throw new Error(a+sig+b+'计算出现异常!');
    }
    return res.toString();
}

module.exports = {
    verifyStr,
    parseFormula,
    calNum
}