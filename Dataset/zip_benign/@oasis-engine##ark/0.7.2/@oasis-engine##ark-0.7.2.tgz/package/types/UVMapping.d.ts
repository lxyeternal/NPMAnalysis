import { Component, Entity, Texture2D } from "oasis-engine";
export declare class UVMapping extends Component {
    private readonly _originalMtl;
    private readonly _coverMtl;
    private _colorTexture;
    private _uvCamera;
    private _parent;
    set coverTexture(texture: Texture2D);
    set originalTexture(texture: Texture2D);
    get colorTexture(): Texture2D;
    constructor(entity: Entity);
    private _createCoverMaterial;
    private _createOriginalMaterial;
}
