import { Animator, Color, Component, Entity } from "oasis-engine";
declare class ArkComponent extends Component {
    group: string;
    subGroup: string;
    asset: string;
    private _setModelPromise;
    private _modelUrl;
    private _actionUrl;
    private _animationUrl;
    private _hairUrl;
    private _eyeUrl;
    private _eyebrowUrl;
    private _beardUrl;
    private _clothUrl;
    private _blendShapes;
    private _modelEntity;
    private _hairEntity;
    private _eyeEntity;
    private _eyebrowEntity;
    private _faceMaterial;
    private _bodyMaterial;
    private _clothEntity;
    private _uvMapping;
    private _originalFaceTexture;
    private _animator;
    private _animationClips;
    private _bsRenderers;
    /**
     * ------------- begin: editor config -------------
     */
    get eyeUrl(): string;
    set eyeUrl(url: string);
    get eyebrowUrl(): string;
    set eyebrowUrl(url: string);
    get hairUrl(): string;
    set hairUrl(url: string);
    get beardUrl(): string;
    set beardUrl(url: string);
    get clothUrl(): string;
    set clothUrl(url: string);
    get modelUrl(): string;
    set modelUrl(url: string);
    get actionUrl(): string;
    set actionUrl(url: string);
    get animationUrl(): string;
    set animationUrl(url: string);
    get blendShapes(): string;
    set blendShapes(str: string);
    /**
     * ------------- end: editor config -------------
     */
    /**
     * The controller of the animation system.
     */
    get animator(): Animator;
    /**
     * All animation name list in current 3D model.
     */
    get animationNameList(): string[];
    /**
     * All blendShape name list in current 3D model.
     */
    get blendShapeNameList(): string[];
    /**
     * All blendShape name/value list in current 3D model.
     */
    get blendShapeNameValueList(): string;
    /**
     * A hook to call back when loading is complete
     */
    get onReady(): Promise<void>;
    constructor(entity: Entity);
    /**
     * Reset all blend shape
     */
    resetBlendShape(): void;
    /**
     * Edit blendShape by name.
     * @param blendShapeName - the name of the blendShape.
     * @param value - The value of blendShape want to set.
     */
    editBlendShape(blendShapeName: string, value: number): void;
    /**
     * Get blendShape value by name.
     * @param blendShapeName - the name of the blendShape.
     * @returns The blendShape value.
     */
    getBlendShapeValue(blendShapeName: string): number;
    /**
     * Replace face and body color.
     * @param baseColor - base Color.
     */
    replaceSkinColor(baseColor: Color): void;
    /**
     * Replace 3D Model by glTF url.
     * @param url - The url of 3D glTF file.
     */
    replaceModel(url: string): Promise<void>;
    /**
     * Replace 3D beard by texture url.
     * @param url - The url of texture file.
     */
    replaceBeard(url: string): Promise<void>;
    /**
     * Replace hair by glTF url.
     * @param url - The url of glTF file.
     */
    replaceHair(url: string): Promise<void>;
    /**
     * Replace eye by glTF url.
     * @param url - The url of glTF file.
     */
    replaceEye(url: string): Promise<void>;
    /**
     * Replace eyebrow by glTF url.
     * @param url - The url of glTF file.
     */
    replaceEyebrow(url: string): Promise<void>;
    /**
     * Replace cloth by glTF url.
     * @param url - The url of glTF file.
     */
    replaceCloth(url: string): Promise<void>;
    /**
     * Replace action by glTF url which includes action information.
     * @param url - The url of action glTF file.
     */
    replaceAction(url: string): Promise<void>;
    /**
     * Replace animation by glTF url which includes animation information.
     * @param url - The url of animation glTF file.
     */
    replaceAnimation(url: string): Promise<void>;
    /**
     * Get time duration of animation clip by name.
     * @param clipName The name of the animation clip.
     * @returns The time duration in seconds.
     */
    getAnimationDuration(clipName: string): number;
    /**
     * @override
     */
    _onDestroy(): void;
    private _replaceModel;
    private _addComponent;
    private _destroyLastGLTF;
}
export { ArkComponent };
