/**
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * @format
 * @flow strict-local
 */
import type { ViewProps } from 'react-native';
import * as React from 'react';
export type Props = ViewProps;
/**
 * The most fundamental component for building a UI, View is a container that
 * supports layout with flexbox, style, some touch handling, and accessibility
 * controls.
 *
 * @see https://reactnative.dev/docs/view
 */
declare const ShadowView: React.ForwardRefExoticComponent<ViewProps & React.RefAttributes<any>>;
export default ShadowView;
