/// <reference types="react-native/types/modules/Codegen" />
import type { ViewProps, HostComponent } from 'react-native';
import * as React from 'react';
import type { Int32 } from 'react-native/Libraries/Types/CodegenTypes';
export interface NativeProps extends ViewProps {
}
interface NativeCommands {
    hotspotUpdate: (viewRef: React.ElementRef<HostComponent<any>>, x: Int32, y: Int32) => void;
    setPressed: (viewRef: React.ElementRef<HostComponent<any>>, pressed: boolean) => void;
}
export declare const Commands: NativeCommands;
declare const _default: HostComponent<NativeProps>;
export default _default;
