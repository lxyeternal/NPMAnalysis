import dashBoard from "./core/dashBoard";
declare const _default: {
    dashBoard: typeof dashBoard;
};
export default _default;
