export interface Pt {
    x: number;
    y: number;
}
declare function dot(A: Pt, B: Pt): number;
declare function $cross(A: Pt, B: Pt): number;
declare function _cross(A: Pt, B: Pt): number;
declare function _(A: Pt): number;
declare function polarToVector(magnitude: number, direction: number): Pt;
declare function movePtToCoordinate(centerPt: Pt, movePt: Pt): Pt;
declare function isScannable(center: Pt, movePt: Pt, alpha: number): boolean;
declare const _default: {
    dot: typeof dot;
    $cross: typeof $cross;
    _cross: typeof _cross;
    _: typeof _;
    polarToVector: typeof polarToVector;
    movePtToCoordinate: typeof movePtToCoordinate;
    isScannable: typeof isScannable;
};
export default _default;
