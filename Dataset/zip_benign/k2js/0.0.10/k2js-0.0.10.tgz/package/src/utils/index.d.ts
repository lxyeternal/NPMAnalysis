/**
 * 简单的浅复制对象。
 * @param {Object} target 要复制的目标对象。
 * @param {Object} source 要复制的源对象。
 * @param {Boolean} strict 指示是否复制未定义的属性，默认为false，即不复制未定义的属性。
 * @returns {Object} 复制后的对象。
 */
export declare function copy(target: any, source: any, strict?: boolean): any;
export declare function warn(str: string | undefined): void;
/**
 * 将鼠标坐标转换为Canvas坐标
 */
export declare function windowToCanvas(canvas: HTMLCanvasElement | undefined, x: number, y: number): {
    x: number;
    y: number;
};
export declare function activeColor(color: string): string;
export declare function isNull(val: any): boolean;
export declare function isUndefined(val: any): boolean;
export declare function suffixTextSize(): 5 | 6 | 7 | 8;
