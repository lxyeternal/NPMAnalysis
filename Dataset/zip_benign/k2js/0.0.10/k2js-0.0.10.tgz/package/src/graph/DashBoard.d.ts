import { labelVal } from '../renderer/base/text';
import BaseDraw from './BaseDraw';
interface DashBoardOptions {
    el: HTMLElement;
    attr: {
        min: number | labelVal;
        max: number | labelVal;
        title: string;
        stops: string[][];
        showColorsBoard?: boolean;
        tooltip?: {
            valueSuffix?: string;
        };
    };
    value: number;
}
export default class DashBoard extends BaseDraw {
    options: DashBoardOptions;
    leftAngle: number;
    color: string;
    value: string;
    stepRadio: number;
    curDrawRadio: number;
    resultRadio: number;
    drawFinish: boolean;
    maxRadius: number;
    maxRadius2: number;
    dashWidth: number;
    minRadius2: number;
    firstMove: boolean;
    maxMoveRadius: number;
    drawingSurfaceImageData: ImageData | undefined;
    constructor(options: DashBoardOptions);
    render(): void;
    setValue(value: any): void;
    resize(): void;
    clear(): Promise<void>;
    destroy(): void;
    /**
     * =============== 鼠标移动 ===============
     */
    private bindMouseMove;
    private drawActiveBoard;
    /**
     * 计算仪表盘参数
     */
    _calcDashBoardParams(): void;
    private _drawDashBoard;
    private _commonDrawBoard;
    _initRadius(): void;
    private drawColorsBoard;
    private drawTooltipRect;
    saveDrawingSurface(): void;
    restoreDrawingSurface(): void;
}
export {};
