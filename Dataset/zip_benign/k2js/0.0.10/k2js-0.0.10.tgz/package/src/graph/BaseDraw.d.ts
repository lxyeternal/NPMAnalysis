export interface labelVal {
    value: number;
    label: string;
}
interface DrawArcOptions {
    x: number;
    y: number;
    color: string;
    radius: number;
    startAngle?: number;
    endAngle?: number;
    clockwise?: boolean;
}
interface DrawTextOptions {
    text: string | undefined;
    x: number;
    y: number;
}
interface DrawLabelOptions {
    ctx: CanvasRenderingContext2D;
    text: number | labelVal | string;
    x: number;
    y: number;
}
interface DrawColorRectOptions {
    color: string;
    x: number;
    y: number;
    text: number | string;
}
interface DrawRoundRectOptions {
    color: string;
    x: number;
    y: number;
    w: number;
    h: number;
    bgColor?: string;
    r?: number;
}
interface DrawTooltipOptions {
    x: number;
    y: number;
    text: string;
    color: string;
}
export default class BaseDraw {
    container: HTMLElement;
    canvas: HTMLCanvasElement;
    ctx: CanvasRenderingContext2D | null;
    minHeight: number;
    minWidth: number;
    width: number;
    height: number;
    widthRadio: number;
    heightRadio: number;
    centerPtx: number;
    centerPty: number;
    textSize: number;
    constructor(container: HTMLElement);
    _initRenderer(): void;
    _initSize(): void;
    /**
     * ================ draw arc ===============
     */
    drawFillArc({ x, y, color, radius, startAngle, endAngle, clockwise, }: DrawArcOptions): void;
    /**
     * ================ draw text ===============
     */
    drawTitle({ text, x, y, }: DrawTextOptions): void;
    drawLabel({ text, x, y, }: DrawLabelOptions): void;
    drawBoldText({ text, x, y, }: DrawTextOptions): void;
    drawSuffixText({ text, x, y, }: DrawTextOptions): void;
    /**
     * ================ draw rect ===============
     */
    drawColorRect({ color, x, y, text, }: DrawColorRectOptions): void;
    drawRoundRect({ color, bgColor, x, y, w, h, r }: DrawRoundRectOptions): void;
    drawTooltip({ color, text, x, y, }: DrawTooltipOptions): void;
}
export declare function setTextCenter(ctx: CanvasRenderingContext2D): void;
export {};
