export interface labelVal {
    value: number;
    label: string;
}
