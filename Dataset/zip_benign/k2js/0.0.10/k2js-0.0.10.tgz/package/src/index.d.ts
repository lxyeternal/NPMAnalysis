import DashBoard from "./graph/DashBoard";
declare const _default: {
    DashBoard: typeof DashBoard;
};
export default _default;
