# k2

## do
- 设置0值，不会报错、不会越界
- 设置100值，不会报错、不会越界
- 选择时，产生动画和浮动窗
- resize时，界面刷新，不会产生动画
- 文字随分辨率改变



## dashboard：仪表盘

```javascript
const myK2 = new window.k2.dashBoard({
  el: document.getElementById('main1'),
  attr: {
    title: '定向通过率',
    min: 0,
    max: 100,
    stops: [
      [0.2, '#f5222d'], // 红
      [0.4, '#ff7a45'], // 橙
      [0.6, '#e5f7d3'], // 青
      [0.8, '#73d13d'], // 浅绿
      [1, '#389e0d'], // 深绿
    ],
    tooltip: {
      valueSuffix: '定向通过率'
    }
  },
  value: 20
});
myK2.draw();
```

