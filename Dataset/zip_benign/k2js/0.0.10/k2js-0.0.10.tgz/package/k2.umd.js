(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
	typeof define === 'function' && define.amd ? define(factory) :
	(global = typeof globalThis !== 'undefined' ? globalThis : global || self, global.k2 = factory());
})(this, (function () { 'use strict';

	function createCommonjsModule(fn, module) {
		return module = { exports: {} }, fn(module, module.exports), module.exports;
	}

	var colorName = {
		"aliceblue": [240, 248, 255],
		"antiquewhite": [250, 235, 215],
		"aqua": [0, 255, 255],
		"aquamarine": [127, 255, 212],
		"azure": [240, 255, 255],
		"beige": [245, 245, 220],
		"bisque": [255, 228, 196],
		"black": [0, 0, 0],
		"blanchedalmond": [255, 235, 205],
		"blue": [0, 0, 255],
		"blueviolet": [138, 43, 226],
		"brown": [165, 42, 42],
		"burlywood": [222, 184, 135],
		"cadetblue": [95, 158, 160],
		"chartreuse": [127, 255, 0],
		"chocolate": [210, 105, 30],
		"coral": [255, 127, 80],
		"cornflowerblue": [100, 149, 237],
		"cornsilk": [255, 248, 220],
		"crimson": [220, 20, 60],
		"cyan": [0, 255, 255],
		"darkblue": [0, 0, 139],
		"darkcyan": [0, 139, 139],
		"darkgoldenrod": [184, 134, 11],
		"darkgray": [169, 169, 169],
		"darkgreen": [0, 100, 0],
		"darkgrey": [169, 169, 169],
		"darkkhaki": [189, 183, 107],
		"darkmagenta": [139, 0, 139],
		"darkolivegreen": [85, 107, 47],
		"darkorange": [255, 140, 0],
		"darkorchid": [153, 50, 204],
		"darkred": [139, 0, 0],
		"darksalmon": [233, 150, 122],
		"darkseagreen": [143, 188, 143],
		"darkslateblue": [72, 61, 139],
		"darkslategray": [47, 79, 79],
		"darkslategrey": [47, 79, 79],
		"darkturquoise": [0, 206, 209],
		"darkviolet": [148, 0, 211],
		"deeppink": [255, 20, 147],
		"deepskyblue": [0, 191, 255],
		"dimgray": [105, 105, 105],
		"dimgrey": [105, 105, 105],
		"dodgerblue": [30, 144, 255],
		"firebrick": [178, 34, 34],
		"floralwhite": [255, 250, 240],
		"forestgreen": [34, 139, 34],
		"fuchsia": [255, 0, 255],
		"gainsboro": [220, 220, 220],
		"ghostwhite": [248, 248, 255],
		"gold": [255, 215, 0],
		"goldenrod": [218, 165, 32],
		"gray": [128, 128, 128],
		"green": [0, 128, 0],
		"greenyellow": [173, 255, 47],
		"grey": [128, 128, 128],
		"honeydew": [240, 255, 240],
		"hotpink": [255, 105, 180],
		"indianred": [205, 92, 92],
		"indigo": [75, 0, 130],
		"ivory": [255, 255, 240],
		"khaki": [240, 230, 140],
		"lavender": [230, 230, 250],
		"lavenderblush": [255, 240, 245],
		"lawngreen": [124, 252, 0],
		"lemonchiffon": [255, 250, 205],
		"lightblue": [173, 216, 230],
		"lightcoral": [240, 128, 128],
		"lightcyan": [224, 255, 255],
		"lightgoldenrodyellow": [250, 250, 210],
		"lightgray": [211, 211, 211],
		"lightgreen": [144, 238, 144],
		"lightgrey": [211, 211, 211],
		"lightpink": [255, 182, 193],
		"lightsalmon": [255, 160, 122],
		"lightseagreen": [32, 178, 170],
		"lightskyblue": [135, 206, 250],
		"lightslategray": [119, 136, 153],
		"lightslategrey": [119, 136, 153],
		"lightsteelblue": [176, 196, 222],
		"lightyellow": [255, 255, 224],
		"lime": [0, 255, 0],
		"limegreen": [50, 205, 50],
		"linen": [250, 240, 230],
		"magenta": [255, 0, 255],
		"maroon": [128, 0, 0],
		"mediumaquamarine": [102, 205, 170],
		"mediumblue": [0, 0, 205],
		"mediumorchid": [186, 85, 211],
		"mediumpurple": [147, 112, 219],
		"mediumseagreen": [60, 179, 113],
		"mediumslateblue": [123, 104, 238],
		"mediumspringgreen": [0, 250, 154],
		"mediumturquoise": [72, 209, 204],
		"mediumvioletred": [199, 21, 133],
		"midnightblue": [25, 25, 112],
		"mintcream": [245, 255, 250],
		"mistyrose": [255, 228, 225],
		"moccasin": [255, 228, 181],
		"navajowhite": [255, 222, 173],
		"navy": [0, 0, 128],
		"oldlace": [253, 245, 230],
		"olive": [128, 128, 0],
		"olivedrab": [107, 142, 35],
		"orange": [255, 165, 0],
		"orangered": [255, 69, 0],
		"orchid": [218, 112, 214],
		"palegoldenrod": [238, 232, 170],
		"palegreen": [152, 251, 152],
		"paleturquoise": [175, 238, 238],
		"palevioletred": [219, 112, 147],
		"papayawhip": [255, 239, 213],
		"peachpuff": [255, 218, 185],
		"peru": [205, 133, 63],
		"pink": [255, 192, 203],
		"plum": [221, 160, 221],
		"powderblue": [176, 224, 230],
		"purple": [128, 0, 128],
		"rebeccapurple": [102, 51, 153],
		"red": [255, 0, 0],
		"rosybrown": [188, 143, 143],
		"royalblue": [65, 105, 225],
		"saddlebrown": [139, 69, 19],
		"salmon": [250, 128, 114],
		"sandybrown": [244, 164, 96],
		"seagreen": [46, 139, 87],
		"seashell": [255, 245, 238],
		"sienna": [160, 82, 45],
		"silver": [192, 192, 192],
		"skyblue": [135, 206, 235],
		"slateblue": [106, 90, 205],
		"slategray": [112, 128, 144],
		"slategrey": [112, 128, 144],
		"snow": [255, 250, 250],
		"springgreen": [0, 255, 127],
		"steelblue": [70, 130, 180],
		"tan": [210, 180, 140],
		"teal": [0, 128, 128],
		"thistle": [216, 191, 216],
		"tomato": [255, 99, 71],
		"turquoise": [64, 224, 208],
		"violet": [238, 130, 238],
		"wheat": [245, 222, 179],
		"white": [255, 255, 255],
		"whitesmoke": [245, 245, 245],
		"yellow": [255, 255, 0],
		"yellowgreen": [154, 205, 50]
	};

	var isArrayish = function isArrayish(obj) {
		if (!obj || typeof obj === 'string') {
			return false;
		}

		return obj instanceof Array || Array.isArray(obj) ||
			(obj.length >= 0 && (obj.splice instanceof Function ||
				(Object.getOwnPropertyDescriptor(obj, (obj.length - 1)) && obj.constructor.name !== 'String')));
	};

	var simpleSwizzle = createCommonjsModule(function (module) {



	var concat = Array.prototype.concat;
	var slice = Array.prototype.slice;

	var swizzle = module.exports = function swizzle(args) {
		var results = [];

		for (var i = 0, len = args.length; i < len; i++) {
			var arg = args[i];

			if (isArrayish(arg)) {
				// http://jsperf.com/javascript-array-concat-vs-push/98
				results = concat.call(results, slice.call(arg));
			} else {
				results.push(arg);
			}
		}

		return results;
	};

	swizzle.wrap = function (fn) {
		return function () {
			return fn(swizzle(arguments));
		};
	};
	});

	var colorString = createCommonjsModule(function (module) {
	/* MIT license */


	var hasOwnProperty = Object.hasOwnProperty;

	var reverseNames = {};

	// create a list of reverse color names
	for (var name in colorName) {
		if (hasOwnProperty.call(colorName, name)) {
			reverseNames[colorName[name]] = name;
		}
	}

	var cs = module.exports = {
		to: {},
		get: {}
	};

	cs.get = function (string) {
		var prefix = string.substring(0, 3).toLowerCase();
		var val;
		var model;
		switch (prefix) {
			case 'hsl':
				val = cs.get.hsl(string);
				model = 'hsl';
				break;
			case 'hwb':
				val = cs.get.hwb(string);
				model = 'hwb';
				break;
			default:
				val = cs.get.rgb(string);
				model = 'rgb';
				break;
		}

		if (!val) {
			return null;
		}

		return {model: model, value: val};
	};

	cs.get.rgb = function (string) {
		if (!string) {
			return null;
		}

		var abbr = /^#([a-f0-9]{3,4})$/i;
		var hex = /^#([a-f0-9]{6})([a-f0-9]{2})?$/i;
		var rgba = /^rgba?\(\s*([+-]?\d+)(?=[\s,])\s*(?:,\s*)?([+-]?\d+)(?=[\s,])\s*(?:,\s*)?([+-]?\d+)\s*(?:[,|\/]\s*([+-]?[\d\.]+)(%?)\s*)?\)$/;
		var per = /^rgba?\(\s*([+-]?[\d\.]+)\%\s*,?\s*([+-]?[\d\.]+)\%\s*,?\s*([+-]?[\d\.]+)\%\s*(?:[,|\/]\s*([+-]?[\d\.]+)(%?)\s*)?\)$/;
		var keyword = /^(\w+)$/;

		var rgb = [0, 0, 0, 1];
		var match;
		var i;
		var hexAlpha;

		if (match = string.match(hex)) {
			hexAlpha = match[2];
			match = match[1];

			for (i = 0; i < 3; i++) {
				// https://jsperf.com/slice-vs-substr-vs-substring-methods-long-string/19
				var i2 = i * 2;
				rgb[i] = parseInt(match.slice(i2, i2 + 2), 16);
			}

			if (hexAlpha) {
				rgb[3] = parseInt(hexAlpha, 16) / 255;
			}
		} else if (match = string.match(abbr)) {
			match = match[1];
			hexAlpha = match[3];

			for (i = 0; i < 3; i++) {
				rgb[i] = parseInt(match[i] + match[i], 16);
			}

			if (hexAlpha) {
				rgb[3] = parseInt(hexAlpha + hexAlpha, 16) / 255;
			}
		} else if (match = string.match(rgba)) {
			for (i = 0; i < 3; i++) {
				rgb[i] = parseInt(match[i + 1], 0);
			}

			if (match[4]) {
				if (match[5]) {
					rgb[3] = parseFloat(match[4]) * 0.01;
				} else {
					rgb[3] = parseFloat(match[4]);
				}
			}
		} else if (match = string.match(per)) {
			for (i = 0; i < 3; i++) {
				rgb[i] = Math.round(parseFloat(match[i + 1]) * 2.55);
			}

			if (match[4]) {
				if (match[5]) {
					rgb[3] = parseFloat(match[4]) * 0.01;
				} else {
					rgb[3] = parseFloat(match[4]);
				}
			}
		} else if (match = string.match(keyword)) {
			if (match[1] === 'transparent') {
				return [0, 0, 0, 0];
			}

			if (!hasOwnProperty.call(colorName, match[1])) {
				return null;
			}

			rgb = colorName[match[1]];
			rgb[3] = 1;

			return rgb;
		} else {
			return null;
		}

		for (i = 0; i < 3; i++) {
			rgb[i] = clamp(rgb[i], 0, 255);
		}
		rgb[3] = clamp(rgb[3], 0, 1);

		return rgb;
	};

	cs.get.hsl = function (string) {
		if (!string) {
			return null;
		}

		var hsl = /^hsla?\(\s*([+-]?(?:\d{0,3}\.)?\d+)(?:deg)?\s*,?\s*([+-]?[\d\.]+)%\s*,?\s*([+-]?[\d\.]+)%\s*(?:[,|\/]\s*([+-]?(?=\.\d|\d)(?:0|[1-9]\d*)?(?:\.\d*)?(?:[eE][+-]?\d+)?)\s*)?\)$/;
		var match = string.match(hsl);

		if (match) {
			var alpha = parseFloat(match[4]);
			var h = ((parseFloat(match[1]) % 360) + 360) % 360;
			var s = clamp(parseFloat(match[2]), 0, 100);
			var l = clamp(parseFloat(match[3]), 0, 100);
			var a = clamp(isNaN(alpha) ? 1 : alpha, 0, 1);

			return [h, s, l, a];
		}

		return null;
	};

	cs.get.hwb = function (string) {
		if (!string) {
			return null;
		}

		var hwb = /^hwb\(\s*([+-]?\d{0,3}(?:\.\d+)?)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?(?=\.\d|\d)(?:0|[1-9]\d*)?(?:\.\d*)?(?:[eE][+-]?\d+)?)\s*)?\)$/;
		var match = string.match(hwb);

		if (match) {
			var alpha = parseFloat(match[4]);
			var h = ((parseFloat(match[1]) % 360) + 360) % 360;
			var w = clamp(parseFloat(match[2]), 0, 100);
			var b = clamp(parseFloat(match[3]), 0, 100);
			var a = clamp(isNaN(alpha) ? 1 : alpha, 0, 1);
			return [h, w, b, a];
		}

		return null;
	};

	cs.to.hex = function () {
		var rgba = simpleSwizzle(arguments);

		return (
			'#' +
			hexDouble(rgba[0]) +
			hexDouble(rgba[1]) +
			hexDouble(rgba[2]) +
			(rgba[3] < 1
				? (hexDouble(Math.round(rgba[3] * 255)))
				: '')
		);
	};

	cs.to.rgb = function () {
		var rgba = simpleSwizzle(arguments);

		return rgba.length < 4 || rgba[3] === 1
			? 'rgb(' + Math.round(rgba[0]) + ', ' + Math.round(rgba[1]) + ', ' + Math.round(rgba[2]) + ')'
			: 'rgba(' + Math.round(rgba[0]) + ', ' + Math.round(rgba[1]) + ', ' + Math.round(rgba[2]) + ', ' + rgba[3] + ')';
	};

	cs.to.rgb.percent = function () {
		var rgba = simpleSwizzle(arguments);

		var r = Math.round(rgba[0] / 255 * 100);
		var g = Math.round(rgba[1] / 255 * 100);
		var b = Math.round(rgba[2] / 255 * 100);

		return rgba.length < 4 || rgba[3] === 1
			? 'rgb(' + r + '%, ' + g + '%, ' + b + '%)'
			: 'rgba(' + r + '%, ' + g + '%, ' + b + '%, ' + rgba[3] + ')';
	};

	cs.to.hsl = function () {
		var hsla = simpleSwizzle(arguments);
		return hsla.length < 4 || hsla[3] === 1
			? 'hsl(' + hsla[0] + ', ' + hsla[1] + '%, ' + hsla[2] + '%)'
			: 'hsla(' + hsla[0] + ', ' + hsla[1] + '%, ' + hsla[2] + '%, ' + hsla[3] + ')';
	};

	// hwb is a bit different than rgb(a) & hsl(a) since there is no alpha specific syntax
	// (hwb have alpha optional & 1 is default value)
	cs.to.hwb = function () {
		var hwba = simpleSwizzle(arguments);

		var a = '';
		if (hwba.length >= 4 && hwba[3] !== 1) {
			a = ', ' + hwba[3];
		}

		return 'hwb(' + hwba[0] + ', ' + hwba[1] + '%, ' + hwba[2] + '%' + a + ')';
	};

	cs.to.keyword = function (rgb) {
		return reverseNames[rgb.slice(0, 3)];
	};

	// helpers
	function clamp(num, min, max) {
		return Math.min(Math.max(min, num), max);
	}

	function hexDouble(num) {
		var str = Math.round(num).toString(16).toUpperCase();
		return (str.length < 2) ? '0' + str : str;
	}
	});
	colorString.to;
	colorString.get;

	/* MIT license */
	/* eslint-disable no-mixed-operators */


	// NOTE: conversions should only return primitive values (i.e. arrays, or
	//       values that give correct `typeof` results).
	//       do not use box values types (i.e. Number(), String(), etc.)

	const reverseKeywords = {};
	for (const key of Object.keys(colorName)) {
		reverseKeywords[colorName[key]] = key;
	}

	const convert$1 = {
		rgb: {channels: 3, labels: 'rgb'},
		hsl: {channels: 3, labels: 'hsl'},
		hsv: {channels: 3, labels: 'hsv'},
		hwb: {channels: 3, labels: 'hwb'},
		cmyk: {channels: 4, labels: 'cmyk'},
		xyz: {channels: 3, labels: 'xyz'},
		lab: {channels: 3, labels: 'lab'},
		lch: {channels: 3, labels: 'lch'},
		hex: {channels: 1, labels: ['hex']},
		keyword: {channels: 1, labels: ['keyword']},
		ansi16: {channels: 1, labels: ['ansi16']},
		ansi256: {channels: 1, labels: ['ansi256']},
		hcg: {channels: 3, labels: ['h', 'c', 'g']},
		apple: {channels: 3, labels: ['r16', 'g16', 'b16']},
		gray: {channels: 1, labels: ['gray']}
	};

	var conversions = convert$1;

	// Hide .channels and .labels properties
	for (const model of Object.keys(convert$1)) {
		if (!('channels' in convert$1[model])) {
			throw new Error('missing channels property: ' + model);
		}

		if (!('labels' in convert$1[model])) {
			throw new Error('missing channel labels property: ' + model);
		}

		if (convert$1[model].labels.length !== convert$1[model].channels) {
			throw new Error('channel and label counts mismatch: ' + model);
		}

		const {channels, labels} = convert$1[model];
		delete convert$1[model].channels;
		delete convert$1[model].labels;
		Object.defineProperty(convert$1[model], 'channels', {value: channels});
		Object.defineProperty(convert$1[model], 'labels', {value: labels});
	}

	convert$1.rgb.hsl = function (rgb) {
		const r = rgb[0] / 255;
		const g = rgb[1] / 255;
		const b = rgb[2] / 255;
		const min = Math.min(r, g, b);
		const max = Math.max(r, g, b);
		const delta = max - min;
		let h;
		let s;

		if (max === min) {
			h = 0;
		} else if (r === max) {
			h = (g - b) / delta;
		} else if (g === max) {
			h = 2 + (b - r) / delta;
		} else if (b === max) {
			h = 4 + (r - g) / delta;
		}

		h = Math.min(h * 60, 360);

		if (h < 0) {
			h += 360;
		}

		const l = (min + max) / 2;

		if (max === min) {
			s = 0;
		} else if (l <= 0.5) {
			s = delta / (max + min);
		} else {
			s = delta / (2 - max - min);
		}

		return [h, s * 100, l * 100];
	};

	convert$1.rgb.hsv = function (rgb) {
		let rdif;
		let gdif;
		let bdif;
		let h;
		let s;

		const r = rgb[0] / 255;
		const g = rgb[1] / 255;
		const b = rgb[2] / 255;
		const v = Math.max(r, g, b);
		const diff = v - Math.min(r, g, b);
		const diffc = function (c) {
			return (v - c) / 6 / diff + 1 / 2;
		};

		if (diff === 0) {
			h = 0;
			s = 0;
		} else {
			s = diff / v;
			rdif = diffc(r);
			gdif = diffc(g);
			bdif = diffc(b);

			if (r === v) {
				h = bdif - gdif;
			} else if (g === v) {
				h = (1 / 3) + rdif - bdif;
			} else if (b === v) {
				h = (2 / 3) + gdif - rdif;
			}

			if (h < 0) {
				h += 1;
			} else if (h > 1) {
				h -= 1;
			}
		}

		return [
			h * 360,
			s * 100,
			v * 100
		];
	};

	convert$1.rgb.hwb = function (rgb) {
		const r = rgb[0];
		const g = rgb[1];
		let b = rgb[2];
		const h = convert$1.rgb.hsl(rgb)[0];
		const w = 1 / 255 * Math.min(r, Math.min(g, b));

		b = 1 - 1 / 255 * Math.max(r, Math.max(g, b));

		return [h, w * 100, b * 100];
	};

	convert$1.rgb.cmyk = function (rgb) {
		const r = rgb[0] / 255;
		const g = rgb[1] / 255;
		const b = rgb[2] / 255;

		const k = Math.min(1 - r, 1 - g, 1 - b);
		const c = (1 - r - k) / (1 - k) || 0;
		const m = (1 - g - k) / (1 - k) || 0;
		const y = (1 - b - k) / (1 - k) || 0;

		return [c * 100, m * 100, y * 100, k * 100];
	};

	function comparativeDistance(x, y) {
		/*
			See https://en.m.wikipedia.org/wiki/Euclidean_distance#Squared_Euclidean_distance
		*/
		return (
			((x[0] - y[0]) ** 2) +
			((x[1] - y[1]) ** 2) +
			((x[2] - y[2]) ** 2)
		);
	}

	convert$1.rgb.keyword = function (rgb) {
		const reversed = reverseKeywords[rgb];
		if (reversed) {
			return reversed;
		}

		let currentClosestDistance = Infinity;
		let currentClosestKeyword;

		for (const keyword of Object.keys(colorName)) {
			const value = colorName[keyword];

			// Compute comparative distance
			const distance = comparativeDistance(rgb, value);

			// Check if its less, if so set as closest
			if (distance < currentClosestDistance) {
				currentClosestDistance = distance;
				currentClosestKeyword = keyword;
			}
		}

		return currentClosestKeyword;
	};

	convert$1.keyword.rgb = function (keyword) {
		return colorName[keyword];
	};

	convert$1.rgb.xyz = function (rgb) {
		let r = rgb[0] / 255;
		let g = rgb[1] / 255;
		let b = rgb[2] / 255;

		// Assume sRGB
		r = r > 0.04045 ? (((r + 0.055) / 1.055) ** 2.4) : (r / 12.92);
		g = g > 0.04045 ? (((g + 0.055) / 1.055) ** 2.4) : (g / 12.92);
		b = b > 0.04045 ? (((b + 0.055) / 1.055) ** 2.4) : (b / 12.92);

		const x = (r * 0.4124) + (g * 0.3576) + (b * 0.1805);
		const y = (r * 0.2126) + (g * 0.7152) + (b * 0.0722);
		const z = (r * 0.0193) + (g * 0.1192) + (b * 0.9505);

		return [x * 100, y * 100, z * 100];
	};

	convert$1.rgb.lab = function (rgb) {
		const xyz = convert$1.rgb.xyz(rgb);
		let x = xyz[0];
		let y = xyz[1];
		let z = xyz[2];

		x /= 95.047;
		y /= 100;
		z /= 108.883;

		x = x > 0.008856 ? (x ** (1 / 3)) : (7.787 * x) + (16 / 116);
		y = y > 0.008856 ? (y ** (1 / 3)) : (7.787 * y) + (16 / 116);
		z = z > 0.008856 ? (z ** (1 / 3)) : (7.787 * z) + (16 / 116);

		const l = (116 * y) - 16;
		const a = 500 * (x - y);
		const b = 200 * (y - z);

		return [l, a, b];
	};

	convert$1.hsl.rgb = function (hsl) {
		const h = hsl[0] / 360;
		const s = hsl[1] / 100;
		const l = hsl[2] / 100;
		let t2;
		let t3;
		let val;

		if (s === 0) {
			val = l * 255;
			return [val, val, val];
		}

		if (l < 0.5) {
			t2 = l * (1 + s);
		} else {
			t2 = l + s - l * s;
		}

		const t1 = 2 * l - t2;

		const rgb = [0, 0, 0];
		for (let i = 0; i < 3; i++) {
			t3 = h + 1 / 3 * -(i - 1);
			if (t3 < 0) {
				t3++;
			}

			if (t3 > 1) {
				t3--;
			}

			if (6 * t3 < 1) {
				val = t1 + (t2 - t1) * 6 * t3;
			} else if (2 * t3 < 1) {
				val = t2;
			} else if (3 * t3 < 2) {
				val = t1 + (t2 - t1) * (2 / 3 - t3) * 6;
			} else {
				val = t1;
			}

			rgb[i] = val * 255;
		}

		return rgb;
	};

	convert$1.hsl.hsv = function (hsl) {
		const h = hsl[0];
		let s = hsl[1] / 100;
		let l = hsl[2] / 100;
		let smin = s;
		const lmin = Math.max(l, 0.01);

		l *= 2;
		s *= (l <= 1) ? l : 2 - l;
		smin *= lmin <= 1 ? lmin : 2 - lmin;
		const v = (l + s) / 2;
		const sv = l === 0 ? (2 * smin) / (lmin + smin) : (2 * s) / (l + s);

		return [h, sv * 100, v * 100];
	};

	convert$1.hsv.rgb = function (hsv) {
		const h = hsv[0] / 60;
		const s = hsv[1] / 100;
		let v = hsv[2] / 100;
		const hi = Math.floor(h) % 6;

		const f = h - Math.floor(h);
		const p = 255 * v * (1 - s);
		const q = 255 * v * (1 - (s * f));
		const t = 255 * v * (1 - (s * (1 - f)));
		v *= 255;

		switch (hi) {
			case 0:
				return [v, t, p];
			case 1:
				return [q, v, p];
			case 2:
				return [p, v, t];
			case 3:
				return [p, q, v];
			case 4:
				return [t, p, v];
			case 5:
				return [v, p, q];
		}
	};

	convert$1.hsv.hsl = function (hsv) {
		const h = hsv[0];
		const s = hsv[1] / 100;
		const v = hsv[2] / 100;
		const vmin = Math.max(v, 0.01);
		let sl;
		let l;

		l = (2 - s) * v;
		const lmin = (2 - s) * vmin;
		sl = s * vmin;
		sl /= (lmin <= 1) ? lmin : 2 - lmin;
		sl = sl || 0;
		l /= 2;

		return [h, sl * 100, l * 100];
	};

	// http://dev.w3.org/csswg/css-color/#hwb-to-rgb
	convert$1.hwb.rgb = function (hwb) {
		const h = hwb[0] / 360;
		let wh = hwb[1] / 100;
		let bl = hwb[2] / 100;
		const ratio = wh + bl;
		let f;

		// Wh + bl cant be > 1
		if (ratio > 1) {
			wh /= ratio;
			bl /= ratio;
		}

		const i = Math.floor(6 * h);
		const v = 1 - bl;
		f = 6 * h - i;

		if ((i & 0x01) !== 0) {
			f = 1 - f;
		}

		const n = wh + f * (v - wh); // Linear interpolation

		let r;
		let g;
		let b;
		/* eslint-disable max-statements-per-line,no-multi-spaces */
		switch (i) {
			default:
			case 6:
			case 0: r = v;  g = n;  b = wh; break;
			case 1: r = n;  g = v;  b = wh; break;
			case 2: r = wh; g = v;  b = n; break;
			case 3: r = wh; g = n;  b = v; break;
			case 4: r = n;  g = wh; b = v; break;
			case 5: r = v;  g = wh; b = n; break;
		}
		/* eslint-enable max-statements-per-line,no-multi-spaces */

		return [r * 255, g * 255, b * 255];
	};

	convert$1.cmyk.rgb = function (cmyk) {
		const c = cmyk[0] / 100;
		const m = cmyk[1] / 100;
		const y = cmyk[2] / 100;
		const k = cmyk[3] / 100;

		const r = 1 - Math.min(1, c * (1 - k) + k);
		const g = 1 - Math.min(1, m * (1 - k) + k);
		const b = 1 - Math.min(1, y * (1 - k) + k);

		return [r * 255, g * 255, b * 255];
	};

	convert$1.xyz.rgb = function (xyz) {
		const x = xyz[0] / 100;
		const y = xyz[1] / 100;
		const z = xyz[2] / 100;
		let r;
		let g;
		let b;

		r = (x * 3.2406) + (y * -1.5372) + (z * -0.4986);
		g = (x * -0.9689) + (y * 1.8758) + (z * 0.0415);
		b = (x * 0.0557) + (y * -0.2040) + (z * 1.0570);

		// Assume sRGB
		r = r > 0.0031308
			? ((1.055 * (r ** (1.0 / 2.4))) - 0.055)
			: r * 12.92;

		g = g > 0.0031308
			? ((1.055 * (g ** (1.0 / 2.4))) - 0.055)
			: g * 12.92;

		b = b > 0.0031308
			? ((1.055 * (b ** (1.0 / 2.4))) - 0.055)
			: b * 12.92;

		r = Math.min(Math.max(0, r), 1);
		g = Math.min(Math.max(0, g), 1);
		b = Math.min(Math.max(0, b), 1);

		return [r * 255, g * 255, b * 255];
	};

	convert$1.xyz.lab = function (xyz) {
		let x = xyz[0];
		let y = xyz[1];
		let z = xyz[2];

		x /= 95.047;
		y /= 100;
		z /= 108.883;

		x = x > 0.008856 ? (x ** (1 / 3)) : (7.787 * x) + (16 / 116);
		y = y > 0.008856 ? (y ** (1 / 3)) : (7.787 * y) + (16 / 116);
		z = z > 0.008856 ? (z ** (1 / 3)) : (7.787 * z) + (16 / 116);

		const l = (116 * y) - 16;
		const a = 500 * (x - y);
		const b = 200 * (y - z);

		return [l, a, b];
	};

	convert$1.lab.xyz = function (lab) {
		const l = lab[0];
		const a = lab[1];
		const b = lab[2];
		let x;
		let y;
		let z;

		y = (l + 16) / 116;
		x = a / 500 + y;
		z = y - b / 200;

		const y2 = y ** 3;
		const x2 = x ** 3;
		const z2 = z ** 3;
		y = y2 > 0.008856 ? y2 : (y - 16 / 116) / 7.787;
		x = x2 > 0.008856 ? x2 : (x - 16 / 116) / 7.787;
		z = z2 > 0.008856 ? z2 : (z - 16 / 116) / 7.787;

		x *= 95.047;
		y *= 100;
		z *= 108.883;

		return [x, y, z];
	};

	convert$1.lab.lch = function (lab) {
		const l = lab[0];
		const a = lab[1];
		const b = lab[2];
		let h;

		const hr = Math.atan2(b, a);
		h = hr * 360 / 2 / Math.PI;

		if (h < 0) {
			h += 360;
		}

		const c = Math.sqrt(a * a + b * b);

		return [l, c, h];
	};

	convert$1.lch.lab = function (lch) {
		const l = lch[0];
		const c = lch[1];
		const h = lch[2];

		const hr = h / 360 * 2 * Math.PI;
		const a = c * Math.cos(hr);
		const b = c * Math.sin(hr);

		return [l, a, b];
	};

	convert$1.rgb.ansi16 = function (args, saturation = null) {
		const [r, g, b] = args;
		let value = saturation === null ? convert$1.rgb.hsv(args)[2] : saturation; // Hsv -> ansi16 optimization

		value = Math.round(value / 50);

		if (value === 0) {
			return 30;
		}

		let ansi = 30
			+ ((Math.round(b / 255) << 2)
			| (Math.round(g / 255) << 1)
			| Math.round(r / 255));

		if (value === 2) {
			ansi += 60;
		}

		return ansi;
	};

	convert$1.hsv.ansi16 = function (args) {
		// Optimization here; we already know the value and don't need to get
		// it converted for us.
		return convert$1.rgb.ansi16(convert$1.hsv.rgb(args), args[2]);
	};

	convert$1.rgb.ansi256 = function (args) {
		const r = args[0];
		const g = args[1];
		const b = args[2];

		// We use the extended greyscale palette here, with the exception of
		// black and white. normal palette only has 4 greyscale shades.
		if (r === g && g === b) {
			if (r < 8) {
				return 16;
			}

			if (r > 248) {
				return 231;
			}

			return Math.round(((r - 8) / 247) * 24) + 232;
		}

		const ansi = 16
			+ (36 * Math.round(r / 255 * 5))
			+ (6 * Math.round(g / 255 * 5))
			+ Math.round(b / 255 * 5);

		return ansi;
	};

	convert$1.ansi16.rgb = function (args) {
		let color = args % 10;

		// Handle greyscale
		if (color === 0 || color === 7) {
			if (args > 50) {
				color += 3.5;
			}

			color = color / 10.5 * 255;

			return [color, color, color];
		}

		const mult = (~~(args > 50) + 1) * 0.5;
		const r = ((color & 1) * mult) * 255;
		const g = (((color >> 1) & 1) * mult) * 255;
		const b = (((color >> 2) & 1) * mult) * 255;

		return [r, g, b];
	};

	convert$1.ansi256.rgb = function (args) {
		// Handle greyscale
		if (args >= 232) {
			const c = (args - 232) * 10 + 8;
			return [c, c, c];
		}

		args -= 16;

		let rem;
		const r = Math.floor(args / 36) / 5 * 255;
		const g = Math.floor((rem = args % 36) / 6) / 5 * 255;
		const b = (rem % 6) / 5 * 255;

		return [r, g, b];
	};

	convert$1.rgb.hex = function (args) {
		const integer = ((Math.round(args[0]) & 0xFF) << 16)
			+ ((Math.round(args[1]) & 0xFF) << 8)
			+ (Math.round(args[2]) & 0xFF);

		const string = integer.toString(16).toUpperCase();
		return '000000'.substring(string.length) + string;
	};

	convert$1.hex.rgb = function (args) {
		const match = args.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);
		if (!match) {
			return [0, 0, 0];
		}

		let colorString = match[0];

		if (match[0].length === 3) {
			colorString = colorString.split('').map(char => {
				return char + char;
			}).join('');
		}

		const integer = parseInt(colorString, 16);
		const r = (integer >> 16) & 0xFF;
		const g = (integer >> 8) & 0xFF;
		const b = integer & 0xFF;

		return [r, g, b];
	};

	convert$1.rgb.hcg = function (rgb) {
		const r = rgb[0] / 255;
		const g = rgb[1] / 255;
		const b = rgb[2] / 255;
		const max = Math.max(Math.max(r, g), b);
		const min = Math.min(Math.min(r, g), b);
		const chroma = (max - min);
		let grayscale;
		let hue;

		if (chroma < 1) {
			grayscale = min / (1 - chroma);
		} else {
			grayscale = 0;
		}

		if (chroma <= 0) {
			hue = 0;
		} else
		if (max === r) {
			hue = ((g - b) / chroma) % 6;
		} else
		if (max === g) {
			hue = 2 + (b - r) / chroma;
		} else {
			hue = 4 + (r - g) / chroma;
		}

		hue /= 6;
		hue %= 1;

		return [hue * 360, chroma * 100, grayscale * 100];
	};

	convert$1.hsl.hcg = function (hsl) {
		const s = hsl[1] / 100;
		const l = hsl[2] / 100;

		const c = l < 0.5 ? (2.0 * s * l) : (2.0 * s * (1.0 - l));

		let f = 0;
		if (c < 1.0) {
			f = (l - 0.5 * c) / (1.0 - c);
		}

		return [hsl[0], c * 100, f * 100];
	};

	convert$1.hsv.hcg = function (hsv) {
		const s = hsv[1] / 100;
		const v = hsv[2] / 100;

		const c = s * v;
		let f = 0;

		if (c < 1.0) {
			f = (v - c) / (1 - c);
		}

		return [hsv[0], c * 100, f * 100];
	};

	convert$1.hcg.rgb = function (hcg) {
		const h = hcg[0] / 360;
		const c = hcg[1] / 100;
		const g = hcg[2] / 100;

		if (c === 0.0) {
			return [g * 255, g * 255, g * 255];
		}

		const pure = [0, 0, 0];
		const hi = (h % 1) * 6;
		const v = hi % 1;
		const w = 1 - v;
		let mg = 0;

		/* eslint-disable max-statements-per-line */
		switch (Math.floor(hi)) {
			case 0:
				pure[0] = 1; pure[1] = v; pure[2] = 0; break;
			case 1:
				pure[0] = w; pure[1] = 1; pure[2] = 0; break;
			case 2:
				pure[0] = 0; pure[1] = 1; pure[2] = v; break;
			case 3:
				pure[0] = 0; pure[1] = w; pure[2] = 1; break;
			case 4:
				pure[0] = v; pure[1] = 0; pure[2] = 1; break;
			default:
				pure[0] = 1; pure[1] = 0; pure[2] = w;
		}
		/* eslint-enable max-statements-per-line */

		mg = (1.0 - c) * g;

		return [
			(c * pure[0] + mg) * 255,
			(c * pure[1] + mg) * 255,
			(c * pure[2] + mg) * 255
		];
	};

	convert$1.hcg.hsv = function (hcg) {
		const c = hcg[1] / 100;
		const g = hcg[2] / 100;

		const v = c + g * (1.0 - c);
		let f = 0;

		if (v > 0.0) {
			f = c / v;
		}

		return [hcg[0], f * 100, v * 100];
	};

	convert$1.hcg.hsl = function (hcg) {
		const c = hcg[1] / 100;
		const g = hcg[2] / 100;

		const l = g * (1.0 - c) + 0.5 * c;
		let s = 0;

		if (l > 0.0 && l < 0.5) {
			s = c / (2 * l);
		} else
		if (l >= 0.5 && l < 1.0) {
			s = c / (2 * (1 - l));
		}

		return [hcg[0], s * 100, l * 100];
	};

	convert$1.hcg.hwb = function (hcg) {
		const c = hcg[1] / 100;
		const g = hcg[2] / 100;
		const v = c + g * (1.0 - c);
		return [hcg[0], (v - c) * 100, (1 - v) * 100];
	};

	convert$1.hwb.hcg = function (hwb) {
		const w = hwb[1] / 100;
		const b = hwb[2] / 100;
		const v = 1 - b;
		const c = v - w;
		let g = 0;

		if (c < 1) {
			g = (v - c) / (1 - c);
		}

		return [hwb[0], c * 100, g * 100];
	};

	convert$1.apple.rgb = function (apple) {
		return [(apple[0] / 65535) * 255, (apple[1] / 65535) * 255, (apple[2] / 65535) * 255];
	};

	convert$1.rgb.apple = function (rgb) {
		return [(rgb[0] / 255) * 65535, (rgb[1] / 255) * 65535, (rgb[2] / 255) * 65535];
	};

	convert$1.gray.rgb = function (args) {
		return [args[0] / 100 * 255, args[0] / 100 * 255, args[0] / 100 * 255];
	};

	convert$1.gray.hsl = function (args) {
		return [0, 0, args[0]];
	};

	convert$1.gray.hsv = convert$1.gray.hsl;

	convert$1.gray.hwb = function (gray) {
		return [0, 100, gray[0]];
	};

	convert$1.gray.cmyk = function (gray) {
		return [0, 0, 0, gray[0]];
	};

	convert$1.gray.lab = function (gray) {
		return [gray[0], 0, 0];
	};

	convert$1.gray.hex = function (gray) {
		const val = Math.round(gray[0] / 100 * 255) & 0xFF;
		const integer = (val << 16) + (val << 8) + val;

		const string = integer.toString(16).toUpperCase();
		return '000000'.substring(string.length) + string;
	};

	convert$1.rgb.gray = function (rgb) {
		const val = (rgb[0] + rgb[1] + rgb[2]) / 3;
		return [val / 255 * 100];
	};

	/*
		This function routes a model to all other models.

		all functions that are routed have a property `.conversion` attached
		to the returned synthetic function. This property is an array
		of strings, each with the steps in between the 'from' and 'to'
		color models (inclusive).

		conversions that are not possible simply are not included.
	*/

	function buildGraph() {
		const graph = {};
		// https://jsperf.com/object-keys-vs-for-in-with-closure/3
		const models = Object.keys(conversions);

		for (let len = models.length, i = 0; i < len; i++) {
			graph[models[i]] = {
				// http://jsperf.com/1-vs-infinity
				// micro-opt, but this is simple.
				distance: -1,
				parent: null
			};
		}

		return graph;
	}

	// https://en.wikipedia.org/wiki/Breadth-first_search
	function deriveBFS(fromModel) {
		const graph = buildGraph();
		const queue = [fromModel]; // Unshift -> queue -> pop

		graph[fromModel].distance = 0;

		while (queue.length) {
			const current = queue.pop();
			const adjacents = Object.keys(conversions[current]);

			for (let len = adjacents.length, i = 0; i < len; i++) {
				const adjacent = adjacents[i];
				const node = graph[adjacent];

				if (node.distance === -1) {
					node.distance = graph[current].distance + 1;
					node.parent = current;
					queue.unshift(adjacent);
				}
			}
		}

		return graph;
	}

	function link(from, to) {
		return function (args) {
			return to(from(args));
		};
	}

	function wrapConversion(toModel, graph) {
		const path = [graph[toModel].parent, toModel];
		let fn = conversions[graph[toModel].parent][toModel];

		let cur = graph[toModel].parent;
		while (graph[cur].parent) {
			path.unshift(graph[cur].parent);
			fn = link(conversions[graph[cur].parent][cur], fn);
			cur = graph[cur].parent;
		}

		fn.conversion = path;
		return fn;
	}

	var route = function (fromModel) {
		const graph = deriveBFS(fromModel);
		const conversion = {};

		const models = Object.keys(graph);
		for (let len = models.length, i = 0; i < len; i++) {
			const toModel = models[i];
			const node = graph[toModel];

			if (node.parent === null) {
				// No possible conversion, or this node is the source model.
				continue;
			}

			conversion[toModel] = wrapConversion(toModel, graph);
		}

		return conversion;
	};

	const convert = {};

	const models = Object.keys(conversions);

	function wrapRaw(fn) {
		const wrappedFn = function (...args) {
			const arg0 = args[0];
			if (arg0 === undefined || arg0 === null) {
				return arg0;
			}

			if (arg0.length > 1) {
				args = arg0;
			}

			return fn(args);
		};

		// Preserve .conversion property if there is one
		if ('conversion' in fn) {
			wrappedFn.conversion = fn.conversion;
		}

		return wrappedFn;
	}

	function wrapRounded(fn) {
		const wrappedFn = function (...args) {
			const arg0 = args[0];

			if (arg0 === undefined || arg0 === null) {
				return arg0;
			}

			if (arg0.length > 1) {
				args = arg0;
			}

			const result = fn(args);

			// We're assuming the result is an array here.
			// see notice in conversions.js; don't use box types
			// in conversion functions.
			if (typeof result === 'object') {
				for (let len = result.length, i = 0; i < len; i++) {
					result[i] = Math.round(result[i]);
				}
			}

			return result;
		};

		// Preserve .conversion property if there is one
		if ('conversion' in fn) {
			wrappedFn.conversion = fn.conversion;
		}

		return wrappedFn;
	}

	models.forEach(fromModel => {
		convert[fromModel] = {};

		Object.defineProperty(convert[fromModel], 'channels', {value: conversions[fromModel].channels});
		Object.defineProperty(convert[fromModel], 'labels', {value: conversions[fromModel].labels});

		const routes = route(fromModel);
		const routeModels = Object.keys(routes);

		routeModels.forEach(toModel => {
			const fn = routes[toModel];

			convert[fromModel][toModel] = wrapRounded(fn);
			convert[fromModel][toModel].raw = wrapRaw(fn);
		});
	});

	var colorConvert = convert;

	const _slice = [].slice;

	const skippedModels = [
		// To be honest, I don't really feel like keyword belongs in color convert, but eh.
		'keyword',

		// Gray conflicts with some method names, and has its own method defined.
		'gray',

		// Shouldn't really be in color-convert either...
		'hex',
	];

	const hashedModelKeys = {};
	for (const model of Object.keys(colorConvert)) {
		hashedModelKeys[_slice.call(colorConvert[model].labels).sort().join('')] = model;
	}

	const limiters = {};

	function Color(object, model) {
		if (!(this instanceof Color)) {
			return new Color(object, model);
		}

		if (model && model in skippedModels) {
			model = null;
		}

		if (model && !(model in colorConvert)) {
			throw new Error('Unknown model: ' + model);
		}

		let i;
		let channels;

		if (object == null) { // eslint-disable-line no-eq-null,eqeqeq
			this.model = 'rgb';
			this.color = [0, 0, 0];
			this.valpha = 1;
		} else if (object instanceof Color) {
			this.model = object.model;
			this.color = object.color.slice();
			this.valpha = object.valpha;
		} else if (typeof object === 'string') {
			const result = colorString.get(object);
			if (result === null) {
				throw new Error('Unable to parse color from string: ' + object);
			}

			this.model = result.model;
			channels = colorConvert[this.model].channels;
			this.color = result.value.slice(0, channels);
			this.valpha = typeof result.value[channels] === 'number' ? result.value[channels] : 1;
		} else if (object.length > 0) {
			this.model = model || 'rgb';
			channels = colorConvert[this.model].channels;
			const newArray = _slice.call(object, 0, channels);
			this.color = zeroArray(newArray, channels);
			this.valpha = typeof object[channels] === 'number' ? object[channels] : 1;
		} else if (typeof object === 'number') {
			// This is always RGB - can be converted later on.
			this.model = 'rgb';
			this.color = [
				(object >> 16) & 0xFF,
				(object >> 8) & 0xFF,
				object & 0xFF,
			];
			this.valpha = 1;
		} else {
			this.valpha = 1;

			const keys = Object.keys(object);
			if ('alpha' in object) {
				keys.splice(keys.indexOf('alpha'), 1);
				this.valpha = typeof object.alpha === 'number' ? object.alpha : 0;
			}

			const hashedKeys = keys.sort().join('');
			if (!(hashedKeys in hashedModelKeys)) {
				throw new Error('Unable to parse color from object: ' + JSON.stringify(object));
			}

			this.model = hashedModelKeys[hashedKeys];

			const labels = colorConvert[this.model].labels;
			const color = [];
			for (i = 0; i < labels.length; i++) {
				color.push(object[labels[i]]);
			}

			this.color = zeroArray(color);
		}

		// Perform limitations (clamping, etc.)
		if (limiters[this.model]) {
			channels = colorConvert[this.model].channels;
			for (i = 0; i < channels; i++) {
				const limit = limiters[this.model][i];
				if (limit) {
					this.color[i] = limit(this.color[i]);
				}
			}
		}

		this.valpha = Math.max(0, Math.min(1, this.valpha));

		if (Object.freeze) {
			Object.freeze(this);
		}
	}

	Color.prototype = {
		toString() {
			return this.string();
		},

		toJSON() {
			return this[this.model]();
		},

		string(places) {
			let self = this.model in colorString.to ? this : this.rgb();
			self = self.round(typeof places === 'number' ? places : 1);
			const args = self.valpha === 1 ? self.color : self.color.concat(this.valpha);
			return colorString.to[self.model](args);
		},

		percentString(places) {
			const self = this.rgb().round(typeof places === 'number' ? places : 1);
			const args = self.valpha === 1 ? self.color : self.color.concat(this.valpha);
			return colorString.to.rgb.percent(args);
		},

		array() {
			return this.valpha === 1 ? this.color.slice() : this.color.concat(this.valpha);
		},

		object() {
			const result = {};
			const channels = colorConvert[this.model].channels;
			const labels = colorConvert[this.model].labels;

			for (let i = 0; i < channels; i++) {
				result[labels[i]] = this.color[i];
			}

			if (this.valpha !== 1) {
				result.alpha = this.valpha;
			}

			return result;
		},

		unitArray() {
			const rgb = this.rgb().color;
			rgb[0] /= 255;
			rgb[1] /= 255;
			rgb[2] /= 255;

			if (this.valpha !== 1) {
				rgb.push(this.valpha);
			}

			return rgb;
		},

		unitObject() {
			const rgb = this.rgb().object();
			rgb.r /= 255;
			rgb.g /= 255;
			rgb.b /= 255;

			if (this.valpha !== 1) {
				rgb.alpha = this.valpha;
			}

			return rgb;
		},

		round(places) {
			places = Math.max(places || 0, 0);
			return new Color(this.color.map(roundToPlace(places)).concat(this.valpha), this.model);
		},

		alpha(value) {
			if (arguments.length > 0) {
				return new Color(this.color.concat(Math.max(0, Math.min(1, value))), this.model);
			}

			return this.valpha;
		},

		// Rgb
		red: getset('rgb', 0, maxfn(255)),
		green: getset('rgb', 1, maxfn(255)),
		blue: getset('rgb', 2, maxfn(255)),

		hue: getset(['hsl', 'hsv', 'hsl', 'hwb', 'hcg'], 0, value => ((value % 360) + 360) % 360),

		saturationl: getset('hsl', 1, maxfn(100)),
		lightness: getset('hsl', 2, maxfn(100)),

		saturationv: getset('hsv', 1, maxfn(100)),
		value: getset('hsv', 2, maxfn(100)),

		chroma: getset('hcg', 1, maxfn(100)),
		gray: getset('hcg', 2, maxfn(100)),

		white: getset('hwb', 1, maxfn(100)),
		wblack: getset('hwb', 2, maxfn(100)),

		cyan: getset('cmyk', 0, maxfn(100)),
		magenta: getset('cmyk', 1, maxfn(100)),
		yellow: getset('cmyk', 2, maxfn(100)),
		black: getset('cmyk', 3, maxfn(100)),

		x: getset('xyz', 0, maxfn(100)),
		y: getset('xyz', 1, maxfn(100)),
		z: getset('xyz', 2, maxfn(100)),

		l: getset('lab', 0, maxfn(100)),
		a: getset('lab', 1),
		b: getset('lab', 2),

		keyword(value) {
			if (arguments.length > 0) {
				return new Color(value);
			}

			return colorConvert[this.model].keyword(this.color);
		},

		hex(value) {
			if (arguments.length > 0) {
				return new Color(value);
			}

			return colorString.to.hex(this.rgb().round().color);
		},

		hexa(value) {
			if (arguments.length > 0) {
				return new Color(value);
			}

			const rgbArray = this.rgb().round().color;

			let alphaHex = Math.round(this.valpha * 255).toString(16).toUpperCase();
			if (alphaHex.length === 1) {
				alphaHex = '0' + alphaHex;
			}

			return colorString.to.hex(rgbArray) + alphaHex;
		},

		rgbNumber() {
			const rgb = this.rgb().color;
			return ((rgb[0] & 0xFF) << 16) | ((rgb[1] & 0xFF) << 8) | (rgb[2] & 0xFF);
		},

		luminosity() {
			// http://www.w3.org/TR/WCAG20/#relativeluminancedef
			const rgb = this.rgb().color;

			const lum = [];
			for (const [i, element] of rgb.entries()) {
				const chan = element / 255;
				lum[i] = (chan <= 0.039_28) ? chan / 12.92 : ((chan + 0.055) / 1.055) ** 2.4;
			}

			return 0.2126 * lum[0] + 0.7152 * lum[1] + 0.0722 * lum[2];
		},

		contrast(color2) {
			// http://www.w3.org/TR/WCAG20/#contrast-ratiodef
			const lum1 = this.luminosity();
			const lum2 = color2.luminosity();

			if (lum1 > lum2) {
				return (lum1 + 0.05) / (lum2 + 0.05);
			}

			return (lum2 + 0.05) / (lum1 + 0.05);
		},

		level(color2) {
			const contrastRatio = this.contrast(color2);
			if (contrastRatio >= 7.1) {
				return 'AAA';
			}

			return (contrastRatio >= 4.5) ? 'AA' : '';
		},

		isDark() {
			// YIQ equation from http://24ways.org/2010/calculating-color-contrast
			const rgb = this.rgb().color;
			const yiq = (rgb[0] * 299 + rgb[1] * 587 + rgb[2] * 114) / 1000;
			return yiq < 128;
		},

		isLight() {
			return !this.isDark();
		},

		negate() {
			const rgb = this.rgb();
			for (let i = 0; i < 3; i++) {
				rgb.color[i] = 255 - rgb.color[i];
			}

			return rgb;
		},

		lighten(ratio) {
			const hsl = this.hsl();
			hsl.color[2] += hsl.color[2] * ratio;
			return hsl;
		},

		darken(ratio) {
			const hsl = this.hsl();
			hsl.color[2] -= hsl.color[2] * ratio;
			return hsl;
		},

		saturate(ratio) {
			const hsl = this.hsl();
			hsl.color[1] += hsl.color[1] * ratio;
			return hsl;
		},

		desaturate(ratio) {
			const hsl = this.hsl();
			hsl.color[1] -= hsl.color[1] * ratio;
			return hsl;
		},

		whiten(ratio) {
			const hwb = this.hwb();
			hwb.color[1] += hwb.color[1] * ratio;
			return hwb;
		},

		blacken(ratio) {
			const hwb = this.hwb();
			hwb.color[2] += hwb.color[2] * ratio;
			return hwb;
		},

		grayscale() {
			// http://en.wikipedia.org/wiki/Grayscale#Converting_color_to_grayscale
			const rgb = this.rgb().color;
			const value = rgb[0] * 0.3 + rgb[1] * 0.59 + rgb[2] * 0.11;
			return Color.rgb(value, value, value);
		},

		fade(ratio) {
			return this.alpha(this.valpha - (this.valpha * ratio));
		},

		opaquer(ratio) {
			return this.alpha(this.valpha + (this.valpha * ratio));
		},

		rotate(degrees) {
			const hsl = this.hsl();
			let hue = hsl.color[0];
			hue = (hue + degrees) % 360;
			hue = hue < 0 ? 360 + hue : hue;
			hsl.color[0] = hue;
			return hsl;
		},

		mix(mixinColor, weight) {
			// Ported from sass implementation in C
			// https://github.com/sass/libsass/blob/0e6b4a2850092356aa3ece07c6b249f0221caced/functions.cpp#L209
			if (!mixinColor || !mixinColor.rgb) {
				throw new Error('Argument to "mix" was not a Color instance, but rather an instance of ' + typeof mixinColor);
			}

			const color1 = mixinColor.rgb();
			const color2 = this.rgb();
			const p = weight === undefined ? 0.5 : weight;

			const w = 2 * p - 1;
			const a = color1.alpha() - color2.alpha();

			const w1 = (((w * a === -1) ? w : (w + a) / (1 + w * a)) + 1) / 2;
			const w2 = 1 - w1;

			return Color.rgb(
				w1 * color1.red() + w2 * color2.red(),
				w1 * color1.green() + w2 * color2.green(),
				w1 * color1.blue() + w2 * color2.blue(),
				color1.alpha() * p + color2.alpha() * (1 - p));
		},
	};

	// Model conversion methods and static constructors
	for (const model of Object.keys(colorConvert)) {
		if (skippedModels.includes(model)) {
			continue;
		}

		const channels = colorConvert[model].channels;

		// Conversion methods
		Color.prototype[model] = function () {
			if (this.model === model) {
				return new Color(this);
			}

			if (arguments.length > 0) {
				return new Color(arguments, model);
			}

			const newAlpha = typeof arguments[channels] === 'number' ? channels : this.valpha;
			return new Color(assertArray(colorConvert[this.model][model].raw(this.color)).concat(newAlpha), model);
		};

		// 'static' construction methods
		Color[model] = function (color) {
			if (typeof color === 'number') {
				color = zeroArray(_slice.call(arguments), channels);
			}

			return new Color(color, model);
		};
	}

	function roundTo(number, places) {
		return Number(number.toFixed(places));
	}

	function roundToPlace(places) {
		return function (number) {
			return roundTo(number, places);
		};
	}

	function getset(model, channel, modifier) {
		model = Array.isArray(model) ? model : [model];

		for (const m of model) {
			(limiters[m] || (limiters[m] = []))[channel] = modifier;
		}

		model = model[0];

		return function (value) {
			let result;

			if (arguments.length > 0) {
				if (modifier) {
					value = modifier(value);
				}

				result = this[model]();
				result.color[channel] = value;
				return result;
			}

			result = this[model]().color[channel];
			if (modifier) {
				result = modifier(result);
			}

			return result;
		};
	}

	function maxfn(max) {
		return function (v) {
			return Math.max(0, Math.min(max, v));
		};
	}

	function assertArray(value) {
		return Array.isArray(value) ? value : [value];
	}

	function zeroArray(array, length) {
		for (let i = 0; i < length; i++) {
			if (typeof array[i] !== 'number') {
				array[i] = 0;
			}
		}

		return array;
	}

	var color = Color;

	function warn(str) {
	    console.error(`[k2] is error: ${str}`);
	}
	/**
	 * 将鼠标坐标转换为Canvas坐标
	 */
	function windowToCanvas(canvas, x, y) {
	    if (!canvas) {
	        warn('canvas is not supported');
	        return { x: 0, y: 0 };
	    }
	    // 获取canvas元素的边界框，该边界框的坐标是相对于整个窗口的
	    const bbox = canvas.getBoundingClientRect();
	    const width = canvas.width / window.devicePixelRatio, height = canvas.height / window.devicePixelRatio;
	    return {
	        x: x - bbox.left * (width / bbox.width),
	        y: y - bbox.top * (height / bbox.height),
	    };
	}
	function activeColor(color$1) {
	    const rgbColor = color(color$1).rgb();
	    const max = getMaxIndexAndVal(rgbColor.array());
	    const newRgbColor = rgbColor.array();
	    newRgbColor[max.idx] += 15;
	    return color.rgb(newRgbColor).hex();
	}
	function getMaxIndexAndVal(arr) {
	    let maxIdx = 0;
	    let maxVal = 0;
	    arr.forEach((item, index) => {
	        if (item > maxVal) {
	            maxVal = item;
	            maxIdx = index;
	        }
	    });
	    return {
	        idx: maxIdx,
	        val: maxVal,
	    };
	}
	function isNull(val) {
	    if (val === null)
	        return true;
	    return false;
	}
	function isUndefined(val) {
	    if (val === undefined)
	        return true;
	    return false;
	}
	function suffixTextSize() {
	    const width = window.screen.width, height = window.screen.height;
	    if (width <= 1152 && height <= 720)
	        return 5;
	    else if (width <= 1344 && height <= 840)
	        return 6;
	    else if (width <= 1536 && height <= 960)
	        return 7;
	    else if (width <= 1792 && height <= 1120)
	        return 8;
	    else
	        return 8;
	}

	class BaseDraw {
	    container;
	    canvas = document.createElement('canvas');
	    ctx = this.canvas.getContext('2d');
	    minHeight = 350;
	    minWidth = 600;
	    width = 0;
	    height = 0;
	    widthRadio = 0;
	    heightRadio = 0;
	    centerPtx = 0;
	    centerPty = 0;
	    textSize = 0;
	    constructor(container) {
	        this.container = container;
	        this._initRenderer();
	        this._initSize();
	        // this._initRadius();
	        // const config = {
	        //   width,
	        //   height,
	        //   widthRadio: parseFloat((canvas.width / this.minWidth).toFixed(2)),
	        //   heightRadio: parseFloat((canvas.height / this.minHeight).toFixed(2)),
	        //   centerPtx: canvas.width / 2,
	        //   centerPty: 0,
	        // }
	        // config.centerPty = canvas.height / 2 + 130 * config.heightRadio;
	        // return config;
	    }
	    // _reRender() {
	    //   this._initSize();
	    //   this._initRadius();
	    // }
	    _initRenderer() {
	        this.container.appendChild(this.canvas);
	    }
	    _initSize() {
	        const container = this.container, canvas = this.canvas;
	        if (!container)
	            return;
	        let width = container.clientWidth + 2;
	        let height = container.clientHeight + 2;
	        // console.log('width: ', width);
	        // console.log('height: ', height);
	        // // if (width < this.minWidth || height < this.minHeight) {
	        // //   width = this.minWidth;
	        // //   height = this.minHeight;
	        // // }
	        if (window.devicePixelRatio) {
	            // console.log('window.devicePixelRatio: ', window.devicePixelRatio);
	            const devicePixelRatio = window.devicePixelRatio;
	            canvas.style.width = width + "px";
	            canvas.style.height = height + "px";
	            canvas.height = height * devicePixelRatio;
	            canvas.width = width * devicePixelRatio;
	        }
	        else {
	            canvas.style.width = width + "px";
	            canvas.style.height = height + "px";
	            canvas.width = width;
	            canvas.height = height;
	        }
	        this.ctx?.scale(devicePixelRatio, devicePixelRatio);
	        // options
	        this.width = width;
	        this.height = height;
	        this.widthRadio = parseFloat((width / this.minWidth).toFixed(2));
	        this.heightRadio = parseFloat((height / this.minHeight).toFixed(2));
	        this.centerPtx = width / 2;
	        this.centerPty = height / 2 + 60 * this.heightRadio;
	    }
	    /**
	     * ================ draw arc ===============
	     */
	    // 绘制圆弧（实心）
	    drawFillArc({ x, y, color, radius, startAngle = 0, endAngle = Math.PI, clockwise = false, }) {
	        if (radius < 1)
	            warn('半径太小');
	        const ctx = this.ctx;
	        if (!ctx)
	            return;
	        if (startAngle === -endAngle)
	            return;
	        ctx.fillStyle = color;
	        // 开始一条新路径
	        ctx.beginPath();
	        // 移动到圆心
	        ctx.moveTo(x, y);
	        // 绘制圆弧
	        ctx.arc(x, y, radius, startAngle, endAngle, clockwise);
	        // 闭合路径
	        ctx.closePath();
	        ctx.fill();
	    }
	    /**
	     * ================ draw text ===============
	     */
	    drawTitle({ text, x, y, }) {
	        const ctx = this.ctx;
	        if (!ctx)
	            return;
	        if (!text)
	            return;
	        setTextCenter(ctx);
	        ctx.font = '900 14pt impact ';
	        ctx.fillStyle = '#000';
	        ctx.fillText(text, x, y);
	    }
	    drawLabel({ text, x, y, }) {
	        const ctx = this.ctx;
	        if (!ctx)
	            return;
	        if (text === undefined || text === null)
	            return;
	        let textVal = '';
	        if (typeof text === 'number')
	            textVal = text.toString();
	        else if (typeof text === 'string')
	            textVal = text;
	        else if (typeof text.label === 'string')
	            textVal = text.label;
	        setTextCenter(ctx);
	        ctx.font = '8pt Arial';
	        ctx.fillStyle = '#000';
	        ctx.fillText(textVal, x, y);
	    }
	    drawBoldText({ text, x, y, }) {
	        const ctx = this.ctx;
	        if (!ctx)
	            return;
	        if (!text)
	            return;
	        setTextCenter(ctx);
	        ctx.font = '12pt Arial';
	        ctx.fillStyle = '#000';
	        ctx.fillText(text, x, y);
	    }
	    // 绘制文字注释
	    drawSuffixText({ text, x, y, }) {
	        const ctx = this.ctx;
	        if (!ctx)
	            return;
	        if (!text)
	            return;
	        setTextCenter(ctx);
	        const size = suffixTextSize();
	        ctx.font = `${size}pt Arial`;
	        ctx.fillStyle = '#bab5b5';
	        ctx.fillText(text, x, y);
	    }
	    /**
	     * ================ draw rect ===============
	     */
	    drawColorRect({ color, x, y, text, }) {
	        const ctx = this.ctx;
	        if (!ctx)
	            return warn('ctx is not supported');
	        const w = 40, h = 20;
	        this.drawRoundRect({
	            color,
	            bgColor: color,
	            x,
	            y,
	            w,
	            h,
	        });
	        // draw text
	        if (text === undefined || text === null)
	            return;
	        let textVal = '';
	        if (typeof text === 'number')
	            textVal = text.toString();
	        else if (typeof text === 'string')
	            textVal = text;
	        setTextCenter(ctx);
	        ctx.font = '500 8pt italic xx-large palatino';
	        ctx.fillStyle = '#fff';
	        ctx.fillText(textVal, x + 40 / 2, y + 20 / 2);
	    }
	    drawRoundRect({ color, bgColor = '#fff', x, y, w, h, r = 4 }) {
	        const ctx = this.ctx;
	        if (!ctx)
	            return warn('ctx is not supported');
	        if (w < 2 * r) {
	            r = w / 2;
	        }
	        if (h < 2 * r) {
	            r = h / 2;
	        }
	        // ctx.lineJoin = 'round';
	        ctx.strokeStyle = color;
	        ctx.fillStyle = bgColor;
	        ctx.beginPath();
	        ctx.moveTo(x + r, y);
	        ctx.arcTo(x + w, y, x + w, y + h, r);
	        ctx.arcTo(x + w, y + h, x, y + h, r);
	        ctx.arcTo(x, y + h, x, y, r);
	        ctx.arcTo(x, y, x + w, y, r);
	        ctx.closePath();
	        ctx.stroke();
	        ctx.fill();
	    }
	    drawTooltip({ color, text, x, y, }) {
	        const ctx = this.ctx;
	        if (!ctx)
	            return warn('ctx is not supported');
	        const w = text.length * 13, h = 36;
	        // draw rect
	        this.drawRoundRect({
	            color,
	            x,
	            y,
	            w,
	            h,
	        });
	        // draw text
	        setTextCenter(ctx);
	        // ctx.font = '300 10pt italic xx-large palatino';
	        ctx.font = '349 10pt century';
	        ctx.fillStyle = '#000';
	        ctx.fillText(text, x + w / 2, y + h / 2);
	    }
	}
	function setTextCenter(ctx) {
	    ctx.textAlign = 'center';
	    ctx.textBaseline = 'middle';
	}

	// 标量积（点乘）
	function dot(A, B) {
	    return A.x * B.x + A.y * B.y;
	}
	// 矢量积（叉乘）方向，1 则为与 z 轴正方向相同，-1 则为相反
	function $cross(A, B) {
	    return Math.sign(A.x * B.y - A.y * B.x);
	}
	// 矢量积（叉乘）的模
	function _cross(A, B) {
	    return Math.abs(A.x * B.y - A.y * B.x);
	}
	// 矢量的模
	function _(A) {
	    return Math.hypot(A.x, A.y);
	}
	// 由模和方向求矢量
	function polarToVector(magnitude, direction) {
	    const x = magnitude * Math.cos(direction);
	    const y = magnitude * Math.sin(direction);
	    return normalPt({ x, y });
	}
	// 将坐标转换成坐标系下的坐标
	function movePtToCoordinate(centerPt, movePt) {
	    const coordinatePt = { x: 0, y: 0 };
	    coordinatePt.x = movePt.x - centerPt.x;
	    coordinatePt.y = centerPt.y - movePt.y;
	    return coordinatePt;
	}
	function normalPt(pt) {
	    let x = 0, y = 0;
	    if (pt.x < -0.0001 || pt.x > 0.0001)
	        x = pt.x;
	    if (pt.y < -0.0001 || pt.y > 0.0001)
	        y = pt.y;
	    return {
	        x,
	        y,
	    };
	}
	function isScannable(center, movePt, alpha) {
	    const coordinatePt = movePtToCoordinate(center, movePt);
	    // 如果 α>2π，360°全覆盖，肯定能扫描到
	    if (alpha >= Math.PI * 2)
	        return true;
	    // 如果 α<0，当前仅当点 P 与原点重合（即 P 的模为 0）时才能扫描到
	    if (alpha < 0)
	        return _(movePt) === 0;
	    // 把一四象限里的边上从原点出发的向量定为 A
	    //  二三象限里的定为 B（如果 α=0，虽然二者不在象限里，不过此时方向一致，无所谓了）
	    const A = polarToVector(1, alpha);
	    const B = polarToVector(1, Math.PI);
	    const AxP = $cross(A, coordinatePt);
	    const PxB = $cross(coordinatePt, B);
	    // 如果 |AxP|=0 或 |PxB|=0，说明 P 与 A 或 B 方向一致，刚好在边缘上，能扫描到
	    if (AxP * PxB === 0)
	        return true;
	    // 如果 α>π，可以假设坐标系上下翻转，有一个视角为 2π-α 的扫描器在扫描 P 关于 x 轴的映射 P'，如果 P' 能被扫描到，说明 P 扫描不到，反之亦然
	    // if (alpha > Math.PI) return !isScannable({ x: movePt.x, y: -movePt.y }, Math.PI * 2 - alpha);
	    // 如果要扫描到，必须要让从 A 到 B 逆时针扫描时经过 P，即 AxP 和 PxB 的方向都要与 z 轴正方向一致
	    return AxP > 0 && PxB > 0;
	}
	var algo = {
	    // 标量积（点乘）
	    dot,
	    // 矢量积（叉乘）方向，1 则为与 z 轴正方向相同，-1 则为相反
	    $cross,
	    // 矢量积（叉乘）的模
	    _cross,
	    // 矢量的模
	    _,
	    // 由模和方向求矢量
	    polarToVector,
	    // 将坐标转换成坐标系下的坐标
	    movePtToCoordinate,
	    isScannable,
	};

	class DashBoard extends BaseDraw {
	    options;
	    leftAngle = 0;
	    color = ''; // 绘制的颜色
	    value = ''; // 值
	    stepRadio = 0; // 动画递增比例
	    curDrawRadio = 0; // 当前绘制比例
	    resultRadio = 0; // 绘制比例
	    drawFinish = false; // 是否绘制
	    maxRadius = 0;
	    maxRadius2 = 0;
	    dashWidth = 0;
	    minRadius2 = 0;
	    firstMove = true;
	    maxMoveRadius = 5; // 选择时，绘制长度增加量
	    drawingSurfaceImageData = undefined;
	    constructor(options) {
	        super(options.el);
	        this.options = options;
	        this._initRadius();
	        this._calcDashBoardParams();
	    }
	    render() {
	        this._drawDashBoard();
	        this.ctx?.canvas?.addEventListener('mousemove', this.bindMouseMove);
	    }
	    setValue(value) {
	        if (isNull(value) || isUndefined(value))
	            return warn('value is undefined');
	        if (value > this.options.attr.max)
	            return warn('value is bigger than max value');
	        if (value < this.options.attr.min)
	            return warn('value is less than max value');
	        this.options.value = value;
	        this.curDrawRadio = 0;
	        this._calcDashBoardParams();
	        this._drawDashBoard();
	    }
	    resize() {
	        this._initSize();
	        this._initRadius();
	        this._calcDashBoardParams();
	        this._drawDashBoard();
	    }
	    async clear() {
	        if (!this.ctx)
	            return warn('ctx is not supported');
	        await this.ctx.clearRect(0, 0, this.width, this.height);
	    }
	    destroy() {
	        this.ctx?.canvas?.removeEventListener('mousemove', this.bindMouseMove);
	    }
	    /**
	     * =============== 鼠标移动 ===============
	     */
	    bindMouseMove = (ev) => {
	        if (!this.drawFinish)
	            return; // 没画完，不进行操作
	        if (!this.ctx)
	            return warn('ctx is not supported!!!');
	        let loc = windowToCanvas(this.ctx?.canvas, ev.clientX, ev.clientY);
	        const centerPt = {
	            x: this.centerPtx,
	            y: this.centerPty,
	        };
	        if (isInBoard(centerPt, loc, this.minRadius2, this.maxRadius2, this.leftAngle)) {
	            document.body.style.setProperty('cursor', 'pointer');
	            if (this.firstMove) {
	                this.firstMove = false;
	                this.drawActiveBoard();
	                this.saveDrawingSurface(); // 解决绘制tooltip的问题
	            }
	            else {
	                this.restoreDrawingSurface(); // 解决绘制tooltip的问题
	                this.drawTooltipRect(loc);
	            }
	        }
	        else {
	            document.body.style.setProperty('cursor', 'auto');
	            if (!this.firstMove) {
	                this._drawDashBoard();
	                this.firstMove = true;
	            }
	        }
	    };
	    drawActiveBoard = () => {
	        if (!this.ctx)
	            return warn('ctx is not supported');
	        const leftAngle = calcDashBoardPercent(this.curDrawRadio);
	        this.clear();
	        // 大圈
	        this.drawFillArc({
	            color: activeColor(this.color),
	            x: this.centerPtx,
	            y: this.centerPty,
	            radius: this.maxRadius + this.maxMoveRadius,
	            startAngle: -leftAngle,
	            endAngle: Math.PI,
	            clockwise: true,
	        });
	        this._commonDrawBoard();
	    };
	    /**
	     * 计算仪表盘参数
	     */
	    _calcDashBoardParams() {
	        const { attr, value } = this.options;
	        const { stops, min, max } = attr;
	        let minVal = 0, maxVal = 0;
	        if (typeof min === 'number')
	            minVal = min;
	        else if (typeof min.value === 'number')
	            minVal = min.value;
	        if (typeof max === 'number')
	            maxVal = max;
	        else if (typeof max.value === 'number')
	            maxVal = max.value;
	        const dist = maxVal - minVal;
	        // dist += (dist * 0.02)
	        const radio = this.resultRadio = parseFloat((value / dist).toFixed(3));
	        const findItem = stops.find(item => radio <= parseFloat(item[0]));
	        this.stepRadio = parseFloat((radio / 40).toFixed(5));
	        if (findItem && findItem.length > 2)
	            this.value = findItem[2];
	        this.color = findItem?.[1] || 'black';
	    }
	    _drawDashBoard = () => {
	        if (!this.ctx)
	            return warn('ctx is not supported');
	        const leftAngle = calcDashBoardPercent(this.curDrawRadio);
	        this.leftAngle = leftAngle;
	        this.clear();
	        // 大圈
	        this.drawFillArc({
	            x: this.centerPtx,
	            y: this.centerPty,
	            color: this.color,
	            radius: this.maxRadius,
	            startAngle: -leftAngle,
	            endAngle: Math.PI,
	            clockwise: true,
	        });
	        this._commonDrawBoard();
	        // @ts-ignore
	        const raf = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame;
	        if (this.curDrawRadio < this.resultRadio) {
	            this.curDrawRadio += this.stepRadio;
	            // 防止超过最大值
	            if (this.curDrawRadio > this.resultRadio)
	                this.curDrawRadio = this.resultRadio;
	            raf(this._drawDashBoard);
	        }
	        else {
	            this.drawFinish = true;
	        }
	    };
	    _commonDrawBoard = () => {
	        if (!this.ctx)
	            return warn('ctx is not supported');
	        const attr = this.options.attr;
	        // 右侧大圈
	        this.drawFillArc({
	            x: this.centerPtx,
	            y: this.centerPty,
	            color: '#dcd9d9',
	            startAngle: 0,
	            endAngle: -this.leftAngle,
	            radius: this.maxRadius,
	            clockwise: true,
	        });
	        // 小圈
	        this.drawFillArc({
	            x: this.centerPtx + 2,
	            y: this.centerPty + 2,
	            color: '#fff',
	            radius: this.maxRadius - this.dashWidth + 2,
	            clockwise: true,
	        });
	        this.drawTitle({
	            text: attr.title,
	            x: this.centerPtx,
	            y: this.centerPty - 350 * this.heightRadio,
	        });
	        // 绘制label
	        this.drawLabel({
	            ctx: this.ctx,
	            text: attr.min,
	            x: this.centerPtx - this.maxRadius + this.dashWidth / 2,
	            y: this.centerPty + 10 * this.heightRadio,
	        });
	        // 绘制label
	        this.drawLabel({
	            ctx: this.ctx,
	            text: attr.max,
	            x: this.centerPtx + this.maxRadius - this.dashWidth / 2,
	            y: this.centerPty + 10 * this.heightRadio,
	        });
	        // 绘制文字
	        this.drawBoldText({
	            x: this.centerPtx,
	            y: this.centerPty - 10 * this.heightRadio,
	            text: this.value,
	        });
	        this.drawSuffixText({
	            x: this.centerPtx,
	            y: this.centerPty + 14 * this.heightRadio,
	            text: attr?.tooltip?.valueSuffix,
	        });
	        if (attr.showColorsBoard) {
	            this.drawColorsBoard();
	        }
	    };
	    _initRadius() {
	        // 从底部开始计算
	        // 只计算宽
	        this.maxRadius = this.width / 2 - 140 * this.widthRadio;
	        this.dashWidth = Math.abs(this.maxRadius - 80 * this.widthRadio);
	        // if (this.width < this.height) {
	        // } else {
	        // this.maxRadius = this.height - 200 * this.heightRadio;
	        // this.dashWidth = Math.abs(this.maxRadius - 60 * this.heightRadio)
	        // }
	        this.maxRadius2 = Math.pow(this.maxRadius, 2);
	        this.minRadius2 = Math.pow(this.maxRadius - this.dashWidth, 2);
	    }
	    drawColorsBoard() {
	        if (!this.ctx)
	            return warn('ctx is not supported');
	        const attr = this.options.attr;
	        // todo: 现在的startX是默认值，只支持5个颜色板
	        let startX = -120;
	        attr.stops.forEach(stop => {
	            this.drawColorRect({
	                color: stop[1],
	                x: this.centerPtx + startX,
	                y: this.centerPty + 50,
	                text: stop[2],
	            });
	            startX += 50;
	        });
	    }
	    drawTooltipRect = (loc) => {
	        if (!this.ctx)
	            return warn('ctx is not supported!!!');
	        const nX = loc.x + 20;
	        const nY = loc.y + 20;
	        let tooltipVal = '';
	        if (this.options.attr.title) {
	            tooltipVal += this.options.attr.title + ': ';
	        }
	        if (this.options.value) {
	            tooltipVal += this.options.value;
	        }
	        // drawFillRect({
	        //   ctx: this.ctx,
	        //   color: this.color,
	        //   x: nX,
	        //   y: nY,
	        //   textLen: tooltipVal.length,
	        // })
	        // 绘制label
	        this.drawTooltip({
	            color: this.color,
	            text: tooltipVal,
	            x: nX,
	            y: nY,
	        });
	    };
	    saveDrawingSurface() {
	        if (window.devicePixelRatio) {
	            this.drawingSurfaceImageData = this.ctx?.getImageData(0, 0, this.width * window.devicePixelRatio, this.height * window.devicePixelRatio);
	        }
	        else {
	            this.drawingSurfaceImageData = this.ctx?.getImageData(0, 0, this.width, this.height);
	        }
	    }
	    restoreDrawingSurface() {
	        if (this.drawingSurfaceImageData)
	            this.ctx?.putImageData(this.drawingSurfaceImageData, 0, 0);
	        else {
	            warn('没有保存图片');
	        }
	    }
	}
	function calcDashBoardPercent(stepRadio) {
	    const rightAngle = Math.PI * stepRadio;
	    const leftAngle = Math.PI - rightAngle;
	    return leftAngle;
	}
	function isInBoard(centerPt, movePt, minRadius2, maxRadius2, leftAngle) {
	    // if (Math.pow(movePt.x - centerPt.x, 2) + Math.pow(movePt.y - centerPt.y, 2) < maxRadius2) {
	    //   console.log('小于大圈');
	    // }
	    // if (Math.pow(movePt.x - centerPt.x, 2) + Math.pow(movePt.y - centerPt.y, 2) > minRadius2) {
	    //   console.log('大于小圈');
	    // }
	    // console.log('pt: ', pt);
	    // console.log('movePt: ', movePt);
	    // console.log('centerPt: ', centerPt);
	    // console.log('minRadius2: ', minRadius2);
	    // console.log('maxRadius2: ', maxRadius2);
	    if (Math.pow(movePt.x - centerPt.x, 2) + Math.pow(movePt.y - centerPt.y, 2) < maxRadius2 &&
	        Math.pow(movePt.x - centerPt.x, 2) + Math.pow(movePt.y - centerPt.y, 2) > minRadius2 &&
	        algo.isScannable(centerPt, movePt, leftAngle)) {
	        return true;
	    }
	    return false;
	}

	// import './animate';
	var index = {
	    DashBoard
	};

	return index;

}));
