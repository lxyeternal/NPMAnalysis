export interface ICoordinates {
    x: number;
    y: number;
    z: number;
}
export interface IOptions {
    element: HTMLElement;
    minZoom?: number;
    maxZoom?: number;
    captureWheel?: boolean;
}
export type UpdateValue = Partial<Readonly<ICoordinates>> | ((prev: Readonly<ICoordinates>) => Partial<Readonly<ICoordinates>>);
export interface ICanvas {
    update: ((value: UpdateValue) => void);
    reset: VoidFunction;
    destroy: VoidFunction;
}
export declare function create({ element, minZoom, maxZoom, captureWheel, }: Readonly<IOptions>): Readonly<ICanvas>;
