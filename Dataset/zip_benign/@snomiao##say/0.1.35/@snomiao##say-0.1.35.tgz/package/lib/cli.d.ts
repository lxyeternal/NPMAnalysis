export default cli;
export declare function cli(args: string[]): Promise<void>;
