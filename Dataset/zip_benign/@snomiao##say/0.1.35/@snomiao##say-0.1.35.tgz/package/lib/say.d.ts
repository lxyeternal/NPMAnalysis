export declare const speak: (
  text: string,
  voice?: string | undefined,
  speed?: number | undefined,
) => Promise<void>;
export declare const stop: () => Promise<void>;
export declare const getInstalledVoices: () => Promise<string[]>;
export declare const exportFile: (
  text: string,
  voice?: string | undefined,
  speed?: number | undefined,
  filePath?: string | undefined,
) => Promise<void>;
