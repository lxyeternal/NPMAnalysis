"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const __1 = require("../..");
let WildcardController = class WildcardController extends __1.BaseController {
    static async get(req, res) {
        if (req.url === "/path/to/some/wildcard/endpoint/with/wild/card" && req.params["*"] === "wild/card") {
            res.status(200).send();
        }
        else {
            res.status(500).send();
        }
    }
};
WildcardController = __decorate([
    (0, __1.lambdaroute)()
], WildcardController);
exports.default = WildcardController;
//# sourceMappingURL=WildcardController.js.map