"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const __1 = require("../..");
const middleware_1 = require("../../../middleware");
const skipProcess = (statusCode) => (0, middleware_1.middleware)((req, res, next) => {
    res.status(statusCode).send();
    return;
});
let WildcardController = class WildcardController extends __1.BaseController {
    static async get(req, res) {
        res.status(500).send();
    }
};
__decorate([
    skipProcess(200),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], WildcardController, "get", null);
WildcardController = __decorate([
    (0, __1.lambdaroute)()
], WildcardController);
exports.default = WildcardController;
//# sourceMappingURL=MiddlewareController.js.map