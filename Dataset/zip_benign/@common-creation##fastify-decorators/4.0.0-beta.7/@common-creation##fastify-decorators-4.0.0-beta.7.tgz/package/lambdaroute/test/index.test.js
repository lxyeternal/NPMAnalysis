"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fastify_1 = __importDefault(require("fastify"));
const __1 = require("..");
const testCases = {
    root: {
        url: "/",
        injectUrl: "/",
        expects: [
            {
                method: "GET",
                status: 410,
            },
            {
                method: "POST",
                status: 411,
            },
            {
                method: "PUT",
                status: 412,
            },
            {
                method: "PATCH",
                status: 413,
            },
            {
                method: "DELETE",
                status: 414,
            },
            {
                method: "HEAD",
                status: 415,
            },
        ],
    },
    some: {
        url: "/path/to/some/endpoint",
        injectUrl: "/path/to/some/endpoint",
        expects: [
            {
                method: "GET",
                status: 510,
            },
            {
                method: "POST",
                status: 511,
            },
            {
                method: "PUT",
                status: 512,
            },
            {
                method: "PATCH",
                status: 513,
            },
            {
                method: "DELETE",
                status: 514,
            },
            {
                method: "HEAD",
                status: 515,
            },
        ],
    },
    params: {
        url: "/path/to/some/endpoint/with/:params",
        injectUrl: "/path/to/some/endpoint/with/param1",
        expects: [
            {
                method: "GET",
                status: 200,
            },
        ],
    },
    wildcard: {
        url: "/path/to/some/wildcard/endpoint/with/*",
        injectUrl: "/path/to/some/wildcard/endpoint/with/wild/card",
        expects: [
            {
                method: "GET",
                status: 200,
            },
        ],
    },
    middleware: {
        url: "/path/to/middleware",
        injectUrl: "/path/to/middleware",
        expects: [
            {
                method: "GET",
                status: 200,
            },
        ],
    },
    invalid: {
        url: "/path/to/invalid/endpoint",
        injectUrl: "/path/to/invalid/endpoint",
        expects: [
            {
                method: "GET",
                status: 404,
            },
            {
                method: "POST",
                status: 404,
            },
            {
                method: "PUT",
                status: 404,
            },
            {
                method: "PATCH",
                status: 404,
            },
            {
                method: "DELETE",
                status: 404,
            },
            {
                method: "HEAD",
                status: 404,
            },
        ],
    },
};
describe("route", () => {
    describe("route without prefix", () => {
        const fastify = (0, fastify_1.default)({
            exposeHeadRoutes: false,
        });
        const controllers = {
            [testCases.root.url]: () => Promise.resolve().then(() => __importStar(require("./controllers/RootController"))),
            [testCases.some.url]: () => Promise.resolve().then(() => __importStar(require("./controllers/SomeController"))),
            [testCases.wildcard.url]: () => Promise.resolve().then(() => __importStar(require("./controllers/WildcardController"))),
            [testCases.middleware.url]: () => Promise.resolve().then(() => __importStar(require("./controllers/MiddlewareController"))),
            [testCases.params.url]: () => Promise.resolve().then(() => __importStar(require("./controllers/ParamsController"))),
        };
        __1.LambdaController.inject(fastify, controllers);
        for (const targetCaseKeys of Object.keys(testCases)) {
            const targetCase = testCases[targetCaseKeys];
            const { url, injectUrl } = targetCase;
            for (const testCase of targetCase.expects) {
                test(`${testCase.method} ${url} <- ${injectUrl}`, async () => {
                    const response = await fastify.inject({
                        url: injectUrl,
                        method: testCase.method,
                    });
                    if (response.statusCode !== testCase.status) {
                        console.log(response.body);
                    }
                    expect(response.statusCode).toBe(testCase.status);
                });
            }
        }
    });
});
//# sourceMappingURL=index.test.js.map