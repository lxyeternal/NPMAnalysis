import type { FastifyReply, FastifyRequest } from "fastify";
import { BaseController } from "../..";
export default class SomeController extends BaseController {
    static get(req: FastifyRequest<{
        Params: {
            "params": string;
        };
    }>, res: FastifyReply): Promise<void>;
}
//# sourceMappingURL=ParamsController.d.ts.map