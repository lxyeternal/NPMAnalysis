"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const __1 = require("../..");
let SomeController = class SomeController extends __1.BaseController {
    static async get(req, res) {
        if (req.params.params === "param1") {
            res.status(200).send();
        }
        else {
            res.status(500).send();
        }
    }
};
SomeController = __decorate([
    (0, __1.lambdaroute)()
], SomeController);
exports.default = SomeController;
//# sourceMappingURL=ParamsController.js.map