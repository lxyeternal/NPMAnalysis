"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
const __1 = require("../..");
let RootController = class RootController extends __1.BaseController {
    static async get(req, res) {
        res.status(410).send();
    }
    static async post(req, res) {
        res.status(411).send();
    }
    static async put(req, res) {
        res.status(412).send();
    }
    static async patch(req, res) {
        res.status(413).send();
    }
    static async delete(req, res) {
        res.status(414).send();
    }
    static async head(req, res) {
        res.status(415).send();
    }
};
RootController = __decorate([
    (0, __1.lambdaroute)()
], RootController);
exports.default = RootController;
//# sourceMappingURL=RootController.js.map