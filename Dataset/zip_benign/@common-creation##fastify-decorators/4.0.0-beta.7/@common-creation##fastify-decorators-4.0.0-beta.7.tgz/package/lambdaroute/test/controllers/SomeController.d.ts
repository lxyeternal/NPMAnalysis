import type { FastifyReply, FastifyRequest } from "fastify";
import { BaseController } from "../..";
export default class SomeController extends BaseController {
    static get(req: FastifyRequest, res: FastifyReply): Promise<void>;
    static post(req: FastifyRequest, res: FastifyReply): Promise<void>;
    static put(req: FastifyRequest, res: FastifyReply): Promise<void>;
    static patch(req: FastifyRequest, res: FastifyReply): Promise<void>;
    static delete(req: FastifyRequest, res: FastifyReply): Promise<void>;
    static head(req: FastifyRequest, res: FastifyReply): Promise<void>;
}
//# sourceMappingURL=SomeController.d.ts.map