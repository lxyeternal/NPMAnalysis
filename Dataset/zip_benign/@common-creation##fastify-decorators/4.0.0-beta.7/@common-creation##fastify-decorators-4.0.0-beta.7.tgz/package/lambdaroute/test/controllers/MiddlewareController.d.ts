import type { FastifyReply, FastifyRequest } from "fastify";
import { BaseController } from "../..";
export default class WildcardController extends BaseController {
    static get(req: FastifyRequest<{
        Params: {
            "*": string;
        };
    }>, res: FastifyReply): Promise<void>;
}
//# sourceMappingURL=MiddlewareController.d.ts.map