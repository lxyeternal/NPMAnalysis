import type { FastifyInstance, HTTPMethods } from "fastify";
export declare function lambdaroute(): (target: any) => any;
export interface IBaseController {
    call(method: HTTPMethods): void;
}
export declare class BaseController {
    static call(method: HTTPMethods): void;
}
export declare type RouteInfo = {
    [path: string]: () => Promise<{
        default: IBaseController;
    }>;
};
export declare class LambdaController {
    private server;
    private finder;
    private router;
    private routes;
    static inject(server: FastifyInstance, routes: RouteInfo): void;
    private constructor();
    private registerCatchAll;
    private registerRoutes;
    private finderHandler;
    private wrapHandler;
    private sendError;
}
//# sourceMappingURL=index.d.ts.map