"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LambdaController = exports.BaseController = exports.lambdaroute = void 0;
const find_my_way_1 = __importDefault(require("find-my-way"));
function lambdaroute() {
    return (target) => {
        return class extends target {
            static call(method) {
                return target[method.toLowerCase()];
            }
        };
    };
}
exports.lambdaroute = lambdaroute;
class BaseController {
    static call(method) {
    }
}
exports.BaseController = BaseController;
class LambdaController {
    server;
    finder;
    router;
    routes;
    static inject(server, routes) {
        new LambdaController(server, routes);
    }
    constructor(server, routes) {
        this.server = server;
        this.routes = routes;
        this.finder = (0, find_my_way_1.default)();
        this.router = (0, find_my_way_1.default)();
        this.registerRoutes();
        this.registerCatchAll();
    }
    registerCatchAll() {
        this.server.route({
            method: ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"],
            url: "/*",
            handler: async (request, reply) => {
                const path = (Array.isArray(request.headers[":path"]) ? request.headers[":path"][0] : request.headers[":path"]) || request.raw.url?.split("?")[0] || "";
                const route = this.finder.find("GET", path);
                if (!route) {
                    this.sendError(request, reply, `Route ${request.method}:${request.url} not found in LambdaController`);
                    return;
                }
                const dummyIncomingMessage = { url: path, method: "GET" };
                route.handler(dummyIncomingMessage, {}, {}, {}, {});
                if (!this.router.find(request.method, dummyIncomingMessage.url)) {
                    const routeInfo = this.routes[dummyIncomingMessage.url];
                    const controller = (await routeInfo()).default;
                    const handler = controller[request.method.toLowerCase()];
                    if (handler) {
                        this.router.on(request.method, dummyIncomingMessage.url, this.wrapHandler(handler));
                    }
                }
                this.router.lookup(request, reply);
                return reply;
            },
        });
    }
    registerRoutes() {
        const paths = Object.keys(this.routes);
        for (const path of paths) {
            this.finder.on("GET", path, this.finderHandler(path));
        }
    }
    finderHandler(path) {
        return (request, reply, params) => {
            request.url = path;
        };
    }
    wrapHandler(handler) {
        return (request, reply, params) => {
            request.params = params;
            return handler(request, reply);
        };
    }
    sendError(request, reply, message) {
        if (request.method !== "HEAD") {
            reply.status(404).send({
                message,
                error: "Not Found",
                statusCode: 404
            });
            return;
        }
        reply.status(404).send();
    }
}
exports.LambdaController = LambdaController;
//# sourceMappingURL=index.js.map