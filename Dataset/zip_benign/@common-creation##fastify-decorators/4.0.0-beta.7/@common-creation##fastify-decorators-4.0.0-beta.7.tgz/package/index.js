"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.route = exports.setPrefix = exports.registerRoutes = exports.BaseController = exports.middleware = void 0;
var middleware_1 = require("./middleware");
Object.defineProperty(exports, "middleware", { enumerable: true, get: function () { return middleware_1.middleware; } });
var route_1 = require("./route");
Object.defineProperty(exports, "BaseController", { enumerable: true, get: function () { return route_1.BaseController; } });
Object.defineProperty(exports, "registerRoutes", { enumerable: true, get: function () { return route_1.registerRoutes; } });
Object.defineProperty(exports, "setPrefix", { enumerable: true, get: function () { return route_1.setPrefix; } });
Object.defineProperty(exports, "route", { enumerable: true, get: function () { return route_1.route; } });
//# sourceMappingURL=index.js.map