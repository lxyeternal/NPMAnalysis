import type { FastifyInstance } from "fastify";
/**
 * @deprecated use registerRoutes params.
 */
export declare function setPrefix(prefix: string): void;
export declare function route(path: string): (target: any) => any;
export interface IBaseController {
    register(server: FastifyInstance, opts: any, next: () => void): void;
}
export declare class BaseController {
    static register(server: FastifyInstance, opts: any, next: () => void): void;
}
export declare function registerRoutes(server: FastifyInstance, routes: IBaseController[], prefix?: string): void;
//# sourceMappingURL=index.d.ts.map