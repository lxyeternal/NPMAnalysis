"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerRoutes = exports.BaseController = exports.route = exports.setPrefix = void 0;
const path_1 = __importDefault(require("path"));
let _prefix = "";
/**
 * @deprecated use registerRoutes params.
 */
function setPrefix(prefix) {
    _prefix = prefix || "";
}
exports.setPrefix = setPrefix;
function route(path) {
    return (target) => {
        return class extends target {
            static register(server, opts, next) {
                const internalPrefix = opts.internalPrefix || _prefix;
                const normalizedPath = path_1.default.posix.join("/", internalPrefix, path);
                if (target.get) {
                    server.log.trace({ method: "GET", path: normalizedPath, func: `${target.name}.get` }, "register route");
                    server.get(normalizedPath, target.get);
                }
                if (target.post) {
                    server.log.trace({ method: "POST", path: normalizedPath, func: `${target.name}.post` }, "register route");
                    server.post(normalizedPath, target.post);
                }
                if (target.put) {
                    server.log.trace({ method: "PUT", path: normalizedPath, func: `${target.name}.put` }, "register route");
                    server.put(normalizedPath, target.put);
                }
                if (target.delete) {
                    server.log.trace({ method: "DELETE", path: normalizedPath, func: `${target.name}.delete` }, "register route");
                    server.delete(normalizedPath, target.delete);
                }
                if (target.head) {
                    server.log.trace({ method: "HEAD", path: normalizedPath, func: `${target.name}.head` }, "register route");
                    server.head(normalizedPath, target.head);
                }
                if (target.patch) {
                    server.log.trace({ method: "PATCH", path: normalizedPath, func: `${target.name}.patch` }, "register route");
                    server.patch(normalizedPath, target.patch);
                }
                next();
            }
        };
    };
}
exports.route = route;
class BaseController {
    static register(server, opts, next) {
        next();
    }
}
exports.BaseController = BaseController;
function registerRoutes(server, routes, prefix) {
    routes.forEach((route) => {
        server.register(route.register, {
            internalPrefix: prefix || "",
        });
    });
}
exports.registerRoutes = registerRoutes;
//# sourceMappingURL=index.js.map