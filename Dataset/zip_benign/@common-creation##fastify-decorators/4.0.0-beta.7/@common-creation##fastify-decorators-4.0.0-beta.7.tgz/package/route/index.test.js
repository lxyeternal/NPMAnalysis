"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fastify_1 = __importDefault(require("fastify"));
const _1 = require(".");
let RootController = class RootController extends _1.BaseController {
    static async get(req, res) {
        res.status(410).send();
    }
    static async post(req, res) {
        res.status(411).send();
    }
    static async put(req, res) {
        res.status(412).send();
    }
    static async patch(req, res) {
        res.status(413).send();
    }
    static async delete(req, res) {
        res.status(414).send();
    }
    static async head(req, res) {
        res.status(415).send();
    }
};
RootController = __decorate([
    (0, _1.route)("/")
], RootController);
let SomeController = class SomeController extends _1.BaseController {
    static async get(req, res) {
        res.status(510).send();
    }
    static async post(req, res) {
        res.status(511).send();
    }
    static async put(req, res) {
        res.status(512).send();
    }
    static async patch(req, res) {
        res.status(513).send();
    }
    static async delete(req, res) {
        res.status(514).send();
    }
    static async head(req, res) {
        res.status(515).send();
    }
};
SomeController = __decorate([
    (0, _1.route)("/path/to/some/endpoint")
], SomeController);
const testCases = {
    root: {
        url: "/",
        expects: [
            {
                method: "GET",
                status: 410,
            },
            {
                method: "POST",
                status: 411,
            },
            {
                method: "PUT",
                status: 412,
            },
            {
                method: "PATCH",
                status: 413,
            },
            {
                method: "DELETE",
                status: 414,
            },
            {
                method: "HEAD",
                status: 415,
            },
        ],
    },
    some: {
        url: "/path/to/some/endpoint",
        expects: [
            {
                method: "GET",
                status: 510,
            },
            {
                method: "POST",
                status: 511,
            },
            {
                method: "PUT",
                status: 512,
            },
            {
                method: "PATCH",
                status: 513,
            },
            {
                method: "DELETE",
                status: 514,
            },
            {
                method: "HEAD",
                status: 515,
            },
        ],
    },
    invalid: {
        url: "/path/to/invalid/endpoint",
        expects: [
            {
                method: "GET",
                status: 404,
            },
            {
                method: "POST",
                status: 404,
            },
            {
                method: "PUT",
                status: 404,
            },
            {
                method: "PATCH",
                status: 404,
            },
            {
                method: "DELETE",
                status: 404,
            },
            {
                method: "HEAD",
                status: 404,
            },
        ],
    },
};
describe("route", () => {
    describe("route without prefix", () => {
        const fastify = (0, fastify_1.default)({
            exposeHeadRoutes: false,
        });
        (0, _1.registerRoutes)(fastify, [RootController, SomeController]);
        for (const targetCaseKeys of Object.keys(testCases)) {
            const targetCase = testCases[targetCaseKeys];
            const url = targetCase.url;
            for (const testCase of targetCase.expects) {
                test(`${testCase.method} ${url}`, async () => {
                    const response = await fastify.inject({
                        url: url,
                        method: testCase.method,
                    });
                    expect(response.statusCode).toBe(testCase.status);
                });
            }
        }
    });
    describe("route with prefix", () => {
        const fastify = (0, fastify_1.default)({
            exposeHeadRoutes: false,
        });
        (0, _1.registerRoutes)(fastify, [RootController, SomeController], "api");
        for (const targetCaseKeys of Object.keys(testCases)) {
            const targetCase = testCases[targetCaseKeys];
            const url = "/api" + targetCase.url;
            for (const testCase of targetCase.expects) {
                test(`${testCase.method} ${url}`, async () => {
                    const response = await fastify.inject({
                        url,
                        method: testCase.method,
                    });
                    expect(response.statusCode).toBe(testCase.status);
                });
            }
        }
    });
    describe("route with prefix with trailing slash", () => {
        const fastify = (0, fastify_1.default)({
            exposeHeadRoutes: false,
        });
        (0, _1.registerRoutes)(fastify, [RootController, SomeController], "api/");
        for (const targetCaseKeys of Object.keys(testCases)) {
            const targetCase = testCases[targetCaseKeys];
            const url = "/api" + targetCase.url;
            for (const testCase of targetCase.expects) {
                test(`${testCase.method} ${url}`, async () => {
                    const response = await fastify.inject({
                        url,
                        method: testCase.method,
                    });
                    expect(response.statusCode).toBe(testCase.status);
                });
            }
        }
    });
});
//# sourceMappingURL=index.test.js.map