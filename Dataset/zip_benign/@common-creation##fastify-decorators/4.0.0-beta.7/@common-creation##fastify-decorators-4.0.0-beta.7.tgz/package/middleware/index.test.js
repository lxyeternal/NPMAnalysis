"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fastify_1 = __importDefault(require("fastify"));
const route_1 = require("../route");
const _1 = require(".");
const skipProcess = (statusCode) => (0, _1.middleware)((req, res, next) => {
    res.status(statusCode).send();
    return;
});
const noop = () => (0, _1.middleware)((req, res, next) => {
    next(req, res);
});
let WithMiddlewareController = class WithMiddlewareController extends route_1.BaseController {
    static async get(req, res) {
        res.status(400).send();
    }
    static async post(req, res) {
        res.status(401).send();
    }
};
__decorate([
    skipProcess(200),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], WithMiddlewareController, "get", null);
__decorate([
    noop(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], WithMiddlewareController, "post", null);
WithMiddlewareController = __decorate([
    (0, route_1.route)("/with/middleware")
], WithMiddlewareController);
let WithoutMiddlewareController = class WithoutMiddlewareController extends route_1.BaseController {
    static async get(req, res) {
        res.status(410).send();
    }
};
WithoutMiddlewareController = __decorate([
    (0, route_1.route)("/without/middleware")
], WithoutMiddlewareController);
const testCases = {
    withMiddleware: {
        url: "/with/middleware",
        expects: [
            {
                method: "GET",
                status: 200,
            },
            {
                method: "POST",
                status: 401,
            },
        ],
    },
    withoutMiddleware: {
        url: "/without/middleware",
        expects: [
            {
                method: "GET",
                status: 410,
            },
        ],
    },
};
describe("middleware", () => {
    const fastify = (0, fastify_1.default)();
    (0, route_1.registerRoutes)(fastify, [WithMiddlewareController, WithoutMiddlewareController]);
    for (const targetCaseKeys of Object.keys(testCases)) {
        const targetCase = testCases[targetCaseKeys];
        const url = targetCase.url;
        for (const testCase of targetCase.expects) {
            test(`${testCase.method} ${url}`, async () => {
                const response = await fastify.inject({
                    url: url,
                    method: testCase.method,
                });
                expect(response.statusCode).toBe(testCase.status);
            });
        }
    }
});
//# sourceMappingURL=index.test.js.map