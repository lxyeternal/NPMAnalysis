"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.middleware = void 0;
const middleware = (func) => {
    return (target, key, descriptor) => {
        if (descriptor === undefined) {
            descriptor = Object.getOwnPropertyDescriptor(target, key);
        }
        const originalMethod = descriptor.value;
        descriptor.value = (currentReq, currentRes) => func(currentReq, currentRes, (nextReq, nextRes) => {
            return originalMethod.apply(target, [nextReq, nextRes]);
        });
        return descriptor;
    };
};
exports.middleware = middleware;
//# sourceMappingURL=index.js.map