# Correct Cal
Correct Calculation

## Description
Correct Cal is a lightweight library that provides accurate math operations for addition, subtraction, multiplication, and division in JavaScript. 
By default, JavaScript has some issues with floating-point arithmetic, which can lead to small calculation errors. 
Correct Cal solves this problem by using the custom library, which provides accurate decimal arithmetic.



## Installation

You can install Correct Math via npm. Simply run the following command:

```bash
npm install correct-math
```

## Usage
To use Correct Math in your JavaScript project, simply require it at the top of your file:

```bash
const correctMath = require('correct-math'); //CommonJs
import correctMath from 'correct-math'; //ES Module
```

Once you have required the package, you can use it to perform your calculations. Here are a few examples:

```bash
// Addition
const result = correctMath.add(0.1, 0.2); // 0.3
const result2 = correctMath.add(0.1, 0.2,'0.3',0.4,'5'); // 6

// Subtraction
const result = correctMath.sub(0.3, 0.1); // 0.2
const result2 = correctMath.sub(0.5, 0.1,'0.2'); // 0.2

// Multiplication
const result = correctMath.mul(0.1, 0.2); // 0.02
const result2 = correctMath.mul(0.5, 0.1,'0.2'); // 0.01

// Division
const result = correctMath.div(0.3, 0.1); // 3
const result2 = correctMath.div(0.3, 0.1,'3'); // 1

```

## Contributing
If you find any issues with Correct Math or have suggestions for improvement, please feel free to open an issue or pull request on the GitHub repository.

## License
Correct Math is released under the ISC License.


###### Note: The author shall not be held responsible for any kind of code error or any issues related to monetary matters.
