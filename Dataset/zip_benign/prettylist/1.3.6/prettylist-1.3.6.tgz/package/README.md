# Pretty List

A package to make items in a list fade in and out as they leave and enter the list. The list can also bend to give a "wheel of fortune of effect.<br>

Live Demo: https://jmonzone.github.io/assets/websites/prettylist/index.html<br>

#### Usage:

```
const list = new PrettyList(items, container, options).list;
```

the prettylist will center itself in the passed container.

#### Options

**rotation** - bends the list (in degrees) . Default is _1._  
**visible** - how many items are visible at once. Default is _3._  
**opacity** - determines how much an item fades from the center. Default is _0.3._

**direction** - the direction of the list (horizontal or vertical). Default is _vertical._

#### Examples:
![Example1](https://media.giphy.com/media/L9V7llWLmaX2EwSuIy/giphy.gif)
![Example2](https://media.giphy.com/media/6iBoYikFWalNH8YT3P/giphy.gif)

