/* eslint-disable consistent-return, no-undef, no-unused-expressions */
import { parse } from "url";

import { expect } from "chai";
import { JSDOM } from "jsdom";

import * as emailSharer from "../../src/sharers/email.js";

describe("Email sharer", () => {
    it("must have name 'email'", () => {
        expect(emailSharer.name).to.equal("email");
    });

    it("must render a link with protocol mailto: and no recipient", () => {
        const html = emailSharer.render("foo", "foo", "path/to/whatever");
        const { window } = new JSDOM(html);

        const anchor = window.document.querySelector("a[href^='mailto:?']");
        expect(anchor).to.not.be.null;
    });

    it("must have a `getShareUrl` helper method", () => {
        expect(typeof emailSharer.getShareUrl).to.equal("function");
    });

    it("must have a `body` parameter in the sharing URL", () => {
        const shareUrl = emailSharer.getShareUrl("foo", "path/to/whatever");
        const parsed = parse(shareUrl, true);
        expect(parsed.query).to.eql({ body: "foo\n\npath/to/whatever" });
    });
});
