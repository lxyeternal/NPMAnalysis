(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('pixi.js'), require('pixi-filters'), require('gsap')) :
  typeof define === 'function' && define.amd ? define('ngxpixi', ['exports', '@angular/core', 'pixi.js', 'pixi-filters', 'gsap'], factory) :
  (global = global || self, factory(global.ngxpixi = {}, global.ng.core, global.pixi_js, global.filters$1, global.gsap));
}(this, function (exports, core, pixi_js, filters$1, gsap) { 'use strict';

  /**
   * @fileoverview added by tsickle
   * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
   */
  /*
    Generated class for the Pixi provider.

    See https://angular.io/docs/ts/latest/guide/dependency-injection.html
    for more info on providers and Angular 2 DI.
  */
  var AssetService = /** @class */ (function () {
      function AssetService() {
          this.loader = new pixi_js.Loader();
          this.loading = false;
          this.assets_loaded = false;
          this.callbacks = {};
      }
      /**
       * @return {?}
       */
      AssetService.prototype.init = /**
       * @return {?}
       */
      function () {
      };
      /**
       * @param {?} id
       * @param {?} fn
       * @return {?}
       */
      AssetService.prototype.registerCallback = /**
       * @param {?} id
       * @param {?} fn
       * @return {?}
       */
      function (id, fn) {
          this.callbacks[id] = fn;
          //If assets are loaded, run callback but delete callback
          if (!this.loading && this.assets_loaded) {
              fn();
              this.deregisterCallback(id);
          }
      };
      /**
       * @param {?} id
       * @return {?}
       */
      AssetService.prototype.deregisterCallback = /**
       * @param {?} id
       * @return {?}
       */
      function (id) {
          delete this.callbacks[id];
      };
      /**
       * @return {?}
       */
      AssetService.prototype.runCallbacks = /**
       * @return {?}
       */
      function () {
          for (var c in this.callbacks) {
              this.callbacks[c]();
          }
      };
      /**
       * @return {?}
       */
      AssetService.prototype.loadAssets = /**
       * @return {?}
       */
      function () {
          /** @type {?} */
          var self = this;
          self.loader.load();
          self.loader.once("complete", (/**
           * @param {?} res
           * @return {?}
           */
          function (res) {
              self.assets_loaded = true;
              self.loading = false;
              //Run callbacks
              self.runCallbacks();
          }));
          self.loader.on("progress", (/**
           * @return {?}
           */
          function () {
              self.loading = true;
          }));
      };
      //only works for horizontal spritesheets
      //only works for horizontal spritesheets
      /**
       * @param {?} texture
       * @param {?} colX
       * @param {?} colY
       * @param {?} rowStart
       * @return {?}
       */
      AssetService.prototype.getFramesFromSpriteSheet = 
      //only works for horizontal spritesheets
      /**
       * @param {?} texture
       * @param {?} colX
       * @param {?} colY
       * @param {?} rowStart
       * @return {?}
       */
      function (texture, colX, colY, rowStart) {
          /** @type {?} */
          var frames = [];
          /** @type {?} */
          var frameWidth = Math.round(texture.width / colX);
          /** @type {?} */
          var frameHeight = Math.round(texture.height / colY);
          /** @type {?} */
          var startY = Math.min(frameHeight * rowStart, texture.height - frameHeight);
          for (var i = 0; i < texture.width - frameWidth; i += frameWidth) {
              frames.push(new pixi_js.Texture(texture.baseTexture, new pixi_js.Rectangle(i, startY, frameWidth, frameHeight)));
          }
          return frames;
      };
      AssetService.decorators = [
          { type: core.Injectable }
      ];
      /** @nocollapse */
      AssetService.ctorParameters = function () { return []; };
      return AssetService;
  }());

  /**
   * @fileoverview added by tsickle
   * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
   */
  /*
    Generated class for the Pixi provider.

    See https://angular.io/docs/ts/latest/guide/dependency-injection.html
    for more info on providers and Angular 2 DI.
  */
  var PixiService = /** @class */ (function () {
      function PixiService() {
          this.loader = new pixi_js.Loader();
          this.ratio = 0;
          this.starting_width = 0;
          this.starting_width_of_window = 0;
          this.starting_height = 0;
          this.starting_height_of_window = 0;
          this.time = 0;
          this.last_time = 0;
          this.anim_loop_callbacks = [];
          this.to_render = [];
      }
      /**
       * @param {?} t
       * @return {?}
       */
      PixiService.prototype.animate = /**
       * @param {?} t
       * @return {?}
       */
      function (t) {
          /** @type {?} */
          var self = this;
          this.time = new Date().getTime() / 1000;
          /** @type {?} */
          var deltaTime = this.time - this.last_time;
          if (typeof this.worldStage != "undefined")
              if (this.worldStage) {
                  for (var s in this.to_render)
                      this.to_render[s].update(deltaTime);
                  for (var c in this.anim_loop_callbacks)
                      this.anim_loop_callbacks[c]();
                  this.renderer.render(this.worldStage);
              }
          this.last_time = this.time;
          requestAnimationFrame((/**
           * @param {?} t
           * @return {?}
           */
          function (t) {
              self.animate(t);
          }));
      };
      /**
       * @param {?} id
       * @return {?}
       */
      PixiService.prototype.appendRenderer = /**
       * @param {?} id
       * @return {?}
       */
      function (id) {
          //Add canvas to page
          /** @type {?} */
          var el = document.getElementById(id);
          if (el)
              el.appendChild(this.renderer.view);
      };
      /**
       * @param {?} el
       * @param {?} args
       * @return {?}
       */
      PixiService.prototype.sizeCollection = /**
       * @param {?} el
       * @param {?} args
       * @return {?}
       */
      function (el, args) {
          //Get current ratio
          /** @type {?} */
          var ratio = this.renderer.width / this.renderer.height;
          //Get current width
          /** @type {?} */
          var old_w = this.renderer.width;
          /** @type {?} */
          var w = el.width();
          //Get new width
          if (typeof args != "undefined")
              w = args.width;
          //Resize to match width
          /** @type {?} */
          var perChange = this.worldStage.scale.x * ((old_w - w) / old_w);
          this.renderer.resize(w, window.innerHeight);
          //Scale Stage based on % change of screen width
          this.worldStage.scale.x -= this.worldStage.scale.x * ((old_w - w) / old_w);
          this.worldStage.scale.y = this.worldStage.scale.x;
      };
      /**
       * @param {?} width
       * @param {?} height
       * @param {?} el
       * @return {?}
       */
      PixiService.prototype.init = /**
       * @param {?} width
       * @param {?} height
       * @param {?} el
       * @return {?}
       */
      function (width, height, el) {
          //Initialize game container
          this.app = new pixi_js.Application({
              width: width,
              height: height,
              transparent: true,
              antialias: true,
              view: el
          });
          this.renderer = this.app.renderer;
          this.renderer.resolution = window.devicePixelRatio;
          this.renderer.rootRenderTarget.resolution = window.devicePixelRatio;
          this.renderer.resize(width - 1, height);
          this.renderer.resize(width, height);
          this.renderer.plugins.interaction.resolution = window.devicePixelRatio;
          this.worldStage = new pixi_js.Container();
          //Initialize game camera
          /** @type {?} */
          var w = this.renderer.width;
          /** @type {?} */
          var h = this.renderer.height;
          this.ratio = w / h;
          this.starting_width = w;
          this.starting_width_of_window = w / window.innerWidth;
          this.starting_height = h;
          this.starting_height_of_window = h / window.innerHeight;
          this.animate(0);
      };
      PixiService.decorators = [
          { type: core.Injectable }
      ];
      /** @nocollapse */
      PixiService.ctorParameters = function () { return []; };
      return PixiService;
  }());

  /**
   * @fileoverview added by tsickle
   * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
   */

  /**
   * @fileoverview added by tsickle
   * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
   */
  var FilterComponent = /** @class */ (function () {
      function FilterComponent() {
          this.filterName = null;
          this.container = null;
          this.config = {};
      }
      /**
       * @return {?}
       */
      FilterComponent.prototype.ngOnInit = /**
       * @return {?}
       */
      function () {
          switch (this.filterName) {
              case 'blur':
                  this.filter = new pixi_js.filters.BlurFilter();
                  for (var c in this.config)
                      this.filter[c] = this.config[c];
                  break;
          }
          if (this.container.filters)
              this.container.filters.push(this.filter);
          else
              this.container.filters = [this.filter];
          this.filterIndex = this.container.filters.length - 1;
      };
      /**
       * @return {?}
       */
      FilterComponent.prototype.ngOnDestroy = /**
       * @return {?}
       */
      function () {
          this.container.filters = null;
      };
      FilterComponent.decorators = [
          { type: core.Component, args: [{
                      selector: 'filter-effect',
                      template: '<span></span>'
                  }] }
      ];
      /** @nocollapse */
      FilterComponent.ctorParameters = function () { return []; };
      FilterComponent.propDecorators = {
          filterName: [{ type: core.Input }],
          container: [{ type: core.Input }],
          config: [{ type: core.Input }]
      };
      return FilterComponent;
  }());

  /**
   * @fileoverview added by tsickle
   * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
   */
  var FilterDirective = /** @class */ (function () {
      function FilterDirective() {
          this._filterConfig = {
              type: "BlurFilter"
          };
      }
      Object.defineProperty(FilterDirective.prototype, "filterConfig", {
          set: /**
           * @param {?} value
           * @return {?}
           */
          function (value) {
              console.log("Tryina change", value, this._filterConfig, this.filter);
              if ((this.filter ? this.filter.type : true) != value.type) {
                  console.log("fitle rchanger", value);
                  this._filterConfig = value;
                  if (filters$1[this._filterConfig.type]) {
                      this.wipeFilter();
                      this.initFilter();
                  }
                  else {
                      console.log(this._filterConfig.type + " filter not available (from set)", filters$1);
                  }
              }
          },
          enumerable: true,
          configurable: true
      });
      /**
       * @return {?}
       */
      FilterDirective.prototype.ngOnInit = /**
       * @return {?}
       */
      function () {
          if (this.container === null)
              return;
          if (filters$1[this._filterConfig.type]) {
              this.initFilter();
          }
          else {
              console.log(this._filterConfig.type + " filter not available", filters$1);
          }
      };
      /**
       * @return {?}
       */
      FilterDirective.prototype.initFilter = /**
       * @return {?}
       */
      function () {
          this.filter = new filters$1[this._filterConfig.type]();
          this.applyConfig();
          this.applyFilter();
      };
      /**
       * @return {?}
       */
      FilterDirective.prototype.applyConfig = /**
       * @return {?}
       */
      function () {
          for (var c in this._filterConfig)
              this.filter[c] = this._filterConfig[c];
      };
      /**
       * @return {?}
       */
      FilterDirective.prototype.applyFilter = /**
       * @return {?}
       */
      function () {
          if (this.container.filters)
              this.container.filters.push(this.filter);
          else
              this.container.filters = [this.filter];
      };
      /**
       * @return {?}
       */
      FilterDirective.prototype.wipeFilter = /**
       * @return {?}
       */
      function () {
          this.container.filters = null;
      };
      /**
       * @return {?}
       */
      FilterDirective.prototype.ngOnDestroy = /**
       * @return {?}
       */
      function () {
          this.wipeFilter();
      };
      /**
       * @return {?}
       */
      FilterDirective.prototype.getAvailableFilters = /**
       * @return {?}
       */
      function () {
          return Object.keys(filters$1);
      };
      FilterDirective.decorators = [
          { type: core.Directive, args: [{
                      selector: "[a2pfilter]"
                  },] }
      ];
      /** @nocollapse */
      FilterDirective.ctorParameters = function () { return []; };
      FilterDirective.propDecorators = {
          container: [{ type: core.Input, args: ["filterStage",] }],
          filterConfig: [{ type: core.Input, args: ["a2pfilter",] }]
      };
      return FilterDirective;
  }());

  /**
   * @fileoverview added by tsickle
   * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
   */
  var SpriteComponent = /** @class */ (function () {
      function SpriteComponent() {
          this.handleClick = null;
          this.imgUrl = "";
          this.frameName = "";
          this.scale = 1;
          this.font = "Arial";
          this.fontSize = "48px";
          this.strokeColor = "#000000";
          this.interactive = true;
          this._x = 0;
          this._y = 0;
          this.text = "";
          this.container = null;
          this.anim = "";
          this.anchor = { x: 0.5, y: 0.5 };
          this.tAnchor = { x: 0.5, y: 0.5 };
          this.textSpr = null;
          this.spriteObject = null;
      }
      Object.defineProperty(SpriteComponent.prototype, "x", {
          get: /**
           * @return {?}
           */
          function () {
              return this._x;
          },
          set: /**
           * @param {?} val
           * @return {?}
           */
          function (val) {
              this._x = val || 0;
              if (this.spriteObject)
                  this.positionSprite();
          },
          enumerable: true,
          configurable: true
      });
      Object.defineProperty(SpriteComponent.prototype, "y", {
          get: /**
           * @return {?}
           */
          function () {
              return this._y;
          },
          set: /**
           * @param {?} val
           * @return {?}
           */
          function (val) {
              this._y = val || 0;
              if (this.spriteObject)
                  this.positionSprite();
          },
          enumerable: true,
          configurable: true
      });
      Object.defineProperty(SpriteComponent.prototype, "valueToShow", {
          set: /**
           * @param {?} val
           * @return {?}
           */
          function (val) {
              this.text = val || "";
              if (this.textSpr)
                  this.textSpr.text = this.text;
          },
          enumerable: true,
          configurable: true
      });
      /**
       * @return {?}
       */
      SpriteComponent.prototype.ngOnInit = /**
       * @return {?}
       */
      function () {
          this.init();
      };
      /**
       * @return {?}
       */
      SpriteComponent.prototype.init = /**
       * @return {?}
       */
      function () {
          this.spriteStage = new pixi_js.Container();
          this.addSprite(this.imgUrl, this.frameName);
          this.addText(this.text);
          if (this.container)
              this.container.addChild(this.spriteStage);
          if (this.anim == "hover")
              this.slowHover();
          if (this.handleClick && this.interactive)
              this.addInteraction(this.handleClick);
      };
      /**
       * @param {?} img
       * @param {?} frame
       * @return {?}
       */
      SpriteComponent.prototype.addSprite = /**
       * @param {?} img
       * @param {?} frame
       * @return {?}
       */
      function (img, frame) {
          if (img.trim() != "" || frame.trim() != "") {
              /** @type {?} */
              var texture = img
                  ? pixi_js.Texture.from(img)
                  : pixi_js.Texture.from(frame);
              //create sprite
              this.spriteObject = new pixi_js.Sprite(texture);
              this.spriteObject.anchor.x = this.anchor.x;
              this.spriteObject.anchor.y = this.anchor.x;
              //positioning and sizing
              this.positionSprite();
              //add to sprite container
              this.spriteStage.addChild(this.spriteObject);
          }
      };
      /**
       * @return {?}
       */
      SpriteComponent.prototype.positionSprite = /**
       * @return {?}
       */
      function () {
          if (!this.spriteObject)
              return;
          this.spriteObject.scale.set(this.scale);
          (this.spriteObject.position.x = this._x),
              (this.spriteObject.position.y = this._y);
      };
      /**
       * @param {?} text
       * @return {?}
       */
      SpriteComponent.prototype.addText = /**
       * @param {?} text
       * @return {?}
       */
      function (text) {
          if (this.textSpr) {
              this.textSpr.text = text;
          }
          else {
              if (text.toString().trim() != "") {
                  /** @type {?} */
                  var t = new pixi_js.Text(text, {
                      fontFamily: this.font,
                      fontSize: this.fontSize,
                      fill: "white",
                      stroke: this.strokeColor,
                      strokeThickness: 4
                  });
                  t.resolution = window.devicePixelRatio;
                  this.spriteStage.addChild(t);
                  t.position.x = this._x - 30;
                  t.position.y = this._y;
                  t.anchor.x = this.tAnchor.x;
                  t.anchor.y = this.tAnchor.y;
                  this.textSpr = t;
              }
          }
      };
      /**
       * @param {?} cb
       * @return {?}
       */
      SpriteComponent.prototype.addInteraction = /**
       * @param {?} cb
       * @return {?}
       */
      function (cb) {
          var _this = this;
          if (!this.spriteObject)
              return;
          this.spriteObject.interactive = true;
          if (this.anim == "explode") {
              this.spriteObject
                  .on("tap", (/**
               * @return {?}
               */
              function () {
                  _this.explodeOut().then(cb);
              }))
                  .on("click", (/**
               * @return {?}
               */
              function () {
                  _this.explodeOut().then(cb);
              }));
          }
          else {
              this.spriteObject.on("tap", cb).on("click", cb);
          }
      };
      /**
       * @return {?}
       */
      SpriteComponent.prototype.slowHover = /**
       * @return {?}
       */
      function () {
          this.hoverUp();
      };
      /**
       * @return {?}
       */
      SpriteComponent.prototype.hoverUp = /**
       * @return {?}
       */
      function () {
          gsap.TweenLite.to(this.spriteObject.position, 3, {
              y: "-=30",
              ease: gsap.Sine.easeInOut,
              onComplete: this.hoverDown.bind(this)
          });
      };
      /**
       * @return {?}
       */
      SpriteComponent.prototype.hoverDown = /**
       * @return {?}
       */
      function () {
          gsap.TweenLite.to(this.spriteObject.position, 4, {
              y: "+=30",
              ease: gsap.Sine.easeInOut,
              onComplete: this.hoverUp.bind(this)
          });
      };
      /**
       * @return {?}
       */
      SpriteComponent.prototype.explodeOut = /**
       * @return {?}
       */
      function () {
          var _this = this;
          return new Promise((/**
           * @param {?} resolve
           * @param {?} reject
           * @return {?}
           */
          function (resolve, reject) {
              gsap.TweenLite.to(_this.spriteObject, 0.8, {
                  alpha: 0
              });
              gsap.TweenLite.to(_this.spriteObject.scale, 0.8, {
                  x: 2,
                  y: 2,
                  onComplete: resolve.bind(_this)
              });
          }));
      };
      /**
       * @return {?}
       */
      SpriteComponent.prototype.ngOnDestroy = /**
       * @return {?}
       */
      function () {
          if (this.spriteStage)
              if (this.spriteStage.parent)
                  this.spriteStage.parent.removeChild(this.spriteStage);
      };
      SpriteComponent.decorators = [
          { type: core.Component, args: [{
                      selector: "sprite",
                      template: "<span></span>"
                  }] }
      ];
      /** @nocollapse */
      SpriteComponent.ctorParameters = function () { return []; };
      SpriteComponent.propDecorators = {
          handleClick: [{ type: core.Input }],
          imgUrl: [{ type: core.Input }],
          frameName: [{ type: core.Input }],
          scale: [{ type: core.Input }],
          font: [{ type: core.Input }],
          fontSize: [{ type: core.Input }],
          strokeColor: [{ type: core.Input }],
          interactive: [{ type: core.Input }],
          _x: [{ type: core.Input }],
          x: [{ type: core.Input }],
          _y: [{ type: core.Input }],
          y: [{ type: core.Input }],
          text: [{ type: core.Input }],
          valueToShow: [{ type: core.Input }],
          container: [{ type: core.Input }],
          anim: [{ type: core.Input }],
          anchor: [{ type: core.Input }],
          tAnchor: [{ type: core.Input }]
      };
      return SpriteComponent;
  }());

  /**
   * @fileoverview added by tsickle
   * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
   */
  var MenuComponent = /** @class */ (function () {
      function MenuComponent() {
          this.container = null;
          this.itemHeight = 200;
          this.itemWidth = 200;
          this.x = 0;
          this.y = 0;
          this.w = window.innerWidth;
          this.h = window.innerHeight;
          this.rowLength = 3;
          this.isGrid = false;
          this.isScrollable = true;
          this.dragPoint = { x: 0, y: 0 };
          this.mouseDown = false;
          this.dragging = false;
      }
      /**
       * @return {?}
       */
      MenuComponent.prototype.ngOnInit = /**
       * @return {?}
       */
      function () {
          this.initMenuContainer();
          if (this.isScrollable)
              this.initInteraction();
          this.positionContainer();
          this.positionItems();
      };
      /**
       * @param {?=} event
       * @return {?}
       */
      MenuComponent.prototype.positionContainer = /**
       * @param {?=} event
       * @return {?}
       */
      function (event) {
          this.menuContainer.position.set(this.x, this.y);
      };
      /**
       * @return {?}
       */
      MenuComponent.prototype.initMenuContainer = /**
       * @return {?}
       */
      function () {
          this.menuContainer = new pixi_js.Container();
          this.menuContainer.interactive = true;
          this.menuContainer.position.x = this.x;
          this.menuContainer.position.y = this.y;
          this.container.addChild(this.menuContainer);
      };
      /**
       * @return {?}
       */
      MenuComponent.prototype.initInteraction = /**
       * @return {?}
       */
      function () {
          this.menuContainer.interactive = true;
          this.menuContainer
              .on("mousedown", this.stageMouseDown.bind(this))
              .on("touchstart", this.stageMouseDown.bind(this));
          this.menuContainer
              .on("mouseupoutside", this.stageMouseUp.bind(this))
              .on("mouseup", this.stageMouseUp.bind(this))
              .on("touchendoutside", this.stageMouseUp.bind(this))
              .on("touchend", this.stageMouseUp.bind(this));
          this.menuContainer
              .on("mousemove", this.stageMove.bind(this))
              .on("touchmove", this.stageMove.bind(this));
      };
      /**
       * @return {?}
       */
      MenuComponent.prototype.getViewport = /**
       * @return {?}
       */
      function () {
          return {
              min: this.menuContainer.position.x,
              max: this.menuContainer.position.x + this.w
          };
      };
      /**
       * @param {?} i
       * @return {?}
       */
      MenuComponent.prototype.distanceFromCenter = /**
       * @param {?} i
       * @return {?}
       */
      function (i) {
          /** @type {?} */
          var child = this.menuContainer.children[i];
          if (!child)
              return 0;
          /** @type {?} */
          var vMin = this.getViewport().min;
          /** @type {?} */
          var vMax = this.getViewport().max;
          /** @type {?} */
          var center = this.w / 2;
          /** @type {?} */
          var itemX = child.transform.worldTransform.tx + child.getBounds().width / 2;
          /** @type {?} */
          var distX = Math.abs(itemX - center);
          return distX;
      };
      /**
       * @return {?}
       */
      MenuComponent.prototype.positionItems = /**
       * @return {?}
       */
      function () {
          for (var c in this.menuContainer.children) {
              /** @type {?} */
              var child = this.menuContainer.children[c];
              if (!child)
                  continue;
              if (!(child instanceof pixi_js.Sprite) &&
                  !(child instanceof pixi_js.Container) &&
                  !(child instanceof pixi_js.Text))
                  return;
              if (child.children.length <= 1)
                  continue;
              /** @type {?} */
              var pos = this.calculateItemPosition(parseInt(c));
              child.position.set(pos.x, pos.y);
              if (!this.isGrid)
                  child.scale.set(pos.scale);
          }
      };
      /**
       * @param {?} i
       * @return {?}
       */
      MenuComponent.prototype.sizeItem = /**
       * @param {?} i
       * @return {?}
       */
      function (i) {
          /** @type {?} */
          var child = this.menuContainer.children[i];
          if (!child)
              return 2;
          /** @type {?} */
          var scaleD = this.distanceFromCenter(i) / (this.w * 0.5);
          /** @type {?} */
          var scale = 1.5 - Math.min(1, scaleD > 0.1 ? scaleD : 0);
          return scale;
      };
      /**
       * @param {?} i
       * @return {?}
       */
      MenuComponent.prototype.calculateItemPosition = /**
       * @param {?} i
       * @return {?}
       */
      function (i) {
          /** @type {?} */
          var child = this.menuContainer.children[i];
          if (!child)
              return {
                  x: 0,
                  y: 0,
                  scale: this.sizeItem(i)
              };
          /** @type {?} */
          var baseH = this.itemHeight;
          /** @type {?} */
          var baseW = this.itemWidth;
          /** @type {?} */
          var scale = this.sizeItem(i);
          if (this.isGrid) {
              return {
                  x: ((i % this.rowLength) * baseW) +
                      Math.max(0, this.itemWidth * (this.rowLength - this.menuContainer.children.length)),
                  y: baseH * Math.floor(i / this.rowLength),
                  scale: 1
              };
          }
          else {
              return {
                  x: (i * baseW) +
                      this.itemWidth * i,
                  y: baseH,
                  scale: scale
              };
          }
      };
      /**
       * @param {?} event
       * @return {?}
       */
      MenuComponent.prototype.stageMouseDown = /**
       * @param {?} event
       * @return {?}
       */
      function (event) {
          this.mouseDown = true;
          if (!this.dragging) {
              /** @type {?} */
              var newPosition = event.data.getLocalPosition(this.container);
              this.dragPoint.x = newPosition.x;
              this.dragPoint.y = newPosition.y;
              // this.menuContainer.pivot.set(this.dragPoint.x, this.isGrid ? this.dragPoint.y : 0);
          }
      };
      /**
       * @param {?} event
       * @return {?}
       */
      MenuComponent.prototype.stageMouseUp = /**
       * @param {?} event
       * @return {?}
       */
      function (event) {
          this.mouseDown = false;
          if (this.dragging) {
              this.dragging = false;
          }
      };
      /**
       * @param {?} event
       * @return {?}
       */
      MenuComponent.prototype.stageMove = /**
       * @param {?} event
       * @return {?}
       */
      function (event) {
          if (this.mouseDown) {
              this.dragging = true;
              /** @type {?} */
              var newPosition = event.data.getLocalPosition(this.container);
              this.calcPosition(newPosition);
              this.dragPoint.x = newPosition.x;
              this.dragPoint.y = newPosition.y;
          }
      };
      /**
       * @param {?} newP
       * @return {?}
       */
      MenuComponent.prototype.calcPosition = /**
       * @param {?} newP
       * @return {?}
       */
      function (newP) {
          /** @type {?} */
          var oldP = Object.assign({}, this.menuContainer.position);
          /** @type {?} */
          var menuWidth = this.menuContainer.children.length * this.itemWidth;
          /** @type {?} */
          var menuHeight = this.h;
          if (this.isGrid) {
              this.menuContainer.position.y -= this.dragPoint.y - newP.y;
              if (this.menuContainer.position.y > this.y + menuHeight)
                  this.menuContainer.position.y = this.y + menuHeight;
              if (this.menuContainer.position.y < menuHeight * -1)
                  this.menuContainer.position.y = menuHeight * -1;
          }
          else {
              this.menuContainer.position.x -= this.dragPoint.x - newP.x;
              if (this.menuContainer.position.x > this.x + menuWidth)
                  this.menuContainer.position.x = this.x + menuWidth;
              if (this.menuContainer.position.x < menuWidth * -1)
                  this.menuContainer.position.x = menuWidth * -1;
          }
      };
      MenuComponent.decorators = [
          { type: core.Component, args: [{
                      selector: "menu",
                      template: "<span></span>"
                  }] }
      ];
      /** @nocollapse */
      MenuComponent.ctorParameters = function () { return []; };
      MenuComponent.propDecorators = {
          container: [{ type: core.Input }],
          itemHeight: [{ type: core.Input }],
          itemWidth: [{ type: core.Input }],
          x: [{ type: core.Input }],
          y: [{ type: core.Input }],
          w: [{ type: core.Input }],
          h: [{ type: core.Input }],
          rowLength: [{ type: core.Input }],
          isGrid: [{ type: core.Input }],
          isScrollable: [{ type: core.Input }]
      };
      return MenuComponent;
  }());

  /**
   * @fileoverview added by tsickle
   * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
   */

  /**
   * @fileoverview added by tsickle
   * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
   */
  var PixiModule = /** @class */ (function () {
      function PixiModule() {
      }
      PixiModule.decorators = [
          { type: core.NgModule, args: [{
                      declarations: [
                          SpriteComponent,
                          FilterComponent,
                          FilterDirective,
                          MenuComponent,
                      ],
                      imports: [],
                      exports: [
                          SpriteComponent,
                          FilterComponent,
                          FilterDirective,
                          MenuComponent,
                      ],
                      providers: [
                          AssetService,
                          PixiService
                      ]
                  },] }
      ];
      return PixiModule;
  }());

  exports.AssetService = AssetService;
  exports.FilterComponent = FilterComponent;
  exports.FilterDirective = FilterDirective;
  exports.MenuComponent = MenuComponent;
  exports.PixiModule = PixiModule;
  exports.PixiService = PixiService;
  exports.SpriteComponent = SpriteComponent;
  exports.ɵa = SpriteComponent;
  exports.ɵb = FilterComponent;
  exports.ɵc = FilterDirective;
  exports.ɵd = MenuComponent;
  exports.ɵe = AssetService;
  exports.ɵf = PixiService;

  Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=ngxpixi.umd.js.map
