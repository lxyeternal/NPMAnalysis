import { Injectable, Component, Input, Directive, NgModule } from '@angular/core';
import { Loader, Texture, Rectangle, Application, Container, filters, Sprite, Text } from 'pixi.js';
import * as filters$1 from 'pixi-filters';
import { TweenLite, Sine } from 'gsap';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
  Generated class for the Pixi provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
class AssetService {
    constructor() {
        this.loader = new Loader();
        this.loading = false;
        this.assets_loaded = false;
        this.callbacks = {};
    }
    /**
     * @return {?}
     */
    init() {
    }
    /**
     * @param {?} id
     * @param {?} fn
     * @return {?}
     */
    registerCallback(id, fn) {
        this.callbacks[id] = fn;
        //If assets are loaded, run callback but delete callback
        if (!this.loading && this.assets_loaded) {
            fn();
            this.deregisterCallback(id);
        }
    }
    /**
     * @param {?} id
     * @return {?}
     */
    deregisterCallback(id) {
        delete this.callbacks[id];
    }
    /**
     * @return {?}
     */
    runCallbacks() {
        for (let c in this.callbacks) {
            this.callbacks[c]();
        }
    }
    /**
     * @return {?}
     */
    loadAssets() {
        /** @type {?} */
        let self = this;
        self.loader.load();
        self.loader.once("complete", (/**
         * @param {?} res
         * @return {?}
         */
        function (res) {
            self.assets_loaded = true;
            self.loading = false;
            //Run callbacks
            self.runCallbacks();
        }));
        self.loader.on("progress", (/**
         * @return {?}
         */
        function () {
            self.loading = true;
        }));
    }
    //only works for horizontal spritesheets
    /**
     * @param {?} texture
     * @param {?} colX
     * @param {?} colY
     * @param {?} rowStart
     * @return {?}
     */
    getFramesFromSpriteSheet(texture, colX, colY, rowStart) {
        /** @type {?} */
        let frames = [];
        /** @type {?} */
        let frameWidth = Math.round(texture.width / colX);
        /** @type {?} */
        let frameHeight = Math.round(texture.height / colY);
        /** @type {?} */
        let startY = Math.min(frameHeight * rowStart, texture.height - frameHeight);
        for (let i = 0; i < texture.width - frameWidth; i += frameWidth) {
            frames.push(new Texture(texture.baseTexture, new Rectangle(i, startY, frameWidth, frameHeight)));
        }
        return frames;
    }
}
AssetService.decorators = [
    { type: Injectable }
];
/** @nocollapse */
AssetService.ctorParameters = () => [];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
  Generated class for the Pixi provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
class PixiService {
    constructor() {
        this.loader = new Loader();
        this.ratio = 0;
        this.starting_width = 0;
        this.starting_width_of_window = 0;
        this.starting_height = 0;
        this.starting_height_of_window = 0;
        this.time = 0;
        this.last_time = 0;
        this.anim_loop_callbacks = [];
        this.to_render = [];
    }
    /**
     * @param {?} t
     * @return {?}
     */
    animate(t) {
        /** @type {?} */
        let self = this;
        this.time = new Date().getTime() / 1000;
        /** @type {?} */
        let deltaTime = this.time - this.last_time;
        if (typeof this.worldStage != "undefined")
            if (this.worldStage) {
                for (let s in this.to_render)
                    this.to_render[s].update(deltaTime);
                for (let c in this.anim_loop_callbacks)
                    this.anim_loop_callbacks[c]();
                this.renderer.render(this.worldStage);
            }
        this.last_time = this.time;
        requestAnimationFrame((/**
         * @param {?} t
         * @return {?}
         */
        t => {
            self.animate(t);
        }));
    }
    /**
     * @param {?} id
     * @return {?}
     */
    appendRenderer(id) {
        //Add canvas to page
        /** @type {?} */
        let el = document.getElementById(id);
        if (el)
            el.appendChild(this.renderer.view);
    }
    /**
     * @param {?} el
     * @param {?} args
     * @return {?}
     */
    sizeCollection(el, args) {
        //Get current ratio
        /** @type {?} */
        let ratio = this.renderer.width / this.renderer.height;
        //Get current width
        /** @type {?} */
        let old_w = this.renderer.width;
        /** @type {?} */
        let w = el.width();
        //Get new width
        if (typeof args != "undefined")
            w = args.width;
        //Resize to match width
        /** @type {?} */
        let perChange = this.worldStage.scale.x * ((old_w - w) / old_w);
        this.renderer.resize(w, window.innerHeight);
        //Scale Stage based on % change of screen width
        this.worldStage.scale.x -= this.worldStage.scale.x * ((old_w - w) / old_w);
        this.worldStage.scale.y = this.worldStage.scale.x;
    }
    /**
     * @param {?} width
     * @param {?} height
     * @param {?} el
     * @return {?}
     */
    init(width, height, el) {
        //Initialize game container
        this.app = new Application({
            width: width,
            height: height,
            transparent: true,
            antialias: true,
            view: el
        });
        this.renderer = this.app.renderer;
        this.renderer.resolution = window.devicePixelRatio;
        this.renderer.rootRenderTarget.resolution = window.devicePixelRatio;
        this.renderer.resize(width - 1, height);
        this.renderer.resize(width, height);
        this.renderer.plugins.interaction.resolution = window.devicePixelRatio;
        this.worldStage = new Container();
        //Initialize game camera
        /** @type {?} */
        let w = this.renderer.width;
        /** @type {?} */
        let h = this.renderer.height;
        this.ratio = w / h;
        this.starting_width = w;
        this.starting_width_of_window = w / window.innerWidth;
        this.starting_height = h;
        this.starting_height_of_window = h / window.innerHeight;
        this.animate(0);
    }
}
PixiService.decorators = [
    { type: Injectable }
];
/** @nocollapse */
PixiService.ctorParameters = () => [];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class FilterComponent {
    constructor() {
        this.filterName = null;
        this.container = null;
        this.config = {};
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        switch (this.filterName) {
            case 'blur':
                this.filter = new filters.BlurFilter();
                for (let c in this.config)
                    this.filter[c] = this.config[c];
                break;
        }
        if (this.container.filters)
            this.container.filters.push(this.filter);
        else
            this.container.filters = [this.filter];
        this.filterIndex = this.container.filters.length - 1;
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.container.filters = null;
    }
}
FilterComponent.decorators = [
    { type: Component, args: [{
                selector: 'filter-effect',
                template: '<span></span>'
            }] }
];
/** @nocollapse */
FilterComponent.ctorParameters = () => [];
FilterComponent.propDecorators = {
    filterName: [{ type: Input }],
    container: [{ type: Input }],
    config: [{ type: Input }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class FilterDirective {
    constructor() {
        this._filterConfig = {
            type: "BlurFilter"
        };
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set filterConfig(value) {
        console.log("Tryina change", value, this._filterConfig, this.filter);
        if ((this.filter ? this.filter.type : true) != value.type) {
            console.log("fitle rchanger", value);
            this._filterConfig = value;
            if (filters$1[this._filterConfig.type]) {
                this.wipeFilter();
                this.initFilter();
            }
            else {
                console.log(this._filterConfig.type + " filter not available (from set)", filters$1);
            }
        }
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        if (this.container === null)
            return;
        if (filters$1[this._filterConfig.type]) {
            this.initFilter();
        }
        else {
            console.log(this._filterConfig.type + " filter not available", filters$1);
        }
    }
    /**
     * @return {?}
     */
    initFilter() {
        this.filter = new filters$1[this._filterConfig.type]();
        this.applyConfig();
        this.applyFilter();
    }
    /**
     * @return {?}
     */
    applyConfig() {
        for (let c in this._filterConfig)
            this.filter[c] = this._filterConfig[c];
    }
    /**
     * @return {?}
     */
    applyFilter() {
        if (this.container.filters)
            this.container.filters.push(this.filter);
        else
            this.container.filters = [this.filter];
    }
    /**
     * @return {?}
     */
    wipeFilter() {
        this.container.filters = null;
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.wipeFilter();
    }
    /**
     * @return {?}
     */
    getAvailableFilters() {
        return Object.keys(filters$1);
    }
}
FilterDirective.decorators = [
    { type: Directive, args: [{
                selector: "[a2pfilter]"
            },] }
];
/** @nocollapse */
FilterDirective.ctorParameters = () => [];
FilterDirective.propDecorators = {
    container: [{ type: Input, args: ["filterStage",] }],
    filterConfig: [{ type: Input, args: ["a2pfilter",] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class SpriteComponent {
    constructor() {
        this.handleClick = null;
        this.imgUrl = "";
        this.frameName = "";
        this.scale = 1;
        this.font = "Arial";
        this.fontSize = "48px";
        this.strokeColor = "#000000";
        this.interactive = true;
        this._x = 0;
        this._y = 0;
        this.text = "";
        this.container = null;
        this.anim = "";
        this.anchor = { x: 0.5, y: 0.5 };
        this.tAnchor = { x: 0.5, y: 0.5 };
        this.textSpr = null;
        this.spriteObject = null;
    }
    /**
     * @param {?} val
     * @return {?}
     */
    set x(val) {
        this._x = val || 0;
        if (this.spriteObject)
            this.positionSprite();
    }
    /**
     * @return {?}
     */
    get x() {
        return this._x;
    }
    /**
     * @param {?} val
     * @return {?}
     */
    set y(val) {
        this._y = val || 0;
        if (this.spriteObject)
            this.positionSprite();
    }
    /**
     * @return {?}
     */
    get y() {
        return this._y;
    }
    /**
     * @param {?} val
     * @return {?}
     */
    set valueToShow(val) {
        this.text = val || "";
        if (this.textSpr)
            this.textSpr.text = this.text;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.init();
    }
    /**
     * @return {?}
     */
    init() {
        this.spriteStage = new Container();
        this.addSprite(this.imgUrl, this.frameName);
        this.addText(this.text);
        if (this.container)
            this.container.addChild(this.spriteStage);
        if (this.anim == "hover")
            this.slowHover();
        if (this.handleClick && this.interactive)
            this.addInteraction(this.handleClick);
    }
    /**
     * @param {?} img
     * @param {?} frame
     * @return {?}
     */
    addSprite(img, frame) {
        if (img.trim() != "" || frame.trim() != "") {
            /** @type {?} */
            let texture = img
                ? Texture.from(img)
                : Texture.from(frame);
            //create sprite
            this.spriteObject = new Sprite(texture);
            this.spriteObject.anchor.x = this.anchor.x;
            this.spriteObject.anchor.y = this.anchor.x;
            //positioning and sizing
            this.positionSprite();
            //add to sprite container
            this.spriteStage.addChild(this.spriteObject);
        }
    }
    /**
     * @return {?}
     */
    positionSprite() {
        if (!this.spriteObject)
            return;
        this.spriteObject.scale.set(this.scale);
        (this.spriteObject.position.x = this._x),
            (this.spriteObject.position.y = this._y);
    }
    /**
     * @param {?} text
     * @return {?}
     */
    addText(text) {
        if (this.textSpr) {
            this.textSpr.text = text;
        }
        else {
            if (text.toString().trim() != "") {
                /** @type {?} */
                let t = new Text(text, {
                    fontFamily: this.font,
                    fontSize: this.fontSize,
                    fill: "white",
                    stroke: this.strokeColor,
                    strokeThickness: 4
                });
                t.resolution = window.devicePixelRatio;
                this.spriteStage.addChild(t);
                t.position.x = this._x - 30;
                t.position.y = this._y;
                t.anchor.x = this.tAnchor.x;
                t.anchor.y = this.tAnchor.y;
                this.textSpr = t;
            }
        }
    }
    /**
     * @param {?} cb
     * @return {?}
     */
    addInteraction(cb) {
        if (!this.spriteObject)
            return;
        this.spriteObject.interactive = true;
        if (this.anim == "explode") {
            this.spriteObject
                .on("tap", (/**
             * @return {?}
             */
            () => {
                this.explodeOut().then(cb);
            }))
                .on("click", (/**
             * @return {?}
             */
            () => {
                this.explodeOut().then(cb);
            }));
        }
        else {
            this.spriteObject.on("tap", cb).on("click", cb);
        }
    }
    /**
     * @return {?}
     */
    slowHover() {
        this.hoverUp();
    }
    /**
     * @return {?}
     */
    hoverUp() {
        TweenLite.to(this.spriteObject.position, 3, {
            y: "-=30",
            ease: Sine.easeInOut,
            onComplete: this.hoverDown.bind(this)
        });
    }
    /**
     * @return {?}
     */
    hoverDown() {
        TweenLite.to(this.spriteObject.position, 4, {
            y: "+=30",
            ease: Sine.easeInOut,
            onComplete: this.hoverUp.bind(this)
        });
    }
    /**
     * @return {?}
     */
    explodeOut() {
        return new Promise((/**
         * @param {?} resolve
         * @param {?} reject
         * @return {?}
         */
        (resolve, reject) => {
            TweenLite.to(this.spriteObject, 0.8, {
                alpha: 0
            });
            TweenLite.to(this.spriteObject.scale, 0.8, {
                x: 2,
                y: 2,
                onComplete: resolve.bind(this)
            });
        }));
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        if (this.spriteStage)
            if (this.spriteStage.parent)
                this.spriteStage.parent.removeChild(this.spriteStage);
    }
}
SpriteComponent.decorators = [
    { type: Component, args: [{
                selector: "sprite",
                template: "<span></span>"
            }] }
];
/** @nocollapse */
SpriteComponent.ctorParameters = () => [];
SpriteComponent.propDecorators = {
    handleClick: [{ type: Input }],
    imgUrl: [{ type: Input }],
    frameName: [{ type: Input }],
    scale: [{ type: Input }],
    font: [{ type: Input }],
    fontSize: [{ type: Input }],
    strokeColor: [{ type: Input }],
    interactive: [{ type: Input }],
    _x: [{ type: Input }],
    x: [{ type: Input }],
    _y: [{ type: Input }],
    y: [{ type: Input }],
    text: [{ type: Input }],
    valueToShow: [{ type: Input }],
    container: [{ type: Input }],
    anim: [{ type: Input }],
    anchor: [{ type: Input }],
    tAnchor: [{ type: Input }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class MenuComponent {
    constructor() {
        this.container = null;
        this.itemHeight = 200;
        this.itemWidth = 200;
        this.x = 0;
        this.y = 0;
        this.w = window.innerWidth;
        this.h = window.innerHeight;
        this.rowLength = 3;
        this.isGrid = false;
        this.isScrollable = true;
        this.dragPoint = { x: 0, y: 0 };
        this.mouseDown = false;
        this.dragging = false;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.initMenuContainer();
        if (this.isScrollable)
            this.initInteraction();
        this.positionContainer();
        this.positionItems();
    }
    /**
     * @param {?=} event
     * @return {?}
     */
    positionContainer(event) {
        this.menuContainer.position.set(this.x, this.y);
    }
    /**
     * @return {?}
     */
    initMenuContainer() {
        this.menuContainer = new Container();
        this.menuContainer.interactive = true;
        this.menuContainer.position.x = this.x;
        this.menuContainer.position.y = this.y;
        this.container.addChild(this.menuContainer);
    }
    /**
     * @return {?}
     */
    initInteraction() {
        this.menuContainer.interactive = true;
        this.menuContainer
            .on("mousedown", this.stageMouseDown.bind(this))
            .on("touchstart", this.stageMouseDown.bind(this));
        this.menuContainer
            .on("mouseupoutside", this.stageMouseUp.bind(this))
            .on("mouseup", this.stageMouseUp.bind(this))
            .on("touchendoutside", this.stageMouseUp.bind(this))
            .on("touchend", this.stageMouseUp.bind(this));
        this.menuContainer
            .on("mousemove", this.stageMove.bind(this))
            .on("touchmove", this.stageMove.bind(this));
    }
    /**
     * @return {?}
     */
    getViewport() {
        return {
            min: this.menuContainer.position.x,
            max: this.menuContainer.position.x + this.w
        };
    }
    /**
     * @param {?} i
     * @return {?}
     */
    distanceFromCenter(i) {
        /** @type {?} */
        let child = this.menuContainer.children[i];
        if (!child)
            return 0;
        /** @type {?} */
        let vMin = this.getViewport().min;
        /** @type {?} */
        let vMax = this.getViewport().max;
        /** @type {?} */
        let center = this.w / 2;
        /** @type {?} */
        let itemX = child.transform.worldTransform.tx + child.getBounds().width / 2;
        /** @type {?} */
        let distX = Math.abs(itemX - center);
        return distX;
    }
    /**
     * @return {?}
     */
    positionItems() {
        for (var c in this.menuContainer.children) {
            /** @type {?} */
            let child = this.menuContainer.children[c];
            if (!child)
                continue;
            if (!(child instanceof Sprite) &&
                !(child instanceof Container) &&
                !(child instanceof Text))
                return;
            if (child.children.length <= 1)
                continue;
            /** @type {?} */
            let pos = this.calculateItemPosition(parseInt(c));
            child.position.set(pos.x, pos.y);
            if (!this.isGrid)
                child.scale.set(pos.scale);
        }
    }
    /**
     * @param {?} i
     * @return {?}
     */
    sizeItem(i) {
        /** @type {?} */
        let child = this.menuContainer.children[i];
        if (!child)
            return 2;
        /** @type {?} */
        let scaleD = this.distanceFromCenter(i) / (this.w * 0.5);
        /** @type {?} */
        let scale = 1.5 - Math.min(1, scaleD > 0.1 ? scaleD : 0);
        return scale;
    }
    /**
     * @param {?} i
     * @return {?}
     */
    calculateItemPosition(i) {
        /** @type {?} */
        let child = this.menuContainer.children[i];
        if (!child)
            return {
                x: 0,
                y: 0,
                scale: this.sizeItem(i)
            };
        /** @type {?} */
        let baseH = this.itemHeight;
        /** @type {?} */
        let baseW = this.itemWidth;
        /** @type {?} */
        let scale = this.sizeItem(i);
        if (this.isGrid) {
            return {
                x: ((i % this.rowLength) * baseW) +
                    Math.max(0, this.itemWidth * (this.rowLength - this.menuContainer.children.length)),
                y: baseH * Math.floor(i / this.rowLength),
                scale: 1
            };
        }
        else {
            return {
                x: (i * baseW) +
                    this.itemWidth * i,
                y: baseH,
                scale: scale
            };
        }
    }
    /**
     * @param {?} event
     * @return {?}
     */
    stageMouseDown(event) {
        this.mouseDown = true;
        if (!this.dragging) {
            /** @type {?} */
            let newPosition = event.data.getLocalPosition(this.container);
            this.dragPoint.x = newPosition.x;
            this.dragPoint.y = newPosition.y;
            // this.menuContainer.pivot.set(this.dragPoint.x, this.isGrid ? this.dragPoint.y : 0);
        }
    }
    /**
     * @param {?} event
     * @return {?}
     */
    stageMouseUp(event) {
        this.mouseDown = false;
        if (this.dragging) {
            this.dragging = false;
        }
    }
    /**
     * @param {?} event
     * @return {?}
     */
    stageMove(event) {
        if (this.mouseDown) {
            this.dragging = true;
            /** @type {?} */
            let newPosition = event.data.getLocalPosition(this.container);
            this.calcPosition(newPosition);
            this.dragPoint.x = newPosition.x;
            this.dragPoint.y = newPosition.y;
        }
    }
    /**
     * @param {?} newP
     * @return {?}
     */
    calcPosition(newP) {
        /** @type {?} */
        let oldP = Object.assign({}, this.menuContainer.position);
        /** @type {?} */
        let menuWidth = this.menuContainer.children.length * this.itemWidth;
        /** @type {?} */
        let menuHeight = this.h;
        if (this.isGrid) {
            this.menuContainer.position.y -= this.dragPoint.y - newP.y;
            if (this.menuContainer.position.y > this.y + menuHeight)
                this.menuContainer.position.y = this.y + menuHeight;
            if (this.menuContainer.position.y < menuHeight * -1)
                this.menuContainer.position.y = menuHeight * -1;
        }
        else {
            this.menuContainer.position.x -= this.dragPoint.x - newP.x;
            if (this.menuContainer.position.x > this.x + menuWidth)
                this.menuContainer.position.x = this.x + menuWidth;
            if (this.menuContainer.position.x < menuWidth * -1)
                this.menuContainer.position.x = menuWidth * -1;
        }
    }
}
MenuComponent.decorators = [
    { type: Component, args: [{
                selector: "menu",
                template: "<span></span>"
            }] }
];
/** @nocollapse */
MenuComponent.ctorParameters = () => [];
MenuComponent.propDecorators = {
    container: [{ type: Input }],
    itemHeight: [{ type: Input }],
    itemWidth: [{ type: Input }],
    x: [{ type: Input }],
    y: [{ type: Input }],
    w: [{ type: Input }],
    h: [{ type: Input }],
    rowLength: [{ type: Input }],
    isGrid: [{ type: Input }],
    isScrollable: [{ type: Input }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class PixiModule {
}
PixiModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    SpriteComponent,
                    FilterComponent,
                    FilterDirective,
                    MenuComponent,
                ],
                imports: [],
                exports: [
                    SpriteComponent,
                    FilterComponent,
                    FilterDirective,
                    MenuComponent,
                ],
                providers: [
                    AssetService,
                    PixiService
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { AssetService, FilterComponent, FilterDirective, MenuComponent, PixiModule, PixiService, SpriteComponent, SpriteComponent as ɵa, FilterComponent as ɵb, FilterDirective as ɵc, MenuComponent as ɵd, AssetService as ɵe, PixiService as ɵf };
//# sourceMappingURL=ngxpixi.js.map
