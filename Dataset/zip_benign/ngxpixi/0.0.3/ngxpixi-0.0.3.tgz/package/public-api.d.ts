export * from './lib/providers';
export * from './lib/components';
export { PixiModule } from './lib/ngxpixi.module';
