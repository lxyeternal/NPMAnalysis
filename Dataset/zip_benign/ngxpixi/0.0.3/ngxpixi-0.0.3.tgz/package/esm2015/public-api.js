/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of ngxpixi
 */
export { AssetService, PixiService } from './lib/providers';
export { FilterComponent, FilterDirective, SpriteComponent, MenuComponent } from './lib/components';
export { PixiModule } from './lib/ngxpixi.module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL25neHBpeGkvIiwic291cmNlcyI6WyJwdWJsaWMtYXBpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFJQSwwQ0FBYyxpQkFBaUIsQ0FBQztBQUNoQyxpRkFBYyxrQkFBa0IsQ0FBQztBQUNqQyxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sc0JBQXNCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogUHVibGljIEFQSSBTdXJmYWNlIG9mIG5neHBpeGlcbiAqL1xuXG5leHBvcnQgKiBmcm9tICcuL2xpYi9wcm92aWRlcnMnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvY29tcG9uZW50cyc7XG5leHBvcnQgeyBQaXhpTW9kdWxlIH0gZnJvbSAnLi9saWIvbmd4cGl4aS5tb2R1bGUnO1xuIl19