export declare class PixiModule {
}
