export declare class FilterDirective {
    container: any;
    filterConfig: any;
    _filterConfig: {
        type: string;
    };
    filter: any;
    constructor();
    ngOnInit(): void;
    initFilter(): void;
    applyConfig(): void;
    applyFilter(): void;
    wipeFilter(): void;
    ngOnDestroy(): void;
    getAvailableFilters(): string[];
}
