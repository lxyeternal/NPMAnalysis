import * as PIXI from "pixi.js";
export declare class SpriteComponent {
    handleClick: any;
    imgUrl: string;
    frameName: string;
    scale: number;
    font: string;
    fontSize: string;
    strokeColor: string;
    interactive: boolean;
    _x: number;
    x: number;
    _y: number;
    y: number;
    text: string;
    valueToShow: string;
    container: PIXI.Container;
    anim: string;
    anchor: {
        x: number;
        y: number;
    };
    tAnchor: {
        x: number;
        y: number;
    };
    spriteStage: PIXI.Container;
    textSpr: PIXI.Text;
    spriteObject: PIXI.Sprite;
    constructor();
    ngOnInit(): void;
    init(): void;
    addSprite(img: any, frame: any): void;
    positionSprite(): void;
    addText(text: any): void;
    addInteraction(cb: any): void;
    slowHover(): void;
    hoverUp(): void;
    hoverDown(): void;
    explodeOut(): Promise<{}>;
    ngOnDestroy(): void;
}
