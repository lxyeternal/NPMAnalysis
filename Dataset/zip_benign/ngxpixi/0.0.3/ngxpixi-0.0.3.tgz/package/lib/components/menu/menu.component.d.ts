import * as PIXI from "pixi.js";
export declare class MenuComponent {
    container: PIXI.Container;
    menuContainer: PIXI.Container;
    itemHeight: number;
    itemWidth: number;
    x: number;
    y: number;
    w: number;
    h: number;
    rowLength: number;
    isGrid: boolean;
    isScrollable: boolean;
    dragPoint: {
        x: number;
        y: number;
    };
    mouseDown: boolean;
    dragging: boolean;
    constructor();
    ngOnInit(): void;
    positionContainer(event?: any): void;
    initMenuContainer(): void;
    initInteraction(): void;
    getViewport(): {
        min: number;
        max: number;
    };
    distanceFromCenter(i: number): number;
    positionItems(): void;
    sizeItem(i: any): number;
    calculateItemPosition(i: number): {
        x: number;
        y: number;
        scale: number;
    };
    stageMouseDown(event: any): void;
    stageMouseUp(event: any): void;
    stageMove(event: any): void;
    calcPosition(newP: any): void;
}
