import * as React from 'react';
export interface NucleusProps {
    layerCount: number;
    particlesPerLayer: number;
    particleFillColor: string;
    particleBorderColor: string;
    particleBorderWidth: number;
    particleSize: number;
    distanceFromCenter: number;
    orbitTime: number;
    nucleusMaskOverlap: boolean;
}
declare const Nucleus: (props: NucleusProps) => React.JSX.Element;
export default Nucleus;
