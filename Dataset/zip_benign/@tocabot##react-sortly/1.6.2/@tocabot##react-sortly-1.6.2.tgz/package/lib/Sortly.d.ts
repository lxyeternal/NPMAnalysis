import { Component, ElementType, ReactElement } from 'react';
import { SortlyItem } from './utils';
import { ItemRendererProps } from './Item';
export interface SortlyProps {
    items: SortlyItem[];
    itemRenderer: (props: ItemRendererProps) => ReactElement;
    onChange: (items: SortlyItem[]) => void;
    type?: string;
    component?: ElementType;
    threshold?: number;
    maxDepth?: number;
    cancelOnDragOutside?: boolean;
    cancelOnDropOutside?: boolean;
    onMove?: Function;
    onDragStart?: Function;
    onDragEnd?: Function;
    onDrop?: Function;
    monitor?: {
        getItem: Function;
        didDrop: Function;
    };
    isOver?: boolean;
    connectDropTarget?: Function;
}
declare class SortlyComponent extends Component<SortlyProps> {
    static defaultProps: Omit<SortlyProps, 'items' | 'itemRenderer' | 'onChange'>;
    state: {
        items: SortlyItem[];
        draggingDescendants: {};
    };
    private originalItems;
    componentWillReceiveProps(nextProps: SortlyProps): void;
    handleDragStart: (dragIndex: number) => void;
    handleDragEnd: (dragIndex: number, didDrop: boolean) => void;
    handleMove: (dragIndex: number, hoverIndex: number, offsetX: number) => number;
    handleEnter: () => void;
    handleLeave: () => void;
    handleDrop: (dragIndex: number, dropIndex: number) => void;
    change: () => void;
    render(): any;
}
export declare const Sortly: import("react-dnd").DndComponentClass<typeof SortlyComponent, Pick<SortlyProps, "type" | "onDragStart" | "onDragEnd" | "onMove" | "onDrop" | "maxDepth" | "items" | "itemRenderer" | "onChange" | "component" | "threshold" | "cancelOnDragOutside" | "cancelOnDropOutside">>;
export {};
