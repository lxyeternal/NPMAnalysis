import { Component, ReactElement } from 'react';
import { SortlyItem } from './utils';
export interface ItemProps extends ItemRendererProps {
    renderer: (props: ItemRendererProps) => ReactElement | null;
    onDragStart: Function;
    onDragEnd: Function;
    onMove: Function;
    onDrop: Function;
    isOver: boolean;
    dropTargetMonitor: {
        getItem: Function;
        getDifferenceFromInitialOffset: Function;
    };
    __dndType: string;
}
export interface ItemRendererProps extends SortlyItem {
    index?: number;
    maxDepth?: number;
    isClosestDragging?: boolean;
    isDragging?: boolean;
    connectDragSource: Function;
    connectDropTarget: Function;
}
declare class ItemComponent extends Component<ItemProps> {
    private reqAnimationFrameId;
    componentWillReceiveProps(nextProps: ItemProps): void;
    componentWillUnmount(): void;
    handleHover: () => void;
    render(): JSX.Element;
}
export declare const Item: import("react-dnd").DndComponentClass<import("react-dnd").DndComponentClass<typeof ItemComponent, Pick<ItemProps, "path" | "name" | "index" | "id" | "renderer" | "onDragStart" | "onDragEnd" | "onMove" | "onDrop" | "isOver" | "dropTargetMonitor" | "__dndType" | "maxDepth" | "isClosestDragging" | "connectDropTarget">>, Pick<Pick<ItemProps, "path" | "name" | "index" | "id" | "renderer" | "onDragStart" | "onDragEnd" | "onMove" | "onDrop" | "isOver" | "dropTargetMonitor" | "__dndType" | "maxDepth" | "isClosestDragging" | "connectDropTarget">, "path" | "name" | "index" | "id" | "renderer" | "onDragStart" | "onDragEnd" | "onMove" | "onDrop" | "__dndType" | "maxDepth" | "isClosestDragging">>;
export {};
