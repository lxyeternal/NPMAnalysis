export declare type ID = string | number;
export interface RawItem {
    id: ID;
    parentId: ID | null;
    index: number;
    name: string;
}
export interface SortlyItem {
    id: ID;
    name: string;
    path: ID[];
}
export interface TreeItem {
    id: ID;
    name: string;
    children: TreeItem[];
}
/**
 * Convert the raw item list to the Sortly item list
 */
export declare function convert(items: RawItem[], parentId?: ID, path?: ID[]): SortlyItem[];
/**
 * Convert the Sortly item list to the tree struct
 */
export declare function buildTree(items: SortlyItem[]): TreeItem[];
/**
 * Convert the Sortly item list to the raw item list
 * Useful when you want to convert the item list to store into database
 */
export declare function flatten(items: SortlyItem[]): RawItem[];
/**
 * Find item descendants
 */
export declare function findDescendants(items: SortlyItem[], index: number): SortlyItem[];
/**
 * Increase the tree item to 1 level depth
 */
export declare function increaseTreeItem(items: SortlyItem[], itemIndex: number): object | null;
/**
 * Decrease the tree item to 1 level depth
 */
export declare function decreaseTreeItem(items: SortlyItem[], itemIndex: number): object | null;
/**
 * Move an item to a new position
 * @param {Array} items The item list
 * @param {Number} sourceIndex The current position of the item to move
 * @param {Number} targetIndex The new position of the item to move
 * @return {{updateFn: {}, newIndex: number}}
 */
export declare function moveTreeItem(items: SortlyItem[], sourceIndex: number, targetIndex: number): {
    updateFn: object;
    newIndex: number;
};
/**
 * Add a new item to the bottom of the list
 */
export declare function add(items: SortlyItem[], itemData: Pick<SortlyItem, 'id' | 'name'>): SortlyItem[];
/**
 * Insert a new item to the list
 */
export declare function insert(items: SortlyItem[], targetIndex: number, itemData: Pick<SortlyItem, 'id' | 'name'>): SortlyItem[];
/**
 * Remove an item and it descendants from the list
 */
export declare function remove(items: SortlyItem[], index: number): SortlyItem[];
