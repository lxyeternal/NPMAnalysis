var holtwinters = require("./index.js")

var data = [1, 2, 1, 2, 1, 2, 1, 2]
var predictionLength = 2
var result = holtwinters(data, predictionLength)

console.log('1D', result)

var data = [[1.1,1634476927],[2,1634476937],[1.5,1634476947],[2,1634476957],[1,1634476967],[1,1634476977],[1,1634476987],[2,1634476997]]
var predictionLength = 4
var result = holtwinters(data, predictionLength)

console.log('2D', result)
