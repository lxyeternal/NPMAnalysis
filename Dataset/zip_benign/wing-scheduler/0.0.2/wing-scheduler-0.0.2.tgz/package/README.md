# wing-scheduler

## Install

```bash
$ npm install wing-scheduler
```

## Usage

```js
import { Scheduler } from 'wing-scheduler';

// Or
<script src='/path/to/wing-scheduler/wing-scheduler.js'></script>;
const { Scheduler } = $WingScheduler;

function getData(n) {
  return new Promise((resolve, reject) => {
    console.log('执行中...', n);
    const random = Math.random();
    setTimeout(() => (random > 0.5 ? resolve(`OK_${n}`) : reject(`Error_${n}`)), random * 1000);
  });
}

function test() {
  const scheduler = new Scheduler(4);
  [...Array(17)].forEach((_, i) => {
    const p = scheduler.add(() => getData(i));
    p.then((v) => {
      console.log('执行中 成功', v);
    }).catch((e) => {
      console.log('执行中 失败', e);
    });
  });
}
```
