
Shopify is a powerful e-commerce platform that operates online and offline, providing businesses with the tools to create professional websites and robust online stores. Because of its widespread popularity, Shopify-based online stores often become prime targets for data scraping for [strategic marketing & advertising decisions](https://scrape-it.cloud/blog/web-scraping-in-e-commerce).

Our Shopify Node API offers a seamless solution, allowing you to get data from these Shopify stores without the need to navigate the complexities of web scraping, proxy configuration, or bypassing potential blocks.

With this Shopify API Node NPM you can focus on leveraging valuable data and maximizing the potential of your business.

## Install

`npm install @scrapeit-cloud/shopify-api`

## API Key

To use this NPM package, you need a Scrape-It.Cloud API key. Follow the steps below to get started:

1. Visit the Scrape-It.Cloud website at [https://scrape-it.cloud](https://scrape-it.cloud/).
2. Sign up to get your API key and some credits for free.

Now you can use this API key to work with Shopify NPM.

## Use

Here's a simple example of using the library to get collection information in a Shopify store:

```javascript
const  ShopifyAPI = require('@scrapeit-cloud/shopify-api');
const  shopifyApi = new  ShopifyAPI('INSERT_YOUR_API_KEY');

const  main = async () => {
  try {
    const result = await shopifyApi.collections({
      url: 'https://libertasbella.com',
    })

    console.log(result)
  } catch(e) {
    if (e.validationErrors) {
      console.log(e.validationErrors)
    }

    console.log(e.message)
  }
};

main();
```

The Shopify API NPM requires the following parameter:

- url (string): The URL of the Shopify store.

You can also use our Shopify API to get product information:

```javascript
const  ShopifyAPI = require('@scrapeit-cloud/shopify-api');
const  shopifyApi = new  ShopifyAPI('INSERT_YOUR_API_KEY');

const  main = async () => {
  try {
    const result = await shopifyApi.products({
      url: 'https://libertasbella.com',
      limit: 250,
      page: 1,
      collection: '1984'
    })

    console.log(result)
  } catch(e) {
    if (e.validationErrors) {
      console.log(e.validationErrors)
    }

    console.log(e.message)
  }
};

main();
```

Shopify API NPM provides the following optional parameters for getting products:

- limit (number, optional): The maximum number of products to retrieve. This parameter is limited to a range between 1 and 250.
- page (number, optional): The page number of the results to retrieve. This parameter is limited to a range starting from 1 and up to the maximum safe integer value.
- collection (string, optional): The collection handle to filter the products. Provide the collection handle as a string.

Please refer to the API documentation for more detailed information about available methods.

## How to use Shopify Node API for Scraping

We developed the Shopify API NodeJS to simplify scraping information from online Shopify stores. To use it, you must install the NPM package and use NodeJS to write a little code to save the data obtained with the API.

If you are not very good at programming but need to get data, you can use no-code [Scrape-It.Cloud Shopify scraper](https://scrape-it.cloud/scrapers/shopify). In this case, you won't need programming skills, and you'll get all the necessary data in a convenient format as a file.
