/// <reference types="node" />
import { Keypair } from "./keypair";
import { PrivateKey } from "./privateKey";
import { PublicKey } from "./publicKey";
import { Signature } from "./signature";
export { Keypair, PrivateKey, PublicKey, Signature };
export { init as initBLS } from "./context";
/**
 * Generates new secret and public key
 */
export declare function generateKeyPair(): Keypair;
/**
 * Generates public key from given secret.
 * @param {BLSSecretKey} secretKey
 */
export declare function generatePublicKey(secretKey: Uint8Array): Buffer;
/**
 * Signs given message using secret key.
 * @param secretKey
 * @param messageHash
 */
export declare function sign(secretKey: Uint8Array, messageHash: Uint8Array): Buffer;
/**
 * Compines all given signature into one.
 * @param signatures
 */
export declare function aggregateSignatures(signatures: Uint8Array[]): Buffer;
/**
 * Combines all given public keys into single one
 * @param publicKeys
 */
export declare function aggregatePubkeys(publicKeys: Uint8Array[]): Buffer;
/**
 * Verifies if signature is message signed with given public key.
 * @param publicKey
 * @param messageHash
 * @param signature
 */
export declare function verify(publicKey: Uint8Array, messageHash: Uint8Array, signature: Uint8Array): boolean;
/**
 * Verifies if aggregated signature is same message signed with given public keys.
 * @param publicKeys
 * @param messageHash
 * @param signature
 */
export declare function verifyAggregate(publicKeys: Uint8Array[], messageHash: Uint8Array, signature: Uint8Array): boolean;
/**
 * Verifies if signature is list of message signed with corresponding public key.
 * @param publicKeys
 * @param messageHashes
 * @param signature
 * @param fast Check if all messages are different
 */
export declare function verifyMultiple(publicKeys: Uint8Array[], messageHashes: Uint8Array[], signature: Uint8Array, fast?: boolean): boolean;
declare const _default: {
    generateKeyPair: typeof generateKeyPair;
    generatePublicKey: typeof generatePublicKey;
    sign: typeof sign;
    aggregateSignatures: typeof aggregateSignatures;
    aggregatePubkeys: typeof aggregatePubkeys;
    verify: typeof verify;
    verifyAggregate: typeof verifyAggregate;
    verifyMultiple: typeof verifyMultiple;
};
export default _default;
