/// <reference types="node" />
import { PrivateKey } from "./privateKey";
import { PublicKeyType } from "@bitgo/eth2-bls-wasm";
import { Signature } from "./signature";
export declare class PublicKey {
    private value;
    protected constructor(value: PublicKeyType);
    static fromPrivateKey(privateKey: PrivateKey): PublicKey;
    static fromBytes(bytes: Uint8Array): PublicKey;
    static fromHex(value: string): PublicKey;
    static fromPublicKeyType(value: PublicKeyType): PublicKey;
    add(other: PublicKey): PublicKey;
    verifyMessage(signature: Signature, messageHash: Uint8Array): boolean;
    toBytesCompressed(): Buffer;
    toHexString(): string;
    getValue(): PublicKeyType;
}
