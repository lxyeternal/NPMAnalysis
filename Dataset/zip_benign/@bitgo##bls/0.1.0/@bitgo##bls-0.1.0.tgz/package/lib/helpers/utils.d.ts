/// <reference types="node" />
/**
 * Pads byte array with zeroes on left side up to desired length.
 * Throws if source is larger than desired result.
 * @param source
 * @param length
 */
export declare function padLeft(source: Uint8Array, length: number): Buffer;
export declare const EMPTY_PUBLIC_KEY: Buffer;
export declare const EMPTY_SIGNATURE: Buffer;
