/// <reference types="node" />
import { SignatureType } from "@bitgo/eth2-bls-wasm";
import { PublicKey } from "./publicKey";
export declare class Signature {
    private value;
    protected constructor(value: SignatureType);
    static fromCompressedBytes(value: Uint8Array): Signature;
    static fromValue(signature: SignatureType): Signature;
    static aggregate(signatures: Signature[]): Signature;
    add(other: Signature): Signature;
    getValue(): SignatureType;
    verifyAggregate(publicKeys: PublicKey[], message: Uint8Array): boolean;
    verifyMultiple(publicKeys: PublicKey[], messages: Uint8Array[], fast?: boolean): boolean;
    toBytesCompressed(): Buffer;
    toHex(): string;
}
