import { PublicKey } from "./publicKey";
import { PrivateKey } from "./privateKey";
export declare class Keypair {
    private readonly _publicKey;
    private readonly _privateKey;
    constructor(privateKey: PrivateKey, publicKey?: PublicKey);
    get publicKey(): PublicKey;
    get privateKey(): PrivateKey;
    static generate(): Keypair;
}
