export declare const SECRET_KEY_LENGTH = 32;
export declare const SIGNATURE_LENGTH = 96;
export declare const FP_POINT_LENGTH = 48;
export declare const PUBLIC_KEY_LENGTH = 48;
export declare const G2_HASH_PADDING = 16;
