import bls from "@bitgo/eth2-bls-wasm";
declare type Bls = typeof bls;
export declare function setupBls(): Promise<Bls>;
export declare function init(): Promise<Bls>;
export declare function destroy(): void;
export declare function getContext(): Bls;
export {};
