/// <reference types="node" />
import { SecretKeyType } from "@bitgo/eth2-bls-wasm";
import { PublicKey } from "./publicKey";
import { Signature } from "./signature";
export declare class PrivateKey {
    private value;
    protected constructor(value: SecretKeyType);
    static fromBytes(bytes: Uint8Array): PrivateKey;
    static fromHexString(value: string): PrivateKey;
    static fromInt(num: number): PrivateKey;
    static random(): PrivateKey;
    getValue(): SecretKeyType;
    signMessage(message: Uint8Array): Signature;
    toPublicKey(): PublicKey;
    toBytes(): Buffer;
    toHexString(): string;
}
