# Change Log

## 1.0.2

### Patch Changes

- Updated dependencies
  [[`e73878ee`](https://github.com/chakra-xui/chakra-xui/commit/e73878ee686c11d3f94ad6ac61b19ae9508d75a5)]:
  - @chakra-xui/utils@1.0.2

## 1.0.1

### Patch Changes

- Updated dependencies
  [[`5c482483`](https://github.com/chakra-xui/chakra-xui/commit/5c482483ce24fc798540c9792a15e06772eae213)]:
  - @chakra-xui/utils@1.0.1

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0 (2020-11-13)

**Note:** Version bump only for package @chakra-xui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-rc.8 (2020-10-29)

### Bug Fixes

- **toast:** allow custom render in update
  ([eb8bff9](https://github.com/chakra-xui/chakra-xui/commit/eb8bff911e6ec9de0165ab1e8f5ca10d5e022459)),
  closes [#2362](https://github.com/chakra-xui/chakra-xui/issues/2362)

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-rc.7 (2020-10-25)

**Note:** Version bump only for package @chakra-xui/clickable

# 1.0.0-rc.6 (2020-10-25)

**Note:** Version bump only for package @chakra-xui/clickable

# 1.0.0-rc.5 (2020-09-27)

**Note:** Version bump only for package @chakra-xui/clickable

# 1.0.0-rc.4 (2020-09-25)

**Note:** Version bump only for package @chakra-xui/clickable

# 1.0.0-rc.3 (2020-08-30)

**Note:** Version bump only for package @chakra-xui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-rc.2 (2020-08-09)

**Note:** Version bump only for package @chakra-xui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-rc.1](https://github.com/chakra-xui/chakra-xui/compare/@chakra-xui/clickable@1.0.0-rc.0...@chakra-xui/clickable@1.0.0-rc.1) (2020-08-06)

**Note:** Version bump only for package @chakra-xui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-rc.0](https://github.com/chakra-xui/chakra-xui/compare/@chakra-xui/clickable@1.0.0-next.7...@chakra-xui/clickable@1.0.0-rc.0) (2020-07-26)

**Note:** Version bump only for package @chakra-xui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-next.7](https://github.com/chakra-xui/chakra-xui/compare/@chakra-xui/clickable@1.0.0-next.6...@chakra-xui/clickable@1.0.0-next.7) (2020-07-26)

### Bug Fixes

- prevent issue where right click triggers active css state
  ([4ea9b88](https://github.com/chakra-xui/chakra-xui/commit/4ea9b8872599168f7a6ecb078b62f3473a25b4d8))
- types issue in use-tabs
  ([c388927](https://github.com/chakra-xui/chakra-xui/commit/c38892760257b9bbf1b63c05f7f9ccf1684a90b0))

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-next.6](https://github.com/chakra-xui/chakra-xui/compare/@chakra-xui/clickable@1.0.0-next.5...@chakra-xui/clickable@1.0.0-next.6) (2020-07-15)

**Note:** Version bump only for package @chakra-xui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-next.5](https://github.com/chakra-xui/chakra-xui/compare/@chakra-xui/clickable@1.0.0-next.4...@chakra-xui/clickable@1.0.0-next.5) (2020-07-15)

**Note:** Version bump only for package @chakra-xui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-next.4 (2020-07-01)

### Bug Fixes

- [#891](https://github.com/chakra-xui/chakra-xui/issues/891)
  ([e107acc](https://github.com/chakra-xui/chakra-xui/commit/e107acc8487898a965b0d695c1da71f46fc56d5e))
- ts issue with sx prop
  ([d3b1340](https://github.com/chakra-xui/chakra-xui/commit/d3b1340cb255937927b4d4c56ce218141570b951))

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-next.3 (2020-06-28)

### Bug Fixes

- [#891](https://github.com/chakra-xui/chakra-xui/issues/891)
  ([e107acc](https://github.com/chakra-xui/chakra-xui/commit/e107acc8487898a965b0d695c1da71f46fc56d5e))
- ts issue with sx prop
  ([d3b1340](https://github.com/chakra-xui/chakra-xui/commit/d3b1340cb255937927b4d4c56ce218141570b951))

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-next.2 (2020-06-21)

### Bug Fixes

- [#891](https://github.com/chakra-xui/chakra-xui/issues/891)
  ([e107acc](https://github.com/chakra-xui/chakra-xui/commit/e107acc8487898a965b0d695c1da71f46fc56d5e))
