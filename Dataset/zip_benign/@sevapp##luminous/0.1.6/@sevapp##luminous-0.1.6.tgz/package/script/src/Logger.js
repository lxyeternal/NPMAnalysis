"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logger = void 0;
const Level_js_1 = require("./Level.js");
const OptionsBuilder_js_1 = require("./OptionsBuilder.js");
/**
 * Logger class for logging messages
 * @class Logger
 * @property {string} name
 * @property {Level} level
 * @property {string} uuid
 */
// deno-lint-ignore ban-types
class Logger {
    constructor(options = new OptionsBuilder_js_1.OptionsBuilder().build(), postfix = '') {
        Object.defineProperty(this, "parents", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'default'
        });
        Object.defineProperty(this, "postfix", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: ''
        });
        Object.defineProperty(this, "loggingLevel", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: Level_js_1.Level.TRACE
        });
        Object.defineProperty(this, "uuid", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'ABCDEF'
        });
        Object.defineProperty(this, "listOfFormatterAndTransports", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        this.parents = options.parents;
        this.name = options.name;
        this.postfix = postfix;
        this.loggingLevel = options.loggingLevel;
        this.listOfFormatterAndTransports.push(...options.listOfFormatterAndTransports);
    }
    /**
     * Log
     * @param {Level} level
     * @param {string} text
     * @returns {string}
     */
    def(level, msg, metadata) {
        const msgString = typeof msg === 'object' ? msg.join(' ') : msg;
        this.listOfFormatterAndTransports.forEach((combination) => {
            const data = {
                parents: this.parents,
                name: this.name,
                postfix: this.postfix,
                level,
                msg: msgString,
                metadata,
            };
            const logString = combination.formatter.format(data);
            combination.transports.forEach((transport) => {
                transport.send(level, logString, data);
            });
        });
        return msgString;
    }
    /**
     * Trace
     * @param {string} msg message
     * @returns {string} message
     */
    trc(msg, metadata = {}) {
        return this.def(Level_js_1.Level.TRACE, msg, metadata);
    }
    /**
     * Debug
     * @param {string} msg message
     * @returns {string} message
     */
    dbg(msg, metadata = {}) {
        return this.def(Level_js_1.Level.DEBUG, msg, metadata);
    }
    /**
     * Verbose
     * @param {string} msg message
     * @returns {string} message
     */
    vrb(msg, metadata = {}) {
        return this.def(Level_js_1.Level.VERBOSE, msg, metadata);
    }
    /**
     * Info
     * @param {string} msg message
     * @returns {string} message
     */
    inf(msg, metadata = {}) {
        return this.def(Level_js_1.Level.INFO, msg, metadata);
    }
    /**
     * User
     * @param {string} msg message
     * @returns {string} message
     */
    usr(msg, metadata = {}) {
        return this.def(Level_js_1.Level.USER, msg, metadata);
    }
    /**
     * Warn
     * @param {string} msg message
     * @returns {string} message
     */
    wrn(msg, metadata = {}) {
        return this.def(Level_js_1.Level.WARN, msg, metadata);
    }
    /**
     * Error
     * @param {string} msg message
     * @returns {string} message
     */
    err(msg, metadata = {}) {
        if (msg instanceof Error) {
            return this.def(Level_js_1.Level.ERROR, msg.message, {
                stack: msg.stack,
                ...metadata,
            });
        }
        else {
            return this.def(Level_js_1.Level.ERROR, msg, metadata);
        }
    }
    /**
     * Fatal
     * @param {string} msg message
     * @returns {string} message
     */
    ftl(msg, metadata = {}) {
        return this.def(Level_js_1.Level.FATAL, msg, metadata);
    }
}
exports.Logger = Logger;
