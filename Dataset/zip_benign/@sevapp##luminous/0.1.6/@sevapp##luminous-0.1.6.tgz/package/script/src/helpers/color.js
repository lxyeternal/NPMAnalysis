"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.colorStringByLevel = void 0;
const deps_js_1 = require("../../deps.js");
const Level_js_1 = require("../Level.js");
/**
 * Color string by level of log message (for console)
 * @param level
 * @param message
 * @returns string with ANSI color codes
 */
const colorStringByLevel = (level, message) => {
    return {
        [Level_js_1.Level.TRACE]: deps_js_1.colors.gray,
        [Level_js_1.Level.DEBUG]: deps_js_1.colors.blue,
        [Level_js_1.Level.VERBOSE]: deps_js_1.colors.cyan,
        [Level_js_1.Level.INFO]: deps_js_1.colors.green,
        [Level_js_1.Level.USER]: deps_js_1.colors.white,
        [Level_js_1.Level.WARN]: deps_js_1.colors.yellow,
        [Level_js_1.Level.ERROR]: deps_js_1.colors.magenta,
        [Level_js_1.Level.FATAL]: deps_js_1.colors.bgBrightRed,
    }[level](message);
};
exports.colorStringByLevel = colorStringByLevel;
