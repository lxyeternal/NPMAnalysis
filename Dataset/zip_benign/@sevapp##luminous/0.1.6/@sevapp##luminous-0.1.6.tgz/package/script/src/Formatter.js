"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AbstractFormatter = void 0;
/**
 * AbstractFormatter is the base class for all formatters.
 */
class AbstractFormatter {
    constructor(options, defaultOptions) {
        Object.defineProperty(this, "options", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: {}
        });
        this.options = defaultOptions;
        for (const [key, value] of Object.entries(options)) {
            if (this.options[key] !== undefined) {
                // deno-lint-ignore ban-ts-comment
                // @ts-ignore
                this.options[key] = value;
            }
        }
    }
}
exports.AbstractFormatter = AbstractFormatter;
