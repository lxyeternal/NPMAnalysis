"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LevelShortName = exports.Level = void 0;
/**
 * Level - The level of the log message
 */
var Level;
(function (Level) {
    Level[Level["TRACE"] = 0] = "TRACE";
    Level[Level["DEBUG"] = 1] = "DEBUG";
    Level[Level["VERBOSE"] = 2] = "VERBOSE";
    Level[Level["INFO"] = 3] = "INFO";
    Level[Level["USER"] = 4] = "USER";
    Level[Level["WARN"] = 5] = "WARN";
    Level[Level["ERROR"] = 6] = "ERROR";
    Level[Level["FATAL"] = 7] = "FATAL";
})(Level = exports.Level || (exports.Level = {}));
/**
 * LevelName - The short name of the level
 */
exports.LevelShortName = {
    [Level.TRACE]: 'TRC',
    [Level.DEBUG]: 'DBG',
    [Level.VERBOSE]: 'VRB',
    [Level.INFO]: 'INF',
    [Level.USER]: 'USR',
    [Level.WARN]: 'WRN',
    [Level.ERROR]: 'ERR',
    [Level.FATAL]: 'FTL',
};
