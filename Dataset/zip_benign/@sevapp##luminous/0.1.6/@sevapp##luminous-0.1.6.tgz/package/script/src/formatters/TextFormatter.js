"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TextFormatter = void 0;
const Formatter_js_1 = require("../Formatter.js");
const color_js_1 = require("../helpers/color.js");
const time_js_1 = require("../helpers/time.js");
const Level_js_1 = require("../Level.js");
/**
 * TextFormatter
 * @class TextFormatter
 * @extends Formatter
 * @property {ITextFormatterOptions} options
 */
class TextFormatter extends Formatter_js_1.AbstractFormatter {
    constructor(options = {}) {
        super(options, {
            showMetadata: false,
            colorize: true,
            showTimestamp: true,
            timestampPattern: 'HH:mm:ss.SSS',
        });
    }
    format(data) {
        const time = (0, time_js_1.formatDate)(new Date(), this.options.timestampPattern);
        const meta = Object.keys(data.metadata).length > 0 &&
            this.options.showMetadata
            ? JSON.stringify(data.metadata, null, 2)
            : '';
        const logString = (this.options.showTimestamp ? `${time} ` : '') +
            ` [${Level_js_1.LevelShortName[data.level]}] ${[...data.parents, data.name].join('.')} ${data.postfix}${data.uuid ? ` <${data.uuid}>` : ''}: ${data.msg} ${meta}\n`;
        return this.options.colorize
            ? (0, color_js_1.colorStringByLevel)(data.level, logString)
            : logString;
    }
}
exports.TextFormatter = TextFormatter;
