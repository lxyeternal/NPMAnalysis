"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogfareTransport = void 0;
const dntShim = __importStar(require("../../_dnt.shims.js"));
const Transport_js_1 = require("../Transport.js");
/**
 * LogfareTransport
 * @class LogfareTransport
 * @extends Transport
 * @property {boolean} showMetadata
 */
class LogfareTransport extends Transport_js_1.AbstractTransport {
    constructor(options) {
        super(options, {
            source: '',
            xApiKey: '',
            hostName: 'unknown',
        });
    }
    send(_level, msg, data) {
        try {
            dntShim.fetch('https://api.logflare.app/api/logs', {
                method: 'POST',
                headers: {
                    'X-API-KEY': this.options.xApiKey,
                    'Content-Type': 'application/json',
                    'User-Agent': `Cloudflare Worker via ${this.options.hostName}`,
                },
                body: JSON.stringify({
                    source: this.options.source,
                    event_message: msg,
                    level: _level,
                    metadata: data,
                }),
            }).catch((e) => console.error(e));
        }
        catch (e) {
            console.error(e);
        }
    }
}
exports.LogfareTransport = LogfareTransport;
