"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TextFormatter = exports.JsonFormatter = void 0;
var JsonFormatter_js_1 = require("./JsonFormatter.js");
Object.defineProperty(exports, "JsonFormatter", { enumerable: true, get: function () { return JsonFormatter_js_1.JsonFormatter; } });
var TextFormatter_js_1 = require("./TextFormatter.js");
Object.defineProperty(exports, "TextFormatter", { enumerable: true, get: function () { return TextFormatter_js_1.TextFormatter; } });
