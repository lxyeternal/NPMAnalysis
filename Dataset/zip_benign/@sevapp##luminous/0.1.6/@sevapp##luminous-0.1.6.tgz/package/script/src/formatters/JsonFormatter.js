"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JsonFormatter = void 0;
const Formatter_js_1 = require("../Formatter.js");
const time_js_1 = require("../helpers/time.js");
/**
 * JsonFormatter
 * @class JsonFormatter
 * @extends Formatter
 * @property {IJsonFormatterOptions} options
 */
class JsonFormatter extends Formatter_js_1.AbstractFormatter {
    constructor(options = {}) {
        super(options, {
            timestampPattern: 'yyyy-MM-dd HH:mm:ss',
        });
    }
    format(data) {
        const time = (0, time_js_1.formatDate)(new Date(), this.options.timestampPattern);
        return JSON.stringify({
            time,
            ...data,
        });
    }
}
exports.JsonFormatter = JsonFormatter;
