"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OptionsBuilder = void 0;
const Level_js_1 = require("./Level.js");
const TextFormatter_js_1 = require("./formatters/TextFormatter.js");
const Terminal_js_1 = require("./transports/Terminal.js");
/**
 * OptionsBuilder
 * @class OptionsBuilder
 * @property {string} name
 * @property {Level} level
 * @property {LoggerOptions} parent
 * @property {Level[]} excludedLoggingLevels
 * @property {Transport[]} transports
 */
class OptionsBuilder {
    constructor() {
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: undefined
        });
        Object.defineProperty(this, "parent", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: void 0
        });
        Object.defineProperty(this, "loggingLevel", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: undefined
        });
        Object.defineProperty(this, "excludedLoggingLevels", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
        Object.defineProperty(this, "listOfFormatterAndTransports", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: []
        });
    }
    /**
     * Set the name of the logger
     * @param name
     * @returns {OptionsBuilder}
     */
    setName(name) {
        this.name = name;
        return this;
    }
    /**
     * Exclude a level from the logger
     * @param level
     * @returns {OptionsBuilder}
     */
    excludeLevel(level) {
        this.excludedLoggingLevels.push(level);
        return this;
    }
    /**
     * Exclude levels from the logger
     * @param levels
     * @returns {OptionsBuilder}
     */
    excludeLevels(levels) {
        this.excludedLoggingLevels = this.excludedLoggingLevels.concat(levels);
        return this;
    }
    /**
     * Set the minimal level of the logger (default: Level.TRACE)
     * @param level
     * @returns {OptionsBuilder}
     */
    setLoggingLevel(level) {
        this.loggingLevel = level;
        return this;
    }
    /**
     * Set the default the logger options
     * @param parent
     * @returns
     */
    inherit(parent) {
        this.parent = parent;
        return this;
    }
    /**
     * Add a transport to the logger
     * @param transport
     * @returns {OptionsBuilder}
     */
    addTransport(
    // deno-lint-ignore no-explicit-any
    formatter, 
    // deno-lint-ignore no-explicit-any
    transport) {
        this.listOfFormatterAndTransports.push({
            formatter,
            transports: [transport],
        });
        return this;
    }
    /**
     * Add transports to the logger
     * @param formatter
     * @param transports
     * @returns {OptionsBuilder}
     */
    addTransports(
    // deno-lint-ignore no-explicit-any
    formatter, 
    // deno-lint-ignore no-explicit-any
    transports) {
        this.listOfFormatterAndTransports.push({ formatter, transports });
        return this;
    }
    /**
     * Build the logger options
     * @returns {object} LoggerOptions
     */
    build() {
        const listOfFormatterAndTransports = [
            ...this.listOfFormatterAndTransports,
            ...this.parent?.listOfFormatterAndTransports || [],
        ];
        const parents = [];
        if (this.parent) {
            parents.push(...this.parent.parents);
            parents.push(this.parent.name);
        }
        return {
            parents: parents,
            name: this.name || this.parent?.name || 'default',
            loggingLevel: this.parent?.loggingLevel || this.loggingLevel ||
                Level_js_1.Level.TRACE,
            excludedLoggingLevels: Array.from(new Set([
                ...this.excludedLoggingLevels,
                ...this.parent?.excludedLoggingLevels || [],
            ])),
            listOfFormatterAndTransports: listOfFormatterAndTransports.length
                ? listOfFormatterAndTransports
                : [
                    {
                        formatter: new TextFormatter_js_1.TextFormatter(),
                        transports: [new Terminal_js_1.TerminalTransport()],
                    },
                ],
        };
    }
}
exports.OptionsBuilder = OptionsBuilder;
