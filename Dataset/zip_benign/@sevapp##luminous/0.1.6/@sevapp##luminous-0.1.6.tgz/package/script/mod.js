"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.log = void 0;
const helpers = __importStar(require("./src/helpers/mod.js"));
const transports = __importStar(require("./src/transports/mod.js"));
const formatters = __importStar(require("./src/formatters/mod.js"));
const OptionsBuilder_js_1 = require("./src/OptionsBuilder.js");
const Logger_js_1 = require("./src/Logger.js");
const Level_js_1 = require("./src/Level.js");
const luminous = {
    helpers,
    Level: Level_js_1.Level,
    transports,
    formatters,
    OptionsBuilder: OptionsBuilder_js_1.OptionsBuilder,
    Logger: Logger_js_1.Logger,
};
exports.log = new Logger_js_1.Logger();
exports.default = luminous;
