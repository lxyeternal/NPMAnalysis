import * as helpers from './src/helpers/mod.js';
import * as transports from './src/transports/mod.js';
import * as formatters from './src/formatters/mod.js';
import { OptionsBuilder } from './src/OptionsBuilder.js';
import { Logger } from './src/Logger.js';
import { Level } from './src/Level.js';
declare const luminous: {
    helpers: typeof helpers;
    Level: typeof Level;
    transports: typeof transports;
    formatters: typeof formatters;
    OptionsBuilder: typeof OptionsBuilder;
    Logger: typeof Logger;
};
export declare const log: Logger<{}>;
export default luminous;
