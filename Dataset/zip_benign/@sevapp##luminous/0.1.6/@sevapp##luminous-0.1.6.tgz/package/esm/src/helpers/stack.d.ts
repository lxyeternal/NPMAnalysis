/**
 * Get last function name from stack trace
 * @param {number} depth depth of stack trace
 * @returns {string} current function name
 */
export declare function getCallerFunctionName(depth?: number): string | undefined;
/**
 * Get file name from stack trace and return it
 * @param {number} depth depth of stack trace
 * @returns {string} current file name
 */
export declare function getCallerFileName(depth?: number): string | undefined;
