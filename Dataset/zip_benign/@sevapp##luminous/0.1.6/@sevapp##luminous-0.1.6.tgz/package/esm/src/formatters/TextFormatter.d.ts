import { AbstractFormatter, IDataForFormatting } from '../Formatter.js';
/**
 * ITextFormatterOptions
 * @interface ITextFormatterOptions
 * @property {boolean} colorize - default true
 * @property {boolean} showMetadata - default true
 * @property {string} timestampPattern - default 'yyyy-MM-dd HH:mm:ss'
 */
interface ITextFormatterOptions {
    showMetadata?: boolean;
    colorize?: boolean;
    showTimestamp?: boolean;
    timestampPattern?: string;
}
/**
 * TextFormatter
 * @class TextFormatter
 * @extends Formatter
 * @property {ITextFormatterOptions} options
 */
export declare class TextFormatter extends AbstractFormatter<ITextFormatterOptions> {
    constructor(options?: {});
    format(data: IDataForFormatting): string;
}
export {};
