import { AbstractFormatter } from './Formatter.js';
import { FormatterAndTransports, LoggerOptions } from './Logger.js';
import { AbstractTransport } from './Transport.js';
import { Level } from './Level.js';
/**
 * OptionsBuilder
 * @class OptionsBuilder
 * @property {string} name
 * @property {Level} level
 * @property {LoggerOptions} parent
 * @property {Level[]} excludedLoggingLevels
 * @property {Transport[]} transports
 */
export declare class OptionsBuilder {
    name: string | undefined;
    parent?: LoggerOptions;
    loggingLevel: Level | undefined;
    excludedLoggingLevels: Level[];
    listOfFormatterAndTransports: FormatterAndTransports[];
    /**
     * Set the name of the logger
     * @param name
     * @returns {OptionsBuilder}
     */
    setName(name: string): OptionsBuilder;
    /**
     * Exclude a level from the logger
     * @param level
     * @returns {OptionsBuilder}
     */
    excludeLevel(level: Level): OptionsBuilder;
    /**
     * Exclude levels from the logger
     * @param levels
     * @returns {OptionsBuilder}
     */
    excludeLevels(levels: Level[]): OptionsBuilder;
    /**
     * Set the minimal level of the logger (default: Level.TRACE)
     * @param level
     * @returns {OptionsBuilder}
     */
    setLoggingLevel(level: Level): OptionsBuilder;
    /**
     * Set the default the logger options
     * @param parent
     * @returns
     */
    inherit(parent: LoggerOptions): this;
    /**
     * Add a transport to the logger
     * @param transport
     * @returns {OptionsBuilder}
     */
    addTransport(formatter: AbstractFormatter<any>, transport: AbstractTransport<any>): OptionsBuilder;
    /**
     * Add transports to the logger
     * @param formatter
     * @param transports
     * @returns {OptionsBuilder}
     */
    addTransports(formatter: AbstractFormatter<any>, transports: AbstractTransport<any>[]): OptionsBuilder;
    /**
     * Build the logger options
     * @returns {object} LoggerOptions
     */
    build(): LoggerOptions;
}
