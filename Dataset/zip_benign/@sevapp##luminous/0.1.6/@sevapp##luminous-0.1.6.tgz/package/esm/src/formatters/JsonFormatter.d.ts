import { AbstractFormatter, IDataForFormatting } from '../Formatter.js';
/**
 * IJsonFormatterOptions
 * @interface IJsonFormatterOptions
 * @property {string} timestampPattern - default 'yyyy-MM-dd HH:mm:ss'
 */
interface IJsonFormatterOptions {
    timestampPattern?: string;
}
/**
 * JsonFormatter
 * @class JsonFormatter
 * @extends Formatter
 * @property {IJsonFormatterOptions} options
 */
export declare class JsonFormatter extends AbstractFormatter<IJsonFormatterOptions> {
    constructor(options?: {});
    format(data: IDataForFormatting): string;
}
export {};
