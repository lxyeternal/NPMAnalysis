import { Level } from './Level.js';
/**
 * IDataToFormat is the data that is passed to the formatter.
 * The formatter can use this data to format the log message.
 */
export interface IDataForFormatting {
    parents: Array<string>;
    name: string;
    postfix: string;
    level: Level;
    uuid?: string;
    msg: string;
    metadata?: any;
}
/**
 * AbstractFormatter is the base class for all formatters.
 */
export declare abstract class AbstractFormatter<O extends {
    [key: string]: any;
}> {
    options: Required<O>;
    constructor(options: {
        [K in keyof O]?: O[K];
    }, defaultOptions: Required<O>);
    /**
     * format formats the data to a string.
     * @param {IDataToFormat} _data
     * @returns {string} The formatted string.
     */
    abstract format(_data: IDataForFormatting): string;
}
