/**
 * Level - The level of the log message
 */
export declare enum Level {
    TRACE = 0,
    DEBUG = 1,
    VERBOSE = 2,
    INFO = 3,
    USER = 4,
    WARN = 5,
    ERROR = 6,
    FATAL = 7
}
/**
 * LevelName - The short name of the level
 */
export declare const LevelShortName: {
    0: string;
    1: string;
    2: string;
    3: string;
    4: string;
    5: string;
    6: string;
    7: string;
};
