/**
 * Get current date in timezone
 * @param {string} timezone
 * @returns {Date} date in timezone
 */
export declare function getCurrentDateInTimezone(timezone: string): Date;
/**
 * Format date with pattern string
 * @param {Date} date date object
 * @param {string} pattern pattern string
 * @returns {string} formatted date string
 */
export declare function formatDate(date: Date, pattern: string): string;
/**
 * Timezone constants
 */
export declare const Timeszone: {
    Europe: {
        Moscow: string;
        London: string;
        Paris: string;
        Berlin: string;
        Kiev: string;
        Rome: string;
        Madrid: string;
        Amsterdam: string;
        Stockholm: string;
        Vienna: string;
        Warsaw: string;
    };
    Africa: {
        Nairobi: string;
        Cairo: string;
        Johannesburg: string;
        Algiers: string;
        Casablanca: string;
        Lagos: string;
        Khartoum: string;
        Tunis: string;
    };
    America: {
        Toronto: string;
        NewYork: string;
        Chicago: string;
        LosAngeles: string;
        Vancouver: string;
        MexicoCity: string;
        Lima: string;
        Bogota: string;
    };
    Asia: {
        Almaty: string;
        Oral: string;
        Yerevan: string;
        Dubai: string;
        Kabul: string;
        Karachi: string;
        Tashkent: string;
        Dhaka: string;
        Colombo: string;
        Bangkok: string;
        Hanoi: string;
        Jakarta: string;
    };
};
