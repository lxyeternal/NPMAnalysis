import { AbstractTransport } from '../Transport.js';
import { Level } from '../Level.js';
import { IDataForFormatting } from '../Formatter.js';
interface LogfareTransportOptions {
    source: string;
    xApiKey: string;
    hostName?: string;
}
/**
 * LogfareTransport
 * @class LogfareTransport
 * @extends Transport
 * @property {boolean} showMetadata
 */
export declare class LogfareTransport extends AbstractTransport<LogfareTransportOptions> {
    constructor(options: LogfareTransportOptions);
    send(_level: Level, msg: string, data: IDataForFormatting): void;
}
export {};
