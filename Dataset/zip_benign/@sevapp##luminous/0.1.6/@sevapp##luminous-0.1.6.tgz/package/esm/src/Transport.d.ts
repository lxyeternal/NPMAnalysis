import { IDataForFormatting } from './Formatter.js';
import { Level } from './Level.js';
export declare abstract class AbstractTransport<O extends {
    [key: string]: any;
}> {
    options: Required<O>;
    constructor(options: { [K in keyof O]?: O[K] | undefined; } | undefined, defaultOptions: Required<O>);
    abstract send(level: Level, log: string, data: IDataForFormatting): void;
}
