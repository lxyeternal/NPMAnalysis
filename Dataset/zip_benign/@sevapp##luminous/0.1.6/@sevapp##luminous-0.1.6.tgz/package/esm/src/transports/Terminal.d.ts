import { AbstractTransport } from '../Transport.js';
import { Level } from '../Level.js';
interface TerminalTransportOptions {
}
/**
 * TerminalTransport
 * @class TerminalTransport
 * @extends Transport
 * @property {boolean} showMetadata
 */
export declare class TerminalTransport extends AbstractTransport<TerminalTransportOptions> {
    constructor(options?: TerminalTransportOptions);
    send(level: Level, msg: string): void;
}
export {};
