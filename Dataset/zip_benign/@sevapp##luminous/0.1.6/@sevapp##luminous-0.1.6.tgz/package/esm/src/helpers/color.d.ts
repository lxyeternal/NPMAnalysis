import { Level } from '../Level.js';
/**
 * Color string by level of log message (for console)
 * @param level
 * @param message
 * @returns string with ANSI color codes
 */
export declare const colorStringByLevel: (level: Level, message: string) => string;
