import { AbstractFormatter } from './Formatter.js';
import { AbstractTransport } from './Transport.js';
import { Level } from './Level.js';
export type MessageType = string | TemplateStringsArray;
export type FormatterAndTransports = {
    formatter: AbstractFormatter<any>;
    transports: AbstractTransport<any>[];
};
export interface LoggerOptions {
    parents: Array<string>;
    name: string;
    loggingLevel: Level;
    excludedLoggingLevels: Level[];
    listOfFormatterAndTransports: FormatterAndTransports[];
}
/**
 * Logger class for logging messages
 * @class Logger
 * @property {string} name
 * @property {Level} level
 * @property {string} uuid
 */
export declare class Logger<MT = {}> {
    parents: Array<string>;
    name: string;
    postfix: string;
    loggingLevel: Level;
    uuid: string;
    listOfFormatterAndTransports: FormatterAndTransports[];
    constructor(options?: LoggerOptions, postfix?: string);
    /**
     * Log
     * @param {Level} level
     * @param {string} text
     * @returns {string}
     */
    def(level: Level, msg: MessageType, metadata: MT): string;
    /**
     * Trace
     * @param {string} msg message
     * @returns {string} message
     */
    trc(msg: MessageType, metadata?: MT): string;
    /**
     * Debug
     * @param {string} msg message
     * @returns {string} message
     */
    dbg(msg: MessageType, metadata?: MT): string;
    /**
     * Verbose
     * @param {string} msg message
     * @returns {string} message
     */
    vrb(msg: MessageType, metadata?: MT): string;
    /**
     * Info
     * @param {string} msg message
     * @returns {string} message
     */
    inf(msg: MessageType, metadata?: MT): string;
    /**
     * User
     * @param {string} msg message
     * @returns {string} message
     */
    usr(msg: MessageType, metadata?: MT): string;
    /**
     * Warn
     * @param {string} msg message
     * @returns {string} message
     */
    wrn(msg: MessageType, metadata?: MT): string;
    /**
     * Error
     * @param {string} msg message
     * @returns {string} message
     */
    err(msg: MessageType | Error, metadata?: MT): string;
    /**
     * Fatal
     * @param {string} msg message
     * @returns {string} message
     */
    ftl(msg: MessageType, metadata?: MT): string;
}
