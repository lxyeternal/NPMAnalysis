export * as colors from './deps/deno.land/std@0.177.0/fmt/colors.js';
export { printf } from './deps/deno.land/std@0.177.0/fmt/printf.js';
