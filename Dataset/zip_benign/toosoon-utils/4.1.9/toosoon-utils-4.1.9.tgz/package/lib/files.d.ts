/**
 * Download a Blob object into user files
 *
 * @param {Blob} blob       Blob object to download
 * @param {string} filename Downloaded file name
 */
export declare function download(blob: Blob, filename: string): void;
/**
 * Upload a file from user files
 *
 * @param {Function} onLoad    Callback called once the file is loaded
 * @param {string} [accept=''] MIME type the file input should accept
 */
export declare function upload(onLoad: (dataUrl: string) => void, accept?: string): void;
