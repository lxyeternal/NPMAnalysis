/**
 * Check if a number is even
 *
 * @param {number} value Value to check
 * @returns {boolean} True if the given number is even, false otherwise
 */
export declare function isEven(value: number): boolean;
/**
 * Check if a number is odd
 *
 * @param {number} value Value to check
 * @returns {boolean} True if the given number is odd, false otherwise
 */
export declare function isOdd(value: number): boolean;
/**
 * Check if a number is a power of 2
 *
 * @param {number} value Value to check
 * @returns {boolean} True if the given number is a power of 2, false otherwise
 */
export declare function isPowerOf2(value: number): boolean;
/**
 * Find closest power of 2 that fits a number
 *
 * @param {number} value         Incoming value
 * @param {string} [mode='ceil'] Can be 'floor' | 'ceil' | 'round'
 * @returns {number} Power of 2
 */
export declare function toPowerOf2(value: number, mode?: 'floor' | 'ceil' | 'round'): number;
/**
 * Return the sign (positive or negative) of a number
 *
 * @param {number} value Value to check
 * @returns {number} 1 if the given number is positive, -1 if it is negative, otherwise 0
 */
export declare function sign(value: number): number;
/**
 * Clamp a value between two bounds
 *
 * @param {number} value   Value to clamp
 * @param {number} [min=0] Minimum boundary
 * @param {number} [max=1] Maximum boundary
 * @returns {number} Clamped value
 */
export declare function clamp(value: number, min?: number, max?: number): number;
/**
 * Linear interpolation between two values (lerping)
 *
 * @param {number} t   Normalized time value to interpolate
 * @param {number} min Minimum value
 * @param {number} max Maximum value
 * @returns {number} Lerped value
 */
export declare function lerp(t: number, min: number, max: number): number;
/**
 * Triangular interpolation between two values
 *
 * @param {number} t      Normalized time value to interpolate
 * @param {number} min    Minimum value
 * @param {number} max    Maximum value
 * @param {number} target Triangle target value
 * @returns {number} Interpolated value
 */
export declare function triLerp(t: number, min: number, max: number, target: number): number;
/**
 * Exponential interpolation between two values
 *
 * @param {number} t          Normalized time value to interpolate
 * @param {number} currentMin Lower bound of the value's current range
 * @param {number} currentMax Upper bound of the value's current range
 * @param {number} targetMin  Lower bound of the value's target range
 * @param {number} targetMax  Upper bound of the value's target range
 * @returns {number} Interpolated value
 */
export declare function expLerp(t: number, currentMin: number, currentMax: number, targetMin: number, targetMax: number): number;
/**
 * Normalize a value between two bounds
 *
 * @param {number} value Value to normalize
 * @param {number} min   Minimum boundary
 * @param {number} max   Maximum boundary
 * @returns {number} Normalized value
 */
export declare function normalize(value: number, min: number, max: number): number;
/**
 * Re-map a number from one range to another
 *
 * @param {number} value      Value to re-map
 * @param {number} currentMin Lower bound of the value's current range
 * @param {number} currentMax Upper bound of the value's current range
 * @param {number} targetMin  Lower bound of the value's target range
 * @param {number} targetMax  Upper bound of the value's target range
 * @returns {number} Re-mapped value
 */
export declare function map(value: number, currentMin: number, currentMax: number, targetMin: number, targetMax: number): number;
/**
 * Round a number up to a nearest multiple
 *
 * @param {number} value        Value to round
 * @param {number} [multiple=1] Multiple to round to
 * @returns {number} Closest multiple
 */
export declare function snap(value: number, multiple?: number): number;
/**
 * Modulo absolute a value based on a length
 *
 * @param {number} value  Value to modulate
 * @param {number} length Total length
 * @returns {number} Modulated value
 */
export declare function modAbs(value: number, length: number): number;
/**
 * Move back and forth a value between 0 and length, so that it is never larger than length and never smaller than 0
 *
 * @param {number} value  Value to modulate
 * @param {number} length Total length
 * @returns {number} PingPonged value
 */
export declare function pingPong(value: number, length: number): number;
/**
 * Smooth a value using cubic Hermite interpolation
 *
 * @param {number} value   Value to smooth
 * @param {number} [min=0] Minimum boundary
 * @param {number} [max=1] Maximum boundary
 * @returns {number} Normalized smoothed value
 */
export declare function smoothstep(value: number, min?: number, max?: number): number;
/**
 * Re-map the [0, 1] interval into [0, 1] parabola, such that corners are remaped to 0 and the center to 1
 * -> parabola(0) = parabola(1) = 0, and parabola(0.5) = 1
 *
 * @param {number} x         Normalized coordinate on X axis
 * @param {number} [power=1] Parabola power
 * @returns {number} Normalized re-mapped value
 */
export declare function parabola(x: number, power?: number): number;
/**
 * Return the sum of numbers
 *
 * @param {number[]} array Array of numbers
 * @returns {number} Total sum
 */
export declare function sum(array: number[]): number;
/**
 * Return the average of numbers
 *
 * @param {number[]} array Array of numbers
 * @returns {number} Total average
 */
export declare function average(array: number[]): number;
/**
 * Smoothly interpolate a number toward another
 *
 * @param {number} value   Value to interpolate
 * @param {number} target  Destination of the interpolation
 * @param {number} damping A higher value will make the movement more sudden, and a lower value will make the movement more gradual
 * @param {number} delta   Delta time (in seconds)
 * @returns {number} Interpolated number
 */
export declare function damp(value: number, target: number, damping: number, delta: number): number;
