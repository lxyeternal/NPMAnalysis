import type { Point, Point3 } from './types';
/**
 * Generate a random boolean (true or false)
 *
 * @param {number} [probability=0.5] Probability to get true
 * @returns {boolean} Either `true` or `false`
 */
export declare function randomBoolean(probability?: number): boolean;
/**
 * Generate a random sign (1 or -1)
 *
 * @param {number} [probability=0.5] Probability to get 1
 * @returns {number} Either 1 or -1
 */
export declare function randomSign(probability?: number): number;
/**
 * Generate a random floating-point number within a specified range
 *
 * @param {number} [min=0]       Minimum boundary
 * @param {number} [max=1]       Maximum boundary
 * @param {number} [precision=2] Number of digits after the decimal point
 * @returns {number} Generated float
 */
export declare function randomFloat(min?: number, max?: number, precision?: number): number;
/**
 * Generate a random integer number within a specified range
 *
 * @param {number} min Minimum boundary
 * @param {number} max Maximum boundary
 * @returns {number} Generated integer
 */
export declare function randomInt(min: number, max: number): number;
/**
 * Generate a random hexadecimal color
 *
 * @returns {string} Generated hexadecimal color
 */
export declare function randomHexColor(): string;
/**
 * Pick a random item from a given array
 *
 * @param {T[]} array Array to pick the item from
 * @returns {T|undefined} Random item picked
 */
export declare function randomItem<T = unknown>(array: T[]): T | undefined;
/**
 * Pick a random property value from a given object
 *
 * @param {object} object Object to pick the property from
 * @returns {T|undefined} Random item picked
 */
export declare function randomObjectProperty<T = unknown>(object: Record<string, T>): T | undefined;
/**
 * Select a random index from an array of weighted items
 *
 * @param {number[]} weights Array of weights
 * @returns {number} Random index based on weights
 */
export declare function randomIndex(weights: number[]): number;
/**
 * Generate a random number fitting a Gaussian (normal) distribution
 *
 * @param {number} [mean=0]   Central value
 * @param {number} [spread=1] Standard deviation
 * @returns {number} Generated number
 */
export declare function randomGaussian(mean?: number, spread?: number): number;
/**
 * Produce a random 2D point around the perimiter of a unit circle
 *
 * @param  {number} [radius=1] Radius of the circle
 * @param  {Point} [target]    Target point
 * @returns {Point} Random 2D point on circle
 */
export declare function onCircle(radius?: number, target?: Point): Point;
/**
 * Produce a random 2D point inside a unit circle
 *
 * @param  {number} [radius=1] Radius of the circle
 * @param  {Point} [target]    Target vector
 * @returns {Point} Random 2D point inside circle
 */
export declare function insideCircle(radius?: number, target?: Point): Point;
/**
 * Produce a random 3D point on the surface of a unit sphere
 *
 * @param  {number} [radius=1] Radius of the sphere
 * @param  {Point3} [target]   Target vector
 * @returns {Point3} Random 3D point on sphere
 */
export declare function onSphere(radius?: number, target?: Point3): Point3;
/**
 * Produce a random 3D point inside a unit sphere
 *
 * @param  {number} [radius=1] Radius of the sphere
 * @param  {Point3} [target]   Target vector
 * @returns {Point3} Random 3D point inside sphere
 */
export declare function insideSphere(radius?: number, target?: Point3): Point3;
