import type { ColorRepresentation } from '../../types';
export type ColorScaleSettings = {
    colorSpace: 'rgb';
} | {
    colorSpace: 'hsl';
    hueOffset?: number;
    saturationOffset?: number;
    lightnessOffset?: number;
} | {
    colorSpace: 'hsb';
    hueOffset?: number;
    saturationOffset?: number;
    brightnessOffset?: number;
} | {
    colorSpace: 'hcl';
    mode?: 'qualitative' | 'sequential' | 'diverging';
    triangular?: number;
    powerStrength?: number;
    hueOffset?: number;
    chromaOffset?: number;
    luminanceOffset?: number;
};
export declare const defaultSettings: Required<ColorScaleSettings>;
/**
 * Utility class for generating color scales and interpolating between colors
 *
 * @exports
 * @class ColorScale
 */
export default class ColorScale {
    /**
     * Array of colors composing the color scale
     */
    colors: Array<[number, number, number]>;
    /**
     * @param {ColorRepresentation} input     Input color representation
     * @param {ColorRepresentation} target    Target color representation
     * @param {number} [length=5]             Amount of colors composing the color scale
     * @param {ColorScaleSettings} [settings] Color scale generation settings
     */
    constructor(input: ColorRepresentation, target: ColorRepresentation, length?: number, settings?: ColorScaleSettings);
    /**
     * Static method for generating a color scale
     *
     * @param {ColorRepresentation} input     Input color representation
     * @param {ColorRepresentation} target    Target color representation
     * @param {number} length                 Amount of colors composing the color scale
     * @param {ColorScaleSettings} [settings] Color scale generation settings
     * @returns {Array<[number, number, number]>} Color scale colors
     */
    static generate(input: ColorRepresentation, target: ColorRepresentation, length: number, settings?: ColorScaleSettings): Array<[number, number, number]>;
    /**
     * Static method for interpolating between colors
     *
     * @param {[number,number,number]} inputColor  Input color
     * @param {[number,number,number]} targetColor Target color
     * @param {number} value                       Interpolation normalized value
     * @param {ColorScaleSettings} [settings]      Color scale settings
     * @returns {[number,number,number]} Interpolated color
     */
    static interpolate(inputColor: [number, number, number], targetColor: [number, number, number], value: number, settings?: ColorScaleSettings): [number, number, number];
}
