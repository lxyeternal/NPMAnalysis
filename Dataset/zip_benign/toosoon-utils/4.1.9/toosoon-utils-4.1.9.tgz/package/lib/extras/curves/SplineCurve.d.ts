import type { Point } from '../../types';
import Curve from './Curve';
/**
 * Utility class for manipulating splines
 *
 * @exports
 * @class SplineCurve
 * @extends Curve
 */
export default class SplineCurve extends Curve {
    readonly type: string;
    points: Point[];
    /**
     * @param {Point[]} [points] Array of points defining the curve
     */
    constructor(points?: Point[]);
    /**
     * Interpolate a point on the Spline curve
     *
     * @param {number} t Normalized time value to interpolate
     * @returns {Point} Interpolated coordinates on the curve
     */
    getPoint(t: number): Point;
}
