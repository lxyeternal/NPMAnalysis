import type { Point } from '../../types';
import Curve from './Curve';
/**
 * Utility class for manipulating ellipses
 *
 * @exports
 * @class EllipseCurve
 * @extends Curve
 */
export default class EllipseCurve extends Curve {
    readonly type: string;
    /**
     * X-axis coordinate of the center of the ellipse
     */
    cx: number;
    /**
     * Y-axis coordinate of the center of the ellipse
     */
    cy: number;
    /**
     * X-radius of the ellipse
     */
    rx: number;
    /**
     * Y-radius of the ellipse
     */
    ry: number;
    /**
     * Rotation angle of the ellipse (in radians), counterclockwise from the positive X-axis
     */
    rotation: number;
    /**
     * Start angle of the arc (in radians)
     */
    startAngle: number;
    /**
     * End angle of the arc (in radians)
     */
    endAngle: number;
    /**
     * Flag indicating the direction of the arc
     */
    counterclockwise: boolean;
    /**
     * @param {number} cx X-axis coordinate of the center of the ellipse
     * @param {number} cy Y-axis coordinate of the center of the ellipse
     * @param {number} rx X-radius of the ellipse
     * @param {number} ry Y-radius of the ellipse
     * @param {number} [rotation]   Rotation angle of the ellipse (in radians), counterclockwise from the positive X-axis
     * @param {number} [startAngle] Rotation angle of the arc (in radians)
     * @param {number} [endAngle]   Rotation angle of the arc (in radians)
     * @param {boolean} [counterclockwise] Flag indicating the direction of the arc
     */
    constructor(cx: number, cy: number, rx: number, ry: number, rotation?: number, startAngle?: number, endAngle?: number, counterclockwise?: boolean);
    /**
     * Interpolate a point on the Ellipse curve
     *
     * @abstract
     * @param {number} t Normalized time value to interpolate
     * @returns {Point} Interpolated coordinates on the curve
     */
    getPoint(t: number): Point;
}
