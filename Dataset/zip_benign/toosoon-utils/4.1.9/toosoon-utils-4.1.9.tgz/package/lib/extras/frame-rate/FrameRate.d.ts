/**
 * Utility class for controlling FPS calls
 *
 * @exports
 * @class FrameRate
 */
export default class FrameRate {
    private _fps;
    private _interval;
    private _time;
    private _elapsedTime;
    private _lastUpdate;
    /**
     * @param {number} [fps=30] Frame per second limit
     */
    constructor(fps?: number);
    /**
     * Return true if elapsed time since last update is higher than current FPS
     *
     * @returns {boolean}
     */
    update(): boolean;
    get fps(): number;
    set fps(fps: number);
}
