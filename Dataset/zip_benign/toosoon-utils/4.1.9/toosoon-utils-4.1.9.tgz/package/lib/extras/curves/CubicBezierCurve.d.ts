import type { Point } from '../../types';
import Curve from './Curve';
/**
 * Utility class for manipulating Cubic Bézier curves
 *
 * @exports
 * @class CubicBezierCurve
 * @extends Curve
 */
export default class CubicBezierCurve extends Curve {
    readonly type: string;
    /**
     * X-axis coordinate of the start point
     */
    x1: number;
    /**
     * Y-axis coordinate of the start point
     */
    y1: number;
    /**
     * X-axis coordinate of the first control point
     */
    cp1x: number;
    /**
     * Y-axis coordinate of the first control point
     */
    cp1y: number;
    /**
     * X-axis coordinate of the second control point
     */
    cp2x: number;
    /**
     * Y-axis coordinate of the second control point
     */
    cp2y: number;
    /**
     * X-axis coordinate of the end point
     */
    x2: number;
    /**
     * Y-axis coordinate of the end point
     */
    y2: number;
    /**
     * @param {number} x1   X-axis coordinate of the start point
     * @param {number} y1   Y-axis coordinate of the start point
     * @param {number} cp1x X-axis coordinate of the first control point
     * @param {number} cp1y Y-axis coordinate of the first control point
     * @param {number} cp2x X-axis coordinate of the second control point
     * @param {number} cp2y Y-axis coordinate of the second control point
     * @param {number} x2   X-axis coordinate of the end point
     * @param {number} y2   Y-axis coordinate of the end point
     */
    constructor(x1: number, y1: number, cp1x: number, cp1y: number, cp2x: number, cp2y: number, x2: number, y2: number);
    /**
     * Interpolate a point on the Cubic Bézier curve
     *
     * @param {number} t Normalized time value to interpolate
     * @returns {Point} Interpolated coordinates on the curve
     */
    getPoint(t: number): Point;
}
