import type { Point } from '../../types';
import Curve from './Curve';
/**
 * Utility class for manipulating Quadratic Bézier curves
 *
 * @exports
 * @class QuadraticBezierCurve
 * @extends Curve
 */
export default class QuadraticBezierCurve extends Curve {
    readonly type: string;
    /**
     *  X-axis coordinate of the start point
     */
    x1: number;
    /**
     *  Y-axis coordinate of the start point
     */
    y1: number;
    /**
     * X-axis coordinate of the control point
     */
    cpx: number;
    /**
     * Y-axis coordinate of the control point
     */
    cpy: number;
    /**
     *  X-axis coordinate of the end point
     */
    x2: number;
    /**
     *  Y-axis coordinate of the end point
     */
    y2: number;
    /**
     * @param {number} x1  X-axis coordinate of the start point
     * @param {number} y1  Y-axis coordinate of the start point
     * @param {number} cpx X-axis coordinate of the control point
     * @param {number} cpy Y-axis coordinate of the control point
     * @param {number} x2  X-axis coordinate of the end point
     * @param {number} y2  Y-axis coordinate of the end point
     */
    constructor(x1: number, y1: number, cpx: number, cpy: number, x2: number, y2: number);
    /**
     * Interpolate a point on the Quadratic Bézier curve
     *
     * @param {number} t Normalized time value to interpolate
     * @returns {Point} Interpolated coordinates on the curve
     */
    getPoint(t: number): Point;
}
