import type { Point } from '../../types';
import Curve from '../curves/Curve';
/**
 * Utility class for manipulating connected curves
 *
 * @exports
 * @class Path
 * @extends Curve
 */
export default class Path extends Curve {
    readonly isPath = true;
    readonly type: string;
    /**
     * Array of curves composing the path
     */
    curves: Curve[];
    /**
     * Array of points composing the path
     */
    points: Point[];
    autoClose: boolean;
    /**
     * Add a curve to this curve path
     *
     * @param {Curve} curve Curve to add
     */
    add(curve: Curve): void;
    /**
     * Interpolate a point on the curve path
     *
     * @param {number} t Normalized time value to interpolate
     * @returns {Point|null} Interpolated coordinates on the curve
     */
    getPoint(t: number): Point;
    /**
     * Compute the curve shape into an array of points
     *
     * @param {number} [divisions=40] Number of divisions
     * @returns {Point[]}
     */
    getPoints(divisions?: number): Point[];
    /**
     * Compute the curve shape into an array of equi-spaced points across the entire curve path
     *
     * @param {number} [divisions=40] Number of divisions
     * @returns {Point[]}
     */
    getSpacedPoints(divisions?: number): Point[];
    /**
     * Compute the total arc length of the curve path
     *
     * @returns {number}
     */
    getLength(): number;
    /**
     * Compute the cumulative curve lengths of the curve path
     *
     * @returns {number[]}
     */
    getCurveLengths(): number[];
    /**
     * Update the cached cumulative segment lengths
     */
    updateArcLengths(): void;
}
