import type { Point } from '../../types';
/**
 * Utility abstract class for manipulating curves
 *
 * @exports
 * @class Curve
 * @abstract
 */
export default abstract class Curve {
    readonly isCurve = true;
    readonly type: string;
    /**
     * Amount of divisions when calculating the cumulative segment lengths of a curve
     */
    arcLengthDivisions: number;
    /**
     * Must be set to `true` if the curve parameters have changed
     */
    needsUpdate: boolean;
    protected _cacheArcLengths: number[];
    /**
     * Interpolate a point on the curve
     *
     * @abstract
     * @param {number} t Normalized time value to interpolate
     * @returns {Point} Interpolated coordinates on the curve
     */
    abstract getPoint(t: number): Point;
    /**
     * Interpolate a point on the curve
     *
     * @param {number} u Normalized position value to interpolate
     * @returns {Point} Interpolated coordinates on the curve
     */
    getPointAt(u: number): Point;
    /**
     * Compute the curve shape into an array of points
     *
     * @param {number} [divisions=5] Number of divisions
     * @returns {Point[]}
     */
    getPoints(divisions?: number): Point[];
    /**
     * Compute the curve shape into an array of equi-spaced points across the entire curve
     *
     * @param {number} [divisions=5] Number of divisions
     * @returns {Point[]}
     */
    getSpacedPoints(divisions?: number): Point[];
    /**
     * Compute the total arc length of the curve
     *
     * @returns {number}
     */
    getLength(): number;
    /**
     * Compute the cumulative segment lengths of the curve
     *
     * @param {number} [divisions=this.arcLengthDivisions] Number of divisions
     * @returns {number[]}
     */
    getLengths(divisions?: number): number[];
    /**
     * Update the cached cumulative segment lengths
     */
    updateArcLengths(): void;
    /**
     * Re-map a normalized position value into normalized time
     *
     * @param {number} u 								 Normalized position value to interpolate
     * @param {number} [targetArcLength] Distance on the curve
     * @returns {number} Updated interpolation value
     */
    getUtoTmapping(u: number, targetArcLength?: number): number;
    /**
     * Compute an unit vector tangent for the given normalized time value
     *
     * @param {number} t Normalized time value
     * @returns {[number, number]} Tangent vector
     */
    getTangent(t: number): Point;
    /**
     * Compute an unit vector tangent for the given normalized position value
     *
     * @param {number} u Normalized position value
     * @returns {[number, number]} Tangent vector
     */
    getTangentAt(u: number): [number, number];
    /**
     * Static method to check if given points are defining a closed curve
     *
     * @param {Point[]} points Points to check
     * @returns {boolean} True if the curve is closed, false otherwise
     */
    static isClosed(points: Point[]): boolean;
}
