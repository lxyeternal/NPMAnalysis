import { Point } from '../../types';
import Path from './Path';
/**
 * Utility class for manipulating connected curves and generating SVG path
 *
 * It works by serializing 2D Canvas API to SVG path data
 *
 * @exports
 * @class PathSVG
 * @extends Path
 */
export default class PathSVG extends Path {
    /**
     * Resolution used for Catmul-Rom curve and Spline curve approximations
     */
    readonly curveResolution: number;
    constructor({ curveResolution }: {
        curveResolution?: number;
    });
    private _commands;
    moveTo(x: number, y: number): this;
    lineTo(x: number, y: number): this;
    polylineTo(points: Point[]): this;
    quadraticCurveTo(cpx: number, cpy: number, x2: number, y2: number): this;
    bezierCurveTo(cp1x: number, cp1y: number, cp2x: number, cp2y: number, x2: number, y2: number): this;
    catmulRomCurveTo(cp1x: number, cp1y: number, cp2x: number, cp2y: number, x2: number, y2: number): this;
    splineTo(points: Point[]): this;
    ellipse(cx: number, cy: number, rx: number, ry: number, rotation?: number, startAngle?: number, endAngle?: number, counterclockwise?: boolean): this;
    arc(cx: number, cy: number, radius: number, startAngle?: number, endAngle?: number, counterclockwise?: boolean): this;
    rect(x: number, y: number, width: number, height: number): this;
    closePath(): this;
    private _writeLineTo;
    private _writeArc;
    private _write;
    /**
     * Return SVG path data string
     *
     * @returns {string}
     */
    toString(): string;
}
