import type { Point } from '../../types';
import Curve from './Curve';
/**
 * Utility class for manipulating lines
 *
 * @exports
 * @class LineCurve
 * @extends Curve
 */
export default class LineCurve extends Curve {
    readonly type: string;
    /**
     * X-axis coordinate of the start point
     */
    x1: number;
    /**
     * Y-axis coordinate of the start point
     */
    y1: number;
    /**
     * X-axis coordinate of the end point
     */
    x2: number;
    /**
     * Y-axis coordinate of the end point
     */
    y2: number;
    /**
     * @param {number} x1 X-axis coordinate of the start point
     * @param {number} y1 Y-axis coordinate of the start point
     * @param {number} x2 X-axis coordinate of the end point
     * @param {number} y2 Y-axis coordinate of the end point
     */
    constructor(x1: number, y1: number, x2: number, y2: number);
    /**
     * Interpolate a point on the line
     *
     * @param {number} t Normalized time value to interpolate
     * @returns {Point} Interpolated coordinates on the line
     */
    getPoint(t: number): Point;
    getPointAt(u: number): Point;
    /**
     * Compute an unit vector tangent for the given normalized time value
     *
     * @param {number} t Normalized time value
     * @returns {[number, number]} Tangent vector
     */
    getTangent(t?: number): [number, number];
    getTangentAt(u: number): [number, number];
}
