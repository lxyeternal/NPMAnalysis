export type PoolSettings = {
    max?: number;
};
export declare const defaultSettings: Required<PoolSettings>;
type PoolItem = {
    setup?: () => void;
    reset?: () => void;
    dispose?: () => void;
};
/**
 * Abstract class for manipulating pool items
 *
 * @exports
 * @class Pool
 */
export default abstract class Pool<I extends PoolItem> {
    items: I[];
    pool: I[];
    settings: Required<PoolSettings>;
    constructor(settings?: PoolSettings);
    /**
     * Abstract method to implement custom item creation
     *
     * @returns {PoolItem}
     */
    protected abstract create(): I;
    /**
     * Add an item to the active items
     *
     * @param {PoolItem} item Item to add to the active items
     */
    protected add(item: I): void;
    /**
     * Remove an item from the active items
     *
     * @param {PoolItem} item Item to remove from the active items
     */
    protected remove(item: I): void;
    /**
     * Return an item from pool or create a new one
     *
     * @returns {PoolItem|undefined}
     */
    get(): I | undefined;
    /**
     * Release an item from the active items and add it to the pool
     *
     * @param {PoolItem} item Item to release
     */
    release(item: I): void;
    /**
     * Dispose all items
     */
    dispose(): void;
}
export {};
