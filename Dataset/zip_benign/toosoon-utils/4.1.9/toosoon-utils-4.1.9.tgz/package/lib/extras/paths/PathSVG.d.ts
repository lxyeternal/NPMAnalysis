import Curve from '../curves/Curve';
import LineCurve from '../curves/LineCurve';
import PolylineCurve from '../curves/PolylineCurve';
import QuadraticBezierCurve from '../curves/QuadraticBezierCurve';
import CubicBezierCurve from '../curves/CubicBezierCurve';
import CatmullRomCurve from '../curves/CatmullRomCurve';
import SplineCurve from '../curves/SplineCurve';
import EllipseCurve from '../curves/EllipseCurve';
import ArcCurve from '../curves/ArcCurve';
import PathContext from './PathContext';
export type SerializationParams = {
    curveResolution?: number;
};
/**
 * Utility class for manipulating connected curves and generating SVG path
 *
 * It works by serializing 2D Canvas API to SVG path data
 *
 * @exports
 * @class PathSVG
 * @extends PathContext
 */
export default class PathSVG extends PathContext {
    /**
     * Serialize a {@link Curve}
     *
     * @param {Curve} curve
     * @param {object} [params.curveResolution=5] Resolution used for Catmull-Rom curves and Spline curves approximations
     * @returns string
     */
    static serialize(curve: Curve, { curveResolution }?: SerializationParams): string;
    /**
     * Serialize a {@link LineCurve}
     *
     * @param {LineCurve} curve
     * @returns string
     */
    static serializeLineCurve(curve: LineCurve): string;
    /**
     * Serialize a {@link PolylineCurve}
     *
     * @param {PolylineCurve} curve
     * @returns string
     */
    static serializePolylineCurve(curve: PolylineCurve): string;
    /**
     * Serialize a {@link QuadraticBezierCurve}
     *
     * @param {QuadraticBezierCurve} curve
     * @returns string
     */
    static serializeQuadraticBezierCurve(curve: QuadraticBezierCurve): string;
    /**
     * Serialize a {@link CubicBezierCurve}
     *
     * @param {CubicBezierCurve} curve
     * @returns string
     */
    static serializeCubicBezierCurve(curve: CubicBezierCurve): string;
    /**
     * Serialize a {@link CatmullRomCurve}
     *
     * @param {CatmullRomCurve} curve
     * @param {object} params
     * @param {number} [params.curveResolution=5]
     * @returns string
     */
    static serializeCatmullRomCurve(curve: CatmullRomCurve, { curveResolution }: Pick<SerializationParams, 'curveResolution'>): string;
    /**
     * Serialize a {@link SplineCurve}
     *
     * @param {SplineCurve} curve
     * @param {object} params
     * @param {number} [params.curveResolution=5]
     * @returns string
     */
    static serializeSplineCurve(curve: SplineCurve, { curveResolution }: Pick<SerializationParams, 'curveResolution'>): string;
    /**
     * Serialize an {@link EllipseCurve}
     *
     * @param {EllipseCurve} curve
     * @returns string
     */
    static serializeEllipseCurve(curve: EllipseCurve): string;
    /**
     * Serialize an {@link ArcCurve}
     *
     * @param {ArcCurve} curve
     * @returns string
     */
    static serializeArcCurve(curve: ArcCurve): string;
    /**
     * Return SVG path data string
     *
     * @param {object} [params]
     * @param {object} [params.curveResolution=5] Resolution used for Catmull-Rom curves and Spline curves approximations
     * @returns {string}
     */
    toString(params?: SerializationParams): string;
}
