import { Deferred } from './types';
/**
 * No-op function
 */
export declare const noop: () => void;
/**
 * Promise wrapped setTimeout
 *
 * @param {number} [delay=0] Time to wait (in milliseconds)
 * @returns {Promise}
 */
export declare function wait(delay?: number): Promise<void>;
/**
 * Create a debounced function that delays the execution of `callback` until a specified `delay` time has passed since the last call
 *
 * @param {Function} callback Function to debounce
 * @param {number} delay      Delay (in milliseconds)
 * @returns {Function} Debounced function
 */
export declare function debounce<T extends (...args: any[]) => void>(callback: T, delay: number): (...args: Parameters<T>) => void;
/**
 * Check if a value is defined
 *
 * @param {any} value Value to check
 * @returns {boolean}
 */
export declare function isDefined<T>(value: T): value is Exclude<T, undefined | null>;
/**
 * Create a throttled function that limits the execution of `callback` to once every `limit` time
 *
 * @param {Function} callback Function to throttle
 * @param {number} limit      Minimum interval between two calls (in milliseconds)
 * @returns {Function} Throttled function
 */
export declare function throttle<T extends (...args: any[]) => void>(callback: T, limit: number): (...args: Parameters<T>) => void;
/**
 * Deferred promise implementation
 *
 * @returns {Deferred}
 */
export declare function defer<T = void>(): Deferred<T>;
/**
 * Polyfill for `now()` functions
 */
export declare let now: () => number;
