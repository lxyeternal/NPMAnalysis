import type { ColorRepresentation } from './types';
/**
 * Normalize a color representation into RGB
 *
 * @param {ColorRepresentation} color Color representation
 * @returns {[number,number,number]} Normalized RGB color
 */
export declare function normalizeColor(color: ColorRepresentation): [number, number, number];
/**
 * Normalize an hexadecimal string
 *
 * @param {string} hex Hexadecimal string
 * @returns {string} Normalized hexadecimal string
 */
export declare function normalizeHexString(hex: string): string;
/**
 * Convert RGB to hexadecimal
 * Note: rgb values are contained in the interval [0, 1]
 *
 * @param  {[number, number, number]} rgb RGB color
 * @returns {number} Hexadecimal color
 */
export declare function rgbToHex([r, g, b]: [number, number, number]): number;
/**
 * Convert RGB to hexadecimal string
 * Note: rgb values are contained in the interval [0, 1]
 *
 * @param  {[number, number, number]} rgb RGB color
 * @returns {string} Hexadecimal string
 */
export declare function rgbToHexString([r, g, b]: [number, number, number]): string;
/**
 * Convert hexadecimal to RGB
 * Note: rgb values are contained in the interval [0, 1]
 *
 * @param  {number|string} hex Hexadecimal color
 * @returns {[number, number, number]} RGB color
 */
export declare function hexToRgb(hex: number | string): [number, number, number];
/**
 * Lighten a color
 *
 * @param {string} hex        Hexadecimal string
 * @param {number} [amount=0] Amount of the color offset
 * @returns {string} Computed hexadecimal
 */
export declare function lighten(hex: string, amount?: number): string;
/**
 * Darken a color
 *
 * @param {string} hex        Hexadecimal string
 * @param {number} [amount=0] Amount of the color offset
 * @returns {string} Computed hexadecimal
 */
export declare function darken(hex: string, amount?: number): string;
/**
 * Normalize an HSL string
 * Note: hsl values are contained in the intervals H: [0, 360], S: [0, 1], L: [0, 1]
 *
 * @param  {string} hsl HSL string (format: 'hsl(360, 100%, 100%)')
 * @returns {[number, number, number]} Normalized HSL color
 */
export declare function normalizeHslString(hsl: string): [number, number, number];
/**
 * Convert RGB to HSL
 * Notes:
 *  - rgb values are contained in the interval [0, 1]
 *  - hsl values are contained in the intervals H: [0, 360], S: [0, 1], L: [0, 1]
 *
 * @param  {[number, number, number]} rgb RGB color
 * @returns {[number, number, number]} HSL color
 */
export declare function rgbToHsl([r, g, b]: [number, number, number]): [number, number, number];
/**
 * Convert HSL to RGB
 * Notes:
 *  - rgb values are contained in the interval [0, 1]
 *  - hsl values are contained in the intervals H: [0, 360], S: [0, 1], L: [0, 1]
 *
 * @param  {[number, number, number]} hsl HSL color
 * @returns {[number, number, number]} RGB color
 */
export declare function hslToRgb([h, s, l]: [number, number, number]): [number, number, number];
/**
 * Convert RGB to HSB
 * Notes:
 *  - rgb values are contained in the interval [0, 1]
 *  - hsb values are contained in the intervals H: [0, 360], S: [0, 1], B: [0, 1]
 *
 * @param  {[number, number, number]} rgb RGB color
 * @returns {[number, number, number]} HSB color
 */
export declare function rgbToHsb([r, g, b]: [number, number, number]): [number, number, number];
/**
 * Convert HSB to RGB
 * Notes:
 *  - rgb values are contained in the interval [0, 1]
 *  - hsb values are contained in the intervals H: [0, 360], S: [0, 1], B: [0, 1]
 *
 * @param  {[number, number, number]} hsb HSB color
 * @returns {[number, number, number]} RGB color
 */
export declare function hsbToRgb([h, s, b]: [number, number, number]): [number, number, number];
/**
 * Convert LAB to HCL
 * -> http://www.brucelindbloom.com/index.html?Eqn_Lab_to_LCH.html
 *
 * @param {[number, number, number]} lab LAB color
 * @returns {[number, number, number]} HCL color
 */
export declare function labToHcl([l, a, b]: [number, number, number]): [number, number, number];
/**
 * Convert HCL to LAB
 * -> http://www.brucelindbloom.com/index.html?Eqn_LCH_to_Lab.html
 *
 * @param {[number, number, number]} hcl HCL color
 * @returns {[number, number, number]} LAB color space
 */
export declare function hclToLab([h, c, l]: [number, number, number]): [number, number, number];
/**
 * Converts LAB to RGB
 *
 * @param {[number, number, number]} lab LAB color
 * @returns {[number, number, number]} RGB color
 */
export declare function labToRgb([l, a, b]: [number, number, number]): [number, number, number];
/**
 * Converts RGB to LAB
 *
 * @param {[number, number, number]} rgb RGB color
 * @returns {[number, number, number]} LAB color
 */
export declare function rgbToLab([r, g, b]: [number, number, number]): [number, number, number];
/**
 * Get the delta from two LAB colors
 *
 * @param {[number, number, number]} labA First LAB color
 * @param {[number, number, number]} labB Second LAB color
 * @returns {number} Delta
 */
export declare function deltaE(labA: [number, number, number], labB: [number, number, number]): number;
/**
 * Convert RGB to HCL
 *
 * @param {[number, number, number]} rgb RGB color
 * @returns {[number, number, number]} HCL color
 */
export declare function rgbToHcl([r, g, b]: [number, number, number]): [number, number, number];
/**
 * Converts HCL to RGB
 *
 * @param {[number, number, number]} hcl RGB color
 * @returns {[number, number, number]} RGB color
 */
export declare function hclToRgb([h, c, l]: [number, number, number]): [number, number, number];
