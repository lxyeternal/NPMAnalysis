/**
 * Produce a 128-bit hash value from a seed
 *
 * @param {string} seed Initial seed state
 * @returns {[number, number, number, number]} Hash numbers
 */
export declare function cyrb128(seed: string): [number, number, number, number];
/**
 * Simple Fast Counter, Generator with a 128-bit state
 *
 * @param {number} a
 * @param {number} b
 * @param {number} c
 * @param {number} d
 * @returns {number} Pseudo-random number
 */
export declare function sfc32(a: number, b: number, c: number, d: number): number;
/**
 * SplitMix32, Generator with a 32-bit state
 *
 * @param {number} a
 * @returns {number} Pseudo-random number
 */
export declare function splitmix32(a: number): number;
/**
 * Mulberry32, Generator with a 32-bit state
 *
 * @param {number} a
 * @returns {number} Pseudo-random number
 */
export declare function mulberry32(a: number): number;
/**
 * Jenkins' Small Fast, Generator with a 32-bit state
 *
 * @param {number} a
 * @returns {number} Pseudo-random number
 */
export declare function jsf32(a: number, b: number, c: number, d: number): number;
/**
 * xoshiro128**, Generator with a 128-bit state
 *
 * @param {number} a
 * @returns {number} Pseudo-random number
 */
export declare function xoshiro128ss(a: number, b: number, c: number, d: number): number;
export type PRNGParameters = string | {
    seed: string;
    algorithm: (...args: number[]) => number;
};
/**
 * Generate a pseudo-random number in the interval [0, 1]
 * PRNG equivalent of `Math.random()`
 *
 * @param {PRNGParameters} prng PRNG parameters
 * @returns {number} Pseudo-random number
 */
export declare function random(prng: PRNGParameters): number;
/**
 * Generate a pseudo-random boolean (true or false)
 *
 * @param {PRNGParameters} prng PRNG parameters
 * @param {number} [probability=0.5] Probability to get true
 * @returns {boolean} Either `true` or `false`
 */
export declare function randomBoolean(prng: PRNGParameters, probability?: number): boolean;
/**
 * Generate a pseudo-random sign (1 or -1)
 *
 * @param {PRNGParameters} prng PRNG parameters
 * @param {number} [probability=0.5] Probability to get 1
 * @returns {number} Either 1 or -1
 */
export declare function randomSign(prng: PRNGParameters, probability?: number): number;
/**
 * Generate a pseudo-random floating-point number within a specified range
 *
 * @param {PRNGParameters} prng  PRNG parameters
 * @param {number} [min=0]       Minimum boundary
 * @param {number} [max=1]       Maximum boundary
 * @param {number} [precision=2] Number of digits after the decimal point
 * @returns {number} Generated float
 */
export declare function randomFloat(prng: PRNGParameters, min?: number, max?: number, precision?: number): number;
/**
 * Generate a pseudo-random integer number within a specified range
 *
 * @param {PRNGParameters} prng PRNG parameters
 * @param {number} min          Minimum boundary
 * @param {number} max          Maximum boundary
 * @returns {number} Generated integer
 */
export declare function randomInt(prng: PRNGParameters, min: number, max: number): number;
/**
 * Generate a pseudo-random hexadecimal color
 *
 * @param {PRNGParameters} prng PRNG parameters
 * @returns {string} Generated hexadecimal color
 */
export declare function randomHexColor(prng: PRNGParameters): string;
/**
 * Pick a pseudo-random item from a given array
 *
 * @param {PRNGParameters} prng PRNG parameters
 * @param {T[]} array           Array to pick the item from
 * @returns {T|undefined} Random item picked
 */
export declare function randomItem<T = unknown>(prng: PRNGParameters, array: T[]): T | undefined;
/**
 * Pick a pseudo-random property value from a given object
 *
 * @param {PRNGParameters} prng PRNG parameters
 * @param {object} object       Object to pick the property from
 * @returns {T|undefined} Random item picked
 */
export declare function randomObjectProperty<T = unknown>(prng: PRNGParameters, object: Record<string, T>): T | undefined;
/**
 * Select a pseudo-random index from an array of weighted items
 *
 * @param {PRNGParameters} prng PRNG parameters
 * @param {number[]} weights    Array of weights
 * @returns {number} Random index based on weights
 */
export declare function randomIndex(prng: PRNGParameters, weights: number[]): number;
/**
 * Generate a pseudo-random number fitting a Gaussian (normal) distribution
 *
 * @param {PRNGParameters} prng PRNG parameters
 * @param {number} [mean=0]     Central value
 * @param {number} [spread=1]   Standard deviation
 * @returns {number} Generated number
 */
export declare function randomGaussian(prng: PRNGParameters, mean?: number, spread?: number): number;
