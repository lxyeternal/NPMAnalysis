import type { Point, Point3 } from './types';
/**
 * Convert a radians value into degrees
 *
 * @param {number} radians Angle in radians
 * @returns {number} Angle in degrees
 */
export declare function toDegrees(radians: number): number;
/**
 * Convert a degrees value into radians
 *
 * @param {number} degrees Angle in degrees
 * @returns {number} Angle in radians
 */
export declare function toRadians(degrees: number): number;
/**
 * Calculate the angle from a point to another
 *
 * @param  {number} x1 X-axis coordinate of the start point
 * @param  {number} y1 Y-axis coordinate of the start point
 * @param  {number} x2 X-axis coordinate of the end point
 * @param  {number} y2 Y-axis coordinate of the end point
 * @returns {number} Angle
 */
export declare function angle(x1: number, y1: number, x2: number, y2: number): number;
/**
 * Find the closest angle between to angles
 *
 * @param {number} source Source angle (in radians)
 * @param {number} target Target angle (in radians)
 * @returns {number} Closest angle
 */
export declare function closestAngle(source: number, target: number): number;
/**
 * Calculate the distance between two points
 *
 * @param {number} x1 X-axis coordinate of the first point
 * @param {number} y1 Y-axis coordinate of the first point
 * @param {number} x2 X-axis coordinate of the second point
 * @param {number} y2 Y-axis coordinate of the second point
 * @returns {number} Computed distance
 */
export declare function distance(x1: number, y1: number, x2: number, y2: number): number;
/**
 * Calculate the dot product of two vectors
 *
 * @param {number} x1 X-axis coordinate of the first vector
 * @param {number} y1 Y-axis coordinate of the first vector
 * @param {number} x2 X-axis coordinate of the second vector
 * @param {number} y2 Y-axis coordinate of the second vector
 * @returns {number} Computed dot product
 */
export declare function dot(x1: number, y1: number, x2: number, y2: number): number;
/**
 * Calculate the cross product of two vectors
 *
 * @param {number} x1 X-axis coordinate of the first vector
 * @param {number} y1 Y-axis coordinate of the first vector
 * @param {number} x2 X-axis coordinate of the second vector
 * @param {number} y2 Y-axis coordinate of the second vector
 * @returns {number} Computed cross product
 */
export declare function cross(x1: number, y1: number, x2: number, y2: number): number;
/**
 * Calculate the length of the diagonal of a rectangle
 *
 * @param {number} width  Width of the rectangle
 * @param {number} height Height of the rectangle
 * @returns {number} Diagonal length
 */
export declare function diagonal(width: number, height: number): number;
/**
 * Convert radians to a 3D point on the surface of a unit sphere
 *
 * @param  {number} radius  Radius of the sphere
 * @param  {number} phi     Polar angle from the y (up) axis     : [0, PI]
 * @param  {number} theta   Equator angle around the y (up) axis : [0, 2*PI]
 * @param  {Point3} target Target 3D point
 * @returns {Point3}
 */
export declare function radToSphere(radius: number, phi: number, theta: number, target?: Point3): Point3;
/**
 * Interpolate a point on a line
 *
 * @param {number} t  Normalized time value to interpolate
 * @param {number} x1 X-axis coordinate of the start point
 * @param {number} y1 Y-axis coordinate of the start point
 * @param {number} x2 X-axis coordinate of the end point
 * @param {number} y2 Y-axis coordinate of the end point
 * @returns {Point} Interpolated coordinates on the line
 */
export declare function line(t: number, x1: number, y1: number, x2: number, y2: number): Point;
/**
 * Interpolate a point on a Quadratic Bézier curve
 *
 * @param {number} t   Normalized time value to interpolate
 * @param {number} x1  X-axis coordinate of the start point
 * @param {number} y1  Y-axis coordinate of the start point
 * @param {number} cpx X-axis coordinate of the control point
 * @param {number} cpy Y-axis coordinate of the control point
 * @param {number} x2  X-axis coordinate of the end point
 * @param {number} y2  Y-axis coordinate of the end point
 * @returns {Point} Interpolated coordinates on the curve
 */
export declare function quadraticBezier(t: number, x1: number, y1: number, cpx: number, cpy: number, x2: number, y2: number): Point;
/**
 * Interpolate a point on a Cubic Bézier curve
 *
 * @param {number} t    Normalized time value to interpolate
 * @param {number} x1   X-axis coordinate of the start point
 * @param {number} y1   Y-axis coordinate of the start point
 * @param {number} cp1x X-axis coordinate of the first control point
 * @param {number} cp1y Y-axis coordinate of the first control point
 * @param {number} cp2x X-axis coordinate of the second control point
 * @param {number} cp2y Y-axis coordinate of the second control point
 * @param {number} x2   X-axis coordinate of the end point
 * @param {number} y2   Y-axis coordinate of the end point
 * @returns {Point} Interpolated coordinates on the curve
 */
export declare function cubicBezier(t: number, x1: number, y1: number, cp1x: number, cp1y: number, cp2x: number, cp2y: number, x2: number, y2: number): Point;
/**
 * Interpolate a point on a Catmull-Rom spline
 *
 * @param {number} t   Normalized time value to interpolate
 * @param {number} x1  X-axis coordinate of the start point
 * @param {number} y1  Y-axis coordinate of the start point
 * @param {number} cp1x X-axis coordinate of the first control point
 * @param {number} cp1y Y-axis coordinate of the first control point
 * @param {number} cp2x X-axis coordinate of the second control point
 * @param {number} cp2y Y-axis coordinate of the second control point
 * @param {number} x2  X-axis coordinate of the end point
 * @param {number} y2  Y-axis coordinate of the end point
 * @returns {Point} Interpolated coordinates on the spline
 */
export declare function catmullRom(t: number, x1: number, y1: number, cp1x: number, cp1y: number, cp2x: number, cp2y: number, x2: number, y2: number): Point;
/**
 * Interpolate a point on an elliptical arc
 *
 * @param {number} t  Normalized time value to interpolate
 * @param {number} cx X-axis coordinate of the center of the ellipse
 * @param {number} cy Y-axis coordinate of the center of the ellipse
 * @param {number} rx X-radius of the ellipse
 * @param {number} ry Y-radius of the ellipse
 * @param {number} [rotation=0] Rotation angle of the ellipse (in radians), counterclockwise from the positive X-axis
 * @param {number} [startAngle=0]  Start angle of the arc (in radians)
 * @param {number} [endAngle=2*PI] End angle of the arc (in radians)
 * @param {boolean} [counterclockwise=false] Flag indicating the direction of the arc
 * @returns {Point} Interpolated coordinates on the arc
 */
export declare function ellipse(t: number, cx: number, cy: number, rx: number, ry: number, rotation?: number, startAngle?: number, endAngle?: number, counterclockwise?: boolean): Point;
/**
 * Interpolate a point on a circular arc
 *
 * @param {number} t  Normalized time value to interpolate
 * @param {number} cx X-axis coordinate of the center of the circle
 * @param {number} cy Y-axis coordinate of the center of the circle
 * @param {number} radius Radius of the circle
 * @param {number} [startAngle] Start angle of the arc (in radians)
 * @param {number} [endAngle]   End angle of the arc (in radians)
 * @param {boolean} [counterclockwise=false] Flag indicating the direction of the arc
 * @returns {Point} Interpolated coordinates on the arc
 */
export declare function arc(t: number, cx: number, cy: number, radius: number, startAngle?: number, endAngle?: number, counterclockwise?: boolean): Point;
/**
 * Check if two points are coincident
 *
 * @param {number} x1 X-axis coordinate of the first point
 * @param {number} y1 Y-axis coordinate of the first point
 * @param {number} x2 X-axis coordinate of the second point
 * @param {number} y2 Y-axis coordinate of the second point
 * @returns {boolean} True if the two are coincident, false otherwise
 */
export declare function isCoincident(x1: number, y1: number, x2: number, y2: number): boolean;
/**
 * Check if three points are collinear (aligned on the same line)
 *
 * @param {number} x1 X-axis coordinate of the first point
 * @param {number} y1 Y-axis coordinate of the first point
 * @param {number} x2 X-axis coordinate of the second point
 * @param {number} y2 Y-axis coordinate of the second point
 * @param {number} x3 X-axis coordinate of the third point
 * @param {number} y3 Y-axis coordinate of the third point
 * @returns {boolean} True if the three points are collinear, false otherwise
 */
export declare function isCollinear(x1: number, y1: number, x2: number, y2: number, x3: number, y3: number): boolean;
export type FitInput = {
    width: number;
    height: number;
};
export type FitOutput = {
    left: number;
    top: number;
    width: number;
    height: number;
    scale: number;
};
/**
 * Make a target fit a container (cover mode)
 *
 * @param {FitInput} target    Dimensions of the target
 * @param {FitInput} container Dimensions of the container
 * @returns {FitOutput}
 */
export declare function cover(target: FitInput, container: FitInput): FitOutput;
/**
 * Make a target fit a container (contain mode)
 *
 * @param {FitInput} target    Dimensions of the target
 * @param {FitInput} container Dimensions of the container
 * @returns {FitOutput}
 */
export declare function contain(target: FitInput, container: FitInput): FitOutput;
