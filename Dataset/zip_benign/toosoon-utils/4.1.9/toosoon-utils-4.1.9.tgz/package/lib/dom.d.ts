/**
 * Find the closest parent that matches a selector
 *
 * @param {Element|null}     element  Target element
 * @param {Element|string} selector Selector or parent to match
 * @returns {Element|null}
 */
export declare function closest(element: Element | null, selector: Element | string): Element | null;
/**
 * Create a canvas and 2d context
 *
 * @param {number} width  Width of the canvas
 * @param {number} height Height of the canvas
 * @returns {{ canvas: HTMLCanvasElement, ctx: CanvasRenderingContext2D }}
 */
export declare function createCanvas(width: number, height: number): {
    canvas: HTMLCanvasElement;
    ctx: CanvasRenderingContext2D;
};
/**
 * Inject CSS styles in `document.head`
 *
 * @param {string} styles CSS styles to inject
 */
export declare function injectStyles(styles: string): void;
