/**
 * Capitalize a string
 *
 * @param {string} string String to capitalize
 * @returns {string} Capitalized string
 */
export declare function capitalize(string: string): string;
/**
 * Convert a string to kebab-case: 'Hello world' -> 'hello-world'
 *
 * @param {string} string String to convert
 * @returns {string} Converted string
 */
export declare function toKebabCase(string: string): string;
/**
 * Convert a string to snake_case: 'Hello world' -> 'hello_world'
 *
 * @param {string} string String to convert
 * @returns {string} Converted string
 */
export declare function toSnakeCase(string: string): string;
/**
 * Convert a string to camelCase: 'Hello world' -> 'helloWorld'
 *
 * @param {string} string String to convert
 * @returns {string} Converted string
 */
export declare function toCamelCase(string: string): string;
/**
 * Convert a string to PascalCase: 'Hello world' -> 'HelloWorld'
 *
 * @param {string} string String to convert
 * @returns {string} Converted string
 */
export declare function toPascalCase(string: string): string;
/**
 * Convert a string to Train-Case: 'Hello world' -> 'Hello-World'
 *
 * @param {string} string String to convert
 * @returns {string} Converted string
 */
export declare function toTrainCase(string: string): string;
/**
 * Convert a string to CONSTANT_CASE: 'Hello world' -> 'HELLO_WORLD'
 *
 * @param {string} string String to convert
 * @returns {string} Converted string
 */
export declare function toConstantCase(string: string): string;
/**
 * Clean a path by removing its parameters
 *
 * @param {string} path Path to clean
 * @returns {string} Cleaned path
 */
export declare function cleanPath(path: string): string;
/**
 * Convert a path by ensuring it has a trailing slash
 *
 * @param {string} path Path to convert
 * @returns {string}
 */
export declare function addTrailingSlash(path: string): string;
/**
 * Convert a path by ensuring it has not a trailing slash
 *
 * @param {string} path Path to convert
 * @returns {string}
 */
export declare function removeTrailingSlash(path: string): string;
