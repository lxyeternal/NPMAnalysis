import { W3CX11 } from './constants';
export type ColorName = keyof typeof W3CX11;
export type ColorRepresentation = ColorName | string | number | [number, number, number];
export interface Deferred<T> {
    promise: Promise<T>;
    resolve: (value: T | PromiseLike<T>) => void;
    reject: (reason?: unknown) => void;
}
export type Point = [number, number];
export type Point2 = [number, number];
export type Point3 = [number, number, number];
