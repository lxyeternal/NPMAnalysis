/**
 * Get a query parameter
 *
 * @param {string} property Query property to check
 * @returns {string|null} Value associated to the given search parameter
 */
export declare function getQuery(property: string): string | null;
/**
 * Set a query parameter
 *
 * @param {string} property Query property to set
 * @param {string} value    Value to set
 */
export declare function setQuery(property: string, value: string): void;
/**
 * Check if a query parameter exists
 *
 * @param {string} property Query property to check
 * @returns {boolean} True if the given property has a query parameter value, false otherwise
 */
export declare function hasQuery(property: string): boolean;
