# StartPHP
StartPHP is a lightweight, easy-to-learn and well-functioning PHP backend development framework developed by CatCatalpa Vitality (Shanghai) Information Technology Co., Ltd.

[Press here](https://doc.startphp.catcatalpa.com) to go to StartPHP document page

## Before using StartPHP

After several rounds of testing, the StartPHP 0.5 version is finally released in advance of a month before the estimated time.You can now go to the GitHub or download the latest version through the npm scaffolding tool we provide.

This StartPHP 0.5 version has added a number of functions, including but not limited to session operation tools, function globalization modules, and multi-language automatic loading mechanisms.In addition, we have optimized some problems that may be encountered in development, for example,we have simplified the calling format of the ORM system, etc., and thanks to the characteristics of namespaces, in the new version, the framework will cancel redundant classes and controller file naming prefixes and suffixes, which will greatly reduce your development costs.

Compared with the framework, the npm tool has not been significantly updated this time, but optimized some detailed functions that can affect the overall experience, so that you can use it more easily and improve development efficiency.

## 0.0.4 update content

- You will be able to choose the type of framework you need to download.
- Improve system speed.
- Optimized the bug that the framework installation failed in the characteristic scene.
- Optimized part of the prompt copy.
- Fixed some known bugs.
