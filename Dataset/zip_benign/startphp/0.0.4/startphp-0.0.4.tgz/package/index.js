#!/usr/bin/env node
//第一行其中#!/usr/bin/env node表示用node解析器执行本文件。
// +------------------------------------------------------------------------------
// | StartPHP
// +------------------------------------------------------------------------------
// | Copyright (c) 2006~2018 Cat Catalpa Vitality Co., Ltd All rights reserved.
// +------------------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +------------------------------------------------------------------------------
// | Author: Cat Catalpa Vitality (Shanghai) Information Technology Co., Ltd
// +------------------------------------------------------------------------------
//cli工具命令

const program = require('commander')
const pkg = require('./package')
const chalk = require('chalk')
const download = require('download-git-repo');
const ora = require('ora');
const spinner = ora('Loading undead unicorns');
const inquirer = require("inquirer");

/**
* version
*/
program
.version(chalk.green('StartPHP Package Version : v' + `${pkg.version}`))
.description(chalk.green('StartPHP 一款轻量化、易上手、完善化的PHP框架  https://startphp.catcatalpa.com'));
program
.option('-v, --version', 'Print the startphp package version')
/**
* init 项目
*/
program
.command('init')
.description('generate a project from a remote template (legacy API, requires ./wk-init)')
.option('-c, --clone', 'Use git clone when fetching remote template')
.action((template, appName, cmd) => {
    inquirer
      .prompt([
        {
          type: "input",
          name: "appname",
          message: "Please enter your project name",
        },
        {
          type: "list",
          name: "type",
          message: "Please choose a type of framework",
          default: "Beta",
          choices: [
            {
              name: "Formal",
              value: "direct:https://github.com/Cat-Catalpa/StartPHP#master",
            },
            {
              name: "Beta",
              value: "direct:https://github.com/Cat-Catalpa/StartPHP-Beta#main",
            },
          ],
        },
      ])
      .then((answers) => {
        spinner.start('Creating new project...');
        if (answers['appname'] == "") answers['appname'] = "myapp" 
        download(answers['type'], answers['appname'], { clone:  true }, err => {
        if (err) {
        spinner.fail(chalk.red('Creating Failed \n' + err));
        process.exit();
        }
        spinner.succeed(chalk.green(`Complate!`));
        spinner.succeed(chalk.green(`Welcome to StartPHP!`));
        if (answers['type'] == "direct:https://github.com/Cat-Catalpa/StartPHP-Beta#main") {
            console.log(chalk.yellow(`! You are using the StartPHP beta version, we cannot guarantee the stability and security of the beta version, please do not use this project for production environment!`));
        }
        spinner.succeed(chalk.green(`StartPHP Document Page:https://doc.startphp.catcatalpa.com`));
        spinner.succeed(chalk.green(`Wish you have a wonderful experience~`));
        });
      })
})

program.parse(process.argv)