/*
 * grunt-contrib-jst
 * http://gruntjs.com/
 *
 * Copyright (c) 2014 Tim Branyen, contributors
 * Licensed under the MIT license.
 */

'use strict';
var _ = require('lodash');
var chalk = require('chalk');

module.exports = function(grunt) {
    // filename conversion for templates
    var defaultProcessName = function(name) {
        return name;
    };

    grunt.registerMultiTask('amd-jst', 'Compile underscore templates to JST file', function() {
        var lf = grunt.util.linefeed;
        var helpers = require('grunt-lib-contrib').init(grunt);
        var options = this.options({
            namespace: 'JST', templateSettings: {}, processContent: function(src) {
                return src;
            }, separator: lf + lf
        });

        // assign filename transformation functions
        var processName = options.processName || defaultProcessName;

        var nsInfo;
        if (options.namespace !== false) {
            nsInfo = helpers.getNamespaceDeclaration(options.namespace);
        }

        this.files.forEach(function(f) {
            var resultmap = f.src
                    .filter(function(filepath) {
                        // Warn on and remove invalid source files (if nonull was set).
                        if (!grunt.file.exists(filepath)) {
                            grunt.log.warn('Source file ' + chalk.cyan(filepath) + ' not found.');
                            return false;
                        } else {
                            return true;
                        }
                    })
                    .reverse()
                    .reduce(function(previousValue, currentValue) {
                        var key = currentValue;
                        if (!!options.keyFilter) {
                            key = options.keyFilter(key);
                        }

                        if (previousValue["keys"].indexOf(key) == -1) {
                            previousValue["keys"].push(key);

                            var html = options.processContent(grunt.file.read(currentValue));
                            var compiled = _.template(html, false, options.templateSettings).source;
                            if (options.prettify) {
                                compiled = compiled.replace(/\n/g, '');
                            }

                            var myTemplates = options.namespace + "[\"" + key + "\"]";

                            if (options.amd && options.namespace === false) {
                                previousValue["output"] += myTemplates + " = " + "return " + compiled + "\n";
                            } else {
                                previousValue["output"] += myTemplates + " = " + compiled + "\n";
                            }
                        }
                        return previousValue;
                    }, {keys: [], output: ""});

            var output = "var " + options.namespace + "= {};\n" + resultmap.output;

            grunt.file.write(f.dest, output);
            grunt.log.writeln('File ' + chalk.cyan(f.dest) + ' created.');
        });

    });
};
