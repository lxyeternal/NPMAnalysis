import { DirectiveOptions } from 'vue';
export interface VLazySrcOption {
    threshold?: number;
    placeholder?: string;
}
declare const VLazySrc: (options?: VLazySrcOption) => DirectiveOptions;
export default VLazySrc;
