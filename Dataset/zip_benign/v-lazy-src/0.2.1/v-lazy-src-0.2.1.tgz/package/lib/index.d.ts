import { PluginObject } from 'vue';
import VLazySrc from './directive';
declare const VLazySrcPlugin: PluginObject<any>;
export default VLazySrcPlugin;
export { VLazySrc };
