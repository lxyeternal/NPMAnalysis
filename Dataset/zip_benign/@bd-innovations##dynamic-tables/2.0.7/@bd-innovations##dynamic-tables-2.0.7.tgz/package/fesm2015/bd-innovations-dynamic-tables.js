import { at, mapValues, map as map$1, isEqual } from 'lodash';
import { InjectionToken, Injectable, Inject, EventEmitter, Component, ChangeDetectorRef, Input, ViewChild, Output, Pipe, NgModule, Optional, Directive, ɵɵdefineInjectable, ɵɵinject, Injector, ContentChild, HostBinding, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Subject, fromEvent } from 'rxjs';
import { debounceTime, takeUntil, filter, map, distinctUntilChanged, startWith, take } from 'rxjs/operators';
import { combineLatest } from 'rxjs/internal/observable/combineLatest';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule, MatPaginatorIntl } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { TimeAgoPipeModule, RandomGradientPipeModule, NullOrUndefinedHandlerPipeModule, SliceWithDotsPipeModule, ToIconPipeModule, BdDatePipeModule, OrderedKeyValuePipeModule, FirstLetterPipeModule } from '@bd-innovations/pipe-collection';
import { DomElementValidatorDirectiveModule, ShortPressDirectiveModule, RandomClassDirectiveModule, ApiDataHandlerDirectiveModule, DomElementValidatorService, ClickerDirectiveModule } from '@bd-innovations/directive-collection';
import { FlexModule, FlexLayoutModule } from '@angular/flex-layout';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule, MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { SelectionModel } from '@angular/cdk/collections';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog, MatDialogModule } from '@angular/material/dialog';
import { DynamicFormService, DynamicFormModule } from '@bd-innovations/dynamic-form';
import { moveItemInArray, DragDropModule } from '@angular/cdk/drag-drop';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';

class BaseColumn {
    /**
     * @param paths declare property/ies of object to display (using the same syntax of "_.at" method)
     * @param mask declare some mask to use for displayed data
     * @param config ''
     */
    constructor(paths, 
    // public mask?: (element: any) => any,
    config = { sortable: false }) {
        this.paths = paths;
        this.config = config;
        // if (config && config.sortable) {
        //   console.log(123)
        // } else {
        //   console.log(456)
        // }
    }
    get(element) {
        return at(element, this.paths);
    }
}

class DateColumn extends BaseColumn {
    // /**
    //  * @param path see BaseColumnInterface.paths
    //  * @param format define format in which to show date (by default equal to 'yyyy/MM/dd'
    //  */
    // constructor(path: string, format?: string);
    // /**
    //  * @param path see BaseColumnInterface.paths
    //  * @param timeAgo set to true when you need to show date in style of "5 minutes ago" (by default equal to false)
    //  */
    // constructor(path: string, timeAgo: boolean);
    constructor(path, config) {
        super(path);
        this.path = path;
        this._columnType = 'DateColumn';
        const defaultFormat = 'yyyy/MM/dd';
        const defaultTimeAgo = false;
        this.format = config && config.format || defaultFormat;
        this.timeAgo = config && config.timeAgo || defaultTimeAgo;
    }
    get(element) {
        const res = super.get(element);
        if (res === null || undefined) {
            return null;
        }
        return res[0];
    }
}

class IconColumn extends BaseColumn {
    // /**
    //  * @param path see BaseColumnInterface.paths
    // * @param icons specify an array of icons from where to take icons based on value of object property
    // * @param config ''
    // */
    constructor(path, config) {
        super(path);
        this.path = path;
        this._columnType = 'IconColumn';
        this.icons = config.icons;
        this.action = config.action;
    }
    get(element) {
        const res = super.get(element);
        if (res === null || undefined) {
            return null;
        }
        return res[0];
    }
}

class TextColumn extends BaseColumn {
    constructor(paths, config) {
        super(paths, config);
        this._columnType = 'TextColumn';
        const defaultLimit = 30;
        const defaultTranslate = '';
        const defaultSeparator = ' ';
        this.limit = config && config.limit || defaultLimit;
        this.translate = config && config.translate || defaultTranslate;
        this.separator = config && config.separator || defaultSeparator;
        this.mask = config && config.mask || undefined;
    }
    get(element) {
        let res = super.get(element);
        res = !!this.mask ? res.map(elem => this.mask(elem)) : res;
        if (res === null || res === undefined) {
            return null;
        }
        if (res instanceof Array) {
            let checkRes = false;
            res.forEach((resElem, index) => {
                if (resElem !== null && resElem !== undefined) {
                    checkRes = true;
                }
                else {
                    res[index] = '';
                }
            });
            if (!checkRes) {
                return null;
            }
        }
        return res && (res
            .map((elem, index) => (this.separator instanceof Array ? this.separator[index] : '') + this.translate + elem)
            .join(this.separator instanceof Array ? '' : this.separator));
    }
}

// TODO add primaryKey property
class UuidColumn extends TextColumn {
    constructor(uuId, config) {
        super(uuId, { limit: config.limit });
        this._columnType = 'TextColumn';
        this.array = config.array;
        this.pathInArray = config.pathInArray;
        this.primaryKeyInArray = config.primaryKeyInArray;
    }
    get(element) {
        const res = super.get(element);
        if (!res) {
            return null;
        }
        const externalRes = at(this.array.find(elem => elem[this.primaryKeyInArray].toString() === res.toString()), this.pathInArray);
        if (!externalRes) {
            return null;
        }
        return externalRes.join(' ');
    }
}

class AvatarColumn extends BaseColumn {
    constructor(paths) {
        super(paths);
        this._columnType = 'AvatarColumn';
    }
    get(element) {
        const res = super.get(element);
        if (res === null || undefined) {
            return null;
        }
        return res[0];
    }
}

var ReservedNamesEnum;
(function (ReservedNamesEnum) {
    ReservedNamesEnum["searchRow"] = "bdReservedNameForSearchRow";
    ReservedNamesEnum["expandedRow"] = "bdReservedNameForExpandedRow";
    // expandColumn = 'bdReservedNameForExpandColumn',
    ReservedNamesEnum["actionsColumn"] = "bdReservedNameForActionsColumn";
    // checkboxColumn = 'bdReservedNameForCheckboxColumn',
    ReservedNamesEnum["serviceColumn"] = "bdReservedNameForServiceColumn";
})(ReservedNamesEnum || (ReservedNamesEnum = {}));

const DYNAMIC_TABLE_MODULE_CONFIG = new InjectionToken('DYNAMIC_TABLE_MODULE_CONFIG');
class MatDynamicTableService {
    constructor(config) {
        this.config = config;
    }
    getParsedData(data, columns) {
        const resArray = [];
        if (data) {
            data.forEach((element, index) => {
                const resElement = {
                    originalIndex: index,
                    selected: false
                };
                const keys = Object.keys(columns);
                keys.forEach(key => {
                    resElement[key] = columns[key].get(element);
                });
                resArray.push(resElement);
            });
        }
        return resArray;
    }
}
MatDynamicTableService.decorators = [
    { type: Injectable }
];
MatDynamicTableService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [DYNAMIC_TABLE_MODULE_CONFIG,] }] }
];

class MatDynamicTableComponent {
    constructor(service, cd) {
        this.service = service;
        this.cd = cd;
        this.columns = {};
        this.displayColumns = [];
        this.translatePath = '';
        this.search = true;
        this.paginator = {
            pageIndex: 0,
            pageSize: 25,
        };
        this.actions = [];
        this.roles = {};
        this.reservedColumnNames = ReservedNamesEnum; // Shortcut to access from the template
        this.searchCtrl = new FormControl();
        this.bulkContainer$ = new Subject();
        this.dataColumns = [];
        this.actionRequest = new EventEmitter();
        this.apiRequest = new EventEmitter();
        this.bulkContainerUpdate = new EventEmitter();
        this.onDestroy = new Subject();
    }
    ngOnChanges() {
        this.initDataSource();
        if (this.matPaginator) {
            this.matPaginator.length = this.paginator.length;
        }
    }
    ngOnInit() {
        this.bulk && this.initBulk();
        this.dataColumns = this.dataColumns.concat(this.displayColumns);
        if (this.expandedRow || this.bulk) {
            this.dataColumns.unshift(ReservedNamesEnum.serviceColumn);
        }
    }
    ngAfterViewInit() {
        this.apiable ? this.initApiableTable() : this.initNotApiableTable();
        this.paginator && this.initPaginator();
        this.cd.detectChanges();
    }
    ngOnDestroy() {
        this.onDestroy.next();
        this.onDestroy.complete();
    }
    isFirstColumnPadding(column_name) {
        return (this.bulk || this.expandedRow) && this.displayColumns.indexOf(column_name) === 0;
    }
    emitActionRequest(actionType, index) {
        const action = {
            type: actionType,
            entity: this.data[index]
        };
        this.actionRequest.emit(action);
    }
    massSelectionChange() {
        this.dataSource.data.forEach(element => element.selected = this.massBulkCheckbox.checked);
        this.bulkContainer$.next();
    }
    onRowClicked(element) {
        this.emitActionRequest('open', element.originalIndex);
    }
    onExpandedClicked(element) {
        if (this.expandedRow) {
            this.expandedElement = this.expandedElement === element ? null : element;
        }
    }
    initDataSource() {
        this.dataSource = new MatTableDataSource(this.service.getParsedData(this.data, this.columns));
    }
    initPaginator() {
        this.matPaginator.pageIndex = this.paginator.pageIndex;
        this.matPaginator.pageSize = this.paginator.pageSize;
        this.matPaginator.pageSizeOptions = [5, 10, 25, 50];
        if (this.apiable) {
            this.matPaginator.length = this.paginator.length;
        }
    }
    disableSort() {
        this.matSort.disabled = true;
    }
    initBulk() {
        this.bulkContainer$
            .pipe(debounceTime(1000), takeUntil(this.onDestroy))
            .subscribe((value) => {
            this.bulkContainerUpdate.emit(value ||
                this.dataSource.data
                    .filter(element => element.selected)
                    .map(element => this.data[element.originalIndex]));
        });
    }
    initApiableTable() {
        const observables = [
            fromEvent(this.searchInput.nativeElement, 'keyup')
                .pipe(filter((event) => event.key === 'Enter'), map(() => this.searchCtrl.value), distinctUntilChanged(), takeUntil(this.onDestroy), startWith(undefined)),
            this.matPaginator.page
                .pipe(startWith(undefined)),
            this.matSort.sortChange
                .pipe(startWith(undefined))
        ];
        combineLatest(observables)
            .pipe(takeUntil(this.onDestroy), filter(([search, paginator, sort]) => !(search === undefined && paginator === undefined && sort === undefined)), map(([search, paginator, sort]) => {
            const resPaginator = paginator || this.paginator;
            const resSort = sort ? Object.assign(Object.assign({}, sort), { direction: sort.direction ? sort.direction.toUpperCase() : null }) : null;
            return { search, paginator: resPaginator, sort: resSort };
        }))
            .subscribe(apiRequest => {
            if (this.previousSearch && apiRequest.search !== this.previousSearch && this.paginator) {
                apiRequest.paginator.pageIndex = 0;
            }
            if (this.bulk) {
                this.massBulkCheckbox.checked = false;
            }
            this.bulkContainer$.next([]);
            this.previousSearch = apiRequest.search;
            this.apiRequest.emit(apiRequest);
        });
    }
    initNotApiableTable() {
        this.dataSource.sort = this.matSort;
        // WORKAROUND don't simplify it, sometimes without it paginator doesn't init itself
        setTimeout(() => this.dataSource.paginator = this.matPaginator);
        fromEvent(this.searchInput.nativeElement, 'keyup')
            .pipe(filter((event) => event.key === 'Enter'), map(() => this.searchCtrl.value), distinctUntilChanged(), takeUntil(this.onDestroy))
            .subscribe(value => {
            this.dataSource.filter = value ? value.trim().toLowerCase() : '';
            if (this.dataSource.paginator) {
                this.dataSource.paginator.firstPage();
            }
        });
    }
}
MatDynamicTableComponent.decorators = [
    { type: Component, args: [{
                selector: 'bd-mat-dynamic-table',
                template: "<div class=\"table-wrapper\">\n  <table [dataSource]=\"dataSource\" mat-table matSort multiTemplateDataRows>\n\n    <!-- SEARCH ROW -->\n    <ng-container [matColumnDef]=\"reservedColumnNames.searchRow\">\n      <th *matHeaderCellDef\n          [colSpan]=\"(dataColumns).length\"\n          class=\"search-row\"\n          mat-header-cell>\n        <div class=\"search-wrapper\" fxLayout=\"row\" fxLayoutAlign=\"space-between center\" fxLayoutGap=\"5px\">\n          <span fxFlex=\"12px\">\n            <span [innerHtml]=\"service.config.searchField.icon\"></span>\n          </span>\n\n          <input [formControl]=\"searchCtrl\"\n                 #searchInput\n                 [placeholder]=\"service.config.searchField.placeholder | translate\"\n                 fxFlex>\n\n          <span fxFlex=\"12px\">\n            <span (click)=\"searchCtrl.reset()\"\n                  *ngIf=\"searchCtrl.value\"\n                  [innerHTML]=\"service.config.searchField.resetIcon\"\n                  class=\"float-right cursor-pointer\"></span>\n          </span>\n        </div>\n      </th>\n    </ng-container>\n\n    <!--SERVICE COLUMNS-->\n    <!--  EXPAND AND CHECKBOX ROW COLUMN  -->\n    <ng-container\n      *ngIf=\"expandedRow || bulk\"\n      [matColumnDef]=\"reservedColumnNames.serviceColumn\"\n      [sticky]=\"true\"\n    >\n      <th\n        *matHeaderCellDef\n        mat-header-cell\n        class=\"service-column-header\"\n        [ngStyle]=\"{'width': bulk && expandedRow ? '15px' : '5px'}\"\n      >\n        <div fxLayout=\"row\" fxLayoutAlign=\"center center\">\n          <i class=\"hidden-icon\" *ngIf=\"expandedRow\"></i>\n          <mat-checkbox #massBulkCheckbox\n                        *ngIf=\"bulk && data.length > 0\"\n                        (bdShortPress)=\"$event.stopPropagation()\"\n                        (change)=\"massSelectionChange()\"\n                        class=\"bulk-checkbox\"\n          ></mat-checkbox>\n        </div>\n      </th>\n\n      <td\n        *matCellDef=\"let element\"\n        mat-cell\n        class=\"service-column-td\"\n        [ngStyle]=\"{'width': bulk && expandedRow ? '15px' : '5px'}\"\n      >\n        <div fxLayout=\"row\" fxLayoutAlign=\"center center\">\n          <span class=\"expand\"\n                *ngIf=\"expandedRow\"\n                (bdShortPress)=\"$event.stopPropagation();onExpandedClicked(element);\"\n                [ngClass]=\"expandedElement && element === expandedElement ? 'bd-expand-open' : 'bd-expand-close'\"\n          >\n            <span [innerHTML]=\"service.config.expandIcon\"></span>\n          </span>\n\n          <span\n            class=\"checkbox\"\n            *ngIf=\"bulk\"\n          >\n          <mat-checkbox (bdShortPress)=\"$event.stopPropagation()\"\n                        (change)=\"bulkContainer$.next()\"\n                        [(ngModel)]=\"element['selected']\">\n          </mat-checkbox>\n        </span>\n        </div>\n\n      </td>\n\n      <!--        [class.service-column-left]=\"expandedRow && !bulk\"-->\n    </ng-container>\n\n    <!-- ACTIONS COLUMN -->\n    <ng-container [matColumnDef]=\"reservedColumnNames.actionsColumn\" stickyEnd>\n      <th *matHeaderCellDef\n          mat-header-cell\n          class=\"actions-column-header\">\n      </th>\n      <td *matCellDef=\"let element\" mat-cell class=\"service-column-right\">\n        <button (bdShortPress)=\"$event.stopPropagation()\" [matMenuTriggerFor]=\"buttonsMenu\"\n                mat-icon-button>\n          <span [outerHTML]=\"service.config.actionsColumn.icon\"></span>\n        </button>\n\n        <mat-menu #buttonsMenu=\"matMenu\">\n          <ng-container *ngFor=\"let action of actions\">\n            <ng-container [ngSwitch]=\"action | simpleOrConditionalAction\">\n              <ng-container *ngSwitchCase=\"'simple'\">\n                <button (click)=\"emitActionRequest(action, element['originalIndex'])\"\n                        *bdDomElementValidator=\"roles ? roles[action] : null\"\n                        mat-menu-item>\n                  <span [outerHTML]=\"service.config.actionsColumn.actions[action].icon\"></span>\n                  <span\n                    style=\"margin-left: 10px\">{{service.config.actionsColumn.actions[action].label | translate}}</span>\n                </button>\n              </ng-container>\n              <ng-container *ngSwitchCase=\"'conditional'\">\n                <button (click)=\"emitActionRequest(action.type, element['originalIndex'])\"\n                        *bdDomElementValidator=\"roles ? roles[action.type] : null\"\n                        [disabled]=\"!(data[element['originalIndex']] | checkActionCondition:action.condition)\"\n                        mat-menu-item>\n                  <span [outerHTML]=\"service.config.actionsColumn.actions[action.type].icon\"></span>\n                  <span\n                    style=\"margin-left: 10px\">{{service.config.actionsColumn.actions[action.type].label | translate}}</span>\n                </button>\n              </ng-container>\n            </ng-container>\n\n          </ng-container>\n        </mat-menu>\n      </td>\n    </ng-container>\n\n    <!-- COLUMNS WITH DATA !== [] -->\n    <ng-container *ngFor=\"let column of columns | orderedKeyValue; let i=index\"\n                  [matColumnDef]=\"column.key\"\n                  [sticky]=\"!bulk && column.value['_columnType'] === 'TextColumn' && column.value['isAvatar']\">\n      <th *matHeaderCellDef\n          [disabled]=\"!column.value['config']['sortable']\"\n          mat-header-cell\n          mat-sort-header\n\n          [ngClass]=\"{\n            'avatar-column-header': column.value['_columnType'],\n            'first-data-row-padding': isFirstColumnPadding(column.key)\n          }\"\n      >\n        <ng-container *ngIf=\"column.value['_columnType'] !== 'AvatarColumn'\">\n          {{translatePath + column.key | translate}}\n        </ng-container>\n      </th>\n\n      <ng-container *ngIf=\"data\">\n        <td *matCellDef=\"let element\"\n            [ngClass]=\"{\n              'avatar-cell': column.value['_columnType'] !== 'AvatarColumn',\n              'first-data-row-padding': isFirstColumnPadding(column.key),\n              'column-text-center': column.value['_columnType'] === 'TextColumn' && !element[column.key]\n            }\"\n\n            mat-cell\n        >\n          <ng-container [ngSwitch]=\"column.value['_columnType']\">\n\n            <!-- Text Column -->\n            <ng-container *ngSwitchCase=\"'TextColumn'\">\n              {{element[column.key] | translate | sliceWithDots:column.value['limit'] | nullOrUndefinedHandler:{placeholder: '-'} }}\n            </ng-container>\n\n            <!-- Avatar Column -->\n            <ng-container *ngSwitchCase=\"'AvatarColumn'\">\n               <span bdRandomClass class='avatar-wrapper'>\n                  <span>{{element[column.key] | firstLetter | nullOrUndefinedHandler:{placeholder: '?'} }}</span>\n               </span>\n            </ng-container>\n\n            <!-- Date Column -->\n            <ng-container *ngSwitchCase=\"'DateColumn'\">\n              <ng-container *ngIf=\"column.value['timeAgo']; else notTimeAgo\">\n                {{element[column.key] | timeAgo | nullOrUndefinedHandler:{placeholder: '-'} }}\n              </ng-container>\n              <ng-template #notTimeAgo>\n                {{element[column.key] | bdDate:column.value['format'] | nullOrUndefinedHandler:{placeholder: '-'} }}\n              </ng-template>\n            </ng-container>\n\n            <!-- Icon Column -->\n            <ng-container *ngSwitchCase=\"'IconColumn'\">\n              <span\n                (bdShortPress)=\"column.value['action'] && emitActionRequest(column.value['action'], element['originalIndex']);$event.stopPropagation()\"\n                [innerHTML]=\"element[column.key] | toIcon:column.value['icons']\"></span>\n            </ng-container>\n          </ng-container>\n        </td>\n      </ng-container>\n    </ng-container>\n\n    <!-- EXPANDED ROW -->\n    <ng-container [matColumnDef]=\"reservedColumnNames.expandedRow\">\n      <td *matCellDef=\"let element; let index = dataIndex\"\n          [colSpan]=\"dataColumns.length\"\n          mat-cell\n          [class.expandedBlock]=\"element === expandedElement\"\n          id=\"{{reservedColumnNames.expandedRow}}\"\n      >\n        <div [@detailExpand]=\"element == expandedElement ? 'expanded' : 'collapsed'\"\n             class=\"element-detail\">\n          <div *ngIf=\"expandedRow\" class=\"element-content\">\n            <ng-container [ngTemplateOutletContext]=\"{element: data[index]}\"\n                          [ngTemplateOutlet]=\"expandedRow\">\n            </ng-container>\n          </div>\n        </div>\n      </td>\n    </ng-container>\n\n    <!--  FINAL THINGS  -->\n    <tr *matHeaderRowDef=\"[reservedColumnNames.searchRow]\" [hidden]=\"!search\" class=\"search-field-row\"\n        mat-header-row></tr>\n\n    <tr *matHeaderRowDef=\"dataColumns\" mat-header-row></tr>\n\n    <tr (bdShortPress)=\"onRowClicked(element);$event.stopPropagation()\"\n        *matRowDef=\"let element; let index = dataIndex; columns: dataColumns;\"\n        mat-row>\n    </tr>\n\n    <tr *matRowDef=\"let row; columns: [reservedColumnNames.expandedRow]\" class=\"expandable-row\" mat-row\n    ></tr>\n\n  </table>\n\n  <mat-paginator [hidden]=\"!paginator\"></mat-paginator>\n</div>\n",
                animations: [
                    trigger('detailExpand', [
                        state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
                        state('expanded', style({ height: '*' })),
                        transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
                    ]),
                ],
                styles: [".expand.bd-expand-close{opacity:.3;transition:all .2s}.expand.bd-expand-open{transform:rotate(180deg);opacity:1;transition:all .2s}.table-wrapper{overflow:auto;display:block;width:100%;border:1px solid #dcdcdc;color:#414141;padding:0;border-bottom-right-radius:5px;border-bottom-left-radius:5px}.table-wrapper table{overflow-x:scroll;min-width:100%;border-collapse:inherit}.table-wrapper table .search-field-row{background-color:#fafafa}.table-wrapper table .search-field-row .search-row{padding:0}.table-wrapper table .search-field-row .search-row .search-wrapper{background-color:#fafafa;width:100%;min-height:40px;padding:10px}.table-wrapper table .search-field-row .search-row .search-wrapper input{background:none!important;border:none;outline:none}.table-wrapper table .avatar-wrapper{width:40px;height:40px;border-radius:50%;display:table-cell!important;vertical-align:middle;text-align:center}.table-wrapper table .avatar-wrapper span{font-weight:600;color:#fff;text-align:center}.table-wrapper table .first-data-row-padding{padding-left:10px}.table-wrapper table th.mat-header-cell{color:#707070;font-weight:700;min-width:100px}.table-wrapper table th .hidden-icon{padding:15px;width:12px}.table-wrapper table th.service-column-header{min-width:5px!important;width:20px;padding-left:0!important}.table-wrapper table th.mat-column-search-field{padding:0!important}.table-wrapper table th.mat-column-avatar{min-width:60px}.table-wrapper table th.actions-column-header{min-width:20px!important}.table-wrapper table tr:hover .expand.bd-expand-close{opacity:1}.table-wrapper table tr.mat-row:nth-child(4n+3){background-color:#efeff0}.table-wrapper table tr.search-field-row{height:auto}.table-wrapper table tr.expandable-row{height:0}.table-wrapper table tr.expandable-row .element-detail{overflow:hidden;display:flex}.table-wrapper table tr.expandable-row .element-detail .element-content{padding:8px;width:100%}.table-wrapper table td .checkbox{padding:10px}.table-wrapper table td .expand{cursor:pointer;padding:15px}.table-wrapper table td.service-column-td{min-width:5px!important;width:20px;padding-left:0!important;border-right:1px solid #e2e2e4}.table-wrapper table td.mat-cell:last-of-type{padding-right:0!important}.table-wrapper table td#bdReservedNameForExpandedRow{border-bottom:0}.table-wrapper table td.mat-cell{border-bottom:1px solid #e2e2e4;color:#5b5b60!important;border-top:none}.expandedBlock{border-bottom:1px solid #dcdcdc!important}", ".gradient-strawberry{background-image:linear-gradient(45deg,#fe0b46,#ffab96)}.gradient-orange{background-image:linear-gradient(45deg,#c471f3,#f671cd)}.gradient-dawn{background-image:linear-gradient(45deg,#f3904f,#3b4371)}.gradient-shdow-night{background-image:linear-gradient(45deg,#000,#53346d)}.gradient-man-of-steel{background-image:linear-gradient(45deg,#780206,#061161)}.gradient-flickr{background-image:linear-gradient(45deg,#33001b,#ff0084)}.gradient-ibiza-sunset{background-image:linear-gradient(45deg,#ee0979,#ff6a00)}.gradient-politics{background-image:linear-gradient(45deg,#2196f3,#f44336)}", ".float-right{float:right!important}.cursor-pointer{cursor:pointer}"]
            },] }
];
MatDynamicTableComponent.ctorParameters = () => [
    { type: MatDynamicTableService },
    { type: ChangeDetectorRef }
];
MatDynamicTableComponent.propDecorators = {
    data: [{ type: Input }],
    columns: [{ type: Input }],
    displayColumns: [{ type: Input }],
    translatePath: [{ type: Input }],
    apiable: [{ type: Input }],
    bulk: [{ type: Input }],
    search: [{ type: Input }],
    paginator: [{ type: Input }],
    actions: [{ type: Input }],
    roles: [{ type: Input }],
    expandedRow: [{ type: Input }],
    searchInput: [{ type: ViewChild, args: ['searchInput',] }],
    matPaginator: [{ type: ViewChild, args: [MatPaginator,] }],
    matSort: [{ type: ViewChild, args: [MatSort,] }],
    massBulkCheckbox: [{ type: ViewChild, args: ['massBulkCheckbox',] }],
    actionRequest: [{ type: Output }],
    apiRequest: [{ type: Output }],
    bulkContainerUpdate: [{ type: Output }]
};

class SimpleOrConditionalActionPipe {
    transform(value) {
        switch (true) {
            case (typeof value === 'string'):
                return 'simple';
            case (value instanceof Object):
                return 'conditional';
            default:
                throw new Error('Unknown Action type passed');
        }
    }
}
SimpleOrConditionalActionPipe.decorators = [
    { type: Pipe, args: [{
                name: 'simpleOrConditionalAction'
            },] }
];

class CheckActionConditionPipe {
    transform(element, callback) {
        return callback(element);
    }
}
CheckActionConditionPipe.decorators = [
    { type: Pipe, args: [{
                name: 'checkActionCondition'
            },] }
];

class ActionMicroPipesModule {
}
ActionMicroPipesModule.decorators = [
    { type: NgModule, args: [{
                declarations: [SimpleOrConditionalActionPipe, CheckActionConditionPipe],
                exports: [SimpleOrConditionalActionPipe, CheckActionConditionPipe],
            },] }
];

class MatDynamicTableModule {
    static forRoot(moduleConfig) {
        return {
            ngModule: MatDynamicTableModule,
            providers: [
                MatDynamicTableService,
                {
                    provide: DYNAMIC_TABLE_MODULE_CONFIG,
                    useValue: moduleConfig
                }
            ]
        };
    }
    static forChild(moduleConfig) {
        return {
            ngModule: MatDynamicTableModule,
            providers: [
                MatDynamicTableService,
                {
                    provide: DYNAMIC_TABLE_MODULE_CONFIG,
                    useValue: moduleConfig
                }
            ]
        };
    }
}
MatDynamicTableModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    MatDynamicTableComponent
                ],
                imports: [
                    CommonModule,
                    FlexModule,
                    FormsModule,
                    ReactiveFormsModule,
                    MatTooltipModule,
                    MatFormFieldModule,
                    MatInputModule,
                    MatTableModule,
                    MatSortModule,
                    MatPaginatorModule,
                    MatButtonModule,
                    MatMenuModule,
                    MatIconModule,
                    MatCheckboxModule,
                    TranslateModule,
                    TimeAgoPipeModule,
                    RandomGradientPipeModule,
                    NullOrUndefinedHandlerPipeModule,
                    SliceWithDotsPipeModule,
                    ToIconPipeModule,
                    TimeAgoPipeModule,
                    BdDatePipeModule,
                    OrderedKeyValuePipeModule,
                    FirstLetterPipeModule,
                    DomElementValidatorDirectiveModule,
                    ShortPressDirectiveModule,
                    RandomClassDirectiveModule,
                    ApiDataHandlerDirectiveModule,
                    ActionMicroPipesModule
                ],
                exports: [
                    MatDynamicTableComponent,
                ]
            },] }
];

function instanceOfAvatarColumnInterface(object) {
    return object.discriminator === 'AvatarColumn';
}

function instanceOfDateColumnInterface(object) {
    return object.discriminator === 'DateColumn';
}

function instanceOfIconColumnInterface(object) {
    return object.discriminator === 'IconColumn';
}

function instanceOfProgressBarColumnInterface(object) {
    return object.discriminator === 'ProgressBarColumn';
}

function instanceOfTextColumnInterface(object) {
    return object.discriminator === 'TextColumn';
}

const EXPANDED_ROW_DATA = new InjectionToken('EXPANDED_ROW_DATA');
const TABLE_CONFIG = new InjectionToken('TABLE_CONFIG');
const TABLE = new InjectionToken('TABLE');

var ReservedNamesV2;
(function (ReservedNamesV2) {
    ReservedNamesV2["expandArrowColumn"] = "__expandArrowColumn__";
    ReservedNamesV2["expandedColumn"] = "__expandedColumnColumn__";
    ReservedNamesV2["actionsColumn"] = "__actionsColumnColumn__";
    ReservedNamesV2["bulkCheckboxColumn"] = "__bulkCheckboxColumn__";
    ReservedNamesV2["bulkMassCheckboxColumn"] = "__bulkMassCheckboxColumn__";
    ReservedNamesV2["infoColumn"] = "__infoColumn__";
})(ReservedNamesV2 || (ReservedNamesV2 = {}));

class FiltersDialogComponent {
    constructor(dialogRef) {
        this.dialogRef = dialogRef;
    }
    resetAndClose() {
        this.form.reset();
        this.dialogRef.close(this.form.value);
    }
}

function instanceOfProgressBarColumnInterface$1(object) {
    return object.discriminator === 'ProgressBarColumn';
}

function instanceOfTextColumnInterface$1(object) {
    return object.discriminator === 'TextColumn';
}

var TextSearchModeEnum;
(function (TextSearchModeEnum) {
    TextSearchModeEnum["EQUAL_TO"] = "EQUAL_TO";
    TextSearchModeEnum["CONTAINS"] = "CONTAINS";
    TextSearchModeEnum["STARTS_WITH"] = "STARTS_WITH";
    TextSearchModeEnum["ENDS_WITH"] = "ENDS_WITH";
})(TextSearchModeEnum || (TextSearchModeEnum = {}));

class ActiveFiltersPipe {
    transform(value) {
        if (!value) {
            return [];
        }
        return this.getActiveFilters(value);
    }
    getActiveFilters(filtersValue) {
        return Object.keys(filtersValue).filter(key => this.hasActiveFilter(filtersValue[key]));
    }
    hasActiveFilter(filterValue) {
        if (!filterValue) {
            return false;
        }
        return Object.values(filterValue).some(value => {
            if (Array.isArray(value)) {
                return value.length > 0;
            }
            if (typeof value === 'object' && value !== null) {
                return this.hasActiveFilter(value);
            }
            return !!value;
        });
    }
}
ActiveFiltersPipe.decorators = [
    { type: Pipe, args: [{
                name: 'activeFilters'
            },] }
];

const EXPANDED_ROW_ANIMATION = trigger('detailExpand', [
    state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
    state('expanded', style({ height: '*' })),
    transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
]);

function enumToArray(enumRef) {
    const res = [];
    for (const key in enumRef) {
        res.push(enumRef[key]);
    }
    return res;
}

function mixinHasSubs(base) {
    return class extends base {
        constructor(...args) {
            super(args);
            this.subs$ = [];
        }
        clearSubscriptions() {
            this.subs$.forEach(sub => sub.unsubscribe());
        }
    };
}

class DisplayedColumnsDialogComponent {
    constructor(data, config, dialogRef) {
        this.data = data;
        this.config = config;
        this.dialogRef = dialogRef;
    }
    reorderColumns({ previousIndex, currentIndex }) {
        moveItemInArray(this.data.displayedColumns, previousIndex, currentIndex);
    }
    submit(data) {
        this.dialogRef.close(data
            .filter(elem => elem.isDisplayed)
            .map(elem => elem.name));
    }
}
DisplayedColumnsDialogComponent.decorators = [
    { type: Component, args: [{
                selector: 'bd-displayed-columns-dialog',
                template: "<mat-card-header mat-dialog-title>\n  <mat-card-title>{{config.globalTranslatePrefix + 'customize-columns' | translate}}</mat-card-title>\n</mat-card-header>\n\n<mat-card-content mat-dialog-content>\n  <div (cdkDropListDropped)=\"reorderColumns($event)\" cdkDropList class=\"order-list\">\n    <div *ngFor=\"let displayedColumn of data.displayedColumns\"\n         cdkDrag\n         class=\"order-list__item-box\">\n      <div class=\"order-list__item\">\n        <mat-checkbox [(ngModel)]=\"displayedColumn.isDisplayed\">\n          {{data.translatePrefix + displayedColumn.name | translate}}\n        </mat-checkbox>\n        <span cdkDragHandle class=\"order-list__handler\">\n          <i [class]=\"config.globalIcons.displayedColumnsReorder\"></i>\n        </span>\n      </div>\n    </div>\n  </div>\n</mat-card-content>\n\n<mat-card-actions align=\"end\" mat-dialog-actions>\n  <button color=\"primary\"\n          mat-button\n          mat-dialog-close>\n    {{config.globalTranslatePrefix + 'cancel' | translate | uppercase}}\n  </button>\n  <button (click)=\"submit(data.displayedColumns)\"\n          color=\"primary\"\n          mat-button>\n    {{config.globalTranslatePrefix + 'save' | translate | uppercase}}\n  </button>\n</mat-card-actions>\n",
                styles: [".order-list{display:block;overflow:hidden}.order-list__item-box{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.order-list__item{display:flex;align-items:center;justify-content:space-between;width:280px;height:36px;margin:5px;padding:10px;background:#fff;border:1px solid #e7e7e7;box-sizing:border-box;border-radius:4px}.order-list__handler{cursor:move}.order-list.cdk-drop-list-dragging .order-list__item-box:not(.cdk-drag-placeholder){transition:transform .25s cubic-bezier(0,0,.2,1)}.cdk-drag-placeholder{opacity:0}.cdk-drag-animating{transition:transform .25s cubic-bezier(0,0,.2,1)}"]
            },] }
];
DisplayedColumnsDialogComponent.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [MAT_DIALOG_DATA,] }] },
    { type: undefined, decorators: [{ type: Inject, args: [TABLE_CONFIG,] }] },
    { type: MatDialogRef }
];

class DefaultFiltersDialogComponent extends FiltersDialogComponent {
    constructor(data, dialogRef, dynamicFormService) {
        super(dialogRef);
        this.data = data;
        this.dialogRef = dialogRef;
        this.dynamicFormService = dynamicFormService;
    }
    ngOnInit() {
        this.form = this.dynamicFormService.generateForm(this.data.metadata, this.data.initValue);
    }
    resetAndClose() {
        this.form.reset();
        this.dialogRef.close(this.form.value);
    }
}
DefaultFiltersDialogComponent.decorators = [
    { type: Component, args: [{
                selector: 'bd-default-filters-dialog',
                template: "<mat-card-header mat-dialog-title>\n  <span>{{'filters' | translate}}</span>\n  <button (click)=\"resetAndClose()\" [color]=\"'primary'\" mat-button>{{'reset-all' | translate}}</button>\n</mat-card-header>\n\n<mat-card-content mat-dialog-content>\n  <bd-dynamic-form [form]=\"form\" [metadata]=\"data.metadata\"></bd-dynamic-form>\n</mat-card-content>\n\n<mat-card-actions mat-dialog-actions align=\"end\">\n  <button [color]=\"'primary'\" mat-button mat-dialog-close>{{'cancel' | translate}}</button>\n  <button [color]=\"'primary'\" [mat-dialog-close]=\"form.value\" mat-button>{{'save' | translate}}</button>\n</mat-card-actions>\n",
                styles: [""]
            },] }
];
DefaultFiltersDialogComponent.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [MAT_DIALOG_DATA,] }] },
    { type: MatDialogRef },
    { type: DynamicFormService, decorators: [{ type: Optional }] }
];

class TableHeaderDirective {
}
TableHeaderDirective.decorators = [
    { type: Directive, args: [{
                selector: '[bdTableHeader]'
            },] }
];

function instanceOfAvatarColumnInterface$1(object) {
    return object.discriminator === 'AvatarColumn';
}

function instanceOfDateColumnInterface$1(object) {
    return object.discriminator === 'DateColumn';
}

function instanceOfIconColumnInterface$1(object) {
    return object.discriminator === 'IconColumn';
}

var ActionConditionOperatorsEnum;
(function (ActionConditionOperatorsEnum) {
    ActionConditionOperatorsEnum["EQUALS"] = "EQUALS";
    ActionConditionOperatorsEnum["NOTEQUAL"] = "NOTEQUAL";
    ActionConditionOperatorsEnum["TRUTHY"] = "TRUTHY";
    ActionConditionOperatorsEnum["IN"] = "IN";
})(ActionConditionOperatorsEnum || (ActionConditionOperatorsEnum = {}));

class ActionsConfigService {
    constructor(domElementValidatorService) {
        this.domElementValidatorService = domElementValidatorService;
        this.actionRequest = new EventEmitter();
        this._actions = {};
    }
    set actions(actions) {
        this._actions = actions;
    }
    get actions() {
        return this._actions;
    }
    set bulkActions(bulkActions) {
        this._bulkActions = bulkActions;
    }
    get bulkActions() {
        return this._bulkActions;
    }
    set headerActions(headerActions) {
        this._headerActions = headerActions;
    }
    get headerActions() {
        return this._headerActions;
    }
    set singleActions(singleActions) {
        this._singleActions = singleActions;
    }
    get singleActions() {
        return this._singleActions;
    }
    checkActions(actionsRequestObservsLength) {
        let header = false;
        let bulk = false;
        let single = false;
        for (const action of Object.values(this.actions)) {
            header = header || action.type === 'header';
            bulk = bulk || action.type === 'bulk' || action.type === 'both';
            single = single || action.type === 'single' || action.type === 'both';
        }
        this.hasSingleActions = single && actionsRequestObservsLength;
        this.hasBulkActions = bulk && actionsRequestObservsLength;
        this.hasHeaderButtons = header && actionsRequestObservsLength;
    }
    filterBulkActions(_bulkActions, actionConfig) {
        return _bulkActions.filter(action => this.domElementValidatorService.validateRole(actionConfig[action].role));
    }
    filterSingleActions(actions, elem) {
        return Object.keys(actions)
            .filter(key => this.checkActionType(actions[key]) &&
            this.checkActionRole(actions[key].role) &&
            this.checkActionCondition(elem, actions[key].condition));
    }
    initActions(actions) {
        this.actions = actions;
        const bulk = [];
        const header = [];
        const single = [];
        Object.entries(actions)
            .forEach(([key, value]) => {
            switch (value.type) {
                case 'both':
                case 'bulk':
                    bulk.push(key);
                    break;
                case 'header':
                    header.push(key);
                    break;
                default:
                    break;
            }
            if (value.type === 'single' || value.type === 'both') {
                single.push(key);
            }
        });
        this.singleActions = single;
        this.bulkActions = bulk;
        this.headerActions = header;
    }
    initFilterBulkActions() {
        this.bulkActions = this.filterBulkActions(this.bulkActions, this.actions);
        this.hasBulkActions = !!this.bulkActions.length;
    }
    // TODO delete ActionsV3Config when ActionsV2Config will be updated
    checkActionCondition(elem, condition) {
        if (!condition) {
            return true;
        }
        if (typeof condition === 'function') {
            return condition(elem);
        }
        const actualValue = at(elem, condition.key)[0];
        switch (condition.operator) {
            case ActionConditionOperatorsEnum.EQUALS:
                return actualValue === condition.value;
            case ActionConditionOperatorsEnum.TRUTHY:
                return !!actualValue;
            case ActionConditionOperatorsEnum.NOTEQUAL:
                return actualValue !== condition.value;
            case ActionConditionOperatorsEnum.IN:
                return condition.value.some(v => v === actualValue);
            default:
                break;
        }
        return false;
    }
    checkActionRole(role) {
        if (!this.domElementValidatorService || !role || role instanceof Array && role.length === 0) {
            return true;
        }
        if (typeof role === 'string') {
            return this.domElementValidatorService.validateRole(role);
        }
        else if (role instanceof Array) {
            let checkRes = false;
            for (let index = 0; index < role.length; index++) {
                if (this.domElementValidatorService.validateRole(role[index])) {
                    checkRes = true;
                    break;
                }
            }
            return checkRes;
        }
    }
    checkActionType(action) {
        return action.type === 'single' || action.type === 'both';
    }
}
ActionsConfigService.ɵprov = ɵɵdefineInjectable({ factory: function ActionsConfigService_Factory() { return new ActionsConfigService(ɵɵinject(DomElementValidatorService, 8)); }, token: ActionsConfigService, providedIn: "root" });
ActionsConfigService.decorators = [
    { type: Injectable, args: [{ providedIn: 'root' },] }
];
ActionsConfigService.ctorParameters = () => [
    { type: DomElementValidatorService, decorators: [{ type: Optional }] }
];

// eslint-disable-next-line @typescript-eslint/ban-types
class TableService {
    constructor(actionsConfigService, domElementValidatorService) {
        this.actionsConfigService = actionsConfigService;
        this.domElementValidatorService = domElementValidatorService;
    }
    fillColumnsConfigDefaults(columnsConfig) {
        const res = columnsConfig;
        Object.keys(columnsConfig).forEach(key => {
            switch (true) {
                case instanceOfTextColumnInterface$1(columnsConfig[key]):
                    res[key] = this.fillTextColumnDefaults(columnsConfig[key]);
                    break;
                case instanceOfDateColumnInterface$1(columnsConfig[key]):
                    res[key] = this.fillDateColumnDefaults(columnsConfig[key]);
                    break;
                case instanceOfAvatarColumnInterface$1(columnsConfig[key]):
                    res[key] = this.fillAvatarColumnDefaults(columnsConfig[key]);
                    break;
                case instanceOfIconColumnInterface$1(columnsConfig[key]):
                    res[key] = this.fillIconColumnDefaults(columnsConfig[key]);
                    break;
                case instanceOfProgressBarColumnInterface$1(columnsConfig[key]):
                    res[key] = this.fillProgressBarColumnDefaults(columnsConfig[key]);
                    break;
                default:
                    throw new Error('');
            }
        });
        return res;
    }
    hasAnyActiveFilter(requestParams) {
        if (requestParams === undefined || requestParams === null) {
            return false;
        }
        return Object.values(requestParams).some(value => typeof value === 'object' && value !== null || Array.isArray(value)
            ? this.hasAnyActiveFilter(value)
            : !!value);
    }
    parseData(data, columns, actions) {
        const keys = Object.keys(columns);
        return data.map((elem, index) => {
            const systemProperties = this.defineParsedElemSystemProperties(elem, index, actions);
            const dataProperties = this.defineParsedElemDataProperties(elem, columns, keys);
            return Object.assign(Object.assign({}, systemProperties), dataProperties);
        });
    }
    // DEFINING PARSED ELEMENTS
    checkMultipleRole(roles) {
        if (roles.length) {
            for (let index = 0; index < roles.length; index++) {
                if (this.domElementValidatorService.validateRole(roles[index])) {
                    return true;
                }
            }
            return false;
        }
        return true;
    }
    defineParsedElemDataProperties(elem, columns, keys) {
        const res = {};
        keys.forEach(key => {
            switch (true) {
                case instanceOfTextColumnInterface$1(columns[key]):
                    res[key] = this.parseTextColumn(elem, columns[key]);
                    break;
                case instanceOfDateColumnInterface$1(columns[key]):
                    res[key] = this.parseDateColumn(elem, columns[key]);
                    break;
                case instanceOfAvatarColumnInterface$1(columns[key]):
                    res[key] = this.parseAvatarColumn(elem, columns[key]);
                    break;
                case instanceOfIconColumnInterface$1(columns[key]):
                    res[key] = this.parseIconColumn(elem, columns[key]);
                    break;
                case instanceOfProgressBarColumnInterface$1(columns[key]):
                    res[key] = this.parseProgressBarColumn(elem, columns[key]);
                    break;
                default:
                    throw new Error('');
            }
        });
        return res;
    }
    defineParsedElemSystemProperties(elem, originalIndex, actions) {
        // TODO how to get list of current user actions?
        return {
            originalIndex,
            selected: false,
            singleActions: this.actionsConfigService.filterSingleActions(actions, elem),
        };
    }
    fillAvatarColumnDefaults(column) {
        return Object.assign(Object.assign({}, this.fillBaseColumnDefaults(column)), column);
    }
    fillBaseColumnDefaults(column) {
        return Object.assign({ sortable: false, hidden: false }, column);
    }
    fillDateColumnDefaults(column) {
        return Object.assign(Object.assign(Object.assign({}, this.fillBaseColumnDefaults(column)), { format: 'yyyy/MM/dd', timeAgo: false }), column);
    }
    fillIconColumnDefaults(column) {
        return Object.assign(Object.assign({}, this.fillBaseColumnDefaults(column)), column);
    }
    fillProgressBarColumnDefaults(column) {
        return Object.assign(Object.assign({}, this.fillBaseColumnDefaults(column)), column);
    }
    fillTextColumnDefaults(column) {
        return Object.assign(Object.assign(Object.assign({}, this.fillBaseColumnDefaults(column)), { subPath: null, limit: 30, translatePrefix: '', subHeaderKey: undefined, separator: ' ', mask: undefined }), column);
    }
    parseAvatarColumn(data, column) {
        const arrayRes = this.parseBaseColumn(data, column);
        const res = arrayRes
            .map(elem => elem ? elem[0] : elem)
            .join('');
        return res;
    }
    parseBaseColumn(data, column) {
        let array = at(data, column.paths);
        if ('dynamicFieldIndex' in column) {
            array = array.map(elem => {
                const keys = Object.keys(elem);
                return elem[keys[0]];
            });
        }
        return array;
    }
    parseDateColumn(data, column) {
        const arrayRes = this.parseBaseColumn(data, column);
        return arrayRes[0];
    }
    parseIconColumn(data, column) {
        const arrayRes = this.parseBaseColumn(data, column);
        return arrayRes[0];
    }
    parseProgressBarColumn(data, column) {
        const actualRes = this.parseBaseColumn(data, column)[0];
        const maxRes = at(data, column.maxValuePaths)[0];
        const ratioRes = actualRes && maxRes && actualRes / maxRes * 100;
        let classRes = '';
        if (column.classesPerRatio) {
            column.classesPerRatio.forEach(classPerRatio => {
                if (classPerRatio.isAlways) {
                    classRes += `${classPerRatio.klass} `;
                }
                else if (classPerRatio.ratioRange &&
                    ratioRes >= classPerRatio.ratioRange.from &&
                    ratioRes <= classPerRatio.ratioRange.to) {
                    classRes += `${classPerRatio.klass} `;
                }
            });
        }
        const tooltipRes = ratioRes ? `${actualRes} / ${maxRes}` : '';
        return { actual: actualRes, max: maxRes, ratio: ratioRes, klass: classRes, tooltip: tooltipRes };
    }
    parseTextColumn(data, column) {
        const arrayRes = this.parseBaseColumn(data, column);
        const mainRes = arrayRes
            .map((elem, index) => {
            if (!elem) {
                return elem;
            }
            if (column.mask) {
                elem = column.mask(elem);
            }
            if (column.translatePrefix) {
                // eslint-disable-next-line @typescript-eslint/restrict-plus-operands
                elem = column.translatePrefix + elem;
            }
            if (column.separator && index < arrayRes.length - 1) {
                if (typeof column.separator === 'string') {
                    // eslint-disable-next-line @typescript-eslint/restrict-plus-operands
                    elem = elem + column.separator;
                }
                else if (column.separator instanceof Array) {
                    // eslint-disable-next-line @typescript-eslint/restrict-plus-operands
                    elem = elem + column.separator[index];
                }
            }
            return elem;
        })
            .join('') || null;
        let subRes;
        if (column.subPath) {
            // fucking lodash types...
            subRes = at(data, column.subPath);
        }
        return {
            main: mainRes,
            sub: subRes === null || subRes === void 0 ? void 0 : subRes[0],
        };
    }
}
TableService.decorators = [
    { type: Injectable }
];
TableService.ctorParameters = () => [
    { type: ActionsConfigService },
    { type: DomElementValidatorService, decorators: [{ type: Optional }] }
];

const ɵ0 = { appearance: 'legacy' };
class TableComponent extends mixinHasSubs(class {
}) {
    constructor(config, service, actionsConfigService, injector, dialog, cd, activeFiltersPipe, dynamicFormService) {
        super();
        this.config = config;
        this.service = service;
        this.actionsConfigService = actionsConfigService;
        this.injector = injector;
        this.dialog = dialog;
        this.cd = cd;
        this.activeFiltersPipe = activeFiltersPipe;
        this.dynamicFormService = dynamicFormService;
        this.customColumnTemplateRefs = {};
        this.filtersDialogRef = DefaultFiltersDialogComponent;
        this.globalSort = true;
        this.rowClickAction = 'open';
        this.textSearchPlaceholder = 'Search';
        this.translatePrefix = '';
        this.actionRequest = new EventEmitter();
        this.bulkActionRequest = new EventEmitter();
        this.displayedColumnsUpdate = new EventEmitter();
        this._actions = {};
        this.bulkSelection = new SelectionModel(true, []);
        this.componentClass = true;
        this.progressBarColumns = [];
        this.reservedNames = ReservedNamesV2;
        this.textColumns = [];
        this.textSearchControl = new FormControl('');
        this.textSearchEnabled = false;
        this.textSearchableColumns = [];
    }
    set actions(actions) {
        this._actions = actions;
        const bulk = [];
        const header = [];
        Object.keys(actions).forEach(key => {
            switch (actions[key].type) {
                case 'both':
                case 'bulk':
                    bulk.push(key);
                    break;
                case 'header':
                    header.push(key);
                    break;
                default:
                    break;
            }
        });
        this._bulkActions = bulk;
        this._headerActions = header;
    }
    get actions() {
        return this._actions;
    }
    set columns(columns) {
        this._columns = this.service.fillColumnsConfigDefaults(columns);
        this.displayedColumns = Object.keys(this._columns)
            .filter(key => !this._columns[key].hidden);
        this.textColumns = Object.keys(this._columns)
            .filter(key => instanceOfTextColumnInterface$1(this._columns[key]));
        this.progressBarColumns = Object.keys(this._columns)
            .filter(key => instanceOfProgressBarColumnInterface$1(this._columns[key]));
        this.textSearchableColumns = Object.entries(this._columns)
            .filter(([key, value]) => !!value.textSearch)
            .map(([key, value]) => key);
        this.textSearchEnabled = this.textSearchableColumns.length > 0;
    }
    // LIFECYCLE HOOKS START
    ngOnChanges(changes) {
        // need to exclude first change because setParams() need to be called first (in ngOnInit())
        if (changes.columns && !changes.columns.firstChange) {
            this.addSystemDisplayColumns();
        }
        if (changes.data && !changes.data.firstChange) {
            this.updateDataSource();
        }
        if (changes.actions && !changes.actions.firstChange) {
            this.filterBulkActions();
        }
        if (changes.pagination && !changes.pagination.firstChange) {
            this.initPagination();
            this.cd.detectChanges();
        }
        if (changes.data && this.hasExpandedRow) {
            this.initExpandedComponentInjectors();
        }
    }
    ngOnInit() {
        this.setFilterPredicate();
        this.setSortingDataAccessor();
        this.setParams();
        this.addSystemDisplayColumns();
        this.initDataSource();
        this.initTextSearch();
        if (this.hasBulkActions) {
            this.filterBulkActions();
        }
        if (this.hasFilters || this.textSearchEnabled) {
            this.dataSource.filterPredicate = this.filterPredicate;
            if (this.hasFilters) {
                this.initFilters();
            }
        }
    }
    ngAfterViewInit() {
        if (this.hasPagination) {
            this.initPagination();
        }
        if (this.hasGlobalSort) {
            this.initGlobalSort();
        }
        this.customHeader = !!this.tableHeader;
        this.cd.detectChanges();
    }
    ngOnDestroy() {
        this.clearSubscriptions();
    }
    // LIFECYCLE HOOKS END
    emitActionRequest(action, originalIndex) {
        const req = {
            action,
            data: this.data[originalIndex],
        };
        this.actionRequest.emit(req);
    }
    emitBulkActionRequest(action) {
        const req = {
            action,
            data: this.data
                .filter((elem, index) => this.bulkSelection.selected
                .map(parsedElem => parsedElem.originalIndex)
                .includes(index)),
        };
        this.bulkActionRequest.emit(req);
    }
    emitHeaderActionRequest(action) {
        this.actionRequest.emit({ action, data: null });
    }
    isAllSelected() {
        const numSelected = this.bulkSelection.selected.length;
        const numRows = this.dataSource.data.length;
        return numSelected === numRows;
    }
    isCurrentPageSelected() {
        const pageIndex = this.dataSource.paginator.pageIndex;
        const pageSize = this.dataSource.paginator.pageSize;
        return this.dataSource.sortData(this.dataSource.filteredData, this.dataSource.sort)
            .slice(pageIndex * pageSize, pageIndex * pageSize + pageSize)
            .every(elem => this.bulkSelection.isSelected(elem));
    }
    onExpandArrowClicked(element) {
        this.expandedElement = this.expandedElement === element ? null : element;
    }
    onRowClicked(element) {
        if (element.singleActions.includes(this.rowClickAction)) {
            this.emitActionRequest(this.rowClickAction, element.originalIndex);
        }
    }
    openDisplayColumnsDialog() {
        const allColumns = Object.keys(this._columns);
        const currentDisplayColumns = this.displayedColumns.filter(elem => !enumToArray(ReservedNamesV2).includes(elem));
        const displayedColumnsDialogData = {
            translatePrefix: this.translatePrefix,
            displayedColumns: currentDisplayColumns
                .map(elem => ({
                name: elem,
                isDisplayed: true,
            }))
                .concat(allColumns
                .filter(elem => !currentDisplayColumns.includes(elem))
                .map(elem => ({
                name: elem,
                isDisplayed: false,
            }))),
        };
        this.subs$.push(this.dialog.open(DisplayedColumnsDialogComponent, {
            data: displayedColumnsDialogData,
        }).afterClosed().pipe(filter(res => !!res)).subscribe(res => {
            this.displayedColumnsUpdate.emit(res);
        }));
    }
    openFiltersDialog() {
        this.subs$.push(this.dialog.open(this.filtersDialogRef, {
            data: {
                initValue: this.filtersValue,
                metadata: this.filtersMetadata,
                additionalData: this.additionalFiltersDialogData,
            },
        }).afterClosed().pipe(filter(res => !!res)).subscribe(res => {
            this.updateFilterValue(res);
            this.dataSource.filter = JSON.stringify(this.filtersValue);
            this.dataSource.paginator.firstPage();
        }));
    }
    removeFilter(control) {
        this.filtersValue = Object.entries(this.filtersValue)
            .reduce((accumulator, [key, value]) => key === control ? accumulator : Object.assign(Object.assign({}, accumulator), { [key]: value }), {});
        for (const name of this.textSearchableColumns) {
            if (!this.filtersValue[name]) {
                this.textSearchControl.setValue('');
            }
        }
        this.dataSource.filter = JSON.stringify(this.filtersValue);
        this.dataSource.paginator.firstPage();
    }
    toggleAll() {
        if (this.isAllSelected()) {
            this.bulkSelection.clear();
        }
        else {
            this.bulkSelection.select(...this.dataSource.data);
        }
    }
    toggleCurrentPage() {
        const pageIndex = this.dataSource.paginator.pageIndex;
        const pageSize = this.dataSource.paginator.pageSize;
        if (this.isCurrentPageSelected()) {
            this.dataSource.sortData(this.dataSource.filteredData, this.dataSource.sort)
                .slice(pageIndex * pageSize, pageIndex * pageSize + pageSize)
                .forEach(elem => {
                this.bulkSelection.deselect(elem);
            });
        }
        else {
            this.dataSource.sortData(this.dataSource.filteredData, this.dataSource.sort)
                .slice(pageIndex * pageSize, pageIndex * pageSize + pageSize)
                .forEach(elem => {
                this.bulkSelection.select(elem);
            });
        }
    }
    addSystemDisplayColumns() {
        if (this.hasExpandedRow) {
            this.displayedColumns.unshift(ReservedNamesV2.expandArrowColumn);
        }
        if (this.hasBulkActions) {
            this.displayedColumns.unshift(ReservedNamesV2.bulkCheckboxColumn);
        }
        if (this.hasSingleActions) {
            this.displayedColumns.push(ReservedNamesV2.actionsColumn);
        }
    }
    checkActions() {
        let header = false;
        let bulk = false;
        let single = false;
        for (const action of Object.values(this._actions)) {
            header = header || action.type === 'header';
            bulk = bulk || action.type === 'bulk' || action.type === 'both';
            single = single || action.type === 'single' || action.type === 'both';
        }
        this.hasSingleActions = single && !!this.actionRequest.observers.length;
        this.hasBulkActions = bulk && !!this.actionRequest.observers.length;
        this.hasHeaderButtons = header && !!this.actionRequest.observers.length;
    }
    filterBulkActions() {
        this._bulkActions = this.actionsConfigService.filterBulkActions(this._bulkActions, this._actions);
    }
    filterCellByTextSearch(column, columnContent, searchString) {
        if (!columnContent && searchString) {
            return false;
        }
        columnContent = String(columnContent);
        if (typeof column.textSearch === 'function') {
            return column.textSearch(columnContent);
        }
        switch (column.textSearch) {
            case TextSearchModeEnum.CONTAINS:
                return RegExp(searchString.toLowerCase()).exec(columnContent.toLowerCase());
            case TextSearchModeEnum.STARTS_WITH:
                return columnContent.toLowerCase().startsWith(searchString.toLowerCase());
            case TextSearchModeEnum.ENDS_WITH:
                return columnContent.toLowerCase().endsWith(searchString.toLowerCase());
            case TextSearchModeEnum.EQUAL_TO:
                return columnContent.toLowerCase() === searchString.toLowerCase();
            default: return false;
        }
    }
    filterRowByTextSearch(data) {
        if (!this.textSearchableColumns || !this.textSearchControl.value) {
            return true;
        }
        const searchString = this.textSearchControl.value;
        for (const name of this.textSearchableColumns) {
            const content = data[name].main;
            const column = this._columns[name];
            if (this.filterCellByTextSearch(column, content, searchString)) {
                return true;
            }
        }
        return false;
    }
    initDataSource() {
        this.dataSource = new MatTableDataSource(this.service.parseData(this.data, this._columns, this._actions));
        if (this.hasExpandedRow) {
            this.initExpandedComponentInjectors();
        }
    }
    initExpandedComponentInjectors() {
        this.expandedComponentInjectors = this.data.map(elem => Injector.create({
            providers: [
                { provide: EXPANDED_ROW_DATA, useValue: elem },
            ],
            parent: this.injector,
        }));
    }
    initFilters() {
        this.filtersMetadata = {
            discriminator: 'group',
            direction: 'row',
            controls: mapValues(this._columns, column => ({
                discriminator: 'control',
                showTitle: true,
                control: column.control,
            })),
        };
        Object.keys(this.filtersMetadata.controls)
            .forEach(key => {
            if (!this.filtersMetadata.controls[key].control) {
                delete this.filtersMetadata.controls[key];
            }
        });
    }
    initGlobalSort() {
        this.dataSource.sort = this.matSort;
        this.dataSource.sortingDataAccessor = this.sortingDataAccessor;
    }
    initPagination() {
        this.matPaginator.pageIndex = this.pagination.pageIndex;
        this.matPaginator.pageSize = this.pagination.pageSize;
        this.matPaginator.pageSizeOptions = this.config.paginatorPageSizeOptions;
        if (this.hasPagination) {
            this.dataSource.paginator = this.matPaginator;
        }
    }
    initTextSearch() {
        this.subs$.push(this.textSearchControl.valueChanges.subscribe(text => {
            if (!this.filtersValue) {
                this.filtersValue = {};
            }
            const searchFilter = {};
            for (const name of this.textSearchableColumns) {
                searchFilter[name] = text;
            }
            this.updateFilterValue(searchFilter);
            this.dataSource.filter = JSON.stringify(this.filtersValue);
        }));
    }
    setFilterPredicate() {
        this.filterPredicate = data => {
            if (!this.activeFiltersPipe.transform(this.filtersValue).length && !this.textSearchControl.value) {
                return true;
            }
            const res = [];
            this.activeFiltersPipe.transform(this.filtersValue).forEach(key => {
                let index;
                switch (true) {
                    case this.textColumns.includes(key):
                        index = data[key].main;
                        break;
                    case this.progressBarColumns.includes(key):
                        index = data[key].actual;
                        break;
                    default:
                        index = data[key];
                        break;
                }
                switch (this._columns[key].control.discriminator) {
                    case 'selection-list':
                        res.push(this.filtersValue[key].includes(index));
                        break;
                    case 'textbox':
                        res.push(index.includes(this.filtersValue[key]));
                        break;
                    case 'dropdown':
                        res.push(index === this.filtersValue[key]);
                        break;
                    case 'chip-list-autocomplete':
                        res.push(this.filtersValue[key].includes(index));
                        break;
                    default:
                        break;
                }
            });
            res.push(!!this.filterRowByTextSearch(data));
            return res.every(elem => elem);
        };
    }
    setParams() {
        this.checkActions();
        this.hasPagination = !!this.pagination;
        this.hasGlobalSort = !!this.globalSort;
        this.hasExpandedRow = !!this.expandedComponentRef;
        this.hasFilters = !!map$1(this._columns, 'control').filter(elem => elem).length ||
            !(this.filtersDialogRef.toString() === DefaultFiltersDialogComponent.toString());
        this.hasDisplayedColumnsUpdate = !!this.displayedColumnsUpdate.observers.length;
        this.hasCursorPointer = !!(this._actions[this.rowClickAction] && this.hasSingleActions);
        this.hasHeader = !!this.title || this.hasBulkActions || this.hasFilters ||
            this.hasDisplayedColumnsUpdate || this.hasHeaderButtons || this.textSearchEnabled;
    }
    setSortingDataAccessor() {
        this.sortingDataAccessor = (data, property) => {
            switch (true) {
                case this.textColumns.includes(property):
                    return data[property].main;
                case this.progressBarColumns.includes(property):
                    return data[property].actual;
                default:
                    return data[property];
            }
        };
    }
    updateDataSource() {
        this.dataSource.data = this.service.parseData(this.data, this._columns, this._actions);
    }
    updateFilterValue(filters) {
        this.filtersValue = Object.assign(Object.assign({}, this.filtersValue), filters);
    }
}
TableComponent.decorators = [
    { type: Component, args: [{
                // eslint-disable-next-line @angular-eslint/component-selector
                selector: 'bd-table',
                template: "<div *ngIf=\"hasHeader && !customHeader\" class=\"table-header\" fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n  <div class=\"title-wrapper\">\n    <span *ngIf=\"title\" class=\"mat-headline title-text\">{{translatePrefix + title | translate}}</span>\n\n    <ng-container *ngIf=\"hasBulkActions && bulkSelection.hasValue()\">\n        <span class=\"mat-small selected-from-text fade-in\">\n          {{bulkSelection.selected.length}}\n          {{config.globalTranslatePrefix + 'selected' | translate}}\n        </span>\n\n      <button (click)=\"toggleAll()\"\n              *ngIf=\"isCurrentPageSelected()\"\n              class=\"mat-button-with-transparent-background\"\n              color=\"primary\"\n              mat-button>\n        <ng-container *ngIf=\"isAllSelected(); else selectTextPlaceholder\">\n          {{'deselect-all' | translate}}\n        </ng-container>\n\n        <ng-template #selectTextPlaceholder>\n          {{'select-all' | translate}}\n        </ng-template>\n\n        {{dataSource.data.length}}\n\n        {{'rows-in-this-table' | translate}}\n      </button>\n    </ng-container>\n  </div>\n\n  <div *ngIf=\"textSearchEnabled\" class=\"text-search-container\">\n    <mat-form-field appearance=\"legacy\">\n      <mat-label>{{textSearchPlaceholder}}</mat-label>\n      <mat-icon matPrefix>search</mat-icon>\n      <input matInput [formControl]=\"textSearchControl\" [placeholder]=\"textSearchPlaceholder\">\n    </mat-form-field>\n  </div>\n\n  <div *ngIf=\"hasBulkActions && bulkSelection.hasValue(); else filtersAndDisplayColumnsButtons\"\n       class=\"fade-in\">\n    <ng-container *ngFor=\"let bulkAction of _bulkActions; let index = index; let last = last\">\n      <ng-container *ngIf=\"index >= 0 && index <= 2\">\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"_actions[bulkAction].custom && !config.actionIcons[bulkAction]\"\n                [matTooltip]=\"_actions[bulkAction].custom.label | translate\"\n                class=\"bulk-action-button\"\n                mat-icon-button>\n          <i [class]=\"_actions[bulkAction].custom.iconClass\"></i>\n        </button>\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"config.actionIcons[bulkAction] && !_actions[bulkAction].custom\"\n                [matTooltip]=\"config.actionIcons[bulkAction].label\"\n                class=\"bulk-action-button\"\n                mat-icon-button>\n          <i [class]=\"config.actionIcons[bulkAction].iconClass\"></i>\n        </button>\n      </ng-container>\n\n      <ng-container *ngIf=\" last && index > 2\">\n        <button [matMenuTriggerFor]=\"bulkActionsMenu\"\n                class=\"bulk-action-button\"\n                mat-icon-button>\n          <i [class]=\"config.globalIcons.actions\"></i>\n        </button>\n      </ng-container>\n    </ng-container>\n  </div>\n\n  <ng-template #filtersAndDisplayColumnsButtons>\n    <div class=\"fade-in\">\n      <ng-container *ngIf=\"(filtersValue | activeFilters) as activeFilters\">\n        <ng-container *ngIf=\"activeFilters.length\">\n          <span class=\"filtered-by-text mat-small\">{{config.globalTranslatePrefix + 'filtered-by' | translate}}:</span>\n          <mat-chip-list>\n            <mat-chip (removed)=\"removeFilter(filter)\"\n                      *ngFor=\"let filter of activeFilters\"\n                      [removable]=\"true\">\\\n              <span class=\"mat-small\">\n                    {{translatePrefix + filter | translate}}\n                  </span>\n              <i [class]=\"config.globalIcons.removeChip\" matChipRemove></i>\n            </mat-chip>\n          </mat-chip-list>\n        </ng-container>\n      </ng-container>\n\n      <button (click)=\"openFiltersDialog()\"\n              *ngIf=\"hasFilters\"\n              [matTooltip]=\"config.globalTranslatePrefix + 'filter' | translate\"\n              class=\"system-button\"\n              mat-stroked-button>\n        <i [class]=\"config.globalIcons.filter\"></i>\n        <span class=\"filter-label\">{{'filter' | translate}}</span>\n      </button>\n\n      <button (click)=\"openDisplayColumnsDialog()\"\n              *ngIf=\"hasDisplayedColumnsUpdate\"\n              [matTooltip]=\"config.globalTranslatePrefix + 'customize-columns' | translate\"\n              class=\"system-button\"\n              mat-stroked-button>\n        <i [class]=\"config.globalIcons.displayedColumns\"></i>\n      </button>\n\n      <!-- HEADER ACTIONS -->\n      <ng-container *ngFor=\"let action of _headerActions\">\n        <button (click)=\"emitHeaderActionRequest(action)\"\n                *bdDomElementValidator=\"_actions[action].role\"\n                class=\"system-button\" color=\"primary\"\n                mat-flat-button>\n          <i [class]=\"_actions[action].custom?.iconClass || config.actionIcons[action]?.iconClass\"></i>\n          <span\n                  class=\"action-label\">{{(_actions[action].custom?.label || config.actionIcons[action]?.label) | translate | uppercase}}</span>\n        </button>\n      </ng-container>\n    </div>\n  </ng-template>\n</div>\n\n<ng-content select=\"[bdTableHeader]\"></ng-content>\n\n<div class=\"mat-elevation-z1\">\n  <div class=\"table-wrapper\">\n    <table [dataSource]=\"dataSource\"\n           mat-table\n           matSort\n           multiTemplateDataRows>\n\n      <!-- BULK CHECKBOX COLUMN -->\n      <ng-container *ngIf=\"hasBulkActions\"\n                    [matColumnDef]=\"reservedNames.bulkCheckboxColumn\"\n                    [sticky]=\"true\">\n        <th *matHeaderCellDef\n            class=\"bulk-checkbox-row-header-cell\"\n            mat-header-cell>\n          <mat-checkbox #massBulkCheckbox\n                        (change)=\"$event && toggleCurrentPage()\"\n                        [checked]=\"bulkSelection.hasValue() && isCurrentPageSelected()\"\n                        [indeterminate]=\"bulkSelection.hasValue() && !isAllSelected()\"\n                        class=\"bulk-checkbox\"></mat-checkbox>\n        </th>\n\n        <td (shortPress)=\"$event.stopPropagation()\"\n            bdClicker\n            *matCellDef=\"let element\"\n            class=\"bulk-checkbox-row-cell\"\n            mat-cell>\n          <mat-checkbox (change)=\"$event && bulkSelection.toggle(element)\"\n                        [checked]=\"bulkSelection.isSelected(element)\"\n                        class=\"checkbox\"></mat-checkbox>\n        </td>\n      </ng-container>\n\n      <!-- EXPAND ARROW COLUMN -->\n      <ng-container *ngIf=\"hasExpandedRow\"\n                    [matColumnDef]=\"reservedNames.expandArrowColumn\"\n                    [sticky]=\"true\">\n        <th *matHeaderCellDef\n            class=\"expand-arrow-row-header-cell\"\n            mat-header-cell></th>\n\n        <td (click)=\"$event.stopPropagation()\"\n            *matCellDef=\"let element\"\n            class=\"expand-arrow-row-cell\"\n            mat-cell>\n            <span (click)=\"onExpandArrowClicked(element);$event.stopPropagation();\"\n                  [ngClass]=\"expandedElement && element === expandedElement ? 'expand-close' : 'expand-open'\"\n                  class=\"expand\">\n              <i [class]=\"config.globalIcons.expand\"></i>\n            </span>\n        </td>\n      </ng-container>\n\n      <!-- DATA COLUMNS -->\n      <ng-container *ngFor=\"let column of _columns | orderedKeyValue; let i=index\"\n                    [matColumnDef]=\"column.key\">\n        <th *matHeaderCellDef\n            [class.avatar-row-header-cell]=\"column.value['discriminator'] === 'AvatarColumn'\"\n            [class.progress-bar-row-header-cell]=\"column.value['discriminator'] === 'ProgressBarColumn'\"\n            [class.text-row-header-cell]=\"column.value['discriminator'] === 'TextColumn'\"\n            [disabled]=\"!globalSort || column.value['sortable'] === false || column.value['discriminator'] === 'AvatarColumn'\"\n            class=\"data-row-header-cell mat-subheading-1\"\n            mat-header-cell\n            mat-sort-header>\n          <ng-container *ngIf=\"column.value['discriminator'] !== 'AvatarColumn'\">\n            {{translatePrefix + column.key | translate}}\n          </ng-container>\n        </th>\n\n        <ng-container *ngIf=\"data\">\n          <td *matCellDef=\"let element\"\n              [class.avatar-row-cell]=\"column.value['discriminator'] === 'AvatarColumn'\"\n              [class.icon-row-cell]=\"column.value['discriminator'] === 'IconColumn'\"\n              [class.progress-bar-row-cell]=\"column.value['discriminator'] === 'ProgressBarColumn'\"\n              [class.text-row-cell]=\"column.value['discriminator'] === 'TextColumn'\"\n              [matTooltipDisabled]=\"column.value['discriminator'] !== 'ProgressBarColumn'\"\n              [matTooltip]=\"element[column.key] && element[column.key]['tooltip']\"\n              class=\"data-row-cell\"\n              mat-cell>\n            <ng-container *ngIf=\"customColumnTemplateRefs[column.key]; else notCustomColumnTemplate\">\n              <ng-container\n                      *ngTemplateOutlet=\"customColumnTemplateRefs[column.key]; context: {element:  data[element['originalIndex']], parsedElement: element}\"></ng-container>\n            </ng-container>\n\n            <ng-template #notCustomColumnTemplate>\n              <ng-container [ngSwitch]=\"column.value['discriminator']\">\n\n                <bd-avatar-column-cell *ngSwitchCase=\"'AvatarColumn'\"\n                                       [cellValue]=\"element[column.key]\"\n                                       [columnConfig]=\"column.value\">\n                </bd-avatar-column-cell>\n\n                <bd-date-column-cell *ngSwitchCase=\"'DateColumn'\"\n                                     [cellValue]=\"element[column.key]\"\n                                     [columnConfig]=\"column.value\">\n                </bd-date-column-cell>\n\n                <bd-icon-column-cell *ngSwitchCase=\"'IconColumn'\"\n                                     [cellValue]=\"element[column.key]\"\n                                     [columnConfig]=\"column.value\"\n                                     (actionRequest)=\"emitActionRequest($event, element['originalIndex'])\">\n                </bd-icon-column-cell>\n\n                <bd-progress-bar-column-cell *ngSwitchCase=\"'ProgressBarColumn'\"\n                                             [cellValue]=\"element[column.key]\"\n                                             [columnConfig]=\"column.value\">\n                </bd-progress-bar-column-cell>\n\n                <bd-text-column-cell *ngSwitchCase=\"'TextColumn'\"\n                                     [cellValue]=\"element[column.key]\"\n                                     [columnConfig]=\"column.value\">\n                </bd-text-column-cell>\n\n              </ng-container>\n            </ng-template>\n\n          </td>\n        </ng-container>\n      </ng-container>\n\n      <!-- EXPANDED ELEMENT COLUMN -->\n      <ng-container *ngIf=\"hasExpandedRow\"\n                    [matColumnDef]=\"reservedNames.expandedColumn\">\n        <td *matCellDef=\"let element; let index = dataIndex\"\n            [colSpan]=\"displayedColumns.length\"\n            class=\"expanded-element-row-cell\"\n            mat-cell>\n          <div [@detailExpand]=\"element == expandedElement ? 'expanded' : 'collapsed'\"\n               class=\"expanded-element-row-cell-element-detail\">\n            <div *ngIf=\"element == expandedElement\"\n                 class=\"expanded-element-row-cell-element-content\">\n              <ng-template\n                      *ngComponentOutlet=\"expandedComponentRef; injector: expandedComponentInjectors[index]\"></ng-template>\n            </div>\n          </div>\n        </td>\n      </ng-container>\n\n      <!-- ACTIONS COLUMN -->\n      <ng-container *ngIf=\"hasSingleActions\"\n                    [matColumnDef]=\"reservedNames.actionsColumn\"\n                    stickyEnd>\n        <th *matHeaderCellDef\n            class=\"actions-row-header-cell\"\n            mat-header-cell></th>\n\n        <td (shortPress)=\"$event.stopPropagation()\"\n            bdClicker\n            *matCellDef=\"let element\"\n            class=\"actions-row-cell\"\n            mat-cell>\n          <button #singleActionsMenuTrigger=\"matMenuTrigger\"\n                  *ngIf=\"element['singleActions'].length\"\n                  [class.menu-opened]=\"singleActionsMenuTrigger.menuOpen\"\n                  [matMenuTriggerData]=\"{element: element}\"\n                  [matMenuTriggerFor]=\"singleActionsMenu\"\n                  class=\"single-actions-button\"\n                  mat-icon-button>\n            <i [class]=\"config.globalIcons.actions\"></i>\n          </button>\n        </td>\n      </ng-container>\n\n      <!-- FINAL THINGS -->\n      <tr *matHeaderRowDef=\"displayedColumns\"\n          class=\"data-header-row\"\n          mat-header-row></tr>\n\n      <tr (shortPress)=\"onRowClicked(element);$event.stopPropagation()\"\n          bdClicker\n          *matRowDef=\"let element; let index = dataIndex; columns: displayedColumns;\"\n          [class.clickable]=\"hasCursorPointer\"\n          [class.selected]=\"bulkSelection.isSelected(element)\"\n          class=\"data-row\"\n          mat-row></tr>\n\n      <ng-container *ngIf=\"hasExpandedRow\">\n        <tr *matRowDef=\"let element; columns: [reservedNames.expandedColumn]\"\n            [class.active]=\"element === expandedElement\"\n            class=\"expanded-element-row\"\n            mat-row></tr>\n      </ng-container>\n\n    </table>\n  </div>\n\n  <mat-paginator [style.display]=\"hasPagination ? 'block' : 'none'\"></mat-paginator>\n</div>\n\n<mat-menu #singleActionsMenu=\"matMenu\">\n  <ng-template matMenuContent let-element=\"element\">\n    <ng-container *ngFor=\"let singleAction of element['singleActions']\">\n      <button (click)=\"emitActionRequest(singleAction, element['originalIndex'])\"\n              mat-menu-item>\n        <ng-container [ngSwitch]=\"true\">\n          <ng-container *ngSwitchCase=\"_actions[singleAction].custom && !config.actionIcons[singleAction]\">\n            <i [class]=\"_actions[singleAction].custom.iconClass\"></i>\n            <span class=\"action-label\">{{_actions[singleAction].custom.label | translate}}</span>\n          </ng-container>\n          <ng-container *ngSwitchCase=\"config.actionIcons[singleAction] && !_actions[singleAction].custom\">\n            <i [class]=\"config.actionIcons[singleAction].iconClass\"></i>\n            <span class=\"action-label\">{{config.actionIcons[singleAction].label | translate}}</span>\n          </ng-container>\n        </ng-container>\n      </button>\n    </ng-container>\n  </ng-template>\n</mat-menu>\n\n<mat-menu #bulkActionsMenu>\n  <ng-template matMenuContent>\n    <ng-container *ngFor=\"let bulkAction of _bulkActions; let index = index\">\n      <ng-container *ngIf=\"index > 2\">\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"actions[bulkAction].custom && !config.actionIcons[bulkAction]\"\n                [matTooltip]=\"actions[bulkAction].custom.label | translate\"\n                mat-menu-item>\n          <!--          <i [class]=\"_actions[bulkAction].custom.iconClass\"></i>-->\n          <span class=\"action-label\">{{actions[bulkAction].custom.label | translate}}</span>\n        </button>\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"config.actionIcons[bulkAction] && !actions[bulkAction].custom\"\n                [matTooltip]=\"config.actionIcons[bulkAction].label\"\n                mat-menu-item>\n          <!--          <i [class]=\"config.actionIcons[bulkAction].iconClass\"></i>-->\n          <span class=\"action-label\">{{config.actionIcons[bulkAction].label | translate}}</span>\n        </button>\n      </ng-container>\n    </ng-container>\n  </ng-template>\n</mat-menu>\n",
                animations: [
                    EXPANDED_ROW_ANIMATION,
                ],
                providers: [
                    { provide: MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: ɵ0 },
                    { provide: TABLE, useExisting: TableComponent },
                ],
                styles: ["@-webkit-keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}.fade-in{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:both;animation-fill-mode:both;-webkit-animation-name:fadeIn;animation-name:fadeIn}:host(.bd-lazy-table),:host(.bd-table){display:block;min-width:100%;padding:0}:host(.bd-lazy-table) .table-header,:host(.bd-table) .table-header{height:40px;margin-bottom:10px}:host(.bd-lazy-table) .table-header .title-wrapper,:host(.bd-table) .table-header .title-wrapper{height:100%;flex-grow:2}:host(.bd-lazy-table) .table-header .title-wrapper .title-text,:host(.bd-table) .table-header .title-wrapper .title-text{color:rgba(0,0,0,.87)}:host(.bd-lazy-table) .table-header .filtered-by-text,:host(.bd-lazy-table) .table-header .selected-from-text,:host(.bd-table) .table-header .filtered-by-text,:host(.bd-table) .table-header .selected-from-text{color:rgba(0,0,0,.54);margin-left:20px;font-weight:500}:host(.bd-lazy-table) .table-header .system-button,:host(.bd-table) .table-header .system-button{margin:0 5px;min-width:40px}:host(.bd-lazy-table) .table-header .system-button:last-of-type,:host(.bd-table) .table-header .system-button:last-of-type{margin-right:0}:host(.bd-lazy-table) .table-header .system-button.mat-stroked-button,:host(.bd-table) .table-header .system-button.mat-stroked-button{background-color:#fff}:host(.bd-lazy-table) .table-header .bulk-action-button,:host(.bd-table) .table-header .bulk-action-button{font-size:20px;color:rgba(0,0,0,.54)}:host(.bd-lazy-table) .table-header .filtered-by-text,:host(.bd-table) .table-header .filtered-by-text{margin-right:10px}:host(.bd-lazy-table) .table-header mat-chip-list,:host(.bd-table) .table-header mat-chip-list{display:inline-block}:host(.bd-lazy-table) .table-header mat-chip-list .mat-chip-remove,:host(.bd-table) .table-header mat-chip-list .mat-chip-remove{line-height:normal}:host(.bd-lazy-table) .table-header .text-search-container,:host(.bd-table) .table-header .text-search-container{margin-right:16px}:host(.bd-lazy-table) .table-header ::ng-deep .text-search-container .mat-form-field-wrapper,:host(.bd-table) .table-header ::ng-deep .text-search-container .mat-form-field-wrapper{position:relative;bottom:-6px}:host(.bd-lazy-table) .table-wrapper,:host(.bd-table) .table-wrapper{overflow:auto}:host(.bd-lazy-table) .table-wrapper .mat-table,:host(.bd-table) .table-wrapper .mat-table{overflow-x:scroll;min-width:100%;border-collapse:inherit}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell{font-weight:500;font-size:13px;color:#000;padding:0 10px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell ::ng-deep .mat-sort-header-button,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell ::ng-deep .mat-sort-header-button{text-align:left}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell,:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.expand-arrow-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.expand-arrow-row-header-cell{width:40px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell{text-align:center}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.progress-bar-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.progress-bar-row-header-cell{min-width:100px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.avatar-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.avatar-row-header-cell{width:40px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell:not(.avatar-row-header-cell),:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell:not(.avatar-row-header-cell){min-width:150px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.actions-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.actions-row-header-cell{text-align:right}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row,:host(.bd-table) .table-wrapper .mat-table .mat-row{transition:background-color .25s}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.data-row.clickable,:host(.bd-table) .table-wrapper .mat-table .mat-row.data-row.clickable{cursor:pointer}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.data-row.selected,:host(.bd-table) .table-wrapper .mat-table .mat-row.data-row.selected{background-color:#f6f6f6}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.expanded-element-row,:host(.bd-table) .table-wrapper .mat-table .mat-row.expanded-element-row{height:0}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.expanded-element-row.active+.data-row .mat-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row.expanded-element-row.active+.data-row .mat-cell{border-top:1px solid #e0e0e0}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row:hover,:host(.bd-table) .table-wrapper .mat-table .mat-row:hover{background-color:#f6f6f6}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.expand-arrow-row-cell .expand.expand-open,:host(.bd-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.expand-arrow-row-cell .expand.expand-open{opacity:1;color:rgba(0,0,0,.87)}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.actions-row-cell .single-actions-button,:host(.bd-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.actions-row-cell .single-actions-button{visibility:visible!important;transition:visibility .25s}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell{color:rgba(0,0,0,.87);font-size:13px;padding:0 10px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.bulk-checkbox-row-cell,:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.bulk-checkbox-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell{text-align:center}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand{display:inline-block;cursor:pointer;transition:all .25s}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-open,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-open{color:rgba(0,0,0,.54)}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-close,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-close{transform:rotate(180deg);color:rgba(0,0,0,.87)}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell{border-bottom-width:0!important}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail{overflow:hidden;display:flex}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail .expanded-element-row-cell-element-content,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail .expanded-element-row-cell-element-content{padding:10px;width:100%}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell{text-align:right}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell .single-actions-button:not(.menu-opened),:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell .single-actions-button:not(.menu-opened){visibility:hidden}.action-label{margin-left:10px}.filter-label{margin-left:5px}", ".gradient-strawberry{background-image:linear-gradient(45deg,#fe0b46,#ffab96)}.gradient-orange{background-image:linear-gradient(45deg,#c471f3,#f671cd)}.gradient-dawn{background-image:linear-gradient(45deg,#f3904f,#3b4371)}.gradient-shdow-night{background-image:linear-gradient(45deg,#000,#53346d)}.gradient-man-of-steel{background-image:linear-gradient(45deg,#780206,#061161)}.gradient-flickr{background-image:linear-gradient(45deg,#33001b,#ff0084)}.gradient-ibiza-sunset{background-image:linear-gradient(45deg,#ee0979,#ff6a00)}.gradient-politics{background-image:linear-gradient(45deg,#2196f3,#f44336)}", ""]
            },] }
];
TableComponent.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [TABLE_CONFIG,] }] },
    { type: TableService },
    { type: ActionsConfigService },
    { type: Injector },
    { type: MatDialog },
    { type: ChangeDetectorRef },
    { type: ActiveFiltersPipe },
    { type: DynamicFormService, decorators: [{ type: Optional }] }
];
TableComponent.propDecorators = {
    actions: [{ type: Input }],
    additionalFiltersDialogData: [{ type: Input }],
    columns: [{ type: Input }],
    customColumnTemplateRefs: [{ type: Input }],
    data: [{ type: Input }],
    expandedComponentRef: [{ type: Input }],
    filtersDialogRef: [{ type: Input }],
    globalSort: [{ type: Input }],
    pagination: [{ type: Input }],
    rowClickAction: [{ type: Input }],
    textSearchPlaceholder: [{ type: Input }],
    title: [{ type: Input }],
    translatePrefix: [{ type: Input }],
    actionRequest: [{ type: Output }],
    bulkActionRequest: [{ type: Output }],
    displayedColumnsUpdate: [{ type: Output }],
    massBulkCheckbox: [{ type: ViewChild, args: ['massBulkCheckbox',] }],
    matPaginator: [{ type: ViewChild, args: [MatPaginator,] }],
    matSort: [{ type: ViewChild, args: [MatSort,] }],
    tableHeader: [{ type: ContentChild, args: [TableHeaderDirective,] }],
    componentClass: [{ type: HostBinding, args: ['class.bd-table',] }]
};

class TableInitStatePlaceholderDirective {
    constructor() { }
}
TableInitStatePlaceholderDirective.decorators = [
    { type: Directive, args: [{
                selector: '[bdTableInitStatePlaceholder]'
            },] }
];
TableInitStatePlaceholderDirective.ctorParameters = () => [];

class TableNoResultPlaceholderDirective {
    constructor() { }
}
TableNoResultPlaceholderDirective.decorators = [
    { type: Directive, args: [{
                selector: '[bdTableNoResultPlaceholder]'
            },] }
];
TableNoResultPlaceholderDirective.ctorParameters = () => [];

var ShowTableModeEnum;
(function (ShowTableModeEnum) {
    ShowTableModeEnum["SHOW_TABLE_DATA"] = "SHOW_TABLE_DATA";
    ShowTableModeEnum["INIT_PLACEHOLDER"] = "INIT_PLACEHOLDER";
    ShowTableModeEnum["NO_RESULT_PLACEHOLDER"] = "NO_RESULT_PLACEHOLDER";
})(ShowTableModeEnum || (ShowTableModeEnum = {}));

var TableLocalStorageEnum;
(function (TableLocalStorageEnum) {
    TableLocalStorageEnum["REQUEST_PARAMS"] = "requestParams";
    TableLocalStorageEnum["PAGINATION"] = "pagination";
    TableLocalStorageEnum["SORT"] = "sort";
    TableLocalStorageEnum["COLUMNS_CONFIG"] = "columnsConfig";
})(TableLocalStorageEnum || (TableLocalStorageEnum = {}));

const ɵ0$1 = { appearance: 'standard' };
// eslint-disable-next-line @typescript-eslint/ban-types
class LazyTableComponent extends mixinHasSubs(class {
}) {
    constructor(config, service, actionsConfigService, injector, dialog, cd) {
        super();
        this.config = config;
        this.service = service;
        this.actionsConfigService = actionsConfigService;
        this.injector = injector;
        this.dialog = dialog;
        this.cd = cd;
        this.storedSettingsConfig = {
            filters: 'localStorage',
            columns: 'localStorage',
            pagination: null,
            sort: null,
        };
        this.customColumnTemplateRefs = {};
        this.filtersDialogConfig = {};
        this.filtersDialogRef = DefaultFiltersDialogComponent;
        this.globalSort = false;
        this.openFilterOnInit = false;
        this.pagination = {
            pageIndex: 0,
            pageSize: 25,
        };
        this.rowClickAction = 'open';
        this.textSearchEnabled = false;
        this.textSearchPlaceholder = 'Search';
        this.translatePrefix = '';
        this.actionRequest = new EventEmitter();
        this.bulkActionRequest = new EventEmitter();
        this.displayedColumnsUpdate = new EventEmitter();
        this.filterRemove = new EventEmitter();
        this.paginationRequest = new EventEmitter();
        this.ShowTableMode = ShowTableModeEnum;
        this.bulkSelection = new SelectionModel(true, []);
        this.dataNotSet = true;
        this.reservedNames = ReservedNamesV2;
        this.showTableMode = ShowTableModeEnum.SHOW_TABLE_DATA;
        this.textSearchControl = new FormControl('');
    }
    set actions(actions) {
        this.actionsConfigService.initActions(actions);
    }
    get actions() {
        return this.actionsConfigService.actions;
    }
    set columns(columns) {
        this._columns = this.service.fillColumnsConfigDefaults(columns);
        this.displayedColumns = Object.entries(this._columns)
            .filter(([key, value]) => !value.hidden)
            .map(([key, value]) => key);
    }
    // LIFECYCLE HOOKS START
    ngOnChanges(changes) {
        // need to exclude first change because setParams() need to be called first (in ngOnInit())
        var _a, _b, _c;
        if (changes.actions && !changes.actions.firstChange) {
            this.actionsConfigService.initFilterBulkActions();
        }
        if (changes.columns && !changes.columns.firstChange) {
            this.addSystemDisplayColumns();
        }
        if (changes.paginatedData) {
            this.bulkSelection.clear();
            if (!changes.paginatedData.firstChange) {
                this.checkDataNotSet();
                this.initDataSource();
                this.matPaginator.length = this.paginatedData.totalItems;
                this.matPaginator.pageIndex = this.pagination.pageIndex;
                this.matPaginator.pageSize = this.pagination.pageSize;
                if (this.bdTableId && ((_a = this.storedSettingsConfig) === null || _a === void 0 ? void 0 : _a.sort)) {
                    this.sort = this.getTableSettingsFromBrowserStorage(this.storedSettingsConfig.sort, TableLocalStorageEnum.SORT);
                }
                if (this.sort) {
                    this.matSort.active = this.sort.active;
                    this.matSort.direction = this.sort.direction;
                    this.dataSource.sort = this.matSort;
                    const activeSortHeader = this.matSort.sortables.get(this.sort.active);
                    // eslint-disable-next-line no-underscore-dangle
                    (_c = (_b = activeSortHeader)._setAnimationTransitionState) === null || _c === void 0 ? void 0 : _c.call(_b, {
                        toState: 'active',
                    });
                }
            }
        }
    }
    ngOnInit() {
        this.setParams();
        this.initDataSource();
        if (this.hasBulkActions) {
            this.actionsConfigService.initFilterBulkActions();
        }
        if (this.hasFilters) {
            this.initFilters();
        }
        this.openFiltersDialogOnInit();
        this.addSystemDisplayColumns();
    }
    ngAfterContentInit() {
        if (this.initStatePlaceholder) {
            this.showTableMode = ShowTableModeEnum.INIT_PLACEHOLDER;
        }
        this.requestTableDataFromSource();
    }
    ngAfterViewInit() {
        this.initPagination();
        this.initPaginatedRequestEmitting();
        this.customHeader = !!this.tableHeader;
        this.cd.detectChanges();
    }
    ngOnDestroy() {
        if (this.filtersDialogInstance) {
            this.filtersDialogInstance.close();
        }
        this.clearSubscriptions();
    }
    emitActionRequest(action, index) {
        const req = {
            action,
            data: this.paginatedData.list[index],
        };
        this.actionRequest.emit(req);
    }
    emitBulkActionRequest(action) {
        const req = {
            action,
            data: this.paginatedData.list
                .filter((elem, index) => this.bulkSelection.selected
                .map(parsedElem => parsedElem.originalIndex)
                .includes(index)),
        };
        this.bulkActionRequest.emit(req);
    }
    emitHeaderActionRequest(action) {
        this.actionRequest.emit({ action, data: null });
    }
    isAllSelected() {
        let res = true;
        this.dataSource.data
            .forEach(elem => {
            if (!this.bulkSelection.isSelected(elem)) {
                res = false;
            }
        });
        return res;
    }
    onExpandArrowClicked(element) {
        this.expandedElement = this.expandedElement === element ? null : element;
    }
    onRowClicked(element) {
        if (element.singleActions.includes(this.rowClickAction)) {
            this.emitActionRequest(this.rowClickAction, element.originalIndex);
        }
    }
    openDisplayColumnsDialog() {
        const allColumns = Object.keys(this._columns);
        const currentDisplayColumns = this.displayedColumns.filter(elem => !enumToArray(ReservedNamesV2).includes(elem));
        const displayedColumnsDialogData = {
            translatePrefix: this.translatePrefix,
            displayedColumns: currentDisplayColumns
                .map(elem => ({
                name: elem,
                isDisplayed: true,
            }))
                .concat(allColumns
                .filter(elem => !currentDisplayColumns.includes(elem))
                .map(elem => ({
                name: elem,
                isDisplayed: false,
            }))),
        };
        this.subs$.push(this.dialog.open(DisplayedColumnsDialogComponent, {
            data: displayedColumnsDialogData,
        }).afterClosed().pipe(filter(res => !!res)).subscribe(res => {
            var _a;
            this.setTableSettingsFromBrowserStorage((_a = this.storedSettingsConfig) === null || _a === void 0 ? void 0 : _a.columns, TableLocalStorageEnum.COLUMNS_CONFIG, res);
            this.displayedColumnsUpdate.emit(res);
        }));
    }
    openFiltersDialog() {
        this.filtersDialogInstance = this.dialog.open(this.filtersDialogRef, Object.assign(Object.assign({}, this.filtersDialogConfig), { data: {
                initValue: this.filtersValue,
                metadata: this.filtersMetadata,
                additionalData: this.additionalFiltersDialogData,
            } }));
        this.subs$.push(this.filtersDialogInstance
            .afterClosed()
            .pipe(filter(res => !!res))
            .subscribe(res => {
            var _a;
            this.setTableSettingsFromBrowserStorage((_a = this.storedSettingsConfig) === null || _a === void 0 ? void 0 : _a.filters, TableLocalStorageEnum.REQUEST_PARAMS, res);
            this.filtersValue = res;
            this.matPaginator.page.emit({
                pageIndex: 0,
                pageSize: this.pagination.pageSize,
                length: this.paginatedData.totalItems,
            });
        }));
    }
    removeFilter(control) {
        var _a;
        this.filtersValue = Object.entries(this.filtersValue).reduce((accumulator, [key, value]) => key === control ? accumulator : Object.assign(Object.assign({}, accumulator), { [key]: value }), {});
        this.setTableSettingsFromBrowserStorage((_a = this.storedSettingsConfig) === null || _a === void 0 ? void 0 : _a.filters, TableLocalStorageEnum.REQUEST_PARAMS, this.filtersValue);
        this.matPaginator.page.emit({
            pageIndex: 0,
            pageSize: this.pagination.pageSize,
            length: this.paginatedData.totalItems,
        });
        this.filterRemove.emit(control);
    }
    toggleAll() {
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        this.isAllSelected() ?
            this.bulkSelection.deselect(...this.dataSource.data) :
            this.bulkSelection.select(...this.dataSource.data);
    }
    addSystemDisplayColumns() {
        if (this.hasExpandedRow) {
            this.displayedColumns.unshift(ReservedNamesV2.expandArrowColumn);
        }
        if (this.hasBulkActions) {
            this.displayedColumns.unshift(ReservedNamesV2.bulkCheckboxColumn);
        }
        if (this.actionsConfigService.hasSingleActions) {
            this.displayedColumns.push(ReservedNamesV2.actionsColumn);
        }
    }
    checkDataNotSet() {
        if (this.paginatedData.totalItems === 0) {
            if (this.noResultPlaceholder) {
                this.showTableMode = ShowTableModeEnum.NO_RESULT_PLACEHOLDER;
            }
            else {
                this.showTableMode = ShowTableModeEnum.SHOW_TABLE_DATA;
            }
        }
        else {
            this.dataNotSet = false;
            this.showTableMode = ShowTableModeEnum.SHOW_TABLE_DATA;
        }
    }
    getTableSettingsFromBrowserStorage(storage, storedSettings) {
        if (storage === 'localStorage') {
            return JSON.parse(localStorage.getItem(this.bdTableId + storedSettings));
        }
        if (storage === 'sessionStorage') {
            return JSON.parse(sessionStorage.getItem(this.bdTableId + storedSettings));
        }
        return;
    }
    initDataSource() {
        this.dataSource = new MatTableDataSource(this.service.parseData(this.paginatedData.list, this._columns, this.actionsConfigService.actions));
        if (this.hasExpandedRow) {
            this.initExpandedComponentInjectors();
        }
    }
    initExpandedComponentInjectors() {
        this.expandedComponentInjectors = this.paginatedData.list.map(elem => Injector.create({
            providers: [
                { provide: EXPANDED_ROW_DATA, useValue: elem },
            ],
            parent: this.injector,
        }));
    }
    initFilters() {
        this.filtersMetadata = {
            discriminator: 'group',
            direction: 'row',
            controls: mapValues(this._columns, column => ({
                discriminator: 'control',
                showTitle: true,
                control: column.control,
            })),
        };
        Object.keys(this.filtersMetadata.controls)
            .forEach(key => {
            if (!this.filtersMetadata.controls[key].control) {
                delete this.filtersMetadata.controls[key];
            }
        });
    }
    initPaginatedRequestEmitting() {
        this.subs$.push(this.matPaginator.page
            .subscribe(({ pageIndex, pageSize }) => {
            var _a;
            const sort = this.matSort.active && this.matSort.direction !== '' ? {
                active: this.matSort.active,
                direction: this.matSort.direction,
            } : null;
            const pagination = { pageIndex, pageSize };
            const textSearch = this.textSearchControl.value ? this.textSearchControl.value : null;
            this.setTableSettingsFromBrowserStorage((_a = this.storedSettingsConfig) === null || _a === void 0 ? void 0 : _a.pagination, TableLocalStorageEnum.PAGINATION, pagination);
            this.paginationRequest.emit({ pagination, sort, requestParams: this.filtersValue, textSearch });
        }), this.matSort.sortChange
            .subscribe(({ active, direction }) => {
            var _a;
            const sort = active && direction !== '' ? { active, direction } : null;
            const pagination = { pageIndex: this.matPaginator.pageIndex, pageSize: this.matPaginator.pageSize };
            const textSearch = this.textSearchControl.value ? this.textSearchControl.value : null;
            this.setTableSettingsFromBrowserStorage((_a = this.storedSettingsConfig) === null || _a === void 0 ? void 0 : _a.sort, TableLocalStorageEnum.SORT, sort);
            this.paginationRequest.emit({ pagination, sort, requestParams: this.filtersValue, textSearch });
        }), this.textSearchControl.valueChanges.pipe(distinctUntilChanged(), debounceTime(500)).subscribe(() => {
            this.matPaginator.page.emit({
                pageIndex: 0,
                pageSize: this.pagination.pageSize,
                length: this.paginatedData.totalItems,
            });
        }));
    }
    initPagination() {
        var _a, _b;
        this.matPaginator.pageIndex = this.pagination.pageIndex;
        this.matPaginator.pageSize = this.pagination.pageSize;
        this.matPaginator.pageSizeOptions = this.config.paginatorPageSizeOptions;
        this.matPaginator.length = this.paginatedData.totalItems;
        if (this.sort) {
            this.matSort.active = this.sort.active;
            this.matSort.direction = this.sort.direction;
            this.dataSource.sort = this.matSort;
            const activeSortHeader = this.matSort.sortables.get(this.sort.active);
            // eslint-disable-next-line no-underscore-dangle
            (_b = (_a = activeSortHeader)._setAnimationTransitionState) === null || _b === void 0 ? void 0 : _b.call(_a, {
                toState: 'active',
            });
        }
    }
    openFiltersDialogOnInit() {
        if (this.openFilterOnInit) {
            this.openFiltersDialog();
            this.openFilterOnInit = false;
        }
    }
    requestTableDataFromSource() {
        if (this.service.hasAnyActiveFilter(this.filtersValue) || !this.initStatePlaceholder) {
            this.paginationRequest.emit({ requestParams: this.filtersValue, pagination: this.pagination, sort: this.sort });
        }
    }
    setParams() {
        var _a, _b, _c, _d, _e;
        if (this.bdTableId) {
            this.filtersValue = this.getTableSettingsFromBrowserStorage((_a = this.storedSettingsConfig) === null || _a === void 0 ? void 0 : _a.filters, TableLocalStorageEnum.REQUEST_PARAMS);
            this.pagination = (_c = this.getTableSettingsFromBrowserStorage((_b = this.storedSettingsConfig) === null || _b === void 0 ? void 0 : _b.pagination, TableLocalStorageEnum.PAGINATION)) !== null && _c !== void 0 ? _c : this.pagination;
            this.sort = this.getTableSettingsFromBrowserStorage((_d = this.storedSettingsConfig) === null || _d === void 0 ? void 0 : _d.sort, TableLocalStorageEnum.SORT);
            const columnsConfig = this.getTableSettingsFromBrowserStorage((_e = this.storedSettingsConfig) === null || _e === void 0 ? void 0 : _e.columns, TableLocalStorageEnum.COLUMNS_CONFIG);
            if (columnsConfig) {
                this.displayedColumnsUpdate.emit(columnsConfig);
            }
        }
        this.actionsConfigService.checkActions(!!this.actionRequest.observers.length);
        this.hasBulkActions = this.actionsConfigService.hasBulkActions;
        this.hasPagination = !!this.pagination;
        this.hasGlobalSort = !!this.globalSort;
        this.hasExpandedRow = !!this.expandedComponentRef;
        this.hasFilters = !!map$1(this._columns, 'control').filter(elem => elem).length;
        this.hasDisplayedColumnsUpdate = !!this.displayedColumnsUpdate.observers.length;
        this.hasCursorPointer = !!(this.actionsConfigService.actions[this.rowClickAction] && this.actionsConfigService.hasSingleActions);
        this.hasHeader = !!this.title || this.hasBulkActions || this.hasFilters ||
            this.hasDisplayedColumnsUpdate || this.actionsConfigService.hasHeaderButtons || this.textSearchEnabled;
    }
    setTableSettingsFromBrowserStorage(storage, storedSettings, value) {
        if (this.bdTableId && this.storedSettingsConfig) {
            if (storage === 'localStorage') {
                localStorage.setItem(this.bdTableId + storedSettings, JSON.stringify(value));
                return;
            }
            sessionStorage.setItem(this.bdTableId + storedSettings, JSON.stringify(value));
        }
    }
}
LazyTableComponent.decorators = [
    { type: Component, args: [{
                // eslint-disable-next-line @angular-eslint/component-selector
                selector: 'bd-lazy-table',
                template: "<div *ngIf=\"hasHeader &&\n!customHeader\" class=\"table-header\" fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n  <div class=\"title-wrapper\">\n    <span *ngIf=\"title\" class=\"mat-headline title-text\">{{translatePrefix + title | translate}}</span>\n\n    <ng-container *ngIf=\"hasBulkActions && bulkSelection.hasValue()\">\n      <span class=\"mat-small selected-from-text fade-in\">\n        {{bulkSelection.selected.length}}\n        {{config.globalTranslatePrefix + 'selected' | translate}}\n      </span>\n    </ng-container>\n  </div>\n\n  <div *ngIf=\"textSearchEnabled\" class=\"text-search-container\">\n    <mat-form-field appearance=\"legacy\">\n      <mat-label>{{textSearchPlaceholder}}</mat-label>\n      <mat-icon matPrefix>search</mat-icon>\n      <input matInput [formControl]=\"textSearchControl\" [placeholder]=\"textSearchPlaceholder\"\n             data-e2e=\"search-field\">\n    </mat-form-field>\n  </div>\n\n  <div *ngIf=\"hasBulkActions && bulkSelection.hasValue(); else filtersAndDisplayColumnsButtons\"\n       class=\"fade-in\">\n    <ng-container *ngFor=\"let bulkAction of actionsConfigService.bulkActions; let index = index; let last = last\">\n      <ng-container *ngIf=\"index >= 0 && index <= 2\">\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"actionsConfigService.actions[bulkAction].custom && !config.actionIcons[bulkAction]\"\n                [attr.data-e2e]=\"actionsConfigService.actions[bulkAction].custom.label\"\n                [matTooltip]=\"actionsConfigService.actions[bulkAction].custom.label | translate\"\n                class=\"bulk-action-button\"\n                mat-icon-button>\n          <i [class]=\"actionsConfigService.actions[bulkAction].custom.iconClass\"></i>\n        </button>\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"config.actionIcons[bulkAction] && !actionsConfigService.actions[bulkAction].custom\"\n                [matTooltip]=\"config.actionIcons[bulkAction].label\"\n                class=\"bulk-action-button\"\n                mat-icon-button>\n          <i [class]=\"config.actionIcons[bulkAction].iconClass\"></i>\n        </button>\n      </ng-container>\n\n      <ng-container *ngIf=\" last && index > 2\">\n        <button [matMenuTriggerFor]=\"bulkActionsMenu\"\n                class=\"bulk-action-button\"\n                mat-icon-button>\n          <i [class]=\"config.globalIcons.actions\"></i>\n        </button>\n      </ng-container>\n    </ng-container>\n  </div>\n\n  <ng-template #filtersAndDisplayColumnsButtons>\n    <div class=\"fade-in\">\n      <ng-container *ngIf=\"(filtersValue | activeFilters) as activeFilters\">\n        <ng-container *ngIf=\"activeFilters.length\">\n          <span class=\"filtered-by-text mat-small\">{{config.globalTranslatePrefix + 'filtered-by' | translate}}:</span>\n          <mat-chip-list>\n            <mat-chip (removed)=\"removeFilter(filter)\"\n                      *ngFor=\"let filter of activeFilters\"\n                      [removable]=\"true\">\n              <span class=\"mat-small\">\n<!--                <span [outerHTML]=\"config.globalIcons.activeChip\"></span>-->\n                {{translatePrefix + filter | translate}}\n              </span>\n              <i [class]=\"config.globalIcons.removeChip\" matChipRemove></i>\n            </mat-chip>\n          </mat-chip-list>\n        </ng-container>\n      </ng-container>\n\n      <button (click)=\"openFiltersDialog()\"\n              *ngIf=\"hasFilters\"\n              [matTooltip]=\"config.globalTranslatePrefix + 'filter' | translate\"\n              class=\"system-button\"\n              mat-stroked-button>\n        <i [class]=\"config.globalIcons.filter\"></i>\n        <span class=\"filter-label\">{{'filter' | translate}}</span>\n      </button>\n\n      <button (click)=\"openDisplayColumnsDialog()\"\n              *ngIf=\"hasDisplayedColumnsUpdate\"\n              [matTooltip]=\"config.globalTranslatePrefix + 'displayed-columns' | translate\"\n              class=\"system-button\"\n              mat-stroked-button>\n        <i [class]=\"config.globalIcons.displayedColumns\"></i>\n      </button>\n\n      <!-- HEADER ACTIONS -->\n      <ng-content select=\"[bdTableHeaderActions]\"></ng-content>\n\n      <ng-container *ngFor=\"let action of actionsConfigService.headerActions\">\n        <button (click)=\"emitHeaderActionRequest(action)\"\n                *bdDomElementValidator=\"actionsConfigService.actions[action].role\"\n                class=\"system-button\" color=\"primary\"\n                [attr.data-e2e]=\"action\"\n                mat-flat-button>\n          <i [class]=\"actionsConfigService.actions[action].custom?.iconClass || config.actionIcons[action]?.iconClass\"></i>\n          <span\n                  class=\"action-label\">{{(actionsConfigService.actions[action].custom?.label || config.actionIcons[action]?.label) | translate | uppercase}}</span>\n        </button>\n      </ng-container>\n    </div>\n  </ng-template>\n</div>\n<ng-content select=\"[bdTableHeader]\"></ng-content>\n\n<ng-content *ngIf = \"showTableMode === ShowTableMode.INIT_PLACEHOLDER\" select=\"[bdTableInitStatePlaceholder]\"></ng-content>\n<ng-content *ngIf = \"showTableMode === ShowTableMode.NO_RESULT_PLACEHOLDER\" select=\"[bdTableNoResultPlaceholder]\"></ng-content>\n\n<div\n        class=\"mat-elevation-z1\">\n  <div class=\"table-wrapper\">\n    <table [dataSource]=\"dataSource\"\n           mat-table\n           matSort\n           multiTemplateDataRows\n           [hidden]=\"showTableMode !== ShowTableMode.SHOW_TABLE_DATA\"\n    >\n\n      <!-- BULK CHECKBOX COLUMN -->\n      <ng-container\n              *ngIf=\"hasBulkActions\"\n              [matColumnDef]=\"reservedNames.bulkCheckboxColumn\"\n              [sticky]=\"true\">\n        <th *matHeaderCellDef\n            class=\"bulk-checkbox-row-header-cell\"\n            mat-header-cell>\n          <mat-checkbox #massBulkCheckbox\n                        (change)=\"$event && toggleAll()\"\n                        [checked]=\"bulkSelection.hasValue() && isAllSelected()\"\n                        [indeterminate]=\"bulkSelection.hasValue() && !isAllSelected()\"\n                        class=\"bulk-checkbox\"></mat-checkbox>\n        </th>\n\n        <td (shortPress)=\"$event.stopPropagation()\"\n            bdClicker\n            *matCellDef=\"let element\"\n            class=\"bulk-checkbox-row-cell\"\n            mat-cell>\n          <mat-checkbox (change)=\"$event && bulkSelection.toggle(element)\"\n                        [checked]=\"bulkSelection.isSelected(element)\"\n                        class=\"checkbox\"></mat-checkbox>\n        </td>\n      </ng-container>\n\n      <!-- EXPAND ARROW COLUMN -->\n      <ng-container *ngIf=\"hasExpandedRow\"\n                    [matColumnDef]=\"reservedNames.expandArrowColumn\"\n                    [sticky]=\"true\">\n        <th *matHeaderCellDef\n            class=\"expand-arrow-row-header-cell\"\n            mat-header-cell></th>\n\n        <td (click)=\"$event.stopPropagation()\"\n            *matCellDef=\"let element\"\n            class=\"expand-arrow-row-cell\"\n            mat-cell>\n        <span (click)=\"onExpandArrowClicked(element);$event.stopPropagation();\"\n              [ngClass]=\"expandedElement && element === expandedElement ? 'expand-close' : 'expand-open'\"\n              class=\"expand\">\n          <i [class]=\"config.globalIcons.expand\"></i>\n        </span>\n        </td>\n      </ng-container>\n\n      <!-- DATA COLUMNS -->\n      <ng-container *ngFor=\"let column of _columns | orderedKeyValue; let i=index\"\n                    [matColumnDef]=\"column.key\">\n        <th *matHeaderCellDef\n            [class.avatar-row-header-cell]=\"column.value['discriminator'] === 'AvatarColumn'\"\n            [class.progress-bar-row-header-cell]=\"column.value['discriminator'] === 'ProgressBarColumn'\"\n            [class.text-row-header-cell]=\"column.value['discriminator'] === 'TextColumn'\"\n            [class.text-row-sub-header-cell]=\"column.value['subHeaderKey']?.length\"\n            [disabled]=\"!globalSort || !column.value['sortable'] || column.value['discriminator'] === 'AvatarColumn'\"\n            class=\"data-row-header-cell mat-subheading-1\"\n            mat-header-cell\n            mat-sort-header>\n          <ng-container *ngIf=\"column.value['discriminator'] !== 'AvatarColumn'\">\n            {{translatePrefix + column.key | translate}}\n\n            <ng-container *ngIf=\"column.value['subHeaderKey']\">\n              <span class=\"sub-header\">\n                {{translatePrefix + column.value['subHeaderKey'] | translate}}\n              </span>\n            </ng-container>\n          </ng-container>\n        </th>\n\n        <ng-container *ngIf=\"paginatedData && paginatedData.list\">\n          <td *matCellDef=\"let element\"\n              [class.avatar-row-cell]=\"column.value['discriminator'] === 'AvatarColumn'\"\n              [class.icon-row-cell]=\"column.value['discriminator'] === 'IconColumn'\"\n              [class.progress-bar-row-cell]=\"column.value['discriminator'] === 'ProgressBarColumn'\"\n              [class.text-row-cell]=\"column.value['discriminator'] === 'TextColumn'\"\n              class=\"data-row-header-cell mat-subheading-1\"\n              mat-cell>\n            <ng-container *ngIf=\"customColumnTemplateRefs[column.key]; else notCustomColumnTemplate\">\n              <ng-container\n                      *ngTemplateOutlet=\"customColumnTemplateRefs[column.key]; context: {element:  paginatedData.list[element['originalIndex']], parsedElement: element, column: column}\"></ng-container>\n            </ng-container>\n\n            <ng-template #notCustomColumnTemplate>\n              <ng-container [ngSwitch]=\"column.value['discriminator']\">\n\n                <bd-avatar-column-cell *ngSwitchCase=\"'AvatarColumn'\"\n                                       [cellValue]=\"element[column.key]\"\n                                       [columnConfig]=\"column.value\">\n                </bd-avatar-column-cell>\n\n                <bd-date-column-cell *ngSwitchCase=\"'DateColumn'\"\n                                     [cellValue]=\"element[column.key]\"\n                                     [columnConfig]=\"column.value\">\n                </bd-date-column-cell>\n\n                <bd-icon-column-cell *ngSwitchCase=\"'IconColumn'\"\n                                     [cellValue]=\"element[column.key]\"\n                                     [columnConfig]=\"column.value\"\n                                     (actionRequest)=\"emitActionRequest($event, element['originalIndex'])\">\n                </bd-icon-column-cell>\n\n                <bd-progress-bar-column-cell *ngSwitchCase=\"'ProgressBarColumn'\"\n                                             [cellValue]=\"element[column.key]\"\n                                             [columnConfig]=\"column.value\">\n                </bd-progress-bar-column-cell>\n\n                <bd-text-column-cell *ngSwitchCase=\"'TextColumn'\"\n                                     [cellValue]=\"element[column.key]\"\n                                     [columnConfig]=\"column.value\">\n                </bd-text-column-cell>\n\n              </ng-container>\n            </ng-template>\n          </td>\n        </ng-container>\n      </ng-container>\n\n      <!-- EXPANDED ELEMENT COLUMN -->\n      <ng-container *ngIf=\"hasExpandedRow\"\n                    [matColumnDef]=\"reservedNames.expandedColumn\">\n        <td *matCellDef=\"let element; let index = dataIndex\"\n            [colSpan]=\"displayedColumns.length\"\n            class=\"expanded-element-row-cell\"\n            mat-cell>\n          <div [@detailExpand]=\"element == expandedElement ? 'expanded' : 'collapsed'\"\n               class=\"expanded-element-row-cell-element-detail\">\n            <div *ngIf=\"element == expandedElement\"\n                 class=\"expanded-element-row-cell-element-content\">\n              <ng-template\n                      *ngComponentOutlet=\"expandedComponentRef; injector: expandedComponentInjectors[index]\"></ng-template>\n            </div>\n          </div>\n        </td>\n      </ng-container>\n\n      <!-- ACTIONS COLUMN -->\n      <ng-container *ngIf=\"actionsConfigService.hasSingleActions\"\n                    [matColumnDef]=\"reservedNames.actionsColumn\"\n                    stickyEnd>\n        <th *matHeaderCellDef\n            class=\"actions-row-header-cell\"\n            mat-header-cell></th>\n\n        <td (shortPress)=\"$event.stopPropagation()\"\n            bdClicker\n            *matCellDef=\"let element\"\n            class=\"actions-row-cell\"\n            mat-cell>\n          <button #singleActionsMenuTrigger=\"matMenuTrigger\"\n                  *ngIf=\"element['singleActions'].length\"\n                  [attr.data-e2e]=\"'single-action-button'\"\n                  [class.menu-opened]=\"singleActionsMenuTrigger.menuOpen\"\n                  [matMenuTriggerData]=\"{element: element}\"\n                  [matMenuTriggerFor]=\"singleActionsMenu\"\n                  class=\"single-actions-button\"\n                  mat-icon-button>\n            <i [class]=\"config.globalIcons.actions\"></i>\n          </button>\n        </td>\n      </ng-container>\n\n      <!-- FINAL THINGS -->\n      <tr *matHeaderRowDef=\"displayedColumns\"\n          class=\"data-header-row\"\n          mat-header-row></tr>\n\n      <tr (shortPress)=\"onRowClicked(element);$event.stopPropagation()\"\n          bdClicker\n          *matRowDef=\"let element; let index = dataIndex; columns: displayedColumns;\"\n          [class.clickable]=\"hasCursorPointer\"\n          [class.selected]=\"bulkSelection.isSelected(element)\"\n          class=\"data-row\"\n          mat-row></tr>\n\n      <ng-container *ngIf=\"hasExpandedRow\">\n        <tr *matRowDef=\"let element; columns: [reservedNames.expandedColumn]\"\n            [class.active]=\"element === expandedElement\"\n            class=\"expanded-element-row\"\n            mat-row></tr>\n      </ng-container>\n\n    </table>\n  </div>\n  <div\n          [hidden]=\"showTableMode !== ShowTableMode.SHOW_TABLE_DATA\">\n    <mat-paginator></mat-paginator>\n  </div>\n</div>\n\n<mat-menu #singleActionsMenu=\"matMenu\">\n  <ng-template matMenuContent let-element=\"element\">\n    <ng-container *ngFor=\"let singleAction of element['singleActions']\">\n      <button (click)=\"emitActionRequest(singleAction, element['originalIndex'])\"\n              [attr.data-e2e]=\"singleAction\"\n              mat-menu-item>\n        <ng-container [ngSwitch]=\"true\">\n          <ng-container *ngSwitchCase=\"actionsConfigService.actions[singleAction].custom && !config.actionIcons[singleAction]\">\n            <i [class]=\"actionsConfigService.actions[singleAction].custom.iconClass\"></i>\n            <span class=\"action-label\">{{actionsConfigService.actions[singleAction].custom.label | translate}}</span>\n          </ng-container>\n          <ng-container *ngSwitchCase=\"config.actionIcons[singleAction] && !actionsConfigService.actions[singleAction].custom\">\n            <i [class]=\"config.actionIcons[singleAction].iconClass\"></i>\n            <span class=\"action-label\">{{config.actionIcons[singleAction].label | translate}}</span>\n          </ng-container>\n        </ng-container>\n      </button>\n    </ng-container>\n  </ng-template>\n</mat-menu>\n\n<mat-menu #bulkActionsMenu>\n  <ng-template matMenuContent>\n    <ng-container *ngFor=\"let bulkAction of actionsConfigService.bulkActions; let index = index\">\n      <ng-container *ngIf=\"index > 2\">\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"actionsConfigService.actions[bulkAction].custom && !config.actionIcons[bulkAction]\"\n                [attr.data-e2e]=\"bulkAction\"\n                [matTooltip]=\"actionsConfigService.actions[bulkAction].custom.label | translate\"\n                mat-menu-item>\n          <!--          <i [class]=\"_actions[bulkAction].custom.iconClass\"></i>-->\n          <span class=\"action-label\">{{actionsConfigService.actions[bulkAction].custom.label | translate}}</span>\n        </button>\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"config.actionIcons[bulkAction] && !actionsConfigService.actions[bulkAction].custom\"\n                [attr.data-e2e]=\"bulkAction\"\n                [matTooltip]=\"config.actionIcons[bulkAction].label\"\n                mat-menu-item>\n          <!--          <i [class]=\"config.actionIcons[bulkAction].iconClass\"></i>-->\n          <span class=\"action-label\">{{config.actionIcons[bulkAction].label | translate}}</span>\n        </button>\n      </ng-container>\n    </ng-container>\n  </ng-template>\n</mat-menu>\n",
                animations: [
                    EXPANDED_ROW_ANIMATION,
                ],
                providers: [
                    ActionsConfigService,
                    { provide: MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: ɵ0$1 },
                    { provide: TABLE, useExisting: LazyTableComponent },
                ],
                host: {
                    '[class.bd-lazy-table]': 'true',
                },
                changeDetection: ChangeDetectionStrategy.OnPush,
                styles: ["@-webkit-keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}.fade-in{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:both;animation-fill-mode:both;-webkit-animation-name:fadeIn;animation-name:fadeIn}:host(.bd-lazy-table),:host(.bd-table){display:block;min-width:100%;padding:0}:host(.bd-lazy-table) .table-header,:host(.bd-table) .table-header{height:40px;margin-bottom:10px}:host(.bd-lazy-table) .table-header .title-wrapper,:host(.bd-table) .table-header .title-wrapper{height:100%;flex-grow:2}:host(.bd-lazy-table) .table-header .title-wrapper .title-text,:host(.bd-table) .table-header .title-wrapper .title-text{color:rgba(0,0,0,.87)}:host(.bd-lazy-table) .table-header .filtered-by-text,:host(.bd-lazy-table) .table-header .selected-from-text,:host(.bd-table) .table-header .filtered-by-text,:host(.bd-table) .table-header .selected-from-text{color:rgba(0,0,0,.54);margin-left:20px;font-weight:500}:host(.bd-lazy-table) .table-header .system-button,:host(.bd-table) .table-header .system-button{margin:0 5px;min-width:40px}:host(.bd-lazy-table) .table-header .system-button:last-of-type,:host(.bd-table) .table-header .system-button:last-of-type{margin-right:0}:host(.bd-lazy-table) .table-header .system-button.mat-stroked-button,:host(.bd-table) .table-header .system-button.mat-stroked-button{background-color:#fff}:host(.bd-lazy-table) .table-header .bulk-action-button,:host(.bd-table) .table-header .bulk-action-button{font-size:20px;color:rgba(0,0,0,.54)}:host(.bd-lazy-table) .table-header .filtered-by-text,:host(.bd-table) .table-header .filtered-by-text{margin-right:10px}:host(.bd-lazy-table) .table-header mat-chip-list,:host(.bd-table) .table-header mat-chip-list{display:inline-block}:host(.bd-lazy-table) .table-header mat-chip-list .mat-chip-remove,:host(.bd-table) .table-header mat-chip-list .mat-chip-remove{line-height:normal}:host(.bd-lazy-table) .table-header .text-search-container,:host(.bd-table) .table-header .text-search-container{margin-right:16px}:host(.bd-lazy-table) .table-header ::ng-deep .text-search-container .mat-form-field-wrapper,:host(.bd-table) .table-header ::ng-deep .text-search-container .mat-form-field-wrapper{position:relative;bottom:-6px}:host(.bd-lazy-table) .table-wrapper,:host(.bd-table) .table-wrapper{overflow:auto}:host(.bd-lazy-table) .table-wrapper .mat-table,:host(.bd-table) .table-wrapper .mat-table{overflow-x:scroll;min-width:100%;border-collapse:inherit}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell{font-weight:500;font-size:13px;color:#000;padding:0 10px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell ::ng-deep .mat-sort-header-button,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell ::ng-deep .mat-sort-header-button{text-align:left}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell,:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.expand-arrow-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.expand-arrow-row-header-cell{width:40px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell{text-align:center}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.progress-bar-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.progress-bar-row-header-cell{min-width:100px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.avatar-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.avatar-row-header-cell{width:40px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell:not(.avatar-row-header-cell),:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell:not(.avatar-row-header-cell){min-width:150px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.actions-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.actions-row-header-cell{text-align:right}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row,:host(.bd-table) .table-wrapper .mat-table .mat-row{transition:background-color .25s}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.data-row.clickable,:host(.bd-table) .table-wrapper .mat-table .mat-row.data-row.clickable{cursor:pointer}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.data-row.selected,:host(.bd-table) .table-wrapper .mat-table .mat-row.data-row.selected{background-color:#f6f6f6}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.expanded-element-row,:host(.bd-table) .table-wrapper .mat-table .mat-row.expanded-element-row{height:0}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.expanded-element-row.active+.data-row .mat-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row.expanded-element-row.active+.data-row .mat-cell{border-top:1px solid #e0e0e0}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row:hover,:host(.bd-table) .table-wrapper .mat-table .mat-row:hover{background-color:#f6f6f6}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.expand-arrow-row-cell .expand.expand-open,:host(.bd-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.expand-arrow-row-cell .expand.expand-open{opacity:1;color:rgba(0,0,0,.87)}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.actions-row-cell .single-actions-button,:host(.bd-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.actions-row-cell .single-actions-button{visibility:visible!important;transition:visibility .25s}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell{color:rgba(0,0,0,.87);font-size:13px;padding:0 10px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.bulk-checkbox-row-cell,:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.bulk-checkbox-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell{text-align:center}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand{display:inline-block;cursor:pointer;transition:all .25s}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-open,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-open{color:rgba(0,0,0,.54)}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-close,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-close{transform:rotate(180deg);color:rgba(0,0,0,.87)}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell{border-bottom-width:0!important}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail{overflow:hidden;display:flex}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail .expanded-element-row-cell-element-content,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail .expanded-element-row-cell-element-content{padding:10px;width:100%}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell{text-align:right}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell .single-actions-button:not(.menu-opened),:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell .single-actions-button:not(.menu-opened){visibility:hidden}.action-label{margin-left:10px}.filter-label{margin-left:5px}", ".gradient-strawberry{background-image:linear-gradient(45deg,#fe0b46,#ffab96)}.gradient-orange{background-image:linear-gradient(45deg,#c471f3,#f671cd)}.gradient-dawn{background-image:linear-gradient(45deg,#f3904f,#3b4371)}.gradient-shdow-night{background-image:linear-gradient(45deg,#000,#53346d)}.gradient-man-of-steel{background-image:linear-gradient(45deg,#780206,#061161)}.gradient-flickr{background-image:linear-gradient(45deg,#33001b,#ff0084)}.gradient-ibiza-sunset{background-image:linear-gradient(45deg,#ee0979,#ff6a00)}.gradient-politics{background-image:linear-gradient(45deg,#2196f3,#f44336)}", ""]
            },] }
];
LazyTableComponent.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [TABLE_CONFIG,] }] },
    { type: TableService },
    { type: ActionsConfigService },
    { type: Injector },
    { type: MatDialog },
    { type: ChangeDetectorRef }
];
LazyTableComponent.propDecorators = {
    actions: [{ type: Input }],
    additionalFiltersDialogData: [{ type: Input }],
    bdTableId: [{ type: Input }],
    storedSettingsConfig: [{ type: Input }],
    columns: [{ type: Input }],
    customColumnTemplateRefs: [{ type: Input }],
    expandedComponentRef: [{ type: Input }],
    filtersDialogConfig: [{ type: Input }],
    filtersDialogRef: [{ type: Input }],
    filtersValue: [{ type: Input }],
    globalSort: [{ type: Input }],
    openFilterOnInit: [{ type: Input }],
    paginatedData: [{ type: Input }],
    pagination: [{ type: Input }],
    rowClickAction: [{ type: Input }],
    sort: [{ type: Input }],
    textSearchEnabled: [{ type: Input }],
    textSearchPlaceholder: [{ type: Input }],
    title: [{ type: Input }],
    translatePrefix: [{ type: Input }],
    actionRequest: [{ type: Output }],
    bulkActionRequest: [{ type: Output }],
    displayedColumnsUpdate: [{ type: Output }],
    filterRemove: [{ type: Output }],
    paginationRequest: [{ type: Output }],
    massBulkCheckbox: [{ type: ViewChild, args: ['massBulkCheckbox',] }],
    matPaginator: [{ type: ViewChild, args: [MatPaginator,] }],
    matSort: [{ type: ViewChild, args: [MatSort,] }],
    initStatePlaceholder: [{ type: ContentChild, args: [TableInitStatePlaceholderDirective,] }],
    noResultPlaceholder: [{ type: ContentChild, args: [TableNoResultPlaceholderDirective,] }],
    tableHeader: [{ type: ContentChild, args: [TableHeaderDirective,] }]
};

// TODO cover with tests
class ToIconPipe {
    transform(value, icons) {
        if (value === null || undefined) {
            return null;
        }
        const res = icons.find(icon => isEqual(icon.case, value)) || icons.find(icon => icon.case === '__default__');
        return res ? res.icon : null;
    }
}
ToIconPipe.decorators = [
    { type: Pipe, args: [{
                name: 'toIcon'
            },] }
];

class ToIconModule {
}
ToIconModule.decorators = [
    { type: NgModule, args: [{
                declarations: [ToIconPipe],
                exports: [ToIconPipe]
            },] }
];

class ToLabelPipe {
    transform(value, icons) {
        if (value === null || undefined) {
            return null;
        }
        const res = icons.find(icon => isEqual(icon.case, value));
        return res ? res.label : null;
    }
}
ToLabelPipe.decorators = [
    { type: Pipe, args: [{
                name: 'toLabel'
            },] }
];

class ToLabelModule {
}
ToLabelModule.decorators = [
    { type: NgModule, args: [{
                declarations: [ToLabelPipe],
                exports: [
                    ToLabelPipe
                ],
                imports: [
                    CommonModule
                ]
            },] }
];

class BdPaginatorIntl extends MatPaginatorIntl {
    constructor(translate) {
        super();
        this.translate = translate;
        this.getAndInitTranslations();
    }
    getAndInitTranslations() {
        this.translate.get(['rows-per-page', 'next-page', 'previous-page']).pipe(take(1)).subscribe(res => {
            this.itemsPerPageLabel = res['rows-per-page'] + ':';
            this.nextPageLabel = res['next-page'];
            this.previousPageLabel = res['previous-page'];
            this.changes.next();
        });
    }
}
BdPaginatorIntl.ɵprov = ɵɵdefineInjectable({ factory: function BdPaginatorIntl_Factory() { return new BdPaginatorIntl(ɵɵinject(TranslateService)); }, token: BdPaginatorIntl, providedIn: "root" });
BdPaginatorIntl.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
BdPaginatorIntl.ctorParameters = () => [
    { type: TranslateService }
];

class TextColumnCellComponent {
    constructor(config) {
        this.config = config;
    }
}
TextColumnCellComponent.decorators = [
    { type: Component, args: [{
                selector: 'bd-text-column-cell',
                template: "<div>{{cellValue.main | nullOrUndefinedHandler:config.nullOrUndefinedPipePlaceholder }}</div>\n<div *ngIf=\"columnConfig.subPath\"\n     class=\"text-column-sub-text\">\n  {{cellValue.sub | nullOrUndefinedHandler:config.nullOrUndefinedPipePlaceholder }}\n</div>\n",
                styles: [".text-column-sub-text{font-size:11px;color:rgba(0,0,0,.54)}"]
            },] }
];
TextColumnCellComponent.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [TABLE_CONFIG,] }] }
];
TextColumnCellComponent.propDecorators = {
    cellValue: [{ type: Input }],
    columnConfig: [{ type: Input }]
};

class AvatarColumnCellComponent {
    constructor(config) {
        this.config = config;
    }
}
AvatarColumnCellComponent.decorators = [
    { type: Component, args: [{
                selector: 'bd-avatar-column-cell',
                template: "<span bdRandomClass class='avatar-wrapper'>\n  <span>{{cellValue | firstLetter | nullOrUndefinedHandler:{placeholder: '?'} }}</span>\n</span>\n",
                styles: [".avatar-wrapper{width:40px;height:40px;border-radius:50%;display:table-cell!important;vertical-align:middle;text-align:center}.avatar-wrapper span{font-weight:600;color:#e1e1e1;text-align:center}"]
            },] }
];
AvatarColumnCellComponent.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [TABLE_CONFIG,] }] }
];
AvatarColumnCellComponent.propDecorators = {
    cellValue: [{ type: Input }],
    columnConfig: [{ type: Input }]
};

class DateColumnCellComponent {
    constructor(config) {
        this.config = config;
    }
}
DateColumnCellComponent.decorators = [
    { type: Component, args: [{
                selector: 'bd-date-column-cell',
                template: "<ng-container *ngIf=\"columnConfig.timeAgo; else notTimeAgo\">\n  {{cellValue | timeAgo | nullOrUndefinedHandler:config.nullOrUndefinedPipePlaceholder }}\n</ng-container>\n<ng-template #notTimeAgo>\n  {{cellValue | bdDate:columnConfig.format | nullOrUndefinedHandler:config.nullOrUndefinedPipePlaceholder }}\n</ng-template>\n",
                styles: [""]
            },] }
];
DateColumnCellComponent.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [TABLE_CONFIG,] }] }
];
DateColumnCellComponent.propDecorators = {
    columnConfig: [{ type: Input }],
    cellValue: [{ type: Input }]
};

class IconColumnCellComponent {
    constructor(config) {
        this.config = config;
        this.actionRequest = new EventEmitter();
    }
}
IconColumnCellComponent.decorators = [
    { type: Component, args: [{
                selector: 'bd-icon-column-cell',
                template: "<i (shortPress)=\"columnConfig.action && actionRequest.emit(columnConfig.action)\"\n   [class.icon-offset]=\"columnConfig.withLabel\"\n   [class]=\"cellValue | toIcon:columnConfig.icons\"\n   bdClicker></i>\n<ng-container *ngIf=\"columnConfig.withLabel\">\n  {{cellValue | toLabel:columnConfig.icons | nullOrUndefinedHandler:config.nullOrUndefinedPipePlaceholder}}\n</ng-container>\n",
                styles: [".icon-offset{margin-right:5px}"]
            },] }
];
IconColumnCellComponent.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [TABLE_CONFIG,] }] }
];
IconColumnCellComponent.propDecorators = {
    cellValue: [{ type: Input }],
    columnConfig: [{ type: Input }],
    actionRequest: [{ type: Output }]
};

class ProgressBarColumnCellComponent {
    constructor(config) {
        this.config = config;
    }
}
ProgressBarColumnCellComponent.decorators = [
    { type: Component, args: [{
                selector: 'bd-progress-bar-column-cell',
                template: "<mat-progress-bar *ngIf=\"cellValue.actual && cellValue.max; else noProgressBarDataTmpl\"\n                  [class]=\"cellValue.klass\"\n                  [value]=\"cellValue.ratio\"\n                  mode=\"determinate\"></mat-progress-bar>\n\n<ng-template #noProgressBarDataTmpl>\n  {{config.nullOrUndefinedPipePlaceholder}}\n</ng-template>\n",
                styles: [""]
            },] }
];
ProgressBarColumnCellComponent.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [TABLE_CONFIG,] }] }
];
ProgressBarColumnCellComponent.propDecorators = {
    cellValue: [{ type: Input }],
    columnConfig: [{ type: Input }]
};

class ActiveFiltersModule {
}
ActiveFiltersModule.decorators = [
    { type: NgModule, args: [{
                declarations: [ActiveFiltersPipe],
                imports: [
                    CommonModule
                ],
                exports: [ActiveFiltersPipe]
            },] }
];

class TableHeaderModule {
}
TableHeaderModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    TableHeaderDirective,
                    TableInitStatePlaceholderDirective,
                    TableNoResultPlaceholderDirective,
                ],
                imports: [
                    CommonModule,
                ],
                exports: [
                    TableHeaderDirective,
                    TableInitStatePlaceholderDirective,
                    TableNoResultPlaceholderDirective,
                ],
            },] }
];

class TableModule {
    static forRoot(moduleConfig) {
        return {
            ngModule: TableModule,
            providers: [
                TableService,
                ActiveFiltersPipe,
                { provide: TABLE_CONFIG, useValue: moduleConfig },
                { provide: MatPaginatorIntl, useClass: BdPaginatorIntl }
            ]
        };
    }
}
TableModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    TableComponent,
                    LazyTableComponent,
                    DefaultFiltersDialogComponent,
                    DisplayedColumnsDialogComponent,
                    TextColumnCellComponent,
                    AvatarColumnCellComponent,
                    DateColumnCellComponent,
                    IconColumnCellComponent,
                    ProgressBarColumnCellComponent,
                ],
                entryComponents: [
                    DefaultFiltersDialogComponent,
                    DisplayedColumnsDialogComponent
                ],
                imports: [
                    CommonModule,
                    FormsModule,
                    DragDropModule,
                    FlexLayoutModule,
                    MatTooltipModule,
                    MatFormFieldModule,
                    MatInputModule,
                    MatTableModule,
                    MatSortModule,
                    MatPaginatorModule,
                    MatButtonModule,
                    MatMenuModule,
                    MatIconModule,
                    MatCheckboxModule,
                    MatProgressBarModule,
                    MatDialogModule,
                    MatCardModule,
                    TranslateModule,
                    TimeAgoPipeModule,
                    RandomGradientPipeModule,
                    NullOrUndefinedHandlerPipeModule,
                    SliceWithDotsPipeModule,
                    ToIconModule,
                    BdDatePipeModule,
                    OrderedKeyValuePipeModule,
                    FirstLetterPipeModule,
                    RandomClassDirectiveModule,
                    DynamicFormModule,
                    MatChipsModule,
                    ToLabelModule,
                    ClickerDirectiveModule,
                    DomElementValidatorDirectiveModule,
                    TableHeaderModule,
                    ReactiveFormsModule,
                    ActiveFiltersModule,
                ],
                exports: [
                    TableComponent,
                    LazyTableComponent
                ]
            },] }
];

/*
 * Public API Surface of dynamic-tables
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AvatarColumn, DateColumn, EXPANDED_ROW_DATA, FiltersDialogComponent, IconColumn, LazyTableComponent, MatDynamicTableComponent, MatDynamicTableModule, ReservedNamesEnum, ReservedNamesV2, TABLE, TABLE_CONFIG, TableComponent, TableModule, TextColumn, UuidColumn, instanceOfAvatarColumnInterface, instanceOfDateColumnInterface, instanceOfIconColumnInterface, instanceOfProgressBarColumnInterface, instanceOfTextColumnInterface, ɵ0, BaseColumn as ɵa, DYNAMIC_TABLE_MODULE_CONFIG as ɵb, TableHeaderModule as ɵba, ActiveFiltersModule as ɵbb, BdPaginatorIntl as ɵbc, MatDynamicTableService as ɵc, ActionMicroPipesModule as ɵd, SimpleOrConditionalActionPipe as ɵe, CheckActionConditionPipe as ɵf, EXPANDED_ROW_ANIMATION as ɵg, TableHeaderDirective as ɵh, TableService as ɵi, ActionsConfigService as ɵj, ActiveFiltersPipe as ɵk, TableInitStatePlaceholderDirective as ɵl, TableNoResultPlaceholderDirective as ɵm, DefaultFiltersDialogComponent as ɵn, DisplayedColumnsDialogComponent as ɵp, TextColumnCellComponent as ɵr, AvatarColumnCellComponent as ɵs, DateColumnCellComponent as ɵt, IconColumnCellComponent as ɵu, ProgressBarColumnCellComponent as ɵv, ToIconModule as ɵw, ToIconPipe as ɵx, ToLabelModule as ɵy, ToLabelPipe as ɵz };
//# sourceMappingURL=bd-innovations-dynamic-tables.js.map
