(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('lodash'), require('@angular/core'), require('@angular/common'), require('@angular/animations'), require('@angular/forms'), require('rxjs'), require('rxjs/operators'), require('rxjs/internal/observable/combineLatest'), require('@angular/material/table'), require('@angular/material/paginator'), require('@angular/material/sort'), require('@ngx-translate/core'), require('@bd-innovations/pipe-collection'), require('@bd-innovations/directive-collection'), require('@angular/flex-layout'), require('@angular/material/tooltip'), require('@angular/material/form-field'), require('@angular/material/input'), require('@angular/material/button'), require('@angular/material/menu'), require('@angular/material/icon'), require('@angular/material/checkbox'), require('@angular/cdk/collections'), require('@angular/material/dialog'), require('@bd-innovations/dynamic-form'), require('@angular/cdk/drag-drop'), require('@angular/material/progress-bar'), require('@angular/material/card'), require('@angular/material/chips')) :
    typeof define === 'function' && define.amd ? define('@bd-innovations/dynamic-tables', ['exports', 'lodash', '@angular/core', '@angular/common', '@angular/animations', '@angular/forms', 'rxjs', 'rxjs/operators', 'rxjs/internal/observable/combineLatest', '@angular/material/table', '@angular/material/paginator', '@angular/material/sort', '@ngx-translate/core', '@bd-innovations/pipe-collection', '@bd-innovations/directive-collection', '@angular/flex-layout', '@angular/material/tooltip', '@angular/material/form-field', '@angular/material/input', '@angular/material/button', '@angular/material/menu', '@angular/material/icon', '@angular/material/checkbox', '@angular/cdk/collections', '@angular/material/dialog', '@bd-innovations/dynamic-form', '@angular/cdk/drag-drop', '@angular/material/progress-bar', '@angular/material/card', '@angular/material/chips'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory((global['bd-innovations'] = global['bd-innovations'] || {}, global['bd-innovations']['dynamic-tables'] = {}), global._, global.ng.core, global.ng.common, global.ng.animations, global.ng.forms, global.rxjs, global.rxjs.operators, global.rxjs['internal/observable/combineLatest'], global.ng.material.table, global.ng.material.paginator, global.ng.material.sort, global['ngx-translate-core'], global['pipe-collection'], global['directive-collection'], global.ng.flexLayout, global.ng.material.tooltip, global.ng.material.formField, global.ng.material.input, global.ng.material.button, global.ng.material.menu, global.ng.material.icon, global.ng.material.checkbox, global.ng.cdk.collections, global.ng.material.dialog, global['dynamic-form'], global.ng.cdk.dragDrop, global.ng.material.progressBar, global.ng.material.card, global.ng.material.chips));
}(this, (function (exports, _, i0, common, animations, forms, rxjs, operators, combineLatest, table, paginator, sort, i1, pipeCollection, i1$1, flexLayout, tooltip, formField, input, button, menu, icon, checkbox, collections, dialog, dynamicForm, dragDrop, progressBar, card, chips) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (b.hasOwnProperty(p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    var __assign = function () {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s)
                    if (Object.prototype.hasOwnProperty.call(s, p))
                        t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    function __rest(s, e) {
        var t = {};
        for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
                t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }
    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
            r = Reflect.decorate(decorators, target, key, desc);
        else
            for (var i = decorators.length - 1; i >= 0; i--)
                if (d = decorators[i])
                    r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }
    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); };
    }
    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
            return Reflect.metadata(metadataKey, metadataValue);
    }
    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try {
                step(generator.next(value));
            }
            catch (e) {
                reject(e);
            } }
            function rejected(value) { try {
                step(generator["throw"](value));
            }
            catch (e) {
                reject(e);
            } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }
    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function () { if (t[0] & 1)
                throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f)
                throw new TypeError("Generator is already executing.");
            while (_)
                try {
                    if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                        return t;
                    if (y = 0, t)
                        op = [op[0] & 2, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return { value: op[1], done: false };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2])
                                _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                }
                catch (e) {
                    op = [6, e];
                    y = 0;
                }
                finally {
                    f = t = 0;
                }
            if (op[0] & 5)
                throw op[1];
            return { value: op[0] ? op[1] : void 0, done: true };
        }
    }
    var __createBinding = Object.create ? (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        Object.defineProperty(o, k2, { enumerable: true, get: function () { return m[k]; } });
    }) : (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        o[k2] = m[k];
    });
    function __exportStar(m, exports) {
        for (var p in m)
            if (p !== "default" && !exports.hasOwnProperty(p))
                __createBinding(exports, m, p);
    }
    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m)
            return m.call(o);
        if (o && typeof o.length === "number")
            return {
                next: function () {
                    if (o && i >= o.length)
                        o = void 0;
                    return { value: o && o[i++], done: !o };
                }
            };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }
    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++)
            s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }
    ;
    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }
    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n])
            i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try {
            step(g[n](v));
        }
        catch (e) {
            settle(q[0][3], e);
        } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length)
            resume(q[0][0], q[0][1]); }
    }
    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }
    function __asyncValues(o) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
    }
    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) {
            Object.defineProperty(cooked, "raw", { value: raw });
        }
        else {
            cooked.raw = raw;
        }
        return cooked;
    }
    ;
    var __setModuleDefault = Object.create ? (function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function (o, v) {
        o["default"] = v;
    };
    function __importStar(mod) {
        if (mod && mod.__esModule)
            return mod;
        var result = {};
        if (mod != null)
            for (var k in mod)
                if (Object.hasOwnProperty.call(mod, k))
                    __createBinding(result, mod, k);
        __setModuleDefault(result, mod);
        return result;
    }
    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }
    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }
    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    var BaseColumn = /** @class */ (function () {
        /**
         * @param paths declare property/ies of object to display (using the same syntax of "_.at" method)
         * @param mask declare some mask to use for displayed data
         * @param config ''
         */
        function BaseColumn(paths, 
        // public mask?: (element: any) => any,
        config) {
            if (config === void 0) { config = { sortable: false }; }
            this.paths = paths;
            this.config = config;
            // if (config && config.sortable) {
            //   console.log(123)
            // } else {
            //   console.log(456)
            // }
        }
        BaseColumn.prototype.get = function (element) {
            return _.at(element, this.paths);
        };
        return BaseColumn;
    }());

    var DateColumn = /** @class */ (function (_super) {
        __extends(DateColumn, _super);
        // /**
        //  * @param path see BaseColumnInterface.paths
        //  * @param format define format in which to show date (by default equal to 'yyyy/MM/dd'
        //  */
        // constructor(path: string, format?: string);
        // /**
        //  * @param path see BaseColumnInterface.paths
        //  * @param timeAgo set to true when you need to show date in style of "5 minutes ago" (by default equal to false)
        //  */
        // constructor(path: string, timeAgo: boolean);
        function DateColumn(path, config) {
            var _this = _super.call(this, path) || this;
            _this.path = path;
            _this._columnType = 'DateColumn';
            var defaultFormat = 'yyyy/MM/dd';
            var defaultTimeAgo = false;
            _this.format = config && config.format || defaultFormat;
            _this.timeAgo = config && config.timeAgo || defaultTimeAgo;
            return _this;
        }
        DateColumn.prototype.get = function (element) {
            var res = _super.prototype.get.call(this, element);
            if (res === null || undefined) {
                return null;
            }
            return res[0];
        };
        return DateColumn;
    }(BaseColumn));

    var IconColumn = /** @class */ (function (_super) {
        __extends(IconColumn, _super);
        // /**
        //  * @param path see BaseColumnInterface.paths
        // * @param icons specify an array of icons from where to take icons based on value of object property
        // * @param config ''
        // */
        function IconColumn(path, config) {
            var _this = _super.call(this, path) || this;
            _this.path = path;
            _this._columnType = 'IconColumn';
            _this.icons = config.icons;
            _this.action = config.action;
            return _this;
        }
        IconColumn.prototype.get = function (element) {
            var res = _super.prototype.get.call(this, element);
            if (res === null || undefined) {
                return null;
            }
            return res[0];
        };
        return IconColumn;
    }(BaseColumn));

    var TextColumn = /** @class */ (function (_super) {
        __extends(TextColumn, _super);
        function TextColumn(paths, config) {
            var _this = _super.call(this, paths, config) || this;
            _this._columnType = 'TextColumn';
            var defaultLimit = 30;
            var defaultTranslate = '';
            var defaultSeparator = ' ';
            _this.limit = config && config.limit || defaultLimit;
            _this.translate = config && config.translate || defaultTranslate;
            _this.separator = config && config.separator || defaultSeparator;
            _this.mask = config && config.mask || undefined;
            return _this;
        }
        TextColumn.prototype.get = function (element) {
            var _this = this;
            var res = _super.prototype.get.call(this, element);
            res = !!this.mask ? res.map(function (elem) { return _this.mask(elem); }) : res;
            if (res === null || res === undefined) {
                return null;
            }
            if (res instanceof Array) {
                var checkRes_1 = false;
                res.forEach(function (resElem, index) {
                    if (resElem !== null && resElem !== undefined) {
                        checkRes_1 = true;
                    }
                    else {
                        res[index] = '';
                    }
                });
                if (!checkRes_1) {
                    return null;
                }
            }
            return res && (res
                .map(function (elem, index) { return (_this.separator instanceof Array ? _this.separator[index] : '') + _this.translate + elem; })
                .join(this.separator instanceof Array ? '' : this.separator));
        };
        return TextColumn;
    }(BaseColumn));

    // TODO add primaryKey property
    var UuidColumn = /** @class */ (function (_super) {
        __extends(UuidColumn, _super);
        function UuidColumn(uuId, config) {
            var _this = _super.call(this, uuId, { limit: config.limit }) || this;
            _this._columnType = 'TextColumn';
            _this.array = config.array;
            _this.pathInArray = config.pathInArray;
            _this.primaryKeyInArray = config.primaryKeyInArray;
            return _this;
        }
        UuidColumn.prototype.get = function (element) {
            var _this = this;
            var res = _super.prototype.get.call(this, element);
            if (!res) {
                return null;
            }
            var externalRes = _.at(this.array.find(function (elem) { return elem[_this.primaryKeyInArray].toString() === res.toString(); }), this.pathInArray);
            if (!externalRes) {
                return null;
            }
            return externalRes.join(' ');
        };
        return UuidColumn;
    }(TextColumn));

    var AvatarColumn = /** @class */ (function (_super) {
        __extends(AvatarColumn, _super);
        function AvatarColumn(paths) {
            var _this = _super.call(this, paths) || this;
            _this._columnType = 'AvatarColumn';
            return _this;
        }
        AvatarColumn.prototype.get = function (element) {
            var res = _super.prototype.get.call(this, element);
            if (res === null || undefined) {
                return null;
            }
            return res[0];
        };
        return AvatarColumn;
    }(BaseColumn));

    (function (ReservedNamesEnum) {
        ReservedNamesEnum["searchRow"] = "bdReservedNameForSearchRow";
        ReservedNamesEnum["expandedRow"] = "bdReservedNameForExpandedRow";
        // expandColumn = 'bdReservedNameForExpandColumn',
        ReservedNamesEnum["actionsColumn"] = "bdReservedNameForActionsColumn";
        // checkboxColumn = 'bdReservedNameForCheckboxColumn',
        ReservedNamesEnum["serviceColumn"] = "bdReservedNameForServiceColumn";
    })(exports.ReservedNamesEnum || (exports.ReservedNamesEnum = {}));

    var DYNAMIC_TABLE_MODULE_CONFIG = new i0.InjectionToken('DYNAMIC_TABLE_MODULE_CONFIG');
    var MatDynamicTableService = /** @class */ (function () {
        function MatDynamicTableService(config) {
            this.config = config;
        }
        MatDynamicTableService.prototype.getParsedData = function (data, columns) {
            var resArray = [];
            if (data) {
                data.forEach(function (element, index) {
                    var resElement = {
                        originalIndex: index,
                        selected: false
                    };
                    var keys = Object.keys(columns);
                    keys.forEach(function (key) {
                        resElement[key] = columns[key].get(element);
                    });
                    resArray.push(resElement);
                });
            }
            return resArray;
        };
        return MatDynamicTableService;
    }());
    MatDynamicTableService.decorators = [
        { type: i0.Injectable }
    ];
    MatDynamicTableService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [DYNAMIC_TABLE_MODULE_CONFIG,] }] }
    ]; };

    var MatDynamicTableComponent = /** @class */ (function () {
        function MatDynamicTableComponent(service, cd) {
            this.service = service;
            this.cd = cd;
            this.columns = {};
            this.displayColumns = [];
            this.translatePath = '';
            this.search = true;
            this.paginator = {
                pageIndex: 0,
                pageSize: 25,
            };
            this.actions = [];
            this.roles = {};
            this.reservedColumnNames = exports.ReservedNamesEnum; // Shortcut to access from the template
            this.searchCtrl = new forms.FormControl();
            this.bulkContainer$ = new rxjs.Subject();
            this.dataColumns = [];
            this.actionRequest = new i0.EventEmitter();
            this.apiRequest = new i0.EventEmitter();
            this.bulkContainerUpdate = new i0.EventEmitter();
            this.onDestroy = new rxjs.Subject();
        }
        MatDynamicTableComponent.prototype.ngOnChanges = function () {
            this.initDataSource();
            if (this.matPaginator) {
                this.matPaginator.length = this.paginator.length;
            }
        };
        MatDynamicTableComponent.prototype.ngOnInit = function () {
            this.bulk && this.initBulk();
            this.dataColumns = this.dataColumns.concat(this.displayColumns);
            if (this.expandedRow || this.bulk) {
                this.dataColumns.unshift(exports.ReservedNamesEnum.serviceColumn);
            }
        };
        MatDynamicTableComponent.prototype.ngAfterViewInit = function () {
            this.apiable ? this.initApiableTable() : this.initNotApiableTable();
            this.paginator && this.initPaginator();
            this.cd.detectChanges();
        };
        MatDynamicTableComponent.prototype.ngOnDestroy = function () {
            this.onDestroy.next();
            this.onDestroy.complete();
        };
        MatDynamicTableComponent.prototype.isFirstColumnPadding = function (column_name) {
            return (this.bulk || this.expandedRow) && this.displayColumns.indexOf(column_name) === 0;
        };
        MatDynamicTableComponent.prototype.emitActionRequest = function (actionType, index) {
            var action = {
                type: actionType,
                entity: this.data[index]
            };
            this.actionRequest.emit(action);
        };
        MatDynamicTableComponent.prototype.massSelectionChange = function () {
            var _this = this;
            this.dataSource.data.forEach(function (element) { return element.selected = _this.massBulkCheckbox.checked; });
            this.bulkContainer$.next();
        };
        MatDynamicTableComponent.prototype.onRowClicked = function (element) {
            this.emitActionRequest('open', element.originalIndex);
        };
        MatDynamicTableComponent.prototype.onExpandedClicked = function (element) {
            if (this.expandedRow) {
                this.expandedElement = this.expandedElement === element ? null : element;
            }
        };
        MatDynamicTableComponent.prototype.initDataSource = function () {
            this.dataSource = new table.MatTableDataSource(this.service.getParsedData(this.data, this.columns));
        };
        MatDynamicTableComponent.prototype.initPaginator = function () {
            this.matPaginator.pageIndex = this.paginator.pageIndex;
            this.matPaginator.pageSize = this.paginator.pageSize;
            this.matPaginator.pageSizeOptions = [5, 10, 25, 50];
            if (this.apiable) {
                this.matPaginator.length = this.paginator.length;
            }
        };
        MatDynamicTableComponent.prototype.disableSort = function () {
            this.matSort.disabled = true;
        };
        MatDynamicTableComponent.prototype.initBulk = function () {
            var _this = this;
            this.bulkContainer$
                .pipe(operators.debounceTime(1000), operators.takeUntil(this.onDestroy))
                .subscribe(function (value) {
                _this.bulkContainerUpdate.emit(value ||
                    _this.dataSource.data
                        .filter(function (element) { return element.selected; })
                        .map(function (element) { return _this.data[element.originalIndex]; }));
            });
        };
        MatDynamicTableComponent.prototype.initApiableTable = function () {
            var _this = this;
            var observables = [
                rxjs.fromEvent(this.searchInput.nativeElement, 'keyup')
                    .pipe(operators.filter(function (event) { return event.key === 'Enter'; }), operators.map(function () { return _this.searchCtrl.value; }), operators.distinctUntilChanged(), operators.takeUntil(this.onDestroy), operators.startWith(undefined)),
                this.matPaginator.page
                    .pipe(operators.startWith(undefined)),
                this.matSort.sortChange
                    .pipe(operators.startWith(undefined))
            ];
            combineLatest.combineLatest(observables)
                .pipe(operators.takeUntil(this.onDestroy), operators.filter(function (_a) {
                var _b = __read(_a, 3), search = _b[0], paginator = _b[1], sort = _b[2];
                return !(search === undefined && paginator === undefined && sort === undefined);
            }), operators.map(function (_a) {
                var _b = __read(_a, 3), search = _b[0], paginator = _b[1], sort = _b[2];
                var resPaginator = paginator || _this.paginator;
                var resSort = sort ? Object.assign(Object.assign({}, sort), { direction: sort.direction ? sort.direction.toUpperCase() : null }) : null;
                return { search: search, paginator: resPaginator, sort: resSort };
            }))
                .subscribe(function (apiRequest) {
                if (_this.previousSearch && apiRequest.search !== _this.previousSearch && _this.paginator) {
                    apiRequest.paginator.pageIndex = 0;
                }
                if (_this.bulk) {
                    _this.massBulkCheckbox.checked = false;
                }
                _this.bulkContainer$.next([]);
                _this.previousSearch = apiRequest.search;
                _this.apiRequest.emit(apiRequest);
            });
        };
        MatDynamicTableComponent.prototype.initNotApiableTable = function () {
            var _this = this;
            this.dataSource.sort = this.matSort;
            // WORKAROUND don't simplify it, sometimes without it paginator doesn't init itself
            setTimeout(function () { return _this.dataSource.paginator = _this.matPaginator; });
            rxjs.fromEvent(this.searchInput.nativeElement, 'keyup')
                .pipe(operators.filter(function (event) { return event.key === 'Enter'; }), operators.map(function () { return _this.searchCtrl.value; }), operators.distinctUntilChanged(), operators.takeUntil(this.onDestroy))
                .subscribe(function (value) {
                _this.dataSource.filter = value ? value.trim().toLowerCase() : '';
                if (_this.dataSource.paginator) {
                    _this.dataSource.paginator.firstPage();
                }
            });
        };
        return MatDynamicTableComponent;
    }());
    MatDynamicTableComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'bd-mat-dynamic-table',
                    template: "<div class=\"table-wrapper\">\n  <table [dataSource]=\"dataSource\" mat-table matSort multiTemplateDataRows>\n\n    <!-- SEARCH ROW -->\n    <ng-container [matColumnDef]=\"reservedColumnNames.searchRow\">\n      <th *matHeaderCellDef\n          [colSpan]=\"(dataColumns).length\"\n          class=\"search-row\"\n          mat-header-cell>\n        <div class=\"search-wrapper\" fxLayout=\"row\" fxLayoutAlign=\"space-between center\" fxLayoutGap=\"5px\">\n          <span fxFlex=\"12px\">\n            <span [innerHtml]=\"service.config.searchField.icon\"></span>\n          </span>\n\n          <input [formControl]=\"searchCtrl\"\n                 #searchInput\n                 [placeholder]=\"service.config.searchField.placeholder | translate\"\n                 fxFlex>\n\n          <span fxFlex=\"12px\">\n            <span (click)=\"searchCtrl.reset()\"\n                  *ngIf=\"searchCtrl.value\"\n                  [innerHTML]=\"service.config.searchField.resetIcon\"\n                  class=\"float-right cursor-pointer\"></span>\n          </span>\n        </div>\n      </th>\n    </ng-container>\n\n    <!--SERVICE COLUMNS-->\n    <!--  EXPAND AND CHECKBOX ROW COLUMN  -->\n    <ng-container\n      *ngIf=\"expandedRow || bulk\"\n      [matColumnDef]=\"reservedColumnNames.serviceColumn\"\n      [sticky]=\"true\"\n    >\n      <th\n        *matHeaderCellDef\n        mat-header-cell\n        class=\"service-column-header\"\n        [ngStyle]=\"{'width': bulk && expandedRow ? '15px' : '5px'}\"\n      >\n        <div fxLayout=\"row\" fxLayoutAlign=\"center center\">\n          <i class=\"hidden-icon\" *ngIf=\"expandedRow\"></i>\n          <mat-checkbox #massBulkCheckbox\n                        *ngIf=\"bulk && data.length > 0\"\n                        (bdShortPress)=\"$event.stopPropagation()\"\n                        (change)=\"massSelectionChange()\"\n                        class=\"bulk-checkbox\"\n          ></mat-checkbox>\n        </div>\n      </th>\n\n      <td\n        *matCellDef=\"let element\"\n        mat-cell\n        class=\"service-column-td\"\n        [ngStyle]=\"{'width': bulk && expandedRow ? '15px' : '5px'}\"\n      >\n        <div fxLayout=\"row\" fxLayoutAlign=\"center center\">\n          <span class=\"expand\"\n                *ngIf=\"expandedRow\"\n                (bdShortPress)=\"$event.stopPropagation();onExpandedClicked(element);\"\n                [ngClass]=\"expandedElement && element === expandedElement ? 'bd-expand-open' : 'bd-expand-close'\"\n          >\n            <span [innerHTML]=\"service.config.expandIcon\"></span>\n          </span>\n\n          <span\n            class=\"checkbox\"\n            *ngIf=\"bulk\"\n          >\n          <mat-checkbox (bdShortPress)=\"$event.stopPropagation()\"\n                        (change)=\"bulkContainer$.next()\"\n                        [(ngModel)]=\"element['selected']\">\n          </mat-checkbox>\n        </span>\n        </div>\n\n      </td>\n\n      <!--        [class.service-column-left]=\"expandedRow && !bulk\"-->\n    </ng-container>\n\n    <!-- ACTIONS COLUMN -->\n    <ng-container [matColumnDef]=\"reservedColumnNames.actionsColumn\" stickyEnd>\n      <th *matHeaderCellDef\n          mat-header-cell\n          class=\"actions-column-header\">\n      </th>\n      <td *matCellDef=\"let element\" mat-cell class=\"service-column-right\">\n        <button (bdShortPress)=\"$event.stopPropagation()\" [matMenuTriggerFor]=\"buttonsMenu\"\n                mat-icon-button>\n          <span [outerHTML]=\"service.config.actionsColumn.icon\"></span>\n        </button>\n\n        <mat-menu #buttonsMenu=\"matMenu\">\n          <ng-container *ngFor=\"let action of actions\">\n            <ng-container [ngSwitch]=\"action | simpleOrConditionalAction\">\n              <ng-container *ngSwitchCase=\"'simple'\">\n                <button (click)=\"emitActionRequest(action, element['originalIndex'])\"\n                        *bdDomElementValidator=\"roles ? roles[action] : null\"\n                        mat-menu-item>\n                  <span [outerHTML]=\"service.config.actionsColumn.actions[action].icon\"></span>\n                  <span\n                    style=\"margin-left: 10px\">{{service.config.actionsColumn.actions[action].label | translate}}</span>\n                </button>\n              </ng-container>\n              <ng-container *ngSwitchCase=\"'conditional'\">\n                <button (click)=\"emitActionRequest(action.type, element['originalIndex'])\"\n                        *bdDomElementValidator=\"roles ? roles[action.type] : null\"\n                        [disabled]=\"!(data[element['originalIndex']] | checkActionCondition:action.condition)\"\n                        mat-menu-item>\n                  <span [outerHTML]=\"service.config.actionsColumn.actions[action.type].icon\"></span>\n                  <span\n                    style=\"margin-left: 10px\">{{service.config.actionsColumn.actions[action.type].label | translate}}</span>\n                </button>\n              </ng-container>\n            </ng-container>\n\n          </ng-container>\n        </mat-menu>\n      </td>\n    </ng-container>\n\n    <!-- COLUMNS WITH DATA !== [] -->\n    <ng-container *ngFor=\"let column of columns | orderedKeyValue; let i=index\"\n                  [matColumnDef]=\"column.key\"\n                  [sticky]=\"!bulk && column.value['_columnType'] === 'TextColumn' && column.value['isAvatar']\">\n      <th *matHeaderCellDef\n          [disabled]=\"!column.value['config']['sortable']\"\n          mat-header-cell\n          mat-sort-header\n\n          [ngClass]=\"{\n            'avatar-column-header': column.value['_columnType'],\n            'first-data-row-padding': isFirstColumnPadding(column.key)\n          }\"\n      >\n        <ng-container *ngIf=\"column.value['_columnType'] !== 'AvatarColumn'\">\n          {{translatePath + column.key | translate}}\n        </ng-container>\n      </th>\n\n      <ng-container *ngIf=\"data\">\n        <td *matCellDef=\"let element\"\n            [ngClass]=\"{\n              'avatar-cell': column.value['_columnType'] !== 'AvatarColumn',\n              'first-data-row-padding': isFirstColumnPadding(column.key),\n              'column-text-center': column.value['_columnType'] === 'TextColumn' && !element[column.key]\n            }\"\n\n            mat-cell\n        >\n          <ng-container [ngSwitch]=\"column.value['_columnType']\">\n\n            <!-- Text Column -->\n            <ng-container *ngSwitchCase=\"'TextColumn'\">\n              {{element[column.key] | translate | sliceWithDots:column.value['limit'] | nullOrUndefinedHandler:{placeholder: '-'} }}\n            </ng-container>\n\n            <!-- Avatar Column -->\n            <ng-container *ngSwitchCase=\"'AvatarColumn'\">\n               <span bdRandomClass class='avatar-wrapper'>\n                  <span>{{element[column.key] | firstLetter | nullOrUndefinedHandler:{placeholder: '?'} }}</span>\n               </span>\n            </ng-container>\n\n            <!-- Date Column -->\n            <ng-container *ngSwitchCase=\"'DateColumn'\">\n              <ng-container *ngIf=\"column.value['timeAgo']; else notTimeAgo\">\n                {{element[column.key] | timeAgo | nullOrUndefinedHandler:{placeholder: '-'} }}\n              </ng-container>\n              <ng-template #notTimeAgo>\n                {{element[column.key] | bdDate:column.value['format'] | nullOrUndefinedHandler:{placeholder: '-'} }}\n              </ng-template>\n            </ng-container>\n\n            <!-- Icon Column -->\n            <ng-container *ngSwitchCase=\"'IconColumn'\">\n              <span\n                (bdShortPress)=\"column.value['action'] && emitActionRequest(column.value['action'], element['originalIndex']);$event.stopPropagation()\"\n                [innerHTML]=\"element[column.key] | toIcon:column.value['icons']\"></span>\n            </ng-container>\n          </ng-container>\n        </td>\n      </ng-container>\n    </ng-container>\n\n    <!-- EXPANDED ROW -->\n    <ng-container [matColumnDef]=\"reservedColumnNames.expandedRow\">\n      <td *matCellDef=\"let element; let index = dataIndex\"\n          [colSpan]=\"dataColumns.length\"\n          mat-cell\n          [class.expandedBlock]=\"element === expandedElement\"\n          id=\"{{reservedColumnNames.expandedRow}}\"\n      >\n        <div [@detailExpand]=\"element == expandedElement ? 'expanded' : 'collapsed'\"\n             class=\"element-detail\">\n          <div *ngIf=\"expandedRow\" class=\"element-content\">\n            <ng-container [ngTemplateOutletContext]=\"{element: data[index]}\"\n                          [ngTemplateOutlet]=\"expandedRow\">\n            </ng-container>\n          </div>\n        </div>\n      </td>\n    </ng-container>\n\n    <!--  FINAL THINGS  -->\n    <tr *matHeaderRowDef=\"[reservedColumnNames.searchRow]\" [hidden]=\"!search\" class=\"search-field-row\"\n        mat-header-row></tr>\n\n    <tr *matHeaderRowDef=\"dataColumns\" mat-header-row></tr>\n\n    <tr (bdShortPress)=\"onRowClicked(element);$event.stopPropagation()\"\n        *matRowDef=\"let element; let index = dataIndex; columns: dataColumns;\"\n        mat-row>\n    </tr>\n\n    <tr *matRowDef=\"let row; columns: [reservedColumnNames.expandedRow]\" class=\"expandable-row\" mat-row\n    ></tr>\n\n  </table>\n\n  <mat-paginator [hidden]=\"!paginator\"></mat-paginator>\n</div>\n",
                    animations: [
                        animations.trigger('detailExpand', [
                            animations.state('collapsed', animations.style({ height: '0px', minHeight: '0', display: 'none' })),
                            animations.state('expanded', animations.style({ height: '*' })),
                            animations.transition('expanded <=> collapsed', animations.animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
                        ]),
                    ],
                    styles: [".expand.bd-expand-close{opacity:.3;transition:all .2s}.expand.bd-expand-open{transform:rotate(180deg);opacity:1;transition:all .2s}.table-wrapper{overflow:auto;display:block;width:100%;border:1px solid #dcdcdc;color:#414141;padding:0;border-bottom-right-radius:5px;border-bottom-left-radius:5px}.table-wrapper table{overflow-x:scroll;min-width:100%;border-collapse:inherit}.table-wrapper table .search-field-row{background-color:#fafafa}.table-wrapper table .search-field-row .search-row{padding:0}.table-wrapper table .search-field-row .search-row .search-wrapper{background-color:#fafafa;width:100%;min-height:40px;padding:10px}.table-wrapper table .search-field-row .search-row .search-wrapper input{background:none!important;border:none;outline:none}.table-wrapper table .avatar-wrapper{width:40px;height:40px;border-radius:50%;display:table-cell!important;vertical-align:middle;text-align:center}.table-wrapper table .avatar-wrapper span{font-weight:600;color:#fff;text-align:center}.table-wrapper table .first-data-row-padding{padding-left:10px}.table-wrapper table th.mat-header-cell{color:#707070;font-weight:700;min-width:100px}.table-wrapper table th .hidden-icon{padding:15px;width:12px}.table-wrapper table th.service-column-header{min-width:5px!important;width:20px;padding-left:0!important}.table-wrapper table th.mat-column-search-field{padding:0!important}.table-wrapper table th.mat-column-avatar{min-width:60px}.table-wrapper table th.actions-column-header{min-width:20px!important}.table-wrapper table tr:hover .expand.bd-expand-close{opacity:1}.table-wrapper table tr.mat-row:nth-child(4n+3){background-color:#efeff0}.table-wrapper table tr.search-field-row{height:auto}.table-wrapper table tr.expandable-row{height:0}.table-wrapper table tr.expandable-row .element-detail{overflow:hidden;display:flex}.table-wrapper table tr.expandable-row .element-detail .element-content{padding:8px;width:100%}.table-wrapper table td .checkbox{padding:10px}.table-wrapper table td .expand{cursor:pointer;padding:15px}.table-wrapper table td.service-column-td{min-width:5px!important;width:20px;padding-left:0!important;border-right:1px solid #e2e2e4}.table-wrapper table td.mat-cell:last-of-type{padding-right:0!important}.table-wrapper table td#bdReservedNameForExpandedRow{border-bottom:0}.table-wrapper table td.mat-cell{border-bottom:1px solid #e2e2e4;color:#5b5b60!important;border-top:none}.expandedBlock{border-bottom:1px solid #dcdcdc!important}", ".gradient-strawberry{background-image:linear-gradient(45deg,#fe0b46,#ffab96)}.gradient-orange{background-image:linear-gradient(45deg,#c471f3,#f671cd)}.gradient-dawn{background-image:linear-gradient(45deg,#f3904f,#3b4371)}.gradient-shdow-night{background-image:linear-gradient(45deg,#000,#53346d)}.gradient-man-of-steel{background-image:linear-gradient(45deg,#780206,#061161)}.gradient-flickr{background-image:linear-gradient(45deg,#33001b,#ff0084)}.gradient-ibiza-sunset{background-image:linear-gradient(45deg,#ee0979,#ff6a00)}.gradient-politics{background-image:linear-gradient(45deg,#2196f3,#f44336)}", ".float-right{float:right!important}.cursor-pointer{cursor:pointer}"]
                },] }
    ];
    MatDynamicTableComponent.ctorParameters = function () { return [
        { type: MatDynamicTableService },
        { type: i0.ChangeDetectorRef }
    ]; };
    MatDynamicTableComponent.propDecorators = {
        data: [{ type: i0.Input }],
        columns: [{ type: i0.Input }],
        displayColumns: [{ type: i0.Input }],
        translatePath: [{ type: i0.Input }],
        apiable: [{ type: i0.Input }],
        bulk: [{ type: i0.Input }],
        search: [{ type: i0.Input }],
        paginator: [{ type: i0.Input }],
        actions: [{ type: i0.Input }],
        roles: [{ type: i0.Input }],
        expandedRow: [{ type: i0.Input }],
        searchInput: [{ type: i0.ViewChild, args: ['searchInput',] }],
        matPaginator: [{ type: i0.ViewChild, args: [paginator.MatPaginator,] }],
        matSort: [{ type: i0.ViewChild, args: [sort.MatSort,] }],
        massBulkCheckbox: [{ type: i0.ViewChild, args: ['massBulkCheckbox',] }],
        actionRequest: [{ type: i0.Output }],
        apiRequest: [{ type: i0.Output }],
        bulkContainerUpdate: [{ type: i0.Output }]
    };

    var SimpleOrConditionalActionPipe = /** @class */ (function () {
        function SimpleOrConditionalActionPipe() {
        }
        SimpleOrConditionalActionPipe.prototype.transform = function (value) {
            switch (true) {
                case (typeof value === 'string'):
                    return 'simple';
                case (value instanceof Object):
                    return 'conditional';
                default:
                    throw new Error('Unknown Action type passed');
            }
        };
        return SimpleOrConditionalActionPipe;
    }());
    SimpleOrConditionalActionPipe.decorators = [
        { type: i0.Pipe, args: [{
                    name: 'simpleOrConditionalAction'
                },] }
    ];

    var CheckActionConditionPipe = /** @class */ (function () {
        function CheckActionConditionPipe() {
        }
        CheckActionConditionPipe.prototype.transform = function (element, callback) {
            return callback(element);
        };
        return CheckActionConditionPipe;
    }());
    CheckActionConditionPipe.decorators = [
        { type: i0.Pipe, args: [{
                    name: 'checkActionCondition'
                },] }
    ];

    var ActionMicroPipesModule = /** @class */ (function () {
        function ActionMicroPipesModule() {
        }
        return ActionMicroPipesModule;
    }());
    ActionMicroPipesModule.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [SimpleOrConditionalActionPipe, CheckActionConditionPipe],
                    exports: [SimpleOrConditionalActionPipe, CheckActionConditionPipe],
                },] }
    ];

    var MatDynamicTableModule = /** @class */ (function () {
        function MatDynamicTableModule() {
        }
        MatDynamicTableModule.forRoot = function (moduleConfig) {
            return {
                ngModule: MatDynamicTableModule,
                providers: [
                    MatDynamicTableService,
                    {
                        provide: DYNAMIC_TABLE_MODULE_CONFIG,
                        useValue: moduleConfig
                    }
                ]
            };
        };
        MatDynamicTableModule.forChild = function (moduleConfig) {
            return {
                ngModule: MatDynamicTableModule,
                providers: [
                    MatDynamicTableService,
                    {
                        provide: DYNAMIC_TABLE_MODULE_CONFIG,
                        useValue: moduleConfig
                    }
                ]
            };
        };
        return MatDynamicTableModule;
    }());
    MatDynamicTableModule.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [
                        MatDynamicTableComponent
                    ],
                    imports: [
                        common.CommonModule,
                        flexLayout.FlexModule,
                        forms.FormsModule,
                        forms.ReactiveFormsModule,
                        tooltip.MatTooltipModule,
                        formField.MatFormFieldModule,
                        input.MatInputModule,
                        table.MatTableModule,
                        sort.MatSortModule,
                        paginator.MatPaginatorModule,
                        button.MatButtonModule,
                        menu.MatMenuModule,
                        icon.MatIconModule,
                        checkbox.MatCheckboxModule,
                        i1.TranslateModule,
                        pipeCollection.TimeAgoPipeModule,
                        pipeCollection.RandomGradientPipeModule,
                        pipeCollection.NullOrUndefinedHandlerPipeModule,
                        pipeCollection.SliceWithDotsPipeModule,
                        pipeCollection.ToIconPipeModule,
                        pipeCollection.TimeAgoPipeModule,
                        pipeCollection.BdDatePipeModule,
                        pipeCollection.OrderedKeyValuePipeModule,
                        pipeCollection.FirstLetterPipeModule,
                        i1$1.DomElementValidatorDirectiveModule,
                        i1$1.ShortPressDirectiveModule,
                        i1$1.RandomClassDirectiveModule,
                        i1$1.ApiDataHandlerDirectiveModule,
                        ActionMicroPipesModule
                    ],
                    exports: [
                        MatDynamicTableComponent,
                    ]
                },] }
    ];

    function instanceOfAvatarColumnInterface(object) {
        return object.discriminator === 'AvatarColumn';
    }

    function instanceOfDateColumnInterface(object) {
        return object.discriminator === 'DateColumn';
    }

    function instanceOfIconColumnInterface(object) {
        return object.discriminator === 'IconColumn';
    }

    function instanceOfProgressBarColumnInterface(object) {
        return object.discriminator === 'ProgressBarColumn';
    }

    function instanceOfTextColumnInterface(object) {
        return object.discriminator === 'TextColumn';
    }

    var EXPANDED_ROW_DATA = new i0.InjectionToken('EXPANDED_ROW_DATA');
    var TABLE_CONFIG = new i0.InjectionToken('TABLE_CONFIG');
    var TABLE = new i0.InjectionToken('TABLE');

    (function (ReservedNamesV2) {
        ReservedNamesV2["expandArrowColumn"] = "__expandArrowColumn__";
        ReservedNamesV2["expandedColumn"] = "__expandedColumnColumn__";
        ReservedNamesV2["actionsColumn"] = "__actionsColumnColumn__";
        ReservedNamesV2["bulkCheckboxColumn"] = "__bulkCheckboxColumn__";
        ReservedNamesV2["bulkMassCheckboxColumn"] = "__bulkMassCheckboxColumn__";
        ReservedNamesV2["infoColumn"] = "__infoColumn__";
    })(exports.ReservedNamesV2 || (exports.ReservedNamesV2 = {}));

    var FiltersDialogComponent = /** @class */ (function () {
        function FiltersDialogComponent(dialogRef) {
            this.dialogRef = dialogRef;
        }
        FiltersDialogComponent.prototype.resetAndClose = function () {
            this.form.reset();
            this.dialogRef.close(this.form.value);
        };
        return FiltersDialogComponent;
    }());

    function instanceOfProgressBarColumnInterface$1(object) {
        return object.discriminator === 'ProgressBarColumn';
    }

    function instanceOfTextColumnInterface$1(object) {
        return object.discriminator === 'TextColumn';
    }

    var TextSearchModeEnum;
    (function (TextSearchModeEnum) {
        TextSearchModeEnum["EQUAL_TO"] = "EQUAL_TO";
        TextSearchModeEnum["CONTAINS"] = "CONTAINS";
        TextSearchModeEnum["STARTS_WITH"] = "STARTS_WITH";
        TextSearchModeEnum["ENDS_WITH"] = "ENDS_WITH";
    })(TextSearchModeEnum || (TextSearchModeEnum = {}));

    var ActiveFiltersPipe = /** @class */ (function () {
        function ActiveFiltersPipe() {
        }
        ActiveFiltersPipe.prototype.transform = function (value) {
            if (!value) {
                return [];
            }
            return this.getActiveFilters(value);
        };
        ActiveFiltersPipe.prototype.getActiveFilters = function (filtersValue) {
            var _this = this;
            return Object.keys(filtersValue).filter(function (key) { return _this.hasActiveFilter(filtersValue[key]); });
        };
        ActiveFiltersPipe.prototype.hasActiveFilter = function (filterValue) {
            var _this = this;
            if (!filterValue) {
                return false;
            }
            return Object.values(filterValue).some(function (value) {
                if (Array.isArray(value)) {
                    return value.length > 0;
                }
                if (typeof value === 'object' && value !== null) {
                    return _this.hasActiveFilter(value);
                }
                return !!value;
            });
        };
        return ActiveFiltersPipe;
    }());
    ActiveFiltersPipe.decorators = [
        { type: i0.Pipe, args: [{
                    name: 'activeFilters'
                },] }
    ];

    var EXPANDED_ROW_ANIMATION = animations.trigger('detailExpand', [
        animations.state('collapsed', animations.style({ height: '0px', minHeight: '0', display: 'none' })),
        animations.state('expanded', animations.style({ height: '*' })),
        animations.transition('expanded <=> collapsed', animations.animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]);

    function enumToArray(enumRef) {
        var res = [];
        for (var key in enumRef) {
            res.push(enumRef[key]);
        }
        return res;
    }

    function mixinHasSubs(base) {
        return /** @class */ (function (_super) {
            __extends(class_1, _super);
            function class_1() {
                var args = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    args[_i] = arguments[_i];
                }
                var _this = _super.call(this, args) || this;
                _this.subs$ = [];
                return _this;
            }
            class_1.prototype.clearSubscriptions = function () {
                this.subs$.forEach(function (sub) { return sub.unsubscribe(); });
            };
            return class_1;
        }(base));
    }

    var DisplayedColumnsDialogComponent = /** @class */ (function () {
        function DisplayedColumnsDialogComponent(data, config, dialogRef) {
            this.data = data;
            this.config = config;
            this.dialogRef = dialogRef;
        }
        DisplayedColumnsDialogComponent.prototype.reorderColumns = function (_a) {
            var previousIndex = _a.previousIndex, currentIndex = _a.currentIndex;
            dragDrop.moveItemInArray(this.data.displayedColumns, previousIndex, currentIndex);
        };
        DisplayedColumnsDialogComponent.prototype.submit = function (data) {
            this.dialogRef.close(data
                .filter(function (elem) { return elem.isDisplayed; })
                .map(function (elem) { return elem.name; }));
        };
        return DisplayedColumnsDialogComponent;
    }());
    DisplayedColumnsDialogComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'bd-displayed-columns-dialog',
                    template: "<mat-card-header mat-dialog-title>\n  <mat-card-title>{{config.globalTranslatePrefix + 'customize-columns' | translate}}</mat-card-title>\n</mat-card-header>\n\n<mat-card-content mat-dialog-content>\n  <div (cdkDropListDropped)=\"reorderColumns($event)\" cdkDropList class=\"order-list\">\n    <div *ngFor=\"let displayedColumn of data.displayedColumns\"\n         cdkDrag\n         class=\"order-list__item-box\">\n      <div class=\"order-list__item\">\n        <mat-checkbox [(ngModel)]=\"displayedColumn.isDisplayed\">\n          {{data.translatePrefix + displayedColumn.name | translate}}\n        </mat-checkbox>\n        <span cdkDragHandle class=\"order-list__handler\">\n          <i [class]=\"config.globalIcons.displayedColumnsReorder\"></i>\n        </span>\n      </div>\n    </div>\n  </div>\n</mat-card-content>\n\n<mat-card-actions align=\"end\" mat-dialog-actions>\n  <button color=\"primary\"\n          mat-button\n          mat-dialog-close>\n    {{config.globalTranslatePrefix + 'cancel' | translate | uppercase}}\n  </button>\n  <button (click)=\"submit(data.displayedColumns)\"\n          color=\"primary\"\n          mat-button>\n    {{config.globalTranslatePrefix + 'save' | translate | uppercase}}\n  </button>\n</mat-card-actions>\n",
                    styles: [".order-list{display:block;overflow:hidden}.order-list__item-box{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.order-list__item{display:flex;align-items:center;justify-content:space-between;width:280px;height:36px;margin:5px;padding:10px;background:#fff;border:1px solid #e7e7e7;box-sizing:border-box;border-radius:4px}.order-list__handler{cursor:move}.order-list.cdk-drop-list-dragging .order-list__item-box:not(.cdk-drag-placeholder){transition:transform .25s cubic-bezier(0,0,.2,1)}.cdk-drag-placeholder{opacity:0}.cdk-drag-animating{transition:transform .25s cubic-bezier(0,0,.2,1)}"]
                },] }
    ];
    DisplayedColumnsDialogComponent.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [dialog.MAT_DIALOG_DATA,] }] },
        { type: undefined, decorators: [{ type: i0.Inject, args: [TABLE_CONFIG,] }] },
        { type: dialog.MatDialogRef }
    ]; };

    var DefaultFiltersDialogComponent = /** @class */ (function (_super) {
        __extends(DefaultFiltersDialogComponent, _super);
        function DefaultFiltersDialogComponent(data, dialogRef, dynamicFormService) {
            var _this = _super.call(this, dialogRef) || this;
            _this.data = data;
            _this.dialogRef = dialogRef;
            _this.dynamicFormService = dynamicFormService;
            return _this;
        }
        DefaultFiltersDialogComponent.prototype.ngOnInit = function () {
            this.form = this.dynamicFormService.generateForm(this.data.metadata, this.data.initValue);
        };
        DefaultFiltersDialogComponent.prototype.resetAndClose = function () {
            this.form.reset();
            this.dialogRef.close(this.form.value);
        };
        return DefaultFiltersDialogComponent;
    }(FiltersDialogComponent));
    DefaultFiltersDialogComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'bd-default-filters-dialog',
                    template: "<mat-card-header mat-dialog-title>\n  <span>{{'filters' | translate}}</span>\n  <button (click)=\"resetAndClose()\" [color]=\"'primary'\" mat-button>{{'reset-all' | translate}}</button>\n</mat-card-header>\n\n<mat-card-content mat-dialog-content>\n  <bd-dynamic-form [form]=\"form\" [metadata]=\"data.metadata\"></bd-dynamic-form>\n</mat-card-content>\n\n<mat-card-actions mat-dialog-actions align=\"end\">\n  <button [color]=\"'primary'\" mat-button mat-dialog-close>{{'cancel' | translate}}</button>\n  <button [color]=\"'primary'\" [mat-dialog-close]=\"form.value\" mat-button>{{'save' | translate}}</button>\n</mat-card-actions>\n",
                    styles: [""]
                },] }
    ];
    DefaultFiltersDialogComponent.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [dialog.MAT_DIALOG_DATA,] }] },
        { type: dialog.MatDialogRef },
        { type: dynamicForm.DynamicFormService, decorators: [{ type: i0.Optional }] }
    ]; };

    var TableHeaderDirective = /** @class */ (function () {
        function TableHeaderDirective() {
        }
        return TableHeaderDirective;
    }());
    TableHeaderDirective.decorators = [
        { type: i0.Directive, args: [{
                    selector: '[bdTableHeader]'
                },] }
    ];

    function instanceOfAvatarColumnInterface$1(object) {
        return object.discriminator === 'AvatarColumn';
    }

    function instanceOfDateColumnInterface$1(object) {
        return object.discriminator === 'DateColumn';
    }

    function instanceOfIconColumnInterface$1(object) {
        return object.discriminator === 'IconColumn';
    }

    var ActionConditionOperatorsEnum;
    (function (ActionConditionOperatorsEnum) {
        ActionConditionOperatorsEnum["EQUALS"] = "EQUALS";
        ActionConditionOperatorsEnum["NOTEQUAL"] = "NOTEQUAL";
        ActionConditionOperatorsEnum["TRUTHY"] = "TRUTHY";
        ActionConditionOperatorsEnum["IN"] = "IN";
    })(ActionConditionOperatorsEnum || (ActionConditionOperatorsEnum = {}));

    var ActionsConfigService = /** @class */ (function () {
        function ActionsConfigService(domElementValidatorService) {
            this.domElementValidatorService = domElementValidatorService;
            this.actionRequest = new i0.EventEmitter();
            this._actions = {};
        }
        Object.defineProperty(ActionsConfigService.prototype, "actions", {
            get: function () {
                return this._actions;
            },
            set: function (actions) {
                this._actions = actions;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ActionsConfigService.prototype, "bulkActions", {
            get: function () {
                return this._bulkActions;
            },
            set: function (bulkActions) {
                this._bulkActions = bulkActions;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ActionsConfigService.prototype, "headerActions", {
            get: function () {
                return this._headerActions;
            },
            set: function (headerActions) {
                this._headerActions = headerActions;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(ActionsConfigService.prototype, "singleActions", {
            get: function () {
                return this._singleActions;
            },
            set: function (singleActions) {
                this._singleActions = singleActions;
            },
            enumerable: false,
            configurable: true
        });
        ActionsConfigService.prototype.checkActions = function (actionsRequestObservsLength) {
            var e_1, _a;
            var header = false;
            var bulk = false;
            var single = false;
            try {
                for (var _b = __values(Object.values(this.actions)), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var action = _c.value;
                    header = header || action.type === 'header';
                    bulk = bulk || action.type === 'bulk' || action.type === 'both';
                    single = single || action.type === 'single' || action.type === 'both';
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
            this.hasSingleActions = single && actionsRequestObservsLength;
            this.hasBulkActions = bulk && actionsRequestObservsLength;
            this.hasHeaderButtons = header && actionsRequestObservsLength;
        };
        ActionsConfigService.prototype.filterBulkActions = function (_bulkActions, actionConfig) {
            var _this = this;
            return _bulkActions.filter(function (action) { return _this.domElementValidatorService.validateRole(actionConfig[action].role); });
        };
        ActionsConfigService.prototype.filterSingleActions = function (actions, elem) {
            var _this = this;
            return Object.keys(actions)
                .filter(function (key) { return _this.checkActionType(actions[key]) &&
                _this.checkActionRole(actions[key].role) &&
                _this.checkActionCondition(elem, actions[key].condition); });
        };
        ActionsConfigService.prototype.initActions = function (actions) {
            this.actions = actions;
            var bulk = [];
            var header = [];
            var single = [];
            Object.entries(actions)
                .forEach(function (_a) {
                var _b = __read(_a, 2), key = _b[0], value = _b[1];
                switch (value.type) {
                    case 'both':
                    case 'bulk':
                        bulk.push(key);
                        break;
                    case 'header':
                        header.push(key);
                        break;
                    default:
                        break;
                }
                if (value.type === 'single' || value.type === 'both') {
                    single.push(key);
                }
            });
            this.singleActions = single;
            this.bulkActions = bulk;
            this.headerActions = header;
        };
        ActionsConfigService.prototype.initFilterBulkActions = function () {
            this.bulkActions = this.filterBulkActions(this.bulkActions, this.actions);
            this.hasBulkActions = !!this.bulkActions.length;
        };
        // TODO delete ActionsV3Config when ActionsV2Config will be updated
        ActionsConfigService.prototype.checkActionCondition = function (elem, condition) {
            if (!condition) {
                return true;
            }
            if (typeof condition === 'function') {
                return condition(elem);
            }
            var actualValue = _.at(elem, condition.key)[0];
            switch (condition.operator) {
                case ActionConditionOperatorsEnum.EQUALS:
                    return actualValue === condition.value;
                case ActionConditionOperatorsEnum.TRUTHY:
                    return !!actualValue;
                case ActionConditionOperatorsEnum.NOTEQUAL:
                    return actualValue !== condition.value;
                case ActionConditionOperatorsEnum.IN:
                    return condition.value.some(function (v) { return v === actualValue; });
                default:
                    break;
            }
            return false;
        };
        ActionsConfigService.prototype.checkActionRole = function (role) {
            if (!this.domElementValidatorService || !role || role instanceof Array && role.length === 0) {
                return true;
            }
            if (typeof role === 'string') {
                return this.domElementValidatorService.validateRole(role);
            }
            else if (role instanceof Array) {
                var checkRes = false;
                for (var index = 0; index < role.length; index++) {
                    if (this.domElementValidatorService.validateRole(role[index])) {
                        checkRes = true;
                        break;
                    }
                }
                return checkRes;
            }
        };
        ActionsConfigService.prototype.checkActionType = function (action) {
            return action.type === 'single' || action.type === 'both';
        };
        return ActionsConfigService;
    }());
    ActionsConfigService.ɵprov = i0.ɵɵdefineInjectable({ factory: function ActionsConfigService_Factory() { return new ActionsConfigService(i0.ɵɵinject(i1$1.DomElementValidatorService, 8)); }, token: ActionsConfigService, providedIn: "root" });
    ActionsConfigService.decorators = [
        { type: i0.Injectable, args: [{ providedIn: 'root' },] }
    ];
    ActionsConfigService.ctorParameters = function () { return [
        { type: i1$1.DomElementValidatorService, decorators: [{ type: i0.Optional }] }
    ]; };

    // eslint-disable-next-line @typescript-eslint/ban-types
    var TableService = /** @class */ (function () {
        function TableService(actionsConfigService, domElementValidatorService) {
            this.actionsConfigService = actionsConfigService;
            this.domElementValidatorService = domElementValidatorService;
        }
        TableService.prototype.fillColumnsConfigDefaults = function (columnsConfig) {
            var _this = this;
            var res = columnsConfig;
            Object.keys(columnsConfig).forEach(function (key) {
                switch (true) {
                    case instanceOfTextColumnInterface$1(columnsConfig[key]):
                        res[key] = _this.fillTextColumnDefaults(columnsConfig[key]);
                        break;
                    case instanceOfDateColumnInterface$1(columnsConfig[key]):
                        res[key] = _this.fillDateColumnDefaults(columnsConfig[key]);
                        break;
                    case instanceOfAvatarColumnInterface$1(columnsConfig[key]):
                        res[key] = _this.fillAvatarColumnDefaults(columnsConfig[key]);
                        break;
                    case instanceOfIconColumnInterface$1(columnsConfig[key]):
                        res[key] = _this.fillIconColumnDefaults(columnsConfig[key]);
                        break;
                    case instanceOfProgressBarColumnInterface$1(columnsConfig[key]):
                        res[key] = _this.fillProgressBarColumnDefaults(columnsConfig[key]);
                        break;
                    default:
                        throw new Error('');
                }
            });
            return res;
        };
        TableService.prototype.hasAnyActiveFilter = function (requestParams) {
            var _this = this;
            if (requestParams === undefined || requestParams === null) {
                return false;
            }
            return Object.values(requestParams).some(function (value) { return typeof value === 'object' && value !== null || Array.isArray(value)
                ? _this.hasAnyActiveFilter(value)
                : !!value; });
        };
        TableService.prototype.parseData = function (data, columns, actions) {
            var _this = this;
            var keys = Object.keys(columns);
            return data.map(function (elem, index) {
                var systemProperties = _this.defineParsedElemSystemProperties(elem, index, actions);
                var dataProperties = _this.defineParsedElemDataProperties(elem, columns, keys);
                return Object.assign(Object.assign({}, systemProperties), dataProperties);
            });
        };
        // DEFINING PARSED ELEMENTS
        TableService.prototype.checkMultipleRole = function (roles) {
            if (roles.length) {
                for (var index = 0; index < roles.length; index++) {
                    if (this.domElementValidatorService.validateRole(roles[index])) {
                        return true;
                    }
                }
                return false;
            }
            return true;
        };
        TableService.prototype.defineParsedElemDataProperties = function (elem, columns, keys) {
            var _this = this;
            var res = {};
            keys.forEach(function (key) {
                switch (true) {
                    case instanceOfTextColumnInterface$1(columns[key]):
                        res[key] = _this.parseTextColumn(elem, columns[key]);
                        break;
                    case instanceOfDateColumnInterface$1(columns[key]):
                        res[key] = _this.parseDateColumn(elem, columns[key]);
                        break;
                    case instanceOfAvatarColumnInterface$1(columns[key]):
                        res[key] = _this.parseAvatarColumn(elem, columns[key]);
                        break;
                    case instanceOfIconColumnInterface$1(columns[key]):
                        res[key] = _this.parseIconColumn(elem, columns[key]);
                        break;
                    case instanceOfProgressBarColumnInterface$1(columns[key]):
                        res[key] = _this.parseProgressBarColumn(elem, columns[key]);
                        break;
                    default:
                        throw new Error('');
                }
            });
            return res;
        };
        TableService.prototype.defineParsedElemSystemProperties = function (elem, originalIndex, actions) {
            // TODO how to get list of current user actions?
            return {
                originalIndex: originalIndex,
                selected: false,
                singleActions: this.actionsConfigService.filterSingleActions(actions, elem),
            };
        };
        TableService.prototype.fillAvatarColumnDefaults = function (column) {
            return Object.assign(Object.assign({}, this.fillBaseColumnDefaults(column)), column);
        };
        TableService.prototype.fillBaseColumnDefaults = function (column) {
            return Object.assign({ sortable: false, hidden: false }, column);
        };
        TableService.prototype.fillDateColumnDefaults = function (column) {
            return Object.assign(Object.assign(Object.assign({}, this.fillBaseColumnDefaults(column)), { format: 'yyyy/MM/dd', timeAgo: false }), column);
        };
        TableService.prototype.fillIconColumnDefaults = function (column) {
            return Object.assign(Object.assign({}, this.fillBaseColumnDefaults(column)), column);
        };
        TableService.prototype.fillProgressBarColumnDefaults = function (column) {
            return Object.assign(Object.assign({}, this.fillBaseColumnDefaults(column)), column);
        };
        TableService.prototype.fillTextColumnDefaults = function (column) {
            return Object.assign(Object.assign(Object.assign({}, this.fillBaseColumnDefaults(column)), { subPath: null, limit: 30, translatePrefix: '', subHeaderKey: undefined, separator: ' ', mask: undefined }), column);
        };
        TableService.prototype.parseAvatarColumn = function (data, column) {
            var arrayRes = this.parseBaseColumn(data, column);
            var res = arrayRes
                .map(function (elem) { return elem ? elem[0] : elem; })
                .join('');
            return res;
        };
        TableService.prototype.parseBaseColumn = function (data, column) {
            var array = _.at(data, column.paths);
            if ('dynamicFieldIndex' in column) {
                array = array.map(function (elem) {
                    var keys = Object.keys(elem);
                    return elem[keys[0]];
                });
            }
            return array;
        };
        TableService.prototype.parseDateColumn = function (data, column) {
            var arrayRes = this.parseBaseColumn(data, column);
            return arrayRes[0];
        };
        TableService.prototype.parseIconColumn = function (data, column) {
            var arrayRes = this.parseBaseColumn(data, column);
            return arrayRes[0];
        };
        TableService.prototype.parseProgressBarColumn = function (data, column) {
            var actualRes = this.parseBaseColumn(data, column)[0];
            var maxRes = _.at(data, column.maxValuePaths)[0];
            var ratioRes = actualRes && maxRes && actualRes / maxRes * 100;
            var classRes = '';
            if (column.classesPerRatio) {
                column.classesPerRatio.forEach(function (classPerRatio) {
                    if (classPerRatio.isAlways) {
                        classRes += classPerRatio.klass + " ";
                    }
                    else if (classPerRatio.ratioRange &&
                        ratioRes >= classPerRatio.ratioRange.from &&
                        ratioRes <= classPerRatio.ratioRange.to) {
                        classRes += classPerRatio.klass + " ";
                    }
                });
            }
            var tooltipRes = ratioRes ? actualRes + " / " + maxRes : '';
            return { actual: actualRes, max: maxRes, ratio: ratioRes, klass: classRes, tooltip: tooltipRes };
        };
        TableService.prototype.parseTextColumn = function (data, column) {
            var arrayRes = this.parseBaseColumn(data, column);
            var mainRes = arrayRes
                .map(function (elem, index) {
                if (!elem) {
                    return elem;
                }
                if (column.mask) {
                    elem = column.mask(elem);
                }
                if (column.translatePrefix) {
                    // eslint-disable-next-line @typescript-eslint/restrict-plus-operands
                    elem = column.translatePrefix + elem;
                }
                if (column.separator && index < arrayRes.length - 1) {
                    if (typeof column.separator === 'string') {
                        // eslint-disable-next-line @typescript-eslint/restrict-plus-operands
                        elem = elem + column.separator;
                    }
                    else if (column.separator instanceof Array) {
                        // eslint-disable-next-line @typescript-eslint/restrict-plus-operands
                        elem = elem + column.separator[index];
                    }
                }
                return elem;
            })
                .join('') || null;
            var subRes;
            if (column.subPath) {
                // fucking lodash types...
                subRes = _.at(data, column.subPath);
            }
            return {
                main: mainRes,
                sub: subRes === null || subRes === void 0 ? void 0 : subRes[0],
            };
        };
        return TableService;
    }());
    TableService.decorators = [
        { type: i0.Injectable }
    ];
    TableService.ctorParameters = function () { return [
        { type: ActionsConfigService },
        { type: i1$1.DomElementValidatorService, decorators: [{ type: i0.Optional }] }
    ]; };

    var ɵ0 = { appearance: 'legacy' };
    var TableComponent = /** @class */ (function (_super) {
        __extends(TableComponent, _super);
        function TableComponent(config, service, actionsConfigService, injector, dialog, cd, activeFiltersPipe, dynamicFormService) {
            var _this = _super.call(this) || this;
            _this.config = config;
            _this.service = service;
            _this.actionsConfigService = actionsConfigService;
            _this.injector = injector;
            _this.dialog = dialog;
            _this.cd = cd;
            _this.activeFiltersPipe = activeFiltersPipe;
            _this.dynamicFormService = dynamicFormService;
            _this.customColumnTemplateRefs = {};
            _this.filtersDialogRef = DefaultFiltersDialogComponent;
            _this.globalSort = true;
            _this.rowClickAction = 'open';
            _this.textSearchPlaceholder = 'Search';
            _this.translatePrefix = '';
            _this.actionRequest = new i0.EventEmitter();
            _this.bulkActionRequest = new i0.EventEmitter();
            _this.displayedColumnsUpdate = new i0.EventEmitter();
            _this._actions = {};
            _this.bulkSelection = new collections.SelectionModel(true, []);
            _this.componentClass = true;
            _this.progressBarColumns = [];
            _this.reservedNames = exports.ReservedNamesV2;
            _this.textColumns = [];
            _this.textSearchControl = new forms.FormControl('');
            _this.textSearchEnabled = false;
            _this.textSearchableColumns = [];
            return _this;
        }
        Object.defineProperty(TableComponent.prototype, "actions", {
            get: function () {
                return this._actions;
            },
            set: function (actions) {
                this._actions = actions;
                var bulk = [];
                var header = [];
                Object.keys(actions).forEach(function (key) {
                    switch (actions[key].type) {
                        case 'both':
                        case 'bulk':
                            bulk.push(key);
                            break;
                        case 'header':
                            header.push(key);
                            break;
                        default:
                            break;
                    }
                });
                this._bulkActions = bulk;
                this._headerActions = header;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(TableComponent.prototype, "columns", {
            set: function (columns) {
                var _this = this;
                this._columns = this.service.fillColumnsConfigDefaults(columns);
                this.displayedColumns = Object.keys(this._columns)
                    .filter(function (key) { return !_this._columns[key].hidden; });
                this.textColumns = Object.keys(this._columns)
                    .filter(function (key) { return instanceOfTextColumnInterface$1(_this._columns[key]); });
                this.progressBarColumns = Object.keys(this._columns)
                    .filter(function (key) { return instanceOfProgressBarColumnInterface$1(_this._columns[key]); });
                this.textSearchableColumns = Object.entries(this._columns)
                    .filter(function (_a) {
                    var _b = __read(_a, 2), key = _b[0], value = _b[1];
                    return !!value.textSearch;
                })
                    .map(function (_a) {
                    var _b = __read(_a, 2), key = _b[0], value = _b[1];
                    return key;
                });
                this.textSearchEnabled = this.textSearchableColumns.length > 0;
            },
            enumerable: false,
            configurable: true
        });
        // LIFECYCLE HOOKS START
        TableComponent.prototype.ngOnChanges = function (changes) {
            // need to exclude first change because setParams() need to be called first (in ngOnInit())
            if (changes.columns && !changes.columns.firstChange) {
                this.addSystemDisplayColumns();
            }
            if (changes.data && !changes.data.firstChange) {
                this.updateDataSource();
            }
            if (changes.actions && !changes.actions.firstChange) {
                this.filterBulkActions();
            }
            if (changes.pagination && !changes.pagination.firstChange) {
                this.initPagination();
                this.cd.detectChanges();
            }
            if (changes.data && this.hasExpandedRow) {
                this.initExpandedComponentInjectors();
            }
        };
        TableComponent.prototype.ngOnInit = function () {
            this.setFilterPredicate();
            this.setSortingDataAccessor();
            this.setParams();
            this.addSystemDisplayColumns();
            this.initDataSource();
            this.initTextSearch();
            if (this.hasBulkActions) {
                this.filterBulkActions();
            }
            if (this.hasFilters || this.textSearchEnabled) {
                this.dataSource.filterPredicate = this.filterPredicate;
                if (this.hasFilters) {
                    this.initFilters();
                }
            }
        };
        TableComponent.prototype.ngAfterViewInit = function () {
            if (this.hasPagination) {
                this.initPagination();
            }
            if (this.hasGlobalSort) {
                this.initGlobalSort();
            }
            this.customHeader = !!this.tableHeader;
            this.cd.detectChanges();
        };
        TableComponent.prototype.ngOnDestroy = function () {
            this.clearSubscriptions();
        };
        // LIFECYCLE HOOKS END
        TableComponent.prototype.emitActionRequest = function (action, originalIndex) {
            var req = {
                action: action,
                data: this.data[originalIndex],
            };
            this.actionRequest.emit(req);
        };
        TableComponent.prototype.emitBulkActionRequest = function (action) {
            var _this = this;
            var req = {
                action: action,
                data: this.data
                    .filter(function (elem, index) { return _this.bulkSelection.selected
                    .map(function (parsedElem) { return parsedElem.originalIndex; })
                    .includes(index); }),
            };
            this.bulkActionRequest.emit(req);
        };
        TableComponent.prototype.emitHeaderActionRequest = function (action) {
            this.actionRequest.emit({ action: action, data: null });
        };
        TableComponent.prototype.isAllSelected = function () {
            var numSelected = this.bulkSelection.selected.length;
            var numRows = this.dataSource.data.length;
            return numSelected === numRows;
        };
        TableComponent.prototype.isCurrentPageSelected = function () {
            var _this = this;
            var pageIndex = this.dataSource.paginator.pageIndex;
            var pageSize = this.dataSource.paginator.pageSize;
            return this.dataSource.sortData(this.dataSource.filteredData, this.dataSource.sort)
                .slice(pageIndex * pageSize, pageIndex * pageSize + pageSize)
                .every(function (elem) { return _this.bulkSelection.isSelected(elem); });
        };
        TableComponent.prototype.onExpandArrowClicked = function (element) {
            this.expandedElement = this.expandedElement === element ? null : element;
        };
        TableComponent.prototype.onRowClicked = function (element) {
            if (element.singleActions.includes(this.rowClickAction)) {
                this.emitActionRequest(this.rowClickAction, element.originalIndex);
            }
        };
        TableComponent.prototype.openDisplayColumnsDialog = function () {
            var _this = this;
            var allColumns = Object.keys(this._columns);
            var currentDisplayColumns = this.displayedColumns.filter(function (elem) { return !enumToArray(exports.ReservedNamesV2).includes(elem); });
            var displayedColumnsDialogData = {
                translatePrefix: this.translatePrefix,
                displayedColumns: currentDisplayColumns
                    .map(function (elem) { return ({
                    name: elem,
                    isDisplayed: true,
                }); })
                    .concat(allColumns
                    .filter(function (elem) { return !currentDisplayColumns.includes(elem); })
                    .map(function (elem) { return ({
                    name: elem,
                    isDisplayed: false,
                }); })),
            };
            this.subs$.push(this.dialog.open(DisplayedColumnsDialogComponent, {
                data: displayedColumnsDialogData,
            }).afterClosed().pipe(operators.filter(function (res) { return !!res; })).subscribe(function (res) {
                _this.displayedColumnsUpdate.emit(res);
            }));
        };
        TableComponent.prototype.openFiltersDialog = function () {
            var _this = this;
            this.subs$.push(this.dialog.open(this.filtersDialogRef, {
                data: {
                    initValue: this.filtersValue,
                    metadata: this.filtersMetadata,
                    additionalData: this.additionalFiltersDialogData,
                },
            }).afterClosed().pipe(operators.filter(function (res) { return !!res; })).subscribe(function (res) {
                _this.updateFilterValue(res);
                _this.dataSource.filter = JSON.stringify(_this.filtersValue);
                _this.dataSource.paginator.firstPage();
            }));
        };
        TableComponent.prototype.removeFilter = function (control) {
            var e_1, _a;
            this.filtersValue = Object.entries(this.filtersValue)
                .reduce(function (accumulator, _a) {
                var _b;
                var _c = __read(_a, 2), key = _c[0], value = _c[1];
                return key === control ? accumulator : Object.assign(Object.assign({}, accumulator), (_b = {}, _b[key] = value, _b));
            }, {});
            try {
                for (var _b = __values(this.textSearchableColumns), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var name = _c.value;
                    if (!this.filtersValue[name]) {
                        this.textSearchControl.setValue('');
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
            this.dataSource.filter = JSON.stringify(this.filtersValue);
            this.dataSource.paginator.firstPage();
        };
        TableComponent.prototype.toggleAll = function () {
            var _a;
            if (this.isAllSelected()) {
                this.bulkSelection.clear();
            }
            else {
                (_a = this.bulkSelection).select.apply(_a, __spread(this.dataSource.data));
            }
        };
        TableComponent.prototype.toggleCurrentPage = function () {
            var _this = this;
            var pageIndex = this.dataSource.paginator.pageIndex;
            var pageSize = this.dataSource.paginator.pageSize;
            if (this.isCurrentPageSelected()) {
                this.dataSource.sortData(this.dataSource.filteredData, this.dataSource.sort)
                    .slice(pageIndex * pageSize, pageIndex * pageSize + pageSize)
                    .forEach(function (elem) {
                    _this.bulkSelection.deselect(elem);
                });
            }
            else {
                this.dataSource.sortData(this.dataSource.filteredData, this.dataSource.sort)
                    .slice(pageIndex * pageSize, pageIndex * pageSize + pageSize)
                    .forEach(function (elem) {
                    _this.bulkSelection.select(elem);
                });
            }
        };
        TableComponent.prototype.addSystemDisplayColumns = function () {
            if (this.hasExpandedRow) {
                this.displayedColumns.unshift(exports.ReservedNamesV2.expandArrowColumn);
            }
            if (this.hasBulkActions) {
                this.displayedColumns.unshift(exports.ReservedNamesV2.bulkCheckboxColumn);
            }
            if (this.hasSingleActions) {
                this.displayedColumns.push(exports.ReservedNamesV2.actionsColumn);
            }
        };
        TableComponent.prototype.checkActions = function () {
            var e_2, _a;
            var header = false;
            var bulk = false;
            var single = false;
            try {
                for (var _b = __values(Object.values(this._actions)), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var action = _c.value;
                    header = header || action.type === 'header';
                    bulk = bulk || action.type === 'bulk' || action.type === 'both';
                    single = single || action.type === 'single' || action.type === 'both';
                }
            }
            catch (e_2_1) { e_2 = { error: e_2_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_2) throw e_2.error; }
            }
            this.hasSingleActions = single && !!this.actionRequest.observers.length;
            this.hasBulkActions = bulk && !!this.actionRequest.observers.length;
            this.hasHeaderButtons = header && !!this.actionRequest.observers.length;
        };
        TableComponent.prototype.filterBulkActions = function () {
            this._bulkActions = this.actionsConfigService.filterBulkActions(this._bulkActions, this._actions);
        };
        TableComponent.prototype.filterCellByTextSearch = function (column, columnContent, searchString) {
            if (!columnContent && searchString) {
                return false;
            }
            columnContent = String(columnContent);
            if (typeof column.textSearch === 'function') {
                return column.textSearch(columnContent);
            }
            switch (column.textSearch) {
                case TextSearchModeEnum.CONTAINS:
                    return RegExp(searchString.toLowerCase()).exec(columnContent.toLowerCase());
                case TextSearchModeEnum.STARTS_WITH:
                    return columnContent.toLowerCase().startsWith(searchString.toLowerCase());
                case TextSearchModeEnum.ENDS_WITH:
                    return columnContent.toLowerCase().endsWith(searchString.toLowerCase());
                case TextSearchModeEnum.EQUAL_TO:
                    return columnContent.toLowerCase() === searchString.toLowerCase();
                default: return false;
            }
        };
        TableComponent.prototype.filterRowByTextSearch = function (data) {
            var e_3, _a;
            if (!this.textSearchableColumns || !this.textSearchControl.value) {
                return true;
            }
            var searchString = this.textSearchControl.value;
            try {
                for (var _b = __values(this.textSearchableColumns), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var name = _c.value;
                    var content = data[name].main;
                    var column = this._columns[name];
                    if (this.filterCellByTextSearch(column, content, searchString)) {
                        return true;
                    }
                }
            }
            catch (e_3_1) { e_3 = { error: e_3_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_3) throw e_3.error; }
            }
            return false;
        };
        TableComponent.prototype.initDataSource = function () {
            this.dataSource = new table.MatTableDataSource(this.service.parseData(this.data, this._columns, this._actions));
            if (this.hasExpandedRow) {
                this.initExpandedComponentInjectors();
            }
        };
        TableComponent.prototype.initExpandedComponentInjectors = function () {
            var _this = this;
            this.expandedComponentInjectors = this.data.map(function (elem) { return i0.Injector.create({
                providers: [
                    { provide: EXPANDED_ROW_DATA, useValue: elem },
                ],
                parent: _this.injector,
            }); });
        };
        TableComponent.prototype.initFilters = function () {
            var _this = this;
            this.filtersMetadata = {
                discriminator: 'group',
                direction: 'row',
                controls: _.mapValues(this._columns, function (column) { return ({
                    discriminator: 'control',
                    showTitle: true,
                    control: column.control,
                }); }),
            };
            Object.keys(this.filtersMetadata.controls)
                .forEach(function (key) {
                if (!_this.filtersMetadata.controls[key].control) {
                    delete _this.filtersMetadata.controls[key];
                }
            });
        };
        TableComponent.prototype.initGlobalSort = function () {
            this.dataSource.sort = this.matSort;
            this.dataSource.sortingDataAccessor = this.sortingDataAccessor;
        };
        TableComponent.prototype.initPagination = function () {
            this.matPaginator.pageIndex = this.pagination.pageIndex;
            this.matPaginator.pageSize = this.pagination.pageSize;
            this.matPaginator.pageSizeOptions = this.config.paginatorPageSizeOptions;
            if (this.hasPagination) {
                this.dataSource.paginator = this.matPaginator;
            }
        };
        TableComponent.prototype.initTextSearch = function () {
            var _this = this;
            this.subs$.push(this.textSearchControl.valueChanges.subscribe(function (text) {
                var e_4, _a;
                if (!_this.filtersValue) {
                    _this.filtersValue = {};
                }
                var searchFilter = {};
                try {
                    for (var _b = __values(_this.textSearchableColumns), _c = _b.next(); !_c.done; _c = _b.next()) {
                        var name = _c.value;
                        searchFilter[name] = text;
                    }
                }
                catch (e_4_1) { e_4 = { error: e_4_1 }; }
                finally {
                    try {
                        if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                    }
                    finally { if (e_4) throw e_4.error; }
                }
                _this.updateFilterValue(searchFilter);
                _this.dataSource.filter = JSON.stringify(_this.filtersValue);
            }));
        };
        TableComponent.prototype.setFilterPredicate = function () {
            var _this = this;
            this.filterPredicate = function (data) {
                if (!_this.activeFiltersPipe.transform(_this.filtersValue).length && !_this.textSearchControl.value) {
                    return true;
                }
                var res = [];
                _this.activeFiltersPipe.transform(_this.filtersValue).forEach(function (key) {
                    var index;
                    switch (true) {
                        case _this.textColumns.includes(key):
                            index = data[key].main;
                            break;
                        case _this.progressBarColumns.includes(key):
                            index = data[key].actual;
                            break;
                        default:
                            index = data[key];
                            break;
                    }
                    switch (_this._columns[key].control.discriminator) {
                        case 'selection-list':
                            res.push(_this.filtersValue[key].includes(index));
                            break;
                        case 'textbox':
                            res.push(index.includes(_this.filtersValue[key]));
                            break;
                        case 'dropdown':
                            res.push(index === _this.filtersValue[key]);
                            break;
                        case 'chip-list-autocomplete':
                            res.push(_this.filtersValue[key].includes(index));
                            break;
                        default:
                            break;
                    }
                });
                res.push(!!_this.filterRowByTextSearch(data));
                return res.every(function (elem) { return elem; });
            };
        };
        TableComponent.prototype.setParams = function () {
            this.checkActions();
            this.hasPagination = !!this.pagination;
            this.hasGlobalSort = !!this.globalSort;
            this.hasExpandedRow = !!this.expandedComponentRef;
            this.hasFilters = !!_.map(this._columns, 'control').filter(function (elem) { return elem; }).length ||
                !(this.filtersDialogRef.toString() === DefaultFiltersDialogComponent.toString());
            this.hasDisplayedColumnsUpdate = !!this.displayedColumnsUpdate.observers.length;
            this.hasCursorPointer = !!(this._actions[this.rowClickAction] && this.hasSingleActions);
            this.hasHeader = !!this.title || this.hasBulkActions || this.hasFilters ||
                this.hasDisplayedColumnsUpdate || this.hasHeaderButtons || this.textSearchEnabled;
        };
        TableComponent.prototype.setSortingDataAccessor = function () {
            var _this = this;
            this.sortingDataAccessor = function (data, property) {
                switch (true) {
                    case _this.textColumns.includes(property):
                        return data[property].main;
                    case _this.progressBarColumns.includes(property):
                        return data[property].actual;
                    default:
                        return data[property];
                }
            };
        };
        TableComponent.prototype.updateDataSource = function () {
            this.dataSource.data = this.service.parseData(this.data, this._columns, this._actions);
        };
        TableComponent.prototype.updateFilterValue = function (filters) {
            this.filtersValue = Object.assign(Object.assign({}, this.filtersValue), filters);
        };
        return TableComponent;
    }(mixinHasSubs(/** @class */ (function () {
        function class_1() {
        }
        return class_1;
    }()))));
    TableComponent.decorators = [
        { type: i0.Component, args: [{
                    // eslint-disable-next-line @angular-eslint/component-selector
                    selector: 'bd-table',
                    template: "<div *ngIf=\"hasHeader && !customHeader\" class=\"table-header\" fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n  <div class=\"title-wrapper\">\n    <span *ngIf=\"title\" class=\"mat-headline title-text\">{{translatePrefix + title | translate}}</span>\n\n    <ng-container *ngIf=\"hasBulkActions && bulkSelection.hasValue()\">\n        <span class=\"mat-small selected-from-text fade-in\">\n          {{bulkSelection.selected.length}}\n          {{config.globalTranslatePrefix + 'selected' | translate}}\n        </span>\n\n      <button (click)=\"toggleAll()\"\n              *ngIf=\"isCurrentPageSelected()\"\n              class=\"mat-button-with-transparent-background\"\n              color=\"primary\"\n              mat-button>\n        <ng-container *ngIf=\"isAllSelected(); else selectTextPlaceholder\">\n          {{'deselect-all' | translate}}\n        </ng-container>\n\n        <ng-template #selectTextPlaceholder>\n          {{'select-all' | translate}}\n        </ng-template>\n\n        {{dataSource.data.length}}\n\n        {{'rows-in-this-table' | translate}}\n      </button>\n    </ng-container>\n  </div>\n\n  <div *ngIf=\"textSearchEnabled\" class=\"text-search-container\">\n    <mat-form-field appearance=\"legacy\">\n      <mat-label>{{textSearchPlaceholder}}</mat-label>\n      <mat-icon matPrefix>search</mat-icon>\n      <input matInput [formControl]=\"textSearchControl\" [placeholder]=\"textSearchPlaceholder\">\n    </mat-form-field>\n  </div>\n\n  <div *ngIf=\"hasBulkActions && bulkSelection.hasValue(); else filtersAndDisplayColumnsButtons\"\n       class=\"fade-in\">\n    <ng-container *ngFor=\"let bulkAction of _bulkActions; let index = index; let last = last\">\n      <ng-container *ngIf=\"index >= 0 && index <= 2\">\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"_actions[bulkAction].custom && !config.actionIcons[bulkAction]\"\n                [matTooltip]=\"_actions[bulkAction].custom.label | translate\"\n                class=\"bulk-action-button\"\n                mat-icon-button>\n          <i [class]=\"_actions[bulkAction].custom.iconClass\"></i>\n        </button>\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"config.actionIcons[bulkAction] && !_actions[bulkAction].custom\"\n                [matTooltip]=\"config.actionIcons[bulkAction].label\"\n                class=\"bulk-action-button\"\n                mat-icon-button>\n          <i [class]=\"config.actionIcons[bulkAction].iconClass\"></i>\n        </button>\n      </ng-container>\n\n      <ng-container *ngIf=\" last && index > 2\">\n        <button [matMenuTriggerFor]=\"bulkActionsMenu\"\n                class=\"bulk-action-button\"\n                mat-icon-button>\n          <i [class]=\"config.globalIcons.actions\"></i>\n        </button>\n      </ng-container>\n    </ng-container>\n  </div>\n\n  <ng-template #filtersAndDisplayColumnsButtons>\n    <div class=\"fade-in\">\n      <ng-container *ngIf=\"(filtersValue | activeFilters) as activeFilters\">\n        <ng-container *ngIf=\"activeFilters.length\">\n          <span class=\"filtered-by-text mat-small\">{{config.globalTranslatePrefix + 'filtered-by' | translate}}:</span>\n          <mat-chip-list>\n            <mat-chip (removed)=\"removeFilter(filter)\"\n                      *ngFor=\"let filter of activeFilters\"\n                      [removable]=\"true\">\\\n              <span class=\"mat-small\">\n                    {{translatePrefix + filter | translate}}\n                  </span>\n              <i [class]=\"config.globalIcons.removeChip\" matChipRemove></i>\n            </mat-chip>\n          </mat-chip-list>\n        </ng-container>\n      </ng-container>\n\n      <button (click)=\"openFiltersDialog()\"\n              *ngIf=\"hasFilters\"\n              [matTooltip]=\"config.globalTranslatePrefix + 'filter' | translate\"\n              class=\"system-button\"\n              mat-stroked-button>\n        <i [class]=\"config.globalIcons.filter\"></i>\n        <span class=\"filter-label\">{{'filter' | translate}}</span>\n      </button>\n\n      <button (click)=\"openDisplayColumnsDialog()\"\n              *ngIf=\"hasDisplayedColumnsUpdate\"\n              [matTooltip]=\"config.globalTranslatePrefix + 'customize-columns' | translate\"\n              class=\"system-button\"\n              mat-stroked-button>\n        <i [class]=\"config.globalIcons.displayedColumns\"></i>\n      </button>\n\n      <!-- HEADER ACTIONS -->\n      <ng-container *ngFor=\"let action of _headerActions\">\n        <button (click)=\"emitHeaderActionRequest(action)\"\n                *bdDomElementValidator=\"_actions[action].role\"\n                class=\"system-button\" color=\"primary\"\n                mat-flat-button>\n          <i [class]=\"_actions[action].custom?.iconClass || config.actionIcons[action]?.iconClass\"></i>\n          <span\n                  class=\"action-label\">{{(_actions[action].custom?.label || config.actionIcons[action]?.label) | translate | uppercase}}</span>\n        </button>\n      </ng-container>\n    </div>\n  </ng-template>\n</div>\n\n<ng-content select=\"[bdTableHeader]\"></ng-content>\n\n<div class=\"mat-elevation-z1\">\n  <div class=\"table-wrapper\">\n    <table [dataSource]=\"dataSource\"\n           mat-table\n           matSort\n           multiTemplateDataRows>\n\n      <!-- BULK CHECKBOX COLUMN -->\n      <ng-container *ngIf=\"hasBulkActions\"\n                    [matColumnDef]=\"reservedNames.bulkCheckboxColumn\"\n                    [sticky]=\"true\">\n        <th *matHeaderCellDef\n            class=\"bulk-checkbox-row-header-cell\"\n            mat-header-cell>\n          <mat-checkbox #massBulkCheckbox\n                        (change)=\"$event && toggleCurrentPage()\"\n                        [checked]=\"bulkSelection.hasValue() && isCurrentPageSelected()\"\n                        [indeterminate]=\"bulkSelection.hasValue() && !isAllSelected()\"\n                        class=\"bulk-checkbox\"></mat-checkbox>\n        </th>\n\n        <td (shortPress)=\"$event.stopPropagation()\"\n            bdClicker\n            *matCellDef=\"let element\"\n            class=\"bulk-checkbox-row-cell\"\n            mat-cell>\n          <mat-checkbox (change)=\"$event && bulkSelection.toggle(element)\"\n                        [checked]=\"bulkSelection.isSelected(element)\"\n                        class=\"checkbox\"></mat-checkbox>\n        </td>\n      </ng-container>\n\n      <!-- EXPAND ARROW COLUMN -->\n      <ng-container *ngIf=\"hasExpandedRow\"\n                    [matColumnDef]=\"reservedNames.expandArrowColumn\"\n                    [sticky]=\"true\">\n        <th *matHeaderCellDef\n            class=\"expand-arrow-row-header-cell\"\n            mat-header-cell></th>\n\n        <td (click)=\"$event.stopPropagation()\"\n            *matCellDef=\"let element\"\n            class=\"expand-arrow-row-cell\"\n            mat-cell>\n            <span (click)=\"onExpandArrowClicked(element);$event.stopPropagation();\"\n                  [ngClass]=\"expandedElement && element === expandedElement ? 'expand-close' : 'expand-open'\"\n                  class=\"expand\">\n              <i [class]=\"config.globalIcons.expand\"></i>\n            </span>\n        </td>\n      </ng-container>\n\n      <!-- DATA COLUMNS -->\n      <ng-container *ngFor=\"let column of _columns | orderedKeyValue; let i=index\"\n                    [matColumnDef]=\"column.key\">\n        <th *matHeaderCellDef\n            [class.avatar-row-header-cell]=\"column.value['discriminator'] === 'AvatarColumn'\"\n            [class.progress-bar-row-header-cell]=\"column.value['discriminator'] === 'ProgressBarColumn'\"\n            [class.text-row-header-cell]=\"column.value['discriminator'] === 'TextColumn'\"\n            [disabled]=\"!globalSort || column.value['sortable'] === false || column.value['discriminator'] === 'AvatarColumn'\"\n            class=\"data-row-header-cell mat-subheading-1\"\n            mat-header-cell\n            mat-sort-header>\n          <ng-container *ngIf=\"column.value['discriminator'] !== 'AvatarColumn'\">\n            {{translatePrefix + column.key | translate}}\n          </ng-container>\n        </th>\n\n        <ng-container *ngIf=\"data\">\n          <td *matCellDef=\"let element\"\n              [class.avatar-row-cell]=\"column.value['discriminator'] === 'AvatarColumn'\"\n              [class.icon-row-cell]=\"column.value['discriminator'] === 'IconColumn'\"\n              [class.progress-bar-row-cell]=\"column.value['discriminator'] === 'ProgressBarColumn'\"\n              [class.text-row-cell]=\"column.value['discriminator'] === 'TextColumn'\"\n              [matTooltipDisabled]=\"column.value['discriminator'] !== 'ProgressBarColumn'\"\n              [matTooltip]=\"element[column.key] && element[column.key]['tooltip']\"\n              class=\"data-row-cell\"\n              mat-cell>\n            <ng-container *ngIf=\"customColumnTemplateRefs[column.key]; else notCustomColumnTemplate\">\n              <ng-container\n                      *ngTemplateOutlet=\"customColumnTemplateRefs[column.key]; context: {element:  data[element['originalIndex']], parsedElement: element}\"></ng-container>\n            </ng-container>\n\n            <ng-template #notCustomColumnTemplate>\n              <ng-container [ngSwitch]=\"column.value['discriminator']\">\n\n                <bd-avatar-column-cell *ngSwitchCase=\"'AvatarColumn'\"\n                                       [cellValue]=\"element[column.key]\"\n                                       [columnConfig]=\"column.value\">\n                </bd-avatar-column-cell>\n\n                <bd-date-column-cell *ngSwitchCase=\"'DateColumn'\"\n                                     [cellValue]=\"element[column.key]\"\n                                     [columnConfig]=\"column.value\">\n                </bd-date-column-cell>\n\n                <bd-icon-column-cell *ngSwitchCase=\"'IconColumn'\"\n                                     [cellValue]=\"element[column.key]\"\n                                     [columnConfig]=\"column.value\"\n                                     (actionRequest)=\"emitActionRequest($event, element['originalIndex'])\">\n                </bd-icon-column-cell>\n\n                <bd-progress-bar-column-cell *ngSwitchCase=\"'ProgressBarColumn'\"\n                                             [cellValue]=\"element[column.key]\"\n                                             [columnConfig]=\"column.value\">\n                </bd-progress-bar-column-cell>\n\n                <bd-text-column-cell *ngSwitchCase=\"'TextColumn'\"\n                                     [cellValue]=\"element[column.key]\"\n                                     [columnConfig]=\"column.value\">\n                </bd-text-column-cell>\n\n              </ng-container>\n            </ng-template>\n\n          </td>\n        </ng-container>\n      </ng-container>\n\n      <!-- EXPANDED ELEMENT COLUMN -->\n      <ng-container *ngIf=\"hasExpandedRow\"\n                    [matColumnDef]=\"reservedNames.expandedColumn\">\n        <td *matCellDef=\"let element; let index = dataIndex\"\n            [colSpan]=\"displayedColumns.length\"\n            class=\"expanded-element-row-cell\"\n            mat-cell>\n          <div [@detailExpand]=\"element == expandedElement ? 'expanded' : 'collapsed'\"\n               class=\"expanded-element-row-cell-element-detail\">\n            <div *ngIf=\"element == expandedElement\"\n                 class=\"expanded-element-row-cell-element-content\">\n              <ng-template\n                      *ngComponentOutlet=\"expandedComponentRef; injector: expandedComponentInjectors[index]\"></ng-template>\n            </div>\n          </div>\n        </td>\n      </ng-container>\n\n      <!-- ACTIONS COLUMN -->\n      <ng-container *ngIf=\"hasSingleActions\"\n                    [matColumnDef]=\"reservedNames.actionsColumn\"\n                    stickyEnd>\n        <th *matHeaderCellDef\n            class=\"actions-row-header-cell\"\n            mat-header-cell></th>\n\n        <td (shortPress)=\"$event.stopPropagation()\"\n            bdClicker\n            *matCellDef=\"let element\"\n            class=\"actions-row-cell\"\n            mat-cell>\n          <button #singleActionsMenuTrigger=\"matMenuTrigger\"\n                  *ngIf=\"element['singleActions'].length\"\n                  [class.menu-opened]=\"singleActionsMenuTrigger.menuOpen\"\n                  [matMenuTriggerData]=\"{element: element}\"\n                  [matMenuTriggerFor]=\"singleActionsMenu\"\n                  class=\"single-actions-button\"\n                  mat-icon-button>\n            <i [class]=\"config.globalIcons.actions\"></i>\n          </button>\n        </td>\n      </ng-container>\n\n      <!-- FINAL THINGS -->\n      <tr *matHeaderRowDef=\"displayedColumns\"\n          class=\"data-header-row\"\n          mat-header-row></tr>\n\n      <tr (shortPress)=\"onRowClicked(element);$event.stopPropagation()\"\n          bdClicker\n          *matRowDef=\"let element; let index = dataIndex; columns: displayedColumns;\"\n          [class.clickable]=\"hasCursorPointer\"\n          [class.selected]=\"bulkSelection.isSelected(element)\"\n          class=\"data-row\"\n          mat-row></tr>\n\n      <ng-container *ngIf=\"hasExpandedRow\">\n        <tr *matRowDef=\"let element; columns: [reservedNames.expandedColumn]\"\n            [class.active]=\"element === expandedElement\"\n            class=\"expanded-element-row\"\n            mat-row></tr>\n      </ng-container>\n\n    </table>\n  </div>\n\n  <mat-paginator [style.display]=\"hasPagination ? 'block' : 'none'\"></mat-paginator>\n</div>\n\n<mat-menu #singleActionsMenu=\"matMenu\">\n  <ng-template matMenuContent let-element=\"element\">\n    <ng-container *ngFor=\"let singleAction of element['singleActions']\">\n      <button (click)=\"emitActionRequest(singleAction, element['originalIndex'])\"\n              mat-menu-item>\n        <ng-container [ngSwitch]=\"true\">\n          <ng-container *ngSwitchCase=\"_actions[singleAction].custom && !config.actionIcons[singleAction]\">\n            <i [class]=\"_actions[singleAction].custom.iconClass\"></i>\n            <span class=\"action-label\">{{_actions[singleAction].custom.label | translate}}</span>\n          </ng-container>\n          <ng-container *ngSwitchCase=\"config.actionIcons[singleAction] && !_actions[singleAction].custom\">\n            <i [class]=\"config.actionIcons[singleAction].iconClass\"></i>\n            <span class=\"action-label\">{{config.actionIcons[singleAction].label | translate}}</span>\n          </ng-container>\n        </ng-container>\n      </button>\n    </ng-container>\n  </ng-template>\n</mat-menu>\n\n<mat-menu #bulkActionsMenu>\n  <ng-template matMenuContent>\n    <ng-container *ngFor=\"let bulkAction of _bulkActions; let index = index\">\n      <ng-container *ngIf=\"index > 2\">\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"actions[bulkAction].custom && !config.actionIcons[bulkAction]\"\n                [matTooltip]=\"actions[bulkAction].custom.label | translate\"\n                mat-menu-item>\n          <!--          <i [class]=\"_actions[bulkAction].custom.iconClass\"></i>-->\n          <span class=\"action-label\">{{actions[bulkAction].custom.label | translate}}</span>\n        </button>\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"config.actionIcons[bulkAction] && !actions[bulkAction].custom\"\n                [matTooltip]=\"config.actionIcons[bulkAction].label\"\n                mat-menu-item>\n          <!--          <i [class]=\"config.actionIcons[bulkAction].iconClass\"></i>-->\n          <span class=\"action-label\">{{config.actionIcons[bulkAction].label | translate}}</span>\n        </button>\n      </ng-container>\n    </ng-container>\n  </ng-template>\n</mat-menu>\n",
                    animations: [
                        EXPANDED_ROW_ANIMATION,
                    ],
                    providers: [
                        { provide: formField.MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: ɵ0 },
                        { provide: TABLE, useExisting: TableComponent },
                    ],
                    styles: ["@-webkit-keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}.fade-in{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:both;animation-fill-mode:both;-webkit-animation-name:fadeIn;animation-name:fadeIn}:host(.bd-lazy-table),:host(.bd-table){display:block;min-width:100%;padding:0}:host(.bd-lazy-table) .table-header,:host(.bd-table) .table-header{height:40px;margin-bottom:10px}:host(.bd-lazy-table) .table-header .title-wrapper,:host(.bd-table) .table-header .title-wrapper{height:100%;flex-grow:2}:host(.bd-lazy-table) .table-header .title-wrapper .title-text,:host(.bd-table) .table-header .title-wrapper .title-text{color:rgba(0,0,0,.87)}:host(.bd-lazy-table) .table-header .filtered-by-text,:host(.bd-lazy-table) .table-header .selected-from-text,:host(.bd-table) .table-header .filtered-by-text,:host(.bd-table) .table-header .selected-from-text{color:rgba(0,0,0,.54);margin-left:20px;font-weight:500}:host(.bd-lazy-table) .table-header .system-button,:host(.bd-table) .table-header .system-button{margin:0 5px;min-width:40px}:host(.bd-lazy-table) .table-header .system-button:last-of-type,:host(.bd-table) .table-header .system-button:last-of-type{margin-right:0}:host(.bd-lazy-table) .table-header .system-button.mat-stroked-button,:host(.bd-table) .table-header .system-button.mat-stroked-button{background-color:#fff}:host(.bd-lazy-table) .table-header .bulk-action-button,:host(.bd-table) .table-header .bulk-action-button{font-size:20px;color:rgba(0,0,0,.54)}:host(.bd-lazy-table) .table-header .filtered-by-text,:host(.bd-table) .table-header .filtered-by-text{margin-right:10px}:host(.bd-lazy-table) .table-header mat-chip-list,:host(.bd-table) .table-header mat-chip-list{display:inline-block}:host(.bd-lazy-table) .table-header mat-chip-list .mat-chip-remove,:host(.bd-table) .table-header mat-chip-list .mat-chip-remove{line-height:normal}:host(.bd-lazy-table) .table-header .text-search-container,:host(.bd-table) .table-header .text-search-container{margin-right:16px}:host(.bd-lazy-table) .table-header ::ng-deep .text-search-container .mat-form-field-wrapper,:host(.bd-table) .table-header ::ng-deep .text-search-container .mat-form-field-wrapper{position:relative;bottom:-6px}:host(.bd-lazy-table) .table-wrapper,:host(.bd-table) .table-wrapper{overflow:auto}:host(.bd-lazy-table) .table-wrapper .mat-table,:host(.bd-table) .table-wrapper .mat-table{overflow-x:scroll;min-width:100%;border-collapse:inherit}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell{font-weight:500;font-size:13px;color:#000;padding:0 10px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell ::ng-deep .mat-sort-header-button,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell ::ng-deep .mat-sort-header-button{text-align:left}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell,:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.expand-arrow-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.expand-arrow-row-header-cell{width:40px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell{text-align:center}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.progress-bar-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.progress-bar-row-header-cell{min-width:100px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.avatar-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.avatar-row-header-cell{width:40px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell:not(.avatar-row-header-cell),:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell:not(.avatar-row-header-cell){min-width:150px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.actions-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.actions-row-header-cell{text-align:right}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row,:host(.bd-table) .table-wrapper .mat-table .mat-row{transition:background-color .25s}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.data-row.clickable,:host(.bd-table) .table-wrapper .mat-table .mat-row.data-row.clickable{cursor:pointer}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.data-row.selected,:host(.bd-table) .table-wrapper .mat-table .mat-row.data-row.selected{background-color:#f6f6f6}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.expanded-element-row,:host(.bd-table) .table-wrapper .mat-table .mat-row.expanded-element-row{height:0}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.expanded-element-row.active+.data-row .mat-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row.expanded-element-row.active+.data-row .mat-cell{border-top:1px solid #e0e0e0}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row:hover,:host(.bd-table) .table-wrapper .mat-table .mat-row:hover{background-color:#f6f6f6}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.expand-arrow-row-cell .expand.expand-open,:host(.bd-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.expand-arrow-row-cell .expand.expand-open{opacity:1;color:rgba(0,0,0,.87)}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.actions-row-cell .single-actions-button,:host(.bd-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.actions-row-cell .single-actions-button{visibility:visible!important;transition:visibility .25s}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell{color:rgba(0,0,0,.87);font-size:13px;padding:0 10px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.bulk-checkbox-row-cell,:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.bulk-checkbox-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell{text-align:center}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand{display:inline-block;cursor:pointer;transition:all .25s}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-open,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-open{color:rgba(0,0,0,.54)}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-close,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-close{transform:rotate(180deg);color:rgba(0,0,0,.87)}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell{border-bottom-width:0!important}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail{overflow:hidden;display:flex}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail .expanded-element-row-cell-element-content,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail .expanded-element-row-cell-element-content{padding:10px;width:100%}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell{text-align:right}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell .single-actions-button:not(.menu-opened),:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell .single-actions-button:not(.menu-opened){visibility:hidden}.action-label{margin-left:10px}.filter-label{margin-left:5px}", ".gradient-strawberry{background-image:linear-gradient(45deg,#fe0b46,#ffab96)}.gradient-orange{background-image:linear-gradient(45deg,#c471f3,#f671cd)}.gradient-dawn{background-image:linear-gradient(45deg,#f3904f,#3b4371)}.gradient-shdow-night{background-image:linear-gradient(45deg,#000,#53346d)}.gradient-man-of-steel{background-image:linear-gradient(45deg,#780206,#061161)}.gradient-flickr{background-image:linear-gradient(45deg,#33001b,#ff0084)}.gradient-ibiza-sunset{background-image:linear-gradient(45deg,#ee0979,#ff6a00)}.gradient-politics{background-image:linear-gradient(45deg,#2196f3,#f44336)}", ""]
                },] }
    ];
    TableComponent.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [TABLE_CONFIG,] }] },
        { type: TableService },
        { type: ActionsConfigService },
        { type: i0.Injector },
        { type: dialog.MatDialog },
        { type: i0.ChangeDetectorRef },
        { type: ActiveFiltersPipe },
        { type: dynamicForm.DynamicFormService, decorators: [{ type: i0.Optional }] }
    ]; };
    TableComponent.propDecorators = {
        actions: [{ type: i0.Input }],
        additionalFiltersDialogData: [{ type: i0.Input }],
        columns: [{ type: i0.Input }],
        customColumnTemplateRefs: [{ type: i0.Input }],
        data: [{ type: i0.Input }],
        expandedComponentRef: [{ type: i0.Input }],
        filtersDialogRef: [{ type: i0.Input }],
        globalSort: [{ type: i0.Input }],
        pagination: [{ type: i0.Input }],
        rowClickAction: [{ type: i0.Input }],
        textSearchPlaceholder: [{ type: i0.Input }],
        title: [{ type: i0.Input }],
        translatePrefix: [{ type: i0.Input }],
        actionRequest: [{ type: i0.Output }],
        bulkActionRequest: [{ type: i0.Output }],
        displayedColumnsUpdate: [{ type: i0.Output }],
        massBulkCheckbox: [{ type: i0.ViewChild, args: ['massBulkCheckbox',] }],
        matPaginator: [{ type: i0.ViewChild, args: [paginator.MatPaginator,] }],
        matSort: [{ type: i0.ViewChild, args: [sort.MatSort,] }],
        tableHeader: [{ type: i0.ContentChild, args: [TableHeaderDirective,] }],
        componentClass: [{ type: i0.HostBinding, args: ['class.bd-table',] }]
    };

    var TableInitStatePlaceholderDirective = /** @class */ (function () {
        function TableInitStatePlaceholderDirective() {
        }
        return TableInitStatePlaceholderDirective;
    }());
    TableInitStatePlaceholderDirective.decorators = [
        { type: i0.Directive, args: [{
                    selector: '[bdTableInitStatePlaceholder]'
                },] }
    ];
    TableInitStatePlaceholderDirective.ctorParameters = function () { return []; };

    var TableNoResultPlaceholderDirective = /** @class */ (function () {
        function TableNoResultPlaceholderDirective() {
        }
        return TableNoResultPlaceholderDirective;
    }());
    TableNoResultPlaceholderDirective.decorators = [
        { type: i0.Directive, args: [{
                    selector: '[bdTableNoResultPlaceholder]'
                },] }
    ];
    TableNoResultPlaceholderDirective.ctorParameters = function () { return []; };

    var ShowTableModeEnum;
    (function (ShowTableModeEnum) {
        ShowTableModeEnum["SHOW_TABLE_DATA"] = "SHOW_TABLE_DATA";
        ShowTableModeEnum["INIT_PLACEHOLDER"] = "INIT_PLACEHOLDER";
        ShowTableModeEnum["NO_RESULT_PLACEHOLDER"] = "NO_RESULT_PLACEHOLDER";
    })(ShowTableModeEnum || (ShowTableModeEnum = {}));

    var TableLocalStorageEnum;
    (function (TableLocalStorageEnum) {
        TableLocalStorageEnum["REQUEST_PARAMS"] = "requestParams";
        TableLocalStorageEnum["PAGINATION"] = "pagination";
        TableLocalStorageEnum["SORT"] = "sort";
        TableLocalStorageEnum["COLUMNS_CONFIG"] = "columnsConfig";
    })(TableLocalStorageEnum || (TableLocalStorageEnum = {}));

    var ɵ0$1 = { appearance: 'standard' };
    // eslint-disable-next-line @typescript-eslint/ban-types
    var LazyTableComponent = /** @class */ (function (_super) {
        __extends(LazyTableComponent, _super);
        function LazyTableComponent(config, service, actionsConfigService, injector, dialog, cd) {
            var _this = _super.call(this) || this;
            _this.config = config;
            _this.service = service;
            _this.actionsConfigService = actionsConfigService;
            _this.injector = injector;
            _this.dialog = dialog;
            _this.cd = cd;
            _this.storedSettingsConfig = {
                filters: 'localStorage',
                columns: 'localStorage',
                pagination: null,
                sort: null,
            };
            _this.customColumnTemplateRefs = {};
            _this.filtersDialogConfig = {};
            _this.filtersDialogRef = DefaultFiltersDialogComponent;
            _this.globalSort = false;
            _this.openFilterOnInit = false;
            _this.pagination = {
                pageIndex: 0,
                pageSize: 25,
            };
            _this.rowClickAction = 'open';
            _this.textSearchEnabled = false;
            _this.textSearchPlaceholder = 'Search';
            _this.translatePrefix = '';
            _this.actionRequest = new i0.EventEmitter();
            _this.bulkActionRequest = new i0.EventEmitter();
            _this.displayedColumnsUpdate = new i0.EventEmitter();
            _this.filterRemove = new i0.EventEmitter();
            _this.paginationRequest = new i0.EventEmitter();
            _this.ShowTableMode = ShowTableModeEnum;
            _this.bulkSelection = new collections.SelectionModel(true, []);
            _this.dataNotSet = true;
            _this.reservedNames = exports.ReservedNamesV2;
            _this.showTableMode = ShowTableModeEnum.SHOW_TABLE_DATA;
            _this.textSearchControl = new forms.FormControl('');
            return _this;
        }
        Object.defineProperty(LazyTableComponent.prototype, "actions", {
            get: function () {
                return this.actionsConfigService.actions;
            },
            set: function (actions) {
                this.actionsConfigService.initActions(actions);
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(LazyTableComponent.prototype, "columns", {
            set: function (columns) {
                this._columns = this.service.fillColumnsConfigDefaults(columns);
                this.displayedColumns = Object.entries(this._columns)
                    .filter(function (_f) {
                    var _g = __read(_f, 2), key = _g[0], value = _g[1];
                    return !value.hidden;
                })
                    .map(function (_f) {
                    var _g = __read(_f, 2), key = _g[0], value = _g[1];
                    return key;
                });
            },
            enumerable: false,
            configurable: true
        });
        // LIFECYCLE HOOKS START
        LazyTableComponent.prototype.ngOnChanges = function (changes) {
            // need to exclude first change because setParams() need to be called first (in ngOnInit())
            var _a, _b, _c;
            if (changes.actions && !changes.actions.firstChange) {
                this.actionsConfigService.initFilterBulkActions();
            }
            if (changes.columns && !changes.columns.firstChange) {
                this.addSystemDisplayColumns();
            }
            if (changes.paginatedData) {
                this.bulkSelection.clear();
                if (!changes.paginatedData.firstChange) {
                    this.checkDataNotSet();
                    this.initDataSource();
                    this.matPaginator.length = this.paginatedData.totalItems;
                    this.matPaginator.pageIndex = this.pagination.pageIndex;
                    this.matPaginator.pageSize = this.pagination.pageSize;
                    if (this.bdTableId && ((_a = this.storedSettingsConfig) === null || _a === void 0 ? void 0 : _a.sort)) {
                        this.sort = this.getTableSettingsFromBrowserStorage(this.storedSettingsConfig.sort, TableLocalStorageEnum.SORT);
                    }
                    if (this.sort) {
                        this.matSort.active = this.sort.active;
                        this.matSort.direction = this.sort.direction;
                        this.dataSource.sort = this.matSort;
                        var activeSortHeader = this.matSort.sortables.get(this.sort.active);
                        // eslint-disable-next-line no-underscore-dangle
                        (_c = (_b = activeSortHeader)._setAnimationTransitionState) === null || _c === void 0 ? void 0 : _c.call(_b, {
                            toState: 'active',
                        });
                    }
                }
            }
        };
        LazyTableComponent.prototype.ngOnInit = function () {
            this.setParams();
            this.initDataSource();
            if (this.hasBulkActions) {
                this.actionsConfigService.initFilterBulkActions();
            }
            if (this.hasFilters) {
                this.initFilters();
            }
            this.openFiltersDialogOnInit();
            this.addSystemDisplayColumns();
        };
        LazyTableComponent.prototype.ngAfterContentInit = function () {
            if (this.initStatePlaceholder) {
                this.showTableMode = ShowTableModeEnum.INIT_PLACEHOLDER;
            }
            this.requestTableDataFromSource();
        };
        LazyTableComponent.prototype.ngAfterViewInit = function () {
            this.initPagination();
            this.initPaginatedRequestEmitting();
            this.customHeader = !!this.tableHeader;
            this.cd.detectChanges();
        };
        LazyTableComponent.prototype.ngOnDestroy = function () {
            if (this.filtersDialogInstance) {
                this.filtersDialogInstance.close();
            }
            this.clearSubscriptions();
        };
        LazyTableComponent.prototype.emitActionRequest = function (action, index) {
            var req = {
                action: action,
                data: this.paginatedData.list[index],
            };
            this.actionRequest.emit(req);
        };
        LazyTableComponent.prototype.emitBulkActionRequest = function (action) {
            var _this = this;
            var req = {
                action: action,
                data: this.paginatedData.list
                    .filter(function (elem, index) { return _this.bulkSelection.selected
                    .map(function (parsedElem) { return parsedElem.originalIndex; })
                    .includes(index); }),
            };
            this.bulkActionRequest.emit(req);
        };
        LazyTableComponent.prototype.emitHeaderActionRequest = function (action) {
            this.actionRequest.emit({ action: action, data: null });
        };
        LazyTableComponent.prototype.isAllSelected = function () {
            var _this = this;
            var res = true;
            this.dataSource.data
                .forEach(function (elem) {
                if (!_this.bulkSelection.isSelected(elem)) {
                    res = false;
                }
            });
            return res;
        };
        LazyTableComponent.prototype.onExpandArrowClicked = function (element) {
            this.expandedElement = this.expandedElement === element ? null : element;
        };
        LazyTableComponent.prototype.onRowClicked = function (element) {
            if (element.singleActions.includes(this.rowClickAction)) {
                this.emitActionRequest(this.rowClickAction, element.originalIndex);
            }
        };
        LazyTableComponent.prototype.openDisplayColumnsDialog = function () {
            var _this = this;
            var allColumns = Object.keys(this._columns);
            var currentDisplayColumns = this.displayedColumns.filter(function (elem) { return !enumToArray(exports.ReservedNamesV2).includes(elem); });
            var displayedColumnsDialogData = {
                translatePrefix: this.translatePrefix,
                displayedColumns: currentDisplayColumns
                    .map(function (elem) { return ({
                    name: elem,
                    isDisplayed: true,
                }); })
                    .concat(allColumns
                    .filter(function (elem) { return !currentDisplayColumns.includes(elem); })
                    .map(function (elem) { return ({
                    name: elem,
                    isDisplayed: false,
                }); })),
            };
            this.subs$.push(this.dialog.open(DisplayedColumnsDialogComponent, {
                data: displayedColumnsDialogData,
            }).afterClosed().pipe(operators.filter(function (res) { return !!res; })).subscribe(function (res) {
                var _a;
                _this.setTableSettingsFromBrowserStorage((_a = _this.storedSettingsConfig) === null || _a === void 0 ? void 0 : _a.columns, TableLocalStorageEnum.COLUMNS_CONFIG, res);
                _this.displayedColumnsUpdate.emit(res);
            }));
        };
        LazyTableComponent.prototype.openFiltersDialog = function () {
            var _this = this;
            this.filtersDialogInstance = this.dialog.open(this.filtersDialogRef, Object.assign(Object.assign({}, this.filtersDialogConfig), { data: {
                    initValue: this.filtersValue,
                    metadata: this.filtersMetadata,
                    additionalData: this.additionalFiltersDialogData,
                } }));
            this.subs$.push(this.filtersDialogInstance
                .afterClosed()
                .pipe(operators.filter(function (res) { return !!res; }))
                .subscribe(function (res) {
                var _a;
                _this.setTableSettingsFromBrowserStorage((_a = _this.storedSettingsConfig) === null || _a === void 0 ? void 0 : _a.filters, TableLocalStorageEnum.REQUEST_PARAMS, res);
                _this.filtersValue = res;
                _this.matPaginator.page.emit({
                    pageIndex: 0,
                    pageSize: _this.pagination.pageSize,
                    length: _this.paginatedData.totalItems,
                });
            }));
        };
        LazyTableComponent.prototype.removeFilter = function (control) {
            var _a;
            this.filtersValue = Object.entries(this.filtersValue).reduce(function (accumulator, _f) {
                var _g;
                var _h = __read(_f, 2), key = _h[0], value = _h[1];
                return key === control ? accumulator : Object.assign(Object.assign({}, accumulator), (_g = {}, _g[key] = value, _g));
            }, {});
            this.setTableSettingsFromBrowserStorage((_a = this.storedSettingsConfig) === null || _a === void 0 ? void 0 : _a.filters, TableLocalStorageEnum.REQUEST_PARAMS, this.filtersValue);
            this.matPaginator.page.emit({
                pageIndex: 0,
                pageSize: this.pagination.pageSize,
                length: this.paginatedData.totalItems,
            });
            this.filterRemove.emit(control);
        };
        LazyTableComponent.prototype.toggleAll = function () {
            var _f, _g;
            // eslint-disable-next-line @typescript-eslint/no-unused-expressions
            this.isAllSelected() ? (_f = this.bulkSelection).deselect.apply(_f, __spread(this.dataSource.data)) : (_g = this.bulkSelection).select.apply(_g, __spread(this.dataSource.data));
        };
        LazyTableComponent.prototype.addSystemDisplayColumns = function () {
            if (this.hasExpandedRow) {
                this.displayedColumns.unshift(exports.ReservedNamesV2.expandArrowColumn);
            }
            if (this.hasBulkActions) {
                this.displayedColumns.unshift(exports.ReservedNamesV2.bulkCheckboxColumn);
            }
            if (this.actionsConfigService.hasSingleActions) {
                this.displayedColumns.push(exports.ReservedNamesV2.actionsColumn);
            }
        };
        LazyTableComponent.prototype.checkDataNotSet = function () {
            if (this.paginatedData.totalItems === 0) {
                if (this.noResultPlaceholder) {
                    this.showTableMode = ShowTableModeEnum.NO_RESULT_PLACEHOLDER;
                }
                else {
                    this.showTableMode = ShowTableModeEnum.SHOW_TABLE_DATA;
                }
            }
            else {
                this.dataNotSet = false;
                this.showTableMode = ShowTableModeEnum.SHOW_TABLE_DATA;
            }
        };
        LazyTableComponent.prototype.getTableSettingsFromBrowserStorage = function (storage, storedSettings) {
            if (storage === 'localStorage') {
                return JSON.parse(localStorage.getItem(this.bdTableId + storedSettings));
            }
            if (storage === 'sessionStorage') {
                return JSON.parse(sessionStorage.getItem(this.bdTableId + storedSettings));
            }
            return;
        };
        LazyTableComponent.prototype.initDataSource = function () {
            this.dataSource = new table.MatTableDataSource(this.service.parseData(this.paginatedData.list, this._columns, this.actionsConfigService.actions));
            if (this.hasExpandedRow) {
                this.initExpandedComponentInjectors();
            }
        };
        LazyTableComponent.prototype.initExpandedComponentInjectors = function () {
            var _this = this;
            this.expandedComponentInjectors = this.paginatedData.list.map(function (elem) { return i0.Injector.create({
                providers: [
                    { provide: EXPANDED_ROW_DATA, useValue: elem },
                ],
                parent: _this.injector,
            }); });
        };
        LazyTableComponent.prototype.initFilters = function () {
            var _this = this;
            this.filtersMetadata = {
                discriminator: 'group',
                direction: 'row',
                controls: _.mapValues(this._columns, function (column) { return ({
                    discriminator: 'control',
                    showTitle: true,
                    control: column.control,
                }); }),
            };
            Object.keys(this.filtersMetadata.controls)
                .forEach(function (key) {
                if (!_this.filtersMetadata.controls[key].control) {
                    delete _this.filtersMetadata.controls[key];
                }
            });
        };
        LazyTableComponent.prototype.initPaginatedRequestEmitting = function () {
            var _this = this;
            this.subs$.push(this.matPaginator.page
                .subscribe(function (_f) {
                var pageIndex = _f.pageIndex, pageSize = _f.pageSize;
                var _a;
                var sort = _this.matSort.active && _this.matSort.direction !== '' ? {
                    active: _this.matSort.active,
                    direction: _this.matSort.direction,
                } : null;
                var pagination = { pageIndex: pageIndex, pageSize: pageSize };
                var textSearch = _this.textSearchControl.value ? _this.textSearchControl.value : null;
                _this.setTableSettingsFromBrowserStorage((_a = _this.storedSettingsConfig) === null || _a === void 0 ? void 0 : _a.pagination, TableLocalStorageEnum.PAGINATION, pagination);
                _this.paginationRequest.emit({ pagination: pagination, sort: sort, requestParams: _this.filtersValue, textSearch: textSearch });
            }), this.matSort.sortChange
                .subscribe(function (_f) {
                var active = _f.active, direction = _f.direction;
                var _a;
                var sort = active && direction !== '' ? { active: active, direction: direction } : null;
                var pagination = { pageIndex: _this.matPaginator.pageIndex, pageSize: _this.matPaginator.pageSize };
                var textSearch = _this.textSearchControl.value ? _this.textSearchControl.value : null;
                _this.setTableSettingsFromBrowserStorage((_a = _this.storedSettingsConfig) === null || _a === void 0 ? void 0 : _a.sort, TableLocalStorageEnum.SORT, sort);
                _this.paginationRequest.emit({ pagination: pagination, sort: sort, requestParams: _this.filtersValue, textSearch: textSearch });
            }), this.textSearchControl.valueChanges.pipe(operators.distinctUntilChanged(), operators.debounceTime(500)).subscribe(function () {
                _this.matPaginator.page.emit({
                    pageIndex: 0,
                    pageSize: _this.pagination.pageSize,
                    length: _this.paginatedData.totalItems,
                });
            }));
        };
        LazyTableComponent.prototype.initPagination = function () {
            var _a, _b;
            this.matPaginator.pageIndex = this.pagination.pageIndex;
            this.matPaginator.pageSize = this.pagination.pageSize;
            this.matPaginator.pageSizeOptions = this.config.paginatorPageSizeOptions;
            this.matPaginator.length = this.paginatedData.totalItems;
            if (this.sort) {
                this.matSort.active = this.sort.active;
                this.matSort.direction = this.sort.direction;
                this.dataSource.sort = this.matSort;
                var activeSortHeader = this.matSort.sortables.get(this.sort.active);
                // eslint-disable-next-line no-underscore-dangle
                (_b = (_a = activeSortHeader)._setAnimationTransitionState) === null || _b === void 0 ? void 0 : _b.call(_a, {
                    toState: 'active',
                });
            }
        };
        LazyTableComponent.prototype.openFiltersDialogOnInit = function () {
            if (this.openFilterOnInit) {
                this.openFiltersDialog();
                this.openFilterOnInit = false;
            }
        };
        LazyTableComponent.prototype.requestTableDataFromSource = function () {
            if (this.service.hasAnyActiveFilter(this.filtersValue) || !this.initStatePlaceholder) {
                this.paginationRequest.emit({ requestParams: this.filtersValue, pagination: this.pagination, sort: this.sort });
            }
        };
        LazyTableComponent.prototype.setParams = function () {
            var _a, _b, _c, _d, _e;
            if (this.bdTableId) {
                this.filtersValue = this.getTableSettingsFromBrowserStorage((_a = this.storedSettingsConfig) === null || _a === void 0 ? void 0 : _a.filters, TableLocalStorageEnum.REQUEST_PARAMS);
                this.pagination = (_c = this.getTableSettingsFromBrowserStorage((_b = this.storedSettingsConfig) === null || _b === void 0 ? void 0 : _b.pagination, TableLocalStorageEnum.PAGINATION)) !== null && _c !== void 0 ? _c : this.pagination;
                this.sort = this.getTableSettingsFromBrowserStorage((_d = this.storedSettingsConfig) === null || _d === void 0 ? void 0 : _d.sort, TableLocalStorageEnum.SORT);
                var columnsConfig = this.getTableSettingsFromBrowserStorage((_e = this.storedSettingsConfig) === null || _e === void 0 ? void 0 : _e.columns, TableLocalStorageEnum.COLUMNS_CONFIG);
                if (columnsConfig) {
                    this.displayedColumnsUpdate.emit(columnsConfig);
                }
            }
            this.actionsConfigService.checkActions(!!this.actionRequest.observers.length);
            this.hasBulkActions = this.actionsConfigService.hasBulkActions;
            this.hasPagination = !!this.pagination;
            this.hasGlobalSort = !!this.globalSort;
            this.hasExpandedRow = !!this.expandedComponentRef;
            this.hasFilters = !!_.map(this._columns, 'control').filter(function (elem) { return elem; }).length;
            this.hasDisplayedColumnsUpdate = !!this.displayedColumnsUpdate.observers.length;
            this.hasCursorPointer = !!(this.actionsConfigService.actions[this.rowClickAction] && this.actionsConfigService.hasSingleActions);
            this.hasHeader = !!this.title || this.hasBulkActions || this.hasFilters ||
                this.hasDisplayedColumnsUpdate || this.actionsConfigService.hasHeaderButtons || this.textSearchEnabled;
        };
        LazyTableComponent.prototype.setTableSettingsFromBrowserStorage = function (storage, storedSettings, value) {
            if (this.bdTableId && this.storedSettingsConfig) {
                if (storage === 'localStorage') {
                    localStorage.setItem(this.bdTableId + storedSettings, JSON.stringify(value));
                    return;
                }
                sessionStorage.setItem(this.bdTableId + storedSettings, JSON.stringify(value));
            }
        };
        return LazyTableComponent;
    }(mixinHasSubs(/** @class */ (function () {
        function class_1() {
        }
        return class_1;
    }()))));
    LazyTableComponent.decorators = [
        { type: i0.Component, args: [{
                    // eslint-disable-next-line @angular-eslint/component-selector
                    selector: 'bd-lazy-table',
                    template: "<div *ngIf=\"hasHeader &&\n!customHeader\" class=\"table-header\" fxLayout=\"row\" fxLayoutAlign=\"space-between center\">\n  <div class=\"title-wrapper\">\n    <span *ngIf=\"title\" class=\"mat-headline title-text\">{{translatePrefix + title | translate}}</span>\n\n    <ng-container *ngIf=\"hasBulkActions && bulkSelection.hasValue()\">\n      <span class=\"mat-small selected-from-text fade-in\">\n        {{bulkSelection.selected.length}}\n        {{config.globalTranslatePrefix + 'selected' | translate}}\n      </span>\n    </ng-container>\n  </div>\n\n  <div *ngIf=\"textSearchEnabled\" class=\"text-search-container\">\n    <mat-form-field appearance=\"legacy\">\n      <mat-label>{{textSearchPlaceholder}}</mat-label>\n      <mat-icon matPrefix>search</mat-icon>\n      <input matInput [formControl]=\"textSearchControl\" [placeholder]=\"textSearchPlaceholder\"\n             data-e2e=\"search-field\">\n    </mat-form-field>\n  </div>\n\n  <div *ngIf=\"hasBulkActions && bulkSelection.hasValue(); else filtersAndDisplayColumnsButtons\"\n       class=\"fade-in\">\n    <ng-container *ngFor=\"let bulkAction of actionsConfigService.bulkActions; let index = index; let last = last\">\n      <ng-container *ngIf=\"index >= 0 && index <= 2\">\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"actionsConfigService.actions[bulkAction].custom && !config.actionIcons[bulkAction]\"\n                [attr.data-e2e]=\"actionsConfigService.actions[bulkAction].custom.label\"\n                [matTooltip]=\"actionsConfigService.actions[bulkAction].custom.label | translate\"\n                class=\"bulk-action-button\"\n                mat-icon-button>\n          <i [class]=\"actionsConfigService.actions[bulkAction].custom.iconClass\"></i>\n        </button>\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"config.actionIcons[bulkAction] && !actionsConfigService.actions[bulkAction].custom\"\n                [matTooltip]=\"config.actionIcons[bulkAction].label\"\n                class=\"bulk-action-button\"\n                mat-icon-button>\n          <i [class]=\"config.actionIcons[bulkAction].iconClass\"></i>\n        </button>\n      </ng-container>\n\n      <ng-container *ngIf=\" last && index > 2\">\n        <button [matMenuTriggerFor]=\"bulkActionsMenu\"\n                class=\"bulk-action-button\"\n                mat-icon-button>\n          <i [class]=\"config.globalIcons.actions\"></i>\n        </button>\n      </ng-container>\n    </ng-container>\n  </div>\n\n  <ng-template #filtersAndDisplayColumnsButtons>\n    <div class=\"fade-in\">\n      <ng-container *ngIf=\"(filtersValue | activeFilters) as activeFilters\">\n        <ng-container *ngIf=\"activeFilters.length\">\n          <span class=\"filtered-by-text mat-small\">{{config.globalTranslatePrefix + 'filtered-by' | translate}}:</span>\n          <mat-chip-list>\n            <mat-chip (removed)=\"removeFilter(filter)\"\n                      *ngFor=\"let filter of activeFilters\"\n                      [removable]=\"true\">\n              <span class=\"mat-small\">\n<!--                <span [outerHTML]=\"config.globalIcons.activeChip\"></span>-->\n                {{translatePrefix + filter | translate}}\n              </span>\n              <i [class]=\"config.globalIcons.removeChip\" matChipRemove></i>\n            </mat-chip>\n          </mat-chip-list>\n        </ng-container>\n      </ng-container>\n\n      <button (click)=\"openFiltersDialog()\"\n              *ngIf=\"hasFilters\"\n              [matTooltip]=\"config.globalTranslatePrefix + 'filter' | translate\"\n              class=\"system-button\"\n              mat-stroked-button>\n        <i [class]=\"config.globalIcons.filter\"></i>\n        <span class=\"filter-label\">{{'filter' | translate}}</span>\n      </button>\n\n      <button (click)=\"openDisplayColumnsDialog()\"\n              *ngIf=\"hasDisplayedColumnsUpdate\"\n              [matTooltip]=\"config.globalTranslatePrefix + 'displayed-columns' | translate\"\n              class=\"system-button\"\n              mat-stroked-button>\n        <i [class]=\"config.globalIcons.displayedColumns\"></i>\n      </button>\n\n      <!-- HEADER ACTIONS -->\n      <ng-content select=\"[bdTableHeaderActions]\"></ng-content>\n\n      <ng-container *ngFor=\"let action of actionsConfigService.headerActions\">\n        <button (click)=\"emitHeaderActionRequest(action)\"\n                *bdDomElementValidator=\"actionsConfigService.actions[action].role\"\n                class=\"system-button\" color=\"primary\"\n                [attr.data-e2e]=\"action\"\n                mat-flat-button>\n          <i [class]=\"actionsConfigService.actions[action].custom?.iconClass || config.actionIcons[action]?.iconClass\"></i>\n          <span\n                  class=\"action-label\">{{(actionsConfigService.actions[action].custom?.label || config.actionIcons[action]?.label) | translate | uppercase}}</span>\n        </button>\n      </ng-container>\n    </div>\n  </ng-template>\n</div>\n<ng-content select=\"[bdTableHeader]\"></ng-content>\n\n<ng-content *ngIf = \"showTableMode === ShowTableMode.INIT_PLACEHOLDER\" select=\"[bdTableInitStatePlaceholder]\"></ng-content>\n<ng-content *ngIf = \"showTableMode === ShowTableMode.NO_RESULT_PLACEHOLDER\" select=\"[bdTableNoResultPlaceholder]\"></ng-content>\n\n<div\n        class=\"mat-elevation-z1\">\n  <div class=\"table-wrapper\">\n    <table [dataSource]=\"dataSource\"\n           mat-table\n           matSort\n           multiTemplateDataRows\n           [hidden]=\"showTableMode !== ShowTableMode.SHOW_TABLE_DATA\"\n    >\n\n      <!-- BULK CHECKBOX COLUMN -->\n      <ng-container\n              *ngIf=\"hasBulkActions\"\n              [matColumnDef]=\"reservedNames.bulkCheckboxColumn\"\n              [sticky]=\"true\">\n        <th *matHeaderCellDef\n            class=\"bulk-checkbox-row-header-cell\"\n            mat-header-cell>\n          <mat-checkbox #massBulkCheckbox\n                        (change)=\"$event && toggleAll()\"\n                        [checked]=\"bulkSelection.hasValue() && isAllSelected()\"\n                        [indeterminate]=\"bulkSelection.hasValue() && !isAllSelected()\"\n                        class=\"bulk-checkbox\"></mat-checkbox>\n        </th>\n\n        <td (shortPress)=\"$event.stopPropagation()\"\n            bdClicker\n            *matCellDef=\"let element\"\n            class=\"bulk-checkbox-row-cell\"\n            mat-cell>\n          <mat-checkbox (change)=\"$event && bulkSelection.toggle(element)\"\n                        [checked]=\"bulkSelection.isSelected(element)\"\n                        class=\"checkbox\"></mat-checkbox>\n        </td>\n      </ng-container>\n\n      <!-- EXPAND ARROW COLUMN -->\n      <ng-container *ngIf=\"hasExpandedRow\"\n                    [matColumnDef]=\"reservedNames.expandArrowColumn\"\n                    [sticky]=\"true\">\n        <th *matHeaderCellDef\n            class=\"expand-arrow-row-header-cell\"\n            mat-header-cell></th>\n\n        <td (click)=\"$event.stopPropagation()\"\n            *matCellDef=\"let element\"\n            class=\"expand-arrow-row-cell\"\n            mat-cell>\n        <span (click)=\"onExpandArrowClicked(element);$event.stopPropagation();\"\n              [ngClass]=\"expandedElement && element === expandedElement ? 'expand-close' : 'expand-open'\"\n              class=\"expand\">\n          <i [class]=\"config.globalIcons.expand\"></i>\n        </span>\n        </td>\n      </ng-container>\n\n      <!-- DATA COLUMNS -->\n      <ng-container *ngFor=\"let column of _columns | orderedKeyValue; let i=index\"\n                    [matColumnDef]=\"column.key\">\n        <th *matHeaderCellDef\n            [class.avatar-row-header-cell]=\"column.value['discriminator'] === 'AvatarColumn'\"\n            [class.progress-bar-row-header-cell]=\"column.value['discriminator'] === 'ProgressBarColumn'\"\n            [class.text-row-header-cell]=\"column.value['discriminator'] === 'TextColumn'\"\n            [class.text-row-sub-header-cell]=\"column.value['subHeaderKey']?.length\"\n            [disabled]=\"!globalSort || !column.value['sortable'] || column.value['discriminator'] === 'AvatarColumn'\"\n            class=\"data-row-header-cell mat-subheading-1\"\n            mat-header-cell\n            mat-sort-header>\n          <ng-container *ngIf=\"column.value['discriminator'] !== 'AvatarColumn'\">\n            {{translatePrefix + column.key | translate}}\n\n            <ng-container *ngIf=\"column.value['subHeaderKey']\">\n              <span class=\"sub-header\">\n                {{translatePrefix + column.value['subHeaderKey'] | translate}}\n              </span>\n            </ng-container>\n          </ng-container>\n        </th>\n\n        <ng-container *ngIf=\"paginatedData && paginatedData.list\">\n          <td *matCellDef=\"let element\"\n              [class.avatar-row-cell]=\"column.value['discriminator'] === 'AvatarColumn'\"\n              [class.icon-row-cell]=\"column.value['discriminator'] === 'IconColumn'\"\n              [class.progress-bar-row-cell]=\"column.value['discriminator'] === 'ProgressBarColumn'\"\n              [class.text-row-cell]=\"column.value['discriminator'] === 'TextColumn'\"\n              class=\"data-row-header-cell mat-subheading-1\"\n              mat-cell>\n            <ng-container *ngIf=\"customColumnTemplateRefs[column.key]; else notCustomColumnTemplate\">\n              <ng-container\n                      *ngTemplateOutlet=\"customColumnTemplateRefs[column.key]; context: {element:  paginatedData.list[element['originalIndex']], parsedElement: element, column: column}\"></ng-container>\n            </ng-container>\n\n            <ng-template #notCustomColumnTemplate>\n              <ng-container [ngSwitch]=\"column.value['discriminator']\">\n\n                <bd-avatar-column-cell *ngSwitchCase=\"'AvatarColumn'\"\n                                       [cellValue]=\"element[column.key]\"\n                                       [columnConfig]=\"column.value\">\n                </bd-avatar-column-cell>\n\n                <bd-date-column-cell *ngSwitchCase=\"'DateColumn'\"\n                                     [cellValue]=\"element[column.key]\"\n                                     [columnConfig]=\"column.value\">\n                </bd-date-column-cell>\n\n                <bd-icon-column-cell *ngSwitchCase=\"'IconColumn'\"\n                                     [cellValue]=\"element[column.key]\"\n                                     [columnConfig]=\"column.value\"\n                                     (actionRequest)=\"emitActionRequest($event, element['originalIndex'])\">\n                </bd-icon-column-cell>\n\n                <bd-progress-bar-column-cell *ngSwitchCase=\"'ProgressBarColumn'\"\n                                             [cellValue]=\"element[column.key]\"\n                                             [columnConfig]=\"column.value\">\n                </bd-progress-bar-column-cell>\n\n                <bd-text-column-cell *ngSwitchCase=\"'TextColumn'\"\n                                     [cellValue]=\"element[column.key]\"\n                                     [columnConfig]=\"column.value\">\n                </bd-text-column-cell>\n\n              </ng-container>\n            </ng-template>\n          </td>\n        </ng-container>\n      </ng-container>\n\n      <!-- EXPANDED ELEMENT COLUMN -->\n      <ng-container *ngIf=\"hasExpandedRow\"\n                    [matColumnDef]=\"reservedNames.expandedColumn\">\n        <td *matCellDef=\"let element; let index = dataIndex\"\n            [colSpan]=\"displayedColumns.length\"\n            class=\"expanded-element-row-cell\"\n            mat-cell>\n          <div [@detailExpand]=\"element == expandedElement ? 'expanded' : 'collapsed'\"\n               class=\"expanded-element-row-cell-element-detail\">\n            <div *ngIf=\"element == expandedElement\"\n                 class=\"expanded-element-row-cell-element-content\">\n              <ng-template\n                      *ngComponentOutlet=\"expandedComponentRef; injector: expandedComponentInjectors[index]\"></ng-template>\n            </div>\n          </div>\n        </td>\n      </ng-container>\n\n      <!-- ACTIONS COLUMN -->\n      <ng-container *ngIf=\"actionsConfigService.hasSingleActions\"\n                    [matColumnDef]=\"reservedNames.actionsColumn\"\n                    stickyEnd>\n        <th *matHeaderCellDef\n            class=\"actions-row-header-cell\"\n            mat-header-cell></th>\n\n        <td (shortPress)=\"$event.stopPropagation()\"\n            bdClicker\n            *matCellDef=\"let element\"\n            class=\"actions-row-cell\"\n            mat-cell>\n          <button #singleActionsMenuTrigger=\"matMenuTrigger\"\n                  *ngIf=\"element['singleActions'].length\"\n                  [attr.data-e2e]=\"'single-action-button'\"\n                  [class.menu-opened]=\"singleActionsMenuTrigger.menuOpen\"\n                  [matMenuTriggerData]=\"{element: element}\"\n                  [matMenuTriggerFor]=\"singleActionsMenu\"\n                  class=\"single-actions-button\"\n                  mat-icon-button>\n            <i [class]=\"config.globalIcons.actions\"></i>\n          </button>\n        </td>\n      </ng-container>\n\n      <!-- FINAL THINGS -->\n      <tr *matHeaderRowDef=\"displayedColumns\"\n          class=\"data-header-row\"\n          mat-header-row></tr>\n\n      <tr (shortPress)=\"onRowClicked(element);$event.stopPropagation()\"\n          bdClicker\n          *matRowDef=\"let element; let index = dataIndex; columns: displayedColumns;\"\n          [class.clickable]=\"hasCursorPointer\"\n          [class.selected]=\"bulkSelection.isSelected(element)\"\n          class=\"data-row\"\n          mat-row></tr>\n\n      <ng-container *ngIf=\"hasExpandedRow\">\n        <tr *matRowDef=\"let element; columns: [reservedNames.expandedColumn]\"\n            [class.active]=\"element === expandedElement\"\n            class=\"expanded-element-row\"\n            mat-row></tr>\n      </ng-container>\n\n    </table>\n  </div>\n  <div\n          [hidden]=\"showTableMode !== ShowTableMode.SHOW_TABLE_DATA\">\n    <mat-paginator></mat-paginator>\n  </div>\n</div>\n\n<mat-menu #singleActionsMenu=\"matMenu\">\n  <ng-template matMenuContent let-element=\"element\">\n    <ng-container *ngFor=\"let singleAction of element['singleActions']\">\n      <button (click)=\"emitActionRequest(singleAction, element['originalIndex'])\"\n              [attr.data-e2e]=\"singleAction\"\n              mat-menu-item>\n        <ng-container [ngSwitch]=\"true\">\n          <ng-container *ngSwitchCase=\"actionsConfigService.actions[singleAction].custom && !config.actionIcons[singleAction]\">\n            <i [class]=\"actionsConfigService.actions[singleAction].custom.iconClass\"></i>\n            <span class=\"action-label\">{{actionsConfigService.actions[singleAction].custom.label | translate}}</span>\n          </ng-container>\n          <ng-container *ngSwitchCase=\"config.actionIcons[singleAction] && !actionsConfigService.actions[singleAction].custom\">\n            <i [class]=\"config.actionIcons[singleAction].iconClass\"></i>\n            <span class=\"action-label\">{{config.actionIcons[singleAction].label | translate}}</span>\n          </ng-container>\n        </ng-container>\n      </button>\n    </ng-container>\n  </ng-template>\n</mat-menu>\n\n<mat-menu #bulkActionsMenu>\n  <ng-template matMenuContent>\n    <ng-container *ngFor=\"let bulkAction of actionsConfigService.bulkActions; let index = index\">\n      <ng-container *ngIf=\"index > 2\">\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"actionsConfigService.actions[bulkAction].custom && !config.actionIcons[bulkAction]\"\n                [attr.data-e2e]=\"bulkAction\"\n                [matTooltip]=\"actionsConfigService.actions[bulkAction].custom.label | translate\"\n                mat-menu-item>\n          <!--          <i [class]=\"_actions[bulkAction].custom.iconClass\"></i>-->\n          <span class=\"action-label\">{{actionsConfigService.actions[bulkAction].custom.label | translate}}</span>\n        </button>\n        <button (click)=\"emitBulkActionRequest(bulkAction)\"\n                *ngIf=\"config.actionIcons[bulkAction] && !actionsConfigService.actions[bulkAction].custom\"\n                [attr.data-e2e]=\"bulkAction\"\n                [matTooltip]=\"config.actionIcons[bulkAction].label\"\n                mat-menu-item>\n          <!--          <i [class]=\"config.actionIcons[bulkAction].iconClass\"></i>-->\n          <span class=\"action-label\">{{config.actionIcons[bulkAction].label | translate}}</span>\n        </button>\n      </ng-container>\n    </ng-container>\n  </ng-template>\n</mat-menu>\n",
                    animations: [
                        EXPANDED_ROW_ANIMATION,
                    ],
                    providers: [
                        ActionsConfigService,
                        { provide: formField.MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: ɵ0$1 },
                        { provide: TABLE, useExisting: LazyTableComponent },
                    ],
                    host: {
                        '[class.bd-lazy-table]': 'true',
                    },
                    changeDetection: i0.ChangeDetectionStrategy.OnPush,
                    styles: ["@-webkit-keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}.fade-in{-webkit-animation-duration:1s;animation-duration:1s;-webkit-animation-fill-mode:both;animation-fill-mode:both;-webkit-animation-name:fadeIn;animation-name:fadeIn}:host(.bd-lazy-table),:host(.bd-table){display:block;min-width:100%;padding:0}:host(.bd-lazy-table) .table-header,:host(.bd-table) .table-header{height:40px;margin-bottom:10px}:host(.bd-lazy-table) .table-header .title-wrapper,:host(.bd-table) .table-header .title-wrapper{height:100%;flex-grow:2}:host(.bd-lazy-table) .table-header .title-wrapper .title-text,:host(.bd-table) .table-header .title-wrapper .title-text{color:rgba(0,0,0,.87)}:host(.bd-lazy-table) .table-header .filtered-by-text,:host(.bd-lazy-table) .table-header .selected-from-text,:host(.bd-table) .table-header .filtered-by-text,:host(.bd-table) .table-header .selected-from-text{color:rgba(0,0,0,.54);margin-left:20px;font-weight:500}:host(.bd-lazy-table) .table-header .system-button,:host(.bd-table) .table-header .system-button{margin:0 5px;min-width:40px}:host(.bd-lazy-table) .table-header .system-button:last-of-type,:host(.bd-table) .table-header .system-button:last-of-type{margin-right:0}:host(.bd-lazy-table) .table-header .system-button.mat-stroked-button,:host(.bd-table) .table-header .system-button.mat-stroked-button{background-color:#fff}:host(.bd-lazy-table) .table-header .bulk-action-button,:host(.bd-table) .table-header .bulk-action-button{font-size:20px;color:rgba(0,0,0,.54)}:host(.bd-lazy-table) .table-header .filtered-by-text,:host(.bd-table) .table-header .filtered-by-text{margin-right:10px}:host(.bd-lazy-table) .table-header mat-chip-list,:host(.bd-table) .table-header mat-chip-list{display:inline-block}:host(.bd-lazy-table) .table-header mat-chip-list .mat-chip-remove,:host(.bd-table) .table-header mat-chip-list .mat-chip-remove{line-height:normal}:host(.bd-lazy-table) .table-header .text-search-container,:host(.bd-table) .table-header .text-search-container{margin-right:16px}:host(.bd-lazy-table) .table-header ::ng-deep .text-search-container .mat-form-field-wrapper,:host(.bd-table) .table-header ::ng-deep .text-search-container .mat-form-field-wrapper{position:relative;bottom:-6px}:host(.bd-lazy-table) .table-wrapper,:host(.bd-table) .table-wrapper{overflow:auto}:host(.bd-lazy-table) .table-wrapper .mat-table,:host(.bd-table) .table-wrapper .mat-table{overflow-x:scroll;min-width:100%;border-collapse:inherit}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell{font-weight:500;font-size:13px;color:#000;padding:0 10px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell ::ng-deep .mat-sort-header-button,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell ::ng-deep .mat-sort-header-button{text-align:left}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell,:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.expand-arrow-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.expand-arrow-row-header-cell{width:40px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.bulk-checkbox-row-header-cell{text-align:center}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.progress-bar-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.progress-bar-row-header-cell{min-width:100px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.avatar-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell.avatar-row-header-cell{width:40px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell:not(.avatar-row-header-cell),:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.data-row-header-cell:not(.avatar-row-header-cell){min-width:150px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.actions-row-header-cell,:host(.bd-table) .table-wrapper .mat-table .mat-header-row .mat-header-cell.actions-row-header-cell{text-align:right}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row,:host(.bd-table) .table-wrapper .mat-table .mat-row{transition:background-color .25s}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.data-row.clickable,:host(.bd-table) .table-wrapper .mat-table .mat-row.data-row.clickable{cursor:pointer}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.data-row.selected,:host(.bd-table) .table-wrapper .mat-table .mat-row.data-row.selected{background-color:#f6f6f6}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.expanded-element-row,:host(.bd-table) .table-wrapper .mat-table .mat-row.expanded-element-row{height:0}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row.expanded-element-row.active+.data-row .mat-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row.expanded-element-row.active+.data-row .mat-cell{border-top:1px solid #e0e0e0}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row:hover,:host(.bd-table) .table-wrapper .mat-table .mat-row:hover{background-color:#f6f6f6}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.expand-arrow-row-cell .expand.expand-open,:host(.bd-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.expand-arrow-row-cell .expand.expand-open{opacity:1;color:rgba(0,0,0,.87)}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.actions-row-cell .single-actions-button,:host(.bd-table) .table-wrapper .mat-table .mat-row:hover .mat-cell.actions-row-cell .single-actions-button{visibility:visible!important;transition:visibility .25s}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell{color:rgba(0,0,0,.87);font-size:13px;padding:0 10px}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.bulk-checkbox-row-cell,:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.bulk-checkbox-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell{text-align:center}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand{display:inline-block;cursor:pointer;transition:all .25s}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-open,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-open{color:rgba(0,0,0,.54)}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-close,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expand-arrow-row-cell .expand.expand-close{transform:rotate(180deg);color:rgba(0,0,0,.87)}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell{border-bottom-width:0!important}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail{overflow:hidden;display:flex}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail .expanded-element-row-cell-element-content,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.expanded-element-row-cell .expanded-element-row-cell-element-detail .expanded-element-row-cell-element-content{padding:10px;width:100%}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell,:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell{text-align:right}:host(.bd-lazy-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell .single-actions-button:not(.menu-opened),:host(.bd-table) .table-wrapper .mat-table .mat-row .mat-cell.actions-row-cell .single-actions-button:not(.menu-opened){visibility:hidden}.action-label{margin-left:10px}.filter-label{margin-left:5px}", ".gradient-strawberry{background-image:linear-gradient(45deg,#fe0b46,#ffab96)}.gradient-orange{background-image:linear-gradient(45deg,#c471f3,#f671cd)}.gradient-dawn{background-image:linear-gradient(45deg,#f3904f,#3b4371)}.gradient-shdow-night{background-image:linear-gradient(45deg,#000,#53346d)}.gradient-man-of-steel{background-image:linear-gradient(45deg,#780206,#061161)}.gradient-flickr{background-image:linear-gradient(45deg,#33001b,#ff0084)}.gradient-ibiza-sunset{background-image:linear-gradient(45deg,#ee0979,#ff6a00)}.gradient-politics{background-image:linear-gradient(45deg,#2196f3,#f44336)}", ""]
                },] }
    ];
    LazyTableComponent.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [TABLE_CONFIG,] }] },
        { type: TableService },
        { type: ActionsConfigService },
        { type: i0.Injector },
        { type: dialog.MatDialog },
        { type: i0.ChangeDetectorRef }
    ]; };
    LazyTableComponent.propDecorators = {
        actions: [{ type: i0.Input }],
        additionalFiltersDialogData: [{ type: i0.Input }],
        bdTableId: [{ type: i0.Input }],
        storedSettingsConfig: [{ type: i0.Input }],
        columns: [{ type: i0.Input }],
        customColumnTemplateRefs: [{ type: i0.Input }],
        expandedComponentRef: [{ type: i0.Input }],
        filtersDialogConfig: [{ type: i0.Input }],
        filtersDialogRef: [{ type: i0.Input }],
        filtersValue: [{ type: i0.Input }],
        globalSort: [{ type: i0.Input }],
        openFilterOnInit: [{ type: i0.Input }],
        paginatedData: [{ type: i0.Input }],
        pagination: [{ type: i0.Input }],
        rowClickAction: [{ type: i0.Input }],
        sort: [{ type: i0.Input }],
        textSearchEnabled: [{ type: i0.Input }],
        textSearchPlaceholder: [{ type: i0.Input }],
        title: [{ type: i0.Input }],
        translatePrefix: [{ type: i0.Input }],
        actionRequest: [{ type: i0.Output }],
        bulkActionRequest: [{ type: i0.Output }],
        displayedColumnsUpdate: [{ type: i0.Output }],
        filterRemove: [{ type: i0.Output }],
        paginationRequest: [{ type: i0.Output }],
        massBulkCheckbox: [{ type: i0.ViewChild, args: ['massBulkCheckbox',] }],
        matPaginator: [{ type: i0.ViewChild, args: [paginator.MatPaginator,] }],
        matSort: [{ type: i0.ViewChild, args: [sort.MatSort,] }],
        initStatePlaceholder: [{ type: i0.ContentChild, args: [TableInitStatePlaceholderDirective,] }],
        noResultPlaceholder: [{ type: i0.ContentChild, args: [TableNoResultPlaceholderDirective,] }],
        tableHeader: [{ type: i0.ContentChild, args: [TableHeaderDirective,] }]
    };

    // TODO cover with tests
    var ToIconPipe = /** @class */ (function () {
        function ToIconPipe() {
        }
        ToIconPipe.prototype.transform = function (value, icons) {
            if (value === null || undefined) {
                return null;
            }
            var res = icons.find(function (icon) { return _.isEqual(icon.case, value); }) || icons.find(function (icon) { return icon.case === '__default__'; });
            return res ? res.icon : null;
        };
        return ToIconPipe;
    }());
    ToIconPipe.decorators = [
        { type: i0.Pipe, args: [{
                    name: 'toIcon'
                },] }
    ];

    var ToIconModule = /** @class */ (function () {
        function ToIconModule() {
        }
        return ToIconModule;
    }());
    ToIconModule.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [ToIconPipe],
                    exports: [ToIconPipe]
                },] }
    ];

    var ToLabelPipe = /** @class */ (function () {
        function ToLabelPipe() {
        }
        ToLabelPipe.prototype.transform = function (value, icons) {
            if (value === null || undefined) {
                return null;
            }
            var res = icons.find(function (icon) { return _.isEqual(icon.case, value); });
            return res ? res.label : null;
        };
        return ToLabelPipe;
    }());
    ToLabelPipe.decorators = [
        { type: i0.Pipe, args: [{
                    name: 'toLabel'
                },] }
    ];

    var ToLabelModule = /** @class */ (function () {
        function ToLabelModule() {
        }
        return ToLabelModule;
    }());
    ToLabelModule.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [ToLabelPipe],
                    exports: [
                        ToLabelPipe
                    ],
                    imports: [
                        common.CommonModule
                    ]
                },] }
    ];

    var BdPaginatorIntl = /** @class */ (function (_super) {
        __extends(BdPaginatorIntl, _super);
        function BdPaginatorIntl(translate) {
            var _this = _super.call(this) || this;
            _this.translate = translate;
            _this.getAndInitTranslations();
            return _this;
        }
        BdPaginatorIntl.prototype.getAndInitTranslations = function () {
            var _this = this;
            this.translate.get(['rows-per-page', 'next-page', 'previous-page']).pipe(operators.take(1)).subscribe(function (res) {
                _this.itemsPerPageLabel = res['rows-per-page'] + ':';
                _this.nextPageLabel = res['next-page'];
                _this.previousPageLabel = res['previous-page'];
                _this.changes.next();
            });
        };
        return BdPaginatorIntl;
    }(paginator.MatPaginatorIntl));
    BdPaginatorIntl.ɵprov = i0.ɵɵdefineInjectable({ factory: function BdPaginatorIntl_Factory() { return new BdPaginatorIntl(i0.ɵɵinject(i1.TranslateService)); }, token: BdPaginatorIntl, providedIn: "root" });
    BdPaginatorIntl.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    BdPaginatorIntl.ctorParameters = function () { return [
        { type: i1.TranslateService }
    ]; };

    var TextColumnCellComponent = /** @class */ (function () {
        function TextColumnCellComponent(config) {
            this.config = config;
        }
        return TextColumnCellComponent;
    }());
    TextColumnCellComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'bd-text-column-cell',
                    template: "<div>{{cellValue.main | nullOrUndefinedHandler:config.nullOrUndefinedPipePlaceholder }}</div>\n<div *ngIf=\"columnConfig.subPath\"\n     class=\"text-column-sub-text\">\n  {{cellValue.sub | nullOrUndefinedHandler:config.nullOrUndefinedPipePlaceholder }}\n</div>\n",
                    styles: [".text-column-sub-text{font-size:11px;color:rgba(0,0,0,.54)}"]
                },] }
    ];
    TextColumnCellComponent.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [TABLE_CONFIG,] }] }
    ]; };
    TextColumnCellComponent.propDecorators = {
        cellValue: [{ type: i0.Input }],
        columnConfig: [{ type: i0.Input }]
    };

    var AvatarColumnCellComponent = /** @class */ (function () {
        function AvatarColumnCellComponent(config) {
            this.config = config;
        }
        return AvatarColumnCellComponent;
    }());
    AvatarColumnCellComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'bd-avatar-column-cell',
                    template: "<span bdRandomClass class='avatar-wrapper'>\n  <span>{{cellValue | firstLetter | nullOrUndefinedHandler:{placeholder: '?'} }}</span>\n</span>\n",
                    styles: [".avatar-wrapper{width:40px;height:40px;border-radius:50%;display:table-cell!important;vertical-align:middle;text-align:center}.avatar-wrapper span{font-weight:600;color:#e1e1e1;text-align:center}"]
                },] }
    ];
    AvatarColumnCellComponent.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [TABLE_CONFIG,] }] }
    ]; };
    AvatarColumnCellComponent.propDecorators = {
        cellValue: [{ type: i0.Input }],
        columnConfig: [{ type: i0.Input }]
    };

    var DateColumnCellComponent = /** @class */ (function () {
        function DateColumnCellComponent(config) {
            this.config = config;
        }
        return DateColumnCellComponent;
    }());
    DateColumnCellComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'bd-date-column-cell',
                    template: "<ng-container *ngIf=\"columnConfig.timeAgo; else notTimeAgo\">\n  {{cellValue | timeAgo | nullOrUndefinedHandler:config.nullOrUndefinedPipePlaceholder }}\n</ng-container>\n<ng-template #notTimeAgo>\n  {{cellValue | bdDate:columnConfig.format | nullOrUndefinedHandler:config.nullOrUndefinedPipePlaceholder }}\n</ng-template>\n",
                    styles: [""]
                },] }
    ];
    DateColumnCellComponent.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [TABLE_CONFIG,] }] }
    ]; };
    DateColumnCellComponent.propDecorators = {
        columnConfig: [{ type: i0.Input }],
        cellValue: [{ type: i0.Input }]
    };

    var IconColumnCellComponent = /** @class */ (function () {
        function IconColumnCellComponent(config) {
            this.config = config;
            this.actionRequest = new i0.EventEmitter();
        }
        return IconColumnCellComponent;
    }());
    IconColumnCellComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'bd-icon-column-cell',
                    template: "<i (shortPress)=\"columnConfig.action && actionRequest.emit(columnConfig.action)\"\n   [class.icon-offset]=\"columnConfig.withLabel\"\n   [class]=\"cellValue | toIcon:columnConfig.icons\"\n   bdClicker></i>\n<ng-container *ngIf=\"columnConfig.withLabel\">\n  {{cellValue | toLabel:columnConfig.icons | nullOrUndefinedHandler:config.nullOrUndefinedPipePlaceholder}}\n</ng-container>\n",
                    styles: [".icon-offset{margin-right:5px}"]
                },] }
    ];
    IconColumnCellComponent.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [TABLE_CONFIG,] }] }
    ]; };
    IconColumnCellComponent.propDecorators = {
        cellValue: [{ type: i0.Input }],
        columnConfig: [{ type: i0.Input }],
        actionRequest: [{ type: i0.Output }]
    };

    var ProgressBarColumnCellComponent = /** @class */ (function () {
        function ProgressBarColumnCellComponent(config) {
            this.config = config;
        }
        return ProgressBarColumnCellComponent;
    }());
    ProgressBarColumnCellComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'bd-progress-bar-column-cell',
                    template: "<mat-progress-bar *ngIf=\"cellValue.actual && cellValue.max; else noProgressBarDataTmpl\"\n                  [class]=\"cellValue.klass\"\n                  [value]=\"cellValue.ratio\"\n                  mode=\"determinate\"></mat-progress-bar>\n\n<ng-template #noProgressBarDataTmpl>\n  {{config.nullOrUndefinedPipePlaceholder}}\n</ng-template>\n",
                    styles: [""]
                },] }
    ];
    ProgressBarColumnCellComponent.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: i0.Inject, args: [TABLE_CONFIG,] }] }
    ]; };
    ProgressBarColumnCellComponent.propDecorators = {
        cellValue: [{ type: i0.Input }],
        columnConfig: [{ type: i0.Input }]
    };

    var ActiveFiltersModule = /** @class */ (function () {
        function ActiveFiltersModule() {
        }
        return ActiveFiltersModule;
    }());
    ActiveFiltersModule.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [ActiveFiltersPipe],
                    imports: [
                        common.CommonModule
                    ],
                    exports: [ActiveFiltersPipe]
                },] }
    ];

    var TableHeaderModule = /** @class */ (function () {
        function TableHeaderModule() {
        }
        return TableHeaderModule;
    }());
    TableHeaderModule.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [
                        TableHeaderDirective,
                        TableInitStatePlaceholderDirective,
                        TableNoResultPlaceholderDirective,
                    ],
                    imports: [
                        common.CommonModule,
                    ],
                    exports: [
                        TableHeaderDirective,
                        TableInitStatePlaceholderDirective,
                        TableNoResultPlaceholderDirective,
                    ],
                },] }
    ];

    var TableModule = /** @class */ (function () {
        function TableModule() {
        }
        TableModule.forRoot = function (moduleConfig) {
            return {
                ngModule: TableModule,
                providers: [
                    TableService,
                    ActiveFiltersPipe,
                    { provide: TABLE_CONFIG, useValue: moduleConfig },
                    { provide: paginator.MatPaginatorIntl, useClass: BdPaginatorIntl }
                ]
            };
        };
        return TableModule;
    }());
    TableModule.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [
                        TableComponent,
                        LazyTableComponent,
                        DefaultFiltersDialogComponent,
                        DisplayedColumnsDialogComponent,
                        TextColumnCellComponent,
                        AvatarColumnCellComponent,
                        DateColumnCellComponent,
                        IconColumnCellComponent,
                        ProgressBarColumnCellComponent,
                    ],
                    entryComponents: [
                        DefaultFiltersDialogComponent,
                        DisplayedColumnsDialogComponent
                    ],
                    imports: [
                        common.CommonModule,
                        forms.FormsModule,
                        dragDrop.DragDropModule,
                        flexLayout.FlexLayoutModule,
                        tooltip.MatTooltipModule,
                        formField.MatFormFieldModule,
                        input.MatInputModule,
                        table.MatTableModule,
                        sort.MatSortModule,
                        paginator.MatPaginatorModule,
                        button.MatButtonModule,
                        menu.MatMenuModule,
                        icon.MatIconModule,
                        checkbox.MatCheckboxModule,
                        progressBar.MatProgressBarModule,
                        dialog.MatDialogModule,
                        card.MatCardModule,
                        i1.TranslateModule,
                        pipeCollection.TimeAgoPipeModule,
                        pipeCollection.RandomGradientPipeModule,
                        pipeCollection.NullOrUndefinedHandlerPipeModule,
                        pipeCollection.SliceWithDotsPipeModule,
                        ToIconModule,
                        pipeCollection.BdDatePipeModule,
                        pipeCollection.OrderedKeyValuePipeModule,
                        pipeCollection.FirstLetterPipeModule,
                        i1$1.RandomClassDirectiveModule,
                        dynamicForm.DynamicFormModule,
                        chips.MatChipsModule,
                        ToLabelModule,
                        i1$1.ClickerDirectiveModule,
                        i1$1.DomElementValidatorDirectiveModule,
                        TableHeaderModule,
                        forms.ReactiveFormsModule,
                        ActiveFiltersModule,
                    ],
                    exports: [
                        TableComponent,
                        LazyTableComponent
                    ]
                },] }
    ];

    /*
     * Public API Surface of dynamic-tables
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.AvatarColumn = AvatarColumn;
    exports.DateColumn = DateColumn;
    exports.EXPANDED_ROW_DATA = EXPANDED_ROW_DATA;
    exports.FiltersDialogComponent = FiltersDialogComponent;
    exports.IconColumn = IconColumn;
    exports.LazyTableComponent = LazyTableComponent;
    exports.MatDynamicTableComponent = MatDynamicTableComponent;
    exports.MatDynamicTableModule = MatDynamicTableModule;
    exports.TABLE = TABLE;
    exports.TABLE_CONFIG = TABLE_CONFIG;
    exports.TableComponent = TableComponent;
    exports.TableModule = TableModule;
    exports.TextColumn = TextColumn;
    exports.UuidColumn = UuidColumn;
    exports.instanceOfAvatarColumnInterface = instanceOfAvatarColumnInterface;
    exports.instanceOfDateColumnInterface = instanceOfDateColumnInterface;
    exports.instanceOfIconColumnInterface = instanceOfIconColumnInterface;
    exports.instanceOfProgressBarColumnInterface = instanceOfProgressBarColumnInterface;
    exports.instanceOfTextColumnInterface = instanceOfTextColumnInterface;
    exports.ɵ0 = ɵ0;
    exports.ɵa = BaseColumn;
    exports.ɵb = DYNAMIC_TABLE_MODULE_CONFIG;
    exports.ɵba = TableHeaderModule;
    exports.ɵbb = ActiveFiltersModule;
    exports.ɵbc = BdPaginatorIntl;
    exports.ɵc = MatDynamicTableService;
    exports.ɵd = ActionMicroPipesModule;
    exports.ɵe = SimpleOrConditionalActionPipe;
    exports.ɵf = CheckActionConditionPipe;
    exports.ɵg = EXPANDED_ROW_ANIMATION;
    exports.ɵh = TableHeaderDirective;
    exports.ɵi = TableService;
    exports.ɵj = ActionsConfigService;
    exports.ɵk = ActiveFiltersPipe;
    exports.ɵl = TableInitStatePlaceholderDirective;
    exports.ɵm = TableNoResultPlaceholderDirective;
    exports.ɵn = DefaultFiltersDialogComponent;
    exports.ɵp = DisplayedColumnsDialogComponent;
    exports.ɵr = TextColumnCellComponent;
    exports.ɵs = AvatarColumnCellComponent;
    exports.ɵt = DateColumnCellComponent;
    exports.ɵu = IconColumnCellComponent;
    exports.ɵv = ProgressBarColumnCellComponent;
    exports.ɵw = ToIconModule;
    exports.ɵx = ToIconPipe;
    exports.ɵy = ToLabelModule;
    exports.ɵz = ToLabelPipe;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=bd-innovations-dynamic-tables.umd.js.map
