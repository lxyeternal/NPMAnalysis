import { BaseColumn, BaseColumnConfig } from './base.column';
export declare class DateColumn extends BaseColumn {
    path: any;
    _columnType: string;
    format: string;
    timeAgo: boolean;
    constructor(path: any, config?: DateColumnConfig);
    get(element: any): any;
}
export interface DateColumnConfig extends BaseColumnConfig {
    format?: string;
    timeAgo?: boolean;
}
