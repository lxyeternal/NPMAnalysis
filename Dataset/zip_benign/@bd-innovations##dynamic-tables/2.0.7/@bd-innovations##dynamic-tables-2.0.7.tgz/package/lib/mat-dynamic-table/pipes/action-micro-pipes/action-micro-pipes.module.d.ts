export declare class ActionMicroPipesModule {
}
