import { PipeTransform } from '@angular/core';
import { ConditionalActionConfig } from '../../../configs/conditional-action.config';
export declare class SimpleOrConditionalActionPipe implements PipeTransform {
    transform(value: string | ConditionalActionConfig<any>): 'simple' | 'conditional';
}
