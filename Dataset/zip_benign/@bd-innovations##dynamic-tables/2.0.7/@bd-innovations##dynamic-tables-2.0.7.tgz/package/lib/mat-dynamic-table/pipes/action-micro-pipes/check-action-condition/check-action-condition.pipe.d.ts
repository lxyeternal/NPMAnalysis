import { PipeTransform } from '@angular/core';
export declare class CheckActionConditionPipe<T> implements PipeTransform {
    transform(element: T, callback: (element: T) => boolean): boolean;
}
