import { BaseColumn } from './base.column';
export declare class AvatarColumn extends BaseColumn {
    _columnType: string;
    constructor(paths: string | string[]);
    get(element: any): string;
}
