export declare enum ReservedNamesEnum {
    searchRow = "bdReservedNameForSearchRow",
    expandedRow = "bdReservedNameForExpandedRow",
    actionsColumn = "bdReservedNameForActionsColumn",
    serviceColumn = "bdReservedNameForServiceColumn"
}
