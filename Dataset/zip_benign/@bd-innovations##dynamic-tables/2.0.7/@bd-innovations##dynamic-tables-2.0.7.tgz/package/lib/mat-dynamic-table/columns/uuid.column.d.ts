import { TextColumn } from './text.column';
import { BaseColumnConfig } from './base.column';
export declare class UuidColumn extends TextColumn {
    _columnType: string;
    array: any[];
    pathInArray: string | string[];
    primaryKeyInArray: any;
    limit: number;
    constructor(uuId: string, config: UuidColumnConfig);
    get(element: any): string;
}
export interface UuidColumnConfig extends BaseColumnConfig {
    array: any[];
    pathInArray: string | string[];
    primaryKeyInArray: string;
    limit?: number;
}
