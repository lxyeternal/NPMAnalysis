import { ModuleWithProviders } from '@angular/core';
import { ModuleConfig } from './configs/module.config';
export declare class MatDynamicTableModule {
    static forRoot(moduleConfig: ModuleConfig): ModuleWithProviders<MatDynamicTableModule>;
    static forChild(moduleConfig: ModuleConfig): ModuleWithProviders<MatDynamicTableModule>;
}
