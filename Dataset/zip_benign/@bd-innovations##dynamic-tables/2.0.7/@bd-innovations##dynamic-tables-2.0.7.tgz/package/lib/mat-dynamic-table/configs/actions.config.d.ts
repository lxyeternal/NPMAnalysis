import { ConditionalActionConfig } from './conditional-action.config';
export declare type ActionsConfig<T> = Array<string | ConditionalActionConfig<T>>;
