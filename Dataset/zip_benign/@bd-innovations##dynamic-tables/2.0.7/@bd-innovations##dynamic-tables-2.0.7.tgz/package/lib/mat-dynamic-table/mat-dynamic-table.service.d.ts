import { InjectionToken } from '@angular/core';
import { ModuleConfig } from './configs/module.config';
import { ColumnsConfig } from './configs/columns.config';
import { ParsedObjectModel } from './models/parsed-object.model';
export declare const DYNAMIC_TABLE_MODULE_CONFIG: InjectionToken<ModuleConfig>;
export declare class MatDynamicTableService<T> {
    config: ModuleConfig;
    constructor(config: ModuleConfig);
    getParsedData(data: T[], columns: ColumnsConfig): ParsedObjectModel<T>[];
}
