export declare abstract class BaseColumn {
    paths: string | string[];
    config: BaseColumnConfig;
    abstract _columnType: string;
    /**
     * @param paths declare property/ies of object to display (using the same syntax of "_.at" method)
     * @param mask declare some mask to use for displayed data
     * @param config ''
     */
    protected constructor(paths: string | string[], config?: BaseColumnConfig);
    get(element: any): any;
}
export interface BaseColumnConfig {
    sortable?: boolean;
}
