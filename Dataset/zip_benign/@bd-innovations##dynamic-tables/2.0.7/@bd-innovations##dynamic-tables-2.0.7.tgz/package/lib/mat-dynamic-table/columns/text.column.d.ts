import { BaseColumn, BaseColumnConfig } from './base.column';
export declare class TextColumn extends BaseColumn {
    _columnType: string;
    limit: number;
    translate: string;
    separator: string | string[];
    mask: Mask;
    constructor(paths: string | string[], config?: TextColumnConfig);
    get(element: any): string;
}
export interface TextColumnConfig extends BaseColumnConfig {
    limit?: number;
    translate?: string;
    separator?: string | string[];
    mask?: Mask;
}
export declare type Mask = (element: any) => any;
