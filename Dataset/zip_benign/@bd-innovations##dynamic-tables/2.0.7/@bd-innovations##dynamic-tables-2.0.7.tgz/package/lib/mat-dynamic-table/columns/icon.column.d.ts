import { BaseColumn, BaseColumnConfig } from './base.column';
import { Icon } from '@bd-innovations/pipe-collection';
export declare class IconColumn extends BaseColumn {
    path: string;
    _columnType: string;
    icons: Icon[];
    action: string;
    constructor(path: string, config: IconColumnConfig);
    get(element: any): string;
}
export interface IconColumnConfig extends BaseColumnConfig {
    icons: Icon[];
    action?: string;
}
