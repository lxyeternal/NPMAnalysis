export declare enum TableLocalStorageEnum {
    REQUEST_PARAMS = "requestParams",
    PAGINATION = "pagination",
    SORT = "sort",
    COLUMNS_CONFIG = "columnsConfig"
}
