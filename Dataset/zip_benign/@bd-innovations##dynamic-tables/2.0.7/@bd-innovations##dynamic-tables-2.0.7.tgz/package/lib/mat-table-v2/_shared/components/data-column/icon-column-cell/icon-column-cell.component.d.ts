import { EventEmitter } from '@angular/core';
import { BaseColumnCellComponent } from '../base-column-cell/base-column-cell.component';
import { IconColumnInterface, IconColumnValue } from './icon-column.interface';
import { ModuleV2Config } from '../../../configs/module-v2.config';
export declare class IconColumnCellComponent implements BaseColumnCellComponent<IconColumnValue> {
    config: ModuleV2Config;
    cellValue: IconColumnValue;
    columnConfig: IconColumnInterface;
    actionRequest: EventEmitter<string>;
    constructor(config: ModuleV2Config);
}
