export declare class TableNoResultPlaceholderDirective {
    constructor();
}
