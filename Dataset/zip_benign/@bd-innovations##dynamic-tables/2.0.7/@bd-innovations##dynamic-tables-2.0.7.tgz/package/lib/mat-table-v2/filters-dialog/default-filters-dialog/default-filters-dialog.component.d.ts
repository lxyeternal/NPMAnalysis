import { OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { DynamicFormService } from '@bd-innovations/dynamic-form';
import { FiltersDialogDataModel } from '../filters-dialog-data.model';
import { MatDialogRef } from '@angular/material/dialog';
import { FiltersDialogComponent } from '../filters-dialog.component';
export declare class DefaultFiltersDialogComponent extends FiltersDialogComponent implements OnInit {
    data: FiltersDialogDataModel;
    protected dialogRef: MatDialogRef<DefaultFiltersDialogComponent>;
    private dynamicFormService?;
    form: FormGroup;
    constructor(data: FiltersDialogDataModel, dialogRef: MatDialogRef<DefaultFiltersDialogComponent>, dynamicFormService?: DynamicFormService);
    ngOnInit(): void;
    resetAndClose(): void;
}
