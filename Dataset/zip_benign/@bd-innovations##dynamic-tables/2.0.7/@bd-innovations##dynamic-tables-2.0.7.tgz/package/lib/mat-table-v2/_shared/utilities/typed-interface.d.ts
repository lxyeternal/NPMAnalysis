export interface TypedInterface {
    discriminator: string;
}
