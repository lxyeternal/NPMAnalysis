export declare class TableInitStatePlaceholderDirective {
    constructor();
}
