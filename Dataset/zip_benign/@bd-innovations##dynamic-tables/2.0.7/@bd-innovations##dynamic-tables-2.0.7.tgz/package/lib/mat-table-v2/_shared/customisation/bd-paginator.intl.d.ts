import { MatPaginatorIntl } from '@angular/material/paginator';
import { TranslateService } from '@ngx-translate/core';
export declare class BdPaginatorIntl extends MatPaginatorIntl {
    private readonly translate;
    constructor(translate: TranslateService);
    getAndInitTranslations(): void;
}
