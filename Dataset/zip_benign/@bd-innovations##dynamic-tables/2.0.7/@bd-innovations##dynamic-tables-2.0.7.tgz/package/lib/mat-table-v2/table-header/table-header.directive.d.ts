export declare class TableHeaderDirective {
}
