export declare function enumToArray<T>(enumRef: any): T[];
