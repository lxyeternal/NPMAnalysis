import { PipeTransform } from '@angular/core';
import { Icon } from '../../components/data-column/icon-column-cell/icon-column.interface';
export declare class ToLabelPipe implements PipeTransform {
    transform(value: any, icons: Icon[]): string;
}
