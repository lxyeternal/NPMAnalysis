import { ModuleWithProviders } from '@angular/core';
import { ModuleV2Config } from './_shared/configs/module-v2.config';
export declare class TableModule {
    static forRoot(moduleConfig: ModuleV2Config): ModuleWithProviders<TableModule>;
}
