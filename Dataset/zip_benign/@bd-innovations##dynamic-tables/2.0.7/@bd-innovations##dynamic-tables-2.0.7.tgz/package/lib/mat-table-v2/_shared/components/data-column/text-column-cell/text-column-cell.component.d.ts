import { ModuleV2Config } from '../../../configs/module-v2.config';
import { TextColumnInterface, TextColumnValue } from './text-column.interface';
import { BaseColumnCellComponent } from '../base-column-cell/base-column-cell.component';
export declare class TextColumnCellComponent implements BaseColumnCellComponent<TextColumnValue> {
    config: ModuleV2Config;
    cellValue: TextColumnValue;
    columnConfig: TextColumnInterface;
    constructor(config: ModuleV2Config);
}
