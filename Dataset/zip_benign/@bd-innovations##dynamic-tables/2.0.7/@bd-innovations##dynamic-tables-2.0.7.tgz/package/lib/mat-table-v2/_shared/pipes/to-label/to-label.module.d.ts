export declare class ToLabelModule {
}
