import { Subscription } from 'rxjs';
import { Constructor } from '@angular/material/core/common-behaviors/constructor';
export interface HasSubs {
    subs$: Subscription[];
    clearSubscriptions(): void;
}
export declare type HasSubsCtor = Constructor<HasSubs>;
export declare function mixinHasSubs<B extends Constructor<{}>>(base: B): HasSubsCtor & B;
