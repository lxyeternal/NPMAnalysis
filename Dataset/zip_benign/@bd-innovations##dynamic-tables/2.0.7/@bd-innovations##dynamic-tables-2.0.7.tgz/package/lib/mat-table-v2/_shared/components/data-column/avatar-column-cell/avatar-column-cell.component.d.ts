import { BaseColumnCellComponent } from '../base-column-cell/base-column-cell.component';
import { AvatarColumnInterface, AvatarColumnValue } from './avatar-column.interface';
import { ModuleV2Config } from '../../../configs/module-v2.config';
export declare class AvatarColumnCellComponent implements BaseColumnCellComponent<AvatarColumnValue> {
    config: ModuleV2Config;
    cellValue: AvatarColumnValue;
    columnConfig: AvatarColumnInterface;
    constructor(config: ModuleV2Config);
}
