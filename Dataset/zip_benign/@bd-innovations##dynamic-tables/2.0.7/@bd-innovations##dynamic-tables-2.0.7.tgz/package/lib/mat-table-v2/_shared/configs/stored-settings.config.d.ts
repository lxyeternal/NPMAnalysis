export interface StoredSettingsConfig {
    filters: StorageType;
    columns: StorageType;
    pagination: StorageType;
    sort: StorageType;
}
export declare type StorageType = 'localStorage' | 'sessionStorage' | null;
