import { BaseColumnCellComponent } from '../base-column-cell/base-column-cell.component';
import { DateColumnInterface, DateColumnValue } from './date-column.interface';
import { ModuleV2Config } from '../../../configs/module-v2.config';
export declare class DateColumnCellComponent implements BaseColumnCellComponent<DateColumnValue> {
    config: ModuleV2Config;
    columnConfig: DateColumnInterface;
    cellValue: DateColumnValue;
    constructor(config: ModuleV2Config);
}
