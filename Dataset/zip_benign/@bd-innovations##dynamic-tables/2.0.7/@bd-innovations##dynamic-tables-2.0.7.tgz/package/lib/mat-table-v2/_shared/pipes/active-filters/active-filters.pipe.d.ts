import { PipeTransform } from '@angular/core';
export declare class ActiveFiltersPipe implements PipeTransform {
    transform(value: object): string[];
    private getActiveFilters;
    private hasActiveFilter;
}
