import { DomElementValidatorService } from '@bd-innovations/directive-collection';
import { ActionsV2Config } from './_shared/configs/actions-v2.config';
import { ColumnsV2Config } from './_shared/configs/columns-v2.config';
import { ParsedObjectConfig } from './_shared/configs/parsed-object.config';
import { ActionsConfigService } from './actions-config-service/actions-config.service';
export declare class TableService<T extends object> {
    private readonly actionsConfigService;
    private readonly domElementValidatorService?;
    constructor(actionsConfigService: ActionsConfigService<T>, domElementValidatorService?: DomElementValidatorService);
    fillColumnsConfigDefaults(columnsConfig: ColumnsV2Config): ColumnsV2Config;
    hasAnyActiveFilter(requestParams: Record<string, any>): boolean;
    parseData(data: T[], columns: ColumnsV2Config, actions: ActionsV2Config<T>): ParsedObjectConfig<T>[];
    private checkMultipleRole;
    private defineParsedElemDataProperties;
    private defineParsedElemSystemProperties;
    private fillAvatarColumnDefaults;
    private fillBaseColumnDefaults;
    private fillDateColumnDefaults;
    private fillIconColumnDefaults;
    private fillProgressBarColumnDefaults;
    private fillTextColumnDefaults;
    private parseAvatarColumn;
    private parseBaseColumn;
    private parseDateColumn;
    private parseIconColumn;
    private parseProgressBarColumn;
    private parseTextColumn;
}
