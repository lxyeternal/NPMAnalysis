import { InjectionToken } from '@angular/core';
import { ModuleV2Config } from '../configs/module-v2.config';
export declare const EXPANDED_ROW_DATA: InjectionToken<any>;
export declare const TABLE_CONFIG: InjectionToken<ModuleV2Config>;
export declare const TABLE: InjectionToken<object>;
