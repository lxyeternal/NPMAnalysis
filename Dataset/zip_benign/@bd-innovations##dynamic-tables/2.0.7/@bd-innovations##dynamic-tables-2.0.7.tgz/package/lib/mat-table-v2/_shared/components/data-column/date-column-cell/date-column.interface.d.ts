import { BaseColumnInterface } from '../base-column-cell/base-column.interface';
export interface DateColumnInterface extends BaseColumnInterface {
    discriminator: 'DateColumn';
    paths: string;
    format?: string;
    timeAgo?: boolean;
}
export declare type DateColumnValue = any;
export declare function instanceOfDateColumnInterface(object: any): object is DateColumnInterface;
