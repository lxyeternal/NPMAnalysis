export declare class ToIconModule {
}
