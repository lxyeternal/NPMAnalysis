import { FormGroup } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
export declare abstract class FiltersDialogComponent {
    protected dialogRef: MatDialogRef<FiltersDialogComponent>;
    form: FormGroup;
    protected constructor(dialogRef: MatDialogRef<FiltersDialogComponent>);
    resetAndClose(): void;
}
