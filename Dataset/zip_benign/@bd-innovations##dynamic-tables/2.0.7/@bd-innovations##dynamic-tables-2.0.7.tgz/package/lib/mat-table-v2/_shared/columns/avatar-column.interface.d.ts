import { BaseColumnInterface } from './base-column.interface';
export interface AvatarColumnInterface extends BaseColumnInterface {
    discriminator: 'AvatarColumn';
    separator?: string | string[];
}
export declare function instanceOfAvatarColumnInterface(object: any): object is AvatarColumnInterface;
