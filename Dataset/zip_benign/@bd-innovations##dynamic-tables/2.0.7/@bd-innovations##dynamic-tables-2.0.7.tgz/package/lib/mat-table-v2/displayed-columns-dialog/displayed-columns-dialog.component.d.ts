import { DisplayedColumnConfig, DisplayedColumnsDialogDataModel } from './displayed-columns-dialog-data.model';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { ModuleV2Config } from '../_shared/configs/module-v2.config';
import { MatDialogRef } from '@angular/material/dialog';
export declare class DisplayedColumnsDialogComponent {
    data: DisplayedColumnsDialogDataModel;
    config: ModuleV2Config;
    private dialogRef;
    constructor(data: DisplayedColumnsDialogDataModel, config: ModuleV2Config, dialogRef: MatDialogRef<DisplayedColumnsDialogComponent>);
    reorderColumns({ previousIndex, currentIndex }: CdkDragDrop<DisplayedColumnConfig>): void;
    submit(data: DisplayedColumnConfig[]): void;
}
