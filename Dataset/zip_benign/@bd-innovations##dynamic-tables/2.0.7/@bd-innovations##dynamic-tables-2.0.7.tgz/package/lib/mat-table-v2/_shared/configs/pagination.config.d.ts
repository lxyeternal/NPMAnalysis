export interface PaginationConfig {
    pageIndex: any;
    pageSize: any;
}
