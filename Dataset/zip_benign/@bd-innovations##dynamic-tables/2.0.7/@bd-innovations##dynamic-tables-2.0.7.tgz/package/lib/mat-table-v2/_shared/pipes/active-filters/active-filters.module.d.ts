export declare class ActiveFiltersModule {
}
