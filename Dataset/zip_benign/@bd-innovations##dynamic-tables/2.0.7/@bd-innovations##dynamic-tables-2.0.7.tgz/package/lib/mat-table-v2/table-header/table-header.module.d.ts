export declare class TableHeaderModule {
}
