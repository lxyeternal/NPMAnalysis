import { AnimationTriggerMetadata } from '@angular/animations';
export declare const EXPANDED_ROW_ANIMATION: AnimationTriggerMetadata;
