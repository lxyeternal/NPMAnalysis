import { BaseColumnCellComponent } from '../base-column-cell/base-column-cell.component';
import { ProgressBarColumnInterface, ProgressBarColumnValue } from './progress-bar-column.interface';
import { ModuleV2Config } from '../../../configs/module-v2.config';
export declare class ProgressBarColumnCellComponent implements BaseColumnCellComponent<ProgressBarColumnValue> {
    config: ModuleV2Config;
    cellValue: ProgressBarColumnValue;
    columnConfig: ProgressBarColumnInterface;
    constructor(config: ModuleV2Config);
}
