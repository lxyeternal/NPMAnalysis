Binaries for the release
