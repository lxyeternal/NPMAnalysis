// src/index.js

import ScrollMenuList from './components/ScrollMenuList.vue';

// 导出组件
export default ScrollMenuList;

// 如果组件有其他部分（例如指令、混入等），可以在这里导出
export { ScrollMenuList };
