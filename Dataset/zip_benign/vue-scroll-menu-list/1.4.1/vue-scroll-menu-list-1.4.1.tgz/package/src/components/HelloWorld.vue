<template>
  <div class="scrolling-menu">
    <div
      class="table-header"
      v-if="headers.length"
      :style="{ backgroundColor: headerBackground }"
    >
      <div
        class="header-item"
        v-for="(header, index) in headers"
        :key="index"
        :style="getHeaderStyle()"
      >
        {{ header }}
      </div>
    </div>
    <div class="table-body" ref="menuContainer">
      <div
        class="menu-item"
        v-for="(item, index) in displayedItems"
        :key="index"
        :style="getItemStyle(index)"
      >
        <div
          v-for="(field, colIndex) in columns"
          :key="colIndex"
          class="column-item"
          :style="getColumnStyle()"
        >
          {{ formatItem(item, field) }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, watch } from 'vue';

const props = {
  data: {
    type: Array,
    required: true,
  },
  headers: {
    type: Array,
    default: () => [],
  },
  columns: {
    type: Array,
    required: true,
  },
  rows: {
    type: Number,
    default: 5,
  },
  scrollSpeed: {
    type: Number,
    default: 3000,
  },
  itemFormatter: {
    type: Function,
    default: (item, field) => item[field]?.toString() || '',
  },
  rowHeight: {
    type: String,
    default: '20%', // 每行高度占父容器的20%，即5行平均分配
  },
  fontSize: {
    type: String,
    default: '16px', // 默认字体大小
  },
  textAlign: {
    type: String,
    default: 'center', // 默认文字居中对齐
  },
  headerBackground: {
    type: String,
    default: 'rgba(0, 0, 50, 0.5)', // 表头背景色
  },
  rowBackground: {
    type: String,
    default: 'rgba(0, 0, 50, 0.2)', // 行背景色
  },
  alternateRowBackground: {
    type: String,
    default: 'rgba(62, 62, 173, 0.2)', // 每隔一行的背景色
  },
};

const menuContainer = ref(null);
const displayedItems = ref([]);

let interval = null;
let currentIndex = 0;

const startScrolling = () => {
  interval = setInterval(() => {
    currentIndex += props.rows;
    if (currentIndex >= props.data.length) {
      currentIndex = 0;
    }
    updateDisplayedItems();
  }, props.scrollSpeed);
};

const updateDisplayedItems = () => {
  displayedItems.value = props.data.slice(currentIndex, currentIndex + props.rows);
};

const formatItem = (item, field) => {
  return props.itemFormatter(item, field);
};

const getHeaderStyle = () => {
  return {
    width: `${100 / props.columns.length}%`,
    fontSize: props.fontSize,
    textAlign: props.textAlign,
  };
};

const getItemStyle = (index) => {
  return {
    display: 'flex',
    width: '100%',
    height: props.rowHeight,
    backgroundColor: index % 2 === 0 ? props.rowBackground : props.alternateRowBackground,
  };
};

const getColumnStyle = () => {
  return {
    width: `${100 / props.columns.length}%`,
    fontSize: props.fontSize,
    textAlign: props.textAlign,
  };
};

onMounted(() => {
  console.log('滚动表格组件已加载……');
  
  updateDisplayedItems();
  startScrolling();
});

onUnmounted(() => {
  clearInterval(interval);
});

watch(
  () => props.data,
  () => {
    currentIndex = 0;
    updateDisplayedItems();
  }
);
</script>

<style scoped>
.scrolling-menu {
  display: flex;
  flex-direction: column;
  overflow: hidden;
  width: 100%;
  height: 100%;
}

.table-header {
  display: flex;
  padding: 10px;
  font-weight: bold;
  color: white;
}

.header-item {
  text-align: center;
}

.table-body {
  display: flex;
  flex-direction: column;
  flex-grow: 1;
  overflow: hidden;
}

.menu-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  box-sizing: border-box;
}
</style>
