# JOT-TIMEPICKER by Jack of Traits

[Youtube](https://www.youtube.com/c/JackofTraits) | [Github](https://github.com/jackoftraits)
The jot-timepicker is a react js timepicker component that lets you easily customize the look of your time picker component.

### Reasons to use jot-timepicker

-   Easy to use.
-   No-brainer configurations are easily passed through the props.

### Installation

The jot-timepicker requires [Node.js](https://nodejs.org/) v10+ and moment-js.

```sh
$ cd react-js-app
$ npm install jot-timepicker
```

# Basic Usage

    import Timepicker from "jot-timepicker";

    export defaults function App() {
      return (
        <Timepicker
          buttonText="Proceed"
	      title="Select Your Time"
          value={"03:00 PM"}
          // value={"15:00:00"} // Also accepts 24 hour format          
          onTimeChange={({
            time12HourFormat,
            time24HourFormat,
            hour,
            minute,
            meridiem,
          }) => {
            console.log(time12HourFormat); // i.e. 12:00 AM, 01:30 PM
            console.log(time24HourFormat); // i.e. 12:00:00, 00:00:00
            console.log(hour);
            console.log(minute);
            console.log(meridiem); // AM/PM
          }}
        />
      );
    }

# Overriding Hours and Minutes List

If you want to limit the hours and minute selection, you can easily do that!

    import Timepicker from "jot-timepicker";

    export defaults function App() {
      return (
        <Timepicker
          value={"03:00 PM"}
          hourList={() => {
            return (
              <>
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
              </>
            );
          }}
          minuteList={() => {
            return (
              <>
                <option value="10">10</option>
                <option value="15">15</option>
                <option value="30">30</option>
                <option value="45">45</option>
              </>
            );
          }}
          onTimeChange={({
            time12HourFormat,
            time24HourFormat,
            hour,
            minute,
            meridiem,
          }) => {
            console.log(time12HourFormat); // i.e. 12:00 AM, 01:30 PM
            console.log(time24HourFormat); // i.e. 12:00:00, 00:00:00
            console.log(hour);
            console.log(minute);
            console.log(meridiem); // AM/PM
          }}
        />
      );
    }

# Adding CSS Styles to every element

You can experiment your own design with this especially when you are really good at CSS!

    import Timepicker from "jot-timepicker";

    export defaults function App() {
      return (
        <Timepicker
          value={"03:00 PM"}
          view={{
            container: {
              modal: {
                border: "2px dashed #E5E7EB",
                backgroundColor: "rgb(24, 68, 148)",
                backgroundColor: "rgba(24, 68, 148, 0.4)",
              },
              modalContent: {
                border: "3px dashed white",
                padding: "20px",
                backgroundColor: "rgb(24, 68, 148)",
                background: "rgb(0,119,213)",
                background:
                  "-moz-radial-gradient(circle, rgba(0,119,213,1) 0%, rgba(0,168,220,1) 100%)",
                background:
                  "-webkit-radial-gradient(circle, rgba(0,119,213,1) 0%, rgba(0,168,220,1) 100%)",
                background:
                  "radial-gradient(circle, rgba(0,119,213,1) 0%, rgba(0,168,220,1) 100%)",
                filter:
                  "progid:DXImageTransform.Microsoft.gradient(startColorstr='#0077d5',endColorstr='#00a8dc',GradientType=1)",
              },
              main: {
                border: "2px dashed #2FCAAD",
                width: "100%",
              },
              input: {
                backgroundColor: "#1C8E78",
                color: "#fff",
              },
              modalTimepicker: {
                border: "3px solid #007FD6",
              },
            },
            element: {
              hourSelectInput: {
                color: "#6C194F",
                fontWeight: "bold",
              },
              minuteSelectInput: {
                color: "#6C194F",
                fontWeight: "bold",
              },
              meridiemSelectInput: {
                color: "#6C194F",
                fontWeight: "bold",
              },
              colon: {
                color: "#6C194F",
              },
              title: {
                color: "white",
              },
              button: {
                backgroundColor: "#6C194F",
                color: "white",
              },
            },
          }}
          onTimeChange={({
            time12HourFormat,
            time24HourFormat,
            hour,
            minute,
            meridiem,
          }) => {
            console.log(time12HourFormat); // i.e. 12:00 AM, 01:30 PM
            console.log(time24HourFormat); // i.e. 12:00:00, 00:00:00
            console.log(hour);
            console.log(minute);
            console.log(meridiem); // AM/PM
          }}
        />
      );
    }

# Here is the full configuration!

    import Timepicker from "jot-timepicker";

    export defaults function App() {
      return (
        <Timepicker
          buttonText="Proceed"
          title="Select Your Time"
          value={"03:00 PM"}
          hourList={() => {
            return (
              <>
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
              </>
            );
          }}
          minuteList={() => {
            return (
              <>
                <option value="10">10</option>
                <option value="15">15</option>
                <option value="30">30</option>
                <option value="45">45</option>
              </>
            );
          }}
          onTimeChange={({
            time12HourFormat,
            time24HourFormat,
            hour,
            minute,
            meridiem,
          }) => {
            console.log(time12HourFormat);
            console.log(time24HourFormat);
            console.log(hour);
            console.log(minute);
            console.log(meridiem);
          }}
          view={{
            container: {
              modal: {
                border: "2px dashed #E5E7EB",
                backgroundColor: "rgb(24, 68, 148)",
                backgroundColor: "rgba(24, 68, 148, 0.4)",
              },
              modalContent: {
                border: "3px dashed white",
                padding: "20px",
                backgroundColor: "rgb(24, 68, 148)",
                background: "rgb(0,119,213)",
                background:
                  "-moz-radial-gradient(circle, rgba(0,119,213,1) 0%, rgba(0,168,220,1) 100%)",
                background:
                  "-webkit-radial-gradient(circle, rgba(0,119,213,1) 0%, rgba(0,168,220,1) 100%)",
                background:
                  "radial-gradient(circle, rgba(0,119,213,1) 0%, rgba(0,168,220,1) 100%)",
                filter:
                  "progid:DXImageTransform.Microsoft.gradient(startColorstr='#0077d5',endColorstr='#00a8dc',GradientType=1)",
              },
              main: {
                border: "2px dashed #2FCAAD",
                width: "100%",
              },
              input: {
                backgroundColor: "#1C8E78",
                color: "#fff",
              },
              modalTimepicker: {
                border: "3px solid #007FD6",
              },
            },
            element: {
              hourSelectInput: {
                color: "#6C194F",
                fontWeight: "bold",
              },
              minuteSelectInput: {
                color: "#6C194F",
                fontWeight: "bold",
              },
              meridiemSelectInput: {
                color: "#6C194F",
                fontWeight: "bold",
              },
              colon: {
                color: "#6C194F",
              },
              title: {
                color: "white",
              },
              button: {
                backgroundColor: "#6C194F",
                color: "white",
              },
            },
          }}
        />
      );
    }

## License

MIT

Copyright (c) 2021 jackoftraits

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
