contract Contract {
  constructor() {
  }
}
