contract Contract {
  function() {
  }
}
