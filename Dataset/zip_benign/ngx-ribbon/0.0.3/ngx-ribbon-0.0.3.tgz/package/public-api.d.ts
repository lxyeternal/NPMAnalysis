export * from './lib/ngx-ribbon.component';
export * from './lib/ngx-ribbon.module';
