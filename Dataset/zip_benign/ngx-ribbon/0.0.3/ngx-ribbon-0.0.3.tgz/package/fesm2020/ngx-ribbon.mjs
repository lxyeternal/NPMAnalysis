import * as i0 from '@angular/core';
import { EventEmitter, PLATFORM_ID, Component, Inject, Input, Output, NgModule } from '@angular/core';
import { isPlatformBrowser, CommonModule } from '@angular/common';

class NgxRibbonComponent {
    constructor(platformId, renderer, el) {
        this.platformId = platformId;
        this.renderer = renderer;
        this.el = el;
        this.position = 'top-left';
        this.clicked = new EventEmitter();
    }
    get transform() {
        return this.scale ? `scale(${this.scale})` : null;
    }
    ngAfterViewInit() {
        if (!isPlatformBrowser(this.platformId))
            return;
        // Force parent element to have position relative so that the ribbon's
        // offset, using position absolute, is secured in the correct intended place.
        const parent = this.el.nativeElement.parentNode;
        if (parent)
            this.renderer.setStyle(parent, 'position', 'relative');
    }
}
NgxRibbonComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.9", ngImport: i0, type: NgxRibbonComponent, deps: [{ token: PLATFORM_ID }, { token: i0.Renderer2 }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
NgxRibbonComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.9", type: NgxRibbonComponent, selector: "ngx-ribbon", inputs: { label: "label", position: "position", scale: "scale" }, outputs: { clicked: "clicked" }, ngImport: i0, template: `
    <div
      class="ribbon ribbon-{{ position }}"
      [style.cursor]="clicked.observed ? 'pointer' : 'default'"
      [style.transform]="transform"
      (click)="this.clicked.emit()"
    >
      <div class="ribbon-label">
        <span>{{ label }}</span>
      </div>
    </div>
  `, isInline: true, styles: [".ribbon{width:150px;height:150px;overflow:hidden;position:absolute;border-color:#d62c1a}.ribbon:before,.ribbon:after{position:absolute;content:\"\";display:block;border-color:inherit;border-width:5px;border-style:solid}.ribbon .ribbon-label{position:absolute;display:block;width:225px;padding:15px 0;background-color:#e74c3c;box-shadow:0 5px 10px #0000001a;color:#fff;text-shadow:0 1px 1px rgba(0,0,0,.2);text-transform:uppercase;text-align:center;line-height:18px!important;font-size:1.25em}.ribbon .ribbon-label span{display:block;min-height:18px}.ribbon-top-left{top:-10px;left:-10px;transform-origin:calc(0% + 10px) calc(0% + 10px)}.ribbon-top-left:before,.ribbon-top-left:after{border-top-color:transparent;border-left-color:transparent}.ribbon-top-left:before{top:0;right:0}.ribbon-top-left:after{bottom:0;left:0}.ribbon-top-left .ribbon-label{right:-25px;top:30px;transform:rotate(-45deg)}.ribbon-top-right{top:-10px;right:-10px;transform-origin:calc(100% - 10px) calc(0% + 10px)}.ribbon-top-right:before,.ribbon-top-right:after{border-top-color:transparent;border-right-color:transparent}.ribbon-top-right:before{top:0;left:0}.ribbon-top-right:after{bottom:0;right:0}.ribbon-top-right .ribbon-label{left:-25px;top:30px;transform:rotate(45deg)}.ribbon-top-right .ribbon-label span{padding-left:1.5ch}.ribbon-bottom-left{bottom:-10px;left:-10px;transform-origin:calc(0% + 10px) calc(100% - 10px)}.ribbon-bottom-left:before,.ribbon-bottom-left:after{border-bottom-color:transparent;border-left-color:transparent}.ribbon-bottom-left:before{bottom:0;right:0}.ribbon-bottom-left:after{top:0;left:0}.ribbon-bottom-left .ribbon-label{right:-25px;bottom:30px;transform:rotate(225deg)}.ribbon-bottom-left .ribbon-label span{padding-left:1.5ch}.ribbon-bottom-right{bottom:-10px;right:-10px;transform-origin:calc(100% - 10px) calc(100% - 10px)}.ribbon-bottom-right:before,.ribbon-bottom-right:after{border-bottom-color:transparent;border-right-color:transparent}.ribbon-bottom-right:before{bottom:0;left:0}.ribbon-bottom-right:after{top:0;right:0}.ribbon-bottom-right .ribbon-label{left:-25px;bottom:30px;transform:rotate(-225deg)}\n"] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.9", ngImport: i0, type: NgxRibbonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ngx-ribbon', template: `
    <div
      class="ribbon ribbon-{{ position }}"
      [style.cursor]="clicked.observed ? 'pointer' : 'default'"
      [style.transform]="transform"
      (click)="this.clicked.emit()"
    >
      <div class="ribbon-label">
        <span>{{ label }}</span>
      </div>
    </div>
  `, styles: [".ribbon{width:150px;height:150px;overflow:hidden;position:absolute;border-color:#d62c1a}.ribbon:before,.ribbon:after{position:absolute;content:\"\";display:block;border-color:inherit;border-width:5px;border-style:solid}.ribbon .ribbon-label{position:absolute;display:block;width:225px;padding:15px 0;background-color:#e74c3c;box-shadow:0 5px 10px #0000001a;color:#fff;text-shadow:0 1px 1px rgba(0,0,0,.2);text-transform:uppercase;text-align:center;line-height:18px!important;font-size:1.25em}.ribbon .ribbon-label span{display:block;min-height:18px}.ribbon-top-left{top:-10px;left:-10px;transform-origin:calc(0% + 10px) calc(0% + 10px)}.ribbon-top-left:before,.ribbon-top-left:after{border-top-color:transparent;border-left-color:transparent}.ribbon-top-left:before{top:0;right:0}.ribbon-top-left:after{bottom:0;left:0}.ribbon-top-left .ribbon-label{right:-25px;top:30px;transform:rotate(-45deg)}.ribbon-top-right{top:-10px;right:-10px;transform-origin:calc(100% - 10px) calc(0% + 10px)}.ribbon-top-right:before,.ribbon-top-right:after{border-top-color:transparent;border-right-color:transparent}.ribbon-top-right:before{top:0;left:0}.ribbon-top-right:after{bottom:0;right:0}.ribbon-top-right .ribbon-label{left:-25px;top:30px;transform:rotate(45deg)}.ribbon-top-right .ribbon-label span{padding-left:1.5ch}.ribbon-bottom-left{bottom:-10px;left:-10px;transform-origin:calc(0% + 10px) calc(100% - 10px)}.ribbon-bottom-left:before,.ribbon-bottom-left:after{border-bottom-color:transparent;border-left-color:transparent}.ribbon-bottom-left:before{bottom:0;right:0}.ribbon-bottom-left:after{top:0;left:0}.ribbon-bottom-left .ribbon-label{right:-25px;bottom:30px;transform:rotate(225deg)}.ribbon-bottom-left .ribbon-label span{padding-left:1.5ch}.ribbon-bottom-right{bottom:-10px;right:-10px;transform-origin:calc(100% - 10px) calc(100% - 10px)}.ribbon-bottom-right:before,.ribbon-bottom-right:after{border-bottom-color:transparent;border-right-color:transparent}.ribbon-bottom-right:before{bottom:0;left:0}.ribbon-bottom-right:after{top:0;right:0}.ribbon-bottom-right .ribbon-label{left:-25px;bottom:30px;transform:rotate(-225deg)}\n"] }]
        }], ctorParameters: function () { return [{ type: Object, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }, { type: i0.Renderer2 }, { type: i0.ElementRef }]; }, propDecorators: { label: [{
                type: Input
            }], position: [{
                type: Input
            }], scale: [{
                type: Input
            }], clicked: [{
                type: Output
            }] } });

class NgxRibbonModule {
}
NgxRibbonModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.9", ngImport: i0, type: NgxRibbonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
NgxRibbonModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.9", ngImport: i0, type: NgxRibbonModule, declarations: [NgxRibbonComponent], imports: [CommonModule], exports: [NgxRibbonComponent] });
NgxRibbonModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.9", ngImport: i0, type: NgxRibbonModule, imports: [CommonModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.9", ngImport: i0, type: NgxRibbonModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [NgxRibbonComponent],
                    imports: [CommonModule],
                    exports: [NgxRibbonComponent],
                }]
        }] });

/*
 * Public API Surface of ngx-ribbon
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgxRibbonComponent, NgxRibbonModule };
//# sourceMappingURL=ngx-ribbon.mjs.map
