import { AfterViewInit, ElementRef, EventEmitter, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class NgxRibbonComponent implements AfterViewInit {
    private platformId;
    private renderer;
    private el;
    label?: string;
    position: 'top-left' | 'top-right' | 'bottom-right' | 'bottom-left';
    /** Applies `transform: scale(amount)` */
    scale?: number;
    clicked: EventEmitter<void>;
    get transform(): string | null;
    constructor(platformId: Object, renderer: Renderer2, el: ElementRef);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxRibbonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NgxRibbonComponent, "ngx-ribbon", never, { "label": "label"; "position": "position"; "scale": "scale"; }, { "clicked": "clicked"; }, never, never, false, never>;
}
