<template>
	<view v-show="isShow" class="code-box" @click="closeOnClickOverlay && closeCodeBox()">
		<view @touchmove.stop.prevent="moveHandle" class="overlay-view"
			:style="{backgroundColor: overlayColor, opacity: overlayOpacity}"></view>
		<view class="container" :style="boxStyle " @click.stop>
			<view class="tips" :style="{color: titleColor}">
				{{title}}
				<view v-show="closeable" class="close-icon" @click.stop="closeCodeBox">
					<icon color="#bcbcbc" type="cancel" size="40" />
				</view>
			</view>
			<view class="original">
				<image :src="bg.src" :mode="bg.mode" :style="originStyle"></image>
				<image id="slider-box" :src="slider.src" class="slider-box" :mode="slider.mode" :style="sliderStyle">
				</image>
			</view>
			<!-- 滑动通道 -->
			<view id="slider-channel" class="slider-channel">
				<view id="channel1" class="channel1">
					<view id="slider-circle" class="slider-circle" :style="circleStyle" @touchend="moveEnd"
						@touchstart="moveStart" @touchmove="moveTouch">
						<icon v-if="showError" class="error-icon" color="#F57A7A" type="clear" size="40" />
						<img v-else
							src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAQhJREFUWEftlt0NwjAMhO1NyiTAJMAmMAlsApvAJqZGTRVQiWzrTF7wc+L74p9rmToHd9anPwC0AiIyMPPD01YYgIjciWgYxY/MfLJCQAD05USkACXMEBAAVa0q4IJAAmgVrlMbzBAwgKLorQQcwNuOFAAPRBqAFSIVwAIxA4jIfpzitdVAnOc0dx2zT7wAFozEmT90fKW2XQCU8BxKE790YOZL3YLNaKe7eL7mzc8W3Jh5qzd+MYTqjvq4ErN4OoCINMVTASziaQBW8RQAjzgUYPISXeWvA7e0J7At8L68wEAAJhuvjext1VoOgQKo/4bM4tAZKN+Ubr/lUQuHtCAqDm9BBKR7BZ6bYnYh+esoXAAAAABJRU5ErkJggg=="
							class="right-arrow" :style="move.left?'':'filter: invert(0.7)'" />
					</view>
					<view class="channel">
						<text>{{ channelText }}</text>
						<view class="channel-color" :style="{width: move.left + (circle.width / 2) + 'px', 
              backgroundColor: showError?'#F57A7A':channelChangeColor, color: changeTextColor}">
							<text>{{ channelChangeText }}</text>
						</view>
					</view>
				</view>

			</view>
		</view>
	</view>
</template>

<script>
	import {
		getImage,
		verify
	} from "./request.js";
	import {
		decrypt,
		encrypt
	} from "./util.js"
	export default {
		name: "sliderCaptcha",
		data() {
			return {
				isShow: false,
				captchaUrl: 'https://cloud.zhitoo.cn',
				channelStyle: { // 滑动管道长度
					width: '100%',
				},
				circle: {
					width: 0,
				},
				move: {
					left: 0
				},
				arr: [],
				channelText: "拖动滑块完成拼图",
				bg: {
					src: ""
				},
				slider: {
					src: "",
					y: 0,
					width: 40,
					height: 40,
					mode: ''
				},
				captcha_id: "",
				encryptData: {},
				callback: null,
				showError: false
			};
		},
		mounted() {

		},
		methods: {
			show(callback) {
				this.callback = callback
				getImage(this.appkey).then(result => {
					console.log('result',result)
					if (result.data.code == 200) {
						let res = result.data.data
						this.encryptData = {
							encrypt_key: res.encrypt_key,
							encrypt_iv: res.encrypt_iv
						}
						let decryptData = JSON.parse(decrypt(this.encryptData, res.info))
						this.captcha_id = decryptData.captcha_id
						this.bg = {
							src: res.back,
							mode: "aspectFit",
						}
						this.slider = {
							src: res.float,
							y: decryptData.y - 2,
							width: 40,
							height: 40,
							mode: ''
						}
						this.init()
					} else {
						this.callback(result.data)
					}
				})
			},
			moveHandle() {

			},
			init() {
				this.$nextTick(async () => {
					// 记录圆宽度
					this.circle.width = 0;
					// 记录左边距
					this.move.min = 0 - 0;
					// 记录右边距
					this.move.max = (this.bg.width || 280) - (this.slider.width || 40);
					// 滑块部分盒子(_channel)宽度：
					//  父盒子宽度(.slider-channel) - 父盒子内边距(20) - 圆形滑块与滑块图片宽度差
					this.channelStyle.width =
						`calc(${0 - 20}px - ${(0 - 0)}px)`;
					this.move.left = this.move.min;
					this.isShow = true
				})
			},
			moveStart(e) {
				// 记录初始位置
				this.move.originX = e.touches[0].pageX;
				this.move.originY = e.touches[0].pageY;
			},
			moveEnd(e) {
				let offset = this.move.left;
				if (offset == 0) {
					return
				}
				var encryptInfo = {
					x: offset,
					addtime: new Date().getTime()
				}
				var info = encrypt(this.encryptData, encryptInfo)
				var data = {
					appkey: this.appkey,
					yData: this.arr,
					captcha_id: this.captcha_id,
					info: info
				}
				verify(data).then(result => {
					let res = result.data
					if (res.code == "200") {
						this.callback(res)
						this.closeCodeBox() // 关闭
					} else {
						this.showError = true
						let timer = setTimeout(() => {
							this.showError = false
							if (this.endToStart)
								this.move.left = this.move.min;
						}, 1000)
					}
				})
			},
			moveTouch(e) {
				let pageX = e.touches[0].pageX;
				let pageY = e.touches[0].pageY;
				let left = pageX - this.move.originX;
				let moveY = pageY - this.move.originY;
				if (left <= this.move.min) {
					left = this.move.min;
				} else if (left >= this.move.max) {
					left = this.move.max;
				}
				this.arr.push(moveY)
				this.move.left = left;
			},
			// 关闭
			closeCodeBox() {
				this.isShow = false
				this.$emit("close", true);
			}
		},
		props: {
			appkey: {
				type: String,
			},
			// 是否显示关闭按钮
			closeable: {
				type: Boolean,
				default: false,
			},
			// 点击遮罩层关闭弹窗
			closeOnClickOverlay: {
				type: Boolean,
				default: false,
			},
			// 遮罩层颜色
			overlayColor: {
				type: String,
				default: "#000000a1"
			},
			// 遮罩层透明度：0-1
			overlayOpacity: {
				type: Number,
				default: 1
			},
			// 标题
			title: {
				type: String,
				default: "请完成下方验证"
			},
			// 标题颜色
			titleColor: {
				type: String,
				default: "black"
			},
			// 滑动管道背景颜色
			channelBG: {
				type: String,
				default: "#d5d5e3"
			},
			// 滑动管道滑动时覆盖掉颜色
			channelChangeColor: {
				type: String,
				default: "#639ef6"
			},
			// 滑动管道内的文字

			// 文字颜色
			textColor: {
				type: String,
				default: "white"
			},
			channelChangeText: {
				type: String,
				default: ""
			},
			// 文字颜色
			changeTextColor: {
				type: String,
				default: "white"
			},
			// 滑动验证码框背景
			boxStyle: {
				type: Object,
				default () {
					return {
						backgroundColor: 'white'
					}
				}
			},
			// 结束后回到起点
			endToStart: {
				type: Boolean,
				default: true,
			}

		},
		computed: {
			// 
			circleStyle() {
				return `left:${this.move.left}px;background:${this.move.left?this.showError?'#fff':this.channelChangeColor:'#fff'};--color:${this.move.left?'#fff':'#626f82'};`
				// return 'left: '+move.left+'px;background:'+move.left?channelChangeColor:'#fff'
			},
			originStyle() {
				if (!this.bg.src) {
					throw "背景图片路径不能为空";
				}
				return `width:${(this.bg.width ||280)}px;height: ${(this.bg.height || 155)}px`
			},
			sliderStyle() {
				if (!this.slider.src) {
					throw "滑块路径不能为空";
				}
				return `top: ${this.slider.y || 0}px;width: ${this.slider.width || 40}px;height:${this.slider.height || 40}px;left:${this.move.left}px`
			},
		},

	};
</script>

<style lang='scss' scoped>
	* {
		box-sizing: content-box;
	}

	.code-box {
		z-index: 1000;
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		background-color: transparent;
		font-size: 14px;

		.overlay-view {
			position: fixed;
			top: 0;
			left: 0;
			z-index: 0;
			width: 100%;
			height: 100%;
		}

		.container {
			z-index: 1;
			overflow: hidden;
			box-sizing: content-box;
			display: flex;
			flex-direction: column;
			justify-content: center;
			position: absolute;
			top: 50%;
			left: 50%;
			padding: 5px;
			background-color: #fff;
			transform: translate(-50%, -50%);
			height: auto;
			border-radius: 15px;
			box-shadow: 0 0 5px #7a7a7a;

			.tips {
				padding: 10px 10px 15px 10px;
				text-align: center;
				flex: none;
				position: relative;

				.close-icon {
					position: absolute;
					top: 5px;
					right: 0px;
					overflow: hidden;
					width: 50rpx;
					height: 50rpx;
					border-radius: 50%;
					display: flex;
					align-items: center;
					justify-content: center;
				}
			}

			.original {
				position: relative;
				flex: 1;
				margin: 0 5px;
				background-repeat: no-repeat;

				.hollow {
					width: 30px;
					height: 30px;
					position: absolute;
					top: 120rpx !important;
					z-index: 9999 !important;
				}

				.slider-box {
					z-index: 100000 !important;
					position: absolute;
					width: 50px;
					height: 50px;
					border: 4rpx solid #fff;

				}
			}

			.slider-channel {

				.channel1 {
					position: relative;
					padding: 10px;

					.slider-circle {
						flex: 1;
						position: absolute;
						z-index: 1000000;
						top: 50%;
						transform: translateY(-50%);
						width: 40px;
						height: 40px;
						line-height: 66rpx;
						text-align: center;
						font-size: 35px;
						color: var(--color);
						background-color: white;
						/* border: 2rpx solid #efefef; */
						border-radius: 50%;
						overflow: hidden;
						box-shadow: 0 0 4rpx #ccc;

						.error-icon {
							position: absolute;
							top: 0;
							left: 0;
						}

					}

					.slider-circle-cover {
						background-color: #639EF6;
					}

					.slider-in-circle {
						display: inline-block;
						width: 80rpx;
						height: 80rpx;

						&::before {
							content: "";
							height: 20rpx;
							width: 20rpx;
							top: 50%;
							margin-top: -13rpx;
							left: 20rpx;
							border-width: 6rpx 6rpx 0 0;
							border-color: var(--color);
							border-style: solid;
							transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);
							position: absolute;
						}

						&::after {
							content: "";
							height: 20rpx;
							width: 20rpx;
							top: 50%;
							margin-top: -13rpx;
							left: 35rpx;
							border-width: 6rpx 6rpx 0 0;
							border-color: var(--color);
							border-style: solid;
							transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);
							position: absolute;
						}
					}

					.channel {
						position: relative;
						height: 35px;
						line-height: 35px;
						text-align: center;
						border-radius: 20px;
						background: #e3e3e3;

						text {
							position: absolute;
							left: 50%;
							width: 100%;
							transform: translateX(-50%);
						}

						.channel-color {
							position: absolute;
							top: 0;
							height: 35px;
							line-height: 35px;
							text-align: center;
							width: 0;
							border-radius: 20px 0 0 20px;
							text-overflow: clip;
							overflow: hidden;

							text {
								position: absolute;
								z-index: 10;
								left: 50%;
								width: 100%;
								transform: translateX(-50%);
							}
						}
					}
				}

			}
		}
	}

	.right-arrow {
		width: 20px;
		height: 20px;
		padding: 10px;
	}
</style>