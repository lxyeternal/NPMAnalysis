package com.jeepeng.reactnative.push.receiver;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import com.tencent.android.hwpush.HWPushMessageReceiver;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Set;

/**
 * 华为官方推送通道消息接收器
 * Created by waveo on 2018/3/11.
 */

public class HuaweiPushMessageReceiver extends HWPushMessageReceiver {

    private static final String TAG = HuaweiPushMessageReceiver.class.getSimpleName();

    public HuaweiPushMessageReceiver() {
    }

    public void onToken(Context context, String token, Bundle extras) {
        Log.d(TAG, "onToken");
    }

    public boolean onPushMsg(Context context, byte[] msg, Bundle bundle) {
        Log.d(TAG, "onPushMsg");
        try {
            Set<String> keySet = bundle.keySet();
            for(String key : keySet){
                // receiveType = 2
                // deviceToken = 0862552039174039300001507300CN01
                // pushMsg = [B@adc6557
                Log.i("XGPUSH", key + " = " + bundle.get(key));
            }
            Log.i("XGPUSH", "pushMsg = " + bundle.getString(BOUND_KEY.pushMsgKey));
            String content = new String(msg, "UTF-8");
            Log.i("PUSH.CHANNEL", "PUSH message content :" + content);
            Intent intent = new Intent("com.tencent.android.tpush.action.PUSH_MESSAGE");
            intent.putExtra("PUSH.CHANNEL", 4);
            intent.putExtra("content", content);
            intent.putExtra("custom_content", "");
            intent.putExtra("type", 1);
            intent.setPackage(context.getPackageName());
            context.sendBroadcast(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public void onEvent(Context var1, Event var2, Bundle var3) {
        Log.d(TAG, "onEvent");
        String var4 = var3.getString("pushMsg");
        Log.i("PUSH.CHANNEL", "onEvent content : " + var4);
        Intent var5 = new Intent("com.tencent.android.tpush.action.FEEDBACK");
        var5.putExtra("TPUSH.FEEDBACK", 4);
        var5.putExtra("PUSH.CHANNEL", 4);
        var5.putExtra("custom_content", var4);
        var5.putExtra("action", 0);
        var5.putExtra("type", 2);

        try {
            if (var4 != null && !TextUtils.isEmpty(var4)) {
                JSONArray var6 = new JSONArray(var4);
                int var7 = var6.length();
                if (var7 > 0) {
                    for (int var8 = 0; var8 < var6.length(); ++var8) {
                        JSONObject var9 = (JSONObject) var6.opt(var8);
                        String var10;
                        if (!var9.isNull("msgId")) {
                            var10 = var9.getString("msgId");
                            var5.putExtra("msgId", Long.valueOf(var10));
                        }

                        if (!var9.isNull("busiMsgId")) {
                            var10 = var9.getString("busiMsgId");
                            var5.putExtra("busiMsgId", Long.valueOf(var10));
                        }
                    }
                }
            }
        } catch (JSONException var11) {
            var11.printStackTrace();
        }

        var5.putExtra("timestamps", System.currentTimeMillis() / 1000L);
        var5.setPackage(var1.getPackageName());
        var1.sendBroadcast(var5);
        super.onEvent(var1, var2, var3);
    }

    public void onPushState(Context var1, boolean var2) {
        Log.d(TAG, "onPushState");
    }
}