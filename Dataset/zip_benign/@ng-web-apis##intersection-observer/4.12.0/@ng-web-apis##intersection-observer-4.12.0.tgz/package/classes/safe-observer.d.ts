export declare const SafeObserver: {
    new (callback: IntersectionObserverCallback, options?: IntersectionObserverInit | undefined): IntersectionObserver;
    prototype: IntersectionObserver;
};
