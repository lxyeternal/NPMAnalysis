import { NgModule } from '@angular/core';
import { WaIntersectionObservee } from './directives/intersection-observee.directive';
import { WaIntersectionObserverDirective } from './directives/intersection-observer.directive';
import { WaIntersectionRoot } from './directives/intersection-root.directive';
import * as i0 from "@angular/core";
export const WaIntersectionObserver = [
    WaIntersectionObserverDirective,
    WaIntersectionObservee,
    WaIntersectionRoot,
];
/**
 * @deprecated: use {@link WaIntersectionObserver}
 */
class IntersectionObserverModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IntersectionObserverModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: IntersectionObserverModule, imports: [WaIntersectionObserverDirective,
            WaIntersectionObservee,
            WaIntersectionRoot], exports: [WaIntersectionObserverDirective,
            WaIntersectionObservee,
            WaIntersectionRoot] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IntersectionObserverModule });
}
export { IntersectionObserverModule };
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IntersectionObserverModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        WaIntersectionObserverDirective,
                        WaIntersectionObservee,
                        WaIntersectionRoot,
                    ],
                    exports: [
                        WaIntersectionObserverDirective,
                        WaIntersectionObservee,
                        WaIntersectionRoot,
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vbGlicy9pbnRlcnNlY3Rpb24tb2JzZXJ2ZXIvc3JjL21vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUMsUUFBUSxFQUFDLE1BQU0sZUFBZSxDQUFDO0FBRXZDLE9BQU8sRUFBQyxzQkFBc0IsRUFBQyxNQUFNLDhDQUE4QyxDQUFDO0FBQ3BGLE9BQU8sRUFBQywrQkFBK0IsRUFBQyxNQUFNLDhDQUE4QyxDQUFDO0FBQzdGLE9BQU8sRUFBQyxrQkFBa0IsRUFBQyxNQUFNLDBDQUEwQyxDQUFDOztBQUU1RSxNQUFNLENBQUMsTUFBTSxzQkFBc0IsR0FBRztJQUNsQywrQkFBK0I7SUFDL0Isc0JBQXNCO0lBQ3RCLGtCQUFrQjtDQUNaLENBQUM7QUFFWDs7R0FFRztBQUNILE1BWWEsMEJBQTBCO3dHQUExQiwwQkFBMEI7eUdBQTFCLDBCQUEwQixZQVYvQiwrQkFBK0I7WUFDL0Isc0JBQXNCO1lBQ3RCLGtCQUFrQixhQUdsQiwrQkFBK0I7WUFDL0Isc0JBQXNCO1lBQ3RCLGtCQUFrQjt5R0FHYiwwQkFBMEI7O1NBQTFCLDBCQUEwQjs0RkFBMUIsMEJBQTBCO2tCQVp0QyxRQUFRO21CQUFDO29CQUNOLE9BQU8sRUFBRTt3QkFDTCwrQkFBK0I7d0JBQy9CLHNCQUFzQjt3QkFDdEIsa0JBQWtCO3FCQUNyQjtvQkFDRCxPQUFPLEVBQUU7d0JBQ0wsK0JBQStCO3dCQUMvQixzQkFBc0I7d0JBQ3RCLGtCQUFrQjtxQkFDckI7aUJBQ0oiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge05nTW9kdWxlfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHtXYUludGVyc2VjdGlvbk9ic2VydmVlfSBmcm9tICcuL2RpcmVjdGl2ZXMvaW50ZXJzZWN0aW9uLW9ic2VydmVlLmRpcmVjdGl2ZSc7XG5pbXBvcnQge1dhSW50ZXJzZWN0aW9uT2JzZXJ2ZXJEaXJlY3RpdmV9IGZyb20gJy4vZGlyZWN0aXZlcy9pbnRlcnNlY3Rpb24tb2JzZXJ2ZXIuZGlyZWN0aXZlJztcbmltcG9ydCB7V2FJbnRlcnNlY3Rpb25Sb290fSBmcm9tICcuL2RpcmVjdGl2ZXMvaW50ZXJzZWN0aW9uLXJvb3QuZGlyZWN0aXZlJztcblxuZXhwb3J0IGNvbnN0IFdhSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgPSBbXG4gICAgV2FJbnRlcnNlY3Rpb25PYnNlcnZlckRpcmVjdGl2ZSxcbiAgICBXYUludGVyc2VjdGlvbk9ic2VydmVlLFxuICAgIFdhSW50ZXJzZWN0aW9uUm9vdCxcbl0gYXMgY29uc3Q7XG5cbi8qKlxuICogQGRlcHJlY2F0ZWQ6IHVzZSB7QGxpbmsgV2FJbnRlcnNlY3Rpb25PYnNlcnZlcn1cbiAqL1xuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbXG4gICAgICAgIFdhSW50ZXJzZWN0aW9uT2JzZXJ2ZXJEaXJlY3RpdmUsXG4gICAgICAgIFdhSW50ZXJzZWN0aW9uT2JzZXJ2ZWUsXG4gICAgICAgIFdhSW50ZXJzZWN0aW9uUm9vdCxcbiAgICBdLFxuICAgIGV4cG9ydHM6IFtcbiAgICAgICAgV2FJbnRlcnNlY3Rpb25PYnNlcnZlckRpcmVjdGl2ZSxcbiAgICAgICAgV2FJbnRlcnNlY3Rpb25PYnNlcnZlZSxcbiAgICAgICAgV2FJbnRlcnNlY3Rpb25Sb290LFxuICAgIF0sXG59KVxuZXhwb3J0IGNsYXNzIEludGVyc2VjdGlvbk9ic2VydmVyTW9kdWxlIHt9XG4iXX0=