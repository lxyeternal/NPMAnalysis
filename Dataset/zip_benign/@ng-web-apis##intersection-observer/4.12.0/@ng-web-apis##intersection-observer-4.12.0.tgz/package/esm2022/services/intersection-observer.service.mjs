import { ElementRef, inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SafeObserver } from '../classes/safe-observer';
import { INTERSECTION_ROOT } from '../tokens/intersection-root';
import { INTERSECTION_ROOT_MARGIN } from '../tokens/intersection-root-margin';
import { INTERSECTION_THRESHOLD } from '../tokens/intersection-threshold';
import * as i0 from "@angular/core";
class IntersectionObserverService extends Observable {
    nativeElement = inject(ElementRef).nativeElement;
    rootMargin = inject(INTERSECTION_ROOT_MARGIN);
    threshold = inject(INTERSECTION_THRESHOLD);
    root = inject(INTERSECTION_ROOT, { optional: true })?.nativeElement ?? null;
    constructor() {
        super((subscriber) => {
            const observer = new SafeObserver((entries) => {
                subscriber.next(entries);
            }, {
                root: this.root,
                rootMargin: this.rootMargin,
                threshold: this.threshold,
            });
            observer.observe(this.nativeElement);
            return () => {
                observer.disconnect();
            };
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IntersectionObserverService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IntersectionObserverService });
}
export { IntersectionObserverService };
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IntersectionObserverService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return []; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW50ZXJzZWN0aW9uLW9ic2VydmVyLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9saWJzL2ludGVyc2VjdGlvbi1vYnNlcnZlci9zcmMvc2VydmljZXMvaW50ZXJzZWN0aW9uLW9ic2VydmVyLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFDLE1BQU0sZUFBZSxDQUFDO0FBQzdELE9BQU8sRUFBQyxVQUFVLEVBQUMsTUFBTSxNQUFNLENBQUM7QUFFaEMsT0FBTyxFQUFDLFlBQVksRUFBQyxNQUFNLDBCQUEwQixDQUFDO0FBQ3RELE9BQU8sRUFBQyxpQkFBaUIsRUFBQyxNQUFNLDZCQUE2QixDQUFDO0FBQzlELE9BQU8sRUFBQyx3QkFBd0IsRUFBQyxNQUFNLG9DQUFvQyxDQUFDO0FBQzVFLE9BQU8sRUFBQyxzQkFBc0IsRUFBQyxNQUFNLGtDQUFrQyxDQUFDOztBQUV4RSxNQUNhLDJCQUE0QixTQUFRLFVBQXVDO0lBQ25FLGFBQWEsR0FBWSxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsYUFBYSxDQUFDO0lBQzFELFVBQVUsR0FBRyxNQUFNLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUM5QyxTQUFTLEdBQUcsTUFBTSxDQUFDLHNCQUFzQixDQUFDLENBQUM7SUFDM0MsSUFBSSxHQUNqQixNQUFNLENBQUMsaUJBQWlCLEVBQUUsRUFBQyxRQUFRLEVBQUUsSUFBSSxFQUFDLENBQUMsRUFBRSxhQUFhLElBQUksSUFBSSxDQUFDO0lBRXZFO1FBQ0ksS0FBSyxDQUFDLENBQUMsVUFBVSxFQUFFLEVBQUU7WUFDakIsTUFBTSxRQUFRLEdBQUcsSUFBSSxZQUFZLENBQzdCLENBQUMsT0FBTyxFQUFFLEVBQUU7Z0JBQ1IsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM3QixDQUFDLEVBQ0Q7Z0JBQ0ksSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2dCQUNmLFVBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtnQkFDM0IsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2FBQzVCLENBQ0osQ0FBQztZQUVGLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBRXJDLE9BQU8sR0FBRyxFQUFFO2dCQUNSLFFBQVEsQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUMxQixDQUFDLENBQUM7UUFDTixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7d0dBMUJRLDJCQUEyQjs0R0FBM0IsMkJBQTJCOztTQUEzQiwyQkFBMkI7NEZBQTNCLDJCQUEyQjtrQkFEdkMsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7RWxlbWVudFJlZiwgaW5qZWN0LCBJbmplY3RhYmxlfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7T2JzZXJ2YWJsZX0gZnJvbSAncnhqcyc7XG5cbmltcG9ydCB7U2FmZU9ic2VydmVyfSBmcm9tICcuLi9jbGFzc2VzL3NhZmUtb2JzZXJ2ZXInO1xuaW1wb3J0IHtJTlRFUlNFQ1RJT05fUk9PVH0gZnJvbSAnLi4vdG9rZW5zL2ludGVyc2VjdGlvbi1yb290JztcbmltcG9ydCB7SU5URVJTRUNUSU9OX1JPT1RfTUFSR0lOfSBmcm9tICcuLi90b2tlbnMvaW50ZXJzZWN0aW9uLXJvb3QtbWFyZ2luJztcbmltcG9ydCB7SU5URVJTRUNUSU9OX1RIUkVTSE9MRH0gZnJvbSAnLi4vdG9rZW5zL2ludGVyc2VjdGlvbi10aHJlc2hvbGQnO1xuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgSW50ZXJzZWN0aW9uT2JzZXJ2ZXJTZXJ2aWNlIGV4dGVuZHMgT2JzZXJ2YWJsZTxJbnRlcnNlY3Rpb25PYnNlcnZlckVudHJ5W10+IHtcbiAgICBwcml2YXRlIHJlYWRvbmx5IG5hdGl2ZUVsZW1lbnQ6IEVsZW1lbnQgPSBpbmplY3QoRWxlbWVudFJlZikubmF0aXZlRWxlbWVudDtcbiAgICBwcml2YXRlIHJlYWRvbmx5IHJvb3RNYXJnaW4gPSBpbmplY3QoSU5URVJTRUNUSU9OX1JPT1RfTUFSR0lOKTtcbiAgICBwcml2YXRlIHJlYWRvbmx5IHRocmVzaG9sZCA9IGluamVjdChJTlRFUlNFQ1RJT05fVEhSRVNIT0xEKTtcbiAgICBwcml2YXRlIHJlYWRvbmx5IHJvb3Q6IEVsZW1lbnQgfCBudWxsID1cbiAgICAgICAgaW5qZWN0KElOVEVSU0VDVElPTl9ST09ULCB7b3B0aW9uYWw6IHRydWV9KT8ubmF0aXZlRWxlbWVudCA/PyBudWxsO1xuXG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKChzdWJzY3JpYmVyKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBTYWZlT2JzZXJ2ZXIoXG4gICAgICAgICAgICAgICAgKGVudHJpZXMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KGVudHJpZXMpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICByb290OiB0aGlzLnJvb3QsXG4gICAgICAgICAgICAgICAgICAgIHJvb3RNYXJnaW46IHRoaXMucm9vdE1hcmdpbixcbiAgICAgICAgICAgICAgICAgICAgdGhyZXNob2xkOiB0aGlzLnRocmVzaG9sZCxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZSh0aGlzLm5hdGl2ZUVsZW1lbnQpO1xuXG4gICAgICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0pO1xuICAgIH1cbn1cbiJdfQ==