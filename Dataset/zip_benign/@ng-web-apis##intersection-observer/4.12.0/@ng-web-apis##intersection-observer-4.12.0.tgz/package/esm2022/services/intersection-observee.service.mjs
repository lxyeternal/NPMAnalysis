import { ElementRef, inject, Injectable } from '@angular/core';
import { Observable, share } from 'rxjs';
import { WaIntersectionObserverDirective } from '../directives/intersection-observer.directive';
import * as i0 from "@angular/core";
class IntersectionObserveeService extends Observable {
    constructor() {
        const nativeElement = inject(ElementRef).nativeElement;
        const observer = inject(WaIntersectionObserverDirective);
        super((subscriber) => {
            observer.observe(nativeElement, (entries) => {
                subscriber.next(entries);
            });
            return () => {
                observer.unobserve(nativeElement);
            };
        });
        return this.pipe(share());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IntersectionObserveeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IntersectionObserveeService });
}
export { IntersectionObserveeService };
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: IntersectionObserveeService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return []; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW50ZXJzZWN0aW9uLW9ic2VydmVlLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9saWJzL2ludGVyc2VjdGlvbi1vYnNlcnZlci9zcmMvc2VydmljZXMvaW50ZXJzZWN0aW9uLW9ic2VydmVlLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFDLE1BQU0sZUFBZSxDQUFDO0FBQzdELE9BQU8sRUFBQyxVQUFVLEVBQUUsS0FBSyxFQUFDLE1BQU0sTUFBTSxDQUFDO0FBRXZDLE9BQU8sRUFBQywrQkFBK0IsRUFBQyxNQUFNLCtDQUErQyxDQUFDOztBQUU5RixNQUNhLDJCQUE0QixTQUFRLFVBQXVDO0lBQ3BGO1FBQ0ksTUFBTSxhQUFhLEdBQVksTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLGFBQWEsQ0FBQztRQUNoRSxNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsK0JBQStCLENBQUMsQ0FBQztRQUV6RCxLQUFLLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRTtZQUNqQixRQUFRLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDLE9BQU8sRUFBRSxFQUFFO2dCQUN4QyxVQUFVLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzdCLENBQUMsQ0FBQyxDQUFDO1lBRUgsT0FBTyxHQUFHLEVBQUU7Z0JBQ1IsUUFBUSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUN0QyxDQUFDLENBQUM7UUFDTixDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO0lBQzlCLENBQUM7d0dBaEJRLDJCQUEyQjs0R0FBM0IsMkJBQTJCOztTQUEzQiwyQkFBMkI7NEZBQTNCLDJCQUEyQjtrQkFEdkMsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7RWxlbWVudFJlZiwgaW5qZWN0LCBJbmplY3RhYmxlfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7T2JzZXJ2YWJsZSwgc2hhcmV9IGZyb20gJ3J4anMnO1xuXG5pbXBvcnQge1dhSW50ZXJzZWN0aW9uT2JzZXJ2ZXJEaXJlY3RpdmV9IGZyb20gJy4uL2RpcmVjdGl2ZXMvaW50ZXJzZWN0aW9uLW9ic2VydmVyLmRpcmVjdGl2ZSc7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBJbnRlcnNlY3Rpb25PYnNlcnZlZVNlcnZpY2UgZXh0ZW5kcyBPYnNlcnZhYmxlPEludGVyc2VjdGlvbk9ic2VydmVyRW50cnlbXT4ge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBjb25zdCBuYXRpdmVFbGVtZW50OiBFbGVtZW50ID0gaW5qZWN0KEVsZW1lbnRSZWYpLm5hdGl2ZUVsZW1lbnQ7XG4gICAgICAgIGNvbnN0IG9ic2VydmVyID0gaW5qZWN0KFdhSW50ZXJzZWN0aW9uT2JzZXJ2ZXJEaXJlY3RpdmUpO1xuXG4gICAgICAgIHN1cGVyKChzdWJzY3JpYmVyKSA9PiB7XG4gICAgICAgICAgICBvYnNlcnZlci5vYnNlcnZlKG5hdGl2ZUVsZW1lbnQsIChlbnRyaWVzKSA9PiB7XG4gICAgICAgICAgICAgICAgc3Vic2NyaWJlci5uZXh0KGVudHJpZXMpO1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgb2JzZXJ2ZXIudW5vYnNlcnZlKG5hdGl2ZUVsZW1lbnQpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXMucGlwZShzaGFyZSgpKTtcbiAgICB9XG59XG4iXX0=