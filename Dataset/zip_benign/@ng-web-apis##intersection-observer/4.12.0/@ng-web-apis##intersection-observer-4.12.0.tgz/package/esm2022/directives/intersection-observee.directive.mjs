import { Directive, inject } from '@angular/core';
import { IntersectionObserveeService } from '../services/intersection-observee.service';
import * as i0 from "@angular/core";
class WaIntersectionObservee {
    waIntersectionObservee = inject(IntersectionObserveeService);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: WaIntersectionObservee, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: WaIntersectionObservee, isStandalone: true, selector: "[waIntersectionObservee]", outputs: { waIntersectionObservee: "waIntersectionObservee" }, providers: [IntersectionObserveeService], ngImport: i0 });
}
export { WaIntersectionObservee };
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: WaIntersectionObservee, decorators: [{
            type: Directive,
            args: [{
                    standalone: true,
                    selector: '[waIntersectionObservee]',
                    outputs: ['waIntersectionObservee'],
                    providers: [IntersectionObserveeService],
                }]
        }] });
/**
 * @deprecated: use {@link WaIntersectionObservee}
 */
export const IntersectionObserveeDirective = WaIntersectionObservee;
/**
 * @deprecated: use {@link WaIntersectionObservee}
 */
export const WaObservee = WaIntersectionObservee;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW50ZXJzZWN0aW9uLW9ic2VydmVlLmRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL2xpYnMvaW50ZXJzZWN0aW9uLW9ic2VydmVyL3NyYy9kaXJlY3RpdmVzL2ludGVyc2VjdGlvbi1vYnNlcnZlZS5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFDLFNBQVMsRUFBRSxNQUFNLEVBQUMsTUFBTSxlQUFlLENBQUM7QUFFaEQsT0FBTyxFQUFDLDJCQUEyQixFQUFDLE1BQU0sMkNBQTJDLENBQUM7O0FBRXRGLE1BTWEsc0JBQXNCO0lBQ1osc0JBQXNCLEdBQUcsTUFBTSxDQUFDLDJCQUEyQixDQUFDLENBQUM7d0dBRHZFLHNCQUFzQjs0RkFBdEIsc0JBQXNCLHNJQUZwQixDQUFDLDJCQUEyQixDQUFDOztTQUUvQixzQkFBc0I7NEZBQXRCLHNCQUFzQjtrQkFObEMsU0FBUzttQkFBQztvQkFDUCxVQUFVLEVBQUUsSUFBSTtvQkFDaEIsUUFBUSxFQUFFLDBCQUEwQjtvQkFDcEMsT0FBTyxFQUFFLENBQUMsd0JBQXdCLENBQUM7b0JBQ25DLFNBQVMsRUFBRSxDQUFDLDJCQUEyQixDQUFDO2lCQUMzQzs7QUFLRDs7R0FFRztBQUNILE1BQU0sQ0FBQyxNQUFNLDZCQUE2QixHQUFHLHNCQUFzQixDQUFDO0FBRXBFOztHQUVHO0FBQ0gsTUFBTSxDQUFDLE1BQU0sVUFBVSxHQUFHLHNCQUFzQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtEaXJlY3RpdmUsIGluamVjdH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7SW50ZXJzZWN0aW9uT2JzZXJ2ZWVTZXJ2aWNlfSBmcm9tICcuLi9zZXJ2aWNlcy9pbnRlcnNlY3Rpb24tb2JzZXJ2ZWUuc2VydmljZSc7XG5cbkBEaXJlY3RpdmUoe1xuICAgIHN0YW5kYWxvbmU6IHRydWUsXG4gICAgc2VsZWN0b3I6ICdbd2FJbnRlcnNlY3Rpb25PYnNlcnZlZV0nLFxuICAgIG91dHB1dHM6IFsnd2FJbnRlcnNlY3Rpb25PYnNlcnZlZSddLFxuICAgIHByb3ZpZGVyczogW0ludGVyc2VjdGlvbk9ic2VydmVlU2VydmljZV0sXG59KVxuZXhwb3J0IGNsYXNzIFdhSW50ZXJzZWN0aW9uT2JzZXJ2ZWUge1xuICAgIHByb3RlY3RlZCByZWFkb25seSB3YUludGVyc2VjdGlvbk9ic2VydmVlID0gaW5qZWN0KEludGVyc2VjdGlvbk9ic2VydmVlU2VydmljZSk7XG59XG5cbi8qKlxuICogQGRlcHJlY2F0ZWQ6IHVzZSB7QGxpbmsgV2FJbnRlcnNlY3Rpb25PYnNlcnZlZX1cbiAqL1xuZXhwb3J0IGNvbnN0IEludGVyc2VjdGlvbk9ic2VydmVlRGlyZWN0aXZlID0gV2FJbnRlcnNlY3Rpb25PYnNlcnZlZTtcblxuLyoqXG4gKiBAZGVwcmVjYXRlZDogdXNlIHtAbGluayBXYUludGVyc2VjdGlvbk9ic2VydmVlfVxuICovXG5leHBvcnQgY29uc3QgV2FPYnNlcnZlZSA9IFdhSW50ZXJzZWN0aW9uT2JzZXJ2ZWU7XG4iXX0=