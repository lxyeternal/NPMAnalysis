import { Directive, ElementRef } from '@angular/core';
import { INTERSECTION_ROOT } from '../tokens/intersection-root';
import * as i0 from "@angular/core";
class WaIntersectionRoot {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: WaIntersectionRoot, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "16.2.12", type: WaIntersectionRoot, isStandalone: true, selector: "[waIntersectionRoot]", providers: [
            {
                provide: INTERSECTION_ROOT,
                useExisting: ElementRef,
            },
        ], ngImport: i0 });
}
export { WaIntersectionRoot };
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: WaIntersectionRoot, decorators: [{
            type: Directive,
            args: [{
                    standalone: true,
                    selector: '[waIntersectionRoot]',
                    providers: [
                        {
                            provide: INTERSECTION_ROOT,
                            useExisting: ElementRef,
                        },
                    ],
                }]
        }] });
/**
 * @deprecated: use {@link WaIntersectionRoot}
 */
export const IntersectionRootDirective = WaIntersectionRoot;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW50ZXJzZWN0aW9uLXJvb3QuZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vbGlicy9pbnRlcnNlY3Rpb24tb2JzZXJ2ZXIvc3JjL2RpcmVjdGl2ZXMvaW50ZXJzZWN0aW9uLXJvb3QuZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBQyxTQUFTLEVBQUUsVUFBVSxFQUFDLE1BQU0sZUFBZSxDQUFDO0FBRXBELE9BQU8sRUFBQyxpQkFBaUIsRUFBQyxNQUFNLDZCQUE2QixDQUFDOztBQUU5RCxNQVVhLGtCQUFrQjt3R0FBbEIsa0JBQWtCOzRGQUFsQixrQkFBa0IsbUVBUGhCO1lBQ1A7Z0JBQ0ksT0FBTyxFQUFFLGlCQUFpQjtnQkFDMUIsV0FBVyxFQUFFLFVBQVU7YUFDMUI7U0FDSjs7U0FFUSxrQkFBa0I7NEZBQWxCLGtCQUFrQjtrQkFWOUIsU0FBUzttQkFBQztvQkFDUCxVQUFVLEVBQUUsSUFBSTtvQkFDaEIsUUFBUSxFQUFFLHNCQUFzQjtvQkFDaEMsU0FBUyxFQUFFO3dCQUNQOzRCQUNJLE9BQU8sRUFBRSxpQkFBaUI7NEJBQzFCLFdBQVcsRUFBRSxVQUFVO3lCQUMxQjtxQkFDSjtpQkFDSjs7QUFHRDs7R0FFRztBQUNILE1BQU0sQ0FBQyxNQUFNLHlCQUF5QixHQUFHLGtCQUFrQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtEaXJlY3RpdmUsIEVsZW1lbnRSZWZ9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQge0lOVEVSU0VDVElPTl9ST09UfSBmcm9tICcuLi90b2tlbnMvaW50ZXJzZWN0aW9uLXJvb3QnO1xuXG5ARGlyZWN0aXZlKHtcbiAgICBzdGFuZGFsb25lOiB0cnVlLFxuICAgIHNlbGVjdG9yOiAnW3dhSW50ZXJzZWN0aW9uUm9vdF0nLFxuICAgIHByb3ZpZGVyczogW1xuICAgICAgICB7XG4gICAgICAgICAgICBwcm92aWRlOiBJTlRFUlNFQ1RJT05fUk9PVCxcbiAgICAgICAgICAgIHVzZUV4aXN0aW5nOiBFbGVtZW50UmVmLFxuICAgICAgICB9LFxuICAgIF0sXG59KVxuZXhwb3J0IGNsYXNzIFdhSW50ZXJzZWN0aW9uUm9vdCB7fVxuXG4vKipcbiAqIEBkZXByZWNhdGVkOiB1c2Uge0BsaW5rIFdhSW50ZXJzZWN0aW9uUm9vdH1cbiAqL1xuZXhwb3J0IGNvbnN0IEludGVyc2VjdGlvblJvb3REaXJlY3RpdmUgPSBXYUludGVyc2VjdGlvblJvb3Q7XG4iXX0=