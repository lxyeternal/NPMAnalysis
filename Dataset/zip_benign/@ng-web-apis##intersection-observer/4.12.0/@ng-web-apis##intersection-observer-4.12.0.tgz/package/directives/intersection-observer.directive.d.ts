import type { OnDestroy } from '@angular/core';
import { SafeObserver } from '../classes/safe-observer';
import * as i0 from "@angular/core";
export declare class WaIntersectionObserverDirective extends SafeObserver implements OnDestroy {
    private readonly callbacks;
    margin: string;
    threshold: string;
    constructor();
    observe(target: Element, callback?: IntersectionObserverCallback): void;
    unobserve(target: Element): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WaIntersectionObserverDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<WaIntersectionObserverDirective, "[waIntersectionObserver]", ["IntersectionObserver"], { "margin": { "alias": "waIntersectionRootMargin"; "required": false; }; "threshold": { "alias": "waIntersectionThreshold"; "required": false; }; }, {}, never, never, true, never>;
}
/**
 * @deprecated: use {@link WaIntersectionObserverDirective}
 */
export declare const IntersectionObserverDirective: typeof WaIntersectionObserverDirective;
/**
 * @deprecated: use {@link WaIntersectionObserver}
 */
export declare const WaObserver: typeof WaIntersectionObserverDirective;
