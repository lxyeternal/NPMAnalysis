import { IntersectionObserveeService } from '../services/intersection-observee.service';
import * as i0 from "@angular/core";
export declare class WaIntersectionObservee {
    protected readonly waIntersectionObservee: IntersectionObserveeService;
    static ɵfac: i0.ɵɵFactoryDeclaration<WaIntersectionObservee, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<WaIntersectionObservee, "[waIntersectionObservee]", never, {}, { "waIntersectionObservee": "waIntersectionObservee"; }, never, never, true, never>;
}
/**
 * @deprecated: use {@link WaIntersectionObservee}
 */
export declare const IntersectionObserveeDirective: typeof WaIntersectionObservee;
/**
 * @deprecated: use {@link WaIntersectionObservee}
 */
export declare const WaObservee: typeof WaIntersectionObservee;
