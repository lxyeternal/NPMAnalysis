import * as i0 from "@angular/core";
export declare class WaIntersectionRoot {
    static ɵfac: i0.ɵɵFactoryDeclaration<WaIntersectionRoot, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<WaIntersectionRoot, "[waIntersectionRoot]", never, {}, {}, never, never, true, never>;
}
/**
 * @deprecated: use {@link WaIntersectionRoot}
 */
export declare const IntersectionRootDirective: typeof WaIntersectionRoot;
