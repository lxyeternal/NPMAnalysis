import type { ElementRef } from '@angular/core';
import { InjectionToken } from '@angular/core';
export declare const WA_INTERSECTION_ROOT: InjectionToken<ElementRef<Element>>;
/**
 * @deprecated: drop in v5.0, use {@link WA_INTERSECTION_ROOT}
 */
export declare const INTERSECTION_ROOT: InjectionToken<ElementRef<Element>>;
