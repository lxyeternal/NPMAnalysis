import { InjectionToken } from '@angular/core';
export declare const WA_INTERSECTION_ROOT_MARGIN_DEFAULT = "0px 0px 0px 0px";
/**
 * @deprecated: drop in v5.0, use {@link WA_INTERSECTION_ROOT_MARGIN_DEFAULT}
 */
export declare const INTERSECTION_ROOT_MARGIN_DEFAULT = "0px 0px 0px 0px";
export declare const WA_INTERSECTION_ROOT_MARGIN: InjectionToken<string>;
/**
 * @deprecated: drop in v5.0, use {@link WA_INTERSECTION_ROOT_MARGIN}
 */
export declare const INTERSECTION_ROOT_MARGIN: InjectionToken<string>;
