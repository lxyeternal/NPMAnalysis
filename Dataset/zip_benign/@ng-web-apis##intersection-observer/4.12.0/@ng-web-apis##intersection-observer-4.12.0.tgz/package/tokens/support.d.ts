import { InjectionToken } from '@angular/core';
export declare const WA_INTERSECTION_OBSERVER_SUPPORT: InjectionToken<boolean>;
/**
 * @deprecated: drop in v5.0, use {@link WA_INTERSECTION_OBSERVER_SUPPORT}
 */
export declare const INTERSECTION_OBSERVER_SUPPORT: InjectionToken<boolean>;
