import { InjectionToken } from '@angular/core';
export declare const WA_INTERSECTION_THRESHOLD_DEFAULT = 0;
/**
 * @deprecated: drop in v5.0, use {@link WA_INTERSECTION_THRESHOLD_DEFAULT}
 */
export declare const INTERSECTION_THRESHOLD_DEFAULT = 0;
export declare const WA_INTERSECTION_THRESHOLD: InjectionToken<number | number[]>;
/**
 * @deprecated: drop in v5.0, use {@link WA_INTERSECTION_THRESHOLD}
 */
export declare const INTERSECTION_THRESHOLD: InjectionToken<number | number[]>;
