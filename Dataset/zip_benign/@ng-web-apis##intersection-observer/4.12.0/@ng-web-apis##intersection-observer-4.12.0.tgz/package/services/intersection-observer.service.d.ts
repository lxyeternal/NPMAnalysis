import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class IntersectionObserverService extends Observable<IntersectionObserverEntry[]> {
    private readonly nativeElement;
    private readonly rootMargin;
    private readonly threshold;
    private readonly root;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<IntersectionObserverService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IntersectionObserverService>;
}
