import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class IntersectionObserveeService extends Observable<IntersectionObserverEntry[]> {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<IntersectionObserveeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IntersectionObserveeService>;
}
