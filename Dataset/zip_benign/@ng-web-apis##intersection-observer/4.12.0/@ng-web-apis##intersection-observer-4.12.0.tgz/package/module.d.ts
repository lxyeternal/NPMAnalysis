import { WaIntersectionObservee } from './directives/intersection-observee.directive';
import { WaIntersectionObserverDirective } from './directives/intersection-observer.directive';
import { WaIntersectionRoot } from './directives/intersection-root.directive';
import * as i0 from "@angular/core";
import * as i1 from "./directives/intersection-observer.directive";
import * as i2 from "./directives/intersection-observee.directive";
import * as i3 from "./directives/intersection-root.directive";
export declare const WaIntersectionObserver: readonly [typeof WaIntersectionObserverDirective, typeof WaIntersectionObservee, typeof WaIntersectionRoot];
/**
 * @deprecated: use {@link WaIntersectionObserver}
 */
export declare class IntersectionObserverModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<IntersectionObserverModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<IntersectionObserverModule, never, [typeof i1.WaIntersectionObserverDirective, typeof i2.WaIntersectionObservee, typeof i3.WaIntersectionRoot], [typeof i1.WaIntersectionObserverDirective, typeof i2.WaIntersectionObservee, typeof i3.WaIntersectionRoot]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<IntersectionObserverModule>;
}
