export declare function thresholdFactory(): number[] | number;
