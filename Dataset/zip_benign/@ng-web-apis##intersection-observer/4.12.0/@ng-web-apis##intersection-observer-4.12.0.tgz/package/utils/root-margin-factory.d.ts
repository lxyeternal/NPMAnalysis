export declare function rootMarginFactory(): string;
