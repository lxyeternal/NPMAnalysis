export declare type StatementRunner = (statement: any) => number;
export declare type Statement = (left: any, right?: any) => StatementRunner;
export interface StatementHandler {
    [statement: string]: Statement;
}
export declare class Lexer {
    private _addop;
    private _mulop;
    private _powop;
    private _function1;
    private _function2;
    private _variable;
    private _number;
    private _open;
    private _close;
    private _calc;
    static parseArgument(arg: any, statement: any): any;
    private _calcLatex;
    private majorCommaIndex(_str);
    private majorOpIndex(_str);
    private _parseString(_str, createCtx?);
    private _parseStack(stack);
    parseString(str: string, context?: 'vm' | 'latex'): any;
    parseStringRep(stringrep: any): (values: any) => any;
    parseStringRepLatex(stringrep: any): any;
}
