import * as vm from 'flnf-jsvm';

export type StatementRunner = (statement: any) => number;
export type Statement = (left: any, right?: any) => StatementRunner;
export interface StatementHandler {
  [statement: string]: Statement;
}
export class Lexer {
  private _addop = '\\+|-';
  private _mulop = '\\*|/|%|\\!';
  private _powop = '\\^';
  private _function1 = 'sqrt|abs|ln|exp|factor';
  private _function2 = 'root|log|mod';
  private _variable = '[a-zA-Z](?:[a-zA-Z0-9])*';
  private _number = '\\d*(?:\\.\\d*)?';
  private _open = '\\(';
  private _close = '\\)';

  private _calc: StatementHandler = {
    idem: (left) => {
      return (statement) => {
        return Lexer.parseArgument(left, statement);
      };
    },
    plus: function (left, right) {
      return function (statement) {
        return Lexer.parseArgument(left, statement) + Lexer.parseArgument(right, statement);
      };
    },
    minus: function (left, right) {
      return function (statement) {
        return Lexer.parseArgument(left, statement) - Lexer.parseArgument(right, statement);
      };
    },
    times: function (left, right) {
      return function (statement) {
        return Lexer.parseArgument(left, statement) * Lexer.parseArgument(right, statement);
      };
    },
    div: function (left, right) {
      return function (statement) {
        return Lexer.parseArgument(left, statement) / Lexer.parseArgument(right, statement);
      };
    },
    mod: function (left, right) {
      return function (statement) {
        return Lexer.parseArgument(left, statement) % Lexer.parseArgument(right, statement);
      };
    },
    factor: (left) => {
      function factor(num) {
        if (num < 0) {
          return -1;
        } else if (num === 0) {
          return 1;
        } else {
          return num * factor(num - 1);
        }
      }
      return function (statement) {
        return factor(Lexer.parseArgument(left, statement));
      };
    },
    log: function (left, right) {
      return function (statement) {
        return Math.log(Lexer.parseArgument(left, statement)) / Math.log(Lexer.parseArgument(right, statement));
      };
    },
    ln: function (left) {
      return function (statement) {
        return Math.log(Lexer.parseArgument(left, statement));
      };
    },
    pow: function (left, right) {
      return function (statement) {
        return Math.pow(Lexer.parseArgument(left, statement), Lexer.parseArgument(right, statement));
      };
    },
    exp: function (left) {
      return function (statement) {
        return Math.exp(Lexer.parseArgument(left, statement));
      };
    },
    root: function (left, right) {
      return function (statement) {
        return Math.pow(Lexer.parseArgument(left, statement), 1 / Lexer.parseArgument(right, statement));
      };
    },
    sqrt: function (left) {
      return function (statement) {
        return Math.sqrt(Lexer.parseArgument(left, statement));
      };
    },
    abs: function (left) {
      return function (statement) {
        return Math.abs(Lexer.parseArgument(left, statement));
      };
    }
  };

  public static parseArgument(arg: any, statement: any) {
    let num;
    if (typeof arg === 'function') {
      num = arg(statement);
    } else if (!isNaN(parseFloat(arg)) && isFinite(arg)) {
      num = parseFloat(arg);
    } else {
      num = parseFloat(statement[arg]);
    }
    return num;
  }

  private _calcLatex = {
    idem: function (left) {
      if (!isNaN(parseFloat(left)) && isFinite(left)) {
        return ['' + parseFloat(left), 'i'];
      }

      return ['\\text{' + left + '}', 'i'];
    },
    plus: function (left, right) {
      let leftt, rightt;
      if (left[0] === '0' && right[0] === '0') {
        return ['0', 'i'];
      } else if (left[0] === '0') {
        return right;
      } else if (right[0] === '0') {
        return left;
      }

      if (left[1] !== '+' && left[1] !== '-' && left[1] !== 'func' && left[1] !== 'i') {
        leftt = '\\left(' + left[0] + '\\right)';
      } else {
        leftt = left[0];
      }

      if (right[1] !== '+' && right[1] !== '-' && right[1] !== 'func' && right[1] !== 'i') {
        rightt = ' + \\left(' + right[0] + '\\right)';
      } else if (right[0][0] === '-') {
        rightt = ' - ' + right[0].substring(1);
      } else {
        rightt = ' + ' + right[0];
      }

      return ['' + leftt + rightt, '+'];
    },
    minus: function (left, right) {
      let leftt, rightt;
      if (left[0] === '0' && right[0] === '0') {
        return ['0', 'i'];
      } else if (left === '0') {
        if (right[1] !== 'i' && right[1] !== 'func' && right[1] !== 'pow') {
          return ['-\\left(' + right[0] + '\\right)', 'i'];
        } else if (right[0][0] === '-') {
          return [right[0].substring(1), 'i'];
        }

        return ['-' + right[0], 'i'];
      } else if (right === '0') {
        return left;
      }

      if (left[1] === '*') {
        leftt = '\\left(' + left[0] + '\\right)';
      } else {
        leftt = left[0];
      }

      if (right[1] === 'pow' || right[1] === 'func') {
        rightt = ' - ' + right[0];
      } else if (right[0][0] === '-') {
        rightt = ' + ' + right[0].substring(1);
      } else {
        rightt = ' - \\left(' + right[0] + '\\right)';
      }

      return ['' + leftt + rightt, '-'];
    },
    times: function (left, right) {
      let leftt, rightt;

      if (left[0] === '-1') {
        if (right[1] !== 'i' && right[1] !== 'func' && right[1] !== 'pow') {
          return ['-\\left(' + right[0] + '\\right)', 'i'];
        } else if (right[0][0] === '-') {
          return [right.substring(1), 'i'];
        }

        return ['-' + right[0], 'i'];
      } else if (left[0] === '1') {
        return right;
      } else if (right[0] === '1') {
        return left;
      }

      if (left[1] === '+' || left[1] === '-') {
        leftt = '\\left(' + left[0] + '\\right)';
      } else {
        leftt = left[0];
      }

      if (right[1] === '+' || right[1] === '-') {
        rightt = '\\left(' + right[0] + '\\right)';
      } else {
        rightt = right[0];
      }

      return [leftt + ' \\cdot ' + rightt, '*'];
    },
    div: function (left, right) {
      if (right === '1') {
        return left;
      }

      return ['\\frac{' + left[0] + '}{' + right[0] + '}', 'func'];
    },
    mod: function (left, right) {
      if (right === '1') {
        return 0;
      }

      return ['' + left[0] + ' \\mod ' + right[0] + '', 'func'];
    },
    factor: function (left) {
      return ['{' + left[0] + '}!', 'func'];
    },
    log: function (left, right) {
      return ['\\log_{' + right[0] + '}\\left(' + left[0] + '\\right)', 'func'];
    },
    ln: function (left) {
      return ['\\ln\\left(' + left[0] + '\\right)', 'func'];
    },
    pow: function (left, right) {
      return ['\\left(' + left[0] + '\\right)^{' + right[0] + '}', 'pow'];
    },
    exp: function (left) {
      return ['e^{' + left[0] + '}', 'pow'];
    },
    Exp: function (left) {
      return ['e^{' + left[0] + '}', 'pow'];
    },
    root: function (left, right) {
      return ['\\sqrt[' + right[0] + ']{' + left[0] + '}', 'func'];
    },
    sqrt: function (left) {
      return ['\\sqrt{' + left[0] + '}', 'func'];
    },
    abs: function (left) {
      return ['\\left|' + left[0] + '\\right|', 'func'];
    }
  };

  private majorCommaIndex(_str: string) {
    let _ptr = 0;
    let _pcount = 0;
    let _comma = -1;
    const _len = _str.length;

    while (_ptr < _len) {
      if (_str[_ptr].match(new RegExp(this._open))) {
        _pcount++;
        _ptr++;
      } else if (_str[_ptr].match(new RegExp(this._close))) {
        _pcount--;
        _ptr++;
      } else if (_pcount === 0 && _str[_ptr] === ',') {
        if (_comma > -1) {
          return -1;
        } else {
          _comma = _ptr;
          _ptr++;
        }
      } else {
        _ptr++;
      }
    }

    return _comma;
  }

  private majorOpIndex(_str: string) {
    let _ptr = 0;
    const _len = _str.length;
    let _pcount = 0;
    let _mop = -1;
    let _moptype = null;
    let _match;

    while (_ptr < _len) {
      if (_str[_ptr].match(new RegExp(this._open))) {
        if (_pcount === 0 && _mop === -1) {
          _mop = _ptr;
          _moptype = 'Group';
        } else if (_pcount === 0 && _moptype === 'Group') {
          return [-1, null];
        }

        _pcount++;
        _ptr++;
      } else if (_str[_ptr].match(new RegExp(this._close))) {
        _pcount--;
        _ptr++;
      } else if (_pcount === 0) {
        const sstr = _str.substring(_ptr);
        if (sstr.match(new RegExp('^(?:' + this._addop + ')'))) {
          if (
            !(_moptype === 'AddOp' || _moptype === 'MulOp' || _moptype === 'PowOp') ||
            (_str.substring(_mop + 1, _ptr).match(/[^\s]/) &&
              !_str.substring(0, _ptr).match(new RegExp('(?:' + this._addop + '|' + this._mulop + '|' + this._powop + ')\\s*$')))
          ) {
            _mop = _ptr;
            _moptype = 'AddOp';
          }
          _ptr++;
        } else if (_moptype !== 'AddOp' && sstr.match(new RegExp('^(?:' + this._mulop + ')'))) {
          _mop = _ptr;
          _moptype = 'MulOp';
          _ptr++;
        } else if (_moptype !== 'AddOp' && _moptype !== 'MulOp' && sstr.match(new RegExp('^(?:' + this._powop + ')'))) {
          if (_moptype === 'PowOp') {
            return [-1, 'PowOp'];
          } else {
            _mop = _ptr;
            _moptype = 'PowOp';
            _ptr++;
          }
        } else if (
          _moptype !== 'AddOp' &&
          _moptype !== 'MulOp' &&
          _moptype !== 'PowOp' &&
          (_match = sstr.match(new RegExp('^(?:' + this._function1 + '|' + this._function2 + ')')))
        ) {
          if (_moptype === 'FuncOp') {
            return [-1, 'FuncOp'];
          } else {
            _mop = _ptr;
            _moptype = 'FuncOp';
            _ptr += _match[0].length;
          }
        } else {
          _ptr++;
        }
      } else {
        _ptr++;
      }
    }

    return [_mop, _moptype];
  }

  private _parseString(_str: string, createCtx?: boolean) {
    let _state = 'Start';
    const __stack = [];
    let _pointer = 0;
    let _majoropindex = -1;
    const _strlen = _str.length;
    let _accepted = false;

    const _statefuncs = {
      Start: fwdstring => {
        if (!fwdstring) {
          _state = 'Error';
          return;
        }

        if (fwdstring[0].match(/\s/)) {
          _pointer++;
          return;
        }

        const _majorop = this.majorOpIndex(fwdstring);

        if (_majorop[0] > -1) {
          _state = _majorop[1];
          _majoropindex = _majorop[0];
          return;
        } else if (_majorop[1]) {
          _state = 'Error';
          return;
        } else {
          if (fwdstring.match(new RegExp('^' + this._variable))) {
            _state = 'Variable';
            return;
          }

          if (fwdstring.match(new RegExp('^' + this._number))) {
            _state = 'Number';
            return;
          }
        }

        _state = 'Error';
        return;
      },
      Accept: () => {
        _accepted = true;
      },
      Error: () => {
        throw new Error();
      },
      Number: fwdstring => {
        const _match = fwdstring.match(new RegExp('^' + this._number));

        if (!_match || fwdstring.substring(_match[0].length).match(/[^\s]/)) {
          _state = 'Error';
          return;
        } else {
          const _num = parseFloat(_match[0]);
          __stack.push(['idem', _num]);
          _state = 'Accept';
          return;
        }
      },
      Variable: fwdstring => {
        const _match = fwdstring.match(new RegExp('^' + this._variable));

        if (!_match || fwdstring.substring(_match[0].length).match(/[^\s]/)) {
          _state = 'Error';
          return;
        } else {
          const _var = _match[0];
          __stack.push(['idem', '"' + _var + '"']);
          _state = 'Accept';
          return;
        }
      },
      AddOp: (fwdstring, opindex) => {
        const _left = fwdstring.substring(0, opindex);
        const _right = fwdstring.substring(opindex + 1);

        let optype;
        if (fwdstring[opindex] === '+') {
          optype = 'plus';
        } else if (fwdstring[opindex] === '-') {
          optype = 'minus';
        } else {
          _state = 'Error';
          return;
        }

        if (optype === 'minus' && !_left.match(/[^\s]/)) {
          __stack.push(['times', [['idem', '-1']], this._parseString(_right)]);
        } else {
          __stack.push([optype, this._parseString(_left), this._parseString(_right)]);
        }

        _state = 'Accept';
        return;
      },
      MulOp: (fwdstring, opindex) => {
        const _left = fwdstring.substring(0, opindex);
        const _right = fwdstring.substring(opindex + 1);

        let optype;
        if (fwdstring[opindex] === '*') {
          optype = 'times';
        } else if (fwdstring[opindex] === '/') {
          optype = 'div';
        } else if (fwdstring[opindex] === '%') {
          optype = 'mod';
        } else if (fwdstring[opindex] === '!') {
          optype = 'factor';
        } else {
          _state = 'Error';
          return;
        }
        if (optype === 'factor') {
          __stack.push([optype, this._parseString(_left)]);
        } else {
          __stack.push([optype, this._parseString(_left), this._parseString(_right)]);
        }
        _state = 'Accept';
        return;
      },
      PowOp: (fwdstring, opindex) => {
        const _left = fwdstring.substring(0, opindex);
        const _right = fwdstring.substring(opindex + 1);

        let optype;
        if (fwdstring[opindex] === '^') {
          optype = 'pow';
        } else {
          _state = 'Error';
          return;
        }

        __stack.push([optype, this._parseString(_left), this._parseString(_right)]);
        _state = 'Accept';
        return;
      },
      Group: fwdstring => {
        const _len = fwdstring.length;
        const _ends = fwdstring
          .split('')
          .reverse()
          .join('')
          .match(new RegExp('^[^' + this._close + ']*' + this._close));

        if (!_ends || fwdstring.substring(_len - _ends[0].length + 1).match(/[^\s]/)) {
          _state = 'Error';
          return;
        } else {
          const _inner = this._parseString(fwdstring.substring(1, _len - _ends[0].length));
          __stack.push(['Group', _inner]);
          _state = 'Accept';
          return;
        }
      },
      FuncOp: fwdstring => {
        let _match;
        let _inner;
        const _len = fwdstring.length;
        const _ends = fwdstring
          .split('')
          .reverse()
          .join('')
          .match(new RegExp('^[^' + this._close + ']*' + this._close));

        if (!_ends || fwdstring.substring(_len - _ends[0].length + 1).match(/[^\s]/)) {
          _state = 'Error';
          return;
        } else {
          _match = fwdstring.match('^(' + this._function1 + ')' + this._open);
          if (_match) {
            _inner = fwdstring.substring(_match[0].length, _len - _ends[0].length);
            __stack.push([_match[1], this._parseString(_inner)]);
            _state = 'Accept';
            return;
          } else {
            _match = fwdstring.match('^(' + this._function2 + ')' + this._open);
            if (_match) {
              _inner = fwdstring.substring(_match[0].length, _len - _ends[0].length);
              const mci = this.majorCommaIndex(_inner);
              if (mci > -1) {
                const _left = _inner.substring(0, mci);
                const _right = _inner.substring(mci + 1);

                __stack.push([_match[1], this._parseString(_left), this._parseString(_right)]);
                _state = 'Accept';
                return;
              } else {
                _state = 'Error';
                return;
              }
            } else {
              _state = 'Error';
              return;
            }
          }
        }
      }
    };

    while (!_accepted && _pointer <= _strlen) {
      _statefuncs[_state](_str.substring(_pointer), _majoropindex);
    }

    return __stack;
  }

  private _parseStack(stack) {
    let _res = '';

    stack.forEach(item => {
      if (item[0] === 'Group') {
        _res += '(' + this._parseStack(item[1]) + ')';
      } else if (item.length > 2 || (item[1] && item[1] instanceof Array)) {
        _res +=
          item[0] +
          '(' +
          item
            .slice(1)
            .map(arg => {
              return this._parseStack(arg);
            })
            .join(',') +
          ')';
      } else if (item.length === 2) {
        _res += item[0] + '(' + item[1] + ')';
      } else {
        throw new Error();
      }
    });

    return _res;
  }

  public parseString(str: string, context?: 'vm' | 'latex'): any {
    let _result = '';

    const _stack = this._parseString(str, true);
    _result = this._parseStack(_stack);

    if (context === 'vm') {
      return _result;
    } else if (context !== 'latex') {
      return this.parseStringRep(_result);
    } else {
      return this.parseStringRepLatex(_result);
    }
  }

  parseStringRep(stringrep) {
    const _resultfunc = vm.runInNewContext(stringrep, this._calc);

    return function (values) {
      values = Object.assign({ pi: Math.PI, e: Math.E }, values || {});
      return _resultfunc(values);
    };
  }

  parseStringRepLatex(stringrep) {
    return vm.runInNewContext(stringrep, this._calcLatex)[0];
  }
}
