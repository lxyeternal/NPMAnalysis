import { Lexer } from '../index';
import { expect } from 'chai';

function Hi5ve() {
  return 5;
}

describe('Lexer', () => {
  let lexer: Lexer;
  beforeEach(() => {
    lexer = new Lexer();
  });
  it('should be created', () => {
    expect(lexer instanceof Lexer).eq(true);
  });

  it(`pi = ${Math.PI}`, () => {
    expect(lexer.parseString('pi')()).eq(Math.PI);
  });

  it(`e = ${Math.E}`, () => {
    expect(lexer.parseString('e')()).eq(Math.E);
  });

  it(`(x + pi) = ${5 + Math.PI} where x = 5`, () => {
    expect(lexer.parseString('(x + pi)')({ x: 5 })).eq(5 + Math.PI);
  });

  it(`(x + e) = ${5 + Math.E} where x = 5`, () => {
    expect(lexer.parseString('(x + e)')({ x: 5 })).eq(5 + Math.E);
  });

  it('10 + 10 = 20', () => {
    expect(lexer.parseString('10 + 10')()).eq(20);
  });

  it('10 + (5 + x) = 20 where x = 5', () => {
    expect(lexer.parseString('10 + (5 + x)')({ x: 5 })).eq(20);
  });

  it('10 - 10 = 0', () => {
    expect(lexer.parseString('10 - 10')()).eq(0);
  });

  it('10 - (5 + x) = 0 where x = 5', () => {
    expect(lexer.parseString('10 - (5 + x)')({ x: 5 })).eq(0);
  });

  it('(10 + 10) * 2 = 40', () => {
    expect(lexer.parseString('(10 + 10) * 2')()).eq(40);
  });

  it('9 ^ (1 / 2) = 3', () => {
    expect(lexer.parseString('9^(1/2)')()).eq(3);
  });

  it('9 ^ 0.5 = 3', () => {
    expect(lexer.parseString('9^(1/2)')()).eq(3);
  });

  it('sqrt(9) = 3', () => {
    expect(lexer.parseString('sqrt(9)')()).eq(3);
  });

  it('(mod(10, 2)) = 1', () => {
    expect(lexer.parseString('mod(10, 2)')()).eq(0);
  });

  it('11 % 4 = 3', () => {
    expect(lexer.parseString('mod(11, 4)')()).eq(3);
  });

  it('abs(root(27, 3)) = 3', () => {
    expect(lexer.parseString('abs(root(27, 3))')()).eq(3);
  });

  it('factor(-1) + 1 = 0', () => {
    expect(lexer.parseString('factor(-1) + 1')()).eq(0);
  });

  it('factor(-10) + 1 = 0', () => {
    expect(lexer.parseString('factor(-10) + 1')()).eq(0);
  });

  it('factor(0) + 1 = 2', () => {
    expect(lexer.parseString('factor(0) + 1')()).eq(2);
  });

  it('factor(5) + 1 = 121', () => {
    expect(lexer.parseString('factor(5) + 1')()).eq(121);
  });

  it(`log(5, 10) = ${Math.log(5) / Math.log(10)}`, () => {
    expect(lexer.parseString('log(5, 10)')()).eq(Math.log(5) / Math.log(10));
  });

  it(`ln(5) = ${Math.log(5)}`, () => {
    expect(lexer.parseString('ln(5)')()).eq(Math.log(5));
  });

  it(`exp(5) = ${Math.exp(5)}`, () => {
    expect(lexer.parseString('exp(5)')()).eq(Math.exp(5));
  });

  it(`e^5 = ${Math.pow(Math.E, 5)}`, () => {
    expect(lexer.parseString('e^5')()).eq(Math.pow(Math.E, 5));
  });
});

describe('Lexer / forContext', () => {
  let lexer: Lexer;
  beforeEach(() => {
    lexer = new Lexer();
  });
  it('should be created', () => {
    expect(lexer instanceof Lexer).eq(true);
  });

  it('10 + 10 = 20', () => {
    expect(lexer.parseString('10 + 10', 'vm')).eq('plus(idem(10),idem(10))');
  });

  it('10 + (5 + x) = 20 where x = 5', () => {
    expect(lexer.parseString('10 + (5 + x)', 'vm')).eq('plus(idem(10),(plus(idem(5),idem("x"))))');
  });

  it('10 - 10 = 0', () => {
    expect(lexer.parseString('10 - 10', 'vm')).eq('minus(idem(10),idem(10))');
  });

  it('10 - (5 + x) = 0 where x = 5', () => {
    expect(lexer.parseString('10 - (5 + x)', 'vm')).eq('minus(idem(10),(plus(idem(5),idem("x"))))');
  });

  it('(10 + 10) * 2 = 40', () => {
    expect(lexer.parseString('(10 + 10) * 2', 'vm')).eq('times((plus(idem(10),idem(10))),idem(2))');
  });

  it('9 ^ (1 / 2) = 3', () => {
    expect(lexer.parseString('9^(1/2)', 'vm')).eq('pow(idem(9),(div(idem(1),idem(2))))');
  });

  it('9 ^ 0.5 = 3', () => {
    expect(lexer.parseString('9^(1/2)', 'vm')).eq('pow(idem(9),(div(idem(1),idem(2))))');
  });

  it('sqrt(9) = 3', () => {
    expect(lexer.parseString('sqrt(9)', 'vm')).eq('sqrt(idem(9))');
  });

  it('(mod(10, 2)) = 1', () => {
    expect(lexer.parseString('mod(10, 2)', 'vm')).eq('mod(idem(10),idem(2))');
  });

  it('11 % 4 = 3', () => {
    expect(lexer.parseString('mod(11, 4)', 'vm')).eq('mod(idem(11),idem(4))');
  });

  it('abs(root(27, 3)) = 3', () => {
    expect(lexer.parseString('abs(root(27, 3))', 'vm')).eq('abs(root(idem(27),idem(3)))');
  });

  it('factor(-1) + 1 = 0', () => {
    expect(lexer.parseString('factor(-1) + 1', 'vm')).eq('plus(factor(times(idem(-1),idem(1))),idem(1))');
  });

  it('factor(-10) + 1 = 0', () => {
    expect(lexer.parseString('factor(-10) + 1', 'vm')).eq('plus(factor(times(idem(-1),idem(10))),idem(1))');
  });

  it('factor(0) + 1 = 2', () => {
    expect(lexer.parseString('factor(0) + 1', 'vm')).eq('plus(factor(idem(0)),idem(1))');
  });

  it('factor(5) + 1 = 121', () => {
    expect(lexer.parseString('factor(5) + 1', 'vm')).eq('plus(factor(idem(5)),idem(1))');
  });

  it(`log(5, 10) = ${Math.log(5) / Math.log(10)}`, () => {
    expect(lexer.parseString('log(5, 10)', 'vm')).eq('log(idem(5),idem(10))');
  });

  it(`ln(5) = ${Math.log(5)}`, () => {
    expect(lexer.parseString('ln(5)', 'vm')).eq('ln(idem(5))');
  });

  it(`exp(5) = ${Math.exp(5)}`, () => {
    expect(lexer.parseString('exp(5)', 'vm')).eq('exp(idem(5))');
  });

  it(`e^5 = ${Math.pow(Math.E, 5)}`, () => {
    expect(lexer.parseString('e^5', 'vm')).eq('pow(idem("e"),idem(5))');
  });
});

describe('Lexer / LaTeX', () => {
  let lexer: Lexer;
  beforeEach(() => {
    lexer = new Lexer();
  });
  it('should be created', () => {
    expect(lexer instanceof Lexer).eq(true);
  });

  it('10 + 10 = 20', () => {
    expect(lexer.parseString('10 + 10', 'latex')).eq('10 + 10');
  });

  it('0 + 10 = 10', () => {
    expect(lexer.parseString('0 + 10', 'latex')).eq('10');
  });

  it('10 + 0 = 10', () => {
    expect(lexer.parseString('0 + 10', 'latex')).eq('10');
  });

  it('10 + (5 + x) = 20 where x = 5', () => {
    expect(lexer.parseString('10 + (5 + x)', 'latex')).eq('10 + 5 + \\text{x}');
  });

  it('10 - 10 = 0', () => {
    expect(lexer.parseString('10 - 10', 'latex')).eq('10 - \\left(10\\right)');
  });

  it('10 - (5 + x) = 0 where x = 5', () => {
    expect(lexer.parseString('10 - (5 + x)', 'latex')).eq('10 - \\left(5 + \\text{x}\\right)');
  });

  it('(10 + 10) * 2 = 40', () => {
    expect(lexer.parseString('(10 + 10) * 2', 'latex')).eq('\\left(10 + 10\\right) \\cdot 2');
  });

  it('9 ^ (1 / 2) = 3', () => {
    expect(lexer.parseString('9^(1/2)', 'latex')).eq('\\left(9\\right)^{\\frac{1}{2}}');
  });

  it('9 ^ 0.5 = 3', () => {
    expect(lexer.parseString('9^(1/2)', 'latex')).eq('\\left(9\\right)^{\\frac{1}{2}}');
  });

  it('sqrt(9) = 3', () => {
    expect(lexer.parseString('sqrt(9)', 'latex')).eq('\\sqrt{9}');
  });

  it('(mod(10, 2)) = 1', () => {
    expect(lexer.parseString('mod(10, 2)', 'latex')).eq('10 \\mod 2');
  });

  it('11 % 4 = 3', () => {
    expect(lexer.parseString('mod(11, 4)', 'latex')).eq('11 \\mod 4');
  });

  it('abs(root(27, 3)) = 3', () => {
    expect(lexer.parseString('abs(root(27, 3))', 'latex')).eq('\\left|\\sqrt[3]{27}\\right|');
  });

  it('factor(-1) + 1 = 0', () => {
    expect(lexer.parseString('factor(-1) + 1', 'latex')).eq('{-1}! + 1');
  });

  it('factor(-10) + 1 = 0', () => {
    expect(lexer.parseString('factor(-10) + 1', 'latex')).eq('{-10}! + 1');
  });

  it('factor(0) + 1 = 2', () => {
    expect(lexer.parseString('factor(0) + 1', 'latex')).eq('{0}! + 1');
  });

  it('factor(5) + 1 = 121', () => {
    expect(lexer.parseString('factor(5) + 1', 'latex')).eq('{5}! + 1');
  });

  it(`log(5, 10) = ${Math.log(5) / Math.log(10)}`, () => {
    expect(lexer.parseString('log(5, 10)', 'latex')).eq('\\log_{10}\\left(5\\right)');
  });

  it(`ln(5) = ${Math.log(5)}`, () => {
    expect(lexer.parseString('ln(5)', 'latex')).eq('\\ln\\left(5\\right)');
  });

  it(`exp(5) = ${Math.exp(5)}`, () => {
    expect(lexer.parseString('exp(5)', 'latex')).eq('e^{5}');
  });

  it(`e^5 = ${Math.pow(Math.E, 5)}`, () => {
    expect(lexer.parseString('e^5', 'latex')).eq('\\left(\\text{e}\\right)^{5}');
  });
});
