export declare class NouisliderModule {
}
