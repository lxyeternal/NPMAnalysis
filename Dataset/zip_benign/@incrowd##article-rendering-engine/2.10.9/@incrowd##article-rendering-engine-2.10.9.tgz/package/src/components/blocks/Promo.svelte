{#await promoPromise then c}
<ContentBlock content={c}/>
{/await}

<script>
import {getContext} from 'svelte'
import ContentBlock from '../ContentBlock.svelte'

export let content

const article = getContext('article')
const accessToken = getContext('accessToken')
const campaignApiUrl = getContext('campaignApiUrl')

let headers = {
	'Content-Type': 'application/json',
	'Accept-Language': article.language
}
if (accessToken) headers.Authorization = 'Bearer ' + accessToken
let promoPromise = fetch(`${campaignApiUrl}/${article.clientId}/campaigns/content/${content.sourceSystemId}`, {
	headers
}).then(r => r.json()).then(r => {
	if (r.status === 'success' && r.data) {
		return r.data
	} else {
		const msg = r.message || 'Something went wrong'
		console.error(`Failed to execute campaign: ${msg}`)
		throw msg
	}
})
</script>
