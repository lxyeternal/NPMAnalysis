<BlockBase isRatio16By9={true}>
	{#if content.link}
	<a href={content.link} target="_blank">
		<div class="icare-image" style={`background-image:url(${content.image});height:100%;width:100%;background-size:contain;background-position:center;background-repeat:no-repeat;`}></div>
	</a>
	{:else}
	<div class="icare-image" style={`background-image:url(${content.image});height:100%;width:100%;background-size:contain;background-position:center;background-repeat:no-repeat;`}></div>
	{/if}
</BlockBase>

<script>
import BlockBase from '../BlockBase.svelte'

export let content
</script>
