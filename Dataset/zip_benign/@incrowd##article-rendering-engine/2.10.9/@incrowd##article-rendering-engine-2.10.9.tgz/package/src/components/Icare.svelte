{#if article}
<div id={icareId} class="icare">
	{#if article.heroMedia.content}
	<ContentBlock content={article.heroMedia.content}/>
	{/if}
	<div class="icare-body">
		<h1>{article.heroMedia.title}</h1>
		<div class="icare-metadata">
			{#if article.author && article.author.imageUrl}
			<img src={article.author.imageUrl} alt={article.author.name}>
			{/if}
			<div style="margin: auto 0;">
				{#if article.author && article.author.name}
				<p>{article.author.name}</p>
				{/if}
				<p>{publishDate} · {article.readTimeMinutes} min read</p>
			</div>
		</div>
		{#if article.content && article.content.length}
			{#each article.content as c}
			{#if c.contentType === 'PROMO'}
			<Promo content={c}/>
			{:else}
			<ContentBlock content={c}/>
			{/if}
			{/each}
		{/if}
		{#if showFooterAuthor}
		<FooterAuthor author={article.author}/>
		{/if}
	</div>
</div>
{/if}

<script>
import {onMount, setContext} from 'svelte'
import {uuid} from '../util.js'
import ContentBlock from './ContentBlock.svelte'
import Promo from './blocks/Promo.svelte'
import FooterAuthor from './FooterAuthor.svelte'

export let article
export let accessToken = null
export let apiUrl = 'https://article-cms-api.incrowdsports.com/v2/articles'
export let campaignApiUrl = 'https://promoblocks-cms-api.incrowdsports.com/v1'
export let onRelatedContentClick = () => {}
let icareId = uuid()

setContext('article', article)
setContext('accessToken', accessToken)
setContext('apiUrl', apiUrl)
setContext('campaignApiUrl', campaignApiUrl)
setContext('onRelatedContentClick', onRelatedContentClick)

$: publishDate = article && article.publishDate ? new Intl.DateTimeFormat('en-GB', {
	day: 'numeric',
	month: 'short',
	year: 'numeric'
}).format(new Date(article.publishDate)) : ''
$: showFooterAuthor = article.author && (article.author.name || article.author.title || article.author.imageUrl)

onMount(reloadScript)

function reloadScript () {
	let reloadableScripts = [
		{
			id: 'twitter-widgets',
			src: 'https://platform.twitter.com/widgets.js',
			needReload: false,
			callback: () => {
				twttr.widgets.load(document.getElementById(icareId))
			}
		}
	]
	const scripts = document.getElementsByTagName('script')
	for (let i = (scripts?.length - 1); i >= 0; i--) {
		const sIndex = reloadableScripts.findIndex(x => x.src === scripts[i].src)
		if (sIndex > -1) {
			reloadableScripts[sIndex].needReload = true
			if (scripts[i].id !== reloadableScripts[sIndex].id) {
				scripts[i].parentNode.removeChild(scripts[i])
			}
		}
	}
	reloadableScripts.forEach(script => {
		if (script.needReload) loadDynamicScript(script.id, script.src, script.callback)
	})
}

function loadDynamicScript (id, src, callback) {
	const existingScript = document.getElementById(id)
	if (!existingScript) {
		const script = document.createElement('script')
		script.id = id
		script.src = src
		document.body.appendChild(script)
		script.onload = () => {
			if (callback) callback()
		}
	}
	if (existingScript && callback) callback()
}
</script>
