<BlockBase>
	{#if title}
	<h2>{title}</h2>
	{/if}
	{#if relatedContent.length}
	<ul class="icare-related-content-list">
		{#each relatedContent as c}
		<li class="icare-related-content-list-item" on:click={() => { onRelatedContentClick(c) }}>{c.heroMedia.title}</li>
		{/each}
	</ul>
	{/if}
</BlockBase>

<script>
import {getContext} from 'svelte'
import BlockBase from '../BlockBase.svelte'

export let content
const {title, tags, categoryIds, linkedIds, articleIds} = content

const clientId = getContext('article').clientId
const apiUrl = getContext('apiUrl')
const onRelatedContentClick = getContext('onRelatedContentClick')

const baseUrl = `${apiUrl}?clientId=${clientId}`
let promises = []
let relatedContent = []
function fetchContent (url) {
	return fetch(url).then(r => r.json())
}
if ((tags && tags.length) || (categoryIds && categoryIds.length) || (linkedIds && linkedIds.length)) {
	let url = baseUrl
	if (tags && tags.length) url += `&tags=${tags.join(',')}`
	if (categoryIds && categoryIds.length) url += `&categoryId=${categoryIds.join(',')}`
	promises = promises.concat(linkedIds && linkedIds.length ? linkedIds.map(x => {
		const scopedUrl = `${url}&linkedId.sourceSystem=${x.sourceSystem}&linkedId.sourceSystemId=${x.sourceSystemId}`
		return fetchContent(scopedUrl)
	}) : [fetchContent(url)])
}
if (articleIds && articleIds.length) {
	promises = promises.concat([
		fetchContent(`${baseUrl}&articleId=${articleIds.join(',')}`)
	])
}
Promise.all(promises).then(values => {
	relatedContent = values.reduce((arr, v) => {
		return v && v.data && v.data.articles ? arr.concat(v.data.articles) : arr
	}, []).filter((c, i, arr) => arr.findIndex(x => x.id === c.id) === i)
})
</script>
