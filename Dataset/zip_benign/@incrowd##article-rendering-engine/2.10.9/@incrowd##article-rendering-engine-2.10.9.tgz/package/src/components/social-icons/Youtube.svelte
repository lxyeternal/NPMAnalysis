<svg class="icare-social-icon" viewBox="0 0 256 256">
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <path d="M162.476068,131.460499 L95.8273075,163.732069 C94.0513818,164.591957 92,163.277434 92,161.280153 L92,94.7198727 C92,92.6941437 94.1053099,91.3812308 95.8849365,92.2969419 L162.533697,126.585652 C164.51529,127.604958 164.480924,130.490038 162.476068,131.460499 Z" fill="#FFFFFF" fill-rule="nonzero"></path>
        <circle fill="#F61C0D" fill-rule="nonzero" cx="128" cy="128" r="128"></circle>
        <polygon fill="#FFFFFF" fill-rule="nonzero" points="92 80 92 176 176 129.106291"></polygon>
    </g>
</svg>
