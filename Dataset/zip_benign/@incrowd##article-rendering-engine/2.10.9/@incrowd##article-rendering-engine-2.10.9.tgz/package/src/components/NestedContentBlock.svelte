<svelte:component this={blocks[content.contentType]} {content}/>

<script>
import {setContext} from 'svelte'
import {uuid} from '../util.js'
import IMAGE from './blocks/Image.svelte'
import POLL from './blocks/Poll.svelte'
import QUOTE from './blocks/Quote.svelte'
import RELATED_CONTENT from './blocks/RelatedContent.svelte'
import TEXT from './blocks/Text.svelte'
import VIDEO from './blocks/Video.svelte'

const blocks = {
	IMAGE,
	POLL,
	QUOTE,
	RELATED_CONTENT,
	TEXT,
	VIDEO
}

export let content
setContext('content', content)
setContext('contentBlockUuid', uuid())
</script>
