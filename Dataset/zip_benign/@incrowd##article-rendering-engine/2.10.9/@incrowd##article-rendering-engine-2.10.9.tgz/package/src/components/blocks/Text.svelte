<BlockBase>
	<div class="icare-text">{@html html}</div>
</BlockBase>

<script>
import BlockBase from '../BlockBase.svelte'
import marked from 'marked'

export let content

let html = ''
if (content.content) {
	let renderer = new marked.Renderer()
	renderer.link = function (href, title, text) {
		let link = marked.Renderer.prototype.link.apply(this, arguments)
		return link.replace("<a","<a target='_blank'")
	}
	marked.setOptions({renderer})
	html = marked(content.content)
}
</script>
