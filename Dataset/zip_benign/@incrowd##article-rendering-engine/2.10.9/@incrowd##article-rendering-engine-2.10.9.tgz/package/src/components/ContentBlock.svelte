<svelte:component this={blocks[content.contentType]} {content}/>

<script>
import {setContext} from 'svelte'
import {uuid} from '../util.js'
import CLOUD_MATRIX from './blocks/CloudMatrix.svelte'
import GALLERY from './blocks/Gallery.svelte'
import IMAGE from './blocks/Image.svelte'
import POLL from './blocks/Poll.svelte'
import QUOTE from './blocks/Quote.svelte'
import RELATED_CONTENT from './blocks/RelatedContent.svelte'
import TEXT from './blocks/Text.svelte'
import VIDEO from './blocks/Video.svelte'
import PROMO from "./blocks/Promo.svelte";

const blocks = {
	CLOUD_MATRIX,
	GALLERY,
	IMAGE,
	POLL,
	QUOTE,
	RELATED_CONTENT,
	TEXT,
	VIDEO,
	PROMO
}

export let content
setContext('content', content)
setContext('contentBlockUuid', uuid())
</script>
