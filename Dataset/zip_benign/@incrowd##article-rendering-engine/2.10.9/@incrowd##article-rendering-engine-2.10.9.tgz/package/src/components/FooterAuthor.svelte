<div class="icare-footer-author">
	{#if author.imageUrl}<img class="icare-footer-author-image" src={author.imageUrl} alt={author.name || author.imageUrl}>{/if}
	<div style="margin: auto 0;">
		{#if author.name}
		<p class="icare-footer-author-name">{author.name}</p>
		{/if}
		{#if author.title}
		<p class="icare-footer-author-title">{author.title}</p>
		{/if}
		{#if author.socialHandles && author.socialHandles.length}
		<div style="display: flex;">
			{#each author.socialHandles as s}
			<a target="_blank" href={s.link} title={s.handle}>
				<svelte:component this={icons[s.provider]}/>
			</a>
			{/each}
		</div>
		{/if}
	</div>
</div>

<script>
import FACEBOOK from './social-icons/Facebook.svelte'
import LINKEDIN from './social-icons/Linkedin.svelte'
import PINTEREST from './social-icons/Pinterest.svelte'
import REDDIT from './social-icons/Reddit.svelte'
import TWITCH from './social-icons/Twitch.svelte'
import TWITTER from './social-icons/Twitter.svelte'
import WHATSAPP from './social-icons/Whatsapp.svelte'
import YOUTUBE from './social-icons/Youtube.svelte'

const icons = {
	FACEBOOK,
	LINKEDIN,
	PINTEREST,
	REDDIT,
	TWITCH,
	TWITTER,
	WHATSAPP,
	YOUTUBE
}

export let author
</script>
