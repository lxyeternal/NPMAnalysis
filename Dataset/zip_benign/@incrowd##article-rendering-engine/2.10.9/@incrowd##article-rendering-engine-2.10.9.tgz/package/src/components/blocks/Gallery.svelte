<BlockBase>
	{#if content.title}
	<h2>{content.title}</h2>
	{/if}
	<div class="icare-gallery" style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;grid-gap:0 0.5rem;">
		{#each content.children as child}
		<NestedContentBlock content={child}/>
		{/each}
	</div>
</BlockBase>

<script>
import BlockBase from '../BlockBase.svelte'
import NestedContentBlock from '../NestedContentBlock.svelte'

export let content
</script>
