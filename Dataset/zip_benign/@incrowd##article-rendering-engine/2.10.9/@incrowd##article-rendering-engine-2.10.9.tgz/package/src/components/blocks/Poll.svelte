<BlockBase>
	<iframe src={`https://polls-widget.fanscore.com/?clientId=${clientId}&pollId=${content.pollId}`} scrolling="no" title="Poll" style="width: 300px; height: 250px; border: 0px;"></iframe>
</BlockBase>

<script>
import {getContext} from 'svelte'
import BlockBase from '../BlockBase.svelte'

export let content

const clientId = getContext('article').clientId
</script>
