<svg class="icare-social-icon" viewBox="0 0 256 256">
    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <circle fill="#673AB7" fill-rule="nonzero" cx="128" cy="128" r="128"></circle>
        <g transform="translate(68.000000, 64.000000)" fill="#FFFFFF" fill-rule="nonzero">
            <path d="M8,0 L0,24 L0,112 L32,112 L32,128 L48,128 L64,112 L88,112 L120,77.92 L120,0 L8,0 Z M112,72 L89.6,96 L61.232,96 L44,108.536 L44,96 L16,96 L16,8 L112,8 L112,72 Z"></path>
            <rect x="56" y="32" width="8" height="32"></rect>
            <rect x="80" y="32" width="8" height="32"></rect>
        </g>
    </g>
</svg>
