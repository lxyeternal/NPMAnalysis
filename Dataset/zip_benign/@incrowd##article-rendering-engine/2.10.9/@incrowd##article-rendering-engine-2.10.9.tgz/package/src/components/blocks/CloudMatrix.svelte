<BlockBase>
	<div class="icare-cm">
		<div class="icare-cm-video-column">
			{#if activeStream}
			<NestedContentBlock content={activeStream}/>
			{/if}
		</div>
		<div class="icare-cm-playlist-column">
			<div class="icare-cm-playlist-container">
				{#if title}
				<p class="icare-cm-playlist-title">{title}</p>
				{/if}
				{#if feed}
				<div class="icare-cm-playlist">
					{#each feed.itemData as item, index}
					<div class="icare-cm-playlist-item"
					class:icare-cm-playlist-item-active={item.mediaData.entryId === activeStream.sourceSystemId}
					on:click={() => openStream(item)}>
						<p>{index + 1}</p>
						<img src={item.mediaData.thumbnailUrl} alt={item.metaData.title}>
						<p>{item.metaData.title}</p>
					</div>
					{/each}
				</div>
				{/if}
			</div>
		</div>
	</div>
</BlockBase>

<script>
import {getContext} from 'svelte'
import BlockBase from '../BlockBase.svelte'
import NestedContentBlock from '../NestedContentBlock.svelte'

export let content
let feed

const contentBlockUuid = getContext('contentBlockUuid')

$: title = content.title || (feed ? feed.metaData.title : null)

fetch(content.feedUrl).then(r => r.json()).then(r => {
	if (r.metaData && r.itemData) {
		feed = r
		openStream(r.itemData[0])
	} else {
		console.error('Failed to fetch Cloud Matrix feed: Something went wrong')
	}
})

let activeStream
function openStream (item) {
	if (!activeStream || activeStream.sourceSystemId !== item.mediaData.entryId) {
		activeStream = {
			contentType: 'VIDEO',
			sourceSystem: 'STREAM',
			sourceSystemId: item.mediaData.entryId
		}
		document.getElementById(contentBlockUuid).scrollIntoView()
	}
}
</script>
