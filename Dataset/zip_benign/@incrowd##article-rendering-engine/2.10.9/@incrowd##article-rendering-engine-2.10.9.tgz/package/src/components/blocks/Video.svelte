<BlockBase isRatio16By9={true}>
	{#if content.sourceSystem === 'YOUTUBE'}
		<iframe class="icare-video-youtube" style="height:100%;width:100%;" src={`https://www.youtube.com/embed/${content.sourceSystemId}`} title="youtube" frameborder="0" allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	{:else if content.sourceSystem === 'MEDIA'}
		<video 
			class="icare-video-media" 
			controls 
			style="height:100%;width:100%;display:block;" 
			src={content.link}
		>
			<track kind="captions">	
		</video>
	{/if}
</BlockBase>

<script>
import {getContext} from 'svelte'
import BlockBase from '../BlockBase.svelte'

export let content

const accessToken = getContext('accessToken')
const clientId = getContext('article').clientId
const contentBlockUuid = getContext('contentBlockUuid')

let partnerId
let uiConfId
let authUrl

if (content.sourceSystem === 'STREAM') {
	fetchClientService().then(async d => {
		if (d.services.content.video && d.services.content.video.providers && d.services.content.video.providers.length) {
			const provider = d.services.content.video.providers.find(p => p.name === 'STREAM')
			if (provider) {
				partnerId = provider.config.partnerId
				uiConfId = provider.config.uiConfId
				authUrl = provider.config.authUrl
				let script = document.createElement('script')
				script.src = `https://open.http.mp.streamamg.com/p/${partnerId}/sp/${partnerId}00/embedIframeJs/uiconf_id/${uiConfId}/partner_id/${partnerId}`
				document.getElementById(contentBlockUuid).append(script)
				script.onload = loadStream
			}
		}
	})
}
function fetchClientService () {
	return fetch(`https://feeds.incrowdsports.com/provider/client-service/v1/clients/${clientId}`).then(r => r.json()).then(r => {
		if (r.status === 'success' && r.data) {
			return r.data
		} else {
			const msg = r.message || 'Something went wrong'
			console.error(`Failed to fetch client service config: ${msg}`)
			throw msg
		}
	})
}
function fetchKSession (authUrl) {
	return fetch(`${authUrl}/?entryid=${content.sourceSystemId}&apijwttoken=${accessToken}`).then(r => r.json()).then(r => {
		return r.KSession
	}).catch(err => undefined)
}
async function loadStream () {
	let ks
	if (authUrl) ks = await fetchKSession(authUrl)
	if (window.kWidget) {
		window.kWidget.embed({
			targetId: contentBlockUuid,
			wid: `_${partnerId}`,
			uiconf_id: uiConfId,
			entry_id: content.sourceSystemId,
			flashvars: {ks}
		})
	}
}

$: {
	if (content.sourceSystem === 'STREAM' && partnerId && uiConfId && window.kWidget) {
		window.kWidget.destroy(contentBlockUuid)
		loadStream()
	}
}
</script>
