<BlockBase>
	<blockquote class="icare-quote">
		<p class="icare-quote-text">{content.text}</p>
		<footer class="icare-quote-footer">
			{#if content.author}<p class="icare-quote-author">{content.author}</p>{/if}
			{#if content.title}<p class="icare-quote-title">{content.title}</p>{/if}
		</footer>
	</blockquote>
</BlockBase>

<script>
import BlockBase from '../BlockBase.svelte'

export let content
</script>
