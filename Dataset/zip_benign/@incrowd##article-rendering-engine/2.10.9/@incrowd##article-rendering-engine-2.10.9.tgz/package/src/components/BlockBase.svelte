{#if content.sponsor && content.sponsor.imageUrl}
<div class="icare-content-block-sponsor">
	<span>Presented by</span>
	{#if content.sponsor.linkUrl}
	<a target="_blank" href={content.sponsor.linkUrl}><img src={content.sponsor.imageUrl} alt="sponsor"></a>
	{:else}
	<div><img src={content.sponsor.imageUrl} alt="sponsor"></div>
	{/if}
</div>
{/if}
<div class="icare-content-block" style={`position:relative;width:100%;${isRatio16By9?'padding-bottom:56.25%;':''}`}>
	<div id={contentBlockUuid} style={isRatio16By9?'position:absolute;top:0;right:0;bottom:0;left:0;':'display:flex;flex-direction:column;'}>
		<slot/>
	</div>
</div>

<script>
import {getContext} from 'svelte'

export let isRatio16By9 = false

const content = getContext('content')
const contentBlockUuid = getContext('contentBlockUuid')
</script>
