# InCrowd Article Rendering Engine (ICARE)

A component for rendering article from the CMS.

## Motivation

To reuse this component across all web apps.

## Getting Started

`npm i @incrowd/article-rendering-engine`

Then import `@incrowd/article-rendering-engine/public/icare_example.css` in global scope.

```css
/* .icare {} */
.icare * {
	box-sizing: border-box;
}
.icare-body {
	padding: 0 1rem 1rem;
}
.icare h1 {
	font-size: 2rem;
	font-weight: bold;
	margin-bottom: 1.5rem;
}
.icare h2 {
	font-size: 1.5rem;
	font-weight: 500;
	margin-bottom: 1rem;
}
.icare-metadata {
	display: flex;
	margin-bottom: 1rem;
}
.icare-metadata img {
	width: 3.5rem;
	height: 3.5rem;
	margin-right: 0.5rem;
	border-radius: 9999px;
}
.icare-metadata p {
	margin: 0.25rem 0;
}
.icare-content-block {
	margin-bottom: 1rem;
}
.icare-content-block-sponsor {
	display: flex;
}
.icare-content-block-sponsor span {
	font-size: 0.875rem;
	margin-top: auto;
	margin-bottom: auto;
	margin-right: 0.5rem;
}
.icare-content-block-sponsor img {
	height: 2rem;
}
/* .icare-image {} */
/* .icare-video-youtube {} */
/* .icare-video-media {} */
.icare-text * {
	margin-bottom: 1rem;
}
.icare-text iframe {
	width: 100%;
	display: block;
}
/* .icare-gallery {} */
.icare-quote {
	margin: 0 auto;
	padding: 1.5rem 0 0 2rem;
	font-weight: 700;
}
.icare-quote-text::before {
	content: '\201C';
	font-size: 4rem;
	position: absolute;
	left: -2rem;
	top: -2rem;
}
.icare-quote-text {
	position: relative;
	font-size: 1.25rem;
	text-align: center;
	margin: 0;
}
.icare-quote-footer {
	text-transform: uppercase;
	text-align: right;
	margin-top: 0.5rem;
}
.icare-quote-author::before {
	content: "\2013\00A0";
}
.icare-quote-author {
	margin: 0;
}
.icare-quote-title {
	margin: 0;
	font-size: 0.5rem;
	opacity: 0.5;
}
.icare-cm {
	display: grid;
	grid-gap: 0.5rem;
	grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
}
.icare-cm-video-column {
	grid-column: auto / span 2;
	display: flex;
}
.icare-cm-playlist-column {
	display: flex;
	margin-bottom: 1rem;
}
.icare-cm-playlist-container {
	width: 100%;
	outline: 1px solid grey;
	display: flex;
	flex-direction: column;
}
.icare-cm-playlist-title {
	margin: 0.5rem;
	font-size: 1.25rem;
	font-weight: 500;
}
.icare-cm-playlist {
	outline: 1px solid grey;
	flex: 1 1 0%;
	max-height: 400px;
	overflow-y: auto;

}
.icare-cm-playlist-item {
	display: flex;
	padding: 0.25rem 0.5rem;
	cursor: pointer;
}
.icare-cm-playlist-item img {
	width: 100px;
	height: auto;
	margin: 0 0.5rem;
}
.icare-cm-playlist-item p {
	margin: auto 0;
	font-size: 0.875rem;
}
.icare-cm-playlist-item-active {
	background-color: lightgrey;
}
.icare-related-content-list {
	margin: 0
}
.icare-related-content-list-item {
	cursor: pointer;
	margin-bottom: 1rem;
}
.icare-footer-author {
	border-top: 1px solid lightgray;
	padding-top: 1rem;
	display: flex;
}
.icare-footer-author-image {
	width: 5rem;
	height: 5rem;
	margin-right: 1rem;
	border-radius: 9999px;
}
.icare-footer-author-name {
	margin: 0 0 0.25rem;
	font-size: 1.25rem;
	font-weight: bold;
}
.icare-footer-author-title {
	margin: 0 0 0.25rem;
}
.icare-social-icon {
	display: block;
	width: 1.5rem;
	height: 1.5rem;
	margin-right: 0.25rem;
}
```

Or copy the class names and customize them.

## Usage

### In Svelte.js

```html
<Icare {article} {accessToken} {apiUrl} {campaignApiUrl} {onRelatedContentClick}/>

<script>
import Icare from '@incrowd/article-rendering-engine'
</script>
```

### In all other environment

```html
<div id="icare"/>

<script>
import Icare from '@incrowd/article-rendering-engine'
const icareInstance = new Icare({
	target: document.getElementById("icare"),
	props: { article, accessToken, apiUrl, campaignApiUrl, onRelatedContentClick }
})
</script>
```

`accessToken` is optional. It is used for executing campaign (PROMO block) and fetching KSession for stream videos.

`apiUrl` is set to `https://article-cms-api.incrowdsports.com/v2/articles` by default.

`campaignApiUrl` is set to `https://promoblocks-cms-api.incrowdsports.com/v1` by default.

`onRelatedContentClick` should be a function that has `content` as the first argument which will be called when a related content is clicked. For example:

```javascript
const onRelatedContentClick = content => {
	console.log(JSON.stringify(content, null, 4))
}
```

Can call `icareInstance.$destroy()` to destroy the element. For more information, please read the [Svelte.js documentation](https://svelte.dev/docs).
