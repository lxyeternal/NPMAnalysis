// + (addition)
export const add = (n1, n2) => {
  let r1, r2, m
  try {
    r1 = n1.toString().split('.')[1].length
  } catch (e) {
    r1 = 0
  }
  try {
    r2 = n2.toString().split('.')[1].length
  } catch (e) {
    r2 = 0
  }
  m = Math.pow(10, Math.max(r1, r2))
  return (n1 * m + n2 * m) / m
}

// - (subtraction)
export const sub = (n1, n2) => {
  let r1, r2, m, n
  try {
    r1 = n1.toString().split('.')[1].length
  } catch (e) {
    r1 = 0
  }
  try {
    r2 = n2.toString().split('.')[1].length
  } catch (e) {
    r2 = 0
  }
  m = Math.pow(10, Math.max(r1, r2))
  n = (r1 >= r2) ? r1 : r2
  return ((n1 * m - n2 * m) / m).toFixed(n)
}

// * (multiplication)
export const mul = (n1, n2) => {
  let m = 0
  let s1 = n1.toString()
  let s2 = n2.toString()
  try {
    m += s1.split('.')[1].length
  } catch (e) {}
  try {
    m += s2.split('.')[1].length
  } catch (e) {}
  return Number(s1.replace('.', '')) * Number(s2.replace('.', '')) / Math.pow(10, m)
}

// / (division)
export const div = (n1, n2) => {
  let t1 = 0
  let t2 = 0
  let r1, r2
  try {
    t1 = n1.toString().split('.')[1].length
  } catch (e) {}
  try {
    t2 = n2.toString().split('.')[1].length
  } catch (e) {}
  if (Math) {
    r1 = Number(n1.toString().replace('.', ''))
    r2 = Number(n2.toString().replace('.', ''))
    return mul((r1 / r2), Math.pow(10, t2 - t1))
  }
}

export default {
  add,
  sub,
  mul,
  div
}
