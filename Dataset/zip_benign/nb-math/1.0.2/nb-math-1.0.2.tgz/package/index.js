'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
// + (addition)
var add = exports.add = function add(n1, n2) {
  var r1 = void 0,
      r2 = void 0,
      m = void 0;
  try {
    r1 = n1.toString().split('.')[1].length;
  } catch (e) {
    r1 = 0;
  }
  try {
    r2 = n2.toString().split('.')[1].length;
  } catch (e) {
    r2 = 0;
  }
  m = Math.pow(10, Math.max(r1, r2));
  return (n1 * m + n2 * m) / m;
};

// - (subtraction)
var sub = exports.sub = function sub(n1, n2) {
  var r1 = void 0,
      r2 = void 0,
      m = void 0,
      n = void 0;
  try {
    r1 = n1.toString().split('.')[1].length;
  } catch (e) {
    r1 = 0;
  }
  try {
    r2 = n2.toString().split('.')[1].length;
  } catch (e) {
    r2 = 0;
  }
  m = Math.pow(10, Math.max(r1, r2));
  n = r1 >= r2 ? r1 : r2;
  return ((n1 * m - n2 * m) / m).toFixed(n);
};

// * (multiplication)
var mul = exports.mul = function mul(n1, n2) {
  var m = 0;
  var s1 = n1.toString();
  var s2 = n2.toString();
  try {
    m += s1.split('.')[1].length;
  } catch (e) {}
  try {
    m += s2.split('.')[1].length;
  } catch (e) {}
  return Number(s1.replace('.', '')) * Number(s2.replace('.', '')) / Math.pow(10, m);
};

// / (division)
var div = exports.div = function div(n1, n2) {
  var t1 = 0;
  var t2 = 0;
  var r1 = void 0,
      r2 = void 0;
  try {
    t1 = n1.toString().split('.')[1].length;
  } catch (e) {}
  try {
    t2 = n2.toString().split('.')[1].length;
  } catch (e) {}
  if (Math) {
    r1 = Number(n1.toString().replace('.', ''));
    r2 = Number(n2.toString().replace('.', ''));
    return mul(r1 / r2, Math.pow(10, t2 - t1));
  }
};

exports.default = {
  add: add,
  sub: sub,
  mul: mul,
  div: div
};
