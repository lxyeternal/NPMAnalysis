# nb-math

> Math library for NB

Install
------

```bash
$ nbnpm install @nb/nb-math
```

Usage
------

```js
import {add} from '@nb/nb-math'

add(0.1, 0.1) // 0.3
```
