Rearranges values in arbitrary order.<br>
> This is part of package [extra-array].

[extra-array]: https://www.npmjs.com/package/extra-array

```javascript
array.shuffle$(x, [n]);
// x: an array (updated)
// n: random seed 0->1
// --> x
```

```javascript
const array = require('extra-array');

var x = [1, 2, 3, 4, 5];
array.shuffle(x);
// [ 1, 5, 4, 3, 2 ]

x;
// [ 1, 5, 4, 3, 2 ]

var x = [1, 2, 3, 4, 5];
array.shuffle(x, 0.3);
// [ 4, 5, 2, 3, 1 ]

var x = [1, 2, 3, 4, 5];
array.shuffle(x, 0.3);
// [ 4, 5, 2, 3, 1 ]
```

### references

- [shuffle-seed: @webcaetano](https://www.npmjs.com/package/shuffle-seed)
- [shuffle-array: @pazguille](https://www.npmjs.com/package/shuffle-array)
- [shuffle(): PHP](https://www.php.net/manual/en/function.shuffle.php)
- [Seeding the random number generator in Javascript](https://stackoverflow.com/a/47593316/1413259)
