const html = (v: any) => v;

export default html;
