declare const html: (v: any) => any;
export default html;
