import { ElementRef, AfterViewInit } from '@angular/core';
import { View } from "tns-core-modules/ui/core/view";
import { Page } from "tns-core-modules/ui/page";
export declare class NSDockMonitor implements AfterViewInit {
    private page;
    screenCover: number;
    toggleBtnEl: ElementRef;
    dockEl: ElementRef;
    private shown;
    toggleLength: number;
    toggleBtn: View;
    dock: View;
    private offsetShown;
    private offsetHidden;
    constructor(page: Page);
    ngAfterViewInit(): void;
    dockLoaded(args: any): void;
    private setup();
    toggleShown(): void;
}
