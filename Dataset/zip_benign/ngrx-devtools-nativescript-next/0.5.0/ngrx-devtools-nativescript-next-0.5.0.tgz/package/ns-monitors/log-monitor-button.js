"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var LogMonitorButton = (function () {
    function LogMonitorButton() {
        this.action = new core_1.EventEmitter();
        this.text = "";
    }
    LogMonitorButton.prototype.handleAction = function () {
        if (!this.disabled) {
            this.action.next({});
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Boolean)
    ], LogMonitorButton.prototype, "disabled", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], LogMonitorButton.prototype, "action", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], LogMonitorButton.prototype, "text", void 0);
    LogMonitorButton = __decorate([
        core_1.Component({
            selector: 'log-monitor-button',
            changeDetection: core_1.ChangeDetectionStrategy.OnPush,
            encapsulation: core_1.ViewEncapsulation.Emulated,
            template: "\n  <label [text]=\"text\" (tap)=\"handleAction()\" [class.disabled]=\"disabled\"></label>",
            styles: ["\n     label {\n      font-family: monospace;\n      font-weight: bold;\n      border-radius: 3;\n      margin: 5 3;\n      padding: 3 5;\n      font-size: 10;\n      color: white;\n      background-color: #4F5A65;\n    }\n\n    .disabled{\n      opacity: 0.2;\n      background-color: transparent;\n    }\n  "]
        })
    ], LogMonitorButton);
    return LogMonitorButton;
}());
exports.LogMonitorButton = LogMonitorButton;
//# sourceMappingURL=log-monitor-button.js.map