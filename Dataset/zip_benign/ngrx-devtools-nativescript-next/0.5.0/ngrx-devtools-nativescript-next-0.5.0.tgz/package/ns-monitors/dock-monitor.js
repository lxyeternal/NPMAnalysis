"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var page_1 = require("tns-core-modules/ui/page");
var TOGGLE_BTN_HEIGHT = 40;
var NSDockMonitor = (function () {
    function NSDockMonitor(page) {
        this.page = page;
        this.screenCover = 0.5;
        this.shown = false;
        this.toggleLength = TOGGLE_BTN_HEIGHT;
    }
    NSDockMonitor.prototype.ngAfterViewInit = function () {
        this.toggleBtn = this.toggleBtnEl.nativeElement;
    };
    NSDockMonitor.prototype.dockLoaded = function (args) {
        var _this = this;
        this.dock = args.object;
        setTimeout(function () { return _this.setup(); }, 100);
    };
    NSDockMonitor.prototype.setup = function () {
        var height = this.dock.getActualSize().height;
        console.log("Dock height: " + height);
        this.offsetHidden = height - this.toggleLength;
        this.offsetShown = height * this.screenCover - this.toggleLength;
        this.dock.height = this.offsetHidden - this.offsetShown + this.toggleLength;
        this.dock.animate({ translate: { x: 0, y: this.offsetHidden } });
    };
    NSDockMonitor.prototype.toggleShown = function () {
        this.shown = !this.shown;
        if (this.shown) {
            this.toggleBtn.animate({ rotate: 180 });
            this.dock.animate({ translate: { x: 0, y: this.offsetShown } });
        }
        else {
            this.toggleBtn.animate({ rotate: 0 });
            this.dock.animate({ translate: { x: 0, y: this.offsetHidden } });
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], NSDockMonitor.prototype, "screenCover", void 0);
    __decorate([
        core_1.ViewChild("toggle"),
        __metadata("design:type", core_1.ElementRef)
    ], NSDockMonitor.prototype, "toggleBtnEl", void 0);
    __decorate([
        core_1.ViewChild("dock"),
        __metadata("design:type", core_1.ElementRef)
    ], NSDockMonitor.prototype, "dockEl", void 0);
    NSDockMonitor = __decorate([
        core_1.Component({
            selector: 'ns-dock-monitor',
            changeDetection: core_1.ChangeDetectionStrategy.OnPush,
            styles: ["\n    .toggle {\n        color: white;\n        border-radius:" + TOGGLE_BTN_HEIGHT / 2 + ";\n        border-width: 2;\n        border-color: #69737D;\n        background-color: #2A2F3A;\n        text-align: center;\n        font-family: monospace;\n        font-size: 32;\n        font-weight: bold;\n    }\n    .dock {\n        vertical-align: top;\n    }\n  "],
            template: "\n    <grid-layout rows=\"auto *\" #dock class=\"dock\" rowSpan=\"100\" colSpan=\"100\" translateY=\"1000\" (loaded)=\"dockLoaded($event)\">\n      <label text=\"^\" (tap)=\"toggleShown()\" #toggle [width]=\"toggleLength\" [height]=\"toggleLength\" class=\"toggle\"></label>\n      <grid-layout row=\"1\">\n        <ns-log-monitor></ns-log-monitor>\n      </grid-layout>\n    </grid-layout>\n  "
        }),
        __metadata("design:paramtypes", [page_1.Page])
    ], NSDockMonitor);
    return NSDockMonitor;
}());
exports.NSDockMonitor = NSDockMonitor;
//# sourceMappingURL=dock-monitor.js.map