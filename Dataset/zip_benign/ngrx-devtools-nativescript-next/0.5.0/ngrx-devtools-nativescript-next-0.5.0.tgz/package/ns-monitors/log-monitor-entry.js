"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var LogMonitorEntry = (function () {
    function LogMonitorEntry() {
        this.toggle = new core_1.EventEmitter();
    }
    LogMonitorEntry.prototype.handleToggle = function () {
        this.toggle.next({ id: this.item.actionId });
    };
    LogMonitorEntry.prototype.logPayload = function () {
        console.log("ACTION: " + JSON.stringify(this.item.action));
    };
    LogMonitorEntry.prototype.logState = function () {
        console.log("STATE: " + JSON.stringify(this.item.state));
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], LogMonitorEntry.prototype, "item", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Boolean)
    ], LogMonitorEntry.prototype, "even", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], LogMonitorEntry.prototype, "toggle", void 0);
    LogMonitorEntry = __decorate([
        core_1.Component({
            selector: 'log-monitor-entry',
            changeDetection: core_1.ChangeDetectionStrategy.OnPush,
            encapsulation: core_1.ViewEncapsulation.Emulated,
            template: "\n    <grid-layout columns=\"* auto\" class=\"container\" [class.even]=\"even\" (tap)=\"handleToggle()\"> \n      <label [text]=\"item.action.type\"\n            class=\"title-bar\"\n            [class.collapsed]=\"item.collapsed\"></label>\n      \n      <stack-layout col=\"1\" *ngIf=\"!item.collapsed\" orientation=\"horizontal\">   \n        <log-monitor-button (action)=\"logPayload()\" text=\"Log Payload\">\n        </log-monitor-button>\n        \n        <log-monitor-button (action)=\"logState()\" text=\"Log State\">\n        </log-monitor-button>\n      </stack-layout>\n    </grid-layout>\n  ",
            styles: ["\n    .container {\n      horizontal-align: stretch;\n    }\n    .title-bar {\n      text-align: left;\n      horizontal-align: stretch;\n      vertical-align: center;\n      margin: 8 10;\n      font-family: monosapce;\n      color: #FFFFFF;\n      font-size: 12;\n      font-weight: bold;\n    }\n    .collapsed{\n      text-decoration: line-through;\n      font-style: italic;\n      opacity: 0.5;\n    }\n    .even {\n      background-color: #7A8590;\n    }\n  "]
        })
    ], LogMonitorEntry);
    return LogMonitorEntry;
}());
exports.LogMonitorEntry = LogMonitorEntry;
//# sourceMappingURL=log-monitor-entry.js.map