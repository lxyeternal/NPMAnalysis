import { EventEmitter } from '@angular/core';
import { LogEntryItem } from './log-entry-item';
export declare class LogMonitorEntry {
    item: LogEntryItem;
    even: boolean;
    toggle: EventEmitter<{}>;
    handleToggle(): void;
    logPayload(): void;
    logState(): void;
}
