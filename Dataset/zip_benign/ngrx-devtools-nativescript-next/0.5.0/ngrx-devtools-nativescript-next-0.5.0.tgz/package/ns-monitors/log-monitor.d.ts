import 'rxjs/add/operator/map';
import { StoreDevtools } from '@ngrx/store-devtools';
export declare class NSLogMonitor {
    private devtools;
    private items$;
    private canRevert$;
    private canSweep$;
    private canCommit$;
    constructor(devtools: StoreDevtools);
    handleToggle(id: number): void;
    handleReset(): void;
    handleRollback(): void;
    handleSweep(): void;
    handleCommit(): void;
}
