"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
require("rxjs/add/operator/map");
var store_devtools_1 = require("@ngrx/store-devtools");
var NSLogMonitor = (function () {
    function NSLogMonitor(devtools) {
        this.devtools = devtools;
        this.canRevert$ = devtools.liftedState.map(function (s) { return !(s.computedStates.length > 1); });
        this.canSweep$ = devtools.liftedState.map(function (s) { return !(s.skippedActionIds.length > 0); });
        this.canCommit$ = devtools.liftedState.map(function (s) { return !(s.computedStates.length > 1); });
        this.items$ = devtools.liftedState
            .map(function (_a) {
            var actionsById = _a.actionsById, skippedActionIds = _a.skippedActionIds, stagedActionIds = _a.stagedActionIds, computedStates = _a.computedStates;
            var actions = [];
            for (var i = 0; i < stagedActionIds.length; i++) {
                var actionId = stagedActionIds[i];
                var action = actionsById[actionId].action;
                var _b = computedStates[i], state = _b.state, error = _b.error;
                var previousState = void 0;
                if (i > 0) {
                    previousState = computedStates[i - 1].state;
                }
                actions.push({
                    key: actionId,
                    collapsed: skippedActionIds.indexOf(actionId) > -1,
                    action: action,
                    actionId: actionId,
                    state: state,
                    previousState: previousState,
                    error: error
                });
            }
            return actions.slice(1);
        });
    }
    NSLogMonitor.prototype.handleToggle = function (id) {
        this.devtools.toggleAction(id);
    };
    NSLogMonitor.prototype.handleReset = function () {
        this.devtools.reset();
    };
    NSLogMonitor.prototype.handleRollback = function () {
        this.devtools.rollback();
    };
    NSLogMonitor.prototype.handleSweep = function () {
        this.devtools.sweep();
    };
    NSLogMonitor.prototype.handleCommit = function () {
        this.devtools.commit();
    };
    NSLogMonitor = __decorate([
        core_1.Component({
            selector: 'ns-log-monitor',
            changeDetection: core_1.ChangeDetectionStrategy.OnPush,
            styles: ["\n    .container {\n      background-color: #2A2F3A;\n      font-family: monospace;\n    }\n    \n    .toolbar {\n      horizontal-align: center;\n    }\n\n    .items {\n      background-color: #69737D;\n      horizontal-align: stretch;\n    }\n  "],
            template: "\n    <grid-layout rows=\"auto *\" class=\"container\">\n      <stack-layout orientation=\"horizontal\" class=\"toolbar\">\n        <log-monitor-button text=\"Reset\" (action)=\"handleReset()\">\n        </log-monitor-button>\n\n        <log-monitor-button text=\"Revert\" (action)=\"handleRollback()\" [disabled]=\"canRevert$ | async\">\n        </log-monitor-button>\n\n        <log-monitor-button text=\"Sweep\"(action)=\"handleSweep()\" [disabled]=\"canSweep$ | async\">\n        </log-monitor-button>\n\n        <log-monitor-button text=\"Commit\" (action)=\"handleCommit()\" [disabled]=\"canCommit$ | async\">\n        </log-monitor-button>\n      </stack-layout>\n      \n      <scroll-view row=\"1\">\n        <stack-layout class=\"items\">\n          <log-monitor-entry\n            *ngFor=\"let item of (items$ | async); let even = even\"\n            [even]=\"even\"\n            [item]=\"item\"\n            (toggle)=\"handleToggle($event.id)\">\n          </log-monitor-entry>\n        </stack-layout>\n      </scroll-view>\n    </grid-layout>\n  "
        }),
        __metadata("design:paramtypes", [store_devtools_1.StoreDevtools])
    ], NSLogMonitor);
    return NSLogMonitor;
}());
exports.NSLogMonitor = NSLogMonitor;
//# sourceMappingURL=log-monitor.js.map