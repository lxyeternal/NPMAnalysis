import { EventEmitter } from '@angular/core';
export declare class LogMonitorButton {
    disabled: boolean;
    action: EventEmitter<{}>;
    text: string;
    handleAction(): void;
}
