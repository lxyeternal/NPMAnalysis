"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var nativescript_module_1 = require("nativescript-angular/nativescript.module");
var dock_monitor_1 = require("./ns-monitors/dock-monitor");
var log_monitor_1 = require("./ns-monitors/log-monitor");
var log_monitor_entry_1 = require("./ns-monitors/log-monitor-entry");
var log_monitor_button_1 = require("./ns-monitors/log-monitor-button");
var NativeScriptDevToolsMonitors = (function () {
    function NativeScriptDevToolsMonitors() {
    }
    NativeScriptDevToolsMonitors = __decorate([
        core_1.NgModule({
            declarations: [log_monitor_entry_1.LogMonitorEntry, log_monitor_button_1.LogMonitorButton, log_monitor_1.NSLogMonitor, dock_monitor_1.NSDockMonitor],
            imports: [nativescript_module_1.NativeScriptModule],
            exports: [dock_monitor_1.NSDockMonitor]
        })
    ], NativeScriptDevToolsMonitors);
    return NativeScriptDevToolsMonitors;
}());
exports.NativeScriptDevToolsMonitors = NativeScriptDevToolsMonitors;
//# sourceMappingURL=index.js.map