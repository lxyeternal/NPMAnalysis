export declare class NativeScriptDevToolsMonitors {
}
