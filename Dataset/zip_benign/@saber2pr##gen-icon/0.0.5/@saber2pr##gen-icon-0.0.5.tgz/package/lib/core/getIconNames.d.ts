export declare function nextJsxName(css: string): IterableIterator<string>;
export declare function getIconNames(css: string): string[];
