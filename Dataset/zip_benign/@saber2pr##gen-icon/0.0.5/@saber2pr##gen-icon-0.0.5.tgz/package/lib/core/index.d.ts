export declare function App(input: string, output: string): Promise<void>;
