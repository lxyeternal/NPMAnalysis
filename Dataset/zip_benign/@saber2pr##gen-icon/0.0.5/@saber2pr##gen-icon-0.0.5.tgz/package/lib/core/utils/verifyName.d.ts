export declare const verifyName: (name: string) => string;
export declare const verifyClassName: (className: string) => string;
export declare const verifyIconClassName: (iconClassName: string) => string;
