interface VNode<K extends keyof HTMLElementTagNameMap> {
    type: K;
    props?: Partial<HTMLElementTagNameMap[K]>;
    children?: Array<VNode<any>>;
}
export declare function createHostTag<K extends keyof HTMLElementTagNameMap>({ type, props, children }: VNode<K>): any;
export {};
