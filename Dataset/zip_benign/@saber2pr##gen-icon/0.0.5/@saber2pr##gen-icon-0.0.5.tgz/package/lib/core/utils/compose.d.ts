export declare const compose: <T>(...fns: ((v: T) => T)[]) => (v: T) => T;
