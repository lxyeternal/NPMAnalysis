export declare function nextJsxName(css: string): IterableIterator<string>;
