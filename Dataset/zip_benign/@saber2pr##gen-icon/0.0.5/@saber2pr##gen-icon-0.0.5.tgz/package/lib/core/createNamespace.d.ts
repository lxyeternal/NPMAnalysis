export declare function createNamespace(name: string, contents: string[]): string;
