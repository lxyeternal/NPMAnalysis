export declare function createJsx(name: string, hostTag: string): string;
