import { PhylogenyTree } from './types/phylogeny-tree';
export declare function setRootNLevelsUp(tree: PhylogenyTree, nodeID: string, noLevels?: number, minLeafToRootLength?: number): void;
export declare function useGetLatest<T>(obj: T): () => T;
