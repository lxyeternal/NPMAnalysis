/// <reference types="react" />
export declare function ZoomButtons({ onZoomIn, onZoomOut, style }: {
    onZoomIn: any;
    onZoomOut: any;
    style: any;
}): JSX.Element;
