import React from 'react';
export declare const TreeCanvas: React.ForwardRefExoticComponent<Pick<JSX.IntrinsicAttributes & React.ClassAttributes<HTMLCanvasElement> & React.CanvasHTMLAttributes<HTMLCanvasElement>, "key" | keyof React.CanvasHTMLAttributes<HTMLCanvasElement>> & React.RefAttributes<HTMLCanvasElement>>;
