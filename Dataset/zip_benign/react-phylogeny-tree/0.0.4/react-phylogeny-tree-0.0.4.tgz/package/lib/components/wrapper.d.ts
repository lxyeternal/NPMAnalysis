import React from 'react';
import { Plugins, Hooks } from '../hooks/usePhylogenyTree';
import { Newick, PhylogenyTreeOptions } from '../types/phylogeny-tree';
declare type TreeProps = {
    newick: Newick;
    options?: PhylogenyTreeOptions;
    plugins?: Plugins;
    hooks?: Hooks;
    interactive?: boolean;
    zoom?: boolean;
    zoomStyle?: React.CSSProperties;
};
export declare function PhylogenyTree({ newick, options, plugins, hooks, interactive, zoom, zoomStyle, }: TreeProps): JSX.Element;
export {};
