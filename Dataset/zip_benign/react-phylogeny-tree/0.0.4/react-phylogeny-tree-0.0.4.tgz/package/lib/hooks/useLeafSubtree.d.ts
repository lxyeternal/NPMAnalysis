import { PhylogenyTree } from '../types/phylogeny-tree';
declare type SubtreeLeafOption = {
    leafSubtree: {
        leafID?: string;
        noLevels?: number;
        minLeafToRootLength?: number;
        setLeafLabels?: (ids: (string | number)[]) => void;
    };
};
export declare function useLeafSubtree(getTree: () => PhylogenyTree | null, { leafSubtree: { leafID, noLevels, minLeafToRootLength, setLeafLabels } }: SubtreeLeafOption): void;
export {};
