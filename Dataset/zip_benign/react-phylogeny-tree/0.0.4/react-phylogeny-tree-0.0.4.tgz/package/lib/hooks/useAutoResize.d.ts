import { PhylogenyTree } from '../types/phylogeny-tree';
export declare function useAutoResize(getTree: () => PhylogenyTree | null): void;
