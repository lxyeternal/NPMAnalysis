/// <reference types="react" />
import { Newick, PhylogenyTreeOptions, PhylogenyTree } from '../types/phylogeny-tree';
export declare type Plugins = ((tree: PhylogenyTree, decorate: (fnName: string, fn: unknown) => void) => void)[];
export declare type Hooks = ((getTree: () => PhylogenyTree | null, options: PhylogenyTreeOptions) => void)[];
export declare function usePhylogenyTree(newick: Newick, canvasRef: React.MutableRefObject<HTMLCanvasElement | null>, options?: PhylogenyTreeOptions, plugins?: Plugins, hooks?: Hooks, interactive?: boolean): {
    handleZoomIn: () => void;
    handleZoomOut: () => void;
};
export declare const loopHooks: (hooks: any, getInstance: any, options: any) => void;
