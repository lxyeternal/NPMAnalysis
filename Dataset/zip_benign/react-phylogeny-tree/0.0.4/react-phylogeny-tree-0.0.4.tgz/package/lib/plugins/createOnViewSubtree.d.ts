import { PhylogenyTree } from '../types/phylogeny-tree';
export declare function createOnViewSubtreePlugin(onViewSubtree: (tree: PhylogenyTree, leafsInSubtree: string[]) => void): (tree: PhylogenyTree, decorate: any) => void;
