import { PhylogenyTree } from '../types/phylogeny-tree';
export declare function createOnSelectPlugin(onSelect: (tree: PhylogenyTree, selectedIds: string[]) => void): (tree: PhylogenyTree, decorate: any) => void;
