import { PhylogenyTree } from '../types/phylogeny-tree';
export declare function createOnRedrawReRootTreePlugin(onRedrawReRootTree: (tree: PhylogenyTree, leafsInTree: string[]) => void): (tree: PhylogenyTree, decorate: any) => void;
