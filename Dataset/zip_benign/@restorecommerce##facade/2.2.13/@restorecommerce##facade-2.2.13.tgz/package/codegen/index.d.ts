export interface GenerateSchemaTypingsArgs {
    schema: any;
    outputFile: string;
    typescript?: {
        [key: string]: any;
    };
    typescriptResolvers?: {
        contextType?: string;
        [key: string]: any;
    };
}
export declare const generateSchemaTypings: ({ schema, outputFile, typescript, typescriptResolvers }: GenerateSchemaTypingsArgs) => Promise<void>;
//# sourceMappingURL=index.d.ts.map