export declare const setPublicKey: (publicKey: string) => void;
export declare const iexApiRequest: (endpoint: string) => Promise<any>;
