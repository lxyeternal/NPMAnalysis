export declare const recommendationTrends: (symbol: string) => Promise<Recommendation[]>;
export interface IEXRecommendation {
    consensusEndDate: Date;
    consensusStartDate: Date;
    corporateActionsAppliedDate: Date;
    ratingBuy: number;
    ratingHold: number;
    ratingNone: number;
    ratingOverweight: number;
    ratingScaleMark: number;
    ratingSell: number;
    ratingUnderweight: number;
}
export declare class Recommendation {
    symbol: string;
    consensusEndDate: number;
    consensusStartDate: number;
    corporateActionsAppliedDate: number;
    ratingBuy: number;
    ratingHold: number;
    ratingNone: number;
    ratingOverweight: number;
    ratingScaleMark: number;
    ratingSell: number;
    ratingUnderweight: number;
}
