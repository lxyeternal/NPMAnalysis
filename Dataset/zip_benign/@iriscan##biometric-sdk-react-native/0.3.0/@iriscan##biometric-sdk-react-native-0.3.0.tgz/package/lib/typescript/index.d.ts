type FACE_DIRECTION = 'LEFT' | 'RIGHT' | 'UP' | 'DOWN' | 'STRAIGHT';
export declare function configure(config: any): Promise<boolean>;
export declare function faceCompare(capturedImage: string, vcImage: string): Promise<boolean>;
export declare function faceScore(capturedImage: string, vcImage: string): Promise<number>;
export declare function livenessValidate(capturedImage: string): Promise<boolean>;
export declare function livenessScore(capturedImage: string): Promise<number>;
export declare function livenessGetDirection(capturedImage: string): Promise<FACE_DIRECTION>;
export {};
//# sourceMappingURL=index.d.ts.map