# Invu

[![npm version](https://badge.fury.io/js/invu.svg)](https://badge.fury.io/js/invu)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Build Status](https://github.com/yourusername/invu/actions/workflows/ci.yml/badge.svg)](https://github.com/yourusername/invu/actions)
[![Coverage Status](https://coveralls.io/repos/github/yourusername/invu/badge.svg?branch=main)](https://coveralls.io/github/yourusername/invu?branch=main)

A lightweight, performant React library for handling element visibility and intersection observer functionality.

## Features

- 🔍 Intersection Observer API integration
- 🚀 Optimized performance with React hooks
- 📦 Zero dependencies (except React)
- 🧪 Fully tested with Jest and React Testing Library
- 📖 Comprehensive documentation with Storybook
- 🔧 TypeScript support out of the box

## Installation

```bash
npm install invu
# or
yarn add invu
```

## Usage

```tsx
import { useVisibility } from "invu";

function MyComponent() {
  const { ref, isVisible } = useVisibility({
    threshold: 0.5,
    rootMargin: "0px",
  });

  return <div ref={ref}>{isVisible ? "Element is visible!" : "Element is not visible"}</div>;
}
```

## API Reference

### useVisibility Hook

The `useVisibility` hook provides an easy way to track element visibility using the Intersection Observer API.

#### Parameters

```typescript
interface UseVisibilityOptions {
  threshold?: number | number[];
  rootMargin?: string;
  root?: Element | null;
  once?: boolean;
}
```

- `threshold`: Number or array of numbers between 0 and 1 indicating the percentage of the target's visibility needed to trigger the callback
- `rootMargin`: Margin around the root element
- `root`: The element used as the viewport for checking visibility
- `once`: If true, the observer will disconnect after the first intersection

#### Return Value

```typescript
interface VisibilityResult {
  ref: React.RefObject<Element>;
  isVisible: boolean;
  entry: IntersectionObserverEntry | null;
}
```

- `ref`: React ref to attach to the target element
- `isVisible`: Boolean indicating if the element is visible
- `entry`: The latest IntersectionObserverEntry

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Author

- Karthik Menon - [GitHub](https://github.com/karthiknmenon)
