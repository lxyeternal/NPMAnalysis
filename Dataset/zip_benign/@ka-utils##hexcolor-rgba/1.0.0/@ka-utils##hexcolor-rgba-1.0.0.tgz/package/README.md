# hexcolor-rgba

![](https://img.shields.io/npm/v/@ka-utils/hexcolor-rgba.svg?style=flat) ![](https://img.shields.io/npm/dt/@ka-utils/hexcolor-rgba.svg?style=flat)

> hexcolor-rgba

## 使用


```js
import colorRgba from "@ka-utils/hexcolor-rgba";

const color = colorRgba('#ffffff', 0.5)
```


## 开发

1. `yarn` 或者 `ayarn`（[阿里内网](https://web.npm.alibaba-inc.com/package/@ali/yarn)）安装依赖
2. 小程序 IDE 打开组件（[下载地址](https://opendocs.alipay.com/mini/ide/download)）

## 更多命令

* `miapp newbranch`: 新建分支
* `miapp push`: 提交代码
* `miapp prepub`: 预发（发布 beta 版本）
* `miapp publish`: 正式发布