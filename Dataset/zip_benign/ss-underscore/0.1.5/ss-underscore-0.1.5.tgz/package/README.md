# Underscore Template Engine wrapper for SocketStream 0.3

                       __                                                         
                      /\ \                                                         __           
     __  __    ___    \_\ \     __   _ __   ____    ___    ___   _ __    __       /\_\    ____  
    /\ \/\ \ /' _ `\  /'_  \  /'__`\/\  __\/ ,__\  / ___\ / __`\/\  __\/'__`\     \/\ \  /',__\ 
    \ \ \_\ \/\ \/\ \/\ \ \ \/\  __/\ \ \//\__, `\/\ \__//\ \ \ \ \ \//\  __/  __  \ \ \/\__, `\
     \ \____/\ \_\ \_\ \___,_\ \____\\ \_\\/\____/\ \____\ \____/\ \_\\ \____\/\_\ _\ \ \/\____/
      \/___/  \/_/\/_/\/__,_ /\/____/ \/_/ \/___/  \/____/\/___/  \/_/ \/____/\/_//\ \_\ \/___/ 
                                                                                  \ \____/      
                                                                                   \/___/

http://documentcloud.github.com/underscore/

Use pre-compiled underscore.js client-side templates in your app to benefit from increased performance and a smaller client-side library download.


### Installation

Add ss-underscore to your application's package.json file and install this npm dependency with the following code in the shell:

	npm install

then add this line to app.js:

	ss.client.templateEngine.use(require('ss-underscore'));

Restart the server. From now on all templates will be pre-compiled and attached to the UT window/global variable.

### Usage

E.g. a template placed in

    /client/templates/offers/latest.html

Can be rendered in your browser with

    html = UT['offers-latest'].render({name: 'Special Offers'})


### Options

When experimenting with underscore, or converting an app from one template type to another, you may find it advantageous to use multiple template engines and confine use of underscore to a sub-directory of `/client/templates`.

Directory names can be passed to the second argument as so:

    ss.client.templateEngine.use(require('ss-underscore'), '/underscore-templates');

To specify another global/window variable instead of `UT` set the 'namespace' option in the config as so:

    ss.client.templateEngine.use(require('ss-underscore'), '/', {namespace: 'MyVar'});