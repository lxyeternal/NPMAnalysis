export declare const tokenTypes: readonly ["sizes", "colors", "space", "fontSizes", "lineHeights", "fontWeights", "fonts", "borderWidths", "radii"];
