export declare const background: (tokens: any, value: any) => {};
export declare const animation: (tokens: any, value: any) => {};
export declare const font: (tokens: any, value: any) => {};
export declare const transition: (tokens: any, value: any) => {};
export declare const margin: (tokens: any, value: any) => {};
export declare const padding: (tokens: any, value: any) => {};
export declare const border: (tokens: any, value: any) => {};
export declare const borderTop: (tokens: any, value: any) => {};
export declare const borderRight: (tokens: any, value: any) => {};
export declare const borderLeft: (tokens: any, value: any) => {};
export declare const borderBottom: (tokens: any, value: any) => {};
export declare const borderWidth: (tokens: any, value: any) => {};
export declare const borderColor: (tokens: any, value: any) => {};
export declare const borderStyle: (tokens: any, value: any) => {};
export declare const borderRadius: (tokens: any, value: any) => {};
export declare const boxShadow: (tokens: any, value: string) => {
    boxShadow: string;
};
