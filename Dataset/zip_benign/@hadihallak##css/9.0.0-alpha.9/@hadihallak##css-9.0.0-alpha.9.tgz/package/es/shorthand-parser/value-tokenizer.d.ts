export declare const tokenizeValue: (str: string) => string[][];
