import { IBreakpoints, ICssPropToToken, ISheet } from "./types";
export declare const MAIN_BREAKPOINT_ID = "initial";
export declare type TMainBreakPoint = typeof MAIN_BREAKPOINT_ID;
export declare const cssPropToToken: ICssPropToToken<any>;
export declare const tokenTypes: readonly ["sizes", "colors", "space", "fontSizes", "lineHeights", "fontWeights", "fonts", "borderWidths", "radii"];
export declare const createSheets: (env: any, screens?: IBreakpoints) => {
    tags: HTMLStyleElement[];
    sheets: {
        [key: string]: ISheet;
    };
};
export declare const specificityProps: {
    [key: string]: any;
};
export declare const getVendorPrefixAndProps: (env: any) => {
    vendorPrefix: string;
    vendorProps: unknown[];
};
export declare const hashString: (str: string) => string;
