export declare let unitlessKeys: {
    [k: string]: 1;
};
