import { ITokensDefinition, TConfig, TCss } from "./types";
export * from "./types";
export * from "./css-types";
export * from "./utils";
export declare const hotReloadingCache: Map<string, any>;
export declare const createTokens: <T extends ITokensDefinition>(tokens: T) => T;
export declare const createCss: <T extends TConfig<false>>(_config: T, env?: Window | null) => TCss<T>;
