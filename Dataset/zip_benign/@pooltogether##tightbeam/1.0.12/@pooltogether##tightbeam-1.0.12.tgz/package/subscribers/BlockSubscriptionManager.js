'use strict';

var _tslib = require('../_virtual/_tslib');
var zenObservableTs = require('zen-observable-ts');

var debug = require('debug')('tightbeam:BlockSubscriptionManager');
var BlockSubscriptionManager = /** @class */ (function () {
    function BlockSubscriptionManager(providerSource) {
        var _this = this;
        this.providerSource = providerSource;
        this.observers = [];
        this.notify = function (blockNumber) { return _tslib.__awaiter(_this, void 0, void 0, function () {
            return _tslib.__generator(this, function (_a) {
                debug("notify(" + blockNumber + ")");
                this.observers.forEach(function (observer) {
                    observer.next(blockNumber);
                });
                return [2 /*return*/];
            });
        }); };
    }
    BlockSubscriptionManager.prototype.start = function () {
        return _tslib.__awaiter(this, void 0, void 0, function () {
            var provider;
            return _tslib.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.providerSource()];
                    case 1:
                        provider = _a.sent();
                        provider.on('block', this.notify);
                        return [2 /*return*/];
                }
            });
        });
    };
    BlockSubscriptionManager.prototype.stop = function () {
        return _tslib.__awaiter(this, void 0, void 0, function () {
            var provider;
            return _tslib.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.providerSource()];
                    case 1:
                        provider = _a.sent();
                        provider.removeListener('block', this.notify);
                        return [2 /*return*/];
                }
            });
        });
    };
    BlockSubscriptionManager.prototype.subscribe = function () {
        return _tslib.__awaiter(this, void 0, Promise, function () {
            var _this = this;
            return _tslib.__generator(this, function (_a) {
                return [2 /*return*/, new zenObservableTs.Observable(function (observer) {
                        _this.addObserver(observer);
                        return function () { _this.removeObserver(observer); };
                    })];
            });
        });
    };
    BlockSubscriptionManager.prototype.addObserver = function (observer) {
        this.observers.push(observer);
    };
    BlockSubscriptionManager.prototype.removeObserver = function (observer) {
        var index = this.observers.findIndex(observer);
        if (index > -1) {
            this.observers.splice(index, 1);
        }
    };
    return BlockSubscriptionManager;
}());

exports.BlockSubscriptionManager = BlockSubscriptionManager;
