'use strict';

var _tslib = require('../_virtual/_tslib');
var zenObservableTs = require('zen-observable-ts');

var debug = require('debug')('tightbeam:EventSubscriptionManager');
var EventSubscriptionManager = /** @class */ (function () {
    function EventSubscriptionManager(providerSource, blockSubscriptionManager) {
        var _this = this;
        this.providerSource = providerSource;
        this.blockSubscriptionManager = blockSubscriptionManager;
        this.observers = [];
        this.notify = function (logs) { return _tslib.__awaiter(_this, void 0, void 0, function () {
            return _tslib.__generator(this, function (_a) {
                this.observers.forEach(function (observer) {
                    observer.next(logs);
                });
                return [2 /*return*/];
            });
        }); };
    }
    EventSubscriptionManager.prototype.start = function () {
        return _tslib.__awaiter(this, void 0, void 0, function () {
            var provider, observable;
            var _this = this;
            return _tslib.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.providerSource()];
                    case 1:
                        provider = _a.sent();
                        return [4 /*yield*/, this.blockSubscriptionManager.subscribe()];
                    case 2:
                        observable = _a.sent();
                        this.unsubscribe = observable.subscribe(function (blockNumber) { return _tslib.__awaiter(_this, void 0, void 0, function () {
                            var logs;
                            return _tslib.__generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, provider.getLogs({
                                            fromBlock: blockNumber,
                                            toBlock: blockNumber
                                        })];
                                    case 1:
                                        logs = _a.sent();
                                        this.notify(logs);
                                        return [2 /*return*/];
                                }
                            });
                        }); });
                        return [2 /*return*/];
                }
            });
        });
    };
    EventSubscriptionManager.prototype.stop = function () {
        return _tslib.__awaiter(this, void 0, void 0, function () {
            return _tslib.__generator(this, function (_a) {
                if (this.unsubscribe) {
                    this.unsubscribe();
                }
                return [2 /*return*/];
            });
        });
    };
    EventSubscriptionManager.prototype.subscribe = function () {
        return _tslib.__awaiter(this, void 0, Promise, function () {
            var _this = this;
            return _tslib.__generator(this, function (_a) {
                return [2 /*return*/, new zenObservableTs.Observable(function (observer) {
                        _this.addObserver(observer);
                        return function () { _this.removeObserver(observer); };
                    })];
            });
        });
    };
    EventSubscriptionManager.prototype.addObserver = function (observer) {
        this.observers.push(observer);
    };
    EventSubscriptionManager.prototype.removeObserver = function (observer) {
        var index = this.observers.indexOf(observer);
        if (index > -1) {
            this.observers.splice(index, 1);
        }
    };
    return EventSubscriptionManager;
}());

exports.EventSubscriptionManager = EventSubscriptionManager;
