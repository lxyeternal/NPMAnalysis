'use strict';

var _tslib = require('../_virtual/_tslib');
var buildFilter = require('../services/buildFilter.js');
var zenObservableTs = require('zen-observable-ts');

var debug = require('debug')('tightbeam:eventSubscriber');
function eventSubscriber(contractCache, logsObserver, eventFilter) {
    return _tslib.__awaiter(this, void 0, Promise, function () {
        var contract, filter;
        return _tslib.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, contractCache.resolveContract({
                        abi: eventFilter.abi,
                        address: eventFilter.address,
                        name: eventFilter.name,
                        contract: eventFilter.contract
                    })];
                case 1:
                    contract = _a.sent();
                    filter = buildFilter.buildFilter(contract.address, contract.interface, eventFilter);
                    debug(eventFilter, filter);
                    return [2 /*return*/, new zenObservableTs.Observable(function (observer) {
                            var unsubscribe = logsObserver.subscribe(function (logs) {
                                var _loop_1 = function (i) {
                                    var log = logs[i];
                                    var addressMatch = !filter.address || filter.address.toLowerCase() === log.address.toLowerCase();
                                    if (!addressMatch) {
                                        return "continue";
                                    }
                                    var topicsMatch = filter.topics.reduce(function (isMatch, filterTopic, currentIndex) {
                                        return isMatch && (filterTopic === null ||
                                            filterTopic === undefined ||
                                            filterTopic === log.topics[currentIndex]);
                                    }, true);
                                    if (!topicsMatch) {
                                        return "continue";
                                    }
                                    var event = {
                                        log: log,
                                        event: contract.interface.parseLog(log)
                                    };
                                    debug("filter received ", filter, event);
                                    observer.next(event);
                                };
                                for (var i = 0; i < logs.length; i++) {
                                    _loop_1(i);
                                }
                            });
                            return unsubscribe;
                        })];
            }
        });
    });
}

exports.eventSubscriber = eventSubscriber;
