'use strict';

var ethers = require('ethers');

function gasCalculator(gasLimit, estimatedGasLimit, scaleGasEstimate, minimumGas) {
    var result;
    if (gasLimit) {
        result = ethers.ethers.utils.bigNumberify(gasLimit);
    }
    else if (estimatedGasLimit) {
        result = ethers.ethers.utils.bigNumberify(estimatedGasLimit);
        if (scaleGasEstimate) {
            result = ethers.ethers.utils.bigNumberify(scaleGasEstimate).mul(result);
        }
    }
    if (minimumGas && result < minimumGas) {
        result = ethers.ethers.utils.bigNumberify(minimumGas);
    }
    return result;
}

exports.gasCalculator = gasCalculator;
