'use strict';

var gasCalculator = require('./gasCalculator.js');



exports.gasCalculator = gasCalculator.gasCalculator;
