'use strict';

function castToJsonRpcProvider(provider) {
    if (!provider || !provider['getSigner']) {
        throw new Error('requires JsonRpcProvider');
    }
    // @ts-ignore
    return provider;
}

exports.castToJsonRpcProvider = castToJsonRpcProvider;
