'use strict';

var ethers = require('ethers');

function normalizeAddress(address) {
    try {
        if (address) {
            address = ethers.ethers.utils.getAddress(address);
        }
    }
    catch (e) {
        throw new Error("Unable to normalize address: " + address + ": " + e.message);
    }
    return address;
}

exports.normalizeAddress = normalizeAddress;
