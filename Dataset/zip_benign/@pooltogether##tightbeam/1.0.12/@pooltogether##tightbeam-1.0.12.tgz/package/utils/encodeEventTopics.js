'use strict';

var ethers = require('ethers');

function encodeEventTopics(extraTopics) {
    var encodedEventTopics = [];
    if (extraTopics.types.length !== extraTopics.values.length) {
        throw new Error("extraTopics must have same number of types and values");
    }
    for (var extraTopicIndex = 0; extraTopicIndex < extraTopics.types.length; extraTopicIndex++) {
        var type = extraTopics.types[extraTopicIndex];
        var value = extraTopics.values[extraTopicIndex];
        var encodedValue = null;
        if (value) {
            encodedValue = ethers.ethers.utils.defaultAbiCoder.encode([type], [value]);
        }
        encodedEventTopics.push(encodedValue);
    }
    return encodedEventTopics;
}

exports.encodeEventTopics = encodeEventTopics;
