'use strict';

var _tslib = require('../_virtual/_tslib');
var apolloLink = require('apollo-link');
var countCalls = require('./countCalls.js');
var MulticallBatch = require('./MulticallBatch.js');
var MulticallExecutor = require('./MulticallExecutor.js');

var debug = require('debug')('tightbeam:MulticallLink');
var MulticallLink = /** @class */ (function (_super) {
    _tslib.__extends(MulticallLink, _super);
    function MulticallLink(providerSource) {
        var _this = _super.call(this) || this;
        _this.multicallExecutor = new MulticallExecutor.MulticallExecutor(providerSource);
        return _this;
    }
    MulticallLink.prototype.request = function (operation, forward) {
        var multicallBatch = new MulticallBatch.MulticallBatch(this.multicallExecutor);
        var batchSize = countCalls.countCalls(operation.query);
        debug(operation.operationName, { batchSize: batchSize, batchId: multicallBatch.id });
        multicallBatch.setBatchSize(batchSize);
        operation.setContext(function (context) { return (_tslib.__assign({ multicallBatch: multicallBatch }, context)); });
        var observer = forward(operation);
        return observer;
    };
    return MulticallLink;
}(apolloLink.ApolloLink));

exports.MulticallLink = MulticallLink;
