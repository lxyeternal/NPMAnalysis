'use strict';

var _tslib = require('../_virtual/_tslib');
var Call = require('./Call.js');
var encodeCalls = require('./encodeCalls.js');
var decodeCalls = require('./decodeCalls.js');

var nextId = 0;
var debug = require('debug')('tightbeam:MulticallBatch');
var MulticallBatch = /** @class */ (function () {
    function MulticallBatch(executor) {
        this.executor = executor;
        this.calls = [];
        this.batchSize = 0;
        this.id = nextId++;
    }
    MulticallBatch.prototype.setBatchSize = function (batchSize) {
        this.batchSize = batchSize;
    };
    MulticallBatch.prototype.call = function (to, data) {
        return _tslib.__awaiter(this, void 0, void 0, function () {
            var resolveCb, rejectCb, promise, call, e_1;
            var _this = this;
            return _tslib.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        promise = new Promise(function (resolve, reject) {
                            resolveCb = resolve;
                            rejectCb = reject;
                        });
                        call = new Call.Call(to, data, resolveCb, rejectCb);
                        this.calls.push(call);
                        if (!this.atBatchSize()) return [3 /*break*/, 4];
                        _a.label = 1;
                    case 1:
                        _a.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, this.execute()];
                    case 2:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        e_1 = _a.sent();
                        console.error(e_1);
                        this.calls.map(function (call) { return _tslib.__awaiter(_this, void 0, void 0, function () { return _tslib.__generator(this, function (_a) {
                            return [2 /*return*/, call.reject(e_1.message)];
                        }); }); });
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/, promise];
                }
            });
        });
    };
    MulticallBatch.prototype.atBatchSize = function () {
        return this.calls.length >= this.batchSize;
    };
    MulticallBatch.prototype.isSupported = function () {
        return _tslib.__awaiter(this, void 0, Promise, function () {
            return _tslib.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.executor.networkSupportsMulticall()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    MulticallBatch.prototype.execute = function () {
        return _tslib.__awaiter(this, void 0, void 0, function () {
            var data, returnData, e_2, _a, blockNumber, returnValues, i;
            return _tslib.__generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        data = encodeCalls.encodeCalls(this.calls);
                        debug('execute', { batchId: this.id });
                        returnData = null;
                        _b.label = 1;
                    case 1:
                        _b.trys.push([1, 3, , 4]);
                        return [4 /*yield*/, this.executor.execute(data)];
                    case 2:
                        returnData = _b.sent();
                        return [3 /*break*/, 4];
                    case 3:
                        e_2 = _b.sent();
                        console.warn("executor.execute() failed", e_2);
                        return [3 /*break*/, 4];
                    case 4:
                        if (returnData) {
                            _a = decodeCalls.decodeCalls(returnData), blockNumber = _a[0], returnValues = _a[1];
                            for (i = 0; i < returnValues.length; i++) {
                                this.calls[i].resolve(returnValues[i]);
                            }
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    return MulticallBatch;
}());

exports.MulticallBatch = MulticallBatch;
