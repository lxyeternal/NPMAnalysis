'use strict';

var Call = /** @class */ (function () {
    function Call(to, data, resolve, reject) {
        this.to = to;
        this.data = data;
        this.resolve = resolve;
        this.reject = reject;
    }
    return Call;
}());

exports.Call = Call;
