'use strict';

var _tslib = require('./_virtual/_tslib');
var ethers = require('ethers');
var normalizeAddress = require('./utils/normalizeAddress.js');

var debug = require('debug')('tightbeam:ContractCache');
function error(message) {
    debug(message);
    throw new Error(message);
}
/**
 * Look up contracts or ABIs by name or address.  Values are cached.  Also offers a contract resolver to easily retrieve an [[ethers.Contract]] object.
 */
var ContractCache = /** @class */ (function () {
    function ContractCache(abiMapping, providerSource) {
        this.abiMapping = abiMapping;
        this.providerSource = providerSource;
        if (!abiMapping) {
            error('constructor: abiMapping must be defined');
        }
        if (!providerSource) {
            error('constructor: provider source must be defined');
        }
        this.contractCache = new Map();
        this.ifaceCache = new Map();
    }
    /**
     * Lookup a contract by name.
     *
     * @param contractName The contract name used to register the contract in the [[AbiMapping]]
     */
    ContractCache.prototype.getContractByName = function (contractName) {
        return _tslib.__awaiter(this, void 0, Promise, function () {
            var chainId, address;
            return _tslib.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!contractName)
                            error('Contract name must be defined');
                        return [4 /*yield*/, this.getChainId()];
                    case 1:
                        chainId = _a.sent();
                        address = this.abiMapping.getContractAddress(contractName, chainId);
                        if (!address) {
                            error("Cannot find address for " + contractName + " and chain id " + chainId);
                        }
                        return [4 /*yield*/, this.getContractByAddress(address)];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    ContractCache.prototype.getChainId = function () {
        return _tslib.__awaiter(this, void 0, Promise, function () {
            var provider, network, chainId;
            return _tslib.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.providerSource()];
                    case 1:
                        provider = _a.sent();
                        return [4 /*yield*/, provider.getNetwork()];
                    case 2:
                        network = _a.sent();
                        chainId = network.chainId;
                        return [2 /*return*/, chainId];
                }
            });
        });
    };
    /**
     * Lookup a contract by address
     *
     * @param address The address that the contract was added under in the [[AbiMapping]]
     */
    ContractCache.prototype.getContractByAddress = function (address, abi) {
        return _tslib.__awaiter(this, void 0, Promise, function () {
            var chainId, contract, abiDef, provider;
            return _tslib.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!address)
                            error('Address must be defined');
                        return [4 /*yield*/, this.getChainId()];
                    case 1:
                        chainId = _a.sent();
                        if (!this.contractCache[chainId]) {
                            this.contractCache[chainId] = {};
                        }
                        address = normalizeAddress.normalizeAddress(address);
                        contract = this.contractCache[chainId][address];
                        if (!!contract) return [3 /*break*/, 6];
                        abiDef = void 0;
                        if (!abi) return [3 /*break*/, 3];
                        return [4 /*yield*/, this.abiMapping.getAbiDefinition(abi)];
                    case 2:
                        abiDef = _a.sent();
                        if (!abiDef) {
                            error("Could not find abi with name '" + abi + "'");
                        }
                        return [3 /*break*/, 4];
                    case 3:
                        abiDef = this.abiMapping.getContractAbiDefinitionByAddress(address, chainId);
                        if (!abiDef) {
                            error("Could not find abi for address '" + address + "' and chain id '" + chainId + "'");
                        }
                        _a.label = 4;
                    case 4: return [4 /*yield*/, this.providerSource()];
                    case 5:
                        provider = _a.sent();
                        contract = new ethers.ethers.Contract(address, abiDef.abi, provider);
                        this.contractCache[chainId][address] = contract;
                        _a.label = 6;
                    case 6: return [2 /*return*/, contract];
                }
            });
        });
    };
    /**
     * Lookup an [[ethers.utils.Interface]] by abi name
     *
     * @param abiName The name of the ABI added in the [[AbiMapping]]
     */
    ContractCache.prototype.getAbiInterfaceByName = function (abiName) {
        return _tslib.__awaiter(this, void 0, Promise, function () {
            var iface, abiDef;
            return _tslib.__generator(this, function (_a) {
                iface = this.ifaceCache[abiName];
                if (!iface) {
                    abiDef = this.abiMapping.getAbiDefinition(abiName);
                    if (!abiDef) {
                        error("Could not find abi with name " + abiName);
                    }
                    iface = new ethers.ethers.utils.Interface(abiDef.abi);
                    this.ifaceCache[abiName] = iface;
                }
                return [2 /*return*/, iface];
            });
        });
    };
    ContractCache.prototype.resolveContract = function (resolveContractOptions) {
        return _tslib.__awaiter(this, void 0, Promise, function () {
            var abi, address, name, contract, contractName, result;
            return _tslib.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        abi = resolveContractOptions.abi, address = resolveContractOptions.address, name = resolveContractOptions.name, contract = resolveContractOptions.contract;
                        contractName = name || contract;
                        address = normalizeAddress.normalizeAddress(address);
                        if (!address) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.getContractByAddress(address, abi)];
                    case 1:
                        result = _a.sent();
                        return [3 /*break*/, 5];
                    case 2:
                        if (!contractName) return [3 /*break*/, 4];
                        return [4 /*yield*/, this.getContractByName(contractName)];
                    case 3:
                        result = _a.sent();
                        return [3 /*break*/, 5];
                    case 4:
                        if (abi) {
                            error("abi '" + abi + "' selected but no address passed");
                        }
                        else {
                            error("abi, address or contract must be defined");
                        }
                        _a.label = 5;
                    case 5: return [2 /*return*/, result];
                }
            });
        });
    };
    return ContractCache;
}());

exports.ContractCache = ContractCache;
