'use strict';

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var _tslib = require('../_virtual/_tslib');
var gql = _interopDefault(require('graphql-tag'));

var transactionFragment = gql(templateObject_1 || (templateObject_1 = _tslib.__makeTemplateObject(["\n  fragment transaction on Transaction {\n    id\n    params {\n      values\n    }\n    name\n    abi\n    address\n    blockNumber\n    completed\n    error\n    hash\n    fn\n    sent\n    gasLimit\n    gasPrice\n    scaleGasEstimate\n    minimumGas\n    value\n  }\n"], ["\n  fragment transaction on Transaction {\n    id\n    params {\n      values\n    }\n    name\n    abi\n    address\n    blockNumber\n    completed\n    error\n    hash\n    fn\n    sent\n    gasLimit\n    gasPrice\n    scaleGasEstimate\n    minimumGas\n    value\n  }\n"])));
var templateObject_1;

exports.transactionFragment = transactionFragment;
