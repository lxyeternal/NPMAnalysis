'use strict';

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var _tslib = require('../_virtual/_tslib');
var gql = _interopDefault(require('graphql-tag'));

var accountQuery = gql(templateObject_1 || (templateObject_1 = _tslib.__makeTemplateObject(["\n  query accountQuery {\n    account @client\n  }\n"], ["\n  query accountQuery {\n    account @client\n  }\n"])));
var templateObject_1;

exports.accountQuery = accountQuery;
