'use strict';

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var _tslib = require('../_virtual/_tslib');
var gql = _interopDefault(require('graphql-tag'));

var sendTransactionMutation = gql(templateObject_1 || (templateObject_1 = _tslib.__makeTemplateObject(["\n  mutation sendTransactionMutation(\n    $name: String!,\n    $abi: String!,\n    $address: String,\n    $fn: String!,\n    $params: Object!,\n    $gasLimit: String,\n    $gasPrice: String,\n    $scaleGasEstimate: String,\n    $value: String,\n    $minimumGas: String\n  ) {\n    sendTransaction(\n      name: $name,\n      abi: $abi,\n      address: $address,\n      fn: $fn,\n      params: $params,\n      gasLimit: $gasLimit,\n      gasPrice: $gasPrice,\n      value: $value,\n      scaleGasEstimate: $scaleGasEstimate,\n      minimumGas: $minimumGas\n    ) @client\n  }\n"], ["\n  mutation sendTransactionMutation(\n    $name: String!,\n    $abi: String!,\n    $address: String,\n    $fn: String!,\n    $params: Object!,\n    $gasLimit: String,\n    $gasPrice: String,\n    $scaleGasEstimate: String,\n    $value: String,\n    $minimumGas: String\n  ) {\n    sendTransaction(\n      name: $name,\n      abi: $abi,\n      address: $address,\n      fn: $fn,\n      params: $params,\n      gasLimit: $gasLimit,\n      gasPrice: $gasPrice,\n      value: $value,\n      scaleGasEstimate: $scaleGasEstimate,\n      minimumGas: $minimumGas\n    ) @client\n  }\n"])));
var templateObject_1;

exports.sendTransactionMutation = sendTransactionMutation;
