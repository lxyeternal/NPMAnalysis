'use strict';

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var _tslib = require('../_virtual/_tslib');
var gql = _interopDefault(require('graphql-tag'));
var transactionFragment = require('./transactionFragment.js');

var cachedTransactionsQuery = gql(templateObject_1 || (templateObject_1 = _tslib.__makeTemplateObject(["\n  query cachedTransactionsQuery {\n    _transactions @client(always: true) {\n      ...transaction\n    }\n  }\n  ", "\n"], ["\n  query cachedTransactionsQuery {\n    _transactions @client(always: true) {\n      ...transaction\n    }\n  }\n  ", "\n"])), transactionFragment.transactionFragment);
var templateObject_1;

exports.cachedTransactionsQuery = cachedTransactionsQuery;
