'use strict';

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var _tslib = require('../_virtual/_tslib');
var gql = _interopDefault(require('graphql-tag'));

var networkQuery = gql(templateObject_1 || (templateObject_1 = _tslib.__makeTemplateObject(["\n  query networkQuery {\n    network @client {\n      chainId\n      name\n    }\n  }\n"], ["\n  query networkQuery {\n    network @client {\n      chainId\n      name\n    }\n  }\n"])));
var templateObject_1;

exports.networkQuery = networkQuery;
