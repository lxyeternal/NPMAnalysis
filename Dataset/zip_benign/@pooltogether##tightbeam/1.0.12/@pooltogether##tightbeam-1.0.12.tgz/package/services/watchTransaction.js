'use strict';

var _tslib = require('../_virtual/_tslib');
var transactionFragment = require('../queries/transactionFragment.js');
require('../queries/index.js');
var lodash = require('lodash');

var debug = require('debug')('tightbeam:watchTransaction');
function watchTransaction(id, client, provider) {
    return _tslib.__awaiter(this, void 0, Promise, function () {
        var readTxFragment, transaction, hash, receipt, tx, error_1, tx;
        return _tslib.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    readTxFragment = function () {
                        return client.readFragment({ fragment: transactionFragment.transactionFragment, id: id });
                    };
                    transaction = readTxFragment();
                    hash = transaction.hash;
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, provider.waitForTransaction(hash)];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, provider.getTransactionReceipt(hash)];
                case 3:
                    receipt = _a.sent();
                    tx = readTxFragment();
                    tx = lodash.cloneDeep(tx);
                    if (receipt.status === 0) {
                        tx = _tslib.__assign(_tslib.__assign({}, tx), { completed: true, error: "Status is 0" });
                        debug("Ethereum tx had a 0 status. Tx hash: " + hash);
                    }
                    else {
                        tx = _tslib.__assign(_tslib.__assign({}, tx), { completed: true, blockNumber: receipt.blockNumber });
                    }
                    client.writeFragment({
                        id: id,
                        fragment: transactionFragment.transactionFragment,
                        data: tx
                    });
                    return [3 /*break*/, 5];
                case 4:
                    error_1 = _a.sent();
                    console.error(error_1);
                    tx = readTxFragment();
                    tx = _tslib.__assign(_tslib.__assign({}, tx), { completed: true, error: "Failed getting receipt: " + error_1 });
                    client.writeFragment({
                        id: id,
                        fragment: transactionFragment.transactionFragment,
                        data: tx
                    });
                    debug("Unable to get transaction receipt for tx with hash: " + hash + " - ", error_1);
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    });
}

exports.watchTransaction = watchTransaction;
