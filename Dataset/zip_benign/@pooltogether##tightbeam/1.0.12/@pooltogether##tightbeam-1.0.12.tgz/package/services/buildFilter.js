'use strict';

var encodeEventTopics = require('../utils/encodeEventTopics.js');

var debug = require('debug')('tightbeam:buildFilter');
function buildFilter(address, ethersInterface, filterParams) {
    var params = filterParams.params, topics = filterParams.topics, event = filterParams.event, extraTopics = filterParams.extraTopics, fromBlock = filterParams.fromBlock, toBlock = filterParams.toBlock;
    var actualTopics = [];
    if (topics) {
        actualTopics = encodeEventTopics.encodeEventTopics(topics);
    }
    else if (!event || event === 'allEvents') {
        actualTopics = [null];
    }
    else {
        var eventInterface = ethersInterface.events[event];
        if (!eventInterface) {
            throw new Error("No event called " + event);
        }
        actualTopics = eventInterface.encodeTopics(params || []);
        debug("using topics for " + event, topics);
    }
    var encodedExtraTopics = [];
    if (extraTopics) {
        encodedExtraTopics = encodeEventTopics.encodeEventTopics(extraTopics);
    }
    var filter = {
        address: address,
        fromBlock: fromBlock || 0,
        toBlock: toBlock || 'latest',
        topics: actualTopics.concat(encodedExtraTopics)
    };
    return filter;
}

exports.buildFilter = buildFilter;
