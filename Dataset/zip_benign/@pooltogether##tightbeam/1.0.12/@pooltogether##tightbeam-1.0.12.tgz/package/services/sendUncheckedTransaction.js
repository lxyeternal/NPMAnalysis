'use strict';

var _tslib = require('../_virtual/_tslib');
var ethers = require('ethers');
var gasCalculator = require('../utils/gasCalculator.js');
require('../utils/index.js');
var castToJsonRpcProvider = require('../utils/castToJsonRpcProvider.js');

var debug = require('debug')('tightbeam:sendUncheckedTransaction');
function sendUncheckedTransaction(contractCache, providerSource, tx) {
    return _tslib.__awaiter(this, void 0, Promise, function () {
        var abi, address, name, fn, params, gasLimit, gasPrice, scaleGasEstimate, minimumGas, value, provider, _a, signer, contract, estimatedGasLimit, e_1, selectedGasLimit, transactionData, unsignedTransaction, selectedGasLimitString;
        var _b;
        return _tslib.__generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    abi = tx.abi, address = tx.address, name = tx.name, fn = tx.fn, params = tx.params, gasLimit = tx.gasLimit, gasPrice = tx.gasPrice, scaleGasEstimate = tx.scaleGasEstimate, minimumGas = tx.minimumGas, value = tx.value;
                    _a = castToJsonRpcProvider.castToJsonRpcProvider;
                    return [4 /*yield*/, providerSource()];
                case 1:
                    provider = _a.apply(void 0, [_c.sent()]);
                    signer = provider.getSigner();
                    return [4 /*yield*/, contractCache.resolveContract({ abi: abi, address: address, name: name })];
                case 2:
                    contract = _c.sent();
                    contract = contract.connect(signer);
                    address = contract.address;
                    estimatedGasLimit = null;
                    _c.label = 3;
                case 3:
                    _c.trys.push([3, 5, , 6]);
                    return [4 /*yield*/, (_b = contract.estimate)[tx.fn].apply(_b, params.values)];
                case 4:
                    estimatedGasLimit = _c.sent();
                    return [3 /*break*/, 6];
                case 5:
                    e_1 = _c.sent();
                    console.log("Error while estimating gas: " + e_1);
                    return [3 /*break*/, 6];
                case 6:
                    selectedGasLimit = gasCalculator.gasCalculator(gasLimit, estimatedGasLimit, scaleGasEstimate, minimumGas);
                    transactionData = contract.interface.functions[fn].encode(params.values);
                    unsignedTransaction = {
                        data: transactionData,
                        to: contract.address,
                        gasLimit: selectedGasLimit
                    };
                    if (value) {
                        // @ts-ignore
                        unsignedTransaction.value = ethers.ethers.utils.bigNumberify(value);
                    }
                    if (gasPrice) {
                        // @ts-ignore
                        unsignedTransaction.gasPrice = ethers.ethers.utils.bigNumberify(gasPrice);
                    }
                    if (selectedGasLimit) {
                        selectedGasLimitString = selectedGasLimit.toString();
                    }
                    debug("ID: " + tx.id + "\n\nContractAddress: " + address + "\n\nContractMethod: " + fn + "\n\nTransactionParams: ", JSON.stringify(params), "\n\n\nwith gasLimit " + selectedGasLimitString + "\n\n\nunsignedTransaction: ", JSON.stringify(unsignedTransaction));
                    return [4 /*yield*/, signer.sendUncheckedTransaction(unsignedTransaction)];
                case 7: return [2 /*return*/, _c.sent()];
            }
        });
    });
}

exports.sendUncheckedTransaction = sendUncheckedTransaction;
