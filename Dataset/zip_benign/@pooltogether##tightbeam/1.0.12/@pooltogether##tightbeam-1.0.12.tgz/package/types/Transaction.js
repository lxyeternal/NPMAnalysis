'use strict';

var TransactionParams = /** @class */ (function () {
    function TransactionParams(values) {
        this.values = values;
        this.__typename = 'JSON';
    }
    return TransactionParams;
}());
var Transaction = /** @class */ (function () {
    function Transaction() {
        this.__typename = 'Transaction';
        this.fn = null;
        this.name = null;
        this.abi = null;
        this.address = null;
        this.completed = false;
        this.sent = false;
        this.hash = null;
        this.error = null;
        this.gasLimit = null;
        this.gasPrice = null;
        this.scaleGasEstimate = null;
        this.minimumGas = null;
        this.blockNumber = null;
        this.params = new TransactionParams([]);
        this.value = null;
    }
    return Transaction;
}());

exports.Transaction = Transaction;
exports.TransactionParams = TransactionParams;
