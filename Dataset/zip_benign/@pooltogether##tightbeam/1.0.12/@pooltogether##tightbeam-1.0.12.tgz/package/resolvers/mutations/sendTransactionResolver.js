'use strict';

var _tslib = require('../../_virtual/_tslib');
var transactionFragment = require('../../queries/transactionFragment.js');
var cachedTransactionsQuery = require('../../queries/cachedTransactionsQuery.js');
require('../../queries/index.js');
var castToJsonRpcProvider = require('../../utils/castToJsonRpcProvider.js');
var sendUncheckedTransaction = require('../../services/sendUncheckedTransaction.js');
var Transaction = require('../../types/Transaction.js');
var watchTransaction = require('../../services/watchTransaction.js');

var debug = require('debug')('tightbeam:sendTransaction');
function sendTransactionResolver(contractCache, providerSource, txId, opts, args, context, info) {
    return _tslib.__awaiter(this, void 0, Promise, function () {
        var cache, abi, name, address, fn, params, gasLimit, gasPrice, value, scaleGasEstimate, minimumGas, provider, _a, signer, contract, identifier, newTx, query, data, id;
        return _tslib.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    cache = context.cache;
                    abi = args.abi, name = args.name, address = args.address, fn = args.fn, params = args.params, gasLimit = args.gasLimit, gasPrice = args.gasPrice, value = args.value, scaleGasEstimate = args.scaleGasEstimate, minimumGas = args.minimumGas;
                    _a = castToJsonRpcProvider.castToJsonRpcProvider;
                    return [4 /*yield*/, providerSource()];
                case 1:
                    provider = _a.apply(void 0, [_b.sent()]);
                    signer = provider.getSigner();
                    return [4 /*yield*/, contractCache.resolveContract({ abi: abi, address: address, name: name })];
                case 2:
                    contract = _b.sent();
                    contract.connect(signer),
                        address = contract.address;
                    identifier = JSON.stringify({ abi: abi, name: name, address: address });
                    if (!contract[fn]) {
                        throw new Error("Unknown function " + fn + " for " + identifier);
                    }
                    if (!params) {
                        params = [];
                    }
                    newTx = new Transaction.Transaction();
                    newTx = _tslib.__assign(_tslib.__assign({}, newTx), { id: txId, fn: fn, name: name || null, abi: abi || null, address: address, completed: false, sent: false, hash: null, error: null, blockNumber: null, gasLimit: gasLimit ? gasLimit.toString() : null, gasPrice: gasPrice ? gasPrice.toString() : null, scaleGasEstimate: scaleGasEstimate ? scaleGasEstimate.toString() : null, minimumGas: minimumGas ? minimumGas.toString() : null, value: value ? value.toString() : null, params: new Transaction.TransactionParams(Array.from(params).map(function (param) { return param ? param.toString() : ''; })) });
                    query = cachedTransactionsQuery.cachedTransactionsQuery;
                    data = cache.readQuery({ query: query });
                    cache.writeData({
                        // query,
                        data: {
                            _transactions: data._transactions.concat([newTx])
                        }
                    });
                    id = "Transaction:" + newTx.id;
                    sendUncheckedTransaction.sendUncheckedTransaction(contractCache, providerSource, newTx)
                        .then(function (hash) {
                        var data = _tslib.__assign(_tslib.__assign({}, newTx), { hash: hash, sent: true });
                        debug("Tx sent!");
                        cache.writeFragment({
                            id: id,
                            fragment: transactionFragment.transactionFragment,
                            data: data
                        });
                        watchTransaction.watchTransaction(id, cache, provider);
                        return data;
                    })
                        .catch(function (error) {
                        console.error(error);
                        debug("Error occured while sending transaction", error);
                        var data = _tslib.__assign(_tslib.__assign({}, newTx), { completed: true, sent: true, error: error.message });
                        cache.writeFragment({
                            id: id,
                            fragment: transactionFragment.transactionFragment,
                            data: data
                        });
                        return data;
                    });
                    return [2 /*return*/, newTx];
            }
        });
    });
}

exports.sendTransactionResolver = sendTransactionResolver;
