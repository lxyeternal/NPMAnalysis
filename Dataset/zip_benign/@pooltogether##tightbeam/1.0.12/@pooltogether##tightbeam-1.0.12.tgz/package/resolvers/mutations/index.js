'use strict';

var sendTransactionResolver = require('./sendTransactionResolver.js');



exports.sendTransactionResolver = sendTransactionResolver.sendTransactionResolver;
