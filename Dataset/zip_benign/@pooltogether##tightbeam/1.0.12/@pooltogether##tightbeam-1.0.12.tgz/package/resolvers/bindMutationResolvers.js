'use strict';

var sendTransactionResolver = require('./mutations/sendTransactionResolver.js');
require('./mutations/index.js');

/**
 *
 * @param tightbeam The Tightbeam object
 */
function bindMutationResolvers(contractCache, txProviderSource) {
    var nextTxId = 1;
    return {
        sendTransaction: function (opts, args, context, info) {
            return sendTransactionResolver.sendTransactionResolver(contractCache, txProviderSource, nextTxId++, opts, args, context);
        }
    };
}

exports.bindMutationResolvers = bindMutationResolvers;
