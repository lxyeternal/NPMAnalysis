'use strict';

var bindMutationResolvers = require('./bindMutationResolvers.js');
var bindQueryResolvers = require('./bindQueryResolvers.js');

/**
 *
 * @param tightbeam The Tightbeam object
 */
function bindResolvers(tightbeam) {
    return {
        Query: bindQueryResolvers.bindQueryResolvers(tightbeam.contractCache, tightbeam.providerSource, tightbeam.txProviderSource, tightbeam.defaultFromBlock),
        Mutation: bindMutationResolvers.bindMutationResolvers(tightbeam.txContractCache, tightbeam.txProviderSource)
    };
}

exports.bindResolvers = bindResolvers;
