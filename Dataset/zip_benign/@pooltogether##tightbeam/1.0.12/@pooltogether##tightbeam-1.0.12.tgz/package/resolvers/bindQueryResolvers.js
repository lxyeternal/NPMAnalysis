'use strict';

var accountResolver = require('./queries/accountResolver.js');
var blockResolver = require('./queries/blockResolver.js');
var callResolver = require('./queries/callResolver.js');
var contractResolver = require('./queries/contractResolver.js');
var networkResolver = require('./queries/networkResolver.js');
var pastEventsResolver = require('./queries/pastEventsResolver.js');
var transactionResolver = require('./queries/transactionResolver.js');
var transactionsResolver = require('./queries/transactionsResolver.js');
require('./queries/index.js');

/**
 *
 * @param tightbeam The Tightbeam object
 * @returns A map of the query resolvers.
 */
function bindQueryResolvers(contractCache, providerSource, txProviderSource, defaultFromBlock) {
    return {
        account: function () {
            return accountResolver.accountResolver(txProviderSource);
        },
        block: function (opts, args, context, info) {
            return blockResolver.blockResolver(providerSource, opts, args);
        },
        call: function (opts, args, context, info) {
            return callResolver.callResolver(contractCache, providerSource, opts, args, context);
        },
        contract: function (opts, args, context, info) {
            return contractResolver.contractResolver(contractCache, opts, args);
        },
        network: function () {
            return networkResolver.networkResolver(providerSource);
        },
        pastEvents: function (opts, args, context, info) {
            return pastEventsResolver.pastEventsResolver(contractCache, providerSource, defaultFromBlock, opts, args);
        },
        transaction: function (opts, args, context, info) {
            return transactionResolver.transactionResolver(opts, args, context);
        },
        transactions: function (opts, args, context, info) {
            return transactionsResolver.transactionsResolver(opts, args, context);
        }
    };
}

exports.bindQueryResolvers = bindQueryResolvers;
