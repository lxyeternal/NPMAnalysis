'use strict';

var _tslib = require('../../_virtual/_tslib');
var castToJsonRpcProvider = require('../../utils/castToJsonRpcProvider.js');

var debug = require('debug')('tightbeam:web3Resolvers');
/**
 * Resolvers execute the behaviour when an Apollo query with the same name is run.
 */
function accountResolver(providerSource) {
    return _tslib.__awaiter(this, void 0, Promise, function () {
        var provider, _a, accounts, signer, address, e_1;
        return _tslib.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 4, , 5]);
                    _a = castToJsonRpcProvider.castToJsonRpcProvider;
                    return [4 /*yield*/, providerSource()];
                case 1:
                    provider = _a.apply(void 0, [_b.sent()]);
                    return [4 /*yield*/, provider.listAccounts()];
                case 2:
                    accounts = _b.sent();
                    if (!accounts.length) {
                        return [2 /*return*/, null];
                    }
                    signer = provider.getSigner();
                    debug('signer: ', signer);
                    return [4 /*yield*/, signer.getAddress()];
                case 3:
                    address = _b.sent();
                    debug('got address: ', address);
                    return [2 /*return*/, address];
                case 4:
                    e_1 = _b.sent();
                    if (/JsonRpcProvider/.test(e_1.toString())) {
                        return [2 /*return*/, null];
                    }
                    if (/unknown account #0/.test(e_1.toString())) {
                        return [2 /*return*/, null];
                    }
                    throw e_1;
                case 5: return [2 /*return*/];
            }
        });
    });
}

exports.accountResolver = accountResolver;
