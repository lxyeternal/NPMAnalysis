'use strict';

var _tslib = require('../../_virtual/_tslib');

var debug = require('debug')('tightbeam:callResolver');
function callResolver(contractCache, providerSource, opts, args, context, info) {
    return _tslib.__awaiter(this, void 0, void 0, function () {
        var name, contract, abi, address, fn, params, ethersContract, identifier, provider, fnCall, data, tx, value, _a, to, data_1, returns, error_1, msg;
        return _tslib.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    name = args.name, contract = args.contract, abi = args.abi, address = args.address, fn = args.fn, params = args.params;
                    params = params || [];
                    return [4 /*yield*/, contractCache.resolveContract({ abi: abi, address: address, name: name, contract: contract })];
                case 1:
                    ethersContract = _b.sent();
                    identifier = JSON.stringify({ abi: abi, address: address, contract: name || contract });
                    return [4 /*yield*/, providerSource()];
                case 2:
                    provider = _b.sent();
                    fnCall = ethersContract.interface.functions[fn];
                    if (!!fnCall) return [3 /*break*/, 3];
                    throw new Error("Unknown function " + fn + " for " + identifier);
                case 3:
                    _b.trys.push([3, 12, , 13]);
                    data = fnCall.encode(params);
                    tx = {
                        data: data,
                        to: ethersContract.address
                    };
                    debug({ identifier: identifier, fn: fn, params: params });
                    value = void 0;
                    _a = context.multicallBatch;
                    if (!_a) return [3 /*break*/, 5];
                    return [4 /*yield*/, context.multicallBatch.isSupported()];
                case 4:
                    _a = (_b.sent());
                    _b.label = 5;
                case 5:
                    if (!_a) return [3 /*break*/, 9];
                    return [4 /*yield*/, tx.to];
                case 6:
                    to = _b.sent();
                    return [4 /*yield*/, tx.data];
                case 7:
                    data_1 = _b.sent();
                    return [4 /*yield*/, context.multicallBatch.call(to, data_1)];
                case 8:
                    value = _b.sent();
                    return [3 /*break*/, 11];
                case 9: return [4 /*yield*/, provider.call(tx)];
                case 10:
                    value = _b.sent();
                    _b.label = 11;
                case 11:
                    returns = fnCall.decode(value);
                    if (fnCall.outputs.length === 1) {
                        returns = returns[0];
                    }
                    if (Array.isArray(returns)) {
                        returns = Object.assign({}, returns);
                    }
                    return [2 /*return*/, returns];
                case 12:
                    error_1 = _b.sent();
                    msg = identifier + " " + fn + "(" + JSON.stringify(params) + "): " + (error_1.message || error_1);
                    console.warn(msg, error_1);
                    throw msg;
                case 13: return [2 /*return*/];
            }
        });
    });
}

exports.callResolver = callResolver;
