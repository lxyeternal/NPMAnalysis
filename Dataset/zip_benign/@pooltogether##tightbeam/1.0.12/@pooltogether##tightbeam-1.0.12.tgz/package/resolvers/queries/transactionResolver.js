'use strict';

var _tslib = require('../../_virtual/_tslib');
var transactionFragment = require('../../queries/transactionFragment.js');
require('../../queries/index.js');

function transactionResolver(opts, args, _a, info) {
    var cache = _a.cache, getCacheKey = _a.getCacheKey;
    return _tslib.__awaiter(this, void 0, Promise, function () {
        var id, cacheKey, result;
        return _tslib.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    id = args.id;
                    if (!id) {
                        return [2 /*return*/, null];
                    }
                    cacheKey = getCacheKey({ __typename: 'Transaction', id: id.toString() });
                    return [4 /*yield*/, cache.readFragment({
                            id: cacheKey,
                            fragment: transactionFragment.transactionFragment
                        })];
                case 1:
                    result = _b.sent();
                    return [2 /*return*/, result];
            }
        });
    });
}

exports.transactionResolver = transactionResolver;
