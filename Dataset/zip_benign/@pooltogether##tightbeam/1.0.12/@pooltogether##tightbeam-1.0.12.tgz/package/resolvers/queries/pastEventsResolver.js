'use strict';

var _tslib = require('../../_virtual/_tslib');
var ethers = require('ethers');
var buildFilter = require('../../services/buildFilter.js');

var debug = require('debug')('tightbeam:pastEventsResolver');
function pastEventsResolver(contractCache, providerSource, defaultFromBlock, opts, eventFilter, context, info) {
    return _tslib.__awaiter(this, void 0, Promise, function () {
        var contract, filter, provider, _a, logs;
        return _tslib.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    debug(eventFilter);
                    return [4 /*yield*/, contractCache.resolveContract({
                            abi: eventFilter.abi,
                            address: eventFilter.address,
                            name: eventFilter.name,
                            contract: eventFilter.contract
                        })];
                case 1:
                    contract = _b.sent();
                    filter = buildFilter.buildFilter(contract.address, contract.interface, _tslib.__assign(_tslib.__assign({}, eventFilter), { fromBlock: eventFilter.fromBlock || defaultFromBlock }));
                    if (!providerSource) return [3 /*break*/, 3];
                    return [4 /*yield*/, providerSource()];
                case 2:
                    _a = _b.sent();
                    return [3 /*break*/, 5];
                case 3: return [4 /*yield*/, ethers.ethers.getDefaultProvider()
                    // const provider = await providerSource()
                ];
                case 4:
                    _a = _b.sent();
                    _b.label = 5;
                case 5:
                    provider = _a;
                    return [4 /*yield*/, provider.getLogs(filter)];
                case 6:
                    logs = _b.sent();
                    return [2 /*return*/, logs.map(function (log) { return ({
                            log: log,
                            event: contract.interface.parseLog(log)
                        }); })];
            }
        });
    });
}

exports.pastEventsResolver = pastEventsResolver;
