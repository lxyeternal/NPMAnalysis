'use strict';

var accountResolver = require('./accountResolver.js');
var blockResolver = require('./blockResolver.js');
var callResolver = require('./callResolver.js');
var contractResolver = require('./contractResolver.js');
var networkResolver = require('./networkResolver.js');
var pastEventsResolver = require('./pastEventsResolver.js');
var transactionResolver = require('./transactionResolver.js');
var transactionsResolver = require('./transactionsResolver.js');



exports.accountResolver = accountResolver.accountResolver;
exports.blockResolver = blockResolver.blockResolver;
exports.callResolver = callResolver.callResolver;
exports.contractResolver = contractResolver.contractResolver;
exports.networkResolver = networkResolver.networkResolver;
exports.pastEventsResolver = pastEventsResolver.pastEventsResolver;
exports.transactionResolver = transactionResolver.transactionResolver;
exports.transactionsResolver = transactionsResolver.transactionsResolver;
