'use strict';

var _tslib = require('../../_virtual/_tslib');
var cachedTransactionsQuery = require('../../queries/cachedTransactionsQuery.js');
require('../../queries/index.js');

var debug = require('debug')('tightbeam:transactionsResolver');
function transactionsResolver(opts, args, _a, info) {
    var cache = _a.cache;
    return _tslib.__awaiter(this, void 0, Promise, function () {
        var _b, id, name, address, fn, query, _transactions, result;
        return _tslib.__generator(this, function (_c) {
            _b = args || {}, id = _b.id, name = _b.name, address = _b.address, fn = _b.fn;
            debug('FIRING TXS RESOLVER! ', { id: id,
                name: name,
                address: address,
                fn: fn });
            query = cachedTransactionsQuery.cachedTransactionsQuery;
            _transactions = cache.readQuery({ query: query })._transactions;
            result = _transactions.filter(function (tx) {
                var matchId = !id || tx.id === id;
                var matchName = !name || tx.name === name;
                var matchAddress = !address || tx.address === address;
                var matchFn = !fn || ((matchName || matchAddress) && tx.fn === fn);
                return matchId && matchName && matchAddress && matchFn;
            });
            debug('found: ', _transactions, result);
            return [2 /*return*/, result];
        });
    });
}

exports.transactionsResolver = transactionsResolver;
