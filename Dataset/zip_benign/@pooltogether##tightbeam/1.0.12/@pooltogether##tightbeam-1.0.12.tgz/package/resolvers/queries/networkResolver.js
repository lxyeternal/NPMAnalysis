'use strict';

var _tslib = require('../../_virtual/_tslib');

var debug = require('debug')('tightbeam:networkResolver');
/**
 * Resolvers execute the behaviour when an Apollo query with the same name is run.
 */
var networkResolver = function (providerSource) {
    return _tslib.__awaiter(this, void 0, void 0, function () {
        var provider, network, result;
        return _tslib.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, providerSource()];
                case 1:
                    provider = _a.sent();
                    return [4 /*yield*/, provider.getNetwork()];
                case 2:
                    network = _a.sent();
                    result = _tslib.__assign({ __typename: 'Network', id: network.chainId }, network);
                    debug(result);
                    return [2 /*return*/, result];
            }
        });
    });
};

exports.networkResolver = networkResolver;
