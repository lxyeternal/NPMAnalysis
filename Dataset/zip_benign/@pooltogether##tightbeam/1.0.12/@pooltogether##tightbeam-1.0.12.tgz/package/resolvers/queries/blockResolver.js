'use strict';

var _tslib = require('../../_virtual/_tslib');

var debug = require('debug')('tightbeam:blockResolver');
/**
 * Resolvers execute the behaviour when an Apollo query with the same name is run.
 */
function blockResolver(providerSource, opts, args, context, info) {
    return _tslib.__awaiter(this, void 0, Promise, function () {
        var blockNumber, provider, block, result;
        return _tslib.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    blockNumber = args.blockNumber;
                    return [4 /*yield*/, providerSource()];
                case 1:
                    provider = _a.sent();
                    debug('blockNumber: ', blockNumber);
                    return [4 /*yield*/, provider.getBlock(blockNumber)];
                case 2:
                    block = _a.sent();
                    result = _tslib.__assign({ __typename: 'Block', id: block.number }, block);
                    debug("block(" + blockNumber + "): ", result);
                    return [2 /*return*/, result];
            }
        });
    });
}

exports.blockResolver = blockResolver;
