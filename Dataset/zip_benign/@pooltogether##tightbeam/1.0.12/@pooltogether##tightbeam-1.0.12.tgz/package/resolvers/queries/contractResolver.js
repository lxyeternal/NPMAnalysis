'use strict';

var _tslib = require('../../_virtual/_tslib');

var debug = require('debug')('tightbeam:contractResolver');
function contractResolver(contractCache, opts, args, context, info) {
    return _tslib.__awaiter(this, void 0, Promise, function () {
        var name, contract, address, abi, ethersContract, error, chainId;
        return _tslib.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    name = args.name, contract = args.contract, address = args.address, abi = args.abi;
                    return [4 /*yield*/, contractCache.resolveContract({ name: name, address: address, abi: abi, contract: contract })];
                case 1:
                    ethersContract = _a.sent();
                    if (!ethersContract) {
                        error = "tightbeam: contractResolver(): unknown contract " + JSON.stringify({ name: name, address: address, abi: abi });
                        debug(error);
                        throw new Error(error);
                    }
                    return [4 /*yield*/, ethersContract.provider.getNetwork()];
                case 2:
                    chainId = (_a.sent()).chainId;
                    return [2 /*return*/, {
                            __typename: 'Contract',
                            id: chainId + "@" + ethersContract.address,
                            address: ethersContract.address,
                            chainId: chainId,
                            name: name
                        }];
            }
        });
    });
}

exports.contractResolver = contractResolver;
