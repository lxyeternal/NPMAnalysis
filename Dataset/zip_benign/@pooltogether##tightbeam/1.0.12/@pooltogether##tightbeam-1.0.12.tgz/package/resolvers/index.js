'use strict';

var index$1 = require('./mutations/index.js');
var index$2 = require('./queries/index.js');
var bindMutationResolvers = require('./bindMutationResolvers.js');
var bindQueryResolvers = require('./bindQueryResolvers.js');
var bindResolvers = require('./bindResolvers.js');



exports.mutations = index$1;
exports.queries = index$2;
exports.bindMutationResolvers = bindMutationResolvers.bindMutationResolvers;
exports.bindQueryResolvers = bindQueryResolvers.bindQueryResolvers;
exports.bindResolvers = bindResolvers.bindResolvers;
