'use strict';

var AbiDefinition = require('./AbiDefinition.js');
var AbiMapping = require('./AbiMapping.js');



exports.AbiDefinition = AbiDefinition.AbiDefinition;
exports.AbiMapping = AbiMapping.AbiMapping;
