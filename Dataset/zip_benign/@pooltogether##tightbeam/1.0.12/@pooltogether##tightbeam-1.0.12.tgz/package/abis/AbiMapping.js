'use strict';

var AbiDefinition = require('./AbiDefinition.js');
var normalizeAddress = require('../utils/normalizeAddress.js');

var debug = require('debug')('tightbeam:AbiMapping');
var AbiMapping = /** @class */ (function () {
    function AbiMapping() {
        this.abiMapping = new Map();
        this.nameToAddressMapping = new Map();
        this.addressToAbiMapping = new Map();
    }
    AbiMapping.prototype.addAbi = function (name, abi) {
        if (!name)
            throw "ABI cannot be mapped to a null name";
        if (!abi)
            throw "ABI cannot be null";
        debug("addAbi(" + name + ", " + JSON.stringify(abi));
        this.abiMapping[name] = new AbiDefinition.AbiDefinition(abi);
    };
    AbiMapping.prototype.addContract = function (name, networkId, address, abi) {
        if (!name)
            throw 'name not defined';
        if (!networkId)
            throw 'networkId not defined';
        if (!address)
            throw 'address not defined';
        if (!abi)
            throw 'abi not defined';
        address = normalizeAddress.normalizeAddress(address);
        if (!this.nameToAddressMapping[name]) {
            this.nameToAddressMapping[name] = {};
        }
        if (!this.addressToAbiMapping[address]) {
            this.addressToAbiMapping[address] = {};
        }
        debug("addContract(" + name + ", " + networkId + ", " + address + ", " + JSON.stringify(abi));
        this.nameToAddressMapping[name][networkId] = address;
        this.addressToAbiMapping[address][networkId] = new AbiDefinition.AbiDefinition(abi);
    };
    AbiMapping.prototype.addTruffleArtifact = function (truffleJsonArtifact) {
        var _this = this;
        Object.keys(truffleJsonArtifact.networks).forEach(function (networkId) {
            debug("addTruffleArtifact addContract(" + truffleJsonArtifact.contractName + ", " + networkId + ", " + truffleJsonArtifact.networks[networkId].address + ", " + JSON.stringify(truffleJsonArtifact.abi));
            _this.addContract(truffleJsonArtifact.contractName, parseInt(networkId), truffleJsonArtifact.networks[networkId].address, truffleJsonArtifact.abi);
        });
    };
    AbiMapping.prototype.getAbiDefinition = function (name) {
        return this.abiMapping[name];
    };
    AbiMapping.prototype.getContractAbiDefinitionByName = function (name, networkId) {
        var mapping = this.nameToAddressMapping[name];
        var result;
        if (mapping) {
            var address = this.nameToAddressMapping[name][networkId];
            result = this.getContractAbiDefinitionByAddress(address, networkId);
        }
        return result;
    };
    AbiMapping.prototype.getContractAbiDefinitionByAddress = function (address, networkId) {
        address = normalizeAddress.normalizeAddress(address);
        var mapping = this.addressToAbiMapping[address];
        var result;
        if (mapping) {
            result = mapping[networkId];
        }
        return result;
    };
    AbiMapping.prototype.getContractAddress = function (name, networkId) {
        if (!this.nameToAddressMapping[name]) {
            return undefined;
        }
        return this.nameToAddressMapping[name][networkId];
    };
    return AbiMapping;
}());

exports.AbiMapping = AbiMapping;
