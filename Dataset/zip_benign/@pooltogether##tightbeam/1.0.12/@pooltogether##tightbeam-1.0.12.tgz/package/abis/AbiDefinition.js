'use strict';

var AbiDefinition = /** @class */ (function () {
    function AbiDefinition(abi) {
        var _this = this;
        if (!abi) {
            throw new Error('abi is undefined');
        }
        this.abi = abi;
        this.nameLookup = {};
        this.abi.forEach(function (def) {
            _this.nameLookup[def.name] = def;
        });
    }
    AbiDefinition.prototype.findByName = function (name) {
        return this.nameLookup[name];
    };
    return AbiDefinition;
}());

exports.AbiDefinition = AbiDefinition;
