'use strict';

var _tslib = require('./_virtual/_tslib');
var ethers = require('ethers');
var AbiMapping = require('./abis/AbiMapping.js');
var index = require('./abis/index.js');
var index$1 = require('./queries/index.js');
var index$2 = require('./utils/index.js');
var bindResolvers = require('./resolvers/bindResolvers.js');
var index$3 = require('./resolvers/index.js');
var index$4 = require('./services/index.js');
var eventSubscriber = require('./subscribers/eventSubscriber.js');
var BlockSubscriptionManager = require('./subscribers/BlockSubscriptionManager.js');
var EventSubscriptionManager = require('./subscribers/EventSubscriptionManager.js');
var index$5 = require('./subscribers/index.js');
var index$6 = require('./types/index.js');
var ContractCache = require('./ContractCache.js');
var MulticallLink = require('./multicall/MulticallLink.js');

var merge = require('lodash.merge');
var Tightbeam = /** @class */ (function () {
    function Tightbeam(options) {
        var _this = this;
        var _a = options || {}, providerSource = _a.providerSource, txProviderSource = _a.txProviderSource, abiMapping = _a.abiMapping, defaultFromBlock = _a.defaultFromBlock;
        this.providerSource = providerSource || (function () { return _tslib.__awaiter(_this, void 0, void 0, function () { return _tslib.__generator(this, function (_a) {
            return [2 /*return*/, ethers.ethers.getDefaultProvider()];
        }); }); });
        this.txProviderSource = txProviderSource || this.providerSource;
        this.abiMapping = abiMapping || new AbiMapping.AbiMapping();
        this.defaultFromBlock = defaultFromBlock || 0;
        this.contractCache = new ContractCache.ContractCache(this.abiMapping, this.providerSource);
        this.txContractCache = new ContractCache.ContractCache(this.abiMapping, this.txProviderSource);
        this.blockSubscriptionManager = new BlockSubscriptionManager.BlockSubscriptionManager(this.providerSource);
        this.eventSubscriptionManager = new EventSubscriptionManager.EventSubscriptionManager(this.providerSource, this.blockSubscriptionManager);
    }
    Tightbeam.prototype.resolvers = function (clientResolvers) {
        if (clientResolvers === void 0) { clientResolvers = {}; }
        return merge(clientResolvers, this.bindResolvers());
    };
    Tightbeam.prototype.multicallLink = function () {
        return new MulticallLink.MulticallLink(this.providerSource);
    };
    Tightbeam.prototype.subscribeEvent = function (eventFilter) {
        return _tslib.__awaiter(this, void 0, void 0, function () {
            return _tslib.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.startSubscribers()];
                    case 1:
                        _a.sent();
                        return [4 /*yield*/, eventSubscriber.eventSubscriber(this.contractCache, this.logsSubscriber, eventFilter)];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    Tightbeam.prototype.startSubscribers = function () {
        return _tslib.__awaiter(this, void 0, void 0, function () {
            var _this = this;
            return _tslib.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.subscribersReady) {
                            this.subscribersReady = new Promise(function (resolve, reject) {
                                var setup = function () { return _tslib.__awaiter(_this, void 0, void 0, function () {
                                    var _a;
                                    return _tslib.__generator(this, function (_b) {
                                        switch (_b.label) {
                                            case 0:
                                                this.blockSubscriptionManager.start();
                                                this.eventSubscriptionManager.start();
                                                _a = this;
                                                return [4 /*yield*/, this.eventSubscriptionManager.subscribe()];
                                            case 1:
                                                _a.logsSubscriber = _b.sent();
                                                return [2 /*return*/];
                                        }
                                    });
                                }); };
                                setup().then(resolve).catch(reject);
                            });
                        }
                        return [4 /*yield*/, this.subscribersReady];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    Tightbeam.prototype.bindResolvers = function () {
        return bindResolvers.bindResolvers(this);
    };
    Tightbeam.prototype.defaultCacheData = function (otherState) {
        if (otherState === void 0) { otherState = {}; }
        return merge(otherState, {
            data: {
                _transactions: []
            }
        });
    };
    return Tightbeam;
}());

exports.AbiMapping = AbiMapping.AbiMapping;
exports.abis = index;
exports.queries = index$1;
exports.utils = index$2;
exports.resolvers = index$3;
exports.services = index$4;
exports.subscribers = index$5;
exports.types = index$6;
exports.ContractCache = ContractCache.ContractCache;
exports.Tightbeam = Tightbeam;
