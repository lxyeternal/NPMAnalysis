export type NamedTransparent = 'transparent';
