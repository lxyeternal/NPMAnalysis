import throttle from 'lodash-es/throttle';

export default class ScrollPercent {
    constructor() {
        this._viewport = this.calculateViewport();
        this._scrollY = this.calculateScrollY();
        this._active = true;
        this._elements = [];

        this.init();
    }

    /**
     * Init
     */
    init() {
        this._resizeEvent = this.throttle(this.resize);
        this._scrollEvent = this.throttle(this.scroll);

        window.addEventListener("resize", this._resizeEvent);
        window.addEventListener("scroll", this._scrollEvent);

        this.refresh();
    }

    /**
     * Destroy
     */
    destroy() {
        window.removeEventListener('resize', this._resizeEvent);
        window.removeEventListener('scroll', this._scrollEvent);
    }

    /**
     * Get default element config
     * @return {Object}
     */
    static get defaultElementConfig() {
        return {
            active: true,
            percent: 0,
            visibleBehavior: "top",
            target: 0,
            hasTriggered: false,
            visible: false,
            triggerBehavior: "once",
            visibleBefore: false,
            visibleAfter: true,
            callback: function () {
            }
        };
    }

    /**
     * Find element
     * @param {mixed} id
     * @return {Object|undefined}
     */
    find(id) {
        return this.elements.find((el) => {
            return (el.id === id);
        });
    }

    /**
     * Add element
     * @param {mixed} id
     * @param {Element}
     * @param {Object}
     * @return {boolean}
     */
    add(id, element, config = {}) {
        config.element = element;
        config.id = id;

        this.elements.push(Object.assign(ScrollPercent.defaultElementConfig, config));

        return true;
    }

    /**
     * Remove element
     * @param {mixed} id
     * @param {boolean}
     */
    remove(id) {
        let index = this.elements.findIndex((el) => {
            return (el.id === element);
        });

        if (index >= 0) {
            this.elements.splice(index, 1);
            return true;
        }

        return false;
    }

    /**
     * Update element
     * @param {mixed} id
     * @param {Object} config
     * @param {boolean}
     */
    update(id, config = {}) {
        let index = this.elements.findIndex((el) => {
            return (el.id === id);
        });

        if (index >= 0) {
            this.elements[index] = Object.assign(this.elements[index], config);
        }
    }

    /**
     * Throttle
     * @param {function} func
     * @return function
     */
    throttle(func) {
        return throttle(func.bind(this), 100, {
            trailing: true,
            leading: true
        });
    }

    /**
     * Resize
     */
    resize() {
        this.viewport = this.calculateViewport();
    }

    /**
     * Scroll
     */
    scroll() {
        this.scrollY = this.calculateScrollY();
    }

    /**
     * Can refresh
     * @return {boolean}
     */
    canRefresh() {
        return this.active;
    }

    /**
     * Can refresh element
     * @param {Object}
     * @return {boolean}
     */
    canRefreshElement(element) {
        return element.active;
    }

    /**
     * Force refresh
     */
    forceRefresh() {
        this._viewport = this.calculateViewport();
        this._scrollY = this.calculateScrollY();
        this.refresh();
    }

    /**
     * Refresh
     */
    refresh() {
        if (this.canRefresh) {
            this.elements.forEach((element) => {
                if (this.canRefreshElement(element)) {
                    this.refreshElement(element);
                }
            });
        }
    }

    /**
     * Refresh element
     * @param {Element} element
     * @return {boolean}
     */
    refreshElement(element) {
        let percent = this.refreshElementPercent(element);
        let visible = this.refreshElementVisible(element, percent);

        element.percent = percent;

        if (this.canTrigger(element, percent, visible)) {
            element.visible = visible;
            element.hasTriggered = true;
            element.callback(element, percent, visible);

            return true;
        }

        return false;
    }

    /**
     * Can trigger
     * @param {Element} element
     * @param {number} percent
     * @param {boolean} visible
     * @return {boolean}
     */
    canTrigger(element, percent, visible) {
        if (typeof element.triggerBehavior === 'function') {
            return element.triggerBehavior(element, percent, visible);
        }

        switch (element.triggerBehavior) {
            case 'always':
                return true;
                break;
            case 'reverse':
                return (element.visible !== visible)
                break;
            case 'once':
                return (!element.hasTriggered && visible);
                break;
            case 'during':
                return visible;
                break;
        }
    }

    /**
     * Refresh element visible
     * @param {Element} element
     * @param {number} percent
     * @return {boolean}
     */
    refreshElementVisible(element, percent) {
        if (typeof element.target === 'function') {
            return element.target(element, percent);
        }

        if (element.visibleBefore && element.visibleAfter) {
            return true;
        } else if (element.visibleBefore) {
            return (percent <= element.target);
        } else if (element.visibleAfter) {
            return (percent >= element.target);
        } else {
            return (percent >= element.target && percent <= 1);
        }
    }

    /**
     * Refresh element percent
     * @param {Element} element
     * @return {boolean}
     */
    refreshElementPercent(element) {
        if (typeof element.visibleBehavior === 'function') {
            return element.visibleBehavior(element);
        }

        switch (element.visibleBehavior) {
            case "top":
                return this.calculateElementPercentTop(element);
                break;

            case "bottom":
                return this.calculateElementPercentBottom(element);
                break;

            case "height":
                return this.calculateElementPercentHeight(element);
                break;

            case "visible":
                return this.calculateElementPercentVisible(element);
                break;
        }
    }

    /**
     * Calculate element percent top
     * @param {Element} element
     * @return {boolean}
     */
    calculateElementPercentTop(element) {
        return (
            (
                this.scrollY
                - this.calculateElementTop(element.element)
            )
            / this.viewport.height
        ) + 1;
    }

    /**
     * Calculate element percent bottom
     * @param {Element} element
     * @return {boolean}
     */
    calculateElementPercentBottom(element) {
        return (
            (
                this.scrollY
                - (
                    this.calculateElementTop(element.element)
                    + this.calculateElementHeight(element.element)
                )
            )
            / this.viewport.height
        ) + 1;
    }

    /**
     * Calculate element percent height
     * @param {Element} element
     * @return {boolean}
     */
    calculateElementPercentHeight(element) {
        let min = this.calculateElementTop(element.element) - this.viewport.height;
        let max = min + this.calculateElementHeight(element.element);

        return (this.scrollY - min) / (max - min);
    }

    /**
     * Calculate element percent visible
     * @param {Element} element
     * @return {boolean}
     */
    calculateElementPercentVisible(element) {
        let min = this.calculateElementTop(element.element) - this.viewport.height;
        let max = min + this.calculateElementHeight(element.element) + this.viewport.height;

        return (this.scrollY - min) / (max - min);
    }

    /**
     * Calculate element top
     * @param {Element} element
     * @return {number}
     */
    calculateElementTop(element) {
        return element.getBoundingClientRect().top + scrollY;
    }

    /**
     * Calculate element height
     * @param {Element} element
     * @return {number}
     */
    calculateElementHeight(element) {
        return element.offsetHeight;
    }

    /**
     * Calculate scroll y
     * @return {number}
     */
    calculateScrollY() {
        return window.scrollY;
    }

    /**
     * Set elements
     * @param {Array} elements
     */
    set elements(elements) {
        this._elements = elements;
    }

    /**
     * Get elements
     * @return {Array}
     */
    get elements() {
        return this._elements;
    }

    /**
     * Set scrollY
     * @param {number} scrollY
     */
    set scrollY(scrollY) {
        if (scrollY !== this.scrollY) {
            this._scrollY = scrollY;
            this.refresh();
        }
    }

    /**
     * Get scrollY
     * @return {number}
     */
    get scrollY() {
        return this._scrollY;
    }

    /**
     * Calculate viewport
     * @return {Object}
     */
    calculateViewport() {
        return {
            width: window.innerWidth,
            height: window.innerHeight
        };
    }

    /**
     * Set viewport
     * @param {Object} d
     */
    set viewport(d) {
        if (d.width !== this.viewport.width || d.height !== this.viewport.height) {
            this._viewport = d;
            this.refresh();
        }
    }

    /**
     * Get viewport
     * @return {Object}
     */
    get viewport() {
        return this._viewport;
    }

    /**
     * Set active
     * @param {boolean} active
     */
    set active(active) {
        this._active = active;

        if (active) {
            this.refresh();
        }
    }

    /**
     * Get active
     * @return {boolean}
     */
    get active() {
        return this._active;
    }
}