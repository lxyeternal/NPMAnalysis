import resolve from '@rollup/plugin-node-resolve';
import babel from '@rollup/plugin-babel';
import { uglify } from 'rollup-plugin-uglify';

export default [
	{
		input: 'src/ScrollPercent.js',
		output: {
			name: 'ScrollPercent',
			file: 'dist/scrollpercent.js',
			format: 'umd'
		},
		plugins: [
			resolve(),
			babel({
				presets: [['@babel/preset-env']],
				exclude: ['node_modules/**']
			}),
			uglify()
		]
	},
	{
		input: 'src/ScrollPercent.js',
		output: {
			file: 'dist/scrollpercent.esm.js',
			format: 'es'
		},
        external: ['lodash-es/throttle']
	}
];