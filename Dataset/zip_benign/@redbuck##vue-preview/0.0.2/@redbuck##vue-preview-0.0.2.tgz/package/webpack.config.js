/**
 * Created by TY-xie on 2018/7/5.
 */
const webpack = require('webpack')
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin
const ExtractTextPlugin = require('extract-text-webpack-plugin')
const path = require('path')
module.exports = {
  devtool: 'cheap-module-source-map',
  entry: './src/index.js',
  output: {
	path: path.resolve(__dirname, './dist/'),
	filename: 'index.js',
	library: '@redbuck/vuePreviewer',
	libraryTarget: 'umd',
	umdNamedDefine: true,
  },
  resolve: {
	extensions: ['.js', '.vue'],
  },
  module: {
	loaders: [
	  {
		test: /\.js$/,
		loader: 'babel-loader',
		include: __dirname,
		exclude: /node_modules/,
	  },
	  {
		test: /\.vue$/,
		loader: 'vue-loader',
		include: __dirname,
		exclude: /node_modules/,
	  },
	],
  },
  plugins: [
	new webpack.LoaderOptionsPlugin({
	  minimize: true,
	}),
	new webpack.optimize.UglifyJsPlugin({
	  beautify: false,
	  comments: false,
	  compress: {
		warnings: false,
	  },
	}),
	new BundleAnalyzerPlugin(),
	new ExtractTextPlugin({
	  filename: 'css/vue-previewer.css',
	}),
  ],
}

