import './slidesJS.css';
import EventEmitter from './EventEmitter';
declare class SlidesJS {
    container: HTMLElement;
    nextKeys: string[];
    previousKeys: string[];
    currentSlide: number;
    eventController: EventEmitter;
    effectName: {
        all?: string;
        previous?: string;
        next?: string;
    };
    transition: number;
    slides: NodeListOf<HTMLElement>;
    lastSlide: HTMLElement;
    constructor(container: string, params: {
        nextKeys?: string[];
        previousKeys?: string[];
        effect?: {
            all?: string;
            previous?: string;
            next?: string;
        };
        transition?: number;
    });
    on(eventName: string, listener: () => void): void;
    next(): void;
    previous(): void;
    applyEffect(name?: string): void;
}
export default SlidesJS;
