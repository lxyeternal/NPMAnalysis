declare class EventEmitter {
    events: any;
    constructor();
    on(eventName: string, listener: () => void): () => void;
    removeListener(eventName: string, listener: () => void): void;
    emit(eventName: string, ...args: any): void;
    once(eventName: string, listener: () => void): void;
}
export default EventEmitter;
