var Path = require("path")
// var appPath = PA
module.exports = {
  entry:Path.resolve(__dirname,"./src","index.js"),
  output:{
    "path":"./lib/",
    "filename":"index.js"
  },
  module:{
    loaders:[
      {test:/\.js$/,exclude:/node_modules/,loader:"babel-loader",
        query:{
          presets:["es2015","react"]
        }},
      {test:/\.css$/,loader:"style-loader!css-loader"}
    ]
  }

}
