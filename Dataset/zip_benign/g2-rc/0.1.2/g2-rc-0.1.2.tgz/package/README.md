# g2-rc
chart插件g2的react 封装版本

Document
example:
import createG2 from "g2-rc"
...
render(){
  const Chart = createG2();
  return (
    <Chart
      dims={}
      initChart={(chart)=>{}}
      data={}
      forceFit={true}
      width={800}
      height={250}
      heightRatio={0.3}
      plotCfg={{
          margin: [20, 150, 100, 100]
      }}  
    />
    )
}

说明：
1.dims
用来给data中的列添加属性
具体见g2官网中的用法

2.initChart
接受一个function作为参数，该function接受一个chart对象最为参数，
该chart就是g2官网上的chart

3.data
数据源

4.forceFit
接受一个boolean值 如果为true
则chart宽度为100%

5.width
在forceFit为false时有效

6.height
chart高度

7.heightRatio
chart宽高比，会根据当前真实width 自动计算height
公式：height = width*heightRatio

8.plotCfg
设定chart的margin padding等 具体同官网
