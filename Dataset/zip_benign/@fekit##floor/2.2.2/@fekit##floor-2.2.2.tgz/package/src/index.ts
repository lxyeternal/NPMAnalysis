import { isArray, isNodeList, isElement, isString } from '@fekit/utils';

const win: any = window;
const getScrollTop = (area: any) => {
  return area ? area.scrollTop : document.documentElement.scrollTop || document.body.scrollTop;
};

// 兼容性处理
const RAF = (() => {
  return (
    win.requestAnimationFrame ||
    win.webkitRequestAnimationFrame ||
    win.mozRequestAnimationFrame ||
    function(callback: any) {
      setTimeout(callback, 1000 / 60);
    }
  );
})();
const fun = () => {};

class Floor {
  activeFloor: any;
  activeIndex: any;
  keepActive: any;
  once: any;
  free: any;
  on: any;
  floors: any;
  scrollStatus: any;
  task: any;
  area: any;
  scrollEvNode: any;
  offset: any;
  constructor(param: any = {}) {
    const { el = [], area = null, offset = 0, keepActive = 0, once = 0, on = {} } = param;
    this.area = isElement(area) ? area : document.documentElement;
    this.scrollEvNode = area ? area : window;
    this.offset = offset;

    if (param) {
      this.activeFloor = null;
      this.activeIndex = null;
      this.keepActive = keepActive;
      this.once = once;
      this.free = 1;
      if (this.once) {
        this.keepActive = false;
      }
      this.on = { ...{ up: fun, down: fun, end: fun, top: fun, init: fun, change: fun }, ...on };

      // 判断指定楼层元素的入参类型并自动获取DOM元素
      if (isArray(el)) {
        this.floors = el;
      } else if (isNodeList(el)) {
        this.floors = Array.prototype.slice.call(el);
      } else if (isElement(el)) {
        this.floors = [el];
      } else if (isString(el)) {
        this.floors = Array.prototype.slice.call(document.querySelectorAll(el)) || [];
      } else {
        this.floors = [];
      }

      // 当前是否正在执行一个核心任务
      let previousScrollTop = getScrollTop(this.area);
      // 任务排队标识
      let tasking = 1;
      let notInit = 0;
      let previousFloor: any = null;
      let nearestFloor = { floor: this.floors[0], index: 0 };
      // 遍历楼层是否有当前的
      let hasActive = 0;
      // 核心代码
      let core = () => {
        // 标识为任务进行中
        tasking = 0;
        // 获取滚动距离
        let scrollTop = getScrollTop(this.area);

        if (!this.once) {
          hasActive = 0;
        }
        const { top = 0 } = this.area.getBoundingClientRect();
        this.floors.forEach((item: any, index: any) => {
          if (isElement(item)) {
            let itemRect = item.getBoundingClientRect();
            let isChange = itemRect.top <= this.offset + top && itemRect.bottom > this.offset + top;
            if (isChange && !item.isActived) {
              this.activeFloor = item;
              this.activeIndex = index;
              hasActive = 1;
              // 是否仅执行一次
              if (this.once) {
                item.isActived = 1;
              }
            }
          }
        });

        if (hasActive) {
          // console.log('当前有');

          if (!notInit || this.activeFloor !== previousFloor) {
            // 初始化过了
            notInit = 1;
            this.on.change(this);
            previousFloor = this.activeFloor;
          }
        } else {
          if (!this.keepActive) {
            // console.log('当前无');
            this.activeFloor = null;
            this.activeIndex = null;
            if (!notInit || this.activeFloor !== previousFloor) {
              // 初始化过了
              notInit = 1;
              this.on.change(this);
              previousFloor = this.activeFloor;
            }
          } else {
            // console.log('最近值');
            this.floors.forEach((item: any, index: any) => {
              let itemRect = item.getBoundingClientRect();
              if (Math.abs(itemRect.top) < Math.abs(nearestFloor.floor.getBoundingClientRect().top)) {
                nearestFloor.floor = item;
                nearestFloor.index = index;
              }
            });
            this.activeFloor = nearestFloor.floor;
            this.activeIndex = nearestFloor.index;
            if (!notInit || this.activeFloor !== previousFloor) {
              // 初始化过了
              notInit = 1;
              this.on.change(this);
              previousFloor = this.activeFloor;
            }
          }
        }

        // 回调函数合集
        // 向向滚
        if (previousScrollTop > scrollTop) {
          this.scrollStatus = 'up';
          this.on.up(this);
        }
        // 向下滚
        else if (previousScrollTop < scrollTop) {
          this.scrollStatus = 'down';
          this.on.down(this);
        }
        // 到顶部
        if (scrollTop <= 0) {
          this.scrollStatus = 'top';
          this.on.top(this);
        }
        // 到底部
        if (this.area.scrollTop + this.area.clientHeight >= this.area.scrollHeight) {
          this.scrollStatus = 'end';
          this.on.end(this);
        }

        // 更新用于对比的值
        previousScrollTop = scrollTop;
        tasking = 1;
      };

      // 初始化
      this.on.init(this);
      // 添加一个滚动事件
      core();
      this.task = (): any => {
        if (tasking && this.free) {
          RAF(() => {
            core();
          });
        } else {
          return false;
        }
      };
      this.scrollEvNode.addEventListener('scroll', this.task);
    }
  }

  // 添加楼层
  add(el: any, cb = (_el: any) => {}) {
    if (el) {
      this.floors.push(el);
      cb(el);
    }
  }

  // 删除楼层
  del(el: any, cb = (_el: any) => {}) {
    if (isElement(el)) {
      this.floors.splice(this.floors.indexOf(el) > -1 && this.floors.indexOf(el), 1);
      cb(el);
    }
  }

  // 注销
  destroy() {
    this.area.removeEventListener('scroll', this.task);
  }
}

export default Floor;
