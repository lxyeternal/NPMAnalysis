import { BaseType, Selection } from 'd3-selection';
import Config from '../Config';
import { ScatterDatum } from '../types/general';
import DataManager from './DataManager';
declare type ScatterNode<Value, Type extends BaseType> = Selection<Type, ScatterDatum<Value>, HTMLElement, ScatterDatum<Value>[]>;
declare class ScatterManager<Value> extends DataManager<ScatterDatum<Value>> {
    private _scatterBinding;
    private _detachedContainer;
    constructor(opts: Config<ScatterDatum<Value>>);
    x: (d: ScatterDatum<Value>) => number;
    y: (d: ScatterDatum<Value>) => number;
    bindScatter: (data: ScatterDatum<Value>[]) => void;
    private updateScatterPoints;
    private joinScatterPoints;
    get binding(): ScatterNode<Value, BaseType>;
    get type(): 'data';
}
export default ScatterManager;
