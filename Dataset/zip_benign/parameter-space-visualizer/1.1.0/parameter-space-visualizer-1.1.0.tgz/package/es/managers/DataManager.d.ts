import Config from '../Config';
import { ParamsTuple } from '../types/general';
import { DataManagerScaleTuple } from '../types/scale';
declare class DataManager<Datum> {
    private paramScales;
    protected config: Config<Datum>;
    constructor(config: Config<Datum>);
    initScales(config: Config<Datum>): void;
    bindCurrentScalesRange(w: number, h: number): void;
    set params(params: ParamsTuple | undefined | null);
    get params(): ParamsTuple | undefined | null;
    get currentScales(): DataManagerScaleTuple;
}
export default DataManager;
