import { Rect } from '@timohausmann/quadtree-js';
import { Delaunay } from 'd3-delaunay';
declare abstract class ChartAreaDataManager<Datum> {
    constructor();
    abstract bindData(data: ArrayLike<Datum>): void;
    abstract find(pointer: [number, number]): Datum | undefined;
}
declare type GetCoordinate<P> = Delaunay.GetCoordinate<P, ArrayLike<P> | Iterable<P>>;
export declare class ChartAreaDelaunayManager<Point extends {
    x: number;
    y: number;
}> extends ChartAreaDataManager<Point> {
    private _delaunay?;
    private _data?;
    private _getX;
    private _getY;
    constructor(getX: GetCoordinate<Point>, getY: GetCoordinate<Point>);
    bindData: (data: ArrayLike<Point>) => void;
    find: (pointer: [number, number]) => Point | undefined;
}
export declare class ChartAreaQuadTreeManager<RectDatum extends Rect> extends ChartAreaDataManager<RectDatum> {
    private _w;
    private _h;
    private _quadTree?;
    constructor(w: number, h: number);
    bindData: (data: ArrayLike<Rect>) => void;
    find: ([x, y]: [number, number]) => RectDatum | undefined;
}
export default ChartAreaDataManager;
