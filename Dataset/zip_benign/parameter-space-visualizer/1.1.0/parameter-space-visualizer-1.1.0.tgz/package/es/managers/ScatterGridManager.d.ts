import { Selection, BaseType } from 'd3-selection';
import { ScaleLinear } from 'd3-scale';
import Config from '../Config';
import { ProbabilityDatum } from '../types/expression';
import DataManager from './DataManager';
export declare type CoordsScales = [ScaleLinear<number, number>, ScaleLinear<number, number>];
declare class ScatterGridManager extends DataManager<ProbabilityDatum> {
    private _scatterBinding;
    private _detachedContainer;
    private distributionScales;
    private _density;
    private dimensions;
    constructor(config: Config<ProbabilityDatum>, density?: number);
    bindScatter(density: number): void;
    get binding(): Selection<BaseType, any, HTMLElement, []>;
    get coordsScales(): CoordsScales;
    get density(): number;
    set density(density: number);
    private updateScatterPoints;
    private joinScatterPoints;
    get type(): 'grid';
}
export default ScatterGridManager;
