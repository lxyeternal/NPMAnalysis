import { ZoomedElementBaseType, ZoomTransform } from 'd3-zoom';
declare type ZoomListener = (translate: ZoomTransform) => void;
declare class Zoom<ZoomRefElement extends ZoomedElementBaseType> {
    private zoomListeners;
    private _currentTransfrom;
    zoom: import("d3-zoom").ZoomBehavior<ZoomRefElement, unknown>;
    constructor(scaleExtent?: [number, number], translateExtent?: [[number, number], [number, number]]);
    private handleZoom;
    onChange(listener: ZoomListener): void;
    removeListeners(): void;
    get currentTransfrom(): ZoomTransform;
}
export default Zoom;
