import { BaseType, Selection } from 'd3-selection';
import Config from '../Config';
import { RegionDatum } from '../types/general';
import DataManager from './DataManager';
declare type RegionNode<Value, Type extends BaseType> = Selection<Type, RegionDatum<Value>, HTMLElement, RegionDatum<Value>[]>;
declare class RegionsManager<Value> extends DataManager<RegionDatum<Value>> {
    private _regionsBinding;
    private _detachedContainer;
    constructor(opts: Config<RegionDatum<Value>>);
    x: (d: RegionDatum<Value>) => number;
    y: (d: RegionDatum<Value>) => number;
    w: (d: RegionDatum<Value>) => number;
    h: (d: RegionDatum<Value>) => number;
    bindRegions: (data: RegionDatum<Value>[]) => void;
    private updateRegion;
    private joinRegions;
    get regionsBinding(): RegionNode<Value, BaseType>;
}
export default RegionsManager;
