import { ScaleBand, ScaleLinear, ScaleTime, ScaleLogarithmic, ScalePower, ScaleSymLog, ScaleRadial, ScaleQuantile, ScaleQuantize, ScaleThreshold, ScaleOrdinal, ScalePoint, NumberValue } from 'd3-scale';
declare type ValueOf<Scale> = Scale[keyof Scale];
export interface AnyD3Scales {
    linear: ScaleLinear<any, any>;
    log: ScaleLogarithmic<any, any>;
    pow: ScalePower<any, any>;
    sqrt: ScalePower<any, any>;
    symlog: ScaleSymLog<any, any>;
    radial: ScaleRadial<any, any>;
    time: ScaleTime<any, any>;
    utc: ScaleTime<any, any>;
    quantile: ScaleQuantile<any>;
    quantize: ScaleQuantize<any>;
    threshold: ScaleThreshold<any, any>;
    ordinal: ScaleOrdinal<any, any>;
    point: ScalePoint<any>;
    band: ScaleBand<any>;
}
export declare type ScaleInput<Scale extends AnyD3Scale> = Parameters<Scale>[0];
export declare type TickFormatter<T> = (value: T) => string | undefined;
/**
 * A catch-all type for all D3 scales.
 */
export declare type AnyD3Scale = ValueOf<AnyD3Scales>;
export declare type DataManagerScaleType = {
    scale: ScaleLinear<number, number>;
    extent: [NumberValue, NumberValue];
} | undefined;
export declare type DataManagerScaleTuple = [DataManagerScaleType, DataManagerScaleType];
export {};
