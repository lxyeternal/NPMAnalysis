import { Rect } from '@timohausmann/quadtree-js';
import { HCLColor } from 'd3-color';
import { NumberValue, ScaleLinear } from 'd3-scale';
import { TooltipValueAccessor } from '../components/Tooltip';
import { ProbabilityDatum, VariableInterval } from './expression';
import { TickFormatter } from './scale';
export declare type ParamType = string;
export declare type Params = {
    x: ParamType;
    y?: ParamType;
} | ParamType;
export declare type ParamsTuple = [ParamType, ParamType] | [ParamType, undefined];
export declare type ParamsFixation = Record<ParamType, number | string>;
export declare type ParamsChangeHandler = (p: ParamsTuple | null) => void;
export declare type FixationChangeHandler = (f: ParamsFixation) => void;
export declare type UserMargin = {
    top?: number;
    left?: number;
    bottom?: number;
    right?: number;
};
export declare type UserAxesConfig<ScaleInput> = {
    tickFontSize?: number;
    tickCount?: number;
    tickFormatter?: TickFormatter<ScaleInput>;
    tickStrokeColor?: string;
    tickSize?: number;
};
export declare type UserGridConfig = {
    color?: string;
};
export declare type UserOptions<Datum, XScaleInput, YScaleInput> = {
    params?: Params;
    paramsFixation?: ParamsFixation;
    handleParamsChange?: ParamsChangeHandler;
    handleFixationChange?: FixationChangeHandler;
    margin?: UserMargin;
    color?: (d: Datum) => string;
    axes?: {
        x: UserAxesConfig<XScaleInput>;
        y?: UserAxesConfig<YScaleInput>;
    };
    grid?: {
        x?: UserGridConfig;
        y?: UserGridConfig;
    };
    tooltip?: boolean;
    tooltipContent?: TooltipValueAccessor<Datum>;
    maxZoomExtent?: number;
};
export declare type Margin = {
    top: number;
    left: number;
    bottom: number;
    right: number;
};
export declare type AxesConfig<ScaleInput> = UserAxesConfig<ScaleInput> & {
    tickFontSize: number;
    tickSize: number;
    tickCount: number;
    tickStrokeColor: string;
};
export declare type Options<UOpts> = UOpts extends UserOptions<infer Datum, infer XScaleInput, infer YScaleInput> ? {
    params?: Params;
    margin: Margin;
    handleParamsChange?: ParamsChangeHandler;
    handleFixationChange?: FixationChangeHandler;
    color?: (d: Datum) => string;
    axes: {
        x: AxesConfig<XScaleInput>;
        y?: AxesConfig<YScaleInput>;
    };
    grid?: {
        x?: UserGridConfig;
        y?: UserGridConfig;
    };
    tooltip?: boolean;
    tooltipContent?: TooltipValueAccessor<Datum>;
    maxZoomExtent: number;
} : never;
export interface RegionDatum<Value = unknown> {
    value: Value;
    params: Record<string, {
        from: NumberValue;
        to: NumberValue;
    }>;
}
export interface ScatterDatum<Value = unknown> {
    value: Value;
    params: Record<string, NumberValue>;
}
export declare type ChartConfig<Datum> = {
    data: Array<Datum>;
} & ChartConfigCommon<Datum>;
export declare type ExpressionConfigPart = {
    expression: string;
    intervals: VariableInterval[];
    data?: never;
};
export declare type DataConfigPart<Datum> = {
    expression?: never;
    intervals?: never;
    data: Array<Datum>;
};
export declare type ChartConfigCommon<Datum> = {
    options?: UserOptions<Datum, NumberValue, NumberValue>;
    width: number;
    height: number;
};
export declare type ChartConfigDynamic<Datum> = ChartConfigCommon<Datum> & (ExpressionConfigPart | DataConfigPart<Datum>);
export declare type ExpressionConfig = ChartConfigCommon<ScatterDatum<ProbabilityDatum>> & ExpressionConfigPart;
export declare type DataConfig<Value> = ChartConfigCommon<ScatterDatum<Value>> & DataConfigPart<ScatterDatum<Value>>;
export declare type SimpleConfigCommon = {
    el: MountElement;
    width: number;
    height: number;
};
export declare type SimpleConfigScatter<Value extends string | number | symbol> = ({
    data: ScatterDatum<Value>[];
    expression?: never;
    intervals?: never;
    url?: never;
    colors?: Record<Value, string>;
    parseCSVValue?: never;
} | {
    data?: never;
    expression: string;
    intervals: VariableInterval[];
    url?: never;
    color?: ScaleLinear<HCLColor, string, never>;
    parseCSVValue?: never;
} | {
    data?: never;
    expression?: never;
    intervals?: never;
    url: string;
    colors?: Record<Value, string>;
    parseCSVValue: (v: string) => Value;
}) & {} & SimpleConfigCommon;
export declare type SimpleConfigRegions<Value extends string | number | symbol> = ({
    data: RegionDatum<Value>[];
    url?: never;
    parseCSVValue?: never;
} | {
    data?: never;
    url: string;
    parseCSVValue: (v?: string) => Value;
}) & {
    colors?: Record<Value, string>;
} & SimpleConfigCommon;
export declare type MountElement = string | HTMLElement;
export declare type DatumRect<Datum> = Datum & Rect;
export declare type DataTransform<Datum> = (data: Datum[], fixs?: ParamsFixation) => Datum[];
