export declare type VariableInterval = {
    name: string;
    start: number;
    end: number;
};
export declare type ProbabilityDatum = {
    name: string;
    value: string | number;
};
export declare type Token = {
    token: string;
    type: number;
    value?: string | ((a: number, b?: number) => number) | undefined;
    show: string;
    preced?: number | undefined;
};
export declare type EvalFunction = (pair: object) => string | number;
