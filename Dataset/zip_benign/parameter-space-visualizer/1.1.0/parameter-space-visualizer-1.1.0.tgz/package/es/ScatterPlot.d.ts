import Chart from './Chart';
import ScatterGridManager from './managers/ScatterGridManager';
import ScatterManager from './managers/ScatterManager';
import { ProbabilityDatum } from './types/expression';
import { ChartConfigDynamic, MountElement, ScatterDatum, SimpleConfigScatter } from './types/general';
declare type Datum<Value> = ScatterDatum<Value> | ProbabilityDatum;
declare type Point<Value> = Datum<Value> & {
    x: number;
    y: number;
};
export declare class CustomScatterPlot<Value> extends Chart<Datum<Value>> {
    private _dataManager;
    private chartAreaDataManager?;
    private expression?;
    private variableTokens?;
    private samplingProxy?;
    private g?;
    private highlight?;
    private tooltip?;
    constructor(element: MountElement, config: ChartConfigDynamic<Datum<Value>>);
    private initWithData;
    private initWithExpression;
    highlightPoint({ x, y }: Point<Value>): void;
    private initHighlightLayer;
    private draw;
    redraw: (transform?: import("d3-zoom").ZoomTransform) => Promise<void>;
    reset: () => void;
    data: (data: ScatterDatum<Value>[]) => void;
    bindDataToChartArea: (data?: Datum<Value>[]) => void;
    bindScatterGridToChartArea: () => void;
    private initChartAreaDataManager;
    private bindMouseMove;
    private transfromDatumToPoint;
    private applyZoomTransformToPoint;
    private enhanceBindingWithFillStyle;
    private runSampling;
    get dataManager(): ScatterGridManager | ScatterManager<Value>;
}
export default class ScatterPlot<Value extends string> {
    private root;
    private chartRoot;
    private chart;
    private chartUI;
    private chartLegend?;
    private color?;
    constructor({ el, width, height, expression, intervals, data, ...rest }: SimpleConfigScatter<Value>);
    private fetchData;
    private initProbabilitySamplingUI;
    remove(): void;
}
export {};
