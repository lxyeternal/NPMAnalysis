export declare const POINT_RADIUS = 7;
export declare const MAX_DENSITY = 150;
