/**
 * Purpose of this array is to provide maximally distinct colors.
 * It is computationally expensive to generate even few of these colors at runtime.
 *
 * Took from: https://stackoverflow.com/a/33295456
 */
export declare const DISTINCT_COLORS: string[];
