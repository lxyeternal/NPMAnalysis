export declare const font = "var(--doc-font-family)";
export declare const theme: {
    readonly colors: {
        readonly textColor: "#5a5a5a";
        readonly lightText: "#c2c2c2";
        readonly white: "#ffffff";
        readonly black: "#000000";
        readonly primary: "#f68328";
        readonly lightGrey: "#c7c7c7";
        readonly grey: "#9b9b9b";
    };
    readonly borderRadius: {
        readonly deafult: "0.25rem";
    };
    readonly boxShadow: {
        readonly default: "rgb(0 0 0 / 10%) 0px 0px 0.625rem 0.1875rem";
    };
    readonly font: "var(--doc-font-family)";
};
