import { RegionResultValue } from '../lib/data/parse';
import { Margin } from '../types/general';
export declare const UNDEFINED_CHART_VALUE = 0;
export declare const ZERO_MARGIN: Margin;
export declare const DEFAULT_CHART_MARGIN: Margin;
export declare const COLOR_MAPPING: Record<RegionResultValue, string>;
export declare const DEFAUL_COLOR_SCALE: import("d3-scale").ScaleLinear<import("d3-color").HCLColor, string, never>;
export declare const AXIS_LABEL_OFFSET = 30;
