import { createURLWorkerFactory } from './_rollup-plugin-web-worker-loader__helper__browser__createURLWorkerFactory';

var WorkerFactory = createURLWorkerFactory('web-worker-1.js');
/* eslint-enable */

export default WorkerFactory;
//# sourceMappingURL=samplingWorker.ts.map
