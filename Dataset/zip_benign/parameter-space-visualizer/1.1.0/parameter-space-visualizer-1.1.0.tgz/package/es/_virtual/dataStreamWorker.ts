import { createURLWorkerFactory } from './_rollup-plugin-web-worker-loader__helper__browser__createURLWorkerFactory';

var WorkerFactory = createURLWorkerFactory('web-worker-0.js');
/* eslint-enable */

export default WorkerFactory;
//# sourceMappingURL=dataStreamWorker.ts.map
