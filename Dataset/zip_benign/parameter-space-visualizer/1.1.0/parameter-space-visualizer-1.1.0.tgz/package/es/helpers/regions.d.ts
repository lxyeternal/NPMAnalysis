import { NumberValue } from 'd3-scale';
import { ParamsFixation, RegionDatum } from '../types/general';
export declare const isRegionsData: <Value>(data: unknown[]) => data is RegionDatum<Value>[];
export declare const getParams: <Value>(data: RegionDatum<Value>[]) => string[];
export declare const getParamDomain: <Value>(data: RegionDatum<Value>[], param: string) => NumberValue[];
export declare const isValueInRange: (range: {
    from: NumberValue;
    to: NumberValue;
}, value: NumberValue) => boolean;
export declare const applyParamsFixations: <Value>(data: RegionDatum<Value>[], fixs?: ParamsFixation | undefined) => RegionDatum<Value>[];
