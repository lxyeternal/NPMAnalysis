import { ScaleOrdinal } from 'd3-scale';
import { AnyD3Scale, ScaleInput, TickFormatter } from '../types/scale';
export declare const getTicks: <Scale extends AnyD3Scale>(scale: Scale, count?: number | undefined) => ScaleInput<Scale>[];
export declare const getTicksFormatter: <Scale extends AnyD3Scale>(scale: Scale) => TickFormatter<ScaleInput<Scale>>;
export declare const extendParamsColorScale: <Datum>(color: ScaleOrdinal<string, string, never>, data: Datum[]) => void;
