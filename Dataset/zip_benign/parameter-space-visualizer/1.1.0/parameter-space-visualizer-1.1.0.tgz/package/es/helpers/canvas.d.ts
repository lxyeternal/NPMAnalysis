import { Rect } from '@timohausmann/quadtree-js';
export declare const rectsOverlapping: (r1: Rect, r2: Rect) => boolean;
