import { ProbabilityDatum, Token, VariableInterval } from '../types/expression';
import { ParamsFixation, ScatterDatum } from '../types/general';
export declare const createVariableTokens: (variable: string) => Token;
export declare const isVariableIntervalData: (data: unknown[]) => data is VariableInterval[];
export declare const isProbabilityData: (data: unknown[]) => data is ProbabilityDatum[];
export declare const getParams: (data: (VariableInterval | ProbabilityDatum)[]) => string[];
export declare const getParamDomain: (data: VariableInterval[], param: string) => number[];
export declare const getParamDomainFromProbabData: (data: ProbabilityDatum[], param: string) => number[];
export declare const createStubProbabilityData: (intervals: VariableInterval[]) => {
    name: string;
    value: number;
}[];
export declare const applyParamsFixations: <Value>(data: ScatterDatum<Value>[], fixs?: ParamsFixation | undefined) => ScatterDatum<Value>[];
