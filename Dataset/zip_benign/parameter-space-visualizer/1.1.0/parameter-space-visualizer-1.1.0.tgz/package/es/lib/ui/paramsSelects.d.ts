import { ParamsChangeHandler } from '../../types/general';
import { StyleDeclaration } from './general';
declare type ParamSetCb = (v: string) => void;
export declare const findParam: (params: string[], param?: string | undefined) => [number, string | undefined];
export declare const createParamsSelectOptions: (params: string[], defaultParam?: string | undefined) => HTMLOptionElement[];
export declare const createParamsSelect: (params: string[], label: string, defaultParam?: string | undefined, style?: Partial<StyleDeclaration>) => [HTMLDivElement, HTMLSelectElement];
export declare const appendParamsSelects: (el: HTMLElement, params: string[], x: ParamSetCb, defaultX?: string | undefined, y?: ParamSetCb | undefined, defaultY?: string | undefined) => ParamsChangeHandler;
export {};
