import { StyleDeclaration } from './general';
export declare const labelDefaultStyle: StyleDeclaration;
export declare const defaultInputStyle: Partial<StyleDeclaration>;
