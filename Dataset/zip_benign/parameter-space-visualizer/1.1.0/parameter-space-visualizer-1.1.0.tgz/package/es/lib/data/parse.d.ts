import { DSVRowString } from 'd3-dsv';
import { ScatterDatum } from '../../types/general';
export declare type RegionResultValue = 'true' | 'false' | 'unknown' | 'partially_sat' | 'partially_violated' | 'center_sat' | 'center_violated';
export interface RegionResult<T> {
    value: T;
    params: Record<string, {
        from: number;
        to: number;
    }>;
}
export declare type RawCSVObject = Array<Record<string, string | undefined>>;
export declare type RegionResults<T> = Array<RegionResult<T>>;
export declare const parseFraction: (fract: string) => number;
export declare const parseParam: (param: string | undefined) => {
    from: number;
    to: number;
};
export declare const parseValue: (value: string | undefined) => RegionResultValue;
export declare const rowToRegionResult: <Value = RegionResultValue>(parseVal?: ((v?: string | undefined) => Value) | undefined) => (rawRow: DSVRowString<string>) => RegionResult<Value> | undefined;
export declare const csvToRegionResultsList: <Value = RegionResultValue>(raw: RawCSVObject, parseVal?: ((v?: string | undefined) => Value) | undefined) => RegionResults<Value>;
export declare const csvToRegionResults: <Value = RegionResultValue>(csv: string, parseVal?: ((v?: string | undefined) => Value) | undefined) => RegionResults<Value>;
export declare const rowToScatterPoint: <Value = RegionResultValue>(parseVal?: (v: string) => Value) => (rawRow: DSVRowString<string>) => ScatterDatum<Value> | undefined;
export declare const csvToScatterPointsList: <Value>(raw: RawCSVObject, parseVal?: ((v: string) => Value) | undefined) => ScatterDatum<Value>[];
export declare const csvToScatterPoints: <Value>(csv: string, parseVal?: ((v: string) => Value) | undefined) => ScatterDatum<Value>[];
