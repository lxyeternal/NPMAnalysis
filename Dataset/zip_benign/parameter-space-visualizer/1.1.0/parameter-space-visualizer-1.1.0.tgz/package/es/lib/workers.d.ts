export declare const DataWorker: new () => Worker;
export declare const SamplingWorker: new () => Worker;
