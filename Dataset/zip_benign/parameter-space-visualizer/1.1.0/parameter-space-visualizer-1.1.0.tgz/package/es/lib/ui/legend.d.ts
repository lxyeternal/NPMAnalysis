import { HCLColor } from 'd3-color';
import { ScaleLinear } from 'd3-scale';
import { Selection } from 'd3-selection';
export declare const createChartLegend: (el: HTMLElement, values: string[], color: (v: string) => string, rectSize?: number, width?: number) => {
    legend: Selection<SVGSVGElement, unknown, null, undefined>;
    update: (v: string[]) => void;
};
export declare const createGradientChartLegend: (el: HTMLElement, colorScale: ScaleLinear<HCLColor, string, never>) => void;
