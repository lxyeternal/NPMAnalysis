import { DSVRowArray, DSVRowString } from 'd3-dsv';
import { Token } from '../../types/expression';
/**
 * Used to retrieve entire CSV from remote location
 *
 * @param from URL of desired CSV
 * @param parser CSV row parser
 * @returns
 */
export declare const fetchCSV: <Column extends string, ParsedRow = DSVRowString<Column>>(from: string, parser?: ((row: DSVRowArray<Column>) => ParsedRow[]) | undefined) => Promise<ParsedRow[]>;
/**
 * Retrieves the last line of the text separated by \n
 * @param text
 * @returns Tuple - fst is last line, snd is index of the end of the penultimate line
 */
export declare const getLastTextLine: (text: string) => [string, number];
/**
 * Used for parsing Uint8Array chunks in ReadableStream
 */
export declare const csvStreamParser: () => {
    parseChunk(chunk: Uint8Array): {}[];
    lastLine: string;
};
export declare const calculateSampling: (pairs: Record<string, string | number>[], expression: string, tokens: Token[]) => (string | number)[];
