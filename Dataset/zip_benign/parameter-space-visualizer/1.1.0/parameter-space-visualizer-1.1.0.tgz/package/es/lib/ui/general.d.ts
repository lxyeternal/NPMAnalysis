import { theme } from "../../constants/styles";
export declare type StyleDeclaration = {
    [P in keyof CSSStyleDeclaration]?: string;
};
export declare const camelToDashCase: (str: string) => string;
export declare const applyStyles: (el: HTMLElement, style: StyleDeclaration) => void;
export declare const addStyle: (style: string | ((t: typeof theme) => string), id?: string | undefined) => void;
export declare const rem: (value: number, base?: number) => string;
