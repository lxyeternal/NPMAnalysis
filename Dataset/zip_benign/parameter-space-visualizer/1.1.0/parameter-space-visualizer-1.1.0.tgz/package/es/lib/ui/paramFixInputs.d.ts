import { ParamsFixation } from '../../types/general';
export declare const appendParamFixInputs: (el: HTMLElement, params: ParamsFixation, onChange: (p: ParamsFixation) => void) => (fixs: ParamsFixation) => void;
