declare type OnLoadCallback = (values: {}[]) => void;
declare const worker: {
    streamData: (filename: string, onLoad: OnLoadCallback) => Promise<import("d3-dsv").DSVRowArray<string>>;
};
export declare type DataStreamWorker = typeof worker;
export {};
