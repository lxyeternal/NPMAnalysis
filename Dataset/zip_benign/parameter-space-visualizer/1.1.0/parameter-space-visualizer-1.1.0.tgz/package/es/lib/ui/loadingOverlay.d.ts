export declare const addLoadingOverlay: (el: HTMLElement) => HTMLDivElement;
