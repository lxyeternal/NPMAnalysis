declare const worker: {
    calculateSampling: (pairs: Record<string, string | number>[], expression: string, tokens: import("../../types/expression").Token[]) => (string | number)[];
};
export declare type SamplingWorkerType = typeof worker;
export {};
