export declare const gradientLegend: (color: any, { title, tickSize, width, height, marginTop, marginRight, marginBottom, marginLeft, ticks, tickFormat, tickValues, }?: {
    title: any;
    tickSize?: number | undefined;
    width?: any;
    height?: number | undefined;
    marginTop?: number | undefined;
    marginRight?: any;
    marginBottom?: number | undefined;
    marginLeft?: number | undefined;
    ticks?: number | undefined;
    tickFormat: any;
    tickValues: any;
}) => SVGSVGElement | null;
