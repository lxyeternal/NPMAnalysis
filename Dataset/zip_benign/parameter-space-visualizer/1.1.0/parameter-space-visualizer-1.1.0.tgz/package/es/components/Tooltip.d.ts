import { SimpleSelection } from '../types/selection';
export declare type TooltipFO = SimpleSelection<SVGForeignObjectElement>;
export declare type TooltipSelection = SimpleSelection<HTMLDivElement>;
export declare type TooltipValueAccessor<Datum> = (d: Datum) => string;
declare class Tooltip<Datum> {
    private fo;
    private tooltip;
    private inner;
    private valueAccessor;
    constructor(svg: SimpleSelection<SVGGElement>, valueAccessor: TooltipValueAccessor<Datum>);
    static styleTooltipInner(tooltip: TooltipSelection): void;
    static styleTooltip(tooltip: TooltipSelection): void;
    static hideTooltip(tooltip: TooltipFO): void;
    static showTooltip(tooltip: TooltipFO): void;
    static handleTooltipOverflow(fo: TooltipFO, x: number, y: number): void;
    showTooltip({ x, y, ...d }: Datum & {
        x: number;
        y: number;
    }): void;
    hideTooltip(): void;
}
export default Tooltip;
