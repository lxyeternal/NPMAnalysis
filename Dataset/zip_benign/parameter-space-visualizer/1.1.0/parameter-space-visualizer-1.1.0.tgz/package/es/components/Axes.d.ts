import { ZoomTransform } from 'd3-zoom';
import Config from '../Config';
import DataManager from '../managers/DataManager';
import { SimpleSelection } from '../types/selection';
declare class Axes {
    private gx?;
    private gy?;
    private labelX?;
    private labelY?;
    private config;
    private dataManager;
    constructor(el: SimpleSelection<SVGGElement>, config: Config<any>, dataManager: DataManager<any>);
    redrawAxes: (transform?: ZoomTransform) => void;
    private initLabels;
}
export default Axes;
