import { ZoomTransform } from 'd3-zoom';
import Config from '../Config';
import DataManager from '../managers/DataManager';
import { SimpleSelection } from '../types/selection';
declare class Grid {
    private gx?;
    private gy?;
    private config;
    private dataManager;
    constructor(el: SimpleSelection<SVGGElement>, config: Config<any>, dataManager: DataManager<any>);
    redrawGrid: (transform?: ZoomTransform) => void;
}
export default Grid;
