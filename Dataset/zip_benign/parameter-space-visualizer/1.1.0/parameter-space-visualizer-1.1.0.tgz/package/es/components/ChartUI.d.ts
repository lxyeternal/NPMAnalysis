import Chart from '../Chart';
import { StyleDeclaration } from '../lib/ui/general';
import { FixationChangeHandler, ParamsChangeHandler } from '../types/general';
declare class ChartUI {
    private root;
    private controls?;
    private inputs;
    handleParamsChange?: ParamsChangeHandler;
    handleFixationChange?: FixationChangeHandler;
    constructor(root: HTMLElement);
    initChartUI(chart: Chart<any>): void;
    addInput: (name: string, value: number | string, onChange: (value: number, ev: Event) => void, style?: StyleDeclaration | undefined) => void;
    remove: () => void;
}
export default ChartUI;
