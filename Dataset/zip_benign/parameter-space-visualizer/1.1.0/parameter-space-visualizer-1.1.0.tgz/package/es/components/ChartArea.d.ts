import { SimpleSelection } from '../types/selection';
import { Margin } from '../types/general';
export declare type ChartAreaMouseEvents = 'mousemove' | 'mouseover' | 'mouseout';
export declare type ChartAreaMouseEventCb<Datum extends {}> = (data: Datum[], pointer: [number, number]) => void;
declare class ChartArea {
    private container;
    private _canvas;
    private _svg;
    constructor(root: SimpleSelection<HTMLDivElement>, w: number, h: number, m: Margin);
    get canvas(): SimpleSelection<HTMLCanvasElement>;
    get context(): CanvasRenderingContext2D | null | undefined;
    get svg(): SimpleSelection<SVGSVGElement>;
}
export default ChartArea;
