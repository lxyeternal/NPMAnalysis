import { ZoomTransform } from 'd3-zoom';
import Axes from './components/Axes';
import ChartArea from './components/ChartArea';
import Grid from './components/Grid';
import Config from './Config';
import DataManager from './managers/DataManager';
import Zoom from './managers/Zoom';
import { ChartConfig, ChartConfigDynamic, MountElement, ParamsFixation } from './types/general';
import { SimpleSelection } from './types/selection';
declare abstract class Chart<Datum> {
    protected el?: SimpleSelection<HTMLDivElement>;
    protected config: Config<Datum>;
    protected chartArea?: ChartArea;
    protected axes?: Axes;
    protected grid?: Grid;
    protected svg?: SimpleSelection<SVGGElement>;
    protected zoom?: Zoom<HTMLCanvasElement>;
    private _width;
    private _height;
    constructor(element: MountElement, config: ChartConfig<Datum> | ChartConfigDynamic<Datum>);
    protected addAxes(dataManager: DataManager<Datum>): void;
    protected addGrid(dataManager: DataManager<Datum>, color?: string): void;
    fixate: (fixations: ParamsFixation) => void;
    resetZoom: () => void;
    /**
     * Change param displayed on axis x
     * @param param
     */
    x: (param: string) => void;
    /**
     * Change param displayed on axis y
     * @param param
     */
    y: (param?: string | undefined) => void;
    abstract reset(): void;
    abstract redraw(transform: ZoomTransform): void;
    get width(): number;
    get height(): number;
    get allParams(): string[];
    get params(): import("./types/general").ParamsTuple | null | undefined;
    get paramFixations(): ParamsFixation | undefined;
    get chartValues(): string[];
}
export default Chart;
