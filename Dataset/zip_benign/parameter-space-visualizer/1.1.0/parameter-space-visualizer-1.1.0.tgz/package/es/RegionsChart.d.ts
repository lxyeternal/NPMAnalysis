import { ZoomTransform } from 'd3-zoom';
import Chart from './Chart';
import { ChartConfig, DatumRect, MountElement, RegionDatum, SimpleConfigRegions } from './types/general';
export declare class CustomRegionsChart<Value> extends Chart<RegionDatum<Value>> {
    private dataManager;
    private chartAreaDataManager?;
    private g?;
    private highlight?;
    private showTooltipAndRect?;
    constructor(element: MountElement, config: ChartConfig<RegionDatum<Value>>);
    highlightRect({ x, y, width, height }: DatumRect<RegionDatum<Value>>): void;
    private initHighlightLayer;
    redraw: (transform?: ZoomTransform) => void;
    reset: () => void;
    data: (data: RegionDatum<Value>[]) => void;
    bindDataToChartArea: () => void;
    private transfromDatumToRect;
    private applyZoomTransformToRect;
}
export default class RegionsChart<Value extends string> {
    private root;
    private chartRoot;
    private chart;
    private chartUI;
    private chartLegend;
    private color;
    constructor({ el, width, height, data, colors, ...rest }: SimpleConfigRegions<Value>);
    private fetchData;
    remove(): void;
}
