# 通路柱状图

- 基于Echrets封装的通路图

![image.png](https://p1-juejin.byteimg.com/tos-cn-i-k3u1fbpfcp/b5ebac73e7cc4408bf26ca7348ad0999~tplv-k3u1fbpfcp-watermark.image?)

```js
/**
 * 名称：通路柱状图
 * @param {*} id 当前选中容器
 * @param {*} seriesData 当前数据
 * @param {*} container 当前图表实例组合
 * @param {*} color 自定义的颜色
 * @param {*} onMouseClick 点击事件
 * @param {*} onMouseOver hover事件
 **/

import { iniTaccessInfeeBarChart } from '~'

  // 柱状图的颜色
  let color  = '#c1322b'
  // 通路柱状图x轴信息
  let xData = ['RTA-E', 'RTA-D', 'RTA-C', 'RTA-B', 'RTA-A', 'RTA-RAX'];
  // 对应的结果数组
  let seriesData = [0.1, 0.2, 0.3, 0.4, 0.5, 0.8]

  // 添加点击事件
  const onMouseClick = ()=>{  }
  // 添加hover事件
  const onMouseOver = ()=>{  }

  // 调用实例 渲染通路柱状图
  iniTaccessInfeeBarChart({name: props.name, seriesData,xData,color,id:props.id,chartMap })
```
