---
title: 基本用法
order: 1
---

裁切组件基本用法，平铺模式

```jsx
import React, { useEffect, useState, useRef } from 'react';
import ReactDOM from 'react-dom';
import { ResponsiveGrid, Box, Button, Dialog } from '@alifd/next';
import SuperImage from '@shihuo/image-component';

import ImageFreeCrop from '@shihuo/image-free-crop-component';

const { Cell } = ResponsiveGrid;

const TextIMG = '//static.shihuocdn.cn/reposition/1629763983/8d30b32a4f34f7f46dd0a223f5514fe0.jpg';

const ImageExample = () => {
  const [loading, setLoading] = useState(false);
  const [coordinate, setCoordinate] = useState({ w: 0, h: 0, x: 0, y: 0 });

  const [isCrop, setIsCrop] = useState(false);

  const instance = useRef(null);

  return (
    <ResponsiveGrid gap={20}>
      <Cell colSpan={12}>
        <Box spacing={20}>
          <ImageFreeCrop
            src={TextIMG}
            ref={instance}
            // minSize={[600, 0]}
            // maxSize={[600, 0]}
            onSuccess={({ image }) => {
              setIsCrop(true);
            }}
            onCropChange={(state) => {
              setCoordinate(state);
            }}
          />

          <Box direction="row" spacing={10}>
            <Box className="free-crop-coordinates" direction="row" spacing={5}>
              <span>x：{coordinate.x}</span>
              <span>y：{coordinate.y}</span>
              <span>宽：{coordinate.w}</span>
              <span>高：{coordinate.h}</span>
            </Box>
          </Box>
        </Box>

        {isCrop || (
          <Button
            type="primary"
            style={{ marginTop: 20 }}
            loading={loading}
            onClick={() => {
              instance.current.API.triggerCrop();
            }}
          >
            确认裁剪
          </Button>
        )}

        {isCrop || (
          <Button
            type="primary"
            style={{ marginLeft: 20, marginTop: 20 }}
            loading={loading}
            onClick={() => {
              instance.current.API.triggerReverseCrop();
            }}
          >
            剪切
          </Button>
        )}

        {isCrop && (
          <Button
            type="primary"
            style={{ marginTop: 20 }}
            loading={loading}
            onClick={() => {
              setIsCrop(false);
              instance.current.API.reset();
            }}
          >
            重新裁剪
          </Button>
        )}
      </Cell>
    </ResponsiveGrid>
  );
};

ReactDOM.render(<ImageExample />, mountNode);
```
