---
title: 弹窗模式
order: 2
---

弹窗模式基于普通用法实现了部分裁切交互功能，特殊说明请查阅下方 api 以及使用实例

```jsx
import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import { ResponsiveGrid, Box, Button } from '@alifd/next';
import SuperImage from '@shihuo/image-component';

import ImageFreeCrop from '@shihuo/image-free-crop-component';

const { Cell } = ResponsiveGrid;

const TextIMG =
  'https://proxy.shihuocdn.cn/aHR0cDovL2ltZy5hbGljZG4uY29tL2ltZ2V4dHJhL2kxLzMwOTU1NTYzMzQvTzFDTjAxYmhwN3k0MXdmMVA3VDI2dGpfISEzMDk1NTU2MzM0LmpwZw..';

const LongIMG =
  'http://proxy.shihuocdn.cn/aHR0cHM6Ly9jZG4ucG9pem9uLmNvbS9ub2RlLWNvbW1vbi9ZMkZ3ZEhWeVpURTJNekkyTWpjME1qYzFPRGs9LmpwZWc.';
const LongIMG2 =
  'https://static.shihuocdn.cn/admin/imgs/20220701/9b12967d4885aa735d708a10d35eca88_750x400.jpeg';

const ImageExample = () => {
  const [src, setSrc] = useState(LongIMG);
  return (
    <ResponsiveGrid gap={20}>
      <Cell colSpan={12}></Cell>
      <Cell colSpan={12}>
        <Box direction="row" spacing={20}>
          <SuperImage ruler="shoes" width={200} height={200} src={src} />
        </Box>

        <Button
          type="primary"
          style={{ marginTop: 20 }}
          onClick={() => {
            ImageFreeCrop.Dialog({
              src,
              // minSize: [(600 / 2913) * 1440, 0],
              // maxSize: [(600 / 2913) * 1440, 0],
              minSize: [0, 600],
              maxSize: [0, 600],
              // ratio: 1,
              onUse: (src) => {
                setSrc(src);
              },
            });
          }}
        >
          开始裁剪
        </Button>
      </Cell>
    </ResponsiveGrid>
  );
};

ReactDOM.render(<ImageExample />, mountNode);
```
