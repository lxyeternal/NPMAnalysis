# 下载

`npm i calcs65`

# 使用

`const calc=require("calcs65")`

`calc.add(10,20) => 30 `

`calc.sub(10,20) => -10 `

`calc.mul(10,20) => 200`

`calc.div(10,20) => 0.5 `

