# Music-admin-vue


## musicJson 数据结构定一下
{
    "title": "标题",
    "composer": "作曲家",
    "lyricist": "作词家",
    "time": {
        "beats": 2,
        "beatType": 4
    },
    "measures": [
        {
            "note": [
                "pitch": {
                    "step": "D",
                    "alter": -1,
                    "octave": 4             // 3绘制下面的点    5绘制上面的点
                },
                "lyric": {
                    "text": "绕"
                },
                "text": "7",
                "octave": 0,   
                "tied": 1,              // 1是开始 0是结束
                "underline": "=",
                'dot': 1,
                "dur": 1,              // 1是四分音符1拍  0.5是八分音符  0.25是十六分音符   2是二分音符2拍  4是全拍音符 4拍
                "acc": "#"
            ]
        }
    ]
}
    