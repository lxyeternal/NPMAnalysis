import '@scoped-vaadin/vaadin-material-styles/color.js';
