require('./share.less');
define(function () {
    var ua = window.L.ua;
    // var Five = require('jspath/modules/fivestep/index');
    var Source = require('./source');
    var GlobalConfig = require('./global');

    /*
     * 开启app分享则加载app分享sdk
     * */
    function letvClientShare(param) {
        // document.write("<script src='" + GlobalConfig.appClientShare +"'><\/script>");
        $.getScript(GlobalConfig.appClientShare, function () {
            var letvClient = require('./letvclient');
            letvClient(param);
        });
    }

    /*
     *   插入分享平台
     *
     * */
    function option(param) {
        var arr = param.webpageShare;
        var shareHtml = '<div style="display: none;" class="back_blur" id="mask"></div>' +
            '<div style="display: none;" class="share_dialog">' +
            '<div class="share_list">' +
            '<div id="shareToMyFriendsBtn" class="share_item wx_appmessage dn" data-share="微信"><i></i></div>' +
            '<div id="shareWeiXinFriendsBtn" class="share_item wx_timeline dn" data-share="朋友圈"><i></i></div>' +
            '<div id="shareQzone" class="share_item qzone dn" data-share="QQ空间"><i></i></div>' +
            '<div id="shareQQ" class="share_item qq dn" data-share="QQ好友"><i></i></div>' +
            '<div id="shareWeiBoBtn" class="share_item wb_sina dn" testnum="" data-share="新浪微博"><i></i></div>' +
            '</div>' +
            '<a href="javascript:void(0);" class="cancel_btn guozuBtn">取消</a>' +
            '</div>';
        $('body').append(shareHtml);

        var $shareWeiXinFriendsBtn = $("#shareWeiXinFriendsBtn");           // 分享微信朋友圈
        var $shareToMyFriendsBtn = $("#shareToMyFriendsBtn");               // 分享微信朋友
        var $shareWeiBoBtn = $("#shareWeiBoBtn");                           // 分享微博
        var $qq = $("#shareQQ");                                            //分享qq
        var $qzone = $("#shareQzone");                                      //分享QQ空间
        var $shareDialog = $(".share_dialog");                              //分享的弹层
        var $cancelShare = $('.share_dialog .cancel_btn');                  //取消分享按钮
        var $mask = $('#mask');
        param.shareWeiXinFriendsBtn = $shareWeiBoBtn;

        if (ua.APP) {
            var ptArray = [$("#shareWeiXinFriendsBtn,#shareToMyFriendsBtn"), $shareWeiBoBtn, $qq, $qzone];
        } else {
            var ptArray = [$shareWeiBoBtn, $qq, $qzone];
        }
        //分享
        param.eventEle.on('click', function () {
            _openShare();
            _platformShow();
        });

        // 注册分享关闭,微信、APP、h5公用
        $cancelShare.on('click', function (event) {
            event.preventDefault();
            event.stopPropagation();
            _closeShare();
        });

        // 注册分享关闭,微信、APP、h5公用
        $mask.on('click', function (event) {
            event.preventDefault();
            event.stopPropagation();
            _closeShare();
        });

        //支持哪些平台显示
        _platformShow = function () {
            try {
                if (arr.constructor === Array) {
                    for (var i = 0; i < arr.length; i++) {
                        if (arr[i] == 0) {
                            $shareWeiXinFriendsBtn.removeClass("dn");
                            $shareToMyFriendsBtn.removeClass("dn");
                            $shareWeiBoBtn.removeClass("dn");
                            $qq.removeClass("dn");
                            $qzone.removeClass("dn");
                        } else {
                            ptArray[arr[i] - 1].removeClass('dn');
                        }
                    }
                } else {
                    if (arr == 1) {
                        $shareWeiXinFriendsBtn.removeClass("dn");
                        $shareToMyFriendsBtn.removeClass("dn");
                        $shareWeiBoBtn.removeClass("dn");
                        $qq.removeClass("dn");
                        $qzone.removeClass("dn");
                    } else if (arr == 2) {
                        $shareWeiXinFriendsBtn.removeClass("dn");
                        $shareToMyFriendsBtn.removeClass("dn");
                    } else if (arr == 3) {
                        $shareWeiBoBtn.removeClass("dn");
                    } else if (arr == 4) {
                        $qq.removeClass("dn");
                    } else if (arr == 5) {
                        $qzone.removeClass("dn");
                    } else if (arr == 6) {
                        $shareWeiXinFriendsBtn.removeClass("dn");
                        $shareToMyFriendsBtn.removeClass("dn");
                        $shareWeiBoBtn.removeClass("dn");
                    }
                }
            } catch (e) {
                console.log(e.message);
            }
        };

        //打开分享浮层
        _openShare = function () {
            $shareDialog.show();
            $mask.show();
        };
        _closeShare = function () {
            $shareDialog.hide();
            $mask.hide();
        };
    }


    function init(param) {
        // 在微信中
        if (ua.weixin) {
            document.write("<script src='" + GlobalConfig.jwinxin + "'><\/script>");
            var ShareWx = require("./weixinshare");
            ShareWx(param);
        } else if (ua.APP) {
            var ShareApp = require('./appshare');
            ShareApp(param);
        } else if (ua.letvclient) {
            letvClientShare(param);
        } else if (!ua.APP && !ua.weixin) {
            var ShareH5 = require('./h5share');
            option(param);
            /*
             * 修改渠道号source
             * */
            param.shareUrl = Source.addSource({url: param.shareUrl, source: param.config.sourceWeiBo});
            ShareH5(param);
        }
    }

    function setStyle(styleCfg) {
        var _style = null;
        if(styleCfg.style.constructor == Array){
            //兼容老版本
            _style = {
                'color': styleCfg.style[0],
                'background': styleCfg.style[1]
            }
        }else{
            _style = styleCfg.style;
        }
        styleCfg.eventEle.css(_style);
    }

    return function (param) {
        param.appShareOpt = param.appSharePlarform || 1;
        param.webpageShare = param.webpageShare || 1;
        if (param) {
            console.log('分享组件已加载');
        }
        if (param.style) {
            setStyle(param)
        }
        init(param);
        // var isLogin = param.isLogin || false;
        /*if (isLogin) {
         // 获取用户信息监听
         $(document).on("getUserInfo", function (e, d) {
         Five.init(d);
         Five.check(1);
         param.userInfo = d || {};
         init(param);
         });
         } else {
         init(param);
         }*/
        if (param.callback && typeof param.callback == 'function') {
            $(document).on('allShareHandle', function (ev, arg) {
                param.callback();
            });
        }
    }
});
