define(function () {
    // var Request = require("jspath/interface/request");
    // var tip = require("tip-le");
    var Global = require('./global');

    return function (param) {
        try {
            Global.sina.shareurl = param.shareUrl;
            param.shareWeiXinFriendsBtn.on('click', function () {
                $.ajax({
                    url: Global.api.weiboAuthUrl,
                    data: {
                        url: Global.sina.shareurl
                    },
                    type: 'GET',
                    success:function(res){
                        if (res.result == 0 || res.data == null) {
                            console.log(res.message);
                            return false;
                        } else {
                            Global.sina.weiboAuthUrl = res.data.result;
                            window.location.href = Global.sina.weiboAuthUrl;
                        }
                    }
                });
            });
            // 获取用户信息监听
            $(document).on("getUserInfo", function (e, d) {
                Global.userInfo = d || {};
                // 登入时
                Global.sina.WBshare = Global.util.getSessionStorage("WBshare");
                if (Global.sina.WBshare == "1") {
                    Global.util.removeSessionStorage("WBshare");
                    $(document).trigger('allShareHandle');
                } else if (Global.sina.WBshare == "0") {
                    console.log("分享失败！");
                    Global.util.removeSessionStorage("WBshare");
                }
            });
        } catch (e) {
            console.log(e.message);
        }
    }
});
