/**
 * Created by zhangsanfang on 2016/9/26.
 */
define(function () {
    var util = window.L.util;
    // var Request = require("jspath/interface/request");
    // var tip = require("tip-le");
    var Source = require('./source');
    var Global = require('./global');

    var weixinFn = {
        initWeiXin: function () {
            $.ajax({
                url: Global.api.weixin,
                data: {
                    token: Global.userInfo.token || "",
                    url: window.location.href
                },
                type: 'GET',
                success:function(res){
                    if (res.result == 0 || res.data == null) {
                        console.log(res.message);
                        return false;
                    } else {
                        var data = res.data;
                        wx.config({
                            debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                            appId: Global.wxAppId, // 必填，公众号的唯一标识
                            timestamp: data.timestamp, // 必填，生成签名的时间戳
                            nonceStr: data.nonceStr, // 必填，生成签名的随机串
                            signature: data.signature,// 必填，签名，见附录1
                            jsApiList: ['onMenuShareTimeline', 'onMenuShareAppMessage', 'onMenuShareQQ', 'onMenuShareWeibo', 'onMenuShareQZone'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
                        });
                        wx.ready(function () {
                            // 分享到朋友圈
                            wx.onMenuShareTimeline({
                                title: Global.wxTitle,
                                desc: Global.wxDesc,
                                link: Global.wxshareurl,
                                imgUrl: Global.wximgurl,
                                success: function () {
                                    weixinFn.shareCallback(1);
                                },
                                cancel: function () {
                                    //alertlayer({w: "分享失败！"});
                                }
                            });
                            // 分享给微信朋友
                            wx.onMenuShareAppMessage({
                                title: Global.wxTitle,
                                desc: Global.wxDesc,
                                link: Global.friendsUrl,
                                imgUrl: Global.wximgurl,
                                success: function () {
                                    weixinFn.shareCallback(2);
                                },
                                cancel: function () {
                                    //alertlayer({w: "分享失败！"});
                                }
                            });
                        });
                    }
                }
            });
        },
        // 分享后的回调
        shareCallback: function (type) {
            Global.$shareGuide.hide();
            Global.$backBlur.hide();
            $(document).trigger('allShareHandle', 'wx');
        },
        //分享操作
        shareOpt: function () {
            weixinFn.guideLayer();
        },
        //分享引导层
        guideLayer: function () {
            Global.$shareGuide.show();
            Global.$backBlur.show().css({
                "width": "100%",
                "height": "100%"
            });
        }
    };

    function init(param) {
        Global.wxTitle = param.config.wxTitle;
        Global.wxDesc = param.config.wxDesc;
        Global.wximgurl = param.config.wximgurl;
        Global.userInfo = param.userInfo || {};
        Global.wxshareurl = param.shareUrl || location.href;  //微信朋友圈
        Global.friendsUrl = param.shareUrl || location.href;//微信朋友

        var MaskHtml = '<div style="display: none; width: 100%; height: 100%;" class="back_blur"></div>';
        var guideHtml = '<div id="shareGuide" style="display: none" data-title="" data-img="" data-desc="" class="share_guide"><img src="/h5active/images/guozu/shareguide.png"></div>';
        $('body').append(MaskHtml + guideHtml);
        //获取dom
        Global.$shareGuide = $('#shareGuide');
        Global.$backBlur = $('.back_blur');
        Global.$share = param.eventEle;

        Global.wxshareurl = Source.addSource({url: Global.wxshareurl, source: param.config.sourceWxGroup});//朋友圈
        Global.friendsUrl = Source.addSource({url: Global.friendsUrl, source: param.config.sourceWxFriend});//微信朋友

        Global.$backBlur.on('click', function () {
            Global.$shareGuide.hide();
            Global.$backBlur.hide();
        });
        Global.$shareGuide.on('click', function () {
            Global.$shareGuide.hide();
            Global.$backBlur.hide();
        });
        //分享
        Global.$share.on('click', function () {
            weixinFn.shareOpt();
        });
        weixinFn.initWeiXin();
    }

    return init;
});
