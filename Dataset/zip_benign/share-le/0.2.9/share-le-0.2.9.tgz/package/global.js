/**
 * Created by boyuan on 2017/1/3.
 */
define(function () {
    var doMain = "";
    return {
        util: window.L.util,
        ua: window.L.ua,
        appClientShare: 'https://sdk-m.le.com/share/share.js',  //乐视视频分享sdk地址
        jwinxin:'https://res.wx.qq.com/open/js/jweixin-1.0.0.js',//微信分享sdk地址
        api: {
            weixin: doMain + '/api/activity/bibi/wxShare',
            //获取新浪微博授权地址
            weiboAuthUrl: doMain + '/api/activity/weiboAuthUrl'
        },
        wxAppId: 'wx3f99823ce8c90111',    //微信公众号的appid
        userInfo: null,                        // 用户信息,当用户登入时会赋值用户信息

        $share: null,
        $shareGuide: null,
        $backBlur: null,
        $shareDialog: null,

        wxshareurl: null,//朋友圈
        friendsUrl: null,//微信朋友
        wxTitle: null,  //微信分享标题
        wxDesc: null,   //微信分享描述
        wximgurl: null, //微信分享小图标

        sina: {
            weiboAuthUrl: "",//获取新浪微博授权地址
            shareurl: location.href,
            WBshare: "" //查看是否通过微博分享成功链接进来的
        }
    }
});
