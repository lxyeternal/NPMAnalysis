/**
 * Created by zhangsanfang on 2016/9/26.
 */
define(function () {
    var userAgent = navigator.userAgent.toLowerCase();
    return function (param) {
        var setSource =function () {
            return window.location.href.split('?')[0].replace('.html', '.html?source=' + window.L.util.getUrlParam('source'));
        };
        if ((userAgent.indexOf('letvmobileclient') > -1 || userAgent.indexOf('letvclient') > -1) && (typeof LemSdk != 'undefined')) {
            LemSdk.config({
                key: 'bb41UMKXG1rDhsOhC2h/woU0w6hbbQnCl8O6w4x2w6vDr8KOwpnDiMOBwqI8Hg==',//key需要申请
                debug: false
            });
            if (userAgent.indexOf('chrome') > -1 || userAgent.indexOf('iphone') > -1) {
                // ios版
                // alert('基线版1' + shareUrl);
                var p = {
                    type: 'webpage', //只有调用app分享时需要此参数，支持webpage、image、text。默认值：webpage
                    title: param.config.wxTitle, //自定义分享标题
                    desc: param.config.wxDesc, //自定义分享内容
                    link: setSource(), //自定义分享链接
                    imgUrl: param.config.wximgurl, //自定义分享图标
                    summary: ''
                };
                var p2 = {
                    type: 'webpage', //只有调用app分享时需要此参数，支持webpage、image、text。默认值：webpage
                    title: param.config.wxTitle, //自定义分享标题
                    desc: param.config.wxDesc, //自定义分享内容
                    link: setSource(), //自定义分享链接
                    imgUrl: param.config.wximgurl, //自定义分享图标
                    summary: ''
                };
            } else {
                var p = {
                    type: 'webpage', //只有调用app分享时需要此参数，支持webpage、image、text。默认值：webpage
                    title: param.config.wxTitle, //自定义分享标题
                    desc: param.config.wxDesc, //自定义分享内容
                    link: setSource(), //自定义分享链接
                    imgUrl: setSource(), //自定义分享图标
                    summary: ''
                };
                var p2 = {
                    type: 'webpage', //只有调用app分享时需要此参数，支持webpage、image、text。默认值：webpage
                    title: param.config.wxTitle, //自定义分享标题
                    desc: param.config.wxDesc, //自定义分享内容
                    link: setSource(), //自定义分享链接
                    imgUrl: setSource(), //自定义分享图标
                    summary: ''
                };
            }

            LemSdk.onReady = function () {
                LemSdk.share.setAppShare(p); //设置APP分享内容
            };
            param.eventEle.on('click', function () {
                LemSdk.share.callAppShare(p2);//调起APP分享内容
            });
        }
    }
});
