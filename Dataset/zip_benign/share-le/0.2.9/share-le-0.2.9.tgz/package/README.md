# 分享组件

## 安装

```$xslt
npm install share-le
```
## 使用

```$xslt
var Share = require('share-le');

Share({
    config: require('./config'),    //配置文件地址
    eventEle:$('#shareBtn'),        //监听显示分享浮层事件的按钮
    shareUrl:shareUrl,              //分享地址
    webpageShare:[1],             //h5分享所需的社交平台   0,所有平台 1，微博
    appSharePlarform:[0],         //app分享所需的社交平台  0,所有平台 1,微信平台 2，微博 3，qq 4,qq空间
    callback:function(){            //分享成功后回调
        alert(分享成功);
    }
});
```

##config.js配置说明
```angular2html
define(function(){
    return {
        "wxTitle":'生态会员嗨翻天，天天乐享0.5%加息！ 【乐视金融】',     //微信分享显示标题
        "wxDesc":"别忘了分享哦~",     //微信分享显示描述
        "wximgurl":"https://jr.letv.com/a1/M00/08/43/Cm5d0VhGmLqADjudAAA2iHZMziw842.jpg",   //微信分享显示的小图标
        "sourceWxFriend":"111", //微信分享给朋友的source
        "sourceWxGroup" :"222", //微信分享到朋友圈的source
        "sourceQQ":"333",       //分享给qq的source
        "sourceQzone":"444",    //分享qq空间的source
        "sourceWeiBo":"555",    //分享到微博的source
        //#component-config#
    }
});
```
