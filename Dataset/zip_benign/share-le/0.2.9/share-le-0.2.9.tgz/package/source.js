/**
 * Created by boyuan on 2016/11/9.
 */
define(function(){
    var util = window.L.util;

    function Source() {
        this.urlSource = util.getUrlParam('source');
    }

    Source.prototype = {
        setSource : function(){
            return window.location.href.split('?')[0].replace('.html','.html?source=' + this.urlSource);
        },
        addSource:function(param){
            var url = param.url || location.href;
            if (url.indexOf("source") == -1) {
                if (url.indexOf("?") == -1) {
                    url = url + "?source=" + param.source;
                } else {
                    url = url + "&source=" + param.source;
                }
            } else {
                url = url.replace(/([?|&]+)source=[\w-]+/, "$1source=" + param.source);
            }
            return url;
        }
    };

    return new Source();
});
