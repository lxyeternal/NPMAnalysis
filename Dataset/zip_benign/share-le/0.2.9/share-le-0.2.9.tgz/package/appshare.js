/**
 * Created by zhangsanfang on 2016/9/26.
 */
define(function () {
    var util = window.L.util;
    var ua = window.L.ua;
    // var config = require('jspath/common/config');
    // var remote = require("jspath/interface/remote");
    // var alertlayer = require("../../modules/bbq_layer/index");
    // var tip = require("tip-le");
    var Source = require('./source');

    var $ = window.$;

    var $shareWeiXinFriendsBtn = null;           // 分享微信朋友圈
    var $shareToMyFriendsBtn = null;               // 分享微信朋友
    var $shareWeiBoBtn = null;                           // 分享微博
    var $qq = null;                                            //分享qq
    var $qzone = null;                                      //分享QQ空间
    var $shareDialog = null;//分享的弹层
    var $backBlur = null;//背景
    var $share = null;
    var $cancelShare = null;//取消分享按钮
    var $mask = null;

    var fxUrl = window.location.href;
    var fxTitle = null;
    var fxDesc = null;
    var fximgurl = null;
    var shareurl = null;
    var appJson = "";

    //分享操作
    function shareOpt(n) {
        $shareDialog.show();
        $mask.show();
        var ptArray = [$shareToMyFriendsBtn, $shareWeiXinFriendsBtn, $shareWeiBoBtn, $qq, $qzone];
        try {
            if (n.constructor === Array) {
                for (var i = 0; i < n.length; i++) {
                    if (n[i] == 0) {
                        $shareWeiXinFriendsBtn.removeClass("dn");
                        $shareToMyFriendsBtn.removeClass("dn");
                        $shareWeiBoBtn.removeClass("dn");
                        $qq.removeClass("dn");
                        $qzone.removeClass("dn");
                    } else if (n[i] == 1) {
                        $shareWeiXinFriendsBtn.removeClass("dn");
                        $shareToMyFriendsBtn.removeClass("dn");
                    } else {
                        ptArray[n[i]].removeClass("dn");
                    }
                }
            } else {
                if (n == 1) {
                    $shareWeiXinFriendsBtn.removeClass("dn");
                    $shareToMyFriendsBtn.removeClass("dn");
                    $shareWeiBoBtn.removeClass("dn");
                    $qq.removeClass("dn");
                    $qzone.removeClass("dn");
                } else if (n == 2) {
                    $shareWeiXinFriendsBtn.removeClass("dn");
                    $shareToMyFriendsBtn.removeClass("dn");
                } else if (n == 3) {
                    $shareWeiBoBtn.removeClass("dn");
                } else if (n == 4) {
                    $qq.removeClass("dn");
                } else if (n == 5) {
                    $qzone.removeClass("dn");
                } else if (n == 6) {
                    $shareWeiXinFriendsBtn.removeClass("dn");
                    $shareToMyFriendsBtn.removeClass("dn");
                    $shareWeiBoBtn.removeClass("dn");
                }
            }
        } catch (e) {
            console.log(e.message);
        }

        $backBlur.show().css({
            "width": "100%",
            "height": "100%"
        });
    }

    // 分享到朋友圈
    function onShareWeiXinFriendsBtnTap(appJson) {
        //alert("WechatTimeline");
        //alert(window.native);
        window.native.SNSShare("WechatTimeline", appJson, "'p'");
    }

    // 分享给微信朋友
    function onShareToMyFriendsBtnTap(appJson) {
        // alert(window.native);
        // alert("WechatSession");
        window.native.SNSShare("WechatSession", appJson, "'f'");
    }

    // 分享微博
    function onShareWeiBoBtnTap(appJson) {
        // alert("SinaWeibo");
        //alert(window.native);
        window.native.SNSShare("SinaWeibo", appJson, "'b'");
    }

    // 分享qq
    function onShareQQTap(appJson) {
        // alert("SinaWeibo");
        //alert(window.native);
        window.native.SNSShare("TencentQQ", appJson, "'q'");
    }

    // 分享qq空间
    function onShareQzoneTap(appJson) {
        // alert("SinaWeibo");
        //alert(window.native);
        window.native.SNSShare("TencentQZone", appJson, "'z'");
    }

    // 关闭分享
    function closeShare() {
        $shareDialog.hide();
        $mask.hide();
        $backBlur.hide();
    }

    // 微信分享回调
    function SNSShareResult(isSuccess, sign) {
        $shareDialog.hide();
        $mask.hide();
        $backBlur.css({
            height: 0,
            width: 0
        }).hide();
        if (isSuccess) {
            $(document).trigger('allShareHandle', ['app']);
        } else {
            //alertlayer({w:"分享失败！"});
        }
    }

    return function (param) {
        var _this = this;
        fxTitle = param.config.wxTitle;
        fxDesc = param.config.wxDesc;
        fximgurl = param.config.wximgurl;
        shareurl = param.config.shareUrl || window.location.href;
        appShareOpt = param.appShareOpt;
        $share = param.eventEle;

        // 在金融app中
        var shareHtml = '<div style="display: none;" class="back_blur" id="mask"></div>' +
            '<div style="display: none;" class="share_dialog">' +
            '<div class="share_list">' +
            '<div id="shareToMyFriendsBtn" class="share_item wx_appmessage dn" data-share="微信"><i></i></div>' +
            '<div id="shareWeiXinFriendsBtn" class="share_item wx_timeline dn" data-share="朋友圈"><i></i></div>' +
            '<div id="shareQzone" class="share_item qzone dn" data-share="QQ空间"><i></i></div>' +
            '<div id="shareQQ" class="share_item qq dn" data-share="QQ好友"><i></i></div>' +
            '<div id="shareWeiBoBtn" class="share_item wb_sina dn" testnum="123123123" data-share="新浪微博"><i></i></div>' +
            '</div><a href="javascript:void(0);" class="cancel_btn guozuBtn">取消</a>' +
            '</div>';
        $('body').append(shareHtml);

        $shareWeiXinFriendsBtn = $("#shareWeiXinFriendsBtn");           // 分享微信朋友圈
        $shareToMyFriendsBtn = $("#shareToMyFriendsBtn");               // 分享微信朋友
        $shareWeiBoBtn = $("#shareWeiBoBtn");                           // 分享微博
        $qq = $("#shareQQ");                                            //分享qq
        $qzone = $("#shareQzone");                                      //分享QQ空间
        $shareDialog = $(".share_dialog");//分享的弹层
        $backBlur = $('.back_blur');//背景
        $cancelShare = $('.share_dialog .cancel_btn');//取消分享按钮
        $mask = $('#mask');

        //分享
        $share.on('click', function () {
            shareOpt(appShareOpt);
        });
        //微信朋友圈
        $shareWeiXinFriendsBtn.on("click", function () {
            fxUrl = Source.addSource({url:shareurl, source:param.config.sourceWxGroup});//朋友圈
            appJson = JSON.stringify({title: fxTitle, img: fximgurl, src: fxUrl, discribe: fxDesc});
            onShareWeiXinFriendsBtnTap(appJson);
        });
        //微信朋友
        $shareToMyFriendsBtn.on("click", function () {
            fxUrl = Source.addSource({url:shareurl, source:param.config.sourceWxFriend});
            appJson = JSON.stringify({title: fxTitle, img: fximgurl, src: fxUrl, discribe: fxDesc});
            onShareToMyFriendsBtnTap(appJson);
        });
        //微博
        $shareWeiBoBtn.on("click", function () {
            fxUrl = Source.addSource({url:shareurl, source:param.config.sourceWeiBo});
            appJson = JSON.stringify({title: fxTitle, img: fximgurl, src: fxUrl, discribe: fxDesc});
            onShareWeiBoBtnTap(appJson);
        });
        //qq
        $qq.on("click", function () {
            fxUrl = Source.addSource({url:shareurl, source:param.config.sourceQQ});
            appJson = JSON.stringify({title: fxTitle, img: fximgurl, src: fxUrl, discribe: fxDesc});
            onShareQQTap(appJson);
        });
        //qq空间
        $qzone.on("click", function () {
            fxUrl = Source.addSource({url:shareurl, source:param.config.sourceQzone});
            appJson = JSON.stringify({title: fxTitle, img: fximgurl, src: fxUrl, discribe: fxDesc});
            onShareQzoneTap(appJson);
        });
        // 注册分享关闭,微信、APP、h5公用
        $cancelShare.on('click', function (event) {
            event.preventDefault();
            event.stopPropagation();
            closeShare();
        });
        window.SNSShareResult = SNSShareResult;
    }
});
