import * as mm from "./metho-math.js";

  describe("metho-math library", () => {
    it("test availability of all metho-math (wrapper) functions", () => {
      expect((-3)[mm.abs]).toBe(3);
      expect((-1)[mm.acos]).toBe(3.141592653589793);
      expect((2)[mm.acosh]).toBe(1.3169578969248166);
      expect((1)[mm.asin]).toBe(1.5707963267948966);
      expect((1)[mm.asinh]).toBe(0.881373587019543);
      expect((1)[mm.atan]).toBe(0.7853981633974483);
      expect((15)[mm.atan2(90)]).toBe(0.16514867741462683);
      expect((0.5)[mm.atanh]).toBe(0.5493061443340548);
      expect((64)[mm.cbrt]).toBe(4);
      expect((7.004)[mm.ceil]).toBe(8);
      expect((2)[mm.clz32]).toBe(30);
      expect(Math.PI[mm.cos]).toBe(-1);
      expect((1)[mm.cosh]).toBe(1.5430806348152437);
      expect((1)[mm.exp]).toBe(2.718281828459045);
      expect((1)[mm.expm1]).toBe(1.718281828459045);
      expect((45.05)[mm.floor]).toBe(45);
      expect((3)[mm.hypot(4)]).toBe(5);
      expect((3)[mm.imul(5)]).toBe(15);
      expect((5.05)[mm.fround]).toBe(5.050000190734863);
      expect((10)[mm.log]).toBe(2.302585092994046);
      expect((1e6)[mm.log10]).toBe(6);
      expect((1)[mm.log1p]).toBe(0.6931471805599453);
      expect((3)[mm.log2]).toBe(1.584962500721156);
      expect([1, 5, 3][mm.max()]).toBe(5);
      expect([1, 5, 3][mm.max(8, 2)]).toBe(8);
      expect((9)[mm.max()]).toBe(9);
      expect((9)[mm.max(11, 12)]).toBe(12);
      expect([1, 5, 3][mm.min()]).toBe(1);
      expect([1, 5, 3][mm.min(0)]).toBe(0);
      expect((5)[mm.min()]).toBe(5);
      expect((5)[mm.min(3)]).toBe(3);
      expect((2)[mm.pow(3)]).toBe(8);
      expect((1000)[mm.random]).toBeGreaterThanOrEqual(0);
      expect((1000)[mm.random]).toBeLessThan(1000);
      expect((20.45)[mm.round]).toBe(20);
      expect((3)[mm.sign]).toBe(1);
      expect((Math.PI / 2)[mm.sin]).toBe(1);
      expect((1)[mm.sinh]).toBe(1.1752011936438014);
      expect((9)[mm.sqrt]).toBe(3);
      expect((1)[mm.tan]).toBe(1.5574077246549023);
      expect((1)[mm.tanh]).toBe(0.7615941559557649);
      expect((13.37)[mm.trunc]).toBe(13);
    });
  });
  