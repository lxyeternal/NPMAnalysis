var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

import JSZip from 'jszip';
import { Geometry } from 'three/src/core/Geometry';

export var mimeType = 'text/plain';

function geometryToData(geometry, material) {
  var faces = geometry.faces,
      vertices = geometry.vertices,
      _geometry$faceVertexU = _slicedToArray(geometry.faceVertexUvs, 1),
      faceVertexUvs = _geometry$faceVertexU[0];

  var output = '';

  if (material) {
    output += 'mtllib material.mtl\n';
  }

  for (var i = 0; i < vertices.length; i++) {
    var vertex = vertices[i];

    output += 'v ' + vertex.x + ' ' + vertex.y + ' ' + vertex.z + '\n';
  }

  for (var _i = 0; _i < faceVertexUvs.length; _i++) {
    var face = faceVertexUvs[_i];
    for (var _i2 = 0; _i2 < face.length; _i2++) {
      var uv = face[_i2];

      output += 'vt ' + uv.x + ' ' + uv.y + '\n';
    }
  }

  for (var _i3 = 0; _i3 < faces.length; _i3++) {
    var _face = faces[_i3];

    for (var _i4 = 0; _i4 < _face.vertexNormals.length; _i4++) {
      var normal = _face.vertexNormals[_i4];

      output += 'vn ' + normal.x + ' ' + normal.y + ' ' + normal.z + '\n';
    }
  }

  var currentMaterial = null;

  var _loop = function _loop(_i5) {
    var face = faces[_i5];

    if (material && face.materialIndex !== currentMaterial) {
      var mtl = material instanceof Array ? material[face.materialIndex] : material;

      output += 'usemtl ' + (mtl.name !== '' ? mtl.name : 'material ' + mtl.id) + '\n';

      currentMaterial = face.materialIndex;
    }

    var faceIndexes = [face.a + 1, face.b + 1, face.c + 1].map(function (faceIndex, j) {
      return faceIndex + '/' + (faceVertexUvs.length > 0 ? j : '') + '/' + (_i5 * 3 + j + 1);
    }).join(' ');

    output += 'f ' + faceIndexes + '\n';
  };

  for (var _i5 = 0; _i5 < faces.length; _i5++) {
    _loop(_i5);
  }

  return output;
}

function materialToData(material) {
  var output = '';

  if (material instanceof Array) {
    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
      for (var _iterator = material[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
        var mtl = _step.value;

        output += materialToData(mtl);
      }
    } catch (err) {
      _didIteratorError = true;
      _iteratorError = err;
    } finally {
      try {
        if (!_iteratorNormalCompletion && _iterator.return) {
          _iterator.return();
        }
      } finally {
        if (_didIteratorError) {
          throw _iteratorError;
        }
      }
    }
  } else {
    output += 'newmtl ' + (material.name !== '' ? material.name : 'material ' + material.id) + '\n';

    output += 'Ns 10.0000\n';
    output += 'Ni 1.5000\n';
    output += 'd 1.0000\n';
    output += 'Tr 0.0000\n';
    output += 'Tf 1.0000 1.0000 1.0000\n';
    output += 'illum 2\n';
    output += 'Ka ' + material.color.r + ' ' + material.color.g + ' ' + material.color.b + '\n';
    output += 'Kd ' + material.color.r + ' ' + material.color.g + ' ' + material.color.b + '\n';
    output += 'Ks 0.0000 0.0000 0.0000\n';
    output += 'Ke 0.0000 0.0000 0.0000\n';
  }

  return output;
}

export function fromGeometry(geometry, matrix, material) {
  if (geometry.isBufferGeometry) {
    geometry = new Geometry().fromBufferGeometry(geometry);
  } else if (geometry.isGeometry) {
    geometry = geometry.clone();
  } else {
    throw new Error('Geometry is not an instance of BufferGeometry or Geometry');
  }

  if (matrix && matrix.isMatrix4) {
    geometry.applyMatrix(matrix);
  }

  var zip = new JSZip();

  var geometryData = geometryToData(geometry, material);
  zip.file('object.obj', geometryData);

  if (material) {
    var materialData = materialToData(material);
    zip.file('material.mtl', materialData);
  }

  return zip.generateAsync({ type: 'blob' });;
}

export function fromMesh(mesh) {
  mesh.updateMatrix();

  return fromGeometry(mesh.geometry, mesh.matrix, mesh.material);
}
//# sourceMappingURL=index.js.map