import { ObservableQuery, ApolloClient, NormalizedCacheObject } from '@apollo/client';
export declare class QueryWatcher<Q> {
    private _watchedQuery;
    private _watchedQuerySubscription;
    private readonly _deferredPromiseQueue;
    private _active;
    private _name;
    private _makeObservableQuery;
    private _handleDataChange;
    private _onAfterInitialized?;
    private _onAfterStart?;
    private _onAfterStop?;
    private _uuid;
    get active(): boolean;
    constructor({ name, makeObservableQuery, onAfterInitialized, onAfterStart: onStart, onDataChange, onAfterStop: onStop, }: {
        name: string;
        makeObservableQuery: (apolloClient: ApolloClient<NormalizedCacheObject>) => Promise<ObservableQuery<Q>>;
        onAfterInitialized?: (apolloClient: ApolloClient<NormalizedCacheObject>) => void;
        onAfterStart?: (apolloClient: ApolloClient<NormalizedCacheObject>) => void;
        onDataChange: (queryResult: Q | null | undefined) => void;
        onAfterStop?: (apolloClient: ApolloClient<NormalizedCacheObject>) => void;
    });
    initialize(apolloClient: ApolloClient<NormalizedCacheObject>): Promise<void>;
    /**
     *
     *
     * @param {ApolloClient<NormalizedCacheObject>} apolloClient
     * @param {boolean} [force=false]  the force parameter will override any existing watch, and trigger a refetch of data even if data already available
     * @returns
     * @memberof QueryWatcher
     */
    start(apolloClient: ApolloClient<NormalizedCacheObject>, force: boolean): void;
    runOnce(apolloClient: ApolloClient<NormalizedCacheObject>): void;
    stop(apolloClient: ApolloClient<NormalizedCacheObject>): void;
    private initiateWatch;
    getNextResultAsync(): Promise<Q | null | undefined>;
    private onDataChange;
}
