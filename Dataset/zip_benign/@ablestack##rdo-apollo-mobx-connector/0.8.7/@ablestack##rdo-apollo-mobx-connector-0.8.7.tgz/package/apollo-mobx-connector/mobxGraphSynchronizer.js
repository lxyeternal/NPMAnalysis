"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MobxGraphSynchronizer = void 0;
const logger_1 = require("@ablestack/rdo/infrastructure/logger");
const rdo_1 = require("@ablestack/rdo");
const mobx_1 = require("mobx");
const logger = logger_1.Logger.make('MobxGraphSynchronizer');
class MobxGraphSynchronizer extends rdo_1.GraphSynchronizer {
    // ------------------------------------------------------------------------------------------------------------------
    // CONSTRUCTOR
    // ------------------------------------------------------------------------------------------------------------------
    constructor(options) {
        var _a;
        // Set '$' as commonRdoFieldnamePostfix unless alternative supplied
        const opt = ((_a = options === null || options === void 0 ? void 0 : options.globalNodeOptions) === null || _a === void 0 ? void 0 : _a.commonRdoFieldnamePostfix) ? options : { ...options, globalNodeOptions: { commonRdoFieldnamePostfix: '$' } };
        super(opt);
    }
    smartSync({ rootSourceNode, rootRdo }) {
        logger.trace('smartSync - entering action', { rootSourceNode, rootSyncableObject: rootRdo });
        mobx_1.runInAction(() => {
            logger.trace('smartSync - entering runInAction', { rootSourceNode, rootSyncableObject: rootRdo });
            super.smartSync({ rootSourceNode, rootRdo });
        });
        logger.trace('smartSync - action completed', { rootSourceNode, rootSyncableObject: rootRdo });
    }
}
exports.MobxGraphSynchronizer = MobxGraphSynchronizer;
//# sourceMappingURL=mobxGraphSynchronizer.js.map