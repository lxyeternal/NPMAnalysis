(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/router'), require('rxjs'), require('@angular/common'), require('@angular/material/expansion'), require('@angular/material/icon')) :
    typeof define === 'function' && define.amd ? define('@hugozalm/sidenav', ['exports', '@angular/core', '@angular/router', 'rxjs', '@angular/common', '@angular/material/expansion', '@angular/material/icon'], factory) :
    (global = global || self, factory((global.hugozalm = global.hugozalm || {}, global.hugozalm.sidenav = {}), global.ng.core, global.ng.router, global.rxjs, global.ng.common, global.ng.material.expansion, global.ng.material.icon));
}(this, (function (exports, i0, i1, rxjs, common, expansion, icon) { 'use strict';

    var NavigationService = /** @class */ (function () {
        function NavigationService(router) {
            this.router = router;
            this.showNav$ = new rxjs.BehaviorSubject(false);
        }
        NavigationService.prototype.ngOnInit = function () { };
        NavigationService.prototype.setAutoClose = function (autoClose) {
            var _this = this;
            if (autoClose) {
                // here any navigation events (i.e. clicking on the nav items to go to a separate page)
                // will be captured inside this subscription, then we hide the nav by setting
                // the showNav$ to false or in our case, calling the setShowNav to false, which does the same
                this.router.events.subscribe(function () {
                    _this.setShowNav(false);
                });
            }
        };
        NavigationService.prototype.getShowNav = function () {
            return this.showNav$.asObservable();
        };
        NavigationService.prototype.setShowNav = function (showHide) {
            this.showNav$.next(showHide);
        };
        NavigationService.prototype.toggleNavState = function () {
            this.showNav$.next(!this.showNav$.value);
        };
        NavigationService.prototype.isNavOpen = function () {
            return this.showNav$.value;
        };
        return NavigationService;
    }());
    NavigationService.ɵprov = i0.ɵɵdefineInjectable({ factory: function NavigationService_Factory() { return new NavigationService(i0.ɵɵinject(i1.Router)); }, token: NavigationService, providedIn: "root" });
    NavigationService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    NavigationService.ctorParameters = function () { return [
        { type: i1.Router }
    ]; };

    var SideNavDirection;
    (function (SideNavDirection) {
        SideNavDirection["Left"] = "left";
        SideNavDirection["Right"] = "right";
    })(SideNavDirection || (SideNavDirection = {}));

    var SidenavComponent = /** @class */ (function () {
        function SidenavComponent(navService) {
            this.navService = navService;
            this.duration = 0.25;
            this.navWidth = window.innerWidth;
            this.direction = SideNavDirection.Left;
            this.autoClose = false;
        }
        SidenavComponent.prototype.ngOnInit = function () {
            this.navService.setAutoClose(this.autoClose);
            this.showSideNav = this.navService.getShowNav();
        };
        SidenavComponent.prototype.onSidebarClose = function () {
            this.navService.setShowNav(false);
        };
        SidenavComponent.prototype.getSideNavBarStyle = function (showNav) {
            var navBarStyle = {};
            navBarStyle.transition = this.direction + ' ' + this.duration + 's, visibility ' + this.duration + 's';
            navBarStyle.width = this.navWidth + 'px';
            navBarStyle[this.direction] = (showNav ? 0 : (this.navWidth * -1)) + 'px';
            return navBarStyle;
        };
        return SidenavComponent;
    }());
    SidenavComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'hz-sidenav',
                    template: "<!-- side bar main wrapper -->\n<div class=\"side-nav-bar\"\n    [ngClass]=\"{ 'side-nav-bar-collapsed': !(showSideNav | async) }\">\n    \n    <!-- overlay -->\n    <div class=\"side-nav-bar-overlay\" \n    [ngStyle]=\"{ 'transition': 'background-color ' + duration + 's, visibility ' + duration + 's' }\"\n    [ngClass]=\"{ 'side-nav-bar-overlay-collapsed': !(showSideNav | async) }\"\n        (click)=\"onSidebarClose()\"></div>\n    \n    <!-- side bar-->\n    <div class=\"side-nav-bar-menu-container\" \n    [ngStyle]=\"getSideNavBarStyle((showSideNav | async))\">\n        \n        <!-- close button -->\n        <div><span class=\"material-icons side-nav-bar-close\" (click)=\"onSidebarClose()\">clear</span></div>\n\n        <!-- side bar content -->\n        <div class=\"side-nav-bar-content-container\">\n            <ng-container *ngTemplateOutlet=\"sidenavTemplateRef\"></ng-container>\n        </div>\n    </div>\n</div>\n",
                    encapsulation: i0.ViewEncapsulation.None,
                    styles: [".side-nav-bar{bottom:0;left:0;position:fixed;right:0;top:0;z-index:1001}.side-nav-bar .side-nav-bar-overlay{background:rgba(0,0,0,.5);height:100%;width:100%}.side-nav-bar .side-nav-bar-menu-container{background:#fff;bottom:0;display:flex;flex-direction:column;position:absolute;top:0}.side-nav-bar .side-nav-bar-menu-container .side-nav-bar-close{cursor:pointer;display:inline-block;font-size:2.5em;margin:24px 0 0 24px}.side-nav-bar .side-nav-bar-content-container{padding:32px}.side-nav-bar-overlay-collapsed{background:transparent!important}.side-nav-bar-collapsed{visibility:collapse!important}"]
                },] }
    ];
    SidenavComponent.ctorParameters = function () { return [
        { type: NavigationService }
    ]; };
    SidenavComponent.propDecorators = {
        sidenavTemplateRef: [{ type: i0.Input }],
        duration: [{ type: i0.Input }],
        navWidth: [{ type: i0.Input }],
        direction: [{ type: i0.Input }],
        autoClose: [{ type: i0.Input }]
    };

    var HeaderComponent = /** @class */ (function () {
        function HeaderComponent(navService) {
            this.navService = navService;
        }
        HeaderComponent.prototype.ngOnInit = function () {
        };
        HeaderComponent.prototype.toggleSideNav = function () {
            this.navService.setShowNav(true);
        };
        return HeaderComponent;
    }());
    HeaderComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'hz-sidenav-app-header',
                    template: "<header>\n    <div class=\"header-menu\">\n        <!-- <span (click)=\"toggleSideNav()\" class=\"menu-icon material-icons\">menu</span> -->\n        <span (click)=\"toggleSideNav()\" class=\"menu-icon\">\n            <mat-icon aria-hidden=\"false\" aria-label=\"open menu\">menu</mat-icon>\n        </span>\n    </div>\n</header>",
                    encapsulation: i0.ViewEncapsulation.None,
                    styles: [".header-menu{background-color:#add8e6;border-radius:25px;margin:5px;position:absolute;z-index:1000}.menu-icon{cursor:pointer;font-size:2em;padding:18px}"]
                },] }
    ];
    HeaderComponent.ctorParameters = function () { return [
        { type: NavigationService }
    ]; };

    var AccordionComponent = /** @class */ (function () {
        function AccordionComponent() {
            console.log('accordion constructor');
        }
        AccordionComponent.prototype.ngOnInit = function () { };
        return AccordionComponent;
    }());
    AccordionComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'hz-accordion',
                    template: "<div class=\"action-buttons\">\n    <button mat-button (click)=\"accordion.openAll()\">Expand All</button>\n    <button mat-button (click)=\"accordion.closeAll()\">Collapse All</button>\n</div>\n<mat-accordion class=\"headers-align\" multi>\n    <mat-expansion-panel *ngFor=\"let panel of config.panels\">\n        <mat-expansion-panel-header>\n            <mat-panel-title>\n                {{ panel.name }}\n            </mat-panel-title>\n            <mat-panel-description>\n                {{ panel.description }}\n                <mat-icon>\n                    {{panel.icon}}\n                </mat-icon>\n            </mat-panel-description>\n        </mat-expansion-panel-header>\n\n        <hz-content-container\n            [selector]=\"panel.component.selector\"\n            [settings]=\"panel.component.settings\">\n        </hz-content-container>\n    </mat-expansion-panel>\n</mat-accordion>",
                    styles: [".action-buttons{padding-bottom:20px}.headers-align .mat-expansion-panel-header-description,.headers-align .mat-expansion-panel-header-title{flex-basis:0}.headers-align .mat-expansion-panel-header-description{align-items:center;justify-content:space-between}.headers-align .mat-form-field+.mat-form-field{margin-left:8px}"]
                },] }
    ];
    AccordionComponent.ctorParameters = function () { return []; };
    AccordionComponent.propDecorators = {
        accordion: [{ type: i0.ViewChild, args: [expansion.MatAccordion,] }],
        config: [{ type: i0.Input }]
    };

    var DummyContentComponent = /** @class */ (function () {
        function DummyContentComponent() {
            console.log('dummy-content constructor');
        }
        DummyContentComponent.prototype.ngOnInit = function () { };
        return DummyContentComponent;
    }());
    DummyContentComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'hz-dummy-content',
                    template: "<p>Message: {{settings.message}}</p>\n",
                    styles: [""]
                },] }
    ];
    DummyContentComponent.ctorParameters = function () { return []; };
    DummyContentComponent.propDecorators = {
        settings: [{ type: i0.Input }]
    };

    var ContentContainerComponent = /** @class */ (function () {
        function ContentContainerComponent(cfr) {
            this.cfr = cfr;
            console.log('content-container constructor');
        }
        ContentContainerComponent.prototype.ngAfterViewInit = function () {
            var type = this.selector;
            if (type && this.content) {
                var factory = this.cfr.resolveComponentFactory(type);
                this.content.clear();
                this.componentRef = this.content.createComponent(factory, 0);
                this.componentRef.instance.settings = this.settings;
            }
        };
        ContentContainerComponent.prototype.ngOnDestroy = function () {
            if (this.componentRef) {
                this.componentRef.destroy();
                this.componentRef = null;
            }
        };
        return ContentContainerComponent;
    }());
    ContentContainerComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'hz-content-container',
                    template: "<ng-container #sidenavcontent></ng-container>\n",
                    styles: [""]
                },] }
    ];
    ContentContainerComponent.ctorParameters = function () { return [
        { type: i0.ComponentFactoryResolver }
    ]; };
    ContentContainerComponent.propDecorators = {
        content: [{ type: i0.ViewChild, args: ['sidenavcontent', { read: i0.ViewContainerRef },] }],
        selector: [{ type: i0.Input }],
        settings: [{ type: i0.Input }]
    };

    var NavigationComponent = /** @class */ (function () {
        function NavigationComponent(router) {
            this.router = router;
            console.log('navigation constructor');
        }
        NavigationComponent.prototype.ngOnInit = function () {
            console.log('navigation onInit');
            var n = this.navItems;
        };
        NavigationComponent.prototype.onNavigationSelection = function (navItem) {
            this.router.navigate([navItem.route]);
        };
        return NavigationComponent;
    }());
    NavigationComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'hz-navigation',
                    template: "<div class=\"navigation-content\">\n    <ul class=\"navigation-menu\">\n        <li *ngFor=\"let navItem of navItems\" (click)=\"onNavigationSelection(navItem)\">\n            {{ navItem.label }}\n        </li>\n    </ul>\n</div>",
                    styles: [".navigation-content{flex:1}.navigation-content .navigation-menu{list-style:none;margin:0;padding:0}.navigation-content li{font-size:1.25em;margin-bottom:32px}.navigation-content li a{color:#000;text-decoration:none}"]
                },] }
    ];
    NavigationComponent.ctorParameters = function () { return [
        { type: i1.Router }
    ]; };
    NavigationComponent.propDecorators = {
        navItems: [{ type: i0.Input }]
    };

    var SidenavModule = /** @class */ (function () {
        function SidenavModule() {
        }
        return SidenavModule;
    }());
    SidenavModule.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [
                        SidenavComponent,
                        HeaderComponent,
                        AccordionComponent,
                        DummyContentComponent,
                        ContentContainerComponent,
                        NavigationComponent,
                    ],
                    imports: [
                        common.CommonModule,
                        icon.MatIconModule,
                        expansion.MatExpansionModule,
                    ],
                    exports: [
                        SidenavComponent,
                        HeaderComponent,
                        AccordionComponent,
                        NavigationComponent,
                    ]
                },] }
    ];

    /*
     * Public API Surface of sidenav
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.AccordionComponent = AccordionComponent;
    exports.ContentContainerComponent = ContentContainerComponent;
    exports.DummyContentComponent = DummyContentComponent;
    exports.HeaderComponent = HeaderComponent;
    exports.NavigationComponent = NavigationComponent;
    exports.NavigationService = NavigationService;
    exports.SidenavComponent = SidenavComponent;
    exports.SidenavModule = SidenavModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=hugozalm-sidenav.umd.js.map
