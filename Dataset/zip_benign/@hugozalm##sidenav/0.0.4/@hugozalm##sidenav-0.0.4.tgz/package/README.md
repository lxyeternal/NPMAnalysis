# Sidenav

A 'sidenav'-component with configurable settings and a content=component

# Use
<!-- this is the sidenav -->
<!-- Settings: -->
<!-- direction: left or right (side from wich the sidenav appears) -->
<!-- navwidth: width of the sidenav in pixels -->
<!-- dureation: -->
<!-- autoClose: if true, sidnav closes automaticly when clicking a router-link (even in non-sidenav-content) -->
<hz-sidenav 
  [sidenavTemplateRef]="navContent"
  [direction]="'left'" 
  [navWidth]="280" 
  [duration]="0.5"
  [autoClose]="true">
</hz-sidenav>

<!-- next part is the main site-content -->
<!-- the hz-sidenav-header is a button wich will appear on top of the content and opens the sidenav -->
<!-- site's content is is filled with regular angular-router pages -->
<div>
  <hz-sidenav-app-header></hz-sidenav-app-header>
  <section>
    <router-outlet></router-outlet>
  </section>
</div>

<!-- next part will be placed in the sidnav -->
<!-- in this example it is a local app-component -->
<ng-template #navContent>
  <app-side-nav-content></app-side-nav-content>
</ng-template>


# Angular Version
This library was generated with [Angular CLI](https://github.com/angular/angular-cli) version 10.0.14.

