import { OnInit } from '@angular/core';
import { Router } from '@angular/router';
export declare class NavigationService implements OnInit {
    private router;
    private showNav$;
    constructor(router: Router);
    ngOnInit(): void;
    setAutoClose(autoClose: boolean): void;
    getShowNav(): import("rxjs").Observable<boolean>;
    setShowNav(showHide: boolean): void;
    toggleNavState(): void;
    isNavOpen(): boolean;
}
