import { ViewContainerRef, ComponentFactoryResolver, AfterViewInit } from '@angular/core';
export declare class ContentContainerComponent implements AfterViewInit {
    private cfr;
    content: ViewContainerRef;
    selector: any;
    settings: any;
    constructor(cfr: ComponentFactoryResolver);
    private componentRef;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
}
