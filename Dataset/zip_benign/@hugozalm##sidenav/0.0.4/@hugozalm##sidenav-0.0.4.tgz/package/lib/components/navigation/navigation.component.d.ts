import { OnInit } from '@angular/core';
import { Router } from '@angular/router';
export declare class NavigationComponent implements OnInit {
    private router;
    navItems: any[];
    constructor(router: Router);
    ngOnInit(): void;
    onNavigationSelection(navItem: any): void;
}
