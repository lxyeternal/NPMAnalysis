import { OnInit } from '@angular/core';
import { NavigationService } from '../../services/navigation.service';
export declare class HeaderComponent implements OnInit {
    private navService;
    constructor(navService: NavigationService);
    ngOnInit(): void;
    toggleSideNav(): void;
}
