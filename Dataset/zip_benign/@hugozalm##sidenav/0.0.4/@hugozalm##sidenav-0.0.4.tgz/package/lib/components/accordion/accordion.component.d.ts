import { OnInit } from '@angular/core';
import { MatAccordion } from '@angular/material/expansion';
export declare class AccordionComponent implements OnInit {
    accordion: MatAccordion;
    config: any;
    constructor();
    ngOnInit(): void;
}
