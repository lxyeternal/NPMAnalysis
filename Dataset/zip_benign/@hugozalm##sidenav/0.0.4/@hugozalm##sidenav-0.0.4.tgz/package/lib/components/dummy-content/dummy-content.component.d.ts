import { OnInit } from '@angular/core';
export declare class DummyContentComponent implements OnInit {
    settings: any;
    constructor();
    ngOnInit(): void;
}
