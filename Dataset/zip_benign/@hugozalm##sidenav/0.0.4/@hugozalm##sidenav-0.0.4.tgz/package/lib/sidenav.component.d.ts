import { OnInit } from '@angular/core';
import { NavigationService } from './services/navigation.service';
import { Observable } from 'rxjs';
import { SideNavDirection } from './sidenav-direction';
export declare class SidenavComponent implements OnInit {
    private navService;
    showSideNav: Observable<boolean>;
    sidenavTemplateRef: any;
    duration: number;
    navWidth: number;
    direction: SideNavDirection;
    autoClose: boolean;
    constructor(navService: NavigationService);
    ngOnInit(): void;
    onSidebarClose(): void;
    getSideNavBarStyle(showNav: boolean): any;
}
