export declare enum SideNavDirection {
    Left = "left",
    Right = "right"
}
