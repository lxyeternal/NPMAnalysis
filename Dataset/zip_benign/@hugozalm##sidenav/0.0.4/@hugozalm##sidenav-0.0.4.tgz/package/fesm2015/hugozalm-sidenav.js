import { ɵɵdefineInjectable, ɵɵinject, Injectable, Component, ViewEncapsulation, Input, ViewChild, ComponentFactoryResolver, ViewContainerRef, NgModule } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { CommonModule } from '@angular/common';
import { MatAccordion, MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';

class NavigationService {
    constructor(router) {
        this.router = router;
        this.showNav$ = new BehaviorSubject(false);
    }
    ngOnInit() { }
    setAutoClose(autoClose) {
        if (autoClose) {
            // here any navigation events (i.e. clicking on the nav items to go to a separate page)
            // will be captured inside this subscription, then we hide the nav by setting
            // the showNav$ to false or in our case, calling the setShowNav to false, which does the same
            this.router.events.subscribe(() => {
                this.setShowNav(false);
            });
        }
    }
    getShowNav() {
        return this.showNav$.asObservable();
    }
    setShowNav(showHide) {
        this.showNav$.next(showHide);
    }
    toggleNavState() {
        this.showNav$.next(!this.showNav$.value);
    }
    isNavOpen() {
        return this.showNav$.value;
    }
}
NavigationService.ɵprov = ɵɵdefineInjectable({ factory: function NavigationService_Factory() { return new NavigationService(ɵɵinject(Router)); }, token: NavigationService, providedIn: "root" });
NavigationService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
NavigationService.ctorParameters = () => [
    { type: Router }
];

var SideNavDirection;
(function (SideNavDirection) {
    SideNavDirection["Left"] = "left";
    SideNavDirection["Right"] = "right";
})(SideNavDirection || (SideNavDirection = {}));

class SidenavComponent {
    constructor(navService) {
        this.navService = navService;
        this.duration = 0.25;
        this.navWidth = window.innerWidth;
        this.direction = SideNavDirection.Left;
        this.autoClose = false;
    }
    ngOnInit() {
        this.navService.setAutoClose(this.autoClose);
        this.showSideNav = this.navService.getShowNav();
    }
    onSidebarClose() {
        this.navService.setShowNav(false);
    }
    getSideNavBarStyle(showNav) {
        let navBarStyle = {};
        navBarStyle.transition = this.direction + ' ' + this.duration + 's, visibility ' + this.duration + 's';
        navBarStyle.width = this.navWidth + 'px';
        navBarStyle[this.direction] = (showNav ? 0 : (this.navWidth * -1)) + 'px';
        return navBarStyle;
    }
}
SidenavComponent.decorators = [
    { type: Component, args: [{
                selector: 'hz-sidenav',
                template: "<!-- side bar main wrapper -->\n<div class=\"side-nav-bar\"\n    [ngClass]=\"{ 'side-nav-bar-collapsed': !(showSideNav | async) }\">\n    \n    <!-- overlay -->\n    <div class=\"side-nav-bar-overlay\" \n    [ngStyle]=\"{ 'transition': 'background-color ' + duration + 's, visibility ' + duration + 's' }\"\n    [ngClass]=\"{ 'side-nav-bar-overlay-collapsed': !(showSideNav | async) }\"\n        (click)=\"onSidebarClose()\"></div>\n    \n    <!-- side bar-->\n    <div class=\"side-nav-bar-menu-container\" \n    [ngStyle]=\"getSideNavBarStyle((showSideNav | async))\">\n        \n        <!-- close button -->\n        <div><span class=\"material-icons side-nav-bar-close\" (click)=\"onSidebarClose()\">clear</span></div>\n\n        <!-- side bar content -->\n        <div class=\"side-nav-bar-content-container\">\n            <ng-container *ngTemplateOutlet=\"sidenavTemplateRef\"></ng-container>\n        </div>\n    </div>\n</div>\n",
                encapsulation: ViewEncapsulation.None,
                styles: [".side-nav-bar{bottom:0;left:0;position:fixed;right:0;top:0;z-index:1001}.side-nav-bar .side-nav-bar-overlay{background:rgba(0,0,0,.5);height:100%;width:100%}.side-nav-bar .side-nav-bar-menu-container{background:#fff;bottom:0;display:flex;flex-direction:column;position:absolute;top:0}.side-nav-bar .side-nav-bar-menu-container .side-nav-bar-close{cursor:pointer;display:inline-block;font-size:2.5em;margin:24px 0 0 24px}.side-nav-bar .side-nav-bar-content-container{padding:32px}.side-nav-bar-overlay-collapsed{background:transparent!important}.side-nav-bar-collapsed{visibility:collapse!important}"]
            },] }
];
SidenavComponent.ctorParameters = () => [
    { type: NavigationService }
];
SidenavComponent.propDecorators = {
    sidenavTemplateRef: [{ type: Input }],
    duration: [{ type: Input }],
    navWidth: [{ type: Input }],
    direction: [{ type: Input }],
    autoClose: [{ type: Input }]
};

class HeaderComponent {
    constructor(navService) {
        this.navService = navService;
    }
    ngOnInit() {
    }
    toggleSideNav() {
        this.navService.setShowNav(true);
    }
}
HeaderComponent.decorators = [
    { type: Component, args: [{
                selector: 'hz-sidenav-app-header',
                template: "<header>\n    <div class=\"header-menu\">\n        <!-- <span (click)=\"toggleSideNav()\" class=\"menu-icon material-icons\">menu</span> -->\n        <span (click)=\"toggleSideNav()\" class=\"menu-icon\">\n            <mat-icon aria-hidden=\"false\" aria-label=\"open menu\">menu</mat-icon>\n        </span>\n    </div>\n</header>",
                encapsulation: ViewEncapsulation.None,
                styles: [".header-menu{background-color:#add8e6;border-radius:25px;margin:5px;position:absolute;z-index:1000}.menu-icon{cursor:pointer;font-size:2em;padding:18px}"]
            },] }
];
HeaderComponent.ctorParameters = () => [
    { type: NavigationService }
];

class AccordionComponent {
    constructor() {
        console.log('accordion constructor');
    }
    ngOnInit() { }
}
AccordionComponent.decorators = [
    { type: Component, args: [{
                selector: 'hz-accordion',
                template: "<div class=\"action-buttons\">\n    <button mat-button (click)=\"accordion.openAll()\">Expand All</button>\n    <button mat-button (click)=\"accordion.closeAll()\">Collapse All</button>\n</div>\n<mat-accordion class=\"headers-align\" multi>\n    <mat-expansion-panel *ngFor=\"let panel of config.panels\">\n        <mat-expansion-panel-header>\n            <mat-panel-title>\n                {{ panel.name }}\n            </mat-panel-title>\n            <mat-panel-description>\n                {{ panel.description }}\n                <mat-icon>\n                    {{panel.icon}}\n                </mat-icon>\n            </mat-panel-description>\n        </mat-expansion-panel-header>\n\n        <hz-content-container\n            [selector]=\"panel.component.selector\"\n            [settings]=\"panel.component.settings\">\n        </hz-content-container>\n    </mat-expansion-panel>\n</mat-accordion>",
                styles: [".action-buttons{padding-bottom:20px}.headers-align .mat-expansion-panel-header-description,.headers-align .mat-expansion-panel-header-title{flex-basis:0}.headers-align .mat-expansion-panel-header-description{align-items:center;justify-content:space-between}.headers-align .mat-form-field+.mat-form-field{margin-left:8px}"]
            },] }
];
AccordionComponent.ctorParameters = () => [];
AccordionComponent.propDecorators = {
    accordion: [{ type: ViewChild, args: [MatAccordion,] }],
    config: [{ type: Input }]
};

class DummyContentComponent {
    constructor() {
        console.log('dummy-content constructor');
    }
    ngOnInit() { }
}
DummyContentComponent.decorators = [
    { type: Component, args: [{
                selector: 'hz-dummy-content',
                template: "<p>Message: {{settings.message}}</p>\n",
                styles: [""]
            },] }
];
DummyContentComponent.ctorParameters = () => [];
DummyContentComponent.propDecorators = {
    settings: [{ type: Input }]
};

class ContentContainerComponent {
    constructor(cfr) {
        this.cfr = cfr;
        console.log('content-container constructor');
    }
    ngAfterViewInit() {
        const type = this.selector;
        if (type && this.content) {
            const factory = this.cfr.resolveComponentFactory(type);
            this.content.clear();
            this.componentRef = this.content.createComponent(factory, 0);
            this.componentRef.instance.settings = this.settings;
        }
    }
    ngOnDestroy() {
        if (this.componentRef) {
            this.componentRef.destroy();
            this.componentRef = null;
        }
    }
}
ContentContainerComponent.decorators = [
    { type: Component, args: [{
                selector: 'hz-content-container',
                template: "<ng-container #sidenavcontent></ng-container>\n",
                styles: [""]
            },] }
];
ContentContainerComponent.ctorParameters = () => [
    { type: ComponentFactoryResolver }
];
ContentContainerComponent.propDecorators = {
    content: [{ type: ViewChild, args: ['sidenavcontent', { read: ViewContainerRef },] }],
    selector: [{ type: Input }],
    settings: [{ type: Input }]
};

class NavigationComponent {
    constructor(router) {
        this.router = router;
        console.log('navigation constructor');
    }
    ngOnInit() {
        console.log('navigation onInit');
        let n = this.navItems;
    }
    onNavigationSelection(navItem) {
        this.router.navigate([navItem.route]);
    }
}
NavigationComponent.decorators = [
    { type: Component, args: [{
                selector: 'hz-navigation',
                template: "<div class=\"navigation-content\">\n    <ul class=\"navigation-menu\">\n        <li *ngFor=\"let navItem of navItems\" (click)=\"onNavigationSelection(navItem)\">\n            {{ navItem.label }}\n        </li>\n    </ul>\n</div>",
                styles: [".navigation-content{flex:1}.navigation-content .navigation-menu{list-style:none;margin:0;padding:0}.navigation-content li{font-size:1.25em;margin-bottom:32px}.navigation-content li a{color:#000;text-decoration:none}"]
            },] }
];
NavigationComponent.ctorParameters = () => [
    { type: Router }
];
NavigationComponent.propDecorators = {
    navItems: [{ type: Input }]
};

class SidenavModule {
}
SidenavModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    SidenavComponent,
                    HeaderComponent,
                    AccordionComponent,
                    DummyContentComponent,
                    ContentContainerComponent,
                    NavigationComponent,
                ],
                imports: [
                    CommonModule,
                    MatIconModule,
                    MatExpansionModule,
                ],
                exports: [
                    SidenavComponent,
                    HeaderComponent,
                    AccordionComponent,
                    NavigationComponent,
                ]
            },] }
];

/*
 * Public API Surface of sidenav
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AccordionComponent, ContentContainerComponent, DummyContentComponent, HeaderComponent, NavigationComponent, NavigationService, SidenavComponent, SidenavModule };
//# sourceMappingURL=hugozalm-sidenav.js.map
