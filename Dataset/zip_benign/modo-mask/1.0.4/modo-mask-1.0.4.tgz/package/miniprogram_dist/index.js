module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var noop = function () { };
Component({
    options: {
        multipleSlots: true,
    },
    properties: {
        maskStatus: {
            type: Boolean,
            value: false
        },
        duration: {
            type: String,
            value: '200ms',
            observer: function (newVal) {
                this.setStyleDict({
                    type: 'transition-duration',
                    prefix: '-webkit-',
                    value: newVal,
                });
            },
        },
        bgColor: {
            type: String,
            value: 'rgba(0, 0, 0, 0.5)',
            observer: function (newVal) {
                this.setStyleDict({
                    type: 'background-color',
                    value: newVal,
                });
            }
        },
        zIndex: {
            type: Number,
            value: 100,
            observer: function (newVal) {
                this.setStyleDict({
                    type: 'z-index',
                    value: newVal,
                });
            }
        }
    },
    data: {
        maskStyleDict: {
            'transition-duration': { value: '200ms', priority: 0, prefix: '-webkit-' },
            'background-color': { value: 'rgba(0, 0, 0, 0.5)', priority: 0 },
            'z-index': { value: 100, priority: 0 },
        },
        maskStyle: ''
    },
    lifetimes: {
        attached: function () {
            this.setStyle();
        },
    },
    methods: {
        noop: noop,
        setStyle: function () {
            var _this = this;
            var maskStyle = Object.keys(this.data.maskStyleDict)
                .reduce(function (acc, key) {
                var _a = _this.data.maskStyleDict[key], prefix = _a.prefix, value = _a.value;
                return !!prefix
                    ? acc + "; " + key + ": " + value + "; " + prefix + key + ": " + value + ";"
                    : acc + "; " + key + ": " + value;
            }, '');
            this.setData({ maskStyle: maskStyle });
        },
        setStyleDict: function (_a) {
            var type = _a.type, value = _a.value, _b = _a.priority, priority = _b === void 0 ? 0 : _b, _c = _a.prefix, prefix = _c === void 0 ? '' : _c;
            var dict = this.data.maskStyleDict;
            if (!(type in dict) || dict[type].priority <= priority) {
                this.data.maskStyleDict[type] = { value: value, priority: priority, prefix: prefix };
            }
            else {
                return;
            }
            this.setStyle();
        },
        handleTapMask: function () {
            this.triggerEvent('tapmask');
        }
    }
});


/***/ })
/******/ ]);