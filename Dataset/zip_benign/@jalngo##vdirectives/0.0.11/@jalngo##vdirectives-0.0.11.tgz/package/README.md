# v-directives

基于 vue 的自定义指令集合，包含

-   添加水印 `v-waterMarker`
-   自适应（自动计算）设置高度 `v-autoHeight`
-   基于 ElementUI 对话框（dialog）实现可拖拽功能 `v-dialogDrag`

## Installation

```sh
npm install -D jalngo-custom-directive
```

## Usage

```js
import Vue from 'vue';
import customDirective from 'jalngo-custom-directive';
Vue.use(customDirective);
```

## Introduce

### vue-waterMarker

使用场景：给某个页面添加背景水印

可设置水印文案，颜色，字体大小

```html
<template>
    <div v-waterMarker="{text:'JalnGo版权所有', font: '28px Microsoft JhengHei', textColor:'rgba(180, 180, 180, 0.4)'}"></div>
</template>
```

### vue-autoHeight

使用场景：当某个元素需要自适应屏幕高度可自动计算高度

```html
<template>
    <div v-autoHeight="{ extraHeight: 0 }"></div>
</template>
```

### vue-dialogDrag

使用场景：ElementUI 对话框（dialog）在页面可视范围内实现可拖拽

```html
<template>
    <!-- dialogVisible是对话框是否显示布尔类型 -->
    <div v-dialogDrag="dialogVisible"></div>
</template>
```
