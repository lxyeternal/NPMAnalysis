(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
    typeof define === 'function' && define.amd ? define(factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, global['@jalngo/vdirectives'] = factory());
}(this, (function () { 'use strict';

    /*
     * @Descripttion : 实现ElementUI对话框可拖拽功能
     * @Author       : JLG
     * @Date         : 2020-12-23 17:23:09
     * @LastEditors  : JalnGo
     * @LastEditTime : 2021-05-08 14:20:43
     */
    // v-dialogDrag: 弹窗拖拽属性
    var ElDialogDrag = {
      bind(el) {
        const dialogHeaderEl = el.querySelector('.el-dialog__header');
        const dragDom = el.querySelector('.el-dialog');
        dialogHeaderEl.style.cssText += ';cursor:move;'; // 获取原有属性 ie dom元素.currentStyle 火狐谷歌 window.getComputedStyle(dom元素, null);

        const sty = function () {
          if (window.document.currentStyle) {
            return (dom, attr) => dom.currentStyle[attr];
          } else {
            return (dom, attr) => getComputedStyle(dom, false)[attr];
          }
        }();

        dialogHeaderEl.onmousedown = e => {
          // 鼠标按下，计算当前元素距离可视区的距离
          const disX = e.clientX - dialogHeaderEl.offsetLeft;
          const disY = e.clientY - dialogHeaderEl.offsetTop;
          const screenWidth = document.body.clientWidth; // body当前宽度

          const screenHeight = document.documentElement.clientHeight; // 可见区域高度(应为body高度，可某些环境下无法获取)

          const dragDomWidth = dragDom.offsetWidth; // 对话框宽度

          const dragDomheight = dragDom.offsetHeight; // 对话框高度

          const minDragDomLeft = dragDom.offsetLeft;
          const maxDragDomLeft = screenWidth - dragDom.offsetLeft - dragDomWidth;
          const minDragDomTop = dragDom.offsetTop;
          const maxDragDomTop = screenHeight - dragDom.offsetTop - dragDomheight; // 获取到的值带px 正则匹配替换

          let styL = sty(dragDom, 'left');
          let styT = sty(dragDom, 'top'); // 注意在ie中 第一次获取到的值为组件自带50% 移动之后赋值为px

          if (styL.includes('%')) {
            // eslint-disable-next-line no-useless-escape
            styL = +document.body.clientWidth * (+styL.replace(/\%/g, '') / 100); // eslint-disable-next-line no-useless-escape

            styT = +document.body.clientHeight * (+styT.replace(/\%/g, '') / 100);
          } else {
            styL = +styL.replace(/\px/g, '');
            styT = +styT.replace(/\px/g, '');
          }

          document.onmousemove = function (e) {
            // 通过事件委托，计算移动的距离
            let left = e.clientX - disX;
            let top = e.clientY - disY; // 边界处理

            if (-left > minDragDomLeft) {
              left = -minDragDomLeft;
            } else if (left > maxDragDomLeft) {
              left = maxDragDomLeft;
            }

            if (-top > minDragDomTop) {
              top = -minDragDomTop;
            } else if (top > maxDragDomTop) {
              top = maxDragDomTop;
            } // 移动当前元素


            dragDom.style.cssText += `;left:${left + styL}px;top:${top + styT}px;`;
          };

          document.onmouseup = function () {
            document.onmousemove = null;
            document.onmouseup = null;
          };
        };
      },

      update(el, binding) {
        if (binding.value === false) {
          const dragDom = el.querySelector('.el-dialog');
          setTimeout(() => {
            dragDom.style.cssText += ';left:auto;top:auto;';
          }, 500);
        }
      }

    };

    /*
     * @Descripttion : 自动计算高度已占据整个屏幕（高度自适应）
     * @Author       : JLG
     * @Date         : 2020-12-23 17:31:27
     * @LastEditors  : JalnGo
     * @LastEditTime : 2021-05-08 14:21:34
     */
    // 枚举信息
    const typeEnums = {
      default: 'default',
      isFooter: 'isFooter',
      table: 'table',
      notTable: 'notTable',
      none: 'none'
    }; // 默认配置

    const defaultAutoHeight = {
      type: typeEnums.default,
      extraHeight: 0
    };

    function getTop(el) {
      return el.offsetParent ? el.offsetTop + getTop(el.offsetParent) : el.offsetTop;
    }

    var eventHandler = null;
    var AutoResizeHeight = {
      inserted(el, binding) {
        let autoHeight = Object.deepExtend({}, defaultAutoHeight);

        if (typeof binding.value == 'object') {
          autoHeight = Object.deepExtend(autoHeight, binding.value);
        } else {
          switch (binding.value) {
            // 底部含有footer
            case 'isFooter':
              autoHeight.type = typeEnums.isFooter;
              break;

            case 'none':
              autoHeight.type = typeEnums.none;
              break;

            case 'notTable':
              autoHeight.type = typeEnums.notTable;
              break;

            default:
              autoHeight.type = typeEnums.default;
            // 默认是tabel兼容以前代码
          }
        } // if (autoHeight.type == typeEnums.none) {
        //     return
        // } else if (autoHeight.type == typeEnums.default) { // 单纯设置高度
        //     autoHeight.height && (el.style.height = autoHeight.height);
        //     return
        // }
        // 获取距离顶部高度、版权信息高度、多余高度


        let top = getTop(el),
            footer = 0;

        if (autoHeight.type == typeEnums.isFooter) {
          footer = 70;
        } // 删减高度


        let subHeight = top + footer + autoHeight.extraHeight; // 设置当前高度

        el.style.height = document.body.clientHeight - subHeight + 'px'; // 监听高度变化

        eventHandler = function () {
          top = getTop(el);
          el.style.height = document.body.clientHeight - subHeight + 'px';
        };

        window.addEventListener('resize', eventHandler, false); // 监听DOM变动，当DOM对象树发生任何变动时，MutationObser会等到通知

        var observer = new MutationObserver(function (mutations) {
          mutations.forEach(() => {
            eventHandler();
          });
        });
        var config = {
          attributes: true,
          attributeOldValue: true,
          attributeFilter: ['style']
        };

        if (document.body.querySelector('.table-row-detail')) {
          observer.observe(document.body.querySelector('.table-row-detail'), config);
        }
      },

      unbind() {
        window.removeEventListener('resize', eventHandler, false);
      }

    };

    /*
     * @Descripttion : 给页面添加背景水印
     * @Author       : JLG
     * @Date         : 2021-01-29 16:15:36
     * @LastEditors  : JalnGo
     * @LastEditTime : 2021-05-07 16:41:56
     */
    function addWaterMarker(str, parentNode, font, textColor) {
      // 水印文字，父元素，字体，文字颜色
      var can = document.createElement('canvas');
      parentNode.appendChild(can);
      can.width = 200;
      can.height = 150;
      can.style.display = 'none';
      var cans = can.getContext('2d');
      cans.rotate(-20 * Math.PI / 180);
      cans.font = font || '16px Microsoft JhengHei';
      cans.fillStyle = textColor || 'rgba(180, 180, 180, 0.3)';
      cans.textAlign = 'left';
      cans.textBaseline = 'Middle';
      cans.fillText(str, can.width / 10, can.height / 2);
      parentNode.style.backgroundImage = 'url(' + can.toDataURL('image/png') + ')';
    }

    const waterMarker = {
      bind: function (el, binding) {
        addWaterMarker(binding.value.text, el, binding.value.font, binding.value.textColor);
      }
    };

    const GuiPlugins = {
      install(Vue) {
        Vue.directive('dialogDrag', ElDialogDrag);
        Vue.directive('autoHeight', AutoResizeHeight);
        Vue.directive('waterMarker', waterMarker);
      }

    };

    return GuiPlugins;

})));
