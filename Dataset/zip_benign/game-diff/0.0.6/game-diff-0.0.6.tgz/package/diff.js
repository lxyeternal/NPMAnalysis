Component({
  mixins: [],
  data: {
    boxId: ""
  },
  props: {},
  didMount() {
    this.parFun("onRef", this);
    this.setData({
      boxId: `f_${this.uniId()}`
    }, () => {
      this.componentInit();
    })
  },
  didUpdate() { },
  didUnmount() { },
  methods: {
    uniId: function () {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    },
    //读取节点信息
    dom(className) {
      return new Promise(function (resolve, reject) {
        let result = {};
        my.createSelectorQuery()
          .select(className)
          .boundingClientRect()
          .exec(([ret]) => {
            if (ret) {
              result.success = true;
              result.data = ret;
            } else {
              result.success = false;
            }
            resolve(result);
          })
      })
    },
    parFun(funName, options) {
      let bl = false;
      try {
        // 判断组件是否有传入事件，如果没有，则再判断页面上是否有指定事件
        this.props[funName](options);
      } catch (e) {
        bl = true;
      }
      if (bl) {
        try {
          // 判断组件是否有传入事件，如果没有，则再判断页面上是否有指定事件
          this.$page[funName](options);
        } catch (e) {
          bl = true;
        }
      }
      if (bl) {
        console.log(`页面和组件传递都没有找到方法：${funName}`)
      }
    },
    random: function (options) {
      let opt = Object.assign({ min: 0, max: 0, isFloat: false, noNum: [] }, options);
      let tempNum;
      do {
        let num = Math.random() * (opt.max - opt.min) + opt.min;
        tempNum = !!opt.isFloat ? num : parseInt(num);
      } while (opt.noNum.includes(tempNum));
      return tempNum;
    },
    getRandomImg: function (images, opsFilter) {
      let filter = Object.assign({ not: {}, is: {} }, opsFilter);
      let isArr = Object.keys(filter.is);
      let notArr = Object.keys(filter.not);
      images.forEach(item => { item.del = false; })

      images.forEach(item => {
        isArr.forEach(isName => {
          if (item[isName] != filter.is[isName]) {
            item.del = true;
          }
        })
        notArr.forEach(isName => {
          if (item[isName] == filter.not[isName]) {
            item.del = true;
          }
        })
      })
      let arr = [];
      images.forEach(item => {
        if (!item.del) {
          arr.push(item);
        }
      })
      let totalProbability = 0;
      arr.forEach(item => {
        item.maxProbability = totalProbability + (item.probability || 1);
        totalProbability = item.maxProbability;
      });
      arr.forEach(item => {
        item.totalProbability = totalProbability;
      });

      let imgObj;
      let idx = 0;
      if (arr.length > 1) {
        idx = this.random({ max: totalProbability });
      }

      arr.forEach(item => {
        if (!imgObj && idx < item.maxProbability) {
          imgObj = item;
        }
      });
      return imgObj;
    },
    randomArray: function (arr) {
      return arr.sort(() => Math.random() - 0.5);
    },
    async componentInit() {
      let domData = await this.dom(`#${this.data.boxId}`);
      this.winW = domData.data.width;
      this.winH = domData.data.height;


      let gameData = this.props.gameSource;
      try {
        gameData = JSON.parse(gameData);
      } catch (e) { }
      this.gameData = gameData;
      let padding = Object.assign({
        left: 0,
        top: 0,
        right: 0,
        bottom: 0
      }, gameData.padding);
      this.setData({
        gameData,
        rotateTime: gameData.rotateTime || 0.5,
        padding
      })

      this.parFun("onInitDone", this);
    },
    async initGame(row, col, levelName, callback) {
      let _col = parseInt(col);
      let _row = parseInt(row);

      let totalNum = (_col * _row) / 2;
      let imgs = this.gameData.items.filter(i => {
        if (!levelName) { return true; }
        let level = i.level || [];
        if (level.includes(levelName)) { return true; }
        return false;
      })
      let curArr = [];
      let i = 0;
      imgs.forEach(img => {
        if (img.minShow) {
          for (let j = 0; j < img.minShow; j++) {
            curArr.push(img);
            curArr.push(img);
            i++;
          }
        }
      })
      for (; i < totalNum; i++) {
        let img = this.getRandomImg(imgs);
        curArr.push(img)
        curArr.push(img)
      }
      this.randomArray(curArr);
      // 当前选中的
      this.gameStatus = false;
      this.selectObj = {};

      this.setData({
        singleW: this.winW / col,
        singleH: this.winH / row,
        row,
        col,
        images: curArr
      }, () => {
        !!callback && callback();
      })
    },
    open(nums, callback) {
      let obj = {};

      nums.forEach(i => {
        obj[`images[${i}].select`] = true;
      })

      this.setData(obj, () => {
        !!callback && callback();
      })
    },
    close(nums, callback) {
      let obj = {};

      nums.forEach(i => {
        obj[`images[${i}].select`] = false;
      })

      this.setData(obj, () => {
        !!callback && callback();
      })
    },
    clickFun(e) {
      let { currentTarget: { dataset: { index, item } } } = e;
      if (!this.gameStatus || !!item.hidden) { return false; }

      if (typeof this.selectObj.begin == "undefined") {
        // 点击了开始第一个卡片
        this.selectObj.begin = {
          index,
          item
        };
        this.open([index])
      } else if (typeof this.selectObj.end == "undefined") {
        // 点击第二个卡片
        if (index == this.selectObj.begin.index) { return false; }
        this.selectObj.end = {
          index,
          item
        };
        this.open([index], () => {
          setTimeout(() => {
            this.checkFun();
          }, this.data.rotateTime * 1000);
        })
      }
    },
    openAll() {
      if (!this.gameStatus) { return false; }
      let obj = {};
      this.data.images.forEach((item, idx) => {
        if (!item.hidden) {
          obj[`images[${idx}].select`] = true
        }
      })
      this.setData(obj)
    },
    closeAll() {
      if (!this.gameStatus) { return false; }
      let obj = {};
      this.data.images.forEach((item, idx) => {
        if (!item.hidden) {
          obj[`images[${idx}].select`] = false
        }
      })
      this.setData(obj)
    },
    start() {
      this.gameStatus = true;
    },
    stop() {
      this.gameStatus = false;
    },
    checkFun() {
      let begin = this.selectObj.begin, end = this.selectObj.end;
      let obj = { items: [begin.item, end.item] };
      if (begin.item.url == end.item.url) {
        // 匹配一致
        obj.type = "success";
        obj.hasNum = 0;
        this.data.images.forEach((item, index) => { if (!item.hidden && index != begin.index && index != end.index) { obj.hasNum++; } })
        this.setData({
          [`images[${begin.index}].hidden`]: true,
          [`images[${end.index}].hidden`]: true,

          // [`images[${begin.index}].select`]: false,
          // [`images[${end.index}].select`]: false,
        })
        if (obj.hasNum == 0) {
          // 游戏结束
          this.stop();
        }
      } else {
        // 不匹配
        obj.type = "error";
        this.close([begin.index, end.index]);
        obj.hasNum = 0;
        this.data.images.forEach((item, index) => { if (!item.hidden) { obj.hasNum++; } })
      }
      this.selectObj = {};
      this.parFun("onUpdate", obj);
    },
  },
});