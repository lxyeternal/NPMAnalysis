# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.1.11](http://git.meprint.com/frontend/chemical-sdk/compare/v0.1.10...v0.1.11) (2022-03-01)


### Bug Fixes

* 修复utm来源判断错误 ([a976cf9](http://git.meprint.com/frontend/chemical-sdk/commit/a976cf9c3b487028aba229303e31d4749b575fa1))

### [0.1.10](http://git.meprint.com/frontend/chemical-sdk/compare/v0.1.9...v0.1.10) (2022-02-28)


### Features

* 新增postData命令 ([41fba6b](http://git.meprint.com/frontend/chemical-sdk/commit/41fba6b96396cab65cb2f0bec3258bebbb51f7dd))

### [0.1.9](http://git.meprint.com/frontend/chemical-sdk/compare/v0.1.8...v0.1.9) (2022-02-28)

### [0.1.8](http://git.meprint.com/frontend/chemical-sdk/compare/v0.1.7...v0.1.8) (2022-02-24)

### [0.1.7](http://git.meprint.com/frontend/chemical-sdk/compare/v0.1.6...v0.1.7) (2022-02-21)

### [0.1.6](http://git.meprint.com/frontend/chemical-sdk/compare/v0.1.5...v0.1.6) (2022-02-18)


### Features

* setUserId 添加支持清空 ([1d98a4c](http://git.meprint.com/frontend/chemical-sdk/commit/1d98a4ca4e208420545a967f3f587f4d074cd4bf))

### [0.1.5](http://git.meprint.com/frontend/chemical-sdk/compare/v0.1.3...v0.1.5) (2022-02-17)

### [0.1.3](http://git.meprint.com/frontend/chemical-sdk/compare/v0.1.2...v0.1.3) (2022-02-17)


### Features

* 发送数据时机优化，添加 auto 属性，支持批量上报 ([af9e413](http://git.meprint.com/frontend/chemical-sdk/commit/af9e4138f394f115326d17f90e0c9b78afcd3270))
* 提供 ajax 方法 ([fd557d3](http://git.meprint.com/frontend/chemical-sdk/commit/fd557d36561cc525c387b7761a37ae842ea8c44d))
* 添加流量来源属性 ([470d9f9](http://git.meprint.com/frontend/chemical-sdk/commit/470d9f9b79e2badfbdee31bbc59c859ee3b72469))
* 添加用户标识 ([ef6717f](http://git.meprint.com/frontend/chemical-sdk/commit/ef6717f152efbfe240a460ff5a361c818a445061))
* 新增 platformType 平台类型属性 ([910ba48](http://git.meprint.com/frontend/chemical-sdk/commit/910ba4887b13f53defc67fdd915bca06ca3abc2c))
* 新增 UTM 解析 ([898c936](http://git.meprint.com/frontend/chemical-sdk/commit/898c9361c06a3e8555fa63a5ba1568aa2506cc20))


### Bug Fixes

* 处理 pageleave 基础数据移动到 storage 文件中，小程序也有同样的问题 ([ef9d114](http://git.meprint.com/frontend/chemical-sdk/commit/ef9d11455a3244e1056e9fa0621b8de6c5e91c87))
* 去除 pageleave 事件延迟执行，延迟执行会导致获取的页面数据错误，并修复 referPage 错误 ([303be80](http://git.meprint.com/frontend/chemical-sdk/commit/303be8063e1591c3d254a730fa12b2d2cc98109f))
* 修复变量不存在 ([6b59f3a](http://git.meprint.com/frontend/chemical-sdk/commit/6b59f3a9d39e613a29d55aaa0ccdd8b4aa333479))
* 修复关闭小程序没有触发页面浏览时长事件 ([0d9f223](http://git.meprint.com/frontend/chemical-sdk/commit/0d9f22395e9525eed102f801875e3e82e3c0209a))
* close 数据没有发送出去 ([1b3192a](http://git.meprint.com/frontend/chemical-sdk/commit/1b3192a7192a2deec059b0bb34567e6802fb013d))
* getDeviceId not export ([e2178c7](http://git.meprint.com/frontend/chemical-sdk/commit/e2178c77ff27b8e18527cdcf638e9d94b797c7e1))

### 0.1.2 (2021-11-03)


### Features

* 初始化 ([cbe4a65](http://git.meprint.com/frontend/chemical-sdk/commit/cbe4a65f7ca111aafae5bfaf1bf90aae950ba942))
* 点击事件可节流并且可配置响应时间 ([785d9b7](http://git.meprint.com/frontend/chemical-sdk/commit/785d9b78daf1ebb246de5827173d470cd32ef5d6))
* 对外提供设置公共数据接口 ([68c8126](http://git.meprint.com/frontend/chemical-sdk/commit/68c8126ee48e3abe27482a92f003651e28c4dc8d))
* 解析 web 端 userAgent 信息 ([4e8aa6b](http://git.meprint.com/frontend/chemical-sdk/commit/4e8aa6bc2c1826110993f57a0d065fc799ca7be2))
* 埋点上报 ([26a6a63](http://git.meprint.com/frontend/chemical-sdk/commit/26a6a63baa0b1a33b16ae3bf9035fa4f4a843977))
* 添加 .npmignore 文件 ([b9278d5](http://git.meprint.com/frontend/chemical-sdk/commit/b9278d580309f6b40d72ff6b8dee2da73aee2f85))
* 添加 pageclose 事件 ([570af1a](http://git.meprint.com/frontend/chemical-sdk/commit/570af1a2739a56e11b1c8618105cbc6524122129))
* 添加支持微信原生小程序点击、曝光事件上报 ([edf124f](http://git.meprint.com/frontend/chemical-sdk/commit/edf124ff66012477c0f4027d3281eab2ed29eb56))
* 完善小程序获取系统信息属性 ([fc03ebb](http://git.meprint.com/frontend/chemical-sdk/commit/fc03ebbba4ab8afcd0350c90811613687d99253f))
* 微信小程序添加 pageleave、pageclose 事件 ([80f3c7a](http://git.meprint.com/frontend/chemical-sdk/commit/80f3c7a9df5d62f1f04819bb9bb1ddf4c4700e19))
* 新增微信原生小程序 chemical-click 组件 ([606a21b](http://git.meprint.com/frontend/chemical-sdk/commit/606a21beb172ee6b1af824acd793e2fb6bfbd437))
* 允许 onAdd 返回空，过滤当前数据 ([29bc247](http://git.meprint.com/frontend/chemical-sdk/commit/29bc24776f0148d92309ea073b9a9acdf7ecf8d5))
* web 端新增 pageleave 事件 ([1204f97](http://git.meprint.com/frontend/chemical-sdk/commit/1204f977c3b75b88ccc74e441a8c00e0261198e7))


### Bug Fixes

* 修复 addChemicalData 对外接口 this 绑定问题 ([18ecc68](http://git.meprint.com/frontend/chemical-sdk/commit/18ecc68666ce74586237eb7c903fbaf18f22f69a))
* 修复 onAdd 修改数据，节流对比错误 ([05bf860](http://git.meprint.com/frontend/chemical-sdk/commit/05bf8602a662a28634874dd914e71bb9caf3491f))
* taro click 事件获取数据方法缺少属性名 ([d3aced7](http://git.meprint.com/frontend/chemical-sdk/commit/d3aced7de309db45df3cedbac17b610c79c08dbb))
