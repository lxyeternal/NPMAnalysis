module.exports = function(value) {
  var x = Math.max(0, Math.min(1, value));
  return x*x*(3 - 2*x);
};