
const spatialIndex = require('.')

function dist2 (a, b) {
  var dx = b[0] - a[0]
  var dy = b[1] - a[1]
  return Math.sqrt(dx * dx + dy * dy)
}
const points = [[0, 0], [1, 0], [2, 1], [1, 0], [0, 0], [0, 2]]

const index = spatialIndex(points, dist2, [0, 1])

console.log(index.uniquePoints())
console.log(index.nearestPoint([0.5, 0.7]))
console.log(index.indexOf([0, 2]))
console.log(index.indexOf([2, 0]))
