# v2.0.1

- [index] export { updateOptions } to have upstream packages extend it.

# v2.0.0

- [major] [label] separate the label placement fom the final prop creation so that we can do the label placement in a Web Worker, and when complete we can spread common props that require the WebGL context to produce. This work is being done in tandem with `mixmap-georender@7` which is also splitting work to do the heaviest parts in Web Workers, and then spreading common props for `regl` rendering on the main thread.
- [major] [shaders] updating the label shader interface to accept all props via `map.prop`, instead of seeding the props within a function that takes common props and defines the draw command with only those prepared props in mind.
- [patch] [label] allow for fontSize of 0 values and guard against division by 0 errors. do not include labels for measuring that have font size of 0.
- [minor] [label] `label.update` options includes defining a subset of feature types to label (point | line | area).
- [minor] [workers] add `src/workers/label` to do label positioning within a worker. This also relies on the 1.3.0 version of `tiny-atlas`, which includes a `TinySDFOffscreen` class that overrides the `_createCanvas` method and first looks for a `document` to create the element, and if not looks for OffscreenCanvas.

# v1

- Render axis aligned labels using `label-placement-engine` and `tiny-atlas` for preparing gpu ready props that get sent to a `regl` draw command.
