import { Atlas } from 'tiny-atlas'
import LabelEngine from 'label-placement-engine'
import labelPresetBbox from 'label-placement-engine/preset/bbox'
import labelPresetPoint from 'label-placement-engine/preset/point'
import labelPresetLine from 'label-placement-engine/preset/line'
import labelPresetArea from 'label-placement-engine/preset/area'
import StyleSettings from '@rubenrodriguez/georender-style2png/settings'
import Read from '@rubenrodriguez/georender-style2png/read'

const labelPreset = {
  bbox: labelPresetBbox,
  point: labelPresetPoint,
  line: labelPresetLine,
  area: labelPresetArea,
}

const labelTypes = {
  pointP: 'point',
  pointT: 'point',
  lineP: 'line',
  lineT: 'line',
  areaP: 'bbox',
  areaT: 'bbox',
}

// atlas: [{ fontFamily, ... }]
export const defaultLabelOpts = {
  atlas: [{
    fontSize: 48,
    buffer: 6,
    radius: 16,
    cutoff: 0.25,
    fontFamily: 'Arial',
  }],
  labelEngine: {
    outlines: false,
    types: {
      bbox: labelPreset.bbox(),
      point: labelPreset.point({
        labelMargin: [10,10],
        pointSize: [10,10],
        pointMargin: [10,10],
        pointSeparation: [10,10],
      }),
      line: labelPreset.line({
        labelMargin: [10,10],
        lineSize: [10,10],
        lineMargin: [10,10],
        lineSeparation: [10,10],
        sides: ['center'],
      }),
      area: labelPreset.area({
        labelMargin: [10,10],
      }),
    }
  },
}

// Creating glyphs in the same context that a `mixmap` and its underlying
// `regl` instance are available
export const createGlyphProps = (labelProps, map) => {
  const baseGamma = 2.0 * 1.4142
  const glyphs = labelProps.glyphs =[]
  for (let i = 0; i < labelProps.atlas.length; i++) {
    const atlas = labelProps.atlas[i]
    if (atlas.texture.width === 0) continue
    const atlasBaselineOffset = atlas.baselineOffset
    const atlasGlyphsTextureDim = [atlas.texture.width, atlas.texture.height]
    const atlasGlyphsTexture = map.regl.texture(atlas.texture)

    const glyphProps = []
    for (const mapProps of map._props()) {
      for (let j = 0; j < labelProps.atlas[i].glyphs.length; j++) {
        const glyph = labelProps.atlas[i].glyphs[j]
        const { fontSize, fillColor, strokeColor, strokeWidth } = glyph
        const gamma = fontSize > 0 ? baseGamma / fontSize : 0
        const strokeBufferDelta = fontSize > 0 ? strokeWidth / fontSize : 0
        const stroke = {
          ...glyph,
          ...mapProps,
          buffer: 0.75 - strokeBufferDelta,
          gamma,
          color: strokeColor,
          atlasBaselineOffset,
          atlasGlyphsTextureDim,
          atlasGlyphsTexture,
        }
        const fill = {
          ...glyph,
          ...mapProps,
          buffer: 0.75,
          gamma,
          color: fillColor,
          atlasBaselineOffset,
          atlasGlyphsTextureDim,
          atlasGlyphsTexture,
        }
        glyphProps.push(stroke)
        glyphProps.push(fill)
      }  
    }
    glyphs.push(glyphProps)
  }
}

export const propsIncludeLabels = (p) => {
  return p?.label?.atlas?.length > 0
}

export const updateOptions = {
  labelFeatureTypes: ['point', 'line', 'area'],
  measureLabels: null,
}

export class Label {
  constructor (opts={}) {
    // opts.fontFamily or opts.atlas can be used
    // to configure `this._atlas`
    // this._atlas : { fontFamilyIndex: Atlas }
    if (Array.isArray(opts.fontFamily)) {
      opts.atlas = opts.fontFamily.map((fontFamily) => {
        return {
          ...defaultLabelOpts.atlas,
          fontFamily,
        }
      })
      this._fontFamily = opts.fontFamily
    }
    if (!opts.atlas) opts.atlas = defaultLabelOpts.atlas
    this._atlas = opts.atlas.map((atlasOpts) => {
      const opts = {
        ...defaultLabelOpts.atlas[0],
        ...atlasOpts,
      }
      const atlas = new Atlas(opts)
      return atlas
    })
    this._labelEngine = LabelEngine({
      ...defaultLabelOpts.labelEngine,
      ...opts.labelEngine,
    })
    this.style = opts.style
    this._props = {}

    if (this.style) {
      this._setStyleRead()
    }
  }
  _setStyleRead () {
    const styleSettings = StyleSettings()
    const labelFontFamily = this.style?.labelFontFamily || this._fontFamily || ['Arial']
    this.styleRead = Read({
      pixels: this.style.data,
      zoomCount: styleSettings.zoomCount,
      imageWidth: styleSettings.imageWidth,
      labelFontFamily,
    })
  }
  update (props, mapProps, opts=updateOptions) {
    if (opts.style) {
      this.style = opts.style
      this._setStyleRead()
    }
    for (const index in this._atlas) {
      this._atlas[index].clear()
    }
    const measureLabels = opts?.measureLabels || []
    const style = this.style

    const labelFeatureTypes = {
      point: opts?.labelFeatureTypes?.includes('point'),
      line: opts?.labelFeatureTypes?.includes('line'),
      area: opts?.labelFeatureTypes?.includes('area'),
    }

    const addPropsToMeasureLabels = (p) => {
      if (labelFeatureTypes.point) {
        this._addPoint(mapProps, style, measureLabels, p.pointT)
        this._addPoint(mapProps, style, measureLabels, p.pointP) 
      }
      if (labelFeatureTypes.line) {
        this._addLine(mapProps, style, measureLabels, p.lineT)
        this._addLine(mapProps, style, measureLabels, p.lineP)  
      }
      if (labelFeatureTypes.area) {
        this._addArea(mapProps, style, measureLabels, p.areaT)
        this._addArea(mapProps, style, measureLabels, p.areaP)  
      }
    }
    
    if (measureLabels.length > 0) {
      // we assume that labels were gathered externally and passed in
    }
    if (Array.isArray(props)) {
      props.forEach(p => addPropsToMeasureLabels(p))
    }
    else {
      addPropsToMeasureLabels(props)
    }

    if (measureLabels.length === 0) {
      const emptyResults = {
        labelEngine: null,
        atlas: [],
      }
      return emptyResults
    }

    // highest priority first
    measureLabels.sort((a, b) => {
      const ap = a.priority ?? 1
      const bp = b.priority ?? 1
      if (ap > bp) return -1
      if (ap < bp) return 1
      return 0
    })

    // knowing a measureLabelIndex we need to find the corresponding label
    // in prepared[i].labels
    // measureIndexToPreparedIndex = { measureIndex: preparedIndex }
    // index back into `prepared.labels` from the `measureLabels` index space
    const measureIndexToPreparedIndex = {}
    const prepared = []
    for (let i = 0; i < this._atlas.length; i++) {
      const labels = []
      for (let im = 0; im < measureLabels.length; im++) {
        const label = measureLabels[im]
        if (i !== label.fontFamilyIndex) continue
        measureIndexToPreparedIndex[im] = labels.length
        labels.push(measureLabels[im])
      }
      prepared.push(this._atlas[i].prepare({ labels }))
    }

    for (let im = 0; im < measureLabels.length; im++) {
      const label = measureLabels[im]
      const preparedLabel = prepared[label.fontFamilyIndex].labels[measureIndexToPreparedIndex[im]]
      switch (label.type) {
        case 'point':
          this._measurePoint(mapProps, prepared[label.fontFamilyIndex], preparedLabel)
          break;
        case 'line':
          this._measureLine(mapProps, prepared[label.fontFamilyIndex], preparedLabel)
          break;
        case 'area':
          this._measureArea(mapProps, prepared[label.fontFamilyIndex], preparedLabel)
          break;
        default:
          throw new Error('implement measure for type=', label.type)
      }
      Object.assign(label, preparedLabel)
    }

    const placedLabels = [{ type: 'bbox', bounds: mapProps.viewbox }].concat(measureLabels)
    this._labelEngine.update(placedLabels)

    const ilabels = []
    const idLabels = {}
    const atlasTypes = new Set(['point', 'line', 'area'])
    const positionMap = new Uint32Array(this._labelEngine.data.positions.length)
    let pindex = 0
    for (let i = 1; i < placedLabels.length; i++) {
      // prepared.labels index is i - 1
      const pi = i - 1
      const l = measureLabels[pi]
      if (!atlasTypes.has(l.type)) continue
      idLabels[l.id] = l
      ilabels[l.id] = i

      const preparedLabelIndex = measureIndexToPreparedIndex[pi]
      prepared[l.fontFamilyIndex].labels[preparedLabelIndex].isVisible = this._labelEngine.isVisible(i) ? 1 : 0
     
      // TODO when moving to instanced data, we will need to scale
      // `labelEngine.data.{positions,cells}` into individual glyph level
      // of props
      const pstart = this._labelEngine.offsets.positions[i * 2 + 0]
      const pend = this._labelEngine.offsets.positions[i * 2 + 1]
      const psize = pend-pstart
      for (let k = 0; k < psize; k++) {
        positionMap[(pstart + k) * 2 + 0] = i
        positionMap[(pstart + k) * 2 + 1] = pindex
        pindex++
      }
      const positions = this._labelEngine.data.positions.slice(pstart, pend)
      prepared[l.fontFamilyIndex].labels[preparedLabelIndex].positions = positions
      for (let k = 0; k < l.glyphIndicies.length; k++) {
        const gi = l.glyphIndicies[k]
        prepared[l.fontFamilyIndex].glyphs[gi].isVisible = prepared[l.fontFamilyIndex].labels[preparedLabelIndex].isVisible
        prepared[l.fontFamilyIndex].glyphs[gi].positions = positions
      }
    }
    const csize = {}
    const cindex = {}
    for (let i = 0; i < this._labelEngine.data.cells.length; i++) {
      const c = this._labelEngine.data.cells[i]
      const labelEngineIndex = positionMap[c * 2 + 0]
      const pi = labelEngineIndex - 1
      if (csize[pi] === undefined) csize[pi] = 1
      else csize[pi]++
    }
    for (let i = 1; i < placedLabels.length; i++) {
      const pi = i - 1
      const l = measureLabels[pi]
      if(!l) continue
      const preparedLabelIndex = measureIndexToPreparedIndex[pi]
      prepared[l.fontFamilyIndex].labels[preparedLabelIndex].cells = new Uint32Array(csize[pi])
    }
    for (let i = 0; i < this._labelEngine.data.cells.length; i++) {
      const c = this._labelEngine.data.cells[i]
      const labelEngineIndex = positionMap[c * 2 + 0]
      const placedPositionIndex = positionMap[c * 2 + 1]
      const pi = labelEngineIndex - 1
      const l = measureLabels[pi]
      if (!l || l.isVisible < 0.5) continue
      if (cindex[pi] === undefined) cindex[pi] = 0
      const preparedLabelIndex = measureIndexToPreparedIndex[pi]
      prepared[l.fontFamilyIndex].labels[preparedLabelIndex].cells[cindex[pi]++] = placedPositionIndex
    }
    for (let i = 0; i < prepared.length; i++) {
      for (let pi = 0; pi < prepared[i].labels.length; pi++) {
        const l = prepared[i].labels[pi]
        for (let k = 0; k < l.glyphIndicies.length; k++) {
          const gi = l.glyphIndicies[k]
          prepared[i].glyphs[gi].cells = prepared[i].labels[pi].cells
        }
      }  
    }

    // TODO? consider label oritentation?
    
    const labelProps = {
      labelEngine: this._labelEngine,
      atlas: prepared,
    }

    return labelProps
  }
  _addPoint (mapProps, style, labels, p) {
    if (!p?.positions) return
    const zoom = Math.round(mapProps.zoom)
    for (let ix = 0; ix < p.id.length; ix++) {
      const id = p.id[ix]
      if (!p.labels.hasOwnProperty(id) || p.labels[id].length === 0) continue
      const text = this._getLabel(p.labels[id])
      const lon = p.positions[ix * 2 + 0]
      const lat = p.positions[ix * 2 + 1]
      if (mapProps.viewbox[0] > lon || lon > mapProps.viewbox[2]) continue
      if (mapProps.viewbox[1] > lat || lat > mapProps.viewbox[3]) continue
      const type = p.types[ix]

      // colors could be powered by the glsl texture?
      // sizes are useful here for calculating bbox size
      const {
        fillColor,
        fillOpacity,
        fontFamilyIndex,
        fontFamilyName,
        fontSize,
        priority,
        strokeWidth,
        strokeColor,
        strokeOpacity,
        pointSize,
      } = this.styleRead.label('point', type, zoom)

      if (fontSize === 0) continue

      labels.push({
        type: 'point',
        point: [lon, lat],
        pointSizePx: [pointSize, pointSize],
        id,
        text,
        fontFamilyIndex,
        fontFamilyName,
        fontSize,
        priority,
        strokeWidth,
        // TODO
        // add to style2png:start
        letterSpacing: 1.0,
        labelMarginPx: [10, 10],
        pointMarginPx: [10, 10],
        // add to style2png:end
        zindex: 2000,
        fillColor: fillColor.map(c => c/255).concat([fillOpacity/100]),
        strokeColor: strokeColor.map(c => c/255).concat([strokeOpacity/100]),
      })
    }
  }
  _addLine (mapProps, style, labels, p) {
    if (!p?.positions) return
    let start = 0
    let prev = null
    const zoom = Math.round(mapProps.zoom)
    for (let ix = 0; ix < p.id.length; ix++) {
      const id = p.id[ix]
      if ((prev === null || prev === id) && ix !== p.id.length - 1) {
        prev = id
        continue
      }
      if (!p.labels.hasOwnProperty(id) || p.labels[id].length === 0) {
        start = ix
        continue
      }
      const text = this._getLabel(p.labels[prev])
      prev = id
      if (text === null) continue
      const end = ix
      const positions = p.positions.slice(start * 2, end * 2 + 2)
      start = ix

      const type = p.types[ix]

      const {
        fillColor,
        fillOpacity,
        fontFamilyIndex,
        fontFamilyName,
        fontSize,
        priority,
        strokeWidth,
        strokeColor,
        strokeOpacity,
      } = this.styleRead.label('line', type, zoom)

      if (fontSize === 0) continue

      labels.push({
        type: 'line',
        text,
        positions,
        fontFamilyIndex,
        fontFamilyName,
        fontSize,
        priority,
        strokeWidth,
        // add to style2png:start
        letterSpacing: 1.0,
        labelMarginPx: [0, 0],
        labelLineMarginPx: [0, 0],
        // add to style2png:end
        zindex: 2000,
        // TODO move colors to glsl
        fillColor: fillColor.map(c => c/255).concat([fillOpacity/100]),
        strokeColor: strokeColor.map(c => c/255).concat([strokeOpacity/100]),
      })
    }
  }
  _addArea (mapProps, style, labels, p) {
    if (!p?.positions) return
    let start = 0
    let prev = null
    const zoom = Math.round(mapProps.zoom)
    for (let ix = 0; ix < p.id.length; ix++) {
      const id = p.id[ix]
      if ((prev === null || prev === id) && ix !== p.id.length - 1) {
        prev = id
        continue
      }
      if (!p.labels.hasOwnProperty(id) || p.labels[id].length === 0) {
        start = ix
        prev = id
        continue
      }

      const labelId = prev
      const text = this._getLabel(p.labels[labelId])
      prev = id
      if (text === null) continue
      const end = ix
      const vb = mapProps.viewbox
      const positions = p.positions.slice(start * 2, end * 2 + 2)
      start = ix

      const type = p.types[ix]

      const {
        fillColor,
        fillOpacity,
        fontFamilyIndex,
        fontFamilyName,
        fontSize,
        priority,
        strokeWidth,
        strokeColor,
        strokeOpacity,
      } = this.styleRead.label('area', type, zoom)

      if (fontSize === 0) continue

      labels.push({
        type: 'area',
        text,
        positions,
        id,
        fontFamilyIndex,
        fontFamilyName,
        fontSize,
        priority,
        strokeWidth,
        // add to style2png:start
        letterSpacing: 1.0,
        labelMarginPx: [0, 0],
        // add to style2png:end
        zindex: 2000,
        fillColor: fillColor.map(c => c/255).concat([fillOpacity/100]),
        strokeColor: strokeColor.map(c => c/255).concat([strokeOpacity/100]),
      })
    }
  }
  _measurePoint (mapProps, prepared, label, { pw=2, ph=2 }={}) {
    // add the following to each `label`:
    // - widthPx
    // - heightPx
    // - labelSize
    // - labelMargin
    // - pointSize
    // - pointMargin
    // ? scale
    // ? labelSizeScale
    // ? labelMarginScale
    // ? pointMarginScale
    // ? pointSizeScale
    // ? pointScale
    const { glyphIndicies } = label
    const {
      labelDim,
      point,
      fontSize,
      letterSpacing,
    } = prepared.glyphs[glyphIndicies[0]]
    const pxToLon = (mapProps.viewbox[2] - mapProps.viewbox[0]) / mapProps.size[0]
    const pxToLat = (mapProps.viewbox[3] - mapProps.viewbox[1]) / mapProps.size[1]
    const aspect = mapProps.size[0]/mapProps.size[1]

    const widthPx = label.widthPx = fontSize * labelDim[0] * letterSpacing / labelDim[1]
    const heightPx = label.heightPx = fontSize
    const widthLon = (widthPx + pw + 1) * pxToLon
    const heightLat = (heightPx + ph + 1) * pxToLat / aspect

    label.labelSize = [widthLon, heightLat]
    label.labelMargin = [
      label.labelMarginPx[0] * pxToLon,
      label.labelMarginPx[1] * pxToLat,
    ]
    label.pointSize = [
      label.pointSizePx[0] * pxToLon,
      label.pointSizePx[1] * pxToLat,
    ]
    label.pointMargin = [
      label.pointMarginPx[0] * pxToLon,
      label.pointMarginPx[1] * pxToLat,
    ]
  }
  _measureLine (mapProps, prepared, label, { pw=2, ph=2 }={}) {
    // add the following to each `label`:
    // - widthPx
    // - heightPx
    // - labelSize
    // - labelMargin
    // - labelLineMargin
    // ? scale
    // ? labelSizeScale
    // ? labelMarginScale
    // ? labelLineMarginScale
    const { glyphIndicies } = label
    const {
      labelDim,
      point,
      fontSize,
      letterSpacing,
    } = prepared.glyphs[glyphIndicies[0]]

    const pxToLon = (mapProps.viewbox[2] - mapProps.viewbox[0]) / mapProps.size[0]
    const pxToLat = (mapProps.viewbox[3] - mapProps.viewbox[1]) / mapProps.size[1]
    const aspect = mapProps.size[0]/mapProps.size[1]

    const widthPx = label.widthPx = fontSize * labelDim[0] * letterSpacing / labelDim[1]
    const heightPx = label.heightPx = fontSize
    const widthLon = (widthPx + pw + 1) * pxToLon
    const heightLat = (heightPx + ph + 1) * pxToLat / aspect

    label.labelSize = [widthLon, heightLat]
    label.labelMargin = [
      label.labelMarginPx[0] * pxToLon,
      label.labelMarginPx[1] * pxToLat,
    ]
    label.labelLineMargin = [
      label.labelLineMarginPx[0] * pxToLon,
      label.labelLineMarginPx[1] * pxToLat,
    ]
  }
  _measureArea (mapProps, prepared, label, { pw=2, ph=2 }={}) {
    // add the following to each `label`:
    // - widthPx
    // - heightPx
    // - labelSize
    // - labelMargin
    // ? scale
    // ? positionsScale
    // ? labelSizeScale
    // ? labelMarginScale
    const { glyphIndicies } = label
    const {
      labelDim,
      point,
      fontSize,
      letterSpacing,
    } = prepared.glyphs[glyphIndicies[0]]

    const pxToLon = (mapProps.viewbox[2] - mapProps.viewbox[0]) / mapProps.size[0]
    const pxToLat = (mapProps.viewbox[3] - mapProps.viewbox[1]) / mapProps.size[1]
    const aspect = mapProps.size[0]/mapProps.size[1]

    const widthPx = label.widthPx = fontSize * labelDim[0] * letterSpacing / labelDim[1]
    const heightPx = label.heightPx = fontSize
    const widthLon = (widthPx + pw + 1) * pxToLon
    const heightLat = (heightPx + ph + 1) * pxToLat / aspect

    label.labelSize = [widthLon, heightLat]
    label.labelMargin = [
      label.labelMarginPx[0] * pxToLon,
      label.labelMarginPx[1] * pxToLat,
    ]
  }
  _getLabel (labels) {
    if (!labels) return null
    const best = {
      score: 0,
      text: null,
    }
    let btext = null
    for (let i = 0; i < labels.length; i++) {
      const m = /^([^=]*)=(.*)/.exec(labels[i])
      if (!m) continue
      const [_, lang, text] = m
      let score = 0
      if (lang === 'en') score += 3
      else if (lang === '') score += 2
      else if (lang === 'alt') score += 1
      if (score > best.score) {
        best.score = score
        best.text = text
      }
    }
    return best.text
  }
}

function findOffset (x, y, imageWidth) {
  return (x + imageWidth * y) * 4
}