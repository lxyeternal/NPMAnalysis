import { Label } from '@/src/label'

let labels

export default function labelWorker (self) {
  self.onmessage = (msg) => {
    const { type } = msg.data
    if (type === 'initialize') {
      const options = msg.data.payload
      labels = new Label(options)
      self.postMessage({ type: 'initialize', status: true })
    }
    else if (type === 'update') {
      const options = msg.data.options
      const labelProps = labels.update(...options)
      if (labelProps?.labelEngine) {
        delete labelProps.labelEngine
      }
      self.postMessage({ type: 'update', labelProps })
    }
  }
}
