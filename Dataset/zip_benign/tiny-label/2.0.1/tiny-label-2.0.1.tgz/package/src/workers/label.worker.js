import { Label } from '@/src/label'

let labels

onmessage = (msg) => {
  const { type } = msg.data
  if (type === 'initialize') {
    const options = msg.data.options
    labels = new Label(options)
    postMessage({ type: 'initialize', status: true })
  }
  else if (type === 'update') {
    const options = msg.data.options
    const labelProps = labels.update(...options)
    if (labelProps?.labelEngine) {
      delete labelProps.labelEngine
    }
    postMessage({ type: 'update', labelProps })
  }
}
