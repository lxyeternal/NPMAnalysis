export {
  createGlyphProps,
  defaultLabelOpts,
  Label,
  propsIncludeLabels,
  updateOptions,
} from '@/src/label'
export { Shaders } from '@/src/shaders'
import LabelPropsWorker from '@/src/workers/label.worker.js'
export { LabelPropsWorker }