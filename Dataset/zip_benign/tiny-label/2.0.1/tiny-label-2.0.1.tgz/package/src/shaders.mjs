export const Shaders = (map) => {
  return {
    outlines: {
      primitive: 'lines',
      lineWidth: 1,
      attributes: {
        position: (context, props) => props.data.outlines,
      },
      uniforms: {
        aspect: (context) => context.viewportWidth / context.viewportHeight,
        viewbox: map.prop('viewbox'),
        offset: map.prop('offset'),
        zindex: map.prop('zindex'),
        color: map.prop('color'),
      },
      count: (context, props) => props.count.outlines,
      vert: `
        precision highp float;
        attribute vec2 position;
        uniform float zindex;
        uniform float aspect;
        uniform vec2 offset;
        uniform vec4 viewbox;
        void main() {
          vec2 p = position.xy + offset;
          gl_Position = vec4(
            (p.x - viewbox.x) / (viewbox.z - viewbox.x) * 2.0 - 1.0,
            ((p.y - viewbox.y) / (viewbox.w - viewbox.y) * 2.0 - 1.0) * aspect,
            1.0/(1.0 + zindex),
            1.0
          );
        }
      `,
      frag: `
        precision highp float;
        uniform vec3 color;
        void main() {
          gl_FragColor = vec4(color,1.0);
        }
      `,
    },
    label: {
      attributes: {
        position: map.prop('positions'),
        uv: [0,0, 1,0, 1,1, 0,1],
      },
      elements: [0, 1, 2, 0, 2, 3],
      primitive: "triangles",
      uniforms: {
        baselineOffset: map.prop('atlasBaselineOffset'),
        glyphsTexture: map.prop('atlasGlyphsTexture'),
        buffer: map.prop('buffer'),
        color: map.prop('color'),
        gamma: map.prop('gamma'),
        glyphInLabelStringOffset: map.prop('glyphInLabelStringOffset'),
        glyphRasterDim: map.prop('glyphRasterDim'),
        glyphRasterTop: map.prop('glyphRasterTop'),
        glyphTexDim: map.prop('glyphTexDim'),
        glyphTexOffset: map.prop('glyphTexOffset'),
        isVisible: map.prop('isVisible'),
        labelDim: map.prop('labelDim'),
        letterSpacing: map.prop('letterSpacing'),
        labelTexDim: map.prop('atlasGlyphsTextureDim'),
        viewport: (context) => [context.viewportWidth, context.viewportHeight],
        zindex: map.prop('zindex'),
        // map-uniforms:start
        aspect: (context) => context.viewportWidth / context.viewportHeight,
        viewbox: map.prop('viewbox'),
        offset: map.prop('offset'),
        // map-uniforms:end
      },
      vert: `
        precision highp float;
        attribute vec2 position;
        attribute vec2 uv;

        // map-uniforms:start
        uniform float aspect;
        uniform vec2 offset;
        uniform vec4 viewbox;
        // map-uniforms:end
        
        uniform vec2 baselineOffset;
        uniform vec2 glyphInLabelStringOffset;
        uniform vec2 glyphRasterDim;
        uniform float glyphRasterTop;
        uniform vec2 glyphTexDim;
        uniform vec2 glyphTexOffset;
        uniform vec2 labelDim;
        uniform float letterSpacing;
        uniform vec2 labelTexDim;
        uniform vec2 viewport;
        uniform float zindex;

        varying vec4 vGlyphOffset;
        varying vec2 vGlyphTexOffset;
        varying vec2 vGlyphTexDim;
        varying vec2 vLabelTexDim;
        varying vec2 vUv;

        void main() {
          /// glyphOffset
          /// .x = x offset into label
          /// .y = x offset + x width into label
          /// .z = y baseline top offset
          /// .w = y baseline bottom offset
          vec4 glyphOffset = vec4(
            glyphInLabelStringOffset.x / labelDim.x * letterSpacing,
            (glyphInLabelStringOffset.x / labelDim.x * letterSpacing) + (glyphRasterDim.x / labelDim.x),
            (glyphRasterTop - baselineOffset.y) / labelDim.y,
            (glyphRasterTop - baselineOffset.y - glyphRasterDim.y) / labelDim.y
          );

          vec2 p = position + offset;
          gl_Position = vec4(
            (p.x - viewbox.x) / (viewbox.z - viewbox.x) * 2.0 - 1.0,
            ((p.y - viewbox.y) / (viewbox.w - viewbox.y) * 2.0 - 1.0) * aspect,
            1.0/(1.0 + zindex),
            1.0
          );

          vGlyphOffset = glyphOffset;
          vUv = uv;
          vGlyphTexOffset = glyphTexOffset;
          vGlyphTexDim = glyphTexDim;
          vLabelTexDim = labelTexDim;
        }
      `,
      frag: `
        precision highp float;
        uniform sampler2D glyphsTexture;
        uniform float buffer, gamma;
        uniform float isVisible;
        uniform vec4 color;

        varying vec4 vGlyphOffset;
        varying vec2 vGlyphTexOffset;
        varying vec2 vGlyphTexDim;
        varying vec2 vLabelTexDim;
        varying vec2 vUv;

        // https://github.com/msfeldstein/glsl-map/blob/master/index.glsl
        vec2 map (vec2 value, vec2 inMin, vec2 inMax, vec2 outMin, vec2 outMax) {
          return outMin + (outMax - outMin) * (value - inMin) / (inMax - inMin);
        }

        void main () {
          float drawGlyph = step(vGlyphOffset.x, vUv.x) * step(vUv.x, vGlyphOffset.y);
          if (drawGlyph < 0.5) {
            discard;
          }
          // the vUv spans the entire label position space, and we only want to account
          // for an individual glyph, so we map our glyph offsets within the label space
          // onto a normalized uv range, and use that to sample our glyphs texture
          vec2 uv = map(vUv, vGlyphOffset.xz, vGlyphOffset.yw, vec2(0.0), vec2(1.0));
          uv = clamp(uv, vec2(0.0), vec2(1.0));
          vec2 tcoord = (vGlyphTexOffset + (vGlyphTexDim * uv)) / vLabelTexDim;
          float dist = texture2D(glyphsTexture, tcoord).a;

          float alpha = smoothstep(buffer - gamma, buffer + gamma, dist);
          gl_FragColor = color * alpha;
        }
      `,
      depth: { enable: false },
      blend: {
        enable: true,
        func: {
          src: 'src alpha',
          dst: 'one minus src alpha'
        }
      },
    },
  }
}
