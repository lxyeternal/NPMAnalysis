import aliasPlugin from 'esbuild-plugin-path-alias'
import inlineWorkerPlugin from 'esbuild-plugin-inline-worker'

const alias = aliasPlugin({
  '@': process.cwd(),
})

export const esm = {
  entryPoints: ['src/index.mjs', 'src/workers/label.mjs'],
  globalName: 'TinyLabel',
  target: 'es6',
  bundle: true,
  format: 'esm',
  outdir: 'dist',
  outExtension: { '.js': '.mjs' },
  plugins: [
    alias,
    inlineWorkerPlugin({ plugins: [alias] }),
  ],
}

export default esm

export const cjs = {
  ...esm,
  format: 'cjs',
  outExtension: { '.js': '.cjs' },
}
