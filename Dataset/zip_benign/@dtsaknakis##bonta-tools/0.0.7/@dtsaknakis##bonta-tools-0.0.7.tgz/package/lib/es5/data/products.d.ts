export declare type Brand = {
    name: string;
    unitsPerVial: number;
    company: string;
};
export declare const products: Array<Brand>;
