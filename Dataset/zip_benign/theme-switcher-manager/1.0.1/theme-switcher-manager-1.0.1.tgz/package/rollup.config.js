import typescript from 'rollup-plugin-typescript2'; // 用于处理 TypeScript
import resolve from '@rollup/plugin-node-resolve';   // 用于处理 node_modules 中的依赖
import commonjs from '@rollup/plugin-commonjs';      // 用于处理 CommonJS 模块
import { minify } from 'rollup-plugin-esbuild';      // 确保正确导入 esbuild 插件

export default {
  input: 'src/index.ts',  // 项目的入口文件
  output: [
    {
      file: 'dist/themeManager.cjs.js', // CommonJS 格式的输出
      format: 'cjs',
      sourcemap: true, // 生成 source map 文件
    },
    {
      file: 'dist/themeManager.js', // ES模块格式的输出
      format: 'esm',
      sourcemap: true,
    },
    {
      file: 'dist/themeManager.umd.js', // UMD 格式的输出（兼容浏览器）
      format: 'umd',
      name: 'themeManager',  // UMD 格式需要一个全局变量名
      sourcemap: true,
    },
  ],
  plugins: [
    resolve(),                  // 使 Rollup 能够找到外部依赖
    commonjs(),                 // 将 CommonJS 模块转换为 ES6 模块
    typescript({                // 使用 TypeScript 插件
      tsconfig: './tsconfig.json',  // 使用自定义的 tsconfig.json 文件
    }),
    minify({                    // 使用 esbuild 进行代码压缩
      minify: true,              // 开启压缩
      target: 'es2015',          // 设置目标 ECMAScript 版本
    }),
  ],
  external: ['some-external-library'],  // 如果有外部依赖需要排除，可以在此声明
  watch: {
    include: 'src/**',          // 监控 src 目录中的文件
  },
};