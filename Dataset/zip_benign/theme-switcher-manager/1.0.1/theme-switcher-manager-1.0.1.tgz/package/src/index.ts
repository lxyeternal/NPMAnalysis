import useThemeManager from './themeManager';

export default useThemeManager;
