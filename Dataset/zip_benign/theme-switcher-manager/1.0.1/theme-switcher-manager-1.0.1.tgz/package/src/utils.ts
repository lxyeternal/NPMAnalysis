export function autoDetectTheme(themes: Record<string, any>, currentTheme: string): string {
    const htmlTheme = document.documentElement.getAttribute("data-theme");
    const savedTheme = localStorage.getItem("theme");

    if (htmlTheme && themes[htmlTheme]) {
        return htmlTheme;
    }

    if (savedTheme && themes[savedTheme]) {
        return savedTheme;
    }

    return currentTheme;
}
