import { Theme, Themes, ThemeManager } from './theme';
import { autoDetectTheme } from './utils';

let themes: Themes = {
    light: {
        "--background-color": "#ffffff",       // 背景颜色
        "--text-color": "#303133",             // 主体文字颜色，调整为Element UI偏深的灰色
        "--primary-color": "#409EFF",          // 主色调改为 Element UI 蓝色
        "--secondary-color": "#545c64",        // 次要色调，调整为 Element UI 的灰色
        "--border-color": "#DCDFE6",           // 边框色调更接近Element UI的边框颜色
        "--accent-color": "#ff6600",           // 点缀色仍保持活泼，但可以考虑更为中性一些
        "--success-color": "#67C23A",          // 成功状态色，更接近 Element UI 的绿色
        "--warning-color": "#E6A23C",          // 警告状态色调整为更温暖的橙色
        "--error-color": "#F56C6C",            // 错误状态色更接近 Element UI 的红色
        "--shadow-color": "rgba(0, 0, 0, 0.1)", // 阴影色更柔和
    },
    dark: {
        "--background-color": "#121212",       // 背景颜色为深色
        "--text-color": "#ffffff",             // 文字颜色白色
        "--primary-color": "#bb86fc",          // 主色调使用 Element UI 的紫色
        "--secondary-color": "#03DAC6",        // 次要色调使用 Element UI 的青色
        "--border-color": "#333333",           // 边框颜色调整为深色
        "--accent-color": "#ff4081",           // 点缀色仍使用较为明亮的粉色，但可以更为简约
        "--success-color": "#4caf50",          // 成功状态色为 Element UI 的绿色
        "--warning-color": "#ffeb3b",          // 警告状态色为 Element UI 的黄色
        "--error-color": "#f44336",            // 错误状态色为 Element UI 的红色
        "--shadow-color": "rgba(0, 0, 0, 0.7)", // 阴影更深
    },
};

let currentTheme = 'light';
const eventListeners: Array<(theme: string) => void> = [];

const loadThemesFromJSON = async (url: string): Promise<void> => {
    try {
        const response = await fetch(url);
        const newThemes = await response.json();
        if (newThemes.light) themes.light = newThemes.light;
        if (newThemes.dark) themes.dark = newThemes.dark;
        Object.assign(themes, newThemes);
        console.log("✅ 主题已加载:", Object.keys(newThemes));

        const savedTheme = localStorage.getItem("theme");
        if (savedTheme && themes[savedTheme]) {
            switchTheme(savedTheme);
        } else {
            switchTheme(currentTheme);
        }
    } catch (error) {
        console.error("❌ 加载 JSON 失败:", error);
    }
};

const switchTheme = (themeName: string): void => {
    if (!themes[themeName]) {
        console.warn(`⚠️ 主题 "${themeName}" 不存在`);
        return;
    }
    currentTheme = themeName;
    localStorage.setItem("theme", themeName);
    document.documentElement.setAttribute("data-theme", themeName);
    applyTheme();
    notifyThemeChange();
};

const onThemeChange = (callback: (theme: string) => void): void => {
    eventListeners.push(callback);
};

const setThemeVariable = (variable: string, value: string): void => {
    document.documentElement.style.setProperty(variable, value);
};

const addThemeVariable = (themeName: string, variable: string, value: string): void => {
    const updatedThemes = { ...themes };  // 创建一个新对象，保持原始对象不变

    if (!updatedThemes[themeName]) {
        updatedThemes[themeName] = {};  // 如果该主题不存在，创建一个新的对象
    }

    updatedThemes[themeName] = {
        ...updatedThemes[themeName],  // 保留原有的变量不变
        [variable]: value  // 更新或添加新的变量
    };

    themes = updatedThemes;

    // 立即应用更新后的主题
    applyTheme();
};

const applyTheme = (): void => {
    const theme = themes[currentTheme];
    const root = document.documentElement;
    for (const key in theme) {
        root.style.setProperty(key, theme[key]);
    }
};

const notifyThemeChange = (): void => {
    eventListeners.forEach(callback => callback(currentTheme));
};

const useThemeManager = (): ThemeManager => {
    const theme = autoDetectTheme(themes, currentTheme);
    currentTheme = theme;
    applyTheme();

    return {
        themes,
        currentTheme,
        eventListeners,
        loadThemesFromJSON,
        switchTheme,
        onThemeChange,
        setThemeVariable,
        addThemeVariable,
        applyTheme
    };
};

export default useThemeManager;
