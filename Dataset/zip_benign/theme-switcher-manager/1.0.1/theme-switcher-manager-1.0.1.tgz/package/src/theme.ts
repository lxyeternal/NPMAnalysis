export type Theme = Record<string, string>;
export type Themes = Record<string, Theme>;
export interface ThemeManager {
    themes: Record<string, Record<string, string>>;
    currentTheme: string;
    eventListeners: Array<(theme: string) => void>;
    loadThemesFromJSON: (url: string) => Promise<void>;
    switchTheme: (themeName: string) => void;
    onThemeChange: (callback: (theme: string) => void) => void;
    setThemeVariable: (variable: string, value: string) => void;
    addThemeVariable: (themeName: string, variable: string, value: string) => void;
    applyTheme: () => void;
}
