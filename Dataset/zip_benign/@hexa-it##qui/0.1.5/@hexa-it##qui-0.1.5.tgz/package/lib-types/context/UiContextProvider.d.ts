import { UiContext } from "./uiContext";
import "./main.scss";
export declare const UiContextProvider: import("@builder.io/qwik").Component<UiContext>;
