export type UiContext = {
    locale?: string;
    strings?: {
        nothingFound?: string;
        selectFile?: string;
        selectFiles?: string;
    };
};
export declare const UiContext: import("@builder.io/qwik").ContextId<UiContext>;
