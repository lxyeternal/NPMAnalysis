import { QwikIntrinsicElements } from "@builder.io/qwik";
import { QuiColor, QuiSize } from "~/internal";
export type SegmentsIntrinsic = {
    overlay?: QwikIntrinsicElements["span"];
    segment?: QwikIntrinsicElements["button"];
};
export type SegmentsData = {
    label: string;
    value: string;
    disabled?: boolean;
};
export type SegmentsProps = QwikIntrinsicElements["div"] & {
    intrinsic?: SegmentsIntrinsic;
    data: SegmentsData[];
    size?: QuiSize;
    color?: QuiColor;
    value?: string;
    onChange$?: (value: string) => void;
    orientation?: "horizontal" | "vertical";
    disabled?: boolean;
};
export declare const Segments: import("@builder.io/qwik").Component<SegmentsProps>;
