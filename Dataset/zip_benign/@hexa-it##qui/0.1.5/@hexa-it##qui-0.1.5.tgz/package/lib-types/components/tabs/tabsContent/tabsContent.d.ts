import { type QwikIntrinsicElements } from "@builder.io/qwik";
export type TabsContentProps = QwikIntrinsicElements["div"] & {
    value: string;
};
export declare const TabsContent: import("@builder.io/qwik").Component<TabsContentProps>;
