import { type QuiSize, QuiColor } from "~/internal";
import { type QwikIntrinsicElements } from "@builder.io/qwik";
export type LoaderVariants = "dots" | "ring";
export type LoaderColors = "current" | QuiColor;
export type LoaderProps = QwikIntrinsicElements["div"] & {
    size?: QuiSize;
    color?: LoaderColors;
    variant?: LoaderVariants;
};
export declare const Loader: import("@builder.io/qwik").Component<LoaderProps>;
