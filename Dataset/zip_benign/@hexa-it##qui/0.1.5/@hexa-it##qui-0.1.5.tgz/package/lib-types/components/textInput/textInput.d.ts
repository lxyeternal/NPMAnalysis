import { type Signal } from "@builder.io/qwik";
import { type InputWrapperProps, type InputProps } from "~/internal";
export type TextInputIntrinsic = {
    input?: InputProps;
};
export type TextInputProps = InputWrapperProps & {
    intrinsic?: TextInputIntrinsic;
    value?: string;
    autoFocus?: boolean;
    name?: string;
    placeholder?: string;
    onChange$?: (value: string) => void;
    ref?: Signal<HTMLInputElement | undefined>;
};
export declare const TextInput: import("@builder.io/qwik").Component<TextInputProps>;
