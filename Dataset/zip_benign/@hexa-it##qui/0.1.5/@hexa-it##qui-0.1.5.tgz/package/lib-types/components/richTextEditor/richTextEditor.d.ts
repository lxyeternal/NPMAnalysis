import { type InputWrapperProps } from "~/internal";
export type RichTextEditorProps = InputWrapperProps & {
    value?: string;
    onChange$?: (value: string) => void;
    autoFocus?: boolean;
    placeholder?: string;
};
export declare const RichTextEditor: import("@builder.io/qwik").Component<RichTextEditorProps>;
