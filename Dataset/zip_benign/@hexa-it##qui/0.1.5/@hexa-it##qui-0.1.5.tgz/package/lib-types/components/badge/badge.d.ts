import { type QwikIntrinsicElements } from "@builder.io/qwik";
import { QuiColor, QuiSize } from "~/internal";
export type BadgeIntrinsic = {
    dot?: QwikIntrinsicElements["div"];
    inner?: QwikIntrinsicElements["div"];
};
export type BadgeVariants = "filled" | "light" | "outline" | "dot";
export type BadgeProps = QwikIntrinsicElements["div"] & {
    intrinsic?: BadgeIntrinsic;
    variant?: BadgeVariants;
    size?: QuiSize;
    color?: QuiColor;
    fullWidth?: boolean;
};
export declare const Badge: import("@builder.io/qwik").Component<BadgeProps>;
