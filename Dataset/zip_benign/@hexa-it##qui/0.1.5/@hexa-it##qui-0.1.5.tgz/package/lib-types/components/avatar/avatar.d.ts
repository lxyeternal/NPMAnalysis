import { type QwikIntrinsicElements } from "@builder.io/qwik";
import { QuiColor, QuiSize } from "~/internal";
export type AvatarIntrinsic = {
    icon?: QwikIntrinsicElements["div"];
    image?: QwikIntrinsicElements["img"];
};
export type AvatarProps = QwikIntrinsicElements["div"] & {
    intrinsic?: AvatarIntrinsic;
    size?: QuiSize;
    color?: QuiColor;
    content?: string;
};
export declare const Avatar: import("@builder.io/qwik").Component<AvatarProps>;
