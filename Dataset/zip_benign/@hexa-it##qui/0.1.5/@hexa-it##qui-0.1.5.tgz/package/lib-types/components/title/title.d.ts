import { type Component, type QwikIntrinsicElements } from "@builder.io/qwik";
export type TitleOrders = 1 | 2 | 3 | 4 | 5 | 6;
export type TitleProps = QwikIntrinsicElements["h1"] & {
    order?: TitleOrders;
};
export declare const Title: Component<TitleProps>;
