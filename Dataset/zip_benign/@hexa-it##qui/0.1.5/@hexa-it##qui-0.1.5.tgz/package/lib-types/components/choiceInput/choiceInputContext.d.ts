export type ChoiceContext = {
    disabled: boolean | undefined;
    id: string;
};
export declare const ChoiceContext: import("@builder.io/qwik").ContextId<ChoiceContext>;
