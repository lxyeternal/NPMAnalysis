import { type CloseIconProps, type InputWrapperProps } from "~/internal";
import { type DateInputProps } from "../dateInput";
import { type TimeInputProps } from "../timeInput";
export declare const dateToTimeString: (date: Date) => string;
export type DateTimeInputIntrinsic = {
    dateInput?: DateInputProps;
    timeInput?: TimeInputProps;
    closeIcon?: CloseIconProps;
};
export type DateTimeInputProps = InputWrapperProps & {
    intrinsic?: DateTimeInputIntrinsic;
    value?: Date | null;
    required?: boolean;
    onChange$?: (value: Date | null) => void;
};
export declare const DateTimeInput: import("@builder.io/qwik").Component<DateTimeInputProps>;
