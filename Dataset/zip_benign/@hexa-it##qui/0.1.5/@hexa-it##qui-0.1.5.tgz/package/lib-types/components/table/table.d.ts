export declare const Table: import("@builder.io/qwik").Component<import("@builder.io/qwik").TableHTMLAttributes<HTMLTableElement>>;
