import { QwikIntrinsicElements } from "@builder.io/qwik";
import { InputProps, InputWrapperProps, InputBase, QuiColor } from "~/internal";
import { type GroupProps } from "../group";
import { FloaterProps } from "../floater";
export type SelectValue = string | number;
export interface SelectOption {
    label: string;
    description?: string;
    value: SelectValue;
    group?: string;
}
export type SelectInputIntrinsic = {
    root: InputWrapperProps;
    multipleWrapper?: GroupProps;
    multipleItemWrapper?: QwikIntrinsicElements["div"];
    multipleItem?: QwikIntrinsicElements["div"];
    multipleItemDeleteIcon?: QwikIntrinsicElements["div"];
    option?: QwikIntrinsicElements["button"];
    optionLabel?: QwikIntrinsicElements["span"];
    optionDescription?: QwikIntrinsicElements["span"];
    input?: InputProps;
    icon?: QwikIntrinsicElements["div"];
    dropdown?: FloaterProps;
};
export type SelectInputProps = InputBase<SelectValue | SelectValue[] | null> & {
    intrinsic?: SelectInputIntrinsic;
    data: SelectOption[];
    color?: QuiColor;
    onSearch$?: (search: string) => void;
    multiple?: boolean;
};
export declare const SelectInput: import("@builder.io/qwik").Component<SelectInputProps>;
