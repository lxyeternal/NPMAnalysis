import { type Signal } from "@builder.io/qwik";
import { type InputWrapperProps, type InputProps, type CloseIconProps } from "~/internal";
export type TimeInputIntrinsic = {
    input?: InputProps;
    closeIcon?: CloseIconProps;
};
export type TimeInputProps = InputWrapperProps & {
    intrinsic?: TimeInputIntrinsic;
    value?: string;
    autoFocus?: boolean;
    name?: string;
    placeholder?: string;
    noIcon?: boolean;
    onChange$?: (value: string) => void;
    ref?: Signal<HTMLInputElement | undefined>;
};
export declare const TimeInput: import("@builder.io/qwik").Component<TimeInputProps>;
