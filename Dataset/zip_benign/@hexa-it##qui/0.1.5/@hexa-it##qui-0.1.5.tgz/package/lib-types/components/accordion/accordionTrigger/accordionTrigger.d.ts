import { type QwikIntrinsicElements } from "@builder.io/qwik";
export type AccordionTriggerProps = QwikIntrinsicElements["button"];
export declare const AccordionTrigger: import("@builder.io/qwik").Component<import("@builder.io/qwik").ButtonHTMLAttributes<HTMLButtonElement>>;
