import { type Signal } from "@builder.io/qwik";
import { type InputProps, type InputWrapperProps } from "~/internal";
export type NumberInputIntrinsic = {
    input?: InputProps;
};
export type NumberInputProps = InputWrapperProps & {
    intrinsic?: NumberInputIntrinsic;
    value?: number | null;
    autoFocus?: boolean;
    decimal?: boolean;
    name?: string;
    placeholder?: string;
    onChange$?: (value: number | null) => void;
    ref?: Signal<HTMLInputElement | undefined>;
};
export declare const NumberInput: import("@builder.io/qwik").Component<NumberInputProps>;
