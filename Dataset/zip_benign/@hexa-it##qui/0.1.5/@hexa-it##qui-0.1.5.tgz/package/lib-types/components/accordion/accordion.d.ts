import { type Component, type QwikIntrinsicElements } from "@builder.io/qwik";
import { AccordionItem } from "./accordionItem";
import { AccordionTrigger } from "./accordionTrigger";
import { AccordionContent } from "./accordionContent";
export type AccordionCompound = {
    Item: typeof AccordionItem;
    Trigger: typeof AccordionTrigger;
    Content: typeof AccordionContent;
};
export type AccordionProps = QwikIntrinsicElements["div"] & {
    multiple?: boolean;
};
export declare const Accordion: Component<AccordionProps> & AccordionCompound;
