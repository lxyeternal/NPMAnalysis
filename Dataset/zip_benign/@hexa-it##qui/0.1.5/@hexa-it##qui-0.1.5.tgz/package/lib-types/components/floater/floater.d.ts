import { type Signal, QwikIntrinsicElements, CSSProperties } from "@builder.io/qwik";
import { type Placement } from "@floating-ui/dom";
export type FloaterProps = QwikIntrinsicElements["div"] & {
    relativeRef?: Signal<HTMLElement | undefined>;
    position?: CSSProperties["position"];
    placement?: Placement;
    ref?: Signal<HTMLElement | undefined>;
};
export declare const Floater: import("@builder.io/qwik").Component<FloaterProps>;
