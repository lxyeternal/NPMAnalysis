import { type Signal } from "@builder.io/qwik";
import { type InputWrapperProps, type CloseIconProps, type InputProps } from "~/internal";
export type DateInputIntrinsic = {
    input?: InputProps;
    closeIcon?: CloseIconProps;
};
export type DateInputProps = InputWrapperProps & {
    intrinsic?: DateInputIntrinsic;
    value?: Date | null;
    autoFocus?: boolean;
    name?: string;
    placeholder?: string;
    onChange$?: (value: Date | null) => void;
    ref?: Signal<HTMLInputElement | undefined>;
    noIcon?: boolean;
};
export declare const dateToDateString: (date: Date) => string;
export declare const DateInput: import("@builder.io/qwik").Component<DateInputProps>;
