import { GroupProps } from "~/components/group";
export declare const ButtonGroup: import("@builder.io/qwik").Component<GroupProps>;
