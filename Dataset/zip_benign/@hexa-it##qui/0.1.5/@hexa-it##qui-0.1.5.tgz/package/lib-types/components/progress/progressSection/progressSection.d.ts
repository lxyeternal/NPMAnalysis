import { QwikIntrinsicElements } from "@builder.io/qwik";
import { type QuiColor } from "~/internal";
export type Section = {
    value: number;
    color?: QuiColor;
    label?: string;
};
export type ProgressSectionProps = QwikIntrinsicElements["div"];
export declare const ProgressSection: import("@builder.io/qwik").Component<import("@builder.io/qwik").HTMLAttributes<HTMLDivElement> & Section>;
