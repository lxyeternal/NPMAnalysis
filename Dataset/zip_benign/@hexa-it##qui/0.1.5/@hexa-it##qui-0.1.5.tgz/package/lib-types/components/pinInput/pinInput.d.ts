import { type InputWrapperProps, type InputProps } from "~/internal";
export type PinInputIntrinsic = {
    input?: InputProps;
};
export type PinInputProps = InputWrapperProps & {
    intrinsic?: PinInputIntrinsic;
    length?: number;
    value?: string;
    autoFocus?: boolean;
    name?: string;
    placeholder?: string;
    onChange$?: (value: string) => void;
};
export declare const PinInput: import("@builder.io/qwik").Component<PinInputProps>;
