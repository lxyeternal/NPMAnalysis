import { type QwikIntrinsicElements } from "@builder.io/qwik";
import { QuiSize } from "~/internal";
export type ColorSwatchProps = Omit<QwikIntrinsicElements["div"], "color"> & {
    color: string;
    size?: QuiSize;
};
export declare const ColorSwatch: import("@builder.io/qwik").Component<ColorSwatchProps>;
