import { QwikIntrinsicElements } from "@builder.io/qwik";
import type { JSX } from "@builder.io/qwik/jsx-runtime";
import { type CloseIconProps, QuiColor } from "~/internal";
import { GroupProps } from "../group";
import { LoaderProps } from "../loader";
export type NotificationIntrinsic = {
    iconWrapper?: QwikIntrinsicElements["div"];
    header?: GroupProps;
    loader?: LoaderProps;
    title?: QwikIntrinsicElements["p"];
    closeIcon?: CloseIconProps;
};
export type NotificationProps = QwikIntrinsicElements["div"] & {
    intrinsic?: NotificationIntrinsic;
    title?: string;
    color?: QuiColor;
    icon?: JSX.Element;
    loading?: boolean;
    onClose$?: () => void;
};
export declare const Notification: import("@builder.io/qwik").Component<NotificationProps>;
