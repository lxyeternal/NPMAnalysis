import { ChoiceOption, ChoiceValue } from "../types";
export type RadioProps = {
    option: ChoiceOption;
    value?: ChoiceValue | null;
    onChange$?: (value: ChoiceValue) => void;
    invalid?: boolean;
};
export declare const Radio: import("@builder.io/qwik").Component<RadioProps>;
