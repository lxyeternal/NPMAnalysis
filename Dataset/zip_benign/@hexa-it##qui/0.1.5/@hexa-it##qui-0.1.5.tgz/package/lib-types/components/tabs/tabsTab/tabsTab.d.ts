import { type QwikIntrinsicElements } from "@builder.io/qwik";
export type TabsTabProps = QwikIntrinsicElements["button"] & {
    value: string;
    disabled?: boolean;
};
export declare const TabsTab: import("@builder.io/qwik").Component<TabsTabProps>;
