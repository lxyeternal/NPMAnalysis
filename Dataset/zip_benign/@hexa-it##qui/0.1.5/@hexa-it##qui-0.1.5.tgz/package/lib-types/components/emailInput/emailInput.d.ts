import { type Signal } from "@builder.io/qwik";
import { type InputWrapperProps, type InputProps } from "~/internal";
export type EmailInputIntrinsic = {
    input?: InputProps;
};
export type EmailInputProps = InputWrapperProps & {
    intrinsic?: EmailInputIntrinsic;
    value?: string;
    autoFocus?: boolean;
    autoComplete?: boolean;
    name?: string;
    placeholder?: string;
    onChange$?: (value: string) => void;
    ref?: Signal<HTMLInputElement | undefined>;
};
export declare const EmailInput: import("@builder.io/qwik").Component<EmailInputProps>;
