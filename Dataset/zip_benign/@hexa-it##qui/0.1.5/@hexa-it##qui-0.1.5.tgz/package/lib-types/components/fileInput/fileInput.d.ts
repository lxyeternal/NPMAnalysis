import { type Signal, type QwikIntrinsicElements } from "@builder.io/qwik";
import { type InputProps, type CloseIconProps, type InputWrapperProps } from "~/internal";
export type FileInputIntrinsic = {
    input?: InputProps;
    button?: QwikIntrinsicElements["button"];
    closeIcon?: CloseIconProps;
};
export type FileInputProps = InputWrapperProps & {
    intrinsic?: FileInputIntrinsic;
    autoFocus?: boolean;
    name?: string;
    accept?: string;
    placeholder?: string;
    ref?: Signal<HTMLInputElement | undefined>;
    multiple?: boolean;
    required?: boolean;
    value?: File | FileList | null;
    onChange$?: (value: File | FileList | null) => void;
};
export declare const FileInput: import("@builder.io/qwik").Component<FileInputProps>;
