export * from "./tabsTab";
