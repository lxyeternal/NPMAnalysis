import { type CSSProperties, type QwikIntrinsicElements } from "@builder.io/qwik";
import { type QuiSize } from "~/internal";
export type GroupProps = QwikIntrinsicElements["div"] & {
    align?: CSSProperties["alignItems"];
    justify?: CSSProperties["justifyContent"];
    wrap?: CSSProperties["flexWrap"];
    gap?: QuiSize;
    grow?: boolean;
};
export declare const Group: import("@builder.io/qwik").Component<GroupProps>;
