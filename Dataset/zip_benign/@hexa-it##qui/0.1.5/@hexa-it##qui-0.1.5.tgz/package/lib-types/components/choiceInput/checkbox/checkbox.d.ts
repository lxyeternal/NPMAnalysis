import { ChoiceOption, ChoiceValue } from "../types";
export type CheckboxProps = {
    option: ChoiceOption;
    value?: ChoiceValue[];
    onChange$?: (value: ChoiceValue[]) => void;
    invalid?: boolean;
};
export declare const Checkbox: import("@builder.io/qwik").Component<CheckboxProps>;
