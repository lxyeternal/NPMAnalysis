import { type QwikIntrinsicElements } from "@builder.io/qwik";
export type TabsListProps = QwikIntrinsicElements["div"];
export declare const TabsList: import("@builder.io/qwik").Component<import("@builder.io/qwik").HTMLAttributes<HTMLDivElement>>;
