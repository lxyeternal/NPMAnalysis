import { type QwikIntrinsicElements } from "@builder.io/qwik";
import { QuiSize } from "~/internal";
import { type Section, type ProgressSectionProps } from "./progressSection";
type BaseProgressProps = QwikIntrinsicElements["div"] & {
    size?: QuiSize;
};
type WithSections = {
    sections: Section[];
    animated?: never;
    value?: never;
    color?: never;
    label?: never;
    intrinsic?: {
        sections?: (ProgressSectionProps | undefined)[];
    };
};
type WithoutSections = Section & {
    sections?: never;
    intrinsic?: {
        section?: ProgressSectionProps;
    };
    animated?: boolean;
};
export type ProgressProps = BaseProgressProps & (WithSections | WithoutSections);
export declare const Progress: import("@builder.io/qwik").Component<ProgressProps>;
export {};
