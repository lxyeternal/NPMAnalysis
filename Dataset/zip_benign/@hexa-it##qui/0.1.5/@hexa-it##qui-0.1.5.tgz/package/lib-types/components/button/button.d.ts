import { type QwikIntrinsicElements, type Component } from "@builder.io/qwik";
import { type QuiSize, QuiColor } from "~/internal";
import type { JSX } from "@builder.io/qwik/jsx-runtime";
import { LoaderProps } from "../loader";
import { ButtonGroup } from "./buttonGroup";
export type ButtonCompound = {
    Group: typeof ButtonGroup;
};
export type ButtonIntrinsic = {
    inner?: QwikIntrinsicElements["div"];
    loaderWrapper?: QwikIntrinsicElements["div"];
    loader?: LoaderProps;
};
export type ButtonVariants = "filled" | "light" | "outline";
export type ButtonProps = QwikIntrinsicElements["button"] & {
    intrinsic?: ButtonIntrinsic;
    size?: QuiSize;
    color?: QuiColor;
    variant?: ButtonVariants;
    icon?: JSX.Element;
    compact?: boolean;
    loading?: boolean;
    fullWidth?: boolean;
};
export declare const _Button: Component<ButtonProps> & ButtonCompound;
export declare const Button: Component<ButtonProps> & ButtonCompound;
