import { type Signal, QwikIntrinsicElements } from "@builder.io/qwik";
import { type InputWrapperProps } from "~/internal";
export type TextareaIntrinsic = {
    input?: QwikIntrinsicElements["textarea"];
};
export type TextareaProps = InputWrapperProps & {
    intrinsic?: TextareaIntrinsic;
    value?: string;
    autoFocus?: boolean;
    name?: string;
    rows?: number;
    onChange$?: (value: string) => void;
    ref?: Signal<HTMLInputElement | undefined>;
};
export declare const Textarea: import("@builder.io/qwik").Component<TextareaProps>;
