import { type QwikIntrinsicElements } from "@builder.io/qwik";
import { type PaperProps } from "../paper";
import { type ButtonProps } from "../button";
import { type TitleProps } from "../title";
import { StackProps } from "../stack";
export type SheetIntrinsic = {
    titleWrapper?: PaperProps;
    title?: TitleProps;
    button?: ButtonProps;
    icon?: QwikIntrinsicElements["div"];
    content?: PaperProps;
};
export type SheetProps = StackProps & {
    intrinsic?: SheetIntrinsic;
    title: string;
    showDefault?: boolean;
    glass?: boolean;
};
export declare const Sheet: import("@builder.io/qwik").Component<SheetProps>;
