import { type CSSProperties, type QwikIntrinsicElements } from "@builder.io/qwik";
import { type QuiSize } from "~/internal";
export type StackProps = QwikIntrinsicElements["div"] & {
    align?: CSSProperties["alignItems"];
    justify?: CSSProperties["justifyContent"];
    gap?: QuiSize;
};
export declare const Stack: import("@builder.io/qwik").Component<StackProps>;
