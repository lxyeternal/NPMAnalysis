import { type Signal } from "@builder.io/qwik";
export type TabsContext = {
    currentTab: Signal<string | undefined>;
    orientation: "horizontal" | "vertical";
};
export declare const TabsContext: import("@builder.io/qwik").ContextId<TabsContext>;
export declare const useTabsContext: () => TabsContext;
