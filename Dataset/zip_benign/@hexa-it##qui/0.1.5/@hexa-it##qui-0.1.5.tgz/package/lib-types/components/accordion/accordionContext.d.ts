export type AccordionContext = {
    items: Record<string, boolean>;
    multiple?: boolean;
};
export declare const AccordionContext: import("@builder.io/qwik").ContextId<AccordionContext>;
export declare const useAccordionContext: () => AccordionContext;
export type AccordionItemContext = {
    id: string;
};
export declare const AccordionItemContext: import("@builder.io/qwik").ContextId<AccordionItemContext>;
export declare const useAccordionItemContext: () => AccordionItemContext;
