import { QwikIntrinsicElements, type Signal } from "@builder.io/qwik";
import { type ColorSwatchProps } from "../colorSwatch";
import { CloseIconProps, type InputProps, type InputWrapperProps } from "~/internal";
export type ColorInputIntrinsic = {
    picker?: QwikIntrinsicElements["input"];
    input?: InputProps;
    swatch?: ColorSwatchProps;
    closeIcon?: CloseIconProps;
};
export type ColorInputProps = InputWrapperProps & {
    intrinsic?: ColorInputIntrinsic;
    value?: string;
    autoFocus?: boolean;
    name?: string;
    placeholder?: string;
    onChange$?: (value: string) => void;
    ref?: Signal<HTMLInputElement | undefined>;
};
export declare const ColorInput: import("@builder.io/qwik").Component<ColorInputProps>;
