import { type QwikIntrinsicElements } from "@builder.io/qwik";
export type AccordionContentProps = QwikIntrinsicElements["div"];
export declare const AccordionContent: import("@builder.io/qwik").Component<import("@builder.io/qwik").HTMLAttributes<HTMLDivElement>>;
