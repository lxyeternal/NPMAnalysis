export * from "./tabsContent";
