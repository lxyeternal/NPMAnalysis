import { type Signal, QwikIntrinsicElements } from "@builder.io/qwik";
import { FloaterProps } from "../floater";
import { type PaperProps } from "../paper";
import { type TitleProps } from "../title";
import { QuiSize } from "~/internal";
export type ModalIntrinsic = {
    wrapper?: PaperProps;
    header?: QwikIntrinsicElements["div"];
    title?: TitleProps;
    closeIcon?: QwikIntrinsicElements["div"];
    inner?: QwikIntrinsicElements["div"];
};
export type ModalProps = FloaterProps & {
    intrinsic?: ModalIntrinsic;
    signal: Signal<boolean>;
    title: string;
    size?: QuiSize;
    noClose?: boolean;
};
export declare const Modal: import("@builder.io/qwik").Component<ModalProps>;
