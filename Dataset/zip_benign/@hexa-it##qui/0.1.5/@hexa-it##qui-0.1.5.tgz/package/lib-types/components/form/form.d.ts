export declare const Form: import("@builder.io/qwik").Component<import("@builder.io/qwik").FormHTMLAttributes<HTMLFormElement>>;
