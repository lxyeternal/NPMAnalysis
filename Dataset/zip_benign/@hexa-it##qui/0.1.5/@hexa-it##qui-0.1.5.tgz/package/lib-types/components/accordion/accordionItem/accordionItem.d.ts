import { type QwikIntrinsicElements } from "@builder.io/qwik";
export type AccordionItemProps = QwikIntrinsicElements["div"] & {
    defaultOpen?: boolean;
};
export declare const AccordionItem: import("@builder.io/qwik").Component<AccordionItemProps>;
