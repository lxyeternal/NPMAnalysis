import { type Component, type QwikIntrinsicElements } from "@builder.io/qwik";
import { TabsList } from "./tabsList";
import { TabsContent } from "./tabsContent";
import { TabsTab } from "./tabsTab";
export type TabsCompound = {
    List: typeof TabsList;
    Tab: typeof TabsTab;
    Content: typeof TabsContent;
};
export type TabsProps = QwikIntrinsicElements["div"] & {
    defaultValue?: string;
    onChange$?: (value: string) => void;
    orientation?: "horizontal" | "vertical";
};
export declare const Tabs: Component<TabsProps> & TabsCompound;
