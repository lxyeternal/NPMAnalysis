import { QwikIntrinsicElements } from "@builder.io/qwik";
import { InputWrapperProps } from "~/internal";
import { ChoiceOption, ChoiceValue } from "./types";
export type ChoiceInputIntrinsic = {
    wrapper?: QwikIntrinsicElements["div"];
};
export type ChoiceInputProps = InputWrapperProps & {
    intrinsic?: ChoiceInputIntrinsic;
    data: ChoiceOption[];
    value?: (ChoiceValue | null) | ChoiceValue[];
    onChange$?: (value: ChoiceValue | ChoiceValue[]) => void;
    horizontal?: boolean;
    multiple?: boolean;
};
export declare const ChoiceInput: import("@builder.io/qwik").Component<ChoiceInputProps>;
