import { type FloaterProps } from "../floater";
import { QwikIntrinsicElements, type Signal } from "@builder.io/qwik";
import type { JSX } from "@builder.io/qwik/jsx-runtime";
import { type PaperProps } from "../paper";
import { Placement } from "@floating-ui/dom";
export type PopoverIntrinsic = {
    trigger?: QwikIntrinsicElements["div"];
    floater?: FloaterProps;
    popover?: PaperProps;
};
export type PopoverProps = QwikIntrinsicElements["div"] & {
    intrinsic?: PopoverIntrinsic;
    trigger: JSX.Element;
    signal?: Signal<boolean>;
    position?: Placement;
    defaultOpened?: boolean;
    hover?: boolean;
};
export declare const Popover: import("@builder.io/qwik").Component<PopoverProps>;
