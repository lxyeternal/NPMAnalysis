import { type Signal, type QwikIntrinsicElements } from "@builder.io/qwik";
import { FloaterProps } from "../floater";
import { TitleProps } from "../title";
export type DrawerIntrinsic = {
    wrapper?: QwikIntrinsicElements["div"];
    header?: QwikIntrinsicElements["div"];
    title?: TitleProps;
    closeIcon?: QwikIntrinsicElements["div"];
    inner?: QwikIntrinsicElements["div"];
};
export type DrawerProps = FloaterProps & {
    intrinsic?: DrawerIntrinsic;
    signal: Signal<boolean>;
    title: string;
    noClose?: boolean;
};
export declare const Drawer: import("@builder.io/qwik").Component<DrawerProps>;
