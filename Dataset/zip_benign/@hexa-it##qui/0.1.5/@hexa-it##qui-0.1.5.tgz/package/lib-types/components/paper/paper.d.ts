import { type QwikIntrinsicElements } from "@builder.io/qwik";
export type PaperVariants = "foreground" | "midground" | "background" | "neutral";
export type PaperProps = QwikIntrinsicElements["div"] & {
    component?: string;
    variant?: PaperVariants;
    glass?: boolean;
    noPadding?: boolean;
    fullWidth?: boolean;
};
export declare const Paper: import("@builder.io/qwik").Component<PaperProps>;
