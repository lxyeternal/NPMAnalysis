export declare const IconBold: import("@builder.io/qwik").Component<import("@builder.io/qwik").HTMLAttributes<HTMLDivElement>>;
