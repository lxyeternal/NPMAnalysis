import { QwikIntrinsicElements } from "@builder.io/qwik";
export type CloseIconProps = QwikIntrinsicElements["div"];
export declare const CloseIcon: import("@builder.io/qwik").Component<import("@builder.io/qwik").HTMLAttributes<HTMLDivElement>>;
