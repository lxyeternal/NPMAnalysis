interface PositionDetail {
    line: number;
    column: number;
}
interface Position {
    start: PositionDetail;
    end: PositionDetail;
    source?: string;
}
export interface Declaration {
    type: "declaration";
    property: string;
    value: string;
    position: Position;
}
interface Comment {
    type: "comment";
    comment: string;
    position: Position;
}
interface Options {
    source?: string;
    silent?: boolean;
}
export declare const inlineStyleParser: (style: string, optionsParam?: Options) => (Declaration | Comment)[];
export {};
