import { type CSSProperties, type ClassList, type Signal } from "@builder.io/qwik";
import clsx from "clsx";
import type { Falsy } from "./types";
type Style = CSSProperties | string | Falsy;
type Class = clsx.ClassValue | Falsy;
export declare const inject: <T extends {
    style?: CSSProperties | string | undefined;
    class?: ClassList | Signal<ClassList>;
}>(props: T | undefined, inject: Omit<T, "style" | "class"> & {
    style?: Style | Style[];
    class?: Class | Class[];
}, debug?: boolean) => T;
export {};
