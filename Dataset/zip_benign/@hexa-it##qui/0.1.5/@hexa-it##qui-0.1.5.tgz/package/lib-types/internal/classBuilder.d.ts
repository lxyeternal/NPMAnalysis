/// <reference types="vite/client" />
import type { Falsy } from "./types";
export declare const classBuilder: (styles: CSSModuleClasses) => (element: string, modifiers: Record<string, string | (boolean | Falsy)>) => string;
