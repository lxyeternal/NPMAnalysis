export declare const getZIndex: () => number;
