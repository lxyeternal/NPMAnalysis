import { QuiSize } from "./types";
export declare const getSize: (spacing: QuiSize) => string;
