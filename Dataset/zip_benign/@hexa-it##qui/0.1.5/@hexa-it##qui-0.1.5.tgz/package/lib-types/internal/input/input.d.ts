import { type QwikIntrinsicElements } from "@builder.io/qwik";
export type InputProps = QwikIntrinsicElements["input"] & {
    invalid?: boolean;
};
export declare const Input: import("@builder.io/qwik").Component<InputProps>;
