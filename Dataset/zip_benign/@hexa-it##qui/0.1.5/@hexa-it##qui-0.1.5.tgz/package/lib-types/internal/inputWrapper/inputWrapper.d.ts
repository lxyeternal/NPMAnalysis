import { QwikIntrinsicElements } from "@builder.io/qwik";
export type InputWrapperIntrinsic = {
    label?: QwikIntrinsicElements["label"];
    asterisk?: QwikIntrinsicElements["span"];
    description?: QwikIntrinsicElements["p"];
    inner?: QwikIntrinsicElements["div"];
    error?: QwikIntrinsicElements["p"];
};
export type InputWrapperProps = QwikIntrinsicElements["div"] & {
    intrinsic?: InputWrapperIntrinsic;
    inputId?: string;
    label?: string;
    description?: string;
    error?: string;
    required?: boolean;
    disabled?: boolean;
};
export type OmittedInputWrapperProps = Omit<InputWrapperProps, "inputId" | "classes" | "styles">;
export declare const InputWrapper: import("@builder.io/qwik").Component<InputWrapperProps>;
