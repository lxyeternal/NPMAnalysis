export declare const IconItalic: import("@builder.io/qwik").Component<import("@builder.io/qwik").HTMLAttributes<HTMLDivElement>>;
