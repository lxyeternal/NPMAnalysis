import type { CSSProperties } from "@builder.io/qwik";
import { QuiColor } from "./types";
export declare const getColor: (color?: QuiColor) => CSSProperties;
