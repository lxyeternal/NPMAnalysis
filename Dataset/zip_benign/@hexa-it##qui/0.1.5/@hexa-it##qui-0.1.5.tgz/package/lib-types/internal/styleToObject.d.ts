import { type Declaration } from "./inlineStyleParser";
interface StyleObject {
    [name: string]: string;
}
type Iterator = (property: string, value: string, declaration: Declaration) => void;
export declare const styleToObject: (style: string, iterator?: Iterator) => StyleObject | null;
export {};
