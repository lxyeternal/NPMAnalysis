export declare const IconUnderline: import("@builder.io/qwik").Component<import("@builder.io/qwik").HTMLAttributes<HTMLDivElement>>;
