import { type QRL, type Tracker } from "@builder.io/qwik";
type CleanupFn = () => void;
type Fn = QRL<() => CleanupFn | void>;
export declare const useUpdateTask: (tracker: QRL<(track: Tracker) => void>, fn: Fn) => void;
export {};
