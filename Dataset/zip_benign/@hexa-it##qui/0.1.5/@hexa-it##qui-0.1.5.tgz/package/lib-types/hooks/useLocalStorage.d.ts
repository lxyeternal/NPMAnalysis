export type UseLocalStorageProps<T> = {
    key: string;
    defaultValue: T | null;
};
export declare const useLocalStorage: <T>({ key, defaultValue, }: UseLocalStorageProps<T>) => {
    current: import("@builder.io/qwik").Signal<T | null>;
    isInitialized: import("@builder.io/qwik").Signal<boolean>;
};
