import { expect } from 'chai'
import { load } from '../src/maineffect'

const parsed = load(require.resolve('../src/examples/find'))

describe('find', () => {
  it('should find go ', () => {
      const find = parsed.find('go')
      const {result} = find
                        .callWith()
      expect(result).to.equal(undefined)
  })
  it('should find go ', () => {
    const Sync = parsed.find('Sync')
    const {result} = Sync
                      .callWith()
    expect(result).to.equal(undefined)
  })
})
