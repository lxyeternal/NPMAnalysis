const log = require('log')

const Sync = () => {
  function go () {
    console.log('Hey')
  }
}