# @saltace/vue-common

vue common 库

## 功能介绍

## 安装方法

使用 npm ： `npm install @saltace/vue-common`

## 用法

### directives

#### 按钮防抖指令 `v-debounce`

NOTICE: 重复点击仅最后一次会触发.

```vue
<button v-debounce="debounceClick">节流提交</button>
```

#### 节流指令 `v-throttle`

防止按钮在短时间内被多次点击，使用节流函数限制规定时间内只能点击一次。

NOTICE: 重复点击仅第一次会触发.

```vue
<button v-throttle="throttleClick">节流提交</button>
```

#### 拖拽指令 `v-draggable`

实现一个拖拽指令，可在父元素区域任意拖拽元素。

```vue
<div class="dialog-model" v-draggable></div>
```

#### 背景水印指令 `v-waterMarker`

给整个页面添加背景水印.

```vue
<div v-waterMarker="{ text: '版权所有', textColor: 'rgba(180, 180, 180, 0.4)' }"></div>
```

#### 长按触发指令 `v-longpress`

长按时触发事件

```vue
<button v-longpress="longpressClick">长按提交</button>
```

#### 点击复制指令 `v-copy`

复制某个值至剪贴板

```vue
<button v-copy="'复制的内容'">复制</button>
```
