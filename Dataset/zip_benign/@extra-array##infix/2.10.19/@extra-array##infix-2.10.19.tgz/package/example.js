const array = require("extra-array");

var x = [1, 2, 3];
array.infix(x);

array.infix(x, 1);

array.infix(x, 1, 0.5);
