declare module "@extra-array/infix" {
/**
 * Picks an arbitrary infix.
 * @param x an array
 * @param n number of values (-1 => any)
 * @param r random seed 0->1
 */
declare function infix<T>(x: T[], n?: number, r?: number): T[];
export = infix;
//# sourceMappingURL=infix.d.ts.map}
