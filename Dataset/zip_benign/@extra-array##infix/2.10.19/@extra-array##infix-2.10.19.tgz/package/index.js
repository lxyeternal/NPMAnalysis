'use strict';
function random(r) {
    var a = Math.floor(r * 2 ** 31);
    return function () {
        var t = a += 0x6D2B79F5;
        t = Math.imul(t ^ t >>> 15, t | 1);
        t ^= t + Math.imul(t ^ t >>> 7, t | 61);
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
}
function infixLength(X, r) {
    var C = 0.5 * X * (X + 1) + 1;
    var n = 0.5 * Math.sqrt(1 + 8 * r * C) - 0.5;
    return X + 1 - Math.floor(n + 1);
}
function infix(x, n = -1, r = Math.random()) {
    var X = x.length, rnd = random(r);
    var n = n >= 0 ? n : infixLength(X, rnd());
    var i = Math.floor((X + 1 - n) * rnd());
    return n > X ? null : x.slice(i, i + n);
}
module.exports = infix;
