'use strict';

var _jquery = require('jquery');

var _jquery2 = _interopRequireDefault(_jquery);

var _pixi = require('pixi.js');

var _pixi2 = _interopRequireDefault(_pixi);

var _displacementImage2 = require('./displacementImage');

var _displacementImage3 = _interopRequireDefault(_displacementImage2);

var _lodash = require('lodash.throttle');

var _lodash2 = _interopRequireDefault(_lodash);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import 'babel-polyfill'


var animating = false;

var elements = [];
var displacementImage = new Image();
var displacementTexture = null;
displacementImage.onload = function () {
	displacementTexture = new _pixi.Texture(new _pixi.BaseTexture(displacementImage));
	init();
};
displacementImage.src = _displacementImage3.default;

function init() {
	(0, _jquery2.default)(document).ready(function () {
		(0, _jquery2.default)('[data-waterify]').each(function () {
			createCanvas(this);
		});
		if (!animating) {
			animating = true;
			animate();
		}
	});
	(0, _jquery2.default)(document).on('resize', handleResize);
}

function createCanvas(elem) {

	var $elem = (0, _jquery2.default)(elem);
	var width = $elem.width();
	var height = $elem.height();
	var resolution = window.devicePixelRatio || 1;

	var displacementUrl = $elem.data('waterify-displacement-url');
	var maskUrl = $elem.data('waterify-mask-url');
	var displacementImageLoaded = false;
	var maskImageLoaded = false;

	var renderer = new _pixi2.default.autoDetectRenderer(width, height, { resolution: resolution, transparent: true });

	var canvas = renderer.view;

	var stage = new _pixi.Container();
	var imageContainer = new _pixi.Container();

	var _displacementTexture = displacementTexture;
	var _maskTexture = null;

	var image = new Image();
	image.crossOrigin = '';
	image.onload = function () {

		var _imageRef = this;
		var speed = typeof $elem.data('waterify-speed') == 'number' ? $elem.data('waterify-speed') : 1;
		var speedX = typeof $elem.data('waterify-speed-x') == 'number' ? $elem.data('waterify-speed-x') : null;
		var speedY = typeof $elem.data('waterify-speed-y') == 'number' ? $elem.data('waterify-speed-y') : null;
		var startScale = $elem.data('waterify-start-amount') || 0;
		// const displacementScale = $elem.data('waterify-displacement-scale') || 1;

		// _displacementTexture.width *= displacementScale;
		// _displacementTexture.height *= displacementScale;
		// console.log(_displacementTexture);

		var displacementSprite = new _pixi.Sprite(_displacementTexture, 1);
		var displacementFilter = new _pixi2.default.filters.DisplacementFilter(displacementSprite);
		displacementFilter.scale.x = startScale;
		displacementFilter.scale.y = startScale;

		var texture = new _pixi.Texture(new _pixi.BaseTexture(this));
		var sprite = new _pixi.Sprite(texture);
		sprite.width = width;
		sprite.height = height;
		imageContainer.addChild(sprite);

		sprite.filters = [displacementFilter];

		if (maskUrl) {
			var maskSprite = new _pixi.Sprite(_maskTexture, 1);
			maskSprite.anchor.set(0.5);
			maskSprite.position.set(width / 2, height / 2);

			// scale mask to fit image
			maskSprite.scale.set(Math.min(width / maskSprite.width, height / maskSprite.height));

			imageContainer.mask = maskSprite;
			imageContainer.addChild(maskSprite);

			// create another image to go underneath masked image
			var underlaySprite = new _pixi.Sprite(texture);
			underlaySprite.width = width;
			underlaySprite.height = height;
			stage.addChild(underlaySprite);
		}

		stage.addChild(imageContainer);

		var attributes = $elem.prop('attributes');
		_jquery2.default.each(attributes, function () {
			// instead of using image width/height tags on the canvas we use css
			if (this.name == 'width' && parseFloat(this.value) != _imageRef.width) {
				(0, _jquery2.default)(canvas).css('width', this.value + 'px');
			} else if (this.name == 'height' && parseFloat(this.value) != _imageRef.height) {
				(0, _jquery2.default)(canvas).css('height', this.value + 'px');
			} else {
				(0, _jquery2.default)(canvas).attr(this.name, this.value);
			}
		});

		elements.push({
			original: $elem.clone(),
			canvas: canvas,
			renderer: renderer,
			stage: stage,
			sprite: sprite,
			width: width,
			height: height,
			displacementFilter: displacementFilter,
			displacementSprite: displacementSprite,
			ease: $elem.data('waterify-ease') || 100,
			scale: $elem.data('waterify-amount') || 20,
			speedX: speedX || (speedY ? 0 : speed),
			speedY: speedY || (speedX ? 0 : speed)
		});

		$elem.replaceWith(canvas);
	};

	if (maskUrl) {
		var maskImage = new Image();
		maskImage.crossOrigin = '';
		maskImage.onload = function () {
			maskImageLoaded = true;
			_maskTexture = new _pixi.Texture(new _pixi.BaseTexture(this));
			if (!displacementUrl || displacementUrl && displacementImageLoaded) image.src = $elem.attr('src');
		};
		maskImage.src = maskUrl;
	} else {
		if (!displacementUrl || displacementUrl && displacementImageLoaded) image.src = $elem.attr('src');
	}

	if (displacementUrl) {
		var _displacementImage = new Image();
		_displacementImage.crossOrigin = '';
		_displacementImage.onload = function () {
			displacementImageLoaded = true;
			_displacementTexture = new _pixi.Texture(new _pixi.BaseTexture(this));
			if (!maskUrl || maskUrl && maskImageLoaded) image.src = $elem.attr('src');
		};
		_displacementImage.src = displacementUrl;
	} else {
		if (!maskUrl || maskUrl && maskImageLoaded) image.src = $elem.attr('src');
	}
}

function animate() {
	var _iteratorNormalCompletion = true;
	var _didIteratorError = false;
	var _iteratorError = undefined;

	try {
		for (var _iterator = elements[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
			var element = _step.value;

			element.displacementSprite.anchor.x += element.speedX / 1000;
			element.displacementSprite.anchor.y += element.speedY / 1000;
			element.displacementFilter.scale.x += (element.scale - element.displacementFilter.scale.x) / element.ease;
			element.displacementFilter.scale.y = element.displacementFilter.scale.x;
			element.renderer.render(element.stage);
		}
	} catch (err) {
		_didIteratorError = true;
		_iteratorError = err;
	} finally {
		try {
			if (!_iteratorNormalCompletion && _iterator.return) {
				_iterator.return();
			}
		} finally {
			if (_didIteratorError) {
				throw _iteratorError;
			}
		}
	}

	if (animating) window.requestAnimationFrame(animate);
}

function _handleResize() {
	var _iteratorNormalCompletion2 = true;
	var _didIteratorError2 = false;
	var _iteratorError2 = undefined;

	try {
		for (var _iterator2 = elements[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
			var element = _step2.value;

			var width = (0, _jquery2.default)(element.canvas).width();
			var height = (0, _jquery2.default)(element.canvas).width();
			if (width != element.width || height != element.height) {
				element.renderer.resize(width, height);
				element.width = width;
				element.height = height;
			}
		}
	} catch (err) {
		_didIteratorError2 = true;
		_iteratorError2 = err;
	} finally {
		try {
			if (!_iteratorNormalCompletion2 && _iterator2.return) {
				_iterator2.return();
			}
		} finally {
			if (_didIteratorError2) {
				throw _iteratorError2;
			}
		}
	}
}
var handleResize = (0, _lodash2.default)(_handleResize, 1000 / 60);