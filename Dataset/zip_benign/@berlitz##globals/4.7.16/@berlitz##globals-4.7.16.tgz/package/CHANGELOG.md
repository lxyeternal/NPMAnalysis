# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [4.7.16](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.15...@berlitz/globals@4.7.16) (2025-02-28)

**Note:** Version bump only for package @berlitz/globals





## [4.7.15](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.14...@berlitz/globals@4.7.15) (2025-02-27)

**Note:** Version bump only for package @berlitz/globals





## [4.7.14](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.13...@berlitz/globals@4.7.14) (2024-09-09)


### Bug Fixes

* fixed card title auto centered when h3 added ([4600c76](https://github.com/berlitz-global/max/commit/4600c768898934cc774449c2a4408dd7a008401f))





## [4.7.13](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.12...@berlitz/globals@4.7.13) (2024-08-26)


### Bug Fixes

* fixed Blog page turning white ([5739eff](https://github.com/berlitz-global/max/commit/5739eff3247c0c870fd4bd1a651fd315a06ec3bf))





## [4.7.12](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.11...@berlitz/globals@4.7.12) (2024-08-22)


### Bug Fixes

* fixed card title highlight when including h3 tag from contentstack ([1e80abe](https://github.com/berlitz-global/max/commit/1e80abe81b42b4d9991899ecb099f1c98239a967))





## [4.7.11](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.10...@berlitz/globals@4.7.11) (2024-07-10)


### Bug Fixes

* made some changes in order to fix text center issue ([14ce57e](https://github.com/berlitz-global/max/commit/14ce57e2db4f5265a2a88a22bc794998113d1884))





## [4.7.10](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.9...@berlitz/globals@4.7.10) (2024-06-18)


### Bug Fixes

* fixed card button not being aligned and card title split ([a37a5b9](https://github.com/berlitz-global/max/commit/a37a5b95604766c738875c172de475255f135d8d))
* fixed title highlight that contains H3 ([09ec915](https://github.com/berlitz-global/max/commit/09ec9156404c725a5a3648169ac02fe642157539))
* snapshot update ([139eb29](https://github.com/berlitz-global/max/commit/139eb299fb891f6beb40770e572756c9ef45063d))





## [4.7.9](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.8...@berlitz/globals@4.7.9) (2024-03-04)


### Bug Fixes

* update rich-text for centered iframes ([2062d85](https://github.com/berlitz-global/max/commit/2062d85fa6198d15f50869dbf4cfa0c8f5493dcb))





## [4.7.8](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.7...@berlitz/globals@4.7.8) (2024-02-12)


### Bug Fixes

* align center in content area ([61f7442](https://github.com/berlitz-global/max/commit/61f744239d1f35fc81d165b010476b0b8271ad95))





## [4.7.7](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.6...@berlitz/globals@4.7.7) (2024-01-19)

**Note:** Version bump only for package @berlitz/globals





## [4.7.6](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.5...@berlitz/globals@4.7.6) (2023-09-27)

**Note:** Version bump only for package @berlitz/globals





## [4.7.5](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.4...@berlitz/globals@4.7.5) (2023-09-22)

**Note:** Version bump only for package @berlitz/globals





## [4.7.4](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.3...@berlitz/globals@4.7.4) (2023-09-13)

**Note:** Version bump only for package @berlitz/globals





## [4.7.3](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.2...@berlitz/globals@4.7.3) (2023-09-07)

**Note:** Version bump only for package @berlitz/globals





## [4.7.2](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.1...@berlitz/globals@4.7.2) (2023-09-06)


### Bug Fixes

* minor fix for sanitize ([21b1ad1](https://github.com/berlitz-global/max/commit/21b1ad1ea16359e4db40e68d5208c802bf2435e6))





## [4.7.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.7.0...@berlitz/globals@4.7.1) (2023-09-01)

**Note:** Version bump only for package @berlitz/globals





# [4.7.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.6.2...@berlitz/globals@4.7.0) (2023-08-22)


### Features

* added DOMPurify for sanitize html ([1d8a013](https://github.com/berlitz-global/max/commit/1d8a013426e816b7c8f7c7bb277aea2dceaf1a53))





## [4.6.2](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.6.1...@berlitz/globals@4.6.2) (2023-06-29)

**Note:** Version bump only for package @berlitz/globals





## [4.6.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.6.0...@berlitz/globals@4.6.1) (2023-04-19)


### Bug Fixes

* rearrange margin bottom ([3fa1a01](https://github.com/berlitz-global/max/commit/3fa1a016f12e5a9dd3908c9136b1fe4ef461584f))





# [4.6.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.5.0...@berlitz/globals@4.6.0) (2023-04-12)


### Bug Fixes

* update snapshots ([5f059a8](https://github.com/berlitz-global/max/commit/5f059a8e65313c290803e15487df7992ea7a1125))


### Features

* added margin top ([300d20c](https://github.com/berlitz-global/max/commit/300d20cdbb52b8e247c1ce3461fefb43773324a0))





# [4.5.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.4.7...@berlitz/globals@4.5.0) (2022-11-17)


### Features

* refactor stories ([5f9f7a5](https://github.com/berlitz-global/max/commit/5f9f7a5d415fe0bfaf0ffe29c0ecb02bf88474df))
* update primary texthighlight to no highlight ([1df9d5d](https://github.com/berlitz-global/max/commit/1df9d5d4fae3582e2fd6418546ce2337ebbc6462))





## [4.4.7](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.4.6...@berlitz/globals@4.4.7) (2022-09-14)


### Bug Fixes

* button richtext ([c4131d7](https://github.com/berlitz-global/max/commit/c4131d7b52f7e16b63a735f2375196000fbde1a1))
* fix button richtext ([f679d31](https://github.com/berlitz-global/max/commit/f679d3154a2ca77a387e42c830ab333d9f5dfdd5))





## [4.4.6](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.4.5...@berlitz/globals@4.4.6) (2022-09-05)


### Performance Improvements

* remove whitespace ([48a80b5](https://github.com/berlitz-global/max/commit/48a80b55e18f865e3a70e0f4d30599994e88d185))





## [4.4.5](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.4.4...@berlitz/globals@4.4.5) (2022-05-13)


### Bug Fixes

* added fine style and strong span ([800f738](https://github.com/berlitz-global/max/commit/800f7380714c146c569b65a4c280a93d102f1b56))





## [4.4.4](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.4.3...@berlitz/globals@4.4.4) (2022-04-05)

**Note:** Version bump only for package @berlitz/globals





## [4.4.3](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.4.2...@berlitz/globals@4.4.3) (2022-03-03)

**Note:** Version bump only for package @berlitz/globals





## [4.4.2](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.4.1...@berlitz/globals@4.4.2) (2022-02-16)

**Note:** Version bump only for package @berlitz/globals





## [4.4.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.4.0...@berlitz/globals@4.4.1) (2022-01-10)

**Note:** Version bump only for package @berlitz/globals





# [4.4.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.3.1...@berlitz/globals@4.4.0) (2021-12-20)


### Bug Fixes

* change a.btn to .btn ([ea4cfb0](https://github.com/berlitz-global/max/commit/ea4cfb00156fe9a3a9f872c908c5626e0281b277))


### Features

* click effect on ie11 ([413177e](https://github.com/berlitz-global/max/commit/413177e5ff59c4a8f2a1d164b35730cb89a0cff6))
* ripple effects on buttons ([3737578](https://github.com/berlitz-global/max/commit/3737578512246355de9d2935e8fc97cfd7378e9e))





## [4.3.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.3.0...@berlitz/globals@4.3.1) (2021-10-26)


### Bug Fixes

* merge from master ([59aa61e](https://github.com/berlitz-global/max/commit/59aa61e745d5c127d5083d1ebcb0a6742137910e))
* modify richtext styles ([6bb6d0e](https://github.com/berlitz-global/max/commit/6bb6d0e195c13ad925e55c6deddcced93d926a0d))
* new heading story ([01c312c](https://github.com/berlitz-global/max/commit/01c312c71337bb94ffc8186d7c12105f0b56b330))





# [4.3.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.2.4...@berlitz/globals@4.3.0) (2021-10-13)


### Bug Fixes

* added style span fine ([7c3d8df](https://github.com/berlitz-global/max/commit/7c3d8dfe0f41ea0c3ce78058617d6bb6c4352197))


### Features

* added color brand primary on span ([46c2c44](https://github.com/berlitz-global/max/commit/46c2c4418aec3ecda6f51a689599b88548639e9e))
* added fine class on span ([dfc03ce](https://github.com/berlitz-global/max/commit/dfc03ceada89dccd60f60fc0cda6838f3fe1b073))
* added text align right ([807af0a](https://github.com/berlitz-global/max/commit/807af0a474688a6b375f68589173f1e3cc6611b6))





## [4.2.4](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.2.3...@berlitz/globals@4.2.4) (2021-10-07)


### Bug Fixes

* **rich-text:** add btn on a tag ([1daf8af](https://github.com/berlitz-global/max/commit/1daf8af407dc765a295b3a611efe127c764398b0))
* **rich-text:** update theme var ([0b68f6b](https://github.com/berlitz-global/max/commit/0b68f6bd665dd43957e72d884719f4d7c0a85786))





## [4.2.3](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.2.2...@berlitz/globals@4.2.3) (2021-09-20)

**Note:** Version bump only for package @berlitz/globals





## [4.2.2](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.2.1...@berlitz/globals@4.2.2) (2021-08-05)


### Bug Fixes

* **audio:** bootstrap no longer watches, fix audio listeners ([b17ce9f](https://github.com/berlitz-global/max/commit/b17ce9f13b45725ee1332892cb0de9fc3cc1eec2))
* **richtext:** clean audio implimentation in richtext ([8af128c](https://github.com/berlitz-global/max/commit/8af128c0112645fda26066ec2fe629c848e6c90a))
* **richtext:** innerHTML fallback object ([9b56d24](https://github.com/berlitz-global/max/commit/9b56d249485930c4471a81da0bd2662b87c2d534))
* **richtext:** normalize data ([947b02d](https://github.com/berlitz-global/max/commit/947b02d6c7d469104739184f2d02d3f332016802))
* **richtext:** scope audio listeners to block by id ([b264aa0](https://github.com/berlitz-global/max/commit/b264aa0b08cb49999518d217e81c7e2962ed9b4e))





## [4.2.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.2.0...@berlitz/globals@4.2.1) (2021-06-14)


### Bug Fixes

* allow for controlslist to disable download ([1412362](https://github.com/berlitz-global/max/commit/141236278d595141efdffdd59c562a3f35230340))





# [4.2.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.1.10...@berlitz/globals@4.2.0) (2021-06-11)


### Features

* add audio to richtext ([33cbadf](https://github.com/berlitz-global/max/commit/33cbadfc85c51b123904581488e2383e13ff1af2))





## [4.1.10](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.1.9...@berlitz/globals@4.1.10) (2021-05-13)


### Bug Fixes

* **richtext:** add gray and white table colors to richtext ([a013866](https://github.com/berlitz-global/max/commit/a01386695fb49b59f60bdfae05fd5c0535c4d868))





## [4.1.9](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.1.8...@berlitz/globals@4.1.9) (2021-04-29)

**Note:** Version bump only for package @berlitz/globals





## [4.1.8](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.1.7...@berlitz/globals@4.1.8) (2021-04-28)


### Bug Fixes

* **block-form:** add white color to a tag link ([58f6a9b](https://github.com/berlitz-global/max/commit/58f6a9b77982895331d689e62c6eebfa7bc63d6c))
* **form:** update snapshot test ([e693cfb](https://github.com/berlitz-global/max/commit/e693cfb36bada03ef128fa6da9c0420a4baa15f8))





## [4.1.7](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.1.6...@berlitz/globals@4.1.7) (2021-04-09)


### Bug Fixes

* **deps:** update deps april 2021 ([da83b95](https://github.com/berlitz-global/max/commit/da83b95f4c18ca82521ff5ed0f66e1bc16cfa324))





## [4.1.6](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.1.5...@berlitz/globals@4.1.6) (2021-03-14)


### Bug Fixes

* **richtext:** allow data key in rich-text ([859f2d3](https://github.com/berlitz-global/max/commit/859f2d341c976b121be05a3f76fdc8a9da13a5c5))





## [4.1.5](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.1.4...@berlitz/globals@4.1.5) (2021-02-17)


### Bug Fixes

* **max:** reduce padding of page banner + blocks ([f0c6f2f](https://github.com/berlitz-global/max/commit/f0c6f2f2fe56c6248613c1d8746b6b3e306a93ef))





## [4.1.4](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.1.3...@berlitz/globals@4.1.4) (2021-02-17)


### Bug Fixes

* **rich-text:** add closing quote to blockquote ([1a846d7](https://github.com/berlitz-global/max/commit/1a846d7f2dbcc1ae1efca6ed8cf1a9f4f21a99ba))





## [4.1.3](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.1.2...@berlitz/globals@4.1.3) (2021-02-12)

**Note:** Version bump only for package @berlitz/globals





## [4.1.2](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.1.1...@berlitz/globals@4.1.2) (2021-02-12)

**Note:** Version bump only for package @berlitz/globals





## [4.1.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.1.0...@berlitz/globals@4.1.1) (2021-02-12)

**Note:** Version bump only for package @berlitz/globals





# [4.1.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.0.5...@berlitz/globals@4.1.0) (2021-02-01)


### Features

* **type:** use any theme color for typography ([e24e3e0](https://github.com/berlitz-global/max/commit/e24e3e052a9f0dd32be1bebaae945c084d222a15))





## [4.0.5](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.0.4...@berlitz/globals@4.0.5) (2021-01-21)

**Note:** Version bump only for package @berlitz/globals





## [4.0.4](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.0.3...@berlitz/globals@4.0.4) (2021-01-20)

**Note:** Version bump only for package @berlitz/globals





## [4.0.3](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.0.2...@berlitz/globals@4.0.3) (2021-01-06)

**Note:** Version bump only for package @berlitz/globals





## [4.0.2](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.0.1...@berlitz/globals@4.0.2) (2021-01-06)


### Bug Fixes

* **react16:** back to react 16, gatsby doesnt like react 17 ([22e8093](https://github.com/berlitz-global/max/commit/22e80932825801ef10907bbb3e22392f86ee17e8))





## [4.0.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@4.0.0...@berlitz/globals@4.0.1) (2021-01-05)


### Bug Fixes

* **peerdeps:** react 17 peer deps ([590cd1a](https://github.com/berlitz-global/max/commit/590cd1a0d5e7bcb9751feb59e6a62b26b7384214))





# [4.0.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.5.0...@berlitz/globals@4.0.0) (2020-10-16)


### Features

* **styled-components:** upgrade to styled components 5 ([96793ca](https://github.com/berlitz-global/max/commit/96793caea797eb50010a3c908d6b4f946a9d177a))


### BREAKING CHANGES

* **styled-components:** styled-components 5 is major update





# [3.5.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.4.7...@berlitz/globals@3.5.0) (2020-09-16)


### Features

* **rich-text:** enable custom data key ([89d5b1b](https://github.com/berlitz-global/max/commit/89d5b1bf4b620125a59daaeb3ba0c54a196f0628))





## [3.4.7](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.4.6...@berlitz/globals@3.4.7) (2020-09-09)

**Note:** Version bump only for package @berlitz/globals





## [3.4.6](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.4.5...@berlitz/globals@3.4.6) (2020-08-04)


### Bug Fixes

* convert nodeList array to be a regular array to be looped over ([275c71a](https://github.com/berlitz-global/max/commit/275c71a46c457c22014ff7a0bf632ad89ef6bdfd))
* only select iframes that have youtube src attr ([ae0ea37](https://github.com/berlitz-global/max/commit/ae0ea370c8f1b7fcbadc1b7d14e81ef4374cb49c))
* revert, looks like the youtube src is already done ([80701d2](https://github.com/berlitz-global/max/commit/80701d219f596306c646d2b1d02ea6ad5ebeaef9))





## [3.4.5](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.4.4...@berlitz/globals@3.4.5) (2020-08-03)


### Bug Fixes

* add iframe wrapper on mount ([63bbba6](https://github.com/berlitz-global/max/commit/63bbba6a6cfd87b30f26a731edbc16943d636801))





## [3.4.4](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.4.3...@berlitz/globals@3.4.4) (2020-07-29)

**Note:** Version bump only for package @berlitz/globals





## [3.4.3](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.4.2...@berlitz/globals@3.4.3) (2020-07-29)


### Bug Fixes

* fix sizes on bullets on smaller screens ([5afae1e](https://github.com/berlitz-global/max/commit/5afae1e42b9a13db04799c9275576318977bdafa))
* refine one more time and snapshots ([119508c](https://github.com/berlitz-global/max/commit/119508ce829bd7666a8a8dbad6b28f78fce7d6b6))





## [3.4.2](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.4.1...@berlitz/globals@3.4.2) (2020-07-28)


### Bug Fixes

* remove unused font-size on bullet, increase dot size by 1px ([0640466](https://github.com/berlitz-global/max/commit/06404664ffb02662ff1880bfeb862b9c4fe55ec4))
* update li bullet to use css styles rather than font character ([ee546ee](https://github.com/berlitz-global/max/commit/ee546eefafe055c31f302273a4ec379a2e35ee85))





## [3.4.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.4.0...@berlitz/globals@3.4.1) (2020-07-27)

**Note:** Version bump only for package @berlitz/globals





# [3.4.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.3.10...@berlitz/globals@3.4.0) (2020-07-17)


### Features

* **richtext:** table alert styles, warning success and danger ([0c8593e](https://github.com/berlitz-global/max/commit/0c8593e0039a3c29c28faf175e39308e8b4a00c3))





## [3.3.10](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.3.9...@berlitz/globals@3.3.10) (2020-07-16)


### Bug Fixes

* **richtext:** browser code does not run in node ([8cdc81e](https://github.com/berlitz-global/max/commit/8cdc81edb6b6a0a5af338af2a9cac49eb8fe70f9))





## [3.3.9](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.3.8...@berlitz/globals@3.3.9) (2020-07-15)


### Bug Fixes

* **richtext:** check document exists before using it ([1f3be13](https://github.com/berlitz-global/max/commit/1f3be135b0cb4de8ca386a2ec4b017d0375833d9))





## [3.3.8](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.3.7...@berlitz/globals@3.3.8) (2020-07-14)


### Bug Fixes

* **richtext:** remove all state from rich text, useMemo ([f8af62b](https://github.com/berlitz-global/max/commit/f8af62b3971a953b8781e3a11f7bb4212fccfd6f))





## [3.3.7](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.3.6...@berlitz/globals@3.3.7) (2020-07-09)


### Bug Fixes

* **rich-text:** remove condition block ([ba38766](https://github.com/berlitz-global/max/commit/ba387666742bd8234a117aace5282671980089f4))
* **rich-text:** update iframe wrapper selector ([84665d2](https://github.com/berlitz-global/max/commit/84665d260f5f6f129f6ac04aea0a6d3bc9522077))





## [3.3.6](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.3.5...@berlitz/globals@3.3.6) (2020-07-09)


### Bug Fixes

* **rich-text:** rename variables to Lowercase and pluralise ([74c068b](https://github.com/berlitz-global/max/commit/74c068be02c10bc738b86bd1b85f5bac56e5e35c))
* **rich-text:** update logic to check iframe length ([fe9f0e3](https://github.com/berlitz-global/max/commit/fe9f0e34d0aef67c3d3ecd0b7b74deea2e0068f8))
* **rich-text:** update PR code review ([7ceca1c](https://github.com/berlitz-global/max/commit/7ceca1c6a1ce938c49649df03dc10a0a3c053f76))
* **rich-text:** update PR review ([9e3a7df](https://github.com/berlitz-global/max/commit/9e3a7dfc2c233bad96427f5e88a48aa3b74791bb))
* **rich-text:** update PR review ([0005da8](https://github.com/berlitz-global/max/commit/0005da89d1c025345dfff1d9f1c3fa7079917f2f))
* **rich-text:** update video wrapper ([878563d](https://github.com/berlitz-global/max/commit/878563d03b8e794283e90216c4234214e25780dd))





## [3.3.5](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.3.4...@berlitz/globals@3.3.5) (2020-07-08)


### Bug Fixes

* **rich-text:** update video iframe wrapper ([66e0c25](https://github.com/berlitz-global/max/commit/66e0c25a8cef7b2e9b55d4daf1868c7a0619b447))





## [3.3.4](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.3.3...@berlitz/globals@3.3.4) (2020-06-30)

**Note:** Version bump only for package @berlitz/globals





## [3.3.3](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.3.2...@berlitz/globals@3.3.3) (2020-06-25)

**Note:** Version bump only for package @berlitz/globals





## [3.3.2](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.3.1...@berlitz/globals@3.3.2) (2020-06-24)

**Note:** Version bump only for package @berlitz/globals





## [3.3.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.3.0...@berlitz/globals@3.3.1) (2020-06-23)


### Bug Fixes

* **richtext:** if passed a plain string, wrap in p tag ([e004d77](https://github.com/berlitz-global/max/commit/e004d77338c9b65cba05a1803a7e398f26d0cfb3))





# [3.3.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.2.7...@berlitz/globals@3.3.0) (2020-06-15)


### Features

* **globals:** xs size option for P tags ([071cf0b](https://github.com/berlitz-global/max/commit/071cf0b95f7fbd999e5713d28a58ae099fc88a37))





## [3.2.7](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.2.6...@berlitz/globals@3.2.7) (2020-06-12)


### Bug Fixes

* **richtext:** allow for multiple video iframe wrappers ([4428ead](https://github.com/berlitz-global/max/commit/4428ead2cede6f68739184032a9367221e2fad1b))





## [3.2.6](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.2.5...@berlitz/globals@3.2.6) (2020-06-11)

**Note:** Version bump only for package @berlitz/globals





## [3.2.5](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.2.4...@berlitz/globals@3.2.5) (2020-05-13)

**Note:** Version bump only for package @berlitz/globals





## [3.2.4](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.2.3...@berlitz/globals@3.2.4) (2020-05-06)


### Bug Fixes

* **globals:** improve nested ul ol styles ([06da7c9](https://github.com/berlitz-global/max/commit/06da7c95622dd1cdc7ef1a337f736834402f2cb5))





## [3.2.3](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.2.2...@berlitz/globals@3.2.3) (2020-05-06)


### Bug Fixes

* **table:** styles for nested tables ([e33675d](https://github.com/berlitz-global/max/commit/e33675d66b76dd06e97a9e33cdffe0591255d4d6))





## [3.2.2](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.2.1...@berlitz/globals@3.2.2) (2020-05-04)

**Note:** Version bump only for package @berlitz/globals





## [3.2.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.2.0...@berlitz/globals@3.2.1) (2020-04-15)


### Bug Fixes

* **card:** align highlight text ([1a7870c](https://github.com/berlitz-global/max/commit/1a7870c66eb555a09ea8467570cd03a1eb7c015e))
* **global:** align highlight text ([59a1fed](https://github.com/berlitz-global/max/commit/59a1fede7ffa9be5018312642123d18873a08b81))
* **richtext:** revert sm to md on Richtext p tags ([636e46d](https://github.com/berlitz-global/max/commit/636e46d5b1310665d7600c6a4b42f5947b76e9b7))





# [3.2.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.1.0...@berlitz/globals@3.2.0) (2020-04-15)


### Features

* **globals:** flex component ([b02bcb5](https://github.com/berlitz-global/max/commit/b02bcb5c4cc18cbcbac8ba9590cfd724f515e1c0))





# [3.1.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@3.0.0...@berlitz/globals@3.1.0) (2020-04-02)


### Bug Fixes

* styling tweaks from pr feedback ([91fe2f7](https://github.com/berlitz-global/max/commit/91fe2f72af8d59d4f36c4b67a9fd3024c06681af))


### Features

* add hr and divider to form and richtext ([2feed46](https://github.com/berlitz-global/max/commit/2feed468c5377368299f36b5b779863b4d27b2c8))





# [3.0.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.11.0...@berlitz/globals@3.0.0) (2020-04-02)


### Features

* **table:** new table component, new table styles ([1dff360](https://github.com/berlitz-global/max/commit/1dff360018f5e8d17b4218f8d3eec53653e18270))


### BREAKING CHANGES

* **table:** RichText table styles have been changed, removed blue th etc





# [2.11.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.10.0...@berlitz/globals@2.11.0) (2020-03-24)


### Features

* **globals:** color text components with class color-brand-primary ([ec09863](https://github.com/berlitz-global/max/commit/ec09863eadc2fbb551906ca7729108fb98653a44))





# [2.10.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.9.2...@berlitz/globals@2.10.0) (2020-03-19)


### Features

* **globals:** section props to disable top or bottom padding ([095899b](https://github.com/berlitz-global/max/commit/095899b4289d700fef8847fac4ea386be7f324ec))





## [2.9.2](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.9.1...@berlitz/globals@2.9.2) (2020-03-17)


### Bug Fixes

* **@berlitz/block:** strict font wieght ([42b387b](https://github.com/berlitz-global/max/commit/42b387be507358456f87156530f3bba5739fa0af))


### Performance Improvements

* **@berlitz/blokc:** add highlight prop to block card ([d486e07](https://github.com/berlitz-global/max/commit/d486e077e4a92060ebaae97694b4aacc4a971f22))





## [2.9.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.9.0...@berlitz/globals@2.9.1) (2020-03-17)


### Bug Fixes

* **data-keys:** add data-keys to RichText TextArea ([aea4395](https://github.com/berlitz-global/max/commit/aea4395e48f717d8670342793e022278c19da9a2))





# [2.9.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.8.3...@berlitz/globals@2.9.0) (2020-03-16)


### Bug Fixes

* **@berlitz/globals:** dummy push ([f2b16b4](https://github.com/berlitz-global/max/commit/f2b16b4e2f8cf728fa898ad2f1e6cc721f07b7b9))
* **typography:** line heights for highlighted text ([898aa2d](https://github.com/berlitz-global/max/commit/898aa2da05375b5e525696cb7298f7c8c9367ef0))


### Features

* **@berlitz/global:** optimize ([daf3fe8](https://github.com/berlitz-global/max/commit/daf3fe8d8b8adc8d2de11fef8573032cba2f4e63))
* **typography:** add highlight props ([40b510b](https://github.com/berlitz-global/max/commit/40b510bd790b66057805697eaa778dea99f047ed))
* **typography:** add highlight props ([7183ce8](https://github.com/berlitz-global/max/commit/7183ce88b0b88fd32ba98867098ce0583e6c3a92))





## [2.8.3](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.8.2...@berlitz/globals@2.8.3) (2020-03-10)

**Note:** Version bump only for package @berlitz/globals





## [2.8.2](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.8.1...@berlitz/globals@2.8.2) (2020-02-11)

**Note:** Version bump only for package @berlitz/globals





## [2.8.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.8.0...@berlitz/globals@2.8.1) (2019-12-12)


### Bug Fixes

* **@berlitz/globals:** tables full width within RichText ([135cc36](https://github.com/berlitz-global/max/commit/135cc361807ed66f48c596d14959bea74b4fdeae))





# [2.8.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.7.2...@berlitz/globals@2.8.0) (2019-12-10)


### Features

* **@berlitz/globals:** add th styles to RichText table ([0d55ac2](https://github.com/berlitz-global/max/commit/0d55ac2ec9e80fa848b12156f6cee4ce5fef60e7))





## [2.7.2](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.7.1...@berlitz/globals@2.7.2) (2019-12-02)

**Note:** Version bump only for package @berlitz/globals





## [2.7.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.7.0...@berlitz/globals@2.7.1) (2019-11-28)

**Note:** Version bump only for package @berlitz/globals





# [2.7.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.6.0...@berlitz/globals@2.7.0) (2019-11-07)


### Features

* option to center content in content area block ([e24ddda](https://github.com/berlitz-global/max/commit/e24dddaedd971c65638420bbc2ca134bee132585))





# [2.6.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.5.0...@berlitz/globals@2.6.0) (2019-10-31)


### Features

* **globals:** add basic styling to tables in RichText ([e8eb2c2](https://github.com/berlitz-global/max/commit/e8eb2c2c87a9ef7920574eee522a8544394a9f5a))





# [2.5.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.4.3...@berlitz/globals@2.5.0) (2019-10-25)


### Bug Fixes

* **page-banner:** remove xs breakpoint ([926440a](https://github.com/berlitz-global/max/commit/926440a))


### Features

* **blocks/page-banner:** refine padding/margin on components ([a80c4b6](https://github.com/berlitz-global/max/commit/a80c4b6))
* **globals:** tweak section size, typography h2 size ([383dc54](https://github.com/berlitz-global/max/commit/383dc54))





## [2.4.3](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.4.2...@berlitz/globals@2.4.3) (2019-10-24)

**Note:** Version bump only for package @berlitz/globals





## [2.4.2](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.4.1...@berlitz/globals@2.4.2) (2019-10-24)

**Note:** Version bump only for package @berlitz/globals





## [2.4.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.4.0...@berlitz/globals@2.4.1) (2019-10-17)


### Bug Fixes

* add missing bottom space for video iframes inside richtext ([b8a84e1](https://github.com/berlitz-global/max/commit/b8a84e1))





# [2.4.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.3.1...@berlitz/globals@2.4.0) (2019-10-15)


### Features

* **max:** add typescript support to max ([8de79d5](https://github.com/berlitz-global/max/commit/8de79d5))





## [2.3.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.3.0...@berlitz/globals@2.3.1) (2019-10-09)

**Note:** Version bump only for package @berlitz/globals





# [2.3.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.2.8...@berlitz/globals@2.3.0) (2019-10-08)


### Bug Fixes

* move fine richtext styles to the correct location ([4826392](https://github.com/berlitz-global/max/commit/4826392))


### Features

* add fine text options for richtext ([b84111c](https://github.com/berlitz-global/max/commit/b84111c))





## [2.2.8](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.2.7...@berlitz/globals@2.2.8) (2019-10-07)

**Note:** Version bump only for package @berlitz/globals





## [2.2.7](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.2.6...@berlitz/globals@2.2.7) (2019-10-07)


### Bug Fixes

* fix error on richtext render ([bb9f777](https://github.com/berlitz-global/max/commit/bb9f777))





## [2.2.6](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.2.5...@berlitz/globals@2.2.6) (2019-10-07)

**Note:** Version bump only for package @berlitz/globals





## [2.2.5](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.2.4...@berlitz/globals@2.2.5) (2019-09-27)

**Note:** Version bump only for package @berlitz/globals





## [2.2.4](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.2.3...@berlitz/globals@2.2.4) (2019-09-10)

**Note:** Version bump only for package @berlitz/globals





## [2.2.3](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.2.2...@berlitz/globals@2.2.3) (2019-09-09)

**Note:** Version bump only for package @berlitz/globals





## [2.2.2](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.2.1...@berlitz/globals@2.2.2) (2019-08-22)

**Note:** Version bump only for package @berlitz/globals





## [2.2.1](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.2.0...@berlitz/globals@2.2.1) (2019-08-22)

**Note:** Version bump only for package @berlitz/globals





# [2.2.0](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.1.19...@berlitz/globals@2.2.0) (2019-07-31)


### Features

* **form:** add field.type title and 3/4 columns ([d7aa5ff](https://github.com/berlitz-global/max/commit/d7aa5ff))





## [2.1.19](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.1.18...@berlitz/globals@2.1.19) (2019-07-30)

**Note:** Version bump only for package @berlitz/globals





## [2.1.18](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.1.17...@berlitz/globals@2.1.18) (2019-07-17)


### Bug Fixes

* clean up according block ([f98e186](https://github.com/berlitz-global/max/commit/f98e186))





## [2.1.17](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.1.16...@berlitz/globals@2.1.17) (2019-07-15)

**Note:** Version bump only for package @berlitz/globals





## [2.1.16](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.1.15...@berlitz/globals@2.1.16) (2019-07-08)


### Bug Fixes

* **package-json:** update peer dependencies ([a02f791](https://github.com/berlitz-global/max/commit/a02f791))





## [2.1.15](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.1.14...@berlitz/globals@2.1.15) (2019-07-04)

**Note:** Version bump only for package @berlitz/globals





## [2.1.14](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.1.13...@berlitz/globals@2.1.14) (2019-07-04)

**Note:** Version bump only for package @berlitz/globals





## [2.1.13](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.1.12...@berlitz/globals@2.1.13) (2019-06-28)

**Note:** Version bump only for package @berlitz/globals





## [2.1.12](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.1.11...@berlitz/globals@2.1.12) (2019-06-25)

**Note:** Version bump only for package @berlitz/globals





## [2.1.11](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.1.10...@berlitz/globals@2.1.11) (2019-06-19)

**Note:** Version bump only for package @berlitz/globals





## [2.1.10](https://github.com/berlitz-global/max/compare/@berlitz/globals@2.1.9...@berlitz/globals@2.1.10) (2019-06-18)

**Note:** Version bump only for package @berlitz/globals
