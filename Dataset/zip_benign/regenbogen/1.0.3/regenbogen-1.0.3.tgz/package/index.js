var color = require('color'),
parse = require('color-parser');

function max(arr) {
    return Math.max.apply(Math, arr);
}
function min(arr) {
    return Math.min.apply(Math, arr);
}
function last(arr) {
    return arr[arr.length - 1];
}

/**
 * Map colors to color objects. This means that
 * we can accpet all input types accepted by
 * color.js as well as CSS colors
 *
 * @example
 * var color = toColorObject("rgb(255, 255, 255)")
 * var color = toColorObject({r: 255, g: 255, b: 255})
 * var color = toColorObject([255, 255, 255])
 * var color = toColorObject("white")
 * => {r:255, g: 255, b:255}
 *
 * @param {any} col
 * @return {Object.{r:int, g:int, b:int}}
 */
function toColorObject(col) {
    if (typeof col === 'undefined' || col === null)
        col = {r:255, g:255, b:255};

    if (typeof col === 'string')
        col = parse(col);

    if (Array.isArray(col))
        return color().rgb(col);

    return color(col);
}

/**
 * Create a function that will return a color when passed
 * a number. Colors can be passed as css color names,
 * css color strings, arrays and objects. The returned function
 * is perfectly suited to be used in Array.prototype.map.
 *
 * If you don't pass an array of color stops, regenbogen
 * will calculate the stops on its first use. If you dont use
 * it in Array.prototype.map, it won't be able to calculate it,
 * though, and use the defaults between 0 and 1 instead.
 *
 * @example
 *     var gradient = regenbogen(['black', 'white'],[0, 1]);
 *     gradient(0); // #000000
 *     gradient(1); // #ffffff
 *
 * @example
 *     var gradient = regenbogen(['red', 'green', 'blue']);
 *     gradient(0.5); // #00ff00
 *
 * Perfectly suited for use in Array.prototype.map:
 *     [0, 5, 1].map(regenbogen(['black', 'white']));
 *     // [#000000, #777777, #ffffff]
 *
 * @param {(string[]|array[]|{r, g, b})} colors
 * @param {number[]} stops
 * @return (number)=>string
 */

function regenbogen(colors, stops) {
    if (!colors)
        colors = 'default';

    if ('string' === typeof colors && (colors in regenbogen.defaults))
        colors = regenbogen.defaults[colors];

    if (!Array.isArray(colors) || colors.length < 2)
        throw new Error('First argument has to be empty or an array of at least two colors');

    /* map colors to color objects */
    colors = colors.map(toColorObject);

    var cache = [];

    return function farbe(pos, idx, arr) {
        /* return transparent when pos is null or undefined */
        if (typeof pos === 'undefined' || pos === null)
            return 'rgba(0,0,0,0)';

        var a, b, x, stop, mx, mn;

        /* calculate color stops */
        if (!stops || (stops.length !== colors.length)) {
            if (Array.isArray(arr)) {
                mn = min(arr);
                mx = max(arr);
                stops = [mn, (mx + mn) / 2, mx];
            }
            else {
                stops = Array(colors.length+1).join('0').split('').map(function(_,i,a){
                    return i === 0 ? 0 : i/(a.length-1);
                });
            }
        }

        if (cache[idx]) {
            a = cache[idx];
        } else if (pos <= stops[0]) {
            a = colors[0];
        } else if (pos >= last(stops)) {
            a = last(colors)
        } else {

            for (idx = 0; idx < stops.length; idx++) {

                stop = stops[idx];

                if (pos === stop) {
                    a = colors[idx];
                    break;
                }

                if (pos < stop) {
                    a = colors[idx-1];
                    b = colors[idx];
                    x = (pos - stops[idx-1]) / (stop - stops[idx-1]);
                    a = a.clone().mix(b, x);
                    break;
                }
            }
        }

        return a.rgbaString();
    };
};

regenbogen.defaults = {}

regenbogen.defaults.heatmap = ['blue', 'white', 'red'];
regenbogen.defaults.rainbow = ['red', 'green', 'blue'];
regenbogen.defaults.default = regenbogen.defaults.heatmap;

module.exports = regenbogen;
