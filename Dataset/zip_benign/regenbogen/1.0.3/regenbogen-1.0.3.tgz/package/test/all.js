var regenbogen = require('..');
var assert = require('assert');

var heatmap = regenbogen();

assert(heatmap(0) === 'rgba(0, 0, 255, 1)', heatmap(0));
assert(heatmap(0.5) === 'rgba(255, 255, 255, 1)');
assert(heatmap(1) === 'rgba(255, 0, 0, 1)');

var rgb = regenbogen(['red', [0,255,0], {r:0,g:0,b:255}]);
assert(rgb(0) === 'rgba(255, 0, 0, 1)');
assert(rgb(0.5) === 'rgba(0, 255, 0, 1)');
assert(rgb(1) === 'rgba(0, 0, 255, 1)');

var more = regenbogen(['red', 'white', 'blue'], [0, 2, 20]);
assert(more(0) === 'rgba(255, 0, 0, 1)');
assert(more(2) === 'rgba(255, 255, 255, 1)');
assert(more(20) === 'rgba(0, 0, 255, 1)');

console.log('all tests passed');
