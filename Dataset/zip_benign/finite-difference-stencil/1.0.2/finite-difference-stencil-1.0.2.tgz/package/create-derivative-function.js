'use strict'

module.exports = createDerivativeFunction (interiorScheme, lowerBoundarySchemes, upperBoundarySchemes, coefficients) {


}
