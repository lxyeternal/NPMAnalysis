# Shogun SDK Integration

# Overview

The Shogun SDK is a TypeScript library that enables cross-chain swaps and transfers between EVM chains and Solana. It provides quote fetching, transaction execution, and fee management capabilities.

## Installation

```
npm install @0xshogun/sdk
```

or

```
yarn add @0xshogun/sdk
```

## Features

- Cross-chain token swaps between EVM chains and Solana
- Quote fetching for optimal swap rates
- Transaction execution management
- Fee estimation and management
- Balance tracking across chains

## Supported Chains

- Ethereum
- Base
- Arbitrum
- Binance Smart Chain
- Berachain
- Sonic
- Solana

## Requirements

- Node.js 16 or higher
- TypeScript 4.5 or higher

## Quick Start

```
import { ShogunQuoteApiClient } from '@0xshogun/sdk';
```

// Initialize the client

```
const client = new ShogunQuoteApiClient(
  'YOUR_API_KEY', // Dextra API key
  'https://api.shogun.com' // Dextra API endpoint
);
```

// Fetch a quote

```
const quoteParams: QuoteParams = {
  srcChain: 1, // Token IN chain ID
  destChain: 8453, // Token Out chain ID
  srcToken: '0x...', // Source token address
  destToken: '...', // Destination token address
  amount: '1000000000000000000', // Amount in smallest unit (e.g. wei)
  senderAddress: '0x...', // Sender's wallet address
  affiliateWallet: '0x...', // Affiliate EVM or Solana wallet address
  affiliateFee: '1', // Affiliate fee in percent as 1%
  slippage: 0.5, // Slippage percentage
  destinationAddress: '...', // Destination wallet address
  dstChainOrderAuthorityAddress: '...' // Destination chain order authority address
  dynamicSlippage: true // Or false, only for Solana transactions
};

const quote = await client.fetchQuote(quoteParams);
```

## Balance Checking

The SDK provides balance checking capabilities for both EVM and Solana chains through the ShogunBalancesApiClient.

```
import { ShogunBalancesApiClient } from '@0xshogun/sdk';

// Initialize the balances client
const balancesClient = new ShogunBalancesApiClient('YOUR_API_KEY'); // YOUR_API_KEY is CODEX API key

// Check EVM wallet balances
const evmBalances = await balancesClient.getEvmWalletBalance('0x...');

// Get token info including prices
const tokenInfo = await balancesClient.getTokenInfo(
  evmBalances,
  '0x...', // wallet address
);

// Check Solana token balances
const solanaBalances = await balancesClient.getSolanaTokenBalances('...');

// Get USD price for a specific token
const tokenPrice = await balancesClient.getTokenUSDPrice(
  '0x...', // token address
  1 // chain ID
);

// Validate addresses
const isValid = balancesClient.isValidAddress('0x...');
```

Development

# Install dependencies

npm install

# Build the package

npm run build

# Run tests

npm test

# Format code

npm run format

# Lint code

npm run lint

Contributing
Contributions are welcome! Please read our Contributing Guide for details on our code of conduct and the process for submitting pull requests.
