import React from "react";
import { StyleProp, ViewStyle } from "react-native";
declare type AnimationConfig = {
    easing?: (value: number) => number;
    duration?: number;
    delay?: number;
    scale?: number;
};
declare type StarRatingProps = {
    rating: number;
    onChange: (rating: number) => void;
    minRating?: number;
    color?: string;
    emptyColor?: string;
    maxStars?: number;
    starSize?: number;
    enableHalfStar?: boolean;
    style?: StyleProp<ViewStyle>;
    starSpace?: number;
    animationConfig?: AnimationConfig;
    testID?: string;
    viewOnly?: boolean;
};
declare const StarRating: React.FC<StarRatingProps>;
export default StarRating;
