/**
 * TODO: This will enable a filter object to be passed in when playing a sound collection so that items
 * can be selected based on the value of properties on the filter object
 */
export default class SoundCollectionFilter {
    test(value: string): boolean;
}
