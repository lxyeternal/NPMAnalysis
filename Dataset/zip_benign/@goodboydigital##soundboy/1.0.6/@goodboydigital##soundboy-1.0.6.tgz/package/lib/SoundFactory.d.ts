import { SoundInstance, SoundInstanceOptions } from './SoundInstance';
/**
 * Contains everything required to register and create a sound
 */
export interface SoundOptions {
    /**
     * the id used to get an instance of this sound.
     * Ids for all sounds and collections must be completely unique.
     */
    id: string;
    /**
     * path or paths (if using multiple filetypes) to the source of the sound.
     * A path without an extension will currently automatically be registered with
     * .mp3 and .ogg extensions by default
     */
    src: string | string[];
    /**
     * if set to true sound file will be requested immediately, otherwise not until sound is first played
     */
    preload?: boolean;
    /**
     * if set to true, sound can start playing before it has completely loaded
     */
    stream?: boolean;
    /**
     * Set to true to indicate that sound loop indefinitely.
     * Can be overridden on individual sound instances by options passed in when creating the sound instance.
     */
    loop?: boolean;
    /**
     * The base volume for all instances of this sound.
     * This is immutable and is effectively altering the volume of the original audio source.
     * The actual sound volume will be the product of the channel volume, the sound instance volume, and this value.
     */
    volume?: number;
}
/**
 * provides an interface for registering sound details and creating instances of sounds to play
 */
export interface SoundFactory {
    /**
     * Register a sound so we can create instances of it
     * @param options - options to register the sound with
     */
    registerSound(options: SoundOptions): void;
    /**
     * Provides a SoundInstance from the specified id, with parameters for this particular instance set from options
     * @param id - the id of the sound to create an instance of
     * @param options - options to use in creating the sound instance
     */
    factorySoundInstance(id: string, baseVolume: number, instanceOptions: SoundInstanceOptions): SoundInstance;
}
