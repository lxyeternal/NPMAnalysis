import { SoundFactory, SoundOptions } from '../SoundFactory';
import { SoundInstance, SoundInstanceOptions } from '../SoundInstance';
import { Howl } from 'howler';
export declare class HowlerSoundInstance extends SoundInstance {
    private uid;
    private howl;
    constructor(id: string, baseVolume: number, howl: Howl, options: SoundInstanceOptions);
    set panning(value: number);
    protected _seek(seconds: number): void;
    protected _setCalculatedVolume(value: number): void;
    protected _setCalculatedRate(value: number): void;
    protected _pause(): void;
    protected _resume(): void;
    protected _stop(): void;
    protected _addListeners(): void;
    protected _removeListeners(): void;
    get rawObject(): {
        id: number;
        howl: Howl;
    };
}
export declare class HowlerSoundFactory implements SoundFactory {
    private soundsById;
    registerSound(options: SoundOptions): void;
    factorySoundInstance(id: string, baseVolume: number, instanceOptions?: SoundInstanceOptions): SoundInstance;
}
