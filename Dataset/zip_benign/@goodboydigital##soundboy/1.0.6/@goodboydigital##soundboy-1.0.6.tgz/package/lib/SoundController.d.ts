import { Signal } from 'typed-signals';
interface SoundControllerState {
    volume: number;
    paused: boolean;
    muted: boolean;
    rate: number;
}
/**
 * Hides away the complexities of managing accumulated state across the hierarchy of SoundBoy,
 * it's SoundChannels and their SoundInstances, all of which extend this base class.
 *
 * A SoundController is responsible of keeping track of it's own internal state, calculating it's
 * accumulated state based on the properties of it's ancestors, and propogating this state down to
 * it's descendent SoundControllers, until reaching any SoundInstances, which will apply the final
 * calculated state to the actual sound.
 */
export declare class SoundController {
    readonly muteChanged: Signal<(boolean: any) => void>;
    private _children;
    protected internal: SoundControllerState;
    protected inherited: SoundControllerState;
    /**
     * the internal volume of this instance, actual volume will depend on inherited state from ancestors
     */
    get volume(): number;
    set volume(value: number);
    /**
     * the internal rate of this instance, actual rate will depend on inherited state from ancestors
     */
    get rate(): number;
    set rate(value: number);
    /**
     * the internal mute state of this instance, actual mute state will also depend on inherited state
     * muted sounds will still play, so timing and callback
     * execution will remain consistent regardless of muted state
     */
    get muted(): boolean;
    set muted(value: boolean);
    mute(value?: boolean): void;
    /**
     * the internal pause state of this instance, actual pause state may also depend on inherited state from ancestors
     */
    get paused(): boolean;
    set paused(value: boolean);
    /**
     * pause this instance
     */
    pause(): void;
    /**
     * unpause this instance
     */
    resume(): void;
    /**
     * add a child, children will calculate their volume, paused and muted state
     * based on the state of all of their ancestors, and propogate this state down
     * to any descendents
     *
     * @param child - the sound controller to add as a child
     * @returns
     */
    addChild(child: SoundController): boolean;
    /**
     * removes a child sound controller
     *
     * @param child - the child to remove
     */
    removeChild(child: SoundController): void;
    protected propogateState(): void;
    protected propogateVolume(): void;
    protected propogatePaused(): void;
    protected propogateMuted(): void;
    protected propogateRate(): void;
    protected propogateValue(accumulator: (child: SoundController) => void): void;
    /**
     * Set the inherited volume and propogate it further down the hierarchy, shouldn't be used except internally within
     * the SoundController hierarchy
     *
     * @param value - the volume to inherit
     * @internal
     */
    inheritVolume(value: number): void;
    /**
     * Set the inherited rate and propogate it further down the hierarchy, shouldn't be used except internally within
     * the SoundController hierarchy
     *
     * @param value - the rate to inherit
     * @internal
     */
    inheritRate(value: number): void;
    /**
     * Set the inherited muted state and propogate it further down the hierarchy, shouldn't be used except internally within
     * the SoundController hierarchy
     *
     * @param value - the muted state to inherit
     * @internal
     */
    inheritMuted(value: boolean): void;
    /**
     * Set the inherited paused state and propogate it further down the hierarchy, shouldn't be used except internally within
     * the SoundController hierarchy
     *
     * @param value - the paused state to inherit
     * @internal
     */
    inheritPaused(value: boolean): void;
    /**
     * Set the inherited state and propogate it further down the hierarchy, shouldn't be used except internally within
     * the SoundController hierarchy
     *
     * @param value - the state to inherit
     * @internal
     */
    inheritState(value: SoundControllerState): void;
    protected get accumulatedVolume(): number;
    protected get accumulatedPaused(): boolean;
    protected get accumulatedMuted(): boolean;
    protected get accumulatedRate(): number;
    protected get accumulatedState(): SoundControllerState;
    /**
     * fade volume from it's current value to the specified value
     *
     * @param targetVolume - target volume value
     * @param duration - in seconds, of fade
     * @param  onComplete - optional callback to execute when fade has completed
     */
    fadeTo(targetVolume: number, duration: number, onComplete?: () => void): void;
    /**
     * fade volume from 0 to 1
     *
     * @param duration - in seconds, of fade
     * @param onComplete - optional callback to execute when fade has completed
     */
    fadeIn(duration: number, onComplete?: () => void): void;
    /**
     * fade volume to 0
     *
     * @param duration - in seconds, of fade
     * @param onComplete - optional callback to execute when fade has completed
     */
    fadeOut(duration: number, onComplete?: () => void): void;
}
export {};
