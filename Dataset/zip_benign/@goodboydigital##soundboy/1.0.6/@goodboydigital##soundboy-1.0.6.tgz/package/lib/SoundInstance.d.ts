import { Signal } from 'typed-signals';
import { SoundController } from './SoundController';
export interface SoundInstanceOptions {
    /**
     * number of times to loop the sound, defaults to 1, meaning the sound will play once. set to true for infinite loops
     */
    loops?: number | boolean;
    /**
     * initial instance volume, defaults to 1
     */
    volume?: number;
    /**
     * initial panning value, defaults to 0
     */
    panning?: number;
    /**
     * initial rate, defaults to 1
     */
    rate?: number;
    /**
     * called when sound (including any loops) completes
     */
    callback?: (sound: SoundInstance) => void;
    /**
     * scope for callback, if you're not using a bound or arrow function
     *
     */
    callbackScope?: Record<string, any>;
    /**
     * if set to true callback will be called if the sound is interrupted by another sound replacing it on a single file sound channel
     *
     */
    callbackOnInterrupt?: boolean;
    /**
     * set to true to only play sound if no sound is currently playing on a single file sound channel
     *
     */
    wontInterrupt?: boolean;
}
/**
 * A representation of a single sound
 * When created a sound will play
 * Unless the sound is looping, once complete or stopped, sound is disposed - event handlers removed etc
 *
 */
export declare abstract class SoundInstance extends SoundController {
    /**
     * dispatches when the sound has fully completed, including any additional loops
     */
    readonly completed: Signal<(soundInstance: SoundInstance) => void>;
    /**
     * dispatches at the start of each additional loop
     */
    readonly looped: Signal<(soundInstance: SoundInstance) => void>;
    /**
     * dispatches when sound is being disposed, after it has stopped and all other signals have been dispatched,
     * this is for information only, the sound should not be re-used at this point
     */
    readonly disposed: Signal<(soundInstance: SoundInstance) => void>;
    private _id;
    private _baseVolume;
    protected _rawObject: any;
    private loopsRemaining;
    private _loop;
    private _keepAlive;
    private callback;
    private callbackScope;
    private callbackOnInterrupt;
    protected canPropogate: boolean;
    /**
     * this should be called when the sound finishes playing, concrete implementations will need ot wire this up
     */
    protected boundOnCompleteHandler: () => void;
    /**
     * id the sound was registered with
     */
    get id(): string;
    /**
     *
     * @param id - the id this sound was registered with
     * @param baseVolume - the volume this sound was registered with, defaults to 1. The base volume is never modified, so is
     * only used to set the overall level of a sound relative to other sounds.
     */
    constructor(id: string, baseVolume?: number);
    /**
     * this needs to be called at the end of a subclass' constructor so we can configure
     * the sound based on the options passed into the constructor
     * @param options - options to initialise sound with
     */
    protected postConstructor(options?: SoundInstanceOptions): void;
    /**
     * seek to the specified position
     *
     */
    seek(seconds: number): void;
    /**
     * seek to the specified position and pause
     *
     */
    cue(seconds: number): void;
    /**
     * restart sound from the beginning
     */
    restart(): void;
    /**
     * This should only be used by the SoundChannel, so we can execute callback if we are supposed to
     */
    interrupt(): void;
    /**
     * stops a sound. Once stopped, a sound is disposed of, unless a callback restarts, seeks or cues the sound
     *
     */
    stop(executeCallback?: boolean): void;
    /**
     * overrides super class method, this is the end of the propogation road, we need to actually set the volume of the sound
     */
    protected propogateVolume(): void;
    /**
     * override super class method, implement muted state
     */
    protected propogateMuted(): void;
    /**
     * override super class method, implement paused state
     */
    protected propogatePaused(): void;
    /**
     * override super class method, set the calculated rate on the sound
     */
    protected propogateRate(): void;
    /**
     * override super class method, implement the entire state on the sound
     */
    protected propogateState(): void;
    protected _onCompleteHandler(): void;
    /**
     * executes callback if there is one
     */
    private executeCallback;
    /**
     * tidy up, after this should not be used any more
     */
    private dispose;
    /**
     * set the actual sound volume, based on internal and any inherited state
     * @param value - the actual volume to set
     */
    protected abstract _setCalculatedVolume(value: number): any;
    /**
     * set the actual sound rate, based on internal and any inherited state
     * @param value - the actual rate to set
     */
    protected abstract _setCalculatedRate(value: number): any;
    /**
     * pause the sound instance
     */
    protected abstract _pause(): void;
    /**
     * resume the sound inatance
     */
    protected abstract _resume(): void;
    /**
     * stop the sound instance
     */
    protected abstract _stop(): void;
    /**
     * seek to the specified position
     * @param seconds - position to seek to
     */
    protected abstract _seek(seconds: number): void;
    /**
     * add listeners for:
     *  * end of sound
     *  * completion of sound (all loops done)
     */
    protected abstract _addListeners(): void;
    /**
     * tidy up - remove all listeners added in _addListeners
     */
    protected abstract _removeListeners(): void;
    protected abstract get rawObject(): any;
    abstract set panning(value: number);
    abstract get panning(): number;
    protected get hasLoopsRemaining(): boolean;
}
