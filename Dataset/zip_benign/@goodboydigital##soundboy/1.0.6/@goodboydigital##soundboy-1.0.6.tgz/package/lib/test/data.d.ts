import { SoundOptions } from "../SoundFactory";
import { SoundCollectionData } from "../SoundCollection";
declare const _default: {
    sounds: SoundOptions[];
    collections: SoundCollectionData[];
};
export default _default;
