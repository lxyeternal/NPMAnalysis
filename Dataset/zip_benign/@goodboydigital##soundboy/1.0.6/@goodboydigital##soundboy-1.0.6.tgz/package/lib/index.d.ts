import SoundBoy from './SoundBoy';
import SoundChannel from './SoundChannel';
import { SoundCollection } from './SoundCollection';
import { SoundInstance } from './SoundInstance';
export default SoundBoy;
export { SoundChannel, SoundInstance, SoundCollection, };
