import { SoundCollection, SoundCollectionData } from './SoundCollection';
import { SoundFactory, SoundOptions } from './SoundFactory';
import { SoundInstance, SoundInstanceOptions } from './SoundInstance';
import { Signal } from 'typed-signals';
import SoundChannel from './SoundChannel';
import { SoundController } from './SoundController';
/**
 * registers, plays and provides various mechanisms for controlling sounds on multiple channels
 */
declare class SoundBoy extends SoundController {
    static readonly CHANNEL_SFX: string;
    static readonly CHANNEL_VO: string;
    static readonly CHANNEL_MUSIC: string;
    get systemMuteChanged(): Signal<(boolean: any) => void>;
    readonly systemPauseChanged: Signal<(boolean: any) => void>;
    protected channelsById: Map<string, SoundChannel>;
    protected soundsById: Map<string, SoundOptions>;
    protected collectionsById: Map<string, SoundCollection>;
    protected preload: boolean;
    protected soundFactory: SoundFactory;
    protected extensions: string[];
    protected system: SoundController;
    constructor();
    /**
     * Register a sound with the provided options
     *
     * @param options - specifies the id and url(s), also determines the options for preload, as well as default options for all sound instances created for this sound.
     *                  volume determines the maximum volume for the sound, a SoundInstance created from this sound will have this volume when it's
     *                  volume is set to 1.
     *
     */
    registerSound(options: SoundOptions): void;
    /**
     * Play a sound on the default (sfx) channel
     *
     * @param id - id the sound was registered with
     * @param options - used to initialise the sound
     * @returns a sound instance
     */
    play(id: string, options?: SoundInstanceOptions): SoundInstance;
    /**
     * Play a sound on the SFX channel
     *
     * @param id - id the sound was registered with
     * @param options - options used to initialise the sound
     * @returns a sound instance
     */
    playSfx(id: string, options?: SoundInstanceOptions): SoundInstance;
    /**
     * Play a sound on the music channel
     *
     * @param id - id the sound was registered with
     * @param options - options used to initialise the sound
     * @returns a sound instance
     */
    playMusic(id: string, options?: SoundInstanceOptions): SoundInstance;
    /**
     * Play a sound on the VO channel
     *
     * @param id - id the sound was registered with
     * @param options - options used to initialise the sound
     * @returns a sound instance
     */
    playVo(id: string, options?: SoundInstanceOptions): SoundInstance;
    /**
     * Play a sound on the specified channel,
     * all requests to play a sound are eventually routed through this method
     *
     * @param id - id the sound was registered with
     * @param channelId - id of the channel
     * @param options - options used to initialise the sound
     * @returns a sound instance
     */
    playOnChannel(id: string, channelId: string, options?: SoundInstanceOptions): SoundInstance;
    /**
     * the global muted state, should only be used to respond to system level events
     * such as changes in app/browser tab visibility
     */
    get systemMuted(): boolean;
    set systemMuted(value: boolean);
    systemMute(mute?: boolean): void;
    /**
     * the global paused state, should only be used to respond to system level events
     * such as changes in app/browser tab visibility
     */
    get systemPaused(): boolean;
    set systemPaused(value: boolean);
    systemPause(pause?: boolean): void;
    /**
     * stop all sounds, callbacks will not be executed
     */
    stop(): void;
    /**
     * Register a sound collecion using the provided data
     * e.g.
     * ```
     * SoundBoy.registerCollection({
     *    id: 'gun-shot',
     *    selectionMode: SELECTION_MODE.RANDOM,
     *    sequenceMode: SEQUENCE_MODE.SINGLE,
     *    children: [
     *        { id: 'shot1' },
     *        { id: 'shot2' },
     *        { id: 'shot3' },
     *        { id: 'shot4' },
     *        { id: 'shot5' },
     *    ]
     * });
     * SoundBoy.playSfx('gun-shot');
     * // will play a single gun shot, randomly selected from the children
     *
     * SoundBoy.registerCollection({
     *    id: 'count-to-5',
     *    selectionMode: SELECTION_MODE.LINEAR,
     *    sequenceMode: SEQUENCE_MODE.GROUP,
     *    children: [
     *        { id: 'number1' },
     *        { id: 'number2' },
     *        { id: 'number3' },
     *        { id: 'number4' },
     *        { id: 'number5' },
     *    ]
     * });
     * SoundBoy.playVo('count-to-5', { loops: true });
     * // will count from one to five, in order, over and over again
     *
     * Because they behave just like a single sound, SoundCollections can also be nested,
     * just add a child with the registered collection id just as you would a normal sound.
     *```
     * @param data - sound collection definition data
     */
    registerCollection(data: SoundCollectionData): void;
    /**
     * add a new sound channel with the specified id
     *
     * @param id - id of new channel
     * @returns the newly created sound channel
     */
    addChannel(id: string): SoundChannel;
    /**
     * return the SoundChannnel registered with the given id
     *
     * @param id - id the channel was registered with
     * @returns the sound channel
     */
    getChannelById(id: string): SoundChannel;
    /**
     * a channel to play music on, by default this is a single file sound channel with crossFade set to 2 seconds
     *
     * @readonly
     */
    get musicChannel(): SoundChannel;
    /**
     * a channel to play sfx on
     *
     * @readonly
     */
    get sfxChannel(): SoundChannel;
    /**
     * a channel to play vo on, by default this is a single file sound channel
     *
     * @readonly
     */
    get voChannel(): SoundChannel;
}
declare const _default: SoundBoy;
export default _default;
