import SoundCollectionFilter from './SoundCollectionFilter';
/**
 * Used to determine if sounds are selected in RANDOM or LINEAR order
 */
export declare enum SELECTION_MODE {
    /**
     * sounds in the collection will be picked in a random order
     */
    RANDOM = "random",
    /**
     * sounds in the collection will be picked in order
     */
    LINEAR = "linear"
}
/**
 * Used to determine whether playing a collection will pick a SINGLE sound to play, or play all the valid sounds in the collection
 * one after the other as a GROUP
 *
 */
export declare enum SEQUENCE_MODE {
    /**
     * sounds in the collection will be picked and played one at a time
     */
    SINGLE = "single",
    /**
     * one or more sounds provided by the collection data will play in sequence as if they were a single sound instance
     */
    GROUP = "group"
}
/**
* A SoundCollection represents one or more sounds that can be treated as a single instance and played back in a variety of ways.
* Multiple sounds can be grouped together and played one at a time or in sequence, randomly or in order, and (TODO:) filters can be
* used to apply complex logic to the selection of sounds.
**/
export interface SoundCollectionData {
    id?: string;
    selectionMode?: SELECTION_MODE;
    sequenceMode?: SEQUENCE_MODE;
    filter?: string;
    children?: SoundCollectionData[];
}
export declare class SoundCollection {
    id: string;
    selectionMode: string;
    sequenceMode: string;
    filter: string;
    private children;
    private matchingChildren;
    private usedChildren;
    constructor(data: SoundCollectionData);
    addItem(item: SoundCollection): void;
    removeAll(): void;
    /**
    * returns an array of one or more sound ids that should be played in sequence
    **/
    getSequence(filter?: SoundCollectionFilter): string[];
    /**
    * returns the next valid item in this collection
    **/
    getItem(filterItem?: SoundCollectionFilter): SoundCollection;
    get playedAll(): boolean;
    get hasChildren(): boolean;
    get numChildren(): number;
    get singleMode(): boolean;
    get parent(): SoundCollection;
    private resetUsedChildren;
    private applyFilter;
    private setMatchingChildren;
    private buildSequence;
}
