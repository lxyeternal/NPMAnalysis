import { SoundController } from './SoundController';
import { SoundInstance } from './SoundInstance';
/**
 * A SoundChannel provides a way of playing back and controlling multiple sounds.
 * Volume, pause
 */
export default class SoundChannel extends SoundController {
    private sounds;
    private _singlefile;
    private _crossFadeDuration;
    /**
     * Adds a sound instance to this channel.
     *
     * @param sound - sound instance to add to channel
     */
    addSound(sound: SoundInstance): void;
    /**
     * If set to true, this channel will only play one sound at a time.
     * A new sound added to the channel will interrupt and stop any existing sound on the channel,
     * unless the sound was played with it's options.wontInterrupt set to false
     */
    set singleFile(value: boolean);
    /**
     * duration of cross fade between sounds on a single file channel
     */
    set crossFadeDuration(value: number);
    /**
     * Will playing a sound on this channel interrupt another sound?
     *
     * @readonly
     */
    get wouldBeInterrupted(): boolean;
    /**
     * restart all sounds on the channel
     */
    restart(): void;
    /**
     * do anything you like to all sounds on the channel
     *
     * @param callback - the function to execute on each sound instance
     */
    forEach(callback: (sound: SoundInstance) => void): void;
    /**
     * stops a sound from playing, this will kill the sound completely,
     * if you want to maintain a reference to the sound then use pause and restart/resume
     */
    stop(executeCallbacks?: boolean): void;
    private removeSound;
}
