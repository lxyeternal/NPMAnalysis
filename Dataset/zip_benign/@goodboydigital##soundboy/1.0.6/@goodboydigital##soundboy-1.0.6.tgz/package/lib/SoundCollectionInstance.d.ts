import { SoundInstance, SoundInstanceOptions } from './SoundInstance';
import { SoundCollection } from './SoundCollection';
/**
 * A SoundInstance that under the hood plays one or more sounds in sequence from a SoundCollection data object.
 * Its behaviour should be indistinguishable from that of a normal SoundInstance, the only limitation being that
 * seeking will not work, unless used to restart the sound instance from the beginning.
 */
export declare class SoundCollectionInstance extends SoundInstance {
    private collection;
    private ids;
    private currentIndex;
    private channel;
    private currentOptions;
    private currentSoundInstance;
    constructor(id: string, collection: SoundCollection, channel: string, options: SoundInstanceOptions);
    /**
     * resets current index and refreshes ids to play from collection data
     */
    private _initFromCollection;
    private _playNext;
    get volume(): number;
    set volume(value: number);
    protected _setCalculatedVolume(): void;
    protected _setCalculatedRate(): void;
    protected _pause(): void;
    protected _resume(): void;
    protected _stop(): void;
    protected _seek(seconds: number): void;
    protected _addListeners(): void;
    protected _removeListeners(): void;
    protected rawObject: any;
    set panning(value: number);
    get panning(): number;
    set rate(value: number);
    get rate(): number;
}
