'use strict';

var _InlineAnimation = require('./lib/InlineAnimation.js');

var _InlineAnimation2 = _interopRequireDefault(_InlineAnimation);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = {
	InlineAnimation: _InlineAnimation2.default
};
