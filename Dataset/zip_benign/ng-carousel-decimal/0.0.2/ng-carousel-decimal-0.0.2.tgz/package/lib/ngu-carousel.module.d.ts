export declare class NguCarouselModule {
}
