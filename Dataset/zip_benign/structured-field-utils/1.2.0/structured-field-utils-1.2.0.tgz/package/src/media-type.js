/*!
 *  Copyright (c) 2024, Rahul Gupta
 *
 *  This Source Code Form is subject to the terms of the Mozilla Public
 *  License, v. 2.0. If a copy of the MPL was not distributed with this
 *  file, You can obtain one at http://mozilla.org/MPL/2.0/.
 *
 *  SPDX-License-Identifier: MPL-2.0
 */
import {
  sortByParameters,
  sortByQuality,
  containsParameter,
} from "./common.js";

const TOKEN = "[-a-zA-Z0-9!#$%^&*_+{}\\|'.`~]+";
const MEDIA_TYPE = new RegExp(`^(${TOKEN})/(${TOKEN})$`);

/**
 * Splits a media-type string/token into its type and subtype components.
 *
 * @param {string} mediaType
 * @returns {string[]}
 */
function split(mediaType) {
  const parts = MEDIA_TYPE.exec(mediaType);
  if (!parts) {
    return [];
  }
  parts.shift();
  return parts.map((t) => t.toLowerCase());
}

/**
 * Sorts an array of media-types (in the structured fields format) based on HTTP
 * rules specified in [RFC9110].
 *
 * @example
 *   import { parseList } from "structured-headers";
 *   import { mediaType } from "sf-utils";
 *   const parsedAccept = parseList(
 *     "text/html;level=3;q=0.7, text/html;q=0.7, text/plain;q=0.5, text/*;q=0.1",
 *   );
 *   const sortedAccept = mediaType.sort(parsedAccept);
 *
 * @param {import("./common").Item[]} types
 * @returns {import("./common").Item[]}
 */
function sort(types) {
  return types.slice().sort(comparator);
}

/**
 * Compares the priority of two media-types based on their quality values,
 * type/subtype specificity, and parameters.
 *
 * @param {import("./common").Item} a
 * @param {import("./common").Item} b
 * @returns {number}
 */
function comparator(a, b) {
  return (
    sortByQuality(a[1].get("q"), b[1].get("q")) ||
    sortByType(a[0], b[0]) ||
    sortByParameters(a[1], b[1])
  );
}

/**
 * Compares the priority of two media-types by specificity.
 *
 * @param {import("./common").BareItem} a
 * @param {import("./common").BareItem} b
 * @returns {number}
 */
function sortByType(a, b) {
  const [aType, aSubtype] = split(a.toString());
  const [bType, bSubtype] = split(b.toString());
  // RFC 9110 does not speak of suffix ordering. We ignore that for now.
  if (aType == bType && aSubtype == bSubtype) return 0;
  if (aType == "*" && aSubtype == "*") return 1;
  if (bType == "*" && bSubtype == "*") return -1;
  if (aSubtype == "*" && bSubtype == "*") return 0;
  if (aSubtype == "*") return 1;
  if (bSubtype == "*") return -1;
  return 0;
}

/**
 * Compares requested media-type with an allowed media-type to determine if they
 * match based on type, subtype, and parameters. If there are any parameter
 * mismatches, it returns a Map containing the mismatched parameters. Otherwise
 * it returns a boolean.
 *
 * @example
 *   import { parseList, Token } from "structured-headers";
 *   import { mediaType } from "sf-utils";
 *   const parsedAccept = parseList("text/html;level=3;q=0.7, text/html;q=0.7, text/plain;q=0.5, text/*;q=0.1");
 *   const matched = mediaType.match(parsedAccept[3], [new Token("text/html"), new Map([["level", 2]])]]);
 *
 * @param {import("./common").Item} req
 * @param {import("./common").Item} allowed
 * @returns {boolean | import("./common").Parameters}
 */
function match(req, allowed) {
  const [reqType, reqSubtype] = split(req[0].toString());
  const [allowedType, allowedSubtype] = split(allowed[0].toString());

  return (
    (reqType == "*" || allowedType == reqType) &&
    (reqSubtype == "*" || allowedSubtype == reqSubtype) &&
    containsParameter(req[1], allowed[1])
  );
}

export { match, sort };
