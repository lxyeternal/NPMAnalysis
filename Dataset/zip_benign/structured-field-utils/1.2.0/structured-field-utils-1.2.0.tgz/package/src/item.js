/*!
 *  Copyright (c) 2024, Rahul Gupta
 *
 *  This Source Code Form is subject to the terms of the Mozilla Public
 *  License, v. 2.0. If a copy of the MPL was not distributed with this
 *  file, You can obtain one at http://mozilla.org/MPL/2.0/.
 *
 *  SPDX-License-Identifier: MPL-2.0
 */
import {
  sortByParameters,
  sortByQuality,
  matchBareItem,
  containsParameter,
} from "./common.js";

/**
 * Sorts an array of items (in the "structured-headers" format) based on HTTP
 * rules specified in [RFC9110].
 *
 * @example
 *   import { parseList } from "structured-headers";
 *   import { mediaType } from "sf-utils";
 *   const parsedList = parseList(
 *     `foo;param="something";q=0.7, bar;q=0.5, baz;q=0.6`,
 *   );
 *   const sortedList = item.sort(parsedAccept);
 *
 * @param {import("./common").Item[]} types
 * @returns {import("./common").Item[]}
 */
function sort(types) {
  return types.slice().sort(comparator);
}

/**
 * Compares the priority of two media-types based on their quality values,
 * type/subtype specificity, and parameters.
 *
 * @param {import("./common").Item} a
 * @param {import("./common").Item} b
 * @returns {number}
 */
function comparator(a, b) {
  return (
    sortByQuality(a[1].get("q"), b[1].get("q")) || sortByParameters(a[1], b[1])
  );
}

/**
 * Compares requested item with an allowed item to determine if they match If
 * there are any parameter mismatches, it returns a Map containing the
 * mismatched parameters. Otherwise it returns a boolean.
 *
 * @example
 *   import { parseList } from "structured-headers";
 *   import { item } from "sf-utils";
 *   const parsedList = parseList(`"foo";param="something";q=0.7, "bar";q=0.7, "baz";q=0.5`);
 *   const item.match = contains(parsedList[0], ["foo", new Map([["param", "nothing"]])]);
 *
 * @param {import("./common").Item} req
 * @param {import("./common").Item} allowed
 * @returns {boolean | import("./common").Parameters}
 */
function match(req, allowed) {
  return (
    matchBareItem(req[0], allowed[0]) && containsParameter(req[1], allowed[1])
  );
}

export { match, sort };
