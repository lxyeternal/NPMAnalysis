/*!
 *  Copyright (c) 2024, Rahul Gupta
 *
 *  This Source Code Form is subject to the terms of the Mozilla Public
 *  License, v. 2.0. If a copy of the MPL was not distributed with this
 *  file, You can obtain one at http://mozilla.org/MPL/2.0/.
 *
 *  SPDX-License-Identifier: MPL-2.0
 */

/**
 * @typedef {import("structured-headers").Item} Item
 *
 * @typedef {import("structured-headers").BareItem} BareItem
 *
 * @typedef {import("structured-headers").Parameters} Parameters
 */

/**
 * Compares the quality values of two items.
 *
 * @param {BareItem | undefined} a
 * @param {BareItem | undefined} b
 * @returns {number}
 */
function sortByQuality(a, b) {
  return extractQuality(b) - extractQuality(a);
}

/**
 * Extracts the quality value x1000 from a given input.
 *
 * @param {BareItem | undefined} q
 * @returns {number}
 */
function extractQuality(q) {
  if (q === undefined) return 1000;
  const qNum =
    typeof q === "number" ? q : typeof q === "string" ? Number(q) : 0;
  if (qNum === 1) return 1000;
  if (qNum > 0 && qNum < 1) {
    return Math.floor(qNum * 1000);
  }
  return 0;
}

/**
 * Compares the priority of two items by parameter count.
 *
 * @param {Parameters} a
 * @param {Parameters} b
 * @returns {number}
 */
function sortByParameters(a, b) {
  return b.size - countQ(b.has("q")) - a.size + countQ(a.has("q"));
}

/**
 * Returns count of `q` parameter.
 *
 * @param {boolean} a
 * @returns {number}
 */
function countQ(a) {
  return a ? 1 : 0;
}

/**
 * Compares requested BareItem with an allowed BareItem to determine if they
 * match
 *
 * @param {import("./common").BareItem} req
 * @param {import("./common").BareItem} allowed
 * @returns {boolean}
 */
function matchBareItem(req, allowed) {
  switch (typeof req) {
    case "number":
    case "string":
    case "boolean":
      return req === allowed;
    case "object":
      return (
        (req instanceof Date &&
          allowed instanceof Date &&
          req.valueOf() === allowed.valueOf()) ||
        req.toString() === allowed.toString()
      );
    default:
      return false;
  }
}

/**
 * Check if the parameters on the requested item exist on and are the same as
 * that on the allowed item (but not the other way around). If all parameters in
 * the requested item exist on the allowed item and there is only mismatch of
 * parameter values, the mismatched parameters are returned. Parameter `q` is
 * ignored.
 *
 * @param {Parameters} req
 * @param {Parameters} allowed
 * @returns {boolean | Parameters}
 */
function containsParameter(req, allowed) {
  const misMatched = new Map();
  for (const key of req.keys()) {
    if (key === "q") {
      continue;
    }
    if (allowed.has(key)) {
      const reqValue = /** @type BareItem */ (req.get(key));
      const allowedValue = /** @type BareItem */ (allowed.get(key));
      if (!matchBareItem(reqValue, allowedValue)) {
        misMatched.set(key, reqValue);
      }
      continue;
    }
    return false;
  }
  return misMatched.size ? misMatched : true;
}

export {
  sortByParameters,
  sortByQuality,
  extractQuality,
  matchBareItem,
  containsParameter,
};
