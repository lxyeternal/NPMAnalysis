export type Item = import("structured-headers").Item;
export type BareItem = import("structured-headers").BareItem;
export type Parameters = import("structured-headers").Parameters;
export function sortByParameters(a: Parameters, b: Parameters): number;
export function sortByQuality(a: BareItem | undefined, b: BareItem | undefined): number;
export function extractQuality(q: BareItem | undefined): number;
export function matchBareItem(req: import("./common").BareItem, allowed: import("./common").BareItem): boolean;
export function containsParameter(req: Parameters, allowed: Parameters): boolean | Parameters;
//# sourceMappingURL=common.d.ts.map