export function match(req: import("./common").Item, allowed: import("./common").Item): boolean | import("./common").Parameters;
export function sort(types: import("./common").Item[]): import("./common").Item[];
//# sourceMappingURL=item.d.ts.map