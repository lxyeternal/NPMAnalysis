module.exports = function (grunt) {
  var _ = require('lodash');
  var paths = require('path');
  var util = require('../tenutil.js')(grunt);

  grunt.registerMultiTask('create_folders', 'Create 1010 folders from nodes configured with grunt-tenutil.build()', function () {
    var options = this.options({
      template: paths.join(__dirname, 'template_create_folders.xml')
    }, this.data);
    var entries = _.reduce(options.file_configs, function (acc, config) {
      return _.extend(acc, grunt.config(config));
    }, {});

    entries = _.reduce(options.folders, function (acc, o, index) {
      var fulldir = o.folder.replace(/[.]/g, '/');
      var name = paths.posix.basename(fulldir);
      var newO = _.extend({}, o, {
        folderLabel: o.title,
        _table: o.folder,
        _table_full_dirname: o.folder
      });
      acc['empty_folder_' + index + '_' + name] = newO;
      return acc;
    }, entries);

    var folders = util.buildListOfPlatformFolders(entries);
    var users = (options.users || '');
    users = (users === 'inherit' || users === 'private') ? users : users.split(',').map(function (u) {
      return u.trim()
    });
    grunt.file.copy(options.template, options.dest, {
      process: function (contents) {
        return grunt.template.process(contents, {
          data: {
            folders: folders,
            users: users
          }
        });
      }
    });
  });
};