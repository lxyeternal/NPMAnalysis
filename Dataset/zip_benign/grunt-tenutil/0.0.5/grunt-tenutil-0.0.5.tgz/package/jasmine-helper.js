module.exports = function (options) {
  var fs = require("fs");
  var _ = require('lodash');
  var tendo = require('tendo');

  var helper = {};

  helper.options = _.extend({
    build_dir: 'build',
    tendoDefaultOptions: {},
    lodash: {
      interpolate: /{{([\s\S]+?)}}/g
    },
    temp_file_ext: '.runtime',
    jasmine: {
      DEFAULT_TIMEOUT_INTERVAL: 10000
    }
  }, options || {});


  // to override set a higher timeout in your spec.js
  if (jasmine.DEFAULT_TIMEOUT_INTERVAL < helper.options.jasmine.DEFAULT_TIMEOUT_INTERVAL)
    jasmine.DEFAULT_TIMEOUT_INTERVAL = helper.options.jasmine.DEFAULT_TIMEOUT_INTERVAL;

  helper.tendo = tendo;

  helper.query = function (options, file, callback) {
    var opts = _.extend(helper.options.tendoDefaultOptions, options);
    if (opts.params) {
      opts.args = _.reduce(opts.params, function (acc, value, key) {
        return helper.withParam(acc, key, value);
      }, opts.args || '');
      delete opts.params;
    }

    var queryFile = (opts.isInlineQuery === true) ? helper.tokenizeToTempFile(null, file, opts.tokens) : helper.tokenizeToTempFile(file, null, opts.tokens);
    tendo.execute(opts, ['@' + queryFile], function (status, results) {
      if (status === false)
        throw new Error(results);

      callback(results[0]);
    });
  };

  // use {{ var }} in file for runtime tokenization
  helper.tokenizeToTempFile = function (file, data, tokens) {
    tokens = tokens || {};
    if (!file)
      file = helper.options.build_dir + '/inline_tendo_query.xml';
    else {
      data = this.readFileToString(file);
    }

    var tempInterpolate = _.templateSettings.interpolate;
    _.templateSettings.interpolate = helper.options.lodash.interpolate;
    var adhocTokenized = _.template(data)(tokens);
    _.templateSettings.interpolate = tempInterpolate;

    var tempFileName = file + helper.options.temp_file_ext;
    fs.writeFileSync(tempFileName, adhocTokenized);

    return tempFileName;
  };

  helper.queryToJson = function (options, file, callback) {
    options.args = options.args ? options.args + ' -h' : '-K -h';
    options.resultsAsJson = true;

    helper.query(options, file, callback);
  };

  helper.queryQuickAppToJson = function (options, file, callback) {
    var tempFile = helper.options.build_dir + '/temp_tendo_results.csv';

    options.args = options.args ? options.args + ' -h' : '-K -h';
    options.args += ' --lenient --data="' + tempFile + '"';

    helper.query(options, file, function () {
      var resultAsJson = tendo.resultToJson(helper.readFileToString(tempFile), options.newLineDelimiter, options.colDelimiter);
      callback(resultAsJson);
    });
  };

  helper.readFileToString = function (file, encoding) {
    return fs.readFileSync(file, encoding || "utf8").toString();
  };

  helper.withParam = function (args, name, value) {
    return args + ' -[[' + name + ']]="' + value + '"';
  };

  return helper;
}

