var GruntTenUtilConfig = {};

module.exports = function (grunt) {
  var _ = require('lodash');
  var paths = require('path');

  function joinPath(ar, separator) {
    separator = separator || '.';
    var a = [];
    _.each(ar, function (o) {
      if (o)
        a.push(o);
    });
    return a.join(separator);
  }

  function expand(k, properties) {
    if (_.isString(k)) {
      try {
        // check for errors
        _.template(k)(properties);

        return grunt.template.process(k, {data: properties});
      } catch (err) {
        return k; // return unprocessed value (it may reference a key being built during this process)
      }
    }
    else if (_.isArray(k)) {
      var a = [];
      _.each(k, function (v) {
        a.push(expand(v, properties));
      });
      return a
    }
    else if (_.isObject(k)) {
      var o = {};
      _.each(_.keys(k), function (key) {
        o[key] = expand(k[key], properties);
      });
      return o;
    }
    else
      return k;
  }

  function mapSrcOrTokenizedFile(src, dest, srcFrom, destFrom, alwaysMerge) {
    srcFrom = srcFrom || 'src';
    destFrom = destFrom || 'dest';
    return function (acc, o, name) {
      var obj = _.cloneDeep(o);
      // use the tokenized file
      if (obj[destFrom]) {
        obj[src] = obj[srcFrom];
        obj[dest] = obj[destFrom];

        acc[name] = obj;
      }

      if (alwaysMerge === true)
        acc[name] = obj;

      return acc;
    }
  }

  function build(options, properties) {
    var fileGroups = _.map(options, function (opts) {
      var g = expand(opts, properties);

      // generate the file list
      var options = _.extend({
        expand: true,
        cwd: '',
        overrides: [{}]
      }, g || {});


      options.build_dir = options.build_dir || properties.build_dir || '';
      options.root_path = options.root_path || properties.root_path || '';
      options.basetable = options.basetable || properties.basetable || 'default.lonely';

      var files = grunt.file.expand(options, g.src);
      files = _.map(files, function (f) {
        var o = {
          _file: f,
          _ext: paths.posix.extname(f),
          _dirname: paths.posix.dirname(f),
          _filename: paths.posix.basename(f),
          _fullpath: paths.posix.join(options.cwd, f),
          _table_dirname: paths.posix.dirname(f).replace(/[/]/g, '.')
        };

        o._table_dirname = o._table_dirname.length > 1 ? o._table_dirname : '';
        o.ordinal = 1;
        o.name = o._filename.replace(o._ext, '');
        o.src = o._fullpath;
        o.dest = paths.posix.join(options.build_dir, o._file);

        var override = _.find(options.overrides, {file: o._fullpath}) || _.find(options.overrides, {file: o._file}) || {};
        o = _.extend(o, override);

        // account for override values
        if (!override.title)
          o.title = o.name;

        if (!override.table)
          o.table = joinPath([options.root_path, o._table_dirname, o.name + '\(' + o.title + '\;\;\)=' + options.basetable]);

        if (!override._table)
          o._table = joinPath([options.root_path, o._table_dirname, o.name]);

        if (!override._table_full_dirname)
          o._table_full_dirname = joinPath([options.root_path, o._table_dirname]);

        return o;
      });

      return files;
    });

    // dedupe any tasks with the same name
    var configs = _
      .chain(fileGroups)
      .flatten()
      .groupBy('name')
      .reduce(function (acc, ar, key) {
        _.each(ar, function (o, i) {
          o._taskname = (i === 0) ? key : key + (i + 1);
          acc[o._taskname] = o;
        });
        return acc;
      }, {})
      .value();

    return configs;
  }

  function transform(name, arIncludeKeys, arRemapValueToKey) {
    var names = _.isArray(name) ? name : [name];
    arIncludeKeys = arIncludeKeys || [];
    var args = arRemapValueToKey || [];
    if (args.length % 2 !== 0)
      grunt.fail.fatal('must have a key and mapToKey for each mapping[map params:' + args + ']');

    var entries = _.reduce(names, function (acc, name) {
      return _.extend(acc, transformKeys(GruntTenUtilConfig[name], arIncludeKeys, arRemapValueToKey));
    }, {});

    return entries;
  }

  /*
  usage examples:
    transformKeys(configs, 'b', 'a', 'c', 'b')    // var args= values mapped to keys
    transformKeys(configs, ['a','b'], ['b','a'])  // arg1=include keys, arg2= values mapped to keys
    transformKeys(configs, ['a','b'], 'b', 'a', 'c', 'b')  // arg1=include keys, var args= values mapped to keys
   */
  function transformKeys(configs) {
    var arIncludeKeys = [];
    var keys = Array.prototype.slice.call(arguments, 1);
    if (_.isArray(arguments[1])) {
      arIncludeKeys = arguments[1];
      keys = Array.prototype.slice.call(arguments, 2);
    }

    var args = keys;
    if (_.isArray(keys[0]))
      args = keys[0];

    if (args.length % 2 !== 0)
      grunt.fail.fatal('must have a key and mapToKey for each mapping[map params:' + args + ']');

    return _.reduce(configs, function (acc, o, key) {
      var obj = _.cloneDeep(o);

      var remapped = {};
      _.each(args, function (arg, index) {
        if (index % 2 !== 0)
          return;

        remapped[args[index + 1]] = obj[arg];
      });

      var newo = _.extend({}, obj, remapped);
      if (arIncludeKeys.length > 0)
        newo = _.pick(newo, arIncludeKeys);

      acc[key] = newo;
      return acc;
    }, {});
  }

  function buildPlatformFolders(entries) {
    var id = 0;

    function buildPaths(path, paths) {
      var o = {
        parent: '0',
        path: path,
        depth: path.split('.').length
      };

      paths.push(o);
      var hasParent = path.indexOf('.') != -1;
      if (hasParent) {
        o.parent = path.substring(0, path.lastIndexOf('.'));
        return buildPaths(o.parent, paths)
      }

      return paths;
    }

    var folders = _.chain(entries)
      .map(function (o) {
        var path = o._table_full_dirname;
        return _.map(buildPaths(path, []), function (p) {
          p.id = id++;
          if (p.path === path) {
            p.folderLabel = o.folderLabel;
            p.title = o.folderLabel || p.path.substring(p.path.lastIndexOf('.') + 1);
          }
          else
            p.title = p.path.substring(p.path.lastIndexOf('.') + 1);
          return p;
        });
      })
      .reduce(function (acc, obj) {
        return acc.concat(obj);
      }, [])
      .groupBy('path')
      .map(function uniqueByPathWithPriorityToFolderInfo(g) {
        if (g.length == 1)
          return g[0];

        var f = _.filter(g, 'folderLabel');
        return (f.length > 0) ? f[0] : g[0];
      })
      .sortBy(['depth', 'asc'])
      .value();
    return folders;
  }

  return {
    build: function (name, options, properties) {
      GruntTenUtilConfig[name] = build(options, properties);
      return GruntTenUtilConfig[name];
    },

    get: function (name/*, key, mapValueToKey, key, mapValueToKey ... */) {
      var args = Array.prototype.slice.call(arguments, 1);
      return transform(name, null, args);

    },

    getOnly: function (name, arOnlyKeysToGet, arOrParamsOfKeys /*, key, mapValueToKey, key, mapValueToKey ... */) {
      var args = Array.prototype.slice.call(arguments, 2);
      if (_.isArray(arOrParamsOfKeys))
        args = arOrParamsOfKeys;
      return transform(name, arOnlyKeysToGet, args);
    },

    buildTendoTasks: function (name) {
      return _.chain(transform(name, null, []))
        .reduce(function asTendoTask(acc, obj, name) {
          acc.push({name: 'tendo:' + name, ordinal: obj.ordinal || 1});
          return acc;
        }, [])
        .sortBy(['ordinal', 'asc'])
        .map('name')
        .value()
    },

    buildWatcherTasks: function (name, arTaskPrefixesToRun, options) {
      return _.reduce(transform(name, null, []), function (acc, obj, name) {
        var tasks = _.map(arTaskPrefixesToRun, function (t) {
          return t + ':' + name;
        });

        var opts = _.extend({
          spawn: true
        }, options || {});

        acc[name] = {
          files: obj.src,
          tasks: tasks,
          options: opts
        };

        return acc;
      }, {});
    },

    /**
     * @typedef {Object} PlatformFolder
     * @property {id} Unique id within result set
     * @property {title} The title based on the path or an override of title in the config
     * @property {path} The fullpath (including the folder name)
     * @property {parent} The fullpath to the parent folder (excludes "this" folder name)
     * @property {depth} The number of parent folders
     */

    /**
     * Build the list of folders which make up the queries.
     *
     * @property {Array<Object>} entries - list of entries created with grunt-tenutil.build() but is best if these
     * entries are access using grunt.config('some entry in build.config') to ensure all tokenizations have occurred.
     * @returns {Array<PlatformFolder>}
     */
    buildListOfPlatformFolders: function (entries) {
      return buildPlatformFolders(entries);
    },

    /*
    usage examples:
      transformKeys(configs, 'b', 'a', 'c', 'b')    // var args= values mapped to keys
      transformKeys(configs, ['a','b'], ['b','a'])  // arg1=include keys, arg2= values mapped to keys
      transformKeys(configs, ['a','b'], 'b', 'a', 'c', 'b')  // arg1=include keys, var args= values mapped to keys
     */
    transformKeys: function (configs) {
      return transformKeys.apply(this, arguments);
    },

    // deprecated use transformKeys()
    mapSrcOrTokenizedFile: function (src, dest, srcFrom, destFrom, alwaysMerge) {
      return mapSrcOrTokenizedFile(src, dest, srcFrom, destFrom, alwaysMerge);
    },

    createJasmineHelper: function (options) {
      return require('./jasmine-helper.js')(options);
    }
  };
};