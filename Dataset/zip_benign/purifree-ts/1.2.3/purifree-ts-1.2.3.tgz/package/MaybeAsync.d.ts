import { MaybeAsync } from 'purify-ts';
import { ofSymbol } from './pointfree/do';
import { Type } from './pointfree/hkt';
export declare const MAYBE_ASYNC_URI = "MaybeAsync";
export declare type MAYBE_ASYNC_URI = typeof MAYBE_ASYNC_URI;
declare module './pointfree/hkt' {
    interface URI2HKT<Types extends any[]> {
        [MAYBE_ASYNC_URI]: MaybeAsync<Types[0]>;
    }
}
declare module 'purify-ts/MaybeAsync' {
    interface MaybeAsync<T> {
        readonly _URI: MAYBE_ASYNC_URI;
        readonly _A: [T];
        [Symbol.iterator]: () => Iterator<Type<MAYBE_ASYNC_URI, [T]>, T, T>;
        [Symbol.toStringTag]: 'MaybeAsync';
        [ofSymbol]: MaybeAsyncTypeRef['of'];
    }
    interface MaybeAsyncTypeRef {
        of<T>(value: T): MaybeAsync<T>;
    }
}
export * from 'purify-ts/MaybeAsync';
