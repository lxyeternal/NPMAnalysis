"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toEither = void 0;
exports.toEither = function (left) { return function (fa) {
    return fa.toEither(left);
}; };
