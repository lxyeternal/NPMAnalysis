"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Do = exports.DoFlex = exports.ofSymbol = void 0;
exports.ofSymbol = Symbol('of');
function DoFlex(_fun) {
    return null;
}
exports.DoFlex = DoFlex;
function Do(fun) {
    var iterator = fun();
    var state = iterator.next();
    var of = state.value[exports.ofSymbol];
    function run(state) {
        if (state.done) {
            return of(state.value);
        }
        return state.value.chain(function (val) {
            return run(iterator.next(val));
        });
    }
    return run(state);
}
exports.Do = Do;
