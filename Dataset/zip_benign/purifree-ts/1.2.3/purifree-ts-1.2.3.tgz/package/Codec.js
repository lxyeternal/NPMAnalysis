"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseError = exports.intersect = exports.date = exports.tuple = exports.nonEmptyList = exports.maybe = exports.lazy = exports.exactly = exports.record = exports.array = exports.oneOf = exports.enumeration = exports.unknown = exports.boolean = exports.nullable = exports.optional = exports.nullType = exports.number = exports.string = exports.Codec = void 0;
var purify_ts_1 = require("purify-ts");
exports.Codec = __assign({ map: purify_ts_1.map }, purify_ts_1.Codec);
var Codec_1 = require("purify-ts/Codec");
Object.defineProperty(exports, "string", { enumerable: true, get: function () { return Codec_1.string; } });
Object.defineProperty(exports, "number", { enumerable: true, get: function () { return Codec_1.number; } });
Object.defineProperty(exports, "nullType", { enumerable: true, get: function () { return Codec_1.nullType; } });
Object.defineProperty(exports, "optional", { enumerable: true, get: function () { return Codec_1.optional; } });
Object.defineProperty(exports, "nullable", { enumerable: true, get: function () { return Codec_1.nullable; } });
Object.defineProperty(exports, "boolean", { enumerable: true, get: function () { return Codec_1.boolean; } });
Object.defineProperty(exports, "unknown", { enumerable: true, get: function () { return Codec_1.unknown; } });
Object.defineProperty(exports, "enumeration", { enumerable: true, get: function () { return Codec_1.enumeration; } });
Object.defineProperty(exports, "oneOf", { enumerable: true, get: function () { return Codec_1.oneOf; } });
Object.defineProperty(exports, "array", { enumerable: true, get: function () { return Codec_1.array; } });
Object.defineProperty(exports, "record", { enumerable: true, get: function () { return Codec_1.record; } });
Object.defineProperty(exports, "exactly", { enumerable: true, get: function () { return Codec_1.exactly; } });
Object.defineProperty(exports, "lazy", { enumerable: true, get: function () { return Codec_1.lazy; } });
Object.defineProperty(exports, "maybe", { enumerable: true, get: function () { return Codec_1.maybe; } });
Object.defineProperty(exports, "nonEmptyList", { enumerable: true, get: function () { return Codec_1.nonEmptyList; } });
Object.defineProperty(exports, "tuple", { enumerable: true, get: function () { return Codec_1.tuple; } });
Object.defineProperty(exports, "date", { enumerable: true, get: function () { return Codec_1.date; } });
Object.defineProperty(exports, "intersect", { enumerable: true, get: function () { return Codec_1.intersect; } });
Object.defineProperty(exports, "parseError", { enumerable: true, get: function () { return Codec_1.parseError; } });
