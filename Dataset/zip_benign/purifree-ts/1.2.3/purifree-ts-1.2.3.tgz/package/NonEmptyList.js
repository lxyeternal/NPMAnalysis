"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NON_EMPTY_LIST_URI = exports.concat = void 0;
var NonEmptyList_1 = require("purify-ts/NonEmptyList");
var List_1 = require("./List");
exports.concat = function (arr) {
    return function (arr2) {
        return arr.concat(arr2);
    };
};
exports.NON_EMPTY_LIST_URI = 'NonEmptyList';
NonEmptyList_1.NonEmptyList.of = function (val) { return new List_1.ListImpl(val); };
__exportStar(require("purify-ts/NonEmptyList"), exports);
