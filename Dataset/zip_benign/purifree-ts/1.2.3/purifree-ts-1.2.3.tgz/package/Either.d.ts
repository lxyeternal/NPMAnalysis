import { ApKind, ofAp } from './pointfree/ap';
import { ofSymbol } from './pointfree/do';
import { HKT, ReplaceFirst, Type, URIS } from './pointfree/hkt';
import { Either } from 'purify-ts/Either';
export declare const EITHER_URI = "Either";
export declare type EITHER_URI = typeof EITHER_URI;
declare module './pointfree/hkt' {
    interface URI2HKT<Types extends any[]> {
        [EITHER_URI]: Either<Types[1], Types[0]>;
    }
}
declare module 'purify-ts/Either' {
    interface Either<L, R> extends HKT<EITHER_URI, [R, L]> {
        readonly _URI: EITHER_URI;
        readonly _A: [R, L];
        [Symbol.iterator]: () => Iterator<Either<L, R>, R, any>;
        [ofSymbol]: typeof Either['of'];
        traverse<URI extends URIS, AP extends ApKind<any, any> = ApKind<URI, any>>(of: ofAp<URI>, f: (a: R) => AP): Type<URI, ReplaceFirst<AP['_A'], Either<L, AP['_A'][0]>>>;
        sequence<Ap extends ApKind<any, any>>(this: Either<L, Ap>, of: ofAp<Ap['_URI']>): Type<Ap['_URI'], ReplaceFirst<Ap['_A'], Either<L, Ap['_A'][0]>>>;
        'fantasy-land/traverse'<URI extends URIS, AP extends ApKind<any, any> = ApKind<URI, any>>(of: ofAp<URI>, f: (a: R) => AP): Type<URI, ReplaceFirst<AP['_A'], Either<L, AP['_A'][0]>>>;
        'fantasy-land/sequence'<Ap extends ApKind<any, any>>(this: Either<L, Ap>, of: ofAp<Ap['_URI']>): Type<Ap['_URI'], ReplaceFirst<Ap['_A'], Either<L, Ap['_A'][0]>>>;
    }
}
export declare type IsLeft = {
    <L, R>(either: Either<L, R>): either is Either<L, never>;
};
export declare type IsRight = {
    <L, R>(either: Either<L, R>): either is Either<never, R>;
};
export declare const isLeft: IsLeft;
export declare const isRight: IsRight;
export { Right, Either, Left } from 'purify-ts/Either';
export type { EitherPatterns } from 'purify-ts/Either';
