"use strict";
// From fp-ts
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spread = (this && this.__spread) || function () {
    for (var ar = [], i = 0; i < arguments.length; i++) ar = ar.concat(__read(arguments[i]));
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.bindTo_ = exports.bind_ = exports.hole = exports.pipe = exports.untupled = exports.tupled = exports.absurd = exports.decrement = exports.increment = exports.flow = exports.flip = exports.constVoid = exports.constUndefined = exports.constNull = exports.constFalse = exports.constTrue = exports.constant = exports.not = exports.unsafeCoerce = exports.identity = void 0;
/**
 *
 */
function identity(a) {
    return a;
}
exports.identity = identity;
/**
 *
 */
exports.unsafeCoerce = identity;
/**
 *
 */
function not(predicate) {
    return function (a) { return !predicate(a); };
}
exports.not = not;
/**
 *
 */
function constant(a) {
    return function () { return a; };
}
exports.constant = constant;
/**
 * A thunk that returns always `true`
 *
 *
 */
exports.constTrue = function () {
    return true;
};
/**
 * A thunk that returns always `false`
 *
 *
 */
exports.constFalse = function () {
    return false;
};
/**
 * A thunk that returns always `null`
 *
 *
 */
exports.constNull = function () {
    return null;
};
/**
 * A thunk that returns always `undefined`
 *
 *
 */
exports.constUndefined = function () {
    return;
};
/**
 * A thunk that returns always `void`
 *
 *
 */
exports.constVoid = function () {
    return;
};
// TODO: remove in v3
/**
 * Flips the order of the arguments of a function of two arguments.
 *
 *
 */
function flip(f) {
    return function (b, a) { return f(a, b); };
}
exports.flip = flip;
function flow() {
    var fns = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        fns[_i] = arguments[_i];
    }
    return function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        return fns.slice(1).reduce(function (acc, fn) { return fn(acc); }, fns[0].apply(fns, __spread(args)));
    };
}
exports.flow = flow;
/**
 *
 */
// export function tuple<T extends ReadonlyArray<any>>(...t: T): T {
//   return t
// }
/**
 *
 */
function increment(n) {
    return n + 1;
}
exports.increment = increment;
/**
 *
 */
function decrement(n) {
    return n - 1;
}
exports.decrement = decrement;
/**
 *
 */
function absurd(_) {
    throw new Error('Called `absurd` function which should be uncallable');
}
exports.absurd = absurd;
/**
 * Creates a tupled version of this function: instead of `n` arguments, it accepts a single tuple argument.
 *
 * @example
 * import { tupled } from 'purifree-ts/function'
 *
 * const add = tupled((x: number, y: number): number => x + y)
 *
 * assert.strictEqual(add([1, 2]), 3)
 *
 */
function tupled(f) {
    return function (a) { return f.apply(void 0, __spread(a)); };
}
exports.tupled = tupled;
/**
 * Inverse function of `tupled`
 */
function untupled(f) {
    return function () {
        var a = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            a[_i] = arguments[_i];
        }
        return f(a);
    };
}
exports.untupled = untupled;
function pipe(a) {
    var fns = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        fns[_i - 1] = arguments[_i];
    }
    return fns.reduce(function (acc, fn) { return fn(acc); }, a);
}
exports.pipe = pipe;
/**
 * Type hole simulation
 */
exports.hole = absurd;
/**
 * @internal
 */
exports.bind_ = function (a, name, b) {
    var _a;
    return Object.assign({}, a, (_a = {}, _a[name] = b, _a));
};
/**
 * @internal
 */
exports.bindTo_ = function (name) {
    return function (b) {
        var _a;
        return (_a = {}, _a[name] = b, _a);
    };
};
