"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spread = (this && this.__spread) || function () {
    for (var ar = [], i = 0; i < arguments.length; i++) ar = ar.concat(__read(arguments[i]));
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.List = exports.ListImpl = exports.LIST_URI = void 0;
var purify_ts_1 = require("purify-ts");
exports.LIST_URI = 'List';
var ListImpl = /** @class */ (function (_super) {
    __extends(ListImpl, _super);
    function ListImpl() {
        var items = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            items[_i] = arguments[_i];
        }
        var _this = _super.apply(this, __spread(items)) || this;
        Object.setPrototypeOf(_this, ListImpl.prototype);
        return _this;
    }
    ListImpl.prototype.ap = function (other) {
        var _this = this;
        return other.chain(function (f) { return _this.map(f); });
    };
    ListImpl.prototype['fantasy-land/ap'] = function (other) {
        return this.ap(other);
    };
    ListImpl.prototype['fantasy-land/traverse'] = function (of, f) {
        return this.traverse(of, f);
    };
    ListImpl.prototype.traverse = function (of, f) {
        var initialState = of(exports.List());
        return this.reduceRight(function (tail, head) {
            var v0 = f(head).map(function (val) { return function (tail) { return __spread([val], tail); }; });
            return tail.ap(v0);
        }, initialState);
    };
    ListImpl.prototype['fantasy-land/sequence'] = function (of) {
        return this.sequence(of);
    };
    ListImpl.prototype.sequence = function (of) {
        return this.traverse(of, function (e) { return e; });
    };
    ListImpl.prototype['fantasy-land/map'] = function (callbackfn, thisArg) {
        return this.map(callbackfn, thisArg);
    };
    ListImpl.prototype['fantasy-land/chain'] = function (callbackfn, thisArg) {
        return this.chain(callbackfn, thisArg);
    };
    ListImpl.prototype.chain = function (callbackfn, thisArg) {
        return this.map(callbackfn, thisArg).joinM();
    };
    ListImpl.prototype.joinM = function () {
        return this.reduce(function (acc, val) { return acc.concat(val); }, exports.List());
    };
    return ListImpl;
}(Array));
exports.ListImpl = ListImpl;
function ListConstructor() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
    }
    if (args.length === 1 && Array.isArray(args[0])) {
        return ListImpl.from(args[0]);
    }
    return ListImpl.of.apply(ListImpl, __spread(args));
}
exports.List = Object.assign(ListConstructor, __assign({ of: function (val) { return ListImpl.of(val); } }, purify_ts_1.List));
