import { ApKind, ofAp } from './pointfree/ap';
import { ofSymbol } from './pointfree/do';
import { HKT, ReplaceFirst, Type, URIS } from './pointfree/hkt';
import { Maybe, Nothing as nothing } from 'purify-ts/Maybe';
export declare const MAYBE_URI = "Maybe";
export declare type MAYBE_URI = typeof MAYBE_URI;
declare module './pointfree/hkt' {
    interface URI2HKT<Types extends any[]> {
        [MAYBE_URI]: Maybe<Types[0]>;
    }
}
declare module 'purify-ts' {
    interface Maybe<T> extends HKT<MAYBE_URI, [T]> {
        readonly _URI: MAYBE_URI;
        readonly _A: [T];
        [ofSymbol]: typeof Maybe.of;
        [Symbol.iterator]: () => Iterator<Type<MAYBE_URI, [T]>, T, any>;
        traverse<URI extends URIS, AP extends ApKind<any, any> = ApKind<URI, any>>(of: ofAp<URI>, f: (a: T) => AP): Type<URI, ReplaceFirst<AP['_A'], Maybe<AP['_A'][0]>>>;
        sequence<Ap extends ApKind<any, any>>(this: Maybe<Ap>, of: ofAp<Ap['_URI']>): Type<Ap['_URI'], ReplaceFirst<Ap['_A'], Maybe<Ap['_A'][0]>>>;
        'fantasy-land/traverse': this['traverse'];
        'fantasy-land/sequence': this['sequence'];
    }
}
declare type N = typeof nothing & Maybe<never>;
interface Nothing extends N {
    readonly _URI: MAYBE_URI;
    readonly _A: [never];
    traverse<URI extends URIS, AP extends ApKind<any, any> = ApKind<URI, any>>(of: ofAp<URI>, _f: (a: never) => AP): Type<URI, ReplaceFirst<AP['_A'], Maybe<AP['_A'][0]>>>;
    'fantasy-land/traverse'<URI extends URIS, AP extends ApKind<any, any> = ApKind<URI, any>>(of: ofAp<URI>, f: (a: never) => AP): Type<URI, ReplaceFirst<AP['_A'], Maybe<AP['_A'][0]>>>;
    'fantasy-land/sequence'<Ap extends ApKind<any, any>>(this: Maybe<Ap>, of: ofAp<Ap['_URI']>): Type<Ap['_URI'], ReplaceFirst<Ap['_A'], Maybe<Ap['_A'][0]>>>;
    sequence<Ap extends ApKind<any, any>>(this: Maybe<Ap>, of: ofAp<Ap['_URI']>): Type<Ap['_URI'], ReplaceFirst<Ap['_A'], Maybe<Ap['_A'][0]>>>;
}
export * from 'purify-ts/Maybe';
export declare const Nothing: Nothing;
