import { ofSymbol } from './pointfree/do';
import { EitherAsync } from 'purify-ts';
import { Type } from './pointfree/hkt';
export declare const EITHER_ASYNC_URI = "EitherAsync";
export declare type EITHER_ASYNC_URI = typeof EITHER_ASYNC_URI;
declare module './pointfree/hkt' {
    interface URI2HKT<Types extends any[]> {
        [EITHER_ASYNC_URI]: EitherAsync<Types[1], Types[0]>;
    }
}
declare module 'purify-ts/EitherAsync' {
    interface EitherAsync<L, R> {
        readonly _URI: EITHER_ASYNC_URI;
        readonly _A: [R, L];
        [ofSymbol]: EitherAsyncTypeRef['of'];
        [Symbol.iterator]: () => Iterator<Type<EITHER_ASYNC_URI, [R, L]>, R, any>;
        [Symbol.toStringTag]: 'EitherAsync';
    }
    interface EitherAsyncTypeRef {
        of<L = never, R = any>(value: R): EitherAsync<L, R>;
    }
}
export * from 'purify-ts/EitherAsync';
