"use strict";
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Left = exports.Either = exports.Right = exports.isRight = exports.isLeft = exports.EITHER_URI = void 0;
var do_1 = require("./pointfree/do");
var Either_1 = require("purify-ts/Either");
exports.EITHER_URI = 'Either';
// God, I'm so sorry
var _right = Object.getPrototypeOf(Either_1.Right(undefined));
var _left = Object.getPrototypeOf(Either_1.Left(undefined));
_right[do_1.ofSymbol] = Either_1.Either.of;
_right[Symbol.iterator] = function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, this];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
};
_right['fantasy-land/traverse'] = function (of, f) {
    return this.traverse(of, f);
};
_right.traverse = function (_of, f) {
    var result = f(this.__value);
    return result.map(Either_1.Right);
};
_right['fantasy-land/sequence'] = function (of) {
    return this.sequence(of);
};
_right.sequence = function (_of) {
    return this.__value.map(Either_1.Right);
};
_left[do_1.ofSymbol] = Either_1.Either.of;
_left[Symbol.iterator] = function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, this];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
};
_left['fantasy-land/traverse'] = function (f) {
    return this.traverse(f);
};
_left.traverse = function (of, _f) {
    return of(this);
};
_left['fantasy-land/sequence'] = function (of) {
    return this.sequence(of);
};
_left.sequence = function (of) {
    return of(this);
};
exports.isLeft = function (either) { return either.isLeft(); };
exports.isRight = function (either) { return either.isRight(); };
var Either_2 = require("purify-ts/Either");
Object.defineProperty(exports, "Right", { enumerable: true, get: function () { return Either_2.Right; } });
Object.defineProperty(exports, "Either", { enumerable: true, get: function () { return Either_2.Either; } });
Object.defineProperty(exports, "Left", { enumerable: true, get: function () { return Either_2.Left; } });
