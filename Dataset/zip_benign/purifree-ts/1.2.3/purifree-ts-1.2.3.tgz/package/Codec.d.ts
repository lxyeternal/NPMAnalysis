import { Codec as C } from 'purify-ts';
export declare const Codec: {
    interface<T extends Record<string, C<any>>>(properties: T): C<{ [k in keyof T]: import("purify-ts").GetType<T[k]>; }>;
    custom<T_1>({ decode, encode, schema }: {
        decode: (value: unknown) => import("purify-ts").Either<string, T_1>;
        encode: (value: T_1) => any;
        schema?: (() => object) | undefined;
    }): C<T_1>;
    map: <K, V>(keyCodec: C<K>, valueCodec: C<V>) => C<Map<K, V>>;
};
export type { FromType, GetType } from 'purify-ts/Codec';
export { string, number, nullType, optional, nullable, boolean, unknown, enumeration, oneOf, array, record, exactly, lazy, maybe, nonEmptyList, tuple, date, intersect, parseError, } from 'purify-ts/Codec';
