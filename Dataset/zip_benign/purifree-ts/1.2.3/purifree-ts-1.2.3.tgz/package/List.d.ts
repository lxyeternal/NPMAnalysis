import { ApKind } from './pointfree/ap';
import { ReplaceFirst, Type, URIS } from './pointfree/hkt';
import { NonEmptyArray, ofAp } from '.';
export declare const LIST_URI = "List";
export declare type LIST_URI = typeof LIST_URI;
declare module './pointfree/hkt' {
    interface URI2HKT<Types extends any[]> {
        [LIST_URI]: List<Types[0]>;
    }
}
export interface List<T> extends Array<T> {
    readonly _URI: LIST_URI;
    readonly _A: [T];
    sequence<Ap extends ApKind<any, any>>(this: List<Ap>, of: ofAp<Ap['_URI']>): Type<Ap['_URI'], ReplaceFirst<Ap['_A'], List<Ap['_A'][0]>>>;
    traverse<URI extends URIS, AP extends ApKind<any, any> = ApKind<URI, any>>(of: ofAp<URI>, f: (a: T) => AP): Type<URI, ReplaceFirst<AP['_A'], List<AP['_A'][0]>>>;
    map<U>(this: List<T>, callbackfn: (value: T, index: number, array: List<T>) => U, thisArg?: any): List<U>;
    ap<R2>(other: List<(value: T) => R2>): List<R2>;
    chain<U>(this: List<T>, callbackfn: (value: T, index: number, array: List<T>) => List<U>, thisArg?: any): List<U>;
    reverse(this: List<T>): List<T>;
    joinM<T2>(this: List<List<T2>>): List<T2>;
    'fantasy-land/traverse': this['traverse'];
    'fantasy-land/sequence': this['sequence'];
    'fantasy-land/map': this['map'];
    'fantasy-land/chain': this['chain'];
    'fantasy-land/ap': this['ap'];
}
export declare class ListImpl<T> extends Array<T> implements List<T> {
    readonly _URI: LIST_URI;
    readonly _A: [T];
    constructor(...items: T[]);
    ap<R2>(other: List<(value: T) => R2>): List<R2>;
    'fantasy-land/ap'<R2>(other: List<(value: T) => R2>): List<R2>;
    'fantasy-land/traverse'<URI extends URIS, AP extends ApKind<any, any> = ApKind<URI, any>>(of: ofAp<URI>, f: (a: T) => AP): Type<URI, ReplaceFirst<AP['_A'], List<AP['_A'][0]>>>;
    traverse<URI extends URIS, AP extends ApKind<any, any> = ApKind<URI, any>>(of: ofAp<URI>, f: (a: T) => AP): Type<URI, ReplaceFirst<AP['_A'], List<AP['_A'][0]>>>;
    'fantasy-land/sequence'<Ap extends ApKind<any, any>>(this: List<Ap>, of: ofAp<Ap['_URI']>): Type<Ap['_URI'], ReplaceFirst<Ap['_A'], List<Ap['_A'][0]>>>;
    sequence<Ap extends ApKind<any, any>>(this: List<Ap>, of: ofAp<Ap['_URI']>): Type<Ap['_URI'], ReplaceFirst<Ap['_A'], List<Ap['_A'][0]>>>;
    'fantasy-land/map'<U>(this: List<T>, callbackfn: (value: T, index: number, array: List<T>) => U, thisArg?: any): List<U>;
    map: <U>(this: List<T>, callbackfn: (value: T, index: number, array: List<T>) => U, thisArg?: any) => List<U>;
    'fantasy-land/chain'<U>(this: List<T>, callbackfn: (value: T, index: number, array: List<T>) => List<U>, thisArg?: any): List<U>;
    chain<U>(this: List<T>, callbackfn: (value: T, index: number, array: List<T>) => List<U>, thisArg?: any): List<U>;
    joinM<T2>(this: List<List<T2>>): List<T2>;
    reverse: (this: List<T>) => List<T>;
}
declare function ListConstructor<T>(list: NonEmptyArray<T>): List<T> & {
    0: T;
};
declare function ListConstructor<T>(list: T[]): List<T>;
declare function ListConstructor<T, Rest extends T[]>(value1: T, ...values: Rest): List<T> & {
    0: T;
};
declare function ListConstructor<T extends any[]>(...values: T): List<T[number]>;
export declare const List: typeof ListConstructor & {
    init: <T>(list: T[]) => import("purify-ts").Maybe<T[]>;
    uncons: <T_1>(list: T_1[]) => import("purify-ts").Maybe<import("purify-ts").Tuple<T_1, T_1[]>>;
    at: {
        <T_2>(index: number, list: T_2[]): import("purify-ts").Maybe<T_2>;
        <T_3>(index: number): (list: T_3[]) => import("purify-ts").Maybe<T_3>;
    };
    head: <T_2_1>(list: T_2_1[]) => import("purify-ts").Maybe<T_2_1>;
    last: <T_3_1>(list: T_3_1[]) => import("purify-ts").Maybe<T_3_1>;
    tail: <T_4>(list: T_4[]) => import("purify-ts").Maybe<T_4[]>;
    find: {
        <T_5>(f: (x: T_5, index: number, arr: T_5[]) => boolean, list: T_5[]): import("purify-ts").Maybe<T_5>;
        <T_6>(f: (x: T_6, index: number, arr: T_6[]) => boolean): (list: T_6[]) => import("purify-ts").Maybe<T_6>;
    };
    findIndex: {
        <T_7>(f: (x: T_7, index: number, arr: T_7[]) => boolean, list: T_7[]): import("purify-ts").Maybe<number>;
        <T_8>(f: (x: T_8, index: number, arr: T_8[]) => boolean): (list: T_8[]) => import("purify-ts").Maybe<number>;
    };
    sum: (list: number[]) => number;
    sort: {
        <T_9>(compare: (a: T_9, b: T_9) => import("purify-ts").Order, list: T_9[]): T_9[];
        <T_10>(compare: (a: T_10, b: T_10) => import("purify-ts").Order): (list: T_10[]) => T_10[];
    };
    of: <T_11>(val: T_11) => List<T_11> & {
        0: T_11;
    };
};
export {};
