export declare const leadingZeros: (num: string) => number;
export declare const trailingZeros: (num: string) => number;
export declare const validateCharactersOfSignificand: (significand: string) => string;
export declare const validateRangeOfPrecision: (precision: number | undefined, significand: string) => number;
export declare const validateSignOfExponent: (exponent: number) => number;
export declare const removeUnnecessaryZeros: (significand: string, exponent: number, precision: number) => [string, number, number];
export declare class PrecisionNumber {
    private _significand;
    private _exponent;
    private _precision;
    constructor(significand: string, exponent: number, precision?: number);
    static fromString(num: string): PrecisionNumber;
    static fromDecimalString(num: string, exponent?: number): PrecisionNumber;
    get significand(): string;
    get exponent(): number;
    get precision(): number;
    toString(): string;
    toDecimalString(exponent?: number): string;
    add(num: PrecisionNumber): PrecisionNumber;
    divideByPositiveInteger(num: number): PrecisionNumber;
}
