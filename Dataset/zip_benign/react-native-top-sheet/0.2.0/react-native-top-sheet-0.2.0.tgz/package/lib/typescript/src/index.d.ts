import React from 'react';
import { View } from 'react-native';
type ViewStyle = View['props']['style'];
type ModalProps = {
    children: React.ReactNode;
    /**
     * Percentage of screen height if < 1 otherwise height in pixels
     */
    snap: number;
    shouldHideOnOverlayPress?: boolean;
    overlayStyle?: ViewStyle;
    modalStyle?: ViewStyle;
    handlerStyle?: ViewStyle;
    handlerWrapperStyle?: ViewStyle;
};
export interface ModalHandle {
    show: () => void;
    hide: () => void;
}
declare const TopSheetModal: React.ForwardRefExoticComponent<ModalProps & React.RefAttributes<ModalHandle>>;
export default TopSheetModal;
//# sourceMappingURL=index.d.ts.map