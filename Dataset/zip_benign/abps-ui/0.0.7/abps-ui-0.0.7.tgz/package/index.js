import _style from "./lib/style.scss";
export default _style;
