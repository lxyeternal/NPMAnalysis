export type Action = {
    type: string;
    data?: {
        [key: string]: any;
    };
};
export interface NativeAdapter {
    dispatchToNative(action: Action): void;
    dispatchToScript(action: Action): void;
}
export interface ScriptAdapter {
    dispatchToScript(action: Action): void;
}
export interface Middleware {
    dispatchToNative(action: Action): void;
    dispatchToScript(action: Action): void;
}
export declare class LoggingMiddleware implements Middleware {
    dispatchToNative(action: Action): void;
    dispatchToScript(action: Action): void;
}
export declare class Cyber {
    static nativeAdapter?: NativeAdapter;
    static scriptAdapter?: ScriptAdapter;
    static middlewares: Middleware[];
    static dispatchToNative(action: Action): void;
    static dispatchToNativeAfterNextRepaint(action: Action): void;
    static dispatchToScript(action: Action): void;
    static dispatchToScriptAfterNextRepaint(action: Action): void;
}
declare global {
    interface Window {
        Cyber: typeof Cyber;
    }
}
