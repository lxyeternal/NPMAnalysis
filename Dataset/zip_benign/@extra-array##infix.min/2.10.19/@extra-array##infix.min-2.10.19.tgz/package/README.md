Picks an arbitrary infix.
[:package:](https://www.npmjs.com/package/@extra-array/infix)
[:smiley_cat:](https://github.com/orgs/nodef/packages?repo_name=extra-array)
[:running:](https://npm.runkit.com/@extra-array/infix)
[:vhs:](https://asciinema.org/a/332066)
[:moon:](https://www.npmjs.com/package/@extra-array/infix.min)
[:scroll:](https://unpkg.com/@extra-array/infix/)
[:newspaper:](https://nodef.github.io/extra-array/)
[:blue_book:](https://github.com/nodef/extra-array/wiki/)

> Similar: [infix], [infixes], [hasInfix], [searchInfix].

> This is part of package [extra-array].

[extra-array]: https://www.npmjs.com/package/extra-array

> This is browserified, minified version of [@extra-array/infix].<br>
> It is exported as global variable **array_infix**.<br>
> CDN: [unpkg], [jsDelivr].

[@extra-array/infix]: https://www.npmjs.com/package/@extra-array/infix
[unpkg]: https://unpkg.com/@extra-array/infix.min
[jsDelivr]: https://cdn.jsdelivr.net/npm/@extra-array/infix.min

<br>

```javascript
array.infix(x, [n], [r]);
// x: an array
// n: number of values (-1 => any)
// r: random seed 0->1
```

```javascript
const array = require("extra-array");

var x = [1, 2, 3];
array.infix(x);
// [ 1, 2 ]

array.infix(x, 1);
// [ 2 ]

array.infix(x, 1, 0.5);
// [ 2 ]
```

[infix]: https://github.com/nodef/extra-array/wiki/infix
[infixes]: https://github.com/nodef/extra-array/wiki/infixes
[hasInfix]: https://github.com/nodef/extra-array/wiki/hasInfix
[searchInfix]: https://github.com/nodef/extra-array/wiki/searchInfix
