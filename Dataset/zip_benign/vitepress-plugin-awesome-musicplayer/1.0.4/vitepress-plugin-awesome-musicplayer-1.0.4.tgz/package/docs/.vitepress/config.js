export default {
    title: 'musicplayers',
    description: 'a music player by vuepress'
};
