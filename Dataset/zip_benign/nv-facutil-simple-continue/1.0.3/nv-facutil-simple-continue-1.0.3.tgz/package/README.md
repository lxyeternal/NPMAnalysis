nv-facutil-simple-continue
===============
- simple promise continue 

install
=======
- npm install nv-facutil-simple-continue 

usage
=====
      
    const {
        normalize_promise,
        Ctx,
        retry,
        Runtime,
        easy,
    } = require("nv-facutil-simple-continue")   
   
    
example
-------

### normalize\_promise

    //(op:Promise):AlwaysResolvedPromise

    var p0 = Promise.resolve(100)
    var np = normalize_promise(p0)
    np
    Promise { Ctx { err: null, data: 100 } }
    
    var p1 = Promise.reject(200)
    var np = normalize_promise(p1)
    np
    > np
    Promise { Ctx { err: 200, data: null } }


### retry


    //(f:Executor,ctx:Ctx,max_times=Infinity):Ctx
    //Executor  (ctx)=>{/*...*/}

    var ctx = new Ctx(null,100)
    > ctx
    Ctx { err: null, data: 100 }
    >

    function func(ctx) {
        let p = new Promise((resolve)=>{
            setTimeout(
                ()=> {
                    /////-----begin
                    ctx.data = ctx.data +10
                    let cond = Math.random()>0.66;
                    if(cond) {
                        console.log("succ")
                        ctx.rtrn()
                    } else {
                        console.log("failed")
                        ctx.thrw('failed')
                    }
                    /////---end
                    resolve(ctx)       //always use resolve, reject is useless
                },
                3000
            );
        });
        return(p)
    }

     > var p = retry(func,ctx)
     > p
     Promise {
       <pending>,
       [Symbol(async_id_symbol)]: 416,
       [Symbol(trigger_async_id_symbol)]: 5,
       [Symbol(destroyed)]: { destroyed: false }
     }
     > failed           //will auto rollback  ctx.data will rollback

     > failed           //will auto rollback  ctx.data will rollback

     > succ

     > p
     Promise {
       Ctx { err: null, data: 110 },               //
       [Symbol(async_id_symbol)]: 416,
       [Symbol(trigger_async_id_symbol)]: 5,
       [Symbol(destroyed)]: { destroyed: false }
     }
     >


### simple runtime, for continue from last-failed-task

    function creat_tsk() {
        let _f = (ctx) => {
            let p = new Promise((resolve)=>{
                setTimeout(
                    ()=> {
                        /////-----begin
                        ctx.data.a = ctx.data.a + 1
                        ctx.data.b = ctx.data.b + 2
                        let cond = Math.random()>0.5;
                        if(cond) {
                            console.log("succ")
                            ctx.rtrn()
                        } else {
                            console.log("failed")
                            ctx.thrw('failed')
                        }
                        /////---end

                        resolve(ctx)      //always use resolve, reject is useless
                    },
                    3000
                )
            });
            return(p)
        }
        return(_f)
    }
    
    var tsk0 = creat_tsk()
    var tsk1 = creat_tsk()
    var tsk2 = creat_tsk()

     var data = {
         a:0,
         b:0,
     }


     var runtime = new Runtime([tsk0,tsk1,tsk2],data)

    > runtime.pc_
    0
    > runtime.funcs_
    [ [Function: _f], [Function: _f], [Function: _f] ]
    > runtime.data_
    { a: 0, b: 0 }
    > runtime.init_data_
    { a: 0, b: 0 }
    >
    > runtime.err_
    null
    >

     > await runtime.run()
     { a: 0, b: 0 }
     failed
     Ctx { err: null, data: { a: 0, b: 0 } }
     > await runtime.run()
     { a: 0, b: 0 }
     succ
     { a: 1, b: 2 }
     succ
     { a: 2, b: 4 }
     succ
     Ctx { err: null, data: { a: 3, b: 6 } }
     > runtime.ctx_
     Ctx { err: null, data: { a: 3, b: 6 } }
     > runtime.init_data_
     { a: 0, b: 0 }
     >
     > runtime.pc_
     3
     > runtime.is_succ()
     true
     > runtime.reset()
     undefined
     > runtime.pc_
     0
     > runtime.ctx_
     Ctx { err: null, data: { a: 0, b: 0 } }
     > await runtime.run()
     { a: 0, b: 0 }
     failed
     Ctx { err: null, data: { a: 0, b: 0 } }       //auto rollback
     > runtime.pc_
     0

     > await runtime.run()                      //will continue from last failed pc(tsk0)
     { a: 0, b: 0 }
     failed
     Ctx { err: null, data: { a: 0, b: 0 } }
     > await runtime.run()
     { a: 0, b: 0 }
     succ
     { a: 1, b: 2 }
     succ
     { a: 2, b: 4 }
     succ
     Ctx { err: null, data: { a: 3, b: 6 } }
     > runtime.reset()
     undefined
     > await runtime.run()
     { a: 0, b: 0 }
     succ
     { a: 1, b: 2 }
     succ
     { a: 2, b: 4 }
     failed
     Ctx { err: null, data: { a: 2, b: 4 } }
     > runtime.pc_
     2
     > await runtime.run()
     { a: 2, b: 4 }
     succ
     Ctx { err: null, data: { a: 3, b: 6 } }
     > runtime.reset()
     undefined
     >


### easy mode


        var ctx = {c:0}

        function creat_tsk(ctx) {
            let _f = function () {
                let p = new Promise((rs,rj)=>{
                    setTimeout(
                        ()=> {
                            let cond = Math.random()>0.5;
                            if(cond) {
                                console.log("succ:"+ctx.c)
                                rs('succ:'+ctx.c)
                                ctx.c = ctx.c+1
                            } else {
                                console.log("failed:"+ctx.c)
                                rj('fail:'+ctx.c)
                            }
                        },
                        2000
                    );
                });
                return(p)
            }
            return(_f)
        }


        var tsks = [creat_tsk(ctx),creat_tsk(ctx),creat_tsk(ctx),creat_tsk(ctx),creat_tsk(ctx)]

        var g = easy(tsks)
        await g.next()
        > await g.next()
        failed:0
        failed:0
        succ:0
        { value: { err: null, rslt: 'succ:0' }, done: false }
        >
        > await g.next()
        succ:1
        { value: { err: null, rslt: 'succ:1' }, done: false }
        > await g.next()
        failed:2
        failed:2
        succ:2
        { value: { err: null, rslt: 'succ:2' }, done: false }
        > await g.next()
        failed:3
        succ:3
        { value: { err: null, rslt: 'succ:3' }, done: false }
        > await g.next()
        failed:4
        succ:4
        { value: { err: null, rslt: 'succ:4' }, done: false }
        > await g.next()
        { value: undefined, done: true }
        >


METHODS
=======

###ctx

- ctx.copy_
- ctx.err
- ctx.data                  

- ctx.commit()                                            
- ctx.rollback()
- ctx.rtrn()                  
- ctx.thrw(err)



###runtime

- runtime.init\_data\_
- runtime.ctx\_
- runtime.err\_
- runtime.data\_
- runtime.funcs\_
- runtime.is\_succ
- runtime.pc\_
- runtime.run(enable\_throw=false)
- runtime.reset()



APIS
====
- normalize\_promise(old\_promise)
- retry(func,ctx,max\_times=Infinity,copy=DFLT\_COPY)
- easy(tsks,tsks,recover\_method\_name,yield\_err=false,...params)


LICENSE
=======
- ISC 
