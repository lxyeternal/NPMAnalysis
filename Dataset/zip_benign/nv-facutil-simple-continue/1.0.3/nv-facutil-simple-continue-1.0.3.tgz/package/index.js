function _ps() {
    let resolve;
    let p = new Promise((rs,rj)=>{resolve=rs});
    return([p,resolve])
}

function _validate_data(r) {
    if(r===null || typeof(r)!=='object') {
        throw(Ctx.ERROR.must_be_object)
    } else {}
}

function _validate_err(err) {
    if(err===null) {
        throw(Ctx.ERROR.cant_throw_null_err)
    } else {}
}

const DFLT_COPY = (data)=> {
    let d ={}
    Object.assign(d,data);
    return(d)
}


class Ctx {
    #prev
    #copy
    constructor(err,data,copy=DFLT_COPY) {
        //_validate_data(data);
        this.err = err;
        this.data = copy(data);
        this.#prev = copy(data)
        this.#copy = copy;
    }
    ////
    get copy_()  {return(this.#copy)}
    set copy_(f) {this.#copy =f}
    ////
    commit()      {
        if(this.err === null) {
            this.#prev = this.#copy(this.data);
        } else {
            console.log(Ctx.ERROR.err_cant_commit)
        }
    }
    rollback()    {
        this.data = this.#copy(this.#prev);
        this.err  = null;
    }
    ////
    rtrn()    {this.err = null}
    thrw(err) {
        _validate_err(err);
        this.err = err
    }
}
Ctx.ERROR = {
    err_cant_commit:'err_cant_commit',
    must_be_object:'must_be_object',
    cant_throw_null_err:'cant_throw_null_err'
}


function normalize_promise(op) {
    let [p,rs] = _ps();
    op.then(r=>{
        rs(new Ctx(null,r))
    }).catch(err=>{
        rs(new Ctx(err,null))
    });
    return(p)
}


async function retry(f,ctx,max_times=Infinity) {
    let c = 0
    while(true) {
        let {err,data} = await f(ctx);
        c = c +1;
        ////
        if(c===max_times) { return(ctx)}
        ////
        if(err === null) {
            ctx.commit()
            return(ctx)
        } else {
            ctx.rollback()
        }
    }
}




class Runtime {
    #funcs = []
    #init_data
    #ctx
    #copy = DFLT_COPY
    #pc = 0
    constructor(funcs,init_data,copy=DFLT_COPY) {
        this.#funcs       = funcs;
        this.#init_data   = init_data;
        this.#copy        = copy
        this.#ctx         = new Ctx(null,init_data,copy)
    }
    ////
    get init_data_() {return(this.#init_data)}
    get ctx_()       {return(this.#ctx)}
    get err_()       {return(this.#ctx.err)}
    get data_()      {return(this.#ctx.data)}
    get funcs_()     {return(this.#funcs)}
    ////
    is_succ()        {return(this.#pc === this.#funcs.length)}
    ////
    get pc_()        {return(this.#pc)}
    ////
    reset() {
        this.#pc = 0;
        this.#ctx         = new Ctx(null,this.#init_data,this.#copy)
    }
    ////
    async run(enable_throw=false) {
        while(this.#pc < this.#funcs.length) {
            console.log(this.#ctx.data)
            let f = this.#funcs[this.#pc];
            let {err,data} = await f(this.#ctx);
            if(err === null) {
                this.#ctx.commit();
                this.#pc = this.#pc + 1
            } else {
                this.#ctx.rollback();
                if(enable_throw) {
                    throw(err)
                } else {
                    break;
                }
            }
        }
        return(this.#ctx)
    }
}


async function * easy(tsks,recover_method_name,yield_err=false,...params) {
    let c = 0;
    while(c<tsks.length) {
        try {
            let rslt = await tsks[c](...params);
            yield({err:null,rslt});
            c = c +1;
        } catch(err) {
            if(yield_err) {
                yield({err,rslt:null})
            } else {}
            if(recover_method_name!==undefined) {
                tsks[c][recover_method_name](...params); //must be sync
            } else {}
        }
    }
}


module.exports = {
    normalize_promise,
    ////
    Ctx,
    DFLT_COPY,
    retry,
    ////
    Runtime,
    ////
    easy
}
