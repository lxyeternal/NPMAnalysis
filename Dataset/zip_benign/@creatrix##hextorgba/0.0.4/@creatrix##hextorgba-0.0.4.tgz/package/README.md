# installation

convert hex color to RGBA

# example
```js
yarn add @creatrix/hextorgba
```

```js
npm i @creatrix/hextorgba
```

```js
import {convertHexToRGBA} from @creatrix/hextorgba;

const hexcolor='#FFF';

const converttorgba=convertHexToRGBA(hexcolor,'0.5') // rgba(255,255,255,0.5)
```
