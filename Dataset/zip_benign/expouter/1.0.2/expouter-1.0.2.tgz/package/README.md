# Getting Started with Awesome Router

```ts
import "@vio/router";

import express, { Router } from "express";

const router = Router();

router.get("/", "UsersController.index");

const app = express();

app.use(router);
app.listen(5000);
```

## Features

- [x] Automatically bind controllers with their routes
- [x] Group routes
- [ ] Scaffold resourceful routes

## Milestone 0.1

- [x] Create an express router wrapper
- [x] Allow to create routes which dynamically find the controller methods
- [x] Set middleware for each route
- [x] Set default Path for controllers
- [ ] Fix types
- [ ] Add tests
- [ ] Add JSDocs

## Milestone 0.2

_Group notes_

## Milestone 0.3

_Scaffold resourceful routes_

## Milestone 0.4

_Support for other routers_

# API

## Init

```ts
import { Router } from "express";
import { AwesomeRouter } from "Vio/AwesomeRouter";

const controllersPath = __dirname + "/Controllers";

const router = AwesomeRouter(Router(), controllersPath);
```

## Router[GET | POST | PATCH | PUT | DELETE | HEAD]

```ts
router.get("/", "UserController.index", [AuthMiddleware]);
```

## Router.group

```ts
router.group(
  "/users",
  (route) => {
    route.get("/", "UserController.index");
    route.get("/:id", "UserController.show", [withUserMiddleware]);
  },
  [AuthMiddleware]
);
```

## Router.resource

```ts
router.resource("users", "UserController");
/*
  [GET] /users              -  UserController.index
  [POST] /users             -  UserController.store
  [GET] /users/:id          -  UserController.show
  [PATCH/PUT] /users/:id    -  UserController.update
  [DELETE] /users/:id       -  UserController.destroy
*/
```

```ts
router.resource("users", "UserController", {
  except: ["destroy"],
});

/*
  [GET] /users              -  UserController.index
  [POST] /users             -  UserController.store
  [GET] /users/:id          -  UserController.show
  [PATCH/PUT] /users/:id    -  UserController.update
*/
```

```ts
router.resource("users", "UserController", {
  only: ["destroy"],
});

/*
  [DELETE] /users/:id    -  UserController.destroy
*/
```

**Adding Middleware**

```ts
router.resource("users", "UserController", {
  middleware: {
    all: [AuthController]
    index: [WithUser]
  }
});
```

# Other

## Override the default controllers directory

```ts
const controllersDir = __dirname + "/Controllers";
const router = AwesomeRouter({
  controllersDir,
});
```
