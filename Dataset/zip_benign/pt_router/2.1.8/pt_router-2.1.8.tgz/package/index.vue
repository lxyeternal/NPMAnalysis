<template>

        <header-nav :title="title" ref="adheader" :back-link="backLink" :back-text="backText"></header-nav>

        <div class="page__bd">
            <panel :list="list"></panel>
            <hr>
            <a href="/find" pt-router>发现</a>


        </div>

</template>
<style>


</style>
<script>

    ptRouter.useComponentUrl = [ '/component/headerNav.vue' , '/component/weui/panel.vue' ];
    var opt = {};
    opt.data = {
        title : 'ptRouter路由' ,
        backText : '首页' ,
        backLink : '#/' ,
        list : [ { name : 'n1' } , { name : 'n2' } , { name : 'n2' } , { name : 'n2' } , { name : 'n2' } , { name : 'n2' } ]
    };
    opt.ready = function () {

    };
    opt.ptRouterLoad = function ( routerData ) {

        console.log( this.$refs );
    };
    opt.ptRouterHidePage = function ( routerData ) {

    };
    opt.ptRouterBeforeLoad=function ( RouterData ) {
        console.log( RouterData );
        console.log( RouterData.name );

    }
    ptRouter.vue = new Vue( opt );

</script>