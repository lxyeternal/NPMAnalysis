<template>
    <div>
        <div>
            <header-nav top-title="title"></header-nav>
        </div>
        <div>
            我的个人中心
            我的个人中心
            <br>
            <br>
            <a href="javascript:router.closeCurrentPage()">关闭</a>
            <br>
            <br>
            我的个人中心
            我的个人中心
        </div>
    </div>

</template>
<style>

</style>

<script>
    ptRouter.useComponentUrl=['/component/headerNav.vue'];
    ptRouter.vue=new ptRouter.$vue( {data:{title:''}} );
</script>