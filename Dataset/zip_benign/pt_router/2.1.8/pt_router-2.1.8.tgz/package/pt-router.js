(
    function ( global , factory ) {
        typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() : typeof define === 'function' && define.amd ? define( factory ) : (
            global.ptRouter = factory()
        );
    }( this , function () {
        var Vue;
        var ptRouter = function ( option ) {
            {
                var _t     = this;
                _t.version = '2.1.8';
                /**
                 * separator:router url 路由分隔符
                 * @type {{separator: string}}
                 */
                this._opt = {separator: '#' , TagEventSelector: 'a[pt-link]'};
                /**
                 * 历史记录索引
                 * @type {number}
                 * @private
                 */
                this._history_index = 0;
                this._templateCache = [];
                
                this._router_name = 'ptRouter';
                
                /**
                 * 历史记录状态
                 * @type {{router_name: string, path: string, index: number}}
                 * @private
                 */
                this._pageState = {router_name: _t._router_name , path: '/' , index: this._history_index};
                /**
                 * 路由列表
                 * @type {Array}
                 */
                this._routerList = [];
                /**
                 * 视图标签名
                 * @type {string}
                 * @private
                 */
                this._router_tag = 'pt-router-view';
                /**
                 * 基路由
                 * @type {string}
                 * @private
                 */
                this._root_domain = '';
                
                this._current_router = '/';
                /**
                 * 页面切换事件
                 * @type {number}
                 */
                this._toggleSpeed = 400;
                
                /**
                 * 历史记录事件队列
                 * @type {Array}
                 */
                this.onPopStateQueue = [];
                /**
                 * 页面数组，以路由路径为key,保存page对象
                 * @type {Array}
                 */
                this.pageList = [];
                this.isGoBack = false;
                this._history = [];
                /**
                 * 是否是后退
                 * @type {boolean}
                 */
                this.isGoBack = false;
                
                /**
                 * pt-router url 参数,解析后的对象
                 * 参数是路由分隔之后的请求参数 #name?id=2&name=name
                 * @type {{}}
                 */
                this._routerParam = {};
                /**
                 * 路由网页容器
                 * @type {string}
                 */
                this._pageContainerSelector = '';
                /**
                 * 是否开启页面切换动画效果
                 * @type {boolean}
                 * @private
                 */
                this._toggleAnimation = false;
                this.isInited = false;
                
                /**
                 * 初始化
                 * @param pageContainerSelector 路由页面容器选择器
                 * @param opt 选项
                 * opt.goBack=function(){}  后退事件,返回false ，ptRouter 路由不切换，但浏览器的后退事依然进行。
                 * opt.goPrevious=function(){}前进事件，返回false ,ptRouter 路由不切换，但浏览器的前进事依然进行。
                 * opt.TagEventSelector='a[pt-router]'; 链接事件选择器
                 * opt.separator='#'; 路由分隔符
                 * opt.container={top:0,left:0,right:0,bottom:0} [v0.5.1+失效]//路由页面容器定位
                 * opt.toggleSpeed //切换时间长，毫秒为单位
                 * opt.toggleAnimation =false 切换动画效果
                 * opt.vueComponents=[] 全局组件,url 方式:opt.vueComponents=['test.vue']; 直接vue组件方式：opt.vueComponents={'com1':component}
                 * opt.initBefore=function() 初始化回调，在页面加载之前
                 * opt.pageLoadBefore=function(routerData) 全局方法，页面显示之前回调,返回false 页面不显示
                 * opt.pageLoaded=function(routerData)  全局方法，页面已显示之后回调
                 * opt.vueComponentBasePath='' [v2.0]//vue子组件基目录设置，在加载组件时，会与此路径为根目录上加载
                 * opt.pageComponentBasePath='' [v2.0]//vue页面级组件基目录设置，在加载组件时，会与此路径为根目录上加载
                 * opt.pageCreated =function(pageInstance) 页面创建时钩子
                 * opt.notBack=function() 当前历史记录状态的index为1时，后退事件触发回调事件。
                 */
                this.init = function ( pageContainerSelector , opt ) {
                    opt                           = opt || {};
                    this.isInited                 = true;
                    _t._opt.separator             = opt.separator || _t._opt.separator;
                    _t._opt.goBackEvent           = opt.goBack;
                    _t._opt.goPreviousEvent       = opt.goPrevious;
                    _t._opt.TagEventSelector      = opt.TagEventSelector || _t._opt.TagEventSelector;
                    _t._opt.pageLoadBefore        = opt.pageLoadBefore;
                    _t._opt.pageLoaded            = opt.pageLoaded;
                    _t._opt.pageCreated           = opt.pageCreated || false;
                    _t._opt.vueComponentBasePath  = opt.vueComponentBasePath || '';
                    _t._opt.pageComponentBasePath = opt.pageComponentBasePath || '';
                    _t._notBack                   = opt.notBack;
                    _t._toggleSpeed               = opt.toggleSpeed || _t._toggleSpeed;//切换速度
                    _t._toggleAnimation           = typeof opt.toggleAnimation == 'undefined' ? false : opt.toggleAnimation;
                    
                    _t._pageContainerSelector = pageContainerSelector || 'body';
                    
                    //加载组件
                    if ( opt.vueComponents ) {
                        if ( typeof opt.vueComponents == 'object' ) {
                            console.log( opt.vueComponents );
                            for ( var i in opt.vueComponents ) {
                                if ( opt.vueComponents[ i ] ) {
                                    if ( typeof opt.vueComponents[ i ] == 'object' ) {
                                        //
                                        ptRouter.$vue.component( i , opt.vueComponents[ i ] );
                                        
                                        console.log( ptRouter.$vue.components );
                                    } else {
                                        ptRouter.addComponent( _t._opt.vueComponentBasePath + opt.vueComponents[ i ] );
                                    }
                                } else {
                                    console.warn( 'the "Component URL" for option data type invalid,it must be string type or not empty' );
                                }
                            }
                            ptRouter.loadVueComponent();
                        } else {
                            console.warn( 'the "opt.vueComponents" for option data type invalid,it must be array type' );
                        }
                    }
                    
                    _t._history_index = history.state ? history.state.index || 0 : 0;
                    _t.createCssKeyframes();
                    window.onpopstate = function ( event ) {
                        for ( var i in _t.onPopStateQueue ) {
                            if ( typeof _t.onPopStateQueue[ i ] == 'function' ) {
                                _t.onPopStateQueue[ i ]( event );
                            }
                        }
                        _t.load( location.hash , 2 );
                    };
                    
                    _t.parseRouterMap();
                    
                    if ( _t.chkFunction( opt.initBefore ) ) {
                        opt.initBefore( _t );
                    }
                    
                    _t.load();
                };
                /**
                 * 创新动画css
                 */
                this.createCssKeyframes = function () {
                    
                    var style  = '    @-webkit-keyframes ptRouterSlideIn{0%{-webkit-transform:translate3d(100%,0,0);transform:translate3d(100%,0,0);opacity:0}to{-webkit-transform:translateZ(0);transform:translateZ(0);opacity:1}}@keyframes ptRouterSlideIn{0%{-webkit-transform:translate3d(100%,0,0);transform:translate3d(100%,0,0);opacity:0}to{-webkit-transform:translateZ(0);transform:translateZ(0);opacity:1}}@-webkit-keyframes ptRouterSlideOut{0%{-webkit-transform:translateZ(0);transform:translateZ(0);opacity:1}to{-webkit-transform:translate3d(100%,0,0);transform:translate3d(100%,0,0);opacity:0}}@keyframes ptRouterSlideOut{0%{-webkit-transform:translateZ(0);transform:translateZ(0);opacity:1}to{-webkit-transform:translate3d(100%,0,0);transform:translate3d(100%,0,0);opacity:0}}';
                    var _times = _t._toggleSpeed + 'ms';
                    var str    = 'ptRouterSlideIn ' + _times + ' forwards';
                    style += ' .ptRouterSlideIn{-webkit-animation:' + str + ';animation:' + str + '}';
                    str        = 'ptRouterSlideOut ' + _times + ' forwards';
                    style += '.ptRouterSlideOut{-webkit-animation:' + str + ';animation:' + str + '}';
                    document.head.innerHTML += '<style>' + style + '</style>';
                };
                
                /**
                 * 检测变量是不是函数
                 * @param funcName
                 * @returns {boolean}
                 */
                this.chkFunction = function ( funcName ) {
                    return typeof funcName == 'function';
                };
                /**
                 * 解析路由请求参数
                 * @param router_query
                 * @returns {*}
                 */
                this.parseUrlParam = function ( router_query ) {
                    var queryData   = {};
                    queryData.path  = '/';
                    queryData.param = {};
                    var _RouterData = null;
                    
                    if ( typeof router_query == 'string' && router_query != '' ) {
                        var temArr     = router_query.split( '?' );
                        queryData.path = $.trim( temArr[ 0 ] );
                        queryData.path = queryData.path.replace( '#' , '' );
                        if ( queryData.path == '' ) queryData.path = '/';
                        //路由匹配处理，
                        var UrlPattern = /:\w+/gi;
                        for ( var j in _t._routerList ) {
                            var RouterData = _t._routerList[ j ];
                            RouterData.url == $.trim( RouterData.url );
                            if ( queryData.path == RouterData.url ) {
                                //直接命中
                                _RouterData = RouterData;
                                break;
                            } else {
                                //路由正则匹配处理
                                if ( RouterData && RouterData.url && typeof RouterData.url == 'string' && UrlPattern.test( RouterData.url ) ) {
                                    //_t.debug( '有路由正则' );
                                    //_t.debug( '请求路由Path : ' +queryData.path );
                                    //var str = '/index/:id/:name';
                                    var Rex2 = new RegExp( RouterData.url.replace( /:\w+/gi , '\\w+' ) , 'gi' );//把原路由正则转成正规正则
                                    //console.log( Rex2 );
                                    if ( Rex2.test( queryData.path ) ) {
                                        _RouterData  = RouterData;
                                        //对应正则参数赋值
                                        var matchRes = queryData.path.split( '/' );
                                        var arr      = RouterData.url.split( '/' );
                                        for ( var i in arr ) {
                                            var sub = arr[ i ].substr( 0 , 1 );
                                            if ( sub == ':' ) {
                                                queryData.param[ arr[ i ].substr( 1 ) ] = matchRes[ i ];
                                            }
                                        }
                                        //console.log( queryData.path.match(/\w+/gi) );
                                        break;
                                    } else {
                                        //_t.debug( '路由没有完全匹配' );
                                    }
                                    
                                } else {
                                    //_t.debug( '路由没有正则' );
                                }
                            }
                        }
                        if ( !_RouterData ) {
                            return false;
                        }
                        _RouterData.routerPath    = queryData.path;
                        _RouterData.urlHash       = router_query;
                        var paramStr              = temArr[ 1 ] || '';
                        //路由参数
                        _RouterData.router_params = _t.parseUrlParamByStr( paramStr );
                        //原URL参数
                        _RouterData.params        = _t.parseUrlParamByStr( location.search.replace( '?' , '' ) );
                        //两种参数合并，路由参数优先
                        for ( var p in _RouterData.router_params ) {
                            _RouterData.params[ p ] = _RouterData.router_params[ p ];
                        }
                    }
                    return _RouterData;
                };
                /**
                 * 解析url 参数
                 * @param paramStr
                 * @returns {Array}
                 */
                this.parseUrlParamByStr = function ( paramStr ) {
                    var param = [];
                    if ( typeof paramStr == 'string' ) {
                        var paramArr1 = paramStr.split( '&' );
                        for ( var i in paramArr1 ) {
                            var paramArrV = paramArr1[ i ].split( '=' );
                            if ( paramArrV[ 0 ] ) {
                                param[ paramArrV[ 0 ] ] = decodeURIComponent( paramArrV[ 1 ] ) || null;
                            }
                        }
                    }
                    return param;
                };
                
                /**
                 * 注册历史监听事件
                 * @param functionName
                 */
                this.registerHistoryPopEvent = function ( functionName ) {
                    
                    if ( typeof functionName == 'function' ) {
                        _t.onPopStateQueue.push( functionName );
                    } else {
                        throw new Error( 'routerPath invalid' );
                    }
                };
                
                this.debug = function ( message ) {
                    console.trace( _t._router_name + ' debug :' , message );
                };
                
                /**
                 * 路由应射
                 * @param option
                 * { name:'movie', url:'/movie', templateUrl:'/movie.html',//模板url vue:''//路由Vue对象 }
                 *
                 */
                this.map = function ( option ) {
                    if ( typeof option == 'object' ) {
                        if ( option.name && typeof option.name == 'string' && option.name !== '' ) {
                            if ( typeof _t._routerList[ option.name ] == 'object' ) {
                                console.warn( 'the router ' + option.name + ' is already exist' );
                            } else {
                                _t._routerList[ option.name ] = option;
                            }
                        } else {
                            throw new Error( 'routerPath invalid' );
                        }
                    } else {
                        console.error( 'ptRoute map() option param must be object' );
                    }
                };
                
                /**
                 * 默认路由
                 * @param option 对象或路由名
                 */
                this.default = function ( option ) {
                    if ( typeof option == 'object' ) {
                        if ( typeof option.name == 'string' && option.name !== '' ) {
                            _t._routerList[ '' ] = option;
                        } else {
                            throw new Error( 'routerPath invalid' );
                        }
                        
                    } else if ( typeof option == "string" && option != '' ) {
                        if ( _t._routerList[ option ] ) {
                            _t._routerList[ '' ] = _t._routerList[ option ];
                        }
                    } else {
                        console.error( 'ptRoute map() option param must be object' );
                    }
                };
                
                /**
                 * 设置404路由
                 * @param option
                 */
                this.error404 = function ( option ) {
                    if ( typeof option == 'object' ) {
                        if ( option.name && typeof option.name == 'string' && option.name !== '' ) {
                            this._routerList[ 'error_404' ] = option;
                        } else {
                            throw new Error( 'routerPath invalid' );
                        }
                    } else {
                        console.error( 'ptRoute map() option param must be object' );
                    }
                };
                /**
                 * 获取404路由
                 * @returns {*}
                 */
                this.getError404 = function () {
                    return this._routerList[ 'error_404' ];
                };
                /**
                 * 添加历史记录
                 */
                this.pushHistory = function ( RouterData ) {
                    
                    if ( !history.state || history.state.router_name != _t._router_name ) {
                        _t._pageState.index = _t._history_index;
                        history.replaceState( _t._pageState , null , _t._current_router );
                    } else {
                        if ( history.state.router_name && history.state.router_name == _t._router_name && _t._current_router != location.hash ) {
                            //_t.isGoBack         = false;
                            _t._pageState.index = _t._history_index;
                            _t._pageState.hash  = _t._current_router;
                            history.pushState( _t._pageState , null , _t._current_router );//浏览器记录
                            _t._history.push( this._pageState );//路由历史记录
                            _t.debug( '[add history], length=' + history.length );
                        }
                        
                    }
                    
                };
                
                /**
                 * 解析路由映射,绑定路由事件
                 */
                this.parseRouterMap = function () {
                    
                    var RouterTagObj = $( 'a[pt-router]' );
                    _t.debug( 'A 路由标签：' + RouterTagObj.length );
                    //解决ios 闪屏问题
                    RouterTagObj.css( {
                        '-webkit-appearance': 'none' , '-webkit-transform-style': 'preserve-3d' , '-webkit-backface-visibility': 'hidden'
                    } );
                    
                    RouterTagObj.unbind( 'click' ).on( 'click' , function ( e ) {
                        var _href = $( this ).attr( 'href' );
                        if ( _href ) {
                            if ( _href.substr( 0 , 11 ) == 'javascript:' ) {
                                return true;
                            } else {
                                _t.load( _href , 1 );
                            }
                        } else {
                            console.error( 'not path for request url' );
                        }
                        
                        if ( e && e.preventDefault ) e.preventDefault(); else
                            window.event.returnValue = false;
                        return false;
                    } );
                };
                /**
                 * 获取映射路由数据
                 * @param name
                 * @returns {*|null}
                 */
                this.getRouterMapData = function ( name ) {
                    return _t._routerList[ name ] || null;
                };
                /**
                 * 路由后退
                 * 如果当前的历史记录index为 1，说明没有历史，则会触发没有后退事件，这样可以处理
                 */
                this.back = function () {
                    if ( history.state && history.state.index== 1 ) {
                        if ( _t.chkFunction( _t._notBack ) ) {
                            _t._notBack( _t._currentShowPageRouterData );
                        }
                    } else {
                        history.back();
                    }
                };
                
                /**
                 * 加载路由
                 * @param ptRouterQuery
                 * @param EventType 事件类型 1 链接事件，2 历史事件，3 不加历史记录
                 */
                this.load = function ( ptRouterQuery , EventType , RouterData ) {
                    EventType = EventType || 1;
                    _t.debug( 'history_index=' + _t._history_index );
                    if ( history.state && history.state.router_name == _t._router_name ) {
                        if ( EventType == 2 ) {
                            if ( history.state.index < _t._history_index ) {
                                _t.isGoBack = true;
                                _t.debug( '后退' );
                                if ( _t.chkFunction( _t._opt.goBackEvent ) ) {
                                    //返回false 不加载页面
                                    if ( _t._opt.goBackEvent( _t ) === false ) {
                                        return false;
                                    }
                                }
                                _t._history_index = history.state.index;
                            } else if ( history.state.index > _t._history_index ) {
                                _t.isGoBack = false;
                                _t.debug( '前进' );
                                
                                if ( _t.chkFunction( _t._opt.goPreviousEvent ) ) {
                                    //返回false 不加载页面
                                    if ( _t._opt.goPreviousEvent( _t ) === false ) {
                                        return false;
                                    }
                                }
                                _t._history_index = history.state.index;
                            } else {
                                _t.isGoBack = false;
                            }
                        } else {
                            _t.isGoBack = false;
                        }
                        if ( history.state.index == _t._history_index ) {
                            _t.debug( '刷新页面' );
                        } else {
                            _t.debug( '新页面' );
                        }
                    }
                    
                    ptRouterQuery = ptRouterQuery || location.hash;
                    
                    if ( _t._current_router == ptRouterQuery )return false;
                    if ( ptRouterQuery ) {
                        _t._current_router = ptRouterQuery;//|| (_t._opt.separator+'/');
                        RouterData         = _t.parseUrlParam( _t._current_router );
                    } else {
                        RouterData = _t._routerList[ '' ];
                        if ( RouterData ) _t._current_router = RouterData.url;
                    }
                    
                    if ( !RouterData ) {
                        var errorRouter = _t.getError404();//404页面
                        if ( errorRouter && typeof errorRouter == 'object' ) {
                            RouterData         = errorRouter;
                            _t._current_router = RouterData.url;
                        } else {
                            console.warn( 'not match path router, please set 404 error Router by method "error404()" ' );
                            return false;
                        }
                    }
                    //加上#
                    if ( _t._current_router.charAt( 0 ) != _t._opt.separator ) {
                        _t._current_router = _t._opt.separator + _t._current_router;
                    }
                    //全局页面加载之前回调
                    if ( _t.chkFunction( _t._opt.pageLoadBefore ) ) {
                        //返回false ，不加载页面
                        if ( _t._opt.pageLoadBefore( RouterData ) === false ) {
                            console.warn( 'the method "pageBeforeLoad()" is return false' );
                            return false;
                        }
                    }
                    
                    //页面加载之前回调
                    if ( typeof RouterData == 'object' && _t.chkFunction( RouterData.pageLoadBefore || null ) ) {
                        //返回false ，不加载页面
                        if ( RouterData.pageLoadBefore( RouterData ) === false ) {
                            console.warn( 'the method "pageLoadBefore()" is return false' );
                            return false;
                        }
                    }
                    
                    var pageData = _t._getPageDataByRouterPath( RouterData.url );
                    
                    if ( !pageData ) {
                        var pageContent = _t.getPageContent( RouterData );//page 页面内容
                        var pageId      = null;
                        if ( pageContent.vue ) {
                            RouterData.vue = pageContent.vue;
                            if ( pageContent.style ) {
                                document.head.innerHTML += pageContent.style;
                            }
                            pageId = _t.createPage( '' , RouterData );
                        } else {
                            pageId = _t.createPage( pageContent.content , RouterData );
                        }
                        if ( typeof RouterData.vueComponent == 'object' && !RouterData.vue ) {
                            RouterData.vue = new ptRouter.$vue( RouterData.vueComponent );
                        }
                        if ( RouterData.vue && typeof RouterData.vue == 'object' ) {
                            if ( !RouterData.vue.$options ) RouterData.vue.$options = {};
                            if ( !RouterData.vue.$options.methods ) RouterData.vue.$options.methods = {};
                            RouterData.vue.$options.methods.getPtRouter = function () {
                                return _t;
                            };
                            
                        }
                        pageData                      = {'pageId': pageId};
                        pageData.router_name          = RouterData.router_name;
                        RouterData.pageData           = pageData;
                        _t.pageList[ RouterData.url ] = pageData;//页面列表
                        //页面初始化回调
                        if ( RouterData.pageInit && _t.chkFunction( RouterData.pageInit ) ) {
                            RouterData.pageInit( RouterData );
                        }
                        
                    }
                    
                    //在实例挂载dom之前调用回调
                    if ( RouterData.vue ) {
                        
                        if (  !RouterData.vue._isMounted ) {
                            if ( RouterData.vue.$options && _t.chkFunction( RouterData.vue.$options.ptRouterBeforeLoad ) ) {
                                RouterData.vue.ptRouterBeforeLoad = RouterData.vue.$options.ptRouterBeforeLoad;
                                delete RouterData.vue.$options.ptRouterBeforeLoad;
                                RouterData.vue.ptRouterBeforeLoad( RouterData );
                            }
                            //vue实例注册关闭当前页面方法
                            RouterData.vue.closeCurrentPage = _t.closeCurrentPage;
                            RouterData.vue.loadByName       = _t.loadByName;
                            RouterData.vue.load             = _t.load;
                            if ( !RouterData.vue.$options ) {
                                RouterData.vue.$options = {}
                            }
                            //vue 对象
                            if ( !RouterData.vue.$options.template ) {
                                RouterData.vue.$options.template = pageContent.content;
                            }
                            RouterData.vue.$options.replace = false;
                            //RouterData.vue.$mount( '#' + pageId+' > div');
                            
                            RouterData.vue.$mount( );
                            $('#' + pageId ).append( RouterData.vue.$el );
                            
                        } else {
                            
                            //console.error( 'the vue install is ready mount' );
                        }
                    }
    
                    if ( RouterData.vue && typeof RouterData.vue == 'object' ) {
                        ptRouter.$vue. RouterData= RouterData ;
                    }
                    
                    _t._pageState.path = ptRouterQuery;
                    _t._pageState.id   = pageData.pageId;
                    _t._history_index++;
                    if ( EventType != 3 && RouterData.notHistory !== true ) {
                        _t.pushHistory( RouterData );
                    }
                    
                    //显示页面
                    _t.showPage( RouterData );
                    if ( _t._toggleAnimation ) {
                        setTimeout( function () {
                            //页面滑动后再加载事件
                            _t.loadShowPagedEvent( RouterData );
                        } , _t._toggleSpeed );
                    } else {
                        _t.loadShowPagedEvent( RouterData );
                    }
                };
                /**
                 * 加载回调事件
                 * @param RouterData
                 */
                this.loadShowPagedEvent = function ( RouterData ) {
                    //全局页面加载显示后的回调
                    if ( _t.chkFunction( _t._opt.pageLoaded || null ) ) {
                        if ( RouterData.vue ) {
                            RouterData.vue.pageLoaded = _t._opt.pageLoaded;
                            //delete _t._opt.pageLoaded;
                            RouterData.vue.pageLoaded( RouterData );
                        } else {
                            if ( _t._opt.pageLoaded( RouterData ) === false ) {
                                //return false 将会被回退操作，待开发
                            }
                        }
                    }
                    //本页面加载显示后的回调
                    if ( typeof RouterData == 'object' && _t.chkFunction( RouterData.pageLoaded || null ) ) {
                        
                        if ( RouterData.vue ) {
                            RouterData.vue.locationPageLoaded = RouterData.pageLoaded;
                            //delete RouterData.pageLoaded;
                            RouterData.vue.locationPageLoaded( RouterData );
                        } else {
                            if ( RouterData.pageLoaded( RouterData ) === false ) {
                                //return false 将会被回退操作，待开发
                            }
                        }
                        
                    }
                    //路由显示页面完成后，调用vue实例事件
                    if ( RouterData.vue && typeof RouterData.vue.$options == 'object' && _t.chkFunction( RouterData.vue.$options.ptRouterLoad ) ) {
                        RouterData.vue.ptRouterLoad = RouterData.vue.$options.ptRouterLoad;
                        //delete RouterData.vue.$options.ptRouterLoad;
                        RouterData.vue.ptRouterLoad( RouterData );
                    }
                    _t.parseRouterMap( RouterData.pageData.pageId );
                };
                
                /**
                 * 通过路由名称加载页面
                 * callParam.urlParams 对象是特定的url参数
                 * @param routerName
                 * @param callParam
                 */
                this.loadByName = function ( routerName , callParam ) {
                    var RouterData        = _t._routerList[ routerName ];
                    callParam             = callParam || {};
                    RouterData.callParams = callParam;
                    var url               = RouterData.url;
                    if ( RouterData.callParams.urlParams && typeof RouterData.callParams.urlParams ) {
                        //RouterData.url+=(RouterData.url.indexOf('?')==-1?'':'?');
                        var paramStr = _t.ArrToUrlParam( RouterData.callParams.urlParams );
                        url          = url + (
                                paramStr == '' ? '' : (
                                           RouterData.url.indexOf( '=' ) == -1 ? '?' : '&'
                                       ) + paramStr
                            );
                    }
                    _t.load( url , 1 , RouterData );
                };
                /**
                 * 对象或数组转url参数
                 * @param paramObj
                 * @returns {string}
                 * @constructor
                 */
                this.ArrToUrlParam = function ( paramObj ) {
                    if ( typeof  paramObj != 'object' ) {
                        return '';
                    }
                    var str = '';
                    for ( var i in paramObj ) {
                        str += (
                            str == '' ? '' : '&'
                        );
                        str += i + '=' + encodeURIComponent( paramObj[ i ] );
                    }
                    return str;
                };
                
                /**
                 * 通过页面id获取路由数据
                 * @param pageId
                 * @returns {*}
                 */
                this.getRouterDataByPageId = function ( pageId ) {
                    var router_name = '';
                    for ( var i in _t.pageList ) {
                        if ( _t.pageList[ i ].pageId == pageId ) {
                            router_name = _t.pageList[ i ].router_name;
                            break;
                        }
                    }
                    if ( _t._routerList[ router_name ] ) {
                        return _t._routerList[ router_name ];
                    }
                    return null;
                };
                /**
                 * 获取页面内容
                 * @param RouterData
                 * @returns {*}
                 */
                this.getPageContent = function ( RouterData ) {
                    //template优先
                    if ( typeof RouterData != 'object' ) {
                        console.error( 'RouterData not object' );
                    }
                    var pageContent = {};
                    if ( RouterData.template ) {
                        pageContent.content = RouterData.template || '';
                    } else if ( RouterData.templateElement ) {
                        //模板是dom选择器
                        pageContent.content = $( RouterData.templateElement ).html();
                    } else if ( RouterData.templateUrl ) {
                        pageContent = _t._templateCache[ RouterData.templateUrl ];
                        if ( pageContent )return pageContent;
                        pageContent = {};
                        //vue模板处理
                        if ( _t.isVueTemplate( RouterData.templateUrl ) ) {
                            pageContent.vue = ptRouter.getVueInstance( _t._opt.pageComponentBasePath + RouterData.templateUrl , _t );
                        } else {
                            pageContent.content = ptRouter.getTemplateContent( _t._opt.pageComponentBasePath + RouterData.templateUrl , _t );
                        }
                        _t._templateCache[ RouterData.templateUrl ] = pageContent;
                    }
                    return pageContent;
                };
                /**
                 * 判断是不是vue模板url
                 * @param templateUrl
                 */
                this.isVueTemplate = function ( templateUrl ) {
                    if ( templateUrl.substr( templateUrl.lastIndexOf( '.' ) + 1 ) == 'vue' ) {
                        return true;
                    }
                    return false;
                };
                /**
                 * 获取页面路由容器
                 * @returns {*|HTMLElement}
                 */
                this.getContainer = function () {
                    return $( _t._pageContainerSelector );
                };
                /**
                 * 通过路由path 从页面数组表中获取页面数据对象
                 * @param path
                 * @returns {*|null}
                 * @private
                 */
                this._getPageDataByRouterPath = function ( path ) {
                    return _t.pageList[ path ] || null;
                };
                /**
                 * 当前显示页面id
                 * @type {string}
                 * @private
                 */
                this._currentShowPageId = '';
                /**
                 * 保存当前显示页面的路由数据
                 * @type {null}
                 * @private
                 */
                this._currentShowPageRouterData = null;
                
                /**
                 * 保存显示页面记录 {RouterData:{}}
                 * @type {Array}
                 * @private
                 */
                this._showPageHistory = [];
                
                /**
                 * 显示页面
                 * @param RouterData
                 */
                this.showPage = function ( RouterData ) {
                    if ( typeof RouterData != 'object' )return false;
                    pageId = RouterData.pageData.pageId;
                    _t.debug( 'show page :' + '#' + pageId );
                    var container = _t.getContainer();
                    if ( _t._currentShowPageId == pageId )return false;
                    if ( pageId && typeof pageId == 'string' ) {
                        _t._showPageHistory.push( RouterData );//页面显示记录
                        if ( _t._showPageHistory.length > 30 ) _t._showPageHistory.pop();//大于30,自动减少
                        try {
                            var currentShowPage = $( '#' + _t._currentShowPageId );//当前已显示的页面
                        } catch ( e ) {
                            console.log( e.message );
                            currentShowPage = $;
                        }
                        
                        _t._current_router = RouterData.routerHash;
                        var willShowPage   = $( '#' + pageId );//将要显示的页面
                        if ( _t.isGoBack ) {
                            //后退时，先显示上一个页面，再没出当前页面
                            willShowPage.show().css( {'margin-left': 0} );
                            if ( RouterData.pageToggleAnimate === false || _t._toggleAnimation === false ) {
                                //后退滑出，禁用切换动画效果
                                currentShowPage.css( {
                                    'z-index': 0
                                } ).hide();
                                willShowPage.css( 'z-index' , 1 );
                                _t.pageHidePageEvent( _t._currentShowPageRouterData );
                                _t._currentShowPageId         = pageId;
                                _t._currentShowPageRouterData = RouterData;
                                
                            } else {
                                currentShowPage.addClass( 'ptRouterSlideOut' );
                                setTimeout( function () {
                                    currentShowPage.css( 'z-index' , 0 ).hide();
                                    currentShowPage.removeClass( 'ptRouterSlideOut' );
                                    willShowPage.css( 'z-index' , 1 );
                                    _t.pageHidePageEvent( _t._currentShowPageRouterData );
                                    _t._currentShowPageId         = pageId;
                                    _t._currentShowPageRouterData = RouterData;
                                    
                                } , _t._toggleSpeed );
                            }
                        } else {
                            
                            currentShowPage.css( 'z-index' , 0 );
                            if ( RouterData.pageToggleAnimate === false || _t._toggleAnimation === false ) {
                                //禁用页面切换动画效果
                                willShowPage.css( {'z-index': 1 , 'margin-left': 0} ).show();
                                if ( _t._currentShowPageId != pageId ) {
                                    currentShowPage.hide();
                                    _t.pageHidePageEvent( _t._currentShowPageRouterData );
                                }
                                _t._currentShowPageId         = pageId;
                                _t._currentShowPageRouterData = RouterData;
                                
                            } else {
                                willShowPage.show();
                                if ( _t._currentShowPageId != '' ) {
                                    willShowPage.addClass( 'ptRouterSlideIn' );
                                }
                                
                                willShowPage.css( {'z-index': 1 , 'margin-left': '0'} );
                                
                                setTimeout( function () {
                                    if ( _t._currentShowPageId != pageId && currentShowPage) {
                                        currentShowPage.hide();
                                        _t.pageHidePageEvent( _t._currentShowPageRouterData );
                                    }
                                    willShowPage.removeClass( 'ptRouterSlideIn' );
                                    _t._currentShowPageId         = pageId;
                                    _t._currentShowPageRouterData = RouterData;
                                    
                                } , _t._toggleSpeed );
                            }
                            
                        }
                        _t.isGoBack = false;
                    } else {
                        throw new Error( 'invalid page ID' );
                    }
                };
                /**
                 * 隐藏页面
                 * @param pageId
                 */
                this.hidePage = function ( pageId ) {
                    var page = $( '#' + pageId );
                    page.hide();
                };
                
                /**
                 * 被隐藏的页面事件
                 * @param routerData
                 */
                this.pageHidePageEvent = function ( routerData ) {
                    if ( !routerData || !routerData.vue )return false;
                    if(!routerData.vue.ptRouterHidePage ){
                        routerData.vue.ptRouterHidePage = routerData.vue.$options.ptRouterHidePage;
                        delete routerData.vue.$options.ptRouterHidePage;
                    }
                    if ( routerData && routerData.vue && _t.chkFunction( routerData.vue.ptRouterHidePage ) ) {
                        routerData.vue.ptRouterHidePage( routerData );
                    }
                };
                /**
                 * 关闭当前页面
                 */
                this.closeCurrentPage = function () {
                    _t.isGoBack = true;
                    _t.showPage( _t._showPageHistory[ _t._showPageHistory.length - 2 ] );
                };
                /**
                 * 获取路由路径
                 */
                this.getRouterPath = function () {
                    
                    var path      = location.hash || '/';
                    path          = path.replace( _t._opt.separator , '' );
                    var queryData = _t.parseUrlParam( path );
                    _t.debug( path );
                    _t._routerParam = queryData.param;
                    return queryData.path;
                };
                /**
                 * 获取路由请求参数
                 * @param name
                 * @returns {*|null}
                 */
                this.getRouterParam = function ( name ) {
                    var v = _t._routerParam[ name ] || null;
                    return v;
                };
                
                /**
                 * 获取当前路由url
                 * @returns {string}
                 */
                this.getFullRouteUrl = function () {
                    return location.origin + _t._opt.separator + _t._current_router;
                };
                
                this._router_pange_index = 0;
                /**
                 * 创建页面
                 * @param html
                 */
                this.createPage = function ( html , RouterData ) {
                    var container = _t.getContainer();
                    var PageDiv   = $( document.createElement( 'div' ) );
                    
                    PageDiv.hide();
                    
                    PageDiv.id = _t._pageState.router_name + 'Page_' + (
                            RouterData ? RouterData.name : ''
                        );
                    PageDiv.attr( 'id' , PageDiv.id );
                    PageDiv.attr( 'pageIndex' , _t._router_pange_index );
                    _t._router_pange_index++;
                    PageDiv.addClass( 'pt-router-page' );
                    PageDiv.html( html );
                    if ( _t.chkFunction( _t._opt.pageCreated ) ) {
                        _t._opt.pageCreated( RouterData , PageDiv , container );
                    }
                    $( _t._pageContainerSelector ).append( PageDiv );
                    
                    return PageDiv.id;
                };
                
            }
        };
        
        /**
         * 临时存放vue component 组件构建函数
         * @type {null}
         */
        ptRouter.vueComponent = null;
        
        ptRouter.prototype.vueComponentsList   = [];
        ptRouter.prototype.loadedVueComponents = [];
        //引入script 文件的url
        ptRouter.requireScript                 = [];
        //style 样式文件
        ptRouter.requireStyle                  = [];
        ptRouter.requireLoadedScript           = [];
        /**
         * 加载
         */
        ptRouter.loadScripts = function ( pathArr ) {
            if ( typeof  pathArr != 'object' ) {
                return false;
            }
            for ( var i in pathArr ) {
                var path = pathArr[ i ];
                if ( path != '' && typeof  path == 'string' ) {
                    if ( this.requireLoadedScript[ path ] ) {
                        continue;
                    }
                    var content = this.getTemplateContent( path );
                    if ( content ) {
                        //eval( content );
                        //document.getElementsByTagName( 'body' )[ 0 ].appendChild('<script>' + content + '</script>');
                        // document.body.innerHTML += '<script>'+content+'</script>';
                    }
                    //event( content );
                    this.requireLoadedScript[ path ] = true;
                } else {
                    console.error( 'invalid script file path!' );
                }
            }
        };
        ptRouter.loadStyle    = function ( pathArr ) {
            if ( typeof  pathArr != 'object' ) {
                return false;
            }
            for ( var i in pathArr ) {
                var path = pathArr[ i ];
                if ( path != '' && typeof  path == 'string' ) {
                    if ( this.requireLoadedScript[ path ] ) {
                        continue;
                    }
                    var content = this.getTemplateContent( path );
                    if ( content ) {
                        document.body.innerHTML += '<style>'+content+'</style>';
                    }
                    //event( content );
                    this.requireLoadedScript[ path ] = true;
                } else {
                    console.error( 'invalid style file path!' );
                }
            }
        };
        ptRouter.addComponent = function ( componentUrl ) {
            ptRouter.prototype.vueComponentsList.push( componentUrl );
        };
        /**
         * 加载全局组件
         */
        ptRouter.loadVueComponent = function () {
            for ( var i in ptRouter.prototype.vueComponentsList ) {
                var vueComponentUrl = ptRouter.prototype.vueComponentsList[ i ];
                var componentName   = ptRouter.getVueNameByTemplateFile( vueComponentUrl );
                if ( !ptRouter.prototype.loadedVueComponents[ componentName ] ) {
                    var component = ptRouter.requireComponent( vueComponentUrl );
                    if ( component ) {
                        ptRouter.$vue.component( componentName , component );
                        ptRouter.prototype.loadedVueComponents[ componentName ] = component;
                    } else {
                        console.warn( 'load vue component "' + vueComponentUrl + '" fail' )
                    }
                }
            }
        };
        /**
         * 通过组件模板文件，获取组件名
         * @param TemplateFile
         * @returns {string}
         */
        ptRouter.getVueNameByTemplateFile = function ( TemplateFile ) {
            var componentName = TemplateFile.substr( TemplateFile.lastIndexOf( '/' ) + 1 , TemplateFile.length - TemplateFile.lastIndexOf( '/' ) - 5 );
            return componentName;
        };
        /**
         * vue 插件安装方法
         * @param Vue
         */
        ptRouter.install = function ( Vue ) {
            ptRouter.$vue = Vue;
        };
        /**
         * 通过组件路径，并请求加载，返回组件构造函数
         */
        ptRouter.requireComponent = function ( vueComponentUrl , ptRouterInstance ) {
            var component     = null;
            var Vue           = ptRouter.$vue;
            var componentName = ptRouter.getVueNameByTemplateFile( vueComponentUrl );
            component         = ptRouter.prototype.vueComponentsList[ componentName ];
            if ( component ) {
                return component;
            }
            
            var componentContent = ptRouter.getTemplateContent( vueComponentUrl );
            var ptVue            = ptRouter.parseComponentVue( componentContent );
            if ( !ptVue )return null;
            try {
                if ( ptVue.style ) {
                    document.head.innerHTML += ptVue.style;
                }
                ptRouter.vueComponent    = null;
                ptRouter.useComponentUrl = [];
                if ( ptVue.script ) {
                    eval( ptVue.script );
                    ptRouter.loadScripts( ptRouter.requireScript );
                    ptRouter.requireScript = [];
                    ptRouter.loadStyle( ptRouter.requireStyle );
                    ptRouter.requireStyle = [];
                    var vueComponent      = ptRouter.vueComponent;
                    if ( typeof  vueComponent != 'object' ) {
                        console.error( 'pt_vue_component in not defined in ' + vueComponentUrl + ', please defined "pt_vue_component" in vue component file' );
                        return null;
                    }
                    
                    vueComponent.template = ptVue.template;
                    var useComponentUrl   = ptRouter.useComponentUrl;
                    if ( useComponentUrl && typeof useComponentUrl == 'object' && useComponentUrl.length > 0 ) {
                        vueComponent.components = {};
                        for ( var j in useComponentUrl ) {
                            var url              = useComponentUrl[ j ] , child_component_name = ptRouter.getVueNameByTemplateFile( url );
                            child_component_name = child_component_name.replace( /([A-Z])/g , "-$1" ).toLocaleLowerCase();
                            if ( child_component_name.indexOf( '-' ) === 0 ) {
                                child_component_name = child_component_name.substr( 1 );
                            }
                            if ( ptRouterInstance && typeof ptRouterInstance == 'object' && ptRouterInstance._opt ) {
                                url = ptRouterInstance._opt.vueComponentBasePath + url;
                            }
                            var childComponent                              = ptRouter.requireComponent( url , ptRouterInstance );
                            vueComponent.components[ child_component_name ] = childComponent;
                        }
                    }
                    
                    component                                             = Vue.extend( vueComponent );
                    ptRouter.prototype.vueComponentsList[ componentName ] = component;
                    return component;
                }
            } catch ( e ) {
                console.error( 'ptRouter load vue component error:' + e.message );
            }
            return null;
        };
        /**
         * 获取 vue 模板文件内容
         * @param vueComponentUrl
         * @returns {null}
         */
        ptRouter.getTemplateContent = function ( vueComponentUrl ) {
            if ( typeof vueComponentUrl == 'string' && vueComponentUrl != '' ) {
                var content = null;
                $.ajax( {
                    url      : vueComponentUrl , async: false , success: function ( res ) {
                        content = res;
                    } , error: function () {
                        console.error( 'get Vue template content error' );
                    }
                } );
                return content;
            }
            return null;
        };
        
        /**
         * 解析vue文件内容，成功返回 {style:'',script:'',template:''}
         * @param content
         * @returns {*}
         */
        ptRouter.parseComponentVue = function ( content ) {
            if ( typeof content == 'string' && content != '' ) {
                //console.log(content.replace(/(<template.*?>)([\s\n]*?)(<\/template>)/g,'$2'));
                
                var ptRouterLineR = 'ptRouterLineR';
                var ptRouterLineN = 'ptRouterLineN';
                content           = content.replace( /[\r]/g , ptRouterLineR );
                content           = content.replace( /[\n]/g , ptRouterLineN );
                
                var ptVue = {};
                
                ptVue.content = content;
                
                var style = content.match( /<style.*?>.*?<\/style>/gi );
                if ( style ) {
                    ptVue.style = style[ 0 ];
                    ptVue.style = ptVue.style.replace( /ptRouterLineR/g , "\r" );
                    ptVue.style = ptVue.style.replace( /ptRouterLineN/g , "\n" );
                }
                
                var script = /<script.*?>(.*?)<\/script>/g.exec( content );
                //console.log( script );
                if ( script ) {
                    ptVue.script = script[ 1 ];
                    ptVue.script = ptVue.script.replace( /ptRouterLineR/g , "\r" );
                    ptVue.script = ptVue.script.replace( /ptRouterLineN/g , "\n" );
                }
                var template = /<template.*?>(.*?)<\/template>/g.exec( content );
                
                if ( template ) {
                    ptVue.template = template[ 1 ];
                    ptVue.template = ptVue.template.replace( /ptRouterLineR/g , "\r" );
                    ptVue.template = ptVue.template.replace( /ptRouterLineN/g , "\n" );
                }
                return ptVue;
            } else {
                console.warn( 'the Vue Component template content is empty or invalid' );
            }
            return null;
        };
        /**
         * 通过模板文件，获取vue 实例
         * @param vueTemplateUrl
         * @param ptRouterInstance ptRouter实例
         * @returns {*}
         */
        ptRouter.getVueInstance = function ( vueTemplateUrl , ptRouterInstance ) {
            
            var ptVue = ptRouter.parseComponentVue( ptRouter.getTemplateContent( vueTemplateUrl ) );
            var Vue   = ptRouter.$vue;
            if ( ptVue && ptVue.script ) {
                ptRouter.vue             = null;
                ptRouter.useComponentUrl = [];
                var childComponentUrl    = [];
                eval( ptVue.script );
                var _vue     = ptRouter.vue;
                ptRouter.vue = null;
                ptRouter.loadScripts( ptRouter.requireScript );
                ptRouter.requireScript   = [];
                childComponentUrl        = ptRouter.useComponentUrl;
                ptRouter.useComponentUrl = [];
                if ( _vue instanceof Vue ) {
                    if ( ptVue.style ) {
                        document.head.innerHTML += ptVue.style;
                    }
                    _vue.$options.template = ptVue.template;
                    for ( var i in childComponentUrl ) {
                        var url = childComponentUrl[ i ];
                        if ( ptRouterInstance && typeof ptRouterInstance == 'object' && ptRouterInstance._opt ) {
                            url = ptRouterInstance._opt.vueComponentBasePath + url;
                        }
                        var name      = ptRouter.getVueNameByTemplateFile( url );
                        var component = ptRouter.requireComponent( url , ptRouterInstance );
                        if ( component ) {
                            _vue.$options.components[ name ] = component;
                        }
                    }
                }
                
                return _vue;
            }
            return null;
        };
        window.ptRouter = ptRouter;
        return ptRouter;
    } )
);
