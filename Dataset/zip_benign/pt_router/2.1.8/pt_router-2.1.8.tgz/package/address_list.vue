<template>
    <div>
        通讯录
    </div>
</template>
<style>

</style>
<script>
    Vue( {} );
</script>