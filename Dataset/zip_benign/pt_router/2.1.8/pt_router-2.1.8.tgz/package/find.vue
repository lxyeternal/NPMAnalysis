<template>
    <div>
        <div>
            <header-nav top-title="title"></header-nav>
        </div>
        <div>
            发现在页面
            <a href="/find?name=aa" pt-router>发现0</a>

            <a href="/find?dd=aadf" pt-router>发现1</a>
            <a v-on:click="goFind()" pt-router>事件调用</a>

        </div>
    </div>

</template>
<style>

</style>

<script>
    ptRouter.useComponentUrl=['/component/headerNav.vue'];
    ptRouter.vue=new ptRouter.$vue( {data:{title:''},methods:{goFind:function () {
        router.loadByName('find',{urlParams:{name:'这个群里',type:3}})
    },

    },
        ptRouterLoad:function ( RouterData ) {
            console.log( RouterData.params );
        }
    } );
</script>