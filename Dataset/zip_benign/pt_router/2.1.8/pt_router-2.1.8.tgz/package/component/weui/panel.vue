<template>
    <div class="weui-panel weui-panel_access">
        <div class="weui-panel__hd" >
            <div v-text="panel||'列表'" style="float: left;"></div>
            <div style="float: right;"><a href="#" class="movie-list-more-link">更多></a></div>
            <div style="clear: both"></div>
        </div>

        <div class="weui-panel__bd">
           <div style="width: 100%;">
                <div class="movie-item" v-for="info in list">
                    <span v-text="info.name"></span>
                </div>
           </div>
        </div>

    </div>
</template>
<style>
    .movie-item{
        /*display: table-cell;*/
        width: 33%;
        
        text-align: center;
        float:left;
    }
    .movie-list-more-link{
        color:#999;
    }
    .weui-panel__hd:after{
        border-bottom: none;
    }
    .weui-panel:before{
       
    }
</style>
<script>
    ptRouter.vueComponent = {props:{panel:'',list:[]}};


</script>