<template>
    <div class="weui-navbar top-nav-bar">
        <div class="weui-navbar top-nav-bar">
            <div class="top-nav-bar-item" style="text-align: left; width: 15%;">
                <a :href="backLink||'javascript:history.go(-1)'" v-text="backText||'返回'" pt-router ></a>
            </div>
            <div class="top-nav-bar-item" style="text-align: center; width: 70%;overflow:hidden;white-space: nowrap; text-overflow: ellipsis;">
                <span v-text="title"></span>
            </div>
            <div class="top-nav-bar-item" style="text-align:right; width: 15% ;">
                <a href="#/mycenter" pt-router>我的</a>
            </div>
        </div>
    </div>
</template>
<style>
    .top-nav-bar{
        border: none;
        background-color: #0abcbc;
        position: fixed;
        top:0;
        left: 0;
    }
    .top-nav-bar-item{
        padding: 5px;
        display: table-cell
    }
    .top-nav-bar-item a{
        color: #ffffff;
    }
</style>
<script>
    ptRouter.vueComponent = {
        data:function () {
            return {}
        },
        props:{'title':'','backLink':null,'backText':'返回'}};
</script>