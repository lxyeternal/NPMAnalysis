import { HTMLAttributes } from "@builder.io/qwik";
import { MotionKeyframesDefinition, AnimationOptionsWithOverrides } from "motion";
export interface AnimatedMotionProps extends HTMLAttributes<HTMLElement> {
    animate: MotionKeyframesDefinition;
    options?: AnimationOptionsWithOverrides;
    element: keyof HTMLElementTagNameMap;
}
export declare const AnimatedMotion: import("@builder.io/qwik").Component<AnimatedMotionProps>;
interface component {
    element: typeof HTMLElement;
}
export declare const component: import("@builder.io/qwik").Component<component>;
export {};
