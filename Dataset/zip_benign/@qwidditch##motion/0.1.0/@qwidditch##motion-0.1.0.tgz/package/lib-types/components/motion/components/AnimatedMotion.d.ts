import { HTMLAttributes } from "@builder.io/qwik";
import { MotionKeyframesDefinition, AnimationOptionsWithOverrides } from "motion";
export interface AnimatedMotionProps extends HTMLAttributes<HTMLElement> {
    animate: MotionKeyframesDefinition;
    options?: AnimationOptionsWithOverrides;
    element: keyof HTMLElementTagNameMap | "svg";
}
export declare const AnimatedMotion: import("@builder.io/qwik").Component<AnimatedMotionProps>;
