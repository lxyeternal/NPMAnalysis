export interface GetElementProps {
    element: keyof HTMLElementTagNameMap | "svg";
    ref: any;
    props: any;
}
export declare const GetElement: import("@builder.io/qwik").Component<GetElementProps>;
