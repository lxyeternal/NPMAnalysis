export declare const MotionDiv: import("@builder.io/qwik").Component<{}>;
