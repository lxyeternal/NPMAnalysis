<style>
    .{nbbId}-settings .checkbox>label.section-title {
        font-size: 24px;
    }
    .{nbbId}-settings .checkbox>label>input[data-toggle-target] {
        margin-bottom: 0;
    }
    .nav-tabs {
        margin-bottom: 2rem;
    }
</style>
<div class="row">
    <div class="col-sm-9">
        <ul class="nav nav-tabs" role="tablist">
            <li role="presentation" class="active"><a href="#svgcaptcha" aria-controls="akismet" role="tab" data-toggle="tab">SVG captcha</a></li>

        </ul>

        <form role="form" class="{nbbId}-settings">
            <fieldset>
                <div class="tab-content">
                <div role="tabpanel" class="tab-pane active" id="svgcaptcha">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="checkbox">
                            <label class="section-title">
                            <input type="radio" id="svgcaptchaEnabled" name="svgcaptchaEnabled" value="svg"/>
                            Enable SVG captcha
                            </label>
                            </div>


                        </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-12">
                        <div class="checkbox">
                        <label class="section-title">
                        <input type="radio" id="mathcaptchaEnabled" name="svgcaptchaEnabled" value="math"/>
                        Enable Math captcha
                        </label>
                        </div>


                    </div>
                </div>
                </div>

                </div>
            </fieldset>
            
        </form>
    </div>

</div>

<button id="save" class="floating-button mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored">
    <i class="material-icons">save</i>
</button>