import * as game from './game'

Component({
  mixins: [],
  data: {
    curPos: {
      x: 0,
      y: 0,
    },
    endPos: {
      x: 0,
      y: 710
    },
  },
  props: {},
  ...game
});