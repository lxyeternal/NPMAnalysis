var FEM = require("femjs"); 

const model = new FEM();  
model.open('./model.json');

model.assembly();

model.loadcase( 1 );

model.solve();
model.show();
model.saveModel();