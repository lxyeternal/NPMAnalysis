<div align="center">

<h2></h2>

  <img src="assets/Logo.svg" width="400">

<h2><code>Squavy Panels</code></h2>

<strong>A super minimalistic modular panel implementation in SolidJS for Squavy.</strong>

  <p>Because reinventing the wheel seems to be the only option.</p>
</div>

# Usage

Simple, declarative api for creating large scale layouts.

```tsx
import { SquanelLayout, SquanelSplit } from './index';
import ExampleComponent from './ExampleComponent';

<SquanelLayout>
    <SquanelSplit orientation="horizontal" split={0.4}>
        <SquanelContent>
            {() => <div>Inline panel</div>}
        </SquanelContent>
        <SquanelContent minWidth={50} maxWidth={150}>
            {ExampleComponent}
        </SquanelContent>
    </SquanelSplit>
</SquanelLayout>
```

![Demo1.png](assets/Demo1.png)
