/**
 * cesium 功能类的基类，提供公共的接口
 *
 * @export
 * @class FeatureBase
 */
export default class FeatureBase {
    viewer;
    constructor(viewer) {
        this.viewer = viewer;
    }
    /**
     * 设置指针样式
     *
     * @protected
     * @param {CursorStyle} cursorStyle
     * @memberof FeatureBase
     */
    setCursorStyle(cursorStyle) {
        this.viewer.container.setAttribute("style", `cursor:${cursorStyle}`);
    }
}
//# sourceMappingURL=FeatureBase.js.map