import { Viewer } from "cesium";
import FeatureBase from "../FeatureBase";
export default class VertexTool extends FeatureBase {
    constructor(viewer: Viewer);
    start(): void;
    stop(): void;
}
