import { CallbackProperty, Color, HeightReference, JulianDate, PolylineGlowMaterialProperty, PolylineGraphics, ScreenSpaceEventType } from "cesium";
import { FeatureBase } from "..";
export default class Editor extends FeatureBase {
    currentMode;
    handler;
    /**
    * 标记样式
    *
    * @type {EditorStyle}
    * @memberof Marker
    */
    style;
    constructor(viewer, style) {
        super(viewer);
        this.handler = viewer.screenSpaceEventHandler;
        this.style = style || {
            point_Color: "#ffffff",
            point_PixelSize: 5,
            line_Width: 5,
            line_MaterialColor: "#ff0000",
            polygon_Outline: true,
            polygon_OutlineWidth: 1,
            polygon_OutlineColor: "#90EE90",
            polygon_MaterialColor: "#ff0000",
            polygon_MaterialColor_Alpha: 0.2,
        };
    }
    start(mode) {
        this.setCursorStyle('CrossHair');
        this.currentMode = mode;
        this.onStart(mode);
    }
    stop() {
        //设置默认光标
        this.setCursorStyle('Default');
        //关闭深度监测
        this.viewer.scene.globe.depthTestAgainstTerrain = false;
        const handler = this.handler;
        //删除所有输入事件
        handler.removeInputAction(ScreenSpaceEventType.LEFT_CLICK);
        handler.removeInputAction(ScreenSpaceEventType.MOUSE_MOVE);
        handler.removeInputAction(ScreenSpaceEventType.RIGHT_CLICK);
        handler.removeInputAction(ScreenSpaceEventType.LEFT_DOUBLE_CLICK);
        this.onStop();
    }
    /**
    * 绘制形状
    *
    * @private
    * @param {ShapeType} shapetype 形状类型
    * @param {*} position 形状点位
    * @return {*}  {Entity}
    * @memberof Mark
    */
    drawShape(shapetype, position) {
        switch (shapetype) {
            case 'Point':
                return this.viewer.entities.add({
                    position: position,
                    point: {
                        color: Color.fromCssColorString(this.style.point_Color),
                        pixelSize: this.style.point_PixelSize,
                        heightReference: HeightReference.CLAMP_TO_GROUND
                    }
                });
            case 'Line':
                return this.viewer.entities.add({
                    polyline: {
                        positions: position,
                        clampToGround: true,
                        width: this.style.line_Width,
                        material: new PolylineGlowMaterialProperty({
                            color: Color.fromCssColorString(this.style.line_MaterialColor)
                        })
                    }
                });
            case 'Polygon':
                var entity = this.viewer.entities.add({
                    polygon: {
                        hierarchy: position,
                        material: Color.fromCssColorString(this.style.polygon_MaterialColor)
                            .withAlpha(this.style.polygon_MaterialColor_Alpha)
                    }
                });
                //获取polygon的轮廓闭合点
                let getRings = () => {
                    let polylinePositaions = new Array().concat(entity.polygon?.hierarchy?.getValue(JulianDate.now()).positions);
                    polylinePositaions.push(polylinePositaions[0]);
                    return polylinePositaions;
                };
                if (this.style.polygon_Outline) {
                    //添加外轮廓
                    entity.polyline = new PolylineGraphics({
                        positions: position instanceof CallbackProperty ? new CallbackProperty(getRings, false) : getRings(),
                        width: this.style.polygon_OutlineWidth,
                        material: Color.fromCssColorString(this.style.polygon_OutlineColor),
                        clampToGround: true
                    });
                }
                return entity;
        }
    }
}
//# sourceMappingURL=Editor.js.map