import { Viewer } from "cesium";
import { Editor, MeasureMode } from "..";
/**
 * 测量功能
 */
export default class Measurer extends Editor<MeasureMode> {
    private marker;
    private areaLable;
    private linePoints;
    constructor(viewer: Viewer);
    protected onStart(): void;
    protected onStop(): void;
    private handleMakerPushPoint;
    private handleMakerPopPoint;
    private handleActivityShapeChange;
    /**
    * 测量线标记
    *
    * @private
    * @param {Array<Entity>} markPoints
    * @memberof Mark
    */
    private addLineMeasure;
}
