import { Cartesian3, Entity, Viewer } from "cesium";
import { EditorStyle, ShapeType } from "..";
import Editor from "./Editor";
export default class Marker extends Editor<ShapeType> {
    private onEntitySave?;
    onActivityShapeChange?: (mode: ShapeType, points: Array<Cartesian3>) => void;
    onPushPoint?: (point: Cartesian3) => void;
    onPopPoint?: (point: Cartesian3) => void;
    constructor(viewer: Viewer, onEntitySave?: (entity: Entity) => void, style?: EditorStyle | undefined);
    protected onStart(): void;
    protected onStop(): void;
}
