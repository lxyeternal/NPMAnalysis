import { Entity, ScreenSpaceEventHandler, Viewer } from "cesium";
import { FeatureBase, EditorStyle, ShapeType } from "..";
import { MeasureMode } from "../DataType";
export default abstract class Editor<T extends ShapeType | MeasureMode> extends FeatureBase {
    protected currentMode: T | undefined;
    protected readonly handler: ScreenSpaceEventHandler;
    /**
    * 标记样式
    *
    * @type {EditorStyle}
    * @memberof Marker
    */
    readonly style: EditorStyle;
    constructor(viewer: Viewer, style: EditorStyle | undefined);
    protected abstract onStart(mode: T): void;
    protected abstract onStop(): void;
    start(mode: T): void;
    stop(): void;
    /**
    * 绘制形状
    *
    * @private
    * @param {ShapeType} shapetype 形状类型
    * @param {*} position 形状点位
    * @return {*}  {Entity}
    * @memberof Mark
    */
    protected drawShape(shapetype: ShapeType, position: any): Entity;
}
