import { Cartesian2, Viewer } from "cesium";
import { FeatureBase } from "..";
export default class Popup extends FeatureBase {
    private readonly define_html;
    /**
     * 当前popup位置 地理坐标
     *
     * @private
     * @type {(Cartesian3 | undefined)}
     * @memberof Popup
     */
    private position;
    /**
     * 是否使用模板
     *
     * @private
     * @type {boolean}
     * @memberof Popup
     */
    private useTemplate;
    /**
     * Creates an instance of Popup.
     * @param {Viewer} viewer
     * @param {boolean} [useTemplate=false] 是否使用模板 默认true
     * @memberof Popup
     */
    constructor(viewer: Viewer, useTemplate?: boolean);
    /**
     * popup展示信息
     *
     * @param {Cartesian2} position 屏幕位置
     * @param {HTMLElement} htmlElement popup渲染的html元素 如果 {@link useTemplate} 设置为true则html作为content渲染，如果为false则直接渲染
     * @memberof Popup
     */
    show(position: Cartesian2, htmlElement: HTMLElement): void;
    /**
     * 关闭当前popup
     *
     * @memberof Popup
     */
    close(): void;
    /**
     * 添加默认模板dom
     *
     * @private
     * @memberof Popup
     */
    private addTemplateDom;
    /**
     * 添加scene更新渲染事件 计算当前地理坐标下的屏幕坐标并更新popup位置
     *
     * @private
     * @memberof Popup
     */
    private addMapListener;
    /**
     * 更新popup位置
     *
     * @private
     * @param {Cartesian2} position
     * @memberof Popup
     */
    private setPopupPosition;
    /**
     * 通过类名获取html第一个元素
     *
     * @private
     * @param {string} className 类名
     * @return {*}
     * @memberof Popup
     */
    private tryGetElementByClass;
}
