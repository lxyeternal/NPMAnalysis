import { Viewer } from "cesium";
import { FeatureBase } from "..";
/**
 * 天气
 *
 * @export
 * @class Weather
 * @extends {FeatureBase}
 */
export default class Weather extends FeatureBase {
    private currentState;
    constructor(viewer: Viewer);
    /**
     * 根据类型添加天气场景
     *
     * @param {WeatherType} type
     * @return {*}  {void}
     * @memberof Weather
     */
    add(type: any): void;
    clear(): void;
}
