import { Cartesian2, Entity, Viewer } from "cesium";
import { FeatureBase } from "..";
/**
 * 实体选择
 *
 * @export
 * @class EntityPicker
 * @extends {FeatureBase}
 */
export default class EntityPicker extends FeatureBase {
    constructor(viewer: Viewer);
    /**
     * 启动选择
     *
     * @param {(entity:Entity,position:Cartesian2) => void} callback entity ：选择获取到的实体  position ：指针单击屏幕坐标
     * @memberof EntityPicker
     */
    start(callback: (entity: Entity, position: Cartesian2) => void): void;
    /**
     * 停止选择
     *
     * @memberof EntityPicker
     */
    stop(): void;
}
