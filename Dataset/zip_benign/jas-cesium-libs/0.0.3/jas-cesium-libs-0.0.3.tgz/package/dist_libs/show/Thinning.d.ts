import { Entity, Viewer } from "cesium";
import { FeatureBase } from "..";
/**
 * 抽稀
 *
 * @export
 * @class Thinning
 * @extends {FeatureBase}
 */
export default class Thinning extends FeatureBase {
    /**
     * 获取点函数
     *
     * @private
     * @memberof Thinning
     */
    private pointsFunc;
    /**
     * x方向 (东方向) 抽稀系数
     *
     * @private
     * @type {number}
     * @memberof Thinning
     */
    private x;
    /**
     * y方向 (西方向) 抽稀系数
     *
     * @private
     * @type {number}
     * @memberof Thinning
     */
    private y;
    constructor(viewer: Viewer);
    /**
     * 设置抽稀点获取函数
     *
     * @param {(viewer: Viewer) => Array<Entity>} pointsFunc
     * @return {*}
     * @memberof Thinning
     */
    setPointsFunc(pointsFunc: (viewer: Viewer) => Array<Entity>): Thinning;
    /**
     * 设置xy抽稀系数
     *
     * @param {number} x
     * @param {number} y
     * @return {*}
     * @memberof Thinning
     */
    setLimitXY(x: number, y: number): Thinning;
    /**
     * 运行抽稀
     *
     * @memberof Thinning
     */
    start(): void;
    /**
     * 停止抽稀
     *
     * @memberof Thinning
     */
    clear(): void;
    private calThinning;
    /**
     * 计算地理分辨率 当前相机层级1px代表的地理长度
     *
     * @private
     * @return {*}
     * @memberof Thinning
     */
    private calGeoRES;
    /**
     * 计算当前点范围
     *
     * @private
     * @param {Array<Entity>} points
     * @return {*}
     * @memberof Thinning
     */
    private calExtent;
}
