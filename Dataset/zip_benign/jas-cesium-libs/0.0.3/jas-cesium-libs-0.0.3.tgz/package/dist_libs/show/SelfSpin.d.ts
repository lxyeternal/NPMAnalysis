import { Viewer } from "cesium";
import FeatureBase from "../FeatureBase";
export default class SelfSpin extends FeatureBase {
    /**
     * 自转执行方法(内部使用)
     *
     * @private
     * @memberof SelfSpin
     */
    private rotateAction;
    constructor(viewer: Viewer);
    /**
     * 地球自转
     *
     * @param {number} rotateSpeed
     * @memberof CesiumDataStore
     */
    start(rotateSpeed?: number): void;
    /**
     * 移除地球自转
     *
     * @memberof CesiumDataStore
     */
    stop(): void;
    clear(): void;
}
