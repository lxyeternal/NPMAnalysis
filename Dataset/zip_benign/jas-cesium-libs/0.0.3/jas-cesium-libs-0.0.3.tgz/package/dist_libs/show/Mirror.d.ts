import { Viewer } from "cesium";
/**
 * 镜像功能，可以实现双屏模式
 *
 * @export
 * @class Mirror
 */
export default class Mirror {
    readonly master: Viewer;
    readonly slave: Viewer;
    /**
     * Creates an instance of Mirror.
     * @param {string} master 左侧参考viewer  标记主体
     * @param {string} slave 右侧参考viewer  跟随标记
     * @memberof Mirror
     */
    constructor(master: string | Viewer, slave: string | Viewer);
    /**
     * 获取左右两个viewer
     *
     * @return {*}  {{ master: Viewer, slave: Viewer }}
     * @memberof Mirror
     */
    getViewers(): {
        master: Viewer;
        slave: Viewer;
    };
    /**
     * 销毁
     *
     * @memberof Mirror
     */
    destroy(): void;
    /**
     * 初始化镜像功能
     *
     * @private
     * @memberof Mirror
     */
    private init;
    /**
     * 创建镜像Handler 实现camera同步
     *
     * @private
     * @param {Camera} masterCamera 主体相机
     * @param {Camera} slaveCamera 跟随相机
     * @return {*}
     * @memberof Mirror
     */
    private createMirrorHandler;
}
