import { Cartesian3, EntityCollection, LabelGraphics, Viewer } from "cesium";
import { SpaceType } from ".";
/**
 * 创建 viewer
 *
 * @export
 * @param {string} containerName div容器 id
 * @return {*}  {Viewer}
 */
export declare function createViewer(containerName: string): Viewer;
/**
 * 设置镜头最大俯仰角，镜头朝下=-Π  镜头平视=0
 *
 * @export
 * @param {Viewer} viewer
 * @param {number} maxPitch 一般使用负数，-pi ~ 0
 */
export declare function setMaxPitch(viewer: Viewer, maxPitch: number): void;
/**
 * 通过entity的名字删除entity
 *
 * @param {Viewer} viewer
 * @param {string} name
 */
export declare function removeEntityByName(entities: EntityCollection, name: string): void;
/**
* 创建cesium lable对象 ，统一样式
*
* @private
* @param {string} text lable显示文字
* @return {*}
* @memberof Mark
*/
export declare function createLabel(text: string): LabelGraphics;
/**
 * 屏幕点转化为投影坐标
 *
 * @export
 * @param {Viewer} viewer
 * @param {*} point
 * @return {*}  {(Cartesian3 | undefined)}
 */
export declare function window2Proj(viewer: Viewer, point: any): Cartesian3 | undefined;
/**
 * 计算面积 todo : 修改points类型
 *
 * @protected
 * @param {Cartesian3[]} points 多边形点
 * @return {number}  面积
 * @memberof FeatureBase
 */
export declare function calArea(points: Cartesian3[]): number;
/**
 * 计算线段长度 (根据空间类型)
 *
 * @export
 * @param {[Cartesian3, Cartesian3]} segmentPoints
 * @param {SpaceType} [spaceType='D3']
 * @return {*}  {number}
 */
export declare function calLength(segmentPoints: [Cartesian3, Cartesian3], spaceType?: SpaceType): number;
/**
 * 数组添加方法监听
 *
 * @private
 * @template T any
 * @param {Array<T>} array 数组
 * @param {arrayMethodName} methodName 方法类型
 * @param {(value: T) => void} callback
 * @memberof Mark
 */
export declare function addArrayListener<T>(array: Array<T>, methodName: keyof T[], callback: (array: Array<T>, args: IArguments) => void): void;
