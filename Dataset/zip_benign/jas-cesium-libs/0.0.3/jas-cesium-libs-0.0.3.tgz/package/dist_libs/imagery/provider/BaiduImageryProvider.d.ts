import { WebMercatorTilingScheme, Rectangle } from 'cesium';
import { CustomProviderStyle, CrsType } from '../ProviderStyle';
declare type BaiduImageryProviderConstructorOptions = {
    style: CustomProviderStyle;
    crs?: CrsType;
    labelStyle?: string;
};
declare class BaiduImageryProvider {
    _url: string;
    _labelStyle: string;
    _tileWidth: number;
    _tileHeight: number;
    _maximumLevel: number;
    _crs: string;
    _tilingScheme: WebMercatorTilingScheme;
    _rectangle: Rectangle;
    _credit: any;
    _token?: string;
    _style: string;
    constructor(options: BaiduImageryProviderConstructorOptions);
    get url(): string;
    get token(): string | undefined;
    get tileWidth(): number;
    get tileHeight(): number;
    get maximumLevel(): number;
    get minimumLevel(): number;
    get tilingScheme(): WebMercatorTilingScheme;
    get rectangle(): Rectangle;
    get ready(): boolean;
    get credit(): any;
    get hasAlphaChannel(): boolean;
    getTileCredits(x: number, y: number, level: number): void;
    /**
     * Request Image
     * @param x
     * @param y
     * @param level
     * @returns {Promise<HTMLImageElement | HTMLCanvasElement>}
     */
    requestImage(x: number, y: number, level: number): Promise<HTMLImageElement | HTMLCanvasElement> | undefined;
}
export default BaiduImageryProvider;
