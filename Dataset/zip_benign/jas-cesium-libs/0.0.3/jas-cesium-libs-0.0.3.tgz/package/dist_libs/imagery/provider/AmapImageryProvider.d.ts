import { UrlTemplateImageryProvider } from 'cesium';
import { CustomProviderStyle, CrsType } from '../ProviderStyle';
declare type AmapImageryProviderConstructorOptions = {
    style: CustomProviderStyle;
    crs?: CrsType;
};
declare class AmapImageryProvider extends UrlTemplateImageryProvider {
    constructor(options: AmapImageryProviderConstructorOptions);
}
export default AmapImageryProvider;
