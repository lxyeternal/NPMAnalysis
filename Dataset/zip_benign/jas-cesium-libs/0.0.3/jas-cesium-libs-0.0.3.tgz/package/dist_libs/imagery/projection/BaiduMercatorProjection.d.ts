declare type LngLatPoint = {
    lng: number;
    lat: number;
};
declare class BaiduMercatorProjection {
    isWgs84: boolean;
    constructor();
    /**
     *
     * @param point1
     * @param point2
     * @returns {number}
     */
    getDistanceByMC(point1: LngLatPoint, point2: LngLatPoint): number;
    /**
     * Calculate the distance between two points according to the latitude and longitude coordinates
     * @param point1
     * @param point2
     * @returns {number|*}
     */
    getDistanceByLL(point1: LngLatPoint, point2: LngLatPoint): number;
    /**
     * The plane cartesian coordinates are converted to latitude and longitude coordinates
     * @param point
     * @returns {Point|{lng: number, lat: number}}
     */
    convertMC2LL(point: LngLatPoint): {
        lng: number;
        lat: number;
    };
    /**
     * The latitude and longitude coordinates are converted to plane cartesian coordinates
     * @param point
     * @returns {{lng: number, lat: number}|*}
     */
    convertLL2MC(point: LngLatPoint): LngLatPoint;
    /**
     *
     * @param fromPoint
     * @param factor
     * @returns {{lng: *, lat: *}}
     */
    convertor(fromPoint: LngLatPoint, factor: number[]): {
        lng: number;
        lat: number;
    };
    /**
     *
     * @param x1
     * @param x2
     * @param y1
     * @param y2
     * @returns {number}
     */
    getDistance(x1: number, x2: number, y1: number, y2: number): number;
    /**
     *
     * @param deg
     * @returns {number}
     */
    toRadians(deg: number): number;
    /**
     *
     * @param rad
     * @returns {number}
     */
    toDegrees(rad: number): number;
    /**
     *
     * @param v
     * @param a
     * @param b
     * @returns {number}
     */
    getRange(v: number, a: number, b: number): number;
    /**
     *
     * @param v
     * @param a
     * @param b
     * @returns {*}
     */
    getLoop(v: number, a: number, b: number): number;
    /**
     *
     * @param point
     * @returns {{lng: number, lat: number}|*}
     */
    lngLatToMercator(point: LngLatPoint): LngLatPoint;
    /**
     *
     * @param point
     * @returns {{x: (number|*), y: (number|*)}}
     */
    lngLatToPoint(point: LngLatPoint): {
        x: number;
        y: number;
    };
    /**
     * WebMercator transforms to latitude and longitude
     * @param point
     * @returns {Point|{lng: number, lat: number}}
     */
    mercatorToLngLat(point: LngLatPoint): {
        lng: number;
        lat: number;
    };
    /**
     *
     * @param point
     * @returns {Point|{lng: number, lat: number}}
     */
    pointToLngLat(point: LngLatPoint): {
        lng: number;
        lat: number;
    };
    /**
     * Latitude and longitude coordinates  transforms to  pixel coordinates
     * @param point
     * @param zoom
     * @param mapCenter
     * @param mapSize
     * @returns {{x: number, y: number}}
     */
    pointToPixel(point: LngLatPoint, zoom: number, mapCenter: LngLatPoint, mapSize: {
        width: number;
        height: number;
    }): {
        x: number;
        y: number;
    };
    /**
     * Pixel coordinates transforms to latitude and longitude coordinates
     * @param pixel
     * @param zoom
     * @param mapCenter
     * @param mapSize
     * @returns {Point|{lng: number, lat: number}}
     */
    pixelToPoint(pixel: {
        x: number;
        y: number;
    }, zoom: number, mapCenter: LngLatPoint, mapSize: {
        width: number;
        height: number;
    }): {
        lng: number;
        lat: number;
    };
    /**
     *
     * @param zoom
     * @returns {number}
     */
    getZoomUnits(zoom: number): number;
}
export default BaiduMercatorProjection;
