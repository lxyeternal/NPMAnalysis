import { WebMercatorTilingScheme, Cartographic, Cartesian2, Ellipsoid } from 'cesium';
declare class BaiduMercatorTilingScheme extends WebMercatorTilingScheme {
    resolutions: number[];
    constructor(options?: {
        ellipsoid?: Ellipsoid;
        numberOfLevelZeroTilesX?: number;
        numberOfLevelZeroTilesY?: number;
        rectangleSouthwestInMeters?: Cartesian2;
        rectangleNortheastInMeters?: Cartesian2;
        resolutions: number[];
    });
    /**
     *
     * @param x
     * @param y
     * @param level
     * @param result
     * @returns {module:cesium.Rectangle|*}
     */
    tileXYToNativeRectangle(x: number, y: number, level: number, result?: any): any;
    /**
     *
     * @param position
     * @param level
     * @param result
     * @returns {undefined|*}
     */
    positionToTileXY(position: Cartographic, level: number, result?: Cartesian2): Cartesian2;
}
export default BaiduMercatorTilingScheme;
