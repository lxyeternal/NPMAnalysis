import { UrlTemplateImageryProvider } from 'cesium';
import AmapMercatorTilingScheme from '../tiling-scheme/AmapMercatorTilingScheme';
import { AMAP_IMG_URL, AMAP_ELEC_URL } from '../ProviderStyle';
class AmapImageryProvider extends UrlTemplateImageryProvider {
    constructor(options) {
        let base = { url: "" };
        base.url = options.style === 'img' ? AMAP_IMG_URL : AMAP_ELEC_URL;
        base.subdomains = base.subdomains || ['01', '02', '03', '04'];
        if (options.crs !== 'SELF') {
            base.tilingScheme = new AmapMercatorTilingScheme();
        }
        super(base);
    }
}
export default AmapImageryProvider;
//# sourceMappingURL=AmapImageryProvider.js.map