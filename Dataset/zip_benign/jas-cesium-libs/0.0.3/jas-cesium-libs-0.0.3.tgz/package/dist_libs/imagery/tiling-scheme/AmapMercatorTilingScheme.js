import { Math as CesiumMath, WebMercatorTilingScheme, WebMercatorProjection, Cartographic, Cartesian3 } from 'cesium';
import CoordTransform from '../CoordTransform';
class AmapMercatorTilingScheme extends WebMercatorTilingScheme {
    constructor(options) {
        super(options);
        let projection = new WebMercatorProjection();
        this.projection.project = function (cartographic, result) {
            let ret = CoordTransform.WGS84ToGCJ02(CesiumMath.toDegrees(cartographic.longitude), CesiumMath.toDegrees(cartographic.latitude));
            result = projection.project(new Cartographic(CesiumMath.toRadians(ret[0]), CesiumMath.toRadians(ret[1])));
            return new Cartesian3(result.x, result.y);
        };
        this.projection.unproject = function (cartesian, result) {
            let cartographic = projection.unproject(cartesian);
            let ret = CoordTransform.GCJ02ToWGS84(CesiumMath.toDegrees(cartographic.longitude), CesiumMath.toDegrees(cartographic.latitude));
            return new Cartographic(CesiumMath.toRadians(ret[0]), CesiumMath.toRadians(ret[1]));
        };
    }
}
export default AmapMercatorTilingScheme;
//# sourceMappingURL=AmapMercatorTilingScheme.js.map