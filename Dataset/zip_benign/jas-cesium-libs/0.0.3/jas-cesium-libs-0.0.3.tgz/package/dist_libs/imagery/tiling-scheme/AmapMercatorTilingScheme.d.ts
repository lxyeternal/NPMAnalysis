import { WebMercatorTilingScheme, Cartesian2, Ellipsoid } from 'cesium';
declare class AmapMercatorTilingScheme extends WebMercatorTilingScheme {
    constructor(options?: {
        ellipsoid?: Ellipsoid;
        numberOfLevelZeroTilesX?: number;
        numberOfLevelZeroTilesY?: number;
        rectangleSouthwestInMeters?: Cartesian2;
        rectangleNortheastInMeters?: Cartesian2;
    });
}
export default AmapMercatorTilingScheme;
