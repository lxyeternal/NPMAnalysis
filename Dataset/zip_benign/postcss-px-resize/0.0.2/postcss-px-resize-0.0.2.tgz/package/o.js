var test = '-webkit-box-shadow: 0 2px 2px rgba(0, 0, 0, 0.12);';

var pxRegExp = /\b(\d+(\.\d+)?)px\b/;
var pxGlobalRegExp = new RegExp(pxRegExp.source, 'g');

var newStr = test.replace(pxGlobalRegExp, function(match, p1, p2) {
    console.log(match, p1, p2)
	return p1/2+'px'
})

console.log(newStr)