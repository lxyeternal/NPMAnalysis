'use strict';

var assert = require('assert');
var path = require('path');
var fs = require('fs');
var postcss = require('postcss');
var autoprefixer = require('autoprefixer');

var srcPath = path.join(__dirname, 'test/source-px-resize.css');
var srcText = fs.readFileSync(srcPath, {encoding: 'utf8'});
var outputText = postcss()
    .use(function(css) {
        var pxRegExp = /\b(\d+(\.\d+)?)px\b/;
        var pxGlobalRegExp = new RegExp(pxRegExp.source, 'g');

        css.walkDecls(function(decl) {
            if (/px/.test(decl.value)) {
                decl.value = decl.value.replace(pxGlobalRegExp, function(match, p1) {
                    return p1/2 + 'px'
                })
            }
        })
    })
    .process(srcText).css;

console.log(outputText)