export declare const date: <K extends string>(key: K) => {
    (): {
        key: K;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: Date | undefined;
        };
    };
    <R extends Date>(): {
        key: K;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: R | undefined;
        };
    };
    (fallback: Date): {
        key: K;
        fallback: Date;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: Date;
        };
    };
    <R_1 extends Date>(fallback: R_1): {
        key: K;
        fallback: R_1;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: R_1;
        };
    };
};
//# sourceMappingURL=date.d.ts.map