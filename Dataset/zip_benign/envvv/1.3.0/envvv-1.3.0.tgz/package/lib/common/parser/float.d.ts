import type { Parser } from '../types';
export declare const asFloat: Parser<number>;
//# sourceMappingURL=float.d.ts.map