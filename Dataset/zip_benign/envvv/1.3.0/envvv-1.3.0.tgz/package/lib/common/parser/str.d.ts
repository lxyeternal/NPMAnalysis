import type { Parser } from '../types';
export declare const asStr: Parser<string>;
//# sourceMappingURL=str.d.ts.map