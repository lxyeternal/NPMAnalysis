import type { Parser } from '../types';
export declare const asJson: Parser<any>;
//# sourceMappingURL=json.d.ts.map