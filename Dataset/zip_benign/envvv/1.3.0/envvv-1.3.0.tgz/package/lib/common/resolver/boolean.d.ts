export declare const bool: <K extends string>(key: K) => {
    (): {
        key: K;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: boolean | undefined;
        };
    };
    <R extends boolean>(): {
        key: K;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: R | undefined;
        };
    };
    (fallback: boolean): {
        key: K;
        fallback: boolean;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: boolean;
        };
    };
    <R_1 extends boolean>(fallback: R_1): {
        key: K;
        fallback: R_1;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: R_1;
        };
    };
};
//# sourceMappingURL=boolean.d.ts.map