import type { Dict, Parser } from './types';
export declare const resolve: <T>(parser: Parser<T>) => <K extends string>(key: K) => {
    (): {
        key: K;
        fn: (obj: Dict) => {
            key: K;
            value: T | undefined;
        };
    };
    <R extends T>(): {
        key: K;
        fn: (obj: Dict) => {
            key: K;
            value: R | undefined;
        };
    };
    (fallback: T): {
        key: K;
        fallback: T;
        fn: (obj: Dict) => {
            key: K;
            value: T;
        };
    };
    <R_1 extends T>(fallback: R_1): {
        key: K;
        fallback: R_1;
        fn: (obj: Dict) => {
            key: K;
            value: R_1;
        };
    };
};
//# sourceMappingURL=resolve.d.ts.map