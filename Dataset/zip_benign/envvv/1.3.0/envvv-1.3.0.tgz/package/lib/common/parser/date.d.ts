import type { Parser } from '../types';
export declare const asDate: Parser<Date>;
//# sourceMappingURL=date.d.ts.map