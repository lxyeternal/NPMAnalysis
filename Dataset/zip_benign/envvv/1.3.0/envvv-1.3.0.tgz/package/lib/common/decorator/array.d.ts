import type { Dict, Resolver } from '../types';
export declare const arrayBy: (delimiter?: RegExp | string) => <K extends string, V>(resolver: Resolver<K, V>) => {
    key: K;
    fn: (obj: Dict) => {
        key: K;
        value: V[];
    };
};
export declare const array: <K extends string, V>(resolver: Resolver<K, V>) => {
    key: K;
    fn: (obj: Dict) => {
        key: K;
        value: V[];
    };
};
export declare const line: <K extends string, V>(resolver: Resolver<K, V>) => {
    key: K;
    fn: (obj: Dict) => {
        key: K;
        value: V[];
    };
};
//# sourceMappingURL=array.d.ts.map