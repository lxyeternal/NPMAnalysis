import type { Parser } from '../types';
export declare const asBool: Parser<boolean>;
//# sourceMappingURL=bool.d.ts.map