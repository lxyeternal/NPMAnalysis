import type { Dict, Resolver } from '../types';
export declare const required: <K extends string, V>(resolver: Resolver<K, V | undefined>) => {
    key: K;
    fn: (obj: Dict) => {
        key: K;
        value: V;
    };
};
//# sourceMappingURL=required.d.ts.map