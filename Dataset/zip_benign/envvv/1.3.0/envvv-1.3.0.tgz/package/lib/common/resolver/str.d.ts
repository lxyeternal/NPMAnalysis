export declare const str: <K extends string>(key: K) => {
    (): {
        key: K;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: string | undefined;
        };
    };
    <R extends string>(): {
        key: K;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: R | undefined;
        };
    };
    (fallback: string): {
        key: K;
        fallback: string;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: string;
        };
    };
    <R_1 extends string>(fallback: R_1): {
        key: K;
        fallback: R_1;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: R_1;
        };
    };
};
//# sourceMappingURL=str.d.ts.map