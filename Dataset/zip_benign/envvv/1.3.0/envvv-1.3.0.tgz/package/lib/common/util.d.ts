export declare const isString: (v?: string | undefined) => v is string;
export declare const isValidDate: <T extends Date>(v: T) => boolean;
//# sourceMappingURL=util.d.ts.map