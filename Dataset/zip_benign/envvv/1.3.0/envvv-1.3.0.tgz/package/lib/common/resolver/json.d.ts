export declare const json: <K extends string>(key: K) => {
    (): {
        key: K;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: string | number | boolean | any[] | Record<string, any> | null | undefined;
        };
    };
    <R extends string | number | boolean | any[] | Record<string, any> | null>(): {
        key: K;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: R | undefined;
        };
    };
    (fallback: string | number | boolean | any[] | Record<string, any> | null): {
        key: K;
        fallback: string | number | boolean | any[] | Record<string, any> | null;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: string | number | boolean | any[] | Record<string, any> | null;
        };
    };
    <R_1 extends string | number | boolean | any[] | Record<string, any> | null>(fallback: R_1): {
        key: K;
        fallback: R_1;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: R_1;
        };
    };
};
//# sourceMappingURL=json.d.ts.map