import type { Parser } from '../types';
export declare const asInt: Parser<number>;
//# sourceMappingURL=int.d.ts.map