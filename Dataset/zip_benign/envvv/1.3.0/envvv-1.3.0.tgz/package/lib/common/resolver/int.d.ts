export declare const int: <K extends string>(key: K) => {
    (): {
        key: K;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: number | undefined;
        };
    };
    <R extends number>(): {
        key: K;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: R | undefined;
        };
    };
    (fallback: number): {
        key: K;
        fallback: number;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: number;
        };
    };
    <R_1 extends number>(fallback: R_1): {
        key: K;
        fallback: R_1;
        fn: (obj: import("..").Dict) => {
            key: K;
            value: R_1;
        };
    };
};
//# sourceMappingURL=int.d.ts.map