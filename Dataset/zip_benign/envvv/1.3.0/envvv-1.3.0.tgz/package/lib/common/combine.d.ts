import type { Ret, UnionToIntersection, Resolver } from './types';
export type CombineOption = {
    fallbackError?: boolean;
};
export declare const combine: <T extends Resolver<string, unknown>[]>(resolvers: T, { fallbackError }?: CombineOption) => (arg: Record<string, string | undefined>) => UnionToIntersection<Ret<T[number]["fn"]>> extends infer T_1 ? { [K in keyof T_1]: UnionToIntersection<Ret<T[number]["fn"]>>[K]; } : never;
//# sourceMappingURL=combine.d.ts.map