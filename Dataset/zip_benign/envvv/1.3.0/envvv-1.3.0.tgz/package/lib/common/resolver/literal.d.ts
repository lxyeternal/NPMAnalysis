export declare const literal: <T extends readonly any[]>(values: T) => <K extends string>(key: K) => {
    (): {
        key: K;
        fn: (obj: import("../types").Dict) => {
            key: K;
            value: T[number] | undefined;
        };
    };
    <R extends T[number]>(): {
        key: K;
        fn: (obj: import("../types").Dict) => {
            key: K;
            value: R | undefined;
        };
    };
    (fallback: T[number]): {
        key: K;
        fallback: T[number];
        fn: (obj: import("../types").Dict) => {
            key: K;
            value: T[number];
        };
    };
    <R_1 extends T[number]>(fallback: R_1): {
        key: K;
        fallback: R_1;
        fn: (obj: import("../types").Dict) => {
            key: K;
            value: R_1;
        };
    };
};
//# sourceMappingURL=literal.d.ts.map