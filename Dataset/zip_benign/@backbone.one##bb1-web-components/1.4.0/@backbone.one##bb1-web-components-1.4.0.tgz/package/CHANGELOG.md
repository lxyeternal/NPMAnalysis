# Changelog

## [1.4.0](https://github.com/backbone-one/bb1-web-components/compare/v1.3.0...v1.4.0) (2025-03-20)


### Features

* add initialState support ([8e5a850](https://github.com/backbone-one/bb1-web-components/commit/8e5a8503bf45ad5c41e655a99d1652512aa1cfa9))

## [1.3.0](https://github.com/backbone-one/bb1-web-components/compare/v1.2.0...v1.3.0) (2025-03-18)


### Features

* enhance loading state animation ([c6e525d](https://github.com/backbone-one/bb1-web-components/commit/c6e525dccea42bc90e1cf9ff918e927c080f9646))

## [1.2.0](https://github.com/backbone-one/bb1-web-components/compare/v1.1.0...v1.2.0) (2025-03-18)


### Features

* add isLoading prop for loading state management ([9202103](https://github.com/backbone-one/bb1-web-components/commit/9202103392d10bb478a3697151ad80a8495073f2))
* update dependencies and change visualizer setting ([c991fae](https://github.com/backbone-one/bb1-web-components/commit/c991faee1d7f9d3d01efb53ad4e1447b2e2c001b))

## [1.1.0](https://github.com/backbone-one/bb1-web-components/compare/v1.0.0...v1.1.0) (2025-03-14)


### Features

* add .npmignore to exclude unnecessary files from npm package ([9df848c](https://github.com/backbone-one/bb1-web-components/commit/9df848c15d4600c0d93f970c210884598dbddc3a))
* Add support for wider layout ([#11](https://github.com/backbone-one/bb1-web-components/issues/11)) ([a2fbe8f](https://github.com/backbone-one/bb1-web-components/commit/a2fbe8f61bb26af91ae0b3579f286f138d77dc58))
* include grid operator details in submit event ([#12](https://github.com/backbone-one/bb1-web-components/issues/12)) ([332f6ad](https://github.com/backbone-one/bb1-web-components/commit/332f6ad01a7b6486c0f12392c63ece30dcdfcf5f))

## 1.0.0 (2025-03-06)


### ⚠ BREAKING CHANGES

* The types for SubmitEvent and ErrorEvent have been updated. This change may affect any code that relies on the previous definitions of these event types.

### Features

* add CI configuration and Dependabot setup for automated workflows ([da2638e](https://github.com/backbone-one/bb1-web-components/commit/da2638e3de3b096e7d8847b5f027389d7e1dd62b))
* add data-testid attributes for improved testing support ([54a6f28](https://github.com/backbone-one/bb1-web-components/commit/54a6f28bc8ad03e9ef47c613d4141cf3ede6571f))
* add onerror and api keys as parameters ([d060e12](https://github.com/backbone-one/bb1-web-components/commit/d060e12b85c60addcd47e099d9e4f3048bd84be6))
* allow styling ([211c18d](https://github.com/backbone-one/bb1-web-components/commit/211c18d51324b03e3bc97a44545d8b18968a5818))
* build script generate types ([751c97e](https://github.com/backbone-one/bb1-web-components/commit/751c97e259ef819ce1e56db462b3c98aba564c24))
* **build:** bundle react ([fe5a421](https://github.com/backbone-one/bb1-web-components/commit/fe5a4213087795b60076f2a4c9dafe6ab4563f9d))
* enhance energy calculator with default translations and open shadow DOM ([52851bc](https://github.com/backbone-one/bb1-web-components/commit/52851bc946be799081ae2917800e9e0c1683e4e6))
* enhance energy calculator with part attributes for improved styling ([9bb7ad3](https://github.com/backbone-one/bb1-web-components/commit/9bb7ad3a725c4bf31513a8c1de07c8a67d1123a7))
* export types for TypeScript ([658ab82](https://github.com/backbone-one/bb1-web-components/commit/658ab82ee0e5a3ac3abb6e66761506f805769789))
* finalize the first version of energy calculator ([1e680ce](https://github.com/backbone-one/bb1-web-components/commit/1e680cebf930fe7d4088a9d63c8a8fa366a6250c))
* handle onsubmit ([3fa464a](https://github.com/backbone-one/bb1-web-components/commit/3fa464a10bcd196543f1f996a395f4368070f85f))
* implement event handling for energy calculator ([ab1d784](https://github.com/backbone-one/bb1-web-components/commit/ab1d784585b32ad96f191efe3de8e6c189117af6))
* make the calculator run in test mode ([2b4f138](https://github.com/backbone-one/bb1-web-components/commit/2b4f138accb5a6c73ae381861e2a0e98a21bdcbc))
* update readme file ([5353d08](https://github.com/backbone-one/bb1-web-components/commit/5353d08202c97c9b8e0993bb06ea867272642697))


### Bug Fixes

* enable custom consumption in the input ([cc8b330](https://github.com/backbone-one/bb1-web-components/commit/cc8b33056b5b9e5e6d57e3b88357a7697f67cbd9))
