import { GridOperator } from './grid-operator';

export type GridOperatorResponse =
  | GridOperator[]
  | { error: string; data?: object };
