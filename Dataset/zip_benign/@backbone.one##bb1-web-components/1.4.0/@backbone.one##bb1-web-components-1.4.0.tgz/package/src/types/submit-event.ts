import { EnergyCalculatorData } from './energy-calculator-data.ts';

interface SubmitEventDetails extends EnergyCalculatorData {
  gridOperatorId: number;
  gridAreaId: number;
}
export interface SubmitEvent extends Event {
  detail: SubmitEventDetails;
}
