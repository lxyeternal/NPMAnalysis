export type HouseholdConsumption = {
  householdSize: string;
  consumption: string;
};

export const householdConsumptions: HouseholdConsumption[] = [
  { householdSize: '1', consumption: '1927' },
  { householdSize: '2', consumption: '3095' },
  { householdSize: '3', consumption: '4255' },
  { householdSize: '4', consumption: '4725' },
  { householdSize: '5+', consumption: '5194' },
];
