export type GridOperator = {
  id: number;
  name: string;
  gridAreaId: number;
};
