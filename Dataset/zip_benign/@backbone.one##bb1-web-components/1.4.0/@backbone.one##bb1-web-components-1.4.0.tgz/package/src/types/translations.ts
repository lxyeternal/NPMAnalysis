export type Translations = {
  title?: string;
  subTitle?: string;
  householdSize: string;
  annualConsumption: string;
  zip: string;
  zipPlaceholder: string;
  gridOperator: string;
  gridOperatorPlaceholder: string;
  gridOperatorInfo: string;
  submit: string;
};
