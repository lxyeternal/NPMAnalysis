export type EnergyCalculatorData = {
  householdSize: string;
  consumption: string;
  zipCode: string;
  gridOperator: string;
};
