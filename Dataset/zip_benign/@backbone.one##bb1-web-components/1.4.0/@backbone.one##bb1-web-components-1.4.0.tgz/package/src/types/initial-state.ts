interface InitialStateBase {
  consumption: number,
  householdSize?: string,
  zipCode: string,
  gridOperatorId?: number,
}

export type InitialState = Partial<InitialStateBase>
