export interface ErrorEvent extends Event {
  detail: {
    name: string;
    message: string;
  };
}
