import EnergyCalculator from './components/energy-calculator.tsx';
import r2wc from '@r2wc/react-to-web-component';

customElements.define(
  'bb1-energy-calculator',
  r2wc(EnergyCalculator, {
    shadow: 'open',
    props: {
      offerServiceApiKey: 'string',
      calculatorLink: 'string',
      translations: 'json',
      initialState: 'json',
      onsubmit: 'function',
      onerror: 'function',
      isLoading: 'boolean',
    },
  })
);

export {};
