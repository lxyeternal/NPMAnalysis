import { z } from 'zod';

const getMandatoryErrorMessage = (field: string) => `${field} eingeben`;
const household = 'Haushalt';
const zipCode = 'Postleitzahl';

export const energyCalculatorSchema = z.object({
  householdSize: z
    .string({ required_error: getMandatoryErrorMessage(household) })
    .trim(),
  consumption: z
    .string({ required_error: getMandatoryErrorMessage(household) })
    .trim()
    .min(1, { message: getMandatoryErrorMessage(household) })
    .max(6, {
      message: 'Der Verbrauch sollte 100.000 kWh nicht überschreiten',
    }),
  zipCode: z
    .string({ required_error: getMandatoryErrorMessage(zipCode) })
    .trim()
    .min(4, { message: getMandatoryErrorMessage(zipCode) })
    .max(4, { message: getMandatoryErrorMessage(zipCode) }),
  gridOperator: z
    .string({ required_error: getMandatoryErrorMessage('Netzbetreiber') })
    .min(1, {
      message:
        'Gib eine gültige Postleitzahl ein, um die Netzbetreiber anzuzeigen',
    })
    .trim(),
});
