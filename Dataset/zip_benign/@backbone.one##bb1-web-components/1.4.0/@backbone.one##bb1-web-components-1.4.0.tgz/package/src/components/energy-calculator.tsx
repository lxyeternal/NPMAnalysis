import { useEffect, useRef, useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Input } from '@nextui-org/input';
import { Button } from '@nextui-org/button';
import { NextUIProvider } from '@nextui-org/system';

import styles from '../globals.css?inline';

const animationSpeed = 0.3;

import {
  Translations,
  EnergyCalculatorData,
  ErrorEvent,
  SubmitEvent,
} from '../types';
import { householdConsumptions } from '../types/household-consumption';
import GridOperatorInput from './grid-operator-input';
import { energyCalculatorSchema } from '../schemas/energy-calculator-schema.ts';
import { defaultTranslations } from '../lib/defaultTranslations.ts';
import { GridOperator } from '../types/grid-operator.ts';
import { Spinner } from '@nextui-org/spinner';
import { motion, AnimatePresence } from 'framer-motion';
import { InitialState } from '../types/initial-state.ts';

export type EnergyCalculatorProps = {
  calculatorLink?: string;
  offerServiceApiKey: string;
  onsubmit?: (event: SubmitEvent) => void;
  onerror?: (event: ErrorEvent) => void;
  translations?: Partial<Translations>;
  initialState?: InitialState;
  isLoading?: boolean;
};

export default function EnergyCalculator({
                                           calculatorLink,
                                           offerServiceApiKey,
                                           translations,
                                           onsubmit,
                                           onerror,
                                           isLoading,
                                           initialState,
                                         }: EnergyCalculatorProps) {
  const t = Object.assign({}, defaultTranslations, translations);
  const ref = useRef<HTMLDivElement>(null);
  const [gridOperator, setGridOperator] = useState<GridOperator | null>(null);
  const initialHouseholdSize = householdConsumptions.find((householdConsumption) => {
    return householdConsumption.householdSize === initialState?.householdSize;
  })?.householdSize ?? '2';

  useEffect(() => {
    if (!offerServiceApiKey) {
      console.error('bb1-energy-calculator - Missing offer-service API key');
    }
  }, [offerServiceApiKey]);

  const onSubmit = (data: EnergyCalculatorData) => {
    const event = new CustomEvent('submit', {
      detail: {
        ...data,
        gridOperatorId: gridOperator?.id,
        gridAreaId: gridOperator?.gridAreaId,
      },
      composed: true,
    } as SubmitEvent);
    if (ref.current) {
      ref.current.dispatchEvent(event);
    }
    onsubmit?.(event);

    if (calculatorLink) {
      const tariffCalculatorLink = `${calculatorLink}?householdSize=${householdSize}&consumption=${data.consumption}&zipCode=${data.zipCode}&gridOperator=${data.gridOperator}`;
      window.open(tariffCalculatorLink, '_blank');
    }
  };

  const onError = (error: Error) => {
    const event = new CustomEvent('error', {
      detail: error,
      composed: true,
    } as ErrorEvent);
    if (ref.current) {
      ref.current.dispatchEvent(event);
    }
    onerror?.(event);
  };

  const {
    handleSubmit,
    register,
    setValue,
    getValues,
    watch,
    formState: { errors },
  } = useForm<z.infer<typeof energyCalculatorSchema>>({
    resolver: zodResolver(energyCalculatorSchema),
    defaultValues: {
      householdSize: initialHouseholdSize,
      consumption: initialState?.consumption?.toString() ?? '3095',
      zipCode: initialState?.zipCode ?? '',
      gridOperator: '',
    },
  });

  const zipCode = getValues('zipCode');
  const consumption = watch('consumption');
  const householdSize = getValues('householdSize');

  const onGridOperatorChange = (gridOperator: GridOperator | null) => {
    setGridOperator(gridOperator);
    setValue('gridOperator', gridOperator?.name ?? '', {
      shouldValidate: true,
    });
  };

  const householdButtonStyles = `border border-darkgray h-[60px] md:h-14 flex-grow`;
  const inputStyles = 'border border-darkgray h-14 font-medium';

  return (
    <NextUIProvider>
      <style type="text/css">{styles}</style>
      <div
        className="w-full min-w-[350px] @container"
        data-testid="energy-calculator"
        ref={ref}
      >
        <div className="p-4 md:p-8">
          {t.title && (
            <p
              className="text-2xl md:text-[28px] leading-8 md:leading-10 pt-10  md:pt-0 ponk"
              data-testid="title"
              part="title"
            >
              {t.title}
            </p>
          )}
          {t.subTitle && (
            <p
              className="font-medium leading-5 md:leading-6 md:text-xl pt-2 md:pt-4"
              data-testid="subtitle"
              part="subtitle"
            >
              {t.subTitle}
            </p>
          )}

          {(t.subTitle || t.title) && <div className="pb-6"></div>}

          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="@4xl:flex @4xl:flex-row @4xl:gap-x-4">
              <div className="pb-6" data-testid="household-selector">
                <p className="font-medium pb-2">{t.householdSize}</p>
                <div className="flex flex-row gap-x-2 houseHoldSize">
                  {householdConsumptions.map((householdConsumption) => (
                    <Button
                      key={householdConsumption.householdSize}
                      variant="bordered"
                      onPress={() => {
                        setValue(
                          'consumption',
                          householdConsumption.consumption,
                          { shouldValidate: true },
                        );
                        setValue(
                          'householdSize',
                          householdConsumption.householdSize,
                          { shouldValidate: true },
                        );
                      }}
                      className={`min-w-[56px] font-semibold text-base ${
                        householdSize == householdConsumption.householdSize
                          ? 'selected'
                          : ''
                      } ${householdButtonStyles}`}
                      aria-label={`Haushalt: ${householdConsumption.householdSize}`}
                      data-testid={`household-size-${householdConsumption.householdSize}`}
                    >
                      {householdConsumption.householdSize}
                    </Button>
                  ))}
                </div>
              </div>
              <div>
                <div className="flex flex-row gap-x-5 md:gap-x-3">
                  <div className="w-full">
                    <p className="font-medium mb-2">{t.annualConsumption}</p>
                    <Input
                      inputMode="numeric"
                      placeholder=" "
                      value={`${consumption}`}
                      {...register('consumption')}
                      radius="sm"
                      size="lg"
                      classNames={{
                        inputWrapper: `${inputStyles} focus-within:!bg-white bg-white`,
                      }}
                      aria-label={t.annualConsumption}
                      isInvalid={!!errors.consumption}
                      errorMessage={errors.consumption?.message}
                      endContent="kWh"
                      data-testid="consumption"
                    />
                  </div>
                  <div className="w-full">
                    <p className="font-medium mb-2">{t.zip}</p>
                    <Input
                      type="tel"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      maxLength={4}
                      placeholder={t.zipPlaceholder}
                      {...register('zipCode')}
                      radius="sm"
                      size="lg"
                      classNames={{
                        inputWrapper: `${inputStyles} focus-within:!bg-white bg-white`,
                      }}
                      onValueChange={() => {
                        setValue('gridOperator', '', { shouldValidate: true });
                      }}
                      aria-label={t.zip}
                      isInvalid={!!errors.zipCode}
                      errorMessage={errors.zipCode?.message}
                      data-testid="zip"
                    />
                  </div>
                </div>
              </div>
              <div className="py-6 @4xl:py-0">
                <GridOperatorInput
                  initialGridOperatorId={initialState?.gridOperatorId}
                  translations={t}
                  offerServiceApiKey={offerServiceApiKey}
                  zipCode={zipCode}
                  onGridOperatorChange={onGridOperatorChange}
                  register={register}
                  errors={errors}
                  onerror={onError}
                />
              </div>
            </div>
            <Button
              isDisabled={isLoading}
              type="submit"
              radius="md"
              className="font-semibold h-[55px] leading-6 w-full @4xl:w-auto @4xl:min-w-[312px]"
              data-testid="submit"
            >
              <AnimatePresence mode="wait">
                {isLoading ? (
                  <motion.div
                    key="spinner"
                    initial={{ clipPath: 'circle(0% at 50% 50%)', opacity: 0 }}
                    animate={{ clipPath: 'circle(100% at 50% 50%)', opacity: 1 }}
                    exit={{
                      clipPath: 'circle(0% at 50% 50%)',
                      opacity: 0,
                      transition: {
                        clipPath: { duration: animationSpeed },
                        opacity: { delay: animationSpeed * 0.5, duration: animationSpeed * 0.75 },
                      },
                    }}
                    transition={{ duration: animationSpeed, ease: 'easeInOut' }}
                    className="flex items-center justify-center w-full h-full"
                  >
                    <Spinner />
                  </motion.div>
                ) : (
                  <motion.div
                    key="text"
                    initial={{ clipPath: 'circle(0% at 50% 50%)', opacity: 0 }}
                    animate={{ clipPath: 'circle(100% at 50% 50%)', opacity: 1 }}
                    exit={{
                      clipPath: 'circle(0% at 50% 50%)',
                      opacity: 0,
                      transition: {
                        clipPath: { duration: animationSpeed },
                        opacity: { delay: animationSpeed * 0.5, duration: animationSpeed * 0.75 },
                      },
                    }}
                    transition={{ duration: animationSpeed, ease: 'easeInOut' }}
                    className="flex items-center justify-center w-full h-full"
                  >
                    {t.submit}
                  </motion.div>
                )}
              </AnimatePresence>
            </Button>
          </form>
        </div>
      </div>
    </NextUIProvider>
  );
}
