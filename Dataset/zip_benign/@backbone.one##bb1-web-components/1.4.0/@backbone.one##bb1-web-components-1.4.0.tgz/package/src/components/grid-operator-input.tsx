import { useEffect, useState } from 'react';
import { GridOperator } from '../types/grid-operator';
import { fetchGridOperators } from '../actions/fetch-grid-operator';
import { EnergyCalculatorData, Translations } from '../types';
import { FieldErrors, UseFormRegister } from 'react-hook-form';
import { GridOperatorResponse } from '../types/grid-operator-response';
import { InvalidZipError } from '../lib/exceptions';
import { Select, SelectItem, SelectSection } from '@nextui-org/select';
import { Input } from '@nextui-org/input';
import { Spinner } from '@nextui-org/spinner';
import infoIcon from '../assets/info-icon.svg';

type GridOperatorInputProps = {
  zipCode: string;
  register: UseFormRegister<EnergyCalculatorData>;
  errors: FieldErrors<EnergyCalculatorData>;
  onerror?: (error: Error) => void;
  onGridOperatorChange: (gridOperator: GridOperator | null) => void;
  translations: Translations;
  offerServiceApiKey: string;
  initialGridOperatorId?: number;
};

export default function GridOperatorInput({
  initialGridOperatorId,
  zipCode,
  register,
  errors,
  onerror,
  onGridOperatorChange,
  translations,
  offerServiceApiKey,
}: GridOperatorInputProps) {
  const [gridOperators, setGridOperators] = useState<GridOperator[]>([]);
  const [selectedGridOperatorName, setSelectedGridOperatorName] =
    useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const inputStyles = 'border border-darkgray h-14 font-medium';

  function gridOperatorChange(gridOperator: GridOperator | null) {
    setSelectedGridOperatorName(gridOperator?.name ?? '');
    onGridOperatorChange(gridOperator);
  }

  const assignGridOperators = async (zipCode: string) => {
    setIsLoading(true);

    try {
      if (!offerServiceApiKey) {
        onerror?.(new Error('Missing offer-service API key'));
        return;
      }

      const gridOperatorResponse: GridOperatorResponse =
        await fetchGridOperators(zipCode, { offerServiceApiKey });
      if ('error' in gridOperatorResponse) {
        const invalidZipError = new InvalidZipError();
        if (gridOperatorResponse.error == invalidZipError.message) {
          onerror?.(invalidZipError);
        } else {
          onerror?.(new Error(gridOperatorResponse.error?.toString()));
        }
      } else {
        setGridOperators(gridOperatorResponse);
        let gridOperatorToUse = gridOperatorResponse[0];

        if(initialGridOperatorId && selectedGridOperatorName === '') { // only initially set the grid operator
          const initialGridOperator = gridOperatorResponse.find(
            (gridOperator) => gridOperator.id === initialGridOperatorId
          );
          gridOperatorToUse = initialGridOperator || gridOperatorToUse;
        }

        gridOperatorChange(gridOperatorToUse);
      }
    } catch (error) {
      onerror?.(new Error(error?.toString()));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (zipCode.trim().length == 4) {
      assignGridOperators(zipCode);
    } else {
      setSelectedGridOperatorName('');
      setGridOperators([]);
    }
  }, [zipCode]);

  return (
    <div className="font-medium pb-2" data-testid="grid-operator">
      {gridOperators.length > 1 ? (
        <div>
          <p className="pb-2 font-medium leading-6">
            {translations.gridOperator}
          </p>
          <Select
            size="lg"
            isLoading={isLoading}
            defaultSelectedKeys={[selectedGridOperatorName]}
            onChange={(e) => {
              const gridOperatorName = e.target.value;
              const gridOperator = gridOperators.find(
                (gridOperator) => gridOperator.name === gridOperatorName
              );
              gridOperatorChange(gridOperator ?? null);
            }}
            classNames={{
              trigger: `h-14 border border-darkgray rounded-lg ${
                gridOperators ? 'bg-white' : ''
              }`,
            }}
            isInvalid={!!errors.gridOperator}
            errorMessage={errors.gridOperator?.message}
            popoverProps={{
              classNames: {
                content: 'rounded-lg',
              },
            }}
            listboxProps={{
              itemClasses: {
                title: 'text-base',
                base: [
                  'data-[selectable=true]:focus:bg-tariffgreen',
                  'data-[pressed=true]:opacity-70',
                ],
              },
            }}
            aria-label={translations.gridOperator}
            disallowEmptySelection={true}
            data-testid="grid-operator-select"
          >
            <SelectSection classNames={{ heading: 'bg-slate' }}>
              {gridOperators.map((gridOperator) => (
                <SelectItem key={gridOperator.name}>
                  {gridOperator.name}
                </SelectItem>
              ))}
            </SelectSection>
          </Select>
        </div>
      ) : (
        <div>
          <p className="font-medium mb-2">{translations.gridOperator}</p>
          <Input
            data-testid="grid-operator-input"
            disabled
            placeholder={translations.gridOperatorPlaceholder}
            value={selectedGridOperatorName}
            style={{ color: 'gray' }}
            {...register('gridOperator')}
            radius="sm"
            size="lg"
            endContent={
              isLoading ? (
                <Spinner
                  className="mx-auto h-[52px]"
                  classNames={{ circle1: 'spinnerCircle' }}
                />
              ) : (
                <></>
              )
            }
            classNames={{
              inputWrapper: `${inputStyles} ${
                selectedGridOperatorName == '' ? 'bg-opacity-50' : 'bg-white'
              }`,
              input: '!text-black',
            }}
            aria-label={translations.gridOperator}
            isInvalid={!!errors.gridOperator}
            errorMessage={errors.gridOperator?.message}
          />
        </div>
      )}
      <div
        className="pt-2 flex flex-row gap-x-[5.33px] items-start"
        data-testid="grid-operator-info"
      >
        <img src={infoIcon} alt="info icon" width={13} height={13} />
        <p className="text-xs leading-4 pb-6">
          {translations.gridOperatorInfo}
        </p>
      </div>
    </div>
  );
}
