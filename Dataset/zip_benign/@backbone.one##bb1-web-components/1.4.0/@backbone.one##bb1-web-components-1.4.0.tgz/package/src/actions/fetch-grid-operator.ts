import { InvalidZipError, NetworkError } from '../lib/exceptions';
import { GridOperatorResponse } from '../types/grid-operator-response';
import { zipCodeSchema } from '../lib/zip-code-schema';

const logger = console;
const offerService = {
  host: 'https://api.platform.backbone.one',
  path: 'offerservice',
};

export async function fetchGridOperators(
  zipCode: string,
  { offerServiceApiKey }: { offerServiceApiKey: string }
): Promise<GridOperatorResponse> {
  try {
    const parsedZip = zipCodeSchema().safeParse(zipCode);

    if (!parsedZip.success) {
      logger.warn('validation failed', {
        zipCode: zipCode,
        validationError: parsedZip.error,
      });
      return { error: 'validation error', data: parsedZip.error.format() };
    }

    const queryParams = new URLSearchParams({
      energyType: 'POWER',
      zipCode: parsedZip.data,
    });

    const response = await fetch(
      `${offerService.host}/${offerService.path}/v1/GridOperators?${queryParams}`,
      {
        method: 'GET',
        headers: {
          'X-API-Key': offerServiceApiKey,
        },
      }
    );
    if (!response.ok) {
      if (response.status == 404) {
        logger.warn('invalid zip', {
          enteredZipCode: zipCode,
        });
        return { error: new InvalidZipError().message };
      } else {
        logger.error('error fetching data', response);
        throw new NetworkError();
      }
    }
    return await response.json();
  } catch (error) {
    logger.error('fetching grid operator failed', error);

    if (error instanceof Error) {
      return { error: error.message };
    }
    return { error: 'fetching grid operator failed' };
  }
}
