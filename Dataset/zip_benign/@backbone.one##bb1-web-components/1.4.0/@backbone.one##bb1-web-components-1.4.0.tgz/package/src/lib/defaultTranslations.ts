import { Translations } from '../types/translations.ts';

export const defaultTranslations: Translations = {
  title: undefined,
  subTitle: undefined,
  householdSize: 'Personen in deinem Haushalt',
  annualConsumption: 'Jahresverbrauch',
  zip: 'Postleitzahl',
  zipPlaceholder: 'z.B. 1100',
  gridOperator: 'Netzbetreiber',
  gridOperatorPlaceholder: 'z.B. Wiener Netze GmbH',
  gridOperatorInfo:
    'Bitte wähle deinen Netzbetreiber, wenn es in deinem Netzgebiet mehr als eine Auswahl gibt.',
  submit: 'Jetzt berechnen',
};