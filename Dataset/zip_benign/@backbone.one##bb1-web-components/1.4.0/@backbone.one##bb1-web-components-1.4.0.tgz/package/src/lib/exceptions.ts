  export class InvalidZipError extends Error {
    constructor(message = 'Ungültige Postleitzahl') {
      super(message);
      this.name = 'InvalidZipError';
    }
  }

  export class NetworkError extends Error {
    constructor(
      message = 'Es ist ein Problem aufgetreten. Bitte versuche es erneut.'
    ) {
      super(message);
      this.name = 'NetworkError';
    }
  }
