import { z } from 'zod';

const errorMessage = 'requiredZip';
const defaultErrorMessage = 'Zip code is required';
const defaultMinLengthMessage = 'Zip code must be at least 4 characters';
const defaultMaxLengthMessage = 'Zip code must not exceed 4 characters';

export const zipCodeSchema = (t?: (key: string) => string): z.ZodString =>
  z
    .string({ required_error: t ? t(errorMessage) : defaultErrorMessage })
    .trim()
    .min(4, { message: t ? t(errorMessage) : defaultMinLengthMessage })
    .max(4, { message: t ? t(errorMessage) : defaultMaxLengthMessage });
