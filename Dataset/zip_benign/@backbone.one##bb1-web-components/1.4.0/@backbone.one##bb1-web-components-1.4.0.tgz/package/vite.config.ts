import { defineConfig } from 'vite';
import typescript from '@rollup/plugin-typescript';
import react from '@vitejs/plugin-react-swc';
import { visualizer } from 'rollup-plugin-visualizer';

export default defineConfig({
  plugins: [react(), visualizer({ open: false })],
  css: {
    postcss: './postcss.config.cjs',
  },
  build: {
    lib: {
      entry: 'src/index.ts',
      name: 'BB1WebComponents',
      fileName: (format, entryName) => `${entryName}.${format}.js`,
    },
    rollupOptions: {
      plugins: [typescript({ tsconfig: 'tsconfig.json' })],
      external: [],
      output: {
        preserveModules: false,
        globals: {
          react: 'React',
          'react-dom': 'ReactDOM',
        },
      },
    },
  },
  optimizeDeps: {
    include: ['react', 'react-dom'],
  },
  define: {
    'process.env.NODE_ENV': '"production"',
  },
});
