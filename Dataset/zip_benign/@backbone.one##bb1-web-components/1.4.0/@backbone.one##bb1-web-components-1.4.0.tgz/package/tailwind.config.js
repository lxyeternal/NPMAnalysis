// tailwind.config.js
const { nextui } = require('@nextui-org/theme');

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/**/*.{js,ts,jsx,tsx}',
    './node_modules/@nextui-org/theme/dist/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        black: '#08230B',
        white: '#ffffff',
        darkgray: '#A6A6A6',
      },
    },
  },
  darkMode: 'class',
  plugins: [
    nextui(),
    require('@tailwindcss/container-queries'),
  ],
};
