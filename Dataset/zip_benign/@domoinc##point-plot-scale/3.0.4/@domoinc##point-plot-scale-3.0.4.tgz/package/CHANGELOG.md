<a name"v2.0.0"></a>
## v2.0.0 (2015-06-09)


#### Bug Fixes

* using unique ID as key value pair attached to data ([7f8377d1](https://git.empdev.domo.com/DA/yoWidget/commit/7f8377d1))
* removed unique id from data and have it added manually via transform ([96713f0f](https://git.empdev.domo.com/DA/yoWidget/commit/96713f0f))
* fix bug with reordering of groups in dom when changing scale ([98291c86](https://git.empdev.domo.com/DA/yoWidget/commit/98291c86))
* fixed label hiding bug, and improved function cohesion ([b8310b8e](https://git.empdev.domo.com/DA/yoWidget/commit/b8310b8e))
* removed cloning node, added dom reordering ([bacc30d4](https://git.empdev.domo.com/DA/yoWidget/commit/bacc30d4))
* fixed bug with ranges and scale clamping ([0ea1eb56](https://git.empdev.domo.com/DA/yoWidget/commit/0ea1eb56))
* transition locks and data ([cdd11013](https://git.empdev.domo.com/DA/yoWidget/commit/cdd11013))
* added key function to prevent paths from transitioning when configs are changed ([aa6c742f](https://git.empdev.domo.com/DA/yoWidget/commit/aa6c742f))
* validating ranges for null values ([2c84e060](https://git.empdev.domo.com/DA/yoWidget/commit/2c84e060))
* fix bug with appending new data rows on edit ([e8f2af9d](https://git.empdev.domo.com/DA/yoWidget/commit/e8f2af9d))
* fixed svg ([9d863004](https://git.empdev.domo.com/DA/yoWidget/commit/9d863004))


#### Features

* added resizing for point groups ([d08473a7](https://git.empdev.domo.com/DA/yoWidget/commit/d08473a7))
* added transitions on render ([520ec090](https://git.empdev.domo.com/DA/yoWidget/commit/520ec090))
* added range scale and color scale for rects and paths ([5a11a34c](https://git.empdev.domo.com/DA/yoWidget/commit/5a11a34c))


<a name"v1.0.0"></a>
## v1.0.0 (2015-05-15)


#### Bug Fixes

* removed bug involving foreach lodash library ([01661d66](https://git.empdev.domo.com/DA/yoWidget/commit/01661d66))
* changed attrs to styles when appropriate ([20f9de02](https://git.empdev.domo.com/DA/yoWidget/commit/20f9de02))


#### Features

* added configs for text style attributes ([f7c576d1](https://git.empdev.domo.com/DA/yoWidget/commit/f7c576d1))


