/*----------------------------------------------------------------------------------
Create Widget -> index.html

© 2011 - 2015 DOMO, INC.
----------------------------------------------------------------------------------*/

//Setup some fake data
var data = [
  ['North', 3,],
  ['South', 4.5,],
  ['East',  5,],
  ['West',  7,],
  ['West',  7,],
  ['West',  7,],
];

var ranges = [
  [0,2],
  [2,4],
  [4,6],
  [6,8],
  [8,10],
]

//Initialze the widget
var chart = d3.select('#vis')
  .append('svg')
  .attr({
    height: 500,
    width: 500
  })
  .append('g')
  .attr('transform', 'translate(0,190)')
  .chart('PointPlotScale')
  .c({
    width: 500,
    height: 11,
    ranges: ranges,
    pointScale: 1,
  });

//Render the chart with data
chart._notifier.showMessage(true);
chart.draw(data);
