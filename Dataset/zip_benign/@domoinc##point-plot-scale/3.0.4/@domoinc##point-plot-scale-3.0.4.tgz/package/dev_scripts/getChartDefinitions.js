var system = require('system');
var page = require('webpage').create();

var args = system.args;

var port = args[1];
var widgetName = args[2];

page.open('http://localhost:'+port+'/index.html', function() {
  var obj = page.evaluate(function(name){
    var chart = d3.select('#vis')
      .append('svg')
      .append('g')
      .chart(name);

    return JSON.stringify({config:chart._config, dataDefinition:chart._dataDefinition}, function(key, val) {
      if (typeof val === 'function') {
        return val.toString();
      }
      return val;
    });

  }, widgetName);

  system.stdout.write(obj);

  /* jshint ignore:start */
  phantom.exit();
  /* jshint ignore:end */
});
