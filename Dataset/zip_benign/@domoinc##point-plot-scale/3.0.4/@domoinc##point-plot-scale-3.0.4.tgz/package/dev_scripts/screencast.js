var system = require('system');
var args = system.args;
var page = require('webpage').create();

var port = 9001;
if (args.length >= 2) {
  console.log(args[1]);
  port = args[1];
}

page.viewportSize = {width:500, height:500};

page.clipRect = {
  top:8,
  left:8,
  width:500,
  height:500
};

page.open('http://localhost:'+port+'/index.html', function() {
  page.evaluate(function() {
    var style = document.createElement('style');
    var text = document.createTextNode('body { background: #fff }');
    style.setAttribute('type', 'text/css');
    style.appendChild(text);
    document.head.insertBefore(style, document.head.firstChild);
  });

  var count = 1;
  var interval = setInterval(function() {
    page.render('media/widget_'+(count++)+'.png', {format:'png'});
  },40);

  setTimeout(function() {
    clearInterval(interval);

    /* jshint ignore:start */
    phantom.exit(count-1);
    /* jshint ignore:end */

  },5000);
});
