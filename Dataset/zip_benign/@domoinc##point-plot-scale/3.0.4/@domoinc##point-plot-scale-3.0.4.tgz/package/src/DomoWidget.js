/*----------------------------------------------------------------------------------
Chart Auto Widget File

© 2011 - 2015 DOMO, INC.
----------------------------------------------------------------------------------*/

// Add your chart to our the registry with your chart's unique name.
AutoWidgets.register('DomoPointPlotScaleDomo', function(container) {

  // Use the bBox of the 'chartBounds' rect to find out
  // the size of the chart we need to render.
  var bBox = container.select('[id^=chartBounds]')
    .node()
    .getBBox();

  // Transform our chart's container to fit where the user placed the wiget
  container.attr('transform', 'translate(' + bBox.x + ',' + bBox.y + ')')
    .selectAll('*')
    .remove();

  // Set some sample data to use with out widget.
  var sampleData = [
    ['North', 3,],
    ['South', 4.5,],
    ['East',  5,],
    ['West',  7,],
    ['West',  7,],
    ['West',  7,],
  ];

  var ranges = [
    [0,2],
    [2,4],
    [4,6],
    [6,8],
    [8,10],
  ];

  // Set the data subscription name to what user specified.
  var dataName = container.node().parentNode.id;

  // This will allow the wiring experience to show the user
  // which widget item they are powering.
  container.attr('data-dm-field', dataName);

  // Create the data subscription with sample data.
  // You can create as many of these as your chart needs.
  var sampleDataObj = {};
  sampleDataObj[dataName + '_Values'] = {
    columnNames: ['Point Name', 'Point Value'],
    defaultValue: sampleData
  };

  sampleDataObj[dataName + '_Ranges'] = {
    columnNames: ['Lower Range Value', 'Upper Range Value'],
    defaultValue: ranges
  };

  //Initialize widget and set parameters.
  var widget = AutoWidgets.baseWidget(container.chart('PointPlotScale'))
    .c({
      'height': bBox.height,
      'width': bBox.width,
      'ranges': ranges
    })
    .sampleData(sampleDataObj);

  widget.renderWithData = function(data) {
    var renderData = data[widget.dataName() + '_Values'].data;
    var renderRange = data[widget.dataName() + '_Ranges'].data;

    widget
      .c('ranges', renderRange)
      .draw(renderData);
    return widget;
  };

  widget._notifier.showMessage(true);

  // Pass the dataname to widget object so it knows which data to call
  // on render.
  widget.dataName(dataName);

  // Return wiget so to keep the methods chainable.
  return widget;
});
