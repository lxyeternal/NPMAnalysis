var d3 = require('d3');
var d3Chart = require('d3.chart');
var Utilities = require('@domoinc/utilities');
var BaseWidget = require('@domoinc/base-widget');
var daTheme2 = require('@domoinc/da-theme2');

/*----------------------------------------------------------------------------------
----------------------------------------------------------------------------------
// PointPlotScale:
//
© 2011 - 2015 DOMO, INC.
----------------------------------------------------------------------------------
----------------------------------------------------------------------------------*/
module.exports = BaseWidget.extend('PointPlotScale', {
  //**********************************************************************************
  //**********************************************************************************
  initialize: function() {
    'use strict';

    var _Chart = this;


    //----------------------------------------------------------------------------------
    // Config helper functions
    //----------------------------------------------------------------------------------
    function getHeight() {
      return _Chart.c('height');
    }

    //----------------------------------------------------------------------------------
    // Config
    //----------------------------------------------------------------------------------
    _Chart._newConfig = {
      //Plugin configurable configs
      width: {
        name: 'Widget Width',
        description: 'Width of the widget',
        value: 400,
        type: 'number',
        units: 'px'
      },
      height: {
        name: 'Bar Height',
        description: 'Height of the bar',
        value: 11,
        type: 'number',
        units: 'px'
      },
      pointScale: {
        name: 'Point Size',
        description: 'Scale value for the point size: (e.g. 1 is default, 0.5 is half the default size, 2 is twice the default size, etc.)',
        value: 1,
        type: 'number',
        units: 'scale',
      },

      textFontFamily: daTheme2.themeElements.h5FontFamily(),
      labelTextSize: daTheme2.themeElements.h5FontSize(),
      labelTextColor: daTheme2.themeElements.h5FontColor(),

      //Widget default configs
      chartName: {
        description: 'Name of chart for reporting',
        value: 'PointPlotScale',
        type: 'string'
      },
      yOffset: {
        description: 'Offset each subsequent tier moves up in y',
        value: -11,
        type: 'number'
      },
      xOffset: {
        description: 'Choose to have the duplicate data points offset on X or Y (true is the X)',
        value: false,
        type: 'boolean'
      },
      colorSeries: {
        description: 'Color Series',
        value: daTheme2.domoColors,
      },
      ranges: {
        description: 'Ranges for scales for each colored bar',
        value: [
          [0,2],
          [2,4],
          [4,6],
          [6,8],
          [8,14],
        ],
        type: 'array',
      },
    };
    _Chart.mergeConfig(_Chart._newConfig);



    //----------------------------------------------------------------------------------
    // Data Definition:
    //----------------------------------------------------------------------------------
    _Chart._newDataDefinition = {
      'Label': {
        type: 'string',
        validate: function (d) { return this.accessor(d) !== undefined; },
        accessor: function (line) { return line[0] === undefined ? undefined : String(line[0]); }
      },
      'Value': {
        type: 'number',
        validate: function (d) { return !isNaN(this.accessor(d)) && this.accessor(d) >= 0; },
        accessor: function (line) { return Number(line[1]); }
      },
      'Key': {
        type: 'string',
        validate: function (d) { return true; },
        accessor: function (line) { return line[2] === undefined ? undefined : String(line[2]); }
      }
    };
    _Chart.mergeDataDefinition(_Chart._newDataDefinition);



    //----------------------------------------------------------------------------------
    // Interface - chart's .on()' and document '.trigger()'
    //----------------------------------------------------------------------------------


    //----------------------------------------------------------------------------------
    // Static - Anything that is defined here will never change
    //----------------------------------------------------------------------------------
    _Chart._pointGroup = _Chart._layerGroup.append('g').classed('totalPointGroup', true);
    _Chart._rectGroup = _Chart._layerGroup.append('g').classed('rectGroup', true);
    _Chart._colorScale = d3.scale.threshold();
    _Chart._linear = d3.scale.linear().clamp(true);


    /*----------------------------------------------------------------------------------
    // Data validation function and chart variable setup.
    ----------------------------------------------------------------------------------*/

    //**********************************************************************************
    // d3.Chart Transform
    //**********************************************************************************
    var superTransform = _Chart.transform;
    _Chart.transform = function (data) {

      var validData = superTransform(data);
      addUniqueID(validData);
      validateRanges();
      sortRanges();
      initChartVariables();
      calculateAverage(validData);

      return validData;
    };


    //----------------------------------------------------------------------------------
    // Layers: This is where you'll place your layers.
    //----------------------------------------------------------------------------------

    //**********************************************************************************
    //**********************************************************************************
    _Chart.layer('rects', _Chart._rectGroup, {
      //**********************************************************************************
      //**********************************************************************************
      dataBind: function(validData) {
        return this.selectAll('rect')
          .data(_Chart.c('ranges'));
      },

      //**********************************************************************************
      //**********************************************************************************
      insert: function() {
        return this.append('rect');
      },

      //----------------------------------------------------------------------------------
      // Events
      //----------------------------------------------------------------------------------
      events: {
        //**********************************************************************************
        //**********************************************************************************
        'enter': function() {
          return this.attr('x', 0).attr('width', 0);
        },

        //**********************************************************************************
        //**********************************************************************************
        'merge': function() {
          return this
            .style('fill', function(d, i) {
              return _Chart._colorScale(_Chart.a('Label')(d));
            })
            .transition('rects')
            .duration(500)
            .attr({
              x: function(d, i) {
                return _Chart._linear(d[0]);
              },
              y: 25 * _Chart.c('pointScale'),
              width: function(d, i) {
                return _Chart._linear(d[1] - d[0]);
              },
              height: _Chart.c('height'),
            });
        },

        //**********************************************************************************
        //**********************************************************************************
        'exit': function() {
          return this.remove();
        }
      }
    });

    //**********************************************************************************
    //**********************************************************************************
    _Chart.layer('points', _Chart._pointGroup, {
      //**********************************************************************************
      //**********************************************************************************
      dataBind: function(validData) {
        _Chart.pointSelection = this.selectAll('g')
          .data(validData, function (d, i) {
            return d.uniqueID;
          });

        return _Chart.pointSelection;
      },

      //**********************************************************************************
      //**********************************************************************************
      insert: function() {
        var pointGroup = this.append('g')

        pointGroup.append('path');
        pointGroup.append('text').attr('class', 'labelText');
        pointGroup.append('circle');
        pointGroup.append('text').attr('class', 'numberText');

        return pointGroup;
      },

      //----------------------------------------------------------------------------------
      // Events
      //----------------------------------------------------------------------------------
      events: {
        //**********************************************************************************
        //**********************************************************************************
        'enter': function() {
          var pointGroup = this;
          pointGroup.attr('class', 'PointGroup');
          pointGroup.on('mouseover', showLabel);
          pointGroup.on('mouseout', hideLabel);

          pointGroup.select('text.labelText')
            .attr('x', 0)
            .style({
              'text-anchor': 'middle',
              'dominant-baseline': 'central',
              'pointer-events': 'none'
            });

          pointGroup.select('circle')
            .style('fill', '#fff');

          pointGroup.select('text.numberText')
            .attr('x', 0)
            .style({
              'text-anchor': 'middle',
              'dominant-baseline': 'central',
              'font-size': '10px',
              'pointer-events': 'none',
            });

          return pointGroup;
        },

        //**********************************************************************************
        //**********************************************************************************
        'merge': function() {
          var pointGroup = this;

          this.attr('transform', 'translate(0,0)')

          pointGroup.select('path')
            .style('fill', function(d, i) {
              return _Chart._colorScale(_Chart.a('Value')(d));
            })
            .attr({
              d: function(d, i) {
                return 'm 0,20 l 9.6 -20.6 c 0.0999866 -0.199994 0.200023 -0.500012 0.299999 -0.8 c 0.5 -1.2 0.8 -2.6 0.8 -4 c 0 -5.9 -4.8 -10.7 -10.7 -10.7 s -10.7 4.8 -10.7 10.7 c 0 1.4 0.3 2.8 0.8 4 c 0.1 0.2 0.2 0.5 0.3 0.7 l 9.6 20.6 Z';
              },
            })
            .transition('path')
            .duration(500)
            .attr({
              'transform': function(d) {
                return 'translate(' + _Chart._linear(_Chart.a('Value')(d)) + ',0) scale(' + _Chart.c('pointScale') + ')';
              },
            });

          pointGroup.select('text.labelText')
            .transition('labelText')
            .duration(500)
            .attr({
              x: function(d, i) {
                return _Chart._linear(_Chart.a('Value')(d))
              },
              y: -27 * _Chart.c('pointScale'),
            })
            .style({
              'opacity': 1,
              'visibility': 'hidden',
              'font-family': _Chart.c('textFontFamily'),
              'font-size': _Chart.c('labelTextSize') * _Chart.c('pointScale') + 'px',
              'fill': _Chart.c('labelTextColor')
            })
            .text(function(d) {
              return _Chart.a('Label')(d);
            })
            .call(d3.DomoTransitionEndAll, collisionDetection);

          pointGroup.select('circle')
            .transition('circle')
            .duration(500)
            .attr({
              cx: function(d, i) {
                return _Chart._linear(_Chart.a('Value')(d))
              },
              cy: -5 * _Chart.c('pointScale'),
              r: 8 * _Chart.c('pointScale'),
            });

          pointGroup.select('text.numberText')
            .style({
              'fill': function(d, i) {
                return _Chart._colorScale(_Chart.a('Value')(d));
              },
              'font-family': _Chart.c('textFontFamily'),
              'font-size': 10 * _Chart.c('pointScale') + 'px',
            })
            .attr('y', -5 * _Chart.c('pointScale'))
            .text(function(d) {
              return Math.floor(_Chart.a('Value')(d));
            })
            .transition('numberText')
            .duration(500)
            .attr({
              x: function(d, i) {
                return _Chart._linear(_Chart.a('Value')(d))
              },
            });

          _Chart.pointSelection.sort(function(a,b) {
            return d3.ascending(a.uniqueID, b.uniqueID)
          });

          return pointGroup;
        },

        //**********************************************************************************
        //**********************************************************************************
        'exit': function() {
          return this.remove();
        }
      }
    });


    //----------------------------------------------------------------------------------
    // Event Functions
    //----------------------------------------------------------------------------------
    /**
    * show label on hover
    * @param  {array} dd - data row
    * @param  {number} ii - index
    */
    function showLabel(dd, ii) {
      var thisNode = this; // jshint ignore:line
      var labelText = d3.select(this).select('.labelText'); // jshint ignore:line

      //move group to front on hover
      if (thisNode.parentElement) {
        thisNode.parentElement.appendChild(thisNode);
      }

      //make path a little bit bigger when hover on
      d3.select(this).select('path') // jshint ignore:line
        .style({
          'stroke': _Chart._colorScale(_Chart.a('Value')(dd)),
          'stroke-width': 1
        });

      //show text on hover
      d3.select(this).select('.labelText').style('opacity', 1); // jshint ignore:line

      if (_Chart.c('xOffset') === false) {
        var filteredData = _Chart._pointGroup.selectAll('.PointGroup')
          .filter(function(d, i) {
            var data = labelText.data()[0];
            if (thisNode !== this) {
              return _Chart.a('Value')(d) === _Chart.a('Value')(data);
            }
          });

        //make other paths not being hovered on gray
        filteredData.selectAll('path').style('fill', '#e4e5e5');
        filteredData.selectAll('.numberText').style('fill', '#e4e5e5');
      }
    }

    /**
    * hide label off hover
    */
    function hideLabel() {
      _Chart.pointSelection.sort(function(a,b) {
        return d3.descending(a.uniqueID, b.uniqueID)
      });

      _Chart._pointGroup.selectAll('path')
        .style({
          'fill': function(d, i) {
            return _Chart._colorScale(_Chart.a('Value')(d));
          },
          'stroke-width': 0,
        });

      _Chart._pointGroup.selectAll('.numberText')
        .style('fill', function(d, i) {
          return _Chart._colorScale(_Chart.a('Value')(d));
        });

      d3.select(this).selectAll('.labelText') // jshint ignore:line
        .style('opacity', function(d) {
          if (d.isOverlapping) {
            return 0;
          } else {
            return 1;
          }
        });
    }

    //----------------------------------------------------------------------------------
    // Helper Functions
    //----------------------------------------------------------------------------------
    /**
    * Add unique ID's to each row of data for key function
    */
    function addUniqueID(validData) {
      var i;
      for (i = 0; i < validData.length; i++) {
        validData[i].uniqueID = i;
        // validData[i][2] = i;
      }
    }

    /**
    * validate to make sure there is no null values
    */
    function validateRanges() {
      var validatedRanges = [];
      for (var i = 0; i < _Chart.c('ranges').length; i++) {

        var lowerRangeIsValid = parseFloat(_Chart.c('ranges')[i][0]) || parseFloat(_Chart.c('ranges')[i][0]) === 0;
        var upperRangeIsValid = parseFloat(_Chart.c('ranges')[i][1]) || parseFloat(_Chart.c('ranges')[i][1]) === 0;

        var arrayIsValid = lowerRangeIsValid && upperRangeIsValid;

        if(arrayIsValid) {
          validatedRanges.push([parseFloat(_Chart.c('ranges')[i][0]), parseFloat(_Chart.c('ranges')[i][1])]);
        }
      }

      _Chart.c('ranges', validatedRanges);

    }

    /**
    * sort the array of ranges
    */
    function sortRanges() {
      _Chart.c('ranges').sort(function (a, b) {
        if (a[0] > b[0]) {
          return 1;
        } else if (a[0] < b[0]) {
          return -1;
        }
      });
    }

    /**
    * initialize scale for rects
    */
    function initChartVariables() {

      //position scale
      var lastRange = _Chart.c('ranges')[_Chart.c('ranges').length - 1];
      var max = lastRange ? lastRange[1] : 0;

      _Chart._linear
        .domain([0, max])
        .range([0, _Chart.c('width')]);

      //color scale
      var rangesUpper = _Chart.c('ranges').map(function(line) { return line[1]; }); //gets the second upper value in each range
      rangesUpper.pop();

      var colorTheme = daTheme2.getPrimaryColorsForNumberOfSeries(_Chart.c('ranges').length, _Chart.c('colorSeries'));

      _Chart._colorScale
        .range(colorTheme)
        .domain(rangesUpper);
    }

    /**
    * Calculate the average and trigger it out
    * @param  {array} data - the charts' valid data
    */
    function calculateAverage(data) {
      var sum = d3.sum(data, function(row) {
        return row[1];
      })
      var avg = Math.round(sum / data.length);

      _Chart.averageNum = avg;
      _Chart.averageColor = _Chart._colorScale(avg);
    }

    //----------------------------------------------------------------------------------
    // Point positioning functions
    //----------------------------------------------------------------------------------
    /**
    * move groups when they have same data and show labels according to room
    */
    function collisionDetection() {
      movePointGroups();
      appendLabels();
      labelCollision();

      _Chart.pointSelection.sort(function(a,b) {
        return d3.descending(a.uniqueID, b.uniqueID)
      });
    }

    /**
    * move point groups to overlap if they have identical data
    */
    function movePointGroups() {
      _Chart._layerGroup.selectAll('.PointGroup')
        .data()
        .forEach(function(row, index) {
          //Same Data gets offset
          var dupeData = _Chart._layerGroup.selectAll('.PointGroup')
            .filter(function(d, i) {
              return d[1] === row[1]
            });
          var i;

          if (dupeData[0].length > 1) {
            //flag used to show or hide labels when hover off
            for (i = 0; i < dupeData[0].length; i++) {
              dupeData[0][i].__data__.isOverlapping = true;
            }

            var mod = 0;
            var count = 0;
            dupeData
              .transition('collision')
              .attr({
                transform: function(d, i) {
                  // i = dupeData.size() - 1 - i;
                  if (_Chart.c('xOffset') === false) {
                    if (i < 5) {
                      return 'translate(0,' + (i * _Chart.c('yOffset')) + ')';
                    } else if (i >= 5 && i < 10) {
                      count++;
                      return 'translate(' + _Chart.c('yOffset') + ',' + ((count * _Chart.c('yOffset')) - _Chart.c('yOffset')) + ')';
                    } else if (i >= 10) {
                      mod++;
                      return 'translate(' + -_Chart.c('yOffset') + ',' + ((mod * _Chart.c('yOffset')) - _Chart.c('yOffset')) + ')';
                    }
                  } else {
                    if ((i + 1) % 2 === 0 && i !== 0) {
                      mod = (i + 1) / 2
                      count++
                        return 'translate(' + (mod * Math.abs(_Chart.c('yOffset'))) + ',0)';
                    } else {
                      return 'translate(' + ((i - count) * _Chart.c('yOffset')) + ',0)';
                    }
                  }
                }
              });

            dupeData.selectAll('text.labelText')
              .style('opacity', 0);
          } else {
            _Chart._layerGroup.selectAll('text.labelText')
              .style('visibility', 'visible');

            //flag used to show or hide labels when hover off
            for (i = 0; i < dupeData[0].length; i++) {
              dupeData[0][i].__data__.isOverlapping = false;
            }
          }
        })
    }

    /**
    * append the labels
    */
    function appendLabels() {
      _Chart._layerGroup.selectAll('.labelText')
        .each(function(data, index) {
          var extendedName = data[0].split(' ')

          if (extendedName.length > 1) {
            d3.select(this).text('')
            d3.select(this)
              .append('tspan')
              .text(extendedName[0])
              .style('text-anchor', 'middle')
              .attr({
                x: function(d, i) {
                  return _Chart._linear(_Chart.a('Value')(d));
                },
                y: -34
              });
            d3.select(this)
              .append('tspan')
              .text(extendedName[1])
              .style('text-anchor', 'middle')
              .attr({
                x: function(d, i) {
                  return _Chart._linear(_Chart.a('Value')(d));
                },
                y: -20
              });
          }
        });
    }

    /**
    * shows or hides labels depending if there is room
    */
    function labelCollision() {
      _Chart._layerGroup.selectAll('.labelText')
        .each(function(data, index) {
          var indexNode = this;
          var indexBBox = this.getBoundingClientRect();

          //Coliding Labels need to be hidden
          _Chart._layerGroup.selectAll('.labelText')
            .each(function(d, i) {
              var thisBBox = this.getBoundingClientRect();
              if (i >= index) {
                var indexBBoxIsInThisBBox = indexBBox.left > thisBBox.left && indexBBox.left < thisBBox.right;
                var thisBBoxIsInIndexBBox = thisBBox.left > indexBBox.left && thisBBox.left < indexBBox.right;
                if (indexBBoxIsInThisBBox || thisBBoxIsInIndexBBox) {
                  d3.select(indexNode).style('opacity', 0);
                  d3.select(this).style('opacity', 0);

                  d3.select(indexNode)[0][0].__data__.isOverlapping = true; //used to show or hide labels when hover off
                  d3.select(this)[0][0].__data__.isOverlapping = true;
                }
              }
            });
        });
    }
  }
});
