var webpack = require('webpack');
var config = {
  entry: './src/Widget',
  output: {
    path: __dirname + '/dist',
    publicPath: '/dist/',
    filename: 'bundle.js',
    libraryTarget: 'umd',
    library: 'PointPlotScale'
  },
  plugins: [
    new webpack.BannerPlugin('Copyright 2016 Domo Inc.')
  ],
  externals: {
    d3: 'd3',
    'd3.chart': 'd3.chart',
    '@domoinc/base-widget': {
      root: 'BaseWidget',
      commonjs: '@domoinc/base-widget',
      commonjs2: '@domoinc/base-widget',
      amd: 'base-widget'
    },
    '@domoinc/da-theme2': {
      root: ['da','theme2'],
      commonjs: '@domoinc/da-theme2',
      commonjs2: '@domoinc/da-theme2',
      amd: 'theme2'
    },
    '@domoinc/utilities': {
      root: 'Utilities',
      commonjs: '@domoinc/utilities',
      commonjs2: '@domoinc/utilities',
      amd: 'utilities'
    }
  }
};

config.setDev = function() {
  var externals = config.externals;
  delete config.externals;
  config.entry = {
    app: config.entry,
    vendor: Object.keys(externals)
  };
  config.plugins.push(new webpack.optimize.CommonsChunkPlugin(/* chunkName= */"vendor", /* filename= */"vendor.bundle.js"));
}
if (process.env.NODE_ENV === 'development') {
  config.setDev();
}

module.exports = config;
