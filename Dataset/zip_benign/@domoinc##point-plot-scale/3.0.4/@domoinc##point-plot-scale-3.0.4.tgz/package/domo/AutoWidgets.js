var AutoWidgets = {
	widgetRegistry: []
};

AutoWidgets.baseWidget = function(widget){

	widget.dataName = function(dataName){
		if(!arguments.length) return widget._dataName;
		widget._dataName = dataName;
		return widget;
	}

	widget.renderWithData = function(){
		widget.draw($badge.data[widget.dataName()].val());
		return widget;
	}
	return widget;
}

AutoWidgets.findWidgets = function(container){
	var widgets = [];
	for(var i=0; i<AutoWidgets.widgetRegistry.length; i++){
		var desc = AutoWidgets.widgetRegistry[i];
		container.selectAll("[id^=" + desc[0] + "]")
			.each(function(){
				widgets.push(desc[1](d3.select(this)));
			})
	}

	widgets.renderAll = function(){
		for(var i=0; i<widgets.length; i++){
		    widgets[i].renderWithData();
		  }
	}
	return widgets;
}

AutoWidgets.register = function(svgName, chartFunction){
	AutoWidgets.widgetRegistry.push([svgName, chartFunction]);
}