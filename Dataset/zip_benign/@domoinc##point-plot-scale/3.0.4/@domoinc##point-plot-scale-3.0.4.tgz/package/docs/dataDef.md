## Data Definition


#### Key
Type: `string`

Default validate:  
```js
function (d) { return true; }
```

Default accessor:  
```js
function (line) { return line[2] === undefined ? undefined : String(line[2]); }
```

#### Label
Type: `string`

Default validate:  
```js
function (d) { return this.accessor(d) !== undefined; }
```

Default accessor:  
```js
function (line) { return line[0] === undefined ? undefined : String(line[0]); }
```

#### Value
Type: `number`

Default validate:  
```js
function (d) { return !isNaN(this.accessor(d)) && this.accessor(d) >= 0; }
```

Default accessor:  
```js
function (line) { return Number(line[1]); }
```

