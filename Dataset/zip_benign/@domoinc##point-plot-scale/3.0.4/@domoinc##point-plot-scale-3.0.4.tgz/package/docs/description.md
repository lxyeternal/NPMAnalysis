# PointPlotScale

A scale with configurable ranges with points marked by the data



