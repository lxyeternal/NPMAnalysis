interface Opts {
    mobileToDesktop?: boolean;
    ignoreUnknownVersions?: boolean;
    config?: string;
    env?: string;
    path?: string;
    throwOnMissing?: boolean;
}
interface Execute {
    (query: string | string[], opts?: Opts): string[];
}
declare const execute: Execute;
export = execute;
