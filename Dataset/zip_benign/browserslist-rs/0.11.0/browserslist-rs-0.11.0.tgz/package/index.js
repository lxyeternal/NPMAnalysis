"use strict";
const helper_1 = require("@node-rs/helper");
const bindings = (0, helper_1.loadBinding)(__dirname, 'browserslist-rs', 'browserslist-rs');
const execute = bindings.execute;
module.exports = execute;
