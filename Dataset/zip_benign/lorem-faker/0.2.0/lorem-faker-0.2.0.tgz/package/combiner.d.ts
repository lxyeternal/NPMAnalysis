import { type TSafeMailDomain } from './domains.js';
import { ShuffledKeyGenerator } from './shuffle.js';
import { NumGenerator, NumPermutationGenerator } from './num.js';
/**
 * Параметры стратегии генератора.
 *
 * Каждый элемент должен быть целым числом определяющим количество выпадений стратегии.
 */
type TPersonCombinerStrategyOptions = {
    /** первое слово параметра */
    ff: number;
    /** второе слово параметра */
    ss: number;
    /** первое + второе */
    fs: number;
    /** второе + первое */
    sf: number;
    /** первое + подстановка */
    fp: number;
    /** подстановка + первое */
    pf: number;
    /** второе + подстановка */
    sp: number;
    /** подстановка + второе */
    ps: number;
    /** только подстановка */
    pp: number;
};
/**
 * Комбинирует уникальные строки на основе константных наборов.
 */
declare class PersonCombiner {
    protected readonly _sets: readonly [readonly string[], readonly string[]];
    protected readonly _nameCache: Map<string, string>;
    protected readonly _loginCache: Set<string>;
    protected readonly _emailCache: Set<string>;
    protected readonly _abCache: string[];
    protected readonly _genAOrB: readonly [NumGenerator, NumGenerator];
    protected readonly _genAB: NumPermutationGenerator<[number, number]>;
    protected readonly _shuffleAOrB: ShuffledKeyGenerator<0 | 1>;
    protected readonly _shuffleEmail: ShuffledKeyGenerator<TSafeMailDomain>;
    protected readonly _strategy: ShuffledKeyGenerator<keyof TPersonCombinerStrategyOptions>;
    /**
     * @param strategy Стратегии объединения имен. По умолчанию применяется предопределенный {@link strategy}.
     */
    constructor(strategy?: undefined | null | TPersonCombinerStrategyOptions);
    protected _getName(name: string): string;
    protected _nextAOrB(): string;
    protected _tryNextAB(): null | {
        value: string;
        cancel(): void;
    };
    protected _trySetLogin(login: string): null | string;
    protected _trySetEmail(prefix: string): null | string;
    protected _fallbackAB(npp: boolean, name: string, surname: string, tryUse: ((v: string) => null | string)): null | string;
    protected _fallbackAOrB(name: string, surname: string, tryUse: ((v: string) => null | string)): null | string;
    protected _fallback(name: string, surname: string, tryUse: ((v: string) => null | string)): string;
    /**
     * Генерирует уникальную строку.
     *
     * @param name    Имя которое может, но необязательно, будет подставлено в целевую строку.
     * @param surname Фамилия.
     */
    next(name: string, surname: string, useEmail: boolean): string;
    /**
     * Очищает кеш данных.
     */
    reset(): void;
}
export { type TPersonCombinerStrategyOptions, PersonCombiner };
