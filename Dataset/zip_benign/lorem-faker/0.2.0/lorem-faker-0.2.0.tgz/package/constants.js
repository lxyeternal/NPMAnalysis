/** Алфавит. */
const alphabet = Object.freeze(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']);
/** Оригинальный `Lorem ipsum ...` */
const loremIpsum = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.';
/** Максимальная и максимальная длина слова в `Lorem ipsum ...` */
const loremImsumWordLengths = Object.freeze({
    min: 2,
    max: 13
});
/** Доступные длины слов `Lorem ipsum ...` */
const availableLoremIpsumLengths = Object.freeze([2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]);
/**
 * Список всех слов `Lorem ipsum ...` в нижнем регистре.
 */
const loremIpsumWords = (() => {
    const set = new Set(loremIpsum.replace(/\.$/, '').split(/[\s,.]+/g).map((s) => s.toLowerCase()));
    return Object.freeze([...set]);
})();
/**
 * Структура всех наборов {@link TLoremIpsumSet} сопоставленная с длиной слов `Lorem ipsum ...`.
 */
const loremIpsumMap = (() => {
    // Подготавливаем структуру
    const map = new Map();
    for (const word of loremIpsumWords) {
        const length = word.length;
        const set = map.get(length);
        if (set) {
            set.add(word);
        }
        else {
            map.set(length, new Set([word]));
        }
    }
    const liMap = {};
    for (const [length, set] of map) {
        const words = Object.freeze([...set]);
        const count = words.length;
        liMap[length] = Object.freeze({ length, count, words });
    }
    return Object.freeze(liMap);
})();
export { alphabet, loremIpsum, loremImsumWordLengths, availableLoremIpsumLengths, loremIpsumWords, loremIpsumMap };
