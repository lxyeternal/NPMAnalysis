import type { TRange, TMinMax } from './types.js';
import { type TLoremIpsumWordLength } from './constants.js';
/** Параметры по умолчанию для генерации предложений и параграфов. */
declare const loremIpsumDefaultOptions: Readonly<{
    readonly sentence: Readonly<{
        readonly min: 40;
        readonly max: 200;
    }>;
    readonly paragraph: Readonly<{
        readonly min: 200;
        readonly max: 800;
    }>;
    readonly commaProbability: 0.2;
}>;
/**
 * Опции генератора. По умолчанию {@link loremIpsumDefaultOptions}.
 *
 *   + `sentence`  - Диапазон длины предложения. Не может быть менее `3`.
 *   + `paragraph` - Диапазон длины параграфа. Не может быть менее `3`.
 *   + `commaProbability` - Вероятность появления запятой в диапазоне `0 - 1`.
 */
type TLoremIpsumOptions = {
    sentence: TMinMax;
    paragraph: TMinMax;
    commaProbability: number;
};
/**
 * Валидирует допустимый диапазон для генерации текста `Lorem ipsum ...`.
 *
 * @param defaultMinMax Параметры по умолчанию.
 * @param min Предполагаемое значение не менее `3`.
 * @param max Предполагаемое значение не менее `3`.
 */
declare function validateLoremRange(defaultMinMax: typeof loremIpsumDefaultOptions['sentence' | 'paragraph'], min?: undefined | null | number, max?: undefined | null | number): TRange;
/**
 * Случайное слово из набора {@link loremIpsumWords}.
 */
declare function word(): string;
/**
 * Генерирует схему предложения не учитывая точку.
 *
 * @param length           Требуемая длина предложения. Не может быть менее `2`.
 * @param commaProbability Вероятность появления запятой. Не может быть менее `0` и более `1`.
 * @returns Возвращает массив индексов или `0`, если после слова идет запятая, структуры {@link TLoremIpsumMap}.
 */
declare function generateSentenceBlueprint(length: 2 | number, commaProbability: 0 | number | 1): (0 | TLoremIpsumWordLength)[];
/**
 * Генерация предложения с фиксированной длиной из слов набора {@link loremIpsumWords}.
 *
 * @param length           Требуемая длина предложения. Значение должно быть валидным и не может быть менее `3`.
 * @param commaProbability Вероятность появления запятой. Не может быть менее `0` и более `1`.
 */
declare function generateSentence(length: 3 | number, commaProbability: 0 | number | 1): string;
/**
 * Предложение состоящее из слов набора {@link loremIpsumWords}.
 *
 * @param min Минимальное количество символов. Не может быть менее `3`.
 *            Если не указано, используется значение диапазона {@link TSentenceOptions}.
 * @param max Максимальное количество символов. Не может быть менее `min`.
 * @param commaProbability Вероятность появления запятой. Не может быть менее `0` и более `1`.
 */
declare function sentence(min?: undefined | null | 3 | number, max?: undefined | null | 3 | number, commaProbability?: undefined | null | 0 | number | 1): string;
/**
 * Генерирует схему параграфа.
 *
 * @param length Требуемая длина параграфа. Не может быть менее `3`.
 * @param min    Желаемая минимальная длина предложения. Не может быть менее `3`.
 * @param max    Желаемая максимальна длина предложения. Не может быть менее `min`.
 * @returns      Возвращает массив количества символов в предложении от `3` и более, учитывая что между предложениями
 *               будут установлены пробелы.
 */
declare function generateParagraphBlueprint(length: 3 | number, min: 3 | number, max: 3 | number): number[];
/**
 * Генерация параграфа с фиксированной длиной из слов набора {@link loremIpsumWords}.
 *
 * @param length Требуемая длина параграфа. Значение должно быть валидным и не может быть менее `3`.
 * @param min    Желаемая минимальная длина предложения. Не может быть менее `3`.
 * @param max    Желаемая максимальна длина предложения. Не может быть менее `min`.
 * @param commaProbability Вероятность появления запятой. Не может быть менее `0` и более `1`.
 */
declare function generateParagraph(length: 3 | number, min: 3 | number, max: 3 | number, commaProbability: 0 | number | 1): string;
/**
 * Несколько предложений(параграф) состоящих из слов набора {@link loremIpsumWords}.
 *
 * @param min Минимальное количество символов. Не может быть менее `3`.
 *            Если не указано, используется случайное значение диапазона {@link TParagraphOptions}.
 * @param max Максимальное количество символов. Не может быть менее `min`.
 *
 * Длина предложений расчитывается параметрами по умолчанию {@link TSentenceOptions}.
 */
declare function paragraph(min?: undefined | null | number, max?: undefined | null | number): string;
/**
 * Несколько параграфов состоящих из слов набора {@link loremIpsumWords}.
 *
 * @param num Точное количество параграфов. Не может быть менее `0`.
 *
 * Количество символов параграфа и предложений расчитываются параметрами по умолчанию {@link loremIpsumDefaultOptions}.
 */
declare function post(num: number): string[];
/**
 * Генерирует фейковый текст из набора слов `Lorem ipsum ...`.
 */
declare class LoremGenerator {
    protected readonly _sentenceRange: Readonly<TRange>;
    protected readonly _paragraphRange: Readonly<TRange>;
    protected readonly _commaProbability: number;
    constructor(options?: undefined | null | Partial<TLoremIpsumOptions>);
    word(): string;
    sentence(): string;
    paragraph(): string;
    post(num: number): string[];
}
export { loremIpsumDefaultOptions, type TLoremIpsumOptions, validateLoremRange, word, generateSentenceBlueprint, generateSentence, sentence, generateParagraphBlueprint, generateParagraph, paragraph, post, LoremGenerator };
