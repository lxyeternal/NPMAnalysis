import { isNumber, randomInt, validateProbabilityValue, RatioGenerator } from './utils.js';
import { maleNames } from './maleNames.js';
import { femaleNames } from './femaleNames.js';
import { surnames } from './surnames.js';
import { mailSuffix } from './domains.js';
import { NumGenerator } from './num.js';
import { PersonCombiner } from './combiner.js';
function validateAge(min, max) {
    if (!isNumber(min)) {
        min = 20;
    }
    else if (!Number.isInteger(min)) {
        min = Math.max(Math.round(min), 0);
    }
    else if (min < 0) {
        min = 0;
    }
    if (!isNumber(max)) {
        max = 80;
    }
    else if (!Number.isInteger(max)) {
        max = Math.round(max);
    }
    return [min, Math.max(min, max)];
}
/**
 * Случайное имя пользователя из набора {@link maleNames}.
 */
function maleName() {
    return maleNames[randomInt(0, maleNames.length - 1)];
}
/**
 * Случайное имя пользователя из набора {@link femaleNames}.
 */
function femaleName() {
    return femaleNames[randomInt(0, femaleNames.length - 1)];
}
/**
 * Случайное имя пользователя из набора {@link surname}.
 */
function surname() {
    return surnames[randomInt(0, surnames.length - 1)];
}
/**
 * Случайное имя пользователя: `FirstName`.
 *
 * @param maleOrFemale Использовать ли таблицу на основе гендера:
 *                       + `1` - male
 *                       + `2` - female
 */
function name(maleOrFemale) {
    if (maleOrFemale !== 1 && maleOrFemale !== 2) {
        maleOrFemale = randomInt(1, 2);
    }
    return maleOrFemale === 1 ? maleName() : femaleName();
}
/**
 * Случайное имя пользователя: `FirstName LastName`.
 *
 * @param maleOrFemale Использовать ли таблицу на основе гендера:
 *                       + `1` - male
 *                       + `2` - female
 */
function fullName(maleOrFemale) {
    if (maleOrFemale !== 1 && maleOrFemale !== 2) {
        maleOrFemale = randomInt(1, 2);
    }
    return `${maleOrFemale === 1 ? maleName() : femaleName()} ${surname()}`;
}
/**
 * Случайная почта пользователя.
 *
 * @param personName Если указано, будет добавлено до символа `@`.
 */
function email(personName) {
    if (personName) {
        personName = personName.replaceAll(/\s+/g, '.');
    }
    else {
        personName = `${name()}.${surname()}`;
    }
    return `${personName.toLowerCase()}${mailSuffix()}`;
}
class PersonGeneratorContext {
    _id = null;
    _name = null;
    _gender = null;
    _surname = null;
    _login = null;
    _email = null;
    _age = null;
    _parent;
    _index;
    _idCounter;
    constructor(parent, index, idCounter) {
        this._parent = parent;
        this._index = index;
        this._idCounter = idCounter;
    }
    index() {
        return this._index;
    }
    id() {
        return this._id ?? (this._id = this._idCounter.next());
    }
    name() {
        if (!this._name) {
            [this._name, this._gender] = this._parent.name();
        }
        return this._name;
    }
    surname() {
        return this._surname ?? (this._surname = this._parent.surname());
    }
    fullName() {
        return `${this.name()} ${this.surname()}`;
    }
    login() {
        return this._login ?? (this._login = this._parent.login(this.name(), this.surname()));
    }
    email() {
        return this._email ?? (this._email = this._parent.email(this.name(), this.surname()));
    }
    gender() {
        if (!this._gender) {
            this._parent.name();
        }
        return this._gender;
    }
    age() {
        return this._age ?? (this._age = this._parent.age());
    }
}
/**
 * Генератор фейковых имен, электронной почты и других полей.
 */
class PersonGenerator {
    _gender;
    _ageRange;
    _combiner;
    constructor(options) {
        this._gender = new RatioGenerator(true, false, validateProbabilityValue(options?.genderRatio, 0.5));
        this._ageRange = Object.freeze(validateAge(options?.ageRange?.min, options?.ageRange?.max));
        this._combiner = new PersonCombiner(options?.strategy);
    }
    name() {
        return this._gender.next() ? [maleName(), 'male'] : [femaleName(), 'female'];
    }
    surname() {
        return surname();
    }
    login(first, second) {
        return this._combiner.next(first, second, false);
    }
    email(first, second) {
        return this._combiner.next(first, second, true);
    }
    age() {
        return randomInt(...this._ageRange);
    }
    /**
     * Возвращает итерируем объект с доступом к контексту получения пользовательских данных с уникальными `login` и `email`.
     *
     * @param num Требуемое количество итераций.
     */
    *generate(num) {
        this.reset();
        if (!isNumber(num) || (num = Math.round(num)) < 1) {
            return;
        }
        const idCounter = new NumGenerator(num, null, 1);
        for (let i = 0; i < num; ++i) {
            yield new PersonGeneratorContext(this, i, idCounter);
        }
    }
    /**
     * Сбросить кешированные данные
     */
    reset() {
        this._combiner.reset();
    }
}
export { maleName, femaleName, surname, name, fullName, email, PersonGeneratorContext, PersonGenerator };
