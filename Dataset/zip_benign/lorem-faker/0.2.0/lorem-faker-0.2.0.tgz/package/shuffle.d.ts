/**
 * Возвращает константные ключи предопределенного набора в случайном порядке с примерным соотношением возможных
 * выпадений и точным количеством раз.
 */
declare class ShuffledKeyGenerator<K> {
    protected readonly _initial: readonly (readonly [K, bigint])[];
    protected readonly _pairs: [number, K, bigint][];
    protected readonly _length: number;
    /**
     * @param pairs Пары `[Key, num]`, где второе значение точно указывает максимальное количество раз выпадения ключа
     *              пока все наборы не будут исчерпаны. Попросту говоря набор `[[A, 7], [B, 3], [C, 0]]` возвратит `7`
     *              раз ключ `A`, `3` раза ключ `B` и ни одного раза `C`, после чего цикл восстанавливается.
     */
    constructor(pairs: readonly ([K, (number | bigint)] | readonly [K, number | bigint])[]);
    get length(): number;
    protected _calculateNumberProbabilities(pairs: readonly (readonly [K, bigint])[]): void;
    protected _removeIndex(index: number): void;
    protected _decrementByIndex(index: number): void;
    next(): K;
    reset(): void;
}
export { ShuffledKeyGenerator };
