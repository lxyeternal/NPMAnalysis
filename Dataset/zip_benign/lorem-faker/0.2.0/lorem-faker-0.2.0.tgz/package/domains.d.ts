/** Популярные и наиболее встречающиеся доменные имена первого уровня. */
declare const topLevelDomains: readonly ["com", "net", "org", "io", "info"];
/** Популярные и наиболее встречающиеся доменные имена первого уровня. */
type TTopLevelDomain = (typeof topLevelDomains)[number];
/** Несуществующие домены [rfc2606](https://datatracker.ietf.org/doc/html/rfc2606) для генерации фейковой почты. */
declare const safeMailDomains: readonly ["@example.com", "@example.net", "@example.org", "@mail.test", "@mail.example"];
/** Несуществующие домены [rfc2606](https://datatracker.ietf.org/doc/html/rfc2606) для генерации фейковой почты. */
type TSafeMailDomain = (typeof safeMailDomains)[number];
/**
 * Случайное популярно доменное имя первого уровня.
 */
declare function tld(): TTopLevelDomain;
/**
 * Случайное доменное имя второго уровня.
 *
 * Для генерации фейковых доменов используются защищенные [TLDs .test/.example](https://datatracker.ietf.org/doc/html/rfc2606).
 */
declare function domain(): string;
/**
 * Случаное защищенное доменное имя с префиксом `@*` для генерации почтового адреса.
 */
declare function mailSuffix(): TSafeMailDomain;
export { topLevelDomains, type TTopLevelDomain, safeMailDomains, type TSafeMailDomain, tld, domain, mailSuffix };
