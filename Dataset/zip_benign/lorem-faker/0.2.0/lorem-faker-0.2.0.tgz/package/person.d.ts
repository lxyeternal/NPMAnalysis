import type { TMinMax, TRange } from './types.js';
import { RatioGenerator } from './utils.js';
import { NumGenerator } from './num.js';
import { type TPersonCombinerStrategyOptions, PersonCombiner } from './combiner.js';
/**
 * Случайное имя пользователя из набора {@link maleNames}.
 */
declare function maleName(): string;
/**
 * Случайное имя пользователя из набора {@link femaleNames}.
 */
declare function femaleName(): string;
/**
 * Случайное имя пользователя из набора {@link surname}.
 */
declare function surname(): string;
/**
 * Случайное имя пользователя: `FirstName`.
 *
 * @param maleOrFemale Использовать ли таблицу на основе гендера:
 *                       + `1` - male
 *                       + `2` - female
 */
declare function name(maleOrFemale?: undefined | null | 0 | 1 | 2): string;
/**
 * Случайное имя пользователя: `FirstName LastName`.
 *
 * @param maleOrFemale Использовать ли таблицу на основе гендера:
 *                       + `1` - male
 *                       + `2` - female
 */
declare function fullName(maleOrFemale?: undefined | null | 0 | 1 | 2): string;
/**
 * Случайная почта пользователя.
 *
 * @param personName Если указано, будет добавлено до символа `@`.
 */
declare function email(personName?: undefined | null | string): string;
/**
 * Опции генератора {@link PersonGenerator}.
 *
 *   + `genderRatio` - Соотношение гендера. От этой опции зависит частота генерируемых имен.
 *   + `ageRange` - Возрастной диапазон.
 */
type TPersonOptions = {
    /** Пример: `0.4` - 4 male и 6 female */
    genderRatio?: undefined | null | 0 | number | 1;
    /** Возрастной диапазон */
    ageRange?: undefined | null | TMinMax;
    /** Смотри {@link TPersonCombinerStrategyOptions} */
    strategy?: undefined | null | TPersonCombinerStrategyOptions;
};
type TGender = 'male' | 'female';
declare class PersonGeneratorContext {
    protected _id: null | number;
    protected _name: null | string;
    protected _gender: null | TGender;
    protected _surname: null | string;
    protected _login: null | string;
    protected _email: null | string;
    protected _age: null | number;
    protected readonly _parent: PersonGenerator;
    protected readonly _index: number;
    protected readonly _idCounter: NumGenerator;
    constructor(parent: PersonGenerator, index: number, idCounter: NumGenerator);
    index(): number;
    id(): number;
    name(): string;
    surname(): string;
    fullName(): string;
    login(): string;
    email(): string;
    gender(): TGender;
    age(): number;
}
/**
 * Генератор фейковых имен, электронной почты и других полей.
 */
declare class PersonGenerator {
    protected readonly _gender: RatioGenerator<boolean>;
    protected readonly _ageRange: Readonly<TRange>;
    protected readonly _combiner: PersonCombiner;
    constructor(options?: undefined | null | TPersonOptions);
    name(): [string, TGender];
    surname(): string;
    login(first: string, second: string): string;
    email(first: string, second: string): string;
    age(): number;
    /**
     * Возвращает итерируем объект с доступом к контексту получения пользовательских данных с уникальными `login` и `email`.
     *
     * @param num Требуемое количество итераций.
     */
    generate(num: number): Generator<PersonGeneratorContext, void, undefined>;
    /**
     * Сбросить кешированные данные
     */
    reset(): void;
}
export { maleName, femaleName, surname, name, fullName, email, type TPersonOptions, type TGender, PersonGeneratorContext, PersonGenerator };
