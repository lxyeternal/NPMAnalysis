import { NumTupleGenerator } from './num.js';
type _Num = {
    readonly isNum: true;
    readonly index: number;
    readonly offset: number;
    readonly size: number;
    readonly length: number;
};
type _Text = {
    readonly isNum: false;
    readonly text: string;
};
/**
 * Формат телефона по умолчанию.
 */
declare const defaultPhoneFormat = "+0({450-499}){10-999}-{10-99}-{10-99}";
declare function parsePhoneTemplate(template: string): (_Num | _Text)[];
/**
 * Генератор телефонного номера.
 */
declare class PhoneGenerator {
    protected readonly _gen: NumTupleGenerator<number[]>;
    protected readonly _parts: readonly (_Text | _Num)[];
    /**
     * @param format Формат телефонного номера.
     */
    constructor(format?: undefined | null | string);
    get maxCombinations(): bigint;
    /**
     * Возвращает следующий доступный номер.
     */
    next(): string;
    /**
     * Возвращает итерируем объект получения уникальных телефонных номеров.
     *
     * @param num Требуемое количество итераций.
     */
    generate(num: number): Generator<string, void, undefined>;
    /**
     * Сбрасывает счетчик номеров.
     */
    reset(): void;
}
/**
 * Случайный телефон в простом формате `+0(999)999-99-99`.
 *
 * Для любого формата и множества уникальных номеров используйте класс {@link PhoneGenerator}.
 */
declare function phone(): string;
export { defaultPhoneFormat, parsePhoneTemplate, PhoneGenerator, phone };
