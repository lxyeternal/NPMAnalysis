import type { TRange } from './types.js';
declare const re: {
    _onlyLettersLowerCase: RegExp;
    readonly onlyLettersLowerCase: RegExp;
};
/**
 * Наличие собственного `enumerable` свойства объекта.
 *
 * @param obj Целевой объект.
 * @param key Искомое имя свойства.
 * @returns
 */
declare function hasOwn<T extends object, K extends string | number | symbol>(obj: T, key: K): obj is (T & {
    [_ in K]: K extends keyof T ? T[K] : never;
});
/**
 * Является ли значение `value` объектом.
 */
declare function isObject<T>(value: T): value is (object & T);
/**
 * Является ли значение `value` строкой.
 */
declare function isString(value: any): value is string;
/**
 * Возвращает строку в нижнем регистре усекая крайние пробельные символы или `null`, если строка пуста.
 */
declare function clampStrOrNull(value: any): string | null;
/**
 * Является ли аргумент `value` числом исключая `NaN`.
 */
declare function isNumber(value: any): value is number;
/**
 * Нормализует минимальное и максимальное значение к `int`, возвращая правильную последовательность от `min` до `max`.
 *
 * @param min Минимальное значение, округляется до максимального целого.
 * @param max Максимальное значение, округляется до минимального целого.
 * @returns `normalizeMinMax(12.8, 0.7) // [0, 13]`
 */
declare function normalizeMinMax(min: number, max: number): TRange;
/**
 * Генерирует случайное число.
 *
 * @param min Минимальное значение.
 * @param max Максимальное значение.
 *
 * Эта функция выполняет то же что и {@link randomInt()}, но нормализует входные параметры.
 */
declare function randomIntSafe(min: number, max: number): number;
/**
 * Генерирует случайное число.
 *
 * @param min Минимальное значение. Не должно быть больше `max`.
 * @param max Максимальное значение. Не должно быть меньше `min`.
 *
 * Warning: Эта функция не проверяет корректность параметров. Для нормализации и проверки используйте {@link randomIntSafe()}.
 */
declare function randomInt(min: number, max: number): number;
/**
 * Валидирует последовательность диапазонов. Все числа приводятся к `int >= 0`.
 *
 * @param ranges Массив с кортежами `[min , max]` {@link TRange}.
 */
declare function validateRanges(ranges?: undefined | null | readonly (TRange | Readonly<TRange>)[]): TRange[];
/**
 * Количество символов в числе.
 */
declare function countDigits(n: number): number;
/**
 * Валидирует предполагаемое число и возвращает значение от `0` до `1`.
 *
 * @param value Значение предполагаемое для использования в вероятностных методах, которое должно быть в диапазоне `0-1`.
 * @param defaultValue Значение в диапазоне `0-1`.
 */
declare function validateProbabilityValue(value: 0 | any | 1, defaultValue: 0 | number | 1): number;
/**
 * Возвращает случайное число в строковом формате дополняя нулями до требуемой `length`.
 *
 * @param min    Минимальное значение. По умолчанию `0`.
 * @param max    Максимальное значение. По умолчанию максимально возможное из `length`, например : `length:3 -> 999`.
 * @param length Целевая длина строки.
 *
 * ```ts
 * randomIntAsStr(1, null, 4)
 * // => '0048'
 * ```
 */
declare function randomIntAsStr(min: null | number, max: null | number, length: number): string;
/**
 * Приводит первый символ к `toUpperCase()` и остальные к `toLowerCase()`.
 */
declare function capitalize(text: string): string;
/**
 * Вычисляет значения для **Shuffled Frog-Leaping Algorithm**.
 *
 * @param size Диапазон генерируемых значений. Ноль вернет `[0, 0]`.
 *             Значение `10` означает: что генерируются числа от `0` до `9`.
 * @param step Необязательный желаемый шаг.
 * @returns    Возвращает кортеж `[size, step]`.
 */
declare function calculatePrimeForSfl(size: number, step?: undefined | null | number): [number, number];
/**
 * Вычисляет значения для **Shuffled Frog-Leaping Algorithm**.
 *
 * @param size Диапазон генерируемых значений. `size < 1n` вернет `[0, 0]`.
 *             Значение `10` означает: что генерируются числа от `0` до `9`.
 * @param fraction Знаменатель который будет применен для начального состояния поиска `size - (size / fraction)`.
 *                 Не может быть менее `2`. По умолчанию `8`.
 * @returns Возвращает кортеж `[size, prime]`.
 */
declare function calculateBigintCoPrimeForSfl(size: bigint, fraction?: undefined | null | number): [bigint, bigint];
/**
 * Генерирует все перестановки элементов от `0` до `n-1`.
 *
 * @param num Количество элементов.
 * @returns   Возвращает только полные перестановки длиной `num:2 -> [[0, 1], [1, 0]]`.
 */
declare function generatePermutations(num: number): number[][];
/**
 * Возвращает массив всех возможных комбинаций в диапазоне от `0` до `num - 1`.
 *
 * @param num Для числа `2` будет сгенерирован массив `[[0], [0, 1], [1], [1, 0]]`.
 * @param minComboSize Минимальный размер комбинации. Например `2` удалит комбинации с одним элементом.
 */
declare function generateCombinations(num: number, minComboSize?: undefined | null | 1 | number): number[][];
/**
 * Генерирует одно из двух значений в желаемом соотношении вероятности.
 */
declare class RatioGenerator<T> {
    protected readonly _first: T;
    protected readonly _second: T;
    protected readonly _ratio: number;
    /**
     * @param first  Первое значение.
     * @param second Второе значение.
     * @param ratio  Коэффициент желаемого вероятностного выпадения `first` относительно `second` в диапазоне `0 - 1`.
     */
    constructor(first: T, second: T, ratio: 0 | number | 1);
    get ratio(): 0 | number | 1;
    next(): T;
}
export { re };
export { hasOwn, isObject, isString, clampStrOrNull, isNumber, randomInt, normalizeMinMax, randomIntSafe, validateRanges, countDigits, validateProbabilityValue, randomIntAsStr, capitalize, calculatePrimeForSfl, calculateBigintCoPrimeForSfl, generatePermutations, generateCombinations, RatioGenerator };
