import { ShuffledKeyGenerator } from './shuffle.js';
/**
 * Параметры генератора.
 *
 * Параметры должны быть валидными и расчитываться функцией {@link calculatePrimeForSfl()}
 */
type TNumGeneratorOptions = {
    size: number;
    prime: number;
    offset?: undefined | null | number;
};
/**
 * Генератор чисел на основе **Shuffled Frog-Leaping Algorithm**.
 */
declare class NumGenerator {
    protected readonly _size: number;
    protected readonly _prime: number;
    protected readonly _offset: number;
    protected _counter: number;
    /**
     * @param size   Верхняя граница генерируемого значения минус один. Не может быть менее `1`.
     *               Значение `10` означает генерацию чисел от `0` до `9`.
     *               Если это объект {@link TNumGeneratorOptions}, остальные параметры игнорируются и `{size, prime}`
     *               должны быть рассчитаны функцией {@link calculatePrimeForSfl}.
     * @param step   Желаемый, но не гарантированный, шаг. С этого числа производится попытка найти `GCD` для генератора.
     * @param offset Если задано, то будет добавлено к генерируемым значениям.
     */
    constructor(size: TNumGeneratorOptions);
    constructor(size: number, step?: undefined | null | number, offset?: undefined | null | number);
    get size(): number;
    get prime(): number;
    get offset(): number;
    get counter(): number;
    /**
     * Проверяет, будет ли следующее значение уникальным или начнется новый круг итераций.
     */
    canNext(): boolean;
    /**
     * Возвращает следующее число не увеличивая счетчик.
     */
    peek(): number;
    /**
     * Возвращает следующее число.
     */
    next(): number;
    /**
     * Сбрасывает счетчик генератора.
     */
    reset(): void;
    _internalSetCounter(value: number): void;
}
interface IDecoder<T extends readonly number[]> {
    values: T;
    decode(currentState: bigint): void;
    reset(): void;
}
/**
 * Генератор фиксированной последовательности числовых значений в заданных диапазонах.
 *
 * Warning: Реализация основана на `bigint` и вычисляет `GCD` суммируя размерности ячеек для максимально возможного
 * количества комбинаций.
 *
 * Установите параметр типа для комфортного получения и использования `tuple` требуемой длины. Длина `tuple` должна
 * соответствовать длине массива передаваемого в параметры конструктора.
 */
declare class NumTupleGenerator<T extends number[]> {
    protected readonly _sizes: readonly number[];
    protected readonly _size: bigint;
    protected readonly _prime: bigint;
    protected readonly _decoder: IDecoder<T>;
    protected _counter: bigint;
    /**
     * @param sizes Каждый элемент массива означает максимальное значение ячейки минус один. То есть число `8` будет
     *              генерировать диапазон от `0` до `7`. Числа `0|1` не имеют эффекта и возвращают `0`.
     */
    constructor(sizes: readonly number[]);
    get sizes(): readonly number[];
    get size(): bigint;
    get counter(): bigint;
    /**
     * Проверяет, есть ли следующая уникальная комбинация.
     */
    canNext(): boolean;
    /**
     * Возвращает следующий кортеж не увеличивая счетчик.
     *
     * Warning: Не изменяйте ячейки массива: последний ссылается на исходный объект и не копируется.
     */
    peek(): Readonly<T>;
    /**
     * Возвращает следующий кортеж.
     *
     * Warning: Не изменяйте ячейки массива: последний ссылается на исходный объект и не копируется.
     */
    next(): Readonly<T>;
    /**
     * Сбрасывает счетчик в нулевое состояние.
     */
    reset(): void;
}
/**
 * Генератор последовательности числовых значений в заданных диапазонах и с перетасовкой индексов.
 *
 * Warning: Реализация основана на `bigint` и вычисляет `GCD` суммируя размерности ячеек для максимально возможного
 * количества комбинаций.
 *
 * Установите параметр типа для комфортного получения и использования `tuple` требуемой длины.
 */
declare class NumMultiGeneratorBase<T extends number[]> {
    protected readonly _generators: readonly (readonly [readonly number[], NumTupleGenerator<T>])[];
    protected readonly _selector: ShuffledKeyGenerator<number>;
    protected readonly _size: bigint;
    protected _counter: bigint;
    /**
     * @param sizes Каждый элемент массива означает максимальное значение минус один. То есть число `8` будет
     *              генерировать диапазон от `0` до `7`. Числа `0|1` не имеют эффекта и возвращают `0`.
     * @param permutations Комбинации перестановок индексов `sizes`. Массив должен иметь элементы не менее одного `[index]`
     *                     и не более `sizes.length`. Смотри примеры в тестах.
     */
    constructor(sizes: readonly number[], permutations: readonly number[][]);
    get size(): bigint;
    get counter(): bigint;
    /**
     * Проверяет, есть ли следующая уникальная комбинация.
     */
    canNext(): boolean;
    /**
     * Возвращает следующее состояние генератора.
     *
     * + Первый массив кортежа содержит перетасованные индексы второго кортежа.
     * + Второй массив кортежа содержит сгенерированное значение диапазона.
     *
     * ```ts
     * const [indexes, values] = gen.nex()
     * // indexes [0, 2, 1]
     * // values  [45, 2, 87]
     * ```
     *
     * Warning: Не изменяйте ячейки массива: последний ссылается на исходный объект и не копируется.
     */
    next(): [Readonly<T>, Readonly<T>];
    /**
     * Сбрасывает счетчик в нулевое состояние.
     */
    reset(): void;
}
/**
 * Генератор фиксированной последовательности числовых значений в заданных диапазонах и с перетасовкой индексов.
 *
 * Warning: Реализация основана на `bigint` и вычисляет `GCD` суммируя размерности ячеек для максимально возможного
 * количества комбинаций.
 *
 * Установите параметр типа для комфортного получения и использования `tuple` требуемой длины. Длина `tuple` должна
 * соответствовать длине массива передаваемого в параметры конструктора.
 */
declare class NumPermutationGenerator<T extends number[]> extends NumMultiGeneratorBase<T> {
    constructor(sizes: readonly number[]);
}
/**
 * Генератор последовательности числовых значений в заданных диапазонах с перетасовкой индексов и всех возможных
 * комбинаций: `[0, 1, 2], [1, 2], [1], ...`
 *
 * Warning: Реализация основана на `bigint` и вычисляет `GCD` суммируя размерности ячеек для максимально возможного
 * количества комбинаций.
 */
declare class NumCombinationGenerator extends NumMultiGeneratorBase<number[]> {
    /**
     * @param sizes Каждый элемент массива означает максимальное значение минус один. То есть число `8` будет
     *              генерировать диапазон от `0` до `7`. Числа `0|1` не имеют эффекта и возвращают `0`.
     * @param minComboSize Минимальный размер комбинации. Например `2` удалит комбинации с одним элементом.
     */
    constructor(sizes: readonly number[], minComboSize?: undefined | null | 1 | number);
}
export { type TNumGeneratorOptions, NumGenerator, NumMultiGeneratorBase, NumTupleGenerator, NumPermutationGenerator, NumCombinationGenerator };
