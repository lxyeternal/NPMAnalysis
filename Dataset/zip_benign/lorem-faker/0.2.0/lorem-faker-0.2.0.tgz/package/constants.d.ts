/** Алфавит. */
declare const alphabet: readonly ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];
/** Алфавит. */
type TAlphabet = typeof alphabet;
/** Оригинальный `Lorem ipsum ...` */
declare const loremIpsum = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
/** Максимальная и максимальная длина слова в `Lorem ipsum ...` */
declare const loremImsumWordLengths: Readonly<{
    min: 2;
    max: 13;
}>;
/** Доступные длины слов `Lorem ipsum ...` */
declare const availableLoremIpsumLengths: readonly [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];
/** Возможная длина слова в `Lorem ipsum ...` */
type TLoremIpsumWordLength = (typeof availableLoremIpsumLengths)[number];
/**
 * Список всех слов `Lorem ipsum ...` в нижнем регистре.
 */
declare const loremIpsumWords: readonly string[];
/**
 * Структура набора слов с одной длиной в `Lorem ipsum ...`.
 */
type TLoremIpsumSet<K extends TLoremIpsumWordLength = TLoremIpsumWordLength> = {
    /** Длина слова */
    readonly length: K;
    /** Количество слов */
    readonly count: number;
    /** Список слов */
    readonly words: readonly string[];
};
/**
 * Структура всех наборов {@link TLoremIpsumSet} сопоставленная с длиной слов `Lorem ipsum ...`.
 */
type TLoremIpsumMap = {
    readonly [K in TLoremIpsumWordLength]: TLoremIpsumSet<K>;
};
/**
 * Структура всех наборов {@link TLoremIpsumSet} сопоставленная с длиной слов `Lorem ipsum ...`.
 */
declare const loremIpsumMap: TLoremIpsumMap;
export { alphabet, type TAlphabet, loremIpsum, loremImsumWordLengths, availableLoremIpsumLengths, type TLoremIpsumWordLength, loremIpsumWords, type TLoremIpsumSet, type TLoremIpsumMap, loremIpsumMap };
