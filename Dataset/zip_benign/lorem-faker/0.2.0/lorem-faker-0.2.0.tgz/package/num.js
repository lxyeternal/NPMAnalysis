import { isObject, isNumber, calculatePrimeForSfl, calculateBigintCoPrimeForSfl, generatePermutations, generateCombinations } from './utils.js';
import { ShuffledKeyGenerator } from './shuffle.js';
/**
 * Генератор чисел на основе **Shuffled Frog-Leaping Algorithm**.
 */
class NumGenerator {
    _size;
    _prime;
    _offset;
    _counter = 0;
    constructor(size, step, offset) {
        [this._size, this._prime] = isObject(size) ? [size.size, size.prime] : calculatePrimeForSfl(size, step);
        if (isObject(size)) {
            offset = size.offset;
        }
        this._offset = isNumber(offset) ? Math.round(offset) : 0;
    }
    get size() {
        return this._size;
    }
    get prime() {
        return this._prime;
    }
    get offset() {
        return this._offset;
    }
    get counter() {
        return this._counter;
    }
    /**
     * Проверяет, будет ли следующее значение уникальным или начнется новый круг итераций.
     */
    canNext() {
        return this._counter < this._size && this._size > 0;
    }
    /**
     * Возвращает следующее число не увеличивая счетчик.
     */
    peek() {
        // Нет смысла производить вычисление для `(1 * 0|1) % 1`, так как остаток всегда 0
        if (this._size < 2) {
            return this._offset;
        }
        return this._offset + ((this._prime * this._counter) % this._size);
    }
    // current (): number {
    //   if (this._size === 0) {
    //     return this.peek()
    //   }
    //   // Счетчик, который использовался для генерации предыдущего значения
    //   // (т.к. текущий _counter будет использован для следующего значения)
    //   const counter = this._counter - 1
    //   // Вычисляем "сырое" значение для этого предыдущего счетчика
    //   const rawValue = this._prime * counter
    //   // Применяем математически корректный модуль для обработки возможных отрицательных rawValue
    //   const moduloResult = ((rawValue % this._size) + this._size) % this._size
    //   // Добавляем смещение
    //   return this._offset + moduloResult
    // }
    /**
     * Возвращает следующее число.
     */
    next() {
        const value = this.peek();
        if (this._size > 0)
            this._counter++;
        return value;
    }
    /**
     * Сбрасывает счетчик генератора.
     */
    reset() {
        this._counter = 0;
    }
    _internalSetCounter(value) {
        if (this._size > 0) {
            this._counter = value;
        }
    }
}
function decoder(length, n, active) {
    const values = Array.from({ length }).fill(0);
    return {
        get values() {
            return values;
        },
        decode(currentState) {
            if (currentState < 0n || currentState >= n) {
                currentState = ((currentState % n) + n) % n; // Приводим к диапазону [0, n-1]
            }
            for (let i = 0; i < active.length; ++i) {
                const currentActiveSize = active[i][1];
                const value = currentState % currentActiveSize;
                values[active[i][0]] = Number(value);
                // Обновляем оставшееся состояние для следующего счетчика
                currentState = currentState / currentActiveSize;
            }
        },
        reset() {
            values.fill(0);
        }
    };
}
function fakeDecoder(length) {
    return {
        values: Object.freeze(Array.from({ length }).fill(0)),
        decode(_currentState) { },
        reset() { }
    };
}
function preprocessForBigintTupleGenerator(sizes) {
    const normalized = sizes.map((v) => isNumber(v) && v > 0 ? Math.round(v) : 0);
    const active = [];
    let size1 = false;
    let combinationCount = 0n;
    for (let i = 0; i < normalized.length; ++i) {
        const size = BigInt(normalized[i]);
        if (size > 1n) {
            if (combinationCount === 0n) {
                combinationCount = size;
            }
            else {
                combinationCount *= size;
            }
            active.push([i, BigInt(size)]);
        }
        else if (size > 0n) {
            size1 = true;
        }
    }
    const [size, prime] = combinationCount > 0
        ? calculateBigintCoPrimeForSfl(combinationCount)
        : [0n, 0n];
    return {
        sizes: normalized,
        active,
        size,
        prime,
        size1,
        decoder: active.length > 0
            ? decoder(normalized.length, size, active)
            : fakeDecoder(normalized.length)
    };
}
/**
 * Генератор фиксированной последовательности числовых значений в заданных диапазонах.
 *
 * Warning: Реализация основана на `bigint` и вычисляет `GCD` суммируя размерности ячеек для максимально возможного
 * количества комбинаций.
 *
 * Установите параметр типа для комфортного получения и использования `tuple` требуемой длины. Длина `tuple` должна
 * соответствовать длине массива передаваемого в параметры конструктора.
 */
class NumTupleGenerator {
    _sizes;
    _size;
    _prime;
    _decoder;
    _counter = 0n;
    /**
     * @param sizes Каждый элемент массива означает максимальное значение ячейки минус один. То есть число `8` будет
     *              генерировать диапазон от `0` до `7`. Числа `0|1` не имеют эффекта и возвращают `0`.
     */
    constructor(sizes) {
        const params = preprocessForBigintTupleGenerator(sizes);
        this._sizes = Object.freeze(params.sizes);
        this._size = params.size;
        this._prime = params.prime;
        this._decoder = params.decoder;
        if (this._size === 0n && params.size1) {
            this._size = 1n;
        }
    }
    get sizes() {
        return this._sizes;
    }
    get size() {
        return this._size;
    }
    get counter() {
        return this._counter;
    }
    /**
     * Проверяет, есть ли следующая уникальная комбинация.
     */
    canNext() {
        // Размерность 0 никогда не возвращает уникальный элемент.
        // Хотя size:1 не имеет эффекта, функция должна сохранить консистентность и вернуть ожидаемый результат.
        return this._counter < this._size && this._size > 0n;
    }
    // /**
    //  * Возвращает текущее значение генератора.
    //  *
    //  * Warning: Не изменяйте ячейки массива: последний ссылается на исходный объект и не копируется.
    //  */
    // current (): Readonly<T> {
    //   return this._decoder.values
    // }
    /**
     * Возвращает следующий кортеж не увеличивая счетчик.
     *
     * Warning: Не изменяйте ячейки массива: последний ссылается на исходный объект и не копируется.
     */
    peek() {
        // При 0n|1n нет смысла ничего считать
        if (this._size > 1n) {
            const value = ((this._prime * this._counter) % this._size);
            this._decoder.decode(value);
        }
        return this._decoder.values;
    }
    /**
     * Возвращает следующий кортеж.
     *
     * Warning: Не изменяйте ячейки массива: последний ссылается на исходный объект и не копируется.
     */
    next() {
        this.peek();
        if (this._size > 0n)
            this._counter++;
        return this._decoder.values;
    }
    /**
     * Сбрасывает счетчик в нулевое состояние.
     */
    reset() {
        this._counter = 0n;
        this._decoder.reset();
    }
}
/**
 * Генератор последовательности числовых значений в заданных диапазонах и с перетасовкой индексов.
 *
 * Warning: Реализация основана на `bigint` и вычисляет `GCD` суммируя размерности ячеек для максимально возможного
 * количества комбинаций.
 *
 * Установите параметр типа для комфортного получения и использования `tuple` требуемой длины.
 */
class NumMultiGeneratorBase {
    _generators;
    _selector;
    _size;
    _counter = 0n;
    /**
     * @param sizes Каждый элемент массива означает максимальное значение минус один. То есть число `8` будет
     *              генерировать диапазон от `0` до `7`. Числа `0|1` не имеют эффекта и возвращают `0`.
     * @param permutations Комбинации перестановок индексов `sizes`. Массив должен иметь элементы не менее одного `[index]`
     *                     и не более `sizes.length`. Смотри примеры в тестах.
     */
    constructor(sizes, permutations) {
        // Проходимся по комбинациям и оборачиваем в кортеж NumTupleGenerator
        const gen = [];
        let minLength = sizes.length;
        for (const arrayIndexes of permutations) {
            const ins = new NumTupleGenerator(arrayIndexes.map((i) => sizes[i]));
            const frozen = Object.freeze([...arrayIndexes]);
            // Несмотря на то что size=1 не генерирует, а возвращает одни нули, здесь мы используем перестановки,
            // поэтому два элемента с размером 1 дадут [0, 1] + [1, 0] два варианта, такие генераторы сохраняем
            if (ins.size > 0) {
                gen.push([frozen, ins]);
            }
            minLength = Math.min(minLength, frozen.length);
        }
        // Если не создали ни одного генератора создаем фейковый
        if (gen.length === 0) {
            this._generators = [[
                    Object.freeze(Array.from({ length: minLength }, ((_, i) => i))),
                    new NumTupleGenerator(Array.from({ length: minLength }).fill(0))
                ]];
            this._size = 0n;
        }
        else {
            this._generators = gen;
            this._size = this._generators.reduce((a, [_, g]) => (a + g.size), 0n);
        }
        // Выбирает случайный генератор
        this._selector = new ShuffledKeyGenerator(this._generators.map(([_, g], i) => [i, g.size]));
    }
    get size() {
        return this._size;
    }
    get counter() {
        return this._counter;
    }
    /**
     * Проверяет, есть ли следующая уникальная комбинация.
     */
    canNext() {
        return this._counter < this._size && this._size > 0n;
    }
    /**
     * Возвращает следующее состояние генератора.
     *
     * + Первый массив кортежа содержит перетасованные индексы второго кортежа.
     * + Второй массив кортежа содержит сгенерированное значение диапазона.
     *
     * ```ts
     * const [indexes, values] = gen.nex()
     * // indexes [0, 2, 1]
     * // values  [45, 2, 87]
     * ```
     *
     * Warning: Не изменяйте ячейки массива: последний ссылается на исходный объект и не копируется.
     */
    next() {
        const index = this._selector.next();
        if (this._size > 0n) {
            this._counter++;
        }
        // @ts-expect-error
        return [this._generators[index][0], this._generators[index][1].next()];
    }
    /**
     * Сбрасывает счетчик в нулевое состояние.
     */
    reset() {
        this._counter = 0n;
        this._generators.forEach(([_, g]) => g.reset());
        this._selector.reset();
    }
}
/**
 * Генератор фиксированной последовательности числовых значений в заданных диапазонах и с перетасовкой индексов.
 *
 * Warning: Реализация основана на `bigint` и вычисляет `GCD` суммируя размерности ячеек для максимально возможного
 * количества комбинаций.
 *
 * Установите параметр типа для комфортного получения и использования `tuple` требуемой длины. Длина `tuple` должна
 * соответствовать длине массива передаваемого в параметры конструктора.
 */
class NumPermutationGenerator extends NumMultiGeneratorBase {
    constructor(sizes) {
        super(sizes, generatePermutations(sizes.length));
    }
}
/**
 * Генератор последовательности числовых значений в заданных диапазонах с перетасовкой индексов и всех возможных
 * комбинаций: `[0, 1, 2], [1, 2], [1], ...`
 *
 * Warning: Реализация основана на `bigint` и вычисляет `GCD` суммируя размерности ячеек для максимально возможного
 * количества комбинаций.
 */
class NumCombinationGenerator extends NumMultiGeneratorBase {
    /**
     * @param sizes Каждый элемент массива означает максимальное значение минус один. То есть число `8` будет
     *              генерировать диапазон от `0` до `7`. Числа `0|1` не имеют эффекта и возвращают `0`.
     * @param minComboSize Минимальный размер комбинации. Например `2` удалит комбинации с одним элементом.
     */
    constructor(sizes, minComboSize) {
        super(sizes, generateCombinations(sizes.length, minComboSize));
    }
}
export { NumGenerator, NumMultiGeneratorBase, NumTupleGenerator, NumPermutationGenerator, NumCombinationGenerator };
