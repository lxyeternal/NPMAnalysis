/**
 * Возвращает константные ключи предопределенного набора в случайном порядке с примерным соотношением возможных
 * выпадений и точным количеством раз.
 */
class ShuffledKeyGenerator {
    _initial;
    _pairs = [];
    _length = -1; // переустановится в конструкторе
    /**
     * @param pairs Пары `[Key, num]`, где второе значение точно указывает максимальное количество раз выпадения ключа
     *              пока все наборы не будут исчерпаны. Попросту говоря набор `[[A, 7], [B, 3], [C, 0]]` возвратит `7`
     *              раз ключ `A`, `3` раза ключ `B` и ни одного раза `C`, после чего цикл восстанавливается.
     */
    constructor(pairs) {
        const toBigint = (v) => {
            v = (typeof v === 'bigint' ? v : BigInt(v));
            return v < 0n ? 0n : v;
        };
        this._initial = Object.freeze(pairs.map(([k, v]) => Object.freeze([k, toBigint(v)])));
        this.reset();
    }
    get length() {
        return this._length;
    }
    _calculateNumberProbabilities(pairs) {
        const totalWeightBigInt = pairs.reduce((a, [_, w]) => a + w, 0n);
        const temp = [];
        let factor = 1n;
        let totalBigint;
        while ((totalBigint = totalWeightBigInt / factor) > Number.MAX_SAFE_INTEGER) {
            factor *= 10n;
        }
        const total = Number(totalBigint);
        for (let i = 0; i < pairs.length; ++i) {
            const [k, w] = pairs[i];
            if (w > 0) {
                temp.push([Number(w / factor) / total, k, w]);
            }
        }
        for (const item of temp) {
            if (item[0] <= 0) {
                item[0] = 0.05;
            }
        }
        if (this._length === -1) {
            // @ts-expect-error
            this._length = temp.length;
        }
        if (temp.length === 0 && pairs.length > 0) {
            temp[0] = [1, pairs[0][0], pairs[0][1]];
        }
        this._pairs.splice(0);
        this._pairs.push(...temp);
    }
    _removeIndex(index) {
        this._pairs.splice(index, 1);
        if (this._pairs.length === 0) {
            this.reset();
        }
        else {
            this._calculateNumberProbabilities(this._pairs.map(([_, k, b]) => [k, b]));
        }
    }
    _decrementByIndex(index) {
        if (--this._pairs[index][2] <= 0n) {
            this._removeIndex(index);
        }
    }
    next() {
        const rand = Math.random();
        let cumulative = 0;
        for (let i = 0; i < this._pairs.length; i++) {
            cumulative += this._pairs[i][0];
            if (rand < cumulative) {
                const next = this._pairs[i][1];
                this._decrementByIndex(i);
                return next;
            }
        }
        if (this._pairs.length > 0) {
            const next = this._pairs[0][1];
            this._decrementByIndex(0);
            return next;
        }
        return null;
    }
    reset() {
        this._pairs.splice(0);
        this._calculateNumberProbabilities(this._initial);
    }
}
export { ShuffledKeyGenerator };
