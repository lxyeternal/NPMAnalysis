## 1.0.6 / 2023-07-27

* `progress-basic` 组件发布