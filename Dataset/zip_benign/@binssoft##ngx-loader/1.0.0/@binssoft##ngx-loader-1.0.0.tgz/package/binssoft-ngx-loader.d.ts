/**
 * Generated bundle index. Do not edit.
 */
export * from './public-api';
export { NgxLoaderComponent as ɵa } from './lib/ngx-loader.component';
export { NgxLoaderInterceptor as ɵb } from './lib/ngx-loader.interceptors';
