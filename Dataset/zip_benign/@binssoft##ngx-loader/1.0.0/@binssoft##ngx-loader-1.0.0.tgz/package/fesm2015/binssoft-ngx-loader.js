import { Injectable, ɵɵdefineInjectable, Component, Input, NgModule } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { delay } from 'rxjs/operators';
import { HttpResponse, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';

/**
 * @fileoverview added by tsickle
 * Generated from: lib/ngx-loader.service.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgxLoaderService {
    constructor() {
        this.isLoading = new BehaviorSubject(false);
        this.skipList = new BehaviorSubject([]);
    }
    /**
     * @param {?=} list
     * @return {?}
     */
    skipMap(list = []) {
        this.skipList.next(list);
    }
}
NgxLoaderService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
/** @nocollapse */
NgxLoaderService.ctorParameters = () => [];
/** @nocollapse */ NgxLoaderService.ngInjectableDef = ɵɵdefineInjectable({ factory: function NgxLoaderService_Factory() { return new NgxLoaderService(); }, token: NgxLoaderService, providedIn: "root" });
if (false) {
    /** @type {?} */
    NgxLoaderService.prototype.isLoading;
    /** @type {?} */
    NgxLoaderService.prototype.skipList;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/ngx-loader.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgxLoaderComponent {
    /**
     * @param {?} loaderService
     */
    constructor(loaderService) {
        this.loaderService = loaderService;
        this.isLoading = true;
        this.config = null;
        this.ngcssBackClass = "";
        this.ngcssSpinnerClass = "";
        this.loaderService.isLoading
            .pipe(delay(0))
            .subscribe((/**
         * @param {?} isLoading
         * @return {?}
         */
        (isLoading) => {
            this.isLoading = isLoading;
        }));
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.ngcssBackClass = "";
        this.ngcssSpinnerClass = "";
        if (this.config && this.config.type == 'bar') {
            if (this.config.theme) {
                this.ngcssBackClass = 'custom-bar';
                document.documentElement.style.setProperty('--custom-back', this.config.theme);
            }
        }
        else {
            if (this.config && this.config.theme && this.config.theme.back) {
                this.ngcssBackClass = 'custom-back';
                this.ngcssSpinnerClass = 'custom-spinner';
                document.documentElement.style.setProperty('--custom-back', this.config.theme.back);
                document.documentElement.style.setProperty('--custom-spinner', this.config.theme.spinner);
            }
        }
    }
}
NgxLoaderComponent.decorators = [
    { type: Component, args: [{
                selector: 'ngx-bins-loader',
                template: "<div class=\"progress-loader\" [hidden]=\"!isLoading\">\r\n    <div class=\"progress-bar\" *ngIf=\"config?.type=='bar'\">\r\n        <div class=\"loader\">\r\n            <div class=\"loaderBar\" [ngClass]=\"ngcssBackClass\"></div>\r\n        </div>\r\n    </div>\r\n    <div class=\"ring-loader loader-container \" *ngIf=\"config?.type=='ring'\" [ngClass]=\"ngcssBackClass\">\r\n        <div class=\"loader spinner\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n    </div>\r\n    <div class=\"line-spinner loader-container \" *ngIf=\"config?.type=='bubble-spinner'\" [ngClass]=\"ngcssBackClass\">\r\n        <div class=\"spinner\">\r\n            <div class=\"bounce1\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n            <div class=\"bounce2\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n            <div class=\"bounce3\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n        </div>\r\n    </div>\r\n    <div class=\"square-loader loader-container \" *ngIf=\"config?.type=='square'\" [ngClass]=\"ngcssBackClass\">\r\n        <div class=\"spinner square\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n    </div>\r\n\r\n    <div class=\"bounce-loader loader-container \" *ngIf=\"config?.type=='bounce'\" [ngClass]=\"ngcssBackClass\">\r\n        <div class=\"spinner\">\r\n            <div class=\"double-bounce1\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n            <div class=\"double-bounce2\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n        </div>\r\n    </div>\r\n\r\n    <div class=\"cube-loader loader-container \" *ngIf=\"config?.type=='cube'\" [ngClass]=\"ngcssBackClass\">\r\n        <div class=\"sk-cube-grid\">\r\n            <div class=\"sk-cube sk-cube1\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n            <div class=\"sk-cube sk-cube2\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n            <div class=\"sk-cube sk-cube3\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n            <div class=\"sk-cube sk-cube4\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n            <div class=\"sk-cube sk-cube5\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n            <div class=\"sk-cube sk-cube6\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n            <div class=\"sk-cube sk-cube7\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n            <div class=\"sk-cube sk-cube8\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n            <div class=\"sk-cube sk-cube9\" [ngClass]=\"ngcssSpinnerClass\"></div>\r\n          </div>\r\n    </div>\r\n    <ng-content></ng-content>\r\n</div>",
                styles: [".loader-container{top:0;left:0;width:100%;height:100%;position:fixed;z-index:999;background-color:rgba(134,134,134,.52)}.loader-container.custom-back{background-color:var(--custom-back)!important}.spinner{position:absolute;z-index:999;top:50%;left:50%}.progress-bar .loader{width:100%;margin:0 auto;border-radius:10px;border:4px solid transparent;position:relative;padding:2px}.progress-bar .loader:before{content:\"\";border:1px solid #fff;border-radius:10px;position:absolute;top:-4px;right:-4px;bottom:-4px;left:-4px}.progress-bar .loader .loaderBar{position:absolute;border-radius:10px;top:0;right:100%;bottom:0;left:0;background:#98a1ce;width:0;-webkit-animation:2s linear infinite borealisBar;animation:2s linear infinite borealisBar}.progress-bar .loader .loaderBar.custom-bar{background:var(--custom-back)!important}@-webkit-keyframes borealisBar{0%{left:0;right:100%;width:0%}10%{left:0;right:75%;width:25%}90%{right:0;left:75%;width:25%}100%{left:100%;right:0;width:0%}}@keyframes borealisBar{0%{left:0;right:100%;width:0%}10%{left:0;right:75%;width:25%}90%{right:0;left:75%;width:25%}100%{left:100%;right:0;width:0%}}.ring-loader .loader{position:absolute;z-index:999;top:50%;left:50%;display:inline-block;width:50px;height:50px;border:3px solid rgba(255,255,255,.3);border-radius:50%;border-top-color:#fff;animation:1s ease-in-out infinite spin;-webkit-animation:1s ease-in-out infinite spin}.ring-loader .loader.custom-spinner{border-top-color:var(--custom-spinner)!important}@keyframes spin{to{-webkit-transform:rotate(360deg)}}@-webkit-keyframes spin{to{-webkit-transform:rotate(360deg)}}.line-spinner{position:fixed;top:0;left:0;width:100%;height:100%}.line-spinner .spinner{width:70px;text-align:center}.line-spinner .spinner>div{width:18px;height:18px;background-color:#333;border-radius:100%;display:inline-block;-webkit-animation:1.4s ease-in-out infinite both sk-bouncedelay;animation:1.4s ease-in-out infinite both sk-bouncedelay}.line-spinner .spinner>div.custom-spinner{background-color:var(--custom-spinner)!important}.line-spinner .spinner .bounce1{-webkit-animation-delay:-.32s;animation-delay:-.32s}.line-spinner .spinner .bounce2{-webkit-animation-delay:-.16s;animation-delay:-.16s}@-webkit-keyframes sk-bouncedelay{0%,100%,80%{-webkit-transform:scale(0)}40%{-webkit-transform:scale(1)}}@keyframes sk-bouncedelay{0%,100%,80%{transform:scale(0)}40%{transform:scale(1)}}.spinner.square{width:40px;height:40px;background-color:#333;-webkit-animation:1.2s ease-in-out infinite sk-rotateplane;animation:1.2s ease-in-out infinite sk-rotateplane}.spinner.square.custom-spinner{background-color:var(--custom-spinner)!important}@-webkit-keyframes sk-rotateplane{0%{-webkit-transform:perspective(120px)}50%{-webkit-transform:perspective(120px) rotateY(180deg)}100%{-webkit-transform:perspective(120px) rotateY(180deg) rotateX(180deg)}}@keyframes sk-rotateplane{0%{transform:perspective(120px) rotateX(0) rotateY(0);-webkit-transform:perspective(120px) rotateX(0) rotateY(0)}50%{transform:perspective(120px) rotateX(-180.1deg) rotateY(0);-webkit-transform:perspective(120px) rotateX(-180.1deg) rotateY(0)}100%{transform:perspective(120px) rotateX(-180deg) rotateY(-179.9deg);-webkit-transform:perspective(120px) rotateX(-180deg) rotateY(-179.9deg)}}.bounce-loader .spinner{width:40px;height:40px;position:relative}.bounce-loader .double-bounce1,.bounce-loader .double-bounce2{width:100%;height:100%;border-radius:50%;background-color:#333;opacity:.6;position:absolute;top:0;left:0;-webkit-animation:2s ease-in-out infinite sk-bounce;animation:2s ease-in-out infinite sk-bounce}.bounce-loader .double-bounce1.custom-spinner,.bounce-loader .double-bounce2.custom-spinner{background-color:var(--custom-spinner)!important}.bounce-loader .double-bounce2{-webkit-animation-delay:-1s;animation-delay:-1s}@-webkit-keyframes sk-bounce{0%,100%{-webkit-transform:scale(0)}50%{-webkit-transform:scale(1)}}@keyframes sk-bounce{0%,100%{transform:scale(0);-webkit-transform:scale(0)}50%{transform:scale(1);-webkit-transform:scale(1)}}.cube-loader .sk-cube-grid{width:40px;height:40px;position:absolute;top:50%;left:50%}.cube-loader .sk-cube-grid .sk-cube{width:33%;height:33%;background-color:#333;float:left;-webkit-animation:1.3s ease-in-out infinite sk-cubeGridScaleDelay;animation:1.3s ease-in-out infinite sk-cubeGridScaleDelay}.cube-loader .sk-cube-grid .sk-cube.custom-spinner{background-color:var(--custom-spinner)!important}.cube-loader .sk-cube-grid .sk-cube1{-webkit-animation-delay:.2s;animation-delay:.2s}.cube-loader .sk-cube-grid .sk-cube2{-webkit-animation-delay:.3s;animation-delay:.3s}.cube-loader .sk-cube-grid .sk-cube3{-webkit-animation-delay:.4s;animation-delay:.4s}.cube-loader .sk-cube-grid .sk-cube4{-webkit-animation-delay:.1s;animation-delay:.1s}.cube-loader .sk-cube-grid .sk-cube5{-webkit-animation-delay:.2s;animation-delay:.2s}.cube-loader .sk-cube-grid .sk-cube6{-webkit-animation-delay:.3s;animation-delay:.3s}.cube-loader .sk-cube-grid .sk-cube7{-webkit-animation-delay:0s;animation-delay:0s}.cube-loader .sk-cube-grid .sk-cube8{-webkit-animation-delay:.1s;animation-delay:.1s}.cube-loader .sk-cube-grid .sk-cube9{-webkit-animation-delay:.2s;animation-delay:.2s}@-webkit-keyframes sk-cubeGridScaleDelay{0%,100%,70%{transform:scale3D(1,1,1)}35%{transform:scale3D(0,0,1)}}@keyframes sk-cubeGridScaleDelay{0%,100%,70%{transform:scale3D(1,1,1)}35%{transform:scale3D(0,0,1)}}"]
            }] }
];
/** @nocollapse */
NgxLoaderComponent.ctorParameters = () => [
    { type: NgxLoaderService }
];
NgxLoaderComponent.propDecorators = {
    config: [{ type: Input }]
};
if (false) {
    /** @type {?} */
    NgxLoaderComponent.prototype.isLoading;
    /** @type {?} */
    NgxLoaderComponent.prototype.config;
    /** @type {?} */
    NgxLoaderComponent.prototype.ngcssBackClass;
    /** @type {?} */
    NgxLoaderComponent.prototype.ngcssSpinnerClass;
    /**
     * @type {?}
     * @private
     */
    NgxLoaderComponent.prototype.loaderService;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/ngx-loader.interceptors.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgxLoaderInterceptor {
    /**
     * @param {?} loaderService
     */
    constructor(loaderService) {
        this.loaderService = loaderService;
        this.requests = [];
    }
    /**
     * @param {?} req
     * @return {?}
     */
    removeRequest(req) {
        /** @type {?} */
        const i = this.requests.indexOf(req);
        if (i >= 0) {
            this.requests.splice(i, 1);
        }
        this.loaderService.isLoading.next(this.requests.length > 0);
    }
    /**
     * @param {?} req
     * @param {?} next
     * @return {?}
     */
    intercept(req, next) {
        this.loaderService.skipList.subscribe((/**
         * @param {?} urlList
         * @return {?}
         */
        (urlList) => {
            if (!urlList || (urlList && !urlList.find((/**
             * @param {?} i
             * @return {?}
             */
            i => req.url.indexOf(i) > -1)))) {
                this.requests.push(req);
                this.loaderService.isLoading.next(true);
            }
        }));
        return Observable.create((/**
         * @param {?} observer
         * @return {?}
         */
        observer => {
            /** @type {?} */
            const subscription = next.handle(req)
                .subscribe((/**
             * @param {?} event
             * @return {?}
             */
            event => {
                if (event instanceof HttpResponse) {
                    this.removeRequest(req);
                    observer.next(event);
                }
            }), (/**
             * @param {?} err
             * @return {?}
             */
            err => {
                this.removeRequest(req);
                observer.error(err);
            }), (/**
             * @return {?}
             */
            () => {
                this.removeRequest(req);
                observer.complete();
            }));
            // remove request from queue when cancelled
            return (/**
             * @return {?}
             */
            () => {
                this.removeRequest(req);
                subscription.unsubscribe();
            });
        }));
    }
}
NgxLoaderInterceptor.decorators = [
    { type: Injectable }
];
/** @nocollapse */
NgxLoaderInterceptor.ctorParameters = () => [
    { type: NgxLoaderService }
];
if (false) {
    /**
     * @type {?}
     * @private
     */
    NgxLoaderInterceptor.prototype.requests;
    /**
     * @type {?}
     * @private
     */
    NgxLoaderInterceptor.prototype.loaderService;
}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/ngx-loader.module.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NgxLoaderModule {
}
NgxLoaderModule.decorators = [
    { type: NgModule, args: [{
                declarations: [NgxLoaderComponent],
                imports: [
                    BrowserModule
                ],
                exports: [NgxLoaderComponent],
                providers: [
                    { provide: HTTP_INTERCEPTORS, useClass: NgxLoaderInterceptor, multi: true }
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * Generated from: public-api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * Generated from: binssoft-ngx-loader.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { NgxLoaderModule, NgxLoaderService, NgxLoaderComponent as ɵa, NgxLoaderInterceptor as ɵb };
//# sourceMappingURL=binssoft-ngx-loader.js.map
