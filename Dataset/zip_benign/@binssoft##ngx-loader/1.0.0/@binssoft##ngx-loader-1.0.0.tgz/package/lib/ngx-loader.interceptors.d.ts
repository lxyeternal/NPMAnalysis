import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { NgxLoaderService } from './ngx-loader.service';
import { Observable } from 'rxjs';
export declare class NgxLoaderInterceptor implements HttpInterceptor {
    private loaderService;
    private requests;
    constructor(loaderService: NgxLoaderService);
    removeRequest(req: HttpRequest<any>): void;
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
}
