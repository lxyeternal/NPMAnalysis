export declare class NgxLoaderModule {
}
