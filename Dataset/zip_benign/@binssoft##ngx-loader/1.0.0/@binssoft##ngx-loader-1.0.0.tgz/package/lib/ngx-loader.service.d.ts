import { BehaviorSubject } from 'rxjs';
export declare class NgxLoaderService {
    isLoading: BehaviorSubject<boolean>;
    skipList: BehaviorSubject<any[]>;
    constructor();
    skipMap(list?: any): void;
}
