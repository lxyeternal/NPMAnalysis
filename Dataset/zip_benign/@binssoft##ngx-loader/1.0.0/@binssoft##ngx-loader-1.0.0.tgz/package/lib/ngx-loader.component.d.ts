import { OnInit } from '@angular/core';
import { NgxLoaderService } from './ngx-loader.service';
export declare class NgxLoaderComponent implements OnInit {
    private loaderService;
    isLoading: boolean;
    config: any;
    ngcssBackClass: any;
    ngcssSpinnerClass: any;
    constructor(loaderService: NgxLoaderService);
    ngOnInit(): void;
}
