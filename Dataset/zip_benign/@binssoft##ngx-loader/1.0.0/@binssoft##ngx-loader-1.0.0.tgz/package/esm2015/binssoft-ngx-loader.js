/**
 * @fileoverview added by tsickle
 * Generated from: binssoft-ngx-loader.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */
export { NgxLoaderService, NgxLoaderModule } from './public-api';
export { NgxLoaderComponent as ɵa } from './lib/ngx-loader.component';
export { NgxLoaderInterceptor as ɵb } from './lib/ngx-loader.interceptors';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmluc3NvZnQtbmd4LWxvYWRlci5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BiaW5zc29mdC9uZ3gtbG9hZGVyLyIsInNvdXJjZXMiOlsiYmluc3NvZnQtbmd4LWxvYWRlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUlBLGtEQUFjLGNBQWMsQ0FBQztBQUU3QixPQUFPLEVBQUMsa0JBQWtCLElBQUksRUFBRSxFQUFDLE1BQU0sNEJBQTRCLENBQUM7QUFDcEUsT0FBTyxFQUFDLG9CQUFvQixJQUFJLEVBQUUsRUFBQyxNQUFNLCtCQUErQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBHZW5lcmF0ZWQgYnVuZGxlIGluZGV4LiBEbyBub3QgZWRpdC5cbiAqL1xuXG5leHBvcnQgKiBmcm9tICcuL3B1YmxpYy1hcGknO1xuXG5leHBvcnQge05neExvYWRlckNvbXBvbmVudCBhcyDJtWF9IGZyb20gJy4vbGliL25neC1sb2FkZXIuY29tcG9uZW50JztcbmV4cG9ydCB7Tmd4TG9hZGVySW50ZXJjZXB0b3IgYXMgybVifSBmcm9tICcuL2xpYi9uZ3gtbG9hZGVyLmludGVyY2VwdG9ycyc7Il19