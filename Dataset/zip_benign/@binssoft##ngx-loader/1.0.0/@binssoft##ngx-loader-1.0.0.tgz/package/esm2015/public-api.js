/**
 * @fileoverview added by tsickle
 * Generated from: public-api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/*
 * Public API Surface of ngx-loader
 */
// export * from './lib/ngx-loader.component';
export { NgxLoaderService } from './lib/ngx-loader.service';
export { NgxLoaderModule } from './lib/ngx-loader.module';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljLWFwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0BiaW5zc29mdC9uZ3gtbG9hZGVyLyIsInNvdXJjZXMiOlsicHVibGljLWFwaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFLQSxpQ0FBYywwQkFBMEIsQ0FBQztBQUN6QyxnQ0FBYyx5QkFBeUIsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBQdWJsaWMgQVBJIFN1cmZhY2Ugb2Ygbmd4LWxvYWRlclxuICovXG5cbi8vIGV4cG9ydCAqIGZyb20gJy4vbGliL25neC1sb2FkZXIuY29tcG9uZW50JztcbmV4cG9ydCAqIGZyb20gJy4vbGliL25neC1sb2FkZXIuc2VydmljZSc7XG5leHBvcnQgKiBmcm9tICcuL2xpYi9uZ3gtbG9hZGVyLm1vZHVsZSc7XG4iXX0=