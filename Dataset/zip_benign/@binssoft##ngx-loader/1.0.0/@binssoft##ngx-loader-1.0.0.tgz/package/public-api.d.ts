export * from './lib/ngx-loader.service';
export * from './lib/ngx-loader.module';
