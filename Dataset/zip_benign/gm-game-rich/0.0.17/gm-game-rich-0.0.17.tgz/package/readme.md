# gm-game-rich

# 大富翁

##### 安装

```
npm install gm-game-rich
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game-rich": "gm-game-rich/rich"
    }
}
```

- js

```
Page({
  data: {
    renderGame: true,
    gameSource: {
      startNum: 15,//player开始时显示的圆点位置，默认第一个
      bgArr: [{
        src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01m120PW1FJvdStt5JI_!!1080040467.jpg",
        width: 750,
        height: 2208,
      }, {
        src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01IDFdiz1FJvdK1FG7O_!!1080040467.png",
        width: 750,
        height: 2208,
        animate: {
          time: 4000,
          repeat: "Infinity",
          maxMove: 6
        },
      }, {
        src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tApsnP1FJvdMTVEzK_!!1080040467.png",
        width: 750,
        height: 2208,
        animate: {
          time: 5000,
          repeat: "Infinity",
          maxMove: 6
        },
      }, {
        src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01mOjgyF1FJvdIiY06K_!!1080040467.png",
        width: 750,
        height: 2208,
        animate: {
          time: 3000,
          repeat: "Infinity",
          maxMove: 2
        },
      }],
      // 流星
      bgStart: [
        { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01pWoLho1FJvdP7pEUM_!!1080040467.png", width: 132, height: 103, x: 750, y: 1980, animate: { time: 3000, delay: 2000, repeat: "Infinity" }, },
        { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01pWoLho1FJvdP7pEUM_!!1080040467.png", width: 132, height: 103, x: 750, y: 1168, animate: { time: 4000, delay: 1000, repeat: "Infinity" }, },
        { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01pWoLho1FJvdP7pEUM_!!1080040467.png", width: 132, height: 103, x: 750, y: 930, animate: { time: 5000, delay: 500, repeat: "Infinity" }, },
        { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01pWoLho1FJvdP7pEUM_!!1080040467.png", width: 132, height: 103, x: 750, y: 514, animate: { time: 2000, delay: 10, repeat: "Infinity" }, },
        { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01pWoLho1FJvdP7pEUM_!!1080040467.png", width: 132, height: 103, x: 750, y: 0, animate: { time: 3000, delay: 0, repeat: "Infinity" }, },
      ],
      prizeStepNum: { min: 3, max: 6 },
      // 奖品 必须配置step:0的数据，否则在限制内没随机到奖品可能会出现内存溢出
      prizeArr: [
        // 人物形象
        { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Q4wuNK1FJvdK1MJFi_!!1080040467.png", width: 112, height: 137, probability: 2, prizetype: "people", step: 12, anchor: { x: 0.5, y: 0.58 } },
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01RIiZ0p1FJvdNzz7ut_!!1080040467.png", width: 112, height: 127, probability: 2, prizetype: "people", step: 12, anchor: { x: 0.5, y: 0.58 } },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01r0REQx1FJvdK1KELA_!!1080040467.png", width: 112, height: 137, probability: 2, prizetype: "people", step: 12, anchor: { x: 0.5, y: 0.58 } },
        { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01kX06xz1FJvdMztV0t_!!1080040467.png", width: 112, height: 137, probability: 2, prizetype: "people", step: 12, anchor: { x: 0.5, y: 0.58 } },
        { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN016fIUAp1FJvdQNjh2P_!!1080040467.png", width: 112, height: 137, probability: 2, prizetype: "people", step: 12, anchor: { x: 0.5, y: 0.58 } },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01eDuNZx1FJvdNzxqua_!!1080040467.png", width: 112, height: 127, probability: 2, prizetype: "people", step: 12, anchor: { x: 0.5, y: 0.58 } },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01zSCYDr1FJvdP7x1Gt_!!1080040467.png", width: 112, height: 137, probability: 2, prizetype: "people", step: 12, anchor: { x: 0.5, y: 0.58 } },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01kyvsej1FJvdTRqHu1_!!1080040467.png", width: 112, height: 127, probability: 2, prizetype: "people", step: 12, anchor: { x: 0.5, y: 0.58 } },
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01JE6ZQL1FJvdK1KABt_!!1080040467.png", width: 112, height: 137, probability: 2, prizetype: "people", step: 12, anchor: { x: 0.5, y: 0.58 } },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01pCczJz1FJvdS2WtwV_!!1080040467.png", width: 112, height: 137, probability: 2, prizetype: "people", step: 12, anchor: { x: 0.5, y: 0.58 } },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN016uDFFv1FJvdTRp0tr_!!1080040467.png", width: 112, height: 127, probability: 2, prizetype: "people", step: 12, anchor: { x: 0.5, y: 0.58 } },
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01OuSzus1FJvdNzyrIN_!!1080040467.png", width: 112, height: 137, probability: 2, prizetype: "people", step: 12, anchor: { x: 0.5, y: 0.58 } },
        { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01qbRDF11FJvdMbIfXh_!!1080040467.png", width: 112, height: 137, probability: 2, prizetype: "people", step: 12, anchor: { x: 0.5, y: 0.58 } },
        // 优惠券
        { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01LE2vCR1FJvdP7z6A4_!!1080040467.png", width: 112, height: 137, probability: 1, prizetype: "coupon", step: 20, anchor: { x: 0.5, y: 0.58 } },
        // 产品
        { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01mUFiUn1FJvdStxzIT_!!1080040467.png", width: 112, height: 137, probability: 1, prizetype: "pro", step: 10, anchor: { x: 0.5, y: 0.58 } },
        // 空格子，未中奖奖品
        { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01T9SgBE1FJvdUEw4fP_!!1080040467.png", width: 112, height: 137, probability: 1, prizetype: "noprize", step: 0, anchor: { x: 0.5, y: 0.58 } },
      ],
      beforeMoveTime: 1,// 移动前停留时间 s秒
      lastFadeTime: 1,// 移动完成后 停留时间再消失 s秒
      playerFixedNum: 4,//player定格在哪个格子上，从底部往上计数
      curPlayerIdx: 4,//默认显示游戏人物下标
      // 游戏人物
      playersArr: [
        { activeImg: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN013SUd111FJvdMbKDAM_!!1080040467.png", width: 200, height: 210 }, lockImg: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN013SUd111FJvdMbKDAM_!!1080040467.png", width: 200, height: 210 }, lock: false },
        { activeImg: { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01z4fMvf1FJvdKaT4ri_!!1080040467.png", width: 200, height: 210 }, lockImg: { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01z4fMvf1FJvdKaT4ri_!!1080040467.png", width: 200, height: 210 }, lock: false },
        { activeImg: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01aeqUDl1FJvdQNllx8_!!1080040467.png", width: 200, height: 210 }, lockImg: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01aeqUDl1FJvdQNllx8_!!1080040467.png", width: 200, height: 210 }, lock: false },
        { activeImg: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01PacuXL1FJvdMztZBO_!!1080040467.png", width: 200, height: 210 }, lockImg: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01PacuXL1FJvdMztZBO_!!1080040467.png", width: 200, height: 210 }, lock: !false },
        { activeImg: { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01jNAJkY1FJvdQNjDvf_!!1080040467.png", width: 200, height: 210 }, lockImg: { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01jNAJkY1FJvdQNjDvf_!!1080040467.png", width: 200, height: 210 }, lock: false },
        { activeImg: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ofGemo1FJvdP7zZIP_!!1080040467.png", width: 200, height: 210 }, lockImg: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ofGemo1FJvdP7zZIP_!!1080040467.png", width: 200, height: 210 }, lock: false },
        { activeImg: { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01LlpLFb1FJvdTRqUO4_!!1080040467.png", width: 200, height: 210 }, lockImg: { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01LlpLFb1FJvdTRqUO4_!!1080040467.png", width: 200, height: 210 }, lock: !false },
        { activeImg: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01yCrwwW1FJvdPuU3Pn_!!1080040467.png", width: 200, height: 210 }, lockImg: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01yCrwwW1FJvdPuU3Pn_!!1080040467.png", width: 200, height: 210 }, lock: false },
        { activeImg: { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01AfHx2m1FJvdIieB6F_!!1080040467.png", width: 200, height: 210 }, lockImg: { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01AfHx2m1FJvdIieB6F_!!1080040467.png", width: 200, height: 210 }, lock: !false },
        { activeImg: { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01rmBYj41FJvdNjsu6F_!!1080040467.png", width: 200, height: 210 }, lockImg: { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01rmBYj41FJvdNjsu6F_!!1080040467.png", width: 200, height: 210 }, lock: false },
        { activeImg: { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01WW41Jw1FJvdQNluHA_!!1080040467.png", width: 200, height: 210 }, lockImg: { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01WW41Jw1FJvdQNluHA_!!1080040467.png", width: 200, height: 210 }, lock: !false },
        { activeImg: { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01xjC4UQ1FJvdRNgNvY_!!1080040467.png", width: 200, height: 210 }, lockImg: { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01xjC4UQ1FJvdRNgNvY_!!1080040467.png", width: 200, height: 210 }, lock: false },
        { activeImg: { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01WyKvMd1FJvdP7wx8D_!!1080040467.png", width: 200, height: 210 }, lockImg: { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01WyKvMd1FJvdP7wx8D_!!1080040467.png", width: 200, height: 210 }, lock: false },
      ],
      // lockStatus
      playerStatus: {
        active: { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN018oxYLr1FJvdROfoOd_!!1080040467.png", width: 56, height: 56, anchor: { x: 0.5, y: 0.9 } },
        lock: { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01Ir0lum1FJvdL1oQ46_!!1080040467.png", width: 56, height: 56, anchor: { x: 0.5, y: 0.9 } },
      },
      playerChange: {
        left: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01l7V7r71FJvdWPd8Hu_!!1080040467.png", width: 100, height: 100, anchor: { x: 1.4, y: 1.8 } },
        right: { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01fyL6OL1FJvdUk3Nup_!!1080040467.png", width: 100, height: 100, anchor: { x: -0.4, y: 1.8 } },
      },
      // 奖品元素上面的发光
      prizeLightArr: {
        width: 127,
        height: 137,
        activeSpeed: 0.1,
        srcArr: [
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN019KGqlh1FJvdK1M6hh_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01gz7SHC1FJvdNzxaDM_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01INmzND1FJvdMTdQbc_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01LacXzh1FJvdKaQC0A_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN017HJLiK1FJvdP7wcG4_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01VsPnWd1FJvdNjr9ut_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01BvLBra1FJvdIibteS_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01bHfvuD1FJvdS2V1Q0_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01lHmNcc1FJvdMbFaAV_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01p9Thby1FJvdKaQnPT_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01MyWzvo1FJvdS2Tsir_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01POVDHw1FJvdIieNTn_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01BhuY2i1FJvdQNiYGA_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01fHAJ2Z1FJvdKaOW2w_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01btA6BS1FJvdS2WZ4n_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Ov2EFk1FJvdMbICKn_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01AevQsd1FJvdP7vLHF_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01fz4QEl1FJvdDx0CqC_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01SvJhLg1FJvdMzr9Op_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01EWqqQR1FJvdTRmvxo_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01oe8AXf1FJvdMzpwXW_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01z44spb1FJvdPuUSHR_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01VtTbHm1FJvdS2UU9W_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01JjuG6r1FJvdQNi0zf_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01lwavUS1FJvdK1JcqG_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01kIOO1W1FJvdTRpLdB_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01KU0fIo1FJvdMTbcNK_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01bmXign1FJvdMztEJb_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN019l1Hfz1FJvdS2WA7y_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01JXitc41FJvdMzq4ri_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN0165Ox2M1FJvdMTbHYJ_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01x8P5au1FJvdS2YZqj_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN013vwGmo1FJvdKaP3Jv_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN017gxkF51FJvdNjrMPj_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01YM9e7q1FJvdMzsDxc_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01am1sXi1FJvdMzqkTl_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01awOmr01FJvdS2YZqv_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01chBpCj1FJvdK1MqTH_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01QeNvW41FJvdNzyO7A_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01YlyB9m1FJvdS2X2CF_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01aABjA51FJvdRNfiJ4_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01q6Tdqj1FJvdDwyOaA_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01RLQ1Wo1FJvdQNhshJ_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01rli77J1FJvdIif7Ec_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN017RevZ31FJvdMTcQGC_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01DGj6tU1FJvdTRoPPn_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0143jIdb1FJvdNzyWS7_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01eRhxwo1FJvdS2Xq7G_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01v9iN9N1FJvdK1MRXR_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015AEXi91FJvdKaOqrg_!!1080040467.png", width: 127, height: 137 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN016CYZE91FJvdNzxRvl_!!1080040467.png", width: 127, height: 137 },
        ]
      },
      // 光效
      lightArr: {
        width: 180,
        height: 180,
        activeSpeed: "0.1",
        srcArr: [
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01Vx1XiV1FJvdSty3JD_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01N7upD51FJvdNzvuCR_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01KBUX6B1FJvdNzv29t_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01qDNqDL1FJvdQNk5qI_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01iM2Aji1FJvdRNeZa2_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Wm7hiz1FJvdKaPBZf_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ibRpYU1FJvdIicdLr_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01SfohTr1FJvdMbERRA_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN016PsV441FJvdIidZZ3_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ESNjf31FJvdQNhgAF_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01Q97kyd1FJvdS2XVFr_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01uwTpSD1FJvdTRoXfA_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01FO2hbp1FJvdNjsADE_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01UdVhj01FJvdMbIX5y_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01o6nvhL1FJvdNzwdxB_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01jQk9Bo1FJvdIib5hg_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01nyscoq1FJvdK1Ktnw_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tjiyNs1FJvdNjrcyS_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01B6tlDq1FJvdTRn4DA_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01jtynWs1FJvdNzvEdx_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01RDndkP1FJvdQNjl4t_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01xzbQYg1FJvdP7x9Td_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN015kiCn51FJvdS2VYeP_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN017H6X4G1FJvdNjtN5V_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01TFVdca1FJvdMTbY9C_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN015dt6sO1FJvdTRnGgl_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01x3xqjA1FJvdMzrPzL_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01VQEmN21FJvdK1KdCF_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01dcdchz1FJvdS2Vl84_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01YtBBBz1FJvdPuUWOz_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01UyzUEO1FJvdMbISwm_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01lM0hAe1FJvdP7wTut_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01MX5qbn1FJvdNjsdMO_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01OTZZ3v1FJvdMbFiSk_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01DY997y1FJvdTRoLCx_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN019jMRgO1FJvdMzpsMg_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN019ADVlL1FJvdTRn05U_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0176vuDY1FJvdMbGzT1_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN014bTaOy1FJvdStyzWM_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01q7jzUN1FJvdNzy7SS_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01XOclYm1FJvdP7wcFJ_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01eqmb811FJvdNzvEf8_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01BYUuVg1FJvdK1HkMl_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN013XY74g1FJvdMTb0tM_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01lNTgbw1FJvdDwyShM_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Vv6NGZ1FJvdKaPirs_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01EiG7uB1FJvdQNicPf_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01tcqtde1FJvdMTd9xJ_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ux5uRp1FJvdMTcHuS_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01olVJ2Z1FJvdK1LuDy_!!1080040467.png", width: 180, height: 180 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ozRHNJ1FJvdMzqTo3_!!1080040467.png", width: 180, height: 180 },
        ]
      },
      // 两侧按钮
      btnArr: [
        {
          // 左下
          clickShow: {//云朵点击按钮
            src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tApsnP1FJvdMTVEzK_!!1080040467.png",
            width: 186,
            height: 192,
            x: 20,
            y: 1640,
          },
          tipImg: {//提示弹窗
            src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01PayT4123c03CsWmLz_!!555657275.png",
            width: 204,
            height: 148,
            x: 55,
            y: 1522,
            btnImg: {
              src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015B75JV1FJvbN2zjjf_!!1080040467.png",
              width: 138,
              height: 36,
              jumpType: "buy",
              x: 88,
              y: 1606,
            },
          },
          animate: {
            time: 5000,
            repeat: "Infinity",
            maxMove: 6
          },
        }, {
          // 右
          clickShow: {//云朵点击按钮
            src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tApsnP1FJvdMTVEzK_!!1080040467.png",
            width: 110,
            height: 110,
            x: 526,
            y: 1640,
          },
          tipImg: {//提示弹窗
            src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN013Z5cvf23c03JDecxw_!!555657275.png",
            width: 204,
            height: 128,
            x: 430,
            y: 1540,
            btnImg: {
              src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015B75JV1FJvbN2zjjf_!!1080040467.png",
              width: 138,
              height: 36,
              jumpType: "zhibo",
              x: 465,
              y: 1598,
            },
          },
        }, {
          // 左上
          clickShow: {//云朵点击按钮
            src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tApsnP1FJvdMTVEzK_!!1080040467.png",
            width: 274,
            height: 172,
            x: 0,
            y: 1330,
          },
          tipImg: {//提示弹窗
            src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01QS08Rj23c03FSJU5F_!!555657275.png",
            width: 204,
            height: 128,
            x: 55,
            y: 1240,
            btnImg: {
              src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015B75JV1FJvbN2zjjf_!!1080040467.png",
              width: 138,
              height: 36,
              jumpType: "shiyanshi",
              x: 90,
              y: 1298,
            },
          },
        },

        {
          // 左下
          clickShow: {//云朵点击按钮
            src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tApsnP1FJvdMTVEzK_!!1080040467.png",
            width: 230,
            height: 176,
            x: 34,
            y: 616,
          },
          tipImg: {//提示弹窗
            src: "https://img.alicdn.com/imgextra/i3/555657275/O1CN01PayT4123c03CsWmLz_!!555657275.png",
            width: 204,
            height: 148,
            x: 55,
            y: 498,
            btnImg: {
              src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015B75JV1FJvbN2zjjf_!!1080040467.png",
              width: 138,
              height: 36,
              jumpType: "buy",
              x: 88,
              y: 582,
            },
          },
          animate: {
            time: 4000,
            repeat: "Infinity",
            maxMove: 6
          },
        }, {
          // 左上
          clickShow: {//云朵点击按钮
            src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tApsnP1FJvdMTVEzK_!!1080040467.png",
            width: 204,
            height: 154,
            x: 20,
            y: 306,
          },
          tipImg: {//提示弹窗
            src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01QS08Rj23c03FSJU5F_!!555657275.png",
            width: 204,
            height: 128,
            x: 55,
            y: 216,
            btnImg: {
              src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015B75JV1FJvbN2zjjf_!!1080040467.png",
              width: 138,
              height: 36,
              jumpType: "shiyanshi",
              x: 90,
              y: 274,
            },
          },
        }, {
          // 右
          clickShow: {//云朵点击按钮
            src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tApsnP1FJvdMTVEzK_!!1080040467.png",
            width: 146,
            height: 146,
            x: 566,
            y: 56,
          },
          tipImg: {//提示弹窗
            src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN013Z5cvf23c03JDecxw_!!555657275.png",
            width: 204,
            height: 128,
            x: 490,
            y: 8,
            btnImg: {
              src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015B75JV1FJvbN2zjjf_!!1080040467.png",
              width: 138,
              height: 36,
              jumpType: "zhibo",
              x: 520,
              y: 68,
            },
          },
        }
      ],
      // 圆点
      singleBox: {
        firstMoveTime: 0,//初始化移动事件 如果startNum大于1时，才会生效。对应步数移动的总时长
        stepX: 75,//相隔元素X轴间隔
        stepY: 0,//相隔元素Y轴间隔
        x: 302,//第一个x轴坐标
        height: 92,//圆点元素高度
        stepNum: 6,//循环个数
        time: 500,//两个元素移动的时间
        direction: "right",//初始圆点方向
        totalNum: 24,//总个数
        anchor: { x: "0.5", y: "0.58" },
      }
    },
  },
  onLoad() {
    // 定时触发可点击按钮回调
    setInterval(() => {
      this.randomTip();
    }, 5000);
  },
  onRef(game) {
    this.gameComponent = game;
  },
  changeFun() {
    this.setData({
      renderGame: !this.data.renderGame
    })
  },
  playFun() {
    // 点击开始游戏，每次游戏不管是否中奖，都会回调onUpdate
    let num = parseInt(Math.random() * 6 + 1);
    // num = 10;
    my.showToast({ content: num });
    this.gameComponent.play(num);
  },
  randomTip() {
    // 调用随机返回可点击按钮回调
    this.gameComponent.hideTipFun();//隐藏提示弹窗
    // 可传一个bool参数，true：显示所有弹窗，false：随机显示一个弹窗
    this.gameComponent.randomTip(!true);
  },
  changePlayer() {
    this.gameComponent.changePlayer(3);
  },

  onBeforeBtnFun() {
    // 点击云朵按钮前回调
    this.gameComponent.hideTipFun();
  },
  onProCallback(obj) {
    console.log("产品按钮点击回调：", obj.imgObj.jumpType);
  },
  onChangePlayer(img) {
    // 开始时选择player皮肤回调
    console.log(img);
  },
  onInitDone() {
    // my.alert({
    //   content: "游戏初始化完成"
    // })
  },
  onUpdate(imgObj) {
    if (!imgObj) {
      imgObj = "未中奖";
    }
    console.log(imgObj)
    // my.alert({
    //   content: imgObj
    // })
  },
});
```

- xaml

```
  <game-rich
    gameSource="{{gameSource}}"
    onRef="onRef"
    onInitDone="onInitDone" 
    onChangePlayer="onChangePlayer"
    onProCallback="onProCallback"
    onBeforeBtnFun="onBeforeBtnFun"
    onUpdate="onUpdate" 
  />
```