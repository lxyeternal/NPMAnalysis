import TWEEN from './tween';

let PIXI;
let Game = function (options) {
  try {
    options.gameSource = JSON.parse(options.gameSource);
  } catch (e) { }
  options.gameSource = JSON.parse(JSON.stringify(options.gameSource));
  this.options = Object.assign({}, options);
  this.GameData = this.options.gameSource;

  let padding = Object.assign({
    left: 0,
    top: 0,
    right: 0,
    bottom: 0
  }, this.GameData.padding);
  this.scale = this.options.$game.fObj.scale;
  this.padding = {
    left: padding.left * this.scale,
    right: padding.right * this.scale,
    top: padding.top * this.scale,
    bottom: padding.bottom * this.scale,
  };
  PIXI = this.options.$game.fObj.PIXI;
  this.width = this.options.$game.fObj.size.windowWidth;
  this.height = this.options.$game.fObj.size.windowHeight;

  // 1.创建pixi需要的对象 容器
  // 背景容器
  this.bgContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.bgContainer);
  this.bg1Container = new PIXI.Container();
  this.bgContainer.addChild(this.bg1Container);
  this.bg2Container = new PIXI.Container();
  this.bgContainer.addChild(this.bg2Container);

  // 精灵容器
  this.baseContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.baseContainer);
  // 操作元素容器 (只有一个元素)
  this.playerContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.playerContainer);
  // 动画容器
  this.animateContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.animateContainer);
  // 格子容器
  this.boxContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.boxContainer);

  // 2.遍历图片资源 并 去重
  let imgArr = [];
  this.traverse(this.GameData, function (k, v) {
    if (k == "src" && !!v && !imgArr.includes(v) && !PIXI.utils.TextureCache[v]) {
      imgArr.push(v);
    }
  })

  // 定时更新
  this.ticker = PIXI.ticker.shared;
  this.ticker.autoStart = false;
  this.ticker.addOnce(() => { });

  // 3.加载图片资源
  if (imgArr.length > 0) {
    let loader = new PIXI.loaders.Loader();
    imgArr.forEach(item => {
      loader.add(this.uniId(), item);
    })
    this.pixiLoadFun(loader);
  } else {
    this.init({});
    this.options.initDone();
  }

  this.ticker.add(() => this.draw());
  console.log(this.GameData)
}
Game.prototype = Object.assign(Game.prototype, {
  pixiLoadFun: function (loader) {
    let time1 = new Date().getTime();
    loader.on("progress", e => {
      this.options.progressFun(e.progress);
    })
    loader.on("error", e => {
      this.options.errorFun(e);
    })
    loader.load(() => {
      // 资源加载完成
      time1 = "";
      this.init({});
      this.options.initDone();
    });
    setTimeout(() => {
      // 5秒还没加载完，重新加载一遍
      if (!!time1) {
        console.log("重新加载资源...")
        this.pixiLoadFun(loader);
      }
    }, 5000)
  },
  uniId: function () {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  },
  random: function (options) {
    let opt = Object.assign({ min: 0, max: 0, isFloat: false, noNum: [] }, options);
    let tempNum;
    do {
      let num = Math.random() * (opt.max - opt.min) + opt.min;
      tempNum = !!opt.isFloat ? num : parseInt(num);
    } while (opt.noNum.includes(tempNum));
    return tempNum;
  },
  isArray: function (obj) {
    return obj instanceof Array;
  },
  isObject: function (obj) {
    // 判断数组对象
    if (!(obj instanceof Array) && (obj instanceof Object)) {
      return true;
    }
    return false;
  },
  traverse: function (obj, callback, RootObj) {
    if (!RootObj) { RootObj = this.GameData; }
    // 遍历json
    for (let name in obj) {
      // 如果是json对象
      if (this.isObject(obj[name])) {
        this.traverse(obj[name], callback, RootObj[name]);
      } else if (this.isArray(obj[name])) {
        // 数组对象
        obj[name].forEach((item, idx) => {
          this.traverse(item, callback, RootObj[name][idx]);
        })
      } else {
        let v = parseFloat(obj[name]);
        if (!v) {
          v = obj[name];
        }
        RootObj[name] = v;
        callback(name, obj[name]);
      }
    }
  },
  tickerStart() {
    let _this = this;
    if (!!_this.req) { return false; }
    this.tickerStopStatus = false;

    this.ticker.start();
    this.req = true;
  },
  tickerStop() {
    this.iStart = false;
    this.tickerStopStatus = true;

    this.ticker.stop();
    this.req = null;
  },
  bindEvent: function (sprite) {
    if (sprite.ftype == "reduce" || sprite.ftype == "add") {
    } else if (sprite.ftype == "proBtn") {
    } else {
      this.btnSpriteArr.push(sprite);
    }
    sprite.interactive = true;
    // 绑定事件
    sprite.on('touchstart', (e) => {
      let item = {
        x: sprite.x,
        y: sprite.y + sprite.parent.y + this.bgContainer.y,
        imgObj: Object.assign({}, sprite.imgObj),
        sprite: sprite,
      };

      if (sprite.ftype == "reduce" || sprite.ftype == "add") {
        this.changePlayer(sprite.ftype);
      } else if (sprite.ftype == "proBtn") {
        this.options.onProCallback(item);
      } else {
        this.options.beforeBtnCallback();
        this.showTipFun([item]);
      }
    })
  },
  hideTipFun: function () {
    this.btnSpriteArr.forEach(sprite => {
      let sprite1 = this[`f_${sprite.uniId}_1`];
      let sprite2 = this[`f_${sprite.uniId}_1_1`];
      if (!!sprite1.visible) {
        sprite1.visible = false;
        sprite2.visible = false;
      }
    })
  },
  hideOtherTipFun: function () {
    // 隐藏超出显示区域的弹窗
    this.btnSpriteArr.forEach(sprite => {
      let sprite1 = this[`f_${sprite.uniId}_1`];
      let sprite2 = this[`f_${sprite.uniId}_1_1`];
      let baseY = sprite.parent.y + this.bgContainer.y;
      if (0 <= sprite1.y + baseY && sprite1.y + baseY <= this.height - sprite1.height) {
      } else {
        if (sprite1.visible) {
          sprite1.visible = false;
          sprite2.visible = false;
        }
      }
    })
  },
  showTipFun: function (items) {
    items.forEach(item => {
      let sprite = item.sprite;
      let sprite1 = this[`f_${sprite.uniId}_1`];
      let sprite2 = this[`f_${sprite.uniId}_1_1`];
      let baseY = sprite.parent.y + this.bgContainer.y;
      if (0 <= sprite1.y + baseY && sprite1.y + baseY <= this.height - sprite1.height) {
        if (!sprite1.visible) {
          sprite1.visible = true;
          sprite2.visible = true;
        }
      } else {
        // 隐藏区域
      }
    })
  },
  frame: function (img, x, y) {
    // 返回texture
    let source = img.src, width = img.width, height = img.height;

    let texture, imageFrame;
    if (typeof source === "string") {
      if (PIXI.utils.TextureCache[source]) {
        texture = new PIXI.Texture(PIXI.utils.TextureCache[source]);
      }
    }
    if (!texture) { console.log(`Please load the ${source} texture into the cache.`); } else {
      imageFrame = new PIXI.Rectangle(x, y, width, height);
      texture.frame = imageFrame;
      return texture;
    }
  },
  renderSprite: function (tImg, spriteContainerName, noContainer) {
    let sprite;
    // 没有唯一标识，说明第一次生成
    if (tImg.type == "animate") {
      // 动画
      let textures = [];
      tImg.srcArr.forEach(img => {
        textures.push(this.frame(img, 0, 0));
      })
      sprite = new PIXI.extras.AnimatedSprite(textures);
      sprite.animationSpeed = tImg.boomSpeed;
      sprite.loop = tImg.loop || false;
      sprite.onComplete = function () {
        if (!!tImg.maxAnimate) {
          // 执行回调
          try {
            tImg.callback(sprite);
          } catch (e) { }
        }
      }
    } else {
      sprite = new PIXI.Sprite();

      let options = { x: 0, y: 0 };
      sprite.texture = this.frame(tImg, options.x, options.y);
    }

    sprite.uniId = this.uniId();
    sprite.width = tImg.width * this.scale;
    sprite.height = tImg.height * this.scale;

    sprite.x = (tImg.x || 0);
    sprite.y = (tImg.y || 0);
    sprite.imgObj = tImg;

    if (!!tImg.anchor) {
      sprite.anchor.set(tImg.anchor.x, tImg.anchor.y);
    }

    sprite.type = tImg.type || "";
    if (!!tImg.global) {
      this[tImg.global] = sprite;
    }
    if (tImg.type == "animate") {
      sprite.stop()
      sprite.gotoAndPlay(0)
    }

    if (!noContainer) {
      if (!spriteContainerName) {
        spriteContainerName = "base";
      }

      this[`${spriteContainerName}SpriteArr`].push(sprite);
      this[`${spriteContainerName}Container`].addChild(sprite);
    }

    return sprite;
  },
  // 添加精灵
  addBlock: function () {
    let renderArr = [];//需要生成的精灵数组
    let totalProbability = 0;
    imgArr.forEach(item => {
      item.probability = item.probability || 1;
      item.max = totalProbability + item.probability
      totalProbability = item.max;
      renderArr.push(Object.assign({}, item));
    });

    // 此次生成的元素
    let defaultImg;
    let tempIndex = this.random({ max: totalProbability });
    renderArr.forEach(item => {
      if (!defaultImg && item.max > tempIndex) {
        defaultImg = Object.assign({
          type: type,
        }, item);
      }
    })

    this.renderSprite(defaultImg);
  },
  // 获取了能量
  updateFun: function (sprite) {
    if (this.firstRender) { this.firstRender = false; return false; }
    let imgObj;
    if (!!sprite) {
      imgObj = sprite.imgObj;
    }
    this.options.onUpdate(imgObj);
  },
  draw: function () {
    TWEEN.update();
    this.hideOtherTipFun();
    // 移动背景
    let curMove = parseInt(Math.abs(this.baseY - this.bgContainer.y) / this.bgH);
    if (curMove != this.movePage) {
      this.renderJStatus = false;
      this.movePage = curMove;
      if (curMove % 2 == 0) {
        this.bg2Container.y = this.bg1Container.y - this.bgH;
      } else {
        this.bg1Container.y = this.bg2Container.y - this.bgH;
      }
      this.renderRandJiang(curMove + 2);
    }
  },
  hideSpriteArrFun(name, ops) {
    let options = Object.assign({ childs: [] }, ops);
    if (!!this[name]) {
      this[name].forEach(sprite => {
        if (!!sprite.visible) {
          sprite.visible = false;
        }
        options.childs.forEach(t => {
          if (!!sprite[t] && !!sprite[t].visible) {
            sprite[t].visible = false;
          }
        })
      })
    }
  },
  bgAniFun: function (sprite) {
    // 背景缓动动画
    let imgObj = sprite.imgObj;

    if (typeof sprite.basePos == "undefined") {
      sprite.basePos = sprite.y;
    }

    new TWEEN.Tween(sprite)
      .to({ y: [sprite.basePos + imgObj.animate.maxMove, sprite.basePos, sprite.basePos - imgObj.animate.maxMove, sprite.basePos] }, imgObj.animate.time)
      .delay(imgObj.animate.delay || 0)
      .repeat(imgObj.animate.repeat || 0)
      .start();
  },
  renderBg: function () {
    let bgH = this.GameData.bgArr[0].height * this.scale;
    this.bgH = bgH;

    this.bgContainer.height = this.bgH * 2;
    this.bgContainer.y = this.height - this.bgH * 2;

    this.GameData.bgArr.forEach(bgItem => {
      let tempImg = Object.assign({}, bgItem);

      let sprite1 = this.renderSprite(tempImg, "bg1");
      let sprite2 = this.renderSprite(tempImg, "bg2");

      if (!!tempImg.animate) {
        this.bgAniFun(sprite1);
        this.bgAniFun(sprite2);
      }
    });
    this.bg1Container.height = this.bgH;
    this.bg2Container.height = this.bgH;
    // 渲染星星
    this.GameData.bgStart.forEach(start => {
      let startImg = Object.assign({}, start);
      startImg.x = startImg.x * this.scale;
      startImg.y = startImg.y * this.scale;

      let sprite = this.renderSprite(startImg, "bg1");
      this.bg1Container.setChildIndex(sprite, 1);
      let startX = sprite.x, endX = -sprite.width;
      sprite.baseX = startX;
      sprite.moveH = (startX - endX);
      let endY = sprite.y + sprite.moveH;
      new TWEEN.Tween(sprite)
        .to({ y: [endY], x: endX }, startImg.animate.time)
        .delay(startImg.animate.delay || 0)
        .repeat(startImg.animate.repeat || 0)
        .onUpdate((sprite) => {
          sprite.alpha = (sprite.moveH - (sprite.baseX - sprite.x)) / sprite.moveH;
        })
        .start();
    });

    // 绘制可点击区域
    this.GameData.btnArr.forEach(item => {
      // 默认点击区域------------
      let img = Object.assign({}, item.clickShow);
      // let sprite = this.drawHelpLine(img.x * this.scale, img.y * this.scale, img.width * this.scale, img.height * this.scale, this.bg1Container);
      if (item.animate) {
        img.animate = item.animate;
      }
      img.x = img.x * this.scale;
      img.y = img.y * this.scale;
      let sprite1 = this.renderSprite(img, "bg1");
      let sprite2 = this.renderSprite(img, "bg2");
      if (!!img.animate) {
        this.bgAniFun(sprite1);
        this.bgAniFun(sprite2);
      }
      sprite1.alpha = 0;//设置透明度为0隐藏显示
      this.bindEvent(sprite1);
      sprite2.alpha = 0;//设置透明度为0隐藏显示
      this.bindEvent(sprite2);

      if (!!item.tipImg) {
        // 提示弹窗-------------------
        let tipImg = Object.assign({}, item.tipImg);
        if (item.animate) {
          tipImg.animate = item.animate;
        }
        tipImg.x = tipImg.x * this.scale;
        tipImg.y = tipImg.y * this.scale;
        tipImg.global = `f_${sprite1.uniId}_1`;
        let tipImgSprite1 = this.renderSprite(tipImg, "bg1");
        tipImg.global = `f_${sprite2.uniId}_1`;
        let tipImgSprite2 = this.renderSprite(tipImg, "bg2");
        if (!!tipImg.animate) {
          this.bgAniFun(tipImgSprite1);
          this.bgAniFun(tipImgSprite2);
        }

        // 提示框上面的按钮----------
        let tipBtn = Object.assign({}, tipImg.btnImg);
        if (item.animate) {
          tipBtn.animate = item.animate;
        }
        // let sprite = this.drawHelpLine(tipBtn.x * this.scale, tipBtn.y * this.scale, tipBtn.width * this.scale, tipBtn.height * this.scale, this.bg1Container);
        tipBtn.x = tipBtn.x * this.scale;
        tipBtn.y = tipBtn.y * this.scale;
        tipBtn.global = `f_${sprite1.uniId}_1_1`;
        let tipBtnSprite1 = this.renderSprite(tipBtn, "bg1");
        tipBtn.global = `f_${sprite2.uniId}_1_1`;
        let tipBtnSprite2 = this.renderSprite(tipBtn, "bg2");
        tipBtnSprite1.ftype = "proBtn";
        tipBtnSprite2.ftype = "proBtn";

        tipBtnSprite1.alpha = 0;
        tipBtnSprite2.alpha = 0;
        if (!!tipBtn.animate) {
          this.bgAniFun(tipBtnSprite1);
          this.bgAniFun(tipBtnSprite2);
        }
        // 绑定事件
        this.bindEvent(tipBtnSprite1);
        this.bindEvent(tipBtnSprite2);

        // 默认先隐藏
        tipImgSprite1.visible = false;
        tipImgSprite2.visible = false;
        tipBtnSprite1.visible = false;
        tipBtnSprite2.visible = false;
      }
    })

    // 渲染圆点容器
    for (let i = 1; i <= this.totalPointNum; i++) {
      this.showLight(i);
    }
  },
  getPos: function (idx) {
    // 圆点从1开始算
    let num = idx % this.totalPointNum;
    if (num == 0) {
      num = this.totalPointNum;
    }

    let tcount = (num - 1) % 6;
    if (tcount == 3) {
      tcount = 2;
    } else if (tcount == 4) {
      tcount = 1;
    } else if (tcount == 5) {
      tcount = 0;
    }

    let singleBox = this.GameData.singleBox;
    let x = singleBox.x * this.scale + (tcount * (singleBox.stepX)) * this.scale;
    let y;
    if (num <= this.totalPointNum / 2) {
      y = (this.totalPointNum / 2 - num) * singleBox.height * this.scale;
    } else {
      y = (this.totalPointNum - num) * singleBox.height * this.scale;
    }

    return { x, y };
  },
  showLight: function (idx) {
    let num = idx % this.totalPointNum;
    if (num == 0) {
      num = this.totalPointNum;
    }
    // num：1-this.totalPointNum
    // 绘制每个点容器
    let singleBox = this.GameData.singleBox;
    // 每一个圆格子容器
    let container = new PIXI.Container();

    container.x = 0;
    let pos = this.getPos(num);
    container.y = pos.y;
    container.width = this.width;
    container.height = singleBox.height * this.scale;
    // 格子发光精灵------------------begin
    let aniImgArr = Object.assign({
      type: "animate",
      loop: true,
      anchor: singleBox.anchor
    }, this.GameData.lightArr);
    aniImgArr.boomSpeed = aniImgArr.activeSpeed;
    aniImgArr.x = pos.x;
    let sprite = this.renderSprite(aniImgArr, "", true);
    sprite.visible = false;//默认隐藏发光
    sprite.ftype = "light";
    container.addChild(sprite);
    // 格子发光精灵------------------end
    // 奖品发光精灵------------------begin
    let aniImgArr1 = Object.assign({
      type: "animate",
      loop: true,
      anchor: singleBox.anchor
    }, this.GameData.prizeLightArr);
    aniImgArr1.boomSpeed = aniImgArr1.activeSpeed;
    aniImgArr1.x = pos.x;
    let sprite1 = this.renderSprite(aniImgArr1, "", true);
    sprite1.visible = false;//默认隐藏发光
    sprite1.ftype = "prizeLight";
    container.addChild(sprite1);
    // 奖品发光精灵------------------end
    container.curIdx = num;
    // 默认隐藏
    if (num <= this.totalPointNum / 2) {
      this.bg1Container.addChild(container);
    } else {
      this.bg2Container.addChild(container);
    }
  },
  hidePoint: function () {
    // 显示指定元素的光效
    this.bg1Container.children.forEach(container => {
      container.children.forEach(sprite => {
        if (sprite.ftype == "light") {
          sprite.visible = false;
        }
      })
    })
    this.bg2Container.children.forEach(container => {
      container.children.forEach(sprite => {
        if (sprite.ftype == "light") {
          sprite.visible = false;
        }
      })
    })
  },
  // 点亮灯光
  showPoint: function (idx) {
    let num = idx % this.totalPointNum;
    if (num == 0) {
      num = this.totalPointNum;
    }

    // 显示指定元素的光效
    this.bg1Container.children.forEach(container => {
      if (container.curIdx == num) {
        container.children.forEach(sprite => {
          if (sprite.ftype == "light") {
            sprite.visible = true;
          }
        })
      }
    })
    this.bg2Container.children.forEach(container => {
      if (container.curIdx == num) {
        container.children.forEach(sprite => {
          if (sprite.ftype == "light") {
            sprite.visible = true;
          }
        })
      }
    })
  },
  // 生成奖品
  renderJiang: function (idx) {
    let num = idx % this.totalPointNum;
    if (num == 0) {
      num = this.totalPointNum;
    }
    if (!(num != this.totalPointNum && num != this.totalPointNum / 2)) {
      return false;
    }
    let tempContainer;
    let lightSprite;
    // 显示指定元素的光效
    this.bg1Container.children.forEach(container => {
      if (container.curIdx == num) {
        tempContainer = container;
        container.children.forEach(sprite => {
          if (sprite.ftype == "prizeLight") {
            lightSprite = sprite;
          }
          if (sprite.ftype == "prize") {
            sprite.visible = false;
          }
        })
      }
    })
    this.bg2Container.children.forEach(container => {
      if (container.curIdx == num) {
        tempContainer = container;
        container.children.forEach(sprite => {
          if (sprite.ftype == "prizeLight") {
            lightSprite = sprite;
          }
          if (sprite.ftype == "prize") {
            sprite.visible = false;
          }
        })
      }
    })
    let totalProbability = 0;
    this.GameData.prizeArr.forEach(item => {
      if (item.step != 0) {
        item.probability = item.probability || 1;
        item.maxProbability = totalProbability + item.probability;
        totalProbability = item.maxProbability;
      }
    });

    let imgObj;
    let tCount = 0, maxCount = 200;
    do {
      imgObj = null;
      let num1 = this.random({ max: totalProbability });
      this.GameData.prizeArr.forEach(item => {
        if (!imgObj && num1 < item.maxProbability) {
          imgObj = item;
        }
      });
      tCount++;
    } while (!(!imgObj.prizetype || !this[`${imgObj.prizetype}`] || (Math.abs(num - this[`${imgObj.prizetype}`]) >= (imgObj.step || 0))) && tCount < maxCount);
    if (tCount == maxCount) {
      // 达到了最大循环也没有随机到元素，则从没有限制的奖品中随机一个
      let tData = this.GameData.prizeArr.filter(item => item.step == 0);
      let num1 = this.random({ max: tData.length });
      imgObj = tData[num1];
    }
    if (!!imgObj.prizetype) {
      this[`${imgObj.prizetype}`] = num;
    }

    lightSprite.visible = true;
    imgObj.x = lightSprite.x;
    imgObj.y = lightSprite.y;

    if (imgObj.prizetype == "noprize") {
      lightSprite.visible = false;
    }

    let sprite = this.renderSprite(Object.assign({}, imgObj), "", true);
    sprite.ftype = "prize";
    if (num == this.GameData.startNum % this.totalPointNum && !!this.firstRender) {
      // 隐藏初始化有步数的时候，对应位置的奖品
      sprite.visible = false;
    }
    tempContainer.addChild(sprite);
    tempContainer.setChildIndex(sprite, 1);

    return true;
  },
  renderRandJiang: function (curPage) {
    let min = (curPage - 1) * this.GameData.singleBox.totalNum + 1, max = curPage * this.GameData.singleBox.totalNum;
    let bl = true;
    while (bl) {
      let idx = this.random({ min: this.GameData.prizeStepNum.min, max: this.GameData.prizeStepNum.max });
      let curIdx = this.lastPrizeNum + idx;

      if (curIdx <= max) {
        // 生成奖品
        let isT = false;
        if (curIdx >= min) {
          isT = this.renderJiang(curIdx);
          if (isT) {
            this.lastPrizeNum = curIdx;
          }
        } else {
          this.lastPrizeNum = curIdx;
        }
      } else {
        bl = false;
      }
    }
  },
  renderPlayer: function () {
    let playerArr = this.GameData.playersArr;
    let tempImg = playerArr[this.curPlayerIdx];
    let lockImg = Object.assign({ global: "lockTrue" }, this.GameData.playerStatus.lock);
    let activeImg = Object.assign({ global: "lockFalse" }, this.GameData.playerStatus.active);
    let changeLeft = Object.assign({ global: "changeLeft" }, this.GameData.playerChange.left);
    let changeRight = Object.assign({ global: "changeRight" }, this.GameData.playerChange.right);
    let status = "";
    if (tempImg.lock) {
      status = "True";
      tempImg = Object.assign({ lock: true }, tempImg.lockImg);
    } else {
      status = "False";
      tempImg = Object.assign({ lock: false }, tempImg.activeImg);
    }
    let imgObj = Object.assign({
      global: "playerSprite",
      anchor: { x: 0.5, y: 1.25 }
    }, tempImg);

    if (this.playerSprite) {
      // 替换
      this.playerSprite.texture = this.frame(imgObj, 0, 0);
    } else {
      let pos = this.getPos(this.curPlayerBoxPoint);
      this.playerContainer.x = pos.x;
      this.playerContainer.y = this.height;
      // 创建
      // 1.创建player精灵
      let sprite = this.renderSprite(imgObj, "player");
      // sprite.x = pos.x;
      sprite.ftype = "player";
      // 2.创建解锁状态
      this.renderSprite(lockImg, "player");
      this.renderSprite(activeImg, "player");
      // 3.创建左右切换按钮
      let changeLeftSprite = this.renderSprite(changeLeft, "player");
      changeLeftSprite.ftype = "reduce";
      this.bindEvent(changeLeftSprite);
      let changeRightSprite = this.renderSprite(changeRight, "player");
      changeRightSprite.ftype = "add";
      this.bindEvent(changeRightSprite);
    }

    this.options.onChangePlayer(imgObj);
    this[`lockTrue`].visible = false;
    this[`lockFalse`].visible = false;
    if (this.changeLeft.visible) {
      this[`lock${status}`].visible = true;
    }
  },
  hideChangeBtn: function () {
    this.changeLeft.visible = false;
    this.changeRight.visible = false;
    this[`lockTrue`].visible = false;
    this[`lockFalse`].visible = false;
  },
  changePlayer: function (type) {
    let idx = this.curPlayerIdx;
    let c = false;
    if (type == "reduce") {
      idx--;
    } else if (type == "add") {
      // add
      idx++;
    } else {
      idx = type || 0;
      c = true;
    }
    let playerArr = this.GameData.playersArr;
    if (!c) {
      if (idx <= 0) {
        idx = playerArr.length - 1;
      }
      if (idx >= playerArr.length) {
        idx = 0;
      }
    }
    this.curPlayerIdx = idx;
    this.renderPlayer();
  },
  init: function (defaultData = {}) {
    this.hideSpriteArrFun("animatespriteArr");
    this.hideSpriteArrFun("spriteArr");
    // 障碍物
    this.baseSpriteArr = defaultData.baseSpriteArr || [];// 存放精灵数组
    this.animateSpriteArr = defaultData.animateSpriteArr || [];// 存放动画精灵数组
    this.playerSpriteArr = defaultData.playerSpriteArr || [];// 存放player精灵数组
    this.bgSpriteArr = defaultData.bgSpriteArr || [];// 存放背景精灵数组
    this.bg1SpriteArr = defaultData.bg1SpriteArr || [];// 存放第一屏背景精灵数组
    this.bg2SpriteArr = defaultData.bg2SpriteArr || [];// 存放第二屏背景精灵数组
    this.btnSpriteArr = [];//存放两侧可以点击的按钮
    this.movePage = 0;//移动了多少页，以bgH为标准
    this.curPlayerBoxPoint = 1;//当前player所在的圆点格
    this.curPlayerIdx = this.GameData.curPlayerIdx || 0;//当前显示player下标
    this.totalPointNum = this.GameData.singleBox.totalNum * 2;//bg1和bg2下面的圆点个数
    this.tempMoveBgCount = this.GameData.playerFixedNum - 1;//临时记录 多一是player占的一格
    this.lastPrizeNum = this.curPlayerBoxPoint;

    this.tickerStart();

    // 1.渲染背景
    this.renderBg();
    this.baseY = this.bgContainer.y;//背景容器原始位置
    // 初始化背景位置
    this.bg1Container.y = this.bgH;
    this.bg2Container.y = this.bg1Container.y - this.bgH;

    this.GameData.startNum = (this.GameData.startNum || 1) % this.totalPointNum;
    if (this.GameData.startNum == 0) {
      this.GameData.startNum = this.totalPointNum;
    }

    if (this.GameData.startNum > 1) {
      this.firstRender = true;
    }
    // 第一次渲染奖品
    this.renderRandJiang(1);
    this.renderRandJiang(2);

    // 2.渲染player
    this.renderPlayer();

    this.draw();

    if (this.GameData.startNum > 1) {
      this.startGame(this.GameData.startNum - 1);
    }
  },
  hideSpriteFun: function () {
    let num = this.curPlayerBoxPoint % this.totalPointNum;
    if (num == 0) { num = this.totalPointNum; }
    let ZJPrize;
    this.bg1Container.children.forEach(container => {
      if (container.curIdx && this.curArr.includes(container.curIdx)) {
        container.children.forEach(sprite => {
          if (sprite.ftype == "light" || sprite.ftype == "prizeLight") {
            if (sprite.visible) {
              setTimeout(() => {
                sprite.visible = false;
              }, (this.GameData.lastFadeTime * 1000) || 0);
            }
          }
          if (sprite.ftype == "prize" && sprite.visible) {
            sprite.visible = false;
            if (container.curIdx == num && sprite.imgObj.prizetype != "noprize") {
              ZJPrize = sprite;
            }
          }
        })
      }
    })
    this.bg2Container.children.forEach(container => {
      if (container.curIdx && this.curArr.includes(container.curIdx)) {
        container.children.forEach(sprite => {
          if (sprite.ftype == "light" || sprite.ftype == "prizeLight") {
            if (sprite.visible) {
              setTimeout(() => {
                sprite.visible = false;
              }, (this.GameData.lastFadeTime * 1000) || 0);
            }
          }
          if (sprite.ftype == "prize" && sprite.visible) {
            sprite.visible = false;
            if (container.curIdx == num && sprite.imgObj.prizetype != "noprize") {
              ZJPrize = sprite;
            }
          }
        })
      }
    })

    this.updateFun(ZJPrize);
  },
  drawHelpLine: function (x, y, width, height, container) {
    var rectangle = new PIXI.Graphics();
    rectangle.lineStyle(4, 0xFF3300, 1);
    rectangle.drawRect(0, 0, width, height);
    rectangle.x = x;
    rectangle.y = y;
    container.addChild(rectangle);

    return rectangle;
  },
  movePlayer: function (toNum, curMoveNum) {
    this.curPlayerBoxPoint++;
    let pos = this.getPos(this.curPlayerBoxPoint);
    let moveOps = { x: [pos.x] };
    let time = this.GameData.singleBox.time;
    if (!!this.firstRender) {
      time = this.GameData.singleBox.firstMoveTime / toNum;
    }
    if (this.curPlayerBoxPoint <= this.GameData.playerFixedNum) {
      moveOps.y = [this.playerContainer.y - this.GameData.singleBox.height * this.scale];
    } else {
      // if (!!this.moveUid) {
      //   this.moveUid = "";
      //   this.moveBg(curMoveNum, time * curMoveNum);
      // }
      this.moveBgOne(toNum);
    }

    if (time == 0) {
      this.playerContainer.x = moveOps.x[0];
      if (typeof moveOps.y != "undefined") {
        this.playerContainer.y = moveOps.y[0];
      }
      if (this.curPlayerBoxPoint < toNum) {
        this.movePlayer(toNum, curMoveNum);
      } else {
        this.moveDoneFun();
      }
      return false;
    }

    // 移动player
    new TWEEN.Tween(this.playerContainer)
      .to(moveOps, time)
      .repeat(0)
      .onComplete(() => {
        if (this.curPlayerBoxPoint < toNum) {
          this.movePlayer(toNum, curMoveNum);
        } else {
          this.moveDoneFun();
        }
      })
      .start();
  },
  moveBg: function (num, time) {
    num -= this.tempMoveBgCount;
    num = Math.max(0, num);

    this.tempMoveBgCount -= num + 2;
    this.tempMoveBgCount = Math.max(0, this.tempMoveBgCount);
    let tempH = (num * (this.GameData.singleBox.height + this.GameData.singleBox.stepY) * this.scale);

    // 移动背景
    new TWEEN.Tween(this.bgContainer)
      .to({ y: [this.bgContainer.y + tempH] }, time)
      .repeat(0)
      .onComplete(() => {
      })
      .start();
  },
  moveBgOne: function (toNum) {
    // 移动背景
    let time = this.GameData.singleBox.time;
    if (!!this.firstRender) {
      time = this.GameData.singleBox.firstMoveTime / toNum;
    }

    if (time == 0) {
      this.bgContainer.y = this.bgContainer.y + (this.GameData.singleBox.height + this.GameData.singleBox.stepY) * this.scale;
      return false;
    }
    new TWEEN.Tween(this.bgContainer)
      .to({ y: [this.bgContainer.y + (this.GameData.singleBox.height + this.GameData.singleBox.stepY) * this.scale] }, time)
      .repeat(0)
      .onComplete(() => {
      })
      .start();
  },
  moveDoneFun: function () {
    this.iStart = false;
    this.hideSpriteFun();
  },
  randomTip: function (showAll) {
    let arr = this.btnSpriteArr;

    let itemArr = [];
    if (!!showAll) {
      // 返回所有可点击按钮
      arr.forEach(sprite => {
        let item = {
          x: sprite.x,
          y: sprite.y + sprite.parent.y + this.bgContainer.y,
          imgObj: Object.assign({}, sprite.imgObj),
          sprite: sprite,
        };
        if (item.y >= 0 && item.y <= this.height) {
          itemArr.push(item);
        }
      })
    } else {
      let item;
      let maxI = 0;
      do {
        let idx = this.random({ max: arr.length });
        let sprite = arr[idx];
        item = {
          x: sprite.x,
          y: sprite.y + sprite.parent.y + this.bgContainer.y,
          imgObj: Object.assign({}, sprite.imgObj),
          sprite: sprite,
        };
        maxI++;
      } while (!((item.y >= 0 && item.y <= this.height) || maxI >= 200));
      if (item) {
        itemArr.push(item);
      }
    }
    if (itemArr.length > 0) {
      this.showTipFun(itemArr);
    } else {
      console.log("没有找到可点击元素")
    }
  }
})
Game.prototype.startGame = function (num) {
  num = num || 0;
  if (num <= 0) {
    my.alert({ content: "步数必须大于0" });
    return false;
  }
  if (!!this.iStart) { return false; }
  this.iStart = "start";
  this.overSprite = null;
  this.hideSpriteArrFun("animatespriteArr");
  let beforeTime = 0;
  if (!this.firstRender) {
    //隐藏切换player操作按钮
    this.hideChangeBtn();
    // 隐藏灯光
    this.hidePoint();
    // 过滤掉初始化时有步数的灯光显示
    beforeTime = (this.GameData.beforeMoveTime || 0) * 1000;
    // 1.显示灯光
    let t = num;
    while (t > 0) {
      this.showPoint(this.curPlayerBoxPoint + t);
      t--;
    }
  }
  if (this.tempMoveBgCount > 0) {
    if (num + 1 <= this.GameData.playerFixedNum) {
      this.tempMoveBgCount -= num;
      this.tempMoveBgCount = Math.max(0, this.tempMoveBgCount);
    }
  }

  setTimeout(() => {
    this.moveUid = this.uniId();
    let arr = [];
    for (let i = this.curPlayerBoxPoint; i <= this.curPlayerBoxPoint + num; i++) {
      let ftNum = i % this.totalPointNum;
      if (ftNum == 0) { ftNum = this.totalPointNum; }
      arr.push(ftNum);
    }
    this.curArr = arr;
    this.movePlayer(this.curPlayerBoxPoint + num, num);
  }, beforeTime)
}

export {
  Game
}