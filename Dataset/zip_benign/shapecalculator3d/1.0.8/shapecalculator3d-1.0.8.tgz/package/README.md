# calculateshape3d

an application that places 3d Objects in a 3D container and calculates empty spaces or incremental spaces

3d Nesneleri 3 boyutlu bir kaba yerleştiren ve boş alanları veya artan alanları hesaplayan uygulama

## installation

calculateshape'i npm kullanarak yükleyin

```bash
  npm install calculateshape3d
```

## Usage/Examples

```javascript
import { Box, packItemsIntoBin } from 'shapecalculator3d';

function calc() {
  /* This packItemsIntoBin function first parameter 
it's uses meters as a unit of measurement for Object   */

  /* Second parameter create new class Box and add parameters width,height,depth this class uses as a unit of measurement in meter  */
  console.log(
    packItemsIntoBin({ width: 15, height: 15, depth: 15 }, [
      new Box(0.5, 1.4, 0.7),
    ]),
  );
}

calc();
```

## Console Result

```javascript
{
  packedItems: [
        Box {
        width: 0.5,
        height: 1.4,
        depth: 0.7,
        volume: 0.48999999999999994
        }
  ],
  remainingVolume: 3374.51,
  residualSpace: []
}

```

## Feedback

Herhangi bir geri bildiriminiz varsa, lütfen hakanatasever422@hotmail.com adresinden bize ulaşın.

## License

[MIT](https://choosealicense.com/licenses/mit/)

## Technologies Used

**İstemci:** TypeScript, JS, Node
