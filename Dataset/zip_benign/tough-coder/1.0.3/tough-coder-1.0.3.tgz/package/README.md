# Tough-Coder

**Tough-Coder** is a CLI tool that infinitely outputs lines of random (or web-sourced) text, giving the appearance that you're running a complex, impressive command. It allows you to control speed, color, lines per tick, probabilities of scenarios, and even pull data from websites.

## Installation

```bash
npm install -g tough-coder
```

# Usage
Run the command with various parameters:


Parameters
Scenarios and Probability:

-P-<prob>: Start a new scenario with the given probability (0.1 to 1). The parameters that follow belong to this scenario until another -P is encountered or arguments end.
Example:

```bash
tough-coder -P-0.5 -s 10 -c r -P-0.1 -s 3 -c y -l 5
```
This means:

- 50% chance per tick: Speed=10 lines/sec, color=red, lines=1 (default if not set)
- 10% chance per tick: Speed=3 lines/sec, color=yellow, 5 lines per tick
- 40% (remaining probability): fallback scenario (default: speed=1, white color, 1 line)

> Speed (-s): Sets how many lines per second. For example, -s 5 means 5 lines/second.

Default: 1

> Color (-c): Sets the text color. Options include:

```
r - red
b - blue
y - yellow
g - green
m - magenta
c - cyan
Default: white
```
`Example: -c y for yellow text.`

> Lines per Tick (-l): How many lines to print each interval.

Default: 1

> URL (-u) and Depth (-d): Fetches words from a given URL and optionally follows links up to a certain depth to gather more words.

If no URL is provided, a default URL inside dataFetcher is used.
Depth controls how many levels of links are followed.

Example:

```bash

tough-coder -u "https://example.com" -d 2
```
This crawls example.com and its linked pages (one level deep) to collect words, mixing them into the output.

Examples
Simple Default Run:

```bash
tough-coder
```
Prints random lines at speed=1 line/second, white color, infinite loop.

Fast Red Lines:

```bash
tough-coder -P-1 -s 10 -c r
```

Always print at 10 lines/sec, red text.

Multiple Scenarios:

```bash
tough-coder -P-0.5 -s 10 -c r -P-0.1 -s 3 -c y -l 5
```
- 50% of the time: red and fast
- 10% of the time: yellow, slower, and more lines
- 40% fallback: default white, speed=1, 1 line/tick

Using Web Data:

```bash
tough-coder -P-1 -s 5 -c g -u "https://example.com" -d 2
```
Green text at 5 lines/sec, mixing words from example.com and its linked pages (one link depth), with fallback to random words if no data is found.