# game-rotate2

# 游戏

##### 安装

```
npm install game-rotate2
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game": "game-rotate2/index"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "common-game"
  ]
}
```

- js

```
Page({
  data: {
    gameSource: {
      bgAni: {
        x: 0,
        y: 0,
        boomSpeed: 0.4,
        srcArr: [
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01Fne8ay1EUdNvKTrDq_!!2185320355.png", "name": "预合成 1_00000.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01zxLZej1EUdNzJKE62_!!2185320355.png", "name": "预合成 1_00001.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01C8JVNy1EUdO14Xbxx_!!2185320355.png", "name": "预合成 1_00002.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN015Y6eKY1EUdNzpGpax_!!2185320355.png", "name": "预合成 1_00003.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN010DI7qq1EUdNyL9QnI_!!2185320355.png", "name": "预合成 1_00004.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01Y4UiSJ1EUdNt7YVMO_!!2185320355.png", "name": "预合成 1_00005.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01qnHtKB1EUdNzJKYtT_!!2185320355.png", "name": "预合成 1_00006.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01Qq8suA1EUdNzpI6ac_!!2185320355.png", "name": "预合成 1_00007.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01JIGhF51EUdO14bIi7_!!2185320355.png", "name": "预合成 1_00008.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01uGl8Cn1EUdNxgjVC0_!!2185320355.png", "name": "预合成 1_00009.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01DkCQWP1EUdNxZLRVj_!!2185320355.png", "name": "预合成 1_00010.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01XToyhd1EUdO3s0smg_!!2185320355.png", "name": "预合成 1_00011.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01enkpTX1EUdO6iy8AA_!!2185320355.png", "name": "预合成 1_00012.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01rwuzeq1EUdO6j0scx_!!2185320355.png", "name": "预合成 1_00013.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01OGqM9l1EUdNzpKJor_!!2185320355.png", "name": "预合成 1_00014.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01N2OJZ31EUdO2kwRmO_!!2185320355.png", "name": "预合成 1_00015.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01l32LKO1EUdNoKUJzR_!!2185320355.png", "name": "预合成 1_00016.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01wihWaG1EUdO2kxmxi_!!2185320355.png", "name": "预合成 1_00017.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01vLzbMY1EUdNxZOScc_!!2185320355.png", "name": "预合成 1_00018.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01YNnYS91EUdNvKUC3f_!!2185320355.png", "name": "预合成 1_00019.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01LdAC2u1EUdO1zfcli_!!2185320355.png", "name": "预合成 1_00020.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01S9xESc1EUdO2kzrrp_!!2185320355.png", "name": "预合成 1_00021.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01cm5OzM1EUdO6izbct_!!2185320355.png", "name": "预合成 1_00022.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01xatmw71EUdO3rzsPv_!!2185320355.png", "name": "预合成 1_00023.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01BbaPnU1EUdNt7YuKn_!!2185320355.png", "name": "预合成 1_00024.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01raO1JW1EUdO3s0HNI_!!2185320355.png", "name": "预合成 1_00025.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01UplBYA1EUdNvKWGzx_!!2185320355.png", "name": "预合成 1_00026.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01RhhLE31EUdO3rzoFs_!!2185320355.png", "name": "预合成 1_00027.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01ipLFgk1EUdNxZLNMV_!!2185320355.png", "name": "预合成 1_00028.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01uctbIf1EUdNxZMJbY_!!2185320355.png", "name": "预合成 1_00029.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN013TZ8mp1EUdO1zghJ5_!!2185320355.png", "name": "预合成 1_00030.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN014JvS8P1EUdO3rz0Mb_!!2185320355.png", "name": "预合成 1_00031.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01CG9dpo1EUdO2kySZN_!!2185320355.png", "name": "预合成 1_00032.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01xQWwCO1EUdNt7Wd1C_!!2185320355.png", "name": "预合成 1_00033.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01vqqFro1EUdO1ziAlW_!!2185320355.png", "name": "预合成 1_00034.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01dGebow1EUdO14YHbM_!!2185320355.png", "name": "预合成 1_00035.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01ezovwz1EUdO2kxzSA_!!2185320355.png", "name": "预合成 1_00036.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01Rz6hxI1EUdNvKTO8n_!!2185320355.png", "name": "预合成 1_00037.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01DTVDOE1EUdNyL9y6G_!!2185320355.png", "name": "预合成 1_00038.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01mQ6cjS1EUdO3rzoGr_!!2185320355.png", "name": "预合成 1_00039.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN017thycO1EUdNuZ0PbQ_!!2185320355.png", "name": "预合成 1_00040.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01BjghuI1EUdNyL9pmS_!!2185320355.png", "name": "预合成 1_00041.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01ABpSzy1EUdO1zfl6e_!!2185320355.png", "name": "预合成 1_00042.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN016x6u4h1EUdNoKUixC_!!2185320355.png", "name": "预合成 1_00043.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN011sPY5Z1EUdNzpKO0q_!!2185320355.png", "name": "预合成 1_00044.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01qA1vCA1EUdO5tFWDy_!!2185320355.png", "name": "预合成 1_00045.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01L7ouxW1EUdO6j0sfs_!!2185320355.png", "name": "预合成 1_00046.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01dZMaTD1EUdO14apdO_!!2185320355.png", "name": "预合成 1_00047.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01eyg9DD1EUdNt7WhAp_!!2185320355.png", "name": "预合成 1_00048.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01U0929Y1EUdO6j1Hd8_!!2185320355.png", "name": "预合成 1_00049.png", "width": "750", "height": "878" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01vM9DOR1EUdO4dhkmN_!!2185320355.png", "name": "预合成 1_00050.png", "width": "750", "height": "878" },
        ]
      },
      pro: { src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01vbdUZM1EUdO6Uy0mv_!!2185320355.png", width: 273, height: 276, x: 220, y: 184, aniTop: -20, duration: 1, noClick: !true, clickDelay: 0 },
      item: {
        clickDelay: 1000,//点击了需要暂停多久
        x: 375,//椭圆x
        y: 365,//椭圆y
        w: 240,//椭圆宽
        h: 170,//椭圆高
        rotateSpeed: 0.01,//旋转速度
        baseRad: Math.PI * -0.1,// 初始旋转角度
        scale: { min: 0.4, max: 0.7 },//元素大小区间
        data: [
          {
            isLock: true
          },
          {
            isLock: true
          },
          {},
          {},
          {},
          {}
        ],
        active: { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN014ed8kp1EUdNyLSITE_!!2185320355.png", "name": "active.png", "width": "161", "height": "192" },
        def: { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01zsYJus1EUdNoKkMvb_!!2185320355.png", "name": "disabled.png", "width": "161", "height": "192" },
        ani: {
          x: 0,
          y: 0,
          boomSpeed: 0.4,
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01lydeup1EUdO1zmXSw_!!2185320355.png", "name": "123_00000.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01KTnhOm1EUdO4doCLC_!!2185320355.png", "name": "123_00001.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01KltRhp1EUdO3s7KJq_!!2185320355.png", "name": "123_00002.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01kx7QNh1EUdNxZSDo5_!!2185320355.png", "name": "123_00003.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01V7GKgu1EUdO5tJx0K_!!2185320355.png", "name": "123_00004.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01eMajok1EUdO2l2HuD_!!2185320355.png", "name": "123_00005.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN019eHUya1EUdO4dmn18_!!2185320355.png", "name": "123_00006.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01XOjegW1EUdO6j4dso_!!2185320355.png", "name": "123_00007.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01NYYdUz1EUdNzpPM2x_!!2185320355.png", "name": "123_00008.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01qUQqmT1EUdNxgq9F3_!!2185320355.png", "name": "123_00009.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01yl4nYb1EUdO3s6n3b_!!2185320355.png", "name": "123_00010.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN015DDbaY1EUdNyLFoBz_!!2185320355.png", "name": "123_00011.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01wCw9EH1EUdO5tM1tn_!!2185320355.png", "name": "123_00012.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN018lgZlk1EUdO4dkqPW_!!2185320355.png", "name": "123_00013.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01csLIm21EUdO6j6BVu_!!2185320355.png", "name": "123_00014.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01BGMoiq1EUdNzpPYYG_!!2185320355.png", "name": "123_00015.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN017kSwK51EUdNoKZYYh_!!2185320355.png", "name": "123_00016.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01yGdcKA1EUdNyLFbjM_!!2185320355.png", "name": "123_00017.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01BlMVp81EUdNuZ5JZp_!!2185320355.png", "name": "123_00018.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01aUNqxY1EUdO3s73i7_!!2185320355.png", "name": "123_00019.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01jS1hEb1EUdNuZ4AtZ_!!2185320355.png", "name": "123_00020.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01Nyh5JU1EUdNvKciVc_!!2185320355.png", "name": "123_00021.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01TRTF9P1EUdNuZ5775_!!2185320355.png", "name": "123_00022.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01WWscDR1EUdO4dleMN_!!2185320355.png", "name": "123_00023.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01WR9DCv1EUdO5tM1un_!!2185320355.png", "name": "123_00024.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01Ues1wX1EUdNuZ5Nka_!!2185320355.png", "name": "123_00025.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01zEkf0d1EUdO1znLOH_!!2185320355.png", "name": "123_00026.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01spczJ01EUdNzpMbat_!!2185320355.png", "name": "123_00027.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01GKpkBg1EUdNyLG0gk_!!2185320355.png", "name": "123_00028.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01R4ec2Z1EUdNt7bjLo_!!2185320355.png", "name": "123_00029.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01Q8ch091EUdNuZ7vl1_!!2185320355.png", "name": "123_00030.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN019uQvhO1EUdNzpNoSj_!!2185320355.png", "name": "123_00031.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01u80g5U1EUdO2l3Qai_!!2185320355.png", "name": "123_00032.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01Twx6sF1EUdNzpQUln_!!2185320355.png", "name": "123_00033.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN018knk9x1EUdNvKadeu_!!2185320355.png", "name": "123_00034.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01KuNvzp1EUdNvKcJae_!!2185320355.png", "name": "123_00035.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01EWEe4Q1EUdNoKZYaJ_!!2185320355.png", "name": "123_00036.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01HNPxhn1EUdO6j77lN_!!2185320355.png", "name": "123_00037.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01PLtQtd1EUdNxgnbHe_!!2185320355.png", "name": "123_00038.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01fPuT1M1EUdO6j4dvL_!!2185320355.png", "name": "123_00039.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01jIcoV11EUdNzpO9G5_!!2185320355.png", "name": "123_00040.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01NHpheo1EUdO2l2pD6_!!2185320355.png", "name": "123_00041.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01aExmKC1EUdNxZUMuX_!!2185320355.png", "name": "123_00042.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN015DeTSb1EUdNzJQKvD_!!2185320355.png", "name": "123_00043.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01HpFBse1EUdO3s4mNo_!!2185320355.png", "name": "123_00044.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01a2BmSM1EUdO3s88Hg_!!2185320355.png", "name": "123_00045.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01WnREVs1EUdNzJOrTQ_!!2185320355.png", "name": "123_00046.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01nWeMlp1EUdO5tK9VR_!!2185320355.png", "name": "123_00047.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01OuSHbX1EUdO14i9GS_!!2185320355.png", "name": "123_00048.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01e5ikeB1EUdNzJPCG1_!!2185320355.png", "name": "123_00049.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01Nt2BML1EUdO4dpCkl_!!2185320355.png", "name": "123_00050.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01e6Ou1B1EUdNvKcW51_!!2185320355.png", "name": "123_00051.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01Xt6Z8K1EUdNxZUyMI_!!2185320355.png", "name": "123_00052.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN018TzABG1EUdO2l3YwS_!!2185320355.png", "name": "123_00053.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01VEFsT21EUdO4dnrci_!!2185320355.png", "name": "123_00054.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01vAIoFL1EUdO5tMQuK_!!2185320355.png", "name": "123_00055.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01tUw7IR1EUdO4dmn4z_!!2185320355.png", "name": "123_00056.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01IGmCKS1EUdO5tNRJ7_!!2185320355.png", "name": "123_00057.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01VX2pRy1EUdO2l4ANF_!!2185320355.png", "name": "123_00058.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01Ai4gWB1EUdO1zoU8j_!!2185320355.png", "name": "123_00059.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01Vb3pVd1EUdO14ffRh_!!2185320355.png", "name": "123_00060.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01mtU04i1EUdO14iDQq_!!2185320355.png", "name": "123_00061.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01QWJAmX1EUdNxZUR6M_!!2185320355.png", "name": "123_00062.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01mXVV2i1EUdNoKY5CO_!!2185320355.png", "name": "123_00063.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01Q9mUlv1EUdNvKbqXq_!!2185320355.png", "name": "123_00064.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01QOSMYh1EUdNoKaECy_!!2185320355.png", "name": "123_00065.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01qB0d391EUdNxgoL4i_!!2185320355.png", "name": "123_00066.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01BSqBOD1EUdNt7cbQp_!!2185320355.png", "name": "123_00067.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01mMmfZ11EUdNzJPX3T_!!2185320355.png", "name": "123_00068.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01ppapuh1EUdNoKa1ji_!!2185320355.png", "name": "123_00069.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01E5ZeLQ1EUdO2l66xa_!!2185320355.png", "name": "123_00070.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01e691T31EUdNt7fksx_!!2185320355.png", "name": "123_00071.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN018Rum7l1EUdO14j5Vn_!!2185320355.png", "name": "123_00072.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01ZXP11z1EUdNzJR0UM_!!2185320355.png", "name": "123_00073.png", "width": "250", "height": "250" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01OOGOei1EUdO14iLls_!!2185320355.png", "name": "123_00074.png", "width": "250", "height": "250" },
          ]
        }
      }
    }
  },
  onInitDone(e) {
    this.gameComponent = e.ref;
  },
  onClickFun(e) {
    // 点击回调
    console.error(e)
  },

  startFun() {
    this.gameComponent.onEvent("start");
  },
  stopFun() {
    this.gameComponent.onEvent("stop");
  },
  unlockFun() {
    // 解锁对应卡片，0：对应item->data数组下标
    this.gameComponent.onEvent("openCard", 0)
  }
});
```

- xaml

```
<view class="pageBox">
  <view class="gameBox">
    <game gameSource="{{gameSource}}" onInitDone="onInitDone" onClick="onClickFun" />
  </view>
  <view class="btn-box2">
    <view class="btn_css" onTap="startFun">开始</view>
    <view class="btn_css" onTap="stopFun">停止</view>
    <view class="btn_css" onTap="unlockFun">解锁卡片</view>
  </view>
</view>
```

- xass

```
.pageBox{
  position: absolute;
  width: 750rpx;
  height: 1184rpx;
  left: 0;
  top: 0;
  background: url("https://img.alicdn.com/imgextra/i4/2185320355/O1CN01lHufKT1EUdO5tYS42_!!2185320355.png") no-repeat center;
  /* background-image: url("https://img.alicdn.com/imgextra/i2/2185320355/O1CN01HMMy1L1EUdO6jPBSG_!!2185320355.png"); */
  background-size: 100% 100%;
}
.gameBox{
  position: relative;
  margin-top: 150rpx;
  /* margin-top: 100rpx; */
  width: 750rpx;
  height: 878rpx;
  /* background: #ccc; */
}

.btn-box2 {
  width: 100vw;
  height: 50px;
  position: fixed;
  left: 0;
  bottom: 50px;
  display: flex;
}
.btn_css {
  width: 40%;
  height: 15px;
  padding: 10px;
  margin: 7px 10px;
  text-align: center;
  background-color: #ccc;
}
```