# Description:
#   Allows Hubot to do mathematics.
#
# Dependencies:
#   "mathjs": ">= 9.4.3"
#
# Configuration:
#   None
#
# Commands:
#   hubot calculate <expression> - Calculate the given math expression.
#   hubot convert <expression> in <units> - Convert expression to given units.
#
# Author:
#   mrinjamul <mrinjamul@gmail.com>

mathjs = require("mathjs")

module.exports = (robot) ->
  robot.respond /(calc|calculate|calculator|convert|math|maths)( me)? (.*)/i, (msg) ->
    try
      result = mathjs.evaluate msg.match[3]
      msg.send "#{result}"
    catch error
      msg.send error.message || 'Could not compute.'

  robot.hear /expr (.*)/i, (msg) ->
    try
      msg.send mathjs.evaluate(msg.match[1])+''
    catch error
      msg.send error.message || 'Could not compute.'
