import { ChartCreator, IDataSet } from './chart-creator/chart-creator';
import * as fs from 'fs';

const inputPath = process.argv[2];
const outputPath = process.argv[3];
const chartType = process.argv[4];

console.log(`datasource path: ${inputPath}`);
console.log(`export path: ${outputPath}.jpeg`);

const HELP = () => {
    console.log(`
  Example:
    npm start -- /tmp/data.json /tmp/chart line|bar
        => Output: /tmp/chart.jpeg

  Example JSON:
    [
        { 
            "label": "a", 
            "color": "rgba(255, 00, 00, 0.5)", 
            "data": [1, 2, 3, 4, 5, 6] 
        },{ 
            "label": "b", 
            "color": "rgba(255, 00, 00, 0.5)", 
            "data": [7, 2, 3, 1, 5, 5] 
        },
    ]
`)
}

if (inputPath && outputPath) {      
    fs.exists(inputPath, exists => {
        if (exists){
            const json = require(inputPath)
            ChartCreator.createChartFrom(
                json, 
                chartType, 
                outputPath
            );     
        } else {
            console.error("[!] invalid 'datasource path'");
            HELP();
        }
    });
} else {
    console.error("[!] missing arguments");
    HELP();
}