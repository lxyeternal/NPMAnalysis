import { ChartJSNodeCanvas } from "chartjs-node-canvas";
import * as fs from "fs";

export interface IDataSet {
    label: string;
    color: string;
    data: number[];
}
const DEFAULT_FONT_COLOR = "white";

const DEFAULT_CHART_OPTIONS = {
    legend: {
        fontColor: DEFAULT_FONT_COLOR
    },
    scales: {
        yAxes: [{
            ticks: {
                fontColor: DEFAULT_FONT_COLOR,
                beginAtZero: true,
                callback: (value: any) => value
            }
        }],
        xAxes: [{
            ticks: {
                fontColor: DEFAULT_FONT_COLOR,
                beginAtZero: true,
                callback: (value: any) => value
            }
        }]
    }
};

export const SUPPORTED_TYPES = ['bar', 'line'];

export class ChartCreator {
    
    static createChartFrom(datasets: IDataSet[], type: string, outFile: string, width=1200, height=800) {
        if(SUPPORTED_TYPES.includes(type)) {
            ChartCreator.createLineChartFrom(datasets, outFile, width, height);
        } else {
            ChartCreator.createBarChartFrom(datasets, outFile, width, height);
        }
    }

    static createBarChartFrom(datasets: IDataSet[], outFile: string, width=1200, height=800) {
        const chart = new ChartJSNodeCanvas({
            width,
            height
        });

        const chartStream = chart.renderToBufferSync(
            {
                type: 'bar',
                data: {
                    labels: datasets.map(dataSet => dataSet.label),
                    datasets: datasets
                        .map(dataSet => {
                            return {
                                label: dataSet.label,
                                data: dataSet.data,
                                backgroundColor: dataSet.color
                            }    
                        }),
                },
                options: DEFAULT_CHART_OPTIONS
            }, 
            "image/jpeg");
            fs.writeFile(outFile + ".jpeg", chartStream, () => {
        });
    }
    static createLineChartFrom(datasets: IDataSet[], outFile: string, width=1200, height=800) {
        const chart = new ChartJSNodeCanvas({
            width,
            height
        });

        const chartStream = chart.renderToBufferSync(
            {
                type: 'line',
                data: {
                    labels: datasets.map(dataSet => dataSet.label),
                    datasets: datasets
                        .map(dataSet => {
                            return {
                                label: dataSet.label,
                                data: dataSet.data,
                                borderColor: dataSet.color,
                                tension: 0.1
                            }    
                        }),
                },
                options: DEFAULT_CHART_OPTIONS
            }, 
            "image/jpeg");
            fs.writeFile(outFile + ".jpeg", chartStream, () => {
        });
    }
}