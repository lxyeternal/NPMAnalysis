# Simple Chart Generator

## Running the Chartgenerator

    npm start -- /tmp/data.json /tmp/chart line|bar
    
    => Output: /tmp/chart.jpeg

## Example input

    Example JSON:
        [
            { 
                "label": "a", 
                "color": "rgba(255, 00, 00, 0.5)", 
                "data": [1, 2, 3, 4, 5, 6] 
            },{ 
                "label": "b", 
                "color": "rgba(255, 00, 00, 0.5)", 
                "data": [7, 2, 3, 1, 5, 5] 
            },
        ]