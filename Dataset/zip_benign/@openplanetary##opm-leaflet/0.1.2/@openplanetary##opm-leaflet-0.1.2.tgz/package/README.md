# OPM-Leaflet
Leaflet plugin to handle OpenPlanetaryMap (OPM) basemaps. OPM datasets may be added in the future.

## Setting Up
1. Include Leaflet JavaScript and CSS (either a [hosted or downloaded](http://leafletjs.com/download.html) version).
2. Initialise a map.
3. Include the file `OPMBasemaps.js` _before_ the map initialisation script; this contains the main OPM basemaps.
4. Include the file `OPMLayers.js` _after_ the map initialisation script; this contains customisation options.
5. To change the initial basemaps / overlay, add the layers to the map in `OPMLayers.js`. All OPM layer names are listed below:
   + `basemapOPMVector` (OPM Vector)
   + `basemapTexture` (Shaded Mars Surface Texture)
   + `basemapMOLAGrey` (Shaded Grayscale MOLA Elevation)
   + `basemapMOLAColor` (Shaded Colour MOLA Elevation)
   + `basemapViking` (Global Viking MDIM2.1 Colorized Mosaic)
   + `basemapHillshade` (Global Hillshade)
   + `overlay` (Labels)

## Example
See below for example implementation. A working example can be found in the `/examples` folder, also at [openplanetary.co/opm-leaflet](http://openplanetary.co/opm-leaflet).

```html
<!-- Leaflet JS and CSS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.2.0/dist/leaflet.css">
<script src="https://unpkg.com/leaflet@1.2.0/dist/leaflet.js"></script>

<!-- OPM Plugin basemaps -->
<script src="src/OPMBasemaps.js"></script>

<!-- Initialise map -->
<script>
  const map = L.map('map', {
    center: [0, 0],
    maxBounds: [
      [-90, -Infinity],
      [90, Infinity],
    ],
    maxBoundsViscosity: 0.5
  }).setView([11.8, -45.04], 3);
</script>

<!-- OPM Plugin layer options -->
<script src="src/OPMLayers.js"></script>
```
