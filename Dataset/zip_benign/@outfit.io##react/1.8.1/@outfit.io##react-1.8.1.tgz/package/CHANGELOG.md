# @outfit.io/react

## 1.8.1

### Patch Changes

- e8c85ef: updated background transparency logic

## 1.8.0

### Minor Changes

- 76d1794: added custom cropSize prop to Page component

## 1.7.1

### Patch Changes

- 767df96: Limiter message font unit changed to rem

## 1.7.0

### Minor Changes

- d0466d1: Add overflowMessage prop

## 1.6.0

### Minor Changes

- 7ba8d2a: Added BackgroundImage component

## 1.5.0

### Minor Changes

- 29f51b1: Add ensureAllImagesLoad prop to Limiter

## 1.4.0

### Minor Changes

- 4d130c4: Add data attributes to limiter to improve debugging

## 1.3.0

### Minor Changes

- 5bfc928: added trimSize and bleedSize props

## 1.2.1

### Patch Changes

- c751731: Fix repo tool dimensions - not sent under some circumstances from Image component

## 1.2.0

### Minor Changes

- 26b8cd2: Add onClick prop to Image and Limiter components

## 1.1.0

### Minor Changes

- dc3dd1b: adding trimColor prop

## 1.0.1

### Patch Changes

- d8ae52b: updating onInlineEditClick to depricate onInlineEditClickOnChild allowing for a optional second atrribute t opass to stop propergation. also will only run function if inputIds != null to prevent error message when attempting to

## 1.0.0

### Major Changes

- 5a9e7b0: Add Image component. NOT actually a breaking change from 0.7.3, but time to move to a major version as the package is now sufficiently mature.

## 0.7.3

### Patch Changes

- f0318d6: add string as acceptable type to maxHeight prop-types

## 0.7.2

### Patch Changes

- 52711c1: Adding import for onInlineEditClickOnChild

## 0.7.1

### Patch Changes

- 81e52f0: fix error caused by missing prop-types package

## 0.7.0

### Minor Changes

- 5b4dc62: adds React version of Outfit Limiter
  adds character limit feature to the Limiter
  adds runValidation and lineCount utility functions
  adds a feature to the Page component to set the document state (preview vs export) and the browser type on the body and the window

## 0.6.0

### Minor Changes

- 0689c8d: added onInlineEditClickOnChild function to enable selecable inputs on child components and element without event bubbling

## 0.5.0

### Minor Changes

- d01f676: adding helper functions for inline editing

## 0.4.0

### Minor Changes

- 769eeec: Add mystery pixel & background color props

## 0.3.0

### Minor Changes

- e6d0aee: Added placeholder component

## 0.2.1

### Patch Changes

- 3c189df: moved format into metadata

## 0.2.0

### Minor Changes

- dd539c6: added custom trim per side via global CSS vars and support for format sizes

## 0.1.2

### Patch Changes

- 420de66: Fixed readme

## 0.1.1

### Patch Changes

- 028e33b: Added storybook

## 0.1.0

### Minor Changes

- 5d47a18: Added release workflow
