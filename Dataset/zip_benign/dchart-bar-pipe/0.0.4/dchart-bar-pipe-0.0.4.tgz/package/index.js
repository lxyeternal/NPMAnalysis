var Bar = require('dchart-core/bar/bar');
var d3 = require('d3');
var _ = require('dchart-core/util');

function BarBox(container, options) {
  var opt = {
    margin : {top: 20, right: 20, bottom: 30, left: 80},
    xaxis : {
      type: 'category',
      padding: [0.9, 0.4],
      dy: 40
    },
    yaxis: {
    }
  };
  _.deepMerge(opt, options);
  Bar.call(this, container, opt);
};
BarBox = Bar.extend(BarBox, {
  afterRender : function () {
    Bar.prototype.afterRender.call(this);
    var opt = this.options;
    var svg = this.svg;

    var axis = this.getComs('axis', 'xaxis');
    var x = axis.getX();
    var bars = this.series.selectAll('.series-group');

    var ykey = opt.yaxis.key;
    var xkey = opt.xaxis.key;
    bars.each(function (data) {
      var that = d3.select(this);
      var bg = that.select('.serie-bg')[0][0] ? that.select('.serie-bg') : that.append('rect')
        .attr({
          'class' : 'serie-bg',
          'y' : -3
        }).style('fill', 'none');

      bg.attr({
        'x' : function (d) {return x(data[xkey]); },
        'width' : x.rangeBand(),
        'height' : opt.innerHeight + 6,
      })

      var label = that.select('.serie-label')[0][0] ? that.select('.serie-label') : that.insert('text')
        .attr({
          'class': 'serie-label',
          'y' : -16,
        });

      label.attr({
        'x' : function (d) {return x(data[xkey]) + 6; },
      }).text(function (d) {
        return data[ykey][0];
      })
    });
  },
  updateAfterRender : function () {
    BarBox.prototype.afterRender.call(this);
  }
});

module.exports = BarBox;
