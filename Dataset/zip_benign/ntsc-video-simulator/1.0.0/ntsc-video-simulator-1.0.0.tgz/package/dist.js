(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.NtscVideo = f()}})(function(){var define,module,exports;return (function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
module.exports = function(strings) {
  if (typeof strings === 'string') strings = [strings]
  var exprs = [].slice.call(arguments,1)
  var parts = []
  for (var i = 0; i < strings.length-1; i++) {
    parts.push(strings[i], exprs[i] || '')
  }
  parts.push(strings[i])
  return parts.join('')
}

},{}],"/index.js":[function(require,module,exports){
var glsl = require('glslify')

module.exports = TV

function TV(opts) {
  if (!(this instanceof TV)) return new TV(opts)
  this._regl = opts.regl
  var widths = Array.isArray(opts.width)
    ? opts.width : [ opts.width || 1024, opts.width || 1024]
  this.shadowMask = opts.shadowMask !== undefined ? opts.shadowMask : 0.1
  this._mtick = 0
  this._dtick = 0

  this._fbOpts = [262,263,262,263,525].map((height,i) => ({
    color: this._regl.texture({
      width: widths[i%2],
      height,
    })
  }))
  this._fbo = this._fbOpts.map(this._regl.framebuffer)
  this._nlines = 0
  this._src = 0
  this._dst = 0
  this._src0 = 0
  this._src1 = 0

  this._setfb = this._regl({
    framebuffer: () => this._fbo[this._dst]
  })
  this._setf = this._regl({
    framebuffer: () => this._fbo[this._dst],
    uniforms: {
      signal: () => this._fbo[this._src],
      n_lines: () => this._nlines,
    }
  })
  this._setd = this._regl({
    uniforms: {
      tick: () => this._dtick
    }
  })

  this._size = [0,0]
  this._mdraw = this._regl({
    frag: glsl(["\n      precision highp float;\n#define GLSLIFY 1\n\n      vec3 rgb_to_yiq_1540259130(vec3 rgb) {\n  float y = 0.30*rgb.x + 0.59*rgb.y + 0.11*rgb.z;\n  return vec3(\n    y,\n    -0.27*(rgb.z-y) + 0.74*(rgb.x-y),\n    0.41*(rgb.z-y) + 0.48*(rgb.x-y)\n  );\n}\n\n//const float FSC = 5e6*63.0/88.0;\nconst float FSC = 3579545.5; // 5e6*63.0/88.0\nconst float PI = 3.1415927410125732;\nconst float L_TIME_1604150559 = 6.35555e-5;\nconst float P_TIME_1604150559 = 5.26e-5;\nconst float FP_TIME_1604150559 = 1.5e-6;\nconst float SP_TIME_1604150559 = 4.7e-6;\nconst float BW_TIME_1604150559 = 0.6e-6;\nconst float CB_TIME_1604150559 = 2.5e-6;\nconst float BP_TIME_1604150559 = 1.6e-6;\nconst float Q_TIME_1604150559 = 2.71e-5;\nconst float EQ_TIME_1604150559 = 2.3e-6;\n\nfloat modulate_t_1604150559(float t, vec3 rgb) {\n  vec3 yiq = rgb_to_yiq_1540259130(rgb);\n  float s = sin(2.0*PI*t*FSC);\n  float c = cos(2.0*PI*t*FSC);\n  return yiq.x*(100.0-7.5) + (c*yiq.y + s*yiq.z)*20.0 + 7.5;\n}\n\nfloat modulate_uv_1604150559(vec2 uv, float n_lines, vec3 rgb) {\n  float v_lines = n_lines - 20.0;\n  float t = uv.x*P_TIME_1604150559 + floor(uv.y*(v_lines-1.0)+0.5)*P_TIME_1604150559;\n  return modulate_t_1604150559(t, rgb);\n}\n\nfloat modulate(vec2 v, float n_lines, sampler2D picture) {\n  float v_lines = n_lines - 20.0;\n  float line = floor((1.0-v.y)*n_lines+0.5);\n  vec2 uv = v\n    * vec2(L_TIME_1604150559/P_TIME_1604150559, n_lines/v_lines)\n    - vec2((L_TIME_1604150559-P_TIME_1604150559)/P_TIME_1604150559, 0);\n  float hblank = step(v.x, (L_TIME_1604150559-P_TIME_1604150559)/L_TIME_1604150559);\n  float vblank = step(1.0-(n_lines-v_lines)/n_lines, v.y);\n\n  float odd = mod(n_lines,2.0);\n  float vsync_pre = step(0.0,line)*step(line, 3.0);\n  float vsync_pulse = step(3.0,line)*step(line,6.0);\n  float vsync_post = step(6.0,line)*step(line,9.0);\n\n  float vt = 0.0;\n  float fporch = step(v.x,FP_TIME_1604150559/L_TIME_1604150559);\n  vt += FP_TIME_1604150559/L_TIME_1604150559;\n  float syncpulse = step(vt,v.x) * step(v.x,vt+SP_TIME_1604150559/L_TIME_1604150559);\n  vt += SP_TIME_1604150559/L_TIME_1604150559;\n  float breezeway = step(vt,v.x) * step(v.x,vt+BW_TIME_1604150559/L_TIME_1604150559);\n  vt += BW_TIME_1604150559/L_TIME_1604150559;\n  float colorburst = step(vt,v.x) * step(v.x,vt+CB_TIME_1604150559/L_TIME_1604150559);\n  vt += CB_TIME_1604150559/L_TIME_1604150559;\n  float bporch = step(vt,v.x) * step(v.x,vt+BP_TIME_1604150559/L_TIME_1604150559);\n  vec3 rgb = texture2D(picture,uv).xyz;\n  float signal = modulate_uv_1604150559(v, n_lines, rgb);\n  signal *= 1.0 - hblank;\n  signal -= 40.0 * syncpulse;\n  signal += sin(2.0*PI*FSC)*20.0*colorburst;\n  signal *= 1.0 - vblank;\n  signal -= 40.0 * vsync_pre * step(mod(v.x,0.5)*L_TIME_1604150559,EQ_TIME_1604150559);\n  signal -= 40.0 * vsync_pulse * step(mod(v.x,0.5)*L_TIME_1604150559,Q_TIME_1604150559);\n  signal -= 40.0 * vsync_post * step(mod(v.x,0.5)*L_TIME_1604150559,EQ_TIME_1604150559);\n  return (signal + 40.0) / (120.0+40.0);\n}\n\n      varying vec2 vpos;\n      uniform float n_lines;\n      uniform sampler2D src;\n      void main () {\n        gl_FragColor = vec4(modulate(vpos*0.5+0.5, n_lines, src),0,0,1);\n      }\n    ",""]),
    vert: `
      precision highp float;
      attribute vec2 position;
      varying vec2 vpos;
      void main () {
        vpos = position;
        gl_Position = vec4(position,0,1);
      }
    `,
    attributes: { position: [-4,-4,-4,+4,+4,+0] },
    elements: [0,1,2],
    framebuffer: this._regl.prop('framebuffer'),
    uniforms: {
      n_lines: this._regl.prop('n_lines'),
      src: () => this._fbo[4]
    }
  })
  this._ddraw = this._regl({
    frag: glsl(["\n      precision highp float;\n#define GLSLIFY 1\n\n      const float FSC = 3579545.5; //5e6*63.0/88.0;\nconst float PI_0 = 3.1415927410125732;\nconst float M = 2.7936508217862865e-7; // 1.0/FSC;\nconst float T_LINE_1604150559 = 5.26e-5;\nconst float L_TIME_1604150559 = 6.35555e-5;\nconst float P_TIME_1604150559 = 5.26e-5;\nconst float RSQ3 = 0.5773502588272095; // 1.0/sqrt(3.0);\n\nvec3 yiq_to_rgb_1540259130(vec3 yiq) {\n  return vec3(\n    yiq.x + 0.9469*yiq.y + 0.6236*yiq.z,\n    yiq.x - 0.2748*yiq.y - 0.6357*yiq.z,\n    yiq.x - 1.1*yiq.y + 1.7*yiq.z\n  );\n}\n\nvec4 read(float t, float n_lines, sampler2D signal) {\n  return texture2D(signal, vec2(\n    mod(t,T_LINE_1604150559)/T_LINE_1604150559,\n    floor(t/T_LINE_1604150559)/(n_lines-1.0)\n  ));\n}\n\nvec3 demodulate_t_1604150559(float t, float n_lines, sampler2D signal) {\n  float f = 1.0, m = 2.0*f;\n  float ti = t - mod(t,M/m);\n  float tq = t - mod(t,M/m) + M*0.25/f;\n  float ta = t - mod(t,M/m) + M*0.50/f;\n\n  float signal_i = read(ti, n_lines, signal).x*(120.0+40.0)-40.0;\n  float signal_q = read(tq, n_lines, signal).x*(120.0+40.0)-40.0;\n  float signal_a = read(ta, n_lines, signal).x*(120.0+40.0)-40.0;\n  float signal_b = read(t, n_lines, signal).x*(120.0+40.0)-40.0;\n\n  float min_y = min(signal_i,signal_q);\n  min_y = min(min_y,signal_a);\n  float max_y = max(signal_i, signal_q);\n  max_y = max(max_y,signal_a);\n  float y = min_y*0.5 + max_y*0.5;\n\n  float s = sin(2.0*PI_0*FSC*t*f);\n  float c = cos(2.0*PI_0*FSC*t*f);\n  vec3 yiq = vec3(\n    (y-7.5)/(100.0-7.5),\n    (signal_i-y)/20.0 * sign(s),\n    (signal_q-y)/20.0 * sign(s)\n  );\n  vec3 rgb = clamp(vec3(0), vec3(1), yiq_to_rgb_1540259130(yiq));\n  float d = max(rgb.x,max(rgb.y,rgb.z))-min(rgb.x,min(rgb.y,rgb.z));\n  float v = (signal_b-7.5+(c*yiq.y+s*yiq.z)*20.0)/(100.0-7.5)*2.0-1.0;\n  float p = pow(abs(v),2.2)*sign(v)*pow(max(d,length(rgb)*RSQ3),2.2);\n  return clamp(vec3(0), vec3(1), mix(rgb,vec3(p*0.5+0.5),abs(p)));\n}\n\nvec3 demodulate_uv_1604150559(vec2 uv, float n_lines, sampler2D signal) {\n  float v_lines = n_lines - 20.0;\n  float t = uv.x*T_LINE_1604150559 + floor(uv.y*(v_lines-1.0)+0.5)*T_LINE_1604150559;\n  return demodulate_t_1604150559(t, v_lines, signal);\n}\n\nvec3 demodulate(vec2 v, vec3 n, sampler2D signal) {\n  float v_lines = n.x - 20.0;\n  vec2 uv = v * vec2(P_TIME_1604150559/L_TIME_1604150559, v_lines/n.x) - vec2(P_TIME_1604150559/L_TIME_1604150559, 0);\n  float odd = floor(mod(uv.x*n.y,2.0));\n  float sy = odd/n.z*0.5;\n  vec2 ruv = vec2(\n    floor(uv.x*n.y+0.5)/n.y,\n    floor(uv.y*n.z+odd*0.5)/n.z\n  );\n  return demodulate_uv_1604150559(ruv, n.x, signal);\n}\n\n      uniform sampler2D signal0, signal1;\n      varying vec2 vpos;\n      uniform float tick, shadowMask;\n      const float PI = ",";\n      const float L_TIME = 6.35555e-5;\n      const float P_TIME = 5.26e-5;\n      void main () {\n        vec2 v = vpos*0.5+0.5;\n        vec2 r = vec2(720, 485);\n        vec3 rgb0 = demodulate(v, vec3(262,r), signal0);\n        vec3 rgb1 = demodulate(v, vec3(263,r), signal1);\n        vec3 rgb = mix(rgb0,rgb1,sin(v.y*PI*2.0*242.5)*0.5+0.5);\n        float sy = floor(mod(v.x*r.x,2.0))/r.x*0.5;\n        vec3 mask = vec3(\n          step(mod(v.x*r.x*3.0+2.0,3.0),1.0),\n          step(mod(v.x*r.x*3.0+1.0,3.0),1.0),\n          step(mod(v.x*r.x*3.0+0.0,3.0),1.0)\n        ) * (1.0-step(mod(((v.y+sy)*r.y)*3.0,3.0),0.5));\n        vec3 c = mix(rgb,rgb*mask,shadowMask);\n        //vec3 c = vec3(texture2D(signal0,v).x);\n        gl_FragColor = vec4(c,1);\n      }\n    ",""],Math.PI),
    vert: `
      precision highp float;
      attribute vec2 position;
      varying vec2 vpos;
      void main () {
        vpos = position;
        gl_Position = vec4(position,0,1);
      }
    `,
    attributes: { position: [-4,-4,-4,+4,+4,+0] },
    elements: [0,1,2],
    uniforms: {
      signal0: this._regl.prop('signal0'),
      signal1: this._regl.prop('signal1'),
      tick: this._regl.context('tick'),
      size: (context) => {
        this._size[0] = context.viewportWidth
        this._size[1] = context.viewportWidth
        return this._size
      },
      shadowMask: () => this.shadowMask
    }
  })
}

TV.prototype._updateFb = function (n) {
  this._fbo[n](this._fbOpts[n])
}

TV.prototype.modulate = function (fn) {
  this._src0 = 0
  this._src1 = 1
  this._updateFb(4)
  this._dst = 4
  this._setfb(fn)
  this._dst = this._mtick%2
  this._updateFb(this._dst)
  this._nlines = this._mtick%2 ? 263 : 262
  this._mdraw({
    n_lines: this._nlines,
    framebuffer: this._fbo[this._dst]
  })
  this._mtick++
}

TV.prototype.filter = function (fn) {
  this._src = this._dst
  this._dst += 2
  this._updateFb(this._dst)
  this._setf(fn)
  this._src0 += 2
  this._src1 += 2
}

/* // todo:
TV.prototype.load = function (opts) {
  // opts.width
  // opts.height
  // opts.data
}

TV.prototype.sync = function (data) {
  this.vsync()
  this.hsync()
}

TV.prototype.vsync = function (data) {
}

TV.prototype.hsync = function (data) {
}
*/

TV.prototype.demodulate = function () {
  this._regl.poll()
  this._regl.clear({ color: [0,0,0,1], depth: true })
  this._setd(() => {
    this._ddraw({
      signal0: this._fbo[this._src0],
      signal1: this._fbo[this._src1],
    })
  })
}

},{"glslify":1}]},{},[])("/index.js")
});
