#!/bin/bash
NODE_BIN='/opt/nodejs_10.33/bin'
PATH=$PATH:$NODE_BIN
export FIREFOX_BIN='/home/luser/.firefox_selenium/firefox'
LOCAL_MODULES='/home/luser/projects_ext/nodes_modules/grunt_plugins/'
MODULES_BIN=$LOCAL_MODULES/.bin/
export NODE_PATH=`$NODE_BIN/npm root -g`:$LOCAL_MODULES

#echo $MODULES_BIN
if [[ $1 == node ]]; then
echo "Start node module"
$NODE_BIN/$1 $MODULES_BIN/$2 $3 $4 $5 $6 $7 $8 $9
else
echo "Start $1"
$NODE_BIN/$1 $2 $3 $4 $5 $6 $7 $8 $9
fi
echo "=================================================================="
