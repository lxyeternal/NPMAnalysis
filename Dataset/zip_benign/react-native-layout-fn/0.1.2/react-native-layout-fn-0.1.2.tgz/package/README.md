# react-native-layout-fn

A React-Native utility belt for layout your apps UI across different sized devices.

## Installation
```js
npm install --save react-native-layout-fn
//or:
yarn add react-native-layout-fn
```

## Api
### Scaling Functions
```js
import {createScaledSheet} from 'react-native-layout-fn';
const {scale, scaleModerate} = createScaledSheet(414/375) // ratio

const Component = props =>
    <View style={{
        width: scale(30),
        height: scale(50),
        padding: scaleModerate(5)
    }}/>;
```


* `scale(size: number)`  
Will return linear scaled result of the provided size, based on your device's screen width.

* `scaleModerate(size: number, factor?: number)`  
Sometimes you don't want to scale everything in a linear manner, that's where moderate scale comes in.  
The cool thing about it is that you can control the resize factor (default is 0.5).  
If normal scale will increase your size by +2X, moderateScale will only increase it by +X, for example:  

### ScaledSheet
```js
import { createScaledSheet } from 'react-native-layout-fn';
const scaledSheet = createScaledSheet(414/375) // ratio

const styles = scaledSheet.create(stylesObject)
const inlineStyle = scaledSheet.inlineStyle(stylesObject)
```

ScaleSheet will take the same stylesObject a regular StyleSheet will take, plus a special (optional) annotation that will automatically apply the scale functions for you:
* `<size>@s` - will apply `scale` function on `size`.
* `<size>@ms` - will apply `scaleModerate` function with resize factor of 0.5 on `size`.
* `<size>@ms<factor>` - will apply `scaleModerate` function with resize factor of `factor` on size.

Example:
```jsx
import { createScaledSheet } from 'react-native-layout-fn';
const scaledSheet = createScaledSheet(414/375) // ratio
const {inlineStyle} = scaledSheet

const styles = scaledSheet.create({
    container: {
        width: '100@s', // = scale(100)
        height: '200@s', // = scale(200)
        margin: 5
    },
    row: {
        padding: '10@ms0.3', // = scaleModerate(10, 0.3)
        height: '50@ms' // = scaleModerate(50)
    }
});

// render

render() {
    return (
        <View style={inlineStyle({width: '350@s', height: '100@s', margin: '10@ms'})}>
        </View>
    )
}
```
