module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _react = __webpack_require__(0);

var _react2 = _interopRequireDefault(_react);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var defaultAnimation = "{\n  from { opacity: 0; transform: translateY(-10px); }\n  to { opacity: 1; transform: translateY(0); }\n}";

var BlanketAnimation = function (_React$Component) {
  _inherits(BlanketAnimation, _React$Component);

  function BlanketAnimation(props) {
    _classCallCheck(this, BlanketAnimation);

    var _this = _possibleConstructorReturn(this, (BlanketAnimation.__proto__ || Object.getPrototypeOf(BlanketAnimation)).call(this, props));

    _this.state = {
      animationFinished: []
      // array of booleans for each child to determine displaying animation styles
    };

    var _this$props = _this.props,
        ssr = _this$props.ssr,
        animation = _this$props.animation,
        animationName = _this$props.animationName;

    // If not server side rendering and the document/stylesheet is available,
    // apply the animation to the stylesheet

    if (!ssr && document && document.styleSheets[0]) {
      var styleSheet = document.styleSheets[0];
      var appliedAnimation = "@keyframes " + animationName + " " + animation;

      styleSheet.insertRule(appliedAnimation, styleSheet.cssRules.length);
    }
    return _this;
  }

  _createClass(BlanketAnimation, [{
    key: "applyAnimationStyle",
    value: function applyAnimationStyle(child, index) {
      var _this2 = this;

      var _props = this.props,
          initialStyle = _props.initialStyle,
          animationName = _props.animationName,
          duration = _props.duration,
          delay = _props.delay,
          delayOffset = _props.delayOffset;

      // Merge original style with animation style with initial style

      var style = Object.assign({}, _extends({}, child.props.style, {
        animationName: animationName,
        animationDuration: duration + "s",
        animationDelay: delay + index * delayOffset + "s",
        animationFillMode: "forwards"
      }, initialStyle));

      // Animation finish time
      var finishTime = (delay + index * delayOffset + duration) * 1000;

      // Set the animation finish boolean to true when the animation completes
      setTimeout(function () {
        return _this2.setState(function (prevState) {
          var newAnimationFinished = prevState.animationFinished.slice();
          newAnimationFinished[index] = true;

          return { animationFinished: newAnimationFinished };
        });
      }, finishTime);

      return _react2.default.cloneElement(child, { style: style });
    }
  }, {
    key: "applyCompletionStyle",
    value: function applyCompletionStyle(child, index) {
      var completionStyle = this.props.completionStyle;


      var style = Object.assign({}, _extends({}, child.props.style, completionStyle));

      return _react2.default.cloneElement(child, { style: style });
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      var children = this.props.children;


      if (!children) return "";

      return _react2.default.Children.map(children, function (child, index) {
        if (_this3.state.animationFinished[index]) {
          return _this3.applyCompletionStyle(child, index);
        } else {
          return _this3.applyAnimationStyle(child, index);
        }
      });
    }
  }]);

  return BlanketAnimation;
}(_react2.default.Component);

exports.default = BlanketAnimation;


BlanketAnimation.defaultProps = {
  ssr: false,
  delay: 0,
  duration: 1,
  delayOffset: 0.1,
  initialStyle: { opacity: 0 },
  completionStyle: {},
  animation: defaultAnimation,
  animationName: "blanketAnimationFadeIn"
};

/***/ })
/******/ ]);