const _tsneez = require('./tsneez.js')

console.log('Starting tests.')

let tsneez_test_1 = new _tsneez.TSNEEZ()

let test_1 = { 
    perplexity: 10,
    numNeighbors: 30,
    theta: 0.5,
    learningRateStart: 5,
    earlyExaggerationStart: 8,
    dims: 2 }

if (tsneez_test_1.perplexity === 10 && 
    tsneez_test_1.numNeighbors === 30 &&
    tsneez_test_1.theta === 0.5 &&
    tsneez_test_1.learningRateStart === 5 &&
    tsneez_test_1.earlyExaggerationStart === 8 &&
    tsneez_test_1.dims === 2
    ) {
        console.log('Test 1 -> Passed')
} else {
    console.log('Test 1 -> Failed')
    throw new Error('Test 1 -> Failed')
}
    

// Hyper parameters
let opt = {}
opt.theta = 0.9 // theta
opt.perplexity = 20 // perplexity

let tsneez_test_2 = new _tsneez.TSNEEZ(opt)

if (tsneez_test_2.perplexity === 20 && 
    tsneez_test_2.numNeighbors === 60 &&
    tsneez_test_2.theta === 0.9 &&
    tsneez_test_2.learningRateStart === 5 &&
    tsneez_test_2.earlyExaggerationStart === 8 &&
    tsneez_test_2.dims === 2
    ) {
        console.log('Test 2 -> Passed')
} else {
    console.log('Test 2 -> Failed')
    throw new Error('Test 2 -> Failed')
}

console.log('Ending tests.')