# tsneez - High Dimensional Visualization Simplified
tsneez is a fast javascript implementation of T-SNE with tree-based acceleration. It simplifies embedding high dimensional data to two-dimensional clusters that can be easily visualized.

## Example code:
Data passed as high dimensional pairwise dissimilar vectors are embedded to an array of 2-dimensional vectors.
```
const _tsneez = require('tsneez')

// Hyper parameters
let opt = {}
opt.theta = 0.5 // theta
opt.perplexity = 10 // perplexity
const GRADIENT_STEPS = 5000 


var tsneez = new _tsneez.TSNEEZ(opt) // create a tsneez instance

// Initialize data. We have four high dimensional pairwise dissimilar vectors
const vecs = [
    [0.418, 0.24968, -0.41242, 0.1217, 0.34527],
    [0.013441, 0.23682, -0.16899, 0.40951, 0.63812],
    [0.15164, 0.30177, -0.16763, 0.17684, 0.31719],
    [0.70853, 0.57088, -0.4716, 0.18048, 0.54449],
]
tsneez.initData(vecs)

// A function that applies tsneez algorithm to reduce high dimensional vectors
function dimensionReduce(vecs) {

    tsneez.initData(vecs)

    for(var k = 0; k < GRADIENT_STEPS ; k++) {
        tsneez.step() // gradient update
        console.log(`Step : ${k}`)
    }

    var Y = tsneez.Y 

    return Y 
}

// Execute dimensionality reduction
let Y = dimensionReduce(vecs) // Y is an array of 2-dimensional vectors that you can visualize.

```

## Visualization
tsneez allows you to visualize high dimensional vectorized data to 2-dimensional vectors. This live [example](https://rajpurkar.github.io/tsneez/) demos tsneez capability to generate beautiful visualization to an interactive SVG with smooth transitions and interaction. tsneez is extremely fast, supports large datasets and through visual imagery communicates comprehension of abstract patterns to concrete ones - high dimensional visualization made simple!

## Web
Here’s an [overview](https://github.com/rajpurkar/tsneez#readme) of how to customize and implement tsneez code to easily create web apps.

## Author
Pranav Rajpurkar

## License
MIT