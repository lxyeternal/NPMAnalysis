# Pepe React Component

A React Three.js component for rendering an animated Pepe 3D model.

## Installation

```bash
npm install i-am-pepe
```

## Usage

First, make sure you have the required peer dependencies installed:

```bash
npm install @react-three/fiber @react-three/drei three
```

Then, use the component in your React application:

```jsx
import { Canvas } from "@react-three/fiber";
import { PepeModel } from "i-am-pepe";

function App() {
  return (
    <Canvas>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
      <PepeModel position={[0, 0, 0]} />
    </Canvas>
  );
}
```

Make sure to place your `pepe.glb` model file in your public directory so it can be accessed at `/pepe.glb`.

## Props

The component accepts all standard Three.js group props from `@react-three/fiber`, including:

- `position`: [x, y, z] coordinates
- `rotation`: [x, y, z] rotation in radians
- `scale`: number or [x, y, z] scale factors

## License

MIT
