const math = require('ez-math.js')
module.exports = {
  random: function random(array) {
  if(Array.isArray(array)) {
    return array[Math.floor(Math.random() * array.length)]
  } else {
  if(typeof array == 'string') {
    var splitArray = array.split(',')
    return splitArray[Math.floor(Math.random() * splitArray.length)]
  } else {
    return undefined
  }
}
},
  add: function add(array) {
    return math.add(array)
  },
  subtr: function subtr(array) {
    return math.subtr(array)
  },
  div: function div(array) {
    return math.div(array)
  },
  multi: function multi(array) {
    return math.multi(array)
  },
  pow: function pow(array) {
    return math.pow(array)
  },
  randomInt: function randomInt(Min, Max)  {
    if(Max && !isNaN(Max)) {
      max = Number(Max)
    } else {
      max = 0
    }
    if(Min && !isNaN(Min)) {
      min = Number(Min)
    } else {
      min = 0
    }
    return Math.floor(Math.random() * max) + min
  },
  avg: function avg(array) {
    return math.avg(array)
  }
  }