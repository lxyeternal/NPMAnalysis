<!--

@license Apache-2.0

Copyright (c) 2022 The Stdlib Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

-->


<details>
  <summary>
    About stdlib...
  </summary>
  <p>We believe in a future in which the web is a preferred environment for numerical computation. To help realize this future, we've built stdlib. stdlib is a standard library, with an emphasis on numerical and scientific computation, written in JavaScript (and C) for execution in browsers and in Node.js.</p>
  <p>The library is fully decomposable, being architected in such a way that you can swap out and mix and match APIs and functionality to cater to your exact preferences and use cases.</p>
  <p>When you use stdlib, you can be absolutely certain that you are using the most thorough, rigorous, well-written, studied, documented, tested, measured, and high-quality code out there.</p>
  <p>To join us in bringing numerical computing to the web, get started by checking us out on <a href="https://github.com/stdlib-js/stdlib">GitHub</a>, and please consider <a href="https://opencollective.com/stdlib">financially supporting stdlib</a>. We greatly appreciate your continued support!</p>
</details>

# asech

[![NPM version][npm-image]][npm-url] [![Build Status][test-image]][test-url] [![Coverage Status][coverage-image]][coverage-url] <!-- [![dependencies][dependencies-image]][dependencies-url] -->

> Compute the [hyperbolic arcsecant][hyperbolic-arcsecant] of a number.

<section class="installation">

## Installation

```bash
npm install @stdlib/math-base-special-asech
```

</section>

<section class="usage">

## Usage

```javascript
var asech = require( '@stdlib/math-base-special-asech' );
```

#### asech( x )

Computes the [hyperbolic arcsecant][hyperbolic-arcsecant] of `x`.

```javascript
var v = asech( 1.0 );
// returns 0.0

v = asech( 0.5 );
// returns ~1.317

v = asech( 0.0 );
// returns Infinity
```

The domain of `x` is restricted to the interval `[0, 1]`. For `x` outside of this interval, the function returns `NaN`.

```javascript
var v = asech( -1.0 );
// returns NaN

v = asech( 2.0 );
// returns NaN
```

</section>

<!-- /.usage -->

<section class="examples">

## Examples

<!-- eslint no-undef: "error" -->

```javascript
var linspace = require( '@stdlib/array-base-linspace' );
var asech = require( '@stdlib/math-base-special-asech' );

var x = linspace( 0.1, 1.0, 100 );

var i;
for ( i = 0; i < x.length; i++ ) {
    console.log( asech( x[ i ] ) );
}
```

</section>

<!-- /.examples -->

<!-- C interface documentation. -->

* * *

<section class="c">

## C APIs

<!-- Section to include introductory text. Make sure to keep an empty line after the intro `section` element and another before the `/section` close. -->

<section class="intro">

</section>

<!-- /.intro -->

<!-- C usage documentation. -->

<section class="usage">

### Usage

```c
#include "stdlib/math/base/special/asech.h"
```

#### stdlib_base_asech( x )

Computes the [hyperbolic arcsecant][hyperbolic-arcsecant] of `x`.

```c
double out = stdlib_base_asech( 1.0 );
// returns 0.0
```

The function accepts the following arguments:

-   **x**: `[in] double` input value.

```c
double stdlib_base_asech( const double x );
```

</section>

<!-- /.usage -->

<!-- C API usage notes. Make sure to keep an empty line after the `section` element and another before the `/section` close. -->

<section class="notes">

</section>

<!-- /.notes -->

<!-- C API usage examples. -->

<section class="examples">

### Examples

```c
#include "stdlib/math/base/special/asech.h"
#include <stdio.h>

int main( void ) {
    const double x[] = { 0.0, 0.5, 1.0, 1.89, 2.33, 3.22, 3.67, 4.11, 4.56, 5.0 };
    
    double v;
    int i;
    for ( i = 0; i < 10; i++ ) {
        v = stdlib_base_asech( x[ i ] );
        printf( "asech(%lf) = %lf\n", x[ i ], v );
    }
}
```

</section>

<!-- /.examples -->

</section>

<!-- /.c -->

<!-- Section for related `stdlib` packages. Do not manually edit this section, as it is automatically populated. -->

<section class="related">

* * *

## See Also

-   <span class="package-name">[`@stdlib/math-base/special/acosh`][@stdlib/math/base/special/acosh]</span><span class="delimiter">: </span><span class="description">compute the hyperbolic arccosine of a double-precision floating-point number.</span>
-   <span class="package-name">[`@stdlib/math-base/special/asec`][@stdlib/math/base/special/asec]</span><span class="delimiter">: </span><span class="description">compute the inverse (arc) secant of a number.</span>
-   <span class="package-name">[`@stdlib/math-base/special/asech`][@stdlib/math/base/special/asech]</span><span class="delimiter">: </span><span class="description">compute the hyperbolic arcsecant of a number.</span>
-   <span class="package-name">[`@stdlib/math-base/special/acoth`][@stdlib/math/base/special/acoth]</span><span class="delimiter">: </span><span class="description">compute the inverse hyperbolic cotangent.</span>

</section>

<!-- /.related -->

<!-- Section for all links. Make sure to keep an empty line after the `section` element and another before the `/section` close. -->


<section class="main-repo" >

* * *

## Notice

This package is part of [stdlib][stdlib], a standard library for JavaScript and Node.js, with an emphasis on numerical and scientific computing. The library provides a collection of robust, high performance libraries for mathematics, statistics, streams, utilities, and more.

For more information on the project, filing bug reports and feature requests, and guidance on how to develop [stdlib][stdlib], see the main project [repository][stdlib].

#### Community

[![Chat][chat-image]][chat-url]

---

## License

See [LICENSE][stdlib-license].


## Copyright

Copyright &copy; 2016-2024. The Stdlib [Authors][stdlib-authors].

</section>

<!-- /.stdlib -->

<!-- Section for all links. Make sure to keep an empty line after the `section` element and another before the `/section` close. -->

<section class="links">

[npm-image]: http://img.shields.io/npm/v/@stdlib/math-base-special-asech.svg
[npm-url]: https://npmjs.org/package/@stdlib/math-base-special-asech

[test-image]: https://github.com/stdlib-js/math-base-special-asech/actions/workflows/test.yml/badge.svg?branch=v0.3.0
[test-url]: https://github.com/stdlib-js/math-base-special-asech/actions/workflows/test.yml?query=branch:v0.3.0

[coverage-image]: https://img.shields.io/codecov/c/github/stdlib-js/math-base-special-asech/main.svg
[coverage-url]: https://codecov.io/github/stdlib-js/math-base-special-asech?branch=main

<!--

[dependencies-image]: https://img.shields.io/david/stdlib-js/math-base-special-asech.svg
[dependencies-url]: https://david-dm.org/stdlib-js/math-base-special-asech/main

-->

[chat-image]: https://img.shields.io/gitter/room/stdlib-js/stdlib.svg
[chat-url]: https://app.gitter.im/#/room/#stdlib-js_stdlib:gitter.im

[stdlib]: https://github.com/stdlib-js/stdlib

[stdlib-authors]: https://github.com/stdlib-js/stdlib/graphs/contributors

[umd]: https://github.com/umdjs/umd
[es-module]: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules

[deno-url]: https://github.com/stdlib-js/math-base-special-asech/tree/deno
[deno-readme]: https://github.com/stdlib-js/math-base-special-asech/blob/deno/README.md
[umd-url]: https://github.com/stdlib-js/math-base-special-asech/tree/umd
[umd-readme]: https://github.com/stdlib-js/math-base-special-asech/blob/umd/README.md
[esm-url]: https://github.com/stdlib-js/math-base-special-asech/tree/esm
[esm-readme]: https://github.com/stdlib-js/math-base-special-asech/blob/esm/README.md
[branches-url]: https://github.com/stdlib-js/math-base-special-asech/blob/main/branches.md

[stdlib-license]: https://raw.githubusercontent.com/stdlib-js/math-base-special-asech/main/LICENSE

[hyperbolic-arcsecant]: https://en.wikipedia.org/wiki/Inverse_hyperbolic_function

<!-- <related-links> -->

[@stdlib/math/base/special/acosh]: https://www.npmjs.com/package/@stdlib/math-base-special-acosh

[@stdlib/math/base/special/asec]: https://www.npmjs.com/package/@stdlib/math-base-special-asec

[@stdlib/math/base/special/asech]: https://www.npmjs.com/package/@stdlib/math-base-special-asech

[@stdlib/math/base/special/acoth]: https://www.npmjs.com/package/@stdlib/math-base-special-acoth

<!-- </related-links> -->

</section>

<!-- /.links -->
