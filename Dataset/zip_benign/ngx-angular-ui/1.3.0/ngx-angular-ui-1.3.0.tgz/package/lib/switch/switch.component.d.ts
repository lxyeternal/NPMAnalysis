import { EventEmitter, OnChanges, OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class SwitchElement implements OnInit, OnChanges {
    _disabled: boolean;
    label: string;
    size: 'sm' | 'md' | 'lg';
    color: 'default' | 'info' | 'help' | 'success' | 'warning' | 'danger';
    checked: boolean;
    switchChange: EventEmitter<boolean>;
    set disabled(value: boolean | string);
    switchClass: string;
    sizeClass: string;
    colorClass: string;
    get disabled(): boolean;
    ngOnInit(): void;
    ngOnChanges(): void;
    private applyClasses;
    private getSizeClass;
    private getColorClass;
    onSwitchChange(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SwitchElement, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SwitchElement, "[uiSwitch]", never, { "label": { "alias": "label"; "required": false; }; "size": { "alias": "size"; "required": false; }; "color": { "alias": "color"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "switchChange": "switchChange"; }, never, never, true, never>;
}
