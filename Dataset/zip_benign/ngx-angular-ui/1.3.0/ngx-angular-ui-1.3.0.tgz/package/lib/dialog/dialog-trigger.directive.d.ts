import { DialogService } from './dialog.service';
import * as i0 from "@angular/core";
export declare class DialogTriggerElement {
    private dialogService;
    dialogId: string;
    constructor(dialogService: DialogService);
    onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogTriggerElement, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DialogTriggerElement, "[uiDialogTrigger]", never, { "dialogId": { "alias": "dialogId"; "required": false; }; }, {}, never, never, true, never>;
}
