import { ElementRef, OnChanges, OnInit, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class DialogFooterElement implements OnInit, OnChanges {
    private el;
    private renderer;
    class: string;
    constructor(el: ElementRef, renderer: Renderer2);
    ngOnInit(): void;
    ngOnChanges(): void;
    private applyClasses;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogFooterElement, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DialogFooterElement, "[uiDialogFooter]", never, { "class": { "alias": "class"; "required": false; }; }, {}, never, never, true, never>;
}
