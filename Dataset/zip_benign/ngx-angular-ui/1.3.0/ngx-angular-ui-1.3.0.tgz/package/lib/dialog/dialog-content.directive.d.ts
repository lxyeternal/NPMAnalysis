import { ElementRef, OnChanges, OnInit, Renderer2 } from '@angular/core';
import { DialogElement } from './dialog.directive';
import { DialogService } from './dialog.service';
import * as i0 from "@angular/core";
export declare class DialogContentElement implements OnInit, OnChanges {
    private el;
    private renderer;
    private _dialogService;
    private dialog;
    size: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl' | '4xl' | '5xl';
    class: string;
    constructor(el: ElementRef, renderer: Renderer2, _dialogService: DialogService, dialog: DialogElement);
    ngOnInit(): void;
    ngOnChanges(): void;
    private applyClasses;
    onClick(event: Event): void;
    private getSizeClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogContentElement, [null, null, null, { optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DialogContentElement, "[uiDialogContent]", never, { "size": { "alias": "size"; "required": false; }; "class": { "alias": "class"; "required": false; }; }, {}, never, never, true, never>;
}
