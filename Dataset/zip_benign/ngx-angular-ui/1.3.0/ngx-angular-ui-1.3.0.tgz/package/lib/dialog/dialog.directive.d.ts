import { ElementRef, OnChanges, OnInit, Renderer2 } from '@angular/core';
import { DialogService } from './dialog.service';
import * as i0 from "@angular/core";
export declare class DialogElement implements OnInit, OnChanges {
    private el;
    private renderer;
    private dialogService;
    size: 'sm' | 'md' | 'lg' | 'xl';
    isOpenDialog: boolean;
    class: string;
    dialogId: string;
    private dialogSubscription;
    constructor(el: ElementRef, renderer: Renderer2, dialogService: DialogService);
    ngOnInit(): void;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    private updateClasses;
    onCloseDialog(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogElement, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DialogElement, "[uiDialog]", never, { "size": { "alias": "size"; "required": false; }; "isOpenDialog": { "alias": "isOpenDialog"; "required": false; }; "class": { "alias": "class"; "required": false; }; "dialogId": { "alias": "dialogId"; "required": false; }; }, {}, never, never, true, never>;
}
