import { ElementRef, OnChanges, OnInit, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ButtonElement implements OnInit, OnChanges {
    private el;
    private renderer;
    variant: 'primary' | 'secondary' | 'outline' | 'ghost' | 'link';
    color: 'info' | 'help' | 'success' | 'warning' | 'danger';
    size: 'sm' | 'md' | 'lg' | 'icon';
    rounded: 'md' | 'lg' | 'full';
    class: string;
    constructor(el: ElementRef, renderer: Renderer2);
    ngOnInit(): void;
    ngOnChanges(): void;
    private applyClasses;
    private getVariantClass;
    private getColorClass;
    private getSizeClass;
    private getRoundedClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonElement, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ButtonElement, "[uiButton]", never, { "variant": { "alias": "variant"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; "rounded": { "alias": "rounded"; "required": false; }; "class": { "alias": "class"; "required": false; }; }, {}, never, never, true, never>;
}
