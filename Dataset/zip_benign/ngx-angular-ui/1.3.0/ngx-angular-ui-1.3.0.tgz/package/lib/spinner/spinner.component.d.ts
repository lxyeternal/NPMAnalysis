import { OnChanges, OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class SpinnerElement implements OnInit, OnChanges {
    size: 'xs' | 'sm' | 'lg' | 'xl';
    color: 'default' | 'primary' | 'secondary' | 'success' | 'warning' | 'danger';
    sizeClass: string;
    colorClass: string;
    ngOnInit(): void;
    ngOnChanges(): void;
    private applyClasses;
    private getSizeClass;
    private getColorClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<SpinnerElement, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SpinnerElement, "[uiSpinner]", never, { "size": { "alias": "size"; "required": false; }; "color": { "alias": "color"; "required": false; }; }, {}, never, never, true, never>;
}
