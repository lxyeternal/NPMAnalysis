import { ElementRef, OnChanges, OnInit, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class BadgeElement implements OnInit, OnChanges {
    private el;
    private renderer;
    variant: 'primary' | 'secondary' | 'outline';
    color: 'info' | 'help' | 'success' | 'warning' | 'danger';
    rounded: 'md' | 'lg' | 'full';
    size: 'sm' | 'md' | 'lg';
    class: string;
    constructor(el: ElementRef, renderer: Renderer2);
    ngOnInit(): void;
    ngOnChanges(): void;
    ngAfterViewInit(): void;
    private applyClasses;
    private applyIconClass;
    private getVariantClass;
    private getColorClass;
    private getRoundedClass;
    private getSizeClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<BadgeElement, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BadgeElement, "[uiBadge]", never, { "variant": { "alias": "variant"; "required": false; }; "color": { "alias": "color"; "required": false; }; "rounded": { "alias": "rounded"; "required": false; }; "size": { "alias": "size"; "required": false; }; "class": { "alias": "class"; "required": false; }; }, {}, never, never, true, never>;
}
