import { ElementRef, OnChanges, OnInit, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class AvatarElement implements OnInit, OnChanges {
    private el;
    private renderer;
    private _border;
    radius: 'full' | 'lg' | 'md' | 'sm';
    size: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
    color: 'primary' | 'info' | 'help' | 'success' | 'warning' | 'danger';
    status: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left';
    class: string;
    set border(value: boolean | string);
    get border(): boolean;
    constructor(el: ElementRef, renderer: Renderer2);
    ngOnInit(): void;
    ngOnChanges(): void;
    private applyClasses;
    private getRadiusClass;
    private getSizeClass;
    private getColorClass;
    private getStatusClass;
    private getStatusSizeClass;
    private getStatusColorClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<AvatarElement, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AvatarElement, "[uiAvatar]", never, { "radius": { "alias": "radius"; "required": false; }; "size": { "alias": "size"; "required": false; }; "color": { "alias": "color"; "required": false; }; "status": { "alias": "status"; "required": false; }; "class": { "alias": "class"; "required": false; }; "border": { "alias": "border"; "required": false; }; }, {}, never, never, true, never>;
}
