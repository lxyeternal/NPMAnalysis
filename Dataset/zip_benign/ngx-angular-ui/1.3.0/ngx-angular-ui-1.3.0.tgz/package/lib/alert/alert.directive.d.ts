import { ElementRef, OnChanges, OnInit, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class AlertElement implements OnInit, OnChanges {
    private el;
    private renderer;
    _showIcon: boolean;
    variant: 'primary' | 'outline' | 'primary-inline' | 'outline-inline';
    color: 'default' | 'info' | 'help' | 'success' | 'warning' | 'danger';
    class: string;
    set showIcon(value: boolean | string);
    get showIcon(): boolean;
    constructor(el: ElementRef, renderer: Renderer2);
    ngOnInit(): void;
    ngOnChanges(): void;
    ngAfterViewInit(): void;
    private applyClasses;
    private applyIconClass;
    private getColorClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertElement, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AlertElement, "[uiAlert]", never, { "variant": { "alias": "variant"; "required": false; }; "color": { "alias": "color"; "required": false; }; "class": { "alias": "class"; "required": false; }; "showIcon": { "alias": "showIcon"; "required": false; }; }, {}, never, never, true, never>;
}
