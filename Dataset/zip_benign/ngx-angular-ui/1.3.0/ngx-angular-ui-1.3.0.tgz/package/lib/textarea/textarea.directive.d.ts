import { ElementRef, OnChanges, OnInit, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class TextareaElement implements OnInit, OnChanges {
    private el;
    private renderer;
    class: string;
    constructor(el: ElementRef, renderer: Renderer2);
    ngOnInit(): void;
    ngOnChanges(): void;
    private applyClasses;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextareaElement, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TextareaElement, "[uiTextarea]", never, { "class": { "alias": "class"; "required": false; }; }, {}, never, never, true, never>;
}
