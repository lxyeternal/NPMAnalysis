import * as i0 from '@angular/core';
import { Directive, Input, Injectable, HostListener, Optional, Host, Component, EventEmitter, Output } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

class AlertDescriptionElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'text-sm';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: AlertDescriptionElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: AlertDescriptionElement, isStandalone: true, selector: "[uiAlertDescription]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: AlertDescriptionElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiAlertDescription]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class AlertTitleElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'font-semibold text-sm leading-none tracking-tight mb-1';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: AlertTitleElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: AlertTitleElement, isStandalone: true, selector: "[uiAlertTitle]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: AlertTitleElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiAlertTitle]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class AlertElement {
    set showIcon(value) {
        this._showIcon = value === '' || value === 'true';
    }
    get showIcon() {
        return this._showIcon;
    }
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this._showIcon = false;
        this.variant = 'outline';
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    ngAfterViewInit() {
        this.applyIconClass();
    }
    applyClasses() {
        const colorClass = this.getColorClass(this.variant, this.color);
        const iconClass = this.showIcon ? '[&>div]:ml-8 relative' : '';
        const inlineClass = this.variant === 'primary-inline' || this.variant === 'outline-inline' ? 'flex items-center gap-2 [&>div]:mb-0' : '';
        const classes = `${colorClass} ${iconClass} ${inlineClass} ${this.class} w-full px-4 py-3 rounded-lg border`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    applyIconClass() {
        if (this._showIcon) {
            const svg = this.el.nativeElement.querySelector('svg');
            if (svg) {
                this.renderer.addClass(svg, 'absolute');
            }
        }
    }
    getColorClass(variant, color) {
        switch (color) {
            case 'default':
                return `${variant === 'outline' || variant === 'outline-inline' ?
                    'border-zinc-200 dark:text-neutral-50 dark:border-zinc-800' :
                    'text-white border-zinc-900 bg-zinc-900 dark:text-zinc-200 dark:border-zinc-800 dark:bg-zinc-800'}`;
            case 'info':
                return `${variant === 'outline' || variant === 'outline-inline' ?
                    'text-blue-600 border-blue-600 dark:text-blue-700 dark:border-blue-700' :
                    'text-blue-200 border-blue-800 bg-blue-800'}`;
            case 'help':
                return `${variant === 'outline' || variant === 'outline-inline' ?
                    'text-violet-600 border-violet-600 dark:text-violet-700 dark:border-violet-700' :
                    'text-violet-200 border-violet-800 bg-violet-800'}`;
            case 'success':
                return `${variant === 'outline' || variant === 'outline-inline' ?
                    'text-green-600 border-green-600 dark:text-lime-700 dark:border-lime-700' :
                    'text-lime-200 border-lime-800 bg-lime-800'}`;
            case 'warning':
                return `${variant === 'outline' || variant === 'outline-inline' ?
                    'text-orange-600 border-orange-600 dark:text-orange-700 dark:border-orange-700' :
                    'text-orange-200 border-orange-800 bg-orange-800'}`;
            case 'danger':
                return `${variant === 'outline' || variant === 'outline-inline' ?
                    'text-red-600 border-red-600 dark:text-red-700 dark:border-red-700' :
                    'text-red-200 border-red-800 bg-red-800'}`;
            default:
                return `${variant === 'outline' || variant === 'outline-inline' ?
                    'border-zinc-200 dark:text-neutral-50 dark:border-zinc-800' :
                    'text-white border-zinc-900 bg-zinc-900 dark:text-zinc-200 dark:border-zinc-800 dark:bg-zinc-800'}`;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: AlertElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: AlertElement, isStandalone: true, selector: "[uiAlert]", inputs: { variant: "variant", color: "color", class: "class", showIcon: "showIcon" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: AlertElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiAlert]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { variant: [{
                type: Input
            }], color: [{
                type: Input
            }], class: [{
                type: Input
            }], showIcon: [{
                type: Input
            }] } });

class AvatarElement {
    set border(value) {
        this._border = value === '' || value === 'true';
    }
    get border() {
        return this._border;
    }
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this._border = false;
        this.radius = 'full';
        this.size = 'lg';
        this.color = 'primary';
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const radiusClass = this.getRadiusClass(this.radius);
        const sizeClass = this.getSizeClass(this.size);
        const colorClass = this.getColorClass(this.color);
        const borderClass = this.border ? 'ring-2 ring-offset-2 ring-offset-white dark:ring-offset-zinc-950' : '';
        const statusClass = this.getStatusClass(this.status);
        const classes = `${radiusClass} ${sizeClass} ${colorClass} ${borderClass} ${statusClass} ${this.class} flex items-center justify-center text-zinc-800 align-middle box-border bg-zinc-300 dark:bg-zinc-400 relative`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
        const img = this.el.nativeElement.querySelector('img');
        if (img) {
            const imgClasses = `w-full h-full object-cover ${radiusClass}`;
            this.renderer.setAttribute(img, 'class', imgClasses);
        }
    }
    getRadiusClass(radius) {
        switch (radius) {
            case 'full':
                return 'rounded-full';
            case 'lg':
                return 'rounded-3xl';
            case 'md':
                return 'rounded-xl';
            case 'sm':
                return 'rounded-lg';
            default:
                return 'rounded-full';
        }
    }
    getSizeClass(size) {
        switch (size) {
            case 'xs':
                return 'w-6 h-6 min-w-6 min-h-6';
            case 'sm':
                return 'w-8 h-8 min-w-8 min-h-8';
            case 'md':
                return 'w-10 h-10 min-w-10 min-h-10';
            case 'lg':
                return 'w-14 h-14 min-w-14 min-h-14';
            case 'xl':
                return 'w-20 h-20 min-w-20 min-h-20';
            default:
                return 'w-14 h-14 min-w-14 min-h-14';
        }
    }
    getColorClass(color) {
        switch (color) {
            case 'primary':
                return 'ring-zinc-300';
            case 'info':
                return 'ring-blue-600';
            case 'help':
                return 'ring-violet-600';
            case 'success':
                return 'ring-green-600';
            case 'warning':
                return 'ring-orange-600';
            case 'danger':
                return 'ring-red-600';
            default:
                return 'ring-zinc-300';
        }
    }
    getStatusClass(status) {
        const baseClass = 'before:rounded-full before:transform before:border-2 before:border-white before:dark:border-zinc-950 before:absolute';
        const sizeClass = this.getStatusSizeClass(this.size);
        const colorClass = this.getStatusColorClass(this.color);
        switch (status) {
            case 'top-right':
                return `${baseClass} ${sizeClass} ${colorClass} before:top-0 before:right-0 before:translate-x-0.5 before:-translate-y-0.5`;
                ;
            case 'top-left':
                return `${baseClass} ${sizeClass} ${colorClass} before:top-0 before:left-0 before:-translate-x-0.5 before:-translate-y-0.5`;
                ;
            case 'bottom-right':
                return `${baseClass} ${sizeClass} ${colorClass} before:bottom-0 before:right-0 before:translate-x-0.5 before:translate-y-0.5`;
                ;
            case 'bottom-left':
                return `${baseClass} ${sizeClass} ${colorClass} before:bottom-0 before:left-0 before:-translate-x-0.5 before:translate-y-0.5`;
                ;
            default:
                return '';
        }
    }
    getStatusSizeClass(size) {
        switch (size) {
            case 'xs':
                return 'before:w-2.5 before:h-2.5';
            case 'sm':
                return 'before:w-3 before:h-3';
            case 'md':
                return 'before:w-3 before:h-3';
            case 'lg':
                return 'before:w-4 before:h-4';
            case 'xl':
                return 'before:w-5 before:h-5';
            default:
                return 'before:w-3 before:h-3';
        }
    }
    getStatusColorClass(color) {
        switch (color) {
            case 'primary':
                return 'before:bg-zinc-300';
            case 'info':
                return 'before:bg-blue-600';
            case 'help':
                return 'before:bg-violet-600';
            case 'success':
                return 'before:bg-green-600';
            case 'warning':
                return 'before:bg-orange-600';
            case 'danger':
                return 'before:bg-red-600';
            default:
                return 'before:bg-green-600';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: AvatarElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: AvatarElement, isStandalone: true, selector: "[uiAvatar]", inputs: { radius: "radius", size: "size", color: "color", status: "status", class: "class", border: "border" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: AvatarElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiAvatar]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { radius: [{
                type: Input
            }], size: [{
                type: Input
            }], color: [{
                type: Input
            }], status: [{
                type: Input
            }], class: [{
                type: Input
            }], border: [{
                type: Input
            }] } });

class BadgeElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.variant = 'primary';
        this.rounded = 'md';
        this.size = 'sm';
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    ngAfterViewInit() {
        this.applyIconClass();
    }
    applyClasses() {
        const variantClass = this.getVariantClass(this.variant, this.color);
        const colorClass = this.getColorClass(this.variant, this.color);
        const roundedClass = this.getRoundedClass(this.rounded);
        const sizeClass = this.getSizeClass(this.size);
        const classes = `${variantClass} ${colorClass} ${roundedClass} ${sizeClass} ${this.class} inline-flex items-center justify-center font-medium transition-colors border`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    applyIconClass() {
        const svg = this.el.nativeElement.querySelector('svg');
        if (svg) {
            this.renderer.addClass(svg, 'mr-1');
        }
    }
    getVariantClass(variant, color) {
        switch (variant) {
            case 'primary':
                return `shadow-sm ${color ? '' : 'text-white bg-zinc-900 hover:bg-zinc-900/90 dark:text-zinc-900 dark:bg-neutral-50 dark:hover:bg-zinc-50/90'}`;
            case 'secondary':
                return 'text-zinc-900 bg-zinc-100 hover:bg-zinc-100/80 shadow-sm dark:text-white dark:border-zinc-800 dark:bg-zinc-800 dark:hover:bg-zinc-800/80';
            case 'outline':
                return `shadow-sm ${color ? '' : 'text-zinc-900 border border-zinc-200 bg-white hover:bg-zinc-100 dark:text-neutral-50 dark:border-zinc-800 dark:bg-transparent dark:hover:bg-zinc-800'}`;
            default:
                return 'text-white shadow-sm bg-zinc-900 hover:bg-zinc-900/90 dark:text-zinc-900 dark:bg-neutral-50 dark:hover:bg-zinc-50/90';
        }
    }
    getColorClass(variant, color) {
        switch (color) {
            case 'info':
                return `${variant === 'outline' ?
                    'text-blue-600 border-blue-600 dark:text-blue-700 dark:border-blue-700' :
                    'text-blue-200 border-blue-800 bg-blue-800'}`;
            case 'help':
                return `${variant === 'outline' ?
                    'text-violet-600 border-violet-600 dark:text-violet-700 dark:border-violet-700' :
                    'text-violet-200 border-violet-800 bg-violet-800'}`;
            case 'success':
                return `${variant === 'outline' ?
                    'text-green-600 border-green-600 dark:text-lime-700 dark:border-lime-700' :
                    'text-lime-200 border-lime-800 bg-lime-800'}`;
            case 'warning':
                return `${variant === 'outline' ?
                    'text-orange-600 border-orange-600 dark:text-orange-700 dark:border-orange-700' :
                    'text-orange-200 border-orange-800 bg-orange-800'}`;
            case 'danger':
                return `${variant === 'outline' ?
                    'text-red-600 border-red-600 dark:text-red-700 dark:border-red-700' :
                    'text-red-200 border-red-800 bg-red-800'}`;
            default:
                return '';
        }
    }
    getRoundedClass(rounded) {
        switch (rounded) {
            case 'md':
                return 'rounded-md';
            case 'lg':
                return 'rounded-lg';
            case 'full':
                return 'rounded-full';
            default:
                return 'rounded-md';
        }
    }
    getSizeClass(size) {
        switch (size) {
            case 'sm':
                return 'text-xs px-2.5 py-0.5';
            case 'md':
                return 'text-xs px-3 py-1';
            case 'lg':
                return 'text-sm px-3.5 py-1';
            default:
                return 'text-xs px-2.5 py-0.5';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: BadgeElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: BadgeElement, isStandalone: true, selector: "[uiBadge]", inputs: { variant: "variant", color: "color", rounded: "rounded", size: "size", class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: BadgeElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiBadge]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { variant: [{
                type: Input
            }], color: [{
                type: Input
            }], rounded: [{
                type: Input
            }], size: [{
                type: Input
            }], class: [{
                type: Input
            }] } });

class ButtonElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.variant = 'primary';
        this.size = 'md';
        this.rounded = 'md';
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const variantClass = this.getVariantClass(this.variant);
        const sizeClass = this.getSizeClass(this.size);
        const colorClass = this.getColorClass(this.color);
        const roundedClass = this.getRoundedClass(this.rounded);
        const classes = `${variantClass} ${sizeClass} ${colorClass} ${roundedClass} ${this.class} inline-flex items-center justify-center font-medium text-sm transition-colors disabled:cursor-not-allowed disabled:opacity-50`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    getVariantClass(variant) {
        switch (variant) {
            case 'primary':
                return `shadow-sm ${this.color ? '' : 'text-white bg-zinc-900 hover:bg-zinc-900/90 dark:text-zinc-900 dark:bg-neutral-50 dark:hover:bg-zinc-50/90'}`;
            case 'secondary':
                return 'text-zinc-900 bg-zinc-100 hover:bg-zinc-100/80 shadow-sm dark:text-white dark:bg-zinc-800 dark:hover:bg-zinc-800/80';
            case 'outline':
                return `shadow-sm ${this.color ? 'border' : 'text-zinc-900 border border-zinc-200 bg-white hover:bg-zinc-100 dark:text-neutral-50 dark:border-zinc-800 dark:bg-transparent dark:hover:bg-zinc-800'}`;
            case 'ghost':
                return ` ${this.color ? '' : 'text-zinc-900 hover:bg-zinc-100 dark:text-neutral-50 dark:hover:bg-zinc-800'} `;
            case 'link':
                return `underline-offset-4 hover:underline ${this.color ? '' : 'text-zinc-900 dark:text-neutral-50'}`;
            default:
                return 'text-white shadow-sm bg-zinc-900 hover:bg-zinc-900/90 dark:text-zinc-900 dark:bg-neutral-50 dark:hover:bg-zinc-50/90';
        }
    }
    getColorClass(color) {
        switch (color) {
            case 'info':
                return `${this.variant === 'outline' ?
                    'text-blue-600 border-blue-600 dark:text-blue-700 dark:border-blue-700' :
                    this.variant === 'ghost' ?
                        'text-blue-600 hover:text-blue-200 hover:bg-blue-800' :
                        this.variant === 'link' ?
                            'text-blue-600' :
                            'text-blue-200 bg-blue-800 hover:bg-blue-800/90'}`;
            case 'help':
                return `${this.variant === 'outline' ?
                    'text-violet-600 border-violet-600 dark:text-violet-700 dark:border-violet-700' :
                    this.variant === 'ghost' ?
                        'text-violet-600 hover:text-violet-200 hover:bg-violet-800' :
                        this.variant === 'link' ?
                            'text-violet-600' :
                            'text-violet-200 bg-violet-800 hover:bg-violet-800/90'}`;
            case 'success':
                return `${this.variant === 'outline' ?
                    'text-green-600 border-green-600 dark:text-lime-700 dark:border-lime-700' :
                    this.variant === 'ghost' ?
                        'text-lime-600 hover:text-lime-200 hover:bg-lime-800' :
                        this.variant === 'link' ?
                            'text-lime-600' :
                            'text-lime-200 bg-lime-800 hover:bg-lime-800/90'}`;
            case 'warning':
                return `${this.variant === 'outline' ?
                    'text-orange-600 border-orange-600 dark:text-orange-700 dark:border-orange-700' :
                    this.variant === 'ghost' ?
                        'text-orange-600 hover:text-orange-200 hover:bg-orange-800' :
                        this.variant === 'link' ?
                            'text-orange-600' :
                            'text-orange-200 bg-orange-800 hover:bg-orange-800/90'}`;
            case 'danger':
                return `${this.variant === 'outline' ?
                    'text-red-600 border-red-600 dark:text-red-700 dark:border-red-700' :
                    this.variant === 'ghost' ?
                        'text-red-600 hover:text-red-200 hover:bg-red-800' :
                        this.variant === 'link' ?
                            'text-red-600' :
                            'text-red-200 bg-red-800 hover:bg-red-800/90'}`;
            default:
                return '';
        }
    }
    getSizeClass(size) {
        switch (size) {
            case 'sm':
                return 'min-h-8 px-3 text-xs';
            case 'md':
                return 'min-h-9 px-4';
            case 'lg':
                return 'min-h-10 px-8';
            case 'icon':
                return 'min-w-9 min-h-9';
            default:
                return 'min-h-9 px-4';
        }
    }
    getRoundedClass(rounded) {
        switch (rounded) {
            case 'full':
                return 'rounded-full';
            case 'lg':
                return 'rounded-lg';
            case 'md':
                return 'rounded-md';
            default:
                return 'rounded-md';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: ButtonElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: ButtonElement, isStandalone: true, selector: "[uiButton]", inputs: { variant: "variant", color: "color", size: "size", rounded: "rounded", class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: ButtonElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiButton]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { variant: [{
                type: Input
            }], color: [{
                type: Input
            }], size: [{
                type: Input
            }], rounded: [{
                type: Input
            }], class: [{
                type: Input
            }] } });

class CardContentElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'p-6 pt-0';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: CardContentElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: CardContentElement, isStandalone: true, selector: "[uiCardContent]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: CardContentElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiCardContent]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class CardDescriptionElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'font-normal text-sm text-zinc-500 dark:text-white/70';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: CardDescriptionElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: CardDescriptionElement, isStandalone: true, selector: "[uiCardDescription]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: CardDescriptionElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiCardDescription]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class CardFooterElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'p-6 pt-0';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: CardFooterElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: CardFooterElement, isStandalone: true, selector: "[uiCardFooter]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: CardFooterElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiCardFooter]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class CardHeaderElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'flex flex-col space-y-1.5 p-6';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: CardHeaderElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: CardHeaderElement, isStandalone: true, selector: "[uiCardHeader]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: CardHeaderElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiCardHeader]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class CardTitleElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'font-semibold leading-none tracking-tight dark:text-zinc-50';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: CardTitleElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: CardTitleElement, isStandalone: true, selector: "[uiCardTitle]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: CardTitleElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiCardTitle]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class CardElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'text-zinc-950 border border-zinc-200 rounded-xl shadow bg-white dark:border-zinc-800 dark:bg-zinc-950';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: CardElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: CardElement, isStandalone: true, selector: "[uiCard]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: CardElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiCard]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class DialogService {
    constructor() {
        this.dialogsState = {};
    }
    getDialogState(id) {
        if (!this.dialogsState[id]) {
            this.dialogsState[id] = new BehaviorSubject(false);
        }
        return this.dialogsState[id].asObservable();
    }
    open(id) {
        if (!this.dialogsState[id]) {
            this.dialogsState[id] = new BehaviorSubject(false);
        }
        this.dialogsState[id].next(true);
    }
    close(id) {
        if (this.dialogsState[id]) {
            this.dialogsState[id].next(false);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class DialogElement {
    constructor(el, renderer, dialogService) {
        this.el = el;
        this.renderer = renderer;
        this.dialogService = dialogService;
        this.size = 'md';
        this.isOpenDialog = false;
        this.class = '';
    }
    ngOnInit() {
        this.updateClasses('opacity-0 pointer-events-none');
        this.dialogSubscription = this.dialogService
            .getDialogState(this.dialogId)
            .subscribe((isOpen) => {
            this.updateClasses(isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none');
        });
    }
    ngOnChanges() {
        this.updateClasses('opacity-0 pointer-events-none');
    }
    ngOnDestroy() {
        if (this.dialogSubscription) {
            this.dialogSubscription.unsubscribe();
        }
    }
    updateClasses(visibilityClasses) {
        const baseClasses = 'flex items-center justify-center px-5 xl:px-0 transition-opacity duration-300 bg-white/80 dark:bg-black/80 inset-0 fixed z-50';
        const classes = `${baseClasses} ${visibilityClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    onCloseDialog(event) {
        if (event.target === this.el.nativeElement) {
            this.dialogService.close(this.dialogId);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: DialogService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: DialogElement, isStandalone: true, selector: "[uiDialog]", inputs: { size: "size", isOpenDialog: "isOpenDialog", class: "class", dialogId: "dialogId" }, host: { listeners: { "click": "onCloseDialog($event)" } }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiDialog]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: DialogService }], propDecorators: { size: [{
                type: Input
            }], isOpenDialog: [{
                type: Input
            }], class: [{
                type: Input
            }], dialogId: [{
                type: Input
            }], onCloseDialog: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

class DialogContentElement {
    constructor(el, renderer, _dialogService, dialog) {
        this.el = el;
        this.renderer = renderer;
        this._dialogService = _dialogService;
        this.dialog = dialog;
        this.size = 'md';
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const sizeClass = this.getSizeClass(this.size);
        const classes = `${sizeClass} ${this.class} grid shadow-md p-6 gap-5 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-950 relative`;
        const button = this.renderer.createElement('button');
        button.classList.add('top-4', 'right-4', 'opacity-50', 'transition-opacity', 'hover:opacity-100', 'absolute');
        const svg = this.renderer.createElement('svg', 'http://www.w3.org/2000/svg');
        this.renderer.setAttribute(svg, 'width', '15');
        this.renderer.setAttribute(svg, 'height', '15');
        this.renderer.setAttribute(svg, 'viewBox', '0 0 24 24');
        this.renderer.setAttribute(svg, 'fill', 'none');
        this.renderer.setAttribute(svg, 'stroke-width', '2');
        this.renderer.setAttribute(svg, 'stroke-linecap', 'round');
        this.renderer.setAttribute(svg, 'stroke-linejoin', 'round');
        const line1 = this.renderer.createElement('line', 'http://www.w3.org/2000/svg');
        this.renderer.setAttribute(line1, 'x1', '18');
        this.renderer.setAttribute(line1, 'y1', '6');
        this.renderer.setAttribute(line1, 'x2', '6');
        this.renderer.setAttribute(line1, 'y2', '18');
        const line2 = this.renderer.createElement('line', 'http://www.w3.org/2000/svg');
        this.renderer.setAttribute(line2, 'x1', '6');
        this.renderer.setAttribute(line2, 'y1', '6');
        this.renderer.setAttribute(line2, 'x2', '18');
        this.renderer.setAttribute(line2, 'y2', '18');
        this.renderer.appendChild(svg, line1);
        this.renderer.appendChild(svg, line2);
        this.renderer.appendChild(button, svg);
        svg.classList.add('stroke-black', 'dark:stroke-white');
        this.renderer.listen(button, 'click', () => {
            this._dialogService.close(this.dialog.dialogId);
        });
        this.renderer.appendChild(this.el.nativeElement, button);
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
        this.el.nativeElement.appendChild(button);
    }
    onClick(event) {
        event.stopPropagation();
    }
    getSizeClass(size) {
        switch (size) {
            case 'xs':
                return 'w-full max-w-xs';
            case 'sm':
                return 'w-full max-w-sm';
            case 'md':
                return 'w-full max-w-md';
            case 'lg':
                return 'w-full max-w-lg';
            case 'xl':
                return 'w-full max-w-xl';
            case '2xl':
                return 'w-full max-w-2xl';
            case '3xl':
                return 'w-full max-w-3xl';
            case '4xl':
                return 'w-full max-w-4xl';
            case '5xl':
                return 'w-full max-w-5xl';
            default:
                return 'w-full max-w-md';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogContentElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: DialogService }, { token: DialogElement, host: true, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: DialogContentElement, isStandalone: true, selector: "[uiDialogContent]", inputs: { size: "size", class: "class" }, host: { listeners: { "click": "onClick($event)" } }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogContentElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiDialogContent]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: DialogService }, { type: DialogElement, decorators: [{
                    type: Optional
                }, {
                    type: Host
                }] }], propDecorators: { size: [{
                type: Input
            }], class: [{
                type: Input
            }], onClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

class DialogDescriptionElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'font-normal text-sm text-zinc-500 dark:text-white/70';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogDescriptionElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: DialogDescriptionElement, isStandalone: true, selector: "[uiDialogDescription]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogDescriptionElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiDialogDescription]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class DialogFooterElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const classes = `${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogFooterElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: DialogFooterElement, isStandalone: true, selector: "[uiDialogFooter]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogFooterElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiDialogFooter]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class DialogHeaderElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'flex flex-col space-y-1.5';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogHeaderElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: DialogHeaderElement, isStandalone: true, selector: "[uiDialogHeader]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogHeaderElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiDialogHeader]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class DialogTitleElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'font-semibold leading-none tracking-tight dark:text-zinc-50';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogTitleElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: DialogTitleElement, isStandalone: true, selector: "[uiDialogTitle]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogTitleElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiDialogTitle]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class DialogTriggerElement {
    constructor(dialogService) {
        this.dialogService = dialogService;
    }
    onClick() {
        this.dialogService.open(this.dialogId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogTriggerElement, deps: [{ token: DialogService }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: DialogTriggerElement, isStandalone: true, selector: "[uiDialogTrigger]", inputs: { dialogId: "dialogId" }, host: { listeners: { "click": "onClick()" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: DialogTriggerElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiDialogTrigger]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: DialogService }], propDecorators: { dialogId: [{
                type: Input
            }], onClick: [{
                type: HostListener,
                args: ['click']
            }] } });

class InputElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'w-full h-9 flex font-normal text-sm placeholder:text-zinc-500 px-3 py-1 shadow-sm rounded-md bg-transparent border border-zinc-200 focus:outline-2 focus:outline-neutral-500 disabled:cursor-not-allowed disabled:opacity-50 dark:text-neutral-50 dark:placeholder:text-white/70 dark:border-zinc-800 dark:focus:outline-zinc-800';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: InputElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: InputElement, isStandalone: true, selector: "[uiInput]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: InputElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiInput]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class LabelElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'font-medium text-sm leading-none dark:text-neutral-50';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: LabelElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: LabelElement, isStandalone: true, selector: "[uiLabel]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: LabelElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiLabel]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class SkeletonElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'animate-pulse bg-zinc-900/10 dark:bg-zinc-50/10';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: SkeletonElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: SkeletonElement, isStandalone: true, selector: "[uiSkeleton]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: SkeletonElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiSkeleton]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

class SpinnerElement {
    constructor() {
        this.size = 'lg';
        this.color = 'default';
        this.sizeClass = '';
        this.colorClass = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        this.sizeClass = this.getSizeClass(this.size);
        this.colorClass = this.getColorClass(this.color);
    }
    getSizeClass(size) {
        switch (size) {
            case 'xs':
                return 'w-3.5 h-3.5';
            case 'sm':
                return 'w-5 h-5';
            case 'lg':
                return 'w-8 h-8';
            case 'xl':
                return 'w-10 h-10';
            default:
                return 'w-5 h-5';
        }
    }
    getColorClass(color) {
        switch (color) {
            case 'default':
                return 'text-zinc-400 dark:text-zinc-500';
            case 'primary':
                return 'text-blue-600';
            case 'secondary':
                return 'text-violet-600';
            case 'success':
                return 'text-green-600';
            case 'warning':
                return 'text-orange-600';
            case 'danger':
                return 'text-red-600';
            default:
                return 'text-zinc-400 dark:text-zinc-500';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: SpinnerElement, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.9", type: SpinnerElement, isStandalone: true, selector: "[uiSpinner]", inputs: { size: "size", color: "color" }, usesOnChanges: true, ngImport: i0, template: `
    <div [ngClass]="sizeClass + ' animate-spin relative'">
      <div class="flex justify-center items-center w-full h-full top-0 left-0 absolute">
        <svg class="transform -rotate-80" viewBox="0 0 36 36">
          <circle
            [attr.class]="colorClass"
            cx="18"
            cy="18"
            r="15.9155"
            fill="none"
            stroke-width="3.5"
            stroke-dasharray="90 100"
            stroke-linecap="round"
            stroke="currentColor"
            stroke-dashoffset="9"
          />
        </svg>
      </div>
    </div>
  `, isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: SpinnerElement, decorators: [{
            type: Component,
            args: [{ selector: '[uiSpinner]', standalone: true, imports: [CommonModule], template: `
    <div [ngClass]="sizeClass + ' animate-spin relative'">
      <div class="flex justify-center items-center w-full h-full top-0 left-0 absolute">
        <svg class="transform -rotate-80" viewBox="0 0 36 36">
          <circle
            [attr.class]="colorClass"
            cx="18"
            cy="18"
            r="15.9155"
            fill="none"
            stroke-width="3.5"
            stroke-dasharray="90 100"
            stroke-linecap="round"
            stroke="currentColor"
            stroke-dashoffset="9"
          />
        </svg>
      </div>
    </div>
  ` }]
        }], propDecorators: { size: [{
                type: Input
            }], color: [{
                type: Input
            }] } });

class SwitchElement {
    constructor() {
        this._disabled = false;
        this.label = '';
        this.size = 'sm';
        this.color = 'default';
        this.checked = false;
        this.switchChange = new EventEmitter();
        this.switchClass = `rounded-full shadow-sm border-2 border-transparent peer peer-focus:outline-none peer-focus:ring-0 after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:rounded-full after:shadow-lg after:transition-all`;
        this.sizeClass = '';
        this.colorClass = '';
    }
    set disabled(value) {
        this._disabled = value === '' || value === 'true';
    }
    get disabled() {
        return this._disabled;
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        this.sizeClass = this.getSizeClass(this.size);
        this.colorClass = this.getColorClass(this.color);
    }
    getSizeClass(size) {
        switch (size) {
            case 'sm':
                return 'w-9 h-5 after:w-4 after:h-4 peer-checked:after:translate-x-4';
            case 'md':
                return 'w-12 h-6 after:w-5 after:h-5 peer-checked:after:translate-x-6';
            case 'lg':
                return 'w-14 h-7 after:w-6 after:h-6 peer-checked:after:translate-x-7';
            default:
                return 'w-9 h-5 after:w-4 after:h-4 peer-checked:after:translate-x-4';
        }
    }
    getColorClass(color) {
        switch (color) {
            case 'default':
                return 'bg-zinc-200 dark:bg-zinc-800 peer-checked:bg-zinc-950 peer-checked:dark:bg-neutral-50 after:bg-neutral-50 after:dark:bg-zinc-950 peer-checked:after:bg-neutral-50 peer-checked:after:dark:bg-zinc-950';
            case 'info':
                return 'bg-zinc-200 dark:bg-zinc-800 peer-checked:bg-blue-800 after:bg-neutral-50 after:dark:bg-zinc-950 peer-checked:after:bg-neutral-50 peer-checked:after:dark:bg-blue-200';
            case 'help':
                return 'bg-zinc-200 dark:bg-zinc-800 peer-checked:bg-violet-700 after:bg-neutral-50 after:dark:bg-zinc-950 peer-checked:after:bg-neutral-50 peer-checked:after:dark:bg-violet-200';
            case 'success':
                return 'bg-zinc-200 dark:bg-zinc-800 peer-checked:bg-lime-700 after:bg-neutral-50 after:dark:bg-zinc-950 peer-checked:after:bg-neutral-50 peer-checked:after:dark:bg-lime-200';
            case 'warning':
                return 'bg-zinc-200 dark:bg-zinc-800 peer-checked:bg-orange-700 after:bg-neutral-50 after:dark:bg-zinc-950 peer-checked:after:bg-neutral-50 peer-checked:after:dark:bg-orange-200';
            case 'danger':
                return 'bg-zinc-200 dark:bg-zinc-800 peer-checked:bg-red-700 after:bg-neutral-50 after:dark:bg-zinc-950 peer-checked:after:bg-neutral-50 peer-checked:after:dark:bg-red-200';
            default:
                return 'bg-zinc-200 dark:bg-zinc-800 peer-checked:bg-zinc-950 peer-checked:dark:bg-neutral-50 after:bg-neutral-50 after:dark:bg-zinc-950 peer-checked:after:bg-neutral-50 peer-checked:after:dark:bg-zinc-950';
        }
    }
    onSwitchChange(event) {
        const target = event.target;
        this.checked = target.checked;
        this.switchChange.emit(this.checked);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: SwitchElement, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.9", type: SwitchElement, isStandalone: true, selector: "[uiSwitch]", inputs: { label: "label", size: "size", color: "color", checked: "checked", disabled: "disabled" }, outputs: { switchChange: "switchChange" }, usesOnChanges: true, ngImport: i0, template: `
    <label class="flex items-center cursor-pointer relative">
      <input 
        type="checkbox" 
        class="sr-only peer" 
        [checked]="checked" 
        (change)="onSwitchChange($event)"
        [disabled]="disabled"
        [ngClass]="disabled ? 'cursor-not-allowed' : ''"
      />
      <div [ngClass]="colorClass + ' ' + switchClass + ' ' + sizeClass + ' ' + (disabled ? 'cursor-not-allowed after:bg-neutral-400 after:dark:bg-zinc-700' : '')">
      </div>
      @if (label) {
        <span class="font-normal text-sm leading-none ml-3 dark:text-neutral-50">
          {{ label }}
        </span>
      }
    </label>
  `, isInline: true, styles: [""], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: SwitchElement, decorators: [{
            type: Component,
            args: [{ selector: '[uiSwitch]', standalone: true, imports: [CommonModule], template: `
    <label class="flex items-center cursor-pointer relative">
      <input 
        type="checkbox" 
        class="sr-only peer" 
        [checked]="checked" 
        (change)="onSwitchChange($event)"
        [disabled]="disabled"
        [ngClass]="disabled ? 'cursor-not-allowed' : ''"
      />
      <div [ngClass]="colorClass + ' ' + switchClass + ' ' + sizeClass + ' ' + (disabled ? 'cursor-not-allowed after:bg-neutral-400 after:dark:bg-zinc-700' : '')">
      </div>
      @if (label) {
        <span class="font-normal text-sm leading-none ml-3 dark:text-neutral-50">
          {{ label }}
        </span>
      }
    </label>
  ` }]
        }], propDecorators: { label: [{
                type: Input
            }], size: [{
                type: Input
            }], color: [{
                type: Input
            }], checked: [{
                type: Input
            }], switchChange: [{
                type: Output
            }], disabled: [{
                type: Input
            }] } });

class TextareaElement {
    constructor(el, renderer) {
        this.el = el;
        this.renderer = renderer;
        this.class = '';
    }
    ngOnInit() {
        this.applyClasses();
    }
    ngOnChanges() {
        this.applyClasses();
    }
    applyClasses() {
        const baseClasses = 'w-full min-h-16 flex bg-transparent border border-input rounded-md px-3 py-2 font-normal text-sm placeholder:text-zinc-400 shadow-sm focus:outline-2 focus:outline-neutral-500 disabled:cursor-not-allowed disabled:opacity-50 dark:text-neutral-50 dark:placeholder:text-white/70 dark:border-zinc-800 dark:focus:outline-zinc-800';
        const classes = `${baseClasses} ${this.class}`;
        this.renderer.setAttribute(this.el.nativeElement, 'class', classes);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: TextareaElement, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.9", type: TextareaElement, isStandalone: true, selector: "[uiTextarea]", inputs: { class: "class" }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.9", ngImport: i0, type: TextareaElement, decorators: [{
            type: Directive,
            args: [{
                    selector: '[uiTextarea]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { class: [{
                type: Input
            }] } });

/*
 * Public API Surface of ngx-angular-ui
 */
// Alert

/**
 * Generated bundle index. Do not edit.
 */

export { AlertDescriptionElement, AlertElement, AlertTitleElement, AvatarElement, BadgeElement, ButtonElement, CardContentElement, CardDescriptionElement, CardElement, CardFooterElement, CardHeaderElement, CardTitleElement, DialogContentElement, DialogDescriptionElement, DialogElement, DialogFooterElement, DialogHeaderElement, DialogService, DialogTitleElement, DialogTriggerElement, InputElement, LabelElement, SkeletonElement, SpinnerElement, SwitchElement, TextareaElement };
//# sourceMappingURL=ngx-angular-ui.mjs.map
