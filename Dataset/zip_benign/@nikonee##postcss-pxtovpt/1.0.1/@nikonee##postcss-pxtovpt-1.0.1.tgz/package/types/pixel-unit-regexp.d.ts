export declare function getUnitRegexp(unit: string): RegExp;
