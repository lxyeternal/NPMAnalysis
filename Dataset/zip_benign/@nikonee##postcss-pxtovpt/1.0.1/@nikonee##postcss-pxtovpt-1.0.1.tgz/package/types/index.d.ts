import { Plugin } from 'postcss';
import { Options } from './type';
declare function pxToViewport(options?: Options): Plugin;
declare namespace pxToViewport {
    var postcss: boolean;
}
export = pxToViewport;
