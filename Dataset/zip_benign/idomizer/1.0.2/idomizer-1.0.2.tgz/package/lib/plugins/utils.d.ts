/**
 * @ignore
 */
export declare function toStringFunction(html: any, options: any): any;
