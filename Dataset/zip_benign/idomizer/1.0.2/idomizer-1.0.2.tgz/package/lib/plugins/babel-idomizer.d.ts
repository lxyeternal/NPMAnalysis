/**
 * @ignore
 */
export default function ({ types: t }: {
    types: any;
}): {
    visitor: {
        TaggedTemplateExpression(path: any, state: any): void;
    };
};
