declare const _default: any;
/**
 * @ignore
 */
export default _default;
