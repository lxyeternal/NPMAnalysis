'use strict';
// var DataV = require('../../barMultiHori');
var DataV = require('dchart-core/bar/barMultiHori');
// var _ = require('../../../util');
var _ = require('dchart-core/util');
var d3 = require('d3');
const s = 22;

function barHoriWithCuteAxis(container, options) {
  var opt = {
    margin: {},
    xaxis: {
      padding: 0.3,
      assistLine: false,
    },
    yaxis: {
      padding: 0.6,
      groupPadding: [0.4, 0],
      assistLine: false,
      decorateLine: '#fff',
      decorateShapeFill: '#fff',
      decorateShapeStroke: '#fff'
    },
    zaxis: {
      key: 'z'
    }
  };
  this.needFirst = true;
  opt = _.deepMerge(opt, options);
  DataV.call(this, container, opt);
}

barHoriWithCuteAxis = DataV.extend(barHoriWithCuteAxis, {
  beforeRender: function () {
    DataV.prototype.beforeRender.call(this);
  },
  updateBeforeRender: function () {
    DataV.prototype.updateBeforeRender.call(this);
    this.beforeRender();
    var axis = this.getComs('axis', 'yaxis');
    var y = axis.getX();
    var w = y.rangeBand() / 4;
    const boxW = axis.getGroupStep() * axis.options.padding[0];

    let expendedBox = axis.el.select('.expended-box')[0][0] ?
      axis.el.select('.expended-box') :
      axis.el.append('rect').attr('class', 'expended-box');

    expendedBox
      .attr({
        x: s + w * 2,
        y: 0,
        width: boxW,
        height: 20
      }).style({
        'fill': 'transparent'
      })
  },
  afterRender: function () {
    DataV.prototype.afterRender.call(this);
    var opt = this.options;
    var axis = this.getComs('axis', 'yaxis');
    const boxW = axis.getGroupStep() * axis.options.padding[0];
    var y = axis.getX();
    var w = y.rangeBand() / 4;
    const lines = axis.selectAll('line:not(.net-line)');
    lines.transition()
      .attr({
        x2: s,
        y2: 0
      })
      .style({
        display: 'block',
        stroke: opt.yaxis.decorateLine
      });
    axis.el.transition().selectAll('.net-line')
      .attr({
        x2: s + w * 2 + opt.innerWidth,
        y2: 0,
        x1: s + w * 2,
        y1: 0
      }).attr({
        display: opt.yaxis.net ? 'block' : 'none',
        stroke: opt.yaxis.netColor
      });
      
    var updateTickAttr = function () {
      var that = d3.select(this);
      that.attr({
        points: function () {
          var points = [
            {x: s, y: 0},
            {x: s + w, y: -w * 2},
            {x: s + w + w, y: -w * 2},
            {x: s + w + w, y: w * 2},
            {x: s + w, y: w * 2},
          ];
          return _.pos2Str(points);
        }
      }).style({
        fill: opt.yaxis.decorateShapeFill,
        stroke: opt.yaxis.decorateShapeStroke
      });
    };

    this.svg.selectAll('.axis2 .tick').each(function (d, i) {
      var that = d3.select(this);
      var line = that.select('.tick-line');
      if (line[0][0]) {
        updateTickAttr.call(line[0][0], d, i);
      } else {
        var line = that.append('polygon').attr('class', 'tick-line');
        line[0][0] && updateTickAttr.call(line[0][0], d, i);
      }
    });

    if (this.needFirst) {
      this.needFirst = false;
      this.update();
      var trans = axis.attr('transform').replace('translate(', '').split(',')[0];
          
      axis.el.transition().attr({
        transform: 'translate(' + (trans - s - w * 2 - boxW) + ', 0)'
      });
    } else {
      this.needFirst = true;
    }
  },
  updateAfterRender: function () {
    this.afterRender();
  }
});

module.exports = barHoriWithCuteAxis;
