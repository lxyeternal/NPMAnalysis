bar-hori-with-cute-axis

符合dchart规范的水平柱状图

### 安装

```
npm install dchart-bar-hori-with-cute-axis
```

### 用法
```
var Bar = require('bar-hori-with-cute-axis');
var bar = new Bar(container, {
  xaxis : {
    padding : 0.3
  },
  yaxis : {
    padding : 0.6,
    groupPadding : [0.4, 0],
  },
  zaxis : {
    key : 'z'
  }
});
bar.render([
    {x: '电子', y : [2, 22], z:['-1.9%', '-1.9%']},
    {x: '服装', y : [21, 3], z:['+2.5%', '+1.3%']},
    {x: '数码', y : [2, 17], z: ['-4.3%', '+2.5%']},
    {x: '医药', y : [5, 12], z: ['+1.3%', '+1.6%']},
    {x: '家装', y : [5, 15], z: ['+0.1%', '+1.3%']}
]);
```
