"use strict";

var _unistUtilVisit = _interopRequireDefault(require("unist-util-visit"));

var _queryString = _interopRequireDefault(require("query-string"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

module.exports = function gatsbyRemarkCodeTitles(_ref) {
  var markdownAST = _ref.markdownAST;

  var _ref2 = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
      customClassName = _ref2.className;

  (0, _unistUtilVisit.default)(markdownAST, 'code', function (node, index) {
    var _split = (node.lang || '').split(':'),
        _split2 = _slicedToArray(_split, 2),
        language = _split2[0],
        params = _split2[1];

    var options = _queryString.default.parse(params);

    var title = options.title,
        rest = _objectWithoutProperties(options, ["title"]);

    if (!title || !language) {
      return;
    }

    var newQuery = '';

    if (Object.keys(rest).length) {
      newQuery = ":" + Object.keys(rest).map(function (key) {
        return "".concat(key, "=").concat(rest[key]);
      }).join('&');
    }

    var className = ['gatsby-code-title'].concat(customClassName || []);
    var titleNode = {
      type: 'html',
      value: "\n<div class=\"".concat(className.map(function (c) {
        return "".concat(c, "-container");
      }).join(' ').trim(), "\"><span class=\"").concat(className.join(' ').trim(), "\">").concat(title, "</span></div>\n      ").trim()
    };
    /*
     * Splice a node back into the Markdown AST with custom title
     */

    markdownAST.children.splice(index, 0, titleNode);
    /*
     * Reset to just the language
     */

    node.lang = language + newQuery;
  });
  return markdownAST;
};