declare function polyfill(): void;
