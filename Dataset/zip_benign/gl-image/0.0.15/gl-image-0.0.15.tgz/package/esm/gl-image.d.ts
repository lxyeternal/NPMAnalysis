export interface FilterValues {
    [type: string]: number;
}
export default class GLImage {
    private canvas;
    private gl;
    private width;
    private height;
    private texture;
    private vertexBuffer;
    private filters;
    private tempFramebuffers;
    private currentFramebufferIndex;
    private _resultCanvas;
    private _ctx2D;
    constructor();
    getCanvas(): HTMLCanvasElement;
    toDataURL(type: string | undefined, quality: any): string;
    getImageData(): ImageData;
    loadImageSrc(src: string): Promise<this>;
    loadFromElement(target: HTMLImageElement | HTMLCanvasElement): Promise<this>;
    applyFilter(type: string, value: number): void;
    applyFilters(values: FilterValues): void;
    resetFilters(): void;
    getAllFilterValues(filters?: any): any;
    getFilterValueByName(type: string): any;
    draw(): void;
    private clear;
    private initImage;
    private updateFilterUniformValue;
    private setupFilters;
    private drawScene;
    private getTempFramebuffer;
}
