export declare const GL_OPTIONS: Readonly<{
    alpha: boolean;
    premultipliedAlpha: boolean;
    depth: boolean;
    stencil: boolean;
    antialias: boolean;
    preserveDrawingBuffer: boolean;
}>;
