import { UNIFORMS } from './filter';
export declare function createTexture(gl: WebGLRenderingContext, image: HTMLImageElement | HTMLCanvasElement): WebGLTexture | null;
export declare function setUniforms(gl: WebGLRenderingContext, program: WebGLProgram, uniforms: UNIFORMS): void;
export declare function initVertex(gl: WebGLRenderingContext): WebGLBuffer | null;
export declare function initFilter(gl: WebGLRenderingContext, program: WebGLProgram): void;
export declare function initShaders(gl: WebGLRenderingContext, shaderObj: any): boolean;
export declare function initFramebufferObject(gl: WebGLRenderingContext, width: number, height: number): {
    fbo: WebGLFramebuffer | null;
    texture: WebGLTexture | null;
};
export declare function getImageData(gl: WebGLRenderingContext, width: number, height: number): ImageData;
