export interface UNIFORMS {
    [name: string]: UNIFORMITEM;
}
export interface UNIFORMITEM {
    value: number;
    range: [number, number];
}
export declare const SUPPORTED_FILTERS: any;
export declare function createFilter(name: string): any;
