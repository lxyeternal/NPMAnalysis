nv-task-event-transcation
==========================
- nv-task-event-transcation 
- resolve until all tasks success


install
=======
- npm install nv-task-event-transcation

usage
=====

     const {creat_parallel,creat_serial,repeat_until_succ} = require("nv-task-event-transcation")

example
-------

### parallel


    var [parallel,forest] = creat_parallel()

    function tsk(rs,rj,self) {
        console.log(self.name,"start:",new Date())
        setTimeout(
            () => {
                let cond =  (Math.random() >0.5)?true:false;
                if(cond) {
                     console.log(self.name,"succ:",new Date())
                    rs(Math.random())
                } else {
                    console.log(self.name,"fail:",new Date())
                    rj(Math.random())
                }
            },
            Math.random()*10000 + 2000
        )
    }
    parallel.add("t0",tsk)
    parallel.add("t1",tsk)
    parallel.add("t2",tsk)

    var r = await parallel.start();

    t0 start: 2021-11-29T11:55:55.839Z
    t1 start: 2021-11-29T11:55:55.841Z
    t2 start: 2021-11-29T11:55:55.842Z
    t1 fail: 2021-11-29T11:55:57.945Z
    Uncaught 0.5145146224195394
    > parallel.p_
    Promise { <rejected> 0.5145146224195394 }
    >

    parallel.reset();
    var r = await parallel.start();
    t0 start: 2021-11-29T11:57:05.228Z
    t1 start: 2021-11-29T11:57:05.229Z
    t2 start: 2021-11-29T11:57:05.231Z
    t2 succ: 2021-11-29T11:57:08.335Z
    t1 fail: 2021-11-29T11:57:10.427Z
    Uncaught 0.6311975765253766
    > t0 fail: 2021-11-29T11:57:12.983Z

    > parallel.p_
    Promise { <rejected> 0.6311975765253766 }
    >

    > parallel.reset();
    undefined
    > var r = await parallel.start();
    t0 start: 2021-11-29T11:58:31.406Z
    t1 start: 2021-11-29T11:58:31.407Z
    t2 start: 2021-11-29T11:58:31.407Z
    t0 succ: 2021-11-29T11:58:35.156Z
    t1 succ: 2021-11-29T11:58:37.350Z
    t2 succ: 2021-11-29T11:58:39.032Z
    undefined
    > r
    [ 0.5653168905010539, 0.08952979280941764, 0.3345300882481612 ]
    >
    > parallel.p_
    Promise {
      [ 0.5653168905010539, 0.08952979280941764, 0.3345300882481612 ]
    }
    >


### serial

            var [serial,forest] = creat_serial()
            
            function tsk(rs,rj,self) {
                console.log(self.name,"start:",new Date())
                setTimeout(
                    () => {
                        let cond =  (Math.random() >0.5)?true:false;
                        if(cond) {
                             console.log(self.name,"succ:",new Date())
                            rs(Math.random())
                        } else {
                            console.log(self.name,"fail:",new Date())
                            rj(Math.random())
                        }
                    },
                    Math.random()*10000 + 2000
                )
            }
            serial.append("t0",tsk)
            serial.append("t1",tsk)
            serial.append("t2",tsk)
        > serial.$sdfs_
        [
          Serial [1 %1fb1e375:1% ] {},
          Base [2 %1fb1e375:2% ] { name: 't0' },
          Base [3 %1fb1e375:3% ] { name: 't1' },
          Base [4 %1fb1e375:4% ] { name: 't2' }
        ]
        >

            
            
            > var r = await serial.start();
            t0 start: 2021-11-29T12:22:45.176Z
            t0 fail: 2021-11-29T12:22:49.110Z
            Uncaught 0.42121530707919574
            > serial.p_
            Promise { <rejected> 0.42121530707919574 }
            >
            > serial.reset()
            undefined
            > serial.p_
            Promise { <pending> }
            >
            > var r = await serial.start();
            t0 start: 2021-11-29T12:27:29.928Z
            t0 succ: 2021-11-29T12:27:34.366Z
            t1 start: 2021-11-29T12:27:34.367Z
            t1 succ: 2021-11-29T12:27:43.180Z
            t2 start: 2021-11-29T12:27:43.181Z
            t2 succ: 2021-11-29T12:27:51.746Z
            undefined
            > r
            0.582265217409822
            >



### repeat\_until\_succ

      var [serial,forest] = creat_serial()
      serial.append("t0",tsk)
      serial.append("t1",tsk)
      serial.append("t2",tsk)

        > var r = await repeat_until_succ(serial);
        t0 start: 2021-11-29T12:49:43.565Z
        t0 succ: 2021-11-29T12:49:54.730Z
        t1 start: 2021-11-29T12:49:54.733Z
        t1 fail: 2021-11-29T12:50:04.885Z
        t0 start: 2021-11-29T12:50:04.888Z
        t0 succ: 2021-11-29T12:50:13.329Z
        t1 start: 2021-11-29T12:50:13.329Z
        t1 succ: 2021-11-29T12:50:17.245Z
        t2 start: 2021-11-29T12:50:17.246Z
        t2 succ: 2021-11-29T12:50:26.110Z
        undefined
        > r
        0.5662500511974513
        > var r = await repeat_until_succ(serial);
        can_only_ready_when_init
        can_only_ready_when_init
        undefined
        undefined
        undefined
        > serial.reset()
        undefined
        > var r = await repeat_until_succ(serial);
        t0 start: 2021-11-29T12:50:58.218Z
        t0 succ: 2021-11-29T12:51:09.006Z
        t1 start: 2021-11-29T12:51:09.007Z
        t1 succ: 2021-11-29T12:51:15.825Z
        t2 start: 2021-11-29T12:51:15.825Z
        t2 succ: 2021-11-29T12:51:25.403Z
        undefined
        > serial.reset()
        undefined
        > var r = await repeat_until_succ(serial);
        t0 start: 2021-11-29T12:51:29.899Z
        t0 fail: 2021-11-29T12:51:32.722Z
        t0 start: 2021-11-29T12:51:32.724Z
        t0 fail: 2021-11-29T12:51:35.228Z
        t0 start: 2021-11-29T12:51:35.230Z
        t0 fail: 2021-11-29T12:51:40.988Z
        t0 start: 2021-11-29T12:51:40.990Z
        t0 fail: 2021-11-29T12:51:44.218Z
        t0 start: 2021-11-29T12:51:44.220Z
        t0 fail: 2021-11-29T12:51:50.296Z
        t0 start: 2021-11-29T12:51:50.298Z
        t0 succ: 2021-11-29T12:52:00.018Z
        t1 start: 2021-11-29T12:52:00.018Z
        t1 fail: 2021-11-29T12:52:07.573Z
        t0 start: 2021-11-29T12:52:07.575Z
        t0 succ: 2021-11-29T12:52:10.666Z
        t1 start: 2021-11-29T12:52:10.667Z
        t1 succ: 2021-11-29T12:52:14.720Z
        t2 start: 2021-11-29T12:52:14.721Z
        t2 succ: 2021-11-29T12:52:18.700Z
        undefined
        >
        > r
        0.5614520757889236
        >
        serial.reset()
        var r = await repeat_until_succ(serial,2);
        t0 start: 2021-11-29T13:18:49.486Z
        t0 succ: 2021-11-29T13:18:59.269Z
        t1 start: 2021-11-29T13:18:59.273Z
        t1 fail: 2021-11-29T13:19:07.131Z
        t0 start: 2021-11-29T13:19:07.135Z
        t0 fail: 2021-11-29T13:19:13.493Z
        Uncaught 0.6774315518935192

        serial.reset()

        > var r = await repeat_until_succ(serial,2);
        t0 start: 2021-11-29T13:24:46.992Z
        t0 fail: 2021-11-29T13:24:54.831Z
        t0 start: 2021-11-29T13:24:54.834Z
        t0 succ: 2021-11-29T13:25:04.002Z
        t1 start: 2021-11-29T13:25:04.003Z
        t1 succ: 2021-11-29T13:25:08.444Z
        t2 start: 2021-11-29T13:25:08.445Z
        t2 succ: 2021-11-29T13:25:14.790Z
        undefined

        serial.reset()

        var r = await repeat_until_succ(serial,10,false);
        > var r = await repeat_until_succ(serial,10,false);
        t0 start: 2021-11-29T14:17:52.944Z
        t0 fail: 2021-11-29T14:18:00.691Z

        t0 start: 2021-11-29T14:18:00.693Z
        t0 fail: 2021-11-29T14:18:05.864Z

        t0 start: 2021-11-29T14:18:05.866Z
        t0 succ: 2021-11-29T14:18:10.440Z
        t1 start: 2021-11-29T14:18:10.441Z
        t1 succ: 2021-11-29T14:18:15.240Z
        t2 start: 2021-11-29T14:18:15.241Z
        t2 fail: 2021-11-29T14:18:26.888Z

        t2 start: 2021-11-29T14:18:26.889Z
        t2 fail: 2021-11-29T14:18:38.000Z

        t2 start: 2021-11-29T14:18:38.002Z
        t2 succ: 2021-11-29T14:18:43.329Z
        undefined
        >
        >
        > r
        0.22477518894573745
        >






APIS
====

- creat\_parallel(forest,max\_size,rtrn\_forest=true)
- creat\_serial(forest,max\_size,rtrn\_forest=true)
- repeat\_unti\_succ(
    task,
    max\_repeat\_times=Infinity,
    reset_all=true,
    forest,max\_size,rtrn\_forest=true
)

LICENSE
=======
- ISC 
