const creat_parallel = require("./parallel");
const creat_serial   = require("./serial");
const repeat_unti_succ = require("./repeat");

module.exports = {
    creat_parallel,
    creat_serial,
    repeat_unti_succ
}

