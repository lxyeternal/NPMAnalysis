
async function repeat_unti_succ(
    tsk,max_repeat_times=Infinity,
    reset_all=true,
    forest,max_size=10000,rtrn_forest=true
) {
    let c = 0;
    while(true) {
       try {
           if(reset_all) {
               tsk.start();
           } else {
               if(tsk.is_rejected()) {
                   tsk.reset_and_start_from_failed()
               } else {
                   tsk.start();
               }
           }
           c = c + 1;
           await tsk.p_;
           break;
       } catch(err) {
           if(c<max_repeat_times) {
               if(reset_all) {
                   tsk.reset()
               } else {
               }
           } else {
               break;
           }
       }
    }
    return(tsk.p_)
}

module.exports = repeat_unti_succ;
