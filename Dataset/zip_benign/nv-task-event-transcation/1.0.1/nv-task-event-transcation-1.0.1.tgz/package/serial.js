const {
   noexist,
   STATE_LABEL_DICT,
   ////
   sym_rs,
   sym_rj,
   sym_exec,
   sym_pause,
   sym_continue,
   sym_reset,
   sym_respawn,
   sym_rdy,
   sym_launch,
   DFLT_CU_EXECUTOR,
   DFLT_EXEC_WRAP,
   DFLT_RECV,
   ////
   Base
} = require("nv-task-event-basic");


const ERROR = {
    already_started:'already_started'
}


class Serial extends Base {
    ////
    append(name,o,Cls=Base) {
        if(this.is_pending() || this.is_settled()) {
            console.log(ERROR.already_started)
        } else {
            let chnd;
            if(o instanceof Function) {
                let forest = this.$forest_;
                chnd = forest.node(Cls);
                chnd.exec_ = o;
                this.$append_child(chnd)
            } else {
                chnd = this.$append_child(o)
            }
            chnd.name = name;
        }
    }
    ////
    start() {
        this[sym_rdy]();
        let fstch = this.$fstch_;
        if(fstch!==null) {
            fstch[sym_rdy]()
        } else {}
        this[sym_launch]();
        if(fstch!==null) {
            fstch[sym_launch]()
        } else {}
        return(this.p_)
    }
    reset() {
        let children = this.$children_;
        children.forEach(chnd=>{
            let nchnd = chnd[sym_respawn]();
            nchnd.name = chnd.name;
        });
        children = this.$children_;
        this[sym_reset]();
    }
    get curr_failed_tsk_() {
        let children = this.$children_;
        for(let chnd of children) {
            if(chnd.is_rejected()) {
                return(chnd)
            } else {}
        }
        return(null)
    }
    reset_and_start_from_failed() {
        let chnd = this.curr_failed_tsk_;
        if(chnd !== null) {
            let nchnd = chnd[sym_respawn]();
            nchnd.name = chnd.name;
            this[sym_reset]();
            this[sym_rdy]();
            this[sym_launch]();
            nchnd[sym_rdy]();
            nchnd[sym_launch]();
        } else {
            console.log(`should-not-called-at-this-time`)
        }
    }
    get curr_pending_tsk_() {
        let children = this.$children_;
        for(let chnd of children) {
            if(chnd.is_pending()) {
                return(chnd)
            } else {}
        }
        return(null)
    }
    get curr_paused_tsk_() {
        if(this.is_paused()) {
            let children = this.$children_;
            for(let chnd of children) {
                if(chnd.is_paused()) {
                    return(chnd)
                } else {}
            }
            return(this)
        } else {
            return(null)
        }
    }
    pause() {
        if(this.is_pending()) {
            let chnd = this.curr_pending_tsk_;
            if(chnd!==null) {
                chnd[sym_pause]();
                let nchnd = chnd[sym_respawn]();
                nchnd.name = chnd.name;
                nchnd[sym_rdy]();
                nchnd[sym_launch]();
                nchnd[sym_pause]();
            } else {
            }
            this[sym_pause]();
        } else {

        }
    }
    continue() {
        if(this.is_paused()) {
            let chnd = this.curr_paused_tsk_;
            if(chnd!==null) {
                if(chnd === this) {
                    let fstch = this.$fstch_;
                    if(fstch!==null) {
                        if(fstch.is_rejected()) {
                            src[sym_reset]();
                            src[sym_rdy]();
                            src[sym_launch]();
                        } else {
                            console.log('impossible')
                        }
                    } else {
                    }
                } else {
                    chnd[sym_continue]()
                }
                this[sym_continue]()
            } else {
                console.log('impossible')
            }
        } else {}
    }
}

const Forest = require("nv-data-tree-csp-forest");

function creat_serial(forest,max_size=10000,rtrn_forest=true) {
    forest = forest??(new Forest(max_size));
    let serial = forest.node(Serial);
    serial.enable_promise();
    serial.regis_$recv$(
        (src,self)=> {
            ////
            if(src.is_resolved()){
                 if(src.$is_lstch()) {
                     self[sym_rs](src.rslt_);
                 } else {
                     let rsib = src.$rsib_;
                     if(rsib!==null) {
                         if(rsib.is_settled()) {
                             console.log('impossible:rsib selttled')
                         } else {
                            rsib[sym_rdy]();
                            rsib[sym_launch]();
                         }
                     } else {
                          console.log('impossible:lstch')
                     }
                 }
            } else if(src.is_rejected()) {
                self[sym_rj](src.exception_)
            } else {
                console.log('impossible:not-settled')
            }
        }
    );
    if(rtrn_forest) {
        return([serial,forest])
    } else {
        return(serial)
    }
}


module.exports = creat_serial;
