const {
   noexist,
   STATE_LABEL_DICT,
   ////
   sym_rs,
   sym_rj,
   sym_exec,
   sym_pause,
   sym_continue,
   sym_reset,
   sym_respawn,
   sym_rdy,
   sym_launch,
   DFLT_CU_EXECUTOR,
   DFLT_EXEC_WRAP,
   DFLT_RECV,
   ////
   Base
} = require("nv-task-event-basic");


const ERROR = {
    already_started:'already_started'
}


class Parallel extends Base {
    ////
    add(name,o,Cls=Base) {
        if(this.is_pending() || this.is_settled()) {
            console.log(ERROR.already_started)
        } else {
            let chnd;
            if(o instanceof Function) {
                let forest = this.$forest_;
                chnd = forest.node(Cls);
                chnd.exec_ = o;
                this.$append_child(chnd)
            } else {
                chnd = this.$append_child(o)
            }
            chnd.name = name;
        }
    }
    ////
    start() {
        this[sym_rdy]();
        let children = this.$children_;
        children.forEach(chnd=>chnd[sym_rdy]());
        ////
        this[sym_launch]();
        children.forEach(chnd=>chnd[sym_launch]());
        return(this.p_)
    }
    reset() {
        let children = this.$children_;
        children.forEach(chnd=>{
            let nchnd = chnd[sym_respawn]();
            nchnd.name = chnd.name;
        });
        children = this.$children_;
        this[sym_reset]();
    }
    reset_and_start_from_failed() {
        let children = this.$children_;
        children = children.filter(chnd=>chnd.is_rejected());
        children.forEach(chnd=>{ 
            let nchnd = chnd[sym_respawn]();
            nchnd.name = chnd.name;
            this[sym_reset]();
            this[sym_rdy]();
            this[sym_launch]();
            nchnd[sym_rdy]();
            nchnd[sym_launch]();
        }
    }
    pause() {
        if(this.is_pending()) {
            let children = this.$children_;
            children = children.filter(chnd=>chnd.is_pending());
            children.forEach(chnd=>{
                chnd[sym_pause]();
                let nchnd = chnd[sym_respawn]();
                nchnd.name = chnd.name;
                nchnd[sym_rdy]();
                nchnd[sym_launch]();
                nchnd[sym_pause]();
            });
            children = this.$children_;
            this[sym_pause]()
        } else {

        }
    }
    continue() {
        if(this.is_paused()) {
            let children = this.$children_;
            children = children.filter(chnd=>chnd.is_paused());
            children.forEach(chnd=>chnd[sym_continue]());
            this[sym_continue]()
        } else {}
    }
    ////
    is_all_settled() {
        let children = this.$children_;
        children = children.filter(chnd=>!chnd.is_settled());
        return(children.length===0)
    }
}

const Forest = require("nv-data-tree-csp-forest");

function creat_parallel(forest,max_size=10000,rtrn_forest=true) {
    forest = forest??(new Forest(max_size));
    let parallel = forest.node(Parallel);
    parallel.enable_promise();
    parallel.regis_$recv$(
        (src,self)=> {
            ////
            if(src.is_resolved()) {
                 if(self.is_all_settled()) {
                     self[sym_rs](self.$children_.map(chnd=>chnd.rslt_));
                 } else {}
            } else if(src.is_rejected()) {
                 self[sym_rj](src.exception_)
            } else {
                console.log('impossible')
            }
        }
    );
    if(rtrn_forest) {
        return([parallel,forest])
    } else {
        return(parallel)
    }
}


module.exports = creat_parallel;
