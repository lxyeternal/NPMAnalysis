module.exports = function(sequelize, DataTypes) {
  return sequelize.define("Games", {
    gameID: { type: DataTypes.INTEGER, primaryKey: true },
    team: { type: DataTypes.STRING(3), primaryKey: true },
    opponent: { type: DataTypes.STRING(3) },
    winner: { type: DataTypes.STRING(3) },
    loser: { type: DataTypes.STRING(3) },
    location: DataTypes.STRING(4),
    result: DataTypes.STRING(1),
    points: DataTypes.INTEGER,
    gameType: DataTypes.STRING(3),
    date: DataTypes.INTEGER,
    time: DataTypes.INTEGER,
    referee1: DataTypes.STRING,
    referee2: DataTypes.STRING,
    linesman1: DataTypes.STRING,
    linesman2: DataTypes.STRING,
    coach: DataTypes.STRING
  }, { 
    tableName: 'Games'+global.halcyonSingleton.season+'' 
  });
};
