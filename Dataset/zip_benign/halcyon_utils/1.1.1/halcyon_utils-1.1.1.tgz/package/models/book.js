module.exports = function(sequelize, DataTypes) {
  return sequelize.define("Books", {
    gameID: { type: DataTypes.INTEGER, primaryKey: true },
    team: { type: DataTypes.STRING(3), primaryKey: true },
    bookID: { type: DataTypes.INTEGER, primaryKey: true },
    location: DataTypes.STRING(4),
    odds: DataTypes.DECIMAL(10, 6),
    bookName: DataTypes.STRING
  }, { 
    tableName: 'Books'+global.halcyonSingleton.season+''
  });
};
