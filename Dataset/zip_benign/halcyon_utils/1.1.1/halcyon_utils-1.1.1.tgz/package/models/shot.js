module.exports = function(sequelize, DataTypes) {
  return sequelize.define("Shots", {
    type: DataTypes.STRING,
    eventID: { type: DataTypes.INTEGER, primaryKey: true },
    gameID: { type: DataTypes.INTEGER, primaryKey: true },
    shooter: DataTypes.STRING,
    goalie: DataTypes.STRING,
    team: { type: DataTypes.STRING(3), index: true },
    opponent: { type: DataTypes.STRING(3), index: true },
    period: DataTypes.INTEGER,
    time: DataTypes.INTEGER,
    state: DataTypes.STRING(3),
    EN: DataTypes.STRING(1),
    strength: DataTypes.STRING(2),
    scoreState: { type: DataTypes.STRING, index: true },
    leadingScore: DataTypes.INTEGER,
    scoreDiff: { type: DataTypes.INTEGER, index: true },
    distance: DataTypes.INTEGER,
    xCoord: DataTypes.INTEGER,
    yCoord: DataTypes.INTEGER,
    shotType: DataTypes.STRING,
    zone: DataTypes.STRING(3),
    players: DataTypes.STRING,
  }, {
    tableName: 'Shots'+global.halcyonSingleton.season+''
  });
};
