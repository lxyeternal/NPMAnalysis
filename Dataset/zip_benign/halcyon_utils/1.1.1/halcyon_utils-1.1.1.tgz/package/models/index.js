"use strict";
var fs = require('fs')
  , path  = require('path')
  , Sequelize = require('sequelize')
  , basename = path.basename(module.filename)
  , sequelize
;

module.exports = function(options) {
  var options = options || global.halcyonSingleton.DBOptions
    , db = {};

  if (!options) {
    throw new Error('Cannot generate sequelize models without options for database connection');
  }

  sequelize = new Sequelize(options.database, options.user, options.password, {
      host:     options.host,
      dialect:  'mysql',
      port:     options.port,
      logging: false,
      pool: {
        max: 100,
        min: 0,
        idle: 1000
      }
  });

  fs.readdirSync(__dirname).filter(function(file) {
      return (file.indexOf(".") !== 0) && (file !== basename);
    }).forEach(function(file) {
      var model = sequelize.import(path.join(__dirname, file));
      db[model.name] = model;
    });

  Object.keys(db).forEach(function(modelName) {
    if ('associate' in db[modelName]) {
      db[modelName].associate(db);
    }
  });

  db.sequelize = sequelize;
  db.Sequelize = Sequelize;

  return db;
}
