module.exports = function(sequelize, DataTypes) {
  return sequelize.define("PlayerIDs", {
    id: { type: DataTypes.INTEGER, primaryKey: true },
    name: DataTypes.STRING(50),
    jersey: DataTypes.INTEGER,
    shoots: DataTypes.STRING(50)
  }, {
    tableName: "playerIDs"
  });
};
