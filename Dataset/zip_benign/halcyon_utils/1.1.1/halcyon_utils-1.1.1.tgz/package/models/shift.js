module.exports = function(sequelize, DataTypes) {
  return sequelize.define("Shifts", {
    shiftID: { type: DataTypes.INTEGER, primaryKey: true },
    gameID: { type: DataTypes.INTEGER, primaryKey: true },
    player: { type: DataTypes.STRING, primaryKey: true },
    team: DataTypes.STRING(3),
    period: DataTypes.INTEGER,
    start: DataTypes.INTEGER,
    end: DataTypes.INTEGER,
    duration: DataTypes.INTEGER,
  }, {
    tableName: 'Shifts'+global.halcyonSingleton.season+''
  });
};
