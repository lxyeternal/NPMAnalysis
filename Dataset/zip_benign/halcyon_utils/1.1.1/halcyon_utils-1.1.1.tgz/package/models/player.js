module.exports = function(sequelize, DataTypes) {
  return sequelize.define("Players", {
    name: { type: DataTypes.STRING, primaryKey: true },
    position: DataTypes.STRING(2),
    shoots: DataTypes.STRING(5),
    height: DataTypes.INTEGER,
    weight: DataTypes.INTEGER
  }, {
    tableName: 'Players'
  });
};
