module.exports = function(sequelize, DataTypes) {
  return sequelize.define("Penalties", {
    type: DataTypes.STRING,
    eventID: { type: DataTypes.INTEGER, primaryKey: true },
    gameID: { type: DataTypes.INTEGER, primaryKey: true },
    player: DataTypes.STRING,
    drawnBy: DataTypes.STRING,
    penaltyType: DataTypes.STRING,
    PIM: DataTypes.INTEGER,
    team: DataTypes.STRING(3),
    opponent: DataTypes.STRING(3),
    period: DataTypes.INTEGER,
    time: DataTypes.INTEGER,
    state: DataTypes.STRING(3),
    EN: DataTypes.STRING(1),
    strength: DataTypes.STRING(2),
    scoreState: DataTypes.STRING,
    leadingScore: DataTypes.INTEGER,
    scoreDiff: DataTypes.INTEGER,
    zone: DataTypes.STRING(3),
    xCoord: DataTypes.INTEGER,
    yCoord: DataTypes.INTEGER,
    players: DataTypes.STRING,
  }, {
    tableName: 'Penalties'+global.halcyonSingleton.season+''
  });
};
