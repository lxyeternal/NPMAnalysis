module.exports = function(sequelize, DataTypes) {
  return sequelize.define("Stoppages", {
    type: DataTypes.STRING,
    eventID: { type: DataTypes.INTEGER, primaryKey: true },
    gameID: { type: DataTypes.INTEGER, primaryKey: true },
    time: DataTypes.INTEGER,
    period: DataTypes.INTEGER,
    stoppageReason: DataTypes.STRING,
    timeOut: DataTypes.STRING(3)
  }, {
    tableName: 'Stoppages'+global.halcyonSingleton.season+''
  });
};
