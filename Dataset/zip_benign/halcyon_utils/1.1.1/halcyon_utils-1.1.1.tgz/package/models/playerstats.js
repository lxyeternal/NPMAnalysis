module.exports = function(sequelize, DataTypes) {
  return sequelize.define("PlayerStats", {
    player: { type: DataTypes.STRING, primaryKey: true },
    gameID: { type: DataTypes.INTEGER, primaryKey: true },
    //particular player's stats
    GF: DataTypes.INTEGER,
    GA: DataTypes.INTEGER,
    SF: DataTypes.INTEGER,
    SA: DataTypes.INTEGER,
    MF: DataTypes.INTEGER,
    MA: DataTypes.INTEGER,
    BF: DataTypes.INTEGER,
    BA: DataTypes.INTEGER,
    FOW: DataTypes.INTEGER,
    FOL: DataTypes.INTEGER,
    HF: DataTypes.INTEGER,
    HA: DataTypes.INTEGER,
    //maybe do both?
    GVF: DataTypes.INTEGER,
    //giveawaysFor: DataTypes.INTEGER,
    GVA: DataTypes.INTEGER,
    //giveawaysAgainst: DataTypes.INTEGER,
    TKF: DataTypes.INTEGER,
    //takeawaysFor: DataTypes.INTEGER,
    TKA: DataTypes.INTEGER,
    //takeawaysAgainst: DataTypes.INTEGER,
    SOGF: DataTypes.INTEGER,
    SOGA: DataTypes.INTEGER,
    PF: DataTypes.INTEGER,
    PA: DataTypes.INTEGER,
    //while the player was on the ice stats
    TGF: DataTypes.INTEGER,
    TGA: DataTypes.INTEGER,
    TSF: DataTypes.INTEGER,
    TSA: DataTypes.INTEGER,
    TMF: DataTypes.INTEGER,
    TMA: DataTypes.INTEGER,
    TBF: DataTypes.INTEGER,
    TBA: DataTypes.INTEGER,
    TFOW: DataTypes.INTEGER,
    TFOL: DataTypes.INTEGER,
    THF: DataTypes.INTEGER,
    THA: DataTypes.INTEGER,
    //maybe do both?
    TGVF: DataTypes.INTEGER,
    //teamGiveawaysFor: DataTypes.INTEGER,
    TGVA: DataTypes.INTEGER,
    //teamGiveawaysAgainst: DataTypes.INTEGER,
    TTKF: DataTypes.INTEGER,
    //teamTakeawaysFor: DataTypes.INTEGER,
    TTKA: DataTypes.INTEGER,
    //teamTakeawaysAgainst: DataTypes.INTEGER,
    TPF: DataTypes.INTEGER,
    TPA: DataTypes.INTEGER
  }, {
    tableName: "PlayerStats"+global.halcyonSingleton.season+''
  });
};