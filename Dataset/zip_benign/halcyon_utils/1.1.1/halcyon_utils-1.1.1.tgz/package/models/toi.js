module.exports = function(sequelize, DataTypes) {
  return sequelize.define("TOI", {
    gameID: { type: DataTypes.INTEGER, primaryKey: true },
    player: { type: DataTypes.STRING, primaryKey: true },
    team: DataTypes.STRING(3),
    shifts: DataTypes.INTEGER,
    EV: DataTypes.INTEGER,
    PP: DataTypes.INTEGER,
    SH: DataTypes.INTEGER,
    average: DataTypes.INTEGER,
    total: DataTypes.INTEGER,
    position: DataTypes.STRING
  }, {
    tableName: 'TOI'+global.halcyonSingleton.season+''
  });
};
