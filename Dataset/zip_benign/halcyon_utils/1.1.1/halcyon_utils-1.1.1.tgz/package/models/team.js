module.exports = function(sequelize, DataTypes) {
  return sequelize.define("Teams", {
    name: { type: DataTypes.STRING, primaryKey: true },
    short: { type: DataTypes.STRING, unique: true, allowNull: false },
    numericID: { type: DataTypes.INTEGER, unique: true, allowNull: true },
  }, {
    tableName: 'Teams'+global.halcyonSingleton.season+''
  });
};