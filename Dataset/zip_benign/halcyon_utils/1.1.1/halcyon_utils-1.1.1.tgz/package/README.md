# Halcyon Utilities

This repo contains utility functions which are needed across various parts of the project, whether it be the models to query, the Schedule to get date and game information, the Simulator to run predictions against the odds in the database, or just some miscellaneous functions.

## APIs

### Simulate
```
var simulate = require('halcyon_utils').simulate;

simulate(season, bets[, options])
```

Simulate takes in 3 arguments: a season, a bets array (or the filename of a .json file containing a bets array), and an options object. From this, it calculates the bets you would have made, how many you were correct on, and how much money you would have made given the parameters in the options object.

#### season

The "season" string for the 2015-2016 season, for example, would look like '20152016'.

#### bets

The "bets" array should be an array of objects, of form 
```
{ gameID: '2014020001', home: 0.5 }
```
where 'gameID' is a valid gameID for the season you have listed, and 'home' is the percent chance of the home team winning, expressed as a decimal. If a game is not listed by gameID in the array OR if the gameID is listed and home is set below 0, the simulator will not bet on this game.

#### options

The options object can contain the following parameters:

| Parameter | Default | Behavior |
|-----------|---------|--------------------------------------------------------------------------------------------|
| books     | ['Pinnacle', 'FiveDimes', 'bodog', 'SportsInteraction'] | Changes the books which will be looked at for odds. If set to an empty array or ANY string, it will include all books. |
| initialFunds | $5000 | The initial value of your betting pool. |
| percentOfFundsToBet | 0.02 | The percentage of your funds at the start of each day which you bet on each game. |
| decisionFunction | expectedWinPct > necessaryToBreakEvenOn(decimalOdds) | A function passed the expected win percentage as specified for each team and the odds of that team winning, which returns true if you would bet on that game and false if you would not. |
| sequelizeOptions | - | Information to connect to a database if you don't use a local DB called halcyonnhl with user root and password 'password'. |

### Schedule

Coming soon...

### Misc

Coming soon...