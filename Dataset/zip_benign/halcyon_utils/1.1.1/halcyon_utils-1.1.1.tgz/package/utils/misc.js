exports.pad = function(number, width, fillChar) {
  	fillChar = fillChar || '0';
  	number = number + '';
  	if (number.length > 4) {
  		number = number.substr(number.length-4);
  	}
  	return number.length >= width ? number : new Array(width - number.length + 1).join(fillChar) + number;
}

exports.TimeToSeconds = function(t) {
	var val = 0;
	if (t.length == 4) {
		val = Number(t.substr(0,1))*60 + Number(t.substr(2))
	} else if (t.length == 5) {
		val = Number(t.substr(0,2))*60 + Number(t.substr(3))
	}
	return val;	
}

exports.getCurrentDate = function() {
  var date = (new Date()).toISOString().slice(0,13).replace(/-/g,"").replace(/T/g,"");
  var year = date.slice(0,4),
      month = date.slice(4,6),
      day = date.slice(6,8),
      hour = date.slice(8,10);
  if ((hour - 8) < 0) { day--; }
  return ''+year+''+exports.pad(month, 2)+''+exports.pad(day, 2)
}

exports.isValidSeason = function(season) {
  if (!season) return false;
  //season of form 20142015 is valid because 2014 == 2015-1, etc.
  if (typeof season != 'string') season = season.toString();
  return (parseInt(season.substr(0,4)) == parseInt(season.substr(4,8))-1);
}

exports.playTypes = ['GOAL', 'SHOT', 'MISS', 'BLOCK', 'HIT', 'TAKE', 'GIVE', 'PENL', 'FAC'];
exports.metaTypes = ['STOP', 'PSTR', 'PEND', 'GEND', 'EIEND', 'EISTR', 'CHL', 'SOC'];
exports.allTypes = exports.playTypes.concat(exports.metaTypes);

exports.books = [
  { ID: 19, name: 'FiveDimes' },
  { ID: 43, name: 'Bet365' },
  { ID: 92, name: 'bodog' },
  { ID: 93, name: 'Bookmaker' },
  { ID: 118, name: 'BetCris' },
  { ID: 227, name: 'TheGreek' },
  { ID: 238, name: 'Pinnacle' },
  { ID: 300, name: 'SportsInteraction' },
  { ID: 349, name: 'WilliamHill' },
  { ID: 1096, name: 'BetOnline' }
]

exports.getBookName = function(bookID) {
  for (var i = 0, len = exports.books.length; i < len; i++) {
    if (exports.books[i].ID == bookID)
      return exports.books[i].name;
  }
  return '';
}

exports.makeObjectWithPropertiesFromArray = function(arr, options) {
  var propsAsArray = options.propsAsArray || false
    , nameOfInputProp = options.nameOfInputProp || 'input'
    , retObj = {}; 
    
  retObj[nameOfInputProp] = arr;

  arr.forEach(function(attr){
    retObj[attr] = options.propsAsArray ? [] : {};
  })

  return retObj;
}

exports.makeObjectWithPropertiesFromArrayWithHomeAndAwayVersions = function(arr, options) {
  options = options || { propsAsArray: false }

  var retObj = { input: arr };
  arr.forEach(function(attr){
    retObj['home'+attr] = options.propsAsArray ? [] : {};
    retObj['away'+attr] = options.propsAsArray ? [] : {};
  })
  return retObj;
}

exports.copyAndDeleteProperty = function(prop, obj) {
  var ret = obj[prop];
  delete obj[prop];
  return ret;
}

exports.dropExtraDecimals = function(number, sigfigs) {
  sigfigs = sigfigs || 4;
  return Number(number.toFixed(sigfigs));
}

var formatDate = function(date) {
  date = date.toString();
  return new Date(date.slice(0,4)+'-'+date.slice(4,6)+'-'+date.slice(6,8));
}

exports.calculateDifferenceBetweenYYYYMMDDDates = function(d, e) {
  d = formatDate(d), e = formatDate(e);
  d = new Date(d);
  e = new Date(e);

  var ret = Math.round((d - e) / (1000*60*60*24));
  return ret;
}

exports.numericalOrder = function(a, b){ 
  if (a > b) return 1; 
  if (a < b) return -1; 
  return 0; 
}

exports.weightedAverage = function(a, b) {
  var lastB = b[b.length-1], bOrLastB;

  var totalWeight = 0;
  b.forEach(function(val) { totalWeight += val });
  if (b.length < a.length) totalWeight += lastB * (a.length - b.length);

  var retSum = 0;
  for (var i = 0, len = a.length; i < len; i++) {
    bOrLastB = b[i] || lastB;
    retSum += (a[i] * bOrLastB) / totalWeight;
  }
  return retSum;
}