var mysql = require('mysql')
  , Promise = require('bluebird');
  
Promise.promisifyAll(require('mysql/lib/Pool').prototype);
Promise.promisifyAll(require('mysql/lib/Connection').prototype);

module.exports = function() {
  var pool = mysql.createPool({
    connectionLimit: 1000,
    database: global.halcyonSingleton.DBOptions.database,
    host: global.halcyonSingleton.DBOptions.host,
    user: global.halcyonSingleton.DBOptions.user,
    password: global.halcyonSingleton.DBOptions.password
  });

  return pool.getConnectionAsync();
}