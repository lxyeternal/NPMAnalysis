var path = require('path');
var Promise = require('bluebird');
var Request = require(path.join(__dirname,'Request'));
var misc = require(path.join(__dirname,'misc'));
var Teams = require(path.join(__dirname,'Teams'));

var oldSeasonScheduleArrayBuilder = function(season) {
  //there was no schedule available, so we don't know the dates ahead of time
  /* Declaring a new Array(N) makes an object with length N but doesn't actually
    declare the key for the values (where the key in the expression array[0] is 0), 
    so .map doesn't even see these keys, so even tho it's a length N array it has 0 keys.
    Array.apply is a cool trick to mitigate this problem, see: 
    //http://stackoverflow.com/questions/18947892/creating-range-in-javascript-strange-syntax/18949651#18949651*/
  return Array.apply(null, {length: 1230}).map((neverDefined, index) => { return {id: misc.pad((index+1), 4), date: undefined}; });
}

var seasonScheduleArrayBuilder = function(season) {
  teams = new Teams(season);
  var scheduleURL = 'http://live.nhl.com/GameData/SeasonSchedule-'+season+'.json';

  return Request({
    //make a get request to nhl.com, to get the specified file
    method: 'GET',
    host: 'live.nhl.com',
    port: 80,
    path: scheduleURL
  }).then(function(data) {
    var gamesList = JSON.parse(data.body)
      , today = misc.getCurrentDate()
      , games = [];
      
    gamesList.forEach(function(game){
      if (game.est.slice(0,8) < today && game.id.toString().slice(4,6)=='02') {
        games.push({
          id: misc.pad(game.id % 10000, 4), 
          date: game.est, 
          home: teams.shortFromScoreboardShort(game.h), 
          away: teams.shortFromScoreboardShort(game.a)
        });
      }
    });
    return games;
  })
}

function experimentalAttemptAtGettingDates(season) {
  if (!global.halcyonSingleton) {
    console.log('There is no saved game data for season 20102011, so the schedule could not be built. You will need to get the season data before attempting to save odds for the season');
    throw new Error('No game data to generate schedule from!');
  }

  var teams = new Teams(season);

  return global.halcyonSingleton.getDB()
  .then(db => {
    return db.queryAsync('SELECT gameID, team, opponent, date, time FROM Games'+season+' WHERE location="home"')
    .then(games => games.map(game => { 
      return { 
        id: game.gameID, 
        est: ''+game.date+' '+game.time+'', 
        a: teams.scoreboardShortFromShort(game.opponent),
        h: teams.scoreboardShortFromShort(game.team)
      }; 
    }))
    .then(gamesList => {
      db.destroy();

      return gamesList;
    })
  })
  .catch(err => { throw err; });
}

function putDaysOnSchedule(gamesList) {
  var today = misc.getCurrentDate()
    , dates = []
    , date
    , retObject = { dates: [] };

  gamesList.forEach(function(game){
    date = game.est.slice(0,8);

    if (game.id.toString().slice(4,6) != '02' || today <= date) 
      return;

    if (!retObject[date]){
      retObject[date] = [];
      retObject.dates.push(date);
    }

    retObject[date].push({gameID: game.id, away: game.a, home: game.h, date: date});
  })
  
  return retObject;
}

var seasonScheduleObjectBuilder = function(season) {
  if (season < 20112012) {
    return experimentalAttemptAtGettingDates(season)
    .then(gamesList => putDaysOnSchedule(gamesList))
  }

  return Request({
    method: 'GET',
    host: 'live.nhl.com',
    port: 80,
    path: 'http://live.nhl.com/GameData/SeasonSchedule-'+season+'.json'
  }).then(data => putDaysOnSchedule(JSON.parse(data.body)));
}

var getTeamsFor = function(season){
  return [
    'N.J', 'NYI', 'NYR', 'PHI', 'PIT', 'BOS', 'BUF',
    'MTL', 'OTT', 'TOR', 'CAR', 'FLA', 'T.B', 'WSH',
    'CHI', 'DET', 'NSH', 'STL', 'CGY', 'COL', 'EDM',
    'VAN', 'ANA', 'DAL', 'L.A', 'S.J', 'CBJ', 'MIN',
    season < 20142015 ? 'PHX' : 'ARI',
    season < 20112012 ? 'ATL' : 'WPG'
  ];
}

exports.getTeamGameLists = function(season) {
  var teams = getTeamsFor(season), 
      schedule = { teams: teams };

  teams.forEach(team => { schedule[team] = []; })
  
  return global.halcyonSingleton.getDB()
  .then(db => {
    return db.queryAsync(
      "SELECT * FROM Games"+global.halcyonSingleton.season+" ORDER BY date"
    )
    .then(result => {
      db.destroy();

      return result;
    })
  })
  .then(result => {
    result.forEach(game => {
      schedule[game.team].push(game.gameID);

      if (typeof schedule[game.gameID] != 'object') { 
        schedule[game.gameID] = {}; 
      }
      
      schedule[game.gameID][game.team] = schedule[game.team].length-1;
    })

    return schedule;
  })
}

exports.getDates = function(season) {
  return seasonScheduleObjectBuilder(season)
  .then(function(schedule){
    return exports.getTeamGameLists(season)
    .then(function(gameLists){
      schedule.season = season;
      schedule.gameLists = gameLists;

      schedule.getLastXGameIDs = function(team, gameID, lastX) {
        gameID = gameID.toString();
        lastX = lastX || 0;

        if (lastX < 1) 
          lastX = 200;

        var cur = this.gameLists[team].indexOf(gameID)
          , first = Math.max((cur-lastX), 0);

        if (cur < 0) 
          finish(team+' has no game with ID '+gameID+', exiting...');

        return this.gameLists[team].slice(first, cur);
      }
      
      return schedule;
    })
  });
}

exports.get = function(season) {
  return season < 20112012 ? Promise.resolve(oldSeasonScheduleArrayBuilder(season)) : seasonScheduleArrayBuilder(season);
}

if (require.main === module) {
  exports.getGamesFor('20152016').then(console.log);
}