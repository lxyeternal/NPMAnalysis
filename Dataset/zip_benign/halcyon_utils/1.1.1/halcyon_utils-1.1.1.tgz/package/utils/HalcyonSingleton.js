var path = require('path')
  , Models = require(path.join(__dirname,'..','models'))
  , getDBConnection = require(path.join(__dirname,'getDBConnection'))
  , misc = require(path.join(__dirname,'misc'))
;

class HalcyonSingleton {
  constructor(season, options) {
    options = getDBOptions(options);

    this.season = season;
    this.DBOptions = options;
    this.getDB = getDBConnection;
    this.dataDirectory = options.directory;
    this.models = false;
    this.gameID = -1;
  }

  getModels(season) {
    var seasonWhenFunctionCalled = this.season;

    if (misc.isValidSeason(season))
      this.season = season;

    var models = Models();

    this.season = seasonWhenFunctionCalled;

    return models;
  }

  setSeason(season) {
    if (misc.isValidSeason(season))
      this.season = season;
  }

  getSeason() {
    return this.season ? this.season.toString() : null;
  }
}

module.exports = HalcyonSingleton;

/* UTILITIES */

function getDBOptions(options) {
  var defaults = {
    database: 'halcyonnhl',
    host: 'localhost',
    user: 'root',
    password: 'password',
    port: 3306,
    directory: undefined
  };

  if (!options) {
    return defaults;
  }

  var retOptions = {}
    , copy = {};

  if (options.host || options.database || options.user || options.password || options.connectionLimit || options.port || options.directory)
    copy = options;

  for (var prop in defaults) {
    retOptions[prop] = (copy[prop] ? copy[prop] : defaults[prop]);
  }

  return retOptions;
}
