var path = require('path')
  , fs = require('fs')
  , htmlparser = require('htmlparser2')
  , Promise = require('bluebird')
  , misc = require(path.join(__dirname,'misc'))
  , Request = require(path.join(__dirname,'Request'))
  , Schedule = require(path.join(__dirname,'Schedule'));

Promise.promisifyAll(fs);

function getFilePaths(season, gameID) {
  var dir = global.halcyonSingleton.dataDirectory
    , extensions = ['ATOI.html', 'HTOI.html', 'PbP.html', 'ROSTER.html', 'JSON.json'];

  return extensions.map(function(ext){
    return path.join(dir,season,season.substr(0,4)+'02'+misc.pad(gameID,4)+ext);
  })
}

function getUrlPaths(season, gameID) {
	return [
    '/scores/htmlreports/'+season+'/TV02'+misc.pad(gameID, 4)+'.HTM',
    '/scores/htmlreports/'+season+'/TH02'+misc.pad(gameID, 4)+'.HTM',
    '/scores/htmlreports/'+season+'/PL02'+misc.pad(gameID, 4)+'.HTM',
    '/scores/htmlreports/'+season+'/RO02'+misc.pad(gameID, 4)+'.HTM',
    '/GameData/'+season+'/'+season.substr(0,4)+'02'+misc.pad(gameID, 4)+'/PlayByPlay.json'
  ];
}

function ensureDataSheetExists(season, gameID, filePath, urlPath) {
	try {
		if(fs.lstatSync(filePath).isFile()) {
      return Promise.resolve();
		}
	} catch(e) {}

	if (urlPath.substr(1,8) == 'GameData') {
		hostName = 'live.nhl.com';
	} else {
		hostName = 'www.nhl.com';
	}

	return Request({
	    method: 'GET',
	    host: hostName,
	    port: 80,
	    path: urlPath
	}).then(function(data) {
		return fs.writeFileAsync(filePath, data.body, 'utf8')
	})
}

exports.ensureDataSheetsExist = function(season, gameID) {
  var dir = global.halcyonSingleton.dataDirectory
    , filePaths = getFilePaths(season, gameID, dir)
    , urlPaths = getUrlPaths(season, gameID);

  return Promise.all(filePaths.map(function(item, index, array) {
    return ensureDataSheetExists(season, gameID, filePaths[index], urlPaths[index]);
  }))
}

var oddsURL = 'http://www.sportsbookreview.com/betting-odds/nhl-hockey/?date=';

function ensureOddsSheetExists(season, date) {
  var dir = global.halcyonSingleton.dataDirectory
    , filePath = path.join(dir,season,'oddsFor'+date)

  try {
    if(fs.lstatSync(filePath)) {
      return Promise.resolve();
    }
  } catch(e) {}
  
  return Request({
    method: 'GET',
    host: 'www.sportsbookreview.com',
    port: 80,
    path: '/betting-odds/nhl-hockey/?date='+date
  }).then(data => fs.writeFileAsync(filePath, data.body, 'utf8'))
}

exports.ensureOddsSheetsExist = function(season) {
  return Schedule.getDates(season)
  .then(function(datesAndGames){
    return Promise.all(datesAndGames.dates.map(function(date){
      return ensureOddsSheetExists(season, date);
    }))
  })
}

if (require.main === module) {
	var season = '';
	try {
		if (season = process.argv[2] + '') {
			if (!(parseInt(season.substr(0,4)) == parseInt(season.substr(4,8))-1)) {
				season = '20142015';
			}
		} else {
			season = '20142015';
		}
	} catch (err) {
		season = '20142015';
	}
	exports.ensureOddsSheetsExist('20152016').then(function() {
		console.log('Success!');
	}).catch(console.log);
}
