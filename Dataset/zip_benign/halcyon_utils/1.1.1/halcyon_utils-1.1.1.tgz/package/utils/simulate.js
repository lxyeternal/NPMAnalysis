var path = require('path')
  , fs = require('fs')
  , Schedule = require(path.join(__dirname,'Schedule'))
  , misc = require(path.join(__dirname,'misc'))
  , Teams = require(path.join(__dirname,'Teams'))
  , constructHalcyonSingleton = require(path.join(__dirname,'halcyonSingleton'));

function numericalOrder(a, b) {
  if (a < b) {
    return -1;
  } else if (a > b) {
    return 1;
  } else {
    return 0;
  }
}

function transformIntoObject(oddsArray) {
  var retObj = {};

  oddsArray.forEach(function(book){
    if (!retObj[book.gameID] || typeof retObj[book.gameID] != 'object') {
      retObj[book.gameID] = { 
        home: [], 
        away: [] 
      };
    }

    if (book.odds) {
      retObj[book.gameID][book.location].push(book);
    }
  })

  return retObj;
}

function putWinnerAndBetsOnGames(schedule, gamesArray, bets) {
  gamesArray.forEach(function(summary){
    schedule[summary.date].forEach(function(game){
      if (game.gameID == summary.gameID) {
        game.winner = summary.winner;
        game.homePct = bets[game.gameID] ? bets[game.gameID].home : -1;
        game.awayPct = bets[game.gameID] ? bets[game.gameID].away : -1;
      }
    })
  })

  return schedule;
}

function brokenOdds(odds, gameID) {
  if (!odds || odds.home.length <= 0 || odds.away.length <= 0 || ['2015020704', '2015020716'].indexOf(gameID.toString()) >= 0)
    return true;

  return false;
}

function findBest(odds) {
  var ret = false;

  if (odds[0]) {
    ret = odds[0].odds;

    odds.forEach(function(book){
      if (book.odds > ret)
        ret = book.odds;
    })
  }

  return ret;
}

function findWorst(odds) {
  var ret = false;

  if (odds[0]) {
    ret = odds[0].odds;
    
    odds.forEach(function(book){
      if (book.odds < ret) 
        ret = book.odds;
    })
  }

  return ret;
}

function findBook(odds, bookName) {
  var ret = false;

  odds.forEach(function(book){
    if (book.bookName == bookName)
      ret = book.odds;
  })

  return ret;
}

function getOddsFunction(mode) {
  if (mode == 'worst')
    return findWorst;
  else if (mode == 'best')
    return findBest;
  else 
    return findBook;
}

function rightPad(input, outputLength, char) {
  char = char || ' ';
  if (char.length < 1)
    char = ' ';

  while (input.length < outputLength) {
    input += char;
  }

  return input;
}

class Tracker {
  constructor(options, mode){
    this.mode = mode;
    this.initialFunds = options.initialFunds;
    this.funds = options.initialFunds;
    this.percentOfFundsToBet = options.percentOfFundsToBet;
    this.currentBet = this.funds * this.percentOfFundsToBet;
    this.placedBetEarnings = [];

    this.betCount = 0;
    this.correct = 0;
    this.doBetOnTeam = options.decisionFunction;
    this.findOdds = getOddsFunction(mode).bind(this);
  }

  prepareNextDay() {
    //note that this can be a bunch of negative numbers
    if (this.placedBetEarnings.length > 0) {
    }
    while (this.placedBetEarnings.length > 0) {
      this.funds += this.placedBetEarnings.shift();
    }

    this.currentBet = this.funds * this.percentOfFundsToBet;
  }

  update(game, oddsData) {
    ['home', 'away'].forEach(function(team){
      var odds = this.findOdds(oddsData[team], this.mode);

      if (odds > 0 && this.doBetOnTeam(game[team+'Pct'], odds)) {
        this.betCount++;
        this.placedBetEarnings.push(-this.currentBet);

        if (game[team] == game.winner) {
          this.placedBetEarnings.push(this.currentBet * odds);
          this.correct++;
        }
      } 
    }.bind(this))
  }

  getResults() {
    var desc = (['best', 'worst'].indexOf(this.mode) >= 0 ? 'Using the '+this.mode+' lines for this season, ' : 'Using lines from '+this.mode+', ');

    console.log(desc+'you bet correctly on '+this.correct+'/'+this.betCount+' games.');
    console.log('Initial: $'+this.options.initialFunds+'\t\tFinal: $'+this.funds.toFixed(2)+'\t\tProfit: $'+(this.funds - this.options.initialFunds).toFixed(2)+'\t\tRatio: '+(this.funds / this.options.initialFunds).toFixed(2));
  }

  toString() {
    var stringRepresentation = 'Method: '+rightPad(this.mode, 20, ' ')+' Initial: $'+rightPad(this.initialFunds.toFixed(2), 15, ' ')+' Finishing: $'+rightPad(this.funds.toFixed(2), 15, ' ')
                             + ' Bets: '+this.correct+' / '+this.betCount+' ('+(100 * this.correct / this.betCount).toFixed(2)+'%)';

    return stringRepresentation;
  }
}

class BetTracker {
  constructor(options) {
    this.trackers = options.books.concat(['best', 'worst']).map(function(mode){
      return new Tracker(options, mode);
    })
  }

  prepareNextDay() {
    this.trackers.forEach(function(tracker){
      tracker.prepareNextDay()
    });
  }

  update(game, odds) {
    this.trackers.forEach(function(tracker){
      tracker.update(game, odds);
    })
  }

  getResults() {
    this.trackers.forEach(function(tracker){
      tracker.getResults();
    })
  }

  toString() {
    var stringRepresentation = '';

    this.trackers.forEach(tracker => {
      stringRepresentation += tracker.toString() + '\n';
    })

    return stringRepresentation;
  }
}

var simulateSeason = function(oddsObj, schedule, season, options) {
  var gameID
    , teams = new Teams(season)
    , betTracker = new BetTracker(options);

  schedule.dates.forEach(function(date){
    schedule[date].forEach(function(game){
      gameID = game.gameID;

      if (brokenOdds(oddsObj[gameID], gameID)) {
        return;
      }

      if (game.homePct >= 0) {
        game.winner = teams.scoreboardShortFromShort(game.winner);

        betTracker.update(game, oddsObj[gameID]);
      }
    })

    betTracker.prepareNextDay();
  })

  return betTracker;
}

function makeBetsObject(bets) {
  var retObject = {};

  bets.forEach(function(bet){
    retObject[bet.gameID] = { home: bet.home, away: (1 - bet.home) };
  })

  return retObject;
}

function necessaryToBreakEvenOn(decimalOdds) {
  return 1 / decimalOdds;
}

function setOptions(options){
  var defaultOptions = {
    books: [
      'Pinnacle',
      'FiveDimes',
      'SportsInteraction',
      'bodog'
    ],
    initialFunds: 5000,
    percentOfFundsToBet: 0.02,
    decisionFunction: function(expectedWinPct, decimalOdds) {
      if (expectedWinPct > necessaryToBreakEvenOn(decimalOdds))
        return true;

      return false;
    }
  };

  if (!options) 
    return defaultOptions;

  if (options.books && (options.books.length == 0 || typeof options.books == 'string')) {
    options.books = misc.books.map(function(book){
      return book.name;
    })
  }

  for (var arg in defaultOptions) {
    if (!options[arg]) 
      options[arg] = defaultOptions[arg];
  }

  return options;
}

function makeBooksQuery(options) {
  if (!options.books) 
    return '';

  var retStr = 'WHERE ';
  options.books.forEach(function(bookName, i){
    if (i > 0) 
      retStr += ' OR ';

    retStr += 'bookName="'+bookName+'"';
  })

  return retStr;
}

module.exports = function(season, bets, options) {
  if (!global.halcyonSingleton) {
    constructHalcyonSingleton(season, options);
  }

  options = setOptions(options);
  bets = makeBetsObject(bets);
  models = global.halcyonSingleton.getModels(season);

  return Schedule.getDates(season)
  .then(function(schedule){
    var whereBooksSatisfyConditions = makeBooksQuery(options);

    return models.sequelize.query("SELECT * FROM Books"+season+" "+whereBooksSatisfyConditions)
    .then(function(oddsQuery){
      return models.sequelize.query("SELECT * FROM Games"+season+" where location='home'")
      .then(function(gamesQuery){

        return simulateSeason(
          transformIntoObject(oddsQuery[0]), 
          putWinnerAndBetsOnGames(schedule, gamesQuery[0], bets),
          season,
          options
        );

      })
    })
  })
}

if (require.main === module) {
  season = process.argv[2];
  betsFile = process.argv[3];

  if (!misc.isValidSeason(season)) {
    process.exit(console.log('Invalid season, exiting...'));
  } else if (season < 20112012) {
    process.exit(console.log('No odds data exists previous to 20112012, exiting...'));
  } else if (!betsFile) {
    process.exit(console.log('No filename provided for bets file, exiting...'));
  } else {
    var betsFileDoesntExist = true;
    try {
      betsFileDoesntExist = !fs.lstatSync(betsFile).isFile();
    } catch(e) {}
    if (betsFileDoesntExist) {
      process.exit(console.log('Invalid filename, exiting...'));
    }
  }

  try {
    bets = JSON.parse(fs.readFileSync(betsFile));
    bets.length.toString();
  } catch(e) {
    process.exit(console.log('Could not parse provided JSON file into an array, exiting...'));
  }

  exports.simulate(season, bets);
}