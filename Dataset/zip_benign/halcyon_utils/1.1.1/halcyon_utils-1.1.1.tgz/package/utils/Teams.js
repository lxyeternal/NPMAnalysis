function getTeamsFor(season) {
  return [
    {teamName: 'New Jersey Devils', teamNick: 'Devils', oddsID: 592, teamID: '1', teamShort: 'N.J', teamScoreboardShort: 'NJD'},
    {teamName: 'New York Islanders', teamNick: 'Islanders', oddsID: 594, teamID: '2', teamShort: 'NYI', teamScoreboardShort: 'NYI'},
    {teamName: 'New York Rangers', teamNick: 'Rangers', oddsID: 591, teamID: '3', teamShort: 'NYR', teamScoreboardShort: 'NYR'},
    {teamName: 'Philadelphia Flyers', teamNick: 'Flyers', oddsID: 590, teamID: '4', teamShort: 'PHI', teamScoreboardShort: 'PHI'},
    {teamName: 'Pittsburgh Penguins', teamNick: 'Penguins', oddsID: 593, teamID: '5', teamShort: 'PIT', teamScoreboardShort: 'PIT'},
    {teamName: 'Boston Bruins', teamNick: 'Bruins', oddsID: 581, teamID: '6', teamShort: 'BOS', teamScoreboardShort: 'BOS'},
    {teamName: 'Buffalo Sabres', teamNick: 'Sabres', oddsID: 583, teamID: '7', teamShort: 'BUF', teamScoreboardShort: 'BUF'},
    {teamName: 'Montreal Canadiens', teamNick: 'Canadiens', oddsID: 580, teamID: '8', teamShort: 'MTL', teamScoreboardShort: 'MTL'},
    {teamName: 'Ottawa Senators', teamNick: 'Senators', oddsID: 582, teamID: '9', teamShort: 'OTT', teamScoreboardShort: 'OTT'},
    {teamName: 'Toronto Maple Leafs', teamNick: 'Maple Leafs', oddsID: 584, teamID: '10', teamShort: 'TOR', teamScoreboardShort: 'TOR'},
    season < 20142015 ? {teamName: 'Phoenix Coyotes', teamNick: 'Coyotes', oddsID: 574, teamID: '53', altID: '27', teamShort: 'PHX', teamScoreboardShort: 'PHX'}
                      : {teamName: 'Arizona Coyotes', teamNick: 'Coyotes', oddsID: 574, teamID: '53', teamShort: 'ARI', teamScoreboardShort: 'ARI'},
    {teamName: 'Carolina Hurricanes', teamNick: 'Hurricanes', oddsID: 589, teamID: '12', teamShort: 'CAR', teamScoreboardShort: 'CAR'},
    {teamName: 'Florida Panthers', teamNick: 'Panthers', oddsID: 586, teamID: '13', teamShort: 'FLA', teamScoreboardShort: 'FLA'},
    {teamName: 'Tampa Bay Lightning', teamNick: 'Lightning', oddsID: 585, teamID: '14', teamShort: 'T.B', teamScoreboardShort: 'TBL'},
    {teamName: 'Washington Capitals', teamNick: 'Capitals', oddsID: 587, teamID: '15', teamShort: 'WSH', teamScoreboardShort: 'WSH'},
    {teamName: 'Chicago Blackhawks', teamNick: 'Blackhawks', oddsID: 565, teamID: '16', teamShort: 'CHI', teamScoreboardShort: 'CHI'},
    {teamName: 'Detroit Red Wings', teamNick: 'Red Wings', oddsID: 566, teamID: '17', teamShort: 'DET', teamScoreboardShort: 'DET'},
    {teamName: 'Nashville Predators', teamNick: 'Predators', oddsID: 569, teamID: '18', teamShort: 'NSH', teamScoreboardShort: 'NSH'},
    {teamName: 'St. Louis Blues', teamNick: 'Blues', oddsID: 567, teamID: '19', teamShort: 'STL', teamScoreboardShort: 'STL'},
    {teamName: 'Calgary Flames', teamNick: 'Flames', oddsID: 577, teamID: '20', teamShort: 'CGY', teamScoreboardShort: 'CGY'},
    {teamName: 'Colorado Avalanche', teamNick: 'Avalanche', oddsID: 575, teamID: '21', teamShort: 'COL', teamScoreboardShort: 'COL'},
    {teamName: 'Edmonton Oilers', teamNick: 'Oilers', oddsID: 579, teamID: '22', teamShort: 'EDM', teamScoreboardShort: 'EDM'},
    {teamName: 'Vancouver Canucks', teamNick: 'Canucks', oddsID: 578, teamID: '23', teamShort: 'VAN', teamScoreboardShort: 'VAN'},
    {teamName: 'Anaheim Ducks', teamNick: 'Ducks', oddsID: 572, teamID: '24', teamShort: 'ANA', teamScoreboardShort: 'ANA'},
    {teamName: 'Dallas Stars', teamNick: 'Stars', oddsID: 570, teamID: '25', teamShort: 'DAL', teamScoreboardShort: 'DAL'},
    {teamName: 'Los Angeles Kings', teamNick: 'Kings', oddsID: 573, altOddsID: 39437, teamID: '26', teamShort: 'L.A', teamScoreboardShort: 'LAK'},
    {teamName: 'Winnipeg Jets', teamNick: 'Jets', oddsID: 588, teamID: '52', teamShort: 'WPG', teamScoreboardShort: 'WPG'},
    {teamName: 'San Jose Sharks', teamNick: 'Sharks', oddsID: 571, teamID: '28', teamShort: 'S.J', teamScoreboardShort: 'SJS'},
    {teamName: 'Columbus Bluejackets', teamNick: 'Bluejackets', oddsID: 568, teamID: '29', teamShort: 'CBJ', teamScoreboardShort: 'CBJ'},
    {teamName: 'Minnesota Wild', teamNick: 'Wild', oddsID: 576, teamID: '30', teamShort: 'MIN', teamScoreboardShort: 'MIN'},
    {teamName: 'Atlanta Thrashers', teamNick: 'Thrashers', oddsID: 0, teamID: '11', teamShort: 'ATL', teamScoreboardShort: 'ATL'}
  ];
}

class Teams {
  constructor(season) {
    this.teams = getTeamsFor(season);
  }

  shortFromID(ID, opts) {
    var i = 0, len = this.teams.length;
    for (; i < len; i++) {
      if (this.teams[i].teamID == ID || (this.teams[i].altID && this.teams[i].altID == ID)) {
        return this.teams[i].teamShort;
      }
    }
    if (opts && opts.returnWhenTeamDoesntExist) return '';
    throw new Error("Couldn't find team with ID "+ID);
  }

  shortFromOddsID(ID, opts) {
    var i = 0, len = this.teams.length;
    for (; i < len; i++) {
      if (this.teams[i].oddsID == ID || (this.teams[i].altOddsID && this.teams[i].altOddsID == ID)) {
        return this.teams[i].teamShort;
      }
    }
    if (opts && opts.returnWhenTeamDoesntExist) return '';
    throw new Error("Couldn't find team with ID "+ID);
  }

  shortFromScoreboardShort(sh, opts) {
    var i = 0, len = this.teams.length;
    for (; i < len; i++) {
      if (this.teams[i].teamScoreboardShort == sh) {
        return this.teams[i].teamShort;
      }
    }
    if (opts && opts.returnWhenTeamDoesntExist) return '';
    throw new Error("Couldn't find team with scoreboardShort "+sh);
  }

  scoreboardShortFromShort(sh, opts) {
    var i = 0, len = this.teams.length;
    for (; i < len; i++) {
      if (this.teams[i].teamShort == sh) {
        return this.teams[i].teamScoreboardShort;
      }
    }
    if (opts && opts.returnWhenTeamDoesntExist) return '';
    throw new Error("Couldn't find team with short "+sh);
  }

  shortFromName(name, opts) {
    var i = 0, len = this.teams.length;
    for (; i < len; i++) {
      if (this.teams[i].teamName == name) {
        return this.teams[i].teamShort;
      }
    }
    if (opts && opts.returnWhenTeamDoesntExist) return '';
    throw new Error("Couldn't find team with name "+name);
  }
}

module.exports = Teams;