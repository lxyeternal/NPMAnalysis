const { head } = require("lodash");
(function(global) {
  'use strict';
  var M = function(el) {
    // this.el = typeof el === "string" ? document.querySelector(el) : el;
  };
  var UAC_URL = 'https://datacvg.datacvg.com';

  var options = {
    text: '', // 水印文本内容，支持通过\n进行换行文本的渲染
    container: '', // 水印挂载位置
    height: 60, // 水印块默认高度
    width: 190, // 水印块默认宽度
    opacity: 0.3, // 水印透明度
    size: 18, // 水印大小（时相对于默认文字大小增加的百分比），如果水印为图片就是水印相对于原图片的放大百分比
    type: 'TEXT', // 水印类型
    color: '#000000', // 水印颜色
    defaultFontSize: 14, // 文本类型注释的默认字体大小
    rotate: 30, // 水印偏转角度
    defaultLineSpace: 12, // 默认行间距
    showForThis: false, // 是否按照传入参数渲染
    defaultUseModel: 'DEFAULT', // 默认渲染的模块
    configUrl: '/api/portal/user/watermark', // 请求配置参数的url
    imgUrl: '/api/portal/user/readwatermark', // 请求配置的水印图片数据
    userInfoUrl: '/api/portal/user/info', // 请求用户信息url
    baseUrl: '', // 外部可以穿入baseUrl
    showModel: null, // 在什么状态下显示水印PC /  Mobile
    mobileImgLimitHeight: 300, // H5模式下图片的限制高度
    mobileImgLimitWidth: 300, // H5模式下图片的限制宽度
    backgroundPosition: '', //  H5模式下限定背景图的位置，防止虚拟键盘弹起引起页面挤压，水印显示位置异常
    showTime: false, // 是否显示当前时间
    userMesageShowKeyList: [], // 用户信息中显示要显示的字段
    waterTextSort: ['text', 'time'], // 默认的文字显示顺序（文本，用户信息，时间）， 用户信息的显示顺序以userMessageShowKeyList中的顺序为准，
    timeFormate: 'YYYY-MM-DD hh:mm:ss', // 时间渲染的文本格式，固定年为YYYY， 月为MM，日为DD， 时为hh, 分为mm, 秒为ss
    distanceBaseData: 200, // 间距默认基数
    lineDistance: 10, // 行间距
    // 设计两种模式，一种业务模式，针对业务场景进行处理
    // 一种通用模式，渲染参数需要外部传入，本组件只承担渲染操作
    wordMode: 'profession', // profession为业务模式，针对业务进行专门处理，渲染数据由内部接口获取； public为通用模式，渲染内容需要从外部传入；
  };

  // 获取带有透明度信息的颜色
  var getTrueColor = function(color, opacity) {
    if (opacity.toString().length === 1) {
      return color + '0' + opacity.toString();
    } else if (opacity && opacity.toString() !== '100') {
      return color + opacity;
    }
    return color;
  };
  /**
   * 将字符串按最大宽度截取成列表
   * @param text 原始字符串
   * @param maxWidth 最大宽度
   * @param context canvas实例
   * @returns {*[]} 返回截取后的列表
   */
  var getAutoWrapTextList = function(text, maxWidth, context) {
    let textList = [];
    let catchText = '';
    const splitTextList = text.split('');
    splitTextList.forEach(item => {
      const nowWidth = context.measureText((catchText + item));
      if (nowWidth > maxWidth) {
        textList.push(catchText);
        catchText = item;
      } else {
        catchText += item;
      }
    })
    textList.push(catchText);
    return textList;
  };
  String.prototype.colorRgb = function(){
    var sColor = this.toLowerCase();
    //十六进制颜色值的正则表达式
    var reg = /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/;
    // 如果是16进制颜色
    if (sColor && reg.test(sColor)) {
      if (sColor.length === 4) {
        var sColorNew = "#";
        for (var i=1; i<4; i+=1) {
          sColorNew += sColor.slice(i, i+1).concat(sColor.slice(i, i+1));
        }
        sColor = sColorNew;
      }
      //处理六位的颜色值
      var sColorChange = [];
      for (var i=1; i<7; i+=2) {
        sColorChange.push(parseInt("0x"+sColor.slice(i, i+2)));
      }
      return "RGB(" + sColorChange.join(",") + ")";
    }
    return sColor;
  };
  // H5渲染文字水印
  var renderTextWaterMarkH5 = function(opts) {
    // 设置H5画布大小与移动端屏幕相同
    const canvas = document.createElement('canvas');
    let _height = window.screen.height;
    let _width = window.screen.width;
    canvas.setAttribute('height', _height);
    canvas.setAttribute('width', _width);
    canvas.style.height = _height;
    canvas.style.width = _width;
    const ctx = canvas.getContext('2d');
    setTimeout(() => {
      // 计算出文字大小和行高
      let fontSize = 22;
      const lineHeight = fontSize + opts.lineDistance;
      ctx.font = `normal bold ${fontSize}px ${opts.font}`;
      // 文本内容按行拆分为列表
      let textList = opts.text.split('\n');
      // 计算当前状态下允许的最大宽度
      const firstWidth = ctx.measureText(textList[0]).width;
      const nowMaxWidth = Math.ceil((2 * _width - (lineHeight * opts.text.split('\n').length)) / 1.73);
      // 判断当前第一行是否过长需要换行展示
      if (firstWidth > nowMaxWidth) {
        // 如果是用户名并且勾选了账号拼接过长就讲用户名账号换行显示
        if (opts.type === 'NAME' && opts.userMesageShowKeyList.indexOf('user_id') > -1) {
          let nameIDList = textList[0].split('-');
          textList.splice(0,1,...nameIDList);
        } else {
          // 如果是文本过长就按照所能允许的最大长度截断换行展示
          const newList = getAutoWrapTextList(textList[0], nowMaxWidth, ctx);
          textList.splice(0, 1, ...newList);
        }
      }

      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      // ctx.strokeStyle = getTrueColor(opts.color, opts.opacity);
      let colorRGB = opts.color.colorRgb()
      ctx.strokeStyle = colorRGB.replace(')', `,${opts.opacity/100})`);

      ctx.translate(Math.ceil( _width / 2), Math.ceil(_height / 2));
      // ctx.strokeRect(0, 0, _width, _height);
      // ctx.lineWidth = 0.5;
      ctx.rotate((-parseFloat(opts.rotate) * Math.PI) / 180);
      textList.forEach((item, index) => {
        const textWidth = ctx.measureText(item);
        ctx.strokeText(item, 5,  index * lineHeight - (textList.length*lineHeight/2))
      })

      renderToContainier(canvas, opts.container);
    }, 300);

  }
  // 渲染文字类型的水印
  var renderTextWaterMark = function(opts) {
    // 获取实际显示倍率
    const canvasTest = document.createElement('canvas');
    const ctxTest = canvasTest.getContext('2d');
    // 计算出渲染文字大小
    let fontSize = (opts.defaultFontSize * opts.size) / 100;
    let realFontSize = Math.floor(fontSize);
    // 行高 = 文字大小 + 间距
    let lineHeight = realFontSize + opts.lineDistance;
    ctxTest.font = `normal ${realFontSize}px ${opts.font}`;
    // 获取要渲染的文本内容
    const textList = opts.text.split('\n');
    // 获取内容最大宽度
    var widthList = [];
    const lines = textList.length;
    for(var i = 0; i < lines; i++) {
      widthList.push(ctxTest.measureText(textList[i]).width)
    }
    const maxWidth = Math.max(...widthList);

    // 实际文字所占的宽高
    const textHeight = lineHeight * lines;
    const textWidth = maxWidth;

    // 文字倾斜后所占宽高
    const realHeight = textHeight * 1.73 / 2 + maxWidth / 2 ;
    const realWidth = textWidth * 1.73 / 2 + realHeight / 2;

    // 计算间距大小
    const distanceTop = opts.distanceBaseData * parseFloat(opts.spacing) / 100;
    const distanceLeft = opts.distanceBaseData * parseFloat(opts.spacing) / 100;
    // 画布宽高
    const renderWidth = distanceLeft + realWidth;
    const renderHeight = distanceTop + realHeight;

    const canvas = document.createElement('canvas');
    // 设置画布大小
    canvas.setAttribute('width', renderWidth );
    canvas.setAttribute('height', renderHeight);
    canvas.style.width = renderWidth;
    canvas.style.height = renderHeight;
    const ctx = canvas.getContext('2d');
    // 画布边界，测试用
    // ctx.strokeRect(0, 0, renderWidth, renderHeight);

    setTimeout(() => {
      // 设置渲染样式
      ctx.font = `normal ${realFontSize}px ${opts.font}`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      ctx.fillStyle = getTrueColor(opts.color, opts.opacity);
      ctx.translate( renderWidth / 2, (renderHeight - textHeight) / 2 );
      ctx.rotate((-parseFloat(opts.rotate) * Math.PI) / 180);
      // 逐行渲染文字
      textList.forEach((item, index) => {
        ctx.fillText(item, 0, index * lineHeight);
      })
      renderToContainier(canvas, opts.container);
    }, 300)
  };

  //
  var renderImgWaterMarkCenterH5 = function(img, opts) {
    const canvas = document.createElement('canvas');
    canvas.setAttribute('height', document.body.clientHeight);
    canvas.setAttribute('width', document.body.clientWidth);
    const _width = img.width;
    const _height = img.height;
    let aa = 1;
    let realHeight,realWidth;
    if (img.width >= img.height) {
      aa = opts.mobileImgLimitWidth / img.width;
      realWidth = opts.mobileImgLimitWidth;
      realHeight = img.height * aa
    } else {
      aa = opts.mobileImgLimitHeight / img.height
      realWidth = img.width * aa;
      realHeight = opts.mobileImgLimitHeight
    }
    const ctx = canvas.getContext('2d');
    ctx.translate((document.body.clientWidth - realWidth) / 2, (document.body.clientHeight - realHeight) / 2);
    ctx.globalAlpha = opts.opacity / 100;
    ctx.fillStyle = opts.color + opts.opacity,
        ctx.drawImage(img, 0, 0, _width, _height, 0, 0, realWidth, realHeight);
    renderToContainier(canvas, opts.container);
  }

  // 图片渲染
  var renderImgWaterMarkCenter = function(img, opts) {
    const canvas = document.createElement('canvas');
    // 渲染要放在onload里面，防止drawImage不生效
    const _width = img.width;
    const _height = img.height;
    const aa = img.width / opts.width;
    const realWidth = (opts.width * parseFloat(opts.size)) / 100;
    const realHeight = ((img.height / aa) * parseFloat(opts.size)) / 100;
    const canvasWidth =
        realWidth * 1.4 + (realWidth * parseFloat(opts.spacing)) / 100;
    const canvasHeight =
        realHeight * 2.1 + (realHeight * parseFloat(opts.spacing)) / 100;
    canvas.setAttribute('height', canvasHeight);
    canvas.setAttribute('width', canvasWidth);
    const ctx = canvas.getContext('2d');
    ctx.rotate((-opts.rotate * Math.PI) / 180);
    ctx.translate(0 - realHeight / 3, realWidth / 2 + realHeight / 7);
    ctx.globalAlpha = opts.opacity / 100;
    ctx.fillStyle = opts.color + opts.opacity,
        ctx.drawImage(img, 0, 0, _width, _height, 0, 0, realWidth, realHeight);
    renderToContainier(canvas, opts.container);
  }

  var renderImgWaterMark = function(opts) {
    // 如果没有图片名称则证明没有保存图片，不显示
    if (!opts.imgpath) {
      return false;
    }
    var img = new Image();
    // 如果外部传入了imgpath，则不请求接口直接加载
    if (opts && opts.showImgpath) {
      img.onload = () => {
        opts.showModel === 'Mobile' ? renderImgWaterMarkCenterH5(img, opts) : renderImgWaterMarkCenter(img, opts);
      }
      img.src = opts.showImgpath;
    } else {
      getConfigImgData(src => {
        img.onload = () => {
          opts.showModel === 'Mobile' ? renderImgWaterMarkCenterH5(img, opts) : renderImgWaterMarkCenter(img, opts);
        };
        img.src = src;
      });
    }
  };
  // 根据配置处理要渲染的文本数据
  /**
   *
   * @param {配置数据} opts
   * @param {用户数据} userData
   * @param {userMessageShowKeyList中不参与显示的字段（由于user_id会和用户名拼接显示，这里不会单独另起一行显示）} hideKey
   * @returns
   */
  var getRenderText = function(opts, userData, hideKey) {
    let textList = [];
    opts.text && textList.push(opts.text);
    const userMesageShowKeyList = opts.userMesageShowKeyList;
    for (let i = 0; i < userMesageShowKeyList.length; i++) {
      if (userMesageShowKeyList[i] !== hideKey) {
        let key = userMesageShowKeyList[i];
        let data = userData[key];
        if (data && data.trim().length > 0) {
          textList.push(data);
        }
      }
    }
    opts.showTime && textList.push(getNowTimeText());
    return textList.join('\n');
  }

  // 根据不同水印类型做处理
  var createWaterMarkElement = function(opts) {
    if (opts.type === 'IMAGE') {
      renderImgWaterMark(opts);
    } else {
      const timeText = getNowTimeText()
      if (opts.type === 'NAME' && !opts.showForThis) {
        getUserInfo(userInfo => {
          // 当为用户名类型水印并且勾选了账号后，账号-用户名在一行显示；手机号，时间另起一行显示
          if (opts.userMesageShowKeyList.indexOf('user_id') > -1) {
            opts.text = userInfo.user_id + '-' + userInfo.user_clname;
          } else {
            opts.text = userInfo.user_clname;
          }
          opts.text = getRenderText(opts, userInfo, 'user_id');
          opts.showModel === 'Mobile' ? renderTextWaterMarkH5(opts) : renderTextWaterMark(opts);
        });
      } else if (opts.type === 'ACCOUNTNAME' && !opts.showForThis) {
        getUserInfo(userInfo => {
          opts.text = userInfo.user_id + '-' + userInfo.user_clname;
          opts.showModel === 'Mobile' ? renderTextWaterMarkH5(opts) : renderTextWaterMark(opts);
        });
      } else {
        opts.text = opts.showTime ? (opts.text + '\n' + timeText) : opts.text;
        opts.showModel === 'Mobile' ? renderTextWaterMarkH5(opts) : renderTextWaterMark(opts);
      }
    }
  };
  // 通用模式渲染水印，只支持图片水印和文本水印
  var createPublicWaterMarkElement = function() {
    if (opts.type === 'IMAGE') {
      renderImgWaterMark(opts);
    } else {
      opts.text = opts.showTime ? (opts.text + '\n' + getNowTimeText()) : opts.text;
      renderTextWaterMark(opts);
    }
  }
  /**
   * 获取url中的参数
   */
  var getUrlParams = function() {
    var url = window.location.href;
    var params = {};
    var keyValueStrList = [];
    if (url.indexOf('?') > -1) {
      keyValueStrList = url.split('?')[1].split('&');
    }
    for(var i = 0; i < keyValueStrList.length; i++) {
      var key = keyValueStrList[i].split('=')[0];
      var value = keyValueStrList[i].split('=')[1];
      params[key] = value;
    }
    return params;
  }
  /**
   * 获取cookie中的token值
   * @returns {string}
   */
  var getCookie = function(otherType) {
    // 判断当前是移动端还是PC端
    const type = otherType || detectDeviceType();
    const cname = type === 'Mobile' ? 'userToken' : 'dap_app_UACTOKEN';
    const headerKey = type === 'Mobile' ? 'token ' : 'ticket ';
    var name = cname + '=';
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
      var c = ca[i].trim();
      if (c.indexOf(name) == 0) {
        return headerKey + c.substring(name.length, c.length);
      }
    }
    // 如果token是通过url中携带的，则从url中获取token值
    const params = getUrlParams();
    const TOKEN = 'semf_token';
    const TICKET = 'semf_ticket';
    if (params[TOKEN] || params[TICKET]) {
      if (params[TOKEN]) {
        return 'dap_app_UACTOKEN' + '=' + params[TOKEN];
      }
      if (params[TICKET]) {
        return 'dap_app_UACTOKEN' + '=' + params[TICKET];
      }
    }
    return '';
  };

  // 获取配置数据
  var getConfigData = function(callback) {
    const token = getCookie();
    fetch(options.baseUrl + options.configUrl, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json;charset=utf-8',
        Authorization: token ? token : getCookie('Desktop')
      }
    })
        .then(response => response.json())
        .then(res => {
          // options = Object.assign(options, res.data);
          if (res.success) {
            callback(res.data);
          }
        })
  };
  // 获取配置图片数据
  var getConfigImgData = function(callback) {
    const token = getCookie();
    fetch(options.baseUrl + options.imgUrl, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json;charset=utf-8',
        Authorization: token ? token : getCookie('Desktop')
      }
    })
        .then(response => response.json())
        .then(res => {
          if (res.success) {
            callback('data:image/png;base64,' + res.data);
          }
        })
  };
  // 获取用户信息
  var getUserInfo = function(callback) {
    const token = getCookie();
    fetch(options.baseUrl + options.userInfoUrl, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json;charset=utf-8',
        connection: 'keep-alive',
        Accept: 'application/json, text/plain, */*',
        Authorization: token ? token : getCookie('Desktop')
      }
    })
        .then(response => response.json())
        .then(res => {
          if (res.success) {
            callback(res.data);
          }
        });
  };
  /**
   * 水印item的实际高度
   * @param h 默认高度
   * @param w 默认宽度
   * @param text 水印文本
   * @param size 水印放大大小
   * @param spacing 水印间距
   * @param lineHeight 文字行高
   * @returns {number} 水印的实际高度
   */
  var canvasHeight = function(h, w, text, size, spacing, lineHeight) {
    const textWidth = text.length * size;
    const lines = Math.ceil(textWidth / parseFloat(w));
    const realHeight =
        parseFloat((lines * lineHeight * (100 + parseFloat(spacing))) / 100) +
        parseFloat(h);
    return realHeight;
  };
  /**
   * 判断当前是移动端还是PC端
   */
  var detectDeviceType = function() {
    const machineType = /Android webOS|Android|Mobi|micromessenger|MicroMessenger|dingtalk|DingTalk|wxwork|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
        navigator.userAgent
    )
        ? 'Mobile'
        : 'Desktop';
    return machineType;
  };

  /**
   * 渲染水印到指定元素
   * @param canvas
   * @param container
   */
  var renderToContainier = function(canvas, container) {
    const __wm = document.querySelector('.__wm');
    __wm && document.querySelector('.__wm').remove();
    const base64Url = canvas.toDataURL();
    const waterMarkDiv = document.createElement('div');
    let styleStr = `
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      width: 100%;
      height: 100%;
      z-index: 10000;
      pointer-events: none;
      background-repeat: repeat;
      background-image: url('${base64Url}');
      background-position: ${options.backgroundPosition};
    `;
    // H5图片水印通过旋转蒙版div实现图片倾斜
    if (options.showModel === 'Mobile' && options.type === 'IMAGE') {
      styleStr += 'transform: rotate(315deg)';
    }
    waterMarkDiv.setAttribute('style', styleStr);
    waterMarkDiv.classList.add('__wm');
    if (container) {
      container.append(waterMarkDiv);
    } else {
      document.body.append(waterMarkDiv);
    }
  };
  var initWaterMark = function(type) {
    console.log('1.7.8')
    const timeText = getNowTimeText();
    var showUserModel = [options.defaultUseModel];
    if (options.useModel) {
      const useModel = options.useModel.split(',');
      showUserModel = [...showUserModel, ...useModel];
    }
    if (showUserModel.indexOf(type) === -1) {
      return false;
    }
    // SCREEN 大屏,EXECUTIVE 领导视窗,REPORTS 主题报表,KANPAN 数字神经,ANALYTICS 管理画布
    console.log(window.location.href);
    if (window.parent && window.parent.location && window.parent.location.pathname) {
      if (type === 'ANALYTICS') {
        // 主题报表或大屏会嵌管理画布，如果父iframe有水印，不再添加水印
        if (showUserModel.indexOf('REPORTS') > -1 && window.parent.location.pathname.indexOf('reportapp') > -1) return;
        if (showUserModel.indexOf('SCREEN') > -1  && window.parent.location.pathname.indexOf('screen') > -1) return;
        // 如果是在H5中打开主题报表就不再主题报表中展示水印
        if (window.location.href.indexOf('mobile') > -1) return;
      }
      if (type === 'REPORTS') {
        // 管理画布或大屏会嵌主题报表，如果父iframe有水印，不再添加水印
        if (showUserModel.indexOf('SCREEN') > -1 && window.parent.location.pathname.indexOf('screen') > -1) return;
        if (showUserModel.indexOf('ANALYTICS') > -1 && window.parent.location.pathname.indexOf('dataexporler') > -1) return;
        if (window.location.href.indexOf('mobile') > -1) return;
      }
    }
    // 如果不为T,就不会渲染水印
    if (options && options.switchd === 'T') {
      createWaterMarkElement(options);
    }
  }

  /*工具方法*/
  // 获取当前时间字符串
  var getNowTimeText = function() {
    const nowDate = new Date();
    const year = nowDate.getFullYear();
    const month = nowDate.getMonth() + 1;
    const day = nowDate.getDate();
    const hour = nowDate.getHours();
    const minute = nowDate.getMinutes();
    const second = nowDate.getSeconds();
    let nowTimeText = options.timeFormate;
    nowTimeText = nowTimeText.replace(/YYYY/, year)
    nowTimeText = nowTimeText.replace(/MM/, month < 10 ? ('0' + month) : month)
    nowTimeText = nowTimeText.replace(/DD/, day < 10 ? ('0' + day) : day)
    nowTimeText = nowTimeText.replace(/hh/, hour < 10 ? ('0' + hour) : hour)
    nowTimeText = nowTimeText.replace(/mm/, minute < 10 ? ('0' + minute) : minute)
    nowTimeText = nowTimeText.replace(/ss/, second < 10 ? ('0' + second) : second)
    return nowTimeText;
  }

  M.prototype = {
    setBg: function(bg) {
      this.el.style.background = bg;
    },
    init: async function(type, opts) {
      const __wm = document.querySelector('.__wm');
      __wm && document.querySelector('.__wm').remove();
      options = Object.assign(options, opts);

      // 判断当前插件的工作模式
      if (options.wordMode === 'public') {
        // 通用模式
        createPublicWaterMarkElement(options)
      } else {
        // 业务模式
        // 移动端不显示水印
        const openType = detectDeviceType();
        options.showModel = openType;
        // options.showModel = 'Mobile'
        if (openType === 'Mobile') {
          // 如果是移动端就只显示一个水印
          options.width = document.body.clientWidth;
          options.height = document.body.clientHeight;
          options.mobileImgLimitHeight = Math.min(options.height, options.mobileImgLimitHeight);
          options.mobileImgLimitWidth = Math.min(options.width, options.mobileImgLimitWidth);
          options.backgroundPosition = 'center';
        } else {
          options.backgroundPosition = '';
        }
        // opts的优先级最高
        // 如果不存在opts就取getConfigData
        // 如果getConfigData获取失败就取默认的options
        if (opts && opts.showForThis) {
          options = Object.assign(options, opts);
          // 接口返回的数据不是boolean而是字符串，这里把他转化为boolean
          if (typeof options.showTime === 'string') {
            options.showTime = (options.showTime === 'true');
          }
          initWaterMark(type);
        } else {
          setTimeout(() => {
            getConfigData(apiConfig => {
              if (apiConfig) {
                options = Object.assign(options, apiConfig);
              }
              if (opts) {
                options = Object.assign(options, opts);
              }
              if (options.additionalContent) {
                options.userMesageShowKeyList = options.additionalContent.split(',');
              }
              // 接口返回的数据不是boolean而是字符串，这里把他转化为boolean
              if (typeof options.showTime === 'string') {
                options.showTime = (options.showTime === 'true');
              }
              initWaterMark(type);
            });
          },options.timeoutDelay || 0);
        }
      }
      return options;
    }
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = M;
  if (typeof define === 'function')
    define(function() {
      return M;
    });
  global.ModifyDivBg = M;
})(this);
