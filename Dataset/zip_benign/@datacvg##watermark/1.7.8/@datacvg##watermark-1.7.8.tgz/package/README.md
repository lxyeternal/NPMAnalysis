# waterMark
水印插件

默认情况下会通过请求接口回去水印配置参数  
如果接口请求失败就取默认参数  
如果外部传入参数则外部参数优先级最高
| 配置key | 默认参数 | 参数类型 | 说明 |  
| ---- | ---- | ---- | ---- | ---- |
| container | body | 元素dom | 水印渲染的父元素 | 
| text | '' | string | 水印文本渲染内容，仅当type为TEXT时支持外部传入，直播hi通过\n进行换行显示 |
| height | 60 | number | 水印块默认高度 |
| width | 190 | number | 水印块默认宽度 | 
| opacity | 0.3 | number | 水印透明度 | 
| size | 18 | number | 水印大小（非图片水印为相对于默认文字增加的百分比， 图片水印为相对于原图片放大的百分比） | 
| type | 'TEXT' | string | 水印类型，目前支持TEXT, NAME, IMAGE |
| color | '#000000' | string | 水印颜色 | 
| defaultFontSize | 14 | number | 文本类水印默认文字大小 |
| rotate | 30 | number | 水印旋转角度（逆时针） |
| defaultLineSpace | 12 | number | 默认行间距 | 
| showForThis | false | boolean | 是否按照外部传入的参数渲染，不再走内部配置请求接口； false会忽略外部传入参数，true会不再请求接口配置参数； 默认为false |
| defaultUseModel | 'DEFAULT' | string | 默认渲染的模块，如果想要渲染水印，传入的渲染模块至少为'DEFAULT' | 
| configUrl | '/api/protal/user/watermark' | string | 请求配置参数的Url, 支持外部传入自定义接口 | 
| imgUrl | '/api/protal/user/readwatermark' | string | 请求水印如片数据Url | 
| userInfoUrl | 'api/protal/user/readwatermark' | string | 请求用户信息Url | 
| baseUrl | '' | string | 可外部传入baseUrl，不传入则为当前环境的baseUrl |
| showModel | null | string, null | 要显示水印的平台，是PC还是Mobile | 
| mobileImgLimitHeight | 300 | number | h5模式下图片的限制高度 | 
| mobileImgLimitWidth | 300 | number | H5模式下图片的限制宽度 |
| showTime | false | boolean | 是否显示时间 |
| userMesageShowKeyList | [] | array | 用户信息中要显示的字段 | 
| timeFormate | YYYY-MM-DD hh:mm:ss | string | 时间显示的格式 |


---

## 组件目标功能
- [x] 支持文本水印显示
- [x] 支持图片水印显示
- [x] 能够根据外部传入数据渲染水印
- [x] 能够通过内置接口获取水印数据  

---

# 更细日志
## v1.5.0
  1. 水印类型修改为 **TEXT** ， **NAME** ， **IMAGE** 三种，保留对原**ACCOUNTNAME** 类型水印的兼容。
     1. 增加显示当前时间的功能，通过参数**showTime**控制开关， 默认会显示**YYYY-MM-DD hh:mm:ss**格式类型的当前时间字符串；用户可以通过传入参数timeFormate来对显示的时间格式进行自定义，但是要注意年、月、日、时、分、秒分别有YYYY、MM、DD、hh、mm、ss表示不能修改，用户只能决定是否显示以及如何排列和如何链接。
  > eg: YYYY===MM===DD   对应的显示效果就是2022===08===26

  3. 增加文字换行显示功能，用户可以通过传入文字中加入 <span style="color: blue">\n</span> 来换行显示
## v1.5.1   
    增加对于移动端浏览器，钉钉，企业微信，微信的判断，修复在移动端打开H5水印显示效果异常
## v1.5.2
    兼容老数据
## v1.5.3
    修复H5水印当虚拟键盘升起改变页面大小时，水印位置显示异常
## v1.5.4
    修复改变H5水印背景位置的逻辑
## v1.5.5
    修复当配置的显示项为空时会显示空白行；时间增加补0
## v1.5.6
    时间补0不生效修复
## v1.5.7
    修复由于接口返回的时间开关为true，false字符串造成一直判断为true
## v1.5.8
    调整H5水印为子大小为28px
## v1.5.9
    H5水印改为空心字
## v1.6.0
    H5空心文字在移动端显示模糊修复
## v1.6.1
    修改H5文字类水印展示方式
## v1.6.2
    修复白色水印字体遮挡内容的问题
## v1.6.3
    修复水印显示问题;修复代码报错造成水印不显示问题;
## v1.6.4
    传入的showTime兼容string，boolean类型
## v1.6.5
    优化H5端文字水印显示效果
## v1.6.6
    测试修复在H5上主题报表打开后显示双重水印
## v1.6.7
    修改水印容器宽度
## v1.6.9
    修改H5，PC文字水印渲染方式。增加睡衣配置返回数据
## v1.7.0
    H5文字水印颜色修改为rgb格式，修复在企业微信中颜色设置不生效问题
## v1.7.1
    修复当在钉钉电脑端打开时会识别为移动端，导致token获取不到
## v1.7.8
    顾家优化报表打开速度，给水印添加延时配置timeoutDelay，不传默认0不延时
