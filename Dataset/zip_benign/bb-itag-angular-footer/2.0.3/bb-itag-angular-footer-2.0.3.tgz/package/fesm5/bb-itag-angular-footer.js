import { __decorate } from 'tslib';
import { EventEmitter, Input, Output, Component, NgModule } from '@angular/core';
import { faNetworkWired, faExclamationTriangle } from '@fortawesome/free-solid-svg-icons';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

var BbItagAngularFooterComponent = /** @class */ (function () {
    function BbItagAngularFooterComponent() {
        // declare all the defaults
        this.internalFooterConfiguration = {
            appVersion: null,
            onlineThemePalette: 'primary',
            offlineThemePalette: 'warn',
            onlineFaIconDefinition: faNetworkWired,
            offlineFaIconDefinition: faExclamationTriangle,
            onlineText: 'ONLINE',
            offlineText: 'OFFLINE',
            showPointer: true,
            versionRouterLink: null,
            versionRouterLinkClass: 'defaultVersion'
        };
        this.appVersionClicked = new EventEmitter();
        this.isInternalOnline = true;
        this.statusText = this.internalFooterConfiguration.onlineText;
        this.statusIcon = this.internalFooterConfiguration.onlineFaIconDefinition;
        this.backgroundTheme = this.internalFooterConfiguration.onlineThemePalette;
        this.updateStatus();
    }
    Object.defineProperty(BbItagAngularFooterComponent.prototype, "appVersion", {
        set: function (value) {
            this.internalFooterConfiguration.appVersion = value;
            this.updateStatus();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BbItagAngularFooterComponent.prototype, "showPointer", {
        set: function (value) {
            this.internalFooterConfiguration.showPointer = value;
            this.updateStatus();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BbItagAngularFooterComponent.prototype, "onlineThemePalette", {
        set: function (value) {
            this.internalFooterConfiguration.onlineThemePalette = value;
            this.updateStatus();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BbItagAngularFooterComponent.prototype, "offlineThemePalette", {
        set: function (value) {
            this.internalFooterConfiguration.offlineThemePalette = value;
            this.updateStatus();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BbItagAngularFooterComponent.prototype, "onlineFaIconDefinition", {
        set: function (value) {
            this.internalFooterConfiguration.onlineFaIconDefinition = value;
            this.updateStatus();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BbItagAngularFooterComponent.prototype, "offlineFaIconDefinition", {
        set: function (value) {
            this.internalFooterConfiguration.offlineFaIconDefinition = value;
            this.updateStatus();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BbItagAngularFooterComponent.prototype, "onlineText", {
        set: function (value) {
            this.internalFooterConfiguration.onlineText = value;
            this.updateStatus();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BbItagAngularFooterComponent.prototype, "offlineText", {
        set: function (value) {
            this.internalFooterConfiguration.offlineText = value;
            this.updateStatus();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BbItagAngularFooterComponent.prototype, "versionRouterLink", {
        set: function (value) {
            this.internalFooterConfiguration.versionRouterLink = value;
            this.updateStatus();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BbItagAngularFooterComponent.prototype, "versionRouterLinkClass", {
        set: function (value) {
            this.internalFooterConfiguration.versionRouterLinkClass = value;
            this.updateStatus();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BbItagAngularFooterComponent.prototype, "online", {
        set: function (online) {
            if (online === null) {
                // if we get a null as value, we using the default value true
                online = true;
            }
            this.isInternalOnline = online;
            this.updateStatus();
        },
        enumerable: true,
        configurable: true
    });
    BbItagAngularFooterComponent.prototype.updateStatus = function () {
        if (this.isInternalOnline) {
            this.statusText = this.internalFooterConfiguration.onlineText;
            this.statusIcon = this.internalFooterConfiguration.onlineFaIconDefinition;
            this.backgroundTheme = this.internalFooterConfiguration.onlineThemePalette;
        }
        else {
            this.statusText = this.internalFooterConfiguration.offlineText;
            this.statusIcon = this.internalFooterConfiguration.offlineFaIconDefinition;
            this.backgroundTheme = this.internalFooterConfiguration.offlineThemePalette;
        }
    };
    BbItagAngularFooterComponent.prototype.onAppVersionClick = function () {
        if (this.internalFooterConfiguration.showPointer) {
            this.appVersionClicked.emit(this.internalFooterConfiguration.appVersion);
        }
    };
    __decorate([
        Input()
    ], BbItagAngularFooterComponent.prototype, "appVersion", null);
    __decorate([
        Input()
    ], BbItagAngularFooterComponent.prototype, "showPointer", null);
    __decorate([
        Input()
    ], BbItagAngularFooterComponent.prototype, "onlineThemePalette", null);
    __decorate([
        Input()
    ], BbItagAngularFooterComponent.prototype, "offlineThemePalette", null);
    __decorate([
        Input()
    ], BbItagAngularFooterComponent.prototype, "onlineFaIconDefinition", null);
    __decorate([
        Input()
    ], BbItagAngularFooterComponent.prototype, "offlineFaIconDefinition", null);
    __decorate([
        Input()
    ], BbItagAngularFooterComponent.prototype, "onlineText", null);
    __decorate([
        Input()
    ], BbItagAngularFooterComponent.prototype, "offlineText", null);
    __decorate([
        Input()
    ], BbItagAngularFooterComponent.prototype, "versionRouterLink", null);
    __decorate([
        Input()
    ], BbItagAngularFooterComponent.prototype, "versionRouterLinkClass", null);
    __decorate([
        Output()
    ], BbItagAngularFooterComponent.prototype, "appVersionClicked", void 0);
    __decorate([
        Input()
    ], BbItagAngularFooterComponent.prototype, "online", null);
    BbItagAngularFooterComponent = __decorate([
        Component({
            selector: 'lib-bb-itag-angular-footer',
            template: "<mat-toolbar [color]=\"backgroundTheme\" class=\"version-wrapper footer\">\n\n  <span class=\"version\"\n        [ngClass]=\"{'show-pointer': internalFooterConfiguration.showPointer, 'show-default': !internalFooterConfiguration.showPointer }\"\n        *ngIf=\"internalFooterConfiguration && internalFooterConfiguration.appVersion && internalFooterConfiguration.versionRouterLink\"\n        [routerLink]=\"internalFooterConfiguration.versionRouterLink\"\n        [routerLinkActive]=\"internalFooterConfiguration.versionRouterLinkClass\"\n        (click)=\"onAppVersionClick()\">\n        {{ internalFooterConfiguration.appVersion }}\n  </span>\n\n  <span class=\"version\"\n        [ngClass]=\"{'show-pointer': internalFooterConfiguration.showPointer, 'show-default': !internalFooterConfiguration.showPointer }\"\n        *ngIf=\"internalFooterConfiguration && internalFooterConfiguration.appVersion && !internalFooterConfiguration.versionRouterLink\"\n        (click)=\"onAppVersionClick()\">\n        {{ internalFooterConfiguration.appVersion }}\n  </span>\n\n  <span class=\"version-spacer\"></span>\n\n  <span class=\"show-default\" *ngIf=\"statusText\">{{statusText}}&nbsp;</span>\n  <fa-icon *ngIf=\"statusIcon\" [icon]=\"statusIcon\"></fa-icon>\n\n</mat-toolbar>\n\n",
            styles: [".version-wrapper{width:100%;height:25px;display:-webkit-box;display:flex;-webkit-box-align:center;align-items:center;font-size:smaller}.version{margin-left:auto;margin-right:20px}.show-default{cursor:default}.show-pointer{cursor:pointer}.version-spacer{-webkit-box-flex:1;flex:1 1 auto}.defaultVersion{color:red}.footer{overflow:hidden;position:absolute;left:0;right:0;height:25px;bottom:0}"]
        })
    ], BbItagAngularFooterComponent);
    return BbItagAngularFooterComponent;
}());

var BbItagAngularFooterModule = /** @class */ (function () {
    function BbItagAngularFooterModule() {
    }
    BbItagAngularFooterModule = __decorate([
        NgModule({
            declarations: [BbItagAngularFooterComponent],
            imports: [
                CommonModule,
                RouterModule,
                FontAwesomeModule,
                MatToolbarModule,
            ],
            exports: [BbItagAngularFooterComponent]
        })
    ], BbItagAngularFooterModule);
    return BbItagAngularFooterModule;
}());

/*
 * Public API Surface of bb-itag-angular-footer
 */

/**
 * Generated bundle index. Do not edit.
 */

export { BbItagAngularFooterComponent, BbItagAngularFooterModule };
//# sourceMappingURL=bb-itag-angular-footer.js.map
