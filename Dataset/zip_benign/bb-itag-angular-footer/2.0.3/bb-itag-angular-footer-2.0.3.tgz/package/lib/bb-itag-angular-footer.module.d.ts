export declare class BbItagAngularFooterModule {
}
