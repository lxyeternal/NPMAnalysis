import { EventEmitter } from '@angular/core';
import { ThemePalette } from '@angular/material/core';
import { IFooterConfiguration } from './models/IFooterConfiguration';
export declare class BbItagAngularFooterComponent {
    internalFooterConfiguration: IFooterConfiguration;
    set appVersion(value: string);
    set showPointer(value: boolean);
    set onlineThemePalette(value: ThemePalette);
    set offlineThemePalette(value: ThemePalette);
    set onlineFaIconDefinition(value: any);
    set offlineFaIconDefinition(value: any);
    set onlineText(value: string);
    set offlineText(value: string);
    set versionRouterLink(value: string);
    set versionRouterLinkClass(value: string);
    appVersionClicked: EventEmitter<string>;
    set online(online: boolean);
    constructor();
    isInternalOnline: boolean;
    statusText: string;
    statusIcon: any;
    backgroundTheme: ThemePalette;
    private updateStatus;
    onAppVersionClick(): void;
}
