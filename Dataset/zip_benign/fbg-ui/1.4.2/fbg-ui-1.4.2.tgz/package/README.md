# fbg-ui

## install 
```bash
npm install fbg-ui
```

## use 
```javascript
// main.js
import Vue from 'vue';
import FBGUI from 'fbg-ui';

Vue.use(FBGUI);
```

## use theme
```
// vue.config.js
css: {
    loaderOptions: {
        sass: {
            prependData: `@import "@/styles/global.scss";`
        }
    }
}
// global.scss
$themeColor : #5a76e4;  // 主题颜色
$themeShadowColor : rgba(90,118,228, 0.3); // 主题阴影
$activeThemeColor: #516ace;   // 主题激活色
$themeDimColor: rgba(90,118,228, 0.1);  //  主题悬浮色
$hoverBackgroundColor : #F5F6F7; // 普通悬浮背景色
```

