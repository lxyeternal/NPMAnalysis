'use strict';
const path = require('path');

function resolve(dir) {
    return path.join(__dirname, dir);
}

const name = 'FBG-UI'; // page title


// All configuration item explanations can be find in https://cli.vuejs.org/config/
module.exports = {
    /**
     * You will need to set publicPath if you plan to deploy your site under a sub path,
     * for example GitHub Pages. If you plan to deploy your site to https://foo.github.io/bar/,
     * then publicPath should be set to "/bar/".
     * In most cases please use '/' !!!
     * Detail: https://cli.vuejs.org/config/#publicpath
     */
    pages: {
        index: {
            // page 的入口
            entry: 'src/example/main.js',
            title: 'FBG-UI 框架'
        }
    },
    publicPath: './',
    outputDir: 'dist',
    assetsDir: 'static',
    productionSourceMap: false,
    css: {
        loaderOptions: {
            sass: {
                prependData: `@import "~@/demo/styles/global.scss";`
            }
        }
    },
    configureWebpack: {
        // provide the app's title in webpack's name field, so that
        // it can be accessed in index.html to inject the correct title.
        name: name,
        resolve: {
            alias: {
                '@': resolve('src/example'),
                '~@': resolve('src')
            }
        }
    },
    chainWebpack(config) {

        // set preserveWhitespace
        config.module
            .rule('vue')
            .use('vue-loader')
            .loader('vue-loader')
            .tap(options => {
                options.compilerOptions.preserveWhitespace = true;
                return options;
            })
            .end();
        config
            .when(process.env.NODE_ENV !== 'development',
                config => {
                    // config
                    // // 打包文件报表
                    //   .plugin('webpack-bundle-analyzer')
                    //   .use(require('webpack-bundle-analyzer').BundleAnalyzerPlugin);

                    config
                        .plugin('ScriptExtHtmlWebpackPlugin')
                        .after('html')
                        .use('script-ext-html-webpack-plugin', [{

                        }])
                        .end();
                    // config
                    //     .optimization.splitChunks({
                    //         chunks: 'all',
                    //         cacheGroups: {
                    //             libs: {
                    //                 name: 'chunk-libs',
                    //                 test: /[\\/]node_modules[\\/]/,
                    //                 priority: 10,
                    //                 chunks: 'initial' // only package third parties that are initially dependent
                    //             },
                    //             elementUI: {
                    //                 name: 'chunk-elementUI', // split elementUI into a single package
                    //                 priority: 20, // the weight needs to be larger than libs and app or it will be packaged into libs or app
                    //                 test: /[\\/]node_modules[\\/]_?element-ui(.*)/ // in order to adapt to cnpm
                    //             },
                    //             commons: {
                    //                 name: 'chunk-commons',
                    //                 test: resolve('src/components'), // can customize your rules
                    //                 minChunks: 2, //  minimum common number
                    //                 priority: 5,
                    //                 reuseExistingChunk: true
                    //             }
                    //         }
                    //     });
                    // config.optimization.runtimeChunk('single');
                }
            );
    }
};