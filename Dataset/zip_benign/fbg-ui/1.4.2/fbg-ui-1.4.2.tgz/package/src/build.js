import Button from './components/button';
import Input from './components/input';
import Select from './components/select';
import Option from './components/select/option';
import Checkbox from './components/checkbox';
import CheckboxGroup from './components/checkbox/group';
import Navbar from './components/navbar';
import Table from './components/table';
import TableColumn from './components/table/column';
import SystemSelect from './components/systemSelect';
import Notice from './components/notice';
import Dropdown from './components/dropdown';
import DropdownItem from './components/dropdown/item.vue';
import Page from './components/page';
import Dialog from './components/dialog';
import Tabpage from './components/tabpage';
import Tree from './components/tree';
import Upload from './components/upload';
import Form from './components/form';
import FormItem from './components/form/item';
import UploadImage from './components/upload/image';
import UploadFile from './components/upload/file';
import ButtonGroup from './components/buttonGroup';
import ButtonGroupItem from './components/buttonGroup/item';
import Tooltip from './components/tooltip';
import MessageList from './components/messageList';
import Message from './components/message';
import { message } from './components/message';
import MessageBox from './components/messageBox';
import { msgbox } from './components/messageBox';
import DatePicker from './components/datePicker';
import DateTimePicker from './components/dateTimePicker';
import TimePicker from './components/timePicker';
import RadioGroup from './components/radio/group';
import Radio from './components/radio/item';
import PageLoading from './components/pageLoading';
import {pageLoading} from './components/pageLoading';
import FixedFooter from './components/fixedFooter';
import Vue from 'vue';

import {
    Loading,
    Breadcrumb,
    Popover,
    BreadcrumbItem,
    Pagination,
    Tabs,
    Row,
    Col,
    Divider,
    Badge,
    Switch
} from 'element-ui';

import '../fonts/iconfont.css';
import '../fonts/fbg-icons.css';
import './components/style.scss';
import 'element-ui/lib/theme-chalk/index.css';

export default {
    install(Vue) {
        Vue.use(Breadcrumb);
        Vue.use(BreadcrumbItem);
        Vue.use(Pagination);
        Vue.use(Tabs);
        Vue.use(Row);
        Vue.use(Col);
        Vue.use(Divider);
        Vue.use(Popover);
        Vue.use(RadioGroup);
        Vue.use(Radio);
        Vue.use(Badge);
        Vue.use(Message);
        Vue.use(MessageBox);
        Vue.use(Loading.directive);
        Vue.use(PageLoading);
        Vue.use(Switch);
        Vue.component('el-button', Button);
        Vue.component('el-input', Input);
        Vue.component('el-select', Select);
        Vue.component('el-option', Option);
        Vue.component('el-checkbox', Checkbox);
        Vue.component('el-checkbox-group', CheckboxGroup);
        Vue.component('el-menu', Navbar);
        Vue.component('el-system-select', SystemSelect);
        Vue.component('el-table-column', TableColumn);
        Vue.component('el-table', Table);
        Vue.component('el-notice', Notice);
        Vue.component('el-dropdown', Dropdown);
        Vue.component('el-dropdown-item', DropdownItem);
        Vue.component('el-page', Page);
        Vue.component('el-dialog', Dialog);
        Vue.component('el-tabpage', Tabpage);
        Vue.component('el-tree', Tree);
        Vue.component('el-upload', Upload);
        Vue.component('el-form', Form);
        Vue.component('el-form-item', FormItem);
        Vue.component('el-upload-image', UploadImage);
        Vue.component('el-upload-file', UploadFile);
        Vue.component('el-button-group', ButtonGroup);
        Vue.component('el-button-group-item', ButtonGroupItem);
        Vue.component('el-tooltip', Tooltip);
        Vue.component('el-message-list', MessageList);
        Vue.component('el-date-picker', DatePicker);
        Vue.component('el-time-picker', TimePicker);
        Vue.component('el-datetime-picker', DateTimePicker);
        Vue.component('el-radio', Radio);
        Vue.component('el-radio-group', RadioGroup);
        Vue.component('el-fixed-footer', FixedFooter);
    }
};