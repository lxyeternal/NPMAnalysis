import Main from './main';
export * from './main';

export default Main;