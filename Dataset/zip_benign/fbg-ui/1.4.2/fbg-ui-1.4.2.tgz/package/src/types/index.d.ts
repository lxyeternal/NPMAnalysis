export * from './index.js'

import FbgUI from './index.js'

export default fbgUI