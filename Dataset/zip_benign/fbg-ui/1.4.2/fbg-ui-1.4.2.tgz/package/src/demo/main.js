import Vue from 'vue'
import App from './App.vue'
import FbgUI from '../index'
import router from './router';
import 'element-ui/lib/theme-chalk/index.css';

document.title = 'FBG-UI 用例';
Vue.config.productionTip = false
Vue.use(FbgUI);

new Vue({
    router,
    render: h => h(App)
}).$mount('#app');