<template>
  <div>
    <header-box />
    <el-menu />
    <el-tabpage />
    <div class="main">
      <keep-alive>
        <router-view />
      </keep-alive>
    </div>
  </div>
</template>
<script>
import Tabs from './components/tabs';
import Header from './components/header';
export default {
  components: {
    'el-tabpage': Tabs,
    'header-box': Header
  }
}
</script>
<style lang="scss" scoped>
.main {
  padding: 30px;
}
</style>