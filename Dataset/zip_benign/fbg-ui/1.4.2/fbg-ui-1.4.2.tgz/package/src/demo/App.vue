<template>
  <div id="app">
    <Layout />
  </div>
</template>

<script>
import Layout from './layout';
export default {
  name: 'app',
  components: {
      Layout
  },
  data() {
    return {};
  },
  methods: {
    handleClick(){

    }
  }
}
</script>

<style lang="scss">
#app {
  button {
  }

}
html, body {
  height: 100%;
}
* {
  margin:0px;
  padding: 0px;
  font-size: 14px;
}

</style>
