<template>
  <div class="fbg-header">
    <el-system-select v-model="selectedSystem" :data="selectDataList"/>
    <el-notice  style="margin-left:100px;"/>
    <div style="display:inline-block;float:right">
      <el-dropdown v-model="selectedValue" style="width: 100px;">
        <span slot="content">
          <i class="fbgiconfont icon-touxiang" style="font-size:16px;vertical-align: middle;"/>
          <span>李治</span>
        </span>
        <el-dropdown-item v-for="(item, index) in menuList" :key="index" :label="item.label" :value="item.value" />
      </el-dropdown>
      <el-divider direction="vertical"></el-divider>
      <i class="fbgiconfont icon-xinxiaoxi" style="font-size:16px;vertical-align: middle;cursor: pointer;"/>
      <el-divider direction="vertical"></el-divider>
      <el-dropdown v-model="selectedLanguage" style="width: 70px;vertical-align: middle;">
        <span slot="content" slot-scope="data">{{data.data.label}}</span>
        <el-dropdown-item v-for="(item, index) in language" :key="index" :label="item.label" :value="item.value" />
      </el-dropdown>
      <i class="fbgiconfont icon-guanjituichudenglu" style="font-size:20px;vertical-align: middle;cursor: pointer;color: #777"/>
    </div>
  </div>
</template>
<script>
import util from '../../../utils';
export default {
  data() {
    return {
      selectedSystem: 1,
      selectedValue: 1,
      selectedLanguage: 2,
      language: [
        {
          label: '中文',
          value: 2,
        },
        {
          label: '英文',
          value: 3,
        }
      ],
      menuList: [
        {
          label: '修改密码',
          value: 2,
        },
        {
          label: '退出',
          value: 3,
        }
      ],
      selectDataList: [
        {
          label: '仓配管理系统11121221',
          value: 1,
          icon: 'shoucang1'
        },
        {
          label: 'OMS',
          value: 2,
          icon: 'service'
        }
      ]
    }
  },
  watch: {
    'selectedSystem': {
      immediate: true,
      handler(value) {
        // if (value === 1) {
        //   window.location.href = "http://192.168.107.238:8080/demo/#/table"
        // } else {
        //   window.location.href = "http://192.168.107.238:8081/demo/#/table"
        // }
      }
    }
  },
  mounted() {

  },
  methods: {

  }
}
</script>
<style lang="scss" scoped>
.fbg {
  &-header {
    padding: 13px 30px;
  }

}
</style>