import Vue from 'vue';
import Router from 'vue-router';

Vue.use(Router);

const routes = [{
        path: '/form',
        component: () =>
            import ('../pages/form'),
        name: 'form',
        meta: {
            title: '用户列表'
        }
    },
    {
        path: '/table',
        component: () =>
            import ('../pages/table'),
        name: 'table',
        meta: {
            title: '客户列表'
        }
    }
]
const createRouter = () => new Router({
    // mode: 'history', // require service support
    scrollBehavior: () => ({ y: 0 }),
    routes: routes
});

export default createRouter();