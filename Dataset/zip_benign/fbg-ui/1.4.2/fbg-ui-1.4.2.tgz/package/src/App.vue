<template>
  <div id="app">
    <h3>按钮</h3>
    <div>
      <el-button type="primary" size="lg">大按钮</el-button>
      <el-button type="default" size="lg">大按钮</el-button>
      <el-button type="text" size="lg">大按钮</el-button>
    </div>
    <div>
      <el-button type="primary">按钮</el-button>
      <el-button type="default">按钮</el-button>
      <el-button type="text">按钮</el-button>
    </div>
    <div>
      <el-button type="primary" size="sm">小按钮</el-button>
      <el-button type="default" size="sm">小按钮</el-button>
      <el-button type="text" size="sm">小按钮</el-button>
    </div>
    <div>
      <el-button type="primary" disabled>禁用按钮</el-button>
      <el-button type="default" disabled>禁用按钮</el-button>
      <el-button type="text" disabled>禁用按钮</el-button>
    </div>
    <div>
      <el-button type="primary" icon="icon-edit">图标按钮</el-button>
      <el-button type="default" icon="icon-edit">图标按钮</el-button>
    </div>
    <h3>输入框</h3>
    <div>
      <el-input placeholder="请输入" size="lg"/>
      <el-input placeholder="请输入" size="lg"><icon class="fbgiconfont icon-edit" slot="prepend"/></el-input>
      <el-input placeholder="请输入" size="lg"><icon class="fbgiconfont icon-edit" slot="append"/></el-input>
    </div>
    <div>
      <el-input placeholder="请输入"/>
      <el-input placeholder="请输入"><icon class="fbgiconfont icon-edit" slot="prepend"/></el-input>
      <el-input placeholder="请输入"><icon class="fbgiconfont icon-edit" slot="append"/></el-input>
    </div>
  </div>
</template>

<script>

export default {
  name: 'app',
  data() {
    return {};
  },
  methods: {
    handleClick(){
      
    }
  }
}
</script>

<style lang="scss">
#app {
  button {
    margin:10px;
  }

}
</style>
