<template>
  <div id="app">
    <Layout />
  </div>
</template>

<script>
import Layout from './layout';
import {pageLoading} from '../index';
export default {
  name: 'app',
  components: {
      Layout
  },
  data() {
    return {};
  },
  watch: {
    '$route': {
      immediate: true,
      handler() {
        pageLoading();
      }
    }
  },
  methods: {
    handleClick(){

    }
  }
}
</script>

<style lang="scss">
html, body{
  height: 100%;
  margin: 0px;
  padding: 0px;
}
#app {
  button {

  }

}

</style>
