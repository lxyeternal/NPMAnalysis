import Main from './Main.vue';

export default {
  install(Vue) {
    Vue.component('demo', Main);
  }
}