<template>
    <el-popper :options="options" style="position: absolute; top: 400px; left: 600px;">
        <el-button>测试</el-button>
        <ul slot="popup" style="width: 400px;">
            <li>测试00001</li>
            <li>测试00001</li>
            <li>测试00001</li>
            <li>测试00001</li>
            <li>测试00001</li>
            <li>测试00001</li>
            <li>测试00001</li>
        </ul>
    </el-popper>
</template>
<script>
import Popper from '../../components/popper/index.vue';
export default {
    components: {
        'el-popper': Popper
    },
    data() {
        return {
            options: {
                boundariesElement: '.layout-right'
            }
        }
    }
}
</script>