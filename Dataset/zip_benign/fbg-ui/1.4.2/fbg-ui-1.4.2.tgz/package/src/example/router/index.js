import Vue from 'vue';
import Router from 'vue-router';

Vue.use(Router);

const routes = [{
        path: '/',
        redirect: '/introduction'
    },
    {
        path: '/dropdown',
        component: () =>
            import ('@/components/Dropdown'),
    },
    {
        path: '/alert',
        component: () =>
            import ('@/components/Alert'),
    },
    {
        path: '/input',
        component: () =>
            import ('@/components/Input'),
        name: 'input'
    },
    {
        path: '/button',
        component: () =>
            import ('@/components/Button'),
        name: 'button'
    },
    {
        path: '/introduction',
        component: () =>
            import ('@/components/Introduction'),
        name: 'introduction'
    },
    {
        path: '/ui',
        component: () =>
            import ('@/components/UI'),
        name: 'ui'
    },
    {
        path: '/select',
        component: () =>
            import ('@/components/Select'),
        name: 'select'
    },
    {
        path: '/checkbox',
        component: () =>
            import ('@/components/Checkbox'),
        name: 'checkbox'
    },
    {
        path: '/navbar',
        component: () =>
            import ('@/components/Navbar'),
        name: 'navbar'
    },
    {
        path: '/table',
        component: () =>
            import ('@/components/Table'),
        name: 'table'
    },
    {
        path: '/systemSelect',
        component: () =>
            import ('@/components/SystemSelect'),
        name: 'systemSelect'
    },
    {
        path: '/notice',
        component: () =>
            import ('@/components/Notice'),
        name: 'notice'
    },
    {
        path: '/dialog',
        component: () =>
            import ('@/components/Dialog'),
        name: 'dialog'
    },
    {
        path: '/page',
        component: () =>
            import ('@/components/Page'),
        name: 'page'
    },
    {
        path: '/tabpage',
        component: () =>
            import ('@/components/Tabpage'),
        name: 'tabpage'
    },
    {
        path: '/tree',
        component: () =>
            import ('@/components/Tree'),
        name: 'tree'
    },
    {
        path: '/calendar',
        component: () =>
            import ('@/components/Calendar'),
        name: 'calendar'
    },
    {
        path: '/timepicker',
        component: () =>
            import ('@/components/TimePicker'),
        name: 'timepicker'
    },
    {
        path: '/upload',
        component: () =>
            import ('@/components/Upload'),
        name: 'upload'
    },
    {
        path: '/header',
        component: () =>
            import ('@/components/Header'),
        name: 'header'
    },
    {
        path: '/form',
        component: () =>
            import ('@/components/Form'),
        name: 'form'
    },
    {
        path: '/buttonGroup',
        component: () =>
            import ('@/components/ButtonGroup'),
        name: 'buttonGroup'
    },
    {
        path: '/message',
        component: () =>
            import ('@/components/Message'),
        name: 'message'
    },
    {
        path: '/theme',
        component: () =>
            import ('@/components/Theme'),
        name: 'theme'
    },
    {
        path: '/tabs',
        component: () =>
            import ('@/components/Tabs'),
        name: 'tabs'
    },
    {
        path: '/tooltip',
        component: () =>
            import ('@/components/Tooltip'),
        name: 'tooltip'
    },
    {
        path: '/card',
        component: () =>
            import ('@/components/Card'),
        name: 'card'
    },
    {
        path: '/popper',
        component: () =>
            import ('@/components/Popper'),
        name: 'Popper'
    }
]
const createRouter = () => new Router({
    mode: 'hash', // require service support
    scrollBehavior: () => ({ y: 0 }),
    routes: routes
});

export default createRouter();