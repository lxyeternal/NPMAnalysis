<template>
  <div>
    <h3 class="fbg-title">开发背景</h3>
    <p class="fbg-text">公司内部业务管理平台ui、ue设计粗糙、风格不统一、用户体验不佳</p>
    <p class="fbg-text">各平台使用的技术、框架各式各样、维护成本极高（tms后端渲染（jquery+iframe）、toms前端渲染（前端渲染（vue）））</p>
    <p class="fbg-text">平台整合难度很高</p>
    <h3 class="fbg-title">目的</h3>
    <p class="fbg-text">一套为开发者、设计师和产品经理准备的，基于 Vue 2.0 的后台管理应用组件库</p>
    <p class="fbg-text">使用组件 Demo 快速体验交互细节；使用前端框架封装的代码帮助工程师快速开发</p>
    <h3 class="fbg-title">一致性</h3>
    <p class="fbg-text">与现实生活一致：与现实生活的流程、逻辑保持一致，遵循用户习惯的语言和概念</p>
    <p class="fbg-text">在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等</p>
    <h3 class="fbg-title">效率</h3>
    <p class="fbg-text">设计简洁直观的操作流程</p>
    <p class="fbg-text">界面简单直白，让用户快速识别而非回忆，减少用户记忆负担</p>
  </div>
</template>
<script>
export default {
  
}
</script>
