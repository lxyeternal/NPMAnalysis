<template>
  <div>
    <h3 class="fbg-title">主题色</h3>
    <p class="fbg-text">fbg-ui提供了6种优质的主题色</p>
    <table class="fbg-table">
      <thead>
        <tr>
          <th>主色</th>
          <th>悬浮色</th>
          <th>激活色</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td style="color: #5a76e4">#5a76e4</td>
          <td style="color: #516ace">#516ace</td>
          <td style="color: #516ace">#516ace</td>
          <td><a download href="./theme/t1/global.scss">下载</a></td>
        </tr>
        <tr>
          <td style="color: #1b998e">#1b998e</td>
          <td style="color: #1a8980">#1a8980</td>
          <td style="color: #1a8980">#1a8980</td>
          <td><a download href="./theme/t2/global.scss">下载</a></td>
        </tr>
        <tr>
          <td style="color: #0082e0">#0082e0</td>
          <td style="color: #0175ca">#0175ca</td>
          <td style="color: #0175ca">#0175ca</td>
          <td><a download href="./theme/t3/global.scss">下载</a></td>
        </tr>
        <tr>
          <td style="color: #494f7f">#494f7f</td>
          <td style="color: #424673">#424673</td>
          <td style="color: #424673">#424673</td>
          <td><a download href="./theme/t4/global.scss">下载</a></td>
        </tr>
        <tr>
          <td style="color: #e27348">#e27348</td>
          <td style="color: #cb6841">#cb6841</td>
          <td style="color: #cb6841">#cb6841</td>
          <td><a download href="./theme/t5/global.scss">下载</a></td>
        </tr>
        <tr>
          <td style="color: #609b4b">#609b4b</td>
          <td style="color: #568b43">#568b43</td>
          <td style="color: #568b43">#568b43</td>
          <td><a download href="./theme/t6/global.scss">下载</a></td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
<script>
export default {
  
}
</script>
