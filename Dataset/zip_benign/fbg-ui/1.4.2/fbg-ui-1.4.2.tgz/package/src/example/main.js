import Vue from 'vue'
import App from './App.vue'
import FbgUI from '../index'
import router from './router';
import './styles/index.scss';
import 'highlight.js/styles/a11y-light.css';
import 'element-ui/lib/theme-chalk/index.css';
import Demo from './components/common/Demo';

document.title = 'FBG-UI 框架';
Vue.config.productionTip = false
Vue.use(FbgUI);
Vue.use(Demo);

new Vue({
    router,
    render: h => h(App)
}).$mount('#app');

