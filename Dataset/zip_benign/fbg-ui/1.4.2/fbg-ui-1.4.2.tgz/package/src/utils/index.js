let tabindex = 1;
export default {
    getTabIndex() {
        return tabindex;
    },
    getDocumentScrollTop() {
       return  document.documentElement.scrollTop;
    },
    getDocumentScrollLeft() {
        return  document.documentElement.scrollLeft;
    },
    getDocumentWidth() {
        return  document.documentElement.clientWidth;
    },
     getDocumentHeight() {
        return  document.documentElement.clientHeight;
    },
    getElTop(e, boundariesElement){
        let top = 0;
        const node = e.parentNode;
        if ((node && this.isDom(node) && node !== boundariesElement))  {
            top = e.offsetTop - node.offsetTop;
            top += this.getElTop(node, boundariesElement);
        }
        return top;
    },
    getElLeft(e, boundariesElement = 'body'){
        let offset = e.offsetLeft;
        if (e.offsetParent && !this.isBoundariesElement(e.offsetParent, boundariesElement))  {
            offset += this.getElLeft(e.offsetParent, boundariesElement);
        }
        return offset;
    },
    isBoundariesElement(e, boundariesElement = 'body') {
        const type = boundariesElement.substr(0, 1);
        const idOrClassName = boundariesElement.substr(1);
        switch(type) {
            case '#':
                return e.id === idOrClassName;
            case '.':
                return e.className.split(' ').indexOf(idOrClassName) > -1;
            default:
                return e.tagName.toUpperCase() === boundariesElement.toUpperCase();
        }
    },
    getBoundariesElement(e, boundariesElement) {
        if (e.parentNode && this.isBoundariesElement(e.parentNode, boundariesElement))  {
            return e.parentNode;
        } else if (e.parentNode){
            return this.getBoundariesElement(e.parentNode, boundariesElement);
        } else {
            return null;
        }
    },
    getScrollParentNode(e) {
        const node = e.parentNode;
        if (node && this.isDom(node) && node.scrollHeight - 20 > node.clientHeight)  {
            return node;
        } else if (this.isDom(node)) {
            return this.getScrollParentNode(node);
        } else {
            return null;
        }
    },
    isDom(obj) {
        return obj && typeof obj === 'object' && (obj.nodeType === 1 || obj.nodeType === 9) && typeof obj.nodeName === 'string';
    },
    getMaxIndex(e, zIndex = 0){
        if (this.isDom(e)) {
            let index = this.getStyle(e, 'z-index');
            if (index === 'auto') {
                index = 0;
            }
            if (zIndex > index) {
                index = zIndex;
            }
            if (e.offsetParent)  {
                return this.getMaxIndex(e.offsetParent, index);
            } else {
                return index;
            }
        } else {
            return this.getMaxIndex(e.offsetParent, zIndex);
        }
    },
    setElScrollTop(e, top = 0){
        if (this.isDom(e)) {
            if (e.tagName.toUpperCase() === 'BODY') {
                document.documentElement.scrollTop = top;
            }
            e.scrollTop = top;
        }
    },
    setElScrollLeft(e, left = 0){
        if (this.isDom(e)) {
            if (e.tagName.toUpperCase() === 'BODY') {
                document.documentElement.scrollLeft = left;
            }
            e.scrollLeft = left;
        }
    },
    getElScrollTop(e){
        if (this.isDom(e)) {
            if (e.tagName.toUpperCase() === 'BODY') {
                return this.getDocumentScrollTop();
            } else {
                return e.scrollTop;
            }
        } else {
            return 0;
        }
    },
    getElScrollLeft(e){
        if (this.isDom(e)) {
            if (e.tagName.toUpperCase() === 'BODY') {
                return this.getDocumentScrollLeft();
            } else {
                return e.scrollLeft;
            }
        } else {
            return 0;
        }
    },
    getElHeight(e){
        return e.offsetHeight;
    },
    getElWidth(e){
        return e.offsetWidth;
    },
    // 获取样式
    getStyle(obj, attr) {
        return obj.currentStyle ? obj.currentStyle[attr] : getComputedStyle(obj, null)[attr];
    },
    getVNode(el, tagName) {
        const arr = [];
        if (el.tag === tagName) {
            arr.push(el);
        } else if (el.componentOptions && el.componentOptions.tag === tagName) {
            arr.push(el);
        }
        // if (el.children && el.children.length) {
        //   el.children.forEach(item => {
        //     const res = this.getVNode(item, tagName);
        //     arr.push(...res);
        //   });
        // } else if (el.componentInstance) {
        //   console.log(el.componentInstance, 777)
        //   // el.componentInstance.children.forEach(item => {
        //   //   console.log(item.$vnode, 777)
        //   //   const res = this.getVNode(item.$vnode, tagName);
        //   //   arr.push(...res);
        //   // });
        // }
        return arr;
    },
    filterEvent(data, names) {
        let events = {};
        for (let key in data) {
            if (names.indexOf(key) === -1) {
                events[key] = data[key];
            }
        }
        return events;
    },
    getVNodeByList(els, tagName) {
        const arr = [];
        els.forEach(item => {
            const res = this.getVNode(item, tagName);
            arr.push(...res);
        });
        return arr;
    },
    // 判断是不是对象类型
    isObject(data) {
        return Object.prototype.toString.call(data) === "[object Object]";
    },
    getObjectValue(data, fields, flag = true) {
        const fs = fields.split('.');
        let d = data;
        const msg = `'form-item' component prop ${fields} is undefined`;
        fs.forEach(item => {
            if (typeof data === "undefined") {
                console.warn(msg);
            } else {
                d = data;
                if (typeof data === 'object') {
                    data = data[item];
                } else {
                    console.warn(msg);
                }
            }
        });
        if (!flag) {
            return d;
        } else {
            return data;
        }
    },
    getLastProp(props) {
        const ps = props.split('.');
        return ps[ps.length - 1];
    },
    getDefaultDateType(type) {
        switch(type) {
            case 'date': 
            case 'daterange':
                return 'yyyy-MM-dd';
                break;
            case 'datetime': 
            case 'datetimerange': 
                return 'yyyy-MM-dd hh:mm:ss';
                break;
            default: 
                return 'yyyy-MM-dd';
        }
    },
    deepCopy(data) {
        try {
            return JSON.parse(JSON.stringify(data));
        } catch (e) {
            return data;
        }
    },

}