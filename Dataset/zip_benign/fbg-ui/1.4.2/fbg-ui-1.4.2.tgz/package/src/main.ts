import Button from './components/button/index.vue';
import Input from './components/input/index.vue';
import Select from './components/select/index.vue';
import Option from './components/select/option.vue';
import Checkbox from './components/checkbox/index.vue';
import CheckboxGroup from './components/checkbox/group.vue';
import Navbar from './components/navbar/index.vue';
import Table from './components/table/index.vue';
import TableColumn from './components/table/column.vue';
import SystemSelect from './components/systemSelect/index.vue';
import Notice from './components/notice/index.vue';
import Dropdown from './components/dropdown/index.vue';
import DropdownItem from './components/dropdown/item.vue';
import Page from './components/page/index.vue';
import Dialog from './components/dialog/index.vue';
import Tabpage from './components/tabpage/index.vue';
import Tree from './components/tree/index.vue';
import Upload from './components/upload/index.vue';
import Form from './components/form/index.vue';
import FormItem from './components/form/item.vue';
import UploadImage from './components/upload/image.vue';
import UploadFile from './components/upload/file.vue';
import ButtonGroup from './components/buttonGroup/index.vue';
import ButtonGroupItem from './components/buttonGroup/item.vue';
import Tooltip from './components/tooltip/index.vue';
import MessageList from './components/messageList/index.vue';
import Message from './components/message';
import {message} from './components/message';
import MessageBox from './components/messageBox';
import {msgbox} from './components/messageBox';
import DatePicker from './components/datePicker/index.vue';
import TimePicker from './components/timePicker/index.vue';
import RadioGroup from './components/radio/group.vue';
import Radio from './components/radio/item.vue';
import {pageLoading} from './components/pageLoading';
import FixedFooter from './components/fixedFooter.vue';

import {
    Breadcrumb,
    BreadcrumbItem,
    Pagination,
    Tabs,
    Row,
    Col,
    Divider,
    Badge,
    Loading,
    Switch
} from 'element-ui';

import '../fonts/iconfont.css';
import '../fonts/fbg-icons.css';
import './components/style.scss';
import 'element-ui/lib/theme-chalk/index.css';
export {
    Loading,
    message,
    msgbox,
    pageLoading
};

export default {
    install(Vue: any) {
        Vue.use(Breadcrumb);
        Vue.use(BreadcrumbItem);
        Vue.use(Pagination);
        Vue.use(Tabs);
        Vue.use(Row);
        Vue.use(Col);
        Vue.use(Divider);
        Vue.use(Badge);
        Vue.use(Message);
        Vue.use(MessageBox);
        Vue.use(Switch);
        Vue.component('el-button', Button);
        Vue.component('el-input', Input);
        Vue.component('el-select', Select);
        Vue.component('el-option', Option);
        Vue.component('el-checkbox', Checkbox);
        Vue.component('el-checkbox-group', CheckboxGroup);
        Vue.component('el-menu', Navbar);
        Vue.component('el-system-select', SystemSelect);
        Vue.component('el-table-column', TableColumn);
        Vue.component('el-table', Table);
        Vue.component('el-notice', Notice);
        Vue.component('el-dropdown', Dropdown);
        Vue.component('el-dropdown-item', DropdownItem);
        Vue.component('el-page', Page);
        Vue.component('el-dialog', Dialog);
        Vue.component('el-tabpage', Tabpage);
        Vue.component('el-tree', Tree);
        Vue.component('el-upload', Upload);
        Vue.component('el-form', Form);
        Vue.component('el-form-item', FormItem);
        Vue.component('el-upload-image', UploadImage);
        Vue.component('el-upload-file', UploadFile);
        Vue.component('el-button-group', ButtonGroup);
        Vue.component('el-button-group-item', ButtonGroupItem);
        Vue.component('el-tooltip', Tooltip);
        Vue.component('el-message-list', MessageList);
        Vue.component('el-date-picker', DatePicker);
        Vue.component('el-time-picker', TimePicker);
        Vue.component('el-radio', Radio);
        Vue.component('el-radio-group', RadioGroup);
        Vue.component('el-fixed-footer', FixedFooter);

    }
};