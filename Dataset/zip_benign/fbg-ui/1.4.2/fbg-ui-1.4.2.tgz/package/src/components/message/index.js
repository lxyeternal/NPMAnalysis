import Vue from 'vue';
import Main from './main.vue';

let seed = 0;
const message = (props) => {
  let id = 'message_' + seed++;
  let Com = Vue.extend(Main);
  let instance = new Com({
      propsData: props
  });
  instance.id = id;
  instance.$mount();
  document.body.appendChild(instance.$el);
}

export {
  message
}

export default {
  install() {
    Vue.prototype.$message = message;
  }
}