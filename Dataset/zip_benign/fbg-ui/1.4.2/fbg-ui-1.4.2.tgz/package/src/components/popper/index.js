import  Main from './index.vue';
export default {
    install(Vue) {
        Vue.component('el-popper', Main);
    }
}