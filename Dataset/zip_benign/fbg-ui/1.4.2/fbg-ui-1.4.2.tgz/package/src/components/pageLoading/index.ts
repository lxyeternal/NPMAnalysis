import Vue from 'vue';
import Main from './main.vue';

const pageLoading = () => {
  let Com = Vue.extend(Main);
  let instance = new Com();
  instance.$mount();
  document.body.appendChild(instance.$el);
  let timer: any = setTimeout(() => {
    instance.$el.remove();
    instance.$destroy();
    clearTimeout(timer);
    timer = null;
  }, 1000);
}

export {
  pageLoading
}

export default {
  install() {
    Vue.prototype.$pageLoading = pageLoading;
  }
}