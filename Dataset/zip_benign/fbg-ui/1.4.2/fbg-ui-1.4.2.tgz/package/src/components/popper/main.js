import Vue from 'vue';
import Popper from './popper';
import util from '../../utils';

let seed = 0;
const popper = (props, slots, parent) => {
  let id = 'popper_' + seed++;
  let Com = Vue.extend(Popper);
  let instance = new Com({
      componentName: 'FbgPopup',
      propsData: props,
      data: {
        positionDirectionClass: '',
        positionVerticalClass: '',
        markStyle: {},
        slots
      },
      created() {
        this.$parent = parent;
      },
      render(h) {
        const arr = [...this.slots];
        if (props.visibleArrow) {
          arr.push(
            h('div', {
              style: this.markStyle,
              class: {
                [this.positionDirectionClass]: true,
                [this.positionVerticalClass]: true,
              }
            })
          );
        }
        return h('div', {
          class: {
            'fbg-popper-box': true
          },
          ref: 'mainRef'
        }, [h('div', {}, arr)]);
      },
  });
  instance.id = id;
  instance.$mount();
  const boundariesElement = util.getBoundariesElement(props.el, props.options.boundariesElement);
  boundariesElement.appendChild(instance.$el);
  return instance;
}

export {
  popper
}

export default {
  install() {
    Vue.prototype.$popper = popper;
  }
}