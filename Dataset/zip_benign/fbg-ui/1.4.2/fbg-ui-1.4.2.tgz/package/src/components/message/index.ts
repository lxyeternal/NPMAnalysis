import Vue from 'vue';
import Main from './main.vue';
interface Props {
  message?: string;
  type?: string;
  content?: string;
  duration?: number;
}
let seed = 0;
const message = (props: Props) => {
  let id = 'message_' + seed++;
  let Com = Vue.extend(Main);
  let instance = new Com({
      propsData: props,
      data() {
        return {
          id: ''
        }
      },
  });
  instance.id = id;
  instance.$mount();
  document.body.appendChild(instance.$el);
}

export {
  message
}

export default {
  install() {
    Vue.prototype.$message = message;
  }
}