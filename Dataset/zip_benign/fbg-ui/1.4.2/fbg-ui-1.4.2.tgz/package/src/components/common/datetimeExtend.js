export default {
    data() {
        return {
            mapData: {
                'yyyy': 'year',
                'MM': 'month',
                'dd': 'day',
                'hh': 'hour',
                'mm': 'minute',
                'ss': 'second'
            },
        }
    },
    computed: {
        isRange() {
            const isRange =  ['daterange', 'datetimerange'].indexOf(this.type) > -1;
            if (isRange && !(this.value instanceof Array)) {
                throw new Error('value must be an array!');
            }
            return isRange;
        }
    },
    methods: {
        setMonth(date, m) {
            const d = new Date(date);
            d.setDate(1);
            d.setMonth(m - 1);
            if (d.getDate() < date.getDate()) {
                date.setDate(d.getDate());
            }
            return date.setMonth(m - 1);
        },
        getMonth(date) {
            return date.getMonth() + 1;
        },
        setTimeContent(date, data) {
            date.setHours(data.hour);
            date.setMinutes(data.minute);
            date.setSeconds(data.second);
            return date;
        },
        getDateTimeInfo(date) {
            const year = date.getFullYear();
            let month = this.getMonth(date);
            let day = date.getDate();
            let hour = date.getHours();
            let minute = date.getMinutes();
            let second = date.getSeconds();
            let stampTime = date.getTime();
            return {
                year: this.zeroize(year),
                month: this.zeroize(month),
                day: this.zeroize(day),
                hour: this.zeroize(hour),
                minute: this.zeroize(minute),
                second: this.zeroize(second),
                stampTime,
                date
            }
        },
        // 获取date对象
        getDate(year, month, day, hours = 0, minutes = 0, second = 0) {
            const date = new Date();
            date.setFullYear(year);
            this.setMonth(date, month);
            date.setDate(day);
            date.setHours(hours);
            date.setMinutes(minutes, second);
            return date;
        },
        getDateInfo(date) {
            const year = date.getFullYear();
            const month = this.getMonth(date);
            const day = date.getDate();
            const stampTime = this.getDate(year, month, day).getTime();
            return {
                year,
                month,
                day,
                stampTime
            };
        },
        // 转换日期格式
        getDateObj(date) {
            if (typeof date === 'number' || typeof date === 'string') {
                return new Date(date);
            }
            if (date instanceof Date) {
                return date;
            }
            throw new Error('value is not Date format!');
        },
        setDateTime(date, data) {
            date.setHours(data.hour);
            date.setMinutes(data.minute, data.second);
            return date;
        },
        zeroize(value) {
            const v = parseInt(value);
            if (isNaN(v)) {
                return value;
            } else if (v < 10) {
                return "0" + v;
            } else {
                return v;
            }

        },
        // 日期时间值依据format规则转换成真正的日期时间格式
        valueToDateTime(value, format) {
            let count = 0;
            return format.replace(/([yMdhms]+)?([^yMdhms]*)/g, (s1, s2, s3, s4) => {
                if (s2) {
                    const v = value.substr(s4, s2.length);
                    count++;
                    if (count <= 2) {
                        return v + '-';
                    } else if(count === 3) {
                        return v + ' ';
                    } else if((s4 + s1.length) < format.length) {
                        return v + ':';
                    } else {
                        return v;
                    }
                } 
                return '';

            }).trim();
        },
        // 格式化日期
        formatDateTime(data, format) {
            return format.replace(/([yMdhms])\1*/g, (s1) => {
                return this.zeroize(data[this.mapData[s1]]);
            });
        },
        // 判断是否同一天
        isSameDate(d1, d2, d) {
            if (!d1 || !d2) {
                return false;
            }
            d1 = this.getDateObj(d1);
            d2 = this.getDateObj(d2);
            
            if (d1.getFullYear() !== d2.getFullYear()) {
                return false;
            }
            if (this.getMonth(d1) !== this.getMonth(d2)) {
                return false;
            }
            if (d1.getDate() !== d2.getDate()) {
                return false;
            }
            
            return true;
        },
        // 转换value
        transformValue(value, data, valueFormat) {
            if (typeof value === 'string') {
                return this.formatDateTime(data, valueFormat);
            } else if (typeof value === 'number') {
                return data.stampTime;
            } else if (value instanceof Date) {
                return data.date;
            } else {
                return this.formatDateTime(data, valueFormat);
            }
        },
        // 获取相对当前date的前n个月或者后n个月
        getDateByMonth(date, n = 1) {
            let nDate = new Date(date);
            this.setMonth(nDate, this.getMonth(date) + n);
            return nDate;
        },
        // 获取相对当前date的前n个年或者后n个年
        getDateByYear(date, n = 1) {
            let nDate = new Date(date);
            nDate.setFullYear(date.getFullYear() + n);
            return nDate;
        },
        // 获取date的天数
        getDays(date) {
            let preDate = this.getDateByMonth(date);
            let ndate = new Date(preDate.getFullYear(), this.getMonth(preDate) - 1, 0);
            return ndate.getDate();
        },
        // 创建日历日期列表
        createdDaysData(date) {
            date = new Date(date);
            date.setDate(1);
            let days = this.getDays(date);
            let year = date.getFullYear();
            let month = this.getMonth(date);
            const weekday = this.getDate(year, month, 1).getDay();
            const preMonthDate = this.getDateByMonth(date, -1);
            let preDays = this.getDays(preMonthDate);
            let preYear = preMonthDate.getFullYear();
            let preMonth = this.getMonth(preMonthDate);
            const nextMonthDate = this.getDateByMonth(date, +1);  
            let nextDays = this.getDays(nextMonthDate);
            let nextYear = nextMonthDate.getFullYear();
            let nextMonth = this.getMonth(nextMonthDate);
            let arr = [];
            console.log(preMonthDate, preDays, year, month, 1, weekday)
            for (let i = 1;i <= days; i++){ 
                const stampDate = this.getDate(year, month, i);
                const stampTime = stampDate.getTime();
                const disabled = typeof this.pickerOptions.disabledDate === 'function' ? this.pickerOptions.disabledDate(stampDate) : false;
                let chooseDisabled = false;
                if (this.isRange && this.chooseDate.length) {
                    chooseDisabled = typeof this.pickerOptions.disabledChooseDateRange === 'function'? this.pickerOptions.disabledChooseDateRange(stampDate, new Date(this.chooseDate[0].stampTime)) : false;
                }
                arr.push({
                    day: i,
                    month,
                    year,
                    stampTime,
                    status: disabled?false:true,
                    chooseDisabled,
                    disabled: this.disabled || disabled
                });
            }
            
            for (let j = 0; j < weekday; j++){
                const stampTime = this.getDate(preYear, preMonth, preDays - j).getTime();
                arr.unshift({
                    day: preDays - j,
                    month: preMonth,
                    year: preYear,
                    stampTime,
                    status: false,
                    disabled: this.disabled 
                });
            }
            const nd = 42 - arr.length;
            if (nd !== 0) {
                for (let z = 1;z <= nd; z++){ 
                    const stampTime = this.getDate(nextYear, nextMonth, z).getTime();
                    arr.push({
                    day: z,
                    month: nextMonth,
                    year: nextYear,
                    stampTime,
                    status: false,
                    disabled: this.disabled 
                    });
                }
            }
    
            const newArr = [];
            let cacheArr = [];
            arr.forEach((item, index) => {
            cacheArr.push(item);
            if ((index+1)%7 === 0) {
                newArr.push(cacheArr);
                cacheArr = [];
            }
            
            });
            return newArr;
        }
    }
}