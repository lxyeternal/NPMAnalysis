export default {
    beforeCreate() {},
    methods: {
        blur(e) {
            this.$refs.mainRef.focus();
        },
        focus(e) {
            this.$refs.mainRef.focus();
        }
    },
}