<template>

</template>
<script>
export default {
  props: {
    src: {
      type: String,
      default: ''
    }
  },
  data() {
    return {};
  },
  methods: {
    handleClickItem() {
      this.$emit('onClick', this.src);
    },
    handleClose() {
      this.$emit('onRemove', this.src);
    },
  }
}
</script>
<style lang="scss" scoped>
.fbg {
  &-upload {
    &-file {
      margin-top: 10px;
      &-item {
        padding: 8px 10px;
        list-style: none;
        overflow: hidden;
        text-overflow:ellipsis;
        white-space: nowrap;
        border-radius: 3px;
        color: #666;
        &:hover {
          background-color: rgba(0, 0, 0, 0.1);
        }
      }
      &-close {
        float: right;
      }
    }
  }
}
</style>