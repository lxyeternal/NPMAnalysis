<template >
  <div v-if="isExist" ref="mainRef" :class="'fbg-message '+className ">
    <div class="fbg-message-main">
      <i class="fbg-message-icon" :class="iconClassName" />
      <div style="flex: 1">
        <slot name="title"><span>{{title}}</span></slot>
        <div>
          <div v-show="description||$scopedSlots.description" class="fbg-message-content">
            <slot name="description">
              {{description}}
            </slot>
          </div>
        </div>
      </div>
      <div v-if="closable" class="fbg-message-close">
        <div class="fbg-message-close-main" @click="handleClose">
          <slot name="close">
            <span v-if="closeText">{{closeText}}</span>
            <i v-else class="fbg-icon-close" />
          </slot>
        </div>
      </div>
    </div>
  
  </div>
</template>
<script>
export default {
  props: {
    closeText: {
      type: String,
      default: ''
    },
    closable: {
      type: Boolean,
      default: false
    },
    title: {
      type: String,
      default: ''
    },
    type: {
      type: String,
      default: 'success'
    },
    description: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      isShow: false,
      isExist: true
    }
  },
  computed: {
    iconClassName() {
      return (this.type === 'success'?'fbg-icon-success':'fbg-icon-warning')+' fbg-message-'+this.type+'-icon';
    },
    className() {
      return 'fbg-message-' + this.type;
    }
  },
  methods: {
    handleClose() {
      this.isExist = false;
      this.$emit('close');
    }
  }
}
</script>
<style lang="scss" scoped>
.fbg {
  &-message {
    padding: 10px;
    color: #666;
    border-radius: 5px;
    position: relative;
    &-main {
      display: flex;
    }
    &-icon {
      width: 20px;
      vertical-align: middle;
      margin-top: 2px;
    }
    &-close {
      color: #888;
      cursor: pointer;
      display: flex;
      align-items: center;

    }
    &-content {
      color: #999;
      margin-top: 5px;
      font-size: 12px;
      vertical-align: top;
    }
    &-success {
      background-color: #D3F4EC;
      border: 1px solid #5BCCA6;
      &-icon {
        font-size: 16px;
        vertical-align: middle;
        margin-right: 8px;
        color: #5BCCA6;
      }
    }
    &-error {
      background-color: #F9D7D8;
      border: 1px solid #ED4849;
      &-icon {
        font-size: 16px;
        vertical-align: middle;
        margin-right: 8px;
        color: #ED4849;
      }
    }
    &-warning {
      background-color: #FCE6CF;
      border: 1px solid #F2873B;
      &-icon {
        font-size: 16px;
        vertical-align: middle;
        margin-right: 8px;
        color: #F2873B;
      }
    }
    &-info {
      background-color: #D3E9FD;
      border: 1px solid #3498F7;
      &-icon {
        font-size: 16px;
        vertical-align: middle;
        margin-right: 8px;
        color: #3498F7;
      }
    }
  }
}
</style>