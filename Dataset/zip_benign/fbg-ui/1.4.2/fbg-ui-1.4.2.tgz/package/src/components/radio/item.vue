<template>
  <fbg-radio v-bind="$attrs" v-on="$listeners"><slot /></fbg-radio>
</template>
<script>
import {Radio} from 'element-ui';
export default {
  components: {
    'fbg-radio': Radio
  }
}
</script>