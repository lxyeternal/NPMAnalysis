export default interface Props  {
  method?: string;
  title?: string;
  message?: string;
  type?: string;
  content?: string;
  modal?: boolean;
  showClose?: boolean;
  showFooter?: boolean;
  cancelButtonText?: string;
  confirmButtonText?: string;
  showCancelButton?: boolean;
  showConfirmButton?: boolean;
  closeOnClickModal?: boolean;
  closeOnPressEscape?: boolean;
};