<template>
  <div class="fixed-footer">
    <slot />
  </div>
</template>
<script>
export default {
  mounted() {
    document.body.style.paddingBottom = "60px";
  },
  destroyed() {
    document.body.style.paddingBottom = "0px";
  },
  activated() {
    document.body.style.paddingBottom = "60px";
  },
  deactivated() {
    document.body.style.paddingBottom = "0px";
  }
}
</script>
<style lang="scss" scoped>
.fixed-footer {
  position: fixed;
  height: 60px;
  line-height: 60px;
  width: 100%;
  left: 0px;
  bottom: 0px;
  background-color: #fff;
  text-align: center;
  box-shadow: 0px -2px 4px $themeShadowColor;
}
</style>