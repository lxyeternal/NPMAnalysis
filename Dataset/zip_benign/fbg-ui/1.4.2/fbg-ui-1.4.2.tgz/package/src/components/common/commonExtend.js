export default {
    methods: {
        click() {
            this.$refs.mainRef && this.$refs.mainRef.click();
        },
        dispatch: function dispatch(componentName, eventName, params) {
            var parent = this.$parent || this.$root;
            var name = parent.$options.componentName;

            while (parent && (!name || name !== componentName)) {
                parent = parent.$parent;
                if (parent) {
                    name = parent.$options.componentName;
                }
            }
            if (parent) {
                parent.$emit.apply(parent, [eventName].concat(params));
            }
        },

        // 选项
        changeEmit(value) {
            this.$emit('change', value);
        },
        setCheckedOptionList() {
            this.options.forEach(item => {
                this.setCheckedOption(item);
            });
        },
        setCheckedOption(item) {
            if (this.multiple) {
                if (this.value.indexOf(item.value) > -1) {
                    item.checked = true;
                } else {
                    item.checked = false;
                }
            } else {  
                item.checked = item.value === this.value;
            }
        },
        setValue(item, flag = true) {
            if (this.multiple) {
                const index = this.value.indexOf(item.value);
                if (item.checked) {
                    if (index === -1) {
                        this.value.push(item.value);
                    }
                } else {
                    if (index > -1) {
                        this.value.splice(index, 1);
                    }
                }
                this.$emit('input', this.value);
            } else {
                const value = item.value;
                // this.resetOptionListChecked(value);
                this.$emit('input', value);
            }
        },
        resetOptionListChecked(value) {
            this.options.forEach(item => {
                if (item.value !== value) {
                    item.checked = false;
                }
            });
        },
        // 键盘控制选项
        handleEnter() {
            this.options.forEach(item => {
                if (item.index === this.hoverIndex) {
                    item.click();
                } 
            });  
        },
        handleDownChoose() {
            this.hoverIndex++;
            if (this.hoverIndex >= this.count) {
                this.hoverIndex = 0;
            }
            
            this.setHoverStatus(this.hoverIndex);
        },
        handleUpChoose() {
            this.hoverIndex--;
            if (this.hoverIndex <= 0) {
                this.hoverIndex = this.count;
            }
            this.setHoverStatus(this.hoverIndex);
        },
        setHoverStatus(index) {
            this.options.forEach(item=> {
                item.isHover = item.index === index;
            });
        },
    }
}