<template>
  <fbg-radio-group :value="value" v-bind="$attrs" @change="handleChange" @input="handleInput"><slot /></fbg-radio-group>
</template>
<script>
import {RadioGroup} from 'element-ui';
import commonExtend from '../common/commonExtend';

export default {
  extends: commonExtend,
  props: {
    value: {
      type: [String, Number],
      default: ''
    },
  },
  components: {
    'fbg-radio-group': RadioGroup,
  },
  methods: {
    handleChange(value) {
      this.$emit('change', value);
    },
    handleInput(value) {
      this.$emit('input', value);
      this.dispatch('FbgFormItem', 'fbg.formItem.validate', [this]);
    }
  }
}
</script>
<style lang="scss" >
.fbg-form-item-content-error {
  .el-radio__inner {
    border-color: red;
  }
}

</style>