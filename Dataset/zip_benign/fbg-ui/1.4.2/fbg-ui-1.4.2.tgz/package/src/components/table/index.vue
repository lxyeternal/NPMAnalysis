<template>
  <table-box ref="table" v-loading="loading" v-bind="$attrs" v-on="$listeners">
    <template v-for="(item, index) in columns">
      <table-column v-if="item.checked !== false" v-bind="item" @overflowColnumCallback="handleOverflowColnum" :key="index" :max="max">
        <template slot-scope="scope">
          <slot :name="item.prop" v-bind="scope">
            {{item.filterEmpty?filterEmpty(scope.row[item.prop]):scope.row[item.prop]}}
          </slot>
        </template>
        <template slot="header" slot-scope="scope">
          <slot :name="item.prop+'-header'" v-bind="scope"></slot>
        </template>
      </table-column>
    </template>
    <template slot="empty">
      <slot name="empty" />
    </template>
  </table-box>
</template>
<script>
import {Table} from 'element-ui';
import TableColumn from './column';
export default {
  components: {
    'table-box': Table,
    TableColumn
  },
  provide() {
    return {
      columns: this.columns
    }
  },
  watch: {
    '$scopedSlots': {
      immediate:true,
      handler(){
        
      }
    }
  },
  props: {
    max:{
      type:Number,
      default:10
    },
    columns: {
      type: Array,
      default() {
        return [];
      }
    },
    filterEmptyText: {
      type: String,
      default: '—'
    },
    loading: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    setCurrentRow(row) {
      this.$refs.table.setCurrentRow(row);
    },
    handleOverflowColnum(item) {
      this.$emit('overflowColnum', item);
    },
    filterEmpty(value) {
      return typeof value === 'undefined' || value === null || value === '' ? this.filterEmptyText: value;
    }
  }
}
</script>