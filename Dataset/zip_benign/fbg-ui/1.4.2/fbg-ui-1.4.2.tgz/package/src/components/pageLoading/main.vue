<template>
  <div class="page-loading"></div>
</template>
<script>
export default {
  
}
</script>
<style lang="scss" scoped>
@keyframes load
{
	from {width: 0px;}
	to {width: 100%;}
}
.page-loading {
  position: fixed;
  top: 0px;
  left: 0px;
  height: 1px;
  width: 0px;
  z-index: 999999999;
  background-color: #5a76e4;
  box-shadow: 1px 0px 2px #5a76e4; 
  animation: load 0.6s;
}
</style>