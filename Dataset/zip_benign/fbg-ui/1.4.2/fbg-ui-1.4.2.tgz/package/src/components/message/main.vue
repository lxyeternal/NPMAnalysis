<template >
  <div v-if="isExist" ref="mainRef" :class="'fbg-message '+className ">
    <div>
      <i :class="iconClassName" />
      <span>{{message}}</span>
      <slot />
    </div>
    <p v-show="content" class="fbg-message-content">{{content}}</p>
  </div>
</template>
<script>
export default {
  props: {
    message: {
      type: String,
      default: '操作失败'
    },
    type: {
      type: String,
      default: 'success'
    },
    content: {
      type: String,
      default: ''
    },
    duration: {
      type: Number,
      default: 2000
    },
    slotRender: {
      type: Function,
      default: null
    }

  },
  data() {
    return {
      isShow: false,
      isExist: true
    }
  },
  beforeUpdate() {
    this.updateSlot();
  },
  created() {
    this.updateSlot();
  },
  computed: {
    iconClassName() {
      return (this.type === 'success'?'fbg-icon-success':'fbg-icon-warning')+' fbg-message-'+this.type+'-icon';
    },
    className() {
      return 'fbg-message-' + this.type + (this.isShow ? ' fbg-message-show' : ' fbg-message-hide');
    }
  },
  mounted() {
    this.show();
  },
  methods: {
    updateSlot() {
      if (typeof this.slotRender === 'function') {
        this.$slots.default = [this.slotRender(this.$createElement)];
      }
    },
    handleClick() {
      this.show();
    },
    show() {
      this.$refs.mainRef.style.display = "block";
      let timer = setTimeout(() => {
        this.isShow = true;
        clearTimeout(timer);
        timer = null;
        let t = setTimeout(() => {
          this.hide();
          clearTimeout(t);
          t = null;
        }, this.duration);
      },30);
    },
    hide() {
      this.isShow = false;
      let timer = setTimeout(() => {
        this.$refs.mainRef.style.display = "none";
        this.isExist = false;
        clearTimeout(timer);
        timer = null;
      },350);
    }
  }
}
</script>
<style lang="scss" scoped>
.fbg {
  &-message {
    padding: 10px;
    color: #666;
    display: inline-block;
    display: none;
    position: fixed;
    transform: translateX(-50%);
    max-width: 350px;
    left: 50%;
    transition: all 0.35s;
    z-index: 9999999;
    border-radius: 5px;
    &-hide {
      top: -100px;
      opacity: 0;
    }
    &-show {
      top: 80px;
      opacity: 1;
    }
    &-content {
      color: #999;
      padding-left: 30px;
      margin-top: 5px;
      font-size: 12px;
    }
    &-success {
      background-color: #D3F4EC;
      border: 1px solid #5BCCA6;
      &-icon {
        font-size: 16px;
        vertical-align: middle;
        margin-right: 8px;
        color: #5BCCA6;
      }
    }
    &-error {
      background-color: #F9D7D8;
      border: 1px solid #ED4849;
      &-icon {
        font-size: 16px;
        vertical-align: middle;
        margin-right: 8px;
        color: #ED4849;
      }
    }
    &-warning {
      background-color: #FCE6CF;
      border: 1px solid #F2873B;
      &-icon {
        font-size: 16px;
        vertical-align: middle;
        margin-right: 8px;
        color: #F2873B;
      }
    }
    &-info {
      background-color: #D3E9FD;
      border: 1px solid #3498F7;
      &-icon {
        font-size: 16px;
        vertical-align: middle;
        margin-right: 8px;
        color: #3498F7;
      }
    }
  }
}
</style>