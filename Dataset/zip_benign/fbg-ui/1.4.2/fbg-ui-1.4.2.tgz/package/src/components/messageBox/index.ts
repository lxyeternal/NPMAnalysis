import Vue from 'vue';
import Main from './main.vue';
import Props from './type';

let seed = 0;
const msgbox = (message: string, content: string, props: Props) => {
  return new Promise((resolve, reject) => {
    let id = 'messagebox_' + seed++;
    let Com = Vue.extend(Main);
    let instance = new Com({
        propsData: {
          message,
          content,
          props
        },
        data() {
          return {
            dialogVisible: true,
            id: ''
          }
        },
        methods: {
          handleCancel() {
            reject();
            this.dialogVisible = false;
          },
          handleConfirm() {
              resolve();
              this.dialogVisible = false;
          }
        }
    });
    instance.id = id;
    instance.$mount();
    document.body.appendChild(instance.$el);
  });
}

export {
  msgbox
}

export default {
  install() {
    Vue.prototype.$confirm = (message: string = '', content: string = '', props: Props) => {
      return msgbox(message, content, { method: 'confirm'});
    };
    Vue.prototype.$alert = (message: string = '', content: string = '', props: Props) => {
      return msgbox(message, content, {method: 'alert'});
    };
  }
}

