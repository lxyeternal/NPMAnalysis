import Vue from 'vue';
import Main from './main.vue';

let seed = 0;
const msgbox = (props) => {
  return new Promise((resolve, reject) => {
    let id = 'messagebox_' + seed++;
    let Com = Vue.extend(Main);
    let instance = new Com({
        propsData: props,
        methods: {
          handleCancel() {
            reject();
            this.dialogVisible = false;
          },
          handleConfirm() {
              resolve();
              this.dialogVisible = false;
          }
        }
    });
    instance.id = id;
    instance.$mount();
    document.body.appendChild(instance.$el);
  });
}

export {
  msgbox
}

export default {
  install() {
    Vue.prototype.$confirm = (props) => {
      return new Promise((resolve, reject) => {
          let id = 'messagebox_' + seed++;
          let Com = Vue.extend(Main);
          let instance = new Com({
              propsData: props,
              methods: {
                  handleCancel() {
                      reject();
                      this.dialogVisible = false;
                  },
                  handleConfirm() {
                      resolve();
                      this.dialogVisible = false;
                  }
              }
          });
          instance.id = id;
          instance.$mount();
          document.body.appendChild(instance.$el);
      })
    };
    Vue.prototype.$alert = (props) => {
        return new Promise((resolve, reject) => {
            let id = 'messagebox_' + seed++;
            let Com = Vue.extend(Main);
            let instance = new Com({
                propsData: {
                    ...props,
                    showCancelButton: false,
                    method: 'alert'
                },
                methods: {
                    handleCancel() {
                        reject();
                        this.dialogVisible = false;
                    },
                    handleConfirm() {
                        resolve();
                        this.dialogVisible = false;
                    }
                }
            });
            instance.id = id;
            instance.$mount();
            document.body.appendChild(instance.$el);
        }).catch((e) => {});
    };
  }
}

