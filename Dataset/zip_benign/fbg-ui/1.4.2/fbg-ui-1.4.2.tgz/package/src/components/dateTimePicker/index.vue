<template>
  <date-picker v-bind="$attrs" v-on="$listeners" type="datetimerange"  />
</template>
<script>
import DatePicker from '../datePicker';

export default {
  components: {
    DatePicker
  }
}
</script>