'use strict';
const production = require('./production.js');
const development = require('./development.js');
if (process.env.NODE_ENV === 'development') {
    module.exports = development;
} else {
    module.exports = production;
}
