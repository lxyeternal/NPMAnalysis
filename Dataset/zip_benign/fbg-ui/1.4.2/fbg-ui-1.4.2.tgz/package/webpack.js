const path = require('path');
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const webpack = require('webpack');

module.exports = {
  devtool: 'cheap-module-eval-source-map',
  entry: {
    index: './src/build.js',
  },
  output: {
      filename: 'fbgui.min.js',
      path: path.resolve(__dirname, 'build')
  },
  module: {

    rules: [
      {
        test: /\.(sa|sc|c)ss$/,
        use: ExtractTextPlugin.extract({
          fallback: "style-loader",
          use: [
            'vue-style-loader',
            'css-loader',
            'sass-loader'
          ]
        })
      },
      {
        test: /\.vue$/,
        use: ['vue-loader'],
        exclude: /node_modules/
      },
      {
        test: /\.(jpg|png|svg|gif)$/,
        use: [
          'file-loader'
        ]
      },
      {
        test: /\.(woff|woff2|eot|ttf|otf)/,
        use: [
            'file-loader'
        ]
      }
    ]
  },
  plugins: [
    new ExtractTextPlugin('style/index.css')
  ]
}