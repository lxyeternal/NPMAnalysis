'use strict';
const path = require('path');

function resolve(dir) {
    return path.join(__dirname, dir);
}


// All configuration item explanations can be find in https://cli.vuejs.org/config/
module.exports = {
    /**
     * You will need to set publicPath if you plan to deploy your site under a sub path,
     * for example GitHub Pages. If you plan to deploy your site to https://foo.github.io/bar/,
     * then publicPath should be set to "/bar/".
     * In most cases please use '/' !!!
     * Detail: https://cli.vuejs.org/config/#publicpath
     */
    pages: {
      index: {
        entry: './src/build.js',
        chunks: ['index']
      }
    },
    publicPath: '/',
    outputDir: 'dist',
    assetsDir: 'static',
    productionSourceMap: false,
    css: {
        loaderOptions: {
            sass: {
                prependData: `@import "~@/demo/styles/global.scss";`
            }
        }
    },
    chainWebpack(config) {

        // set preserveWhitespace
        config.module
            .rule('vue')
            .use('vue-loader')
            .loader('vue-loader')
            .tap(options => {
                options.compilerOptions.preserveWhitespace = true;
                return options;
            })
            .end();
    }
};