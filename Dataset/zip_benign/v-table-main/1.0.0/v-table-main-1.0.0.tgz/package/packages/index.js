// 导入单个组件
import TableMain from './TableMain/index'

export default TableMain