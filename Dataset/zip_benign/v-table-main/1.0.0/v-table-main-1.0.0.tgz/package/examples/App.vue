<template>
    <div id="app">
        <div class="editor-main">
            <div class="editor-view">
                <TableMain ref="table" :columnItems="columnItems" :api="api" :listQuery="listQuery" border></TableMain>
            </div>
            <div class="editor-config">
                <div class="label">filterSchema</div>
                <editor v-model="content" @init="editorInit" lang="json" theme="github" width="1190" height="300"></editor>
            </div>
        </div>
        
    </div>
</template>

<script>
import TableMain from '../packages/TableMain'

export default {
    name: 'App',
    components: {editor: require('vue2-ace-editor'),TableMain},
    data() {
        return {
            listQuery: {},
            api: ()=>{return Promise.resolve({result:{data:[
                {"cloudType":"aliyun","cpus":1,"eniQuantity":1,"flavorId":"1272833273558597632","flavorName":"ecs.t1.xsmall","gpus":0,"memorySize":0.5,"providerId":""},{"cloudType":"aliyun","cpus":1,"eniQuantity":2,"flavorId":"1272833670587219968","flavorName":"ecs.t5-lc2m1.nano","gpus":0,"memorySize":0.5,"providerId":""},{"cloudType":"aliyun","cpus":1,"eniQuantity":1,"flavorId":"1272833144202067968","flavorName":"ecs.n1.tiny","gpus":0,"memorySize":1,"providerId":""},{"cloudType":"aliyun","cpus":1,"eniQuantity":2,"flavorId":"1272834835144114176","flavorName":"ecs.s6-c1m1.small","gpus":0,"memorySize":1,"providerId":""},{"cloudType":"aliyun","cpus":1,"eniQuantity":1,"flavorId":"1272833156709482496","flavorName":"ecs.t1.small","gpus":0,"memorySize":1,"providerId":""},{"cloudType":"aliyun","cpus":1,"eniQuantity":2,"flavorId":"1272833656284643328","flavorName":"ecs.t5-lc1m1.small","gpus":0,"memorySize":1,"providerId":""},{"cloudType":"aliyun","cpus":1,"eniQuantity":2,"flavorId":"1272833362138103808","flavorName":"ecs.xn4.small","gpus":0,"memorySize":1,"providerId":""},{"cloudType":"aliyun","cpus":1,"eniQuantity":1,"flavorId":"1272834596815372288","flavorName":"ecs.ht6c.small","gpus":0,"memorySize":2,"providerId":""},{"cloudType":"aliyun","cpus":1,"eniQuantity":1,"flavorId":"1272833148618670080","flavorName":"ecs.n1.small","gpus":0,"memorySize":2,"providerId":""},{"cloudType":"aliyun","cpus":1,"eniQuantity":2,"flavorId":"1272833365988474880","flavorName":"ecs.n4.small","gpus":0,"memorySize":2,"providerId":""}
            ],total: 80}})},
            content: 
`[
    { "prop": "flavorName", "label": "规格名称", "name": "规格名称","tooltip":true},
    { "prop": "cpus", "label": "CPU（核）", "name": "CPU（核）","tooltip":true},
    { "prop": "memorySize", "label": "内存（GB）", "name": "内存（GB）","tooltip":true},
    { "prop": "gpus", "label": "GPU（核）","name": "GPU（核）","tooltip":true},
    { "prop": "cloudType", "label": "云平台"}
]`,
        }
    },
    computed:{
        columnItems(){
            var result = [];
            try{
                result = JSON.parse(this.content)
            }catch(e){

            }
            return result
        },
    },
    created() {
    },
    methods: {
        search(){
            console.log(this.listQuery)
        },
        handleClose(){

        },
        editorInit: function () {
            require('brace/ext/language_tools') //language extension prerequsite...
            require('brace/mode/html')                
            require('brace/mode/javascript')    //language
            require('brace/mode/json')
            require('brace/theme/github')
            require('brace/snippets/javascript') //snippet
        }
    }
}
</script>

<style lang="scss" scoped>
.editor-main{
    width: 1200px;
    margin: 20px auto;
    overflow: hidden;

    .editor-view{
        width: 100%;
        height: 300px;
        overflow: auto;
        border: 1px solid #eee;
        padding: 20px;
        box-sizing: border-box;
    }
    .editor-config{
        overflow: auto;
        border: 1px solid #eee;
    }
}
    .editor-control{
        text-align: center;
    }
</style>
