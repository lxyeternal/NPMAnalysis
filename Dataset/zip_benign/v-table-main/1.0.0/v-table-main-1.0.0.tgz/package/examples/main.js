import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false
// import {Textarea} from '../packages/index'
// Vue.use(Textarea)
import 'element-ui/lib/theme-chalk/index.css';
import ElementUi from 'element-ui'
Vue.use(ElementUi)
new Vue({
  render: h => h(App),
}).$mount('#app')
