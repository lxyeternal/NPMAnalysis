'use strict';
// var DataV = require('../line-with-point');
var DataV = require('dchart-line-with-point');
// var _ = require('../../../util');
var _ = require('dchart-core/util');
var d3 = require('d3');
var animationController = _.animationController;

function LineWithPointArea(container, options) {
  var opt = {
    margin: {right: 20, left: 10, top: 10, bottom: 10, containLabel: true},
    xaxis: {
      type: 'category',
      padding: 0.2,
      dy: 10,
    },
    yaxis: {},
    series: [{color: null, area: {frameColor: null, frameColorWidth: null, color: {type: 'double', from: '#fff', to: '#fff'}, hide: null}}]
  };
  opt = _.deepMerge(opt, options);
  DataV.call(this, container, opt);
}

LineWithPointArea = DataV.extend(LineWithPointArea, {
  beforeRender: function () {
    DataV.prototype.beforeRender.call(this);
    var self = this;
    var opt  = this.options;

    this.dealColor(opt, 'areaColor');
    opt.series && opt.series.length && opt.series.forEach(function (serie, i) {
      serie.area && self.dealColor(opt, 'series[' + i + '].area.color');
    });
  },
  afterRender: function () {
    var opt = this.options;
    var data = this.data();
    var xAxis = this.getComs('axis', 'xaxis');
    var x = xAxis.getX();
    var yAxis = this.getComs('axis', 'yaxis');
    var y = yAxis.getX();
    var xkey = opt.xaxis.key;
    var ykey = opt.yaxis.key;
    var self = this;
    var series = opt.isFirst ? this.svg.insert('g', '.series')
      .attr({class: 'area-g series', transform: this.svg.select('.series:not(.area-g)').attr('transform')}) :
      this.svg.select('.area-g').attr('transform', this.svg.select('.series:not(.area-g)').attr('transform'));

    var len = _.maxBy(data, function (n) {
      return n[ykey].length;
    })[ykey].length;

    var updateSeriesAttr = function (d, i, seriesIndex) {
      var that = this;
      var area = d3.svg
        .area().x(function (d) {
          if (opt.xaxis.type === 'time' && typeof d[xkey] === 'string') {
            return x(d3.time.format(xAxis.options.format).parse(d[xkey])) + (x.rangeBand ?  x.rangeBand() / 2 : 0);
          }
          return x(d[xkey]) +
            (x.rangeBand ?  x.rangeBand() / 2 : 0);
        })
        .y0(function (d) {
          return y(yAxis.getMin());
        })
        .y1(function (d) {
          return y(_.isNumber(d[ykey]) ? d[ykey] : yAxis.getMin());
        });
      // if (opt.interpolate) {
      area.interpolate(opt.series[seriesIndex] && opt.series[seriesIndex].interpolate || opt.interpolate || '');
      // }

      // clipPath 动画
      that.attr('clip-path', 'url(#' + self.clipPathId + ')');
     
      var animationHandler = ({duration, ease}) => {
        that.transition()
          .duration(opt.isFirst || !opt.animationUpdateFromPrevious ? 0 : duration)
          .ease(ease)
          .attr('d', area);
      }

      var notAnimationHandler = () => that.attr('d', area);

      animationController({animationHandler: animationHandler, notAnimationHandler, options: opt})

      var cfg = opt.series[seriesIndex] && opt.series[seriesIndex].area || opt.area;
      if (cfg && _.isObject(cfg)) {
        that.style({
          'fill': function () {
            return cfg.color && cfg.color.res;
          },
          'stroke': function () {
            return cfg.frameColor;
          },
          'stroke-width': function () {
            return cfg.frameColorWidth;
          },
          'display': cfg.hide && 'none' || 'block',
          'pointer-events': 'none'
        });
      }
    };

    series.datum(data);
    series.each(function (d, index) {
      var that = d3.select(this);
      for (var i = 0; i < len; i++) {
        var lineData = self.calLineData(d, i);
        var area = that.select('.serie' + (i + 1));
        var node = area[0][0] && area || that.append('path').attr('class', 'serie serie' + (i + 1)).style('stroke', 'none');
        node = node.datum(lineData);
        node && updateSeriesAttr.call(node, lineData, index, i);
      }
    });
    series.selectAll('.serie.serie' + len + ' ~ .serie').remove();

    DataV.prototype.afterRender.call(this);
  },
  updateAfterRender: function () {
    LineWithPointArea.prototype.afterRender.call(this);
  }
});

module.exports = LineWithPointArea;
