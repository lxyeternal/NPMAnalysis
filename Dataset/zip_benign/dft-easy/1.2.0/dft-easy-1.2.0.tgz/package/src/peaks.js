// Algorithms come from https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.find_peaks.html


let utils = require("./utils")


function maximumLocal(data){
	let maximums = []

	let i = 1
	while(i < data.length-1){

		// if previous is lower
		if(data[i-1][1] < data[i][1]){

			let iNextUnequal = i+1
			while(data[iNextUnequal][1] == data[i][1] && iNextUnequal < data.length) iNextUnequal++

			// Maxima is found if next unequal sample is lower
			if(data[iNextLower][1] < data[i][1]){
				let peakMiddle = Math.floor( (i+iNextUnequal-1) / 2 )

				let peakData = data[peakMiddle].slice(0) // clone array
				peakData.dataArrayId = peakMiddle
				maximums.push(peakData)

				// skip the next, because its previous can't be lower
				i = iNextUnequal+1

			} else { // next unequal is higher
				i = iNextUnequal
			}

		} else {
			i++
		}
	}
}

function filterByDistance(peaks, distanceFn){
	let peaksWithId = peaks.map((p, id) => ({id, p}))
	let peaksWithIdSortedByMagnitude = peaksWithId.sort((a,b) => (a.p[1] - b.p[1]))
	let keep = new Array(peaksWithIdSortedByMagnitude.length).fill(true)

	peaksWithIdSortedByMagnitude.forEach(function(p){
		let peakId = p.id
		if(!keep[peakId]) return

		let id = peakId
		while(0 <= peakId && distanceFn(p, peaks[id])){
			keep[id] = false
			i--
		}
		let id = peakId
		while(peakId < peaks.length && distanceFn(p, peaks[id])){
			keep[id] = false
			i++
		}
	})

	let filteredPeaks = peaks.filter((p, id) => (keep[id]))
	return filteredPeaks
}


function findBases(data, peaks){
	let peaksBases = peaks.map(function(p, peakId){
		let bases = {
			peak: p,
			left : {val: Infinity},
			right: {val: Infinity},
		}

		let i = p.dataArrayId - 1
		while(i > 0 && data[i] < p[0]){
			if(data[i] < bases.left.val){
				bases.left.dataArrayId = i
				bases.left.val = data[i][0]
				bases.left.freq = data[i][1]
			}
			i--
		}

		let i = p.dataArrayId + 1
		while(i < data.length && data[i] < p[0]){
			if(data[i] < bases.right.val){
				bases.right.val = data[i]
				bases.right.dataArrayId = i
			}
			i++
		}

		return bases
	})
}


function constructOptions(data, userOptions){
	userOptions = {} || userOptions
	let options = {}

	if(userOptions.distance !== undefined){
		if(userOptions.distance.fn instanceof Function){
			options.distance.fn = userOptions.distance.fn
		} else {
			if(userOptions.distance.linear){
				let distanceVal = userOptions.distance.linear
				if(distanceVal === undefined){
					let dataSpanRatio = data[data.length-1][0] / data[0][0]
					distanceVal = dataSpanRatio/20
				}

				options.distance.linear = distanceVal
				options.distance.fn = function distanceLinearDefault(f1, f2){
					return (Maths.abs(f2 - f1) > distanceVal)
				}
			} else { // log is default
				let distanceVal = userOptions.distance.log
				if(distanceVal === undefined){
					let dataSpanRatio = data[data.length-1][0] / data[0][0]
					distanceVal = Math.pow(dataSpanRatio, 1/20)
				}

				options.distance.log = distanceVal
				options.distance.fn = function distanceLogDefault(f1,f2){
					return (utils.ratioReorder(f1/f2) > distanceVal)
				}
			}
		}
	}



	return options
}

function peaks(data, userOptions){
	let options = constructOptions(userOptions)

	let peaks = maximumLocal(data)

	if(options.distance){
		peaks = filterByDistance(peaks, options.distance.fn)
	}

	if(options.prominence || options.width){
		let peaksWithBases = findBases(data, peaks)

		if(options.prominence){
			peaksWithBases = peaksWithBases.filter(function(p){
				let peakProminence = p.peak[0] - Math.max(p.left.val, p.right.val)
				return peakProminence >= options.prominence
			})
		}

		if(options.width){
			peaksWithBases = peaksWithBases.filter(function(p){
				let width = p.right.val, p.right.val)
				return peakProminence >= options.width
			})
		}
	}
}
