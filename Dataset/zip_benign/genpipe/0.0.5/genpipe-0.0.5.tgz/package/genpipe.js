"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __await = (this && this.__await) || function (v) { return this instanceof __await ? (this.v = v, this) : new __await(v); }
var __asyncDelegator = (this && this.__asyncDelegator) || function (o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: false } : f ? f(v) : v; } : f; }
};
var __asyncGenerator = (this && this.__asyncGenerator) || function (thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.H = exports.F = exports.delay = exports.concurrentInOrder = exports.concurrent = exports.reduce = exports.filterAsync = exports.filter = exports.forEachAsync = exports.forEach = exports.mapConcurrentInOrder = exports.mapConcurrent = exports.mapAsync = exports.map = exports.batch = exports.range = exports.toAsyncGen = exports.toGen = exports.AsyncPipeline = exports.Pipeline = void 0;
/**
 * Encapsulates an iterable and allows chaining of transformations.
 */
class Pipeline {
    constructor(iter) {
        /**
         * Alias for `transform`.
         */
        this.tf = this.transform;
        this.iter = iter;
    }
    /**
     * Transform the pipeline using the given function, and returns a new pipeline.
     * The function should accept an iterable and should return a generator.
     * The pipeline's backing generator will be passed to the function, and the returned generator
     * will be used to create the new pipeline that is returned.
     *
     * Example:
     * ```
     * const x = new Pipeline(range(0, 40))
     *    .transform(F.filter((i) => i % 3 == 0))
     *    .transform(F.map((i) => i * 2))
     * ```
     */
    transform(func) {
        return new Pipeline(func(this.iter));
    }
    /**
     * Convenience method to convert the iterable to an array.
     */
    eval() {
        return [...this.iter];
    }
    /**
     * Convenience method to convert the pipeline to an async pipeline.
     */
    toAsync() {
        return AsyncPipeline.fromSync(this.iter);
    }
    /**
     * Convenience method to convert the pipeline to a generator.
     */
    toGen() {
        return this.iter;
    }
}
exports.Pipeline = Pipeline;
class AsyncPipeline {
    constructor(iter) {
        /**
         * Alias for `transform`.
         */
        this.tf = this.transform;
        this.iter = toAsyncGen(iter);
    }
    /**
     * Transform the pipeline using the given function, and returns a new pipeline.
     * The function should accept an async iterable and should return an async generator.
     * The pipeline's backing async generator will be passed to the function, and the returned
     * async generator will be used to create the new pipeline that is returned.
     *
     * Example:
     * ```
     * const x = new AsyncPipeline(range(0, 40))
     *   .transform(F.filterAsync((i) => i % 3 == 0))
     *   .transform(F.mapAsync((i) => i * 2))
     * ```
     */
    transform(func) {
        return new AsyncPipeline(func(this.iter));
    }
    /**
     * Convenience method to convert the async pipeline to an array.
     */
    eval() {
        var _a, e_1, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            const results = [];
            try {
                for (var _d = true, _e = __asyncValues(this.iter), _f; _f = yield _e.next(), _a = _f.done, !_a; _d = true) {
                    _c = _f.value;
                    _d = false;
                    const x = _c;
                    results.push(x);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (!_d && !_a && (_b = _e.return)) yield _b.call(_e);
                }
                finally { if (e_1) throw e_1.error; }
            }
            return results;
        });
    }
    /**
     * Convenience method to create an async pipeline from a sync iterable.
     */
    static fromSync(iter) {
        return new AsyncPipeline(toAsyncGen(iter));
    }
    /**
     * Convenience method to convert the async pipeline to an async generator.
     */
    toAsyncGen() {
        return toAsyncGen(this.iter);
    }
}
exports.AsyncPipeline = AsyncPipeline;
/**
 * Convenience function to convert an iterable to a generator.
 */
function* toGen(iter) {
    for (const x of iter) {
        yield x;
    }
}
exports.toGen = toGen;
/**
 * Convenience function to convert an iterable or async iterable to an async generator.
 */
function toAsyncGen(iter) {
    return __asyncGenerator(this, arguments, function* toAsyncGen_1() {
        var _a, e_2, _b, _c;
        if (Symbol.iterator in iter) {
            yield __await(yield* __asyncDelegator(__asyncValues(toGen(iter))));
        }
        else if (Symbol.asyncIterator in iter) {
            try {
                for (var _d = true, iter_1 = __asyncValues(iter), iter_1_1; iter_1_1 = yield __await(iter_1.next()), _a = iter_1_1.done, !_a; _d = true) {
                    _c = iter_1_1.value;
                    _d = false;
                    const x = _c;
                    yield yield __await(x);
                }
            }
            catch (e_2_1) { e_2 = { error: e_2_1 }; }
            finally {
                try {
                    if (!_d && !_a && (_b = iter_1.return)) yield __await(_b.call(iter_1));
                }
                finally { if (e_2) throw e_2.error; }
            }
        }
        else {
            throw new Error(`Not an iterable: ${iter}`);
        }
    });
}
exports.toAsyncGen = toAsyncGen;
/**
 * Generator that yields the numbers from start to stop (exclusive)
 */
function* range(start, stop) {
    for (let i = start; i < stop; i++) {
        yield i;
    }
}
exports.range = range;
/**
 * Generator that yields the elements of the given iterable in batches of the given size.
 * No batches are yielded for empty iterables, and zero or negative batch sizes.
 */
function* batch(iter, batchSize) {
    const iterator = iter[Symbol.iterator]();
    while (true) {
        const nextBatch = [];
        while (nextBatch.length < batchSize) {
            const res = iterator.next();
            if (res.done) {
                break;
            }
            nextBatch.push(res.value);
        }
        if (nextBatch.length == 0) {
            break;
        }
        yield nextBatch;
    }
}
exports.batch = batch;
/**
 * `Array.map` for generators.
 *
 * Generator that applies the given function to each element of the given iterable
 * and yields the result.
 */
function* map(iter, func) {
    for (const x of iter) {
        yield func(x);
    }
}
exports.map = map;
/**
 * `Array.map` for async generators.
 *
 * Generator that applies the given function to each element of the given iterable,
 * and awaits the result if it is a promise, and yields the result.
 */
function mapAsync(iter, func) {
    return __asyncGenerator(this, arguments, function* mapAsync_1() {
        var _a, e_3, _b, _c;
        try {
            for (var _d = true, iter_2 = __asyncValues(iter), iter_2_1; iter_2_1 = yield __await(iter_2.next()), _a = iter_2_1.done, !_a; _d = true) {
                _c = iter_2_1.value;
                _d = false;
                const x = _c;
                yield yield __await(yield __await(func(x)));
            }
        }
        catch (e_3_1) { e_3 = { error: e_3_1 }; }
        finally {
            try {
                if (!_d && !_a && (_b = iter_2.return)) yield __await(_b.call(iter_2));
            }
            finally { if (e_3) throw e_3.error; }
        }
    });
}
exports.mapAsync = mapAsync;
/**
 * Generator that applies the given async function to each element of the given iterable
 * concurrently. The results are yielded in the order they complete, which may not be the
 * same order as the order of the tasks in the input iterable.
 */
function mapConcurrent(iter, concurrencyLimit, func) {
    return new AsyncPipeline(iter)
        .tf(exports.F.mapAsync((x) => () => func(x)))
        .tf(exports.F.concurrent(concurrencyLimit))
        .toAsyncGen();
}
exports.mapConcurrent = mapConcurrent;
/**
 * Generator that applies the given async function to each element of the given iterable
 * concurrently. The results are yielded in the same order as the tasks in the input iterable.
 */
function mapConcurrentInOrder(iter, concurrencyLimit, func) {
    return new AsyncPipeline(iter)
        .tf(exports.F.mapAsync((x) => () => func(x)))
        .tf(exports.F.concurrentInOrder(concurrencyLimit))
        .toAsyncGen();
}
exports.mapConcurrentInOrder = mapConcurrentInOrder;
/**
 * `Array.forEach` for generators.
 *
 * Generator that applies the given function to each element of the given iterable
 * and yields the element.
 */
function* forEach(iter, func) {
    for (const x of iter) {
        func(x);
        yield x;
    }
}
exports.forEach = forEach;
/**
 * `Array.forEach` for async generators.
 *
 * Generator that applies the given function to each element of the given iterable,
 * and awaits the result if it is a promise, and yields the element.
 */
function forEachAsync(iter, func) {
    return __asyncGenerator(this, arguments, function* forEachAsync_1() {
        var _a, e_4, _b, _c;
        try {
            for (var _d = true, iter_3 = __asyncValues(iter), iter_3_1; iter_3_1 = yield __await(iter_3.next()), _a = iter_3_1.done, !_a; _d = true) {
                _c = iter_3_1.value;
                _d = false;
                const x = _c;
                yield __await(func(x));
                yield yield __await(x);
            }
        }
        catch (e_4_1) { e_4 = { error: e_4_1 }; }
        finally {
            try {
                if (!_d && !_a && (_b = iter_3.return)) yield __await(_b.call(iter_3));
            }
            finally { if (e_4) throw e_4.error; }
        }
    });
}
exports.forEachAsync = forEachAsync;
/**
 * `Array.filter` for generators.
 *
 * Generator that yields the elements of the given iterable that satisfy the given predicate.
 */
function* filter(iter, func) {
    for (const x of iter) {
        if (func(x)) {
            yield x;
        }
    }
}
exports.filter = filter;
/**
 * `Array.filter` for async generators.
 *
 * Generator that yields the elements of the given iterable that satisfy the given predicate.
 * The predicate can return a promise, in which case it will be awaited.
 */
function filterAsync(iter, func) {
    return __asyncGenerator(this, arguments, function* filterAsync_1() {
        var _a, e_5, _b, _c;
        try {
            for (var _d = true, iter_4 = __asyncValues(iter), iter_4_1; iter_4_1 = yield __await(iter_4.next()), _a = iter_4_1.done, !_a; _d = true) {
                _c = iter_4_1.value;
                _d = false;
                const x = _c;
                if (yield __await(func(x))) {
                    yield yield __await(x);
                }
            }
        }
        catch (e_5_1) { e_5 = { error: e_5_1 }; }
        finally {
            try {
                if (!_d && !_a && (_b = iter_4.return)) yield __await(_b.call(iter_4));
            }
            finally { if (e_5) throw e_5.error; }
        }
    });
}
exports.filterAsync = filterAsync;
/**
 * `Array.reduce` for generators.
 *
 * Generator that applies the given reducer function to each element of the given iterable
 * and yields the result.
 */
function reduce(iter, func, initialValue) {
    let acc = initialValue;
    for (const x of iter) {
        acc = func(acc, x);
    }
    return acc;
}
exports.reduce = reduce;
/**
 * Asynchronously execute an iterable of tasks with a given concurrency limit, yielding results as
 * they complete.
 *
 * The tasks are functions that start an asynchronous operation and return a promise. Tasks will be
 * started up to the concurrency limit, and as soon as one completes, the result is yielded and
 * another task is started.
 *
 * If any of the tasks throw an error, the generator will throw that error immediately without
 * waiting for the other tasks.
 */
function concurrent(tasks, limit) {
    return __asyncGenerator(this, arguments, function* concurrent_1() {
        const executing = new Set();
        function scheduleTask(task) {
            const promise = task().finally(() => {
                executing.delete(promise);
            });
            executing.add(promise);
        }
        if (Symbol.iterator in tasks) {
            tasks = toAsyncGen(tasks);
        }
        const tasksIter = tasks[Symbol.asyncIterator]();
        while (true) {
            const nextResult = yield __await(tasksIter.next());
            if (!nextResult.done) {
                while (executing.size >= limit) {
                    yield yield __await(yield __await(Promise.race(executing)));
                }
                scheduleTask(nextResult.value);
            }
            else if (executing.size > 0) {
                yield yield __await(yield __await(Promise.race(executing)));
            }
            else {
                break;
            }
        }
    });
}
exports.concurrent = concurrent;
/**
 * A queue that yields its items in consecutive order.
 *
 * Items are added to the queue with an index. The queue will yield items only in consecutive order
 * of their index. If the item at the next index is not present, the queue will throw an error.
 *
 * This is useful for maintaining the order of items that are processed concurrently.
 */
class ConsecutiveQueue {
    constructor() {
        this.currIdx = 0;
        this.idxToItem = new Map();
    }
    add(idx, item) {
        this.idxToItem.set(idx, item);
    }
    hasNext() {
        return this.idxToItem.has(this.currIdx);
    }
    remove() {
        if (!this.hasNext()) {
            throw new Error(`No item at current index ${this.currIdx}`);
        }
        const item = this.idxToItem.get(this.currIdx);
        this.idxToItem.delete(this.currIdx);
        this.currIdx++;
        return item;
    }
    *removeConsecutive() {
        while (this.hasNext()) {
            yield this.remove();
        }
    }
}
/**
 * Asynchronously execute an iterable of tasks with a given concurrency limit, yielding results
 * in the same order as the tasks.
 *
 * The tasks are functions that start an asynchronous operation and return a promise. Tasks will be
 * started up to the concurrency limit. As tasks are completed, the consecutive results available
 * are yielded, in the same order as the tasks. If taks complete out of order, the results will be
 * buffered in memory until the preceding results are available.
 *
 * If any of the tasks throw an error, the generator will throw that error immediately without
 * waiting for the other tasks.
 */
function concurrentInOrder(tasks, limit) {
    return __asyncGenerator(this, arguments, function* concurrentInOrder_1() {
        const executing = new Set();
        const results = new ConsecutiveQueue();
        function scheduleTask(idx, task) {
            const promise = task()
                .then((result) => {
                results.add(idx, result);
                return result;
            })
                .finally(() => {
                executing.delete(promise);
            });
            executing.add(promise);
        }
        if (Symbol.iterator in tasks) {
            tasks = toAsyncGen(tasks);
        }
        const tasksIter = tasks[Symbol.asyncIterator]();
        let currIdx = 0;
        while (true) {
            const nextResult = yield __await(tasksIter.next());
            if (!nextResult.done) {
                while (executing.size >= limit) {
                    yield __await(Promise.race(executing));
                    yield __await(yield* __asyncDelegator(__asyncValues(results.removeConsecutive())));
                }
                scheduleTask(currIdx++, nextResult.value);
            }
            else if (executing.size > 0) {
                yield __await(Promise.race(executing));
                yield __await(yield* __asyncDelegator(__asyncValues(results.removeConsecutive())));
            }
            else {
                break;
            }
        }
    });
}
exports.concurrentInOrder = concurrentInOrder;
function partial(func) {
    return (...a) => (t) => func(t, ...a);
}
function delay(ms) {
    return __awaiter(this, void 0, void 0, function* () {
        return yield new Promise((resolve) => setTimeout(resolve, ms));
    });
}
exports.delay = delay;
/**
 * Partially applied versions of the functions in this module.
 * Useful for chaining transformations.
 */
exports.F = {
    batch: partial(batch),
    concurrent: partial(concurrent),
    concurrentInOrder: partial(concurrentInOrder),
    filter: partial(filter),
    filterAsync: partial(filterAsync),
    forEach: partial(forEach),
    forEachAsync: partial(forEachAsync),
    map: partial(map),
    mapAsync: partial(mapAsync),
    mapConcurrent: partial(mapConcurrent),
    mapConcurrentInOrder: partial(mapConcurrentInOrder),
    reduce: partial(reduce),
};
exports.H = {
    logEach: exports.F.forEach(console.log),
    logEachAsync: exports.F.forEachAsync(console.log),
};
