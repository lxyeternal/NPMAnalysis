import { IconDefinition, IconName, IconPack, IconPrefix } from '@fortawesome/fontawesome-svg-core';
export declare class FaIconLibrary {
    private definitions;
    addIcons(...icons: IconDefinition[]): void;
    addIconPacks(...packs: IconPack[]): void;
    getIconDefinition(prefix: IconPrefix, name: IconName): IconDefinition | null;
}
