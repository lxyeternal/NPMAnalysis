"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.svgCoreVersion = '^1.2.21';
exports.angularFontawesomeVersion = '~0.5.0';
exports.iconPackVersion = '^5.10.2';
//# sourceMappingURL=versions.js.map