export declare const svgCoreVersion = "^1.2.21";
export declare const angularFontawesomeVersion = "~0.5.0";
export declare const iconPackVersion = "^5.10.2";
