export declare class FontAwesomeModule {
}
