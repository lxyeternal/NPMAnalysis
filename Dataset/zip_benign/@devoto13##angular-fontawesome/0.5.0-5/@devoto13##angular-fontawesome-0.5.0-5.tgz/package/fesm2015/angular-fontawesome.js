import { Injectable, ɵɵdefineInjectable, Directive, Input, Component, Optional, HostBinding, Renderer2, ElementRef, Inject, forwardRef, NgModule, ɵɵinject } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { findIconDefinition, parse, icon, counter, text } from '@fortawesome/fontawesome-svg-core';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class FaConfig {
    constructor() {
        /**
         * Default prefix to use, when one is not provided with the icon name.
         *
         * \@default 'fas'
         */
        this.defaultPrefix = 'fas';
        /**
         * Whether components should lookup icon definitions in the global icon
         * library (the one available from
         * `import { library } from '\@fortawesome/fontawesome-svg-core')`.
         *
         * See https://github.com/FortAwesome/angular-fontawesome/blob/master/docs/usage/icon-library.md
         * for detailed description of library modes.
         *
         * - 'unset' - Components should lookup icon definitions in the global library
         * and emit warning if they find a definition there. This option is a default
         * to assist existing applications with a migration. Applications are expected
         * to switch to using {\@link FaIconLibrary}.
         * - true - Components should lookup icon definitions in the global library.
         * Note that global icon library is deprecated and support for it will be
         * removed. This option can be used to temporarily suppress warnings.
         * - false - Components should not lookup icon definitions in the global
         * library. Library will throw an error if missing icon is found in the global
         * library.
         *
         * @deprecated This option is deprecated since 0.5.0. In 0.6.0 default will
         * be changed to false. In 0.7.0 the option will be removed together with the
         * support for the global icon library.
         *
         * \@default 'unset'
         */
        this.globalLibrary = 'unset';
    }
}
FaConfig.decorators = [
    { type: Injectable, args: [{ providedIn: 'root' },] }
];
/** @nocollapse */ FaConfig.ngInjectableDef = ɵɵdefineInjectable({ factory: function FaConfig_Factory() { return new FaConfig(); }, token: FaConfig, providedIn: "root" });
if (false) {
    /**
     * Default prefix to use, when one is not provided with the icon name.
     *
     * \@default 'fas'
     * @type {?}
     */
    FaConfig.prototype.defaultPrefix;
    /**
     * Whether components should lookup icon definitions in the global icon
     * library (the one available from
     * `import { library } from '\@fortawesome/fontawesome-svg-core')`.
     *
     * See https://github.com/FortAwesome/angular-fontawesome/blob/master/docs/usage/icon-library.md
     * for detailed description of library modes.
     *
     * - 'unset' - Components should lookup icon definitions in the global library
     * and emit warning if they find a definition there. This option is a default
     * to assist existing applications with a migration. Applications are expected
     * to switch to using {\@link FaIconLibrary}.
     * - true - Components should lookup icon definitions in the global library.
     * Note that global icon library is deprecated and support for it will be
     * removed. This option can be used to temporarily suppress warnings.
     * - false - Components should not lookup icon definitions in the global
     * library. Library will throw an error if missing icon is found in the global
     * library.
     *
     * @deprecated This option is deprecated since 0.5.0. In 0.6.0 default will
     * be changed to false. In 0.7.0 the option will be removed together with the
     * support for the global icon library.
     *
     * \@default 'unset'
     * @type {?}
     */
    FaConfig.prototype.globalLibrary;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class FaIconLibrary {
    constructor() {
        this.definitions = {};
    }
    /**
     * @param {...?} icons
     * @return {?}
     */
    addIcons(...icons) {
        for (let i = 0; i < icons.length; i++) {
            /** @type {?} */
            const icon = icons[i];
            if (!(icon.prefix in this.definitions)) {
                this.definitions[icon.prefix] = {};
            }
            this.definitions[icon.prefix][icon.iconName] = icon;
        }
    }
    /**
     * @param {...?} packs
     * @return {?}
     */
    addIconPacks(...packs) {
        for (let i = 0; i < packs.length; i++) {
            /** @type {?} */
            const pack = packs[i];
            /** @type {?} */
            const icons = Object.keys(pack).map((/**
             * @param {?} key
             * @return {?}
             */
            (key) => pack[key]));
            this.addIcons(...icons);
        }
    }
    /**
     * @param {?} prefix
     * @param {?} name
     * @return {?}
     */
    getIconDefinition(prefix, name) {
        if (prefix in this.definitions && name in this.definitions[prefix]) {
            return this.definitions[prefix][name];
        }
        return null;
    }
}
FaIconLibrary.decorators = [
    { type: Injectable, args: [{ providedIn: 'root' },] }
];
/** @nocollapse */ FaIconLibrary.ngInjectableDef = ɵɵdefineInjectable({ factory: function FaIconLibrary_Factory() { return new FaIconLibrary(); }, token: FaIconLibrary, providedIn: "root" });
if (false) {
    /**
     * @type {?}
     * @private
     */
    FaIconLibrary.prototype.definitions;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const faWarnIfIconDefinitionMissing = (/**
 * @param {?} iconSpec
 * @return {?}
 */
(iconSpec) => {
    console.error(`FontAwesome: Could not find icon with iconName=${iconSpec.iconName} and prefix=${iconSpec.prefix}. ` +
        `This warning will become a hard error in 0.6.0.`);
});

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const faWarnIfIconSpecMissing = (/**
 * @return {?}
 */
() => {
    console.error('FontAwesome: Property `icon` is required for `fa-icon`/`fa-duotone-icon` components. ' +
        `This warning will become a hard error in 0.6.0.`);
});

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Fontawesome class list.
 * Returns classes array by props.
 * @type {?}
 */
const faClassList = (/**
 * @param {?} props
 * @return {?}
 */
(props) => {
    /** @type {?} */
    const classes = {
        'fa-spin': props.spin,
        'fa-pulse': props.pulse,
        'fa-fw': props.fixedWidth,
        'fa-border': props.border,
        'fa-li': props.listItem,
        'fa-inverse': props.inverse,
        'fa-layers-counter': props.counter,
        'fa-flip-horizontal': props.flip === 'horizontal' || props.flip === 'both',
        'fa-flip-vertical': props.flip === 'vertical' || props.flip === 'both',
        [`fa-${props.size}`]: props.size !== null,
        [`fa-rotate-${props.rotate}`]: props.rotate !== null,
        [`fa-pull-${props.pull}`]: props.pull !== null,
        [`fa-stack-${props.stackItemSize}`]: props.stackItemSize != null,
    };
    return Object.keys(classes)
        .map((/**
     * @param {?} key
     * @return {?}
     */
    key => (classes[key] ? key : null)))
        .filter((/**
     * @param {?} key
     * @return {?}
     */
    key => key));
});

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Returns if is IconLookup or not.
 * @type {?}
 */
const isIconLookup = (/**
 * @param {?} i
 * @return {?}
 */
(i) => {
    return ((/** @type {?} */ (i))).prefix !== undefined && ((/** @type {?} */ (i))).iconName !== undefined;
});

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Normalizing icon spec.
 * @type {?}
 */
const faNormalizeIconSpec = (/**
 * @param {?} iconSpec
 * @param {?} defaultPrefix
 * @return {?}
 */
(iconSpec, defaultPrefix) => {
    if (isIconLookup(iconSpec)) {
        return iconSpec;
    }
    if (Array.isArray(iconSpec) && ((/** @type {?} */ (iconSpec))).length === 2) {
        return { prefix: iconSpec[0], iconName: iconSpec[1] };
    }
    if (typeof iconSpec === 'string') {
        return { prefix: defaultPrefix, iconName: iconSpec };
    }
});

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class FaStackItemSizeDirective {
    constructor() {
        /**
         * Specify whether icon inside {\@link FaStackComponent} should be rendered in
         * regular size (1x) or as a larger icon (2x).
         */
        this.stackItemSize = '1x';
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if ('size' in changes) {
            throw new Error('fa-icon is not allowed to customize size when used inside fa-stack. ' +
                'Set size on the enclosing fa-stack instead: <fa-stack size="4x">...</fa-stack>.');
        }
    }
}
FaStackItemSizeDirective.decorators = [
    { type: Directive, args: [{
                selector: 'fa-icon[stackItemSize],fa-duotone-icon[stackItemSize]',
            },] }
];
FaStackItemSizeDirective.propDecorators = {
    stackItemSize: [{ type: Input }],
    size: [{ type: Input }]
};
if (false) {
    /**
     * Specify whether icon inside {\@link FaStackComponent} should be rendered in
     * regular size (1x) or as a larger icon (2x).
     * @type {?}
     */
    FaStackItemSizeDirective.prototype.stackItemSize;
    /**
     * \@internal
     * @type {?}
     */
    FaStackItemSizeDirective.prototype.size;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class FaIconComponent {
    /**
     * @param {?} sanitizer
     * @param {?} config
     * @param {?} iconLibrary
     * @param {?} stackItem
     */
    constructor(sanitizer, config, iconLibrary, stackItem) {
        this.sanitizer = sanitizer;
        this.config = config;
        this.iconLibrary = iconLibrary;
        this.stackItem = stackItem;
        this.classes = [];
    }
    /**
     * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `icon` property directly.
     * @return {?}
     */
    get iconProp() {
        return this.icon;
    }
    /**
     * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `icon` property directly.
     * @param {?} value
     * @return {?}
     */
    set iconProp(value) {
        this.icon = value;
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (this.icon == null) {
            return faWarnIfIconSpecMissing();
        }
        if (changes) {
            /** @type {?} */
            const iconDefinition = this.findIconDefinition(this.icon);
            if (iconDefinition != null) {
                /** @type {?} */
                const params = this.buildParams();
                this.renderIcon(iconDefinition, params);
            }
        }
    }
    /**
     * Programmatically trigger rendering of the icon.
     *
     * This method is useful, when creating {\@link FaIconComponent} dynamically or
     * changing its inputs programmatically as in these cases icon won't be
     * re-rendered automatically.
     * @return {?}
     */
    render() {
        this.ngOnChanges({});
    }
    /**
     * @protected
     * @param {?} i
     * @return {?}
     */
    findIconDefinition(i) {
        /** @type {?} */
        const lookup = faNormalizeIconSpec(i, this.config.defaultPrefix);
        if ('icon' in lookup) {
            return lookup;
        }
        /** @type {?} */
        const definition = this.iconLibrary.getIconDefinition(lookup.prefix, lookup.iconName);
        if (definition != null) {
            return definition;
        }
        /** @type {?} */
        const globalDefinition = findIconDefinition(lookup);
        if (globalDefinition != null) {
            /** @type {?} */
            const message = 'Global icon library is deprecated. ' +
                'Consult https://github.com/FortAwesome/angular-fontawesome/blob/master/UPGRADING.md ' +
                'for the migration instructions.';
            if (this.config.globalLibrary === 'unset') {
                console.error('FontAwesome: ' + message);
            }
            else if (!this.config.globalLibrary) {
                throw new Error(message);
            }
            return globalDefinition;
        }
        faWarnIfIconDefinitionMissing(lookup);
        return null;
    }
    /**
     * @protected
     * @return {?}
     */
    buildParams() {
        /** @type {?} */
        const classOpts = {
            flip: this.flip,
            spin: this.spin,
            pulse: this.pulse,
            border: this.border,
            inverse: this.inverse,
            listItem: this.listItem,
            size: this.size || null,
            pull: this.pull || null,
            rotate: this.rotate || null,
            fixedWidth: this.fixedWidth,
            stackItemSize: this.stackItem != null ? this.stackItem.stackItemSize : null,
        };
        /** @type {?} */
        const parsedTransform = typeof this.transform === 'string' ? parse.transform(this.transform) : this.transform;
        return {
            title: this.title,
            transform: parsedTransform,
            classes: [...faClassList(classOpts), ...this.classes],
            mask: this.mask != null ? this.findIconDefinition(this.mask) : null,
            styles: this.styles != null ? this.styles : {},
            symbol: this.symbol,
            attributes: {
                role: this.a11yRole
            }
        };
    }
    /**
     * @private
     * @param {?} definition
     * @param {?} params
     * @return {?}
     */
    renderIcon(definition, params) {
        /** @type {?} */
        const renderedIcon = icon(definition, params);
        this.renderedIconHTML = this.sanitizer.bypassSecurityTrustHtml(renderedIcon.html.join('\n'));
    }
}
FaIconComponent.decorators = [
    { type: Component, args: [{
                selector: 'fa-icon',
                template: ``,
                host: {
                    class: 'ng-fa-icon',
                    '[attr.title]': 'title',
                }
            }] }
];
/** @nocollapse */
FaIconComponent.ctorParameters = () => [
    { type: DomSanitizer },
    { type: FaConfig },
    { type: FaIconLibrary },
    { type: FaStackItemSizeDirective, decorators: [{ type: Optional }] }
];
FaIconComponent.propDecorators = {
    icon: [{ type: Input }],
    title: [{ type: Input }],
    spin: [{ type: Input }],
    pulse: [{ type: Input }],
    mask: [{ type: Input }],
    styles: [{ type: Input }],
    flip: [{ type: Input }],
    size: [{ type: Input }],
    pull: [{ type: Input }],
    border: [{ type: Input }],
    inverse: [{ type: Input }],
    symbol: [{ type: Input }],
    listItem: [{ type: Input }],
    rotate: [{ type: Input }],
    fixedWidth: [{ type: Input }],
    classes: [{ type: Input }],
    transform: [{ type: Input }],
    a11yRole: [{ type: Input }],
    renderedIconHTML: [{ type: HostBinding, args: ['innerHTML',] }]
};
if (false) {
    /** @type {?} */
    FaIconComponent.prototype.icon;
    /**
     * Specify a title for the icon.
     * This text will be displayed in a tooltip on hover and presented to the
     * screen readers.
     * @type {?}
     */
    FaIconComponent.prototype.title;
    /** @type {?} */
    FaIconComponent.prototype.spin;
    /** @type {?} */
    FaIconComponent.prototype.pulse;
    /** @type {?} */
    FaIconComponent.prototype.mask;
    /** @type {?} */
    FaIconComponent.prototype.styles;
    /** @type {?} */
    FaIconComponent.prototype.flip;
    /** @type {?} */
    FaIconComponent.prototype.size;
    /** @type {?} */
    FaIconComponent.prototype.pull;
    /** @type {?} */
    FaIconComponent.prototype.border;
    /** @type {?} */
    FaIconComponent.prototype.inverse;
    /** @type {?} */
    FaIconComponent.prototype.symbol;
    /**
     * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `fixedWidth` with your custom styles instead.
     * @type {?}
     */
    FaIconComponent.prototype.listItem;
    /** @type {?} */
    FaIconComponent.prototype.rotate;
    /** @type {?} */
    FaIconComponent.prototype.fixedWidth;
    /** @type {?} */
    FaIconComponent.prototype.classes;
    /** @type {?} */
    FaIconComponent.prototype.transform;
    /**
     * Specify the `role` attribute for the rendered <svg> element.
     *
     * \@default 'img'
     * @type {?}
     */
    FaIconComponent.prototype.a11yRole;
    /** @type {?} */
    FaIconComponent.prototype.renderedIconHTML;
    /**
     * @type {?}
     * @private
     */
    FaIconComponent.prototype.sanitizer;
    /**
     * @type {?}
     * @private
     */
    FaIconComponent.prototype.config;
    /**
     * @type {?}
     * @private
     */
    FaIconComponent.prototype.iconLibrary;
    /**
     * @type {?}
     * @private
     */
    FaIconComponent.prototype.stackItem;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class FaDuotoneIconComponent extends FaIconComponent {
    /**
     * @protected
     * @param {?} i
     * @return {?}
     */
    findIconDefinition(i) {
        /** @type {?} */
        const lookup = super.findIconDefinition(i);
        if (lookup != null && lookup.prefix !== 'fad') {
            throw new Error('The specified icon does not appear to be a Duotone icon. ' +
                'Check that you specified the correct style: ' +
                `<fa-duotone-icon [icon]="['fab', '${lookup.iconName}']"></fa-duotone-icon> ` +
                `or use: <fa-icon icon="${lookup.iconName}"></fa-icon> instead.`);
        }
        return lookup;
    }
    /**
     * @protected
     * @return {?}
     */
    buildParams() {
        /** @type {?} */
        const params = super.buildParams();
        if (this.swapOpacity === true || this.swapOpacity === 'true') {
            params.classes.push('fa-swap-opacity');
        }
        if (this.primaryOpacity != null) {
            params.styles['--fa-primary-opacity'] = this.primaryOpacity.toString();
        }
        if (this.secondaryOpacity != null) {
            params.styles['--fa-secondary-opacity'] = this.secondaryOpacity.toString();
        }
        if (this.primaryColor != null) {
            params.styles['--fa-primary-color'] = this.primaryColor;
        }
        if (this.secondaryColor != null) {
            params.styles['--fa-secondary-color'] = this.secondaryColor;
        }
        return params;
    }
}
FaDuotoneIconComponent.decorators = [
    { type: Component, args: [{
                selector: 'fa-duotone-icon',
                template: ``
            }] }
];
FaDuotoneIconComponent.propDecorators = {
    swapOpacity: [{ type: Input }],
    primaryOpacity: [{ type: Input }],
    secondaryOpacity: [{ type: Input }],
    primaryColor: [{ type: Input }],
    secondaryColor: [{ type: Input }]
};
if (false) {
    /**
     * Swap the default opacity of each duotone icon’s layers. This will make an
     * icon’s primary layer have the default opacity of 40% rather than its
     * secondary layer.
     *
     * \@default false
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.swapOpacity;
    /**
     * Customize the opacity of the primary icon layer.
     * Valid values are in range [0, 1.0].
     *
     * \@default 1.0
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.primaryOpacity;
    /**
     * Customize the opacity of the secondary icon layer.
     * Valid values are in range [0, 1.0].
     *
     * \@default 0.4
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.secondaryOpacity;
    /**
     * Customize the color of the primary icon layer.
     * Accepts any valid CSS color value.
     *
     * \@default CSS inherited color
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.primaryColor;
    /**
     * Customize the color of the secondary icon layer.
     * Accepts any valid CSS color value.
     *
     * \@default CSS inherited color
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.secondaryColor;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Fontawesome layers.
 */
class FaLayersComponent {
    /**
     * @param {?} renderer
     * @param {?} elementRef
     */
    constructor(renderer, elementRef) {
        this.renderer = renderer;
        this.elementRef = elementRef;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.renderer.addClass(this.elementRef.nativeElement, 'fa-layers');
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if ('size' in changes) {
            if (changes.size.currentValue != null) {
                this.renderer.addClass(this.elementRef.nativeElement, `fa-${changes.size.currentValue}`);
            }
            if (changes.size.previousValue != null) {
                this.renderer.removeClass(this.elementRef.nativeElement, `fa-${changes.size.previousValue}`);
            }
        }
    }
}
FaLayersComponent.decorators = [
    { type: Component, args: [{
                selector: 'fa-layers',
                template: `<ng-content select="fa-icon, fa-duotone-icon, fa-layers-text, fa-layers-counter"></ng-content>`
            }] }
];
/** @nocollapse */
FaLayersComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];
FaLayersComponent.propDecorators = {
    size: [{ type: Input }],
    fixedWidth: [{ type: Input }, { type: HostBinding, args: ['class.fa-fw',] }]
};
if (false) {
    /** @type {?} */
    FaLayersComponent.prototype.size;
    /** @type {?} */
    FaLayersComponent.prototype.fixedWidth;
    /**
     * @type {?}
     * @private
     */
    FaLayersComponent.prototype.renderer;
    /**
     * @type {?}
     * @private
     */
    FaLayersComponent.prototype.elementRef;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Warns if parent component not existing.
 * @type {?}
 */
const faWarnIfParentNotExist = (/**
 * @param {?} parent
 * @param {?} parentName
 * @param {?} childName
 * @return {?}
 */
(parent, parentName, childName) => {
    if (!parent) {
        console.error(`FontAwesome: ${childName} should be used as child of ${parentName} only.`);
    }
});

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @abstract
 */
class FaLayersTextBaseComponent {
    /**
     * @param {?} parent
     * @param {?} sanitizer
     */
    constructor(parent, sanitizer) {
        this.parent = parent;
        this.sanitizer = sanitizer;
        this.classes = [];
        faWarnIfParentNotExist(this.parent, 'FaLayersComponent', this.constructor.name);
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes) {
            this.updateParams();
            this.updateContent();
        }
    }
    /**
     * Updating content by params and content.
     * @private
     * @return {?}
     */
    updateContent() {
        this.renderedHTML = this.sanitizer.bypassSecurityTrustHtml(this.renderFontawesomeObject(this.content || '', this.params).html.join('\n'));
    }
}
FaLayersTextBaseComponent.decorators = [
    { type: Injectable }
];
/** @nocollapse */
FaLayersTextBaseComponent.ctorParameters = () => [
    { type: FaLayersComponent, decorators: [{ type: Inject, args: [forwardRef((/**
                     * @return {?}
                     */
                    () => FaLayersComponent)),] }, { type: Optional }] },
    { type: DomSanitizer }
];
FaLayersTextBaseComponent.propDecorators = {
    renderedHTML: [{ type: HostBinding, args: ['innerHTML',] }],
    content: [{ type: Input }],
    title: [{ type: Input }],
    styles: [{ type: Input }],
    classes: [{ type: Input }]
};
if (false) {
    /** @type {?} */
    FaLayersTextBaseComponent.prototype.renderedHTML;
    /**
     * @type {?}
     * @protected
     */
    FaLayersTextBaseComponent.prototype.params;
    /**
     * @type {?}
     * @protected
     */
    FaLayersTextBaseComponent.prototype.content;
    /**
     * @type {?}
     * @protected
     */
    FaLayersTextBaseComponent.prototype.title;
    /**
     * @type {?}
     * @protected
     */
    FaLayersTextBaseComponent.prototype.styles;
    /**
     * @type {?}
     * @protected
     */
    FaLayersTextBaseComponent.prototype.classes;
    /**
     * @type {?}
     * @private
     */
    FaLayersTextBaseComponent.prototype.parent;
    /**
     * @type {?}
     * @private
     */
    FaLayersTextBaseComponent.prototype.sanitizer;
    /**
     * Updating params by component props.
     * @abstract
     * @protected
     * @return {?}
     */
    FaLayersTextBaseComponent.prototype.updateParams = function () { };
    /**
     * Render the FontawesomeObject using the content and params.
     * @abstract
     * @protected
     * @param {?} content
     * @param {?=} params
     * @return {?}
     */
    FaLayersTextBaseComponent.prototype.renderFontawesomeObject = function (content, params) { };
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Fontawesome layers counter.
 */
class FaLayersCounterComponent extends FaLayersTextBaseComponent {
    /**
     * Updating params by component props.
     * @protected
     * @return {?}
     */
    updateParams() {
        this.params = {
            title: this.title,
            classes: this.classes,
            styles: this.styles,
        };
    }
    /**
     * @protected
     * @param {?} content
     * @param {?=} params
     * @return {?}
     */
    renderFontawesomeObject(content, params) {
        return counter(content, params);
    }
}
FaLayersCounterComponent.decorators = [
    { type: Component, args: [{
                selector: 'fa-layers-counter',
                template: '',
                host: {
                    class: 'ng-fa-layers-counter'
                }
            }] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Fontawesome layers text.
 */
class FaLayersTextComponent extends FaLayersTextBaseComponent {
    /**
     * Updating params by component props.
     * @protected
     * @return {?}
     */
    updateParams() {
        /** @type {?} */
        const classOpts = {
            flip: this.flip,
            spin: this.spin,
            pulse: this.pulse,
            border: this.border,
            inverse: this.inverse,
            listItem: this.listItem,
            size: this.size || null,
            pull: this.pull || null,
            rotate: this.rotate || null,
            fixedWidth: this.fixedWidth
        };
        /** @type {?} */
        const parsedTransform = typeof this.transform === 'string' ? parse.transform(this.transform) : this.transform;
        this.params = {
            transform: parsedTransform,
            classes: [...faClassList(classOpts), ...this.classes],
            title: this.title,
            styles: this.styles
        };
    }
    /**
     * @protected
     * @param {?} content
     * @param {?=} params
     * @return {?}
     */
    renderFontawesomeObject(content, params) {
        return text(content, params);
    }
}
FaLayersTextComponent.decorators = [
    { type: Component, args: [{
                selector: 'fa-layers-text',
                template: '',
                host: {
                    class: 'ng-fa-layers-text'
                }
            }] }
];
FaLayersTextComponent.propDecorators = {
    spin: [{ type: Input }],
    pulse: [{ type: Input }],
    flip: [{ type: Input }],
    size: [{ type: Input }],
    pull: [{ type: Input }],
    border: [{ type: Input }],
    inverse: [{ type: Input }],
    listItem: [{ type: Input }],
    rotate: [{ type: Input }],
    fixedWidth: [{ type: Input }],
    transform: [{ type: Input }]
};
if (false) {
    /** @type {?} */
    FaLayersTextComponent.prototype.spin;
    /** @type {?} */
    FaLayersTextComponent.prototype.pulse;
    /** @type {?} */
    FaLayersTextComponent.prototype.flip;
    /** @type {?} */
    FaLayersTextComponent.prototype.size;
    /** @type {?} */
    FaLayersTextComponent.prototype.pull;
    /** @type {?} */
    FaLayersTextComponent.prototype.border;
    /** @type {?} */
    FaLayersTextComponent.prototype.inverse;
    /** @type {?} */
    FaLayersTextComponent.prototype.listItem;
    /** @type {?} */
    FaLayersTextComponent.prototype.rotate;
    /** @type {?} */
    FaLayersTextComponent.prototype.fixedWidth;
    /** @type {?} */
    FaLayersTextComponent.prototype.transform;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class FaStackComponent {
    /**
     * @param {?} renderer
     * @param {?} elementRef
     */
    constructor(renderer, elementRef) {
        this.renderer = renderer;
        this.elementRef = elementRef;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.renderer.addClass(this.elementRef.nativeElement, 'fa-stack');
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if ('size' in changes) {
            if (changes.size.currentValue != null) {
                this.renderer.addClass(this.elementRef.nativeElement, `fa-${changes.size.currentValue}`);
            }
            if (changes.size.previousValue != null) {
                this.renderer.removeClass(this.elementRef.nativeElement, `fa-${changes.size.previousValue}`);
            }
        }
    }
}
FaStackComponent.decorators = [
    { type: Component, args: [{
                selector: 'fa-stack',
                // TODO: See if it is better to select fa-icon and throw if it does not have stackItemSize directive
                template: `<ng-content select="fa-icon[stackItemSize],fa-duotone-icon[stackItemSize]"></ng-content>`
            }] }
];
/** @nocollapse */
FaStackComponent.ctorParameters = () => [
    { type: Renderer2 },
    { type: ElementRef }
];
FaStackComponent.propDecorators = {
    size: [{ type: Input }]
};
if (false) {
    /**
     * Size of the stacked icon.
     * Note that stacked icon is by default 2 times bigger, than non-stacked icon.
     * You'll need to set size using custom CSS to align stacked icon with a
     * simple one. E.g. `fa-stack { font-size: 0.5em; }`.
     * @type {?}
     */
    FaStackComponent.prototype.size;
    /**
     * @type {?}
     * @private
     */
    FaStackComponent.prototype.renderer;
    /**
     * @type {?}
     * @private
     */
    FaStackComponent.prototype.elementRef;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class FontAwesomeModule {
}
FontAwesomeModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    FaIconComponent,
                    FaDuotoneIconComponent,
                    FaLayersComponent,
                    FaLayersTextComponent,
                    FaLayersCounterComponent,
                    FaStackComponent,
                    FaStackItemSizeDirective,
                ],
                exports: [
                    FaIconComponent,
                    FaDuotoneIconComponent,
                    FaLayersComponent,
                    FaLayersTextComponent,
                    FaLayersCounterComponent,
                    FaStackComponent,
                    FaStackItemSizeDirective,
                ],
                entryComponents: [
                    FaIconComponent,
                    FaDuotoneIconComponent,
                ]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use FaConfig directly.
 */
class FaIconService {
    /**
     * @param {?} config
     */
    constructor(config) {
        this.config = config;
    }
    /**
     * @return {?}
     */
    get defaultPrefix() {
        return this.config.defaultPrefix;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set defaultPrefix(value) {
        this.config.defaultPrefix = value;
    }
}
FaIconService.decorators = [
    { type: Injectable, args: [{ providedIn: 'root' },] }
];
/** @nocollapse */
FaIconService.ctorParameters = () => [
    { type: FaConfig }
];
/** @nocollapse */ FaIconService.ngInjectableDef = ɵɵdefineInjectable({ factory: function FaIconService_Factory() { return new FaIconService(ɵɵinject(FaConfig)); }, token: FaIconService, providedIn: "root" });
if (false) {
    /**
     * @type {?}
     * @private
     */
    FaIconService.prototype.config;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { FaConfig, FaDuotoneIconComponent, FaIconComponent, FaIconLibrary, FaIconService, FaLayersComponent, FaLayersCounterComponent, FaLayersTextComponent, FaStackComponent, FaStackItemSizeDirective, FontAwesomeModule, FaLayersTextBaseComponent as ɵa };
//# sourceMappingURL=angular-fontawesome.js.map
