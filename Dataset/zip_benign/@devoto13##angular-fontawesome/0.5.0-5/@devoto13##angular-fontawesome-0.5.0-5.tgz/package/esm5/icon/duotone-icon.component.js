/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import * as tslib_1 from "tslib";
import { Component, Input } from '@angular/core';
import { FaIconComponent } from './icon.component';
var FaDuotoneIconComponent = /** @class */ (function (_super) {
    tslib_1.__extends(FaDuotoneIconComponent, _super);
    function FaDuotoneIconComponent() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /**
     * @protected
     * @param {?} i
     * @return {?}
     */
    FaDuotoneIconComponent.prototype.findIconDefinition = /**
     * @protected
     * @param {?} i
     * @return {?}
     */
    function (i) {
        /** @type {?} */
        var lookup = _super.prototype.findIconDefinition.call(this, i);
        if (lookup != null && lookup.prefix !== 'fad') {
            throw new Error('The specified icon does not appear to be a Duotone icon. ' +
                'Check that you specified the correct style: ' +
                ("<fa-duotone-icon [icon]=\"['fab', '" + lookup.iconName + "']\"></fa-duotone-icon> ") +
                ("or use: <fa-icon icon=\"" + lookup.iconName + "\"></fa-icon> instead."));
        }
        return lookup;
    };
    /**
     * @protected
     * @return {?}
     */
    FaDuotoneIconComponent.prototype.buildParams = /**
     * @protected
     * @return {?}
     */
    function () {
        /** @type {?} */
        var params = _super.prototype.buildParams.call(this);
        if (this.swapOpacity === true || this.swapOpacity === 'true') {
            params.classes.push('fa-swap-opacity');
        }
        if (this.primaryOpacity != null) {
            params.styles['--fa-primary-opacity'] = this.primaryOpacity.toString();
        }
        if (this.secondaryOpacity != null) {
            params.styles['--fa-secondary-opacity'] = this.secondaryOpacity.toString();
        }
        if (this.primaryColor != null) {
            params.styles['--fa-primary-color'] = this.primaryColor;
        }
        if (this.secondaryColor != null) {
            params.styles['--fa-secondary-color'] = this.secondaryColor;
        }
        return params;
    };
    FaDuotoneIconComponent.decorators = [
        { type: Component, args: [{
                    selector: 'fa-duotone-icon',
                    template: ""
                }] }
    ];
    FaDuotoneIconComponent.propDecorators = {
        swapOpacity: [{ type: Input }],
        primaryOpacity: [{ type: Input }],
        secondaryOpacity: [{ type: Input }],
        primaryColor: [{ type: Input }],
        secondaryColor: [{ type: Input }]
    };
    return FaDuotoneIconComponent;
}(FaIconComponent));
export { FaDuotoneIconComponent };
if (false) {
    /**
     * Swap the default opacity of each duotone icon’s layers. This will make an
     * icon’s primary layer have the default opacity of 40% rather than its
     * secondary layer.
     *
     * \@default false
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.swapOpacity;
    /**
     * Customize the opacity of the primary icon layer.
     * Valid values are in range [0, 1.0].
     *
     * \@default 1.0
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.primaryOpacity;
    /**
     * Customize the opacity of the secondary icon layer.
     * Valid values are in range [0, 1.0].
     *
     * \@default 0.4
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.secondaryOpacity;
    /**
     * Customize the color of the primary icon layer.
     * Accepts any valid CSS color value.
     *
     * \@default CSS inherited color
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.primaryColor;
    /**
     * Customize the color of the secondary icon layer.
     * Accepts any valid CSS color value.
     *
     * \@default CSS inherited color
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.secondaryColor;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHVvdG9uZS1pY29uLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0Bmb3J0YXdlc29tZS9hbmd1bGFyLWZvbnRhd2Vzb21lLyIsInNvdXJjZXMiOlsiaWNvbi9kdW90b25lLWljb24uY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFakQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLGtCQUFrQixDQUFDO0FBRW5EO0lBSTRDLGtEQUFlO0lBSjNEOztJQWtGQSxDQUFDOzs7Ozs7SUFwQ1csbURBQWtCOzs7OztJQUE1QixVQUE2QixDQUE0Qjs7WUFDakQsTUFBTSxHQUFHLGlCQUFNLGtCQUFrQixZQUFDLENBQUMsQ0FBQztRQUUxQyxJQUFJLE1BQU0sSUFBSSxJQUFJLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxLQUFLLEVBQUU7WUFDN0MsTUFBTSxJQUFJLEtBQUssQ0FDYiwyREFBMkQ7Z0JBQzNELDhDQUE4QztpQkFDOUMsd0NBQXFDLE1BQU0sQ0FBQyxRQUFRLDZCQUF5QixDQUFBO2lCQUM3RSw2QkFBMEIsTUFBTSxDQUFDLFFBQVEsMkJBQXVCLENBQUEsQ0FDakUsQ0FBQztTQUNIO1FBRUQsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQzs7Ozs7SUFFUyw0Q0FBVzs7OztJQUFyQjs7WUFDUSxNQUFNLEdBQUcsaUJBQU0sV0FBVyxXQUFFO1FBRWxDLElBQUksSUFBSSxDQUFDLFdBQVcsS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLFdBQVcsS0FBSyxNQUFNLEVBQUU7WUFDNUQsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztTQUN4QztRQUNELElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxJQUFJLEVBQUU7WUFDL0IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxFQUFFLENBQUM7U0FDeEU7UUFDRCxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJLEVBQUU7WUFDakMsTUFBTSxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsQ0FBQztTQUM1RTtRQUNELElBQUksSUFBSSxDQUFDLFlBQVksSUFBSSxJQUFJLEVBQUU7WUFDN0IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7U0FDekQ7UUFDRCxJQUFJLElBQUksQ0FBQyxjQUFjLElBQUksSUFBSSxFQUFFO1lBQy9CLE1BQU0sQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO1NBQzdEO1FBRUQsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQzs7Z0JBakZGLFNBQVMsU0FBQztvQkFDVCxRQUFRLEVBQUUsaUJBQWlCO29CQUMzQixRQUFRLEVBQUUsRUFBRTtpQkFDYjs7OzhCQVNFLEtBQUs7aUNBUUwsS0FBSzttQ0FRTCxLQUFLOytCQVFMLEtBQUs7aUNBUUwsS0FBSzs7SUFzQ1IsNkJBQUM7Q0FBQSxBQWxGRCxDQUk0QyxlQUFlLEdBOEUxRDtTQTlFWSxzQkFBc0I7Ozs7Ozs7Ozs7SUFRakMsNkNBQWtEOzs7Ozs7OztJQVFsRCxnREFBMEM7Ozs7Ozs7O0lBUTFDLGtEQUE0Qzs7Ozs7Ozs7SUFRNUMsOENBQStCOzs7Ozs7OztJQVEvQixnREFBaUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJY29uRGVmaW5pdGlvbiwgSWNvblByb3AgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuaW1wb3J0IHsgRmFJY29uQ29tcG9uZW50IH0gZnJvbSAnLi9pY29uLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2ZhLWR1b3RvbmUtaWNvbicsXG4gIHRlbXBsYXRlOiBgYFxufSlcbmV4cG9ydCBjbGFzcyBGYUR1b3RvbmVJY29uQ29tcG9uZW50IGV4dGVuZHMgRmFJY29uQ29tcG9uZW50IHtcbiAgLyoqXG4gICAqIFN3YXAgdGhlIGRlZmF1bHQgb3BhY2l0eSBvZiBlYWNoIGR1b3RvbmUgaWNvbuKAmXMgbGF5ZXJzLiBUaGlzIHdpbGwgbWFrZSBhblxuICAgKiBpY29u4oCZcyBwcmltYXJ5IGxheWVyIGhhdmUgdGhlIGRlZmF1bHQgb3BhY2l0eSBvZiA0MCUgcmF0aGVyIHRoYW4gaXRzXG4gICAqIHNlY29uZGFyeSBsYXllci5cbiAgICpcbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIEBJbnB1dCgpIHN3YXBPcGFjaXR5PzogJ3RydWUnIHwgJ2ZhbHNlJyB8IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIEN1c3RvbWl6ZSB0aGUgb3BhY2l0eSBvZiB0aGUgcHJpbWFyeSBpY29uIGxheWVyLlxuICAgKiBWYWxpZCB2YWx1ZXMgYXJlIGluIHJhbmdlIFswLCAxLjBdLlxuICAgKlxuICAgKiBAZGVmYXVsdCAxLjBcbiAgICovXG4gIEBJbnB1dCgpIHByaW1hcnlPcGFjaXR5Pzogc3RyaW5nIHwgbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBDdXN0b21pemUgdGhlIG9wYWNpdHkgb2YgdGhlIHNlY29uZGFyeSBpY29uIGxheWVyLlxuICAgKiBWYWxpZCB2YWx1ZXMgYXJlIGluIHJhbmdlIFswLCAxLjBdLlxuICAgKlxuICAgKiBAZGVmYXVsdCAwLjRcbiAgICovXG4gIEBJbnB1dCgpIHNlY29uZGFyeU9wYWNpdHk/OiBzdHJpbmcgfCBudW1iZXI7XG5cbiAgLyoqXG4gICAqIEN1c3RvbWl6ZSB0aGUgY29sb3Igb2YgdGhlIHByaW1hcnkgaWNvbiBsYXllci5cbiAgICogQWNjZXB0cyBhbnkgdmFsaWQgQ1NTIGNvbG9yIHZhbHVlLlxuICAgKlxuICAgKiBAZGVmYXVsdCBDU1MgaW5oZXJpdGVkIGNvbG9yXG4gICAqL1xuICBASW5wdXQoKSBwcmltYXJ5Q29sb3I/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEN1c3RvbWl6ZSB0aGUgY29sb3Igb2YgdGhlIHNlY29uZGFyeSBpY29uIGxheWVyLlxuICAgKiBBY2NlcHRzIGFueSB2YWxpZCBDU1MgY29sb3IgdmFsdWUuXG4gICAqXG4gICAqIEBkZWZhdWx0IENTUyBpbmhlcml0ZWQgY29sb3JcbiAgICovXG4gIEBJbnB1dCgpIHNlY29uZGFyeUNvbG9yPzogc3RyaW5nO1xuXG4gIHByb3RlY3RlZCBmaW5kSWNvbkRlZmluaXRpb24oaTogSWNvblByb3AgfCBJY29uRGVmaW5pdGlvbik6IEljb25EZWZpbml0aW9uIHwgbnVsbCB7XG4gICAgY29uc3QgbG9va3VwID0gc3VwZXIuZmluZEljb25EZWZpbml0aW9uKGkpO1xuXG4gICAgaWYgKGxvb2t1cCAhPSBudWxsICYmIGxvb2t1cC5wcmVmaXggIT09ICdmYWQnKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdUaGUgc3BlY2lmaWVkIGljb24gZG9lcyBub3QgYXBwZWFyIHRvIGJlIGEgRHVvdG9uZSBpY29uLiAnICtcbiAgICAgICAgJ0NoZWNrIHRoYXQgeW91IHNwZWNpZmllZCB0aGUgY29ycmVjdCBzdHlsZTogJyArXG4gICAgICAgIGA8ZmEtZHVvdG9uZS1pY29uIFtpY29uXT1cIlsnZmFiJywgJyR7bG9va3VwLmljb25OYW1lfSddXCI+PC9mYS1kdW90b25lLWljb24+IGAgK1xuICAgICAgICBgb3IgdXNlOiA8ZmEtaWNvbiBpY29uPVwiJHtsb29rdXAuaWNvbk5hbWV9XCI+PC9mYS1pY29uPiBpbnN0ZWFkLmBcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGxvb2t1cDtcbiAgfVxuXG4gIHByb3RlY3RlZCBidWlsZFBhcmFtcygpIHtcbiAgICBjb25zdCBwYXJhbXMgPSBzdXBlci5idWlsZFBhcmFtcygpO1xuXG4gICAgaWYgKHRoaXMuc3dhcE9wYWNpdHkgPT09IHRydWUgfHwgdGhpcy5zd2FwT3BhY2l0eSA9PT0gJ3RydWUnKSB7XG4gICAgICBwYXJhbXMuY2xhc3Nlcy5wdXNoKCdmYS1zd2FwLW9wYWNpdHknKTtcbiAgICB9XG4gICAgaWYgKHRoaXMucHJpbWFyeU9wYWNpdHkgIT0gbnVsbCkge1xuICAgICAgcGFyYW1zLnN0eWxlc1snLS1mYS1wcmltYXJ5LW9wYWNpdHknXSA9IHRoaXMucHJpbWFyeU9wYWNpdHkudG9TdHJpbmcoKTtcbiAgICB9XG4gICAgaWYgKHRoaXMuc2Vjb25kYXJ5T3BhY2l0eSAhPSBudWxsKSB7XG4gICAgICBwYXJhbXMuc3R5bGVzWyctLWZhLXNlY29uZGFyeS1vcGFjaXR5J10gPSB0aGlzLnNlY29uZGFyeU9wYWNpdHkudG9TdHJpbmcoKTtcbiAgICB9XG4gICAgaWYgKHRoaXMucHJpbWFyeUNvbG9yICE9IG51bGwpIHtcbiAgICAgIHBhcmFtcy5zdHlsZXNbJy0tZmEtcHJpbWFyeS1jb2xvciddID0gdGhpcy5wcmltYXJ5Q29sb3I7XG4gICAgfVxuICAgIGlmICh0aGlzLnNlY29uZGFyeUNvbG9yICE9IG51bGwpIHtcbiAgICAgIHBhcmFtcy5zdHlsZXNbJy0tZmEtc2Vjb25kYXJ5LWNvbG9yJ10gPSB0aGlzLnNlY29uZGFyeUNvbG9yO1xuICAgIH1cblxuICAgIHJldHVybiBwYXJhbXM7XG4gIH1cbn1cblxuIl19