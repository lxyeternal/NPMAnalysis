/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Injectable } from '@angular/core';
import { FaConfig } from '../config';
import * as i0 from "@angular/core";
import * as i1 from "../config";
/**
 * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use FaConfig directly.
 */
var FaIconService = /** @class */ (function () {
    function FaIconService(config) {
        this.config = config;
    }
    Object.defineProperty(FaIconService.prototype, "defaultPrefix", {
        get: /**
         * @return {?}
         */
        function () {
            return this.config.defaultPrefix;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.config.defaultPrefix = value;
        },
        enumerable: true,
        configurable: true
    });
    FaIconService.decorators = [
        { type: Injectable, args: [{ providedIn: 'root' },] }
    ];
    /** @nocollapse */
    FaIconService.ctorParameters = function () { return [
        { type: FaConfig }
    ]; };
    /** @nocollapse */ FaIconService.ngInjectableDef = i0.ɵɵdefineInjectable({ factory: function FaIconService_Factory() { return new FaIconService(i0.ɵɵinject(i1.FaConfig)); }, token: FaIconService, providedIn: "root" });
    return FaIconService;
}());
export { FaIconService };
if (false) {
    /**
     * @type {?}
     * @private
     */
    FaIconService.prototype.config;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWNvbi5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQGZvcnRhd2Vzb21lL2FuZ3VsYXItZm9udGF3ZXNvbWUvIiwic291cmNlcyI6WyJpY29uL2ljb24uc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sV0FBVyxDQUFDOzs7Ozs7QUFLckM7SUFVRSx1QkFBb0IsTUFBZ0I7UUFBaEIsV0FBTSxHQUFOLE1BQU0sQ0FBVTtJQUFHLENBQUM7SUFSeEMsc0JBQUksd0NBQWE7Ozs7UUFBakI7WUFDRSxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDO1FBQ25DLENBQUM7Ozs7O1FBRUQsVUFBa0IsS0FBaUI7WUFDakMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBQ3BDLENBQUM7OztPQUpBOztnQkFKRixVQUFVLFNBQUMsRUFBQyxVQUFVLEVBQUUsTUFBTSxFQUFDOzs7O2dCQUx2QixRQUFROzs7d0JBRmpCO0NBa0JDLEFBWEQsSUFXQztTQVZZLGFBQWE7Ozs7OztJQVNaLCtCQUF3QiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEljb25QcmVmaXggfSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuaW1wb3J0IHsgRmFDb25maWcgfSBmcm9tICcuLi9jb25maWcnO1xuXG4vKipcbiAqIEBkZXByZWNhdGVkIFNpbmNlIDAuNS4wLiBXaWxsIGJlIHJlbW92ZWQgaW4gMC42LjAuIFVzZSBGYUNvbmZpZyBkaXJlY3RseS5cbiAqL1xuQEluamVjdGFibGUoe3Byb3ZpZGVkSW46ICdyb290J30pXG5leHBvcnQgY2xhc3MgRmFJY29uU2VydmljZSB7XG4gIGdldCBkZWZhdWx0UHJlZml4KCk6IEljb25QcmVmaXgge1xuICAgIHJldHVybiB0aGlzLmNvbmZpZy5kZWZhdWx0UHJlZml4O1xuICB9XG5cbiAgc2V0IGRlZmF1bHRQcmVmaXgodmFsdWU6IEljb25QcmVmaXgpIHtcbiAgICB0aGlzLmNvbmZpZy5kZWZhdWx0UHJlZml4ID0gdmFsdWU7XG4gIH1cblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGNvbmZpZzogRmFDb25maWcpIHt9XG59XG4iXX0=