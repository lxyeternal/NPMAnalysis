/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import * as tslib_1 from "tslib";
import { Component, HostBinding, Input, Optional } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { findIconDefinition, icon, parse } from '@fortawesome/fontawesome-svg-core';
import { FaConfig } from '../config';
import { FaIconLibrary } from '../icon-library';
import { faWarnIfIconDefinitionMissing } from '../shared/errors/warn-if-icon-html-missing';
import { faWarnIfIconSpecMissing } from '../shared/errors/warn-if-icon-spec-missing';
import { faClassList } from '../shared/utils/classlist.util';
import { faNormalizeIconSpec } from '../shared/utils/normalize-icon-spec.util';
import { FaStackItemSizeDirective } from '../stack/stack-item-size.directive';
var FaIconComponent = /** @class */ (function () {
    function FaIconComponent(sanitizer, config, iconLibrary, stackItem) {
        this.sanitizer = sanitizer;
        this.config = config;
        this.iconLibrary = iconLibrary;
        this.stackItem = stackItem;
        this.classes = [];
    }
    Object.defineProperty(FaIconComponent.prototype, "iconProp", {
        /**
         * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `icon` property directly.
         */
        get: /**
         * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `icon` property directly.
         * @return {?}
         */
        function () {
            return this.icon;
        },
        /**
         * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `icon` property directly.
         */
        set: /**
         * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `icon` property directly.
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.icon = value;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @param {?} changes
     * @return {?}
     */
    FaIconComponent.prototype.ngOnChanges = /**
     * @param {?} changes
     * @return {?}
     */
    function (changes) {
        if (this.icon == null) {
            return faWarnIfIconSpecMissing();
        }
        if (changes) {
            /** @type {?} */
            var iconDefinition = this.findIconDefinition(this.icon);
            if (iconDefinition != null) {
                /** @type {?} */
                var params = this.buildParams();
                this.renderIcon(iconDefinition, params);
            }
        }
    };
    /**
     * Programmatically trigger rendering of the icon.
     *
     * This method is useful, when creating {@link FaIconComponent} dynamically or
     * changing its inputs programmatically as in these cases icon won't be
     * re-rendered automatically.
     */
    /**
     * Programmatically trigger rendering of the icon.
     *
     * This method is useful, when creating {\@link FaIconComponent} dynamically or
     * changing its inputs programmatically as in these cases icon won't be
     * re-rendered automatically.
     * @return {?}
     */
    FaIconComponent.prototype.render = /**
     * Programmatically trigger rendering of the icon.
     *
     * This method is useful, when creating {\@link FaIconComponent} dynamically or
     * changing its inputs programmatically as in these cases icon won't be
     * re-rendered automatically.
     * @return {?}
     */
    function () {
        this.ngOnChanges({});
    };
    /**
     * @protected
     * @param {?} i
     * @return {?}
     */
    FaIconComponent.prototype.findIconDefinition = /**
     * @protected
     * @param {?} i
     * @return {?}
     */
    function (i) {
        /** @type {?} */
        var lookup = faNormalizeIconSpec(i, this.config.defaultPrefix);
        if ('icon' in lookup) {
            return lookup;
        }
        /** @type {?} */
        var definition = this.iconLibrary.getIconDefinition(lookup.prefix, lookup.iconName);
        if (definition != null) {
            return definition;
        }
        /** @type {?} */
        var globalDefinition = findIconDefinition(lookup);
        if (globalDefinition != null) {
            /** @type {?} */
            var message = 'Global icon library is deprecated. ' +
                'Consult https://github.com/FortAwesome/angular-fontawesome/blob/master/UPGRADING.md ' +
                'for the migration instructions.';
            if (this.config.globalLibrary === 'unset') {
                console.error('FontAwesome: ' + message);
            }
            else if (!this.config.globalLibrary) {
                throw new Error(message);
            }
            return globalDefinition;
        }
        faWarnIfIconDefinitionMissing(lookup);
        return null;
    };
    /**
     * @protected
     * @return {?}
     */
    FaIconComponent.prototype.buildParams = /**
     * @protected
     * @return {?}
     */
    function () {
        /** @type {?} */
        var classOpts = {
            flip: this.flip,
            spin: this.spin,
            pulse: this.pulse,
            border: this.border,
            inverse: this.inverse,
            listItem: this.listItem,
            size: this.size || null,
            pull: this.pull || null,
            rotate: this.rotate || null,
            fixedWidth: this.fixedWidth,
            stackItemSize: this.stackItem != null ? this.stackItem.stackItemSize : null,
        };
        /** @type {?} */
        var parsedTransform = typeof this.transform === 'string' ? parse.transform(this.transform) : this.transform;
        return {
            title: this.title,
            transform: parsedTransform,
            classes: tslib_1.__spread(faClassList(classOpts), this.classes),
            mask: this.mask != null ? this.findIconDefinition(this.mask) : null,
            styles: this.styles != null ? this.styles : {},
            symbol: this.symbol,
            attributes: {
                role: this.a11yRole
            }
        };
    };
    /**
     * @private
     * @param {?} definition
     * @param {?} params
     * @return {?}
     */
    FaIconComponent.prototype.renderIcon = /**
     * @private
     * @param {?} definition
     * @param {?} params
     * @return {?}
     */
    function (definition, params) {
        /** @type {?} */
        var renderedIcon = icon(definition, params);
        this.renderedIconHTML = this.sanitizer.bypassSecurityTrustHtml(renderedIcon.html.join('\n'));
    };
    FaIconComponent.decorators = [
        { type: Component, args: [{
                    selector: 'fa-icon',
                    template: "",
                    host: {
                        class: 'ng-fa-icon',
                        '[attr.title]': 'title',
                    }
                }] }
    ];
    /** @nocollapse */
    FaIconComponent.ctorParameters = function () { return [
        { type: DomSanitizer },
        { type: FaConfig },
        { type: FaIconLibrary },
        { type: FaStackItemSizeDirective, decorators: [{ type: Optional }] }
    ]; };
    FaIconComponent.propDecorators = {
        icon: [{ type: Input }],
        title: [{ type: Input }],
        spin: [{ type: Input }],
        pulse: [{ type: Input }],
        mask: [{ type: Input }],
        styles: [{ type: Input }],
        flip: [{ type: Input }],
        size: [{ type: Input }],
        pull: [{ type: Input }],
        border: [{ type: Input }],
        inverse: [{ type: Input }],
        symbol: [{ type: Input }],
        listItem: [{ type: Input }],
        rotate: [{ type: Input }],
        fixedWidth: [{ type: Input }],
        classes: [{ type: Input }],
        transform: [{ type: Input }],
        a11yRole: [{ type: Input }],
        renderedIconHTML: [{ type: HostBinding, args: ['innerHTML',] }]
    };
    return FaIconComponent;
}());
export { FaIconComponent };
if (false) {
    /** @type {?} */
    FaIconComponent.prototype.icon;
    /**
     * Specify a title for the icon.
     * This text will be displayed in a tooltip on hover and presented to the
     * screen readers.
     * @type {?}
     */
    FaIconComponent.prototype.title;
    /** @type {?} */
    FaIconComponent.prototype.spin;
    /** @type {?} */
    FaIconComponent.prototype.pulse;
    /** @type {?} */
    FaIconComponent.prototype.mask;
    /** @type {?} */
    FaIconComponent.prototype.styles;
    /** @type {?} */
    FaIconComponent.prototype.flip;
    /** @type {?} */
    FaIconComponent.prototype.size;
    /** @type {?} */
    FaIconComponent.prototype.pull;
    /** @type {?} */
    FaIconComponent.prototype.border;
    /** @type {?} */
    FaIconComponent.prototype.inverse;
    /** @type {?} */
    FaIconComponent.prototype.symbol;
    /**
     * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `fixedWidth` with your custom styles instead.
     * @type {?}
     */
    FaIconComponent.prototype.listItem;
    /** @type {?} */
    FaIconComponent.prototype.rotate;
    /** @type {?} */
    FaIconComponent.prototype.fixedWidth;
    /** @type {?} */
    FaIconComponent.prototype.classes;
    /** @type {?} */
    FaIconComponent.prototype.transform;
    /**
     * Specify the `role` attribute for the rendered <svg> element.
     *
     * \@default 'img'
     * @type {?}
     */
    FaIconComponent.prototype.a11yRole;
    /** @type {?} */
    FaIconComponent.prototype.renderedIconHTML;
    /**
     * @type {?}
     * @private
     */
    FaIconComponent.prototype.sanitizer;
    /**
     * @type {?}
     * @private
     */
    FaIconComponent.prototype.config;
    /**
     * @type {?}
     * @private
     */
    FaIconComponent.prototype.iconLibrary;
    /**
     * @type {?}
     * @private
     */
    FaIconComponent.prototype.stackItem;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWNvbi5jb21wb25lbnQuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AZm9ydGF3ZXNvbWUvYW5ndWxhci1mb250YXdlc29tZS8iLCJzb3VyY2VzIjpbImljb24vaWNvbi5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQWEsUUFBUSxFQUFpQixNQUFNLGVBQWUsQ0FBQztBQUNsRyxPQUFPLEVBQUUsWUFBWSxFQUFZLE1BQU0sMkJBQTJCLENBQUM7QUFDbkUsT0FBTyxFQUVMLGtCQUFrQixFQUVsQixJQUFJLEVBSUosS0FBSyxFQU1OLE1BQU0sbUNBQW1DLENBQUM7QUFDM0MsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLFdBQVcsQ0FBQztBQUNyQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDaEQsT0FBTyxFQUFFLDZCQUE2QixFQUFFLE1BQU0sNENBQTRDLENBQUM7QUFDM0YsT0FBTyxFQUFFLHVCQUF1QixFQUFFLE1BQU0sNENBQTRDLENBQUM7QUFFckYsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLGdDQUFnQyxDQUFDO0FBQzdELE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLDBDQUEwQyxDQUFDO0FBQy9FLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLG9DQUFvQyxDQUFDO0FBRTlFO0lBNkRFLHlCQUNVLFNBQXVCLEVBQ3ZCLE1BQWdCLEVBQ2hCLFdBQTBCLEVBQ2QsU0FBbUM7UUFIL0MsY0FBUyxHQUFULFNBQVMsQ0FBYztRQUN2QixXQUFNLEdBQU4sTUFBTSxDQUFVO1FBQ2hCLGdCQUFXLEdBQVgsV0FBVyxDQUFlO1FBQ2QsY0FBUyxHQUFULFNBQVMsQ0FBMEI7UUEvQmhELFlBQU8sR0FBYyxFQUFFLENBQUM7SUFpQ2pDLENBQUM7SUFwQkQsc0JBQUkscUNBQVE7UUFIWjs7V0FFRzs7Ozs7UUFDSDtZQUNFLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQztRQUNuQixDQUFDO1FBRUQ7O1dBRUc7Ozs7OztRQUNILFVBQWEsS0FBZTtZQUMxQixJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQztRQUNwQixDQUFDOzs7T0FQQTs7Ozs7SUFvQkQscUNBQVc7Ozs7SUFBWCxVQUFZLE9BQXNCO1FBQ2hDLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLEVBQUU7WUFDckIsT0FBTyx1QkFBdUIsRUFBRSxDQUFDO1NBQ2xDO1FBRUQsSUFBSSxPQUFPLEVBQUU7O2dCQUNMLGNBQWMsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUN6RCxJQUFJLGNBQWMsSUFBSSxJQUFJLEVBQUU7O29CQUNwQixNQUFNLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRTtnQkFDakMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLENBQUM7YUFDekM7U0FDRjtJQUNILENBQUM7SUFFRDs7Ozs7O09BTUc7Ozs7Ozs7OztJQUNILGdDQUFNOzs7Ozs7OztJQUFOO1FBQ0UsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUN2QixDQUFDOzs7Ozs7SUFFUyw0Q0FBa0I7Ozs7O0lBQTVCLFVBQTZCLENBQTRCOztZQUNqRCxNQUFNLEdBQUcsbUJBQW1CLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDO1FBQ2hFLElBQUksTUFBTSxJQUFJLE1BQU0sRUFBRTtZQUNwQixPQUFPLE1BQU0sQ0FBQztTQUNmOztZQUVLLFVBQVUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLFFBQVEsQ0FBQztRQUNyRixJQUFJLFVBQVUsSUFBSSxJQUFJLEVBQUU7WUFDdEIsT0FBTyxVQUFVLENBQUM7U0FDbkI7O1lBRUssZ0JBQWdCLEdBQUcsa0JBQWtCLENBQUMsTUFBTSxDQUFDO1FBQ25ELElBQUksZ0JBQWdCLElBQUksSUFBSSxFQUFFOztnQkFDdEIsT0FBTyxHQUFHLHFDQUFxQztnQkFDbkQsc0ZBQXNGO2dCQUN0RixpQ0FBaUM7WUFDbkMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsS0FBSyxPQUFPLEVBQUU7Z0JBQ3pDLE9BQU8sQ0FBQyxLQUFLLENBQUMsZUFBZSxHQUFHLE9BQU8sQ0FBQyxDQUFDO2FBQzFDO2lCQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRTtnQkFDckMsTUFBTSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQzthQUMxQjtZQUVELE9BQU8sZ0JBQWdCLENBQUM7U0FDekI7UUFFRCw2QkFBNkIsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN0QyxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7Ozs7O0lBRVMscUNBQVc7Ozs7SUFBckI7O1lBQ1EsU0FBUyxHQUFZO1lBQ3pCLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtZQUNmLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtZQUNmLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztZQUNqQixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07WUFDbkIsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO1lBQ3JCLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtZQUN2QixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJO1lBQ3ZCLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUk7WUFDdkIsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSTtZQUMzQixVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7WUFDM0IsYUFBYSxFQUFFLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsSUFBSTtTQUM1RTs7WUFFSyxlQUFlLEdBQUcsT0FBTyxJQUFJLENBQUMsU0FBUyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTO1FBRTdHLE9BQU87WUFDTCxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7WUFDakIsU0FBUyxFQUFFLGVBQWU7WUFDMUIsT0FBTyxtQkFBTSxXQUFXLENBQUMsU0FBUyxDQUFDLEVBQUssSUFBSSxDQUFDLE9BQU8sQ0FBQztZQUNyRCxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7WUFDbkUsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQzlDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtZQUNuQixVQUFVLEVBQUU7Z0JBQ1YsSUFBSSxFQUFFLElBQUksQ0FBQyxRQUFRO2FBQ3BCO1NBQ0YsQ0FBQztJQUNKLENBQUM7Ozs7Ozs7SUFFTyxvQ0FBVTs7Ozs7O0lBQWxCLFVBQW1CLFVBQTBCLEVBQUUsTUFBa0I7O1lBQ3pELFlBQVksR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQztRQUM3QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQy9GLENBQUM7O2dCQTVKRixTQUFTLFNBQUM7b0JBQ1QsUUFBUSxFQUFFLFNBQVM7b0JBQ25CLFFBQVEsRUFBRSxFQUFFO29CQUNaLElBQUksRUFBRTt3QkFDSixLQUFLLEVBQUUsWUFBWTt3QkFDbkIsY0FBYyxFQUFFLE9BQU87cUJBQ3hCO2lCQUNGOzs7O2dCQWhDUSxZQUFZO2dCQWdCWixRQUFRO2dCQUNSLGFBQWE7Z0JBTWIsd0JBQXdCLHVCQW1FNUIsUUFBUTs7O3VCQXhEVixLQUFLO3dCQU9MLEtBQUs7dUJBQ0wsS0FBSzt3QkFDTCxLQUFLO3VCQUNMLEtBQUs7eUJBQ0wsS0FBSzt1QkFDTCxLQUFLO3VCQUNMLEtBQUs7dUJBQ0wsS0FBSzt5QkFDTCxLQUFLOzBCQUNMLEtBQUs7eUJBQ0wsS0FBSzsyQkFLTCxLQUFLO3lCQUNMLEtBQUs7NkJBQ0wsS0FBSzswQkFDTCxLQUFLOzRCQUNMLEtBQUs7MkJBT0wsS0FBSzttQ0FnQkwsV0FBVyxTQUFDLFdBQVc7O0lBbUcxQixzQkFBQztDQUFBLEFBN0pELElBNkpDO1NBckpZLGVBQWU7OztJQUMxQiwrQkFBd0I7Ozs7Ozs7SUFPeEIsZ0NBQXdCOztJQUN4QiwrQkFBd0I7O0lBQ3hCLGdDQUF5Qjs7SUFDekIsK0JBQXlCOztJQUN6QixpQ0FBeUI7O0lBQ3pCLCtCQUF5Qjs7SUFDekIsK0JBQXlCOztJQUN6QiwrQkFBeUI7O0lBQ3pCLGlDQUEwQjs7SUFDMUIsa0NBQTJCOztJQUMzQixpQ0FBMkI7Ozs7O0lBSzNCLG1DQUE0Qjs7SUFDNUIsaUNBQTZCOztJQUM3QixxQ0FBOEI7O0lBQzlCLGtDQUFpQzs7SUFDakMsb0NBQXdDOzs7Ozs7O0lBT3hDLG1DQUEwQjs7SUFnQjFCLDJDQUNrQzs7Ozs7SUFHaEMsb0NBQStCOzs7OztJQUMvQixpQ0FBd0I7Ozs7O0lBQ3hCLHNDQUFrQzs7Ozs7SUFDbEMsb0NBQXVEIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBIb3N0QmluZGluZywgSW5wdXQsIE9uQ2hhbmdlcywgT3B0aW9uYWwsIFNpbXBsZUNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IERvbVNhbml0aXplciwgU2FmZUh0bWwgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcbmltcG9ydCB7XG4gIEZhU3ltYm9sLFxuICBmaW5kSWNvbkRlZmluaXRpb24sXG4gIEZsaXBQcm9wLFxuICBpY29uLFxuICBJY29uRGVmaW5pdGlvbixcbiAgSWNvblBhcmFtcyxcbiAgSWNvblByb3AsXG4gIHBhcnNlLFxuICBQdWxsUHJvcCxcbiAgUm90YXRlUHJvcCxcbiAgU2l6ZVByb3AsXG4gIFN0eWxlcyxcbiAgVHJhbnNmb3JtXG59IGZyb20gJ0Bmb3J0YXdlc29tZS9mb250YXdlc29tZS1zdmctY29yZSc7XG5pbXBvcnQgeyBGYUNvbmZpZyB9IGZyb20gJy4uL2NvbmZpZyc7XG5pbXBvcnQgeyBGYUljb25MaWJyYXJ5IH0gZnJvbSAnLi4vaWNvbi1saWJyYXJ5JztcbmltcG9ydCB7IGZhV2FybklmSWNvbkRlZmluaXRpb25NaXNzaW5nIH0gZnJvbSAnLi4vc2hhcmVkL2Vycm9ycy93YXJuLWlmLWljb24taHRtbC1taXNzaW5nJztcbmltcG9ydCB7IGZhV2FybklmSWNvblNwZWNNaXNzaW5nIH0gZnJvbSAnLi4vc2hhcmVkL2Vycm9ycy93YXJuLWlmLWljb24tc3BlYy1taXNzaW5nJztcbmltcG9ydCB7IEZhUHJvcHMgfSBmcm9tICcuLi9zaGFyZWQvbW9kZWxzL3Byb3BzLm1vZGVsJztcbmltcG9ydCB7IGZhQ2xhc3NMaXN0IH0gZnJvbSAnLi4vc2hhcmVkL3V0aWxzL2NsYXNzbGlzdC51dGlsJztcbmltcG9ydCB7IGZhTm9ybWFsaXplSWNvblNwZWMgfSBmcm9tICcuLi9zaGFyZWQvdXRpbHMvbm9ybWFsaXplLWljb24tc3BlYy51dGlsJztcbmltcG9ydCB7IEZhU3RhY2tJdGVtU2l6ZURpcmVjdGl2ZSB9IGZyb20gJy4uL3N0YWNrL3N0YWNrLWl0ZW0tc2l6ZS5kaXJlY3RpdmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdmYS1pY29uJyxcbiAgdGVtcGxhdGU6IGBgLFxuICBob3N0OiB7XG4gICAgY2xhc3M6ICduZy1mYS1pY29uJyxcbiAgICAnW2F0dHIudGl0bGVdJzogJ3RpdGxlJyxcbiAgfVxufSlcbmV4cG9ydCBjbGFzcyBGYUljb25Db21wb25lbnQgaW1wbGVtZW50cyBPbkNoYW5nZXMge1xuICBASW5wdXQoKSBpY29uOiBJY29uUHJvcDtcblxuICAvKipcbiAgICogU3BlY2lmeSBhIHRpdGxlIGZvciB0aGUgaWNvbi5cbiAgICogVGhpcyB0ZXh0IHdpbGwgYmUgZGlzcGxheWVkIGluIGEgdG9vbHRpcCBvbiBob3ZlciBhbmQgcHJlc2VudGVkIHRvIHRoZVxuICAgKiBzY3JlZW4gcmVhZGVycy5cbiAgICovXG4gIEBJbnB1dCgpIHRpdGxlPzogc3RyaW5nO1xuICBASW5wdXQoKSBzcGluPzogYm9vbGVhbjtcbiAgQElucHV0KCkgcHVsc2U/OiBib29sZWFuO1xuICBASW5wdXQoKSBtYXNrPzogSWNvblByb3A7XG4gIEBJbnB1dCgpIHN0eWxlcz86IFN0eWxlcztcbiAgQElucHV0KCkgZmxpcD86IEZsaXBQcm9wO1xuICBASW5wdXQoKSBzaXplPzogU2l6ZVByb3A7XG4gIEBJbnB1dCgpIHB1bGw/OiBQdWxsUHJvcDtcbiAgQElucHV0KCkgYm9yZGVyPzogYm9vbGVhbjtcbiAgQElucHV0KCkgaW52ZXJzZT86IGJvb2xlYW47XG4gIEBJbnB1dCgpIHN5bWJvbD86IEZhU3ltYm9sO1xuXG4gIC8qKlxuICAgKiBAZGVwcmVjYXRlZCBTaW5jZSAwLjUuMC4gV2lsbCBiZSByZW1vdmVkIGluIDAuNi4wLiBVc2UgYGZpeGVkV2lkdGhgIHdpdGggeW91ciBjdXN0b20gc3R5bGVzIGluc3RlYWQuXG4gICAqL1xuICBASW5wdXQoKSBsaXN0SXRlbT86IGJvb2xlYW47XG4gIEBJbnB1dCgpIHJvdGF0ZT86IFJvdGF0ZVByb3A7XG4gIEBJbnB1dCgpIGZpeGVkV2lkdGg/OiBib29sZWFuO1xuICBASW5wdXQoKSBjbGFzc2VzPzogc3RyaW5nW10gPSBbXTtcbiAgQElucHV0KCkgdHJhbnNmb3JtPzogc3RyaW5nIHwgVHJhbnNmb3JtO1xuXG4gIC8qKlxuICAgKiBTcGVjaWZ5IHRoZSBgcm9sZWAgYXR0cmlidXRlIGZvciB0aGUgcmVuZGVyZWQgPHN2Zz4gZWxlbWVudC5cbiAgICpcbiAgICogQGRlZmF1bHQgJ2ltZydcbiAgICovXG4gIEBJbnB1dCgpIGExMXlSb2xlOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBkZXByZWNhdGVkIFNpbmNlIDAuNS4wLiBXaWxsIGJlIHJlbW92ZWQgaW4gMC42LjAuIFVzZSBgaWNvbmAgcHJvcGVydHkgZGlyZWN0bHkuXG4gICAqL1xuICBnZXQgaWNvblByb3AoKTogSWNvblByb3Age1xuICAgIHJldHVybiB0aGlzLmljb247XG4gIH1cblxuICAvKipcbiAgICogQGRlcHJlY2F0ZWQgU2luY2UgMC41LjAuIFdpbGwgYmUgcmVtb3ZlZCBpbiAwLjYuMC4gVXNlIGBpY29uYCBwcm9wZXJ0eSBkaXJlY3RseS5cbiAgICovXG4gIHNldCBpY29uUHJvcCh2YWx1ZTogSWNvblByb3ApIHtcbiAgICB0aGlzLmljb24gPSB2YWx1ZTtcbiAgfVxuXG4gIEBIb3N0QmluZGluZygnaW5uZXJIVE1MJylcbiAgcHVibGljIHJlbmRlcmVkSWNvbkhUTUw6IFNhZmVIdG1sO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgc2FuaXRpemVyOiBEb21TYW5pdGl6ZXIsXG4gICAgcHJpdmF0ZSBjb25maWc6IEZhQ29uZmlnLFxuICAgIHByaXZhdGUgaWNvbkxpYnJhcnk6IEZhSWNvbkxpYnJhcnksXG4gICAgQE9wdGlvbmFsKCkgcHJpdmF0ZSBzdGFja0l0ZW06IEZhU3RhY2tJdGVtU2l6ZURpcmVjdGl2ZSxcbiAgKSB7XG4gIH1cblxuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XG4gICAgaWYgKHRoaXMuaWNvbiA9PSBudWxsKSB7XG4gICAgICByZXR1cm4gZmFXYXJuSWZJY29uU3BlY01pc3NpbmcoKTtcbiAgICB9XG5cbiAgICBpZiAoY2hhbmdlcykge1xuICAgICAgY29uc3QgaWNvbkRlZmluaXRpb24gPSB0aGlzLmZpbmRJY29uRGVmaW5pdGlvbih0aGlzLmljb24pO1xuICAgICAgaWYgKGljb25EZWZpbml0aW9uICE9IG51bGwpIHtcbiAgICAgICAgY29uc3QgcGFyYW1zID0gdGhpcy5idWlsZFBhcmFtcygpO1xuICAgICAgICB0aGlzLnJlbmRlckljb24oaWNvbkRlZmluaXRpb24sIHBhcmFtcyk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFByb2dyYW1tYXRpY2FsbHkgdHJpZ2dlciByZW5kZXJpbmcgb2YgdGhlIGljb24uXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIGlzIHVzZWZ1bCwgd2hlbiBjcmVhdGluZyB7QGxpbmsgRmFJY29uQ29tcG9uZW50fSBkeW5hbWljYWxseSBvclxuICAgKiBjaGFuZ2luZyBpdHMgaW5wdXRzIHByb2dyYW1tYXRpY2FsbHkgYXMgaW4gdGhlc2UgY2FzZXMgaWNvbiB3b24ndCBiZVxuICAgKiByZS1yZW5kZXJlZCBhdXRvbWF0aWNhbGx5LlxuICAgKi9cbiAgcmVuZGVyKCkge1xuICAgIHRoaXMubmdPbkNoYW5nZXMoe30pO1xuICB9XG5cbiAgcHJvdGVjdGVkIGZpbmRJY29uRGVmaW5pdGlvbihpOiBJY29uUHJvcCB8IEljb25EZWZpbml0aW9uKTogSWNvbkRlZmluaXRpb24gfCBudWxsIHtcbiAgICBjb25zdCBsb29rdXAgPSBmYU5vcm1hbGl6ZUljb25TcGVjKGksIHRoaXMuY29uZmlnLmRlZmF1bHRQcmVmaXgpO1xuICAgIGlmICgnaWNvbicgaW4gbG9va3VwKSB7XG4gICAgICByZXR1cm4gbG9va3VwO1xuICAgIH1cblxuICAgIGNvbnN0IGRlZmluaXRpb24gPSB0aGlzLmljb25MaWJyYXJ5LmdldEljb25EZWZpbml0aW9uKGxvb2t1cC5wcmVmaXgsIGxvb2t1cC5pY29uTmFtZSk7XG4gICAgaWYgKGRlZmluaXRpb24gIT0gbnVsbCkge1xuICAgICAgcmV0dXJuIGRlZmluaXRpb247XG4gICAgfVxuXG4gICAgY29uc3QgZ2xvYmFsRGVmaW5pdGlvbiA9IGZpbmRJY29uRGVmaW5pdGlvbihsb29rdXApO1xuICAgIGlmIChnbG9iYWxEZWZpbml0aW9uICE9IG51bGwpIHtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPSAnR2xvYmFsIGljb24gbGlicmFyeSBpcyBkZXByZWNhdGVkLiAnICtcbiAgICAgICAgJ0NvbnN1bHQgaHR0cHM6Ly9naXRodWIuY29tL0ZvcnRBd2Vzb21lL2FuZ3VsYXItZm9udGF3ZXNvbWUvYmxvYi9tYXN0ZXIvVVBHUkFESU5HLm1kICcgK1xuICAgICAgICAnZm9yIHRoZSBtaWdyYXRpb24gaW5zdHJ1Y3Rpb25zLic7XG4gICAgICBpZiAodGhpcy5jb25maWcuZ2xvYmFsTGlicmFyeSA9PT0gJ3Vuc2V0Jykge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdGb250QXdlc29tZTogJyArIG1lc3NhZ2UpO1xuICAgICAgfSBlbHNlIGlmICghdGhpcy5jb25maWcuZ2xvYmFsTGlicmFyeSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBnbG9iYWxEZWZpbml0aW9uO1xuICAgIH1cblxuICAgIGZhV2FybklmSWNvbkRlZmluaXRpb25NaXNzaW5nKGxvb2t1cCk7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICBwcm90ZWN0ZWQgYnVpbGRQYXJhbXMoKSB7XG4gICAgY29uc3QgY2xhc3NPcHRzOiBGYVByb3BzID0ge1xuICAgICAgZmxpcDogdGhpcy5mbGlwLFxuICAgICAgc3BpbjogdGhpcy5zcGluLFxuICAgICAgcHVsc2U6IHRoaXMucHVsc2UsXG4gICAgICBib3JkZXI6IHRoaXMuYm9yZGVyLFxuICAgICAgaW52ZXJzZTogdGhpcy5pbnZlcnNlLFxuICAgICAgbGlzdEl0ZW06IHRoaXMubGlzdEl0ZW0sXG4gICAgICBzaXplOiB0aGlzLnNpemUgfHwgbnVsbCxcbiAgICAgIHB1bGw6IHRoaXMucHVsbCB8fCBudWxsLFxuICAgICAgcm90YXRlOiB0aGlzLnJvdGF0ZSB8fCBudWxsLFxuICAgICAgZml4ZWRXaWR0aDogdGhpcy5maXhlZFdpZHRoLFxuICAgICAgc3RhY2tJdGVtU2l6ZTogdGhpcy5zdGFja0l0ZW0gIT0gbnVsbCA/IHRoaXMuc3RhY2tJdGVtLnN0YWNrSXRlbVNpemUgOiBudWxsLFxuICAgIH07XG5cbiAgICBjb25zdCBwYXJzZWRUcmFuc2Zvcm0gPSB0eXBlb2YgdGhpcy50cmFuc2Zvcm0gPT09ICdzdHJpbmcnID8gcGFyc2UudHJhbnNmb3JtKHRoaXMudHJhbnNmb3JtKSA6IHRoaXMudHJhbnNmb3JtO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIHRpdGxlOiB0aGlzLnRpdGxlLFxuICAgICAgdHJhbnNmb3JtOiBwYXJzZWRUcmFuc2Zvcm0sXG4gICAgICBjbGFzc2VzOiBbLi4uZmFDbGFzc0xpc3QoY2xhc3NPcHRzKSwgLi4udGhpcy5jbGFzc2VzXSxcbiAgICAgIG1hc2s6IHRoaXMubWFzayAhPSBudWxsID8gdGhpcy5maW5kSWNvbkRlZmluaXRpb24odGhpcy5tYXNrKSA6IG51bGwsXG4gICAgICBzdHlsZXM6IHRoaXMuc3R5bGVzICE9IG51bGwgPyB0aGlzLnN0eWxlcyA6IHt9LFxuICAgICAgc3ltYm9sOiB0aGlzLnN5bWJvbCxcbiAgICAgIGF0dHJpYnV0ZXM6IHtcbiAgICAgICAgcm9sZTogdGhpcy5hMTF5Um9sZVxuICAgICAgfVxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIHJlbmRlckljb24oZGVmaW5pdGlvbjogSWNvbkRlZmluaXRpb24sIHBhcmFtczogSWNvblBhcmFtcykge1xuICAgIGNvbnN0IHJlbmRlcmVkSWNvbiA9IGljb24oZGVmaW5pdGlvbiwgcGFyYW1zKTtcbiAgICB0aGlzLnJlbmRlcmVkSWNvbkhUTUwgPSB0aGlzLnNhbml0aXplci5ieXBhc3NTZWN1cml0eVRydXN0SHRtbChyZW5kZXJlZEljb24uaHRtbC5qb2luKCdcXG4nKSk7XG4gIH1cbn1cblxuIl19