/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Component, ElementRef, Input, Renderer2 } from '@angular/core';
var FaStackComponent = /** @class */ (function () {
    function FaStackComponent(renderer, elementRef) {
        this.renderer = renderer;
        this.elementRef = elementRef;
    }
    /**
     * @return {?}
     */
    FaStackComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        this.renderer.addClass(this.elementRef.nativeElement, 'fa-stack');
    };
    /**
     * @param {?} changes
     * @return {?}
     */
    FaStackComponent.prototype.ngOnChanges = /**
     * @param {?} changes
     * @return {?}
     */
    function (changes) {
        if ('size' in changes) {
            if (changes.size.currentValue != null) {
                this.renderer.addClass(this.elementRef.nativeElement, "fa-" + changes.size.currentValue);
            }
            if (changes.size.previousValue != null) {
                this.renderer.removeClass(this.elementRef.nativeElement, "fa-" + changes.size.previousValue);
            }
        }
    };
    FaStackComponent.decorators = [
        { type: Component, args: [{
                    selector: 'fa-stack',
                    // TODO: See if it is better to select fa-icon and throw if it does not have stackItemSize directive
                    template: "<ng-content select=\"fa-icon[stackItemSize],fa-duotone-icon[stackItemSize]\"></ng-content>"
                }] }
    ];
    /** @nocollapse */
    FaStackComponent.ctorParameters = function () { return [
        { type: Renderer2 },
        { type: ElementRef }
    ]; };
    FaStackComponent.propDecorators = {
        size: [{ type: Input }]
    };
    return FaStackComponent;
}());
export { FaStackComponent };
if (false) {
    /**
     * Size of the stacked icon.
     * Note that stacked icon is by default 2 times bigger, than non-stacked icon.
     * You'll need to set size using custom CSS to align stacked icon with a
     * simple one. E.g. `fa-stack { font-size: 0.5em; }`.
     * @type {?}
     */
    FaStackComponent.prototype.size;
    /**
     * @type {?}
     * @private
     */
    FaStackComponent.prototype.renderer;
    /**
     * @type {?}
     * @private
     */
    FaStackComponent.prototype.elementRef;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhY2suY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6Im5nOi8vQGZvcnRhd2Vzb21lL2FuZ3VsYXItZm9udGF3ZXNvbWUvIiwic291cmNlcyI6WyJzdGFjay9zdGFjay5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBcUIsU0FBUyxFQUFpQixNQUFNLGVBQWUsQ0FBQztBQUcxRztJQWNFLDBCQUNVLFFBQW1CLEVBQ25CLFVBQXNCO1FBRHRCLGFBQVEsR0FBUixRQUFRLENBQVc7UUFDbkIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtJQUVoQyxDQUFDOzs7O0lBRUQsbUNBQVE7OztJQUFSO1FBQ0UsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsVUFBVSxDQUFDLENBQUM7SUFDcEUsQ0FBQzs7Ozs7SUFFRCxzQ0FBVzs7OztJQUFYLFVBQVksT0FBc0I7UUFDaEMsSUFBSSxNQUFNLElBQUksT0FBTyxFQUFFO1lBQ3JCLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLElBQUksSUFBSSxFQUFFO2dCQUNyQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxRQUFNLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBYyxDQUFDLENBQUM7YUFDMUY7WUFDRCxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxJQUFJLElBQUksRUFBRTtnQkFDdEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsUUFBTSxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWUsQ0FBQyxDQUFDO2FBQzlGO1NBQ0Y7SUFDSCxDQUFDOztnQkFqQ0YsU0FBUyxTQUFDO29CQUNULFFBQVEsRUFBRSxVQUFVOztvQkFFcEIsUUFBUSxFQUFFLDRGQUEwRjtpQkFDckc7Ozs7Z0JBUHlELFNBQVM7Z0JBQS9DLFVBQVU7Ozt1QkFlM0IsS0FBSzs7SUFzQlIsdUJBQUM7Q0FBQSxBQWxDRCxJQWtDQztTQTdCWSxnQkFBZ0I7Ozs7Ozs7OztJQU8zQixnQ0FBeUI7Ozs7O0lBR3ZCLG9DQUEyQjs7Ozs7SUFDM0Isc0NBQThCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBFbGVtZW50UmVmLCBJbnB1dCwgT25DaGFuZ2VzLCBPbkluaXQsIFJlbmRlcmVyMiwgU2ltcGxlQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgU2l6ZVByb3AgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdmYS1zdGFjaycsXG4gIC8vIFRPRE86IFNlZSBpZiBpdCBpcyBiZXR0ZXIgdG8gc2VsZWN0IGZhLWljb24gYW5kIHRocm93IGlmIGl0IGRvZXMgbm90IGhhdmUgc3RhY2tJdGVtU2l6ZSBkaXJlY3RpdmVcbiAgdGVtcGxhdGU6IGA8bmctY29udGVudCBzZWxlY3Q9XCJmYS1pY29uW3N0YWNrSXRlbVNpemVdLGZhLWR1b3RvbmUtaWNvbltzdGFja0l0ZW1TaXplXVwiPjwvbmctY29udGVudD5gLFxufSlcbmV4cG9ydCBjbGFzcyBGYVN0YWNrQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMge1xuICAvKipcbiAgICogU2l6ZSBvZiB0aGUgc3RhY2tlZCBpY29uLlxuICAgKiBOb3RlIHRoYXQgc3RhY2tlZCBpY29uIGlzIGJ5IGRlZmF1bHQgMiB0aW1lcyBiaWdnZXIsIHRoYW4gbm9uLXN0YWNrZWQgaWNvbi5cbiAgICogWW91J2xsIG5lZWQgdG8gc2V0IHNpemUgdXNpbmcgY3VzdG9tIENTUyB0byBhbGlnbiBzdGFja2VkIGljb24gd2l0aCBhXG4gICAqIHNpbXBsZSBvbmUuIEUuZy4gYGZhLXN0YWNrIHsgZm9udC1zaXplOiAwLjVlbTsgfWAuXG4gICAqL1xuICBASW5wdXQoKSBzaXplPzogU2l6ZVByb3A7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSByZW5kZXJlcjogUmVuZGVyZXIyLFxuICAgIHByaXZhdGUgZWxlbWVudFJlZjogRWxlbWVudFJlZixcbiAgKSB7XG4gIH1cblxuICBuZ09uSW5pdCgpIHtcbiAgICB0aGlzLnJlbmRlcmVyLmFkZENsYXNzKHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LCAnZmEtc3RhY2snKTtcbiAgfVxuXG4gIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcbiAgICBpZiAoJ3NpemUnIGluIGNoYW5nZXMpIHtcbiAgICAgIGlmIChjaGFuZ2VzLnNpemUuY3VycmVudFZhbHVlICE9IG51bGwpIHtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5hZGRDbGFzcyh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgYGZhLSR7Y2hhbmdlcy5zaXplLmN1cnJlbnRWYWx1ZX1gKTtcbiAgICAgIH1cbiAgICAgIGlmIChjaGFuZ2VzLnNpemUucHJldmlvdXNWYWx1ZSAhPSBudWxsKSB7XG4gICAgICAgIHRoaXMucmVuZGVyZXIucmVtb3ZlQ2xhc3ModGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQsIGBmYS0ke2NoYW5nZXMuc2l6ZS5wcmV2aW91c1ZhbHVlfWApO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuIl19