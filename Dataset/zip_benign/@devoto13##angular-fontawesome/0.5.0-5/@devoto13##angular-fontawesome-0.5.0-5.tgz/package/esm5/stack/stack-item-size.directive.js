/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Directive, Input } from '@angular/core';
var FaStackItemSizeDirective = /** @class */ (function () {
    function FaStackItemSizeDirective() {
        /**
         * Specify whether icon inside {\@link FaStackComponent} should be rendered in
         * regular size (1x) or as a larger icon (2x).
         */
        this.stackItemSize = '1x';
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    FaStackItemSizeDirective.prototype.ngOnChanges = /**
     * @param {?} changes
     * @return {?}
     */
    function (changes) {
        if ('size' in changes) {
            throw new Error('fa-icon is not allowed to customize size when used inside fa-stack. ' +
                'Set size on the enclosing fa-stack instead: <fa-stack size="4x">...</fa-stack>.');
        }
    };
    FaStackItemSizeDirective.decorators = [
        { type: Directive, args: [{
                    selector: 'fa-icon[stackItemSize],fa-duotone-icon[stackItemSize]',
                },] }
    ];
    FaStackItemSizeDirective.propDecorators = {
        stackItemSize: [{ type: Input }],
        size: [{ type: Input }]
    };
    return FaStackItemSizeDirective;
}());
export { FaStackItemSizeDirective };
if (false) {
    /**
     * Specify whether icon inside {\@link FaStackComponent} should be rendered in
     * regular size (1x) or as a larger icon (2x).
     * @type {?}
     */
    FaStackItemSizeDirective.prototype.stackItemSize;
    /**
     * \@internal
     * @type {?}
     */
    FaStackItemSizeDirective.prototype.size;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhY2staXRlbS1zaXplLmRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0Bmb3J0YXdlc29tZS9hbmd1bGFyLWZvbnRhd2Vzb21lLyIsInNvdXJjZXMiOlsic3RhY2svc3RhY2staXRlbS1zaXplLmRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQTRCLE1BQU0sZUFBZSxDQUFDO0FBSTNFO0lBQUE7Ozs7O1FBUVcsa0JBQWEsR0FBZ0IsSUFBSSxDQUFDO0lBYzdDLENBQUM7Ozs7O0lBUEMsOENBQVc7Ozs7SUFBWCxVQUFZLE9BQXNCO1FBQ2hDLElBQUksTUFBTSxJQUFJLE9BQU8sRUFBRTtZQUNyQixNQUFNLElBQUksS0FBSyxDQUNiLHNFQUFzRTtnQkFDdEUsaUZBQWlGLENBQUMsQ0FBQztTQUN0RjtJQUNILENBQUM7O2dCQXJCRixTQUFTLFNBQUM7b0JBQ1QsUUFBUSxFQUFFLHVEQUF1RDtpQkFDbEU7OztnQ0FNRSxLQUFLO3VCQUtMLEtBQUs7O0lBU1IsK0JBQUM7Q0FBQSxBQXRCRCxJQXNCQztTQW5CWSx3QkFBd0I7Ozs7Ozs7SUFLbkMsaURBQTJDOzs7OztJQUszQyx3Q0FBeUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaXJlY3RpdmUsIElucHV0LCBPbkNoYW5nZXMsIFNpbXBsZUNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFNpemVQcm9wIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZvbnRhd2Vzb21lLXN2Zy1jb3JlJztcbmltcG9ydCB7IEZhU3RhY2tDb21wb25lbnR9IGZyb20gJy4vc3RhY2suY29tcG9uZW50JztcblxuQERpcmVjdGl2ZSh7XG4gIHNlbGVjdG9yOiAnZmEtaWNvbltzdGFja0l0ZW1TaXplXSxmYS1kdW90b25lLWljb25bc3RhY2tJdGVtU2l6ZV0nLFxufSlcbmV4cG9ydCBjbGFzcyBGYVN0YWNrSXRlbVNpemVEaXJlY3RpdmUgaW1wbGVtZW50cyBPbkNoYW5nZXMge1xuICAvKipcbiAgICogU3BlY2lmeSB3aGV0aGVyIGljb24gaW5zaWRlIHtAbGluayBGYVN0YWNrQ29tcG9uZW50fSBzaG91bGQgYmUgcmVuZGVyZWQgaW5cbiAgICogcmVndWxhciBzaXplICgxeCkgb3IgYXMgYSBsYXJnZXIgaWNvbiAoMngpLlxuICAgKi9cbiAgQElucHV0KCkgc3RhY2tJdGVtU2l6ZTogJzF4JyB8ICcyeCcgPSAnMXgnO1xuXG4gIC8qKlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIEBJbnB1dCgpIHNpemU/OiBTaXplUHJvcDtcblxuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XG4gICAgaWYgKCdzaXplJyBpbiBjaGFuZ2VzKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdmYS1pY29uIGlzIG5vdCBhbGxvd2VkIHRvIGN1c3RvbWl6ZSBzaXplIHdoZW4gdXNlZCBpbnNpZGUgZmEtc3RhY2suICcgK1xuICAgICAgICAnU2V0IHNpemUgb24gdGhlIGVuY2xvc2luZyBmYS1zdGFjayBpbnN0ZWFkOiA8ZmEtc3RhY2sgc2l6ZT1cIjR4XCI+Li4uPC9mYS1zdGFjaz4uJyk7XG4gICAgfVxuICB9XG59XG4iXX0=