/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
export var faWarnIfIconDefinitionMissing = (/**
 * @param {?} iconSpec
 * @return {?}
 */
function (iconSpec) {
    console.error("FontAwesome: Could not find icon with iconName=" + iconSpec.iconName + " and prefix=" + iconSpec.prefix + ". " +
        "This warning will become a hard error in 0.6.0.");
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2Fybi1pZi1pY29uLWh0bWwtbWlzc2luZy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0Bmb3J0YXdlc29tZS9hbmd1bGFyLWZvbnRhd2Vzb21lLyIsInNvdXJjZXMiOlsic2hhcmVkL2Vycm9ycy93YXJuLWlmLWljb24taHRtbC1taXNzaW5nLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBRUEsTUFBTSxLQUFPLDZCQUE2Qjs7OztBQUFHLFVBQUMsUUFBb0I7SUFDaEUsT0FBTyxDQUFDLEtBQUssQ0FDWCxvREFBa0QsUUFBUSxDQUFDLFFBQVEsb0JBQWUsUUFBUSxDQUFDLE1BQU0sT0FBSTtRQUNyRyxpREFBaUQsQ0FDbEQsQ0FBQztBQUNKLENBQUMsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEljb25Mb29rdXAgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuXG5leHBvcnQgY29uc3QgZmFXYXJuSWZJY29uRGVmaW5pdGlvbk1pc3NpbmcgPSAoaWNvblNwZWM6IEljb25Mb29rdXApID0+IHtcbiAgY29uc29sZS5lcnJvcihcbiAgICBgRm9udEF3ZXNvbWU6IENvdWxkIG5vdCBmaW5kIGljb24gd2l0aCBpY29uTmFtZT0ke2ljb25TcGVjLmljb25OYW1lfSBhbmQgcHJlZml4PSR7aWNvblNwZWMucHJlZml4fS4gYCArXG4gICAgYFRoaXMgd2FybmluZyB3aWxsIGJlY29tZSBhIGhhcmQgZXJyb3IgaW4gMC42LjAuYFxuICApO1xufTtcbiJdfQ==