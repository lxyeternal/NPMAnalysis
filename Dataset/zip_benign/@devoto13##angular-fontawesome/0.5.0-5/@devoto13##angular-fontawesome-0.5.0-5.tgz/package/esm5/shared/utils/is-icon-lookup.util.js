/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Returns if is IconLookup or not.
 * @type {?}
 */
export var isIconLookup = (/**
 * @param {?} i
 * @return {?}
 */
function (i) {
    return ((/** @type {?} */ (i))).prefix !== undefined && ((/** @type {?} */ (i))).iconName !== undefined;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXMtaWNvbi1sb29rdXAudXRpbC5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0Bmb3J0YXdlc29tZS9hbmd1bGFyLWZvbnRhd2Vzb21lLyIsInNvdXJjZXMiOlsic2hhcmVkL3V0aWxzL2lzLWljb24tbG9va3VwLnV0aWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFLQSxNQUFNLEtBQU8sWUFBWTs7OztBQUFHLFVBQUMsQ0FBVztJQUN0QyxPQUFPLENBQUMsbUJBQVksQ0FBQyxFQUFBLENBQUMsQ0FBQyxNQUFNLEtBQUssU0FBUyxJQUFJLENBQUMsbUJBQVksQ0FBQyxFQUFBLENBQUMsQ0FBQyxRQUFRLEtBQUssU0FBUyxDQUFDO0FBQ3hGLENBQUMsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7SWNvbkxvb2t1cCwgSWNvblByb3B9IGZyb20gJ0Bmb3J0YXdlc29tZS9mb250YXdlc29tZS1zdmctY29yZSc7XG5cbi8qKlxuICogUmV0dXJucyBpZiBpcyBJY29uTG9va3VwIG9yIG5vdC5cbiAqL1xuZXhwb3J0IGNvbnN0IGlzSWNvbkxvb2t1cCA9IChpOiBJY29uUHJvcCk6IGkgaXMgSWNvbkxvb2t1cCA9PiB7XG4gIHJldHVybiAoPEljb25Mb29rdXA+aSkucHJlZml4ICE9PSB1bmRlZmluZWQgJiYgKDxJY29uTG9va3VwPmkpLmljb25OYW1lICE9PSB1bmRlZmluZWQ7XG59O1xuIl19