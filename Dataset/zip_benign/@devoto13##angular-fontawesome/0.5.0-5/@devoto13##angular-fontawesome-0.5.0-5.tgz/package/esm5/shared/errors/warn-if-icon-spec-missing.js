/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
export var faWarnIfIconSpecMissing = (/**
 * @return {?}
 */
function () {
    console.error('FontAwesome: Property `icon` is required for `fa-icon`/`fa-duotone-icon` components. ' +
        "This warning will become a hard error in 0.6.0.");
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2Fybi1pZi1pY29uLXNwZWMtbWlzc2luZy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0Bmb3J0YXdlc29tZS9hbmd1bGFyLWZvbnRhd2Vzb21lLyIsInNvdXJjZXMiOlsic2hhcmVkL2Vycm9ycy93YXJuLWlmLWljb24tc3BlYy1taXNzaW5nLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsTUFBTSxLQUFPLHVCQUF1Qjs7O0FBQUc7SUFDckMsT0FBTyxDQUFDLEtBQUssQ0FBQyx1RkFBdUY7UUFDbkcsaURBQWlELENBQUMsQ0FBQztBQUN2RCxDQUFDLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgZmFXYXJuSWZJY29uU3BlY01pc3NpbmcgPSAoKSA9PiB7XG4gIGNvbnNvbGUuZXJyb3IoJ0ZvbnRBd2Vzb21lOiBQcm9wZXJ0eSBgaWNvbmAgaXMgcmVxdWlyZWQgZm9yIGBmYS1pY29uYC9gZmEtZHVvdG9uZS1pY29uYCBjb21wb25lbnRzLiAnICtcbiAgICBgVGhpcyB3YXJuaW5nIHdpbGwgYmVjb21lIGEgaGFyZCBlcnJvciBpbiAwLjYuMC5gKTtcbn07XG4iXX0=