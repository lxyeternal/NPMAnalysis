/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { isIconLookup } from './is-icon-lookup.util';
/**
 * Normalizing icon spec.
 * @type {?}
 */
export var faNormalizeIconSpec = (/**
 * @param {?} iconSpec
 * @param {?} defaultPrefix
 * @return {?}
 */
function (iconSpec, defaultPrefix) {
    if (isIconLookup(iconSpec)) {
        return iconSpec;
    }
    if (Array.isArray(iconSpec) && ((/** @type {?} */ (iconSpec))).length === 2) {
        return { prefix: iconSpec[0], iconName: iconSpec[1] };
    }
    if (typeof iconSpec === 'string') {
        return { prefix: defaultPrefix, iconName: iconSpec };
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibm9ybWFsaXplLWljb24tc3BlYy51dGlsLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQGZvcnRhd2Vzb21lL2FuZ3VsYXItZm9udGF3ZXNvbWUvIiwic291cmNlcyI6WyJzaGFyZWQvdXRpbHMvbm9ybWFsaXplLWljb24tc3BlYy51dGlsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFDQSxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7Ozs7O0FBS3JELE1BQU0sS0FBTyxtQkFBbUI7Ozs7O0FBQUcsVUFDakMsUUFBbUMsRUFDbkMsYUFBeUI7SUFFekIsSUFBSSxZQUFZLENBQUMsUUFBUSxDQUFDLEVBQUU7UUFDMUIsT0FBTyxRQUFRLENBQUM7S0FDakI7SUFFRCxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxtQkFBZSxRQUFRLEVBQUEsQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7UUFDckUsT0FBTyxFQUFFLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0tBQ3ZEO0lBRUQsSUFBSSxPQUFPLFFBQVEsS0FBSyxRQUFRLEVBQUU7UUFDaEMsT0FBTyxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxDQUFDO0tBQ3REO0FBQ0gsQ0FBQyxDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSWNvbkRlZmluaXRpb24sIEljb25Mb29rdXAsIEljb25QcmVmaXgsIEljb25Qcm9wIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZvbnRhd2Vzb21lLXN2Zy1jb3JlJztcbmltcG9ydCB7IGlzSWNvbkxvb2t1cCB9IGZyb20gJy4vaXMtaWNvbi1sb29rdXAudXRpbCc7XG5cbi8qKlxuICogTm9ybWFsaXppbmcgaWNvbiBzcGVjLlxuICovXG5leHBvcnQgY29uc3QgZmFOb3JtYWxpemVJY29uU3BlYyA9IChcbiAgaWNvblNwZWM6IEljb25Qcm9wIHwgSWNvbkRlZmluaXRpb24sXG4gIGRlZmF1bHRQcmVmaXg6IEljb25QcmVmaXhcbik6IEljb25Mb29rdXAgfCBJY29uRGVmaW5pdGlvbiA9PiB7XG4gIGlmIChpc0ljb25Mb29rdXAoaWNvblNwZWMpKSB7XG4gICAgcmV0dXJuIGljb25TcGVjO1xuICB9XG5cbiAgaWYgKEFycmF5LmlzQXJyYXkoaWNvblNwZWMpICYmICg8QXJyYXk8c3RyaW5nPj5pY29uU3BlYykubGVuZ3RoID09PSAyKSB7XG4gICAgcmV0dXJuIHsgcHJlZml4OiBpY29uU3BlY1swXSwgaWNvbk5hbWU6IGljb25TcGVjWzFdIH07XG4gIH1cblxuICBpZiAodHlwZW9mIGljb25TcGVjID09PSAnc3RyaW5nJykge1xuICAgIHJldHVybiB7IHByZWZpeDogZGVmYXVsdFByZWZpeCwgaWNvbk5hbWU6IGljb25TcGVjIH07XG4gIH1cbn07XG4iXX0=