/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Fontawesome class list.
 * Returns classes array by props.
 * @type {?}
 */
export var faClassList = (/**
 * @param {?} props
 * @return {?}
 */
function (props) {
    var _a;
    /** @type {?} */
    var classes = (_a = {
            'fa-spin': props.spin,
            'fa-pulse': props.pulse,
            'fa-fw': props.fixedWidth,
            'fa-border': props.border,
            'fa-li': props.listItem,
            'fa-inverse': props.inverse,
            'fa-layers-counter': props.counter,
            'fa-flip-horizontal': props.flip === 'horizontal' || props.flip === 'both',
            'fa-flip-vertical': props.flip === 'vertical' || props.flip === 'both'
        },
        _a["fa-" + props.size] = props.size !== null,
        _a["fa-rotate-" + props.rotate] = props.rotate !== null,
        _a["fa-pull-" + props.pull] = props.pull !== null,
        _a["fa-stack-" + props.stackItemSize] = props.stackItemSize != null,
        _a);
    return Object.keys(classes)
        .map((/**
     * @param {?} key
     * @return {?}
     */
    function (key) { return (classes[key] ? key : null); }))
        .filter((/**
     * @param {?} key
     * @return {?}
     */
    function (key) { return key; }));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xhc3NsaXN0LnV0aWwuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AZm9ydGF3ZXNvbWUvYW5ndWxhci1mb250YXdlc29tZS8iLCJzb3VyY2VzIjpbInNoYXJlZC91dGlscy9jbGFzc2xpc3QudXRpbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFNQSxNQUFNLEtBQU8sV0FBVzs7OztBQUFHLFVBQUMsS0FBYzs7O1FBQ2xDLE9BQU87WUFDWCxTQUFTLEVBQUUsS0FBSyxDQUFDLElBQUk7WUFDckIsVUFBVSxFQUFFLEtBQUssQ0FBQyxLQUFLO1lBQ3ZCLE9BQU8sRUFBRSxLQUFLLENBQUMsVUFBVTtZQUN6QixXQUFXLEVBQUUsS0FBSyxDQUFDLE1BQU07WUFDekIsT0FBTyxFQUFFLEtBQUssQ0FBQyxRQUFRO1lBQ3ZCLFlBQVksRUFBRSxLQUFLLENBQUMsT0FBTztZQUMzQixtQkFBbUIsRUFBRSxLQUFLLENBQUMsT0FBTztZQUNsQyxvQkFBb0IsRUFBRSxLQUFLLENBQUMsSUFBSSxLQUFLLFlBQVksSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLE1BQU07WUFDMUUsa0JBQWtCLEVBQUUsS0FBSyxDQUFDLElBQUksS0FBSyxVQUFVLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxNQUFNOztRQUN0RSxHQUFDLFFBQU0sS0FBSyxDQUFDLElBQU0sSUFBRyxLQUFLLENBQUMsSUFBSSxLQUFLLElBQUk7UUFDekMsR0FBQyxlQUFhLEtBQUssQ0FBQyxNQUFRLElBQUcsS0FBSyxDQUFDLE1BQU0sS0FBSyxJQUFJO1FBQ3BELEdBQUMsYUFBVyxLQUFLLENBQUMsSUFBTSxJQUFHLEtBQUssQ0FBQyxJQUFJLEtBQUssSUFBSTtRQUM5QyxHQUFDLGNBQVksS0FBSyxDQUFDLGFBQWUsSUFBRyxLQUFLLENBQUMsYUFBYSxJQUFJLElBQUk7V0FDakU7SUFFRCxPQUFPLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO1NBQ3hCLEdBQUc7Ozs7SUFBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUEzQixDQUEyQixFQUFDO1NBQ3ZDLE1BQU07Ozs7SUFBQyxVQUFBLEdBQUcsSUFBSSxPQUFBLEdBQUcsRUFBSCxDQUFHLEVBQUMsQ0FBQztBQUN4QixDQUFDLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGYVByb3BzIH0gZnJvbSAnLi4vbW9kZWxzL3Byb3BzLm1vZGVsJztcblxuLyoqXG4gKiBGb250YXdlc29tZSBjbGFzcyBsaXN0LlxuICogUmV0dXJucyBjbGFzc2VzIGFycmF5IGJ5IHByb3BzLlxuICovXG5leHBvcnQgY29uc3QgZmFDbGFzc0xpc3QgPSAocHJvcHM6IEZhUHJvcHMpOiBzdHJpbmdbXSA9PiB7XG4gIGNvbnN0IGNsYXNzZXMgPSB7XG4gICAgJ2ZhLXNwaW4nOiBwcm9wcy5zcGluLFxuICAgICdmYS1wdWxzZSc6IHByb3BzLnB1bHNlLFxuICAgICdmYS1mdyc6IHByb3BzLmZpeGVkV2lkdGgsXG4gICAgJ2ZhLWJvcmRlcic6IHByb3BzLmJvcmRlcixcbiAgICAnZmEtbGknOiBwcm9wcy5saXN0SXRlbSxcbiAgICAnZmEtaW52ZXJzZSc6IHByb3BzLmludmVyc2UsXG4gICAgJ2ZhLWxheWVycy1jb3VudGVyJzogcHJvcHMuY291bnRlcixcbiAgICAnZmEtZmxpcC1ob3Jpem9udGFsJzogcHJvcHMuZmxpcCA9PT0gJ2hvcml6b250YWwnIHx8IHByb3BzLmZsaXAgPT09ICdib3RoJyxcbiAgICAnZmEtZmxpcC12ZXJ0aWNhbCc6IHByb3BzLmZsaXAgPT09ICd2ZXJ0aWNhbCcgfHwgcHJvcHMuZmxpcCA9PT0gJ2JvdGgnLFxuICAgIFtgZmEtJHtwcm9wcy5zaXplfWBdOiBwcm9wcy5zaXplICE9PSBudWxsLFxuICAgIFtgZmEtcm90YXRlLSR7cHJvcHMucm90YXRlfWBdOiBwcm9wcy5yb3RhdGUgIT09IG51bGwsXG4gICAgW2BmYS1wdWxsLSR7cHJvcHMucHVsbH1gXTogcHJvcHMucHVsbCAhPT0gbnVsbCxcbiAgICBbYGZhLXN0YWNrLSR7cHJvcHMuc3RhY2tJdGVtU2l6ZX1gXTogcHJvcHMuc3RhY2tJdGVtU2l6ZSAhPSBudWxsLFxuICB9O1xuXG4gIHJldHVybiBPYmplY3Qua2V5cyhjbGFzc2VzKVxuICAgIC5tYXAoa2V5ID0+IChjbGFzc2VzW2tleV0gPyBrZXkgOiBudWxsKSlcbiAgICAuZmlsdGVyKGtleSA9PiBrZXkpO1xufTtcbiJdfQ==