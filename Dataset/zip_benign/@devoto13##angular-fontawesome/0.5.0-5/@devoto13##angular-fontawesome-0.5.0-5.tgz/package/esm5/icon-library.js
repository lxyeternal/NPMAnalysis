/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
var FaIconLibrary = /** @class */ (function () {
    function FaIconLibrary() {
        this.definitions = {};
    }
    /**
     * @param {...?} icons
     * @return {?}
     */
    FaIconLibrary.prototype.addIcons = /**
     * @param {...?} icons
     * @return {?}
     */
    function () {
        var icons = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            icons[_i] = arguments[_i];
        }
        for (var i = 0; i < icons.length; i++) {
            /** @type {?} */
            var icon = icons[i];
            if (!(icon.prefix in this.definitions)) {
                this.definitions[icon.prefix] = {};
            }
            this.definitions[icon.prefix][icon.iconName] = icon;
        }
    };
    /**
     * @param {...?} packs
     * @return {?}
     */
    FaIconLibrary.prototype.addIconPacks = /**
     * @param {...?} packs
     * @return {?}
     */
    function () {
        var packs = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            packs[_i] = arguments[_i];
        }
        var _loop_1 = function (i) {
            /** @type {?} */
            var pack = packs[i];
            /** @type {?} */
            var icons = Object.keys(pack).map((/**
             * @param {?} key
             * @return {?}
             */
            function (key) { return pack[key]; }));
            this_1.addIcons.apply(this_1, tslib_1.__spread(icons));
        };
        var this_1 = this;
        for (var i = 0; i < packs.length; i++) {
            _loop_1(i);
        }
    };
    /**
     * @param {?} prefix
     * @param {?} name
     * @return {?}
     */
    FaIconLibrary.prototype.getIconDefinition = /**
     * @param {?} prefix
     * @param {?} name
     * @return {?}
     */
    function (prefix, name) {
        if (prefix in this.definitions && name in this.definitions[prefix]) {
            return this.definitions[prefix][name];
        }
        return null;
    };
    FaIconLibrary.decorators = [
        { type: Injectable, args: [{ providedIn: 'root' },] }
    ];
    /** @nocollapse */ FaIconLibrary.ngInjectableDef = i0.ɵɵdefineInjectable({ factory: function FaIconLibrary_Factory() { return new FaIconLibrary(); }, token: FaIconLibrary, providedIn: "root" });
    return FaIconLibrary;
}());
export { FaIconLibrary };
if (false) {
    /**
     * @type {?}
     * @private
     */
    FaIconLibrary.prototype.definitions;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWNvbi1saWJyYXJ5LmpzIiwic291cmNlUm9vdCI6Im5nOi8vQGZvcnRhd2Vzb21lL2FuZ3VsYXItZm9udGF3ZXNvbWUvIiwic291cmNlcyI6WyJpY29uLWxpYnJhcnkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDOztBQUczQztJQUFBO1FBRVUsZ0JBQVcsR0FBNkQsRUFBRSxDQUFDO0tBMEJwRjs7Ozs7SUF4QkMsZ0NBQVE7Ozs7SUFBUjtRQUFTLGVBQTBCO2FBQTFCLFVBQTBCLEVBQTFCLHFCQUEwQixFQUExQixJQUEwQjtZQUExQiwwQkFBMEI7O1FBQ2pDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFOztnQkFDL0IsSUFBSSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFDckIsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUU7Z0JBQ3RDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUUsQ0FBQzthQUNwQztZQUNELElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUM7U0FDckQ7SUFDSCxDQUFDOzs7OztJQUVELG9DQUFZOzs7O0lBQVo7UUFBYSxlQUFvQjthQUFwQixVQUFvQixFQUFwQixxQkFBb0IsRUFBcEIsSUFBb0I7WUFBcEIsMEJBQW9COztnQ0FDdEIsQ0FBQzs7Z0JBQ0YsSUFBSSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUM7O2dCQUNmLEtBQUssR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUc7Ozs7WUFBQyxVQUFDLEdBQUcsSUFBSyxPQUFBLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBVCxDQUFTLEVBQUM7WUFDdkQsT0FBSyxRQUFRLGdDQUFJLEtBQUssR0FBRTs7O1FBSDFCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRTtvQkFBNUIsQ0FBQztTQUlUO0lBQ0gsQ0FBQzs7Ozs7O0lBRUQseUNBQWlCOzs7OztJQUFqQixVQUFrQixNQUFrQixFQUFFLElBQWM7UUFDbEQsSUFBSSxNQUFNLElBQUksSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNsRSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDdkM7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7O2dCQTNCRixVQUFVLFNBQUMsRUFBQyxVQUFVLEVBQUUsTUFBTSxFQUFDOzs7d0JBSGhDO0NBK0JDLEFBNUJELElBNEJDO1NBM0JZLGFBQWE7Ozs7OztJQUN4QixvQ0FBbUYiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJY29uRGVmaW5pdGlvbiwgSWNvbk5hbWUsIEljb25QYWNrLCBJY29uUHJlZml4IH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZvbnRhd2Vzb21lLXN2Zy1jb3JlJztcblxuQEluamVjdGFibGUoe3Byb3ZpZGVkSW46ICdyb290J30pXG5leHBvcnQgY2xhc3MgRmFJY29uTGlicmFyeSB7XG4gIHByaXZhdGUgZGVmaW5pdGlvbnM6IHsgW3ByZWZpeDogc3RyaW5nXTogeyBbbmFtZTogc3RyaW5nXTogSWNvbkRlZmluaXRpb24gfSB9ID0ge307XG5cbiAgYWRkSWNvbnMoLi4uaWNvbnM6IEljb25EZWZpbml0aW9uW10pIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGljb25zLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBpY29uID0gaWNvbnNbaV07XG4gICAgICBpZiAoIShpY29uLnByZWZpeCBpbiB0aGlzLmRlZmluaXRpb25zKSkge1xuICAgICAgICB0aGlzLmRlZmluaXRpb25zW2ljb24ucHJlZml4XSA9IHt9O1xuICAgICAgfVxuICAgICAgdGhpcy5kZWZpbml0aW9uc1tpY29uLnByZWZpeF1baWNvbi5pY29uTmFtZV0gPSBpY29uO1xuICAgIH1cbiAgfVxuXG4gIGFkZEljb25QYWNrcyguLi5wYWNrczogSWNvblBhY2tbXSkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcGFja3MubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IHBhY2sgPSBwYWNrc1tpXTtcbiAgICAgIGNvbnN0IGljb25zID0gT2JqZWN0LmtleXMocGFjaykubWFwKChrZXkpID0+IHBhY2tba2V5XSk7XG4gICAgICB0aGlzLmFkZEljb25zKC4uLmljb25zKTtcbiAgICB9XG4gIH1cblxuICBnZXRJY29uRGVmaW5pdGlvbihwcmVmaXg6IEljb25QcmVmaXgsIG5hbWU6IEljb25OYW1lKTogSWNvbkRlZmluaXRpb24gfCBudWxsIHtcbiAgICBpZiAocHJlZml4IGluIHRoaXMuZGVmaW5pdGlvbnMgJiYgbmFtZSBpbiB0aGlzLmRlZmluaXRpb25zW3ByZWZpeF0pIHtcbiAgICAgIHJldHVybiB0aGlzLmRlZmluaXRpb25zW3ByZWZpeF1bbmFtZV07XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG59XG4iXX0=