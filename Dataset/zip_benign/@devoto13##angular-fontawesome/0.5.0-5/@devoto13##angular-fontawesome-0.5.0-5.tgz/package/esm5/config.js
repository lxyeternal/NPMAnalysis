/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
var FaConfig = /** @class */ (function () {
    function FaConfig() {
        /**
         * Default prefix to use, when one is not provided with the icon name.
         *
         * \@default 'fas'
         */
        this.defaultPrefix = 'fas';
        /**
         * Whether components should lookup icon definitions in the global icon
         * library (the one available from
         * `import { library } from '\@fortawesome/fontawesome-svg-core')`.
         *
         * See https://github.com/FortAwesome/angular-fontawesome/blob/master/docs/usage/icon-library.md
         * for detailed description of library modes.
         *
         * - 'unset' - Components should lookup icon definitions in the global library
         * and emit warning if they find a definition there. This option is a default
         * to assist existing applications with a migration. Applications are expected
         * to switch to using {\@link FaIconLibrary}.
         * - true - Components should lookup icon definitions in the global library.
         * Note that global icon library is deprecated and support for it will be
         * removed. This option can be used to temporarily suppress warnings.
         * - false - Components should not lookup icon definitions in the global
         * library. Library will throw an error if missing icon is found in the global
         * library.
         *
         * @deprecated This option is deprecated since 0.5.0. In 0.6.0 default will
         * be changed to false. In 0.7.0 the option will be removed together with the
         * support for the global icon library.
         *
         * \@default 'unset'
         */
        this.globalLibrary = 'unset';
    }
    FaConfig.decorators = [
        { type: Injectable, args: [{ providedIn: 'root' },] }
    ];
    /** @nocollapse */ FaConfig.ngInjectableDef = i0.ɵɵdefineInjectable({ factory: function FaConfig_Factory() { return new FaConfig(); }, token: FaConfig, providedIn: "root" });
    return FaConfig;
}());
export { FaConfig };
if (false) {
    /**
     * Default prefix to use, when one is not provided with the icon name.
     *
     * \@default 'fas'
     * @type {?}
     */
    FaConfig.prototype.defaultPrefix;
    /**
     * Whether components should lookup icon definitions in the global icon
     * library (the one available from
     * `import { library } from '\@fortawesome/fontawesome-svg-core')`.
     *
     * See https://github.com/FortAwesome/angular-fontawesome/blob/master/docs/usage/icon-library.md
     * for detailed description of library modes.
     *
     * - 'unset' - Components should lookup icon definitions in the global library
     * and emit warning if they find a definition there. This option is a default
     * to assist existing applications with a migration. Applications are expected
     * to switch to using {\@link FaIconLibrary}.
     * - true - Components should lookup icon definitions in the global library.
     * Note that global icon library is deprecated and support for it will be
     * removed. This option can be used to temporarily suppress warnings.
     * - false - Components should not lookup icon definitions in the global
     * library. Library will throw an error if missing icon is found in the global
     * library.
     *
     * @deprecated This option is deprecated since 0.5.0. In 0.6.0 default will
     * be changed to false. In 0.7.0 the option will be removed together with the
     * support for the global icon library.
     *
     * \@default 'unset'
     * @type {?}
     */
    FaConfig.prototype.globalLibrary;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQGZvcnRhd2Vzb21lL2FuZ3VsYXItZm9udGF3ZXNvbWUvIiwic291cmNlcyI6WyJjb25maWcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBSTNDO0lBQUE7Ozs7OztRQU9FLGtCQUFhLEdBQWUsS0FBSyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztRQTJCbEMsa0JBQWEsR0FBc0IsT0FBTyxDQUFDO0tBQzVDOztnQkFuQ0EsVUFBVSxTQUFDLEVBQUMsVUFBVSxFQUFFLE1BQU0sRUFBQzs7O21CQUpoQztDQXVDQyxBQW5DRCxJQW1DQztTQWxDWSxRQUFROzs7Ozs7OztJQU1uQixpQ0FBa0M7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQTJCbEMsaUNBQTJDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSWNvblByZWZpeCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mb250YXdlc29tZS1jb21tb24tdHlwZXMnO1xuaW1wb3J0IHsgRmFJY29uTGlicmFyeSB9IGZyb20gJy4vaWNvbi1saWJyYXJ5JztcblxuQEluamVjdGFibGUoe3Byb3ZpZGVkSW46ICdyb290J30pXG5leHBvcnQgY2xhc3MgRmFDb25maWcge1xuICAvKipcbiAgICogRGVmYXVsdCBwcmVmaXggdG8gdXNlLCB3aGVuIG9uZSBpcyBub3QgcHJvdmlkZWQgd2l0aCB0aGUgaWNvbiBuYW1lLlxuICAgKlxuICAgKiBAZGVmYXVsdCAnZmFzJ1xuICAgKi9cbiAgZGVmYXVsdFByZWZpeDogSWNvblByZWZpeCA9ICdmYXMnO1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIGNvbXBvbmVudHMgc2hvdWxkIGxvb2t1cCBpY29uIGRlZmluaXRpb25zIGluIHRoZSBnbG9iYWwgaWNvblxuICAgKiBsaWJyYXJ5ICh0aGUgb25lIGF2YWlsYWJsZSBmcm9tXG4gICAqIGBpbXBvcnQgeyBsaWJyYXJ5IH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZvbnRhd2Vzb21lLXN2Zy1jb3JlJylgLlxuICAgKlxuICAgKiBTZWUgaHR0cHM6Ly9naXRodWIuY29tL0ZvcnRBd2Vzb21lL2FuZ3VsYXItZm9udGF3ZXNvbWUvYmxvYi9tYXN0ZXIvZG9jcy91c2FnZS9pY29uLWxpYnJhcnkubWRcbiAgICogZm9yIGRldGFpbGVkIGRlc2NyaXB0aW9uIG9mIGxpYnJhcnkgbW9kZXMuXG4gICAqXG4gICAqIC0gJ3Vuc2V0JyAtIENvbXBvbmVudHMgc2hvdWxkIGxvb2t1cCBpY29uIGRlZmluaXRpb25zIGluIHRoZSBnbG9iYWwgbGlicmFyeVxuICAgKiBhbmQgZW1pdCB3YXJuaW5nIGlmIHRoZXkgZmluZCBhIGRlZmluaXRpb24gdGhlcmUuIFRoaXMgb3B0aW9uIGlzIGEgZGVmYXVsdFxuICAgKiB0byBhc3Npc3QgZXhpc3RpbmcgYXBwbGljYXRpb25zIHdpdGggYSBtaWdyYXRpb24uIEFwcGxpY2F0aW9ucyBhcmUgZXhwZWN0ZWRcbiAgICogdG8gc3dpdGNoIHRvIHVzaW5nIHtAbGluayBGYUljb25MaWJyYXJ5fS5cbiAgICogLSB0cnVlIC0gQ29tcG9uZW50cyBzaG91bGQgbG9va3VwIGljb24gZGVmaW5pdGlvbnMgaW4gdGhlIGdsb2JhbCBsaWJyYXJ5LlxuICAgKiBOb3RlIHRoYXQgZ2xvYmFsIGljb24gbGlicmFyeSBpcyBkZXByZWNhdGVkIGFuZCBzdXBwb3J0IGZvciBpdCB3aWxsIGJlXG4gICAqIHJlbW92ZWQuIFRoaXMgb3B0aW9uIGNhbiBiZSB1c2VkIHRvIHRlbXBvcmFyaWx5IHN1cHByZXNzIHdhcm5pbmdzLlxuICAgKiAtIGZhbHNlIC0gQ29tcG9uZW50cyBzaG91bGQgbm90IGxvb2t1cCBpY29uIGRlZmluaXRpb25zIGluIHRoZSBnbG9iYWxcbiAgICogbGlicmFyeS4gTGlicmFyeSB3aWxsIHRocm93IGFuIGVycm9yIGlmIG1pc3NpbmcgaWNvbiBpcyBmb3VuZCBpbiB0aGUgZ2xvYmFsXG4gICAqIGxpYnJhcnkuXG4gICAqXG4gICAqIEBkZXByZWNhdGVkIFRoaXMgb3B0aW9uIGlzIGRlcHJlY2F0ZWQgc2luY2UgMC41LjAuIEluIDAuNi4wIGRlZmF1bHQgd2lsbFxuICAgKiBiZSBjaGFuZ2VkIHRvIGZhbHNlLiBJbiAwLjcuMCB0aGUgb3B0aW9uIHdpbGwgYmUgcmVtb3ZlZCB0b2dldGhlciB3aXRoIHRoZVxuICAgKiBzdXBwb3J0IGZvciB0aGUgZ2xvYmFsIGljb24gbGlicmFyeS5cbiAgICpcbiAgICogQGRlZmF1bHQgJ3Vuc2V0J1xuICAgKi9cbiAgZ2xvYmFsTGlicmFyeTogYm9vbGVhbiB8ICd1bnNldCcgPSAndW5zZXQnO1xufVxuIl19