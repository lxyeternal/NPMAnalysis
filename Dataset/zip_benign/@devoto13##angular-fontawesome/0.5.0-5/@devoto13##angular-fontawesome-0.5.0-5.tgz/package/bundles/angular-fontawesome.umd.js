(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/platform-browser'), require('@fortawesome/fontawesome-svg-core')) :
    typeof define === 'function' && define.amd ? define('@fortawesome/angular-fontawesome', ['exports', '@angular/core', '@angular/platform-browser', '@fortawesome/fontawesome-svg-core'], factory) :
    (global = global || self, factory((global.fortawesome = global.fortawesome || {}, global.fortawesome['angular-fontawesome'] = {}), global.ng.core, global.ng.platformBrowser, global.fontawesomeSvgCore));
}(this, function (exports, core, platformBrowser, fontawesomeSvgCore) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
        if (m) return m.call(o);
        return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var FaConfig = /** @class */ (function () {
        function FaConfig() {
            /**
             * Default prefix to use, when one is not provided with the icon name.
             *
             * \@default 'fas'
             */
            this.defaultPrefix = 'fas';
            /**
             * Whether components should lookup icon definitions in the global icon
             * library (the one available from
             * `import { library } from '\@fortawesome/fontawesome-svg-core')`.
             *
             * See https://github.com/FortAwesome/angular-fontawesome/blob/master/docs/usage/icon-library.md
             * for detailed description of library modes.
             *
             * - 'unset' - Components should lookup icon definitions in the global library
             * and emit warning if they find a definition there. This option is a default
             * to assist existing applications with a migration. Applications are expected
             * to switch to using {\@link FaIconLibrary}.
             * - true - Components should lookup icon definitions in the global library.
             * Note that global icon library is deprecated and support for it will be
             * removed. This option can be used to temporarily suppress warnings.
             * - false - Components should not lookup icon definitions in the global
             * library. Library will throw an error if missing icon is found in the global
             * library.
             *
             * @deprecated This option is deprecated since 0.5.0. In 0.6.0 default will
             * be changed to false. In 0.7.0 the option will be removed together with the
             * support for the global icon library.
             *
             * \@default 'unset'
             */
            this.globalLibrary = 'unset';
        }
        FaConfig.decorators = [
            { type: core.Injectable, args: [{ providedIn: 'root' },] }
        ];
        /** @nocollapse */ FaConfig.ngInjectableDef = core.ɵɵdefineInjectable({ factory: function FaConfig_Factory() { return new FaConfig(); }, token: FaConfig, providedIn: "root" });
        return FaConfig;
    }());
    if (false) {
        /**
         * Default prefix to use, when one is not provided with the icon name.
         *
         * \@default 'fas'
         * @type {?}
         */
        FaConfig.prototype.defaultPrefix;
        /**
         * Whether components should lookup icon definitions in the global icon
         * library (the one available from
         * `import { library } from '\@fortawesome/fontawesome-svg-core')`.
         *
         * See https://github.com/FortAwesome/angular-fontawesome/blob/master/docs/usage/icon-library.md
         * for detailed description of library modes.
         *
         * - 'unset' - Components should lookup icon definitions in the global library
         * and emit warning if they find a definition there. This option is a default
         * to assist existing applications with a migration. Applications are expected
         * to switch to using {\@link FaIconLibrary}.
         * - true - Components should lookup icon definitions in the global library.
         * Note that global icon library is deprecated and support for it will be
         * removed. This option can be used to temporarily suppress warnings.
         * - false - Components should not lookup icon definitions in the global
         * library. Library will throw an error if missing icon is found in the global
         * library.
         *
         * @deprecated This option is deprecated since 0.5.0. In 0.6.0 default will
         * be changed to false. In 0.7.0 the option will be removed together with the
         * support for the global icon library.
         *
         * \@default 'unset'
         * @type {?}
         */
        FaConfig.prototype.globalLibrary;
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var FaIconLibrary = /** @class */ (function () {
        function FaIconLibrary() {
            this.definitions = {};
        }
        /**
         * @param {...?} icons
         * @return {?}
         */
        FaIconLibrary.prototype.addIcons = /**
         * @param {...?} icons
         * @return {?}
         */
        function () {
            var icons = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                icons[_i] = arguments[_i];
            }
            for (var i = 0; i < icons.length; i++) {
                /** @type {?} */
                var icon = icons[i];
                if (!(icon.prefix in this.definitions)) {
                    this.definitions[icon.prefix] = {};
                }
                this.definitions[icon.prefix][icon.iconName] = icon;
            }
        };
        /**
         * @param {...?} packs
         * @return {?}
         */
        FaIconLibrary.prototype.addIconPacks = /**
         * @param {...?} packs
         * @return {?}
         */
        function () {
            var packs = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                packs[_i] = arguments[_i];
            }
            var _loop_1 = function (i) {
                /** @type {?} */
                var pack = packs[i];
                /** @type {?} */
                var icons = Object.keys(pack).map((/**
                 * @param {?} key
                 * @return {?}
                 */
                function (key) { return pack[key]; }));
                this_1.addIcons.apply(this_1, __spread(icons));
            };
            var this_1 = this;
            for (var i = 0; i < packs.length; i++) {
                _loop_1(i);
            }
        };
        /**
         * @param {?} prefix
         * @param {?} name
         * @return {?}
         */
        FaIconLibrary.prototype.getIconDefinition = /**
         * @param {?} prefix
         * @param {?} name
         * @return {?}
         */
        function (prefix, name) {
            if (prefix in this.definitions && name in this.definitions[prefix]) {
                return this.definitions[prefix][name];
            }
            return null;
        };
        FaIconLibrary.decorators = [
            { type: core.Injectable, args: [{ providedIn: 'root' },] }
        ];
        /** @nocollapse */ FaIconLibrary.ngInjectableDef = core.ɵɵdefineInjectable({ factory: function FaIconLibrary_Factory() { return new FaIconLibrary(); }, token: FaIconLibrary, providedIn: "root" });
        return FaIconLibrary;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        FaIconLibrary.prototype.definitions;
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var faWarnIfIconDefinitionMissing = (/**
     * @param {?} iconSpec
     * @return {?}
     */
    function (iconSpec) {
        console.error("FontAwesome: Could not find icon with iconName=" + iconSpec.iconName + " and prefix=" + iconSpec.prefix + ". " +
            "This warning will become a hard error in 0.6.0.");
    });

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /** @type {?} */
    var faWarnIfIconSpecMissing = (/**
     * @return {?}
     */
    function () {
        console.error('FontAwesome: Property `icon` is required for `fa-icon`/`fa-duotone-icon` components. ' +
            "This warning will become a hard error in 0.6.0.");
    });

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Fontawesome class list.
     * Returns classes array by props.
     * @type {?}
     */
    var faClassList = (/**
     * @param {?} props
     * @return {?}
     */
    function (props) {
        var _a;
        /** @type {?} */
        var classes = (_a = {
                'fa-spin': props.spin,
                'fa-pulse': props.pulse,
                'fa-fw': props.fixedWidth,
                'fa-border': props.border,
                'fa-li': props.listItem,
                'fa-inverse': props.inverse,
                'fa-layers-counter': props.counter,
                'fa-flip-horizontal': props.flip === 'horizontal' || props.flip === 'both',
                'fa-flip-vertical': props.flip === 'vertical' || props.flip === 'both'
            },
            _a["fa-" + props.size] = props.size !== null,
            _a["fa-rotate-" + props.rotate] = props.rotate !== null,
            _a["fa-pull-" + props.pull] = props.pull !== null,
            _a["fa-stack-" + props.stackItemSize] = props.stackItemSize != null,
            _a);
        return Object.keys(classes)
            .map((/**
         * @param {?} key
         * @return {?}
         */
        function (key) { return (classes[key] ? key : null); }))
            .filter((/**
         * @param {?} key
         * @return {?}
         */
        function (key) { return key; }));
    });

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Returns if is IconLookup or not.
     * @type {?}
     */
    var isIconLookup = (/**
     * @param {?} i
     * @return {?}
     */
    function (i) {
        return ((/** @type {?} */ (i))).prefix !== undefined && ((/** @type {?} */ (i))).iconName !== undefined;
    });

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Normalizing icon spec.
     * @type {?}
     */
    var faNormalizeIconSpec = (/**
     * @param {?} iconSpec
     * @param {?} defaultPrefix
     * @return {?}
     */
    function (iconSpec, defaultPrefix) {
        if (isIconLookup(iconSpec)) {
            return iconSpec;
        }
        if (Array.isArray(iconSpec) && ((/** @type {?} */ (iconSpec))).length === 2) {
            return { prefix: iconSpec[0], iconName: iconSpec[1] };
        }
        if (typeof iconSpec === 'string') {
            return { prefix: defaultPrefix, iconName: iconSpec };
        }
    });

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var FaStackItemSizeDirective = /** @class */ (function () {
        function FaStackItemSizeDirective() {
            /**
             * Specify whether icon inside {\@link FaStackComponent} should be rendered in
             * regular size (1x) or as a larger icon (2x).
             */
            this.stackItemSize = '1x';
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        FaStackItemSizeDirective.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if ('size' in changes) {
                throw new Error('fa-icon is not allowed to customize size when used inside fa-stack. ' +
                    'Set size on the enclosing fa-stack instead: <fa-stack size="4x">...</fa-stack>.');
            }
        };
        FaStackItemSizeDirective.decorators = [
            { type: core.Directive, args: [{
                        selector: 'fa-icon[stackItemSize],fa-duotone-icon[stackItemSize]',
                    },] }
        ];
        FaStackItemSizeDirective.propDecorators = {
            stackItemSize: [{ type: core.Input }],
            size: [{ type: core.Input }]
        };
        return FaStackItemSizeDirective;
    }());
    if (false) {
        /**
         * Specify whether icon inside {\@link FaStackComponent} should be rendered in
         * regular size (1x) or as a larger icon (2x).
         * @type {?}
         */
        FaStackItemSizeDirective.prototype.stackItemSize;
        /**
         * \@internal
         * @type {?}
         */
        FaStackItemSizeDirective.prototype.size;
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var FaIconComponent = /** @class */ (function () {
        function FaIconComponent(sanitizer, config, iconLibrary, stackItem) {
            this.sanitizer = sanitizer;
            this.config = config;
            this.iconLibrary = iconLibrary;
            this.stackItem = stackItem;
            this.classes = [];
        }
        Object.defineProperty(FaIconComponent.prototype, "iconProp", {
            /**
             * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `icon` property directly.
             */
            get: /**
             * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `icon` property directly.
             * @return {?}
             */
            function () {
                return this.icon;
            },
            /**
             * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `icon` property directly.
             */
            set: /**
             * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `icon` property directly.
             * @param {?} value
             * @return {?}
             */
            function (value) {
                this.icon = value;
            },
            enumerable: true,
            configurable: true
        });
        /**
         * @param {?} changes
         * @return {?}
         */
        FaIconComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (this.icon == null) {
                return faWarnIfIconSpecMissing();
            }
            if (changes) {
                /** @type {?} */
                var iconDefinition = this.findIconDefinition(this.icon);
                if (iconDefinition != null) {
                    /** @type {?} */
                    var params = this.buildParams();
                    this.renderIcon(iconDefinition, params);
                }
            }
        };
        /**
         * Programmatically trigger rendering of the icon.
         *
         * This method is useful, when creating {@link FaIconComponent} dynamically or
         * changing its inputs programmatically as in these cases icon won't be
         * re-rendered automatically.
         */
        /**
         * Programmatically trigger rendering of the icon.
         *
         * This method is useful, when creating {\@link FaIconComponent} dynamically or
         * changing its inputs programmatically as in these cases icon won't be
         * re-rendered automatically.
         * @return {?}
         */
        FaIconComponent.prototype.render = /**
         * Programmatically trigger rendering of the icon.
         *
         * This method is useful, when creating {\@link FaIconComponent} dynamically or
         * changing its inputs programmatically as in these cases icon won't be
         * re-rendered automatically.
         * @return {?}
         */
        function () {
            this.ngOnChanges({});
        };
        /**
         * @protected
         * @param {?} i
         * @return {?}
         */
        FaIconComponent.prototype.findIconDefinition = /**
         * @protected
         * @param {?} i
         * @return {?}
         */
        function (i) {
            /** @type {?} */
            var lookup = faNormalizeIconSpec(i, this.config.defaultPrefix);
            if ('icon' in lookup) {
                return lookup;
            }
            /** @type {?} */
            var definition = this.iconLibrary.getIconDefinition(lookup.prefix, lookup.iconName);
            if (definition != null) {
                return definition;
            }
            /** @type {?} */
            var globalDefinition = fontawesomeSvgCore.findIconDefinition(lookup);
            if (globalDefinition != null) {
                /** @type {?} */
                var message = 'Global icon library is deprecated. ' +
                    'Consult https://github.com/FortAwesome/angular-fontawesome/blob/master/UPGRADING.md ' +
                    'for the migration instructions.';
                if (this.config.globalLibrary === 'unset') {
                    console.error('FontAwesome: ' + message);
                }
                else if (!this.config.globalLibrary) {
                    throw new Error(message);
                }
                return globalDefinition;
            }
            faWarnIfIconDefinitionMissing(lookup);
            return null;
        };
        /**
         * @protected
         * @return {?}
         */
        FaIconComponent.prototype.buildParams = /**
         * @protected
         * @return {?}
         */
        function () {
            /** @type {?} */
            var classOpts = {
                flip: this.flip,
                spin: this.spin,
                pulse: this.pulse,
                border: this.border,
                inverse: this.inverse,
                listItem: this.listItem,
                size: this.size || null,
                pull: this.pull || null,
                rotate: this.rotate || null,
                fixedWidth: this.fixedWidth,
                stackItemSize: this.stackItem != null ? this.stackItem.stackItemSize : null,
            };
            /** @type {?} */
            var parsedTransform = typeof this.transform === 'string' ? fontawesomeSvgCore.parse.transform(this.transform) : this.transform;
            return {
                title: this.title,
                transform: parsedTransform,
                classes: __spread(faClassList(classOpts), this.classes),
                mask: this.mask != null ? this.findIconDefinition(this.mask) : null,
                styles: this.styles != null ? this.styles : {},
                symbol: this.symbol,
                attributes: {
                    role: this.a11yRole
                }
            };
        };
        /**
         * @private
         * @param {?} definition
         * @param {?} params
         * @return {?}
         */
        FaIconComponent.prototype.renderIcon = /**
         * @private
         * @param {?} definition
         * @param {?} params
         * @return {?}
         */
        function (definition, params) {
            /** @type {?} */
            var renderedIcon = fontawesomeSvgCore.icon(definition, params);
            this.renderedIconHTML = this.sanitizer.bypassSecurityTrustHtml(renderedIcon.html.join('\n'));
        };
        FaIconComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'fa-icon',
                        template: "",
                        host: {
                            class: 'ng-fa-icon',
                            '[attr.title]': 'title',
                        }
                    }] }
        ];
        /** @nocollapse */
        FaIconComponent.ctorParameters = function () { return [
            { type: platformBrowser.DomSanitizer },
            { type: FaConfig },
            { type: FaIconLibrary },
            { type: FaStackItemSizeDirective, decorators: [{ type: core.Optional }] }
        ]; };
        FaIconComponent.propDecorators = {
            icon: [{ type: core.Input }],
            title: [{ type: core.Input }],
            spin: [{ type: core.Input }],
            pulse: [{ type: core.Input }],
            mask: [{ type: core.Input }],
            styles: [{ type: core.Input }],
            flip: [{ type: core.Input }],
            size: [{ type: core.Input }],
            pull: [{ type: core.Input }],
            border: [{ type: core.Input }],
            inverse: [{ type: core.Input }],
            symbol: [{ type: core.Input }],
            listItem: [{ type: core.Input }],
            rotate: [{ type: core.Input }],
            fixedWidth: [{ type: core.Input }],
            classes: [{ type: core.Input }],
            transform: [{ type: core.Input }],
            a11yRole: [{ type: core.Input }],
            renderedIconHTML: [{ type: core.HostBinding, args: ['innerHTML',] }]
        };
        return FaIconComponent;
    }());
    if (false) {
        /** @type {?} */
        FaIconComponent.prototype.icon;
        /**
         * Specify a title for the icon.
         * This text will be displayed in a tooltip on hover and presented to the
         * screen readers.
         * @type {?}
         */
        FaIconComponent.prototype.title;
        /** @type {?} */
        FaIconComponent.prototype.spin;
        /** @type {?} */
        FaIconComponent.prototype.pulse;
        /** @type {?} */
        FaIconComponent.prototype.mask;
        /** @type {?} */
        FaIconComponent.prototype.styles;
        /** @type {?} */
        FaIconComponent.prototype.flip;
        /** @type {?} */
        FaIconComponent.prototype.size;
        /** @type {?} */
        FaIconComponent.prototype.pull;
        /** @type {?} */
        FaIconComponent.prototype.border;
        /** @type {?} */
        FaIconComponent.prototype.inverse;
        /** @type {?} */
        FaIconComponent.prototype.symbol;
        /**
         * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `fixedWidth` with your custom styles instead.
         * @type {?}
         */
        FaIconComponent.prototype.listItem;
        /** @type {?} */
        FaIconComponent.prototype.rotate;
        /** @type {?} */
        FaIconComponent.prototype.fixedWidth;
        /** @type {?} */
        FaIconComponent.prototype.classes;
        /** @type {?} */
        FaIconComponent.prototype.transform;
        /**
         * Specify the `role` attribute for the rendered <svg> element.
         *
         * \@default 'img'
         * @type {?}
         */
        FaIconComponent.prototype.a11yRole;
        /** @type {?} */
        FaIconComponent.prototype.renderedIconHTML;
        /**
         * @type {?}
         * @private
         */
        FaIconComponent.prototype.sanitizer;
        /**
         * @type {?}
         * @private
         */
        FaIconComponent.prototype.config;
        /**
         * @type {?}
         * @private
         */
        FaIconComponent.prototype.iconLibrary;
        /**
         * @type {?}
         * @private
         */
        FaIconComponent.prototype.stackItem;
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var FaDuotoneIconComponent = /** @class */ (function (_super) {
        __extends(FaDuotoneIconComponent, _super);
        function FaDuotoneIconComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /**
         * @protected
         * @param {?} i
         * @return {?}
         */
        FaDuotoneIconComponent.prototype.findIconDefinition = /**
         * @protected
         * @param {?} i
         * @return {?}
         */
        function (i) {
            /** @type {?} */
            var lookup = _super.prototype.findIconDefinition.call(this, i);
            if (lookup != null && lookup.prefix !== 'fad') {
                throw new Error('The specified icon does not appear to be a Duotone icon. ' +
                    'Check that you specified the correct style: ' +
                    ("<fa-duotone-icon [icon]=\"['fab', '" + lookup.iconName + "']\"></fa-duotone-icon> ") +
                    ("or use: <fa-icon icon=\"" + lookup.iconName + "\"></fa-icon> instead."));
            }
            return lookup;
        };
        /**
         * @protected
         * @return {?}
         */
        FaDuotoneIconComponent.prototype.buildParams = /**
         * @protected
         * @return {?}
         */
        function () {
            /** @type {?} */
            var params = _super.prototype.buildParams.call(this);
            if (this.swapOpacity === true || this.swapOpacity === 'true') {
                params.classes.push('fa-swap-opacity');
            }
            if (this.primaryOpacity != null) {
                params.styles['--fa-primary-opacity'] = this.primaryOpacity.toString();
            }
            if (this.secondaryOpacity != null) {
                params.styles['--fa-secondary-opacity'] = this.secondaryOpacity.toString();
            }
            if (this.primaryColor != null) {
                params.styles['--fa-primary-color'] = this.primaryColor;
            }
            if (this.secondaryColor != null) {
                params.styles['--fa-secondary-color'] = this.secondaryColor;
            }
            return params;
        };
        FaDuotoneIconComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'fa-duotone-icon',
                        template: ""
                    }] }
        ];
        FaDuotoneIconComponent.propDecorators = {
            swapOpacity: [{ type: core.Input }],
            primaryOpacity: [{ type: core.Input }],
            secondaryOpacity: [{ type: core.Input }],
            primaryColor: [{ type: core.Input }],
            secondaryColor: [{ type: core.Input }]
        };
        return FaDuotoneIconComponent;
    }(FaIconComponent));
    if (false) {
        /**
         * Swap the default opacity of each duotone icon’s layers. This will make an
         * icon’s primary layer have the default opacity of 40% rather than its
         * secondary layer.
         *
         * \@default false
         * @type {?}
         */
        FaDuotoneIconComponent.prototype.swapOpacity;
        /**
         * Customize the opacity of the primary icon layer.
         * Valid values are in range [0, 1.0].
         *
         * \@default 1.0
         * @type {?}
         */
        FaDuotoneIconComponent.prototype.primaryOpacity;
        /**
         * Customize the opacity of the secondary icon layer.
         * Valid values are in range [0, 1.0].
         *
         * \@default 0.4
         * @type {?}
         */
        FaDuotoneIconComponent.prototype.secondaryOpacity;
        /**
         * Customize the color of the primary icon layer.
         * Accepts any valid CSS color value.
         *
         * \@default CSS inherited color
         * @type {?}
         */
        FaDuotoneIconComponent.prototype.primaryColor;
        /**
         * Customize the color of the secondary icon layer.
         * Accepts any valid CSS color value.
         *
         * \@default CSS inherited color
         * @type {?}
         */
        FaDuotoneIconComponent.prototype.secondaryColor;
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Fontawesome layers.
     */
    var FaLayersComponent = /** @class */ (function () {
        function FaLayersComponent(renderer, elementRef) {
            this.renderer = renderer;
            this.elementRef = elementRef;
        }
        /**
         * @return {?}
         */
        FaLayersComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.renderer.addClass(this.elementRef.nativeElement, 'fa-layers');
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        FaLayersComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if ('size' in changes) {
                if (changes.size.currentValue != null) {
                    this.renderer.addClass(this.elementRef.nativeElement, "fa-" + changes.size.currentValue);
                }
                if (changes.size.previousValue != null) {
                    this.renderer.removeClass(this.elementRef.nativeElement, "fa-" + changes.size.previousValue);
                }
            }
        };
        FaLayersComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'fa-layers',
                        template: "<ng-content select=\"fa-icon, fa-duotone-icon, fa-layers-text, fa-layers-counter\"></ng-content>"
                    }] }
        ];
        /** @nocollapse */
        FaLayersComponent.ctorParameters = function () { return [
            { type: core.Renderer2 },
            { type: core.ElementRef }
        ]; };
        FaLayersComponent.propDecorators = {
            size: [{ type: core.Input }],
            fixedWidth: [{ type: core.Input }, { type: core.HostBinding, args: ['class.fa-fw',] }]
        };
        return FaLayersComponent;
    }());
    if (false) {
        /** @type {?} */
        FaLayersComponent.prototype.size;
        /** @type {?} */
        FaLayersComponent.prototype.fixedWidth;
        /**
         * @type {?}
         * @private
         */
        FaLayersComponent.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        FaLayersComponent.prototype.elementRef;
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Warns if parent component not existing.
     * @type {?}
     */
    var faWarnIfParentNotExist = (/**
     * @param {?} parent
     * @param {?} parentName
     * @param {?} childName
     * @return {?}
     */
    function (parent, parentName, childName) {
        if (!parent) {
            console.error("FontAwesome: " + childName + " should be used as child of " + parentName + " only.");
        }
    });

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @abstract
     */
    var FaLayersTextBaseComponent = /** @class */ (function () {
        function FaLayersTextBaseComponent(parent, sanitizer) {
            this.parent = parent;
            this.sanitizer = sanitizer;
            this.classes = [];
            faWarnIfParentNotExist(this.parent, 'FaLayersComponent', this.constructor.name);
        }
        /**
         * @param {?} changes
         * @return {?}
         */
        FaLayersTextBaseComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if (changes) {
                this.updateParams();
                this.updateContent();
            }
        };
        /**
         * Updating content by params and content.
         */
        /**
         * Updating content by params and content.
         * @private
         * @return {?}
         */
        FaLayersTextBaseComponent.prototype.updateContent = /**
         * Updating content by params and content.
         * @private
         * @return {?}
         */
        function () {
            this.renderedHTML = this.sanitizer.bypassSecurityTrustHtml(this.renderFontawesomeObject(this.content || '', this.params).html.join('\n'));
        };
        FaLayersTextBaseComponent.decorators = [
            { type: core.Injectable }
        ];
        /** @nocollapse */
        FaLayersTextBaseComponent.ctorParameters = function () { return [
            { type: FaLayersComponent, decorators: [{ type: core.Inject, args: [core.forwardRef((/**
                             * @return {?}
                             */
                            function () { return FaLayersComponent; })),] }, { type: core.Optional }] },
            { type: platformBrowser.DomSanitizer }
        ]; };
        FaLayersTextBaseComponent.propDecorators = {
            renderedHTML: [{ type: core.HostBinding, args: ['innerHTML',] }],
            content: [{ type: core.Input }],
            title: [{ type: core.Input }],
            styles: [{ type: core.Input }],
            classes: [{ type: core.Input }]
        };
        return FaLayersTextBaseComponent;
    }());
    if (false) {
        /** @type {?} */
        FaLayersTextBaseComponent.prototype.renderedHTML;
        /**
         * @type {?}
         * @protected
         */
        FaLayersTextBaseComponent.prototype.params;
        /**
         * @type {?}
         * @protected
         */
        FaLayersTextBaseComponent.prototype.content;
        /**
         * @type {?}
         * @protected
         */
        FaLayersTextBaseComponent.prototype.title;
        /**
         * @type {?}
         * @protected
         */
        FaLayersTextBaseComponent.prototype.styles;
        /**
         * @type {?}
         * @protected
         */
        FaLayersTextBaseComponent.prototype.classes;
        /**
         * @type {?}
         * @private
         */
        FaLayersTextBaseComponent.prototype.parent;
        /**
         * @type {?}
         * @private
         */
        FaLayersTextBaseComponent.prototype.sanitizer;
        /**
         * Updating params by component props.
         * @abstract
         * @protected
         * @return {?}
         */
        FaLayersTextBaseComponent.prototype.updateParams = function () { };
        /**
         * Render the FontawesomeObject using the content and params.
         * @abstract
         * @protected
         * @param {?} content
         * @param {?=} params
         * @return {?}
         */
        FaLayersTextBaseComponent.prototype.renderFontawesomeObject = function (content, params) { };
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Fontawesome layers counter.
     */
    var FaLayersCounterComponent = /** @class */ (function (_super) {
        __extends(FaLayersCounterComponent, _super);
        function FaLayersCounterComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /**
         * Updating params by component props.
         */
        /**
         * Updating params by component props.
         * @protected
         * @return {?}
         */
        FaLayersCounterComponent.prototype.updateParams = /**
         * Updating params by component props.
         * @protected
         * @return {?}
         */
        function () {
            this.params = {
                title: this.title,
                classes: this.classes,
                styles: this.styles,
            };
        };
        /**
         * @protected
         * @param {?} content
         * @param {?=} params
         * @return {?}
         */
        FaLayersCounterComponent.prototype.renderFontawesomeObject = /**
         * @protected
         * @param {?} content
         * @param {?=} params
         * @return {?}
         */
        function (content, params) {
            return fontawesomeSvgCore.counter(content, params);
        };
        FaLayersCounterComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'fa-layers-counter',
                        template: '',
                        host: {
                            class: 'ng-fa-layers-counter'
                        }
                    }] }
        ];
        return FaLayersCounterComponent;
    }(FaLayersTextBaseComponent));

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * Fontawesome layers text.
     */
    var FaLayersTextComponent = /** @class */ (function (_super) {
        __extends(FaLayersTextComponent, _super);
        function FaLayersTextComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /**
         * Updating params by component props.
         */
        /**
         * Updating params by component props.
         * @protected
         * @return {?}
         */
        FaLayersTextComponent.prototype.updateParams = /**
         * Updating params by component props.
         * @protected
         * @return {?}
         */
        function () {
            /** @type {?} */
            var classOpts = {
                flip: this.flip,
                spin: this.spin,
                pulse: this.pulse,
                border: this.border,
                inverse: this.inverse,
                listItem: this.listItem,
                size: this.size || null,
                pull: this.pull || null,
                rotate: this.rotate || null,
                fixedWidth: this.fixedWidth
            };
            /** @type {?} */
            var parsedTransform = typeof this.transform === 'string' ? fontawesomeSvgCore.parse.transform(this.transform) : this.transform;
            this.params = {
                transform: parsedTransform,
                classes: __spread(faClassList(classOpts), this.classes),
                title: this.title,
                styles: this.styles
            };
        };
        /**
         * @protected
         * @param {?} content
         * @param {?=} params
         * @return {?}
         */
        FaLayersTextComponent.prototype.renderFontawesomeObject = /**
         * @protected
         * @param {?} content
         * @param {?=} params
         * @return {?}
         */
        function (content, params) {
            return fontawesomeSvgCore.text(content, params);
        };
        FaLayersTextComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'fa-layers-text',
                        template: '',
                        host: {
                            class: 'ng-fa-layers-text'
                        }
                    }] }
        ];
        FaLayersTextComponent.propDecorators = {
            spin: [{ type: core.Input }],
            pulse: [{ type: core.Input }],
            flip: [{ type: core.Input }],
            size: [{ type: core.Input }],
            pull: [{ type: core.Input }],
            border: [{ type: core.Input }],
            inverse: [{ type: core.Input }],
            listItem: [{ type: core.Input }],
            rotate: [{ type: core.Input }],
            fixedWidth: [{ type: core.Input }],
            transform: [{ type: core.Input }]
        };
        return FaLayersTextComponent;
    }(FaLayersTextBaseComponent));
    if (false) {
        /** @type {?} */
        FaLayersTextComponent.prototype.spin;
        /** @type {?} */
        FaLayersTextComponent.prototype.pulse;
        /** @type {?} */
        FaLayersTextComponent.prototype.flip;
        /** @type {?} */
        FaLayersTextComponent.prototype.size;
        /** @type {?} */
        FaLayersTextComponent.prototype.pull;
        /** @type {?} */
        FaLayersTextComponent.prototype.border;
        /** @type {?} */
        FaLayersTextComponent.prototype.inverse;
        /** @type {?} */
        FaLayersTextComponent.prototype.listItem;
        /** @type {?} */
        FaLayersTextComponent.prototype.rotate;
        /** @type {?} */
        FaLayersTextComponent.prototype.fixedWidth;
        /** @type {?} */
        FaLayersTextComponent.prototype.transform;
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var FaStackComponent = /** @class */ (function () {
        function FaStackComponent(renderer, elementRef) {
            this.renderer = renderer;
            this.elementRef = elementRef;
        }
        /**
         * @return {?}
         */
        FaStackComponent.prototype.ngOnInit = /**
         * @return {?}
         */
        function () {
            this.renderer.addClass(this.elementRef.nativeElement, 'fa-stack');
        };
        /**
         * @param {?} changes
         * @return {?}
         */
        FaStackComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
        function (changes) {
            if ('size' in changes) {
                if (changes.size.currentValue != null) {
                    this.renderer.addClass(this.elementRef.nativeElement, "fa-" + changes.size.currentValue);
                }
                if (changes.size.previousValue != null) {
                    this.renderer.removeClass(this.elementRef.nativeElement, "fa-" + changes.size.previousValue);
                }
            }
        };
        FaStackComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'fa-stack',
                        // TODO: See if it is better to select fa-icon and throw if it does not have stackItemSize directive
                        template: "<ng-content select=\"fa-icon[stackItemSize],fa-duotone-icon[stackItemSize]\"></ng-content>"
                    }] }
        ];
        /** @nocollapse */
        FaStackComponent.ctorParameters = function () { return [
            { type: core.Renderer2 },
            { type: core.ElementRef }
        ]; };
        FaStackComponent.propDecorators = {
            size: [{ type: core.Input }]
        };
        return FaStackComponent;
    }());
    if (false) {
        /**
         * Size of the stacked icon.
         * Note that stacked icon is by default 2 times bigger, than non-stacked icon.
         * You'll need to set size using custom CSS to align stacked icon with a
         * simple one. E.g. `fa-stack { font-size: 0.5em; }`.
         * @type {?}
         */
        FaStackComponent.prototype.size;
        /**
         * @type {?}
         * @private
         */
        FaStackComponent.prototype.renderer;
        /**
         * @type {?}
         * @private
         */
        FaStackComponent.prototype.elementRef;
    }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    var FontAwesomeModule = /** @class */ (function () {
        function FontAwesomeModule() {
        }
        FontAwesomeModule.decorators = [
            { type: core.NgModule, args: [{
                        declarations: [
                            FaIconComponent,
                            FaDuotoneIconComponent,
                            FaLayersComponent,
                            FaLayersTextComponent,
                            FaLayersCounterComponent,
                            FaStackComponent,
                            FaStackItemSizeDirective,
                        ],
                        exports: [
                            FaIconComponent,
                            FaDuotoneIconComponent,
                            FaLayersComponent,
                            FaLayersTextComponent,
                            FaLayersCounterComponent,
                            FaStackComponent,
                            FaStackItemSizeDirective,
                        ],
                        entryComponents: [
                            FaIconComponent,
                            FaDuotoneIconComponent,
                        ]
                    },] }
        ];
        return FontAwesomeModule;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
     */
    /**
     * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use FaConfig directly.
     */
    var FaIconService = /** @class */ (function () {
        function FaIconService(config) {
            this.config = config;
        }
        Object.defineProperty(FaIconService.prototype, "defaultPrefix", {
            get: /**
             * @return {?}
             */
            function () {
                return this.config.defaultPrefix;
            },
            set: /**
             * @param {?} value
             * @return {?}
             */
            function (value) {
                this.config.defaultPrefix = value;
            },
            enumerable: true,
            configurable: true
        });
        FaIconService.decorators = [
            { type: core.Injectable, args: [{ providedIn: 'root' },] }
        ];
        /** @nocollapse */
        FaIconService.ctorParameters = function () { return [
            { type: FaConfig }
        ]; };
        /** @nocollapse */ FaIconService.ngInjectableDef = core.ɵɵdefineInjectable({ factory: function FaIconService_Factory() { return new FaIconService(core.ɵɵinject(FaConfig)); }, token: FaIconService, providedIn: "root" });
        return FaIconService;
    }());
    if (false) {
        /**
         * @type {?}
         * @private
         */
        FaIconService.prototype.config;
    }

    exports.FaConfig = FaConfig;
    exports.FaDuotoneIconComponent = FaDuotoneIconComponent;
    exports.FaIconComponent = FaIconComponent;
    exports.FaIconLibrary = FaIconLibrary;
    exports.FaIconService = FaIconService;
    exports.FaLayersComponent = FaLayersComponent;
    exports.FaLayersCounterComponent = FaLayersCounterComponent;
    exports.FaLayersTextComponent = FaLayersTextComponent;
    exports.FaStackComponent = FaStackComponent;
    exports.FaStackItemSizeDirective = FaStackItemSizeDirective;
    exports.FontAwesomeModule = FontAwesomeModule;
    exports.ɵa = FaLayersTextBaseComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=angular-fontawesome.umd.js.map
