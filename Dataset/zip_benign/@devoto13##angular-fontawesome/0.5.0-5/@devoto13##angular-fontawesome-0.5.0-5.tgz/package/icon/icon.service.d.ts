import { IconPrefix } from '@fortawesome/fontawesome-svg-core';
import { FaConfig } from '../config';
/**
 * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use FaConfig directly.
 */
export declare class FaIconService {
    private config;
    defaultPrefix: IconPrefix;
    constructor(config: FaConfig);
}
