/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Component, Input } from '@angular/core';
import { FaIconComponent } from './icon.component';
export class FaDuotoneIconComponent extends FaIconComponent {
    /**
     * @protected
     * @param {?} i
     * @return {?}
     */
    findIconDefinition(i) {
        /** @type {?} */
        const lookup = super.findIconDefinition(i);
        if (lookup != null && lookup.prefix !== 'fad') {
            throw new Error('The specified icon does not appear to be a Duotone icon. ' +
                'Check that you specified the correct style: ' +
                `<fa-duotone-icon [icon]="['fab', '${lookup.iconName}']"></fa-duotone-icon> ` +
                `or use: <fa-icon icon="${lookup.iconName}"></fa-icon> instead.`);
        }
        return lookup;
    }
    /**
     * @protected
     * @return {?}
     */
    buildParams() {
        /** @type {?} */
        const params = super.buildParams();
        if (this.swapOpacity === true || this.swapOpacity === 'true') {
            params.classes.push('fa-swap-opacity');
        }
        if (this.primaryOpacity != null) {
            params.styles['--fa-primary-opacity'] = this.primaryOpacity.toString();
        }
        if (this.secondaryOpacity != null) {
            params.styles['--fa-secondary-opacity'] = this.secondaryOpacity.toString();
        }
        if (this.primaryColor != null) {
            params.styles['--fa-primary-color'] = this.primaryColor;
        }
        if (this.secondaryColor != null) {
            params.styles['--fa-secondary-color'] = this.secondaryColor;
        }
        return params;
    }
}
FaDuotoneIconComponent.decorators = [
    { type: Component, args: [{
                selector: 'fa-duotone-icon',
                template: ``
            }] }
];
FaDuotoneIconComponent.propDecorators = {
    swapOpacity: [{ type: Input }],
    primaryOpacity: [{ type: Input }],
    secondaryOpacity: [{ type: Input }],
    primaryColor: [{ type: Input }],
    secondaryColor: [{ type: Input }]
};
if (false) {
    /**
     * Swap the default opacity of each duotone icon’s layers. This will make an
     * icon’s primary layer have the default opacity of 40% rather than its
     * secondary layer.
     *
     * \@default false
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.swapOpacity;
    /**
     * Customize the opacity of the primary icon layer.
     * Valid values are in range [0, 1.0].
     *
     * \@default 1.0
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.primaryOpacity;
    /**
     * Customize the opacity of the secondary icon layer.
     * Valid values are in range [0, 1.0].
     *
     * \@default 0.4
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.secondaryOpacity;
    /**
     * Customize the color of the primary icon layer.
     * Accepts any valid CSS color value.
     *
     * \@default CSS inherited color
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.primaryColor;
    /**
     * Customize the color of the secondary icon layer.
     * Accepts any valid CSS color value.
     *
     * \@default CSS inherited color
     * @type {?}
     */
    FaDuotoneIconComponent.prototype.secondaryColor;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHVvdG9uZS1pY29uLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0Bmb3J0YXdlc29tZS9hbmd1bGFyLWZvbnRhd2Vzb21lLyIsInNvdXJjZXMiOlsiaWNvbi9kdW90b25lLWljb24uY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUVqRCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFNbkQsTUFBTSxPQUFPLHNCQUF1QixTQUFRLGVBQWU7Ozs7OztJQTBDL0Msa0JBQWtCLENBQUMsQ0FBNEI7O2NBQ2pELE1BQU0sR0FBRyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO1FBRTFDLElBQUksTUFBTSxJQUFJLElBQUksSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLEtBQUssRUFBRTtZQUM3QyxNQUFNLElBQUksS0FBSyxDQUNiLDJEQUEyRDtnQkFDM0QsOENBQThDO2dCQUM5QyxxQ0FBcUMsTUFBTSxDQUFDLFFBQVEseUJBQXlCO2dCQUM3RSwwQkFBMEIsTUFBTSxDQUFDLFFBQVEsdUJBQXVCLENBQ2pFLENBQUM7U0FDSDtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7Ozs7O0lBRVMsV0FBVzs7Y0FDYixNQUFNLEdBQUcsS0FBSyxDQUFDLFdBQVcsRUFBRTtRQUVsQyxJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssTUFBTSxFQUFFO1lBQzVELE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7U0FDeEM7UUFDRCxJQUFJLElBQUksQ0FBQyxjQUFjLElBQUksSUFBSSxFQUFFO1lBQy9CLE1BQU0sQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ3hFO1FBQ0QsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLElBQUksSUFBSSxFQUFFO1lBQ2pDLE1BQU0sQ0FBQyxNQUFNLENBQUMsd0JBQXdCLENBQUMsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFLENBQUM7U0FDNUU7UUFDRCxJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksSUFBSSxFQUFFO1lBQzdCLE1BQU0sQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1NBQ3pEO1FBQ0QsSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksRUFBRTtZQUMvQixNQUFNLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztTQUM3RDtRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7OztZQWpGRixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLGlCQUFpQjtnQkFDM0IsUUFBUSxFQUFFLEVBQUU7YUFDYjs7OzBCQVNFLEtBQUs7NkJBUUwsS0FBSzsrQkFRTCxLQUFLOzJCQVFMLEtBQUs7NkJBUUwsS0FBSzs7Ozs7Ozs7Ozs7SUFoQ04sNkNBQWtEOzs7Ozs7OztJQVFsRCxnREFBMEM7Ozs7Ozs7O0lBUTFDLGtEQUE0Qzs7Ozs7Ozs7SUFRNUMsOENBQStCOzs7Ozs7OztJQVEvQixnREFBaUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJY29uRGVmaW5pdGlvbiwgSWNvblByb3AgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuaW1wb3J0IHsgRmFJY29uQ29tcG9uZW50IH0gZnJvbSAnLi9pY29uLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2ZhLWR1b3RvbmUtaWNvbicsXG4gIHRlbXBsYXRlOiBgYFxufSlcbmV4cG9ydCBjbGFzcyBGYUR1b3RvbmVJY29uQ29tcG9uZW50IGV4dGVuZHMgRmFJY29uQ29tcG9uZW50IHtcbiAgLyoqXG4gICAqIFN3YXAgdGhlIGRlZmF1bHQgb3BhY2l0eSBvZiBlYWNoIGR1b3RvbmUgaWNvbuKAmXMgbGF5ZXJzLiBUaGlzIHdpbGwgbWFrZSBhblxuICAgKiBpY29u4oCZcyBwcmltYXJ5IGxheWVyIGhhdmUgdGhlIGRlZmF1bHQgb3BhY2l0eSBvZiA0MCUgcmF0aGVyIHRoYW4gaXRzXG4gICAqIHNlY29uZGFyeSBsYXllci5cbiAgICpcbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIEBJbnB1dCgpIHN3YXBPcGFjaXR5PzogJ3RydWUnIHwgJ2ZhbHNlJyB8IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIEN1c3RvbWl6ZSB0aGUgb3BhY2l0eSBvZiB0aGUgcHJpbWFyeSBpY29uIGxheWVyLlxuICAgKiBWYWxpZCB2YWx1ZXMgYXJlIGluIHJhbmdlIFswLCAxLjBdLlxuICAgKlxuICAgKiBAZGVmYXVsdCAxLjBcbiAgICovXG4gIEBJbnB1dCgpIHByaW1hcnlPcGFjaXR5Pzogc3RyaW5nIHwgbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBDdXN0b21pemUgdGhlIG9wYWNpdHkgb2YgdGhlIHNlY29uZGFyeSBpY29uIGxheWVyLlxuICAgKiBWYWxpZCB2YWx1ZXMgYXJlIGluIHJhbmdlIFswLCAxLjBdLlxuICAgKlxuICAgKiBAZGVmYXVsdCAwLjRcbiAgICovXG4gIEBJbnB1dCgpIHNlY29uZGFyeU9wYWNpdHk/OiBzdHJpbmcgfCBudW1iZXI7XG5cbiAgLyoqXG4gICAqIEN1c3RvbWl6ZSB0aGUgY29sb3Igb2YgdGhlIHByaW1hcnkgaWNvbiBsYXllci5cbiAgICogQWNjZXB0cyBhbnkgdmFsaWQgQ1NTIGNvbG9yIHZhbHVlLlxuICAgKlxuICAgKiBAZGVmYXVsdCBDU1MgaW5oZXJpdGVkIGNvbG9yXG4gICAqL1xuICBASW5wdXQoKSBwcmltYXJ5Q29sb3I/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEN1c3RvbWl6ZSB0aGUgY29sb3Igb2YgdGhlIHNlY29uZGFyeSBpY29uIGxheWVyLlxuICAgKiBBY2NlcHRzIGFueSB2YWxpZCBDU1MgY29sb3IgdmFsdWUuXG4gICAqXG4gICAqIEBkZWZhdWx0IENTUyBpbmhlcml0ZWQgY29sb3JcbiAgICovXG4gIEBJbnB1dCgpIHNlY29uZGFyeUNvbG9yPzogc3RyaW5nO1xuXG4gIHByb3RlY3RlZCBmaW5kSWNvbkRlZmluaXRpb24oaTogSWNvblByb3AgfCBJY29uRGVmaW5pdGlvbik6IEljb25EZWZpbml0aW9uIHwgbnVsbCB7XG4gICAgY29uc3QgbG9va3VwID0gc3VwZXIuZmluZEljb25EZWZpbml0aW9uKGkpO1xuXG4gICAgaWYgKGxvb2t1cCAhPSBudWxsICYmIGxvb2t1cC5wcmVmaXggIT09ICdmYWQnKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdUaGUgc3BlY2lmaWVkIGljb24gZG9lcyBub3QgYXBwZWFyIHRvIGJlIGEgRHVvdG9uZSBpY29uLiAnICtcbiAgICAgICAgJ0NoZWNrIHRoYXQgeW91IHNwZWNpZmllZCB0aGUgY29ycmVjdCBzdHlsZTogJyArXG4gICAgICAgIGA8ZmEtZHVvdG9uZS1pY29uIFtpY29uXT1cIlsnZmFiJywgJyR7bG9va3VwLmljb25OYW1lfSddXCI+PC9mYS1kdW90b25lLWljb24+IGAgK1xuICAgICAgICBgb3IgdXNlOiA8ZmEtaWNvbiBpY29uPVwiJHtsb29rdXAuaWNvbk5hbWV9XCI+PC9mYS1pY29uPiBpbnN0ZWFkLmBcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGxvb2t1cDtcbiAgfVxuXG4gIHByb3RlY3RlZCBidWlsZFBhcmFtcygpIHtcbiAgICBjb25zdCBwYXJhbXMgPSBzdXBlci5idWlsZFBhcmFtcygpO1xuXG4gICAgaWYgKHRoaXMuc3dhcE9wYWNpdHkgPT09IHRydWUgfHwgdGhpcy5zd2FwT3BhY2l0eSA9PT0gJ3RydWUnKSB7XG4gICAgICBwYXJhbXMuY2xhc3Nlcy5wdXNoKCdmYS1zd2FwLW9wYWNpdHknKTtcbiAgICB9XG4gICAgaWYgKHRoaXMucHJpbWFyeU9wYWNpdHkgIT0gbnVsbCkge1xuICAgICAgcGFyYW1zLnN0eWxlc1snLS1mYS1wcmltYXJ5LW9wYWNpdHknXSA9IHRoaXMucHJpbWFyeU9wYWNpdHkudG9TdHJpbmcoKTtcbiAgICB9XG4gICAgaWYgKHRoaXMuc2Vjb25kYXJ5T3BhY2l0eSAhPSBudWxsKSB7XG4gICAgICBwYXJhbXMuc3R5bGVzWyctLWZhLXNlY29uZGFyeS1vcGFjaXR5J10gPSB0aGlzLnNlY29uZGFyeU9wYWNpdHkudG9TdHJpbmcoKTtcbiAgICB9XG4gICAgaWYgKHRoaXMucHJpbWFyeUNvbG9yICE9IG51bGwpIHtcbiAgICAgIHBhcmFtcy5zdHlsZXNbJy0tZmEtcHJpbWFyeS1jb2xvciddID0gdGhpcy5wcmltYXJ5Q29sb3I7XG4gICAgfVxuICAgIGlmICh0aGlzLnNlY29uZGFyeUNvbG9yICE9IG51bGwpIHtcbiAgICAgIHBhcmFtcy5zdHlsZXNbJy0tZmEtc2Vjb25kYXJ5LWNvbG9yJ10gPSB0aGlzLnNlY29uZGFyeUNvbG9yO1xuICAgIH1cblxuICAgIHJldHVybiBwYXJhbXM7XG4gIH1cbn1cblxuIl19