/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Component, HostBinding, Input, Optional } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { findIconDefinition, icon, parse } from '@fortawesome/fontawesome-svg-core';
import { FaConfig } from '../config';
import { FaIconLibrary } from '../icon-library';
import { faWarnIfIconDefinitionMissing } from '../shared/errors/warn-if-icon-html-missing';
import { faWarnIfIconSpecMissing } from '../shared/errors/warn-if-icon-spec-missing';
import { faClassList } from '../shared/utils/classlist.util';
import { faNormalizeIconSpec } from '../shared/utils/normalize-icon-spec.util';
import { FaStackItemSizeDirective } from '../stack/stack-item-size.directive';
export class FaIconComponent {
    /**
     * @param {?} sanitizer
     * @param {?} config
     * @param {?} iconLibrary
     * @param {?} stackItem
     */
    constructor(sanitizer, config, iconLibrary, stackItem) {
        this.sanitizer = sanitizer;
        this.config = config;
        this.iconLibrary = iconLibrary;
        this.stackItem = stackItem;
        this.classes = [];
    }
    /**
     * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `icon` property directly.
     * @return {?}
     */
    get iconProp() {
        return this.icon;
    }
    /**
     * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `icon` property directly.
     * @param {?} value
     * @return {?}
     */
    set iconProp(value) {
        this.icon = value;
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (this.icon == null) {
            return faWarnIfIconSpecMissing();
        }
        if (changes) {
            /** @type {?} */
            const iconDefinition = this.findIconDefinition(this.icon);
            if (iconDefinition != null) {
                /** @type {?} */
                const params = this.buildParams();
                this.renderIcon(iconDefinition, params);
            }
        }
    }
    /**
     * Programmatically trigger rendering of the icon.
     *
     * This method is useful, when creating {\@link FaIconComponent} dynamically or
     * changing its inputs programmatically as in these cases icon won't be
     * re-rendered automatically.
     * @return {?}
     */
    render() {
        this.ngOnChanges({});
    }
    /**
     * @protected
     * @param {?} i
     * @return {?}
     */
    findIconDefinition(i) {
        /** @type {?} */
        const lookup = faNormalizeIconSpec(i, this.config.defaultPrefix);
        if ('icon' in lookup) {
            return lookup;
        }
        /** @type {?} */
        const definition = this.iconLibrary.getIconDefinition(lookup.prefix, lookup.iconName);
        if (definition != null) {
            return definition;
        }
        /** @type {?} */
        const globalDefinition = findIconDefinition(lookup);
        if (globalDefinition != null) {
            /** @type {?} */
            const message = 'Global icon library is deprecated. ' +
                'Consult https://github.com/FortAwesome/angular-fontawesome/blob/master/UPGRADING.md ' +
                'for the migration instructions.';
            if (this.config.globalLibrary === 'unset') {
                console.error('FontAwesome: ' + message);
            }
            else if (!this.config.globalLibrary) {
                throw new Error(message);
            }
            return globalDefinition;
        }
        faWarnIfIconDefinitionMissing(lookup);
        return null;
    }
    /**
     * @protected
     * @return {?}
     */
    buildParams() {
        /** @type {?} */
        const classOpts = {
            flip: this.flip,
            spin: this.spin,
            pulse: this.pulse,
            border: this.border,
            inverse: this.inverse,
            listItem: this.listItem,
            size: this.size || null,
            pull: this.pull || null,
            rotate: this.rotate || null,
            fixedWidth: this.fixedWidth,
            stackItemSize: this.stackItem != null ? this.stackItem.stackItemSize : null,
        };
        /** @type {?} */
        const parsedTransform = typeof this.transform === 'string' ? parse.transform(this.transform) : this.transform;
        return {
            title: this.title,
            transform: parsedTransform,
            classes: [...faClassList(classOpts), ...this.classes],
            mask: this.mask != null ? this.findIconDefinition(this.mask) : null,
            styles: this.styles != null ? this.styles : {},
            symbol: this.symbol,
            attributes: {
                role: this.a11yRole
            }
        };
    }
    /**
     * @private
     * @param {?} definition
     * @param {?} params
     * @return {?}
     */
    renderIcon(definition, params) {
        /** @type {?} */
        const renderedIcon = icon(definition, params);
        this.renderedIconHTML = this.sanitizer.bypassSecurityTrustHtml(renderedIcon.html.join('\n'));
    }
}
FaIconComponent.decorators = [
    { type: Component, args: [{
                selector: 'fa-icon',
                template: ``,
                host: {
                    class: 'ng-fa-icon',
                    '[attr.title]': 'title',
                }
            }] }
];
/** @nocollapse */
FaIconComponent.ctorParameters = () => [
    { type: DomSanitizer },
    { type: FaConfig },
    { type: FaIconLibrary },
    { type: FaStackItemSizeDirective, decorators: [{ type: Optional }] }
];
FaIconComponent.propDecorators = {
    icon: [{ type: Input }],
    title: [{ type: Input }],
    spin: [{ type: Input }],
    pulse: [{ type: Input }],
    mask: [{ type: Input }],
    styles: [{ type: Input }],
    flip: [{ type: Input }],
    size: [{ type: Input }],
    pull: [{ type: Input }],
    border: [{ type: Input }],
    inverse: [{ type: Input }],
    symbol: [{ type: Input }],
    listItem: [{ type: Input }],
    rotate: [{ type: Input }],
    fixedWidth: [{ type: Input }],
    classes: [{ type: Input }],
    transform: [{ type: Input }],
    a11yRole: [{ type: Input }],
    renderedIconHTML: [{ type: HostBinding, args: ['innerHTML',] }]
};
if (false) {
    /** @type {?} */
    FaIconComponent.prototype.icon;
    /**
     * Specify a title for the icon.
     * This text will be displayed in a tooltip on hover and presented to the
     * screen readers.
     * @type {?}
     */
    FaIconComponent.prototype.title;
    /** @type {?} */
    FaIconComponent.prototype.spin;
    /** @type {?} */
    FaIconComponent.prototype.pulse;
    /** @type {?} */
    FaIconComponent.prototype.mask;
    /** @type {?} */
    FaIconComponent.prototype.styles;
    /** @type {?} */
    FaIconComponent.prototype.flip;
    /** @type {?} */
    FaIconComponent.prototype.size;
    /** @type {?} */
    FaIconComponent.prototype.pull;
    /** @type {?} */
    FaIconComponent.prototype.border;
    /** @type {?} */
    FaIconComponent.prototype.inverse;
    /** @type {?} */
    FaIconComponent.prototype.symbol;
    /**
     * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use `fixedWidth` with your custom styles instead.
     * @type {?}
     */
    FaIconComponent.prototype.listItem;
    /** @type {?} */
    FaIconComponent.prototype.rotate;
    /** @type {?} */
    FaIconComponent.prototype.fixedWidth;
    /** @type {?} */
    FaIconComponent.prototype.classes;
    /** @type {?} */
    FaIconComponent.prototype.transform;
    /**
     * Specify the `role` attribute for the rendered <svg> element.
     *
     * \@default 'img'
     * @type {?}
     */
    FaIconComponent.prototype.a11yRole;
    /** @type {?} */
    FaIconComponent.prototype.renderedIconHTML;
    /**
     * @type {?}
     * @private
     */
    FaIconComponent.prototype.sanitizer;
    /**
     * @type {?}
     * @private
     */
    FaIconComponent.prototype.config;
    /**
     * @type {?}
     * @private
     */
    FaIconComponent.prototype.iconLibrary;
    /**
     * @type {?}
     * @private
     */
    FaIconComponent.prototype.stackItem;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWNvbi5jb21wb25lbnQuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AZm9ydGF3ZXNvbWUvYW5ndWxhci1mb250YXdlc29tZS8iLCJzb3VyY2VzIjpbImljb24vaWNvbi5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBYSxRQUFRLEVBQWlCLE1BQU0sZUFBZSxDQUFDO0FBQ2xHLE9BQU8sRUFBRSxZQUFZLEVBQVksTUFBTSwyQkFBMkIsQ0FBQztBQUNuRSxPQUFPLEVBRUwsa0JBQWtCLEVBRWxCLElBQUksRUFJSixLQUFLLEVBTU4sTUFBTSxtQ0FBbUMsQ0FBQztBQUMzQyxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sV0FBVyxDQUFDO0FBQ3JDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUNoRCxPQUFPLEVBQUUsNkJBQTZCLEVBQUUsTUFBTSw0Q0FBNEMsQ0FBQztBQUMzRixPQUFPLEVBQUUsdUJBQXVCLEVBQUUsTUFBTSw0Q0FBNEMsQ0FBQztBQUVyRixPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sZ0NBQWdDLENBQUM7QUFDN0QsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sMENBQTBDLENBQUM7QUFDL0UsT0FBTyxFQUFFLHdCQUF3QixFQUFFLE1BQU0sb0NBQW9DLENBQUM7QUFVOUUsTUFBTSxPQUFPLGVBQWU7Ozs7Ozs7SUFxRDFCLFlBQ1UsU0FBdUIsRUFDdkIsTUFBZ0IsRUFDaEIsV0FBMEIsRUFDZCxTQUFtQztRQUgvQyxjQUFTLEdBQVQsU0FBUyxDQUFjO1FBQ3ZCLFdBQU0sR0FBTixNQUFNLENBQVU7UUFDaEIsZ0JBQVcsR0FBWCxXQUFXLENBQWU7UUFDZCxjQUFTLEdBQVQsU0FBUyxDQUEwQjtRQS9CaEQsWUFBTyxHQUFjLEVBQUUsQ0FBQztJQWlDakMsQ0FBQzs7Ozs7SUFwQkQsSUFBSSxRQUFRO1FBQ1YsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ25CLENBQUM7Ozs7OztJQUtELElBQUksUUFBUSxDQUFDLEtBQWU7UUFDMUIsSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUM7SUFDcEIsQ0FBQzs7Ozs7SUFhRCxXQUFXLENBQUMsT0FBc0I7UUFDaEMsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksRUFBRTtZQUNyQixPQUFPLHVCQUF1QixFQUFFLENBQUM7U0FDbEM7UUFFRCxJQUFJLE9BQU8sRUFBRTs7a0JBQ0wsY0FBYyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQ3pELElBQUksY0FBYyxJQUFJLElBQUksRUFBRTs7c0JBQ3BCLE1BQU0sR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFO2dCQUNqQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxNQUFNLENBQUMsQ0FBQzthQUN6QztTQUNGO0lBQ0gsQ0FBQzs7Ozs7Ozs7O0lBU0QsTUFBTTtRQUNKLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDdkIsQ0FBQzs7Ozs7O0lBRVMsa0JBQWtCLENBQUMsQ0FBNEI7O2NBQ2pELE1BQU0sR0FBRyxtQkFBbUIsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUM7UUFDaEUsSUFBSSxNQUFNLElBQUksTUFBTSxFQUFFO1lBQ3BCLE9BQU8sTUFBTSxDQUFDO1NBQ2Y7O2NBRUssVUFBVSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQ3JGLElBQUksVUFBVSxJQUFJLElBQUksRUFBRTtZQUN0QixPQUFPLFVBQVUsQ0FBQztTQUNuQjs7Y0FFSyxnQkFBZ0IsR0FBRyxrQkFBa0IsQ0FBQyxNQUFNLENBQUM7UUFDbkQsSUFBSSxnQkFBZ0IsSUFBSSxJQUFJLEVBQUU7O2tCQUN0QixPQUFPLEdBQUcscUNBQXFDO2dCQUNuRCxzRkFBc0Y7Z0JBQ3RGLGlDQUFpQztZQUNuQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxLQUFLLE9BQU8sRUFBRTtnQkFDekMsT0FBTyxDQUFDLEtBQUssQ0FBQyxlQUFlLEdBQUcsT0FBTyxDQUFDLENBQUM7YUFDMUM7aUJBQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFO2dCQUNyQyxNQUFNLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQzFCO1lBRUQsT0FBTyxnQkFBZ0IsQ0FBQztTQUN6QjtRQUVELDZCQUE2QixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3RDLE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQzs7Ozs7SUFFUyxXQUFXOztjQUNiLFNBQVMsR0FBWTtZQUN6QixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDZixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDZixLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7WUFDakIsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ25CLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTztZQUNyQixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7WUFDdkIsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSTtZQUN2QixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJO1lBQ3ZCLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUk7WUFDM0IsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO1lBQzNCLGFBQWEsRUFBRSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLElBQUk7U0FDNUU7O2NBRUssZUFBZSxHQUFHLE9BQU8sSUFBSSxDQUFDLFNBQVMsS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUztRQUU3RyxPQUFPO1lBQ0wsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO1lBQ2pCLFNBQVMsRUFBRSxlQUFlO1lBQzFCLE9BQU8sRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLFNBQVMsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztZQUNyRCxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7WUFDbkUsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFO1lBQzlDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtZQUNuQixVQUFVLEVBQUU7Z0JBQ1YsSUFBSSxFQUFFLElBQUksQ0FBQyxRQUFRO2FBQ3BCO1NBQ0YsQ0FBQztJQUNKLENBQUM7Ozs7Ozs7SUFFTyxVQUFVLENBQUMsVUFBMEIsRUFBRSxNQUFrQjs7Y0FDekQsWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsTUFBTSxDQUFDO1FBQzdDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLHVCQUF1QixDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDL0YsQ0FBQzs7O1lBNUpGLFNBQVMsU0FBQztnQkFDVCxRQUFRLEVBQUUsU0FBUztnQkFDbkIsUUFBUSxFQUFFLEVBQUU7Z0JBQ1osSUFBSSxFQUFFO29CQUNKLEtBQUssRUFBRSxZQUFZO29CQUNuQixjQUFjLEVBQUUsT0FBTztpQkFDeEI7YUFDRjs7OztZQWhDUSxZQUFZO1lBZ0JaLFFBQVE7WUFDUixhQUFhO1lBTWIsd0JBQXdCLHVCQW1FNUIsUUFBUTs7O21CQXhEVixLQUFLO29CQU9MLEtBQUs7bUJBQ0wsS0FBSztvQkFDTCxLQUFLO21CQUNMLEtBQUs7cUJBQ0wsS0FBSzttQkFDTCxLQUFLO21CQUNMLEtBQUs7bUJBQ0wsS0FBSztxQkFDTCxLQUFLO3NCQUNMLEtBQUs7cUJBQ0wsS0FBSzt1QkFLTCxLQUFLO3FCQUNMLEtBQUs7eUJBQ0wsS0FBSztzQkFDTCxLQUFLO3dCQUNMLEtBQUs7dUJBT0wsS0FBSzsrQkFnQkwsV0FBVyxTQUFDLFdBQVc7Ozs7SUFqRHhCLCtCQUF3Qjs7Ozs7OztJQU94QixnQ0FBd0I7O0lBQ3hCLCtCQUF3Qjs7SUFDeEIsZ0NBQXlCOztJQUN6QiwrQkFBeUI7O0lBQ3pCLGlDQUF5Qjs7SUFDekIsK0JBQXlCOztJQUN6QiwrQkFBeUI7O0lBQ3pCLCtCQUF5Qjs7SUFDekIsaUNBQTBCOztJQUMxQixrQ0FBMkI7O0lBQzNCLGlDQUEyQjs7Ozs7SUFLM0IsbUNBQTRCOztJQUM1QixpQ0FBNkI7O0lBQzdCLHFDQUE4Qjs7SUFDOUIsa0NBQWlDOztJQUNqQyxvQ0FBd0M7Ozs7Ozs7SUFPeEMsbUNBQTBCOztJQWdCMUIsMkNBQ2tDOzs7OztJQUdoQyxvQ0FBK0I7Ozs7O0lBQy9CLGlDQUF3Qjs7Ozs7SUFDeEIsc0NBQWtDOzs7OztJQUNsQyxvQ0FBdUQiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIEhvc3RCaW5kaW5nLCBJbnB1dCwgT25DaGFuZ2VzLCBPcHRpb25hbCwgU2ltcGxlQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRG9tU2FuaXRpemVyLCBTYWZlSHRtbCB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xuaW1wb3J0IHtcbiAgRmFTeW1ib2wsXG4gIGZpbmRJY29uRGVmaW5pdGlvbixcbiAgRmxpcFByb3AsXG4gIGljb24sXG4gIEljb25EZWZpbml0aW9uLFxuICBJY29uUGFyYW1zLFxuICBJY29uUHJvcCxcbiAgcGFyc2UsXG4gIFB1bGxQcm9wLFxuICBSb3RhdGVQcm9wLFxuICBTaXplUHJvcCxcbiAgU3R5bGVzLFxuICBUcmFuc2Zvcm1cbn0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZvbnRhd2Vzb21lLXN2Zy1jb3JlJztcbmltcG9ydCB7IEZhQ29uZmlnIH0gZnJvbSAnLi4vY29uZmlnJztcbmltcG9ydCB7IEZhSWNvbkxpYnJhcnkgfSBmcm9tICcuLi9pY29uLWxpYnJhcnknO1xuaW1wb3J0IHsgZmFXYXJuSWZJY29uRGVmaW5pdGlvbk1pc3NpbmcgfSBmcm9tICcuLi9zaGFyZWQvZXJyb3JzL3dhcm4taWYtaWNvbi1odG1sLW1pc3NpbmcnO1xuaW1wb3J0IHsgZmFXYXJuSWZJY29uU3BlY01pc3NpbmcgfSBmcm9tICcuLi9zaGFyZWQvZXJyb3JzL3dhcm4taWYtaWNvbi1zcGVjLW1pc3NpbmcnO1xuaW1wb3J0IHsgRmFQcm9wcyB9IGZyb20gJy4uL3NoYXJlZC9tb2RlbHMvcHJvcHMubW9kZWwnO1xuaW1wb3J0IHsgZmFDbGFzc0xpc3QgfSBmcm9tICcuLi9zaGFyZWQvdXRpbHMvY2xhc3NsaXN0LnV0aWwnO1xuaW1wb3J0IHsgZmFOb3JtYWxpemVJY29uU3BlYyB9IGZyb20gJy4uL3NoYXJlZC91dGlscy9ub3JtYWxpemUtaWNvbi1zcGVjLnV0aWwnO1xuaW1wb3J0IHsgRmFTdGFja0l0ZW1TaXplRGlyZWN0aXZlIH0gZnJvbSAnLi4vc3RhY2svc3RhY2staXRlbS1zaXplLmRpcmVjdGl2ZSc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2ZhLWljb24nLFxuICB0ZW1wbGF0ZTogYGAsXG4gIGhvc3Q6IHtcbiAgICBjbGFzczogJ25nLWZhLWljb24nLFxuICAgICdbYXR0ci50aXRsZV0nOiAndGl0bGUnLFxuICB9XG59KVxuZXhwb3J0IGNsYXNzIEZhSWNvbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XG4gIEBJbnB1dCgpIGljb246IEljb25Qcm9wO1xuXG4gIC8qKlxuICAgKiBTcGVjaWZ5IGEgdGl0bGUgZm9yIHRoZSBpY29uLlxuICAgKiBUaGlzIHRleHQgd2lsbCBiZSBkaXNwbGF5ZWQgaW4gYSB0b29sdGlwIG9uIGhvdmVyIGFuZCBwcmVzZW50ZWQgdG8gdGhlXG4gICAqIHNjcmVlbiByZWFkZXJzLlxuICAgKi9cbiAgQElucHV0KCkgdGl0bGU/OiBzdHJpbmc7XG4gIEBJbnB1dCgpIHNwaW4/OiBib29sZWFuO1xuICBASW5wdXQoKSBwdWxzZT86IGJvb2xlYW47XG4gIEBJbnB1dCgpIG1hc2s/OiBJY29uUHJvcDtcbiAgQElucHV0KCkgc3R5bGVzPzogU3R5bGVzO1xuICBASW5wdXQoKSBmbGlwPzogRmxpcFByb3A7XG4gIEBJbnB1dCgpIHNpemU/OiBTaXplUHJvcDtcbiAgQElucHV0KCkgcHVsbD86IFB1bGxQcm9wO1xuICBASW5wdXQoKSBib3JkZXI/OiBib29sZWFuO1xuICBASW5wdXQoKSBpbnZlcnNlPzogYm9vbGVhbjtcbiAgQElucHV0KCkgc3ltYm9sPzogRmFTeW1ib2w7XG5cbiAgLyoqXG4gICAqIEBkZXByZWNhdGVkIFNpbmNlIDAuNS4wLiBXaWxsIGJlIHJlbW92ZWQgaW4gMC42LjAuIFVzZSBgZml4ZWRXaWR0aGAgd2l0aCB5b3VyIGN1c3RvbSBzdHlsZXMgaW5zdGVhZC5cbiAgICovXG4gIEBJbnB1dCgpIGxpc3RJdGVtPzogYm9vbGVhbjtcbiAgQElucHV0KCkgcm90YXRlPzogUm90YXRlUHJvcDtcbiAgQElucHV0KCkgZml4ZWRXaWR0aD86IGJvb2xlYW47XG4gIEBJbnB1dCgpIGNsYXNzZXM/OiBzdHJpbmdbXSA9IFtdO1xuICBASW5wdXQoKSB0cmFuc2Zvcm0/OiBzdHJpbmcgfCBUcmFuc2Zvcm07XG5cbiAgLyoqXG4gICAqIFNwZWNpZnkgdGhlIGByb2xlYCBhdHRyaWJ1dGUgZm9yIHRoZSByZW5kZXJlZCA8c3ZnPiBlbGVtZW50LlxuICAgKlxuICAgKiBAZGVmYXVsdCAnaW1nJ1xuICAgKi9cbiAgQElucHV0KCkgYTExeVJvbGU6IHN0cmluZztcblxuICAvKipcbiAgICogQGRlcHJlY2F0ZWQgU2luY2UgMC41LjAuIFdpbGwgYmUgcmVtb3ZlZCBpbiAwLjYuMC4gVXNlIGBpY29uYCBwcm9wZXJ0eSBkaXJlY3RseS5cbiAgICovXG4gIGdldCBpY29uUHJvcCgpOiBJY29uUHJvcCB7XG4gICAgcmV0dXJuIHRoaXMuaWNvbjtcbiAgfVxuXG4gIC8qKlxuICAgKiBAZGVwcmVjYXRlZCBTaW5jZSAwLjUuMC4gV2lsbCBiZSByZW1vdmVkIGluIDAuNi4wLiBVc2UgYGljb25gIHByb3BlcnR5IGRpcmVjdGx5LlxuICAgKi9cbiAgc2V0IGljb25Qcm9wKHZhbHVlOiBJY29uUHJvcCkge1xuICAgIHRoaXMuaWNvbiA9IHZhbHVlO1xuICB9XG5cbiAgQEhvc3RCaW5kaW5nKCdpbm5lckhUTUwnKVxuICBwdWJsaWMgcmVuZGVyZWRJY29uSFRNTDogU2FmZUh0bWw7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSBzYW5pdGl6ZXI6IERvbVNhbml0aXplcixcbiAgICBwcml2YXRlIGNvbmZpZzogRmFDb25maWcsXG4gICAgcHJpdmF0ZSBpY29uTGlicmFyeTogRmFJY29uTGlicmFyeSxcbiAgICBAT3B0aW9uYWwoKSBwcml2YXRlIHN0YWNrSXRlbTogRmFTdGFja0l0ZW1TaXplRGlyZWN0aXZlLFxuICApIHtcbiAgfVxuXG4gIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcbiAgICBpZiAodGhpcy5pY29uID09IG51bGwpIHtcbiAgICAgIHJldHVybiBmYVdhcm5JZkljb25TcGVjTWlzc2luZygpO1xuICAgIH1cblxuICAgIGlmIChjaGFuZ2VzKSB7XG4gICAgICBjb25zdCBpY29uRGVmaW5pdGlvbiA9IHRoaXMuZmluZEljb25EZWZpbml0aW9uKHRoaXMuaWNvbik7XG4gICAgICBpZiAoaWNvbkRlZmluaXRpb24gIT0gbnVsbCkge1xuICAgICAgICBjb25zdCBwYXJhbXMgPSB0aGlzLmJ1aWxkUGFyYW1zKCk7XG4gICAgICAgIHRoaXMucmVuZGVySWNvbihpY29uRGVmaW5pdGlvbiwgcGFyYW1zKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUHJvZ3JhbW1hdGljYWxseSB0cmlnZ2VyIHJlbmRlcmluZyBvZiB0aGUgaWNvbi5cbiAgICpcbiAgICogVGhpcyBtZXRob2QgaXMgdXNlZnVsLCB3aGVuIGNyZWF0aW5nIHtAbGluayBGYUljb25Db21wb25lbnR9IGR5bmFtaWNhbGx5IG9yXG4gICAqIGNoYW5naW5nIGl0cyBpbnB1dHMgcHJvZ3JhbW1hdGljYWxseSBhcyBpbiB0aGVzZSBjYXNlcyBpY29uIHdvbid0IGJlXG4gICAqIHJlLXJlbmRlcmVkIGF1dG9tYXRpY2FsbHkuXG4gICAqL1xuICByZW5kZXIoKSB7XG4gICAgdGhpcy5uZ09uQ2hhbmdlcyh7fSk7XG4gIH1cblxuICBwcm90ZWN0ZWQgZmluZEljb25EZWZpbml0aW9uKGk6IEljb25Qcm9wIHwgSWNvbkRlZmluaXRpb24pOiBJY29uRGVmaW5pdGlvbiB8IG51bGwge1xuICAgIGNvbnN0IGxvb2t1cCA9IGZhTm9ybWFsaXplSWNvblNwZWMoaSwgdGhpcy5jb25maWcuZGVmYXVsdFByZWZpeCk7XG4gICAgaWYgKCdpY29uJyBpbiBsb29rdXApIHtcbiAgICAgIHJldHVybiBsb29rdXA7XG4gICAgfVxuXG4gICAgY29uc3QgZGVmaW5pdGlvbiA9IHRoaXMuaWNvbkxpYnJhcnkuZ2V0SWNvbkRlZmluaXRpb24obG9va3VwLnByZWZpeCwgbG9va3VwLmljb25OYW1lKTtcbiAgICBpZiAoZGVmaW5pdGlvbiAhPSBudWxsKSB7XG4gICAgICByZXR1cm4gZGVmaW5pdGlvbjtcbiAgICB9XG5cbiAgICBjb25zdCBnbG9iYWxEZWZpbml0aW9uID0gZmluZEljb25EZWZpbml0aW9uKGxvb2t1cCk7XG4gICAgaWYgKGdsb2JhbERlZmluaXRpb24gIT0gbnVsbCkge1xuICAgICAgY29uc3QgbWVzc2FnZSA9ICdHbG9iYWwgaWNvbiBsaWJyYXJ5IGlzIGRlcHJlY2F0ZWQuICcgK1xuICAgICAgICAnQ29uc3VsdCBodHRwczovL2dpdGh1Yi5jb20vRm9ydEF3ZXNvbWUvYW5ndWxhci1mb250YXdlc29tZS9ibG9iL21hc3Rlci9VUEdSQURJTkcubWQgJyArXG4gICAgICAgICdmb3IgdGhlIG1pZ3JhdGlvbiBpbnN0cnVjdGlvbnMuJztcbiAgICAgIGlmICh0aGlzLmNvbmZpZy5nbG9iYWxMaWJyYXJ5ID09PSAndW5zZXQnKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZvbnRBd2Vzb21lOiAnICsgbWVzc2FnZSk7XG4gICAgICB9IGVsc2UgaWYgKCF0aGlzLmNvbmZpZy5nbG9iYWxMaWJyYXJ5KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihtZXNzYWdlKTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGdsb2JhbERlZmluaXRpb247XG4gICAgfVxuXG4gICAgZmFXYXJuSWZJY29uRGVmaW5pdGlvbk1pc3NpbmcobG9va3VwKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHByb3RlY3RlZCBidWlsZFBhcmFtcygpIHtcbiAgICBjb25zdCBjbGFzc09wdHM6IEZhUHJvcHMgPSB7XG4gICAgICBmbGlwOiB0aGlzLmZsaXAsXG4gICAgICBzcGluOiB0aGlzLnNwaW4sXG4gICAgICBwdWxzZTogdGhpcy5wdWxzZSxcbiAgICAgIGJvcmRlcjogdGhpcy5ib3JkZXIsXG4gICAgICBpbnZlcnNlOiB0aGlzLmludmVyc2UsXG4gICAgICBsaXN0SXRlbTogdGhpcy5saXN0SXRlbSxcbiAgICAgIHNpemU6IHRoaXMuc2l6ZSB8fCBudWxsLFxuICAgICAgcHVsbDogdGhpcy5wdWxsIHx8IG51bGwsXG4gICAgICByb3RhdGU6IHRoaXMucm90YXRlIHx8IG51bGwsXG4gICAgICBmaXhlZFdpZHRoOiB0aGlzLmZpeGVkV2lkdGgsXG4gICAgICBzdGFja0l0ZW1TaXplOiB0aGlzLnN0YWNrSXRlbSAhPSBudWxsID8gdGhpcy5zdGFja0l0ZW0uc3RhY2tJdGVtU2l6ZSA6IG51bGwsXG4gICAgfTtcblxuICAgIGNvbnN0IHBhcnNlZFRyYW5zZm9ybSA9IHR5cGVvZiB0aGlzLnRyYW5zZm9ybSA9PT0gJ3N0cmluZycgPyBwYXJzZS50cmFuc2Zvcm0odGhpcy50cmFuc2Zvcm0pIDogdGhpcy50cmFuc2Zvcm07XG5cbiAgICByZXR1cm4ge1xuICAgICAgdGl0bGU6IHRoaXMudGl0bGUsXG4gICAgICB0cmFuc2Zvcm06IHBhcnNlZFRyYW5zZm9ybSxcbiAgICAgIGNsYXNzZXM6IFsuLi5mYUNsYXNzTGlzdChjbGFzc09wdHMpLCAuLi50aGlzLmNsYXNzZXNdLFxuICAgICAgbWFzazogdGhpcy5tYXNrICE9IG51bGwgPyB0aGlzLmZpbmRJY29uRGVmaW5pdGlvbih0aGlzLm1hc2spIDogbnVsbCxcbiAgICAgIHN0eWxlczogdGhpcy5zdHlsZXMgIT0gbnVsbCA/IHRoaXMuc3R5bGVzIDoge30sXG4gICAgICBzeW1ib2w6IHRoaXMuc3ltYm9sLFxuICAgICAgYXR0cmlidXRlczoge1xuICAgICAgICByb2xlOiB0aGlzLmExMXlSb2xlXG4gICAgICB9XG4gICAgfTtcbiAgfVxuXG4gIHByaXZhdGUgcmVuZGVySWNvbihkZWZpbml0aW9uOiBJY29uRGVmaW5pdGlvbiwgcGFyYW1zOiBJY29uUGFyYW1zKSB7XG4gICAgY29uc3QgcmVuZGVyZWRJY29uID0gaWNvbihkZWZpbml0aW9uLCBwYXJhbXMpO1xuICAgIHRoaXMucmVuZGVyZWRJY29uSFRNTCA9IHRoaXMuc2FuaXRpemVyLmJ5cGFzc1NlY3VyaXR5VHJ1c3RIdG1sKHJlbmRlcmVkSWNvbi5odG1sLmpvaW4oJ1xcbicpKTtcbiAgfVxufVxuXG4iXX0=