/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Injectable } from '@angular/core';
import { FaConfig } from '../config';
import * as i0 from "@angular/core";
import * as i1 from "../config";
/**
 * @deprecated Since 0.5.0. Will be removed in 0.6.0. Use FaConfig directly.
 */
export class FaIconService {
    /**
     * @param {?} config
     */
    constructor(config) {
        this.config = config;
    }
    /**
     * @return {?}
     */
    get defaultPrefix() {
        return this.config.defaultPrefix;
    }
    /**
     * @param {?} value
     * @return {?}
     */
    set defaultPrefix(value) {
        this.config.defaultPrefix = value;
    }
}
FaIconService.decorators = [
    { type: Injectable, args: [{ providedIn: 'root' },] }
];
/** @nocollapse */
FaIconService.ctorParameters = () => [
    { type: FaConfig }
];
/** @nocollapse */ FaIconService.ngInjectableDef = i0.ɵɵdefineInjectable({ factory: function FaIconService_Factory() { return new FaIconService(i0.ɵɵinject(i1.FaConfig)); }, token: FaIconService, providedIn: "root" });
if (false) {
    /**
     * @type {?}
     * @private
     */
    FaIconService.prototype.config;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWNvbi5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQGZvcnRhd2Vzb21lL2FuZ3VsYXItZm9udGF3ZXNvbWUvIiwic291cmNlcyI6WyJpY29uL2ljb24uc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUUzQyxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sV0FBVyxDQUFDOzs7Ozs7QUFNckMsTUFBTSxPQUFPLGFBQWE7Ozs7SUFTeEIsWUFBb0IsTUFBZ0I7UUFBaEIsV0FBTSxHQUFOLE1BQU0sQ0FBVTtJQUFHLENBQUM7Ozs7SUFSeEMsSUFBSSxhQUFhO1FBQ2YsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQztJQUNuQyxDQUFDOzs7OztJQUVELElBQUksYUFBYSxDQUFDLEtBQWlCO1FBQ2pDLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztJQUNwQyxDQUFDOzs7WUFSRixVQUFVLFNBQUMsRUFBQyxVQUFVLEVBQUUsTUFBTSxFQUFDOzs7O1lBTHZCLFFBQVE7Ozs7Ozs7O0lBZUgsK0JBQXdCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSWNvblByZWZpeCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mb250YXdlc29tZS1zdmctY29yZSc7XG5pbXBvcnQgeyBGYUNvbmZpZyB9IGZyb20gJy4uL2NvbmZpZyc7XG5cbi8qKlxuICogQGRlcHJlY2F0ZWQgU2luY2UgMC41LjAuIFdpbGwgYmUgcmVtb3ZlZCBpbiAwLjYuMC4gVXNlIEZhQ29uZmlnIGRpcmVjdGx5LlxuICovXG5ASW5qZWN0YWJsZSh7cHJvdmlkZWRJbjogJ3Jvb3QnfSlcbmV4cG9ydCBjbGFzcyBGYUljb25TZXJ2aWNlIHtcbiAgZ2V0IGRlZmF1bHRQcmVmaXgoKTogSWNvblByZWZpeCB7XG4gICAgcmV0dXJuIHRoaXMuY29uZmlnLmRlZmF1bHRQcmVmaXg7XG4gIH1cblxuICBzZXQgZGVmYXVsdFByZWZpeCh2YWx1ZTogSWNvblByZWZpeCkge1xuICAgIHRoaXMuY29uZmlnLmRlZmF1bHRQcmVmaXggPSB2YWx1ZTtcbiAgfVxuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgY29uZmlnOiBGYUNvbmZpZykge31cbn1cbiJdfQ==