/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Fontawesome props.
 * @record
 */
export function FaProps() { }
if (false) {
    /** @type {?|undefined} */
    FaProps.prototype.mask;
    /** @type {?|undefined} */
    FaProps.prototype.className;
    /** @type {?|undefined} */
    FaProps.prototype.spin;
    /** @type {?|undefined} */
    FaProps.prototype.pulse;
    /** @type {?|undefined} */
    FaProps.prototype.border;
    /** @type {?|undefined} */
    FaProps.prototype.fixedWidth;
    /** @type {?|undefined} */
    FaProps.prototype.listItem;
    /** @type {?|undefined} */
    FaProps.prototype.counter;
    /** @type {?|undefined} */
    FaProps.prototype.inverse;
    /** @type {?|undefined} */
    FaProps.prototype.flip;
    /** @type {?|undefined} */
    FaProps.prototype.size;
    /** @type {?|undefined} */
    FaProps.prototype.pull;
    /** @type {?|undefined} */
    FaProps.prototype.rotate;
    /** @type {?|undefined} */
    FaProps.prototype.transform;
    /** @type {?|undefined} */
    FaProps.prototype.symbol;
    /** @type {?|undefined} */
    FaProps.prototype.style;
    /** @type {?|undefined} */
    FaProps.prototype.stackItemSize;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvcHMubW9kZWwuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AZm9ydGF3ZXNvbWUvYW5ndWxhci1mb250YXdlc29tZS8iLCJzb3VyY2VzIjpbInNoYXJlZC9tb2RlbHMvcHJvcHMubW9kZWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFjQSw2QkFrQkM7OztJQWpCQyx1QkFBZ0I7O0lBQ2hCLDRCQUFtQjs7SUFDbkIsdUJBQWU7O0lBQ2Ysd0JBQWdCOztJQUNoQix5QkFBaUI7O0lBQ2pCLDZCQUFxQjs7SUFDckIsMkJBQW1COztJQUNuQiwwQkFBa0I7O0lBQ2xCLDBCQUFrQjs7SUFDbEIsdUJBQWdCOztJQUNoQix1QkFBZ0I7O0lBQ2hCLHVCQUFnQjs7SUFDaEIseUJBQW9COztJQUNwQiw0QkFBK0I7O0lBQy9CLHlCQUFrQjs7SUFDbEIsd0JBQWU7O0lBQ2YsZ0NBQTRCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgRmFTeW1ib2wsXG4gIEZsaXBQcm9wLFxuICBJY29uUHJvcCxcbiAgUHVsbFByb3AsXG4gIFJvdGF0ZVByb3AsXG4gIFNpemVQcm9wLFxuICBUcmFuc2Zvcm0sXG4gIFN0eWxlc1xufSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuXG4vKipcbiAqIEZvbnRhd2Vzb21lIHByb3BzLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEZhUHJvcHMge1xuICBtYXNrPzogSWNvblByb3A7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgc3Bpbj86IGJvb2xlYW47XG4gIHB1bHNlPzogYm9vbGVhbjtcbiAgYm9yZGVyPzogYm9vbGVhbjtcbiAgZml4ZWRXaWR0aD86IGJvb2xlYW47XG4gIGxpc3RJdGVtPzogYm9vbGVhbjtcbiAgY291bnRlcj86IGJvb2xlYW47XG4gIGludmVyc2U/OiBib29sZWFuO1xuICBmbGlwPzogRmxpcFByb3A7XG4gIHNpemU/OiBTaXplUHJvcDtcbiAgcHVsbD86IFB1bGxQcm9wO1xuICByb3RhdGU/OiBSb3RhdGVQcm9wO1xuICB0cmFuc2Zvcm0/OiBzdHJpbmcgfCBUcmFuc2Zvcm07XG4gIHN5bWJvbD86IEZhU3ltYm9sO1xuICBzdHlsZT86IFN0eWxlcztcbiAgc3RhY2tJdGVtU2l6ZT86ICcxeCcgfCAnMngnO1xufVxuIl19