/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Warns if parent component not existing.
 * @type {?}
 */
export const faWarnIfParentNotExist = (/**
 * @param {?} parent
 * @param {?} parentName
 * @param {?} childName
 * @return {?}
 */
(parent, parentName, childName) => {
    if (!parent) {
        console.error(`FontAwesome: ${childName} should be used as child of ${parentName} only.`);
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2Fybi1pZi1wYXJlbnQtbm90LWV4aXN0LmpzIiwic291cmNlUm9vdCI6Im5nOi8vQGZvcnRhd2Vzb21lL2FuZ3VsYXItZm9udGF3ZXNvbWUvIiwic291cmNlcyI6WyJzaGFyZWQvZXJyb3JzL3dhcm4taWYtcGFyZW50LW5vdC1leGlzdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUdBLE1BQU0sT0FBTyxzQkFBc0I7Ozs7OztBQUFHLENBQUMsTUFBVyxFQUFFLFVBQWtCLEVBQUUsU0FBaUIsRUFBRSxFQUFFO0lBQzNGLElBQUksQ0FBQyxNQUFNLEVBQUU7UUFDWCxPQUFPLENBQUMsS0FBSyxDQUFDLGdCQUFnQixTQUFTLCtCQUErQixVQUFVLFFBQVEsQ0FBQyxDQUFDO0tBQzNGO0FBQ0gsQ0FBQyxDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBXYXJucyBpZiBwYXJlbnQgY29tcG9uZW50IG5vdCBleGlzdGluZy5cbiAqL1xuZXhwb3J0IGNvbnN0IGZhV2FybklmUGFyZW50Tm90RXhpc3QgPSAocGFyZW50OiBhbnksIHBhcmVudE5hbWU6IHN0cmluZywgY2hpbGROYW1lOiBzdHJpbmcpID0+IHtcbiAgaWYgKCFwYXJlbnQpIHtcbiAgICBjb25zb2xlLmVycm9yKGBGb250QXdlc29tZTogJHtjaGlsZE5hbWV9IHNob3VsZCBiZSB1c2VkIGFzIGNoaWxkIG9mICR7cGFyZW50TmFtZX0gb25seS5gKTtcbiAgfVxufTtcbiJdfQ==