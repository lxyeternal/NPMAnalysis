/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Fontawesome class list.
 * Returns classes array by props.
 * @type {?}
 */
export const faClassList = (/**
 * @param {?} props
 * @return {?}
 */
(props) => {
    /** @type {?} */
    const classes = {
        'fa-spin': props.spin,
        'fa-pulse': props.pulse,
        'fa-fw': props.fixedWidth,
        'fa-border': props.border,
        'fa-li': props.listItem,
        'fa-inverse': props.inverse,
        'fa-layers-counter': props.counter,
        'fa-flip-horizontal': props.flip === 'horizontal' || props.flip === 'both',
        'fa-flip-vertical': props.flip === 'vertical' || props.flip === 'both',
        [`fa-${props.size}`]: props.size !== null,
        [`fa-rotate-${props.rotate}`]: props.rotate !== null,
        [`fa-pull-${props.pull}`]: props.pull !== null,
        [`fa-stack-${props.stackItemSize}`]: props.stackItemSize != null,
    };
    return Object.keys(classes)
        .map((/**
     * @param {?} key
     * @return {?}
     */
    key => (classes[key] ? key : null)))
        .filter((/**
     * @param {?} key
     * @return {?}
     */
    key => key));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xhc3NsaXN0LnV0aWwuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AZm9ydGF3ZXNvbWUvYW5ndWxhci1mb250YXdlc29tZS8iLCJzb3VyY2VzIjpbInNoYXJlZC91dGlscy9jbGFzc2xpc3QudXRpbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFNQSxNQUFNLE9BQU8sV0FBVzs7OztBQUFHLENBQUMsS0FBYyxFQUFZLEVBQUU7O1VBQ2hELE9BQU8sR0FBRztRQUNkLFNBQVMsRUFBRSxLQUFLLENBQUMsSUFBSTtRQUNyQixVQUFVLEVBQUUsS0FBSyxDQUFDLEtBQUs7UUFDdkIsT0FBTyxFQUFFLEtBQUssQ0FBQyxVQUFVO1FBQ3pCLFdBQVcsRUFBRSxLQUFLLENBQUMsTUFBTTtRQUN6QixPQUFPLEVBQUUsS0FBSyxDQUFDLFFBQVE7UUFDdkIsWUFBWSxFQUFFLEtBQUssQ0FBQyxPQUFPO1FBQzNCLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxPQUFPO1FBQ2xDLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxJQUFJLEtBQUssWUFBWSxJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssTUFBTTtRQUMxRSxrQkFBa0IsRUFBRSxLQUFLLENBQUMsSUFBSSxLQUFLLFVBQVUsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLE1BQU07UUFDdEUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxJQUFJLEtBQUssSUFBSTtRQUN6QyxDQUFDLGFBQWEsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sS0FBSyxJQUFJO1FBQ3BELENBQUMsV0FBVyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsSUFBSSxLQUFLLElBQUk7UUFDOUMsQ0FBQyxZQUFZLEtBQUssQ0FBQyxhQUFhLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxhQUFhLElBQUksSUFBSTtLQUNqRTtJQUVELE9BQU8sTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7U0FDeEIsR0FBRzs7OztJQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUM7U0FDdkMsTUFBTTs7OztJQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRmFQcm9wcyB9IGZyb20gJy4uL21vZGVscy9wcm9wcy5tb2RlbCc7XG5cbi8qKlxuICogRm9udGF3ZXNvbWUgY2xhc3MgbGlzdC5cbiAqIFJldHVybnMgY2xhc3NlcyBhcnJheSBieSBwcm9wcy5cbiAqL1xuZXhwb3J0IGNvbnN0IGZhQ2xhc3NMaXN0ID0gKHByb3BzOiBGYVByb3BzKTogc3RyaW5nW10gPT4ge1xuICBjb25zdCBjbGFzc2VzID0ge1xuICAgICdmYS1zcGluJzogcHJvcHMuc3BpbixcbiAgICAnZmEtcHVsc2UnOiBwcm9wcy5wdWxzZSxcbiAgICAnZmEtZncnOiBwcm9wcy5maXhlZFdpZHRoLFxuICAgICdmYS1ib3JkZXInOiBwcm9wcy5ib3JkZXIsXG4gICAgJ2ZhLWxpJzogcHJvcHMubGlzdEl0ZW0sXG4gICAgJ2ZhLWludmVyc2UnOiBwcm9wcy5pbnZlcnNlLFxuICAgICdmYS1sYXllcnMtY291bnRlcic6IHByb3BzLmNvdW50ZXIsXG4gICAgJ2ZhLWZsaXAtaG9yaXpvbnRhbCc6IHByb3BzLmZsaXAgPT09ICdob3Jpem9udGFsJyB8fCBwcm9wcy5mbGlwID09PSAnYm90aCcsXG4gICAgJ2ZhLWZsaXAtdmVydGljYWwnOiBwcm9wcy5mbGlwID09PSAndmVydGljYWwnIHx8IHByb3BzLmZsaXAgPT09ICdib3RoJyxcbiAgICBbYGZhLSR7cHJvcHMuc2l6ZX1gXTogcHJvcHMuc2l6ZSAhPT0gbnVsbCxcbiAgICBbYGZhLXJvdGF0ZS0ke3Byb3BzLnJvdGF0ZX1gXTogcHJvcHMucm90YXRlICE9PSBudWxsLFxuICAgIFtgZmEtcHVsbC0ke3Byb3BzLnB1bGx9YF06IHByb3BzLnB1bGwgIT09IG51bGwsXG4gICAgW2BmYS1zdGFjay0ke3Byb3BzLnN0YWNrSXRlbVNpemV9YF06IHByb3BzLnN0YWNrSXRlbVNpemUgIT0gbnVsbCxcbiAgfTtcblxuICByZXR1cm4gT2JqZWN0LmtleXMoY2xhc3NlcylcbiAgICAubWFwKGtleSA9PiAoY2xhc3Nlc1trZXldID8ga2V5IDogbnVsbCkpXG4gICAgLmZpbHRlcihrZXkgPT4ga2V5KTtcbn07XG4iXX0=