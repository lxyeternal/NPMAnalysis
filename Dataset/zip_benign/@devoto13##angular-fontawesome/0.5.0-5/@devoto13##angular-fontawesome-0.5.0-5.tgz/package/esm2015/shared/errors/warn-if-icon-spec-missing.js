/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
export const faWarnIfIconSpecMissing = (/**
 * @return {?}
 */
() => {
    console.error('FontAwesome: Property `icon` is required for `fa-icon`/`fa-duotone-icon` components. ' +
        `This warning will become a hard error in 0.6.0.`);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2Fybi1pZi1pY29uLXNwZWMtbWlzc2luZy5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0Bmb3J0YXdlc29tZS9hbmd1bGFyLWZvbnRhd2Vzb21lLyIsInNvdXJjZXMiOlsic2hhcmVkL2Vycm9ycy93YXJuLWlmLWljb24tc3BlYy1taXNzaW5nLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsTUFBTSxPQUFPLHVCQUF1Qjs7O0FBQUcsR0FBRyxFQUFFO0lBQzFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsdUZBQXVGO1FBQ25HLGlEQUFpRCxDQUFDLENBQUM7QUFDdkQsQ0FBQyxDQUFBIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IGZhV2FybklmSWNvblNwZWNNaXNzaW5nID0gKCkgPT4ge1xuICBjb25zb2xlLmVycm9yKCdGb250QXdlc29tZTogUHJvcGVydHkgYGljb25gIGlzIHJlcXVpcmVkIGZvciBgZmEtaWNvbmAvYGZhLWR1b3RvbmUtaWNvbmAgY29tcG9uZW50cy4gJyArXG4gICAgYFRoaXMgd2FybmluZyB3aWxsIGJlY29tZSBhIGhhcmQgZXJyb3IgaW4gMC42LjAuYCk7XG59O1xuIl19