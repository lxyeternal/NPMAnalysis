/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class FaIconLibrary {
    constructor() {
        this.definitions = {};
    }
    /**
     * @param {...?} icons
     * @return {?}
     */
    addIcons(...icons) {
        for (let i = 0; i < icons.length; i++) {
            /** @type {?} */
            const icon = icons[i];
            if (!(icon.prefix in this.definitions)) {
                this.definitions[icon.prefix] = {};
            }
            this.definitions[icon.prefix][icon.iconName] = icon;
        }
    }
    /**
     * @param {...?} packs
     * @return {?}
     */
    addIconPacks(...packs) {
        for (let i = 0; i < packs.length; i++) {
            /** @type {?} */
            const pack = packs[i];
            /** @type {?} */
            const icons = Object.keys(pack).map((/**
             * @param {?} key
             * @return {?}
             */
            (key) => pack[key]));
            this.addIcons(...icons);
        }
    }
    /**
     * @param {?} prefix
     * @param {?} name
     * @return {?}
     */
    getIconDefinition(prefix, name) {
        if (prefix in this.definitions && name in this.definitions[prefix]) {
            return this.definitions[prefix][name];
        }
        return null;
    }
}
FaIconLibrary.decorators = [
    { type: Injectable, args: [{ providedIn: 'root' },] }
];
/** @nocollapse */ FaIconLibrary.ngInjectableDef = i0.ɵɵdefineInjectable({ factory: function FaIconLibrary_Factory() { return new FaIconLibrary(); }, token: FaIconLibrary, providedIn: "root" });
if (false) {
    /**
     * @type {?}
     * @private
     */
    FaIconLibrary.prototype.definitions;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWNvbi1saWJyYXJ5LmpzIiwic291cmNlUm9vdCI6Im5nOi8vQGZvcnRhd2Vzb21lL2FuZ3VsYXItZm9udGF3ZXNvbWUvIiwic291cmNlcyI6WyJpY29uLWxpYnJhcnkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBSTNDLE1BQU0sT0FBTyxhQUFhO0lBRDFCO1FBRVUsZ0JBQVcsR0FBNkQsRUFBRSxDQUFDO0tBMEJwRjs7Ozs7SUF4QkMsUUFBUSxDQUFDLEdBQUcsS0FBdUI7UUFDakMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7O2tCQUMvQixJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUNyQixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRTtnQkFDdEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDO2FBQ3BDO1lBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUksQ0FBQztTQUNyRDtJQUNILENBQUM7Ozs7O0lBRUQsWUFBWSxDQUFDLEdBQUcsS0FBaUI7UUFDL0IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7O2tCQUMvQixJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQzs7a0JBQ2YsS0FBSyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRzs7OztZQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUM7WUFDdkQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDO1NBQ3pCO0lBQ0gsQ0FBQzs7Ozs7O0lBRUQsaUJBQWlCLENBQUMsTUFBa0IsRUFBRSxJQUFjO1FBQ2xELElBQUksTUFBTSxJQUFJLElBQUksQ0FBQyxXQUFXLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDbEUsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3ZDO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDOzs7WUEzQkYsVUFBVSxTQUFDLEVBQUMsVUFBVSxFQUFFLE1BQU0sRUFBQzs7Ozs7Ozs7SUFFOUIsb0NBQW1GIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSWNvbkRlZmluaXRpb24sIEljb25OYW1lLCBJY29uUGFjaywgSWNvblByZWZpeCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mb250YXdlc29tZS1zdmctY29yZSc7XG5cbkBJbmplY3RhYmxlKHtwcm92aWRlZEluOiAncm9vdCd9KVxuZXhwb3J0IGNsYXNzIEZhSWNvbkxpYnJhcnkge1xuICBwcml2YXRlIGRlZmluaXRpb25zOiB7IFtwcmVmaXg6IHN0cmluZ106IHsgW25hbWU6IHN0cmluZ106IEljb25EZWZpbml0aW9uIH0gfSA9IHt9O1xuXG4gIGFkZEljb25zKC4uLmljb25zOiBJY29uRGVmaW5pdGlvbltdKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpY29ucy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgaWNvbiA9IGljb25zW2ldO1xuICAgICAgaWYgKCEoaWNvbi5wcmVmaXggaW4gdGhpcy5kZWZpbml0aW9ucykpIHtcbiAgICAgICAgdGhpcy5kZWZpbml0aW9uc1tpY29uLnByZWZpeF0gPSB7fTtcbiAgICAgIH1cbiAgICAgIHRoaXMuZGVmaW5pdGlvbnNbaWNvbi5wcmVmaXhdW2ljb24uaWNvbk5hbWVdID0gaWNvbjtcbiAgICB9XG4gIH1cblxuICBhZGRJY29uUGFja3MoLi4ucGFja3M6IEljb25QYWNrW10pIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHBhY2tzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBwYWNrID0gcGFja3NbaV07XG4gICAgICBjb25zdCBpY29ucyA9IE9iamVjdC5rZXlzKHBhY2spLm1hcCgoa2V5KSA9PiBwYWNrW2tleV0pO1xuICAgICAgdGhpcy5hZGRJY29ucyguLi5pY29ucyk7XG4gICAgfVxuICB9XG5cbiAgZ2V0SWNvbkRlZmluaXRpb24ocHJlZml4OiBJY29uUHJlZml4LCBuYW1lOiBJY29uTmFtZSk6IEljb25EZWZpbml0aW9uIHwgbnVsbCB7XG4gICAgaWYgKHByZWZpeCBpbiB0aGlzLmRlZmluaXRpb25zICYmIG5hbWUgaW4gdGhpcy5kZWZpbml0aW9uc1twcmVmaXhdKSB7XG4gICAgICByZXR1cm4gdGhpcy5kZWZpbml0aW9uc1twcmVmaXhdW25hbWVdO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuIl19