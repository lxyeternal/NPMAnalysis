/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Input, Inject, Injectable, Optional, forwardRef, HostBinding } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { FaLayersComponent } from './layers.component';
import { faWarnIfParentNotExist } from '../shared/errors/warn-if-parent-not-exist';
/**
 * @abstract
 */
export class FaLayersTextBaseComponent {
    /**
     * @param {?} parent
     * @param {?} sanitizer
     */
    constructor(parent, sanitizer) {
        this.parent = parent;
        this.sanitizer = sanitizer;
        this.classes = [];
        faWarnIfParentNotExist(this.parent, 'FaLayersComponent', this.constructor.name);
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes) {
            this.updateParams();
            this.updateContent();
        }
    }
    /**
     * Updating content by params and content.
     * @private
     * @return {?}
     */
    updateContent() {
        this.renderedHTML = this.sanitizer.bypassSecurityTrustHtml(this.renderFontawesomeObject(this.content || '', this.params).html.join('\n'));
    }
}
FaLayersTextBaseComponent.decorators = [
    { type: Injectable }
];
/** @nocollapse */
FaLayersTextBaseComponent.ctorParameters = () => [
    { type: FaLayersComponent, decorators: [{ type: Inject, args: [forwardRef((/**
                     * @return {?}
                     */
                    () => FaLayersComponent)),] }, { type: Optional }] },
    { type: DomSanitizer }
];
FaLayersTextBaseComponent.propDecorators = {
    renderedHTML: [{ type: HostBinding, args: ['innerHTML',] }],
    content: [{ type: Input }],
    title: [{ type: Input }],
    styles: [{ type: Input }],
    classes: [{ type: Input }]
};
if (false) {
    /** @type {?} */
    FaLayersTextBaseComponent.prototype.renderedHTML;
    /**
     * @type {?}
     * @protected
     */
    FaLayersTextBaseComponent.prototype.params;
    /**
     * @type {?}
     * @protected
     */
    FaLayersTextBaseComponent.prototype.content;
    /**
     * @type {?}
     * @protected
     */
    FaLayersTextBaseComponent.prototype.title;
    /**
     * @type {?}
     * @protected
     */
    FaLayersTextBaseComponent.prototype.styles;
    /**
     * @type {?}
     * @protected
     */
    FaLayersTextBaseComponent.prototype.classes;
    /**
     * @type {?}
     * @private
     */
    FaLayersTextBaseComponent.prototype.parent;
    /**
     * @type {?}
     * @private
     */
    FaLayersTextBaseComponent.prototype.sanitizer;
    /**
     * Updating params by component props.
     * @abstract
     * @protected
     * @return {?}
     */
    FaLayersTextBaseComponent.prototype.updateParams = function () { };
    /**
     * Render the FontawesomeObject using the content and params.
     * @abstract
     * @protected
     * @param {?} content
     * @param {?=} params
     * @return {?}
     */
    FaLayersTextBaseComponent.prototype.renderFontawesomeObject = function (content, params) { };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGF5ZXJzLXRleHQtYmFzZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290Ijoibmc6Ly9AZm9ydGF3ZXNvbWUvYW5ndWxhci1mb250YXdlc29tZS8iLCJzb3VyY2VzIjpbImxheWVycy9sYXllcnMtdGV4dC1iYXNlLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsT0FBTyxFQUNMLEtBQUssRUFDTCxNQUFNLEVBQ04sVUFBVSxFQUNWLFFBQVEsRUFFUixVQUFVLEVBQ1YsV0FBVyxFQUVaLE1BQU0sZUFBZSxDQUFDO0FBTXZCLE9BQU8sRUFBRSxZQUFZLEVBQVksTUFBTSwyQkFBMkIsQ0FBQztBQUVuRSxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUN2RCxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSwyQ0FBMkMsQ0FBQzs7OztBQUduRixNQUFNLE9BQWdCLHlCQUF5Qjs7Ozs7SUFLN0MsWUFBNkUsTUFBeUIsRUFDNUYsU0FBdUI7UUFENEMsV0FBTSxHQUFOLE1BQU0sQ0FBbUI7UUFDNUYsY0FBUyxHQUFULFNBQVMsQ0FBYztRQVVkLFlBQU8sR0FBYyxFQUFFLENBQUM7UUFSekMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxtQkFBbUIsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2xGLENBQUM7Ozs7O0lBU0QsV0FBVyxDQUFDLE9BQXNCO1FBQ2hDLElBQUksT0FBTyxFQUFFO1lBQ1gsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztTQUN0QjtJQUNILENBQUM7Ozs7OztJQWVPLGFBQWE7UUFDbkIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLHVCQUF1QixDQUN4RCxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLE9BQU8sSUFBSSxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQzlFLENBQUM7SUFDSixDQUFDOzs7WUEzQ0YsVUFBVTs7OztZQUhGLGlCQUFpQix1QkFTWCxNQUFNLFNBQUMsVUFBVTs7O29CQUFDLEdBQUcsRUFBRSxDQUFDLGlCQUFpQixFQUFDLGNBQUcsUUFBUTtZQVgzRCxZQUFZOzs7MkJBUWxCLFdBQVcsU0FBQyxXQUFXO3NCQVd2QixLQUFLO29CQUNMLEtBQUs7cUJBQ0wsS0FBSztzQkFDTCxLQUFLOzs7O0lBZE4saURBQzhCOzs7OztJQVE5QiwyQ0FBNkI7Ozs7O0lBRTdCLDRDQUFtQzs7Ozs7SUFDbkMsMENBQWtDOzs7OztJQUNsQywyQ0FBbUM7Ozs7O0lBQ25DLDRDQUEyQzs7Ozs7SUFYL0IsMkNBQTBGOzs7OztJQUNwRyw4Q0FBK0I7Ozs7Ozs7SUFzQmpDLG1FQUF3Qzs7Ozs7Ozs7O0lBS3hDLDZGQUE2RyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIElucHV0LFxuICBJbmplY3QsXG4gIEluamVjdGFibGUsXG4gIE9wdGlvbmFsLFxuICBPbkNoYW5nZXMsXG4gIGZvcndhcmRSZWYsXG4gIEhvc3RCaW5kaW5nLFxuICBTaW1wbGVDaGFuZ2VzXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgU3R5bGVzLFxuICBGb250YXdlc29tZU9iamVjdCxcbiAgVGV4dFBhcmFtc1xufSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuaW1wb3J0IHsgRG9tU2FuaXRpemVyLCBTYWZlSHRtbCB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xuXG5pbXBvcnQgeyBGYUxheWVyc0NvbXBvbmVudCB9IGZyb20gJy4vbGF5ZXJzLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBmYVdhcm5JZlBhcmVudE5vdEV4aXN0IH0gZnJvbSAnLi4vc2hhcmVkL2Vycm9ycy93YXJuLWlmLXBhcmVudC1ub3QtZXhpc3QnO1xuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgYWJzdHJhY3QgY2xhc3MgRmFMYXllcnNUZXh0QmFzZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XG5cbiAgQEhvc3RCaW5kaW5nKCdpbm5lckhUTUwnKVxuICBwdWJsaWMgcmVuZGVyZWRIVE1MOiBTYWZlSHRtbDtcblxuICBjb25zdHJ1Y3RvcihASW5qZWN0KGZvcndhcmRSZWYoKCkgPT4gRmFMYXllcnNDb21wb25lbnQpKSBAT3B0aW9uYWwoKSBwcml2YXRlIHBhcmVudDogRmFMYXllcnNDb21wb25lbnQsXG4gICAgcHJpdmF0ZSBzYW5pdGl6ZXI6IERvbVNhbml0aXplcikge1xuXG4gICAgZmFXYXJuSWZQYXJlbnROb3RFeGlzdCh0aGlzLnBhcmVudCwgJ0ZhTGF5ZXJzQ29tcG9uZW50JywgdGhpcy5jb25zdHJ1Y3Rvci5uYW1lKTtcbiAgfVxuXG4gIHByb3RlY3RlZCBwYXJhbXM6IFRleHRQYXJhbXM7XG5cbiAgQElucHV0KCkgcHJvdGVjdGVkIGNvbnRlbnQ6IHN0cmluZztcbiAgQElucHV0KCkgcHJvdGVjdGVkIHRpdGxlPzogc3RyaW5nO1xuICBASW5wdXQoKSBwcm90ZWN0ZWQgc3R5bGVzPzogU3R5bGVzO1xuICBASW5wdXQoKSBwcm90ZWN0ZWQgY2xhc3Nlcz86IHN0cmluZ1tdID0gW107XG5cbiAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgIGlmIChjaGFuZ2VzKSB7XG4gICAgICB0aGlzLnVwZGF0ZVBhcmFtcygpO1xuICAgICAgdGhpcy51cGRhdGVDb250ZW50KCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFVwZGF0aW5nIHBhcmFtcyBieSBjb21wb25lbnQgcHJvcHMuXG4gICAqL1xuICBwcm90ZWN0ZWQgYWJzdHJhY3QgdXBkYXRlUGFyYW1zKCk6IHZvaWQ7XG5cbiAgLyoqXG4gICAqIFJlbmRlciB0aGUgRm9udGF3ZXNvbWVPYmplY3QgdXNpbmcgdGhlIGNvbnRlbnQgYW5kIHBhcmFtcy5cbiAgICovXG4gIHByb3RlY3RlZCBhYnN0cmFjdCByZW5kZXJGb250YXdlc29tZU9iamVjdChjb250ZW50OiBzdHJpbmcgfCBudW1iZXIsIHBhcmFtcz86IFRleHRQYXJhbXMpOiBGb250YXdlc29tZU9iamVjdDtcblxuICAvKipcbiAgICogVXBkYXRpbmcgY29udGVudCBieSBwYXJhbXMgYW5kIGNvbnRlbnQuXG4gICAqL1xuICBwcml2YXRlIHVwZGF0ZUNvbnRlbnQoKSB7XG4gICAgdGhpcy5yZW5kZXJlZEhUTUwgPSB0aGlzLnNhbml0aXplci5ieXBhc3NTZWN1cml0eVRydXN0SHRtbChcbiAgICAgIHRoaXMucmVuZGVyRm9udGF3ZXNvbWVPYmplY3QodGhpcy5jb250ZW50IHx8ICcnLCB0aGlzLnBhcmFtcykuaHRtbC5qb2luKCdcXG4nKVxuICAgICk7XG4gIH1cbn1cblxuIl19