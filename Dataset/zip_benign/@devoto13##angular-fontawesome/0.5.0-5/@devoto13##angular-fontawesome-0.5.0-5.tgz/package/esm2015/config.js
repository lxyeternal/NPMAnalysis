/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class FaConfig {
    constructor() {
        /**
         * Default prefix to use, when one is not provided with the icon name.
         *
         * \@default 'fas'
         */
        this.defaultPrefix = 'fas';
        /**
         * Whether components should lookup icon definitions in the global icon
         * library (the one available from
         * `import { library } from '\@fortawesome/fontawesome-svg-core')`.
         *
         * See https://github.com/FortAwesome/angular-fontawesome/blob/master/docs/usage/icon-library.md
         * for detailed description of library modes.
         *
         * - 'unset' - Components should lookup icon definitions in the global library
         * and emit warning if they find a definition there. This option is a default
         * to assist existing applications with a migration. Applications are expected
         * to switch to using {\@link FaIconLibrary}.
         * - true - Components should lookup icon definitions in the global library.
         * Note that global icon library is deprecated and support for it will be
         * removed. This option can be used to temporarily suppress warnings.
         * - false - Components should not lookup icon definitions in the global
         * library. Library will throw an error if missing icon is found in the global
         * library.
         *
         * @deprecated This option is deprecated since 0.5.0. In 0.6.0 default will
         * be changed to false. In 0.7.0 the option will be removed together with the
         * support for the global icon library.
         *
         * \@default 'unset'
         */
        this.globalLibrary = 'unset';
    }
}
FaConfig.decorators = [
    { type: Injectable, args: [{ providedIn: 'root' },] }
];
/** @nocollapse */ FaConfig.ngInjectableDef = i0.ɵɵdefineInjectable({ factory: function FaConfig_Factory() { return new FaConfig(); }, token: FaConfig, providedIn: "root" });
if (false) {
    /**
     * Default prefix to use, when one is not provided with the icon name.
     *
     * \@default 'fas'
     * @type {?}
     */
    FaConfig.prototype.defaultPrefix;
    /**
     * Whether components should lookup icon definitions in the global icon
     * library (the one available from
     * `import { library } from '\@fortawesome/fontawesome-svg-core')`.
     *
     * See https://github.com/FortAwesome/angular-fontawesome/blob/master/docs/usage/icon-library.md
     * for detailed description of library modes.
     *
     * - 'unset' - Components should lookup icon definitions in the global library
     * and emit warning if they find a definition there. This option is a default
     * to assist existing applications with a migration. Applications are expected
     * to switch to using {\@link FaIconLibrary}.
     * - true - Components should lookup icon definitions in the global library.
     * Note that global icon library is deprecated and support for it will be
     * removed. This option can be used to temporarily suppress warnings.
     * - false - Components should not lookup icon definitions in the global
     * library. Library will throw an error if missing icon is found in the global
     * library.
     *
     * @deprecated This option is deprecated since 0.5.0. In 0.6.0 default will
     * be changed to false. In 0.7.0 the option will be removed together with the
     * support for the global icon library.
     *
     * \@default 'unset'
     * @type {?}
     */
    FaConfig.prototype.globalLibrary;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmpzIiwic291cmNlUm9vdCI6Im5nOi8vQGZvcnRhd2Vzb21lL2FuZ3VsYXItZm9udGF3ZXNvbWUvIiwic291cmNlcyI6WyJjb25maWcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBSzNDLE1BQU0sT0FBTyxRQUFRO0lBRHJCOzs7Ozs7UUFPRSxrQkFBYSxHQUFlLEtBQUssQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7UUEyQmxDLGtCQUFhLEdBQXNCLE9BQU8sQ0FBQztLQUM1Qzs7O1lBbkNBLFVBQVUsU0FBQyxFQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUM7Ozs7Ozs7Ozs7SUFPOUIsaUNBQWtDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUEyQmxDLGlDQUEyQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEljb25QcmVmaXggfSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtY29tbW9uLXR5cGVzJztcbmltcG9ydCB7IEZhSWNvbkxpYnJhcnkgfSBmcm9tICcuL2ljb24tbGlicmFyeSc7XG5cbkBJbmplY3RhYmxlKHtwcm92aWRlZEluOiAncm9vdCd9KVxuZXhwb3J0IGNsYXNzIEZhQ29uZmlnIHtcbiAgLyoqXG4gICAqIERlZmF1bHQgcHJlZml4IHRvIHVzZSwgd2hlbiBvbmUgaXMgbm90IHByb3ZpZGVkIHdpdGggdGhlIGljb24gbmFtZS5cbiAgICpcbiAgICogQGRlZmF1bHQgJ2ZhcydcbiAgICovXG4gIGRlZmF1bHRQcmVmaXg6IEljb25QcmVmaXggPSAnZmFzJztcblxuICAvKipcbiAgICogV2hldGhlciBjb21wb25lbnRzIHNob3VsZCBsb29rdXAgaWNvbiBkZWZpbml0aW9ucyBpbiB0aGUgZ2xvYmFsIGljb25cbiAgICogbGlicmFyeSAodGhlIG9uZSBhdmFpbGFibGUgZnJvbVxuICAgKiBgaW1wb3J0IHsgbGlicmFyeSB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mb250YXdlc29tZS1zdmctY29yZScpYC5cbiAgICpcbiAgICogU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9Gb3J0QXdlc29tZS9hbmd1bGFyLWZvbnRhd2Vzb21lL2Jsb2IvbWFzdGVyL2RvY3MvdXNhZ2UvaWNvbi1saWJyYXJ5Lm1kXG4gICAqIGZvciBkZXRhaWxlZCBkZXNjcmlwdGlvbiBvZiBsaWJyYXJ5IG1vZGVzLlxuICAgKlxuICAgKiAtICd1bnNldCcgLSBDb21wb25lbnRzIHNob3VsZCBsb29rdXAgaWNvbiBkZWZpbml0aW9ucyBpbiB0aGUgZ2xvYmFsIGxpYnJhcnlcbiAgICogYW5kIGVtaXQgd2FybmluZyBpZiB0aGV5IGZpbmQgYSBkZWZpbml0aW9uIHRoZXJlLiBUaGlzIG9wdGlvbiBpcyBhIGRlZmF1bHRcbiAgICogdG8gYXNzaXN0IGV4aXN0aW5nIGFwcGxpY2F0aW9ucyB3aXRoIGEgbWlncmF0aW9uLiBBcHBsaWNhdGlvbnMgYXJlIGV4cGVjdGVkXG4gICAqIHRvIHN3aXRjaCB0byB1c2luZyB7QGxpbmsgRmFJY29uTGlicmFyeX0uXG4gICAqIC0gdHJ1ZSAtIENvbXBvbmVudHMgc2hvdWxkIGxvb2t1cCBpY29uIGRlZmluaXRpb25zIGluIHRoZSBnbG9iYWwgbGlicmFyeS5cbiAgICogTm90ZSB0aGF0IGdsb2JhbCBpY29uIGxpYnJhcnkgaXMgZGVwcmVjYXRlZCBhbmQgc3VwcG9ydCBmb3IgaXQgd2lsbCBiZVxuICAgKiByZW1vdmVkLiBUaGlzIG9wdGlvbiBjYW4gYmUgdXNlZCB0byB0ZW1wb3JhcmlseSBzdXBwcmVzcyB3YXJuaW5ncy5cbiAgICogLSBmYWxzZSAtIENvbXBvbmVudHMgc2hvdWxkIG5vdCBsb29rdXAgaWNvbiBkZWZpbml0aW9ucyBpbiB0aGUgZ2xvYmFsXG4gICAqIGxpYnJhcnkuIExpYnJhcnkgd2lsbCB0aHJvdyBhbiBlcnJvciBpZiBtaXNzaW5nIGljb24gaXMgZm91bmQgaW4gdGhlIGdsb2JhbFxuICAgKiBsaWJyYXJ5LlxuICAgKlxuICAgKiBAZGVwcmVjYXRlZCBUaGlzIG9wdGlvbiBpcyBkZXByZWNhdGVkIHNpbmNlIDAuNS4wLiBJbiAwLjYuMCBkZWZhdWx0IHdpbGxcbiAgICogYmUgY2hhbmdlZCB0byBmYWxzZS4gSW4gMC43LjAgdGhlIG9wdGlvbiB3aWxsIGJlIHJlbW92ZWQgdG9nZXRoZXIgd2l0aCB0aGVcbiAgICogc3VwcG9ydCBmb3IgdGhlIGdsb2JhbCBpY29uIGxpYnJhcnkuXG4gICAqXG4gICAqIEBkZWZhdWx0ICd1bnNldCdcbiAgICovXG4gIGdsb2JhbExpYnJhcnk6IGJvb2xlYW4gfCAndW5zZXQnID0gJ3Vuc2V0Jztcbn1cbiJdfQ==