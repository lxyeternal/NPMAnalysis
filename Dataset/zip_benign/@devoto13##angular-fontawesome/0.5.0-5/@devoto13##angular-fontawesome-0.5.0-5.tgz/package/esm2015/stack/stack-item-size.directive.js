/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
import { Directive, Input } from '@angular/core';
export class FaStackItemSizeDirective {
    constructor() {
        /**
         * Specify whether icon inside {\@link FaStackComponent} should be rendered in
         * regular size (1x) or as a larger icon (2x).
         */
        this.stackItemSize = '1x';
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if ('size' in changes) {
            throw new Error('fa-icon is not allowed to customize size when used inside fa-stack. ' +
                'Set size on the enclosing fa-stack instead: <fa-stack size="4x">...</fa-stack>.');
        }
    }
}
FaStackItemSizeDirective.decorators = [
    { type: Directive, args: [{
                selector: 'fa-icon[stackItemSize],fa-duotone-icon[stackItemSize]',
            },] }
];
FaStackItemSizeDirective.propDecorators = {
    stackItemSize: [{ type: Input }],
    size: [{ type: Input }]
};
if (false) {
    /**
     * Specify whether icon inside {\@link FaStackComponent} should be rendered in
     * regular size (1x) or as a larger icon (2x).
     * @type {?}
     */
    FaStackItemSizeDirective.prototype.stackItemSize;
    /**
     * \@internal
     * @type {?}
     */
    FaStackItemSizeDirective.prototype.size;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhY2staXRlbS1zaXplLmRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL0Bmb3J0YXdlc29tZS9hbmd1bGFyLWZvbnRhd2Vzb21lLyIsInNvdXJjZXMiOlsic3RhY2svc3RhY2staXRlbS1zaXplLmRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7O0FBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQTRCLE1BQU0sZUFBZSxDQUFDO0FBTzNFLE1BQU0sT0FBTyx3QkFBd0I7SUFIckM7Ozs7O1FBUVcsa0JBQWEsR0FBZ0IsSUFBSSxDQUFDO0lBYzdDLENBQUM7Ozs7O0lBUEMsV0FBVyxDQUFDLE9BQXNCO1FBQ2hDLElBQUksTUFBTSxJQUFJLE9BQU8sRUFBRTtZQUNyQixNQUFNLElBQUksS0FBSyxDQUNiLHNFQUFzRTtnQkFDdEUsaUZBQWlGLENBQUMsQ0FBQztTQUN0RjtJQUNILENBQUM7OztZQXJCRixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLHVEQUF1RDthQUNsRTs7OzRCQU1FLEtBQUs7bUJBS0wsS0FBSzs7Ozs7Ozs7SUFMTixpREFBMkM7Ozs7O0lBSzNDLHdDQUF5QiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpcmVjdGl2ZSwgSW5wdXQsIE9uQ2hhbmdlcywgU2ltcGxlQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgU2l6ZVByb3AgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuaW1wb3J0IHsgRmFTdGFja0NvbXBvbmVudH0gZnJvbSAnLi9zdGFjay5jb21wb25lbnQnO1xuXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdmYS1pY29uW3N0YWNrSXRlbVNpemVdLGZhLWR1b3RvbmUtaWNvbltzdGFja0l0ZW1TaXplXScsXG59KVxuZXhwb3J0IGNsYXNzIEZhU3RhY2tJdGVtU2l6ZURpcmVjdGl2ZSBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XG4gIC8qKlxuICAgKiBTcGVjaWZ5IHdoZXRoZXIgaWNvbiBpbnNpZGUge0BsaW5rIEZhU3RhY2tDb21wb25lbnR9IHNob3VsZCBiZSByZW5kZXJlZCBpblxuICAgKiByZWd1bGFyIHNpemUgKDF4KSBvciBhcyBhIGxhcmdlciBpY29uICgyeCkuXG4gICAqL1xuICBASW5wdXQoKSBzdGFja0l0ZW1TaXplOiAnMXgnIHwgJzJ4JyA9ICcxeCc7XG5cbiAgLyoqXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgQElucHV0KCkgc2l6ZT86IFNpemVQcm9wO1xuXG4gIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcbiAgICBpZiAoJ3NpemUnIGluIGNoYW5nZXMpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgJ2ZhLWljb24gaXMgbm90IGFsbG93ZWQgdG8gY3VzdG9taXplIHNpemUgd2hlbiB1c2VkIGluc2lkZSBmYS1zdGFjay4gJyArXG4gICAgICAgICdTZXQgc2l6ZSBvbiB0aGUgZW5jbG9zaW5nIGZhLXN0YWNrIGluc3RlYWQ6IDxmYS1zdGFjayBzaXplPVwiNHhcIj4uLi48L2ZhLXN0YWNrPi4nKTtcbiAgICB9XG4gIH1cbn1cbiJdfQ==