export declare const faWarnIfIconSpecMissing: () => void;
