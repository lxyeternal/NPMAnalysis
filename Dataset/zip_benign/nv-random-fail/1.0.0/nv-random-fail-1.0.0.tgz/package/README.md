nv-random-fail
============
- nv-random-fail 
- creat random throw/return  resolve/reject
- for simple test using


install
=======
- npm install nv-random-fail

usage
=====

     const rnd_fail = require("nv-random-fail")

example
-------

### paramd-ctx

    {
        ratio:0.5,                       //succ-ratio
        avg_dly:1000,                    //for async, average delay
        rslt_creater:()=>undefined,      //rslt creater
        err_creater: ()=>new Error(),    //err  creater
    }

### sync 


        const x = require("nv-random-fail")

        > x.sync()
        undefined
        > x.sync()
        undefined
        > x.sync()
        undefined
        > x.sync()
        Uncaught Error
            at DFLT_ERR_CREATER (/opt/JS/NV6-/nvrnd/pkgs/nv-random-fail/index.js:3:31)
            at Object._sync [as sync] (/opt/JS/NV6-/nvrnd/pkgs/nv-random-fail/index.js:26:15)
        >


### async 

        > await x.async()
        undefined
        > await x.async()
        Uncaught Error
            at DFLT_ERR_CREATER (/opt/JS/NV6-/nvrnd/pkgs/nv-random-fail/index.js:3:31)
        > await x.async()
        undefined
        > await x.async()
        Uncaught Error
            at DFLT_ERR_CREATER (/opt/JS/NV6-/nvrnd/pkgs/nv-random-fail/index.js:3:31)
        >



APIS
====
- ParamD
- sync(ctx)
- async(ctx)


LICENSE
=======
- ISC 
