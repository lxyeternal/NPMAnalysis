
const DFLT_RSLT_CREATER = ()=>undefined;
const DFLT_ERR_CREATER  = ()=>new Error();


class ParamD {
    ratio =0.5;                       //succ-ratio
    avg_dly=2000;                    //for async, average delay
    rslt_creater=DFLT_RSLT_CREATER;      //rslt creater
    err_creater= DFLT_ERR_CREATER;    //err  creater
}

const _init = (ctx)=>{
    let nctx = new ParamD()
    Object.assign(nctx,ctx);
    return(nctx)
}

function _sync(ctx) {
    let nctx = _init(ctx);
    let {ratio,avg_dly,rslt_creater,err_creater} = nctx
    let cond =  (Math.random() <ratio)?true:false;
    if(cond) {
        return(rslt_creater())
    } else {
        throw(err_creater())
    }
}


async function _async(ctx) {
    let nctx = _init(ctx);
    let {ratio,avg_dly,rslt_creater,err_creater} = nctx 
    let p = new Promise((rs,rj)=>{
        setTimeout(
            () => {
                let cond =  (Math.random() <ratio)?true:false;
                if(cond) {
                    rs(rslt_creater())
                } else {
                    rj(err_creater())
                }
            },
            avg_dly*Math.random()
        )
   });
   return(p) 
}


module.exports = {
    ParamD,DFLT_RSLT_CREATER,DFLT_ERR_CREATER,
    sync:_sync,
    async:_async,
}
