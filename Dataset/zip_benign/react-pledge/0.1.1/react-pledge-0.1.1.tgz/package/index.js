'use strict';

exports.__esModule = true;

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _react = require('react');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var initialState = {
  pending: false,
  resolved: false,
  rejected: false,
  value: null,
  error: null
};

var Track = function (_Component) {
  _inherits(Track, _Component);

  function Track() {
    var _temp, _this, _ret;

    _classCallCheck(this, Track);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, _Component.call.apply(_Component, [this].concat(args))), _this), _initialiseProps.call(_this), _temp), _possibleConstructorReturn(_this, _ret);
  }

  Track.prototype.componentDidMount = function componentDidMount() {
    this.mounted = true;
  };

  Track.prototype.componentWillUnmount = function componentWillUnmount() {
    this.mounted = false;
  };

  Track.prototype.render = function render() {
    var _props = this.props,
        render = _props.render,
        children = _props.children,
        promise = _props.promise;

    var callback = render || children;
    if (typeof callback !== 'function') {
      throw Error('Props `render` or `children` must be a function.');
    }
    if (!promise instanceof Promise) {
      throw Error('The prop `promise` is required.');
    }

    return callback(this.triggerPromise, this.state);
  };

  return Track;
}(_react.Component);

var _initialiseProps = function _initialiseProps() {
  var _this2 = this;

  this.state = initialState;

  this.triggerPromise = function () {
    var promise = _this2.props.promise;

    var isMounted = _this2.mounted;

    isMounted && _this2.setState(_extends({}, initialState, {
      pending: true
    }));

    return promise.apply(undefined, arguments).then(function (value) {
      isMounted && _this2.setState(_extends({}, initialState, {
        value: value,
        resolved: true
      }));
    }).catch(function (error) {
      isMounted && _this2.setState(_extends({}, initialState, {
        error: error,
        rejected: true
      }));
    });
  };
};

exports.default = Track;