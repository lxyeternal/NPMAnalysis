const axios = require('axios');

class SpotifySearch {
  constructor(clientId, clientSecret) {
    this.clientId = clientId;
    this.clientSecret = clientSecret;
    this.token = null;
    this.language = 'en'; // Varsayılan dil
    this.translations = {
      en: {
        trackName: 'Track Name',
        album: 'Album',
        artists: 'Artists',
        popularity: 'Popularity',
        duration: 'Duration'
      },
      es: {
        trackName: 'Nombre de la Canción',
        album: 'Álbum',
        artists: 'Artistas',
        popularity: 'Popularidad',
        duration: 'Duración'
      },
      tr: {
        trackName: 'Şarkı Adı',
        album: 'Albüm',
        artists: 'Sanatçılar',
        popularity: 'Popülerlik',
        duration: 'Süre'
      }
    };
  }

  setLanguage(language) {
    if (this.translations[language]) {
      this.language = language;
    } else {
      throw new Error('Unsupported language');
    }
  }

  async authenticate() {
    const response = await axios.post('https://accounts.spotify.com/api/token', 
      new URLSearchParams({
        'grant_type': 'client_credentials'
      }), {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Authorization': 'Basic ' + Buffer.from(this.clientId + ':' + this.clientSecret).toString('base64')
        }
      }
    );
    this.token = response.data.access_token;
  }

  formatDuration(ms) {
    const minutes = Math.floor(ms / 60000);
    const seconds = ((ms % 60000) / 1000).toFixed(0);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  }

  async searchTrack(query, limit = 3) {
    if (!this.token) {
      await this.authenticate();
    }
    const response = await axios.get('https://api.spotify.com/v1/search', {
      headers: {
        'Authorization': 'Bearer ' + this.token
      },
      params: {
        q: query,
        type: 'track',
        limit: 50  // Daha fazla sonuç alıp popülariteye göre filtreleyeceğiz
      }
    });

    const tracks = response.data.tracks.items;
    tracks.sort((a, b) => b.popularity - a.popularity); // Popülariteye göre sıralama

    return Promise.all(tracks.slice(0, limit).map(async (track) => {
      const duration = this.formatDuration(track.duration_ms);
      const prodiaUrl = `https://api.modloff.com/api/prodia/generate?trackName=${encodeURIComponent(track.name)}&artistName=${encodeURIComponent(track.artists.map(artist => artist.name).join(', '))}&imageUrl=${encodeURIComponent(track.album.images[0]?.url)}&startTime=0:30&endTime=${duration}`;

      return {
        name: track.name,
        album: track.album.name,
        artists: track.artists.map(artist => artist.name),
        popularity: track.popularity,
        imageUrl: track.album.images[0]?.url, // Albüm kapağı fotoğrafı
        duration: duration,
        prodiaUrl: prodiaUrl,
        translations: {
          [this.translations[this.language].trackName]: track.name,
          [this.translations[this.language].album]: track.album.name,
          [this.translations[this.language].artists]: track.artists.map(artist => artist.name).join(', '),
          [this.translations[this.language].popularity]: track.popularity,
          [this.translations[this.language].duration]: duration
        }
      };
    }));
  }

  async searchArtist(query, limit = 3) {
    if (!this.token) {
      await this.authenticate();
    }
    const response = await axios.get('https://api.spotify.com/v1/search', {
      headers: {
        'Authorization': 'Bearer ' + this.token
      },
      params: {
        q: query,
        type: 'artist',
        limit: 50  // Daha fazla sonuç alıp popülariteye göre filtreleyeceğiz
      }
    });

    const artists = response.data.artists.items;
    artists.sort((a, b) => b.popularity - a.popularity); // Popülariteye göre sıralama

    return artists.slice(0, limit).map(artist => ({
      name: artist.name,
      genres: artist.genres,
      popularity: artist.popularity,
      imageUrl: artist.images[0]?.url, // Sanatçı fotoğrafı
      translations: {
        [this.translations[this.language].trackName]: artist.name,
        [this.translations[this.language].popularity]: artist.popularity
      }
    }));
  }
}

module.exports = SpotifySearch;
