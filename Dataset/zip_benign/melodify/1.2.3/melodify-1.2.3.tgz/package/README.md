---

# Melodify

Melodify is an npm module designed to simplify searching for songs and artists on Spotify. It allows developers to easily integrate Spotify search functionality into their projects without requiring user login credentials.

## Features

- **Search for Songs**: Retrieve song details, including album names, artists, popularity, duration, and album cover images.
- **Search for Artists**: Get information about artists, including their genres, popularity, and profile images.
- **Top Results**: Customize the number of top results based on popularity to suit your needs.
- **Multilingual Support**: Set the language for returned results.
- **Prodia URL**: Generate a URL for additional information about tracks using the Prodia API.

## Installation

To install Melodify, use npm:

```sh
npm install melodify
```

## Usage

First, you need to obtain your Spotify client ID and client secret from the [Spotify Developer Dashboard](https://developer.spotify.com/dashboard/applications).

### Example

Here's an example of how to use Melodify in your project:

```javascript
const SpotifySearch = require('melodify');

const clientId = 'YOUR_SPOTIFY_CLIENT_ID';
const clientSecret = 'YOUR_SPOTIFY_CLIENT_SECRET';

const spotifySearch = new SpotifySearch(clientId, clientSecret);

(async () => {
  try {
    spotifySearch.setLanguage('tr'); // Set language to Turkish

    // Search for tracks
    const tracks = await spotifySearch.searchTrack('Imagine', 5);
    console.log('Tracks:', tracks);

    // Search for artists
    const artists = await spotifySearch.searchArtist('John Lennon', 5);
    console.log('Artists:', artists);
  } catch (error) {
    console.error('Error:', error);
  }
})();
```

### API

#### `searchTrack(query, limit = 3)`

Searches for tracks based on the query. Returns an array of tracks with the following properties:

- `name`: The name of the track.
- `album`: The name of the album.
- `artists`: An array of artist names.
- `popularity`: The popularity of the track.
- `duration`: The duration of the track in "minutes:seconds" format.
- `imageUrl`: The URL of the album cover image.
- `prodiaUrl`: The generated URL for additional information.
- `translations`: An object containing the translated keys.

#### `searchArtist(query, limit = 3)`

Searches for artists based on the query. Returns an array of artists with the following properties:

- `name`: The name of the artist.
- `genres`: An array of genres associated with the artist.
- `popularity`: The popularity of the artist.
- `imageUrl`: The URL of the artist's profile image.
- `translations`: An object containing the translated keys.

#### `setLanguage(language)`

Sets the language for the translations. Supported languages are:

- `en` (English)
- `es` (Spanish)
- `tr` (Türkçe)

## Testing

To run tests, use the following command:

```sh
npm test
```
