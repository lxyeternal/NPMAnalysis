/**
 * The Lifecycle callbacks invoked on scripts that can be run by WorkEngine Cloud Scripting
 */
import {BaseLifecycle, DoneCallback} from "./Base";
import {Break, Shift} from "../api/addons/Timesheets";

export interface InitResult {
    timeout: number;
    skipTriggers: boolean;
}

export interface CloudScriptLifecycle extends BaseLifecycle {
    /**
     * Respond when WorkEngine initialises your Script.
     *
     * @cloud
     *
     * @param done Callback function to signal your lifecycle hook is complete
     *
     * @remarks
     *
     * Try and avoid too much work in your init, as other WorkEngine core components will wait until scripting is initialised.
     * Note that the order that scripts are initialised is not consistent. If you need to utilise another script when initialising, use `postInit`
     *
     * In cloud scripting we can return an object to the done function
     */
    init(done: (initResult: InitResult) => void): void;

    /**
     * Respond when WorkEngine runs your Script through Cloud Scripting.
     *
     * @cloud
     *
     * @param done Callback function to signal your lifecycle hook is complete
     * @param data
     *
     * @remarks
     *
     * This lifecycle can be run on multiple types of objects, such as Transitions, Objects and so on. Each type of Cloud Script has an associated data message explained below
     */
    run(done: DoneCallback, data: TriggerData | TransitionData | TaskData | SigningRequestData | TimesheetData): void;
}

/**
 * An event representing the signing request that caused the cloud script to run
 *
 * @cloud
 */
interface SigningRequestData {
    /**
     * The type of the update
     */
    type: "esignature",

    /**
     * Signing Flow
     */
    signing_flow: any;

    /**
     * Signing Request
     */
    signing_request: any;
}

/**
 * An event representing the task that caused the cloud script to run
 *
 * @cloud
 */
interface TaskData {
    /**
     * The type of the update
     */
    type: "task",

    /**
     * ID of the task
     */
    task_id: number;

    /**
     * The payload of the task, provided when the task was created
     */
    payload: any;
}

/**
 * An event representing the trigger and object that caused the cloud script to run
 *
 * @cloud
 */
interface TriggerData {
    /**
     * The type of the update
     */
    type: "trigger";
    /**
     * The change that triggered this, one of "create", "update" or "destroy"
     */
    change: string;
    /**
     * The object identifier type
     */
    object_identifier: string;
    /**
     * The object
     */
    object: any;
}

/**
 * An event representing the transition and object that caused the cloud script to run
 *
 * @cloud
 */
interface TransitionData {
    /**
     * The type of the update
     */
    type: "transition";
    /**
     * Transition ID
     */
    transition_id: number;
    /**
     * Workflow ID that this transition belongs to
     */
    workflow_id: number;
    /**
     * The object identifier type
     */
    object_identifier: string;
    /**
     * The object
     */
    object: any;
}

/**
 * An event representing a shift/break starting or ending
 *
 * @cloud
 */
interface TimesheetData {

    type: "timesheet";

    /**
     * The currently active shift or the current shift being started/ended
     */
    shift: Shift;

    /**
     * The break being started/ended
     */
    break: Break;


}
