import {CloudScriptLifecycle} from "./CloudScript";
import {DoneCallback} from "./Base";

/**
 * The Lifecycle callbacks invoked on scripts that are attached to a Timesheet in WorkEngine
 */
export interface TimesheetLifecycle extends CloudScriptLifecycle {

    /**
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * Note you can stop the shift being started by calling done with false.
     *
     * @param done
     */
    beforeShiftStart(done: DoneCallback): void;

    /**
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * Note you can stop the shift being ended by calling done with false.
     *
     * @param done
     */
    beforeShiftEnd(done: DoneCallback): void;

    /**
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * Note you can stop the break being started by calling done with false.
     *
     * @param done
     */
    beforeBreakStart(done: DoneCallback): void;

    /**
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * Note you can stop the break being ended by calling done with false.
     *
     * @param done
     */
    beforeBreakEnd(done: DoneCallback): void;

}
