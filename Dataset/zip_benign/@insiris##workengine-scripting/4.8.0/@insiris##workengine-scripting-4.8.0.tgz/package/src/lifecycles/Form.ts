/**
 * The Lifecycle callbacks invoked on scripts that are attached to a Form in WorkEngine
 */
import {BaseLifecycle, DoneCallback} from "./Base";
import {QuestionApi} from "../api/core/questions/Questions";


export interface FormLifecycle extends BaseLifecycle {

    /**
     * Respond before a Form is saved
     *
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * Note that you can prevent the form from being saved by calling the callback with a parameter of false.  If multiple Scripts implement this callback, if any of them invoke the callback with false, the form save will be halted.
     *
     * @param done Callback function to signal your lifecycle hook is complete
     */
    beforeSave(done: BeforeEventDoneCallback): void;

    /**
     * Respond after a Form has been successfully saved
     *
     * @web
     * @android
     * @ios
     *
     * @param done Callback function to signal your lifecycle hook is complete
     */
    afterSave(done: DoneCallback): void;

    /**
     * Respond before the current active page is changed
     *
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * Note that you can prevent the page from being changed by calling the callback with a parameter of false.  If multiple Scripts implement this callback, if any of them invoke the callback with false, the page change will be halted.
     *
     * @param currentPageIdentifier The identifier of the current page
     * @param currentPagePosition The position (zero-indexed) of the current page
     * @param newPageIdentifier The identifier of the page being navigated to
     * @param newPagePosition The position (zero-indexed) of the page being navigated to
     * @param done Callback function to signal your lifecycle hook is complete
     */
    beforePageChange(done: BeforeEventDoneCallback, currentPageIdentifier: string, currentPagePosition: number, newPageIdentifier: string, newPagePosition: number): void;

    /**
     * Respond when a user taps a button on a Form
     *
     * @web
     * @android
     * @ios
     *
     * @param controlIdentifier The identifier of the button that was pressed
     * @param done Callback function to signal your lifecycle hook is complete
     */
    onPress(done: DoneCallback, controlIdentifier: string): void;

    /**
     * Respond when a popup form is being closed
     *
     * @web
     *
     * @param done
     */
    onClose(done: DoneCallback): void;

    /**
     * Respond when a control's value changes
     *
     * @web
     * @android
     * @ios
     *
     * @param controlIdentifier The identifier of the control bound to the value that has changed
     * @param value The new value
     * @param done Callback function to signal your lifecycle hook is complete
     */
    onValueChange(done: DoneCallback, controlIdentifier: string, value: any): void;

    /**
     * Respond when a control will gain focus
     *
     * @web
     * @android
     * @ios
     *
     * @param controlIdentifier The identifier of the control that will gain focus
     * @param done Callback function to signal your lifecycle hook is complete
     */
    beforeFocus(done: DoneCallback, controlIdentifier: string): void;

    /**
     * Respond when a control loses focus
     *
     * @web
     * @android
     * @ios
     *
     * @param controlIdentifier The identifier of the control that has lost focus
     * @param done Callback function to signal your lifecycle hook is complete
     */
    lostFocus(done: DoneCallback, controlIdentifier: string): void;

    /**
     * Respond when an object's relationship changes from another form
     *
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * Note that this is not triggered if the relationship is manually changed (i.e. by scripting).  It will be triggered if the user changes a relationship
     * via a relationship control on a form - either by adding a new one, or deleting an existing one.
     *
     * @param relationshipFromIdentifier The 'from' identifier of the relationship that has changed
     * @param done Callback function to signal your lifecycle hook is complete
     */
    onRelationshipChange(done: DoneCallback, relationshipFromIdentifier: string): void;

    /**
     * Only on Relationship Control and Question Control
     *
     * Allows questions to be modified before being asked
     *
     * @web
     * @android
     * @ios
     *
     * @deprecated Use Visualisation onAsk instead
     *
     * @param done - return modified question as done parameter
     * @param question
     * @param questionIdentifier
     */
    onQuestionAsk(done: DoneCallback, question: QuestionApi, questionIdentifier: string): void;


    /**
     * Only on Relationship Control
     *
     * Fires when the 'create new', 'pick existing' and 'delete' buttons are pressed.
     *
     * @web
     * @android
     * @ios
     *
     * @param done - return modified question as done parameter
     * @param identifier - control identifier
     * @param type - the type of relationship button that was pressed('create', 'existing', 'delete')
     */
    onRelationshipPress(done: DoneCallback, identifier: String, type: ["create", "existing", "delete"]): void;
}

/**
 * Callback invoked for 'before' lifecycle callbacks that support halting
 *
 * @param halt Halt the action by invoking this function with false
 */
type BeforeEventDoneCallback = (halt: boolean) => void;
