/**
 * @hidden
 */
export interface BaseLifecycle {
    /**
     * Respond when WorkEngine initialises your Script.
     *
     * @web
     * @android
     * @ios
     *
     * @param done Callback function to signal your lifecycle hook is complete
     *
     * @remarks
     *
     * Try and avoid too much work in your init, as other WorkEngine core components will wait until scripting is initialised.
     * Note that the order that scripts are initialised is not consistent. If you need to utilise another script when initialising, use `postInit`
     */
    init(done: DoneCallback): void;

    /**
     * Respond when WorkEngine has initialised all Scripts
     *
     * @web
     * @cloud
     * @android
     * @ios
     *
     * @param done Callback function to signal your lifecycle hook is complete
     *
     * @remarks
     *
     * This lifecycle hook allows you to know all other scripts have initialised, and you can reference them if required
     */
    postInit(done: DoneCallback): void;

    /**
     * Respond when WorkEngine is destroying your context
     *
     * @web
     * @cloud
     * @android
     * @ios
     *
     * @param done Callback function to signal your lifecycle hook is complete
     *
     * @remarks
     *
     * Use this hook to release any resources held by your script and perform any cleanup
     */
    destroy(done: DoneCallback): void;
}


/**
 * Callback function to signal a lifecycle hook is complete, returning no parameters
 *
 */
export type DoneCallback = () => void;
