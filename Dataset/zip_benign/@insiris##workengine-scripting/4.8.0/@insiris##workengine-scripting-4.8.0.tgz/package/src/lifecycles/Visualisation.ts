import {BaseLifecycle, DoneCallback} from "./Base";
import {Answer, AnswerApi, AnswerColumn, Question, QuestionApi} from "../api/core/questions/Questions";

export type OnAnswerCallback = (answer: AnswerApi) => void;

export type OnCellRenderCallback = (result: { value?: any, backgroundColour?: string, textColour?: string }) => void;
export type OnRowRenderCallback = (result: { backgroundColour?: string }) => void;

export interface VisualisationLifecycle extends BaseLifecycle {

    /**
     * Only on Relationship Control and Question Control
     *
     * Allows questions to be modified before being asked
     *
     * @web
     * @android
     * @ios
     *
     * @param done - return modified question as done parameter
     * @param question
     */
    onAsk(done: DoneCallback, question: Question): void;

    /**
     * @web
     * @android
     * @ios
     *
     * @param done
     * @param answer
     * @param page
     * @param perPage
     */
    onAnswer(done: OnAnswerCallback, answer: AnswerApi, page: number, perPage: number): void;

    /**
     * Allows cells on a Table Visualisation to be customised
     *
     * @web
     *
     * @param done
     * @param value
     * @param answerColumn
     * @param row
     * @param answerColumns
     */
    onCellRender(done: OnCellRenderCallback, value: any, answerColumn: AnswerColumn, row: any[], answerColumns: AnswerColumn[]): void;

    /**
     * Allows rows on a Table Visualisation to be customised
     *
     * @web
     *
     * @param done
     * @param row
     * @param answer
     */
    onRowRender(done: OnRowRenderCallback, row: any[], answer: Answer): void;

    /**
     * Triggered when a linked scripting column value is clicked
     *
     * @web
     * @android
     * @ios
     *
     * @param done
     * @param value
     * @param answerColumn
     * @param row
     * @param answerColumns
     */
    onLinkablePress(done: DoneCallback, value: any, answerColumn: AnswerColumn, row: any[], answerColumns: AnswerColumn[]): void;
}
