import {DoneCallback} from "./Base";
import {CloudScriptLifecycle} from "./CloudScript";

/**
 * The Lifecycle callbacks invoked on scripts that are attached to a Transition in WorkEngine
 */
export interface TransitionLifecycle extends CloudScriptLifecycle {

    /**
     * Runs before a transition, can return false to abort the transition action
     *
     * @web
     * @android
     * @ios
     *
     * @param done
     * @param objectUuid the object uuid of the object being transition
     * @param objectIdentifier the object identifier of the object being transition
     */
    beforeTransition(done: BeforeTransitionCallback, objectUuid: string, objectIdentifier: string): void;

    /**
     * Respond when a transition is being invoked, and the object's status is being changed
     *
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * *Important: this lifecycle hook is called after the server-side call to move the object to the new status is made*
     *
     * @param done Callback function to signal your lifecycle hook is complete
     * @param objectUuid the object uuid of the object being transition
     * @param objectIdentifier the object identifier of the object being transition
     */
    afterTransition(done: DoneCallback, objectUuid: string, objectIdentifier: string): void;

    /**
     * Respond when a transition is being invoked, and the object's status is being changed
     *
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * *Important: this lifecycle hook is called after the server-side call to move the object to the new status is made*
     *
     * @param done Callback function to signal your lifecycle hook is complete
     * @deprecated
     */
    onTransition(done: DoneCallback): void;

    /**
     *
     * Respond to let WorkEngine know if the current object can transition to the specified status
     *
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * Use this lifecycle hook to let WorkEngine know if an object is capable if being transitioned to this status.  If your callback function returns `false` WorkEngine will disable the transition and will not let the user transition
     *
     * @param done Callback function that signals to WorkEngine whether this transition can be run
     */
    canTransition(done: CanTransitionCallback): void;

}

/**
 * Callback invoked for 'before' lifecycle callbacks that support halting
 *
 * @param result Whether the transition can be activated
 */
type CanTransitionCallback = (result: boolean) => void;

type BeforeTransitionCallback = (result: boolean) => void;
