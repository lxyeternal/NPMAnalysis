import {Request, Response} from 'express';
import {glob} from "glob";

const express = require('express');
const app = express();
const port = 4000;
const fs = require('fs');
const cors = require('cors');

const scriptsPath = process.argv[2];

app.use(cors());

app.get('/scripts/:organisation/index.json', (req: Request, res: Response) => {
    const organisation = req.params["organisation"];
    if (scriptsPath.endsWith(organisation)) {
        handleIndexRequest(req, res, scriptsPath)
    } else {
        handleIndexRequest(req, res, `${scriptsPath}/${organisation}`)
    }
});

app.get('/scripts/index.json', (req: Request, res: Response) => {
    handleIndexRequest(req, res, scriptsPath)
});

function handleIndexRequest(req: Request, res: Response, scriptsPath: string) {
    console.log("Request for index.json");

    let scriptFiles = glob.sync(`${scriptsPath}/src/**/*.js`)
        .map(path => path.replace(`${scriptsPath}/`, ''))
        .join("\n");

    if (scriptFiles.length === 0) console.warn("No script files found!");

    res.send(scriptFiles);
}

app.get('/scripts/:organisation/*', (req: Request, res: Response) => {
    const organisation = req.params["organisation"];
    if (scriptsPath.endsWith(organisation)) {
        handleScriptFileRequest(req, res, scriptsPath);
    } else {
        handleScriptFileRequest(req, res, `${scriptsPath}/${organisation}`);
    }
})

app.get('/scripts/*', (req: Request, res: Response) => {
    handleScriptFileRequest(req, res, scriptsPath);
})

function handleScriptFileRequest(req: Request, res: Response, scriptsPath: string) {
    let script = `${scriptsPath}/${req.params[0]}`;
    console.log("Request for local script " + script);
    if (fs.existsSync(script)) {
        const data = fs.readFileSync(script, 'utf8')

        res.send(data);
    } else {
        const message = `Scripting file '${script}' not found!'`;
        console.error(message);

        res.status(404);
        res.send(message);
    }
}

app.listen(port, () => {
    console.log(`Scripts Server listening at http://localhost:${port}`);
    if (!scriptsPath) console.warn("No script path provided!");
});
