import {Api, Async, Logger} from "..";
import {HashMap} from "../api/api";

export function throwOverride(name: string) {
    throw "Override api function " + name + " when testing!";
}

declare global {
    interface Window {
        api: Api;
        logger: Logger;
        async: Async;
        apis: HashMap<string, any>;
        scripts: HashMap<string, any>;
        environment: string;
        doneCalled: boolean;
    }
}

export function setupWorkEngineScripting(environment = "test", apis: HashMap<string, any> = {}, scripts: HashMap<string, any> = {}) {
    window.api = new Api();
    window.logger = new Logger();
    window.async = new Async();
    window.apis = apis;
    window.scripts = scripts;
    window.environment = environment;
    window.doneCalled = false;
}

export function noop() {
}

export function done() {
    window.doneCalled = true;
}
