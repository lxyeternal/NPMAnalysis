/**
 * Scan NFC Tags in Mobile App
 */
export class Nfc {

    /**
     * Scan an NFC Tag
     *
     * @android
     * @ios
     *
     *
     * @param sendGridOptions Sendgrid authentication options
     * @param message Email message to send
     * @param callback Callback to invoke on complete/error
     */
    readTag(callback: ReadTagCallback) {
    }

}

/**
 * Callback function invoked by WorkEngine when the tag is read.
 *
 * @param response NFC Tag Payload
 */
type ReadTagCallback = (error: Error | any | null, response: string) => void;
