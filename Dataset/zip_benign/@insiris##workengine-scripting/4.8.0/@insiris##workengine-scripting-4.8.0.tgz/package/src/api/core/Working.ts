/**
 * Shows Working message/notification
 */
export class Working {

    /**
     * Shows a global working message with a spinner
     *
     * @web
     * @android
     * @ios
     *
     * @param message Message to show
     * @param type Whether this is an info or error message ("info" or "error")
     * @param dismissible Whether the user can dismiss this
     */
    show(message: string, type: "info" | "error", dismissible: boolean) {
    }

    /**
     * Dismiss the global working message
     *
     * @web
     * @android
     * @ios
     *
     */
    dismiss() {
    }
}
