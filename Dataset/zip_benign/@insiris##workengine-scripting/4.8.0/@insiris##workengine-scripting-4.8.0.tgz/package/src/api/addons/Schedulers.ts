import {AddOnsToolbar} from "./AddOns";
import {DayPilot} from "daypilot-pro-angular";

/**
 * Manage the currently active scheduler
 *
 */
export class Schedulers {

    /**
     * Manage the currently active Scheduler
     *
     * @web
     *
     */
    scheduler: Scheduler = new Scheduler();
}

/**
 * Manage the currently active Scheduler.
 *
 * @remarks
 *
 * Many of these functions are wrappers around the DayPilot library used for rendering the scheduler
 */
export class Scheduler {

    /**
     * Return the top daypilot scheduler control - see https://api.daypilot.org/daypilot-scheduler-class/
     *
     * @web
     *
     */
    // @ts-ignore
    topDaypilotScheduler:  DayPilot.Scheduler = null;

    /**
     * Return the bottom daypilot scheduler control - see https://api.daypilot.org/daypilot-scheduler-class/
     *
     * @web
     *
     */
    // @ts-ignore
    bottomDaypilotScheduler: DayPilot.Scheduler = {};


    /**
     * Manage the top Toolbar used by the Scheduler
     *
     * @web
     *
     */
    topToolbar: AddOnsToolbar = new AddOnsToolbar();

    /**
     * Manage the bottom Toolbar used by the Scheduler
     *
     * @web
     *
     */
    bottomToolbar: AddOnsToolbar = new AddOnsToolbar();

    /**
     * Set the scheduler sidebar's top HTML
     *
     * @web
     *
     * @param html HTML to show at the top of the sidebar
     */
    public setSidebarTopHtml(html: string) {
    }

    /**
     * Set the scheduler sidebar's groups
     *
     * @web
     *
     * @param groups Groups for the sidebar
     */
    public setSidebarGroups(groups: SchedulerSidebarGroup[]) {
    }

    /**
     * Sets the 'Top' Scheduler's DayPilot Config
     *
     * @web
     *
     * @param config A DayPilot Config object. See https://api.daypilot.org/daypilot-scheduler-properties/
     */
    public setTopDayPilotConfig(config: any) {
    }

    /**
     * Sets the 'Bottom' Scheduler's DayPilot Config
     *
     * @web
     *
     * @param config A DayPilot Config object. See https://api.daypilot.org/daypilot-scheduler-properties/
     */
    public setBottomDayPilotConfig(config: any) {
    }

    /**
     * Set the events for the 'Top' Scheduler
     *
     * @web
     *
     * @param events A list of events. The format for an event is provided at https://api.daypilot.org/daypilot-event-data/
     */
    public setTopEvents(events: any[]) {
    }

    /**
     * Set the events for the 'Bottom' Scheduler
     *
     * @web
     *
     * @param events A list of events. The format for an event is provided at https://api.daypilot.org/daypilot-event-data/
     */
    public setBottomEvents(events: any[]) {
    }

    /**
     * Set the resources for the 'Allocated' Scheduler
     *
     * @web
     *
     * @param resources A list of resources.  The format for a resource is provided at https://api.daypilot.org/daypilot-scheduler-resources/
     */
    public setTopResources(resources: any[]) {
    }

    /**
     * Set the resources for the 'Bottom' Scheduler
     *
     * @web
     *
     * @param resources A list of resources.  The format for a resource is provided at https://api.daypilot.org/daypilot-scheduler-resources/
     */
    public setBottomResources(resources: any[]) {
    }

    /**
     * Sets the resource times used for rendering background cells for resources
     *
     * @web
     *
     * @param resourceTimes
     */
    public setResourceTimes(resourceTimes: SchedulerResourceTime[]) {
    }

    /**
     * Set the date/time
     *
     * @web
     *
     * @param dateTime Date/Time for the schedulers to start at
     */
    public setDateTime(dateTime: string) {
    }

    /**
     * Set the scale and headers for the 'Top' Scheduler
     *
     * @web
     *
     * @remarks
     *
     * See https://doc.daypilot.org/scheduler/scale/ for more info
     *
     * @param scale DayPilot Scale
     * @param timeHeaders DayPilot TimeHeaders
     * @param numberOfDays Number of days to show
     */
    public setTopSchedulerScale(scale: string, timeHeaders: { groupBy: string, format: string }[], numberOfDays: number | null = null) {
    }

    /**
     * Set the scale and headers for the 'Bottom' Scheduler
     *
     * @web
     *
     * @remarks
     *
     * See https://doc.daypilot.org/scheduler/scale/ for more info
     *
     * @param scale DayPilot Scale
     * @param timeHeaders DayPilot TimeHeaders
     * @param numberOfDays Number of days to show
     */
    public setBottomSchedulerScale(scale: string, timeHeaders: { groupBy: string, format: string }[], numberOfDays: number | null = null) {
    }

    /**
     * Sets up the now date line auto refresh behaviour
     *
     * @param shouldRefresh should refresh automatically
     * @param color Color of the line in hexadecimal e.g. #EFEFEF
     * @param layer Whether to show 'AboveEvents' or not
     */
    public setNowDateLineAutoRefresh(shouldRefresh: Boolean, color: String = 'red', layer: String = 'AboveEvents') {
    }

    /**
     * Sets the line that displays the current time on the scheduler
     *
     * @web
     *
     * @remarks
     *
     * This line will automatically refresh as time ticks
     *
     * @param nowLine Not used
     * @param color Color of the line in hexadecimal e.g. #EFEFEF
     */
    public setNowLine(nowLine: any, color: any) {
    }

    /**
     * Sets the dimensions of the unallocated/bottom schedulers
     *
     * @web
     *
     * @param sidePercentage Percentage for side unallocated scheduler
     * @param bottomPercentage Percentage for bottom unallocated scheduler
     */
    public setBottomDimensions(sidePercentage: number, bottomPercentage: number | null = null) {
    }

    /**
     * Iterate over DayPilot's Top Events using DayPilot's iterator
     *
     * @param iterateFunction Function to invoke for each event
     */
    public iterateTopSchedulerEvents(iterateFunction: (it: DayPilotEvent) => void) {
    }

    /**
     * Iterate over DayPilot's Bottom Events using DayPilot's iterator
     *
     * @web
     *
     * @param iterateFunction Function to invoke for each event
     */
    public iterateBottomSchedulerEvents(iterateFunction: (it: DayPilotEvent) => void) {
    }

    /**
     * Scroll to a date on the scheduler
     *
     * @web
     *
     * @param date Date to scroll to (ISO8601 Format)
     */
    public scrollTo(date: string) {
    }

    /**
     * Update the 'Top' Scheduler's DayPilot Config
     *
     * @web
     *
     * @remarks
     *
     * See [[setAllocatedDayPilotConfig]]
     * Note that this supports partial config updates
     *
     * @param config A DayPilot Config object. See https://api.daypilot.org/daypilot-scheduler-properties/
     */
    public updateTopScheduler(config: any = {}) {
    }

    /**
     * Update the 'Bottom' Scheduler's DayPilot Config
     *
     * @web
     *
     * @remarks
     *
     * See [[setBottomDayPilotConfig]]
     * Note that this supports partial config updates
     *
     * @param config A DayPilot Config object. See https://api.daypilot.org/daypilot-scheduler-properties/
     */
    public updateBottomScheduler(config: any = {}) {
    }

    /**
     * Update both the 'Top' and 'Bottom' Scheduler with a DayPilot Config
     *
     * @web
     *
     * @remarks
     *
     * Note that this supports partial config updates
     *
     * @param config  A DayPilot Config object. See https://api.daypilot.org/daypilot-scheduler-properties/
     */
    public update(config = {}) {
    }

    /**
     * Set the context menu items provided when right clicking on a resource on the 'Top' Scheduler
     *
     * @web
     *
     * @param items A list of DayPilot Context Menu items. See https://api.daypilot.org/daypilot-menu-class/
     */
    public setTopSchedulerResourceContextMenu(items: any = {}) {
    }

    /**
     * Set the context menu items provided when right clicking on a resource on the 'Bottom' Scheduler
     *
     * @web
     *
     * @param items A list of DayPilot Context Menu items. See https://api.daypilot.org/daypilot-menu-class/
     */
    public setBottomSchedulerResourceContextMenu(items: any = {}) {
    }

    /**
     * Sets the line that displays a time on the scheduler
     *
     * @web
     *
     * @remarks
     *
     * This line will **not** automatically refresh as time ticks
     *
     * @param date Date for the line (ISO8601 format)
     * @param color Color of the line in hexadecimal e.g. #EFEFEF
     */
    public setNowDateLine(date: Date, color: string = 'red') {
    }

    /**
     * Scroll the scheduler to the event with the provided ID
     *
     * @web
     *
     * @remarks
     *
     * This functions scrolls both the 'Allocated' and 'Bottom' schedulers to the resource and event
     *
     * @param id ID of the event
     */
    public moveToEvent(id: string) {
    }

    /**
     * Scroll the scheduler just to the resource with the provided ID
     *
     * @web
     *
     * @param id ID of the resource
     */
    public moveToResource(id: number) {
    }

    /**
     * Receive updates when certain scheduler events occur
     *
     * @web
     *
     * @param eventType Type of the event registering for
     * @param callback Callback function that will be invoked when the event occurs
     */
    public onCallback(eventType: 'eventMove' | 'eventDropped' | 'eventMenuItemClicked', callback: (event: SchedulerEvent) => void) {
    }

    /**
     * Update an event
     *
     * @web
     *
     * @param eventId ID of the event
     * @param event Event properties. See https://api.daypilot.org/daypilot-event-data/
     */
    public updateEvent(eventId: string, event: any) {
    }

    /**
     * Set whether the bottom scheduler is visible
     *
     * @web
     *
     * @param visible Whether the scheduler is visible
     */
    public setBottomSchedulerVisible(visible: boolean) {
    }

    /**
     * Set whether the sidebar is visible
     *
     * @web
     *
     * @param visible Whether the sidebar is visible
     */
    public setSidebarVisible(visible: boolean) {
    }

    /**
     * Set the bubble popup shown
     *
     * @param bubblePopup Bubble popup
     */
    public setBubblePopup(bubblePopup: any) {
    }

    /**
     * Sets the bubble popup on click args
     *
     * @param args
     */
    public setBubblePopupFromOnEventClickArgs(args: any) {
    }

    /**
     * Converts a Javascript Date object into a DayPilot Date object
     * This is *really* useful for dealing with timezone calculations as you can use this function
     * to convert a local datetime into a daypilot one, striping off the timezone info
     *
     * @param date Date to convert
     * @param isLocal Whether timezone info should be considered - see https://api.daypilot.org/daypilot-date-class/
     */
    public asDayPilotDate(date: Date, isLocal = true) {
    }

}

/**
 * Used to represent a Resource Time for drawing on a Scheduler
 *
 * @web
 *
 * @remarks
 *
 * This controls the background cells for a resource time and can be used to colour code cells, for example, for unavailability
 */
interface SchedulerResourceTime {
    /**
     * ID of the resource
     */
    resourceId: string;

    /**
     * Start time (ISO8601 format)
     */
    start: string;

    /**
     * End time (ISO8601 format)
     */
    end: string;

    /**
     * CSS Styling to apply
     */
    css?: string;

    /**
     * HTML to apply
     */
    html?: string;
}

/**
 * Used to represent a Scheduler Sidebar Group
 *
 * @web
 *
 */
interface SchedulerSidebarGroup {
    /**
     * Whether the group is visible
     */
    visible?: boolean;

    /**
     * The html for item
     */
    html: string;

    /**
     * The identifier for the group
     */
    identifier: string;

    /**
     * The items shown in the sidebar
     */
    items: SchedulerSidebarItem[];
}

/**
 * Used to represent an item in a Scheduler Sidebar Group
 *
 * @web
 */
interface SchedulerSidebarItem {
    /**
     * The HTML rendered inside the sidebar item's card
     */
    html: string;

    /**
     * List of actions the user can perform on the sidebar item
     */
    actions: SchedulerSidebarItemActions[];

    /**
     * Whether this item can be dragged to the scheduler
     */
    draggableToScheduler: any;
}

/**
 * Used to represent an Action for a Scheduler Sidebar Item
 *
 * @web
 */
interface SchedulerSidebarItemActions {
    /**
     * Text displayed to the user for the action
     */
    text: string;

    /**
     * Function to invoke when a user selects the action
     */
    callback: () => void;
}

/**
 * Used to represent an event provided by the `onCallback` function of the Scheduler
 */
interface SchedulerEvent {

    /**
     * Type of the event
     */
    type: 'eventMove' | 'eventDropped' | 'eventMenuItemClicked';

    /**
     * The event being moved
     *
     * @remarks
     *
     * See https://api.daypilot.org/daypilot-event-data/ for structure of this object
     *
     */
    event: any;

    /**
     * The resource the event was on
     *
     * @remarks
     *
     * See https://api.daypilot.org/daypilot-scheduler-resources/ for structure of this object
     */
    resource: any;

    /**
     * Which scheduler the event is being moved from
     */
    fromScheduler: 'allocated' | 'left' | 'bottom';

    /**
     * Which scheduler the event is being moved to
     */
    toScheduler: 'allocated' | 'left' | 'bottom';

    /**
     * Additional Data
     */
    extra: any

}

class DayPilotEvent {
    data: any;
}
