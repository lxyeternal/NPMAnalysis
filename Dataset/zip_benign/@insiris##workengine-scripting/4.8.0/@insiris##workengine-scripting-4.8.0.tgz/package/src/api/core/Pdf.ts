import {ApiCallback} from "../api";
/**
 * Buffer from browser/node
 */
interface Buffer {
}

/**
 * Generate PDF Documents, using the PDF Make Library
 *
 * @remarks
 *
 * All methods are passed a PDFMake Object.  See http://pdfmake.org/ for a specification of this object
 */
export class Pdf {

    /**
     * Create a PDF Document and call PDFMake's `open` function
     *
     * @web
     *
     * @param document PDFMake document
     */
    open(document: any) {
    }

    /**
     * Create a PDF Document and call PDFMake's `download` function
     *
     * @web
     *
     * @param document PDFMake document
     * @param fileName PDF filename
     */
    download(document: any, fileName: string) {
    }

    /**
     * Create a PDF Document and call PDFMake's `print` function
     *
     * @web
     *
     * @param document PDFMake document
     */
    print(document: any) {
    }

    /**
     * Create a PDF Document and buffer the result from PDFMake into a Buffer
     *
     * @cloud
     *
     * @param document PDFMake document
     * @param callback Callback to invoke on complete/error, returning the buffer on complete
     */
    buffer(document: any, callback: ApiCallback<Buffer>) {
    }
}

