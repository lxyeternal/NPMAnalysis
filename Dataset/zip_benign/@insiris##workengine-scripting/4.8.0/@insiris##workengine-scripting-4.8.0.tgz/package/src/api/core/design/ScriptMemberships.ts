import {ApiCallback, DomainPaginationResponse} from "../../api";

/**
 * Manage Script Memberships
 */
export class ScriptMemberships {

    /**
     * Creates a script membership
     *
     * @cloud
     * @web
     *
     * @param scriptMembership
     * @param callback
     */
    create(scriptMembership: ScriptMembership, callback: ApiCallback<ScriptMembership>) {
    }

    /**
     * Gets a script membership
     *
     * @cloud
     * @web
     *
     * @param idOrUuid
     * @param callback
     */
    get(idOrUuid: number | string, callback: ApiCallback<ScriptMembership>) {
    }

    /**
     * Updates a script membership
     *
     * @cloud
     * @web
     *
     * @param scriptMembership
     * @param callback
     */
    update(scriptMembership: ScriptMembership, callback: ApiCallback<ScriptMembership>) {
    }

    /**
     * Deletes a script membership
     *
     * @cloud
     * @web
     *
     * @param idOrUuid
     * @param callback
     */
    delete(idOrUuid: number | string, callback: ApiCallback<boolean>) {
    }

    /**
     * List Script memberships by scriptable thing
     *
     * @cloud
     * @web
     *
     * @param page
     * @param scriptableId ID of the scriptable thing you are listing for
     * @param scriptableType e.g. "Form", "Question" etc
     * @param callback
     */
    list(page: number, scriptableId: number, scriptableType: string, callback: ApiCallback<DomainPaginationResponse<ScriptMembership>>) {
    }

    /**
     * All Script memberships by scriptable thing
     *
     * @cloud
     * @web
     *
     * @param scriptableId ID of the scriptable thing you are listing for
     * @param scriptableType e.g. "Form", "Question" etc
     * @param callback
     */
    all( scriptableId: number, scriptableType: string, callback: ApiCallback<ScriptMembership[]>) {
    }

}

export interface Script {
    scriptMemberships: ScriptMembership[];
    id?: number,
    path?: string,
    js?: string,
    bucketUrl?: string,
    createdAt?: Date,
    updatedAt?: Date
}
export interface ScriptMembership {
   script: Script;
   id?: number;
   scriptableId?: number;
   scriptableType?: string;
   scriptId?: number | string;
   scriptableIdentifier?: string;
   scriptableName?: string;
   createdAt?: Date;
   updatedAt?: Date;

}
