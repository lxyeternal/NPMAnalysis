/**
 * Manage Users
 */
import {ApiCallback} from "../api";

export class Users {
    /**
     * Fetch all users that the current user has access to
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @remarks
     *
     * Note that this method can take a long time to return for large result sets. Only use where you know there are just a few pages (a few hundred) objects
     *
     * @param callback Callback to invoke on complete/error
     */
    all(callback: ApiCallback<User[]>) {
    }

    /**
     * Fetch a user by its id
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param userId
     * @param callback
     */
    get(userId: number, callback: ApiCallback<User>) {

    }
}

/**
 * Callback function invoked by WorkEngine when a call to the WorkEngine Users API succeeds or fails
 *
 * @remarks
 *
 * Note that response differs from platform to platform and is the raw underlying response from the networking library used on the platform.  This may change in the future and it is not advised you use this response in your Script.
 *
 * @param response Response
 */

export class User {
    constructor(
        public id?: number,
        public organisationId?: number,
        public profileId?: number,
        public name?: string,
        public email?: string,
        public language?: string,
        public timezone?: string,
        public settings?: UserSettings,
        public createdAt?: Date,
        public updatedAt?: Date,
        public profile?: Profile,
        public webFcmToken?: string,
        public mobileFcmToken?: string,
        public password?: string,
        public passwordConfirmation?: string,
        public dataKey?: string,
        public organisation?: Organisation,
        public scriptingCdnUrlPrefix?: string,
        public profileIds?: number[],
        public appInfo?: string,
        public deviceInfo?: string,
        public scriptBuildInfo?: string,
        public insiris = false) {
    }
}

export enum SidebarMode {
    Icon = "Icon",
    IconWithLabel = "IconWithLabel"
}

export class UserSettings {
    constructor(
        public shortcuts: { [shortcutId: number]: ShortcutEntry } = {},
        public sidebarShortcutMode: SidebarMode = SidebarMode.IconWithLabel,
    ) {
    }
}


interface ShortcutEntry {
    type?: string;
    instanceId?: number;
    sidebar?: boolean;
    startCenter?: boolean;
    position?: number;
}

interface Profile {
    id?: number;
    organisationId?: number;
    name?: string;
    createdAt?: Date;
    updatedAt?: Date;
    permissions?: Permission[];
    shortcuts?: Shortcut[];
    defaultOrgGroupPermissionTemplateId?: number;
    profileAddOns?: ProfileAddOn[];
    componentOnly?: boolean;
}

interface ProfileAddOn {
    id?: number;
    profileId?: number;
    instanceId?: number;
    type?: string;
    createdAt?: Date;
    updatedAt?: Date;
}

interface Permission {
    id?: number;
    type?: string;
    profileId?: number;
    instanceId?: number;
    level?: string;
    instanceIsDefault?: boolean;
    extra?: any;
    permissionId?: number;
    orgGroupPermissionTemplateId?: number;
    createdAt?: Date;
    updatedAt?: Date;
}

interface Shortcut {
    id?: number;
    profileId?: number;
    type?: string;
    instanceId?: number;
    startCenter?: boolean;
    sidebar?: boolean;
    name?: string;
    icon?: string;
    description?: string;
    createdAt?: Date;
    updatedAt?: Date;
}

interface Organisation {
    id?: number;
    namespace?: string;
    name?: string;
    language?: string;
    timezone?: string;
    modelVersion?: number;
    scriptBuild?: string;
    scriptBuilds?: string[];
    startCenterHtml?: string;
    dataBucket?: string;
    whitelistIps?: string[];
    primaryThemeColour?: string;
    webSidebarSmallImgSrc?: string;
    webSidebarBigImgSrc?: string;
    webLoginImgSrc?: string;
    mobileLoginImgSrc?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
