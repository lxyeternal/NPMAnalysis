export class Logger {
    /**
     * Log a message
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param level One of debug, info, notice, warn, error
     * @param message Message to log
     * @param data Hash to log
     */
    log(level: 'debug' | 'info' | 'notice' | 'warn' | 'error', message: string, data?: any) {
        message = `📝 ${message}`;
        data ? console.log(message, data) : console.log(message);
    }

    /**
     * Log a message at debug level
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param message Message to log
     * @param data Hash to log
     */
    debug(message: string, data?: any) {
        message = `📝 ${message}`;
        data ? console.debug(message, data) : console.log(message);
    }

    /**
     * Log a message at info level
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param message Message to log
     * @param data Hash to log
     */
    info(message: string, data?: any) {
        message = `📝 ${message}`;
        data ? console.info(message, data) : console.log(message);
    }

    /**
     * Log a message at notice level
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param message Message to log
     * @param data Hash to log
     */
    notice(message: string, data?: any) {
        message = `📣 📝 ${message}`;
        data ? console.info(message, data) : console.info(message);
    }

    /**
     * Log a message at warn level
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param message Message to log
     * @param data Hash to log
     */
    warn(message: string, data?: any) {
        message = `📝 ${message}`;
        data ? console.warn(message, data) : console.warn(message);
    }

    /**
     * Log a message at error level
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param message Message to log
     * @param data Hash to log
     */
    error(message: string, data?: any) {
        message = `📝 ${message}`;
        data ? console.error(message, data) : console.error(message);
    }
}

const breakLoop = {};
export default breakLoop;

export class Async {

    /**
     * Runs a function once
     *
     * @web
     * @cloud
     * @ios
     *
     * @param fn Function to run
     * @returns Wrapped function
     */
    once(fn: ((...args: any[]) => void) | null): (...args: any[]) => void {
        function wrapper(...args: any[]): void {
            if (fn === null) return;
            const callFn = fn;
            fn = null;
            // @ts-ignore
            callFn.apply(this, args);
        }

        Object.assign(wrapper, fn);
        return wrapper;
    }

    /**
     * Ensures a function is run only once
     *
     * @web
     * @cloud
     * @ios
     *
     * @param fn Function to run
     * @returns Wrapped function
     */
    onlyOnce(fn: ((...args: any[]) => void) | null): (...args: any[]) => void {
        return function (...args: any[]) {
            if (fn === null) throw new Error('Callback was already called.');
            const callFn = fn;
            fn = null;
            // @ts-ignore
            callFn.apply(this, args);
        };
    }

    /**
     * Create an iterator over a collection
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param coll Collection to iterate
     * @returns an iterator function on which you can call next
     */
    createArrayIterator(coll: any[]): () => ({ value: any; key: number } | null) {
        let i = -1;
        const len = coll.length;
        return function next() {
            return ++i < len ? {value: coll[i], key: i} : null;
        };
    }

    /**
     * Applies the function iteratee to each item in coll, in series. The iteratee is called with an item from the list, and a callback for when it has finished. If the iteratee passes an error to its callback, the main callback (for the each function) is immediately called with the error.
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param obj A collection to iterate over.
     * @param iteratee A function to apply to each item in coll. Invoked with (item, callback). The array index is not passed to the iteratee. If you need the index, use eachOf.
     * @param finishCallback A callback which is called when all iteratee functions have finished, or an error occurs. Invoked with (err).
     */
    each(
        obj: any[],
        iteratee: (value: any, callback: (error?: string) => void) => void,
        finishCallback: (error?: string) => void,
    ) {
        const onComplete = this.once(finishCallback);
        const onlyOnce2 = this.onlyOnce;
        if (!obj) {
            console.log('passed in object was null');
            return onComplete(null);
        }

        let done = false;

        // Retrieves next item or return nothing
        const nextElem = this.createArrayIterator(obj);

        // Called by the iterate function once the iterator is complete
        function iterateeCallback(err: any, value: any) {
            if (err) {
                done = true;
                onComplete(err);
            }
            iterate();
        }

        // Get the next element and run the provided callback
        function iterate() {
            if (done) return; // We've had an error from our callback

            const elem = nextElem();

            // If no more elements
            if (elem === null) {
                return onComplete(null);
            }

            iteratee(elem.value, onlyOnce2(iterateeCallback));
        }

        iterate();
    }

    /**
     * Applies the function iteratee to each item in coll, in parallel. The iteratee is called with an item from the list, and a callback for when it has finished. If the iteratee passes an error to its callback, the main callback (for the each function) is immediately called with the error.
     *
     * @cloud
     *
     * @param concurrency Controls the number of items that can be processed in parallel.
     * @param obj A collection to iterate over.
     * @param iteratee A function to apply to each item in coll. Invoked with (item, callback). The array index is not passed to the iteratee. If you need the index, use eachOf.
     * @param finishCallback A callback which is called when all iteratee functions have finished, or an error occurs. Invoked with (err).
     */
    parallel(
        concurrency: number,
        obj: any[],
        iteratee: (value: any, callback: (error?: string) => void) => void,
        finishCallback: (error?: string) => void,
    ) {

        const onComplete = this.once(finishCallback);
        const onlyOnce2 = this.onlyOnce;
        if (concurrency <= 0) {
            throw new RangeError('concurrency limit cannot be less than 1');
        }
        if (!obj) {
            return onComplete(null);
        }
        const nextElem = this.createArrayIterator(obj);
        let done = false;
        let canceled = false;
        let running = 0;
        let looping = false;

        function iterateeCallback(err: any, value: any) {
            if (canceled) return;
            running -= 1;
            if (err) {
                done = true;
                onComplete(err);
            } else if (err === false) {
                done = true;
                canceled = true;
            } else if (value === breakLoop || (done && running <= 0)) {
                done = true;
                return onComplete(null);
            } else if (!looping) {
                replenish();
            }
        }

        function replenish() {
            looping = true;
            while (running < concurrency && !done) {
                const elem = nextElem();
                if (elem === null) {
                    done = true;
                    if (running <= 0) {
                        onComplete(null);
                    }
                    return;
                }
                running += 1;
                iteratee(elem.value,
                    onlyOnce2(iterateeCallback));
            }
            looping = false;
        }

        replenish();
    }

}

