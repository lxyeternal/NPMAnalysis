import {ApiCallback} from "../api";

/**
 * Manage Workflows
 */
export class Workflows {
    /**
     * Get a Workflow
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param id ID of object
     * @param callback Callback to invoke on complete/error
     */
    get(id: number, callback: ApiCallback<Workflow>) {
    }
}

/**
 * Callback function invoked by WorkEngine when a call to the WorkEngine Workflows API succeeds or fails
 *
 * @remarks
 *
 * Note that response differs from platform to platform and is the raw underlying response from the networking library used on the platform.  This may change in the future and it is not advised you use this response in your Script.
 *
 * @param response Response
 */

interface Workflow {
    id?: number;
    positionJson?: JSON;
    organisationId?: number;
    name?: string;
    description?: string;
    statuses?: Status[];
    transitions?: Transition[];
    flowTags?: FlowTag[];
    defaultTransitionId?: number;
    identifier?: string;
    createdAt?: Date;
    updatedAt?: Date;
}

interface Status {
    fromTransitions: Transition[];
    toTransitions: Transition[];

    id?: number;
    workflowId?: number;
    name?: string;
    description?: string;
    colour?: string;
    icon?: string;
    cluster?: string;
    disabled?: boolean;
    identifier?: string;
    updatedAt?: Date;
    createdAt?: Date;
}

interface Transition {
    id?: number;
    workflowId?: number;
    name?: string;
    description?: string;
    profileId?: number;
    fromStatusId?: number;
    toStatusId?: number;
    transitionFlowTags?: TransitionFlowTag[];
    defaultStart?: boolean;
    identifier?: string;
    scriptTransitionId?: number;
    workerQueue?: string;
    workerRetry?: number;
    workerUnique?: boolean;
    updatedAt?: Date;
    createdAt?: Date;
}

interface TransitionFlowTag {
    id?: number;
    transitionId?: number;
    flowTagId?: number;
    updatedAt?: Date;
    createdAt?: Date;
}

interface FlowTag {
    id?: number;
    workflowId?: number;
    name?: string;
    createdAt?: Date;
    updatedAt?: Date;
}
