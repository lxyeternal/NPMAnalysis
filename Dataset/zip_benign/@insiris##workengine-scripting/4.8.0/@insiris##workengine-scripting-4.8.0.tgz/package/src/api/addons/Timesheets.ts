export interface Shift {
    snapped_start_at: Date;
    snapped_finish_at: Date;
    start_at_position: string;
    finish_at_position: string;
    actual_start_at: Date;
    actual_finish_at: Date;
    last_break_at: Date;
    actual_shift_duration: number;
    actual_working_duration: number;
    snapped_shift_duration: number;
    snapped_working_duration: number;
    total_break_duration: number;
}

export interface Break {
    start_at: Date;
    finish_at: Date;
    start_at_position: string;
    finish_at_position: string;
    reason: number;
    duration: number;
}
