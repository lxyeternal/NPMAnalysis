import {ApiCallback} from "../../api";

/**
 * Manage the currently active Form
 */
export class Form {

    /**
     * Get the current form
     *
     * @web
     * @android
     * @ios
     *
     * @param callback Callback that will be invoked with the form
     */
    getForm(callback: ApiCallback<Form>) {
    }

    /**
     * Get the object currently backing the form
     *
     * @web
     * @android
     * @ios
     *
     * @param callback Callback that will be invoked with the form's object
     */
    getObject(callback: GetObjectCallback) {
    }

    /**
     * Set the object currently backing the form
     *
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * Note that this will cause any control's bound to values in the object to update
     *
     * @param object Updated object for the form
     */
    setObject(object: any) {
    }

    /**
     * Set a card as visible on the form
     *
     * @web
     * @android
     * @ios
     *
     *
     * @param cardIdentifier Identifier of the card
     * @param visible Whether the card is visible or not
     */
    setCardVisible(cardIdentifier: string, visible: boolean) {
    }

    /**
     * Set a page as visible on the form
     *
     * @web
     * @android
     * @ios
     *
     *
     * @param pageIdentifier Identifier of the page
     * @param visible Whether the card is visible or not
     */
    setPageVisible(pageIdentifier: string, visible: boolean) {
    }

    /**
     * Set the currently active page on the form
     *
     * @web
     * @android
     * @ios
     *
     * @param pageIdentifier Identifier of the page to make active
     */
    showPage(pageIdentifier: string) {
    }

    /**
     * Hides all the pages on a form
     *
     * @web
     * @android
     * @ios
     * @param excludePageIdentifiers Optional parameter of page identifiers which will be shown instead of hidden
     */
    hideAllPages(excludePageIdentifiers: string[] = []) {
    }

    /**
     * Get the value for a field for the form's object
     *
     * @web
     * @android
     * @ios
     *
     * @param identifier Identifier of the control
     * @param callback Callback that will be invoked with the field's value
     */
    getObjectValue(identifier: string, callback: ApiCallback<any>) {
    }

    /**
     * Set the value for a field for the form's object
     *
     * @web
     * @android
     * @ios
     *
     * @param identifier Identifier of the control/backing object's key
     * @param value New value
     */
    setObjectValue(identifier: string, value: any) {
    }

    /**
     * Sets multiple fields for an object
     *
     * @web
     * @android
     * @ios
     *
     * @param object Hash of key value pairs to set
     */
    setObjectValues(object: any) {
    }

    /**
     * Get the value of a control
     *
     * @web
     * @android
     * @ios
     *
     * @deprecated This forwards to getObjectValue
     *
     * @param identifier Identifier of the control
     * @param callback Callback that will be invoked with the control's value
     */
    getControlValue(identifier: string, callback: ApiCallback<any>) {
    }

    /**
     * Set the value of a control
     *
     * @web
     * @android
     * @ios
     *
     * @deprecated This forwards to setObjectValue
     *
     * @remarks
     *
     * Note that this function actually sets the form's backing object's value.
     *
     * @param identifier Identifier of the control/backing object's key
     * @param value New value
     */
    setControlValue(identifier: string, value: any) {
    }

    /**
     * Set the options that are shown for a select field control
     *
     * @web
     * @android
     * @ios
     *
     * @deprecated Use setControlOptions, passing in a {selectOptions: ...}
     *
     * @remarks
     *
     * The format for the options is an array of hash objects with a `value` that is used when a user selects the `label` option.
     *
     * Example:
     *
     * `[{label: "Darth Vader", value: 'darth_vader'}, {label: "Luke Skywalker", value: "luke_skywalker"}]`
     *
     * @param identifier Identifier of the select control
     * @param options Options to set
     */
    setSelectOptions(identifier: string, options: any[]) {
    }

    /**
     * Set the options that are shown for a select field control
     *
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * Sets the options for a control - for example, for setting the selectOptions for a select control
     *
     * @param identifier Identifier of the select control
     * @param options Options to set
     */
    setControlOptions(identifier: string, options: ControlOptions) {
    }

    /**
     * Tells a control to reload/redraw
     *
     * @web
     *
     * @remarks
     *
     * Tells a control it should reload/redraw or rebind its value
     *
     * @param identifier Identifier of the control
     */
    reloadControl(identifier: string) {
    }

    /**
     * Closes a form
     *
     * @web
     * @android
     * @ios
     *
     */
    close() {
    }

    /**
     * Performs the save logic on the form.  Callbacks and file uploads will be invoked and [[FormLifecycle]] hooks will be run
     *
     * @web
     * @android
     * @ios
     *
     * @param callback returns true if the save was successful
     *
     * @remarks
     * BeforeSave and AfterSave call backs are still run
     */
    save(callback: ApiCallback<boolean> | null = null) {
    }
}

/**
 * Callback function invoked by WorkEngine with the form's object
 *
 * @remarks
 *
 * Note that for schemaless forms, WorkEngine automatically creates a backing object for control values.  This is the object that is returned for schemaless forms.
 *
 * @param object Current Object the form is bound to
 */
type GetObjectCallback = (error: Error | any | null, object: any) => void;

interface ControlOptions {

    /**
     * Used to show/hide the control
     *
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * Works on ALL controls
     *
     */
    visible?: boolean;

    /**
     * Used to set the options on a select control
     *
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * Works on 'select' control.  The expected array is a sequence of hashes with keys for 'label' and 'value' for the select options
     *
     * `{selectOptions: [{label: "Darth Vader", value: 'darth_vader'}, {label: "Luke Skywalker", value: "luke_skywalker"}]}`
     */
    selectOptions?: [{ label: string, value: string }];

    /**
     * Used to set the contents for a label control
     *
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * By default a label control will show either the value in the backing object, by the label's identifier, or the value provided for label when designing the control.
     * Use this to override the label that is shown on a label control in all instances, from scripting.
     */
    label?: string;

    /**
     * Used to set the contents for a html control
     *
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * By default a html control will show either the value in the backing object, by the control's field, or the value provided for HTML when designing the control.
     * Use this to override the html that is shown on a html control in all instances, from scripting.
     */
    html?: string;
}
