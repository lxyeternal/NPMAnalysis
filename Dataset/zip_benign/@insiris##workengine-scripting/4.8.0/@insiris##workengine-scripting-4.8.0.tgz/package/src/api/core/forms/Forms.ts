
import {ApiCallback, HashMap} from "../../api";
import {WeObject} from "../objects/Objects";
import {Form} from "./Form";

/**
 * Open forms, and get access to the current active form
 */
export class Forms {
    /**
     * Manage the currently active WorkEngine Form
     *
     * @web
     * @android
     * @ios
     */
    form: Form = new Form();

    /**
     * Open a WorkEngine Form
     *
     * @web
     *
     * @remarks
     *
     * This function opens a form as an embedded modal form within the current user interface.  Forms that are opened in this manner are called 'schemaless' forms as they are not tied to a WorkEngine object.
     *
     * When opening a form in this way, you can provide an apiName to create a new Scripting context within which to run any scripts attached to the opened form
     *
     * @param formId ID of the form
     * @param formName Title for the modal form popup
     * @param apiName Unique name for the scripting context for the form
     * @param object Used to set the object fields on the form
     * @param afterClosedCallback Called when the form is closed
     * @param formData Additional data that can be passed to a form to be used by that forms scripts
     */
    openForm(
        formId: number | string,
        formName: string,
        apiName?: string,
        object?: WeObject,
        afterClosedCallback?: ApiCallback<WeObject>,
        formData?: HashMap<string, any>,
    ) {
    }

    /**
     *
     * Opens a WorkEngine Form by its identifier
     *
     * @web
     *
     * @deprecated Replaced by openForm
     *
     * @remarks
     *
     * See [[openForm]] for behaviour
     *
     * @param formIdentifier Identifier of the form
     * @param formName Title for the modal form popup
     * @param apiName Unique name for the scripting context for the form
     * @param object Used to set the object fields on the form
     */
    openFormByIdentifier(formIdentifier: string, formName: string, apiName?: string, object?: WeObject) {
    }

    /**
     * Open a WorkEngine Form in a popup, with an object
     *
     * @web
     * @ios
     * @android
     *
     * @param formIdOrIdentifier Form to open - pass null to pick the default form, or show the form picker
     * @param objectDefinitionIdentifier Identifier of the object
     * @param object A seed object used to initialise the form's object
     * @param apiName Unique name for the scripting context for the form
     * @param afterClosedCallback Called when the form is closed
     * @param formData Additional data that can be passed to a form to be used by that forms scripts
     */
    openFormForObject(
        formIdOrIdentifier: number | string | null,
        objectDefinitionIdentifier: string,
        object: any,
        apiName?: string,
        afterClosedCallback?: ApiCallback<WeObject>,
        formData?: HashMap<string, any>,
    ) {
    }
}
