import {RelationshipDefinition} from "./RelationshipDefinitions";
import {Group} from "./Groups";
import {ApiCallback, DomainPaginationResponse} from "../../api";

/**
 * Manage Object Definitions
 */
export class ObjectDefinitions {
    /**
     * Create an object definition
     *
     * @cloud
     * @web
     *
     * @param objectDefinition
     * @param callback
     */
    create(objectDefinition: ObjectDefinition, callback: ApiCallback<ObjectDefinition>) {
    }

    /**
     * Get an object definition
     *
     * @cloud
     * @web
     * @ios
     * @android
     *
     * @param idOrUuid
     * @param callback
     */
    get(idOrUuid: number | string, callback: ApiCallback<ObjectDefinition>) {
    }

    /**
     * Update an object definition
     *
     * @cloud
     * @web
     *
     * @param objectDefinition
     * @param callback
     */
    update(objectDefinition: ObjectDefinition, callback: ApiCallback<ObjectDefinition>) {
    }

    /**
     * Delete an object definition
     *
     * @cloud
     * @web
     *
     * @param idOrUuid
     * @param callback
     */
    delete(idOrUuid: number | string, callback: ApiCallback<boolean>) {
    }

    /**
     * List object definitions
     *
     * @cloud
     * @web
     *
     * @param page
     * @param callback
     */
    list(page: number, callback: ApiCallback<DomainPaginationResponse<ObjectDefinition>>) {
    }

    /**
     * Get all object definitions
     *
     * @cloud
     * @web
     * @ios
     * @android
     *
     * @param options parameters for object definitions. Includes Full and WorkflowID
     * @param callback
     */
    all(options: ObjectDefinitionAllOptions, callback: ApiCallback<ObjectDefinition[]>) {

    }
}

export interface ObjectDefinition {
    groups: Group[],
    relationshipDefinitions: RelationshipDefinition[],
    relationshipDefinitionsAsDestination: RelationshipDefinition[],

    id?: number,
    organisationId?: number,
    workflowId?: number,
    name?: string,
    lastPublishedAt?: Date,
    identifier?: string,
    pendingMigration?: boolean,
    defaultFormId?: number,
    defaultPermission?: string,
    createdAt?: Date,
    updatedAt?: Date,
    auditVersions?: boolean,
    limitAuditVersions?: boolean,
    auditVersionsToKeep?: number,
    disablePublish?: boolean,
    defaultAssignToCurrentUser?: boolean,
    statusVersions?: boolean,
    tableCreated?: boolean,
    statusesTableCreated?: boolean,
    versionsTableCreated?: boolean,
    latestError?: string,
}

export interface ObjectDefinitionAllOptions {
    /**
     * Include all groups, fields and relationship definitions. This always defaults to true on ios and android
     */
    full?: boolean;
    /**
     * Filter results by workflow
     */
    workflowIdOrIdentifier?: number | string | undefined;
}
