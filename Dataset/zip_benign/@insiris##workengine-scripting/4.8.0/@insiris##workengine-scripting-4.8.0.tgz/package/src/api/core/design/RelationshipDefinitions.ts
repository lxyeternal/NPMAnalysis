import {ApiCallback, DomainPaginationResponse} from "../../api";

/**
 * Manage Relationhip Definitions
 */
export class RelationshipDefinitions {
    /**
     * Create Relationship Definitions
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param relationshipDefinition
     * @param callback
     */
    create(objectDefinitionId: number, relationshipDefinition: RelationshipDefinition, callback: ApiCallback<RelationshipDefinition>) {

    }

    /**
     * Get a Relationship Definition
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param idOrUuid
     * @param callback
     */
    get(objectDefinitionId: number, idOrUuid: number | string, callback: ApiCallback<RelationshipDefinition>) {

    }

    /**
     * Update a Relationship Definition
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param relationshipDefinition
     * @param callback
     */
    update(objectDefinitionId: number, relationshipDefinition: RelationshipDefinition, callback: ApiCallback<RelationshipDefinition>) {
    }

    /**
     * Delete a Relationship Definition
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param idOrUuid
     * @param callback
     */
    delete(objectDefinitionId: number, idOrUuid: number | string, callback: ApiCallback<boolean>) {
    }

    /**
     * List Relationship Definitions by object definition
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param page
     * @param callback
     */
    list(objectDefinitionId: number, page: number, callback: ApiCallback<DomainPaginationResponse<RelationshipDefinition>>) {
    }

    /**
     * Get all Relationship Definitions
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param callback
     */
    all(objectDefinitionId: number, callback: ApiCallback<RelationshipDefinition[]>) {
    }
}

export interface RelationshipDefinition {
    id?: number,
    objectDefinitionId?: number,
    destinationObjectDefinitionId?: number,
    toName?: string,
    fromName?: string,
    direction?: string,
    fromIdentifier?: string,
    toIdentifier?: string,
    dependent?: string,
    mandatory?: boolean,
    migrated?: boolean,
    createdAt?: Date,
    updatedAt?: Date,
}
