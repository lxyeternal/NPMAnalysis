import {ApiCallback, DomainPaginationResponse} from "../../api";
import {Card} from "./Cards";

/**
 * Manage Pages
 */
export class Pages {
    /**
     * Creates a page for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param page
     * @param callback
     */
    create(formId: number, page: any, callback: ApiCallback<Page>) {
    }

    /**
     * Gets a page for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param idOrUuid
     * @param callback
     */
    get(formId: number, idOrUuid: number | string, callback: ApiCallback<Page>) {
    }

    /**
     * Updates a page for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param page
     * @param callback
     */
    update(formId: number, page: any, callback: ApiCallback<Page>) {
    }

    /**
     * Deletes a page for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param idOrUuid
     * @param callback
     */
    delete(formId: number, idOrUuid: number | string, callback: ApiCallback<boolean>) {
    }

    /**
     * Lists pages for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param page
     * @param callback
     */
    list(formId: number, page: number, callback: ApiCallback<DomainPaginationResponse<Page>>) {
    }
}

export interface Page {
    cards: Card[];

    id?: number;
    formId?: number;
    name?: string;
    identifier?: string;
    position?: number;
    hidden?: boolean;
    createdAt?: Date;
    updatedAt?: Date;
}
