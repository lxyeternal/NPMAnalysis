import {ApiCallback, DomainPaginationResponse} from "../../api";
import {Control} from "./Controls";

/**
 * Manage Cards
 */
export class Cards {
    /**
     * Creates a card for a page for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param pageId
     * @param card
     * @param callback
     */
    create(formId: number, pageId: number, card: Card, callback: ApiCallback<Card>) {
    }

    /**
     * Gets a card for a page for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param pageId
     * @param idOrUuid
     * @param callback
     */
    get(formId: number, pageId: number, idOrUuid: number | string, callback: ApiCallback<Card>) {
    }

    /**
     * Updates a card for a page for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param pageId
     * @param card
     * @param callback
     */
    update(formId: number, pageId: number, card: Card, callback: ApiCallback<Card>) {
    }

    /**
     * Deletes a card for a page for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param pageId
     * @param idOrUuid
     * @param callback
     */
    delete(formId: number, pageId: number, idOrUuid: number | string, callback: ApiCallback<boolean>) {
    }

    /**
     * Lists cards for a page for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param pageId
     * @param page
     * @param callback
     */
    list(formId: number, pageId: number, page: number, callback: ApiCallback<DomainPaginationResponse<Card>>) {
    }
}

export interface Card {
    controls: Control[];

    id?: number;
    pageId?: number;
    name?: string;
    identifier?: string;
    position?: number;
    createdAt?: Date;
    updatedAt?: Date;

}
