import {Parcel} from "./Parcels";

export class ParcelBuilder {

    constructor(userId: number) {
    }

    /**
     * Returns the built parcel
     *
     * @cloud
     * @web
     */
    build(): Parcel {
        return new Parcel();
    }

    /**
     *
     * @cloud
     * @web
     *
     * @param identifier
     * @param objectUuid
     */
    addObject(identifier: string, objectUuid: string): ParcelBuilder {
        return this;
    }

    /**
     *
     * @cloud
     * @web
     *
     * @param identifier
     * @param objectUuids
     */
    addObjects(identifier: string, objectUuids: string[]): ParcelBuilder {
        return this;
    }

}
