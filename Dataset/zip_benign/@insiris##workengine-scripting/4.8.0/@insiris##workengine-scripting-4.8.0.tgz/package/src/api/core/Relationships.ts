/**
 * Manage Relationships between Objects
 */
import {ApiCallback, HashMap} from "../api";

export class Relationships {
    /**
     * Creates a new Relationship between two objects
     *
     * @web
     * @cloud
     * @android
     * @ios
     *
     * @param objectIdOrUuid ID or UUID of the object
     * @param objectIdentifier Type of the object
     * @param foreignObjectIdOrUuid ID or UUID of the foreign object
     * @param relationshipIdentifier Type of the relationship
     * @param callback Callback to invoke on complete/error
     */
    create(objectIdOrUuid: number | string, objectIdentifier: string, foreignObjectIdOrUuid: number | string, relationshipIdentifier: string, callback: ApiCallback<any>) {
    }

    /**
     * Gets a Relationship between two objects
     *
     * @web
     * @cloud
     * @android
     * @ios
     *
     * @remarks
     *
     * Note that either objectId or foreignObjectId can be specified
     *
     * @param objectIdOrUUid ID or UUID of the object
     * @param objectIdentifier Type of the object
     * @param foreignObjectIdOrUuid ID or UUID of the foreign object
     * @param relationshipIdentifier Type of the relationship
     * @param callback Callback to invoke on complete/error
     */
    get(objectIdOrUUid: number | string, objectIdentifier: string, foreignObjectIdOrUuid: number | string, relationshipIdentifier: string, callback: ApiCallback<any>) {
    }

    /**
     * Deletes a new Relationship between two objects
     *
     * @web
     * @cloud
     * @android
     * @ios
     *
     * @param objectIdOrUuid ID or UUID of the object
     * @param objectIdentifier Type of the object
     * @param foreignObjectIdOrUuid ID or UUID of the foreign object
     * @param relationshipIdentifier Type of the relationship
     * @param callback Callback to invoke on complete/error
     */
    delete(objectIdOrUuid: number | string, objectIdentifier: string, foreignObjectIdOrUuid: number | string, relationshipIdentifier: string, callback: ApiCallback<boolean>) {
    }

    /**
     * Fetches all objects for an object by the relationship
     *
     * @web
     * @cloud
     * @android
     * @ios
     *
     * @param objectIdOrUuid ID or UUID of the object
     * @param objectIdentifier Type of the object
     * @param relationshipIdentifier Type of the relationship
     * @param callback Callback to invoke on complete/error
     */
    all(objectIdOrUuid: number | string, objectIdentifier: string, relationshipIdentifier: string, callback: ApiCallback<any[]>) {
    }

    /**
     * Fetches all the related objects broken down by relationship identifier
     *
     * @web
     * @cloud
     * @android
     * @ios
     *
     * @param objectIdOrUuid
     * @param objectIdentifier
     * @param relationships List of relationship identifiers to filter the results by
     * @param fields List of field identifiers to filter each object's fields by
     * @param callback
     */
    allForObject(
        objectIdOrUuid: number | string,
        objectIdentifier: string,
        relationships: string[] | undefined,
        fields: string[] | undefined,
        callback: ApiCallback<HashMap<string, any[]>>,
    ) {
    }

}

/**
 * Callback function invoked by WorkEngine when a call to the WorkEngine Relationships API succeeds or fails
 *
 * @remarks
 *
 * Note that response differs from platform to platform and is the raw underlying response from the networking library used on the platform.  This may change in the future and it is not advised you use this response in your Script.
 *
 * @param response Response
 */
