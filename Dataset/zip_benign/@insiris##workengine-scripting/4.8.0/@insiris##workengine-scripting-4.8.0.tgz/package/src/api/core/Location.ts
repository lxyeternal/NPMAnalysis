/**
 * Fetch the Location of a user
 */
export class Location {
    /**
     * Fetches the Latitude and Longitude of a user
     *
     * @web
     * @android
     * @ios
     *
     * @remarks
     *
     * Location Accuracy can be defined for WorkEngine Mobile using the following:
     *
     * 0: Location is accurate within a distance of 3000m on iOS and 500m on Android
     * 1: Location is accurate within a distance of 1000m on iOS and 500m on Android
     * 2: Location is accurate within a distance of 100m on iOS and between 100m and 500m on Android
     * 3: Location is accurate within a distance of 10m on iOS and between 0m and 100m on Android
     * 4: Location is accurate within a distance of ~0m on iOS and between 0m and 100m on Android
     * 5: Location accuracy is optimized for navigation on iOS and matches the [LocationAccuracy.best] on Android
     *
     * Location accuracy is ignored in WorkEngine Web
     *
     * @param accuracy The accuracy level for obtaining location (see remarks above)
     * @param timeout How long to wait to acquire a location before calling back (in millis)
     * @param callback Callback to invoke on complete/error
     */
    getLocation(accuracy: number, timeout: number, callback: GetLocationCallback) {

    }

    /**
     * Forward geocodes an address using the LocationIQ Api
     *
     * @cloud
     *
     * @param searchText Address
     * @param postcode Postcode
     * @param countryCode Bias the geocoder using a country code
     * @param callback Callback to invoke on complete/error
     */
    forwardGeocode(searchText: string, postcode: string, countryCode: string, callback: ForwardGeocodeCallback) {

    }

    /**
     * Forward geocodes a postion using the LocationIQ Api
     *
     * @cloud
     *
     * @param lat Latitude of position
     * @param lon Longitude of position
     * @param callback Callback to invoke on complete/error
     */
    reverseGeocode(lat: number, lon: number, callback: ReverseGeocodeCallback) {

    }
}

/**
 * Callback function invoked when the user's location is acquired
 *
 *
 * @param response Location Response
 */
type GetLocationCallback = (error: Error | any | null, response: LocationResponse) => void;

/**
 * Callback function invoked when forward geocoding succeeds
 *
 * @param response Geocode Response
 */
type ForwardGeocodeCallback = (error: Error | any | null, response: [LocationIqForwardGeocodeResponse]) => void;

/**
 * Callback function invoked when reverse geocoding succeeds
 *
 * @param response Geocode Response
 */
type ReverseGeocodeCallback = (error: Error | any | null, response: LocationIqReverseGeocodeResponse) => void;

/**
 * This is the response object provided by LocationIQ. A full breakdown of the available fields
 * can be found at https://locationiq.com/docs
 */
interface LocationIqForwardGeocodeResponse {
    /**
     * Latitude of the position
     */
    lat: number;

    /**
     * Longitude of the position
     */
    lon: number;
}

/**
 * This is the response object provided by LocationIQ. A full breakdown of the available fields
 * can be found at https://locationiq.com/docs
 */
interface LocationIqReverseGeocodeResponse {
    /**
     * Display Name for address
     */
    display_name: string;

    /**
     * Address of the response
     */
    address: {road: string, suburb: string, county: string, region: string, state: string, postcode: string, country: string, country_code: string}
}

interface LocationResponse {
    /**
     * Latitude of the position
     */
    lat: number;

    /**
     * Longitude of the position
     */
    lng: number;
}
