/**
 * Core provides access to many of the core features provided by WorkEngine
 */
import {Forms} from "./forms/Forms";
import {Objects} from "./objects/Objects";
import {Relationships} from "./Relationships";
import {Push} from "./Push";
import {Pdf} from "./Pdf";
import {Workflows} from "./Workflows";
import {User, Users} from "./Users";
import {FilesUtil} from "./FilesUtil";
import {Questions} from "./questions/Questions";
import {Location} from "./Location";
import {Nfc} from "./Nfc";

import {throwOverride} from "../../test-helpers/test-helpers"
import {Email} from "./Email";
import {Http} from "./Http";
import {Working} from "./Working";
import {Design} from "./design/Design";
import {ApiCallback} from "../api";
import {Libraries} from "./Libraries";

export class Core {


    /**
     * The user's current auth token
     *
     * @web
     *
     * @deprecated This will be removed - using [[authToken]] instead which provides a callback
     *
     * @remarks
     *
     * *Deprecated* - use the callback authToken method below
     */
    "authToken[Deprecated]": string;

    /**
     * The user's current WorkEngine Auth Token
     *
     * @web
     * @android
     * @ios
     *
     * @param callback Callback that will be invoked with the auth token
     */
    authToken(callback: AuthTokenCallback) {
    }

    /**
     * The user's ID
     *
     * @web
     * @android
     * @ios
     *
     * @param callback Callback that will be invoked with the user's ID
     */
    currentUserId(callback: CurrentUserIdCallback) {
    }

    /**
     * The current user's account (including profile if set)
     *
     * @web
     *
     * @param callback Callback that will be invoked with the user's account
     */
    currentAccount(callback: CurrentAccountCallback) {
    }

    /**
     * The environment (one of local, test, staging, production)
     *
     * @web
     * @cloud
     * @android
     * @ios
     *
     * @param callback Callback that will be invoked with the current environment
     */
    environment(callback: EnvironmentCallback) {
    }

    /**
     * Show an alert
     *
     * @web
     * @android
     * @ios
     *
     * @param message Message to show in alert
     * @param title Title only used on mobile
     * @param config
     */
    showAlert(message: string, title?: string, config?: {duration: number}) {
        throwOverride(arguments.callee["name"]);
    }

    /**
     * Shows a dialog that can only be closed by clicking either the "yes" or "no" button
     *
     * @web
     * @android
     * @ios
     *
     * @param question
     * @param title The title shown on mobile
     * @param yesCallback The Callback that is called when the yes button is clicked
     * @param noCallback The Callback that is called when the no button is clicked
     */
    showYesNoQuestion(question: string, title: string, yesCallback: () => void, noCallback: () => void) {

    }

    /**
     * Shows a dialog that can only be closed by clicking on of the provided buttons
     *
     * @web
     * @android
     * @ios
     *
     * @param question
     * @param title The title shown on mobile
     * @param buttons
     */
    showQuestion(question: string, title: string, buttons: { text: string, callback: () => void }[]) {

    }

    /**
     * Show a Snackbar
     *
     * @web
     * @android
     * @ios
     *
     * @param message Title Message
     * @param label Label to show
     * @param config Optional config object to configure the snackbar (only used on web)
     */
    showSnackbar(message: string, label?: string, config?: any) {
    };

    /**
     * Navigate to a specific URL
     *
     * @web
     *
     * @param args List of paths to navigate to
     */
    navigate(...args: any[]) {
    }

    /**
     * Opens a URL
     *
     * @web
     * @android
     * @ios
     *
     * @param url URL to navigate to
     * @param newWindow whether to open in new window (defaults to true)
     */
    openUrl(url: string, newWindow = true) {

    }

    /**
     * Returns a generated uuid
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param callback
     */
    uuid(callback: ApiCallback<string>) {

    }

    forms: Forms = new Forms();

    objects: Objects = new Objects();

    relationships: Relationships = new Relationships();

    questions: Questions = new Questions();

    push: Push = new Push();

    pdf: Pdf = new Pdf();

    email: Email = new Email();

    workflows: Workflows = new Workflows();

    users: Users = new Users();

    location: Location = new Location();

    http: Http = new Http();

    nfc: Nfc = new Nfc();

    working: Working = new Working();

    libraries = new Libraries();

    /**
     * Util APIs
     */
    util = {
        files: new FilesUtil()
    }

    /**
     * Design APIs
     */
    design = new Design();
}

/**
 * Callback function invoked by WorkEngine with the user's ID
 *
 * @param userId Current User ID
 */
type CurrentUserIdCallback = (error: Error | any | null, userId: number) => void;

/**
 * Callback function invoked by WorkEngine with the user's ID
 *
 * @param userId Current User ID
 */
type CurrentAccountCallback = (error: Error | any | null, user: User) => void;

/**
 * Callback function invoked by WorkEngine with the user's current Auth Token
 *
 * @param authToken Current WorkEngine Auth Token
 */
type AuthTokenCallback = (error: Error | any | null, authToken: string) => void;

/**
 * Callback function invoked by WorkEngine with the current environment
 *
 * @param environment local, test, staging or production
 */
type EnvironmentCallback = (error: Error | any | null, environment: string) => void;
