import {Field} from "./Fields";
import {ApiCallback, DomainPaginationResponse} from "../../api";

/**
 * Manage Groups
 */
export class Groups {
    /**
     * Create a group
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param group
     * @param callback
     */
    create(objectDefinitionId: number, group: Group, callback: ApiCallback<Group>) {
    }

    /**
     * Get a group
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param idOrUuid
     * @param callback
     */
    get(objectDefinitionId: number, idOrUuid: number | string, callback: ApiCallback<Group>) {
    }

    /**
     * Update a group
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param group
     * @param callback
     */
    update(objectDefinitionId: number, group: Group, callback: ApiCallback<Group>) {
    }

    /**
     * Delete a group
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param idOrUuid
     * @param callback
     */
    delete(objectDefinitionId: number, idOrUuid: number | string, callback: ApiCallback<boolean>) {
    }

    /**
     * List all groups for an object definition
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param page
     * @param callback
     */
    list(objectDefinitionId: number, page: number, callback: ApiCallback<DomainPaginationResponse<Group>>) {
    }

    /**
     * Get all groups for an object definition
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param callback
     */
    all(objectDefinitionId: number, callback: ApiCallback<Group[]>) {
    }
}

export interface Group {
    fields: Field[],
    id?: number,
    objectDefinitionId?: number,
    name?: string,
    position?: number,
    createdAt?: Date,
    updatedAt?: Date
}
