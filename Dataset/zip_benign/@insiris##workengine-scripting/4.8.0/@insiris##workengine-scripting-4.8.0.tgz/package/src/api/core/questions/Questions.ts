import {ApiCallback} from "../../api";
import {DataSource, DataSources} from "./DataSources";

/**
 * Ask Questions through the question builder
 */
export class Questions {

    /**
     * Manage data sources for a question
     */
    dataSources = new DataSources();

    /**
     * Returns a question builder
     *
     * @cloud
     * @web
     *
     * @param dataSource Build with DataSourceBuilder
     * @param rowLimit
     */
    builder(dataSource: DataSource, rowLimit?: number): QuestionBuilder {
        return new QuestionBuilder(dataSource, rowLimit);
    }

    /**
     * Ask a Question
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param question Question to ask
     * @param page Page Number
     * @param perPage Number of results per page
     * @param callback Callback to invoke on complete/error
     */
    ask(question: QuestionApi | Question, page: number, perPage: number, callback: ApiCallback<AnswerApi | Answer>) {
    }

    /**
     * Ask a Question by ID
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param questionIdOrIdentifier The id or identifier of the question to ask
     * @param page Page Number
     * @param perPage Number of results per page
     * @param filters A map of filter identifier to array of values
     * @param callback Callback to invoke on complete/error
     */
    askById(questionIdOrIdentifier: number | string, page: number, perPage: number, filters: Map<string, any[]>, callback: ApiCallback<AnswerApi>) {
    }

    /**
     * Count number of results in a WorkEngine Question
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @remarks
     *
     * Note that when counting, the results are provided in the Answer object, in the data array - it will have one row, one column, which is the count
     *
     * @param question Question to ask
     * @param callback Callback to invoke on complete/error
     */
    count(question: QuestionApi, callback: ApiCallback<AnswerApi>) {
    }

    /**
     * Count number of results in a Question by Id
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @remarks
     *
     * Note that when counting, the results are provided in teh Answer object, in the data array - it will have one row, one column, which is the count
     *
     * @param questionIdOrIdentifier The id or identifier of the question to ask
     * @param filters A map of filter identifier to array of values
     * @param callback Callback function invoked by WorkEngine in response to a Question
     */
    countById(questionIdOrIdentifier: number | string, filters: Map<string, any[]>, callback: ApiCallback<AnswerApi>) {
    }

}

export enum DataSourceType {
    Object = 'DataSources::ObjectDataSource',
    Relationship = 'DataSources::RelationshipDataSource',
    HistoricalStatus = 'DataSources::HistoricalStatusDataSource',
}

export type FilterGroupOperator = 'and' | 'or';

class QuestionBuilder {

    constructor(dataSource: DataSource, rowLimit?: number) {
    }

    /**
     * Build a question from the builder
     *
     * @cloud
     * @web
     *
     */
    build(): Question {
        return new Question();
    }

    /**
     * Add a new filter group to the question being built
     *
     * @cloud
     * @web
     *
     * @param filterOperator
     * @param previousOperator
     */
    addFilterGroup(filterOperator: FilterGroupOperator, previousOperator: FilterGroupOperator = 'and'): QuestionBuilder {
        return this;
    }

}


export interface QuestionApi {
    /**
     * List of Filter Groups
     */
    filter_groups?: FilterGroupApi[];
    /**
     * Root data source the question runs on
     */
    data_source: DataSourceApi;
    /**
     * Used when saving a question - not required for scripting (pass an empty array)
     */
    visualisations?: any[];
}

export interface FilterGroupApi {
    /**
     * Always pass null
     */
    id?: number;
    /**
     * Always pass null
     */
    question_id?: number;
    /**
     * Previous operator (one of 'OR' or 'AND' for merging filter groups together
     */
    previous_operator?: 'OR' | 'AND' | 'or' | 'and';
    /**
     * This filter operator
     */
    filter_operator?: 'OR' | 'AND' | 'or' | 'and';
    /**
     * Position of filter group
     */
    position?: number;
}

export interface DataSourceApi {
    /**
     * Child Data Sources
     */
    children?: DataSourceApi[];
    /**
     * Columns to show in Answer
     */
    data_source_columns?: DataSourceFieldApi[];
    /**
     * Aggregations for the Question
     */
    aggregations?: DataSourceFieldApi[];
    /**
     * Breakuts for the Question
     */
    breakouts?: DataSourceFieldApi[];
    /**
     * Filters for the Question
     */
    filters?: FilterApi[];
    /**
     * Always pass null
     */
    id?: number;
    /**
     * Always pass null
     */
    question_id?: number;
    /**
     * Always pass null
     */
    parent_id?: number;
    /**
     * The type of the data source
     */
    type: DataSourceType;
    /**
     * Always pass null
     */
    instance_id?: number;
    /**
     * Object definition identifier or Relationship definition identifier
     */
    instance_identifier?: string;
    /**
     * Always pass null
     */
    created_at?: string;
    /**
     * Always pass null
     */
    updated_at?: string;
    /**
     * If this is joining on another data source, whether this is an INNER or OUTER join
     * Defaults to 'inner'
     */
    join_type?: string;
}

export interface FilterApi {
    /**
     * Always pass null
     */
    id?: number;
    /**
     * Always pass null
     */
    data_source_id?: number;
    /**
     * Always pass null
     */
    control_id?: number;
    /**
     * ID of the field (if this filter is not core)
     */
    field_id?: number;
    /**
     * Field identifier, including core field identifiers
     */
    field_identifier?: string;
    /**
     * Always pass null
     */
    filter_group_id?: number;
    /**
     * Which filter group this filter belongs to
     */
    filter_group_position: number;
    /**
     * Values array for filter
     */
    values: any[];
    /**
     * Type of Filter
     */
    type: string;
    /**
     * Options for filter
     */
    options?: any;
    /**
     * Identifier of field this filter is for, when core
     */
    core_field_identifier?: string;
    /**
     * Always pass null
     */
    created_at?: string;
    /**
     * Always pass null
     */
    updated_at?: string;
}

export enum BreakoutType {
    Simple = 'DataSourceFields::Breakout::Simple',
    Minute = 'DataSourceFields::Breakout::Minute',
    Hour = 'DataSourceFields::Breakout::Hour',
    Day = 'DataSourceFields::Breakout::Day',
    Week = 'DataSourceFields::Breakout::Week',
    Month = 'DataSourceFields::Breakout::Month',
    Quarter = 'DataSourceFields::Breakout::Quarter',
    Year = 'DataSourceFields::Breakout::Year',
    MinuteOfHour = 'DataSourceFields::Breakout::MinuteOfHour',
    HourOfDay = 'DataSourceFields::Breakout::HourOfDay',
    DayOfWeek = 'DataSourceFields::Breakout::DayOfWeek',
    DayOfMonth = 'DataSourceFields::Breakout::DayOfMonth',
    DayOfYear = 'DataSourceFields::Breakout::DayOfYear',
    WeekOfYear = 'DataSourceFields::Breakout::WeekOfYear',
    MonthOfYear = 'DataSourceFields::Breakout::MonthOfYear',
    QuarterOfYear = 'DataSourceFields::Breakout::QuarterOfYear',
}

export enum DataSourceColumnType {
    Column = "DataSourceFields::Column",
    Scripting = "DataSourceFields::Column::Scripting",
}

export enum AggregationType {
    Count = "DataSourceFields::Aggregation::Count",
    Sum = "DataSourceFields::Aggregation::Sum",
    Avg = "DataSourceFields::Aggregation::Avg",
    Distinct = "DataSourceFields::Aggregation::Distinct",
    Stddev = "DataSourceFields::Aggregation::Stddev",
    Min = "DataSourceFields::Aggregation::Min",
    Max = "DataSourceFields::Aggregation::Max"
}

export interface DataSourceFieldApi {
    sort?: SortApi;
    /**
     * Always pass null
     */
    id?: number;
    /**
     * Always pass null
     */
    data_source_id?: number;
    /**
     * Field this Data Source Field points at (when not core)
     * Use field_identifier instead
     */
    field_id?: number;
    /**
     * Field identifier, including core field identifiers
     * Should be used in place of field_id and core_field_identifier
     */
    field_identifier?: string;
    /**
     * Identifier of field this is for, when core
     * Use field_identifier instead
     */
    core_field_identifier?: string;
    /**
     * Type of field
     */
    type: BreakoutType | DataSourceColumnType | AggregationType;
    /**
     * Always pass null
     */
    created_at?: string;
    /**
     * Always pass null
     */
    updated_at?: string;
    /**
     * Unique identifier for this field (used in the Answer Columns)
     */
    guid: string;
}

export interface SortApi {
    /**
     * Always pass null
     */
    id?: number;
    /**
     * Always pass null
     */
    data_source_field_id?: number;
    /**
     * Whether to sort results by this field ASC or DESC
     */
    direction: 'ASC' | 'DESC';
    /**
     * Always pass null
     */
    created_at?: string;
    /**
     * Always pass null
     */
    updated_at?: string;
}

// Answer interfaces
export interface AnswerApi {
    /**
     * Original Question asked
     */
    question: QuestionApi;

    /**
     * List of Columns for Data
     */
    columns: AnswerColumnApi[];

    /**
     * Data array - a row of columns
     */
    data: any[][];
}

export interface AnswerColumnApi {
    guid: string;
    label: string;
    type: string;
    object_definition_identifier: string;
    core_field_identifier?: string;
}


// Domain objects
export class Question {
    /**
     * List of Filter Groups
     */
    filterGroups?: FilterGroup[];
    /**
     * Root data source the question runs on
     */
    dataSource: DataSource = new DataSource();
    /**
     * Used when saving a question - not required for scripting (pass an empty array)
     */
    visualisations?: any[];
}

export interface FilterGroup {
    /**
     * Always pass null
     */
    id?: number;
    /**
     * Always pass null
     */
    questionId?: number;
    /**
     * Previous operator (one of 'OR' or 'AND' for merging filter groups together
     */
    previousOperator?: 'OR' | 'AND' | 'or' | 'and';
    /**
     * This filter operator
     */
    filterOperator?: 'OR' | 'AND' | 'or' | 'and';
    /**
     * Position of filter group
     */
    position?: number;
}

export interface Filter {
    /**
     * Always pass null
     */
    id?: number;
    /**
     * Always pass null
     */
    dataSourceId?: number;
    /**
     * Always pass null
     */
    controlId?: number;
    /**
     * ID of the field (if this filter is not core)
     */
    fieldId?: number;
    /**
     * Field identifier, including core field identifiers
     */
    fieldIdentifier?: string;
    /**
     * Always pass null
     */
    filterGroupId?: number;
    /**
     * Which filter group this filter belongs to
     */
    filterGroupPosition: number;
    /**
     * Values array for filter
     */
    values: any[];
    /**
     * Type of Filter
     */
    type: FilterType;
    /**
     * Options for filter
     */
    options?: any;
    /**
     * Identifier of field this filter is for, when core
     */
    coreFieldIdentifier?: string;
    /**
     * Always pass null
     */
    createdAt?: Date;
    /**
     * Always pass null
     */
    updatedAt?: Date;
}

export interface DataSourceField {
    sort?: Sort;
    /**
     * Always pass null
     */
    id?: number;
    /**
     * Always pass null
     */
    dataSourceId?: number;
    /**
     * Field this Data Source Field points at (when not core)
     * @deprecated Use field_identifier instead
     */
    fieldId?: number;
    /**
     * Field identifier, including core field identifiers
     * Should be used in place of field_id and core_field_identifier
     */
    fieldIdentifier?: string;
    /**
     * Identifier of field this is for, when core
     * @deprecated Use field_identifier instead
     */
    coreFieldIdentifier?: string;
    /**
     * Type of field
     */
    type: string;
    /**
     * Always pass null
     */
    createdAt?: Date;
    /**
     * Always pass null
     */
    updatedAt?: Date;
    /**
     * Unique identifier for this field (used in the Answer Columns)
     */
    guid: string;
}

export interface Sort {
    /**
     * Always pass null
     */
    id?: number;
    /**
     * Always pass null
     */
    dataSourceFieldId?: number;
    /**
     * Whether to sort results by this field ASC or DESC
     */
    direction: 'ASC' | 'DESC';
    /**
     * Always pass null
     */
    createdAt?: Date;
    /**
     * Always pass null
     */
    updatedAt?: Date;
}

// Answer interfaces
export interface Answer {
    /**
     * Original Question asked
     */
    question: Question;

    /**
     * List of Columns for Data
     */
    columns: AnswerColumn[];

    /**
     * Data array - a row of columns
     */
    data: any[][];
}

export interface AnswerColumn {
    guid: string;
    label: string;
    type: string;
    objectDefinitionIdentifier: string;
    coreFieldIdentifier?: string;
    settings?: any;
}

export enum FilterType {
    // All
    IsEmpty = "Filters::IsEmpty",
    IsNotEmpty = "Filters::IsNotEmpty",

    // Text
    TextIs = "Filters::Text::Is",
    TextIsNot = "Filters::Text::IsNot",
    TextContains = "Filters::Text::Contains",
    TextDoesNotContain = "Filters::Text::DoesNotContain",
    TextStartsWith = "Filters::Text::StartsWith",
    TextEndsWith = "Filters::Text::EndsWith",

    // Numeric
    NumericEq = "Filters::Numeric::Eq",
    NumericNotEq = "Filters::Numeric::NotEq",
    NumericGt = "Filters::Numeric::Gt",
    NumericLt = "Filters::Numeric::Lt",
    NumericBetween = "Filters::Numeric::Between",
    NumericGtEq = "Filters::Numeric::GtEq",
    NumericLtEq = "Filters::Numeric::LtEq",

    // Boolean
    BooleanIs = "Filters::Boolean::Is",

    // Datetime
    DatetimePrevious = "Filters::Datetime::Previous",
    DatetimeNext = "Filters::Datetime::Next",
    DatetimeCurrent = "Filters::Datetime::Current",
    DatetimeBefore = "Filters::Datetime::Before",
    DatetimeAfter = "Filters::Datetime::After",
    DatetimeOn = "Filters::Datetime::On",
    DatetimeBetween = "Filters::Datetime::Between",

    // Status
    StatusIs = "Filters::Status::Is",
    StatusIsNot = "Filters::Status::IsNot",

    // Users
    UsersAny = "Filters::Users::Any",

    // Groups
    GroupsIs = "Filters::Groups::Is",
    GroupsIsNot = "Filters::Groups::IsNot",
}
