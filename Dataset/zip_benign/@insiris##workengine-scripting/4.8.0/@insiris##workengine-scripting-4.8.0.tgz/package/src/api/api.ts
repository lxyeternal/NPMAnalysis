/**
 * This is the root Api interface to which Scripts can invoke WorkEngine Scripting functions.
 */
import {Core} from "./core/Core";
import {AddOns} from "./addons/AddOns";
import {Async, Logger} from "./scripting-functions";

export type HashMap<k extends number | string, v> = { [key in k]: v };
export type ApiCallback<T> = (error: Error | any | null, result?: T) => void;

export class DomainPaginationResponse<D> {
    constructor(
        public items: D[],
        public page = 1,
        public perPage = 25,
        public totalCount = 0,
    ) {
    }
}

export class Api {
    /**
     * The current environment that this script is running under
     *
     * @web
     * @cloud
     *
     * @remarks
     *
     * A WorkEngine Script can be run under "test", "staging" or "production" environments.  You can use this to change constants and other settings dependent upon the environment being utilised
     */
    environment: string = 'test';

    /**
     * See the global 'scripts' object - it is the same here
     *
     * @web
     * @cloud
     * @ios
     * @android
     */
    scripts: HashMap<string, any> = {};

    /**
     * See the global 'apis' object - it is the same here
     *
     * @web
     * @cloud
     */
    apis: HashMap<string, any> = {};

    /**
     * All WorkEngine core functions are accessed through this namespace. Core namespaces include functions for managing objects, forms and other core features
     */
    core: Core = new Core();

    /**
     * Add Ons are able to attach additional scripting functions through the addOns namespace
     *
     * @web
     * @cloud
     *
     */
    addOns: AddOns = new AddOns();

}

/**
 * This is the WorkEngine Scripting API which is an instance of the root API class defined by this API.
 *
 * @web
 * @cloud
 * @android
 * @ios
 *
 */
export var api: Api = new Api();

/**
 * Holds all of your scripts that have been added to the current context.  You can reference these scripts as a regular javascript object using dot notation or string indexes.
 *
 * @web
 * @cloud
 * @android
 * @ios
 *
 * @remarks
 *
 * It is recommended that you access Scripts using lookup notation as WorkEngine adds your scripts using the 'identifier' you specify in WorkEngine. If you put dots in your Script identifier
 * therefore you will get an error.  Note that the direct accessing of scripts is discouraged and you should use require function instead
 *
 *
 * ```javascript
 * scripts["mymodule/MyScript.js"].myFunction()
 * ```
 */
export var scripts: HashMap<string, any>;

/**
 * Holds all the named contexts/APIs currently running inside scripting.
 *
 * @web
 *
 * @remarks
 *
 * Note that multiple contexts is currently only supported when running WorkEngine scripts in the Web App!
 */
export var apis: HashMap<string, Api>;

/**
 * Global Require function
 *
 * @web
 * @cloud
 * @android
 * @ios
 *
 *  @param scriptPath Path to the script - you can omit .js and the loader will add it for you
 * @returns the script
 */
// @ts-ignore
export var require: (scriptPath: string) => void;

/**
 * Utility methods for running async functions
 *
 * @web
 * @cloud
 * @android
 * @ios
 */
export var async: Async;

/**
 * Global logger
 *
 * @web
 * @cloud
 * @android
 * @ios
 */
export var logger = new Logger();

/**
 * The current environment scripting is running under. This will be one of
 * * local
 * * test
 * * staging
 * * production
 */
export var environment: string;
