import {ApiCallback, DomainPaginationResponse} from "../../api";

/**
 * Manage Fields
 */
export class Fields {
    /**
     * Create a field
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param groupId
     * @param field
     * @param callback
     */
    create(objectDefinitionId: number, groupId: number, field: Field, callback: ApiCallback<Field>) {
    }

    /**
     * Get a field
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param groupId
     * @param idOrUuid
     * @param callback
     */
    get(objectDefinitionId: number, groupId: number, idOrUuid: number | string, callback: ApiCallback<Field>) {
    }

    /**
     * Update a field
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param groupId
     * @param field
     * @param callback
     */
    update(objectDefinitionId: number, groupId: number, field: Field, callback: ApiCallback<Field>) {
    }

    /**
     * Delete a field
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param groupId
     * @param idOrUuid
     * @param callback
     */
    delete(objectDefinitionId: number, groupId: number, idOrUuid: number | string, callback: ApiCallback<boolean>) {
    }

    /**
     * List all fields for a group
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param groupId
     * @param page
     * @param callback
     */
    list(objectDefinitionId: number, groupId: number, page: number, callback: ApiCallback<DomainPaginationResponse<Field>>) {
    }

    /**
     * Get all fields for a group
     *
     * @cloud
     * @web
     *
     * @param objectDefinitionId
     * @param groupId
     * @param callback
     */
    all(objectDefinitionId: number, groupId: number, callback: ApiCallback<Field[]>) {
    }
}

export interface Field {
    id?: number,
    groupId?: number,
    name?: string,
    identifier?: string,
    typ3?: string,
    description?: string,
    mandatory?: boolean,
    migrated?: boolean,
    unique?: boolean,
    createdAt?: Date,
    updatedAt?: Date,
}
