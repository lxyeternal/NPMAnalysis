import {Answer} from "../questions/Questions";
import {ApiCallback} from "../../api";

/**
 * Manage the current active visualisation
 */
export class Visualisation {

    /**
     * Returns the current visualisation
     *
     * @web
     * @android
     * @ios
     *
     * @param callback
     */
    getVisualisation(callback: ApiCallback<VisualisationDomain>) {

    }

    /**
     * Sets the current visualisation's answer and runs the onAnswer callback
     *
     * @web
     * @android
     * @ios
     *
     * @param answer
     */
    setAnswer(answer: Answer) {

    }

}

class VisualisationDomain {
    constructor(
        public id?: number,
        public name?: string,
        public questionId?: number,
        public type?: string,
        public settings?: {},
        public objectDefinitionId?: number,
        public icon?: string,
        public createFormId?: number,
        public drillDownQuestionId?: number,
        public createdAt?: Date,
        public updatedAt?: Date,
    ) {
    }
}
