/**
 * Buffer from browser/node
 */
interface Buffer {
}

/**
 * Files Util
 */
export class FilesUtil {

    /**
     * Downloads a URL and returns the result as a Buffer
     *
     * @cloud
     * @web
     *
     * @param url URL to get
     * @param callback Callback to invoke on complete/error
     */
    urlToBuffer(url: string, callback: (error: Error | any | null, response: Buffer) => void) {
    }

    /**
     * Converts a buffer into a base64 encoded string
     *
     * @cloud
     * @web
     *
     * @param buffer Buffer to encode
     * @param callback Callback to invoke on complete/error
     */
    bufferToBase64(buffer: Buffer, callback: (error: Error | any | null, response: string) => void) {
    }

    /**
     * Converts a base64 string into a Data URI
     *
     * @cloud
     * @web
     *
     * @param base64String String to encode
     * @param mimeType Mime type for Data URI
     * @param callback Callback to invoke on complete/error
     */
    base64StringToDataUri(base64String: string, mimeType: string, callback: (error: Error | any | null, response: string) => void) {

    }

}
