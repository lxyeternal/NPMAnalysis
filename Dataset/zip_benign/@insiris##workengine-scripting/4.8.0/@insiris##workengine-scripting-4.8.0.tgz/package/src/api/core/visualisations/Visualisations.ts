import {Visualisation} from "./Visualisation";

/**
 * Get access to the current active visualisation
 */
export class Visualisations {
    /**
     * Manage the currently active visualisation
     *
     * @web
     * @android
     * @ios
     */
    visualisation: Visualisation = new Visualisation();
}
