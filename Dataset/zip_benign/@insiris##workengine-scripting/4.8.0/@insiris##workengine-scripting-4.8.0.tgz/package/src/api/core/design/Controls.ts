import {ApiCallback, DomainPaginationResponse} from "../../api";

/**
 * Manage Controls
 */
export class Controls {
    /**
     * Creates a control for a card for a page for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param pageId
     * @param cardId
     * @param control
     * @param callback
     */
    create(formId: number, pageId: number, cardId: number, control: any, callback: ApiCallback<Control>) {
    }

    /**
     * Gets a control for a card for a page for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param pageId
     * @param cardId
     * @param idOrUuid
     * @param callback
     */
    get(formId: number, pageId: number, cardId: number, idOrUuid: number | string, callback: ApiCallback<Control>) {
    }

    /**
     * Updates a control for a card for a page for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param pageId
     * @param cardId
     * @param control
     * @param callback
     */
    update(formId: number, pageId: number, cardId: number, control: any, callback: ApiCallback<Control>) {
    }

    /**
     * Deletes a control for a card for a page for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param pageId
     * @param cardId
     * @param idOrUuid
     * @param callback
     */
    delete(formId: number, pageId: number, cardId: number, idOrUuid: number | string, callback: ApiCallback<boolean>) {
    }

    /**
     * Lists controls for a card for a page for a form
     *
     * @cloud
     * @web
     *
     * @param formId
     * @param pageId
     * @param cardId
     * @param page
     * @param callback
     */
    list(formId: number, pageId: number, cardId: number, page: number, callback: ApiCallback<DomainPaginationResponse<Control>>) {
    }
}

export interface Control {
    id?: number;
    cardId?: number;
    fieldId?: number;
    name?: string;
    identifier?: string;
    label?: string;
    type?: string;
    binding?: string;
    defaultDataType?: string;
    position?: number;
    createdAt?: Date;
    updatedAt?: Date;

    settings: any;

}
