import {ApiCallback, DomainPaginationResponse} from "../../api";
import {Page} from "./Pages";

/**
 * Manage Forms
 */
export class Forms {
    /**
     * Creates a form
     *
     * @cloud
     * @web
     *
     * @param form
     * @param callback
     */
    create(form: Form, callback: ApiCallback<Form>) {
    }

    /**
     * Gets a form
     *
     * @cloud
     * @web
     *
     * @param idOrUuid
     * @param callback
     */
    get(idOrUuid: number | string, callback: ApiCallback<Form>) {
    }

    /**
     * Updates a form
     *
     * @cloud
     * @web
     *
     * @param form
     * @param callback
     */
    update(form: any, callback: ApiCallback<Form>) {
    }

    /**
     * Deletes a form
     *
     * @cloud
     * @web
     *
     * @param idOrUuid
     * @param callback
     */
    delete(idOrUuid: number | string, callback: ApiCallback<boolean>) {
    }

    /**
     * Lists forms
     *
     * @cloud
     * @web
     *
     * @param page
     * @param objectDefinitionIdOrIdentifier
     * @param callback
     */
    list(page: number, objectDefinitionIdOrIdentifier: number | string, callback: ApiCallback<DomainPaginationResponse<Form>>) {
    }
}

interface Form {
    pages: Page[];

    id?: number;
    organisationId?: number;
    userId?: number;
    name?: string;
    objectDefinitionId?: number;
    identifier?: string;
    settings?: FormSettings;
    localRemoteMode?: string;
    createdAt?: Date;
    updatedAt?: Date;

}

export class FormSettings {
    constructor(
        public visibleItems: string[] = [],
        public hideSaveButton: boolean = false,
        public hidePageSelector: boolean = false,
        public disableDraftMode: boolean = false,
    ) {
    }
}
