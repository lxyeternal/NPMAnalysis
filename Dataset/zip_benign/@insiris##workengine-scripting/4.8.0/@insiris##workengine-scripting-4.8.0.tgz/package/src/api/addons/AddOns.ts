import {Schedulers} from "./Schedulers";
import {Maps} from "./Maps";
import {Esignature} from "./Esignature";

export class AddOns {

    schedulers: Schedulers = new Schedulers();

    /**
     * Manage the Maps Add On
     *
     * @web
     *
     */
    maps: Maps = new Maps();


    /**
     * Create Signing Requests
     *
     * @web
     * @cloud
     *
     */
    esignature: Esignature = new Esignature();
}

/**
 * Manage the Toolbar used by different Add Ons
 */
export class AddOnsToolbar {
    /**
     * Sets the toolbar visibility
     *
     * @web
     *
     * @param visible Whether the toolbar is visible
     */
    public setVisible(visible: boolean) {
    }

    /**
     * Sets the CSS style for the toolbar
     *
     * @web
     *
     * @param style CSS e.g. border-bottom: 1px solid; color: red
     */
    public setStyle(style: string) {
    }

    /**
     * Sets the color of the toolbar
     *
     * @web
     *
     * @param color Color of toolbar in Hex string e.g. #EFEFEF
     */
    public setColor(color: string) {
    }

    /**
     * Sets the items shown in the toolbar
     *
     * @param items List of items to show in the toolbar
     * @param callback Callback that is invoked when all the items have been added and are displaced on screen
     */
    public setItems(items: ToolbarItem[], callback: () => void) {
    }

    /**
     * Update an item in the toolbar
     *
     * @param item Toolbar Item to update
     */
    public updateItem(item: ToolbarItem) {
    }
}

/**
 * This is used by the [[AddOnsToolbar]] when setting the items on a toolbar
 */
interface ToolbarItem {
    /**
     * The type of the toolbar item.
     *
     * @web
     *
     * @remarks
     *
     * The following are supported types
     *
     * * button
     * * combo
     * * datepicker
     * * label
     * * spacer (the shorthand '->' can also be used when setting up items)
     * * activityIndicator
     * * html
     */
    type: string;


    /**
     * The identifier of the item, for later referencing
     *
     * @web
     */
    identifier: string;

    /**
     * The colour of the item
     *
     * @web
     */
    colour: string;

    /**
     * The individual properties for the item
     *
     * @web
     *
     * @remarks
     *
     * The properties that are passed here are dependent upon the **type** of the item and are provided below.  Additionally, all items support a `hidden` property to hide them.
     */
    properties: ToolbarItemButtonProperties | ToolbarItemComboProperties | ToolbarItemDatepickerProperties | ToolbarItemLabelProperties | ToolbarItemHtmlProperties;
}

/**
 * Properties for the Button Toolbar Item
 */
interface ToolbarItemButtonProperties {
    /**
     * Title shown for the button
     */
    title: string;

    /**
     * Icon shown for the button - must be a material icon identifier
     */
    icon: string;

    /**
     * Callback handler invoked when the button is tapped
     */
    click: () => void;

    /**
     * Tooltip shown on hover
     */
    tooltip: string;

    /**
     * Controls whether the button is enabled or not
     */
    disabled: boolean;

    /**
     * Whether the button is hidden
     */
    hidden: boolean;
}

/**
 * Properties for the Combo Toolbar Item
 */
interface ToolbarItemComboProperties {
    /**
     * Placeholder text when a value is not provided
     */
    placeholder: string;

    /**
     * Current selected value
     */
    value: string;

    /**
     * Callback when the value changes
     * @param value New value
     * @param event Original event
     */
    onChange: (value: any, event: any) => void;

    /**
     * List of items to show
     */
    items: {
        value: any;
        display: any;
    }[]
}

/**
 * Represents a Moment from the moment library
 */

interface Moment {

}

/**
 * Properties for the Date Picker Toolbar Item
 */
interface ToolbarItemDatepickerProperties {
    /**
     * Placeholder text when a value is not provided
     */
    placeholder: string;

    /**
     * Icon shown for the button - must be a material icon identifier
     */
    icon: string;

    /**
     * Callback when the value changes
     * @param value New value - this is an instance of Moment
     * @param event Original event
     */
    onChange: (value: Moment, event: any) => void;

    /**
     * Date to start the picker at
     */
    startDate: Date;
}

/**
 * Properties for the Label Toolbar Item
 */
interface ToolbarItemLabelProperties {
    /**
     * Label text
     */
    title: string;

    /**
     * Icon shown for the icon - must be a material icon identifier
     */
    icon: string;
}

/**
 * Properties for the Html Toolbar Item
 */
interface ToolbarItemHtmlProperties {
    /**
     * HTML
     */
    html: string;
}
