/**
 * Send email from WorkEngine
 */
export class Email {

    /**
     * Send an email using the SendGrid library
     *
     * @cloud
     *
     * @remarks
     *
     * Currently, the underlying provider for sending emails is sendgrid.  The sendGridOptions that are passed are in need to provide
     * authentication details for the sendgrid account that will be used for sending
     *
     * @param sendGridOptions Sendgrid authentication options
     * @param message Email message to send
     * @param callback Callback that will be invoked
     */
    send(sendGridOptions: SendgridOptions, message: EmailMessage, callback: EmailApiCallback) {
    }

}

/**
 * Callback function invoked by WorkEngine when a call to the WorkEngine Email API succeeds or fails
 *
 * @param response Response
 */
type EmailApiCallback = (error: Error | any | null, response: any) => void;

interface EmailMessage {
    /**
     * Email recipients
     */
    to: string,
    /**
     * Address to send from
     */
    from: string,
    /**
     * Subject
     */
    subject: string,
    /**
     * Plain text for the email
     */
    text: string,
    /**
     * HTML for the email
     */
    html?: string,
    /**
     * List of attachments
     */
    attachments?: EmailAttachment[]
}


export interface EmailAttachment {
    /**
     * File Content as a Base64 encoded string (use api.core.util.files.bufferToBase64 to convert buffers into appropriate strings)
     */
    content: string;
    /**
     * Filename
     */
    filename: string;
    /**
     * File mime type
     */
    type: string;
    /**
     * Attachment disposition
     */
    disposition: string;
}

interface SendgridOptions {
    /**
     * API Key to use for sending via sendgrid
     */
    apiKey: string;
}
