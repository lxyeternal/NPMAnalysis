import {AggregationType, BreakoutType, DataSourceField, DataSourceType, Filter, FilterType} from "./Questions";

export class DataSources {

    /**
     * Returns a data source builder
     *
     * @cloud
     * @web
     *
     * @param instanceIdentifier
     * @param type
     * @param joinType
     */
    builder(
        instanceIdentifier: string,
        type: string = DataSourceType.Relationship,
        joinType: DataSourceJoinType = 'inner',
    ): DataSourceBuilder {
        return new DataSourceBuilder(instanceIdentifier, type, joinType);
    }
}

export type DataSourceJoinType = 'inner' | 'left';

class DataSourceBuilder {

    constructor(
        instanceIdentifier: string,
        type: string = DataSourceType.Relationship,
        joinType: DataSourceJoinType = 'inner',
    ) {
    }

    /**
     * Builds a data source
     *
     * @cloud
     * @web
     *
     */
    build(): DataSource {
        return new DataSource();
    }

    /**
     * Add a data source
     *
     * @cloud
     * @web
     *
     * @param dataSource
     */
    addDataSource(
        dataSource: DataSource,
    ): DataSourceBuilder {
        return this;
    }

    /**
     * Add an aggregation
     *
     * @cloud
     * @web
     *
     * @param dataSource
     */
    addAggregation(fieldIdentifier: string, type: AggregationType, guid?: string, sortDirection?: 'ASC' | 'DESC'): DataSourceBuilder {
        return this;
    }

    /**
     * Add a breakout
     *
     * @param fieldIdentifier
     * @param type
     * @param guid
     * @param sortDirection
     */
    addBreakout(fieldIdentifier: string, type: BreakoutType = BreakoutType.Simple, guid?: string, sortDirection?: 'ASC' | 'DESC'): DataSourceBuilder {
        return this;
    }

    /**
     * Add a column
     *
     * @cloud
     * @web
     *
     * @param dataSource
     */
    addColumn(fieldIdentifier: string, guid?: string, sortDirection?: 'ASC' | 'DESC'): DataSourceBuilder {
        return this;
    }

    /**
     * Add a filter
     *
     * @cloud
     * @web
     *
     * @param dataSource
     */
    addFilter(fieldIdentifier: string, type: FilterType, values: any[], filterGroupPosition: number = 1): DataSourceBuilder {
        return this;
    }

}

export class DataSource {
    /**
     * Child Data Sources
     */
    children?: DataSource[];
    /**
     * Columns to show in Answer
     */
    dataSourceColumns?: DataSourceField[];
    /**
     * Aggregations for the Question
     */
    aggregations?: DataSourceField[];
    /**
     * Breakuts for the Question
     */
    breakouts?: DataSourceField[];
    /**
     * Filters for the Question
     */
    filters?: Filter[];
    /**
     * Always pass null
     */
    id?: number;
    /**
     * Always pass null
     */
    questionId?: number;
    /**
     * Always pass null
     */
    parentId?: number;
    /**
     * The type of the data source
     */
    type: DataSourceType | null = null;
    /**
     * Always pass null
     */
    instanceId?: number;
    /**
     * Object definition identifier or Relationship definition identifier
     */
    instanceIdentifier?: string;
    /**
     * Always pass null
     */
    createdAt?: Date;
    /**
     * Always pass null
     */
    updatedAt?: Date;
    /**
     * If this is joining on another data source, whether this is an INNER or OUTER join
     * Defaults to 'inner'
     */
    joinType?: string;
}
