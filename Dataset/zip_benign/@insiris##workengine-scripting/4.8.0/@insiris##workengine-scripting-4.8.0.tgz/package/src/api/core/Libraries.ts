import djs = require("dayjs");
import duration = require("dayjs/plugin/duration");
import utc = require("dayjs/plugin/utc");
import {Storage} from "@google-cloud/storage";

djs.extend(duration);
djs.extend(utc);

/**
 * Provide useful libraries to scripting users
 */
export class Libraries {

    /**
     * Returns a dayjs object, extened with duration plugin and utc
     *
     * @web
     * @cloud
     */
    dayjs = djs;

    /**
     * Returns the google cloud storage library, allowing files to be fetched from buckets
     *
     * @cloud
     */
    googleCloudStorage = Storage;

}
