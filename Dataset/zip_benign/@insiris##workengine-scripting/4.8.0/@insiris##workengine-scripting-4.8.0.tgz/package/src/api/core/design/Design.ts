import {Controls} from "./Controls";
import {Cards} from "./Cards";
import {Pages} from "./Pages";
import {Forms} from "./Forms";
import {ScriptMemberships} from "./ScriptMemberships";
import {ObjectDefinitions} from "./ObjectDefinitions";
import { RelationshipDefinitions} from "./RelationshipDefinitions";
import {Fields} from "./Fields";
import {Groups} from "./Groups";

export class Design {
    forms: Forms = new Forms();
    pages: Pages = new Pages();
    cards: Cards = new Cards();
    controls: Controls = new Controls();
    objectDefinitions: ObjectDefinitions = new ObjectDefinitions();
    groups: Groups = new Groups();
    fields: Fields = new Fields();
    relationshipDefinitions:RelationshipDefinitions = new RelationshipDefinitions();
    scriptMembership: ScriptMemberships = new ScriptMemberships();
}
