/**
 * Make http requests
 */
import {AxiosRequestConfig} from "axios";

export class Http {

    /**
     * Make an HTTP Request
     *
     * @cloud
     *
     * @remarks
     *
     * Currently this call uses the axios http client, which is an axios request config object.
     *
     * @param config Http Config - see https://github.com/axios/axios#request-config
     * @param callback Callback to invoke on complete/error
     */
    request(config: AxiosRequestConfig, callback: HttpApiCallback) {
    }
}

/**
 * Callback function invoked by WorkEngine when a call to the WorkEngine HTTP API succeeds or fails
 *
 *
 * @param response Response from axios - see https://github.com/axios/axios#response-schema
 */
type HttpApiCallback = (error: Error | any | null, response: any) => void;
