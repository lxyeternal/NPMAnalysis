/**
 * Manage Objects
 */
import {Bulk} from "./Bulk";
import {ApiCallback, HashMap} from "../../api";

/**
 * Manage Objects
 */

export class Objects {

    /**
     * Modify objects in bulk
     *
     * @web
     * @cloud
     */
    bulk: Bulk = new Bulk();

    /**
     * Create a new WorkEngine Object
     *
     * @web
     * @cloud
     * @android
     * @ios
     *
     * @param object Object to create
     * @param objectIdentifier Type of object
     * @param callback Callback to invoke on complete/error
     */
    create<T extends WeObject>(object: T, objectIdentifier: string, callback: ApiCallback<T>) {
    }

    /**
     * Get an existing WorkEngine Object
     *
     * @web
     * @cloud
     * @android
     * @ios
     *
     * @param objectIdentifier Type of object
     * @param idOrUuid ID or UUID of object
     * @param callback Callback to invoke on complete/error
     */
    get(objectIdentifier: string, idOrUuid: number | string, callback: ApiCallback<WeObject>) {
    }

    /**
     * Update an existing WorkEngine Object
     *
     * @web
     * @cloud
     * @android
     * @ios
     *
     * @param object Object to update
     * @param objectIdentifier Type of object
     * @param callback Callback to invoke on complete/error
     */
    update<T extends WeObject>(object: T, objectIdentifier: string, callback: ApiCallback<T>) {
    }

    /**
     * Delete an existing WorkEngine Object
     *
     * @web
     * @cloud
     * @android
     * @ios
     *
     * @param objectIdentifier Type of object
     * @param idOrUuid ID or UUID of object
     * @param callback Callback to invoke on complete/error
     */
    delete(objectIdentifier: string, idOrUuid: number | string, callback: ApiCallback<boolean>) {
    }

    /**
     * Fetch all objects of a particular type
     *
     * @web
     * @cloud
     *
     * @remarks
     *
     * Note that this method can take a long time to return for large result sets. Only use where you know there are just a few pages (a few hundred) objects
     *
     * @param objectIdentifier Type of object
     * @param callback Callback to invoke on complete/error
     */
    all(objectIdentifier: string, callback: ApiCallback<WeObject[]>) {
    }

    /**
     * Transition an object from one status to another
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param objectIdentifier Type of object
     * @param object Used to set the status_id when using an 'all' transition
     * @param transitionIdOrIdentifier The ID or identifier of the transition being invoked
     * @param callback Callback to invoke on complete/error
     */
    transition(objectIdentifier: string, object: WeObject, transitionIdOrIdentifier: number | string, callback: ApiCallback<WeObject>) {
    }

    /**
     * Get the URL for a file from WorkEngine
     *
     * @web
     * @cloud
     * @ios
     * @android
     *
     * @param object Object to get the file for
     * @param objectIdentifier Type of object
     * @param fieldIdentifier Identifier for field to download
     * @param filename Filename of file to download
     * @param downloadAs Download name for file
     * @param callback Callback to invoke on complete/error
     */
    getFileUrl(object: WeObject, objectIdentifier: string, fieldIdentifier: string, filename: string, downloadAs: string, callback: GetFileUrlCallback) {
    }

    /**
     * Uploads a file to WorkEngine
     *
     * @web
     * @cloud
     *
     * @remarks
     *
     * Note that the returned response in the callback includes the information for the file, but this is not saved on the object.  It is up to the caller
     * to make a second call to post changes to the actual file field on the workengine object using the api.core.objects.update call to actually save the new information
     *
     * @param object Object to put the file for
     * @param objectIdentifier Type of object
     * @param fieldIdentifier Identifier for field to upload
     * @param fileData File data (buffer, file)
     * @param fileName Name of file
     * @param callback Callback to invoke on complete/error
     * @param overrideMimeType Used to override the files mime type
     */
    putFile(object: WeObject, objectIdentifier: string, fieldIdentifier: string, fileData: any, fileName: string, callback: PutFileCallback, overrideMimeType?: string) {
    }

}

/**
 * Callback function invoked by WorkEngine when a call to get a file URL succeeds
 *
 * @param url The authenticated URL to download the file from. Note this link expires after a few seconds
 */
type GetFileUrlCallback = (error: Error | any | null, url: string) => void;

/**
 * Callback function invoked by WorkEngine when a call to put a file succeeds
 *
 * @param response The File Upload Response
 */
type PutFileCallback = (error: Error | any | null, response: FileUploadResponse) => void;

interface FileUploadResponse {
    /**
     * Filename to send file up as
     */
    filename: string;
    /**
     * Download name for file
     */
    download_as: string;
    /**
     * Created at
     */
    created_at: string;
    /**
     * Mime type of file
     */
    mime_type: string;
    /**
     * Whether the file is temporary
     */
    temporary: boolean;
    /**
     * The authenticated URL to post the file to.  Note this link expires after a few seconds
     */
    url: string;
}
export type WeObject = HashMap<string, any> & { id?: number; uuid?: string };
