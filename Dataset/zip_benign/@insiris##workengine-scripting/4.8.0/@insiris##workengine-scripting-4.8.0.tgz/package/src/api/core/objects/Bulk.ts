import {ApiCallback, HashMap} from "../../api";

/**
 * Modify objects in bulk
 */
export class Bulk {

    /**
     * Create a Bulk Action Builder
     *
     * @web
     * @cloud
     *
     * @param errorStrategy the default error strategy, used if an action doesn't provide one
     */
    builder(errorStrategy: ErrorStrategy): BulkActionBuilder {
        return new BulkActionBuilder();
    }

    /**
     * Executes the bulk actions
     *
     * @web
     * @cloud
     *
     * @param bulkAction
     * @param callback Callback invoked on complete/error
     */
    synchronous(bulkAction: BulkAction, callback: ApiCallback<BulkResponse>): void {
    }

}

export class BulkActionBuilder {

    build(): BulkAction {
        return new BulkAction('abort');
    }

    /**
     * Adds an object create action
     *
     * @web
     * @cloud
     *
     * @param object Object to create
     * @param objectDefinitionIdentifier Type of object
     * @param errorStrategy Override the default error strategy
     * @param identifier Used to identify each action in the response
     * @param skipTriggers Skip triggers
     */
    addObjectCreateAction(
        object: HashMap<string, any>,
        objectDefinitionIdentifier: string,
        errorStrategy?: ErrorStrategy,
        identifier?: string,
        skipTriggers: boolean = false,
    ): BulkActionBuilder {
        return this;
    }

    addObjectUpdateAction(
        object: HashMap<string, any>,
        objectDefinitionIdentifier: string,
        errorStrategy?: ErrorStrategy,
        identifier?: string,
        skipTriggers: boolean = false,
    ): BulkActionBuilder {
        return this;
    }

    addObjectDestroyAction(
        idOrUuid: number | string,
        objectDefinitionIdentifier: string,
        errorStrategy?: ErrorStrategy,
        identifier?: string,
        skipTriggers: boolean = false,
    ): BulkActionBuilder {
        return this;
    }

    addObjectTransitionAction(
        idOrUuid: number | string,
        objectDefinitionIdentifier: string,
        transitionIdOrIdentifier: number | string,
        errorStrategy?: ErrorStrategy,
        identifier?: string,
        skipTriggers: boolean = false,
    ): BulkActionBuilder {
        return this;
    }

    addRelationshipCreateAction(
        objectIdOrUuid: number | string,
        objectIdentifier: string,
        foreignObjectIdOrUuid: number | string,
        relationshipIdentifier: string,
        errorStrategy?: ErrorStrategy,
        identifier?: string,
        skipTriggers: boolean = false,
    ): BulkActionBuilder {
        return this;
    }

    addRelationshipDestroyAction(
        objectIdOrUuid: number | string,
        objectIdentifier: string,
        foreignObjectIdOrUuid: number | string,
        relationshipIdentifier: string,
        errorStrategy?: ErrorStrategy,
        identifier?: string,
        skipTriggers: boolean = false,
    ): BulkActionBuilder {
        return this;
    }

}

export class BulkAction {
    constructor(
        public errorStrategy: ErrorStrategy,
        public actions: (ObjectAction | RelationshipAction)[] = [],
    ) {
    }
}

export type ObjectActionAction = 'create' | 'update' | 'destroy' | 'transition';

export interface ObjectAction {
    target: string;
    action: ObjectActionAction;
    params: HashMap<string, any>;
    data?: HashMap<string, any>;
    errorStrategy?: ErrorStrategy
    identifier?: string;
    skipTriggers?: boolean;

}

export type RelationshipActionAction = 'create' | 'destroy';

export interface RelationshipAction {
    target: string;

    action: RelationshipActionAction,
    params: HashMap<string, any>,
    errorStrategy?: ErrorStrategy,
    identifier?: string,
    skipTriggers?: boolean,

}

export type Code = 'success' | 'aborted';

export interface BulkResponse {
    code: Code;
    actions: ResponseAction[];
}

export type ResponseActionCode = 'success' | 'aborted' | 'fail';

export interface ResponseAction {
    identifier: string;
    code: ResponseActionCode;
    response: any;
}
export type ErrorStrategy = 'abort' | 'fail';
