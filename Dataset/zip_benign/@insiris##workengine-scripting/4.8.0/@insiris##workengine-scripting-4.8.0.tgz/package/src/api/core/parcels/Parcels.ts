import {ApiCallback, HashMap} from "../../api";
import {ParcelBuilder} from "./ParcelBuilder";

export class Parcels {

    /**
     * Creates a parcel
     *
     * @cloud
     * @web
     *
     * @param parcel
     * @param callback
     */
    create(parcel: Parcel, callback: ApiCallback<Parcel>) {
    }

    /**
     * Deletes a pending parcel, will error if the parcel has been dispatched
     *
     * @cloud
     * @web
     *
     * @param idOrIdentifier
     * @param callback
     */
    delete(idOrIdentifier: number | string, callback: ApiCallback<boolean>) {
    }

    /**
     * Returns a Parcel Builder
     *
     * @cloud
     * @web
     *
     * @param userId
     */
    builder(userId: number): ParcelBuilder {
        return new ParcelBuilder(userId);
    }

    /**
     * Sets a parcel's status to 'done'
     *
     * @cloud
     * @web
     * @ios
     * @android
     *
     * @param idOrIdentifier
     * @param callback
     */
    done(idOrIdentifier: number | string, callback: ApiCallback<any>) {
    }
}

export class Parcel {
    id?: number;
    name?: string;
    identifier?: string;
    description?: string;
    userId?: number;
    objects?: HashMap<string, string[]>;
    createdAt?: Date;
    updatedAt?: Date;
}
