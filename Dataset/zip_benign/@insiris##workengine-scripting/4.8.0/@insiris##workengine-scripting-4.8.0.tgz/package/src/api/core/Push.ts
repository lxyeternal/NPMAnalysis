/**
 * Manage the pushing of messages and data to WorkEngine users
 */
export class Push {

    /**
     * Push an object to a WorkEngine User
     *
     * @web
     * @cloud
     *
     * @param message Push message
     * @param callback Callback to invoke on complete/error
     */
    pushMessage(message: PushMessage, callback: PushApiCallback) {

    }
}

/**
 * Callback function invoked by WorkEngine when a call to the WorkEngine Push API succeeds or fails
 *
 * @remarks
 *
 * Note that response differs from platform to platform and is the raw underlying response from the networking library used on the platform.  This may change in the future and it is not advised you use this response in your Script.
 *
 * @param response Response
 */
type PushApiCallback = (error: Error | any | null, response: any) => void;

interface PushMessage {

    /**
     * Email or ID of user pushing message to
     */
    userIdOrEmail: string;

    /**
     * Type of message to send
     */
    type: "notification" | "upload_logs" | "sync";

    /**
     * Optional notification
     */
    notification: { title: string, body: string };

    /**
     * Whether to send the message as an alert or silent (in the background) - iOS Only
     */
    sendAs: "alert" | "background";

    /**
     * Any additional data to send in the message
     *
     * Current supported values:
     *
     * - sync
     *      forcePullData - used for sync to specify whether to force the pulling of data
     *      syncQuestion - specify the identifier of a single sync question to run
     */
    data?: { forcePullData?: boolean, syncQuestion?: String };
}
