/**
 * Generate Signing Requests via the API
 *
 * @web
 * @cloud
 *
 */
import {ApiCallback} from "../api";

export class Esignature {

    /**
     * Create a new Signing Request
     *
     * @web
     * @cloud
     *
     * @param signingFlowIdentifier Signing Flow Identifier
     * @param signingRequest Request to create
     * @param callback Callback on success
     */
    createSigningRequest(signingFlowIdentifier: string, signingRequest: SigningRequest, callback: ApiCallback<SigningRequest>) {
    }
}


interface SigningRequest {
    /**
     * Leave blank
     */
    id: number;
    /**
     * Unique ID for this request
     */
    uuid: string;
    /**
     * Name of the request
     */
    name: string;
    /**
     * Recipient Name
     */
    recipientName: string;
    /**
     * Recipient Email
     */
    recipientEmail: string;
    /**
     * Original Unsigned File (or use URL below)
     */
    originalFile: File;
    /**
     * Original Unsigned File URL (or use File Above)
     */
    originalFileUrl: string;
    /**
     * Status of signing request
     */
    status: string;
    /**
     * Expiry time
     */
    expiresAt: Date;
    /**
     * ID of Signing Flow
     */
    signingFlowId: number;
}
