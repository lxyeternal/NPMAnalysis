import {AddOnsToolbar} from "./AddOns";

/**
 * Manage the Maps Add On
 */
export class Maps {
    /**
     * Manage the currently active Map
     *
     * @web
     *
     */
    map: Map = new Map();
}
/**
 * Manage the currently active Map
 */
export class Map {

    /**
     * Manage the Toolbar used by the Map
     *
     * @web
     *
     */
    toolbar: AddOnsToolbar= new AddOnsToolbar();

    /**
     * Manage the Sidebar used by the Map
     *
     * @web
     */
    sidebar: MapSidebar = new MapSidebar();

    /**
     * Set the items shown on the map
     *
     * @web
     *
     */
    items: MapItem[] = [];

    /**
     * Center the Map
     *
     * @web
     *
     * @param latitude Latitude for map center, in decimal degrees
     * @param longitude Longitude for map center, in decimal degrees
     */
    setCenter(latitude: number, longitude: number) {
    }

    /**
     * Set the zoom level
     *
     * @web
     *
     * @param zoomLevel number from 0 to 15 representing the zoom level (0 being most zoomed out)
     */
    setZoom(zoomLevel: number) {
    }

    /**
     * Add an individual item to the map
     *
     * @web
     *
     * @param item Item to add
     */
    addItem(item: MapItem) {
    }

    /**
     * Remove an item from the map
     *
     * @web
     *
     * @param identifier Identifier of item to remove
     */
    removeItem(identifier: string) {
    }

    /**
     * Set the visibility of a map item
     *
     * @web
     *
     * @param identifier Identifier of item
     * @param visible Whether the item is visible
     */
    setItemVisibility(identifier: string, visible: boolean) {
    }

    /**
     * Set the visibility of a map item's popup
     *
     * @web
     *
     * @param identifier Identifier of item
     * @param visible Whether the item's popup is visible
     */
    setMapItemPopupVisibility(identifier: string, visible: boolean) {
    }

    /**
     * Sets the visibility of a set of map items, by groupIdentifier
     *
     * @web
     *
     * @remarks
     *
     * Map Items can be provided a property `groupIdentifier` (see [[MapItem]] and its properties). Items with the same groupIdentifier will have their visibility controller by this function.
     *
     * @param groupIdentifier Identifier of group
     * @param visible Whether the map items should be visible
     */
    setGroupVisibility(groupIdentifier: string, visible: boolean) {
    }

    /**
     * Update a Map Item's properties
     *
     * @web
     *
     * @param identifier Identifier of item
     * @param properties Properties
     */
    updateItem(identifier: string, properties: PointMapItemProperties | PolylineMapItemProperties | AreaMapItemProperties) {
    }
}

interface MapItem {
    /**
     * Type of map item
     *
     * @web
     *
     * @remarks
     *
     * The following are supported types:
     *
     * * point
     * * polyline
     * * area
     */
    type: string;

    /**
     * Identifier for the item
     *
     * @web
     */
    identifier: string;

    /**
     * The individual properties for the item
     *
     * @web
     *
     * @remarks
     *
     * The properties that are passed here are dependent upon the **type** of the item and are provided below.
     *
     * Additionally, all items support a `hidden` property to hide them, and a groupIdentifier for grouping and hiding items en masse.
     */
    properties: PointMapItemProperties | PolylineMapItemProperties | AreaMapItemProperties;
}

/**
 * Properties for the Point Map Item
 */
interface PointMapItemProperties {
    /**
     * Latitude of the point in decimal degrees
     */
    lat: number;

    /**
     * Longitude of the point in decimal degrees
     */
    lng: number;

    /**
     * URL for the icon
     */
    iconUrl: string;

    /**
     * Popup when clicking on the item
     */
    popup: MapPopupProperties;
}

/**
 * Properties for the Polyline Map Item
 */
interface PolylineMapItemProperties {
    /**
     * List of points in decimal degrees
     */
    points: [{
        lat: number,
        lng: number
    }];

    /**
     * Popup when clicking on the item
     */
    popup: MapPopupProperties;
}

/**
 * Properties for the Area Map Item
 */
interface AreaMapItemProperties {
    /**
     * List of points in decimal degrees
     */
    points: [{
        lat: number,
        lng: number
    }],

    /**
     * Whether this can be edited by the user (enter drawing mode)
     */
    editable: boolean,

    /**
     * Popup when clicking on the item
     */
    popup: MapPopupProperties;
}

interface MapPopupProperties {
    /**
     * Title for the popup
     */
    title: string;

    /**
     * HTML displayed within the popup
     */
    html: string;

    /**
     * List of actions the user can perform on the sidebar item
     */
    actions: MapPopupAction[];
    visible: boolean;
}

/**
 * Used to represent an Action for a Map Popup Item
 *
 * @web
 */
interface MapPopupAction {
    /**
     * Text displayed to the user for the action
     */
    text: string;

    /**
     * Function to invoke when a user selects the action
     */
    callback: () => void;
}

/**
 * Manage the Map Sidebar
 */
export class MapSidebar {

    /**
     * Sets the sidebar as visible or not
     *
     * @web
     *
     * @param visible Whether the sidebar should be visible
     */
    public setVisible(visible: boolean) {
    }

    /**
     * Sets the list of Sidebar Groups for the Map
     *
     * @web
     *
     * @param groups
     */
    public setGroups(groups: MapSidebarGroup[]) {
    }

    /**
     * Sets whether a sidebar group is visible or not
     *
     * @web
     *
     * @param identifier Identifier of the sidebar group
     * @param visible Whether the group should be visible
     */
    public setGroupVisibility(identifier: string, visible: boolean) {
    }

}

/**
 * Used to represent a Map Sidebar Group
 *
 * @web
 */
interface MapSidebarGroup {
    /**
     * Title of the group
     */
    title: string;

    /**
     * Identifier for the group
     */
    identifier: string;

    /**
     * List of items to show in sidebar
     */
    items: MapSidebarItem[];
}

/**
 * Used to represent a Map Sidebar Item
 *
 * @web
 */
interface MapSidebarItem {
    /**
     * HTML to render for item in sidebar
     */
    html: string;

    /**
     * List of actions the user can perform on the sidebar item
     */
    actions: MapSidebarAction[];
}

/**
 * Used to represent an Action for a Map Sidebar Item
 *
 * @web
 */
interface MapSidebarAction {
    /**
     * Text displayed to the user for the action
     */
    text: string;

    /**
     * Function to invoke when a user selects the action
     */
    callback: () => void;
}
