#!/bin/bash
set -e
set -x #echo on

sed -i -e "s/DOC_NAME/WorkEngine Scripting Docs - Built on $(date)/g" ./typedoc.json
npm run docs

# Download and install google cloud sdk
curl -o ./google-cloud-sdk.tar.gz -L https://dl.google.com/dl/cloudsdk/channels/rapid/downloads/google-cloud-sdk-228.0.0-linux-x86_64.tar.gz \
&& tar -xvf ./google-cloud-sdk.tar.gz && ./google-cloud-sdk/install.sh -q && source ./google-cloud-sdk/path.bash.inc

# Authenticate with gcloud
gcloud auth activate-service-account --key-file $1 --project insiris-test

#Build our command as a string
GSUTIL_COMMAND="gsutil -m cp -r docs/** gs://scripting.docs.insiris.com"

#Execute the string as a command
eval $GSUTIL_COMMAND
