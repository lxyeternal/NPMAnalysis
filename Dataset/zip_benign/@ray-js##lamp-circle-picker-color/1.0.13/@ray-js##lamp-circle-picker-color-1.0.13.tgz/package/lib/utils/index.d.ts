declare type HSL = {
    h: number;
    s: number;
    l: number;
};
export declare const rgbToHsv: (r: number, g: number, b: number) => HSV;
export declare const hsvToRgb: (h: number, s: number, v: number) => RGB;
export declare const rgbToHsl: (r: number, g: number, b: number) => HSL;
export declare const getPixelRatio: () => number;
export {};
