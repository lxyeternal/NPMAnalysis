declare const _default: {
    en: {
        color_red: string;
        color_orange: string;
        color_yellow: string;
        color_yellow_green: string;
        color_green: string;
        color_cyan_green: string;
        color_cyan: string;
        color_indigo: string;
        color_blue: string;
        color_purple: string;
        color_magenta: string;
        color_purple_red: string;
    };
    zh: {
        color_red: string;
        color_orange: string;
        color_yellow: string;
        color_yellow_green: string;
        color_green: string;
        color_cyan_green: string;
        color_cyan: string;
        color_indigo: string;
        color_blue: string;
        color_purple: string;
        color_magenta: string;
        color_purple_red: string;
    };
};
export default _default;
