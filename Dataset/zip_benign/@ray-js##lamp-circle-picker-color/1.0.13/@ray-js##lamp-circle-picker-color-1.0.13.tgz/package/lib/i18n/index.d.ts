import { kit } from '@ray-js/panel-sdk';
declare const _default: kit.I18N;
export default _default;
