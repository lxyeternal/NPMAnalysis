/// <reference types="react" />
import { IProps } from './props';
declare const LampCirclePickerColor: {
    (props: IProps): JSX.Element;
    defaultProps: IProps;
};
export default LampCirclePickerColor;
