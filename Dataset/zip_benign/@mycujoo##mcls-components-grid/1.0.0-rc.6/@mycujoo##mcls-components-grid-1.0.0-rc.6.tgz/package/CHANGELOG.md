# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.0.0-alpha.2](/compare/v1.0.0-alpha.1...v1.0.0-alpha.2) (2023-07-11)

- Optimize bundle size

## [1.0.0-alpha.1](/compare/v1.0.0-beta.26...v1.0.0-alpha.1) (2023-07-10)

**Note:** Version bump only for package @mycujoo/mcls-components-grid
