FD LIB 
=============

### Docs ###

### Resources ###

[Five and Done](<http://www.fiveanddone.com/>)


### Road Map ###

### Contribute ###

Great!

### How to build ###

FD Lib is built with Grunt. If you don't already have this, go install Node and NPM then install the Grunt Command Line.

```
$> npm install -g grunt-cli
```

Then, in the folder where you have downloaded the source, install the build dependencies using npm:

```
$> npm install
```

Then build:

```
$> grunt
```

This will create a non-minified versions in a bin directory.

### Usage ###

```javascript

	var NumberUtil = require("../bin/util/NumberUtil");

	NumberUtil.isEqual(3.042, 3, 0.5) //should equal true
```

This content is released under the (http://opensource.org/licenses/MIT) MIT License.