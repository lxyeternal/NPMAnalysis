var NumberUtil = require("../bin/util/NumberUtil");
var Percent = require("../bin/math/Percent");

exports.testIsEqual = function(test){
    test.expect(2);
    test.ok( !NumberUtil.isEqual(3.042, 3, 0), "This shuold be false");
    test.ok( NumberUtil.isEqual(3.042, 3, 0.5), "this assertion should pass");

    test.done();
};

exports.testMin = function(test){
	test.expect(3);
	test.equal( NumberUtil.min(5, null), 5, "Should be 5");
	test.equal( NumberUtil.min(5, "CASA"), 5, "Should be 5");
	test.equal( NumberUtil.min(5, 13), 5, "Should be 5");

	test.done();
}

exports.testMax = function(test){
	test.expect(3);
	test.equal( NumberUtil.max(-5, null), -5, "Should be -5");
	test.equal( NumberUtil.max(-5, "CASA"), -5, "Should be -5");
	test.equal( NumberUtil.max(-5, -13), -5, "Should be -5");

	test.done();
}

exports.testIsEven = function(test){
	test.expect(2);
	test.ok( !NumberUtil.isEven(7) );
	test.ok( NumberUtil.isEven(12) );

	test.done();
}

exports.testIsOdd = function(test){
	test.expect(2);
	test.ok( NumberUtil.isOdd(7) );
	test.ok( !NumberUtil.isOdd(12) );

	test.done();
}

exports.testIsInteger = function(test){
	test.expect(2);
	test.ok( NumberUtil.isInteger(13) );
	test.ok( !NumberUtil.isInteger(1.2345) );

	test.done();
}

exports.testIsPrime = function(test){
	test.expect(2);
	test.ok( NumberUtil.isPrime(13) );
	test.ok( !NumberUtil.isPrime(4));

	test.done();
}

exports.testRoundDecimalToPlace = function(test){
	test.expect(2);
	test.equal( NumberUtil.roundDecimalToPlace(3.14159, 2), 3.14 ); // Traces 3.14
	test.equal( NumberUtil.roundDecimalToPlace(3.14159, 3), 3.142 ); // Traces 3.142

	test.done();
}

exports.testLoopIndex = function(test){
	test.expect(3);
	var colors = new Array("Red", "Green", "Blue");

	test.equal( colors[NumberUtil.loopIndex(2, colors.length)], "Blue"); // Traces Blue
	test.equal( colors[NumberUtil.loopIndex(4, colors.length)], "Green"); // Traces Green
	test.equal( colors[NumberUtil.loopIndex(-6, colors.length)], "Red"); // Traces Red

	test.done();
}

exports.testIsBetween = function(test){
	test.expect(2);

	test.ok( NumberUtil.isBetween(3, 0, 5) ); // Traces true
	test.ok( !NumberUtil.isBetween(7, 0, 5) ); // Traces false

	test.done();
}

exports.testContains = function(test){
	test.expect(2);

	test.equal( NumberUtil.constrain(3, 0, 5), 3); // Traces 3
	test.equal( NumberUtil.constrain(7, 0, 5), 5); // Traces 5

	test.done();
}

exports.testCreateStepsBetween = function(test){
	test.expect(2);

	test.deepEqual( NumberUtil.createStepsBetween(0, 5, 4), [1,2,3,4] ); // Traces 1,2,3,4
	test.deepEqual( NumberUtil.createStepsBetween(1, 3, 3), [1.5,2,2.5] ); // Traces 1.5,2,2.5

	test.done();
}

exports.testInterpolate = function(test){
	test.expect(1);
	test.equal( NumberUtil.interpolate(new Percent(0.5), 0, 10), 5); // Traces 5

	test.done();
}

exports.testNormalize = function(test){
	test.expect(1);
	test.equal( NumberUtil.normalize(8, 4, 20).decimalPercentage, 0.25); // Traces 0.25

	test.done();
}

exports.testMap = function(test){
	test.expect(1);
	test.equal( NumberUtil.map(0.75, 0, 1, 0, 100), 75); // Traces 75

	test.done();
}

exports.testFormat = function(test){
	test.expect(1);
	test.equal( NumberUtil.format(1234567, ",", 8), "01,234,567"); // Traces 01,234,567

	test.done();
}

exports.testFormatCurrency = function(test){
	test.expect(1);
	test.equal( NumberUtil.formatCurrency(1234.5), "1,234.50"); // Traces "1,234.50"

	test.done();
}

exports.testOrdinalSuffix = function(test){
	test.expect(1);
	test.equal( 32 + NumberUtil.getOrdinalSuffix(32), "32nd"); // Traces 32nd

	test.done();
}

exports.testSpell = function(test){
	test.expect(3);
	test.equal( NumberUtil.spell(0), "Zero"); // Traces Zero
	test.equal( NumberUtil.spell(23), "Twenty-Three"); // Traces Twenty-Three
	test.equal( NumberUtil.spell(2005678), "Two Million, Five Thousand, Six Hundred Seventy-Eight"); // Traces Two Million, Five Thousand, Six Hundred Seventy-Eight

	test.done();
}