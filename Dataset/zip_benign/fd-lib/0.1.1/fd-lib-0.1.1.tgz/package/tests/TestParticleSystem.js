var Emitter = require('../bin/particlesystem/Emitter');

exports.testConstructor = function(test){

	var emitter = new Emitter(5);

	test.equal( emitter._totalParticles, 5, "should be 5");
	
	test.done();
}