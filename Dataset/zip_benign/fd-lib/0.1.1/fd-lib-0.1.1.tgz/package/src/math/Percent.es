export default class Percent {
    /**
        Creates a new Percent.
         
        @param percentage: Percent formatted at a percentage or an decimal percentage.
        @param isDecimalPercentage: Indicates if the parameter <code>percentage</code> is a decimal percentage <code>true</code>, or regular percentage <code>false</code>.
    */
    constructor(percentage:Number = 0, isDecimalPercentage:Boolean = true) {

        this._percent;
         
        if (isDecimalPercentage) {
            this.decimalPercentage = percentage;
        } else {
            this.percentage = percentage;
        }
    }
     
    /**
        The percent expressed as a regular percentage. 37.5% would be expressed as <code>37.5</code>.
    */
    get percentage():Number {
        return 100 * this._percent;
    }
     
    set percentage(percent:Number):void {
        this._percent = percent * .01;
    }
     
    /**
        The percent expressed as a decimal percentage. 37.5% would be expressed as <code>0.375</code>.
    */
    get decimalPercentage():Number {
        return this._percent;
    }
     
    set decimalPercentage(percent:Number):void {
        this._percent = percent;
    }
     
    /**
        Determines if the percent specified in the <code>percent</code> parameter is equal to this percent object.
         
        @param percent: A Percent object.
        @return Returns <code>true</code> if percents are identical; otherwise <code>false</code>.
    */
    equals(percent:Percent):Boolean {
        return this.decimalPercentage == percent.decimalPercentage;
    }
     
    /**
        @return A new percent object with the same value as this percent.
    */
    clone():Percent {
        return new Percent(this.decimalPercentage);
    }
     
    valueOf():Number {
        return this.decimalPercentage;
    }
     
    toString():String {
        return this.decimalPercentage.toString();
    }
}