import NumberUtil from "./NumberUtil";
import * as Percent from "../math/Percent";

export default class ColorUtil {

    static interpolateColor(decimal, start, end) {
        var r = NumberUtil.interpolateDecimal(decimal, start.r, end.r);
        var g = NumberUtil.interpolateDecimal(decimal, start.g, end.g);
        var b = NumberUtil.interpolateDecimal(decimal, start.b, end.b);

        return [r, g, b];
    }

    /**
        Convert hex to rgb
         
        @param val1: A hex value.
        @return Returns the and object with r,g,b values.
        @example
            <code>
                alert( hexToRgb("#0033ff").g ); // "51";
				alert( hexToRgb("#03f").g ); // "51";
            </code>
    */
    static hexToRgb(hex) {
        var shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
        hex = hex.replace(shorthandRegex, function(m, r, g, b) {
            return r + r + g + g + b + b;
        });

        var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : null;
    }

    static getHexStringFromRGB(r: Number, g: Number, b: Number): String {
        var rr: String = r.toString(16);
        var gg: String = g.toString(16);
        var bb: String = b.toString(16);
        rr = (rr.length == 1) ? '0' + rr : rr;
        gg = (gg.length == 1) ? '0' + gg : gg;
        bb = (bb.length == 1) ? '0' + bb : bb;
        return "0x"+(rr + gg + bb);
    }

    /**
            Converts a 24-bit RGB color value into an RGB object.
             
            @param color: The 24-bit RGB color value.
            @return Returns an object with the properties r, g, and b defined.
            @example
                <code>
                    var myRGB:Object = ColorUtil.getRGB(0xFF00FF);
                    trace("Red = " + myRGB.r);
                    trace("Green = " + myRGB.g);
                    trace("Blue = " + myRGB.b);
                </code>
        */
    static getRGB(color): Object {
        var c: Object = {};
        c.r = color >> 16 & 0xFF;
        c.g = color >> 8 & 0xFF;
        c.b = color & 0xFF;
        return c;
    }
}
