import NumberUtil from "../util/NumberUtil";
import ObjectUtil from "../util/ObjectUtil";
import ColorUtil from "../util/ColorUtil";

export default class Particle{

    position    = {x:500,y:500};
    filters     = [];
    life        = 5 * Math.random();
    totalLife   = this.life;
    _angle      = 360;
    speed       = 50;
    radians     = this._angle * Math.PI / 180;
    velocity    = {x: this.speed * Math.cos(this.radians),y: -this.speed * Math.sin(this.radians)};
    forces      = {x:0, y:0};
    alpha       = 1;
    startColor  = ColorUtil.hexToRgb("#ffffff");
    endColor    = ColorUtil.hexToRgb("#0080ff");
//console.log('startColor: ', startColor);
    constructor(options) {
        this.position = options.position;
        this.life = options.life;
        this.totalLife = options.life;
        this.angle = options.angle;
        this.speed = options.speed;
        this.velocity =  {x: this.speed * Math.cos(this.radians),y: -this.speed * Math.sin(this.radians)};
        this.filters = options.filters;

        this.graphic;
        this.sprite;
        this.draw();

    }

    draw(){
        this.graphic = new PIXI.Graphics();
        this.graphic.lineStyle(0);
        this.graphic.beginFill(0xFFFFFF, 1);
        this.graphic.drawCircle(0, 0,2);
        this.graphic.endFill();
        if(this.filters.length){
            this.graphic.filters = this.filters;
        }
        this.graphic.cacheAsBitmap = true;


        this.sprite = new PIXI.Sprite( this.graphic.generateTexture() );
    }

    set angle(value:Number){
        this._angle = value;
        this.radians = this._angle * Math.PI / 180;
        this.velocity = {
            x: this.speed * Math.cos(this.radians),
            y: -this.speed * Math.sin(this.radians)
        }
    }

    update(dt):void{
        this.life -= dt;
        
        this.position.x += this.velocity.x * dt;
        this.position.y += this.velocity.y * dt;

        var normalized = NumberUtil.normalizeDecimal(this.life, this.totalLife, 0);
        var color = ColorUtil.interpolateColor( normalized, this.startColor, this.endColor );
        var hex = ColorUtil.getHexStringFromRGB( Math.floor(color[0]), Math.floor(color[1]), Math.floor(color[2]) );

        this.sprite.tint = hex;
        this.sprite.position = this.position;
        this.sprite.alpha = NumberUtil.map(this.life, this.totalLife, 0, 1, this.alpha);
    }

    reset():void{
        this.life = this.totalLife;
    }

    dispose():void{
        delete this;
    }
}