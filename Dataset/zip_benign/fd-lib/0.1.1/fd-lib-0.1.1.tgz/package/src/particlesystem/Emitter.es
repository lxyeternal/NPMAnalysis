import Particle from "./Particle";
import buckets from "buckets-js/buckets";
import signals from "signals";
import ColorUtil from "../util/ColorUtil";

export default class Emitter{

    constructor(totalParticles:Number) {
        this._particlePool = [];
        this._particles = new buckets.LinkedList();
        this._totalParticles = totalParticles;
        this._speed = 50;
        this._angle = 360;
        this._life = 5;
        this._alpha = 1;
        this._gravity = {x:0,y:0};
        this._spawn_x = 500;
        this._spawn_y = 500;
        this._spawn_width = 0;
        this._spawn_height = 0;
        this._turbulence = 0;
        this._start_color = ColorUtil.hexToRgb("#ffffff");
        this._end_color = ColorUtil.hexToRgb("#0080ff");
        //this._timestamp = 0;
        this._lastTimestamp = null;

        this.particleAdded = new signals.Signal();
        this.particleRemoved = new signals.Signal();

        /*this.blurFilter = new PIXI.filters.BlurFilter();
        this.blurFilter.blur = 50;*/
    }

    get particles():Object{
        //return this._particlePool;
        return this._particles;
    }

    set particles(value:Object):void{
        this._particles = value;
    }

    set totalParticles(value:Number):void{
        var diff = value - this._totalParticles;
        if(diff > 0){
            do{
                this.addParticle();
                diff--;
            }
            while(diff > 0);
        }

        if( diff < 0 ){
            do{
                this.removeParticle();
                diff++;
            }
            while(diff < 0);
        }

        this._totalParticles = value;
    }

    set speed(value:Number):void{
        this._speed = value;
    }

    set angle(value:Number):void{
        this._angle = value;
    }

    set life(value:Number):void{
        this._life = value;
    }

    get gravity():Object{
        return this._gravity;
    }

    set gravity(value:Object):void{
        this._gravity = value;
    }

    set spawn_x(value:Number):void{
        this._spawn_x = value;
    }

    set spawn_y(value:Number):void{
        this._spawn_y = value;
    }

    set spawn_width(value:Number):void{
        this._spawn_width = value;
    }

    set spawn_height(value:Number):void{
        this._spawn_height = value;
    }

    set turbulence(value:Number):void{
        this._turbulence = value;
    }

    set alpha(value:Number):void{
        this._alpha = value;
    }

    set start_color(value:Number):void{
        this._start_color = ColorUtil.hexToRgb(value);
    }

    set end_color(value:Number):void{
        this._end_color = ColorUtil.hexToRgb(value);
    }

    get turbulence():void{
        return this._turbulence * Math.random() * (Math.round(Math.random()) * 2 - 1);
    }

    start() {
        this._timestamp = new Date().getTime();

        for(var i = 0; i < this._totalParticles; ++i) {
            this.addParticle();
        }
    }

    addParticle():void{
        /*var filter = new PIXI.filters.BlurFilter();
            filter.blur = 50 * Math.random();*/
            //x:Number, y:Number, life:Number, angle:Number, speed:Number, filters:Array
        var particle = new Particle({
            "position" : {x: this._spawn_x, y:this._spawn_y},
            "life"     : 5 * Math.random(),
            "angle"    : this._angle*Math.random(),
            "speed"    : this._speed,
            "filters"  : []
        });
        
        this._particles.add(particle);

        this.particleAdded.dispatch(particle);
    }

    removeParticle():Object{
        var last = this._particles.last();

        this._particles.remove( last );

        this.particleRemoved.dispatch( last );

        last.dispose();
    }

    update(timestamp){
        var delta = timestamp - (this._lastTimestamp || timestamp);
        
        this._lastTimestamp = timestamp;

        delta /= 1000;

        /*for(var i = 0, l = this._particlePool.length; i < l; ++i) {
            var particle = this._particlePool[i];*/
        for (var i = 0; i < this._particles.size(); i++) {
            var p = this._particles.elementAtIndex(i);
                
            if( p.life > 0 ){
                p.forces.x = this.gravity.x + this.turbulence; //<- testing turbulance
                p.forces.y = this.gravity.y + this.turbulence;//+ ( 300 * Math.random() );
                p.forces.x *= delta;
                p.forces.y *= delta;
                p.velocity.x += p.forces.x;
                p.velocity.y += p.forces.y;
                p.alpha = this._alpha;
                p.update(delta);
            }else{
                p.position = {x: this._spawn_x + this._spawn_width * Math.random(), y:this._spawn_y + this._spawn_height * Math.random() };
                p.speed = this._speed;
                p.angle = this._angle*Math.random();
                p.forces = {x:0, y:0};
                p.startColor = this._start_color;
                p.endColor = this._end_color;
                p.reset();
            }
        }
    }
}