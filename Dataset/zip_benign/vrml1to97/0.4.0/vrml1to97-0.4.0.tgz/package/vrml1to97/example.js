import { convert } from "./index.js";
const example = `
#VRML V1.0 ascii

# Example 2 - using the Separator and Material Nodes

# Here comes the Sun
# The Separator node groups everything within it together
Separator {
       # The material will affect all subsequent nodes
       # The Sun becomes yellow
       Material {
              diffuseColor 1 1 0    # R G B
       }
       Sphere {
               radius 10                   # the Sun is very big
       }
}`;
console.log(convert(example, 'https://www.cg.tuwien.ac.at/studentwork/VRSem96/VRML/vrml3.html#ex2'));
