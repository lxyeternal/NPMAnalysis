type Tree = {
    [key: string]: (string | Tree)[];
};
type DefTree = {
    _definitions?: Tree;
} & Tree;
export declare function tree97(vrml1: string): DefTree;
export declare function convert(vrml1: string, source?: string): string;
export {};
