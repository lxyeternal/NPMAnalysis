import moo from "../deps/moo.js";
const lexer = moo.compile({
    comment: /#.*?$/,
    whitespace: {
        match: /\s+/,
        lineBreaks: true,
    },
    string: {
        match: /"(?:\\"|[^"])*"/,
        lineBreaks: true,
    },
    number: /[\d.-][\d.x]*/,
    word: /[^\d.-\W]\w*/,
    comma: ',',
    obrace: '{',
    cbrace: '}',
    obracket: '[',
    cbracket: ']',
    oparen: '(',
    cparen: ')',
});
export function tree97(vrml1) {
    return parse(lexer.reset(vrml1));
}
function filtered(stream) {
    let result = stream.next();
    while (result && (result.type === 'whitespace' || result.type === 'comment')) {
        result = stream.next();
    }
    return result;
}
function toksUntilClose(stream) {
    let ref;
    const results = [];
    while (ref = filtered(stream)) {
        const tok = ref;
        if (tok.type == 'cbrace')
            break;
        results.push(({ type: [tok.type ?? ''], value: [tok.value] }));
    }
    ;
    return results;
}
function sum(arr) {
    let ret = 0;
    for (let i = 0, len = arr.length; i < len; i++) {
        const n = arr[i];
        ret += n;
    }
    return ret;
}
function translatedToksUntilClose(stream) {
    let ref1;
    const results1 = [];
    while (ref1 = filtered(stream)) {
        const tok = ref1;
        if (tok.type === 'cbrace')
            break;
        if (tok.type === 'word' && tok.value === 'filename') {
            results1.push(({ type: ['word'], value: ['url'] }));
        }
        else if (tok.type === 'word' && tok.value === 'textureCoordIndex') {
            results1.push(({ type: ['word'], value: ['texCoordIndex'] }));
        }
        else if (tok.type === 'word' && tok.value === 'ambientColor') {
            const rgb = [filtered(stream), filtered(stream), filtered(stream)];
            if (rgb.every($ => $)) {
                const value = sum(rgb.map((t) => parseFloat(t.value))) / 3;
                results1.push(`ambientIntensity ${value}`);
            }
            else
                continue;
        }
        else
            results1.push(({ type: [tok.type ?? ''], value: [tok.value] }));
    }
    ;
    return results1;
}
function findNumbersAtTopLevel(stream, fields) {
    // modifies fields by side effect
    let depth = 1;
    let selecting = '';
    while (depth > 0) {
        const tok = filtered(stream);
        if (!tok)
            break;
        let selector = '';
        if (typeof tok === 'object' && tok != null && 'type' in tok && tok.type === 'cbrace') {
            const { type } = tok;
            depth -= 1;
        }
        else if (typeof tok === 'object' && tok != null && 'type' in tok && tok.type === 'word') {
            const { type } = tok;
            if (depth === 1 && tok.value in fields) {
                selector = tok.value;
            }
        }
        else if (typeof tok === 'object' && tok != null && 'type' in tok && tok.type === 'number') {
            const { type } = tok;
            if (selecting)
                fields[selecting] = tok.value;
        }
        else if (typeof tok === 'object' && tok != null && 'type' in tok && tok.type === 'obrace') {
            const { type } = tok;
            depth += 1;
        }
        selecting = selector;
    }
}
function addChild(child, tree) {
    (tree.children ??= []).push(child);
}
function addWorldParameter(name, value, tree) {
    const children = tree.children ??= [];
    let world = (children.find((x) => {
        if (typeof x === 'object') {
            return 'WorldInfo' in x;
        }
        else
            return false;
    }));
    if (!world) {
        world = { WorldInfo: [] };
        children.push(world);
    }
    world.WorldInfo.push(` ${name}`, ` ${value}`);
}
// Current best way to re-use a pattern
const matches = (str, pat) => pat.test(str);
const GroupNode = /(?:Transform)?Separator|Group|Switch|WWWAnchor/;
const TransformNode = /^(?:Rotation|Scale|Transform|Translation)$/;
const SetNode = /IndexedFaceSet|IndexedLineSet|PointSet/;
const LightNode = /Light$/;
function parse(stream, tree = {}) {
    let held = filtered(stream); // for lookahead
    let currentDefinition = ''; // if we have just started a DEF
    let ref2; // if we have just started a DEF
    while (ref2 = filtered(stream)) {
        const next = ref2;
        if (!held)
            break;
        // May need to know the current definition, but it clears each round
        const lastDefinition = currentDefinition;
        currentDefinition = '';
        {
            let ref3 = { nt: next.type, nv: next.value, ht: held.type, hv: held.value };
            const data = ref3;
            if (typeof ref3 === 'object' && ref3 != null && 'ht' in ref3 && ref3.ht === 'word' && 'hv' in ref3 && ref3.hv === 'Info') {
                // Here the meaning is entirely dependent on what DEF we are in
                const { ht, hv } = ref3;
                // Here the meaning is entirely dependent on what DEF we are in
                if (next.type !== 'obrace') {
                    // Not sure what this construct is, so ignore it
                    held = next;
                    continue;
                }
                const contents = toksUntilClose(stream);
                held = filtered(stream);
                if (lastDefinition === 'BackgroundColor') {
                    // Find the first string token and assume it is the color
                    const stok = contents.find($1 => $1.type[0] === 'string');
                    const colorString = stok?.value[0];
                    if (colorString && typeof colorString === 'string') {
                        const color = colorString.replace(/^"|"$/g, '');
                        addChild(`Background {
                        groundColor [ ${color} ]
                        skyColor [ ${color} ]
                     }\n`, tree);
                    }
                }
                else if (lastDefinition === 'Title') {
                    // Find the first string token and assume it is the title
                    const stok = contents.find($2 => $2.type[0] === 'string');
                    const titleString = stok?.value[0];
                    if (titleString && typeof titleString === 'string') {
                        addWorldParameter('title', titleString, tree);
                    }
                }
                else if (lastDefinition === 'SceneInfo') {
                    // Filter all the strings and add them as info
                    const info = ((contents.filter($3 => $3.type[0] === 'string')).map($4 => $4.value[0])).join(' ');
                    addWorldParameter('info', `[ ${info} ]`, tree);
                }
                else if (lastDefinition === 'Viewer') {
                    // Filter all of the strings, and translate them into
                    // current viewer names
                    const tr = { '"examiner"': '"EXAMINE"' };
                    const viewers = (((contents.filter($5 => $5.type[0] === 'string')).map($6 => $6.value[0])).map((x) => x in tr ? tr[x] : x.toUpperCase())).join(' ');
                    addChild(`NavigationInfo { type [ ${viewers} ] }\n`, tree);
                }
            }
            else if (typeof ref3 === 'object' && ref3 != null && 'ht' in ref3 && ref3.ht === 'word' && 'hv' in ref3 && ref3.hv === 'DEF') {
                const { ht, hv } = ref3;
                if (!(next.type === 'word')) {
                    // Don't understand this construction, ignore the DEF
                    held = next;
                    continue;
                }
                currentDefinition = next.value;
                held = filtered(stream);
                // Special case from VRML 1: DEF Cameras Switch { ... }
                // needs to be hoisted to a list of viewpoints at this level
                if (currentDefinition === 'Cameras' && held?.value === 'Switch') {
                    held = filtered(stream);
                    if (!(held?.type === 'obrace')) {
                        console.error(`DEF Cameras Switch followed by ${held?.value}, ignoring`);
                        continue;
                    }
                    const { children, ...context } = tree;
                    const subTree = parse(stream, context);
                    addChild(renderList(subTree.children), tree);
                    held = filtered(stream);
                    continue;
                }
                if (held?.type === 'word') {
                    const clause = `DEF ${currentDefinition}`;
                    let role = held.value;
                    if (matches(role, GroupNode)) {
                        role = 'Child';
                    }
                    else if (matches(role, TransformNode)) {
                        role = 'Transform';
                    }
                    else if (role === 'Coordinate3') {
                        role = 'Coordinate';
                    }
                    else if (typeof role === 'string' && /Cube|Cone|Cylinder|Sphere/.test(role)) {
                        role = 'Shape';
                    }
                    else if (role === 'PerspectiveCamera') {
                        role = 'Viewpoint';
                    }
                    else if (role === 'ShapeHints') {
                        role = 'Dummy';
                    }
                    else if (role === 'Texture2') {
                        role = 'Texture';
                    }
                    else if (role === 'TextureCoordinate2') {
                        role = 'TextureCoordinate';
                    }
                    else if (matches(role, SetNode)) {
                        role = 'Shape';
                    }
                    else if (matches(role, LightNode)) {
                        role = 'Child';
                    }
                    ;
                    (tree._definitions ??= {})[currentDefinition] = [role];
                    if (!(role === 'Info')) {
                        // Info nodes don't directly generate a node in translation
                        addChild(clause, tree);
                    }
                }
            }
            else if (typeof ref3 === 'object' && ref3 != null && 'ht' in ref3 && ref3.ht === 'word' && 'hv' in ref3 && ref3.hv === 'USE') {
                const { ht, hv } = ref3;
                if (!(next.type === 'word')) {
                    // Don't understand this construction, ignore the USE
                    held = next;
                    continue;
                }
                const known = tree._definitions;
                if (known && next.value in known) {
                    const role = known[next.value][0];
                    const clause = `USE ${next.value}`;
                    if (role === 'Child') {
                        addChild(clause, tree);
                    }
                    else if (role === 'Shape') {
                        addShape(clause, [], tree);
                    }
                    else if (role === 'Transform') {
                        // VRML97 doesn't allow just the transform part of
                        // a Transform to be USEd (the whole node must be), so
                        // we have to recreate the transform. FIXME: dedupe code
                        const content = known[next.value].slice(1);
                        const { children, ...context } = tree;
                        const restOfTree = parse(stream, context);
                        let ref4;
                        if (ref4 = restOfTree.children) {
                            const remainingKids = ref4;
                            const newChild = `Transform {\n   ${renderList(content)}\n   `
                                + `children [\n      ${renderList(remainingKids)}`
                                + "] }\n";
                            addChild(newChild, tree);
                        }
                        return tree;
                    }
                    else if (typeof role === 'object' && role != null) {
                        mergeTree(role, tree);
                    }
                    else {
                        tree[role] = [clause];
                    }
                }
                else {
                    console.error('USE of unDEFined identifier', next.value);
                }
                held = filtered(stream);
            }
            else if (typeof ref3 === 'object' && ref3 != null && 'ht' in ref3 && ref3.ht === 'word' && 'nt' in ref3 && ref3.nt === 'obrace') {
                const { ht, nt } = ref3;
                let m;
                if (m = held.value, matches(m, GroupNode)) {
                    const { children, ...context } = tree;
                    const subTree = parse(stream, context);
                    let ref5;
                    if (ref5 = subTree.children) {
                        const newKids = ref5;
                        let newChild = '';
                        if (held.value === 'Switch') {
                            newChild = "Switch {\n  ";
                            if ('whichChoice' in subTree) {
                                newChild += `whichChoice ${subTree.whichChoice[0]}\n   `;
                            }
                            newChild += `choice [\n     ${renderList(newKids)} ] }\n`;
                        }
                        else
                            newChild =
                                `Group { children [\n   ${renderList(newKids)} ] }\n`;
                        addChild(newChild, tree);
                    }
                }
                else if (matches(m, TransformNode)) {
                    const content = toksUntilClose(stream);
                    if (lastDefinition
                        && tree._definitions?.[lastDefinition][0] === 'Transform') {
                        tree._definitions[lastDefinition].push(...content);
                    }
                    const { children, ...context } = tree;
                    const restOfTree = parse(stream, context);
                    let ref6;
                    if (ref6 = restOfTree.children) {
                        const remainingKids = ref6;
                        const newChild = `Transform {\n   ${renderList(content)}\n   `
                            + `children [\n      ${renderList(remainingKids)} ] }\n`;
                        addChild(newChild, tree);
                    }
                    return tree;
                }
                else if (m === 'ShapeHints') {
                    const subTree = parse(stream);
                    const hints = {};
                    if ('vertexOrdering' in subTree) {
                        hints.ccw = [
                            subTree.vertexOrdering[0] === 'ccw' ? 'TRUE' : 'FALSE'
                        ];
                    }
                    if ('creaseAngle' in subTree) {
                        hints.creaseAngle = subTree.creaseAngle;
                    }
                    mergeTree(hints, tree);
                    if (lastDefinition && tree._definitions) {
                        tree._definitions[lastDefinition] = [hints];
                    }
                }
                else if (m === 'PerspectiveCamera') {
                    const contents = toksUntilClose(stream);
                    const hasDescription = contents.find((e) => {
                        return e.type?.[0] === 'word' && e.value?.[0] === 'description';
                    });
                    if (lastDefinition && hasDescription === undefined) {
                        contents.push({ type: ['word'], value: ['description'] });
                        contents.push({ type: ['word'], value: [`"${lastDefinition}"`] });
                    }
                    addChild({ Viewpoint: contents }, tree);
                }
                else if (m === 'Coordinate3') {
                    tree.Coordinate = toksUntilClose(stream);
                }
                else if (m === 'Normal') {
                    tree.Normal = toksUntilClose(stream);
                }
                else if (m === 'TextureCoordinate2') {
                    tree.TextureCoordinate = toksUntilClose(stream);
                }
                else if (m === 'Texture2') {
                    tree.Texture = translatedToksUntilClose(stream);
                }
                else if (m === 'Material') {
                    tree.Material = translatedToksUntilClose(stream);
                }
                else if (m === 'Cube') {
                    const dims = { width: '', height: '', depth: '' };
                    findNumbersAtTopLevel(stream, dims);
                    const params = [`size ${dims.width} ${dims.height} ${dims.depth}`];
                    addShape('Box', params, tree);
                }
                else if (m === 'Cone') {
                    const dims = { bottomRadius: '', height: '' };
                    findNumbersAtTopLevel(stream, dims);
                    const params = [`bottomRadius ${dims.bottomRadius}`,
                        `height ${dims.height}`];
                    addShape('Cone', params, tree);
                }
                else if (m === 'Cylinder') {
                    const dims = { radius: '', height: '' };
                    findNumbersAtTopLevel(stream, dims);
                    const params = [`radius ${dims.radius} height ${dims.height}`];
                    addShape('Cylinder', params, tree);
                }
                else if (m === 'Sphere') {
                    const dims = { radius: '' };
                    findNumbersAtTopLevel(stream, dims);
                    addShape('Sphere', [`radius ${dims.radius}`], tree);
                }
                else if (matches(m, SetNode)) {
                    const isFaces = held.value === 'IndexedFaceSet';
                    const contents = translatedToksUntilClose(stream);
                    const params = [];
                    if ('Coordinate' in tree) {
                        params.push("coord Coordinate {\n", ...tree.Coordinate, " }\n");
                    }
                    if ('Normal' in tree) {
                        params.push("normal Normal {\n", ...tree.Normal, " }\n");
                    }
                    if (isFaces && 'TextureCoordinate' in tree) {
                        params.push("texCoord TextureCoordinate {\n", ...tree.TextureCoordinate, " }\n");
                    }
                    if (isFaces && 'creaseAngle' in tree) {
                        params.push(`creaseAngle ${tree.creaseAngle[0]}`);
                    }
                    if (isFaces) {
                        if ('ccw' in tree)
                            params.push(`ccw ${tree.ccw[0]}`);
                        else
                            params.push('solid FALSE');
                    }
                    params.push(...contents);
                    addShape(held.value, params, tree);
                }
                else if (matches(m, LightNode)) {
                    const contents = toksUntilClose(stream);
                    addChild({ [held.value]: contents }, tree);
                }
                else {
                    parse(stream);
                } // discard the subgroup
                held = filtered(stream);
            }
            else if (typeof ref3 === 'object' && ref3 != null && 'ht' in ref3 && ref3.ht === 'word' && 'hv' in ref3 && ref3.hv === 'vertexOrdering' && 'nt' in ref3 && ref3.nt === 'word') {
                const { ht, hv, nt } = ref3;
                let m1;
                if (m1 = next.value, m1 === 'COUNTERCLOCKWISE') {
                    tree.vertexOrdering = ['ccw'];
                }
                else if (m1 === 'CLOCKWISE') {
                    tree.vertexOrdering = ['cw'];
                }
                held = filtered(stream);
            }
            else if (typeof ref3 === 'object' && ref3 != null && 'ht' in ref3 && ref3.ht === 'word' && 'hv' in ref3 && ref3.hv === 'creaseAngle' && 'nt' in ref3 && ref3.nt === 'number') {
                const { ht, hv, nt } = ref3;
                tree.creaseAngle = [next.value];
                held = filtered(stream);
            }
            else if (typeof ref3 === 'object' && ref3 != null && 'ht' in ref3 && ref3.ht === 'word' && 'hv' in ref3 && ref3.hv === 'whichChild') {
                const { ht, hv } = ref3;
                tree.whichChoice = [next.value];
                held = filtered(stream);
            }
            else {
                console.error('Ignoring unparseable token', held);
                held = next;
            }
        } // ignore unknown words
        if (!held || held.type === 'cbrace')
            break;
    }
    if (held && held.type !== 'cbrace') {
        console.error('Incomplete parse, symbol at end:', held);
    }
    return tree;
}
function addShape(nodeType, params, tree) {
    const shape = { Shape: [] };
    if ('Texture' in tree || 'Material' in tree) {
        shape.Shape.push("appearance Appearance {\n");
        if ('Material' in tree) {
            shape.Shape.push("material Material {\n", ...tree.Material, " }\n");
        }
        if ('Texture' in tree) {
            shape.Shape.push("texture ImageTexture {\n", ...tree.Texture, " }\n");
        }
        shape.Shape.push(" }\n");
    }
    const geometry = [`geometry ${nodeType}`];
    if (params.length)
        geometry.push("  {\n", ...params, " }\n");
    shape.Shape.push(...geometry);
    addChild(shape, tree);
}
function mergeTree(subtree, tree) {
    for (const key in subtree) {
        const value = subtree[key];
        tree[key] = value;
    }
}
function render(t) {
    if (typeof t === 'string')
        return t;
    if ('children' in t)
        return renderList(t.children);
    if ('type' in t && 'value' in t) {
        const val = renderList(t.value);
        return (() => {
            let m2;
            if (m2 = t.type[0], typeof m2 === 'string' && /string|number|word/.test(m2)) {
                return val;
            }
            else if (typeof m2 === 'string' && /comma|oparen|cparen/.test(m2)) {
                return val;
            }
            else if (typeof m2 === 'string' && /obrace|cbrace|obracket|cbracket/.test(m2)) {
                return `${val}\n`;
            }
            else {
                return `\nUNKNOWN TYPE ${t.type}\n\n`;
            }
        })();
    }
    let result = '';
    for (const prop in t) {
        result += `${prop} {\n  ${renderList(t[prop])} }\n`;
    }
    return result;
}
function renderList(l) {
    let ret1 = '';
    let neg1triggersComma = false;
    let commaNewlineOnce = false;
    let commaTriggersNewline = false;
    for (let i1 = 0, len1 = l.length; i1 < len1; i1++) {
        const item = l[i1];
        const next = render(item);
        if (ret1 && !',()'.includes(next[0])) {
            ret1 += ' ';
        }
        ret1 += next;
        if (typeof item === 'object' && item != null && 'type' in item && Array.isArray(item.type) && item.type.length === 1 && item.type[0] === 'word' && 'value' in item && Array.isArray(item.value) && item.value.length === 1 && item.value[0] === 'point') {
            const { type: [], value: [] } = item;
            commaTriggersNewline = true;
        }
        else if (typeof item === 'object' && item != null && 'type' in item && Array.isArray(item.type) && item.type.length === 1 && item.type[0] === 'word' && 'value' in item && Array.isArray(item.value) && item.value.length === 1 && typeof item.value[0] === 'string' && /Index$/.test(item.value[0])) {
            const { type: [], value: [] } = item;
            neg1triggersComma = true;
        }
        else if (typeof item === 'object' && item != null && 'type' in item && Array.isArray(item.type) && item.type.length === 1 && item.type[0] === 'number' && 'value' in item && Array.isArray(item.value) && item.value.length === 1 && item.value[0] === '-1') {
            const { type: [], value: [] } = item;
            if (neg1triggersComma)
                commaNewlineOnce = true;
        }
        else if (typeof item === 'object' && item != null && 'type' in item && Array.isArray(item.type) && item.type.length === 1 && item.type[0] === 'comma') {
            const { type: [] } = item;
            if (commaTriggersNewline || commaNewlineOnce) {
                ret1 += "\n";
                commaNewlineOnce = false;
            }
        }
        else if (typeof item === 'object' && item != null && 'type' in item && Array.isArray(item.type) && item.type.length === 1 && item.type[0] === 'cbracket') {
            const { type: [] } = item;
            neg1triggersComma = false;
            commaNewlineOnce = false;
            commaTriggersNewline = false;
        }
    }
    return ret1;
}
export function convert(vrml1, source = '') {
    let ret2 = '#VRML V2.0 utf8\n';
    if (source) {
        ret2 += `# Converted by npm vrml1to97 from ${source}\n`;
    }
    ret2 += "\n";
    ret2 += render(tree97(vrml1));
    return ret2;
}
