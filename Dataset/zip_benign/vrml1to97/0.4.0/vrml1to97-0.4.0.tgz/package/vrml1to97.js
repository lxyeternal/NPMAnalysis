#!/usr/bin/env node

import {convert} from './vrml1to97/index.js'
import {stdin, argv} from 'node:process'
import {streamToString} from './streamToString.js'

if (argv.length > 2) {
   console.log('Usage: vrml1to97 < old.wrl > shinynew.wrl')
   console.log('  Translates VRML 1.0 on standard input to VRML97 on standard out.')
} else {
   const input = await streamToString(stdin)
   console.log(convert(input))
}
