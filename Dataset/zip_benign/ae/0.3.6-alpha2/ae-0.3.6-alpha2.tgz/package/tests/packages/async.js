var Q = require('kew');

module.exports =
    function asyncPackage()
    {
        this.factory('simple', function()
        {
            var defer = Q.defer();
            setTimeout(function()
            {
                defer.resolve(', world');
            },50);
            return defer.promise;
        });

        this.factory('compound', [
            'async.simple',
            'values.strVal',
            function(simple, strVal)
            {
                return strVal + simple;
            }
        ]);

        this.factory('nested', [
            'async.compound',
            function(compound)
            {
                var defer = Q.defer();
                setTimeout(function()
                {
                    defer.resolve(compound + ': nested');
                }, 50);
                return defer.promise;
            }
        ]);

        this.factory('deepNest', [

            'async.nested',
            function(nested)
            {
                var defer = Q.defer();
                setTimeout(function()
                {
                    defer.resolve(nested + '-deep');
                }, 50);
                return defer.promise;
            }
        ]);
    }
