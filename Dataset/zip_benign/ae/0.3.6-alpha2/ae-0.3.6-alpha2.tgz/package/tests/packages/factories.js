module.exports =
    function factories()
    {
        var counter = 0;

        this.factory('primitive', function()
        {
            return ', world';
        });

        this.factory('compound', [
            'values.strVal',
            'factories.primitive',
            function(strVal, primitive)
            {
                return strVal + primitive;
            }
        ]);

        this.factory('objFactory', function()
        {
            return { id: counter++ };
        });

        this.factory('fnFactory', function()
        {
            return function() { return 1; }
        });

    }
