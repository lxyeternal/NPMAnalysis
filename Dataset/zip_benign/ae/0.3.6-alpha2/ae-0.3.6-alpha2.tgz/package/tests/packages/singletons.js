var Q = require('kew');
module.exports =
    function singletonPackage()
    {
        this.singleton('obj', {
            sayFoo: function() { return 'foo'; }
        });

        this.singleton('wrapped',
        [
            'values.objVal',

            function(objVal)
            {
                return {
                    sayFoo: function() { return objVal.id }
                }
            }
        ]);

        this.singleton('async', [

            'async.deepNest',

            function(deepNest)
            {
                var defer = Q.defer();
                setTimeout(function()
                {
                    defer.resolve({
                        sayNested: function() { return deepNest; }
                    });

                },50);
                return defer.promise;
            }

        ])

    }
