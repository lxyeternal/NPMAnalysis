module.exports =
    function values()
    {
        this.value('numeric0', 0);
        this.value('numeric1', 1);
        this.value('strVal', 'hello');
        this.value('objVal', { id: 'foo' });
        this.value('arrVal', ['foo', 'bar']);
        this.value('fnVal', function() { return ', world' });
    }
