var test = require('tap').test;
var Ae  = require('../'),
    app = Ae.App('testApp');

app.register('values',     require('./packages/values'))
   .register('async',      require('./packages/async'))
   .register('factories',  require('./packages/factories'))
   .register('singletons', require('./packages/singletons'));
  // .register('types',      require('./packages/types'));

test('Injection: Values', function(t)
{
    app.invoke([
        'values.numeric0',
        'values.numeric1',
        'values.strVal',
        'values.objVal',
        'values.arrVal',
        'values.fnVal',

        function (num0, num1, str, obj, arr, fn)
        {
            t.equals(num0, 0,      'Falsey numeric value');
            t.equals(num1, 1,      'Numeric value');
            t.equals(str, 'hello', 'String value');

            t.deepEquals(obj, { id: 'foo' },   'Object value');
            t.deepEquals(arr, ['foo', 'bar' ], 'Array value');

            t.end();
        }
    ])
});

test('Injection: Factories', function(t)
{
    app.invoke([
        'factories.primitive',
        'factories.compound',
        'factories.objFactory',
        'factories.fnFactory',

        function(prim, comp, objFactory, fnFactory)
        {
            t.equals(prim, ', world', 'Primitive factory');
            t.equals(comp, 'hello, world', 'Compound factory');
            t.deepEquals(objFactory, { id: 0 }, 'Object factory');
            t.equals(fnFactory(), 1, 'Function factory');
            t.end();
        }
    ])
})

test('Injection: Async', function(t)
{
    t.plan(4);

    app.invoke([
        'async.simple',
        'async.compound',
        'async.nested',
        'async.deepNest',

        function(simple,compound,nested,deepNested)
        {
            t.equals(simple, ', world', 'Simple async factory');
            t.equals(compound, 'hello, world', 'Compound async factory');
            t.equals(nested, 'hello, world: nested', 'Nested async factories');
            t.equals(deepNested, 'hello, world: nested-deep', 'Deep nested async factories');
            t.end();
        }
    ]);
})

test('Injection: Singleton', function(t)
{
    t.plan(3);
    app.invoke([
        'singletons.obj',
        'singletons.wrapped',
        'singletons.async',

        function(obj, wrapped, async)
        {
            t.equals(obj.sayFoo(), 'foo', 'Object notation singleton');
            t.equals(wrapped.sayFoo(), 'foo', 'Wrapped singleton with dep');
            t.equals(async.sayNested(), 'hello, world: nested-deep', 'Async singleton with nested async dep');
            t.end();
        }
    ])
});
