var Ae  = require('../src');
var test = require('tap').test;

test('Assertion: isDefined', function(t)
{
    t.equal( Ae.isDefined(0),         true,  "isDefined(0)  is true");
    t.equal( Ae.isDefined([]),        true,  "isDefined([]) is true");
    t.equal( Ae.isDefined(NaN),       true,  "isDefined(NaN) is true");
    t.equal( Ae.isDefined(false),     true,  "isDefined(false) is true");
    t.equal( Ae.isDefined(null),      false, "isDefined(null) is fall");
    t.equal( Ae.isDefined(undefined), false, "isDefined(undefined) is false");
    t.end();
});

test("Assertion: isNumber", function(t)
{
    t.equal( Ae.isNumber(1),         true,  "is.number(1) is true");
    t.equal( Ae.isNumber(0),         true,  "is.number(0) is true");
    t.equal( Ae.isNumber(NaN),       false, "is.number(NaN is false");
    t.equal( Ae.isNumber(Infinity),  true, "is.number(Infinity) is false");  // use isFinite
    t.equal( Ae.isNumber(-Infinity), true, "is.number(-Infinity) is false");
    t.end();
});

test('Assertion: isString', function(t)
{
    t.equal( Ae.isString('foo'),     true, "isString('foo') is true");
    t.equal( Ae.isString(1),         false, "isString(1) is false");
    t.equal( Ae.isString({}),        false, "isString({}) is false");
    t.equal( Ae.isString(null),      false, "isString(null) is false");
    t.equal( Ae.isString(undefined), false, "isString(undefined) is false");
    t.end();
});

test("Assertion: isArray", function(t)
{
    t.equal( Ae.isArray([]),      true, "[] is true");
    t.equal( Ae.isArray([1,2,3]), true, "[1,2,3] is true");
    t.equal( Ae.isArray([null]),  true, "[null] is true");
    t.equal( Ae.isArray({}),      false, "{} is false");
    t.end();
});

test('Assertion: isObject', function(t)
{
    var inst = new testCtor('foo');
    function testCtor(id) { this.id = id;  }

    t.equal( Ae.isObject({}),        true,  "isObject({}) is true");
    t.equal( Ae.isObject(inst),      true,  "isObject(instance) is true");
    t.equal( Ae.isObject([]),        false, "isObject([]) is false");
    t.equal( Ae.isObject(1),         false, "isObject(1) is false");
    t.equal( Ae.isObject(null),      false, "isObject(null) is false");
    t.equal( Ae.isObject(undefined), false, "isObject(undefined) is false");
    t.end();
})

test('Assertion: isFn', function(t)
{
    t.equal( Ae.isFn(1),  false, "1 is false");
    t.equal( Ae.isFn({}), false, "{} is false");
    t.equal( Ae.isFn(function() { }),           true, "'function(){}' is true");
    t.equal( Ae.isFn(new Function('return 1')), true, "evaled fn is true");
    t.end();
});
