var Ae  = require('../../'),
    App = Ae.App('test');

var Q = require('kew');

App.value('test', 'hello')
    .factory('async',
        function(test)
        {
            var defer = Q.defer();
            setTimeout(function()
            {
                defer.resolve(' world');
            }, 50);
            return defer.promise;
        }
    )
    .factory('partialAsync', [
        'async',
        'test',
        function(test, async)
        {
            return async + test;
        }
    ]);


App.invoke([
    'partialAsync',
    function(greeting)
    {
        console.log(greeting);
    }
])
