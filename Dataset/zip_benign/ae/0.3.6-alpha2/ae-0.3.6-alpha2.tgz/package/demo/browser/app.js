var Ae = require('ae'),
    App = Ae.App('helloWorld');

App.value('msgFormat', 'Hello, {0}')
   .value('recipient', 'world')
   .factory('greeter', [
       'msgFormat',
       'recipient',
       function(msgFormat, recipient)
       {
           return Ae.supplant(msgFormat, [recipient]);
       }
    ]);

App.invoke([
    'greeter',
    function(greeting)
    {
        console.log(greeting); //> Hello, World
    }
]);
