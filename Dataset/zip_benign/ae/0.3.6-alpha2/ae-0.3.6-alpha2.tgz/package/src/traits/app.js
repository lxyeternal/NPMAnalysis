var util = require('../utility');
var assert = require('assert');
var resolvePath  = require('path').resolve;

module.exports = util.trait({

    path: function()
    {
        if (!arguments.length || 'undefined' === typeof arguments[0])
            return this.__path;

        var paths = [].slice.call(arguments);
        paths.unshift(this.__path);

        return resolvePath.apply(null, paths);
    },

    bootstrap: function(manifestPath)
    {
        var depPath,
            manifest = require(this.path(manifestPath));

        assert(manifest,
              'Ae.bootstrap: Failed to load manifest file "' + manifestPath +'"');

        for (var dependency in manifest)
        {
            if (manifest.hasOwnProperty(dependency))
            {
                this.register(dependency, require(this.path(manifest[dependency])));
            }
        }


    }


})
