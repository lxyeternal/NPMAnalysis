var
    slice    = Array.prototype.slice,
    toStr    = Object.prototype.toString,
    builtin = /Construct|Implements|Derives|Identify/;


/*
    TYPE ASSERTION

    Provides standardised, reliable type assertion without
    any reliance on the deprecated type utils in iojs
*/

exports.isDefined = function(v)
{
    return v != null;
};

exports.isNumber = function(v)
{
    return !!('number' === typeof v && v === v);
};

exports.isString = function(v)
{
    return !!(v && 'string' === typeof v);
};

exports.isObject = function(v)
{
    return !!(v && toStr.call(v) === '[object Object]');
};

exports.isFn = function(v)
{
    return !!(v && v.constructor && v.call && v.apply);
};

exports.isArray = Array.isArray
               || function(v)
               {
                   return !!(v && 'object' === typeof v && v.length && v.splice);
               };


/*
    GENERAL UTILITIES

    Generic helpers and sugar methods
*/

exports.exists = function(v, key)
{
    if (!v) return false;

    return v.hasOwnProperty
         ? v.hasOwnProperty(key)
         : !!v[key];
 }

 var extend = exports.extend
            = function(base, ext, allowOverwrite)
            {
                for (var cursor in ext)
                {
                    if (ext.hasOwnProperty(cursor))
                    {
                        if (allowOverwrite || !base.hasOwnProperty(cursor))
                            base[cursor] = ext[cursor];
                    }
                }
                return base;
            };

exports.delegate = function callback(fn, context)
{
    if (exports.isFn( fn ))
    {
        if ('undefined' === typeof context) { return fn; }

        // Avoid the use of Apply for all but edge cases
        switch(fn.length)
        {
            case 0: return function()       {  return fn.call(context);  };
            case 1: return function(a)      {  return fn.call(context, a);  };
            case 2: return function(a,b)    {  return fn.call(context, a, b);  };
            case 3: return function(a,b,c)  {  return fn.call(context, a, b, c);  };
        }
        return function() { return fn.apply(context, arguments); };
    }
    throw new TypeError('coa.callback | Expected {Function}, {*?}');
};


/*
    STRING UTILITIES

*/

exports.supplant = function(format, values)
{
    return format.replace(
        /\{([^{}]*)\}/g,
        function (a, b) {
            var r = values[b];
            return typeof r === 'string' || typeof r === 'number' ? r : a;
        }
    );
};

/*
    OBSERVABLE
*/


exports.observable = (function()
{
    function _on(id, callback)
    {
        var channel = this._channels[id]
                  ||( this._channels[id] = [] );

        channel.push(callback);
    }

    function _notify(id, values)
    {
        var channel = this._channels[id],
            count = channel ? channel.length : 0;

        if (!count) return;

        for (var i = 0; i < count; i++)
        {
            channel[i].apply(null, values);
        }
    }

    return function(target)
    {
        target._channels = {};
        target.on = _on;
        target.notify = _notify;
    }

})();


exports.type = function(descriptor)
{
    if (!exports.isObject(descriptor))
    {
        throw new Error('Ae.type - Expected descriptor of type Object');
    }

    var key,
        proto,
        superCtor = descriptor.Inherits,
        typeKeys = Object.keys(descriptor),
        ctor = descriptor.Construct || function anonymousType() {};

    if (exports.isFn( superCtor ))
    {
        ctor.super_ = superCtor;
        ctor.prototype = Object.create(superCtor.prototype,
        {
            constructor:
            {
                value: ctor,
                enumerable: false,
                writable: true,
                configurable: true
            }
        });
    }
    else { ctor.prototype = {}; }

    proto = ctor.prototype;

    exports.isFn( descriptor.Identify ) && ( ctor.Identify = descriptor.Identify );

    for (var i = 0, len = typeKeys.length; i < len; i++)
    {
        key = typeKeys[i];
        if (key[0] === '$')
        {
            ctor[key.substring(1)] = descriptor[key];
        }
        else if (!builtin.test(key))
        {
            proto[key] = descriptor[key];
        }
    }
    return ctor;
}

function isRequired() { }

function Trait(props, methods, required)
{
    this._map = props;
    this._methods = methods;
}

Trait.prototype.apply = function( host )
{
    var cursor,
    target = ('prototype' in host)
    ? host.prototype : host;

    for (var i = 0, len = this._methods.length; i < len; i++)
    {
        cursor = this._methods[i];
        target[cursor] = this._map[cursor];
    }
    return host;
}




exports.trait = function trait(descriptor)
{
    var cursor,
    proto = {}
    traitProps = [];

    for (var prop in descriptor)
    {
        if (descriptor.hasOwnProperty(prop))
        {
            cursor = descriptor[prop];
            if (cursor !== isRequired)
            {
                traitProps.push(prop);
                proto[prop] = descriptor[prop];
            }
        }
    }
    return new Trait(proto, traitProps);
}
