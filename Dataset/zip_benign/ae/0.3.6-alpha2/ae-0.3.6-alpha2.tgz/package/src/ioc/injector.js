module.exports = createContainer

    var util      = require('../utility');
    var assert    = require('assert');
    var Q         = require('kew');
    var isPromise = Q.isPromise;

    var Graph    = require('./graph');
    var reflect  = require('./reflect');

    function createContainer(modules, config)
    {
        var _appContext = null,
            _depGraph   = new Graph(),
            _modules    = Object.create(null),
            _archetypes = Object.create(null);

        var AeModule = util.type({

            Construct: function(ns, factory, context)
            {
                this.ns = ns;
                this.factory = factory;
                this.context = context || createContext();
                this.context.module = this;
                this.children = [];
            }

        });

        var _rootModule = new AeModule(null, null, Object.create({},
        {
            resolve:  {  value: resolve         },
            register: {  value: registerModule  },
            invoke:   {  value: invokeAnonymous }
        }));

        var _rootContext = _rootModule.context;




        var injector = {};

        injector.resolve         = resolve;
        injector.define          = define;
        injector.getAppContext   = getAppContext;
        injector.mapDependencies = mapDependencies;
        injector.archetype       = defineArchetype;
        injector.invoke          = invokeAnonymous;



        initialise(modules, config);

        return injector;



        /* Config & Bootstrapping */



        function initialise(modules)
        {
            var definition;

            for (var i = 0, len = modules.length; i < len; i++)
            {
                definition = modules[i];
                defineArchetype(definition.id, definition.definition);
            }
        }

        /*
            ARCHETYPES
        */

        function getArchetype(id)
        {
            return _archetypes[id];
        }

        function defineArchetype(id, descriptor)
        {
            assert(!_archetypes[id],
                  'Ae.archetype: Archetype "' + id + '" already exists');

            var archetype = _archetypes[id] = {};
            descriptor.call(archetype, injector);

            if (archetype.$expose)
                expose(_rootContext, id, archetype.$expose);
        }


        /*
            CONTEXTS & MODULES
        */

        function getAppContext()
        {
            if (!_appContext) {
                _appContext = createContext(_rootContext);
                _appContext.graph = _depGraph;
            }
            return _appContext;
        }


        function createContext(contextBase)
        {
            contextBase || ( contextBase = _rootContext );

            return Object.create(contextBase);
        }


        function expose(context, key, fn)
        {
            assert(!context.hasOwnProperty(key),
            'Ae.expose: Context already possesses method "' + key +'"')

            context[key] = fn;
        }



        /*
            DEFINITION & RESOLUTION
        */

        function define(ident, value, type)
        {
            var namespace,
                dependency,
                parent = this.module,
                archetype = _archetypes[type];

            if (parent && ( namespace = parent.ns ))
                ident = namespace + '.' + ident;

            assert(!_depGraph.isDefined(ident),
                  'Ae.define: Dependency "' + ident + '" already exists');

            /*
                TODO:
                    Replace explicit handling of primitive value types
                    with complete overload via archetype.define.

                    All archetypes ultimately should be able to determine
                    how the arguments are handled, dependencies gathereed,
                    and the dependency value processed.
            */
            if (type !== 'value')
            {
                var annotated = reflect(value),
                    dependencies = annotated.dependencies;

                dependency = _depGraph.define(ident, annotated.value, archetype, parent);

                _depGraph.assignDependencies(ident, dependency, dependencies);
                archetype.define && ( archetype.define(dependency, annotated) );
            }
            else
            {
                dependency = _depGraph.define(ident, value, archetype, parent);
                archetype.define(dependency);
            }
            return this;
        }



        function resolve(ident)
        {
            assert(util.isString(ident),
                  'Ae.resolve: Non-string dependency ID provided');

            var depMap,
                archetype,
                dependency = mapInternal(ident);

            if (dependency)
                return dependency;

            dependency = _depGraph.getDefined(ident) || resolveDynamic(ident);

            assert(dependency,
                  'Ae.resolve: Dependendency "' + ident + '" does not exist');



            archetype = dependency.type;
            assert(archetype,
                  'Ae.resolve: Dependency "' + ident + '" is of unknown type');

            if (dependency.cache)
                return archetype.isTransient
                     ? dependency.cache(context)
                     : dependency.cache;

            var mod = dependency.module;
            var context = mod ? mod.context : _appContext;

            depMap = mapDependencies(dependency.dependencies, context);

            if (!depMap.hasAsync)
                return archetype.get(dependency, depMap.values, context);

            return Q.all(depMap.values)
                    .then(function(values)
                    {
                        return archetype.get(dependency, values, context);
                    });
        }



        function resolveDynamic(ident)
        {
            var cursor,
                aeModule  = _rootModule,
                fragments = ident.split('.'),
                depth     = fragments.length - 1;



            if (!depth)
                return undefined;

            for (var i = 0; i < depth; i++)
            {
                cursor = fragments[i];
                aeModule = aeModule.children[cursor];

                if (!aeModule)
                    throw new Error('Module '+ cursor + 'does not exist');

                if (!aeModule.wasInjected)
                    injectModule(aeModule);
            }

            return _depGraph.get(ident);
        }



        /*
            PACKAGE SPECIFIC
        */

        function registerModule(ident, factory)
        {
            var _module = this.module,
                namespace = _module.ns,
                name = this.name;

            var fullName = name + '.' + ident,
                absoluteIdent = namespace ? namespace + '.' + ident : ident;

            _module.children[ident] = new AeModule(absoluteIdent, factory);
            _module.children[ident].context.name = fullName;

            return this;
        }

        function injectModule(aeModule)
        {
            var ctx = aeModule.context;
            aeModule.factory.call(ctx);
            aeModule.wasInjected = true;
        }



        /*
            HELPER FUNCTIONALITY
        */

        function mapInternal(ident)
        {
            switch(ident)
            {
                case 'app': case 'App':
                    return _appContext;
                case 'injector':
                    return injector;
            }
        }

        function invoke(fn, dependencies, context)
        {
            context || ( context = _appContext );
            return fn.apply(context, dependencies);
        }

        function instantiate(ctor, dependencies)
        {

        }

        function invokeAnonymous(fn, deps)
        {
            var depMap,
                annotation = reflect(fn),
                actual = annotation.value,
                dependencies = deps || annotation.dependencies;

            depMap = mapDependencies(dependencies);
            if (!depMap.hasAsync)
                return actual.apply(actual, depMap.values);

            return Q.all(depMap.values)
                    .then(function(values)
                    {
                        return actual.apply(actual, values);
                    });
        }

        function wrapSync(descriptor)
        {

        }

        function wrapAsync(dependency)
        {

        }

        function mapDependencies(dependencies, context)
        {
            var value,
                valueList = [],
                hasAsync = false,
                count = dependencies.length;

            for (var i = 0, count = dependencies.length; i < count; i++)
            {
                value = resolve(dependencies[i], context);
                valueList.push(value);

                if (!hasAsync && isPromise(value))
                    hasAsync = true;
            }

            return {
                values: valueList,
                hasAsync: hasAsync
            };
        }







    }
