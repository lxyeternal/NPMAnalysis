var assert = require('assert');
var util   = require('../utility');
var Dependency = require('./dependency');

module.exports =

    util.type({

        Construct: function DependencyGraph()
        {
            this._nodes = Object.create(null);
        },

        get: function(id)
        {
            return this._nodes[id];
        },
        getDefined: function(id)
        {
            var node = this._nodes[id];
            return node && node.state ? node : undefined;
        },

        isDefined: function(id)
        {
            var node = this._nodes[id];
            return !!(node && node.state);
        },

        define: function(id, value, provider, package)
        {
            var node = this._nodes[id]
                  || ( this._nodes[id] = new Dependency() );

            assert(!node.state,
                  'Dependency node "'+ id +'" is already defined');

            node.define(value, provider, package);
            return node;
        },


        assignDependencies: function(id, targetNode, dependencies)
        {
            var parentID,
                parentNode;

            for (var i = 0, len = dependencies.length; i < len; i++)
            {
                parentID = dependencies[i];
                parentNode = this._nodes[parentID]
                        || ( this._nodes[parentID] = new Dependency() );

                parentNode.dependents.push(id);
                targetNode.dependencies.push(parentID);
            }

            assert(!this._isCyclical(id),
                  'Cyclical dependency: ' + id );
        },


        /*
            Niave cycle check.

            Since dependent nodes are maintained for runtime dependency
            destruction, this simply traverses them recursively and
            ensures it doesn't encounter itself.

            Should work just fine, and is quite a bit faster than any topological
            solution. If some nasty edge case pops up, it can be replaced with
            some Tarjans algorithm derivative, most suitably, probably Johnsons
            algorithm.
        */

        _isCyclical: function(searchID)
        {
            var self = this;
            return walkDependents(searchID);

            function walkDependents(id)
            {
                var cursor,
                    dependents,
                    node = self._nodes[id];

                assert(node, 'Dependency "' + id + '" does not exist');
                dependents = node.dependents;

                for ( var i = 0, len = dependents.length; i < len; i++)
                {
                    cursor = dependents[i];
                    if (cursor === searchID || walkDependents(cursor))
                        return true;
                }
                return false;
            }
        }

    });
