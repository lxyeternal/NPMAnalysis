var assert   = require('assert');
var isFn     = require('../utility').isFn;
var isArray  = require('../utility').isArray;
var isString = require('../utility').isString;

var seperatorRgx = /^\s+|,\s+|\s+$/;
var stripCommentRgx = /((\/\/.*$)|(\/\*[\s\S]*?\*\/))/mg;

module.exports = reflect;

    function reflect( dependency )
    {
        var result = {};

        if (isArray( dependency ))
        {
            result.value = dependency.pop();
            result.dependencies = dependency;
        }
        else if (isFn( dependency ))
        {
            result.value        = dependency;
            result.dependencies = dependency.$uses || reflect.params(dependency);
        }
        else
        {
            result.value = dependency;
            result.dependencies = [];
        }
        return result;
    }

    reflect.params = function( fn )
    {
        assert(isFn( fn ),
              'Ae.reflect: Invalid function provided');

        var src = fn.toString && fn.toString();

        assert(isString( src ),
              'Ae.reflect: Failed to reflect dependency source');

        src = src.replace(stripCommentRgx, '');
        var paramStr = src.substring(src.indexOf('(')+1, src.indexOf(')'));

        return (paramStr.length)
             ?  paramStr.split(seperatorRgx)
             :  [];
    }
