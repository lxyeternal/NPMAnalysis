var util = require('../utility');

module.exports = util.type({

    state: 0,
    value: null,
    cache: null,
    type: null,
    module: null,
    context: null,

    Construct: function Dependency()
    {
        this.dependencies = [];
        this.dependents = [];
    },

    define: function(value, archetype, aeModule)
    {
        this.value = value;
        this.type = archetype;
        this.module = aeModule;
        this.state = 1;
    },

    setContext: function(content)
    {
        this.context = context;
    }
});
