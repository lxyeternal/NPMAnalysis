var isFn = require('../utility').isFn;
module.exports = SingletonProvider

    function SingletonProvider(injector)
    {
        this.get = function(node, dependencies)
        {
            if (!node.cache)
            {
                var value = node.value;
                node.cache = isFn(value)
                           ? value.apply(node.context, dependencies)
                           : value;

            }
            return node.cache;
        };

        this.$expose = function(id, value)
        {
            return injector.define.call(this, id, value, 'singleton');
        }
    }
