module.exports =

    function ValueDependency(injector)
    {
        this.isTransient = false;

        this.get = function(node, dependencies)
        {
            return node.cache;
        }

        this.define = function(node)
        {
            node.cache = node.value;
        }

        this.$expose = function(id, value)
        {
            return injector.define.call(this, id, value, 'value');
        }
    }
