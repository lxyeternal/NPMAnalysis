module.exports = [
    { id: 'value'    , definition: require('./value') },
    { id: 'singleton', definition: require('./singleton') },
    { id: 'factory',   definition: require('./factory') },
    { id: 'type', definition: require('./type') }
];
