module.exports = FactoryDependency

    function FactoryDependency(injector, cache)
    {
        this.get = function(node, dependencies)
        {
            return node.value.apply(node.context, dependencies);
        }

        this.$expose = function(id, descriptor)
        {
            return injector.define.call(this, id, descriptor, 'factory');
        }
    }
