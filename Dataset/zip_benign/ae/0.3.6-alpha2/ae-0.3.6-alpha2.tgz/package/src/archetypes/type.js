var util = require('../utility');

module.exports =

    function TypeDependency(injector)
    {
        function createAeType(definition)
        {
            var type = util.type(definition);
            type.prototype.constructor = type;
            return type;
        }

        function getConstructor(value, dependencies)
        {
            var definition = util.isFn(value)
                           ? value.apply(value, dependencies)
                           : value;

            if (util.isObject(definition))
                return createAeType(definition);

            return definition;
        }

        this.isTransient = true;
        this.get = function(node, dependencies)
        {
            var DepType = getConstructor(node.value, dependencies),
                cache;

            if (DepType.instantiate)
                cache = node.cache = function() { return new DepType(); }
            else
                cache = node.cache = function() { return DepType; };

            return cache();
        }

        this.$expose = function(id, descriptor)
        {
            injector.define.call(this, id, descriptor, 'type');
        }
    }
