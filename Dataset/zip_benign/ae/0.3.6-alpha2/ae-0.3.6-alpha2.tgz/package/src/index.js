var assert         = require('assert');
var archetypes     = require('./archetypes');
var TApplication   = require('./traits/app');
var createInjector = require('./ioc/injector.js');

var Ae = module.exports = require('./utility');



var _entities = {},
    _channels = {};


Ae.Injector = function(id)
{
    assert(!_entities.hasOwnProperty(id),
          'Ae.App: Entity "' + id + '" already exists');

    return createInjector(archetypes, { standalone: false });
}

Ae.App = function(id, opts)
{
    assert(!_entities.hasOwnProperty(id),
          'Ae.App: Entity "' + id +'" already exists');

    var injector = createInjector(archetypes, { standalone: false }),
        context  = injector.getAppContext();

    opts || ( opts = {} );

    context.__path = Ae.isString(opts.path)
                   ? opts.path
                   : process.cwd();

    context.__parent = opts.parent || null;

    TApplication.apply(context);

    return _entities[id] = context;
};
