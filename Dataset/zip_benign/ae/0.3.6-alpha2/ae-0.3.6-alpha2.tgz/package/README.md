![alt text](https://api.travis-ci.org/MateriaIO/Ae.svg?branch=master "Build Status")  

# Aether

Aether is a lightweight Dependency Injection library, intended for use in both desktop and web applications.

Providing a powerful injector, Aether encourages the writing of loosely coupled, reusable code that scales superbly as your project grows.

> Note: Aether is still in alpha. While currently passing a lengthy set of unit tests, some instability is to be expected. The last set of interface breaking changes are scheduled to occur with the 0.4 revision, after which the interface can be assumed to be stable.

### Features
- Lightweight & performant DI
- Browser and Node/IO support
- Transparent support of asynchronous dependencies
- Namespaced modules, with nesting
- Traits


## Installation
```
npm install ae
```

For use in the browser, first ensure browserify is installed:
```
npm install -g browserify
```
then run the following command
```
npm run build-browser
```
to generate a browser compliant build (build/ae-web.js)


## Getting Started
```javascript
var Ae  = require('ae'),
    app = Ae.App('myApp');

app.value('msgFormat', 'Hello, {0}')
   .value('recipient', 'world')
   .factory('greeter',
   [
       'msgFormat',
       'recipient',
       function(msgFormat, recipient)
       {
           return Ae.supplant(msgFormat, [ recipient ]);
       }
    ]);

app.invoke([
    'greeter',
    function(greeting)
    {
        console.log(greeting); //> Hello, World
    }
]);
```
