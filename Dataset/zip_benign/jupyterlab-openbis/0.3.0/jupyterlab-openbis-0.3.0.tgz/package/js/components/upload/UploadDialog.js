import React, { useContext } from 'react';
import { UploadDialogContext } from '../../context/uploaddialog';
import { Input } from '../common/Input';
import { Table } from '../common/Table';
import { Button } from '../common/Button';
import { Row } from '../common/Row';
import { SelectDataSetType, UpdateProperty, UpdateTargetEntity, SelectDataSet, UnselectDataSet, SelectFile, UnselectFile, GetDirectoryContent, GoToParentDirectory, Upload, } from '../../actions/uploaddialog';
const folder = (React.createElement("svg", { xmlns: 'http://www.w3.org/2000/svg', width: '16', viewBox: '0 0 24 24' },
    React.createElement("path", { fill: '#616161', d: 'M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z' })));
const notebook = (React.createElement("svg", { xmlns: 'http://www.w3.org/2000/svg', width: '16', viewBox: '0 0 22 22' },
    React.createElement("g", { fill: '#EF6C00' },
        React.createElement("path", { d: 'M18.7 3.3v15.4H3.3V3.3h15.4m1.5-1.5H1.8v18.3h18.3l.1-18.3z' }),
        React.createElement("path", { d: 'M16.5 16.5l-5.4-4.3-5.6 4.3v-11h11z' }))));
const file = (React.createElement("svg", { xmlns: 'http://www.w3.org/2000/svg', width: '16', viewBox: '0 0 22 22' },
    React.createElement("path", { fill: '#616161', d: 'M19.3 8.2l-5.5-5.5c-.3-.3-.7-.5-1.2-.5H3.9c-.8.1-1.6.9-1.6 1.8v14.1c0 .9.7 1.6 1.6 1.6h14.2c.9 0 1.6-.7 1.6-1.6V9.4c.1-.5-.1-.9-.4-1.2zm-5.8-3.3l3.4 3.6h-3.4V4.9zm3.9 12.7H4.7c-.1 0-.2 0-.2-.2V4.7c0-.2.1-.3.2-.3h7.2v4.4s0 .8.3 1.1c.3.3 1.1.3 1.1.3h4.3v7.2s-.1.2-.2.2z' })));
export const UploadDialog = (props) => {
    const [state, dispatch] = useContext(UploadDialogContext);
    const propertyAssignments = state.dataSetType == null ? [] : state.dataSetType.propertyAssignments;
    if (!state.panel.model.metadata.keys().includes('datasets')) {
        state.panel.model.metadata.set('datasets', {});
    }
    let datasets;
    if (state.panel.model.metadata.keys().includes('datasets')) {
        datasets = Object.keys(state.panel.model.metadata.get('datasets'));
    }
    else {
        datasets = [];
    }
    const directories = state.currentDirectoryContent.filter((entry) => entry.type === 'directory');
    const files = state.currentDirectoryContent.filter((entry) => entry.type !== 'directory');
    const uploadActive = state.error == '' && state.selectedFiles.length > 0 && !state.uploadInProgress;
    return (React.createElement("div", { id: 'jupyterlab-openbis-upload-dialog', className: 'jupyterlab-openbis-dialog' },
        state.error !== '' && React.createElement("div", { className: 'main-error' }, state.error),
        state.error === '' && state.connection != null && (React.createElement("div", { className: 'main-info' },
            "Connected to openBIS '",
            state.connection.name,
            "' (",
            state.connection.url,
            ")")),
        React.createElement("div", { className: 'row' },
            React.createElement("div", { className: 'label' }, "Select dataset type"),
            React.createElement("div", { className: 'select' },
                React.createElement("select", { onChange: (e) => dispatch(new SelectDataSetType(e.target.value)) }, state.dataSetTypes.map((t) => (React.createElement("option", { key: t.code, value: t.permId },
                    t.permId,
                    t.description != null && t.description.length > 0 ? ': ' + t.description : '')))),
                React.createElement("div", { className: 'message-info' }))),
        propertyAssignments.map((prop) => (React.createElement("div", { className: 'row', key: prop.code },
            React.createElement("div", { className: 'label' }, prop.label),
            React.createElement(Input, { context: UploadDialogContext, updateAction: (value) => new UpdateProperty(prop.code, value), placeholder: prop.description, field: (s) => s.properties[prop.code] })))),
        React.createElement("div", { className: 'row' },
            React.createElement("div", { className: 'label' }, "Sample/experiment identifier"),
            React.createElement(Input, { context: UploadDialogContext, updateAction: (value) => new UpdateTargetEntity(value), placeholder: 'Sample or experiment identifier/permId to attach this dataset to', field: (s) => s.targetEntity })),
        datasets.length > 0 && state.error === '' && (React.createElement(React.Fragment, null,
            React.createElement("div", { className: 'header' }, "Parent datasets"),
            React.createElement(Table, { className: 'openbis-table openbis-table-bordered openbis-table-striped upload-table' }, datasets.map((dataset, index) => (React.createElement(Row, { key: index, growIndex: 1 },
                React.createElement("input", { type: 'checkbox', checked: state.selectedDataSets.includes(dataset), onChange: (e) => dispatch(e.target.checked ? new SelectDataSet(dataset) : new UnselectDataSet(dataset)) }),
                React.createElement("div", { className: 'text-left' }, dataset))))))),
        state.currentDirectoryContent != null && state.currentDirectoryContent.length > 0 && state.error == '' && (React.createElement(React.Fragment, null,
            React.createElement("div", { className: 'header' }, "Files to upload"),
            React.createElement(Table, { className: 'openbis-table openbis-table-bordered openbis-table-striped upload-table' },
                state.currentDirectory !== '' && (React.createElement(Row, { growIndex: 2 },
                    React.createElement("div", null),
                    React.createElement("div", { className: 'pointer', onClick: () => dispatch(new GoToParentDirectory()) }, folder),
                    React.createElement("div", { className: 'pointer text-left', onClick: () => dispatch(new GoToParentDirectory()) }, ".."),
                    React.createElement("div", null))),
                directories.map((entry, index) => (React.createElement(Row, { key: index, growIndex: 2 },
                    React.createElement("div", null),
                    React.createElement("div", { className: 'pointer', onClick: () => dispatch(new GetDirectoryContent(entry.path)) }, folder),
                    React.createElement("div", { className: 'pointer text-left', onClick: () => dispatch(new GetDirectoryContent(entry.path)) }, entry.name),
                    React.createElement("div", null)))),
                files.map((entry, index) => (React.createElement(Row, { key: index, growIndex: 2 },
                    React.createElement("input", { type: 'checkbox', checked: state.selectedFiles.includes(entry.path), onChange: (e) => dispatch(e.target.checked ? new SelectFile(entry.path) : new UnselectFile(entry.path)) }),
                    entry.type === 'notebook' ? notebook : file,
                    React.createElement("div", { className: 'text-left' }, entry.name),
                    React.createElement("div", null, entry.size))))))),
        React.createElement(Button, { context: UploadDialogContext, isActive: uploadActive, commandAction: Upload }, "Upload"),
        React.createElement("div", { className: 'upload-message' }, state.uploadInProgress ? 'Uploading dataset' : state.uploadMessage)));
};
