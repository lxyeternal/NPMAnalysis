import { FunctionComponent } from 'react';
import { ConnectionDialogState } from '../../context/connectiondialog';
import { ContextProviderProps } from '../../common';
export declare const ConnectionDialogContextProvider: FunctionComponent<ContextProviderProps<ConnectionDialogState>>;
