import React, { useContext } from 'react';
import { MessageType } from '../../common';
export const Input = (props) => {
    const { updateAction, commandAction, placeholder, field, disabled } = props;
    const [state, dispatch] = useContext(props.context);
    const { value, message, messageType } = field(state);
    const handleEnter = (e) => {
        e.stopPropagation();
        if (e.key === 'Enter' && commandAction != null && disabled(state, value)) {
            dispatch(new commandAction());
        }
    };
    const messageClass = messageType === MessageType.ERROR ? 'message-error' : messageType === MessageType.SUCCESS ? 'message-success' : 'message-info';
    return (React.createElement("div", { className: 'input' },
        React.createElement("input", { type: 'text', placeholder: placeholder, value: value, onChange: (e) => dispatch(updateAction(e.target.value)), onKeyDown: handleEnter }),
        React.createElement("div", { className: messageClass }, message)));
};
Input.defaultProps = {
    placeholder: '',
    disabled: (s, v) => false,
};
