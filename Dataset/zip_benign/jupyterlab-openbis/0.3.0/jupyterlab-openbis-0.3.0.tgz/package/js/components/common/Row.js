import * as React from 'react';
export const Row = (props) => (React.createElement("tr", null, React.Children.map(props.children, (c, index) => (React.createElement("td", { key: index, className: props.growIndex === index ? 'wide' : '' }, c)))));
