import React, { useContext } from 'react';
export const Button = (props) => {
    const { commandAction, isActive } = props;
    const [_, dispatch] = useContext(props.context);
    return (React.createElement("button", { disabled: !isActive, onClick: () => dispatch(new commandAction()) }, props.children));
};
