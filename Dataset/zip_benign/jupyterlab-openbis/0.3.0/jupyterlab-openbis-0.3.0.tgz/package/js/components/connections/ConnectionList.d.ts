/// <reference types="react" />
export declare const ConnectionList: (props: any) => JSX.Element;
