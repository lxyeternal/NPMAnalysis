import * as React from 'react';
interface RowProps {
    growIndex?: number;
}
export declare const Row: (props: React.PropsWithChildren<RowProps>) => JSX.Element;
export {};
