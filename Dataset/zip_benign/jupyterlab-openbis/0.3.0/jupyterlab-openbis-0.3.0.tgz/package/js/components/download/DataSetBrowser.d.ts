/// <reference types="react" />
export declare const DataSetBrowser: (props: any) => JSX.Element;
