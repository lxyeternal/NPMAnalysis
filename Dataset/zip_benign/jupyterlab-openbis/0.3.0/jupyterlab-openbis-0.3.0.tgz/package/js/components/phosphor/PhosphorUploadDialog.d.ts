/// <reference types="react" />
import { PhosphorBaseDialog } from './PhosphorBaseDialog';
import { NotebookPanel } from '@jupyterlab/notebook';
export declare class PhosphorUploadDialog extends PhosphorBaseDialog {
    constructor(panel: NotebookPanel);
    render(): JSX.Element;
}
