import React from 'react';
export const Table = ({ className, children, columns = [], headDisabled = false }) => (React.createElement("table", { className: className },
    !headDisabled && (React.createElement("thead", null,
        React.createElement("tr", null, columns.map((col, index) => (React.createElement("th", { key: index }, col)))))),
    React.createElement("tbody", null, children)));
