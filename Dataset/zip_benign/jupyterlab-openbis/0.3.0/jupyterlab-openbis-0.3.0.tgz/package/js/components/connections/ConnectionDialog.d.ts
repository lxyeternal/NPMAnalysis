/// <reference types="react" />
export declare const ConnectionDialog: (props: any) => JSX.Element;
