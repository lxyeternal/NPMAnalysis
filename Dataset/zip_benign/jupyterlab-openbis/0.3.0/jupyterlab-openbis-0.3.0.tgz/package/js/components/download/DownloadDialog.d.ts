/// <reference types="react" />
export declare const DownloadDialog: (props: any) => JSX.Element;
