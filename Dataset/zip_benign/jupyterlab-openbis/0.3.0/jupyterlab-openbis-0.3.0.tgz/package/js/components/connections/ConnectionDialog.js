import React, { useContext } from 'react';
import { ConnectionCreation } from './ConnectionCreation';
import { WorkingDir } from './WorkingDir';
import { ConnectionList } from './ConnectionList';
import { ConnectionDialogContext } from '../../context/connectiondialog';
export const ConnectionDialog = (props) => {
    const [state, dispatch] = useContext(ConnectionDialogContext);
    return (React.createElement("div", { className: 'openbis-flex-vertical' },
        state.connections.length !== 0 && (React.createElement(React.Fragment, null,
            React.createElement("div", { className: 'openbis-connection-dialog-header' }, "Choose connection"),
            React.createElement(ConnectionList, null))),
        React.createElement("div", { className: 'openbis-connection-dialog-header' }, "Create new connection"),
        React.createElement(ConnectionCreation, null),
        React.createElement("div", { className: 'openbis-connection-dialog-header' }, "Your working directory"),
        React.createElement(WorkingDir, null)));
};
