import React, { useContext } from 'react';
import { Table } from '../common/Table';
import { Row } from '../common/Row';
import { ConnectionDialogContext } from '../../context/connectiondialog';
import { UpdateProposedConnection } from '../../actions/connectiondialog';
import { CreateConnection } from '../../actions/connectiondialog';
function isCreationDisabled(conn) {
    return conn.name === '' || conn.url === '' || conn.user === '' || conn.password === '';
}
export const ConnectionCreation = (props) => {
    const [context, dispatch] = useContext(ConnectionDialogContext);
    const conn = context.proposedConnection;
    const handleEnter = (conn) => (e) => {
        e.stopPropagation();
        if (e.key === 'Enter' && !isCreationDisabled(conn)) {
            dispatch(new CreateConnection());
        }
    };
    return (React.createElement(Table, { columns: ['Name', 'URL', 'Username', 'Password'], className: 'openbis-table openbis-connection-creation' },
        React.createElement(Row, null,
            React.createElement("input", { type: 'text', placeholder: 'openBIS instance name', value: conn.name, onChange: (e) => dispatch(new UpdateProposedConnection('name', e.target.value)), onKeyDown: handleEnter(conn) }),
            React.createElement("input", { type: 'text', placeholder: 'https://openbis.domain:port', value: conn.url, onChange: (e) => dispatch(new UpdateProposedConnection('url', e.target.value)), onKeyDown: handleEnter(conn) }),
            React.createElement("input", { type: 'text', placeholder: 'username', value: conn.user, onChange: (e) => dispatch(new UpdateProposedConnection('user', e.target.value)), onKeyDown: handleEnter(conn) }),
            React.createElement("input", { type: 'password', placeholder: 'password', value: conn.password, onChange: (e) => dispatch(new UpdateProposedConnection('password', e.target.value)), onKeyDown: handleEnter(conn) })),
        React.createElement(Row, null,
            React.createElement("div", null),
            React.createElement("div", null),
            React.createElement("div", { className: 'openbis-flex-vertical' },
                React.createElement("span", { className: 'openbis-error' }, conn.error)),
            React.createElement("div", { className: 'openbis-flex-vertical' },
                React.createElement("button", { disabled: isCreationDisabled(conn), onClick: () => dispatch(new CreateConnection()) }, "Create")))));
};
