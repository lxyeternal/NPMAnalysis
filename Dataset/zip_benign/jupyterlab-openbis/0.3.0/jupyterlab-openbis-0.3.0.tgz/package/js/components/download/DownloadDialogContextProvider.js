import React, { useReducer, useEffect, useLayoutEffect } from 'react';
import { DownloadDialogContext } from '../../context/downloaddialog';
import { combineMiddlewares } from '../../common';
import { reducer } from '../../reducers/downloaddialog';
import { apiMiddleware } from '../../middleware/api';
import { downloadDialogMiddleware } from '../../middleware/downloaddialog';
import { OpenDialog } from '../../actions/state';
export const DownloadDialogContextProvider = (props) => {
    const [state, dispatch] = useReducer(reducer, props.initialState);
    const enhancedDispatch = combineMiddlewares(state, dispatch, props.getDispatch, apiMiddleware, downloadDialogMiddleware);
    useLayoutEffect(() => {
        props.setDispatch(enhancedDispatch);
    });
    useEffect(() => {
        props.getDispatch()(new OpenDialog(props.id));
    }, []);
    return React.createElement(DownloadDialogContext.Provider, { value: [state, enhancedDispatch] }, props.children);
};
