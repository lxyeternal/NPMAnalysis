import React from 'react';
import { Dispatch } from '../../common';
declare type ButtonProps<State> = {
    context: React.Context<[State, Dispatch]>;
    commandAction?: new () => any;
    isActive: boolean;
};
export declare const Button: <State>(props: React.PropsWithChildren<ButtonProps<State>>) => JSX.Element;
export {};
