import { ReactWidget } from '@jupyterlab/apputils';
import { CloseDialog } from '../../actions/state';
export class PhosphorBaseDialog extends ReactWidget {
    constructor(panel) {
        super();
        this.setDispatch = (d) => (this.dispatch = d);
        this.getDispatch = () => this.dispatch;
        this.panel = panel;
    }
    onAfterAttach(msg) {
        super.onAfterAttach(msg);
    }
    getValue() {
        this.dispatch(new CloseDialog(this.panel.id));
    }
    onBeforeDetach(msg) {
        super.onBeforeDetach(msg);
    }
}
