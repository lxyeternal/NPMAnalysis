import { FunctionComponent } from 'react';
import { DownloadDialogState } from '../../context/downloaddialog';
import { ContextProviderProps } from '../../common';
export declare const DownloadDialogContextProvider: FunctionComponent<ContextProviderProps<DownloadDialogState>>;
