import React, { useReducer, useEffect, useLayoutEffect } from 'react';
import { UploadDialogContext } from '../../context/uploaddialog';
import { combineMiddlewares } from '../../common';
import { reducer } from '../../reducers/uploaddialog';
import { apiMiddleware } from '../../middleware/api';
import { uploadDialogMiddleware } from '../../middleware/uploaddialog';
import { OpenDialog } from '../../actions/state';
export const UploadDialogContextProvider = (props) => {
    const [state, dispatch] = useReducer(reducer, props.initialState);
    const enhancedDispatch = combineMiddlewares(state, dispatch, props.getDispatch, apiMiddleware, uploadDialogMiddleware);
    useLayoutEffect(() => {
        props.setDispatch(enhancedDispatch);
    });
    useEffect(() => {
        props.getDispatch()(new OpenDialog(props.id));
    }, []);
    return React.createElement(UploadDialogContext.Provider, { value: [state, enhancedDispatch] }, props.children);
};
