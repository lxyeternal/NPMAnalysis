import * as React from 'react';
import { DownloadDialog } from '../download/DownloadDialog';
import { PhosphorBaseDialog } from './PhosphorBaseDialog';
import { globalState, initialState } from '../../context/downloaddialog';
import { DownloadDialogContextProvider } from '../download/DownloadDialogContextProvider';
export class PhosphorDownloadDialog extends PhosphorBaseDialog {
    constructor(panel) {
        super(panel);
        if (!(this.panel.id in globalState)) {
            globalState[this.panel.id] = initialState;
            globalState[this.panel.id].panel = this.panel;
        }
    }
    render() {
        return (React.createElement(DownloadDialogContextProvider, { id: this.panel.id, initialState: globalState[this.panel.id], setDispatch: this.setDispatch, getDispatch: this.getDispatch },
            React.createElement(DownloadDialog, null)));
    }
}
