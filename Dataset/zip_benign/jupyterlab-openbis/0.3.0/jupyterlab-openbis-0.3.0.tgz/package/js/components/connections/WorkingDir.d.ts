/// <reference types="react" />
export declare const WorkingDir: (props: any) => JSX.Element;
