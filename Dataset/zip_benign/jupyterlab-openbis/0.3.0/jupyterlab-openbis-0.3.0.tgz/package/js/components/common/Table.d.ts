import { FunctionComponent } from 'react';
declare type TableProps = {
    columns?: string[];
    className: string;
    headDisabled?: boolean;
};
export declare const Table: FunctionComponent<TableProps>;
export {};
