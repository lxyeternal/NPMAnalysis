import * as React from 'react';
import { ConnectionDialog } from '../connections/ConnectionDialog';
import { PhosphorBaseDialog } from './PhosphorBaseDialog';
import { globalState, initialState } from '../../context/connectiondialog';
import { ConnectionDialogContextProvider } from '../connections/ConnectionDialogContextProvider';
export class PhosphorConnectionDialog extends PhosphorBaseDialog {
    constructor(panel) {
        super(panel);
        if (!(this.panel.id in globalState)) {
            globalState[this.panel.id] = initialState;
        }
    }
    render() {
        return (React.createElement(ConnectionDialogContextProvider, { id: this.panel.id, initialState: globalState[this.panel.id], setDispatch: this.setDispatch, getDispatch: this.getDispatch },
            React.createElement(ConnectionDialog, null)));
    }
}
