/// <reference types="react" />
export declare const ConnectionCreation: (props: any) => JSX.Element;
