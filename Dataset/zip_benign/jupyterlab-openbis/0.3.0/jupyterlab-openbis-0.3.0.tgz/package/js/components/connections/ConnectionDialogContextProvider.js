import React, { useReducer, useLayoutEffect, useEffect } from 'react';
import { ConnectionDialogContext } from '../../context/connectiondialog';
import { combineMiddlewares } from '../../common';
import { reducer } from '../../reducers/connectiondialog';
import { apiMiddleware } from '../../middleware/api';
import { connectionDialogMiddleware } from '../../middleware/connectiondialog';
import { ListConnections } from '../../actions/connectiondialog';
export const ConnectionDialogContextProvider = (props) => {
    const [state, dispatch] = useReducer(reducer, props.initialState);
    const enhancedDispatch = combineMiddlewares(state, dispatch, props.getDispatch, apiMiddleware, connectionDialogMiddleware);
    useLayoutEffect(() => {
        props.setDispatch(enhancedDispatch);
    });
    useEffect(() => {
        props.getDispatch()(new ListConnections(null));
    }, []);
    return React.createElement(ConnectionDialogContext.Provider, { value: [state, enhancedDispatch] }, props.children);
};
