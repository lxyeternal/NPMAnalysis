import React from 'react';
import { InputField } from '../../common';
import { Dispatch } from '../../common';
declare type InputProps<State> = {
    context: React.Context<[State, Dispatch]>;
    updateAction: (value: string) => any;
    commandAction?: new () => any;
    placeholder?: string;
    field: (state: State) => InputField;
    disabled?: (state: State, value: string) => boolean;
};
export declare const Input: {
    <State>(props: React.PropsWithChildren<InputProps<State>>): JSX.Element;
    defaultProps: {
        placeholder: string;
        disabled: (s: any, v: any) => boolean;
    };
};
export {};
