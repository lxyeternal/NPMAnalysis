import React, { useContext } from 'react';
import { DownloadDialogContext } from '../../context/downloaddialog';
import { UpdateEntityId, ShowDataSets, UpdatePermId, DownloadPermId, UpdatePath } from '../../actions/downloaddialog';
import { Input } from '../common/Input';
import { Button } from '../common/Button';
import { DataSetBrowser } from './DataSetBrowser';
export const DownloadDialog = (props) => {
    const [state, dispatch] = useContext(DownloadDialogContext);
    return (React.createElement("div", { id: 'jupyterlab-openbis-download-dialog', className: 'jupyterlab-openbis-dialog' },
        state.error !== '' && React.createElement("div", { className: 'main-error' }, state.error),
        state.error === '' && state.connection != null && (React.createElement("div", { className: 'main-info' },
            "Connected to openBIS '",
            state.connection.name,
            "' (",
            state.connection.url,
            ")")),
        React.createElement("div", { className: 'row' },
            React.createElement("div", { className: 'label' }, "Entity identifier / permId"),
            React.createElement(Input, { context: DownloadDialogContext, updateAction: (value) => new UpdateEntityId(value), commandAction: ShowDataSets, placeholder: 'Sample or experiment identifier / permId', field: (s) => s.entityId, disabled: (state, value) => state.error === '' && value !== '' }),
            React.createElement(Button, { context: DownloadDialogContext, isActive: state.error === '' && state.entityId.value !== '', commandAction: ShowDataSets }, "Show datasets")),
        React.createElement(DataSetBrowser, null),
        React.createElement("div", { className: 'row' },
            React.createElement("div", { className: 'label' }, "Enter dataset permId directly"),
            React.createElement(Input, { context: DownloadDialogContext, updateAction: (value) => new UpdatePermId(value), commandAction: DownloadPermId, placeholder: 'Dataset permId', field: (s) => s.dataSetId, disabled: (state, value) => state.error === '' && value !== '' }),
            React.createElement(Button, { context: DownloadDialogContext, isActive: state.error === '' && state.dataSetId.value !== '' && state.downloadingActive, commandAction: DownloadPermId }, "Download")),
        React.createElement("div", { className: 'row' },
            React.createElement("div", { className: 'label' }, "Download data to path"),
            React.createElement(Input, { context: DownloadDialogContext, updateAction: (value) => new UpdatePath(value), field: (s) => s.downloadPath }))));
};
