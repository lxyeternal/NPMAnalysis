/// <reference types="react" />
export declare const UploadDialog: (props: any) => JSX.Element;
