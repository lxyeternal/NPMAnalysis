/// <reference types="react" />
import { PhosphorBaseDialog } from './PhosphorBaseDialog';
import { NotebookPanel } from '@jupyterlab/notebook';
export declare class PhosphorConnectionDialog extends PhosphorBaseDialog {
    constructor(panel: NotebookPanel);
    render(): JSX.Element;
}
