import React, { useContext } from 'react';
import { Table } from '../common/Table';
import { Row } from '../common/Row';
import { ConnectionDialogContext } from '../../context/connectiondialog';
import { UpdateConnection, SelectConnection } from '../../actions/connectiondialog';
import { Connect, DeleteConnection } from '../../actions/connectiondialog';
const connectDisabled = (conn) => conn.username.length === 0 || conn.password.length === 0;
function connectionStatus(conn) {
    const className = conn.status === 'connected' ? 'openbis-connection-status-connected' : 'openbis-connection-status-not-connected';
    return React.createElement("span", { className: className },
        " ",
        conn.status,
        " ");
}
export const ConnectionList = (props) => {
    const [state, dispatch] = useContext(ConnectionDialogContext);
    const handleEnter = (index) => (e) => {
        e.stopPropagation();
        if (e.key === 'Enter' && !connectDisabled(state.connections[index])) {
            dispatch(new Connect(index));
        }
    };
    return (React.createElement(Table, { columns: ['', 'Name', 'URL', 'Status', 'Credentials'], className: 'openbis-table openbis-table-bordered openbis-table-striped openbis-connection-list' }, state.connections.map((conn, index) => (React.createElement(Row, { key: index },
        React.createElement("input", { type: 'radio', name: 'connection', checked: state.selected === index, onChange: () => dispatch(new SelectConnection(index)) }),
        React.createElement("div", { className: 'openbis-flex-vertical' },
            React.createElement("span", null, conn.name)),
        React.createElement("div", { className: 'openbis-flex-vertical' },
            React.createElement("span", null, conn.url)),
        React.createElement("div", { className: 'openbis-flex-vertical' },
            connectionStatus(conn),
            state.errors[index] !== '' && React.createElement("span", { className: 'openbis-error' }, state.errors[index])),
        React.createElement("div", { className: 'openbis-flex-vertical' },
            React.createElement("input", { type: 'text', placeholder: 'username', value: conn.username, onChange: (e) => dispatch(new UpdateConnection(index, 'user', e.target.value)), onKeyDown: handleEnter(index) }),
            React.createElement("input", { type: 'password', placeholder: 'password', value: conn.password, onChange: (e) => dispatch(new UpdateConnection(index, 'password', e.target.value)), onKeyDown: handleEnter(index) }),
            React.createElement("div", { className: 'openbis-flex-horizontal' },
                React.createElement("button", { className: 'connect-button', onClick: () => dispatch(new Connect(index)), disabled: connectDisabled(conn) }, "Connect"),
                React.createElement("button", { className: 'delete-button', onClick: () => dispatch(new DeleteConnection(index)) }, "Delete"))))))));
};
