import React, { useContext } from 'react';
import { DownloadDialogContext } from '../../context/downloaddialog';
import { DownloadSelected, SelectDataSet, UnselectDataSet, PreviousPage, NextPage } from '../../actions/downloaddialog';
import { Table } from '../common/Table';
import { Row } from '../common/Row';
import { Button } from '../common/Button';
import classNames from 'classnames';
export const DataSetBrowser = (props) => {
    const [state, dispatch] = useContext(DownloadDialogContext);
    if (state.result == null || state.result.totalCount === 0) {
        return null;
    }
    const { start_with, count, totalCount } = state.result;
    const prevClasses = classNames('position', 'link', { disabled: start_with === 0, 'not-visible': totalCount <= 5 });
    const nextClasses = classNames('position', 'link', { disabled: start_with + count >= totalCount, 'not-visible': totalCount <= 5 });
    const positionClasses = classNames('position', { 'not-visible': totalCount <= 5 });
    const message = state.downloadQueue.length > 0
        ? 'Downloading (' + (state.selected.length - state.downloadQueue.length + 1) + '/' + state.selected.length + ')'
        : state.selected.length + ' datasets selected';
    return (React.createElement("div", { className: 'browser' },
        React.createElement(Table, { columns: ['', 'permId', 'Name', 'Type', 'Registration date', 'Status', 'Size'], className: 'openbis-table openbis-table-bordered openbis-table-striped' }, state.result.dataSets.map((ds, index) => (React.createElement(Row, { key: index },
            React.createElement("input", { type: 'checkbox', checked: state.selected.includes(ds.permId), onChange: (e) => dispatch(e.target.checked ? new SelectDataSet(ds.permId) : new UnselectDataSet(ds.permId)) }),
            React.createElement("div", null, ds.permId),
            React.createElement("div", null, ds.$NAME),
            React.createElement("div", null, ds.type),
            React.createElement("div", null, ds.registrationDate),
            React.createElement("div", null, ds.status),
            React.createElement("div", null, ds.size))))),
        React.createElement("div", { className: 'footer' },
            React.createElement("div", { className: prevClasses, onClick: () => dispatch(new PreviousPage()) }, '<<  '),
            React.createElement("div", { className: positionClasses }, `${state.result.start_with + 1}-${state.result.start_with + state.result.count}/${state.result.totalCount}`),
            React.createElement("div", { className: nextClasses, onClick: () => dispatch(new NextPage()) }, ' >>'),
            React.createElement("div", { className: 'message' }, message),
            React.createElement(Button, { context: DownloadDialogContext, isActive: state.error === '' && state.selected.length > 0 && state.downloadingActive, commandAction: DownloadSelected }, "Download selected"))));
};
