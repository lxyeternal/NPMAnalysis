import React, { useContext } from 'react';
import { Table } from '../common/Table';
import { Row } from '../common/Row';
import { ConnectionDialogContext } from '../../context/connectiondialog';
import { UpdateWorkingDir, ResetWorkingDir } from '../../actions/connectiondialog';
export const WorkingDir = (props) => {
    const [state, dispatch] = useContext(ConnectionDialogContext);
    return (React.createElement(Table, { className: 'openbis-table openbis-working-directory' },
        React.createElement(Row, null,
            React.createElement("div", { className: 'openbis-flex-vertical' },
                React.createElement("input", { className: 'openbis-working-directory', type: 'text', placeholder: 'Working directory', value: state.workingDir, onChange: (e) => dispatch(new UpdateWorkingDir(e.target.value)) })),
            React.createElement("a", { href: '#', className: 'openbis-link', onClick: () => dispatch(new ResetWorkingDir()) }, "Reset to default"))));
};
