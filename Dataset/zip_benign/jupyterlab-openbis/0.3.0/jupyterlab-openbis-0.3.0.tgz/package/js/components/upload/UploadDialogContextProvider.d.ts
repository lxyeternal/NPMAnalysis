import { FunctionComponent } from 'react';
import { UploadDialogState } from '../../context/uploaddialog';
import { ContextProviderProps } from '../../common';
export declare const UploadDialogContextProvider: FunctionComponent<ContextProviderProps<UploadDialogState>>;
