import * as React from 'react';
import { UploadDialog } from '../upload/UploadDialog';
import { PhosphorBaseDialog } from './PhosphorBaseDialog';
import { globalState, initialState } from '../../context/uploaddialog';
import { UploadDialogContextProvider } from '../upload/UploadDialogContextProvider';
export class PhosphorUploadDialog extends PhosphorBaseDialog {
    constructor(panel) {
        super(panel);
        if (!(this.panel.id in globalState)) {
            globalState[this.panel.id] = initialState;
            globalState[this.panel.id].panel = this.panel;
        }
    }
    render() {
        return (React.createElement(UploadDialogContextProvider, { id: this.panel.id, initialState: globalState[this.panel.id], setDispatch: this.setDispatch, getDispatch: this.getDispatch },
            React.createElement(UploadDialog, null)));
    }
}
