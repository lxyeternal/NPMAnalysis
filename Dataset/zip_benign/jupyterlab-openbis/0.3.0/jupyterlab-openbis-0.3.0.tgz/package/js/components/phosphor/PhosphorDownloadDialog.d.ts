/// <reference types="react" />
import { PhosphorBaseDialog } from './PhosphorBaseDialog';
import { NotebookPanel } from '@jupyterlab/notebook';
export declare class PhosphorDownloadDialog extends PhosphorBaseDialog {
    constructor(panel: NotebookPanel);
    render(): JSX.Element;
}
