/// <reference types="react" />
import { ReactWidget } from '@jupyterlab/apputils';
import { Message } from '@lumino/messaging';
import { Dispatch } from '../../common';
import { NotebookPanel } from '@jupyterlab/notebook';
export declare abstract class PhosphorBaseDialog extends ReactWidget {
    protected panel: NotebookPanel;
    private dispatch;
    constructor(panel: NotebookPanel);
    onAfterAttach(msg: Message): void;
    getValue(): void;
    onBeforeDetach(msg: Message): void;
    setDispatch: (d: Dispatch) => import("react").Dispatch<import("../../common").Action>;
    getDispatch: () => import("react").Dispatch<import("../../common").Action>;
}
