import { Action } from '../common';
import { UploadDialogState } from '../context/uploaddialog';
export declare const reducer: (stxate: UploadDialogState, action: Action) => UploadDialogState;
