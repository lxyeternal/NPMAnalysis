import { Action } from '../common';
import { DownloadDialogState } from '../context/downloaddialog';
export declare const reducer: (state: DownloadDialogState, action: Action) => DownloadDialogState;
