import { Action } from '../common';
import { ConnectionDialogState } from '../context/connectiondialog';
export declare const reducer: (state: ConnectionDialogState, action: Action) => ConnectionDialogState;
