import { produce } from 'immer';
import { OpenDialog } from '../actions/state';
import { globalState as connectionGlobalState } from '../context/connectiondialog';
import { GetDataSetTypesSuccess, SelectDataSetType, UpdateProperty, UpdateTargetEntity, GetDirectoryContent, GetDirectoryContentSuccess, SelectDataSet, UnselectDataSet, SelectFile, UnselectFile, Upload, UploadSuccessful, } from '../actions/uploaddialog';
import { initialState } from '../context/uploaddialog';
import { emptyInputField } from '../common';
export const reducer = produce((state, action) => {
    if (action instanceof OpenDialog) {
        const panelId = action.panelId;
        if (panelId in connectionGlobalState) {
            const { selected: index, connections } = connectionGlobalState[panelId];
            if (index in connections) {
                const newConnection = connections[index];
                // changing connection resets dialog state
                if (state.connection) {
                    if (newConnection.name !== state.connection.name) {
                        Object.assign(state, initialState);
                    }
                }
                if (newConnection.status !== 'connected') {
                    state.error = 'Please authenticate the selected connection';
                }
                else {
                    state.error = '';
                }
                state.connection = newConnection;
            }
            else {
                state.error = 'Please select a connection';
            }
        }
        else {
            state.error = 'Please select a connection';
        }
    }
    if (action instanceof GetDataSetTypesSuccess) {
        if (action.success) {
            state.dataSetTypes = action.dataSetTypes;
        }
    }
    if (action instanceof SelectDataSetType) {
        const selected = state.dataSetTypes.find((t) => t.code === action.code);
        state.dataSetType = selected;
        state.properties = {};
        state.dataSetType.propertyAssignments.forEach((prop) => (state.properties[prop.code] = emptyInputField));
    }
    if (action instanceof UpdateProperty) {
        state.properties[action.code].value = action.value;
    }
    if (action instanceof UpdateTargetEntity) {
        state.targetEntity.value = action.value;
    }
    if (action instanceof GetDirectoryContent) {
        state.currentDirectory = action.path;
    }
    if (action instanceof GetDirectoryContentSuccess) {
        if (action.success) {
            state.currentDirectoryContent = action.entries;
        }
    }
    if (action instanceof SelectDataSet) {
        state.selectedDataSets.push(action.permId);
    }
    if (action instanceof UnselectDataSet) {
        state.selectedDataSets = state.selectedDataSets.filter((value) => value !== action.permId);
    }
    if (action instanceof SelectFile) {
        state.selectedFiles.push(action.path);
    }
    if (action instanceof UnselectFile) {
        state.selectedFiles = state.selectedFiles.filter((value) => value !== action.path);
    }
    if (action instanceof Upload) {
        state.uploadInProgress = true;
    }
    if (action instanceof UploadSuccessful) {
        state.uploadInProgress = false;
        if (action.success) {
            state.uploadMessage = action.value.statusText;
        }
        else {
            if ('errors' in action.value) {
                try {
                    const key = Object.keys(action.value.errors[0])[0];
                    state.uploadMessage = key + ': ' + action.value.errors[0][key];
                }
                catch (_a) {
                    state.uploadMessage = 'Upload failed';
                }
            }
            else {
                state.uploadMessage = 'Upload failed';
            }
        }
    }
});
