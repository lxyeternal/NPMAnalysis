import { initialProposedConnection } from '../context/connectiondialog';
import { UpdateProposedConnection, UpdateConnection, ListConnectionsSuccess, CreateConnectionError, CreateConnectionSuccess, ConnectError, ConnectSuccess, SelectConnection, UpdateWorkingDir, ResetWorkingDir, } from '../actions/connectiondialog';
import { produce } from 'immer';
export const reducer = produce((state, action) => {
    if (action instanceof ListConnectionsSuccess) {
        state.connections = action.connections;
        state.defaultWorkingDir = action.notebook_dir;
        if (state.workingDir === '') {
            state.workingDir = state.defaultWorkingDir;
        }
        if (action.selected != null) {
            state.selected = state.connections.findIndex((c) => c.name === action.selected);
        }
    }
    if (action instanceof UpdateProposedConnection) {
        const { key, value } = action;
        if (key === 'name') {
            state.proposedConnection.name = value;
        }
        else if (key === 'url') {
            state.proposedConnection.url = value;
        }
        else if (key === 'user') {
            state.proposedConnection.user = value;
        }
        else if (key === 'password') {
            state.proposedConnection.password = value;
        }
        state.proposedConnection.error = '';
    }
    if (action instanceof UpdateConnection) {
        const { key, index, value } = action;
        if (key === 'user') {
            state.connections[index].username = value;
        }
        else if (key === 'password') {
            state.connections[index].password = value;
        }
        state.errors[index] = '';
    }
    if (action instanceof CreateConnectionSuccess) {
        state.proposedConnection = initialProposedConnection;
    }
    if (action instanceof CreateConnectionError) {
        state.proposedConnection.error = action.message;
    }
    if (action instanceof ConnectError) {
        state.errors[action.index] = action.message;
    }
    if (action instanceof ConnectSuccess) {
        state.errors[action.index] = '';
    }
    if (action instanceof SelectConnection) {
        state.selected = action.index;
    }
    if (action instanceof UpdateWorkingDir) {
        state.workingDir = action.value;
    }
    if (action instanceof ResetWorkingDir) {
        state.workingDir = state.defaultWorkingDir;
    }
});
