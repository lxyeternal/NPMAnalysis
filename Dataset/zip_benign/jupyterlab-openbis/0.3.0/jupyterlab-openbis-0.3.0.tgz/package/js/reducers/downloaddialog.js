import { produce } from 'immer';
import { OpenDialog } from '../actions/state';
import { globalState as connectionGlobalState } from '../context/connectiondialog';
import { UpdateEntityId, UpdatePermId, UpdatePath, ShowDataSets, ShowDataSetsSuccess, DownloadPermId, DownloadSelected, DownloadComplete, DownloadPermIdComplete, NextPage, PreviousPage, } from '../actions/downloaddialog';
import { SelectDataSet, UnselectDataSet } from '../actions/downloaddialog';
import { emptyInputField, MessageType } from '../common';
export const reducer = produce((state, action) => {
    if (action instanceof OpenDialog) {
        const panelId = action.panelId;
        if (panelId in connectionGlobalState) {
            const { selected: index, connections, workingDir } = connectionGlobalState[panelId];
            if (state.defaultDownloadPath !== workingDir) {
                state.downloadPath.value = workingDir;
                state.defaultDownloadPath = workingDir;
            }
            if (index in connections) {
                const newConnection = connections[index];
                // changing connection resets dialog state
                if (state.connection) {
                    if (newConnection.name !== state.connection.name) {
                        state.dataSetId = emptyInputField;
                        state.downloadPath = emptyInputField;
                        state.entityId = emptyInputField;
                        state.result = null;
                        state.selected = [];
                    }
                }
                if (newConnection.status !== 'connected') {
                    state.error = 'Please authenticate the selected connection';
                }
                else {
                    state.error = '';
                }
                state.connection = newConnection;
            }
            else {
                state.error = 'Please select a connection';
            }
        }
        else {
            state.error = 'Please select a connection';
        }
    }
    if (action instanceof UpdateEntityId) {
        state.entityId.value = action.value;
        state.entityId.message = '';
    }
    if (action instanceof UpdatePermId) {
        state.dataSetId.value = action.value;
        state.dataSetId.message = '';
    }
    if (action instanceof UpdatePath) {
        state.downloadPath.value = action.value;
        state.downloadPath.message = '';
    }
    if (action instanceof ShowDataSets) {
        state.selected = [];
        state.entityId.message = '';
    }
    if (action instanceof ShowDataSetsSuccess) {
        state.result = action.result;
        state.result.count = Number(state.result.count);
        state.result.start_with = Number(state.result.start_with);
        if (action.result.totalCount === 0) {
            state.entityId.message = 'No datasets found';
            state.entityId.messageType = MessageType.ERROR;
        }
        state.activeEntityId = state.entityId.value;
    }
    if (action instanceof NextPage || action instanceof PreviousPage) {
        state.entityId.value = state.activeEntityId;
    }
    if (action instanceof SelectDataSet) {
        state.selected.push(action.permId);
    }
    if (action instanceof UnselectDataSet) {
        state.selected = state.selected.filter((value) => value !== action.permId);
    }
    if (action instanceof DownloadSelected) {
        state.downloadQueue = state.selected;
        state.downloadingActive = false;
    }
    if (action instanceof DownloadComplete) {
        if (action.success) {
            state.downloadQueue = state.downloadQueue.filter((id) => id !== action.permId);
        }
        else {
            state.downloadQueue = [];
        }
        if (state.downloadQueue.length === 0) {
            state.downloadingActive = true;
        }
    }
    if (action instanceof DownloadPermId) {
        state.dataSetId.message = 'Downloading ' + state.dataSetId.value;
        state.dataSetId.messageType = MessageType.INFO;
        state.downloadingActive = false;
    }
    if (action instanceof DownloadPermIdComplete) {
        if (action.success) {
            state.dataSetId.message = 'Download of ' + action.permId + ' complete';
            state.dataSetId.messageType = MessageType.INFO;
        }
        else {
            state.dataSetId.message = 'Dataset ' + action.permId + ' not found';
            state.dataSetId.messageType = MessageType.ERROR;
        }
        state.downloadingActive = true;
    }
});
