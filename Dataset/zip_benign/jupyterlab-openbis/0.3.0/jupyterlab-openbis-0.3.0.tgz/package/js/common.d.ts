/// <reference types="react" />
export interface Action {
}
export interface Connection {
    name: string;
    url: string;
    status: string;
    username: string;
    password: string;
}
export declare enum MessageType {
    ERROR = 0,
    INFO = 1,
    SUCCESS = 2
}
export interface InputField {
    value: string;
    message: string;
    messageType: MessageType;
}
export declare const emptyInputField: InputField;
export declare type Dispatch = React.Dispatch<Action>;
export declare type Middleware<State> = (dispatch: Dispatch) => (state: State) => (action: Action) => void;
export declare function combineMiddlewares<State>(state: State, dispatch: Dispatch, nextDispatch: () => Dispatch, ...middlewares: Middleware<State>[]): React.Dispatch<Action>;
export declare type ContextProviderProps<State> = {
    id: string;
    initialState: State;
    setDispatch: (d: Dispatch) => void;
    getDispatch: () => Dispatch;
};
