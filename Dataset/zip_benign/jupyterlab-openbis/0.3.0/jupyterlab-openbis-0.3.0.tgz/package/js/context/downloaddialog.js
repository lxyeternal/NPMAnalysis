import { createContext } from 'react';
import { emptyInputField } from '../common';
export const initialState = {
    error: '',
    connection: null,
    downloadPath: emptyInputField,
    defaultDownloadPath: '',
    entityId: emptyInputField,
    activeEntityId: '',
    dataSetId: emptyInputField,
    result: null,
    selected: [],
    downloadQueue: [],
    panel: null,
    downloadingActive: true,
};
export const globalState = {};
export const DownloadDialogContext = createContext([initialState, null]);
