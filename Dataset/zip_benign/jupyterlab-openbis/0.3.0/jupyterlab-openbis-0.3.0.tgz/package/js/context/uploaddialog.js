import { createContext } from 'react';
import { emptyInputField } from '../common';
export const initialState = {
    error: '',
    connection: null,
    dataSetTypes: [],
    dataSetType: null,
    properties: {},
    targetEntity: emptyInputField,
    currentDirectory: null,
    currentDirectoryContent: [],
    selectedDataSets: [],
    selectedFiles: [],
    uploadInProgress: false,
    uploadMessage: '',
    panel: null,
};
export const globalState = {};
export const UploadDialogContext = createContext([initialState, null]);
