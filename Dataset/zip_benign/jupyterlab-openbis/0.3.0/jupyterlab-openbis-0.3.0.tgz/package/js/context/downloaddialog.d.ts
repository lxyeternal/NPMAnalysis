import React from 'react';
import { Action, Connection } from '../common';
import { NotebookPanel } from '@jupyterlab/notebook';
import { InputField } from '../common';
export interface DataSet {
    permId: string;
    $NAME: string;
    type: string;
    registrationDate: string;
    status: string;
    size: number;
}
export interface Result {
    start_with: number;
    count: number;
    totalCount: number;
    cwd: string;
    dataSets: DataSet[];
}
export interface DownloadDialogState {
    error: string;
    connection: Connection;
    entityId: InputField;
    activeEntityId: string;
    dataSetId: InputField;
    defaultDownloadPath: string;
    downloadPath: InputField;
    result: Result;
    selected: string[];
    downloadQueue: string[];
    panel: NotebookPanel;
    downloadingActive: boolean;
}
export declare const initialState: DownloadDialogState;
export declare const globalState: {
    [id: string]: DownloadDialogState;
};
export declare const DownloadDialogContext: React.Context<[DownloadDialogState, React.Dispatch<Action>]>;
