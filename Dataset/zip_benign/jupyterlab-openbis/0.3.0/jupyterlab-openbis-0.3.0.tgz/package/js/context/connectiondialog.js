import { createContext } from 'react';
export const initialProposedConnection = {
    name: '',
    url: '',
    user: '',
    password: '',
    error: '',
};
export const initialState = {
    connections: [],
    workingDir: '',
    defaultWorkingDir: '',
    proposedConnection: initialProposedConnection,
    errors: [],
    selected: -1,
};
export const globalState = {};
export const ConnectionDialogContext = createContext([initialState, null]);
