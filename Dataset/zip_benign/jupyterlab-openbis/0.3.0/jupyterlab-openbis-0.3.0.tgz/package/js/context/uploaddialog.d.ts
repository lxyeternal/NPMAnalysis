import React from 'react';
import { Action, Connection, InputField } from '../common';
import { NotebookPanel } from '@jupyterlab/notebook';
export interface PropertyAssignment {
    code: string;
    dataType: string;
    description: string;
    label: string;
    propertyType: string;
    ordinal: number;
    mandatory: boolean;
    section: string;
}
export interface DataSetType {
    permId: string;
    code: string;
    description: string;
    propertyAssignments: PropertyAssignment[];
}
export interface Entry {
    name: string;
    path: string;
    size: string;
    type: string;
}
export interface UploadDialogState {
    error: string;
    connection: Connection;
    dataSetTypes: DataSetType[];
    dataSetType: DataSetType;
    properties: {
        [code: string]: InputField;
    };
    targetEntity: InputField;
    currentDirectory: string;
    currentDirectoryContent: Entry[];
    selectedDataSets: string[];
    selectedFiles: string[];
    uploadInProgress: boolean;
    uploadMessage: string;
    panel: NotebookPanel;
}
export declare const initialState: UploadDialogState;
export declare const globalState: {
    [id: string]: UploadDialogState;
};
export declare const UploadDialogContext: React.Context<[UploadDialogState, React.Dispatch<Action>]>;
