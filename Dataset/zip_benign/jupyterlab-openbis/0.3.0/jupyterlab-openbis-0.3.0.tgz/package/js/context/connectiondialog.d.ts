import React from 'react';
import { Action, Connection } from '../common';
export interface ProposedConnection {
    name: string;
    url: string;
    user: string;
    password: string;
    error: string;
}
export interface ConnectionDialogState {
    proposedConnection: ProposedConnection;
    connections: Connection[];
    errors: String[];
    selected: number;
    workingDir: string;
    defaultWorkingDir: string;
}
export declare const initialProposedConnection: ProposedConnection;
export declare const initialState: ConnectionDialogState;
export declare const globalState: {
    [id: string]: ConnectionDialogState;
};
export declare const ConnectionDialogContext: React.Context<[ConnectionDialogState, React.Dispatch<Action>]>;
