import { Dialog } from '@jupyterlab/apputils';
import { globalState } from './context/connectiondialog';
export const patches = {
    load: () => {
        Dialog.prototype._evtKeydownOriginal = Dialog.prototype._evtKeydown;
        Dialog.prototype._evtKeydown = function (event) {
            if (event.keyCode === 13 && Object.keys(globalState).includes(this._body.panel.id)) {
                return;
            }
            else
                this._evtKeydownOriginal(event);
        };
    },
};
