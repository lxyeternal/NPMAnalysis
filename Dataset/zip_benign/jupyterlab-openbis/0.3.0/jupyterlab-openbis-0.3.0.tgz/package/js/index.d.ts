import { IDisposable } from '@lumino/disposable';
import { JupyterFrontEndPlugin } from '@jupyterlab/application';
import { DocumentRegistry } from '@jupyterlab/docregistry';
import { NotebookPanel, INotebookModel } from '@jupyterlab/notebook';
import { Connection } from './common';
declare const plugin: JupyterFrontEndPlugin<void>;
export declare class ButtonExtension implements DocumentRegistry.IWidgetExtension<NotebookPanel, INotebookModel> {
    connections: Array<Connection>;
    defaultWorkingDir: string;
    createNew(panel: NotebookPanel, context: DocumentRegistry.IContext<INotebookModel>): IDisposable;
}
export default plugin;
