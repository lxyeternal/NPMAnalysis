import { Action, Connection } from '../common';
export declare class UpdateProposedConnection implements Action {
    key: string;
    value: string;
    constructor(key: string, value: string);
}
export declare class SelectConnection implements Action {
    index: number;
    constructor(index: number);
}
export declare class UpdateConnection implements Action {
    index: number;
    key: string;
    value: string;
    constructor(index: number, key: string, value: string);
}
export declare class ListConnectionsSuccess implements Action {
    connections: Connection[];
    notebook_dir: string;
    selected: string;
    constructor(connections: Connection[], notebook_dir: string, selected: string);
}
export declare class ListConnectionsError implements Action {
    error: any;
    constructor(error: any);
}
export declare class ListConnections implements Action {
    selected: string;
    constructor(selected: string);
}
export declare class CreateConnection implements Action {
}
export declare class CreateConnectionSuccess implements Action {
    name: string;
    constructor(name: string);
}
export declare class CreateConnectionError implements Action {
    message: string;
    constructor(message: string);
}
export declare class Connect implements Action {
    index: number;
    constructor(index: number);
}
export declare class DeleteConnection implements Action {
    index: number;
    constructor(index: number);
}
export declare class DeleteConnectionSuccess implements Action {
    index: number;
    constructor(index: number);
}
export declare class ConnectSuccess implements Action {
    index: number;
    constructor(index: number);
}
export declare class ConnectError implements Action {
    index: number;
    message: string;
    constructor(index: number, message: string);
}
export declare class UpdateWorkingDir implements Action {
    value: string;
    constructor(value: string);
}
export declare class ResetWorkingDir implements Action {
}
