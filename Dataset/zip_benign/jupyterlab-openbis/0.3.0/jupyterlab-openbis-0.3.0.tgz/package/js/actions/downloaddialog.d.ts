import { Action } from '../common';
import { Result } from '../context/downloaddialog';
export declare class UpdateEntityId implements Action {
    value: string;
    constructor(value: string);
}
export declare class UpdatePermId implements Action {
    value: string;
    constructor(value: string);
}
export declare class UpdatePath implements Action {
    value: string;
    constructor(value: string);
}
export declare class ShowDataSets implements Action {
}
export declare class ShowDataSetsSuccess implements Action {
    result: Result;
    constructor(result: Result);
}
export declare class ShowDataSetsError implements Action {
}
export declare class SelectDataSet implements Action {
    permId: string;
    constructor(permId: string);
}
export declare class UnselectDataSet implements Action {
    permId: string;
    constructor(permId: string);
}
export declare class NextPage implements Action {
}
export declare class PreviousPage implements Action {
}
export declare class DownloadPermId implements Action {
}
export declare class DownloadSelected implements Action {
}
export declare class ProcessDownload implements Action {
}
interface DownloadDetails {
    url: string;
    permId: string;
    path: string;
    dataStore: string;
    location: string;
    size: number;
    files: string[];
    statusText: string;
}
export declare class DownloadComplete implements Action {
    permId: string;
    data: DownloadDetails;
    success: boolean;
    constructor(permId: string, data: DownloadDetails, success: boolean);
}
export declare class DownloadPermIdComplete implements Action {
    permId: string;
    data: DownloadDetails;
    success: boolean;
    constructor(permId: string, data: DownloadDetails, success: boolean);
}
export {};
