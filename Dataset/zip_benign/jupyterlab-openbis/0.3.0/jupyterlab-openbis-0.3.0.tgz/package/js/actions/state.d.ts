import { Action } from '../common';
export declare class OpenDialog implements Action {
    panelId: string;
    constructor(panelId: string);
}
export declare class CloseDialog implements Action {
    panelId: string;
    constructor(panelId: string);
}
