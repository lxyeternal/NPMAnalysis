import { Action } from '../common';
export declare enum Method {
    GET = "GET",
    PUT = "PUT",
    POST = "POST",
    DELETE = "DELETE"
}
declare type FollowUp = (status: number, content: any) => Action;
declare type ErrorFollowUp = (error: any) => Action;
export declare class ApiRequest implements Action {
    url: string;
    method: Method;
    body: string;
    onSuccess: FollowUp;
    onError: ErrorFollowUp;
    constructor(url: string, method: Method, body: string, onSuccess: FollowUp, onError: ErrorFollowUp);
}
export declare class GetRequest extends ApiRequest {
    constructor(url: string, onSuccess: FollowUp, onError: ErrorFollowUp);
}
export declare class PutRequest extends ApiRequest {
    constructor(url: string, body: string, onSuccess: FollowUp, onError: ErrorFollowUp);
}
export declare class PostRequest extends ApiRequest {
    constructor(url: string, body: string, onSuccess: FollowUp, onError: ErrorFollowUp);
}
export declare class DeleteRequest extends ApiRequest {
    constructor(url: string, onSuccess: FollowUp, onError: ErrorFollowUp);
}
export {};
