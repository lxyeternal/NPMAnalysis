export var Method;
(function (Method) {
    Method["GET"] = "GET";
    Method["PUT"] = "PUT";
    Method["POST"] = "POST";
    Method["DELETE"] = "DELETE";
})(Method || (Method = {}));
export class ApiRequest {
    constructor(url, method, body, onSuccess, onError) {
        this.url = url;
        this.method = method;
        this.body = body;
        this.onSuccess = onSuccess;
        this.onError = onError;
    }
}
export class GetRequest extends ApiRequest {
    constructor(url, onSuccess, onError) {
        super(url, Method.GET, null, onSuccess, onError);
    }
}
export class PutRequest extends ApiRequest {
    constructor(url, body, onSuccess, onError) {
        super(url, Method.PUT, body, onSuccess, onError);
    }
}
export class PostRequest extends ApiRequest {
    constructor(url, body, onSuccess, onError) {
        super(url, Method.POST, body, onSuccess, onError);
    }
}
export class DeleteRequest extends ApiRequest {
    constructor(url, onSuccess, onError) {
        super(url, Method.DELETE, null, onSuccess, onError);
    }
}
