import { Action } from '../common';
import { DataSetType, Entry } from '../context/uploaddialog';
export declare class GetDataSetTypes implements Action {
}
export declare class GetDataSetTypesSuccess implements Action {
    dataSetTypes: DataSetType[];
    success: boolean;
    constructor(dataSetTypes: DataSetType[], success: boolean);
}
export declare class SelectDataSetType implements Action {
    code: string;
    constructor(code: string);
}
export declare class UpdateProperty implements Action {
    code: string;
    value: string;
    constructor(code: string, value: string);
}
export declare class UpdateTargetEntity implements Action {
    value: string;
    constructor(value: string);
}
export declare class SelectDataSet implements Action {
    permId: string;
    constructor(permId: string);
}
export declare class UnselectDataSet implements Action {
    permId: string;
    constructor(permId: string);
}
export declare class SelectFile implements Action {
    path: string;
    constructor(path: string);
}
export declare class UnselectFile implements Action {
    path: string;
    constructor(path: string);
}
export declare class GetDirectoryContent implements Action {
    path: string;
    constructor(path: string);
}
export declare class GetDirectoryContentSuccess implements Action {
    entries: Entry[];
    success: boolean;
    constructor(entries: Entry[], success: boolean);
}
export declare class GoToParentDirectory implements Action {
}
export declare class Upload implements Action {
}
export declare class UploadSuccessful implements Action {
    value: any;
    success: boolean;
    constructor(value: any, success: boolean);
}
