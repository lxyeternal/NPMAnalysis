export class UpdateEntityId {
    constructor(value) {
        this.value = value;
    }
}
export class UpdatePermId {
    constructor(value) {
        this.value = value;
    }
}
export class UpdatePath {
    constructor(value) {
        this.value = value;
    }
}
export class ShowDataSets {
}
export class ShowDataSetsSuccess {
    constructor(result) {
        this.result = result;
    }
}
export class ShowDataSetsError {
}
export class SelectDataSet {
    constructor(permId) {
        this.permId = permId;
    }
}
export class UnselectDataSet {
    constructor(permId) {
        this.permId = permId;
    }
}
export class NextPage {
}
export class PreviousPage {
}
export class DownloadPermId {
}
export class DownloadSelected {
}
export class ProcessDownload {
}
export class DownloadComplete {
    constructor(permId, data, success) {
        this.permId = permId;
        this.data = data;
        this.success = success;
    }
}
export class DownloadPermIdComplete {
    constructor(permId, data, success) {
        this.permId = permId;
        this.data = data;
        this.success = success;
    }
}
