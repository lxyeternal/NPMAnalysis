export class UpdateProposedConnection {
    constructor(key, value) {
        this.key = key;
        this.value = value;
    }
}
export class SelectConnection {
    constructor(index) {
        this.index = index;
    }
}
export class UpdateConnection {
    constructor(index, key, value) {
        this.index = index;
        this.key = key;
        this.value = value;
    }
}
export class ListConnectionsSuccess {
    constructor(connections, notebook_dir, selected) {
        this.connections = connections;
        this.notebook_dir = notebook_dir;
        this.selected = selected;
    }
}
export class ListConnectionsError {
    constructor(error) {
        this.error = error;
    }
}
export class ListConnections {
    constructor(selected) {
        this.selected = selected;
    }
}
export class CreateConnection {
}
export class CreateConnectionSuccess {
    constructor(name) {
        this.name = name;
    }
}
export class CreateConnectionError {
    constructor(message) {
        this.message = message;
    }
}
export class Connect {
    constructor(index) {
        this.index = index;
    }
}
export class DeleteConnection {
    constructor(index) {
        this.index = index;
    }
}
export class DeleteConnectionSuccess {
    constructor(index) {
        this.index = index;
    }
}
export class ConnectSuccess {
    constructor(index) {
        this.index = index;
    }
}
export class ConnectError {
    constructor(index, message) {
        this.index = index;
        this.message = message;
    }
}
export class UpdateWorkingDir {
    constructor(value) {
        this.value = value;
    }
}
export class ResetWorkingDir {
}
