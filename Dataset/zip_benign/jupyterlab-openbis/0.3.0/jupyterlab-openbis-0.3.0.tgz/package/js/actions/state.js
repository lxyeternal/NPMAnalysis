export class OpenDialog {
    constructor(panelId) {
        this.panelId = panelId;
    }
}
export class CloseDialog {
    constructor(panelId) {
        this.panelId = panelId;
    }
}
