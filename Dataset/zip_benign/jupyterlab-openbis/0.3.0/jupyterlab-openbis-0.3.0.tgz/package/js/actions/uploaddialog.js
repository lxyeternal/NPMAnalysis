export class GetDataSetTypes {
}
export class GetDataSetTypesSuccess {
    constructor(dataSetTypes, success) {
        this.dataSetTypes = dataSetTypes;
        this.success = success;
    }
}
export class SelectDataSetType {
    constructor(code) {
        this.code = code;
    }
}
export class UpdateProperty {
    constructor(code, value) {
        this.code = code;
        this.value = value;
    }
}
export class UpdateTargetEntity {
    constructor(value) {
        this.value = value;
    }
}
export class SelectDataSet {
    constructor(permId) {
        this.permId = permId;
    }
}
export class UnselectDataSet {
    constructor(permId) {
        this.permId = permId;
    }
}
export class SelectFile {
    constructor(path) {
        this.path = path;
    }
}
export class UnselectFile {
    constructor(path) {
        this.path = path;
    }
}
export class GetDirectoryContent {
    constructor(path) {
        this.path = path;
    }
}
export class GetDirectoryContentSuccess {
    constructor(entries, success) {
        this.entries = entries;
        this.success = success;
    }
}
export class GoToParentDirectory {
}
export class Upload {
}
export class UploadSuccessful {
    constructor(value, success) {
        this.value = value;
        this.success = success;
    }
}
