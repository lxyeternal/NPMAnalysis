import { DisposableDelegate } from '@lumino/disposable';
import { ToolbarButton, IThemeManager } from '@jupyterlab/apputils';
import { INotebookTracker } from '@jupyterlab/notebook';
import { Dialog, showDialog } from '@jupyterlab/apputils';
import { PhosphorConnectionDialog } from './components/phosphor/PhosphorConnectionDialog';
import { PhosphorDownloadDialog } from './components/phosphor/PhosphorDownloadDialog';
import { PhosphorUploadDialog } from './components/phosphor/PhosphorUploadDialog';
import { patches } from './patches';
import { globalState as connectionDialogGlobalState } from './context/connectiondialog';
import { globalState as downloadDialogGlobalState } from './context/downloaddialog';
import { globalState as uploadDialogGlobalState } from './context/uploaddialog';
// info for implementing openBIS mount browsing: https://discourse.jupyter.org/t/custom-panel-extension-in-the-left-jupyterlab-area/1502
const plugin = {
    activate,
    id: 'jupyterlab-openbis:dialogs',
    autoStart: true,
    requires: [INotebookTracker, IThemeManager],
};
patches.load();
export class ButtonExtension {
    createNew(panel, context) {
        const connection = new PhosphorConnectionDialog(panel);
        const download = new PhosphorDownloadDialog(panel);
        const upload = new PhosphorUploadDialog(panel);
        let openDialog = (widget, title) => () => {
            showDialog({
                title: title,
                body: widget,
                buttons: [Dialog.okButton({ label: 'Close' })],
            });
        };
        const connectionButton = new ToolbarButton({
            iconClass: 'fa fa-sliders-h openbis-toolbar-button',
            onClick: openDialog(connection, 'openBIS connections'),
            tooltip: 'Choose openBIS connection',
        });
        const downloadButton = new ToolbarButton({
            className: 'myButton',
            iconClass: 'fa fa-download openbis-toolbar-button',
            onClick: openDialog(download, 'Download openBIS datasets'),
            tooltip: 'Download openBIS datasets',
        });
        const uploadButton = new ToolbarButton({
            className: 'myButton',
            iconClass: 'fa fa-upload openbis-toolbar-button',
            onClick: openDialog(upload, 'Upload openBIS datasets'),
            tooltip: 'Upload openBIS datasets',
        });
        panel.toolbar.insertItem(9, 'connections', connectionButton);
        panel.toolbar.insertItem(10, 'download', downloadButton);
        panel.toolbar.insertItem(11, 'upload', uploadButton);
        return new DisposableDelegate(() => {
            delete connectionDialogGlobalState[panel.id];
            delete downloadDialogGlobalState[panel.id];
            delete uploadDialogGlobalState[panel.id];
            connectionButton.dispose();
            downloadButton.dispose();
            uploadButton.dispose();
        });
    }
}
function activate(app, notebooks, manager) {
    app.docRegistry.addWidgetExtension('Notebook', new ButtonExtension());
}
export default plugin;
