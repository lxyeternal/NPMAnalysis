export var MessageType;
(function (MessageType) {
    MessageType[MessageType["ERROR"] = 0] = "ERROR";
    MessageType[MessageType["INFO"] = 1] = "INFO";
    MessageType[MessageType["SUCCESS"] = 2] = "SUCCESS";
})(MessageType || (MessageType = {}));
export const emptyInputField = {
    value: '',
    message: '',
    messageType: MessageType.INFO,
};
export function combineMiddlewares(state, dispatch, nextDispatch, ...middlewares) {
    const combined = (action) => {
        const delayedDispatch = (action) => setTimeout(() => nextDispatch()(action));
        middlewares.forEach((mw) => mw(delayedDispatch)(state)(action));
        dispatch(action);
    };
    return combined;
}
