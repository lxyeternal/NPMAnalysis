import { Middleware } from '../common.js';
import { ConnectionDialogState } from '../context/connectiondialog.js';
export declare const connectionDialogMiddleware: Middleware<ConnectionDialogState>;
