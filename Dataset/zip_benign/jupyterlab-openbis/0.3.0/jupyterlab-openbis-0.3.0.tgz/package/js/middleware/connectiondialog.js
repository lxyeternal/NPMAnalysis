import { GetRequest, PostRequest, PutRequest, DeleteRequest } from '../actions/api';
import { ListConnections, ListConnectionsSuccess, ListConnectionsError, DeleteConnection, SelectConnection } from '../actions/connectiondialog';
import { CreateConnection, CreateConnectionSuccess, CreateConnectionError, DeleteConnectionSuccess } from '../actions/connectiondialog';
import { Connect, ConnectSuccess, ConnectError } from '../actions/connectiondialog';
import { globalState } from '../context/connectiondialog.js';
import { CloseDialog } from '../actions/state.js';
export const connectionDialogMiddleware = (dispatch) => (state) => (action) => {
    if (action instanceof ListConnections) {
        dispatch(new GetRequest('openbis/conns', (status, data) => new ListConnectionsSuccess(data.connections, data.notebook_dir, action.selected), (error) => new ListConnectionsError(error)));
    }
    if (action instanceof CreateConnection) {
        dispatch(new PostRequest('openbis/conns', JSON.stringify({
            name: state.proposedConnection.name,
            url: state.proposedConnection.url,
            username: state.proposedConnection.user,
            password: state.proposedConnection.password,
        }), (status, data) => status === 200 ? new CreateConnectionSuccess(state.proposedConnection.name) : new CreateConnectionError('Connection error'), (error) => new CreateConnectionError('Connection error')));
    }
    if (action instanceof CreateConnectionSuccess) {
        dispatch(new ListConnections(action.name));
    }
    if (action instanceof DeleteConnection) {
        dispatch(new DeleteRequest('openbis/conn/' + state.connections[action.index].name, (status, data) => new DeleteConnectionSuccess(action.index), (error) => new ListConnections(null)));
    }
    if (action instanceof DeleteConnectionSuccess) {
        if (state.selected === action.index) {
            dispatch(new SelectConnection(-1));
        }
        else if (state.selected > action.index) {
            dispatch(new SelectConnection(state.selected - 1));
        }
        dispatch(new ListConnections(null));
    }
    if (action instanceof Connect) {
        const conn = state.connections[action.index];
        dispatch(new PutRequest('openbis/conn/' + conn.name, JSON.stringify({
            username: conn.username,
            password: conn.password,
        }), (status, data) => {
            if (status === 200) {
                return new ConnectSuccess(action.index);
            }
            else if (status === 401) {
                return new ConnectError(action.index, 'Username / password incorrect');
            }
            else {
                return new ConnectError(action.index, 'Connection error');
            }
        }, (error) => new ConnectError(action.index, 'Connection error')));
    }
    if (action instanceof ConnectSuccess) {
        dispatch(new ListConnections(null));
    }
    if (action instanceof CloseDialog) {
        globalState[action.panelId] = state;
    }
};
