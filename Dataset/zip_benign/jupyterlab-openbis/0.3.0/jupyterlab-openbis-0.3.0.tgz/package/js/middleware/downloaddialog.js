import { globalState } from '../context/downloaddialog';
import { CloseDialog } from '../actions/state.js';
import { ShowDataSets, ShowDataSetsSuccess, ShowDataSetsError, NextPage, PreviousPage, DownloadSelected, ProcessDownload, DownloadComplete, DownloadPermId, DownloadPermIdComplete, } from '../actions/downloaddialog.js';
import { GetRequest } from '../actions/api';
function getDataSetsRequest(state, startIndex, entityId) {
    const start = startIndex <= 0 ? 0 : startIndex + 5 > state.result.totalCount ? state.result.totalCount - 5 : startIndex;
    return new GetRequest('openbis/sample/' + state.connection.name + '/' + encodeURIComponent(entityId) + '?start_with=' + start + '&count=5', (status, data) => new ShowDataSetsSuccess(data), (error) => new ShowDataSetsError());
}
export const downloadDialogMiddleware = (dispatch) => (state) => (action) => {
    if (action instanceof CloseDialog) {
        globalState[action.panelId] = state;
    }
    if (action instanceof ShowDataSets) {
        dispatch(getDataSetsRequest(state, 0, state.entityId.value));
    }
    if (action instanceof NextPage) {
        dispatch(getDataSetsRequest(state, state.result.start_with + 5, state.activeEntityId));
    }
    if (action instanceof PreviousPage) {
        dispatch(getDataSetsRequest(state, state.result.start_with - 5, state.activeEntityId));
    }
    if (action instanceof DownloadSelected) {
        dispatch(new ProcessDownload());
    }
    if (action instanceof DownloadPermId) {
        const permId = state.dataSetId.value;
        const downloadPath = state.downloadPath.value;
        const downloadUrl = 'openbis/dataset/' + state.connection.name + '/' + permId + '/' + encodeURIComponent(downloadPath);
        dispatch(new GetRequest(downloadUrl, (status, data) => new DownloadPermIdComplete(permId, data, status === 200), (error) => new DownloadPermIdComplete(permId, error, false)));
    }
    if (action instanceof ProcessDownload) {
        const permId = state.downloadQueue[0];
        const downloadPath = state.downloadPath.value;
        const downloadUrl = 'openbis/dataset/' + state.connection.name + '/' + permId + '/' + encodeURIComponent(downloadPath);
        dispatch(new GetRequest(downloadUrl, (status, data) => new DownloadComplete(permId, data, status === 200), (error) => new DownloadComplete(permId, error, false)));
    }
    if (action instanceof DownloadComplete || action instanceof DownloadPermIdComplete) {
        if (action.success) {
            if (!state.panel.model.metadata.keys().includes('datasets')) {
                state.panel.model.metadata.set('datasets', {});
            }
            const datasets = state.panel.model.metadata.get('datasets');
            datasets[action.data.permId] = action.data;
            state.panel.model.dirty = true;
        }
        if (state.downloadQueue.filter((id) => id !== action.permId).length > 0) {
            dispatch(new ProcessDownload());
        }
    }
};
