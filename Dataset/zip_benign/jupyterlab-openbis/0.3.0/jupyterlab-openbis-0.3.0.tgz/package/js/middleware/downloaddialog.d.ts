import { Middleware } from '../common.js';
import { DownloadDialogState } from '../context/downloaddialog';
export declare const downloadDialogMiddleware: Middleware<DownloadDialogState>;
