import { Middleware } from '../common.js';
export declare const apiMiddleware: Middleware<any>;
