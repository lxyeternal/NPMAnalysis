import { Middleware } from '../common.js';
import { UploadDialogState } from '../context/uploaddialog';
export declare const uploadDialogMiddleware: Middleware<UploadDialogState>;
