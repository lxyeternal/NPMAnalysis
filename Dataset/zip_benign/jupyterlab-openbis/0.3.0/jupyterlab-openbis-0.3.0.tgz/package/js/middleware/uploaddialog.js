import { globalState } from '../context/uploaddialog';
import { OpenDialog, CloseDialog } from '../actions/state.js';
import { GetDataSetTypes, GetDataSetTypesSuccess, SelectDataSetType, GetDirectoryContent, GetDirectoryContentSuccess, GoToParentDirectory, Upload, UploadSuccessful, } from '../actions/uploaddialog';
import { GetRequest, PostRequest } from '../actions/api';
export const uploadDialogMiddleware = (dispatch) => (state) => (action) => {
    if (action instanceof OpenDialog) {
        dispatch(new GetDataSetTypes());
        if (state.currentDirectory == null || state.currentDirectory === '') {
            dispatch(new GetDirectoryContent(''));
        }
    }
    if (action instanceof CloseDialog) {
        globalState[action.panelId] = state;
    }
    if (action instanceof GetDataSetTypes) {
        if (state.connection != null) {
            const downloadUrl = 'openbis/datasetTypes/' + state.connection.name;
            dispatch(new GetRequest(downloadUrl, (status, data) => new GetDataSetTypesSuccess(data.dataSetTypes, status === 200), (error) => new GetDataSetTypesSuccess(error, false)));
        }
    }
    if (action instanceof GetDataSetTypesSuccess) {
        if (action.success && action.dataSetTypes.length > 0) {
            if (state.dataSetType == null || !action.dataSetTypes.find((ds) => ds.code === state.dataSetType.code)) {
                dispatch(new SelectDataSetType(action.dataSetTypes[0].code));
            }
        }
    }
    if (action instanceof GetDirectoryContent) {
        if (state.connection != null) {
            const downloadUrl = 'api/contents/' + action.path;
            dispatch(new GetRequest(downloadUrl, (status, data) => new GetDirectoryContentSuccess(data.content, status === 200), (error) => new GetDirectoryContentSuccess(error, false)));
        }
    }
    if (action instanceof GoToParentDirectory) {
        if (state.currentDirectory !== '') {
            if (state.currentDirectory.indexOf('/') !== -1) {
                dispatch(new GetDirectoryContent(state.currentDirectory.substring(0, state.currentDirectory.indexOf('/'))));
            }
            else {
                dispatch(new GetDirectoryContent(''));
            }
        }
    }
    if (action instanceof Upload) {
        const url = 'openbis/dataset/' + state.connection.name;
        const props = {};
        Object.keys(state.properties).forEach((key) => {
            props[key] = state.properties[key].value;
        });
        const body = {
            type: state.dataSetType.permId,
            files: state.selectedFiles,
            parents: state.selectedDataSets,
            entityIdentifier: state.targetEntity.value,
            props: props,
        };
        dispatch(new PostRequest(url, JSON.stringify(body), (status, data) => new UploadSuccessful(data, status == 200), (error) => new UploadSuccessful(error, false)));
    }
};
