import { ServerConnection } from '@jupyterlab/services';
import { ApiRequest } from '../actions/api';
export const apiMiddleware = (dispatch) => (state) => (action) => {
    if (action instanceof ApiRequest) {
        const { url, method, onSuccess, onError } = action;
        const settings = ServerConnection.makeSettings();
        const fullUrl = settings.baseUrl + url;
        const init = {
            method: method,
            body: action.body,
        };
        const response = ServerConnection.makeRequest(fullUrl, init, settings);
        const json = response.then((response) => {
            if (init.method === 'DELETE') {
                return Promise.resolve({});
            }
            else {
                return response.json();
            }
        });
        Promise.all([response, json])
            .then(([response, json]) => dispatch(onSuccess(response.status, json)))
            .catch((error) => dispatch(onError(error)));
    }
};
