export namespace patches {
    function load(): void;
}
