# 消消乐

# 游戏

##### 安装

```
npm install game-xxl
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game": "game-xxl/xxl"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "common-game"
  ]
}
```

- js

```
Page({
  data: {
    gameSource1: {
      row: 6,//行
      col: 6,//列
      showRect: { x: 50, y: 100, width: 650, height: 626 },
      moveSpeed: 0.1,//移动一格的时间 时间越大，速度越慢
      syncMove: !true,//同步移动
      startNoSkill: true,//开始游戏布局不生成技能元素

      gameStartPlayAudio: false,
      boomNum: 5,//生成炸弹的个数
      // 游戏元素
      items: [
        {
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01nEhDCu1FJvfnA1AKT_!!1080040467.png",
          val: 10,
          probability: 1,//出现概率
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01CR3ww01FJvftxZa11_!!1080040467.png",
            // srcArr: [
            //   { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN016sHbY51FJvaBrJHhh_!!1080040467.png", "width": 110, "height": 110 },
            //   { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01HrKV2m1FJvaFPPdrE_!!1080040467.png", "width": 110, "height": 110 },
            // ],
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "220",//大图宽度
            height: "110",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 2,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01TgQXCf23c06LMcz3x_!!555657275.png",
            // srcArr: [
            //   { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01nEhDCu1FJvfnA1AKT_!!1080040467.png", "name": "1_00000.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01V9iJ8h1FJvfnA1u4z_!!1080040467.png", "name": "1_00001.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01QDbPxZ1FJvfs36y2y_!!1080040467.png", "name": "1_00002.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Y4sqaH1FJvfiRBD5x_!!1080040467.png", "name": "1_00003.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01Dw1HHq1FJvfylo3KX_!!1080040467.png", "name": "1_00004.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01VZn3KO1FJvfvRV3kf_!!1080040467.png", "name": "1_00005.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01e6oTO41FJvfpHtfjJ_!!1080040467.png", "name": "1_00006.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01EHoeg31FJvfzU4ucc_!!1080040467.png", "name": "1_00007.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01RS6p3J1FJvfxnUfIA_!!1080040467.png", "name": "1_00008.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01nwY6oF1FJvfpHvTwU_!!1080040467.png", "name": "1_00009.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01j1R5bG1FJvfsxrHog_!!1080040467.png", "name": "1_00010.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01P04yIO1FJvfx2SbxG_!!1080040467.png", "name": "1_00011.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01c8e8wm1FJvfiRDQNX_!!1080040467.png", "name": "1_00012.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01N879A71FJvftHP3wP_!!1080040467.png", "name": "1_00013.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01xCXk1a1FJvfvRSe1w_!!1080040467.png", "name": "1_00014.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01BXFZsg1FJvfpHuTYW_!!1080040467.png", "name": "1_00015.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01gEXf2F1FJvfvRT77s_!!1080040467.png", "name": "1_00016.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN016BJBLY1FJvfvRSF43_!!1080040467.png", "name": "1_00017.png", "width": "100", "height": "100" },
            //   { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01QbNzUA1FJvfvRWKk5_!!1080040467.png", "name": "1_00018.png", "width": "100", "height": "100" },
            // ],
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "600",//大图宽度
            height: "600",//大图高度
            fWidth: 100,//一帧宽度
            fHeight: 100,//一帧高度
            count: 36,//总共帧数
            boomSpeed: 1,//播放速度
            loop: !true,//是否循环
          },
          skill_boom_Obj: {
            srcArr: [
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01IPjHaZ1FJvfogMWLx_!!1080040467.png", "name": "1_00000.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01g9w4lB1FJvfylnzJH_!!1080040467.png", "name": "1_00001.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01aTj8SO1FJvfx2RXYw_!!1080040467.png", "name": "1_00002.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01bmkbml1FJvfzU4iFV_!!1080040467.png", "name": "1_00003.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01020plK1FJvfpHwDmT_!!1080040467.png", "name": "1_00004.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01mobaFf1FJvfogLa9t_!!1080040467.png", "name": "1_00005.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01meHgyn1FJvfuQyeLx_!!1080040467.png", "name": "1_00006.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01xa4BKi1FJvfylrwgY_!!1080040467.png", "name": "1_00007.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01CukP631FJvfx2Ucnz_!!1080040467.png", "name": "1_00008.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01DBQuvZ1FJvfyloj4z_!!1080040467.png", "name": "1_00009.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01hPbcyC1FJvfvRVrnk_!!1080040467.png", "name": "1_00010.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01bjxkqO1FJvfrT3af0_!!1080040467.png", "name": "1_00011.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01eKBPnD1FJvfiRGAwk_!!1080040467.png", "name": "1_00012.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01In1j7Y1FJvfiRDtab_!!1080040467.png", "name": "1_00013.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01PRJ8Kw1FJvfylqXN3_!!1080040467.png", "name": "1_00014.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01thNjBh1FJvfrQlCEN_!!1080040467.png", "name": "1_00015.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01IC5Giv1FJvfx2VIPK_!!1080040467.png", "name": "1_00016.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01U4cFdh1FJvfpHxILT_!!1080040467.png", "name": "1_00017.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01YilWhJ1FJvfxnYpF3_!!1080040467.png", "name": "1_00018.png", "width": "100", "height": "100" },
            ],
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "1900",//大图宽度
            height: "100",//大图高度
            fWidth: 100,//一帧宽度
            fHeight: 100,//一帧高度
            count: 19,//总共帧数
            boomSpeed: 1,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01JG401o1FJvfuQvxwl_!!1080040467.png",
          val: 10,
          probability: 1,//出现概率
          // 爆炸动画序列帧
          boomObj: {
            srcArr: [
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01JG401o1FJvfuQvxwl_!!1080040467.png", "name": "2_00000.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN018mjNRL1FJvfiRFdcd_!!1080040467.png", "name": "2_00001.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01TWSDOR1FJvfuQwAPp_!!1080040467.png", "name": "2_00002.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01dlQVkd1FJvfylnifU_!!1080040467.png", "name": "2_00003.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ZW0WgC1FJvfvRUSQE_!!1080040467.png", "name": "2_00004.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN0126dZd31FJvfpHv0va_!!1080040467.png", "name": "2_00005.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01tOhwlc1FJvfiRH78h_!!1080040467.png", "name": "2_00006.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01mtnkIv1FJvfs36hWi_!!1080040467.png", "name": "2_00007.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01yfaRI11FJvfzU5v5O_!!1080040467.png", "name": "2_00008.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN012Sc1w01FJvfogO85f_!!1080040467.png", "name": "2_00009.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN015uKS2U1FJvfnA3iSc_!!1080040467.png", "name": "2_00010.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01rdy4sX1FJvftHO3dv_!!1080040467.png", "name": "2_00011.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01cxRXmd1FJvfsxuN5i_!!1080040467.png", "name": "2_00012.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01joOwrX1FJvfogMJrZ_!!1080040467.png", "name": "2_00013.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01KgyFaw1FJvfxnV8Wz_!!1080040467.png", "name": "2_00014.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ru1OZG1FJvfiRGZsC_!!1080040467.png", "name": "2_00015.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01vCADVl1FJvfx2SD78_!!1080040467.png", "name": "2_00016.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01fVmAOF1FJvfnA4zUp_!!1080040467.png", "name": "2_00017.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01x9YC1n1FJvfpHu4ia_!!1080040467.png", "name": "2_00018.png", "width": "100", "height": "100" },
            ],
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "1900",//大图宽度
            height: "100",//大图高度
            fWidth: 100,//一帧宽度
            fHeight: 100,//一帧高度
            count: 19,//总共帧数
            boomSpeed: 0.3,//播放速度
            loop: !true,//是否循环
          },
          skill_boom_Obj: {
            srcArr: [
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN019oESPt1FJvfvwh8Z4_!!1080040467.png", "name": "2_00000.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01xWxSiD1FJvfogMWKf_!!1080040467.png", "name": "2_00001.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN010dwYgO1FJvfsxv6pZ_!!1080040467.png", "name": "2_00002.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01IDf35y1FJvfuQzaXQ_!!1080040467.png", "name": "2_00003.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01fPvlaR1FJvfvwhfoR_!!1080040467.png", "name": "2_00004.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01diazWv1FJvfuQwq4G_!!1080040467.png", "name": "2_00005.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015pBeNY1FJvfvRWXKi_!!1080040467.png", "name": "2_00006.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Ye8Vg91FJvfpHvHZo_!!1080040467.png", "name": "2_00007.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01gLuzcT1FJvfvRWTAS_!!1080040467.png", "name": "2_00008.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01c6J16m1FJvfrT3enr_!!1080040467.png", "name": "2_00009.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0175h6Cc1FJvfzU46q1_!!1080040467.png", "name": "2_00010.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01t5LijM1FJvfzU3N70_!!1080040467.png", "name": "2_00011.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01zloysz1FJvfylnS2b_!!1080040467.png", "name": "2_00012.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01abLkB51FJvfiREZBV_!!1080040467.png", "name": "2_00013.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015Tz0wl1FJvfrQjmr3_!!1080040467.png", "name": "2_00014.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN017lF26y1FJvfvRVCBr_!!1080040467.png", "name": "2_00015.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN017MQjLB1FJvfx2RsMM_!!1080040467.png", "name": "2_00016.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ldWpnG1FJvfuQwZOe_!!1080040467.png", "name": "2_00017.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN012Fsenv1FJvfxnWLMy_!!1080040467.png", "name": "2_00018.png", "width": "100", "height": "100" },
            ],
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "1900",//大图宽度
            height: "100",//大图高度
            fWidth: 100,//一帧宽度
            fHeight: 100,//一帧高度
            count: 19,//总共帧数
            boomSpeed: 0.3,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tMVx2I1FJvfuQv5pH_!!1080040467.png",
          val: 10,
          probability: 1,//出现概率
          // 爆炸动画序列帧
          boomObj: {
            srcArr: [
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tMVx2I1FJvfuQv5pH_!!1080040467.png", "name": "3_00000.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01682ayQ1FJvfx2PKBy_!!1080040467.png", "name": "3_00001.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01fGnFb91FJvfiRCHgp_!!1080040467.png", "name": "3_00002.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01c1Y2u01FJvfylnv1W_!!1080040467.png", "name": "3_00003.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01jxADNr1FJvfsxs1WT_!!1080040467.png", "name": "3_00004.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01MaVgNy1FJvftHOG2x_!!1080040467.png", "name": "3_00005.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01hHsB7P1FJvfogKNDH_!!1080040467.png", "name": "3_00006.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01qz1tpu1FJvfvweS6t_!!1080040467.png", "name": "3_00007.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01GOKbgN1FJvfvRTeOt_!!1080040467.png", "name": "3_00008.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01OI6EjY1FJvfzU5aDQ_!!1080040467.png", "name": "3_00009.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01reFOjb1FJvfrQkSLz_!!1080040467.png", "name": "3_00010.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01CLYWB91FJvfrQie8W_!!1080040467.png", "name": "3_00011.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01s98cLl1FJvfsxslEg_!!1080040467.png", "name": "3_00012.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01x6aIcp1FJvfiRC5DO_!!1080040467.png", "name": "3_00013.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01n7FQCI1FJvfylpGF3_!!1080040467.png", "name": "3_00014.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01WMWleB1FJvfiRFR7k_!!1080040467.png", "name": "3_00015.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN015PRXfV1FJvfxnTnEr_!!1080040467.png", "name": "3_00016.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Rtm3Sb1FJvfxnTSRc_!!1080040467.png", "name": "3_00017.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN011mDRRx1FJvfrQlOal_!!1080040467.png", "name": "3_00018.png", "width": "100", "height": "100" },
            ],
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "1900",//大图宽度
            height: "100",//大图高度
            fWidth: 100,//一帧宽度
            fHeight: 100,//一帧高度
            count: 19,//总共帧数
            boomSpeed: 0.3,//播放速度
            loop: !true,//是否循环
          },
          skill_boom_Obj: {
            srcArr: [
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01KuXXy01FJvfiRGAyc_!!1080040467.png", "name": "3_00000.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN019e4BN31FJvfs37qDd_!!1080040467.png", "name": "3_00001.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ERncXL1FJvfrQnXmW_!!1080040467.png", "name": "3_00002.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01E7S5xd1FJvfvwiPcP_!!1080040467.png", "name": "3_00003.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01jnrqPr1FJvfvRWGkK_!!1080040467.png", "name": "3_00004.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN013fSK7l1FJvfnA2mKy_!!1080040467.png", "name": "3_00005.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN011o89ub1FJvftHPKkZ_!!1080040467.png", "name": "3_00006.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01GOAyX91FJvfogMejR_!!1080040467.png", "name": "3_00007.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01lGP6wh1FJvfpHzJ8a_!!1080040467.png", "name": "3_00008.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01NChvnZ1FJvfzU5FZD_!!1080040467.png", "name": "3_00009.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01egn5Ak1FJvftHPnob_!!1080040467.png", "name": "3_00010.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01xH4oos1FJvfx2TQ2Y_!!1080040467.png", "name": "3_00011.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01OdgoHW1FJvfvwg45B_!!1080040467.png", "name": "3_00012.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01RzMp7Z1FJvfogOX7y_!!1080040467.png", "name": "3_00013.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01DBn0Mq1FJvfsxthbU_!!1080040467.png", "name": "3_00014.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN013bDWwt1FJvfvwhft4_!!1080040467.png", "name": "3_00015.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN015Hy0W61FJvfsxt22B_!!1080040467.png", "name": "3_00016.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01yrX6k71FJvfvRVX1w_!!1080040467.png", "name": "3_00017.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01jp8GsD1FJvfnA5zvi_!!1080040467.png", "name": "3_00018.png", "width": "100", "height": "100" },
            ],
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "1900",//大图宽度
            height: "100",//大图高度
            fWidth: 100,//一帧宽度
            fHeight: 100,//一帧高度
            count: 19,//总共帧数
            boomSpeed: 0.3,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ruehD91FJvfsxtUya_!!1080040467.png",
          val: 10,
          probability: 1,//出现概率
          // 爆炸动画序列帧
          boomObj: {
            srcArr: [
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01ruehD91FJvfsxtUya_!!1080040467.png", "name": "4_00000.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01gCSJrN1FJvfrQiFAb_!!1080040467.png", "name": "4_00001.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01gazyDZ1FJvfxnT3W1_!!1080040467.png", "name": "4_00002.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01MAm51Y1FJvfnA3a6r_!!1080040467.png", "name": "4_00003.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01VH2EXv1FJvfnA3iPo_!!1080040467.png", "name": "4_00004.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01RVfLkB1FJvfylmqXm_!!1080040467.png", "name": "4_00005.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01yEJhqo1FJvfzU2Z7m_!!1080040467.png", "name": "4_00006.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01xJgcha1FJvfsxtQps_!!1080040467.png", "name": "4_00007.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01GYr1Z71FJvfuQvMWG_!!1080040467.png", "name": "4_00008.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ZNF2N51FJvfnA4r8T_!!1080040467.png", "name": "4_00009.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01vF9k9w1FJvfiRDlCB_!!1080040467.png", "name": "4_00010.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ZHIwDU1FJvfsxuAZZ_!!1080040467.png", "name": "4_00011.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0157mZq21FJvfvwfWhu_!!1080040467.png", "name": "4_00012.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01RDocIY1FJvfs35E35_!!1080040467.png", "name": "4_00013.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01kneN3Q1FJvfvRTzIf_!!1080040467.png", "name": "4_00014.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0102KgLh1FJvfvRW024_!!1080040467.png", "name": "4_00015.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01l9WI171FJvfx2SoV5_!!1080040467.png", "name": "4_00016.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01FZOazL1FJvfnA4iqj_!!1080040467.png", "name": "4_00017.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01kMiZn71FJvfvRUWYw_!!1080040467.png", "name": "4_00018.png", "width": "100", "height": "100" },
            ],
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "1900",//大图宽度
            height: "100",//大图高度
            fWidth: 100,//一帧宽度
            fHeight: 100,//一帧高度
            count: 19,//总共帧数
            boomSpeed: 0.3,//播放速度
            loop: !true,//是否循环
          },
          skill_boom_Obj: {
            srcArr: [
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN013VBRCC1FJvfxnVXWs_!!1080040467.png", "name": "4_00000.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01uTq6WR1FJvfuQxe1q_!!1080040467.png", "name": "4_00001.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01uCA7B81FJvfogOGVL_!!1080040467.png", "name": "4_00002.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01QzMCIu1FJvfrQmCeX_!!1080040467.png", "name": "4_00003.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01B1jxFK1FJvftHRPbf_!!1080040467.png", "name": "4_00004.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01p0yH2e1FJvfpHw9i3_!!1080040467.png", "name": "4_00005.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01wSU3Bq1FJvfxnYxbX_!!1080040467.png", "name": "4_00006.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Wm2SA21FJvfuR0KM6_!!1080040467.png", "name": "4_00007.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01bqajgH1FJvfrQmo3n_!!1080040467.png", "name": "4_00008.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01VNl8PQ1FJvfzU5r3y_!!1080040467.png", "name": "4_00009.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN019msKe01FJvfylscJf_!!1080040467.png", "name": "4_00010.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01kKrdHq1FJvfylqflW_!!1080040467.png", "name": "4_00011.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01X2VXkl1FJvfrT2S4l_!!1080040467.png", "name": "4_00012.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN015vWBjq1FJvfnA6jhf_!!1080040467.png", "name": "4_00013.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01kVXuGL1FJvfyls0uX_!!1080040467.png", "name": "4_00014.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01uUxmM01FJvfnA6OuD_!!1080040467.png", "name": "4_00015.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01tjHAi01FJvfpHw9j8_!!1080040467.png", "name": "4_00016.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Ob7eX81FJvfpHxhNW_!!1080040467.png", "name": "4_00017.png", "width": "100", "height": "100" },
              { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01Lh5pRv1FJvfx2VQms_!!1080040467.png", "name": "4_00018.png", "width": "100", "height": "100" },
            ],
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "1900",//大图宽度
            height: "100",//大图高度
            fWidth: 100,//一帧宽度
            fHeight: 100,//一帧高度
            count: 19,//总共帧数
            boomSpeed: 0.3,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
      ],
      // 九宫格技能 炸弹
      boom: {
        name: "boom",
        isSkill: true,
        src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01YXRLVc1FJvfiRI7om_!!1080040467.png",
        val: 10,
        // 默认显示时的序列帧动画 如果有srcArr会忽略src
        /* type: "animate",
        loop: true,
        srcArr: [
        ],
        srcArrSpeed: 0.08, */
        // 爆炸动画序列帧
        boom2Obj: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01YXRLVc1FJvfiRI7om_!!1080040467.png", "name": "1_00000.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ZRIwMb1FJvfnA7Xfv_!!1080040467.png", "name": "1_00001.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01vLPv3N1FJvfzUAt6f_!!1080040467.png", "name": "1_00002.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01UNuGto1FJvftHT1bq_!!1080040467.png", "name": "1_00003.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01jY0Al21FJvfogOs83_!!1080040467.png", "name": "1_00004.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01YgxJv11FJvfogRp4y_!!1080040467.png", "name": "1_00005.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ZsAp8B1FJvfvRay1R_!!1080040467.png", "name": "1_00006.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01TxowVt1FJvfvRYt7w_!!1080040467.png", "name": "1_00007.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN013CsUBn1FJvfs39vKl_!!1080040467.png", "name": "1_00008.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN019wRtmf1FJvfiRKXT6_!!1080040467.png", "name": "1_00009.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01bihwKR1FJvfrQoYO6_!!1080040467.png", "name": "1_00010.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01R67JYt1FJvfxnbiJl_!!1080040467.png", "name": "1_00011.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN017EGnu41FJvftHTlLn_!!1080040467.png", "name": "1_00012.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ID8JMs1FJvfogRxPy_!!1080040467.png", "name": "1_00013.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01yiewVp1FJvfxndanE_!!1080040467.png", "name": "1_00014.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01cBNhAF1FJvfiRKCgx_!!1080040467.png", "name": "1_00015.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01pONno41FJvfs39vLT_!!1080040467.png", "name": "1_00016.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01nhKG731FJvfyluA8w_!!1080040467.png", "name": "1_00017.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01FuMqim1FJvfs3ABxB_!!1080040467.png", "name": "1_00018.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01QCMFh91FJvftHSl1X_!!1080040467.png", "name": "1_00019.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01rablQm1FJvfx2XmUX_!!1080040467.png", "name": "1_00020.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01OPeQea1FJvfiRKo6y_!!1080040467.png", "name": "1_00021.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN013WuA7W1FJvfnA9l0R_!!1080040467.png", "name": "1_00022.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01OJh0tS1FJvfiRJ3zj_!!1080040467.png", "name": "1_00023.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01S1nxPX1FJvfvRaITr_!!1080040467.png", "name": "1_00024.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01i8zuXt1FJvfvwkUkK_!!1080040467.png", "name": "1_00025.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN019qlBiW1FJvfnA6XRe_!!1080040467.png", "name": "1_00026.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01y2qAqx1FJvfvwlV7Q_!!1080040467.png", "name": "1_00027.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01rtHBZC1FJvfxnd3Wo_!!1080040467.png", "name": "1_00028.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01sj90SE1FJvfiRJ896_!!1080040467.png", "name": "1_00029.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01LFi0yb1FJvfs39aZ5_!!1080040467.png", "name": "1_00030.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ZIX06Y1FJvftHT1dp_!!1080040467.png", "name": "1_00031.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ZO3M9a1FJvfogPkEz_!!1080040467.png", "name": "1_00032.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01MFLmMP1FJvftHTMPT_!!1080040467.png", "name": "1_00033.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01NxE2YE1FJvfylt5dA_!!1080040467.png", "name": "1_00034.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01TieAM31FJvfx2WhzV_!!1080040467.png", "name": "1_00035.png", "width": "100", "height": "100" },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "3600",//大图宽度
          height: "100",//大图高度
          fWidth: 100,//一帧宽度
          fHeight: 100,//一帧高度
          count: 36,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: !true,//是否循环
        },
        boomObj: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01JTWlUE1FJvfxndScE_!!1080040467.png", "name": "1_00000.png", "width": "100", "height": "100" },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "100",//大图宽度
          height: "100",//大图高度
          fWidth: 100,//一帧宽度
          fHeight: 100,//一帧高度
          count: 1,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: !true,//是否循环
        },
        audioName: "bomb2"
      },
      // 十字消除技能
      cross: {
        name: "cross",
        isSkill: true,
        srcArr: [
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01RjcJ6x1FJvaL2kc1w_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01djOFhV1FJvaKE7XSv_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN018VgEqA1FJvaI3KMot_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN012KRYpr1FJvaHT4lNk_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN014DUos91FJvaIBJULh_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01KM3c0S1FJvaI3KdQp_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01bLcznq1FJvaFT89bZ_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01gresXX1FJvaIBLdLB_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01EW8FwP1FJvaMrIlu0_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01gLQyr51FJvaLhpQKg_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN011kENJj1FJvaHWObeD_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01iavVQl1FJvaHWQDQO_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01wojuCv1FJvaMrIEdz_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01rS0WCR1FJvaKE9Lj2_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01wFIUzL1FJvaJvQSbj_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN015aLsa11FJvaJvQvga_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01VBKIjq1FJvaL2lDSD_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01bEzL2G1FJva9HTUnt_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN017yHyUo1FJvaKE8kKc_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01xvagrq1FJvaJvSo6N_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01RoE93Z1FJvaHWQoqE_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01BpRERF1FJvaMXAjwX_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01VDqs3T1FJvaHAePJ1_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01qxoWQ31FJvaMrIVIZ_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Y6DiuX1FJva9HS5VY_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01w8EubD1FJvaJvPrB0_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01onMP1v1FJvaHWObfX_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN017vAJe51FJvaHWPLPK_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01euSpJ31FJvaL2nlSC_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01z8BmTc1FJvaHWRUPb_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01BDdhzm1FJvaFT8Hw9_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01NoHmNw1FJvaFT95qC_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01awUH5M1FJvaIBLIZL_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01rhAWse1FJvaI3KdSU_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01lWSpXY1FJvaJvRKe9_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01jF5y2P1FJvaI3MVt5_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01vynkJp1FJvaI3LVVG_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01IWr6hy1FJvaF0PseZ_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01wlM4HA1FJvaLhoxFJ_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01pltUE71FJvaHT5ll5_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01xWLT1l1FJvaF0QPuE_!!1080040467.png", width: 110, height: 110 },
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01JUPzhN1FJvaHT6J1x_!!1080040467.png", width: 110, height: 110 }
        ],
        type: "animate",//标识为动画
        imgType: "max",//标识为大图
        width: "4620",//大图宽度
        height: "110",//大图高度
        fWidth: 110,//一帧宽度
        fHeight: 110,//一帧高度
        count: 42,//总共帧数
        boomSpeed: 0.5,//播放速度
        loop: true,//是否循环
        val: 10,
        probability: 100,//全消概率 此处概率相对于1000
        selectObj: {
          srcArr: [
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01dl3mha1FJvaBrK9k0_!!1080040467.png", "width": 110, "height": 110 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01HrKV2m1FJvaFPPdrE_!!1080040467.png", "width": 110, "height": 110 },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "220",//大图宽度
          height: "110",//大图高度
          fWidth: 110,//一帧宽度
          fHeight: 110,//一帧高度
          count: 2,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: true,//是否循环
        },
        // 爆炸动画序列帧
        boomObj: {
          srcArr: [
            { src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01QSkpNr1FJvaFPKDXy_!!1080040467.png", width: 110, height: 110 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01vQWadX1FJvaCYjiwa_!!1080040467.png", width: 110, height: 110 },
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01u1NgZ11FJvaHCzKCC_!!1080040467.png", width: 110, height: 110 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01gLQBYt1FJvaFPJwuK_!!1080040467.png", width: 110, height: 110 },
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01vCR2K31FJvaBXo457_!!1080040467.png", width: 110, height: 110 },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "550",//大图宽度
          height: "110",//大图高度
          fWidth: 110,//一帧宽度
          fHeight: 110,//一帧高度
          count: 5,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: !true,//是否循环
        },
        audioName: "bomb1"
      },
      // 横向消除
      horizontal: {
        name: "horizontal",
        isSkill: true,
        src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01GLto4W1FJvfvRdaJP_!!1080040467.png",
        isLine: true,//动画占用整行
        val: 10,
        otherBoomHide: !true,//此元素爆炸时，其他消除元素是否隐藏
        // 爆炸动画序列帧 先播放boom2Arr再播放boomArr
        boomObj: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01OXsroc1FJvfvwfjKE_!!1080040467.png", "name": "1_00000.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01mtMJ981FJvfiRFhvw_!!1080040467.png", "name": "1_00001.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01wTM7XD1FJvfpHvow6_!!1080040467.png", "name": "1_00002.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Fb8WHL1FJvfuQzK1N_!!1080040467.png", "name": "1_00003.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01pUJVdD1FJvfs38B6M_!!1080040467.png", "name": "1_00004.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01mYBEce1FJvfvwhXdq_!!1080040467.png", "name": "1_00005.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01zfYUc51FJvfuR0SiR_!!1080040467.png", "name": "1_00006.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01enJDYg1FJvfvRXPWX_!!1080040467.png", "name": "1_00007.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN018wEXD31FJvfnA5C6i_!!1080040467.png", "name": "1_00008.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01avgbNG1FJvfx2WEhu_!!1080040467.png", "name": "1_00009.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01E8wraQ1FJvfvwj18F_!!1080040467.png", "name": "1_00010.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eo9OQY1FJvfylqCf9_!!1080040467.png", "name": "1_00011.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01E1MFse1FJvfvwi956_!!1080040467.png", "name": "1_00012.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Bhbdr91FJvfzU90WE_!!1080040467.png", "name": "1_00013.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01RXUCMe1FJvfxnWHJn_!!1080040467.png", "name": "1_00014.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01htLPIS1FJvfvRWbcB_!!1080040467.png", "name": "1_00015.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01H764Zo1FJvfzU7X11_!!1080040467.png", "name": "1_00016.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0155b6ut1FJvftHS5Fi_!!1080040467.png", "name": "1_00017.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01AOmpnF1FJvfx2WdfD_!!1080040467.png", "name": "1_00018.png", "width": "650", "height": "100" },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "650",//大图宽度
          height: "1900",//大图高度
          fWidth: 650,//一帧宽度
          fHeight: 100,//一帧高度
          count: 19,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: !true,//是否循环
        },
        boom2Obj: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01GLto4W1FJvfvRdaJP_!!1080040467.png", "name": "1_00000.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tjcr6c1FJvftHXBb8_!!1080040467.png", "name": "1_00001.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01KwB4Kt1FJvfuR2HFu_!!1080040467.png", "name": "1_00002.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01nOHrcq1FJvfrT79Nt_!!1080040467.png", "name": "1_00003.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01r1rjgn1FJvftHXJvC_!!1080040467.png", "name": "1_00004.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN010K0JhA1FJvfnA9tPV_!!1080040467.png", "name": "1_00005.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01nTm45e1FJvfnA91O2_!!1080040467.png", "name": "1_00006.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01v5ssuc1FJvfylw6r4_!!1080040467.png", "name": "1_00007.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN019GLGAe1FJvfuR6hiy_!!1080040467.png", "name": "1_00008.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01OGHjBu1FJvfrQsRgn_!!1080040467.png", "name": "1_00009.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN016esXIl1FJvfiRKPKZ_!!1080040467.png", "name": "1_00010.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01RqBIX41FJvftHStPH_!!1080040467.png", "name": "1_00011.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01pYpTGv1FJvfuR4pHX_!!1080040467.png", "name": "1_00012.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01QHTSq71FJvfsxyTBK_!!1080040467.png", "name": "1_00013.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01JaqKci1FJvfrQpYro_!!1080040467.png", "name": "1_00014.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01FOnU8I1FJvfuR4pHi_!!1080040467.png", "name": "1_00015.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01NnUqpi1FJvfrQt7Fu_!!1080040467.png", "name": "1_00016.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01sBDsoV1FJvfnA8ouU_!!1080040467.png", "name": "1_00017.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01PDWqjZ1FJvfiRMQ1w_!!1080040467.png", "name": "1_00018.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01BPzEWY1FJvfvwldZd_!!1080040467.png", "name": "1_00019.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01eXsnxB1FJvfuR4MC9_!!1080040467.png", "name": "1_00020.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01RjVoYM1FJvfx2Yr5j_!!1080040467.png", "name": "1_00021.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01f5Tt7l1FJvfuR4Yf4_!!1080040467.png", "name": "1_00022.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01VG9Lnl1FJvfrQpxqU_!!1080040467.png", "name": "1_00023.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01nMbrd51FJvfrT692s_!!1080040467.png", "name": "1_00024.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN015W4d2F1FJvfiRL92h_!!1080040467.png", "name": "1_00025.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01pFnoEE1FJvfx2a86r_!!1080040467.png", "name": "1_00026.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01LTzxDM1FJvfxnc3H3_!!1080040467.png", "name": "1_00027.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01hXwPzC1FJvfsxzPPg_!!1080040467.png", "name": "1_00028.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01wiMe9O1FJvfnAAQhZ_!!1080040467.png", "name": "1_00029.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01zaf1ya1FJvfs3Ck5H_!!1080040467.png", "name": "1_00030.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01XoXUDP1FJvfogSlQe_!!1080040467.png", "name": "1_00031.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01wLiSbd1FJvfuR7F1V_!!1080040467.png", "name": "1_00032.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01JRigPf1FJvfsxz8ni_!!1080040467.png", "name": "1_00033.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN012Fpfub1FJvfx2Y7OH_!!1080040467.png", "name": "1_00034.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01JTWlUE1FJvfxndScE_!!1080040467.png", "name": "1_00035.png", "width": "100", "height": "100" },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "3600",//大图宽度
          height: "100",//大图高度
          fWidth: 100,//一帧宽度
          fHeight: 100,//一帧高度
          count: 36,//总共帧数
          boomSpeed: 2.5,//播放速度
          loop: !true,//是否循环
        },
        audioName: "bomb2"
      },
      // 纵向消除
      vertical: {
        name: "vertical",
        isSkill: true,
        src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01xj3XjJ1FJvfxnefTU_!!1080040467.png",
        isLine: true,//动画占用整行
        val: 10,
        otherBoomHide: !true,//此元素爆炸时，其他消除元素是否隐藏
        // 爆炸动画序列帧
        boomObj: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01HvkIvO1FJvfvRXD4I_!!1080040467.png", "name": "2_00000.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01KbS91B1FJvfvRZ5Su_!!1080040467.png", "name": "2_00001.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01fm38wk1FJvfnA4FvC_!!1080040467.png", "name": "2_00002.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01KTQmgV1FJvfnA78hn_!!1080040467.png", "name": "2_00003.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN016PTHiq1FJvfvRXkJ8_!!1080040467.png", "name": "2_00004.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01iOQcZW1FJvfxnZhQD_!!1080040467.png", "name": "2_00005.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01DyOAnc1FJvfxnXUBW_!!1080040467.png", "name": "2_00006.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01WW9UyJ1FJvfogR14F_!!1080040467.png", "name": "2_00007.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01IFTlDg1FJvfxnWobD_!!1080040467.png", "name": "2_00008.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01dIu6yX1FJvfpHylxB_!!1080040467.png", "name": "2_00009.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01EiCTlJ1FJvfxnXcY3_!!1080040467.png", "name": "2_00010.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN016v56YO1FJvfylsPv8_!!1080040467.png", "name": "2_00011.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01BcsKUe1FJvfnA80mC_!!1080040467.png", "name": "2_00012.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ubF3G51FJvfvwh0Pr_!!1080040467.png", "name": "2_00013.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01PKJWGL1FJvfvRZM7j_!!1080040467.png", "name": "2_00014.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01WKMvWc1FJvftHR0lI_!!1080040467.png", "name": "2_00015.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01DaKGrw1FJvfpI02wY_!!1080040467.png", "name": "2_00016.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01imVZnL1FJvfvRWsGS_!!1080040467.png", "name": "2_00017.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01YAldZF1FJvfvRWwQn_!!1080040467.png", "name": "2_00018.png", "width": "100", "height": "650" },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "1900",//大图宽度
          height: "650",//大图高度
          fWidth: 100,//一帧宽度
          fHeight: 650,//一帧高度
          count: 19,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: !true,//是否循环
        },
        boom2Obj: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01xj3XjJ1FJvfxnefTU_!!1080040467.png", "name": "2_00000.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ahJn2E1FJvfylwFJ6_!!1080040467.png", "name": "2_00001.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01gNoRnD1FJvfogTyJ3_!!1080040467.png", "name": "2_00002.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01M5ujwq1FJvfsy2MQ2_!!1080040467.png", "name": "2_00003.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN012sqXGo1FJvfs3DgM8_!!1080040467.png", "name": "2_00004.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01SL7oJU1FJvfrQuaqp_!!1080040467.png", "name": "2_00005.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01uRfXUT1FJvfrTAVNF_!!1080040467.png", "name": "2_00006.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01zBQZQO1FJvfsy0Pqj_!!1080040467.png", "name": "2_00007.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01MoOmrV1FJvfvRbuQe_!!1080040467.png", "name": "2_00008.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01gA8O391FJvfrT8DzM_!!1080040467.png", "name": "2_00009.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01xaHRrG1FJvfvRcB3C_!!1080040467.png", "name": "2_00010.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Jed9vb1FJvfpI2w5h_!!1080040467.png", "name": "2_00011.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01TxaWK61FJvfvwpvm3_!!1080040467.png", "name": "2_00012.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01PBSBZi1FJvfylx3Ax_!!1080040467.png", "name": "2_00013.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01W0AZ8D1FJvfvRenEa_!!1080040467.png", "name": "2_00014.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01yPaGv51FJvfsy1cgd_!!1080040467.png", "name": "2_00015.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ViPfV91FJvfrQrAkR_!!1080040467.png", "name": "2_00016.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01zIBKZJ1FJvfzUChcJ_!!1080040467.png", "name": "2_00017.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN015TozTf1FJvfvRdzNa_!!1080040467.png", "name": "2_00018.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015pJSxO1FJvfrTAEkd_!!1080040467.png", "name": "2_00019.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01nuyUSE1FJvfvwoaar_!!1080040467.png", "name": "2_00020.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01G1OhJR1FJvfsy2UjW_!!1080040467.png", "name": "2_00021.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01dxMhzN1FJvfsy054j_!!1080040467.png", "name": "2_00022.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN011TQ1v01FJvfnACuca_!!1080040467.png", "name": "2_00023.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01bKDwy91FJvfnACmIi_!!1080040467.png", "name": "2_00024.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN013rSMfy1FJvfs3E5KG_!!1080040467.png", "name": "2_00025.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01jaGouh1FJvfxnfwXu_!!1080040467.png", "name": "2_00026.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01EWqF2G1FJvfs3Egjm_!!1080040467.png", "name": "2_00027.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN019PByH41FJvfpI4D6Y_!!1080040467.png", "name": "2_00028.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ZTFAaV1FJvfuR4taL_!!1080040467.png", "name": "2_00029.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01J1IE4q1FJvfxnf4TA_!!1080040467.png", "name": "2_00030.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01G9mQyk1FJvfogUAps_!!1080040467.png", "name": "2_00031.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01TVdHHl1FJvfvRcFGt_!!1080040467.png", "name": "2_00032.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN018k4Bw71FJvfs3E1BT_!!1080040467.png", "name": "2_00033.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01y5qfiJ1FJvftHaH1U_!!1080040467.png", "name": "2_00034.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01tKj00O1FJvftHWzEx_!!1080040467.png", "name": "2_00035.png", "width": "100", "height": "100" },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "3600",//大图宽度
          height: "100",//大图高度
          fWidth: 100,//一帧宽度
          fHeight: 100,//一帧高度
          count: 36,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: !true,//是否循环
        },
        audioName: "bomb2"
      },
      audio: {
        default: { srcAudio: "http://isv-vod.alibabausercontent.com/RGjZJMdpNgKGVQeEyw8/md0TVJ9FNFauX46iy5H?auth_key=1600418297-0-0-abfad5e2fa6d2a568be518189562d827" },//默认音效
        bomb1: { srcAudio: "http://isv-vod.alibabausercontent.com/RGjZJMdpNgKGVQeEyw8/RNpLxsf1VfhnI3puBjI?auth_key=1600418314-0-0-5b59216722fd88b18586e7c605ad3b76" },//十字消除音效
        bomb2: { srcAudio: "http://isv-vod.alibabausercontent.com/RGjZJMdpNgKGVQeEyw8/RNpLxsf1VfhnI3puBjI?auth_key=1600418314-0-0-5b59216722fd88b18586e7c605ad3b76" },//炸弹音乐
        clearAudio: { srcAudio: "http://isv-vod.alibabausercontent.com/RGjZJMdpNgKGVQeEyw8/RNpLxsf1VfhnI3puBjI?auth_key=1600418314-0-0-5b59216722fd88b18586e7c605ad3b76" },//全屏消除音乐
      }
    },
    // 纪梵希消消乐配置
    gameSource2: {
      clickDelayTime: 300,//两次点击最小间隔时间
      row: 6,//行
      col: 6,//列
      autoStart: true,//自动开始游戏
      fadeBoomTop: !false,//消除动画是否在元素之上显示，然后一起消失 默认false（元素消失了再播放动画）
      showRect: { x: 20, y: 30, width: 650, height: 650 },
      moveSpeed: 0.1,//移动一格的时间 时间越大，速度越慢
      syncMove: !true,//同步移动
      startNoSkill: true,//开始游戏布局不生成技能元素
      gameStartPlayAudio: false,
      boomNum: 4,//生成炸弹的个数
      crossNum: 5,//配置合成十字消除
      // singleCross: 4,//配置横向或者纵向消除（需要配置horizontal(横向) 或 vertical(纵向)数据才有效）
      // 游戏元素
      items: [
        {
          src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01qzgEMv1FJvhisxSBR_!!1080040467.png",
          noMove: true,//不能移动----------------------------
          maxCount: 3,//出现的最多个数-------------------------------
          noSkill: true,//不生成技能元素-----------------------------------
          val: 1,
          probability: 1,//出现概率
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "330",//大图宽度
            height: "880",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 24,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01RdOyZc1FJvhqxKgTU_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "550",//大图宽度
            height: "110",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 5,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01lDuYlh1EUdLc0VuXA_!!2185320355.png",
          val: 1,
          probability: 1,//出现概率
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "330",//大图宽度
            height: "880",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 24,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01RdOyZc1FJvhqxKgTU_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "550",//大图宽度
            height: "110",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 5,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01OyHVuO1FJvhqxJbyH_!!1080040467.png",
          val: 1,
          probability: 1,//出现概率
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "330",//大图宽度
            height: "880",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 24,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01RdOyZc1FJvhqxKgTU_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "550",//大图宽度
            height: "110",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 5,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01ObW64M1EUdLZnIyMJ_!!2185320355.png",
          val: 1,
          probability: 1,//出现概率
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "330",//大图宽度
            height: "880",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 24,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01RdOyZc1FJvhqxKgTU_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "550",//大图宽度
            height: "110",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 5,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN012giINR1FJvhcXsWdz_!!1080040467.png",
          val: 1,
          probability: 1,//出现概率
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "330",//大图宽度
            height: "880",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 24,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01RdOyZc1FJvhqxKgTU_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "550",//大图宽度
            height: "110",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 5,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01JMWw6J1FJvi4gPR8K_!!1080040467.png",
          val: 1,
          probability: 1,//出现概率
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "330",//大图宽度
            height: "880",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 24,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01RdOyZc1FJvhqxKgTU_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "550",//大图宽度
            height: "110",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 5,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
      ],
      // 九宫格技能 炸弹
      boom: {
        name: "boom",
        isSkill: true,
        hideSelf: true,
        src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN0119qfcc1FJvi3y5k9h_!!1080040467.png",
        noPlayAni: true,//炸弹周围元素不执行动画
        type: "animate",//标识为动画
        imgType: "max",//标识为大图
        width: "990",//大图宽度
        height: "1100",//大图高度
        fWidth: 110,//一帧宽度
        fHeight: 110,//一帧高度
        count: 90,//总共帧数
        boomSpeed: 0.5,//播放速度
        loop: true,//是否循环
        val: 1,
        selectObj: {
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "330",//大图宽度
          height: "880",//大图高度
          fWidth: 110,//一帧宽度
          fHeight: 110,//一帧高度
          count: 24,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: true,//是否循环
        },
        // 爆炸动画序列帧
        boomObj: {
          src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01zysO981FJvi9XALjO_!!1080040467.png",
          anchor: { x: 0.5, y: 0.5 },//中心点
          offset: { x: 55, y: 55 },//偏移量
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "2028",//大图宽度
          height: "2366",//大图高度
          fWidth: 338,//一帧宽度
          fHeight: 338,//一帧高度
          count: 42,//总共帧数
          boomSpeed: 1.2,//播放速度
          loop: !true,//是否循环
        },
        audioName: "bomb2"
      },
      // 十字消除技能
      cross: {
        name: "cross",
        isSkill: true,
        hideSelf: true,
        src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01EtQl3n1FJvi0QNPzE_!!1080040467.png",
        noPlayAni: true,//炸弹周围元素不执行动画
        type: "animate",//标识为动画
        imgType: "max",//标识为大图
        width: "880",//大图宽度
        height: "1210",//大图高度
        fWidth: 110,//一帧宽度
        fHeight: 110,//一帧高度
        count: 88,//总共帧数
        boomSpeed: 0.5,//播放速度
        loop: true,//是否循环
        val: 10,
        probability: 0,//全消概率 此处概率相对于1000
        selectObj: {
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "330",//大图宽度
          height: "880",//大图高度
          fWidth: 110,//一帧宽度
          fHeight: 110,//一帧高度
          count: 24,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: true,//是否循环
        },
        // 爆炸动画序列帧
        boomObj: {
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01OKLaW31FJvi0TLq0w_!!1080040467.png",
          rX: 0,
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "1360",//大图宽度
          height: "2970",//大图高度
          fWidth: 680,//一帧宽度
          fHeight: 110,//一帧高度
          count: 54,//总共帧数
          boomSpeed: 1.2,//播放速度
          loop: !true,//是否循环
        },
        boomCopy: {
          src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01zcnrqV1FJvhyCi5OW_!!1080040467.png",
          rY: 0,
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "2970",//大图宽度
          height: "1360",//大图高度
          fWidth: 110,//一帧宽度
          fHeight: 680,//一帧高度
          count: 54,//总共帧数
          boomSpeed: 1.2,//播放速度
          loop: !true,//是否循环
        },
        audioName: "bomb1"
      },
      // 横向消除
      horizontal: {
        name: "horizontal",
        isSkill: true,
        src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01GLto4W1FJvfvRdaJP_!!1080040467.png",
        isLine: true,//动画占用整行
        val: 10,
        otherBoomHide: !true,//此元素爆炸时，其他消除元素是否隐藏
        // 爆炸动画序列帧 先播放boom2Arr再播放boomArr
        boomObj: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01OXsroc1FJvfvwfjKE_!!1080040467.png", "name": "1_00000.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01mtMJ981FJvfiRFhvw_!!1080040467.png", "name": "1_00001.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01wTM7XD1FJvfpHvow6_!!1080040467.png", "name": "1_00002.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01Fb8WHL1FJvfuQzK1N_!!1080040467.png", "name": "1_00003.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01pUJVdD1FJvfs38B6M_!!1080040467.png", "name": "1_00004.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01mYBEce1FJvfvwhXdq_!!1080040467.png", "name": "1_00005.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01zfYUc51FJvfuR0SiR_!!1080040467.png", "name": "1_00006.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01enJDYg1FJvfvRXPWX_!!1080040467.png", "name": "1_00007.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN018wEXD31FJvfnA5C6i_!!1080040467.png", "name": "1_00008.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01avgbNG1FJvfx2WEhu_!!1080040467.png", "name": "1_00009.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01E8wraQ1FJvfvwj18F_!!1080040467.png", "name": "1_00010.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eo9OQY1FJvfylqCf9_!!1080040467.png", "name": "1_00011.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01E1MFse1FJvfvwi956_!!1080040467.png", "name": "1_00012.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01Bhbdr91FJvfzU90WE_!!1080040467.png", "name": "1_00013.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01RXUCMe1FJvfxnWHJn_!!1080040467.png", "name": "1_00014.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01htLPIS1FJvfvRWbcB_!!1080040467.png", "name": "1_00015.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01H764Zo1FJvfzU7X11_!!1080040467.png", "name": "1_00016.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN0155b6ut1FJvftHS5Fi_!!1080040467.png", "name": "1_00017.png", "width": "650", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01AOmpnF1FJvfx2WdfD_!!1080040467.png", "name": "1_00018.png", "width": "650", "height": "100" },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "650",//大图宽度
          height: "1900",//大图高度
          fWidth: 650,//一帧宽度
          fHeight: 100,//一帧高度
          count: 19,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: !true,//是否循环
        },
        boom2Obj: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01GLto4W1FJvfvRdaJP_!!1080040467.png", "name": "1_00000.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01tjcr6c1FJvftHXBb8_!!1080040467.png", "name": "1_00001.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01KwB4Kt1FJvfuR2HFu_!!1080040467.png", "name": "1_00002.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01nOHrcq1FJvfrT79Nt_!!1080040467.png", "name": "1_00003.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01r1rjgn1FJvftHXJvC_!!1080040467.png", "name": "1_00004.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN010K0JhA1FJvfnA9tPV_!!1080040467.png", "name": "1_00005.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01nTm45e1FJvfnA91O2_!!1080040467.png", "name": "1_00006.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01v5ssuc1FJvfylw6r4_!!1080040467.png", "name": "1_00007.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN019GLGAe1FJvfuR6hiy_!!1080040467.png", "name": "1_00008.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01OGHjBu1FJvfrQsRgn_!!1080040467.png", "name": "1_00009.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN016esXIl1FJvfiRKPKZ_!!1080040467.png", "name": "1_00010.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01RqBIX41FJvftHStPH_!!1080040467.png", "name": "1_00011.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01pYpTGv1FJvfuR4pHX_!!1080040467.png", "name": "1_00012.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01QHTSq71FJvfsxyTBK_!!1080040467.png", "name": "1_00013.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01JaqKci1FJvfrQpYro_!!1080040467.png", "name": "1_00014.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01FOnU8I1FJvfuR4pHi_!!1080040467.png", "name": "1_00015.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01NnUqpi1FJvfrQt7Fu_!!1080040467.png", "name": "1_00016.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01sBDsoV1FJvfnA8ouU_!!1080040467.png", "name": "1_00017.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01PDWqjZ1FJvfiRMQ1w_!!1080040467.png", "name": "1_00018.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01BPzEWY1FJvfvwldZd_!!1080040467.png", "name": "1_00019.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01eXsnxB1FJvfuR4MC9_!!1080040467.png", "name": "1_00020.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01RjVoYM1FJvfx2Yr5j_!!1080040467.png", "name": "1_00021.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01f5Tt7l1FJvfuR4Yf4_!!1080040467.png", "name": "1_00022.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01VG9Lnl1FJvfrQpxqU_!!1080040467.png", "name": "1_00023.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01nMbrd51FJvfrT692s_!!1080040467.png", "name": "1_00024.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN015W4d2F1FJvfiRL92h_!!1080040467.png", "name": "1_00025.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01pFnoEE1FJvfx2a86r_!!1080040467.png", "name": "1_00026.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01LTzxDM1FJvfxnc3H3_!!1080040467.png", "name": "1_00027.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01hXwPzC1FJvfsxzPPg_!!1080040467.png", "name": "1_00028.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01wiMe9O1FJvfnAAQhZ_!!1080040467.png", "name": "1_00029.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01zaf1ya1FJvfs3Ck5H_!!1080040467.png", "name": "1_00030.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01XoXUDP1FJvfogSlQe_!!1080040467.png", "name": "1_00031.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01wLiSbd1FJvfuR7F1V_!!1080040467.png", "name": "1_00032.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01JRigPf1FJvfsxz8ni_!!1080040467.png", "name": "1_00033.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN012Fpfub1FJvfx2Y7OH_!!1080040467.png", "name": "1_00034.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01JTWlUE1FJvfxndScE_!!1080040467.png", "name": "1_00035.png", "width": "100", "height": "100" },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "3600",//大图宽度
          height: "100",//大图高度
          fWidth: 100,//一帧宽度
          fHeight: 100,//一帧高度
          count: 36,//总共帧数
          boomSpeed: 2.5,//播放速度
          loop: !true,//是否循环
        },
        audioName: "bomb2"
      },
      // 纵向消除
      vertical: {
        name: "vertical",
        isSkill: true,
        src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01xj3XjJ1FJvfxnefTU_!!1080040467.png",
        isLine: true,//动画占用整行
        val: 10,
        otherBoomHide: !true,//此元素爆炸时，其他消除元素是否隐藏
        // 爆炸动画序列帧
        boomObj: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01HvkIvO1FJvfvRXD4I_!!1080040467.png", "name": "2_00000.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01KbS91B1FJvfvRZ5Su_!!1080040467.png", "name": "2_00001.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01fm38wk1FJvfnA4FvC_!!1080040467.png", "name": "2_00002.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01KTQmgV1FJvfnA78hn_!!1080040467.png", "name": "2_00003.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN016PTHiq1FJvfvRXkJ8_!!1080040467.png", "name": "2_00004.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01iOQcZW1FJvfxnZhQD_!!1080040467.png", "name": "2_00005.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01DyOAnc1FJvfxnXUBW_!!1080040467.png", "name": "2_00006.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01WW9UyJ1FJvfogR14F_!!1080040467.png", "name": "2_00007.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01IFTlDg1FJvfxnWobD_!!1080040467.png", "name": "2_00008.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01dIu6yX1FJvfpHylxB_!!1080040467.png", "name": "2_00009.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01EiCTlJ1FJvfxnXcY3_!!1080040467.png", "name": "2_00010.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN016v56YO1FJvfylsPv8_!!1080040467.png", "name": "2_00011.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01BcsKUe1FJvfnA80mC_!!1080040467.png", "name": "2_00012.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ubF3G51FJvfvwh0Pr_!!1080040467.png", "name": "2_00013.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01PKJWGL1FJvfvRZM7j_!!1080040467.png", "name": "2_00014.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01WKMvWc1FJvftHR0lI_!!1080040467.png", "name": "2_00015.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01DaKGrw1FJvfpI02wY_!!1080040467.png", "name": "2_00016.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01imVZnL1FJvfvRWsGS_!!1080040467.png", "name": "2_00017.png", "width": "100", "height": "650" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01YAldZF1FJvfvRWwQn_!!1080040467.png", "name": "2_00018.png", "width": "100", "height": "650" },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "1900",//大图宽度
          height: "650",//大图高度
          fWidth: 100,//一帧宽度
          fHeight: 650,//一帧高度
          count: 19,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: !true,//是否循环
        },
        boom2Obj: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01xj3XjJ1FJvfxnefTU_!!1080040467.png", "name": "2_00000.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01ahJn2E1FJvfylwFJ6_!!1080040467.png", "name": "2_00001.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01gNoRnD1FJvfogTyJ3_!!1080040467.png", "name": "2_00002.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01M5ujwq1FJvfsy2MQ2_!!1080040467.png", "name": "2_00003.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN012sqXGo1FJvfs3DgM8_!!1080040467.png", "name": "2_00004.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01SL7oJU1FJvfrQuaqp_!!1080040467.png", "name": "2_00005.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01uRfXUT1FJvfrTAVNF_!!1080040467.png", "name": "2_00006.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01zBQZQO1FJvfsy0Pqj_!!1080040467.png", "name": "2_00007.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01MoOmrV1FJvfvRbuQe_!!1080040467.png", "name": "2_00008.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01gA8O391FJvfrT8DzM_!!1080040467.png", "name": "2_00009.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01xaHRrG1FJvfvRcB3C_!!1080040467.png", "name": "2_00010.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01Jed9vb1FJvfpI2w5h_!!1080040467.png", "name": "2_00011.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01TxaWK61FJvfvwpvm3_!!1080040467.png", "name": "2_00012.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01PBSBZi1FJvfylx3Ax_!!1080040467.png", "name": "2_00013.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01W0AZ8D1FJvfvRenEa_!!1080040467.png", "name": "2_00014.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01yPaGv51FJvfsy1cgd_!!1080040467.png", "name": "2_00015.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01ViPfV91FJvfrQrAkR_!!1080040467.png", "name": "2_00016.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01zIBKZJ1FJvfzUChcJ_!!1080040467.png", "name": "2_00017.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN015TozTf1FJvfvRdzNa_!!1080040467.png", "name": "2_00018.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN015pJSxO1FJvfrTAEkd_!!1080040467.png", "name": "2_00019.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01nuyUSE1FJvfvwoaar_!!1080040467.png", "name": "2_00020.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01G1OhJR1FJvfsy2UjW_!!1080040467.png", "name": "2_00021.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01dxMhzN1FJvfsy054j_!!1080040467.png", "name": "2_00022.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN011TQ1v01FJvfnACuca_!!1080040467.png", "name": "2_00023.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01bKDwy91FJvfnACmIi_!!1080040467.png", "name": "2_00024.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN013rSMfy1FJvfs3E5KG_!!1080040467.png", "name": "2_00025.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01jaGouh1FJvfxnfwXu_!!1080040467.png", "name": "2_00026.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01EWqF2G1FJvfs3Egjm_!!1080040467.png", "name": "2_00027.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i3/1080040467/O1CN019PByH41FJvfpI4D6Y_!!1080040467.png", "name": "2_00028.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ZTFAaV1FJvfuR4taL_!!1080040467.png", "name": "2_00029.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01J1IE4q1FJvfxnf4TA_!!1080040467.png", "name": "2_00030.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01G9mQyk1FJvfogUAps_!!1080040467.png", "name": "2_00031.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01TVdHHl1FJvfvRcFGt_!!1080040467.png", "name": "2_00032.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i1/1080040467/O1CN018k4Bw71FJvfs3E1BT_!!1080040467.png", "name": "2_00033.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01y5qfiJ1FJvftHaH1U_!!1080040467.png", "name": "2_00034.png", "width": "100", "height": "100" },
            { "src": "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01tKj00O1FJvftHWzEx_!!1080040467.png", "name": "2_00035.png", "width": "100", "height": "100" },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "3600",//大图宽度
          height: "100",//大图高度
          fWidth: 100,//一帧宽度
          fHeight: 100,//一帧高度
          count: 36,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: !true,//是否循环
        },
        audioName: "bomb2"
      },
      audio: {
        default: { srcAudio: "http://isv-vod.alibabausercontent.com/mk8pOHtSi7MPYyhqseq/OUYnodGjrmfRTVKo7Rw?auth_key=1648879783-0-0-fe84360762aff9b50a2ef5c9cb4dd40e&w=0&h=0&e=sd&t=2132e43616486205834606540e17c2&s=86B9DCF207E360F6A0A7C7CBD0E89C70" },//默认音效
        bomb1: { srcAudio: "http://isv-vod.alibabausercontent.com/mk8pOHtSi7MPYyhqseq/OUYnodGjrmfRTVKo7Rw?auth_key=1648879783-0-0-fe84360762aff9b50a2ef5c9cb4dd40e&w=0&h=0&e=sd&t=2132e43616486205834606540e17c2&s=86B9DCF207E360F6A0A7C7CBD0E89C70" },//十字消除音效
        bomb2: { srcAudio: "http://isv-vod.alibabausercontent.com/mk8pOHtSi7MPYyhqseq/OUYnodGjrmfRTVKo7Rw?auth_key=1648879783-0-0-fe84360762aff9b50a2ef5c9cb4dd40e&w=0&h=0&e=sd&t=2132e43616486205834606540e17c2&s=86B9DCF207E360F6A0A7C7CBD0E89C70" },//炸弹音乐
        clearAudio: { srcAudio: "http://isv-vod.alibabausercontent.com/mk8pOHtSi7MPYyhqseq/OUYnodGjrmfRTVKo7Rw?auth_key=1648879783-0-0-fe84360762aff9b50a2ef5c9cb4dd40e&w=0&h=0&e=sd&t=2132e43616486205834606540e17c2&s=86B9DCF207E360F6A0A7C7CBD0E89C70" },//全屏消除音乐
      }
    },
    gameSource3: {
      clickDelayTime: 300,//两次点击最小间隔时间
      row: 6,//行
      col: 6,//列
      autoStart: true,//自动开始游戏
      // fadeBoomTop: !false,//消除动画是否在元素之上显示，然后一起消失 默认false（元素消失了再播放动画）
      showRect: { x: 30, y: 30, width: 690, height: 690 },
      moveSpeed: 0.1,//移动一格的时间 时间越大，速度越慢
      syncMove: !true,//同步移动
      startNoSkill: true,//开始游戏布局不生成技能元素
      gameStartPlayAudio: false,
      // boomNum: 4,//生成炸弹的个数
      // crossNum: 4,//配置合成十字消除
      singleCross: 4,//配置横向或者纵向消除（需要配置horizontal(横向) 或 vertical(纵向)数据才有效）
      singleCross2: true,//true，合成时，超过singleCross个数就会合成
      // 游戏元素
      items: [
        {
          src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01YwKszW1EUdMxcpUv5_!!2185320355.png",
          noMove: true,//不能移动----------------------------
          maxCount: 3,//出现的最多个数-------------------------------
          noSkill: true,//不生成技能元素-----------------------------------
          val: 1,
          probability: 1,//出现概率
          hideSelf: true,
          otherBoomHide: true,//此元素爆炸时，其他消除元素是否隐藏
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "330",//大图宽度
            height: "880",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 24,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01Sgz2YN23c08lCwisR_!!555657275.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "672",//大图宽度
            height: "448",//大图高度
            fWidth: 112,//一帧宽度
            fHeight: 112,//一帧高度
            count: 26,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01Zcm8x41EUdMqEL9zU_!!2185320355.png",
          val: 1,
          probability: 1,//出现概率
          hideSelf: true,
          otherBoomHide: true,//此元素爆炸时，其他消除元素是否隐藏
          noSkill: true,//不生成技能元素-----------------------------------
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "330",//大图宽度
            height: "880",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 24,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01Sgz2YN23c08lCwisR_!!555657275.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "672",//大图宽度
            height: "448",//大图高度
            fWidth: 112,//一帧宽度
            fHeight: 112,//一帧高度
            count: 26,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01zQcQVQ1EUdMxcn9Ne_!!2185320355.png",
          val: 1,
          probability: 1,//出现概率
          hideSelf: true,
          otherBoomHide: true,//此元素爆炸时，其他消除元素是否隐藏
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "330",//大图宽度
            height: "880",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 24,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01Sgz2YN23c08lCwisR_!!555657275.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "672",//大图宽度
            height: "448",//大图高度
            fWidth: 112,//一帧宽度
            fHeight: 112,//一帧高度
            count: 26,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          // 固定在爆炸位置的静态精灵
          fixArr: [
            { src: "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01hXsqOH1EUdNGWX6h4_!!2185320355.png", offset: { x: 0, y: 0 } },
          ],
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01YFbPXB1EUdMumFHXz_!!2185320355.png",
          val: 1,
          probability: 1,//出现概率
          hideSelf: true,
          otherBoomHide: true,//此元素爆炸时，其他消除元素是否隐藏
          noSkill: true,//不生成技能元素-----------------------------------
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "330",//大图宽度
            height: "880",//大图高度
            fWidth: 110,//一帧宽度
            fHeight: 110,//一帧高度
            count: 24,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i2/555657275/O1CN01Sgz2YN23c08lCwisR_!!555657275.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "672",//大图宽度
            height: "448",//大图高度
            fWidth: 112,//一帧宽度
            fHeight: 112,//一帧高度
            count: 26,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          // 固定在爆炸位置的静态精灵
          fixArr: [
            { src: "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01hXsqOH1EUdNGWX6h4_!!2185320355.png", offset: { x: 0, y: 0 } },
          ],
          audioName: "default"
        },
      ],
      // 横向消除
      horizontal: {
        name: "horizontal",
        isSkill: true,
        // src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01GLto4W1FJvfvRdaJP_!!1080040467.png",
        srcArr: [
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01lRxPws1EUdMzccJE7_!!2185320355.png", "name": "瓶子_00000.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01M2OeUD1EUdMq9zsrw_!!2185320355.png", "name": "瓶子_00001.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01o5XW5h1EUdMtlc9jL_!!2185320355.png", "name": "瓶子_00002.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01oWsN6r1EUdMrz0REO_!!2185320355.png", "name": "瓶子_00003.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01YAo2Ak1EUdMsS79Gp_!!2185320355.png", "name": "瓶子_00004.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN010zRmpl1EUdMyly646_!!2185320355.png", "name": "瓶子_00005.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01O2ojPw1EUdMq9z0no_!!2185320355.png", "name": "瓶子_00006.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01Kirv3d1EUdMq9xjmd_!!2185320355.png", "name": "瓶子_00007.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN015Rg7KA1EUdMqsR5JR_!!2185320355.png", "name": "瓶子_00008.png", "width": "112", "height": "112" },
        ],
        type: "animate",
        imgType: "max",
        width: 112,
        height: 1008,
        fWidth: 112,
        fHeight: 112,
        count: 9,
        boomSpeed: 0.5,
        loop: true,
        bgImg: {
          src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01LXNE3T1EUdMzdNEXN_!!2185320355.png"
        },

        isLine: true,//动画占用整行
        val: 10,
        // 爆炸动画序列帧 先播放boom2Arr再播放boomArr
        boomObj: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01hzYY5b23c08uiYLRe_!!555657275.png", "name": "横00.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01epTmKa23c08upOhlQ_!!555657275.png", "name": "横01.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01oIOAFq23c08yRShY7_!!555657275.png", "name": "横02.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01sMYZJ223c08upRJws_!!555657275.png", "name": "横03.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01ZM9Uup23c08yRR1dn_!!555657275.png", "name": "横04.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01P2tzOQ23c092E6GaH_!!555657275.png", "name": "横05.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01JkUFO623c08wesf6Q_!!555657275.png", "name": "横06.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01GhlykI23c08zNXG3I_!!555657275.png", "name": "横07.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01izL39623c08vYEoBn_!!555657275.png", "name": "横08.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01a762EB23c092E646e_!!555657275.png", "name": "横09.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01jtHNda23c08uia9iT_!!555657275.png", "name": "横10.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN019hyl8z23c08vYCOWU_!!555657275.png", "name": "横11.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01hImbWJ23c08werWPo_!!555657275.png", "name": "横12.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01DAmqru23c094I7lwQ_!!555657275.png", "name": "横13.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01RLsnGo23c08sOHci2_!!555657275.png", "name": "横14.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN016pCq6E23c08x7lXl0_!!555657275.png", "name": "横15.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01LcGJFv23c094I5Ua3_!!555657275.png", "name": "横16.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01FRSQkJ23c093ROzmC_!!555657275.png", "name": "横17.png", "width": "700", "height": "112" },
            { "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01Jztvql23c08zNZP82_!!555657275.png", "name": "横18.png", "width": "700", "height": "112" },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "700",//大图宽度
          height: "2128",//大图高度
          fWidth: 700,//一帧宽度
          fHeight: 112,//一帧高度
          count: 19,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: !true,//是否循环
          offset: {
            x: 0,
            y: 0,
          }
        },
        selectObj: {
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "330",//大图宽度
          height: "880",//大图高度
          fWidth: 110,//一帧宽度
          fHeight: 110,//一帧高度
          count: 24,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: true,//是否循环
        },
        audioName: "bomb2"
      },
      // 纵向消除
      vertical: {
        name: "vertical",
        isSkill: true,
        // src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01xj3XjJ1FJvfxnefTU_!!1080040467.png",
        srcArr: [
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01lRxPws1EUdMzccJE7_!!2185320355.png", "name": "瓶子_00000.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01M2OeUD1EUdMq9zsrw_!!2185320355.png", "name": "瓶子_00001.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01o5XW5h1EUdMtlc9jL_!!2185320355.png", "name": "瓶子_00002.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01oWsN6r1EUdMrz0REO_!!2185320355.png", "name": "瓶子_00003.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01YAo2Ak1EUdMsS79Gp_!!2185320355.png", "name": "瓶子_00004.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN010zRmpl1EUdMyly646_!!2185320355.png", "name": "瓶子_00005.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01O2ojPw1EUdMq9z0no_!!2185320355.png", "name": "瓶子_00006.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01Kirv3d1EUdMq9xjmd_!!2185320355.png", "name": "瓶子_00007.png", "width": "112", "height": "112" },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN015Rg7KA1EUdMqsR5JR_!!2185320355.png", "name": "瓶子_00008.png", "width": "112", "height": "112" },
        ],
        type: "animate",
        imgType: "max",
        width: 112,
        height: 1008,
        fWidth: 112,
        fHeight: 112,
        count: 9,
        boomSpeed: 0.5,
        loop: true,
        bgImg: {
          src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01LXNE3T1EUdMzdNEXN_!!2185320355.png"
        },

        isLine: true,//动画占用整行
        val: 10,
        // 爆炸动画序列帧
        boomObj: {
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01GH0HBO23c08q6Z0F5_!!555657275.png", "name": "竖00.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01k6oz6P23c08zNfNji_!!555657275.png", "name": "竖01.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01GlAJFr23c08vYMjLd_!!555657275.png", "name": "竖02.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01Xc7uKZ23c08zNiKfs_!!555657275.png", "name": "竖03.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01YVHSXX23c08upUwua_!!555657275.png", "name": "竖04.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01dFupHH23c091RCXjV_!!555657275.png", "name": "竖05.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01bFqGwt23c094IFd2r_!!555657275.png", "name": "竖06.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN016dX2tM23c08sOPPbp_!!555657275.png", "name": "竖07.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01Y1uhNN23c08yRZU1u_!!555657275.png", "name": "竖08.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i2/555657275/O1CN01rXWIFn23c08yRbIJC_!!555657275.png", "name": "竖09.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01cCjJLt23c08yRags1_!!555657275.png", "name": "竖10.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01zuoVhH23c08q6YnnY_!!555657275.png", "name": "竖11.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i1/555657275/O1CN01xWwnVJ23c08upXpjv_!!555657275.png", "name": "竖12.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01Dq5zVz23c092ECJG3_!!555657275.png", "name": "竖13.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01U0tL1k23c091RC4bE_!!555657275.png", "name": "竖14.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01wJP2D723c08rexiCJ_!!555657275.png", "name": "竖15.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i4/555657275/O1CN01pTntDm23c08rewZWk_!!555657275.png", "name": "竖16.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN01DMXMWn23c092EFSh8_!!555657275.png", "name": "竖17.png", "width": "112", "height": "700" },
            { "src": "https://img.alicdn.com/imgextra/i3/555657275/O1CN014WvhLu23c093RVAnz_!!555657275.png", "name": "竖18.png", "width": "112", "height": "700" },
          ],
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "2128",//大图宽度
          height: "700",//大图高度
          fWidth: 112,//一帧宽度
          fHeight: 700,//一帧高度
          count: 19,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: !true,//是否循环
          offset: {
            x: 0,
            y: 0
          }
        },
        selectObj: {
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01eQDTui1FJvi3xtOGA_!!1080040467.png",
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "330",//大图宽度
          height: "880",//大图高度
          fWidth: 110,//一帧宽度
          fHeight: 110,//一帧高度
          count: 24,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: true,//是否循环
        },
        audioName: "bomb2"
      },
      audio: {
        default: { srcAudio: "http://isv-vod.alibabausercontent.com/mk8pOHtSi7MPYyhqseq/IkmmyXfFa1Y7NqXjCZz?auth_key=1656898315-0-0-f4f78b31d26030a01d7a3eaf8dec72c5&w=0&h=0&e=sd&t=2132c91a16566391149857420e3428&b=tb_rcpaasm&p=*_null&tr=aac-264-sd" },//炸弹音乐
        bomb2: { srcAudio: "http://isv-vod.alibabausercontent.com/mk8pOHtSi7MPYyhqseq/2GbqzXZIG2vg7L4jDgD?auth_key=1656898307-0-0-66658c05cb7326b18b1e5f26f07fd4ad&w=0&h=0&e=sd&t=2132c91a16566391073076820e3428&b=tb_rcpaasm&p=*_null&tr=aac-264-sd" },//默认音效
      }
    },
    // 朵梵配置
    gameSource: {
      clickDelayTime: 300,//两次点击最小间隔时间
      row: 6,//行
      col: 6,//列
      autoStart: true,//自动开始游戏
      // fadeBoomTop: !false,//消除动画是否在元素之上显示，然后一起消失 默认false（元素消失了再播放动画）
      showRect: { x: 30, y: 30, width: 690, height: 690 },
      moveSpeed: 0.1,//移动一格的时间 时间越大，速度越慢
      syncMove: !true,//同步移动
      startNoSkill: true,//开始游戏布局不生成技能元素
      gameStartPlayAudio: false,
      // boomNum: 4,//生成炸弹的个数
      // crossNum: 4,//配置合成十字消除
      singleCross: 4,//配置横向或者纵向消除（需要配置horizontal(横向) 或 vertical(纵向)数据才有效）
      singleCross2: true,//true，合成时，超过singleCross个数就会合成
      // 游戏元素
      items: [
        {
          src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01QdhHEZ1EUdNtLFVPn_!!2185320355.png",
          val: 1,
          probability: 1,//出现概率
          hideSelf: true,
          otherBoomHide: true,//此元素爆炸时，其他消除元素是否隐藏
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01KoY6t01EUdNqy2e0Z_!!2185320355.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "115",//大图宽度
            height: "115",//大图高度
            fWidth: 115,//一帧宽度
            fHeight: 115,//一帧高度
            count: 1,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01vgUei11EUdNqysweI_!!2185320355.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "805",//大图宽度
            height: "460",//大图高度
            fWidth: 115,//一帧宽度
            fHeight: 115,//一帧高度
            count: 26,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          // 固定在爆炸位置的静态精灵
          fixArr: [
            { src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01iAIVDr1EUdO1YDaG7_!!2185320355.png", offset: { x: 0, y: 0 } },
          ],
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01LOvRQz1EUdO2OyZmj_!!2185320355.png",
          val: 1,
          probability: 1,//出现概率
          hideSelf: true,
          otherBoomHide: true,//此元素爆炸时，其他消除元素是否隐藏
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01KoY6t01EUdNqy2e0Z_!!2185320355.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "115",//大图宽度
            height: "115",//大图高度
            fWidth: 115,//一帧宽度
            fHeight: 115,//一帧高度
            count: 1,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01vgUei11EUdNqysweI_!!2185320355.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "805",//大图宽度
            height: "460",//大图高度
            fWidth: 115,//一帧宽度
            fHeight: 115,//一帧高度
            count: 26,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          // 固定在爆炸位置的静态精灵
          fixArr: [
            { src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01iAIVDr1EUdO1YDaG7_!!2185320355.png", offset: { x: 0, y: 0 } },
          ],
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01K5rI4C1EUdNjxUTEm_!!2185320355.png",
          val: 1,
          probability: 1,//出现概率
          hideSelf: true,
          otherBoomHide: true,//此元素爆炸时，其他消除元素是否隐藏
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01KoY6t01EUdNqy2e0Z_!!2185320355.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "115",//大图宽度
            height: "115",//大图高度
            fWidth: 115,//一帧宽度
            fHeight: 115,//一帧高度
            count: 1,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01vgUei11EUdNqysweI_!!2185320355.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "805",//大图宽度
            height: "460",//大图高度
            fWidth: 115,//一帧宽度
            fHeight: 115,//一帧高度
            count: 26,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          // 固定在爆炸位置的静态精灵
          fixArr: [
            { src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01iAIVDr1EUdO1YDaG7_!!2185320355.png", offset: { x: 0, y: 0 } },
          ],
          audioName: "default"
        },
        {
          src: "https://img.alicdn.com/imgextra/i2/2185320355/O1CN015mnAbj1EUdNtDqQuS_!!2185320355.png",
          val: 1,
          probability: 1,//出现概率
          hideSelf: true,
          otherBoomHide: true,//此元素爆炸时，其他消除元素是否隐藏
          selectObj: {
            src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01KoY6t01EUdNqy2e0Z_!!2185320355.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "115",//大图宽度
            height: "115",//大图高度
            fWidth: 115,//一帧宽度
            fHeight: 115,//一帧高度
            count: 1,//总共帧数
            boomSpeed: 0.5,//播放速度
            loop: true,//是否循环
          },
          // 爆炸动画序列帧
          boomObj: {
            src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01vgUei11EUdNqysweI_!!2185320355.png",
            type: "animate",//标识为动画
            imgType: "max",//标识为大图
            width: "805",//大图宽度
            height: "460",//大图高度
            fWidth: 115,//一帧宽度
            fHeight: 115,//一帧高度
            count: 26,//总共帧数
            boomSpeed: 0.4,//播放速度
            loop: !true,//是否循环
          },
          // 固定在爆炸位置的静态精灵
          fixArr: [
            { src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01iAIVDr1EUdO1YDaG7_!!2185320355.png", offset: { x: 0, y: 0 } },
          ],
          audioName: "default"
        },
      ],
      // 横向消除
      horizontal: {
        name: "horizontal",
        isSkill: true,
        srcArr: [
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01AYFyut1EUdNu0h0gE_!!2185320355.png", "name": "瓶子_00000.png", "width": "115", "height": "115" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01WSmQV31EUdNqzzxLx_!!2185320355.png", "name": "瓶子_00001.png", "width": "115", "height": "115" },
        ],
        type: "animate",
        imgType: "max",
        width: 115,
        height: 230,
        fWidth: 115,
        fHeight: 115,
        count: 2,
        boomSpeed: 0.1,
        loop: true,
        // bgImg: {
        //   src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01LXNE3T1EUdMzdNEXN_!!2185320355.png"
        // },

        val: 1,
        // 爆炸动画序列帧
        boomObj: {
          src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01vgUei11EUdNqysweI_!!2185320355.png",
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "805",//大图宽度
          height: "460",//大图高度
          fWidth: 115,//一帧宽度
          fHeight: 115,//一帧高度
          count: 26,//总共帧数
          boomSpeed: 0.4,//播放速度
          loop: !true,//是否循环
        },
        selectObj: {
          src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01KoY6t01EUdNqy2e0Z_!!2185320355.png",
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "115",//大图宽度
          height: "115",//大图高度
          fWidth: 115,//一帧宽度
          fHeight: 115,//一帧高度
          count: 1,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: true,//是否循环
        },
        audioName: "bomb2"
      },
      // 纵向消除
      vertical: {
        name: "vertical",
        isSkill: true,
        // src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01of4CDO1EUdNxgtWql_!!2185320355.png",
        srcArr: [
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01AYFyut1EUdNu0h0gE_!!2185320355.png", "name": "瓶子_00000.png", "width": "115", "height": "115" },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01WSmQV31EUdNqzzxLx_!!2185320355.png", "name": "瓶子_00001.png", "width": "115", "height": "115" },
        ],
        type: "animate",
        imgType: "max",
        width: 115,
        height: 230,
        fWidth: 115,
        fHeight: 115,
        count: 2,
        boomSpeed: 0.1,
        loop: true,
        // bgImg: {
        //   src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01LXNE3T1EUdMzdNEXN_!!2185320355.png"
        // },

        val: 1,
        // 爆炸动画序列帧
        boomObj: {
          src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01vgUei11EUdNqysweI_!!2185320355.png",
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "805",//大图宽度
          height: "460",//大图高度
          fWidth: 115,//一帧宽度
          fHeight: 115,//一帧高度
          count: 26,//总共帧数
          boomSpeed: 0.4,//播放速度
          loop: !true,//是否循环
        },
        selectObj: {
          src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01KoY6t01EUdNqy2e0Z_!!2185320355.png",
          type: "animate",//标识为动画
          imgType: "max",//标识为大图
          width: "115",//大图宽度
          height: "115",//大图高度
          fWidth: 115,//一帧宽度
          fHeight: 115,//一帧高度
          count: 1,//总共帧数
          boomSpeed: 0.5,//播放速度
          loop: true,//是否循环
        },
        audioName: "bomb2"
      },
      audio: {
        default: { srcAudio: "http://isv-vod.alibabausercontent.com/mk8pOHtSi7MPYyhqseq/IkmmyXfFa1Y7NqXjCZz?auth_key=1656898315-0-0-f4f78b31d26030a01d7a3eaf8dec72c5&w=0&h=0&e=sd&t=2132c91a16566391149857420e3428&b=tb_rcpaasm&p=*_null&tr=aac-264-sd" },//炸弹音乐
        bomb2: { srcAudio: "http://isv-vod.alibabausercontent.com/mk8pOHtSi7MPYyhqseq/2GbqzXZIG2vg7L4jDgD?auth_key=1656898307-0-0-66658c05cb7326b18b1e5f26f07fd4ad&w=0&h=0&e=sd&t=2132c91a16566391073076820e3428&b=tb_rcpaasm&p=*_null&tr=aac-264-sd" },//默认音效
      }
    }
  },
  onLoad() {
    this.time1 = +new Date();
  },

  overFun() {
    this.gameComponent.onEvent("gameOver");
  },
  beginFun() {
    /* my.alert({
      content: "游戏开始"
    }) */
    // this.gameComponent.onEvent("start");
  },
  muteFun() {
    // 静音
    this.gameComponent.onEvent("mute");
  },
  playFun() {
    // 播放
    this.gameComponent.onEvent("play");
  },
  resetFun() {
    // 传递参数 level，对应关卡
    this.gameComponent.onEvent("reset", 2);
  },
  clearFun() {
    this.gameComponent.onEvent("clear");
  },
  refreshFun() {
    console.log("刷新")
    this.gameComponent.onEvent("refresh");
  },
  onRef(ref) {
    this.gameComponent = ref;
  },

  onGameOver(score) {
    console.log("游戏结束：", score)
  },
  onInitDone(obj) {
    // 游戏重置也会回调
    /* my.alert({
      content: "游戏初始化完成" + obj.renderTime + "--" + (obj.endTime - this.time1)
    }) */
    this.beginFun();
  },
  onUpdate(item) {
    // curFadeArr：本次消除的元素个数（fadeNum）totalFadeArr：本局消除的元素个数（fadeNum）
    // {curScore,totalScore,curFadeArr,totalFadeArr}
    this.setData({
      totalScore: item.totalScore,
      curScore: item.curScore
    })
    let fadeNum = 0;
    item.totalFadeArr.forEach(item => {
      if (item.noMove) {
        fadeNum = item.fadeNum;
      }
    })
    console.error("不能移动的元素消除个数", fadeNum)
    console.log("update:", item)
    // my.alert({
    //   content: "游戏消除了"
    // })
  },
  onRefreshCallback(bl) {
    console.log("刷新回调：", bl)
  },
  onClearCallback(bl) {
    console.log("全消回调：", bl)
  },
  onSkillCallback(obj) {
    // 返回技能
    // {new:[新生成的技能],all:[所有技能]}
    console.log("生成技能回调：", obj)
  },
  onNoMoveCallback() {
    // this.refreshFun();
    // 没有可移动元素回调
    console.log("页面上没有可移动的元素了")
    my.alert({
      content: "页面上没有可移动的元素了"
    })
  },
  onShareAppMessage(e) {
    my.alert({ content: "分享" })
    return {
      title: "title",
      desc: "desc",
      url: "https://m.duanqu.com?_ariver_appid=3000000067861941&page=pages%2findex%2findex",
      // path: "pages/index/index",
      success: (e) => { },
    };
  },
});

```

- xaml

```
  <view class="pageBox">
    <view class="gameBox">
      <game gameSource="{{gameSource}}" onRef="onRef" onInitDone="onInitDone" onUpdate="onUpdate" onGameOver="onGameOver" onRefreshCallback="onRefreshCallback" 
        onClearCallback="onClearCallback" onSkillCallback="onSkillCallback" onNoMoveCallback="onNoMoveCallback" />
    </view>
    
    <view style="height: 10vh;">总分数：{{totalScore || 0}} 本次消除分数：{{curScore|| 0}}</view>
    <view onTap="clearFun" style="position:absolute;left: 0rpx;bottom: 0;">全消</view>
    <view onTap="beginFun" style="position:absolute;left: 100rpx;bottom: 0;">开始</view>
    <view onTap="overFun" style="position:absolute;left: 200rpx;bottom: 0;">停止</view>
    <view onTap="resetFun" style="position:absolute;left: 300rpx;bottom: 0;">重置</view>
    <view onTap="refreshFun" style="position:absolute;left: 400rpx;bottom: 0;">刷新</view>
    <view onTap="muteFun" style="position:absolute;left: 500rpx;bottom: 0;">静音</view>
    <view onTap="playFun" style="position:absolute;left: 600rpx;bottom: 0;">播放</view>
  </view>
```