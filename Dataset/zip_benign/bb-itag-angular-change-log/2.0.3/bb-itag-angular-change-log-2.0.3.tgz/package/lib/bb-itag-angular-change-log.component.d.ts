import { IChangeLogInfo } from './models';
export declare class BbItagAngularChangeLogComponent {
    changeLogInfos: IChangeLogInfo[];
    classNameTitle: string;
}
