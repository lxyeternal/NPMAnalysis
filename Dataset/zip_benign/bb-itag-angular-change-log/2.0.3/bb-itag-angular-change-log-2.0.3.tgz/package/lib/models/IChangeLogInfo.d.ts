import { IChangeLogFixInfo } from './IChangeLogFixInfo';
export interface IChangeLogInfo {
    fixes: IChangeLogFixInfo[];
    releaseDate: string;
    version: string;
}
