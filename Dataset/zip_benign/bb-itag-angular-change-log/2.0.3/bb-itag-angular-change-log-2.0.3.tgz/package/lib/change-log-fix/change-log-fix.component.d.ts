import { OnInit } from '@angular/core';
import { IChangeLogFixInfo } from '../models';
export declare class ChangeLogFixComponent implements OnInit {
    typeIcon: any;
    changeLogFix: IChangeLogFixInfo;
    ngOnInit(): void;
}
