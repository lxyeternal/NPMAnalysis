export declare class BbItagAngularChangeLogModule {
}
