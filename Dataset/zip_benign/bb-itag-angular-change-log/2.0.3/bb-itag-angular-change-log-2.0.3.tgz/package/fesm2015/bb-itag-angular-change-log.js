import { __decorate } from 'tslib';
import { Input, Component, NgModule } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { CommonModule } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatToolbarModule } from '@angular/material/toolbar';
import { FlexModule } from '@angular/flex-layout';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MatButtonModule } from '@angular/material/button';
import { faBug, faPuzzlePiece } from '@fortawesome/free-solid-svg-icons';

let BbItagAngularChangeLogComponent = class BbItagAngularChangeLogComponent {
    constructor() {
        this.classNameTitle = 'title';
    }
};
__decorate([
    Input()
], BbItagAngularChangeLogComponent.prototype, "changeLogInfos", void 0);
__decorate([
    Input()
], BbItagAngularChangeLogComponent.prototype, "classNameTitle", void 0);
BbItagAngularChangeLogComponent = __decorate([
    Component({
        selector: 'lib-bb-itag-angular-change-log',
        template: "<mat-accordion>\r\n  <mat-expansion-panel *ngFor=\"let versionInfo of changeLogInfos\">\r\n    <mat-expansion-panel-header>\r\n      <mat-panel-title>\r\n        version: {{ versionInfo.version }}\r\n      </mat-panel-title>\r\n      <mat-panel-description>\r\n        released: {{ versionInfo.releaseDate | date: \"EE, MMM d, y\" }}\r\n      </mat-panel-description>\r\n    </mat-expansion-panel-header>\r\n    <div class=\"full-row\" [ngClass]=\"classNameTitle\" fxLayout=\"row\" >\r\n      <div fxFlex=\"20\">issueNo</div>\r\n      <div fxFlex=\"60\">title</div>\r\n      <div fxFlex=\"20\">type</div>\r\n    </div>\r\n    <lib-change-log-fix *ngFor=\"let changeLogFix of versionInfo.fixes\" [changeLogFix]=\"changeLogFix\"></lib-change-log-fix>\r\n  </mat-expansion-panel>\r\n</mat-accordion>\r\n",
        styles: [".title{background-color:#4fc3f7;font-weight:bolder;margin-top:5px;margin-bottom:5px;height:25px}"]
    })
], BbItagAngularChangeLogComponent);

let ChangeLogFixComponent = class ChangeLogFixComponent {
    ngOnInit() {
        if (this.changeLogFix.type === 'bug') {
            this.typeIcon = faBug;
        }
        else if (this.changeLogFix.type === 'feature') {
            this.typeIcon = faPuzzlePiece;
        }
    }
};
__decorate([
    Input()
], ChangeLogFixComponent.prototype, "changeLogFix", void 0);
ChangeLogFixComponent = __decorate([
    Component({
        selector: 'lib-change-log-fix',
        template: "<div class=\"full-row box\" fxLayout=\"column\">\r\n  <div class=\"full-row\" fxLayout=\"row\" >\r\n    <div fxFlex=\"20\">{{ changeLogFix.issueNo }}</div>\r\n    <div fxFlex=\"60\">{{ changeLogFix.title }}</div>\r\n    <div fxFlex=\"20\">{{ changeLogFix.type }}<fa-icon [icon]=\"typeIcon\" class=\"faIconClass\"></fa-icon></div>\r\n  </div>\r\n  <div class=\"full-row\" fxFlex=\"grow\">{{ changeLogFix.description }}</div>\r\n</div>\r\n",
        styles: [".box{border:1px solid rgba(0,0,0,.03);box-shadow:0 2px 2px rgba(0,0,0,.24),0 0 2px rgba(0,0,0,.12);margin-bottom:5px}.faIconClass{margin-left:5px}"]
    })
], ChangeLogFixComponent);

let BbItagAngularChangeLogModule = class BbItagAngularChangeLogModule {
};
BbItagAngularChangeLogModule = __decorate([
    NgModule({
        declarations: [
            BbItagAngularChangeLogComponent,
            ChangeLogFixComponent,
        ],
        imports: [
            CommonModule,
            MatCardModule,
            MatExpansionModule,
            MatTabsModule,
            MatToolbarModule,
            MatButtonModule,
            FlexModule,
            FontAwesomeModule,
            FontAwesomeModule,
        ],
        exports: [BbItagAngularChangeLogComponent]
    })
], BbItagAngularChangeLogModule);

/*
 * Public API Surface of bb-itag-angular-change-log
 */

/**
 * Generated bundle index. Do not edit.
 */

export { BbItagAngularChangeLogComponent, BbItagAngularChangeLogModule, ChangeLogFixComponent };
//# sourceMappingURL=bb-itag-angular-change-log.js.map
