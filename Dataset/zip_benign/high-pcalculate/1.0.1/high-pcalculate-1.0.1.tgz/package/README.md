
## 安装
```js
# Using npm
npm install high-pcalculate

# Using yarn
yarn add high-pcalculate
```

## 使用
```js
import highPcalculate from 'high-pcalculate'

const { add, subtract, multiply, divide } = highPcalculate

add(0.1, 0.2)
// 0.30000000000000004
// 0.3(处理后值)

subtract(1.1, 0.2)
// 0.9000000000000001
// 0.9(处理后值)

multiply(1.1, 0.1)
// 0.11000000000000001
// 0.11(处理后值)

divide(1.1, 10)
// 0.11000000000000001
// 0.11(处理后值)


