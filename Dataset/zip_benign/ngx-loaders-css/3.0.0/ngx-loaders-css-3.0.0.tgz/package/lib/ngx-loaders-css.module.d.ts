import * as i0 from "@angular/core";
import * as i1 from "./ngx-loaders-css.component";
import * as i2 from "@angular/common";
export declare class NgxLoadersCssModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxLoadersCssModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NgxLoadersCssModule, [typeof i1.NgxLoadersCssComponent], [typeof i2.CommonModule], [typeof i1.NgxLoadersCssComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NgxLoadersCssModule>;
}
