import { ElementRef, QueryList } from '@angular/core';
import * as i0 from "@angular/core";
export declare class NgxLoadersCssComponent {
    spinners?: QueryList<ElementRef>;
    bgColor: string;
    color: string;
    $loader: LoadersCSS;
    children: unknown[];
    set loader(loader: LoadersCSS);
    $scale: string;
    set scale(scale: number);
    private updateSpinnersColor;
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxLoadersCssComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NgxLoadersCssComponent, "loaders-css", never, { "bgColor": "bgColor"; "color": "color"; "loader": "loader"; "scale": "scale"; }, {}, never, never>;
}
export declare type LoadersCSS = 'ball-pulse' | 'ball-grid-pulse' | 'ball-clip-rotate' | 'ball-clip-rotate-pulse' | 'square-spin' | 'ball-clip-rotate-multiple' | 'ball-pulse-rise' | 'ball-rotate' | 'cube-transition' | 'ball-zig-zag' | 'ball-zig-zag-deflect' | 'ball-triangle-path' | 'ball-scale' | 'line-scale' | 'line-scale-party' | 'ball-scale-multiple' | 'ball-pulse-sync' | 'ball-beat' | 'line-scale-pulse-out' | 'line-scale-pulse-out-rapid' | 'ball-scale-ripple' | 'ball-scale-ripple-multiple' | 'ball-spin-fade-loader' | 'line-spin-fade-loader' | 'triangle-skew-spin' | 'pacman' | 'ball-grid-beat' | 'semi-circle-spin';
