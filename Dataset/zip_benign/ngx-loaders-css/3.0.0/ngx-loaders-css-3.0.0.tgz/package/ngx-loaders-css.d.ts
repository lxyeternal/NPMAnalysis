/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ngx-loaders-css" />
export * from './public_api';
