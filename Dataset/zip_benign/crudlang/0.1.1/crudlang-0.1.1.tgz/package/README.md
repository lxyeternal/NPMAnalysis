

                   The CrudLang Project
            

The CrudLang Project is an attempt to build a small kernel that will do it all. In other words, you should be able to create any application with configuration only and no coding. Of course, it is not there yet. But by adding a lot of common modules over time, hope is there that we will cover all application usage in the digital realm.

The philosophy of this project is based on CRUD principles, URI paths and JSON datatypes. We want to expand these basics with JSON-LD semantics and RDF graph storage model. We feel that by normalizing a JSON-LD document a certain way, we will have a graph store functionally, even if the underlying database storage engine is not a graph storage per se.

Speaking of database, we want to support the widest types of databases. For a start, we will support MySQL and MongoDB. But others are to come. Finally, we want the technology stack used in this project to be part of the "MEAN stack" movement (aiming to reach the LAMP stack popularity). So we will also be using NodeJS and AngularJS. But CrudLang is more of a protocol than an application. So we want to be able to support integration and mixing of other technologies too (servlets, dotNet, jQuery, graph stores and other SQL database types).

For now the humble immediate goal is to have these interfaces running:
- File browser
- Database manager
- Personal agenda
- Contact book
- Spreadsheet
- Chat interface
- 3D virtual world

More interfaces will be added later on.

To run the project, just execute the main.js file with node. Of course, you need to have Node JS installed on your machine. You might have to do a npm install if the needed dependencies are not installed globally on your machine. You also have to create a config.json file that contains the informations needed for your users and databases. This file must be either in the current directory, the home directory of the current user or in the /etc/crudlang directory. You will find an example of config.json in the doc directory. Once the config.json file is created, you can add users and groups in it with the configuser.js script.



