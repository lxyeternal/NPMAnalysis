#!/usr/local/bin/node

args = process.argv.slice(2);
if (args.length < 1) {
   console.log("Syntax: dbuser.js <dburl> [key=value [key=value [...]]]");
   process.exit(1);
}
var mongo = require('mongodb').MongoClient;
var urlparser = require('url');
eval(require('fs').readFileSync("lib.js", {encoding:'utf8'}));

var dburl = args[0];
var keys = args.slice(1);
var urlparts = urlparser.parse(dburl);
var protocol = urlparts.protocol.replace(':','');
if (protocol != "mongodb") {
   console.log("Unsupported url: "+dburl);
   process.exit(1);
}

mongo.connect(dburl, function(err, db) {
   if (err)
      console.log(err);
   else if (urlparts.auth) {
      var auth = urlparts.auth.split(":");
      db.admin().authenticate(auth[0], auth[1], function(err, result) {
         if (err) {
            console.log(err);
            db.close();
         }
         else
            runCommand(db);
      });
   }
   else
      runCommand(db);
});

function runCommand(db) {
   if (keys.length == 0)
      return listUsers(db);

   var user = {};
   var action = buildUser(user);
   if (action == null)
      return db.close();
   
   switch (action) {
      case 'add':
         return addUser(user, db);
      case 'update':
         return updateUser(user, db);
      case 'delete':
         return deleteUser(user, db);
      case 'search':
         return searchUser(user, db);
      default:
         console.log("Invalid action "+action+"\nValid actions are: add, update, delete, search");
         db.close();
   }
}

function listUsers(db) {
   db.collection("system.users").find({}).toArray(function(err, users) {
      if (err)
         console.log(err);
      else if (users.length == 0)
         console.log("No user in this database");
      else
         for (var u in users) {
            var user = users[u];
            delete user.credentials;
            console.log(JSON.stringify(user));
         }
      db.close();
   });
}

function buildUser(user) {
   var action;
   for (var i in keys) {
      var parts = keys[i].split('=');
      if (parts.length == 1) {
         var parts = keys[i].split(':');
         if (parts.length == 1) {
            if (!action)
               action = parts[0];
            continue;
         }
      }
      user[parts[0]] = parts[1];
   }
   if (!user.user)
      return console.log("Empty username");
   if (!user.db)
      user.db = urlparts.pathname.split("/")[1];
   if (user.roles) {
      var roles = user.roles.split(",");
      for (var i in roles) {
         var role = roles[i];
         roles[i] = {role:role.trim(), db:user.db};
      }
      user.roles = roles;
   }
   return action || "search";
}

function addUser(user, db) {
   if (!user.roles)
      user.roles = [{role:"dbOwner", db:user.db}];
   db.admin().addUser(user.user, user.pwd||user.pass||user.password,
                      {roles:user.roles}, function(err, result) {
      console.log(err || result);
      db.close();
   });
}

function updateUser(user, db) {
   db.collection("system.users").findOneAndUpdate({user:user.user, db:user.db},
                                                  {$set: user}, function(err, result) {
      console.log(err || result);
       db.close();
   });
}

function deleteUser(user, db) {
   db.admin().removeUser(user.user, function(err, result) {
      console.log(err || result);
      db.close();
   });
}

function searchUser(user, db) {
   db.collection("system.users").find({user:user.user, db:user.db}).toArray(function(err, users) {
      if (err) {
         console.log(err);
         db.close();
      }
      else if (users.length == 0)
         addUser(user, db);
      else
         updateUser(user, db);
   });
}

// use this in mongo shell to create the first user
// db.createUser({user:"user",pwd:"pwd",roles:[{role:"userAdminAnyDatabase",db:"admin"}]})


