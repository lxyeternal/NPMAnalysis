#!/usr/bin/env node

args = process.argv.slice(2);
if (args.length < 3) {
   console.log("Syntax: configuser.js <config-file> <username> <password>");
   process.exit(1);
}
var fs = require('fs');
var lib = require("./ui/lib");
var salt = lib.editable(require('crypto').randomBytes(16));
//TODO: if (args[2] == '-' || args[1] starts with '-') user should be removed
var configFilename = args[0];
var password = lib.crypt(args[2], salt);
var user = {username:args[1], password:password, salt:salt};
console.log(JSON.print(user));

var config = JSON.parse(fs.readFileSync(configFilename, {encoding:'utf8'}));
config.users = lib.array(config.users, "username");
var found = false;
for (var u in config.users) {
   if (config.users[u].username == user.username) {
      config.users[u].password = user.password;
      config.users[u].salt = user.salt;
      found = true;
      break;
   }
}
if (!found)
   config.users.push(user);
   
if (args.length > 3) {
   var groups = {};
   for (var i = 3; i < args.length; i++) {
      //TODO: a minus in front would mean to remove user from this group
      group = args[i];
      groups[group] = group;
   }
   config.groups = lib.array(config.groups);
   for (var g in config.groups) {
      var group = config.groups[g];
      var name = null;
      var users = null;
      for (var i in group) {
         name = i;
         users = group[name];
         break;
      }
      if (name != null && groups[name] != null) {
         if (users == null)
            users = group[name] = [];
         else if (!(users instanceof Array))
            users = group[name] = [users];
         users.push(user.username);
         delete groups[name];
      }
   }
   for (var g in groups) {
      var name = groups[g];
      var group = {};
      group[name] = [user.username];
      config.groups.push(group);
   }
}
   
fs.writeFileSync(configFilename, JSON.print(config));   


