var title = "Database Manager";
var serviceUrl = "/mongo/";
var width = (window.innerWidth || document.documentElement.clientWidth);
var height = (window.innerHeight || document.documentElement.clientHeight) - 100;

angular.module('DataApp', [])
   // rest service to fetch data from the database
   .factory('dataService', function($http) {
      var service = {
         getDatabases: function() {
            return $http({
               method: 'GET',
               url: serviceUrl
            });
         },
         getTables: function(database) {
            return $http({
               method: 'GET',
               url: serviceUrl + database
            });
         },
         getRows: function(database, table) {
            return $http({
               method: 'GET',
               url: serviceUrl + database + "/" + table
            });
         }
      };
      return service;
   })
   // main controller
   .controller('dataController', function($scope, dataService) {
      var w = parseInt(width / 2);
      var h = parseInt(height / 2);
      var x = parseInt((width - w) / 4);
      var y = parseInt((height - h) / 4);
      $scope.editWindowDimensions = "position:absolute;left:"+x+"px;top:"+y+"px;width:"+w+"px;height:"+h+"px;"
      $scope.title = document.title = title;
      $scope.databases = [];
      $scope.database = null;
      $scope.tables = [];
      $scope.table = null;
      $scope.fields = [];
      $scope.rows = [];
      $scope.selectedRow = null;
      // call to load databases list
      dataService.getDatabases().success(function (response) {
         $scope.databases = response || [];
      });
      // called when a database is selected in the databases list
      $scope.$watch("database", function(newdb, olddb) {
         if (newdb) {
            dataService.getTables(newdb).success(function (response) {
               $scope.tables = response || [];
            });
         }
      });
      // called when a table is clicked in the tables list
      $scope.$watch("table", function(newtable, oldtable) {
         if (newtable && $scope.database) {
            dataService.getRows($scope.database, newtable).success(function (response) {
               if (response == null || response.length == 0)
                  $scope.fields = "This table is empty";
               else {
                  var fields = [];
                  for (var f in response[0])
                     fields.push(f);
                  $scope.fields = fields;
               }
               $scope.rows = response;
            });
         }
      });
   })
   // style filter for data cells
   .filter('style', function() {
      return function(value) {
         switch (typeof(value)) {
            case 'number':
               return 'text-align:right;white-space:nowrap;';
            case 'boolean':
               return 'text-align:center;';
            default:
               return validDate(value) ? 'text-align:left;white-space:nowrap;' : 'text-align:left;';
         }
      }
   });

