var datetimeseparators = ['t','T',' ','\t','\n'];
var htmlescapes = {"&":"&amp;", "<":"&lt;", ">":"&gt;", "'":"&#39;", '"':"&#34;"};
var htmlcolors = {
	"black":"#000000","silver":"#c0c0c0","gray":"#808080","white":"#ffffff","maroon":"#800000","red":"#ff0000","purple":"#800080","fuchsia":"#ff00ff",
	"green":"#008000","lime":"#00ff00","olive":"#808000","yellow":"#ffff00","navy":"#000080","blue":"#0000ff","teal":"#008080","aqua":"#00ffff",
	"orange":"#ffa500","aliceblue":"#f0f8ff","antiquewhite":"#faebd7","aquamarine":"#7fffd4","azure":"#f0ffff","beige":"#f5f5dc","bisque":"#ffe4c4",
	"blanchedalmond":"#ffe4c4","blueviolet":"#8a2be2","brown":"#a52a2a","burlywood":"#deb887","cadetblue":"#5f9ea0","chartreuse":"#7fff00",
	"chocolate":"#d2691e","coral":"#ff7f50","cornflowerblue":"#6495ed","cornsilk":"#fff8dc","crimson":"#dc143c","darkblue":"#00008b",
	"darkcyan":"#008b8b","darkgoldenrod":"#b8860b","darkgray":"#a9a9a9","darkgreen":"#006400","darkgrey":"#a9a9a9","darkkhaki":"#bdb76b",
	"darkmagenta":"#8b008b","darkolivegreen":"#556b2f","darkorange":"#ff8c00","darkorchid":"#9932cc","darkred":"#8b0000","darksalmon":"#e9967a",
	"darkseagreen":"#8fbc8f","darkslateblue":"#483d8b","darkslategray":"#2f4f4f","darkslategrey":"#2f4f4f","darkturquoise":"#00ced1","darkviolet":"#9400d3",
	"deeppink":"#ff1493","deepskyblue":"#00bfff","dimgray":"#696969","dimgrey":"#696969","dodgerblue":"#1e90ff","firebrick":"#b22222","floralwhite":"#fffaf0",
	"forestgreen":"#228b22","gainsboro":"#dcdcdc","ghostwhite":"#f8f8ff","gold":"#ffd700","goldenrod":"#daa520","greenyellow":"#adff2f","grey":"#808080",
	"honeydew":"#f0fff0","hotpink":"#ff69b4","indianred":"#cd5c5c","indigo":"#4b0082","ivory":"#fffff0","khaki":"#f0e68c","lavender":"#e6e6fa","lavenderblush":"#fff0f5",
	"lawngreen":"#7cfc00","lemonchiffon":"#fffacd","lightblue":"#add8e6","lightcoral":"#f08080","lightcyan":"#e0ffff","lightgoldenrodyellow":"#fafad2",
	"lightgray":"#d3d3d3","lightgreen":"#90ee90","lightgrey":"#d3d3d3","lightpink":"#ffb6c1","lightsalmon":"#ffa07a","lightseagreen":"#20b2aa","lightskyblue":"#87cefa",
	"lightslategrey":"#778899","lightsteelblue":"#b0c4de","lightyellow":"#ffffe0","limegreen":"#32cd32","linen":"#faf0e6","mediumaquamarine":"#66cdaa","mediumblue":"#0000cd",
	"mediumorchid":"#ba55d3","mediumpurple":"#9370db","mediumseagreen":"#3cb371","mediumslateblue":"#7b68ee","mediumspringgreen":"#00fa9a","mediumturquoise":"#48d1cc",
	"mediumvioletred":"#c71585","midnightblue":"#191970","mintcream":"#f5fffa","mistyrose":"#ffe4e1","moccasin":"#ffe4b5","navajowhite":"#ffdead","oldlace":"#fdf5e6",
	"olivedrab":"#6b8e23","orangered":"#ff4500","orchid":"#da70d6","palegoldenrod":"#eee8aa","palegreen":"#98fb98","paleturquoise":"#afeeee","palevioletred":"#db7093",
	"papayawhip":"#ffefd5","peachpuff":"#ffdab9","peru":"#cd853f","pink":"#ffc0cb","plum":"#dda0dd","powderblue":"#b0e0e6","rosybrown":"#bc8f8f","royalblue":"#4169e1",
	"saddlebrown":"#8b4513","salmon":"#fa8072","sandybrown":"#f4a460","seagreen":"#2e8b57","seashell":"#fff5ee","sienna":"#a0522d","skyblue":"#87ceeb","slateblue":"#6a5acd",
	"slategray":"#708090","snow":"#fffafa","springgreen":"#00ff7f","steelblue":"#4682b4","tan":"#d2b48c","thistle":"#d8bfd8","tomato":"#ff6347","turquoise":"#40e0d0",
	"violet":"#ee82ee","wheat":"#f5deb3","whitesmoke":"#f5f5f5","yellowgreen":"#9acd32","rebeccapurple":"#663399"};
var operatorlabels = null; 
var operatordefinitions = 
[{
   js:"==",
   mongo:"$eq",
   sql:"=",
   fr:"égal",
   en:"equal"
}, {
   js:">",
   mongo:"$gt",
   sql:">",
   fr:"plus grand",
   en:"greater"
}, {
   js:">=",
   mongo:"$gte",
   sql:">=",
   fr:"plus grand ou égal",
   en:"greater or equal"
}, {
   js:"<",
   mongo:"$lt",
   sql:"<",
   fr:"plus petit",
   en:"lesser"
}, {
   js:"<=",
   mongo:"$lte",
   sql:"<=",
   fr:"plus petit ou égal",
   en:"lesser or equal"
}, {
   js:"!=",
   mongo:"$ne",
   sql:"!=",
   fr:"non égal",
   en:"not equal"
}, {
   js:"have",
   mongo:"$in",
   sql:" in ",
   fr:"dans",
   en:"in"
}, {
   js:"havenot",
   mongo:"$nin",
   sql:" not in ",
   fr:"pas dans",
   en:"not in"
}, {
   js:"||",
   mongo:"$or",
   sql:" or ",
   fr:"ou",
   en:"or"
}, {
   js:"&&",
   mongo:"$and",
   sql:" and ",
   fr:"et",
   en:"and"
}, {
   js:"not",
   mongo:"$not",
   sql:" not ",
   fr:"non",
   en:"not"
}];
if (typeof(alert) != "function") {
   if (typeof(console) == "object")
      alert = function(txt) { console.log(txt); };
   else if (typeof(java) == "object")
      alert = function(txt) { java.lang.System.println(txt); };
   else if (typeof(print) == "function")
      alert = print;
   else
      throw new Error("Cannot detect system");
}
if (typeof(moment) == "function")
   moment.prototype.toString = function() { return this.format("YYYY-MM-DD HH:mm:ss.SSS"); };
if (JSON.tabulation == null)
   JSON.tabulation = "   ";
if (typeof(JSON.print) != "function") {
   // JSON pretty printing function
   JSON.print = function(src, tab) {
      if (tab == null)
         tab = "";
      switch (type(src)) {
         case 'null':
            return tab+"null";
         case 'array':
            var txt = tab+"[";
            var tab2 = JSON.tabulation + tab;
            for (var i = 0; i < src.length; i++) {
               if (i > 0)
                  txt += ",";
               txt += "\n"+JSON.print(src[i], tab2);
            }
            if (src.length > 0)
               txt += "\n"+tab;
            return txt + "]";
         case 'date':
            return tab+'"'+src.getFullYear()
                      +"-"+(src.getMonth()+101).toString().substring(1)
                      +"-"+(src.getDate()+100).toString().substring(1)
                      +"T"+(src.getHours()+100).toString().substring(1)
                      +":"+(src.getMinutes()+100).toString().substring(1)
                      +":"+(src.getSeconds()+100).toString().substring(1)
                      +"."+(src.getMilliseconds()+1000).toString().substring(1)
                      +'"';
         case 'regexp':
            return tab+JSON.stringify(src.toString());
         case 'object':
            var txt = tab+"{";
            var tab2 = JSON.tabulation + tab;
            var first = true;
            for (var key in src) {
               if (first)
                  first = false;
               else
                  txt += ",";
               txt += "\n"+tab2+JSON.stringify(key)+": "+JSON.print(src[key], tab2).substring(tab2.length);
            }
            if (!first)
               txt += "\n"+tab;
            return txt + "}";
         case 'function':
            src = src.toString();
            src = src.substring(0,src.indexOf('{')).trim();
         default:
            return tab+JSON.stringify(src);
      }
   };
}

// debug function to display object fields with circular protection
function extractFields(src, fields) {
   var dst = {};
   if (fields) {
      for (var f in fields) {
         var field = (fields instanceof Array) ? fields[f] : f;
         dst[field] = src[field];
      }
   }
   else if (src instanceof Array) {
      var lst = [];
      for (var e in src)
         lst.push(extractFields(src[e]));
      return lst;
   }
   else {
      for (var f in src) {
         var value = src[f];
         var type = typeof(value);
         if (value == null)
            dst[f] = null;
         else if (type == "object")
            dst[f] = value.constructor.name;
         else
            dst[f] = type;
      }
   }
   return dst;
}

// merge duplicate object properties into array values
function addFields(obj, fields) {
   if (obj == null || typeof(obj) != "object")
      obj = {value:obj};
   if (fields instanceof Array) {
      for (var i in fields)
         addFields(obj, fields[i]);
   }
   else if (fields != null) {
      for (var i in fields) {
         var old = obj[i];
         var value = fields[i];
         if (old == null)
            obj[i] = value;
         else if (old instanceof Array)
            old.push(value);
         else
            obj[i] = [old, value];
      }
   }
   return obj;
}

// clone an object and its properties values
function deepClone(src) {
   if (src == null || typeof(src) != 'object')
      return src;
   switch (type(src)) {
      case 'date':
         return new Date(src.getTime());
      case 'array':
         var dst = [];
         for (var i in src)
            dst[i] = deepClone(src[i]);
         return dst;
      case 'object':
         var dst = {};
         for (var i in src)
            dst[i] = deepClone(src[i]);
         return dst;
      default:
         return src;
   }
}

// split a string into a list of single word strings
function parseWords(txt, separators) {
   if (txt == null)
      return [];
   else if (typeof(separators) != "string")
      separators = "";
   switch (typeof(txt)) {
      case 'function':
         txt = txt.toString();
         var i = txt.indexOf('{');
         txt = txt.substring(0, i).trim();
      case 'string':
         break;
      default:
         txt = JSON.stringify(txt);
   }
   
   var words = [];
   var start = -1;
   var quote = null;
   for (var i = 0; i < txt.length; i++) {
      var c = txt.charAt(i);
      if (quote != null) {
         if (quote == c) {
            words.push(txt.substring(start, i+1));
            start = -1;
            quote = null;
         }
      }
      else if (separators.indexOf(c) >= 0) {
         if (start >= 0) {
            words.push(txt.substring(start, i));
            start = -1;
         }
         switch (c) {
            case '"':
            case "'":
            case "`":
               quote = c;
               start = i;
               break;
            default:
               words.push(c);
         }
      }
      else if (isBlank(c)) {
         if (start >= 0) {
            words.push(txt.substring(start, i));
            start = -1;
         }
      }
      else if (start < 0)
         start = i;
   }
   if (start >= 0)
      words.push(txt.substring(start));
   return words;
}

// try to convert strings to number, boolean or date
function normalize(src) {
   if (src == null)
      return src;
   switch (typeof(src)) {
      default:
         return src;
      case 'object':
         for (var i in src)
            src[i] = normalize(src[i]);
         return src;
      case 'string':
         if (src.trim() == "")
            return src;
         else if (!isNaN(src))
            return parseFloat(src);
         else {
            var date = new Date(src);
            return isNaN(date) ? src : date;
         }
   }
}

// render an object to an editable string
function editable(src)  {
   if (src == null)
      return "";
   else if (typeof(src) != "object")
      return src.toString();
   switch (type(src)) {
      case 'date':
         return src.toISOString();
      case 'array':
         return src.toString();
      case 'object':
         return JSON.stringify(src);
      case 'buffer':
         var txt = "";
         for (var i = 0; i < src.length; i++)
            txt += (src[i]+0x100).toString(16).substring(1);
         return txt;
      default:
         return src.toString();
   }
}

function crypt(secret, salt) {
   if (typeof(crypto) == "undefined") {
      if (typeof(require) == "function")
         crypto = require("crypto");
      else {
         crypto = {
            secret: "",
            createHmac: function() {
               return this;
            },
            update: function(secret) {
               this.secret = secret;
               return this;
            },
            digest: function() {
               if (this.secret == null || this.secret == "")
                  return "";
               else if (typeof(this.secret) != "string")
                  this.secret = this.secret.toString();
               var code = "";
               for (var i = 0; i < this.secret.length; i++)
                  code += (this.secret.charCodeAt(i)+0x10000).toString(16).substring(1);
               return code;
            }
         };
      }
   }
   return crypto.createHmac('sha256', salt).update(secret).digest('hex');
}

function type(data) {
   if (data == null)
      return "null";
   var t = typeof(data);
   return (t == "object") ? data.constructor.name.toLowerCase() : t;
}

function empty(obj) {
   switch (type(obj)) {
      case 'null':
         return true;
      case 'regexp':
         obj = obj.toString();
      case 'string':
         return obj.trim() == "";
      case 'number':
         return obj == 0 || isNaN(obj);
      case 'boolean':
         return obj == false;
      case 'function':
         var txt = obj.toString();
         var start = txt.indexOf('{');
         var end = txt.lastIndexOf('}');
         txt = txt.substring(start+1, end).trim();
         return txt == "";
      case 'array':
         return obj.length == 0;
      case 'date':
         return isNaN(obj);
      default:
         for (var i in obj)
            return false;
         return true;
   }
}

function object(data, valueProperty) {
   switch (type(data)) {
      case 'null':
         return {};
      case 'number':
      case 'boolean':
      case 'string':
      case 'function':
      case 'regexp':
         var obj = {}
         obj[valueProperty||"value"] = data;
         return obj;
      case 'array':
         var obj = {};
         for (var i = 0; i < data.length; i++) {
            sub = object(data[i], valueProperty);
            for (var i in sub)
               obj[i] = sub[i];
         }
         return obj;
      case 'date':
         return {
            year: value.getFullYear(),
            month: value.getMonth()+1,
            date: value.getDate(),
            day: value.getDay(),
            hour: value.getHours(),
            minute: value.getMinutes(),
            second: value.getSeconds(),
            millisecond: value.getMilliseconds()
        };
      case 'object':
         return data;
      default:
         var obj = {};
         var nf = 0;
         for (var i in data) {
            obj[i] = data[i];
            nf++;
         }
         if (nf == 0) {
            obj.type = data.constructor.name;
            obj[valueProperty||"value"] = data.toString();
         }
         return obj;
   }
}

function array(value, fieldProperty) {
   if (value == null)
      return [];
   switch (type(value)) {
      case 'string':
         return value.split(",");
      case 'number':
      case 'boolean':
      case 'function':
      case 'regexp':
         return [value];
      case 'array':
         return value;
      case 'date':
         return [value.getFullYear(), value.getMonth()+1, value.getDate(),
                 value.getHours(), value.getMinutes(), value.getSeconds(), value.getMilliseconds()];
      default:
         var a = [];
         for (var f in value) {
            if (fieldProperty) {
               var obj = object(value[f]);
               obj[fieldProperty] = f;
               a.push(obj);
            }
            else
               a.push({f:value[f]});
         }
         return a;
   }
}

function date(value) {
   switch (type(value)) {
      case 'null':
         return null;
      case 'number':
         return new Date(value);
      case 'regexp':
         value = value.toString();
      case 'string':
         var dt = isNaN(value) ? new Date(value) : new Date(parseFloat(value));
         return isNaN(dt) ? null : dt;
      case 'boolean':
      case 'function':
         return null;
      case 'date':
         return value;
      case 'array':
         try { return eval("new Date("+value.join(",")+")"); }
         catch (e) { return null; }
      default:
         var dt = new Date();
         var properties = 0;
         for (var f in value) {
            try {
               var n = parseInt(value[f]);
               if (!isNaN(n)) {
                  dt["set"+f.charAt(0).toUpperCase()+f.substring(1)](n);
                  properties++;
               }
            }
            catch (e) {}
         }
         return properties ? dt : null;
   }
}

function color(value) {
   if (value == null)
      return 0;
   switch (typeof(value)) {
      case 'boolean':
         value = value ? "#ffffff" : "#000000";
      case 'string':
         value = value.trim();
         if (value == "")
            value = "#000000";
         else if (value.charAt(0) == '#') {
            var txt = value.substring(1);
            switch (value.length) {
               case 0:
                  txt = "000000";
                  break;
               case 1:
                  break;
               case 2:
                  txt += txt+txt;
                  break;
               case 4:
                  txt.substring(0,3);
               case 3:
                  break;
               case 5:
                  txt += "0";
               case 6:
                  break;
               default:
                  txt = txt.substring(0,6);
            }
            value = "#"+txt;
         }
         else if (value.substring(0,4) == "rgb(")
            return color(value.substring(4).split(","));
         else
            value = htmlcolors[value.toLowerCase()];
         return parseInt(value.substring(1), 16) || 0;
      case 'number':
         if (value > 0xffffff || value < 0)
            value = value & 0xffffff;
         return "#"+(value + 0x1000000).toString(16).substring(1);
      case 'function':
         return color(value());
      case 'object':
         var parts = [0, 0, 0];
         if (value instanceof Array) {
            for (var i = 0; i < 3; i++)
               parts[i] = parseInt(value[i]) || 0;
         }
         else {
            for (var f in value) {
               switch (f.toLowerCase()) {
                  case 'r':
                  case 'red':
                     parts[0] = parseInt(value[f]) || 0;
                     break;
                  case 'g':
                  case 'green':
                     parts[0] = parseInt(value[f]) || 0;
                     break;
                  case 'b':
                  case 'blue':
                     parts[0] = parseInt(value[f]) || 0;
                     break;
               }
            }
         }
         return ((parts[0] & 0xff) << 16) + ((parts[1] & 0xff) << 8) + (parts[2] & 0xff);
   }
}

function html(data,target) {
   var result = "";
   if (data != null) {
      switch (type(data)) {
         case 'regexp':
            data = data.toString();
         case 'string':
            if (data.charAt(0) == '&' && data.charAt(data.length-1) == ';')
               result = data;
            else {
               for (var e in htmlescapes) {
                  if (data.indexOf(e) >= 0)
                     data = data.split(e).join(htmlescapes[e]);
               }
               result = data;
            }
            break;
         case 'boolean':
         case 'number':
            result = data.toString();
            break;
         case 'function':
            result = html(data());
            break;
         case 'array':
            for (var i = 0; i < data.length; i++)
               result += html(data[i]);
            break;
         default:
            var tag = "div";
            var children = null;
            var htmldata = null;
            for (var i in data) {
               switch (i) {
                  case 'tag':
                     tag = data[i];
                     break;
                  case 'children':
                     children = data[i];
                     break;
                  case 'html':
                     htmldata = data[i];
                     break;
                  case 'style':
                     result += " "+i+"='"+css(data[i])+"'";
                     break;
                  case 'class':
                     var value = data[i];
                     if (value == null)
                        value = "";
                     else if (value instanceof Array)
                        value = value.join(" ");
                     else if (typeof(value) == "object") {
                        var a = [];
                        for (var i in value)
                           a.push(value[i]);
                        value = a.join(" ");
                     }
                     result += " class='"+html(value)+"'";
                     break;
                  default:
                     var value = data[i];
                     if (value == null)
                        value = '""';
                     else if (i.substring(0,11) == "javascript:") {
                        var quote = value.indexOf('"');
                        var apos = value.indexOf("'");
                        if (apos >= 0)
                           value =  (quote >= 0) ? JSON.stringify(value) : '"'+value+'"';
                        else
                           value = "'"+value+"'";
                     }
                     else if (i.substring(0,2) == "on")
                        value = JSON.stringify(value);
                     else
                        value = "'"+html(value)+"'";
                     result += " "+i+"="+value;
               }
            }
            result = "<"+tag+result;
            if (children == null && htmldata == null)
               result += "/>";
            else {
               result += ">";
               if (children != null)
                  result += html(children);
               if (htmldata != null)
                  result += htmldata;
               result += "</"+tag+">";
            }
       }
   }

   if (target != null) {
      if (typeof(target) == "string") {
         var id = target
         target = document.getElementById(id);
         if (target == null)
            alert("Cannot find element "+id);
      }
      if (target.hasAttribute("value"))
         target.value = result;
      else
         target.innerHTML = result;
   }
   return result;
}

function css(data) {
   switch (type(data)) {
      case 'regexp':
         data = data.toString();
      case 'string':
         var txt = data.trim();
         if (txt.charAt(txt.length-1) != ';')
            txt += ';';
         return txt;
      case 'boolean':
      case 'number':
      case 'null':
         return "";
      case 'function':
         return css(data());
      case 'array':
         var txt = "";
         for (var i = 0; i < data.length; i++)
            txt += css(data[i]);
         return txt;
      default:
         var txt = "";
         for (var i in data)
            txt += i+":"+data[i]+";";
         return txt;
   }
}

function operator(op) {
   if (typeof(op) != "string")
      return null;
   if (operatorlabels == null) {
      operatorlabels = {};
      for (var i in operatordefinitions) {
         var opdef = operatordefinitions[i];
         for (var f in opdef) {
            var d = opdef[f];
            if (typeof(d) == "string")
               operatorlabels[d] = opdef;
         }
      }
   }
   return operatorlabels[op];
}

function have(a,b) {
   switch (type(b)) {
      case 'null':
         return false;
      case 'regexp':
         return (a != null && a.toString().match(b)) || false;
      case 'string':
      case 'number':
      case 'boolean':
         if (a == null)
            return false;
         else if (typeof(a) != "string")
            a = a.toString();
         if (a == "")
            return false;
         return b.toString().indexOf(a) >= 0;
      case 'function':
         return have(a, b());
      case 'array':
         for (var i in b) {
            if (a == b[i])
               return true;
         }
      default:
         for (var i in b) {
            if (a == i)
               return true;
            var v = b[i];
            if (a == v)
               return true;
            else if (have(a, v))
               return true;
         }
   }
   return false;
}

function havenot(a,b) {
   return !have(a,b);
}

function not(a,b) {
   return !a && !b;
}

function join(a,b) {
   var dst = [];
   a = array(a);
   for (var i in a)
      dst.push(a[i]);
   b = array(b);
   for (var i in b)
      dst.push(b[i]);
   return dst;
}

function validDate(value) {
   if (value instanceof Date)
      return true;
   else if (value == null)
      return false;
   var parts = value.toString().trim().toLowerCase().split('-');
   if (parts.length != 3)
      return false;
   var time = null;
   for (var s in datetimeseparators) {
      var i = parts[2].indexOf(datetimeseparators[s]);
      if (i >= 0) {
         time = parts[2].substring(i+1).trim().split(':');
         parts[2] = parts[2].substring(0, i);
         break;
      }
   }
   for (var i in parts) {
      var part = parts[i].trim();
      if (part == '' || isNaN(part))
         return false;
   }
   if (time != null) {
      if (time.length > 3)
         return false;
      for (var i in time) {
         var t = time[i].trim();
         if (t == '' || isNaN(t))
            return false;
      }
   }
   return true;
}

function isBlank(c) {
   switch (typeof(c)) {
      case 'string':
         c = c.charCodeAt(0);
      case 'number':
      case 'boolean':
         return c <= 32 || (c >= 127 && c <= 0xa0);
      default:
         return c == null;
   }
}

lib = {
   css: css,
   html: html,
   color: color,
   operator: operator,
   date: date,
   array: array,
   object: object,
   empty: empty,
   type: type,
   alert: alert,
   validDate: validDate,
   extractFields: extractFields,
   addFields: addFields,
   deepClone: deepClone,
   parseWords: parseWords,
   normalize: normalize,
   editable: editable,
   crypt: crypt,
   have: have,
   join: join
};
if (typeof(module) == "object" && module != null)
   module.exports = lib;




