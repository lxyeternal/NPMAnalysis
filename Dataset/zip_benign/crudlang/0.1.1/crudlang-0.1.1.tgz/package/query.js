#!/usr/local/bin/node

args = process.argv.slice(2);
if (args.length < 1) {
   console.log("Syntax: query.js <dburl> [query]");
   process.exit(1);
}
var mysql = require('mysql');
var mongo = require('mongodb').MongoClient;
var urlparser = require('url');
eval(require('fs').readFileSync("lib.js", {encoding:'utf8'}));

var dburl = args[0];
var query = args[1];
var urlparts = urlparser.parse(dburl);
var protocol = urlparts.protocol.replace(':','');
if (protocol == "mysql") {
   var dbname = urlparts.pathname ? urlparts.pathname.split('/')[1] : "";
   var infos = {
     host     : urlparts.hostname || 'localhost',
     user     : urlparts.auth ? urlparts.auth.split(':')[0] : "root",
     password : urlparts.auth ? (urlparts.auth.split(':')[1]||"") : "",
     database : dbname || "mysql"
   };
   if (urlparts.port)
      infos.port = urlparts.port;

   var connection = mysql.createConnection(infos);
   connection.connect(function(err,callback){
      if (err) return console.log(err);
      if (query)
         connection.query(query, sqlQueryResults);
      else if (dbname)
         connection.query("show tables", sqlTablesCount);
      else
         connection.query("show databases", sqlDatabaseList);
   });
}
else if (protocol == "mongodb") {
   mongo.connect(dburl, function(err, db) {
      if (err) 
         return console.log(err);
      else if (urlparts.auth) {
         var auth = urlparts.auth.split(":");
         db.admin().authenticate(auth[0], auth[1], function(err, result) {
            if (err) {
               console.log(err);
               db.close();
            }
            else
               mongoQuery(query, db);
         });
      }
      else
         mongoQuery(query, db);
   });
}
else {
   console.log(protocol+" database type not supported");
   process.exit(1);
}

function sqlTablesCount(err, tables, fields) {
   if (err) return console.log(err);
   var tableField = fields[0].name;
   for (var t in tables) {
      var table = tables[t][tableField];
      connection.query("select count(*) as "+table+" from "+table, function(err, rows, fields) {
         var field = fields[0].name;
         if (err) return console.log("Error counting "+field+" rows: "+err);
         console.log(field+" has "+rows[0][field]+" records");
      });
   }
   connection.end();
}

function sqlDatabaseList(err, rows, fields) {
   if (err) return console.log(err);
   if (rows.length == 0)
      console.log("No database found");
   else
      for (var i in rows)
         console.log(rows[i].Database);
   connection.end();
}

function sqlQueryResults(err, rows, fields) {
   if (err) return console.log(err);
   console.log(JSON.print(rows));
   connection.end();
}

function mongoQuery(query, db) {
   if (query) {
      var p = query.indexOf('{');
      if (p < 0)
         var q = {};
      else {
         var q = eval("("+query.substring(p)+")");
         query = query.substring(0,p).trim();
      }
      db.collection(query).find(normalize(q)).toArray(function(err, docs) {
         if (err) return console.log(err);
         console.log(JSON.print(docs));
         db.close();
      });
   }
   else if (urlparts.pathname == null || urlparts.pathname == "/") {
      db.admin().listDatabases(function(err, dbs) {
         if (err) return console.log(err);
         if (dbs.databases.length == 0)
            console.log("No database found on this server");
         else {
            for (var i in dbs.databases) {
               var d = dbs.databases[i];
               console.log(d.name+" is "+d.sizeOnDisk+" octects");
            }
         }
         db.close();
      });
   }
   else {
      db.collections(function(err, colls) {
         if (err) return console.log(err);
         if (colls.length == 0)
            return db.close();
         var counter = {count:colls.length, got:0};
         for (var c in colls)
            mongoCollectionCount(db, colls[c], counter);
      });
   }
}

function mongoCollectionCount(db, col, counter) {
   col.count(function(err, n) {
      if (err) return console.log(err);
      console.log(col.collectionName+" has "+n+" documents");
      counter.got++;
      if (counter.got >= counter.count)
         db.close();
   });
}

