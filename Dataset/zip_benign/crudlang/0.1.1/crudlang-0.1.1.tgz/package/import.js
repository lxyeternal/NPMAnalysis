#!/usr/local/bin/node

// check the command line args
args = process.argv.slice(2);
if (args.length < 2) {
   console.log("Syntax: import.js <mysql connection> <mongodb connection>");
   process.exit(1);
}

// initialize the required modules and variables
var mysql = require('mysql');
var mongo = require('mongodb').MongoClient;
var urlparser = require('url');
var basicFields = "name,type,length,flags,decimals".split(",");
eval(require('fs').readFileSync("lib.js", {encoding:'utf8'}));

//get mysql connection
var urlparts = urlparser.parse(args[0]);
var protocol = urlparts.protocol.replace(':','');
if (protocol == "mysql") {
   var infos = {
     host     : urlparts.hostname || 'localhost',
     user     : urlparts.auth ? urlparts.auth.split(':')[0] : "root",
     password : urlparts.auth ? (urlparts.auth.split(':')[1]||"") : "",
     database : urlparts.pathname.split('/')[1]
   };
   if (urlparts.port)
      infos.port = urlparts.port;
   var src = mysql.createConnection(infos);
}
else {
   console.log(protocol+" database type not supported");
   process.exit(1);
}

// get mongodb connection
mongo.connect(args[1], function(err, db) {
   if (err) return console.log(err);
   startImporting(db);
});

// function to start the import process
function startImporting(db) {
   src.connect(function(err,callback){
      if (err) return console.log(err);
      src.query("show tables", function(err, tables, fields) {
         if (err) return console.log(err);
         if (tables.length == 0)
            return db.close();
         var counter = {count:tables.length, got:0};
         var tableField = fields[0].name;
         for (var t in tables)   
            importTable(tables[t][tableField], db, counter);
         src.end();
      });
   });
}

// function to import a single table
function importTable(table, db, counter) {
   src.query("select * from "+table, function(err, rows, fields) {
      if (err) return console.log("Error querying "+table+": "+err);
      console.log(table+" has "+rows.length+" records");
      for (var f in fields) {
         var field = fields[f];
         console.log("  "+JSON.print(extractFields(field, basicFields)));
         if (field.name == "id") {
            for (var r in rows) {
               var row = rows[r];
               row._id = row.id;
               delete row.id;
            }
         }
         else if (field.type == 10 || field.type == 12) {
            for (var r in rows) {
               var row = rows[r];
               row[field.name] = new Date(row[field.name]);
            }
         }
      }
      var col = db.collection(table);
      col.drop();
      if (rows.length == 0)
         return checkCounter(counter, db);
      while (rows.length > 1000)
         insertRows(table, rows.splice(0, 1000), db, col);
      insertRows(table, rows, db, col, counter);
   });
}

function insertRows(table, rows, db, col, counter) {
   col.insert(rows, function(err) {
      if (err) return console.log("Error importing "+table+": "+err);
      checkCounter(counter, db);
   });
}

function checkCounter(counter, db) {
   if (counter != null) {
      counter.got++;
      if (counter.got >= counter.count)
         db.close();
   }
}

/**
detected types:
-   3 row,col      = int(11)
-   5 dette,solde  = float(22)
-   8 id           = sequential(20)
-  10 date         = date(10)
-  12 *date*       = datetime(19)
- 252 value        = text(196605)
- 253 text         = varchar(*)
- 254 categorie    = char(*)



**/


