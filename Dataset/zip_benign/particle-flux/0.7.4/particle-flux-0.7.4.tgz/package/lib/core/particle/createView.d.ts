import { ViewFactory, ViewParticle } from '../../types';
export declare function createView<View extends ViewParticle>(viewFactory: ViewFactory<View>): View;
//# sourceMappingURL=createView.d.ts.map