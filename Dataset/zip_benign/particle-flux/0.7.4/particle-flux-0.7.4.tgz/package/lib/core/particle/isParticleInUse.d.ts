import { ViewParticle, IParticle } from '../../types';
export declare function isParticleInUse<View extends ViewParticle>(particle: IParticle<View>): boolean;
//# sourceMappingURL=isParticleInUse.d.ts.map