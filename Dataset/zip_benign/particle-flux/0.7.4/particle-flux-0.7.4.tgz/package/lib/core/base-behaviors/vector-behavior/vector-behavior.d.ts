import { VectorBehaviorConfig, VectorBehavior } from './vector-behavior.types';
import { Point2d } from '../../../types';
export declare function getVectorBehavior(config: VectorBehaviorConfig): VectorBehavior;
export declare function getVectorBehaviorValue(behavior: VectorBehavior, lifeTimeNormalizedProgress: number): Point2d;
//# sourceMappingURL=vector-behavior.d.ts.map