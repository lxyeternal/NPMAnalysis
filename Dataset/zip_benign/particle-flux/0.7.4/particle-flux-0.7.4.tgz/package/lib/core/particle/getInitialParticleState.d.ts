import { ViewParticle, IParticle } from '../../types';
export declare function getInitialParticleState<View extends ViewParticle>(): Omit<IParticle<View>, 'view'>;
//# sourceMappingURL=getInitialParticleState.d.ts.map