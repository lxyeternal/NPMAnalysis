import { IParticle, ParticleEmitterConfig, ViewContainer, ViewFactory, ViewParticle } from '../types';
import { ConfigManager } from './ConfigManager';
interface UpdateReport {
    currentTime: number;
    prevSpawnTime: number;
    particleCreatedCount: number;
    deltaBetweenCurrentTimeAndCurrentSpawnTime: number;
}
export declare class ParticleEmitter<View extends ViewParticle = ViewParticle> {
    readonly config: ConfigManager<View>;
    private currentTime;
    private currentSpawnInterval;
    private prevSpawnTime;
    private readonly container;
    private readonly ticker;
    private skipFirstEmit;
    constructor(viewContainer: ViewContainer<View>, viewFactory: ViewFactory<View>, initialConfig: ParticleEmitterConfig);
    emitOnce(particlesCount?: number): void;
    emitWave(): IParticle<View>[];
    startEmit(): void;
    pauseEmit(): void;
    resumeEmit(): void;
    stopEmit(): void;
    restart(): void;
    clean(): void;
    destroy(): void;
    isEmitActive(): boolean;
    update(elapsedDelta: number, deltaMS: number): UpdateReport;
    updateContainer(elapsedDelta: number, deltaMS: number): void;
    getParticlesCount(): number;
    getParticles(): IParticle<View>[];
    fillPool(particlesCount: number): void;
    clearPool(): void;
    private handleUpdate;
    private createParticlesBetweenFrames;
    private emit;
    private getNextSpawnTime;
    private resetTime;
    private getAvailableForEmitParticlesCount;
    private getSpawnTime;
}
export {};
//# sourceMappingURL=ParticleEmitter.d.ts.map