import { AnyBaseBehaviorConfig } from '../base-behaviors.types';
import { VectorBehaviorConfig } from './vector-behavior.types';
export declare function isVectorBehaviorConfig(config: AnyBaseBehaviorConfig): config is VectorBehaviorConfig;
//# sourceMappingURL=vector-behavior.typeguards.d.ts.map