import { SpawnShapeBehavior } from './spawn-shapes.types';
import { Point2d } from '../../types';
export declare function getSpawnPosition(spawnShape: SpawnShapeBehavior, relativePoint?: Point2d): Point2d;
//# sourceMappingURL=getSpawnPosition.d.ts.map