import { SpawnTorusShape } from '../spawn-shapes.types';
import { Point2d } from '../../../types';
export declare function getSpawnPositionOfTorus(config: SpawnTorusShape): Point2d;
//# sourceMappingURL=torus-shape.d.ts.map