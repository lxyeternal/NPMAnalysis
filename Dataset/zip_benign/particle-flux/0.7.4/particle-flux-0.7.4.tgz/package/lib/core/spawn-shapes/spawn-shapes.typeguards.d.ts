import { PolygonalChain, Chain, SpawnShapeBehavior, SpawnRectangleShape, SpawnPointShape, SpawnTorusShape, PolygonalChainShape } from './spawn-shapes.types';
export declare function isSinglePolygonalChain(chain: PolygonalChain): chain is Chain;
export declare function isSpawnPointShape(shape: SpawnShapeBehavior): shape is SpawnPointShape;
export declare function isSpawnRectangleShape(shape: SpawnShapeBehavior): shape is SpawnRectangleShape;
export declare function isTorusShape(shape: SpawnShapeBehavior): shape is SpawnTorusShape;
export declare function isPolygonalShape(shape: SpawnShapeBehavior): shape is PolygonalChainShape;
//# sourceMappingURL=spawn-shapes.typeguards.d.ts.map