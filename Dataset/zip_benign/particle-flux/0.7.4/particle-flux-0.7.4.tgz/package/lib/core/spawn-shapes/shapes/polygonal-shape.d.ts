import { PolygonalChainShape } from '../spawn-shapes.types';
import { Point2d } from '../../../types';
export declare function getSpawnPositionOfPolygonalShape(config: PolygonalChainShape): Point2d;
//# sourceMappingURL=polygonal-shape.d.ts.map