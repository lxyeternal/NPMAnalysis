import { AnyBaseBehaviorConfig } from '../base-behaviors.types';
import { ScalarBehaviorConfig, ScalarDynamicBehaviorConfig, ScalarStaticBehaviorConfig } from './scalar-behavior.types';
export declare function isScalarDynamicBehavior(config: AnyBaseBehaviorConfig): config is ScalarDynamicBehaviorConfig;
export declare function isScalarStaticBehavior(config: AnyBaseBehaviorConfig): config is ScalarStaticBehaviorConfig;
export declare function isScalarBehaviorConfig(config: AnyBaseBehaviorConfig): config is ScalarBehaviorConfig;
//# sourceMappingURL=scalar-behavior.typeguards.d.ts.map