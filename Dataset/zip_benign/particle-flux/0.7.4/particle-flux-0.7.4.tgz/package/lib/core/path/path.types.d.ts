export interface PathConfig {
    path: string;
}
export type PathFunction = (x: number) => number;
//# sourceMappingURL=path.types.d.ts.map