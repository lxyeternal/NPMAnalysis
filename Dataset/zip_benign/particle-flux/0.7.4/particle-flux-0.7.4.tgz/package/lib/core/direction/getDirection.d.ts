import { DirectionConfig } from './direction.types';
import { Point2d } from '../../types';
export declare function getDirection(config: DirectionConfig): {
    vector: Point2d;
    angle: number;
};
//# sourceMappingURL=getDirection.d.ts.map