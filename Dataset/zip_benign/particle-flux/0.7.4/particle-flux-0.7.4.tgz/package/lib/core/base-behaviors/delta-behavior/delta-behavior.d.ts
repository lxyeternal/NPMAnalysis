import { DeltaBehaviorConfig, DeltaBehavior } from './delta-behavior.types';
export declare function getDeltaBehavior(config: DeltaBehaviorConfig): DeltaBehavior;
export declare function getDeltaBehaviorValue(behavior: DeltaBehavior, elapsedDelta: number): number;
//# sourceMappingURL=delta-behavior.d.ts.map