import { ViewParticle, IParticle, ParticleConfig } from '../../types';
export declare function useParticle<View extends ViewParticle>(particle: IParticle<View>, config: ParticleConfig): void;
//# sourceMappingURL=useParticle.d.ts.map