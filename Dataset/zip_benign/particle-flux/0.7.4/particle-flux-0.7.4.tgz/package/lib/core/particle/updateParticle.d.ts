import { ViewParticle, IParticle } from '../../types';
export declare function updateParticle<View extends ViewParticle>(particle: IParticle<View>, elapsedDelta: number, deltaMS: number): void;
//# sourceMappingURL=updateParticle.d.ts.map