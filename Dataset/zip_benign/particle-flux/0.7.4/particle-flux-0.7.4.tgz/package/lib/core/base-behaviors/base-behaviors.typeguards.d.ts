import { AnyBaseBehavior } from './base-behaviors.types';
import { DeltaBehavior } from './delta-behavior/delta-behavior.types';
import { ScalarBehavior } from './scalar-behavior/scalar-behavior.types';
import { ScriptBehavior } from './script-behavior/script-behavior.types';
import { VectorBehavior } from './vector-behavior/vector-behavior.types';
export declare function isScalarBehavior(behavior: AnyBaseBehavior): behavior is ScalarBehavior;
export declare function isVectorBehavior(behavior: AnyBaseBehavior): behavior is VectorBehavior;
export declare function isScriptBehavior<T>(behavior: AnyBaseBehavior): behavior is ScriptBehavior<T>;
export declare function isDeltaBehavior(behavior: AnyBaseBehavior): behavior is DeltaBehavior;
//# sourceMappingURL=base-behaviors.typeguards.d.ts.map