import { ScalarBehavior, ScalarDynamicBehaviorConfig, ScalarStaticBehaviorConfig } from './scalar-behavior.types';
export declare function getScalarBehavior(config: ScalarDynamicBehaviorConfig): ScalarBehavior;
export declare function getStaticBehaviorValue(config: ScalarStaticBehaviorConfig): number;
export declare function getScalarBehaviorValue(behavior: ScalarBehavior, lifeTimeNormalizedProgress: number): number;
//# sourceMappingURL=scalar-behavior.d.ts.map