import { ViewParticle, ViewContainer, IParticle } from '../../types';
export declare function createUnusedParticle<View extends ViewParticle>(viewContainer: ViewContainer<View>, view: View): IParticle<View>;
//# sourceMappingURL=createUnusedParticle.d.ts.map