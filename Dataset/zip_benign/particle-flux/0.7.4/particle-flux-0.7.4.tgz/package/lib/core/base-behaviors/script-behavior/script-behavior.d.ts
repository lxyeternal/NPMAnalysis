import { ScriptBehaviorConfig, ScriptBehavior } from './script-behavior.types';
export declare function getScriptBehavior<V>(config: ScriptBehaviorConfig<V>): ScriptBehavior<V>;
export declare function getScriptBehaviorValue<V>(behavior: ScriptBehavior<V>, lifeTimeNormalizedProgress: number): V;
//# sourceMappingURL=script-behavior.d.ts.map