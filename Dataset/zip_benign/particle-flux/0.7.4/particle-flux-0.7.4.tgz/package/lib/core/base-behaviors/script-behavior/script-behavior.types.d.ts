import { BaseBehaviorType } from '../base-behaviors.types';
export type TimeScriptConfig<V> = {
    time: number;
    value: V;
}[];
export interface ScriptBehaviorConfig<V> {
    script: TimeScriptConfig<V>;
}
export interface ScriptBehavior<V> {
    script: TimeScriptConfig<V>;
    lastValueIndex: number;
    type: BaseBehaviorType.Script;
}
//# sourceMappingURL=script-behavior.types.d.ts.map