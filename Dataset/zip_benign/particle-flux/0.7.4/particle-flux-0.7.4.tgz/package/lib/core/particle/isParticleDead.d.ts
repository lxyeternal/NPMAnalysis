import { ViewParticle, IParticle } from '../../types';
export declare function isParticleDead<View extends ViewParticle>(particle: IParticle<View>): boolean;
//# sourceMappingURL=isParticleDead.d.ts.map