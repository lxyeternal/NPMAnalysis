import { DirectionConfig, DirectionRangeConfig, StaticDirectionConfig } from './direction.types';
export declare function isStaticDirectionBehaviorConfig(config: DirectionConfig): config is StaticDirectionConfig;
export declare function isDirectionRangeBehaviorConfig(config: DirectionConfig): config is DirectionRangeConfig;
//# sourceMappingURL=direction.typeguards.d.ts.map