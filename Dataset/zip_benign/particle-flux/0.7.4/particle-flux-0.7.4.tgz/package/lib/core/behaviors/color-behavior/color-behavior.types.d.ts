import { ScriptBehaviorConfig, ScriptBehavior } from '../../base-behaviors/script-behavior/script-behavior.types';
import { EasingFunction, EasingName } from '../../../utils/easing/easing.types';
export interface ColorDynamicBehaviorConfig {
    start: string;
    end: string;
    easing?: EasingName;
}
export interface ColorStaticBehaviorConfig {
    value: string;
}
export type ColorBehaviorConfig = ColorStaticBehaviorConfig | ColorDynamicBehaviorConfig | ScriptBehaviorConfig<string>;
export interface ColorDynamicBehavior {
    startColor: string;
    endColor: string;
    easing: EasingFunction | null;
    type: ColorBehaviorType.Dynamic;
}
export declare enum ColorBehaviorType {
    Dynamic = "Dynamic"
}
export type AnyColorBehavior = ColorDynamicBehavior | ScriptBehavior<string>;
//# sourceMappingURL=color-behavior.types.d.ts.map