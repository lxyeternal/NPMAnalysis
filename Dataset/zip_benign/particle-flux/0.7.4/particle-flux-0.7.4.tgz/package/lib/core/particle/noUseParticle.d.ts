import { ViewParticle, IParticle } from '../../types';
export declare function noUseParticle<View extends ViewParticle>(particle: IParticle<View>): void;
//# sourceMappingURL=noUseParticle.d.ts.map