import { LifeTimeBehaviorConfig, LifeTimeStaticBehaviorConfig, LifeTimeRangeBehaviorConfig } from './life-time-behavior.types';
export declare function isLifeTimeStaticBehaviorConfig(config: LifeTimeBehaviorConfig): config is LifeTimeStaticBehaviorConfig;
export declare function isLifeTimeRangeBehaviorConfig(config: LifeTimeBehaviorConfig): config is LifeTimeRangeBehaviorConfig;
//# sourceMappingURL=life-time-behavior.typeguards.d.ts.map