import { LifeTimeBehaviorConfig } from './life-time-behavior.types';
export declare const getLifeTimeNormalizedProgress: (age: number, lifeTime: number) => number;
export declare function getLifeTimeBehavior(config: LifeTimeBehaviorConfig): number;
//# sourceMappingURL=life-time-behavior.d.ts.map