export interface SpawnPositionConfig {
    x: number;
    y: number;
}
//# sourceMappingURL=spawn-position.types.d.ts.map