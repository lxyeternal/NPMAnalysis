import { ColorDynamicBehaviorConfig, ColorDynamicBehavior, ColorStaticBehaviorConfig } from './color-behavior.types';
export declare function getColorDynamicBehavior(config: ColorDynamicBehaviorConfig): ColorDynamicBehavior;
export declare function getColorStaticBehaviorValue(config: ColorStaticBehaviorConfig): string;
export declare function getColorDynamicBehaviorValue(behavior: ColorDynamicBehavior, lifeTimeNormalizedProgress: number): string;
//# sourceMappingURL=color-dynamic-behavior.d.ts.map