import { AnyBaseBehaviorConfig } from '../base-behaviors.types';
import { DeltaBehaviorConfig } from './delta-behavior.types';
export declare function isDeltaBehaviorConfig(config: AnyBaseBehaviorConfig): config is DeltaBehaviorConfig;
//# sourceMappingURL=delta-behavior.typeguards.d.ts.map