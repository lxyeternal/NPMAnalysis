import { ScriptBehaviorConfig } from '../../base-behaviors/script-behavior/script-behavior.types';
import { AnyColorBehavior, ColorBehaviorConfig, ColorDynamicBehavior, ColorDynamicBehaviorConfig, ColorStaticBehaviorConfig } from './color-behavior.types';
export declare function isColorStaticBehaviorConfig(config: ColorBehaviorConfig): config is ColorStaticBehaviorConfig;
export declare function isColorDynamicBehaviorConfig(config: ColorBehaviorConfig): config is ColorDynamicBehaviorConfig;
export declare function isColorScriptBehaviorConfig(config: ColorBehaviorConfig): config is ScriptBehaviorConfig<string>;
export declare function isColorDynamicBehavior(behavior: AnyColorBehavior): behavior is ColorDynamicBehavior;
//# sourceMappingURL=color-behavior.typeguards.d.ts.map