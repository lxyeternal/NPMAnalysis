import { ViewParticle, IParticle } from '../../types';
export declare function wasParticleRemoved<View extends ViewParticle>(particle: IParticle<View>): boolean;
//# sourceMappingURL=wasParticleRemoved.d.ts.map