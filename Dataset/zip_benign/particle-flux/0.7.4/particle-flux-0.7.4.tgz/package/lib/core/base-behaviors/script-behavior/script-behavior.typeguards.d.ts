import { AnyBaseBehaviorConfig } from '../base-behaviors.types';
import { ScriptBehaviorConfig } from './script-behavior.types';
export declare function isScriptBehaviorConfig<T>(config: AnyBaseBehaviorConfig): config is ScriptBehaviorConfig<T>;
//# sourceMappingURL=script-behavior.typeguards.d.ts.map