import { ViewParticle, ViewContainer, IParticle } from '../../types';
export declare function removeParticle<View extends ViewParticle>(viewContainer: ViewContainer<View>, particle: IParticle<View>): void;
//# sourceMappingURL=removeParticle.d.ts.map