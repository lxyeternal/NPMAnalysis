import { SpawnRectangleShape } from '../spawn-shapes.types';
import { Point2d } from '../../../types';
export declare function getSpawnPositionOfRectangle(config: SpawnRectangleShape): Point2d;
//# sourceMappingURL=rectangle-shape.d.ts.map