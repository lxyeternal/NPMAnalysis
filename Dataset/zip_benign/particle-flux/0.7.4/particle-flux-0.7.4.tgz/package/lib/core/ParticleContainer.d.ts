import { IParticleContainer, ViewContainer, IParticle, ViewParticle } from '../types';
import { ConfigManager } from './ConfigManager';
export declare class ParticleContainer<View extends ViewParticle> implements IParticleContainer<View> {
    private readonly viewContainer;
    private readonly config;
    particleHead: IParticle<View> | null;
    availableParticleHead: IParticle<View> | null;
    private containerParticlesCount;
    constructor(viewContainer: ViewContainer<View>, config: ConfigManager<View>);
    getParticlesArray(): IParticle<View>[];
    getPoolParticlesArray(): IParticle<View>[];
    getParticlesCount(): number;
    update(elapsedDelta: number, deltaMS: number): void;
    clear(): void;
    clearViewContainer(): void;
    clearPool(): void;
    createParticle(): IParticle<View>;
    fillPool(count: number): void;
    private removeActiveParticle;
    private addParticleInUsedParticles;
    private addParticleToPool;
    private getParticleFromPool;
}
//# sourceMappingURL=ParticleContainer.d.ts.map