export declare function testParticleFluxPerformance(): () => void;
//# sourceMappingURL=test-performance.d.ts.map