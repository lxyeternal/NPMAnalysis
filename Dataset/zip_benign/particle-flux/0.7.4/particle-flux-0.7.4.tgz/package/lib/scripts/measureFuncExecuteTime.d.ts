export declare function measureFuncExecuteTime(fn: VoidFunction, runs?: number, trimPercentage?: number): {
    runs: number;
    trimmedRuns: number;
    average: number;
    median: number;
    min: number;
    max: number;
};
//# sourceMappingURL=measureFuncExecuteTime.d.ts.map