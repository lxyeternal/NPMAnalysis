import { AlphaBehaviorConfig } from './core/behaviors/alpha-behavior/alpha-behavior.types';
import { ColorBehaviorConfig, ColorDynamicBehavior } from './core/behaviors/color-behavior/color-behavior.types';
import { DirectionConfig } from './core/direction/direction.types';
import { GravityBehaviorConfig } from './core/behaviors/gravity-behavior/gravity-behavior.types';
import { LifeTimeBehaviorConfig } from './core/behaviors/life-time-behavior/life-time-behavior.types';
import { RotationBehaviorConfig } from './core/behaviors/rotation-behavior/rotation-behavior.types';
import { ScaleBehaviorConfig } from './core/behaviors/scale-behavior/scale-behavior.types';
import { SpawnShapeBehavior } from './core/spawn-shapes/spawn-shapes.types';
import { SpeedBehaviorConfig } from './core/behaviors/speed-behavior/speed-behavior.types';
import { TickerCallback } from './utils/Ticker';
import { SpawnPositionConfig } from './core/spawn-position/spawn-position.types';
import { PathConfig, PathFunction } from './core/path/path.types';
import { ScalarBehavior } from './core/base-behaviors/scalar-behavior/scalar-behavior.types';
import { ScriptBehavior } from './core/base-behaviors/script-behavior/script-behavior.types';
import { VectorBehavior } from './core/base-behaviors/vector-behavior/vector-behavior.types';
import { DeltaBehavior } from './core/base-behaviors/delta-behavior/delta-behavior.types';
export type GlobalWindow = Window & typeof globalThis;
export interface ViewParticle {
    x: number;
    y: number;
    scale: Point2d;
    alpha: number;
    tint: string | number;
    angle: number;
    destroyed: boolean;
    visible: boolean;
    width: number;
    height: number;
    [key: string | number]: any;
}
export interface ViewContainer<View extends ViewParticle> {
    addChild(child: View): void;
    removeChild(child: View): void;
}
export interface IParticleContainer<View extends ViewParticle> {
    createParticle(): void;
    getParticlesCount(): number;
    getParticlesArray(): IParticle<View>[];
    clear(): void;
    update(elapsedDelta: number, deltaMS: number): void;
}
export interface IParticle<View extends ViewParticle> {
    view: View;
    next: IParticle<View> | null;
    prev: IParticle<View> | null;
    inUse: boolean;
    age: number;
    lifeTime: number;
    speed: number;
    deltaPath: Point2d;
    initialPosition: Point2d;
    deltaDirection: Point2d;
    directionRotation: number;
    direction: Point2d;
    isFollowDirection: boolean;
    speedBehavior: ScalarBehavior | ScriptBehavior<number> | null;
    pathFunc: PathFunction | null;
    gravityBehavior: ScalarBehavior | ScriptBehavior<number> | DeltaBehavior | number;
    alphaBehavior: ScalarBehavior | ScriptBehavior<number> | null;
    rotationBehavior: ScalarBehavior | DeltaBehavior | ScriptBehavior<number> | null;
    scaleBehavior: ScalarBehavior | ScriptBehavior<Point2d> | VectorBehavior | null;
    colorBehavior: ColorDynamicBehavior | ScriptBehavior<string> | null;
}
export interface ITicker {
    FPS: number;
    deltaMS: number;
    elapsedDelta: number;
    started: boolean;
    start(): void;
    stop(): void;
    setCallback(cb: TickerCallback): void;
}
export interface Point2d {
    x: number;
    y: number;
}
export type ViewRenderFn<View extends ViewParticle> = () => View;
export type ViewFactory<View extends ViewParticle> = ViewRenderFn<View>[] | ViewRenderFn<View>;
export interface EmitterConfig {
    spawnInterval?: NumberValue;
    spawnTime?: number;
    spawnTimeout?: number;
    maxParticles?: number;
    spawnParticlesPerWave?: number;
    spawnChance?: number;
    autoStart?: boolean;
}
export interface ParticleConfig {
    lifeTime?: LifeTimeBehaviorConfig;
    spawnPosition?: SpawnPositionConfig;
    spawnShape?: SpawnShapeBehavior;
    direction?: DirectionConfig;
    speed?: SpeedBehaviorConfig;
    scale?: ScaleBehaviorConfig;
    alpha?: AlphaBehaviorConfig;
    gravity?: GravityBehaviorConfig;
    rotation?: RotationBehaviorConfig;
    color?: ColorBehaviorConfig;
    path?: PathConfig;
}
export interface ParticleEmitterConfig {
    emitterConfig: EmitterConfig;
    particleConfig: ParticleConfig;
}
export type RangeValue = {
    min: number;
    max: number;
};
export type NumberValue = RangeValue | number;
export type Multiplier = NumberValue;
//# sourceMappingURL=types.d.ts.map