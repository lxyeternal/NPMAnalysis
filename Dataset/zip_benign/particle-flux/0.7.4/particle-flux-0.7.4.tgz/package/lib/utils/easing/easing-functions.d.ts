import { EasingDictionary } from './easing.types';
export declare const EASING_FUNCTIONS: EasingDictionary;
//# sourceMappingURL=easing-functions.d.ts.map