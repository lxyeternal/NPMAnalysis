export declare class ArrayUtils {
    static last<T>(array: T[]): T | undefined;
    static range(start: number, stop: number, step?: number): number[];
}
//# sourceMappingURL=ArrayUtils.d.ts.map