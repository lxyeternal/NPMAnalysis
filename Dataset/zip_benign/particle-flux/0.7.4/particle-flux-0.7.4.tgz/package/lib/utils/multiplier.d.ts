import { Multiplier } from '../types';
export declare function getMultiplierValue(multiplier: Multiplier): number;
//# sourceMappingURL=multiplier.d.ts.map