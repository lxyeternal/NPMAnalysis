import { IRandomGenerator } from './IRandom';
export declare abstract class AbstractRandom implements IRandomGenerator {
    getArrayFromValues<T>(valuesArray: T[], length: number): T[];
    choice<T>(valuesArray: T[]): T;
    choiceList<T>(valuesArray: T[], length: number): T[];
    generateNumberArray(length: number, minValue: number, maxValue: number, isInteger?: boolean): number[];
    getRandomArrayIndex(array: Array<any>): number;
    generateRandomHexColor(): string;
    abstract generateIntegerNumber(min: number, max: number): number;
    abstract generateFloatNumber(min: number, max: number): number;
}
//# sourceMappingURL=Random.d.ts.map