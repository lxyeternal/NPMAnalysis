import { AbstractRandom } from './Random';
export declare class RealRandom extends AbstractRandom {
    generateIntegerNumber(minValue: number, maxValue: number): number;
    generateFloatNumber(minValue: number, maxValue: number): number;
}
export declare const realRandom: RealRandom;
//# sourceMappingURL=RealRandom.d.ts.map