import { PathFunction } from '../core/path/path.types';
export declare function parsePath(pathString: string): PathFunction;
//# sourceMappingURL=parsePath.d.ts.map