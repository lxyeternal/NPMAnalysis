export type EventCallback = <D>(data: D) => void;
export declare class EventEmitter {
    private events;
    on(event: string, callback: EventCallback): void;
    off(event: string, callback: EventCallback): void;
    emit<D>(event: string, data: D): void;
}
//# sourceMappingURL=EventEmitter.d.ts.map