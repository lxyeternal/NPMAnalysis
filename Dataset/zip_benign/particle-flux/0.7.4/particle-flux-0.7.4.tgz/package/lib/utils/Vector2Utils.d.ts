import { Point2d } from '../types';
export declare class Vector2Utils {
    static distance(v1: Point2d, v2: Point2d): number;
    static squaredDistance(v1: Point2d, v2: Point2d): number;
    static add(v1: Point2d, v2: Point2d): Point2d;
    static subtract(v1: Point2d, v2: Point2d): Point2d;
    static angleInDegreesToPoint(angleInDegrees: number): Point2d;
    static angleInRadToPoint(angleInRad: number): Point2d;
    static rotate(v: Point2d, angle: number): Point2d;
    static pointToAngleInDegrees(point: Point2d): number;
}
//# sourceMappingURL=Vector2Utils.d.ts.map