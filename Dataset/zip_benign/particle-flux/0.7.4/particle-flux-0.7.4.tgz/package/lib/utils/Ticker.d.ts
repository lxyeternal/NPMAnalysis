import { ITicker } from '../types';
export type TickerCallback = (elapsedDelta: number, deltaMS: number) => void;
export declare const STANDARD_DELTA_MS: number;
export declare class Ticker implements ITicker {
    private lastTime;
    private isStarted;
    private deltaBetweenFrames;
    private callback;
    constructor(cb: TickerCallback);
    get FPS(): number;
    get deltaMS(): number;
    get elapsedDelta(): number;
    get started(): boolean;
    setCallback(cb: TickerCallback): void;
    start(): void;
    stop(): void;
    private getDeltaBetweenFrames;
    private isWrongDeltaBetweenFrames;
}
//# sourceMappingURL=Ticker.d.ts.map