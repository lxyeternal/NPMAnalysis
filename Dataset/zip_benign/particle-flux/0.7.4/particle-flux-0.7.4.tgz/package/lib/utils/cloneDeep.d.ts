export declare function cloneDeep<T>(obj: T): T;
//# sourceMappingURL=cloneDeep.d.ts.map