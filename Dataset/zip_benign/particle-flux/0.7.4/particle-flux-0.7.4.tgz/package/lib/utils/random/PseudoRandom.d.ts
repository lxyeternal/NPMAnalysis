import { AbstractRandom } from './Random';
export declare class PseudoRandom extends AbstractRandom {
    private prevValue;
    private callsCounter;
    randomSeed: number;
    init(randomSeed: number, callsCounter?: number): void;
    setRandomSeed(randomSeed: number): void;
    setCallsCounter(callsCounter: number): void;
    reset(): void;
    getCallsCounter(): number;
    generateIntegerNumber(minValue: number, maxValue: number): number;
    generateFloatNumber(minValue: number, maxValue: number): number;
    private random;
    private initByCallsCounter;
}
//# sourceMappingURL=PseudoRandom.d.ts.map