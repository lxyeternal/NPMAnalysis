export declare class NumberUtils {
    static clamp(min: number, max: number, value: number): number;
    static inRange(min: number, max: number, value: number): boolean;
    static calcPercentage(value: number, max: number): number;
    static lerp(v1: number, v2: number, progress: number): number;
    static hexToRgb(hexColor: string): {
        r: number;
        g: number;
        b: number;
    };
    static rgbToHex(r: number, g: number, b: number): string;
    static lerpColor(color1: string, color2: string, progress: number): string;
    static degreesToRadians(angleInDegrees: number): number;
    static radiansToDegrees(angleInRad: number): number;
    static roundWith2Precision(n: number): number;
    static getDecimalPart(n: number): number;
    static getOrderedMinMax(a: number, b: number): [number, number];
    static normalizedDegrees(degrees: number): number;
}
//# sourceMappingURL=NumberUtils.d.ts.map