import { NumberValue, RangeValue } from './types';
export declare function isRangeValue(value: NumberValue): value is RangeValue;
//# sourceMappingURL=typeguards.d.ts.map