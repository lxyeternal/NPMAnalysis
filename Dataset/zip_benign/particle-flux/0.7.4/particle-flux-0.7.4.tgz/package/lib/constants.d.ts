import { LifeTimeStaticBehaviorConfig } from './core/behaviors/life-time-behavior/life-time-behavior.types';
export declare const DEFAULT_LIFE_TIME_CONFIG: LifeTimeStaticBehaviorConfig;
export declare const GRAVITY_DEFAULT_MULTIPLIER = 100;
//# sourceMappingURL=constants.d.ts.map