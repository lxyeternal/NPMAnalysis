import { GlobalWindow } from './types';
export declare const globalWindow: GlobalWindow | null;
//# sourceMappingURL=globalWindow.d.ts.map