
module.exports = {
    type: "default",
};
