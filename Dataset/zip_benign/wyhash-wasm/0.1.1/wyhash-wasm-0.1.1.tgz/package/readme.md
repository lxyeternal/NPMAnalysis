# WYHASH 0.5 (WASM)

This module has been ported to the web from https://crates.io/crates/wyhash (Rust implementation of the wyhash algorithm by Wang Yi)

> As of now it is the fastest algorithm in the SMHasher benchmark (faster than t1ha and XXH3).

## Usage

```html5
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8"/>
    <title>WyHash Wasm Demo</title>
  </head>
  <body>
    <script type="module">
      import init, { calculate_hash, BaseEncoding } from "wyhash-wasm";

      async function runHash() {
        await init(); // Initialize the wasm module

        const data = new TextEncoder().encode("Hello World");
        const seed = BigInt(0xA4DE);

        let resultHex   = calculate_hash(data, seed, BaseEncoding.Base16);
        let resultB32   = calculate_hash(data, seed, BaseEncoding.Base32);
        let resultB58   = calculate_hash(data, seed, BaseEncoding.Base58);

        console.log("Base16 / Hex:   ", resultHex);
        console.log("Base32:         ", resultB32);
        console.log("Base58:         ", resultB58);
      }

      runHash();
    </script>
  </body>
</html>
```
