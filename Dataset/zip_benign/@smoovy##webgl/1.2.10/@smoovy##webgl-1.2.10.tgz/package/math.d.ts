export type Mat4 = Float32Array;
export type Vec3A = [number, number, number];
export interface Vec2 {
    x: number;
    y: number;
}
export interface Vec3 extends Vec2 {
    z: number;
}
export interface Vec4 extends Vec3 {
    w: number;
}
/** Returns an identity matrix */
export declare function mat4(): Mat4;
/** Transforms to an identity matrix */
export declare function mat4i(m: Mat4, out?: Float32Array): Mat4;
/** Prints the matrix in a readable format to the console */
export declare function mat4log(m: Mat4): void;
/** Translates matrix by a vector (object) */
export declare function mat4tv(m: Mat4, v: Partial<Vec3>, out?: Float32Array): Mat4;
/** Translates the matrix by a vector (relative) */
export declare function mat4t(m: Mat4, t: Partial<Vec3A>, out?: Float32Array): Mat4;
/** multiply two matrices and output the transformed one */
export declare function mat4m(m1: Mat4, m2: Mat4, out?: Float32Array): Mat4;
/** euler to quaternion */
export declare function etq(r: Vec3, q: Vec4): Vec4;
/** mat4 scale, rotate (quaternion) and translate */
export declare function mat4srqt(m: Mat4, s: Vec3, q: Vec4, t: Vec3, out?: Float32Array): Mat4;
/**
 * Creates a perspective projection matrix.
 *
 * https://github.com/toji/gl-matrix/blob/master/src/mat4.js#L1537-L1563
 *
 * @param fovY vertical field of view in radians
 * @param asp aspect ratio
 * @param near near plane bound
 * @param far far plane bound
 */
export declare function mat4p(fovY: number, asp: number, near: number, far?: number, out?: Float32Array): Float32Array;
