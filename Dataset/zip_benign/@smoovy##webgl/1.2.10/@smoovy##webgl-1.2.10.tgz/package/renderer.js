"use strict";
import { Ticker } from "@smoovy/ticker";
import { Camera } from "./camera";
export class Renderer {
  constructor(gl, meshes, ticker = Ticker.main, order = 100, camera, initialSize = { width: 0, height: 0 }, uniforms) {
    this.gl = gl;
    this.meshes = meshes;
    this.ticker = ticker;
    this.order = order;
    this.uniforms = uniforms;
    this.cameras = {};
    this.cameras.main = new Camera(camera, initialSize);
  }
  get camera() {
    return this.cameras.main;
  }
  start() {
    this.ticker.add((_, time) => this.render(time / 1e3), this.order);
  }
  addCamera(name, camera) {
    this.cameras[name] = camera;
    return camera;
  }
  getCamera(name) {
    return this.cameras[name];
  }
  removeCamera(name) {
    delete this.cameras[name];
  }
  resize(width, height, ratio = 1) {
    this._resize = { width: width * ratio, height: height * ratio };
  }
  handleResize() {
    if (this._resize) {
      const { width, height } = this._resize;
      const gl = this.gl;
      gl.canvas.width = width;
      gl.canvas.height = height;
      gl.viewport(0, 0, width, height);
      for (const camera of Object.values(this.cameras)) {
        camera.updateView(width, height);
      }
      for (const mesh of this.meshes) {
        mesh.updateGeometry();
      }
      delete this._resize;
    }
  }
  render(time = Ticker.now()) {
    const gl = this.gl;
    this.handleResize();
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    for (const camera of Object.values(this.cameras)) {
      camera.draw();
    }
    for (const mesh of this.meshes.filter((m) => !m.disabled)) {
      mesh.bind();
      mesh.draw(time, this.uniforms);
      mesh.unbind();
    }
  }
}
