import { Camera } from './camera';
import { Vec2 } from './math';
import { Model } from './model';
import { Program } from './program';
import { Texture } from './texture';
import { UniformType, UniformValue } from './uniform';
export interface MeshConfig {
    /**
     * The mode to draw the vertices. This can be one of the following:
     *
     * - gl.POINTS
     * - gl.LINE_STRIP
     * - gl.LINE_LOOP
     * - gl.LINES
     * - gl.TRIANGLE_STRIP
     * - gl.TRIANGLE_FAN
     * - gl.TRIANGLES
     *
     * Default = gl.TRIANGLES
     */
    mode?: number;
    /**
     * The camera to use for the mesh. This is required if you want to use
     * the mesh in a scene.
     */
    camera: Camera;
    /**
     * The vertex shader for the program of the mesh
     */
    vertex?: string;
    /**
     * The fragment shader for the program of the mesh
     */
    fragment?: string;
    /**
     * Whether to transform coordinates and sizes from screen to clip space.
     * This allows you to set pixel values as coordinates and sizes instead
     * of clip space values. Useful if mapping to the DOM
     *
     * @default false
     */
    screen?: boolean;
    /**
     * The uniforms to pass to the shader program. This will be passed as
     * a uniform with the name of the key. The value will be used as the
     * value of the uniform.
     *
     * @default {}
     */
    uniforms?: Record<string, UniformValue>;
    /**
     * Hint for the autodection of the uniform type. This is useful if you
     * want to pass a uniform that is ambiguous. This is  only needed if the
     * uniforms type can't be detected or there's an overlap like mat2 (size = 4)
     * and vec4 (size = 4). It will not force the type if the type has already
     * been detected correctly. It will always fallback to the vector float type,
     * since it's more commonly used
     *
     * @default {}
     */
    uniformTypes?: Record<string, UniformType>;
    /**
     * Whether to warn if a uniform is not found. This is useful if you
     * want to pass uniforms to the shader program that are optional.
     *
     * @default {}
     */
    uniformOptionals?: Record<string, boolean>;
    /**
     * The texture to use for the mesh. This can be a single texture or
     * an object with multiple textures. The key will be used as the
     * uniform name and the value as the texture.
     */
    texture?: Texture | Record<string, Texture>;
    /**
     * Hide the mesh as long as e.g. a texture is loading
     *
     * @default true
     */
    hideOnLoad?: boolean;
    /**
     * The initial translated x-position
     */
    x?: number;
    /**
     * The initial translated y-position
     */
    y?: number;
    /**
     * The initial translated z-position
     */
    z?: number;
}
export declare class Mesh<C extends MeshConfig = MeshConfig> extends Model {
    protected gl: WebGLRenderingContext;
    protected config: C;
    private static defaultViewProj;
    private disables;
    private screenPosition;
    private textures;
    protected rawPosition: Vec2;
    protected program: Program;
    constructor(gl: WebGLRenderingContext, config: C);
    private initTextures;
    get disabled(): boolean;
    get mode(): number;
    get uniforms(): Record<string, UniformValue>;
    get camera(): Camera;
    get centerX(): number;
    get centerY(): number;
    protected screenX(x?: number): number;
    protected screenY(y?: number): number;
    set y(y: number);
    get y(): number;
    set x(x: number);
    get x(): number;
    updateGeometry(): void;
    bind(): void;
    updateModel(): void;
    draw(time?: number, uniforms?: Record<string, UniformValue>): void;
    protected beforeDraw(): void;
    protected afterDraw(): void;
    unbind(): void;
    disable(ref?: string): void;
    enable(ref?: string, enabled?: boolean): void;
    destroy(): void;
}
