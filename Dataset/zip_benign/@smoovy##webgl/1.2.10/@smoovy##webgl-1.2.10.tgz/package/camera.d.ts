import { Size } from '@smoovy/utils';
import { Model } from './model';
export interface CameraConfig {
    fov: number;
    near: number;
    far: number;
    posZ: number;
}
export declare class Camera extends Model {
    readonly size: Size;
    readonly view: Size;
    private _projection;
    private config;
    constructor(config?: Partial<CameraConfig>, view?: Partial<Size>);
    get projection(): Float32Array;
    /** Transforms pixel coordianate to clip space coordinate */
    cw(width: number): number;
    ch(height: number): number;
    cx(x: number, z?: number): number;
    cy(y: number, z?: number): number;
    draw(): void;
    updateView(width?: number, height?: number): void;
}
