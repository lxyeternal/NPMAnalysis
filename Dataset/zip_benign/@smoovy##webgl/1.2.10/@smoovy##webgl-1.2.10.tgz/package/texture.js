"use strict";
import { Ticker } from "@smoovy/ticker";
import { Resolver } from "@smoovy/utils";
const _TextureMediaLoader = class {
  static load(source) {
    const cache = _TextureMediaLoader.images;
    if (cache.has(source)) {
      return cache.get(source);
    }
    const image = new Image();
    image.src = source;
    image.crossOrigin = "anonymous";
    const promise = new Promise((resolve, reject) => {
      image.addEventListener("error", (err) => reject(err));
      image.addEventListener("load", () => resolve(image));
    });
    cache.set(source, promise);
    return promise;
  }
};
export let TextureMediaLoader = _TextureMediaLoader;
TextureMediaLoader.images = /* @__PURE__ */ new Map();
export class Texture {
  constructor(gl, config) {
    this.gl = gl;
    this.config = config;
    this.resolver = new Resolver();
    this.texture = gl.createTexture();
  }
  bind(slot = 0, location) {
    const gl = this.gl;
    gl.activeTexture(gl.TEXTURE0 + slot);
    gl.bindTexture(gl.TEXTURE_2D, this.texture);
    if (location) {
      gl.uniform1i(location, slot);
    }
  }
  unbind(slot = 0) {
    const gl = this.gl;
    gl.activeTexture(gl.TEXTURE0 + slot);
    gl.bindTexture(gl.TEXTURE_2D, null);
  }
  upload(data) {
    const gl = this.gl;
    const config = this.config;
    const wrapS = config.wrapS || gl.CLAMP_TO_EDGE;
    const wrapT = config.wrapT || gl.CLAMP_TO_EDGE;
    const minFilter = config.minFilter || gl.LINEAR;
    gl.bindTexture(gl.TEXTURE_2D, this.texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, minFilter);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, wrapS);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrapT);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, config.unpackFlip !== false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, data);
    gl.bindTexture(gl.TEXTURE_2D, null);
    if (!this.resolver.completed) {
      this.resolver.resolve(true);
    }
  }
  get uploaded() {
    return this.resolver.promise;
  }
  destroy() {
  }
}
export class ImageTexture extends Texture {
  constructor(gl, config) {
    super(gl, config);
    if (config.load !== false) {
      this.load();
    }
  }
  load() {
    TextureMediaLoader.load(this.config.src).then((image) => {
      this.upload(image);
    });
  }
}
export class VideoTexture extends Texture {
  constructor(gl, config) {
    super(gl, config);
    this.rvfcSupported = false;
    if (config.src instanceof HTMLVideoElement) {
      this.video = config.src;
    } else {
      this.video = document.createElement("video");
      this.video.muted = true;
      this.video.src = config.src;
    }
    this.video.crossOrigin = "anonymous";
    this.rvfcSupported = "requestVideoFrameCallback" in this.video;
    this.updateVideoCbRVFC = this.updateVideoRVFC.bind(this);
    if (this.rvfcSupported) {
      this.video.requestVideoFrameCallback(() => this.updateVideoRVFC());
      Ticker.main.add((delta, time, kill) => {
        if (this.video.readyState >= this.video.HAVE_CURRENT_DATA) {
          this.updateVideo();
          kill();
        }
      });
    } else {
      let first = true;
      Ticker.main.add(() => {
        const ready = this.video.readyState >= this.video.HAVE_CURRENT_DATA;
        if (ready && !this.video.paused || ready && first) {
          first = false;
          this.updateVideo();
        }
      });
    }
  }
  updateVideoRVFC() {
    this.updateVideo();
    this.video.requestVideoFrameCallback(this.updateVideoCbRVFC);
  }
  updateVideo() {
    const gl = this.gl;
    const vid = this.video;
    if (!this.resolver.completed) {
      this.upload(vid);
    } else {
      gl.bindTexture(gl.TEXTURE_2D, this.texture);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, vid);
      gl.bindTexture(gl.TEXTURE_2D, null);
    }
  }
}
export class FramebufferTexture extends Texture {
}
