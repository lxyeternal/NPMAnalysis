"use strict";
import { isNum } from "@smoovy/utils";
import { mat4 } from "./math";
import { Model } from "./model";
import { Program } from "./program";
import { Texture } from "./texture";
const _Mesh = class extends Model {
  constructor(gl, config) {
    super();
    this.gl = gl;
    this.config = config;
    this.disables = /* @__PURE__ */ new Set();
    this.screenPosition = {};
    this.textures = /* @__PURE__ */ new Map();
    this.rawPosition = { x: 0, y: 0 };
    if (!config.vertex || !config.fragment) {
      throw new Error("vertex and fragment shader required");
    }
    this.x = config.x || 0;
    this.y = config.y || 0;
    this.z = config.z || 0;
    this.program = new Program(gl, config.vertex, config.fragment);
    this.initTextures();
  }
  initTextures() {
    const texture = this.config.texture;
    if (texture) {
      if (this.config.hideOnLoad !== false) {
        this.disable("texture");
      }
      const uploads = [];
      if (texture instanceof Texture) {
        this.textures.set(texture, [this.program.uniform("u_texture"), 0]);
        uploads.push(texture.uploaded);
      } else {
        let slot = 0;
        for (const [k, tex] of Object.entries(texture)) {
          const key = k.charAt(0).toUpperCase() + k.slice(1);
          const apx = k.toLowerCase() !== "default" ? `${key}` : "";
          const name = `u_texture${apx}`;
          this.textures.set(tex, [this.program.uniform(name), slot++]);
          uploads.push(tex.uploaded);
        }
      }
      if (this.config.hideOnLoad !== false) {
        Promise.all(uploads).then(() => this.enable("texture"));
      }
    }
  }
  get disabled() {
    return this.disables.size > 0;
  }
  get mode() {
    return this.config.mode || this.gl.TRIANGLES;
  }
  get uniforms() {
    return this.config.uniforms || {};
  }
  get camera() {
    return this.config.camera;
  }
  get centerX() {
    return 0;
  }
  get centerY() {
    return 0;
  }
  screenX(x = 0) {
    return this.camera.cx(x, this.z) + this.camera.cw(this.centerX);
  }
  screenY(y = 0) {
    return this.camera.cy(y, this.z) - this.camera.ch(this.centerY);
  }
  set y(y) {
    this.rawPosition.y = y;
    if (this.config.screen) {
      this.screenPosition.y = y;
      this.config.y = y;
    } else {
      this.position.y = y - this.centerY;
      this.config.y = y - this.centerY;
    }
  }
  get y() {
    return this.rawPosition.y;
  }
  set x(x) {
    this.rawPosition.x = x;
    if (this.config.screen) {
      this.screenPosition.x = x;
      this.config.x = x;
    } else {
      this.position.x = x - this.centerX;
      this.config.x = this.position.x;
    }
  }
  get x() {
    return this.rawPosition.x;
  }
  updateGeometry() {
  }
  bind() {
    this.program.bind();
  }
  updateModel() {
    if (this.config.screen) {
      const { x, y } = this.screenPosition;
      if (isNum(x)) {
        this.position.x = this.screenX(x);
        delete this.screenPosition.x;
      }
      if (isNum(y)) {
        this.position.y = this.screenY(y);
        delete this.screenPosition.y;
      }
    }
    super.updateModel();
  }
  draw(time = 0, uniforms = {}) {
    this.updateModel();
    const program = this.program;
    const camera = this.config.camera;
    const view = camera?.model || _Mesh.defaultViewProj;
    const proj = camera?.projection || _Mesh.defaultViewProj;
    program.uniform("u_time", time, "f", false);
    program.uniform("u_res", camera.view, "v2", false);
    program.uniform("u_proj", proj, "m4", false);
    program.uniform("u_view", view, "m4", false);
    program.uniform("u_model", this.model, "m4", false);
    uniforms = { ...uniforms, ...this.config.uniforms };
    if (uniforms) {
      const uniformTypes = this.config.uniformTypes || {};
      const uniformOptionals = this.config.uniformOptionals || {};
      for (const [name, value] of Object.entries(uniforms)) {
        const type = uniformTypes[name];
        const warn = !uniformOptionals[name];
        program.uniform(name, value, type, warn);
      }
    }
    for (const [texture, [location, slot]] of this.textures) {
      texture.bind(slot, location);
    }
    this.beforeDraw();
    this.gl.drawArrays(this.mode, 0, this.program.enableAttribs());
    this.afterDraw();
  }
  beforeDraw() {
  }
  afterDraw() {
  }
  unbind() {
    this.program.unbind();
  }
  disable(ref = "_") {
    if (!this.disables.has(ref)) {
      this.disables.add(ref);
    }
  }
  enable(ref = "_", enabled = true) {
    if (enabled) {
      this.disables.delete(ref);
    } else {
      this.disable(ref);
    }
  }
  destroy() {
    this.program.destroy();
  }
};
export let Mesh = _Mesh;
Mesh.defaultViewProj = mat4();
