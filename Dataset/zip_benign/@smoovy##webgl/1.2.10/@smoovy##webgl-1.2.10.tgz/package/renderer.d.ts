import { Ticker } from '@smoovy/ticker';
import { Size } from '@smoovy/utils';
import { Camera, CameraConfig } from './camera';
import { Mesh } from './mesh';
import { UniformValue } from './uniform';
export declare class Renderer {
    private gl;
    private meshes;
    private ticker;
    private order;
    private uniforms?;
    private _resize?;
    private cameras;
    constructor(gl: WebGLRenderingContext, meshes: Mesh[], ticker?: Ticker, order?: number, camera?: Partial<CameraConfig>, initialSize?: Size, uniforms?: Record<string, UniformValue> | undefined);
    get camera(): Camera;
    start(): void;
    addCamera(name: string, camera: Camera): Camera;
    getCamera(name: string): Camera;
    removeCamera(name: string): void;
    resize(width: number, height: number, ratio?: number): void;
    private handleResize;
    render(time?: number): void;
}
