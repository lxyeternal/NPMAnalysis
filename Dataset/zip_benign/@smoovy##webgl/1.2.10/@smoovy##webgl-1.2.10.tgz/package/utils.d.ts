import { Coordinate } from '@smoovy/utils';
import { UniformType, UniformValue } from './uniform';
export declare function createCanvas(canvas?: HTMLCanvasElement | string): HTMLCanvasElement;
export declare function createShader(gl: WebGLRenderingContext, type: GLenum, source: string): WebGLShader;
export declare function uniformValue(value: UniformValue): number | Float32Array | number[];
export declare function uniformMethod(value: number | number[] | Float32Array, type?: UniformType): string | undefined;
export declare function triangulate(density: Coordinate, center?: boolean, cache?: boolean): Float32Array;
export declare function warnOnce(message: string, warn?: boolean): void;
