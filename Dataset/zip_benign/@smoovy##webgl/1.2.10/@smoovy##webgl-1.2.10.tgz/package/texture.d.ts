import { Resolver } from "@smoovy/utils";
export interface TextureConfig {
    wrapS?: number;
    wrapT?: number;
    minFilter?: number;
    unpackFlip?: boolean;
}
export interface ImageTextureConfig extends TextureConfig {
    src: string;
    load?: boolean;
}
export interface VideoTextureConfig extends TextureConfig {
    src: string | HTMLVideoElement;
}
export type FramebufferTextureConfig = TextureConfig;
export declare class TextureMediaLoader {
    static readonly images: Map<string, Promise<HTMLImageElement>>;
    static load(source: string): Promise<HTMLImageElement>;
}
export declare class Texture<C extends TextureConfig = TextureConfig> {
    protected gl: WebGLRenderingContext;
    protected config: C;
    protected texture: WebGLTexture;
    protected resolver: Resolver<boolean, boolean>;
    constructor(gl: WebGLRenderingContext, config: C);
    bind(slot?: number, location?: WebGLUniformLocation): void;
    unbind(slot?: number): void;
    upload(data: any): void;
    get uploaded(): Promise<boolean>;
    destroy(): void;
}
export declare class ImageTexture extends Texture<ImageTextureConfig> {
    constructor(gl: WebGLRenderingContext, config: ImageTextureConfig);
    load(): void;
}
export declare class VideoTexture extends Texture<VideoTextureConfig> {
    readonly video: HTMLVideoElement;
    private rvfcSupported;
    private updateVideoCbRVFC;
    constructor(gl: WebGLRenderingContext, config: VideoTextureConfig);
    private updateVideoRVFC;
    private updateVideo;
}
export declare class FramebufferTexture extends Texture<FramebufferTextureConfig> {
}
