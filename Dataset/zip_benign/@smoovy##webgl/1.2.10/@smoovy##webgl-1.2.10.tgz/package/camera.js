"use strict";
import { mapRange } from "@smoovy/utils";
import { mat4, mat4p } from "./math";
import { Model } from "./model";
export class Camera extends Model {
  constructor(config = {}, view) {
    super();
    this.size = { width: 0, height: 0 };
    this.view = { width: 1, height: 1 };
    this._projection = mat4();
    this.config = { near: 0.1, far: 100, fov: 45, posZ: -3, ...config };
    this.position.z = this.config.posZ;
    this.updateView(view?.width, view?.height);
  }
  get projection() {
    return this._projection;
  }
  cw(width) {
    return width / this.view.width * this.size.width;
  }
  ch(height) {
    return height / this.view.height * this.size.height;
  }
  cx(x, z = 0) {
    const fov = this.config.fov * Math.PI / 180;
    const aspect = this.view.width / this.view.height;
    const height = 2 * Math.tan(fov / 2) * Math.abs(this.position.z + z);
    const width = height * aspect * 0.5;
    const value = x / this.view.width * 2 - 1;
    return mapRange(value, -1, 1, -width, width);
  }
  cy(y, z = 0) {
    const fov = this.config.fov * Math.PI / 180;
    const height = 2 * Math.tan(fov / 2) * Math.abs(this.position.z + z) * 0.5;
    const value = y / this.view.height * -1 * 2 + 1;
    return mapRange(value, -1, 1, -height, height);
  }
  draw() {
    this.updateModel();
  }
  updateView(width, height) {
    if (typeof width === "number") {
      this.view.width = width;
    }
    if (typeof height === "number") {
      this.view.height = height;
    }
    const { near, far } = this.config;
    const fov = this.config.fov * Math.PI / 180;
    const aspect = this.view.width / this.view.height;
    this.size.height = 2 * Math.tan(fov / 2) * Math.abs(this.position.z);
    this.size.width = this.size.height * aspect;
    this._projection = mat4p(fov, aspect, near, far);
  }
}
