import { UniformType, UniformValue } from './uniform';
export interface ProgramAttrib {
    type: number;
    size: number;
    norm: boolean;
    count: number;
    stride: number;
    offset: number;
    location: number;
    buffer: WebGLBuffer;
}
export declare class Program {
    protected gl: WebGLRenderingContext;
    private buffers;
    private attribs;
    private uniforms;
    private vertex;
    private fragment;
    private _program;
    private bound;
    constructor(gl: WebGLRenderingContext, vertex: string, fragment: string);
    bind(): void;
    unbind(): void;
    enableAttribs(): number;
    uniform(name: string, value?: UniformValue, type?: UniformType, warn?: boolean): WebGLUniformLocation;
    attribute(name: string, data: WebGLBuffer | Float32Array, size?: number, count?: number, norm?: boolean, type?: number, stride?: number, offset?: number): void;
    bufferData(name: string, data: Float32Array): WebGLBuffer;
    get program(): WebGLProgram;
    destroy(): void;
}
