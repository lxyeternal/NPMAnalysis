"use strict";
import { EventEmitter } from "@smoovy/emitter";
import { observe } from "@smoovy/observer";
import { Ticker } from "@smoovy/ticker";
import { Camera } from "./camera";
import { Plane } from "./geometry/plane";
import { Renderer } from "./renderer";
import {
  ImageTexture,
  VideoTexture
} from "./texture";
import { createCanvas } from "./utils";
export var WebGLEvent = /* @__PURE__ */ ((WebGLEvent2) => {
  WebGLEvent2["BEFORE_RENDER"] = "beforerender";
  WebGLEvent2["AFTER_RENDER"] = "afterrender";
  return WebGLEvent2;
})(WebGLEvent || {});
export class WebGL extends EventEmitter {
  constructor(config = {}) {
    super();
    this.meshes = [];
    this.lastSize = { width: 0, height: 0 };
    this.config = {
      color: [0, 0, 0],
      alpha: true,
      antialias: true,
      premultipliedAlpha: true,
      dpr: 1,
      depth: true,
      ...config
    };
    this.ticker = config.ticker || Ticker.main;
    this.canvas = createCanvas(config.canvas);
    this.observable = observe(window, { resizeDetection: true });
    this.context = this.canvas.getContext("webgl2", config) || this.canvas.getContext("webgl", config) || this.canvas.getContext("webgl-experimental", config);
    this.renderer = new Renderer(
      this.context,
      this.meshes,
      this.config.ticker,
      this.config.taskOrder,
      this.config.camera,
      this.observable.size,
      this.config.uniforms
    );
    this.init();
    this.start();
  }
  get uniforms() {
    return this.config.uniforms || {};
  }
  get ctx() {
    return this.context;
  }
  init() {
    if (this.config.autoSize !== false) {
      const style = this.canvas.style;
      const size = this.observable.size;
      style.pointerEvents = "none";
      style.position = "fixed";
      style.left = "0px";
      style.top = "0px";
      this.setSize(size.width, size.height);
      this.unlisten = this.observable.onChange((state) => {
        this.setSize(state.width, state.height);
      });
    }
  }
  start() {
    const gl = this.context;
    const color = this.config.color || [0, 0, 0];
    const alpha = this.config.alpha;
    gl.enable(gl.BLEND);
    gl.enable(gl.CULL_FACE);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.clearColor(color[0], color[1], color[2], alpha ? 0 : 1);
    gl.clear(gl.COLOR_BUFFER_BIT);
    this.renderer.start();
  }
  setSize(width, height) {
    if (this.lastSize.width === width && this.lastSize.height === height) {
      return;
    }
    this.canvas.style.width = `${width}px`;
    this.canvas.style.height = `${height}px`;
    this.lastSize.width = width;
    this.lastSize.height = height;
    this.renderer.resize(width, height, this.config.dpr || 1);
  }
  remove(mesh) {
    const index = this.meshes.indexOf(mesh);
    if (index > -1) {
      this.meshes.splice(index, 1).forEach((m) => m.destroy());
    }
    return this;
  }
  plane(config = {}) {
    const plane = new Plane(this.context, {
      camera: this.renderer.camera,
      ...config
    });
    this.meshes.push(plane);
    return plane;
  }
  camera(name, config) {
    if (!config) {
      return this.renderer.getCamera(name);
    }
    return this.renderer.addCamera(
      name,
      new Camera(config, this.observable.size)
    );
  }
  image(config) {
    return new ImageTexture(this.context, config);
  }
  video(config) {
    return new VideoTexture(this.context, config);
  }
  destroy() {
    if (this.unlisten) {
      this.unlisten();
      delete this.unlisten;
    }
    if (this.task) {
      this.task.kill();
      delete this.task;
    }
  }
}
