import { EventEmitter } from '@smoovy/emitter';
import { Observable } from '@smoovy/observer';
import { Ticker, TickerTask } from '@smoovy/ticker';
import { Camera, CameraConfig } from './camera';
import { Plane, PlaneConfig } from './geometry/plane';
import { Mesh } from './mesh';
import { Renderer } from './renderer';
import { ImageTexture, ImageTextureConfig, VideoTexture, VideoTextureConfig } from './texture';
export interface WebGLConfig extends WebGLContextAttributes {
    /**
     * The canvas element you want to use. If you don't provide the config
     * with an element or selector a new canvas elemnt will be created and
     * prepended to the body element.
     */
    canvas?: HTMLCanvasElement | string;
    /**
     * Custom ticker. This is useful if you want something like frame-lock.
     * The default has no frame-lock.
     */
    ticker?: Ticker;
    /**
     * The order of the the ticker task. This is useful if you want to
     * control the order of the tasks. So if you have some values that
     * need to be calculated in the same frame before webgl renders
     *
     * @default 100
     */
    taskOrder?: number;
    /**
     * This will position the canvas element as fixed and always sets its size
     * to the users screen size.
     *
     * @default true
     */
    autoSize?: boolean;
    /**
     * Global uniforms that will be passed to all meshes. This is useful if
     * you want to pass some values to all meshes without setting them
     * manually. You can still override them on each mesh. The values will
     * be passed to the shader as a uniform with the name of the key.
     *
     * @default {}
     */
    uniforms?: Record<string, any>;
    /**
     * The pixel ratio of the canvas. This will be multiplied with the
     * width and height of the canvas.
     *
     * @default 1
     */
    dpr?: number;
    /**
     * The clear color of the canvas. This will be set on the first render
     * call.
     *
     * @default [0, 0, 0]
     */
    color?: [number, number, number];
    /**
     * Config for the main camera
     *
     * @default { posZ: -3, fov: 45, near: 0.1, far: 100  }
     */
    camera?: Partial<CameraConfig>;
}
export declare enum WebGLEvent {
    BEFORE_RENDER = "beforerender",
    AFTER_RENDER = "afterrender"
}
export declare class WebGL extends EventEmitter {
    readonly renderer: Renderer;
    protected readonly meshes: Mesh[];
    protected canvas: HTMLCanvasElement;
    protected observable: Observable<Window>;
    protected ticker: Ticker;
    protected task?: TickerTask;
    private config;
    private context;
    private unlisten?;
    private lastSize;
    constructor(config?: WebGLConfig);
    get uniforms(): Record<string, any>;
    get ctx(): WebGLRenderingContext;
    init(): void;
    start(): void;
    setSize(width: number, height: number): void;
    remove(mesh: Mesh): this;
    plane(config?: Partial<PlaneConfig>): Plane<{
        width?: number | undefined;
        height?: number | undefined;
        originX?: number | undefined;
        originY?: number | undefined;
        density?: number | import("@smoovy/utils").Coordinate<number> | undefined;
        mode?: number | undefined;
        camera: Camera;
        vertex?: string | undefined;
        fragment?: string | undefined;
        screen?: boolean | undefined;
        uniforms?: Record<string, import("./uniform").UniformValue> | undefined;
        uniformTypes?: Record<string, import("./uniform").UniformType> | undefined;
        uniformOptionals?: Record<string, boolean> | undefined;
        texture?: import("./texture").Texture<import("./texture").TextureConfig> | Record<string, import("./texture").Texture<import("./texture").TextureConfig>> | undefined;
        hideOnLoad?: boolean | undefined;
        x?: number | undefined;
        y?: number | undefined;
        z?: number | undefined;
    }>;
    camera(name: string, config?: Partial<CameraConfig>): Camera;
    image(config: ImageTextureConfig): ImageTexture;
    video(config: VideoTextureConfig): VideoTexture;
    destroy(): void;
}
