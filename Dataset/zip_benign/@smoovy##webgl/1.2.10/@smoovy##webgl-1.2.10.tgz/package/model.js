"use strict";
import { etq, mat4, mat4srqt } from "./math";
export class Model {
  constructor() {
    this.position = Object.seal({ x: 0, y: 0, z: 0 });
    this.rotation = Object.seal({ x: 0, y: 0, z: 0 });
    this.scaling = Object.seal({ x: 1, y: 1, z: 1 });
    this.quaternion = Object.seal({ x: 0, y: 0, z: 0, w: 1 });
    this._model = mat4();
    this.state = 3;
  }
  set x(x) {
    this.position.x = x;
  }
  get x() {
    return this.position.x;
  }
  set y(y) {
    this.position.y = y;
  }
  get y() {
    return this.position.y;
  }
  set z(z) {
    this.position.z = z;
  }
  get z() {
    return this.position.z;
  }
  set scaleX(x) {
    this.scaling.x = x;
  }
  get scaleX() {
    return this.scaling.x;
  }
  set scaleY(y) {
    this.scaling.y = y;
  }
  get scaleY() {
    return this.scaling.y;
  }
  set scaleZ(z) {
    this.scaling.z = z;
  }
  get scaleZ() {
    return this.scaling.z;
  }
  set rotationX(x) {
    this.rotation.x = x;
  }
  get rotationX() {
    return this.rotation.x;
  }
  set rotationY(y) {
    this.rotation.y = y;
  }
  get rotationY() {
    return this.rotation.y;
  }
  set rotationZ(z) {
    this.rotation.z = z;
  }
  get rotationZ() {
    return this.rotation.z;
  }
  get model() {
    return this._model;
  }
  updateModelState() {
    const p = this.position;
    const r = this.rotation;
    const s = this.scaling;
    this.state = p.x + p.y + p.z + r.x + r.y + r.z + s.x + s.y + s.z;
  }
  updateModel() {
    const prevState = this.state;
    this.updateModelState();
    if (prevState !== this.state) {
      this.modelWillUpdate();
      mat4srqt(
        this._model,
        this.scaling,
        etq(this.rotation, this.quaternion),
        this.position
      );
    }
  }
  modelWillUpdate() {
  }
}
