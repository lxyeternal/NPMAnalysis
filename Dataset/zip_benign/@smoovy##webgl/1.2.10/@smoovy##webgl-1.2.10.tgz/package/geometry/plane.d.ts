import { Coordinate } from '@smoovy/utils';
import { Mesh, MeshConfig } from '../mesh';
export interface PlaneConfig extends MeshConfig {
    width?: number;
    height?: number;
    originX?: number;
    originY?: number;
    density?: number | Coordinate;
}
export declare class Plane<C extends PlaneConfig = PlaneConfig> extends Mesh<C> {
    protected gl: WebGLRenderingContext;
    constructor(gl: WebGLRenderingContext, config: C);
    set originX(origin: number);
    get originX(): number;
    set originY(origin: number);
    get originY(): number;
    get centerX(): number;
    get centerY(): number;
    get density(): Coordinate<number>;
    set width(width: number);
    get width(): number;
    set height(height: number);
    get height(): number;
    private scaleVertices;
    private parseNormals;
    updateGeometry(): void;
    beforeDraw(): void;
}
