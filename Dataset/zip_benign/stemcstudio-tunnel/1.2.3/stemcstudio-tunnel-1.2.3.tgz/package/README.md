# stemcstudio-tunnel

[![version](https://img.shields.io/npm/v/stemcstudio-tunnel.svg)](https://www.npmjs.com/package/stemcstudio-tunnel) 

Allows STEMCstudio programs to post and receive messages when launched from a Learning Management System using the Learning Tools Interoperability 1.3 protocol.

Based on [Learning Tools Interoperability (LTI) Assignment and Grade Services Specification](http://www.imsglobal.org/spec/lti-ags/v2p0)

The primary usage for this API will be interacting with the LMS Gradebook.

## Usage (LTI Activity or Resource authoring).

Select 'stemcstudio-tunnel' as a project dependency in the Project Settings dialog of STEMCstudio.

In your project code, import the symbols that you will need...

```typescript
import { gradebook, Item, Result, Score } from 'stemcstudio-tunnel'
```

Getting the items (columns) for the activity from the Gradebook is essential because it allows you to know the identifier of each item.
A Gradebook item identifier will be used when submitting scores and retrieving results for the current activity.
An LMS will generally ensure the existence of a default item for each activity, but you can add more.

```typescript
const promise: Promise<Item[]> = gradebook.getItems();
```

Submitting a score for the activity...

```typescript
const itemId = "...";               // discover from getItems.
const score: Score = {
    scoreGiven: 0.5,
    scoreMaximum: 1,
    activityProgress: "Completed",
    gradingProgress: "FullyGraded",
    comment: "Jolly good show!"     // optional
}
// The submission is complete when the promise resolves.
// The promise does not provide a value.
const promise: Promise<void> = gradebook.submitScore(itemId, score);
```

Getting the results for an activity...

```typescript
const itemId = "...";               // discover from getItems.
const promise: Promise<Result[]> = gradebook.getResults(itemId);
const results: Result[] = await promise;
const result: Result = results[0];
result.id;
result.resultScore;
result.resultMaximum;
result.scoreOf;
result.userId;
result.timestamp;
result.comment;
```
Creating a new Gradebook item for the current activity...

```typescript
const item: Omit<Item, "id"> = {
    label: "",
    scoreMaximum: 100,
    startDateTime: "",  // optional, ISO8601 format.
    endDateTime: "",    // optional, ISO8601 format.
    ltiLinkId: "",      // optional
    resourceId: "",     // optional
    resourceLinkId: "", // optional
    tag: ""             // optional
}
const promise: Promise<Item> = gradebook.createItem(item);
```

## Example: A STEMCstudio program as an Activity or Resource in a Learning Management System.

This example is best experienced by launching it from your LMS. To do so, first register STEMCstudio using
LTI 1.3 Advantage Dynamic Registration. You can then use LTI 1.3 Deep Linking to link in this STEMCstudio program.

Be aware that score submission can fail if you are not logged in as a user enrolled in the course!

It will also run in simulation mode when STEMCstudio is run standalone (i.e. outside of the LMS).

[LTI 1.3 Playground](https://stemcstudio.com/gists/96ea9435cb61fa7ba342bb226fb99623)

