export declare function isNumber(source: any, checkSafetyNumber?: boolean): boolean;
