export declare function percentage(source: number | string, digits?: number): string;
