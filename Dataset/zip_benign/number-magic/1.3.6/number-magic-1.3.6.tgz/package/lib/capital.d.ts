export declare function capital(source: number | string): string;
