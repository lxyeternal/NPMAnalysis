export declare function idxList(len: number, delta?: number): number[];
