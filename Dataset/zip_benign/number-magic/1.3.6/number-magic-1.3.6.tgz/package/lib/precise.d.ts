export declare function precise(source: number, precision?: number): number;
