export declare function toFixed(source: number | string, digits?: number): string;
