export declare const MAX_SAFETY_NUMBER: number;
export declare const MIN_SAFETY_NUMBER: number;
