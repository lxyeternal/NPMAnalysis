export declare function comma(source: number | string, length?: Number): string;
