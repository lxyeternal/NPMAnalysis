/** Pretty-print TLV-TYPE number. */
export declare function printTT(tlvType: number): string;
