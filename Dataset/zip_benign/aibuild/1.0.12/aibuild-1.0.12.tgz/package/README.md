# aibuild

aibuild is a command line tool for interacting with the OpenAI API.

## Installation

```
npm install -g aibuild
```

## Usage

### Set API Key

To use the aibuild tool, you will need to [obtain an API key from OpenAI](https://beta.openai.com/). Once you have your key, you can use the `aibuild key` command to set it.

```
aibuild key <your-key-here>
```

### Check API Key

Once you have set your API key, you can use the `aibuild check-key` command to verify that it is valid.

```
aibuild check-key
```

### Generate Text

The `aibuild generate` command can be used to generate text using the OpenAI text completion model.

```
aibuild generate <prompt> [model] [temperature]
```

#### Prompt

The `prompt` parameter is the text that you want the model to complete. This can be a single word or a complete sentence.

#### Model

The `model` parameter is the name of the model that you want to use. The default model is `text-davinci-002`.

#### Temperature

The `temperature` parameter controls how creative the generated text will be. A higher temperature will result in more creative output, while a lower temperature will result in more conservative output. The default temperature is `0.5`.

### Generate Text from File

The `aibuild generate-from-file` command can be used to generate text using the OpenAI text completion model, using the contents of a file as the prompt.

```
aibuild generate-from-file <file> [model] [temperature]
```

#### File

The `file` parameter is the path to the file that contains the text that you want the model to complete.

#### Model

The `model` parameter is the name of the model that you want to use. The default model is `text-davinci-002`.

#### Temperature

The `temperature` parameter controls how creative the generated text will be. A higher temperature will result in more creative output, while a lower temperature will result in more conservative output. The default temperature is `0.5`.

### Generate Text to File

The `aibuild generate-to-file` command can be used to generate text using the OpenAI text completion model and write the result to a file.

```
aibuild generate-to-file <file> <prompt> [model] [temperature]
```

#### File

The `file` parameter is the path to the file where you want the generated text to be saved.

#### Prompt

The `prompt` parameter is the text that you want the model to complete. This can be a single word or a complete sentence.

#### Model

The `model` parameter is the name of the model that you want to use. The default model is `text-davinci-002`.

#### Temperature

The `temperature` parameter controls how creative the generated text will be. A higher temperature will result in more creative output, while a lower temperature will result in more conservative output. The default temperature is `0.5`.