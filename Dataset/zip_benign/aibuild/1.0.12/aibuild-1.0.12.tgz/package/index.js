#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const commander = require('commander');
const { Configuration, OpenAIApi } = require('openai');


const globalNodeModulesPath = execSync('npm root -g').toString().trim();
const API_KEY_FILE = path.join(globalNodeModulesPath, 'aibuild/.openai-api-key');;

const setAPIKey = (key) => {
  fs.writeFileSync(API_KEY_FILE, key);
  console.log(`API key set to ${key}`);
};

const checkAPIKey = async () => {
  if (fs.readFileSync(API_KEY_FILE) == 'EMPTY') {
    console.error('No API key set. Use the `key` command to set your API key.');
    return;
  }

  const apiKey = fs.readFileSync(API_KEY_FILE, 'utf8');
  const configuration = new Configuration({ apiKey });
  const openai = new OpenAIApi(configuration);

  try {
    await openai.listModels();
    console.log('API key is valid');
  } catch (error) {
    console.error('Error: Invalid API key', error);
  }
};

const generateText = async (prompt, model, temperature) => {
  if (fs.readFileSync(API_KEY_FILE) == 'EMPTY') {
    console.error('No API key set. Use the `key` command to set your API key.');
    return;
  }

  const apiKey = fs.readFileSync(API_KEY_FILE, 'utf8');
  const configuration = new Configuration({ apiKey });
  const openai = new OpenAIApi(configuration);

  try {
    const response = await openai.createCompletion({
      model,
      prompt,
      temperature,
      max_tokens: 2048,
      top_p: 1,
      frequency_penalty: 0,
      presence_penalty: 0,
    });
    console.log(response.data.choices[0].text);
  } catch (error) {
    console.error('An error occurred while generating text:', error);
  }
};

const generateTextFromFile = async (file, model, temperature) => {
  if (fs.readFileSync(API_KEY_FILE) == 'EMPTY') {
    console.error('No API key set. Use the `key` command to set your API key.');
    return;
  }

  const apiKey = fs.readFileSync(API_KEY_FILE, 'utf8');
  const configuration = new Configuration({ apiKey });
  const openai = new OpenAIApi(configuration);

  try {
    const prompt = fs.readFileSync(file, 'utf8');
    const response = await openai.createCompletion({
      model,
      prompt,
      temperature,
      max_tokens: 2048,
      top_p: 1,
      frequency_penalty: 0,
      presence_penalty: 0,
    });

    console.log(response.data.choices[0].text);
  } catch (error) {
    console.error('An error occurred while generating text:', error.message);
  }
};

const generateFileFromText = async (file, prompt, model, temperature) => {
  if (fs.readFileSync(API_KEY_FILE) == 'EMPTY') {
    console.error('No API key set. Use the `key` command to set your API key.');
    return;
  }

  const apiKey = fs.readFileSync(API_KEY_FILE, 'utf8');
  const configuration = new Configuration({ apiKey });
  const openai = new OpenAIApi(configuration);

  try {
    const response = await openai.createCompletion({
      model,
      prompt,
      temperature,
      max_tokens: 2048,
      top_p: 1,
      frequency_penalty: 0,
      presence_penalty: 0,
    });

    console.log(response)

    fs.writeFileSync(file, response.data.choices[0].text);
    console.log(`Text generated and saved to ${file}`);
  } catch (error) {
    console.error('An error occurred while generating text:', error.message);
  }

};

commander
  .command('key <key>')
  .description('Set the OpenAI API key')
  .action((key) => setAPIKey(key));

commander
  .command('check-key')
  .description('Check if the API key is valid')
  .action(() => checkAPIKey());

commander
  .command('generate <prompt> [model] [temperature]')
  .description('Generate text using the OpenAI text completion model')
  .action((prompt, model = 'text-davinci-002', temperature = 0.5) => generateText(prompt, model, temperature));

commander
  .command('generate-from-file <file> [model] [temperature]')
  .description('Generate text using the OpenAI text completion model, using the contents of a file as the prompt')
  .action((file, model = 'text-davinci-002', temperature = 0.5) => generateTextFromFile(file, model, temperature));

commander
  .command('generate-to-file <file> <prompt> [model] [temperature]')
  .description('Generate text using the OpenAI text completion model and write the result to a file')
  .action(async (file, prompt, model = 'text-davinci-002', temperature = 0.5) => generateFileFromText(file, prompt, model, temperature));

commander.parse(process.argv);