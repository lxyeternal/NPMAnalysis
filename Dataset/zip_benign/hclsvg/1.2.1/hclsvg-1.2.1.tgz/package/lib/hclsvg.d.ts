export declare class Hclsvg {
    tag: any;
    proceed: boolean;
    canvas: {
        width: number;
        height: number;
    };
    mouseX: number;
    mouseY: number;
    mousePos: {
        x: number;
        y: number;
    };
    mousePosOld: {
        x: number;
        y: number;
    };
    selectedElement: {
        id: any;
        tag: any;
        dragstart: any;
        ondrag: any;
        dragend: any;
        onclick: any;
    };
    draggables: any[];
    clickables: any[];
    lastId: number;
    imgLoading: number;
    constructor(id: any);
    onMouseMove(e: any): void;
    onMouseDown(e: any): void;
    onMouseUp(e: any): void;
    onClick(e: any): void;
    makeDraggable(element?: any, params?: any): void;
    disableDraggable(element?: any): void;
    makeClickable(element?: any, params?: any): void;
    disableClickable(element?: any): void;
    setCommon(item: any, params: any): any;
    setCanvasSize(size: any): void;
    rect(params?: any): SVGRectElement;
    circle(params?: any): SVGCircleElement;
    line(params?: any): SVGLineElement;
    polarToCartesian(centerX: number, centerY: number, radius: number, angleInDegrees: number): {
        x: number;
        y: number;
    };
    arc(params?: any): SVGPathElement;
    text(params?: any): SVGTextElement;
    polyline(params?: any): SVGPolylineElement;
    polygon(params?: any): SVGPolygonElement;
    path(params?: any): SVGPathElement;
    image(params?: any): Promise<{}>;
    remove(element?: any): void;
    rotate(element?: any, params?: any): void;
    translate(element?: any, params?: any): void;
    scale(element?: any, params?: any): void;
    exportPng(): Promise<{}>;
    exportSvg(): string;
}
