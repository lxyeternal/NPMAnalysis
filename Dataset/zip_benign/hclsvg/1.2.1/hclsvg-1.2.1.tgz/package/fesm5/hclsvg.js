import { __values } from 'tslib';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var Hclsvg = /** @class */ (function () {
    function Hclsvg(id) {
        var _this = this;
        this.canvas = {
            width: 0,
            height: 0
        };
        this.mouseX = 0;
        this.mouseY = 0;
        this.mousePos = {
            x: 0,
            y: 0
        };
        this.mousePosOld = {
            x: 0,
            y: 0
        };
        this.selectedElement = {
            id: null,
            tag: null,
            dragstart: null,
            ondrag: null,
            dragend: null,
            onclick: null
        };
        this.draggables = [];
        this.clickables = [];
        this.lastId = 0;
        this.imgLoading = 0;
        this.tag = document.getElementById(id);
        if (!this.tag) {
            console.log('hclsvg error: can not find svg tag named "' + id + '"');
            this.proceed = false;
            return;
        }
        if (this.tag.tagName !== 'svg') {
            console.log('hclsvg error: tag "' + id + '" must be <svg ...></svg>');
            this.proceed = false;
            return;
        }
        this.proceed = true;
        document.body.addEventListener('mousemove', (/**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            _this.onMouseMove(e);
        }));
        document.body.addEventListener('mousedown', (/**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            _this.onMouseDown(e);
        }));
        document.body.addEventListener('mouseup', (/**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            _this.onMouseUp(e);
        }));
        document.body.addEventListener('click', (/**
         * @param {?} e
         * @return {?}
         */
        function (e) {
            _this.onClick(e);
        }));
    }
    /**
     * @param {?} e
     * @return {?}
     */
    Hclsvg.prototype.onMouseMove = /**
     * @param {?} e
     * @return {?}
     */
    function (e) {
        /** @type {?} */
        var bbox = this.tag.getBoundingClientRect();
        this.mousePos = {
            x: e.clientX,
            y: e.clientY
        };
        if ((this.selectedElement.tag && this.selectedElement.tag.style.cursor === 'move') &&
            (e.clientX > bbox.left && e.clientX < bbox.left + bbox.width &&
                e.clientY > bbox.top && e.clientY < bbox.top + bbox.height)) {
            if (this.selectedElement.tag) {
                /** @type {?} */
                var dx = this.mousePos.x - this.mousePosOld.x;
                /** @type {?} */
                var dy = this.mousePos.y - this.mousePosOld.y;
                /** @type {?} */
                var group = this.selectedElement.tag.parentNode;
                /** @type {?} */
                var gx = parseInt(group.getAttribute('x'));
                /** @type {?} */
                var gy = parseInt(group.getAttribute('y'));
                group.setAttribute('x', gx + dx);
                group.setAttribute('y', gy + dy);
            }
            if (this.selectedElement.ondrag) {
                this.selectedElement.ondrag(this.selectedElement.tag.getBoundingClientRect());
            }
        }
        this.mousePosOld = this.mousePos;
    };
    /**
     * @param {?} e
     * @return {?}
     */
    Hclsvg.prototype.onMouseDown = /**
     * @param {?} e
     * @return {?}
     */
    function (e) {
        var e_1, _a;
        this.selectedElement.tag = e.target;
        if (this.selectedElement.tag.style.cursor === 'move') {
            /** @type {?} */
            var id = this.selectedElement.tag.getAttribute('id');
            try {
                for (var _b = __values(this.draggables), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var item = _c.value;
                    if (item.id === id) {
                        this.selectedElement = item;
                        if (this.selectedElement.dragstart) {
                            this.selectedElement.dragstart(this.selectedElement.tag.getBoundingClientRect());
                        }
                        break;
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
        }
    };
    /**
     * @param {?} e
     * @return {?}
     */
    Hclsvg.prototype.onMouseUp = /**
     * @param {?} e
     * @return {?}
     */
    function (e) {
        var e_2, _a;
        this.selectedElement.tag = e.target;
        if (this.selectedElement.tag.style.cursor === 'move') {
            /** @type {?} */
            var id = this.selectedElement.tag.getAttribute('id');
            try {
                for (var _b = __values(this.draggables), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var item = _c.value;
                    if (item.id === id) {
                        this.selectedElement = item;
                        if (this.selectedElement.dragend) {
                            this.selectedElement.dragend(this.selectedElement.tag.getBoundingClientRect());
                        }
                        break;
                    }
                }
            }
            catch (e_2_1) { e_2 = { error: e_2_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_2) throw e_2.error; }
            }
            this.selectedElement = {
                id: null,
                tag: null,
                dragstart: null,
                ondrag: null,
                dragend: null,
                onclick: null
            };
        }
    };
    /**
     * @param {?} e
     * @return {?}
     */
    Hclsvg.prototype.onClick = /**
     * @param {?} e
     * @return {?}
     */
    function (e) {
        var e_3, _a;
        if (this.selectedElement.tag && this.selectedElement.tag.style.cursor === 'pointer') {
            this.selectedElement.tag = e.target;
            /** @type {?} */
            var id = this.selectedElement.tag.getAttribute('id');
            try {
                for (var _b = __values(this.clickables), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var item = _c.value;
                    if (item.id === id) {
                        this.selectedElement = item;
                        if (this.selectedElement.onclick) {
                            this.selectedElement.onclick(this.selectedElement.tag.getBoundingClientRect());
                            this.selectedElement = {
                                id: null,
                                tag: null,
                                dragstart: null,
                                ondrag: null,
                                dragend: null,
                                onclick: null
                            };
                        }
                        break;
                    }
                }
            }
            catch (e_3_1) { e_3 = { error: e_3_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_3) throw e_3.error; }
            }
        }
    };
    /**
     * @param {?=} element
     * @param {?=} params
     * @return {?}
     */
    Hclsvg.prototype.makeDraggable = /**
     * @param {?=} element
     * @param {?=} params
     * @return {?}
     */
    function (element, params) {
        if (!element) {
            console.log('Hclsvg error: you must give an element to make draggable');
            return;
        }
        element.style.cursor = 'move';
        this.draggables.push({
            id: element.getAttribute('id'),
            tag: element,
            dragstart: params && params.dragstart ? params.dragstart : null,
            ondrag: params && params.ondrag ? params.ondrag : null,
            dragend: params && params.dragend ? params.dragend : null
        });
    };
    /**
     * @param {?=} element
     * @return {?}
     */
    Hclsvg.prototype.disableDraggable = /**
     * @param {?=} element
     * @return {?}
     */
    function (element) {
        if (!element) {
            console.log('Hclsvg error: you must give an element to disable draggable');
            return;
        }
        element.style.cursor = 'default';
    };
    /**
     * @param {?=} element
     * @param {?=} params
     * @return {?}
     */
    Hclsvg.prototype.makeClickable = /**
     * @param {?=} element
     * @param {?=} params
     * @return {?}
     */
    function (element, params) {
        if (!element) {
            console.log('Hclsvg error: you must give an element to be cliked');
            return;
        }
        element.style.cursor = 'pointer';
        this.clickables.push({
            id: element.getAttribute('id'),
            tag: element,
            onclick: params && params.onclick ? params.onclick : null
        });
    };
    /**
     * @param {?=} element
     * @return {?}
     */
    Hclsvg.prototype.disableClickable = /**
     * @param {?=} element
     * @return {?}
     */
    function (element) {
        if (!element) {
            console.log('Hclsvg error: you must give an element to disable clickable');
            return;
        }
        element.style.cursor = 'default';
    };
    //========================================================================
    //========================================================================
    /**
     * @param {?} item
     * @param {?} params
     * @return {?}
     */
    Hclsvg.prototype.setCommon = 
    //========================================================================
    /**
     * @param {?} item
     * @param {?} params
     * @return {?}
     */
    function (item, params) {
        item.setAttributeNS(null, 'stroke', params.stroke ? params.stroke.toString() : '#000');
        item.setAttributeNS(null, 'stroke-width', params.strokeWidth ? params.strokeWidth.toString() : '1');
        item.setAttributeNS(null, 'stroke-opacity', params.strokeOpacity ? params.strokeOpacity.toString() : '1');
        item.setAttributeNS(null, 'stroke-linecap', params.strokeLinecap ? params.strokeLinecap.toString() : '');
        item.setAttributeNS(null, 'stroke-dasharray', params.strokeDasharray ? params.strokeDasharray.toString() : '');
        item.setAttributeNS(null, 'transform', params.transform ? params.transform.toString() : '');
        item.setAttributeNS(null, 'fill-opacity', params.fillOpacity ? params.fillOpacity.toString() : params.fill ? 1 : 0);
        return item;
    };
    /**
     * @param {?} size
     * @return {?}
     */
    Hclsvg.prototype.setCanvasSize = /**
     * @param {?} size
     * @return {?}
     */
    function (size) {
        if (this.proceed) {
            this.tag.setAttribute('width', size.width);
            this.tag.setAttribute('height', size.height);
            this.canvas = {
                width: size.width,
                height: size.height
            };
        }
    };
    /**
     * @param {?=} params
     * @return {?}
     */
    Hclsvg.prototype.rect = /**
     * @param {?=} params
     * @return {?}
     */
    function (params) {
        if (this.proceed) {
            params = params ? params : {
                x: 1,
                y: 1,
                width: 50,
                height: 50,
                stroke: 'rgb(0,0,0)',
                strokeWidth: 1,
                strokeOpacity: 1,
                fill: 'none',
                fillOpacity: 0,
                rx: 0,
                ry: 0
            };
            /** @type {?} */
            var group = document.createElementNS('http://www.w3.org/2000/svg', "svg");
            /** @type {?} */
            var item = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
            item.setAttributeNS(null, 'id', '_hclsvg_' + this.lastId.toString());
            this.lastId++;
            item.setAttributeNS(null, 'x', params.x ? params.x.toString() : '0');
            item.setAttributeNS(null, 'y', params.y ? params.y.toString() : '0');
            item.setAttributeNS(null, 'width', params.width ? params.width.toString() : '50');
            item.setAttributeNS(null, 'height', params.height ? params.height.toString() : '50');
            item.setAttributeNS(null, 'fill', params.fill ? params.fill.toString() : 'none');
            item = this.setCommon(item, params);
            group.appendChild(item);
            /** @type {?} */
            var bbox = group.getBBox();
            group.setAttributeNS(null, "x", bbox.x.toString());
            group.setAttributeNS(null, "y", bbox.y.toString());
            this.tag.appendChild(group);
            return item;
        }
    };
    /**
     * @param {?=} params
     * @return {?}
     */
    Hclsvg.prototype.circle = /**
     * @param {?=} params
     * @return {?}
     */
    function (params) {
        if (this.proceed) {
            params = params ? params : {
                cx: 50,
                cy: 50,
                r: 30,
                fill: 'rgb(0,255,0)',
                stroke: 'rgb(255,0,255)',
                strokeWidth: 1
            };
            /** @type {?} */
            var group = document.createElementNS('http://www.w3.org/2000/svg', "svg");
            /** @type {?} */
            var item = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
            item.setAttributeNS(null, 'id', '_hclsvg_' + this.lastId.toString());
            this.lastId++;
            item.setAttributeNS(null, 'cx', params.cx.toString());
            item.setAttributeNS(null, 'cy', params.cy.toString());
            item.setAttributeNS(null, 'r', params.r.toString());
            item.setAttributeNS(null, 'fill', params.fill ? params.fill.toString() : 'none');
            item = this.setCommon(item, params);
            group.appendChild(item);
            /** @type {?} */
            var bbox = group.getBBox();
            group.setAttributeNS(null, "x", bbox.x.toString());
            group.setAttributeNS(null, "y", bbox.y.toString());
            this.tag.appendChild(group);
            return item;
        }
    };
    /**
     * @param {?=} params
     * @return {?}
     */
    Hclsvg.prototype.line = /**
     * @param {?=} params
     * @return {?}
     */
    function (params) {
        if (this.proceed) {
            params = params ? params : {
                x1: 0,
                y1: 0,
                x2: 20,
                y2: 20,
                stroke: 'rgb(255,0,255)',
                strokeWidth: 2
            };
            /** @type {?} */
            var group = document.createElementNS('http://www.w3.org/2000/svg', "svg");
            /** @type {?} */
            var item = document.createElementNS('http://www.w3.org/2000/svg', 'line');
            item.setAttributeNS(null, 'id', '_hclsvg_' + this.lastId.toString());
            this.lastId++;
            item.setAttributeNS(null, 'x1', params.x1 ? params.x1.toString() : '0');
            item.setAttributeNS(null, 'y1', params.y1 ? params.y1.toString() : '0');
            item.setAttributeNS(null, 'x2', params.x2 ? params.x2.toString() : '10');
            item.setAttributeNS(null, 'y2', params.y2 ? params.y2.toString() : '10');
            item = this.setCommon(item, params);
            group.appendChild(item);
            /** @type {?} */
            var bbox = group.getBBox();
            group.setAttributeNS(null, "x", bbox.x.toString());
            group.setAttributeNS(null, "y", bbox.y.toString());
            this.tag.appendChild(group);
            return item;
        }
    };
    /**
     * @param {?} centerX
     * @param {?} centerY
     * @param {?} radius
     * @param {?} angleInDegrees
     * @return {?}
     */
    Hclsvg.prototype.polarToCartesian = /**
     * @param {?} centerX
     * @param {?} centerY
     * @param {?} radius
     * @param {?} angleInDegrees
     * @return {?}
     */
    function (centerX, centerY, radius, angleInDegrees) {
        /** @type {?} */
        var angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;
        return {
            x: centerX + (radius * Math.cos(angleInRadians)),
            y: centerY + (radius * Math.sin(angleInRadians))
        };
    };
    /**
     * @param {?=} params
     * @return {?}
     */
    Hclsvg.prototype.arc = /**
     * @param {?=} params
     * @return {?}
     */
    function (params) {
        if (this.proceed) {
            params = params ? params : {
                cx: 60,
                cy: 60,
                r: 50,
                startAngle: 0,
                endAngle: 180,
                stroke: '#000',
                strokeWidth: 1,
                fill: 'none'
            };
            /** @type {?} */
            var start = this.polarToCartesian(params.cx, params.cy, params.r, params.endAngle);
            /** @type {?} */
            var end = this.polarToCartesian(params.cx, params.cy, params.r, params.startAngle);
            /** @type {?} */
            var largeArcFlag = params.endAngle - params.startAngle <= 180 ? '0' : '1';
            /** @type {?} */
            var d = [
                "M", start.x, start.y,
                "A", params.r, params.r, 0, largeArcFlag, 0, end.x, end.y
            ].join(" ");
            /** @type {?} */
            var group = document.createElementNS('http://www.w3.org/2000/svg', "svg");
            /** @type {?} */
            var item = document.createElementNS('http://www.w3.org/2000/svg', 'path');
            item.setAttributeNS(null, 'd', d);
            item.setAttributeNS(null, 'id', '_hclsvg_' + this.lastId.toString());
            this.lastId++;
            item.setAttributeNS(null, 'fill', params.fill ? params.fill.toString() : 'none');
            item = this.setCommon(item, params);
            group.appendChild(item);
            /** @type {?} */
            var bbox = group.getBBox();
            group.setAttributeNS(null, "x", bbox.x.toString());
            group.setAttributeNS(null, "y", bbox.y.toString());
            this.tag.appendChild(group);
            return item;
        }
    };
    /**
     * @param {?=} params
     * @return {?}
     */
    Hclsvg.prototype.text = /**
     * @param {?=} params
     * @return {?}
     */
    function (params) {
        if (this.proceed) {
            params = params ? params : {
                x: 80,
                y: 80,
                dx: 0,
                dy: 0,
                textAnchor: 'start',
                rotate: 0,
                text: 'Hello World !',
                stroke: 'rgb(255,0,255)',
                strokeWidth: 1,
                strokeOpacity: 1,
                fill: 'rgb(255,200,200)',
                fillOpacity: 1,
                fontSize: 32
            };
            /** @type {?} */
            var group = document.createElementNS('http://www.w3.org/2000/svg', "svg");
            /** @type {?} */
            var item = document.createElementNS('http://www.w3.org/2000/svg', "text");
            //item.style.fontFamily='arial, helvetica'
            item.setAttributeNS(null, 'id', '_hclsvg_' + this.lastId.toString());
            this.lastId++;
            item.setAttributeNS(null, "x", params.x ? params.x.toString() : '0');
            item.setAttributeNS(null, "y", params.y ? params.y.toString() : '0');
            item.setAttributeNS(null, "dx", params.dx ? params.dx.toString() : '0');
            item.setAttributeNS(null, "dy", params.dy ? params.dy.toString() : '0');
            item.setAttributeNS(null, "rotate", params.rotate ? params.rotate.toString() : '0');
            item.setAttributeNS(null, "text-anchor", params.textAnchor ? params.textAnchor.toString() : 'start');
            item.setAttributeNS(null, "font-size", params.fontSize ? params.fontSize.toString() : '16');
            item.setAttributeNS(null, "font-family", params.fontFamily ? params.fontFamily.toString() : 'arial,helvetica');
            item.setAttributeNS(null, 'fill', params.fill ? params.fill.toString() : '#000');
            item = this.setCommon(item, params);
            /** @type {?} */
            var textNode = document.createTextNode(params.text ? params.text : '');
            item.appendChild(textNode);
            group.appendChild(item);
            /** @type {?} */
            var bbox = group.getBBox();
            group.setAttributeNS(null, "x", bbox.x.toString());
            group.setAttributeNS(null, "y", bbox.y.toString());
            this.tag.appendChild(group);
            return item;
        }
    };
    /**
     * @param {?=} params
     * @return {?}
     */
    Hclsvg.prototype.polyline = /**
     * @param {?=} params
     * @return {?}
     */
    function (params) {
        var e_4, _a;
        if (this.proceed) {
            params = params ? params : {
                points: [[0, 0], [100, 100], [50, 75]],
                stroke: '#000',
                strokeWidth: 1,
                fill: 'none'
            };
            /** @type {?} */
            var str = '';
            try {
                for (var _b = __values(params.points), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var point = _c.value;
                    str += point[0] + ',' + point[1] + ' ';
                }
            }
            catch (e_4_1) { e_4 = { error: e_4_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_4) throw e_4.error; }
            }
            /** @type {?} */
            var group = document.createElementNS('http://www.w3.org/2000/svg', "svg");
            /** @type {?} */
            var item = document.createElementNS('http://www.w3.org/2000/svg', "polyline");
            item.setAttributeNS(null, 'id', '_hclsvg_' + this.lastId.toString());
            this.lastId++;
            item.setAttributeNS(null, "points", str);
            item.setAttributeNS(null, 'fill', params.fill ? params.fill.toString() : 'none');
            item = this.setCommon(item, params);
            group.appendChild(item);
            /** @type {?} */
            var bbox = group.getBBox();
            group.setAttributeNS(null, "x", bbox.x.toString());
            group.setAttributeNS(null, "y", bbox.y.toString());
            this.tag.appendChild(group);
            return item;
        }
    };
    /**
     * @param {?=} params
     * @return {?}
     */
    Hclsvg.prototype.polygon = /**
     * @param {?=} params
     * @return {?}
     */
    function (params) {
        var e_5, _a;
        if (this.proceed) {
            params = params ? params : {
                points: [[0, 0], [100, 100], [50, 75]],
                stroke: '#000',
                strokeWidth: 1,
                fill: 'none'
            };
            /** @type {?} */
            var str = '';
            try {
                for (var _b = __values(params.points), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var point = _c.value;
                    str += point[0] + ',' + point[1] + ' ';
                }
            }
            catch (e_5_1) { e_5 = { error: e_5_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_5) throw e_5.error; }
            }
            /** @type {?} */
            var group = document.createElementNS('http://www.w3.org/2000/svg', "svg");
            /** @type {?} */
            var item = document.createElementNS('http://www.w3.org/2000/svg', "polygon");
            item.setAttributeNS(null, 'id', '_hclsvg_' + this.lastId.toString());
            this.lastId++;
            item.setAttributeNS(null, "points", str);
            item.setAttributeNS(null, 'fill', params.fill ? params.fill.toString() : 'none');
            item = this.setCommon(item, params);
            group.appendChild(item);
            /** @type {?} */
            var bbox = group.getBBox();
            group.setAttributeNS(null, "x", bbox.x.toString());
            group.setAttributeNS(null, "y", bbox.y.toString());
            this.tag.appendChild(group);
            return item;
        }
    };
    /**
     * @param {?=} params
     * @return {?}
     */
    Hclsvg.prototype.path = /**
     * @param {?=} params
     * @return {?}
     */
    function (params) {
        if (this.proceed) {
            /** @type {?} */
            var group = document.createElementNS('http://www.w3.org/2000/svg', "svg");
            /** @type {?} */
            var item = document.createElementNS('http://www.w3.org/2000/svg', "path");
            item.setAttributeNS(null, 'id', '_hclsvg_' + this.lastId.toString());
            this.lastId++;
            item.setAttributeNS(null, "d", params.path ? params.path : '');
            item.setAttributeNS(null, 'fill', params.fill ? params.fill.toString() : 'none');
            item = this.setCommon(item, params);
            group.appendChild(item);
            /** @type {?} */
            var bbox = group.getBBox();
            group.setAttributeNS(null, "x", bbox.x.toString());
            group.setAttributeNS(null, "y", bbox.y.toString());
            this.tag.appendChild(group);
            return item;
        }
    };
    /**
     * @param {?=} params
     * @return {?}
     */
    Hclsvg.prototype.image = /**
     * @param {?=} params
     * @return {?}
     */
    function (params) {
        var _this = this;
        if (this.proceed) {
            this.imgLoading++;
            return new Promise((/**
             * @param {?} resolve
             * @return {?}
             */
            function (resolve) {
                /** @type {?} */
                var group = document.createElementNS('http://www.w3.org/2000/svg', "svg");
                /** @type {?} */
                var item = document.createElementNS('http://www.w3.org/2000/svg', "image");
                item.setAttributeNS(null, 'id', '_hclsvg_' + _this.lastId.toString());
                _this.lastId++;
                item.setAttributeNS("http://www.w3.org/1999/xlink", "href", params.src ? params.src : '');
                item.setAttributeNS(null, 'x', params.x ? params.x.toString() : '0');
                item.setAttributeNS(null, 'y', params.y ? params.y.toString() : '0');
                item.setAttributeNS(null, 'width', params.width ? params.width.toString() : '0');
                item.setAttributeNS(null, 'height', params.height ? params.height.toString() : '0');
                //===========================================================================
                /** @type {?} */
                var canvas = document.createElement("canvas");
                /** @type {?} */
                var ctx = canvas.getContext("2d");
                ctx.canvas.width = parseInt(_this.tag.getAttribute('width'));
                ctx.canvas.height = parseInt(_this.tag.getAttribute('height'));
                /** @type {?} */
                var svgString = new XMLSerializer().serializeToString(item);
                /** @type {?} */
                var svg = new Blob([svgString], { type: "image/svg+xml;charset=utf-8" });
                /** @type {?} */
                var url = self.URL.createObjectURL(svg);
                /** @type {?} */
                var img = new Image();
                img.crossOrigin = 'anonymous';
                img.src = item.getAttribute('href');
                img.onload = (/**
                 * @return {?}
                 */
                function () {
                    ctx.drawImage(img, 0, 0);
                    /** @type {?} */
                    var png = canvas.toDataURL("image/png");
                    item.setAttributeNS("http://www.w3.org/1999/xlink", "href", png);
                    group.appendChild(item);
                    /** @type {?} */
                    var bbox = group.getBBox();
                    group.setAttributeNS(null, "x", bbox.x.toString());
                    group.setAttributeNS(null, "y", bbox.y.toString());
                    _this.tag.appendChild(group);
                    _this.imgLoading--;
                    resolve(item);
                });
                img.onerror = (/**
                 * @return {?}
                 */
                function () {
                    _this.imgLoading--;
                });
            }));
        }
    };
    //================================================
    //================================================
    /**
     * @param {?=} element
     * @return {?}
     */
    Hclsvg.prototype.remove = 
    //================================================
    /**
     * @param {?=} element
     * @return {?}
     */
    function (element) {
        if (!element) {
            console.log('Hclsvg error: you must give an element to remove');
            return;
        }
        this.tag.removeChild(element.parentNode);
    };
    /**
     * @param {?=} element
     * @param {?=} params
     * @return {?}
     */
    Hclsvg.prototype.rotate = /**
     * @param {?=} element
     * @param {?=} params
     * @return {?}
     */
    function (element, params) {
        if (!element) {
            console.log('Hclsvg error: you must give an element to rotate');
            return;
        }
        params = params ? params : {
            angle: 0
        };
        /** @type {?} */
        var previousTransform = element.getAttribute('transform') ? element.getAttribute('transform') : '';
        /** @type {?} */
        var cx = 0;
        /** @type {?} */
        var cy = 0;
        if (isNaN(params.cx) || isNaN(params.cy)) {
            /** @type {?} */
            var bbox = element.getBBox();
            cx = bbox.x + bbox.width / 2;
            cy = bbox.y + bbox.height / 2;
        }
        else {
            cx = params.cx;
            cy = params.cy;
        }
        element.setAttributeNS(null, 'transform', previousTransform + ' rotate(' + params.angle + ' ' + cx + ' ' + cy + ')');
    };
    /**
     * @param {?=} element
     * @param {?=} params
     * @return {?}
     */
    Hclsvg.prototype.translate = /**
     * @param {?=} element
     * @param {?=} params
     * @return {?}
     */
    function (element, params) {
        params = params ? params : {
            dx: 0,
            dy: 0
        };
        /** @type {?} */
        var group = element.parentNode;
        /** @type {?} */
        var gx = parseInt(group.getAttribute('x'));
        /** @type {?} */
        var gy = parseInt(group.getAttribute('y'));
        group.setAttribute('x', gx + (params.dx ? params.dx : 0));
        group.setAttribute('y', gy + (params.dy ? params.dy : 0));
    };
    /**
     * @param {?=} element
     * @param {?=} params
     * @return {?}
     */
    Hclsvg.prototype.scale = /**
     * @param {?=} element
     * @param {?=} params
     * @return {?}
     */
    function (element, params) {
        /** @type {?} */
        var previousTransform = element.getAttribute('transform') ? element.getAttribute('transform') : '';
        if (!element) {
            console.log('Hclsvg error: you must give an element to scale');
            return;
        }
        params = params ? params : {
            x: 0,
            y: 0
        };
        /** @type {?} */
        var x = isNaN(params.x) ? 1 : params.x;
        /** @type {?} */
        var y = isNaN(params.y) ? x : params.y;
        /** @type {?} */
        var bbox = element.getBBox();
        /** @type {?} */
        var dx = bbox.x + bbox.width / 2;
        /** @type {?} */
        var dy = bbox.y + bbox.height / 2;
        element.setAttributeNS(null, 'transform', previousTransform + ' scale(' + x + ',' + y + ') translate(' + dx + ',' + dy + ')');
    };
    /**
     * @return {?}
     */
    Hclsvg.prototype.exportPng = /**
     * @return {?}
     */
    function () {
        var _this = this;
        return new Promise((/**
         * @param {?} resolve
         * @return {?}
         */
        function (resolve) {
            if (_this.imgLoading) {
                /** @type {?} */
                var loading_1 = setInterval((/**
                 * @return {?}
                 */
                function () {
                    console.log(_this.imgLoading);
                    if (!_this.imgLoading) {
                        clearInterval(loading_1);
                        /** @type {?} */
                        var canvas_1 = document.createElement("canvas");
                        /** @type {?} */
                        var ctx_1 = canvas_1.getContext("2d");
                        ctx_1.canvas.width = parseInt(_this.tag.getAttribute('width'));
                        ctx_1.canvas.height = parseInt(_this.tag.getAttribute('height'));
                        /** @type {?} */
                        var svgString = new XMLSerializer().serializeToString(_this.tag);
                        /** @type {?} */
                        var svg = new Blob([svgString], { type: "image/svg+xml;charset=utf-8" });
                        /** @type {?} */
                        var url = self.URL.createObjectURL(svg);
                        /** @type {?} */
                        var img = new Image();
                        img.crossOrigin = 'anonymous';
                        img.src = url;
                        img.onload = (/**
                         * @return {?}
                         */
                        function () {
                            ctx_1.drawImage(img, 0, 0);
                            /** @type {?} */
                            var png = canvas_1.toDataURL("image/png");
                            resolve(png);
                        });
                    }
                }), 200);
            }
        }));
    };
    /**
     * @return {?}
     */
    Hclsvg.prototype.exportSvg = /**
     * @return {?}
     */
    function () {
        return new XMLSerializer().serializeToString(this.tag).replace(/_ng[^ ]+/, '');
    };
    return Hclsvg;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { Hclsvg };

//# sourceMappingURL=hclsvg.js.map