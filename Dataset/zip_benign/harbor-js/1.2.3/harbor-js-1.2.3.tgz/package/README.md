# Harbor-js v1

```npm install -S harbor-js```

<br />

## Example setup for index.js (create-react-app)

Harbor wraps your app in [react-redux](https://react-redux.js.org/) Provider.<br />
Pass your [@reduxjs/toolkit](https://redux-toolkit.js.org/) slices as ```reducer```.

```
import React from 'react';
import ReactDOM from 'react-dom';
import reducer from './app/reducer';
import App from './App';

import { Harbor } from 'harbor';

const options = {
    global: {
        "contentSize": [
            {
                "width": 0.9,
                "height": 1
            },
            {
                "width": 0.8,
                "height": 1
            }
        ],
        "maxContentWidth": 1200,
        "bg": "white",
        "fadeInTime": 0.3,
        "loadingTimeout": 10
    },
    theme: {},
    reducer
};

ReactDOM.render(
    <Harbor options={options}>
        <App/>
    </Harbor>,
    document.getElementById('root')
);
```
<br />

## Further setup
```Index.html``` theme color, fonts, description, title<br />
```manifest.json``` name, theme color, bg color
<br />
<br />

## Further exports

### Services

```configService``` getGlobal(), getTheme(), withBreakpoint(value), withTheme(value)<br />
```requestService``` baseUrl, setBaseUrl(url), get(url), post(url, data)<br />
```trackingSerivce``` startProcessTimer(name), stopProcessTimer(name)<br />

### Components

```Page``` width, height, minHeight, bg, fadeInTime, loadingIcon, css<br />
```Image``` width, height, src, srcRatio, targetRatio, awaitLoad, priority, className, css<br />
```Header / Footer``` height, fixed = true, bg, css<br />
```FlyOverBox``` height, maxHeight<br />
```ZoomBox``` auto, doZoom, factor, time<br />

### Hooks

```useI18n```<br />

### Utils

```isObject```<br />
```isEmail```<br />
```deepCompare```<br />
```mergeObjects``` favors first input, concatenates arrays<br />

