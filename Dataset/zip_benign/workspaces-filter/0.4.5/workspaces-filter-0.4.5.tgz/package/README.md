# workspaces-filter

> A companion for filtering monorepo workspaces, by package name or package dir. Useful for running
> scripts on a subset of workspaces. The primary reason is because Bun's "--filter" feature is
> buggy, but it's also useful for other package manger, it also runs shell scripts using the `execa`
> package

## Install

```sh
bun add workspaces-filter
npm install workspaces-filter
```

or use the CLI directly:

```sh
bunx workspaces-filter
npx workspaces-filter
pnpm dlx workspaces-filter

# or install globally
npm install -g workspaces-filter
```

## Usage

```
workspaces-filter/0.4

Usage:
  $ workspaces-filter <pattern> [...command]

Commands:
  <pattern> [...command]  Select by package name or workspace directory

For more info, run any command with the `--help` flag:
  $ workspaces-filter --help

Options:
  --print <mode>                Print the names/folders of selected packages, without running command
  --cwd <dir>                   Current working directory (default: /home/charlike/code/hela)
  --pm, --package-manager <pm>  The package manager to use. Defaults to packageManager from root package.json, or Bun
  -v, --version                 Display version number
  -h, --help                    Display this message

Examples:
workspaces-filter . build   # run in all packages of all workspaces
workspaces-filter _ build   # because the '*' would not work

workspaces-filter '*preset*' build
workspaces-filter '*preset*' add foo-pkg
workspaces-filter '*preset*' add --dev typescript

workspaces-filter './packages/foo' -- echo 'Hello, World!'
workspaces-filter './packages/*preset*' -- pwd

workspaces-filter '*preset*' --print names
workspaces-filter '*preset*' --print json
workspaces-filter '*preset*' --print dirs
```

**NOTE: To run a shell command in selected/filtered packages, use `--` right after the pattern!**

## Examples

```sh
npx workspaces-filter '*preset*' build
pnpm dlx workspaces-filter '*preset*' add foo-pkg
bunx workspaces-filter '*preset*' add --dev typescript
```

It checks if there is a script in package's scripts field (thus runs it with `bun run`, `npm run` or
`pnpm run`), if not runs the package manager command (`bun add`, `npm add`), or a shell command if
`_` or `sh` is provided right after the pattern, like so

```sh
bunx workspaces-filter './packages/foo' -- echo 'Hello, World!' # runs `echo 'Hello, World!'` in the `./packages/foo` workspace
bunx workspaces-filter './packages/*preset*' -- pwd # runs `pwd` in each workspace
```

You can run `pnpm dlx` like so

```sh
pnpx workspaces-filter '*preset*' dlx esmc
```
