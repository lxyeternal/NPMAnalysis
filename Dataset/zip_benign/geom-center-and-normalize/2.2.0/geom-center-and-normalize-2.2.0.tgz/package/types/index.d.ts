export default centerAndNormalize;
declare function centerAndNormalize(positions: any, { center, normalize, normalizedSize }?: {
    center?: boolean;
    normalize?: boolean;
    normalizedSize?: number;
}): any;
