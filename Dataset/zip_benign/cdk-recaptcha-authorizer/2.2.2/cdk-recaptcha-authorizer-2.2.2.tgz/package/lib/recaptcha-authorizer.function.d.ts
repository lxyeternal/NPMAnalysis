import { APIGatewayAuthorizerResult, APIGatewayRequestAuthorizerEvent } from 'aws-lambda';
export declare const resetSecret: () => void;
/**
 * Lambda authorizer handler
 * @param {APIGatewayRequestAuthorizerEvent} event - API Gateway Lambda Proxy Input Format
 * @returns {APIGatewayAuthorizerResult} API Gateway Lambda Proxy Output Format
 */
export declare const handler: (event: APIGatewayRequestAuthorizerEvent) => Promise<APIGatewayAuthorizerResult>;
