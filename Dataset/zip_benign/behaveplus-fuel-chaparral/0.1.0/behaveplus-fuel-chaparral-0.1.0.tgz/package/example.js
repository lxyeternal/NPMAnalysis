const chaparral = require('./behaveplus-fuel-chaparral');

/**
 * Invokes all the behaveplus-fuel-chaparral methods
 * for a single set of inputs.
 * @param {*} depth
 * @param {*} deadFraction
 * @param {*} type
 * @param {*} dead1hMois
 * @param {*} dead10hMois
 * @param {*} dead100hMois
 * @param {*} liveHerbMois
 * @param {*} liveStemMois
 */
function runOnce(depth,
  deadFraction,
  type,
  dead1hMois,
  dead10hMois,
  dead100hMois,
  liveHerbMois,
  liveStemMois) {
  const age = chaparral.age(depth, type);
  const totalLoad = chaparral.load(age, type);

  /* eslint-disable no-unused-vars */
  const domain = chaparral.domain();
  const estDfAvereage = chaparral.dead.fraction.averageMortality(age);
  const estDfSevere = chaparral.dead.fraction.severeMortality(age);
  const estDepth = chaparral.fuelDepth(age, type);
  const fuelTypes = chaparral.fuelTypes();

  const deadLoad = chaparral.dead.load(totalLoad, deadFraction);
  const deadMext = chaparral.dead.extinctionMoisture();
  const liveLoad = chaparral.live.load(totalLoad, deadFraction);
  /* eslint-enable no-unused-vars */

  for (const particle of chaparral.deadParticles()) {
    chaparral.dead[particle].density();
    chaparral.dead[particle].heat();
    chaparral.dead[particle].label();
    chaparral.dead[particle].load(totalLoad, deadFraction);
    chaparral.dead[particle].moisture(dead1hMois, dead10hMois, dead100hMois);
    chaparral.dead[particle].savr();
    chaparral.dead[particle].effectiveMineral();
  }

  for (const particle of chaparral.liveParticles()) {
    chaparral.live[particle].density();
    chaparral.live[particle].heat();
    chaparral.live[particle].label();
    chaparral.live[particle].load(totalLoad, deadFraction);
    chaparral.live[particle].moisture(liveHerbMois, liveStemMois);
    chaparral.live[particle].savr();
    chaparral.live[particle].effectiveMineral();
    chaparral.live[particle].totalMineral();
  }
}

/**
 * Makes a lot of behaveplus-fuel-chaparral runs for timing purposes.
 */
function runBatch() {
  let count = 0;
  for (let depth = 0.01; depth <= 10.0; depth += 0.1) {
    for (let deadFraction = 0.0; deadFraction <= 1.0; deadFraction += 0.1) {
      for (const type of chaparral.fuelTypes()) {
        for (let dead1h = 0.05; dead1h <= 0.20; dead1h += 0.05) {
          for (let dead10h = 0.05; dead10h <= 0.10; dead10h += 0.05) {
            for (let dead100h = 0.05; dead100h <= 0.10; dead100h += 0.05) {
              for (let liveHerb = 1.0; liveHerb <= 1.5; liveHerb += 0.5) {
                for (let liveStem = 1.0; liveStem <= 1.50; liveStem += 0.5) {
                  count += 1;
                  runOnce(depth, deadFraction, type,
                    dead1h, dead10h, dead100h, liveHerb, liveStem);
                }
              }
            }
          }
        }
      }
    }
  }
  /* eslint-enable no-restricted-syntax */
  return count;
}

/* eslint-disable no-console */
let t0 = Date.now();
chaparral.enableParameterValidation();
let count = runBatch();
const ms1 = Date.now() - t0;
console.log(`Elapsed time for ${count} iterations`);
console.log(`WITHOUT Parameter Validation: ${ms1}`);

t0 = Date.now();
chaparral.disableParameterValidation();
count = runBatch();
const ms2 = Date.now() - t0;
console.log(`WITHOUT Parameter Validation: ${ms2}`);
const factor = (ms1 / ms2).toPrecision(4);
console.log(`Factor: ${factor}`);
