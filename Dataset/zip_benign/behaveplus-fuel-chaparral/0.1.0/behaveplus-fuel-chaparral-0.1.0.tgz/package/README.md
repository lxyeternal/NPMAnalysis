# behaveplus-fuel-chaparral

The `behaveplus-fuel-chaparral` package implements the dynamic chaparral fuel models described by Rothermel and Philpot (1973) as modified by Cohen (FIRECAST) and applied in BehavePlus Version 6.


## Background

In 1973 Richard .C. Rothermel and  Charles W. Philpot published <i>Predicting Changes in Chaparral Flammability</i> (Journal of Fotestry, Oct 1973, p640-643).

Rothermel had just published his seminal paper <i>A Mathematical Model for Predicting Fire Spread in Wildland Fuels</i> (USDA Forest Service, Research Paper INT-115, 1972, 40 p.), which would become the foundation of the U.S. National Fire Danger Rating System, the BEHAVE and BehavePlus software applications, and wildland fire modeling, prediction, and planning in general across the U.S.

Rothermel and Philpot demonstrated use of the fire spread model in evaluating fire spread rates in chaparral of varying age, height, fuel load, and seasonal moisture content.  Their original approach was to use the age of the chaparral (years since last burn) to estimate fuel load, fuel depth, and dead fuel fraction.  These in turn were used to estimate dead and live fuel load by size class.

Jack Cohen subsequently implemented the dynamic fuel model equations in his FORTRAN program `FIRECAST`, making a few changes in the age-fuel relationships for better behavior.

BehavePlus V6 introduced the 'Chaparral Special Case Fuel Model' option, which requires fuel depth, fuel type ('chamise' or 'mixed brush'), and dead fuel fraction as inputs.  Fuel depth and type are used to derive a proxy age estimate from which a total fuel load is estimated.  Optionally, the user may enter the total fuel load as an input, eliminating the proxy age estimate.

Rothermel and Philpot (1973) identify 9 chaparral fuel particle types:

  - dead 0 to 0.25 inch diameter stem wood,
  - dead 0.25 to 0.5 inch diameter stem wood,
  - dead 0.5 to 1 inch diameter stem wood,
  - dead 1 to 3 inch diameter stem wood,
  - live 0 to 0.25 inch diameter stem wood,
  - live 0.25 to 0.5 inch diameter stem wood,
  - live 0.5 to 1 inch diameter stem wood,
  - live 1 to 3 inch diameter stem wood,
  - live leaves

The BehavePlus fire model requires 8 properties of each `fuel particle`:
  - wood density (lb/ft3),
  - low heat of combustion (BTU/lb),
  - brief descriptive label (string)
  - load (lb/ft2),
  - moisture content (ratio of water weight to oven-dry fuel weight)
  - surface area-to-volume ratio (ft2/ft3),
  - effective (silice-free) mineral content (fraction),
  - total mineral content (fraction).

Furthermore, the fire model requires the following `fuel bed` properties:
  - fuel bed depth (ft),
  - dead fuel extinction moisture content (ratio).

## API

This package provides methods for estimating all the chaparral fuel parameters required to perform `BehavePlus V6` fuel modeling and fire behavior prediction.

Note that all methods are pure functions; they take zero or more simple primitive types as arguments and return a single, primitive type as a result.

The `BehavePlus V6` convention is to require the fuel depth (ft), dead fuel fraction, and fuel type ('chamise' or 'mixed') as inputs, and to either
  - input total fuel load (lb/ft2), or
  - estimate total fuel load from the fuel depth and type via the fuel.load() method.

### Processing Methods

  - `disableParameterValidation()` turns on API parameter validation

  - `enableParameterValidation()` turns off API parameter validation

### Fuel Bed Methods

The following methods return properties applicable to the entire fuel bed:

  - `age(depth, type)` returns estimated age (years since last burned)

  - `domain()` returns the fuel model domain string 'chaparral`

  - `fuelDepth(age, type)` returns estimated chaparral fuel depth (ft)  (provided only as a reference to Rothermel and Philpot, and is not used by BehavePlus V6)

  - `fuelTypes()` - returns an array of the valid chaparral fuel types ('chamise' and 'mixed'), used primarily for iteration purposes

  - `lifeCategories()` returns an array of the 2 valid chaparral fuel types ('dead' and 'live'), used primarily for iteration purposes

  - `load(age, type)` returns the total fuel bed load (lb/ft2)

### Dead Fuel

The following methods return properties applicable to the dead portion of the fuel bed:

  - `dead.extinctionMoisture()` returns dead fuel extinction moisture content (0.3)

  - `dead.fraction.averageMortality(age)` returns dead fuel fraction under average mortality conditions (provided only as a reference to Rothermel and Philpot, and is not used by BehavePlus V6)

  - `dead.fraction.severeMortality(age)` returns dead fuel fraction under severe mortality conditions (provided only as a reference to Rothermel and Philpot, and is not used by BehavePlus V6)

  - `dead.load(totalFuelLoad, deadFuelFraction)` returns dead fuel load (lb/ft2)

  - `dead.particles()` returns an array of the 4 dead fuel particle keys ('particle1'...'particle4'), used primarily for iteration purposes

### Dead Fuel Particles

The following methods return properties applicable to an individual dead fuel particle.  A complete set of methods exist for each of the 4 chaparral dead fuel particles:

  - `particle1` is the dead fine (0 to 0.25 inch diameter) stem wood,
  - `particle2` is the dead small (0.25 to 0.5 inch diameter) stem wood,
  - `particle3` is the dead medium (0.5 to 1 inch diameter) stem wood, and
  - `particle4` is the dead large (1 to 3 inch diameter) stem wood.

(for brevity, only the `particle1` methods are listed below):

  - `dead.particle1.density()` returns the particle density (lb/ft3)

  - `dead.particle1.heat()` returns the heat of combustion (BTU/lb)

  - `dead.particle1.label()` returns a brief fuel particle label (string),

  - `dead.particle1.load(totalFuelLoad, deadFuelFraction)` returns the fuel load (lb/ft2)

  - `dead.particle1.moisture(dead1h, dead10h, dead100h)` returns the moisture content (ratio)

  - `dead.particle1.savr()` returns the surface area-to-volume ratio (ft2/ft3)

  - `dead.particle1.effectiveMineral()` returns the effective (silica-free) mineral content (fraction)

  - `dead.particle1.totalMineral()` returns the total mineral content (fraction)

### Live Fuel

The following methods return properties applicable to the live portion of the fuel bed:

  - `live.load(totalFuelLoad, deadFuelFraction)` returns live fuel load (lb/ft2)

  - `live.particles()` returns an array of the 5 live fuel particle keys ('particle1'...'particle5'), used primarily for iteration purposes

### Live Fuel Particles

The following methods return properties applicable to an individual live fuel particle.  A complete set of methods exist for each of the 5 chaparral live fuel particles:

  - `particle1` is the live fine (0 to 0.25 inch diameter) stem wood,
  - `particle2` is the live small (0.25 to 0.5 inch diameter) stem wood,
  - `particle3` is the live medium (0.5 to 1 inch diameter) stem wood,
  - `particle4` is the live large (1 to 3 inch diameter) stem wood, and
  - `particle5` is the live leaf component.

(for brevity, only the `particle1` methods are listed below):

  - `live.particle1.density()` returns the particle density (lb/ft3)

  - `live.particle1.heat()` returns the heat of combustion (BTU/lb)

  - `live.particle1.label()` returns a brief fuel particle label (string)

  - `live.particle1.load(totalFuelLoad, deadFuelFraction)` returns the fuel load (lb/ft2)

  - `live.particle1.moisture(liveHerbMois, liveStemWoodMois)` returns the moisture content (ratio)

  - `dead.particle1.savr()` returns the surface area-to-volume ratio (ft2/ft3)

  - `dead.particle1.effectiveMineral()` returns the effective (silica-free) mineral content (fraction)

  - `dead.particle1.totalMineral()` returns the total mineral content (fraction)

It is worth noting that the only fuel particle methods that do NOT return a constant value are the load() and mois() methods.

# Example

```js
const chaparral = require('behaveplus-fuel-chaparral')

// Inputs
const depth = 6;
const deadFraction = 0.5;
const type = 'chamise'

// Either input total load or estimate it
const age = chaparral.age(depth, type);
const totalLoad = chaparral.load(age, type);

const deadload = chaparral.dead.load(totalLoad, deadFraction);
const dead1Load = chaparral.dead.particle1.load(totalLoad, deadFraction);
const dead1Mois = chaparral.dead.particle1.moisture(0.05, 0.07, 0.09);
```

# Installation

```
npm install behaveplus-fuel-chaparral@latest
```

