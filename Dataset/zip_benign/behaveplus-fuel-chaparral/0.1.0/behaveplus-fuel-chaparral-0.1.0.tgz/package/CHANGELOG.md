# behaveplus-fuel-chaparral

The `behaveplus-fuel-chaparral` package implements the dynamic chaparral fuel models described by Rothermel and Philpot (1973) as modified by Cohen (FIRECAST) and applied in BehavePlus Version 6.

## 0.1.0 (February 2019)
- Initial README.md
- Initial API
- Initial tests.js
