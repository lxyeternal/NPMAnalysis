const test = require('tape');
const lib = require('./behaveplus-fuel-chaparral');

// Disable these because we are testing!
/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
/* eslint-disable no-restricted-syntax */
/* eslint-disable no-loop-func */

test('behaveplus-fuel-chaparral.disableParameterValidation()', (assert) => {
  lib.disableParameterValidation();
  assert.true(lib.validateParms === false, 'Parameter validation should be false');
  assert.end();
});

test('behaveplus-fuel-chaparral.disableParameterValidation()', (assert) => {
  lib.enableParameterValidation();
  assert.true(lib.validateParms === true, 'Parameter validation should be true');
  assert.end();
});

test('behaveplus-fuel-chaparral.age()', (assert) => {
  lib.enableParameterValidation();
  assert.throws((f) => { lib.age(); }, 'Zero arguments throws an Error');
  assert.throws((f) => { lib.age(1.0); }, 'One argument throws an Error');

  assert.throws((f) => { lib.age(junk, 'chamise'); }, 'Undefined depth value throws an Error');
  assert.throws((f) => { lib.age(null, 'chamise'); }, 'Null depth value throws an Error');
  assert.throws((f) => { lib.age('1.0', 'chamise'); }, 'String depth value throws an Error');
  assert.throws((f) => { lib.age({ value: 1 }, 'chamise'); }, 'Object depth value throws an Error');
  assert.throws((f) => { lib.age(true, 'chamise'); }, 'TRUE depth value throws an Error');
  assert.throws((f) => { lib.age(false, 'chamise'); }, 'FALSE depth value throws an Error');
  assert.throws((f) => { lib.age([1, 2], 'chamise'); }, 'Array depth value throws an Error');

  assert.throws((f) => { lib.age(1.0, type); }, 'Undefined type value throws an Error');
  assert.throws((f) => { lib.age(1.0, null); }, 'Null type value throws an Error');
  assert.throws((f) => { lib.age(1.0, 2.0); }, 'Number type value throws an Error');
  assert.throws((f) => { lib.age(1.0, { type: 'chamise' }); }, 'Object type value throws an Error');
  assert.throws((f) => { lib.age(1.0, true); }, 'TRUE type value throws an Error');
  assert.throws((f) => { lib.age(1.0, false); }, 'FALSE type value throws an Error');
  assert.throws((f) => { lib.age(1.0, ['chamise']); }, 'Array type value throws an Error');

  assert.throws((f) => { lib.age(-1.0, 'chamise'); }, 'Negative depth value throws an Error');
  assert.throws((f) => { lib.age(11.0, 'chamise'); }, 'Depth value > 10 throws an Error');
  assert.throws((f) => { lib.age(1.0, 'NOTchamise'); }, 'Invalid type value throws an Error');

  for( let validate of [true, false] ) {
    (validate) ? lib.enableParameterValidation() : lib.disableParameterValidation();
    for (const type of ['chamise', 'mixed']) {
      const factor = (type === 'chamise') ? 7.5 : 10.0;
      for (const depth of [0.1, 1.0, 6.0, 10.0]) {
        const expected = Math.exp(3.912023 * Math.sqrt(depth / factor));
        assert.equals(lib.age(depth, type), expected,
          `'${type}' depth '${depth}' yields age '${expected}'`);
      }
    }
  }
  lib.enableParameterValidation();
  assert.end();
});

test('behaveplus-fuel-chaparral.deadParticles()', (assert) => {
  lib.enableParameterValidation();
  const a = lib.deadParticles();
  assert.true(a.length === 4, 'Should return an array of 4 strings');
  assert.true(a.includes('particle1'), 'Should include \'particle1\'');
  assert.true(a.includes('particle2'), 'Should include \'particle2\'');
  assert.true(a.includes('particle3'), 'Should include \'particle3\'');
  assert.true(a.includes('particle4'), 'Should include \'particle4\'');
  assert.end();
});

test('behaveplus-fuel-chaparral.domain()', (assert) => {
  lib.enableParameterValidation();
  assert.equals(lib.domain(), 'chaparral', 'Should return string \'chaparral\'');
  assert.end();
});

test('behaveplus-fuel-chaparral.fuelDepth()', (assert) => {
  assert.throws((f) => { lib.fuelDepth(); }, 'Zero arguments throws an Error');
  assert.throws((f) => { lib.fuelDepth(1.0); }, 'One argument throws an Error');

  assert.throws((f) => { lib.fuelDepth(junk, 'chamise'); }, 'Undefined age value throws an Error');
  assert.throws((f) => { lib.fuelDepth(null, 'chamise'); }, 'Null age value throws an Error');
  assert.throws((f) => { lib.fuelDepth('1.0', 'chamise'); }, 'String age value throws an Error');
  assert.throws((f) => { lib.fuelDepth({ value: 1 }, 'chamise'); }, 'Object age value throws an Error');
  assert.throws((f) => { lib.fuelDepth(true, 'chamise'); }, 'TRUE age value throws an Error');
  assert.throws((f) => { lib.fuelDepth(false, 'chamise'); }, 'FALSE age value throws an Error');
  assert.throws((f) => { lib.fuelDepth([1, 2], 'chamise'); }, 'Array age value throws an Error');

  assert.throws((f) => { lib.fuelDepth(1.0, type); }, 'Undefined type value throws an Error');
  assert.throws((f) => { lib.fuelDepth(1.0, null); }, 'Null type value throws an Error');
  assert.throws((f) => { lib.fuelDepth(1.0, 2.0); }, 'Number type value throws an Error');
  assert.throws((f) => { lib.fuelDepth(1.0, { type: 'chamise' }); }, 'Object type value throws an Error');
  assert.throws((f) => { lib.fuelDepth(1.0, true); }, 'TRUE type value throws an Error');
  assert.throws((f) => { lib.fuelDepth(1.0, false); }, 'FALSE type value throws an Error');
  assert.throws((f) => { lib.fuelDepth(1.0, ['chamise']); }, 'Array type value throws an Error');

  assert.throws((f) => { lib.fuelDepth(-1.0, 'chamise'); }, 'Negative age value throws an Error');
  assert.throws((f) => { lib.fuelDepth(101.0, 'chamise'); }, 'Age value > 100 throws an Error');
  assert.throws((f) => { lib.fuelDepth(1.0, 'NOTchamise'); }, 'Invalid type value throws an Error');

  for( let validate of [true, false] ) {
    (validate) ? lib.enableParameterValidation() : lib.disableParameterValidation();
    for (const type of ['chamise', 'mixed']) {
      const factor = (type === 'chamise') ? 7.5 : 10.0;
      for (const age of [0.0, 0.01, 0.1, 1, 1.01, 1.1, 25, 50, 100]) {
        const x = Math.log(Math.max(age, 1.1)) / 3.912023;
        const expected = factor * x * x;
        assert.equals(lib.fuelDepth(age, type), expected,
          `'${type}' age '${age}' yields depth '${expected}'`);
      }
    }
  }
  lib.enableParameterValidation();
  assert.end();
});

test('behaveplus-fuel-chaparral.fuelTypes()', (assert) => {
  lib.enableParameterValidation();
  const a = lib.fuelTypes();
  assert.true(a.length === 2, 'Should return an array of 2 strings');
  assert.true(a.includes('chamise'), 'Should include fuel type \'chamise\'');
  assert.true(a.includes('mixed'), 'Should include fuel type \'mixed\'');
  assert.end();
});

test('behaveplus-fuel-chaparral.lifeCategories()', (assert) => {
  lib.enableParameterValidation();
  const a = lib.lifeCategories();
  assert.true(a.length === 2, 'Should return an array of 2 strings');
  assert.true(a.includes('dead'), 'Should include life category \'dead\'');
  assert.true(a.includes('live'), 'Should include life category \'live\'');
  assert.end();
});

test('behaveplus-fuel-chaparral.liveParticles()', (assert) => {
  lib.enableParameterValidation();
  const a = lib.liveParticles();
  assert.true(a.length === 5, 'Should return an array of 5 strings');
  assert.true(a.includes('particle1'), 'Should include \'particle1\'');
  assert.true(a.includes('particle2'), 'Should include \'particle2\'');
  assert.true(a.includes('particle3'), 'Should include \'particle3\'');
  assert.true(a.includes('particle4'), 'Should include \'particle4\'');
  assert.true(a.includes('particle5'), 'Should include \'particle5\'');
  assert.end();
});

test('behaveplus-fuel-chaparral.load()', (assert) => {
  lib.enableParameterValidation();
  const method = lib.load;
  assert.throws((f) => { method(); }, 'Zero arguments throws an Error');
  assert.throws((f) => { method(1.0); }, 'One argument throws an Error');

  assert.throws((f) => { method(junk, 'chamise'); }, 'Undefined age value throws an Error');
  assert.throws((f) => { method(null, 'chamise'); }, 'Null age value throws an Error');
  assert.throws((f) => { method('1.0', 'chamise'); }, 'String age value throws an Error');
  assert.throws((f) => { method({ value: 1 }, 'chamise'); }, 'Object age value throws an Error');
  assert.throws((f) => { method(true, 'chamise'); }, 'TRUE age value throws an Error');
  assert.throws((f) => { method(false, 'chamise'); }, 'FALSE age value throws an Error');
  assert.throws((f) => { method([1, 2], 'chamise'); }, 'Array age value throws an Error');

  assert.throws((f) => { method(1.0, type); }, 'Undefined type value throws an Error');
  assert.throws((f) => { method(1.0, null); }, 'Null type value throws an Error');
  assert.throws((f) => { method(1.0, 2.0); }, 'Number type value throws an Error');
  assert.throws((f) => { method(1.0, { type: 'chamise' }); }, 'Object type value throws an Error');
  assert.throws((f) => { method(1.0, true); }, 'TRUE type value throws an Error');
  assert.throws((f) => { method(1.0, false); }, 'FALSE type value throws an Error');
  assert.throws((f) => { method(1.0, ['chamise']); }, 'Array type value throws an Error');

  assert.throws((f) => { method(-1.0, 'chamise'); }, 'Negative age value throws an Error');
  assert.throws((f) => { method(101.0, 'chamise'); }, 'Age value > 100 throws an Error');
  assert.throws((f) => { method(1.0, 'NOTchamise'); }, 'Invalid type value throws an Error');

  for( let validate of [true, false] ) {
    (validate) ? lib.enableParameterValidation() : lib.disableParameterValidation();
    for (const type of ['chamise', 'mixed']) {
      const factor = (type === 'chamise') ? 7.5 : 10.0;
      for (const depth of [0.1, 1.0, 6.0, 10.0]) {
        const age = Math.exp(3.912023 * Math.sqrt(depth / factor));
        const tpa = (type === 'chamise')
          ? age / (1.4459 + 0.0347 * age)
          : age / (0.4849 + 0.0170 * age);
        const expected = tpa * 2000.0 / 43560.0;
        assert.equals(method(age, type), expected,
          `'${type}' depth '${depth}' yields age '${age}' and load '${expected}'`);
      }
    }
  }
  lib.enableParameterValidation();
  assert.end();
});

test('behaveplus-fuel-chaparral.dead.extinctionMoisture()', (assert) => {
  lib.enableParameterValidation();
  assert.equals(lib.dead.extinctionMoisture(), 0.3, 'Dead extinction  moisture is 0.30');
  assert.end();
});

test('behaveplus-fuel-chaparral.dead.fraction.averageMortality()', (assert) => {
  lib.enableParameterValidation();
  const method = lib.dead.fraction.averageMortality;
  assert.throws((f) => { method(); }, 'Zero arguments throws an Error');

  assert.throws((f) => { method(junk); }, 'Undefined age value throws an Error');
  assert.throws((f) => { method(null); }, 'Null age value throws an Error');
  assert.throws((f) => { method('1.0'); }, 'String age value throws an Error');
  assert.throws((f) => { method({ value: 1 }); }, 'Object age value throws an Error');
  assert.throws((f) => { method(true); }, 'TRUE age value throws an Error');
  assert.throws((f) => { method(false); }, 'FALSE age value throws an Error');
  assert.throws((f) => { method([1, 2]); }, 'Array age value throws an Error');

  for( let validate of [true, false] ) {
    (validate) ? lib.enableParameterValidation() : lib.disableParameterValidation();
    for (const age of [0.0, 0.01, 0.1, 1, 1.01, 1.1, 25, 50, 60, 70, 80, 90, 100]) {
      const expected = Math.min(1.0, Math.max(0.0, 0.0694 * Math.exp(0.0402 * age)));
      assert.equals(method(age), expected,
        `Average mortality at age '${age}' is '${expected}'`);
    }
  }
  lib.enableParameterValidation();
  assert.end();
});

test('behaveplus-fuel-chaparral.dead.fraction.severeMortality()', (assert) => {
  lib.enableParameterValidation();
  const method = lib.dead.fraction.severeMortality;
  assert.throws((f) => { method(); }, 'Zero arguments throws an Error');

  assert.throws((f) => { method(junk); }, 'Undefined age value throws an Error');
  assert.throws((f) => { method(null); }, 'Null age value throws an Error');
  assert.throws((f) => { method('1.0'); }, 'String age value throws an Error');
  assert.throws((f) => { method({ value: 1 }); }, 'Object age value throws an Error');
  assert.throws((f) => { method(true); }, 'TRUE age value throws an Error');
  assert.throws((f) => { method(false); }, 'FALSE age value throws an Error');
  assert.throws((f) => { method([1, 2]); }, 'Array age value throws an Error');

  for( let validate of [true, false] ) {
    (validate) ? lib.enableParameterValidation() : lib.disableParameterValidation();
    for (const age of [0.0, 0.01, 0.1, 1, 1.01, 1.1, 25, 50, 60, 70, 80, 90, 100]) {
      const expected = Math.min(1.0, Math.max(0.0, 0.1094 * Math.exp(0.0385 * age)));
      assert.equals(method(age), expected,
        `Severe mortality at age '${age}' is '${expected}'`);
    }
  }
  lib.enableParameterValidation();
  assert.end();
});

test('behaveplus-fuel-chaparral.dead.load()', (assert) => {
  lib.enableParameterValidation();
  const method = lib.dead.load;
  assert.throws((f) => { method(); }, 'Zero arguments throws an Error');
  assert.throws((f) => { method(1.0); }, 'One argument throws an Error');

  assert.throws((f) => { method(junk, 0.5); }, 'Undefined totalFuelLoad value throws an Error');
  assert.throws((f) => { method(null, 0.5); }, 'Null totalFuelLoad value throws an Error');
  assert.throws((f) => { method('1.0', 0.5); }, 'String totalFuelLoad value throws an Error');
  assert.throws((f) => { method({ value: 1 }, 0.5); }, 'Object totalFuelLoad value throws an Error');
  assert.throws((f) => { method(true, 0.5); }, 'TRUE totalFuelLoad value throws an Error');
  assert.throws((f) => { method(false, 0.5); }, 'FALSE totalFuelLoad value throws an Error');
  assert.throws((f) => { method([1, 2], 0.5); }, 'Array totalFuelLoad value throws an Error');

  assert.throws((f) => { method(1.0, type); }, 'Undefined deadFuelFraction value throws an Error');
  assert.throws((f) => { method(1.0, null); }, 'Null deadFuelFraction value throws an Error');
  assert.throws((f) => { method(1.0, '0.5'); }, 'String deadFuelFraction value throws an Error');
  assert.throws((f) => { method(1.0, { type: 'chamise' }); }, 'Object deadFuelFraction value throws an Error');
  assert.throws((f) => { method(1.0, true); }, 'TRUE deadFuelFraction value throws an Error');
  assert.throws((f) => { method(1.0, false); }, 'FALSE deadFuelFraction value throws an Error');
  assert.throws((f) => { method(1.0, [0.5]); }, 'Array deadFuelFraction value throws an Error');

  assert.throws((f) => { method(-1.0, 0.5); }, 'Negative totalFuelLoad value throws an Error');
  assert.throws((f) => { method(5.0, 0.5); }, 'totalFuelLoad > 4 throws an Error');
  assert.throws((f) => { method(1.0, -0.1); }, 'Negative deadFuelFraction value throws an Error');
  assert.throws((f) => { method(1.0, 1.1); }, 'deadFuelFraction value > 1 throws an Error');

  for( let validate of [true, false] ) {
    (validate) ? lib.enableParameterValidation() : lib.disableParameterValidation();
    for (const totalFuelLoad of [0.0, 0.1, 1]) {
      for (const deadFuelFraction of [0, 0.1, 0.5, 0.9, 1]) {
        const expected = totalFuelLoad * deadFuelFraction;
        assert.equals(method(totalFuelLoad, deadFuelFraction), expected,
          `Total fuel load '${totalFuelLoad}' dead fraction '${deadFuelFraction}' yields dead fuel load '${expected}'`);
      }
    }
  }
  lib.enableParameterValidation();
  assert.end();
});

test('behaveplus-fuel-chaparral.dead.particle.load()', (assert) => {
  lib.enableParameterValidation();
  const factor = {
    particle1: 0.347,
    particle2: 0.364,
    particle3: 0.207,
    particle4: 0.082,
  };
  for (const particle of lib.deadParticles()) {
    const method = lib.dead[particle].load;
    assert.throws((f) => { method(); }, `${particle}: Zero arguments throws an Error`);
    assert.throws((f) => { method(1.0); }, `${particle}: One argument throws an Error`);

    assert.throws((f) => { method(junk, 0.5); }, `${particle}: Undefined totalFuelLoad value throws an Error`);
    assert.throws((f) => { method(null, 0.5); }, `${particle}: Null totalFuelLoad value throws an Error`);
    assert.throws((f) => { method('1.0', 0.5); }, `${particle}: String totalFuelLoad value throws an Error`);
    assert.throws((f) => { method({ value: 1 }, 0.5); }, `${particle}: Object totalFuelLoad value throws an Error`);
    assert.throws((f) => { method(true, 0.5); }, `${particle}: TRUE totalFuelLoad value throws an Error`);
    assert.throws((f) => { method(false, 0.5); }, `${particle}: FALSE totalFuelLoad value throws an Error`);
    assert.throws((f) => { method([1, 2], 0.5); }, `${particle}: Array totalFuelLoad value throws an Error`);

    assert.throws((f) => { method(1.0, type); }, `${particle}: Undefined deadFuelFraction value throws an Error`);
    assert.throws((f) => { method(1.0, null); }, `${particle}: Null deadFuelFraction value throws an Error`);
    assert.throws((f) => { method(1.0, '0.5'); }, `${particle}: String deadFuelFraction value throws an Error`);
    assert.throws((f) => { method(1.0, { type: 'chamise' }); }, `${particle}: Object deadFuelFraction value throws an Error`);
    assert.throws((f) => { method(1.0, true); }, `${particle}: TRUE deadFuelFraction value throws an Error`);
    assert.throws((f) => { method(1.0, false); }, `${particle}: FALSE deadFuelFraction value throws an Error`);
    assert.throws((f) => { method(1.0, [0.5]); }, `${particle}: Array deadFuelFraction value throws an Error`);

    assert.throws((f) => { method(-1.0, 0.5); }, `${particle}: Negative totalFuelLoad value throws an Error`);
    assert.throws((f) => { method(5.0, 0.5); }, `${particle}: totalFuelLoad > 4 throws an Error`);
    assert.throws((f) => { method(1.0, -0.1); }, `${particle}: Negative deadFuelFraction value throws an Error`);
    assert.throws((f) => { method(1.0, 1.1); }, `${particle}: deadFuelFraction value > 1 throws an Error`);

    for( let validate of [true, false] ) {
      (validate) ? lib.enableParameterValidation() : lib.disableParameterValidation();
      for (const totalFuelLoad of [0.0, 0.1, 1]) {
        for (const deadFuelFraction of [0, 0.1, 0.5, 0.9, 1]) {
          const expected = totalFuelLoad * factor[particle] * deadFuelFraction;
          assert.equals(method(totalFuelLoad, deadFuelFraction), expected,
            `Total fuel load '${totalFuelLoad}' dead fraction '${deadFuelFraction}' yields dead ${particle} load '${expected}'`);
        }
      }
    }
    lib.enableParameterValidation();
  }
  assert.end();
});

test('behaveplus-fuel-chaparral.dead.particle.moisture()', (assert) => {
  lib.enableParameterValidation();
  const dead1 = 0.05;
  const dead10 = 0.07;
  const dead100 = 0.09;
  const expected = {
    particle1: dead1,
    particle2: dead10,
    particle3: dead10,
    particle4: dead100,
  };
  for (const particle of lib.deadParticles()) {
    const method = lib.dead[particle].moisture;
    assert.throws((f) => { method(); }, `${particle}: Zero arguments throws an Error`);
    assert.throws((f) => { method(dead1); }, `${particle}: One argument throws an Error`);
    assert.throws((f) => { method(dead1, dead10); }, `${particle}: Two arguments throws an Error`);

    assert.throws((f) => { method(junk, dead10, dead100); }, `${particle}: Undefined dead1 value throws an Error`);
    assert.throws((f) => { method(null, dead10, dead100); }, `${particle}: Null dead1 value throws an Error`);
    assert.throws((f) => { method('0.05', dead10, dead100); }, `${particle}: String dead1 value throws an Error`);
    assert.throws((f) => { method({ value: 0.05}, dead10, dead100); }, `${particle}: Object dead1 value throws an Error`);
    assert.throws((f) => { method(true, dead10, dead100); }, `${particle}: TRUE dead1 value throws an Error`);
    assert.throws((f) => { method(false, dead10, dead100); }, `${particle}: FALSE dead1 value throws an Error`);
    assert.throws((f) => { method([1, 2], dead10, dead100); }, `${particle}: Array dead1 value throws an Error`);

    assert.throws((f) => { method(dead1, junk, dead100); }, `${particle}: Undefined dead10 value throws an Error`);
    assert.throws((f) => { method(dead1, null, dead100); }, `${particle}: Null dead10 value throws an Error`);
    assert.throws((f) => { method(dead1, '0.07', dead100); }, `${particle}: String dead10 value throws an Error`);
    assert.throws((f) => { method(dead1, { value: 0.07}, dead100); }, `${particle}: Object dead10 value throws an Error`);
    assert.throws((f) => { method(dead1, true, dead100); }, `${particle}: TRUE dead10 value throws an Error`);
    assert.throws((f) => { method(dead1, false, dead100); }, `${particle}: FALSE dead10 value throws an Error`);
    assert.throws((f) => { method(dead1, [1, 2], dead100); }, `${particle}: Array dead10 value throws an Error`);

    assert.throws((f) => { method(dead1, dead10, junk); }, `${particle}: Undefined dead100 value throws an Error`);
    assert.throws((f) => { method(dead1, dead10, null); }, `${particle}: Null dead100 value throws an Error`);
    assert.throws((f) => { method(dead1, dead10, '0.09'); }, `${particle}: String dead100 value throws an Error`);
    assert.throws((f) => { method(dead1, dead10, { value: 0.09}); }, `${particle}: Object dead100 value throws an Error`);
    assert.throws((f) => { method(dead1, dead10, true); }, `${particle}: TRUE dead100 value throws an Error`);
    assert.throws((f) => { method(dead1, dead10, false); }, `${particle}: FALSE dead100 value throws an Error`);
    assert.throws((f) => { method(dead1, dead10, [1, 2]); }, `${particle}: Array dead100 value throws an Error`);

    assert.throws((f) => { method(0.0, dead10, dead100); }, `${particle}: dead1 value < 0.01 throws an Error`);
    assert.throws((f) => { method(dead1, 0.0, dead100); }, `${particle}: dead10 value < 0.01 throws an Error`);
    assert.throws((f) => { method(dead1, dead10, 0.0); }, `${particle}: dead100 value < 0.01 throws an Error`);
    assert.throws((f) => { method(1.01, dead10, dead100); }, `${particle}: dead1 value > 1.0 throws an Error`);
    assert.throws((f) => { method(dead1, 1.01, dead100); }, `${particle}: dead10 value > 1.0 throws an Error`);
    assert.throws((f) => { method(dead1, dead10, 1.01); }, `${particle}: dead100 value > 1.0 throws an Error`);

    for( let validate of [true, false] ) {
      (validate) ? lib.enableParameterValidation() : lib.disableParameterValidation();
     assert.equals(method(dead1, dead10, dead100), expected[particle],
      `Dead ${particle} moisture content is ${expected[particle]}`);
    }
    lib.enableParameterValidation();
  }
  assert.end();
});

test('behaveplus-fuel-chaparral.live.load()', (assert) => {
  lib.enableParameterValidation();
  const method = lib.live.load;
  assert.throws((f) => { method(); }, 'Zero arguments throws an Error');
  assert.throws((f) => { method(1.0); }, 'One argument throws an Error');

  assert.throws((f) => { method(junk, 0.5); }, 'Undefined totalFuelLoad value throws an Error');
  assert.throws((f) => { method(null, 0.5); }, 'Null totalFuelLoad value throws an Error');
  assert.throws((f) => { method('1.0', 0.5); }, 'String totalFuelLoad value throws an Error');
  assert.throws((f) => { method({ value: 1 }, 0.5); }, 'Object totalFuelLoad value throws an Error');
  assert.throws((f) => { method(true, 0.5); }, 'TRUE totalFuelLoad value throws an Error');
  assert.throws((f) => { method(false, 0.5); }, 'FALSE totalFuelLoad value throws an Error');
  assert.throws((f) => { method([1, 2], 0.5); }, 'Array totalFuelLoad value throws an Error');

  assert.throws((f) => { method(1.0, type); }, 'Undefined deadFuelFraction value throws an Error');
  assert.throws((f) => { method(1.0, null); }, 'Null deadFuelFraction value throws an Error');
  assert.throws((f) => { method(1.0, '0.5'); }, 'String deadFuelFraction value throws an Error');
  assert.throws((f) => { method(1.0, { type: 'chamise' }); }, 'Object deadFuelFraction value throws an Error');
  assert.throws((f) => { method(1.0, true); }, 'TRUE deadFuelFraction value throws an Error');
  assert.throws((f) => { method(1.0, false); }, 'FALSE deadFuelFraction value throws an Error');
  assert.throws((f) => { method(1.0, [0.5]); }, 'Array deadFuelFraction value throws an Error');

  assert.throws((f) => { method(-1.0, 0.5); }, 'Negative totalFuelLoad value throws an Error');
  assert.throws((f) => { method(5.0, 0.5); }, 'totalFuelLoad > 4 throws an Error');
  assert.throws((f) => { method(1.0, -0.1); }, 'Negative deadFuelFraction value throws an Error');
  assert.throws((f) => { method(1.0, 1.1); }, 'deadFuelFraction value > 1 throws an Error');

  for( let validate of [true, false] ) {
    (validate) ? lib.enableParameterValidation() : lib.disableParameterValidation();
    for (const totalFuelLoad of [0.0, 0.1, 1]) {
      for (const deadFuelFraction of [0, 0.1, 0.5, 0.9, 1]) {
        const expected = totalFuelLoad * (1.0 - deadFuelFraction);
        assert.equals(method(totalFuelLoad, deadFuelFraction), expected,
          `Total fuel load '${totalFuelLoad}' dead fraction '${deadFuelFraction}' yields live fuel load '${expected}'`);
      }
    }
  }
  lib.enableParameterValidation();
  assert.end();
});

test('behaveplus-fuel-chaparral.live.particle.load()', (assert) => {
  lib.enableParameterValidation();
  const offset = {
    particle1: 0.2416,
    particle2: 0.1918,
    particle3: 0.2648,
    particle4: 0.1036,
    particle5: 0.1957,
  };
  const factor = {
    particle1: 0.256,
    particle2: 0.256,
    particle3: 0.050,
    particle4: 0.114,
    particle5: 0.305,
  };
  for (const particle of lib.liveParticles()) {
    const method = lib.live[particle].load;
    assert.throws((f) => { method(); }, `${particle}: Zero arguments throws an Error`);
    assert.throws((f) => { method(1.0); }, `${particle}: One argument throws an Error`);

    assert.throws((f) => { method(junk, 0.5); }, `${particle}: Undefined totalFuelLoad value throws an Error`);
    assert.throws((f) => { method(null, 0.5); }, `${particle}: Null totalFuelLoad value throws an Error`);
    assert.throws((f) => { method('1.0', 0.5); }, `${particle}: String totalFuelLoad value throws an Error`);
    assert.throws((f) => { method({ value: 1 }, 0.5); }, `${particle}: Object totalFuelLoad value throws an Error`);
    assert.throws((f) => { method(true, 0.5); }, `${particle}: TRUE totalFuelLoad value throws an Error`);
    assert.throws((f) => { method(false, 0.5); }, `${particle}: FALSE totalFuelLoad value throws an Error`);
    assert.throws((f) => { method([1, 2], 0.5); }, `${particle}: Array totalFuelLoad value throws an Error`);

    assert.throws((f) => { method(1.0, type); }, `${particle}: Undefined deadFuelFraction value throws an Error`);
    assert.throws((f) => { method(1.0, null); }, `${particle}: Null deadFuelFraction value throws an Error`);
    assert.throws((f) => { method(1.0, '0.5'); }, `${particle}: String deadFuelFraction value throws an Error`);
    assert.throws((f) => { method(1.0, { type: 'chamise' }); }, `${particle}: Object deadFuelFraction value throws an Error`);
    assert.throws((f) => { method(1.0, true); }, `${particle}: TRUE deadFuelFraction value throws an Error`);
    assert.throws((f) => { method(1.0, false); }, `${particle}: FALSE deadFuelFraction value throws an Error`);
    assert.throws((f) => { method(1.0, [0.5]); }, `${particle}: Array deadFuelFraction value throws an Error`);

    assert.throws((f) => { method(-1.0, 0.5); }, `${particle}: Negative totalFuelLoad value throws an Error`);
    assert.throws((f) => { method(5.0, 0.5); }, `${particle}: totalFuelLoad > 4 throws an Error`);
    assert.throws((f) => { method(1.0, -0.1); }, `${particle}: Negative deadFuelFraction value throws an Error`);
    assert.throws((f) => { method(1.0, 1.1); }, `${particle}: deadFuelFraction value > 1 throws an Error`);

    for( let validate of [true, false] ) {
      (validate) ? lib.enableParameterValidation() : lib.disableParameterValidation();
      for (const totalFuelLoad of [0.0, 0.1, 1]) {
        for (const deadFuelFraction of [0, 0.1, 0.5, 0.9, 1]) {
          const expected = totalFuelLoad * (offset[particle] - factor[particle] * deadFuelFraction);
          assert.equals(method(totalFuelLoad, deadFuelFraction), expected,
            `Total fuel load '${totalFuelLoad}' dead fraction '${deadFuelFraction}' yields live ${particle} load '${expected}'`);
        }
      }
    }
    lib.enableParameterValidation();
  }
  assert.end();
});

test('behaveplus-fuel-chaparral particle constants', (assert) => {
  lib.enableParameterValidation();
  let particle = lib.dead.particle1;
  let name = 'Dead particle1';
  assert.equals(particle.density(), 46.0, `${name} fuel density is 46. lb/ft3`);
  assert.equals(particle.heat(), 8000.0, `${name} heat is 8000 btu/lb.`);
  assert.equals(particle.label(), 'Dead fine (0 to 0.25 inch diameter) stem wood',
    `${name} label is 'Dead fine (0 to 0.25 inch diameter) stem wood'`);
  assert.equals(particle.savr(), 640.0, `${name} savr is 640 ft2/ft3`);
  assert.equals(particle.effectiveMineral(), 0.015, `${name} seff is 0.015`);
  assert.equals(particle.totalMineral(), 0.055, `${name} total mineral content is 0.055`);

  particle = lib.dead.particle2;
  name = 'Dead particle2';
  assert.equals(particle.density(), 46.0, `${name} fuel density is 46. lb/ft3`);
  assert.equals(particle.heat(), 8000.0, `${name} heat is 8000 btu/lb.`);
  assert.equals(particle.label(), 'Dead small (0.25 to 0.5 inch diameter) stem wood',
    `${name} label is 'Dead small (0.25 to 0.5 inch diameter) stem wood'`);
  assert.equals(particle.savr(), 127.0, `${name} savr is 127 ft2/ft3`);
  assert.equals(particle.effectiveMineral(), 0.015, `${name} seff is 0.015`);
  assert.equals(particle.totalMineral(), 0.055, `${name} total mineral content is 0.055`);

  particle = lib.dead.particle3;
  name = 'Dead particle3';
  assert.equals(particle.density(), 46.0, `${name} fuel density is 46. lb/ft3`);
  assert.equals(particle.heat(), 8000.0, `${name} heat is 8000 btu/lb.`);
  assert.equals(particle.label(), 'Dead medium (0.5 to 1 inch diameter) stem wood',
    `${name} label is 'Dead medium (0.5 to 1 inch diameter) stem wood'`);
  assert.equals(particle.savr(), 61.0, `${name} savr is 61 ft2/ft3`);
  assert.equals(particle.effectiveMineral(), 0.015, `${name} seff is 0.015`);
  assert.equals(particle.totalMineral(), 0.055, `${name} total mineral content is 0.055`);

  particle = lib.dead.particle4;
  name = 'Dead particle4';
  assert.equals(particle.density(), 46.0, `${name} fuel density is 46. lb/ft3`);
  assert.equals(particle.heat(), 8000.0, `${name} heat is 8000 btu/lb.`);
  assert.equals(particle.label(), 'Dead large (1 to 3 inch diameter) stem wood',
    `${name} label is 'Dead large (1 to 3 inch diameter) stem wood'`);
  assert.equals(particle.savr(), 27.0, `${name} savr is 27 ft2/ft3`);
  assert.equals(particle.effectiveMineral(), 0.015, `${name} seff is 0.015`);
  assert.equals(particle.totalMineral(), 0.055, `${name} total mineral content is 0.055`);

  particle = lib.live.particle1;
  name = 'Live particle1';
  assert.equals(particle.density(), 46.0, `${name} fuel density is 46. lb/ft3`);
  assert.equals(particle.heat(), 10500.0, `${name} heat is 10500 btu/lb.`);
  assert.equals(particle.label(), 'Live fine (0 to 0.25 inch diameter) stem wood',
    `${name} label is 'Live fine (0 to 0.25 inch diameter) stem wood'`);
  assert.equals(particle.savr(), 640.0, `${name} savr is 640 ft2/ft3`);
  assert.equals(particle.effectiveMineral(), 0.015, `${name} seff is 0.015`);
  assert.equals(particle.totalMineral(), 0.055, `${name} total mineral content is 0.055`);

  particle = lib.live.particle2;
  name = 'Live particle2';
  assert.equals(particle.density(), 46.0, `${name} fuel density is 46. lb/ft3`);
  assert.equals(particle.heat(), 9550.0, `${name} heat is 9550 btu/lb.`);
  assert.equals(particle.label(), 'Live small (0.25 to 0.5 inch diameter) stem wood',
    `${name} label is 'Live small (0.25 to 0.5 inch diameter) stem wood'`);
  assert.equals(particle.savr(), 127.0, `${name} savr is 127 ft2/ft3`);
  assert.equals(particle.effectiveMineral(), 0.015, `${name} seff is 0.015`);
  assert.equals(particle.totalMineral(), 0.055, `${name} total mineral content is 0.055`);

  particle = lib.live.particle3;
  name = 'Live particle3';
  assert.equals(particle.density(), 46.0, `${name} fuel density is 46. lb/ft3`);
  assert.equals(particle.heat(), 9550.0, `${name} heat is 9550 btu/lb.`);
  assert.equals(particle.label(), 'Live medium (0.5 to 1 inch diameter) stem wood',
    `${name} label is 'Live medium (0.5 to 1 inch diameter) stem wood'`);
  assert.equals(particle.savr(), 61.0, `${name} savr is 61 ft2/ft3`);
  assert.equals(particle.effectiveMineral(), 0.015, `${name} seff is 0.015`);
  assert.equals(particle.totalMineral(), 0.055, `${name} total mineral content is 0.055`);

  particle = lib.live.particle4;
  name = 'Live particle4';
  assert.equals(particle.density(), 46.0, `${name} fuel density is 46. lb/ft3`);
  assert.equals(particle.heat(), 9550.0, `${name} heat is 9550 btu/lb.`);
  assert.equals(particle.label(), 'Live large (1 to 3 inch diameter) stem wood',
    `${name} label is 'Live large (1 to 3 inch diameter) stem wood'`);
  assert.equals(particle.savr(), 27.0, `${name} savr is 27 ft2/ft3`);
  assert.equals(particle.effectiveMineral(), 0.015, `${name} seff is 0.015`);
  assert.equals(particle.totalMineral(), 0.055, `${name} total mineral content is 0.055`);

  particle = lib.live.particle5;
  name = 'Live particle5';
  assert.equals(particle.density(), 32.0, `${name} fuel density is 32. lb/ft3`);
  assert.equals(particle.heat(), 10500.0, `${name} heat is 10500 btu/lb.`);
  assert.equals(particle.label(), 'Live leaves', `${name} label is 'Live leaves'`);
  assert.equals(particle.savr(), 2200.0, `${name} savr is 2200ft2/ft3`);
  assert.equals(particle.effectiveMineral(), 0.035, `${name} seff is 0.035`);
  assert.equals(particle.totalMineral(), 0.055, `${name} total mineral content is 0.055`);
  assert.end();
});

test('behaveplus-fuel-chaparral.live.particle.moisture()', (assert) => {
  lib.enableParameterValidation();
  const herbMc = 0.5;
  const stemMc = 1.0;
  const expected = {
    particle1: stemMc,
    particle2: stemMc,
    particle3: stemMc,
    particle4: stemMc,
    particle5: herbMc,
  };
  for (const particle of lib.liveParticles()) {
    const method = lib.live[particle].moisture;
    assert.throws((f) => { method(); }, `${particle}: Zero arguments throws an Error`);
    assert.throws((f) => { method(herbMc); }, `${particle}: One argument throws an Error`);

    assert.throws((f) => { method(junk, stemMc); }, `${particle}: Undefined herbMc value throws an Error`);
    assert.throws((f) => { method(null, stemMc); }, `${particle}: Null herbMc value throws an Error`);
    assert.throws((f) => { method('1.0', stemMc); }, `${particle}: String herbMc value throws an Error`);
    assert.throws((f) => { method({ value: 0.5}, stemMc); }, `${particle}: Object herbMc value throws an Error`);
    assert.throws((f) => { method(true, stemMc); }, `${particle}: TRUE herbMc value throws an Error`);
    assert.throws((f) => { method(false, stemMc); }, `${particle}: FALSE herbMc value throws an Error`);
    assert.throws((f) => { method([1, 2], stemMc); }, `${particle}: Array herbMc value throws an Error`);

    assert.throws((f) => { method(herbMc, junk); }, `${particle}: Undefined stemMc value throws an Error`);
    assert.throws((f) => { method(herbMc, null); }, `${particle}: Null stemMc value throws an Error`);
    assert.throws((f) => { method(herbMc, '1.0'); }, `${particle}: String stemMc value throws an Error`);
    assert.throws((f) => { method(herbMc, { value: 0.5}); }, `${particle}: Object stemMc value throws an Error`);
    assert.throws((f) => { method(herbMc, true); }, `${particle}: TRUE stemMc value throws an Error`);
    assert.throws((f) => { method(herbMc, false); }, `${particle}: FALSE stemMc value throws an Error`);
    assert.throws((f) => { method(herbMc, [1, 2]); }, `${particle}: Array stemMc value throws an Error`);

    assert.throws((f) => { method(0.0, stemMc); }, `${particle}: herbMc value < 0.01 throws an Error`);
    assert.throws((f) => { method(herbMc, 0.0); }, `${particle}: stemMc value < 0.01 throws an Error`);
    assert.throws((f) => { method(5.1, stemMc); }, `${particle}: herbMc value < 5.0 throws an Error`);
    assert.throws((f) => { method(herbMc, 5.1); }, `${particle}: stemMc value > 5.0 throws an Error`);

    for( let validate of [true, false] ) {
      (validate) ? lib.enableParameterValidation() : lib.disableParameterValidation();
      assert.equals(method(herbMc, stemMc), expected[particle],
      `Live ${particle} moisture content is ${expected[particle]}`);
    }
    lib.enableParameterValidation();
  }
  assert.end();
});
