/**
 * @file BehavePlus function parameter validation methods.
 * @copyright Systems for Environmentl Management 2019
 * @author Collin D. Bevins
 * @version 0.1.0
 */

const assert = require('behaveplus-validate-parms');

/* eslint-disable no-multi-assign */
const self = module.exports = {
/* eslint-enable no-multi-assign */

  validateParms: true,

  /**
   * Disables behaveplus-fuel-chaparral method parameter validatrion.
   */
  disableParameterValidation() {
    self.validateParms = false;
  },

  /**
   * Enables behaveplus-fuel-chaparral method parameter validatrion.
   */
  enableParameterValidation() {
    self.validateParms = true;
  },

  validAgeMin: 0.0,
  validAgeMax: 100.0,
  validDeadMoistureMin: 0.01,
  validDeadMoistureMax: 1.0,
  validDepthMin: 0.0,
  validDepthMax: 10.0,
  validFractionMin: 0.0,
  validFractionMax: 1.0,
  validLiveMoistureMin: 0.01,
  validLiveMoistureMax: 5.0,
  validLoadMin: 0.0,
  validLoadMax: 4.0,
  validTypes: ['chamise', 'mixed'],

  /**
   * Estimates the chaparral age (years since last burned)
   * from the chaparral fuel depth and fuel type.
   *
   *  @param {number} depth - Chaparral fuel depth (ft+1)
   *  @param {string} type -  Chaparral fuel type ['chamise' | 'mixed']
   *  @returns {number} Estimated chaparral age (years since last burned).
   */
  age(depth, type) {
    if (self.validateParms) {
      assert.isNumberInRange('depth', depth, self.validDepthMin, self.validDepthMax);
      assert.isStringInSet('type', type, self.validTypes);
    }
    const factor = (type === 'chamise') ? 7.5 : 10.0;
    return Math.exp(3.912023 * Math.sqrt(depth / factor));
  },

  /**
   * @returns {string[]} Array of dead fuel particle property keys
   */
  deadParticles() {
    return ['particle1', 'particle2', 'particle3', 'particle4'];
  },

  /**
  * @returns {string} Fuel model domain 'chaparral'
  */
  domain() {
    return 'chaparral';
  },

  /**
   * Estimates the chaparral fuel depth from its age and type.
   *
   * @param {number} age
   * @param {string} type  One of 'chamise' or 'mixed'
   * @returns {number} Estimated fuel bed depth (ft+1)
   */
  fuelDepth(age, type) {
    if (self.validateParms) {
      assert.isNumberInRange('age', age, self.validAgeMin, self.validAgeMax);
      assert.isStringInSet('type', type, self.validTypes);
    }
    // Prevent values of age < 1 from increasing the depth!
    const x = Math.log(Math.max(age, 1.1)) / 3.912023;
    return (type === 'chamise') ? 7.5 * x * x : 10.0 * x * x;
  },

  /**
   * @returns {string[]} Array of valid chaparral fuel types.
   */
  fuelTypes() {
    return self.validTypes;
  },

  /**
   * @returns {string[]} Array of fuel life category property keys
   */
  lifeCategories() {
    return ['dead', 'live'];
  },

  /**
   * @returns {string[]} Array of live fuel particle property keys
   */
  liveParticles() {
    return ['particle1', 'particle2', 'particle3', 'particle4', 'particle5'];
  },

  /**
   *  Estimates the total chaparral fuel load from age and type.
   *
   * NOTE - Rothermel & Philpot (1973) used a factor of 0.0315 for chamise age,
   * while Cohen used 0.0347 in FIRECAST.  According to Faith Ann Heinsch:
   * <i>We are going to use Cohen’s calculation from FIRECAST. The change has to do
   * with the fact that we are creating a proxy age from fuel bed depth rather than
   * using an entered age. He had to make some corrections for that assumption.</i>
   *
   *  @param {number} age - Chaparral age (years since last burned)
   *  @param {string} type -  Chaparral fuel type ['chamise' | 'mixed']
   *  @returns {number} Total fuel load (lb+1 ft-2)
   */
  load(age, type) {
    if (self.validateParms) {
      assert.isNumberInRange('age', age, self.validAgeMin, self.validAgeMax);
      assert.isStringInSet('type', type, self.validTypes);
    }
    // const chamise1 = 0.0315;   // Chamise load factor from Rothermel & Philpot (1973)
    const chamise2 = 0.0347; // Chamise load factor from Cohen's FIRECAST code
    // Total load in tons per acre
    const tpa = (type === 'chamise')
      ? age / (1.4459 + chamise2 * age)
      : age / (0.4849 + 0.0170 * age);
    // Return total load in lb/ft2
    return tpa * 2000.0 / 43560.0;
  },

  dead: {
    /**
     * @returns {number} The dead fuel moisture content of extinction (fraction)
     * as used in BehavePlus V6.
     */
    extinctionMoisture() {
      return 0.3;
    },

    fraction: {
      /**
       * Dead fuel fraction from age for AVERAGE mortality level
       *
       * @param {number} age - Chaparral age (years since last burned)
       * @returns {number} Dead fuel fraction assuming avereage mortality.
       */
      averageMortality(age) {
        if (self.validateParms) {
          assert.isNumberInRange('age', age, self.validAgeMin, self.validAgeMax);
        }
        return Math.min(1.0, Math.max(0.0, 0.0694 * Math.exp(0.0402 * age)));
      },

      /**
       * Dead fuel fraction from age for SEVERE mortality level
       *
       * @param {number} age - Chaparral age (years since last burned)
       * @returns {number} Dead fuel fraction assuming severe mortality.
       */
      severeMortality(age) {
        if (self.validateParms) {
          assert.isNumberInRange('age', age, self.validAgeMin, self.validAgeMax);
        }
        return Math.min(1.0, Math.max(0.0, 0.1094 * Math.exp(0.0385 * age)));
      },
    },

    /**
     *  Estimates chaparral dead fuel load.
     *
     * @param {number} totalFuelLoad Total chaparral fuel load (lb+1 ft-2)
     * @param {*} deadFuelFraction Dead fuel fraction (fraction)
     * @returns {number} Chaparral dead fuel load (lb+1 ft-2)
     */
    load(totalFuelLoad, deadFuelFraction) {
      if (self.validateParms) {
        assert.isNumberInRange('totalFuelLoad', totalFuelLoad,
          self.validLoadMin, self.validLoadMax);
        assert.isNumberInRange('deadFuelFraction', deadFuelFraction,
          self.validFractionMin, self.validFractionMax);
      }
      return totalFuelLoad * deadFuelFraction;
    },

    particle1: {
      /**
       * @returns {number} The particle density (lb+1 ft-3)
       * of the dead fine (0 to 0.25 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      density() {
        return 46.0;
      },

      /**
       * @returns {number} The heat of combustion (btu+1 lb-1)
       * of the dead fine (0 to 0.25 inch diameter) chaparral stem wood
       * as used in BehavePlus V6.
       */
      heat() {
        return 8000.0;
      },

      label() {
        return 'Dead fine (0 to 0.25 inch diameter) stem wood';
      },

      /**
       * @param {number} totalFuelLoad Total chaparral fuel load (lb+1 ft-2)
       * @param {*} deadFuelFraction Dead fuel fraction (fraction)
       * @returns {number} The load (lb+1 ft-2)
       * of the dead fine (0 to 0.25 inch diameter) chaparral stem wood
       * as per Rothermel and Philpot 1973 Figure 1.
       */
      load(totalFuelLoad, deadFuelFraction) {
        if (self.validateParms) {
          assert.isNumberInRange('totalFuelLoad', totalFuelLoad,
            self.validLoadMin, self.validLoadMax);
          assert.isNumberInRange('deadFuelFraction', deadFuelFraction,
            self.validFractionMin, self.validFractionMax);
        }
        return totalFuelLoad * 0.347 * deadFuelFraction;
      },

      /**
       * Returns the dead fuel moisture content appropriate for dead small chaparral stem wood.
       *
       * @param {number} dead1h Dead 1-h time-lag fuel moisture content (ratio)
       * @param {number} dead10h Dead 10-h time-lag fuel moisture content (ratio)
       * @param {number} dead100h Dead 100-h time-lag fuel moisture content (ratio)
       * @returns {number} The fuel moisture content (ratio)
       * of the dead fine (0 to 0.25 inch diameter) chaparral stem wood
       * as assigned in BehavePlus V6 from the dead 1-, 10- and 100-hour
       * time-lag moisture contents.
       */
      moisture(dead1h, dead10h, dead100h) {
        if (self.validateParms) {
          assert.isNumberInRange('dead1h', dead1h,
            self.validDeadMoistureMin, self.validDeadMoistureMax);
          assert.isNumberInRange('dead10h', dead10h,
            self.validDeadMoistureMin, self.validDeadMoistureMax);
          assert.isNumberInRange('dead100h', dead100h,
            self.validDeadMoistureMin, self.validDeadMoistureMax);
        }
        return dead1h;
      },

      /**
       * @returns {number} the surface area-to-volume ratio (ft+2 ft-3)
       * of the dead fine (0 to 0.25 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      savr() {
        return 640.0;
      },

      /**
       * @returns {number} The silica-free mineral content (fraction)
       * of the dead fine (0 to 0.25 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      effectiveMineral() {
        return 0.015;
      },

      /**
       * @returns {number} The fuel particle total mineral content (fraction)
       * of the dead fine (0 to 0.25 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      totalMineral() {
        return 0.055;
      },
    },

    particle2: {
      /**
       * @returns {number} the particle density (lb+1 ft-3)
       * of the dead small (0.25 to 0.5 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      density() {
        return 46.0;
      },

      /**
       * @returns {number} The heat of combustion (btu+1 lb-1)
       * of the dead small (0.25 to 0.5 inch diameter) chaparral stem wood
       * as used in BehavePlus V6.
       */
      heat() {
        return 8000.0;
      },

      label() {
        return 'Dead small (0.25 to 0.5 inch diameter) stem wood';
      },

      /**
       *  Estimates chaparral small (0.25-0.5 inch diameter) dead fuel load.
       *
       * @param {number} totalFuelLoad Total chaparral fuel load (lb+1 ft-2)
       * @param {*} deadFuelFraction Dead fuel fraction (fraction)
       * @returns {number} The load (lb+1 ft-2)
       * of the dead small (0.25 to 0.5 inch diameter) chaparral stem wood
       * as per Rothermel and Philpot 1973 Figure 1.
       */
      load(totalFuelLoad, deadFuelFraction) {
        if (self.validateParms) {
          assert.isNumberInRange('totalFuelLoad', totalFuelLoad,
            self.validLoadMin, self.validLoadMax);
          assert.isNumberInRange('deadFuelFraction', deadFuelFraction,
            self.validFractionMin, self.validFractionMax);
        }
        return totalFuelLoad * 0.364 * deadFuelFraction;
      },

      /**
       * Returns the dead fuel moisture content appropriate for dead small chaparral stem wood.
       *
       * @param {number} dead1h Dead 1-h time-lag fuel moisture content (ratio)
       * @param {number} dead10h Dead 10-h time-lag fuel moisture content (ratio)
       * @param {number} dead100h Dead 100-h time-lag fuel moisture content (ratio)
       * @returns {number} The fuel moisture content (ratio)
       * of the dead small (0.25 to 0.5 inch diameter) chaparral stem wood
       * as assigned in BehavePlus V6 from the dead 1-, 10- and 100-hour
       * time-lag moisture contents.
       */
      moisture(dead1h, dead10h, dead100h) {
        if (self.validateParms) {
          assert.isNumberInRange('dead1h', dead1h,
            self.validDeadMoistureMin, self.validDeadMoistureMax);
          assert.isNumberInRange('dead10h', dead10h,
            self.validDeadMoistureMin, self.validDeadMoistureMax);
          assert.isNumberInRange('dead100h', dead100h,
            self.validDeadMoistureMin, self.validDeadMoistureMax);
        }
        return dead10h;
      },

      /**
       * @returns {number} The surface area-to-volume ratio (ft+2 ft-3)
       * of the dead small (0.25 to 0.5 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      savr() {
        return 127.0;
      },

      /**
       * @returns {number} The silica-free mineral content (fraction)
       * of the dead small (0.25 to 0.5 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      effectiveMineral() {
        return 0.015;
      },

      /**
       * @returns {number} The fuel particle total mineral content (fraction)
       * of the dead small (0.25 to 0.5 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      totalMineral() {
        return 0.055;
      },
    },

    particle3: {
      /**
       * @returns {number} the particle density (lb+1 ft-3)
       * of the dead medium (0.5 to 1 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      density() {
        return 46.0;
      },

      /**
       * @returns {number} The heat of combustion (btu+1 lb-1)
       * of the dead medium (0.5 to 1 inch diameter) chaparral stem wood
       * as used in BehavePlus V6.
       */
      heat() {
        return 8000.0;
      },

      label() {
        return 'Dead medium (0.5 to 1 inch diameter) stem wood';
      },

      /**
       * @param {number} totalFuelLoad Total chaparral fuel load (lb+1 ft-2)
       * @param {*} deadFuelFraction Dead fuel fraction (fraction)
       * @returns {number} The load (lb+1 ft-2)
       * of the dead medium (0.5 to 1 inch diameter) chaparral stem wood
       * as per Rothermel and Philpot (1973) Figure 1.
       */
      load(totalFuelLoad, deadFuelFraction) {
        if (self.validateParms) {
          assert.isNumberInRange('totalFuelLoad', totalFuelLoad,
            self.validLoadMin, self.validLoadMax);
          assert.isNumberInRange('deadFuelFraction', deadFuelFraction,
            self.validFractionMin, self.validFractionMax);
        }
        return totalFuelLoad * 0.207 * deadFuelFraction;
      },

      /**
       * Returns the dead fuel moisture content appropriate for dead small chaparral stem wood.
       *
       * @param {number} dead1h Dead 1-h time-lag fuel moisture content (ratio)
       * @param {number} dead10h Dead 10-h time-lag fuel moisture content (ratio)
       * @param {number} dead100h Dead 100-h time-lag fuel moisture content (ratio)
       * @returns {number} The fuel moisture content (ratio)
       * of the dead medium (0.5 to 1 inch diameter) chaparral stem wood
       * as assigned in BehavePlus V6 from the dead 1-, 10- and 100-hour
       * time-lag moisture contents.
       */
      moisture(dead1h, dead10h, dead100h) {
        if (self.validateParms) {
          assert.isNumberInRange('dead1h', dead1h,
            self.validDeadMoistureMin, self.validDeadMoistureMax);
          assert.isNumberInRange('dead10h', dead10h,
            self.validDeadMoistureMin, self.validDeadMoistureMax);
          assert.isNumberInRange('dead100h', dead100h,
            self.validDeadMoistureMin, self.validDeadMoistureMax);
        }
        return dead10h;
      },

      /**
       * @returns {number} The surface area-to-volume ratio (ft+2 ft-3)
       * of the dead medium (0.5 to 1 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      savr() {
        return 61.0;
      },

      /**
       * @returns {number} The silica-free mineral content (fraction)
       * of the dead medium (0.5 to 1 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      effectiveMineral() {
        return 0.015;
      },

      /**
       * @returns {number} The fuel particle total mineral content (fraction)
       * of the dead medium (0.5 to 1 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      totalMineral() {
        return 0.055;
      },
    },

    particle4: {
      /**
       * @returns {number} the particle density (lb+1 ft-3)
       * of the dead large (1 to 3 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      density() {
        return 46.0;
      },

      /**
       * @returns {number} The dead fuel heat of combustion (btu+1 lb-1)
       * of the dead large (1 to 3 inch diameter) chaparral stem wood
       * as used in BehavePlus V6.
       */
      heat() {
        return 8000.0;
      },

      label() {
        return 'Dead large (1 to 3 inch diameter) stem wood';
      },

      /**
       * Estimates chaparral large (1 to 3 inch diameter) dead fuel load.
       *
       * Note that the factor of 0.082 varies from the Rothermel & Philpot
       * Figure 1 value of .085, because their factors totaled 1.03 instead of 1.
       *
       * @param {number} totalFuelLoad Total chaparral fuel load (lb+1 ft-2)
       * @param {*} deadFuelFraction Dead fuel fraction (fraction)
       * @returns {number} The load (lb+1 ft-2)
       * of the dead large (1 to 3 inch diameter) chaparral stem wood
       * as per Rothermel and Philpot (1973) Figure 1.
       */
      load(totalFuelLoad, deadFuelFraction) {
        if (self.validateParms) {
          assert.isNumberInRange('totalFuelLoad', totalFuelLoad,
            self.validLoadMin, self.validLoadMax);
          assert.isNumberInRange('deadFuelFraction', deadFuelFraction,
            self.validFractionMin, self.validFractionMax);
        }
        return totalFuelLoad * 0.082 * deadFuelFraction;
      },

      /**
       * Returns the dead fuel moisture content appropriate for dead small chaparral stem wood.
       *
       * @param {number} dead1h Dead 1-h time-lag fuel moisture content (ratio)
       * @param {number} dead10h Dead 10-h time-lag fuel moisture content (ratio)
       * @param {number} dead100h Dead 100-h time-lag fuel moisture content (ratio)
       * @returns {number} The fuel moisture content (ratio)
       * of the dead large (1 to 3 inch diameter) chaparral stem wood
       * as assigned in BehavePlus V6 from the dead 1-, 10- and 100-hour
       * time-lag moisture contents.
       */
      moisture(dead1h, dead10h, dead100h) {
        if (self.validateParms) {
          assert.isNumberInRange('dead1h', dead1h,
            self.validDeadMoistureMin, self.validDeadMoistureMax);
          assert.isNumberInRange('dead10h', dead10h,
            self.validDeadMoistureMin, self.validDeadMoistureMax);
          assert.isNumberInRange('dead100h', dead100h,
            self.validDeadMoistureMin, self.validDeadMoistureMax);
        }
        return dead100h;
      },
      /* eslint-enable no-unused-vars */

      /**
       * @returns {number} the surface area-to-volume ratio (ft+2 ft-3)
       * of the dead large (1 to 3 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      savr() {
        return 27.0;
      },

      /**
       * @returns {number} The silica-free mineral content (fraction)
       * of the dead large (1 to 3 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      effectiveMineral() {
        return 0.015;
      },

      /**
       * @returns {number} The fuel particle total mineral content (fraction)
       * of the dead large (1 to 3 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      totalMineral() {
        return 0.055;
      },
    }, // particle4
  }, // dead

  live: {
    /**
     *  Estimates chaparral live fuel load.
     *
     * @param {number} totalFuelLoad Total chaparral fuel load (lb+1 ft-2)
     * @param {*} deadFuelFraction Dead fuel fraction (fraction)
     * @returns {number} Chaparral live fuel load (lb+1 ft-2)
     */
    load(totalFuelLoad, deadFuelFraction) {
      if (self.validateParms) {
        assert.isNumberInRange('totalFuelLoad', totalFuelLoad,
          self.validLoadMin, self.validLoadMax);
        assert.isNumberInRange('deadFuelFraction', deadFuelFraction,
          self.validFractionMin, self.validFractionMax);
      }
      return totalFuelLoad * (1.0 - deadFuelFraction);
    },

    particle1: {
      /**
       * @returns {number} the particle density (lb+1 ft-3)
       * of the live fine (0 - 0.25 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      density() {
        return 46.0;
      },

      /**
       * @returns {number} Heat of combustion (btu+1 lb-1)
       * of the live fine (0 - 0.25 inch diameter) chaparral stem wood
       * as used in BehavePlus V6.
       */
      heat() {
        return 10500.0;
      },

      label() {
        return 'Live fine (0 to 0.25 inch diameter) stem wood';
      },

      /**
       *  Estimates live fine (0 to 0.25 inch diameter) chaparral stem wood fuel load.
       *
       * @param {number} totalFuelLoad Total chaparral fuel load (lb+1 ft-2)
       * @param {*} deadFuelFraction Dead fuel fraction (fraction)
       * @returns {number} The load (lb+1 ft-2)
       * of the live fine (0 to 0.25 inch diameter) chaparral stem wood
       * as per Rothermel and Philpot (1973) Figure 1.
       */
      load(totalFuelLoad, deadFuelFraction) {
        if (self.validateParms) {
          assert.isNumberInRange('totalFuelLoad', totalFuelLoad,
            self.validLoadMin, self.validLoadMax);
          assert.isNumberInRange('deadFuelFraction', deadFuelFraction,
            self.validFractionMin, self.validFractionMax);
        }
        return totalFuelLoad * (0.2416 - 0.256 * deadFuelFraction);
      },

      /**
       * Returns the appropriate live fuel moisture content.
       *
       * @param {number} liveHerbMc Live herbaceous fuel moisture content (ratio)
       * @param {number} liveStemMc Live woody stem fuel moisture content (ratio)
       * @returns {number} The fuel moisture content (ratio)
       * of the live fine (0 to 0.25 inch diameter) chaparral stem wood
       * as assigned in BehavePlus V6 from the live herbaceous and live woody
       * stem moisture contents.
       */
      moisture(liveHerbMc, liveStemMc) {
        if (self.validateParms) {
          assert.isNumberInRange('liveHerbMc', liveHerbMc,
            self.validLiveMoistureMin, self.validLiveMoistureMax);
          assert.isNumberInRange('liveStemMc', liveStemMc,
            self.validLiveMoistureMin, self.validLiveMoistureMax);
        }
        return liveStemMc;
      },

      /**
       * @returns {number} the surface area-to-volume ratio (ft+2 ft-3)
       * of the live fine (0 to 0.25 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      savr() {
        return 640.0;
      },

      /**
       * @returns {number} The silica-free mineral content (fraction)
       * of the live fine (0 to 0.25 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      effectiveMineral() {
        return 0.015;
      },

      /**
       * @returns {number} The total mineral content (fraction)
       * of the live fine (0 to 0.25 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      totalMineral() {
        return 0.055;
      },
    }, // particle 1

    particle2: {
      /**
       * @returns {number} the particle density (lb+1 ft-3)
       * of the live small (0.25 to 0.5 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      density() {
        return 46.0;
      },

      /**
       * @returns {number} Heat of combustion (btu+1 lb-1)
       * of the live small (0.25 to 0.5 inch diameter) chaparral stem wood
       * as used in BehavePlus V6.
       */
      heat() {
        return 9550.0;
      },

      label() {
        return 'Live small (0.25 to 0.5 inch diameter) stem wood';
      },

      /**
       *  Estimates live small (0.25 to 0.5 inch diameter) chaparral stem wood fuel load.
       *
       * @param {number} totalFuelLoad Total chaparral fuel load (lb+1 ft-2)
       * @param {*} deadFuelFraction Dead fuel fraction (fraction)
       * @returns {number} The load (lb+1 ft-2)
       * of the live small (0.25 t0 0.5 inch diameter) chaparral stem wood
       * as per Rothermel and Philpot (1973) Figure 1.
       */
      load(totalFuelLoad, deadFuelFraction) {
        if (self.validateParms) {
          assert.isNumberInRange('totalFuelLoad', totalFuelLoad,
            self.validLoadMin, self.validLoadMax);
          assert.isNumberInRange('deadFuelFraction', deadFuelFraction,
            self.validFractionMin, self.validFractionMax);
        }
        return totalFuelLoad * (0.1918 - 0.256 * deadFuelFraction);
      },

      /**
       * Returns the appropriate live fuel moisture content.
       *
       * @param {number} liveHerbMc Live herbaceous fuel moisture content (ratio)
       * @param {number} liveStemMc Live woody stem fuel moisture content (ratio)
       * @returns {number} The fuel moisture content (ratio)
       * of the live small (0.25 to 0.5 inch diameter) chaparral stem wood
       * as assigned in BehavePlus V6 from the live herbaceous and live woody
       * stem moisture contents.
       */
      moisture(liveHerbMc, liveStemMc) {
        if (self.validateParms) {
          assert.isNumberInRange('liveHerbMc', liveHerbMc,
            self.validLiveMoistureMin, self.validLiveMoistureMax);
          assert.isNumberInRange('liveStemMc', liveStemMc,
            self.validLiveMoistureMin, self.validLiveMoistureMax);
        }
        return liveStemMc;
      },

      /**
       * @returns {number} the surface area-to-volume ratio (ft+2 ft-3)
       * of the live small (0.25 to 0.5 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      savr() {
        return 127.0;
      },

      /**
       * @returns {number} The silica-free mineral content (fraction)
       * of the live small (0.25 to 0.5 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      effectiveMineral() {
        return 0.015;
      },

      /**
        * @returns {number} The total mineral content (fraction)
       * of the live small (0.25 to 0.5 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
      */
      totalMineral() {
        return 0.055;
      },
    }, // particle 2

    particle3: {
      /**
       * @returns {number} the particle density (lb+1 ft-3)
       * of the live medium (0.5 - 1 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      density() {
        return 46.0;
      },

      /**
       * @returns {number} Heat of combustion (btu+1 lb-1)
       * of the live medium (0.5 to 1 inch diameter) chaparral stem wood
       * as used in BehavePlus V6.
       */
      heat() {
        return 9550.0;
      },

      label() {
        return 'Live medium (0.5 to 1 inch diameter) stem wood';
      },

      /**
       *  Estimates live medium (0.5 to 1 inch diameter) chaparral stem wood fuel load.
       *
       * @param {number} totalFuelLoad Total chaparral fuel load (lb+1 ft-2)
       * @param {*} deadFuelFraction Dead fuel fraction (fraction)
       * @returns {number} The load (lb+1 ft-2)
       * of the live medium (0.5 to 1 inch diameter) chaparral stem wood
       * as per Rothermel and Philpot (1973) Figure 1.
       */
      load(totalFuelLoad, deadFuelFraction) {
        if (self.validateParms) {
          assert.isNumberInRange('totalFuelLoad', totalFuelLoad,
            self.validLoadMin, self.validLoadMax);
          assert.isNumberInRange('deadFuelFraction', deadFuelFraction,
            self.validFractionMin, self.validFractionMax);
        }
        return totalFuelLoad * (0.2648 - 0.050 * deadFuelFraction);
      },

      /**
       * Returns the appropriate live fuel moisture content.
       *
       * @param {number} liveHerbMc Live herbaceous fuel moisture content (ratio)
       * @param {number} liveStemMc Live woody stem fuel moisture content (ratio)
       * @returns {number} The fuel moisture content (ratio)
       * of the live medium (0.5 to 1 inch diameter) chaparral stem wood
       * as assigned in BehavePlus V6 from the live herbaceous and live woody
       * stem moisture contents.
       */
      moisture(liveHerbMc, liveStemMc) {
        if (self.validateParms) {
          assert.isNumberInRange('liveHerbMc', liveHerbMc,
            self.validLiveMoistureMin, self.validLiveMoistureMax);
          assert.isNumberInRange('liveStemMc', liveStemMc,
            self.validLiveMoistureMin, self.validLiveMoistureMax);
        }
        return liveStemMc;
      },

      /**
       * @returns {number} the surface area-to-volume ratio (ft+2 ft-3)
       * of the live medium (0.5 to 1 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      savr() {
        return 61.0;
      },

      /**
       * @returns {number} The silica-free mineral content (fraction)
       * of the live medium (0.5 to 1 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      effectiveMineral() {
        return 0.015;
      },

      /**
       * @returns {number} The total mineral content (fraction)
       * of the live medium (0.5 to 1 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      totalMineral() {
        return 0.055;
      },
    }, // particle3

    particle4: {
      /**
       * @returns {number} the particle density (lb+1 ft-3)
       * of the live large (1 - 3 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      density() {
        return 46.0;
      },

      /**
       * @returns {number} Heat of combustion (btu+1 lb-1)
       * of the live large (1 - 3 inch diameter) chaparral stem wood
       * as used in BehavePlus V6.
       */
      heat() {
        return 9550.0;
      },

      label() {
        return 'Live large (1 to 3 inch diameter) stem wood';
      },

      /**
       *  Estimates live large (1 to 3 inch diameter) chaparral stem wood fuel load.
       *
       * @param {number} totalFuelLoad Total chaparral fuel load (lb+1 ft-2)
       * @param {*} deadFuelFraction Dead fuel fraction (fraction)
       * @returns {number} The load (lb+1 ft-2)
       * of the live large (1 to 3 inch diameter) chaparral stem wood
       * as per Rothermel and Philpot (1973) Figure 1.
       */
      load(totalFuelLoad, deadFuelFraction) {
        if (self.validateParms) {
          assert.isNumberInRange('totalFuelLoad', totalFuelLoad,
            self.validLoadMin, self.validLoadMax);
          assert.isNumberInRange('deadFuelFraction', deadFuelFraction,
            self.validFractionMin, self.validFractionMax);
        }
        return totalFuelLoad * (0.1036 - 0.114 * deadFuelFraction);
      },

      /**
       * Returns the appropriate live fuel moisture content.
       *
       * @param {number} liveHerbMc Live herbaceous fuel moisture content (ratio)
       * @param {number} liveStemMc Live woody stem fuel moisture content (ratio)
       * @returns {number} The fuel moisture content (ratio)
       * of the live large (1 to 3 inch diameter) chaparral stem wood
       * as assigned in BehavePlus V6 from the live herbaceous and live woody
       * stem moisture contents.
       */
      moisture(liveHerbMc, liveStemMc) {
        if (self.validateParms) {
          assert.isNumberInRange('liveHerbMc', liveHerbMc,
            self.validLiveMoistureMin, self.validLiveMoistureMax);
          assert.isNumberInRange('liveStemMc', liveStemMc,
            self.validLiveMoistureMin, self.validLiveMoistureMax);
        }
        return liveStemMc;
      },

      /**
       * @returns {number} the surface area-to-volume ratio (ft+2 ft-3)
       * of the live large (1 to 3 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      savr() {
        return 27.0;
      },

      /**
       * @returns {number} The silica-free mineral content (fraction)
       * of the live large (1 to 3 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      effectiveMineral() {
        return 0.015;
      },

      /**
       * @returns {number} The total mineral content (fraction)
       * of the live large (1 to 3 inch diameter) chaparral stem wood
       * per Rothermel and Philpot (1973) Table 1.
       */
      totalMineral() {
        return 0.055;
      },
    }, // partiucle4

    particle5: {
      /**
       * @returns {number} the particle density (lb+1 ft-3)
       * of the live chaparral leaves per Rothermel and Philpot (1973) Table 1.
       */
      density() {
        return 32.0;
      },

      /**
       * @returns {number} Heat of combustion (btu+1 lb-1)
       * of the live chaparral leaves as used in BehavePlus V6.
       */
      heat() {
        return 10500.0;
      },

      label() {
        return 'Live leaves';
      },

      /**
       *  Estimates live chaparral leaf fuel load.
       *
       * @param {number} totalFuelLoad Total chaparral fuel load (lb+1 ft-2)
       * @param {*} deadFuelFraction Dead fuel fraction (fraction)
       * @returns {number} The load (lb+1 ft-2)
       * of the live chaparral leaf
       * as per Rothermel and Philpot (1973) Figure 1.
      */
      load(totalFuelLoad, deadFuelFraction) {
        if (self.validateParms) {
          assert.isNumberInRange('totalFuelLoad', totalFuelLoad,
            self.validLoadMin, self.validLoadMax);
          assert.isNumberInRange('deadFuelFraction', deadFuelFraction,
            self.validFractionMin, self.validFractionMax);
        }
        return totalFuelLoad * (0.1957 - 0.305 * deadFuelFraction);
      },

      /**
       * Returns the live fuel moisture content appropriate for live chaparral leaves.
       *
       * @param {number} liveHerbMc Live herbaceous fuel moisture content (ratio)
       * @param {number} liveStemMc Live woody stem fuel moisture content (ratio)
       * @returns {number} The fuel moisture content (ratio)
       * of the live chaparral leaves
       * as assigned in BehavePlus V6 from the live herbaceous and live woody
       * stem moisture contents.
       */
      moisture(liveHerbMc, liveStemMc) {
        if (self.validateParms) {
          assert.isNumberInRange('liveHerbMc', liveHerbMc,
            self.validLiveMoistureMin, self.validLiveMoistureMax);
          assert.isNumberInRange('liveStemMc', liveStemMc,
            self.validLiveMoistureMin, self.validLiveMoistureMax);
        }
        return liveHerbMc;
      },

      /**
       * @returns {number} the surface area-to-volume ratio (ft+2 ft-3)
       * of the live chaparral leaves
       * per Rothermel and Philpot (1973) Table 1.
       */
      savr() {
        return 2200.0;
      },

      /**
       * @returns {number} The silica-free mineral content (fraction)
       * of the live chaparral leaved
       * per Rothermel and Philpot (1973) Table 1.
       */
      effectiveMineral() {
        return 0.035;
      },

      /**
       * @returns {number} The total mineral content (fraction)
       * of the live chaparral leaved
       * per Rothermel and Philpot (1973) Table 1.
       */
      totalMineral() {
        return 0.055;
      },
    }, // particle5
  }, // live
};
