declare const getByteLen: (val: string) => number;
export default getByteLen;
