declare const each: (o: any, next: any) => void;
export default each;
