declare const isInstallFlash: () => boolean;
export default isInstallFlash;
