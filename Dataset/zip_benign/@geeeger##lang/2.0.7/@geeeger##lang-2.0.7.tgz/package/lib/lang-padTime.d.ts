export default function padTime(time: number): string;
