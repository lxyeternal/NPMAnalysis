declare const string: {
    bytelen: (s: string) => number;
    format: (...args: any) => string;
    join: (...args: any[]) => string;
};
export default string;
