declare const getStrLen: (val: string) => number;
export default getStrLen;
