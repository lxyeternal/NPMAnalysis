export default function getTimeTips(nowTime: number, hisTime: number): string;
