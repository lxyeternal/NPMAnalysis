declare global {
    interface Screen {
        deviceXDPI: any;
        logicalXDPI: any;
    }
}
export default function getScreenRatio(): number;
