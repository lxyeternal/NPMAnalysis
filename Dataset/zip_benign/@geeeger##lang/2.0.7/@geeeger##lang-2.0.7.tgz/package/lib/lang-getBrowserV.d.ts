declare const getBrowserV: (num: number) => boolean;
export default getBrowserV;
