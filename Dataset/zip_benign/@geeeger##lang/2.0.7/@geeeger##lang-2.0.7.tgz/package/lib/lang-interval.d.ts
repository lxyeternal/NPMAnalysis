declare const interval: (fn: any, step: any, right?: any) => void;
export default interval;
