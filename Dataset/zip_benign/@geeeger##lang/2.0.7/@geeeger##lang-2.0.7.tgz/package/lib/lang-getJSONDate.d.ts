/**
 * 获取json格式的日期，便于操作
 * @param timeStamp 时间戳
 * @param isUnixTimeStamp 是否是Unix时间戳
 */
export default function getJSONDate(timeStamp: number, isUnixTimeStamp?: boolean): {
    y: number;
    M: number;
    d: number;
    day: number;
    h: number;
    m: number;
    s: number;
    ms: number;
};
