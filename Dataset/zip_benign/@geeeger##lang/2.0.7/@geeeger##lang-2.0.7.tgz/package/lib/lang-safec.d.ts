declare const safec: (fn: any, isPrint?: any) => void;
export default safec;
