declare const mixi: <T = any>(...obj: any) => T;
export default mixi;
