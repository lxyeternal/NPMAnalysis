declare const floatMath: {
    Subtr: (arg1: any, arg2: any, num: any) => string;
    accAdd: (arg1: any, arg2: any, num: any) => string;
    accDiv: (arg1: any, arg2: any) => number;
    accMul: (arg1: any, arg2: any) => number;
};
export default floatMath;
