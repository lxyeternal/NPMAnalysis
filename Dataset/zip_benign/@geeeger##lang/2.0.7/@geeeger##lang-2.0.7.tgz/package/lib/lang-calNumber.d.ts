declare const calNumber: (a: number, b: number) => string;
export default calNumber;
