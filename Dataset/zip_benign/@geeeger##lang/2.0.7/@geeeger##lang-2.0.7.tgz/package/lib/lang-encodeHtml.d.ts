export default function encode(text: string): string;
