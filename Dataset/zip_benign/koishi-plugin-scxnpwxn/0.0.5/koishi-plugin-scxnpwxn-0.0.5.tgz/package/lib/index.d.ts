import { Context, Schema } from 'koishi';
export declare const name = "auto-stock";
export interface Config {
    multi: number,
    strategy: 1 | 2 | 3
}
export declare const Config: Schema<Config> = Schema.object({
    multi: Schema.number().description('买卖倍数').min(0).default(2),
    strategy: Schema.union([
        Schema.const(1).description('开盘即购买'),
        Schema.const(2).description('开盘后第一次为涨才购买'),
        Schema.const(3).description('yaozi法'),
      ]).role('radio'),
});
export declare function apply(ctx: Context): void;
