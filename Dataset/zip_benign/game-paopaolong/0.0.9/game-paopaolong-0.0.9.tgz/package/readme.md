# game-paopaolong

# 游戏

##### 安装

```
npm install game-paopaolong
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game": "game-paopaolong/paopaolong"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "game-paopaolong"
  ]
}
```

- js

```
Page({
  data: {
    gameSource2: {
      // 游戏元素
      speed: 26,//飞行速度
      MAX_ANGLE: 70,//最大角度
      MIN_ANGLE: -70,//最小角度
      firstBottomLineType: "max",//第一行是大行
      rowMaxNum: 7,//大行最大球球个数
      baseScore: 0,//基础分数
      firstRowNum: 3,//初始化渲染多少行
      nextRenderLine: 3,//自动生成行时，新增行数
      padding: {
        left: 0,
        right: 0,
      },
      totalBall: 100,//当前剩余泡泡个数
      items: [
        {
          src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01rz3tx01FJvdsWJyzY_!!1080040467.png",
          val: 10,
          width: 102,
          height: 102,
          probability: 10,//出现概率
          bzType: "3",//标识唯一类型 类型相同，则可以消除
          // 爆炸动画序列帧
          srcArr: [
            { src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01nP97Ns1FJvaQm5lMf_!!1080040467.png", width: 1280, height: 1280 },
          ],
          boomScale: 1,//爆炸动画缩放，相对精灵尺寸，默认为1
          boomSpeed: 0.5,// 爆炸动画速度 值越大，速度越快
        },
        {
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01R3jVF91FJvdpzFzoq_!!1080040467.png",
          val: 110,
          noSend: true,//不出现在发射球位置
          width: 102,
          height: 102,
          probability: 1,//出现概率
          bzType: "1",//标识唯一类型 类型相同，则可以消除
          // 爆炸动画序列帧
          srcArr: [
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ZMJGZb1FJvaRPRlW4_!!1080040467.png", width: 1280, height: 1280 },
          ],
          boomSpeed: 0.5,// 爆炸动画速度 值越大，速度越快
        },
        {
          src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01WV7JRV1FJvdpzG3yx_!!1080040467.png",
          val: 110,
          // noSend: true,
          width: 102,
          height: 102,
          probability: 1,//出现概率
          bzType: "2",
          // 爆炸动画序列帧
          srcArr: [
            { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ZMJGZb1FJvaRPRlW4_!!1080040467.png", width: 1280, height: 1280 },
          ],
          boomSpeed: 0.5,// 爆炸动画速度 值越大，速度越快
        },
      ],
      /* boom: {
        src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01SDWDR51FJvdpXOYVT_!!1080040467.png",
        val: 10,
        width: 102,
        height: 102,
        delayTime: 500,//显示炸弹后延迟时间再消除
        probability: 1,//出现概率
        bzType: "5",
        // 爆炸动画序列帧
        srcArr: [
          { src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ZMJGZb1FJvaRPRlW4_!!1080040467.png", width: 1280, height: 1280 },
        ],
        boomSpeed: 0.5,// 爆炸动画速度 值越大，速度越快
      }, */
      pao: {
        src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01c2dCfs1FJvdnGgdUB_!!1080040467.png",
        width: 102,
        height: 102,
        isHide: true,//true:不显示直接处理成贴着底部
        x: 750 / 2,
        y: 1000 - 100
      },
      nextBallBg1: {
        src: "https://img.alicdn.com/imgextra/i3/1080040467/O1CN01sKmSxb1FJvaQJ5QNt_!!1080040467.png",
        width: 160,
        height: 107,
        x: 750 / 2,
        y: 1000 - 10 - 107 / 2
      },
      line: {
        src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01VWMP521FJvdm58r5L_!!1080040467.png",
        width: 750,
        height: 61,
        bottom: 199,
        showAllWidth: true
      },
      helpLine: {
        // src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01RrwVBL1FJvdnXcDWX_!!1080040467.png",
        // width: 48,
        // height: 298,
        src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01k4EK9T1EUdLzCZGTC_!!2185320355.png",
        width: 135,
        height: 240
      }
    },
    showGame: true,
    // 希思黎
    gameSource: {
      // 游戏元素
      speed: 26,//飞行速度
      helpLineNum: 5,//开始渲染辅助线个数
      MAX_ANGLE: 70,//最大角度
      MIN_ANGLE: -70,//最小角度
      firstBottomLineType: "max",//第一行是大行
      autoStart: true,
      rowMaxNum: 7,//大行最大球球个数
      baseScore: 0,//基础分数
      firstRowNum: 3,//初始化渲染多少行
      padding: {
        left: 0,
        right: 0,
      },
      items: [
        {
          src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01Rs3xlk1EUdM19jNy0_!!2185320355.png",
          val: 1,
          width: 93,
          height: 93,
          probability: 1,//出现概率
          bzType: "3",//标识唯一类型 类型相同，则可以消除
          // 爆炸动画序列帧
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01LMhvOu1EUdM8O7cYa_!!2185320355.png", "name": "希思黎互动 2_00007.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01MqVCAh1EUdM0FT4vO_!!2185320355.png", "name": "希思黎互动 2_00008.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN019e36E31EUdM6dawI0_!!2185320355.png", "name": "希思黎互动 2_00009.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01W4fGmF1EUdM75yKhA_!!2185320355.png", "name": "希思黎互动 2_00010.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01luMK711EUdM9Jrplz_!!2185320355.png", "name": "希思黎互动 2_00011.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01P5f3e71EUdM1neUrE_!!2185320355.png", "name": "希思黎互动 2_00012.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01L8h6VU1EUdMC4ocPf_!!2185320355.png", "name": "希思黎互动 2_00013.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01GEGuRS1EUdM0FUYQN_!!2185320355.png", "name": "希思黎互动 2_00014.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN0129uhzV1EUdMC4o0zR_!!2185320355.png", "name": "希思黎互动 2_00015.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01opKgly1EUdM4u7mE7_!!2185320355.png", "name": "希思黎互动 2_00016.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01stVuLj1EUdM1neZ1u_!!2185320355.png", "name": "希思黎互动 2_00017.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01glFjux1EUdM4n8kpu_!!2185320355.png", "name": "希思黎互动 2_00018.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01oDgQ4I1EUdM6dboJq_!!2185320355.png", "name": "希思黎互动 2_00019.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01vLJqYC1EUdM8O7kt5_!!2185320355.png", "name": "希思黎互动 2_00020.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01wMMPD01EUdM5auOVa_!!2185320355.png", "name": "希思黎互动 2_00021.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01xVDQR81EUdM2Uc3Ws_!!2185320355.png", "name": "希思黎互动 2_00022.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01KbLwoz1EUdMC4p5WS_!!2185320355.png", "name": "希思黎互动 2_00023.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN011xtAq01EUdLvMConL_!!2185320355.png", "name": "希思黎互动 2_00024.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01uCy7ES1EUdMDGWzsF_!!2185320355.png", "name": "希思黎互动 2_00025.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01ObrQx61EUdM9JqxkM_!!2185320355.png", "name": "希思黎互动 2_00026.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01Uo3g121EUdM5avCNV_!!2185320355.png", "name": "希思黎互动 2_00027.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01pjcGud1EUdMDGYGsQ_!!2185320355.png", "name": "希思黎互动 2_00028.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01CMKAbg1EUdM5at7UM_!!2185320355.png", "name": "希思黎互动 2_00029.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01wgnpci1EUdMBJoBBA_!!2185320355.png", "name": "希思黎互动 2_00030.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN018zwnj91EUdMBJnEyc_!!2185320355.png", "name": "希思黎互动 2_00031.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01qhR5Hu1EUdM8O7De3_!!2185320355.png", "name": "希思黎互动 2_00032.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01swVLKY1EUdMA6c61C_!!2185320355.png", "name": "希思黎互动 2_00033.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN014Qc2gg1EUdM8O697q_!!2185320355.png", "name": "希思黎互动 2_00034.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01qdDrte1EUdM6dbkAs_!!2185320355.png", "name": "希思黎互动 2_00035.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01ejYxQk1EUdLvM9rpd_!!2185320355.png", "name": "希思黎互动 2_00036.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01VdJTNe1EUdM1ngmJu_!!2185320355.png", "name": "希思黎互动 2_00037.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01Wconx21EUdMC4nD7z_!!2185320355.png", "name": "希思黎互动 2_00038.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01CfBRUl1EUdLvMDtMK_!!2185320355.png", "name": "希思黎互动 2_00039.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01uwuraS1EUdM2Udncf_!!2185320355.png", "name": "希思黎互动 2_00040.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN019S6nkT1EUdM8O7kuF_!!2185320355.png", "name": "希思黎互动 2_00041.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01o9L7QF1EUdMA6cQnz_!!2185320355.png", "name": "希思黎互动 2_00042.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN019Ulxfs1EUdLvMDtMU_!!2185320355.png", "name": "希思黎互动 2_00043.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01aNwHVI1EUdM4n6PKu_!!2185320355.png", "name": "希思黎互动 2_00044.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01EbUr6f1EUdM75z8cp_!!2185320355.png", "name": "希思黎互动 2_00045.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01uaZF401EUdM6dawJo_!!2185320355.png", "name": "希思黎互动 2_00046.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01gLn3h21EUdMA6dlxw_!!2185320355.png", "name": "希思黎互动 2_00047.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01KTFKt21EUdM75yfVX_!!2185320355.png", "name": "希思黎互动 2_00048.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01yY22Aj1EUdM5auSfd_!!2185320355.png", "name": "希思黎互动 2_00049.png", "width": "81", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01CZKKYW1EUdMC4m8bA_!!2185320355.png", "name": "希思黎互动 2_00050.png", "width": "81", "height": "82" },
          ],
          boomScale: 1,//爆炸动画缩放，相对精灵尺寸，默认为1
          boomSpeed: 0.5,// 爆炸动画速度 值越大，速度越快
        },
        {
          src: "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01RDATUU1EUdLuiAWcg_!!2185320355.png",
          val: 1,
          // noSend: true,//不出现在发射球位置
          width: 93,
          height: 93,
          probability: 1,//出现概率
          bzType: "1",//标识唯一类型 类型相同，则可以消除
          // 爆炸动画序列帧
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01Xr8ly11EUdM6dgF2g_!!2185320355.png", "name": "希思黎互动 3_00007.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01xnbfBA1EUdM4nBqUA_!!2185320355.png", "name": "希思黎互动 3_00008.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01bQDoki1EUdM5b1NF7_!!2185320355.png", "name": "希思黎互动 3_00009.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01OeM2YR1EUdME3xPti_!!2185320355.png", "name": "希思黎互动 3_00010.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01S4BtaM1EUdM1nkwRY_!!2185320355.png", "name": "希思黎互动 3_00011.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01XFoec31EUdM5azILe_!!2185320355.png", "name": "希思黎互动 3_00012.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN019hGtXU1EUdM0FWhpv_!!2185320355.png", "name": "希思黎互动 3_00013.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01SDnoaW1EUdM6dg6jG_!!2185320355.png", "name": "希思黎互动 3_00014.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01zQ59MN1EUdLvMHNrO_!!2185320355.png", "name": "希思黎互动 3_00015.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01QTVKmR1EUdM9JtaDW_!!2185320355.png", "name": "希思黎互动 3_00016.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01G9l3861EUdM765eLp_!!2185320355.png", "name": "希思黎互动 3_00017.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01u1M38z1EUdMA6hw4I_!!2185320355.png", "name": "希思黎互动 3_00018.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01ZpJ9U51EUdLvMHS2K_!!2185320355.png", "name": "希思黎互动 3_00019.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN013jPm3J1EUdM4nFKkF_!!2185320355.png", "name": "希思黎互动 3_00020.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01SFWrNy1EUdM4uFQcs_!!2185320355.png", "name": "希思黎互动 3_00021.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01LudeYB1EUdM4uBsE2_!!2185320355.png", "name": "希思黎互动 3_00022.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01xAvc3A1EUdME3vo7v_!!2185320355.png", "name": "希思黎互动 3_00023.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01xeL72y1EUdM9Jun6v_!!2185320355.png", "name": "希思黎互动 3_00024.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01zq6No61EUdM9Jxft8_!!2185320355.png", "name": "希思黎互动 3_00025.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01pDRy0P1EUdM2UhQSu_!!2185320355.png", "name": "希思黎互动 3_00026.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01I1gMZZ1EUdM1nmPxb_!!2185320355.png", "name": "希思黎互动 3_00027.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01d5Vkti1EUdME3wwpD_!!2185320355.png", "name": "希思黎互动 3_00028.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01OHO7A41EUdM4nCmhV_!!2185320355.png", "name": "希思黎互动 3_00029.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01ZS3ogm1EUdM5ayQJE_!!2185320355.png", "name": "希思黎互动 3_00030.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01BE5gSu1EUdM1nopdq_!!2185320355.png", "name": "希思黎互动 3_00031.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01zU4rvY1EUdLvMGiJ1_!!2185320355.png", "name": "希思黎互动 3_00032.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN017tfHdV1EUdM5b1ZjN_!!2185320355.png", "name": "希思黎互动 3_00033.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01a5T4n41EUdM1nlLQ0_!!2185320355.png", "name": "希思黎互动 3_00034.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01YszQzr1EUdLvMHr0a_!!2185320355.png", "name": "希思黎互动 3_00035.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01pbblu71EUdM765qp6_!!2185320355.png", "name": "希思黎互动 3_00036.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN013uh0jj1EUdLvMHmqD_!!2185320355.png", "name": "希思黎互动 3_00037.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN014wnb1j1EUdM8OAucz_!!2185320355.png", "name": "希思黎互动 3_00038.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01ewZrKk1EUdMDGb5rj_!!2185320355.png", "name": "希思黎互动 3_00039.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01qJXHF81EUdMDGcZKg_!!2185320355.png", "name": "希思黎互动 3_00040.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01ZOL4nd1EUdM6dgqUx_!!2185320355.png", "name": "希思黎互动 3_00041.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01gEtBPA1EUdM762hMc_!!2185320355.png", "name": "希思黎互动 3_00042.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01nc10fJ1EUdM9Jx4TC_!!2185320355.png", "name": "希思黎互动 3_00043.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01pEgPd31EUdMDGatPc_!!2185320355.png", "name": "希思黎互动 3_00044.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01UV2oAn1EUdM2UfPl2_!!2185320355.png", "name": "希思黎互动 3_00045.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN018V0aT71EUdM0FYNmx_!!2185320355.png", "name": "希思黎互动 3_00046.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01C7bjpa1EUdM0FWZY4_!!2185320355.png", "name": "希思黎互动 3_00047.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01zMk4gE1EUdLvMIzfy_!!2185320355.png", "name": "希思黎互动 3_00048.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN016cKjOg1EUdM5b1VaR_!!2185320355.png", "name": "希思黎互动 3_00049.png", "width": "76", "height": "82" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01sffQfZ1EUdM6dey57_!!2185320355.png", "name": "希思黎互动 3_00050.png", "width": "76", "height": "82" },
          ],
          boomSpeed: 0.5,// 爆炸动画速度 值越大，速度越快
        },
        {
          src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01P3uCf81EUdMAfFjFU_!!2185320355.png",
          val: 1,
          // noSend: true,
          width: 93,
          height: 93,
          probability: 1,//出现概率
          bzType: "2",
          // 爆炸动画序列帧
          srcArr: [
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01Q7s6Xk1EUdM4uJex5_!!2185320355.png", "name": "希思黎互动 4_00007.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01ACeyP81EUdM1ntSvB_!!2185320355.png", "name": "希思黎互动 4_00008.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01ucKFTc1EUdM0FcgF1_!!2185320355.png", "name": "希思黎互动 4_00009.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01aFDAsR1EUdMA6l5q2_!!2185320355.png", "name": "希思黎互动 4_00010.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN0177bkJI1EUdLvMKoJT_!!2185320355.png", "name": "希思黎互动 4_00011.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01TitEnN1EUdM6dkjwZ_!!2185320355.png", "name": "希思黎互动 4_00012.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01yKJMPK1EUdM6dmU4G_!!2185320355.png", "name": "希思黎互动 4_00013.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01sQP7GI1EUdMDGfj8P_!!2185320355.png", "name": "希思黎互动 4_00014.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01m2M1sb1EUdM4uLfhZ_!!2185320355.png", "name": "希思黎互动 4_00015.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01xd4mnt1EUdMDGj0qZ_!!2185320355.png", "name": "希思黎互动 4_00016.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01P6EUUV1EUdM4nLAtt_!!2185320355.png", "name": "希思黎互动 4_00017.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01LieBS31EUdM4uJexi_!!2185320355.png", "name": "希思黎互动 4_00018.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01JtRzpY1EUdM1nr3Fg_!!2185320355.png", "name": "希思黎互动 4_00019.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN0193qjpB1EUdM6dlkKw_!!2185320355.png", "name": "希思黎互动 4_00020.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01H1paJ21EUdMC4zpV0_!!2185320355.png", "name": "希思黎互动 4_00021.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01ZaHnNH1EUdLvMMLwT_!!2185320355.png", "name": "希思黎互动 4_00022.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN015YaUGY1EUdME42aQh_!!2185320355.png", "name": "希思黎互动 4_00023.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01UqqnfD1EUdM5b4GQ3_!!2185320355.png", "name": "希思黎互动 4_00024.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN019lVgfY1EUdMBJyv8x_!!2185320355.png", "name": "希思黎互动 4_00025.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01BLPeuT1EUdM0Fd5DN_!!2185320355.png", "name": "希思黎互动 4_00026.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01IT5Y2q1EUdM4nKIoz_!!2185320355.png", "name": "希思黎互动 4_00027.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN010ipTmG1EUdM4uKjWK_!!2185320355.png", "name": "希思黎互动 4_00028.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01PCnuv91EUdM8OEbd1_!!2185320355.png", "name": "希思黎互动 4_00029.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01OLco3v1EUdMBJy7FH_!!2185320355.png", "name": "希思黎互动 4_00030.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01mJ02wK1EUdM1ns7oq_!!2185320355.png", "name": "希思黎互动 4_00031.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN019N0lRl1EUdM9K1hmA_!!2185320355.png", "name": "希思黎互动 4_00032.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN010svAr81EUdM9K1EgK_!!2185320355.png", "name": "希思黎互动 4_00033.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01CI9Lab1EUdMBK0Sld_!!2185320355.png", "name": "希思黎互动 4_00034.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01jjULXV1EUdMDGh8Qv_!!2185320355.png", "name": "希思黎互动 4_00035.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01f3ecAX1EUdMDGhKue_!!2185320355.png", "name": "希思黎互动 4_00036.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN011zqGfo1EUdMA6oFKi_!!2185320355.png", "name": "希思黎互动 4_00037.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01qVa9eS1EUdLvMP2Iu_!!2185320355.png", "name": "希思黎互动 4_00038.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01Pc70ds1EUdM4uJWem_!!2185320355.png", "name": "希思黎互动 4_00039.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01XZFDYT1EUdMC4wLHh_!!2185320355.png", "name": "希思黎互动 4_00040.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01cIOiji1EUdM6dlwpW_!!2185320355.png", "name": "希思黎互动 4_00041.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01pOteyY1EUdM4nKhoD_!!2185320355.png", "name": "希思黎互动 4_00042.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01WtVrxc1EUdM769oWB_!!2185320355.png", "name": "希思黎互动 4_00043.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01w9W4cE1EUdM1nsORf_!!2185320355.png", "name": "希思黎互动 4_00044.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01xfTnQo1EUdMC4xsv2_!!2185320355.png", "name": "希思黎互动 4_00045.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01GD1qto1EUdM9K3qpP_!!2185320355.png", "name": "希思黎互动 4_00046.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01bVS78u1EUdMA6pmzs_!!2185320355.png", "name": "希思黎互动 4_00047.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01j79Xhy1EUdM76BM8l_!!2185320355.png", "name": "希思黎互动 4_00048.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01veVzxd1EUdM4uJaqg_!!2185320355.png", "name": "希思黎互动 4_00049.png", "width": "75", "height": "84" },
            { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01a00n9O1EUdM4uJvc0_!!2185320355.png", "name": "希思黎互动 4_00050.png", "width": "75", "height": "84" },
          ],
          boomSpeed: 0.5,// 爆炸动画速度 值越大，速度越快
        },
      ],
      pao: {
        src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01c2dCfs1FJvdnGgdUB_!!1080040467.png",
        width: 102,
        height: 102,
        isHide: true,//true:不显示直接处理成贴着底部
        x: 750 / 2,
        y: 1000 - 100
      },
      line: {
        alpha: 0,
        src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01VWMP521FJvdm58r5L_!!1080040467.png",
        width: 750,
        height: 61,
        bottom: 199,
        showAllWidth: true
      },
      helpLine: {
        // src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01RrwVBL1FJvdnXcDWX_!!1080040467.png",
        // width: 48,
        // height: 298,
        src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN011hpEIo1EUdM9SC6Rs_!!2185320355.png",
        width: 9,
        height: 246
      }
    },
  },
  onLoad() { },
  onRef(game) {
    this.gameComponent = game;
    console.log("进入游戏")
  },
  onInitDone() {
    // my.alert({
    //   content: "游戏初始化完成"
    // })
    // this.beginFun();
  },
  onRenderPlay(img) {
    // 发射求发生变化回调
    console.log("当前发射求：", img)
  },
  onUpdate(item) {
    // curDestroyObj:{}本次消除元素对象个数 key:name_${img.bzType}_${img.probability}
    // sendImg：当前发射求对象
    // totalDestroyObj本局消除元素对象个数
    // score本次游戏分数
    // totalScore本局总分数
    console.log(item)
    this.ballNum--;
    if (this.ballNum <= 0) {
      // 游戏结束
      this.overFun();
    }
    // this.addLineFun();
  },
  onGameOver(totalScore) {
    console.log(totalScore)
    my.alert({
      content: "游戏结束"
    })
  },


  changeFun() {
    this.setData({
      showGame: !this.data.showGame
    })
  },
  beginFun() {
    this.ballNum = 5;
    this.gameComponent.onEvent("start");
  },
  overFun() {
    this.gameComponent.onEvent("gameOver");
  },
  resetFun() {
    this.gameComponent.onEvent("reset", true);
  },
  addLineFun() {
    // 添加一行
    this.gameComponent.onEvent("addLine");
  },
  renderNextFun() {
    // 刷新
    this.gameComponent.onEvent("renderSendBall");//刷新当前发射求
    // this.gameComponent.onEvent("nextBall");//刷新下一个
  },
  helpFun() {
    // 开启辅助线
    this.gameComponent.onEvent("showHelpLine", 3);
  },
  closeFun() {
    // 关闭辅助线
    this.gameComponent.onEvent("triggerHelpLine", !true);
  },
  fadeLineFun() {
    // 消除指定行
    if (this.gameComponent.onEvent("getSpriteCount").length <= 0) {
      my.showToast({
        content: "没有泡泡，无法使用"
      });
      return false;
    }
    this.gameComponent.onEvent("fadeLineFun");
  },
  fadeEndLineFun() {
    // 消除最后一行
    if (this.gameComponent.onEvent("getSpriteCount").length <= 0) {
      my.showToast({
        content: "没有泡泡，无法使用"
      });
      return false;
    }
    this.gameComponent.onEvent("fadeLineFun", "end");
  },
  boomFun() {
    // 技能求
    this.gameComponent.onEvent("boomFun", {
      num: 3,
      notGo: true,
      callback: (isSuccess) => {
        if (isSuccess) {
          console.log("等待接口返回成功就执行...")
          setTimeout(() => {
            this.gameComponent.onEvent("boomFun", { num: 3, });
          }, 3000);
        } else {
          console.log("----------不能生成炸弹")
        }
      }
    });
  },
});
```

- xaml

```
  <view>
    <view style="height: 5vh;">总分数：{{totalScore || 0}} 本次消除分数：{{curScore|| 0}} 剩余泡泡：{{gameSource.totalBall}} 特殊泡泡：{{special}}</view>
    <view style="width: 750rpx;height: 1000rpx;margin:0 auto;position:relative;background:#ccc;">
      <game gameSource="{{gameSource}}" onRef="onRef" onInitDone="onInitDone" onRenderPlay="onRenderPlay" onUpdate="onUpdate" onGameOver="onGameOver" />
    </view>

    <view onTap="renderNextFun" style="position:absolute;left: 300rpx;bottom: 100rpx;">生成下一个</view>
    <view onTap="closeFun" style="position:absolute;left: 500rpx;bottom: 100rpx;">关闭辅助线</view>

    <view onTap="fadeLineFun" style="position:absolute;left: 100rpx;bottom: 50rpx;">消除指定行</view>
    <view onTap="boomFun" style="position:absolute;left: 300rpx;bottom: 50rpx;">生成炸弹</view>
    <view onTap="fadeEndLineFun" style="position:absolute;left: 500rpx;bottom: 50rpx;">消除最后一行</view>

    <view onTap="beginFun" style="position:absolute;left: 100rpx;bottom: 0;">开始</view>
    <view onTap="overFun" style="position:absolute;left: 200rpx;bottom: 0;">停止</view>
    <view onTap="resetFun" style="position:absolute;left: 300rpx;bottom: 0;">重置</view>
    <view onTap="addLineFun" style="position:absolute;left: 400rpx;bottom: 0;">再生成一行</view>
    <view onTap="helpFun" style="position:absolute;left: 550rpx;bottom: 0;">开启辅助线</view>
  </view>
```