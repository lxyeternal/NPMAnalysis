import { Observable } from 'rxjs';
import { getTestScheduler } from './scheduler';
export class TestColdObservable extends Observable {
    constructor(marbles, values, error) {
        super();
        this.marbles = marbles;
        this.values = values;
        this.error = error;
        this.source = getTestScheduler().createColdObservable(marbles, values, error);
    }
    getSubscriptions() {
        return this.source['subscriptions'];
    }
}
export class TestHotObservable extends Observable {
    constructor(marbles, values, error) {
        super();
        this.marbles = marbles;
        this.values = values;
        this.error = error;
        this.source = getTestScheduler().createHotObservable(marbles, values, error);
    }
    getSubscriptions() {
        return this.source['subscriptions'];
    }
}
//# sourceMappingURL=test-observables.js.map