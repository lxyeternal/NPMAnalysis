import { Notification, Observable } from 'rxjs';
import { TestScheduler } from 'rxjs/testing';
import { getTestScheduler, initTestScheduler, resetTestScheduler } from './src/scheduler';
import { TestColdObservable, TestHotObservable } from './src/test-observables';
export { getTestScheduler, initTestScheduler, resetTestScheduler } from './src/scheduler';
export function hot(marbles, values, error) {
    return new TestHotObservable(marbles.trim(), values, error);
}
export function cold(marbles, values, error) {
    return new TestColdObservable(marbles.trim(), values, error);
}
export function time(marbles) {
    return getTestScheduler().createTime(marbles.trim());
}
/*
* Based on source code found in rxjs library
* https://github.com/ReactiveX/rxjs/blob/master/src/testing/TestScheduler.ts
*
*/
function materializeInnerObservable(observable, outerFrame) {
    const messages = [];
    const scheduler = getTestScheduler();
    observable.subscribe(value => {
        messages.push({
            frame: scheduler.frame - outerFrame,
            notification: Notification.createNext(value)
        });
    }, err => {
        messages.push({
            frame: scheduler.frame - outerFrame,
            notification: Notification.createError(err)
        });
    }, () => {
        messages.push({
            frame: scheduler.frame - outerFrame,
            notification: Notification.createComplete()
        });
    });
    return messages;
}
export function addMatchers() {
    jasmine.addMatchers({
        toHaveSubscriptions: () => ({
            compare: function (actual, marbles) {
                const marblesArray = typeof marbles === 'string' ? [marbles] : marbles;
                const results = marblesArray.map(marbles => TestScheduler.parseMarblesAsSubscriptions(marbles));
                expect(results).toEqual(actual.getSubscriptions());
                return { pass: true };
            }
        }),
        toBeObservable: () => ({
            compare: function (actual, fixture) {
                const results = [];
                let subscription;
                const scheduler = getTestScheduler();
                scheduler.schedule(() => {
                    subscription = actual.subscribe((x) => {
                        let value = x;
                        // Support Observable-of-Observables
                        if (x instanceof Observable) {
                            value = materializeInnerObservable(value, scheduler.frame);
                        }
                        results.push({
                            frame: scheduler.frame,
                            notification: Notification.createNext(value)
                        });
                    }, (err) => {
                        results.push({
                            frame: scheduler.frame,
                            notification: Notification.createError(err)
                        });
                    }, () => {
                        results.push({
                            frame: scheduler.frame,
                            notification: Notification.createComplete()
                        });
                    });
                });
                scheduler.flush();
                const expected = TestScheduler.parseMarbles(fixture.marbles, fixture.values, fixture.error, true);
                expect(results).toEqual(expected);
                return { pass: true };
            }
        })
    });
}
if (typeof module === 'object' && module.exports) {
    jasmine.getEnv().beforeAll(() => addMatchers());
    jasmine.getEnv().beforeEach(() => initTestScheduler());
    jasmine.getEnv().afterEach(() => {
        getTestScheduler().flush();
        resetTestScheduler();
    });
}
//# sourceMappingURL=index.js.map