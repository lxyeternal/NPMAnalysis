# Changelog 


## 0.0.9 / 2017-05-24 

  * [[24f0404](http://gitlab.alibaba-inc.com/nuke/list-swipe-item/commit/24f0404da1d845b9f612a2efac91d766268268d4)] - `fix` 默认nuke为peer 

## 0.0.8 / 2017-04-18 

  * [[cac26e5](http://gitlab.alibaba-inc.com/nuke/list-swipe-item/commit/cac26e507eb5f39094350f72b27604b4fdf39ec2)] - `fix` 修改驼峰事件，以支持rax0.2.2以上版本 

## 0.0.6 / 2017-03-31 

  * [[bc5b323](http://gitlab.alibaba-inc.com/nuke/list-swipe-item/commit/bc5b323ea65513c383f99cd4bb96181b6469d032)] - `fix` 修复android下无法滑动的问题，以及拖拽结束后的卡顿 
  * [[3bb26bf](http://gitlab.alibaba-inc.com/nuke/list-swipe-item/commit/3bb26bf350c9e3ddc4192c8d3cd54c7676f47ffc)] - `fix` android delay 

## 0.0.5 / 2017-03-29 

  * [[35f140d](http://gitlab.alibaba-inc.com/nuke/list-swipe-item/commit/35f140d80812a6d3be1638b6faf2622129e3a34a)] - `perf` 增加移除注册监听器的逻辑 

## 0.0.4 / 2017-03-29 

  * [[47a10ea](http://gitlab.alibaba-inc.com/nuke/list-swipe-item/commit/47a10ea95a7cb197f120fe1e6eb2051a7a7f4fbb)] - `docs` 增加兼容性说明 
  * [[9d434bc](http://gitlab.alibaba-inc.com/nuke/list-swipe-item/commit/9d434bcd7967944f9505853de1636cc8b85087dc)] - `perf` expressionBingding 

## 0.0.2 / 2017-03-25 

  * [[7d51911](http://gitlab.alibaba-inc.com/nuke/list-swipe-item/commit/7d51911f0ea7d639e884d274c1a8b72e2a497276)] - `fix` 第一项无法触发主动关闭 
  * [[5cf3cc1](http://gitlab.alibaba-inc.com/nuke/list-swipe-item/commit/5cf3cc1c9e9511acdf0f827cc700bb434a62186f)] - `feat` 事件外抛done 
  * [[295f9e8](http://gitlab.alibaba-inc.com/nuke/list-swipe-item/commit/295f9e873c94ecf2564f6c5d91f20edcdd4bd9e7)] - `fix` 逆向滑动 
  * [[92d6f48](http://gitlab.alibaba-inc.com/nuke/list-swipe-item/commit/92d6f48838c5ad7627d5f4dd3ff9d635de54337c)] - `fix` 事件外抛 
  * [[219d8b6](http://gitlab.alibaba-inc.com/nuke/list-swipe-item/commit/219d8b6d4199186b869fbd1f39a6cc5d8e8846ba)] - `fix` IOS左滑显示右侧button完成，weex存在滑动帧数丢失的情况 
  * [[0c99f1f](http://gitlab.alibaba-inc.com/nuke/list-swipe-item/commit/0c99f1fb0f51304279d09cf717361dd3f20ca52f)] - `fix` 滑动闪烁 

## 0.0.1 / 2017-03-24 

  * [[2af4e84](http://gitlab.alibaba-inc.com/nuke/list-swipe-item/commit/2af4e8414d7c4787c7119925dfa89d935875bdb6)] - `feat` init repo 
