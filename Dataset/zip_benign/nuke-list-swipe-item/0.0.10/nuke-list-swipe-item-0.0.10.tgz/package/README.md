
# NukeListSwipeItem

- category: BizComponent
- chinese: listView子组件用于实现左右滑动
- type: 基本

---

## API

参数 | 说明 | 类型 | 默认值
-----|-----|-----|-----
onPress | 点击触发事件 |func | () |
longPress | 长按触发事件,ios无法再长按状态下进行滑动，仅在`disabledSwipe`状态下可触发长按事件 | func | () |
touchStart | 非press触摸，触发条件没有onPress严格，用于配合实现滚动隐藏滑动项目 | func |
style  | list item点击区域外观 | object | {} |
itemStyle  | list item滑块外观 | object | {} |
rightBtn | 右侧滑动出现的列表 | array | [] |
leftBtn | 左侧滑动出现的列表 | array | [] |
indent | 滑动回弹距离 | number | 100 |
id | 当前item的唯一标识，建议制定，不建议使用序列index| string |  |
expand | 滑块展开的回调 | function | (e) |
threshold |自动收回的阈值 | number | 0.5 |
disabledSwipe | 禁用左右滑动  | bool | false |
current | 当前点击项目 | string | '' |
deleteAnimation | 移除item的动画效果[todo] | string | default、none |
insertAnimation(string) | 插入item的动画效果[todo] | string | default、none |
> 在该组件中添加id等同于为cell添加key，可以优化列表的重绘效率，同时滑块的自动隐藏也依赖于id

> 手势组件在android低端机型下会存在卡顿，建议在android机采用长按触发实现交互。

> 如需主动关闭当前滑动，只需将current置空

- rightBtn | leftBtn 的内容需满足

```
let rightBtn = [{
    id: '按钮1的唯一标识',
	text: '按钮1内的文字内容',
	style:{
        height:80,
        backgroundColor:'#ffffff'
    },
    textStyle:{
        color:'black'
    }
    onPress: (e,item)=>{console.log('delete1!');},
}, {
    id: '按钮2的唯一标识',
	text: '按钮2内的文字内容',
	style:{
        height:80,
        backgroundColor:'#ffffff'
    },
    textStyle:{
        color:'black'
    }
    onPress: ()=>{console.log('delete1!');},
}]
```

使用细节请参考：`docs/basic.md`

*注意*  

本组件依赖于aliweex最新expressBinding新特性，低于`5.8.7的IOS千牛`及`手淘iOS 6.4.0``天猫 iOS 5.30.1` `手淘 Android 6.3.0`` 天猫 Android 5.28.1`无法拖拽，只能通过disable拖拽改为长按降级。


