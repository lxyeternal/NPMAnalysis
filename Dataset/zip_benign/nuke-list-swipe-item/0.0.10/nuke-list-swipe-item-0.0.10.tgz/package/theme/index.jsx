/** @jsx createElement */
import {createElement, Component,render} from 'rax';
import {View,Text} from 'nuke';

let App = class NukeDemoIndex extends Component {
    constructor() {
        super();
    }

    render() {
        return (
            <View>
                <Text>这是一个主题目录，应该配合nuke-demo尽量列出组件的所有使用方式</Text>
            </View>
        );
    }
}

render(<App/>);
