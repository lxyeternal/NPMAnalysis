# 组件特性1

- order: 0

简单的文档描述

---

````js

/** @jsx createElement */
import {createElement, Component,render} from 'rax';
import {View,Text,ListView,Modal} from 'nuke';
import SwipeItem from 'nuke-list-swipe-item';

let listData = [{
    key:'data1',text:'数据数据数据数据数据数据数据数据数据数据'
},{
    key:'data2',text:'数据数据数据数据数据数据数据数据数据数据'
},{
    key:'data3',text:'数据数据数据数据数据数据数据数据数据数据'
},{
    key:'data4',text:'数据数据数据数据数据数据数据数据数据数据'
},{
    key:'data5',text:'数据数据数据数据数据数据数据数据数据数据'
},{
    key:'data6',text:'数据数据数据数据数据数据数据数据数据数据'
}];


const rightBtn = [{
    id: 'top',
	text: '置顶',
	style:{
        height:140,
        width:150,
        backgroundColor:'blue',
        justifyContent:'center',
        flexDirection:'row'
    },
    onPress: ()=>{console.log('top')}
},{
    id: 'more',
	text: '更多',
	style:{
        height:140,
        width:150,
        backgroundColor:'green',
        justifyContent:'center',
        flexDirection:'row'
    },
    onPress: (e,item,id)=>{console.log(e,item,id)},
}];


let App = class NukeDemoIndex extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data:listData,
            current:''
        }
        this.leftBtn = [{
            id: 'delete',
            text: '删除',
            style:{
                height:140,
                width:100,
                backgroundColor:'red',
                justifyContent:'center',
                flexDirection:'row'
            },
            textStyle:{
                color:'black'
            },
            onPress: (e,item,id)=>{
                this.setState({
                    current:''
                });
                console.log(e,item,id);
                },
        }];
    }
    
    componentDidMount(){
   
    }


    renderItem=(item)=>{
        return <SwipeItem style={CSS.cellItemList} 
                onPress={this.itemPress} 
                onLongPress={this.itemLongPress} 
                id={item.key} 
                touchStart={this.touchStart} 
                current={this.state.current} 
                threshold={0.1}
                rightBtn={rightBtn}
                leftBtn ={this.leftBtn}
                itemStyle={CSS.childContainer}
                indent={20}
                disabledSwipe={false}
                >
                <Text style={CSS.itemTextList}>{item.text}</Text>
            </SwipeItem>;
    }

    itemPress = (e) =>{
        Modal.toast('press');
        console.log('》》》》》press');
    }

    itemLongPress = (e) =>{
        Modal.toast('longpress');
        console.log('》》》》》longpress');
    }
    
    touchStart = (e) => {
       // Modal.toast('touchStart');
        console.log('>>>>touchStart');
        if(this.state.current != e.id){
            this.setState({
                current:e.id
            })
        }
    }

    render() {
        return (
            <ListView
                renderRow={this.renderItem}
                dataSource={this.state.data}
                ref = "mylist"
                style={CSS.listContainer}>
            </ListView>
        );
    }
}

const CSS = {
    header:{
        height:100,
        borderBottomWidth:"2rem",
        borderBottomStyle:"solid",
        borderBottomColor:"#e8e8e8"
    },
    listContainer:{
        flex:1
    },
    childContainer: {
        backgroundColor: '#ffffff',
        flex: 1,
        height: 140,
        borderBottomWidth:"2rem",
        borderBottomStyle:"solid",
        borderBottomColor:"#e8e8e8",
        alignItems: "center",
        justifycontent: "center",
        flexDirection: "row"
    },
    cellItemList:{
        backgroundColor:"#333333",
        height:"140rem",
        alignItems:"center",
        flexDirection:"row"
    },
    itemTextList:{
        color:"#EB7E10"
    }
}
render(<App/>);

````
