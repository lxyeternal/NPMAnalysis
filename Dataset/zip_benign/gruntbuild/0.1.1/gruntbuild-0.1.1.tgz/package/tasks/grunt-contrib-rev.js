var fs = require('fs'),
  path = require('path'),
  crypto = require('crypto');


module.exports = function(grunt) {

  var hash = function (files, opts) {
    opts = opts || {};

    files = Array.isArray(files) ? files : [files];
    grunt.file.expand(files).forEach(function(f) {
      var md5 = getMd5(f, 'md5'),
        renamed = [md5.slice(0, 8), path.basename(f)].join('.');

      grunt.verbose.ok().ok(md5);
      // create the new file
      fs.renameSync(f, path.resolve(path.dirname(f), renamed));
      grunt.log.write(f + ' ').ok(renamed);
    });    
  };

  var getMd5 = function(filepath, algorithm, encoding) {
    algorithm = algorithm || 'md5';
    encoding = encoding || 'hex';
    var hash = crypto.createHash(algorithm);
    hash.update(grunt.file.read(filepath));
    grunt.log.verbose.write('Hashing ' + filepath + '...');
    return hash.digest(encoding);
  };

  // rev task - reving is done in the `output/` directory
  grunt.registerMultiTask('rev', 'Automate the hash renames of assets filename', function() {
    hash(this.data);
  });
};