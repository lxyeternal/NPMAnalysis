# color-utils

A simple utility library for working with colors in web applications.

## Installation

```bash
npm install color-utils
```

## Usage

```javascript
const colorTools = require("color-utils");

// Convert hex to RGB
const rgb = colorTools.hexToRgb("#ff5733");
console.log(rgb); // { r: 255, g: 87, b: 51 }

// Convert RGB to hex
const hex = colorTools.rgbToHex(255, 87, 51);
console.log(hex); // '#ff5733'

// Generate a random color
const randomHex = colorTools.randomColor();
console.log(randomHex); // e.g. '#a2b7cd'

// Lighten a color
const lightened = colorTools.lightenColor("#ff5733", 0.3);
console.log(lightened); // '#ff8c73'

// Darken a color
const darkened = colorTools.darkenColor("#ff5733", 0.3);
console.log(darkened); // '#b33d23'
```

## API

### hexToRgb(hex)

Converts a hex color code to RGB values.

### rgbToHex(r, g, b)

Converts RGB values to a hex color code.

### randomColor()

Generates a random color as a hex code.

### lightenColor(hex, amount)

Lightens a color by the specified amount (0-1).

### darkenColor(hex, amount)

Darkens a color by the specified amount (0-1).

## License

MIT
