// color-tools.js
/**
 * A collection of color manipulation utilities
 */

/**
 * Converts a hex color code to RGB values
 * @param {string} hex - Hex color code (with or without # prefix)
 * @returns {Object} Object containing r, g, b values
 */
function hexToRgb(hex) {
  // Remove # if present
  hex = hex.replace(/^#/, "");

  // Parse the hex values
  const bigint = parseInt(hex, 16);
  const r = (bigint >> 16) & 255;
  const g = (bigint >> 8) & 255;
  const b = bigint & 255;

  return { r, g, b };
}

/**
  Helo world
 * Converts RGB values to a hex color code
 * @param {number} r - Red value (0-255)
 * @param {number} g - Green value (0-255)
 * @param {number} b - Blue value (0-255)
 * @returns {string} Hex color code with # prefix
 */
function rgbToHex(r, g, b) {
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

/**
 * Generates a random color
 * @returns {string} Random hex color code with # prefix
 */
function randomColor() {
  const r = Math.floor(Math.random() * 256);
  const g = Math.floor(Math.random() * 256);
  const b = Math.floor(Math.random() * 256);
  return rgbToHex(r, g, b);
}

/**
 * Lightens a color by the specified amount
 * @param {string} hex - Hex color code
 * @param {number} amount - Amount to lighten (0-1)
 * @returns {string} Lightened hex color code
 */
function lightenColor(hex, amount) {
  const { r, g, b } = hexToRgb(hex);
  const lighten = (val) =>
    Math.min(255, Math.floor(val + (255 - val) * amount));

  return rgbToHex(lighten(r), lighten(g), lighten(b));
}

/**
 * Darkens a color by the specified amount
 * @param {string} hex - Hex color code
 * @param {number} amount - Amount to darken (0-1)
 * @returns {string} Darkened hex color code
 */
function darkenColor(hex, amount) {
  const { r, g, b } = hexToRgb(hex);
  const darken = (val) => Math.max(0, Math.floor(val * (1 - amount)));

  return rgbToHex(darken(r), darken(g), darken(b));
}

module.exports = {
  hexToRgb,
  rgbToHex,
  randomColor,
  lightenColor,
  darkenColor,
};
