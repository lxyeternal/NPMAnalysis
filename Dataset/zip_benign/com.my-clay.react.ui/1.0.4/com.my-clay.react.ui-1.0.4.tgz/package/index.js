var Input = require('./dist/input').default;
var DropDown = require('./dist/dropdown').default;
var DropDownMenu = require('./dist/dropdown/menu').default;
var DropDownTrigger = require('./dist/dropdown/trigger').default;
var Img = require('./dist/img').default;
var Loading = require('./dist/loading').default;
var Validation = require('./dist/validation').default;
var Button = require('./dist/button').default;
var Checkbox = require('./dist/checkbox').default;
var Pagination = require('./dist/pagination').default;
var Radio = require('./dist/radio').default;

module.exports = {
  Input: Input,
  Validation: Validation,
  DropDown: DropDown,
  DropDownMenu: DropDownMenu,
  DropDownTrigger: DropDownTrigger,
  Img: Img,
  Loading: Loading,
  Button: Button,
  Checkbox: Checkbox,
  Radio: Radio,
  Pagination: Pagination
};
