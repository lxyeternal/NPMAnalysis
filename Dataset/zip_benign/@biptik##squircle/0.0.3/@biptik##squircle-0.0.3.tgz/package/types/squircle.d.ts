import * as React from 'react';
interface Bounds {
    readonly width: number;
    readonly height: number;
}
export declare function getMaskStyle(bounds: Bounds, props: SquircleProps): React.CSSProperties;
export interface SquircleImgProps {
    width: number;
    height: number;
    href: string | undefined;
    style?: React.CSSProperties;
    ratio1?: number;
    ratio2?: number;
    backgroundColor?: string;
    strokeColor?: string;
    strokeWidth?: number;
}
export declare const SquircleImg: (props: SquircleImgProps) => JSX.Element;
export interface SquircleProps {
    ratio1?: number;
    ratio2?: number;
    pixelRatio1?: number;
    pixelRatio2?: number;
    children: React.ReactNode;
}
declare const Squircle: (props: SquircleProps & React.HTMLAttributes<HTMLDivElement>) => JSX.Element;
export default Squircle;
