export declare function calcSquirclePath(width: number, height: number, ratio1: number, ratio2: number): string;
export declare function getSquirclePathAsDataUri(width: number, height: number, ratio1: number, ratio2: number): {
    id: string;
    svg: string;
    dataUri: string;
};
export declare function svg2DataUri(data: string): string;
