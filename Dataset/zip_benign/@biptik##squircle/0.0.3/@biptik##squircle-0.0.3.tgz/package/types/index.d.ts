import Squircle from './squircle';
export * from './preset';
export * from './squircle';
export default Squircle;
