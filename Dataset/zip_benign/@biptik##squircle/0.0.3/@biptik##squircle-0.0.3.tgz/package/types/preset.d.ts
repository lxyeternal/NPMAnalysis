export declare const Preset: {
    iOS: {
        ratio1: number;
        ratio2: number;
    };
    KakaoTalk: {
        ratio1: number;
        ratio2: number;
    };
};
