export declare const sigmoid: (x: number, gain: number) => number;
export declare const makeSigmoid: ({ center, deviation, deviation_output, }: {
    center: number;
    deviation: number;
    deviation_output: number;
}) => (x: number) => number;
export default makeSigmoid;
