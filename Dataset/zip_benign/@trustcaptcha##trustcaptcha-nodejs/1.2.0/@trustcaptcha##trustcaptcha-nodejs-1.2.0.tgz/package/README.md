# Trustcaptcha NodeJS-Library

The NodeJS library helps you to integrate Trustcaptcha into your NodeJS backend applications.


## What is Trustcaptcha?

A captcha solution that protects you from bot attacks and puts a special focus on user experience and data protection.

You can find more information on your website: [www.trustcaptcha.com](https://www.trustcaptcha.com).


## How does the library work?

Detailed instructions and examples for using the library can be found in our [documentation](https://docs.trustcaptcha.com/en/backend/integration?backend=nodejs).


## Short example

Here you can see a short code example of a possible integration. Please refer to our provided [documentation](https://docs.trustcaptcha.com/en/backend/integration?backend=nodejs) for complete and up-to-date integration instructions.

Installing the library

``npm i @trustcaptcha/trustcaptcha-nodejs``

Fetching and handling the result

```
// Retrieving the verification result
let verificationResult = await CaptchaManager.getVerificationResult("<your_secret_key>", verificationToken);

// Do something with the verification result
if (!verificationResult.verificationPassed || verificationResult.score > 0.5) {
    console.log("Verification failed, or bot score is higher than 0.5 – this could indicate a bot.");
}
```

## Ideas and support

If you have any ideas, suggestions, or need support, please [contact us](https://www.trustcaptcha.com/en/contact-us).
