// Retrieve all data-iva targets
const observerElements = [...document.querySelectorAll('[data-iva]')];
// Start Observing all Observer targets
observerElements.forEach((el) => {
    let threshold = el.dataset.ivaThreshold ? parseFloat(el.dataset.ivaThreshold) : 0.4;
    new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            let delay = entry.target.dataset.ivaDelay != undefined ? parseFloat(entry.target.dataset.ivaDelay) : 0;
            let duration = entry.target.dataset.ivaDuration ? parseFloat(entry.target.dataset.ivaDuration) : 0.5;

            entry.target.style.transitionDuration = `${duration}s`;
            entry.target.style.transitionDelay = `${delay}s`;
            
            if (entry.isIntersecting) {
                entry.target.classList.add('show');
            }
        });
    }, 
    // Options
    {
        rootMargin: '0px 0px -60px',
        threshold: threshold
    }
    // Start Observing target
    ).observe(el);
});