export declare function safeMultiply(a: number, b: number): number;
