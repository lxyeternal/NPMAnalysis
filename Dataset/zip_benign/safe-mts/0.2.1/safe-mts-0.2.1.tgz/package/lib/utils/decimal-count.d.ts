export declare function decimalCount(val: number): number;
export declare function issScientific(val: number): boolean;
