export declare function parseScientific(num: string): string;
