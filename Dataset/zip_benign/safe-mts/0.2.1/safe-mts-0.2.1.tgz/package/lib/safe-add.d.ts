export declare function safeAdd(a: number, b: number): number;
