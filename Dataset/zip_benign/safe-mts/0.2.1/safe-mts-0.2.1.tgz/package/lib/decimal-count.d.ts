export declare function decimalCount(val: number): number;
