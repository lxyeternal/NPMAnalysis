export declare function safeSubtract(a: number, b: number): number;
