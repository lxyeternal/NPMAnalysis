import { Component, EventEmitter, Input, Output, Inject, LOCALE_ID } from '@angular/core';
import { CalendarService } from './calendar.service';
export var Step;
(function (Step) {
    Step[Step["QuarterHour"] = 15] = "QuarterHour";
    Step[Step["HalfHour"] = 30] = "HalfHour";
    Step[Step["Hour"] = 60] = "Hour";
})(Step || (Step = {}));
var CalendarComponent = (function () {
    function CalendarComponent(calendarService, appLocale) {
        this.calendarService = calendarService;
        this.appLocale = appLocale;
        this.eventSource = [];
        this.calendarMode = 'month';
        this.formatDay = 'd';
        this.formatDayHeader = 'EEE';
        this.formatDayTitle = 'MMMM dd, yyyy';
        this.formatWeekTitle = 'MMMM yyyy, Week $n';
        this.formatMonthTitle = 'MMMM yyyy';
        this.formatWeekViewDayHeader = 'EEE d';
        this.formatHourColumn = 'j';
        this.showEventDetail = true;
        this.startingDayMonth = 0;
        this.startingDayWeek = 0;
        this.allDayLabel = 'all day';
        this.noEventsLabel = 'No Events';
        this.queryMode = 'local';
        this.step = Step.Hour;
        this.autoSelect = true;
        this.dir = "";
        this.scrollToHour = 0;
        this.preserveScrollPosition = false;
        this.lockSwipeToPrev = false;
        this.lockSwipes = false;
        this.locale = "";
        this.startHour = 0;
        this.endHour = 24;
        this.spaceBetween = 0;
        this.onCurrentDateChanged = new EventEmitter();
        this.onRangeChanged = new EventEmitter();
        this.onEventSelected = new EventEmitter();
        this.onTimeSelected = new EventEmitter();
        this.onTitleChanged = new EventEmitter();
        this.hourParts = 1;
        this.locale = appLocale;
    }
    Object.defineProperty(CalendarComponent.prototype, "currentDate", {
        get: function () {
            return this._currentDate;
        },
        set: function (val) {
            if (!val) {
                val = new Date();
            }
            this._currentDate = val;
            this.calendarService.setCurrentDate(val, true);
            this.onCurrentDateChanged.emit(this._currentDate);
        },
        enumerable: true,
        configurable: true
    });
    CalendarComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.autoSelect) {
            if (this.autoSelect.toString() === 'false') {
                this.autoSelect = false;
            }
            else {
                this.autoSelect = true;
            }
        }
        this.hourParts = 60 / this.step;
        this.startHour = parseInt(this.startHour.toString());
        this.endHour = parseInt(this.endHour.toString());
        this.calendarService.queryMode = this.queryMode;
        this.currentDateChangedFromChildrenSubscription = this.calendarService.currentDateChangedFromChildren$.subscribe(function (currentDate) {
            _this._currentDate = currentDate;
            _this.onCurrentDateChanged.emit(currentDate);
        });
    };
    CalendarComponent.prototype.ngOnDestroy = function () {
        if (this.currentDateChangedFromChildrenSubscription) {
            this.currentDateChangedFromChildrenSubscription.unsubscribe();
            this.currentDateChangedFromChildrenSubscription = null;
        }
    };
    CalendarComponent.prototype.rangeChanged = function (range) {
        this.onRangeChanged.emit(range);
    };
    CalendarComponent.prototype.eventSelected = function (event) {
        this.onEventSelected.emit(event);
    };
    CalendarComponent.prototype.timeSelected = function (timeSelected) {
        this.onTimeSelected.emit(timeSelected);
    };
    CalendarComponent.prototype.titleChanged = function (title) {
        this.onTitleChanged.emit(title);
    };
    CalendarComponent.prototype.loadEvents = function () {
        this.calendarService.loadEvents();
    };
    return CalendarComponent;
}());
export { CalendarComponent };
CalendarComponent.decorators = [
    { type: Component, args: [{
                selector: 'calendar',
                template: "<ng-template #monthviewDefaultDisplayEventTemplate let-view=\"view\" let-row=\"row\" let-col=\"col\">             {{view.dates[row*7+col].label}}         </ng-template>         <ng-template #monthviewDefaultEventDetailTemplate let-showEventDetail=\"showEventDetail\" let-selectedDate=\"selectedDate\" let-noEventsLabel=\"noEventsLabel\">             <ion-list class=\"event-detail-container\" has-bouncing=\"false\" *ngIf=\"showEventDetail\" overflow-scroll=\"false\">                 <ion-item *ngFor=\"let event of selectedDate?.events\" tappable  (click)=\"eventSelected(event)\">                         <span *ngIf=\"!event.allDay\" class=\"monthview-eventdetail-timecolumn\">{{event.startTime|date: 'HH:mm'}}                         </span>                     <span *ngIf=\"event.allDay\" class=\"monthview-eventdetail-timecolumn\">{{allDayLabel}}</span>           <span class=\"event-detail\">{{event.title}}</span>            <span *ngIf=\"event.convidado\" style=\"float:right;margin: 0px 5px;\"><ion-icon name=\"ios-mail-open\"></ion-icon></span>   <ion-icon *ngIf=\"event.admin\" style=\"float:right;\" name=\"cog\"></ion-icon>          </ion-item>                 <ion-item *ngIf=\"selectedDate?.events.length==0\">                     <div class=\"no-events-label\">{{noEventsLabel}}</div>                 </ion-item>             </ion-list>         </ng-template>         <ng-template #defaultAllDayEventTemplate let-displayEvent=\"displayEvent\">             <div class=\"calendar-event-inner\">{{displayEvent.event.title}}</div>         </ng-template>         <ng-template #defaultNormalEventTemplate let-displayEvent=\"displayEvent\">             <div class=\"calendar-event-inner\">{{displayEvent.event.title}}</div>         </ng-template>          <div [ngSwitch]=\"calendarMode\" class=\"{{calendarMode}}view-container\">             <monthview *ngSwitchCase=\"'month'\"                 [formatDay]=\"formatDay\"                 [formatDayHeader]=\"formatDayHeader\"                 [formatMonthTitle]=\"formatMonthTitle\"                 [startingDayMonth]=\"startingDayMonth\"                 [showEventDetail]=\"showEventDetail\"                 [noEventsLabel]=\"noEventsLabel\"                 [autoSelect]=\"autoSelect\"                 [eventSource]=\"eventSource\"                 [markDisabled]=\"markDisabled\"                 [monthviewDisplayEventTemplate]=\"monthviewDisplayEventTemplate||monthviewDefaultDisplayEventTemplate\"                 [monthviewInactiveDisplayEventTemplate]=\"monthviewInactiveDisplayEventTemplate||monthviewDefaultDisplayEventTemplate\"                 [monthviewEventDetailTemplate]=\"monthviewEventDetailTemplate||monthviewDefaultEventDetailTemplate\"                 [locale]=\"locale\"                 [dateFormatter]=\"dateFormatter\"                 [dir]=\"dir\"                 [lockSwipeToPrev]=\"lockSwipeToPrev\"                 [lockSwipes]=\"lockSwipes\"                 [spaceBetween]=\"spaceBetween\"                        (onRangeChanged)=\"rangeChanged($event)\"                 (onEventSelected)=\"eventSelected($event)\"                 (onTimeSelected)=\"timeSelected($event)\"                 (onTitleChanged)=\"titleChanged($event)\">             </monthview>             <weekview *ngSwitchCase=\"'week'\"                 [formatWeekTitle]=\"formatWeekTitle\"                 [formatWeekViewDayHeader]=\"formatWeekViewDayHeader\"                 [formatHourColumn]=\"formatHourColumn\"                 [startingDayWeek]=\"startingDayWeek\"                 [allDayLabel]=\"allDayLabel\"                 [hourParts]=\"hourParts\"                 [eventSource]=\"eventSource\"                 [markDisabled]=\"markDisabled\"                 [weekviewAllDayEventTemplate]=\"weekviewAllDayEventTemplate||defaultAllDayEventTemplate\"                 [weekviewNormalEventTemplate]=\"weekviewNormalEventTemplate||defaultNormalEventTemplate\"                 [locale]=\"locale\"                 [dateFormatter]=\"dateFormatter\"                 [dir]=\"dir\"                 [scrollToHour]=\"scrollToHour\"                 [preserveScrollPosition]=\"preserveScrollPosition\"                 [lockSwipeToPrev]=\"lockSwipeToPrev\"                 [lockSwipes]=\"lockSwipes\"                 [startHour]=\"startHour\"                 [endHour]=\"endHour\"                 [spaceBetween]=\"spaceBetween\"                 (onRangeChanged)=\"rangeChanged($event)\"                 (onEventSelected)=\"eventSelected($event)\"                 (onTimeSelected)=\"timeSelected($event)\"                 (onTitleChanged)=\"titleChanged($event)\">             </weekview>             <dayview *ngSwitchCase=\"'day'\"                 [formatDayTitle]=\"formatDayTitle\"                 [formatHourColumn]=\"formatHourColumn\"                 [allDayLabel]=\"allDayLabel\"                 [hourParts]=\"hourParts\"                 [eventSource]=\"eventSource\"                 [markDisabled]=\"markDisabled\"                 [dayviewAllDayEventTemplate]=\"dayviewAllDayEventTemplate||defaultAllDayEventTemplate\"                 [dayviewNormalEventTemplate]=\"dayviewNormalEventTemplate||defaultNormalEventTemplate\"                 [locale]=\"locale\"                 [dateFormatter]=\"dateFormatter\"                 [dir]=\"dir\"                 [scrollToHour]=\"scrollToHour\"                 [preserveScrollPosition]=\"preserveScrollPosition\"                 [lockSwipeToPrev]=\"lockSwipeToPrev\"                 [lockSwipes]=\"lockSwipes\"                 [startHour]=\"startHour\"                 [endHour]=\"endHour\"                 [spaceBetween]=\"spaceBetween\"                 (onRangeChanged)=\"rangeChanged($event)\"                 (onEventSelected)=\"eventSelected($event)\"                 (onTimeSelected)=\"timeSelected($event)\"                 (onTitleChanged)=\"titleChanged($event)\">             </dayview>         </div>",
                styles: [":host > div { height: 100%; }        .event-detail-container {          border-top: 2px darkgrey solid;        }        .no-events-label {          font-weight: bold;          color: darkgrey;          text-align: center;        }        .event-detail {          cursor: pointer;          white-space: nowrap;          text-overflow: ellipsis;        }        .monthview-eventdetail-timecolumn {          width: 110px;          overflow: hidden;        }        .calendar-event-inner {          overflow: hidden;          background-color: #3a87ad;          color: white;          height: 100%;          width: 100%;          padding: 2px;          line-height: 15px;        }        @media (max-width: 750px) {          .calendar-event-inner {            font-size: 12px;          }        }"],
                providers: [CalendarService]
            },] },
];
CalendarComponent.ctorParameters = function () { return [
    { type: CalendarService, },
    { type: undefined, decorators: [{ type: Inject, args: [LOCALE_ID,] },] },
]; };
CalendarComponent.propDecorators = {
    'currentDate': [{ type: Input },],
    'eventSource': [{ type: Input },],
    'calendarMode': [{ type: Input },],
    'formatDay': [{ type: Input },],
    'formatDayHeader': [{ type: Input },],
    'formatDayTitle': [{ type: Input },],
    'formatWeekTitle': [{ type: Input },],
    'formatMonthTitle': [{ type: Input },],
    'formatWeekViewDayHeader': [{ type: Input },],
    'formatHourColumn': [{ type: Input },],
    'showEventDetail': [{ type: Input },],
    'startingDayMonth': [{ type: Input },],
    'startingDayWeek': [{ type: Input },],
    'allDayLabel': [{ type: Input },],
    'noEventsLabel': [{ type: Input },],
    'queryMode': [{ type: Input },],
    'step': [{ type: Input },],
    'autoSelect': [{ type: Input },],
    'markDisabled': [{ type: Input },],
    'monthviewDisplayEventTemplate': [{ type: Input },],
    'monthviewInactiveDisplayEventTemplate': [{ type: Input },],
    'monthviewEventDetailTemplate': [{ type: Input },],
    'weekviewAllDayEventTemplate': [{ type: Input },],
    'weekviewNormalEventTemplate': [{ type: Input },],
    'dayviewAllDayEventTemplate': [{ type: Input },],
    'dayviewNormalEventTemplate': [{ type: Input },],
    'weekviewAllDayEventSectionTemplate': [{ type: Input },],
    'weekviewNormalEventSectionTemplate': [{ type: Input },],
    'dayviewAllDayEventSectionTemplate': [{ type: Input },],
    'dayviewNormalEventSectionTemplate': [{ type: Input },],
    'dateFormatter': [{ type: Input },],
    'dir': [{ type: Input },],
    'scrollToHour': [{ type: Input },],
    'preserveScrollPosition': [{ type: Input },],
    'lockSwipeToPrev': [{ type: Input },],
    'lockSwipes': [{ type: Input },],
    'locale': [{ type: Input },],
    'startHour': [{ type: Input },],
    'endHour': [{ type: Input },],
    'spaceBetween': [{ type: Input },],
    'onCurrentDateChanged': [{ type: Output },],
    'onRangeChanged': [{ type: Output },],
    'onEventSelected': [{ type: Output },],
    'onTimeSelected': [{ type: Output },],
    'onTitleChanged': [{ type: Output },],
};
//# sourceMappingURL=calendar.js.map