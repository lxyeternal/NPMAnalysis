export default class BionicReadHelp extends HTMLElement {
    static get tagName(): string;
    static get attributes(): Readonly<{
        "brh-opacity": "brh-opacity";
        "brh-algorithm": "brh-algorithm";
        "brh-type": "brh-type";
        "brh-text-color": "brh-text-color";
    }>;
    static get observedAttributes(): any;
    content: string;
    isBionic: boolean;
    bionicOpacity: number;
    bionicTextColor: string;
    bionicAlgo: number[];
    bionicToolsBar: {
        dom: HTMLSpanElement;
    };
    bionicType: string;
    connectedCallback(): void;
    attributeChangedCallback(name: any, oldValue: any, newValue: any): void;
    updateElement(): void;
    #private;
}
//# sourceMappingURL=bionic-read-help.d.ts.map