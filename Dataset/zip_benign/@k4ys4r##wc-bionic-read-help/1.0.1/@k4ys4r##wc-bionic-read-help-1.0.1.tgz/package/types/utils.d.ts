export function setElementStyleProperties(el: any, style: any): void;
export function toggleAttribute(el: any, name: any): void;
export namespace defaultSetting {
    const bionicAlgorithm: number[];
    namespace bionicTypes {
        let _static: string;
        export { _static as static };
        export let interactive: string;
    }
    const bionicOpacity: number;
    const bionicTextColor: string;
    namespace bionicStyles {
        let global: {
            display: string;
            "flex-direction": string;
            border: string;
            "border-radius": string;
            padding: string;
            overflow: string;
            "text-align": string;
        };
        let label: {
            display: string;
            "justify-content": string;
            "align-items": string;
            gap: string;
            "background-color": string;
            color: string;
            padding: string;
            "border-radius": string;
            border: string;
            "margin-top": string;
            height: string;
            "max-height": string;
        };
        let toolbar: {
            padding: string;
            "background-color": string;
            "margin-left": string;
            "margin-top": string;
            "margin-right": string;
            "margin-bottom": string;
            display: string;
            "flex-wrap": string;
            "flex-direction": string;
            "justify-content": string;
            "align-items": string;
            "border-bottom": string;
        };
        let input: {
            display: string;
            padding: string;
            "text-align": string;
            "border-radius": string;
            "background-color": string;
            border: string;
        };
    }
    const bionicToolsBar: {
        toolbar: {
            dom: () => HTMLSpanElement;
        };
        bionic: {
            id: string;
            dom: () => HTMLLabelElement;
        };
        opacity: {
            id: string;
            dom: () => HTMLLabelElement;
        };
        "text-color": {
            id: string;
            dom: () => HTMLLabelElement;
        };
        algorithm: {
            id: string;
            dom: () => HTMLLabelElement;
        };
    };
}
//# sourceMappingURL=utils.d.ts.map