## 1.0.6 / 2023-07-27

* `progress-horizontal` 组件发布