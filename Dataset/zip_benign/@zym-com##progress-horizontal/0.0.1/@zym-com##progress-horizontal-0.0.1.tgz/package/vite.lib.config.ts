import { defineConfig } from "vite";
import { resolve } from "path";
import react from "@vitejs/plugin-react-swc";
const packageJson = require("./package.json");

// https://vitejs.dev/config/
export default defineConfig({
  define: {
    "process.env.NODE_ENV": "'production'",
  },
  build: {
    lib: {
      entry: resolve(__dirname, "src/index.tsx"),
      name: "progress-horizontal",
      fileName: (format) => `${format}/index.js`,
      formats: ["es", "cjs", "umd", "iife"],
    },
    minify: "esbuild", //esbuild terser
    rollupOptions: {
      external: [...Object.keys(packageJson.dependencies || {}), ...Object.keys(packageJson.devDependencies || {}), ...Object.keys(packageJson.peerDependencies || {})],
      output: {
        extend: true,
        globals: {
          react: "React",
          "react-dom": "ReactDOM",
        },
      },
    },
    outDir: "dist", //指定输出路径
  },
  resolve: {
    // 配置路径别名
    alias: {
      "@": resolve(__dirname, "./src"),
    },
  },
  plugins: [react()],
});
