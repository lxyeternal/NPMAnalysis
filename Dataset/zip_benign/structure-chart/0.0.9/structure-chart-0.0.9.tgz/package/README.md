# Structure Chart

## วิธีใช้

```
// import Structure Chart Component
import { StructChart } from 'structure-chart'
import 'structure-chart/structure-chart.css' // or import 'structure-chart/dist/style.css'

// import Data from static file or API
import chartData from '@/assets/structChartData'
const dataSource = ref(chartData)

// onClick Event
const chartClick = (data: any) => {
	console.log(data.value)
}

<StructChart
	:dataSource="data"
	@onElementClick="chartClick"
	:config="{
		'minZoom': 0.5,
		'maxZoom': 3
	}"
/>
```
