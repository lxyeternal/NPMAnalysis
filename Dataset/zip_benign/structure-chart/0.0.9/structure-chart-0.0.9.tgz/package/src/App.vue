<script setup lang="ts">
import { ref } from 'vue'
import StructChart from './components/StructChart.vue'
import chartData from './assets/structChartData2'
const dataSource = ref(chartData)

const chartRef = ref()

const savePNG = () => {
	chartRef.value.savePNG()
}
const savePDF = () => {
	chartRef.value.savePDF()
}
</script>
<template>
	<div>
		<button @click="savePNG()">Save PNG</button>
		<button @click="savePDF()">Save PDF</button>
		<StructChart ref="chartRef" :dataSource="dataSource"/>
	</div>
</template>

<style scoped>
</style>
