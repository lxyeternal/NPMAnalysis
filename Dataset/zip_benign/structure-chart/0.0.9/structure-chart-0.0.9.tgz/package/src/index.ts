import StructChart from './components/StructChart.vue'

export { StructChart }