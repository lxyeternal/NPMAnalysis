import { ref } from 'vue'
import { defineStore } from 'pinia'

/**
 * @interface IStructConfig
 * Configuration of StructureChart
 */
export interface IStructConfig {
	'minZoom'?: number,
	'maxZoom'?: number
}

export const useStructStore = defineStore('StructStore', () => {

	// StructureChart configuration
	const config = ref<IStructConfig>({
		'minZoom': 0.5,
		'maxZoom': 2.0
	})

	// ข้อมูลที่กำลังแสดงอยู่
	const dataSource = ref()

	// Current (Active) Node
	const selectedElement = ref()

	return {
		config,
		dataSource,
		selectedElement
	}
})
