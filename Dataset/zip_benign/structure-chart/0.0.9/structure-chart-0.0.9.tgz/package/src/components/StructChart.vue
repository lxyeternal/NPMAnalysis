<script setup lang="ts">
/**
 * import Vue's Stuff
 */
import { computed, watch, onMounted } from 'vue'
import type { PropType } from 'vue'
import panzoom from 'panzoom'
import html2canvas from 'html2canvas'
import { jsPDF } from "jspdf"

/**
 * import Chart Node componenet
 */
import StructChartNode from './StructChartNode.vue'

/**
 * import Pinia Store
 */
import { storeToRefs } from 'pinia'
import { useStructStore } from '../stores/StructStore'
import type { IStructConfig } from '../stores/StructStore'
const { config, dataSource, selectedElement } = storeToRefs(useStructStore())

/**
 * define Prop (Pass down value)
 */
const props = defineProps({
	config: Object as PropType<IStructConfig>, // Chart configuration
	dataSource: Object, // Data Source
})

/**
 * define Emit (Child to Parent value)
 */
const emit = defineEmits([
	'onElementClick', // Event call when user click each element
])

/**
 * Computed Property
 *	- minZoom : if parent don't send minZoom value, use default from StructStore (0.5)
 *	- maxZoom : if parent don't send maxZoom value, use default from StructStore (2)
 */
const minZoom = computed(() => props.config?.minZoom ? props.config.minZoom : config.value.minZoom)
const maxZoom = computed(() => props.config?.maxZoom ? props.config.maxZoom : config.value.maxZoom)

/**
 * จับภาพหน้าจอออกมาเป็น canvas object ส่งให้ฟังก์ชันอื่น ๆ นำไปประมวลผลต่อ
 * @param scale ขนาดของภาพที่ต้องการ ค่าพื้นฐานคือ 3 เท่าของหน้าจอ
 */
const captureChart = async(scale: number = 3) => {
	return await html2canvas(document.querySelector('.struct-chart-container') as HTMLElement, {
		scale: scale,
		width: (document.querySelector('.struct-chart-container') as HTMLElement).scrollWidth,
		height: (document.querySelector('.struct-chart-container') as HTMLElement).scrollHeight
	})
}

/**
 * จับภาพหน้าจอออกมาเป็น PNG แล้วดาวน์โหลด
 * @param scale ขนาดของภาพที่ต้องการ ค่าพื้นฐานคือ 3 เท่าของหน้าจอ
 */
const savePNG = async(scale: number = 3) => {
	let canvas = await captureChart(scale)
	let anchor = document.createElement('a')
	anchor.href = canvas.toDataURL('image/png')
	anchor.download = 'structure-chart.png'
	anchor.click()
	anchor.remove()
}

/**
 * savePDF - save canvas to PNG format and embed in PDF file then download.
 */
const savePDF = async(scale: number = 3) => {
	let canvas = await captureChart(scale)
	const doc = new jsPDF('l', 'px', 'a4')
	// const doc = new jsPDF('p', 'px', 'a4')
	let pageWidth = doc.internal.pageSize.getWidth()
	let pageHeight = doc.internal.pageSize.getHeight()

	let widthRatio = pageWidth / canvas.width
	let heightRatio = pageHeight / canvas.height
	let canvasRatio = widthRatio > heightRatio ? heightRatio : widthRatio

	let canvasWidth = canvas.width * canvasRatio;
	let canvasHeight = canvas.height * canvasRatio;

	let marginX = (pageWidth - canvasWidth) / 2
	let marginY = (pageHeight - canvasHeight) / 2
	doc.addImage(canvas.toDataURL('image/png'), 'PNG', marginX, marginY, canvasWidth, canvasHeight);
	doc.save('structure-chart.pdf');
}

// export method to public
defineExpose({ savePNG, savePDF })

/**
 * onMounted:
 *	- assign dataSource to internal Store
 *	- init panzoom
 */
onMounted(async () => {
	dataSource.value = props.dataSource

	// PanZoom
	// let element = document.querySelector('.struct-chart-container')
	// panzoom(element as HTMLElement, { // or let instance = panzoom(...)
	// 	smoothScroll: true,
	// 	minZoom: minZoom.value,
	// 	maxZoom: maxZoom.value
	// })
})

/**
 * watch if dataSource change -> update internal Store
 */
watch(() => props.dataSource, (newVal) => {
	dataSource.value = newVal
	// if (dataSourceLock.value === undefined) dataSourceLock.value = newVal
})

/**
 * watch if user click element (selectedElement in internal Store change value)
 */
watch(selectedElement, () => {
	// emit onElementClick when user select element
	emit('onElementClick', selectedElement)
})

</script>

<template>
	<div class="struct-chart">
		<div class="struct-chart-container">
			<StructChartNode :dataSource="props.dataSource" />
		</div>
	</div>
</template>

<style scoped lang="scss">
.struct-chart {
	width: 100vw;
	height: 100vh;
	background-color: white;
	// cursor: grab;
	user-select: none;
}
.struct-chart-container {
	width: auto;
	height: auto;
}
</style>
