<script setup lang="ts">
import { toRefs, watch, onMounted } from 'vue'
import { storeToRefs } from 'pinia'
import { useStructStore } from '../stores/StructStore'

const { dataSource, selectedElement } = storeToRefs(useStructStore())

const props = defineProps({
	dataSource: Object
})

const propDataSource = toRefs(props).dataSource

onMounted(() => {
	// console.log(propDataSource?.value)
})

watch(() => props.dataSource, (newVal) => {
	// console.log(newVal)
})

const onElementSelected = (data: any) => {
	selectedElement.value = data
}

const onSideElementClick = (data: any) => {
	console.log(data)
}

const numberFormat = (data: number) => {
	return new Intl.NumberFormat().format(data)
}

</script>

<template>
	<table class="node-container">
		<tbody>
			<!-- ส่วนนี้คือ Root Node เช่น "สำนักงานเลขานุการผู้ว่าราชการกรุงเทพมหานคร" -->
			<template v-if="propDataSource">
				<tr class="root-node">
					<td :colspan="propDataSource.children?.length * 2">
						<div class="element-container root-element" @click="onElementSelected(propDataSource?.deptID)">
							<div class="section-primary">
								<div class="column-content">
									<span class="header">{{ propDataSource.departmentName }}</span>
								</div>
								<div class="column-side">
									<div class="side-button" @click.stop="onSideElementClick('test')">
										{{ numberFormat(propDataSource.totalPositionCount) }}
									</div>
								</div>
							</div>
							<!-- ถ้ามีรายการตำแหน่งของ ผอ. -->
							<template v-if="propDataSource.heads.length > 0">
								<template v-for="head in propDataSource.heads" :key="head.positionID">
									<div class="section-secondary">
										<div class="column-content">
											<span class="header">{{ head.positionName }} {{ head.positionNum }}</span>
										</div>
										<div class="column-side">
											<div class="side-button">
												{{ numberFormat(head.totalPositionCount) }}
											</div>
										</div>
									</div>
								</template>
							</template>
							<!-- ถ้ามีรายการตำแหน่งของเจ้าหน้าที่ -->
							<template v-if="propDataSource.officer.length > 0">
								<div class="section-tertiary">
									<template v-for="officer in propDataSource.officer" :key="officer.positionID">
										<div class="section-list">
											<div class="column-content">
												<span class="header">
													{{ officer.positionName }} {{ officer.positionNum }}
												</span>
											</div>
											<div class="column-side">
												<div class="side-button">
													{{ numberFormat(officer.totalPositionCount) }}
												</div>
											</div>
										</div>
									</template>
								</div>
							</template>
						</div>
					</td>
				</tr>
			</template>

			<!-- เส้นแบ่ง Node -->
			<template v-if="propDataSource?.children?.length > 0">
				<tr class="nodeline">
					<td :colspan="propDataSource?.children?.length * 2">
						<div class="nodeline-down"></div>
					</td>
				</tr>
				<tr class="nodeline">
					<td class="nodeline-right"></td>
					<template v-for="n in propDataSource?.children?.length - 1" v-bind:key="n">
						<td class="nodeline-left nodeline-top"></td>
						<td class="nodeline-right nodeline-top"></td>
					</template>
					<td class="nodeline-left"></td>
				</tr>

				<!-- Child Node ทั้งหมดอยู่ที่นี่  -->
				<tr class="node-children">
					<!-- วนรอบเพื่อแสดง Root ของ Child Node เป็นคอลัมน์ต่าง ๆ การแสดงผลจะเป็นแบบแนวนอนสำหรับ Child Node ลำดับแรก จากนั้นจะเป็นแบบแนวตั้งในลำดับถัด ๆ ไป -->
					<template v-for="child in propDataSource?.children" :key="child.deptID">
						<td colspan="2">
							<!-- ส่วนนี้คือ Root ของ Child Node เช่น "ฝ่ายบริหารทั่วไป" -->
							<div class="element-container child-element" @click="onElementSelected(child?.deptID)">
								<div class="section-primary">
									<div class="column-content">
										<span class="header">{{ child.departmentName }}</span>
									</div>
									<div class="column-side">
										<div class="side-button">
											{{ numberFormat(child.totalPositionCount) }}
										</div>
									</div>
								</div>
								<!-- ถ้ามีรายการตำแหน่ง ผอ. -->
								<template v-if="child.heads?.length > 0">
									<template v-for="head in child.heads" :key="head.positionID">
										<div class="section-secondary">
											<div class="column-content">
												<span class="header">{{ head.positionName }} {{ head.positionNum }}</span>
											</div>
											<div class="column-side">
												<div class="side-button">
													{{ numberFormat(head.totalPositionCount) }}
												</div>
											</div>
										</div>
									</template>
								</template>
								<!-- ถ้ามีรายการตำแหน่งพนักงาน -->
								<template v-if="child.officer?.length > 0">
									<div class="section-tertiary">
										<template v-for="officer in child.officer" :key="officer.positionID">
											<div class="section-list">
												<div class="column-content">
													<span class="header">
														{{ officer.positionName }} {{ officer.positionNum }}
													</span>
												</div>
												<div class="column-side">
													<div class="side-button">
														{{ numberFormat(officer.totalPositionCount) }}
													</div>
												</div>
											</div>
										</template>
									</div>
								</template>
							</div>
							<!-- ถ้ามีกลุ่ม/กองย่อยภายใต้ Child Node นี้ เช่น "กลุ่มงานประชุม" -->
							<template v-if="child.children?.length > 0">
								<table class="subchild-section">
									<tbody>
										<template v-for="(group, index) in child.children" :key="group.deptID">
											<tr>
												<td class="nodeline-left nodeline-bottom subchild-section-nodeline"></td>
												<td rowspan="2">
													<div class="element-container subchild-element" @click="onElementSelected(group?.deptID)" >
														<div class="section-primary">
															<div class="column-content">
																<span class="header">
																	{{ group.departmentName }}
																</span>
															</div>
															<div class="column-side">
																<div class="side-button">
																	{{ numberFormat(group.totalPositionCount) }}
																</div>
																<template v-if="group.children?.length > 0">
																	<span class="subchild-more"></span>
																</template>
															</div>
														</div>
														<template v-if="group.heads?.length > 0">
															<template v-for="groupHead in group.heads"
																:key="groupHead.positionID">
																<div class="section-secondary">
																	<div class="column-content">
																		<span class="header">{{ groupHead.positionName }} {{
																			groupHead.positionNum }}</span>
																	</div>
																	<div class="column-side">
																		<div class="side-button">
																			{{ numberFormat(groupHead.totalPositionCount) }}
																		</div>
																	</div>
																</div>
															</template>
														</template>
														<template v-if="group.officer?.length > 0">
															<div class="section-tertiary">
																<template v-for="groupOfficer in group.officer"
																	:key="groupOfficer.positionID">
																	<div class="section-list">
																		<div class="column-content">
																			<span class="header">
																				{{ groupOfficer.positionName }} {{
																					groupOfficer.positionNum }}
																			</span>
																		</div>
																		<div class="column-side">
																			<div class="side-button">
																				{{ numberFormat(groupOfficer.totalPositionCount) }}
																			</div>
																		</div>
																	</div>
																</template>
															</div>
														</template>
													</div>
												</td>
											</tr>
											<tr>
												<template v-if="index != child.children.length - 1">
													<td class="nodeline-left nodeline-top subchild-section-nodeline"></td>
												</template>
												<template v-else>
													<td></td>
												</template>
											</tr>
										</template>
									</tbody>
								</table>
							</template>
						</td>
					</template>
				</tr>
			</template>
		</tbody>
	</table>
</template>


<style scoped lang="scss">
/**
 * 1 level = 1 node
 * แต่ละ node มีสิ่งที่เรียกว่า element
 * 1 element = 1 person/dept
 */

// container ของทั้ง node (level)
.node-container {
	border-collapse: collapse;
	margin: 0 auto 0 auto;
}

// root node element
.root-node {
	td {
		text-align: center;
		width: 100%;
	}
}

// container ของ element
.element-container {
	background: white;
	border: 1px solid #f0efef;
	border-radius: 5px;
	box-sizing: border-box;
	box-shadow: 0px 20px 20px -20px hsla(229, 6%, 66%, 0.212);
	display: inline-flex;
	flex-direction: column;
	position: relative;
	margin: 0 1px 2px 1px;
	min-width: 9rem;
	text-align: left;
	transition-duration: 250ms;

	&:hover {
		box-shadow: 0 6px 10px #7c7c7c;
		cursor: pointer;
		transform: scale(1.05);
		z-index: 20;
	}
}

// กรณีเป็น root element ใช้สีฟ้า
.root-element {
	border-top: 3px solid hsl(212, 86%, 64%);
}

// กรณีเป็น child element ใช้สีเขียว
.child-element {
	border-top: 3px solid hsl(180, 62%, 55%);
	width: 99%;
}

// กรณีเป็น sub child element ใช้สีน้ำตาล
.subchild-element {
	border-top: 3px solid #995511;
}

.section-primary,
.section-secondary,
.section-list {
	font-family: sans-serif;
	display: flex;
	align-items: center;
	padding: 6px 15px 6px 20px;
	bottom: 0;
	justify-content: space-between;

	.column-content {
		min-width: 120px;
	}

	.column-side {
		margin-left: 20px;

		.side-button {
			background-color: #d9d9d9;
			border: 1px solid white;
			// border-radius: 50%;
			border-radius: 8px;
			color: #717181;
			display: inline-grid;
			align-items: center;
			min-width: 32px;
			max-width: auto;
			padding: 0 8px;
			height: 36px;
			text-align: center;
		}
	}
}

.section-primary, .section-secondary, .section-tertiary {
	.header {
		color: #334454;
		font-size: 1.1rem;
		line-height: 1.5rem;
		margin: 0;
	}

}

.section-primary {
	.header {
		font-weight: 700 !important;
	}
}

.section-secondary,
.section-tertiary {
	border-top: 1px solid #d9d9d9;
}

.section-secondary {
	.header {
		font-weight: 500 !important;
	}
}
.section-tertiary {
	background: #fafafa;
	padding-left: 10px;

	.header {
		font-weight: 300 !important;
	}
	.header::before {
		content: "\2022";
		color: #394b5c;
		font-weight: bold;
		display: inline-block;
		width: 0.9em;
	}
}

.node-children {
	vertical-align: top;
}

.nodeline {
	height: 1.75rem;
}

// $line-color: #D2D6DB;
$line-color: #B0B4B0;

.nodeline-down {
	background: $line-color;
	margin-left: auto;
	margin-right: auto;
	margin-top: -1rem;
	margin-bottom: -1rem;
	height: 1.9rem;
	width: 0.125rem;
	float: none;
}

.nodeline-top {
	border-top-color: $line-color;
	border-top-style: solid;
	border-top-width: 2px;
}

.nodeline-bottom {
	border-bottom-color: $line-color;
	border-bottom-style: solid;
	border-bottom-width: 2px;
}

.nodeline-right {
	border-right-color: $line-color;
	border-right-style: solid;
	border-right-width: 2px;
}

.nodeline-left {
	border-left-color: $line-color;
	border-left-style: solid;
	border-left-width: 2px;
}

.subchild-section {
	margin-left: 1rem;
	border-collapse: collapse;
}
.subchild-section-nodeline {
	min-width: 20px;
	max-width: 30px;
}

.subchild-more {
	background: transparent url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz48IS0tIFVwbG9hZGVkIHRvOiBTVkcgUmVwbywgd3d3LnN2Z3JlcG8uY29tLCBHZW5lcmF0b3I6IFNWRyBSZXBvIE1peGVyIFRvb2xzIC0tPgo8c3ZnIHdpZHRoPSI4MDBweCIgaGVpZ2h0PSI4MDBweCIgdmlld0JveD0iMCAwIDE2IDE2IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGZpbGw9IiMwMDAwMDAiIGNsYXNzPSJiaSBiaS1jYXJldC1kb3duLWZpbGwiPgogIDxwYXRoIGQ9Ik03LjI0NyAxMS4xNCAyLjQ1MSA1LjY1OEMxLjg4NSA1LjAxMyAyLjM0NSA0IDMuMjA0IDRoOS41OTJhMSAxIDAgMCAxIC43NTMgMS42NTlsLTQuNzk2IDUuNDhhMSAxIDAgMCAxLTEuNTA2IDB6Ii8+Cjwvc3ZnPg==) no-repeat center bottom;
	background-size: 16px;
	border: 1px solid white;
	border-radius: 5px;
	cursor: pointer;
	padding: 5px 10px;
	color: #330000;
	width: 36px;
	height: 40px;
	text-align: center;
}

</style>
