const chartData2 = {
	"deptID": "bb89741a-050b-41f4-b60a-30bd51fc04ad",
	"departmentName": "สำนักงานคณะกรรมการข้าราชการกรุงเทพมหานคร",
	"totalPositionCount": 54155,
	"totalPositionVacant": 0,
	"children": [
		{
			"deptID": "bcc0852c-c7d1-4c3e-bd10-3237ff657c60",
			"departmentName": "กองบริหารทั่วไป",
			"totalPositionCount": 0,
			"totalPositionVacant": 0,
			"children": [
				{
					"deptID": "f2dd6fce-36d4-477c-b310-0d5fb9c3be68",
					"departmentName": "กลุ่มงานช่วยนักบริหาร",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [

					],
					"officer": [
						{
							"positionID": "423535aa-0303-4fde-ac19-9e2cfc3756fb",
							"positionName": "นักจัดการงานทั่วไป",
							"positionNum": "",
							"totalPositionCount": 3,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "2268abe3-0b7c-4607-a12f-3f8c169b860c",
					"departmentName": "ฝ่ายบริหารงานทั่วไปและการประชุม",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "fbd2ac18-e36f-4408-b23f-d0e4d7fb63c1",
							"positionName": "นักจัดการงานทั่วไป (หัวหน้าฝ่าย)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "423535aa-0303-4fde-ac19-9e2cfc3756fb",
							"positionName": "นักจัดการงานทั่วไป",
							"positionNum": "",
							"totalPositionCount": 3,
							"totalPositionVacant": 0
						},
						{
							"positionID": "835eab03-5169-4ca0-9d29-d8cb7a96da4d",
							"positionName": "เจ้าพนักงานธุรการ",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "929e0b74-a703-45fe-928c-9d88dc9d9efd",
					"departmentName": "ฝ่ายการคลัง",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "7163a367-7ee9-409b-b67e-c28943e91120",
							"positionName": "นักวิชาการเงินและบัญชี (หัวหน้าฝ่าย)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "91a9a430-1da5-4ca6-aaf8-35535376c24b",
							"positionName": "นักวิชาการเงินและบัญชี",
							"positionNum": "",
							"totalPositionCount": 3,
							"totalPositionVacant": 0
						},
						{
							"positionID": "de89c4b1-c8c7-4ca9-83ab-db07da45d9a5",
							"positionName": "เจ้าพนักงานพัสดุ",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						},
						{
							"positionID": "c5ce889e-4d12-4132-9f0b-daf45ff333f9",
							"positionName": "เจ้าพนักงานการเงินและบัญชี",
							"positionNum": "",
							"totalPositionCount": 2,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "e83467ea-1029-4e72-8977-d29c81fa82e5",
					"departmentName": "ฝ่ายการเจ้าหน้าที่",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c173bc63-3788-4caf-b3d1-58ac841134bc",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้าฝ่าย)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 3,
							"totalPositionVacant": 0
						},
						{
							"positionID": "835eab03-5169-4ca0-9d29-d8cb7a96da4d",
							"positionName": "เจ้าพนักงานธุรการ",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					]
				}
			],
			"heads": [
				{
					"positionID": "0be0cf17-626d-4052-b7a4-38ad17b03dac",
					"positionName": "ผู้อำนวยการ (ผู้อำนวยการกอง)",
					"positionNum": "",
					"totalPositionCount": 1,
					"totalPositionVacant": 0
				}
			],
			"officer": [

			]
		},
		{
			"deptID": "3d4e3296-3e81-42a3-8979-c988ced10eaf",
			"departmentName": "กองสรรหาบุคคล",
			"totalPositionCount": 0,
			"totalPositionVacant": 0,
			"children": [
				{
					"deptID": "113077b9-d01b-4e4d-9600-dd36557073b5",
					"departmentName": "ฝ่ายบริหารงานทั่วไป ",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [

					],
					"officer": [

					]
				},
				{
					"deptID": "240bed7a-33f8-49e8-814f-f021d044940c",
					"departmentName": "กลุ่มงานดำเนินการสรรหา ๑",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 3,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "877154b3-02ad-48c0-be6e-24899fd32572",
					"departmentName": "กลุ่มงานดำเนินการสรรหา ๒",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 3,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "2237c91e-0057-42c0-94a0-7bb48297220b",
					"departmentName": "กลุ่มงานวิชาการสอบ",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 3,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "07cf9e84-3d40-4713-9e47-656c2fc799d4",
					"departmentName": "กลุ่มงานพัฒนาระบบการสรรหา",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 4,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "f6132e5e-d9a1-4cba-84e0-5cacd0809d95",
					"departmentName": "กลุ่มงานมาตรฐานการสรรหา",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 4,
							"totalPositionVacant": 0
						}
					]
				}
			],
			"heads": [
				{
					"positionID": "0be0cf17-626d-4052-b7a4-38ad17b03dac",
					"positionName": "ผู้อำนวยการ (ผู้อำนวยการกอง)",
					"positionNum": "",
					"totalPositionCount": 1,
					"totalPositionVacant": 0
				}
			],
			"officer": [

			]
		},
		{
			"deptID": "8786ce07-0b95-4122-854f-5a6f1ba880dd",
			"departmentName": "กองพัฒนาระบบราชการกรุงเทพมหานคร",
			"totalPositionCount": 0,
			"totalPositionVacant": 0,
			"children": [
				{
					"deptID": "b1a5f200-f169-4b25-8bdb-4f1246fe3626",
					"departmentName": "ฝ่ายบริหารงานทั่วไป",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [

					],
					"officer": [

					]
				},
				{
					"deptID": "1ad402f4-dcca-4dba-bd4b-5e1255cca374",
					"departmentName": "ส่วนพัฒนาระบบบริหาร",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [

					],
					"officer": [

					]
				},
				{
					"deptID": "e32f08b4-1f25-443e-b29c-b8272a9426f7",
					"departmentName": "กลุ่มงานบริหารผลงาน",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c05e485c-c9b6-44a4-8497-7ec612092108",
							"positionName": "ผู้อำนวยการ (ผู้อำนวยการส่วน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						},
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 4,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "3034f8e1-8508-4f33-a57d-e9a14e06cb4f",
					"departmentName": "กลุ่มงานพัฒนาระบบงานและนวัตกรรมบริการ",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 4,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "a2b2c45a-332f-437d-9280-e37d5ce31541",
					"departmentName": "กลุ่มงานบริหารค่าตอบแทนและคุณภาพชีวิต",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 4,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "9ffdb56f-273e-4935-b594-6c39b0dfd00d",
					"departmentName": "กลุ่มงานขับเคลื่อนการบริหารทรัพยากรบุคคล",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 3,
							"totalPositionVacant": 0
						}
					]
				}
			],
			"heads": [
				{
					"positionID": "8e456008-5c13-416f-87c0-261a2c036f40",
					"positionName": "ผู้อำนวยการ (ผู้อำนวยการกอง)",
					"positionNum": "",
					"totalPositionCount": 1,
					"totalPositionVacant": 0
				}
			],
			"officer": [

			]
		},
		{
			"deptID": "a89230e9-4aa6-493c-bb2a-49b37011f947",
			"departmentName": "กองอัตรากำลัง",
			"totalPositionCount": 0,
			"totalPositionVacant": 0,
			"children": [
				{
					"deptID": "bad23771-77c8-471f-9107-bd1e4ab48c54",
					"departmentName": "ฝ่ายบริหารงานทั่วไป",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [

					],
					"officer": [

					]
				},
				{
					"deptID": "06aac64c-93cf-43fd-ac3d-b6c98b9103be",
					"departmentName": "ส่วนโครงสร้างและอัตรากำลัง",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c05e485c-c9b6-44a4-8497-7ec612092108",
							"positionName": "ผู้อำนวยการ (ผู้อำนวยการส่วน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [

					]
				},
				{
					"deptID": "8e3ac777-cf39-484b-ae0a-247ff3e96e0d",
					"departmentName": "กลุ่มงานโครงสร้างและอัตรากำลัง ๑",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 4,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "c0556898-cc09-43fc-b78f-f50b18b1a23c",
					"departmentName": "กลุ่มงานโครงสร้างและอัตรากำลัง ๒",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 4,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "c68f1e25-ead1-4ad0-a1d5-2aba43957ca6",
					"departmentName": "กลุ่มงานโครงสร้างและอัตรากำลัง ๓",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 4,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "51396453-5b06-4531-b16f-0fe09066ebf1",
					"departmentName": "กลุ่มงานประเมินบุคคล",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 7,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "bad68235-409a-4e07-a33c-178ea1102193",
					"departmentName": "ส่วนระบบตำแหน่งและมาตรฐานกำหนดตำแหน่ง",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c05e485c-c9b6-44a4-8497-7ec612092108",
							"positionName": "ผู้อำนวยการ (ผู้อำนวยการส่วน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [

					]
				},
				{
					"deptID": "dccf8a87-6ffb-4fc6-b00e-44fd85af74c1",
					"departmentName": "กลุ่มงานตำแหน่งข้าราชการกรุงเทพมหานคร",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 5,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "9e4a1974-9299-4990-9054-ea7946cb56dd",
					"departmentName": "กลุ่มงานมาตรฐานกำหนดตำแหน่งข้าราชการกรุงเทพมหานคร",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 4,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "3c3dc746-dbc3-4753-9a9f-a6398dafe531",
					"departmentName": "กลุ่มงานบุคลากรกรุงเทพมหานคร",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 3,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "0ce0d2f1-8040-48b7-8779-e0a45ce53032",
					"departmentName": "กลุ่มงานเสริมสร้างวิทยฐานะข้าราชการครูและบุคลากรทางการศึกษากรุงเทพมหานคร ๑",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 3,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "c5e9ec7f-96c2-41f8-9a35-c5d24247e419",
					"departmentName": "กลุ่มงานเสริมสร้างวิทยฐานะข้าราชการครูและบุคลากรทางการศึกษากรุงเทพมหานคร ๒",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 3,
							"totalPositionVacant": 0
						}
					]
				}
			],
			"heads": [
				{
					"positionID": "8e456008-5c13-416f-87c0-261a2c036f40",
					"positionName": "ผู้อำนวยการ (ผู้อำนวยการกอง)",
					"positionNum": "",
					"totalPositionCount": 1,
					"totalPositionVacant": 0
				}
			],
			"officer": [

			]
		},
		{
			"deptID": "b6c64eae-2c65-4ba0-a50e-8ee089e848c0",
			"departmentName": "กองทะเบียนประวัติข้าราชการ",
			"totalPositionCount": 0,
			"totalPositionVacant": 0,
			"children": [
				{
					"deptID": "f67cfea3-6c74-42ad-b4d8-f1162aad6141",
					"departmentName": "ฝ่ายบริหารงานทั่วไป",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [

					],
					"officer": [

					]
				},
				{
					"deptID": "a7a3ccdc-9175-461f-84bc-d9bef4237b4e",
					"departmentName": "กลุ่มงานทะเบียนประวัติข้าราชการ ๑",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 5,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "76ce57ba-bd5c-4692-882f-80697265c8da",
					"departmentName": "กลุ่มงานทะเบียนประวัติข้าราชการ ๒",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 5,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "9d863367-4ad8-4dfc-b822-82657401c6dd",
					"departmentName": "กลุ่มงานสารสนเทศทรัพยากรบุคคล",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "c34a1bf3-61f9-47c5-b8bf-3b18016af414",
							"positionName": "นักทรัพยากรบุคคล (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "26b76cd2-7838-463b-80b1-e83137b8d4cf",
							"positionName": "นักทรัพยากรบุคคล",
							"positionNum": "",
							"totalPositionCount": 2,
							"totalPositionVacant": 0
						},
						{
							"positionID": "59089417-91d3-4d97-961d-98b4083dd4cb",
							"positionName": "นักวิชาการคอมพิวเตอร์",
							"positionNum": "",
							"totalPositionCount": 2,
							"totalPositionVacant": 0
						}
					]
				}
			],
			"heads": [
				{
					"positionID": "0be0cf17-626d-4052-b7a4-38ad17b03dac",
					"positionName": "ผู้อำนวยการ (ผู้อำนวยการกอง)",
					"positionNum": "",
					"totalPositionCount": 1,
					"totalPositionVacant": 0
				}
			],
			"officer": [

			]
		},
		{
			"deptID": "1fddb8a9-a43f-4d29-ae2e-2f976ec5dc39",
			"departmentName": "กองวินัยและเสริมสร้างจริยธรรม",
			"totalPositionCount": 0,
			"totalPositionVacant": 0,
			"children": [
				{
					"deptID": "3686f5e7-f9e6-4d64-b748-2a917c3baebc",
					"departmentName": "ฝ่ายบริหารงานทั่วไป",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "35e7711f-9638-4ebd-ab64-cb97dec7b7d4",
							"positionName": "นักจัดการงานทั่วไป (หัวหน้าฝ่าย)",
							"positionNum": "",
							"totalPositionCount": 3,
							"totalPositionVacant": 0
						},
						{
							"positionID": "fbd2ac18-e36f-4408-b23f-d0e4d7fb63c1",
							"positionName": "นักจัดการงานทั่วไป (หัวหน้าฝ่าย)",
							"positionNum": "",
							"totalPositionCount": 3,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "835eab03-5169-4ca0-9d29-d8cb7a96da4d",
							"positionName": "เจ้าพนักงานธุรการ",
							"positionNum": "",
							"totalPositionCount": 10,
							"totalPositionVacant": 0
						},
						{
							"positionID": "423535aa-0303-4fde-ac19-9e2cfc3756fb",
							"positionName": "นักจัดการงานทั่วไป",
							"positionNum": "",
							"totalPositionCount": 11,
							"totalPositionVacant": 0
						},
						{
							"positionID": "c5ce889e-4d12-4132-9f0b-daf45ff333f9",
							"positionName": "เจ้าพนักงานการเงินและบัญชี",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "dee95909-7f08-46be-a1c6-3f91c1965d5e",
					"departmentName": "ส่วนวินัยและเสริมสร้างจริยธรรม",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "f9ceaf95-3b7d-4201-8655-b18d75701a1a",
							"positionName": "ผู้อำนวยการเฉพาะด้าน (ผู้อำนวยการส่วน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [

					]
				},
				{
					"deptID": "bdd8c4f0-afd3-406b-a545-88dc8005ace5",
					"departmentName": "กลุ่มงานมาตรฐานวินัย",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "86e1771f-088c-4f39-964d-73b68f9fe7a9",
							"positionName": "นิติกร (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "e944465c-238a-4515-af19-dea8b03d4353",
							"positionName": "นิติกร",
							"positionNum": "",
							"totalPositionCount": 8,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "9a522ee0-9cd9-42de-9a62-bc2b2e26ab8c",
					"departmentName": "กลุ่มงานเสริมสร้างจริยธรรม",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "86e1771f-088c-4f39-964d-73b68f9fe7a9",
							"positionName": "นิติกร (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "e944465c-238a-4515-af19-dea8b03d4353",
							"positionName": "นิติกร",
							"positionNum": "",
							"totalPositionCount": 4,
							"totalPositionVacant": 0
						}
					]
				},
				{
					"deptID": "33c32426-3d26-4361-b20d-aabce4d8eab3",
					"departmentName": "กลุ่มงานนิติการ",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "86e1771f-088c-4f39-964d-73b68f9fe7a9",
							"positionName": "นิติกร (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "e944465c-238a-4515-af19-dea8b03d4353",
							"positionName": "นิติกร",
							"positionNum": "",
							"totalPositionCount": 3,
							"totalPositionVacant": 0
						}
					]
				}
			],
			"heads": [
				{
					"positionID": "72e8e447-612c-4e96-b114-c0311875fb48",
					"positionName": "ผู้อำนวยการเฉพาะด้าน (ผู้อำนวยการกอง)",
					"positionNum": "",
					"totalPositionCount": 1,
					"totalPositionVacant": 0
				}
			],
			"officer": [

			]
		},
		{
			"deptID": "60781404-0d0c-48be-abec-a8d05bd74f6b",
			"departmentName": "กองพิทักษ์ระบบคุณธรรม",
			"totalPositionCount": 0,
			"totalPositionVacant": 0,
			"children": [
				{
					"deptID": "43362202-f229-46e1-bda6-0e51d42a03c5",
					"departmentName": "ฝ่ายบริหารงานทั่วไป",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [

					],
					"officer": [

					]
				},
				{
					"deptID": "8e451796-42ef-4514-a79d-69c71425dab6",
					"departmentName": "กลุ่มงานพิทักษ์ระบบคุณธรรม",
					"totalPositionCount": 0,
					"totalPositionVacant": 0,
					"children": [

					],
					"heads": [
						{
							"positionID": "86e1771f-088c-4f39-964d-73b68f9fe7a9",
							"positionName": "นิติกร (หัวหน้ากลุ่มงาน)",
							"positionNum": "",
							"totalPositionCount": 1,
							"totalPositionVacant": 0
						}
					],
					"officer": [
						{
							"positionID": "e944465c-238a-4515-af19-dea8b03d4353",
							"positionName": "นิติกร",
							"positionNum": "",
							"totalPositionCount": 9,
							"totalPositionVacant": 0
						}
					]
				}
			],
			"heads": [
				{
					"positionID": "6ecab715-dd26-4494-91d9-593637379f14",
					"positionName": "ผู้อำนวยการเฉพาะด้าน (ผู้อำนวยการกอง)",
					"positionNum": "",
					"totalPositionCount": 1,
					"totalPositionVacant": 0
				}
			],
			"officer": [

			]
		}
	],
	"heads": [
		{
			"positionID": "803536a6-7e24-4ef3-aee2-a228ace3d273",
			"positionName": "นักบริหาร (หัวหน้าสำนักงาน )",
			"positionNum": "",
			"totalPositionCount": 1,
			"totalPositionVacant": 0
		},
		{
			"positionID": "cd72a45f-de45-4ff0-b334-6cf44bf07cd5",
			"positionName": "นักบริหาร (ผู้ช่วยหัวหน้าสำนักงาน )",
			"positionNum": "",
			"totalPositionCount": 2,
			"totalPositionVacant": 0
		}
	],
	"officer": [

	]
}

export default chartData2
