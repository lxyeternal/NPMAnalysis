/*
 * @Author: zhangwenyuan
 * @Date: 2021-05-26 11:15:38
 * @LastEditors: zhangwenyuan
 * @LastEditTime: 2022-08-15 17:33:01
 * @FilePath: /fe-less/src/index.ts
 * @Description:
 */
import './styles/index.less';
