function add(a, b) {
  return a + b;
}
function decrease(a, b) {
  return a - b;
}
function multiply(a, b) {
  return a * b;
}
function divide(a, b) {
  return a / b;
}

module.exports = {
  add,
  decrease,
  multiply,
  divide,
};
