## 安装

npm i awesome-caculator

## 导入方式

const awesomeCaculator = require("./awesome-caculator");

## 使用示例

const add = awesomeCaculator.add(1, 2); <br>
const decrease = awesomeCaculator.decrease(1, 2); <br>
const multiply = awesomeCaculator.multiply(1, 2); <br>
const divide = awesomeCaculator.divide(1, 2); <br>

console.log(add,'add'); //3 add <br>
console.log(decrease,'decrease'); //-1 decrease <br>
console.log(multiply,'multiply'); //2 multiply <br>
console.log(divide,'divide'); //0.5 divide <br>

## 开源协议

ISC
