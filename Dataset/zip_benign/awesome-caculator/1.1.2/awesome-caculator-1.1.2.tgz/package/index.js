const fn = require("./src/fn");

module.exports = {
  ...fn,
};
