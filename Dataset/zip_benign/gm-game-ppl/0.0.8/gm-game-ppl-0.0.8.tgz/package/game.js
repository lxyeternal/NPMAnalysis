let PIXI;
let Game = function (options) {
  this.options = Object.assign({
    rowMaxNum: 7,//一行最多的泡泡个数
    paddingLeft: 0,//左侧内边距
    paddingRight: 0,//右侧内边距
    MAX_ANGLE: 70,//最大角度
    MIN_ANGLE: -70,//最小角度
    speed: 2,//精灵掉落时，每次移动距离
    flySpeed: 20,//发射泡泡飞行速度
    baseScore: 0,//游戏基础分
    animateTime: 5,//精灵掉落延迟时间（毫秒）
    firstBottomLineType: "max",//第一行类型，max:球个数为rowMaxNum min:球个数为rowMaxNum-1
    firstShowLine: 5,//初始化行数
    nextRenderLine: 0,//每次生成行数
    totalBall: 10,//总共可发射的球个数
  }, options);

  PIXI = this.options.$game.fObj.PIXI;
  this.width = this.options.$game.fObj.size.windowWidth;
  this.height = this.options.$game.fObj.size.windowHeight;

  this.options.paddingLeft = this.options.paddingLeft * this.options.$game.fObj.scale;
  this.options.paddingRight = this.options.paddingRight * this.options.$game.fObj.scale;
  // 单个元素宽高
  this.spriteW = (this.width - (this.options.paddingLeft + this.options.paddingRight)) / this.options.rowMaxNum;
  this.spriteH = this.spriteW;

  // 1.创建pixi需要的对象 容器
  // 精灵容器
  this.spriteContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.spriteContainer);
  // 炮容器
  this.paoContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.paoContainer);
  // 元素背后线条容器
  this.bubbleLineContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.bubbleLineContainer);
  // 动画容器
  this.animateContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.animateContainer);
  // 长线短线容器
  this.longOrShortContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.longOrShortContainer);
  // 绘制个矩形，解决触摸事件
  let rect1 = new PIXI.Graphics();
  rect1.beginFill(0xff0000, 0);
  rect1.drawRect(0, 0, this.width, this.height);
  rect1.endFill();
  this.spriteContainer.addChild(rect1);
  this.spriteContainer.setChildIndex(rect1, 0);

  // 2.遍历图片资源 并 去重
  let imgArr = [];
  options.gameSource = JSON.parse(JSON.stringify(options.gameSource));
  this.traverse(options.gameSource, function (k, v) {
    if (k == "src" && !!v && !imgArr.includes(v) && !PIXI.utils.TextureCache[v]) {
      imgArr.push(v);
    }
  })

  // 定时更新
  this.ticker = PIXI.ticker.shared;
  // this.ticker.speed = 5;
  this.ticker.autoStart = false;
  this.ticker.addOnce(() => { });

  // 3.加载图片资源
  if (imgArr.length > 0) {
    let loader = new PIXI.loaders.Loader();
    imgArr.forEach(item => {
      loader.add(this.uniId(), item);
    })
    this.pixiLoadFun(loader);
  } else {
    this.init({});
    this.options.initDone();
  }
  // 绑定事件
  this.bindEvent();
}
Game.prototype = Object.assign(Game.prototype, {
  pixiLoadFun: function (loader) {
    let time1 = new Date().getTime();
    loader.on("progress", e => {
      this.options.progressFun(e.progress);
    })
    loader.on("error", e => {
      this.options.errorFun(e);
    })
    loader.load(() => {
      // 资源加载完成
      time1 = "";
      this.init({});
      this.options.initDone();
    });
    setTimeout(() => {
      // 5秒还没加载完，重新加载一遍
      if (!!time1) {
        console.log("重新加载资源...")
        this.pixiLoadFun(loader);
      }
    }, 5000)
  },
  uniId: function () {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  },
  random: function (options) {
    let opt = Object.assign({ min: 0, max: 0, isFloat: false, noNum: [] }, options);
    let tempNum;
    do {
      let num = Math.random() * (opt.max - opt.min) + opt.min;
      tempNum = !!opt.isFloat ? num : parseInt(num);
    } while (opt.noNum.includes(tempNum));
    return tempNum;
  },
  isArray: function (obj) {
    return obj instanceof Array;
  },
  isObject: function (obj) {
    // 判断数组对象
    if (!(obj instanceof Array) && (obj instanceof Object)) {
      return true;
    }
    return false;
  },
  traverse: function (obj, callback) {
    // 遍历json
    for (let name in obj) {
      // 如果是json对象
      if (this.isObject(obj[name])) {
        this.traverse(obj[name], callback);
      } else if (this.isArray(obj[name])) {
        // 数组对象
        obj[name].forEach(item => {
          this.traverse(item, callback);
        })
      } else {
        callback(name, obj[name]);
      }
    }
  },
  bindEvent: function () {
    this.spriteContainer.interactive = true;
    // 绑定事件
    this.spriteContainer.on('touchstart', (e) => {
      this.getAngule(e);
    })
    this.spriteContainer.on('touchmove', (e) => {
      this.getAngule(e);
    })
    this.spriteContainer.on('touchendoutside', (e) => {
      this.getAngule(e, 'end');
    })
    this.spriteContainer.on('touchend', (e) => {
      this.getAngule(e, 'end');
    })
  },
  getAngule: function (e, play) {
    if (!this.playStatus) { return false; }
    if (!!this.helpLineSprite && !this.helpLineSprite.visible) { this.helpLineSprite.visible = true; }
    let x = e.data.global.x,
      y = e.data.global.y;

    if (!this.originPoint) {
      this.originPoint = { x: this.paotongSprite.x, y: this.paotongSprite.y };
    }
    let w = Math.abs(this.originPoint.x - x);
    let h = Math.abs(this.originPoint.y - y);

    let angule = 90 - Math.atan2(h, w) * 180 / Math.PI;
    if (x < this.originPoint.x) {
      angule = -angule;
    }
    angule = Math.max(Math.min(angule, this.options.MAX_ANGLE), this.options.MIN_ANGLE);

    angule = angule * Math.PI / 180;
    this.angule = angule;

    this.paotongSprite.rotation = angule;

    if (!!this.helpLineSprite) {
      // 辅助线
      let pointX = this.paotongSprite.x + Math.sin(this.angule || 0) * this.paotongSprite.height * 0.5,
        pointY = this.paotongSprite.y - this.paotongSprite.height / 2 - Math.cos(this.angule || 0) * this.paotongSprite.height * 0.5;
      let minSprite;
      this.spriteArr.forEach(sprite => {
        if (!!sprite.visible) {
          if (!minSprite) {
            minSprite = sprite;
          } else {
            if (Math.pow((sprite.x - pointX), 2) + Math.pow((sprite.y - pointY), 2) < Math.pow((minSprite.x - pointX), 2) + Math.pow((minSprite.y - pointY), 2)) {
              minSprite = sprite;
            }
          }
        }
      })
      let maxLen = 9999;
      try {
        // 辅助线最大长度
        maxLen = Math.sqrt(Math.pow((minSprite.x - pointX), 2) + Math.pow((minSprite.y - pointY), 2)) - this.spriteW / 2;
        // 转成缩放之前的值
        maxLen = maxLen / this.options.$game.fObj.scale;
      } catch (e) { }

      this.helpLineSprite.rotation = angule;
      this.helpLineSprite.x = pointX;
      this.helpLineSprite.y = pointY;
      let helpLineImg = Object.assign({ type: "pao", name: "helpLineSprite" }, this.options.gameSource.helpLine);
      // this.helpLineSprite.height = 50;
      helpLineImg.height = Math.min(maxLen, helpLineImg.height);
      this.helpLineSprite.height = helpLineImg.height * this.options.$game.fObj.scale;
      this.helpLineSprite.texture = this.frame(helpLineImg, 0, 0)
    }

    if (!!play && !this.addLineStatus) {
      this.playStatus = false;
      if (!!this.helpLineSprite) {
        this.helpLineSprite.visible = false;
      }
      // 发射
      this.send();
    }
  },
  audioFun: function (name) {
    if (!name) { return false; }
    let tempAudio;
    if (!!this.fAudio) {
      this.fAudio.destroy();
    }
    const innerAudioContext = my.createInnerAudioContext();
    this.fAudio = innerAudioContext;
    for (let audioName in this.options.gameSource.audioObj) {
      let audioObj = this.options.gameSource.audioObj[audioName];

      if (!!name && name == audioName) {
        tempAudio = audioObj;
      }
    }
    if (!!tempAudio) {
      this.fAudio.src = tempAudio.audioSrc;
      this.fAudio.play();
    }
  },
  send: function () {
    // 发射泡泡
    this.flySpeedX = Math.floor(this.options.flySpeed * Math.sin(this.angule));
    this.flySpeedY = -Math.floor(this.options.flySpeed * Math.cos(this.angule));

    // 1.泡泡飞行
    this.bubbleFlyAnimation();
  },
  // 泡泡飞行动画
  bubbleFlyAnimation: function () {
    let bl = false;

    // 1.碰墙判定
    if (this.curBallSprite.x + this.curBallSprite.width / 2 >= this.width - this.options.paddingRight || this.curBallSprite.x - this.curBallSprite.width / 2 <= this.options.paddingLeft) {
      // 撞到两边墙
      this.flySpeedX = -this.flySpeedX;
    } else if (/* this.curBallSprite.y + this.curBallSprite.height / 2 >= this.height ||  */this.curBallSprite.y - this.curBallSprite.width / 2 <= 0) {
      // 撞到上下墙
      this.flySpeedY = -this.flySpeedY;
    }
    // 被撞的bubble
    let hitedBubblePos = this.hitBubble();
    if (hitedBubblePos) {
      this.fixedBubble(hitedBubblePos);
    } else {
      bl = true;
      this.curBallSprite.x += this.flySpeedX;
      this.curBallSprite.y += this.flySpeedY;
    }


    if (!!bl) {
      setTimeout(() => {
        this.bubbleFlyAnimation();
      }, this.options.animateTime * 5)
    }
  },
  getBoundings: function (bubblePos, type) {
    let base = [
      { x: bubblePos.x - this.spriteW / 2, y: (bubblePos.y - (this.spriteW / 2 + this.stepHeight)) }, { x: bubblePos.x + this.spriteW / 2, y: (bubblePos.y - (this.spriteW / 2 + this.stepHeight)) },
      { x: bubblePos.x - this.spriteW, y: bubblePos.y }, { x: bubblePos.x + this.spriteW, y: bubblePos.y },
      { x: bubblePos.x - this.spriteW / 2, y: (bubblePos.y + (this.spriteW / 2 + this.stepHeight)) }, { x: bubblePos.x + this.spriteW / 2, y: (bubblePos.y + (this.spriteW / 2 + this.stepHeight)) },
    ];
    // 只存储在显示区域内的元素坐标位置
    let arr = [];
    base.forEach(item => {
      if (Math.floor(this.options.paddingLeft + this.spriteW / 2) <= item.x && Math.floor(item.x) <= this.width - this.options.paddingRight - this.spriteW / 2 && 0 < item.y && item.y < this.height) {
        arr.push(item);
      }
    })
    // 元素周围有精灵的
    let hasSprite = [];
    // 元素周围为空的位置
    let emptySprite = [];

    arr.forEach(item => {
      let bl = true;
      this.spriteArr.forEach(sprite => {
        if (!!sprite.visible) {
          if (Math.abs(sprite.x - item.x) < 0.1 && Math.abs(sprite.y - item.y) < 0.1) {
            bl = false;
            if (type == "has") {
              hasSprite.push(sprite);
            }
          }
        }
      })
      if (!!bl && type == "empty") {
        emptySprite.push(item);
      }
    })

    if (type == "empty") {
      return emptySprite;
    }
    if (type == "has") {
      return hasSprite;
    }

    return arr;
  },
  getHitedBubbleNearestBubble(hitedBubblePos) {
    // 获取被撞元素最近的空位

    // 获取被撞击元素周围的空位置
    let emptyIndexs = this.getBoundings(hitedBubblePos, "empty");

    // 最短距离
    let minDistance = 0,
      nearestIndex = "",
      len = emptyIndexs.length;
    if (len <= 0) {
      console.error("撞击位置有误， 周围应该有空位");
    }
    for (let i = 0; i < len; ++i) {
      let distance = Math.pow((this.curBallSprite.x - emptyIndexs[i].x), 2) + Math.pow((this.curBallSprite.y - emptyIndexs[i].y), 2);
      if (!minDistance || (!!minDistance && distance < minDistance)) {
        minDistance = distance;
        nearestIndex = emptyIndexs[i];
      }
    }
    return nearestIndex;
  },
  getEqualNum: function (baseSprite, notArr = []) {
    // 传递一个元素，返回和该元素相同的个数
    let arr = [baseSprite];
    Array.prototype.push.apply(arr, notArr)
    // 去重
    arr = this.quchong(arr);
    let hasSprite = this.getBoundings(baseSprite, "has");
    hasSprite.forEach(sprite => {
      if (baseSprite.imgObj.src == sprite.imgObj.src) {
        let bl = true;
        notArr.forEach(t => {
          if (Math.abs(sprite.x - t.x) < 0.1 && Math.abs(sprite.y - t.y) < 0.1 && t.imgObj.src == sprite.imgObj.src) {
            // 已存在该元素  不再存储
            bl = false;
          }
        })
        if (!!bl) {
          // 和传入进来的元素类型相同
          Array.prototype.push.apply(arr, this.getEqualNum(sprite, arr))
        }
      }
    })
    // 去重
    arr = this.quchong(arr);

    return arr;
  },
  fixedBubble(hitedBubblePos) {
    let fixedPos;
    if (!!hitedBubblePos.isOut) {
      // 撞上顶部了
      fixedPos = hitedBubblePos;
    } else {
      fixedPos = this.getHitedBubbleNearestBubble(hitedBubblePos);
    }
    // 1.生成新球到页面上
    let newImg = this.curBallSprite.imgObj;
    newImg.x = fixedPos.x;
    newImg.y = fixedPos.y;
    newImg.type = "sprite";
    newImg.uniId = undefined;
    newImg.name = undefined;
    newImg.spriteW = this.spriteW;
    newImg.spriteH = this.spriteH;
    let newSprite = this.renderSprite(newImg);
    // 2.恢复发射球
    if (!this.nextBallSprite.imgObj) {
      this.curBallSprite.imgObj = "";
      this.curBallSprite.texture = null;
    } else {
      this.curBallSprite.x = this.baseCurBallX;//this.paotongSprite.x + Math.sin(this.angule || 0) * this.paotongSprite.height - Math.sin(this.angule || 0) * this.curBallSprite.width / 2;
      this.curBallSprite.y = this.baseCurBallY;//this.paotongSprite.y - Math.cos(this.angule || 0) * this.paotongSprite.height + Math.cos(this.angule || 0) * this.curBallSprite.width / 2;
      let tImg = Object.assign({}, this.nextBallSprite.imgObj);
      tImg.uniId = "";
      tImg.type = "pao";
      tImg.name = "curBallSprite";
      this.curBallSprite.imgObj = tImg;
      this.curBallSprite.texture = this.frame(tImg, 0, 0);
    }
    // 3.渲染下一个发射球
    this.renderNext(true);
    // 4.检测并返回连续的个数
    let spriteArr = this.getEqualNum(newSprite);

    if (spriteArr.length >= 3) {
      // 播放音效
      this.audioFun("default");

      // 1.隐藏消除的元素
      spriteArr.forEach(sprite => {
        sprite.visible = false;
      });
      // 2.检测没有悬挂的点的元素
      let noHangs = this.getNoHangs();
      // 3.隐藏没有悬挂的元素
      noHangs.forEach(sprite => {
        sprite.visible = false;
      });
      // 4.执行动画
      // 记录当前已消除个数 执行完后再调用回调
      this.tempCount = 0;
      this.totalCount = spriteArr.length + noHangs.length;
      // 消除该元素
      spriteArr.forEach(sprite => {
        let imgObj = sprite.imgObj;

        let bubbleSprite;
        if (imgObj.renderType == "down") {
          // 生成线条
          let bubbleLine = this.options.gameSource.bubbleLine;
          if (!!bubbleLine) {
            // console.log("线条--")
            let lineObj = Object.assign({}, {
              type: "animate",
              x: sprite.x - sprite.width / 2,
              y: sprite.y,
              boomSpeed: bubbleLine.speed,
              bubbleLine: true,
              srcArr: bubbleLine.arr,
              beginStop: true,//开始不播放
            }, bubbleLine.arr[0]);
            lineObj.spriteW = lineObj.width * this.options.$game.fObj.scale;
            lineObj.spriteH = lineObj.height * this.options.$game.fObj.scale;

            bubbleSprite = this.renderSprite(lineObj);
          }
        }

        if (!!imgObj.boomArr && imgObj.boomArr.length > 0) {
          let animateObj = Object.assign({}, {
            type: "animate",
            fadeBubble: true,// 标识消除元素，改变坐标圆心
            srcArr: imgObj.boomArr,
            boomSpeed: imgObj.boomSpeed,
            width: imgObj.width,
            height: imgObj.height,
            x: sprite.x,
            y: sprite.y,
            callback: () => {
              this.tempCount++;
              if (!!bubbleSprite) {
                bubbleSprite.play();
              }
              if (this.totalCount == this.tempCount) {
                this.fadeDone(spriteArr, noHangs);
              }
            }
          });
          this.renderSprite(animateObj);
        }
      })
      // 没有悬挂点的元素也做消失
      noHangs.forEach(sprite => {
        let imgObj = sprite.imgObj;
        let bubbleSprite;
        if (imgObj.renderType == "down") {
          // 生成线条
          let bubbleLine = this.options.gameSource.bubbleLine;
          if (!!bubbleLine) {
            // console.log("线条--")
            let lineObj = Object.assign({}, {
              type: "animate",
              x: sprite.x - sprite.width / 2,
              y: sprite.y,
              boomSpeed: bubbleLine.speed,
              bubbleLine: true,
              srcArr: bubbleLine.arr,
              beginStop: true,//开始不播放
            }, bubbleLine.arr[0]);
            lineObj.spriteW = lineObj.width * this.options.$game.fObj.scale;
            lineObj.spriteH = lineObj.height * this.options.$game.fObj.scale;

            bubbleSprite = this.renderSprite(lineObj);
          }
        }
        if (!!imgObj.boomArr && imgObj.boomArr.length > 0) {
          let animateObj = Object.assign({}, {
            type: "animate",
            fadeBubble: true,// 标识消除元素，改变坐标圆心
            srcArr: imgObj.boomArr,
            boomSpeed: imgObj.boomSpeed,
            width: imgObj.width,
            height: imgObj.height,
            x: sprite.x,
            y: sprite.y,
            callback: () => {
              this.tempCount++;
              if (!!bubbleSprite) {
                bubbleSprite.play();
              }
              if (this.totalCount == this.tempCount) {
                this.fadeDone(spriteArr, noHangs);
                // 判断新球 有没有超过计分线
                if (newImg.y + this.spriteH / 2 >= this.lifeY) {
                  // 超过了，结束游戏
                  this.gameOver();
                }
              }
            }
          });
          this.renderSprite(animateObj);
        }
      })

      // let arr = [];
      this.spriteArr.forEach(sprite => {
        if (!!sprite.visible) {
          // arr.push(sprite);
        }
      })
      // this.spriteArr = arr;
    } else {
      // 没有消除
      this.updateFun();

      // 判断新球 有没有超过计分线
      if (newImg.y + this.spriteH / 2 >= this.lifeY) {
        // 超过了，结束游戏
        this.gameOver();
      }
    }
  },
  fadeDone: function (spriteArr, noHangs) {
    this.curScore = 0;
    spriteArr.forEach(sprite => {
      this.totalScore += sprite.imgObj.val;
      this.curScore += sprite.imgObj.val;
    })
    noHangs.forEach(sprite => {
      this.totalScore += sprite.imgObj.val;
      this.curScore += sprite.imgObj.val;
    })

    this.updateFun({ spriteArr, noHangs });
  },
  getNoHangs: function () {
    // 获取没有悬挂的元素
    // 1.获取第一行元素
    let firstLineSprite = [];
    this.spriteArr.forEach(sprite => {
      if (!!sprite.visible) {
        if (Math.abs(sprite.y - this.spriteW / 2) < 0.1) {
          firstLineSprite.push(sprite);
        }
      }
    })
    // 2.递归循环第一行元素连接的元素
    firstLineSprite.forEach(sprite => {
      // 打标识
      this.checkBS1(sprite);
    })

    let noHangs = [];
    this.spriteArr.forEach(sprite => {
      if (!!sprite.visible) {
        if (!sprite.xuangua) {
          noHangs.push(sprite);
        } else {
          sprite.xuangua = false;
        }
      }
    });

    return noHangs;
  },
  checkBS1: function (sprite) {
    sprite.xuangua = true;
    let hasSprite = this.getBoundings(sprite, "has");
    hasSprite.forEach(ts => {
      if (!!ts.visible && !ts.xuangua) {
        this.checkBS1(ts);
      }
    })
  },
  quchong: function (arr) {
    // 去重
    let tt = [];
    arr.forEach(sprite => {
      let bl = true;
      tt.forEach(t => {
        if (t.x == sprite.x && t.y == sprite.y) {
          bl = false;
        }
      })
      if (bl) {
        tt.push(sprite);
      }
    })
    return tt;
  },
  // 泡泡碰撞
  hitBubble: function () {
    // 圆形碰撞模型
    let result = "";
    if (this.curBallSprite.y - this.curBallSprite.width / 2 <= 0) {
      // 球已经飞出屏幕上方
      let lineNum = this.lastType == "max" ? this.options.rowMaxNum : this.options.rowMaxNum - 1;
      let baseX = this.lastType == "max" ? 0 : this.spriteW / 2;
      baseX += this.options.paddingLeft;
      let x;
      for (let i = 0; i < lineNum; i++) {
        let tempX = i * this.spriteW + baseX + this.spriteW / 2;
        if (tempX - this.spriteW / 2 <= this.curBallSprite.x && this.curBallSprite.x <= tempX + this.spriteW / 2 && !x) {
          x = tempX;
        }
      }
      result = {
        x: x,
        y: this.curBallSprite.width / 2,
        isOut: true
      };
      return result;
    }
    this.spriteArr.forEach(sprite => {
      if (!!sprite.visible) {
        let x = sprite.x - this.curBallSprite.x,
          y = sprite.y - this.curBallSprite.y,
          radius = this.spriteW;
        // 加1是为了防重叠 temp = 1;
        let temp = 0;
        if (Math.pow((x), 2) + Math.pow((y), 2) <= Math.pow((radius), 2) + temp && !result) {
          result = {
            x: sprite.x,
            y: sprite.y,
            sprite
          };
          return result;
        }
      }
    })
    return result;
  },
  frame: function (img, x, y) {
    if (img.name == "curBallSprite") {
      // 生成发射球
      try {
        this.options.renderSendBallFun(img);
      } catch (e) { }
    }
    // 返回texture
    let source = img.src, width = img.width, height = img.height;
    if (img.type == "pao" && !!img.nextImg && !!img.nextImg.src) {
      source = img.nextImg.src;
    }
    if (y > img.height) {
      y = img.height;
    }

    let texture, imageFrame;
    if (typeof source === "string") {
      if (PIXI.utils.TextureCache[source]) {
        texture = new PIXI.Texture(PIXI.utils.TextureCache[source]);
      }
    }
    if (!texture) { console.log(`Please load the ${source} texture into the cache.`); } else {
      imageFrame = new PIXI.Rectangle(x, y, width, height);
      texture.frame = imageFrame;
      return texture;
    }
  },
  renderSprite: function (img) {
    let imgArr = img;
    if (Object.prototype.toString.call(img) == "[object Array]") {
      // 数组
    } else {
      // 对象
      imgArr = [img];
    }
    for (let i = 0, total = imgArr.length; i < total; i++) {
      let tImg = imgArr[i];
      let sprite;
      if (!tImg.uniId) {
        // 没有唯一标识，说明第一次生成
        if (tImg.type == "animate") {
          // 动画
          let textures = [];
          tImg.srcArr.forEach(img => {
            textures.push(this.frame(img, 0, 0));
          })
          sprite = new PIXI.extras.AnimatedSprite(textures);
          sprite.animationSpeed = tImg.boomSpeed;
          sprite.loop = !!tImg.loop;
          sprite.onComplete = function () {
            if (!tImg.animationDoneShow) {
              this.visible = false;
            }
            if (!!tImg.callback) {
              try {
                tImg.callback();
              } catch (e) { }
            }
            // console.log("动画播放完毕...");
          }
        } else {
          if (!!tImg.srcArr && tImg.srcArr.length > 0) {
            // 动画
            let textures = [];
            tImg.srcArr.forEach(img => {
              textures.push(this.frame(img, 0, 0));
            })
            sprite = new PIXI.extras.AnimatedSprite(textures);
            sprite.animationSpeed = tImg.srcArrSpeed || 0.1;
            sprite.loop = true;
            sprite.play();
          } else {
            sprite = new PIXI.Sprite();
            sprite.texture = this.frame(tImg, 0, 0);
          }
        }

        sprite.width = tImg.spriteW || this.spriteW;
        sprite.height = tImg.spriteH || this.spriteH;

        sprite.x = (tImg.x || 0);
        sprite.y = (tImg.y || 0);
        sprite.imgObj = tImg;
        if (!!tImg.name) {
          this[tImg.name] = sprite;
        }

        tImg.uniId = this.uniId();
        if (!!tImg.allName) {
          this[tImg.allName] = sprite;
        }

        if (tImg.type == "animate") {
          if (!!tImg.fadeBubble) {
            sprite.anchor.set(0.5, 0.5);
          } else if (!!tImg.longOrShortLine) {
            sprite.anchor.set(0, 0.5);
          }
          sprite.type = tImg.type;
          sprite.stop()
          if (!!tImg.beginStop) {
            sprite.gotoAndStop(0);
          } else {
            sprite.gotoAndPlay(0)
          }
          if (!!tImg.bubbleLine) {
            sprite.anchor.set(0, 0.5);

            this.bubbleLineArr.push(sprite);
            this.bubbleLineContainer.addChild(sprite);
          } else if (!!tImg.longOrShortLine) {
            this.longOrShortSpriteArr.push(sprite);
            this.longOrShortContainer.addChild(sprite);
          } else {
            this.animateSpriteArr.push(sprite);
            this.animateContainer.addChild(sprite);
          }
        } else if (tImg.type == "pao") {
          if (tImg.name == "paotongSprite") {
            // 设置旋转中心
            this.paotongSprite.anchor.set(0.5, 1);
          } else if (tImg.name == "curBallSprite") {
            this.curBallSprite.anchor.set(0.5, 0.5);
          } else if (tImg.name == "helpLineSprite") {
            this.helpLineSprite.anchor.set(0.5, 1);
          }

          this.paoSpriteArr.push(sprite);
          this.paoContainer.addChild(sprite);
        } else if (tImg.type == "bubbleLine") {
          sprite.anchor.set(0, 0.5);

          this.bubbleLineArr.push(sprite);
          this.bubbleLineContainer.addChild(sprite);
        } else {
          sprite.anchor.set(0.5, 0.5);
          sprite.type = !!tImg.type;
          this.spriteArr.push(sprite);
          this.spriteContainer.addChild(sprite);
        }

        return sprite;
      }
    }
  },
  // 获取了能量
  updateFun: function (obj) {
    this.playStatus = true;
    this.totalBall--;
    if (this.totalBall <= 0) {
      // 游戏结束
      this.gameOver();
    }
    obj = Object.assign({ totalScore: this.totalScore, curScore: this.curScore, curBallNum: this.totalBall }, obj);
    this.curScore = 0;

    if (!!this.options.nextRenderLine) {
      let nowBall = 0;
      this.spriteArr.forEach(sprite => {
        if (!!sprite.visible) {
          nowBall++;
        }
      })
      if (nowBall == 0) {
        // 生成下一波可消除球球
        this.addLine(this.options.nextRenderLine);
      }
    }
    try {
      this.options.updateFun(obj);
    } catch (e) { }
  },
  renderLineSprite: function () {
    let y = 0;
    let minSprite = null;
    this.spriteArr.forEach(sprite => {
      if (!!sprite.visible) {
        if (!minSprite) {
          minSprite = sprite;
        } else {
          if (sprite.y < minSprite.y) {
            minSprite = sprite;
          }
        }
      }
    })
    if (!minSprite) {
      // 没有数据，生成在第一行之上
      y = -this.spriteH / 2;
      this.lastType = this.options.firstBottomLineType;
    } else {
      // 有数据
      y = minSprite.y - (this.spriteH / 2 + this.stepHeight);
      this.lastType = this.lastType == "min" ? "max" : "min";
    }
    if (!this.moveDown) {
      this.moveDown = Math.abs(y) + this.spriteH / 2;
    } else {
      if (this.moveDown < Math.abs(y)) {
        this.moveDown = Math.abs(y) + this.spriteH / 2;
      }
    }
    // 当前行数据
    let lineNum = this.lastType == "max" ? this.options.rowMaxNum : this.options.rowMaxNum - 1;
    let baseX = this.lastType == "max" ? 0 : this.spriteW / 2;
    baseX += this.options.paddingLeft;

    if (!this.imgArr) {
      this.totalProbability = 0;
      this.imgArr = [];
      this.options.gameSource.items.forEach(item => {
        item.probability = item.probability || 1;
        item.max = this.totalProbability + item.probability
        this.totalProbability = item.max;
        this.imgArr.push(Object.assign({}, item));
      });
    }

    for (let i = 0; i < lineNum; i++) {
      let imgObj = this.getImg({
        x: i * this.spriteW + baseX + this.spriteW / 2,
        y: y,
        renderType: "down",
      });
      if (i == 0) {
        imgObj.renderLineType = this.lastType;
      }

      let src = imgObj.src;
      if (!!imgObj.defaultBg) {
        imgObj.src = imgObj.defaultBg.src;
      }
      let sprite = this.renderSprite(imgObj);
      if (!!imgObj.defaultBg) {
        sprite.defaultBg = true;
        sprite.imgObj.src = src;
      }
      if (this.options.gameSource.alphaStep) {
        sprite.alpha = 0;
      }
    }
  },
  moveDownSpriteFun: function (callback) {
    let tempDown = this.moveDown;
    this.moveDown = 0;
    let tempLen = 0;
    let downLen = 0;
    let bl = false;
    // 下移精灵
    this.spriteArr.forEach(sprite => {
      if (!!sprite.visible) {
        // 判断最下面的球 有没有超过计分线
        if (tempDown + sprite.y + this.spriteH / 2 >= this.lifeY) {
          bl = true;
        }
        tempLen++;
        this.tickerStart(sprite, this.options.speed, tempDown + sprite.y, () => {
          downLen++;
          if (!!sprite.defaultBg) {
            sprite.defaultBg = false;
            sprite.texture = this.frame({
              src: sprite.imgObj.src,
              width: sprite.imgObj.width,
              height: sprite.imgObj.height,
            });
          }
          if (downLen == tempLen) {
            // 精灵下移动画完成
            try {
              if (!!bl) {
                // 超过了，结束游戏
                this.gameOver();
              }

              callback();
            } catch (e) { }
          }
        });
      }
    });
  },
  moveYFun: function (sprite, speed, maxNum, callback) {
    if (sprite.y == maxNum && sprite.alpha == 1) { return false; }
    let stepAlpha = this.options.gameSource.alphaStep || 0.01;
    if (sprite.alpha != 1) {
      sprite.alpha = Math.min(sprite.alpha + stepAlpha, 1);
    }
    // y轴移动
    let tempNum = sprite.y + speed;
    if (speed > 0) {
      // 精灵向下移动
      tempNum = Math.min(tempNum, maxNum);
    } else {
      // 精灵向上移动
      tempNum = Math.max(maxNum, tempNum);
    }
    sprite.y = tempNum;
    if (sprite.y == maxNum && sprite.alpha == 1) {
      this.tickerStop();
      let delayTime = 0;
      try {
        delayTime = sprite.imgObj.defaultBg.delayTime || 0;
      } catch (e) { }

      if (!!sprite.imgObj.renderLineType) {
        // 判断线上长线还是短线
        if (this.options.gameSource.longLine) {
          let lineImg = {
            x: 0, y: sprite.y,
            type: "animate",
            animationDoneShow: true,
            longOrShortLine: true,
          };
          // longLine
          if (sprite.imgObj.renderLineType == "max") {
            // 长线
            lineImg = Object.assign(lineImg, this.options.gameSource.longLine);
          } else {
            // 短线
            lineImg = Object.assign(lineImg, this.options.gameSource.shortLine);
          }
          sprite.imgObj.renderLineType = null;
          lineImg.srcArr = lineImg.arr;
          lineImg.boomSpeed = lineImg.speed;
          lineImg.spriteW = lineImg.arr[0].width * this.options.$game.fObj.scale;
          lineImg.spriteH = lineImg.arr[0].height * this.options.$game.fObj.scale;
          let lineSprite;
          lineImg.callback = () => {
            setTimeout(() => {
              lineSprite.visible = 0;
              try {
                callback();
              } catch (e) { }
            }, delayTime)
          };
          lineSprite = this.renderSprite(lineImg);
        }
      } else {
        setTimeout(() => {
          try {
            callback();
          } catch (e) { }
        }, delayTime)
      }
    } else {
      setTimeout(() => {
        this.tickerStart(sprite, speed, maxNum, callback);
      }, this.options.speedTotalTime || 0)
    }
  },
  getImg: function (options, ops) {
    ops = Object.assign({ notSrc: "" }, ops);
    // 默认只生成标准items元素
    let maxNum = this.totalProbability;
    let num1 = this.random({ max: maxNum });
    let imgObj;
    this.options.gameSource.items.forEach(item => {
      if (!imgObj && num1 < item.max) {
        imgObj = item;
      }
    });
    if (imgObj.src == ops.notSrc) {
      // 连续重复了，重新生成
      imgObj = this.getImg(options, ops);
    }
    return Object.assign({}, options, imgObj);
  },
  hideSpriteArrFun(name, ops) {
    let options = Object.assign({ childs: [] }, ops);
    if (!!this[name]) {
      this[name].forEach(sprite => {
        if (!!sprite.visible) {
          sprite.visible = false;
        }
        options.childs.forEach(t => {
          if (!!sprite[t] && !!sprite[t].visible) {
            sprite[t].visible = false;
          }
        })
      })
    }
  },
  init: function (defaultData = {}) {
    this.hideSpriteArrFun("spriteArr");
    this.hideSpriteArrFun("paoSpriteArr");
    this.hideSpriteArrFun("bubbleLineArr");
    this.hideSpriteArrFun("animateSpriteArr");
    this.hideSpriteArrFun("longOrShortSpriteArr");
    // 数组
    this.spriteArr = defaultData.spriteArr || [];// 存放精灵数组
    this.paoSpriteArr = defaultData.paoSpriteArr || [];// 存放精灵数组
    this.bubbleLineArr = defaultData.bubbleLineArr || [];//精灵背后线条数组
    this.animateSpriteArr = defaultData.animateSpriteArr || [];// 存放动画精灵数组
    this.longOrShortSpriteArr = defaultData.longOrShortSpriteArr || [];//存放长线短线数组
    this.playStatus = false;//当前游戏不可操作
    // 总分数
    this.totalScore = defaultData.totalScore || (0 + (this.options.baseScore || 0));

    this.stepHeight = (Math.sqrt(3) - 1) * (this.spriteW / 2);
    // 初始化生成指定行数球
    this.addLine(this.options.firstShowLine, true);

    // 绘制线条
    let lineImg = Object.assign({ type: "pao", name: "lineSprite" }, this.options.gameSource.line);
    lineImg.spriteW = lineImg.width * this.options.$game.fObj.scale;
    if (!!lineImg.showAllWidth) {
      lineImg.spriteW = this.width;
    }
    lineImg.spriteH = lineImg.height * this.options.$game.fObj.scale;
    lineImg.x = (this.width - lineImg.spriteW) / 2;
    if (typeof lineImg.top != "undefined") {
      lineImg.y = lineImg.top * this.options.$game.fObj.scale;
    }
    if (typeof lineImg.bottom != "undefined") {
      lineImg.y = this.height - lineImg.bottom * this.options.$game.fObj.scale;
    }
    this.lifeY = lineImg.y + lineImg.height / 2;
    this.renderSprite(lineImg);

    // 绘制下一个发射球背景
    let nextBallBgImg = Object.assign({ type: "pao", name: "nextBallBgSprite" }, this.options.gameSource.nextBallBg);
    nextBallBgImg.spriteW = nextBallBgImg.width * this.options.$game.fObj.scale;
    nextBallBgImg.spriteH = nextBallBgImg.height * this.options.$game.fObj.scale;
    nextBallBgImg.x = (this.width - nextBallBgImg.spriteW) / 2;
    nextBallBgImg.y = this.height - nextBallBgImg.spriteH;

    // 当前剩余的可发射球个数
    this.totalBall = this.options.totalBall;

    // 绘制发射炮
    let paoImg = Object.assign({ type: "pao", name: "paotongSprite" }, this.options.gameSource.pao);
    paoImg.spriteW = paoImg.width * this.options.$game.fObj.scale;
    paoImg.spriteH = paoImg.height * this.options.$game.fObj.scale;
    paoImg.x = (this.width - paoImg.spriteW) / 2 + paoImg.spriteW / 2;
    paoImg.y = this.height;// - paoImg.spriteH - nextBallBgImg.height * this.options.$game.fObj.scale / 2 + paoImg.spriteH;

    // 绘制辅助线
    if (!!this.options.gameSource.helpLine) {
      let helpImg = Object.assign({ type: "pao", name: "helpLineSprite" }, this.options.gameSource.helpLine);
      helpImg.spriteW = helpImg.width * this.options.$game.fObj.scale;
      helpImg.spriteH = helpImg.height * this.options.$game.fObj.scale;
      helpImg.x = paoImg.x + Math.sin(this.angule || 0) * paoImg.spriteH;
      helpImg.y = paoImg.y - Math.cos(this.angule || 0) * paoImg.spriteH;
      this.renderSprite(helpImg);
      this.helpLineSprite.visible = false;
    }

    this.angule = 0;
    // 绘制当前发射球
    let curBallImg = this.getImg({
      type: "pao",
      name: "curBallSprite",
    });
    curBallImg.spriteW = this.spriteW;
    curBallImg.spriteH = this.spriteH;

    this.baseCurBallX = paoImg.x;
    this.baseCurBallY = paoImg.y - paoImg.spriteH / 2 - 4 * this.options.$game.fObj.scale;

    curBallImg.x = this.baseCurBallX;
    curBallImg.y = this.baseCurBallY;
    this.renderSprite(curBallImg);
    // 渲染发射炮 发射炮在当前发射球之后渲染 让发射炮上面的透明球渲染在当前发射球之上
    this.renderSprite(paoImg);

    // 渲染发射球背景
    this.renderSprite(nextBallBgImg);
    // 生成下一个发射球
    this.nextBallSprite = null;
    this.renderNext(true);
  },
  renderNext: function (bl, type) {
    if (!bl && !this.playStatus) { return false; }
    if (this.totalBall <= 2 && type != "no") {
      // 渲染为空 当用户球不够时
      this.nextBallSprite.imgObj = null;
      this.nextBallSprite.texture = null;
      return false;
    }
    // 生成下一个发射球
    if (!this.nextBallSprite) {
      let nextBallImg = this.getImg({
        type: "pao",
        name: "nextBallSprite",
        spriteW: (this.nextBallBgSprite.imgObj.height - 2 * this.nextBallBgSprite.imgObj.padding) * this.options.$game.fObj.scale,
        spriteH: (this.nextBallBgSprite.imgObj.height - 2 * this.nextBallBgSprite.imgObj.padding) * this.options.$game.fObj.scale,
      });
      nextBallImg.x = (this.width - nextBallImg.spriteW) / 2;
      nextBallImg.y = (this.height - nextBallImg.spriteH) - this.nextBallBgSprite.imgObj.height * this.options.$game.fObj.scale / 2 + nextBallImg.spriteH / 2;

      if (!!this.options.gameSource.nextBallBg && !!this.options.gameSource.nextBallBg.nextBallPos) {
        nextBallImg.spriteW = this.options.gameSource.nextBallBg.nextBallPos.width * this.options.$game.fObj.scale;
        nextBallImg.spriteH = this.options.gameSource.nextBallBg.nextBallPos.height * this.options.$game.fObj.scale;
        nextBallImg.x = (this.width - nextBallImg.spriteW) / 2 + (this.options.gameSource.nextBallBg.nextBallPos.left || 0) * this.options.$game.fObj.scale;
        nextBallImg.y = this.height - nextBallImg.spriteH - (this.options.gameSource.nextBallBg.nextBallPos.bottom || 0) * this.options.$game.fObj.scale;
      }
      this.renderSprite(nextBallImg);
    } else {
      // 已经存在 直接替换图片
      let notSrc = "";
      try {
        notSrc = this.nextBallSprite.imgObj.src;
      } catch (e) { }
      let tImg = this.getImg({
        type: "pao",
        name: "nextBallSprite",
        spriteW: (this.nextBallBgSprite.imgObj.height - 2 * this.nextBallBgSprite.imgObj.padding) * this.options.$game.fObj.scale,
        spriteH: (this.nextBallBgSprite.imgObj.height - 2 * this.nextBallBgSprite.imgObj.padding) * this.options.$game.fObj.scale,
        x: this.nextBallSprite.x,
        y: this.nextBallSprite.y,
      }, { notSrc });
      this.nextBallSprite.imgObj = tImg;
      this.nextBallSprite.texture = this.frame(tImg, 0, 0);
    }

    this.nextBallSprite.visible = false;
  },
  tickerStart(sprite, speed, maxNum, callback) {
    let _this = this;
    this.tickerStopStatus = false;

    this.ticker.addOnce(() => {
      _this.moveYFun(sprite, speed, maxNum, callback);
    });
    this.ticker.start();
    /* function ani() {
      _this.moveYFun(sprite, speed, maxNum, callback);

      if (!_this.tickerStopStatus) {
        _this.req = _this.options.$game.fObj.pixiCanvas.requestAnimationFrame(ani)
      }
    }

    ani(); */
  },
  tickerStop() {
    // this.ticker.stop();
    this.tickerStopStatus = true;
    /* this.options.$game.fObj.pixiCanvas.cancelAnimationFrame(this.req) */
  }
})
Game.prototype.addBubble = function (num = 1, bl) {
  if (!!this.addBubbleStatus) { return false; }
  this.addBubbleStatus = true;
  this.totalBall += num;
  this.addBubbleStatus = false;

  if (!!bl) {
    // 调用回调
    this.options.onAddBallCallBack({
      cur: num,
      total: this.totalBall
    });
  }

  // 检测
  // 1.判断是否渲染发射球
  if (!this.curBallSprite.imgObj) {
    // 没有发射球 
    // 1.判断下一个发射球
    if (!this.nextBallSprite.imgObj) {
      // 下一个发射球也没有
      this.renderNext(true, "no");
    }
    // 有下一个发射球 将下一个发射球转到当前发射球上
    this.curBallSprite.x = this.baseCurBallX;// + Math.sin(this.angule || 0) * this.paotongSprite.height - Math.sin(this.angule || 0) * this.spriteW / 2;
    this.curBallSprite.y = this.baseCurBallY;// - Math.cos(this.angule || 0) * this.paotongSprite.height + Math.cos(this.angule || 0) * this.spriteW / 2;
    let tImg = Object.assign({}, this.nextBallSprite.imgObj);
    tImg.uniId = "";
    tImg.type = "pao";
    tImg.name = "curBallSprite";
    this.curBallSprite.imgObj = tImg;
    this.curBallSprite.texture = this.frame(tImg, 0, 0);
    // 判断是否还有球 如果还有球，则渲染下一个发射球 如果没有球，则清空下一个发射球
    if (this.totalBall > 1) {
      this.renderNext(true, "no");
    } else {
      this.nextBallSprite.imgObj = null;
      this.nextBallSprite.texture = null;
    }
  } else {
    // 1.判断下一个发射球
    if (!this.nextBallSprite.imgObj) {
      // 发射球渲染了
      this.renderNext(true, "no");
    }
  }
};
// 生成球 lineNum:生成行数，默认一行
Game.prototype.addLine = function (lineNum = 1, bl) {
  if (!bl && !this.playStatus) { return false; }
  if (!!this.addLineStatus) { return false; }
  this.addLineStatus = true;

  for (let i = 1; i <= lineNum; i++) {
    this.renderLineSprite();
  }
  this.moveDownSpriteFun(() => {
    this.addLineStatus = false;
  });
}
// 游戏结束
Game.prototype.gameOver = function () {
  if (!!this.playStatus) {
    this.playStatus = false;
    try {
      this.options.overFun(this.totalScore);
    } catch (e) { }
  }
}
// 重置游戏
Game.prototype.reset = function () {
  this.init();
}
Game.prototype.startGame = function () {
  this.playStatus = true;

  // 判断剩余球是否大于0
  if (this.totalBall > 0) {
    // 1.判断是否渲染发射球
    if (!this.curBallSprite.imgObj) {
      // 没有发射球 
      // 1.判断下一个发射球
      if (!this.nextBallSprite.imgObj) {
        // 下一个发射球也没有
        this.renderNext(true, "no");
      }
      // 有下一个发射球 将下一个发射球转到当前发射球上
      this.curBallSprite.x = this.baseCurBallX;// this.paotongSprite.x + Math.sin(this.angule || 0) * this.paotongSprite.height - Math.sin(this.angule || 0) * this.spriteW / 2;
      this.curBallSprite.y = this.baseCurBallY;//this.paotongSprite.y - Math.cos(this.angule || 0) * this.paotongSprite.height + Math.cos(this.angule || 0) * this.spriteW / 2;
      let tImg = Object.assign({}, this.nextBallSprite.imgObj);
      tImg.uniId = "";
      tImg.type = "pao";
      tImg.name = "curBallSprite";
      this.curBallSprite.imgObj = tImg;
      this.curBallSprite.texture = this.frame(tImg, 0, 0);
      // 判断是否还有球 如果还有球，则渲染下一个发射球 如果没有球，则清空下一个发射球
      if (this.totalBall > 1) {
        this.renderNext(true, "no");
      } else {
        this.nextBallSprite.imgObj = null;
        this.nextBallSprite.texture = null;
      }
    } else {
      // 1.判断下一个发射球
      if (!this.nextBallSprite.imgObj) {
        // 发射球渲染了
        this.renderNext(true, "no");
      }
    }
  } else {
    // 开始失败
    this.playStatus = false;
  }
}

export {
  Game
}