import { Formatter, Path, SitemapPathOptions } from "./types";
import { NSArgs } from "sitemap/dist/lib/sitemap-stream";
export declare function generateSitemaps(paths: Array<Path>, base: string, xslUrl: string, xmlns: NSArgs, publicPath: string, filename: string, skipgzip: boolean, globalPathOptions: SitemapPathOptions, formatter?: Formatter): Promise<Array<string>>;
//# sourceMappingURL=generators.d.ts.map