import { Compiler } from "webpack";
import { Configuration } from "./types";
export default class SitemapWebpackPlugin {
    private base;
    private paths;
    private filename;
    private xslUrl;
    private xmlns;
    private skipgzip;
    private formatter?;
    private globalPathOptions;
    constructor(configuration: Configuration);
    private emitSitemaps;
    private emitCompressedSitemaps;
    private run;
    apply(compiler: Compiler): void;
}
//# sourceMappingURL=index.d.ts.map