import { SitemapItemLoose, EnumChangefreq } from "sitemap";
import { NSArgs } from "sitemap/dist/lib/sitemap-stream";
export declare type SitemapPathOptions = Omit<SitemapItemLoose, "url" | "lastmod" | "changefreq"> & {
    lastmod?: string | boolean;
    changefreq?: string | EnumChangefreq;
};
declare type PathOptions = SitemapPathOptions & {
    path: string;
};
export declare type Path = string | PathOptions;
export declare type ConfigurationOptions = SitemapPathOptions & {
    xslUrl?: string;
    xmlns?: NSArgs;
    filename?: string;
    skipgzip?: boolean;
    formatter?: (code: string) => string;
};
export declare type Configuration = {
    base: string;
    paths: Array<Path>;
    options?: ConfigurationOptions;
};
export declare type Formatter = (code: string) => string;
export {};
//# sourceMappingURL=types.d.ts.map