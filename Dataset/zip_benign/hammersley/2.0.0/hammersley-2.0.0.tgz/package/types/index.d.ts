export default hammersley;
export function radicalInverse(i: any): number;
declare function hammersley(i: any, n: any): number[];
