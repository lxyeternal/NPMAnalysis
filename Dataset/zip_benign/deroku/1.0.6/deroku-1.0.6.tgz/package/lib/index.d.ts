export function emojify(TextToEmojify: string, IsForDiscord: boolean): string;
export function style(TextToStyle: string): string;
export function fortnite(text: string, size: number|string, color: string): string;
export const version: number
export function compareVersion(v: number): void;

export namespace emojify {
    const prototype: {};
}

export namespace style {
    const prototype: {};
}

export namespace fortnite {
    const prototype: {};
}

export namespace compareVersion {
    const prototype: {};
}