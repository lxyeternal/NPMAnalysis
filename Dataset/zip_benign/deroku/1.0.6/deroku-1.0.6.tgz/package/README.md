#  Deroku
What is the Deroku?
the Deroku is a discord selfbot made by me. It have ~80 commands.

What is this package?
This package is some util method to help me developping the selfbot. I am making this now because i will soon finish the 0.5 version of the selfbot.

If you want, you can still use this package. docs:
```javascript
let deroku = require("deroku")
message.channel.send(deroku.style("Example")) 
// 𝙀𝙭𝙖𝙢𝙥𝙡𝙚
message.channel.send(deroku.emojify("Example", true))// true if this will be used in discord.
//:regional_indicator_e::regional_indicator_x::regional_indicator_a::regional_indicator_m::regional_indicator_p::regional_indicator_l::regional_indicator_e:
message.channel.send(deroku.emojify("Example", false))
//🇪🇽🇦🇲🇵🇱🇪
```
For now, only this can be downloaded. The source code is obfuscated.