# xtinypng

```shell
npm install -g xtinypng
```

```
Usage: xtinypng <filename | path> [options]

Options:
  -V, --version           output the version number
  -j, --png2jpeg          PNG 转 JPEG
  -q, --quality <number>  JPEG 品质(0..100)
  -s, --smooth <number>   JPEG 平滑(0..100)
  -L, --speed <number>    PNG 速度(1..11) | 1
  -f, --floyd <number>    PNG 抖动(0-1) | 0.5
  -C, --ncolors <number>  PNG 调色板(2-256)
  -A, --shrink <number>   advpng压缩算法(0-4) | 2
  -sq, --show-quality     查看 JPEG 品质
  -d, --diff <number>     diff算法(1.2.3) | 1
  -t, --tiny-png          对比tinypng.com
  -h, --help              display help for command
```

- 替换 mozjpeg 版本 jpegtran.exe
- node-canvas Windows Installation Dependencies

https://github.com/Automattic/node-canvas/wiki/Installation:-Windows
