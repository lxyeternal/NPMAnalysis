//引入pixi引擎 
import * as PIXI from "@tbminiapp/pixi-miniprogram-engine";
// registerCanvas 注册canvas给PIXI 
const { registerCanvas, devicePixelRatio } = PIXI.miniprogram;
import { Game } from "./game";

Component({
  // 供pixi渲染的canvas
  pixiCanvas: null,
  mixins: [],
  data: {
    canvasId: ""
  },
  props: {},
  didMount() {
    this.gameReadyStatus = false;
    if (!!this.checkVersion()) {
      this.setData({
        canvasId: "canvas" + new Date().getTime()
      }, () => {
        this.parFun("onRef", this);
      });
    } else {
      if (my.tb.showErrorView) {
        my.tb.showErrorView({
          icon: this.props.versionImg || "",
          reason: '手淘版本太低',
          message: '升级版本',
          action: 3,
          success: (res) => {
            console.log(res);
          },
          fail: (res) => {
            console.log(res);
          }
        })
      } else {
        my.alert({
          content: "手淘版本太低，请先升级手淘"
        })
      }
    }
  },
  didUpdate() { },
  didUnmount() {
    try {
      this.fObj.application.destroy();
    } catch (e) { }
    try {
      this.fObj = null;
    } catch (e) { }
  },
  methods: {
    checkVersion() {
      let res = my.getSystemInfoSync()
      let bl = false;
      try {
        let versionA = (res.version + "").split(".");
        let checkVer = (this.props.version || "9.9") + "";
        let checkVerArr = checkVer.split(".");
        // 此处判断 大于 9.9.0版本才能运行游戏
        if (parseInt(versionA[0]) > parseInt(checkVerArr[0]) || (parseInt(versionA[0]) == parseInt(checkVerArr[0]) && parseInt(versionA[1]) >= parseInt(checkVerArr[1]))) {
          bl = true;
        }
      } catch (e) { }

      return bl;
    },
    parFun(funName, options) {
      try {
        // 判断组件是否有传入事件，如果没有，则再判断页面上是否有指定事件
        this.props[funName](options);
      } catch (e) { }
    },
    //读取节点信息
    dom(className) {
      return new Promise(function (resolve, reject) {
        let result = {};
        my.createSelectorQuery()
          .select(className)
          .boundingClientRect()
          .exec(([ret]) => {
            if (ret) {
              result.success = true;
              result.data = ret;
            } else {
              result.success = false;
            }
            resolve(result);
          })
      })
    },
    // canvas的onReady事件侦听函数 onCanvasReady
    async onCanvasReady() {
      try {
        this.fObj.application.destroy();
      } catch (e) { }
      // 建立canvas引用
      my._createCanvas({
        id: this.data.canvasId,
        success: async (canvas) => {
          // 拿到当前容器的宽高
          let canvasDom = await this.dom("#" + this.data.canvasId);
          if (!canvasDom.success) { return false; }
          let windowWidth = canvasDom.data.width;
          let windowHeight = canvasDom.data.height;

          let size = {
            windowWidth,
            windowHeight,
            devicePixelRatio
          };
          this.setData(size);
          // 为canvas设定宽高（需要设备宽高* 像素密度）;
          canvas.width = windowWidth * devicePixelRatio;
          canvas.height = windowHeight * devicePixelRatio;
          this.pixiCanvas = canvas;
          //为pixi引擎注册当前的canvas  
          registerCanvas(canvas);
          //初始化PIXI.Application  
          //计算application的宽高  
          const context = canvas.getContext('webgl');
          const application = new PIXI.Application({
            width: windowWidth,
            height: windowHeight,
            view: canvas,
            context: context,
            transparent: true,
            // 强制使用2d上下文进行渲染，如果为flase,则默认使用webgl渲染  
            // forceCanvas: true,
            // 设置resolution 为像素密度  
            resolution: devicePixelRatio,
          });

          this.fObj = {
            application,
            pixiCanvas: canvas,
            scale: windowWidth / 750,
            size,
            PIXI
          };

          this.game = new Game(Object.assign({
            $game: this,
            errorFun: e => {
              // loader读取资源报错时回调
              this.parFun("onError", e);
            },
            progressFun: progress => {
              // loader读取资源进度实时回调
              this.parFun("onProgress", progress);
            },
            updateFun: (item) => {
              // 获取能量方法
              this.parFun("onUpdate", item);
            },
            initDone: () => {
              this.gameReadyStatus = true;
              setTimeout(() => {
                this.parFun("onInitDone", this.game);
              }, 0)
            }
          }, this.props));
        },
      });
    },
    // 监听小程序canvas的touch事件，并触发pixi内部事件  
    onTouchHandle(event) {
      if (this.pixiCanvas && event.changedTouches && event.changedTouches.length) {
        this.pixiCanvas.dispatchEvent(event);
      }
    },
    start() {
      let bl = false;
      if (!!this.gameReadyStatus) {
        bl = true;
        this.game.startGame();
      } else {
        my.alert({ content: "游戏还在初始化中..." })
      }
      return bl;
    },
    stop(type) {
      this.game.stopGame(type);
    },
    yyy(callback) {
      this.game.yyy(callback);
    }
  },
});
