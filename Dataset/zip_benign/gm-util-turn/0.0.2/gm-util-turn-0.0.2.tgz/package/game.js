let PIXI;
let Game = function (options) {
  this.options = Object.assign({}, options);

  PIXI = this.options.$game.fObj.PIXI;
  this.width = this.options.$game.fObj.size.windowWidth;
  this.height = this.options.$game.fObj.size.windowHeight;
  this.scale = this.options.$game.fObj.scale;

  // 1.创建pixi需要的对象 容器
  // 精灵容器
  this.spriteContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.spriteContainer);
  my.sss = this.spriteContainer;
  // 动画容器
  this.animateContainer = new PIXI.Container();
  this.options.$game.fObj.application.stage.addChild(this.animateContainer);

  // 绘制个矩形，解决触摸事件
  let rect1 = new PIXI.Graphics();
  rect1.beginFill(0xff0000, 0);
  rect1.drawRect(0, 0, this.width, this.height);
  rect1.endFill();
  this.spriteContainer.addChild(rect1);
  this.spriteContainer.setChildIndex(rect1, 0);

  // 2.遍历图片资源 并 去重
  let imgArr = [];
  options.gameSource = JSON.parse(JSON.stringify(options.gameSource));
  this.traverse(options.gameSource, function (k, v) {
    if (k == "src" && !!v && !imgArr.includes(v) && !PIXI.utils.TextureCache[v]) {
      imgArr.push(v);
    }
  })

  // 定时更新
  this.ticker = PIXI.ticker.shared;
  this.ticker.autoStart = false;
  this.ticker.addOnce(() => { });

  // 3.加载图片资源
  if (imgArr.length > 0) {
    let loader = new PIXI.loaders.Loader();
    imgArr.forEach(item => {
      loader.add(this.uniId(), item);
    })
    this.pixiLoadFun(loader);
  } else {
    this.init();
    this.options.initDone();
  }
  // 绑定事件
  this.bindEvent();

  this.ticker.add(() => this.draw());
}
Game.prototype = Object.assign(Game.prototype, {
  pixiLoadFun: function (loader) {
    let time1 = new Date().getTime();
    loader.on("progress", e => {
      this.options.progressFun(e.progress);
    })
    loader.on("error", e => {
      this.options.errorFun(e);
    })
    loader.load(() => {
      // 资源加载完成
      time1 = "";
      this.init();
      this.options.initDone();
    });
    setTimeout(() => {
      // 5秒还没加载完，重新加载一遍
      if (!!time1) {
        console.log("重新加载资源...")
        this.pixiLoadFun(loader);
      }
    }, 5000)
  },
  uniId: function () {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  },
  random: function (options) {
    let opt = Object.assign({ min: 0, max: 0, isFloat: false, noNum: [] }, options);
    let tempNum;
    do {
      let num = Math.random() * (opt.max - opt.min) + opt.min;
      tempNum = !!opt.isFloat ? num : parseInt(num);
    } while (opt.noNum.includes(tempNum));
    return tempNum;
  },
  isArray: function (obj) {
    return obj instanceof Array;
  },
  isObject: function (obj) {
    // 判断数组对象
    if (!(obj instanceof Array) && (obj instanceof Object)) {
      return true;
    }
    return false;
  },
  traverse: function (obj, callback) {
    // 遍历json
    for (let name in obj) {
      // 如果是json对象
      if (this.isObject(obj[name])) {
        this.traverse(obj[name], callback);
      } else if (this.isArray(obj[name])) {
        // 数组对象
        obj[name].forEach(item => {
          this.traverse(item, callback);
        })
      } else {
        callback(name, obj[name]);
      }
    }
  },
  bindEvent: function () {
    // 绑定事件
    this.spriteContainer.interactive = true;
    let startX, startY;
    let moveX = 0, moveY = 0;
    let wcz = 5;//误差值，如果滑动在此范围内，则视为点击事件
    let direction = "";
    this.spriteContainer.on('touchstart', (e) => {
      let x = e.data.global.x,
        y = e.data.global.y;
      startX = x;
      startY = y;
    })
    this.spriteContainer.on('touchmove', (e) => {
      if (startX == -1 || startY == -1) { return false; }
      let x = e.data.global.x,
        y = e.data.global.y;
      moveX = x - startX;
      moveY = y - startY;

      if (Math.abs(moveX) > wcz || !!direction) {
        startX = x;
        startY = y;
        direction == "none";
        if (!!this.spriteStatus) { return false; }
        // 滑动了
        if (moveX < 0) {
          // 向左滑动-----------------
          direction = "left";
        } else {
          // 向右滑动-----------------
          direction = "right";
        }
        this.tempMoveX = moveX;

        this.curAngle += -1 * moveX / 2;
      }
    })
    this.spriteContainer.on('touchend', (e) => {
      let bl = false, bl1 = false;
      if (!direction) {
        // 点击事件-----------------
        this.spriteArr.forEach(sprite => {
          if (!!sprite.isClick && !!sprite.visible) {
            if (sprite.x - sprite.width / 2 <= startX && startX <= sprite.x + sprite.width / 2 && sprite.y - sprite.height / 2 <= startY && startY <= sprite.y + sprite.height / 2) {
              bl = true;
              clearTimeout(this.clickTimer)
              this.updateFun(sprite);
            }
          }
        })
      } else {
        // 滑动事件
        if (direction == "left") {
          // 向左滑动-----------------
          bl1 = true;
        } else if (direction == "right") {
          // 向右滑动-----------------
          bl1 = true;
        }
      }
      if (!!bl) {
        this.tickerStop();
      }
      if (!!bl1 && direction != "none") {
        this.tickerStart();
        this.clickTimer = setTimeout(() => {
          if (!!this.options.gameSource.autoPlay) {
            this.tempMoveX = 0;
          }
        }, this.options.gameSource.clickTime || 1000)
      }
      direction = "";
      moveX = 0;
      moveY = 0;
      startX = -1;
      startY = -1;
    })
  },
  frame: function (img, x, y) {
    // 返回texture
    let source = img.src, width = img.width, height = img.height;

    let texture, imageFrame;
    if (typeof source === "string") {
      if (PIXI.utils.TextureCache[source]) {
        texture = new PIXI.Texture(PIXI.utils.TextureCache[source]);
      }
    }
    if (!texture) { console.log(`Please load the ${source} texture into the cache.`); } else {
      imageFrame = new PIXI.Rectangle(x, y, width, height);
      texture.frame = imageFrame;
      return texture;
    }
  },
  renderSprite: function (tImg) {
    let sprite;
    // 动画
    let textures = [];
    tImg.srcArr.forEach(img => {
      textures.push(this.frame(img, 0, 0));
    })
    sprite = new PIXI.extras.AnimatedSprite(textures);
    sprite.animationSpeed = tImg.speed;
    sprite.loop = true;

    sprite.width = tImg.width * this.scale;
    sprite.height = tImg.height * this.scale;

    sprite.x = (tImg.x || 0);
    sprite.y = (tImg.y || 0);
    sprite.imgObj = tImg;

    tImg.sprite = sprite;

    if (!!tImg.center) {
      // 中心点
      sprite.anchor.set(0.5, 0.5);
    }
    if (!!tImg.anchorObj) {
      // 底部中心
      sprite.anchor.set(tImg.anchorObj.x, tImg.anchorObj.y);
    }
    sprite.type = tImg.type;

    sprite.gotoAndPlay(0)
    sprite.stop()
    sprite.onComplete = function () {
      // console.log("动画播放完毕...");
      if (!!tImg.callback) {
        try {
          tImg.callback();
        } catch (e) { }
      }
    }
    // sprite.play();
    if (!!tImg.globalName) {
      this[tImg.globalName] = sprite;
    }

    this.spriteArr.push(sprite);
    this.spriteContainer.addChild(sprite);

    return sprite;
  },
  // 获取了能量
  updateFun: function (sprite) {
    try {
      this.options.updateFun(sprite.imgObj);
    } catch (e) { }
    this.clickTimer = setTimeout(() => {
      if (!!this.options.gameSource.autoPlay) {
        this.tempMoveX = 0;
      }
      this.tickerStart();
    }, this.options.gameSource.clickTime || 1000)
  },
  draw: function () {
    let _this = this;

    if (!!this.phoneSprite) {
      // 手机上下浮动--------------
      // 方向
      if (!this.phoneSpeed) {
        this.phoneSpeed = (this.phoneSprite.imgObj.topSpeed || 1);
      }
      if (!this.phoneSpriteBaseY) {
        this.phoneSpriteBaseY = this.phoneSprite.y;
      }
      let tempY = this.phoneSprite.y + this.phoneSpeed;
      let minTop = (this.phoneSprite.imgObj.minTop || 10) * this.scale;
      let maxTop = (this.phoneSprite.imgObj.maxTop || 10) * this.scale;
      if (tempY >= this.phoneSpriteBaseY + maxTop) {
        tempY = this.phoneSpriteBaseY + maxTop;
        this.phoneSpeed = this.phoneSpeed * -1;
      }
      if (tempY <= this.phoneSpriteBaseY - minTop) {
        tempY = this.phoneSpriteBaseY - minTop;
        this.phoneSpeed = this.phoneSpeed * -1;
      }
      this.phoneSprite.y = tempY;
      // 手机上下浮动--------------
    }
    // 摇一摇动画
    if (this.yyyStatus == "start") {

      let tempRotate = this.phoneSpriteRotate;
      this.phoneSpriteRotate += this.phoneRotateSpeed;
      if (!!this.phoneSprite) {
        let max = this.phoneSprite.imgObj.maxRotate;
        let min = this.phoneSprite.imgObj.minRotate;
        this.phoneSpriteRotate = Math.min(Math.max(this.phoneSpriteRotate, min), max);
        if (this.phoneSpriteRotate == max || this.phoneSpriteRotate == min) {
          // 达到最大值了，减小
          this.phoneRotateSpeed *= -1;
        }
        if ((tempRotate >= 0 && this.phoneSpriteRotate <= 0) || (tempRotate <= 0 && this.phoneSpriteRotate >= 0)) {
          this.rotateCount++;
        }
        if (this.rotateCount == this.phoneSprite.imgObj.rotateTo0Count) {
          this.yyyStop();
        }
        this.phoneSprite.rotation = this.phoneSpriteRotate;
      }
    }

    if (!!this.animationSprite) {
      this.spriteStatus = true;

      let tempSprite = this.animationSprite;
      this.animationSprite = null;

      tempSprite.onLoop = function () {
        // console.log("动画完璧...")
        tempSprite.gotoAndPlay(0);
        tempSprite.stop();
        tempSprite = null;
        _this.spriteStatus = false;
      }
      tempSprite.play();
    }
    if (!!this.spriteStatus) {
      return false;
    }
    if (!this.tempMoveX && !!this.options.gameSource.autoPlay) {
      this.curAngle += this.speed;
    }

    this.spriteArr.forEach(sprite => {
      let imgObj = sprite.imgObj;
      if (imgObj.type == "item") {
        let angle = imgObj.angle + this.curAngle;
        let radian = angle * (Math.PI / 180);

        sprite.x = this.globalData.circle_x + this.globalData.circle_a * Math.cos(radian);
        sprite.y = this.globalData.circle_y + this.globalData.circle_b * Math.sin(radian);
      }
    })

    this.sortFun();
  },
  setProp: function (ball, n1, n2) {
    return (((ball.y + ball.height / 2 - this.globalData.circle_y) + 2 * this.globalData.circle_b) / this.globalData.circle_b - 1) / 2 * (n2 - n1) + n1;
  },
  sortFun: function () {
    // 排序显示层级
    let backIndex = 0;
    let maxBackIndex = 0;
    this.spriteArr.forEach(sprite => {
      let imgObj = sprite.imgObj;
      if (imgObj.type == "item") {
        if (sprite.y + sprite.height / 2 * 0 <= this.globalData.circle_y) {
          // 元素在舞台后面(上面)
          maxBackIndex++;
        }
      }
    })
    this.spriteArr.forEach(sprite => {
      let imgObj = sprite.imgObj;
      if (imgObj.type == "item") {
        if (sprite.y + sprite.height / 2 * 0 <= this.globalData.circle_y) {
          // 元素在舞台后面(上面)
          sprite.pipei = false;
          this.spriteContainer.setChildIndex(sprite, backIndex);
          backIndex++;
          sprite.isClick = false;
        } else {
          // 元素在舞台前面(下面)
          this.spriteContainer.setChildIndex(sprite, maxBackIndex);
          maxBackIndex++;
          sprite.isClick = true;
          // 判断并执行动画
          if (!this.spriteStatus) {
            if (this.width / 2 - this.speed * 2 <= sprite.x && sprite.x <= this.width / 2 + this.speed * 2) {
              if (!sprite.pipei) {
                sprite.pipei = true;
                this.animationSprite = sprite;
              }
            } else {
              sprite.pipei = false;
            }
          }
        }
        let num = this.setProp(sprite, 0.7, 1.1);
        sprite.width = sprite.imgObj.baseW * num;
        sprite.height = sprite.imgObj.baseH * num;
      }
    })
    this.spriteContainer.setChildIndex(this.stageSprite, backIndex);
    backIndex++;
    this.spriteContainer.setChildIndex(this.phoneSprite, backIndex);
  },
  renderFun: function () {
    // 绘制精灵
    // 绘制手机
    let phoneImg = Object.assign({
      type: "phone",
      globalName: "phoneSprite"
    }, this.options.gameSource.phone);
    phoneImg.width = phoneImg.srcArr[0].width;
    phoneImg.height = phoneImg.srcArr[0].height;
    phoneImg.x = phoneImg.x * this.scale;
    phoneImg.y = phoneImg.y * this.scale;
    this.renderSprite(phoneImg);
    // 1.绘制舞台
    let stageImg = Object.assign({
      type: "stage",
      globalName: "stageSprite"
    }, this.options.gameSource.stage);
    stageImg.width = stageImg.srcArr[0].width;
    stageImg.height = stageImg.srcArr[0].height;
    stageImg.x = (this.width - stageImg.width * this.scale) / 2;
    stageImg.y = (this.height - stageImg.height * this.scale) / 2;

    this.renderSprite(stageImg);

    let stageImgObj = Object.assign({
      centerTop: 0,
      centerLeft: 0
    }, this.stageSprite.imgObj);

    this.globalData = {
      circle_a: stageImgObj.radiusW * this.scale,//椭圆长轴半径
      circle_b: stageImgObj.radiusH * this.scale,//椭圆短轴半径
      now_count: this.options.gameSource.items.length,//当前显示小球的个数
    };
    this.globalData.circle_x = this.stageSprite.x + this.globalData.circle_a + stageImgObj.paddingLeft * this.scale + stageImgObj.centerLeft * this.scale;//圆心的X坐标
    this.globalData.circle_y = this.stageSprite.y + this.globalData.circle_b + stageImgObj.paddingTop * this.scale + stageImgObj.centerTop * this.scale;//圆心的Y坐标
    // 2.绘制舞台周边精灵
    // 1.生成精灵
    this.options.gameSource.items.forEach((item, index) => {
      let angle = (index + 1) * (360 / this.globalData.now_count + 1);//角度
      let tempImg = Object.assign({
        type: "item",
        angle,
        index: index,
        center: true
      }, item);
      tempImg.width = tempImg.showWidth || tempImg.srcArr[0].width;
      tempImg.height = tempImg.showHeight || tempImg.srcArr[0].height;

      let radian = angle * (Math.PI / 180);//弧度
      tempImg.x = this.globalData.circle_x + this.globalData.circle_a * Math.cos(radian);
      tempImg.y = this.globalData.circle_y + this.globalData.circle_b * Math.sin(radian);
      tempImg.baseW = tempImg.width * this.scale;
      tempImg.baseH = tempImg.height * this.scale;

      let sprite = this.renderSprite(tempImg)
      let num = this.setProp(sprite, 0.7, 1.1);
      sprite.width = sprite.imgObj.baseW * num;
      sprite.height = sprite.imgObj.baseH * num;
    })

    this.sortFun();
  },
  hideSpriteArrFun(name) {
    if (!!this[name]) {
      this[name].forEach(sprite => {
        if (!!sprite.visible) {
          sprite.visible = false;
        }
      })
    }
  },
  init: function (defaultData = {}) {
    this.hideSpriteArrFun("spriteArr");
    this.hideSpriteArrFun("animateSpriteArr");
    // 障碍物
    this.spriteArr = defaultData.spriteArr || [];// 存放精灵数组
    this.animateSpriteArr = defaultData.animateSpriteArr || [];// 存放动画精灵数组
    this.speed = defaultData.speed || this.options.speed || 4;// 转动速度
    this.curAngle = defaultData.curAngle || 0;
    this.phoneRotateSpeed = defaultData.phoneRotateSpeed || 0;
    this.phoneSpriteRotate = defaultData.phoneSpriteRotate || 0;
    this.rotateCount = 0;

    // 1.绘制精灵
    this.renderFun();
    // 2.执行动画
    // this.draw();
  },
  tickerStart() {
    if (!!this.req) { return false; }
    this.req = true;

    this.ticker.start();
  },
  tickerStop() {
    this.req = null;

    this.ticker.stop();
  }
})
Game.prototype.yyy = function (callback) {
  if (this.yyyStatus == "start") { return false; }
  this.yyyStatus = "start";
  this.rotateCount = -1;
  this.phoneRotateSpeed = this.options.gameSource.phone.rotateSpeed || 0.01;
  this.yyyCallback = callback;
}
Game.prototype.yyyStop = function () {
  this.yyyStatus = "stop";
  this.phoneRotateSpeed = 0;
  this.phoneSpriteRotate = 0;
  this.phoneSprite.rotation = 0;
  try {
    this.yyyCallback();
  } catch (e) { }
}
// 游戏结束
Game.prototype.stopGame = function (type) {
  if (!this.iStart || this.iStart == "over") { return false; }
  this.pauseTime = new Date().getTime();
  this.tickerStop();
  this.iStart = "over";
  // 防止结束了还在移动
  let bl = true;
  if (!!this.options.playerAnimal) {
    if (type == "timeout") {
      // 倒计时结束结束游戏
      if (!!this.options.isTimeOverAnimal) {
        // 游戏时间结束结束游戏时，player动画是否执行，默认false不执行
        bl = false;
      }
    } else {
      // 碰撞到障碍物结束游戏
    }
  } else {
    if (!!this.overSprite && !!this.overSprite.imgObj.changePlayer) {
      this.changePlayerFun(this.overSprite);
    }
  }
  if (!bl) {
    this.animateBoom(() => {
      try {
        this.options.overFun({ score: this.totalScore, type });
      } catch (e) { }
    });
  } else {
    try {
      // 页面销毁时，不调用游戏结束回调
      if (type != "unmount") {
        this.options.overFun({ score: this.totalScore, type });
      }
    } catch (e) { }
  }
}
Game.prototype.startGame = function (type) {
  if (!!this.iStart) { return false; }
  this.iStart = "start";
  this.overSprite = null;
  if (!!this.playerSprite) {
    this.playerSprite.visible = true;
  }
  this.hideSpriteArrFun("animateSpriteArr");

  this.startTime = new Date().getTime();
  this.tickerStart();
}

export {
  Game
}