# gm-util-turn

# 工具-转圈

##### 安装

```
npm install gm-util-turn
```

##### 使用
```
必须开启 "enableSkia": "true"
```
```
如果项目需要使用插件，在window下加上 disablePluginSandBox：“true”
```
- json

```
{
    "usingComponents": {
        "util-turn": "gm-util-turn/turn"
    }
}
```

- js

```
Page({
  data: {
    gameSource: {
      // 游戏元素
      items: [{
        srcArr: [{
          src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01vjkxw81FJvbNBLorG_!!1080040467.png",
          width: 289,
          height: 267,
        }, {
          src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01i3vzzD1FJvbNBJXTK_!!1080040467.png",
          width: 289,
          height: 267,
        }],
        speed: 0.5,
      }, {
        srcArr: [{
          src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01i3vzzD1FJvbNBJXTK_!!1080040467.png",
          width: 289,
          height: 267,
        }, {
          src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01l1Eco41FJvbJknWNJ_!!1080040467.png",
          width: 289,
          height: 267,
        }],
        speed: 0.5,
      }, {
        srcArr: [{
          src: "https://img.alicdn.com/imgextra/i2/1080040467/O1CN01l1Eco41FJvbJknWNJ_!!1080040467.png",
          width: 289,
          height: 267,
        }, {
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ku32F71FJvbOyxZJ7_!!1080040467.png",
          width: 289,
          height: 267,
        }],
        speed: 0.5,
      }, {
        srcArr: [{
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01ku32F71FJvbOyxZJ7_!!1080040467.png",
          width: 289,
          height: 267,
        }, {
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01TznthO1FJvbMyUSiu_!!1080040467.png",
          width: 289,
          height: 267,
        }],
        speed: 0.5,
      }, {
        srcArr: [{
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01TznthO1FJvbMyUSiu_!!1080040467.png",
          width: 289,
          height: 267,
        }, {
          src: "https://img.alicdn.com/imgextra/i4/1080040467/O1CN01vjkxw81FJvbNBLorG_!!1080040467.png",
          width: 289,
          height: 267,
        }],
        speed: 0.5,
      }],
      stage: {
        srcArr: [{
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01RHIKNg1FJvbQMvNzl_!!1080040467.png",
          width: 429,
          height: 185
        }],
        radiusW: 390 / 2 + 185,//椭圆横轴半径
        radiusH: 120 / 2 + 40,//椭圆纵轴半径
        centerLeft: 0,//圆心在居中位置向左位移值
        centerTop: 0,//圆心在居中位置向上位移值
        paddingLeft: -160,
        paddingTop: -80,
        speed: 0.3
      },
      phone: {
        srcArr: [{
          src: "https://img.alicdn.com/imgextra/i1/1080040467/O1CN01zt9CDW1FJvbPH0uJh_!!1080040467.png",
          width: 309,
          height: 425,
        }],
        x: 750 / 2,
        y: 685,
        topSpeed: 0.1,//上下浮动速度
        minTop: 10,//上下浮动基于初始位置向上移动的最大位置
        maxTop: 10,//上下浮动基于初始位置向下移动的最大位置
        maxRotate: 0.2,//左右角度
        minRotate: -0.2,
        rotateTo0Count: 2,//转到0位置的次数，等于此数字，则停止
        rotateSpeed: 0.009,
        anchorObj: {
          x: 0.5,
          y: 1
        },
        speed: 0.5,
      },
      autoPlay: !false,//自动播放
      clickTime: 1000,//点击后间隔时间，动画继续执行
    },
  },
  onLoad() { },
  onRef(game) {
    this.turnComponent = game;
  },
  stopFun() {
    this.turnComponent.stop();
  },
  beginFun() {
    this.turnComponent.start();
    this.startListenYyy();
  },
  yFun(callback) {
    this.turnComponent.yyy(callback);
  },
  startListenYyy() {
    // 监听手机摇一摇
    my.onAccelerometerChange(function (res) { });
    this.listenYyy();
  },
  stopListenYyy() {
    // 停止监听摇一摇
    my.offGyroscopeChange();
  },
  listenYyy() {
    let _this = this;
    let temp = { x: '0', y: '0', z: '0' };
    let count = 0;
    let time = 0;
    let lmd = 1.0;
    my.onGyroscopeChange((e) => {
      // console.log('x,y,z:' + temp.x + ',' + temp.y + ',' + temp.z);
      // console.log('count:' + count);
      // console.log('time:' + time);
      if (temp == null) {
        temp = e;
      }
      if (temp.x - e.x > lmd || e.x - temp.x > lmd) {
        time += 1;
      }
      if (temp.y - e.y > lmd || e.y - temp.y > lmd) {
        time += 1;
      }
      if (temp.z - e.z > lmd || e.z - temp.z > lmd) {
        time += 1;
      }
      count += 1;
      temp = e;
      if (count >= 3) {
        if (time >= 3) {
          // 触发震动
          _this.stopListenYyy();
          _this.yFun(() => {
            _this.startListenYyy();
          })
        } else {
          count = 0;
          time = 0;
        }
      }
    });
  },

  onInitDone() {
    this.beginFun();
  },
});

```

- xaml

```
  <util-turn
      gameSource="{{gameSource}}"
      speed="{{0.4}}"
      
      onRef="onRef"
      onInitDone="onInitDone" 
  />
```