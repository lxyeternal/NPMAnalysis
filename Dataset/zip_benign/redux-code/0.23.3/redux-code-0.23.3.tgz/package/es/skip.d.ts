import { Middleware, AnyAction } from 'redux'
/**
 *
 * A special object to make an ability to skip actions.
 * This is only can be used with skipMiddleware
 */
export declare const SKIP: AnyAction
export declare const skipMiddleware: Middleware
