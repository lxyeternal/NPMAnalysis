import { AnyAction, Reducer, Store } from 'redux'
/**
 *
 * Types of persist actions
 */
export declare const persistTypes: {
  /** Rehydrate an reducer */
  readonly REHYDRATE: 'persist/rehydrate'
  /** All reducers were completely rehydrated */
  readonly COMPLETE: 'persist/complete'
  /** Purge an reducer state */
  readonly PURGE: 'persist/purge'
  /** Pause an reducer persistence */
  readonly PAUSE: 'persist/pause'
  /** Resume an reducer persistence */
  readonly RESUME: 'persist/resume'
}
declare type PersistStorage = {
  setItem: (key: string, value: any) => Promise<void>
  getItem: (key: string) => Promise<any>
  removeItem: (key: string) => Promise<void>
}
export declare type PersistConfig = {
  /**
   *
   * Persist key (name in storage, persist key in action)
   */
  key: string
  /**
   *
   * Storage to use
   */
  storage?: PersistStorage
  /**
   *
   * Rehydrate reducer state
   */
  serialize?: (state: any) => string
  /**
   *
   * Deserialize function
   */
  deserialize?: (stored: string) => any
  /**
   *
   * A function to compare different states
   */
  compare?: <S>(state: S, oldState: S, action: AnyAction) => boolean
  /** A function to merge states */
  merge?: <S>(stored: S, state: S) => S
  /** Throttle save in ms */
  throttle?: number
}
/**
 *
 * Create a mixin for a reducer that adds the ability to handle persistence.
 * @param {config} config The configuration.
 * @param {reducer} reducer The reducer to handle.
 */
export declare function persistReducer<S = any, A extends AnyAction = AnyAction>(
  config: PersistConfig,
  reducer: Reducer<S, A>,
): Reducer<S, A>
/**
 *
 * Create a store enhancer that rehydrates the state of reducers
 * @param {store} store The store to enhance.
 * @param {storage} storage The storage to use.
 */
export declare function persistStore(
  store: Store,
  storage?: PersistStorage,
): {
  rehydrate: () => Promise<{
    type: 'persist/complete'
  }>
  then: any
  purge: (key?: string) => void
  pause: (key?: string) => void
  resume: (key?: string) => void
}
/**
 *
 * Create a storage that uses localStorage
 */
export declare const localStorage: {
  setItem: (key: any, value: any) => Promise<void>
  getItem: (key: any) => Promise<string>
  removeItem: (key: any) => Promise<void>
  clear: () => Promise<void>
}
/**
 *
 * Create a storage that uses sessionStorage
 */
export declare const sessionStorage: {
  setItem: (key: any, value: any) => Promise<void>
  getItem: (key: any) => Promise<string>
  removeItem: (key: any) => Promise<void>
  clear: () => Promise<void>
}
/**
 *
 * Create a storage that uses memory
 */
export declare const memoryStorage: {
  setItem: (key: any, value: any) => Promise<void>
  getItem: (key: any) => Promise<any>
  removeItem: (key: any) => Promise<void>
}
export {}
