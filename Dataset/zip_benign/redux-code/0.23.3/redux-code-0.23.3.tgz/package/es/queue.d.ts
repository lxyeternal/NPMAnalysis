import { AnyAction } from 'redux'
export declare const queue: AnyAction[]
/**
 *
 * Dispatch an action to the store.
 * @param {action} action The action to dispatch.
 * @returns {action} The action.
 */
export declare function push(action: any): any
/**
 *
 * Clear the queue.
 */
export declare const clear: () => AnyAction[]
/**
 *
 * Create middleware that dispatches actions from the queue.
 */
export declare function middleware({
  dispatch,
}: {
  dispatch: any
}): (next: any) => (action: any) => any
