import { Actions, MixType, ActionCreatorResult } from './types'
/**
 * Create an action creator
 * @param type an action type
 * @param action a source to create an action creator
 */
export declare function createAction<
  TypeName extends string,
  Action extends (...args: any[]) => any,
>(
  type: TypeName,
  action: Action,
): {
  (...args: unknown[]): ActionCreatorResult<TypeName, ReturnType<Action>>
  type: TypeName
  toString(): TypeName
}
declare type UnionToIntersection<U> = (U extends any ? (k: U) => void : never) extends (
  k: infer I,
) => void
  ? I
  : never
/**
 * Build an action creator from a union of action creators
 * @param prefix the prefix of the actions type
 */
export declare function createActions<
  Prefix extends string,
  M extends S[] | Record<string, any>,
  S extends string,
>(prefix: Prefix, mixin: M): Actions<Prefix, MixType<M>>
export declare function createActions<
  Prefix extends string,
  Ms extends Array<S[] | Record<string, any>>, // we have to use any to prevent never
  S extends string,
>(prefix: Prefix, ...mixins: Ms): Actions<Prefix, UnionToIntersection<MixType<Ms[number]>>>
/**
 * Just a helper to create identity actions
 * createActions('prefix/', {update:identity, save:identity})
 */
export declare const identity: <T>(arg?: T) => T
export {}
