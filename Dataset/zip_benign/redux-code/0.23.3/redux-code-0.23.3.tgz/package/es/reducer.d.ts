import { Reducer } from 'redux'
/**
 *
 * A helper to create reducer (uses immer)
 * @param initial The initial state
 */
export declare const createReducer: <S>(
  initial: S,
  ...mixins: object[]
) => Reducer<S, import('redux').AnyAction>
/**
 *
 * A helper to create reducer (without immer)
 * @param initial The initial state
 */
export declare const createBaseReducer: <S>(
  initial: S,
  ...mixins: object[]
) => Reducer<S, import('redux').AnyAction>
export declare const buildStructuredReducer: (reducer: any) => any
