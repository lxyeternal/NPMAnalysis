import { Actions } from './types'
/**
 * Actions Mixin provides reset and update actions
 */
export declare const commonActions: {
  /**
   *
   * Creates an action to reset the state
   */
  reset: any
  /**
   *
   * Creates an action to update the state with the given payload
   */
  update: <T>(payload: T) => T
}
/**
 *
 * Creates a mixin for a reducer that adds the ability to reset and update the state
 * @param {actions} actions The actions to handle.
 * @param {initial} initial The initial state.
 */
export declare const commonReducer: <
  T extends Record<string, any> & {
    /**
     *
     * Creates an action to reset the state
     */
    reset: any
    /**
     *
     * Creates an action to update the state with the given payload
     */
    update: <T>(payload: T) => T
  },
  S,
>(
  actions: Actions<string, T>,
  initial: S,
) => {
  [x: string]: (
    state: object,
    {
      payload,
    }: {
      payload: any
    },
  ) => any
}
/**
 * Initial reducer.
 * Supports INIT action
 */
export declare const initReducer: (actions: Actions<string, Record<string, any>>) => {
  [x: string]: (state: any) => any
}
