import { Actions } from './types'
interface EntitiesState<Entity = any> {
  ids: string[]
  entities: Record<string, Entity>
}
export declare const entitiesActions: {
  /**
   * Creates an action to add a new entity to the store.
   * @param {entity} entity The entity to add.
   */
  addOne: (entity: any) => any
  /**
   * Creates an action to add multiple entities to the store.
   * @param {entities} entities The entities to add.
   */
  addMany: (entities: any[]) => any[]
  /**
   * Creates an action to update an entity in the store.
   * @param {entity} entity The entity to update.
   */
  updateOne: (entity: any) => any
  /**
   * Creates an action to update multiple entities in the store.
   * @param {entities} entities The entities to update.
   */
  updateMany: (entities: any[]) => any[]
  /**
   * Creates an action to insert or update an entity in the store.
   * @param {entity} entity The entity to insert or update.
   */
  upsertOne: (entity: any) => any
  /**
   * Create an action to insert or update multiple entities in the store.
   * @param {entities} entities The entities to insert or update.
   */
  upsertMany: (entities: any[]) => any[]
  /**
   * Creates an action to replace an entity in the store.
   * @param {entity} entity The entity to replace.
   */
  setOne: (entity: any) => any
  /**
   * Creates an action to replace multiple entities in the store.
   * @param {entities} entities The entities to replace.
   */
  setMany: (entities: any[]) => any[]
  /**
   * Creates an action to replace all entities in the store.
   * @param {entities} entities The entities to replace.
   */
  setAll: (entities: any[]) => any[]
  /**
   * Creates an action to remove an entity from the store.
   * @param {entity} entity The entity to remove.
   */
  removeOne: (entity: any) => any
  /**
   * Creates an action to remove multiple entities from the store.
   * @param {entities} entities The entities to remove.
   */
  removeMany: (entities: any[]) => any[]
  /**
   * Creates an action to remove all entities from the store.
   */
  removeAll: () => any
}
/**
 * Create a mixin for a reducer that adds the ability to handle entities.
 * @param {actions} actions The actions to handle.
 * @param {config} config The configuration.
 */
export declare const entitiesReducer: (
  actions: Actions<string, typeof entitiesActions>,
  {
    processEntity,
    selectId,
    sortComparer,
    updateComparer,
  }?: {
    processEntity?: <T>(entity: T) => T
    selectId?: (entity: any) => any
    sortComparer?: (a: any, b: any) => number
    updateComparer?: <T_1>(a: T_1, b: T_1) => boolean
  },
) => {
  [x: string]:
    | ((
        state: any,
        {
          payload,
        }: {
          payload: any
        },
      ) => {
        entities: {
          [k: string]: any
        }
        ids: any
      })
    | ((state: any) => any)
}
/**
 * Select the entities from the state.
 * @param {state} state The state.
 */
export declare const selectEntities: <Entity>(state: EntitiesState<Entity>) => Entity[]
/**
 * Select the entity with the given id from the state.
 * @param {state} state The state.
 */
export declare const selectEntityById: <Entity>(state: EntitiesState<Entity>, id: any) => Entity
/**
 * Select the total number of entities in the state.
 * @param {state} state The state.
 */
export declare const selectEntitiesTotal: (state: EntitiesState) => number
export {}
