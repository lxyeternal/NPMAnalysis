import {MeshLine, MeshLineMaterial, MeshLineRaycast} from './three.meshline'
import * as THREE from 'three'

const lineCollection = []

// 创建流动线条
export function createFlowLine(options, _this) {

  // 初始化设置loader 和当前屏幕大小
  let textureLoader = new THREE.TextureLoader()
  let resolution = new THREE.Vector2( _this.canvas.offsetWidth, _this.canvas.offsetHeight)

  // 默认设置
  const _options = {
    pointList: [ [20,5,10], [10,5,-9], [10,5,20], [-40,5,-40] ],
    color: 'red',
    useMap: true,                     
    lineWidth: 10,                              
    dashArray: 0.8,                   
    dashRatio: 0.5,                   
    dashOffset: 0,                    
    transparent: true,                
    sizeAttenuation: 0,
    shouldCurve: true               
  }
  Object.assign(_options, options)

  
  // 开始创建流动线
  textureLoader.load('/imgs/flowLine.png', function(texture) {
    // 使用MeshLine插件添加材质
    // 如果需要使用特定材质请添加材质图片不设置color并设置useMap为false
    const material = new MeshLineMaterial({
      color: _options.color,                     // 线条颜色
      map: texture,                              // 线条样式
      useMap: _options.useMap,                   // 时候使用texture，false时使用传入的color，true时使用color与texture混合
      lineWidth: _options.lineWidth,             // 线条宽度
      resolution: resolution,                    // 当前窗口大小
      dashArray: _options.dashArray,             // 上一个材质消失多少出现下一个材质(0材质不动，1上个材质消失完出现下个材质)
      dashRatio: _options.dashRatio,             // 线条流动速度
      dashOffset: _options.dashOffset,           // 线条初始时从哪里开始
      transparent: _options.transparent,         // 透明 
      sizeAttenuation: _options.sizeAttenuation, // 衰减（使线恒宽，让流动条变成线）
      side: THREE.AdditiveBlending,
    })
    
    // 将传入的点转变为连续的three支持的点
    const l = []
    _options.pointList.forEach(e => l.push(new THREE.Vector3(e[0], e[1], e[2])))
    // curve记录曲线顶点
    let curve = new THREE.CatmullRomCurve3(l)
    // geo使用bufferGeometry存储刚才的曲线顶点
    const geo = new THREE.BufferGeometry()

    if(_options.shouldCurve) { // 启用圆滑处理
      geo.vertices = curve.getPoints(50)  
    }else { // 不启用圆滑处理
      geo.vertices = curve.getPoints(_options.pointList.length - 1)
    }

    // 使用meshline插件传入刚才的bufferGeometry
    const meshLine = new MeshLine()
    meshLine.setGeometry(geo)
    
    // 将meshLineMaterial和meshLine进行mesh
    let line = new THREE.Mesh(meshLine.geometry, material)
    
    // 每次创建后记录全部创建的流动线
    lineCollection.push(line)
    _this.scene.add(line)
  })
}

// 获取当前创建的所有的流动线
export function requestLines(){
  return lineCollection
}