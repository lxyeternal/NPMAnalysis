import * as THREE from 'three'

export function createPlaneMesh(){
    let planeGeo = new THREE.PlaneBufferGeometry(2, 2);
    let planeMaterial = new THREE.MeshStandardMaterial({
        color: 0xeeeeee,
        side: THREE.DoubleSide
    })

    let plane = new THREE.Mesh(planeGeo, planeMaterial)
    plane.receiveShadow = true

    return plane
}
