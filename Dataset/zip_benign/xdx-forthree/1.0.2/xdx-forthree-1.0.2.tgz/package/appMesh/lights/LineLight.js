import * as THREE from "three";

function createMesh(options) {
  const lightGeometry = new THREE.CylinderBufferGeometry(0.1, 0.1, 2, 32);
  const lightMaterial = new THREE.MeshStandardMaterial({
    // transparent: true,
    opacity: 0.3,
    color: 0xeeeeee,
  });

  const light = new THREE.Mesh(lightGeometry, lightMaterial);
  const innerGeometry = new THREE.CylinderBufferGeometry(0.02, 0.02, 2, 32);
  const innerMaterial = new THREE.MeshStandardMaterial({
    // transparent: true,
    opacity: 0.8,
    color: 0x999999,
  });
  const inner = new THREE.Mesh(innerGeometry, innerMaterial);

  light.add(inner);

  const rectGeometry = new THREE.PlaneBufferGeometry(0.3, 2.2);
  const rectMaterial = new THREE.MeshStandardMaterial({
    side: THREE.DoubleSide,
    color: 0xc3bcbc,
  });

  const rectGroup = new THREE.Group();
  const rect1 = new THREE.Mesh(rectGeometry, rectMaterial);
  rect1.position.z = -0.2;
  const rect2 = rect1.clone();
  rect2.position.set(0.2, 0, -0.07);
  rect2.rotation.y = 2;

  const rect3 = rect1.clone();
  rect3.position.set(-0.2, 0, -0.07);
  rect3.rotation.y = -2;

  rect1.castShadow = true;
  rect2.castShadow = true;
  rect3.castShadow = true;

  rectGroup.add(rect1, rect2, rect3);

  // light.add(rectGroup)

  const realLight = new THREE.PointLight(
    options.color,
    options.intensity,
    options.distance,
    options.decay
  );
  realLight.castShadow = true;
  realLight.position.z = 0.3;

  realLight.shadow.mapSize.width = 512;
  realLight.shadow.mapSize.height = 512;
  realLight.shadow.camera.near = 0.5;
  realLight.shadow.camera.far = 500;

  // realLight.add(light)
  light.add(realLight);

  rectGroup.add(realLight);

  rectGroup.rotation.x = Math.PI / 2;

  rectGroup.name = "lightMesh";

  // const rectGroup1 = rectGroup.clone(true);
  // rectGroup1.position.x += 1.5;
  // const rectGroup2 = rectGroup.clone(true);
  // rectGroup2.position.x += 0.75;
  //
  // const result = new THREE.Group()
  //
  // result.add(rectGroup)
  // result.add(rectGroup1)
  // result.add(rectGroup2)

  rectGroup.scale.setScalar(2);

  return rectGroup;
}

export function createLineLight(options) {
  const _options = {
    color: 0xffffff,

    intensity: 0.5,
    // 光距
    distance: 10,
    // 衰退
    decay: 1,
  };

  Object.assign(_options, options);

  const realLight = createMesh(_options);

  return realLight;
}
