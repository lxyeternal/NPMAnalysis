import * as THREE from 'three'
import { FBXLoader } from "three/examples/jsm/loaders/FBXLoader"


// ***暴露的创建空调及空调相应功能函数***
export function createAirConditioner(options) {
  const _options = {
    // 开启状态
    state: 'on'
  };

  // 返回一个空three对象在异步任务处理完成后可以获得该对象
  Object.assign(_options, options)
  const airConditionerGroup = new THREE.Group()


  // 添加异步属性(给用户提供一个异步属性，表示对象创建完毕)
  airConditionerGroup.resolve = false
  airConditionerGroup.readyPromise = new Promise((resolve) => {  airConditionerGroup.resolve = resolve})
  // 异步加载模型
  let promise = createMesh(airConditionerGroup)
  

  // 异步任务处理完成后在刚才返回的对象中添加创建好的空调对象
  promise.then(models => {
    // 遍历所有创造好的模型，加入到组中
    for (let i in models) {
      airConditionerGroup.add(models[i])
    }
    // 添加空调内置功能
    airConditionerAddFun(airConditionerGroup)
    airConditionerGroup.resolve()
  })

  return airConditionerGroup

}


// ***添加模型相关的方法***
function createMesh() {

  let loader = new FBXLoader()
  let textureLoader = new THREE.TextureLoader()

  // 添加空调模型
  function addConditioner() {
    return new Promise((resolve) => {
      loader.load('http://172.18.22.146:8089/airConditioner/airConditioner.fbx', model => {
        model.test = "air"
        model.enableClick = true
        resolve(model)
      })
    })
  }

  // 添加吹风模型
  function addAirModels() {
    let plane = new THREE.PlaneBufferGeometry(15, 15)
    let airGroup = new THREE.Group()
    return new Promise((resolve) => {
      textureLoader.load('http://172.18.22.146:8089/airConditioner/airArrow.png', (texture) => {
        texture.warpT = texture.wrapS = THREE.RepeatWrapping
        texture.repeat.x = 2
        const material = new THREE.MeshBasicMaterial({
          map: texture,
          color: 0xeeeeee,
          side: THREE.DoubleSide
        })
        // z轴正方向风
        let mesh = new THREE.Mesh(plane, material)
        let adjustedMesh = adjustZMesh(mesh, -10, 20, -Math.PI / 9, Math.PI / 2)
        airGroup.add(adjustedMesh)

        let mesh2 = new THREE.Mesh(plane, material)
        adjustedMesh = adjustZMesh(mesh2, -23, 27.5, -Math.PI / 18 * 4, Math.PI / 2)
        airGroup.add(adjustedMesh)

        // z轴负方向风
        let mesh3 = new THREE.Mesh(plane, material)
        adjustedMesh = adjustZMesh(mesh3, -10, -20, Math.PI / 9, Math.PI / 2)
        airGroup.add(adjustedMesh)

        let mesh4 = new THREE.Mesh(plane, material)
        adjustedMesh = adjustZMesh(mesh4, -23, -27.5, Math.PI / 18 * 4, Math.PI / 2)
        airGroup.add(adjustedMesh)

        // x轴正方向风
        let mesh5 = new THREE.Mesh(plane, material)
        adjustedMesh = adjustXMesh(mesh5, 20, -10, Math.PI / 2 + Math.PI / 9, Math.PI / 2)
        airGroup.add(mesh5)

        let mesh6 = new THREE.Mesh(plane, material)
        adjustedMesh = adjustXMesh(mesh6, 27.5, -23, Math.PI / 2 + Math.PI / 18 * 4, Math.PI / 2)
        airGroup.add(mesh6)

        // x轴负方向风
        let mesh7 = new THREE.Mesh(plane, material)
        adjustedMesh = adjustXMesh(mesh7, -20, -10, Math.PI / 2 - Math.PI / 9, Math.PI / 2)
        airGroup.add(mesh7)

        let mesh8 = new THREE.Mesh(plane, material)
        adjustedMesh = adjustXMesh(mesh8, -27.5, -23, Math.PI / 2 - Math.PI / 18 * 4, Math.PI / 2)
        airGroup.add(mesh8)

        // 材质移动
        setInterval(() => {
          if (texture.offset.x >= 0.9) {
            texture.offset.x = 0
          }
          texture.offset.x += 0.05
        }, 100)
        resolve(airGroup)
      })
    })
  }

  // 模型集合存放所有的关于空调的模型
  const Group = []

  // 异步任务在创建好所有的空调模型后再返回
  async function addModels() {
    // 空调模型加载
    const conditioner = await addConditioner();
    Group.push(conditioner)
    // 出风模型加载
    const plane = await addAirModels()
    Group.push(plane)
    // 空调模型组
    return Group
  }

  const promise = addModels();

  return promise
}

// 调整z轴方向风模型用
function adjustZMesh(mesh, ty, tz, rx, rz) {
  mesh.material.transparent = true
  mesh.translateY(ty)
  mesh.translateZ(tz)
  mesh.rotateX(rx)
  mesh.rotateZ(rz)
  return mesh
}

// 调整x轴方向风模型用
function adjustXMesh(mesh, tx, ty, rz, rx) {
  mesh.material.transparent = true
  mesh.translateX(tx)
  mesh.translateY(ty)
  mesh.rotateZ(rz)
  mesh.rotateX(rx)
}


// ***给空调模型添加的内置方法***
function airConditionerAddFun(models) {
  // 控制空调开关状态
  models.onOff = function (flag) {
    if (flag == 'on') {
      models.children[1].visable = true
    }
    if (flag == 'off') {
      models.children[1].visible = false
    }
  },
  // 返回当前空调的位置等信息用于提交后端用
  models.submit = function() {
    const airStatement = {}
    airStatement.position = models.position
    airStatement.rotation = models.rotation
    airStatement.scale = models.scale
    airStatement.onOff = models.children[1].visable? 'on' : 'off'
    return airStatement
  }
}

