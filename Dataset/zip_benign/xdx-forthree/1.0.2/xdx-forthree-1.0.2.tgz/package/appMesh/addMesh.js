import {createLineLight} from "./lights/LineLight";
import {createPlaneMesh} from "./plane/Plane";
import {createAirConditioner} from './airConditioner/airConditioner'
import {createFlowLine} from './flowLine/flowLine'

const meshMap = {
    'lineLight': createLineLight,
    'plane': createPlaneMesh, 
    'airConditioner': createAirConditioner,
    'flowLine': createFlowLine
}

export default function addMesh(flag, options){
    const _this = this

    let mesh = meshMap[flag](options, _this);
    
    if(mesh){ 
        this.scene.add(mesh)
    }
    
    return mesh;
}
