import {GLTFLoader} from "three/examples/jsm/loaders/GLTFLoader";
import {FBXLoader} from "three/examples/jsm/loaders/FBXLoader";
import {OBJLoader} from "three/examples/jsm/loaders/OBJLoader";

export function addModel(url, process){
    const arr = url.split('.')
    const format = arr[arr.length-1];
    let loader;
    const promise = new Promise((resolve, reject) => {
        switch (format){
            case 'gltf':
            case 'glb':
                loader = new GLTFLoader()
                break;
            case 'fbx':
            case 'FBX':
                loader = new FBXLoader()
                break;
            case 'obj':
                loader = new OBJLoader()
                break;
        }
        loader.load(url, model=>{
            model.enableClick = false;
            resolve(model)
        }, process, error => reject(error));
    })

    return promise;

}

export function addModelEvent(model, event){
    switch (event){
        case 'click':
            model.enableClick = true;
    }
}


