import * as THREE from 'three'

const mouse = new THREE.Vector2();
const raycaster = new THREE.Raycaster();

export const event ={
    mousemove: null,
    mouse,
    enableMouseEvent: false
}

let width = 0;
let height = 0;


function onMouseMove(event){
    mouse.x = (event.clientX / width) * 2 -1;
    mouse.y = -(event.clientY / height) * 2 + 1;
}

export function rayModel(){
    raycaster.setFromCamera(mouse, this.camera)

    const intersects = raycaster.intersectObjects(this.scene.children, true);



    if (intersects.length > 0) {
        // 判断第一个检测到的mesh
        for(let i in intersects) {
            if(intersects[i].object.type == 'Mesh') {
                return intersects[i].object;
            }
        }
        // return intersects[0].object;

        // if(!!model && model.enableClick){
        //     console.log(1)
        // }
        // if(intersects[0].object.enableClick){
        //     console.log(1)
        // }
        // .object.visible = false
        // console.log(intersects)
    }
}

export function startRay(){
    this.canvas = this.renderer.domElement;

    width = this.canvas.clientWidth;
    height = this.canvas.clientHeight;

    event.mousemove = this.canvas.addEventListener(
        'mousemove', onMouseMove)


    // 最后执行
    event.enableMouseEvent  = true;

}
