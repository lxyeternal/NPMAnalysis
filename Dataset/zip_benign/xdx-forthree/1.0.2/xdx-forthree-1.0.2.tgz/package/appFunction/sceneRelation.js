import * as THREE from 'three'
/**
 * options 中有 type 参数, 表明灯的类型
 * @param options
 */
function createLight(options){
    let $option = {
        type: 1,
        color: 0x999999,
        intensity: 0.5,
    }
    Object.assign($option, options)
    switch ($option.type){
        case 1:
            return new THREE.AmbientLight($option.color,  $option.intensity)
        case 2:
            return new THREE.PointLight($option.color, $option.intensity)
    }
}

export function addLight(options){
    const light = createLight( options);
    this.scene.add(light)
    return light;
}
