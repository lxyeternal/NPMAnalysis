import {OrbitControls} from "three/examples/jsm/controls/OrbitControls";
import {TransformControls} from "three/examples/jsm/controls/TransformControls";

// let _this = this
export function addCameraControl(){
    let orbit = new OrbitControls(this.camera, this.renderer.domElement)
    orbit.update();
    // orbit.addEventListener('change', this.animation.bind(this))
    return orbit;
}


// eslint-disable-next-line no-unused-vars
export function addTransform(orbit){
    let transform = new TransformControls(this.camera, this.renderer.domElement);
    // transform.addEventListener('change', this.animation.bind(this))
    transform.addEventListener('dragging-changed', event=>{
        console.log(1, event.value)
        orbit.enabled = !event.value;
    })

    eventTransform(transform)

    transform.name = 'transform'

    let attach = transform.attach;

    transform.attach = (object)=>{
        attach.call(transform, object);
        eventTransform(transform)
    }

    this.scene.add(transform)

    return transform
}


export function eventTransform(transform){
    const keypressTransform = function (event){
        console.log(1)
        switch (event.key){
            case 'w':
            case 'W':
                transform.setMode("translate");
                break;
            case 'r':
            case 'R':
                transform.setMode("rotate");
                break;
            case 's':
            case 'S':
                transform.setMode("scale");
                break;
            case '+':
            case '=':
                transform.setSize(transform.size + 0.1);
                break;
            case '-':
            case '_':
                transform.setSize(transform.size - 0.1);
                break;
            case 'X':
            case 'x':
                transform.showX = ! transform.showX;
                break;
            case 'y':
            case 'Y':
                transform.showY = ! transform.showY;
                break;
            case 'z':
            case 'Z':
                transform.showZ = ! transform.showZ;
                break;
            case ' ':
                transform.enabled = !transform.enabled;
                break;
            case 'u':
            case 'U':
                transform.detach();
                transform.visible = false;
                document.removeEventListener('keypress', keypressTransform)
                break;

        }
    }

    document.addEventListener('keypress', keypressTransform)
}

// transform 绑定到点击的物体上
export function transformAttachModel(transForm) {
    let _this = this
    let model = findClickModel(_this)
    // 添加移动坐标轴
    transForm.attach(model)
    transForm.object = model
}

// 寻找点击处的模型
export function findClickModel(_this) {
    let model
    if(_this) {
        model = _this.rayModel()
    }else {
        model = this.rayModel()
    }
    // 点击的是空白或者xyz轴时不执行
    if (model == undefined || model.name == "XYZE") { return }
    // 找到最外层Group
    while (model.parent.type != 'Scene') {
      // 点击到transform时跳出循环
      if(model.type == "Object3D"){return}
      model = model.parent
    }
    return model
}