// import {event} from './raycasterRelation'
// import * as THREE from 'three'
import { requestLines } from '../appMesh/flowLine/flowLine'
// // const
//
// const raycaster = new THREE.Raycaster()


export default function Mounted(){
    // 获取需要渲染的动态线条
    let lines = requestLines()
    // 线条数组不为空时触发
    if(lines.length != 0) {
        for(let i of lines) {
            i.material.uniforms.dashOffset.value -= 0.01
        }
    }
    // if(event.enableMouseEvent){
    //     raycaster.setFromCamera(event.mouse, this.camera);
    //
    //     const intersects = raycaster
    // }
}
