import {addCameraControl, addTransform, transformAttachModel, findClickModel} from "./cameraRelation";
import {addModel, addModelEvent} from "./modelRelation";
import {addLight} from './sceneRelation'
import {rayModel, startRay}  from './raycasterRelation'
import addMesh from "../appMesh/addMesh";

/**
 * xdx 方法入口
 */
export default {
    addCameraControl,
    addTransform,
    transformAttachModel,   // 坐标轴绑定电机的模型
    findClickModel,         // 查询当前点击的模型

    // modelRelation
    addModel,
    addModelEvent,
    addMesh,

    addLight,

    // raycasterRelation
    startRay,
    rayModel,
}
