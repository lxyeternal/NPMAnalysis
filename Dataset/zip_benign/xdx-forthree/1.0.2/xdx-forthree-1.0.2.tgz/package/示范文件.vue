<template>
  <div class="hello">

<!--    <img src="" alt="">-->
    <canvas id="canvas"></canvas>
    <button @click="change">点击</button>
<!--    <div id="container"></div>-->
  </div>
</template>

<script>
import XDX from '@/assets/xdx'

// import * as THREE from 'three'

// import actions from "./childWorker";

// let scene;

// export {scene};

export default {
  name: 'HelloWorld',
  mounted() {
    this.init();

    // let worker = this.$worker.create(actions)

    // worker.postMessage('func1', ['hello i am parent worker'])
    //   .then(console.log)

    // let worker = new Worker('/child2.js');
    // worker.postMessage('hello, i am parent', [])

    this.img = document.querySelector('img')
    // let imageURL = this.canvas.toDataURL('./image/png')
    // let dom = document.querySelector('img')
    // this.img.src = imageURL;



  },
  methods: {
    init(){
      const dom = document.querySelector('#canvas')

      this.canvas = dom;

      const xdx = new XDX.App({
        canvas: dom,
        color: 0xeeeeee
      })

      // 添加视角移动
      const orbit = xdx.addCameraControl()

      // 添加物体移动,
      const transForm = xdx.addTransform(orbit)
      this.transForm = transForm;

      // scene = xdx.scene;

      let promise = xdx.addModel('/model/dog.FBX')
      // let dogModel;
      promise.then(model => {
        xdx.scene.add(model)

        model.traverse(child=>{
          if(child.isMesh){
            child.castShadow = true;
            child.receiveShadow = true;
          }
        })

        model.scale.set(0.4, 0.4, 0.4)
        model.position.set(0, -40, 0)
        // dogModel = model;
        xdx.addModelEvent(model, 'click')
      })

      // xdx.addLight({type: 1, color: 0xffffff})
      // const pointLight = xdx.addLight({type: 2, color: 0xffffff, intensity: 0.5})
      // pointLight.position.set(10, 10, 10)

      const light2 = xdx.addMesh('lineLight', {intensity: 1});
      this.light = light2
      transForm.attach(light2)

      // console.log(transForm)

      console.log(light2)

      // xdx.addMesh('plane')

      // dom.addEventListener('click', (event)=>{
      //   console.log(event)
      //   xdx.rayModel(dogModel)
      // })
    },
    change(event){
      // console.log(event)
      //
      // console.log(this.canvas)
      //
      // let imageURL = this.canvas.toDataURL('./image/png')

      // let img = document.createElement('img')
      //
      // img.src = imageURL;
      // this.img.src = imageURL

      // let dom = document.querySelector('img')
      // this.img.src = imageURL;

      console.log(event)
      this.transForm.attach(this.light)
      // this.transForm.attach(this.light)
      console.log(this.transForm, this.light)
      // this.transForm.enabled = true;
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
#canvas{
  width: 96vw;
  height: 95vh;
}
</style>
