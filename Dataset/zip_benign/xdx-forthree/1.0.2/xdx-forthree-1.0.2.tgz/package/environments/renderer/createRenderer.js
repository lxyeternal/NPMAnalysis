import * as THREE from 'three'

function initRenderer(renderer, options){
    renderer.setPixelRatio(window.devicePixelRatio);

    let canvas = renderer.domElement;

    // alpha 透明度

    // antialias 抗锯齿
    canvas.antialias = options.antialias;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.BasicShadowMap;

    renderer.setSize(canvas.clientWidth, canvas.clientHeight)


}

export function createRenderer(options){
    if(! ('canvas' in options)){
        console.error('没有传入正确的 canvas 标签')
    }

    const _options = {
        antialias: true
    }


    Object.assign(_options, options)

    let renderer = new THREE.WebGLRenderer(_options);

    initRenderer(renderer, _options)


    return renderer;
}
