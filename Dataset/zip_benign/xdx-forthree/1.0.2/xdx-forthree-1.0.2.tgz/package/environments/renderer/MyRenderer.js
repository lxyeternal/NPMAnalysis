
import {createRenderer} from './createRenderer'
/**
 * 与渲染器相关内容
 */
export default class MyRenderer{
    constructor(options) {
        this.$options = {
        }
        Object.assign(this.$options, options)

        this.renderer = createRenderer(this.$options);
    }
}
