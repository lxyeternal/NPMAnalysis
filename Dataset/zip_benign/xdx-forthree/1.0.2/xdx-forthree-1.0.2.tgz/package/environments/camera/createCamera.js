import * as THREE from 'three'

const cameraObj = {
    orthographicCamera (options){
        let $options = {
            left: -1,
            right: 1,
            top: 1,
            bottom: -1,
            near: 0.1,
            far: 2000
        }
        Object.assign($options, options)
        return new THREE.OrthographicCamera(
            $options.left,
            $options.right,
            $options.top,
            $options.bottom,
            $options.near,
            $options.far
        )
    },
    perspective(options){
        let $options = {
            fov: 50,
            aspect: 1,
            near: 0.1,
            far: 2000,
        }
        Object.assign($options, options)
        return new THREE.PerspectiveCamera(
            $options.fov,
            $options.aspect,
            $options.near,
            $options.far
        )
    }
}

/*function initCamera(camera, options){

}*/

/**
 *
 * @param options 表示相机的相关属性, 一定是相应相机的属性
 * options 包括两个属性, cameraOptions, cameraType
 * cameraType 一定是 类全名
 */
export function createCamera(options){
    let {cameraOptions, cameraType} = options
    let camera = cameraObj[cameraType](cameraOptions);

    camera.position.set(5, 5, 5)
    camera.lookAt(0, 0, 0 )
    // initCamera(camera, options)

    return camera;
}
