
import {createCamera} from "./createCamera";

/**
 * 相机有关内容
 */
export default class MyCamera{
    constructor(options) {

        // let cameraOptions
        // cameraType

        let cameraOptions = {
            aspect : options.canvas.clientWidth /
                options.canvas.clientHeight
        }

        let cameraType = 'perspective'

        this.camera = createCamera({
            cameraType, cameraOptions, ...options })
    }
}
