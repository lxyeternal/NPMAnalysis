// import * as THREE from 'three'
import {createScene} from "./sceneFunction";

/**
 * 场景类, 有成员 scene
 * 可扩展 属性有, autoUpdate, background, environment, fog, overrideMaterial
 */
export default class MyScene{
    constructor(options) {
        // 默认配置
        const $options = {

        }
        Object.assign($options, options);

        this.scene = createScene(options);

    }
}
