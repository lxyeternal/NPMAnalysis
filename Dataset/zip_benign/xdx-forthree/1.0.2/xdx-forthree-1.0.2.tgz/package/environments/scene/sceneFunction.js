import * as THREE from 'three'

function initScene(scene, options){
    scene.background = new THREE.Color(options.color)
}

/**
 * 根据 options 创建 scene
 * @param options
 * @return {Scene}
 */
// eslint-disable-next-line no-unused-vars
export function createScene(options){

    let scene = new THREE.Scene()

    initScene(scene, options)

    scene.add(new THREE.AxesHelper(3))

    return scene
}
