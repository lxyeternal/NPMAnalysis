import App from './App'
/**
 * xdx 西电 x 入口文件
 */
export default {
    App,
}
