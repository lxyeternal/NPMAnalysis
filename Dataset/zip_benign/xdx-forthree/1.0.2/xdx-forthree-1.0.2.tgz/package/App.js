import MyScene from "./environments/scene/MyScene";
import MyCamera from "./environments/camera/MyCamera";
import MyRenderer from "./environments/renderer/MyRenderer";
import AppFunction from "./appFunction/AppFunction"
import mounted from "./appFunction/Mount"
import * as TWEEN from "@tweenjs/tween.js";
import Stats from "three/examples/jsm/libs/stats.module";

/**
 *
 */
export default class App{
    constructor(options) {
        this.myScene = new MyScene(options);

        this.stats = new Stats()

        const canvas = options.canvas

        this.canvas  = canvas;

        canvas.parentNode.insertBefore(this.stats.dom, canvas)

        this.myCamera = new MyCamera(options);

        this.myRenderer = new MyRenderer({...options, canvas})

        this.scene = this.myScene.scene;
        this.camera = this.myCamera.camera;
        this.renderer = this.myRenderer.renderer;

        Object.assign(this, AppFunction)

        this.animation()


    }

    animation(time){
        // 遍历事件队列

        this.myRenderer.renderer.render(this.myScene.scene, this.myCamera.camera);

        TWEEN.update(time)

        this.stats.update()

        mounted()

        // class 中用到 requestAnimationFrame 需要设置animation的bind
        this.animationNum = requestAnimationFrame(this.animation.bind(this))
    }
}
