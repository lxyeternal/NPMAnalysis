# uic-immersive-page

![](https://img.shields.io/npm/v/@miapp/uic-immersive-page.svg?style=flat) ![](https://img.shields.io/npm/dt/@miapp/uic-immersive-page.svg?style=flat)

> uic-immersive-page

## 使用

    
在页面的 `page.json` 中配置：

```json
{
  "usingComponents": {
    "uic-immersive-page": "@miapp/uic-immersive-page/lib/index"
  }
}
```

在页面的 `page.axml` 中直接使用：

```html
<uic-immersive-page />
```
### option参数

| 属性 | 类型 | 默认值 | 描述 |
|:--|:--|:--|:--|
| `title` | string | `''` | 导航栏标题 |
| `icon` | string | `''` | 导航栏图标 |
| `backgroundColor` | HexColor | `#0368D9` | 导航栏背景色 |
| `bannerList` | Arrary | `[]` | banner区 |
| `bannerHeight` | String | `'904rpx'` | banner区高度 |
| `marginTop` | String | `'-110rpx'` | 主题内容距离banner距离 |
| `subShow` | boolean | `true` | 是否展示索引下标 |
| `subWidth` | String | `'100rpx'` | 索引下标宽度 |
| `subSize` | String | `'280rpx'` | 索引下标字体大小 |
| `subRadius` | String | `'30rpx'` | 索引下标圆角 |
| `subBg` | Color | `'rgba(255, 255, 255, 0.3)'` | 索引下标背景色 |
| `subColor` | HexColor | `#ffffff` | 索引下标字体颜色 |
| `autoplay` | boolean | `false` | 轮播图是否自动播放 |
| `showTheme` | boolean | `true` | 是否展示banner主题色 |
| `tabBarTheme` | boolean | `true` | tabbar背景色是否跟随banner主题色切换 |
| `trapScrollTop` | Number | `240` | 停止切换主题色时的滚动距离 |
| `interval` | Number | `3000` | 自动切换时间间隔 |
| `color` | HexColor | `#333333` | tab上的文字默认颜色 |
| `selectedColor` | HexColor | `#0368D9` | tab上的文字选中时的颜色 |
| `OnHandleTap` | EventHandle | `` | banner点击事件（已适配跳转url） |
| `tabBarItem` | Arrary | `[]` | tabBar参数 |
| `topButton` | boolean | `true` | 是否展示回顶部按钮 |
| `topIconUrl` | String | `''` | 返回顶部图标 |

tabBarItem

* `tabBarItem` 参数

  - index
  - text
  - iconPath
  - selectedIconPath

## 开发

1. `yarn` 安装依赖
2. 小程序 IDE 打开组件（[下载地址](https://opendocs.alipay.com/mini/ide/download)）

## 更多命令

* `miapp newbranch`: 新建分支
* `miapp push`: 提交代码
* `miapp prepub`: 预发（发布 beta 版本）
* `miapp publish`: 正式发布