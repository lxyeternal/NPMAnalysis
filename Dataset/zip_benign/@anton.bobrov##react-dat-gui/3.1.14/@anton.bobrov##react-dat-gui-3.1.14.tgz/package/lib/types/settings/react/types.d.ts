import { TData } from '../types';
import { TCreateDatGuiSettingsProps } from '../vanilla';
export declare type TUseDatGuiSettingsProps<T extends TData> = TCreateDatGuiSettingsProps<T>;
//# sourceMappingURL=types.d.ts.map