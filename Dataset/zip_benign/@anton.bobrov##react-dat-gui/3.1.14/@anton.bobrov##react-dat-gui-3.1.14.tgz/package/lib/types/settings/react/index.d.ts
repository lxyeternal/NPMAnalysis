import { TUseDatGuiSettingsProps } from './types';
import { TData } from '../types';
export * from './types';
/**
 * Create dat.gui settings
 *
 * @example
 *
 * const { defaults } = useDatGuiSettings({
 *   name: 'GUI Folder',
 *   parent: guiParentFolder,
 *   data: {
 *     color: 0xff0000,
 *     intensity: 0.5,
 *     isVisible: true,
 *   },
 *   parameters: {
 *     color: { type: 'color' },
 *     intensity: { type: 'number', min: 0, max: 1, step: 0.1 },
 *     isVisible: { type: 'boolean' },
 *   },
 *   onChange(current) {
 *     console.log(defaults, current);
 *   },
 * });
 */
export declare function useDatGuiSettings<T extends TData>({ name, isOpen, parent, data, parameters, onChange: onChangeProp, debounceDelay, }: TUseDatGuiSettingsProps<T>): {
    defaults: T;
    current: T;
};
//# sourceMappingURL=index.d.ts.map