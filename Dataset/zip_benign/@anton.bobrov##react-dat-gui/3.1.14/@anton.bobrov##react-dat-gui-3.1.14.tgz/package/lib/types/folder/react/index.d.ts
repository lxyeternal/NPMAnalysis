import { GUI } from '../../base';
import { TUseDatGuiFolderProps } from './types';
export * from './types';
/**
 * React hook to create and manage a dat.GUI folder.
 *
 * @example
 * const folder = useDatGuiFolder({ name: 'GUI Folder', parent: guiParentFolder });
 */
export declare function useDatGuiFolder({ name, isOpen, parent, }: TUseDatGuiFolderProps): GUI | null;
//# sourceMappingURL=index.d.ts.map