import { TCreateDatGuiFolderReturns, TCreateDatGuiFolderProps } from './types';
export * from './types';
/**
 * Creates a folder in a dat.GUI instance and provides a method to destroy it later.
 * This function handles asynchronous loading of `dat.gui` and manages the folder creation within the given `parent` GUI instance.
 *
 * @example
 * const instance = createDatGuiFolder({
 *   name: 'GUI Folder',
 *   parent: guiParentFolder,
 *   onCreate: (folder) => console.log(folder),
 * });
 *
 * instance.destroy();
 */
export declare function createDatGuiFolder({ name, onCreate, parent, isOpen, }: TCreateDatGuiFolderProps): TCreateDatGuiFolderReturns;
//# sourceMappingURL=index.d.ts.map