import type { GUI } from 'dat.gui';
declare global {
    interface Window {
        USE_DAT_GUI?: boolean;
        OPEN_DAT_GUI?: boolean;
    }
}
/**
 * Creates a dat.GUI instance for use in the browser.
 * It checks for the availability of the `dat.gui` library and global window flags (`USE_DAT_GUI` and `OPEN_DAT_GUI`) to conditionally load the GUI.
 *
 * @example
 *
 * datGUI.then((gui) => {
 *   if (gui) {
 *     // use dat.gui
 *   }
 * });
 */
export declare const datGUI: Promise<GUI | null>;
export type { GUI };
//# sourceMappingURL=index.d.ts.map