export declare type TNumber = {
    type: 'number';
    min: number;
    max: number;
    step: number;
};
export declare type TColor = {
    type: 'color';
};
export declare type TBoolean = {
    type: 'boolean';
};
export declare type TData = Record<string, number | boolean | unknown>;
export declare type TDataParameters<T extends TData> = {
    [Prop in keyof T]: T[Prop] extends boolean ? TBoolean : T[Prop] extends number ? TNumber | TColor : null;
};
//# sourceMappingURL=types.d.ts.map