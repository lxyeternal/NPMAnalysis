import { TCreateDatGuiFolderProps } from '../vanilla';
export declare type TUseDatGuiFolderProps = Omit<TCreateDatGuiFolderProps, 'onCreate'>;
//# sourceMappingURL=types.d.ts.map