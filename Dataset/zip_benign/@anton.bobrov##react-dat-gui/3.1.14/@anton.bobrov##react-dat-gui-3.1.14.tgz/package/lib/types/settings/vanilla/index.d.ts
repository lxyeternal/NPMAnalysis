import { TCreateDatGuiSettingsReturns, TCreateDatGuiSettingsProps } from './types';
import { TData } from '../types';
export * from './types';
/**
 * Creates a dat.GUI settings interface with different controls based on the provided parameters.
 *
 * @example
 * const instance = createDatGuiSettings({
 *   name: 'GUI Folder',
 *   parent: guiParentFolder,
 *   data: {
 *     color: 0xff0000,
 *     intensity: 0.5,
 *     isVisible: true,
 *   },
 *   parameters: {
 *     color: { type: 'color' },
 *     intensity: { type: 'number', min: 0, max: 1, step: 0.1 },
 *     isVisible: { type: 'boolean' },
 *   },
 *   onChange(current) {
 *     console.log(instance.defaults, current);
 *   },
 * });
 *
 * instance.destroy();
 */
export declare function createDatGuiSettings<T extends TData>({ name, isOpen, parent, data, parameters, onChange: onChangeProp, debounceDelay, }: TCreateDatGuiSettingsProps<T>): TCreateDatGuiSettingsReturns<T>;
//# sourceMappingURL=index.d.ts.map