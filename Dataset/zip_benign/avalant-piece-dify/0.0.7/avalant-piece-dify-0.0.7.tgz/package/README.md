# Dify

## Description
This piece provides integration with Dify's knowledgebase search functionality. It allows you to search through your Dify knowledgebases and retrieve relevant information.

## Authentication
This piece requires the following authentication parameters:
- **API Endpoint**: Your Dify API endpoint URL
- **API Key**: Your Dify API key

## Actions

### Search Knowledgebase
Search through a Dify knowledgebase using a query and get relevant results.

#### Input Parameters
- **Search Query**: The query to search for in the knowledgebase
- **Knowledgebase**: The ID of the knowledgebase to search in
- **Number of Results**: Number of top results to return (default: 3, range: 1-10)
- **Score Threshold**: Minimum similarity score threshold for results (default: 0.5, range: 0.0 to 1.0)

#### Output
Returns a JSON object containing the search results from Dify API.

## Example Usage
```typescript
const searchResults = await actions.search_knowledgebase({
  query: "How to get started?",
  knowledgebase: "kb_123456",
  topK: 3,
  scoreThreshold: 0.5
});
