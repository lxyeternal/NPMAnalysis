export declare const searchKnowledgebase: import("@activepieces/pieces-framework").IAction<undefined, {
    query: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    knowledgebase: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    topK: import("@activepieces/pieces-framework").NumberProperty<true>;
    scoreThreshold: import("@activepieces/pieces-framework").NumberProperty<false>;
}>;
