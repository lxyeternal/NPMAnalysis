export declare const knowledgebase: import("@activepieces/pieces-framework").Piece<undefined>;
export default knowledgebase;
