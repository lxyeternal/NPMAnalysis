"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.knowledgebase = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const search_knowledgebase_1 = require("./lib/actions/search-knowledgebase");
exports.knowledgebase = (0, pieces_framework_1.createPiece)({
    displayName: 'Knowledgebase',
    logoUrl: 'https://i.ibb.co/PZm04qwf/book-open-solid.png',
    minimumSupportedRelease: '0.5.0',
    authors: ['activepieces'],
    auth: pieces_framework_1.PieceAuth.None(),
    actions: [search_knowledgebase_1.searchKnowledgebase],
    triggers: [],
});
exports.default = exports.knowledgebase;
//# sourceMappingURL=index.js.map