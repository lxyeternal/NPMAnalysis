import { drawImage } from "./package/draw_image/draw_image";
import { drawReact, drawReactArrow } from "./package/draw_react/draw_react";
import { drawText } from "./package/draw_text/draw_text";
import { drawStone } from "./package/draw_stone/draw_stone";
import {version} from './package.json'
import { drawArc } from "./package/draw_cicle/draw_cicle";
import { drawLine } from "./package/draw_line/draw_line";
import { handleData } from './package/draw_st/index';
import { clearCanvas, clearReact } from "./package/clear_canvas/clear_canvas";
import { drawStTable } from "./package/draw_st/draw_st_table/draw_st_table";
import { drawStLine } from "./package/draw_st/draw_st_line/draw_st_line";
import { drawRtCh } from "./package/draw_st/draw_rtch/draw_rtch";

const DrawTool = {
    version,
    drawImage,
    drawReact,
    drawText,
    drawReactArrow,
    drawStone,
    drawArc,
    drawLine,
    handleData,
    clearCanvas, 
    clearReact,
    drawStTable,
    drawStLine,
    drawRtCh
    
}

let toolFn = [];
for (let fn in DrawTool) {
    if (fn === 'version') {
        continue;
    }
    toolFn.push(fn);
}
// 属性挂载
DrawTool['fnList'] = toolFn;

export { drawImage, drawReact, drawText, drawReactArrow, drawStone, drawArc, drawLine, clearCanvas, clearReact, drawStTable, handleData, drawStLine, drawRtCh };

export default DrawTool