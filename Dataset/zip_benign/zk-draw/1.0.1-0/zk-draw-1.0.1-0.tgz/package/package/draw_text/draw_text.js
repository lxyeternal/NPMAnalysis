/*
 * @Author: wangfpp 
 * @Date: 2020-04-27 18:33:01 
 * @Last Modified by: wangfpp
 * @Last Modified time: 2020-04-27 19:23:09
 */
// 绘制文本

import { copyCtxConf } from "../../comm/comm";

/**
 * @description 绘制文本
 * @param {Canvas 2D} ctx 
 * @param {String} text 绘制的文本 
 * @param {Object} option 绘制的附属参数
 */
const drawText = (ctx, text, x, y, option) => {
    const defaultConfig = copyCtxConf(ctx);
    let reactConfig = Object.assign(defaultConfig, option),
    {fillStyle, textAlign,  font  } = reactConfig;
    ctx.beginPath();
    ctx.font = font;
    ctx.fillStyle=fillStyle;
    ctx.textAlign = textAlign;
    ctx.fillText(text, x, y);
    ctx.closePath();
}

export { drawText };