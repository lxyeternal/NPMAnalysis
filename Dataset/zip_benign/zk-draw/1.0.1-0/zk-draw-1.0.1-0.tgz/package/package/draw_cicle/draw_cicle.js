/*
 * @Author: wangfpp 
 * @Date: 2020-04-27 17:42:50 
 * @Last Modified by: wangfpp
 * @Last Modified time: 2020-04-28 12:52:26
 */
// 绘制圆 圆心半径为圆的必须参数

import { copyCtxConf } from "../../comm/comm";
import { kpArr } from '../../comm/comm';

/**
 * 
 * @param {Canvas 2D} ctx 
 * @param {Array} dot 圆心位置 
 * @param {Number} radius 圆的半径 
 * @param {Object} option  {xkp: 1, ykp: 1, sAngle: 0,  eAngle: Math.PI * 2, counterclockwise: true}
 */
const drawArc = (ctx, dot, radius, option) => { 
    const ctxConfig = copyCtxConf(ctx);
    const defaultConfig = {xkp: 1, ykp: 1, sAngle: 0,  eAngle: Math.PI * 2, counterclockwise: true};
    let reactConfig = Object.assign(ctxConfig, defaultConfig, option),
    { fillStyle, xkp, ykp, sAngle, eAngle, counterclockwise  } = reactConfig,
    copyArr = kpArr(dot, xkp, ykp);
    if (radius <= 0) {
        radius = 5
    }
    // 外侧大圆
    ctx.beginPath();
    ctx.fillStyle = fillStyle;
    ctx.arc(copyArr[0], copyArr[1], radius, sAngle, eAngle, counterclockwise);
    ctx.fill();
    ctx.closePath();
}

export { drawArc };