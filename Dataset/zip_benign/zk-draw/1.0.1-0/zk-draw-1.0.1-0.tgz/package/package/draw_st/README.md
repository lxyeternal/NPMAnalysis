### 这里是对于ST的处理


#### ST分为ST表格 ST曲线图 ST课堂分布三部分


- 1. ST表格
```javasctipt
ST表格表示每一个采样间隔(30s)内 ST的指向
每分钟为一列的表格数据

``` 

- 2. ST曲线图

```javascript
ST曲线图为在以ST为X,Y轴的二维空间中 ST的分布曲线
````


- 3.ST课堂分布
```javascript 
按照S T的占比以及ch(S T)的转化率类规定课堂的类型归属
````