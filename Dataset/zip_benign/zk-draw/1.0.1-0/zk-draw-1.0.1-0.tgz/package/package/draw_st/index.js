/*
* @Author: wangfpp
* @Date:   2020-05-02 20:42:44
 * @Last Modified by: wangfpp
 * @Last Modified time: 2020-06-05 17:38:30
*/
import { splitArr } from '../../comm/comm.js';
import titles from './titles.json';
// import { drawStLine } from './draw_st_line/draw_st_line.js';
// import { createTable } from './draw_st_table/draw_st_table.js';
// import { drawRtCh } from './draw_rtch/draw_rtch.js';


/**
 * @description 对原始分析结果的数据处理函数
 * @param  {Array} result [AI原始数据]
 * @param  {Number} Smax   [每个合并数据中有几个S才合并为S]
 * @param {Object} [titles2] [行为归属]
 * @return {Object}        [description]
 */
const handleData = (result, Smax, titles2) => {
	let recGap = 6, // 分析间隔
	len = result.length,
	timeLength = (result[len - 1] && result[len - 1][0] && result[len - 1][0][0]) ? Math.ceil(result[len - 1][0][0] / recGap) : 0;
	if (!timeLength) {
		return null;
	} 
	titles2 = titles2 || titles;
	// 遍历原始数据 取出时间戳 行为分类 以及行为归属
	let timeData = result.map(item => {
		let time = parseInt(item[0][0]),
		catlog = item[2][1],
		actionClassify = actionClassifyFn(catlog, titles2);
		return {time, catlog, actionClassify};
	});

	// 对数据根据分析间隔来分类 装进每一个分析间隔中的array中
	let perMergeData = [],
	_index = 0;
	while (_index < timeLength) {
		let empytArr = [];
		timeData.forEach((item, index) => {
			let { time, actionClassify } = item,
			timeStart = (_index * recGap),
			timeEnd = ((_index + 1) * recGap);
			if (time >= timeStart && time < timeEnd) {
				empytArr.push(actionClassify);
			}
		});
		// 每6s合并进一个数据 如果全为S归为S 否则归为T
		if (empytArr.length && empytArr.every(isEveryS)) {
			perMergeData[_index] = 'S';
		} else {
			perMergeData[_index] = 'T';		
		}
		_index++;
	}
	// [s, t, t, t, s, s, s, t] => [[s,t,t,t,s], [s,s,t]....]
	// 按每5个一组分割数组 5个一组 每次分析6s 则每一组为30s的数据
	let splitAfterArr = splitArr(5, perMergeData);

	// 以下开始进行ST数据合并处理
	let mergedData = splitAfterArr.map(item => {
		let scount = 0;
		item.forEach(catlog => {
			if (catlog === 'S') {
				scount ++;
			}
		})
		if (scount >= Smax) {
			item = 'S';
		} else {
			item = 'T';
		}
		return item;
	})

	// 计算ST的结果数据
	let processData = cal_st(mergedData);
	return {
		permerge: perMergeData, // 未合并的数据
		mergeData: mergedData, //合并后的数据
		rtch: processData // ST结果

	}
}



/**
 * 计算S T的数量以及行为转化率和课堂类型
 * @param  {Array} data  [S T待计算数据]
 * @return {Object}  {}
 */
const cal_st = data =>{
    let s = 0,t = 0,Rt = 0, Rs = 0, Ch = 0, catlogCount = 0, type = '';
    let curr = data[0];
    for (let i = 0; i < data.length; i++) {
        if (data[i] == 'T') {
            t++;
        } else if (data[i] == 'S') {
            s++;
        }
        if (curr !== data[i]) {
            curr = data[i];
            Ch++;
        }
    }
    catlogCount = (s + t);
    Rt = (t / catlogCount).toFixed(2);
    Rs = (s / catlogCount).toFixed(2);
    Ch = (Ch / catlogCount).toFixed(2);
    type = cal_type(Rt,Ch);
    return {s, t, rt: Rt, rs: Rs, ch: Ch, type};
}

/**
 * 按照ST规则得出课堂类型
 * @param  {Number} Rt [RT占比]
 * @param  {Number} Ch [Ch占比]
 * @return {String}  返回课堂类型
 */
const cal_type = (Rt,Ch) =>{
   let type = ""
    if (Rt <= 0.3) {
        type = '练习型'
    } else if (Rt >= 0.7) {
        type = '讲授型'
    }
    if (Ch >= 0.4) {
        type = '对话型'
    }
    if ((Rt > 0.3 && Rt < 0.7) && Ch < 0.4) {
        type = '混合型'
    }
    return type
}

/**
 * 判断数组中的每个元素是否是S
 * @param  {String} actionClassify 
 * @return {Boolean}           
 */
const isEveryS = actionClassify => {
	return actionClassify === 'S';
}

/**
 * 行为归属为教师还是学生
 * @param  {String} catlog [行为的catlog]
 * @param  {Object} titles [分析机的titles2]
 * @return {String}     返回行为归属
 */
const actionClassifyFn = (catlog, titles) => {
	let { student, teacher } = titles;
	if (student.includes(catlog)) {
		return 'S';
	} else {
		return 'T';
	}
}

// let data = handleData(orinalData, 3, titles);
// let { mergeData, permerge, rtch } = data;
// let node = document.querySelector('#root'),
// rtchNode = document.querySelector('#rtch'),
// tableNode = document.querySelector('#table');
// drawStLine(node, null, '#000', false, [{data: permerge, title: '教授A', scolor: '', tcolor: '', lineWidth: 3},{data: mergeData, title: '教授b', scolor: '', tcolor: '', lineWidth: 3}]);
// createTable(tableNode, mergeData, 15);
// drawRtCh(rtchNode, null, '#f00', "", "", [{...rtch}]);

export { handleData };












