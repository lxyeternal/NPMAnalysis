/*
* @Author: wangfpp
* @Date:   2020-05-03 21:20:22
 * @Last Modified by: wangfpp
 * @Last Modified time: 2020-07-06 18:32:49
*/

import { splitArr, deepFlatten, getNodeById } from '../../../comm/comm.js';

/**
 * @description 创建ST表格
 * @param  {Dom node} parentNode  要插入的节点
 * @param  {Array} tabledata  合并后的数据
 * @param {Number} doubleNum  大于多少分钟就分割数组
 */
const drawStTable = (parentNode, tabledata, doubleNum = 25,extraClass=null) => {
	console.log(new Date().getTime())
	let table = document.createElement('table'),
	splitData = splitArr(2, tabledata),
	tableHtml = "";
	table.setAttribute('name', 'zqqd_st_table');
	table.setAttribute('class', extraClass);
	if (splitData.length > doubleNum) {
		splitData = splitArr(2, splitData);
		table.setAttribute('border', 1);
		table.setAttribute('cellpadding', 0)
		table.setAttribute('cellspacing', 0)
		tableHtml = `<tr><th></th><th>30s</th><th>60s</th><th>&nbsp;&nbsp</th><th>30s</th><th>60s</th></tr>`;
		
		for(var i = 0; i < splitData.length; i++) {
			tableHtml += `<tr><td style="text-align: center">${i * 2 + 1}分钟</td>`;
			let item = splitData[i];
			let flatArr = deepFlatten(item);
			for(var j = 0; j < flatArr.length; j++) {
				j === 1 ? tableHtml += `<td style="text-align: center">${flatArr[j]}</td><td style="text-align: center">${i * 2 + 2}分钟</td>` : tableHtml += `<td style="text-align: center">${flatArr[j]}</td>`
			}
			tableHtml += '</tr>'
		}
	} else {
		table.setAttribute('border', 1);
		table.setAttribute('cellpadding', 0);
		table.setAttribute('cellspacing', 0);
		tableHtml = `<tr><th></th><th>30s</th><th>60s</th></tr>`;
		for(var i = 0; i < splitData.length; i++) {
			tableHtml += `<tr><td style="text-align: center">${i + 1}分钟</td>`;
			let item = splitData[i];
			for(var j = 0; j < item.length; j++) {
				tableHtml += `<td style="text-align: center">${item[j]}</td>`
			}
			tableHtml += '</tr>'
		}
	}
	table.innerHTML = tableHtml;
	let trueNode = getNodeById(parentNode);
	let stTableConeten = trueNode.querySelector('table[name="zqqd_st_table"]'); // table无法通过id获取
	if (stTableConeten) {
		trueNode.removeChild(stTableConeten);
	}
	trueNode.appendChild(table);
	console.log(stTableConeten)
}


export { drawStTable };