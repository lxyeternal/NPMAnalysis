const  path = require('path');

module.exports = {
    mode: 'none',
    entry: './index.js',
    output: {
        filename: 'canvas_tool.js',
        libraryTarget: 'umd',
        umdNamedDefine: true,
        libraryExport: 'default'
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                loader: 'babel',
                exclude: /(node_modules|dist|)/,
                query: {
                    
                }
            }
        ]
    }
}