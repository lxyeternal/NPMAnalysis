import type { TRgba, THsva } from '@fantasy-color/types';
declare const _default: (color: TRgba) => THsva;
export default _default;
