var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _normalizeRgba2 = _interopRequireDefault(require("@fantasy-color/normalize-rgba"));

var _default = function _default(color) {
  var _normalizeRgba = (0, _normalizeRgba2.default)(color),
      red = _normalizeRgba.red,
      green = _normalizeRgba.green,
      blue = _normalizeRgba.blue,
      alpha = _normalizeRgba.alpha;

  var min = Math.min(Math.min(red, green), blue);
  var max = Math.max(Math.max(red, green), blue);
  var delta = max - min;
  var value = Math.round(max * 100);

  if (delta === 0) {
    return {
      hue: 0,
      saturation: 0,
      value: value,
      alpha: alpha
    };
  }

  var hue;

  if (max === red) {
    hue = 60 * ((green - blue) / (max - min)) % 360;
  } else if (max === green) {
    hue = 60 * ((blue - red) / (max - min)) + 120;
  } else {
    hue = 60 * ((red - green) / (max - min)) + 240;
  }

  if (hue < 0) {
    hue += 360;
  }

  var saturation = 1 - min / max;
  return {
    hue: Math.round(hue),
    saturation: Math.round(saturation * 100),
    value: value,
    alpha: alpha
  };
};

exports.default = _default;
//# sourceMappingURL=index.js.map