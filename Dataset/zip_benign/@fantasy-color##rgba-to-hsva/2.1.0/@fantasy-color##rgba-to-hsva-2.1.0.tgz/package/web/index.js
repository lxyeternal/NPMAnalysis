// eslint-disable-next-line import/no-unresolved
import normalizeRgba from '@fantasy-color/normalize-rgba';
export default (function (color) {
  var _normalizeRgba = normalizeRgba(color),
      red = _normalizeRgba.red,
      green = _normalizeRgba.green,
      blue = _normalizeRgba.blue,
      alpha = _normalizeRgba.alpha;

  var min = Math.min(Math.min(red, green), blue);
  var max = Math.max(Math.max(red, green), blue);
  var delta = max - min;
  var value = Math.round(max * 100); // If grey shade

  if (delta === 0) {
    return {
      hue: 0,
      saturation: 0,
      value: value,
      alpha: alpha
    };
  } // Hue


  var hue;

  if (max === red) {
    hue = 60 * ((green - blue) / (max - min)) % 360;
  } else if (max === green) {
    hue = 60 * ((blue - red) / (max - min)) + 120;
  } else {
    hue = 60 * ((red - green) / (max - min)) + 240;
  }

  if (hue < 0) {
    hue += 360;
  } // Saturation


  var saturation = 1 - min / max;
  return {
    hue: Math.round(hue),
    saturation: Math.round(saturation * 100),
    value: value,
    alpha: alpha
  };
});
//# sourceMappingURL=index.js.map