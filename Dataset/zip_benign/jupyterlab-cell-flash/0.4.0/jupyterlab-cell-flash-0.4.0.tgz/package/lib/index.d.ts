import { JupyterFrontEndPlugin } from '@jupyterlab/application';
/**
 * Initialization data for the jupyterlab-cell-flash extension.
 */
declare const extension: JupyterFrontEndPlugin<void>;
export default extension;
