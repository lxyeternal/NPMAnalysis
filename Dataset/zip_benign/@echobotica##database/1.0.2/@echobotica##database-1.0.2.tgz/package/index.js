/**
 * Export lib/database
 *
 */

'use strict';

const database = require('./lib/');

module.exports = database;
module.exports.default = database;
module.exports.database = database;

// Re-export for ESM support
module.exports.cast = database.cast;
module.exports.STATES = database.STATES;
module.exports.setDriver = database.setDriver;
module.exports.set = database.set;
module.exports.get = database.get;
module.exports.createConnection = database.createConnection;
module.exports.connect = database.connect;
module.exports.disconnect = database.disconnect;
module.exports.startSession = database.startSession;
module.exports.pluralize = database.pluralize;
module.exports.model = database.model;
module.exports.deleteModel = database.deleteModel;
module.exports.modelNames = database.modelNames;
module.exports.plugin = database.plugin;
module.exports.connections = database.connections;
module.exports.version = database.version;
module.exports.Database = database.Database;
module.exports.Schema = database.Schema;
module.exports.SchemaType = database.SchemaType;
module.exports.SchemaTypes = database.SchemaTypes;
module.exports.VirtualType = database.VirtualType;
module.exports.Types = database.Types;
module.exports.Query = database.Query;
module.exports.Model = database.Model;
module.exports.Document = database.Document;
module.exports.ObjectId = database.ObjectId;
module.exports.isValidObjectId = database.isValidObjectId;
module.exports.isObjectIdOrHexString = database.isObjectIdOrHexString;
module.exports.syncIndexes = database.syncIndexes;
module.exports.Decimal128 = database.Decimal128;
module.exports.Mixed = database.Mixed;
module.exports.Date = database.Date;
module.exports.Number = database.Number;
module.exports.Error = database.Error;
module.exports.now = database.now;
module.exports.CastError = database.CastError;
module.exports.SchemaTypeOptions = database.SchemaTypeOptions;
module.exports.mongo = database.mongo;
module.exports.mquery = database.mquery;
module.exports.sanitizeFilter = database.sanitizeFilter;
module.exports.trusted = database.trusted;
module.exports.skipMiddlewareFunction = database.skipMiddlewareFunction;
module.exports.overwriteMiddlewareResult = database.overwriteMiddlewareResult;

// The following properties are not exported using ESM because `setDriver()` can mutate these
// module.exports.connection = database.connection;
// module.exports.Collection = database.Collection;
// module.exports.Connection = database.Connection;
