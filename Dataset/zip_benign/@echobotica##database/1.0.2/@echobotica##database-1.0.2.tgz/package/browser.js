/**
 * Export lib/database
 *
 */

'use strict';

module.exports = require('./lib/browser');
