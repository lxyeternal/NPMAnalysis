declare class NativeError extends global.Error { }

declare module 'database' {
  import mongodb = require('mongodb');

  type CastError = Error.CastError;
  type SyncIndexesError = Error.SyncIndexesError;

  class DatabaseError extends global.Error {
    constructor(msg: string);

    /** The type of error. "DatabaseError" for generic errors. */
    name: string;

    static messages: any;

    static Messages: any;
  }

  class Error extends DatabaseError { }

  namespace Error {

    export class CastError extends DatabaseError {
      name: 'CastError';
      stringValue: string;
      kind: string;
      value: any;
      path: string;
      reason?: NativeError | null;
      model?: any;

      constructor(type: string, value: any, path: string, reason?: NativeError, schemaType?: SchemaType);
    }
    export class SyncIndexesError extends DatabaseError {
      name: 'SyncIndexesError';
      errors?: Record<string, mongodb.MongoServerError>;

      constructor(type: string, value: any, path: string, reason?: NativeError, schemaType?: SchemaType);
    }

    export class DivergentArrayError extends DatabaseError {
      name: 'DivergentArrayError';
    }

    export class MissingSchemaError extends DatabaseError {
      name: 'MissingSchemaError';
    }

    export class DocumentNotFoundError extends DatabaseError {
      name: 'DocumentNotFoundError';
      result: any;
      numAffected: number;
      filter: any;
      query: any;
    }

    export class ObjectExpectedError extends DatabaseError {
      name: 'ObjectExpectedError';
      path: string;
    }

    export class ObjectParameterError extends DatabaseError {
      name: 'ObjectParameterError';
    }

    export class OverwriteModelError extends DatabaseError {
      name: 'OverwriteModelError';
    }

    export class ParallelSaveError extends DatabaseError {
      name: 'ParallelSaveError';
    }

    export class ParallelValidateError extends DatabaseError {
      name: 'ParallelValidateError';
    }

    export class DatabaseServerSelectionError extends DatabaseError {
      name: 'DatabaseServerSelectionError';
    }

    export class StrictModeError extends DatabaseError {
      name: 'StrictModeError';
      isImmutableError: boolean;
      path: string;
    }

    export class ValidationError extends DatabaseError {
      name: 'ValidationError';

      errors: { [path: string]: ValidatorError | CastError };
      addError: (path: string, error: ValidatorError | CastError) => void;

      constructor(instance?: DatabaseError);
    }

    export class ValidatorError extends DatabaseError {
      name: 'ValidatorError';
      properties: {
        message: string,
        type?: string,
        path?: string,
        value?: any,
        reason?: any
      };
      kind: string;
      path: string;
      value: any;
      reason?: DatabaseError | null;

      constructor(properties: {
        message?: string,
        type?: string,
        path?: string,
        value?: any,
        reason?: any
      });
    }

    export class VersionError extends DatabaseError {
      name: 'VersionError';
      version: number;
      modifiedPaths: Array<string>;

      constructor(doc: Document, currentVersion: number, modifiedPaths: Array<string>);
    }

    export class StrictPopulateError extends DatabaseError {
      name: 'StrictPopulateError';
      path: string;
    }
  }
}
