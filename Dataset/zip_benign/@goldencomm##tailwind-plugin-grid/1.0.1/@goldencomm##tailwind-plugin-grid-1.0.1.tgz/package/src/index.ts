import plugin from "tailwindcss/plugin";
import defaultTheme from "tailwindcss/defaultTheme";

export default plugin(
  ({ matchUtilities, theme }) => {
    matchUtilities(
      {
        "auto-fill": (value) => ({
          gridTemplateColumns: `repeat(auto-fill, minmax(min(${value}, 100%), 1fr))`,
        }),
      },
      {
        values: {
          ...theme("spacing"),
          ...theme("autoFill"),
        },
      }
    );

    matchUtilities(
      {
        "auto-fit": (value) => ({
          gridTemplateColumns: `repeat(auto-fit, minmax(min(${value}, 100%), 1fr))`,
        }),
      },
      {
        values: {
          ...theme("spacing"),
          ...theme("autoFit"),
        },
      }
    );
  },
  {
    theme: {
      autoFill: {},
      autoFit: {},
    },
  }
);
