# @goldencomm/tailwind-plugin-grid

## 1.0.1

### Patch Changes

- README corrections/updates.

## 1.0.0

### Major Changes

- Release v1
