
## 1.0.5 [06-09-2023]

* Updates package.json

See merge request itentialopensource/pre-built-automations/automation-gateway-copy-files-from-git!21

---

## 1.0.4 [05-26-2023]

* Merging pre-release/2023.1 into master to run cypress tests

See merge request itentialopensource/pre-built-automations/automation-gateway-copy-files-from-git!16

---

## 1.0.3 [04-13-2023]

* Update manifestTester to have updated logic and better error messages

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!12

---

## 1.0.2 [04-13-2023]

* Updating cypress to use NPM module instead of git submodules

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!11

---

## 1.0.1 [03-30-2023]

* Test

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!7

---
\n## 1.0.0 [03-17-2023]\n\n* Major/full release

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!6\n\n---\n\n\n## 0.0.20 [03-16-2023]\n\n* patch/2023-03-15T12-00-47

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!5\n\n---\n\n\n## 0.0.19 [03-15-2023]\n\n* patch/2023-03-14T14-54-09

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!4\n\n---\n\n\n## 0.0.18 [03-15-2023]\n\n* patch/2023-03-14T14-54-09

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!4\n\n---\n\n\n## 0.0.17 [03-02-2023]\n\n* Bug fixes and performance improvements

See commit 36f5520n\n\n---\n\n\n## 0.0.16 [03-02-2023]\n\n* Readme updates and Dependency Updates

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!2\n\n---\n\n\n## 0.0.15 [03-02-2023]\n\n* Readme updates and Dependency Updates

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!2\n\n---\n\n\n## 0.0.14 [03-01-2023]\n\n* Readme updates and Dependency Updates

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!2\n\n---\n\n\n## 0.0.13 [03-01-2023]\n\n* Readme updates and Dependency Updates

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!2\n\n---\n\n\n## 0.0.12 [03-01-2023]\n\n* Readme updates and Dependency Updates

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!2\n\n---\n\n\n## 0.0.10 [03-01-2023]\n\n* Readme updates and Dependency Updates

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!2\n\n---\n\n\n## 0.0.10 [03-01-2023]\n\n* Readme updates and Dependency Updates

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!2\n\n---\n\n\n## 0.0.9 [03-01-2023]\n\n* Readme updates and Dependency Updates

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!2\n\n---\n\n\n## 0.0.7 [03-01-2023]\n\n* Readme updates and Dependency Updates

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!2\n\n---\n\n\n## 0.0.6 [03-01-2023]\n\n* Readme updates and Dependency Updates

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!2\n\n---\n\n\n## 0.0.5 [03-01-2023]\n\n* Readme updates and Dependency Updates

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!2\n\n---\n\n\n## 0.0.4 [03-01-2023]\n\n* Readme updates and Dependency Updates

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!2\n\n---\n\n\n## 0.0.3 [03-01-2023]\n\n* Readme updates and Dependency Updates

See merge request itentialopensource/pre-built-automations/staging/automation-gateway-copy-files-from-git!2\n\n---\n\n
## 0.0.2 [02-27-2023]

* Bug fixes and performance improvements

See commit 8a1ec2f

---

## 0.0.7 [04-21-2022]

* Bug fixes and performance improvements

See commit 3983a14

---

## 0.0.6 [10-15-2020]

* updated the template to replace the word Artifact

See merge request itentialopensource/pre-built-automations/artifact-template-2020.1!3

---

## 0.0.5 [08-03-2020]

* Fixed repository.url in Package.json

See merge request itentialopensource/pre-built-automations/artifact-template-2020.1!2

---

## 0.0.4 [07-17-2020]

* [patch/LB-404] Update readme template to follow standard

See merge request itentialopensource/pre-built-automations/artifact-template-2020.1!1

---

## 0.0.3 [07-07-2020]

* [patch/LB-404] Update readme template to follow standard

See merge request itentialopensource/pre-built-automations/artifact-template-2020.1!1

---

## 0.0.2 [06-19-2020]

* [patch/LB-404] Update readme template to follow standard

See merge request itentialopensource/pre-built-automations/artifact-template-2020.1!1

---\n\n\n\n\n
