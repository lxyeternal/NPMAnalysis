/// <reference types="react" />
import { GetClaimInvoiceDetailData } from '@mojito-inc/core-service';
import * as React from 'react';
import { Theme } from '@mui/material/styles';

interface TokenGatingNoClaimContainerProps {
    title?: string;
    primaryButtonTitle?: string;
    secondaryButtonTitle?: string;
    tertiaryButtonTitle?: string;
    onClickTertiaryButton?: () => void;
    onClickSecondaryButton?: () => void;
    onClickPrimaryButton?: () => void;
}

interface TokenGatingLoadingContainerProps {
    loaderTitle?: string;
    loaderSubtitle?: string;
}

interface TokenGatingErrorContainerProps {
    title?: string;
    subTitle?: string;
    errorMessage?: string;
    buttonName?: string;
    apiErrorMessage?: string;
    onClickButton?: () => void;
}

type TokenGatingClaimContainerTokenDetail = {
    tokenImage?: string;
    tokenName?: string;
    tokenSubtitle?: string;
    tokenButtonText?: string;
};
interface ImageProps {
    logo: string;
    metamask?: string;
    walletConnect?: string;
    phantom?: string;
    backPack?: string;
    error?: string;
}
interface WalletOptionsProps {
    enableMetamask?: boolean;
    enableWalletConnect?: boolean;
    enableEmail?: boolean;
    enableMagic?: boolean;
    enablePhantom?: boolean;
    enableBackPack?: boolean;
}
interface ContentData {
    title?: string;
    description?: string;
}
interface ContentProps {
    walletOptionsContentData?: ContentData;
    otpContentData?: ContentData;
    emailContentData?: ContentData;
    loadingContentData?: ContentData;
    recoverCodeContentData?: {
        description?: string;
    };
}
interface WalletConfiguration {
    orgId: string;
    groupId?: string;
    ruleId?: string;
    isClaimToken?: boolean;
    collectionItemId?: string;
    invoiceId?: string;
}
interface SupportedNetworksData {
    chainID: number;
    id: string;
    isTestnet: boolean;
    name: string;
}
interface BalanceData {
    native: number;
    nonNative: number;
}
interface WalletDetailsData {
    walletAddress: string;
    networkDetails: SupportedNetworksData;
    providerType: string;
    balance: BalanceData;
    provider: any;
}
interface NetworkData {
    id: string;
    name: string;
    chainID: number;
    isTestnet: boolean;
}
interface ConnectWalletProps {
    open: boolean;
    isWeb2Login?: boolean;
    isDisConnect: boolean;
    config: {
        organizationId: string;
        paperClientId?: string;
        paperNetworkName?: 'Ethereum' | 'Sepolia' | 'Goerli' | 'Polygon' | 'Mumbai';
        solanaWebAppBaseURL?: string;
    };
    walletOptions: WalletOptionsProps;
    image: ImageProps;
    content?: ContentProps;
    isRefetchBalance?: boolean;
    skipSignature?: boolean;
    isPaperWallet?: boolean;
    userEmail?: string;
    customErrorMessage?: {
        externalWalletConnection?: {
            highRiskMessage?: string;
            wrongWalletMessage?: string;
            defaultMessage?: string;
        };
    };
    skipExternalWalletCheck?: boolean;
    getSupportedNetworkData?: (data: NetworkData[]) => void;
    onCloseModal: (event?: boolean) => void;
}
interface WalletImages {
    metamask?: string;
    walletConnect?: string;
    logo?: string;
    error?: string;
    phantom?: string;
    backPack?: string;
}
interface TokenGatingWalletScreenProps {
    title?: string;
    subTitle?: string;
    walletOptions: WalletOptionsProps;
    image: WalletImages;
}
interface ScreenConfig {
    title?: string;
    subTitle?: string;
}
interface GatedToken {
    tokenId: number;
    contractAddress: string;
}
interface TokenGatingContainerProps {
    open: boolean;
    walletConnectScreenDetails: TokenGatingWalletScreenProps;
    config: WalletConfiguration;
    errorScreenDetails: TokenGatingNoClaimContainerProps & {
        redirectionPageURL?: string;
    };
    screenConfig: ScreenConfig;
    claimTokenScreenDetails: {
        tokenDetail?: TokenGatingClaimContainerTokenDetail;
        redirectionPageURL?: string;
        onSuccess?: (data?: GatedToken[]) => void;
    };
    gatingLoaderDetails?: TokenGatingLoadingContainerProps;
    gatingErrorDetails?: TokenGatingErrorContainerProps;
    invoiceID?: string;
    onCloseModal: (event?: boolean) => void;
    onChangeWalletAddress?: (walletDetails: WalletDetailsData) => void;
    setInvoice?: (id: string) => void;
    getInvoiceDetails?: (data?: GetClaimInvoiceDetailData) => void;
}
interface MetaData {
    name: string;
    description: string;
    url: string;
    icons: string[];
}

declare const ConnectWalletContainer: ({ open, isWeb2Login, walletOptions, config, isDisConnect, image, content, isRefetchBalance, skipSignature, isPaperWallet, userEmail, customErrorMessage, skipExternalWalletCheck, onCloseModal, getSupportedNetworkData, }: ConnectWalletProps) => React.JSX.Element;

type SolanaWalletType = 'devnet' | 'testnet' | 'mainnet-beta';

interface ApolloClientOptions {
    uri?: string;
    token?: string;
}
type ChainName = 'ethereum' | 'polygon' | 'goerli' | 'mumbai' | 'sepolia' | 'base-sepolia-testnet' | 'base';
type WalletType = 'ethereum' | 'solana';
interface WalletThemeProviderProps {
    children: JSX.Element | JSX.Element[];
    theme: Theme;
    clientOptions: ApolloClientOptions;
    walletConnectProjectId?: string;
    activeChain?: ChainName;
    clientId?: string;
    metaData?: MetaData;
    walletType?: WalletType;
    solanaWalletEnv?: SolanaWalletType;
    customRPCUrl?: string;
    magicProjectId?: string;
    onAuthenticated: (token: string) => void;
}
declare const ConnectWalletProvider: ({ children, theme, clientOptions, metaData, walletType, magicProjectId, solanaWalletEnv, walletConnectProjectId, activeChain, clientId, customRPCUrl, onAuthenticated, }: WalletThemeProviderProps) => React.JSX.Element;

declare const TokenGatingContainer: ({ open, config, screenConfig, walletConnectScreenDetails, errorScreenDetails, claimTokenScreenDetails, gatingErrorDetails, gatingLoaderDetails, invoiceID, onCloseModal, setInvoice, getInvoiceDetails, }: TokenGatingContainerProps) => React.JSX.Element;

interface NetworkDetailsProps {
    chainID: number;
    id: string;
    isTestnet: boolean;
    name: string;
}

declare function useNetwork(): NetworkDetailsProps;

interface WalletProviderProps {
    provider: any;
    providerType: string;
}

declare function useProvider(): WalletProviderProps;

interface WalletDetailsProps {
    address: string;
    balance: {
        native: number;
        nonNative: number;
    };
    walletType: WalletType;
}
type WalletConnectionStatus = 'connect' | 'connecting' | 'connected';
type WalletDisconnectStatus = 'disconnect' | 'disconnecting' | 'disconnected';
type BalanceRefetchStatus = 'refetch' | 'refetching' | 'refetched';

declare function useWallet(): WalletDetailsProps;

interface WalletStatusProp {
    connectStatus: WalletConnectionStatus;
    disconnectStatus: WalletDisconnectStatus;
    refetchBalanceStatus: BalanceRefetchStatus;
}
declare function useWalletStatus(): WalletStatusProp;

export { ConnectWalletContainer, ConnectWalletProvider, NetworkData, TokenGatingContainer, useNetwork, useProvider, useWallet, useWalletStatus };
