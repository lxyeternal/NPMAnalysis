export declare const walletConnectMetadata: {
    name: string;
    description: string;
    url: string;
    icons: string[];
};
export declare const supportedNetworksData: {
    chainId: number;
    name: string;
    currency: string;
    explorerUrl: string;
    rpcUrl: string;
}[];
