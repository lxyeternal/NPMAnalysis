export declare const RPC_URL: {
    1: string;
    5: string;
    80001: string;
    137: string;
};
export declare const emailRegex: RegExp;
export declare enum ErrorsType {
    RECOVERY_CODE = "Invalid recovery",
    HIGH_RISK = "high risk wallet",
    WRONG_WALLET = "wallet does not belong to the user"
}
export declare enum WalletProviderType {
    METAMASK = "Metamask",
    WALLET_CONNECT = "WalletConnect",
    EMAIL = "Email",
    MAGIC = "Magic",
    PHANTOM = "Phantom",
    BACKPACK = "Backpack"
}
