import { type ConnectWalletLayoutProps, type TokenGatingLayoutProps } from '../interface/index';
import ConnectWalletContainerLayout from './ConnectWalletLayout';
import TokenGatingLayout from './TokenGatingLayout';
export { ConnectWalletContainerLayout as ConnectWalletLayout, type ConnectWalletLayoutProps, TokenGatingLayout, type TokenGatingLayoutProps, };
