import * as React from 'react';
import { TokenGatingLayoutProps } from '../interface';
declare const TokenGatingLayout: ({ currentModalState, error, otp, loaderTitle, email, open, walletScreenDetails, walletScreenActions, tokenClaimDetails, errorScreenDetails, recoveryCode, gatingLoaderDetails, gatingErrorDetails, screenConfig, errorMessage, handleRetry, onChangeEmail, onChangeOTP, onClickVerifyOTP, onClickContinueWithEmail, onCloseModal, onSuccess, onChangeRecoveryCode, onClickRecoveryCode, }: TokenGatingLayoutProps) => React.JSX.Element;
export default TokenGatingLayout;
