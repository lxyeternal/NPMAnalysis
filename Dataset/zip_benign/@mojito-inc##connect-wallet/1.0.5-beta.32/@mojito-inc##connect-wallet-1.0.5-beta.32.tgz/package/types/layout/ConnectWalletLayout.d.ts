import * as React from 'react';
import { ConnectWalletLayoutProps } from '../interface';
declare const ConnectWalletContainerLayout: ({ open, error, email, otp, walletOptions, image, currentModalState, loaderTitle, content, recoveryCode, loaderDescription, skipErrorTitle, onChangeEmail, onChangeOTP, onChangeRecoveryCode, onClickVerifyOTP, onClickContinueWithEmail, onClickEmail, handleRetry, onClickMetamask, onClickWalletConnect, onClickRecoveryCode, onCloseModal, onClickBackPackWallet, onClickPhantomWallet, handleChangeMobile, }: ConnectWalletLayoutProps) => React.JSX.Element;
export default ConnectWalletContainerLayout;
