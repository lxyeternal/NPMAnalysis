import * as React from 'react';
import { ConnectWalletActionProps, TokenGatingWalletScreenProps } from '../interface';
export type TokenGatingConnectWalletContainerProps = ConnectWalletActionProps & TokenGatingWalletScreenProps;
declare const TokenGatingConnectWalletContainer: ({ title, subTitle, walletOptions, image, onClickMetamask, onClickEmail, onClickBackPackWallet, onClickPhantomWallet, onClickWalletConnect, onSubmitMobile, }: TokenGatingConnectWalletContainerProps) => React.JSX.Element;
export default TokenGatingConnectWalletContainer;
