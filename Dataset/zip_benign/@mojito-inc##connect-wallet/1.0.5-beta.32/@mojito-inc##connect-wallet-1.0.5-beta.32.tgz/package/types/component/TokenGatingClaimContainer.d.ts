import * as React from 'react';
import { TokenGatingClaimContainerTokenDetail } from '../interface';
export interface TokenGatingClaimContainerProps {
    tokenDetail?: TokenGatingClaimContainerTokenDetail;
    onSuccess?: () => void;
}
declare const TokenGatingClaimContainer: ({ tokenDetail, onSuccess, }: TokenGatingClaimContainerProps) => React.JSX.Element;
export default TokenGatingClaimContainer;
