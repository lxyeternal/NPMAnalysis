import * as React from 'react';
import { WalletImages, WalletOptionsProps } from '../interface';
export interface WalletListContainerProps {
    walletOptions: WalletOptionsProps;
    image: WalletImages;
    isMobile: boolean;
    onClickMetamask?: () => void;
    onClickWalletConnect?: () => void;
    onClickEmail?: () => void;
    onClickPhantomWallet?: () => void;
    onClickBackPackWallet?: () => void;
    onSubmitMobile?: (countryCode: string, _mobileNumber: number) => void;
}
declare const WalletListContainer: ({ walletOptions, image, isMobile, onClickMetamask, onClickWalletConnect, onClickEmail, onClickBackPackWallet, onClickPhantomWallet, onSubmitMobile, }: WalletListContainerProps) => React.JSX.Element;
export default WalletListContainer;
