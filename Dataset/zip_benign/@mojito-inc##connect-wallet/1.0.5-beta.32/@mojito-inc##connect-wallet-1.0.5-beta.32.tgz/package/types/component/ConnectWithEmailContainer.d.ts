import * as React from 'react';
import { ContentData } from '../interface';
export interface ConnectWithEmailContainerProps {
    email: string;
    error?: string;
    logoUrl?: string;
    content?: ContentData;
    onChangeEmail: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onClickContinueWithEmail: () => void;
}
declare const ConnectWithEmailContainer: ({ email, error, logoUrl, content, onChangeEmail, onClickContinueWithEmail, }: ConnectWithEmailContainerProps) => React.JSX.Element;
export default ConnectWithEmailContainer;
