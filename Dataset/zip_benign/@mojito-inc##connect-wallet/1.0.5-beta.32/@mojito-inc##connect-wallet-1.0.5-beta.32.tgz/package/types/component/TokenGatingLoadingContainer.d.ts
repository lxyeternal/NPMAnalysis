import * as React from 'react';
export interface TokenGatingLoadingContainerProps {
    loaderTitle?: string;
    loaderSubtitle?: string;
}
declare const TokenGatingLoadingContainer: ({ loaderTitle, loaderSubtitle, }: TokenGatingLoadingContainerProps) => React.JSX.Element;
export default TokenGatingLoadingContainer;
