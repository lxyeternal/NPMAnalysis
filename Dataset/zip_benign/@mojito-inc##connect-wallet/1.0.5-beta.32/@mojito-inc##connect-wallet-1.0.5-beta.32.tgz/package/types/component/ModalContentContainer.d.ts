import * as React from 'react';
export interface ModalContentContainerProps {
    image?: string;
    title: string;
    subTitle?: string;
    description?: string;
}
declare const ModalContentContainer: ({ image, title, subTitle, description, }: ModalContentContainerProps) => React.JSX.Element;
export default ModalContentContainer;
