import * as React from 'react';
import { ContentData } from '../interface';
export interface OTPContainerProps {
    email: string;
    otp: string;
    error?: string;
    logo?: string;
    content?: ContentData;
    onClickRequestNewCode: () => void;
    onClickVerifyOTP: () => void;
    onChangeOTP: (event: string) => void;
}
declare const OTPContainer: ({ email, otp, error, logo, content, onChangeOTP, onClickVerifyOTP, onClickRequestNewCode, }: OTPContainerProps) => React.JSX.Element;
export default OTPContainer;
