import * as React from 'react';
import { ContentData, WalletOptionsProps } from '../interface';
export interface ExistingWalletProps {
    walletOptions: WalletOptionsProps;
    image: {
        logo: string;
        metamask?: string;
        walletConnect?: string;
        phantom?: string;
        backPack?: string;
    };
    content?: ContentData;
    isMobile: boolean;
    onClickEmail: () => void;
    onClickMetamask: () => void;
    onClickWalletConnect: () => void;
    onClickPhantomWallet: () => void;
    onClickBackPackWallet: () => void;
    onSubmitMobile: (countryCode: string, _mobileNumber: number) => void;
}
declare const ExistingWalletContainer: ({ walletOptions, image, content, isMobile, onClickEmail, onClickMetamask, onClickWalletConnect, onClickPhantomWallet, onClickBackPackWallet, onSubmitMobile, }: ExistingWalletProps) => React.JSX.Element;
export default ExistingWalletContainer;
