import * as React from 'react';
export interface TokenGatingErrorContainerProps {
    title?: string;
    subTitle?: string;
    errorMessage?: string;
    buttonName?: string;
    apiErrorMessage?: string;
    onClickButton?: () => void;
}
declare const TokenGatingErrorContainer: ({ title, subTitle, errorMessage, apiErrorMessage, buttonName, onClickButton, }: TokenGatingErrorContainerProps) => React.JSX.Element;
export default TokenGatingErrorContainer;
