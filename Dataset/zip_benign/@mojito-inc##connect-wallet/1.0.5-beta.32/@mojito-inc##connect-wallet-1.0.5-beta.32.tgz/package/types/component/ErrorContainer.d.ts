import * as React from 'react';
export interface ErrorContainerProps {
    errorMessage: string;
    errorImage?: string;
    skipErrorTitle?: boolean;
    handleRetry: () => void;
    onCloseModal: () => void;
}
declare const ErrorContainer: ({ errorMessage, errorImage, skipErrorTitle, handleRetry, onCloseModal }: ErrorContainerProps) => React.JSX.Element;
export default ErrorContainer;
