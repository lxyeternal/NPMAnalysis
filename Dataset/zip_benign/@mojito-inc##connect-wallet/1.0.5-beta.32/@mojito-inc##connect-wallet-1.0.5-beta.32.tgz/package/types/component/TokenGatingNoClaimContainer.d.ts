import * as React from 'react';
export interface TokenGatingNoClaimContainerProps {
    title?: string;
    primaryButtonTitle?: string;
    secondaryButtonTitle?: string;
    tertiaryButtonTitle?: string;
    onClickTertiaryButton?: () => void;
    onClickSecondaryButton?: () => void;
    onClickPrimaryButton?: () => void;
}
declare const TokenGatingNoClaimContainer: ({ title, primaryButtonTitle, secondaryButtonTitle, tertiaryButtonTitle, onClickPrimaryButton, onClickSecondaryButton, onClickTertiaryButton, }: TokenGatingNoClaimContainerProps) => React.JSX.Element;
export default TokenGatingNoClaimContainer;
