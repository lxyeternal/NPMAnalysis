import React from 'react';
interface MobileNumberSignInProps {
    onSubmitMobile?: (countryCode: string, _mobileNumber: number) => void;
}
declare const MobileNumberSignIn: ({ onSubmitMobile }: MobileNumberSignInProps) => React.JSX.Element;
export default MobileNumberSignIn;
