import { WalletProviderProps } from '../provider/WalletProvider';
declare function useProvider(): WalletProviderProps;
export default useProvider;
