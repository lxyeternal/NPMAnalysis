declare const useSolanaWalletsMethod: (providerType: string) => {
    solanaWallets: import("@solana/wallet-adapter-react").Wallet[];
    solanaWalletSelect: (walletName: import("@solana/wallet-adapter-base").WalletName<string> | null) => void;
    connectedSolanaAddress: any;
    disconnectSolanaWallet: () => Promise<void>;
    solanaSignMessage: any;
    solanaWalletConnected: boolean;
    solanaWallet: import("@solana/wallet-adapter-react").Wallet | null;
    solanaWalletConnect: () => Promise<void>;
} | {
    thirdWebWallet: undefined;
    connect: undefined;
    activeAccount: undefined;
    thirdWebDisconnect: undefined;
    connectedThirdWebWallet: undefined;
    thirdWebConnectedChain: undefined;
    connectionStatus: undefined;
    solanaWallets: undefined;
    solanaWalletConnect: undefined;
    connectedSolanaAddress: undefined;
    disconnectSolanaWallet: undefined;
    solanaSignMessage: undefined;
    solanaWalletConnected: undefined;
    solanaWallet: undefined;
    solanaWalletSelect: undefined;
};
export default useSolanaWalletsMethod;
