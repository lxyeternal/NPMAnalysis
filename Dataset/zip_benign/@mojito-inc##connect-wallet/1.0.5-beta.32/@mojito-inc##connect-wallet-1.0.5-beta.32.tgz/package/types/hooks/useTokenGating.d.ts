import { CheckTokenGatingData, CheckTokenGatingParams, RedeemEarnableItemData, GetClaimInvoiceDetailData } from '@mojito-inc/core-service';
interface useTokenGatingParams {
    data: CheckTokenGatingParams;
}
export interface GatingParams {
    ruleId: string;
    contractAddress: string;
    tokenId: string;
    ownerWallet: string;
}
export declare const useTokenGating: ({ data }: useTokenGatingParams) => {
    gatedTokens: CheckTokenGatingData | null | undefined;
    redeemItem: RedeemEarnableItemData | null | undefined;
    invoiceDetails: GetClaimInvoiceDetailData | null | undefined;
    loading: {
        gatingLoading: boolean;
        redeemEarnableLoading: boolean;
        invoiceLoading: boolean;
    };
    error: boolean;
    errorMessage: {
        gatingMessage: string;
        redeemEarnableMessage: string;
        invoiceMessage: string;
    };
    handleReCheckTokenGating: () => void;
    redeemEarnableToken: (claimableItemId: string, destAddr?: string, gating?: GatingParams) => Promise<RedeemEarnableItemData | null | undefined>;
    getClaimInvoiceDetails: (invoiceID: string) => Promise<GetClaimInvoiceDetailData | null | undefined>;
};
export {};
