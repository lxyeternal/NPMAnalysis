import { BalanceRefetchStatus, WalletConnectionStatus, WalletDisconnectStatus } from '../provider/ConnectedWalletDetailsProvider';
interface WalletStatusProp {
    connectStatus: WalletConnectionStatus;
    disconnectStatus: WalletDisconnectStatus;
    refetchBalanceStatus: BalanceRefetchStatus;
}
declare function useWalletStatus(): WalletStatusProp;
export default useWalletStatus;
