import { SolanaExtension } from '@magic-ext/solana';
export declare const useMagic: () => {
    magic: import("@magic-sdk/provider").InstanceWithExtensions<import("@magic-sdk/provider").SDKBase, SolanaExtension[]> | null;
};
