declare const useEthWalletsMethod: () => {
    thirdWebWallet: import("thirdweb/wallets").Wallet<"inApp">;
    connect: (walletOrFn: import("thirdweb/wallets").Wallet<import("thirdweb/wallets").WalletId> | (() => Promise<import("thirdweb/wallets").Wallet<import("thirdweb/wallets").WalletId>>)) => Promise<import("thirdweb/wallets").Wallet<import("thirdweb/wallets").WalletId> | null>;
    activeAccount: import("thirdweb/wallets").Account | undefined;
    thirdWebDisconnect: (wallet: import("thirdweb/wallets").Wallet<import("thirdweb/wallets").WalletId>) => void;
    connectedThirdWebWallet: import("thirdweb/wallets").Wallet<import("thirdweb/wallets").WalletId> | undefined;
    thirdWebConnectedChain: Readonly<import("thirdweb/chains").ChainOptions & {
        rpc: string;
    }> | undefined;
    connectionStatus: import("thirdweb/wallets").ConnectionStatus;
} | {
    thirdWebWallet: undefined;
    connect: undefined;
    activeAccount: undefined;
    thirdWebDisconnect: undefined;
    connectedThirdWebWallet: undefined;
    thirdWebConnectedChain: undefined;
    connectionStatus: undefined;
};
export default useEthWalletsMethod;
