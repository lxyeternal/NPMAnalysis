import { NetworkDetailsProps } from '../provider/NetworkProvider';
declare function useNetwork(): NetworkDetailsProps;
export default useNetwork;
