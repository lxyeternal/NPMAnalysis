import { WalletDetailsProps } from '../provider/ConnectedWalletDetailsProvider';
declare function useWallet(): WalletDetailsProps;
export default useWallet;
