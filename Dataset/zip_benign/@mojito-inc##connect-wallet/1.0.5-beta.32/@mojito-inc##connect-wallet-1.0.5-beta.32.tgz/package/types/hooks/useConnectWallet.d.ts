import { NetworkData } from '../interface';
interface Configuration {
    orgId: string;
    isTokenGating?: boolean;
    setSupportedNetworksData?: (data: NetworkData[]) => void;
}
interface ApiResponse {
    status: boolean;
    message: string;
}
interface ConnectWalletParam {
    getSignature: (walletAddress: string, networkId: string) => Promise<ApiResponse | undefined>;
    loginWithWallet: (signatureMessage: string, signer: string, signature: string, chainId: number) => Promise<ApiResponse | undefined>;
    isTokenGating: boolean;
}
declare const useWalletConnect: ({ orgId, isTokenGating, setSupportedNetworksData, }: Configuration) => ConnectWalletParam;
export default useWalletConnect;
