import * as React from 'react';
import { Theme } from '@mui/material/styles';
import { MetaData } from '../interface';
import { SolanaWalletType } from '../interface/solanaConfig';
export interface ApolloClientOptions {
    uri?: string;
    token?: string;
}
export type ChainName = 'ethereum' | 'polygon' | 'goerli' | 'mumbai' | 'sepolia' | 'base-sepolia-testnet' | 'base';
export type WalletType = 'ethereum' | 'solana';
interface WalletThemeProviderProps {
    children: JSX.Element | JSX.Element[];
    theme: Theme;
    clientOptions: ApolloClientOptions;
    walletConnectProjectId?: string;
    activeChain?: ChainName;
    clientId?: string;
    metaData?: MetaData;
    walletType?: WalletType;
    solanaWalletEnv?: SolanaWalletType;
    customRPCUrl?: string;
    magicProjectId?: string;
    onAuthenticated: (token: string) => void;
}
declare const ConnectWalletProvider: ({ children, theme, clientOptions, metaData, walletType, magicProjectId, solanaWalletEnv, walletConnectProjectId, activeChain, clientId, customRPCUrl, onAuthenticated, }: WalletThemeProviderProps) => React.JSX.Element;
export default ConnectWalletProvider;
