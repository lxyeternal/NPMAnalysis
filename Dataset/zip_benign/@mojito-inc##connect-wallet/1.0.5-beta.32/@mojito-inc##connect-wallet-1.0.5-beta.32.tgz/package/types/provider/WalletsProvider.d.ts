import * as React from 'react';
import { ReactNode } from 'react';
import { ChainName, WalletType } from './ConnectWalletProvider';
import { MetaData } from '../interface';
import { SolanaWalletType } from '../interface/solanaConfig';
interface WalletsProviderProps {
    clientId?: string;
    walletConnectProjectId?: string;
    activeChain?: ChainName;
    metaData?: MetaData;
    walletType?: WalletType;
    solanaWalletEnv?: SolanaWalletType;
    magicProjectId?: string;
    customRPCUrl?: string;
    children: ReactNode;
}
declare const WalletsProvider: ({ children, activeChain, clientId, magicProjectId, metaData, solanaWalletEnv, walletConnectProjectId, walletType, customRPCUrl, }: WalletsProviderProps) => React.JSX.Element;
export default WalletsProvider;
