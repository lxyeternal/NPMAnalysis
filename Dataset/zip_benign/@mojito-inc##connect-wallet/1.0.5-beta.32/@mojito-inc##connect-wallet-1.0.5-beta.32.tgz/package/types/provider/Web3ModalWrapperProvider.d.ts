import * as React from 'react';
import { MetaData } from '../interface';
export interface Web3ModalContextType {
    web3Provider: any;
}
export declare const useWeb3ModalWrapper: () => any;
interface Web3ModalProviderProps {
    projectId?: string;
    metaData?: MetaData;
    children: React.ReactNode;
}
export declare const Web3ModalProvider: ({ children, projectId, metaData }: Web3ModalProviderProps) => React.JSX.Element;
export {};
