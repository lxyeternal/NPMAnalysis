import * as React from 'react';
export interface NetworkDetailsProps {
    chainID: number;
    id: string;
    isTestnet: boolean;
    name: string;
}
export interface NetworkContextType {
    networkDetails: NetworkDetailsProps;
    setNetworkDetails(f: NetworkDetailsProps | ((prev: NetworkDetailsProps) => NetworkDetailsProps)): void;
}
export declare const useNetworkDetails: () => NetworkContextType;
export declare const NetworkProvider: ({ children }: {
    children: React.ReactNode;
}) => React.JSX.Element;
