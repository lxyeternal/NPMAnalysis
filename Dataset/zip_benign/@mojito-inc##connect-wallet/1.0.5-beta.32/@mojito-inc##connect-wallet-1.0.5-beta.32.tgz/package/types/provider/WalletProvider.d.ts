import * as React from 'react';
export interface WalletProviderProps {
    provider: any;
    providerType: string;
}
export interface WalletProviderContextType {
    walletProvider: WalletProviderProps;
    setWalletProvider(f: WalletProviderProps | ((prev: WalletProviderProps) => WalletProviderProps)): void;
}
export declare const useWalletProvider: () => WalletProviderContextType;
export declare const WalletProvider: ({ children }: {
    children: React.ReactNode;
}) => React.JSX.Element;
