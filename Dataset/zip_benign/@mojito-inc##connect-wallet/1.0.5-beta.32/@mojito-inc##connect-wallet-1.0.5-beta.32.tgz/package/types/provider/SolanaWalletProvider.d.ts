import { SolanaWalletType } from '../interface/solanaConfig';
declare const SolanaWalletProvider: ({ children, env, customRPCUrl }: {
    children: any;
    env?: SolanaWalletType | undefined;
    customRPCUrl?: string | undefined;
}) => any;
export default SolanaWalletProvider;
