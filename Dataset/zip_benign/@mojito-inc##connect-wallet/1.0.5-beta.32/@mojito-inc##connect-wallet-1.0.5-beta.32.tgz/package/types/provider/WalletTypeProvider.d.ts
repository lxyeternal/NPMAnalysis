import * as React from 'react';
import { ReactNode } from 'react';
import { WalletType } from './ConnectWalletProvider';
interface WalletTypeContextProp {
    walletType?: WalletType;
}
interface WalletTypeProviderProp {
    children: ReactNode;
    walletType: WalletType;
}
export declare const useWalletType: () => WalletTypeContextProp;
export declare const WalletTypeProvider: ({ children, walletType }: WalletTypeProviderProp) => React.JSX.Element;
export {};
