import * as React from 'react';
import { SolanaWalletType } from '../interface/solanaConfig';
interface MagicWalletContextProp {
    magicWalletId?: string;
    env?: SolanaWalletType;
    customRPCUrl?: string;
}
interface MagicWalletProviderProp {
    children: any;
    magicWalletId?: string;
    env?: SolanaWalletType;
    customRPCUrl?: string;
}
export declare const useMagicConfig: () => MagicWalletContextProp;
declare const MagicWalletProvider: ({ children, env, magicWalletId, customRPCUrl }: MagicWalletProviderProp) => React.JSX.Element;
export default MagicWalletProvider;
