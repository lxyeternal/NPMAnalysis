import * as React from 'react';
import { ChainName } from './ConnectWalletProvider';
export interface ThirdWebClientContext {
    clientId: string;
    chainId: number;
}
export declare const useThirdWebClient: () => ThirdWebClientContext;
interface ThirdWebClientProviderProps {
    projectId?: string;
    children: React.ReactNode;
    activeChain?: ChainName;
}
export declare const ThirdWebClientProvider: ({ children, projectId, activeChain }: ThirdWebClientProviderProps) => React.JSX.Element;
export {};
