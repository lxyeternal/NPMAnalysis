import * as React from 'react';
import { WalletType } from './ConnectWalletProvider';
export interface WalletDetailsProps {
    address: string;
    balance: {
        native: number;
        nonNative: number;
    };
    walletType: WalletType;
}
export type WalletConnectionStatus = 'connect' | 'connecting' | 'connected';
export type WalletDisconnectStatus = 'disconnect' | 'disconnecting' | 'disconnected';
export type BalanceRefetchStatus = 'refetch' | 'refetching' | 'refetched';
export interface WalletDetailsContextType {
    walletDetails: WalletDetailsProps;
    connectStatus: WalletConnectionStatus;
    disconnectStatus: WalletDisconnectStatus;
    refetchBalanceStatus: BalanceRefetchStatus;
    setConnectStatus(f: WalletConnectionStatus | ((prev: WalletConnectionStatus) => WalletConnectionStatus)): void;
    setDisconnectStatus(f: WalletDisconnectStatus | ((prev: WalletDisconnectStatus) => WalletDisconnectStatus)): void;
    setRefetchingBalanceStatus(f: BalanceRefetchStatus | ((prev: BalanceRefetchStatus) => BalanceRefetchStatus)): void;
    setWalletDetails(f: WalletDetailsProps | ((prev: WalletDetailsProps) => WalletDetailsProps)): void;
}
export declare const useWalletDetails: () => WalletDetailsContextType;
export declare const WalletDetailsProvider: ({ children }: {
    children: React.ReactNode;
}) => React.JSX.Element;
