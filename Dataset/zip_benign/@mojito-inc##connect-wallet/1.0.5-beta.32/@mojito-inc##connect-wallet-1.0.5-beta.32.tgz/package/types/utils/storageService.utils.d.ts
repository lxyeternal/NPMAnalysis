declare class SecureStorage {
    key: string;
    constructor(key: string);
    setValue: (value: any) => void;
    getValue: () => any;
    clear: () => void;
}
export declare const StorageService: {
    networkDetails: SecureStorage;
    walletDetails: SecureStorage;
    authToken: SecureStorage;
    authTokenType: SecureStorage;
};
export {};
