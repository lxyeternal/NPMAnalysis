export declare function getCurrencyAddress(chainId: number): string;
