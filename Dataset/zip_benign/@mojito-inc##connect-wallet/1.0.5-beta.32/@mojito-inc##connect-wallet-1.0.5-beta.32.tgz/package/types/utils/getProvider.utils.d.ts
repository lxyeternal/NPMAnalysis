export declare const getProvider: (providerType: string, embeddedWalletSigner: any, walletProvider: any) => Promise<any>;
