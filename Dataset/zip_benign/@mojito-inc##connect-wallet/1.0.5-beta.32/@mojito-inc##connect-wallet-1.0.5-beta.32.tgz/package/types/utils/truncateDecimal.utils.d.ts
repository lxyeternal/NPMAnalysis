export declare const truncateDecimal: (price?: string | number, index?: number, removeEmptyDot?: boolean) => string;
