import { SolanaWalletType } from '../interface/solanaConfig';
import { ChainName } from '../provider/ConnectWalletProvider';
export declare const getChainId: (name: string) => number;
export declare const getActiveChainId: (chainName: ChainName) => 137 | 80001 | 1 | 5 | 11155111 | 84532 | 8453;
export declare const getSolanaChainId: (chain?: SolanaWalletType, customRPCUrl?: string) => 901 | 900 | 902;
