import { ethers } from 'ethers';
import { SolanaWalletType } from '../interface/solanaConfig';
interface BalanceData {
    native: number;
    nonNative: number;
}
export declare function getNonNativeCurrencyBalancePaper(provider: ethers.providers.Web3Provider | any, currencyContractAddress: string, currency: string): Promise<number>;
export declare function getNonNativeCurrencyBalance(provider: ethers.providers.Web3Provider | any, currencyContractAddress: string, currency: string): Promise<number>;
export declare const getBalance: (provider: ethers.providers.Web3Provider | any, walletAddress: string, chainId: number, providerType: string) => Promise<BalanceData>;
export declare const getSolanaBalance: (address: string, network?: SolanaWalletType, customRPCUrl?: string) => Promise<{
    native: number;
    nonNative: any;
}>;
export {};
