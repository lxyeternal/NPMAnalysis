/// <reference types="react" />
import { GetClaimInvoiceDetailData } from '@mojito-inc/core-service';
import { TokenGatingErrorContainerProps, TokenGatingLoadingContainerProps, TokenGatingNoClaimContainerProps } from '../component';
export declare enum ModalType {
    CONNECT_WALLET = "CONNECT_WALLET",
    LOADING = "LOADING",
    OTP = "OTP",
    ERROR = "ERROR",
    EMAIL = "EMAIL",
    RECOVERY_CODE = "RECOVERY_CODE",
    CLAIM_DISCOUNT = "CLAIM_DISCOUNT",
    NO_CLAIM = "NO_CLAIM",
    GATING_LOADING = "GATING_LOADING",
    GATING_ERROR = "GATING_ERROR"
}
export type TokenGatingClaimContainerTokenDetail = {
    tokenImage?: string;
    tokenName?: string;
    tokenSubtitle?: string;
    tokenButtonText?: string;
};
export interface ImageProps {
    logo: string;
    metamask?: string;
    walletConnect?: string;
    phantom?: string;
    backPack?: string;
    error?: string;
}
export interface WalletOptionsProps {
    enableMetamask?: boolean;
    enableWalletConnect?: boolean;
    enableEmail?: boolean;
    enableMagic?: boolean;
    enablePhantom?: boolean;
    enableBackPack?: boolean;
}
export interface ContentData {
    title?: string;
    description?: string;
}
export interface ContentProps {
    walletOptionsContentData?: ContentData;
    otpContentData?: ContentData;
    emailContentData?: ContentData;
    loadingContentData?: ContentData;
    recoverCodeContentData?: {
        description?: string;
    };
}
export interface ConnectWalletLayoutProps {
    open: boolean;
    error: string;
    email: string;
    otp: string;
    recoveryCode: string;
    image: ImageProps;
    currentModalState: ModalType;
    loaderTitle: string;
    walletOptions: WalletOptionsProps;
    content?: ContentProps;
    loaderDescription?: string;
    skipErrorTitle?: boolean;
    onChangeEmail: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onChangeOTP: (event: string) => void;
    onChangeRecoveryCode: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onClickContinueWithEmail: () => void;
    onClickEmail: () => void;
    handleRetry: () => void;
    onClickVerifyOTP: () => void;
    onClickMetamask: () => void;
    onClickWalletConnect: () => void;
    onClickRecoveryCode: () => void;
    onCloseModal: () => void;
    onClickPhantomWallet: () => void;
    onClickBackPackWallet: () => void;
    handleChangeMobile: (countryCode: string, _mobileNumber: number) => void;
}
interface WalletConfiguration {
    orgId: string;
    groupId?: string;
    ruleId?: string;
    isClaimToken?: boolean;
    collectionItemId?: string;
    invoiceId?: string;
}
export interface SupportedNetworksData {
    chainID: number;
    id: string;
    isTestnet: boolean;
    name: string;
}
export interface BalanceData {
    native: number;
    nonNative: number;
}
export interface WalletDetailsData {
    walletAddress: string;
    networkDetails: SupportedNetworksData;
    providerType: string;
    balance: BalanceData;
    provider: any;
}
export interface AppMetaData {
    appName: string;
    appDescription: string;
    appURL: string;
    logo: string;
}
export interface NetworkData {
    id: string;
    name: string;
    chainID: number;
    isTestnet: boolean;
}
export interface MobileNumberProp {
    number?: number;
    countryCode?: string;
}
export interface ConnectWalletProps {
    open: boolean;
    isWeb2Login?: boolean;
    isDisConnect: boolean;
    config: {
        organizationId: string;
        paperClientId?: string;
        paperNetworkName?: 'Ethereum' | 'Sepolia' | 'Goerli' | 'Polygon' | 'Mumbai';
        solanaWebAppBaseURL?: string;
    };
    walletOptions: WalletOptionsProps;
    image: ImageProps;
    content?: ContentProps;
    isRefetchBalance?: boolean;
    skipSignature?: boolean;
    isPaperWallet?: boolean;
    userEmail?: string;
    customErrorMessage?: {
        externalWalletConnection?: {
            highRiskMessage?: string;
            wrongWalletMessage?: string;
            defaultMessage?: string;
        };
    };
    skipExternalWalletCheck?: boolean;
    getSupportedNetworkData?: (data: NetworkData[]) => void;
    onCloseModal: (event?: boolean) => void;
}
export interface ConnectWalletActionProps {
    onClickMetamask?: () => void;
    onClickWalletConnect?: () => void;
    onClickEmail?: () => void;
    onClickPhantomWallet?: () => void;
    onClickBackPackWallet?: () => void;
    onSubmitMobile?: (countryCode: string, _mobileNumber: number) => void;
}
export interface WalletImages {
    metamask?: string;
    walletConnect?: string;
    logo?: string;
    error?: string;
    phantom?: string;
    backPack?: string;
}
export interface TokenGatingWalletScreenProps {
    title?: string;
    subTitle?: string;
    walletOptions: WalletOptionsProps;
    image: WalletImages;
}
export interface ScreenConfig {
    title?: string;
    subTitle?: string;
}
export interface TokenGatingLayoutProps {
    currentModalState: ModalType;
    loaderTitle: string;
    error: string;
    email: string;
    otp: string;
    open: boolean;
    recoveryCode: string;
    walletScreenDetails: TokenGatingWalletScreenProps;
    walletScreenActions: ConnectWalletActionProps;
    errorScreenDetails: TokenGatingNoClaimContainerProps;
    screenConfig?: ScreenConfig;
    tokenClaimDetails?: TokenGatingClaimContainerTokenDetail;
    gatingLoaderDetails?: TokenGatingLoadingContainerProps;
    gatingErrorDetails?: TokenGatingErrorContainerProps;
    errorMessage?: string;
    onChangeOTP: (event: string) => void;
    onChangeEmail: (event: React.ChangeEvent<HTMLInputElement>) => void;
    onChangeRecoveryCode: (event: React.ChangeEvent<HTMLInputElement>) => void;
    handleRetry: () => void;
    onClickVerifyOTP: () => void;
    onClickContinueWithEmail: () => void;
    onCloseModal: () => void;
    onSuccess: () => void;
    onClickRecoveryCode: () => void;
}
interface GatedToken {
    tokenId: number;
    contractAddress: string;
}
export interface TokenGatingContainerProps {
    open: boolean;
    walletConnectScreenDetails: TokenGatingWalletScreenProps;
    config: WalletConfiguration;
    errorScreenDetails: TokenGatingNoClaimContainerProps & {
        redirectionPageURL?: string;
    };
    screenConfig: ScreenConfig;
    claimTokenScreenDetails: {
        tokenDetail?: TokenGatingClaimContainerTokenDetail;
        redirectionPageURL?: string;
        onSuccess?: (data?: GatedToken[]) => void;
    };
    gatingLoaderDetails?: TokenGatingLoadingContainerProps;
    gatingErrorDetails?: TokenGatingErrorContainerProps;
    invoiceID?: string;
    onCloseModal: (event?: boolean) => void;
    onChangeWalletAddress?: (walletDetails: WalletDetailsData) => void;
    setInvoice?: (id: string) => void;
    getInvoiceDetails?: (data?: GetClaimInvoiceDetailData) => void;
}
export interface MetaData {
    name: string;
    description: string;
    url: string;
    icons: string[];
}
export {};
