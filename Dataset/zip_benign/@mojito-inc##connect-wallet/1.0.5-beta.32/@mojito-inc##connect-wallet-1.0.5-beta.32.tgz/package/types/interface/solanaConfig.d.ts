export type SolanaWalletType = 'devnet' | 'testnet' | 'mainnet-beta';
