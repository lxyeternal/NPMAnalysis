import * as React from 'react';
import { ConnectWalletProps } from '../interface';
declare const ConnectWalletContainer: ({ open, isWeb2Login, walletOptions, config, isDisConnect, image, content, isRefetchBalance, skipSignature, isPaperWallet, userEmail, customErrorMessage, skipExternalWalletCheck, onCloseModal, getSupportedNetworkData, }: ConnectWalletProps) => React.JSX.Element;
export default ConnectWalletContainer;
