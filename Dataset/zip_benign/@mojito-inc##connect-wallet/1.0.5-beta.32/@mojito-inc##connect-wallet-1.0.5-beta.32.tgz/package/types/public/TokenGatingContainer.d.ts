import * as React from 'react';
import { TokenGatingContainerProps } from '../interface';
declare const TokenGatingContainer: ({ open, config, screenConfig, walletConnectScreenDetails, errorScreenDetails, claimTokenScreenDetails, gatingErrorDetails, gatingLoaderDetails, invoiceID, onCloseModal, setInvoice, getInvoiceDetails, }: TokenGatingContainerProps) => React.JSX.Element;
export default TokenGatingContainer;
