## `dhc-tool`

#### `js工具代码`

##### 使用方式：

1. 使用方式一：通过 npm 导入使用

```
import utils from 'dhc-tool';

utils.trim("......");
utils.format("2022-12-18 12:00:00")
```

1. 使用方式二：通过编译后在浏览器中使用。链接地址：

   ```

   ```

##### 集成有：

###### 校验类：

- `isNull：是否是一个null`
- `isUndefined：是否是一个undefined`
- `isString：是否是一个字符串`
- isNumber：是否是一个数字
- `isArray：是否是一个数组`
- `isObject：是否是一个对象`
- `isPromise：是否是一个promise`
- `isPhoneNumber：是否是一个手机号`
- `isEmail：是否是一个邮箱`
- `isAndroid：是否是安卓设备`
- `isiOS：是否是ios设备`
- `isWeixin：是否是微信浏览器`

###### 工具类：

- `trim`：去除首尾空字符
- `concatString：`字符串拼接
- `debounce`：防抖
- `throttle`：节流
- `Log`：日志收集
- `Interval`：倒计时

  ```
  const interval = new dhcTool.Interval(function(){
      // 倒计时每次触发执行函数
  }, 1000)

  // 清除倒计时
  interval.$clear()
  ```

- `Online`：网络状态监控

  ```
  const NW = new dhcTool.Online({
      //正常网络
      online: ()=>{ ... },
      //弱网
      lowline: ()=>{ ... },
      //断网
      offline: ()=>{ ... }
  })
  // 设置弱网判断阀值，默认400
  NW.defaults.rtt = 100;
  ```

- `loadScript`：脚本读取

  ```
  // 回调写法
  dhcTool.loadScript(url, function(){
  	// 加载成功
  }, function(){
  	// 加载失败
  })

  // promise写法
  dhcTool.loadScript(url).then(function(){
  	// 加载成功
  }).catch(function(){
  	// 加载失败
  })
  ```

- `loadCss`：样式读取

  ```
  // 回调写法
  dhcTool.loadCss(url, function(){
  	// 加载成功
  }, function(){
  	// 加载失败
  })

  // promise写法
  dhcTool.loadCss(url).then(function(){
  	// 加载成功
  }).catch(function(){
  	// 加载失败
  })
  ```

###### 时间日期：

- `format：`时间日期转换

  ```
  dhcTool.format('2022-12-01', 'YYYY-MM-DD hh:mm:ss'); // 2022-12-01 00:00:00

  dhcTool.format('2022/12/01 13:33:00', 'YY-MM-DD hh:mm:ss') // 22-12-01 13:33:00

  dhcTool.format(1670061437001, 'YYYY/MM/DD hh:mm:ss') // 2022/12/03 17:57:17
  ```

- `getDate`：转换为 *分钟前、*天前、\*月前

  ```
  dhcTool.getDate(1670061437001) // 20分钟前

  // 可传入服务器当前时间（1670063374674），更精确！！！跨时区时建议使用
  dhcTool.getDate(1670061437001, 1670063374674) // 32分钟前
  ```

###### 存储类：

- `cookie：cookie操作`
- `storage：storage操作，不需要处理转换数据类型，存入什么，取出来就是什么！！！`

  ```
  // 设置 localstroage
  dhcTool.stroage.set(key, value)
  // 读取 localstroage
  dhcTool.stroage.get(key)

  // 设置 sessionstroage
  dhcTool.stroage.set(key, value, true)
  // 读取 sessionstroage
  dhcTool.stroage.get(key, true)
  ```

###### 计算类：

- `toFixed：`四舍五入

  ```
  dhcTool.toFixed('44.5678', 2) //保留2位小数
  dhcTool.toFixed(44.555, 2) //保留2位小数
  ```

- `math：`四则运算对象（add 加法、subtract 减法、multiply 乘法、divide 除法）

  ```
  dhcTool.math.add(0.1, 0.2) // 0.3
  dhcTool.math.add(0.1, '0.2') // 0.3
  ```
