let moduleExport = {
    isNull: function(val){ return val === null },
    isUndefined: function(val){ return val === undefined },
    isString: function(val){ return typeof val === 'string' },
    isArray: function(val){ return Array.isArray(val) },
    isObject: function(val){ return val.toString() === '[object Object]' },
    isPromise: function (val) { return val.toString() === '[object Promise]' },
    //手机号
    isPhoneNumber: function (val) { return /^[1][3-9][0-9]{9}$/.test(val) },
    //邮箱
    isEmail: function (str) { return (new RegExp(/^[a-zA-Z0-9]+[@][a-zA-Z0-9]+[.][a-zA-Z0-9]+$/)).test(str) },
    //安卓
    isAndroid: function () { var u = navigator.userAgent; return u.indexOf('Android') > -1 || u.indexOf('Linux') > -1 },
    //ios
    isiOS: function () { var u = navigator.userAgent; return !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) },
    //微信环境
    isWeixin: function () { var u = navigator.userAgent.toLowerCase(); return u.match(/MicroMessenger/i) === "micromessenger" },
    //去空字符
    trim: function (str) { return str.replace(/(^\s*)|(\s*$)/g, "") },
    
    isNumber: require('./libs/isNumber'),
    concatString: require('./libs/concatString'),
    cookie: require('./libs/cookie'),
    debounce: require('./libs/debounce'),
    throttle: require('./libs/throttle'),
    toFixed: require('./libs/toFixed'),
    stroage: require('./libs/stroage'),
    Online: require('./libs/Online'),
    Log: require('./libs/Log'),
    loadScript: require('./libs/loadScript'),
    loadCss: require('./libs/loadCss'),
    Interval: require('./libs/Interval'),
    getDate: require('./libs/getDate'),
    format: require('./libs/format'),
    deFrozenBody: require('./libs/deFrozenBody'),
    enFrozenBody: require('./libs/enFrozenBody'),
}

const r = require.context("./libs/", true, /.js$/)

r.keys().forEach((key) => {
    console.log(key)
    let arrt = key.substring(key.lastIndexOf("/") + 1, key.lastIndexOf("."))
    moduleExport[arrt] = r(key)
})

module.exports = moduleExport