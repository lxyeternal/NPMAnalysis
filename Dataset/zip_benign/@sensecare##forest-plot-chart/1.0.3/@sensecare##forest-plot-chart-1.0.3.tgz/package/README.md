# 森林图

```js
/**
 * 名称：森林图
 * @param {*} id 当前选中容器
 * @param {*} data 当前数据
 * @param {*} plotConfig 配置项
 **/

 import { initForestPlot } from 'xxx'

 let forestData = {
    plotConfig: {
      effectLabel: 'Hazard Ratio(97%CL)',
      vBar: 1,
      nTicks: 6
    },
    data: [
      {
        description: 'PCSK9 score above median',
        pValue: 0.92,
        effect: { effect: 0.92, low: 0.88, high: 0.95 },
        markerSize: 0.5
      },
      {
        description: '4',
        descriptionOffset: 1,
        pValue: 0.89,
        effect: { effect: 0.89, low: 0.84, high: 0.94 },
        markerSize: 0.5
      },
      {
        description: '3',
        descriptionOffset: 1,
        pValue: 0.93,
        effect: { effect: 0.93, low: 0.88, high: 0.98 },
        markerSize: 0.5
      },
      {
        description: '2',
        descriptionOffset: 1,
        pValue: 0.97,
        effect: { effect: 0.97, low: 0.91, high: 1.03 },
        markerSize: 0.5
      },
      {
        description: 'Something else',
        descriptionOffset: 1,
        pValue: 0.85,
        effect: { effect: 0.85, sd: 0.04 },
        markerSize: 0.5
      },
      {
        description: 'Sd syntax',
        descriptionOffset: 1,
        pValue: 0.85,
        effect: { effect: 0.85, sd: 0.04 },
        markerSize: 0.5
      }
    ]
  }
  initForestPlot({
    data: forestData.data,
    id: '#forest',
    plotConfig: forestData.plotConfig
  })

```
