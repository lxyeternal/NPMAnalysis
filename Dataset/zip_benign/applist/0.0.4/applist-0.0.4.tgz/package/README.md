# node-applist

A library to get list of active processes / applications

## If You Are Submitting Bugs or Issues

Verify that the node version you are using is a _stable_ version; it has an even major release number. Unstable versions are currently not supported and issues created while using an unstable version will be closed.

If you are on a stable version of node, please provide a sufficient code snippet or log files for installation issues. The code snippet does not require you to include confidential information. However, it must provide enough information such that the problem can be replicable. Issues which are closed without resolution often lack required information for replication.

## Version Compatibility

| Node Version   | Support |
| -------------- | -------------- |
| 0.4            | OK             |
| 0.6, 0.8, 0.10 | OK             |
| 0.11           | OK             |
| 4              | OK             |
| 8              | OK             |
| 10, 11         | OK             |
| 12 (nightly)   | OK             |

`node-gyp` only works with stable/released versions of node. Since the `applist` module uses `node-gyp` to build and install, you'll need a stable version of node to use applist. If you do not, you'll likely see an error that starts with:

```
gyp ERR! stack Error: "pre" versions of node cannot be installed, use the --nodedir flag instead
```

## Security Issues And Concerns

> applist uses platform native code to get list of active applications. Current implementation does only return list of process names in unix environment scanning `/proc` and windows platform using `Wtsapi32` api.

As should be the case with any security tool, this library should be scrutinized by anyone using it. If you find or suspect an issue with the code, please bring it to my attention and I'll spend some time trying to make sure that this tool is as secure as possible.

## Dependencies

* NodeJS
* `node-gyp`
 * Please check the dependencies for this tool at: https://github.com/nodejs/node-gyp
  * Windows users will need the options for c++ installed with their visual studio instance.
  * Python 2.x

## Install via NPM

```
npm install applist
```
***Note:*** OS X users using Xcode 4.3.1 or above may need to run the following command in their terminal prior to installing if errors occur regarding xcodebuild: ```sudo xcode-select -switch /Applications/Xcode.app/Contents/Developer```

_Pre-built binaries for various NodeJS versions are made available on a best-effort basis._

Only the current stable and supported LTS releases are actively tested against. Please note that there may be an interval between the release of the module and the availability of the compiled modules.

Currently, we have pre-built binaries that support the following platforms:

1. Windows x32 and x64
2. Linux x64 (GlibC targets only). Pre-built binaries for MUSL targets such as Apline Linux are not available.
3. macOS


If you face an error like this:

```
node-pre-gyp ERR! Tried to download(404): https://github.com/nowakcasimir/node-applist/releases/download/v0.0.1/applist_lib-v0.0.1-node-v60-linux-x64.tar.gz
```

make sure you have the appropriate dependencies installed and configured for your platform.

## Usage

```javascript
const applist = require('applist');
```

### To get list of active processes

#### async (recommended)

```javascript
applist.list(function(err, list) {
    console.log(list)
});
```

#### with promises

applist uses whatever Promise implementation is available in `global.Promise`. NodeJS >= 0.12 has a native Promise implementation built in. However, this should work in any Promises/A+ compliant implementation.

Async methods that accept a callback, return a `Promise` when callback is not specified if Promise support is available.

```javascript
applist.list().then(function(list) {
    console.log(list)
});
```
This is also compatible with `async/await`

```javascript
async function getlist() {
    const list = await applist.list();
    //...
}
```

#### sync

```javascript
var list = applist.listSync()
```

## API

`applist.`

  * `list(cb)`
    * `cb` - [OPTIONAL] - a callback to be fired once the list has been generated. uses eio making it asynchronous. If `cb` is not specified, a `Promise` is returned if Promise support is available.
      * `err` - First parameter to the callback detailing any errors.
      * `list` - Second parameter to the callback providing the active list of process names (strings).
  * `listSync()`

## Testing

If you create a pull request, tests better pass :)

```
npm install
npm test
```

## Credits

The code for this comes from a few sources:

* node.bcrypt.js - for the native node module framework

## License
Unless stated elsewhere, file headers or otherwise, the license as stated in the LICENSE file.