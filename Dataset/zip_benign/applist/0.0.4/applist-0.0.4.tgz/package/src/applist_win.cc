#ifdef _WIN32

#include <windows.h>
#include <Wtsapi32.h>
#include <vector>
#include <string>

#pragma comment(lib, "Wtsapi32.lib")

std::vector<std::string> GetListOfActiveProcesses() {

    std::vector<std::string> result;

    WTS_PROCESS_INFO* pWPIs = NULL;
    DWORD dwProcCount = 0;
    if (WTSEnumerateProcesses(WTS_CURRENT_SERVER_HANDLE, NULL, 1, &pWPIs, &dwProcCount))
    {
        //Go through all processes retrieved
        for(DWORD i = 0; i < dwProcCount; i++)
        {
            //pWPIs[i].pProcessName = process file name only, no path!
            //pWPIs[i].ProcessId = process ID
            //pWPIs[i].SessionId = session ID, if you need to limit it to the logged in user processes
            //pWPIs[i].pUserSid = user SID that started the process
            result.push_back(pWPIs[i].pProcessName);
        }
    }

    //Free memory
    if (pWPIs)
    {
        WTSFreeMemory(pWPIs);
        pWPIs = NULL;
    }

    return result;
}

#endif