#ifndef _NODE_APPLIST_H_
#define _NODE_APPLIST_H_

#include <string>
#include <cstring>
#include <vector>

#ifdef _WIN32
// Windows
std::vector<std::string> GetListOfActiveProcesses();
#elif __APPLE__
// MacOSX
std::vector<std::string> GetListOfActiveProcesses();
#elif __linux__
// Linux
std::vector<std::string> GetListOfActiveProcesses();
#else
#  error "Unknown compiler"
#endif

#endif