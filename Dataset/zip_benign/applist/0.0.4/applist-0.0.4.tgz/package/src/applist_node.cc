#include <nan.h>

#include "applist.h"

#define NODE_LESS_THAN (!(NODE_VERSION_AT_LEAST(0, 5, 4)))

using namespace v8;
using namespace node;

namespace {

char ToCharVersion(Local<String> str) {
  //String::Utf8Value value(str);

  std::string our_str = *Nan::Utf8String(str);

  return our_str[0];
}

class ApplistAsyncWorker : public Nan::AsyncWorker {
public:
    ApplistAsyncWorker(Nan::Callback *callback)
        : Nan::AsyncWorker(callback, "applist:ApplistAsyncWorker") {
    }

    ~ApplistAsyncWorker() {}

    void Execute() {
        this->applist = GetListOfActiveProcesses();
    }

    void HandleOKCallback() {
        Nan::HandleScope scope;

        Local<Value> argv[2];

        Local<Array> apps = Nan::New<v8::Array>(this->applist.size());

        for (int i=0;i<this->applist.size();i++) {
            Nan::Set(apps, i, Nan::New<String>(this->applist[i].c_str()).ToLocalChecked());
        }
        argv[0] = Nan::Undefined();
        argv[1] = apps;
        callback->Call(2, argv, async_resource);
    }

private:
    std::vector<std::string> applist;
};

NAN_METHOD(GetApplist) {
    Nan::HandleScope scope;

    Local<Function> callback = Local<Function>::Cast(info[0]);

    ApplistAsyncWorker* listWorker = new ApplistAsyncWorker(new Nan::Callback(callback));

    Nan::AsyncQueueWorker(listWorker);
}

NAN_METHOD(GetApplistSync) {
    Nan::HandleScope scope;

    std::vector<std::string> applist = GetListOfActiveProcesses();
    Local<Array> apps = Nan::New<v8::Array>(applist.size());

    for (int i=0;i<applist.size();i++) {
        Nan::Set(apps, i, Nan::New<String>(applist[i].c_str()).ToLocalChecked());
    }
    info.GetReturnValue().Set(apps);
}

} // anonymous namespace

NAN_MODULE_INIT(init) {
    Nan::Export(target, "get_applist_sync", GetApplistSync);
    Nan::Export(target, "get_applist", GetApplist);
};

NODE_MODULE(applist_lib, init);
