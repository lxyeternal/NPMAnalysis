{
  'targets': [
    {
      'target_name': 'applist_lib',
      'sources': [
        'src/applist_node.cc',
        'src/applist_win.cc',
        'src/applist_linux.cc',
        'src/applist_mac.cc'
      ],
      'include_dirs' : [
          "<!(node -e \"require('nan')\")"
      ],
      'conditions': [
        [ 'OS=="win"', {
          'defines': [
            'uint=unsigned int',
          ],
        }],
      ],
    },
    {
      "target_name": "action_after_build",
      "type": "none",
      "dependencies": [ "<(module_name)" ],
      "copies": [
        {
          "files": [ "<(PRODUCT_DIR)/<(module_name).node" ],
          "destination": "<(module_path)"
        }
      ]
    }
  ]
}
