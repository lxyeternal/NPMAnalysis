/**
 *
 * @param fn 返回 promise 的函数
 * @param remainRetries 重试次数
 * @param err reject info
 */
function _wrapperPromiseWithRetry(fn, remainRetries = 3, err = null) {
  if (!remainRetries) {
    return Promise.reject(err);
  }
  return fn().catch((err) => {
    return _wrapperPromiseWithRetry(fn, remainRetries - 1, err);
  });
}

/**
 *
 * @param {Array} tasks 返回 promise 函数的数组
 * @param {Object} option maxConcurrent 最大并发，Promise 失败后 Retry 重试次数, debug 是否 debug
 */
function runAll(tasks, option = { maxConcurrent: 3, retry: 1 }) {
  const tasksWithRetry = tasks.map((task) => () => _wrapperPromiseWithRetry(task, option.retry));

  return new Promise((taskResolve, taskReject) => {
    const values = [];
    let isSuccess = true;

    let fulfilledCounts = 0;
    let pos = option.maxConcurrent;

    const maxLen = Math.min(option.maxConcurrent, tasks.length);
    for (let i = 0; i < maxLen; i++) {
      tasksWithRetry[i]()
        .then((value) => {
          _check(value, i);
        })
        .catch((value) => {
          isSuccess = false;
          _check(value, i);
        });
    }

    /**
     *
     * @param value result
     * @param index position
     */
    function _check(value, index) {
      fulfilledCounts++;
      values[index] = value;

      // allSettled
      if (fulfilledCounts === tasks.length) {
        isSuccess === true ? taskResolve(values) : taskReject(values);
        return;
      }

      // no task left
      if (pos >= tasks.length) {
        return;
      }

      // recursion
      const currentPos = pos;
      tasksWithRetry[currentPos]()
        .then((value) => {
          _check(value, currentPos);
        })
        .catch((value) => {
          isSuccess = false;
          _check(value, currentPos);
        });
      pos++;
    }
  });
}

export { runAll };
