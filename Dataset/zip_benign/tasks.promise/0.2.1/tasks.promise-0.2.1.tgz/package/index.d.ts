declare namespace tasks.promise {
  export function runAll(tasks: Array<() => Promise<any>>): Promise<any>;
  export function runAll(
    tasks: Array<() => Promise<any>>,
    option: {
      maxConcurrent: number;
      retry: number;
    }
  ): Promise<any>;
}
export = tasks.promise;
