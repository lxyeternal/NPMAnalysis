# Installation
> `npm install --save-dev @ryancavanaugh/domo`

# Summary
This package contains type definitions for Domo 0.5.

The project URL or description is http://domo-js.com/

# Credits

These definitions were written by Steve Fenton <https://github.com/Steve-Fenton>.

# Details
Typings were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped in the domo directory.

Additional Details
 * Last updated: Tue, 17 May 2016 00:18:10 GMT
 * Typings kind: Global
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: A, ABBR, ACRONYM, ADDRESS, AREA, ARTICLE, ASIDE, AUDIO, B, BDI, BDO, BIG, BLOCKQUOTE, BODY, BR, BUTTON, CANVAS, CAPTION, CITE, CODE, COL, COLGROUP, COMMAND, DATALIST, DD, DEL, DETAILS, DFN, DIV, DL, DT, EM, EMBED, FIELDSET, FIGCAPTION, FIGURE, FOOTER, FORM, FRAME, FRAMESET, H1, H2, H3, H4, H5, H6, HEAD, HEADER, HGROUP, HR, HTML, I, IFRAME, IMG, INPUT, INS, KBD, KEYGEN, LABEL, LEGEND, LI, LINK, MAP, MARK, META, METER, NAV, NOSCRIPT, OBJECT, OL, OPTGROUP, OPTION, OUTPUT, P, PARAM, PRE, PROGRESS, Q, RP, RT, RUBY, SAMP, SCRIPT, SECTION, SELECT, SMALL, SOURCE, SPAN, SPLIT, STRONG, STYLE, SUB, SUMMARY, SUP, TABLE, TBODY, TD, TEXTAREA, TFOOT, TH, THEAD, TIME, TITLE, TR, TRACK, TT, UL, VAR, VIDEO, WBR
