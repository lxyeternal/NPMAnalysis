import { privateGetExternalStore, RouteComponent } from './types';
declare class Component {
    store: Map<string, object>;
    props: any;
    route: RouteComponent;
    __getExternalStore: privateGetExternalStore;
    constructor(props?: any);
    beforeRender(): void;
    afterRender(): void;
    beforeDestroy(): void;
    afterDestroy(): void;
    render(): void;
    setStore(data: any): void;
    getStore(key: string, path?: string): object | undefined | null;
}
export default Component;
