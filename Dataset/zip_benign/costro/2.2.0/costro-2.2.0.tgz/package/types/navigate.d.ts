export default function navigate(to: string): void;
