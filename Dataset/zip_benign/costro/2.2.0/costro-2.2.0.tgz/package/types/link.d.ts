import { Attributes } from './types';
export default function Link({ to, children, ...attrs }: {
    attrs?: Attributes;
    children?: any[] | string;
    to: string;
}, isHtml?: boolean): HTMLElement | string | any;
