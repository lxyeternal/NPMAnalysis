declare function hasOwn(obj: any, key: string): any;
declare function extend(deep?: boolean, ...objects: any[]): any;
declare function getDynamicSegmentsFromPath(path: string): string[];
declare function createRegExpFromPath(path: string): string;
export { extend, hasOwn, getDynamicSegmentsFromPath, createRegExpFromPath };
