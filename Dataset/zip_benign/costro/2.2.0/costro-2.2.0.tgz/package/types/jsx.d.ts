import { ElementAttributes, createElementFunction, Constructable, Component } from './types';
type ChildrenAsArray = string[] | HTMLElement[] | SVGElement[];
declare function Fragment({ children }?: {
    children?: ChildrenAsArray;
}): DocumentFragment;
declare function createElement(tag: string | createElementFunction | Constructable<Component>, attributes: null | ElementAttributes, ...children: string[] | HTMLElement[] | SVGElement[]): DocumentFragment | HTMLElement | SVGElement | string | null;
declare function jsx(tag: string | createElementFunction | Constructable<Component>, { children, ...attributes }: {
    attributes?: null | ElementAttributes;
    children: string[] | HTMLElement[] | SVGElement[];
}): DocumentFragment | HTMLElement | SVGElement | string | null;
export { jsx, createElement, createElement as h, Fragment, Fragment as F };
