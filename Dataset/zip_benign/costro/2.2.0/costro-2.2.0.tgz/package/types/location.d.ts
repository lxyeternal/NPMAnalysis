import { onRouteChangeFunction } from './types';
export default class Location {
    callback: onRouteChangeFunction;
    mode: string;
    basePath: string;
    isHashMode: boolean;
    currentPath: string;
    constructor({ callback, mode, basePath }: {
        basePath: string;
        callback: onRouteChangeFunction;
        mode: string;
    });
    normalizeBasePath(basePath: string): string;
    init(): void;
    addEvents(): void;
    onRouteChange(): void;
    getPath(): string;
    stripBasePath(pathname: string, basePath: string): string;
    setPath(path: string): void;
    destroy(): void;
}
