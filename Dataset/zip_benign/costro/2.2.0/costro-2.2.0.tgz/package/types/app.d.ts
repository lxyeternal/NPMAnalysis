import { RouteData, Route, HelperFunction, Fn, Component } from './types';
export default class App {
    target: HTMLElement;
    mode: string;
    basePath: string;
    silentOnNotFound: boolean;
    routes: Map<string, RouteData>;
    location: any;
    currentRoute: undefined | RouteData;
    previousRoute: undefined | RouteData;
    constructor({ mode, routes, target, basePath, silentOnNotFound }: {
        basePath?: string;
        mode?: 'hash' | 'history';
        routes: Route[];
        silentOnNotFound?: boolean;
        target: HTMLElement;
    });
    createRoutesData(routes: Route[]): Map<string, RouteData>;
    isInterfaceTypeFromComponentGranted(component: Fn | Component): boolean;
    isComponentClass(component: Fn | Component): boolean;
    addEvents(): void;
    onNavigate(e: Event): void;
    onClickOnApp(e: Event): void;
    onRouteChange(currentPath: string): void;
    getRouteMatch(path: string): RouteData | undefined;
    destroyCurrentRoute(): void;
    destroyComponent(): void;
    createComponent(): void;
    initComponentInCache(): void;
    getComponentView(): Promise<any>;
    runRenderWhenReady(currentRoute: RouteData, beforeRenderFn: Promise<unknown>): Promise<any>;
    updateComponentRouteData(): void;
    getInterfaceTypeFromView(component: string | Node): string | null;
    transformLinksInStringComponent(component: string): DocumentFragment;
    getComponentHelpers(): HelperFunction;
    destroy(): void;
}
