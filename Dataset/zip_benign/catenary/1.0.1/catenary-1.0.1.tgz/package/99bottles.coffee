cat = require './catenary'

cat.define 'bottles', cat(1).dupd.equal.cat(' bottle', ' bottles').q.dupd.plus

cat.define 'beer',
  cat.bottles.cat(' of beer on the wall,').plus.print
    .bottles.cat(' of beer!').plus.print
    .cat('Take one down, pass it around,').print.dec
    .bottles.cat(' of beer on the wall.').plus.print
    .cat('').print

cat(99, cat.beer).loop()