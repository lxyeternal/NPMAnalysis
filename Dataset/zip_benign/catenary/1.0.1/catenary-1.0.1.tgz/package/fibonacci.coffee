cat = require './catenary'

cat.define 'nextfib', cat.swap.over.plus

cat(0, 1, 10, cat.dup.print.nextfib).repeat()

# [1, 1]
# [1, 1, 1]
# [1, 2]
# [2, 1, 2]
# [2, 3]
# [3, 2, 3]
# [3,
# [1, 2, 1]



# 1 1 2 3 5 8