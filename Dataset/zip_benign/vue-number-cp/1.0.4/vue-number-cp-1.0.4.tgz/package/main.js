// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'

import Layout from './components/Layout'
import htmlToPdf from '@/utils/htmlToPdf'
import router from './router'
import utils from './utils/util'
import filters from './filters/index'
import directives from './directives/index'
import store from './store/index.js'
// 国际化
// import i18n from './i18n/i18n'
import {
  InputNumber,
  Button,
  Select,
  Option,
  OptionGroup,
  Popover,
  Checkbox,
  Menu,
  Submenu,
  MenuItem,
  MenuItemGroup,
  Icon,
  Row,
  Col,
  // Tabs,
  // TabPane,
  Input,
  CheckboxButton,
  CheckboxGroup,
  Pagination,
  MessageBox,
  Message,
  Dialog,
  Form,
  FormItem,
  Tooltip,
  Radio,
  RadioGroup,
  Table,
  TableColumn,
  DatePicker,
  TimeSelect,
  Carousel,
  CarouselItem,
  Tree,
  Autocomplete,
  Alert,
  Tag,
  Steps,
  Step,
  Collapse,
  CollapseItem,
  Card,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  Progress,
  Cascader,
  Breadcrumb,
  BreadcrumbItem,
  Transfer,
    Tabs,
    TabPane,
} from 'element-ui';
import '@/styles/element-variables.scss'

// element ui component
Vue.component(Input.name, Input);
Vue.component(InputNumber.name, InputNumber);
Vue.component(Button.name, Button);
Vue.component(Select.name, Select);
Vue.component(Option.name, Option);
Vue.component(OptionGroup.name, OptionGroup);
Vue.component(Popover.name, Popover);
Vue.component(Checkbox.name, Checkbox);
Vue.component(Menu.name, Menu);
Vue.component(Row.name, Row);
Vue.component(Col.name, Col);
Vue.component(Icon.name, Icon);
// Vue.component(Tabs.name, Tabs);
// Vue.component(TabPane.name, TabPane);
Vue.component(Submenu.name, Submenu);
Vue.component(MenuItem.name, MenuItem);
Vue.component(MenuItemGroup.name, MenuItemGroup);
Vue.component(CheckboxButton.name, CheckboxButton);
Vue.component(CheckboxGroup.name, CheckboxGroup);
Vue.component(Pagination.name, Pagination);
Vue.component(MessageBox.name, MessageBox);
Vue.component(Message.name, Message);
Vue.component(Dialog.name, Dialog);
Vue.component(Form.name, Form);
Vue.component(FormItem.name, FormItem);
Vue.component(Tooltip.name, Tooltip);
Vue.component(Radio.name, Radio);
Vue.component(RadioGroup.name, RadioGroup);
Vue.component(Table.name, Table);
Vue.component(TableColumn.name, TableColumn);
Vue.component(DatePicker.name, DatePicker);
Vue.component(TimeSelect.name, TimeSelect);
Vue.component(Carousel.name, Carousel);
Vue.component(CarouselItem.name, CarouselItem);
Vue.component(Tree.name, Tree);
Vue.component(Autocomplete.name, Autocomplete);
Vue.component(Alert.name, Alert);
Vue.component(Tag.name, Tag);
Vue.component(Steps.name, Steps);
Vue.component(Step.name, Step);
Vue.component(Collapse.name, Collapse);
Vue.component(CollapseItem.name, CollapseItem);
Vue.component(Card.name, Card);
Vue.component(Dropdown.name, Dropdown);
Vue.component(DropdownMenu.name, DropdownMenu);
Vue.component(DropdownItem.name, DropdownItem);
Vue.component(Progress.name, Progress);
Vue.component(Cascader.name, Cascader);
Vue.component(Breadcrumb.name, Breadcrumb);
Vue.component(BreadcrumbItem.name, BreadcrumbItem);
Vue.component(Transfer.name, Transfer);
Vue.component(Tabs.name, Tabs);
Vue.component(TabPane.name, TabPane);
Vue.config.productionTip = false
Vue.use(utils)
Vue.use(filters)
Vue.use(directives)
Vue.use(htmlToPdf)

Vue.prototype.$message = Message;
Vue.prototype.$message.error = function (msg) {
  return MessageBox.alert(
    msg,
    {
      customClass: "alert-box",
      center: true,
      dangerouslyUseHTMLString: true,
      confirmButtonText: "知道了",
      callback: action => { }
    }
  );
}
Vue.prototype.$msgbox = MessageBox;
Vue.prototype.$message.error = function (msg) {
  return MessageBox.alert(
    msg,
    {
      customClass: "alert-box",
      center: true,
      dangerouslyUseHTMLString: true,
      confirmButtonText: "知道了",
      callback: action => { }
    }
  );
}
Vue.prototype.$alert = MessageBox.alert;
Vue.prototype.$confirm = MessageBox.confirm;
Vue.prototype.$prompt = MessageBox.prompt;

import VueLazyLoad from 'vue-lazyload'
Vue.use(VueLazyLoad)
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  // i18n,
  template: '<Layout/>',
  components: {
    Layout
  },
  mounted() {
    // window.onpopstate = () => {
    //   if (!this.allowBack) {    //这个allowBack 是存在vuex里面的变量
    //       history.go(1)
    //   }
    // }
  }
})