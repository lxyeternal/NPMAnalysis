import formatMoney from './formatMoney';
import formatThreeDigits from './formatThreeDigits';
import formatTwoDigits from './formatTwoDigits';
import getDateYmdTm from './getDateYmdTm';
import ceilNumber from './ceilNumber';
import supplierRank from './supplierRank';
import fillZero from './fillZero';
import venderProductStatus from './venderProductStatus';
import date from './date';
import datetime from './datetime';
import delayDate from './delayDate';

import formatName from './formatName';
import formatPhone from './formatPhone';
import formatEmail from './formatEmail';
import formatCardNum from './formatCardNum';
import weekDay from './weekDay';
import stakeHolder from './stakeHolder';
import stakeHolderSign from './stakeHolderSign';

import spliceString from './spliceString';
import moneyGetAns from './moneyGetAns';
import formatLongTime from './formatLongTime';
import noDataPlaceholder from './noDataPlaceholder';
import formatPhoneNumber from './formatPhoneNumber';
import formatPercentage from './formatPercentage';
import sliceValue from './sliceValue';
import nullValueConversion from './nullValueConversion';
export default {
    install(Vue, options) {
        //货币格式化  1000->1,000
        Vue.filter('formatMoney', formatMoney);
        // 每隔三位数 添加 逗号  100000.33 -> 100,000.33
        Vue.filter('formatThreeDigits', formatThreeDigits);
        // 保留两位小数 每隔三位数 添加 逗号  100000.33 -> 100,000.33
        Vue.filter('formatTwoDigits', formatTwoDigits);
        //时间格式化  2015-12-08 17:09:02 -> 2015-12-08 17:09
        Vue.filter('getDateYmdTm', getDateYmdTm);
        //取大整数
        Vue.filter('ceilNumber', ceilNumber);
        // 供应商等级
        Vue.filter('supplierRank', supplierRank);
        // 补零
        Vue.filter('fillZero', fillZero);
        // 供应商产品状态
        Vue.filter('venderProductStatus', venderProductStatus);
        // 日期格式化
        Vue.filter('date', date);
        Vue.filter('datetime', datetime);
        // 延迟时间
        Vue.filter('delayDate', delayDate);
         // Ydsagn  -> Y****n
        Vue.filter('formatName',formatName);
         // 13426004526 ->  134****4526
        Vue.filter('formatPhone',formatPhone);
         // 13426004526@qq.com ->  134****4526@qq.com
        Vue.filter('formatEmail',formatEmail);
        // 获取星期几
        Vue.filter('weekDay',weekDay);
        // 干系人
        Vue.filter('stakeHolder',stakeHolder);
        Vue.filter('stakeHolderSign',stakeHolderSign);

        // 干系人
        Vue.filter('spliceString',spliceString);

        Vue.filter('moneyGetAns',moneyGetAns);
        //格式化时间戳日期格式数据
        Vue.filter('formatLongTime',formatLongTime);
        // 数据未空时转换
        Vue.filter('noDataPlaceholder',noDataPlaceholder);
        // 格式化银行卡号（四位一组）
        Vue.filter('formatCardNum',formatCardNum);
        // 格式化电话号码（3-4-4）
        Vue.filter('formatPhoneNumber',formatPhoneNumber);
        // 百分比 %
        Vue.filter('formatPercentage',formatPercentage);
        // 字符串截取添加省略号
        Vue.filter('sliceValue',sliceValue);
        // 空值转换成 --
        Vue.filter('nullValueConversion',nullValueConversion);
    }
}