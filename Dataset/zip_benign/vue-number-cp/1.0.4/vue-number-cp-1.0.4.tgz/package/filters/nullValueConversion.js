export default function nullValueConversion(val) {
    return !val ? '--' : val
}
