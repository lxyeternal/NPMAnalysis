export default function noDataPlaceholder(value) {
    return (value === null || value === undefined || value === 'null' || value === 'undefined'  || value === '') ? '--' : value;
}

