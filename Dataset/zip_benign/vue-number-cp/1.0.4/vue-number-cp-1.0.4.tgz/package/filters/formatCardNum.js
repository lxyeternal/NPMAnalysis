export default function formatCardNum(val) {
    return val && val.replace(/\s/g,'').replace(/(.{4})/g,"$1 ");
}