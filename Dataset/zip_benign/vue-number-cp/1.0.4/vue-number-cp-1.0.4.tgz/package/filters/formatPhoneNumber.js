// 入参str "3-4-4" ———— 111-1111-1111
// 入参str "3 4 4" ———— 111 1111 1111

export default function formatPhoneNumber(val,str) {
    let renum=""; //函数返回对象
    if (val) {
        if (val.length == 11 && val.indexOf("-") == -1) {
            let arr=[3,4,4];
            let i,m=0,n;
            if(str.indexOf('-')>-1){
                arr=str.split("-");
                for(i=0; i<arr.length; i++){
                    n=m+Number(arr[i]);
                    renum+=val.substring(m,n);
                    if(i<arr.length-1) renum+="-";
                    m=n;
                }
            }else{
                arr=str.split(" ");
                for(i=0; i<arr.length; i++){
                    n=m+Number(arr[i]);
                    renum+=val.substring(m,n);
                    if(i<arr.length-1) renum+=" ";
                    m=n;
                }
            }
        }else {
            renum = val
        }
    }
    return renum
}