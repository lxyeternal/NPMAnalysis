export default function formatThreeDigits(number) {
    const numStr = number && number.toString() || '',
        numArr = numStr.split('.'),
        [num, dotNum] = numArr,
        operateNum = num.split('').reverse(),
        result = [], len = operateNum.length

    for (let i = 0; i < len; i++) {
        result.push(operateNum[i])
        if (((i + 1) % 3 === 0) && (i !== len - 1)) {
            result.push(',')
        }
    }

    if (dotNum) {
        result.reverse().push('.', ...dotNum)
        return result.join('')
    } else {
        return result.reverse().join('')
    }
}

