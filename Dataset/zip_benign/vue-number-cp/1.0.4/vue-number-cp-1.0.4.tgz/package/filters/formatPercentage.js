export default function formatPercentage(val) {
    return `${parseFloat((Number(val) * 100).toFixed(10)) || 0}%`
}

