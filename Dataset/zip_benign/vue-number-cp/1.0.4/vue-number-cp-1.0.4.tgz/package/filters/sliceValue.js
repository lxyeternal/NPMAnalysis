export default function sliceValue(val, maxLength) {
    maxLength = maxLength || 22
    return val.length > maxLength ? `${val.slice(0, maxLength)}…` : val
}

