// 与账户有关的混入
export default {
    computed: {
        userinfo() {
            return this.$store.state.userInfo;
        },
        role() {
            return this.$store.state.userInfo
                ? this.$store.state.userInfo.bs
                : 0;
        },
        acctId() {
            return this.$store.state.userInfo && this.$store.state.userInfo.acctId;
        },
        mxAcctIdList() {
            return this.$store.state.userInfo && this.$store.state.userInfo.acctIdList || [];
        },
        groupCompanyCode() {
            return this.$store.state.userInfo && this.$store.state.userInfo.groupCompanyCode;
        },
        corpIdList() {
            return this.$store.state.userInfo && this.$store.state.userInfo.corpIdList || []
        },
        // 施工单位、监理
        specialRole() {
            return (
                this.$store.state.userInfo &&
                (this.$store.state.userInfo.contractCorpType ===
                    "construction" ||
                    this.$store.state.userInfo.contractCorpType ===
                    "supervisory")
            );
        },
        // 经销商或代理商
        isAgent() {
            return (
                this.$store.state.userInfo && this.$store.state.userInfo.bs == 'S' && this.$store.state.userInfo.supplyType !== '0'
            );
        },
        // 合同公司类型
        contractCorpTypeMixins() {
            return this.$store.state.userInfo && this.$store.state.userInfo.contractCorpType || ''
        },
        // 不允许查看合同详情
        notViewContractDetails() {
            // 第二个条件待定, 施工单位监理、工程部项目经理鉴证，请款列表合同详情不需要添加链接
            return (this.$store.state.userInfo && this.$store.state.userInfo.contractCorpType === "supervisory")
        },
        // 监理
        supervisory() {
            return (this.$store.state.userInfo && this.$store.state.userInfo.contractCorpType === "supervisory")
        },
        specialPurChaseRole() {
            return (
                this.$store.state.userInfo &&
                this.$store.state.userInfo.contractCorpType === "material"
            );
        },
        // 大基建角色
        bigFrastructRole() {
            return this.$store.state.userInfo &&
                this.$store.state.userInfo.contractCorpType === "broker"
        },
        // 材料公司角色
        brokerRole() {
            return this.$store.state.userInfo &&
                this.$store.state.userInfo.contractCorpType === "broker"
        },
        // 舆情角色
        ldkgContract() {
            return this.$store.state.userInfo &&
                this.$store.state.userInfo.contractCorpType === "LDKG-CONTRACT"
        },
        roleIds() {
            return (this.$store.state.userInfo && this.$store.state.userInfo.roleIds) || [];
        },
        // 招标公司
        mxCorpList() {
            return (this.$store.state.userInfo && this.$store.state.userInfo.corpList) || [];
        },
        //博置招采部
        settlementRole() {
            return (this.$store.state.userInfo && this.$store.state.userInfo.roleIds.some(role => { return role.roleId === "1008" })) || false
        },
        //博置招采部
        recruitmentRole() {
            return (this.$store.state.userInfo && this.$store.state.userInfo.roleIds.some(role => { return role.roleId === "1002" })) || false
        },
        //博置工程部
        operateRole() {
            return (this.$store.state.userInfo && this.$store.state.userInfo.roleIds.some(role => { return role.roleId === "1003" })) || false
        },
        //博置财务部
        financeRole() {
            return (this.$store.state.userInfo && this.$store.state.userInfo.roleIds.some(role => { return role.roleId === "1004" })) || false
        },
        //博置副总经理
        managerRole() {
            return (this.$store.state.userInfo && this.$store.state.userInfo.roleIds.some(role => { return role.roleId === "1001" })) || false
        },

        // 当前登录用户 corpId
        mxCorpId() {
            return this.$store.state.userInfo && this.$store.state.userInfo.corpId || '';
        },

        // 事业部
        division() {
            return this.userinfo && this.userinfo.contractCorpType == "division"
        },

        // 大基建 用户
        // bigInfrastructure() {
        //     return this.userinfo && this.userinfo.custTags && this.userinfo.custTags.some(s => s.tagId == 'LVDI_CONSTRUCTION')
        // },
        bigInfrastructure() {
            return this.userinfo && this.userinfo.busitypeMng && this.userinfo.busitypeMng.some(i=> [1005].includes(i.busiId))
        },

        // 返回 过滤后 roleIds
        roleListFilter() {
            return corpId => {
                corpId = corpId || null
                const corpRoleList = this.userinfo && this.userinfo.corpRoleList || [],
                    roleFind = corpRoleList.find(f => f.corpId == corpId) || {}

                return roleFind.roleList || [];
            }
        },



    },
}