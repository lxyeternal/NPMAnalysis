// 跳转confluence
const axios = require('axios'),
    qs = require('qs'),
    configBase = require('../config/config.js')

export default {
    methods: {
        /**
         * @param id: 对应ID
         */
        toConfluence(id) {
            return new Promise((resolve, reject) => {
                const BASE_CONFIG = configBase && configBase.BASE_CONFIG || {},
                    user = JSON.parse(this.$getRootScope('user')) || {},
                    userName = user.confluenceUserName || '游客账户',
                    config = {
                        headers: { 'Content-type': 'application/x-www-form-urlencoded' },
                    },
                    param = {
                        'os_username': userName,
                        'os_password': BASE_CONFIG.OS_PASSWORD || '',
                        'login': '登录',
                        'os_destination': ''
                    },
                    pageId = this.getConfluencePageId(id) || ''

                axios.post(`${BASE_CONFIG.ROOT_URL}/confluence/dologin.action`, qs.stringify(param), config).then(response => {
                    window.open(`${BASE_CONFIG.ROOT_URL}/confluence/pages/viewpage.action?pageId=${pageId}`);
                    resolve('success')
                }).catch(err => reject('err'))
            })
        },
        // 获取 跳转ID
        getConfluencePageId(id) {
            const item = JSON.parse(this.$getRootScope('confluenceInfoList'))
            let pageId = ''

            item && item.some(s => {
                if (s.id == id) {
                    pageId = s.confluenceUrl
                    return true
                }
            })

            return pageId
        },
        // 检测权限
        privilegeDetection() {
            const item = JSON.parse(this.$getRootScope('user')) || {}
            // item && item.groupCompanyCode === "GREENLANDHK"
            // 采购商可以查看
            return item && item.bs === "B"
        }
    }
}