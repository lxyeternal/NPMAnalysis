<template>
  <div class="index-wrap">
    <Header :is-white-bg="true" :isHome="true" @refresh="openEsUserPerfectListDialog"></Header>
    <SearchBar :is-red-bg="true" :fromIndex="true" :search-type="searchBarType" :scrollShowFixed="true" @listenIsShowFooter="clickPoint()" :inputShowPointNotice="true" :isShowBigInfrastructure="false" @outputPointNotice="outputPointNotice"></SearchBar>
    <!--     <MoUpload></MoUpload> -->
    <!--<MenuBar :curren-router="currentRouter"></MenuBar>-->
    <LightColorMenuBar :curren-router="currentRouter"></LightColorMenuBar>

    <div class="index-view">
      <!-- <div style="height:60px;background: red;" @click="goT">跳转confluence</div> -->
      <div class="app-banner-container" ref="app-banner-container" id="app-banner-container">
        <el-carousel @change="carouselChange" :interval="5000" arrow="always" ref="banner" id="vueCarousel-wrapper">
          <el-carousel-item v-for="(item,index) in bannerList" :key="index">
            <img v-lazy="item.url" :class="{hand:item.jumpPage}" alt="" @click="go(item.jumpPage,item.params, item.bannerDetailSrc || '', item.newWindow)">
          </el-carousel-item>
        </el-carousel>
        <div class="member-container inner-container" ref="container" id="member-container">
          <div class="home-main clearfloat">
            <div class="site-bar-service">
              <ul class="service-bd f12">
                <li v-for="(treeLable,index) in categoryList" class="category-item" :key="index" v-on:mouseenter="showCategory(index)" v-on:mouseleave="hiddenCategory(index)">
                  <div class="parent-category" :title="treeLable.displayCategoryName || treeLable.categoryName">
                    <i class="arrow_right"></i>
                    <span class="child-category " @click="treeLable.existence && goProductList(treeLable.categoryName,treeLable.categoryId)">
                      <i class="icon-small-24"></i>{{treeLable.displayCategoryName || treeLable.categoryName}}</span>
                  </div>
                  <em></em>
                </li>
              </ul>
            </div>
            <div class="categoryListBox">
              <div v-for="(treeLable,index) in categoryList" :key="index+'categoryList'">
                <div class="expand-panel " v-show="treeLable.show" v-bind:style="{ top: -(index*50) + 'px' }" v-on:mouseenter="showCategory(index)" v-on:mouseleave="hiddenCategory(index)">
                  <div v-for="item in treeLable.numList">
                    <div class="second-category" v-for="(treeItem,inde) in filerCate(treeLable.children,item)" :key="inde">
                      <div class="expand-panel-parent" :class="{hand: treeItem.existence}" @click="treeItem.existence && goProductList(treeItem.categoryName,treeItem.categoryId)">{{treeItem.categoryName}}
                      </div>
                      <div class="expand-panel-child">
                        <span class="children-name" :class="{existence: treeLeaf.existence}" v-for="(treeLeaf,ind) in treeItem.children" :key="ind" @click="treeLeaf.existence && goProductList(treeLeaf.categoryName,treeLeaf.categoryId)">{{treeLeaf.categoryName}}</span>
                      </div>
                    </div>
                    <div style="clear: both"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div style="position:relative;width:100%;height:auto;z-index:999;">
          <div class="spec-wraper f14" v-if="false">
            <div class="spec-container inner-container clearfloat">
              <div class="spec-item">
                <div class="icon-cont icon-cont1"></div>
                <p class="spec-item-bd">钢材</p>
              </div>
              <div class="spec-item">
                <div class="icon-cont icon-cont2"></div>
                <p class="spec-item-bd">建筑材料</p>
              </div>
              <div class="icon-cont spec-item">
                <div class="icon-cont icon-cont3"></div>
                <p class="spec-item-bd">机械设备</p>
              </div>
              <div class="spec-item">
                <div class="icon-cont icon-cont4"></div>
                <p class="spec-item-bd">五金工具</p>
              </div>
              <div class="spec-item">
                <div class="icon-cont icon-cont5"></div>
                <p class="spec-item-bd">橡塑制品</p>
              </div>
              <div class="spec-item">
                <div class="icon-cont icon-cont6"></div>
                <p class="spec-item-bd">安防劳保</p>
              </div>
              <div class="spec-item">
                <div class="icon-cont icon-cont7"></div>
                <p class="spec-item-bd">行政办公</p>
              </div>
              <div class="spec-item">
                <div class="icon-cont icon-cont8"></div>
                <p class="spec-item-bd">电工电气</p>
              </div>
              <div class="spec-item">
                <div class="icon-cont icon-cont9"></div>
                <p class="spec-item-bd">施工杂料</p>
              </div>
            </div>
          </div>

          <div class="bg-container bg_water_01">
            <div class="hot-entrance inner-container clearfloat" style="padding-top: 60px;">
              <div class="item-title">
                <span>场景采购</span>
                <span>场景分类查询更便捷</span>
                <!--<span></span>-->
                <div style="clear: both"></div>
              </div>
              <div class="img-container">
                <img src="../../assets/images/home/construction_scene.jpg" style="display: block;">
                <ul>
                  <li>
                    <div><span>卧室</span></div>
                  </li>
                  <li>
                    <div><span>阳台</span></div>
                  </li>
                  <li>
                    <div><span>客厅</span></div>
                  </li>
                  <li>
                    <div><span>浴室</span></div>
                  </li>
                  <li>
                    <div><span>厨房</span></div>
                  </li>
                </ul>
              </div>
              <!-- 热门大宗 -->
              <div class="hot-container" v-if="false">
                <div class="home-hot-list clearfloat">
                  <ul class="home-list-bd" id="home-list-bd">
                    <li class="tl" style="padding-left: 40px">
                      <div class="bold" style="font-size: 34px;margin-bottom: 20px;">客厅</div>
                      <p><span class="hand">瓷砖</span></p>
                      <p><span class="hand">室内灯具</span></p>
                      <p><span class="hand">集成吊顶</span></p>
                      <p><span class="hand">家用电器</span></p>
                    </li>
                    <li v-for="(prod, index) in homePageProductRecommended.list && homePageProductRecommended.list.slice(0,4)" :key="index" @click="goDetail(prod)">
                      <div class="hot-pro-img"><img :src="prod.url" alt="" class="hand"></div>
                      <div :title="prod.spuName" class="first-hot-pro-title">{{prod.spuName}}</div>
                      <div class="price-content">
                        <div class="hot-pro-prize" v-if="isLogin == '1' && prod.price"><span>¥</span>{{prod.price}}</div>
                        <div class="hot-pro-prize" v-if="(!isLogin || isLogin != '1')">
                          <span class="red f15">￥登录可见</span>
                        </div>
                        <div class="hot-pro-prize-r">
                          销量:1831
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
              <!--<div class="more-container">-->
              <!--<i @click="goProduct(homePageProductRecommended.condition)">点击查看更多 &gt;</i>-->
              <!--</div>-->
            </div>
          </div>

          <div class=" bg-container bg_water_02">
            <div class="hot-entrance inner-container clearfloat" style="padding-top: 80px;">
              <div class="item-title">
                <span>热销品类</span>
                <span>精挑细选&nbsp;&nbsp;为您选购</span>
                <!--<span></span>-->
                <div style="clear: both"></div>
              </div>
              <div class="home-goods-list clearfloat" v-for="(item,ind) in hotGoodsList" :key="ind">
                <ul class="home-list-bd">
                  <li :class="{[item.background]:item.background}">
                    <div>{{item.title}}</div>
                    <span>{{item.content}}</span>
                    <p class="hand search-more" :class="{[item.background]:item.background}">查看更多</p>
                  </li>
                  <li class="hand hot-pro" v-for="(_item,index) in item.subList" :key="index">
                    <div>
                      <div class="hot-pro-title">{{_item.title}}</div>
                      <span class="hot-pro-sub-title">{{_item.subTitle}}</span>
                    </div>
                    <div class="hot-pro-img">
                      <img :src="_item.attachUrl">
                    </div>
                  </li>
                </ul>
              </div>
              <!-- <div class="more-goods">查看更多品类</div> -->
            </div>
          </div>
          <div class=" bg-container bg_water_03">
            <div class="hot-entrance inner-container clearfloat">
              <div class="item-title">
                <span>品牌直达</span>
                <span>精挑细选&nbsp;&nbsp;为您选购</span>
                <!--<span></span>-->
                <div style="clear: both"></div>
              </div>
              <div class="friends-logo">
                <p v-for="(brand,index) in brandList" :key="index" :style="{'background':'url('+brand.attachUrl+') no-repeat','background-size':'contain'}"></p>
                <!-- <p class="friends-1"></p>
                <p class="friends-2"></p>
                <p class="friends-3"></p>
                <p class="friends-4"></p>
                <p class="friends-5"></p>
                <p class="friends-6"></p>
                <p class="friends-7"></p>
                <p class="friends-8"></p>
                <p class="friends-9"></p>
                <p class="friends-10"></p>
                <p class="friends-11"></p>
                <p class="friends-12"></p> -->
              </div>
            </div>
          </div>
          <div class="bg-container" style="height: 124px;background: #a78640;">
            <div class="inner-container clearfloat f-content">
              <div>
                优质的资源供应
              </div>
              <div>
                500强企业背景
              </div>
              <div>
                融资一触即达
              </div>
              <div>
                全球领先建材交易平台
              </div>
              <div style="clear: both">
              </div>
              <!--<img src="../../assets/images/home/footer.png" height="100%" style="display: block;">-->
              <!--</div>-->
            </div>
          </div>

        </div>
      </div>
    </div>
    <Footer></Footer>
    <Loading :is-loading="isLoading"></Loading>
    <OpenDraftBoxList v-if="showDraftBoxList" v-model="showDraftBoxList" @showSelectSupplier="showSelectSupplier"></OpenDraftBoxList>
    <SelectSupplier v-if="isShowSelectSupplier" v-model="isShowSelectSupplier"></SelectSupplier>
    <PointComponent v-if="isLogin == 1 && userInfo.bs=='B' && isShowPoint" v-model="isShowPoint" :forceState="forceState" :imgPath="'batchOrder'" :imgNum="2" :targetId="userInfo.acctId" :targetKey="'USER_LOGIN_INDEX_COUNT'" @output="listenIsShowFooter" @close="isShowPoint = false"></PointComponent>
    <EsUserPerfectListDialog ref="EsUserPerfectListDialog"></EsUserPerfectListDialog>
  </div>
</template>

<script>
import {
  mapActions,
  mapState
} from 'vuex'
import VPagenation from '@/components/base/Pagenation'
import { InterfaceService } from '@/services/api'
import SearchBar from '@/components/SearchBar'
import Loading from '@/components/base/Loading'
import Footer from '@/components/base/Footer'
import Header from '@/components/base/Header'

import MenuBar from '@/components/MenuBar'
import LightColorMenuBar from '@/components/LightColorMenuBar'

// import { Carousel, Slide } from 'vue-carousel'
import MoUpload from '@/components/base/Upload'
import download from "@/utils/download";
import OpenDraftBoxList from '@/components/order/OpenDraftBoxList';
import SelectSupplier from '@/components/order/SelectSupplier';
import PointComponent from '@/components/base/PointComponent';
import snow from "../../utils/snowflake";

import EsUserPerfectListDialog from "@/components/order/dialog/EsUserPerfectListDialog";
import axios from 'axios'
import qs from 'qs';
export default {
  components: {
    VPagenation,
    SearchBar,
    LightColorMenuBar,
    Footer,
    Header,
    Loading,
    // Carousel,
    // Slide,
    MenuBar,
    MoUpload,
    OpenDraftBoxList,
    SelectSupplier,
    PointComponent,
    EsUserPerfectListDialog
  },
  data() {
    return {
      brandList: [
      ],
      hotGoodsList: [],
      currentRouter: '',
      isWhiteBg: false,
      slides: null,
      boardList: null,
      newsList: [],
      productList: null,
      total: 19,
      pageSize: 7,
      isLoading: false,
      searchBarType: 1,
      queryByName: '',
      bs: '1',
      menuTree: [],
      categoryList: [],
      // hotProductList: {},
      //bannerList:[],
      //shopList:[],
      //hotProductList:[],
      interval: null,
      nowCarouse: {}, // 走马灯当前对象
      showDraftBoxList: false,
      isShowSelectSupplier: false,
      isShowPoint: false,
      showPointComputed: false,
      forceState: false, // 强制显示
      homePageProductRecommended: {}, // 精品推荐
      categoryBaseBeans: [],
    }
  },
  watch: {},

  computed: {
    filerCate() {
      return function (list, num) {
        let remainder = num % 3;
        if (remainder == 0) {
          return list.slice(num - 3, num)
        } else {
          return list.slice(num - remainder, num)
        }
      }
    },
    isLogin() {
      // console.log(this.$store.state.isLogin)
      return this.$store.state.isLogin
    },
    userInfo() {
      // console.log(this.$store.state.LoginedUser.custName)
      return this.$store.state.userInfo
    },
    bannerList() {
      let item = this.$store.state.bannerList
      // 判断是否为采购商, 不是则移除 confluence介绍
      if (!(this.userInfo && this.userInfo.bs === 'B')) {
        item = item.filter(f => f.name !== 'conflurence_Banner')
      }
      return item
    },
    shopList() {
      return this.$store.state.shopList
    },
    hotProductList() {
      //console.log(this.$store.state.hotProductList)
      return this.$store.state.hotProductList
    }
    // categoryList(){
    //   // console.log(this.$store.state.LoginedUser.custName)
    //   return this.$store.state.categoryList
    // }
  },
  methods: {
    // 获取首页热销品类商品文件
    getHomeProdList() {
      InterfaceService.getHomeProdList(data => {
        let item = {}
        if (typeof data === "string") {
          item = eval("(" + data + ")");
        } else if (typeof data === "object") {
          item = data
        }
        this.hotGoodsList = item
      })
    },
    // 获取首页品牌直达列表文件
    getHomeBrandList() {
      InterfaceService.getHomeBrandList(data => {
        let item = {}
        if (typeof data === "string") {
          item = eval("(" + data + ")");
        } else if (typeof data === "object") {
          item = data
        }
        this.brandList = item
      })
    },
    searchWholeStation() {
      console.log(this.queryByName)
    },
    async init() {
      this.$removeRootScope('productBrandSelectList')
      setTimeout(async e => {
        try {
          await this.getCategoryOfBidWinning()
        } catch (error) {
          console.log('getCategoryOfBidWinning Error')
        }
        this.initCategoryList()
      }, 300)
      this.getStaticCommodityJson()

      this.getHomeProdList()
      this.getHomeBrandList()
    },

    getCategoryOfBidWinning() {
      return new Promise((resolve, reject) => {
        const categoryBaseBeans = JSON.parse(this.$getRootScope('categoryBaseBeans') || '[]') || []
        if (categoryBaseBeans.length) {
          this.categoryBaseBeans = categoryBaseBeans
          resolve(true)
          return
        }
        InterfaceService.getCategoryOfBidWinning({}, data => {
          if (data.respData && data.respData.respCode === "0000") {
            this.categoryBaseBeans = data.respData.categoryBaseBeans || []
            this.$setRootScope('categoryBaseBeans', JSON.stringify(data.respData.categoryBaseBeans))
          } else {
            this.$message.error(data.respData && data.respData.respMsg);
          }
          resolve(true)
        }, data => { reject(data) }, () => { }, () => { });
      })
    },

    handlePreferredBrandActive(item) {
      item.active = true
    },
    getStaticCommodityJson() {
    },
    showCategory(index) {
      //console.log(index)
      let newArr = this.categoryList[index];
      //console.log(newArr)
      newArr.show = true
      this.$forceUpdate();
      this.$set(this.categoryList, index, newArr)
    },
    hiddenCategory(index) {

      //console.log(index)
      let newArr = this.categoryList[index]
      newArr.show = false
      this.$forceUpdate();
      this.$set(this.categoryList, index, newArr)
    },

    showLeft() {

    },
    showRight() {

    },
    changeWho(type) {
      if (this.bs != type) {
        this.bs = type
      }
    },
    goProductList(name, id) {
      // 三新产品
      const threeNewProIds = ['1000', '10001', '100011', '10002', '100021', '10003', '100031', '10004', '100041', '10005', '100051']
      if (threeNewProIds.includes(id)) {
        const routeData = this.$router.resolve({
          path: `/threeNew`,
          query: {
            scrollTop: id.includes('10001') ? 900 : id.includes('10002') ? 1500 : id.includes('10003') ? 1855 : id.includes('10004') ? 2320 : id.includes('10005') ? 3400 : 0
          }
        });
        window.open(routeData.href, "_blank");
        return
      }
      const routeData = this.$router.resolve({
        path: "/productList",
        query: {
          categoryId: id,
          categoryName: name
        }
      });
      window.open(routeData.href, "_blank");
    },
    goProduct(condition) {
      if (condition.corpId) {
        const routeData = this.$router.resolve({
          path: "/store",
          query: {
            'corpId': condition.corpId,
            'categoryId': condition.categoryIds,
            'categoryName': condition.categoryName,
            'brandIds': condition.brandIds,
            'attrs': condition.attrs
          }
        });
        window.open(routeData.href, "_blank")
      } else if (condition.categoryIds) {
        const routeData = this.$router.resolve({
          path: "/productList",
          query: {
            'categoryId': condition.categoryIds,
            'categoryName': condition.categoryName,
            'brandIds': condition.brandIds,
            'attrs': condition.attrs
          }
        })

        window.open(routeData.href, "_blank")
      } else {
        const routeData = this.$router.resolve({
          path: "/productList"
        })

        window.open(routeData.href, "_blank")
      }
    },

    openEsUserPerfectListDialog(){
      this.$refs.EsUserPerfectListDialog && this.$refs.EsUserPerfectListDialog.open()
    },

    /**
     * 查找已存在商品类目
     */
    findAlreadyExists(categoryBaseBeans, res) {
      categoryBaseBeans && categoryBaseBeans.forEach(f => {
        this.categoryInfosExternalCirculation(f.categoryId, res)
        if (f.children && f.children.length) {
          this.findAlreadyExists(f.children, res)
        }
      })
    },

    categoryInfosExternalCirculation(id, res) {
      res && res.some(s => {
        if (s.categoryId == id) {
          return s.existence = true
        }
        if (s.children && s.children.length) {
          this.categoryInfosExternalCirculation(id, s.children)
        }
      })
    },

    initCategoryList() {
      let categoryList = this.$getRootScope('categoryList')
      if (categoryList) {
        categoryList = JSON.parse(categoryList)
        this.findAlreadyExists(this.categoryBaseBeans, categoryList)
        this.categoryList = categoryList
        this.categoryList.forEach(item => {
          item.numList = [];
          for (let i = 1; i <= item.children.length; i++) {
            if (i != item.children.length) {
              if (i % 3 == 0) {
                item.numList.push(i);
              }
            } else {
              item.numList.push(item.children.length);
            }
          }
        })
      } else {
        InterfaceService.getCategoryList(
          {
            categoryId: "1",
            queryType: "2",
          },
          data => {
            //console.log(data);
            if (data.respData.respCode === "0000") {
              let res = data.respData.categoryInfos || []
              this.findAlreadyExists(this.categoryBaseBeans, res)
              this.$store.commit('changeCategoryList', res)
              this.$setRootScope('categoryList', JSON.stringify(res))
              this.categoryList = res
              this.categoryList.forEach(item => {
                item.numList = [];
                for (let i = 1; i <= item.children.length; i++) {
                  if (i != item.children.length) {
                    if (i % 3 == 0) {
                      item.numList.push(i);
                    }
                  } else {
                    item.numList.push(item.children.length);
                  }
                }
              })
            } else {
              this.$message.error(data.respData.respMsg);
            }
          },
          data => { },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      }


      // if (!this.categoryList.some(s => s.key === '1100')) {
      //   this.categoryList.unshift(threeItem1)
      // }
      // if (!this.categoryList.some(s => s.key === '1200')) {
      //   this.categoryList.unshift(threeItem2)
      // }
    },
    // homePageBanner(){
    //     InterfaceService.homePageBanner(data => {
    //         if (typeof data === "string"){
    //             this.bannerList = eval ("(" + data + ")");
    //         } else if (typeof data === "object"){
    //             this.bannerList = data
    //         }
    //     });


    // },
    // homePageShop(){
    //     InterfaceService.homePageShop(data => {
    //         if (typeof data === "string"){
    //             this.shopList = eval ("(" + data + ")");
    //         } else if (typeof data === "object"){
    //             this.shopList = data
    //         }
    //     });
    // },
    // homePageProduct(){
    //     InterfaceService.homePageProduct(data => {
    //         if (typeof data === "string"){
    //             this.hotProductList = eval ("(" + data + ")");
    //         } else if (typeof data === "object"){
    //             this.hotProductList = data
    //         }
    //     });
    // },
    go(path, params, specialUrl, newWindow) {
      if (!path) return
      if (specialUrl && specialUrl.length > 0) {
        const routeData = this.$router.resolve({
          path: `/${path}`,
          query: {
            url: specialUrl
          }
        });
        window.open(routeData.href, "_blank");
        return
      }
      if (path == '/productDetail') {
        this.$router.push({
          path: path,
          query: {
            id: params.id,
            corpId: params.corpId
          }
        });
      } else if (path.indexOf('store') > -1) {
        this.$router.push({
          path: "/store",
          query: {
            corpId: params,
          }
        });
      } else if (path == '/productList') {
        this.$router.push({
          path: path,
          query: {
            'categoryId': params.categoryIds,
            'categoryName': params.categoryName,
            'brandIds': params.brandIds,
            'attrs': params.attrs
          }
        });
      } else {
        if (newWindow) {
          const routeData = this.$router.resolve({
            path: `/${path}`
          });
          window.open(routeData.href, "_blank");
          return
        }
        this.$router.push({
          path: path,
        });
      }
    },
    goDetail(product) {
      const routeData = this.$router.resolve({
        path: "/productDetail",
        query: {
          id: product.spuId,
          corpId: product.corpId
        }
      })
      window.open(routeData.href, "_blank")
    },
    goShop(id) {
      let store = {
        corpId: id
      };
      const routeData = this.$router.resolve({
        path: "/store",
        query: store
      })

      window.open(routeData.href, "_blank")
    },
    carouselChange(idx) {
      this.nowCarouse = this.bannerList[idx];
    },
    outputPointNotice() {
      console.log(1);

      this.forceState = true
      this.isShowPoint = true
    },
    clickPoint() {
      console.log(2);
      this.forceState = false
      this.isShowPoint = true
    },
    listenIsShowFooter(event) {
      this.showDraftBoxList = true
    },
    showSelectSupplier() {
      this.isShowSelectSupplier = true
    }
  },
  mounted() {
    this.init();
  },
  destroyed() {
    let countNum = Number(this.$getRootLocalStorage('countNum')) || 0

    this.$setRootLocalStorage('countNum', countNum + 1)
  },
  updated() {
  }
}
</script>

<style lang="scss" scoped>
.inner-container {
  width: 1200px;
}
.home-main {
  position: relative;
  margin: auto;
  height: 480px;
  .site-bar-service {
    position: relative;
    float: left;
    width: 280px;
    height: 480px;
    // background-color: #504c4c;
    overflow-x: hidden;
    overflow-y: auto;
    &:hover {
      width: 290px;
    }

    .service-bd {
      background-color: #504c4c;
      min-height: 480px;
      &:hover {
        margin-right: 10px;
      }
      li {
        position: relative;
        line-height: 50px;
        height: 50px;
        cursor: pointer;
        .icon-small-24 {
          position: absolute;
          top: 50%;
          left: 24px;
          margin-top: -12px;
        }
        .child-category {
          text-shadow: 0 2px 2px rgba(1, 78, 128, 0.4);
        }
        &:hover {
          .parent-category {
            background: #c99f4f;
            .arrow_right {
              opacity: 1;
            }
            .child-category {
              color: #fff;
              text-shadow: 2px 2px 4px rgba(26, 109, 67, 0.4);
            }
          }
          em {
            border-color: #fff;
          }
        }
        em {
          position: absolute;
          content: "";
          width: 11px;
          height: 11px;
          border: 1px solid #fff;
          border-left: 0;
          border-bottom: 0;
          transform: rotate(45deg);
          -webkit-transform: rotate(45deg);
          -moz-transform: rotate(45deg);
          -o-transform: rotate(45deg);
          top: 50%;
          right: 24px;
          margin-top: -7px;
        }
        .parent-category {
          transition: all 0.3s linear;
          position: relative;
          height: 50px;
          .arrow_right {
            opacity: 0;
            width: 10px;
            height: 100%;
            position: absolute;
            right: -10px;
            top: 0;
            &::before {
              content: "";
              transition: all 0.3s linear;
              position: absolute;
              border-width: 6px;
              border-style: solid;
              border-color: transparent transparent #c99f4f #c99f4f;
              left: -6px;
              transform: rotate(-135deg);
              top: 20px;
              z-index: 1000;
            }
          }
          a {
            display: inline-block;
            width: 100%;
            height: 100%;
          }

          span {
            display: inline-block;
            width: 100%;
            height: 100%;
            font-weight: 400;
            padding: 0 40px 0 64px;
            font-size: 14px;
            color: #fff;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
        }
      }
    }
  }
  /*.service-bd li:nth-of-type(2):hover {
      i {
        background-position: 0 -30px;
      }
    }
    .service-bd li:nth-of-type(3):hover {
      i {
        background-position: 0 -60px;
      }
    }
    .service-bd li:nth-of-type(4):hover {
      i {
        background-position: -31px 0;
      }
    }
    .service-bd li:nth-of-type(5):hover {
      i {
        background-position: -31px -30px;
      }
    }
    .service-bd li:nth-of-type(6):hover {
      i {
        background-position: -31px -60px;
      }
    }
    .service-bd li:nth-of-type(7):hover {
      i {
        background-position: -63px -29px;
      }
    }*/
  .promo-container {
    float: right;
    width: 896px;
    height: 100%;
    overflow: hidden;
    .promo-left {
      float: left;
      width: 450px;
      height: 580px;
    }

    .promo-right {
      float: right;
      width: 435px;
      /*height: 580px;*/

      .promo-right-img {
        margin-bottom: 11.5px;
        width: 100%;
      }
    }
  }
  .categoryListBox {
    position: absolute;
    top: 0;
    left: 280px;
    z-index: 999;
    > div {
      .expand-panel {
        width: 910px;
        min-height: 580px;
        background-color: #fff;
        background-position: -640px -156px;
        padding: 24px;
        -moz-box-shadow: 2px 8px 12px #e7e7e7;
        -webkit-box-shadow: 2px 8px 12px #e7e7e7;
        box-shadow: 2px 8px 12px #e7e7e7;
        .expand-panel-parent {
          line-height: 20px;
          cursor: text;
          &.existence {
            color: #0082ff;
            cursor: pointer;
          }
        }
        .second-category {
          width: 33%;
          float: left;
          margin-bottom: 52px;
          min-height: 100px;

          .expand-panel-child {
            font-size: 12px;
            color: #999;
            margin-right: 8px;
            line-height: 22px;
            width: 100%;
            margin-top: 10px;
            overflow: hidden;

            .children-name {
              color: #999;
              display: -moz-inline-stack;
              display: inline-block;
              vertical-align: middle;
              text-shadow: none;
              zoom: 1;
              border-right: 1px solid #ddd;
              line-height: 12px;
              font-size: 12px;
              margin: 0 10px 10px 0;
              padding: 0 10px 0 0;
              float: left;
              white-space: nowrap;
              display: inline-block;
              word-wrap: break-word;
              word-break: normal;
            }
            .children-name.existence {
              color: #0082ff;
              cursor: pointer;
            }
          }
        }
      }
    }
  }
}
.index-view {
  /*padding-bottom: 40px;*/
  background-color: #fff;
  position: relative;
  /deep/ .el-carousel__container {
    height: 480px;
  }

  /deep/ .el-carousel__arrow--left {
    display: none;
  }

  /deep/ .el-carousel__arrow--right {
    display: none;
  }

  /deep/ .el-carousel__item {
    img {
      position: absolute;
      height: 100%;
      top: 0;
      left: 50%;
      transform: translate(-50%, 0);
      -webkit-transform: translate(-50%, 0);
      -o-transform: translate(-50%, 0);
      -moz-transform: translate(-50%, 0);
    }
  }
  .app-banner-carousel-item-link {
    position: absolute;
    bottom: 93px;
    left: 50%;
    margin-left: -519px;
    pointer-events: none;
    z-index: 1;
    height: 74px;
    width: 241px;
    background: rgba(120, 122, 128, 0.01);
    pointer-events: auto;
    border-radius: 50px;
  }
  /*banner*/
  .app-banner-container {
    position: relative;
    .member-container {
      position: absolute;
      top: 0;
      left: 50%;
      margin-left: -600px;
      /*pointer-events: none;*/
      z-index: 100;
      .member {
        width: 300px;
        height: 100%;
        background-color: rgba(120, 122, 128, 0.75);
        position: absolute;
        top: 0;
        right: 0;
        pointer-events: auto;
        .member-header {
          padding-top: 40px;

          .member-header-ph {
            width: 82px;
            height: 78px;
            margin: 0 auto;
          }
          .member-header-hello {
            padding-top: 20px;
            text-align: center;
            color: #fff;
          }
        }
        .member-center {
          padding-top: 40px;
          overflow: hidden;
          .member-center-bar {
            height: 22px;
            line-height: 1.5;
            .member-center-tab {
              position: relative;
              float: left;
              width: 50%;
              color: #cccccc;
              text-align: center;

              &:before {
                position: absolute;
                content: "";
                width: 100%;
                height: 1px;
                background: #ccc;
                left: 0;
                bottom: 0;
              }

              &.active {
                color: #c99f4f;
              }

              &.active:before {
                background: #c99f4f;
                height: 2px;
              }
            }
          }
          .member-center-bar-bd {
            padding-top: 15px;
            li {
              height: 26px;
              line-height: 26px;
              font-size: 14px;
              color: #eee;
              padding-left: 30px;
            }
          }

          .is-purchase-center-bar {
            height: 65px;
            border-bottom: 1px solid #ddd;
            .is-purchase {
              width: 50%;
              height: 65px;
              color: #fff;
              font-size: 14px;
              line-height: 1;
              .counter {
                margin-bottom: 12px;
              }
            }
          }
        }

        .member-bottom {
          height: 96px;
          padding-top: 120px;
          .member-button {
            width: 48%;
            height: 36px;
          }

          .member-login {
            float: left;
            text-align: right;
            cursor: pointer;

            span {
              display: inline-block;
              width: 112px;
              height: 36px;
              background: #c99f4f;
              color: #fff;
              text-align: center;
              font-size: 16px;
              line-height: 36px;
            }
          }

          .member-register {
            float: right;
            text-align: left;
            cursor: pointer;

            span {
              display: inline-block;
              width: 111px;
              height: 35px;
              background: rgba(255, 255, 255, 0.8);
              border: 1px solid #c99f4f;
              color: #c99f4f;
              text-align: center;
              font-size: 16px;
              line-height: 36px;
            }
          }
        }
      }
    }
  }

  /*特色入口*/
  .spec-wraper {
    width: 100%;
    margin: auto;
    z-index: 100;
    background: #303030;
    /*height: 229px;*/
    .spec-container {
      height: 140px;
      margin: 0 auto;
      text-align: center;
      color: #fff;
      .spec-item {
        padding: 32px 35px;
        display: inline-block;
        height: 100%;
        width: 128px;
        &:hover {
          cursor: pointer;
          color: #c99f4f;
        }
        .icon-cont {
          height: 42px;
          display: block;
          margin-bottom: 10px;
          background: url("../../assets/images/icon/cate_icon.png") no-repeat;
          background-size: cover;
        }
        .icon-cont1 {
          background-position: 6px 0;
        }
        .icon-cont2 {
          background-position: -120px 0;
        }
        .icon-cont3 {
          background-position: -250px 0;
        }
        .icon-cont4 {
          background-position: -372px 0;
        }
        .icon-cont5 {
          background-position: -503px 0;
        }
        .icon-cont6 {
          background-position: -629px 0;
        }
        .icon-cont7 {
          background-position: -759px 0;
        }
        .icon-cont8 {
          background-position: -886px 0;
        }
        .icon-cont9 {
          background-position: -1015px 0;
        }
        .spec-item-bd {
          line-height: 1;
          margin-bottom: 10px;
        }
      }
    }
  }

  /*正文*/
  .container {
    margin: 0 auto;
    position: relative;
    z-index: 11;
    .bg-container {
      width: 100%;
      padding: 0 0 40px;
      background-position: center;
      /*&.bg_water_01 {*/
      /*background-image: url("../../assets/images/home/191119/bg_water_01.jpg");*/
      /*}*/
      &.bg_water_02 {
        background: #f2f2f2;
        padding: 0 0 1px;
      }
      /*&.bg_water_03 {*/
      /*background-image: url("../../assets/images/home/191119/information_display.jpg");*/
      /*height: 230px;*/
      /*}*/
      &.bg_water_03 {
        padding: 0 0 70px;
      }
      .head-tab {
        display: flex;
        justify-content: flex-end;
        li {
          user-select: none;
          cursor: pointer;
          margin-left: 22px;
          font-size: 16px;
          font-weight: bold;
          color: #7d7d7d;
          transition: all 0.3s linear;
          position: relative;
          padding-bottom: 12px;
          &:hover,
          &.active {
            color: #c99f4f;
          }
          &::after {
            content: "";
            position: absolute;
            width: 50px;
            height: 4px;
            background: transparent;
            top: 26px;
            left: 50%;
            transform: translateX(-50%);
            animation-fill-mode: forwards;
            -webkit-transform: translateX(-50%);
            -webkit-animation-fill-mode: forwards;
          }
          &.active {
            &::after {
              background: #c99f4f;
              animation: smallDndBig 0.3s 1;
              @keyframes smallDndBig {
                0% {
                  height: 0px;
                  top: 18px;
                }
                100% {
                  top: 26px;
                  height: 4px;
                }
              }
              @-webkit-keyframes smallDndBig {
                0% {
                  height: 0px;
                  top: 18px;
                }
                100% {
                  top: 26px;
                  height: 4px;
                }
              }
            }
          }
        }
      }
      .body-center {
        display: flex;
        justify-content: space-between;
        .left {
          width: 40%;
          margin-top: 30px;
          cursor: pointer;
          img {
            height: 100%;
          }
        }
        .right {
          display: flex;
          justify-content: space-between;
          width: 55%;
          flex-wrap: wrap;
          margin-top: 13px;

          li {
            width: 47%;
            background: #e5e5e5;
            text-align: center;
            margin-top: 16px;
            padding-bottom: 14px;
            cursor: pointer;
            transition: all 0.3s linear;
            &:hover {
              background: #c99f4f;

              .hot-pro-title {
                color: #333333;
              }
            }
            .hot-pro-img {
              height: 155px;
              img {
                height: 100%;
              }
            }
            .hot-pro-title {
              margin-top: 3px;
              transition: all 0.3s linear;
              white-space: pre;
              overflow: hidden;
              text-overflow: ellipsis;
              padding: 0 12px;
              font-size: 14px;
            }
          }
        }
      }
    }
    .contain_snow {
      height: 222px;
      width: 1920px;
      margin: auto;
      background-repeat: no-repeat;
      background-size: cover;
      position: relative;
      z-index: 99;
      pointer-events: none;
    }
    img {
      width: 100%;
      display: block;
      margin: 0 auto;
      height: auto;
    }

    .hot-entrance {
      padding: 65px 0 0;
      .item-title {
        height: 32px;
        line-height: 32px;
        margin-bottom: 32px;
        background: url("../../assets/images/home/grey_line.png") no-repeat
          370px 23px;
        span {
          display: inline-block;
        }
        span:first-child {
          font-size: 32px;
          padding-left: 66px;
          height: 34px;
          font-weight: bold;
          margin-right: 24px;
          // width: 209px;
          background: url("../../assets/images/home/icon/title_icon.png")
            no-repeat 0px;
        }
        span:nth-child(2) {
          color: #c99f4f;
          font-size: 14px;
          margin-right: 20px;
          letter-spacing: 1px;
          vertical-align: sub;
        }
        /*span:nth-child(3){*/
        /*height: 10px;*/
        /*background: #dedede;*/
        /*width: 800px;*/
        /*}*/
      }
      .hot-title {
        text-align: center;
        color: #444;
        font-size: 36px;
        line-height: 94px;
        height: 94px;
        margin: 37px auto;
        img {
          width: auto;
          height: 93px;
        }
      }

      .home-hot-list {
        text-align: center;
        ul {
          display: flex;
          // justify-content: space-between;
          flex-wrap: wrap;
          li {
            margin-bottom: 40px;
            position: relative;
            width: 232px;
            height: 260px;
            margin-right: 10px;
            // transition: all 0.3s linear;
            cursor: pointer;
            &:first-child {
              cursor: auto;
              border: none;
              padding: 33px 0 32px;
              color: #fff;
              line-height: 35px;
              background: url("../../assets/images/home/black.png") no-repeat;
              background-size: contain;
              &:hover {
                border: none !important;
              }
              p {
                font-size: 18px;
                &:hover {
                  color: #c99f4f;
                }
              }
            }
            &:last-child {
              margin-right: 0;
            }
            &:hover {
              /*border: 0;*/
              .first-hot-pro-title {
                color: #c99f4f;
              }
              border: 2px solid #c99f4f;
              .hot-pro-img {
                width: 226px !important;
                margin-left: 1px;
              }
            }
            .hot-pro-img {
              width: 100%;
              overflow: hidden;
              height: 180px;
              img {
                width: 100%;
                height: 100%;
              }
            }
            .first-hot-pro-title {
              text-align: left;
              font-size: 14px;
              color: #444;
              height: 32px;
              line-height: 17px;
              margin-top: 15px;
              margin-bottom: 10px;
              overflow: hidden;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-line-clamp: 2;
              -webkit-box-orient: vertical;
              padding: 0 10px;
            }

            .hot-pro-title {
              text-align: center;
              font-size: 14px;
              color: #fff;
              line-height: 1;
              padding: 16px 12px;
              transition: all 0.3s linear;
              white-space: pre;
              overflow: hidden;
              text-overflow: ellipsis;
            }
            .price-content {
              position: absolute;
              bottom: 0;
              height: 35px;
              line-height: 38px;
              width: 100%;
              padding: 0 10px;
              .hot-pro-prize {
                float: left;
                width: 49%;
                font-size: 24px;
                color: #888;
                line-height: 1;
                margin-top: 4px;
                text-align: left;
                height: 100%;
                span {
                  font-size: 14px;
                }
              }
              .hot-pro-prize-r {
                float: right;
                text-align: right;
                width: 49%;
                color: #888;
                height: 100%;
              }
            }
          }
        }

        .list-slide {
          position: absolute;
          top: 50%;
          width: 40px;
          height: 40px;
          background-color: #bbbbbb;
          margin-top: -20px;
          z-index: 999;

          &:before {
            content: "";
            position: absolute;
            width: 8px;
            height: 8px;
            border-top: 1px solid #fff;
            border-right: 1px solid #fff;
            top: 50%;
            left: 50%;
            margin-top: -4px;
            margin-left: -4px;
          }
        }

        .list-slide-left {
          left: 0;

          &:before {
            transform: rotate(-135deg);
          }
        }

        .list-slide-right {
          right: 0;

          &:before {
            transform: rotate(45deg);
          }
        }
      }
      .more-goods {
        margin-bottom: 30px;
        text-decoration: underline;
        text-align: center;
        font-size: 16px;
        color: #585858;
        cursor: pointer;
      }
      .home-goods-list {
        margin-bottom: 60px;
        position: relative;
        ul {
          background-size: contain;
          .blueBg {
            background: url("../../assets/images/home/blue.png") no-repeat;
            color: #8baed5;
          }
          .greenBg {
            background: url("../../assets/images/home/green.png") no-repeat;
            color: rgb(147, 182, 187);
          }
          .orangeBg {
            background: url("../../assets/images/home/orange.png") no-repeat;
            color: rgb(245, 161, 115);
          }
          li {
            width: 232px;
            height: 260px;
            float: left;
            padding: 21px 0 0;
            text-align: center;
            background: #fff;
            margin-left: 10px;
            margin-bottom: 10px;
            &:hover {
              border: 2px solid #c99f4f;
              .hot-pro-img {
                width: 226px !important;
                height: 176px !important;
                margin-left: 1px;
              }
            }
            &:first-child {
              color: #fff;
              margin-left: 0;
              line-height: 40px;
              padding-top: 40px;
              /*background: linear-gradient(to bottom, rgb(131, 169, 211) 0%, rgb(175, 197, 220) 100%);*/
              &:hover {
                border: none;
              }
              div {
                font-size: 36px;
                font-weight: bold;
              }
              span {
                margin-top: 2px;
                font-size: 16px;
                display: block;
              }
              p {
                margin: 26px auto;
                width: 110px;
                height: 32px;
                line-height: 32px;
                background: #fff !important;
                border-radius: 20px;
                font-size: 16px;
                &:hover {
                  background: linear-gradient(
                    120deg,
                    rgba(215, 176, 100, 1) 0%,
                    rgba(236, 206, 139, 1) 100%
                  ) !important;
                  color: #fff;
                }
              }
            }
            &:nth-child(6) {
              margin-left: 0;
            }
            &.hot-pro {
              display: flex;
              flex-direction: column;
              justify-content: space-between;
            }
            .hot-pro-title {
              color: #333;
              font-size: 14px;
              // line-height: 30px;
              // line-height: 16px;
              margin-bottom: 10px;
            }
            .hot-pro-sub-title {
              color: #9f9f9f;
              font-size: 12px;
              // margin-bottom: 14px;
              display: block;
            }
            .hot-pro-img {
              width: 230px;
              margin: 0 auto 1px;
              height: 180px;
              img {
                width: 100%;
                height: 100%;
              }
            }
          }
        }
      }
    }
    .corp-list {
      padding: 0 0 40px;
    }
  }

  .friends-box {
    position: relative;
    height: 450px;
    z-index: 11;
    .left {
      float: left;
    }
    .friends-left {
      width: 600px;
      height: 100%;
    }
    .friends-right {
      width: 300px;
      height: 100%;
    }
    .friends-center {
      width: 290px;
      height: 100%;
    }
  }
  .category-item:nth-child(1) i {
    background-position: 0px 0px;
  }
  .category-item:nth-child(2) i {
    background-position: -0px -30px;
  }
  .category-item:nth-child(3) i {
    background-position: 0px -60px;
  }
  .category-item:nth-child(4) i {
    background-position: -31px 0;
  }
  .category-item:nth-child(5) i {
    background-position: -31px -30px;
  }
  .category-item:nth-child(6) i {
    background-position: -31px -60px;
  }
  .category-item:nth-child(7) i {
    background-position: -63px -29px;
  }
  /* .category-item:nth-child(3) i {
    background-position: 0px 0px;
  }
  .category-item:nth-child(4) i {
    background-position: -0px -30px;
  }
  .category-item:nth-child(5) i {
    background-position: 0px -60px;
  }
  .category-item:nth-child(6) i {
    background-position: -31px 0;
  }
  .category-item:nth-child(7) i {
    background-position: -31px -30px;
  }
  .category-item:nth-child(1) i {
    background-position: -31px -60px;
  }
  .category-item:nth-child(2) i {
    background-position: -63px -29px;
  }*/
}
.more-container {
  text-align: center;
  margin-top: 40px;
  i {
    border: 1px solid #c99f4f;
    color: #c99f4f;
    padding: 12px 22px;
    border-radius: 4px;
    margin: auto;
    cursor: pointer;
    transition: all 0.3s linear;
    &:hover {
      background: #c99f4f;
      color: #fff;
    }
  }
}
.search-more:hover {
  color: #0082ff;
}
.img-container {
  // margin-bottom: 60px;
  position: relative;
  width: 1170px;
  height: 695px;
  ul {
    width: 100%;
    height: 100%;
    position: absolute;
    left: 0;
    top: 0;
    li {
      position: absolute;
      width: 28px;
      height: 28px;
      border: 2px solid #ff1e00;
      border-radius: 50%;
      box-shadow: 0 0 3px #ffeff1;
      cursor: pointer;
      transition: all 0.3s linear;
      $animationShadowBg: #ffeff1;
      @keyframes suspendedAnima {
        0% {
          box-shadow: 0 0 3px $animationShadowBg;
        }
        50% {
          box-shadow: 0 0 3px #ff1e00;
        }
        100% {
          box-shadow: 0 0 3px $animationShadowBg;
        }
      }
      @keyframes suspendedAnimaBefore {
        0% {
          box-shadow: 0 0 3px $animationShadowBg;
          transform: translate(-50%, -50%) scale(0.5);
        }
        50% {
          box-shadow: 0 0 3px #ff1e00;
          transform: translate(-50%, -50%) scale(1);
        }
        100% {
          box-shadow: 0 0 3px $animationShadowBg;
          transform: translate(-50%, -50%) scale(0.5);
        }
      }
      &:hover {
        animation: suspendedAnima 1s infinite;
        &::before {
          animation: suspendedAnimaBefore 1s infinite;
        }
        & > div {
          width: 100px;
        }
      }
      &::before {
        content: "";
        width: 18px;
        height: 18px;
        background: #ff1e00;
        border-radius: 50%;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        box-shadow: 0 0 3px #ffeff1;
      }
      & > div {
        transition: all 0.3s linear;
        position: absolute;
        left: 2px;
        transition: all 0.3s linear;
        width: 0px;
        overflow: hidden;
        height: 26px;
        span {
          position: absolute;
          left: 10px;
          background: #ff1e00;
          color: #fff;
          font-size: 16px;
          height: 26px;
          line-height: 26px;
          white-space: pre;
          margin-left: 30px;
          border-top-right-radius: 4px;
          border-bottom-right-radius: 4px;
          box-shadow: 1px 1px 2px #999;
          padding: 0 12px 0 9px;
          &::before {
            content: "";
            position: absolute;
            margin-left: -35px;
            border: 13px solid;
            border-color: transparent #ff1e00 transparent transparent;
            margin-top: 0px;
          }
        }
      }
      &:nth-child(1) {
        left: 518px;
        top: 180px;
      }
      &:nth-child(2) {
        left: 252px;
        top: 230px;
      }
      &:nth-child(3) {
        left: 351px;
        top: 311px;
      }
      &:nth-child(4) {
        left: 640px;
        top: 342px;
      }
      &:nth-child(5) {
        left: 865px;
        top: 408px;
      }
    }
  }
}
.f-content {
  div {
    display: inline-block;
    line-height: 124px;
    font-size: 18px;
    color: #fff;
    background-repeat: no-repeat;
    background-position: 20px center;
    padding: 0 85px 0 100px;
  }
  & div:nth-of-type(1) {
    background-image: url("../../assets/images/home/f_1.png");
  }
  & div:nth-of-type(2) {
    background-image: url("../../assets/images/home/f_2.png");
  }
  & div:nth-of-type(3) {
    background-image: url("../../assets/images/home/f_3.png");
  }
  & div:nth-of-type(4) {
    padding-right: 0;
    background-image: url("../../assets/images/home/f_4.png");
  }
}
.friends-logo {
  height: 401px;
  width: 1201px;
  border-left: 1px solid #f5f5f5;
  border-top: 1px solid #f5f5f5;
  margin-top: 65px;
  background-size: contain;
  p {
    border-bottom: 1px solid #f5f5f5;
    border-right: 1px solid #f5f5f5;
    float: left;
    width: 200px;
    height: 80px;
    // background: url("../../assets/images/home/friends.png") no-repeat;
  }
  .friends-1 {
    background-position: -21px -10px;
  }
  .friends-2 {
    background-position: -220px -10px;
  }
  .friends-3 {
    background-position: -418px -10px;
  }
  .friends-4 {
    background-position: -618px -10px;
  }
  .friends-5 {
    background-position: -818px -10px;
  }
  .friends-6 {
    background-position: -1018px -10px;
  }
  .friends-7 {
    background-position: -21px -90px;
  }
  .friends-8 {
    background-position: -220px -90px;
  }
  .friends-9 {
    background-position: -418px -90px;
  }
  .friends-10 {
    background-position: -618px -90px;
  }
  .friends-11 {
    background-position: -818px -90px;
  }
  .friends-12 {
    background-position: -1018px -90px;
  }
}
.special-img {
  background: url("../../assets/images/friends/partners/2-3.png") no-repeat;
}
</style>
