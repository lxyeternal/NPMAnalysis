<template>
  <div class="index-wrap">
    <Header :is-white-bg="true" :is-official-index="true"></Header>
    <SearchBar :is-red-bg="true" :searchType="8" :is-official-index="true" :search-type="searchBarType" :scrollShowFixed="true" @listenIsShowFooter="clickPoint()" :inputShowPointNotice="true" @outputPointNotice="outputPointNotice"></SearchBar>
    <!--     <MoUpload></MoUpload> -->
    <!--<MenuBar :curren-router="currentRouter"></MenuBar>-->
    <MenuBar :curren-router="currentRouter"></MenuBar>

    <div class="index-view">
      <!-- <div style="height:60px;background: red;" @click="goT">跳转confluence</div> -->
      <div class="app-banner-container" ref="app-banner-container" id="app-banner-container">
        <el-carousel @change="carouselChange" :interval="5000" arrow="always" ref="banner" id="vueCarousel-wrapper">
          <el-carousel-item v-for="(item,index) in bannerList" :key="index">
            <img src="../../assets/images/officailHome/banner.jpg" :class="{hand:item.jumpPage}" alt="" @click="go(item.jumpPage,item.params, item.bannerDetailSrc || '', item.newWindow)">
          </el-carousel-item>
        </el-carousel>
      </div>
      <div class="container">
        <div style="position:relative;width:100%;height:auto;z-index:999;">
          <div class="spec-wraper f14">
            <div class="spec-container inner-container clearfloat">
              <div class="spec-item">
                <div class="spec-item-cont">
                  <p class="spec-item-bd">平台资源丰富</p>
                  <span class="spec-item-bd">多年深耕房地产行业，20,000+优质供应商。共享龙头企业供应商成果</span>
                </div>
              </div>
              <div style="float:left;width: 1px;height: 135px;background: #fff;margin-top: 15px;"></div>
              <div class="spec-item">
                <div class="spec-item-cont">
                  <p class="spec-item-bd">交易规范透明</p>
                  <span class="spec-item-bd">覆盖企业供应链生命周期。过程在线实时追踪，对交易行为施行严格监控与管理</span>
                </div>
              </div>
              <div style="float:left;width: 1px;height: 135px;background: #fff;margin-top: 15px;"></div>
              <div class="icon-cont spec-item">
                <div class="spec-item-cont" style="width: 300px;">
                  <p class="spec-item-bd">降本增效赋能</p>
                  <span class="spec-item-bd">采购流程简化，支持线上合同订立、材料管理、请款结算。享受超低折扣，降低采购成本</span>
                </div>
              </div>
            </div>
          </div>

          <div class="bg-container bg_water_01">
            <div class="hot-entrance inner-container clearfloat">
              <img src="../../assets/images/officailHome/advantage.jpg" height="624">
            </div>
          </div>
          <div class=" bg-container bg_water_02">
            <div class="hot-entrance inner-container clearfloat">
              <img src="../../assets/images/officailHome/friends.jpg" height="624">
              <div class="more-goods">查看更多合作品牌</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <Footer></Footer>
    <Loading :is-loading="isLoading"></Loading>
    <OpenDraftBoxList v-if="showDraftBoxList" v-model="showDraftBoxList" @showSelectSupplier="showSelectSupplier"></OpenDraftBoxList>
    <SelectSupplier v-if="isShowSelectSupplier" v-model="isShowSelectSupplier"></SelectSupplier>
    <PointComponent v-if="isLogin == 1 && userInfo.bs=='B' && isShowPoint" v-model="isShowPoint" :forceState="forceState" :imgPath="'batchOrder'" :imgNum="2" :targetId="userInfo.acctId" :targetKey="'USER_LOGIN_INDEX_COUNT'" @output="listenIsShowFooter" @close="isShowPoint = false"></PointComponent>
  </div>
</template>

<script>
import {
  mapActions,
  mapState
} from 'vuex'
import VPagenation from '@/components/base/Pagenation'
import { InterfaceService } from '@/services/api'
import SearchBar from '@/components/SearchBar'
import Loading from '@/components/base/Loading'
import Footer from '@/components/base/Footer'
import Header from '@/components/base/Header'

import MenuBar from '@/components/MenuBar'
import LightColorMenuBar from '@/components/LightColorMenuBar'

// import { Carousel, Slide } from 'vue-carousel'
// import $ from 'jquery'
import MoUpload from '@/components/base/Upload'
import download from "@/utils/download";
import OpenDraftBoxList from '@/components/order/OpenDraftBoxList';
import SelectSupplier from '@/components/order/SelectSupplier';
import PointComponent from '@/components/base/PointComponent';
import snow from "../../utils/snowflake";


import axios from 'axios'
import qs from 'qs';
export default {
  components: {
    VPagenation,
    SearchBar,
    LightColorMenuBar,
    Footer,
    Header,
    Loading,
    // Carousel,
    // Slide,
    MenuBar,
    MoUpload,
    OpenDraftBoxList,
    SelectSupplier,
    PointComponent
  },
  data() {
    return {
      hotGoodsList:[{
        title:"劳保日杂",
        content:"安全施工防护省心",
        background:"blueBg",
        subList: [{
          title:"劳保鞋",
          subTitle:"劳保鞋",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"障碍帽",
          subTitle:"障碍帽",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"玻璃钢安全帽",
          subTitle:"生产再忙 安全不忘",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"双背安全带",
          subTitle:"高空作业的安全保障",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"彩条布",
          subTitle:"防渗 防水 防潮",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"苫布",
          subTitle:"更厚 更密 更完美",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"安全网",
          subTitle:"高密度 大拉力",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"雨鞋",
          subTitle:"精良炫彩 精细做工",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"遮阳网",
          subTitle:"质地柔软 精密贴合",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },]
      },{
        title:"电工电料",
        content:"电气工程精工品质",
        background:"greenBg",
        subList: [{
          title:"漏电断路器",
          subTitle:"用电安全有它",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"接线鼻子",
          subTitle:"连接生活",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"BV电线",
          subTitle:"点亮生活",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"电揽",
          subTitle:"服务电力安全可靠",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"扎带",
          subTitle:"电力金箍",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"电度表",
          subTitle:"幸福生活精度表",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"金属穿线管",
          subTitle:"电路安全保驾护航",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"塑料线盒",
          subTitle:"高防护易安装",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"插座",
          subTitle:"电流转移安全多样",
          attachUrl:"../../assets/images/home/hot_goods.png",
        }]
      },{
        title:"消防器材",
        content:"消防工程贴心保障",
        background:"orangeBg",
        subList: [{
          title:"ABC灭火器",
          subTitle:"3C消防认证",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"铝合金玻璃门窗",
          subTitle:"优质，美观，大方",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"灭火器箱",
          subTitle:"专用材质坚固",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"室内消火栓",
          subTitle:"室内消火栓",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"消防斧",
          subTitle:"消防拿控手中",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"消防勾",
          subTitle:"使用方便耐用",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"消防锹",
          subTitle:"优质铸铁锋利",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"消防桶",
          subTitle:"材质坚固持久",
          attachUrl:"../../assets/images/home/hot_goods.png",
        },{
          title:"消防水带",
          subTitle:"消防高压耐磨",
          attachUrl:"../../assets/images/home/hot_goods.png",
        }]
      }],
      currentRouter: '',
      isWhiteBg: false,
      slides: null,
      boardList: null,
      newsList: [],
      productList: null,
      total: 19,
      pageSize: 7,
      isLoading: false,
      searchBarType: 1,
      queryByName: '',
      bs: '1',
      menuTree: [],
      categoryList: [],
      // hotProductList: {},
      //bannerList:[],
      //shopList:[],
      //hotProductList:[],
      interval: null,
      nowCarouse: {}, // 走马灯当前对象
      showDraftBoxList: false,
      isShowSelectSupplier: false,
      isShowPoint: false,
      showPointComputed: false,
      forceState: false, // 强制显示
      homePageProductRecommended: {}, // 精品推荐
      homePageProductPreferredBrand: [], // 优选品牌
    }
  },
  watch: {},

  computed: {
    isLogin() {
      // console.log(this.$store.state.isLogin)
      return this.$store.state.isLogin
    },
    userInfo() {
      // console.log(this.$store.state.LoginedUser.custName)
      return this.$store.state.userInfo
    },
    bannerList() {
      let item = this.$store.state.bannerList
      // 判断是否为采购商, 不是则移除 confluence介绍
      if (!(this.userInfo && this.userInfo.bs === 'B')) {
        item = item.filter(f => f.name !== 'conflurence_Banner')
      }
      return item
    },
    shopList() {
      return this.$store.state.shopList
    },
    hotProductList() {
      //console.log(this.$store.state.hotProductList)
      return this.$store.state.hotProductList
    }
    // categoryList(){
    //   // console.log(this.$store.state.LoginedUser.custName)
    //   return this.$store.state.categoryList
    // }
  },
  methods: {

    goT() {
      let config = {
        headers: { 'Content-type': 'application/x-www-form-urlencoded' },
        // withCredentials:true
      };
      let param = {
        'os_username': "zhonglingyu",
        'os_password': "456",
        'login': "登录",
        'os_destination': ''
      }
      axios.post("https://sit.he-zhi.com/confluence/dologin.action", qs.stringify(param), config)
        .then(response => {
          console.log(response)
          window.open("https://sit.he-zhi.com/confluence/pages/viewpage.action?pageId=8978487");

        })
      // this.$setRootScope('toExport', "哈哈哈测试")
      // window.open("http://localhost:8080/#/exportInvoice");
    },
    searchWholeStation() {
      console.log(this.queryByName)
    },
    init() {
      this.initCategoryList()
      // this.initHotProductList()
      //this.homePageBanner()

      //this.homePageShop()
      //this.homePageProduct()
      // console.log(this.homePageBanner);
      this.getStaticCommodityJson()
    },
    handlePreferredBrandActive(item) {
      this.homePageProductPreferredBrand.forEach(f => f.active = false)
      item.active = true
    },
    getStaticCommodityJson() {
      this.getHomePageProductPreferredBrand()
      this.getHomePageProductRecommended()
    },

    getHomePageProductPreferredBrand() {
      InterfaceService.homePageProductPreferredBrand(data => {
        let item = []
        if (typeof data === "string") {
          item = eval("(" + data + ")");
        } else if (typeof data === "object") {
          item = data
        }
        this.homePageProductPreferredBrand = item
      })
    },

    getHomePageProductRecommended() {
      InterfaceService.homePageProductRecommended(data => {
        let item = {}
        if (typeof data === "string") {
          item = eval("(" + data + ")");
        } else if (typeof data === "object") {
          item = data
        }
        this.homePageProductRecommended = item
      })
    },
    showCategory(index) {
      //console.log(index)
      let newArr = this.categoryList[index];
      //console.log(newArr)
      newArr.show = true
      this.$forceUpdate();
      this.$set(this.categoryList, index, newArr)
    },
    hiddenCategory(index) {

      //console.log(index)
      let newArr = this.categoryList[index]
      newArr.show = false
      this.$forceUpdate();
      this.$set(this.categoryList, index, newArr)
    },

    showLeft() {

    },
    showRight() {

    },
    changeWho(type) {
      if (this.bs != type) {
        this.bs = type
      }
    },
    goProductList(name, id) {
      // 三新产品
      const threeNewProIds = ['1000', '10001', '100011', '10002', '100021', '10003', '100031', '10004', '100041', '10005', '100051']
      if (threeNewProIds.includes(id)) {
        const routeData = this.$router.resolve({
          path: `/threeNew`,
          query: {
            scrollTop: id.includes('10001') ? 900 : id.includes('10002') ? 1500 : id.includes('10003') ? 1855 : id.includes('10004') ? 2320 : id.includes('10005') ? 3400 : 0
          }
        });
        window.open(routeData.href, "_blank");
        return
      }
      const routeData = this.$router.resolve({
        path: "/productList",
        query: {
          categoryId: id,
          categoryName: name
        }
      });
      window.open(routeData.href, "_blank");
    },
    goProduct(condition) {
      if (condition.corpId) {
        const routeData = this.$router.resolve({
          path: "/store",
          query: {
            'corpId': condition.corpId,
            'categoryId': condition.categoryIds,
            'categoryName': condition.categoryName,
            'brandIds': condition.brandIds,
            'attrs': condition.attrs
          }
        });
        window.open(routeData.href, "_blank")
      } else if (condition.categoryIds) {
        const routeData = this.$router.resolve({
          path: "/productList",
          query: {
            'categoryId': condition.categoryIds,
            'categoryName': condition.categoryName,
            'brandIds': condition.brandIds,
            'attrs': condition.attrs
          }
        })

        window.open(routeData.href, "_blank")
      } else {
        const routeData = this.$router.resolve({
          path: "/productList"
        })

        window.open(routeData.href, "_blank")
      }
    },

    initCategoryList() {
      let categoryList = this.$getRootScope('categoryList')
      //console.log(categoryList)
      const threeNewItem = {
        key: "1000",
        show: false,
        title: "三新产品",
        children: [
          {
            key: "10001",
            title: "软瓷",
            children: [
              {
                key: "100011",
                title: "软瓷-柔石"
              }
            ]
          },
          {
            key: "10002",
            title: "膨石",
            children: [
              {
                key: "100021",
                title: "天基膨石"
              }
            ]
          },

          {
            key: "10003",
            title: "抹灰石膏",
            children: [
              {
                key: "100031",
                title: "轻质抹灰石膏"
              }
            ]
          },

          {
            key: "10004",
            title: "厨电类(住宅)",
            children: [
              {
                key: "100041",
                title: "抽油烟机"
              }
            ]
          },

          {
            key: "10005",
            title: "墙地砖",
            children: [
              {
                key: "100051",
                title: "呼吸砖"
              }
            ]
          },
        ]
      }
      if (categoryList) {
        this.categoryList = JSON.parse(categoryList)
      } else {
        InterfaceService.getCategoryList(res => {
          this.$store.commit('changeCategoryList', res['children'])
          this.$setRootScope('categoryList', JSON.stringify(res['children']))
          this.categoryList = res['children']
        })
      }
      if (!this.categoryList.some(s => s.key === '1000')) {
        this.categoryList.push(threeNewItem)
      }
    },
    // homePageBanner(){
    //     InterfaceService.homePageBanner(data => {
    //         if (typeof data === "string"){
    //             this.bannerList = eval ("(" + data + ")");
    //         } else if (typeof data === "object"){
    //             this.bannerList = data
    //         }
    //     });


    // },
    // homePageShop(){
    //     InterfaceService.homePageShop(data => {
    //         if (typeof data === "string"){
    //             this.shopList = eval ("(" + data + ")");
    //         } else if (typeof data === "object"){
    //             this.shopList = data
    //         }
    //     });
    // },
    // homePageProduct(){
    //     InterfaceService.homePageProduct(data => {
    //         if (typeof data === "string"){
    //             this.hotProductList = eval ("(" + data + ")");
    //         } else if (typeof data === "object"){
    //             this.hotProductList = data
    //         }
    //     });
    // },
    go(path, params, specialUrl, newWindow) {
      if (!path) return
      if (specialUrl && specialUrl.length > 0) {
        const routeData = this.$router.resolve({
          path: `/${path}`,
          query: {
            url: specialUrl
          }
        });
        window.open(routeData.href, "_blank");
        return
      }
      if (path == '/productDetail') {
        this.$router.push({
          path: path,
          query: {
            id: params.id,
            corpId: params.corpId
          }
        });
      } else if (path.indexOf('store') > -1) {
        this.$router.push({
          path: "/store",
          query: {
            corpId: params,
          }
        });
      } else if (path == '/productList') {
        this.$router.push({
          path: path,
          query: {
            'categoryId': params.categoryIds,
            'categoryName': params.categoryName,
            'brandIds': params.brandIds,
            'attrs': params.attrs
          }
        });
      } else {
        if (newWindow) {
          const routeData = this.$router.resolve({
            path: `/${path}`
          });
          window.open(routeData.href, "_blank");
          return
        }
        this.$router.push({
          path: path,
        });
      }
    },
    goDetail(product) {
      const routeData = this.$router.resolve({
        path: "/productDetail",
        query: {
          id: product.spuId,
          corpId: product.corpId
        }
      })
      window.open(routeData.href, "_blank")
    },
    goShop(id) {
      let store = {
        corpId: id
      };
      const routeData = this.$router.resolve({
        path: "/store",
        query: store
      })

      window.open(routeData.href, "_blank")
    },
    carouselChange(idx) {
      this.nowCarouse = this.bannerList[idx];
    },
    outputPointNotice() {
      console.log(1);

      this.forceState = true
      this.isShowPoint = true
    },
    clickPoint() {
      console.log(2);
      this.forceState = false
      this.isShowPoint = true
    },
    listenIsShowFooter(event) {
      this.showDraftBoxList = true
    },
    showSelectSupplier() {
      this.isShowSelectSupplier = true
    }
  },
  mounted() {
    this.init();
  },
  destroyed() {
    let countNum = Number(this.$getRootLocalStorage('countNum')) || 0

    this.$setRootLocalStorage('countNum', countNum+1)
  },
  updated() {
  }
}
</script>

<style lang="scss" scoped>
  .home-main {
    position: relative;
    margin: auto;
    height: 480px;
    .site-bar-service {
      position: relative;
      float: left;
      width: 280px;
      height: 480px;
      background-color: #504c4c;

      .service-bd {
        li {
          position: relative;
          line-height: 50px;
          height: 50px;
          cursor: pointer;
          .icon-small-24 {
            position: absolute;
            top: 50%;
            left: 24px;
            margin-top: -12px;
          }
          .child-category {
            text-shadow: 0 2px 2px rgba(1, 78, 128, 0.4);
          }
          &:hover {
            .parent-category {
              background: #c99f4f;
              &::before {
                opacity: 1;
              }
              .child-category {
                color: #fff;
                text-shadow: 2px 2px 4px rgba(26, 109, 67, 0.4);
              }
            }
            em {
              border-color: #fff;
            }
          }
          em {
            position: absolute;
            content: "";
            width: 11px;
            height: 11px;
            border: 1px solid #fff;
            border-left: 0;
            border-bottom: 0;
            transform: rotate(45deg);
            -webkit-transform: rotate(45deg);
            -moz-transform: rotate(45deg);
            -o-transform: rotate(45deg);
            top: 50%;
            right: 24px;
            margin-top: -7px;
          }
          .parent-category {
            transition: all 0.3s linear;
            position: relative;
            &::before {
              content: "";
              opacity: 0;
              transition: all 0.3s linear;
              position: absolute;
              border-width: 6px;
              border-style: solid;
              border-color: transparent transparent #c99f4f #c99f4f;
              right: -5px;
              transform: rotate(-135deg);
              top: 20px;
              z-index: 1000;
            }
            a {
              display: inline-block;
              width: 100%;
              height: 100%;
            }

            span {
              display: inline-block;
              width: 100%;
              height: 100%;
              font-weight: 400;
              padding-left: 64px;
              font-size: 14px;
              color: #fff;
            }
          }

          .expand-panel {
            position: absolute;
            width: 910px;
            min-height: 580px;
            background-color: #fff;
            background-position: -640px -156px;
            top: 0;
            left: 100%;
            z-index: 999;
            padding: 24px;
            -moz-box-shadow: 2px 8px 12px #e7e7e7;
            -webkit-box-shadow: 2px 8px 12px #e7e7e7;
            box-shadow: 2px 8px 12px #e7e7e7;
            .expand-panel-parent {
              line-height: 20px;

              &:hover {
                color: #0082ff;
              }
            }
            .second-category {
              width: 33%;
              float: left;
              margin-bottom: 52px;
              min-height: 100px;

              .expand-panel-child {
                font-size: 12px;
                color: #999;
                margin-right: 8px;
                line-height: 22px;
                width: 100%;
                margin-top: 10px;
                height: 56px;
                overflow: hidden;

                .children-name {
                  color: #999;
                  display: -moz-inline-stack;
                  display: inline-block;
                  vertical-align: middle;
                  text-shadow: none;
                  zoom: 1;
                  border-right: 1px solid #ddd;
                  line-height: 12px;
                  font-size: 12px;
                  margin: 0 10px 10px 0;
                  padding: 0 10px 0 0;
                  float: left;
                  white-space: nowrap;
                  display: inline-block;
                  word-wrap: break-word;
                  word-break: normal;
                }
                .children-name:hover {
                  color: #0082ff;
                }
              }
            }
          }
        }
      }
    }
    .service-bd li:nth-of-type(2):hover {
      i {
        background-position: 0 -30px;
      }
    }
    .service-bd li:nth-of-type(3):hover {
      i {
        background-position: 0 -60px;
      }
    }
    .service-bd li:nth-of-type(4):hover {
      i {
        background-position: -31px 0;
      }
    }
    .service-bd li:nth-of-type(5):hover {
      i {
        background-position: -31px -30px;
      }
    }
    .service-bd li:nth-of-type(6):hover {
      i {
        background-position: -31px -60px;
      }
    }
    .service-bd li:nth-of-type(7):hover {
      i {
        background-position: -63px -29px;
      }
    }
    .promo-container {
      float: right;
      width: 896px;
      height: 100%;
      overflow: hidden;
      .promo-left {
        float: left;
        width: 450px;
        height: 580px;
      }

      .promo-right {
        float: right;
        width: 435px;
        /*height: 580px;*/

        .promo-right-img {
          margin-bottom: 11.5px;
          width: 100%;
        }
      }
    }
  }
.index-view {
  /*padding-bottom: 40px;*/
  background-color: #fff;
  position: relative;
  /deep/ .el-carousel__container {
    height: 480px;
  }

  /deep/ .el-carousel__arrow--left {
    display: none;
  }

  /deep/ .el-carousel__arrow--right {
    display: none;
  }

  /deep/ .el-carousel__item {
    img {
      position: absolute;
      height: 100%;
      top: 0;
      left: 50%;
      transform: translate(-50%, 0);
      -webkit-transform: translate(-50%, 0);
      -o-transform: translate(-50%, 0);
      -moz-transform: translate(-50%, 0);
    }
  }
  .app-banner-carousel-item-link {
    position: absolute;
    bottom: 93px;
    left: 50%;
    margin-left: -519px;
    pointer-events: none;
    z-index: 1;
    height: 74px;
    width: 241px;
    background: rgba(120, 122, 128, 0.01);
    pointer-events: auto;
    border-radius: 50px;
  }
  /*banner*/
  .app-banner-container {
    position: relative;
    .member-container {
      position: absolute;
      top: 0;
      left: 50%;
      margin-left: -600px;
      /*pointer-events: none;*/
      z-index: 999;
      .member {
        width: 300px;
        height: 100%;
        background-color: rgba(120, 122, 128, 0.75);
        position: absolute;
        top: 0;
        right: 0;
        pointer-events: auto;
        .member-header {
          padding-top: 40px;

          .member-header-ph {
            width: 82px;
            height: 78px;
            margin: 0 auto;
          }
          .member-header-hello {
            padding-top: 20px;
            text-align: center;
            color: #fff;
          }
        }
        .member-center {
          padding-top: 40px;
          overflow: hidden;
          .member-center-bar {
            height: 22px;
            line-height: 1.5;
            .member-center-tab {
              position: relative;
              float: left;
              width: 50%;
              color: #cccccc;
              text-align: center;

              &:before {
                position: absolute;
                content: "";
                width: 100%;
                height: 1px;
                background: #ccc;
                left: 0;
                bottom: 0;
              }

              &.active {
                color: #c99f4f;
              }

              &.active:before {
                background: #c99f4f;
                height: 2px;
              }
            }
          }
          .member-center-bar-bd {
            padding-top: 15px;
            li {
              height: 26px;
              line-height: 26px;
              font-size: 14px;
              color: #eee;
              padding-left: 30px;
            }
          }

          .is-purchase-center-bar {
            height: 65px;
            border-bottom: 1px solid #ddd;
            .is-purchase {
              width: 50%;
              height: 65px;
              color: #fff;
              font-size: 14px;
              line-height: 1;
              .counter {
                margin-bottom: 12px;
              }
            }
          }
        }

        .member-bottom {
          height: 96px;
          padding-top: 120px;
          .member-button {
            width: 48%;
            height: 36px;
          }

          .member-login {
            float: left;
            text-align: right;
            cursor: pointer;

            span {
              display: inline-block;
              width: 112px;
              height: 36px;
              background: #c99f4f;
              color: #fff;
              text-align: center;
              font-size: 16px;
              line-height: 36px;
            }
          }

          .member-register {
            float: right;
            text-align: left;
            cursor: pointer;

            span {
              display: inline-block;
              width: 111px;
              height: 35px;
              background: rgba(255, 255, 255, 0.8);
              border: 1px solid #c99f4f;
              color: #c99f4f;
              text-align: center;
              font-size: 16px;
              line-height: 36px;
            }
          }
        }
      }
    }
  }

  /*特色入口*/
  .spec-wraper {
    width: 100%;
    margin: auto;
    z-index: 100;
    background: #303030;
    /*height: 229px;*/
    .spec-container {
      height: 164px;
      margin: 0 auto;
      text-align: center;
      color: #fff;
      .spec-item {
        padding-left:97px;
        float: left;
        width: 33%;
        text-align: left;
        background-repeat: no-repeat;
        background-position: 10px center;
        background-size: 80px;
        .spec-item-cont{
          height: 124px;
          width: 264px;
          margin: 40px 0 0;
        }
        &:hover {
          cursor: pointer;
          background-color: #15151b;
        }
        p{
          margin-top: 20px;
          font-size: 22px;
          font-weight: bold;
        }
        .spec-item-bd {
          line-height: 20px;
          margin-bottom: 25px;
        }
      }
    }
    .spec-container > div:first-child {
      background-image: url("../../assets/images/officailHome/trans.png") ;
    }
    .spec-container > div:nth-child(3) {
      background-image: url("../../assets/images/officailHome/quality.png");
    }
    .spec-container > div:last-child {
      background-image: url("../../assets/images/officailHome/efficiency.png");
    }
  }

  /*正文*/
  .container {
    margin: 0 auto;
    position: relative;
    z-index: 11;
    .bg-container {
      width: 100%;
      padding: 0 0 90px;
      background-position: center;
      /*&.bg_water_01 {*/
        /*background-image: url("../../assets/images/home/191119/bg_water_01.jpg");*/
      /*}*/
      &.bg_water_02 {
        background: #f5f5f5
      }
      /*&.bg_water_03 {*/
        /*background-image: url("../../assets/images/home/191119/information_display.jpg");*/
        /*height: 230px;*/
      /*}*/
      .head-tab {
        display: flex;
        justify-content: flex-end;
        li {
          user-select: none;
          cursor: pointer;
          margin-left: 22px;
          font-size: 16px;
          font-weight: bold;
          color: #7d7d7d;
          transition: all 0.3s linear;
          position: relative;
          padding-bottom: 12px;
          &:hover,
          &.active {
            color: #c99f4f;
          }
          &::after {
            content: "";
            position: absolute;
            width: 50px;
            height: 4px;
            background: transparent;
            top: 26px;
            left: 50%;
            transform: translateX(-50%);
            animation-fill-mode: forwards;
            -webkit-transform: translateX(-50%);
            -webkit-animation-fill-mode: forwards;
          }
          &.active {
            &::after {
              background: #c99f4f;
              animation: smallDndBig 0.3s 1;
              @keyframes smallDndBig {
                0% {
                  height: 0px;
                  top: 18px;
                }
                100% {
                  top: 26px;
                  height: 4px;
                }
              }
              @-webkit-keyframes smallDndBig {
                0% {
                  height: 0px;
                  top: 18px;
                }
                100% {
                  top: 26px;
                  height: 4px;
                }
              }
            }
          }
        }
      }
      .body-center {
        display: flex;
        justify-content: space-between;
        .left {
          width: 40%;
          margin-top: 30px;
          cursor: pointer;
          img {
            height: 100%;
          }
        }
        .right {
          display: flex;
          justify-content: space-between;
          width: 55%;
          flex-wrap: wrap;
          margin-top: 13px;

          li {
            width: 47%;
            background: #e5e5e5;
            text-align: center;
            margin-top: 16px;
            padding-bottom: 14px;
            cursor: pointer;
            transition: all 0.3s linear;
            &:hover {
              background: #c99f4f;

              .hot-pro-title {
                color: #333333;
              }
            }
            .hot-pro-img {
              height: 155px;
              img {
                height: 100%;
              }
            }
            .hot-pro-title {
              margin-top: 3px;
              transition: all 0.3s linear;
              white-space: pre;
              overflow: hidden;
              text-overflow: ellipsis;
              padding: 0 12px;
              font-size: 14px;
            }
          }
        }
      }
    }
    .contain_snow {
      height: 222px;
      width: 1920px;
      margin: auto;
      background-repeat: no-repeat;
      background-size: cover;
      position: relative;
      z-index: 99;
      pointer-events: none;
    }
    img {
      width: 100%;
      display: block;
      margin: 0 auto;
      height: auto;
    }



    .hot-entrance {
      padding: 30px 0 0;
      .item-title{
        height: 32px;
        margin-bottom: 20px;
        background: url("../../assets/images/home/grey_line.png") no-repeat right bottom;
        span{
          display: inline-block;
        }
        span:first-child{
          font-size: 32px;
          padding-left: 81px;
          font-weight: bold;
          margin-right: 20px;
          width: 209px;
          background: url("../../assets/images/home/icon/title_icon.png") no-repeat 25px;
        }
        span:nth-child(2){
          color: #c99f4f;
          font-size: 14px;
          margin-right: 20px;
        }
        /*span:nth-child(3){*/
          /*height: 10px;*/
          /*background: #dedede;*/
          /*width: 800px;*/
        /*}*/
      }
      .hot-title {
        text-align: center;
        color: #444;
        font-size: 36px;
        line-height: 94px;
        height: 94px;
        margin: 37px auto;
        img {
          width: auto;
          height: 93px;
        }
      }

      .home-hot-list {
        text-align: center;
        ul {
          display: flex;
          justify-content: space-between;
          flex-wrap: wrap;
          li {
            margin-bottom: 40px;
            position: relative;
            border: 2px solid #fff;
            box-shadow: 0px 0px 1px #eaeaea;
            transition: all 0.3s linear;
            width: 16%;
            cursor: pointer;
            &:first-child {
              cursor: auto;
              border:none;
              padding: 40px;
              color: #fff;
              line-height: 35px;
              background: #16151c;
              p{
                &:hover{
                  color: #c99f4f;
                }
              }
            }
            &:hover {
              border-color: #c99f4f;
              box-shadow: 0px 0px 1px #ffe167;
              .hot-pro-title {
                background: #c99f4f;
              }
            }
            .hot-pro-img {
              width: 100%;
              overflow: hidden;
              height: 160px;
              img {
                width: 100%;
                height: 100%;
              }
            }
            .first-hot-pro-title{
              text-align: left;
              font-size: 14px;
              color: #b1b1b1;
              height: 28px;
              margin-top: 15px;
              margin-bottom: 10px;
              overflow: hidden;
              text-overflow: ellipsis;
              display: -webkit-box;
              -webkit-line-clamp: 2;
              -webkit-box-orient: vertical;
            }

            .hot-pro-title {
              text-align: center;
              font-size: 14px;
              color: #fff;
              line-height: 1;
              padding: 16px 12px;
              transition: all 0.3s linear;
              white-space: pre;
              overflow: hidden;
              text-overflow: ellipsis;
            }
            .price-content{
              position: absolute;
              bottom: 0;
              height: 35px;
              line-height: 38px;
              width: 100%;
              .hot-pro-prize {
                float: left;
                width: 49%;
                font-size: 24px;
                color: #444;
                line-height: 1;
                margin-top: 4px;
                text-align: left;
                height: 100%;
                span {
                  font-size: 14px;
                }
              }
              .hot-pro-prize-r{
                float: right;
                text-align: right;
                width: 49%;
                color: #b1b1b1;
                height: 100%;
              }
            }

          }
        }

        .list-slide {
          position: absolute;
          top: 50%;
          width: 40px;
          height: 40px;
          background-color: #bbbbbb;
          margin-top: -20px;
          z-index: 999;

          &:before {
            content: "";
            position: absolute;
            width: 8px;
            height: 8px;
            border-top: 1px solid #fff;
            border-right: 1px solid #fff;
            top: 50%;
            left: 50%;
            margin-top: -4px;
            margin-left: -4px;
          }
        }

        .list-slide-left {
          left: 0;

          &:before {
            transform: rotate(-135deg);
          }
        }

        .list-slide-right {
          right: 0;

          &:before {
            transform: rotate(45deg);
          }
        }
      }
      .more-goods{
        text-decoration: underline;
        text-align: center;
        font-size: 16px;
        color: #585858;
        cursor: pointer;
      }
      .home-goods-list{
        margin-bottom: 100px;
        position: relative;
        ul {
          .blueBg{
            background: linear-gradient(to bottom, rgb(131, 169, 211) 0%, rgb(175, 197, 220) 100%);
            color: #8baed5;
          }
          .greenBg{
            background: linear-gradient(to bottom, rgb(147, 182, 187) 0%, rgb(196, 219, 220) 100%);
            color: rgb(147, 182, 187)
          }
          .orangeBg{
            background: linear-gradient(to bottom, rgb(245, 161, 115) 0%, rgb(246, 221, 211) 100%);
            color: rgb(245, 161, 115)
          }
          li{
            width: 230px;
            height: 258px;
            float: left;
            padding: 36px 50px 30px;
            text-align: center;
            background: #fff;
            margin-left: 10px;
            margin-bottom: 10px;
            &:first-child {
              color: #fff;
              margin-left:0;
              line-height: 40px;
              /*background: linear-gradient(to bottom, rgb(131, 169, 211) 0%, rgb(175, 197, 220) 100%);*/
              div {
                font-size: 32px;
                font-weight: bold;
              }
              span{
                font-size: 14px
              }
              p{
                margin: 32px auto;
                width: 110px;
                height: 32px;
                line-height: 32px;
                background: #fff !important;
                border-radius: 20px;
              }
            }
            &:nth-child(6) {
              margin-left:0;
            }
            .hot-pro-title{
              color: #333;
              font-size: 16px;
              line-height: 30px;
              margin-bottom: 10px;
            }
            .hot-pro-sub-title {
              color: #9f9f9f;
              font-size: 14px;
              margin-bottom: 50px;
              display: block;
            }
          }
        }
      }
    }
    .corp-list {
      padding: 0 0 40px;
    }
  }

  .frends-box {
    position: relative;
    height: 450px;
    z-index: 11;
    .left {
      float: left;
    }
    .frends-left {
      width: 600px;
      height: 100%;
    }
    .frends-right {
      width: 300px;
      height: 100%;
    }
    .frends-center {
      width: 290px;
      height: 100%;
    }
    .frends-logo {
      height: 150px;
      width: 100%;

      .left {
        float: left;
        width: 150px;
        height: 150px;

        &:hover {
          background-position: 0 -150px;
        }
      }

      .frends-1 {
        background: url(../../assets/images/friends/01.png) no-repeat;
        background-position: 0 0;
      }
      .frends-2 {
        background: url(../../assets/images/friends/02.png) no-repeat;
        background-position: 0 0;
      }
      .frends-3 {
        background: url(../../assets/images/friends/03.png) no-repeat;
        background-position: 0 0;
      }
      .frends-4 {
        background: url(../../assets/images/friends/04.png) no-repeat;
        background-position: 0 0;
      }
      .frends-5 {
        background: url(../../assets/images/friends/05-1.png) no-repeat;
        background-position: 0 0;
      }
      .frends-6 {
        background: url(../../assets/images/friends/06.png) no-repeat;
        background-position: 0 0;
      }

      .frends-7 {
        background: url(../../assets/images/friends/07.png) no-repeat;
        background-position: 0 0;
      }
      .frends-8 {
        background: url(../../assets/images/friends/08.png) no-repeat;
        background-position: 0 0;
      }
      .frends-9 {
        background: url(../../assets/images/friends/09.png) no-repeat;
        background-position: 0 0;
      }

      .frends-10 {
        background: url(../../assets/images/friends/10.png) no-repeat;
        background-position: 0 0;
      }
      .frends-11 {
        background: url(../../assets/images/friends/11.png) no-repeat;
        background-position: 0 0;
      }

      .frends-12 {
        background: url(../../assets/images/friends/12.png) no-repeat;
        background-position: 0 0;
      }
      .frends-13 {
        background: url(../../assets/images/friends/13.png) no-repeat;
        background-position: 0 0;
      }
      .frends-14 {
        background: url(../../assets/images/friends/14.png) no-repeat;
        background-position: 0 0;
      }
      .frends-15 {
        background: url(../../assets/images/friends/15.png) no-repeat;
        background-position: 0 0;
      }

      .frends-16 {
        background: url(../../assets/images/friends/16.png) no-repeat;
        background-position: 0 0;
      }
      .frends-17 {
        background: url(../../assets/images/friends/17.png) no-repeat;
        background-position: 0 0;
      }
      .frends-18 {
        background: url(../../assets/images/friends/18.png) no-repeat;
        background-position: 0 0;
      }
    }
  }
  .category-item:nth-child(1) i {
    background-position: 0px 0px;
  }
  .category-item:nth-child(2) i {
    background-position: -0px -30px;
  }
  .category-item:nth-child(3) i {
    background-position: 0px -60px;
  }
  .category-item:nth-child(4) i {
    background-position: -31px 0;
  }
  .category-item:nth-child(5) i {
    background-position: -31px -30px;
  }
  .category-item:nth-child(6) i {
    background-position: -31px -60px;
  }
  .category-item:nth-child(7) i {
    background-position: -63px -29px;
  }
}
.more-container {
  text-align: center;
  margin-top: 40px;
  i {
    border: 1px solid #c99f4f;
    color: #c99f4f;
    padding: 12px 22px;
    border-radius: 4px;
    margin: auto;
    cursor: pointer;
    transition: all 0.3s linear;
    &:hover {
      background: #c99f4f;
      color: #fff;
    }
  }
}
  .search-more:hover{
    color: #0082ff;
  }
</style>
