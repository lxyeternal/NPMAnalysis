<template>
  <div class="msgInfo" id="msgInfoSysNoticeId">
    <PanelTitle :tabs="tabs" @select="handleChangeTab" :unreadNum="unreadNum"></PanelTitle>

    <div class="msgInfo-table">
      <!-- 列表 -->
      <ul v-for="(msgInfo,index) in msgList" :key="index">
        <li class="contain" @click="handlechangeStatus(index)">
          <!--<div class="con i-1">{{msgInfo.creTm}}<div class="row-line"></div></div>-->
          <!--<div class="con i-2" v-show="msgInfo.messageSubClassName">{{msgInfo.messageSubClassName}}</div>-->
          <div class="con i-3">
            <p>{{msgInfo.title || '-'}}</p>
          </div>
          <div class="con i-2">{{msgInfo.creTm}}</div>
          <div class="con i-4 blue" :class="msgInfo.openStatus?'isOpen':''">
            <span class="icon-left-name">{{msgInfo.showStatusName}}</span>
            <!--<span class="el-icon-caret-top"></span>-->
            <span :class="msgInfo.openStatus?'el-icon-caret-top':'el-icon-caret-bottom'"></span>
          </div>
          <div class="clear"></div>
        </li>
        <div class="contain-datial" ref="detailId" :class="msgInfo.openStatus?'isShow':''">
          <CommonRiskInfo :msgInfo="msgInfo"></CommonRiskInfo>
        </div>
      </ul>
      <div class="table-pagination" v-show="msgList.length && tab==0">
        <el-pagination @current-change="handleCurrentChange" :current-page="unReadPageIndex" :page-size="pageSize" :total="commonTotal" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
        </el-pagination>
      </div>
      <div class="table-pagination" v-show="msgList.length && tab==1">
        <el-pagination @current-change="handleCurrentChange" :current-page="readPageIndex" :page-size="pageSize" :total="commonTotal" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
        </el-pagination>
      </div>

      <!-- 空列表 -->
      <div class="msgInfo-empty" v-if="!msgList.length&&!isLoading">
        <img src="@/assets/images/icon-no-product.png">
        <p>暂无相关信息</p>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import CommonRiskInfo from "@/components/riskMsgCenter/CommonRiskInfo";
import { InterfaceService } from "@/services/api";
import { filterEventByAcct } from '@/utils/orderUtil';

export default {
  components: {
    Loading,
    PanelTitle,
    CommonRiskInfo
  },
  computed: {
    unreadNum() {
      let info = JSON.parse(this.$getRootScope("watchUnreadInfo") || '{}');
      // info.unreadNum = Number(this.totalUnreadNums) - this.msgIdList.length
      info.unreadNum = Number(this.totalUnreadNums)
      console.log(this.msgIdList.length);
      this.$setRootScope("watchUnreadInfo", JSON.stringify(info));
      this.$store.dispatch('setMsgIdList',Number(this.totalUnreadNums))
      console.log(this.$store);
      this.$emit('unreadNum',info.unreadNum);
      return Number(this.totalUnreadNums)
    }
  },
  data() {
    return {
      haveMoreFlag: false,//是否还有更多数据
      dialogTitle: '详情',
      tabDetailType: '',
      gridData: [],
      dialogTableVisible: false,
      unReadPageIndex: 1,
      readPageIndex: 1,
      pageSize: 10,
      totalUnreadNums: '',
      tab: "0",
      tabs: [
        { label: "未读信息", isRead: 0, active: true },
        { label: "已读信息", isRead: 1 }
      ],
      // form: Object.assign({}, params),
      msgList: [],
      readTotal: 0,
      commonTotal: 0,
      isLoading: false,
      msgType: '01',
      msgIdList: [],
    };
  },
  methods: {
    /**
     * 监听 去查看
     */
    addEventCommonRiskLink() {
      document.getElementById("msgInfoSysNoticeId").addEventListener("click", (e) => {
        console.log(e, '---ee');
        const target = e.target || {}
        if (target.innerText == '去查看' || target.className == "goDetails") {
          e.preventDefault()
          console.log(target.href);
          const url = target.href || ''
          const path = url.slice(url.indexOf('#')) || ''
          if (path) {
            window.open(path, "_blank");
          }
        }
      })
    },
    // 修改tab
    handleChangeTab(tab) {
      this.tab = tab.isRead;
      this.unReadPageIndex = 1;
      this.readPageIndex = 1;
      if (tab.isRead == 0) {
        this.callMsgListData(this.tab, this.unReadPageIndex, 'normal');
      } else {
        this.callMsgListData(this.tab, this.readPageIndex, 'normal');
      }

    },
    // 分页跳转
    handleCurrentChange(page) {
      if (this.tab == 0) {
        this.unReadPageIndex = page;
        this.callMsgListData(this.tab, this.unReadPageIndex, 'normal');
      } else {
        this.readPageIndex = page;
        this.callMsgListData(this.tab, this.readPageIndex, 'normal');
      }
      window.scrollTo(0, 0)
    },
    handlechangeStatus(index) {
      var temparr = [];
      this.msgList.forEach((item, ind) => {
        if (ind == index) {
          item.openStatus = !item.openStatus;
          if (item.openStatus) {
            item.showStatusName = '收起';
            if (this.tab == 0) {
              this.doSysMsgStatusReaded([item.msgId])
            }
          } else {
            item.showStatusName = '展开';

          }
        }
        temparr.push(item);
      })
      console.log(this.msgList);
      this.msgList = [];
      this.msgList = temparr;

    },
    callMsgListData(isRead, pageIndex, messageType,init) {
      let params = {
        isRead: isRead,
        pageIndex: pageIndex,
        pageSize: this.pageSize,
        messageType: messageType,
        messageParentClass: this.msgType
      }
      InterfaceService.getSysMsgList(
        params,
        data => {
          if (null == data.respData.msgList) {
            this.msgList = [];//置空
            return;
          }
          if (this.tab == 0) {
              this.msgIdList = []
          }
          this.msgList = data.respData.msgList;
          if (this.tab == 1) {//已读
            this.commonTotal = data.respData.totalReadedNums;
          } else {
            this.commonTotal = data.respData.totalUnreadNums;
            if (init) {
              this.totalUnreadNums = this.commonTotal;
            }
          }
          //根据业务 完成赋值
          for (let i = 0; i < this.msgList.length; i++) {
            this.msgList[i].openStatus = false;
            this.msgList[i].delayFlag = false;
            this.msgList[i].showStatusName = '展开';
            try {
              this.msgList[i].content = JSON.parse(this.msgList[i].content);
              this.msgList[i].messageSubClass = 99;
              console.log(this.msgList[i].content);
            } catch (error) {
              console.log(error);
              console.log(this.msgList[i].content)
            }
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    doSysMsgStatusReaded(ids) {
      let params = {
        messageParentClass: this.msgType,
        messageType: 'normal',
        ids: ids
      }//未读
      InterfaceService.doSysMsgStatusReaded(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            this.msgIdList.push(ids[0])
            this.msgIdList = [...new Set(this.msgIdList)]
            this.commonTotal = data.respData.totalUnreadNums
            this.totalUnreadNums = data.respData.totalUnreadNums
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    init() {
      //默认 拉取未读第一页数据
      this.callMsgListData(0, 1, 'normal','init');
      this.addEventCommonRiskLink()
    }
  },
  mounted() {
    this.init();
    // this.handleLoadMore();
  },
  beforeDestroy() {
    console.log('beforeDestroy')
  },
};
</script>

<style lang="scss" scoped>
.hand + .hand {
  margin-left: 10px;
}
.price-tip {
  cursor: pointer;
  color: #a9a9aa;

  &:hover {
    color: #0082ff;
  }
}

.msgInfo {
  font-size: 14px;
}

.pointer {
  cursor: pointer;
  &:hover {
    color: #0082ff;
  }
  &:active {
    color: #4c9cdd;
  }

  .active {
    color: #ffd64e;
  }
}

.nowrap {
  white-space: nowrap;
}

.panel-content {
  margin-bottom: 5px;
  padding: 20px 10px;
  background: #f5f5f5;
}

.error-info {
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
  position: absolute;
  top: 100%;
  left: 0;
}

.form-btns {
  text-align: center;
}

.msgInfo-table {
  .clear {
    clear: both;
  }
  display: block;
  min-height: 530px;
  ul {
    display: block;
    width: 100%;
    list-style: unset;
    min-height: 60px;
    margin-top: 10px;
    li {
      list-style: none;
      min-height: 60px;
      line-height: 60px;
      background: #eee;
    }
    .contain {
      cursor: pointer;
      position: relative;
      padding-left: 20px;
      // .parent{
      //     display: inline-block;

      // }
      .con {
        // float: left;
        display: inline-block;
        margin: 1px 0;
        vertical-align: middle;
      }
      .i-1 {
        color: #444;
        width: 90px;
        position: relative;
        font-size: 12px;
      }
      .i-2 {
        color: #888;
        width: 105px;
        height: 100%;
        // line-height: 60px;
        font-size: 12px;
      }
      .i-3 {
        min-height: 60px;
        color: #444;
        width: 830px;
        //    overflow:hidden; /*超出的部分隐藏起来。*/
        //     white-space:nowrap;/*不显示的地方用省略号...代替*/
        //     text-overflow:ellipsis;/* 支持 IE */
        font-size: 14px;
        font-weight: 600;
        // position: relative;
        p {
          // position: absolute;
          width: 600px;
          margin: 21px 0px;
          display: block;
          // clear: both;
          line-height: 18px;
          // top: 50%;
          // left: 300px;
          // transform: translate(-50%,-50%)
        }
      }
      .i-4 {
        width: 50px;
        text-align: right;
        font-size: 12px;
      }
      .con.i-1::after {
        content: "";
        display: inline-block;
        width: 11px;
        height: 16px;
        border-right: 1px solid #888;
        position: absolute;
        right: 8px;
        top: 38%;
        transform: translate(-50%) rotate(0deg);
        -webkit-transform: translate(-50%) rotate(0deg);
      }
      /*<!--.i-4::before{-->*/
      /*<!--content: '';-->*/
      /*<!--position: absolute;-->*/
      /*<!--top: 42%;-->*/
      /*<!--right:50px;-->*/
      /*<!--width: 6px;-->*/
      /*<!--height: 6px;-->*/
      /*<!--border-top: 1px solid #adadad;-->*/
      /*<!--border-right: 1px solid #adadad;-->*/
      /*<!--transform: rotate(135deg);-->*/
      /*<!-- -webkit-transform: rotate(135deg);-->*/
      /*<!-- -moz-transform: rotate(135deg);-->*/
      /*<!-- -o-transform: rotate(135deg);-->*/
      /*<!--// margin-top: 9px;-->*/
      /*<!---->*/
      /*<!--}-->*/
      /*<!--.con.i-4.isOpen::before{-->*/
      /*<!--margin-top: 4px;-->*/
      /*<!--transform: rotate(-45deg);-->*/
      /*<!-- -webkit-transform: rotate(-45deg);-->*/
      /*<!-- -moz-transform: rotate(-45deg);-->*/
      /*<!-- -o-transform: rotate(-45deg);-->*/
      /*<!--}-->*/
    }
    .contain-datial {
      font-size: 12px;
      padding-top: 10px;
      // min-height: 60px;
      // height: 300px;
      opacity: 0;
      display: none;
      height: auto;
      background: #fff;
      padding: 0 20px;
      overflow: hidden;
      transition: height 0.5s ease-in-out, opacity 0.5s ease-in-out;
      -webkit-transition: height 0.5s ease-in-out, opacity 0.5s ease-in-out;
      .up {
        height: 40px;
        line-height: 40px;
        width: 100%;
        .left {
          width: 50%;
          float: left;
          .l-1 {
            width: 35%;
            float: left;
          }
          .l-2 {
            width: 65%;
            float: left;
            a {
              cursor: pointer;
              color: #0082ff;
            }
          }
        }
        .right {
          float: left;
          width: 50%;
          .r-1 {
            width: 35%;
            float: left;
          }
          .r-2 {
            width: 65%;
            float: left;
            a {
              cursor: pointer;
              color: #0082ff;
            }
          }
        }
      }
      .down {
        min-height: 40px;
        line-height: 25px;
        display: flex;
        .left {
          float: left;
          width: 17.5%;
        }
        .right {
          float: left;
          width: 82.5%;
          a {
            cursor: pointer;
            color: #0082ff;
          }
        }
      }
    }
    .isShow {
      border: 1px solid #eee;
      display: block;
      opacity: 1;
    }
    .contain-datial.isHide {
      opacity: 1;
      height: 0;
    }
  }
}

.msgInfo-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}

.price-popover {
  display: flex;
  color: #ababac;

  > div:first-child {
    margin-right: 10px;
  }

  p:first-child {
    padding: 0 5px;
    border-left: 3px solid #ffd64e;
    line-height: 15px;
  }

  p:last-child {
    margin-top: 10px;
    color: #ffffff;
  }
}

.table-pagination {
  margin: 20px 0 80px;
  text-align: center;
  color: #888888;
  .loadMore {
    cursor: pointer;
    margin: 0 auto;
    width: 80px;
    height: 30px;
    line-height: 30px;
    background: #ffd64e;
    color: #000;
    border-radius: 3px;
  }
}
:hover {
  //  background:none!important;
}
/deep/ .table-pagination:hover {
  background: none !important;
}
/deep/ .table-pagination .btn-prev:hover {
  background: none !important;
}
</style>




