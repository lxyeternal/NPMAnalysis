
<template>
  <div class="container">
    <div class="performance-repote-container" id="pdfContainerT">
      <div class="performance-repote-mid-center">
        <div class="performance-repote-center">
          <div class="head-container">
            <div class="logo-container">
              <a @click="go('/home')" class="logo-bd"></a>
            </div>
            <div class="report-information">
              <h3>{{evaluationInfo.name}}</h3>
              <h1>评估报告</h1>
              <div class="foot-information">
                <span>
                  数据提供: 合制平台及第三方数据网站
                </span>
                <span>
                  信息更新时间: {{evaluationInfo.updateDate | nullValueConversion}}
                </span>
              </div>
            </div>
          </div>
          <div class="bg-gary">
            <div class="title-info">
              <i></i>
              企业工商信息
            </div>
            <div class="m-title mt80">
              {{evaluationInfo.name | nullValueConversion}}
            </div>
            <div class="used-name" v-if="evaluationInfo.usedName">曾用名: {{evaluationInfo.usedName | nullValueConversion}}</div>
            <div class="company-info-row">
              <div class="company-info">
                <p>
                  <i class="pr-icon"></i>
                  <span>法人</span>
                </p>
                <b>{{evaluationInfo.legalPerson | nullValueConversion}}</b>
              </div>
              <div class="company-info-border"></div>
              <div class="company-info">
                <div class="border-container"></div>
                <p>
                  <i class="pr-icon"></i>
                  <span>注册资本</span>
                </p>
                <b>{{evaluationInfo.regCapital | nullValueConversion}}</b>
              </div>
              <div class="company-info-border"></div>
              <div class="company-info">
                <p>
                  <i class="pr-icon"></i>
                  <span>注册时间</span>
                </p>
                <b>{{evaluationInfo.estiblishTime ? formatDate(evaluationInfo.estiblishTime) : evaluationInfo.estiblishTime | nullValueConversion}}</b>
              </div>
            </div>
            <div class="border-bottom-dashede pr-icon"></div>
            <div class="company-number-row">
              <div>
                <p>工商注册号</p>
                <b>{{evaluationInfo.regNumber | nullValueConversion}}</b>
              </div>
              <div>
                <p>组织机构代码</p>
                <b>{{evaluationInfo.orgNumber | nullValueConversion}}</b>
              </div>
              <div>
                <p>纳税识别号</p>
                <b>{{evaluationInfo.taxNumber | nullValueConversion}}</b>
              </div>
            </div>

            <div class="company-info-row rating">
              <div>
                <div class="company-info">
                  <p>
                    <i class="pr-icon"></i>
                    <span>税务评级</span>
                  </p>
                  <b>{{evaluationInfo.taxRating | nullValueConversion}}</b>
                  <span v-if="evaluationInfo.taxRating">{{evaluationInfo.taxRatingYear ? '最新可查:' : ''}} {{evaluationInfo.taxRatingYear | nullValueConversion}}</span>
                </div>
              </div>
            </div>

            <div class="company-info-row industry">
              <div>
                <div class="company-info w800">
                  <p>
                    <i class="pr-icon"></i>
                    <span>所在行业</span>
                  </p>
                  <b>{{evaluationInfo.industry | nullValueConversion}}</b>
                </div>
              </div>
            </div>

            <div class="company-info-row registered-address">
              <div>
                <div class="company-info w800">
                  <p>
                    <i class="pr-icon"></i>
                    <span>注册地址</span>
                  </p>
                  <b>{{evaluationInfo.regLocation | nullValueConversion}}</b>
                </div>
              </div>
            </div>
          </div>
          <div class="title-info">
            <i></i>
            供应商入库条件风险评估
          </div>
          <div class="storage-container">
            <ul>
              <li v-for="(item, idx) in inboundAssessmentList" :key="idx">
                <span :class="{red: item.status == 0, gray: item.status == 3}">{{item.status == 0 ? '未通过' : item.status == 1 ? '通过' : '未检测' }}</span>
                <dl>
                  <dt>{{item.title}}</dt>
                  <dd>{{item.content}}</dd>
                </dl>
                <i v-if="inboundAssessmentList && idx < inboundAssessmentList.length - 1" class="pr-icon"></i>
              </li>
            </ul>
          </div>

          <div class="certification-info" v-if="inboundAssessmentList.filter(f=>f.status == 0).length">
            <i class="pr-icon"></i>
            <span>该供应商风险评估如上所示, 请慎重考虑。</span>
          </div>
          <div class="certification-info" v-else-if="inboundAssessmentList.length">
            <dl>
              <dt>特别说明：</dt>
              <dd>评估结果系通过技术手段抓取信息获得，评估通过不代表本公司对被评估对象及其相关信息的认可或保证，请使用者仔细鉴别。</dd>
            </dl>
          </div>
          <div class="applets-indication">
            <span>
              如需查看供应商风险详情, 可微信扫描报告最后一页的二维码, 登录履约小程序查看。
            </span>
            <i class="pr-icon"></i>
          </div>
          <!-- <div class="bg-gary pb20">
          <p>
            以上企业工商信息及风险舆情信息由第三方数据平台提供，数据分析结果并不代表我方对信息及内容的真实准确以及合法合规性的确认或认同，仅供用户参考。在报告披露的信息基础上，用户须自己作出决策并对所作的决策承担责任。
          </p>
        </div> -->
          <div class="applets-icon-container">
            <img width="240" height="240" src="@/assets/images/activity/performanceReport/applets_icon.png">
            <p>
              如需查看详细评估信息及舆情信息, 请登录履约评估小程序查看。
            </p>
            <p>
              微信扫一扫, 立即登录。
            </p>
          </div>
          <div class="foot-container1">
            <img src="@/assets/images/activity/performanceReport/pr_foot_bg_yellow.png">
            <div class="disclaimer">
              <p>
                免责声明：本报告谨作决策参考，所涉全部信息及数据均来源于第三方数据平台，本公司不控制、编辑或修改信息内容，不保证此类信息及数据的真实性、完整性、及时性及准确性。使用本报告做出任何行为所产生之权利义务由行为人自行承担，与本公司无涉。
              </p>
            </div>
          </div>
          <i class="position-icon"></i>
          <i class="position-icon top-right"></i>
          <i class="position-icon bottom-left"></i>
          <i class="position-icon bottom-right"></i>
          <i class="position-icon head-icon"></i>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
    <div :class="['download-container', {active: fixedDownloadActive, b50: fixedDoloadBottom}]">
      <i @click="downLoadDom('#pdfContainerT', `${evaluationInfo.name || ''}${evaluationInfo.name?' - ':''}评估报告`, false)"></i>
    </div>
  </div>
</template>
<script>
import Header from "@/components/base/Header"
import Loading from '@/components/base/Loading'
import CityInfoCompontent from "@/components/activity/performanceReport/CityInfoCompontent"
import RatingAndRanking from "@/components/activity/performanceReport/RatingAndRanking"
import { InterfaceService } from "@/services/api"
export default {
  components: { Header, Loading, CityInfoCompontent, RatingAndRanking },
  computed: {
    // 基本信息
    evaluationInfo() {
      let result = {}
      try {
        result = this.queryRespData && this.queryRespData.evaluationInfo
      } catch (error) { console.warn(`purchaseContractInfo: ${error}`) }
      return result || {}
    },
    inboundAssessmentList() {
      let result = []
      try {
        result = this.queryRespData && this.queryRespData.inboundAssessmentList
      } catch (error) { console.warn(`inboundAssessmentList: ${error}`) }
      return result || []
    },
    //时间戳转换方法    date:时间戳数字
    formatDate() {
      return (dateNum) => {
        const date = new Date(dateNum),
          YY = date.getFullYear() + ' -',
          MM = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + ' -',
          DD = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()),
          hh = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':',
          mm = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':',
          ss = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds())
        // + " " + hh + mm + ss
        return `${YY || ''} ${MM || ''} ${DD || ''}`;
      }
    }

  },
  data() {
    return {
      isLoading: false,
      corpId: '',
      queryRespData: {}, // 查询返回
      fixedDownloadActive: false,
      fixedDoloadBottom: false,
      supplierName: '', // 供应商名称
    }
  },
  mounted() {
    this.init()
    this.$nextTick(function () {
      window.addEventListener('scroll', this.onScroll)
    })
  },
  methods: {
    init() {
      this.getNinvestedMedicalExamination()
    },
    getNinvestedMedicalExamination() {
      this.queryRespData = JSON.parse(this.$getRootScope('ninvestedMedicalExamination')) || {}
    },
    downLoadDom(selector, fileName, isPdf) {
      this.getPdf(selector, fileName, isPdf)
    },
    onScroll() {
      const scrolled = document.documentElement.scrollTop || document.body.scrollTop,
        clientHeight = document.documentElement.clientHeight || document.body.clientHeight,
        scrollHeight = document.documentElement.scrollHeight || document.body.scrollHeight

      if (scrolled + clientHeight >= scrollHeight - 180) {
        this.fixedDownloadActive = true
      } else {
        this.fixedDownloadActive = false
      }

      if (scrolled + clientHeight >= scrollHeight) {
        this.fixedDoloadBottom = true
      } else {
        this.fixedDoloadBottom = false
      }

    },

    go(path) {
      this.$router.push(path);
    },

    /**
     * 获取供应商ID
     */
    getCorpId() {
      this.corpId = this.$route.query.corpId || ''
    },
  },

  destroyed() {
    window.removeEventListener('scroll', this.onScroll)
    this.$removeRootScope('ninvestedMedicalExamination')
  }
}
</script>

<style lang="scss" scoped>
$yellowColor: #ffd64f;
.container {
  position: relative;
  padding-bottom: 82px;
  .pr-icon {
    width: 50px;
    height: 50px;
    display: inline-block;
    background-image: url(../../assets/images/activity/performanceReport/performance_report_icon.png);
    background-repeat: no-repeat;
    background-position: -20px -10px;
    vertical-align: middle;
  }

  .download-container {
    $dfWidth: 80px;
    height: 90px;
    text-align: center;
    background: rgba(255, 214, 79, 0.9);
    position: fixed;
    width: calc(100% - #{$dfWidth});
    left: 40px;
    right: 0;
    bottom: 0;
    min-width: 1110px;
    transition: all 0.3s linear;
    box-shadow: 0px -1px 3px #ddd;
    &.active {
      left: 0;
      width: 100%;
      background: rgba(255, 214, 79, 1);
    }
    &.b50 {
      bottom: 50px;
    }
    i {
      background-image: url(../../assets/images/activity/performanceReport/download-icon.png);
      margin: auto;
      width: 630px;
      height: 100px;
      background-position: 100px 33px;
      cursor: pointer;
      display: block;
      background-repeat: no-repeat;
      background-size: 70%;
    }
  }
}
.performance-repote-container {
  // background: url(../../assets/images/activity/performanceReport/pic_bg1.png);
  background-position: center 20px;
  background-repeat: no-repeat;
  text-align: center;
  background-size: 80%;
  border: 34px solid $yellowColor;
  // border-right-width: 50px;
  position: relative;
  .performance-repote-mid-center {
    border: 4px solid #fff;
    position: relative;
    border-bottom: 0;
  }
  .performance-repote-center {
    border: 10px solid $yellowColor;
    position: relative;
    .head-container {
      background: url(../../assets/images/activity/performanceReport/head_bg.png);
      border-top: 1px solid transparent;
      overflow: hidden;
      background-position: center center;
      background-repeat: no-repeat;
      height: 875px;
    }
  }
  .mt20 {
    margin-top: 20px;
  }
  .mt100 {
    margin-top: 60px;
  }
  .mb20 {
    margin-bottom: 20px;
  }
  .mt80 {
    margin-top: 80px;
  }
  .mt-30 {
    margin-top: -30px !important;
  }
  .bgred {
    background: red;
  }

  .bg-gary {
    background: #f9f9f9;
    // url(../../assets/images/activity/performanceReport/pic_bg2.png);
    background-position: center -50px;
    background-repeat: no-repeat;
    text-align: center;
    padding: 20px 0 40px;
    margin-top: 0px;
    background-size: 120%;

    .title-info {
      margin-top: 80px;
    }
    &.pb20 {
      padding-bottom: 20px;
    }
    & > p {
      font-size: 12px;
      color: #666;
      width: 593px;
      margin: auto;
      line-height: 19px;
    }
  }
  .un-assessinfo {
    margin-top: 60px;
    color: #888;
    font-size: 18px;
  }
  .bg-f8f8f8 {
    background: #f8f8f8;
    background-position: center -40px;
    background-repeat: no-repeat;
    text-align: center;
    padding: 10px 0 100px;
    margin-top: 60px;

    .title-info {
      margin-top: 80px;
    }
  }

  .applets-notice {
    font-size: 21px;
    color: #999;
    margin-top: 12px;
  }

  .logo-container {
    text-align: center;
    margin: 200px 0 70px;
    a {
      margin: auto;
    }
  }

  .report-information {
    color: #333333;
    text-align: center;
    h3 {
      font-size: 42px;
    }
    h1 {
      font-size: 64px;
      margin: 53px auto 33px;
      font-weight: bold;
    }
    .foot-information {
      font-size: 16px;
      margin-top: 110px;
      margin-bottom: 93px;
      span {
        &:first-child {
          border-right: 1px solid #333;
          padding-right: 20px;
          margin-right: 22px;
        }
      }
    }
  }

  .title-info {
    font-size: 36px;
    position: relative;
    padding-top: 20px;
    margin-top: 80px;
    margin-bottom: 20px;
    text-align: center;
    i {
      width: 188px;
      height: 8px;
      background: #ffd64f;
      position: absolute;
      left: 50%;
      top: 0;
      transform: translateX(-50%);
    }
  }

  .evaluate-info-container {
    margin: 60px auto;
    width: 1050px;
    .special-title {
      span {
        font-size: 32px;
        color: #333;
        position: relative;
        i {
          background-image: url(../../assets/images/activity/performanceReport/performance_report_icon.png);
          background-repeat: no-repeat;
          display: inline-block;
          width: 80px;
          height: 50px;
          position: absolute;
          &:nth-child(1) {
            background-position: -44px -497px;
            left: -100px;
          }
          &:nth-child(2) {
            background-position: -277px -492px;
            right: -90px;
          }
        }
      }
    }
  }

  .m-title {
    font-size: 33px;
  }

  .company-info-row {
    width: 1050px;
    margin: 50px auto;
    .company-info-border {
      width: 1px;
      background: #999;
      height: 54px;
      display: inline-block;
    }
    .company-info {
      display: inline-block;
      width: 32%;
      position: relative;
      &.w800 {
        width: 800px;
      }
      &:nth-child(3) {
        p .pr-icon {
          background-position: -152px -10px;
        }
      }
      &:nth-child(5) {
        p .pr-icon {
          background-position: -298px -10px;
        }
      }
      p {
        font-size: 22px;
        color: #666666;
        span {
          margin-left: 4px;
        }
      }
      b {
        font-size: 24px;
        margin-top: 12px;
        display: block;
      }
    }
    // 评级
    &.rating {
      div {
        p .pr-icon {
          background-position: -300px -108px;
          width: 46px;
        }
        b {
          font-size: 60px;
        }
        span {
          margin-left: 0;
        }
        & > span {
          margin-top: 10px;
          color: #b6b6b6;
          font-size: 16px;
          display: block;
        }
      }
    }

    // 所在行业
    &.industry {
      div {
        p .pr-icon {
          background-position: -40px -103px;
          width: 30px;
        }
        span {
          margin-left: 0;
        }
      }
    }
    &.registered-address {
      div {
        p .pr-icon {
          background-position: -170px -103px;
          width: 30px;
        }
        span {
          margin-left: 0;
        }
      }
    }
  }
  .border-bottom-dashede {
    width: 1050px;
    background-position: 0px -790px;
    background-repeat: initial;
  }
  .company-number-row {
    width: 1050px;
    margin: 60px auto;
    & > div {
      text-align: center;
      display: inline-block;
      width: 33%;
      p {
        font-size: 22px;
        color: #666666;
      }
      b {
        font-size: 29px;
        margin-top: 12px;
        display: block;
      }
    }
  }

  // 采购数据
  .stock-info-container {
    padding-bottom: 80px;
    padding-top: 50px;
    width: 1050px;
    margin: auto;
    .stock-info-border {
      width: 2px;
      height: 154px;
      background: #999;
      display: inline-block;
      transform: scaleX(0.5);
    }
    & > div {
      display: inline-block;
      width: 24%;
      &:nth-child(3) {
        .pr-icon {
          background-position: -154px -203px;
        }
      }
      &:nth-child(6) {
        .pr-icon {
          background-position: -300px -203px;
        }
      }
      &:nth-child(8) {
        .pr-icon {
          background-position: -436px -203px;
        }
      }
      .pr-icon {
        background-position: -23px -203px;
      }
      .stock-info-center {
        font-size: 21px;
        li {
          margin-top: 16px;
          b {
            font-size: 28px;
            font-weight: bold;
          }
        }
      }
    }
  }

  // 基本信息
  .bace-info-container {
    width: 1050px;
    margin: auto;
    margin-top: 60px;
    width: 30%;
    font-size: 19px;
    color: #666666;
    overflow: hidden;
    & > div {
      float: left;
      width: 49%;
    }
    .code {
      color: #333333;
      font-size: 124px;
      font-family: cursive;
    }
    .level {
      color: #333333;
      font-size: 32px;
      line-height: 130px;
    }
  }

  // 合作城市信息
  .cooperative-city-info {
    background: #ffd64f;
    padding: 40px 20px 20px;
    width: 1050px;
    margin: 24px auto;
    .head-title {
      span {
        font-size: 22px;
        color: #333;
        position: relative;
        i {
          height: 1px;
          background: #333;
          width: 140px;
          position: absolute;
          top: 14px;
          &:nth-child(1) {
            left: -150px;
          }
          &:nth-child(2) {
            right: -150px;
          }
        }
      }
    }
  }
  // 舆情信息
  .notice-info {
    font-size: 30px;
    margin-top: 70px;
    .pr-icon {
      background-position: -20px -333px;
      vertical-align: middle;
    }
    p {
      display: inline-block;
    }
  }
  // 风险信息
  .el-row-center {
    width: 1050px;
    margin: auto;
    margin-top: 50px;
    overflow: hidden;
    .el-col-center {
      display: inline-block;
      width: 24%;
      font-size: 24px;
      .pr-icon {
        vertical-align: top;
      }

      &:nth-child(1) {
        .pr-icon {
          background-position: -23px -578px;
        }
      }
      &:nth-child(2) {
        .pr-icon {
          background-position: -310px -578px;
        }
      }
      &:nth-child(3) {
        .pr-icon {
          background-position: -598px -578px;
        }
      }
      &:nth-child(4) {
        .pr-icon {
          background-position: -886px -578px;
        }
      }
    }
    dl {
      margin-top: 13px;
      margin-left: 14px;
      text-align: left;
      display: inline-block;
      dt {
        margin-bottom: 20px;
      }
    }
    span {
      font-size: 36px;
      font-weight: bold;
    }

    &.el-row-center-last {
      margin-top: 80px;
      .el-col-center {
        &:nth-child(1) {
          .pr-icon {
            background-position: -23px -666px;
          }
        }
        &:nth-child(2) {
          .pr-icon {
            background-position: -310px -666px;
          }
        }
        &:nth-child(3) {
          .pr-icon {
            background-position: -599px -666px;
          }
        }
        &:nth-child(4) {
          .pr-icon {
            background-position: -886px -669px;
          }
        }
      }
    }
  }
  // 小程序ICON
  .applets-icon-container {
    margin-top: 60px;
    margin-bottom: 60px;
    img {
      display: block;
      margin: auto auto 50px;
      width: 240px;
    }
    p {
      margin-top: 20px;
      font-size: 18px;
    }
  }
  // 小程序
  .foot-container {
    background: url(../../assets/images/activity/performanceReport/pr_foot_bg.png)
      center center;
    height: 185px;
    background-size: 100%;
    width: 100%;
    background-repeat: no-repeat;
  }
  .foot-container1 {
    img {
      width: 100%;
      margin-bottom: -3px;
    }
    .disclaimer {
      position: absolute;
      margin-top: -46px;
      width: 560px;
      left: 50%;
      margin-left: -250px;
      font-size: 12px;
      line-height: 16px;
    }
  }
  .used-name {
    font-size: 20px;
    color: #525065;
    margin-top: 60px;
  }
  // 入库信息
  .storage-container {
    width: 770px;
    margin: auto;
    margin-top: 60px;
    overflow: hidden;
    ul {
      li {
        position: relative;
        min-height: 90px;
        padding-top: 22px;
        span {
          padding: 8px 0;
          border-radius: 20px;
          color: #35c56b;
          border: 1px solid #35c56b;
          float: left;
          width: 80px;
          margin-right: 20px;
          line-height: 14px;

          &.red {
            color: #f60000;
            border-color: #f60000;
          }

          &.gray {
            color: #8d908e;
            border-color: #8d908e;
          }
        }
        dl {
          $defaultWidth: 100px;
          float: left;
          text-align: left;
          width: calc(100% - #{$defaultWidth});
          dt {
            color: #333;
            font-size: 22px;
            margin-bottom: 12px;
            line-height: 26px;
          }
          dd {
            color: #808080;
            font-size: 14px;
          }
        }
        i {
          position: absolute;
          width: 100%;
          background-position: -20px -986px;
          bottom: 0;
          left: 0;
          height: 4px;
        }
      }
    }
  }

  // 认证信息
  .certification-info {
    position: relative;
    width: 770px;
    margin: 60px auto 100px;
    text-align: left;
    dl {
      font-size: 14px;
      line-height: 22px;
      overflow: hidden;
      dt {
        float: left;
        width: 76px;
      }
      dd {
        float: left;
        width: 680px;
      }
    }
    i {
      &:first-child {
        background-position: -103px -920px;
        position: absolute;
        left: 0;
      }
      &:last-child {
        background-position: -173px -847px;
        position: absolute;
        right: -10px;
        width: 274px;
        height: 134px;
        margin-top: 42px;
      }
    }
    span {
      color: #333;
      font-size: 30px;
      margin-left: 42px;
      margin-top: 0px;
      display: inline-block;
    }
  }

  // 履约小程序提示
  .applets-indication {
    margin: auto;
    span {
      font-size: 16px;
      color: #9a9898;
      display: block;
    }
    i {
      background-position: -91px -850px;
    }
  }

  // 边框图片
  .position-icon {
    width: 410px;
    height: 410px;
    background-image: url(../../assets/images/activity/performanceReport/position_top_left_icon.png);
    background-repeat: no-repeat;
    background-position: 0 0;
    vertical-align: middle;
    position: absolute;
    left: -40px;
    top: -40px;
    z-index: 1;

    &.top-right {
      right: -40px;
      left: auto;
      background-position: -17px 0px;
      background-image: url(../../assets/images/activity/performanceReport/position_top_right_icon.png);
    }
    &.bottom-left {
      top: auto;
      bottom: -40px;
      background-position: 0 0;
      background-image: url(../../assets/images/activity/performanceReport/position_bottom_left_icon.png);
    }
    &.bottom-right {
      top: auto;
      left: auto;
      bottom: -40px;
      right: -40px;
      background-position: -17px 0px;
      background-image: url(../../assets/images/activity/performanceReport/position_bottom_right_icon.png);
    }

    &.head-icon {
      left: 50%;
      margin-left: -300px;
      background-position: -613px 0px;
      width: 600px;
      background-image: url(../../assets/images/activity/performanceReport/position_icon.png);
    }
  }
}
</style>
