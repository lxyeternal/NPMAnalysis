
<template>
  <div class="container pb42">
    <div class="performance-repote-container" id="pdfContainer">
      <div class="performance-repote-mid-center">
        <div class="performance-repote-center">
          <div class="head-container">
            <div class="logo-container">
              <a @click="go('/home')" class="logo-bd"></a>
            </div>
            <div class="report-information">
              <h3>{{companyBaseInfo.name}}</h3>
              <h1>履约情况及风险评估报告</h1>
              <div class="foot-information">
                <span>
                  数据提供: 合制平台及第三方数据网站
                </span>
                <span>
                  信息更新时间: {{queryRespData.updateDate | nullValueConversion}}
                </span>
              </div>
            </div>
          </div>
          <div class="bg-gary mt0">
            <div class="title-info">
              <i></i>
              企业工商信息
            </div>
            <div class="m-title mt80">
              {{companyBaseInfo.name | nullValueConversion}}
            </div>

            <div class="company-info-row">
              <div class="company-info">
                <p>
                  <i class="pr-icon"></i>
                  <span>法人</span>
                </p>
                <b>{{companyBaseInfo.legalPersonName | nullValueConversion}}</b>
              </div>
              <div class="company-info-border"></div>
              <div class="company-info">
                <div class="border-container"></div>
                <p>
                  <i class="pr-icon"></i>
                  <span>注册资本</span>
                </p>
                <b>{{companyBaseInfo.regCapital | nullValueConversion}}</b>
              </div>
              <div class="company-info-border"></div>
              <div class="company-info">
                <p>
                  <i class="pr-icon"></i>
                  <span>注册时间</span>
                </p>
                <b>{{companyBaseInfo.estiblishTime ? formatDate(companyBaseInfo.estiblishTime) : companyBaseInfo.estiblishTime | nullValueConversion}}</b>
              </div>
            </div>
            <div class="border-bottom-dashede pr-icon"></div>
            <div class="company-number-row">
              <div>
                <p>工商注册号</p>
                <b>{{companyBaseInfo.regNumber | nullValueConversion}}</b>
              </div>
              <div>
                <p>组织机构代码</p>
                <b>{{companyBaseInfo.orgNumber | nullValueConversion}}</b>
              </div>
              <div>
                <p>纳税识别号</p>
                <b>{{companyBaseInfo.taxNumber | nullValueConversion}}</b>
              </div>
            </div>

            <div class="company-info-row industry">
              <div>
                <div class="company-info w800">
                  <p>
                    <i class="pr-icon"></i>
                    <span>所在行业</span>
                  </p>
                  <b>{{companyBaseInfo.industry | nullValueConversion}}</b>
                </div>
              </div>
            </div>

            <div class="company-info-row registered-address">
              <div>
                <div class="company-info w800">
                  <p>
                    <i class="pr-icon"></i>
                    <span>注册地址</span>
                  </p>
                  <b>{{companyBaseInfo.regLocation | nullValueConversion}}</b>
                </div>
              </div>
            </div>
          </div>

          <!-- 采购数据 -->
          <div class="title-info">
            <i></i>
            合制平台采购数据
          </div>
          <div class="stock-info-container" v-if="purchaseContractInfo">
            <div>
              <ul class="stock-info-center">
                <li><i class="pr-icon"></i></li>
                <li>合作过的城市</li>
                <li><b>{{purchaseContractInfo.cityCompanyCount || 0}}</b>个</li>
              </ul>
            </div>
            <div class="stock-info-border"></div>
            <div>
              <ul class="stock-info-center">
                <li><i class="pr-icon"></i></li>
                <li>合作过的项目</li>
                <li><b>{{purchaseContractInfo.projectCount || 0}}</b>个</li>
              </ul>
            </div>
            <div class="stock-info-border"></div>
            <div class="stock-info-border" style="width:0"></div>
            <div>
              <ul class="stock-info-center">
                <li><i class="pr-icon"></i></li>
                <li>合同</li>
                <li><b>{{purchaseContractInfo.contractCount || 0}}</b>个</li>
              </ul>
            </div>
            <div class="stock-info-border"></div>
            <div>
              <ul class="stock-info-center">
                <li><i class="pr-icon"></i></li>
                <li>所签合同总金额</li>
                <li><b>{{purchaseContractInfo.contractTotalAmount}}</b>元</li>
              </ul>
            </div>
          </div>

          <div class="border-bottom-dashede pr-icon"></div>

          <!-- 供应商履约评估基本信息 -->
          <div class="title-info">
            <i></i>
            供应商履约评估基本信息
          </div>
          <div class="un-assessinfo" v-if="!assessInfo.providerTotalScore && !assessInfo.projectContractList && !assessInfo.providerItemScoreList && !assessInfo.providerIsBlack">暂无履约评估信息</div>
          <div v-else>
            <div class="bace-info-container" v-if="assessInfo">
              <div>
                <div class="title">
                  履约评估 历史综合得分
                </div>
                <span class="code">
                  {{(assessInfo.providerTotalScore == null || assessInfo.providerTotalScore == -1 || assessInfo.providerIsBlack) ? '--' : assessInfo.providerTotalScore}}
                </span>
              </div>
              <div>
                <div class="title">
                  履约评估 所属名单
                </div>
                <span class="level" v-if="assessInfo.providerIsBlack">黑名单</span>
                <span class="level" v-else>{{filterLevel(assessInfo.providerTotalScore)}}</span>
              </div>
            </div>

            <!-- 评估信息 -->
            <div class="evaluate-info-container">
              <div class="special-title">
                <span>
                  <i></i>
                  合同评估信息
                  <i></i>
                </span>
              </div>
              <div class="applets-notice" v-if="assessInfo.providerContractCount > 8">
                该供应商合同较多, 以下展示的为近期合作合同, 如需查看所有合同评估详情, 请登录"履约评估"小程序。
              </div>
            </div>
            <div class="cooperative-city-info" v-for="(item, idx) in assessInfo.projectContractList || []" :key="idx">
              <div class="head-title">
                <span>
                  <i class="lf"></i>
                  合作城市公司: {{item.cityCompany | nullValueConversion}}
                  <i class="rf"></i>
                </span>
              </div>
              <CityInfoCompontent v-for="(proItem, pIdx) in item.projectList  || []" :key="pIdx" :data="proItem"></CityInfoCompontent>
            </div>
            <!-- 专业评分及排名 -->
            <div class="evaluate-info-container">
              <div class="special-title mt100 mb20">
                <span>
                  <i></i>
                  专业评分及排名
                  <i></i>
                </span>
              </div>
              <!--  -->
              <RatingAndRanking v-for="(proItem, pIdx) in assessInfo.providerItemScoreList  || []" :key="pIdx" :data="proItem"></RatingAndRanking>
            </div>
          </div>

          <div class="bg-f8f8f8">
            <!-- 舆情风险信息 -->
            <div class="title-info">
              <i></i>
              舆情风险信息
            </div>
            <div class="notice-info" v-if="queryRespData && queryRespData.riskInfo && (queryRespData.riskInfo.hasBreakFaith || queryRespData.riskInfo.hasEquityPledge)">
              <i class="pr-icon"></i>
              <p v-if="queryRespData.riskInfo.hasBreakFaith || queryRespData.riskInfo.hasEquityPledge">
                该供应商有
                <b v-if="queryRespData.riskInfo.hasBreakFaith">
                  <span class="red">失信信息</span>
                </b>
                <b v-if="queryRespData.riskInfo.hasBreakFaith && queryRespData.riskInfo.hasEquityPledge">
                  、
                </b>
                <b v-if="queryRespData.riskInfo.hasEquityPledge">
                  <span class="red">股权出质</span>信息
                </b>
              </p>。
            </div>

            <!-- 近三个月发生的风险信息 -->
            <div class="evaluate-info-container">
              <div class="special-title mt20">
                <span>
                  <i></i>
                  近三个月发生的风险信息
                  <i></i>
                </span>
              </div>
            </div>
            <div class="el-row-center">
              <div class="el-col-center">
                <i class="pr-icon"></i>
                <dl>
                  <dt>严重违法</dt>
                  <dd><span>{{riskTypeCountMapFilter('1')}}</span>条</dd>
                </dl>
              </div>
              <div class="el-col-center">
                <i class="pr-icon"></i>
                <dl>
                  <dt>失信信息</dt>
                  <dd><span>{{riskTypeCountMapFilter('3')}}</span>条</dd>
                </dl>
              </div>
              <div class="el-col-center">
                <i class="pr-icon"></i>
                <dl>
                  <dt>经营异常</dt>
                  <dd><span>{{riskTypeCountMapFilter('7')}}</span>条</dd>
                </dl>
              </div>
              <div class="el-col-center">
                <i class="pr-icon"></i>
                <dl>
                  <dt>股权出质</dt>
                  <dd><span>{{riskTypeCountMapFilter('9')}}</span>条</dd>
                </dl>
              </div>
            </div>
            <div class="el-row-center  el-row-center-last">
              <div class="el-col-center">
                <i class="pr-icon"></i>
                <dl>
                  <dt>动产抵押</dt>
                  <dd><span>{{riskTypeCountMapFilter('10')}}</span>条</dd>
                </dl>
              </div>
              <div class="el-col-center">
                <i class="pr-icon"></i>
                <dl>
                  <dt>被执行</dt>
                  <dd><span>{{riskTypeCountMapFilter('5')}}</span>条</dd>
                </dl>
              </div>
              <div class="el-col-center">
                <i class="pr-icon"></i>
                <dl>
                  <dt>行政处罚</dt>
                  <dd><span>{{riskTypeCountMapFilter('6')}}</span>条</dd>
                </dl>
              </div>
              <div class="el-col-center">
                <i class="pr-icon"></i>
                <dl>
                  <dt>法律诉讼</dt>
                  <dd><span>{{riskTypeCountMapFilter('8')}}</span>条</dd>
                </dl>
              </div>
            </div>
          </div>
          <div class="applets-icon-container">
            <img width="240" height="240" src="@/assets/images/activity/performanceReport/applets_icon.png">
            <p>
              如需查看详细评估信息及舆情信息, 请登录履约评估小程序查看。
            </p>
            <p>
              微信扫一扫, 立即登录。
            </p>
          </div>

          <div class="foot-container1">
            <img src="@/assets/images/activity/performanceReport/pr_foot_bg_yellow.png">
            <div class="disclaimer">
              <p>
                免责声明：本报告谨作决策参考，所涉全部信息及数据均来源于第三方数据平台，本公司不控制、编辑或修改信息内容，不保证此类信息及数据的真实性、完整性、及时性及准确性。使用本报告做出任何行为所产生之权利义务由行为人自行承担，与本公司无涉。
              </p>
            </div>
          </div>
          <i class="position-icon"></i>
          <i class="position-icon top-right"></i>
          <i class="position-icon bottom-left"></i>
          <i class="position-icon bottom-right"></i>
          <i class="position-icon head-icon"></i>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
    <div :class="['download-container', {active: fixedDownloadActive, b50: fixedDoloadBottom}]">
      <i @click="getPdf('#pdfContainer', `${companyBaseInfo.name || ''}${companyBaseInfo.name?' - ':''}履约情况及风险评估报告`, false)"></i>
    </div>
  </div>
</template>
<script>
import Header from "@/components/base/Header"
import Loading from '@/components/base/Loading'
import CityInfoCompontent from "@/components/activity/performanceReport/CityInfoCompontent"
import RatingAndRanking from "@/components/activity/performanceReport/RatingAndRanking"
import { InterfaceService } from "@/services/api"
export default {
  components: { Header, Loading, CityInfoCompontent, RatingAndRanking },
  computed: {
    formatContractTotalAmount() {
      return val => {
        //每隔三位小数加逗号
        const add_comma_toThousands = (num) => {
          num = (num || 0).toString()
          let result = ''
          while (num.length > 3) {
            result = ',' + num.slice(-3) + result
            num = num.slice(0, num.length - 3)
          }
          if (num) { result = num + result }
          return result;
        }

        return add_comma_toThousands(val)
      }
    },
    item2() {
      return [
        { itemName: '姓名', totalScore: '123' },
        { itemName: '姓名' },
        { itemName: '姓名' },
        { itemName: '姓名' },
        { itemName: '姓名' },
        { itemName: '姓名' },
      ]
    },
    item1() {
      return [{
        projectName: '你好歹啊',
        contractList: [{ contractName: 1, contractStatus: 2, totalScore: 3 }, { contractName: 1, contractStatus: 2, totalScore: 3 }]
      }, {
        projectName: '你好歹啊',
        contractList: [{ contractName: 1, contractStatus: 2, totalScore: 3 }]
      }]
    },
    // 企业工商信息
    companyBaseInfo() {
      let result = {}
      try {
        result = this.queryRespData && this.queryRespData.riskInfo && this.queryRespData.riskInfo.companyBaseInfo
      } catch (error) { console.warn(`companyBaseInfo: ${error}`) }
      return result || {}
    },
    // 合制平台采购数据
    purchaseContractInfo() {
      let result = {}
      try {
        result = this.queryRespData && this.queryRespData.purchaseContractInfo
      } catch (error) { console.warn(`purchaseContractInfo: ${error}`) }
      return result || {}
    },
    // 供应商专业排名集合 - 专业评分及排名
    providerItemScoreList() {
      let result = {}
      try {
        result = this.queryRespData && this.queryRespData.providerItemScoreList
      } catch (error) { console.warn(`purchaseContractInfo: ${error}`) }
      return result || {}
    },
    // 舆情风险信息
    riskTypeCountMap() {
      let result = []
      try {
        const item = this.queryRespData && this.queryRespData.riskInfo && this.queryRespData.riskInfo.riskTypeCountMap || {}
        for (let key in item) {
          result.push(item[key])
        }
      } catch (error) { console.warn(`purchaseContractInfo: ${error}`) }
      return result || []
    },
    riskTypeCountMapFilter() {
      return riskDataType => {
        return this.riskTypeCountMap && this.riskTypeCountMap.length && this.riskTypeCountMap.filter(f => f.riskDataType === riskDataType)[0].riskDetailCount || 0
      }
    },
    // 综合得分转换
    filterLevel() {
      // 动态综合评估分数90~100   白名单A级
      // 动态综合评估分数80~89    白名单B级
      // 动态综合评估分数40~79    白名单C级
      // 动态综合评估分数0~39     灰名单
      return val => {
        return val >= 90 ? '白名单A级' : val >= 80 ? '白名单B级' : val >= 40 ? '白名单C级' : (val != null && val >= 0) ? '灰名单' : '--'
      }
    },
    // 供应商履约评估基本信息
    assessInfo() {
      let result = {}
      try {
        result = this.queryRespData && this.queryRespData.assessInfo
      } catch (error) { console.warn(`purchaseContractInfo: ${error}`) }
      return result || {}
    },

    //时间戳转换方法    date:时间戳数字
    formatDate() {
      return (dateNum) => {
        const date = new Date(dateNum),
          YY = date.getFullYear() + ' -',
          MM = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + ' -',
          DD = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()),
          hh = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':',
          mm = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':',
          ss = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds())
        // + " " + hh + mm + ss
        return `${YY || ''} ${MM || ''} ${DD || ''}`;
      }
    }
  },
  data() {
    return {
      isLoading: false,
      corpId: '',
      queryRespData: {}, // 查询返回
      fixedDownloadActive: false,
      fixedDoloadBottom: false,
    }
  },
  mounted() {
    this.init()
    this.$nextTick(function () {
      window.addEventListener('scroll', this.onScroll)
    })
  },
  methods: {
    init() {
      this.getCorpId()
      this.getRiskAssessmentReport()
    },

    onScroll() {
      const scrolled = document.documentElement.scrollTop || document.body.scrollTop,
        clientHeight = document.documentElement.clientHeight || document.body.clientHeight,
        scrollHeight = document.documentElement.scrollHeight || document.body.scrollHeight

      // console.log(scrolled + clientHeight >= scrollHeight, scrolled + clientHeight , scrollHeight)
      if (scrolled + clientHeight >= scrollHeight - 180) {
        this.fixedDownloadActive = true
      } else {
        this.fixedDownloadActive = false
      }

      if (scrolled + clientHeight >= scrollHeight) {
        this.fixedDoloadBottom = true
      } else {
        this.fixedDoloadBottom = false
      }
    },

    go(path) {
      this.$router.push(path);
    },

    /**
     * 获取供应商ID
     */
    getCorpId() {
      this.corpId = this.$route.query.corpId || ''
    },

    /**
     * 查询供应商履约及风险评估报告
     */
    getRiskAssessmentReport() {
      // CORP2018062800000000000000001674
      const params = { supplierId: this.corpId || '' }

      InterfaceService.getRiskAssessmentReport(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.queryRespData = data.respData || {}
          console.log(this.queryRespData);
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },
  },
  destroyed() {
    window.removeEventListener('scroll', this.onScroll)
  }
}
</script>

<style lang="scss" scoped>
$yellowColor: #ffd64f;
.container {
  position: relative;
  &.pb42 {
    padding-bottom: 82px;
  }
  .pr-icon {
    width: 50px;
    height: 50px;
    display: inline-block;
    background-image: url(../../assets/images/activity/performanceReport/performance_report_icon.gif);
    background-repeat: no-repeat;
    background-position: -20px -10px;
    vertical-align: middle;
  }

  .download-container {
    $dfWidth: 80px;
    height: 90px;
    text-align: center;
    background: rgba(255, 214, 79, 0.9);
    position: fixed;
    width: calc(100% - #{$dfWidth});
    left: 40px;
    right: 0;
    bottom: 0;
    min-width: 1110px;
    transition: all 0.3s linear;
    box-shadow: 0px -1px 3px #ddd;
    &.active {
      left: 0;
      width: 100%;
      background: rgba(255, 214, 79, 1);
    }
    &.b50 {
      bottom: 50px;
    }
    i {
      background-image: url(../../assets/images/activity/performanceReport/download-icon.png);
      margin: auto;
      width: 630px;
      height: 100px;
      background-position: 100px 33px;
      cursor: pointer;
      display: block;
      background-repeat: no-repeat;
      background-size: 70%;
    }
  }
}
.performance-repote-container {
  background-position: center 20px;
  background-repeat: no-repeat;
  text-align: center;
  background-size: 80%;
  border: 34px solid $yellowColor;
  position: relative;
  .performance-repote-mid-center {
    border: 4px solid #fff;
    position: relative;
    border-bottom: 0;
  }
  .performance-repote-center {
    border: 10px solid $yellowColor;
    position: relative;
    .head-container {
      background: url(../../assets/images/activity/performanceReport/head_bg.png);
      border-top: 1px solid transparent;
      background-position: center center;
      overflow: hidden;
      background-repeat: no-repeat;
      height: 875px;
    }
  }
  .mt0 {
    margin-top: 0 !important;
  }

  .mt20 {
    margin-top: 20px;
  }
  .mt100 {
    margin-top: 60px;
  }
  .mb20 {
    margin-bottom: 20px;
  }
  .mt80 {
    margin-top: 80px;
  }
  .mt-30 {
    margin-top: -30px !important;
  }
  .bgred {
    background: red;
  }

  .bg-gary {
    background: #f9f9f9;
    // url(../../assets/images/activity/performanceReport/pic_bg2.png);
    background-position: center -50px;
    background-repeat: no-repeat;
    text-align: center;
    padding: 20px 0 40px;
    margin-top: 60px;
    background-size: 120%;

    .title-info {
      margin-top: 80px;
    }
    &.pb20 {
      padding-bottom: 20px;
    }
    & > p {
      font-size: 12px;
      color: #666;
      width: 593px;
      margin: auto;
      line-height: 19px;
    }
  }
  .un-assessinfo {
    margin-top: 60px;
    color: #888;
    font-size: 18px;
  }
  .bg-f8f8f8 {
    background: #f8f8f8;
    background-position: center -40px;
    background-repeat: no-repeat;
    text-align: center;
    padding: 10px 0 100px;
    margin-top: 60px;

    .title-info {
      margin-top: 80px;
    }
  }

  .applets-notice {
    font-size: 21px;
    color: #999;
    margin-top: 12px;
  }

  .logo-container {
    text-align: center;
    margin: 200px 0 70px;
    a {
      margin: auto;
    }
  }

  .report-information {
    color: #333333;
    text-align: center;
    h3 {
      font-size: 42px;
    }
    h1 {
      font-size: 64px;
      margin: 53px auto 33px;
      font-weight: bold;
    }
    .foot-information {
      font-size: 16px;
      margin-top: 110px;
      margin-bottom: 93px;
      span {
        &:first-child {
          border-right: 1px solid #333;
          padding-right: 20px;
          margin-right: 22px;
        }
      }
    }
  }

  .title-info {
    font-size: 36px;
    position: relative;
    padding-top: 20px;
    margin-top: 80px;
    margin-bottom: 20px;
    text-align: center;
    i {
      width: 188px;
      height: 8px;
      background: #ffd64f;
      position: absolute;
      left: 50%;
      top: 0;
      transform: translateX(-50%);
    }
  }

  .evaluate-info-container {
    margin: 60px auto;
    width: 1050px;
    .special-title {
      span {
        font-size: 32px;
        color: #333;
        position: relative;
        i {
          background-image: url(../../assets/images/activity/performanceReport/performance_report_icon.png);
          background-repeat: no-repeat;
          display: inline-block;
          width: 80px;
          height: 50px;
          position: absolute;
          &:nth-child(1) {
            background-position: -44px -497px;
            left: -100px;
          }
          &:nth-child(2) {
            background-position: -277px -492px;
            right: -90px;
          }
        }
      }
    }
  }

  .m-title {
    font-size: 33px;
  }

  .company-info-row {
    width: 1050px;
    margin: 50px auto;
    .company-info-border {
      width: 1px;
      background: #999;
      height: 54px;
      display: inline-block;
    }
    .company-info {
      display: inline-block;
      width: 32%;
      position: relative;
      &.w800 {
        width: 800px;
      }
      &:nth-child(3) {
        p .pr-icon {
          background-position: -152px -10px;
        }
      }
      &:nth-child(5) {
        p .pr-icon {
          background-position: -298px -10px;
        }
      }
      p {
        font-size: 22px;
        color: #666666;
        span {
          margin-left: 4px;
        }
      }
      b {
        font-size: 24px;
        margin-top: 12px;
        display: block;
      }
    }
    // 所在行业
    &.industry {
      div {
        p .pr-icon {
          background-position: -40px -103px;
          width: 30px;
        }
        span {
          margin-left: 0;
        }
      }
    }
    &.registered-address {
      div {
        p .pr-icon {
          background-position: -170px -103px;
          width: 30px;
        }
        span {
          margin-left: 0;
        }
      }
    }
  }
  .border-bottom-dashede {
    width: 1050px;
    background-position: 0px -790px;
    background-repeat: initial;
  }
  .company-number-row {
    width: 1050px;
    margin: 60px auto;
    & > div {
      text-align: center;
      display: inline-block;
      width: 33%;
      p {
        font-size: 22px;
        color: #666666;
      }
      b {
        font-size: 29px;
        margin-top: 12px;
        display: block;
      }
    }
  }

  // 采购数据
  .stock-info-container {
    padding-bottom: 80px;
    padding-top: 50px;
    width: 1050px;
    margin: auto;
    .stock-info-border {
      width: 2px;
      height: 154px;
      background: #999;
      display: inline-block;
      transform: scaleX(0.5);
    }
    & > div {
      display: inline-block;
      width: 24%;
      &:nth-child(3) {
        .pr-icon {
          background-position: -154px -203px;
        }
      }
      &:nth-child(6) {
        .pr-icon {
          background-position: -300px -203px;
        }
      }
      &:nth-child(8) {
        .pr-icon {
          background-position: -436px -203px;
        }
      }
      .pr-icon {
        background-position: -23px -203px;
      }
      .stock-info-center {
        font-size: 21px;
        li {
          margin-top: 16px;
          b {
            font-size: 28px;
            font-weight: bold;
          }
        }
      }
    }
  }

  // 基本信息
  .bace-info-container {
    margin: auto;
    margin-top: 60px;
    width: 420px;
    font-size: 19px;
    color: #666666;
    overflow: hidden;
    & > div {
      float: left;
      width: 49%;
    }
    .code {
      color: #333333;
      font-size: 124px;
      font-family: cursive;
    }
    .level {
      color: #333333;
      font-size: 32px;
      line-height: 130px;
    }
  }

  // 合作城市信息
  .cooperative-city-info {
    background: #ffd64f;
    padding: 40px 20px 20px;
    width: 1050px;
    margin: 24px auto;
    .head-title {
      span {
        font-size: 22px;
        color: #333;
        position: relative;
        i {
          height: 1px;
          background: #333;
          width: 140px;
          position: absolute;
          top: 14px;
          &:nth-child(1) {
            left: -150px;
          }
          &:nth-child(2) {
            right: -150px;
          }
        }
      }
    }
  }
  // 舆情信息
  .notice-info {
    font-size: 30px;
    margin-top: 70px;
    .pr-icon {
      background-position: -20px -333px;
      vertical-align: middle;
    }
    p {
      display: inline-block;
    }
  }
  // 风险信息
  .el-row-center {
    width: 1050px;
    margin: auto;
    margin-top: 50px;
    overflow: hidden;
    .el-col-center {
      display: inline-block;
      width: 24%;
      font-size: 24px;
      .pr-icon {
        vertical-align: top;
      }

      &:nth-child(1) {
        .pr-icon {
          background-position: -23px -578px;
        }
      }
      &:nth-child(2) {
        .pr-icon {
          background-position: -310px -578px;
        }
      }
      &:nth-child(3) {
        .pr-icon {
          background-position: -598px -578px;
        }
      }
      &:nth-child(4) {
        .pr-icon {
          background-position: -886px -578px;
        }
      }
    }
    dl {
      margin-top: 13px;
      margin-left: 14px;
      text-align: left;
      display: inline-block;
      dt {
        margin-bottom: 20px;
      }
    }
    span {
      font-size: 36px;
      font-weight: bold;
    }

    &.el-row-center-last {
      margin-top: 80px;
      .el-col-center {
        &:nth-child(1) {
          .pr-icon {
            background-position: -23px -666px;
          }
        }
        &:nth-child(2) {
          .pr-icon {
            background-position: -310px -666px;
          }
        }
        &:nth-child(3) {
          .pr-icon {
            background-position: -599px -666px;
          }
        }
        &:nth-child(4) {
          .pr-icon {
            background-position: -886px -669px;
          }
        }
      }
    }
  }
  // 小程序ICON
  .applets-icon-container {
    margin-top: 60px;
    margin-bottom: 60px;
    img {
      display: block;
      margin: auto auto 50px;
      width: 240px;
    }
    p {
      margin-top: 20px;
      font-size: 18px;
    }
  }
  // 小程序
  .foot-container {
    background: url(../../assets/images/activity/performanceReport/pr_foot_bg.png)
      center center;
    height: 185px;
    background-size: 100%;
    width: 100%;
    background-repeat: no-repeat;
  }
  .foot-container1 {
    img {
      width: 100%;
      margin-bottom: -3px;
    }
    .disclaimer {
      position: absolute;
      margin-top: -46px;
      width: 560px;
      left: 50%;
      margin-left: -250px;
      font-size: 12px;
      line-height: 16px;
    }
  }

  // 边框图片
  .position-icon {
    width: 410px;
    height: 410px;
    background-image: url(../../assets/images/activity/performanceReport/position_top_left_icon.png);
    background-repeat: no-repeat;
    background-position: 0 0;
    vertical-align: middle;
    position: absolute;
    left: -40px;
    top: -40px;
    z-index: 1;

    &.top-right {
      right: -40px;
      left: auto;
      background-position: -17px 0px;
      background-image: url(../../assets/images/activity/performanceReport/position_top_right_icon.png);
    }
    &.bottom-left {
      top: auto;
      bottom: -40px;
      background-position: 0 0;
      background-image: url(../../assets/images/activity/performanceReport/position_bottom_left_icon.png);
    }
    &.bottom-right {
      top: auto;
      left: auto;
      bottom: -40px;
      right: -40px;
      background-position: -17px 0px;
      background-image: url(../../assets/images/activity/performanceReport/position_bottom_right_icon.png);
    }

    &.head-icon {
      left: 50%;
      margin-left: -300px;
      background-position: -613px 0px;
      width: 600px;
      background-image: url(../../assets/images/activity/performanceReport/position_icon.png);
    }
  }
}
</style>
