
<template>
  <div class="index-wrap">
    <Header></Header>
    <div class="roast-banner">
      <img :src="imgAttach['roast-top-img']" />
    </div>

    <div
      class="roast-container"
      :style="{
        paddingBottom:
          isActivityState === 0 ? (isInputFocus ? '250px' : '150px') : '0'
      }"
    >
      <div
        class="scroll-container"
        :style="{ right: fixedIconRight }"
        v-if="showScrollIcon && isActivityState === 0 && false"
        @click="scrollBottom"
      >
        <i @click.stop.prevent="closeScrollBottom" title="关闭"></i>
      </div>
      <img :src="imgAttach['roast-img-1']" />
      <img :src="imgAttach['roast-img-2']" />
      <img :src="imgAttach['roast-img-3']" v-if="isActivityState === 2" />
      <img :src="imgAttach['roast-img-4']" />
      <img :src="imgAttach['roast-img-5']" />
      <div
        :class="['submit-roast-container', { inputFocus: isInputFocus }]"
        v-if="isActivityState === 0"
      >
        <div class="submit-roast-center">
          <el-input
            type="textarea"
            placeholder="请开始你的吐槽"
            v-model="roastVlaue"
            maxlength="500"
            @focus="handleInputFocus"
            @blur="handleInputBlur"
          >
          </el-input>
          <el-button @click="handleSubmitRoast">提交吐槽</el-button>
          <!--<div class="count">-->
            <!--累计吐槽(条)-->
            <!--<span>{{ totalCnt }}</span>-->
          <!--</div>-->
        </div>
      </div>
    </div>
    <!-- 弹窗 -->
    <el-dialog
      class="dialog dialog-drafts"
      title="请留下您的联系方式"
      :append-to-body="true"
      :lock-scroll="true"
      :visible.sync="draftsDialogVisible"
      width="50%"
      center
      :close-on-click-modal="true"
    >
      <div class="drafts-list">
        <p>
          我们将根据手机号颁发奖品，若放弃填写或填写错误将无法领奖，请注意。
        </p>
        <dl>
          <dt>请填写您的领奖手机号</dt>
          <dd>
            <el-input
              v-model="mobilePhoneValue"
              @blur="verificationPhoneNumber"
              onkeyup="if(this.value.length==1){this.value=this.value.replace(/[^1-9]/g,'')}else{this.value=this.value.replace(/\D/g,'')}"
              clearable
            ></el-input>
            <div class="error-msg red" v-if="mobilePhoneErrorMsg.length">
              {{ mobilePhoneErrorMsg }}
            </div>
          </dd>
        </dl>
      </div>

      <div slot="footer" class="dialog-footer">
        <el-button
          type="primary"
          size="small"
          style="width: 100px"
          @click="handlePhoneNumber"
          >确认手机号</el-button
        >
        <el-button size="small" style="width: 100px" @click="handleCancel"
          >放弃填写</el-button
        >
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Header from "@/components/base/Header";
import Loading from '@/components/base/Loading'
export default {
  components: { Header, Loading },
  data() {
    return {
      isActivityState: 0, // 活动状态 0 开始 , 1 进行中 , 2 结束
      roastVlaue: "", // 吐槽内容
      draftsDialogVisible: false, // 是否显示弹窗
      mobilePhoneValue: "", // 手机号码
      mobilePhoneErrorMsg: "", // 手机错误提示
      totalCnt: '0', // 吐槽数量
      isLoading: false,
      imgAttach: {},
      showScrollIcon: true, // 是否展示滚动到吐槽图标
      fixedIconRight: '150px',
      isInputFocus: false, // 输入框是否获得焦点
      inputTimer: null
    };
  },
  mounted() {
    this.init()
    this.addMakeComplaints(true);
    this.setFixedIconRight();
  },
  methods: {
    init() {
      InterfaceService.activityOssAttach(data => {

        if (typeof data === "string") {
          this.imgAttach = eval("(" + data + ")");
        } else if (typeof data === "object") {
          this.imgAttach = data
        }
        // 判断活动状态
        this.isActivityState = Number(this.imgAttach.status)
      });
    },
    handleInputFocus() {
      this.isInputFocus = true;
      clearTimeout(this.inputTimer);
    },
    handleInputBlur() {
      this.inputTimer = setTimeout(e => {
        this.isInputFocus = false;
      }, 50)
    },
    setFixedIconRight() {
      if (document.body.clientWidth < 1558) {
        this.fixedIconRight = '44px';
      }
    },
    // 滚动到底部
    scrollBottom() {
      window.scrollTo(0, document.body.clientHeight);
    },
    closeScrollBottom() {
      this.showScrollIcon = false;
    },
    // 提交吐槽
    handleSubmitRoast() {
      // 未输入内容
      if (this.roastVlaue.length) {
        // 是否登录 1登录 0未登录
        const userLoginInfo = this.$getRootLocalStorage("user") ? JSON.parse(this.$getRootLocalStorage("user")) : "",
          isLogin = (userLoginInfo && userLoginInfo.isLogin) || "0";

        // 未登录
        if (isLogin === "0") {
          this.draftsDialogVisible = true;
        } else {
          this.addMakeComplaints();
        }
      } else {
        this.$message({
          message: "请输入您的建议",
          type: "warning"
        });
      }
    },
    // 提交手机号
    handlePhoneNumber() {
      if (this.verificationPhoneNumber()) {
        this.addMakeComplaints();
        this.handleCloseNotice();
      }
    },
    // 放弃填写
    handleCancel() {
      // 放弃填写清空手机号
      this.mobilePhoneValue = '';
      this.addMakeComplaints();
      this.handleCloseNotice();
    },
    // 关闭弹窗
    handleCloseNotice() {
      this.mobilePhoneValue = "";
      this.draftsDialogVisible = false;
      this.mobilePhoneErrorMsg = "" // 手机错误提示
    },
    // 验证手机号
    verificationPhoneNumber() {
      const reg = this.$commonExpression("mobile"); // /^[1][0-9][0-9]{9}$/;
      let state = true;

      if (!reg.test(this.mobilePhoneValue)) {
        this.mobilePhoneErrorMsg = "请输入正确的手机号";
        state = false;
      } else {
        this.mobilePhoneErrorMsg = "";
      }
      return state;
    },
    // 提交数据到接口 firstState: true 首次加载执行查询 , false 提交数据
    addMakeComplaints(firstState = false) {
      const params = {
        mobile: this.mobilePhoneValue || "",
        content: this.roastVlaue || ""
      };

      InterfaceService.addMakeComplaints(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.totalCnt = data.respData.totalCnt.toString();
          // 首次查询 不显示提示信息
          if (!firstState) {
            this.$message({
              message: `提交${data.respData.respMsg || ''}`,
              type: "success"
            });
          }
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      });
      this.roastVlaue = "";
    }

  }
};
</script>

<style lang="scss" scoped>
@keyframes shake {
  0% {
    bottom: 200px;
  }
  25% {
    bottom: 205px;
  }
  50% {
    bottom: 200px;
  }
  75% {
    bottom: 195px;
  }
  100% {
    bottom: 200px;
  }
}
@-webkit-keyframes shake {
  0% {
    bottom: 200px;
  }
  25% {
    bottom: 210px;
  }
  50% {
    bottom: 200px;
  }
  75% {
    bottom: 190px;
  }
  100% {
    bottom: 200px;
  }
}
.roast-banner {
  overflow: hidden;
  position: relative;
  height: 550px;
  img {
    position: absolute;
    height: 100%;
    top: 0;
    left: 50%;
    transform: translate(-50%, 0);
    -webkit-transform: translate(-50%, 0);
    -o-transform: translate(-50%, 0);
    -moz-transform: translate(-50%, 0);
  }
}
.roast-container {
  background: #eae7f8;
  text-align: center;
  transition: all 0.3s linear;
  .scroll-container {
    position: fixed;
    cursor: pointer;
    bottom: 200px;
    right: 150px;
    width: 120px;
    height: 120px;
    background: url(../../assets/images/activity/roast/roast_hover.png)
      no-repeat top center/100% 100%;
    animation: shake 1s infinite;
    animation-timing-function: linear;
    i {
      position: absolute;
      width: 20px;
      height: 20px;
      right: 0;
      top: 0;
    }
  }
  img {
    width: 1190px;
    margin: 0 auto;
    display: block;
  }

  .submit-roast-container {
    background-color: #222222;
    height: 150px;
    display: flex;
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    transition: all 0.3s linear;
    overflow: hidden;
    &.inputFocus {
      height: 300px;
      .submit-roast-center {
        /deep/ .el-textarea {
          .el-textarea__inner {
            height: 250px !important;
          }
        }
      }
    }
    .submit-roast-center {
      display: flex;
      width: 1090px;
      margin: 0 auto;
      align-items: center;
      /deep/ .el-textarea {
        width: auto;
        .el-textarea__inner {
          resize: none;
          width: 664px;
          height: 98px !important;
          transition: all 0.3s linear;
        }
      }
      .el-button--default {
        margin-left: 32px;
        background: #2b2834;
        color: #fff;
        border: 1px solid #fff;
        outline: none;
        height: 58px;
        width: 195px;
        border-radius: 4px;
        font-size: 18px;
        margin-right: 30px;
      }
      .count {
        border-left: 2px solid #fff;
        color: #fff;
        font-size: 18px;
        height: 22px;
        padding-left: 12px;
        position: relative;
        width: 192px;
        span {
          font-size: 40px;
          position: absolute;
          top: -11px;
          margin-left: 14px;
        }
      }
    }
  }
}
.dialog-drafts {
  .drafts-list {
    color: #444;
    font-size: 12px;
    font-weight: bold;
    text-align: center;
    margin-bottom: 22px;
    .error-msg {
      position: absolute;
      margin-left: 22px;
      margin-top: 2px;
    }
    p {
      margin: 20px 0 30px;
    }
    dl {
      display: flex;
      width: 380px;
      margin: auto;
      align-items: center;
      /deep/ .el-input__inner {
        width: 238px;
        height: 34px;
        margin-left: 22px;
      }
    }
  }
}
</style>
