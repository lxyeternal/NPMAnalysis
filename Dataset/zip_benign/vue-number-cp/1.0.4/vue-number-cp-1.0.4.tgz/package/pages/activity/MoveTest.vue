<template>
  <div class="moveSignatureMainContainer">
    <div id="moveSignatureMain">
      <div class="tuo tuo1" @mousedown="move">
        <img src="@/assets/images/activity/performanceReport/applets_icon.png" width="200" height="200">
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      relativelyTop: 0, // 相对 展示 div  top
      relativelyLeft: 0,
      relativelyRight: 0,
      relativelyBottom: 0,
      isExceed: false, // 是否不再显示位置之类
    };
  },

  mounted() {
    this.initAddEvent()
  },
  methods: {
    initAddEvent() {
      const markMoveCloses = document.querySelectorAll('.markMoveClose')

      for (let i = 0, len = markMoveCloses.length; i < len; i++) {
        markMoveCloses[i].onclick = () => {
          markMoveCloses[i].offsetParent.remove()
        }
      }
    },
    move(e) {
      const __this = this,
        appendDom = document.getElementById("moveSignatureMain"),
        imgUrl = require('@/assets/images/activity/performanceReport/applets_icon.png'),
        odiv = e.target, //获取目标元素
        oMark = document.createElement("div") //创建要拖拽的元素

      let disX, disY, left, top

      // 布局赋给新的元素
      oMark.style.width = odiv.offsetWidth + "px";
      oMark.style.height = odiv.offsetHeight + "px";
      oMark.style.left = odiv.offsetLeft + "px";
      oMark.style.right = odiv.offsetTop + "px";
      // 类名
      oMark.className = "markMove";
      // 内容
      oMark.innerHTML = `<img src="${imgUrl}" width="200" height="200"><i title="关闭" class="markMoveClose">×</i>`;
      // append到对应容器内
      appendDom.appendChild(oMark);

      disX = e.clientX - oMark.offsetLeft,
        disY = e.clientY - oMark.offsetTop;
      // 鼠标移动
      document.onmousemove = e => {
        left = e.clientX - disX;
        top = e.clientY - disY;
        oMark.style.left = left + "px";
        oMark.style.top = top + "px";

        this.relativelyTop = top
        this.relativelyLeft = left
        this.relativelyRight = appendDom.offsetWidth - (left + odiv.offsetWidth)
        this.relativelyBottom = appendDom.offsetHeight - (top + odiv.offsetHeight)

        this.isExceed = `${this.relativelyTop}${this.relativelyLeft}${this.relativelyRight}${this.relativelyBottom}`.includes('-')
        console.log(this.relativelyTop, this.relativelyLeft, this.relativelyRight, this.relativelyBottom, appendDom.offsetWidth, '---1');
      };
      // 鼠标抬开
      document.onmouseup = e => {
        // document.onmousemove = null;
        // document.onmouseup = null;

        console.log(left, top, '---2');
        oMark.onmousedown = this.moveTo;
        __this.initAddEvent()
      };
    },
    moveTo(e) {
      const odiv = e.target, //获取目标元素
        //算出鼠标相对元素的位置
        disX = e.clientX - odiv.offsetLeft,
        disY = e.clientY - odiv.offsetTop
      let left, top

      document.onmousemove = e => {
        left = e.clientX - disX;
        top = e.clientY - disY;
        console.log(left, top, '---3');

        //移动当前元素
        odiv.style.left = left + "px";
        odiv.style.top = top + "px";
      };
      document.onmouseup = e => {
        console.log(left, top, '---4');
        document.onmousemove = null;
        document.onmouseup = null;
      };
    }
  }
};
</script>

<style lang="scss">
.moveSignatureMainContainer {
  width: 1100px;
  height: 600px;
  position: relative;
  margin: 100px auto;
  border: 1px solid red;
  .markMove {
    position: absolute;
    img {
      border-radius: 50%;
    }
    i {
      position: absolute;
      right: 0;
      top: 0;
      font-size: 22px;
      border: 1px solid #333;
      border-radius: 50%;
      height: 20px;
      width: 20px;
      text-align: center;
      line-height: 18px;
      cursor: pointer;
    }
  }
  .tuo {
    width: 50px;
    height: 50px;
    text-align: center;
    line-height: 50px;
    background: pink;
  }
  .tuo1 {
    position: absolute;
    left: 10px;
    top: 10px;
  }
}
.left {
  width: 500px;
  height: 500px;
  float: left;
  border: 1px solid;
}
.right {
  width: 500px;
  height: 500px;
  float: left;
  border: 1px solid;
}
</style>