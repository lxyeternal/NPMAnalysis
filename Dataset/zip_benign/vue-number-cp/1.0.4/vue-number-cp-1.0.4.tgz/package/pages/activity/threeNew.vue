
<template>
  <div class="index-wrap">
    <Header></Header>
    <ul class="three-new-container">
      <li>
        <img src="@/assets/images/activity/threeNew/banner-three-new_01.jpg">
      </li>
      <li>
        <div class="center">
          <a @click="go(spuIdList[0])">
            <span>
              软瓷-柔石洞石系列
            </span>
          </a>
          <a @click="go(spuIdList[1])">
            <span>
              软瓷-柔石仿古系列
            </span>
          </a>
        </div>
        <img src="@/assets/images/activity/threeNew/banner-three-new_01_1.jpg">
      </li>
      <li>
        <div class="center">
          <i class="product-hover product-hover-1" @click="go(spuIdList[2])"></i>
          <i class="product-hover product-hover-2" @click="go(spuIdList[3])"></i>
        </div>
        <img src="@/assets/images/activity/threeNew/banner-three-new_01_2.jpg">
      </li>
      <li>
        <div class="center">
          <a @click="go(spuIdList[4], '60A')">
            <span>中央吸油烟机60A</span>
          </a>
          <a @click="go(spuIdList[4], '60B')">
            <span>中央吸油烟机60B</span>
          </a>

        </div>
        <img src="@/assets/images/activity/threeNew/banner-three-new_02.jpg">
      </li>
      <li>
        <div class="center">
          <div class="video-container">
            <video id="video" width="666" height="376" :poster="videoList && videoList[1]" controls muted loop>
              <source type="video/mp4">
              您的浏览器不支持 HTML5 video 标签。
            </video>
          </div>
        </div>
        <img src="@/assets/images/activity/threeNew/banner-three-new_03.jpg">
      </li>
      <li>
        <div class="center">
          <a @click="go(spuIdList[5])">
            <span>
              印象拼接 呼吸砖
            </span>
          </a>
          <a @click="go(spuIdList[6])">
            <span>
              陶文拼接 呼吸砖
            </span>
          </a>
          <a @click="go(spuIdList[7])">
            <span>
              竹节纹 呼吸砖
            </span>
          </a>
        </div>
        <img src="@/assets/images/activity/threeNew/banner-three-new_04.jpg">
      </li>
    </ul>
    <Footer :bgColor="'#373737'"></Footer>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import Header from "@/components/base/Header";
import Loading from '@/components/base/Loading'
import Footer from '@/components/base/Footer'
import { InterfaceService } from "@/services/api";
export default {
  components: { Header, Loading, Footer },
  data() {
    return {
      isLoading: false,
      spuIdList: [],
      videoList: []
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.init()
      setTimeout(e => { window.addEventListener('scroll', this.onScroll) }, 1000)
    })
  },
  methods: {
    init() {
      this.getData()

      let scrollTop = 0

      try {
        scrollTop = Number(this.$route.query.scrollTop)
      } catch (error) { }
      window.scrollTo(0, scrollTop)
    },

    getData() {
      InterfaceService.activityOssThreeNew(data => {
        let dataItem = []
        if (typeof data === "string") {
          dataItem = eval("(" + data + ")");
        } else if (typeof data === "object") {
          dataItem = data
        }
        if (!dataItem[0]) return

        this.spuIdList = dataItem[0].SPU_ID && dataItem[0].SPU_ID.split(',') || []
        this.videoList = dataItem[0].videoUrl && dataItem[0].videoUrl.split(',') || []
        video.src = this.videoList[0] || ''
      });
    },

    onScroll() {
      let scrolled = document.documentElement.scrollTop || document.body.scrollTop

      if (scrolled >= 2400  && scrolled <= 3300) {
        video.play()
      } else {
        video.pause()
      }
    },

    go(params1, params2) {
      if (!params1) {
        return
      }
      const routeData = this.$router.resolve({
        path: "/productDetail",
        query: {
          id: params1,
          model: params2 || ''
        }
      });
      window.open(routeData.href, "_blank");
    }
  },

  destroyed() {
    window.removeEventListener('scroll', this.onScroll)
  }
};
</script>

<style lang="scss" scoped>
.three-new-container {
  li {
    position: relative;
    height: 809px;

    .center {
      width: 1190px;
      margin: 0 auto;
      height: 100%;
      position: relative;
      z-index: 1;
      .video-container {
        position: absolute;
        right: 16px;
        top: 14px;
        z-index: 1;
        width: 666px;
        height: 809px;
        video {
          outline: none;
        }
      }
      .product-hover {
        position: absolute;
        background-image: url(../../assets/images/activity/threeNew/product_hover_1.png);
        opacity: 0;
        width: 992px;
        height: 282px;
        top: 29px;
        left: 212px;
        opacity: 0;
        transition: all 0.3s linear;
        background-position: 0px 62px;
        background-repeat: no-repeat;
        cursor: pointer;
        &:hover {
          opacity: 1;

          &.product-hover-2 {
            &::after {
              background: #ffb400;
              box-shadow: 0px 0px 3px #fff;
            }
          }
        }
        &.product-hover-2 {
          background-image: url(../../assets/images/activity/threeNew/product_hover_2.png);
          background-repeat: no-repeat;
          width: 1165px;
          height: 410px;
          background-position: 501px 66px;
          top: 366px;
          left: 31px;
          &::after {
            content: "";
            position: absolute;
            height: 4px;
            background: transparent;
            width: 245px;
            top: 413px;
            left: 419px;
            box-shadow: 0px 0px 3px transparent;
            transition: all 0.3s linear;
          }
        }
      }
    }

    &:nth-child(2) {
      height: 669px;
      a {
        width: 251px;
        height: 337px;
        position: absolute;
        top: 242px;
        left: 426px;
        background: rgba(255, 255, 255, 0.1);
        border: 5px solid #fff;
        transition: all 0.3s linear;
        &:last-child {
          left: 827px;
          top: 243px;
        }
        &:hover {
          border-color: #ffb400;
          box-shadow: 0px 1px 10px #ffb404;
          border-radius: 2px;
          span {
            box-shadow: 0px 1px 10px #ffb404;
            text-shadow: 0px 1px 4px #ffb404;
            border-color: #ffb400;
            color: #ffb400;
          }
        }
        span {
          position: absolute;
          height: 55px;
          line-height: 53px;
          top: -89px;
          left: -5px;
          border: 2px solid #fff;
          transition: all 0.3s linear;
          width: 251px;
          text-align: center;
          font-size: 16px;
          color: #fff;
        }
      }
    }

    &:nth-child(3) {
      height: 825px;
    }
    &:nth-child(4) {
      height: 598px;
      .center {
        a {
          width: 220px;
          height: 222px;
          position: absolute;
          bottom: 114px;
          left: 176px;
          background: rgba(255, 255, 255, 0.1);
          border: 4px solid transparent;
          border-radius: 2px;
          transition: all 0.3s linear;
          &:last-child {
            left: 922px;
            bottom: 54px;

            span {
              left: 50px;
              bottom: -38px;
            }
          }

          &:hover {
            border-color: #c9d7fa;
            box-shadow: 0px 1px 10px #c9d7fa;
            span {
              color: #c9d7fa;
              border-color: #c9d7fa;
              text-shadow: 0px 1px 5px #c9d7fa;
              border-width: 2px;
            }
          }

          span {
            width: 118px;
            height: 24px;
            color: #fefdf9;
            position: absolute;
            bottom: -37px;
            left: 46px;
            font-size: 15px;
            text-align: center;
            border-bottom: 2px solid transparent;
            transition: all 0.3s linear;
          }
        }
      }
    }

    &:nth-child(5) {
      height: 867px;
    }
    &:nth-child(6) {
      height: 916px;
      a {
        width: 251px;
        height: 337px;
        position: absolute;
        top: 258px;
        left: 354px;
        background: rgba(255, 255, 255, 0.1);
        border: 5px solid #fff;
        transition: all 0.3s linear;
        &:first-child {
          left: 2px;
        }
        &:last-child {
          left: 784px;
          top: 392px;
        }
        &:hover {
          border-color: #ffb400;
          box-shadow: 0px 1px 10px #ffb404;
          border-radius: 2px;
          span {
            box-shadow: 0px 1px 10px #ffb404;
            text-shadow: 0px 1px 4px #ffb404;
            border-color: #ffb400;
            color: #ffb400;
          }
        }
        span {
          position: absolute;
          height: 55px;
          line-height: 53px;
          top: -89px;
          left: -5px;
          border: 2px solid #fff;
          transition: all 0.3s linear;
          width: 251px;
          text-align: center;
          font-size: 16px;
          color: #fff;
        }
      }
    }
    img {
      position: absolute;
      top: 0;
      left: 50%;
      height: 100%;
      transform: translate(-50%, 0);
      -webkit-transform: translate(-50%, 0);
      -o-transform: translate(-50%, 0);
      -moz-transform: translate(-50%, 0);
    }
  }
}
</style>
