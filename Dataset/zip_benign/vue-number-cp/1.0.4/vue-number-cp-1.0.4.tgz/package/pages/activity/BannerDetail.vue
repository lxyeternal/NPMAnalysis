
<template>
  <div class="pictureContainer">
    <Header></Header>
    <div v-if="typeof $route.query.url === 'string'">
      <img
        :style="{ marginLeft: mlLeftWidth }"
        :src="$route.query.url || ''"
        alt=""
      />
    </div>
    <div v-else>
      <img
        :style="{ marginLeft: mlLeftWidth }"
        :src="item"
        v-for="(item, index) in $route.query.url"
        :key="index"
      />
    </div>
  </div>
</template>

<script>
import Header from "@/components/base/Header";
export default {
  components: { Header },
  data() {
    return {
      mlLeftWidth: '0px'
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.calcImgMLWidth()
      window.onresize = () => this.calcImgMLWidth()
    },

    /**
     * 计算图片 marginLeft
     */
    calcImgMLWidth() {
      const imgWidth = 1200,
        browserWidth = document.body.clientWidth || 0
      if (browserWidth >= 1920) {
        this.mlLeftWidth = '-0px'
        return
      }
      if (browserWidth >= 1200) {
        this.mlLeftWidth = `${-355 + (browserWidth - imgWidth) / 2}px`
      } else {
        this.mlLeftWidth = '-355px'
      }
    }
  }
}
</script>
<style lang="scss" scoped>
.pictureContainer {
  text-align: center;
  overflow: hidden;
  img {
    display: block;
  }
}
</style>
