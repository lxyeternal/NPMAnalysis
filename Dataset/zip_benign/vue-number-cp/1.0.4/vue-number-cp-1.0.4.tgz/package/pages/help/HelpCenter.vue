<template>
  <div class="help-wrap">
    <Header :is-white-bg="true"></Header>
    <SearchBar :is-red-bg="true" :search-type="searchBarType" @listenIsShowFooter="listenIsShowFooter()"></SearchBar>
    <LightColorMenuBar :current-router="currentRouter"></LightColorMenuBar>
    <div class="account-info-inner" id="account-info-inner">
      <div class="contain inner-container">
        <div class="menu">
          <el-menu :default-active="menuIndex" @open="handleOpen" @close="handleClose" background-color="#f8f8f8" text-color="#4f525a" style="padding-bottom:140px;border-right: none;">
            <el-submenu index="5" v-if="isLogin == '1'">
              <template slot="title">
                <i class="icon-help vendor" :class="{purchasers: role == 'B'}"></i>
                <span>操作资料</span>
              </template>
              <el-menu-item-group>
                <el-menu-item index="5-1" @click="showHelp('5-1')">
                  操作文档下载
                </el-menu-item>
              </el-menu-item-group>
            </el-submenu>
          </el-menu>
        </div>

        <div class="rightList" ref="content">
          <!-- download -->
          <div v-if="this.showMessage == '5-1' && isLogin == '1'">
            <div class="title">操作文档下载</div>
            <ul>
              <!--<li class="download f14">采购商系统使用说明.pdf<span >下载</span></li>-->
              <li class="download f14" v-for="(item,index) in attachList" :key="index">{{item.attachName}}<span @click="download(item,index)">下载</span></li>
              <!-- <li class="download f14"><span class="blue ml0" v-if="privilegeDetection()" @click="goConfluence('2')">前往合制知识库查看更多资料></span></li> -->
            </ul>
            <!-- 1 -->
          </div>
        </div>
      </div>
    </div>
    <Footer></Footer>
    <Loading :is-loading="isLoading"></Loading>
    <OpenDraftBoxList v-if="showDraftBoxList" v-model="showDraftBoxList" @showSelectSupplier="showSelectSupplier"></OpenDraftBoxList>
    <SelectSupplier v-if="isShowSelectSupplier" v-model="isShowSelectSupplier"></SelectSupplier>
  </div>
</template>
<script>
import { mapActions, mapState } from "vuex";
import SearchBar from "@/components/SearchBar";
import Header from "@/components/base/Header";
import LightColorMenuBar from "@/components/LightColorMenuBar";
import Footer from "@/components/base/Footer";
import { InterfaceService } from "@/services/api";
import download from "@/utils/download";
import Loading from "@/components/base/Loading";
import accountMixin from "@/mixins/account";
import jumpConfluence from "@/mixins/jumpConfluence";
import OpenDraftBoxList from '@/components/order/OpenDraftBoxList';
import SelectSupplier from '@/components/order/SelectSupplier';
export default {
  mixins: [jumpConfluence, accountMixin],
  components: {
    SearchBar,
    Footer,
    Header,
    LightColorMenuBar,
    Loading,
    OpenDraftBoxList,
    SelectSupplier
  },
  data() {
    return {
      searchBarType: 1, //搜索框组件的显示类型
      currentRouter: "helpCenter",
      showMessage: '5-1',
      menuIndex: '5-1',
      position: '',
      attachList: [],
      isLoading: false,
      showDraftBoxList: false,
      isShowSelectSupplier: false,
    }
  },
  computed: {
    isLogin() {
      return this.$store.state.isLogin
    },
  },
  methods: {
    showSelectSupplier() {
      this.isShowSelectSupplier = true
    },
    listenIsShowFooter() {
      this.showDraftBoxList = true
    },
    async goConfluence(id) {
      this.isLoading = true
      try {
        await this.toConfluence(id)
      } catch (error) {
        console.log(error, 'ee---');
        this.$message.error('系统繁忙, 请稍后重试')
      }
      this.isLoading = false
    },
    handleOpen(key, keyPath) {

    },
    handleClose(key, keyPath) {

    },
    showHelp(type) {
      this.showMessage = type;
      console.log(this.showMessage)
      if (type == "5-1") {
        this.getOperationManual();
      }
    },
    getOperationManual() {
      InterfaceService.getOperationManual(
        {
          // 下载类型（0：大家采；1：大基建）
          downLoadType: this.bigInfrastructure ? '1' : '0'
        },
        data => {
          console.log(data.respData);
          if (data.respCode === "0000") {
            console.log(data.respData)
            this.attachList = data.respData.attachList;
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    download(item, index) {
      // this.isLoading = true;
      // const x = new XMLHttpRequest();
      // x.open("GET", item.attachUrl, true);
      // x.responseType = "blob";
      // x.onload = e => {
      //   download(x.response, item.attachName, x.response.type);
      // };
      // x.send();
      // this.$message.success("已下载");
      // this.isLoading = false;
      this.handleDownload(item.attachUrl, item.attachName)
    },
    handleDownload(url, name) {
      this.isLoading = true
      let attach = []
      attach.push({
        url: url,
        name: name
      });
      this.$download(attach).then(res => {
        this.$message.success("已下载");
        this.isLoading = false
      }).catch(res => {
        this.$message.error("下载失败");
        this.isLoading = false
      })
    },
  },
  watch: {},
  created() {

  },
  mounted() {
    console.log(this.isLogin);
    this.menuIndex = this.$route.query.index || this.menuIndex
    this.showMessage = this.menuIndex;
    this.position = this.$route.query.position || ''
    if (this.position) {
      // setTimeout(() => {
      //   window.scrollTo(0, $("#" + this.menuIndex + '-' + this.position).offset().top);
      // }, 400)
    }
    this.isLogin == '1' && this.getOperationManual()
  }
}
</script>

<style scoped lang="scss">
.blue {
  cursor: pointer;
}
.ml0 {
  margin-left: 0px !important;
}
.mt20 {
  margin-top: 20px;
}
.contain {
  position: relative;
  margin-top: 40px;
  min-height: 800px;

  &:after {
    display: table;
    content: "";
  }

  .rightList {
    margin-left: 280px;
    font-size: 18px;
    color: #444444;
    margin-bottom: 60px;

    .title {
      font-weight: 700;
      border-bottom: 1px solid #dddddd;
      padding-bottom: 20px;
    }

    .message {
      margin-top: 40px;

      .number {
        width: 26px;
        height: 26px;
        background: #444444;
        display: inline-block;
        color: #fff;
        text-align: center;
        line-height: 26px;
        border-radius: 13px;
        margin-bottom: 20px;
      }
    }
    .question-message {
      margin-top: 40px;
      position: relative;

      .q {
        width: 20px;
        height: 20px;
        position: absolute;
      }
      .a {
        width: 20px;
        height: 20px;
        position: absolute;
        top: 30px;
      }

      .question {
        margin-left: 28px;
        line-height: 22px;
        font-size: 16px;
        color: #444444;
        font-weight: 600;
      }
      .answer {
        margin-left: 28px;
        line-height: 22px;
        font-size: 12px;
        color: #888888;
        margin-top: 8px;
      }
    }

    img {
      width: 766px;
    }
  }

  .menu {
    position: absolute;
    width: 240px;
    border-top: 2px solid #f8f8f8;
  }

  .el-menu-item.is-active {
    color: #0082ff;
  }

  /deep/ .el-submenu.is-active .el-submenu__title {
    background-color: #ffffff !important;
    color: #444444 !important;
  }
}

// icon 20 X 20
.icon-help {
  width: 24px;
  height: 24px;
  background: url(../../assets/images/help/help-menu.png) no-repeat;
  background-position: 0 0;
  position: absolute;
  top: 12px;
  &.vendor {
    background-position: 0 -24px;
  }
  &.purchasers {
    background-position: 0 -47px;
  }
  &.question {
    background-position: 0 -70px;
  }
}

/deep/ .el-submenu__title * {
  padding-left: 30px;
}

/deep/ .el-submenu.is-opened > .el-submenu__title .el-submenu__icon-arrow {
  padding-left: 0;
}

/deep/ .el-submenu__title:hover {
  background-color: #fff !important;
  color: #4f525a !important;
}

.el-submenu.is-active {
  border-bottom: 1px solid #f8f8f8;
}

/deep/ .el-menu-item:hover,
.el-menu-item:active {
  background-color: #fff !important;
  color: #4f525a !important;
}

.el-submenu.is-opened {
  border-bottom: 1px solid #f8f8f8;
}

.download {
  margin-top: 20px;
  span {
    margin-left: 20px;
    color: #0082ff;
    cursor: pointer;
  }
}
</style>