<template>
    <div class="success-wrap">
        <Header></Header>
        <SearchBar :is-white-bg="true" :search-type="5" :progress="''" :is-border-bottom="true" :product-create-process="3"></SearchBar>
        <div class="success-wrap-content" id='success-wrap-content-res'>
            <div class="success-icon"></div>
            <p class="success-text">很抱歉，该商品已下架！</p>
            <p class="sub-success-text">
                可联系供应商查询，或返回
                <span class="blue" @click="go('user')">管理中心</span>
                <span>|</span>
                <span class="blue" @click="go('/')">首页</span>
            </p>
        </div>
        <Footer></Footer>

    </div>
</template>

<script>
import Header from "@/components/base/Header";
import Footer from "@/components/base/Footer";
import SearchBar from "@/components/SearchBar";

export default {
    components: {
        Header,
        SearchBar,
        Footer
    },
    data() {
        return {};
    },

    methods: {
        init() {
            let w =
                window.innerWidth ||
                document.documentElement.clientWidth ||
                document.body.clientWidth;
            let h =
                window.innerHeight ||
                document.documentElement.clientHeight ||
                document.body.clientHeight;
            document.getElementById("success-wrap-content-res").style.height =
                h - 200 - 55 - 34 - 160 + "px";
        },
        go(path) {
            if (path == "user") {
                let res = this.$store.state.userInfo;
                let bs = res.bs && res.bs.toUpperCase();
                if (bs == "S") {
                    this.$router.push("/vendorCenter/accountInfo");
                } else if (bs == "B") {
                    this.$router.push("/purchaserCenter/accountInfo");
                }
            } else {
                this.$router.push("/");
            }
        }
    },
    mounted() {
        this.init();
    }
};
</script>

<style lang="scss" scoped>
.success-wrap-content {
    padding-top: 90px;
    height: 100%;
}
.success-icon {
    width: 100px;
    height: 79px;
    margin: 0 auto 25px;
    background: url(../../assets/images/product-offline.png) no-repeat 0 0;
    background-size: 100% 100%;
}
.success-text {
    font-weight: bold;
    font-size: 20px;
    color: #333;
    text-align: center;
}
.sub-success-text {
    width: 540px;
    font-weight: bold;
    font-size: 12px;
    color: #333;
    text-align: center;
    margin: 15px auto;
    line-height: 20px;
    cursor: pointer;
}
</style>