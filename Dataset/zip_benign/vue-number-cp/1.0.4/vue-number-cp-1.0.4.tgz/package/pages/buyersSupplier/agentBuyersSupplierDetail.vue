<template>
  <div class="buyersSupplierDetail">
    <PanelTitle :title="'公司详情'"></PanelTitle>
    <div class="content">
      <UsersManage v-if="corpId" :companyCorpId="corpId" :breadcrumb="breadcrumb" :currentRole="bs"></UsersManage>
    </div>
  </div>
</template>

<script>
import {
  InterfaceService
} from "@/services/api";
import UsersManage from "@/components/company/CompanyMessageInfo";
import PanelTitle from "@/components/base/PanelTitle";

export default {
  components: {
    UsersManage, PanelTitle
  },
  data() {
    return {
      breadcrumb: [],
      corpId: "",
      bs: '',
    };
  },
  methods: {

  },
  mounted() {
    this.bs = 'S';
    this.breadcrumb = [
      { name: '账户管理中心', path: '/purchaserCenter/accountInfo' },
      { name: '代理商/经销商列表', goBack: true },
      { name: '公司详情' },
    ];
    this.bs =  'S';
    this.corpId = this.$route.query.corpId || ""
  }
};
</script>

<style lang="scss" scoped>
/deep/ .panel-title {
  margin-bottom: 0 !important;
}
.content {
  margin: 0 auto 20px;
}
</style>