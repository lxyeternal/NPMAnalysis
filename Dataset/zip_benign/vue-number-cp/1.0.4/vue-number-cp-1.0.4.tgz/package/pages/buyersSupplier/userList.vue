<template>
  <div class="userList">
    <UsetListComponent></UsetListComponent>
  </div>
</template>

<script>
import UsetListComponent from "@/components/order/UsetListComponent";

export default {
  components: {
    UsetListComponent
  },
}
</script>
