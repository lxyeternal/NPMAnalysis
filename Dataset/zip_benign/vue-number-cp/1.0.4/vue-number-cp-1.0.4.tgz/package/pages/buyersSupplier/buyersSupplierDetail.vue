<template>
  <div class="buyersSupplierDetail">
    <PanelTitle :title="'公司详情'"></PanelTitle>
    <div class="content">
      <UsersManage v-if="corpId" :companyCorpId="corpId" :breadcrumb="breadcrumb" :currentRole="bs"></UsersManage>
    </div>
  </div>
</template>

<script>
import {
  InterfaceService
} from "@/services/api";
import UsersManage from "@/components/company/CompanyMessageInfo";
import PanelTitle from "@/components/base/PanelTitle";

export default {
  components: {
    UsersManage,PanelTitle
  },
  data() {
    return {
      breadcrumb: [],
      corpId: "",
      params: {},
      bs:'',
    };
  },
  methods: {

  },
  mounted() {
    this.bs = this.$route.name == 'buyersSupplierDetailV' ? 'S' : 'B';
    this.params = JSON.parse(this.$route.query.params || '{}')
    this.breadcrumb=[
      { name: '账户管理中心',  path: '/purchaserCenter/accountInfo' },
      { name: this.bs == 'B' ? '采购商列表' : '供应商列表',
        path: this.bs == "B" ? "/purchaserCenter/buyersSupplierListP" : "/purchaserCenter/buyersSupplierListV",
        queryName: 'params',query: JSON.stringify(this.params)},
      { name: '公司详情'},
    ];
    this.bs = this.$route.name == 'buyersSupplierDetailV' ? 'S' : 'B';
    this.corpId = this.$route.query.corpId || ""
  }
};
</script>

<style lang="scss" scoped>
/deep/ .panel-title{
  margin-bottom: 0 !important;
}
.content {
  margin: 0 auto 20px;
}
</style>