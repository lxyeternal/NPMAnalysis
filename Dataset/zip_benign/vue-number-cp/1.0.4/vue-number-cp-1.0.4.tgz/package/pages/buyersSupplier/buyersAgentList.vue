<template>
  <div class="buyersSupplierList">
    <PanelTitle :title="'代理商/经销商列表'"></PanelTitle>
    <div class="list-home">
      <div class="list-content">
        <div class="panel">
          <el-form class="form" size="small" label-width="100px">
            <el-row>
              <el-col :span="8">
                <el-form-item label="公司名称：">
                  <el-input v-model.trim="corpName" placeholder="请输入公司名称" maxlength="64" @keyup.enter.native="search()" clearable></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <div class="searchbox">
              <div class="searchBtn" @click="search()">搜索</div>
              <div class="clearBtn" @click="clear()">清除</div>
            </div>
          </el-form>
        </div>
        <table>
          <thead>
            <tr>
              <td width="6%">序号</td>
              <td width="35%">公司名称</td>
              <td width="20%">品类</td>
              <td width="20%">所属供应商</td>
              <td width="10%">代理商类型</td>
              <td width="10%">操作</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in suppliersRst" :key="ind" class="tbody-row">
            <tr>
              <td>
                {{ind+1}}
              </td>
              <td>
                {{item.corpName}}
              </td>
              <td class="ellipsisOne" :title="item.corpCategorys">
                {{item.corpCategorys}}
              </td>
              <td>
                {{item.supplierCorpName}}
                <!-- {{item.rankDisp}} -->
              </td>
              <td>{{item.supplyTypeDisp}}</td>
              <td>
                <p class="operate" @click="handleOpenDetail(item.corpId)">查看详情</p>
                <p class="operate" @click="handleOpenUser(item.corpId)">用户列表</p>
              </td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!suppliersRst.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>没有搜索到相关记录，请重新修改搜索条件搜索！</p>
        </div>
        <div class="table-pagination" v-if="suppliersRst.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>

    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
export default {
  components: {
    Loading,
    PanelTitle
  },
  data() {
    return {
      isLoading: false,

      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码
      suppliersRst: [],
      bs: '', // （"S"：供应商；"B"：采购商）
      corpName: '',// 公司名称
      groupCompanyCode: '', // 所属事业部
      corpId: '',
      corpStatus: '',
      options: [],
      showFreeze: false,
      showThaw: false,
    };
  },
  watch: {
    "$route": function (to, from) {
      console.log(to, from);
      if (from.name != to.name) {
        this.init()
      }
    }
  },
  methods: {
    // 去用户列表
    handleOpenUser(corpId) {
      this.$setRootScope('breadcrumb', JSON.stringify([
        { name: '账户管理中心', path: '/purchaserCenter/accountInfo' },
        { name: '代理商/经销商列表', goBack: true },
        { name: '用户列表' },
      ]))
      this.$router.push({
        path: "/purchaserCenter/agentUserList",
        query: {
          corpId: corpId,
          bs: this.bs
        }
      });
    },
    // 去详情
    handleOpenDetail(corpId) {
      this.$router.push({
        path: "/purchaserCenter/agentBuyersSupplierDetail",
        query: {
          corpId: corpId,
          bs: this.bs
        }
      });
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.getAgentList()
      window.scrollTo(0, 0)
    },


    // 冻结/解冻弹框
    open() {
      this.$confirm(
        this.corpStatus == 1 ? '您确认冻结该公司吗？冻结后该公司下属员工将无法再通过帐号登录大家采平台。' : '您确定解冻该公司吗？解冻后该公司下属员工可通过帐号登录大家采平台。',
        this.corpStatus == 1 ? '冻结' : '解冻',
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          type: 'warning',
          confirmButtonText: "确认",
          cancelButtonText: '取消',
        }).then(() => {
          this.isThawCompany()
        }).catch(() => {
        });
    },
    search() {
      this.corpName = this.corpName.trim()
      this.groupCompanyCode = this.groupCompanyCode
      this.pageIndex = 1
      this.getAgentList()
    },
    clear() {
      this.corpName = ''
      this.groupCompanyCode = ''
      this.pageIndex = 1
      this.getAgentList()
    },

    // 代理商列表
    getAgentList() {
      let param = {
        corpName: this.corpName,
        supplyTypeList: ['1', '2', '5'],
        pageIndex: String(this.pageIndex),
        pageSize: String(this.pageSize),
      }
      InterfaceService.getAgentList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.suppliersRst = data.respData.suppliersRst || []
          this.total = data.respData.totalCount || []
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    init() {
      this.bs = 'S';
      this.getAgentList()
    },
  },
  mounted() {
    this.init()
  },
  destroyed() {
  }
};
</script>

<style lang="scss" scoped>
.buyersSupplierList {
  /*width: 950px;*/
  margin: 0 auto;
  padding-bottom: 60px;
  .list-content {
    .panel {
      background: rgba(249, 249, 249, 1);
      padding: 20px 10px;
      margin: 20px 0;
    }

    table {
      margin-top: 20px;
      table-layout: fixed;
      width: 100%;
      line-height: 23px;
      font-size: 12px;
      td {
        padding: 16px 10px;
        vertical-align: middle;
        word-break: break-all;
        &:last-child {
          text-align: right;
        }
      }

      thead {
        font-size: 14px;
        text-align: left;
        white-space: nowrap;
        border-bottom: 1px solid #eee;
        background: rgba(249, 249, 249, 1);
        color: rgba(136, 136, 136, 1);
        tr {
          td {
            padding: 13px 10px;
            &:last-child {
              text-align: right;
            }
          }
        }
      }
      .tbody-row {
        &:hover {
          background: #f0f8ff;
        }
      }
      tbody {
        text-align: left;
        tr {
          border-bottom: 1px solid #eee;
        }
        td {
          span:hover {
            color: #0082ff;
            cursor: pointer;
            text-decoration: underline;
          }
        }
        .operate {
          color: rgba(0, 130, 255, 1);
          cursor: pointer;
        }
        .border-none {
          border-bottom: none;
        }
      }
    }
  }
}
.el-button + .el-button {
  margin-left: 18px;
}
.el-select {
  width: 100%;
}
.btn {
  width: 80px;
  height: 26px;
  line-height: 26px;
  font-size: 12px;
  padding: 0;
}

.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}
.txt-center {
  text-align: center;
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
.searchbox {
  text-align: center;
  margin-top: 20px;
  .searchBtn {
    width: 80px;
    height: 26px;
    line-height: 26px;
    background: linear-gradient(
      122deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(255, 255, 255, 1);
    margin-right: 20px;
    display: inline-block;
    cursor: pointer;
  }
  .clearBtn {
    width: 80px;
    height: 26px;
    line-height: 24px;
    border: 1px solid rgba(201, 159, 79, 1);
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(201, 159, 79, 1);
    display: inline-block;
    cursor: pointer;
  }
}
/deep/ .el-form-item--small.el-form-item {
  margin-bottom: 0;
}
</style>
