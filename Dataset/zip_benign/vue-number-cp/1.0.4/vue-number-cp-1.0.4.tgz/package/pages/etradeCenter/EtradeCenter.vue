<template>
  <div class="help-wrap">
    <Header :is-white-bg="true"></Header>
    <SearchBar :is-red-bg="true"  :search-type="searchBarType"></SearchBar>
    <LightColorMenuBar :current-router="currentRouter"></LightColorMenuBar>
    <div class="account-info-inner" id="account-info-inner">
      <div class="contain inner-container">
          <div class="menu">
            <el-menu :default-active="menuIndex" @open="handleOpen" @close="handleClose" background-color="#f8f8f8" text-color="#4f525a" style="padding-bottom:140px;border-right: none;">
              <el-submenu index="1">
                <template slot="title">
                  <i class="icon-help"></i>
                  <span>公司介绍</span>
                </template>
                <el-menu-item-group>
                  <el-menu-item index="1-1" @click="showHelp('1-1')">
                    <!-- <i class="icon-help us"></i> -->关于我们
                  </el-menu-item>
                  <el-menu-item index="1-2" @click="showHelp('1-2')">
                    <!-- <i class="icon-help contact"></i> -->联系我们
                  </el-menu-item>
                </el-menu-item-group>
              </el-submenu>
            </el-menu>
          </div>

          <div class="rightList" ref = "content">
            <div v-if="this.showMessage == '1-1'">
              <div class="title"><span>关于我们</span></div>
              <p class="sub-title bold">一站式地产行业智能采购云平台</p>
              <p class="etrade-center text hd first">平台简介</p>
              <p class="etrade-center text bd">
              这是一个有着——以 “中国制造2025”为目标，以需方需求上线指导产业链升级为亮点，应用区块链技术作为技术预留——三大特色的电商平台。平台通过汇聚供需双方资源、提升采购精度及效率、简化操作过程、降低交易成本、建立互评体系，给全国地产开发商及工程需方，提供一个业内专业性、开放性、规模性B2B线上交易平台。
              在此平台上，资源得以共享，信息实现公开展示，采购方可直接提出自身需求，进行更高效的采购操作；供应方则面向更多的大众，公平竞争获取市场业务的拓宽。一场从线下到线上的采购转型，进而将建材采购向着更加智能化、透明化、标准化、高效化的管理模式发展，推进建筑业采购的全面降本增效。
              </p>

              <p class="etrade-center text hd">平台特点</p>
              <p class="etrade-center text bd">
              电商平台按客户敏感、技术敏感等角度进行细化分类标准，根据需求即可快速精确筛选到想要的产品。商品SKU体系更加科学地搭建，建立数据库基础，便于采购方、供应方线上线下统一管理。零售采购与批量采购结合的采购模式，人性化满足采购方需求。更优化的零售界面，商品详情信息清晰可见；需求清单批量导入，操作动作更方便、流程更快捷。合同一经确认，电子合同即刻生成，供需双方权益获得充分保障。
              </p>
              <p class="etrade-center text bd f14 bold">
              采购流程全节点总览，全生命周期化管理，实现线上管理合同进程，摆脱线下人力收发货跟踪及付款结算追查带来的不便。
              </p>

              <p class="etrade-center text hd">平台前景</p>
              <p class="etrade-center text bd">
              作为绿地香港材料公司上海博置实业有限公司力推电商平台，目前已完成平台搭建内部测试，商品可在线演示、流程可在线交易。6月底面向广大采购商及供应商呈现一个更加完善的采购平台，相关采购流程均可实现线上化完成。截止2018年底已有500家供应商入驻平台，实现30~50亿的年度成交金额。致力于在当今互联网+、供应链整合创新的市场环境下，弯道超车，成为行业领先的建筑业B2B线上交易电商平台。
              </p>
              <div class="etrade-data clearfloat">
                <div class="etrade-data-info fl first">
                  <span class="etrade-data-info-inner">会员</span> <span class="f18 red bold">500+</span>
                </div>
                <div class="etrade-data-info fl">
                  <span class="etrade-data-info-inner">大类产品</span> <span class="f18 red bold">100+</span>
                </div>
                <div class="etrade-data-info fl last">
                  <span class="etrade-data-info-inner">成交额</span> <span class="f18 red bold">30亿+</span>
                </div>
              </div>
            </div>
            <div v-if="this.showMessage == '1-2'">
              <div class="title"><span>联系我们</span></div>
              <p class="contact-title">公司地址</p>
              <p class="contact-value">总部：上海市浦东新区商城路506号新梅联合广场23F 邮政编码：200003</p>

              <p class="contact-title">联系电话</p>
              <p class="contact-value">{{$platformContact()['hotLine']}} {{$platformContact()['hotLineTime']}}</p>


              <p class="contact-title">联系邮箱</p>
              <p class="contact-value">{{$platformContact()['email']}}</p>

              <p class="contact-title">客服微信</p>
              <p class="contact-value">
                <img src="../../assets/images/maer/wx_custom_service.png" alt="">
              </p>
            </div>
          </div>
      </div>
    </div>
    <Footer></Footer>
  </div>
</template>
<script>
  import { mapActions, mapState } from "vuex";
  import SearchBar from "@/components/SearchBar";
  import Header from "@/components/base/Header";
  import LightColorMenuBar from "@/components/LightColorMenuBar";
  import Footer from "@/components/base/Footer";
  export default {

    components: {
      SearchBar,
      Footer,
      Header,
      LightColorMenuBar
    },
    data() {
      return {
        searchBarType: 1, //搜索框组件的显示类型
        currentRouter: "etradeCenter",
        showMessage: '1-1',
        menuIndex:'1-1',
        position:''
      }
    },
    computed: {},
    methods: {
      handleOpen(key, keyPath) {

      },
      handleClose(key, keyPath) {

      },
      showHelp(type) {
        this.showMessage = type;
      },
    },
    watch: {

    },
    created () {

    },
    mounted() {
      this.menuIndex = this.$route.query.index || '1-1'
      this.showMessage = this.menuIndex;
      // this.position = this.$route.query.position || ''

      // if(this.position){
      //   setTimeout(()=>{
      //      window.scrollTo(0, $("#"+this.menuIndex+'-'+this.position).offset().top);
      //   },400)
      // }

    }
  }
</script>

<style scoped lang="scss">
.contain {
  position: relative;
  margin-top: 40px;
  min-height: 800px;

  &:after{
    display: table;
    content: '';
  }

  .rightList{
    margin-left: 280px;
    font-size: 18px;
    color: #444444;
    margin-bottom: 60px;

    .title{
      font-weight: 700;
      border-bottom: 1px solid #dddddd;
      height:40px;
      line-height:40px;

      span{
        display:inline-block;
        padding:0 4px;
        height:40px;
        line-height:40px;
        border-bottom:2px solid #ffd64e;

      }
    }

    .message {
      margin-top: 40px;

      .number{
        width: 26px;
        height: 26px;
        background: #444444;
        display: inline-block;
        color: #fff;
        text-align: center;
        line-height: 26px;
        border-radius: 13px;
        margin-bottom: 20px;
      }
    }
    .question-message {
      margin-top: 40px;
      position: relative;

      .q {
        width: 20px;
        height: 20px;
        position: absolute;
      }
      .a {
        width: 20px;
        height: 20px;
        position: absolute;
        top: 30px;
      }

      .question {
        margin-left: 28px;
        line-height: 22px;
        font-size: 16px;
        color: #444444;
        font-weight: 600;
      }
      .answer {
        margin-left: 28px;
        line-height: 22px;
        font-size: 12px;
        color: #888888;
        margin-top: 8px;
      }
    }


  }

  .menu{
    position: absolute;
    width: 240px;
    border-top: 2px solid #f8f8f8;
  }


  .el-menu-item.is-active {
    color: #0082ff
  }

  /deep/ .el-submenu.is-active .el-submenu__title {
    background-color: #ffffff !important;
    color: #444444 !important;
  }
}

// icon 20 X 20
.icon-help {
  width: 20px;
  height: 24px;
  background: url(../../assets/images/home/etrade_center.png) no-repeat;
  background-position: 0 0;
  position: absolute;
  top: 12px;
  &.us {
    background-position: 0 -24px;
  }
  &.contact {
    background-position: 0 -47px;
  }

}

/deep/ .el-submenu__title * {
  padding-left: 30px;
}
/deep/ .el-submenu.is-opened > .el-submenu__title .el-submenu__icon-arrow {
  padding-left: 0
}

/deep/ .el-submenu__title:hover {
  background-color: #fff !important;
  color: #4f525a !important;
}

.el-submenu.is-active {
    border-bottom: 1px solid #f8f8f8;
}

/deep/ .el-menu-item:hover, .el-menu-item:active {
  background-color: #fff !important;
  color: #4f525a !important;
}
.el-submenu.is-opened {
    border-bottom: 1px solid #f8f8f8;
}

.sub-title{
  color:#303030;
  font-size:16px;
  line-height:44px;
  padding-top:16px;
}
.etrade-center{
  font-size:12px;
  color:#444;
  line-height:40px;

  &.hd{
    margin-top:50px;

    &.first{
      margin-top:0;
    }
  }

  &.bd{
    text-indent:24px;
  }
}
.contact-title{padding-top:16px;}
.contact-title,.contact-value{
  font-size:14px;
  color:#585858;
  line-height:30px;
}
.contact-value{
  margin-bottom:10px;

  img{
    width:155px;
    height:auto;
  }
}
.etrade-data{
  padding-top:20px;
}
.etrade-data-info{
  font-size:18px;
  color:#444;
  padding-right:40px;
  border-right:1px solid #888;
  padding-left:40px;

  &.first{
    padding-left:0;
  }
  &.last{
    border-right:0;
  }
  .etrade-data-info-inner{
    margin-right:8px;
  }
}
</style>