<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <SearchBar :search-type="5" :progress="status === 'processing'?'编辑选型项目':'创建选型项目'" :is-border-bottom="true" :product-create-process="2"></SearchBar>
        <div class="inner-container">
            <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
            <div class="panel-content">
                <el-form class="form" :model="submitForm" size="small" label-width="80px">
                    <el-row>
                        <el-col :span="24">
                            <el-form-item label="选型编号">
                                {{submitForm.selectionNo}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="24">
                            <el-form-item label="选型项目" required>
                                <el-input v-model="submitForm.selectionName" placeholder="请输入选型项目名称，限20字" maxlength="20"></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <SelectCategory v-if="initParams" :marginLeft="'margin31'" :disabled="status === 'processing'" :initParams="initParams" :changeWaring="true" :required="true" :label="'选择品类'" @formData="getCategoryForm" :form="form" @initChangeCate = "handleinitChangeCate"></SelectCategory>
                </el-form>
            </div>
            <div class="info-title">
                <span class="order-info-title bold fl">生成选型清单</span>
                <span style="margin-top: 5px;" class="blue fr hand" @click="handleFold()">{{showSelectionOpt === true? "收起" : "展开"}}
                    <i class="el-icon-caret-top active" v-if="opened"></i>
                    <i class="el-icon-caret-bottom active" v-if="!opened"></i>
                </span>
            </div>
            <template v-if="showSelectionOpt">
                <CreactModelSelection
                        v-if="initParams"
                        :supplierSelectionInfo="supplierSelectionInfo"
                        :prodSelectionInfo="prodSelectionInfo"
                        :attrList="totalAttrList"
                        :supplierCnt="supplierCnt"
                        :prodCnt="prodCnt"
                        :clearParam="clearParam"
                        @selectedData="handleSearch"
                        @initFormParmas="initFormParmas"
                        :form="form"
                        :fromsearch = "fromsearch"
                        :initChangeCate = "initChangeCate"
                >
                </CreactModelSelection>
                <el-row>
                    <el-col :span="24" class="form-btns">
                        <el-button :disabled="prodCnt == '0'" type="primary" @click="handleCreateList">生成清单</el-button>
                        <el-button @click="handleClear()">重置</el-button>
                    </el-col>
                </el-row>
            </template>
            <SupplierDetailList :mainSelection ="true" :selectionName="form.selectionName" :create="true" v-if="showSupplierListDetail" :supplierDetailList="supplierDetailList" :selectionNo="form.selectionNo"></SupplierDetailList>
            <CoordinationModelSelection v-if = "initParams" :selectorList="selectorList" @getCoordinationList="getCoordinationList" :supplierDetailList="supplierDetailList"></CoordinationModelSelection>
        </div>
        <div class="save-tip" v-if="showTips && (status === 'draft' || !this.status)">
            <div class="save-tip-cont bold">
                请实时点击【保存】按钮，避免自己操作记录，因长时间未操作而丢失。
                <i class="el-icon-close fr" @click="showTips = false"></i>
            </div>
            <div class="d3"></div>
        </div>
        <FixBottom>
            <div class="fix-bottom">
                <el-button type="primary" :disabled="cantSave" style="width: 120px;" @click="alertConfirm('processing')">{{status === 'processing'?"更新":"发布"}}</el-button>
                <el-button v-if="status === 'draft' || !this.status" style="width: 120px;" :disabled="cantSave"  @click="alertConfirm('draft')">保存</el-button>
                <el-button style="width: 120px;" @click="handleGoList(status)">关闭</el-button>
            </div>
        </FixBottom>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>
<script>
    import Header from "@/components/base/Header";
    import SearchBar from "@/components/SearchBar";
    import Loading from "@/components/base/Loading";
    import PanelTitle from "@/components/base/PanelTitle";
    import FixBottom from "@/components/base/FixBottom";
    import Breadcrumb from "@/components/base/Breadcrumb";
    import SelectCategory from "@/components/onlineModelSelection/SelectCategory";
    import CreactModelSelection from "@/components/onlineModelSelection/CreactModelSelection";
    import SupplierDetailList from "@/components/onlineModelSelection/SupplierDetailList";
    import CoordinationModelSelection from "@/components/onlineModelSelection/CoordinationModelSelection";
    import { InterfaceService } from "@/services/api";
    import accountMixin from "@/mixins/account";

    const params = {
        selectionNo: "",
        selectionName: "",
        searchParam: "",
        categoryId: "",
        categoryName: "",
        listCreationFlg: "",
        searchFlg: "",
        selectionSearchFrom: "",
        assessLevelList:[],
        riskLevelList:[],
        prodLevelList:[],
        prodFromList:[],
        attrList:[],
    };
    const submitForm = {
        selectionNo: "",
        selectionName: "",
        searchParam: "",
        searchOpt: "",
        categoryId: "",
        status: "",
        searchResult: {},
        supplierList: [],
        coordinationList: [],
    };
    export default {
        mixins: [accountMixin],
        components: {
            Header,
            SearchBar,
            Loading,
            PanelTitle,
            FixBottom,
            Breadcrumb,
            SelectCategory,
            CreactModelSelection,
            SupplierDetailList,
            CoordinationModelSelection,
        },
        data() {
            return {
                isLoading: false,
                opened: false,
                clearParam: false,
                showTips: true,
                dialogVisible: false,
                showSelectionOpt: true,
                showSupplierListDetail: false,
                fromsearch: false,
                fromDialog: false,
                initParams: false,
                initCnt: false,
                status: "",
                uptTm: "",
                initChangeCate: true,
                form: Object.assign({}, params),
                submitForm: Object.assign({}, submitForm),
                breadcrumb: [],
                originSearchParam: {},
                supplierSelectionInfo: {},
                prodSelectionInfo: {},
                supplierDetailList: [],
                totalAttrList: [],
                selectorList:[],
                supplierCnt: 0,
                prodCnt: 0,
            };
        },
        computed: {
            canCreact() {
                let bool = false;
                if (this.form.selectionName && this.form.categoryId) {
                    bool = true
                }
                return bool
            },
            cantSave() {
                return !this.showSupplierListDetail || !this.form.categoryId || !this.submitForm.selectionName || this.prodCnt == '0'
            }
        },
        methods: {
            handleGoList(type){
                window.opener=null;
                window.close();
            },
            //关闭弹窗
            handleCloseDailog() {
                this.dialogVisible = false;
                this.fromDialog = false
            },
            createSelectionProject() {
                this.dialogVisible = false;
                this.fromDialog = false;
                this.submitForm.selectionName = this.dialogForm.selectionName;
                this.form = Object.assign(this.form, this.dialogForm);
                this.handleClear()
            },
            handleClear(){
                this.form.assessLevelList = [];
                this.form.riskLevelList = [];
                this.form.prodLevelList = [];
                this.form.prodFromList = [];
                this.form.attrList=[];
                this.clearParam = true;
                this.form.searchFlg = "firstCreation";
                this.getGoodsFromCategory('firstCreation');
            },
            // 收起展开
            handleFold(){
                this.showSelectionOpt = !this.showSelectionOpt;
            },
            handleSearch(type,data) {
                this.clearParam = false;
                for (let i in this.form) {
                    if (i === type + "List") {
                        this.form[i] = [];
                        data.forEach(item=>{
                            this.form[i].push({
                                [type] :item
                            })
                        })
                    }
                }
                if (type === "attrList") {
                    this.form.attrList = data
                }else {
                    this.form.attrList = []
                }
                this.form.searchFlg = "filter";
                this.getGoodsFromCategory('filter')
            },
            initFormParmas(type,data) {
                for (let i in this.form) {
                    if (i === type + "List") {
                        this.form[i] = [];
                        data.forEach(item=>{
                            this.form[i].push({
                                [type] :item
                            })
                        })
                    }
                }
            },
            getCategoryForm(form){
                this.form = Object.assign(this.form,form);
                this.handleClear()
            },
            handleinitChangeCate(initChangeCate) {
                this.initChangeCate = initChangeCate
                if (!initChangeCate) {
                    this.supplierCnt = 0;
                    this.prodCnt = 0
                    // this.attrList = []
                    this.totalAttrList = []
                    // this.supplierSelectionInfo={}
                    // this.prodSelectionInfo={}
                }
            },
            getDialogCategoryForm(form) {
                this.dialogForm = Object.assign(this.dialogForm,form);
            },
            getGoodsFromCategory(type) {
                if (type === "create") {
                    this.form.listCreationFlg = "1";
                    // this.form.selectionSearchFrom = "createList";
                    this.form.searchParam = JSON.stringify(this.form);
                }else {
                    // if (type === "filter") {
                    //     this.form.selectionSearchFrom = "filter";
                    // }else {
                    //     this.form.selectionSearchFrom = "initDetail";
                    // }
                    this.form.listCreationFlg = "0";
                    this.form.searchParam = "";
                }

                let params = Object.assign({},this.form);
                console.log(params);
                InterfaceService.getGoodsFromCategory(
                    params,
                    data => {
                        let res = data.respData;
                        if (res.respCode === "0000") {
                            if (type === 'create') {
                                this.supplierDetailList = res.supplierDetailList || [];
                                this.supplierDetailList = this.supplierDetailList.sort(this.compare);
                                this.supplierDetailList.forEach((item,ind)=> {
                                    if (item.corpStatus !== "1") {
                                        item.tags.push({
                                            tagId: "out",
                                            tagName: "未入驻"
                                        })
                                    }
                                });
                                this.$message({
                                    type:"success",
                                    message:"生成清单成功！",
                                    offset:"400",
                                });
                            }else {
                                this.supplierSelectionInfo = res.supplierSelectionInfo || {};
                                this.prodSelectionInfo = res.prodSelectionInfo || {};
                                this.supplierDetailList = this.supplierDetailList || [];
                                if (type === "diffSearch") {
                                    if (res.prodChangeCnt != "0") {
                                        this.$alert(
                                            "该项目的候选商品已发生变化，系统将为您重新生成选型清单。",
                                            {
                                                customClass: "alert-box",
                                                center: true,
                                                confirmButtonText: "知道了",
                                                callback: action => {
                                                    this.form.searchFlg = "createList";
                                                    this.getGoodsFromCategory("create")
                                                }
                                            }
                                        );
                                    }
                                    this.form.listCreationFlg = "1";
                                }
                            }
                            // this.attrList = res.attrList || [];
                            this.totalAttrList = res.totalAttrList || [];
                            if (!this.fromsearch || this.initCnt) {
                                this.supplierCnt = res.supplierSelectionInfo.supplierCnt || 0;
                                this.prodCnt = res.prodSelectionInfo.prodCnt || 0;
                            }
                            this.initCnt = true;
                            this.initParams = true;
                        } else {
                            //生成清单失败时，把flg重置为0
                            this.form.listCreationFlg = "0";
                            this.$message.error(res.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            init() {
              this.getSelectionNo();
            },
            getSelectionNo() {
                InterfaceService.getTenderNo({
                    type:"SEL"
                }, data => {
                    if (data && data.respData && data.respData.respCode === "0000") {
                        this.submitForm.selectionNo = data.respData.busiNo || ""
                        this.form.selectionNo = data.respData.busiNo || ""
                        this.form.searchFlg = "firstCreation";
                        this.initParams = false;
                        this.getGoodsFromCategory('init');
                    } else {
                        this.$message.error(data.respData.respMsg)
                    }
                }, data => { }, () => {
                    this.Loading = true
                }, () => {
                    this.Loading = false
                })
            },
            //生成清单
            handleCreateList() {
                if (this.supplierDetailList && this.supplierDetailList.length > 0) {
                    this.$confirm(
                        "新筛选结果将覆盖已生成的清单明细，是否覆盖清单明细？",
                        {
                            cancelButtonClass: "btn-custom-cancel",
                            confirmButtonClass: "btn-custom-confirm",
                            center: true,
                            type: 'warning',
                            confirmButtonText: "确认",
                            cancelButtonText: '取消',
                        }).then(() => {
                        this.form.searchFlg = "createList";
                        this.getGoodsFromCategory("create");
                        this.showSupplierListDetail = true
                    }).catch(() => {
                    });
                }else {
                    this.form.searchFlg = "createList";
                    this.getGoodsFromCategory("create");
                    this.showSupplierListDetail = true
                }

            },
            getGoodsSelectionDetail(msg) {
                this.fromsearch = false;
                InterfaceService.getGoodsSelectionDetail({
                    selectionNo:this.form.selectionNo
                }, data => {
                    if (data && data.respData && data.respData.respCode === "0000") {
                        let res = data.respData || {};
                        this.status = res.status || "";
                        this.changeBreadcrumb();
                        this.uptTm = res.uptTm;
                        this.form.selectionName = res.selectionName;
                        this.form.firstCate = res.categoryLv1Id;
                        this.form.secondCate = res.categoryLv2Id;
                        this.form.categoryId = res.categoryLv3Id;
                        this.submitForm.selectionName = res.selectionName;
                        this.submitForm.categoryId = res.categoryLv3Id;
                        this.supplierDetailList = res.selectionSupplierList || [];
                        this.supplierDetailList = this.supplierDetailList.sort(this.compare);
                        this.supplierDetailList.forEach((item,ind)=> {
                            if (item.corpStatus !== "1") {
                                item.tags.push({
                                    tagId: "out",
                                    tagName: "未入驻"
                                })
                            }
                        });
                        this.selectorList = res.selectorList || [];
                        this.prodCnt = res.skuCnt || 0;
                        this.supplierCnt = res.supplierCnt || 0;
                        let searchParam = JSON.parse(res.searchParam);
                        this.originSearchParam = JSON.parse(res.searchParam);
                        this.form.assessLevelList = searchParam.assessLevelList || []
                        this.form.riskLevelList = searchParam.riskLevelList || [];
                        this.form.prodLevelList = searchParam.prodLevelList || [];
                        this.form.prodFromList = searchParam.prodFromList || [];
                        this.form.attrList = searchParam.attrList || [];
                        this.showSupplierListDetail = true;
                        this.fromsearch = true;
                        // this.form.searchFlg = "";
                        if (msg) {
                            this.$message.success(msg)
                        }else {
                            this.form.searchFlg = "diffSearch";
                            this.getGoodsFromCategory('diffSearch');
                        }
                    } else {
                        this.$message.error(data.respData.respMsg)
                    }
                }, data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    })
            },
            compare (obj1, obj2) {
                let val1 = obj1.corpStatus;
                let val2 = obj2.corpStatus;
                if (val1 < val2) {
                    return -1;
                } else if (val1 > val2) {
                    return 1;
                } else {
                    return 0;
                }
            },
            changeBreadcrumb(){
                this.breadcrumb = [
                    { name: '首页', path: '/home' },
                    { name: '管理中心', path: '/purchaserCenter/accountInfo'},
                    { name: '选型管理',path:'/purchaserCenter/modelSelectionList' },
                    { name: this.status === 'processing'?'编辑选型项目':'创建选型项目',path:'/purchaserCenter/modelSelectionList' },
                ];
            },
            getCoordinationList(list) {
                this.coordinationList = list || []
            },
            filterCoordination() {
                let list = [];
                this.selectorList.forEach(item=>{
                    let onOff = false;
                    this.coordinationList.forEach((_item,ind)=>{
                        if (_item.acctId === item.acctId && _item.acctId) {
                            onOff = true;
                            _item.initPerson = true;
                        }
                    });
                    if (!onOff && item.selectionRole != "main") {
                        list.push({
                            acctId : item.acctId,
                            optFlg : "del"
                        })
                    }
                });
                this.coordinationList.forEach(item=>{
                    if (!item.initPerson && item.acctId) {
                        list.push(item)
                    }
                })
                return list
            },
            alertConfirm(type) {
                let str = "";
                let title = "";
                // if ((this.form.listCreationFlg === "0" && !this.fromsearch) || ((this.checkeParam() && this.form.listCreationFlg === "0") && this.fromsearch)) {
                if (this.form.listCreationFlg === "0") {
                    this.$alert(
                        "查询条件已改变但未生成清单，请重新生成清单再进行操作",
                        {
                            customClass: "alert-box",
                            center: true,
                            confirmButtonText: "知道了",
                            callback: action => {}
                        }
                    );
                    return
                }
                if (type === "processing") {
                    if (this.status === "draft" || !this.status) {
                        title = "确认发布选型项目";
                        str = "确认发布选型项目，并同步给相关协同选型人员？"
                    }else if (this.status === "processing") {
                        title = "确认更新选型项目";
                        str = "将已更改的相关选型信息，同步给相关选型人员吗？"
                    }
                    this.$confirm(
                        str,
                        title,
                        {
                            cancelButtonClass: "btn-custom-cancel",
                            confirmButtonClass: "btn-custom-confirm",
                            center: true,
                            type: 'warning',
                            confirmButtonText: "确认",
                            cancelButtonText: '取消',
                        }).then(() => {
                        this.handleConfirm(type)
                    }).catch(() => {
                    });
                } else {
                    this.handleConfirm(type)
                }
            },
            handleConfirm(type) {
                this.submitForm.categoryId = this.form.categoryId;
                this.submitForm.searchResult.companyCnt = this.supplierCnt;
                this.submitForm.searchResult.prodCnt = this.prodCnt;
                this.submitForm.searchParam = JSON.stringify(this.form);
                this.submitForm.originSearchParam = this.originSearchParam;
                this.submitForm.supplierList = [];
                if (this.supplierDetailList.length) {
                    this.supplierDetailList.forEach(item=>{
                        this.submitForm.supplierList.push({
                            supplierId : item.corpId,
                            attachUrl : item.attachUrl || "",
                        })
                    })
                }
                this.submitForm.lastUpdateTime = type !== "draft" && this.status === 'processing' ? this.uptTm : "";
                this.submitForm.status = type;
                this.submitForm.coordinationList = this.filterCoordination();
                let searchOpt = {};
                searchOpt.supplierSelectionInfo = this.supplierSelectionInfo;
                searchOpt.prodSelectionInfo = this.prodSelectionInfo;
                this.submitForm.searchOpt = JSON.stringify(searchOpt);
                console.log(this.submitForm);
                InterfaceService.createOrEditGoodsSelection(
                    this.submitForm,
                    data => {
                        let res = data.respData;
                        if (res.respCode === "0000") {
                            if (window.opener) {
                                window.opener.location.reload();
                            }
                            // this.$message.success(type === "processing" ? "选型项目发布成功！" : "选型项目保存成功！")
                            if (type !== "draft") {
                                this.$alert(
                                    "选型项目发布成功！",
                                    {
                                        customClass: "alert-box",
                                        center: true,
                                        type: "success",
                                        confirmButtonText: "知道了",
                                        callback: action => {
                                            this.handleGoList(type);
                                        }
                                    }
                                );
                            }else {
                                this.getGoodsSelectionDetail("选型项目保存成功！")
                            }
                        } else {
                            this.$message.error(res.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                )
            },
            checkeParam() {
                return JSON.stringify(this.originSearchParam.assessLevelList.sort()) !== JSON.stringify(this.form.assessLevelList.sort()) ||
                    JSON.stringify(this.originSearchParam.attrList.sort()) !== JSON.stringify(this.form.attrList.sort()) ||
                    JSON.stringify(this.originSearchParam.prodFromList.sort()) !== JSON.stringify(this.form.prodFromList.sort()) ||
                    JSON.stringify(this.originSearchParam.prodLevelList.sort()) !== JSON.stringify(this.form.prodLevelList.sort()) ||
                    JSON.stringify(this.originSearchParam.riskLevelList.sort()) !== JSON.stringify(this.form.riskLevelList.sort())
            }
        },
        mounted() {
            this.changeBreadcrumb();
            if (this.$route.query.categoryForm) {
                let categoryForm = eval('(' + this.$route.query.categoryForm + ')');
                this.form = Object.assign(this.form,categoryForm || {});
                this.submitForm.selectionNo = this.form.selectionNo;
                this.submitForm.selectionName = this.form.selectionName;
                this.init();
            }else if (this.$route.query.selectionNo) {
                this.form.selectionNo = this.$route.query.selectionNo;
                this.submitForm.selectionNo = this.$route.query.selectionNo;
                this.getGoodsSelectionDetail()
            }
        }
    };
</script>
<style lang="scss" scoped>
    .inner-container {
        margin-bottom: 100px;
        font-size: 14px;
    }
    .el-button{
        height: 20px;
        line-height: 20px;
        padding-top: 0;
    }
    /deep/ .el-col{
        /*padding: 0 10px;*/
    }
    .fix-bottom{
        width: 100%;
        height: 40px;
        margin: 0 auto;
        text-align: center;
        .el-button{
            height: 40px;
            line-height: 40px;
        }
    }
    .panel-content {
        margin-bottom: 30px;
        padding: 10px 20px 0;
        background: #f5f5f5;
    }
    .form {
        /deep/ .el-col {
            height: 52px;
        }

        /deep/ .el-select {
            width: 100%;
        }

        /deep/ .el-date-editor {
            input.el-input__inner {
                padding: 0 15px;
            }
            .el-input__prefix {
                display: none;
            }
        }

        &:after {
            display: table;
            content: "";
            clear: both;
        }
    }
    .order-info-title {
        margin: 0 0 10px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
        width: 300px;
    }
    .info-title {
        &:after {
            display: table;
            content: "";
            clear: both;
        }
    }
    .form-btns{
        background: #f5f5f5;
        padding:0 0 20px;
        margin-bottom: 10px;
        text-align: center;
        .el-button{
            width: 120px;
            height: 30px;
            line-height: 30px;
        }
    }
    .save-tip {
        position: fixed;
        /*margin: 0 auto;*/
        bottom: 45px;
        width: 100%;
        z-index: 2001;
        .save-tip-cont{
            width: 1190px;
            margin: 0 auto;
            text-align: center;
            text-indent: 2em;
            background: #fef4f3;
            height: 30px;
            line-height: 30px;
            text-indent: 2em;
            i{
                height: 30px;
                line-height: 30px;
                margin-right: 10px;
                cursor: pointer;
            }
        }
        .d3{
            margin-left: 50%;
            width: 0;
            height: 0;
            border-width: 7px;
            border-style: solid;
            border-color:#fef4f3 transparent transparent transparent;
        }
        .el-form-item .el-form-item--small{
            margin-bottom: 14px !important;
        }
    }

</style>

