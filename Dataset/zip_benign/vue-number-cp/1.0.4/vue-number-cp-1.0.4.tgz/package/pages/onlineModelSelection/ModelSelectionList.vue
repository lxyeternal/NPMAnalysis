<template>
    <div class="product">
        <PanelTitle :tabs="tabs" @select="handleChangeTab" :titleButton="canCreateNew" @handleOpen="handleOpenDialog"></PanelTitle>
        <!-- 查询条件 -->
        <div class="panel-content">

            <el-form class="form" :model="form" size="small" label-width="80px">
                <el-row>
                    <el-col :span="24">
                        <el-form-item label="选型项目">
                            <el-input v-model="form.selectionName" placeholder="请输入选型项目名称,限20字" maxlength="20"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <SelectCategory :marginLeft="'margin18'" @formData="getCategoryForm" :form="form" :clear="clearCategory"></SelectCategory>
                <el-row>
                    <el-col :span="24" class="form-btns">
                        <el-button type="primary" size="small" @click="handleSearch">搜索</el-button>
                        <el-button size="small" @click="handleClear">清除</el-button>
                    </el-col>
                </el-row>
            </el-form>
        </div>
        <div class="product-table">
            <!-- 列表 -->
            <div v-if="fixedhead" class="fixedhead">
                <ul>
                    <li style="width:149px;padding-left: 0;">选型编号</li>
                    <li style="width:275px">选型项目</li>
                    <li style="width:144px" class="pointer" @click="handleSort()">创建时间
                        <i class="el-icon-caret-top active" v-if="form.sort === '1'"></i>
                        <i class="el-icon-caret-bottom active" v-if="form.sort === '2'"></i>
                    </li>
                    <li  style="width:166px">品类</li>
                    <li  style="width:103px">状态</li>
                    <li style="width:113px;padding-right: 10px;">操作</li>
                </ul>
            </div>
            <table>
                <thead ref="head">
                <tr class="tc">
                    <td style="width:144px;padding-left: 0;">选型编号</td>
                    <td style="width:266px">选型项目</td>
                    <td style="width:140px" class="pointer" @click="handleSort()">创建时间
                        <i class="el-icon-caret-top active" v-if="form.sort === '1'"></i>
                        <i class="el-icon-caret-bottom active" v-if="form.sort === '2'"></i>
                    </td>
                    <td  style="width:160px">品类</td>
                    <td  style="width:100px">状态</td>
                    <td style="width:100px;padding-right: 10px;">操作</td>
                </tr>
                </thead>
                <template v-if="selectionList.length">
                    <tbody v-for="(sel,index) in selectionList" :key="index" class="tl tbody-row">
                        <tr>
                            <td style="width:144px;padding-left: 0;">{{sel.selectionNo}}</td>
                            <td  style="width:266px">{{sel.selectionName}}</td>
                            <td  style="width:140px">{{sel.creTm}}</td>
                            <td  style="width:160px">{{sel.categoryFullName}}</td>
                            <td style="width:100px" :class="{'fixed-padding':fixedhead}">{{sel.statusDisp}}</td>
                            <td class="tr" style="width:100px;padding-right: 10px;">
                                <!--<ModelSelectionOperation :order="product"></ModelSelectionOperation>-->
                                <ModelSelectionOperation :mainSelection="sel.mainSelection" :subSelection="!sel.mainSelection" :selectionInfo="sel" @refrash="handleRefrash"></ModelSelectionOperation>
                            </td>
                        </tr>
                    </tbody>
                </template>
            </table>
            <div class="table-pagination" v-if="selectionList.length">
                <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
                </el-pagination>
            </div>

            <!-- 空列表 -->
            <div class="product-empty" v-if="!selectionList.length&&!isLoading">
                <img src="@/assets/images/icon-no-product.png">
                <p>没有搜索到相关选型，请重新修改搜索条件搜索！</p>
            </div>
        </div>
        <el-dialog class="dialog" title="创建选型项目" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="850px" center :close-on-click-modal="false" @close="handleCloseDialog()">
            <div class="panel-content dialog-cont">
                <el-form class="dialog-form" :model="categoryForm" size="small" label-width="80px">
                    <el-row>
                        <el-col :span="24">
                            <el-form-item required label="选型项目">
                                <el-input v-model="categoryForm.selectionName" placeholder="请输入选型项目名称,限20字" maxlength="20"></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <SelectCategory ref="selectCategory" :marginLeft="'margin9'" :required="true" :label="'选择品类'" @formData="getDialogCategoryForm" :form="categoryForm"></SelectCategory>
                    <div class="tips red tl">
                        ※目前能选择的品类是能辅助选型决策的优质数据。后续会逐步开放其余品类，敬请期待。
                    </div>
                    <el-row>
                        <el-col :span="24" class="form-btns">
                            <el-button type="primary" size="small" :disabled="!canCreact" @click="createSelectionProject">下一步</el-button>
                            <el-button size="small" @click="handleCloseDialog">取消</el-button>
                        </el-col>
                    </el-row>
                </el-form>
            </div>
        </el-dialog>
        <PointComponent v-if="mainSelection && isShowPoint" v-model="isShowPoint"
                        :forceState="false"
                        :imgPath="'createSelection'"
                        :imgNum="2"
                        :targetId="userinfo.acctId"
                        :targetKey="'USER_CREATE_SELECTION_COUNT'"
                        @close="isShowPoint = false"
        ></PointComponent>
        <Loading :is-loading="isLoading"></Loading>
        <!-- 确认合同/批量确认合同 -->
    </div>
</template>

<script>
    import accountMixin from "@/mixins/account";
    import Loading from "@/components/base/Loading";
    import PanelTitle from "@/components/base/PanelTitle";
    import SelectCategory from "@/components/onlineModelSelection/SelectCategory";
    import ModelSelectionOperation from "@/components/onlineModelSelection/ModelSelectionOperation";
    import { InterfaceService } from "@/services/api";
    import PointComponent from '@/components/base/PointComponent';

    const params = {
        sort: "2",
        firstCate: "",
        secondCate: "",
        pageIndex: 1,
        pageSize: 10,
        statusList: ["processing","approving","approved","confirmed"],
        selectionName: "",
        categoryId: "",
    };
    const categoryForm = {
        selectionName: "",
        firstCate: "",
        secondCate: "",
        categoryId: "",
    };
    export default {
        mixins: [accountMixin],
        components: {
            Loading,
            PanelTitle,
            ModelSelectionOperation,
            SelectCategory,
            PointComponent,
        },
        data() {
            return {
                tab: "2",
                tabs: [
                    { label: "待发布", index: "1" },
                    { label: "进行中", index: "2", active: true },
                    { label: "已结束", index: "3"},
                ],
                form: Object.assign({}, params),
                categoryForm: Object.assign({}, categoryForm),
                allChecked: false,
                disableAllCheck: false,
                hasChecked: false,
                dialogVisible: false,
                isShowPoint: true,
                forceState: true,
                sortList: [2, 0, 0],
                priceList: [
                    { label: "全部", value: "" },
                    { label: "战略价(税前)", value: "A" },
                    { label: "市场价(税前)", value: "D" },
                    { label: "协议价(税前)", value: "Negotiated" }
                ],
                statusList: [],
                categoryList: [],
                categorySecondList: [],
                categoryThirdList: [],
                overStatusList: [],
                selectionList: [],
                total: 0,
                isLoading: false,
                fixedhead: false, // 是否显示固定表头
                signFlag: false,
                clearCategory: false,
                mainSelection: false,
                subSelection: false,
                storeParams: {},
            };
        },
        computed: {
            canCreact() {
                let bool = false;
                if (this.categoryForm.selectionName && this.categoryForm.categoryId) {
                    bool = true
                }
                return bool
            },
            canCreateNew() {
                let str = "";
                this.roleIds.forEach(role=>{
                    if (role.roleId == "615") {
                        str = "创建选型项目"
                    }
                });
                return str
            }
        },
        methods: {
            // 修改tab
            handleChangeTab(tab) {
                this.tab = tab.index;
                this.form.statusList = []
                if (tab.index == "1") {
                    this.form.statusList.push("draft")
                }else if (tab.index == "2") {
                    this.form.statusList.push("processing","approving","approved","confirmed")
                }else {
                    this.form.statusList.push("finished","canceled")
                }
                this.form.pageIndex = 1;
                this.form.sort= "2";
                this.form.firstCate= "";
                this.form.secondCate="";
                this.form.selectionName= "";
                this.form.categoryId= "";
                this.getGoodsSelectionList();
            },
            handleOpenDialog(){
                this.dialogVisible = true;
            },
            handleRefrash(type,bool) {
                if (type === "cancel" && this.mainSelection) {
                    this.form.statusList = ["finished","canceled"];
                    this.tabs = [
                        { label: "待发布", index: "1" },
                        { label: "进行中", index: "2"},
                        { label: "已结束", index: "3", active: true },
                    ];
                    this.tab = "3"
                }
                this.getGoodsSelectionList();
            },
            getCategoryForm(form){
                this.form = Object.assign(this.form,form);
                this.clearCategory = false
            },
            getDialogCategoryForm(form) {
                // this.form = Object.assign(this.categoryForm,form);
            },
            createSelectionProject() {
                this.dialogVisible = false;
                // this.$router.push({
                //     path: "/createSelectionCategory",
                //     query:{ categoryForm:JSON.stringify(this.categoryForm) }
                // });
                const { href } = this.$router.resolve({
                    path: "/createSelectionCategory",
                    query: {
                        categoryForm:JSON.stringify(this.categoryForm)
                    },
                });
                window.open(href, '_blank');
            },
            onScroll(){
                // let top = this.$refs["head"] && (this.$refs["head"].getBoundingClientRect().top || 0);
                let scrolled = document.documentElement.scrollTop || document.body.scrollTop
                // console.log(top);
                // this.fixedhead = top <= 0;
                this.fixedhead = scrolled >= 510;
            },
            // 清除
            handleClear() {
                this.form.pageIndex = 1;
                this.form.sort= "2";
                this.form.firstCate= "";
                this.form.secondCate="";
                this.form.selectionName= "";
                this.form.categoryId= "";
                this.clearCategory = true
            },
            // 搜索
            handleSearch() {
                if (this.form.status) {
                    this.form.orderStatus = [this.form.status];
                }

                if (this.form.externalCode) {
                    this.form.sysCode = 'ERP';
                } else {
                    delete this.form.sysCode;
                    delete this.form.externalCode;
                }

                if (this.tab > 3) {
                    delete this.form.searchType;
                }

                this.getGoodsSelectionList();
            },
            // 排序
            handleSort() {
                if (this.form.sort === "1") {
                    this.form.sort = "2"
                }else {
                    this.form.sort = "1"
                }
                this.getGoodsSelectionList();
            },
            //关闭弹窗
            handleCloseDialog() {
                this.dialogVisible = false
                this.categoryForm = Object.assign({}, categoryForm);
            },
            // 刷新列表
            handleRefresh() {
                this.getGoodsSelectionList();
            },
            // 分页跳转
            handleCurrentChange(page) {
                this.form.pageIndex = page;
                this.getGoodsSelectionList();
                window.scrollTo(0,0)
            },
            init() {
                this.roleIds.forEach(role=>{
                    if (role.roleId == "616") {
                        this.subSelection = true;
                        this.tabs= [
                            { label: "进行中", index: 2 , active: true },
                            { label: "已结束", index: 3 },
                        ]
                        this.form.statusList = ["processing","approving","approved","confirmed"]
                    }
                    if (role.roleId == "615") {
                        this.mainSelection = true;
                    }
                });
                if (this.mainSelection) {
                    if (this.$route.query.type === "draft") {
                        this.form.statusList = ["draft"]
                        this.tabs = [
                            { label: "待发布", index: "1" , active: true },
                            { label: "进行中", index: "2"},
                            { label: "已结束", index: "3"},
                        ];
                        this.tab = "1"
                    }else if (this.$route.query.type === "cancel" && this.mainSelection) {
                        this.form.statusList = ["finished","canceled"];
                        this.tabs = [
                            { label: "待发布", index: "1" },
                            { label: "进行中", index: "2"},
                            { label: "已结束", index: "3", active: true },
                        ];
                        this.tab = "3"
                    }else {
                        this.form.statusList = ["processing","approving","approved","confirmed"]
                        this.tabs = [
                            { label: "待发布", index: "1"},
                            { label: "进行中", index: "2" , active: true },
                            { label: "已结束", index: "3"},
                        ];
                        this.tab = "2"
                    }
                }

                    this.getGoodsSelectionList();
                // this.initCategoryList();
            },
            getGoodsSelectionList() {
                let params = {};
                for (let i in this.form) {
                    if (this.form[i]) {
                        params[i] = this.form[i];
                    }
                }
                params.categoryId = params.categoryId || params.secondCate || params.firstCate || "";
                InterfaceService.getGoodsSelectionList(
                    params,
                    data => {
                        //console.log(data);
                        if (data.respData.respCode === "0000") {
                            this.selectionList = data.respData.selectionList || [];
                            this.selectionList.forEach(item=>{
                                item.mainSelection = false;
                                item.selectorList.forEach(_item=>{
                                    if (this.mxAcctIdList.includes(_item.acctId) && _item.selectionRole === "main") {
                                        item.mainSelection = true
                                    }
                                })
                            });
                            this.total = +data.respData.totalCount;
                            this.form.pageSize = +data.respData.pageSize;
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
        },
        mounted() {
            this.init();
            this.$nextTick(function () {
                setTimeout(()=>{
                    window.addEventListener('scroll', this.onScroll)
                },500)
            })
        },
        destroyed: function () {
            window.removeEventListener('scroll', this.onScroll)
        }
    };
</script>

<style lang="scss" scoped>
    .hand + .hand {
        margin-left: 10px;
    }
    .price-tip {
        cursor: pointer;
        color: #a9a9aa;

        &:hover {
            color: #0082ff;
        }
    }

    .product {
        font-size: 14px;
    }

    .pointer {
        cursor: pointer;
        &:hover {
            color: #0082ff;
        }
        &:active {
            color: #4c9cdd;
        }

        .active {
            color: #ffd64e;
        }
    }

    .nowrap {
        white-space: nowrap;
    }

    .panel-content {
        margin-bottom: 20px;
        padding: 20px 10px 0;
        background: #f5f5f5;
    }

    .form {
        /*height: 135px;*/

        /deep/ .el-col {
            height: 52px;
        }

        /deep/ .el-select {
            width: 100%;
        }

        /deep/ .el-date-editor {
            input.el-input__inner {
                padding: 0 15px;
            }
            .el-input__prefix {
                display: none;
            }
        }

        &:after {
            display: table;
            content: "";
            clear: both;
        }
    }
    .dialog-form{
        height: 166px;
    }
    .form-item {
        position: relative;
        display: inline-block;
        line-height: 32px;

        .float-right {
            position: absolute;
            top: 2px;
            right: 1px;
            height: 30px;
            padding: 0 7px;
            line-height: 30px;
            background: #ffffff;
        }
    }

    .error-info {
        color: #f56c6c;
        font-size: 12px;
        line-height: 1;
        padding-top: 4px;
        position: absolute;
        top: 100%;
        left: 0;
    }

    .form-btns {
        text-align: center;
    }
    .dialog-cont{
        background: #fff;
        margin-bottom: 0;
        padding-bottom: 0;
        padding-top: 0;
        /deep/ .el-button {
            width: 100px;
        }
    }
    .product-table {
        position: relative;
        /deep/ .el-table__body-wrapper {
            font-size: 12px;
        }

        /deep/ .el-table th,
        .el-table td {
            padding: 14px 0;
        }

        /deep/ .el-button {
            font-size: 12px;
        }

        table {
            width: 100%;
            line-height: 23px;
            font-size: 12px;
            td {
                padding: 14px 30px;
                vertical-align: middle;
                word-break: break-word;
            }

            thead {
                font-size: 14px;
                text-align: center;
                white-space: nowrap;
                color: #909399;
                background: #f5f5f5;
            }

            .tbody-row:hover {
                background: #e8f3fd;
            }
            .tbody-row .nailsupply{
                display: inline-block;
                max-width: 100%;
                min-height: 14px;
                padding: 0 6px;
                line-height: 14px;
                border: 1px solid #ffa300;
                border-radius: 7px;
                color: #ffa300;
                margin-right: 6px
            }
            tbody {
                text-align: center;

                tr {
                    &.sign-content {
                        display: none;
                        background: #f0f8ff;

                        &:hover {
                            display: table-row;
                        }

                        td {
                            padding: 0;
                            border-bottom: none;
                        }
                    }

                    &.all-check {
                        text-align: left;

                        &:hover{
                            background: #ffffff;
                        }
                    }
                }

                tr:hover + tr.sign-content {
                    display: table-row;
                }

                td {
                    border-bottom: 1px solid #ebeef5;
                }
            }
        }

        .product-name {
            display: inline-flex;
            width: 100%;
            vertical-align: top;
            line-height: 20px;

            img {
                width: 75px;
                height: 75px;
            }

            .left {
                margin-right: 10px;
            }

            .right {
                text-align: left;

                p:first-child {
                    margin-bottom: 10px;
                }
                p:last-child {
                    word-break: break-all;
                    max-height: 40px;
                    overflow: hidden;
                    color: #969799;
                }
            }
        }
    }

    .product-empty {
        padding: 150px;
        text-align: center;
        line-height: 50px;
        color: #909399;
    }

    .price-popover {
        display: flex;
        color: #ababac;

        > div:first-child {
            margin-right: 10px;
        }

        p:first-child {
            padding: 0 5px;
            border-left: 3px solid #ffd64e;
            line-height: 15px;
        }

        p:last-child {
            margin-top: 10px;
            color: #ffffff;
        }
    }

    .table-pagination {
        margin: 50px 0 80px;
        text-align: center;
        color: #888888;
    }
    /deep/ .el-dropdown-menu__item{
        min-height: 14px;
        line-height: 14px;
        border: 1px solid #ffa300;
        border-radius: 7px;
        color: #ffa300;
        cursor: default;
        margin-top: 5px;
        &:hover{
            color: #ffa300;
            background: #fff;
        }
        &:first-child {
            margin-top:  0;
        }
    }
    .tips{
        margin: -10px 0 20px 80px;
    }
    .fixedhead{
        width: 950px;
        height: 30px;
        position: fixed;
        text-align: center;
        top: 0;
        z-index: 9999;
        background: #535864;
        color: #fff;
        li{
            float: left;
            line-height: 30px;
            padding: 0 30px;
            font-size: 14px;
        }
    }
</style>




