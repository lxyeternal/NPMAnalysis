<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <SearchBar :search-type="5" :progress="mainSelection ? selectionInfo.status === 'canceled' ? '选型项目详情': '在线选型详情': '选型项目详情'" :is-border-bottom="true" :product-create-process="2"></SearchBar>
        <div class="inner-container">
            <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
            <div class="cancel-cont" v-if="selectionInfo.status === 'canceled'">
                <span>
                    主选型人已撤销选型项目!
                </span>
                <div>
                    <p>
                        撤销原因：{{selectionInfo.reason}}
                    </p>
                    <p v-if="selectionInfo.uptTm">
                        撤销时间：{{selectionInfo.uptTm.substring(0, selectionInfo.uptTm.length - 6)}}
                    </p>
                </div>
            </div>
            <div class="panel-content">
                <el-row>
                    <el-col :span="24">
                        <label>选型编号：</label>{{selectionInfo.selectionNo}}
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <label>创建时间：</label>{{selectionInfo.creTm}}
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <label>选型项目：</label>{{selectionInfo.selectionName}}
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24" style="height: 16px;">
                        <label>选择品类：</label>{{selectionInfo.categoryFullName}}
                    </el-col>
                </el-row>
                <el-row style="margin-bottom: 0;">
                    <el-col :span="24">
                        <label>主选型人：</label>{{this.mainSelector}}<span v-if="selectionInfo.mainSelectorMobile">(Tel:{{selectionInfo.mainSelectorMobile}})</span>
                    </el-col>
                </el-row>
            </div>
            <div class="info-title">
                <span class="order-info-title bold fl">生成选型清单</span>
            </div>
            <SupplierDetailList
                    v-if="selectionInfo.selectionSupplierList"
                    :mainSelection="mainSelection"
                    :subSelection="!mainSelection"
                    :selectionNo = "selectionInfo.selectionNo"
                    :selectionName = "selectionInfo.selectionName"
                    :selectionInfo = "selectionInfo"
                    :hasSub = "hasSub"
                    :lastNoticeTm = "lastNoticeTm"
                    :supplierDetailList="selectionInfo.selectionSupplierList"
                    @refresh = "getGoodsSelectionDetail"
                    @operationTips = "operationTips"
                    :detail = "true"
            ></SupplierDetailList>
            <div class="info-title">
                <span class="order-info-title bold fl">协同选型</span>
            </div>
            <el-row class="coordination-content tl">
                <el-col :span="12" v-for="(item,ind) in filterSelector(selectorList)" :key="ind" v-if="hasSub">
                    <span>协同选型人员{{ind+1}}：{{item.custName}}</span><span v-if="item.mobile">(Tel:{{item.mobile}})</span>
                    <em v-if="item.dept">{{item.dept}}</em>
                    <em v-if="item.title">{{item.title}}</em>
                </el-col>
                <el-col :span="12" v-if="!hasSub">
                    <span>暂无协同选型人</span>
                </el-col>
            </el-row>
        </div>
        <FixBottom v-if="selectionInfo.status === 'canceled' && mainSelection">
            <div class="fix-bottom">
                <el-button type="primary" style="width: 120px;" @click="handleReCreate()">重新创建</el-button>
                <!--<el-button v-if="locked && selectionInfo.status !== 'canceled'" type="primary" style="width: 120px;" @click="quickBuy()">快速采购</el-button>-->
                <!--<el-button style="width: 120px;" @click="handleGoBack()">上一步</el-button>-->
                <el-button style="width: 120px;" @click="handleGoList()">关闭</el-button>
            </div>
        </FixBottom>
        <FixBottom v-if="selectionInfo.status !== 'canceled' && !mainSelection && showSendingBtn">
        <!--<FixBottom>-->
            <div class="fix-bottom">
                <p class="fl">若您已选完型，请点击【发送通知】按钮，系统将选型结果自动通知给主选型人。</p>
                <el-button class="fr" type="primary" style="width: 120px;" @click="subSelectionSendNotice()">发送通知</el-button>
            </div>
        </FixBottom>
        <FixBottom v-if="mainSelection && showQuickBuy && selectionInfo.status !== 'canceled'">
            <div class="fix-bottom">
                <el-button type="primary" style="width: 120px;" @click="getSelectionFile">快速采购</el-button>
                <el-button style="width: 120px;" @click="handleGoList()">关闭</el-button>
            </div>
        </FixBottom>
        <PointComponent v-if="isShowPoint" v-model="isShowPoint"
                        :forceState="false"
                        :imgPath="mainSelection ? 'onlineSelection' : 'subOnlineSelection'"
                        :imgNum="mainSelection ? 2 : 1"
                        :targetId="userinfo.acctId"
                        :targetKey="mainSelection ? 'USER_ONLINE_SELECTION_COUNT' : 'USER_SUB_ONLINE_SELECTION_COUNT'"
                        @close="isShowPoint = false"
        ></PointComponent>
        <SelectionQuickBuy ref="SelectionQuickBuy"></SelectionQuickBuy>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>
<script>
    import Header from "@/components/base/Header";
    import SearchBar from "@/components/SearchBar";
    import Loading from "@/components/base/Loading";
    import Breadcrumb from "@/components/base/Breadcrumb";
    import SupplierDetailList from "@/components/onlineModelSelection/SupplierDetailList";
    import SelectionQuickBuy from "@/components/onlineModelSelection/dialog/SelectionQuickBuy";
    import { InterfaceService } from "@/services/api";
    import accountMixin from "@/mixins/account";
    import FixBottom from "@/components/base/FixBottom";
    import PointComponent from '@/components/base/PointComponent';
    const params = {
        selectionNo: "",
        selectionName: "",
        searchParam: "",
        categoryId: "",
        categoryName: "",
        listCreationFlg: "",
        searchFlg: "",
        assessLevelList:[],
        riskLevelList:[],
        prodLevelList:[],
        prodFromList:[],
        attrList:[],
    };
    export default {
        mixins: [accountMixin],
        components: {
            Header,
            SearchBar,
            Loading,
            Breadcrumb,
            SupplierDetailList,
            FixBottom,
            PointComponent,
            SelectionQuickBuy,
        },
        data() {
            return {
                isLoading: false,
                subSelection: false,
                mainSelection: false,
                locked: false,
                hasSub: false,
                showSendingBtn: false,
                showQuickBuy: false,
                isShowPoint: false,
                lastNoticeTm: "",
                selectionInfo: {},
                breadcrumb: [],
                supplierDetailList: [],
                attrList: [],
                lastCreTmList: [],
                form: Object.assign({}, params),
                selectorList: [],
                mainSelector: "",
            };
        },
        computed: {
        },
        methods: {
            operationTips(ind) {
                this.lastCreTmList.forEach(item=>{
                    if (item.ind === ind) {
                        item.closed = true
                    }
                })
            },
            getGoodsSelectionDetail(type) {
                InterfaceService.getGoodsSelectionDetail({
                    selectionNo:this.selectionInfo.selectionNo || ""
                }, data => {
                    let res = data.respData|| {}
                    if (data && data.respData && res.respCode === "0000") {
                        this.selectionInfo = Object.assign(this.selectionInfo,data.respData || {});
                        this.supplierDetailList = res.selectionSupplierList;
                        this.lastNoticeTm = res.lastNoticeTm || "";
                        this.locked = this.supplierDetailList.some(item=>{
                            return item.lockFlg === "1";
                        });
                        let lastTimeList = []
                        this.showQuickBuy = false;
                        // 三角和粉色提示条显示
                        this.supplierDetailList = this.supplierDetailList.sort(this.compare)
                        this.supplierDetailList.forEach((item,ind)=>{
                            if (item.mergeUploadFlg) {
                                this.showQuickBuy = true
                            }
                            if (item.corpStatus !== "1") {
                                item.tags.push({
                                    tagId: "out",
                                    tagName: "未入驻"
                                })
                            }
                            item.creTmList = [];
                            item.subPersonList = [];
                            item.subListUpLoadInfos && item.subListUpLoadInfos.forEach(_item=>{
                                item.subPersonList.push(_item.custName);
                                item.creTmList.push(_item.creTm);
                                let onOff = false;
                                this.lastCreTmList.forEach(tm=>{
                                    if (tm.ind === ind) {
                                        onOff = true
                                    }
                                });
                                if (!onOff) {
                                    this.lastCreTmList.push({
                                        creTm:item.creTmList.sort()[item.creTmList.length-1],
                                        ind:ind,
                                        closed:false,
                                    });
                                }
                                if (type) {
                                    item.showTips = true;
                                }else {
                                    this.lastCreTmList.forEach(__item=>{
                                        if (__item.ind === ind) {
                                            console.log(__item.creTm,item.creTmList.sort()[item.creTmList.length - 1]);
                                            if (__item.creTm < item.creTmList.sort()[item.creTmList.length-1]) {
                                                item.showTips = true;
                                                __item.creTm = item.creTmList.sort()[item.creTmList.length-1]
                                            }else {
                                                item.showTips = __item.closed === false;
                                            }
                                        }
                                    });
                                }
                                item.showPoint = true;
                            });

                            if (item.creTmList.length) {
                                lastTimeList.push(item.creTmList.sort()[item.creTmList.length-1])
                            }
                        });
                        this.showSendingBtn = lastTimeList && lastTimeList.sort()[lastTimeList.length-1] > this.lastNoticeTm || (lastTimeList && lastTimeList.length && !this.lastNoticeTm);
                        this.selectorList = res.selectorList || [];
                        this.hasSub = this.selectorList.length > 1;
                        this.selectorList.forEach(item=>{
                            if (item.selectionRole === "main") {
                                this.mainSelector = item.custName
                            }
                            if (item.selectionRole === "main" && this.mxAcctIdList.includes(item.acctId)) {
                                this.mainSelection = true
                            }
                        });
                        this.$setRootScope('selectionRole', this.mainSelection);
                        if (this.selectionInfo.status !== 'canceled' && type) {
                            this.isShowPoint = this.$route.query.detail !== "detail";
                            this.form.selectionName = res.selectionName;
                            this.form.selectionNo = res.selectionNo;
                            this.form.firstCate = res.categoryLv1Id;
                            this.form.secondCate = res.categoryLv2Id;
                            this.form.categoryId = res.categoryLv3Id;
                            let searchParam = JSON.parse(res.searchParam);
                            this.form.assessLevelList = searchParam.assessLevelList || []
                            this.form.riskLevelList = searchParam.riskLevelList || [];
                            this.form.prodLevelList = searchParam.prodLevelList || [];
                            this.form.prodFromList = searchParam.prodFromList || [];
                            this.form.attrList = searchParam.attrList || [];
                            this.form.searchFlg = type;
                            this.getGoodsFromCategory(type);
                        }
                        this.changeBreadcrumb();
                    } else {
                        this.$message.error(data.respData.respMsg)
                    }
                }, data => { }, () => {
                    this.isLoading = true
                }, () => {
                    this.isLoading = false
                })
            },
            compare (obj1, obj2) {
                let val1 = obj1.corpStatus;
                let val2 = obj2.corpStatus;
                if (val1 < val2) {
                    return -1;
                } else if (val1 > val2) {
                    return 1;
                } else {
                    return 0;
                }
            },
            getGoodsFromCategory(type) {
                if (type === "create") {
                    this.form.searchParam = JSON.stringify(this.form);
                }else {
                    this.form.searchParam = "";
                }
                let params = Object.assign({},this.form);
                InterfaceService.getGoodsFromCategory(
                    params,
                    data => {
                        let res = data.respData;
                        if (res.respCode === "0000") {
                            if (type === "diffSearch") {
                                if (res.prodChangeCnt != "0") {
                                    this.$alert(
                                        "该项目的候选商品已发生变化，系统将为您重新生成选型清单。",
                                        {
                                            customClass: "alert-box",
                                            center: true,
                                            confirmButtonText: "知道了",
                                            callback: action => {
                                                this.form.searchFlg = "createList";
                                                this.getGoodsFromCategory("create")
                                            }
                                        }
                                    );
                                }
                            }else {
                                this.getGoodsSelectionDetail()
                            }
                        } else {
                            this.$message.error(res.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleGoList(){
                window.opener=null;
                window.close();
            },
            subSelectionSendNotice() {
                InterfaceService.subSelectionSendNotice({
                    selectionNo:this.selectionInfo.selectionNo || ""
                }, data => {
                    let res = data.respData|| {};
                    if (data && data.respData && res.respCode === "0000") {
                        this.showSendingBtn = false;
                        this.$message.success("发送通知成功")
                    } else {
                        this.$message.error(data.respData.respMsg)
                    }
                }, data => { }, () => {
                    this.isLoading = true
                }, () => {
                    this.isLoading = false
                })
            },
            handleReCreate() {
                this.selectionInfo.firstCate = this.selectionInfo.categoryLv1Id;
                this.selectionInfo.secondCate = this.selectionInfo.categoryLv2Id;
                this.$router.push({
                    path: "/createSelectionCategory",
                    // query:{selectionNo:this.selectionInfo.selectionNo}
                    query:{ categoryForm:JSON.stringify(this.selectionInfo) }
                });
            },
            getSelectionFile() {
                const params = {
                    selectionNo : this.selectionInfo.selectionNo,
                    supplierId : "",
                };
                InterfaceService.selectionFileDownload(
                    params,
                    data => {
                        let res = data.respData|| {};
                        if (data && data.respData && res.respCode === "0000") {
                            this.supplierDetailList.forEach(item=>{
                                res.supplierDetailList.forEach(_item=>{
                                    if (item.corpId === _item.corpId) {
                                        item.selectionAttachList = _item.selectionAttachList
                                    }
                                })
                            });
                            // this.supplierDetailList.selectionSupplierList = res.supplierDetailList || [];
                            this.quickBuy();
                        } else {
                            this.$message.error(data.respData.respMsg)
                        }
                    }, data => {
                        this.$message.error(data.respData.respMsg)
                    },
                    () => {
                        this.isLoading = true
                    }, (

                    ) => {
                        this.isLoading = false
                    }
                )
            },
            //快速采购
            quickBuy() {
                this.$refs["SelectionQuickBuy"].open(this.selectionInfo)
            },
            filterSelector(list){
                return list.length && list.filter(item=>{
                    return item.selectionRole === "sub"
                })
            },
            init() {
                // this.roleIds.forEach(role=>{
                //     if (role.roleId == "616") {
                //         this.subSelection = true;
                //     }
                //     if (role.roleId == "615") {
                //         this.mainSelection = true;
                //     }
                // });
                this.selectionInfo = eval('(' + this.$route.query.selectionInfo + ')');
                this.getGoodsSelectionDetail('diffSearch');
            },
            changeBreadcrumb(){
                let name = "";
                if (this.selectionInfo.status === 'canceled') {
                    name = "查看详情"
                }else {
                    name = this.mainSelection ? this.selectionInfo.status === 'canceled' ? '选型详情': '在线选型' : "去选型"
                }
                if (!this.mainSelection) {
                    this.breadcrumb = [
                        { name: '首页', path: '/home' },
                        { name: '管理中心', path: '/purchaserCenter/accountInfo'},
                        { name: '选型管理',path:'/purchaserCenter/modelSelectionList'},
                        { name: '协同选型',path:'/purchaserCenter/modelSelectionList'},
                        { name: name,path:''},
                    ];
                }else {
                    this.breadcrumb = [
                        { name: '首页', path: '/home' },
                        { name: '管理中心', path: '/purchaserCenter/accountInfo'},
                        { name: '选型管理',path:'/purchaserCenter/modelSelectionList'},
                        { name: '在线选型',path:'/purchaserCenter/modelSelectionList'},
                        { name: name,path:''},
                    ];
                }

            }
        },
        mounted() {
            this.init()
        }
    };
</script>
<style lang="scss" scoped>
    .inner-container {
        margin-bottom: 100px;
        font-size: 14px;
    }
    .el-button{
        height: 20px;
        line-height: 20px;
        padding-top: 0;
    }
    /deep/ .el-col{
        padding: 0 10px;
    }
    .fix-bottom{
        width: 100%;
        height: 40px;
        margin: 0 auto;
        text-align: center;
        .el-button{
            height: 40px;
            line-height: 40px;
        }
        p {
            color: #fff;
            line-height: 40px;
            font-size: 14px;
        }
    }
    .panel-content {
        .el-row{
            margin-bottom: 15px;
        }
        margin-bottom: 20px;
        padding: 20px 10px;
        background: #f5f5f5;
    }
    .form {
        /deep/ .el-col {
            height: 52px;
        }

        /deep/ .el-select {
            width: 100%;
        }

        /deep/ .el-date-editor {
            input.el-input__inner {
                padding: 0 15px;
            }
            .el-input__prefix {
                display: none;
            }
        }

        &:after {
            display: table;
            content: "";
            clear: both;
        }
    }
    .order-info-title {
        margin: 5px 0;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
        width: 300px;
    }
    .info-title {
        &:after {
            display: table;
            content: "";
            clear: both;
        }
    }
    .coordination-content{
        margin: 10px 0;
        padding: 20px;
        background: #f5f5f5;
        .el-col {
            padding: 10px;
        }
        em {
            margin-left: 8px;
        }
    }
    .cancel-cont{
        padding: 20px;
        background: #ffe9eb;
        border: 1px solid #E82835;
        min-height: 70px;
        margin-bottom: 10px;
        span{
            float: left;
            height: 30px;
            line-height: 30px;
            padding-right: 10px;
            font-size: 18px;
            border-right: 1px solid #000;
        }
        div{
            display: inline-block;
            width: 80%;
            padding-left: 10px;
            p{
                line-height: 15px;
                word-break: break-word;
            }
            p:last-child{
                margin-top: 5px;
            }
        }
    }
</style>

