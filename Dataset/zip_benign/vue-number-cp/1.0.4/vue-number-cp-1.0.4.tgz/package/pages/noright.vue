<template>
    <div class="success-wrap">
        <Header></Header>
        <SearchBar :is-white-bg="true" :search-type="5" :progress="''" :is-border-bottom="true" :product-create-process="3"></SearchBar>
        <div class="success-wrap-content" id='success-wrap-content-res'>
            <div class="success-icon"></div>
            <p class="success-text">您没有权限访问该页面</p>
            <!-- <p class="sub-success-text">您可以联系您公司的管理员修改，如果仍有问题请联系 {{$platformContact()['hotLine']}}</p> -->
            <p class="sub-success-text hand" @click="back">
              <span> 返回 </span><span class="blue hand">上一页</span>
            </p>
        </div>
        <!--<ConfluenceFloat :id="'6'"></ConfluenceFloat>-->
        <Footer></Footer>
  </div>
</template>

<script>
import Header from "@/components/base/Header";
import Footer from '@/components/base/Footer'
import SearchBar from "@/components/SearchBar";
import ConfluenceFloat from '@/components/base/ConfluenceFloat'
export default {
    components: {
        Header,
        SearchBar,
        Footer,
        ConfluenceFloat
    },
    data() {
        return {

        };
    },

    methods: {
        init() {
            let w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
            let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
            document.getElementById('success-wrap-content-res').style.height = (h-200-55-34-160) + 'px';
        },
        go(path){
            if(path == 'user'){
                let res = this.$store.state.userInfo;
                  let bs = res.bs && res.bs.toUpperCase()
                  if(bs == 'B') {
                    this.$router.push('/vendorCenter/accountInfo')
                  } else if (bs == 'S') {
                    this.$router.push('/purchaserCenter/accountInfo')
                  }
            }else{
                this.$router.push('/home')
            }

        },
        back(){
            this.$router.go(-1)
        }
    },
    mounted() {
        this.init();
    }
};
</script>

<style lang="scss" scoped>
.success-wrap-content{padding-top:90px;height: 100%;}
.success-icon{width:74px;height:54px;margin:0 auto 25px;background:url(../assets/images/grey_no_right.png) no-repeat 0 0;}
.success-text{font-size:20px;color:#333;text-align:center;}
.sub-success-text{width:540px;font-size:12px;color:#333;text-align:center;margin: 15px auto;line-height:20px;}
</style>