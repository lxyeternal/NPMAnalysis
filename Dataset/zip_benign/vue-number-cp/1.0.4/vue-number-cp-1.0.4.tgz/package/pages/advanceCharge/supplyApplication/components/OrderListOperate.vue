<template>
  <div class="operate">
    <!--供应商-->
    <a @click="handleDraftOfCreateOrder(order)">编辑</a>
              <a @click="handleDel('2',order)">删除</a>
    <!-- <Signature ref="signature" @close="handleCloseSignature"></Signature>
    <Loading :is-loading="isLoading"></Loading> -->
  </div>
</template>

<script>
import Signature from "@/components/order/dialog/Signature";
import Loading from "@/components/base/Loading";

export default {
  components: {
    Loading,
    Signature,
  },
  props: ["order","tab"],
  data() {
    return {
      attach: {},
      rejectionListReasons: '', // 拒绝清单 理由
      selectedList: [],
      isLoading: false,
      refuseDialogOptions: [], // 取消原因
    };
  },
  computed: {
    approveStatus() {
      let status = ''
      let oaApprovalInfo = this.order.externalSysList && this.order.externalSysList.find(i=>{return i.sysCode === 'OA'}) || {};
      status = oaApprovalInfo.approveStatus
      return status
    },
    unconfirmedOrderNosComputed() {
      return subOrderList => {
        return subOrderList.filter(f => f.subOrderStatus == '01') || []
      }
    },
    cancelSupplementList() {
      return data => {
        let item = []
        data && data.subOrderList && data.subOrderList.map(m => {
          if (m.subOrderStatus == '01') {
            const count = Number(m.subOrderNo && m.subOrderNo.split('-') && m.subOrderNo.split('-')[1]) || 1
            item.push(Object.assign(m, { orderCount: count }))
          }
        })
        return item
      }
    },
    userInfo() {
      return this.$store.state.userInfo || {};
    },
  },
  methods: {
  
  },
  mounted() {
    // this.init()
  }
};
</script>

<style lang="scss" scoped>
/deep/ .el-button {
  margin-bottom: 5px;
}

.operate {
  a {
    display: block;
    white-space: nowrap;
    padding: 5px 0 0 5px;
    line-height: 18px;
    color: #0082FF;
    font-size: 12px;
    // text-align: right;
  }
}
/deep/ .el-dropdown {
  width: 100%;
  text-align: right;
}
/deep/ .el-dropdown-menu__item {
  color: #0082FF;
  text-align: right;
  font-size: 12px;
  &:hover {
    color: #0082FF;
    background: #e8f3fd;
  }
  a {
    display: block;
    width: 100%;
    height: 100%;
  }
}
</style>
