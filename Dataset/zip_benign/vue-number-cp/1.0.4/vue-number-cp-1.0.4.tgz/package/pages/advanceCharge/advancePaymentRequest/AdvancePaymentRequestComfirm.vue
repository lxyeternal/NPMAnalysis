<template>
  <div class="statementDeclaredComfirmContainer">
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" progress="预付款申请-确认预付款申请清单" :is-border-bottom="true"></SearchBar>
    <div class="breadcrumb">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
    </div>
    <div class="statement-dec-center">
      <PanelTitle :title="'预付款申请'"></PanelTitle>
      <dl v-if="orderInfo.pmtMethod">
        <dt>付款方式：</dt>
        <dd v-html="orderInfo.pmtMethod && orderInfo.pmtMethod.replace(/\n/g, '<br/>')">
        </dd>
      </dl>
    </div>
    <div class="reminder">
      <p v-if="role == 'B'">
        温馨提示：能选出来的要货单为已生效的要货单（即为用完印的要货单）；开票信息请点击预付款申请单右侧<span class="blue hand" @click="beenReconciled">【开票信息】</span>文字按钮查看，若开票信息账号有误，
        请至<span class="blue hand" @click="handleClicJump(`${role == 'S' ? '/vendorCenter' : '/purchaserCenter'}/enterpriseCertification`)">【管理中心】-【公司管理】-【企业实名认证】</span>页面，【基本户银行账户认证】重新认证成功后，
        系统自动替换。实际开票信息以本平台「基本户银行账户认证」的最新信息为准。
      </p>
      <p v-else>
        温馨提示：能选出来的要货单为已生效的要货单（即为用完印的要货单）。
      </p>
    </div>
    <TableInfo ref="tableInfoRef" :pageSave="true" :tabIndex="tabIndex" @refreshOrderInfoData="tableInfoRefreshData"></TableInfo>

    <Loading :isLoading="isLoading"></Loading>
  </div>
</template>
<script>
import accountMixin from "@/mixins/account";
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Breadcrumb from "@/components/base/Breadcrumb";
import TableInfo from "@/components/advanceCharge/advancePaymentRequest/TableInfo";
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";

export default {
  mixins: [accountMixin],
  components: {
    SearchBar,
    Breadcrumb,
    Header,
    TableInfo,
    PanelTitle,
    Loading
  },
  data() {
    return {
      isLoading: false,
      breadcrumb: [
        { name: '管理中心', path: `/vendorCenter/accountInfo` },
        { name: '请款管理-预付款申请', path: `/vendorCenter/advancePaymentRequestList` },
        { name: '确认预付款申请清单' }
      ],
      tabIndex: 1,
      orderInfo: {}
    }
  },
  computed: {

  },
  methods: {
    beenReconciled() {
      this.$refs['tableInfoRef'].beenReconciled()
    },
    handleClicJump(path) {
      this.$router.push(path)
    },
    tableInfoRefreshData(data) {
      console.log(data, '-data');

      this.orderInfo = data.orderDetailInfo || {}
    },
  },

}
</script>
<style lang="scss" scoped>
.reminder {
  margin: 0 auto;
  width: 1190px;
  background: #fffcf0;
  border: 1px solid #fae2a5;
  padding: 6px 10px 5px 10px;
  span {
    width: 1124px;
    height: 19px;
    font-size: 12px;
    font-family: PingFang SC;
    font-weight: 400;
    line-height: 17px;
    color: #444444;
    opacity: 1;
  }
}
.breadcrumb {
  width: 1190px;
  margin: auto;
}
.multi_line {
  height: 42px;
  display: flex;
  flex-direction: column;
  p {
    flex: 1;
    font-size: 12px;
    line-height: 12px;
  }
}
.statementDeclaredComfirmContainer {
  margin-bottom: 50px;
}
.mt14 {
  margin-top: 14px;
}
.statement-dec-center {
  width: 1190px;
  margin: 10px auto 16px;
  dl {
    display: flex;
    dt {
      color: #888888;
      width: 80px;
      white-space: pre;
    }
    dd {
      color: #444444;
    }
  }
}
</style>