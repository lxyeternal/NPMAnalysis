<template>
  <div class="statementDeclaredComfirmContainer">
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" progress="确认对账清单" :is-border-bottom="true"></SearchBar>
    <div class="breadcrumb">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
    </div>
    <!-- <div class="reminder" v-if="examine">
      <p>温馨提示：能选出来的要货单为已生效的要货单（即为用完印的要货单）；若开票信息有误，请至
        <span class="blue hand" @click="$router.push(`${role == 'S' ? '/vendorCenter' : '/purchaserCenter'}/enterpriseCertification`)">【管理中心】-【公司管理】-【企业实名认证】</span>
        页面，【基本户银行认证成功】重新认证成功后。
      </p>
    </div> -->
    <div class="reminder" v-if="examine">
      <p>
        温馨提示：若开票信息有误，请至p>温馨提示：能选出来的要货单为已生效的要货单（即为用完印的要货单）；若开票信息有误，请至 <span class="blue hand" @click="$router.push(`${role == 'S' ? '/vendorCenter' : '/purchaserCenter'}/enterpriseCertification`)">【管理中心】-【公司管理】-【企业实名认证】</span>页面，【基本户银行账户认证】重新认证成功后，系统自动替换。实际开票信息以本平台「基本户银行账户认证」的最新信息为准。
      </p>
    </div>
    <!-- mt14 -->
    <!-- 有可编辑数据才显示 -->
    <div class="reminder" v-else-if="isEditItem">
      <p>操作小贴士：「采购单价」一列，按shift或ctrl点击多个输入框，鼠标右击并点击【批量填写单价】可批量设置价格；点击【查询价格】可查询浮动商品的价格基准。 </p>
    </div>

    <StatementDeclaredTableInfo :pageSave="true" :tabIndex="1" @refreshData="refreshData"></StatementDeclaredTableInfo>
    <Loading :isLoading="isLoading"></Loading>
  </div>
</template>
<script>
import accountMixin from "@/mixins/account";
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Breadcrumb from "@/components/base/Breadcrumb";
import StatementDeclaredTableInfo from "@/components/advanceCharge/statementDeclared/StatementDeclaredTableInfo";
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";

export default {
  mixins: [accountMixin],
  components: {
    SearchBar,
    Breadcrumb,
    Header,
    StatementDeclaredTableInfo,
    Loading
  },
  data() {
    return {
      // breadcrumb: [
      //   { name: '管理中心', path: '/vendorCenter/accountInfo' },
      //   { name: '请款管理', path: '/purchaserCenter/goodsAuditList' },
      //   { name: '创建对账单申报', path: '/#' },
      //   { name: '确认对账清单' }
      // ],

      breadcrumb: [
        { name: '管理中心', path: `/vendorCenter/accountInfo` },
        { name: '请款管理-对账单申报', path: `/vendorCenter/statementDeclaredList` },
        { name: '确认对账清单' }
      ],
      readStatusChecked: false,
      isLoading: false,
      examine: false,
      tableInfo: {},
      isEditItem: false, // 是否有可编辑数据
    }
  },
  watch: {

  },
  mounted() {
    this.examine = this.$route.query.state == 'examine' || false
  },
  methods: {
    refreshData(data) {
      console.log(data.statementDetailInfo, 'data.statementDetailInfo');

      const statementDetailInfo = data.statementDetailInfo || {}
      const item = statementDetailInfo.statementDetails && statementDetailInfo.statementDetails[0] || {}
      const tableDataList = item.deliveryDetail || []

      this.isEditItem = tableDataList.some(s => s.priceModel == 'floatingPrice')
    },

  },

}
</script>
<style lang="scss" scoped>
.reminder {
  margin: 0 auto;
  width: 1190px;
  height: 30px;
  background: #fffcf0;
  border: 1px solid #fae2a5;
  padding: 6px 10px 5px 10px;
  span {
    width: 1124px;
    height: 19px;
    font-size: 12px;
    font-family: PingFang SC;
    font-weight: 400;
    line-height: 17px;
    color: #444444;
    opacity: 1;
  }
}
.breadcrumb {
  width: 1190px;
  margin: auto;
}
.multi_line {
  height: 42px;
  display: flex;
  flex-direction: column;
  p {
    flex: 1;
    font-size: 12px;
    line-height: 12px;
  }
}
.statementDeclaredComfirmContainer {
  margin-bottom: 50px;
}
.mt14 {
  margin-top: 14px;
}
</style>