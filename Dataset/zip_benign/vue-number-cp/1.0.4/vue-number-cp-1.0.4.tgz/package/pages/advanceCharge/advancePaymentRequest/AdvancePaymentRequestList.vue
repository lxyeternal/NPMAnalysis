<template>
  <div class="statementDeclaredContainer">
    <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>
    <div class="head-btn" v-if="role == 'S'">
      <el-button :type="'primary'" @click="handleClickCreatMostBill">材料预付款申请</el-button>
    </div>
    <!-- 查询条件 -->
    <div class="panel-content">
      <el-form class="form" :model="form" size="small" label-width="85px">
        <el-row>
          <el-col :span="24">
            <el-form-item label="合同名称：">
              <el-input clearable v-model.trim="form.contractName" placeholder="请输入合同关键词或合同编号"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="预付款单号：">
              <el-input clearable style="width: 240px;" v-model.trim="form.statementNo" placeholder="请输入预付款单号"></el-input>
            </el-form-item>
          </el-col>
          <template>
            <el-col :span="8">
              <el-form-item label="采购商：" v-if="userinfo&&userinfo.bs=='S'">
                <el-input clearable style="width: 240px;" v-model.trim="form.purchaserName" placeholder="请输入采购商名称"></el-input>
              </el-form-item>
              <el-form-item label="供应商：" v-if="userinfo&&userinfo.bs=='B'">
                <el-input clearable style="width: 240px;" v-model.trim="form.supplierName" placeholder="请输入供应商名称"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8" v-if="tab != 1||role == 'B'">
              <el-form-item label="申报时间：">
                <el-col :span="11" class="form-item">
                  <el-date-picker clearable :picker-options="pickerOptionsStart" type="date" placeholder="选择时间" value-format="yyyy-MM-dd" v-model="form.applyTmFrom" style="width: 100%;"></el-date-picker>
                </el-col>
                <el-col :span="2" class="tc">~</el-col>
                <el-col :span="11" class="form-item">
                  <el-date-picker clearable :picker-options="pickerOptionsEnd" type="date" placeholder="选择时间" value-format="yyyy-MM-dd" v-model="form.applyTmTo" style="width: 100%;"></el-date-picker>
                </el-col>
              </el-form-item>
            </el-col>

            <el-col :span="16" v-if="brokerRole">
              <el-form-item label="项目公司：">
                <el-select style="width:240px" placeholder="请选择事业部" v-model="form.groupCompanyCode" clearable @change="handleClearGroup" @clear="form.purchaserName = ''">
                  <el-option v-for="(item,index) in groupCompanyList" :key="index" :value="item.code" :label="item.value"></el-option>
                </el-select>
                <el-select style="width:240px" placeholder="请输入关键词搜索选择项目公司" :disabled="!form.groupCompanyCode" v-model="form.purchaserName" filterable clearable>
                  <el-option v-for="(item,index) in projectList" :key="index" :value="item" :label="item"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </template>
        </el-row>
        <div class="txt-center">
          <el-button type="primary" class="small-btn" @click="handleSearch">搜索</el-button>
          <el-button class="small-btn" @click="handleClear">清除</el-button>
        </div>
      </el-form>
    </div>
    <div class="table-container">
      <TableComponent :data="statementList" clearable :tab="tab" :pageIndex="form.pageIndex" :pageSize="form.pageSize" :total="form.pageTotal" @currentChange="handleCurrentChange" @sortChange="handleSort" @refresh="handleRefresh"></TableComponent>
      <!-- 空列表 -->
      <div class="product-empty" v-if="!statementList.length && !isLoading">
        <img src="@/assets/images/icon-no-product.png">
        <p>没有搜索到相关数据，请重新修改搜索条件搜索！</p>
      </div>
    </div>
    <Loading :isLoading="isLoading"></Loading>

    <el-dialog title="预付款申请" class="creatDiaContainer" :visible.sync="creatMostBillDialogVisible" :show-close="false" width="850px">
      <el-form>
        <el-form-item>
          <label slot="label">
            <span class="red">*</span>
            合同名称：
          </label>
          <el-select style="width:719px;" popper-class="selectContractDialogSelectContainer" placeholder="请输入合同名称" filterable remote reserve-keyword :remote-method="remoteContractNameMethod" v-model="orderNo" clearable>
            <el-option :value="item.orderNo" v-for="(item,index) in contractList" :title="item.contractName" :key="index" :label="`${item.clOrderNo || ''} ${item.contractName}`"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-row>
          <el-col :span="24" class="txt-center">
            <el-button type="primary" class="small-btn" :disabled="!orderNo" @click="handleClickNextStep">下一步</el-button>
            <el-button class="small-btn" @click="handleCancel">取消</el-button>
          </el-col>
        </el-row>
      </span>
    </el-dialog>

  </div>
</template>
<script>
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import { InterfaceService } from "@/services/api";
import accountMixin from "@/mixins/account";
import TableComponent from "@/components/advanceCharge/advancePaymentRequest/TableComponent";

const params = {
  contractName: "",
  purchaserName: "",
  supplierName: "",
  applyTmFrom: "",
  applyTmTo: "",
  statementNo: "",
  pageIndex: 1,
  pageTotal: 1,
  pageSize: 10,
  groupCompanyCode: '',
};

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    PanelTitle,
    TableComponent
  },
  data() {
    return {
      tab: "1",
      tabs: [],
      statementList: [],
      contractList: [],
      groupCompanyList: [],
      projectList: [],
      orderNo: '',
      isLoading: false,
      creatMostBillDialogVisible: false,
      form: Object.assign({}, params),
      pickerOptionsEnd: {
        disabledDate: time => {
          if (this.form.applyTmFrom) {
            return time.getTime() <= new Date(this.form.applyTmFrom).getTime() - 86400000
          }
        }
      },
      pickerOptionsStart: {
        disabledDate: time => {
          if (this.form.applyTmTo) {
            return time.getTime() >= new Date(this.form.applyTmTo).getTime()
          }
        }
      },
      searchType: 0,
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      if (this.brokerRole) {
        this.tabs = [
          { label: '进行中', index: 2, active: true, searchType: 1, },
          { label: '已结束', index: 3, searchType: 2, },
        ]
      } else {
        this.tabs = [
          { label: '待处理', index: 1, active: true, searchType: 0, },
          { label: '进行中', index: 2, searchType: 1, },
          { label: '已结束', index: 3, searchType: 2, },
        ]
      }

      const findItem = this.tabs.find(f => f.active) || {}
      this.tab = findItem.index;
      this.searchType = findItem.searchType
      this.brokerRole && this.getBusinessDepartmentList()
      this.queryStatementList()
    },
    handleClickNextStep() {
      // window.open(this.$router.resolve({
      //   path: '/advancePaymentRequestComfirm',
      //   query: {
      //     orderNo: this.orderNo
      //   }
      // }).href, '_blank')
      this.$router.push({
        path: '/advancePaymentRequestComfirm',
        query: {
          orderNo: this.orderNo
        }
      })
      this.creatMostBillDialogVisible = false
    },
    handleCancel() {
      this.creatMostBillDialogVisible = false
    },
    handleClearGroup() {
      console.log('-getBuyersList-');
      this.getBuyersList()
    },

    // 查询供应商
    remoteSearchOrder(searchKey) {
      return new Promise(resolve => {
        // searchSimpleOrderListLimit
        // searchKey,
        // usage: "prepaymentOrder",
        searchKey = searchKey.replace(/(^\s*)|(\s*$)/g, "")
        InterfaceService.getOrderList({
          contractName: searchKey,
          "orderStatus": ["11", "addProduct"], "status": "11", "searchType": "2", 
          // "enterFrom": 1,
          "sort": "2_0_0", "operType": "0"
        }, data => {
          if (data.respData && data.respData.respCode == '0000') {
            this.contractList = []
            this.contractList = data.respData && data.respData.orders || []
            resolve(data.respData && data.respData.orders || [])
          } else {
            this.$message.error(data.respData && data.respData.respMsg);
          }
        }, data => {
        }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },

    async handleClickCreatMostBill() {
      await this.remoteSearchOrder('')
      this.orderNo = ''
      this.creatMostBillDialogVisible = true
    },
    // 排序
    handleSort(arr) {
      this.queryStatementList();
    },
    // 分页跳转
    handleCurrentChange(page) {
      this.form.pageIndex = page;
      this.queryStatementList();
      window.scrollTo(0, 0)
    },
    handleRefresh() {
      this.queryStatementList();
    },

    // 搜索
    handleSearch() {
      this.form.pageIndex = 1
      this.queryStatementList();
    },
    // 修改tab
    handleChangeTab(tab) {
      this.tab = tab.index;
      console.log(tab);
      this.searchType = tab.searchType
      this.form = Object.assign({}, params)
      this.projectList = []
      this.queryStatementList();
    },
    remoteContractNameMethod(e) {
      console.log(e, '--');
      this.remoteSearchOrder(e)
    },
    handleClear() {
      this.form = Object.assign({}, params)
      this.projectList = []
      this.queryStatementList();
    },

    getBuyersList() {
      let param = {
        corpIds: [],
        groupCompanyCode: this.form.groupCompanyCode,
      };
      this.form.purchaserName = ''
      this.projectList = []

      if (!this.form.groupCompanyCode) return
      InterfaceService.getBuyersList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          const purchasers = data.respData.purchasers || [];
          purchasers.forEach(f => {
            f.corpName && this.projectList.push(f.corpName)
          })
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },

    getBusinessDepartmentList() {
      const params = {
        groupId: 'GROUP_COMPANY'
      };
      InterfaceService.getBusinessDepartmentList(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          this.groupCompanyList = res.configList || [];
          this.projectList = [];
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },

    // 获取列表
    queryStatementList() {
      const { contractName, purchaserName, supplierName, applyTmFrom, applyTmTo, statementNo, groupCompanyCode, pageIndex } = this.form || {},

        params = {
          contractName,
          purchaserName,
          supplierName,
          applyTmFrom,
          applyTmTo,
          groupCompanyCode,
          pageIndex,
          statementNo,
          searchType: this.searchType,
          // statementType: this.role == 'B' ? 1 : 2,
          // 预付款1  对账单2
          statementType: 1,
          pageFlg: this.role == 'B' ? 0 : 1
        }
      InterfaceService.queryStatementList(params, data => {
        if (data.respData && data.respData.respCode === "0000") {
          this.statementList = data.respData.statementList || []
          this.form.pageTotal = data.respData.totalCount
        } else {
          this.$message.error(data.respData && data.respData.respMsg);
        }
      }, data => {
      }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
  },
}
</script>
<style lang="scss" scoped>
.statementDeclaredContainer {
  position: relative;
  .head-btn {
    text-align: right;
    /deep/ .el-button--primary {
      padding: 6px 15px;
    }
  }
  .panel-content {
    margin-bottom: 20px;
    padding: 10px 10px 20px;
    background: #f9f9f9;
    /deep/ .el-date-editor {
      input.el-input__inner {
        padding: 0 15px;
      }
      .el-input__prefix {
        display: none;
      }
    }
  }
  .txt-center {
    text-align: center;
  }
  .table-container {
    .table {
      /deep/ .el-button {
        font-size: 12px;
      }

      width: 100%;
      line-height: 23px;
      font-size: 12px;
      table {
        table-layout: fixed;
        width: 100%;
      }
      td {
        padding: 14px 10px;
        vertical-align: middle;
        word-break: break-word;
      }

      thead {
        text-align: left;
        white-space: nowrap;
        font-size: 14px;
        color: #888;
        background: #f9f9f9;
      }

      tbody {
        text-align: center;

        tr:hover {
          background: #e8f3fd;
        }
      }
      .tbody-row {
        &:hover {
          background: #e8f3fd;
          .sign-content {
            background: #f0f8ff;
          }
        }
        .sign-content {
          display: table-row;
          background: #f9f9f9;
          &:hover {
            display: table-row;
          }
          td {
            padding: 0;
            border-top: none;
          }
        }
      }

      tbody {
        text-align: center;
        /*tr:hover + tr.sign-content {*/
        /*display: table-row;*/
        /*}*/

        tr {
          border-bottom: 1px solid #ebeef5;
        }
        .border-none {
          border-bottom: none;
        }
      }
    }
  }
}
.product-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
.creatDiaContainer {
  /deep/ .el-dialog__body {
    padding: 30px 20px 0px;
  }
  /deep/ .el-dialog__footer {
    padding-top: 0;
  }
}
</style>

<style lang="scss">
.selectContractDialogSelectContainer {
  max-width: 680px;
}
</style>