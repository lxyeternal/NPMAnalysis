<template>
  <div class="statementAuditContainer">
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" :progress="`${examine ? '预付款审核-材料预付款审核' : '材料预付款详情'}`" :is-border-bottom="true"></SearchBar>
    <div class="breadcrumb">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
    </div>
    <div class="steps-cont">
      <Steps :tenderList="flowList" :active="stepActive" :space="396"></Steps>
    </div>
    <div class="view-container">
      <ViewTheTransferComponent v-if="computedList && computedList.length" :computedList="computedList"></ViewTheTransferComponent>
    </div>

    <div class="panel-title-container">
      <PanelTitle v-if="role == 'B'" :tabs="tabs" @select="handleChangeTab"></PanelTitle>
      <PanelTitle v-else :title="'预付款信息'"></PanelTitle>
    </div>
    <div class="reminder">
      <p>
        温馨提示：开票信息请点击预付款申请单右侧 <span class="blue hand" @click="beenReconciled">【开票信息】</span>文字按钮查看。
      </p>
    </div>
    <div class="download-container">
      <el-button style="width: 140px; height: 30px; padding: 0;" @click="handleClickBottom(3)">下载预付款单PDF</el-button>
    </div>
    <TableInfo :tdBgColor="'white'" :tabIndex="tabIndex" ref="tableInfoRef" :TopDistance="900" :isReview="isReview" @refreshData="tableInfoRefreshData"></TableInfo>
    <FixBottom v-if="examine">
      <div class="tc">
        <el-button type="primary" style="width: 140px;" @click="handleClickBottom(1)">提交OA审核</el-button>
        <el-button style="width: 140px;" @click="handleClickBottom(2)">退回</el-button>
        <!-- <el-button style="width: 140px;" @click="handleClickBottom(3)">下载预付款单PDF</el-button> -->
      </div>
    </FixBottom>

    <el-dialog class="dialog returnDialogContainer pr50" title="退回原因" :append-to-body="true" :lock-scroll="true" :visible.sync="rejectDialogVisible" width="840px" center :close-on-click-modal="false" @close="rejectForm.refuseReason = ''">
      <div>
        <el-form :model="rejectForm" label-width="80px" ref="ruleForm" :rules="rules">
          <el-form-item label="退回原因：" prop="refuseReason">
            <el-input type="textarea" class="resize-none" v-model="rejectForm.refuseReason" rows="4" maxlength="200" show-word-limit placeholder="请输入..."></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" :disabled="!rejectForm.refuseReason.replace(/\s+/g,'')" @click="handleRejcet">退回</el-button>
        <el-button class="normal-btn" @click="rejectDialogVisible = false">取消</el-button>
      </div>
    </el-dialog>
    <Loading :isLoading="isLoading"></Loading>
  </div>
</template>
<script>
import accountMixin from '@/mixins/account';
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import FixBottom from "@/components/base/FixBottom";
import Breadcrumb from "@/components/base/Breadcrumb";
import ViewTheTransferComponent from "@/components/advanceCharge/statementDeclared/ViewTheTransferComponent";
import { InterfaceService } from "@/services/api";
import Steps from "@/components/base/steps";
import PanelTitle from "@/components/base/PanelTitle";
import TableInfo from "@/components/advanceCharge/advancePaymentRequest/TableInfo";
import Loading from "@/components/base/Loading";

export default {
  mixins: [accountMixin],
  components: {
    SearchBar,
    Breadcrumb,
    Header,
    FixBottom,
    TableInfo,
    ViewTheTransferComponent,
    Steps,
    PanelTitle,
    Loading
  },
  data() {
    return {
      breadcrumb: [],
      isLoading: false,
      computedList: [],
      readStatusChecked: false,
      rejectDialogVisible: false,
      isReview: true, // 查看模式
      examine: false, // 审核模式
      flowList: [],
      tabIndex: 1,
      stepActive: 0,
      rejectForm: {
        refuseReason: ''
      },
      tabs: [
        { label: "材料合同预付款单", listType: 1, active: true },
        { label: "事业部合同预付款单", listType: 0 }
      ],
      orderDetailInfo: {},
      // 预付款详情
      statementDetailInfo: {},
      rules: {
        refuseReason: [{ required: true, message: '请填写退回原因', trigger: 'blur' }],
      }
    }
  },
  watch: {

  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.examine = this.$route.query.state == 'examine' || false
      if (!this.brokerRole && this.role == 'B') {
        this.tabIndex = 0
      }

      this.tabs.some(s => {
        this.$set(s, 'active', s.listType == this.tabIndex)
      })

      this.initData()
    },
    initData() {
      this.breadcrumb = [
        { name: `${this.role == 'S' ? '供应商' : '采购商'}管理中心`, path: `${this.role == 'S' ? '/vendorCenter' : '/purchaserCenter'}/accountInfo` },
        { name: `请款管理-预付款${this.role == 'S' ? '申请' : '审核'}`, path: `${this.role == 'S' ? '/vendorCenter' : '/purchaserCenter'}/advancePaymentRequestList` },
        { name: `材料预付款${this.examine ? '审核' : '详情'}` },
      ]
    },
    tableInfoRefreshData(data) {
      console.log(data, '---');
      this.flowList = data.flowList || []
      this.stepActive = data.activeNode || 0
      this.computedList = data.orderOperFlow || []
      this.orderDetailInfo = data.orderDetailInfo || {}
      this.statementDetailInfo = data.statementDetailInfo
    },
    beenReconciled() {
      this.$refs['tableInfoRef'].beenReconciled()
    },
    handleClickBottom(state) {
      this.rejectForm.refuseReason = ''
      switch (state) {
        case 1:
          this.$confirm("确定要提交OA审核吗？", "提交提示", {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            confirmButtonText: "确认",
            cancelButtonText: '取消',
          }).then(() => {
            const findItem = this.statementDetailInfo && this.statementDetailInfo.externalSysList.find(f => ['4'].includes(f.approveStatus)) || {}
            this.advanceExamineOperationHearing(findItem)
          }).catch(() => {
          });
          break;
        case 2:
          // 退回
          this.rejectDialogVisible = true
          this.resetForm()
          break;
        case 3:
          const documentList = this.statementDetailInfo && this.statementDetailInfo.documentList || []
          console.log(documentList);
          this.$download([{
            name: documentList[0] && documentList[0].attachName,
            url: documentList[0] && documentList[0].attachUrl
          }], () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
            this.$message.success("已下载");
          });
          break;

        default:
          break;
      }
    },

    resetForm() {
      this.$refs['ruleForm'] && this.$refs['ruleForm'].resetFields();
    },
    handleRejcet() {
      if (!this.rejectForm.refuseReason.replace(/\s+/g, "")) {
        this.$message.error('退回原因不能为空!')
        return
      }
      this.advanceExamineOperation('purchaserReturn')
    },
    // 先调用 确认
    advanceExamineOperationHearing(findItem) {
      // 状态2||4需要重新提交审核
      const operType = findItem.externalCode ? 'resubmit' : 'submit'
      const params = {
        statementNo: this.$route.query.statementNo, // 预付款单编号
        operType: operType || '', // 操作类型（保存:save;提交审核:submit;重新提交审核:resubmit）
        approveId: findItem.externalCode || ''// OA流程编号（重新提交审核时必传）
      }
      InterfaceService.advanceExamineOperationHearing(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.advanceExamineOperation('purchaserPassed')
        } else if (data && data.respData && data.respData.respCode == "TRANS0455") {
          this.$confirm(
            '您还没有绑定集团OA账号，请先去绑定！',
            '提示信息',
            {
              cancelButtonClass: "btn-custom-cancel",
              confirmButtonClass: "btn-custom-confirm",
              center: true,
              dangerouslyUseHTMLString: true,
              confirmButtonText: '去绑定',
              cancelButtonText: '取消',
            }).then(() => {
              this.$router.push({ path: '/purchaserCenter/accountInfo' })
            }).catch(() => {
            });
          return
        } else {
          this.$message.error(data && data.respData && data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },

    advanceExamineOperation(operType) {
      const params = {
        statementNo: this.$route.query.statementNo, // 预付款单编号
        operType: operType || '', // 操作类型（删除:supplierDelete;审核通过:purchaserPassed;退回:purchaserReturn;关闭:supplierClose）
        returnReason: this.rejectForm.refuseReason, // 退回原因
      }
      InterfaceService.advanceExamineOperation(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          switch (operType) {
            case 'purchaserPassed':
              this.$router.push({
                path: '/resultsFeedback',
                query: {
                  type: operType,
                  orderNo: this.$route.query.orderNo,
                  statementNo: this.$route.query.statementNo,
                  purchaserStatementNo: this.$route.query.purchaserStatementNo,
                  supplierStatementNo: this.$route.query.supplierStatementNo,
                }
              })
              break;
            case 'purchaserReturn':
              this.rejectDialogVisible = false
              this.$message.success(`已退回, 页面将在1秒后跳转列表`)
              // window.opener && window.opener.location.reload()
              setTimeout(e => {
                // window.close()
                this.$router.push(this.role == 'B' ? '/purchaserCenter/advancePaymentRequestList': '/vendorCenter/advancePaymentRequestList')
              }, 1000)
              break;

            default:
              break;
          }
          window.opener && window.opener.location.reload()
        } else {
          this.$message.error(data && data.respData && data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },
    handleChangeTab(tab) {
      this.tabIndex = tab.listType;

    },
  }

}
</script>
<style lang="scss" scoped>
.statementAuditContainer {
  .reminder {
    margin: 0 auto 10px;
    width: 1190px;
    height: 30px;
    background: #fffcf0;
    border: 1px solid #fae2a5;
    padding: 6px 10px 5px 10px;
    span {
      width: 1124px;
      height: 19px;
      font-size: 12px;
      font-family: PingFang SC;
      font-weight: 400;
      line-height: 17px;
      color: #444444;
      opacity: 1;
    }
  }
  .multi_line {
    height: 42px;
    display: flex;
    flex-direction: column;
    p {
      flex: 1;
      font-size: 12px;
      line-height: 12px;
    }
  }

  .steps-cont {
    margin: 10px auto 30px;
    width: 1190px;
    padding: 20px 0;
    box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
  }
  .view-container {
    margin: 30px auto;
    width: 1190px;
  }
  .breadcrumb {
    width: 1190px;
    margin: auto;
  }
  .panel-title-container {
    margin: 30px auto 0;
    width: 1190px;
    .panel-title {
      margin-bottom: 10px;
    }
  }
  .mid-btn-container {
    width: 1190px;
    margin: auto;
    margin-top: -27px;
    display: flex;
    justify-content: flex-end;
    button {
      height: 26px;
      line-height: 26px;
      padding: 0 12px;
      font-size: 12px;
    }
  }
}
.download-container {
  width: 1190px;
  margin: auto;
  text-align: right;
}
</style>