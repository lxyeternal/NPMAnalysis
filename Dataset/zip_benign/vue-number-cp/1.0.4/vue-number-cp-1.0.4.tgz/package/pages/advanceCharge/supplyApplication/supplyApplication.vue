<template>
  <div class="product">
    <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>
     <el-row>
          <el-col :span="24" class="form_btns">
            <el-button type="primary" class="small-btn" @click="apply">材料预付款申请</el-button>
          </el-col>
        </el-row>
    <!-- 查询条件 -->
    <div class="panel-content" :style="{'margin-bottom' : brokerRole ? '40px' : '35px'}">
      <el-form class="form" :model="form" size="small" label-width="75px">
        <el-row>
          <el-col :span="24">
            <el-form-item label="合同名称：">
              <el-input v-model.trim="contractName" placeholder="请输入合同关键词或合同编号"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item  label-width="95px" label="预付款单号：" >
              <el-input style="width: 240px;" v-model.trim="statementNo" placeholder="请输入预付款编号"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="采购商：">
              <el-input style="width: 240px;" v-model.trim="purchaserName" placeholder="请输入采购商名称"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="申请时间：" label-width="93px">
              <el-col :span="11" class="form-item">
                <el-date-picker style="width: 110px;" type="date" placeholder="选择时间" value-format="yyyy-MM-dd" v-model="applyTmFrom"></el-date-picker>
              </el-col>
              <el-col :span="2" class="tc">~</el-col>
              <el-col :span="11" class="form-item">
                <el-date-picker style="width: 110px;" type="date" placeholder="选择时间" value-format="yyyy-MM-dd" v-model="applyTmTo"></el-date-picker>
              </el-col>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24" class="form-btns">
            <el-button type="primary" class="small-btn" @click.native="handleSearch">搜索</el-button>
            <el-button class="small-btn" @click="handlerclear">清除</el-button>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="product-table">
      <!-- 列表 -->
      <table>
        <thead>
          <tr class="tl">
            <td style="width: 180px">预付款单号/合同名称</td>
            <td style="width: 100px">采购商</td>
            <td style="width: 76px;">申请时间</td>
            <td style="width: 72px;">预付类型</td>
            <td style="width: 56px;" class="tr">预付比例</td>
            <td style="width: 120px; box-sizing: border-box;" class="tr">
              <p>本期应付款</p>
              <p>(含税)(元)</p>
            </td>
            <td style="width: 51px;">状态</td>
            <td style="width: 102px;" class="tr">操作</td>
          </tr>
        </thead>
          <tbody v-for="(item,index) in statementList" :key="index" class="tl tbody-row">
            <tr>
              <td>
                <p> {{item.orderNo  || '——'}} </p>
                <p> {{item.contractName || '——'}} </p>
              </td>
              <td> {{item.purchaserName || '——'}} </td>
              <!-- 采购商 -->
              <td v-if="item.creTm">{{item.creTm | datetime}}</td>
              <td v-else> —— </td>
              <!-- 时间 -->
              <td>
                <p> {{item.prepaymentType || '——'}} </p>
              </td>
              <!-- 预付类型 -->
              <td class="tr"> {{item.prepaymentRatio || '——'}} </td>
              <td class="tr">{{item.statementAmt || '——'}} </td>
              <!-- 本期应付款 -->
              <td>{{item.statementStatusDesc || '——'}} </td>
              <!-- 状态 -->
              <td class="tr">
                <OrderListOperate :tab="tab" :order="product" ></OrderListOperate>
              </td>
            </tr>
            <tr class="sign-content" v-if="showSignProcess(product)">
              <td colspan="100">
                <SignProcessOrderList :order="product"></SignProcessOrderList>
              </td>
            </tr>
          </tbody>
      </table>
      <div class="Reasons_for_return">
        <span style="font-weight:600;font-size:12px;width:70px;">退回原因：</span>
        <span style="font-size:12px;" class="hidde" ref="hide">一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十
          一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十
          一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一
          </span>
          <span class="click_to_expand" @click="showdown"><a href="javascript:;" >展开</a><i class="el-icon-caret-bottom"></i></span>
      </div>
      <!-- 退回原因 -->
      <div class="table-pagination" v-if="productList.length">
        <el-pagination>
        </el-pagination>
      </div>
      <el-dialog
        title="预付款申请"
        :visible.sync="dialogVisible"
        :show-close="false"
        width="850px"
        style="
          font-size: 14px;
          font-family: PingFang SC;
          font-weight: 400;"
        :before-close="handleClose">
        <el-form>
          <el-form-item label="*合同名称：">
            <el-select style="width:719px;" v-model="contractname" @change="change" >
              <el-option  :value="item.statementNo" v-for="(item,index) in statementList" :key="index" :label="item.contractName"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
           <el-row>
          <el-col :span="24" class="form-btns">
            <el-button type="primary" class="small-btn" @click="beforeClose">下一步</el-button>
            <el-button class="small-btn" @click="cancel">取消</el-button>
          </el-col>
        </el-row>
        </span>
      </el-dialog>
    </div>
  </div>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import OrderListOperate from "./components/OrderListOperate";
import OrderConfirm from "@/components/order/dialog/orderOperate/OrderConfirm";
import ContractOperate from "@/components/order/ContractOperate";
import SignProcessOrderList from "@/components/order/SignProcessOrderList";
import { InterfaceService } from "@/services/api";
import { filterEventByAcct } from '@/utils/orderUtil';
import ConfluenceFloat from '@/components/base/ConfluenceFloat'
import Signature from "@/components/order/dialog/Signature";
import { DateUtil } from '@/utils/dateUtil';
import Header from '@/components/base/Header'

const params = {
  orderNo: "",
  orderAccName: "",
  orderStatus: [],
  status: "",

  // priceType: "D", // 字段删除
  sort: "2_0_0",
  pageIndex: 1,
  pageSize: 10,
  enterFrom: 1,
  searchType: '',
  groupCompanyCode: '',
  purchaserCorpId: '',
};

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    OrderListOperate,
    OrderConfirm,
    ContractOperate,
    SignProcessOrderList,
    Signature,
    ConfluenceFloat,
    Header,
    PanelTitle
  },
  data() {
    return {
      tab: "1",
      tabs: [
        { label: "待处理", index: "1", active: true },
        { label: "进行中", index: "2" },
        { label: "已结束", index: "3" },
      ],
      dialogVisible: false,
      contractName: '',
      purchaserName: '',
      contractname: '',
      applyTmFrom: '',
      applyTmTo: '',
      statementNo: '',
      statementList: [],
      contractTrray: [],
      purchaserName: "",
      supplierName: "",
      agentCorpName: "",
      orderTmFrom: "",
      orderTmTo: "",
      orderStatus:'',
      product: {},
      form: Object.assign({}, params),
      allChecked: false,
      signResultDialogVisible: false,
      disableAllCheck: false,
      hasChecked: false,
      sortList: [2, 0, 0],
      priceList: [
        { label: "全部", value: "" },
        { label: "战略价(税前)", value: "A" },
        { label: "市场价(税前)", value: "D" },
        { label: "协议价(税前)", value: "Negotiated" }
      ],
      statusList: [],
      overStatusList: [],
      productList: [],
      groupCompanyList: [],
      projectList: [],
      total: 0,
      obj: [],
      presentTime: '',
      signResultTitle: '',
      signFailNum: 0,
      selectedSignLength: 0,
      isLoading: false,
      listLoading: false,
      signFlag: false,
      storeParams: {},
      isSubOrderOperMsg: true,
      contract: {
        contractName:""
      }
    };
  },
  methods: {
    showdown () { // 退回原因
      let hide = this.$refs.hide
      let btn = document.querySelector('.click_to_expand>a')
      console.log(hide)
      if(btn.innerHTML == '展开') {
        let hide = this.$refs.hide
        hide.classList.remove('hidde')
        hide.classList.add('show')
        btn.innerHTML = '收起'
      } else if (btn.innerHTML == '收起') {
          let hide = this.$refs.hide
          console.log(hide)
          hide.classList.remove('show')
          hide.classList.add('hidde')
          btn.innerHTML = '展开'
      }
    },
    handlerclear(){ // 清除
      this.contractName = ''
      this.statementNo = ''
      this.purchaserName = ''
      this.applyTmFrom = ''
      this.applyTmTo = ''
    },
    apply(){
      this.dialogVisible = true
    },
    handleClose() { // 对话框关闭后回调
      this.form.city='';
    },
    handleCloseSignature(bool, num) {
      if (bool) {
        this.selectedSignLength = this.productList.filter(i => { return i.checked }).length;
        this.presentTime = DateUtil.dateToString();
        this.signFailNum = num;
        num == 0 ? this.signResultTitle = '签署成功' : this.signResultTitle = '签署失败';
        this.signResultDialogVisible = true;
      }
    },
    beforeClose(){ // 对话框下一步
      this.dialogVisible = false
      this.contractname = ''
      this.$router.push('/confirmationList')
    },
    cancel(){ // 对话框取消
      this.dialogVisible = false
      this.contractname = ''
      this.form.city='';
    },
    change(val){
      this.obj = this.statementList.filter(item => {
        console.log(val)
         return item.statementNo === val
      })
      console.log(this.obj)
    },
    handleSign() {
      let num = this.productList.filter(i => { return i.checked }).length;
      let str = '';
      let title = '';
      str = "您已选中<span class='red'>" + num + "</span>份合同，确认要批量签章吗？";
      title = '批量签章'
      this.$confirm(
        str,
        title,
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确认签章",
          cancelButtonText: '取消',
        }).then(() => {
          this.handleConfirm()
        }).catch(() => {
        });
    },
    confirmBtn(type) {
      this.signResultDialogVisible = false;
      if (type === 1) {
        this.tabs = [
          { label: "待处理", index: "1" },
          { label: "进行中", index: "2", active: true },
          { label: "已结束", index: "3" },
        ];
        this.tab = '2'
      }
    },
    // 批量确认合同完成
    handleConfirm() {
      let attach = [];
      this.productList.filter(i => { return i.checked }).forEach(item => {
        item.eventList.forEach(ev => {
          if (ev.eventType == 0 &&
            (ev.eventStatus == "0" || ev.eventStatus == "1")) {
            attach.push(ev)
          }
        })
      });
      this.$refs["signature"].open(attach, "order");
    },
    // 修改tab
    handleChangeTab(tab) {
      this.tab = tab.index;
      // this.recoverStatus(this.tab);
      this.form = Object.assign({}, params);
      this.getOrderList();
    },
    showSignProcess(product) {
      return product.orderStatus === '05' && product.eventList && product.eventList.length
    },
    // 清楚状态选择
    handleSelectClear() {
      // this.recoverStatus(this.tab);
    },
    // 搜索
    handleSearch() {
      const params = {
      contractName:this.contractName,
      purchaserName:this.presentTime,
      applyTmFrom:this.applyTmFrom,
      applyTmTo:this.applyTmTo,
      statementNo:this.statementNo,
      searchType:0,
      statementType:1,
      pageFlg:0
    }
    InterfaceService.queryStatementList(params, data => {
      this.statementList = data.respData.statementList
    })
    },
    // 排序
    handleSort(index) {
      let arr = [].concat(this.sortList);
      this.sortList.forEach((item, i) => {
        if (index == i) {
          if (item == 0) {
            arr[i] = 2;
          } else if (item == 2) {
            arr[i] = 1;
          } else {
            arr[i] = 0;
          }
        } else {
          arr[i] = 0;
        }
      });
      this.sortList = arr;
      this.getOrderList();
    },
    // 全选
    handleAllSelectTableRow(bool) {
      this.productList.filter(i => { return i.orderStatus == '05' }).forEach(item => {
        item.checked = bool;
      });
      this.checkBatch();
    },
    // 选中行
    handleSelectTableRow(product, index) {
      this.$set(this.productList, index, product);
      this.checkBatch();
      this.checkAllSelect();
    },
    // 刷新列表
    handleRefresh(operationType) {
      //关闭、删除
      this.form.pageIndex = 1;
      if (operationType === '4') {
        this.handleChangeTab({ index: '3' });
        this.tabs = [
          { label: "待处理", index: "1" },
          { label: "进行中", index: "2" },
          { label: "已结束", index: "3", active: true },
        ]
        //撤回
      } else if (operationType === '3' || operationType === '2') {
        this.handleChangeTab({ index: '1' });
        this.tabs = [
          { label: "待处理", index: "1", active: true },
          { label: "进行中", index: "2" },
          { label: "已结束", index: "3" },
        ]
      }
    },
    // 批量确认合同弹窗
    handleBatchOrderConfirm() {
      const orders = [];
      this.productList.forEach(item => {
        if (item.checked) {
          orders.push(item);
        }
      });
      this.$refs["orderConfirm"].open(orders, true);
    },
    // 批量确认合同完成
    handleCloseOrderConfirm(bool) {
      if (bool) {
        this.getOrderList();
      }
    },
    // 分页跳转
    handleCurrentChange(page) {
      this.form.pageIndex = page;
      this.getOrderList();
      window.scrollTo(0, 0)
    },
    // 是否全选
    checkAllSelect() {
      this.allChecked = this.productList.filter(i => { return i.orderStatus == '05' }).every(item => {
        return item.checked;
      });
    },
    // 是否可批量
    checkBatch() {
      this.hasChecked = this.productList.filter(i => { return i.orderStatus == '05' }).some(item => {
        return item.checked;
      });
    },
    // 待签署合同
    waitSignContract(order) {
      let allow = false;
      let acctIdList = [];
      if (this.userinfo.accountList.length) {
        this.userinfo.accountList.forEach(item => {
          acctIdList.push(item.acctId)
        });
      } else {
        acctIdList.push(this.acctId)
      }
      if (order.eventList) {
        const list = filterEventByAcct(order.eventList, 0, acctIdList);
        list.forEach(item => {
          if (
            item.eventType == 0 &&
            (item.eventStatus == 0 || item.eventStatus == 1)
          ) {
            if (item.processList) {
              item.processList.forEach(process => {
                if (process.processFlg == 0) {
                  allow = true;
                }
              });
            }
          }
        });
      }
      if ((order.orderStatus == 'contractTerminating' || order.orderStatus == 'contractTerminated')) {
        allow = false;
      }
      return allow;
    },
    waitBrokerSign(order) {
      let allow = true;
      if (order.externalSysList && order.externalSysList.length > 0) {
        order.externalSysList.forEach(item => {
          if (item.approveStatus != "1") {
            allow = false
          }
        })
      } else {
        allow = false
      }
      return allow
    },
  },
  mounted() {
    const user = JSON.parse(localStorage.getItem('user'))
    if(user.bs == 'B') {
      this.statementType = 1
    } else {
      this.statementType = 2
    }
    const params = {
      contractName:this.contractName,
      purchaserName:this.presentTime,
      applyTmFrom:this.applyTmFrom,
      applyTmTo:this.applyTmTo,
      statementNo:this.statementNo,
      searchType:0,
      statementType:this.statementType,
      pageFlg:0
    }
    const objone = {}
    InterfaceService.queryStatementList(params, data => {
      this.statementList = data.respData.statementList
    })
  }
};
</script>

<style lang="scss" scoped>
*{
font-weight: 400;
}
.hand + .hand {
  margin-left: 10px;
}
.price-tip {
  cursor: pointer;
  color: #a9a9aa;

  &:hover {
    color: #0082ff;
  }
}

.product {
  font-size: 14px;
}

.pointer {
  cursor: pointer;
  &:hover {
    color: #0082ff;
  }
  &:active {
    color: #4c9cdd;
  }

  .active {
    color: #ffd64e;
  }
}

.nowrap {
  white-space: nowrap;
}

.panel-content {
  padding: 20px 10px 0;
  background: #f9f9f9;
}

.form {
  min-height: 135px;

  /deep/ .el-col {
    height: 52px;
  }

  /deep/ .el-select {
    width: 100%;
  }

  /deep/ .el-date-editor {
    input.el-input__inner {
      padding: 0 15px;
    }
    .el-input__prefix {
      display: none;
    }
  }

  &:after {
    display: table;
    content: "";
    clear: both;
  }
}

.form-item {
  position: relative;
  display: inline-block;
  line-height: 32px;

  .float-right {
    position: absolute;
    top: 2px;
    right: 1px;
    height: 30px;
    padding: 0 7px;
    line-height: 30px;
    background: #ffffff;
  }
}

.error-info {
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
  position: absolute;
  top: 100%;
  left: 0;
}

.form-btns {
  text-align: center;
}
.form_btns {
  text-align: right;
  margin-bottom: 10px;
}

.product-table {
  /deep/ .el-table__body-wrapper {
    font-size: 12px;
  }

  /deep/ .el-table th,
  .el-table td {
    padding: 14px 0;
  }

  /deep/ .el-button {
    font-size: 12px;
  }

  table {
    table-layout: fixed;
    width: 100%;
    line-height: 23px;
    font-size: 12px;
    td {
      padding: 14px 15px;
      vertical-align: middle;
      word-break: break-all;
    }
    td:last-child {
      padding-right: 10px;
    }
    td:first-child {
      padding-left: 10px;
    }

    thead {
      font-size: 14px;
      text-align: center;
      white-space: nowrap;
      color: #909399;
      background: #f9f9f9;
    }

    .tbody-row {
      &:hover {
        background: #e8f3fd;
        .sign-content {
          background: #f0f8ff;
        }
      }
      .sign-content {
        display: table-row;
        background: #f9f9f9;
        td {
          padding: 0;
          border-top: none;
        }
      }
    }
    .tbody-row .nailsupply {
      display: inline-block;
      max-width: 100%;
      min-height: 14px;
      padding: 0 6px;
      line-height: 14px;
      border: 1px solid #ffa300;
      border-radius: 7px;
      color: #ffa300;
      margin-right: 6px;
    }
    tbody {
      text-align: center;

      tr {
        &.all-check {
          text-align: left;

          &:hover {
            background: #ffffff;
          }
        }
      }

      /*tr:hover + tr.sign-content {*/
      /*display: table-row;*/
      /*}*/

      tr {
        border-bottom: 1px solid #ebeef5;
      }
      .border-none {
        border-bottom: none;
      }
    }
  }

  .product-name {
    display: inline-flex;
    width: 100%;
    vertical-align: top;
    line-height: 20px;

    img {
      width: 75px;
      height: 75px;
    }

    .left {
      margin-right: 10px;
    }

    .right {
      text-align: left;

      p:first-child {
        margin-bottom: 10px;
      }
      p:last-child {
        word-break: break-all;
        max-height: 40px;
        overflow: hidden;
        color: #969799;
      }
    }
  }
}

.product-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}

.price-popover {
  display: flex;
  color: #ababac;

  > div:first-child {
    margin-right: 10px;
  }

  p:first-child {
    padding: 0 5px;
    border-left: 3px solid #ffd64e;
    line-height: 15px;
  }

  p:last-child {
    margin-top: 10px;
    color: #ffffff;
  }
}

.table-pagination {
  margin: 50px 0 80px;
  text-align: center;
  color: #888888;
}
/deep/ .el-dropdown-menu__item {
  min-height: 14px;
  line-height: 14px;
  border: 1px solid #ffa300;
  border-radius: 7px;
  color: #ffa300;
  cursor: default;
  margin-top: 5px;
  &:hover {
    color: #ffa300;
    background: #fff;
  }
  &:first-child {
    margin-top: 0;
  }
}
.w284 {
  width: 284px !important;
}
.subOrderMsgContainer {
  padding: 0 !important;
  span {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border: 0;
  }
}
.batch-operation {
  padding-left: 10px;
  margin-top: -10px;
  margin-bottom: 10px;
  .el-button {
    margin-left: 8px;
  }
}
.sign-result-dialog {
  /deep/ .el-dialog__body {
    width: 100%;
  }
  text-align: center;
  div {
    text-align: center;
    margin: 20px auto 20px;
  }
}
.Reasons_for_return {
  position: relative;
  display: flex;
  flex-direction: row;
  padding: 6px 0 7px 10px;
  padding-right: 61px;
  background: #F8F8FF ;
  margin-top: 15px;
  .hidde {
    width: 890px;
    line-height: 17px;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
  }
  .show {
     width: 890px;
    line-height: 17px;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1000;
    overflow: hidden;
  }
  .click_to_expand {
    cursor:pointer;
    color: blue;
    font-size: 12px;
    position: absolute;
    top: 5px;
    right: 13px;
  }
}
</style>