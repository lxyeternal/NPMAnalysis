<template>
  <div>
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" progress="确认对账清单" :is-border-bottom="true"></SearchBar>
    <div class="breadcrumb">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
    </div>
    <div class="contract">
      <span>合同基本信息</span>
    </div>
    <div class="information">
      <ul class="information_left">
        <li>
          <p>品类：</p>
          <span>{{orderDetailInfo.categoryName || ''}}</span>
        </li>
        <li>
          <p>合同编号：</p>
          <span>{{orderDetailInfo.clOrderNo || ''}}</span>
        </li>
        <li>
          <p>项目名称：</p>
          <span>{{orderDetailInfo.projectName || ''}}</span>
        </li>
        <li>
          <p>标段：</p>
          <span>{{orderDetailInfo.building || ''}}</span>
        </li>
      </ul>
      <ul class="information_right">
        <li class="dis-flex">
          <p>合同名称：</p>
          <span>《{{orderDetailInfo.contractName || ''}}》</span>
          <div class="contract_btns">
            <a href="javascript:;" @click="handleDownloadContract">下载合同</a>
            &nbsp;
            <a href="javascript:;" @click="handleOrderDetail">查看合同详情</a>
          </div>
        </li>
        <li>
          <p>采购商：</p>
          <span>{{orderDetailInfo.purchaserName || ''}}</span>
        </li>
        <li>
          <p>项目分期：</p>
          <!-- <span>{{orderDetailInfo.projectTerm || ''}}</span> -->
          <span>{{orderDetailInfo.projectTermName || ''}}</span>
        </li>
        <!-- <li>
          <p>对账期间：</p>
          <span>暂无</span>
        </li> -->
      </ul>
    </div>
    <div class="contract">
      <span>货物验收一览表</span>
    </div>
    <div class="table-container">
      <table>
        <thead>
          <tr>
            <td width="80">序号</td>
            <td width="200">验收单据编号</td>
            <td width="300">验收单名称</td>
            <td width="200">关联发货单号</td>
            <td width="300">关联发货单</td>
          </tr>
        </thead>
        <tbody v-if="!(deliveryList && deliveryList.length)">
          <tr>
            <td colspan="5" class="p0">
              <div class="tc">暂无数据</div>
            </td>
          </tr>
        </tbody>
        <tbody>
          <tr v-for="(item,index) in deliveryList" :key="index">
            <td>
              <div>{{index + 1}}</div>
            </td>
            <td>
              <div>{{item.deliveryNo || ''}}</div>
            </td>
            <td>
              <div><span class="blue hand" @click="handleView(item)">{{item.deliveryName || ''}}</span></div>
            </td>
            <td>
              <div>{{item.requireNo || ''}}</div>
            </td>
            <td class="blue hand">
              <div><span class="blue hand" @click="handleView(requireCp(item))">{{requireCp(item).requireName || ''}}</span></div>
            </td>
          </tr>
        </tbody>
      </table>
      <el-button class="reconciliation-receipt" @click="beenReconciled">已对账的验收单</el-button>
    </div>
    <FixBottom>
      <div class="tc">
        <el-button type="primary" style="width: 120px;" :disabled="!(deliveryList && deliveryList.length)" @click="handleClickBottom(1)">确认生成对账单</el-button>
        <el-button @click="handleClickBottom(2)">返回列表</el-button>
      </div>
    </FixBottom>

    <ReconciliationReceiptFloatBottom ref="reconciliationReceiptFloatBottomRef" @close="handleCloseReconciliationReceiptFloatBottom"></ReconciliationReceiptFloatBottom>

    <Loading :isLoading="isLoading"></Loading>
  </div>
</template>
<script>
import Breadcrumb from "@/components/base/Breadcrumb";
import FixBottom from "@/components/base/FixBottom";
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import accountMixin from "@/mixins/account";


import ReconciliationReceiptFloatBottom from "@/components/advanceCharge/statementDeclared/ReconciliationReceiptFloatBottom";

export default {
  mixins: [accountMixin],
  components: {
    Header,
    SearchBar,
    Breadcrumb,
    ReconciliationReceiptFloatBottom,
    FixBottom,
    Loading
  },
  data() {
    return {
      breadcrumb: [],
      isLoading: false,
      orderNo: '',
      orderDetailInfo: {},
      // 已对账的验收单
      alreadyBillInfo: {},
      deliveryList: [],
      requireList: [],
      statementNo: ''
    }
  },

  computed: {
    requireCp() {
      return item => this.requireList.find(f => f.requireNo == item.requireNo) && this.requireList.find(f => f.requireNo == item.requireNo) || {}
    },
    divisionContract() {
      return this.role == 'B'
    },
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.orderNo = this.$route.query.orderNo || ''
      this.statementNo = this.$route.query.statementNo || ''
      this.breadcrumb = [
        { name: '管理中心', path: '/vendorCenter/accountInfo' },
        { name: '请款管理-对账单申报', path: '/vendorCenter/statementDeclaredList' },
        { name: '创建对账单申报' },
      ]
      this.getPaymentReportBillList()
      this.orderDetails()
    },
    handleView(item) {
      console.log(item, '-');

      let encodeUrl = encodeURIComponent(item.attachUrl);
      const officeOpenTypeList = [".docx", ".dotx", ".doc", ".xlsx", ".xlsb", ".xlsm", ".xls", ".pptx", ".ppsx", ".ppt", ".pps", ".potx", ".ppsm"];
      let officeOpen = false;
      let userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
      let isIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; //判断是否IE<11浏览器
      let isEdge = userAgent.indexOf("Edge") > -1 && !isIE; //判断是否IE的Edge浏览器
      let isIE11 = userAgent.indexOf('Trident') > -1 && userAgent.indexOf("rv:11.0") > -1;
      let IE = false;
      if (isIE || isEdge || isIE11) {
        IE = true
      } else {
        IE = false  //不是ie浏览器
      }
      officeOpenTypeList.some(item => {
        if (encodeUrl.indexOf(item) != -1) {
          return officeOpen = true
        }
      });
      if (officeOpen && !IE) {
        window.open("https://view.officeapps.live.com/op/view.aspx?src=" + encodeUrl, "_blank");
      } else {
        window.open(item.attachUrl, "_blank");
      }
    },
    handleCloseReconciliationReceiptFloatBottom() {

    },
    handleClickBottom(state) {
      switch (state) {
        case 1:
          this.$confirm("确认生成对账单吗？", "操作提示", {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            confirmButtonText: "确认",
            cancelButtonText: '取消',
          }).then(() => {
            this.generateStatements()
          }).catch(() => {
          });
          break;
        case 2:
          this.$router.push('/vendorCenter/statementDeclaredList')
          break;

        default:
          break;
      }

    },
    async beenReconciled() {
      await this.getPaymentReportBillList('0')
      // this.alreadyBillInfo.deliveryList[0].statementStatus = 'supplierSubmit'
      this.$refs["reconciliationReceiptFloatBottomRef"].open(this.alreadyBillInfo || {})
    },
    orderDetails() {
      const params = {
        orderNo: this.orderNo
      }
      InterfaceService.orderDetails(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.orderDetailInfo = data.respData || {}
        } else {
          this.$message.error(data && data.respData && data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },

    getPaymentReportBillList(searchType) {
      return new Promise(resolve => {
        const params = {
          orderNo: this.orderNo,
          searchType: searchType || '1' //（""0"":已对账；1未对账）
        };
        InterfaceService.getPaymentReportBillList(
          params,
          data => {
            if (data.respData.respCode === "0000") {
              if (searchType == '0') {
                this.alreadyBillInfo = {}
                this.alreadyBillInfo = data.respData || {}
                resolve(true)
                return
              }
              this.deliveryList = []
              this.requireList = []
              this.deliveryList = data.respData.deliveryList || []
              this.requireList = data.respData.requireList || []
            } else {
              this.$message.error(data.respData.respMsg);
            }
            resolve(true)
          }, data => { }, () => {
            this.isLoading = true;
          }, () => {
            this.isLoading = false;
          })
      })
    },


    /**
     * 查看合同详情
     */
    handleOrderDetail() {
      // 取消增补 功能需要
      window.open(this.$router.resolve({
        path: "/orderDetail",
        query: {
          orderNo: this.orderDetailInfo && this.orderDetailInfo.orderNo,
        }
      }).href, '_blank')
    },


    generateStatements() {
      return new Promise((resolve, reject) => {
        const delArr = []
        this.deliveryList.forEach(f => delArr.push(f.deliveryNo))
        const params = {
          deliveryList: delArr || [],
          operType: 'save',
          statementType: 2,
          orderNo: this.orderNo,
          statementNo: this.statementNo || ''
        }

        InterfaceService.generateStatements(params, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            window.opener && window.opener.location.reload()
            this.$router.push({
              path: '/statementDeclaredComfirm',
              query: {
                orderNo: this.orderNo,
                statementNo: data.respData.statementNo || '',
              }
            })
            resolve(data.respData)
          } else {
            this.$message.error(data && data.respData && data.respData.respMsg)
            reject(data.respData)
          }
        }, data => {
          this.$message.error(data.respData && data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      })
    },

    handleDownloadContract() {
      const params = {
        orderNo: this.orderNo,
        bs: this.divisionContract ? 'B' : 'S',
        documentVersion: "",
        fileFrom: "userUpload,systemCreate",
        documentTypeList: []
      };
      InterfaceService.getContractInfo(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          let attachList = [];
          let list = res.documentInfos || [];
          let hasPdf = list.some(item => {
            return item.documentType === 'dt_10_contract_profession' || item.documentType === 'dt_00_contract_profession'
          });
          list.forEach(item => {
            if (hasPdf) {
              // if (item.documentType === 'dt_10_contract_profession' || item.documentType === 'dt_00_contract_profession' || item.documentType === 'otherFile') {
              if (['dt_10_contract_profession', 'dt_00_contract_profession', 'dt_00_contract_common', 'dt_10_contract_common', 'otherFile'].indexOf(item.documentType) != -1) {
                let onOff = false;
                attachList.forEach(_item => {
                  if (item.documentId == _item.documentId) {
                    onOff = true
                  }
                });
                if (!onOff) {
                  attachList.push(item)
                }
              }
            } else {
              let onOff = false;
              attachList.forEach(_item => {
                if (item.documentId == _item.documentId) {
                  onOff = true
                }
              });
              if (!onOff) {
                attachList.push(item)
              }
            }
          });
          this.handleBatchDownload(attachList, hasPdf)
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },


    handleBatchDownload(attachList, hasPdf) {
      let fileInfoBeans = []
      if (attachList.length) {
        if (!hasPdf) {
          attachList.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: item.documentName,
              fileUrl: item.attachUrl,
            })
          })
        } else {
          attachList.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: (item.documentType.indexOf('profession') != -1 ? '合同专业版/' : item.documentType.indexOf('common') != -1 ? '合同通用版/' : '') + item.documentName,
              fileUrl: item.attachUrl,
            })
          })
        }
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: (this.divisionContract ? (this.orderDetailInfo.contractName.replace('采购合同', '供应合同')) : (this.orderDetailInfo.contractName)) + ".zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },

  }
}
</script>
<style lang="scss" scoped>
ul,
li {
  list-style: none;
}
.header {
  width: 100%;
  height: 30px;
  background: #f5f5f5;
}
.logo {
  width: 1920px;
  height: 134px;
  position: relative;
  margin-bottom: 9px;
  img {
    display: block;
    width: 180px;
    height: 56px;
    position: absolute;
    top: 40px;
    left: 330px;
  }
  span {
    display: block;
    position: absolute;
    width: 90px;
    top: 55px;
    left: 545px;
    font-size: 18px;
    font-family: PingFang SC;
    font-weight: 600;
    color: #444444;
  }
}
.reconciled {
  width: 100px;
  height: 26px;
  background: #ffffff;
  border: 1px solid #c99f4f;
  font-size: 12px;
  font-family: PingFang SC;
  font-weight: 400;
  text-align: center;
  line-height: 26px;
  color: #c99f4f;
  position: absolute;
  top: 489px;
  left: 1456px;
  cursor: pointer;
}
.Line {
  width: 1920px;
  border-bottom: 2px solid #c99f4f;
  position: absolute;
  top: 164px;
  margin-bottom: 9px;
}
.contract {
  box-sizing: border-box;
  width: 1190px;
  height: 50px;
  background: #f9f9f9;
  border-bottom: 2px solid #fae2a5;
  margin: 0 auto;
  padding-top: 16px;
  span {
    font-size: 14px;
    font-family: PingFang SC;
    font-weight: 600;
    color: #444444;
    padding: 0px 18px 13px 18px;
    border-bottom: 2px solid #222b43;
  }
}
.information {
  width: 1190px;
  min-height: 148px;
  margin: 20px auto 0;
  position: relative;
  display: flex;
  ul {
    width: 60%;
  }
  .information_left {
    width: 40%;
    li {
      margin-bottom: 10px;
      p {
        display: inline-block;
        font-size: 12px;
        font-family: PingFang SC;
        font-weight: 400;
        line-height: 17px;
        color: #888888;
      }
      span {
        font-size: 12px;
        font-family: PingFang SC;
        font-weight: 400;
        line-height: 17px;
        color: #444444;
      }
    }
  }
  .information_right {
    li {
      margin-bottom: 10px;
      p {
        display: inline-block;
        font-size: 12px;
        font-family: PingFang SC;
        font-weight: 400;
        line-height: 17px;
        color: #888888;
      }
      span {
        font-size: 12px;
        font-family: PingFang SC;
        font-weight: 400;
        line-height: 17px;
        color: #444444;
      }
    }
  }
}
.contract_btns {
  a {
    color: #0082ff;
    font-size: 12px;
    font-family: PingFang SC;
    font-weight: 400;
    color: #0082ff;
  }
}
table {
  margin: 46px auto 0;
  width: 100%;
  thead {
    tr {
      td {
        text-align: left;
      }
    }
  }
  tbody {
    tr {
      border: 1px solid #eeeeee;
      td {
        text-align: left;
        line-height: 45px;
        height: 45px;
        font-size: 12px;
        font-family: PingFang SC;
        font-weight: 400;
        color: #444444;
        padding: 0 12px;
      }
    }
  }
}
.breadcrumb {
  width: 1190px;
  margin: auto;
}
footer {
  width: 1920px;
  height: 60px;
  background: #313131;
  position: absolute;
  bottom: 0;
  left: 0;
  display: flex;
  .btns {
    margin: auto;
    width: 260px;
    height: 34px;
    span {
      display: inline-block;
      text-align: center;
    }
    .btn_one {
      width: 120px;
      height: 34px;
      background: linear-gradient(125deg, #d7b064 0%, #ecce8b 100%);
      font-size: 12px;
      font-family: PingFang SC;
      font-weight: 400;
      color: #ffffff;
      line-height: 34px;
    }
    .btn_two {
      width: 120px;
      height: 34px;
      line-height: 34px;
      background: #ffffff;
      font-size: 12px;
      font-family: PingFang SC;
      font-weight: 400;
      color: #c99f4f;
      margin-left: 16px;
    }
  }
}
.dis-flex {
  display: flex;
}
.table-container {
  position: relative;
  width: 1190px;
  margin: auto;
  padding-bottom: 50px;
  .reconciliation-receipt {
    position: absolute;
    top: -36px;
    right: 0;
    height: 26px;
    line-height: 26px;
    padding: 0 8px;
  }
  table {
    thead {
      tr {
        border: 1px solid #eee;
        td {
          background: #f9f9f9;
          height: 50px;
          line-height: 50px;
          padding: 0 12px;
          color: #888888;
          font-size: 14px;
          font-weight: bold;
        }
      }
    }
  }
}
</style>