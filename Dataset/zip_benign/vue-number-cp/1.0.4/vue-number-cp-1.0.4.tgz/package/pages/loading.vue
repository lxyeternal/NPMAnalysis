<template>
    <div class="success-wrap">
        <Header></Header>
        <SearchBar :is-white-bg="true" :search-type="5" :progress="''" :is-border-bottom="true" :product-create-process="3"></SearchBar>
        <div class="success-wrap-content" id='success-wrap-content-res' style="height:1000px;">
            <div style="text-align: center;
            font-size: 14px;
            color: #666;
            padding-top: 100px;
            padding-bottom: 200px;">正在拼命加载，请耐心等待!</div>
           <Loading :is-loading="true"></Loading>
        </div>
        
  </div>
</template>

<script>
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from '@/components/base/Loading'
export default {
    components: {
        Header,
        SearchBar,
        Loading
    },
    data() {
        return {
       
        };
    },

    methods: {
        init() {
        },

    },
    mounted() {
        //this.init();
    }
};
</script>

<style lang="scss" scoped>

</style>