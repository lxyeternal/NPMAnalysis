<template>
  <div>
    <Header :is-white-bg="false"></Header>
    <SearchBar :is-white-bg="true" :search-type="5" :progress="authorizationFlg ? '修改授权书':'资料完善'" :is-border-bottom="true"></SearchBar>
    <div class="inner-container regist-perfect-info">
      <el-form ref="form" :model="form" :rules="rules" label-width="185px">
        <!-- 公司信息 -->
        <div class="info-panel" v-if="!authorizationFlg">
          <p class="info-panel-title">公司信息</p>
          <div class="info-panel-content">
            <div class="form-inline-item">
              <el-form-item label="公司名称：" prop="corpName">
                <el-input v-model="form.corpName" disabled placeholder="" @focus="checkForm('corpName',$event)" @blur="handleSearchCorp"></el-input>
                <div class="el-form-item__error" v-if="errorRules['corpName']">
                  {{ errorRules["corpName"] }}
                </div>
              </el-form-item>
              <el-form-item label="统一社会信用代码：" prop="busiLicense">
                <el-input v-model="form.busiLicense" disabled placeholder="" @focus="checkForm('busiLicense')" maxlength="18"></el-input>
                <div class="el-form-item__error" v-if="errorRules['busiLicense']">
                  {{ errorRules["busiLicense"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="法人代表：" prop="legalRepresent">
                <el-input disabled v-model="form.legalRepresent" placeholder="请输入" @focus="checkForm('legalRepresent')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['legalRepresent']">
                  {{ errorRules["legalRepresent"] }}
                </div>
              </el-form-item>
              <!-- <el-form-item label="法人证件号：" prop="legalCertNo">
                <el-input type="text" v-model="form.legalCertNo" placeholder="请输入" @focus="checkForm('legalCertNo')" maxlength="100"></el-input>
                <div class="el-form-item__error" v-if="errorRules['legalCertNo']">
                  {{ errorRules["legalCertNo"] }}
                </div>
              </el-form-item> -->
            </div>
            <div class="form-inline-item">
              <el-form-item label="注册资本（万元）：" prop="registCapital">
                <el-input :disabled="isManufactorFlg" type="text" v-model="form.registCapital" placeholder="请输入" @focus="checkForm('registCapital')" maxlength="100"></el-input>
                <div class="el-form-item__error" v-if="errorRules['registCapital']">
                  {{ errorRules["registCapital"] }}
                </div>
              </el-form-item>
              <el-form-item label="纳税人资格：" prop="taxpayerType">
                <el-radio-group v-model="form.taxpayerType">
                  <el-radio :disabled="isManufactorFlg" label="0">一般纳税人</el-radio>
                  <el-radio :disabled="isManufactorFlg" label="1">小规模纳税人</el-radio>
                </el-radio-group>
                <div class="el-form-item__error" v-if="errorRules['taxpayerType']">
                  {{ errorRules["taxpayerType"] }}
                </div>
              </el-form-item>
            </div>

            <div class="form-inline-item">
              <el-form-item label="企业类型：" prop="corpTypeName">
                <el-input :disabled="isManufactorFlg" v-model="form.corpTypeName" placeholder="请输入" @focus="checkForm('corpTypeName')" maxlength="32"></el-input>
                <div class="el-form-item__error" v-if="errorRules['corpTypeName']">
                  {{ errorRules["corpTypeName"] }}
                </div>
              </el-form-item>
              <el-form-item label="成立日期：" prop="establishDt">
                <el-date-picker :disabled="isManufactorFlg" value-format="yyyy-MM-dd" v-model="form.establishDt" size="" type="date" placeholder="请选择日期" @change="checkForm('establishDt')">
                </el-date-picker>
                <div class="el-form-item__error" v-if="errorRules['establishDt']">
                  {{ errorRules["establishDt"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="公司简称：" prop="shortCorpName">
                <el-input :disabled="isManufactorFlg" v-model="form.shortCorpName" maxlength="6" placeholder="请输入" @focus="checkForm('shortCorpName')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['shortCorpName']">
                  {{ errorRules["shortCorpName"] }}
                </div>
              </el-form-item>
              <el-form-item label="上级公司名称：" prop="supCorpName">
                <el-input :disabled="isManufactorFlg" v-model="form.supCorpName" placeholder="请输入" @focus="checkForm('supCorpName')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['supCorpName']">
                  {{ errorRules["supCorpName"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-upload-text">
              <span class="form-upload-text-left"><i :class="{red:!isManufactorFlg}">*</i> 营业执照：</span><span class="form-upload-right">请上传工商营业执照、组织机构代码证、税务登记证或三证合一的营业执照 (单张图片大小不超过1M，建议方形尺寸500*500，jpg或png格式)</span>
            </div>
            <div class="form-upload-content">
              <el-form-item label="" prop="attachList">
                <div class="info-master-img">
                  <div class="img-item" :class="{ 'has-img': img.previewSrcr }" v-for="(img, index) in imgList" :key="index">
                    <div class="img-item-cover">
                      <div class="img-item-add">
                        <label :for="'masterImg' + index">
                          <i v-if="!isManufactorFlg" class="el-icon-plus"></i>
                        </label>
                        <img v-if="img.previewSrcr" :src="img.previewSrcr" />
                        <input v-if="!isManufactorFlg" :id="'masterImg' + index" type="file" ref="imgFileBtn" @change="pushImg($event, index,'imgList')" />
                      </div>
                      <div class="img-item-bottom" v-if="img.previewSrcr" :class="{'manufactor-flg' : isManufactorFlg}">
                        <a @click="clearImg(index,'imgList')" v-if="!isManufactorFlg">删除</a>
                        <a @click="img.dialogVisible = true">预览</a>
                      </div>
                    </div>
                    <el-dialog title="" :visible.sync="img.dialogVisible">
                      <img :src="img.previewSrcr" alt="" />
                    </el-dialog>
                  </div>
                </div>
                <div class="el-form-item__error">{{ imgListImgError }}</div>
              </el-form-item>
            </div>

            <!-- 供应商 -->
            <div class="form-item" style="width:60%;">
              <el-form-item label="营业期限：" prop="dealFrom">
                <el-row>
                  <el-col :span="11">
                    <el-date-picker :disabled="isManufactorFlg" value-format="yyyy-MM-dd" v-model="form.dealFrom" size="" type="date" placeholder="开始日期">
                    </el-date-picker>
                  </el-col>
                  <el-col :span="2" class="tc">~</el-col>
                  <el-col :span="11">
                    <el-date-picker :disabled="isManufactorFlg" value-format="yyyy-MM-dd" v-model="form.dealTo" size="" type="date" placeholder="结束日期">
                    </el-date-picker>
                  </el-col>
                </el-row>
                <div class="el-form-item__error" v-if="errorRules['dealFrom']">
                  {{ errorRules["dealFrom"] }}
                </div>
              </el-form-item>
            </div>
            <div style="margin-bottom: 22px;line-height: 40px;" v-if="isManufactorFlg">
              <span style="float: left;width: 185px; text-align: right;font-size: 12px">
                <span class="red" style="padding-right: 2px;">*</span><span class="color888">公司类型：</span>
              </span>
              <div class="fl register-input-outer">
                <div class="register-input-box">
                  <el-radio-group v-model="form.accountType" @change="changeAccountType">
                    <p>
                      <el-radio label="agent">代理商</el-radio>
                      <el-radio label="distributor">经销商</el-radio>
                      <el-radio label="subsidiary">分/子公司</el-radio>
                    </p>
                  </el-radio-group>
                </div>
              </div>
              <div style="clear: both;"></div>
            </div>
            <template>
              <div style="margin-bottom: 22px;line-height: 40px;">
                <span style="float: left;width: 185px; text-align: right;font-size: 12px">
                  <span class="red" style="padding-right: 2px;">*</span><span class="color888">经营品类：</span>
                </span>
                <div style="width: 945px;float: left">
                  <multipleDropdownTree @categoryInfo="getCategoryInfo" :width="'1005px'" :dataList="cateList" :limitCategoryList="limitCategoryList"></multipleDropdownTree>
                  <div style="clear: both"></div>
                </div>
                <div style="clear: both"></div>
              </div>
            </template>
            <template v-if="brandListData && brandListData.length">
              <div style="margin-bottom: 22px;line-height: 40px;">
                <span style="float: left;width: 185px; text-align: right;font-size: 12px">
                  <span class="red" style="padding-right: 2px;">*</span><span class="color888">经营品牌：</span>
                </span>
                <div style="width: 945px;float: left">
                  <el-checkbox-group v-model="form.brandList" class="brand-checkbox-container">
                    <el-checkbox v-for="item in brandListData" :label="item.brandId" :key="item.brandId">{{item.brandNameCn}}</el-checkbox>
                  </el-checkbox-group>
                  <div style="clear: both"></div>
                </div>
                <div style="clear: both"></div>
              </div>
            </template>
          </div>
        </div>
        <div class="info-panel">
          <p class="info-panel-title">
            代理商/经销商授权
            <!-- <i style="margin-left: 20px;" class="red">需提供厂家授权书。请点击【下载模版】，填写《大家采平台代理商公司厂家授权委托书》并加盖公司公章后，上传授权书的PDF扫描件。</i> -->
          </p>
          <el-form-item label="上传授权书：" :required="true" class="authorization">
            <el-col :span="24">
              <ul class="neet-upload-upfile" :class="{isie:isIE11}">
                <li>
                  <p class="input-file-p">
                    <span class="gray">
                      {{upfileResultName || '请上传授权书'}}
                    </span>
                    <!--<span v-else>{{authorizationInfo.name || ''}}</span>-->
                  </p>
                </li>
                <li>
                  <div class="upfile-container">
                    <div class="center">
                      <label class="blue">
                        <!-- <input name="my-upfile-component-input-name" type="file" @change="handleUpload" /> -->
                        <UpfileComponent ref="upfileRef" :immediateClearList="true" :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :btnName="'选择文件'" :dirName="`${new Date().getTime()}/`" :type="'4'" :fileTypes="this.uploadFileSuffix" :id="'123'" @outputList="handleUpFileResult($event)"></UpfileComponent>
                      </label>
                    </div>
                  </div>
                </li>
              </ul>
            </el-col>
            <!-- <el-col :span="3">
              <el-button style="width: 120px;height:40px;margin-left:3px;" @click="handleDownTemp()">下载模板</el-button>
            </el-col> -->
          </el-form-item>
          <div class="upload-cont">
            <div class="upload-title">
              <span>
                已上传文本
              </span>
              <span>
                上传时间
              </span>
              <span>
                操作
              </span>
            </div>
            <div class="upload-title tl" v-if="authorizationInfo.attachName">
              <span>
                {{authorizationInfo.attachName}}
              </span>
              <span>
                {{authorizationInfo.creTm}}
              </span>
              <span>
                <i class="hand blue" @click="delFileInfo">删除</i>
                <i v-if="authorizationInfo.viewUrl" class="hand blue" @click="handleDownload">下载</i>
              </span>
            </div>
          </div>
        </div>
        <div class="continue" v-if="!authorizationFlg">
          <el-button class="large-btn" type="primary" @click="submit('rules')">提交并继续</el-button>
        </div>
        <div class="continue" v-else>
          <el-button class="large-btn" type="primary" @click="submitAuthorization()">提交并继续</el-button>
        </div>
      </el-form>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import Distpicker from "@/components/base/Distpicker";
import { InterfaceService } from '@/services/api'
import { DateUtil } from '@/utils/dateUtil';
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
import DropdownTree from "@/components/order/dropdownTree";
import multipleDropdownTree from "@/components/order/multipleDropdownTree";

export default {
  components: {
    Header,
    SearchBar,
    Loading,
    UpfileComponent,
    DropdownTree,
    Distpicker,
    multipleDropdownTree
  },
  data() {
    var validateDate = (rule, value, callback) => {
      if (value) {
        var thetime = value
        var curDate = new Date(Date.parse(localStorage.getItem('systemTime').replace(/-/g, "/")));
        if (thetime > curDate) {
          callback(new Error('请选择有效的成立日期'));
        } else {
          callback();
        }
      } else {
        callback();
      }
    };
    var validateDateSection = (rule, value, callback) => {
      if (value) {
        var thetimeFirst = value
        var thetimeSecond = this.form.dealTo
        if (thetimeSecond && thetimeFirst > thetimeSecond) {
          this.form.dealFrom = ''
          // this.form.dealTo = ''
          callback(new Error('请选择有效的营业期限'));
        } else {
          callback();
        }

      } else {
        callback();
      }
    };

    var validatePass2 = (rule, value, callback) => {
      if (!/^[A-Za-z0-9]+([._\\-]*[A-Za-z0-9])*@([a-zA-Z0-9]+[-a-z0-9]*[a-zA-Z0-9]+.){1,63}[a-zA-Z0-9]+$/.test(value)) {
        callback(new Error('邮箱格式不正确'));
      } else {
        const mail = value || '',
          mailSuffix = mail.slice(mail.lastIndexOf('.') + 1, mail.length)

        const errorMailSuffix = JSON.parse(this.$getRootLocalStorage('errorMailSuffix') || '[]')
        if (errorMailSuffix.includes(mailSuffix)) {
          callback(new Error('邮箱后缀不正确'));
          return
        }
        callback();
      }
    };
    let agentUserInfo = JSON.parse(this.$getRootScope("agentUserInfo") || '{}')
    let isManufactorFlg = agentUserInfo.isManufactor == '1'
    return {
      isLoading: false,
      categoryId: "",
      imgList: [
        { 'previewSrcr': '', 'file': '', 'dialogVisible': false },
      ],
      brandListData: [],
      delImgList: [],
      cateList: [{
        categoryId: "",
        fullName: "",
        parentId: "",
        originalId: "",
      }],
      dialogFormVisible: false,
      isReject: false,
      pcbCode: {},
      imgListImgError: '',
      upfileResultName: '', // 上传文件名称
      form: {
        brandList: [],
        corpName: '',
        supCorpName: '',
        busiLicense: '',
        corpTypeName: '',
        establishDt: '',
        legalRepresent: '',
        // legalCertNo: '',
        taxpayerType: '',
        registCapital: '',
        prodType: [],
        attachList: [],
        dealFrom: '',
        dealTo: '',
        adminName: '',
        adminCertNo: '',
        adminMobile: '',
        adminEmail: '',
        department: '',
        shortCorpName: '',
        acctId: ''
      },
      // 用于判断 管理员输入框是否 可以输入
      adminFormBackup: {
        adminName: '',
        adminCertNo: '',
        adminMobile: '',
        adminEmail: '',
      },
      limitCategoryList: [], // 限制数据
      rules: {
        corpName: [
          {
            required: !isManufactorFlg,
            message: "必填"
          },
          { max: 200, message: "公司名称不得大于200个字", trigger: "blur" }
        ],
        shortCorpName: [
          {
            required: !isManufactorFlg,
            message: "必填"
          },
          { max: 6, message: "公司简称不得大于6个字", trigger: "blur" }
        ],
        supCorpName: [
          { max: 200, message: "上级公司名称不得大于200个字", trigger: "blur" }
        ],
        busiLicense: [
          {
            required: !isManufactorFlg,
            message: "必填"
          },
          { pattern: /^[0-9A-Z]{18}/, message: '请输入正确的统一社会信用代码', trigger: "blur" }
        ],
        corpTypeName: [
          {
            required: !isManufactorFlg,
            message: "必填",
            trigger: 'blur'
          }
        ],
        establishDt: [
          {
            required: !isManufactorFlg,
            message: "必填"
          },
          { validator: validateDate, trigger: 'blur' }
        ],
        legalRepresent: [
          {
            required: !isManufactorFlg,
            message: "必填",
            trigger: 'blur'
          },
          { max: 200, message: "法人代表不得大于200个字", trigger: "blur" }
        ],
        taxpayerType: [
          {
            required: !isManufactorFlg,
            message: "请选择纳税人资格",
            trigger: "change"
          }
        ],
        registCapital: [
          {
            required: !isManufactorFlg,
            message: "请填写注册资本",
            trigger: 'blur'
          }
        ],
        dealFrom: [
          {
            required: !isManufactorFlg,
            message: "必填"
          },
          { validator: validateDateSection, trigger: 'blur' }
        ],
        attachList: [
          {
            required: !isManufactorFlg,
            message: "请上传营业执照附件"
          }
        ]
      },
      addressCode: {},
      errorRules: {},
      authorizationInfo: {},
      isFirstSubmit: true,
      isChangeImg: false,
      canClick: true,
      timer: '',
      uploadFileSuffix: 'pdf',
      focusCorpName: '',
      registerAdvancedInfo: {}, // 下一页面需要数据
      supplierBiddingInfo: {}, // 招募令 - 去完善注册进入
    };
  },
  computed: {
    authorizationFlg() {
      return this.$route.query.authorizationFlg == '1'
    },
    isIE11() {
      let userAgent = navigator.userAgent;
      return userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; // ie11<11
    },
    userInfo() {
      return this.$store.state.userInfo || {}
    },

    agentUserInfo() {
      return JSON.parse(this.$getRootScope("agentUserInfo") || '{}')
    },
    isManufactorFlg() {
      return this.agentUserInfo.isManufactor == '1'
    }
  },
  methods: {
    changeAccountType(value) {
      this.form.accountType = value;//identifyCode
      this.$forceUpdate();
    },
    init() {
      this.limitCategoryList = this.agentUserInfo.limitCategoryList || []
      this.initSearchBrandList()
      this.initSupplierBiddingInfo()
      this.getOrderConfiguration()
      this.errorRules = {}
      this.form.corpName = this.agentUserInfo.corpName || "";

      if (this.form.corpName) {
        if (!this.isManufactorFlg) {
          this.handleSearchCorp(this.form.corpName)
        }else {
          this.getVendorMessage();
        }
      }
    },

    getCategoryInfo(info) {
      info.forEach(f => {
        // 如果一条都没有 做添加处理
        if (!this.cateList.length) {
          this.cateList.push({
            categoryId: f.categoryId,
            fullName: f.brandName,
            parentId: f.parentId,
            originalId: f.originalId,
          })
        } else {
          // 如果没找到 做 新增处理
          if (!this.cateList.some(s => {
            // 如果 已有 做更新处理
            if (f.categoryId == s.categoryId) {
              s.fullName = f.brandName
              s.parentId = f.parentId
              s.originalId = f.originalId
              this.$set(s, 'delete', false)
              return true
            }
          })) {
            // 如果已经添加过 则 跳过
            if (this.cateList.some(s => s.categoryId == f.categoryId)) return
            this.cateList.push({
              categoryId: f.categoryId,
              fullName: f.brandName,
              parentId: f.parentId,
              originalId: f.originalId,
            })
          }
        }
      })
      // 如果 在cateList 没有找到该数据 说明已经删除
      this.cateList.forEach(f => {
        // 未找到
        if (!f.categoryId) return
        if (!info.some(s => f.categoryId == s.categoryId)) {
          this.$set(f, 'delete', true)
        }
      })

    },
    outputValue(ev, cate, index) {
      let num = 0;
      this.cateList.forEach(item => {
        if (item.categoryId && item.categoryId == cate) {
          num++
        }
      })
      if (num >= 2) {
        this.cateList.splice(index, 1);
        this.$message.error("已存在该类目")
      }
    },
    handleDelCateSelection(index) {
      this.cateList.splice(index, 1)
    },
    handleAddCateSelection() {
      this.cateList.push({
        categoryId: "",
        fullName: "",
        parentId: "",
        originalId: "",
      })
    },
    // 如果是去完善 跳转过来 需要 初始化信息
    initSupplierBiddingInfo() {
      try {
        this.supplierBiddingInfo = JSON.parse(this.$getRootScope('supplierBiddingInfo') || '{}')
        if (this.supplierBiddingInfo && this.supplierBiddingInfo.respCode) {
          // 初始化信息
          const {
            supplierName, busiLicense, corpType, establishDt,
            legalRepresent, registCapital, dealFrom, dealTo, taxpayerType
          } = this.supplierBiddingInfo

          this.form.corpName = supplierName
          this.form.busiLicense = busiLicense
          this.form.corpTypeName = corpType
          this.form.establishDt = establishDt

          this.form.legalRepresent = legalRepresent
          this.form.taxpayerType = taxpayerType
          this.form.registCapital = registCapital
          this.form.dealFrom = dealFrom
          this.form.dealTo = dealTo

        }
      } catch (error) {
        console.error('initSupplierBiddingInfo', error);
      }
    },
    handleUpFileResult(e) {
      this.delFileInfo()
      const { file, name, targetValue, url } = e[0]
      this.authorizationInfo = {
        file: file,
        attachName: name,
        creTm: this.dateFormat("YYYY-mm-dd HH:MM", new Date()),
        targetValue,
        attachUrl: url
      }
    },
    dateFormat(fmt, date) {
      let ret;
      const opt = {
        "Y+": date.getFullYear().toString(),        // 年
        "m+": (date.getMonth() + 1).toString(),     // 月
        "d+": date.getDate().toString(),            // 日
        "H+": date.getHours().toString(),           // 时
        "M+": date.getMinutes().toString(),         // 分
        "S+": date.getSeconds().toString()          // 秒
      };
      for (let k in opt) {
        ret = new RegExp("(" + k + ")").exec(fmt);
        if (ret) {
          fmt = fmt.replace(ret[1], (ret[1].length == 1) ? (opt[k]) : (opt[k].padStart(ret[1].length, "0")))
        }
      }
      return fmt;
    },
    /**
     * 重置input value  防止 同一个文件连续提交 不触发 onchange事件
     */
    resetInputValue() {
      let isIE10 = false,
        uploadInputs = document.getElementsByName('my-upfile-component-input-name') || []
      if (window.navigator.userAgent.indexOf('MSIE') >= 1) { // 判断ie10以及以下
        isIE10 = true
      } else {
        isIE10 = false
      }
      for (let i = 0, len = uploadInputs.length; i < len; i++) {
        const element = uploadInputs[i];

        if (isIE10) {
          let form = document.createElement('form'),
            beforInput = element.nextSibling,
            parentInput = element.parentNode

          form.appendChild(element)
          form.reset()
          parentInput.insertBefore(element, beforInput)
        } else {
          element.value = ''
        }

      }
    },
    getOrderConfiguration() {
      const params = {
        businessType: 'AUTHORIZATION'
      };
      InterfaceService.getOrderConfiguration(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          let list = res.uploadFileList || [];
          list.forEach(item => {
            if (item.fileTypeId === "regist_authorization") {
              this.templateFileUrl = item.attachUrl || "";
              this.templateFileName = item.templateFileName || "";
              this.uploadFileSuffix = item.uploadFileSuffix || "pdf";
            }
          })
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    handleDownload() {
      let info = {};
      info.name = this.authorizationInfo.attachName
      info.url = this.authorizationInfo.viewUrl
      this.$download([info]).then(e => {
        this.$message.success('下载成功')
      })
    },
    delFileInfo() {
      if (this.authorizationInfo.id) {
        this.delImgList.push({ attachId: this.authorizationInfo.id });
      }
      this.authorizationInfo = {};
    },
    timestampToTime(timestamp) {
      let date = new Date(timestamp);
      let Y = date.getFullYear() + '-';
      let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
      let D = date.getDate() + ' ';
      return Y + M + D;
    },
    handleSearchCorp(name) {
      InterfaceService.doGetProviderRiskDetail(
        { name: name, type: "baseInfo" },
        data => {
          if (data.respData.respCode === "0000") {
            let corpInfo = data.respData.riskBaseInfoBean || {};
            this.form.establishDt = corpInfo.estiblishTime || "";
            this.form.registCapital = corpInfo.regCapital || "";
            this.form.dealFrom = corpInfo.fromTime && this.timestampToTime(corpInfo.fromTime) || "";
            this.form.dealTo = corpInfo.toTime && this.timestampToTime(corpInfo.toTime) || "";
            this.form.corpTypeName = corpInfo.companyOrgType || "";
            this.errorRules = {}
            this.getVendorMessage();
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },

    /**
     * 查询 供应商
     */
    initSearchBrandList() {
      this.getVendorMessageBrand()
    },
    getVendorMessageBrand() {
      const params = {
        corpId: this.userInfo.corpId
      }
      InterfaceService.rejectQuerySupplier(params, (data) => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.brandListData = data.respData.brandList
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      });
    },

    /**
     * 驳回-查询
     * @param supplierCorpId 查询 供应商
     */
    getVendorMessage() {
      const params = {
        corpId: this.agentUserInfo.corpId
      }
      InterfaceService.rejectQuerySupplier(params, (data) => {
        if (data && data.respData && data.respData.respCode === "0000") {
          try {
            this.isReject = !!data.respData.corpAddrInfoRst.regProvCode
            this.$setRootScope('registerAdvancedInfo', JSON.stringify(Object.assign({}, data.respData.acCorpFinInfoBean || {}, data.respData.corpAddrInfoRst || {}, { taxClassifyList: data.respData.corpTaxClassifyList || [] })))
          } catch (error) {
            console.log('try: ', error);
          }
          if (data.respData && data.respData.acCorpContactInfoList && data.respData.acCorpContactInfoList.length) {
            // 管理员 acctId
            data.respData.acCorpContactInfoList.some(s => s.contactType == '9' && (this.form.acctId = s.acctId))
          }
          console.log(this.form.acctId, 'this.form.acctId');

          this.form.busiLicense = this.agentUserInfo.busiLicense || this.userInfo.busiLicense || "";
          this.form.legalRepresent = data.respData.acCorpInfoBean && data.respData.acCorpInfoBean.legalRepresent || this.agentUserInfo.legalRepresent || this.userInfo.legalRepresent || "";
          // 只 查询 供应商 品牌
          this.antiDisplayDataAcCorpInfoBean(data.respData)
          this.antiDisplayDataAcSupplierInfoBean(data.respData.acSupplierInfoBean)
          this.antiDisplayDataAcCorpAttachInfoList(data.respData.acCorpAttachInfoList)
          // this.cateList = data.respData.categoryList.length && data.respData.categoryList || [{
          //   categoryId: "",
          //   fullName: "",
          //   parentId: "",
          //   originalId: "",
          // }];

          // 默认选中 limitCategoryList 里面 数据
          this.cateList = this.limitCategoryList || [{
            categoryId: "",
            fullName: "",
            parentId: "",
            originalId: "",
          }];
          // this.form = Object.assign(this.form,data.respData.acCorpFinInfoBean || {},data.respData.corpAddrInfoRst || {});
          this.registerAdvancedInfo = JSON.stringify(Object.assign({}, data.respData.acCorpInfoBean || {}, data.respData.acCorpFinInfoBean || {}, data.respData.corpAddrInfoRst || {}))

        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      });
    },
    // 公司基本信息
    antiDisplayDataAcCorpInfoBean(data) {
      const FORM = {
        corpName: this.form.corpName || data.acCorpInfoBean.corpName || "",
        supCorpName: this.form.supCorpName || data.acCorpInfoBean.supCorpName || "",
        busiLicense: this.form.busiLicense || data.acCorpInfoBean.busiLicense || "",
        corpTypeName: this.form.corpTypeName || data.acCorpInfoBean.corpTypeName || "",
        establishDt: this.form.establishDt || data.acCorpInfoBean.establishDtStr || "",
        legalRepresent: this.form.legalRepresent || data.acCorpInfoBean.legalRepresent || "",
        taxpayerType: data.acCorpInfoBean.taxpayerType || data.acCorpInfoBean.taxpayerType || "",
        registCapital: this.form.registCapital || data.acCorpInfoBean.registCapital || "",
        shortCorpName: this.form.shortCorpName || data.acCorpInfoBean.shortCorpName || "",
      }
      FORM.brandList = [];
      if (this.isManufactorFlg) {
        if(data.brandList && data.brandList.length){
          data.brandList.forEach(i=>{
            this.brandListData.forEach(brand=>{
              if (brand.brandId === i.brandId) {
                FORM.brandList.push(i.brandId)
              }
            })
          })
        }
      } else {
        if(data.brandList && data.brandList.length){
          data.brandList.forEach(i=>{
                FORM.brandList.push(i.brandId)
          })
        }
      }
      this.form = Object.assign({}, this.form, FORM)
    },
    //  公司基本信息 - 经营期限-范围
    antiDisplayDataAcSupplierInfoBean(data) {
      if (data) {
        const FORM = {
          dealFrom: this.form.dealFrom || data.dealFromStr || "",
          dealTo: this.form.dealTo || data.dealToStr || "",
        }
        this.form = Object.assign({}, this.form, FORM)
      }
    },
    handleDownTemp() {
      this.$download([{
        name: this.templateFileName || '',
        url: this.templateFileUrl || ''
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    // 上传图片
    antiDisplayDataAcCorpAttachInfoList(data) {
      if (data) {
        this.imgList = [];
      }
      for (let i = 0, len = data.length; i < len; i++) {
        if (data[i]) {
          const itemUrl = data[i].attachContent || '';
          const url = itemUrl.slice(itemUrl.indexOf('/djc'), itemUrl.length)
          if (data[i].attachType === "0") {
            this.imgList.push({
              previewSrcr: itemUrl,
              file: { name: itemUrl.slice(itemUrl.lastIndexOf('/') + 1, itemUrl.length) },
              id: data[i].attachId,
              dialogVisible: false,
            })
            this.form.attachList[i] = {
              "attachUrl": `#url#${url}`,
              "attachType": `0`,
            };
          } else if (data[i].attachType === "4" && data[i].authorizeSupplierId == this.userInfo.corpId) {
            this.form.attachList[i] = {
              "attachUrl": this.authorizationInfo && this.authorizationInfo.attachUrl || '', // 替换地址
              "attachType": `4`,
            };
            this.authorizationInfo = {
              attachName: data[i].attachName,
              id: data[i].attachId || "",
              creTm: data[i].creTm,
              attachUrl: data[i].attachPath,
              viewUrl: data[i].attachUrl,
            }
          }
        }
      }
      console.log(this.authorizationInfo, '0this.authorizationInfo');

      if (this.imgList.length < 3 && !this.isManufactorFlg) {
        this.imgList.push({ 'previewSrcr': '', 'file': '', 'dialogVisible': false })
      }
    },
    getCropId() {
      InterfaceService.registerGetCropId({}, (data) => { },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    checkForm(key, ev) {
      if (ev) {
        this.focusCorpName = ev.target.value || ""
      }
      if (this.form[key]) {
        delete this.errorRules[key]
      }
      if (ev == 'establishDt') {
      }
    },
    submit(rules) {
      console.log(this.form);
      let _this = this;
      let _loadImg = [];
      let upLoadState = false;
      for (let i = 0; i < _this.imgList.length; i++) {
        if (!_this.imgList[i].id) {
          let file = _this.imgList[i] && _this.imgList[i].file
          if (file) {
            _loadImg.push(_this.imgList[i])
          }
        }
      }
      _this.imgList.forEach(item => {
        if (!!item.id) {
          upLoadState = true;
        }
      })
      if (!upLoadState && _loadImg.length == 0) {
        _this.imgListImgError = '请上传营业执照附件'
        return false
      }
      if(this.isManufactorFlg && !this.form.accountType){
        _this.$message.error('请选择公司类型')
        return false
      }
      let bool = this.cateList.some(item => item.categoryId && !item.delete);
      if (!bool) {
        _this.$message.error('请选择经营品类')
        return false
      }
      if(this.brandListData && this.brandListData.length && !this.form.brandList.length){
        _this.$message.error('请选择经营品牌')
        return false
      }
      if (!this.authorizationInfo.attachName) {
        _this.$message.error('请上传授权书')
        return false
      }
      // 如果loadImg长度为0 , 说明用的是反显数据图片, 直接提交
      _this.$refs.form.validate((valid) => {
        if (valid) {
          _this.form['attachList'] = []
          _this.form['attachList'].push({
            'attachUrl': this.authorizationInfo && this.authorizationInfo.attachUrl || '', // 替换地址,
            'attachType': "4",
          })

          if (_this.isFirstSubmit) {//未上传过图片或者上传过但是更换过图片 则直接提交
            if (_loadImg.length === 0) {
              _this.submitCompelet()
              return
            }
            if (_loadImg.length) {
              //先上传图片
              //去后端拿签名一次性
              InterfaceService.getOssSignatureDisposable('',{}, (data) => {
                let signature = data
                // 如果loadImg长度为0 , 说明用的是反显数据图片, 直接提交
                for (let pos = 0; pos < _loadImg.length; pos++) {
                  let file = _loadImg[pos] && _loadImg[pos].file
                  let fileFlag = false;
                  _loadImg[pos].attachName ? fileFlag = true : fileFlag = false
                  if (file) {
                    let dirType = 'company/'
                    _this.uploadHander(pos, file, dirType, signature, (pos, file, dirType, signature) => {
                      //let u = signature.host+'/'+signature.dir+dirType+file.name
                      let u = "#url#" + '/' + signature.dir + dirType + file.name
                      if (!fileFlag) {
                        _this.form['attachList'].push({
                          'attachUrl': u,
                          'attachType': "0",
                        })
                      } else {
                      }
                      //图片上传到oss之后 提交注册信息
                      if (pos >= _loadImg.length - 1) {
                        setTimeout(() => {
                          _this.submitCompelet()
                        }, 800)
                      }
                    })
                  }
                }
              }, (data) => {
                _this.isLoading = false;
              },
                () => {
                  _this.isLoading = true;
                },
                () => {
                  //_this.isLoading = false;
                });
            }
          } else {//已经上传过图片 则直接提交
            _this.isLoading = false;
            _this.submitCompelet()
          }
        } else {

          return false;
        }
      })
    },
    submitAuthorization() {
      console.log(this.authorizationInfo);
      console.log(this.delImgList);
      if (!this.authorizationInfo.attachName) {
        this.$message.error('请上传授权书')
        return false
      }
      let params = {
        supplierId : this.userInfo.corpId,
        agentId : this.agentUserInfo.corpId,
        attachId : this.delImgList.length ? this.delImgList[0].attachId : this.authorizationInfo.id,
        attachName : this.authorizationInfo.attachName,
        attachUrl : this.authorizationInfo.attachUrl,
        attachType : '4',
      }
      console.log(params);
      InterfaceService.changeAuthorization(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            this.$router.push({
              path: "/registerSuccess",
              query: {
                contactName: this.agentUserInfo.corpName || '',
                corpId: this.agentUserInfo.corpId || '',
                isAgent: true, // 是否代理商
                authorization: true, // 是否是修改授权书
              }
            });
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    // 格式化imgList URL名字
    formatImgUrlName(imgList) {
      for (let len = imgList.length, i = len - 1; i >= 0; i--) {
        // 如果有ID表示不是新增或者修改 不进入这次更改list
        if (!imgList[i].attachId && imgList[i].attachUrl) {
          imgList[i].attachContent = imgList[i].attachUrl
          delete imgList[i].attachUrl
        } else {
          // 移除未被修改的图片
          imgList.splice(i, 1);
        }
      }
    },
    submitCompelet() {
      let _this = this;
      let params = {};
      if (!this.isManufactorFlg) {
        params = JSON.parse(JSON.stringify(_this.form));
        params.prodType = ''
        params.corpId = this.agentUserInfo.corpId;
        params.contractCorpType = this.userInfo.contractCorpType || null;
      } else {
        params = {
          corpId : this.agentUserInfo.corpId,
          contractCorpType : this.form.accountType,
          supplierCorpId : this.userInfo.corpId,
          brandList : this.form.brandList,
          supplyType : '0',
        }
      }
      params.attachList = _this.form['attachList']
      params.categoryList = []
      this.cateList.forEach(item => {
        if (item.categoryId && !item.delete) {
          params.categoryList.push(item)
        }
      });
      let brandList =[]
      this.brandListData.forEach(item => {
        params.brandList.forEach(i=>{
          if(item.brandId === i){
            brandList.push(item)
          }
        })
      });
      params.brandList = brandList
      console.log(params);
      InterfaceService.agentPerfectInfo(
        params,
        data => {
          _this.result = data.respData;
          if (_this.result.respCode == '0000') {
            _this.isFirstSubmit = false;//上传过 则此标记为false
            //去缓存里获取userInfo  加入公司信息
            let agentUserInfo = JSON.parse(_this.$getRootScope('agentUserInfo'))


            try {
              window.opener && window.opener.location.reload()
            } catch (error) { }

            // 有地址 直接 成功
            const registerAdvancedInfo = JSON.parse(this.registerAdvancedInfo || '{}') || {}
            if (registerAdvancedInfo && registerAdvancedInfo.regDistrictCode && registerAdvancedInfo.regProvCode && registerAdvancedInfo.regCityCode) {
              this.$router.push({
                path: "/registerSuccess",
                query: {
                  contactName: registerAdvancedInfo.corpName || '',
                  corpId: _this.result.corpId || '',
                  isAgent: true, // 是否代理商
                }
              });

            } else {
              agentUserInfo.corpName = _this.form.corpName
              _this.$setRootScope('agentUserInfo', JSON.stringify(agentUserInfo))
              this.$router.push({
                path: "/registerAdvanced",
                query: {
                  corpId: agentUserInfo.corpId,
                  corpName: this.form.corpName || _this.result.corpId,
                  isAgent: "agent",
                  isPurchase: true
                }
              })
            }

          } else {
            if (_this.result.respCode == 'MEM0089' || _this.result.respCode == 'MEM0037') {
              _this.errorRules['orgCode'] = _this.result.respMsg
            } else if (_this.result.respCode == 'MEM0090' || _this.result.respCode == 'MEM0036' || _this.result.respCode == 'MEM0012') {
              _this.errorRules['busiLicense'] = _this.result.respMsg
            } else if (_this.result.respCode == 'MEM0073') {
              _this.errorRules['corpName'] = _this.result.respMsg
            } else if (_this.result.respCode == 'MEM0056') {
              _this.errorRules['prevPurchase'] = _this.result.respMsg
            } else if (_this.result.respCode == 'MEM0013' || _this.result.respCode == 'MEM0037') {
              _this.errorRules['orgCode'] = _this.result.respMsg
            } else {
              _this.$message.error(_this.result.respMsg);
            }
          }
        },
        data => {

        },
        () => {
          _this.isLoading = true;
        },
        () => {
          _this.isLoading = false;
        }
      );
    },
    pushImg(event, index, listType) {//input控件（自定义）获取文件 上传
      let _this = this;
      _this.isFirstSubmit = true;//更改过图片 则视为第一次提交（需要上传图片)
      let file = event.target.files[0]
      if (file) {
        let checkTextList = JSON.parse(sessionStorage.getItem('checkTextList') || '[]');
        let onOff = false;
        let forbidText = ''
        checkTextList.forEach(i=>{
          if (i != '' && file.name.indexOf(i) != -1) {
            onOff = true
            forbidText = i
          }
        });
        if (onOff) {
          this.$message.error('文件名包含特殊字符【'+forbidText+'】,请修改文件名后再上传')
          return false
        }
        _this[listType + 'ImgError'] = ''
        // 判断是否图片
        if ((file.type).indexOf("image/") == -1) {
          _this[listType + 'ImgError'] = '请选择图片!'
          return false
        }

        let fSize = Math.round(file.size / 1024 * 100) / 100;//取得图片文件的大小
        if (fSize >= 1024) {//单位为KB
          _this[listType + 'ImgError'] = '照片最大尺寸为1024KB，请重新上传!'
          return false
        }

        for (var i in _this[listType]) {
          // name: "building.png"
          // size: 2731
          // type: "image/png"
          let cImg = _this[listType][i] && _this[listType][i].file
          if (cImg) {
            if (file.name == cImg.name && file.size == cImg.size && file.type == cImg.type) {
              _this[listType + 'ImgError'] = '图片已经存在，请重新选择!'
              return false
            }
          }
        }

        let reader = new FileReader();
        reader.onloadend = function () {
          _this[listType][index].previewSrcr = reader.result
          _this[listType][index].file = file;
          _this.form['attachList'].push({ 'attachUrl': file })
          if (_this.imgList.length < 3) {
            _this.imgList.push({ 'previewSrcr': '', 'file': '', 'dialogVisible': false })
          }
          _this.$forceUpdate();
          _this.$set(_this[listType], _this[listType]);
        }

        if (file) {
          reader.readAsDataURL(file);
        } else {
          _this.previewSrcr = "";
        }
      } else {
        _this[listType + 'ImgError'] = '图片获取错误'
      }



      // _this.uploadHander(0,file,function(pos,file,signature){
      //     let u = signature.host+'/'+signature.dir+'/'+file.name

      // })
    },
    uploadHander(pos, file, dirType, signature, callBack) {
      let _this = this;
      //去后端拿签名
      InterfaceService.uploadToOss(signature, file, dirType, pos, callBack)
    },
    reviewImg(index, listType) {
      this[listType][index].dialogVisible = true;
      this.$forceUpdate()
    },
    clearImg(index, listType) {
      // this.isFirstSubmit = true;//更改过图片 则视为第一次提交（需要上传图片)
      // 存储被删除的ID
      if (listType == 'imgList') {
        if (this.imgList[index].id !== '') {
          this.delImgList.push({ attachId: this.imgList[index].id });
        }
        let threeIpt = this.imgList.every((item) => {
          return item.file !== ""
        });
        if (threeIpt && this.imgList.length == 3) {
          this.imgList.splice(index, 1, { 'previewSrcr': '', 'file': '', 'dialogVisible': false })
        } else {
          this.imgList.splice(index, 1)
        }
      }
      // this[listType][index] = { 'previewSrcr': '', 'file': '', 'dialogVisible': false }
      this.$forceUpdate();
      this.$set(this[listType], this[listType]);
      //清空input[file]
      let file = '';
      file = document.getElementById("masterImg" + index)
      file.value = "";
    },
    goBack() {
      this.$router.go(-1);
    }
  },
  mounted() {
    this.init();
  }
};
</script>

<style lang="scss" scoped>
p {
  margin-bottom: 20px;
}
/deep/ .el-radio-group{
  p{
    margin-bottom: 0;
  }
}
a.link {
  display: inline-block;
  vertical-align: middle;
  padding: 0 10px;
  color: #7ab7e8;
}

.inner-container {
  margin-bottom: 100px;
  font-size: 14px;
}

.form-inline-item {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;

  & > div {
    width: 40%;
    flex-shrink: 0;
  }

  &.col-3 > div {
    width: 32%;
  }

  /deep/ .el-select {
    width: 100%;
  }
}
.regist-perfect-info {
  .brand-checkbox-container {
    /deep/ .el-checkbox {
      min-width: auto;
    }
  }
  /deep/ .el-form-item__label {
    font-size: 12px;
  }
  /deep/ .el-checkbox {
    min-width: 189px;
    + .el-checkbox {
      margin-left: 0px;
    }
  }
  /deep/ .el-date-editor.el-input {
    width: 100%;
  }
}

.form-item {
  position: relative;
  line-height: 40px;

  .float-right {
    position: absolute;
    top: 0;
    right: 10px;
  }
}

.info-panel {
  margin-top: 30px;
}

.brand-other {
  margin-top: 20px;
  padding-left: 30px;
}

.info-panel-title {
  border-left: 3px solid #000;
  margin: 10px 0;
  padding: 0 10px;
  font-weight: bold;
  color: rgb(41, 41, 41);
  i {
    font-size: 12px;
    color: rgb(143, 143, 143);
  }
  a {
    font-size: 12px;
    text-decoration: underline;
    color: #7ab7e8;
  }
}

.info-panel-content {
  padding-bottom: 0;
  background: #fff;
  &.bottom {
    padding-bottom: 20px;
  }
}

.info-master-img {
  .img-item {
    position: relative;
    display: inline-block;
    width: 120px;
    height: 120px;
    vertical-align: middle;
    margin-right: 20px;
    border: 1px dashed #ccc;
    border-radius: 2px;
  }

  .img-item-add {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    font-size: 30px;
    text-align: center;
    color: #ccc;
    position: relative;
    overflow: hidden;

    i {
      cursor: pointer;
    }

    input[type="file"] {
      display: none;
    }
    img {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      pointer-events: none;
      height: auto;
    }
  }

  .img-item-cover {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0);

    .img-item-top,
    .img-item-bottom {
      display: none;
      position: absolute;
      width: 100%;
      padding: 10px;
      text-align: center;
      background: rgba(167, 166, 166, 0.2);
    }

    .img-item-top {
      top: 0;
    }

    .img-item-bottom {
      bottom: 0;
      padding: 0 10px;

      a {
        display: inline-block;
        width: 46%;
        padding: 10px 5px;
        vertical-align: middle;
        color: rgb(88, 167, 231);
      }
    }
    .manufactor-flg{
      a{
        width: 100%;
      }
    }
  }

  .img-item:hover {
    .img-item-cover {
      background: rgba(255, 255, 255, 0.2);
    }

    .img-item-top,
    .img-item-bottom {
      display: block;
    }
  }

  img {
    width: 100%;
    height: 100%;
    border: none;
  }

  .img-item.has-img {
    border: none;

    .img-item-add {
      // display: none;
    }

    &:hover .img-item-add {
      display: flex;
    }
  }
}

.info-detail {
  position: relative;
  z-index: 0;
}

.info-detail-img {
  padding: 10px 30px;
  border: 1px solid #e0e0e0;
  border-top: none;
  line-height: 30px;
  background: #f5f5f5;

  button {
    float: right;
    margin: 0 5px;
  }
}

.model-table {
  thead td {
    text-align: center;
  }

  td {
    padding: 10px;
    padding-left: 0;
  }
}

.apply-dialog {
  line-height: 25px;

  a {
    text-decoration: underline;
    color: #7ab7e8;
  }
}

.fix-bottom {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  padding: 20px;
  text-align: center;
  background: rgba(79, 82, 90, 0.8);

  button {
    width: 150px;
  }
}

.form-upload-text {
  height: 40px;
  line-height: 40px;
  font-size: 12px;
  color: #888;

  .form-upload-text-left {
    display: inline-block;
    width: 185px;
    text-align: right;
  }
  .form-upload-text-right {
    display: inline-block;
    width: 100%;
    padding-left: 185px;
  }
}

.form-upload-content {
  margin-bottom: 22px;
  .info-master-img {
  }

  /deep/ .el-dialog__header {
    border-bottom: 0;
  }
}
.continue {
  text-align: center;
  margin: 0 auto 0;
}
/deep/ .el-date-editor {
  /deep/ .el-range-separator {
    width: 7%;
  }
}
.neet-upload-upfile {
  box-sizing: border-box;
  display: flex;
  border-top: 1px solid transparent;

  &.disabled {
    /deep/ .center .blue {
      // background: #dddddd !important;
      // color: #a9a9a9 !important;
    }
  }

  & > li {
    &:nth-child(1) {
      .input-file-p {
        border: 1px solid #dcdfe6;
        box-sizing: border-box;
        padding: 0 12px;
        color: #606266;
        display: block;
        display: flex;
        flex-wrap: wrap;
        min-height: 40px;
        width: 884px;

        span {
          height: 38px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        & > .gray {
          color: #c0c4cc;
          font-size: 12px;
          outline: none;
          height: 38px;
        }

        .el-tag {
          margin: 4px;
          height: 30px;
        }
      }
    }

    &:nth-child(2) {
    }

    &:nth-child(3) {
      width: 33%;
    }

    .el-button--default {
      height: 40px;
      margin-left: 4px;
    }
  }

  .el-button--primary {
    width: 119px;
    margin-right: 12px;
  }

  /deep/ .upfile-container {
    .center {
      label {
        width: 120px;
        background: linear-gradient(
          120deg,
          rgba(215, 176, 100, 1) 0%,
          rgba(236, 206, 139, 1) 100%
        );
        color: #fff !important;
        text-align: center;
        height: 40px;
      }
    }
  }
}
.isie {
  /deep/ .upfile-container {
    .center {
      label {
        height: 42px;
      }
    }
  }
}
.upload-cont {
  margin: 0 0 30px 185px;
}
.upload-title {
  background: #f5f5f5;
  border-bottom: 1px solid #fff;
  height: 35px;
  line-height: 35px;

  span {
    display: inline-block;
    padding-left: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  & span:nth-child(1) {
    width: 65%;
  }
  & span:nth-child(2) {
    width: 25%;
  }
}
.authorization {
  margin-top: 30px;
  margin-bottom: 0 !important;
}
.upfile-container {
  text-align: left;
  .center {
    input {
      width: 0;
      height: 0;
      overflow: hidden;
      opacity: 0;
      border: 0;
      padding: 0;
    }
    label {
      float: left;
      cursor: pointer;
      user-select: none;
      outline: none;
    }
  }
  ::-webkit-scrollbar {
    width: 1px !important;
  }
}
.info-panel-content {
  /deep/ .el-form-item__error {
    background: #fff;
    width: 100%;
  }
}
.dropdownTree {
  position: relative;
  float: left;
  width: 290px;
  margin-bottom: 14px;
  span {
    position: absolute;
    right: 31px;
    top: 2px;
  }
}
/deep/ .title-container {
  line-height: 40px;
  text-align: left;
}

/deep/ .body-container .center ul li {
  line-height: 35px;
}
/deep/ .body-container .center ul li {
  line-height: 35px;
}
.color888 {
  color: #888;
}
.multipleDropdownTree {
  position: relative;
  float: left;
  width: 290px;
  margin-bottom: 14px;
  span {
    position: absolute;
    right: 31px;
    top: 2px;
  }
}
</style>