<template>
  <div>
    <Header :is-white-bg="false"></Header>
    <SearchBar :is-white-bg="true" :search-type="isagentType ? 5 :7" :progress="'资料完善'" :is-border-bottom="true" :product-create-process="2"></SearchBar>
    <div class="inner-container regist-perfect-info">
      <el-form ref="form" :model="form" :rules="rules" label-width="156px">
        <!-- 财务信息 -->
        <div class="info-panel" v-if="false">
          <p class="info-panel-title">基本户银行账户信息</p>
          <div class="info-panel-content">
            <div class="form-inline-item">
              <el-form-item label="基本户开户行行名：" prop="bankName" ref="bankName">
                <el-input v-model="form.bankName" placeholder="请输入基本户开户行行名" @focus="checkForm('bankName')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['bankName']">
                  {{ errorRules["bankName"] }}
                </div>
              </el-form-item>
              <el-form-item label="基本户开户行联行号：" prop="bankCode" ref="bankCode">
                <el-input v-model="form.bankCode" placeholder="请输入12位的数字联行号" @focus="checkForm('bankCode')" maxlength="12"></el-input>
                <div class="el-form-item__error" v-if="errorRules['bankCode']">
                  {{ errorRules["bankCode"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="基本户开户人名称：" prop="bankAcctName" ref="bankAcctName">
                <el-input v-model="form.bankAcctName" placeholder="请输入基本户开户人名称" @focus="checkForm('bankAcctName')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['bankAcctName']">
                  {{ errorRules["bankAcctName"] }}
                </div>
              </el-form-item>
              <el-form-item label="基本户银行账号：" prop="bankAcct" ref="bankAcct">
                <el-input v-model="form.bankAcct" placeholder="请输入基本户银行账号" maxlength="30" @focus="checkForm('bankAcct')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['bankAcct']">{{errorRules['bankAcct']}}</div>
              </el-form-item>
            </div>
            <div class="form-inline-item-dispickter">
              <el-form-item label="基本户开户行地址：" prop="provCode" ref="provCode">
                <Distpicker v-if="areaList.length" :areaList="areaList" :address="form.addInfo" @receive="getAddressCode"></Distpicker>
                <div class="el-form-item__error" v-if="!baseRegSelectedFlg">
                  必填
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item address-input">
              <el-form-item label=" " prop="bankDetailAddr" ref="bankDetailAddr">
                <el-input v-model="form.bankDetailAddr" maxlength="200" placeholder="请输入开户行详细地址" @focus="checkForm('bankDetailAddr')"> &gt;</el-input>
                <div class="el-form-item__error" v-if="errorRules['bankDetailAddr']">
                  {{ errorRules["bankDetailAddr"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="联系人：" prop="contact" ref="contact">
                <el-input v-model="form.contact" maxlength="30" placeholder="请输入联系人姓名" @focus="checkForm('contact')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['contact']">
                  {{ errorRules["contact"] }}
                </div>
              </el-form-item>
              <el-form-item label="联系方式：" prop="contactMobile" ref="contactMobile">
                <el-input v-model="form.contactMobile" placeholder="请输入联系方式" @focus="checkForm('contactMobile')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['contactMobile']">
                  {{ errorRules["contactMobile"] }}
                </div>
              </el-form-item>
            </div>
          </div>
        </div>

        <!-- 承兑汇票银行账户信息 -->
        <!--<div class="info-panel" v-if="role === 'S'">-->
        <div class="info-panel" v-if="false">
          <p class="info-panel-title">承兑汇票银行账户信息</p>
          <div class="info-panel-content">
            <div class="form-inline-item">
              <el-form-item label="承兑汇票开户行行名：" prop="bankNameBA" ref="bankNameBA" :rules='[{ required: !isagentType, message: " 必填", trigger: "blur" }, { max: 30, message: "开户行行名不得大于30个字" , trigger: "blur" }]'>
                <el-input v-model=" form.bankNameBA" placeholder="请输入承兑汇票开户行行名" @focus="checkForm('bankNameBA')">
                </el-input>
                <div class="el-form-item__error" v-if="errorRules['bankNameBA']">
                  {{ errorRules["bankNameBA"] }}
                </div>
              </el-form-item>
              <el-form-item label="承兑汇票开户行联行号：" prop="bankCodeBA" ref="bankCodeBA" :rules='[{ required:  !isagentType, message: " 必填", trigger: "blur" }, { pattern: /^[0-9]{12}$/, message: "请输入正确的承兑汇票开户行联行号", trigger: "blur" }]'>
                <el-input v-model="form.bankCodeBA" placeholder="请输入12位的数字联行号" @focus="checkForm('bankCodeBA')" maxlength="12"></el-input>
                <div class="el-form-item__error" v-if="errorRules['bankCodeBA']">
                  {{ errorRules["bankCodeBA"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="承兑汇票开户人名称：" prop="bankAcctNameBA" ref="bankAcctNameBA" :rules='[{ required:  !isagentType, message: " 必填", trigger: "blur" }, { max: 30, message: "承兑汇票开户人名称不得大于30个字" , trigger: "blur" }]'>
                <el-input v-model="form.bankAcctNameBA" placeholder="请输入承兑汇票开户人名称" @focus="checkForm('bankAcctNameBA')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['bankAcctNameBA']">
                  {{ errorRules["bankAcctNameBA"] }}
                </div>
              </el-form-item>
              <el-form-item label="承兑汇票银行账号：" prop="bankAcctBA" ref="bankAcctBA" :rules='[{ required:  !isagentType, message: " 必填", trigger: "blur" }, { pattern: /^[0-9]{0,30}$/, message: "请输入正确的承兑汇票银行卡号", trigger: "blur" }]'>
                <el-input v-model="form.bankAcctBA" maxlength="30" placeholder="请输入承兑汇票银行账号" @focus="checkForm('bankAcctBA')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['bankAcctBA']">{{errorRules['bankAcctBA']}}</div>
              </el-form-item>
            </div>
            <div class="form-inline-item-dispickter" :class="{'un-require': isagentType}">
              <el-form-item label="承兑汇票开户行地址：" prop="provCode" ref="provCode">
                <Distpicker v-if="areaList.length" :areaList="areaList" :address="form.addInfoBA" @receive="getAddressCodeBA"></Distpicker>
                <div class="el-form-item__error" v-if="!baseRegSelectedFlgBA">
                  必填
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item address-input">
              <el-form-item label=" " prop="bankDetailAddrBA" ref="bankDetailAddrBA" :rules='[{ required:  !isagentType, message: " 必填", trigger: "blur" }]'>
                <el-input v-model="form.bankDetailAddrBA" placeholder="请输入开户行详细地址" maxlength="200" @focus="checkForm('bankDetailAddrBA')"> &gt;</el-input>
                <div class="el-form-item__error" v-if="errorRules['bankDetailAddrBA']">
                  {{ errorRules["bankDetailAddrBA"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="联系人：" prop="contactBA" ref="contactBA" :rules='[{ required:  !isagentType, message: " 必填", trigger: "blur" }]'>
                <el-input maxlength="30" v-model="form.contactBA" placeholder="请输入联系人姓名" @focus="checkForm('contactBA')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['contactBA']">
                  {{ errorRules["contactBA"] }}
                </div>
              </el-form-item>
              <el-form-item label="联系方式：" prop="contactMobileBA" ref="contactMobileBA" :rules='[{ required:  !isagentType, message: " 必填", trigger: "blur" },  { pattern: /^[\d-\s\(\)\+\,]*$/, message: "联系电话格式错误，请填写手机号或座机", trigger: "blur" }]'>
                <el-input v-model="form.contactMobileBA" placeholder="请输入联系方式" @focus="checkForm('contactMobileBA')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['contactMobileBA']">
                  {{ errorRules["contactMobileBA"] }}
                </div>
              </el-form-item>
            </div>
          </div>
        </div>
        <!-- 开票信息 -->
        <div class="info-panel invoiceType">
          <millingInformationCompontent :width="'1190px'" :taxClassifyList.sync="form.taxClassifyList" :invoiceType.sync="form.invoiceType" @outInvoiceList="outInvoiceList"></millingInformationCompontent>
        </div>
        <!-- 公司地址 -->
        <div class="info-panel">
          <p class="info-panel-title">公司地址</p>
          <div class="info-panel-content">
            <div class="form-inline-item-dispickter">
              <el-form-item label="工商登记地址：">
                <Distpicker v-if="areaList.length" :areaList="areaList" :address="form.addRegInfo" @receive="getRegAddressCode"></Distpicker>
                <div class="el-form-item__error" v-if="!regSelectedFlg">
                  必填
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item address-input">
              <el-form-item label=" " prop="regDetailAddr" ref="regDetailAddr">
                <el-input v-model="form.regDetailAddr" placeholder="请输入工商登记详细地址" @focus="checkForm('regDetailAddr')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['regDetailAddr']">
                  {{ errorRules["regDetailAddr"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item-dispickter">
              <el-form-item label="办公地址：">
                <Distpicker v-if="areaList.length" :areaList="areaList" :address="form.addOfficeInfo" @receive="getOfficeAddressCode"></Distpicker>
                <div class="el-form-item__error" v-if="!officeSelectedFlg">
                  必填
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item address-input">
              <el-form-item label=" " prop="officeDetailAddr" ref="officeDetailAddr">
                <el-input v-model="form.officeDetailAddr" placeholder="请输入办公地详细地址" @focus="checkForm('officeDetailAddr')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['officeDetailAddr']">
                  {{ errorRules["officeDetailAddr"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="邮编：" prop="officeZipCode" ref="officeZipCode">
                <el-input maxlength="6" v-model="form.officeZipCode" placeholder="请输入6位邮编" @focus="checkForm('officeZipCode')" @blur="blurCheckForm('officeZipCode')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['officeZipCode']">
                  {{ errorRules["officeZipCode"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="电话号码：" prop="officeTelNumber" ref="officeTelNumber">
                <el-input v-model="form.officeTelNumber" placeholder="例如：021-62629876" @focus="checkForm('officeTelNumber')" @blur="blurCheckForm('officeTelNumber')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['officeTelNumber']">
                  {{ errorRules["officeTelNumber"] }}
                </div>
              </el-form-item>
              <el-form-item label="传真号码：" prop="officeFaxNumber" ref="officeFaxNumber">
                <el-input v-model="form.officeFaxNumber" placeholder="例如：021-62629877" @focus="checkForm('officeFaxNumber')" @blur="blurCheckForm('officeFaxNumber')" maxlength="64"></el-input>
                <div class="el-form-item__error" v-if="errorRules['officeFaxNumber']">
                  {{ errorRules["officeFaxNumber"] }}
                </div>
              </el-form-item>
            </div>
          </div>
        </div>
        <div class="continue">
          <el-button class="large-btn" type="primary" @click="fromSubmit('rules')">提交并继续</el-button>
          <el-button class="large-btn" v-if="!isagentType" @click="goPreviousStep">上一步</el-button>
        </div>
      </el-form>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import millingInformationCompontent from "@/components/order/millingInformationCompontent";
import Loading from "@/components/base/Loading";
import Distpicker from "@/components/base/Distpicker";
import { InterfaceService } from '@/services/api'
import accountMixin from "@/mixins/account";
import { mapActions, mapState } from 'vuex'

export default {
  mixins: [accountMixin],
  components: {
    Header,
    SearchBar,
    Loading,
    Distpicker,
    millingInformationCompontent
  },
  data() {
    const emailReg = this.$commonExpression('email')
    const mobileReg = this.$commonExpression('mobile')
    const cerNoReg = this.$commonExpression('certNo')
    const bs = this.$store.state.userInfo && this.$store.state.userInfo.bs
    const validateMobile = (rule, value, callback) => {
      const reg = new RegExp(/^[1][0-9][0-9]{9}$|^s?$/);                    // 手机
      const reg1 = new RegExp(/^[\d-\s\(\)\+\,]*$/); // 座机
      if (!reg.test(value) && !reg1.test(value)) {
        return callback(new Error('联系电话格式错误，请填写手机号或座机'));
      } else {
        callback();
      }
    };
    const validatePhone = (rule, value, callback) => {
      const reg = new RegExp(/^[1][0-9][0-9]{9}$/);                    // 手机
      const reg1 = new RegExp(/^((0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$/); // 座机
      if (!reg.test(value) && !reg1.test(value)) {
        return callback(new Error('电话号码格式错误，请填写11位的手机号'));
      } else {
        callback();
      }
    };
    return {
      isReject: false,
      isPurchase: false, // 是否为采购 true:采购 false:非采购
      registerAdvancedInfo: {},
      isLoading: false,
      regSelectedFlg: true,
      baseRegSelectedFlg: true,
      baseRegSelectedFlgBA: true,
      officeSelectedFlg: true,
      corpId: '',
      imgError: '',
      imgList: [
        { 'previewSrcr': '', 'file': '', 'dialogVisible': false }
      ],
      bankList: [],
      form: {
        invoiceType: [],
        taxPayerName: "",
        addRegInfo: {},
        addInfo: {},
        addInfoBA: {},
        regProvCode: "",
        regCityCode: "",
        regDistrictCode: "",
        regDetailAddr: "",
        addOfficeInfo: {},
        officeProvCode: "",
        officeCityCode: "",
        officeDistrictCode: "",
        officeDetailAddr: "",
        officeZipCode: "",
        officeTelNumber: "",
        officeFaxNumber: "",
        baseBankNumber: "",

        // 基本户
        bankName: '', //	String	基本户开户行行名
        bankCode: '', //	String	基本户开户行联行号
        bankAcct: '', //	String	基本户银行账号
        bankAcctName: '', //	String	基本户开户人名称
        bankProvCode: '', //	String	基本户开户行地址，省
        bankCityCode: '', //	String	基本户开户行地址，市
        bankDistrictCode: '', //	String	基本户开户行地址，区
        bankDetailAddr: '', // 基本户开户行详细地址
        contact: '', //	String	联系人
        contactMobile: '', //	String	联系方式

        // 承兑
        bankNameBA: '', //	String	承兑汇票开户银行，供应商必须
        bankCodeBA: '', //	String	承兑汇票开户行联行号，供应商必须
        bankAcctBA: '', //	String	承兑汇票银行账号，供应商必须
        bankAcctNameBA: '', //	String	承兑汇票开户人名称，供应商必须
        bankProvCodeBA: '', //	String	开户行地址，省，供应商必须
        bankCityCodeBA: '', //	String	开户行地址，市，供应商必须
        bankDistrictCodeBA: '', //	String	开户行地址，区，供应商必须
        bankDetailAddrBA: '', // 开户行详细地址
        contactBA: '', //	String	联系人，供应商必须
        contactMobileBA: '', //	String	联系方式，供应商必须
        taxClassifyList: [],

      },
      rules: {
        bankName: [
          { required: true, message: "必填", trigger: "blur" },
          { max: 30, message: "开户行行名不得大于30个字", trigger: "blur" }
        ],
        bankCode: [
          { pattern: /^[0-9]{12}$/, message: '请输入正确的基本户开户行联行号', trigger: "blur" },
          { required: true, message: "必填", trigger: "blur" }
        ],
        bankAcct: [
          { required: true, message: "必填", trigger: "blur" },
          { pattern: /^[0-9]{0,30}$/, message: '请输入正确的银行卡号', trigger: "blur" },
        ],
        bankAcctName: [
          { max: 30, message: "开户人名称不得大于30个字", trigger: "blur" },
          { required: true, message: "必填", trigger: "blur" }
        ],
        bankDetailAddr: [{ required: true, message: "必填", trigger: "blur" }],
        contact: [{ required: true, message: "必填", trigger: "blur" }],
        contactMobile: [{ required: true, message: "必填", trigger: "blur" },
        { validator: validateMobile, trigger: "blur" },],

        baseBankNumber: [
          { required: true, message: "必填", trigger: "blur" },
          { max: 200, message: "开户行不得大于200个字", trigger: "blur" }
        ],
        taxPayerName: [
          { required: true, message: "必填", trigger: "blur" },
          { max: 200, message: "纳税人名称不得大于200个字", trigger: "blur" }
        ],
        invoiceType: [
          { type: 'array', required: true, message: '请至少选择一个票种', trigger: 'change' }
        ],
        regDetailAddr: [
          { required: true, message: "必填", trigger: "blur" },
          { max: 200, message: "地址不得大于200个字", trigger: "blur" }
        ],
        officeDetailAddr: [
          { required: true, message: "必填", trigger: "blur" },
          { max: 200, message: "地址不得大于200个字", trigger: "blur" }
        ],
        officeZipCode: [
          {
            required: true,
            message: "必填",
            trigger: "blur"
          },
          { pattern: /^\d{6}$/, message: '请输入正确的邮编', trigger: "blur" }
        ],
        officeTelNumber: [
          {
            required: true,
            message: "必填",
            trigger: "blur"
          },
          { validator: validateMobile, trigger: "blur" },
        ],
        officeFaxNumber: [
          { pattern: /^[0-9\-]{0,32}$/, message: '请输入正确的传真号码', trigger: "blur" },
        ]
      },
      errorRules: {},
      areaList: [],
      canClick: true,
      isagentType: false,
      timer: ''
    };
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo || {}
    },
    agentUserInfo() {
      return JSON.parse(this.$getRootScope('agentUserInfo') || '{}') || {}
    },
  },
  methods: {
    ...mapActions(['setNationalRegionListAction', 'setUserInfoAction']),
    getDistrictsList() {
      let params = { //给予后端的入参
        level: "1,2,3",
      };
      InterfaceService.getDistrictsList(params, data => {
        if (data.respData.respCode === '0000') {
          this.areaList = data.respData.areaList || [];
          this.setNationalRegionListAction(this.areaList)
        }
      }, data => {
      }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },
    init() {
      this.isagentType = this.$route.query.isAgent || "";
      // 代理过来的 不用 固定在此页面
      if (!this.isagentType) {
        this.$setRootScope("registerPath", JSON.stringify({ path: this.$route.path, query: this.$route.query }));
      } else {
        this.$removeRootScope('registerPath')
      }

      if (this.$store.state.nationalRegionList && this.$store.state.nationalRegionList.length > 0) {
        this.areaList = this.$store.state.nationalRegionList;
      } else {
        this.getDistrictsList()
      }

      if (this.isagentType) {
        this.getVendorMessage()
        this.corpId = this.$route.query.corpId || this.agentUserInfo.corpId;
        this.form.bankAcctName = this.$route.query.corpName || this.agentUserInfo.corpName
        this.form.bankAcctNameBA = this.$route.query.corpName || this.agentUserInfo.corpName
        this.form.taxPayerName = this.$route.query.corpName || this.agentUserInfo.corpName
        this.isReject = !!this.$route.query.isReject
        this.isPurchase = this.$route.query.isPurchase || false
      } else {
        this.corpId = this.$route.query.corpId || this.userInfo.corpId;
        this.form.bankAcctName = this.$route.query.corpName || this.userInfo.corpName
        this.form.taxPayerName = this.$route.query.corpName || this.userInfo.corpName
        this.form.bankAcctNameBA = this.$route.query.corpName || this.userInfo.corpName
        this.isReject = !!this.$route.query.isReject && this.userInfo.regStep == '2';
        if (this.userInfo.regStep == '2') {
          this.isPurchase = this.$route.query.isPurchase || false;
          this.getVendorMessage()
        }
      }
    },
    resetFieldsBtn() {
      this.$refs.form.resetFields();
    },
    getVendorMessage() {
      const registerAdvancedInfo = JSON.parse(this.$getRootScope('registerAdvancedInfo')) || {};
      console.log(registerAdvancedInfo);
      this.form = Object.assign({}, this.form, registerAdvancedInfo)
      this.form.addRegInfo = {
        provCode: registerAdvancedInfo.regProvCode || "",
        cityCode: registerAdvancedInfo.regCityCode || "",
        blockCode: registerAdvancedInfo.regDistrictCode || ""
      };

      this.form.addInfo = {
        provCode: registerAdvancedInfo.bankProvCode || "",
        cityCode: registerAdvancedInfo.bankCityCode || "",
        blockCode: registerAdvancedInfo.bankDistrictCode || ""
      };
      this.form.addInfoBA = {
        provCode: registerAdvancedInfo.bankProvCodeBA || "",
        cityCode: registerAdvancedInfo.bankCityCodeBA || "",
        blockCode: registerAdvancedInfo.bankDistrictCodeBA || ""
      };
      this.form.addOfficeInfo = {
        provCode: registerAdvancedInfo.officeProvCode || "",
        cityCode: registerAdvancedInfo.officeCityCode || "",
        blockCode: registerAdvancedInfo.officeDistrictCode || ""
      };

      console.log(this.$clone(this.form), '-form');

    },

    /**
     * 发票信息返回
     */
    outInvoiceList(e) {
      console.log(e, '--eefa');
      // this.ftaxClassifyList = e
    },

    getRegAddressCode(res) {
      this.form.regProvCode = res.provinceCode
      this.form.regCityCode = res.cityCode
      this.form.regDistrictCode = res.blockCode
      if (this.form.regDistrictCode) {
        this.regSelectedFlg = true
      }
    },
    getAddressCode(res) {
      this.form.bankProvCode = res.provinceCode
      this.form.bankCityCode = res.cityCode
      this.form.bankDistrictCode = res.blockCode
      console.log(this.form);

      if (this.form.bankDistrictCode) {
        this.baseRegSelectedFlg = true
      }
    },
    getAddressCodeBA(res) {
      this.form.bankProvCodeBA = res.provinceCode
      this.form.bankCityCodeBA = res.cityCode
      this.form.bankDistrictCodeBA = res.blockCode
      if (this.form.bankDistrictCodeBA) {
        this.baseRegSelectedFlgBA = true
      }
    },
    getOfficeAddressCode(res) {
      this.form.officeProvCode = res.provinceCode
      this.form.officeCityCode = res.cityCode
      this.form.officeDistrictCode = res.blockCode
      if (this.form.officeDistrictCode) {
        this.officeSelectedFlg = true
      }
    },
    checkForm(key) {
      if (this.form[key]) {
        delete this.errorRules[key]
      }
    },
    blurCheckForm(key) {
      let errorRules = JSON.parse(JSON.stringify(this.errorRules))
      // if(key == 'name' && this.form[key]) {
      //     if(this.form[key] == this.form['nameUrgent']){
      //         this.errorRules[key] = "联系人姓名被占用"
      //     }else{
      //         errorRules['name'] && delete errorRules['name']
      //         errorRules['nameUrgent'] && delete errorRules['nameUrgent']
      //     }
      // }

      // if(key == 'nameUrgent' && this.form[key]){
      //     if(this.form[key] == this.form['name']){
      //         errorRules[key] = "紧急联系人姓名被占用"
      //     }else{
      //         errorRules['name'] && delete errorRules['name']
      //         errorRules['nameUrgent'] && delete errorRules['nameUrgent']
      //     }
      // }

      if (key == 'certNo' && this.form[key]) {
        this.form[key] = this.form[key].toUpperCase();
        if (this.form[key] == this.form['certNoUrgent']) {
          errorRules[key] = "联系人身份证号码被占用"
        } else {
          errorRules['certNo'] && delete errorRules['certNo']
          errorRules['certNoUrgent'] && delete errorRules['certNoUrgent']
        }
      }

      if (key == 'certNoUrgent' && this.form[key]) {
        this.form[key] = this.form[key].toUpperCase();
        if (this.form[key] == this.form['certNo']) {
          errorRules[key] = "紧急联系人身份证号码被占用"
        } else {
          errorRules['certNo'] && delete errorRules['certNo']
          errorRules['certNoUrgent'] && delete errorRules['certNoUrgent']
        }
      }

      if (key == 'mobile' && this.form[key]) {
        if (this.form[key] == this.form['mobileUrgent']) {
          errorRules[key] = "联系人手机号码被占用"
        } else {
          errorRules['mobile'] && delete errorRules['mobile']
          errorRules['mobileUrgent'] && delete errorRules['mobileUrgent']
        }
      }

      if (key == 'mobileUrgent' && this.form[key]) {
        if (this.form[key] == this.form['mobile']) {
          errorRules[key] = "紧急联系人手机号码被占用"
        } else {
          errorRules['mobile'] && delete errorRules['mobile']
          errorRules['mobileUrgent'] && delete errorRules['mobileUrgent']
        }
      }

      if (key == 'email' && this.form[key]) {
        if (this.form[key] == this.form['emailUrgent']) {
          errorRules[key] = "联系人邮箱被占用"
        } else {
          errorRules['email'] && delete errorRules['email']
          errorRules['emailUrgent'] && delete errorRules['emailUrgent']
        }
      }
      if (key == 'emailUrgent' && this.form[key]) {
        if (this.form[key] == this.form['email']) {
          errorRules[key] = "紧急联系人邮箱被占用"
        } else {
          errorRules['email'] && delete errorRules['email']
          errorRules['emailUrgent'] && delete errorRules['emailUrgent']
        }
      }

      this.errorRules = errorRules
    },
    goPreviousStep() {
      this.$router.push({
        path: this.role === 'B' ? "/PregisterPerfectInfo" : "/VregisterPerfectInfo",
        query: {
          corpId: this.corpId
        }
      });
    },
    fromSubmit() {
      this.submit(this.rules)
    },
    delParams(params) {
      if (params.invoiceType && Object.prototype.toString.call(params.invoiceType) === "[object String]") {
        try {
          params.invoiceType = params.invoiceType && params.invoiceType.split('/') || []
        } catch (error) {
          // console.error('catch: ', error);
        }
      }
      if (this.role === 'B') {
        delete params.addInfoBA
        delete params.bankAcctBA
        delete params.contactBA
        delete params.bankNameBA
        delete params.bankAcctNameBA
        delete params.bankCityCodeBA
        delete params.bankCodeBA
        delete params.bankDetailAddrBA
        delete params.bankDistrictCodeBA
        delete params.bankProvCodeBA
        delete params.contactMobileBA
        delete params.taxClassifyList
      }
    },
    rejectSubmit() {
      let params = {
        corpId: this.$route.query.corpId || '',
        // 是否提交审批（当入会申请被驳回后修改公司信息时，传"1":提交审批，否则不传值）
        approveApplyFlg: '1'
      };
      params.taxClassifyList = this.$clone(this.form.taxClassifyList)
      params.invoiceType = this.$clone(this.form.invoiceType)
      params = Object.assign(params, this.form);
      params.corpId = this.corpId || '';
      params.approveApplyFlg = '1';
      params.contractCorpType = this.userInfo.contractCorpType || null;
      this.delParams(params)
      console.log(params, '驳回====params');
      InterfaceService[`${this.isPurchase ? 'rejectUpdateSupplier' : 'rejectUpdatePurchaser'}`](
        params,
        data => {
          this.result = data.respData;
          if (this.result.respCode == '0000') {
            try {
              window.opener && window.opener.location.reload();
            } catch (error) { }
            let userInfo = JSON.parse(this.$getRootScope('user'))
            userInfo.regStep = '2'
            this.$setRootScope('user', JSON.stringify(userInfo))
            this.setUserInfoAction(userInfo)
            this.$router.push({
              path: "/registerSuccess",
              isAgent: this.isagentType
            });
          } else {
            this.$message.error(this.result.respMsg)
          }
        },
        data => {
          this.$message.error(data.respMsg || '')

        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      )
    },

    /**
     * 验证发票信息
     */
    verificationInvoiceInformation() {
      let state = true

      if (!this.form.invoiceType.length) {
        this.$message.error('请选择发票类型')
        state = false
      }
      if (!this.form.taxClassifyList.length) {
        state = false
      }
      this.form.taxClassifyList.forEach(f => {
        if (!state || this.role === 'B') return
        if (f.classify === '') {
          this.$message.error('请填写货物或应税劳务分类')
          state = false
          return
        }
        if (f.tax === '') {
          this.$message.error('请填写税率')
          state = false
        }
      })
      return state
    },
    submit(rules) {
      if (this.canClick) {
        this.canClick = false
        clearTimeout(this.timer);
        this.timer = setTimeout(() => {
          this.canClick = true
        }, 2000)
        for (var i in this.errorRules) {
          if (this.errorRules[i]) {
            this.canClick = true
            return false
          }
        }
        // if (!this.form.bankDistrictCode) {
        //   this.baseRegSelectedFlg = false;
        //   document.documentElement.scrollTop = 0
        //   return false
        // }
        //
        // // 代理商 不验证承兑汇票开户行地址
        // if (!this.isagentType && !this.form.bankDistrictCodeBA && this.role == 'S') {
        //   this.baseRegSelectedFlgBA = false;
        //   document.documentElement.scrollTop = 600
        //   return false
        // }
        // if (!this.form.regDistrictCode) {
        //   document.documentElement.scrollTop = 1200
        //   this.regSelectedFlg = false;
        //   return false
        // }
        // if (!this.form.officeDistrictCode) {
        //   document.documentElement.scrollTop = 1200
        //   this.officeSelectedFlg = false;
        //   return false
        // }
        this.$refs.form.validate((valid, object) => {
          if (valid) {
            if (!this.verificationInvoiceInformation()) return
            let params = Object.assign({}, this.form);

            params.taxClassifyList = this.$clone(this.form.taxClassifyList)
            params.invoiceType = this.$clone(this.form.invoiceType)
            params.corpId = this.corpId
            // 如果是驳回
            console.log(this.isReject, '-isReject');

            if (this.isReject) {
              this.rejectSubmit()
              return
            }

            params.contractCorpType = this.userInfo.contractCorpType || null;
            this.delParams(params)
            console.log(params, '====params');

            //提交信息
            InterfaceService.registerAdvanced(
              params,
              data => {
                this.result = data.respData;
                //this.form.nameUrgent = ''
                if (this.result.respCode == '0000') {
                  try {
                    window.opener && window.opener.location.reload();
                  } catch (error) { }
                  let userInfo = JSON.parse(this.$getRootScope('user'))
                  userInfo.regStep = '2'
                  this.$setRootScope('user', JSON.stringify(userInfo))
                  this.setUserInfoAction(userInfo)
                  this.$router.push({
                    path: "/registerSuccess",
                    query: {
                      contactName: this.agentUserInfo && this.agentUserInfo.corpName || '',
                      corpId: this.agentUserInfo && this.agentUserInfo.corpId || '',
                      isAgent: this.isagentType, // 是否代理商
                    }
                  });
                } else {
                  this.$message.error(this.result.respMsg)
                }
              },
              data => {
                this.$message.error(data.respMsg || '')
              },
              () => {
                this.isLoading = true;
              },
              () => {
                this.isLoading = false;
              }
            );

          } else {
            // 校验失败滚动到对应位置
            for (let i in object) {
              let dom = this.$refs[i];
              if (Object.prototype.toString.call(dom) !== '[object Object]') {
                dom = dom[0];
              }
              let top = dom.$el.getBoundingClientRect().top;
              let scrollTop = document.documentElement.scrollTop;
              let diff = top + scrollTop;

              document.documentElement.scrollTop = diff - 276;
              break;
            }
            this.canClick = true
            return false;
          }
        })
      }
    },
    goBack() {
      this.$router.go(-1);
    }
  },
  mounted() {
    this.init();
  },
  destroyed() {
    this.$removeRootScope('registerAdvancedInfo');
  }
};
</script>

<style lang="scss" scoped>
p {
  margin-bottom: 20px;
}
a.link {
  display: inline-block;
  vertical-align: middle;
  padding: 0 10px;
  color: #7ab7e8;
}

.inner-container {
  margin-bottom: 100px;
  font-size: 14px;
}

.form-inline-item {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;

  & > div {
    width: 40%;
    flex-shrink: 0;
  }

  &.col-3 > div {
    width: 32%;
  }

  /deep/ .el-select {
    width: 100%;
  }
}
.regist-perfect-info {
  /deep/ .el-form-item {
    margin-bottom: 28px;
  }
  /deep/ .el-form-item__label {
    font-size: 12px;
    white-space: pre;
  }

  /deep/ .el-date-editor.el-input {
    width: 100%;
  }
  /deep/ .linkage .el-select {
    width: 33%;
  }
}

.form-item {
  position: relative;
  line-height: 40px;

  .float-right {
    position: absolute;
    top: 0;
    right: 10px;
  }
}

.info-panel {
  margin-top: 30px;
}

.brand-other {
  margin-top: 20px;
  padding-left: 30px;
}

.info-panel-title {
  border-left: 3px solid #000;
  margin: 10px 0;
  padding: 0 10px;
  font-weight: bold;
  color: rgb(41, 41, 41);
  i {
    font-size: 12px;
    color: rgb(143, 143, 143);
  }
  a {
    font-size: 12px;
    text-decoration: underline;
    color: #7ab7e8;
  }
}

.info-panel-content {
  padding-bottom: 0;
  background: #fff;
  &.bottom {
    padding-bottom: 20px;
  }
}

.info-master-img {
  .img-item {
    position: relative;
    display: inline-block;
    width: 120px;
    height: 120px;
    vertical-align: middle;
    margin-right: 20px;
    border: 1px dashed #ccc;
    border-radius: 2px;
  }

  .img-item-add {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    font-size: 30px;
    text-align: center;
    color: #ccc;

    position: relative;
    overflow: hidden;

    i {
      cursor: pointer;
    }

    input[type="file"] {
      display: none;
    }
    img {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      pointer-events: none;
      height: auto;
    }
  }

  .img-item-cover {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0);

    .img-item-top,
    .img-item-bottom {
      display: none;
      position: absolute;
      width: 100%;
      padding: 10px;
      text-align: center;
      background: rgba(167, 166, 166, 0.2);
    }

    .img-item-top {
      top: 0;
    }

    .img-item-bottom {
      bottom: 0;
      padding: 0 10px;

      a {
        display: inline-block;
        width: 48%;
        padding: 10px 5px;
        vertical-align: middle;
        color: rgb(88, 167, 231);
      }
    }
  }

  .img-item:hover {
    .img-item-cover {
      background: rgba(255, 255, 255, 0.2);
    }

    .img-item-top,
    .img-item-bottom {
      display: block;
    }
  }

  img {
    width: 100%;
    height: 100%;
    border: none;
  }

  .img-item.has-img {
    border: none;

    .img-item-add {
      // display: none;
    }

    &:hover .img-item-add {
      display: flex;
    }
  }
}

.info-detail {
  position: relative;
  z-index: 0;
}

.info-detail-img {
  padding: 10px 30px;
  border: 1px solid #e0e0e0;
  border-top: none;
  line-height: 30px;
  background: #f5f5f5;

  button {
    float: right;
    margin: 0 5px;
  }
}

.model-table {
  thead td {
    text-align: center;
  }

  td {
    padding: 10px;
    padding-left: 0;
  }
}

.apply-dialog {
  line-height: 25px;

  a {
    text-decoration: underline;
    color: #7ab7e8;
  }
}

.fix-bottom {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  padding: 20px;
  text-align: center;
  background: rgba(79, 82, 90, 0.8);

  button {
    width: 150px;
  }
}

.form-upload-text {
  height: 40px;
  line-height: 40px;
  .form-upload-text-left {
    display: inline-block;
    width: 195px;
    padding-right: 12px;
    text-align: right;
  }
  .form-upload-text-right {
    display: inline-block;
    width: 100%;
    padding-left: 195px;
  }
}

.form-upload-content {
  margin-bottom: 22px;
  .info-master-img {
    padding-left: 0px;
  }
}
.continue {
  text-align: center;
  margin: 0 auto 0;
}
.address-input {
  .el-form-item {
    width: 100% !important;
    /deep/ .el-form-item__label:before {
      content: none !important;
    }
  }
}
.form-inline-item-dispickter {
  .el-form-item {
    /deep/ .el-form-item__label:before {
      content: "*";
      color: #f56c6c;
      margin-right: 4px;
    }
  }
  &.un-require {
    .el-form-item {
      /deep/ .el-form-item__label:before {
        content: "";
        color: transparent;
        margin-right: 4px;
      }
    }
  }
}
.milling-information-compontent {
  /deep/ .form-inline-item-dispickter {
    color: #888 !important;
  }
}
.invoiceType {
  /deep/ .milling-information-compontent .bold {
    &:first-child {
      padding: 0 10px;
      border-left: 3px solid #000;
    }
  }
}
</style>