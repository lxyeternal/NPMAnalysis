<template>
  <div class="reviewProductContainer">
    <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>
    <div class="panel-content">
      <el-form class="form" :model="form" size="small" label-width="75px">
        <el-row style="overflow: visible !important;">
          <el-col :span="24">
            <el-form-item label="招标品类：">
              <!-- <el-cascader :key="cascaderIndex" v-model="form.categoryIds" :options="categoryList" :props="{ checkStrictly: true,value:'categoryIds',label:'categoryName'}" clearable></el-cascader> -->
              <DropdownTree ref="dropdownTree" @categoryInfo="getCategoryInfo" :width="'926px'" :bodyWidth="'808px'"></DropdownTree>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="公司名：">
              <el-input placeholder="请输入公司名" v-model="form.corpName" clearable></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="公司性质：">
              <el-select clearable filterable v-model="form.corpType" placeholder="请选择公司性质">
                <el-option label="全部" value=""></el-option>
                <el-option v-for="(seal,index) in corpTypeList" :key="index" :label="seal.corpTypeName" :value="seal.corpType"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8" v-if="tab == 2">
            <el-form-item label="状态：">
              <el-select clearable filterable v-model="form.sealStatus" placeholder="请选择状态">
                <el-option label="全部" value=""></el-option>
                <el-option v-for="(seal,index) in sealStatusList" :key="index" :label="seal.sealStatusName" :value="seal.sealStatus"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="提交时间：">
              <el-date-picker :picker-options="pickerOptionsStart" type="date" placeholder="请选择日期" value-format="yyyy-MM-dd" v-model="form.fromDt" style="width: 250px;"></el-date-picker>
              ~
              <el-date-picker type="date" :picker-options="pickerOptionsEnd" placeholder="请选择日期" value-format="yyyy-MM-dd" v-model="form.toDt" style="width: 250px;"></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24" class="tc search-btn">
            <el-button type="primary" size="small" @click="handleSearch">搜索</el-button>
            <el-button size="small" @click="handleClear">清除</el-button>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="review-product-table">
      <!-- 列表 -->
      <table>
        <thead>
          <tr class="tl">
            <td width="120">公司名</td>
            <td width="150">品类</td>
            <td>公司性质</td>
            <td>印章类型</td>
            <td width="200">印章授权日期</td>
            <td width="170">提交时间</td>
            <td>状态</td>
            <td class="tr" width="150">操作</td>
          </tr>
        </thead>
        <template v-if="sealList.length">
          <tbody v-for="(seal,index) in sealList" :key="index" class="tl tbody-row">
            <tr>
              <td>
                {{seal.corpName}}
              </td>
              <td class="ellipsisOne" :title="seal.categoryFullNames">
                {{seal.categoryFullNames}}
              </td>
              <td>
                {{seal.corpTypeName}}
              </td>
              <td>
                {{seal.sealKindName}}
              </td>
              <td>
                {{seal.effectiveStartdate || ''}} ~ {{seal.effectiveEnddate || ''}}
              </td>
              <td>
                {{seal.creTm}}
              </td>
              <td>
                {{seal.sealStatusName}}
              </td>
              <td width="100" class="opreate tr">
                <div>
                  <span v-if="tab == 1" class="hand blue" @click="handleReviewDetail(seal, 0)">
                    {{seal.authorityFlg==1 ? '补交授权书' : '授权印章' }}审核
                  </span>
                  <span v-else class="hand blue" @click="handleReviewDetail(seal, 1)">
                    详情
                  </span>
                </div>
              </td>
            </tr>
            <!-- <tr v-if="seal.sealStatus === 'rejected' && seal.approveMsg">
              <td colspan="7" class="p0">
                <p class="reject_notice">
                  <span>申请失败原因：</span>
                  <span>{{seal.approveMsg}}</span>
                </p>
              </td>
            </tr> -->
          </tbody>
        </template>
      </table>
      <div class="product-empty" v-if="!sealList.length">
        <img src="@/assets/images/icon-no-product.png">
        <p>没有搜索到相关印章，请重新修改搜索条件搜索！</p>
      </div>
    </div>
    <div class="table-pagination" v-if="sealList.length">
      <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="form.totalCount" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
      </el-pagination>
    </div>
    <Loading :is-loading="isLoading"></Loading>

  </div>
</template>
<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import PanelTitle from "@/components/base/PanelTitle";
import PersonSeal from "@/components/account/PersonSeal";
import ApplicationRecordList from "@/components/electronicSeal/ApplicationRecordList";
import { viewFile } from '@/utils/orderUtil';
import DropdownTree from "@/components/order/dropdownTreeTender";


const changeSealParams = {
  esignId: '',
  acctType: "2",
  processFlg: '',
  sealType: '',
  mainText: '',
  hText: '',
  qText: '',
  sealData: '',
  sealParamFront: ''
};
const form = {
  categoryIds: [], // 品类
  corpName: "", // 名称
  corpType: "", // 性质
  sealStatus: "", // 状态
  fromDt: "", // 开始
  toDt: "", // 结束
  pageIndex: 1,
  pageSize: 10,
  totalCount: 0
}
export default {
  name: "corporateSeal",
  components: {
    PanelTitle,
    Loading,
    PersonSeal,
    ApplicationRecordList,
    DropdownTree,
  },
  data() {
    return {
      tabs: [
        { label: "待处理", index: 1, active: true },
        { label: "已处理", index: 2 },
      ],
      isLoading: false,
      tab: 1,
      form: Object.assign({}, form),
      sealList: [],
      sealKindList: [],
      sealStatusList: [],
      corpTypeList: [],
      pickerOptionsEnd: {
        disabledDate: time => {
          return time.getTime() < (new Date(this.form.fromDt).getTime() - 86400000)
        }
      },
      pickerOptionsStart: {
        disabledDate: time => {
          return this.form && this.form.toDt && time.getTime() >= new Date(this.form.toDt).getTime()
        }
      },

      cascaderIndex: 1,//解决组件删除数据查询获取数据报错
      categoryList: [],
    }
  },

  methods: {
    init() {
      if (this.specialRole) {
        this.sealList = [
          { label: "项目专用章", type: 2, sealData: "", sealKind: "project" },
          { label: "个人名章", type: 4, sealData: "", sealKind: "personal" },
        ];
      }
      // 判断是否需要跳转 到列表 - 来源 电子印章申请
      if (this.$getRootLocalStorage('applicationState')) {
        this.tab = this.$getRootLocalStorage('applicationState')
        this.$removeRootLocalStorage('applicationState')
        this.tabs.forEach(f => {
          f.active = false
          if (f.index === 2) {
            f.active = true
          }
        })
      }

      this.searchSealApplicationList()
      this.getCategoryList()
    },


    // 获取招标品类
    getCategoryInfo(info) {
      console.log(info, '-info');

      this.form.categoryIds = []
      info.forEach(f => {
        // 入参处理
        this.form.categoryIds.push(f.categoryId)
      })
    },

    // 分页跳转
    handleCurrentChange(page) {
      this.form.pageIndex = page;
      this.searchSealApplicationList();
      window.scrollTo(0, 0)
    },

    // 获取招标品类
    getCategoryList() {
      InterfaceService.getCategoryList(
        {
          categoryId: "1",
          queryType: "2",
        },
        data => {
          if (data.respData.respCode === "0000") {
            this.cascaderIndex++
            let res = data.respData.categoryInfos || []
            this.categoryList = res
            this.categoryList.forEach(i => {
              i.children.forEach(j => {
                j.children.forEach(k => {
                  if (k.children !== 'underfind') {
                    this.$delete(k, 'children')
                  }
                });
              });
            })
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },

    searchSealApplicationList() {
      let params = {}

      params = Object.assign(params, this.form);
      params.tab = this.tab - 1
      if (this.form.categoryId && this.form.categoryId.length) {
        params.categoryId = this.form.categoryId[this.form.categoryId.length - 1]
      }
      InterfaceService.searchSealApplicationList(
        params,
        data => {
          if (data.respCode === "0000") {
            if (data.respData.respCode == "0000") {
              this.sealList = data.respData.sealApproveList || [];
              this.sealKindList = data.respData.sealKindList || [];
              this.sealStatusList = data.respData.sealStatusList || [];
              this.corpTypeList = data.respData.corpTypeList || [];
              this.form.pageSize = data.respData.pageSize
              this.form.totalCount = data.respData.totalCount
            } else {
              this.$message.error(data.respData.respMsg);
            }
          } else {
            this.$message.error(data.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        }
      )
    },
    handleReviewDetail(item, state) {
      console.log(item, state);
      window.open(this.$router.resolve({
        path: '/sealReviewDetail',
        query: {
          applyId: item.applyNo,
          sealKind: item.sealKind,
          sealStatus: item.sealStatus,
          state,
        }
      }).href, '_blank')
    },
    handleChangeTab(tab) {
      this.tab = tab.index
      this.handleClear()
    },
    handleSearch() {
      this.form.pageIndex = 1
      this.searchSealApplicationList()
    },
    handleClear() {
      this.$refs.dropdownTree.clear()
      this.form = Object.assign({}, form)
      this.searchSealApplicationList()
    },
  },
  mounted() {
    this.init();
  }
}
</script>

<style lang="scss" scoped>
.reviewProductContainer {
  .panel-content {
    margin: 20px 0;
    padding: 20px 10px;
    background: #f5f5f5;
    .form-item {
      position: relative;
      display: inline-block;
      line-height: 32px;

      .float-right {
        position: absolute;
        top: 3px;
        right: 1px;
        bottom: 2px;
        padding: 0 5px;
        line-height: 27px;
        background: #ffffff;
        height: 27px;
      }
    }
  }
  /deep/ .el-date-editor.el-input {
    width: 118px !important;
    .el-input__inner {
      padding: 0 24px !important;
    }
  }
  .search-btn {
    .el-button {
      width: 100px !important;
    }
  }

  .review-product-table {
    margin-top: 20px;
    /deep/ .el-table__body-wrapper {
      font-size: 12px;
    }

    /deep/ .el-table th,
    .el-table td {
      padding: 14px 0;
    }
    table {
      table-layout: fixed;
      width: 100%;
      line-height: 23px;
      font-size: 12px;
      td {
        padding: 14px 20px;
        vertical-align: middle;
        word-break: break-all;
      }
      thead {
        font-size: 14px;
        text-align: center;
        white-space: nowrap;
        color: #909399;
        background: #f5f5f5;
      }
      .tbody-row {
        &:hover {
          background: #e8f3fd;
        }
      }
      tbody {
        text-align: center;
        tr {
          border-bottom: 1px solid #ebeef5;
        }
      }
      .opreate {
        span {
          display: block;
        }
      }
    }
  }
  .product-empty {
    padding: 150px;
    text-align: center;
    line-height: 50px;
    color: #909399;
  }
  .p0 {
    padding: 0 !important;
  }
  .reject_notice {
    text-align: left;
    background: #ffe9eb;
    padding: 4px 12px;
  }
}
/deep/ .el-cascader {
  width: 100%;
}
</style>