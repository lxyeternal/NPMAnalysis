<template>
  <div class="register-wrap">
    <Header></Header>
    <search-bar :search-type="5" :progress="'注册'" :is-white-bg="true"></search-bar>
    <div class="register-wrapper">
      <div class="register-wrapper-inner">
        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>姓 名：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <el-input placeholder="请输入用户名" v-model.trim="model.acctName" @blur="checkForm('acctName')" maxlength="30" v-popover:popoverAcct clearable>
              </el-input>
              <!--<el-input style="display: none"></el-input>-->
            </div>
            <div class="error-msg red" v-if="errorMsg.acctName">{{errorMsg.acctName}}</div>
          </div>
        </div>
        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>身份证：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <el-input placeholder="请输入您的身份证号码" v-model="model.certNo" @blur="checkForm('certNo')" v-popover:popoverAcct clearable>
              </el-input>
              <!--<el-input style="display: none"></el-input>-->
            </div>
            <div class="error-msg red" v-if="errorMsg.certNo">{{errorMsg.certNo}}</div>
          </div>
        </div>
        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>手机号：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <!-- <input type="text" v-model="model.mobile" @keyup="checkForm('mobile')" placeholder="请输入您的常用手机号"> -->
              <el-input placeholder="请输入您的常用手机号" v-model.trim="model.mobile" @blur="checkForm('mobile')" maxlength="11" onkeyup="if(this.value.length==1){this.value=this.value.replace(/[^1-9]/g,'')}else{this.value=this.value.replace(/\D/g,'')}" clearable>
              </el-input>
              <!--<el-input style="display: none"></el-input>-->
            </div>
            <div class="error-msg red" v-if="errorMsg.mobile">{{errorMsg.mobile}}</div>
          </div>
        </div>

        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>邮 箱：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <!-- <input type="text" v-model="model.email" @keyup="checkForm('email')" placeholder="请输入您的常用邮箱"> -->
              <el-input style="position: fixed;bottom: -9999px;z-index: -999;" placeholder="请输入您的常用邮箱" maxlength="64" clearable>
              </el-input>
              <el-autocomplete ref="autocomplete" :fetch-suggestions="querySearch" :trigger-on-focus="false" placeholder="请输入您的常用邮箱" v-model.trim="model.email" @select="checkForm('email')" @blur="checkForm('email')" clearable>
              </el-autocomplete>
              <!--<el-input style="display: none"></el-input>-->
            </div>
            <div class="error-msg red" v-if="errorMsg.email">{{errorMsg.email}}</div>
          </div>
        </div>

        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>输入密码：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <el-input type="password" style="position: fixed;bottom: -9999px;z-index: -999;" placeholder="请输入密码" maxlength="18" v-model="model.loginPwd" @keyup.native="checkForm('loginPwd')" v-popover:popoverPwd auto-complete="new-password" clearable>
              </el-input>
              <el-input type="password" placeholder="请输入密码" maxlength="18" v-model="model.loginPwd" @keyup.native="checkForm('loginPwd')" v-popover:popoverPwd auto-complete="new-password" clearable>
              </el-input>
              <!--<el-input  type="password" style="display: none"></el-input>-->
              <el-popover ref="popoverPwd" placement="right" title="" width="300" trigger="focus">
                <div class="guid-text guid-1"><i class="el-icon-circle-check" :class="{'green':model.loginPwd && instant && instant ==2}"></i>必须是6-18个字母和数字</div>
                <div class="guid-text guid-2"><i class="el-icon-circle-check" :class="{'green':model.loginPwd && instant && instant >=1}"></i>同时包含字母和数字</div>
                <!-- <div class="guid-text guid-3"><i :class="{'el-icon-circle-check':!model.loginPwd || !loginPwdError,'el-icon-circle-close green':model.loginPwd && loginPwdError,'el-icon-circle-check green':model.loginPwd && !loginPwdError}"></i>密码不能与用户名相同</div> -->
              </el-popover>

            </div>

            <div class="error-msg red" v-if="errorMsg.loginPwd">{{errorMsg.loginPwd}}</div>
          </div>
        </div>
        <div class="register-label clearfloat">
          <div class="fl register-title"></div>
          <div class="fl register-input-box">
            <PwdStrength :pwd="model.loginPwd" @received="getPwdStrength" @instant="getPwdInstant"></PwdStrength>
          </div>
        </div>

        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>确认密码：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <!-- <input type="text" v-model="model.reLoginPwd" @keyup="checkForm('reLoginPwd')" placeholder="请再次输入密码"> -->
              <el-input type="password" placeholder="请再次输入密码" maxlength="18" v-model="model.reLoginPwd" @blur="checkForm('reLoginPwd')" auto-complete="new-password" clearable>
              </el-input>
              <!--<el-input  type="password" style="display: none"></el-input>-->
            </div>
            <div class="error-msg red" v-if="errorMsg.reLoginPwd">{{errorMsg.reLoginPwd}}</div>
          </div>
        </div>

        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>企业类型：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <el-radio-group v-model="model.accountType" @change="changeAccountType">
                <p>
                  <el-radio label="1">材料采购</el-radio>
                  <el-radio label="2">材料供应</el-radio>
                  <el-radio label="construction">工程施工</el-radio>
                   <!-- <el-radio label="3">我是施工单位</el-radio> -->
                </p>
                <p>
                  <!--<el-radio label="4">我是监理单位</el-radio>-->
                </p>
                <!--<el-radio label="3">我是代理商</el-radio>-->
              </el-radio-group>
            </div>
            <div class="error-msg red" v-if="errorMsg.accountType">{{errorMsg.accountType}}</div>
          </div>
        </div>
        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>公司名称：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <!-- <input type="text" v-model="model.email" @keyup="checkForm('email')" placeholder="请输入您的常用邮箱"> -->
              <!--<el-input-->
              <!--placeholder="请输入公司名称"-->
              <!--v-model="model.corpName"-->
              <!--@blur="checkForm('corpName')"-->
              <!--maxlength="200"-->
              <!--clearable>-->
              <!--</el-input>-->
              <el-select filterable remote default-first-option @change="handleChange($event)" placeholder="请输入公司名称" v-model="model.corpName" clearable @focus="clearCorpList()" @blur="checkForm('corpName')" :remote-method="handleSearchCompany" @clear="handleClear">
                <el-option v-for="(item,index) in companyList" :value="item.supplierName" :key="index"></el-option>
              </el-select>
            </div>
            <div class="error-msg red" v-if="errorMsg.corpName">{{errorMsg.corpName}}</div>
          </div>
        </div>
        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>统一社会信用代码：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <!-- <input type="text" v-model="model.email" @keyup="checkForm('email')" placeholder="请输入您的常用邮箱"> -->
              <el-input placeholder="请输入统一社会信用代码" v-model.trim="model.busiLicense" @blur="checkForm('busiLicense')" maxlength="18" clearable>
              </el-input>
              <!--<el-input style="display: none"></el-input>-->
            </div>
            <div class="error-msg red" v-if="errorMsg.busiLicense">{{errorMsg.busiLicense}}</div>
          </div>
        </div>
        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>法人代表：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <el-input placeholder="请输入法人代表" v-model.trim="model.legalRepresent" @blur="checkForm('legalRepresent')" maxlength="200" v-popover:popoverAcct clearable>
              </el-input>
              <!--<el-input style="display: none"></el-input>-->
            </div>
            <div class="error-msg red" v-if="errorMsg.legalRepresent">{{errorMsg.legalRepresent}}</div>
          </div>
        </div>
        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>验证码：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <ValidateCode :is-show-validate="true" @received="getCode" :update="updateCode"></ValidateCode>
            </div>
            <div class="error-msg red" v-if="errorMsg.validateCode">{{errorMsg.validateCode}}</div>
          </div>
        </div>

        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>手机验证码：
          </div>
          <div class="fl register-input-outer register-phone-v">
            <div class="register-input-box">
              <PhoneCode :is-show-phone-code="true" :type="'1'" :phone="model.mobile" :imgCode="model.validateCode" :origTxCode="'register'" :disable="!model.validateCode || !model.mobile" :update="updateCode" @error="getError" @received="getPhoneCode">
              </PhoneCode>
            </div>
            <div class="error-msg red" v-if="errorMsg.identifyCode">{{errorMsg.identifyCode}}</div>
          </div>
        </div>

        <div class="register-agree register-label clearfloat">
          <div class="fl register-title"></div>
          <div class="fl register-input-box register-checx-container">
            <el-checkbox v-model="checked" style="color:#444;">创建网站账号的同时，我同意遵守</el-checkbox>
            <i class="blue hand" @click.stop @click="dialogAgreementVisible=true">《会员注册协议》</i>、
            <i class="blue hand" @click.stop @click="managementMeasuresDialog=true">《电商平台会员管理暂行办法》</i>
          </div>
        </div>
        <el-button type="primary" class="submit-btn large-btn" @click="submit" :class="{'disable':!checked}">
          同意并注册
        </el-button>
        <!--<div class="submit-btn large-btn hand" @click="submit" :class="{'disable':!checked}">-->
        <!--同意并注册-->
        <!--</div>-->

        <el-dialog title="请仔细阅读平台条款" :visible.sync="dialogAgreementVisible" class="dialog-agreement">
          <div class="agrement-body scroll-style">
            <Agreement></Agreement>
          </div>
          <el-button type="primary" class="submit-btn large-btn" @click="dialogAgreementVisible=false;">
            同意条款
          </el-button>
        </el-dialog>
        <el-dialog title="请仔细阅读平台条款" :visible.sync="managementMeasuresDialog" class="dialog-agreement">
          <div class="agrement-body scroll-style">
            <ManagementMeasures></ManagementMeasures>
          </div>
          <el-button type="primary" class="submit-btn large-btn" @click="managementMeasuresDialog=false;">
            同意条款
          </el-button>
        </el-dialog>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import {
  mapActions,
  mapState
} from 'vuex'
import { InterfaceService } from "@/services/api";
import SearchBar from '@/components/SearchBar'
import Header from '@/components/base/Header'
import ValidateCode from '@/components/base/ValidateCode'
import PhoneCode from '@/components/base/PhoneCode'
import PwdStrength from '@/components/base/PwdStrength'
import CryptoJS from 'crypto-js';
import Loading from "@/components/base/Loading";
import Agreement from "@/components/modal/Agreement";
import ManagementMeasures from "@/components/modal/ManagementMeasures";
export default {
  components: {
    SearchBar,
    Header,
    ValidateCode,
    PhoneCode,
    PwdStrength,
    Loading,
    Agreement,
    ManagementMeasures
  },
  data() {
    return {
      managementMeasuresDialog: false,
      model: {
        acctName: '',
        legalRepresent: '',
        certNo: '',
        mobile: '',
        email: '',
        corpName: '',
        busiLicense: '',
        loginPwd: '',
        reLoginPwd: '',
        identifyCode: '',
        accountType: '',
        validateCode: '',
      },
      loginPwdError: '',
      strength: '',
      instant: '',
      checked: false,
      fromSearchInfo: false,
      isLoading: false,
      errorMsg: {},
      companyList: [],
      shieldList: [],
      canClick: true,
      timer: '',
      popoverMsg: {
        acctName: true
      },
      updateCode: 0,
      dialogAgreementVisible: false,
      isConstruction: '0',
    }
  },
  watch: {
    // model: {
    //   handler: function ( newVal, oldVal ) {
    //       if(newVal.acctName){

    //         this.checkPopover('acctName')
    //       }
    //   },
    //   deep: true
    // },
  },
  methods: {
    ...mapActions(['setUserInfoAction']),
    querySearch(queryString, callback) {
      let commonMailbox = this.$commonMailbox()
      let results = this.$clone(commonMailbox)
      let value = ''
      if(queryString && queryString.indexOf('@') != -1){
        value = queryString.substring(0, queryString.indexOf('@'))
      }else{
        value = queryString
      }
      results.forEach((i,index) =>{
          i.value = value + '' + commonMailbox[index].value
      })
      callback(results)
      this.$refs.autocomplete.handleFocus()
    },
    handleChange(ev) {
      console.log(ev);
      if (ev) {
        let onOff = true
        this.companyList.forEach(item => {
          if (ev == item.supplierName) {
            this.model.legalRepresent = item.legalPersonName || "";
            this.model.busiLicense = item.trustCode || "";
            this.fromSearchInfo = true;
            onOff = false
          }
        });
        if (onOff) {
          this.handleClear()
        }
      }
    },
    handleSearchCompany(query) {
      if (query.length >= 2) {
        this.getSupplierMedicalChecklist(query)
      } else {
        this.companyList = []
      }
    },
    handleClear() {
      if (this.fromSearchInfo) {
        this.model.legalRepresent = "";
        this.model.busiLicense = "";
        this.fromSearchInfo = false
      }
    },
    getCode(validateCode) {
      //console.log(this.model.validateCode)
      this.model.validateCode = validateCode;
      if (validateCode) {
        delete this.errorMsg['validateCode']
      }


      this.$forceUpdate();
      this.$set(this.model, this.model);
      this.$set(this.errorMsg, this.errorMsg);
    },
    getPhoneCode(identifyCode) {
      this.model.identifyCode = identifyCode
      delete this.errorMsg['identifyCode']
      this.$forceUpdate();
      this.$set(this.model, this.model);
      this.$set(this.errorMsg, this.errorMsg);
    },
    getPwdStrength(strength) {
      this.strength = strength
    },
    getPwdInstant(instant) {
      this.instant = instant
    },
    changeAccountType(value) {
      this.model.accountType = value;//identifyCode
      delete this.errorMsg['accountType']
      this.$forceUpdate();
      this.$set(this.model, this.model);
      this.$set(this.errorMsg, this.errorMsg);
    },
    clearCorpList() {
      this.companyList = [];
    },
    checkForm(key) {
      let reg = ''
      if (!this.model[key]) {
        delete this.errorMsg[key]
        this.$forceUpdate();
        this.$set(this.model, this.model);
        this.$set(this.errorMsg, this.errorMsg);
        return
      }
      if (key == 'acctName') {
        // 移除 敏感字验证
        // this.model[key] = this.checkShieldWord(this.model[key])
        reg = this.$commonExpression('account'); // /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]{6,18}$/ ;
        if (!reg.test(this.model[key])) {
          this.errorMsg[key] = '姓名设置不符合要求'
        } else {
          delete this.errorMsg[key]
        }

      }
      if (key == "legalRepresent") {
        if (!this.model[key]) {
          this.errorMsg[key] = '法人代表设置不符合要求'
        } else {
          delete this.errorMsg[key]
        }
      }

      if (key == 'certNo') {
        reg = this.$commonExpression('certNo'); // /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]{6,18}$/ ;
        this.model[key] = this.model[key].toUpperCase();
        if (!reg.test(this.model[key])) {
          this.errorMsg[key] = '身份证号码不正确'
        } else {
          delete this.errorMsg[key]
        }

      }

      if (key == 'mobile') {
        // if(this.model[key].length >= 11){
        //   this.model[key] = this.model[key].substr(0,11)
        // }
        reg = this.$commonExpression('mobile');  // /^[1][0-9][0-9]{9}$/;
        if (!reg.test(this.model[key])) {
          this.errorMsg[key] = '手机号格式不正确 '
        } else {
          delete this.errorMsg[key]
        }
      }

      if (key == 'email') {

        reg = this.$commonExpression('email'); // /^([0-9A-Za-z\-_\.]+)@([0-9a-z]+\.[a-z]{2,3}(\.[a-z]{2})?)$/g;
        if (!reg.test(this.model[key])) {

          this.errorMsg[key] = '邮箱格式不正确 '
        } else {

          const mail = this.model[key] || '',
            mailSuffix = mail.slice(mail.lastIndexOf('.') + 1, mail.length),
            errorMailSuffix = JSON.parse(this.$getRootLocalStorage('errorMailSuffix') || '[]')

          if (errorMailSuffix.includes(mailSuffix)) {
            this.$set(this.errorMsg, key, '邮箱后缀不正确')
            return
          }

          delete this.errorMsg[key]
        }

      }
      if (key == 'corpName') {

        // if(!reg.test(this.model[key])){
        if (!this.model[key]) {

          this.errorMsg[key] = '公司名称格式不正确'
        } else {

          delete this.errorMsg[key]
        }

      }
      if (key == 'busiLicense') {

        reg = this.$commonExpression('busiLicense');
        if (!reg.test(this.model[key])) {

          this.errorMsg[key] = '统一社会信用代码格式不正确'
        } else {

          delete this.errorMsg[key]
        }

      }
      //密码验证
      if (key == 'loginPwd') {
        let reg = new RegExp(/[^\u4e00-\u9fa5\w]/g);
        // this.model[key]  = this.model[key].replace(/[^\u4e00-\u9fa5\w]/g,'')
        if (this.model[key].length >= 18) {
          this.model[key] = this.model[key].substr(0, 18)
        }
        this.loginPwdError = false
        if (!this.model[key]) {
          this.errorMsg[key] = '请输入密码'
        }
        if (this.model[key] && this.strength <= 1 || reg.test(this.model[key])) {
          this.errorMsg[key] = '密码设置不符合要求'
          // if(this.model[key] == this.model['acctName']){
          //   this.loginPwdError = true
          // }
          this.$forceUpdate();
          this.$set(this.model, this.model);
          this.$set(this.errorMsg, this.errorMsg);
          return false;
        } else {
          delete this.errorMsg[key]
        }

        if (this.model.reLoginPwd && this.model.loginPwd && this.model.reLoginPwd != this.model.loginPwd) {
          this.errorMsg['reLoginPwd'] = '两次输入的密码不一致，请重新输入'
        } else {
          delete this.errorMsg['reLoginPwd']
        }
      }
      //密码验证
      if (key == 'reLoginPwd') {
        if (this.model.loginPwd && this.model.reLoginPwd && this.model.reLoginPwd != this.model.loginPwd) {
          this.errorMsg[key] = '两次输入的密码不一致，请重新输入'
        } else {
          delete this.errorMsg[key]
        }
      }
      this.$forceUpdate();
      this.$set(this.model, this.model);
      this.$set(this.errorMsg, this.errorMsg);

    },
    checkPopover(key) {
      let reg = '';
      if (key == 'acctName' && this.model[key]) {
        reg = this.$commonExpression('account'); // /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]{6,18}$/ ;
        if (!reg.test(this.model[key])) {
          this.popoverMsg[key] = true
        } else {
          this.popoverMsg[key] = false
        }
        this.$forceUpdate();
        this.$set(this.popoverMsg, this.popoverMsg);
      }

    },
    submit() {
      if (this.checked) {

        for (let key in this.model) {

          if (!this.model[key]) {
            if (key == 'accountType') {
              this.errorMsg[key] = '请选择企业类型';
            } else {
              if (key != 'validateCode') {
                this.errorMsg[key] = '输入不能为空'
              }
            }
          }
        }
        this.$forceUpdate();
        this.$set(this.model, this.model);
        this.$set(this.errorMsg, this.errorMsg);
        if(this.model.accountType == 'construction'){
          this.isConstruction = '1'
          this.model.accountType == '2'
        }
        if (JSON.stringify(this.errorMsg) == "{}") {
          let loginPwd = CryptoJS.MD5(this.model.loginPwd).toString();
          let bs = this.model.accountType == '1' ? 'purchaser' : 'supplier';
          let contractCorpType = this.model.accountType == '3' ? "construction" : this.model.accountType == '4' ? "supervisory" : null;
          let param = {
            'acctName': this.model.acctName,
            'legalRepresent': this.model.legalRepresent,
            'contractCorpType': contractCorpType,
            'mobile': this.model.mobile,
            'email': this.model.email,
            'corpName': this.model.corpName,
            'busiLicense': this.model.busiLicense,
            'loginPwd': loginPwd,
            'bs': bs,
            'identifyCode': this.model.identifyCode,
            'validateCode': this.model.validateCode,
            'certNo': this.model.certNo,
            'isConstruction': this.isConstruction
          }
          InterfaceService.register(
            param,
            data => {
              let res = data.respData
              let errorKey = '';
              if (res.respCode == '0000') {
                //缓存账户名
                this.$setRootScope('registerName', this.model.acctName)

                //登录

                let userInfo = {
                  'acctId': res.acctId,
                  'mobileNo': res.mobile,
                  'acctName': this.model.acctName,
                  'legalRepresent': this.model.legalRepresent,
                  'isLogin': '1',
                  'corpId': res.corpId,
                  'contractCorpType': contractCorpType,
                  'corpName': this.model.corpName,
                  'busiLicense': this.model.busiLicense,
                  'bs': bs == 'purchaser' ? "B" : "S",
                  'email': this.model.email,
                  'regStep': '0'
                }
                this.$setRootScope('user', JSON.stringify(userInfo))
                this.setUserInfoAction(userInfo)
                //权限树
                if (res.menuList && res.menuList[0]) {
                  //获取menuList  menuAvailable!='1'则表示没有权限
                  let limitTxCodeArr = []
                  limitTxCodeArr = res.menuList[0].menuList || []
                  let treeToArray = this.treeToArray(limitTxCodeArr, [])
                  let limitTxCode = []
                  if (treeToArray && treeToArray.length > 0) {
                    for (var i = 0; i < treeToArray.length; i++) {
                      if (treeToArray[i].menuAvailable != '1') {

                        limitTxCode.push({ 'code': treeToArray[i].menuURL, 'type': treeToArray[i].menuType })
                      }
                    }
                    this.$setRootScope('limitTxCode', JSON.stringify(limitTxCode))
                  }

                }


                if (this.model.accountType == '1') {//采购
                  this.$router.push({
                    path: "/pregisterPerfectInfo"
                  });
                } else {
                  this.$router.push({
                    path: "/vregisterPerfectInfo",
                    query: {
                      role: this.model.accountType,
                      isConstruction: this.isConstruction
                    }
                  });
                }

              } else {

                if (res.respCode == 'MEM0064' || res.respCode == 'MEM0058' || res.respCode == 'MEM0062') {
                  errorKey = 'acctName'
                } else if (res.respCode == 'MEM0066' || res.respCode == 'MEM0025' || res.respCode == 'MEM0051') {
                  errorKey = 'mobile'
                } else if (res.respCode == 'MEM0065' || res.respCode == 'MEM0059' || res.respCode == 'MEM0063') {
                  errorKey = 'email'
                } else if (res.respCode == 'MEM0060' || res.respCode == 'MEM0061' || res.respCode == 'MEM0035') {
                  errorKey = 'loginPwd'
                } else if (res.respCode == 'F000002') {
                  errorKey = 'validateCode'
                } else if (res.respCode == 'F000003' || res.respCode == 'F000005') {
                  errorKey = 'identifyCode'
                  if (res.respCode == 'F000005') {
                    this.updateCode++
                  }
                } else if (res.respCode == 'MEM0196' || res.respCode == 'MEM0194' || res.respCode == 'MEM0190' || res.respCode == 'MEM0195') {//身份证
                  errorKey = 'certNo'
                } else if (res.respCode == 'MEM020030') {//统一社会信用代码
                  errorKey = 'busiLicense'
                }

                if (errorKey) {
                  this.errorMsg[errorKey] = res.respMsg
                } else {
                  this.$message.error(res.respMsg);
                }


                this.$forceUpdate();
                this.$set(this.errorMsg, this.errorMsg);

              }

            },
            data => { },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            }
          );
        } else {
          // this.$message({
          //   message: '注册信息不完善',
          //   type: 'error'
          // });

          this.dialogAgreementVisible = false
        }
      }
    },
    getError(msg) {


      this.model.validateCode = '';
      this.updateCode++;
      this.$set(this.errorMsg, 'validateCode', msg)
      this.$forceUpdate();

    },
    getSupplierMedicalChecklist(keyWord) {
      const params = { keyWord: keyWord }
      InterfaceService.getSupplierMedicalChecklist(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.companyList = data.respData.storageInfo || [];
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },
    treeToArray(tree, arr) {
      if (tree) {
        let res = arr
        for (let n = 0; n < tree.length; n++) {
          let treeItem = tree[n]
          res.push({
            menuAvailable: treeItem.menuAvailable,
            menuDisplaySort: treeItem.menuDisplaySort,
            menuID: treeItem.menuID,
            menuLevel: treeItem.menuLevel,

            menuName: treeItem.menuName,
            menuParentID: treeItem.menuParentID,
            menuStatus: treeItem.menuStatus,
            menuType: treeItem.menuType,
            menuURL: treeItem.menuURL
          })

          if (treeItem.menuList && treeItem.menuList.length > 0) {
            this.treeToArray(treeItem.menuList, res)
          }
        }

        return res
      } else {
        return []
      }
    },
    checkShieldWord(word) {
      var shieldListLen = this.shieldList.length;
      // flag true 默认没有敏感字
      var flag = true;
      if (/[\\|<|>]/.test(word)) {
        flag = false;
        return flag;
      } else {
        for (var i = 0; i < shieldListLen; i++) {
          // 设置flag有敏感字
          flag = false;
          var shieldItem = this.shieldList[i];
          var k = -1;
          for (var j = 0; j < shieldItem.length; j++) {
            var shieldItemStr = shieldItem[j];
            var index = word.indexOf(shieldItemStr, k + 1);
            if (index <= k) {
              flag = true; // 内容不满足敏感字规则
              break;
            } else {
              k = index;
            }
          }
          if (!flag) {
            break;
          }
        }
      }
      if (flag) {
        return word
      } else {
        return '';
      }
    },
    getShieldList() {
      InterfaceService.getshieldList(data => {
        if (typeof data === "string") {
          let info = eval("(" + data + ")") || {};
          this.shieldList = info.exportDefault.shieldList || []
        } else if (typeof data === "object") {
          this.shieldList = data.exportDefault.shieldList || []
        }
      })
    }
  },
  mounted() {
    this.$removeRootScope('registerName')
    this.$removeRootScope('limitTxCode')
    this.$removeRootScope('user')
    this.$removeRootLocalStorage('user')
    this.setUserInfoAction({});
    this.getShieldList()
  }
}
</script>

<style lang="scss" scoped>
.guid-text {
  font-size: 12px;
  color: #888;
  line-height: 20px;
  i {
    margin-right: 8px;
  }
}
/deep/ .el-radio__input.is-checked + .el-radio__label {
  color: #444;
}
/* 注册页面 */
.register-wrapper {
  border-top: 2px solid #c99f4f;
  padding-bottom: 100px;

  .register-wrapper-inner {
    width: 840px;
    margin: 0 auto;
    padding: 46px 85px 0;

    .register-label {
      margin-bottom: 15px;
      //overflow: hidden;

      .register-input-outer {
        width: 500px;
        min-height: 40px;

        // .error-msg{
        //   // height: 40px;
        //   line-height: 1.5;
        //   font-size: 12px;
        // }
      }

      .register-input-box {
        width: 500px;
        height: 40px;
        line-height: 40px;

        input {
          width: 100%;
          height: 40px;
          border: 1px solid #dddddd;
          text-indent: 20px;
          padding: 0;
        }
      }

      .register-title {
        width: 170px;
        height: 40px;
        line-height: 40px;
        text-align: right;
        padding-right: 15px;
        font-size: 12px;
        color: #888;

        i {
          color: #e93340;
          padding-right: 2px;
        }
      }
    }
    .submit-btn {
      display: block;
      margin: 40px auto 0;
    }
  }

  /deep/ .el-checkbox__input.is-checked + .el-checkbox__label {
    color: #444;
  }

  .dialog-agreement {
    /deep/ .el-dialog__body {
      position: relative;
      font-size: 12px;
      color: #444;
      line-height: 23px;

      padding-top: 24px;
      padding-left: 40px;

      .agrement-body {
        overflow-y: scroll;
        height: 500px;
      }
    }
  }
}
.disable {
  cursor: not-allowed !important;
}
.el-select {
  width: 100%;
}

.register-checx-container {
  width: 560px !important;
  margin-left: 117px;
}
.register-phone-v {
  /deep/ .verify-btn.active {
    color: #fff;
    height: 42px;
  }
}
</style>