<template>
  <div class="register-wrap">
    <Header></Header>
    <search-bar
      :search-type="5"
      :progress="'资料完善'"
      :is-white-bg="true"
    ></search-bar>
    <div class="register-wrapper">
      <div class="register-wrapper-inner">
        <div class="register-label clearfloat">
          <div class="fl register-title"><i>*</i>姓名：</div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <el-input
                :value="model.acctName | formatName"
                disabled
              ></el-input>
            </div>
          </div>
        </div>

        <div class="register-label clearfloat">
          <div class="fl register-title"><i>*</i>手机号：</div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <el-input
                :value="model.mobileNo | formatPhone"
                disabled
              ></el-input>
            </div>
          </div>
        </div>

        <div class="register-label clearfloat">
          <div class="fl register-title"><i>*</i>邮 箱：</div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <el-input :value="model.email | formatEmail" disabled></el-input>
            </div>
          </div>
        </div>

        <div class="register-label clearfloat">
          <div class="fl register-title"><i>*</i>企业类型：</div>

          <div class="fl register-input-outer ">
            <div class="register-input-box clearfloat">
              <el-radio-group
                v-model="accountType"
                @change="changeAccountType($event)"
              >
                <el-radio :label="1">我是采购方</el-radio>
                <el-radio :label="2">我是供应商（厂家）</el-radio>
                <!--<el-radio :label="3">我是经销商</el-radio>-->
              </el-radio-group>
            </div>
          </div>
        </div>
        <div
          class="submit-btn large-btn hand"
          @click="submit"
          :class="{ disable: !checked }"
        >
          提交并继续
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {
  mapActions,
  mapState
} from 'vuex'
import { InterfaceService } from "@/services/api";
import SearchBar from '@/components/SearchBar'
import Header from '@/components/base/Header'
import ValidateCode from '@/components/base/ValidateCode'
import PhoneCode from '@/components/base/PhoneCode'
import PwdStrength from '@/components/base/PwdStrength'
import axios from 'axios'
export default {
  components: {
    SearchBar,
    Header,
    ValidateCode,
    PhoneCode,
    PwdStrength
  },
  data() {
    return {

      model: {
        acctName: '111111',
        mobileNo: '',
        email: '',
      },
      accountType: 0,
      checked: false,
      isLoading: false,
      bsState: '',
      isReject: false // 是否来源于驳回
    }
  },
  methods: {
    ...mapActions(['setUserInfoAction']),
    init() {
      this.model = JSON.parse(this.$getRootScope('user'))
      // 如果是从审核失败过来需要填写企业类型
      if (this.$route.query.isAuditFalied) {
        this.isReject = true;
        // （"S"：供方；"B"：采购方；"":不确定）
        const BS = this.model.bs.toUpperCase();
        this.bsState = BS === 'B' ? 1 : BS === 'S' ? 2 : 3;
        this.changeAccountType(this.bsState)
      }
    },
    changeAccountType(value) {
      this.checked = true
      this.accountType = value;//identifyCode
    },
    submit() {
      if (!this.checked) {
        return
      }
      // 如果企业类型发生改变, 走普通流程
      if (this.bsState !== this.accountType) {
        if (this.accountType == 1) {//采购
          this.$router.push({
            path: "/pregisterPerfectInfo"
          });
        } else {
          this.$router.push({
            path: "/vregisterPerfectInfo",
            query: {
              role: this.accountType
            }
          });
        }
      } else {
        if (this.accountType == 1) {//采购
          this.$router.push({
            path: "/pregisterPerfectInfo",
            query: {
              corpId: this.model.corpId || ''
            }
          });
        } else {
          this.$router.push({
            path: "/vregisterPerfectInfo",
            query: {
              role: this.accountType,
              corpId: this.model.corpId || ''
            }
          });
        }
      }


    }
  },
  mounted() {
    this.init()
  }
}
</script>

<style lang="scss" scoped>
/deep/ .tip-content {
  padding: 7px 20px;
  line-height: 27px;
  width: 292px;
  background: #fff;
  border: 1px solid #eee;

  i {
    margin-right: 8px;
  }
}

/* 注册页面 */
.register-wrapper {
  border-top: 2px solid #ffd64e;
  padding-bottom: 100px;

  .register-wrapper-inner {
    width: 770px;
    margin: 0 auto;
    padding: 46px 85px 0;
    height: 580px;
    .register-label {
      margin-bottom: 15px;
      .register-input-outer {
        width: 500px;
        min-height: 40px;

        .error-msg {
          height: 40px;
          line-height: 40px;
          font-size: 12px;
        }
      }

      .register-input-box {
        width: 500px;
        height: 40px;
        line-height: 40px;

        input {
          width: 100%;
          height: 40px;
          border: 1px solid #dddddd;
          text-indent: 20px;
          padding: 0;
        }
      }

      .register-title {
        width: 96px;
        height: 40px;
        line-height: 40px;
        text-align: right;
        padding-right: 15px;
        font-size: 12px;
        color: #888;

        i {
          color: #e93340;
          padding-right: 2px;
        }
      }
    }
    .submit-btn {
      display: block;
      margin: 50px auto 0;
    }
  }

  /deep/ .el-checkbox__input.is-checked + .el-checkbox__label {
    color: #444;
  }
}
</style>