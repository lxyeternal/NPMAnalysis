<template>
  <div class="register-wrap">
    <Header></Header>
    <search-bar
      :search-type="5"
      :progress="type == 'admin' ? '提交授权委托书':'资料完善'"
      :is-white-bg="true"
    ></search-bar>
    <div class="auditFailedContainer">
      <i></i>
      <h1>审核未通过</h1>
      <p>
        您提交的{{type == "admin"? '授权委托书':'企业信息审核'}}未通过, 您可以参照驳回意见,
        重新提交{{type == "admin"? '授权委托书':'企业信息'}}。也可以联系客服 {{$platformContact()['hotLine']}} {{$platformContact()['hotLineTime']}}
        了解详情。驳回意见:
        <span>{{ $route.query.approveMsg || "暂无" }}</span>
      </p>
      <el-button class="large-btn" size="" type="primary" @click="handleResubmission">
        重新提交信息
      </el-button>
    </div>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Header from '@/components/base/Header'
import SearchBar from '@/components/SearchBar'
export default {
  components: {
    Header,
    SearchBar
  },
  data() {
    return {
      user: {}, // 用户信息
      type: "", // 拒绝类型
      accountType: 1 // 企业类型
    }
  },
  mounted() {
    this.init();
    this.$setRootScope("registerPath",JSON.stringify({path:this.$route.path,query:this.$route.query}));
  },
  methods: {
    init() {
      this.type = this.$route.query.type || "";
      this.user = JSON.parse(this.$getRootScope('user'))
      const BS = this.user.bs.toUpperCase();
      this.accountType = BS === 'B' ? 1 : BS === 'S' ? 2 : 3;
    },
    handleResubmission() {
      // 跳过选择企业类型步骤
      // this.$router.push({ path: '/registerSupplement', query: { isAuditFalied: true } });
      if (!this.type) {
        if (this.accountType == 1) {//采购
          this.$router.push({
            path: "/pregisterPerfectInfo",
            query: {
              corpId: this.user.corpId || ''
            }
          });
        } else {
          this.$router.push({
            path: "/vregisterPerfectInfo",
            query: {
              role: this.accountType,
              corpId: this.user.corpId || ''
            }
          });
        }
      }else {
        this.$router.push('/activateac');
      }

    },
  }
}
</script>

<style lang="scss" scoped>
.auditFailedContainer {
  border-top: 2px solid #ffd64e;
  padding-bottom: 100px;
  height: 675px;
  text-align: center;
  padding-top: 110px;
  i {
    background: url(../../../assets/images/red_no_right.png) no-repeat;
    width: 48px;
    height: 48px;
    display: block;
    margin: auto;
  }
  h1 {
    color: #313231;
    font-size: 22px;
    font-weight: bold;
    margin: 22px auto;
  }
  p {
    font-size: 12px;
    font-weight: bold;
    max-width: 700px;
    margin: auto;
    line-height: 20px;
    span {
      color: #ee2d3a;
    }
  }
  button {
    text-align: center;
    outline: none;
    font-size: 14px;
    margin-top: 40px;
  }
}
</style>