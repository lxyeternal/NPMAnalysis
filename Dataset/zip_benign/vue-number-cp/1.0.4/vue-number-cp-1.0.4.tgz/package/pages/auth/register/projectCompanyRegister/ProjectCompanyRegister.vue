<template>
  <div class="register-wrap">
    <Header></Header>
    <search-bar :search-type="5" :progress="'新增项目公司'" :is-white-bg="true"></search-bar>
    <div class="register-wrapper">
      <div class="register-wrapper-inner">
        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>公司名称：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <el-select allow-create filterable remote default-first-option @change="handleChange($event)" placeholder="请输入公司名称" v-model="model.corpName" clearable @focus="clearCorpList(model.corpName)" @blur="checkForm('corpName')" :remote-method="handleSearchCompany" @clear="handleClear">
                <el-option v-for="(item,index) in companyList" :value="item.supplierName" :key="index" :disabled="!!item.corpId" :title="item.corpId && '已入驻' || undefined"></el-option>
              </el-select>
            </div>
            <div class="error-msg red" v-if="errorMsg.corpName">{{errorMsg.corpName}}</div>
          </div>
        </div>
        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>统一社会信用代码：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <!-- <input type="text" v-model="model.email" @keyup="checkForm('email')" placeholder="请输入您的常用邮箱"> -->
              <el-input placeholder="请输入统一社会信用代码" v-model.trim="model.busiLicense" @blur="checkForm('busiLicense')" maxlength="18" clearable>
              </el-input>
              <el-input style="display: none"></el-input>
            </div>
            <div class="error-msg red" v-if="errorMsg.busiLicense">{{errorMsg.busiLicense}}</div>
          </div>
        </div>
        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>法人代表：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <el-input placeholder="请输入法人代表" v-model.trim="model.legalRepresent" @blur="checkForm('legalRepresent')" maxlength="200" v-popover:popoverAcct clearable>
              </el-input>
              <el-input style="display: none"></el-input>
            </div>
            <div class="error-msg red" v-if="errorMsg.legalRepresent">{{errorMsg.legalRepresent}}</div>
          </div>
        </div>

        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>授权联系人姓名：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <el-input placeholder="请输入授权联系人姓名" v-model.trim="model.acctName" @blur="checkForm('acctName')" maxlength="30" v-popover:popoverAcct clearable>
              </el-input>
              <el-input style="display: none"></el-input>
            </div>
            <div class="error-msg red" v-if="errorMsg.acctName">{{errorMsg.acctName}}</div>
          </div>
        </div>
        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>授权联系人身份证：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <el-input placeholder="请输入授权联系人身份证" v-model.trim="model.certNo" @blur="checkForm('certNo')" maxlength="30" v-popover:popoverAcct clearable>
              </el-input>
              <el-input style="display: none"></el-input>
            </div>
            <div class="error-msg red" v-if="errorMsg.certNo">{{errorMsg.certNo}}</div>
          </div>
        </div>
        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>手机号：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <el-input placeholder="请输入授权联系人名下的手机号" v-model.trim="model.mobile" @blur="checkForm('mobile')" maxlength="11" onkeyup="if(this.value.length==1){this.value=this.value.replace(/[^1-9]/g,'')}else{this.value=this.value.replace(/\D/g,'')}" clearable>
              </el-input>
              <el-input style="display: none"></el-input>
            </div>
            <div class="error-msg red" v-if="errorMsg.mobile">{{errorMsg.mobile}}</div>
          </div>
        </div>
        <div class="register-label clearfloat">
          <div class="fl register-title">
            <i>*</i>邮 箱：
          </div>
          <div class="fl register-input-outer">
            <div class="register-input-box">
              <el-input placeholder="请输入授权联系人常用的邮箱" v-model.trim="model.email" @blur="checkForm('email')" maxlength="64" clearable>
              </el-input>
              <el-input style="display: none"></el-input>
            </div>
            <div class="error-msg red" v-if="errorMsg.email">{{errorMsg.email}}</div>
          </div>
        </div>
        <el-button type="primary" class="submit-btn large-btn" @click="submit">
          提交并继续
        </el-button>
        <el-dialog title="请仔细阅读平台条款" :visible.sync="dialogAgreementVisible" class="dialog-agreement">
          <div class="agrement-body scroll-style">
            <Agreement></Agreement>
          </div>
          <el-button type="primary" class="submit-btn large-btn" @click="checked=true;dialogAgreementVisible=false;">
            同意条款
          </el-button>
        </el-dialog>

        <el-dialog title="请仔细阅读平台条款" :visible.sync="managementMeasuresDialog" class="dialog-agreement">
          <div class="agrement-body scroll-style">
            <ManagementMeasures></ManagementMeasures>
          </div>
          <el-button type="primary" class="submit-btn large-btn" @click="managementMeasuresDialog=false;">
            同意条款
          </el-button>
        </el-dialog>

      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import {
  mapActions,
  mapState
} from 'vuex'
import { InterfaceService } from "@/services/api";
import SearchBar from '@/components/SearchBar'
import Header from '@/components/base/Header'
import Loading from "@/components/base/Loading";
import Agreement from "@/components/modal/Agreement";
import ManagementMeasures from "@/components/modal/ManagementMeasures";

export default {
  components: {
    SearchBar,
    Header,
    Loading,
    Agreement,
    ManagementMeasures
  },
  data() {
    return {

      model: {
        acctName: '',
        legalRepresent: '',
        mobile: '',
        email: '',
        corpName: '',
        busiLicense: '',
        certNo: '',
      },
      checked: false,
      managementMeasuresDialog: false,
      fromSearchInfo: false,
      isLoading: false,
      dialogAgreementVisible: false,
      errorMsg: {},
      companyList: [],
      shieldList: [],
      popoverMsg: {
        acctName: true
      },
    }
  },
  computed: {
    agentUserInfo() {
      return JSON.parse(this.$getRootScope("agentUserInfo") || '{}')
    },
  },
  methods: {
    ...mapActions(['setUserInfoAction']),
    handleChange(ev) {
      console.log(ev);
      if (ev) {
        let onOff = true
        this.companyList.forEach(item => {
          if (ev == item.supplierName) {
            this.model.legalRepresent = item.legalPersonName || "";
            this.model.busiLicense = item.trustCode || "";
            this.fromSearchInfo = true;
            this.checkForm('busiLicense');
            this.checkForm('legalRepresent');
            onOff = false
          }
        });
        if (onOff) {
          this.handleClear()
        }
      }
    },
    handleSearchCompany(query) {
      if (query.length >= 2) {
        this.getSupplierMedicalChecklist(query)
      } else {
        this.companyList = []
      }
    },
    handleClear() {
      if (this.fromSearchInfo) {
        this.model.legalRepresent = "";
        this.model.busiLicense = "";
        this.fromSearchInfo = false
      }
    },

    clearCorpList(query) {
      this.companyList = [];
      this.handleSearchCompany(query)
    },
    checkForm(key) {
      let reg = ''
      if (!this.model[key]) {
        delete this.errorMsg[key]
        this.$forceUpdate();
        this.$set(this.model, this.model);
        this.$set(this.errorMsg, this.errorMsg);
        return
      }
      if (key == 'acctName') {
        this.model[key] = this.checkShieldWord(this.model[key])
        reg = this.$commonExpression('account'); // /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]{6,18}$/ ;
        if (!reg.test(this.model[key])) {
          this.errorMsg[key] = '姓名设置不符合要求'
        } else {
          delete this.errorMsg[key]
        }

      }
      if (key == "legalRepresent") {
        if (!this.model[key]) {
          this.errorMsg[key] = '法人代表设置不符合要求'
        } else {
          delete this.errorMsg[key]
        }
      }

      if (key == 'mobile') {
        // if(this.model[key].length >= 11){
        //   this.model[key] = this.model[key].substr(0,11)
        // }
        reg = this.$commonExpression('mobile');  // /^[1][0-9][0-9]{9}$/;
        if (!reg.test(this.model[key])) {
          this.errorMsg[key] = '手机号格式不正确 '
        } else {
          delete this.errorMsg[key]
        }
      }


      if (key == 'certNo') {
        reg = this.$commonExpression('certNo');
        if (!reg.test(this.model[key])) {
          this.errorMsg[key] = '身份证号不正确 '
        } else {
          delete this.errorMsg[key]
        }
      }

      if (key == 'email') {

        reg = this.$commonExpression('email'); // /^([0-9A-Za-z\-_\.]+)@([0-9a-z]+\.[a-z]{2,3}(\.[a-z]{2})?)$/g;
        if (!reg.test(this.model[key])) {

          this.errorMsg[key] = '邮箱格式不正确 '
        } else {

          const mail = this.model[key] || '',
            mailSuffix = mail.slice(mail.lastIndexOf('.') + 1, mail.length),
            errorMailSuffix = JSON.parse(this.$getRootLocalStorage('errorMailSuffix') || '[]')

          if (errorMailSuffix.includes(mailSuffix)) {
            this.$set(this.errorMsg, key, '邮箱后缀不正确')
            return
          }

          delete this.errorMsg[key]
        }

      }
      if (key == 'corpName') {

        // if(!reg.test(this.model[key])){
        if (!this.model[key]) {

          this.errorMsg[key] = '公司名称格式不正确'
        } else {

          delete this.errorMsg[key]
        }

      }
      if (key == 'busiLicense') {

        reg = this.$commonExpression('busiLicense');
        if (!reg.test(this.model[key])) {

          this.errorMsg[key] = '统一社会信用代码格式不正确'
        } else {

          delete this.errorMsg[key]
        }

      }
      this.$forceUpdate();
      this.$set(this.model, this.model);
      this.$set(this.errorMsg, this.errorMsg);

    },
    checkPopover(key) {
      let reg = '';
      if (key == 'acctName' && this.model[key]) {
        reg = this.$commonExpression('account'); // /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]{6,18}$/ ;
        if (!reg.test(this.model[key])) {
          this.popoverMsg[key] = true
        } else {
          this.popoverMsg[key] = false
        }
        this.$forceUpdate();
        this.$set(this.popoverMsg, this.popoverMsg);
      }

    },
    submit() {

      for (let key in this.model) {

        if (!this.model[key]) {
          if (key != 'validateCode') {
            this.errorMsg[key] = '输入不能为空'
          }
        }
      }
      this.$forceUpdate();
      this.$set(this.model, this.model);
      this.$set(this.errorMsg, this.errorMsg);
      if (JSON.stringify(this.errorMsg) == "{}") {
        let param = {
          'acctName': this.model.acctName,
          'legalRepresent': this.model.legalRepresent,
          'mobile': this.model.mobile,
          'email': this.model.email,
          'corpName': this.model.corpName,
          'busiLicense': this.model.busiLicense,
          'certNo': this.model.certNo,
        }
        InterfaceService.agentRegister(
          param,
          data => {
            let res = data.respData
            let errorKey = '';
            if (res.respCode == '0000') {
              let agentUserInfo = {
                'acctName': this.model.acctName,
                'legalRepresent': this.model.legalRepresent,
                'mobile': this.model.mobile,
                'email': this.model.email,
                'corpName': this.model.corpName,
                'busiLicense': this.model.busiLicense,
                'certNo': this.model.certNo,
                'acctId': res.acctId,
                'mobileNo': res.mobile,
                'corpId': res.corpId,
                'limitCategoryList': this.agentUserInfo.limitCategoryList
              };
              this.$setRootScope('agentUserInfo', JSON.stringify(agentUserInfo))
              try {
                window.opener && window.opener.location.reload()
              } catch (error) { }
              this.$router.push("/projectCompanyPregisterPerfectInfo")
            } else {
              if (res.respCode == 'MEM0064' || res.respCode == 'MEM0058' || res.respCode == 'MEM0062') {
                errorKey = 'acctName'
              } else if (res.respCode == 'MEM0066' || res.respCode == 'MEM0025' || res.respCode == 'MEM0051') {
                errorKey = 'mobile'
              } else if (res.respCode == 'MEM0065' || res.respCode == 'MEM0059' || res.respCode == 'MEM0063') {
                errorKey = 'email'
              } else if (res.respCode == 'MEM020030') {//统一社会信用代码
                errorKey = 'busiLicense'
              }
              if (errorKey) {
                this.errorMsg[errorKey] = res.respMsg
              } else {
                this.$message.error(res.respMsg);
              }
              this.$forceUpdate();
              this.$set(this.errorMsg, this.errorMsg);
            }
          },
          data => { },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      } else {
        this.dialogAgreementVisible = false
      }
    },
    getSupplierMedicalChecklist(keyWord) {
      const params = { keyWord: keyWord }
      InterfaceService.getSupplierMedicalChecklist(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.companyList = data.respData.storageInfo || [];
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },
    treeToArray(tree, arr) {
      if (tree) {
        let res = arr
        for (let n = 0; n < tree.length; n++) {
          let treeItem = tree[n]
          res.push({
            menuAvailable: treeItem.menuAvailable,
            menuDisplaySort: treeItem.menuDisplaySort,
            menuID: treeItem.menuID,
            menuLevel: treeItem.menuLevel,

            menuName: treeItem.menuName,
            menuParentID: treeItem.menuParentID,
            menuStatus: treeItem.menuStatus,
            menuType: treeItem.menuType,
            menuURL: treeItem.menuURL
          })

          if (treeItem.menuList && treeItem.menuList.length > 0) {
            this.treeToArray(treeItem.menuList, res)
          }
        }

        return res
      } else {
        return []
      }

    },
    checkShieldWord(word) {
      var shieldListLen = this.shieldList.length;
      // flag true 默认没有敏感字
      var flag = true;
      if (/[\\|<|>]/.test(word)) {
        flag = false;
        return flag;
      } else {
        for (var i = 0; i < shieldListLen; i++) {
          // 设置flag有敏感字
          flag = false;
          var shieldItem = this.shieldList[i];
          var k = -1;
          for (var j = 0; j < shieldItem.length; j++) {
            var shieldItemStr = shieldItem[j];
            var index = word.indexOf(shieldItemStr, k + 1);
            if (index <= k) {
              flag = true; // 内容不满足敏感字规则
              break;
            } else {
              k = index;
            }
          }
          if (!flag) {
            break;
          }
        }
      }
      if (flag) {
        return word
      } else {
        return '';
      }
    },
    getShieldList() {
      InterfaceService.getshieldList(data => {
        if (typeof data === "string") {
          let info = eval("(" + data + ")") || {};
          this.shieldList = info.exportDefault.shieldList || []
        } else if (typeof data === "object") {
          this.shieldList = data.exportDefault.shieldList || []
        }
      })
    }
  },
  mounted() {
    if (this.agentUserInfo && this.agentUserInfo.acctName) {
      const { acctName, busiLicense, legalRepresent } = this.agentUserInfo
      this.model.corpName = acctName
      this.model.busiLicense = busiLicense
      this.model.legalRepresent = legalRepresent
    }
    this.getShieldList()
    console.log(this.model, '-this.model');

  }
}
</script>

<style lang="scss" scoped>
.guid-text {
  font-size: 12px;
  color: #888;
  line-height: 20px;
  i {
    margin-right: 8px;
  }
}
/deep/ .el-radio__input.is-checked + .el-radio__label {
  color: #444;
}
/deep/ .el-radio-group {
  width: 100%;
}
/deep/ .el-radio {
  width: 100px;
}
/* 注册页面 */
.register-wrapper {
  border-top: 2px solid #c99f4f;
  padding-bottom: 100px;

  .register-wrapper-inner {
    width: 840px;
    margin: 0 auto;
    padding: 46px 85px 0;

    .register-label {
      margin-bottom: 15px;
      //overflow: hidden;

      .register-input-outer {
        width: 500px;
        min-height: 40px;

        // .error-msg{
        //   // height: 40px;
        //   line-height: 1.5;
        //   font-size: 12px;
        // }
      }

      .register-input-box {
        width: 500px;
        height: 40px;
        line-height: 40px;
        &.w620 {
          width: 620px;
          margin-left: 56px;
        }

        input {
          width: 100%;
          height: 40px;
          border: 1px solid #dddddd;
          text-indent: 20px;
          padding: 0;
        }
      }

      .register-title {
        width: 170px;
        height: 40px;
        line-height: 40px;
        text-align: right;
        padding-right: 15px;
        font-size: 12px;
        color: #888;

        i {
          color: #e93340;
          padding-right: 2px;
        }
      }
    }
    .submit-btn {
      display: block;
      margin: 50px auto 0;
    }
  }

  /deep/ .el-checkbox__input.is-checked + .el-checkbox__label {
    color: #444;
  }

  .dialog-agreement {
    /deep/ .el-dialog__body {
      position: relative;
      font-size: 12px;
      color: #444;
      line-height: 23px;

      padding-top: 24px;
      padding-left: 40px;

      .agrement-body {
        overflow-y: scroll;
        height: 500px;
      }
    }
  }
}
.disable {
  cursor: not-allowed !important;
}
.el-select {
  width: 100%;
}
</style>