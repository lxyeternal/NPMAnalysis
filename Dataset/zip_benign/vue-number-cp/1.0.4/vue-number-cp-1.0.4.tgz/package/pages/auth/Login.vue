<template>
  <div class="login-wrap">
    <Header :showLoginOpint="false" :is-white-bg="isWhiteBg"></Header>
    <search-bar :searchType="searchType" @login="onLogin('')"></search-bar>
    <div class="login-wrap-inner" id="login-wrap-inner">
      <video class="loginVideo" muted id="login-video" loop="loop" autoplay="autoplay" width="1920" height="1080">
        <!-- <source v-bind:src= "bgVideoUrl" type="video/mp4" /> -->
        <!-- <source src="../../assets/video/loginBg.mp4" type="video/mp4" /> -->
        <source src="../../../static/video/loginBg.mp4" type="video/mp4" />
        <!-- <source  v-bind:src= "bgVideoUrl"  type="video/mp4"> -->
      </video>

      <div class="contain inner-container" style="position:absolute;top:0px;left:50%;margin-left:-595px;height:100%;min-height:1000px;">
        <el-form class="form">
          <!--<div class="login-title">欢迎登录</div>-->
          <div class="login-title">
            <ul>
              <li :class="{active:loginType == 1}" @click="handleChangeLoginType(1)">
                <span>密码登录</span>
              </li>
              <li :class="{active:loginType == 2}" @click="handleChangeLoginType(2)">
                <span>短信登录</span>
              </li>
            </ul>
          </div>
          <div class="errorMsg" v-if="respMsg">
            <img src="../../assets/images/login/notice.png" alt="" />
            {{ respMsg }}
          </div>
          <el-form-item class="user-modal">
            <el-input type="text" v-model="usernameModel" name="userName" placeholder="请输入手机号码" clearable :maxlength="11" @input="clearBlankSpace($event)"></el-input>
          </el-form-item>
          <el-form-item class="user-modal" v-show="loginType == 1">
            <!-- @keyup.enter.native="onLogin('')" -->
            <el-input class="pass-word" v-show="isIE" type="password" v-model="passwordModel" name="passWord" placeholder="请输入登录密码" auto-complete="off" clearable></el-input>
            <el-input class="pass-word" v-show="!isIE" type="password" v-model="passwordModel" name="passWord" placeholder="请输入登录密码" auto-complete="off" clearable @keyup.enter.native="onLogin('')"></el-input>
          </el-form-item>
          <el-form-item class="user-modal" v-show="loginType == 2">
            <!-- @keyup.enter.native="onLogin('')" -->
            <!--<el-input class="pass-word message-login" v-show="isIE" type="password" v-model="passwordModel" name="passWord" placeholder="请输入四位验证码" auto-complete="off" clearable></el-input>-->
            <!--<el-button type="primary" class="message-login-btn" v-show="isIE" @click="getMessageCode">获取验证码</el-button>-->
            <!--<el-input class="pass-word message-login" v-show="!isIE" type="password" v-model="passwordModel" name="passWord" placeholder="请输入四位验证码" auto-complete="off" clearable @keyup.enter.native="onLogin('')"></el-input>-->
            <!--<el-button type="primary" class="message-login-btn" v-show="!isIE" @click="getMessageCode">获取验证码</el-button>-->
            <PhoneCode class="pass-word message-login-btn" :is-show-phone-code="true" :type="'1'" :placeholder="'请输入四位验证码'" :btnContent="'获取验证码'" :phone="usernameModel" :imgCode="validateCode" :origTxCode="'login'" :disable="usernameModel.length < 11" @error="getError" @received="getPhoneCode">
            </PhoneCode>
          </el-form-item>
          <el-form-item class="fo-4" v-if="isShowValidate && loginType != 2">
            <ValidateCode v-if="isShowValidate" @received="handleChangeValidCode" :update="updateCode"></ValidateCode>
          </el-form-item>
          <el-form-item class="fo-2">
            <el-button class="button" size="" type="primary" @click="onLogin('')">登录</el-button>
            <div style="margin-top: 58px;letter-spacing: 2px;">
              <div class="left">
                <el-checkbox v-model="checked" style="color:#fff;">记住账号</el-checkbox>
                <el-checkbox v-model="checkedPwd" style="color:#fff;">记住密码</el-checkbox>
              </div>
              <div class="right">
                <div style="color: #fff;">
                  <a @click="go('/forgetpwd')"> 忘记密码?</a> |
                  <a @click="go('/register')"> 立即注册</a>
                </div>
              </div>
              <div style="clear: both"></div>
            </div>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>

    <!-- 切换账号 -->
    <el-dialog class="dialog" title="选择账号" :append-to-body="true" :lock-scroll="true" :visible.sync="selectAccountDialogVisible" width="50%" center :close-on-click-modal="false" :show-close="false">
      <div class="change-account ">
        <div class="change-account-inner clearfloat">
          <div class="fl" style="width:33%;height:100%;min-height:50px;"></div>
          <div class="fl" style="width:67%;">
            <el-radio-group v-model="accountCheckList">
              <el-radio :label="item.acctId" v-for="item in accountList" v-bind:key="item.acctId">{{ item.corpName }}</el-radio>
            </el-radio-group>
          </div>
        </div>
        <div class="change-account-btns tc">
          <el-button size="" type="primary" @click="handleSelectAccount">确认登录</el-button>
          <!-- <el-button size="" @click="cancelChangeAccount">&nbsp;&nbsp;&nbsp;&nbsp;取消&nbsp;&nbsp;&nbsp;&nbsp;</el-button> -->
        </div>
      </div>
    </el-dialog>
    <Footer></Footer>

  </div>
</template>
<script>
import {
  BASE_CONFIG
} from '@/config/config'
import {
  mapActions,
  mapState
} from 'vuex'
import SearchBar from '@/components/SearchBar'
import Header from '@/components/base/Header'
import Loading from '@/components/base/Loading'
import ValidateCode from '@/components/base/ValidateCode.vue';
import Footer from '@/components/base/Footer'
import PhoneCode from '@/components/base/PhoneCode'
import {
  InterfaceService
} from '@/services/api'
import CryptoJS from 'crypto-js';

export default {
  components: {
    SearchBar,
    Header,
    Loading,
    Footer,
    PhoneCode,
    ValidateCode,
  },
  data() {
    return {
      identifyCode: "",
      isIE: false,
      isWhiteBg: true,
      pageName: '登录',
      searchType: 2,
      usernameModel: '',
      passwordModel: '',
      validateCode: '',
      errorText: '',
      msgGoPath: '',
      loginWrapInner: 100,
      loginType: 1,
      isLoading: false,
      isShowDialog: false,
      isShowValidate: false,
      message: '',
      respMsg: '',
      errorTimes: '55',
      checked: false,
      updateCode: 0,
      bgVideoUrl: '',//背景视频地址,
      selectAccountDialogVisible: false,
      accountList: [],
      unreadNum: 0,
      unreadList: [],
      accountCheckList: '',
      usetAcctId: '',
      checkedPwd: false,
    }
  },
  methods: {
    ...mapActions(['setUserInfoAction', 'setSysMsgInfo']),
    handleChangeValidCode(code, type) {
      console.log(code);
      this.validateCode = code;
      if (type == 'enter') {
        this.onLogin('')
      }
    },
    handleChangeLoginType(type) {
      this.loginType = type;
      this.respMsg = "";
      // if (this.loginType == 2) {
      //   this.isShowValidate = false;
      // }else {
      // }
    },
    getError(msg) {
      this.validateCode = '';
      // this.updateCode ++;
      this.respMsg = msg
      this.$forceUpdate();
    },
    getPhoneCode(identifyCode) {
      this.identifyCode = identifyCode
      this.$forceUpdate();
    },
    getMessageCode() {

    },
    treeToArray(tree, arr) {
      let res = arr
      let len = tree.length
      for (let n = 0; n < len; n++) {
        let treeItem = tree[n]
        // res.push({
        //     menuAvailable: treeItem.menuAvailable,
        //     menuDisplaySort: treeItem.menuDisplaySort,
        //     menuID: treeItem.menuID,
        //     menuLevel: treeItem.menuLevel,

        //     menuName: treeItem.menuName,
        //     menuParentID: treeItem.menuParentID,
        //     menuStatus: treeItem.menuStatus,
        //     menuType: treeItem.menuType,
        //     menuURL:treeItem.menuURL
        // })
        res.push(treeItem)
        if (treeItem.menuList && treeItem.menuList.length > 0) {
          this.treeToArray(treeItem.menuList, res)
        }
      }

      return res
    },
    treeToSimpleArray(tree, arr) {
      let res = arr
      let len = tree.length
      for (let n = 0; n < len; n++) {
        let treeItem = tree[n]
        if (treeItem.menuType == "1") {
          res.push({
            menuAvailable: treeItem.menuAvailable,
            menuType: treeItem.menuType,
            menuID: treeItem.menuID,
            menuName: treeItem.menuName,
            menuList: treeItem.menuList,
            menuURL: treeItem.menuURL,
            menuIcon: treeItem.menuIcon || "",
            menuPath: treeItem.menuPath || ""
          })
        }

      }
      res.forEach(item => {
        if (item.menuList && item.menuList.length > 0) {
          item.menuList = this.treeToSimpleArray(item.menuList, [])
        }
      });
      return res
    },
    onLogin(o_params) {
      var self = this
      //console.log(o_params)
      if (!o_params) {//页面用户名密码登录 才 验证
        if (!this.usernameModel) {
          self.respMsg = '请输入手机号码';
          return;
        } else {
          if (this.loginType == 1) {
            if (!this.passwordModel) {
              self.respMsg = '请输入密码';
              return;
            } else if (!/^\w{6,18}$/g.test(this.passwordModel)) {
              self.respMsg = '请输入6-18位密码'
            }
          } else if (this.loginType == 2) {
            if (!this.identifyCode) {
              self.respMsg = '请输入验证码';
              return;
            }
          }
          // 记住账户
          if (self.checked == true) {
            self.$setCookie('account', self.usernameModel, 365)
          }
          // 记住密码
          if (self.accountPwd == true) {
            self.$setCookie('accountPwd', self.passwordModel, 365)
          }
          if (this.isShowValidate) {
            console.log(this.validateCode);
            if (this.validateCode == '' && this.loginType == '1') {
              self.errorText = '验证码不符，请输入正确的验证码';
              self.respMsg = self.errorText;
              return;
            }
          }
        }
      }
      var password = CryptoJS.MD5(self.passwordModel).toString();
      //与后端请求
      let param = {};
      if (this.loginType == 1) {
        param = {
          'mobile': self.usernameModel,
          'pwd': password,
        }
      } else {
        param = {
          'mobile': self.usernameModel,
          'identifyCode': this.identifyCode,
        }
      }
      if (!o_params && this.validateCode != '') {
        param['validateCode'] = self.validateCode
      }
      let params = Object.assign({}, param);
      if (o_params) {
        params = Object.assign(param, o_params);
      }
      //console.log(params)
      InterfaceService[this.loginType == 1 ? 'login' : o_params ? 'multipleAccountsLogin' : 'msgLogin'](params, (data) => {
        // InterfaceService[this.loginType == 1 ? 'loginNew': o_params ? 'multipleAccountsLogin' : 'msgLogin' ](params, (data) => {
        // console.log(data)

        let resulstOuter = data.respData
        if (resulstOuter.respCode == "0000") {//单账号 或者已选择账号
          self.usetAcctId = resulstOuter.acctId || ''
          self.setUserInfoAction([])
          //上传时禁用的特殊字符
          self.getSpecialChar()
          this.$removeRootScope('frameworkListStorage')
          this.$removeRootScope('canSaveCoincidenceVisible')
          // 获取 confluence 信息
          // this.getConfluenceInfo()
          // 重置签章有效性
          this.$store.dispatch("setSignSMSValid", false);
          // console.log(resulstOuter)
          // 存储登录次数
          // resulstOuter.bs === 'B' && this.getCacheInfos(resulstOuter.acctId)

          let accountList = []
          if (this.accountList.length > 1) {
            let acc_len = this.accountList.length
            for (let i = 0; i < acc_len; i++) {
              let item = this.accountList[i]
              if (item.acctId === this.accountCheckList) {
                item.selected = true
              } else {
                item.selected = false
              }
              accountList.push(item)
            }

          }

          // 如果是 多账户 (因为采购商多账户,被后台处理成了一条 取不到this.accountList), 因为有多处地方 使用到了accountList 里查找 acctId 匹配 所以这里组装一个
          if (resulstOuter.acctInfos && resulstOuter.acctInfos[0] && resulstOuter.acctInfos[0].bs == 'B') {
            resulstOuter.acctIdList && resulstOuter.acctIdList.forEach(f => {
              accountList.push({
                acctId: f
              })
            })
          }

          if (!resulstOuter.acctInfos || resulstOuter.acctInfos.length == 0) {//跳转到补填公司类型

            let userInfo = {
              'mobileNo': resulstOuter.mobileNo,
              'email': resulstOuter.email,

              'invoiceFlag': '0',
              'acctId': '',
              'acctName': '',
              'isLogin': '1',
              'corpId': '',
              'corpName': '',
              'bs': '',
              'contractCorpType': '',
              'accountList': accountList,
              'groupCompanyCode': '',
              'groupCompanyName': '',
              'groupCompanyName': '',
              'regStep': '0',
              'custTags': resulstOuter.custTags || [],
              // 菜单改造
              'corpRoleList': resulstOuter.corpRoleList || [],
              'acctIdList': resulstOuter.acctIdList || [],
              'corpIdList': resulstOuter.corpIdList || [],
              'corpMenuList': resulstOuter.corpMenuList || [],
              'corpList': resulstOuter.corpList || [],
              'busitypeMng': resulstOuter.busitypeMng || [],
            };
            self.$setRootScope('user', JSON.stringify(userInfo))
            self.$setRootLocalStorage('user', JSON.stringify(userInfo))
            self.setUserInfoAction(userInfo)
            self.$router.push('/registerSupplement');
          } else {
            let resInner = resulstOuter.acctInfos && resulstOuter.acctInfos[0]
            let cName = ''
            if (resulstOuter.groupCompanyName && resulstOuter.cityCompany) {
              cName = `${resulstOuter.groupCompanyName}${resulstOuter.cityCompany}`
            }

            // 菜单改造 - 把之前 默认项 更新为 corpRoleList 对应 corpId 下的 roleList
            try {
              resulstOuter.roleIds = resulstOuter.corpRoleList && resulstOuter.corpRoleList.find(f => f.corpId == resInner.corpId) && resulstOuter.corpRoleList.find(f => f.corpId == resInner.corpId).roleList || []
            } catch (error) {
              console.error('LoginTypeError: ', error)
            }


            let userInfo = {
              'mobileNo': resulstOuter.mobileNo,
              'email': resulstOuter.email,
              'invoiceFlag': resInner.invoiceFlg,
              'acctId': resInner.acctId,
              'acctName': resInner.acctName,
              'isLogin': '1',
              'corpId': resInner.corpId,
              'corpName': resInner.corpName,
              'busiLicense': resInner.busiLicense,
              'bs': resInner.bs,
              'contractCorpType': resInner.contractCorpType,
              'accountList': accountList,
              'groupCompanyCode': resulstOuter.groupCompanyCode, // 是否绿地公司：1：绿地Group 2: 非绿地Group
              'groupCompanyName': resulstOuter.groupCompanyName, // 是否绿地公司：1：绿地Group 2: 非绿地Group
              'brokerList': resulstOuter.brokerList || [],
              'regStep': resInner.regStep,
              'approveId': resInner.approveId,
              'attachUrl': resInner.attachUrl || "",
              'legalRepresent': resInner.legalRepresent || "",
              'custStatus': resulstOuter.custStatus,
              'approveStatus': resInner.approveStatus,
              'corpStatus': resulstOuter.corpStatus,
              'roleIds': resulstOuter.roleIds,
              'confluenceUserName': cName,
              'supplyType': resulstOuter.supplyType || "",
              'cityCompany': resulstOuter.cityCompany,
              'shortCorpName': resInner.shortCorpName || "",
              'corpTags': resulstOuter.corpTags || [],
              'custTags': resulstOuter.custTags || [],
              // 菜单改造
              'corpRoleList': resulstOuter.corpRoleList || [],
              'acctIdList': resulstOuter.acctIdList || [],
              'corpIdList': resulstOuter.corpIdList || [],
              'corpMenuList': resulstOuter.corpMenuList || [],
              'corpList': resulstOuter.corpList || [],
              'busitypeMng': resulstOuter.busitypeMng || [],
            };
            self.$setRootScope('user', JSON.stringify(userInfo))
            self.$setRootLocalStorage('user', JSON.stringify(userInfo))
            self.setUserInfoAction(userInfo)
            //权限树
            //获取menuList  menuAvailable!='1'则表示没有权限
            let limitTxCodeArr = [],
              menuList = []
            const corpMenuList = resulstOuter && resulstOuter.corpMenuList || [],
              findItme = corpMenuList.find(f => f.corpId == resulstOuter.corpId) || {}

            menuList = findItme.menuList || []
            if (menuList && menuList.length) {
              limitTxCodeArr = menuList[0] && menuList[0].menuList || []

              let treeToArray = this.treeToArray(limitTxCodeArr, []),
                limitTxCode = [],
                showMenuList = [];

              for (let i = 0; i < treeToArray.length; i++) {
                if (treeToArray[i].menuAvailable != '1') {
                  limitTxCode.push({ 'code': treeToArray[i].menuURL, 'type': treeToArray[i].menuType, 'name': treeToArray[i].menuName })
                } else {
                  showMenuList = this.treeToSimpleArray(limitTxCodeArr, [])
                }
              }
              self.$setRootScope('limitTxCode', JSON.stringify(limitTxCode))
              self.$setRootScope('showMenuList', JSON.stringify(showMenuList))
            } else {
              self.$setRootScope('limitTxCode', JSON.stringify([]))
              self.$setRootScope('showMenuList', JSON.stringify([]))
            }
            //跳转处理------开始-------

            console.log(resulstOuter.custStatus, 'resulstOuter.custStatus ');
            // 判断是否是管理员身份，如果是管理员身份但没授权书，先上传授权书
            let adminRoles = ['1000', '2000', '3000', '4000', '5000', '9000']
            let isAdmin = userInfo.roleIds && userInfo.roleIds.some(item => {
              return adminRoles.indexOf(item.roleId) != -1
            });

            // 大基建 直接跳转
            // if (resulstOuter.custTags && resulstOuter.custTags.length > 0) {
            //   let isConstruction = false;
            //   resulstOuter.custTags.forEach(el => {
            //     if (el.tagId == "LVDI_CONSTRUCTION") {
            //       isConstruction = true;
            //     }
            //   })
            //   if (isConstruction) {
            //     this.getAcctDialogList();
            //     this.$router.push('/bigInfrastructureCenter/workbench')
            //     return;
            //   }
            // }

            // 如果是官网登录的 需 跳回官网
            if (this.$route.query.isWebsite) {
              window.location = BASE_CONFIG.OFFICIAL_URL
              return
            }

            // 显示 完善信息
            const corpItem = resulstOuter.corpList && resulstOuter.corpList.find(f => f.corpId == resulstOuter.corpId) || {}
            if (corpItem.enterFrom == '2') {
              if (resulstOuter.custStatus == '2') {//未激活
                self.$router.push('/activateac');
                return;
              }
              this.$setRootScope('sessionShowEsUserPerfectListDialog', '1')
              this.$router.push('/home');
              return
            }

            if (resInner.contractCorpType === 'broker' || !isAdmin || !resInner.approveStatus || resInner.approveStatus === 'approved') {
              if (resulstOuter.custStatus && resulstOuter.custStatus == '0') {//用户已激活
                this.getAcctDialogList();
                // if (resInner.attachUrl)
                if (resulstOuter.corpStatus == '-1') {
                  // 审核失败
                  self.$router.push({ path: '/auditFailed', query: { approveMsg: resulstOuter.approveMsg } });
                  return;
                }
                //判断是否注册信息需要补充
                if (resInner.regStep == '2') {//注册信息完善 跳转到登录前的页面
                  if (resInner.corpStatus == '0') {//账号未激活
                    self.$router.push('/registerSuccess');
                    return;
                  }

                  let defaultGoRout = self.$getRootScope('defaultGoRout')
                  const toFullPath = sessionStorage.getItem('toFullPath')
                  let query = self.$getRootScope('query') && JSON.parse(self.$getRootScope('query'))

                  //是否跳转登录前记录的页面：注册页、更改过bs
                  let isChangeBs = false;
                  let rout = defaultGoRout ? defaultGoRout.toLocaleLowerCase() : ''

                  //施工单位 监理单位 或者 上次登出前的BS和本次登录不一致的 跳转到首页
                  if (resInner.bs == "C" || resInner.bs == "CS" || (self.$getRootScope('defaultBs') && resInner.bs != self.$getRootScope('defaultBs'))) {
                    isChangeBs = true
                  }
                  //从某些页面跳转到登录页  登录后不再回到原页面：注册相关页、忘记密码页 、发票页
                  if (rout.indexOf('register') > -1 ||
                    rout.indexOf('change') > -1 ||
                    rout.indexOf('forgetpwd') > -1 ||
                    rout.indexOf('error') > -1 ||
                    rout.indexOf('noright') > -1 ||
                    rout.indexOf('invoice') > -1 ||
                    rout.indexOf('activateac') > -1
                  ) {//从注册相关页、发票页 跳转登录后 不再回到注册相关页
                    isChangeBs = true
                  }
                  if (toFullPath) {

                    if (!isChangeBs) {
                      if (toFullPath.indexOf("accountInfo") != -1) {
                        if (resInner.bs == "B") {
                          toFullPath == "/purchaserCenter/accountInfo"
                        } else {
                          toFullPath == "/vendorCenter/accountInfo"
                        }
                        self.$router.push({
                          path: toFullPath
                        });
                      } else if (toFullPath.indexOf("biddingSignUpInfo") != -1) {
                        if (userInfo.bs == "B") {
                          this.$message.info("采购商不可报名招标！")
                          self.$router.push({
                            path: "/home"
                          });
                        } else {
                          self.$router.push({
                            path: toFullPath
                          });
                        }
                      } else {
                        if (toFullPath == '/register' || toFullPath == '/forgetpwd' || toFullPath == '/registerAdvanced' || toFullPath == '/PregisterPerfectInfo' || toFullPath == '/VregisterPerfectInfo') {
                          self.$router.push({
                            path: "/home"
                          });
                        } else {
                          self.$router.push({
                            path: toFullPath
                          });
                        }

                      }
                      return
                    } else {
                      self.$router.push('/home');
                    }
                  }
                  if (!isChangeBs && defaultGoRout) {

                    // 当前新ID
                    const user = self.$getRootScope('user') && JSON.parse(self.$getRootScope('user')),
                      acctIdOld = self.$getRootScope('acctIdOld')

                    console.log(acctIdOld, user.acctId, '---');

                    self.$router.push({
                      // 如果 退出之前的人和现在登录的人是同一个人 进入之前页面, 否则去home
                      path: acctIdOld === user.acctId ? defaultGoRout : '/home',
                      query: query
                    });
                    // 如果 是 别的指定路径 跳转过来 需要登录的  登录后 跳转回原来路径
                  } else {
                    console.log(3);
                    self.$router.push('/home');
                  }

                  self.$removeRootScope('acctIdOld')
                } else if (resInner.regStep == '1') {//注册信息不完善 跳转到注册第三步
                  console.log(resInner);

                  self.$router.push('/registerAdvanced');
                } else {
                  if (resInner.bs) {
                    self.$router.push(resInner.bs == 'B' ? '/PregisterPerfectInfo' : 'VregisterPerfectInfo');
                  }
                }
                // 登录成功获取站内信
                self.callMsgListData();
              } else if (resulstOuter.custStatus == '2') {//未激活
                self.$router.push('/activateac');
                return;
              } else {
                self.$router.push('/home');
                return;
              }
            } else {
              if (resInner.approveStatus == 'rejected') {
                self.$router.push({ path: '/auditFailed', query: { approveMsg: resInner.approveMsg, type: 'admin' } });
              } else if (resInner.approveStatus == 'submited') {
                self.$router.push({ path: '/registerSuccess', query: { type: 'admin' } });
              } else {
                self.$router.push('/activateac');
              }
            }

          }
          // self.getMsgNumLimit();

        } else {//多账号或者登录失败
          self.$removeRootScope('user')

          self.$removeRootScope('limitTxCode')
          self.setUserInfoAction({})


          if (resulstOuter.respCode == "MEM0175") {//多账号
            let divisionItem = {}

            resulstOuter.acctInfos = resulstOuter.acctInfos || []

            // 先 查找 是否名称 = 上海绿地建筑材料集团有限公司, 先使用这个公司的登录
            divisionItem = resulstOuter.acctInfos.find(f => f.contractCorpType == 'broker' && f.corpName == '上海绿地建筑材料集团有限公司') || {}

            // 没有的话使用 事业部登录
            if (!divisionItem.acctId) {
              // 查找事业部
              divisionItem = resulstOuter.acctInfos && resulstOuter.acctInfos.find(f => f.contractCorpType == 'division') || {}

            }

            // 如果没有 事业部, 查看是否有 材料公司
            if (!divisionItem.acctId) {
              divisionItem = resulstOuter.acctInfos && resulstOuter.acctInfos.find(f => f.contractCorpType == 'broker') || {}
            }

            this.accountList = resulstOuter.acctInfos // 事业部不要多账户切换
            // 事业部/材料公司 自动登录
            if (divisionItem.acctId) {
              this.accountCheckList = divisionItem.acctId
              this.onLogin({ 'acctId': this.accountCheckList })
              return
            }

            // this.accountList = resulstOuter.acctInfos
            self.selectAccountDialogVisible = true

          } else {//登录失败
            self.respMsg = resulstOuter.respMsg;
            if (this.loginType == 1) {
              self.isShowValidate = true;
              self.updateCode++
            }

          }

        }


      }, (data) => {
        self.$removeRootScope('limitTxCode')
        self.$removeRootScope('user')
        console.log(333);
        self.setUserInfoAction({});

        //self.loginAction('0')
        if (data && data.respMsg) {
          self.isShowDialog = true;
          self.message = data.respMsg;
        }
      }, () => {
        self.isLoading = true
      }, () => {
        self.isLoading = false
      });
      self.errorText = ''
    },
    fireKeyEvent(el, evtType, keyCode) {
      var evtObj;
      if (document.createEvent) {
        if (window.KeyEvent) {//firefox 浏览器下模拟事件
          evtObj = document.createEvent('KeyEvents');
          evtObj.initKeyEvent(evtType, true, true, window, true, false, false, false, keyCode, 0);
        } else {//chrome 浏览器下模拟事件
          evtObj = document.createEvent('UIEvents');
          evtObj.initUIEvent(evtType, true, true, window, 1);

          delete evtObj.keyCode;
          if (typeof evtObj.keyCode === "undefined") {//为了模拟keycode
            Object.defineProperty(evtObj, "keyCode", { value: keyCode });
          } else {
            evtObj.key = String.fromCharCode(keyCode);
          }

          if (typeof evtObj.ctrlKey === 'undefined') {//为了模拟ctrl键
            Object.defineProperty(evtObj, "ctrlKey", { value: true });
          } else {
            evtObj.ctrlKey = true;
          }
        }
        el.dispatchEvent(evtObj);

      } else if (document.createEventObject) {//IE 浏览器下模拟事件
        evtObj = document.createEventObject();
        evtObj.keyCode = keyCode
        el.fireEvent('on' + evtType, evtObj);
      }
    },
    getSpecialChar() {
      InterfaceService.getPaymentMethod({
        appName: 'TRANS',
        groupIds: ["FILE_SPECIAL_CHARS_CFG"]
      }, (data) => {
        if (data.respData.respCode == '0000') {
          let innerRes = data.respData;
          let CHANGE_FILE_REPLACE_DATA = innerRes.configEntityListMap && innerRes.configEntityListMap.FILE_SPECIAL_CHARS_CFG[0] || {}
          let checkTextList = (CHANGE_FILE_REPLACE_DATA.value && CHANGE_FILE_REPLACE_DATA.value.split(';')) || [];
          this.$setRootScope('checkTextList', JSON.stringify(checkTextList))
          console.log(checkTextList);
        }
      }, (data) => {
      }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      });
    },
    //获取账户弹层列表
    getAcctDialogList() {
      const __this = this
      InterfaceService.getAcctDialogList({}, (data) => {
        if (data.respData.respCode == '0000') {
          let popupInfos = data.respData.popupInfos || [];

          if (popupInfos.length) {
            popupInfos = [popupInfos[0]] || []

            document.querySelector("body").addEventListener("click", this.handleClick)
            let str = "";
            let title = "";
            let popupId = popupInfos[0] && popupInfos[0].popupId || '';
            let popupBtnName = popupInfos[0] && popupInfos[0].buttonContent || '确认'
            let isImg = false
            popupInfos.forEach(item => {
              title = item.popupName;
              this.msgGoPath = item.popupPath;
              if (item.popupContext) {
                str += `<div class="tl">${item.popupContext}</div>`
              } else {
                str += `<img width="100%" height="100%" src="${item.popupImgUrl}"/>`
                isImg = true
              }
            });

            let popupCancelBtnName = isImg ? '不再提示' : '取消'

            setTimeout(() => {
              this.$confirm(
                str,
                title,
                {
                  cancelButtonClass: "btn-custom-cancel width-auto",
                  confirmButtonClass: "btn-custom-confirm width-auto",
                  customClass: "alert-box",
                  confirmButtonText: popupBtnName,
                  cancelButtonText: popupCancelBtnName,
                  dangerouslyUseHTMLString: true,
                  center: true,
                  distinguishCancelAndClose: true,
                  beforeClose(action, instance, done) {

                    if (action == 'confirm' || action == 'cancel') {
                      __this.UpdateCacheInfos(__this.usetAcctId, action === 'confirm' ? 'true' : 'false', popupId)
                    }

                    done()
                    // 如果是图片的情况下 需要点击 不再提示  才标注已读
                    if (isImg && action != 'cancel') {
                      return
                    }

                    if (popupInfos[0]) {
                      InterfaceService.updateAcctDialogStatus({
                        popupId: popupId
                      }, (data) => {
                        if (data.respData.respCode == '0000') {
                        }
                      }, (data) => {
                      }, () => {
                        this.isLoading = true
                      }, () => {
                        this.isLoading = false
                      });

                    }
                  }
                }).then(() => {
                  this.$router.push(this.msgGoPath);
                  document.querySelector("body").removeEventListener("click", this.handleClick)
                }).catch(() => {
                  document.querySelector("body").removeEventListener("click", this.handleClick)
                });
            }, 500)
          }
        }
      }, (data) => {
      }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      });
    },
    // 获取并存储 fonfluence 信息
    getConfluenceInfo() {
      InterfaceService.confluenceInfoOssAttach(data => {
        let item = []
        if (typeof data === "string") {
          item = eval("(" + data + ")");
        } else if (typeof data === "object") {
          item = data
        }

        this.$setRootScope('confluenceInfoList', JSON.stringify(item || []))
      });
    },
    handleSelectAccount() {
      this.onLogin({ 'acctId': this.accountCheckList })
    },
    init: function () {

      // 存储旧 ID
      const user = this.$getRootScope('user') && JSON.parse(this.$getRootScope('user')) || {}
      user.acctId && this.$setRootScope('acctIdOld', user.acctId)

      //登录初始化 清除store的登录状态和seession
      this.$removeRootScope('limitTxCode')
      this.$removeRootScope('user')
      this.$removeRootLocalStorage('user')
      this.$removeRootLocalStorage('watchUnreadInfo')
      this.$removeRootScope('registerPath')
      this.setUserInfoAction({});
      this.usernameModel = this.$getCookie('account');
      this.usernameModel && (this.checked = true)
      this.passwordModel = this.$getCookie('accountPwd');
      this.passwordModel && (this.checkedPwd = true)
      console.log(this.usernameModel, this.passwordModel, '-----------usernameModel');

      //登录初始化 获取是否需要验证码（上次登录失败的情况则后台会保存记录）
      InterfaceService.loginInit({}, (data) => {
        if (data.respData && data.respData.loginCnt > 0) {
          if (this.loginType == 1) {
            this.isShowValidate = true;
          }
        }
      }, (data) => {

      });

      let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
      // document.getElementById('login-wrap-inner').style.height = (h-34-160-55) + 'px';
      //extraconfig oss 上的配置文件刷新
      InterfaceService.getExtraConfig(res => {
        // console.log(res)
        this.$setRootScope('extraConfig', JSON.stringify(res))
      });
    },
    go(path) {
      this.$router.push(path);
    },
    clearBlankSpace(val) {
      this.usernameModel = val.replace(/\s+/g, "")
    },
    // getMsgNumLimit() {
    //   //1、请求未读留言数
    //   InterfaceService.doSysMsgUnReadNum({}, (data) => {
    //     if (data.respData.respCode == '0000') {
    //       this.$store.dispatch("setSysMsgInfo", data.respData.totalUnreadNums);
    //     }
    //   }, (data) => {
    //   }, () => {
    //     this.isLoading = true
    //   }, () => {
    //     this.isLoading = false
    //   });
    // },

    /**
     * 获取登录计数
     */
    getCacheInfos(id) {
      return new Promise(resolve => {
        let params = {
          targetId: id || '',
          key: 'USER_LOGIN_COUNT' || ''
        };
        InterfaceService.getCacheInfos(params, data => {
          if (data.respData.respCode === "0000") {
            const result = data.respData || {}
            console.log(result, Number(result.value) + 1, ' -');

            this.UpdateCacheInfos(id, Number(result.value) + 1 || 0)
            resolve(result)
          } else {
            this.$message.error(data.respData.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },

    /**
     * 存储登录计数
     */
    UpdateCacheInfos(id, count, key) {
      let params = {
        userCaches: [{
          targetId: id || '',
          key: key || 'USER_LOGIN_COUNT' || '',
          value: count || 0,
        }]
      };

      InterfaceService.UpdateCacheInfos(params, data => {
        if (data.respData.respCode === "0000") {
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      });
    },
    handleClick(e) {
      let ev = e || window.event;
      let oLi = ev.srcElement || ev.target;

      if (oLi.className == 'blue hand') {
        this.$router.push(this.msgGoPath);
        this.fireKeyEvent(document.querySelector("body"), 'keydown', 27)
      }
    },
    callMsgListData(isRead, pageIndex, messageType) {
      let params = {
        isRead: 0,
        pageIndex: 1,
        pageSize: 3,
        messageType: 'normal',
        messageParentClass: '01'
      }
      InterfaceService.getSysMsgList(
        params,
        data => {
          // let msgList;
          if (null == data.respData.msgList) {
            this.unreadList = [];//置空
            // return;
          } else {
            this.unreadList = data.respData.msgList
          }
          // this.msgList = data.respData.msgList;
          // this.$store.commit("setSysMsgInfoList", msgList);
          // this.$store.commit("setSysMsgInfo", data.respData.totalUnreadNums);
          let info = {
            unreadList: this.unreadList,
            unreadNum: +data.respData.totalUnreadNums || 0,
          };
          this.$setRootScope('watchUnreadInfo', JSON.stringify(info));
          // this.unreadNum = +data.respData.totalUnreadNums || 0
          // this.$setRootScope("setSysMsgInfoList", JSON.stringify(this.unreadList));
          // this.$setRootScope("setSysMsgInfo", data.respData.totalUnreadNums)
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    }
  },
  watch: {
    loginWrapInner(val) {
      this.loginWrapInner = val
    },
    checked(val) {
      if (val) {
        this.$setCookie('account', this.usernameModel, 365)
      } else {
        this.$setCookie('account', '', 365)
      }
    },
    checkedPwd(val) {
      if (val) {
        this.$setCookie('accountPwd', this.passwordModel, 365)
      } else {
        this.$setCookie('accountPwd', '', 365)
      }
    }
  },
  mounted() {
    this.init();
  },
  created() {
    //console.log(this.$getConfig().STATICS_CDN_URL);

    //this.bgVideoUrl = this.$getConfig().STATICS_CDN_URL + "static/media/loginBg.19b5ee7.mp4";

    this.isIE = this.$isIE()

  }
}
</script>

<style scoped lang="scss">
.change-account {
  /deep/ .el-radio-group {
    width: 100%;
    padding-left: 4%;
  }
  /deep/ .el-radio {
    line-height: 30px;
    width: 100%;
    text-align: left;
  }
  /deep/ .el-radio + .el-radio {
    margin-left: 0;
  }

  .change-account-btns {
    padding-top: 25px;
  }
  /deep/ .el-radio__inner {
    border-radius: 2px;
  }
  /deep/ .el-radio__inner::after {
    display: none;
  }
  /deep/ .el-radio__inner::before {
    box-sizing: content-box;
    content: "";
    border: 1px solid #fff;
    border-left: 0;
    border-top: 0;
    height: 7px;
    left: 4px;
    position: absolute;
    top: 1px;
    transform: rotate(45deg) scaleY(0);
    width: 3px;
    transition: transform 0.15s ease-in 0.05s;
    transform-origin: center;
    transform: rotate(45deg) scaleY(1);
  }
}
/deep/ .el-radio__input.is-checked .el-radio__inner {
  background: #c99f4f !important;
}
.login-wrap {
  .search-bar-container {
    height: 100%;
    padding-top: 15px;
  }
}

.login-wrap-inner {
  min-height: 1000px;
  position: relative;
  overflow: hidden;
  text-align: center;
  // height: 665px;
  // background: url(../../assets/images/login_bg.jpg) no-repeat;
  // background-size: 100% 100%;
  border-top: 2px solid #c99f4f;
  background: -webkit-linear-gradient(
    left,
    #0a0406,
    #080201
  ); /* Safari 5.1 - 6.0 */
  background: -o-linear-gradient(
    right,
    #0a0406,
    #080201
  ); /* Opera 11.1 - 12.0 */
  background: -moz-linear-gradient(
    right,
    #0a0406,
    #080201
  ); /* Firefox 3.6 - 15 */
  background: linear-gradient(to right, #0a0406, #080201); /* 标准的语法 */
}

.login-wrap .contain {
  position: relative;
  height: 100%;
}

.login-wrap {
  .form {
    width: 500px;
    height: 460px;
    position: absolute;
    right: 0;
    top: 30%;
    margin-top: -150px;
    text-align: left;
    border-radius: 30px;
    /*background: rgba(44,46,94,.7);*/
    padding: 55px 60px 65px;
    .login-title {
      /*letter-spacing: 6px;*/
      font-size: 16px;
      margin-bottom: 15px;
      text-align: center;
      color: #fff;
      & > ul {
        height: 60px;
        & > li {
          float: left;
          height: 60px;
          font-size: 16px;
          color: #fff;
          width: 190px;
          text-align: center;
          cursor: pointer;
          position: relative;
          transition: all 0.3s linear;
          line-height: 60px;
          &:hover,
          &.active {
            &::after {
              width: 50px;
            }
            & > span {
              color: #eec676;
              background-image: -webkit-gradient(
                linear,
                0 0,
                0 bottom,
                from(#fae4af),
                to(#b08a44)
              );
            }
            .down-list {
              max-height: 300px;
              opacity: 1;
              z-index: 10;
            }
          }
          &::after {
            content: "";
            width: 0;
            height: 2px;
            border-radius: 2px;
            background: #c99f4f;
            position: absolute;
            bottom: 4px;
            left: 50%;
            transform: translate(-50%, 0);
            transition: all 0.3s linear;
          }
          & > span {
            transition: all 0.3s linear;
            font-weight: bold;
            /*font-family: "微软雅黑";*/
            color: #fff;
            background-image: -webkit-gradient(
              linear,
              0 0,
              0 bottom,
              from(#fff),
              to(#fff)
            );
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
          }
          .down-list {
            background: #313131;
            margin-top: -3px;
            max-height: 0;
            opacity: 1;
            overflow: hidden;
            transition: all 0.3s linear;
            li {
              &:hover {
                background: #1c1c21;
              }
            }
          }
        }
      }
    }
  }
}

.login-wrap {
  .form {
    .errorMsg {
      width: 100%;
      // height: 34px;
      background-color: #ffdfe0;
      // border: 1px solid #e83440;
      line-height: 20px;
      font-size: 14px;
      color: #e8323e;
      margin-bottom: 14px;
      position: relative;
      padding: 10px 10px 10px 35px;

      img {
        position: absolute;
        top: 12px;
        left: 12px;
      }
    }
  }
}

.login-wrap {
  .form {
    .fo-1 {
      input {
        width: 100%;
        height: 48px;
        line-height: 48px;
        border: 1px solid #ddd;
        font-size: 18px;
        text-indent: 20px;
      }
    }
  }
}

.login-wrap {
  .form {
    .fo-1 {
      input:last-child {
        margin-top: 30px;
        line-height: 50px;
        font-size: 16px;
      }
    }
  }
}

.login-wrap {
  .form {
    .fo-4 {
      width: 100%;
      height: 48px;
      line-height: 48px;
      margin-top: 30px;
    }
  }
}

.login-wrap {
  .form {
    .fo-2 {
      height: 20px;
      margin-top: 14px;
      color: #c3c5c9;
      line-height: 20px;
    }
  }
}

.login-wrap .form .fo-2 .left {
  float: left;
}
/deep/ .el-checkbox__label {
  padding-left: 6px;
  color: #fff;
}
/deep/ .el-checkbox {
  margin-right: 10px;
}
/deep/ .el-checkbox__inner {
  background: rgba(255, 255, 255, 0.7);
}
/deep/ .el-checkbox__input.is-checked .el-checkbox__inner {
  background: linear-gradient(
    120deg,
    rgba(215, 176, 100, 0.7) 0%,
    rgba(236, 206, 139, 0.7) 100%
  );
}
.login-wrap .form .fo-2 .left span {
  vertical-align: middle;
  color: #fff;
}

.login-wrap .form .fo-2 .right {
  float: right;
  color: #fff;
}

.login-wrap .form .button {
  position: absolute;
  right: 0;
  left: 0;
  height: 54px;
  text-align: center;
  width: 100%;
}
.login-wrap .form .button:hover {
  background: linear-gradient(
    120deg,
    rgba(215, 176, 100, 1) 0%,
    rgba(236, 206, 139, 1) 100%
  );
}
.login-wrap .form .button {
  font-weight: bold;
  letter-spacing: 6px;
  /*text-shadow: 0 3px 0 #967a47;*/
  font-size: 18px;
}
.login-wrap .form .button span {
  font-size: 20px;
}

.fo-4 {
  /deep/ .el-input__inner {
    width: 240px;
    height: 48px;
    background: rgba(0, 0, 0, 0.1);
    color: #fff;
  }
}

.user-modal {
  /deep/ .el-input__inner {
    width: 100%;
    height: 48px;
    background-color: rgba(0, 0, 0, 0.1);
    background-image: url("../../assets/images/login/user.png");
    background-repeat: no-repeat;
    background-position: 8px center;
    color: #fff;
    padding-left: 40px;
  }
  .pass-word {
    /deep/ .el-input__inner {
      background-image: url("../../assets/images/login/password.png");
    }
  }
  .message-login {
    width: 255px;
    /deep/ .el-input__inner {
      border-right: none;
    }
  }
  .message-login-btn {
    /deep/ .el-button {
      position: absolute;
      right: 0;
      width: 130px;
      height: 50px;
      padding: 0;
    }
  }
}
/deep/ .app-header.white-bg {
  position: absolute;
  z-index: 11;
}
/deep/ .app-search-bar {
  top: 34px;
  position: absolute;
  z-index: 10;
  border-bottom: 2px solid #c99f4f;
}
.btn-custom-confirm {
  width: auto !important;
}
.loginVideo {
  position: absolute;
  left: -38px;
  top: -50px;
}
</style>