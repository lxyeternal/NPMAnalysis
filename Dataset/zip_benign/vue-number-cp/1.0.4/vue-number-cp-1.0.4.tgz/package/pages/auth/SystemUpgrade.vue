<template>
  <div class="systemUpgrade">
    <Header :showLoginOpint="false" :is-white-bg="true"></Header>
    <search-bar></search-bar>
    <div class="center">
      <img src="../../assets/images/systemUpgrade.png" alt="" />
    </div>
  </div>
</template>
<script>
import SearchBar from '@/components/SearchBar'
import Header from '@/components/base/Header'
export default {
  components: {
    SearchBar,
    Header,
  },
}
</script>

<style lang="scss" scoped>
.systemUpgrade {
  .center {
    position: relative;
    height: 714px;
    img {
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
    }
  }
}
</style>