<template>
  <div>
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" :progress="'申请电子印章'" :is-border-bottom="true" :product-create-process="2"></SearchBar>
    <div class="inner-container">
      <div class="header">
        <ul>
          <li class="active">{{!isDoesItExist && !isPersonalExistence ? '创建' : ''}}电子印章</li>
        </ul>
      </div>
      <div class="order-info-title">签章类型</div>
      <span style="margin-right: 5px;"><i class="red">*</i>签章类型</span>
      <el-select :disabled="hasSelected" filterable v-model="selectedIndex" placeholder="请选择签章类型" @change="handleChangeRSealType">
        <el-option v-for="(seal,index) in sealKindList" :key="index" :label="seal.sealKindName" :value="index"></el-option>
      </el-select>
      <div class="dashed-line">
        <p class="mb20">
          <template v-if="isDoesItExist">
            如待审核信息需要变更，请联系大家采平台客服<template v-if="groupCompanyCode != 'GREENLANDHK'">{{$platformContact().hotLineTime}}</template>。
          </template>
          <template v-else>
            电子印章一经创建无法自行修改，请慎重对待。如印章影响电子合同签署，请联系大家采平台客服解决遇到的问题<template v-if="groupCompanyCode != 'GREENLANDHK'">{{$platformContact().hotLineTime}}</template>。
          </template>
          <!--<a class="hand blue" @click="handleSendEmail">去发邮件</a>-->
          <!--<a class="hand blue send-email" @click="handleCopyEmail" :data-clipboard-text="$platformContact()['email']">复制Email地址</a>-->
        </p>
        <div v-if="['1', '2'].includes(selectedSealType)">
          <div class="company-seal-content">
            <el-row :gutter="10">
              <el-col :span="14">
                <el-form :model="changeSealParams" label-width="125px" label-position="left">
                  <el-form-item label="企业名称：" prop="mainText">
                    <el-input v-model="changeSealParams.mainText" :disabled="true"></el-input>
                  </el-form-item>
                  <el-form-item label="印章横向文内容：">
                    <el-input ref="warning" :disabled="isDoesItExist" v-model="changeSealParams.hText" @change="handleInputChange" clearable :placeholder="hPlaceholder" :maxlength="8">

                    </el-input>
                  </el-form-item>
                  <el-form-item label="印章下弦文内容：">
                    <el-input :disabled="isDoesItExist" v-model="changeSealParams.qText" clearable @change="handleInputChange" :placeholder="qPlaceholder" :maxlength="20">
                    </el-input>
                  </el-form-item>
                </el-form>
                <div style="width: 100%;text-align: center" v-if="!isDoesItExist">
                  <el-button style="width: 120px;" @click="contractSealFun('refresh')">
                    生成预览
                  </el-button>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="preview-seal">
                  <div class="preview-seal-content" :class="{'seal-selected':compTextChange}">
                    <img v-if="changeSealData" :src="changeSealData? ('data:image/jpeg;base64,'+changeSealData):''">
                    <div style="width: 100%;height: 100%;" v-else></div>
                  </div>
                  <label style="color: #000;">印章预览</label>
                </div>
              </el-col>
            </el-row>
          </div>
        </div>
        <div v-else>
          <div class="personal-input-container" v-if="!isDoesItExist">
            <div class="personal-center">
              <div class="left">
                <span><i class="red">*</i>{{selectedSealType == '3'? '法' : selectedSealType == '4' ? '本' : '被授权'}}人姓名</span>
                <el-input clearable :disabled="isPersonalExistence" :maxlength="10" @change="handleInputChange" v-model="changeSealParams.acctName"></el-input>
              </div>
              <div class="left">
                <span><i class="red">*</i>{{selectedSealType == '3'? '法' : selectedSealType == '4' ? '本' : '被授权'}}人身份证</span>
                <el-input clearable :disabled="isPersonalExistence" :maxlength="20" @change="handleInputChange" type="text" v-model="changeSealParams.certNo" />
              </div>
            </div>
            <div class="personal-center float-right" v-if="!isPersonalExistence">
              <el-button style="width: 120px;" :size="'mini'" @click="contractSealFun('refresh')">
                生成预览
              </el-button>
            </div>
          </div>
          <div class="preview-seal">
            <div class="preview-seal-content" :class="{'seal-selected':compTextChange}">
              <img v-if="changeSealData" :src="changeSealData? ('data:image/jpeg;base64,'+changeSealData):''">
              <div style="width: 100%;height: 100%;" v-else></div>
            </div>
            <label style="color: #000;">印章预览</label>
          </div>
        </div>
      </div>
      <p class="line"></p>
      <template v-if="selectedSealType != '4'">
        <div class="order-info-title">
          <span>授权日期</span>
        </div>
        <el-row class="print-date">
          <el-col :span="12">
            <span><i class="red" v-if="(!isDoesItExist || isViewHistory) || supplementaryAuthorization">*</i>开始日期：</span>
            <el-date-picker v-if="(!isDoesItExist || isViewHistory) || supplementaryAuthorization" :picker-options="pickerOptionsStart" type="date" placeholder="请选择日期" value-format="yyyy-MM-dd" v-model="changeSealParams.effectiveStartdate" style="width: 250px;"></el-date-picker>
            <span v-else>{{changeSealParams.effectiveStartdateOld}}</span>
          </el-col>
          <el-col :span="12">
            <span><i class="red" v-if="(!isDoesItExist || isViewHistory) || supplementaryAuthorization">*</i>结束日期：</span>
            <el-date-picker type="date" v-if="(!isDoesItExist || isViewHistory) || supplementaryAuthorization" :picker-options="pickerOptionsEnd" placeholder="请选择日期" value-format="yyyy-MM-dd" v-model="changeSealParams.effectiveEnddate" style="width: 250px;"></el-date-picker>
            <span v-else>{{changeSealParams.effectiveEnddateOld}}</span>
          </el-col>
        </el-row>
      </template>

      <div class="order-info-title" v-if="selectedSealType != '4'">
        <span>用印人员</span>
        <span class="blue hand" v-if="isDoesItExist" @click="handleLookHistory">查看授权履历</span>
      </div>
      <template v-if="(!isDoesItExist || isViewHistory) && !supplementaryAuthorization">
        <el-row class="upload-cont" v-if="selectedSealType != '4'">
          <el-col :span="6" class="dis-fix">
            <span style="margin-right: 5px;"><i class="red">*</i>用印人员：</span>
            <el-select clearable filterable v-model="sealPerson" placeholder="请选择用印人员" @change="handleChangeSealPerson">
              <el-option v-for="(seal,index) in personList.filter(f=> f.acctId !== activePrintAccId)" :key="index" :label="seal.acctName" :value="seal.acctId"></el-option>
            </el-select>
          </el-col>
          <el-col :span="18">
            <ul class="neet-upload-upfile">
              <li>
                <p class="input-file-p">
                  <span :class="{gray: !uploadFileName}">
                    {{uploadFileName || '请上传该用印人员使用印章授权书'}}
                  </span>
                </p>
              </li>
              <li>
                <UpfileComponent ref="upfileRef" :immediateClearList="false" :immediateSubmit="false" :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :btnName="'选择文件'" :dirName="`${new Date().getTime()}/`" :type="'13'" :fileTypes="this.uploadFileSuffix" :id="'123'" @outputList="handleUpFileResult($event)"></UpfileComponent>
              </li>
              <el-button type="primary" @click.native="submitUpfile">
                上传
              </el-button>
              <el-button @click="handleDownTemp()" class="download-btn">下载授权书模板</el-button>
            </ul>
          </el-col>
        </el-row>
        <div class="upload-cont" v-if="selectedSealType != '4'">
          <div class="upload-title">
            <span>
              已上传文本
            </span>
            <span>
              上传时间
            </span>
            <span>
              操作
            </span>
          </div>
          <div class="upload-title tl" v-if="authorizationInfo.attachName">
            <span>
              {{authorizationInfo.attachName}}
            </span>
            <span>
              {{authorizationInfo.creTm}}
            </span>
            <span>
              <i class="hand blue" @click="delFileInfo">删除</i>
            </span>
          </div>
        </div>
        <template v-if="groupCompanyCode != 'GREENLANDHK'">
          <p class="red" style="line-height: 17px;" v-if="selectedSealType == '1' || selectedSealType == '2'">请上传用印人员在大家采电商平台使用电子印章的授权书、受托人劳动合同的PDF扫描件。
          </p>
          <p class="red" style="line-height: 17px;" v-if="selectedSealType == '3' || selectedSealType == '5'">请上传用印人员在大家采电商平台使用电子印章的授权书、委托人劳动合同、受托人劳动合同的PDF扫描件。
          </p>
        </template>
        <template v-else>
          <p class="red" style="line-height: 17px;" v-if="selectedSealType == '1' || selectedSealType == '2'">请上传用印人员在大家采电商平台使用电子印章的授权书、OA系统受托人的“人员卡片”截图
          </p>
          <p class="red" style="line-height: 17px;" v-if="selectedSealType == '3' || selectedSealType == '5'">请上传用印人员在大家采电商平台使用电子印章的授权书、OA系统委托人的“人员卡片”截图、OA系统受托人的“人员卡片”截图。
          </p>
          <p class="red" v-if="selectedSealType !== '4'" style="line-height: 17px;">
            <span class="red">注：<br>
              1、 授权书模板请点击【下载授权书模板】下载，填写并加盖公章（两页以上加盖骑缝章）。<br>
              2、 获取“人员卡片”方式：登录OA系统，输入姓名搜索，即可查询。<br>
              <br>
              如有疑问，请联系大家采平台客服：<br>
              {{$platformContact().hotLine}}{{$platformContact().hotLineTime}}<br>
            </span>
          </p>
        </template>
      </template>
      <template v-else-if="!supplementaryAuthorization">
        <el-row>
          <el-col :span="12">
            <span>用印人员:</span>
            <span v-if="searchPersonBySealPerson.acctName || searchPersonBySealPerson.dept || searchPersonBySealPerson.mobile">
              &emsp;
              {{searchPersonBySealPerson.acctName || ''}}
              &emsp;
              {{searchPersonBySealPerson.dept || ''}}
              &emsp;
              {{searchPersonBySealPerson.mobile || ''}}
            </span>
            <span v-else>-</span>
          </el-col>
          <el-col :span="12">
            <span>授权书:</span>
            <span class="ml12">{{authorizationInfo.attachName}}</span>
            <span class="ml12 blue hand" :class="{gray: !authorizationInfo.attachName}" @click="authorizationInfo.attachName && handleView(authorizationInfo)">查看</span>
            <span class="ml12 blue hand" :class="{gray: !authorizationInfo.attachName}" @click="authorizationInfo.attachName && handleDownload(authorizationInfo)">下载</span>
          </el-col>
        </el-row>
      </template>

      <!-- 补交授权书 -->
      <template v-if="(!isDoesItExist || isViewHistory) && supplementaryAuthorization">
        <el-row class="upload-cont" v-if="selectedSealType != '4'">
          <el-col :span="6">
            <span style="margin-right: 5px;">用印人员：</span>
            <span style="margin-top: 12px; display: inline-block;" v-if="searchPersonBySealPerson.acctName">
              &emsp;
              {{searchPersonBySealPerson.acctName || ''}}
            </span>
            <span v-else>-</span>
          </el-col>
          <el-col :span="18">
            <ul class="neet-upload-upfile">
              <li>
                <p class="input-file-p">
                  <span :class="{gray: !uploadFileName}">
                    {{uploadFileName || '请上传该用印人员使用印章授权书'}}
                  </span>
                </p>
              </li>
              <li>
                <UpfileComponent ref="upfileRef" :immediateClearList="false" :immediateSubmit="false" :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :btnName="'选择文件'" :dirName="`${new Date().getTime()}/`" :type="'13'" :fileTypes="this.uploadFileSuffix" :id="'123'" @outputList="handleUpFileResult($event)"></UpfileComponent>
              </li>
              <el-button type="primary" @click.native="submitUpfile">
                上传
              </el-button>
              <el-button @click="handleDownTemp()" class="download-btn">下载授权书模板</el-button>
            </ul>
          </el-col>
        </el-row>
        <div class="upload-cont" v-if="selectedSealType != '4'">
          <div class="upload-title">
            <span>
              已上传文本
            </span>
            <span>
              上传时间
            </span>
            <span>
              操作
            </span>
          </div>
          <div class="upload-title tl" v-if="authorizationInfo.attachName">
            <span>
              {{authorizationInfo.attachName}}
            </span>
            <span>
              {{authorizationInfo.creTm}}
            </span>
            <span>
              <i class="hand blue" @click="delFileInfo">删除</i>
            </span>
          </div>
        </div>
        <template v-if="groupCompanyCode != 'GREENLANDHK'">
          <p class="red" style="line-height: 17px;" v-if="selectedSealType == '1' || selectedSealType == '2'">请上传用印人员在大家采电商平台使用电子印章的授权书、受托人劳动合同的PDF扫描件。
          </p>
          <p class="red" style="line-height: 17px;" v-if="selectedSealType == '3' || selectedSealType == '5'">请上传用印人员在大家采电商平台使用电子印章的授权书、委托人劳动合同、受托人劳动合同的PDF扫描件。
          </p>
        </template>
        <template v-else>
          <p class="red" style="line-height: 17px;" v-if="selectedSealType == '1' || selectedSealType == '2'">请上传用印人员在大家采电商平台使用电子印章的授权书、OA系统受托人的“人员卡片”截图
          </p>
          <p class="red" style="line-height: 17px;" v-if="selectedSealType == '3' || selectedSealType == '5'">请上传用印人员在大家采电商平台使用电子印章的授权书、OA系统委托人的“人员卡片”截图、OA系统受托人的“人员卡片”截图。
          </p>
          <p class="red" v-if="selectedSealType !== '4'" style="line-height: 17px;">
            <span class="red">注：<br>
              1、 授权书模板请点击【下载授权书模板】下载，填写并加盖公章（两页以上加盖骑缝章）。<br>
              2、 获取“人员卡片”方式：登录OA系统，输入姓名搜索，即可查询。<br>
              <br>
              如有疑问，请联系大家采平台客服：<br>
              {{$platformContact().hotLine}}{{$platformContact().hotLineTime}}<br>
            </span>
          </p>
        </template>

      </template>

      <el-dialog class="dialog" title="郑重声明" :append-to-body="true" :lock-scroll="true" :visible.sync="confirmDialogVisible" width="840px" center :close-on-click-modal="false">
        <div class="tl confirm-dialog">
          <p>1、本公司已核对信息的完全真实，且愿意承担由于信息虚假失实而导致的一切后果。</p>
          <p>2、本公司：{{changeSealParams.mainText}}当前申请电子印章，签章类型为
            <em class="red">
              {{selectedSealName}}
            </em>
            ，
            <em class="red" v-if="selectedSealType === '3'">
              确认经过法人{{changeSealParams.acctName || ''}}授权给{{searchPersonBySealPersonNew.acctName || ''}}
            </em>
            <span v-if="selectedSealType === '3'">，</span>
            已确认申请信息无误，且知晓点击【确认提交】后不可编辑。</p>
          <div class="check">
            <el-checkbox v-model="selectChecked" @change="handleSelectChecked"><em class="black bold">我已认真阅读以上声明，并同意以上声明所述内容。</em></el-checkbox>
          </div>
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button :disabled="!selectChecked" type="primary" @click="projectSeal('confirm')">确认提交</el-button>
          <el-button @click="handleCancelReplce">取消</el-button>
        </div>
      </el-dialog>

      <el-dialog class="dialog history-resume-dialog" title="历史履历" :append-to-body="true" :lock-scroll="true" :visible.sync="lookHistoryDialog" width="840px" center :close-on-click-modal="false">
        <div class="tl confirm-dialog">
          <!-- 列表 -->
          <table class="history-dialog-table">
            <thead>
              <tr class="tc">
                <td width="120">印章类型</td>
                <td>用印人员</td>
                <td width="200">授权时间</td>
                <td>创建时间</td>
                <td>状态</td>
                <td width="100">操作</td>
              </tr>
            </thead>
            <template v-if="sealList && sealList.length">
              <tbody v-for="(seal,index) in sealList" :key="index" class="tc tbody-row">
                <tr>
                  <td>
                    {{seal.sealName || seal.sealKindName}}
                  </td>
                  <td>
                    {{seal.sealAcctName}}
                  </td>
                  <td>
                    {{seal.effectiveStartdate || ''}} ~ {{seal.effectiveEnddate || ''}}
                  </td>
                  <td>
                    {{seal.creTm}}
                  </td>
                  <td>
                    {{seal.sealStatusName}}
                  </td>
                  <td class="opreate" align="right">
                    <div v-if="!['rejected', 'canceled'].includes(seal.sealStatus)">
                      <span class="blue hand" @click="handleView(seal)">查看</span>
                      <span class="ml12 blue hand" @click="handleDownload(seal)">下载</span>
                    </div>
                    <div v-else>-</div>
                  </td>
                </tr>
                <tr v-if="seal.sealStatus === 'rejected' && seal.approveMsg">
                  <td colspan="5" class="p0">
                    <p class="reject_notice">
                      <span>申请失败原因：</span>
                      <span>{{seal.approveMsg}}</span>
                    </p>
                  </td>
                </tr>
              </tbody>
            </template>

            <template v-else>
              <tr>
                <td colspan="5">
                  <p class="txt-center">暂无数据</p>
                </td>
              </tr>
            </template>
          </table>
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button @click="lookHistoryDialog = false">关闭</el-button>
        </div>
      </el-dialog>

      <FixBottom v-if="!isPersonalExistence">
        <div class="fix-bottom" v-if="isDoesItExist && !isViewHistory && !supplementaryAuthorization">
          <el-button @click="handleviewHistory" type="primary" :disabled="isApproving" style="width: 160px;">
            {{isApproving ? '审核中' : '替换用印人员'}}
          </el-button>
          <el-button v-if="['0', '1', '3'].includes(sealDataItem.expireFlg) && sealDataItem.sealStatus == 'approved' && sealDataItem.authorityAcctId" @click="handleSupplementaryAuthorization" style="width: 160px;">
            补交授权书
          </el-button>
        </div>
        <div class="fix-bottom" v-else>
          <el-button :disabled="!selectedSealType" type="primary" style="width: 160px;" @click="submit()">提交{{selectedSealType == '4'? '' : '申请'}}</el-button>
          <el-button v-if="isViewHistory" style="width: 160px;" @click="handleCancelHistory">取消</el-button>
        </div>
      </FixBottom>
      <Loading :is-loading="isLoading"></Loading>
    </div>
  </div>
</template>

<script>
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
import Loading from "@/components/base/Loading";
import FixBottom from "@/components/base/FixBottom";
import { InterfaceService } from "@/services/api";
import ClipBoard from "clipboard";
import { resolve } from 'q';
import { viewFile } from '@/utils/orderUtil';
import accountMixin from "@/mixins/account";

const emailMap = {
  "@163.com": "http://mail.163.com",
  "@qq.com": "http://mail.qq.com",
  "@sina.com": "http://mail.sina.com.cn/",
  "@sina.cn": "http://mail.sina.com.cn/"
};
const changeSealParams = {
  esignId: '',
  sealType: '',
  acctType: "2",
  processFlg: '1',
  mainText: '',
  hText: '',
  qText: '',
  sealKind: '',
  sealData: '',
  certNo: '',
  acctName: '',
  // corpId:'CORP2018062800000000000000001674',
  // custId:'CUST2018092900000000013515154352'
  effectiveStartdate: '',
  effectiveEnddate: '',
  effectiveStartdateOld: '',
  effectiveEnddateOld: '',
  authorityFlg: '0', // 授权标志（0：授权用印人员；1：修改授权日期）
};
export default {
  mixins: [accountMixin],
  name: "ApplicationSeal",
  components: {
    Header,
    SearchBar,
    UpfileComponent,
    Loading,
    FixBottom,
  },
  data() {
    return {
      // dddd
      sendinfo: {},
      authorizationInfo: {},
      authorizationInfoBackup: {},
      lookHistoryDialog: false, // 查看历史lvli
      sealList: [],
      contractSealFlag: false,
      uploadFileSuffix: '',
      selectChecked: false, // 是否勾选
      isLoading: false,
      confirmDialogVisible: false,
      confirmSubmit: false,
      createFlg: true,
      textHasChange: false,
      hasSelected: false,
      selectedSealType: "",
      selectedSealName: "",
      selectedSealId: "",
      sealPerson: "",
      changeSealData: '',
      uploadFileList: [],
      corpName: '',
      sealKindObj: {
        corp: '合同专用印章',
        project: '项目专用印章',
        legal: '法人代表章',
        personal: '个人名章',
        authorize: '被授权的个人名章',
        applying: '审核中',
        approved: '审核通过',
        rejected: '审核失败',
        replaced: '替换',
        canceled: '已撤回',
      },
      sealTypeList: [{
        sealId: "1",
        sealName: "合同专用印章",
        sealKind: "corp"
      }, {
        sealId: "2",
        sealName: "项目专用印章",
        sealKind: "project"
      }, {
        sealId: "3",
        sealName: "法人代表章",
        sealKind: "legal"
      }, {
        sealId: "4",
        sealName: "个人名章",
        sealKind: "personal"
      }, {
        sealId: "5",
        sealName: "被授权的个人名章",
        sealKind: "authorize"
      }],
      personList: [],
      authorizationName: "",
      changeSealParams: Object.assign({}, changeSealParams),
      hPlaceholder: "限8个字符",
      qPlaceholder: "限20个字符",
      lastHtext: "",
      lastQtext: "",
      uploadFileName: '',
      sealDataList: [], // 已有用印列表
      isDoesItExist: false, // 是否已有用印
      isViewHistory: false, // 查看授权履历
      isPersonalExistence: false, // 个人名章 是否已创建
      isWhetherPreviewed: false, // 是否预览过
      activePrintAccId: '', // 现授权人ID
      firstSealPerson: '', // 是否第一次选择用印人
      authorizationInfoHistory: {}, // 历史文件信息
      contractSealFunTimer: null,
      accountInfoTimer: null,
      esignSealId: this.$route.query.esignSealId,
      selectedIndex: '',
      sealKindList: [],
      authenticationStatus: false, // 是否实名认证
      supplementaryAuthorization: false, // 补交授权书按钮
      dateOption: {},

      pickerOptionsEnd: {
        disabledDate: time => {
          return time.getTime() <= new Date(this.changeSealParams.effectiveStartdate).getTime() || (time.getTime() < new Date().getTime())
        }
      },
      pickerOptionsStart: {
        disabledDate: time => {
          return this.changeSealParams && this.changeSealParams.effectiveEnddate && time.getTime() >= new Date(this.changeSealParams.effectiveEnddate).getTime()
        }
      },

    }
  },
  computed: {
    // 施工监理
    specialRole() {
      return this.$store.state.userInfo &&
        (this.$store.state.userInfo.contractCorpType == "construction" ||
          this.$store.state.userInfo.contractCorpType == "supervisory")
    },
    // 印章是否在审核中
    isApproving() {
      let result = false
      // 被选中的 印章类型 sealKind
      const typeSelectArr = this.sealTypeList.filter(f => f.sealId == this.selectedSealType) || [],
        typeSelectItem = typeSelectArr[0] || {},
        typeSealKind = typeSelectItem.sealKind || ''

      if (typeSealKind) {
        // 选中的印章类型是否为 审核状态
        result = this.sealDataList && this.sealDataList.some(s => s.sealKind == typeSealKind && s.esignSealId == this.esignSealId && s.sealStatus === 'approving')
      }

      return result
    },

    // 当前用印
    sealDataItem() {
      let item = {}
      // 被选中的 印章类型 sealKind
      const typeSelectArr = this.sealTypeList.filter(f => f.sealId == this.selectedSealType) || [],
        typeSelectItem = typeSelectArr[0] || {},
        typeSealKind = typeSelectItem.sealKind || ''

      this.sealDataList && this.sealDataList.some(s => {
        if (s.sealKind == typeSealKind && s.esignSealId == this.esignSealId) {
          return item = s
        }
      })

      if (this.changeSealParams) {
        this.changeSealParams.effectiveStartdate = item.effectiveStartdate
        this.changeSealParams.effectiveEnddate = item.effectiveEnddate
        this.changeSealParams.effectiveStartdateOld = item.effectiveStartdate
        this.changeSealParams.effectiveEnddateOld = item.effectiveEnddate
      }
      console.log(this.changeSealParams);
      console.log(item, '----item');


      return item || {}
    },
    acctId() {
      return (
        this.$store.state.userInfo && this.$store.state.userInfo.acctId
      );
    },
    email() {
      return (
        this.$store.state.userInfo && this.$store.state.userInfo.email
      );
    },
    compTextChange() {
      // 横向 和 下弦 内容允许为空
      const state = (this.lastHtext == this.changeSealParams.hText || !this.changeSealParams.hText) &&
        (this.lastQtext == this.changeSealParams.qText || !this.changeSealParams.qText) &&
        this.lastAccName == this.changeSealParams.acctName &&
        this.lastCertNo == this.changeSealParams.certNo

      return state
    },
    // 现用印人员
    searchPersonBySealPerson() {
      const addIc = this.activePrintAccId,
        item = this.personList.filter(f => f.acctId === addIc)[0] || {}

      return addIc && item
    },

    // 新用印人员
    searchPersonBySealPersonNew() {
      const addIc = this.sealPerson,
        item = this.personList.filter(f => f.acctId === addIc)[0] || {}

      return addIc && item
    }
  },
  methods: {
    async init() {
      console.log('init');
      this.selectedSealType = this.$route.query.sealType || "1";
      this.selectedSealId = this.$route.query.sealId;
      await this.getSealList()
      this.selectedSealType && this.handleChangeRSealType(this.selectedSealType, 'init');
      this.hasSelected = this.$route.query.hasSelected == "1";
      this.changeSealParams.mainText = this.$route.query.mainText || this.$store.state.userInfo.corpName;
      this.getAccountInfo();
      await this.getOrderConfiguration()
      // 个人不查询 用印人员信息
      if (this.searchSealTypeBySelected().sealKind != 'personal') {

        this.getSubordinateData()
      }
      this.errorRules = {}
      this.initSealKind()
      // await this.getSealList()
      this.searchDoesItExist()
      this.dateOption = {
        disabledDate: now => {
          return now.getTime() < new Date().getTime() - 86400000
        }
      };
    },

    handleInputChange() {
      this.isWhetherPreviewed = false
    },

    handleSupplementaryAuthorization() {
      this.supplementaryAuthorization = true
      this.handleviewHistory()
    },

    handleChangeRSealType(ev, initState) {
      this.changeSealParams.effectiveStartdate = ''
      this.changeSealParams.effectiveEnddate = ''
      // console.log('ev', ev, this.sealTypeList.filter(item => {
      //   return item.sealId == ev
      // }))
      // this.selectedSealName = this.sealTypeList.filter(item => {
      //   return item.sealId == ev
      // })[0].sealName

      if (this.sealKindList.length > 0) {
        this.setSealType();
      }
      this.initSealKind()
      this.changeSealData = ''
      this.isWhetherPreviewed = false

      // 非 初始化 才处理
      !initState && this.searchDoesItExist()
    },

    handleChangeSealPerson(e) {
      if (this.firstSealPerson) {
        this.$refs.upfileRef.clearAttachList()
        this.authorizationInfoBackup = {}
        this.authorizationInfo = {}
        this.uploadFileName = ''
      }
      this.firstSealPerson = this.sealPerson
    },

    // 上传附件
    submitUpfile() {
      if (!this.authorizationInfoBackup.file) {
        this.$message.error('请先选择文件')
        return
      }
      this.$refs.upfileRef.handleConfim([this.authorizationInfoBackup]).then(e => {
        this.uploadFileName = ''
        this.authorizationInfoBackup = {}
      })
    },

    /**
     * 查看历史履历
     */
    handleviewHistory() {
      this.isViewHistory = true
      this.authorizationInfoBackup = {}
      this.authorizationInfoHistory = this.$clone(this.authorizationInfo)
      this.authorizationInfo = {}
      this.firstSealPerson = ''
    },

    /**
     * 取消替换
     */
    handleCancelHistory() {
      this.authorizationInfo = this.authorizationInfoHistory
      this.sealPerson = ''
      this.authorizationInfoBackup = {}
      this.uploadFileName = ''
      this.isViewHistory = false
      this.supplementaryAuthorization = false
    },

    // 发送邮件
    handleSendEmail() {
      let valid = false;
      let email = this.email.split("@")[1];
      email = "@" + email;
      Object.keys(emailMap).forEach(key => {
        let reg = new RegExp(key, "i");
        if (reg.test(email)) {
          valid = true;
          window.open(emailMap[key]);
        }
      });

      if (!valid) {
        this.$message.info(
          "未匹配到相应邮件网站，请打开邮件客户端发送邮件"
        );
      }
    },

    handleView(item) {
      if (item.attachUrl) {
        viewFile(item.attachUrl)
      }
    },

    handleDownload(item) {
      item.name = item.attachName
      item.url = item.attachUrl
      this.$download([item]).then(e => {
        this.$message.success('下载成功')
      })
    },

    // 复制email
    handleCopyEmail() {
      const clipboard = new ClipBoard(".send-email");
      clipboard.on("success", e => {
        this.$message.success("已复制");
        clipboard.destroy();
      });
      clipboard.on("error", e => {
        this.$message.error("该浏览器不支持复制");
        clipboard.destroy();
      });
    },
    getOrderConfiguration() {
      return new Promise(resolve => {
        const params = {
          businessType: 'SEAL'
        };
        InterfaceService.getOrderConfiguration(params, data => {
          let res = data.respData;
          if (res.respCode === "0000") {
            this.uploadFileList = res.uploadFileList || [];
            resolve(this.uploadFileList)
          } else {
            this.$message.error(data.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },

    /**
     * 设置对应下载末班
     */
    setDownloadSealKind() {
      const sealKind = this.searchSealTypeBySelected() && this.searchSealTypeBySelected().sealKind || ''
      this.uploadFileList.forEach(item => {
        if (item.fileTypeId === sealKind) {
          this.templateFileUrl = item.attachUrl || "";
          this.templateFileName = item.templateFileName || "";
          this.uploadFileSuffix = item.uploadFileSuffix || "";
        }
      })
    },

    delFileInfo() {
      if (this.authorizationInfo.id) {
        this.delImgList.push({ attachId: this.authorizationInfo.id });
      }
      this.authorizationInfo = {};
    },
    handleUpFileResult(e) {
      if (e && e.length > 1) {
        e.shift()
      }
      this.authorizationInfoBackup = e[0]
      const { file, name, targetValue, url } = e[0]
      // 上传成功后才赋值 已上传文件信息
      if (url) {
        this.authorizationInfo = {
          file: file,
          attachName: name,
          creTm: this.dateFormat("YYYY-mm-dd HH:MM", new Date()),
          targetValue,
          attachUrl: url
        }
      }

      this.uploadFileName = name
    },
    handleLookHistory() {
      this.searchSealApplicationList()
      this.lookHistoryDialog = true
    },

    searchSealApplicationList() {

      let i = this.sealDataList.findIndex(s => { return s.esignSealId == this.esignSealId })
      let params = {
        sealId: this.sealDataList[i].sealId,
        sealKind: this.changeSealParams.sealKind,
        sealStatus: ""
      };
      try {
        params.corpId = this.$store.state.userInfo.corpId
      } catch (error) {
        console.error(error)
      }
      InterfaceService.searchSealApplicationList(params, data => {
        if (data.respCode === "0000") {
          if (data.respData.respCode == "0000") {
            this.sealList = data.respData.sealApproveList || [];
          } else {
            this.$message.error(data.respData.respMsg);
          }
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    dateFormat(fmt, date) {
      let ret;
      const opt = {
        "Y+": date.getFullYear().toString(),        // 年
        "m+": (date.getMonth() + 1).toString(),     // 月
        "d+": date.getDate().toString(),            // 日
        "H+": date.getHours().toString(),           // 时
        "M+": date.getMinutes().toString(),         // 分
        "S+": date.getSeconds().toString()          // 秒
      };
      for (let k in opt) {
        ret = new RegExp("(" + k + ")").exec(fmt);
        if (ret) {
          fmt = fmt.replace(ret[1], (ret[1].length == 1) ? (opt[k]) : (opt[k].padStart(ret[1].length, "0")))
        }
      }
      return fmt;
    },

    // 下载附件
    handleDownTemp() {
      this.$download([{
        name: this.templateFileName || '',
        url: this.templateFileUrl || ''
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    // 查询公司下属账户信息 xxxx   返回绑定数据 this.sealPerson
    getSubordinateData() {
      this.signUserinfo = this.$store.state.userInfo
      const params = {
        acctStatus: this.signUserinfo.acctStatus,
        corpId: this.$route.query.propCorpId || undefined,
        pageIndex: '',

      }
      InterfaceService.getQuerySubordinate(params, (data) => {
        if (data.respCode === "0000") {
          this.personList = data.respData.acctList || [];
        } else {
          this.$message.error(data.respMsg);
        }
      },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        });
    },
    getCropId() {
      InterfaceService.registerGetCropId({}, (data) => { },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },

    /**
    * 实名认证
    */
    certify() {
      return new Promise(resolve => {
        const params = {
          acctType: '1',
          name: this.changeSealParams && this.changeSealParams.acctName || '',
          certType: this.signUserinfo && this.signUserinfo.certType || '01',
          certNo: this.changeSealParams && this.changeSealParams.certNo || '',
        }
        InterfaceService.certifyAccount(params, data => {
          let res = data.respData;
          if (res.respCode === "0000") {
            resolve(data.respData.esignId)
          } else {
            this.$message.error(res && res.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },

    /**
     * 验证输入项
     */
    validationEntry() {
      let state = true
      switch (this.selectedSealType) {
        case '1':
        case '2':
          // if (!this.changeSealParams.hText) {
          //   this.$message.error('请输入印章横向文内容')
          //   state = false
          // }
          // if (state && !this.changeSealParams.qText) {
          //   this.$message.error('请输入印章下弦文内容')
          //   state = false
          // }
          break;
        case '3':
        case '4':
        case '5':
          // 替换用印人 不验证
          if (!this.isDoesItExist) {
            if (!this.changeSealParams.acctName) {
              this.$message.error('请输入姓名')
              state = false
            }
            if (state && !this.changeSealParams.certNo) {
              this.$message.error('请输入身份证号')
              state = false
            }
          }
          break
      }
      return state
    },

    handleCancelReplce() {
      this.confirmDialogVisible = false
      this.supplementaryAuthorization = false
    },

    submit() {
      if (!this.validationEntry()) return

      if (!this.isWhetherPreviewed && !this.isDoesItExist) {
        this.$message.error('请先点击生成预览印章')
        return
      }

      if (this.selectedSealType === "4") {
        this.$confirm(
          "您申请的电子印章类型为<em class='red'>个人名章</em>, 已确认申请信息无误，且知晓点击【确认提交】后不可编辑。",
          "确认提交",
          {
            dangerouslyUseHTMLString: true,
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            confirmButtonText: "确认提交",
            cancelButtonText: '取消',
          }).then(() => {
            this.projectSeal('confirm')
          }).catch(() => {
          });
      } else {
        if ((!this.isDoesItExist || this.isViewHistory) || this.supplementaryAuthorization) {
          if (!this.changeSealParams.effectiveStartdate) {
            this.$message.error('请选择授权开始日期')
            return
          }
          if (!this.changeSealParams.effectiveEnddate) {
            this.$message.error('请选择授权结束日期')
            return
          }
        }
        // 不需要 选择用印人员时 默认设置当前显示
        if (!((!this.isDoesItExist || this.isViewHistory) && !this.supplementaryAuthorization)) {
          this.sealPerson = this.searchPersonBySealPerson && this.searchPersonBySealPerson.acctId
        }
        if (!this.sealPerson && !this.supplementaryAuthorization) {
          this.$message.error('请选择用印人员')
          return
        }
        if (!this.authorizationInfo.attachUrl) {
          this.$message.error('请上传授权书')
          return
        }
        this.selectChecked = ''
        if (this.isDoesItExist) {
          this.$confirm(
            "确认替换用印人员信息无误，且与新上传的授权书内容一致。",
            "确认提交",
            {
              dangerouslyUseHTMLString: true,
              cancelButtonClass: "btn-custom-cancel",
              confirmButtonClass: "btn-custom-confirm",
              center: true,
              confirmButtonText: "确认提交",
              cancelButtonText: '取消',
            }).then(() => {
              this.projectSeal('confirm')
            }).catch(() => {
            })
          return
        }
        this.confirmDialogVisible = true
      }

    },

    handleSelectChecked() {
    },

    /**
     * 创建预览合同   项目印章创建55555  this.authorizationInfo
     */
    async projectSeal(type) {
      let esignId = ''
      if (this.selectedSealType == '4') {
        esignId = await this.certify()
        if (!esignId) {
          this.$message.error('未获取到esignId')
          return
        }
        this.changeSealParams.esignId = esignId
      }
      if (type == "refresh") {
        this.changeSealParams.processFlg = "0";
      } else if (type == "confirm") {
        this.changeSealParams.processFlg = "1";
      }

      let params = {
        esignSealId: this.esignSealId,
        sealKind: this.changeSealParams.sealKind,
        acctId: this.sealPerson,
        corpId: this.$route.query.propCorpId || undefined,
        esignId,
        attachName: this.authorizationInfo && this.authorizationInfo.attachName || '',
        attachUrl: this.authorizationInfo && this.authorizationInfo.attachUrl || '',
      };

      // 如果是用印不存在 &&  confirm  赋值 sealDateInfo
      if (!this.isDoesItExist && this.changeSealParams.processFlg == '1') {
        params.sealDateInfo = this.changeSealParams
        params.processFlg = this.changeSealParams.processFlg
      }

      params.effectiveStartdate = this.changeSealParams && this.changeSealParams.effectiveStartdate
      params.effectiveEnddate = this.changeSealParams && this.changeSealParams.effectiveEnddate
      params.authorityFlg = this.supplementaryAuthorization ? '1' : '0'

      console.log(this.sealKindList && this.sealKindList[this.selectedIndex], '-sealKindItem');
      // personal
      const sealKindItem = this.sealKindList && this.sealKindList[this.selectedIndex] || {}
      const API = sealKindItem.sealKind === 'personal' ? 'addPersonalStamp' : 'addStamp'
      InterfaceService[API](params, data => {
        if (data.respCode === "0000") {
          if (data.respData.respCode == "0000") {
            this.$message.success("添加印章成功, 页面将在1秒后关闭")
            setTimeout(e => {
              this.confirmDialogVisible = false
              this.supplementaryAuthorization = false
            }, 1000)
            try {
              // 个人印章 不跳转列表页
              if (this.searchSealTypeBySelected().sealKind != 'personal') {
                this.$setRootLocalStorage('applicationState', '2')
              }
              window.opener && window.opener.location.reload()
              setTimeout(e => {
                window.close()
              }, 1000)
            } catch (error) {
              console.error(error)
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    getAccountInfo() {
      const params = {
        acctId: this.$route.query.propAcctId || this.acctId
      };
      InterfaceService.accountInfo(
        params,
        data => {
          if (data.respCode === "0000") {
            const result = data.respData;
            this.signUserinfo = result;
            this.authenticationStatus = result.authenticationStatus;
            // console.log('isthis', this.signUserinfo);
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },

    // yyyyyyy
    async contractSealFun(type) {  //创建预览合同
      // 个人 时 需查询 esignId
      if (!this.validationEntry()) return
      let esignId = ''
      if (this.selectedSealType == '4') {
        esignId = await this.certify()
        if (!esignId) {
          this.$message.error('未获取到esignId')
          return
        }
        this.changeSealParams.esignId = esignId
      }

      //记录上一次预览时的印章文字
      this.lastHtext = this.changeSealParams.hText
      this.lastQtext = this.changeSealParams.qText
      this.lastAccName = this.changeSealParams.acctName
      this.lastCertNo = this.changeSealParams.certNo

      if (type == "refresh") {
        this.changeSealParams.processFlg = "0";
      } else if (type == "confirm") {
        this.changeSealParams.processFlg = "1";
      }
      let params = { sealDateInfo: Object.assign({}, this.changeSealParams) };
      params.corpId = this.$route.query.propCorpId || undefined

      // 根据不同签章类型 调用不同接口
      const interfaceNameObj = {
        1: 'contractSeal',
        2: 'projectSeal',
        3: 'authorizeSeal',
        4: 'setSeal',
        5: 'authorizeSeal',
      }

      console.log(interfaceNameObj[Number(this.selectedSealType)], 'interfaceNameObj[Number(this.selectedSealType)]');


      InterfaceService[interfaceNameObj[Number(this.selectedSealType)]](params, data => {
        if (data.respCode === "0000") {
          if (data.respData.respCode == "0000") {
            const result = data.respData;
            this.sendinfo.sealData = result.sealDataPreViewList[0].sealData
            this.sendinfo.sealId = result.sealDataPreViewList[0].sealId
            this.sendinfo.sealType = result.sealDataPreViewList[0].sealType
            if (type == "refresh") {
              this.changeSealData = result.sealDataPreViewList[0].sealData
              this.isWhetherPreviewed = true
            }
            if (type == "confirm") {
              this.addCorporateDialogVisible = false;
              this.$message.success("添加印章成功")
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })

    },

    /**
     * 获取印章列表
     */
    getSealList() {
      return new Promise(resolve => {
        let params = {
          corpId: this.$route.query.propCorpId || undefined,
          sealDataType: 3 // 获取公司印章列表参数
        };
        InterfaceService.getSealList(params, data => {
          if (data.respCode === "0000") {
            if (data.respData && data.respData.respCode == "0000") {
              try {
                this.sealDataList = data.respData.sealDataList || [];
                this.sealKindList = data.respData.sealKindList && data.respData.sealKindList.filter(f => { return this.specialRole ? ['project', 'personal'].includes(f.sealKind) : true }) || [];
                this.selectedIndex = this.esignSealId ? this.sealKindList.findIndex(s => { return s.esignSealId == this.esignSealId }) : 0
                this.setSealType();
              } catch (error) {
                console.error(error);
              }
              resolve(true)
            } else {
              this.$message.error(data.respData.respMsg);
            }
          } else {
            this.$message.error(data.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },

    /**
     * 根据 选择项 匹配对应印章类型
     */
    searchSealTypeBySelected() {
      // const arr = this.sealTypeList.filter(f => f.sealId === this.selectedSealType) || []
      const arr = this.sealKindList.filter(f => f.esignSealId === this.esignSealId) || []
      return arr[0] || {}
    },

    /**
     * 查询印章类型是否存在
     */
    searchDoesItExist() {
      if (!this.$route.query.esignSealId) {
        this.esignSealId = this.sealKindList[this.selectedIndex].esignSealId
      }
      this.selectedSealName = this.sealKindList[this.selectedIndex].sealKindName

      const result = this.searchSealTypeBySelected() || {},
        matchArr = this.sealDataList.filter(f => f.esignSealId === result.esignSealId) || [],
        item = matchArr[0] || {},
        { hText, qText, sealData, authorityAcctId, attachName, attachUrl, creTm } = item

      this.isDoesItExist = !!matchArr.length
      if (this.isDoesItExist) {
        this.changeSealParams.hText = hText || ''
        this.changeSealParams.qText = qText || ''
        this.changeSealData = sealData || ''
        this.activePrintAccId = authorityAcctId || ''
        this.authorizationInfo = {
          attachName: attachName,
          creTm: this.dateFormat("YYYY-mm-dd HH:MM", new Date(creTm)),
          attachUrl: attachUrl
        }
      } else {
        this.activePrintAccId = ''
      }

      this.isViewHistory = false

      // 用印不存在时, 合同和项目 先生成预览
      if (!this.isDoesItExist && ['1', '2'].includes(this.selectedSealType)) {
        setTimeout(e => { this.contractSealFun('refresh') }, 500)
      }

      this.isPersonalExistence = false

      // 个人如果存在  不进入 替换模式
      if (item.sealKind === "personal") {
        this.isPersonalExistence = true
        this.isDoesItExist = false
      }

      this.setDownloadSealKind()
    },

    initSealKind() {
      // sealKind	String	印章种类（corp:合同章；project:项目章;legal:法人章；personal：个人章）
      const sealKind = {
        1: 'corp',
        2: 'project',
        3: 'legal',
        4: 'personal',
        5: 'authorize',
      }

      this.changeSealParams.sealKind = sealKind[Number(this.selectedSealType)]
      this.changeSealParams.acctType = ['3', '4'].includes(this.selectedSealType) ? '1' : '2'
      this.changeSealParams.certNo = ''
      this.changeSealParams.acctName = ''
      this.changeSealParams.hText = ''
      this.changeSealParams.qText = ''
      if (this.selectedSealType === '4') {
        clearInterval(this.accountInfoTimer)
        this.accountInfoTimer = setTimeout(e => { this.accountInfo() }, 500)
      }
      this.sealPerson = ''
      this.authorizationInfoBackup = {}
      this.authorizationInfo = {}
      this.uploadFileName = ''
    },

    accountInfo() {
      const result = this.$clone(this.signUserinfo) || {};
      this.changeSealParams.acctName = result.accName || ''
      this.changeSealParams.certNo = result.certNo || ''
      // 如果两个有值 则 直接 生成预览
      if (!!this.changeSealParams.acctName && !!this.changeSealParams.certNo) {
        clearTimeout(this.contractSealFunTimer)
        this.contractSealFunTimer = setTimeout(e => { this.contractSealFun('refresh') }, 500)
      }
    },

    setSealType() {
      if (this.sealKindList[this.selectedIndex].sealKind == 'corp') {
        this.selectedSealType = '1'
      }
      if (this.sealKindList[this.selectedIndex].sealKind == 'project') {
        this.selectedSealType = '2'
      }
      if (this.sealKindList[this.selectedIndex].sealKind == 'legal') {
        this.selectedSealType = '3'
      }
      if (this.sealKindList[this.selectedIndex].sealKind == 'personal') {
        this.selectedSealType = '4'
      }
      if (this.sealKindList[this.selectedIndex].sealKind == 'authorize') {
        this.selectedSealType = '5'
      }
    }
  },
  mounted() {
    this.init();
  }
}
</script>

<style scoped lang="scss">
.inner-container {
  margin-top: 20px;
  margin-bottom: 100px;
}
.header {
  margin-bottom: 20px;
  background: #f5f5f5;
}
.header ul {
  width: 100%;
  height: 48px;
  border-bottom: 3px solid #ffd64e;
  font-weight: bold;
  li {
    width: 110px;
    height: 48px;
    line-height: 48px;
    text-align: center;
    float: left;
    cursor: pointer;
    position: relative;

    &:after {
      display: none;
      position: absolute;
      bottom: 0px;
      left: 0;
      content: "";
      width: 110px;
      height: 3px;
      background: #4f525a;
    }
    &.active:after {
      display: block;
    }
  }
}
.order-info-title {
  margin: 5px 0;
  margin-bottom: 20px;
  padding: 0 10px;
  font-size: 14px;
  border-left: 3px solid #000;
  line-height: 12px;
  .blue {
    margin-left: 12px;
  }
}
.line {
  width: 100%;
  height: 1px;
  background: #eeeeee;
  margin: 30px 0 20px;
}
.upload-cont {
  margin: 20px 0;
}
.neet-upload-upfile {
  box-sizing: border-box;
  padding-left: 12px;
  display: flex;
  border-top: 1px solid transparent;

  & > li {
    width: 53%;

    &:nth-child(1) {
      .input-file-p {
        border: 1px solid #dcdfe6;
        box-sizing: border-box;
        padding: 0 12px;
        color: #606266;
        display: block;
        display: flex;
        flex-wrap: wrap;
        min-height: 38px;

        span {
          height: 36px;
          line-height: 36px;
        }

        & > .gray {
          color: #c0c4cc;
          font-size: 12px;
          outline: none;
          height: 36px;
        }

        .el-tag {
          margin: 4px;
          height: 30px;
        }
      }
    }

    &:nth-child(2) {
      width: 15%;
    }

    &:nth-child(3) {
      width: 33%;
    }

    .el-button--default {
      height: 38px;
      margin-left: 4px;
    }
  }

  .el-button--primary {
    width: 119px;
    margin-right: 12px;
  }

  /deep/ .upfile-container {
    .center {
      label {
        height: 38px;
        line-height: 38px;
        width: 90%;
        background: linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
        color: #fff !important;
        text-align: center;
      }
    }
  }
}
.company-seal-content {
  width: 100%;
  padding: 20px 70px 50px 60px;
  img {
    width: 100%;
    height: 100%;
  }
}
.preview-seal {
  position: relative;
  display: inline-block;
  vertical-align: middle;
  margin: 0 10px;
  text-align: center;
  p {
    color: #ccc;
    margin-top: 0;
  }
  img {
    max-width: 185px;
    max-height: 185px;
    vertical-align: middle;
  }

  label {
    display: inline-block;
    margin: 10px 0;
    color: #888888;
  }

  i {
    font-size: 30px;
    color: #ccc;
  }

  .preview-seal-content {
    position: relative;
    width: 185px;
    height: 185px;
    line-height: 96px;
    border: 1px solid #eee;
    cursor: pointer;
    overflow: hidden;
    em {
      color: #e7e7e7;
      position: absolute;
      left: 0;
      right: 0;
      margin: 100px auto 0;
      font-size: 18px;
    }
    .seal-change {
      position: absolute;
      left: 5px;
      bottom: -35px;
    }

    .preview-seal-text {
      position: absolute;
      top: 3px;
      left: -40px;
      display: block;
      width: 100px;
      line-height: 20px;
      font-size: 12px;
      background: #eee;
      transform: rotatez(-45deg);
    }
    &.active .preview-seal-text {
      background: #ffd64e;
    }
  }
  .seal-selected {
    border: 1px solid #ffd64e;
  }
  .seal-selected:after {
    content: "";
    position: absolute;
    height: 25px;
    width: 25px;
    bottom: -2px;
    right: -2px;
    background: url(../../assets/images/detail/right.png) no-repeat;
    z-index: 5;
  }
}
.fix-bottom {
  width: 100%;
  margin: 0 auto;
  text-align: center;
  .el-button {
    height: 34px;
  }
  p {
    color: #fff;
    line-height: 40px;
    font-size: 14px;
  }
}
.upload-title {
  background: #f5f5f5;
  border-bottom: 1px solid #fff;
  height: 35px;
  line-height: 35px;

  span {
    display: inline-block;
    padding-left: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  & span:nth-child(1) {
    width: 95%;
  }
}
.dashed-line {
  margin-top: 30px;
  padding-top: 10px;
  border-top: 1px dashed #eee;
  a {
    margin-left: 10px;
  }
}
.download-btn {
  margin-left: 0 !important;
}
.confirm-dialog {
  & > p {
    height: 20px;
    line-height: 20px;
  }
  .check {
    margin-top: 25px;
    padding: 0 5px;
    height: 30px;
    line-height: 30px;
    font-size: 14px;
    background: #f5f5f5;
  }
}
.black {
  color: #444;
  .el-icon-question {
    color: #bbb;
  }
  .el-icon-question:hover {
    color: #444;
  }
}
.dialog-footer {
  .el-button {
    width: 120px;
    padding: 8px;
  }
}
.upload-title {
  background: #f5f5f5;
  border-bottom: 1px solid #fff;
  height: 35px;
  line-height: 35px;

  span {
    display: inline-block;
    padding-left: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  & span:nth-child(1) {
    width: 65%;
  }
  & span:nth-child(2) {
    width: 25%;
  }
}
.personal-input-container {
  background: #f3f3f3;
  padding: 12px;
  margin-bottom: 20px;
  overflow: hidden;
  .personal-center {
    float: left;
    overflow: hidden;
    &.float-right {
      float: right;
    }
    & > .left {
      float: left;
      display: flex;
      align-items: center;
      margin-left: 22px;
      & > span {
        margin-right: 12px;
        white-space: pre;
      }
    }

    /deep/ .el-input--suffix {
      width: 217px;
    }
    /deep/ .el-input__inner {
      height: 30px;
      line-height: 30px;
      width: 217px;
    }
    /deep/ .el-input__suffix {
      top: -4px;
    }
    input {
      height: 30px;
      line-height: 30px;
      width: 225px;
    }
  }
}
.ml12 {
  margin-left: 12px;
}
.mb20 {
  margin-bottom: 20px;
}
.gray {
  color: #c0c4cc !important;
  font-size: 12px;
  outline: none;
  height: 36px;
}
input :disabled {
  border-color: #dddddd;
  color: #606266;
  background-color: #dddddd;
}
.history-dialog-table {
  width: 100%;
  thead {
    font-size: 14px;
    text-align: center;
    white-space: nowrap;
    color: #909399;
    background: #f5f5f5;
  }
  td {
    padding: 14px 10px;
    vertical-align: middle;
    word-break: break-all;
    border-bottom: 1px solid #eaeaea;
  }
}

.p0 {
  padding: 0 !important;
}
.reject_notice {
  text-align: left;
  background: #ffe9eb;
  padding: 4px 12px;
}
.history-resume-dialog {
  /deep/ .el-dialog__body {
    max-height: 400px;
    overflow: auto;
  }
}
.txt-center {
  font-size: 14px;
  text-align: center;
}
.el-row {
  padding: 1px 0;
}

.print-date {
  margin-bottom: 22px;
  .el-col {
    display: flex;
    align-items: center;
    & > span {
      margin-right: 14px;
    }
  }
}
.dis-fix {
  display: flex;
  align-items: center;
}
</style>