<template>
  <div class="forgetpwd-wrap">
    <Header :is-white-bg="isWhiteBg"></Header>
    <search-bar :search-type="5" :progress="'忘记密码'" :is-white-bg="true"></search-bar>
    <div class="forgetpwd-wrap-inner">
      <div class="contain inner-container register-wrapper-inner">
        <form class="form" onsubmit="return false;">
          <div class="title-tab">
            <div class="fw-tab fw-tab-0 tr" :class="{active: identifyType == 0}" @click="handleClick('0','1')"><span>使用手机号验证</span></div>
            <div class="fw-tab fw-tab-1 tl" :class="{active: identifyType == 1}" @click="handleClick('1','2')"><span>使用邮箱验证</span></div>
          </div>
          <div class="tab-content" v-if="identifyType == '0'">
            <div class="register-label">
              <div class="fl register-title"><i>*</i>手机号：</div>
              <div class="fl register-input-outer">
                <div class="register-input-box">
                  <!-- 防止浏览器自动填充用户密码 -->
                  <input name="old-userName" type="text" style="position: absolute; top: -9999px;opacity: 0">
                  <input name="old-pwd" type="password" style="position: absolute; top: -9999px;opacity: 0">
                  <el-input type="text" autocomplete="off" onkeyup="if(this.value.length==1){this.value=this.value.replace(/[^1-9]/g,'')}else{this.value=this.value.replace(/\D/g,'')}" placeholder="请输入您的注册手机号" v-model="model.mobile" @blur="checkForm('mobile')" clearable></el-input>
                </div>
                <div class="error-msg red" v-if="errorMsg.mobile">{{errorMsg.mobile}}</div>
              </div>
            </div>

            <div class="register-label">
              <div class="fl register-title"><i>*</i>新的登录密码：</div>
              <div class="fl register-input-outer">
                <div class="register-input-box">
                  <el-input placeholder="请输入新密码" type="password" v-model="model.pwd" @keyup.native="checkForm('pwd')" v-popover:popoverPwd1 autocomplete="off" clearable></el-input>
                  <el-popover ref="popoverPwd1" placement="right" title="" width="300" trigger="focus">
                    <div class="guid-text guid-1"><i class="el-icon-circle-check" :class="{'green':instant && instant ==2}"></i>必须是6-18个字母和数字</div>
                    <div class="guid-text guid-2"><i class="el-icon-circle-check" :class="{'green':instant && instant >=1}"></i>同时包含字母和数字</div>
                  </el-popover>
                </div>
                <div class="error-msg red" v-if="errorMsg.pwd">{{errorMsg.pwd}}</div>
              </div>
            </div>
            <div class="register-label">
              <div class="fl register-title"></div>
              <div class="fl register-input-box">
                <PwdStrength :pwd="model.pwd" @received="getPwdStrength" @instant="getPwdInstant"></PwdStrength>
              </div>
            </div>

            <div class="register-label">
              <div class="fl register-title"><i>*</i>确认新的登录密码：</div>
              <div class="fl register-input-outer">
                <div class="register-input-box">
                  <el-input placeholder="请再次输入新密码" v-model="model.rePwd" @blur="checkForm('rePwd')" type="password" auto-complete="off" clearable></el-input>
                </div>
                <div class="error-msg red" v-if="errorMsg.rePwd">{{errorMsg.rePwd}}</div>
              </div>
            </div>
            <!-- 公共部分 -->
            <div class="register-label">
              <div class="fl register-title">
                <i>*</i>验证码：
              </div>
              <div class="fl register-input-outer">
                <div class="register-input-box">
                  <ValidateCode :is-show-validate="true" @received="getCode" :update="updateCode"></ValidateCode>
                </div>
                <div class="error-msg red" v-if="errorMsg.validateCode">{{errorMsg.validateCode}}</div>
              </div>
            </div>

            <div class="register-label" v-if="getCodeType == '1'">
              <div class="fl register-title">
                <i>*</i>手机验证码：
              </div>
              <div class="fl register-input-outer">
                <div class="register-input-box">
                  <PhoneCode :is-show-phone-code="true" :type="'1'" :update="updateCode" :disable="!model.validateCode || !model.mobile" :phone="model.mobile" :imgCode="model.validateCode" :origTxCode="'forgetPwd'" @error="getError" @received="getPhoneCode">
                  </PhoneCode>
                </div>
                <div class="error-msg red" v-if="errorMsg.identifyCode">{{errorMsg.identifyCode}}</div>
              </div>
            </div>
            <div class="register-label" v-if="getCodeType == '2'">
              <div class="fl register-title">
                <i>*</i>邮箱验证码：
              </div>
              <div class="fl register-input-outer">
                <div class="register-input-box">
                  <PhoneCode :is-show-phone-code="true" :type="'2'" :update="updateCode" :disable="!model.validateCode || !model.email" :phone="model.email" :imgCode="model.validateCode" :origTxCode="'forgetPwd'" @error="getError" @received="getPhoneCode">
                  </PhoneCode>
                </div>
                <div class="error-msg red" v-if="errorMsg.identifyCode">{{errorMsg.identifyCode}}</div>
              </div>
            </div>
          </div>
          <div class="tab-content" v-if="identifyType == '1'">

            <div class="register-label">
              <div class="fl register-title"> <i>*</i>邮 箱： </div>
              <div class="fl register-input-outer">
                <div class="register-input-box">
                  <el-autocomplete ref="autocomplete" name="email" :fetch-suggestions="querySearch" :trigger-on-focus="false" placeholder="请输入您的注册邮箱" v-model="model.email" @blur="checkForm('email')" auto-complete="new-password" clearable> </el-autocomplete>
                </div>
                <div class="error-msg red" v-if="errorMsg.email">{{errorMsg.email}}</div>
              </div>
            </div>
            <div class="register-label">
              <div class="fl register-title"><i>*</i>新的登录密码：</div>
              <div class="fl register-input-outer">
                <div class="register-input-box">
                  <el-input type="password" placeholder="请输入新密码" v-model="model.pwd" @blur="checkForm('pwd')" v-popover:popoverPwd auto-complete="new-password" clearable></el-input>
                  <el-popover ref="popoverPwd" placement="right" title="" width="300" trigger="focus">
                    <div class="guid-text guid-1"><i class="el-icon-circle-check" :class="{'green':instant && instant ==2}"></i>必须是6-18个字母和数字</div>
                    <div class="guid-text guid-2"><i class="el-icon-circle-check" :class="{'green':instant && instant >=1}"></i>同时包含字母和数字</div>
                  </el-popover>
                </div>
                <div class="error-msg red" v-if="errorMsg.pwd">{{errorMsg.pwd}}</div>
              </div>
            </div>
            <div class="register-label">
              <div class="fl register-title"></div>
              <div class="fl register-input-box">
                <PwdStrength :pwd="model.pwd" @received="getPwdStrength" @instant="getPwdInstant"></PwdStrength>
              </div>
            </div>

            <div class="register-label">
              <div class="fl register-title"><i>*</i>确认新的登录密码：</div>
              <div class="fl register-input-outer">
                <div class="register-input-box">
                  <el-input placeholder="请再次输入新密码" v-model="model.rePwd" @blur="checkForm('rePwd')" type="password" auto-complete="off" clearable>
                  </el-input>
                </div>
                <div class="error-msg red" v-if="errorMsg.rePwd">{{errorMsg.rePwd}}</div>
              </div>
            </div>

            <!-- 公共部分 -->
            <div class="register-label">
              <div class="fl register-title">
                <i>*</i>验证码：
              </div>
              <div class="fl register-input-outer">
                <div class="register-input-box">
                  <ValidateCode :is-show-validate="true" @received="getCode" :update="updateCode"></ValidateCode>
                </div>
                <div class="error-msg red" v-if="errorMsg.validateCode">{{errorMsg.validateCode}}</div>
              </div>
            </div>

            <div class="register-label" v-if="getCodeType == '1'">
              <div class="fl register-title">
                <i>*</i>手机验证码：
              </div>
              <div class="fl register-input-outer">
                <div class="register-input-box">
                  <PhoneCode :is-show-phone-code="true" :type="'1'" :update="updateCode" :disable="!model.validateCode || !model.mobile" :phone="model.mobile" :imgCode="model.validateCode" :origTxCode="'forgetPwd'" @error="getError" @received="getPhoneCode">
                  </PhoneCode>
                </div>
                <div class="error-msg red" v-if="errorMsg.identifyCode">{{errorMsg.identifyCode}}</div>
              </div>
            </div>
            <div class="register-label" v-if="getCodeType == '2'">
              <div class="fl register-title">
                <i>*</i>邮箱验证码：
              </div>
              <div class="fl register-input-outer">
                <div class="register-input-box">
                  <PhoneCode :is-show-phone-code="true" :type="'2'" :update="updateCode" :disable="!model.validateCode || !model.email" :phone="model.email" :imgCode="model.validateCode" :origTxCode="'forgetPwd'" @error="getError" @received="getPhoneCode">
                  </PhoneCode>
                </div>
                <div class="error-msg red" v-if="errorMsg.identifyCode">{{errorMsg.identifyCode}}</div>
              </div>
            </div>
            <!-- 公共部分 -->
            <!-- <div class="register-label">
                  <div class="fl register-title">
                    <i>*</i>验证码：
                  </div>
                  <div class="fl register-input-outer">
                    <div class="register-input-box">
                      <ValidateCode :is-show-validate="true"  @received="getCode"></ValidateCode>
                    </div>
                    <div class="error-msg red" v-if="errorMsg.validateCode">{{errorMsg.validateCode}}</div>
                  </div>
                </div>

                <div class="register-label">
                  <div class="fl register-title">
                    <i>*</i>邮箱验证码：
                  </div>
                  <div class="fl register-input-outer">
                    <div class="register-input-box">
                      <PhoneCode :is-show-phone-code="true" :type= "'2'"
                      :disable="!model.validateCode || !model.email"
                      :phone= "model.email" :imgCode= "model.validateCode"
                      :origTxCode = "'forgetPwd'"
                      @error="getError"
                      @received="getPhoneCode">
                      </PhoneCode>
                    </div>
                    <div class="error-msg red" v-if="errorMsg.identifyCode">{{errorMsg.identifyCode}}</div>
                  </div>
                </div> -->

          </div>
          <el-button type="primary" class="submit-btn large-btn" @click="submit" :disabled="(!model.mobile && !model.email) || !model.pwd || !model.rePwd || !model.identifyCode">
            确认
          </el-button>
        </form>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import SearchBar from '@/components/SearchBar'
import Header from '@/components/base/Header'
import ValidateCode from '@/components/base/ValidateCode'
import PhoneCode from '@/components/base/PhoneCode'
import Loading from '@/components/base/Loading'
import PwdStrength from '@/components/base/PwdStrength'
import CryptoJS from 'crypto-js';
export default {
  components: {
    SearchBar,
    Header,
    Loading,
    ValidateCode,
    PhoneCode,
    PwdStrength
  },
  data() {
    return {
      isWhiteBg: true,
      identifyType: '0',
      model: {
        mobile: '',
        email: '',
        pwd: '',
        rePwd: '',
        identifyCode: '',
        validateCode: '',
      },
      pwdError: '',
      strength: '',
      instant: '',
      isLoading: false,
      errorMsg: {},
      getCodeType: '1',
      updateCode: 0,
    }
  },
  methods: {
    querySearch(queryString, callback) {
      let commonMailbox = this.$commonMailbox()
      let results = this.$clone(commonMailbox)
      let value = ''
      if(queryString && queryString.indexOf('@') != -1){
        value = queryString.substring(0, queryString.indexOf('@'))
      }else{
        value = queryString
      }
      results.forEach((i,index) =>{
          i.value = value + '' + commonMailbox[index].value
      })
      callback(results)
      this.$refs.autocomplete.handleFocus()
    },
    handleClick(identifyType, getCodeType) {
      this.identifyType = identifyType
      this.getCodeType = getCodeType

    },
    getCode(validateCode) {
      console.log(validateCode)
      this.model.validateCode = validateCode;
      if (validateCode) {
        delete this.errorMsg['validateCode']
      }

      this.$forceUpdate();
      this.$set(this.model, this.model);
      this.$set(this.errorMsg, this.errorMsg);
    },
    getPhoneCode(identifyCode) {
      //console.log(identifyCode)
      this.model.identifyCode = identifyCode
      delete this.errorMsg['identifyCode']
      this.$forceUpdate();
      this.$set(this.model, this.model);
      this.$set(this.errorMsg, this.errorMsg);
    },
    getPwdStrength(strength) {
      this.strength = strength
    },
    getPwdInstant(instant) {
      this.instant = instant
    },
    // 判断图形验证码是否正确
    getError(msg) {
      this.model.validateCode = '';
      this.updateCode++;
      this.$set(this.errorMsg, 'validateCode', msg);
    },

    checkForm(key) {

      let reg = ''

      if (!this.model[key]) {
        delete this.errorMsg[key]
        this.$forceUpdate();
        this.$set(this.model, this.model);
        this.$set(this.errorMsg, this.errorMsg);
        return
      }
      if (key == 'mobile') {
        reg = this.$commonExpression('mobile');  // /^[1][0-9][0-9]{9}$/;
        if (!reg.test(this.model[key])) {
          this.errorMsg[key] = '手机号格式不正确 '
        } else {
          delete this.errorMsg[key]
        }
      }

      if (key == 'email') {
        reg = this.$commonExpression('email'); // /^([0-9A-Za-z\-_\.]+)@([0-9a-z]+\.[a-z]{2,3}(\.[a-z]{2})?)$/g;
        if (!reg.test(this.model[key])) {
          this.errorMsg[key] = '邮箱格式不正确 '
        } else {
          const mail = this.model[key] || '',
            mailSuffix = mail.slice(mail.lastIndexOf('.') + 1, mail.length),
            errorMailSuffix = JSON.parse(this.$getRootLocalStorage('errorMailSuffix') || '[]')
          if (errorMailSuffix.includes(mailSuffix)) {
            this.$set(this.errorMsg, key, '邮箱后缀不正确')
            return
          } else {
            delete this.errorMsg[key]
          }
        }
      }

      //密码验证
      if (key == 'pwd') {
        let reg = new RegExp(/[^\u4e00-\u9fa5\w]/g)
        // this.model[key]  = this.model[key].replace(/[^\u4e00-\u9fa5\w]/g,'')
        if (this.model[key].length >= 18) {
          this.model[key] = this.model[key].substr(0, 18)
        }
        this.pwdError = false
        if (this.strength <= 1 || reg.test(this.model[key])) {
          this.errorMsg[key] = '密码设置不符合要求'
          this.pwdError = true
          // if(this.model[key] == this.$store.state.userInfo.acctName){
          //   this.pwdError = true
          // }
        } else {
          this.errorMsg[key] = ''
        }
        if (this.model.rePwd && this.model.rePwd != this.model.pwd) {
          this.errorMsg['rePwd'] = '两次输入的密码不一致，请重新输入'
        } else {
          delete this.errorMsg['rePwd']
        }


      }

      //重复密码验证
      if (key == 'rePwd') {
        if (this.model.pwd && this.model.rePwd != this.model.pwd) {
          this.errorMsg[key] = '两次输入的密码不一致，请重新输入'
        } else {
          this.errorMsg[key] = ''
        }
      }

      this.$forceUpdate();
      this.$set(this.model, this.model);
      this.$set(this.errorMsg, this.errorMsg);
    },

    submit() {
      // this.$router.push({ path: "/changePwdSuccess" });
      // if(JSON.stringify(this.errorMsg) == "{}"){
      console.log(this.model)
      // for(let key in this.model){
      //   if(!this.model[key]){
      //     this.errorMsg[key] = '输入不能为空'
      //   }
      // }
      for (let key in this.errorMsg) {
        if (this.errorMsg[key]) {
          return false;
        }
      }

      let pwd = CryptoJS.MD5(this.model.pwd).toString();
      let param = {
        'identifyType': this.identifyType,
        'pwd': pwd,
        'identifyCode': this.model.identifyCode,
        'validateCode': this.model.validateCode
      }
      if (this.identifyType == "0") {
        param.mobile = this.model.mobile
      } else if (this.identifyType == "1") {
        param.email = this.model.email
      }
      console.log(param)
      InterfaceService.forgetPwd(
        param,
        data => {
          let res = data.respData
          let errorKey = '';
          if (res.respCode == '0000') {
            this.$router.push({
              path: "/changePwdSuccess"
            });
            // this.$router.push({ path: "/changePwdSuccess" });
          } else {
            if (res.respCode == 'MEM0025' || res.respCode == 'MEM0111' || res.respCode == 'MEM0051' || res.respCode == 'MEM0112') {
              errorKey = 'mobile'
            } else if (res.respCode == 'MEM0109' || res.respCode == 'MEM0110' || res.respCode == 'MEM0114') {
              errorKey = 'email'
            } else if (res.respCode == 'MEM0027' || res.respCode == 'MEM0035') {
              errorKey = 'pwd'
            } else if (res.respCode == 'F000002') {
              errorKey = 'validateCode'
            } else if (res.respCode == 'F000003' || res.respCode == 'F000005') {
              if (res.respCode == 'F000005') {
                this.updateCode++
              }
              errorKey = 'identifyCode'
            }

            if (errorKey) {
              this.errorMsg[errorKey] = res.respMsg
            } else {
              this.$message.error(res.respMsg);
            }

            this.$forceUpdate();
            this.$set(this.errorMsg, this.errorMsg);

          }

        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
      // }
    }
  },
  // watch: {
  //   loginWrapInner(val) {
  //     this.loginWrapInner = val
  //   }
  // },
}
</script>

<style lang="scss" scoped>
.title-tab {
  height: 40px;
  margin-bottom: 60px;
  .fw-tab {
    float: left;
    width: 50%;
    height: 40px;
    line-height: 40px;
    font-size: 16px;
    font-weight: 900;
    cursor: pointer;

    &.active {
      span {
        &:before {
          background-color: #c99f4f;
        }
      }

      color: #c99f4f;
    }
    span {
      position: relative;
      &:before {
        content: "";
        width: 108px;
        height: 2px;
        background-color: transparent;
        position: absolute;
        bottom: -10px;
        left: 50%;
        margin-left: -54px;
        transition: all 0.3s linear;
      }
    }

    &.fw-tab-0 {
      padding-right: 25px;
    }
    &.fw-tab-1 {
      padding-left: 25px;
    }
  }
}
.guid-text {
  font-size: 12px;
  color: #888;
  line-height: 20px;
  i {
    margin-right: 8px;
  }
}
.register-wrapper-inner {
  .register-label {
    margin-bottom: 15px;
    overflow: hidden;

    .register-input-outer {
      width: 500px;
      min-height: 40px;

      .error-msg {
        height: 40px;
        line-height: 40px;
        font-size: 12px;
      }
    }

    .register-input-box {
      width: 500px;
      height: 40px;
      line-height: 40px;

      input {
        width: 100%;
        height: 40px;
        border: 1px solid #dddddd;
        text-indent: 20px;
        padding: 0;
      }
    }

    .register-title {
      width: 140px;
      height: 40px;
      line-height: 40px;
      text-align: right;
      padding-right: 10px;
      font-size: 12px;
      color: #888;

      i {
        color: #e93340;
        padding-right: 2px;
      }
    }
  }
  .submit-btn {
    display: block;
    margin: 50px auto 0;
  }
}

.forgetpwd-wrap .search-bar-container {
  height: 100%;
  padding-top: 15px;
}

.forgetpwd-wrap-inner {
  height: 800px;
  border-top: 2px solid #c99f4f;
}

.forgetpwd-wrap .contain {
  position: relative;
  height: 100%;
}

.forgetpwd-wrap .form {
  width: 650px;
  position: absolute;
  right: 0;
  top: 0;
  left: 0;
  bottom: 0;
  margin: auto;
  margin-top: 60px;
}

/deep/ .el-tabs__nav-wrap::after {
  background: #fff;
  height: 4px;
}

/deep/ .el-tabs__item {
  font-size: 16px;
  font-weight: 900;
}

/deep/ .el-tabs__item.is-active {
  color: #000;
}
/deep/ .el-tabs__header {
  margin: 0 0 40px 200px;
}
</style>
