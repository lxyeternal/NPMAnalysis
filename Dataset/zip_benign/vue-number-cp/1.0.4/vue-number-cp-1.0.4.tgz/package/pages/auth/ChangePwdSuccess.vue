<template>
  <div class="forgetpwd-wrap">
    <Header :is-white-bg="isWhiteBg"></Header>
    <search-bar :search-type="5" :progress="'忘记密码'" :is-white-bg="true"></search-bar>
    <div class="forgetpwd-wrap-inner">
      <div class="contain inner-container register-wrapper-inner">
				<div class="success"><i class="el-icon-check"></i></div>
        重置成功
				<div class="toLogin" @click="goLogin()">重新登录</div>
      </div>
    </div>
  </div>
</template>
<script>
  import SearchBar from '@/components/SearchBar'
  import Header from '@/components/base/Header'
  import axios from 'axios'

  export default {
    components: {
      SearchBar,
      Header
    },
    data() {
      return {
        isWhiteBg:true
      }
    },
    computed: {

    },
    methods: {
      goLogin(){
				this.$router.push('/login')
			}
    }
  }
</script>

<style lang="scss" scoped>
.success {
	margin: 160px auto 30px;
	width: 30px;
	height: 30px;
	border-radius: 15px;
	background: #5ea509;

	i {
		margin-top: 5px;
    color: #fff;
	}
}

.toLogin {
	font-size: 12px;
	color: #0082ff;
	cursor: pointer;
	margin-top: 20px;

}
.forgetpwd-wrap-inner {
	height: 800px;
	text-align: center;
	font-size: 20px;
	font-weight: 700;
	border-top: 2px solid #ffd64e;
}
</style>
