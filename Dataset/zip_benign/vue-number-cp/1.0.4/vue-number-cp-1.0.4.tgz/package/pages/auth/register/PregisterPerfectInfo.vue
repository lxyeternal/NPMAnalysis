<template>
  <div>
    <Header :is-white-bg="false"></Header>
    <SearchBar :is-white-bg="true" :search-type="7" :progress="'资料完善'" :is-border-bottom="true" :product-create-process="1"></SearchBar>
    <div class="inner-container regist-perfect-info">
      <el-form ref="form" :model="form" :rules="rules" label-width="134px">
        <!-- 公司信息 -->
        <div class="info-panel">
          <p class="info-panel-title">公司信息</p>
          <div class="info-panel-content">
            <div class="form-inline-item">
              <el-form-item label="公司名称：" prop="corpName">
                <el-input v-model="form.corpName" disabled placeholder="" @focus="checkForm('corpName',$event)" @blur="handleSearchCorp"></el-input>
                <div class="el-form-item__error" v-if="errorRules['corpName']">
                  {{ errorRules["corpName"] }}
                </div>
              </el-form-item>
              <el-form-item label="统一社会信用代码：" prop="busiLicense">
                <el-input v-model="form.busiLicense" disabled placeholder="" @focus="checkForm('busiLicense')" maxlength="18"></el-input>
                <div class="el-form-item__error" v-if="errorRules['busiLicense']">
                  {{ errorRules["busiLicense"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="法人代表：" prop="legalRepresent">
                <el-input disabled v-model="form.legalRepresent" placeholder="请输入" @focus="checkForm('legalRepresent')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['legalRepresent']">
                  {{ errorRules["legalRepresent"] }}
                </div>
              </el-form-item>
              <el-form-item label="法人证件号：" prop="legalCertNo">
                <el-input type="text" v-model="form.legalCertNo" placeholder="请输入" @focus="checkForm('legalCertNo')" maxlength="30"></el-input>
                <div class="el-form-item__error" v-if="errorRules['legalCertNo']">
                  {{ errorRules["legalCertNo"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="注册资本（万元）：" prop="registCapital">
                <el-input type="text" v-model="form.registCapital" placeholder="请输入" @focus="checkForm('registCapital')" maxlength="100"></el-input>
                <div class="el-form-item__error" v-if="errorRules['registCapital']">
                  {{ errorRules["registCapital"] }}
                </div>
              </el-form-item>
              <el-form-item label="纳税人资格：" prop="taxpayerType">
                <el-radio-group v-model="form.taxpayerType">
                  <el-radio label="0">一般纳税人</el-radio>
                  <el-radio label="1">小规模纳税人</el-radio>
                </el-radio-group>
                <div class="el-form-item__error" v-if="errorRules['taxpayerType']">
                  {{ errorRules["taxpayerType"] }}
                </div>
              </el-form-item>
            </div>

            <div class="form-inline-item">
              <el-form-item label="企业类型：" prop="corpTypeName">
                <el-input v-model="form.corpTypeName" placeholder="请输入" @focus="checkForm('corpTypeName')" maxlength="32"></el-input>
                <div class="el-form-item__error" v-if="errorRules['corpTypeName']">
                  {{ errorRules["corpTypeName"] }}
                </div>
              </el-form-item>
              <el-form-item label="成立日期：" prop="establishDt">
                <el-date-picker value-format="yyyy-MM-dd" v-model="form.establishDt" size="" type="date" placeholder="请选择日期" @change="checkForm('establishDt')">
                </el-date-picker>
                <div class="el-form-item__error" v-if="errorRules['establishDt']">
                  {{ errorRules["establishDt"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="公司简称：" prop="shortCorpName">
                <el-input v-model="form.shortCorpName" maxlength="6" placeholder="请输入" @focus="checkForm('shortCorpName')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['shortCorpName']">
                  {{ errorRules["shortCorpName"] }}
                </div>
              </el-form-item>
              <el-form-item label="上级公司名称：" prop="supCorpName">
                <el-input v-model="form.supCorpName" placeholder="请输入" @focus="checkForm('supCorpName')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['supCorpName']">
                  {{ errorRules["supCorpName"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-upload-text">
              <span class="form-upload-text-left"><i class="red">*</i> 营业执照：</span><span class="form-upload-right">请上传工商营业执照、组织机构代码证、税务登记证或三证合一的营业执照 (单张图片大小不超过1M，建议方形尺寸500*500，jpg或png格式)</span>
            </div>
            <div class="form-upload-content">
              <el-form-item label="">
                <div class="info-master-img">
                  <div class="img-item" :class="{ 'has-img': img.previewSrcr }" v-for="(img, index) in imgList" :key="index">
                    <div class="img-item-cover">
                      <div class="img-item-add">
                        <label :for="'masterImg' + index">
                          <i class="el-icon-plus"></i>
                        </label>
                        <img v-if="img.previewSrcr" :src="img.previewSrcr" />
                        <input :disabled='img.file != ""' :id="'masterImg' + index" type="file" @change="pushImg($event, index)" />
                      </div>
                      <div class="img-item-bottom" v-if="img.previewSrcr">
                        <a @click="clearImg(index)">删除</a>
                        <a @click="reviewImg(index)">预览</a>
                      </div>
                    </div>
                    <el-dialog title="" :visible.sync="img.dialogVisible">
                      <img :src="img.previewSrcr" alt="" />
                    </el-dialog>
                  </div>
                </div>
                <div class="el-form-item__error">{{ imgError }}</div>
              </el-form-item>
            </div>
            <div class="form-item" style="width:60%;">
              <el-form-item label="营业期限：" prop="dealFrom">
                <el-row>
                  <el-col :span="11">
                    <el-date-picker value-format="yyyy-MM-dd" v-model="form.dealFrom" size="" type="date" placeholder="开始日期">
                    </el-date-picker>
                  </el-col>
                  <el-col :span="2" class="tc">~</el-col>
                  <el-col :span="11">
                    <el-date-picker value-format="yyyy-MM-dd" v-model="form.dealTo" size="" type="date" placeholder="结束日期">
                    </el-date-picker>
                  </el-col>
                </el-row>
                <div class="el-form-item__error" v-if="errorRules['dealFrom']">
                  {{ errorRules["dealFrom"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-item" style="width:40%;">
              <el-form-item label="所属事业部：" prop="groupCompanyCode">
                <el-select v-model="form.groupCompanyCode" placeholder="请选择所属事业部">
                  <el-option v-for='(item,index) in groupCompanyList' :label="item.value" :value="item.code" :key="index"></el-option>
                </el-select>
              </el-form-item>
            </div>
          </div>
        </div>
        <div class="info-panel">
          <p class="info-panel-title">
            公司授权管理员
          </p>
          <div class="info-panel-content">
            <div class="form-inline-item">
              <el-form-item label="本人是否为管理员：">
                <el-radio v-model="isAdmin" label="1" @change="handleChangeAdminInfo">是</el-radio>
                <el-radio v-model="isAdmin" label="0" @change="handleChangeAdminInfo">否</el-radio>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="管理员姓名：" prop="adminName">
                <el-input v-model="form.adminName" placeholder="请输入姓名" @focus="checkForm('adminName')" :disabled="isAdmin == '1'" maxlength="10"></el-input>
                <div class="el-form-item__error" v-if="errorRules['adminName']">
                  {{ errorRules["adminName"] }}
                </div>
              </el-form-item>
              <el-form-item label="管理员身份证号：" prop="adminCertNo">
                <el-input v-model="form.adminCertNo" placeholder="请输入身份证号" @focus="checkForm('adminCertNo')" :disabled="isAdmin == '1'"></el-input>
                <div class="el-form-item__error" v-if="errorRules['adminCertNo']">
                  {{ errorRules["adminCertNo"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="管理员手机号：" prop="adminMobile">
                <el-input v-model="form.adminMobile" placeholder="请输入手机号" @focus="checkForm('adminMobile')" :disabled="isAdmin == '1'"></el-input>
                <div class="el-form-item__error">
                  ※该手机号将作为管理员登录大家采的账号
                </div>
              </el-form-item>
              <el-form-item label="管理员邮箱：" prop="adminEmail">
                <el-autocomplete ref="autocomplete" :fetch-suggestions="querySearch" :trigger-on-focus="false" v-model="form.adminEmail" placeholder="请输入邮箱" @focus="checkForm('adminEmail')" :disabled="isAdmin == '1'" maxlength="64"></el-autocomplete>
                <div class="el-form-item__error" v-if="errorRules['adminEmail']">
                  {{ errorRules["adminEmail"] }}
                </div>
              </el-form-item>
              <el-form-item label="部门：" prop="department">
                <el-input v-model="form.department" placeholder="请输入部门" @focus="checkForm('department')" maxlength="50"></el-input>
                <div class="el-form-item__error" v-if="errorRules['department']">
                  {{ errorRules["department"] }}
                </div>
              </el-form-item>
              <el-form-item label="职务：" prop="position">
                <el-input v-model="form.position" placeholder="请输入职务" @focus="checkForm('position')" maxlength="40"></el-input>
                <div class="el-form-item__error" v-if="errorRules['position']">
                  {{ errorRules["position"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-item" style="width:60%;">
              <el-form-item label="授权委托期：" prop="effectiveStartdate">
                <el-row>
                  <el-col :span="11">
                    <el-date-picker value-format="yyyy-MM-dd" v-model="form.effectiveStartdate" size="" type="date" placeholder="开始日期">
                    </el-date-picker>
                  </el-col>
                  <el-col :span="2" class="tc">~</el-col>
                  <el-col :span="11">
                    <el-date-picker value-format="yyyy-MM-dd" v-model="form.effectiveEnddate" size="" type="date" placeholder="结束日期">
                    </el-date-picker>
                  </el-col>
                </el-row>
                <div class="el-form-item__error" v-if="errorRules['effectiveStartdate']">
                  {{ errorRules["effectiveStartdate"] }}
                </div>
              </el-form-item>
            </div>
          </div>
          <i class="red f12" style="margin: 30px 0px 0px 135px;display: block;">※需提供公司授权管理员以公司名义在大家采平台上进行操作的授权书。请点击【下载模板】，填写《大家采平台管理员授权委托书》并加盖公司公章后，上传授权书的PDF扫描件。</i>
          <el-form-item label="上传授权书：" :required="true" class="authorization">
            <el-col :span="21">
              <ul class="neet-upload-upfile" :class="{isie:isIE11}">
                <li>
                  <p class="input-file-p">
                    <span class="gray">
                      请上传授权书
                    </span>
                    <!--<span v-else>{{authorizationInfo.name || ''}}</span>-->
                  </p>
                </li>
                <li>
                  <div class="upfile-container">
                    <div class="center">
                      <label class="blue">
                        <UpfileComponent ref="upfileRef" :immediateClearList="true" :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :btnName="'选择文件'" :dirName="`${new Date().getTime()}/`" :type="'13'" :fileTypes="uploadFileSuffix" :id="'123'" @outputList="handleUpFileResult($event)"></UpfileComponent>
                      </label>
                    </div>
                  </div>
                </li>
              </ul>
            </el-col>
            <el-col :span="3">
              <el-button size="small" style="height: 40px;width: 120px;margin-left:10px;" @click="handleDownTemp()">下载模板</el-button>
            </el-col>
          </el-form-item>
          <div class="upload-cont">
            <div class="upload-title">
              <span>
                已上传文本
              </span>
              <span>
                上传时间
              </span>
              <span>
                操作
              </span>
            </div>
            <div class="upload-title tl" v-if="authorizationInfo.attachName">
              <span>
                {{authorizationInfo.attachName}}
              </span>
              <span>
                {{authorizationInfo.creTm}}
              </span>
              <span>
                <i class="hand blue" @click="delFileInfo">删除</i>
              </span>
            </div>
          </div>
        </div>
        <div class="continue">
          <el-button class="large-btn" type="primary" @click="submit('rules')">提交并继续</el-button>
        </div>
      </el-form>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import {
  mapActions,
  mapState
} from 'vuex'
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import Distpicker from "@/components/base/Distpicker";
import { InterfaceService } from '@/services/api'
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
import { DateUtil } from '@/utils/dateUtil';

export default {
  components: {
    Header,
    SearchBar,
    Loading,
    Distpicker,
    UpfileComponent,
  },
  data() {
    var validateDate = (rule, value, callback) => {
      if (value) {
        var thetime = value
        var curDate = new Date(Date.parse(localStorage.getItem('systemTime').replace(/-/g, "/")));
        if (thetime > curDate) {
          callback(new Error('请选择有效的成立日期'));
        } else {
          callback();
        }
      } else {
        callback();
      }
    };
    var validateDateSection = (rule, value, callback) => {
      if (value) {
        var thetimeFirst = value
        var thetimeSecond = this.form.dealTo
        if (thetimeSecond && thetimeFirst > thetimeSecond) {
          this.form.dealFrom = ''
          // this.form.dealTo = ''
          callback(new Error('请选择有效的营业期限'));
        } else {
          callback();
        }

      } else {
        callback();
      }
    };
    var validateEffectiveStartdate = (rule, value, callback) => {
      if (value) {
        var thetimeFirst = value
        var thetimeSecond = this.form.effectiveEnddate
        if (thetimeSecond && thetimeFirst > thetimeSecond) {
          this.form.effectiveStartdate = ''
          // this.form.dealTo = ''
          callback(new Error('请选择有效的授权委托期'));
        } else {
          callback();
        }

      } else {
        callback();
      }
    };
    var validatePass2 = (rule, value, callback) => {
      if (!/^[A-Za-z0-9]+([._\\-]*[A-Za-z0-9])*@([a-zA-Z0-9]+[-a-z0-9]*[a-zA-Z0-9]+.){1,63}[a-zA-Z0-9]+$/.test(value)) {
        callback(new Error('邮箱格式不正确'));
      } else {
        const mail = value || '',
          mailSuffix = mail.slice(mail.lastIndexOf('.') + 1, mail.length)

        const errorMailSuffix = JSON.parse(this.$getRootLocalStorage('errorMailSuffix') || '[]')
        if (errorMailSuffix.includes(mailSuffix)) {
          callback(new Error('邮箱后缀不正确'));
          return
        }
        callback();
      }
    };
    var validateLegalCertNo = (rule, value, callback) => {
      if (value) {
        if (!this.corporateNameList.length || this.corporateNameList.length && this.corporateNameList[0].value.split(',').every(i=> i !== this.form.corpName) ) {
          if (!/^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/.test(value)) {
            callback(new Error('请输入正确法人证件号'));
          } else {
            callback();
          }
        } else {
          callback();
        }
      } else {
        callback();
      }
    };
    return {
      isLoading: false,
      isReject: false,
      isAdmin: "",
      imgList: [
        { 'previewSrcr': '', 'file': '', 'dialogVisible': false },
        // { 'previewSrcr': '', 'file': '', 'dialogVisible': false },
        // { 'previewSrcr': '', 'file': '', 'dialogVisible': false },
      ],
      pcbCode: {},

      form: {
        corpName: '',
        dealFrom: '',
        dealTo: '',
        effectiveStartdate: '',
        effectiveEnddate: '',
        supCorpName: '',
        busiLicense: '',
        corpTypeName: '',
        establishDt: '',
        legalRepresent: '',
        shortCorpName: '',
        legalCertNo: '',
        registCapital: '',
        taxpayerType: '',
        prodType: [],
        prevPurchase: '',
        attachList: [],
        adminName: '',
        adminCertNo: '',
        adminMobile: '',
        adminEmail: '',
        department: '',
        position: '',
        groupCompanyCode: '',
        groupCompanyName: '',
      },
      rules: {
        corpName: [
          {
            required: true,
            message: "必填"
          },
          { max: 200, message: "公司名称不得大于200个字", trigger: "blur" }
        ],
        supCorpName: [
          { max: 200, message: "上级公司名称不得大于200个字", trigger: "blur" }
        ],
        // orgCode: [
        //     {
        //         required: true,
        //         message: "必填"
        //     },
        //     { pattern: /^[0-9a-zA-Z]{1,18}$/, message: '请输入正确的组织机构代码' , trigger: "blur"}
        // ],
        busiLicense: [
          {
            required: true,
            message: "必填"
          },
          // { pattern: /^(?=.*[A-Z])(?=.*[0-9])[0-9A-Z]{18}/, message: '请输入正确的统一社会信用代码' , trigger: "blur"}
          { pattern: /^[0-9A-Z]{18}/, message: '请输入正确的统一社会信用代码', trigger: "blur" }
        ],
        corpTypeName: [
          {
            required: true,
            message: "必填"
          }
        ],
        establishDt: [
          {
            required: true,
            message: "必填"
          },
          { validator: validateDate, trigger: 'blur' }
        ],
        legalRepresent: [
          {
            required: true,
            message: "必填"
          },
          { max: 200, message: "法人代表不得大于200个字", trigger: "blur" }
        ],
        shortCorpName: [
          {
            required: true,
            message: "必填"
          },
          { max: 6, message: "公司简称不得大于6个字", trigger: "blur" }
        ],
        legalCertNo: [
          {
            required: true,
            message: "请填写法人证件号"
          },
          { validator: validateLegalCertNo, max: 30, message: "请输入正确法人证件号", trigger: "blur" }
        ],
        registCapital: [
          {
            required: true,
            message: "请填写注册资本"
          }
        ],
        taxpayerType: [
          {
            required: true,
            message: "请选择纳税人资格",
            trigger: "change"
          }
        ],
        dealFrom: [
          {
            required: true,
            message: "必填"
          },
          { validator: validateDateSection, trigger: 'blur' }
        ],
        effectiveStartdate: [
          {
            required: true,
            message: "必填"
          },
          { validator: validateEffectiveStartdate, trigger: 'blur' }
        ],
        groupCompanyCode: [
          {
            required: true,
            message: "必填"
          }
        ],
        adminName: [
          {
            required: true,
            message: "必填"
          },
          { pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]{2,200}$/, max: 200, message: "姓名设置不符合要求", trigger: "blur" }
        ],
        adminCertNo: [
          {
            required: true,
            message: "必填"
          },
          { pattern: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/, max: 20, message: "身份证号码不正确", trigger: "blur" }
        ],
        adminMobile: [
          {
            required: true,
            message: "必填"
          },
          { pattern: /^[1][0-9][0-9]{9}$/, max: 11, message: "手机号格式不正确", trigger: "blur" }
        ],
        adminEmail: [
          {
            required: true,
            message: "必填"
          },
          { validator: validatePass2, trigger: 'blur' },
        ],
        department: [
          {
            required: true,
            message: "必填"
          },
          { max: 50, message: "部门名称不得大于50个字", trigger: "blur" }
        ],
        position: [
          {
            required: true,
            message: "必填"
          },
          { max: 40, message: "职务名称不得大于40个字", trigger: "blur" }
        ],
      },
      errorRules: {},
      isFirstSubmit: true,
      canClick: true,
      timer: '',
      imgError: '',
      fileError: '',
      authorizationInfo: {},
      focusCorpName: '',
      templateFileUrl: '',
      templateFileName: '',
      uploadFileSuffix: '',
      registerAdvancedInfo: {}, // 下一页面需要数据
      isAdminInfo: {}, //
      delImgList: [], // 删除的图片存储
      groupCompanyList: [], // 删除的图片存储
      corporateNameList:[],
    };
  },
  computed: {
    isIE11() {
      let userAgent = navigator.userAgent;
      return userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; // ie11<11
    },
    userInfo() {
      return this.$store.state.userInfo
    },
  },
  methods: {
    ...mapActions(['setUserInfoAction']),
    querySearch(queryString, callback) {
      let commonMailbox = this.$commonMailbox()
      let results = this.$clone(commonMailbox)
      let value = ''
      if(queryString && queryString.indexOf('@') != -1){
        value = queryString.substring(0, queryString.indexOf('@'))
      }else{
        value = queryString
      }
      results.forEach((i,index) =>{
          i.value = value + '' + commonMailbox[index].value
      })
      callback(results)
      this.$refs.autocomplete.handleFocus()
    },
    init() {
      this.getPaymentMethod()
      // 如果有corpId 则需要先执行查询数据操作
      console.log(this.$route.query.corpId);
      if (!!this.$route.query.corpId) {
        this.getPurchaserMessage();
        this.isReject = true;
      } else {
        this.form.corpName = this.userInfo.corpName || "";
        this.form.busiLicense = this.userInfo.busiLicense || "";
        this.form.legalRepresent = this.userInfo.legalRepresent || "";
        if (this.form.corpName) {
          this.handleSearchCorp(this.form.corpName)
        }
        this.getBusinessDepartmentList()
      }
      this.getOrderConfiguration()
      this.errorRules = {}
    },
    getPaymentMethod() {
      let params = {
        appName: 'PRODUCT',
        groupId: 'REGIST_LEGAL_WHITE_LIST',
      };
      InterfaceService.getPaymentMethod(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.corporateNameList = data.respData.configEntityList || [] //公司白名单
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => { this.isLoading = true; }, () => { this.isLoading = false; })
    },
    handleUpFileResult(e) {
      this.delFileInfo()
      const { file, name, targetValue, url } = e[0]
      this.authorizationInfo = {
        file: file,
        attachName: name,
        creTm: this.dateFormat("YYYY-mm-dd HH:MM", new Date()),
        targetValue,
        attachUrl: url
      }
      console.log(this.authorizationInfo, this.imgList, '--this.authorizationInfo ')
    },
    handleUpload(e) {
      let file = e.target.files[0]
      // 获取当前上传文件名
      let name = file.name || ''
      const fileType = name.slice(name.lastIndexOf('.') + 1, name.length),
        targetValue = e.target.value || ''
      let typeOnOff = true;
      let fileSizeOnOff = true;
      if (this.uploadFileSuffix && fileType != this.uploadFileSuffix) {
        this.$message.error("请上传有公司用印的PDF扫描文件！");
        this.resetInputValue()
        typeOnOff = false
        return;
      }
      if (file.size > 52428800) {
        this.$message.error("上传文件不能超过50M, 请重新选择");
        this.resetInputValue()
        fileSizeOnOff = false
        return;
      }
      let now = new Date();
      if (this.authorizationInfo.id) {
        this.delImgList.push({ attachId: this.authorizationInfo.id })
      }
      this.authorizationInfo = {
        file: file,
        attachName: name,
        creTm: this.dateFormat("YYYY-mm-dd HH:MM", now),
        targetValue
      }
      this.resetInputValue()
    },
    dateFormat(fmt, date) {
      let ret;
      const opt = {
        "Y+": date.getFullYear().toString(),        // 年
        "m+": (date.getMonth() + 1).toString(),     // 月
        "d+": date.getDate().toString(),            // 日
        "H+": date.getHours().toString(),           // 时
        "M+": date.getMinutes().toString(),         // 分
        "S+": date.getSeconds().toString()          // 秒
      };
      for (let k in opt) {
        ret = new RegExp("(" + k + ")").exec(fmt);
        if (ret) {
          fmt = fmt.replace(ret[1], (ret[1].length == 1) ? (opt[k]) : (opt[k].padStart(ret[1].length, "0")))
        };
      };
      return fmt;
    },
    /**
     * 重置input value  防止 同一个文件连续提交 不触发 onchange事件
     */
    resetInputValue() {
      let isIE10 = false,
        uploadInputs = document.getElementsByName('my-upfile-component-input-name') || []
      if (window.navigator.userAgent.indexOf('MSIE') >= 1) { // 判断ie10以及以下
        isIE10 = true
      } else {
        isIE10 = false
      }
      for (let i = 0, len = uploadInputs.length; i < len; i++) {
        const element = uploadInputs[i];

        if (isIE10) {
          let form = document.createElement('form'),
            beforInput = element.nextSibling,
            parentInput = element.parentNode

          form.appendChild(element)
          form.reset()
          parentInput.insertBefore(element, beforInput)
        } else {
          element.value = ''
        }

      }
    },
    getBusinessDepartmentList() {
      const params = {
        groupId: 'GROUP_COMPANY'
      };
      InterfaceService.getBusinessDepartmentList(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          this.groupCompanyList = res.configList || [];
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    getOrderConfiguration() {
      const params = {
        businessType: 'AUTHORIZATION'
      };
      InterfaceService.getOrderConfiguration(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          let list = res.uploadFileList || [];
          list.forEach(item => {
            if (item.fileTypeId === "regist_authorization") {
              this.templateFileUrl = item.attachUrl || "";
              this.templateFileName = item.templateFileName || "";
              this.uploadFileSuffix = item.uploadFileSuffix || "";
            }
          })
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    getCropId() {
      InterfaceService.registerGetCropId({}, (data) => { },
        data => { },
        () => {
          //this.isLoading = true;
        },
        () => {
          //this.isLoading = false;
        }
      );
    },
    handleDownTemp() {
      this.$download([{
        name: this.templateFileName || '',
        url: this.templateFileUrl || ''
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    timestampToTime(timestamp) {
      let date = new Date(timestamp);
      let Y = date.getFullYear() + '-';
      let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
      let D = date.getDate() + ' ';
      return Y + M + D;
    },
    handleSearchCorp(name) {
      if (name) {
        InterfaceService.doGetProviderRiskDetail(
          { name: name, type: "baseInfo" },
          data => {
            if (data.respData.respCode === "0000") {
              let corpInfo = data.respData.riskBaseInfoBean || {};
              this.form.establishDt = corpInfo.estiblishTime || "";
              this.form.registCapital = corpInfo.regCapital || "";
              this.form.dealFrom = corpInfo.fromTime && this.timestampToTime(corpInfo.fromTime) || "";
              this.form.dealTo = corpInfo.toTime && this.timestampToTime(corpInfo.toTime) || "";
              this.form.corpTypeName = corpInfo.companyOrgType || "";
              this.errorRules = {}
            }
          },
          data => { },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      }
    },
    checkForm(key, ev) {
      if (ev) {
        this.focusCorpName = ev.target.value || ""
      }
      if (this.form[key]) {
        delete this.errorRules[key]
      }
    },
    submit(rules) {
      let _this = this;
      let _loadImg = []
      let upLoadState = false; // 是否提示 - 请上传图片附件
      for (var i = 0; i < _this.imgList.length; i++) {
        if (!_this.imgList[i].id) {
          let file = _this.imgList[i] && _this.imgList[i].file
          if (file) {
            _loadImg.push(_this.imgList[i])
          }
        }
      }

      _this.imgList.forEach(item => {
        if (!!item.id) {
          upLoadState = true;
        }
      })
      if (!upLoadState && _loadImg.length == 0) {
        _this.imgError = '请上传图片附件'
        return false
      }

      if (!this.authorizationInfo.attachName) {
        _this.$message.error('请上传授权书')
        return false
      }
      _this.$refs.form.validate((valid) => {
        if (valid) {

          _this.form['attachList'] = []
          _this.form['attachList'].push({
            'attachURL': this.authorizationInfo && this.authorizationInfo.attachUrl || '', // 替换地址,
            'attachType': "2",
          })

          if (_this.isFirstSubmit) {
            // 如果loadImg长度为0 , 说明用的是反显数据图片, 直接提交
            if (_loadImg.length === 0) {
              _this.submitCompelet()
              return
            }
            //先上传图片
            //去后端拿签名一次性
            InterfaceService.getOssSignatureDisposable('',{}, (data) => {
              console.log(_loadImg);
              let signature = data
              for (var pos = 0; pos < _loadImg.length; pos++) {
                let file = _loadImg[pos] && _loadImg[pos].file
                let fileFlag = false;
                _loadImg[pos].attachName ? fileFlag = true : fileFlag = false
                if (file) {
                  let dirType = 'company/'
                  _this.uploadHander(pos, file, dirType, signature, (pos, file, dirType, signature) => {
                    let u = "#url#" + '/' + signature.dir + dirType + file.name
                    if (!fileFlag) {
                      _this.form['attachList'].push({
                        'attachURL': u,
                        'attachType': "0",
                      })
                    }
                    //图片上传到oss之后 提交注册信息
                    if (pos >= _loadImg.length - 1) {
                      setTimeout(() => {
                        _this.submitCompelet()
                      }, 800)
                    }
                  })
                }
              }

              console.log(_this.form, '---_this.form');


            }, (data) => {
              _this.isLoading = false;
            },
              () => {
                _this.isLoading = true;
              },
              () => {
                //_this.isLoading = false;
              });


          } else {

            _this.isLoading = false;
            _this.submitCompelet()
          }


        }
      })
    },
    submitCompelet() {
      // 如果是驳回 则走驳回更新
      if (this.isReject) {
        this.rejectSubmit();
        return;
      }
      let _this = this
      _this.isLoading = false;
      let params = JSON.parse(JSON.stringify(_this.form));
      params.prodType = ''
      //establishDt 格式
      // params.establishDt = params.establishDt.replace(/-/g, '/').substr(0, 10)
      // params.dealFrom = params.dealFrom && params.dealFrom.replace(/-/g, '/').substr(0, 10)
      // params.dealTo = params.dealTo && params.dealTo.replace(/-/g, '/').substr(0, 10)
      params.corpId = this.userInfo.corpId;
      params.attachList = _this.form['attachList'];
      this.groupCompanyList.forEach(item => {
        if (item.code === params.groupCompanyCode) {
          params.groupCompanyName = item.value
        }
      })
      //提交信息
      InterfaceService.registerPurchaser(
        params,
        data => {
          _this.result = data.respData;
          if (_this.result.respCode == '0000') {
            _this.isFirstSubmit = false;//上传过 则此标记为false
            //去缓存里获取userInfo  加入公司信息
            let userInfo = JSON.parse(_this.$getRootScope('user'))
            // userInfo.corpId = _this.result.corpId
            userInfo.corpName = _this.form.corpName
            userInfo.bs = "B";
            _this.$setRootScope('user', JSON.stringify(userInfo))
            _this.setUserInfoAction(userInfo)
            this.$router.push({
              path: "/registerAdvanced",
              query: {
                corpId: userInfo.corpId,
                corpName: this.form.corpName,
              }
            });
          } else {

            // corpName supCorpName orgCode busiLicense corpTypeName establishDt legalRepresent
            // registCapital prevSales prevPurchase thisYearSales avlDevelopYears prodType
            // telNumber faxAreaCode faxNumber
            if (_this.result.respCode == 'MEM0089' || _this.result.respCode == 'MEM0037') {
              _this.errorRules['orgCode'] = _this.result.respMsg
            } else if (_this.result.respCode == 'MEM0090' || _this.result.respCode == 'MEM0036' || _this.result.respCode == 'MEM0012') {
              _this.errorRules['busiLicense'] = _this.result.respMsg
            } else if (_this.result.respCode == 'MEM0073') {
              _this.errorRules['corpName'] = _this.result.respMsg
            } else if (_this.result.respCode == 'MEM0056') {
              _this.errorRules['prevPurchase'] = _this.result.respMsg
            } else if (_this.result.respCode == 'MEM0013' || _this.result.respCode == 'MEM0037') {
              _this.errorRules['orgCode'] = _this.result.respMsg
            } else {
              _this.$message.error(_this.result.respMsg);
            }
          }
        },
        data => {

        },
        () => {
          _this.isLoading = true;
        },
        () => {
          _this.isLoading = false;
        }
      );
    },
    pushImg(event, index) {//input控件（自定义）获取文件 上传
      let _this = this;
      _this.isFirstSubmit = true;//更改过图片 则视为第一次提交（需要上传图片)
      let file = event.target.files[0]
      if (file) {
        let checkTextList = JSON.parse(sessionStorage.getItem('checkTextList') || '[]');
        let onOff = false;
        let forbidText = ''
        checkTextList.forEach(i=>{
          if (i != '' && file.name.indexOf(i) != -1) {
            onOff = true
            forbidText = i
          }
        });
        if (onOff) {
          this.$message.error('文件名包含特殊字符【'+forbidText+'】,请修改文件名后再上传')
          return false
        }
        _this.imgError = ''
        // 判断是否图片
        if ((file.type).indexOf("image/") == -1) {
          _this.imgError = '请选择图片!'
          return false
        }

        let fSize = Math.round(file.size / 1024 * 100) / 100;//取得图片文件的大小
        if (fSize >= 1024) {//单位为KB
          _this.imgError = '照片最大尺寸为1024KB，请重新上传!'
          return false
        }

        for (var i in _this.imgList) {
          // name: "building.png"
          // size: 2731
          // type: "image/png"
          let cImg = _this.imgList[i] && _this.imgList[i].file

          if (cImg) {
            if (file.name == cImg.name && file.size == cImg.size && file.type == cImg.type) {
              _this.imgError = '图片已经存在，请重新选择!'
              return false
            }
          }
        }

        let reader = new FileReader();
        reader.onloadend = function () {
          _this.imgList[index].previewSrcr = reader.result
          _this.imgList[index].file = file
          _this.form['attachList'].push({
            'attachURL': file,
            'attachType': "0",
          })
          if (_this.imgList.length < 3) {
            _this.imgList.push({ 'previewSrcr': '', 'file': '', 'dialogVisible': false })
          }
          _this.$forceUpdate();
          _this.$set(_this.imgList, _this.imgList);
          _this.$set(_this.form, _this.form);

        }
        if (file) {
          reader.readAsDataURL(file);
        } else {
          _this.previewSrcr = "";
        }
      } else {
        _this.imgError = '图片获取错误'
      }


      // _this.uploadHander(0,file,function(pos,file,signature){
      //     let u = signature.host+'/'+signature.dir+'/'+file.name

      // })
    },
    uploadHander(pos, file, dirType, signature, callBack) {
      let _this = this;
      //去后端拿签名
      InterfaceService.uploadToOss(signature, file, dirType, pos, callBack)
    },
    reviewImg(index) {
      this.imgList[index].dialogVisible = true
    },
    clearImg(index) {
      this.isFirstSubmit = false;//上传过 则此标记为false
      // 存储被删除的ID
      if (this.imgList[index].id !== '') {
        this.delImgList.push({ attachId: this.imgList[index].id });
      }
      let threeIpt = this.imgList.every((item) => {
        return item.file !== ""
      });
      if (threeIpt && this.imgList.length == 3) {
        this.imgList.splice(index, 1, { 'previewSrcr': '', 'file': '', 'dialogVisible': false })
      } else {
        this.imgList.splice(index, 1)
      }
      // this.imgList[index] = { 'previewSrcr': '', 'file': '', 'dialogVisible': false }
      this.$forceUpdate();
      //清空input[file]
      let file = document.getElementById("masterImg" + index)
      file.value = "";

    },
    delFileInfo() {
      if (this.authorizationInfo.id) {
        this.delImgList.push({ attachId: this.authorizationInfo.id });
      }
      this.authorizationInfo = {};
    },
    goBack() {
      this.$router.go(-1);
    },

    // 查询反显信息
    getPurchaserMessage() {
      const params = {
        corpId: this.$route.query.corpId
      }
      InterfaceService.rejectQueryPurchaser(params, (data) => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.setAntiDisplay(data.respData);
          data.respData.acPurchaserInfoBean && this.antiDisplayDataAcPurchaserInfoBean(data.respData.acPurchaserInfoBean)
          data.respData.acCorpAttachInfoList && this.antiDisplayDataAcCorpAttachInfoList(data.respData.acCorpAttachInfoList)
          this.form = Object.assign(this.form, data.respData.acCorpFinInfoBean || {}, data.respData.corpAddrInfoRst || {});

          if (this.form.invoiceType == "") {
            this.form.invoiceType = [];
          } else if (this.form.invoiceType == "0") {
            this.form.invoiceType = ["0"];
          } else if (this.form.invoiceType == "1") {
            this.form.invoiceType = ["1"];
          } else {
            this.form.invoiceType = ["0", "1"];
          }
          this.registerAdvancedInfo = JSON.stringify(Object.assign({}, data.respData.acCorpFinInfoBean || {}, data.respData.corpAddrInfoRst || {}))
          this.getBusinessDepartmentList()
        } else {
          this.$message.error(data.respData.respMsg);
        }

      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      });
    },
    //  公司基本信息 - 经营期限-范围
    antiDisplayDataAcPurchaserInfoBean(data) {
      const FORM = {
        dealFrom: data.dealFromStr,
        dealTo: data.dealToStr,
        groupCompanyName: data.groupCompanyName,
        groupCompanyCode: data.groupCompanyCode,
      };
      this.form = Object.assign({}, this.form, FORM)
    },
    setAntiDisplay(data) {
      const FORM = {
        // 公司信息
        corpName: data.acCorpInfoBean.corpName, // 公司名称
        supCorpName: data.acCorpInfoBean.supCorpName, // 上级公司名称
        busiLicense: data.acCorpInfoBean.busiLicense, // 统一社会信用代码
        corpTypeName: data.acCorpInfoBean.corpTypeName, // 企业类型：
        establishDt: data.acCorpInfoBean.establishDtStr, // 成立日期：
        legalRepresent: data.acCorpInfoBean.legalRepresent, // 法人代表
        legalCertNo: data.acCorpInfoBean.legalCertNo, // 法人证件号
        registCapital: data.acCorpInfoBean.registCapital, // 注册资本
        taxpayerType: data.acCorpInfoBean.taxpayerType, // 纳税人资格
        shortCorpName: data.acCorpInfoBean.shortCorpName, // 注册资本
      }
      let adminInfo = {};
      let list = data.acCorpContactInfoList || [];
      list.forEach(item => {
        if (item.contactType === "9") {
          adminInfo = {
            adminName: item.name || "",
            adminEmail: item.email || "",
            adminMobile: item.mobile || "",
            adminCertNo: item.certNo || "",
            department: item.department || "",
            position: item.position || "",
            effectiveStartdate: item.effectiveStartdate || "",
            effectiveEnddate: item.effectiveEnddate || "",
          }
        }
      })
      this.form = Object.assign({}, this.form, adminInfo, FORM)
    },
    // 上传图片
    antiDisplayDataAcCorpAttachInfoList(data) {
      if (data) {
        this.imgList = [];
      }
      for (let i = 0, len = data.length; i < len; i++) {
        if (data[i]) {
          const itemUrl = data[i].attachContent || '';
          const url = itemUrl.slice(itemUrl.indexOf('/djc'), itemUrl.length)
          if (data[i].attachType === "0") {
            // if (!!this.imgList[i]) {
            //    const itemUrl = data[i].attachContent || '';
            //    this.imgList[i].previewSrcr = itemUrl;
            //    this.imgList[i].file = { name: itemUrl.slice(itemUrl.lastIndexOf('/') + 1, itemUrl.length) };
            //    this.imgList[i].id = data[i].attachId;
            //    const url = itemUrl.slice(itemUrl.indexOf('/etrade'), itemUrl.length)
            //    this.form.attachList[i] = `#url#${url}`;
            this.imgList.push({
              previewSrcr: itemUrl,
              file: { name: itemUrl.slice(itemUrl.lastIndexOf('/') + 1, itemUrl.length) },
              id: data[i].attachId,
            })
            this.form.attachList[i] = {
              "attachUrl": `#url#${url}`,
              "attachType": `0`,
            };
          } else if (data[i].attachType === "2") {
            this.form.attachList[i] = {
              "attachUrl": `#url#${url}`,
              "attachType": `2`,
            };
            this.authorizationInfo = {
              attachName: data[i].attachName,
              id: data[i].attachId || "",
              creTm: data[i].creTm,
            }
          }
        }
        // }
      }
      console.log(this.form.attachList);

      if (this.imgList.length < 3) {
        this.imgList.push({ 'previewSrcr': '', 'file': '', 'dialogVisible': false })
      }
      // this.imgList = storeImgList
    },
    // 格式化imgList URL名字
    formatImgUrlName(imgList) {
      for (let len = imgList.length, i = len - 1; i >= 0; i--) {
        // 如果有ID表示不是新增或者修改 不进入这次更改list
        if (!imgList[i].attachId && imgList[i].attachURL) {
          imgList[i].attachContent = imgList[i].attachURL
          delete imgList[i].attachURL
        } else {
          // 移除未被修改的图片
          imgList.splice(i, 1);
        }
      }
    },
    // 驳回 - 提交
    rejectSubmit() {
      let params = JSON.parse(JSON.stringify(this.form));
      // 转换url名称
      // params.establishDt = params.establishDt.replace(/-/g, '/').substr(0, 10)
      // params.dealFrom = params.dealFrom && params.dealFrom.replace(/-/g, '/').substr(0, 10)
      // params.dealTo = params.dealTo && params.dealTo.replace(/-/g, '/').substr(0, 10)
      this.formatImgUrlName(params['attachList']);
      params.acCorpAttachInfoList = params['attachList']
      // 拼接 删除的图片
      params.acCorpAttachInfoList = params.attachList.concat(this.delImgList)
      // 移除 旧图片list
      delete params['attachList']

      params.corpId = this.$route.query.corpId
      params.prodType = params.prodType.toString()
      this.groupCompanyList.forEach(item => {
        if (item.code === params.groupCompanyCode) {
          params.groupCompanyName = item.value
        }
      })
      console.log(params, this.form, '===================par');
      InterfaceService.rejectUpdatePurchaser(params, (data) => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$router.push({
            path: "/registerAdvanced",
            query: {
              isReject: true,
              corpId: this.$route.query.corpId,
              corpName: this.form.corpName,
            }
          });
          this.$setRootScope('registerAdvancedInfo', this.registerAdvancedInfo)
        } else {
          this.$message.error(data.respData.respMsg);
        }

      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      });
    },
    handleChangeAdminInfo(ev) {
      if (this.isAdmin == "1") {
        if (Object.keys(this.isAdminInfo).length == 0) {
          InterfaceService.accountInfo({ acctId: this.userInfo.acctId }, (data) => {
            if (data && data.respData && data.respData.respCode === "0000") {
              this.isAdminInfo = data.respData || {};
              this.form.adminName = this.isAdminInfo.accName;
              this.form.adminCertNo = this.isAdminInfo.certNo;
              this.form.adminMobile = this.isAdminInfo.mobile;
              this.form.adminEmail = this.isAdminInfo.email;
              this.form.department = this.isAdminInfo.dept || '';
              this.form.position = this.isAdminInfo.title || '';
              this.form.effectiveStartdate = this.isAdminInfo.effectiveStartdate || '';
              this.form.effectiveEnddate = this.isAdminInfo.effectiveEnddate || '';
            } else {
              this.$message.error(data.respData.respMsg);
            }
          }, data => { }, () => {
            this.isLoading = true;
          }, () => {
            this.isLoading = false;
          });
        }
        this.form.adminName = this.isAdminInfo.accName;
        this.form.adminCertNo = this.isAdminInfo.certNo;
        this.form.adminMobile = this.isAdminInfo.mobile;
        this.form.adminEmail = this.isAdminInfo.email;
        this.form.department = this.isAdminInfo.dept || '';
        this.form.position = this.isAdminInfo.title || '';
        this.form.effectiveStartdate = this.isAdminInfo.effectiveStartdate || '';
        this.form.effectiveEnddate = this.isAdminInfo.effectiveEnddate || '';
      } else {
        this.form.adminName = "";
        this.form.adminCertNo = "";
        this.form.adminMobile = "";
        this.form.adminEmail = "";
        this.form.department = "";
        this.form.position = "";
        this.form.effectiveStartdate = "";
        this.form.effectiveEnddate = "";
      }
    },
  },
  mounted() {
    this.init();
    this.$setRootScope("registerPath", JSON.stringify({ path: this.$route.path, query: this.$route.query }));
  }
};
</script>

<style lang="scss" scoped>
p {
  margin-bottom: 20px;
}
a.link {
  display: inline-block;
  vertical-align: middle;
  padding: 0 10px;
  color: #7ab7e8;
}

.inner-container {
  margin-bottom: 100px;
  font-size: 14px;
}

.form-inline-item {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;

  & > div {
    width: 40%;
    flex-shrink: 0;
  }

  &.col-3 > div {
    width: 32%;
  }
}
.regist-perfect-info {
  /deep/ .el-form-item__label {
    font-size: 12px;
  }
  /deep/ .el-checkbox {
    min-width: 138px;
    + .el-checkbox {
      margin-left: 0px;
    }
  }
  /deep/ .el-date-editor.el-input {
    width: 100%;
  }
}

.form-item {
  position: relative;
  line-height: 40px;

  .float-right {
    position: absolute;
    top: 0;
    right: 10px;
  }
}

.info-panel {
  margin-top: 30px;
}

.brand-other {
  margin-top: 20px;
  padding-left: 30px;
}

.info-panel-title {
  display: inline-block;
  border-left: 3px solid #000;
  margin: 10px 0;
  padding: 0 10px;
  font-weight: bold;
  color: rgb(41, 41, 41);
  i {
    font-size: 12px;
    color: rgb(143, 143, 143);
  }
  a {
    font-size: 12px;
    text-decoration: underline;
    color: #7ab7e8;
  }
}

.info-panel-content {
  padding-bottom: 0;
  background: #fff;
  &.bottom {
    padding-bottom: 20px;
  }
}

.info-master-img {
  .img-item {
    position: relative;
    display: inline-block;
    width: 120px;
    height: 120px;
    vertical-align: middle;
    margin-right: 20px;
    border: 1px dashed #ccc;
    border-radius: 2px;
  }

  .img-item-add {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    font-size: 30px;
    text-align: center;
    color: #ccc;
    position: relative;
    overflow: hidden;
    i {
      cursor: pointer;
    }

    input[type="file"] {
      display: none;
    }

    img {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      pointer-events: none;
    }
  }

  .img-item-cover {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0);

    .img-item-top,
    .img-item-bottom {
      display: none;
      position: absolute;
      width: 100%;
      padding: 10px;
      text-align: center;
      background: rgba(167, 166, 166, 0.2);
    }

    .img-item-top {
      top: 0;
    }

    .img-item-bottom {
      bottom: 0;
      padding: 0 10px;

      a {
        display: inline-block;
        width: 46%;
        padding: 10px 5px;
        vertical-align: middle;
        color: rgb(88, 167, 231);
      }
    }
  }

  .img-item:hover {
    .img-item-cover {
      background: rgba(255, 255, 255, 0.2);
    }

    .img-item-top,
    .img-item-bottom {
      display: block;
    }
  }

  img {
    width: 100%;
    height: 100%;
    border: none;
  }

  .img-item.has-img {
    border: none;

    .img-item-add {
      //display: none;
    }

    &:hover .img-item-add {
      display: flex;
    }
  }
}

.info-detail {
  position: relative;
  z-index: 0;
}

.info-detail-img {
  padding: 10px 30px;
  border: 1px solid #e0e0e0;
  border-top: none;
  line-height: 30px;
  background: #f5f5f5;

  button {
    float: right;
    margin: 0 5px;
  }
}

.model-table {
  thead td {
    text-align: center;
  }

  td {
    padding: 10px;
    padding-left: 0;
  }
}

.apply-dialog {
  line-height: 25px;

  a {
    text-decoration: underline;
    color: #7ab7e8;
  }
}

.fix-bottom {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  padding: 20px;
  text-align: center;
  background: rgba(79, 82, 90, 0.8);

  button {
    width: 150px;
  }
}

.form-upload-text {
  height: 40px;
  line-height: 40px;
  font-size: 12px;
  color: #888;

  .form-upload-text-left {
    display: inline-block;
    width: 134px;
    padding-right: 12px;
    text-align: right;
  }
  .form-upload-text-right {
    display: inline-block;
    width: 100%;
    padding-left: 195px;
  }
}

.form-upload-content {
  margin-bottom: 22px;
  .info-master-img {
  }
}
.continue {
  text-align: center;
  margin: 0 auto 0;
}
.neet-upload-upfile {
  box-sizing: border-box;
  display: flex;
  border-top: 1px solid transparent;

  &.disabled {
    /deep/ .center .blue {
      // background: #dddddd !important;
      // color: #a9a9a9 !important;
    }
  }

  & > li {
    width: 87%;

    &:nth-child(1) {
      .input-file-p {
        border: 1px solid #dcdfe6;
        box-sizing: border-box;
        padding: 0 12px;
        color: #606266;
        display: block;
        display: flex;
        flex-wrap: wrap;
        min-height: 40px;

        span {
          height: 38px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        & > .gray {
          color: #c0c4cc;
          font-size: 12px;
          outline: none;
          height: 38px;
        }

        .el-tag {
          margin: 4px;
          height: 30px;
        }
      }
    }

    &:nth-child(2) {
      width: 15%;
    }

    &:nth-child(3) {
      width: 33%;
    }

    .el-button--default {
      height: 40px;
      margin-left: 4px;
    }
  }

  .el-button--primary {
    width: 119px;
    margin-right: 12px;
  }

  /deep/ .upfile-container {
    .center {
      label {
        width: 120px;
        background: linear-gradient(
          120deg,
          rgba(215, 176, 100, 1) 0%,
          rgba(236, 206, 139, 1) 100%
        );
        color: #fff !important;
        text-align: center;
        height: 40px;
      }
    }
  }
}
.isie {
  /deep/ .upfile-container {
    .center {
      label {
        height: 42px;
      }
    }
  }
}
.upload-cont {
  margin: 0 0 30px 134px;
}
.upload-title {
  background: #f5f5f5;
  border-bottom: 1px solid #fff;
  height: 35px;
  line-height: 35px;

  span {
    display: inline-block;
    padding-left: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  & span:nth-child(1) {
    width: 65%;
  }
  & span:nth-child(2) {
    width: 25%;
  }
}
.authorization {
  /*margin-top: 30px;*/
  margin-bottom: 0 !important;
}
.upfile-container {
  text-align: left;
  .center {
    input {
      width: 0;
      height: 0;
      overflow: hidden;
      opacity: 0;
      border: 0;
      padding: 0;
    }
    label {
      float: left;
      cursor: pointer;
      user-select: none;
      outline: none;
    }
  }
  ::-webkit-scrollbar {
    width: 1px !important;
  }
}
.info-panel-content {
  /deep/ .el-form-item__error {
    background: #fff;
    width: 100%;
    height: 20px;
  }
}
/deep/ .el-select {
  width: 100%;
}
</style>