<template>
  <div class="changeMobile-wrap">
    <Header :is-white-bg="isWhiteBg"></Header>
    <div class="pageTop" :class="{purpleBg: bigInfrastructure}">
      <div class="logo fl">
        <img src="@/assets/images/logo_s.png">
        <div class="company-info">
          <p>{{userInfo.bs == 'B' ? "采购":"供应"}}商管理中心</p>
        </div>
        <div class="company-info f16" style="padding-left: 130px;">
          <p class="go-index hand" @click="goIndex">建材集采</p>
        </div>
      </div>
    </div>
    <div class="changeMobile-wrap-inner" id="changeMobile-wrap-inner">
      <div class="contain inner-container">
        <Breadcrumb v-if="breadcrumb && breadcrumb.length" :breadcrumbList="breadcrumb" @refresh="handleGoBack()"></Breadcrumb>
        <div class="errorMsg" v-if="errorMsg.false">
          <img src="../../assets/images/login/notice.png" alt="">{{errorMsg.false}}
        </div>
        <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="form" onsubmit="return false;">
          <p class="hint">
            <i class="el-icon-info"></i>
            请确保您输入的新手机号能正常接收验证码，新手机号才能生效。
          </p>
          <el-form-item label="姓名：">
            <span>{{userInfo.acctName}}</span>
          </el-form-item>
          <el-form-item label="新手机号：" prop="mobile">
            <el-input type="text" v-model="ruleForm.mobile" @keyup.native="checkNumber($event)" placeholder="请输入手机号码" clearable></el-input>
            <div class="error-msg red" v-if="errorMsg.mobile">{{errorMsg.mobile}}</div>
          </el-form-item>
          <el-form-item label="验证码：" prop="validateCode">
            <div class='validate-code'>
              <ValidateCode :is-show-validate="true" @received="getCode" :update="updateCode"></ValidateCode>
              <div class="error-msg red" v-if="errorMsg.validateCode">{{errorMsg.validateCode}}</div>
            </div>
          </el-form-item>
          <el-form-item class="ver-mobile" label="手机验证码：" prop="identifyCode">
            <div class="ver-mobile-input">
              <PhoneCode :is-show-phone-code="true" :update="updateCode" :type="'1'" :disable="!ruleForm.validateCode || !ruleForm.mobile" :phone="ruleForm.mobile" :imgCode="ruleForm.validateCode" :origTxCode="'changePhone'" @error="getError" @received="getPhoneCode"></PhoneCode>
              <div class="error-msg red" v-if="errorMsg.identifyCode">{{errorMsg.identifyCode}}</div>
            </div>
          </el-form-item>
          <div class="tc">
            <el-button type="primary" class="large-btn" @click="onSubmit('rules')">确认</el-button>
          </div>
        </el-form>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import {
  mapActions,
  mapState
} from 'vuex'
import SearchBar from '@/components/SearchBar'
import Header from '@/components/base/Header'
import Loading from '@/components/base/Loading'
import ValidateCode from '@/components/base/ValidateCode'
import PhoneCode from '@/components/base/PhoneCode';
import Breadcrumb from "@/components/base/Breadcrumb";
import {
  InterfaceService
} from '@/services/api'
import accountMixin from "@/mixins/account"

export default {
  props: ['isShowPhoneCode', 'update', 'phone', 'disable'],
  mixins: [accountMixin],
  components: {
    SearchBar,
    Header,
    Loading,
    ValidateCode,
    Breadcrumb,
    PhoneCode
  },
  data() {

    return {
      breadcrumb: [],
      updateCode: 0,
      number: 4,
      //imgUrl: this.$getConfig().IMAGE_SERVLET,
      validateCode: '',// 图片验证码
      isWhiteBg: true,
      pageName: '修改手机号',
      searchType: 5,
      mobile: '',// 手机号
      isLoading: false,
      errorMsg: {},
      identifyCode: '',// 手机验证码
      ruleForm: {
        mobile: '',
        validateCode: '',
        identifyCode: ''
      },
      rules: {
        mobile: [
          { required: true, message: '请填写手机号', trigger: 'blur' },
          { pattern: this.$commonExpression('mobile'), message: '手机号格式不正确', trigger: "blur" }
        ],
        validateCode: [],
        identifyCode: [{ required: true, message: "请输入手机验证码", trigger: 'blur' }]
      }
    }
  },
  computed: {
    isLogin() {
      return this.$store.state.isLogin
    },
    userInfo() {
      // console.log(this.$store.state.LoginedUser.custName)
      return this.$store.state.userInfo
    }

  },
  methods: {
    ...mapActions(['setUserInfoAction']),
    goIndex() {
      this.$router.push("/");
    },
    checkNumber() {
      this.ruleForm.mobile = this.ruleForm.mobile.replace(/\D+/, '')
    },
    getCode: function (code) {
      this.ruleForm.validateCode = code
      code && (delete this.errorMsg['validateCode']);
      this.$forceUpdate();
    },
    getPhoneCode(identifyCode) {
      this.ruleForm.identifyCode = identifyCode
      this.$forceUpdate();
    },
    // 判断图形验证码是否正确
    getError(msg) {

      this.ruleForm.validateCode = '';
      this.updateCode++;
      this.$set(this.errorMsg, 'validateCode', msg);
      this.$forceUpdate();
    },
    onSubmit(rules) {
      this.errorMsg = {}
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          var params = {
            'mobile': this.ruleForm.mobile,
            'validateCode': this.ruleForm.validateCode,
            'identifyCode': this.ruleForm.identifyCode
          }
          InterfaceService.changeMolile(params, (data) => {
            console.log(data)
            let res = data.respData
            if (res.respCode == '0000') {
              //去缓存里更改userInfo
              let userInfo = JSON.parse(this.$getRootScope('user'))
              userInfo.mobileNo = this.ruleForm.mobile
              this.$setRootScope('user', JSON.stringify(userInfo))
              this.setUserInfoAction(userInfo)
              this.$router.push({
                path: "/changeSuccess",
                query: {
                  type: '1',
                  mobile: this.ruleForm.mobile
                }
              });
            } else if (res.respCode == 'F000002') {
              this.$set(this.errorMsg, 'validateCode', res.respMsg);
            } else if (res.respCode == 'F000003' || res.respCode == 'F000005') {
              this.$set(this.errorMsg, 'identifyCode', res.respMsg);
              if (res.respCode == 'F000005') {
                this.updateCode++
              }
            } else if (res.respCode == 'S0001' || res.respCode == 'MEM0054') {
              this.$set(this.errorMsg, 'false', '修改手机号失败，请重试');
            } else if (res.respCode == 'MEM0025' || res.respCode == 'MEM0051' || res.respCode == 'MEM0052' || res.respCode == 'MEM0053') {
              this.$set(this.errorMsg, 'mobile', res.respMsg);
              return
            }
          })
        } else {
          console.log('error submit!!');
          return false;
        }
      });

    },
    handleGoBack() {
      this.$router.go(-1);
    },
  },
  watch: {
  },
  mounted() {
    const breadcrumb = JSON.parse(this.$getRootScope('breadcrumb') || '[]')
    this.breadcrumb = (breadcrumb && breadcrumb.length) && breadcrumb || []
  },
  destroyed() {
    this.$removeRootScope('breadcrumb')
  }
}
</script>

<style scoped lang="scss">
/deep/ .el-form-item__label {
  color: #888888;
}

.errorMsg {
  background-color: #ffdfe0;
  line-height: 20px;
  font-size: 14px;
  color: #e8323e;
  position: relative;
  padding: 10px 10px 10px 35px;
  margin: 60px auto;
  width: 55%;
  text-align: center;
  img {
    position: absolute;
    top: 12px;
    left: 240px;
  }
}

.changeMobile-wrap .search-bar-container {
  height: 100%;
  padding-top: 15px;
}

.changeMobile-wrap-inner {
  height: 710px;
  border-top: 2px solid #ffd64e;
}

.changeMobile-wrap .contain {
  position: relative;
  height: 100%;

  /deep/ .el-form-item.is-required {
    .el-form-item__label:before {
      display: none;
    }
  }
}

.changeMobile-wrap .form {
  width: 650px;
  position: absolute;
  right: 0;
  top: 0;
  left: 0;
  bottom: 0;
  margin: auto;
  margin-top: 90px;
  .hint {
    font-size: 14px;
    font-weight: 900;
    margin-bottom: 30px;
    margin-left: 100px;

    i {
      color: #5dc539;
      font-size: 16px;
    }

    .phone {
      color: red;
      font-weight: 700;
    }

    span:nth-last-child(1) {
      font-weight: 700;
      color: #989898;
    }
  }
}
.pageTop {
  position: relative;
  width: 100%;
  height: 60px;
  margin: 0 auto;
  background: linear-gradient(
    145deg,
    rgba(215, 176, 100, 1) 0%,
    rgba(236, 206, 139, 1) 100%
  );
  opacity: 1;
  &.purpleBg {
    background: linear-gradient(134deg, #6424de 0%, #a36df8 100%);
  }
  .logo {
    position: absolute;
    left: 0;
    bottom: 0;
    right: 0;
    margin: auto;
    width: 1190px;
    height: 60px;
    line-height: 60px;
  }
  img {
    vertical-align: middle;
  }

  .company-info {
    display: inline-block;
    padding: 0 4px;
    font-size: 18px;
    line-height: 60px;
    vertical-align: top;
    color: #ffffff;
    .hl22 {
      line-height: 22px;
      font-size: 14px;
    }
  }
}
.go-index {
  padding: 0 20px;
  &:hover {
    font-weight: 600;
    color: #fae2a5;
    background: linear-gradient(
      180deg,
      rgba(16, 16, 24, 1) 0%,
      rgba(90, 88, 88, 1) 100%
    );
  }
}
</style>