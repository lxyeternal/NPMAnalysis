<template>
  <div class="forgetpwd-wrap">
    <Header :is-white-bg="isWhiteBg"></Header>
    <div class="pageTop" :class="{purpleBg: bigInfrastructure}">
      <div class="logo fl">
        <img src="@/assets/images/logo_s.png">
        <div class="company-info">
          <p v-if="userInfo.bs == 'B'">采购商管理中心</p>
          <template v-else>
            <p v-if="userInfo.contractCorpType === 'construction'">施工单位管理中心</p>
            <p v-if="userInfo.contractCorpType === 'supervisory'">监理单位管理中心</p>
            <p v-else>供应商管理中心</p>
          </template>
        </div>
        <div class="company-info f16" style="padding-left: 130px;">
          <p class="go-index hand" @click="goIndex">建材集采</p>
        </div>
        <div class="company-info fr">
          <p class="hl22" style="margin-top: 10px;">{{userInfo.corpName}}</p>
          <p class="hl22 f12"> {{userInfo.acctName}}</p>
        </div>
      </div>
    </div>
    <div class="forgetpwd-wrap-inner">
      <div class="contain inner-container register-wrapper-inner">
        <div class="success"><i class="el-icon-check"></i></div>
        <div>修改成功</div>
        <div class="message" v-if="type == '1'">已设置{{userInfo.mobileNo}}为您的手机号</div>
        <div class="message" v-if="type == '2'">已设置{{userInfo.email}}为您的邮箱</div>
        <div class="goBack" @click="goBack()">返回</div>
      </div>
    </div>
  </div>
</template>
<script>
import SearchBar from '@/components/SearchBar'
import Header from '@/components/base/Header'
import accountMixin from "@/mixins/account"

export default {
  components: {
    SearchBar,
    Header
  },
  mixins: [accountMixin],
  data() {
    return {
      isWhiteBg: true,
      type: ''
    }
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo
    }
  },
  methods: {
    goIndex() {
      this.$router.push("/");
    },
    goBack() {
      console.log(1111111111);
      // this.$router.go(-1);
      // if (this.bigInfrastructure) {
      //   this.$router.push({ path: "/bigInfrastructureCenter/bigAccountInfo" });
      //   return
      // }
      if (this.userInfo.bs == 'B') {
        this.$router.push({ path: "/purchaserCenter/accountInfo" });
      } else {
        this.$router.push({ path: "/vendorCenter/accountInfo" });
      }

    }
  },
  mounted() {
    this.type = this.$route.query.type;   // 1为手机号，2为邮箱
  }
}
</script>

<style lang="scss" scoped>
.success {
  margin: 100px auto 30px;
  width: 58px;
  height: 58px;
  border-radius: 29px;
  background: #5ea509;
  font-size: 38px;

  i {
    margin-top: 8px;
    color: #fff;
  }
}

.message {
  font-size: 12px;
  margin: 20px;
}

.pageTop {
  position: relative;
  width: 100%;
  height: 60px;
  margin: 0 auto;
  background: linear-gradient(
    145deg,
    rgba(215, 176, 100, 1) 0%,
    rgba(236, 206, 139, 1) 100%
  );
  opacity: 1;
  &.purpleBg {
    background: linear-gradient(134deg, #6424de 0%, #a36df8 100%);
  }
}

.pageTop .logo {
  position: absolute;
  left: 0;
  bottom: 0;
  right: 0;
  margin: auto;
  width: 1190px;
  height: 60px;
  line-height: 60px;
}

.pageTop {
  img {
    vertical-align: middle;
  }

  .company-info {
    display: inline-block;
    padding: 0 4px;
    font-size: 18px;
    line-height: 60px;
    vertical-align: top;
    color: #ffffff;
    .hl22 {
      line-height: 22px;
      font-size: 14px;
    }
  }
}
.goBack {
  font-size: 12px;
  color: #0082ff;
  cursor: pointer;
  margin-top: 20px;
}
.forgetpwd-wrap-inner {
  height: 800px;
  text-align: center;
  font-size: 20px;
  font-weight: 700;
  border-top: 2px solid #ffd64e;
}
.go-index {
  padding: 0 20px;
  &:hover {
    font-weight: 600;
    color: #fae2a5;
    background: linear-gradient(
      180deg,
      rgba(16, 16, 24, 1) 0%,
      rgba(90, 88, 88, 1) 100%
    );
  }
}
</style>
