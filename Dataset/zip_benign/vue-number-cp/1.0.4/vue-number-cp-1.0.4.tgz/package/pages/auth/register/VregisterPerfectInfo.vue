<template>
  <div>
    <Header :is-white-bg="false"></Header>
    <SearchBar :is-white-bg="true" :search-type="7" :progress="'资料完善'" :is-border-bottom="true" :product-create-process="1"></SearchBar>
    <div class="inner-container regist-perfect-info">
      <el-form ref="form" :model="form" :rules="rules" label-width="134px">
        <!-- 公司信息 -->
        <div class="info-panel">
          <p class="info-panel-title">公司信息</p>
          <div class="info-panel-content">
            <div class="form-inline-item">
              <el-form-item label="公司名称：" prop="corpName" ref="corpName">
                <el-input v-model="form.corpName" disabled placeholder="" @focus="checkForm('corpName',$event)" @blur="handleSearchCorp"></el-input>
                <div class="el-form-item__error" v-if="errorRules['corpName']">
                  {{ errorRules["corpName"] }}
                </div>
              </el-form-item>
              <el-form-item label="统一社会信用代码：" prop="busiLicense" ref="busiLicense">
                <el-input v-model="form.busiLicense" disabled placeholder="" @focus="checkForm('busiLicense')" maxlength="18"></el-input>
                <div class="el-form-item__error" v-if="errorRules['busiLicense']">
                  {{ errorRules["busiLicense"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="法人代表：" prop="legalRepresent" ref="legalRepresent">
                <el-input disabled v-model="form.legalRepresent" placeholder="请输入" @focus="checkForm('legalRepresent')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['legalRepresent']">
                  {{ errorRules["legalRepresent"] }}
                </div>
              </el-form-item>
              <el-form-item label="法人证件号：" prop="legalCertNo" ref="legalCertNo">
                <el-input type="text" v-model="form.legalCertNo" placeholder="请输入" @focus="checkForm('legalCertNo')" maxlength="30"></el-input>
                <div class="el-form-item__error" v-if="errorRules['legalCertNo']">
                  {{ errorRules["legalCertNo"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="注册资本（万元）：" prop="registCapital" ref="registCapital">
                <el-input type="text" v-model="form.registCapital" placeholder="请输入" @focus="checkForm('registCapital')" maxlength="100"></el-input>
                <div class="el-form-item__error" v-if="errorRules['registCapital']">
                  {{ errorRules["registCapital"] }}
                </div>
              </el-form-item>
              <el-form-item label="纳税人资格：" prop="taxpayerType">
                <el-radio-group v-model="form.taxpayerType">
                  <el-radio label="0">一般纳税人</el-radio>
                  <el-radio label="1">小规模纳税人</el-radio>
                </el-radio-group>
                <div class="el-form-item__error" v-if="errorRules['taxpayerType']">
                  {{ errorRules["taxpayerType"] }}
                </div>
              </el-form-item>
            </div>

            <div class="form-inline-item">
              <el-form-item label="企业类型：" prop="corpTypeName" ref="corpTypeName">
                <el-input v-model="form.corpTypeName" placeholder="请输入" @focus="checkForm('corpTypeName')" maxlength="32"></el-input>
                <div class="el-form-item__error" v-if="errorRules['corpTypeName']">
                  {{ errorRules["corpTypeName"] }}
                </div>
              </el-form-item>
              <el-form-item label="成立日期：" prop="establishDt" ref="establishDt">
                <el-date-picker value-format="yyyy-MM-dd" v-model="form.establishDt" size="" type="date" placeholder="请选择日期" @change="checkForm('establishDt')">
                </el-date-picker>
                <div class="el-form-item__error" v-if="errorRules['establishDt']">
                  {{ errorRules["establishDt"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="公司简称：" prop="shortCorpName" ref="shortCorpName">
                <el-input v-model="form.shortCorpName" maxlength="6" placeholder="请输入" @focus="checkForm('shortCorpName')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['shortCorpName']">
                  {{ errorRules["shortCorpName"] }}
                </div>
              </el-form-item>
              <el-form-item label="上级公司名称：" prop="supCorpName" ref="supCorpName">
                <el-input v-model="form.supCorpName" placeholder="请输入" @focus="checkForm('supCorpName')"></el-input>
                <div class="el-form-item__error" v-if="errorRules['supCorpName']">
                  {{ errorRules["supCorpName"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-upload-text">
              <span class="form-upload-text-left"><i class="red">*</i> 营业执照：</span><span class="form-upload-right">请上传工商营业执照、组织机构代码证、税务登记证或三证合一的营业执照 (单张图片大小不超过1M，建议方形尺寸500*500，jpg或png格式)</span>
            </div>
            <div class="form-upload-content">
              <el-form-item label="" prop="attachList" ref="attachList">
                <div class="info-master-img">
                  <div class="img-item" :class="{ 'has-img': img.previewSrcr }" v-for="(img, index) in imgList" :key="index">
                    <div class="img-item-cover">
                      <div class="img-item-add">
                        <label :for="'masterImg' + index">
                          <i class="el-icon-plus"></i>
                        </label>
                        <img v-if="img.previewSrcr" :src="img.previewSrcr" />
                        <input :id="'masterImg' + index" type="file" ref="imgFileBtn" @change="pushImg($event, index,'imgList')" />
                      </div>
                      <div class="img-item-bottom" v-if="img.previewSrcr">
                        <a @click="clearImg(index,'imgList')">删除</a>
                        <a @click="img.dialogVisible = true">预览</a>
                      </div>
                    </div>
                    <el-dialog title="" :visible.sync="img.dialogVisible">
                      <img :src="img.previewSrcr" alt="" />
                    </el-dialog>
                  </div>
                </div>
                <div class="el-form-item__error">{{ imgListImgError }}</div>
              </el-form-item>
            </div>

            <!-- 供应商 -->
            <div class="form-item" style="width:60%;">
              <el-form-item label="营业期限：" prop="dealFrom" ref="dealFrom">
                <el-row>
                  <el-col :span="11">
                    <el-date-picker value-format="yyyy-MM-dd" v-model="form.dealFrom" size="" type="date" placeholder="开始日期">
                    </el-date-picker>
                  </el-col>
                  <el-col :span="2" class="tc">~</el-col>
                  <el-col :span="11">
                    <el-date-picker value-format="yyyy-MM-dd" v-model="form.dealTo" size="" type="date" placeholder="结束日期">
                    </el-date-picker>
                  </el-col>
                </el-row>
                <div class="el-form-item__error" v-if="errorRules['dealFrom']">
                  {{ errorRules["dealFrom"] }}
                </div>
              </el-form-item>
            </div>
            <template>
              <div style="margin-bottom: 22px;line-height: 40px;">
                <span style="float: left;width: 134px; text-align: right;font-size: 12px">
                  <span class="red" style="padding-right: 2px;">*</span><span style="color: #888">经营品类：</span>
                </span>
                <div style="width: 945px;float: left">
                  <!-- <multipleDropdownTree @categoryInfo="getCategoryInfo" :width="'1054px'" :dataList="cateList"></multipleDropdownTree> -->
                  <DropdownTree ref="dropdownTree" @categoryInfo="getCategoryInfo" :dataList="cateList" :width="'1054px'" :bodyWidth="'1054px'"></DropdownTree>
                  <div style="clear: both"></div>
                </div>
                <div style="clear: both"></div>
              </div>
            </template>
          </div>
        </div>

        <!-- 经营品牌 -->
        <div class="info-panel border-EEEEEE" v-if="!(userInfo && userInfo.contractCorpType)">
          <p class="info-panel-title">
            <span>经营品牌</span>
            <strong class="blue hand add-brand" @click="handleAddBrandItem">添加品牌</strong>
          </p>
          <ul class="brand-management-ul">
            <li v-for="(item, idx) in form.brandList" :key="idx">
              <h1>
                <span>经营品牌{{idx + 1}}</span>
                <strong class="blue hand add-brand" v-if="form.brandList && form.brandList.length > 1" @click="handleDeleteBrandItem(idx)">删除</strong>
              </h1>
              <div class="center">
                <div class="form-inline-item">
                  <el-form-item label="品牌中文名：" :prop="`brandList.${idx}.brandNameCn`" :ref="`brandList.${idx}.brandNameCn`" :rules="isConstruction != '1' ? {
                      required: true, message: '必填', trigger: 'blur'
                    } : {}">
                    <el-input v-model="item.brandNameCn" placeholder="请输入" :maxlength="64"></el-input>
                  </el-form-item>
                  <!-- <div class="upfile-brand-name">
                    <span><i class="red">*</i>品牌英文名：</span>
                    <el-input v-model="item.brandENNmae" placeholder="请输入" :maxlength="64"></el-input>
                  </div> -->
                  <el-form-item label="品牌英文名：" :prop="`brandList.${idx}.brandNameEn`" :ref="`brandList.${idx}.brandNameEn`" :rules="isConstruction != '1' ? {
                      required: true, message: '必填', trigger: 'blur'
                    } : {}">
                    <el-input v-model="item.brandNameEn" placeholder="请输入" :maxlength="64"></el-input>
                  </el-form-item>
                </div>
                <div class="logo-item">
                  <div class="head-logo">
                    <i class="red" v-if="isConstruction != '1'">*&nbsp;</i>
                    <span>品牌logo</span>
                    <UpfileComponent ref="upfileRef" :immediateClearList="true" :fileSize="1048576" :fileSizeMsg="'上传文件不能超过1M, 请重新选择'" :btnName="'上传'" :dirName="`${new Date().getTime()}/`" :type="'2'" :appName="'MEM'" :fileTypes="'png,jpg,jpeg,bmp,gif'" :id="`logo${idx}`" @outputList="handleLogoUpFileResult($event, idx)"></UpfileComponent>
                  </div>
                  <div class="upfile-introduce">请上传品牌logo (单张图片大小不超过1M，建议方形尺寸500*500，jpg或png格式)</div>
                </div>
                <ol>
                  <li v-if="item.logoImgUrl">
                    <span>{{item.logoImgUrl.slice(item.logoImgUrl.lastIndexOf('/') + 1)}}</span>
                    <strong class="blue hand add-brand" @click="handleDelBrandLogoImg(idx)">删除</strong>
                  </li>
                  <li v-else class="un-data">
                    未上传附件!
                  </li>
                </ol>
              </div>
            </li>
          </ul>
        </div>

        <div class="info-panel">
          <p>
            <span class="info-panel-title">公司授权管理员</span>
          </p>
          <div class="info-panel-content">
            <div class="form-inline-item">
              <el-form-item label="本人是否为管理员：">
                <el-radio v-model="isAdmin" label="1" @change="handleChangeAdminInfo">是</el-radio>
                <el-radio v-model="isAdmin" label="0" @change="handleChangeAdminInfo">否</el-radio>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="管理员姓名：" prop="adminName" ref="adminName">
                <el-input v-model="form.adminName" placeholder="请输入姓名" @focus="checkForm('adminName')" :disabled="isAdmin == '1' && !!adminFormBackup.adminName" maxlength="10"></el-input>
                <div class="el-form-item__error" v-if="errorRules['adminName']">
                  {{ errorRules["adminName"] }}
                </div>
              </el-form-item>
              <el-form-item label="管理员身份证号：" prop="adminCertNo" ref="adminCertNo">
                <el-input v-model="form.adminCertNo" maxlength="18" placeholder="请输入身份证号" @focus="checkForm('adminCertNo')" :disabled="isAdmin == '1' && !!adminFormBackup.adminCertNo"></el-input>
                <div class="el-form-item__error" v-if="errorRules['adminCertNo']">
                  {{ errorRules["adminCertNo"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="管理员手机号：" prop="adminMobile" ref="adminMobile">
                <el-input v-model="form.adminMobile" placeholder="请输入手机号" @focus="checkForm('adminMobile')" :disabled="isAdmin == '1' && !!adminFormBackup.adminMobile"></el-input>
                <div class="el-form-item__error">
                  ※该手机号将作为管理员登录大家采的账号
                </div>
              </el-form-item>
              <el-form-item label="管理员邮箱：" prop="adminEmail" ref="adminEmail">
                <el-autocomplete ref="autocomplete" :fetch-suggestions="querySearch" :trigger-on-focus="false" v-model="form.adminEmail" placeholder="请输入邮箱" @focus="checkForm('adminEmail')" :disabled="isAdmin == '1' && !!adminFormBackup.adminEmail" :maxlength="64"></el-autocomplete>
                <div class="el-form-item__error" v-if="errorRules['adminEmail']">
                  {{ errorRules["adminEmail"] }}
                </div>
              </el-form-item>
              <el-form-item label="部门：" prop="department" ref="department">
                <el-input v-model="form.department" placeholder="请输入部门" @focus="checkForm('department')" maxlength="50"></el-input>
                <div class="el-form-item__error" v-if="errorRules['department']">
                  {{ errorRules["department"] }}
                </div>
              </el-form-item>
              <el-form-item label="职务：" prop="position" ref="position">
                <el-input v-model="form.position" placeholder="请输入职务" @focus="checkForm('position')" maxlength="40"></el-input>
                <div class="el-form-item__error" v-if="errorRules['position']">
                  {{ errorRules["position"] }}
                </div>
              </el-form-item>
            </div>
            <div class="form-item" style="width:60%;">
              <el-form-item label="授权委托期：" prop="effectiveStartdate">
                <el-row>
                  <el-col :span="11">
                    <el-date-picker value-format="yyyy-MM-dd" v-model="form.effectiveStartdate" size="" type="date" placeholder="开始日期">
                    </el-date-picker>
                  </el-col>
                  <el-col :span="2" class="tc">~</el-col>
                  <el-col :span="11">
                    <el-date-picker value-format="yyyy-MM-dd" v-model="form.effectiveEnddate" size="" type="date" placeholder="结束日期">
                    </el-date-picker>
                  </el-col>
                </el-row>
                <div class="el-form-item__error" v-if="errorRules['effectiveStartdate']">
                  {{ errorRules["effectiveStartdate"] }}
                </div>
              </el-form-item>
            </div>
          </div>
          <i class="red f12" style="margin: 30px 0px 0px 135px;display: block;">※需提供公司授权管理员以公司名义在大家采平台上进行操作的授权书。请点击【下载模板】，填写《大家采平台管理员授权委托书》并加盖公司公章后，上传授权书的PDF扫描件。</i>
          <el-form-item label="上传授权书：" :required="true" class="authorization">
            <el-col :span="21">
              <ul class="neet-upload-upfile" :class="{isie:isIE11}">
                <li>
                  <p class="input-file-p">
                    <span class="gray">
                      {{upfileResultName || '请上传授权书'}}
                    </span>
                    <!--<span v-else>{{authorizationInfo.name || ''}}</span>-->
                  </p>
                </li>
                <li>
                  <div class="upfile-container">
                    <div class="center">
                      <label class="blue">
                        <!-- <input name="my-upfile-component-input-name" type="file" @change="handleUpload" /> -->
                        <UpfileComponent ref="upfileRef" :immediateClearList="true" :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :btnName="'选择文件'" :dirName="`${new Date().getTime()}/`" :type="'13'" :fileTypes="this.uploadFileSuffix" :id="'123'" @outputList="handleUpFileResult($event)"></UpfileComponent>
                      </label>
                    </div>
                  </div>
                </li>
              </ul>
            </el-col>
            <el-col :span="3">
              <el-button size="small" style="width: 120px; height:40px;margin-left:10px;" @click="handleDownTemp()">下载模板</el-button>
            </el-col>
          </el-form-item>
          <div class="upload-cont">
            <div class="upload-title">
              <span>
                已上传文本
              </span>
              <span>
                上传时间
              </span>
              <span>
                操作
              </span>
            </div>
            <div class="upload-title tl" v-if="authorizationInfo.attachName">
              <span>
                {{authorizationInfo.attachName}}
              </span>
              <span>
                {{authorizationInfo.creTm}}
              </span>
              <span>
                <i class="hand blue" @click="delFileInfo">删除</i>
              </span>
            </div>
          </div>
        </div>
        <div class="continue">
          <el-button class="large-btn" type="primary" @click="submit('rules')">提交并继续</el-button>
        </div>
      </el-form>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import {
  mapActions,
  mapState
} from 'vuex'
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import Distpicker from "@/components/base/Distpicker";
import { InterfaceService } from '@/services/api'
import { DateUtil } from '@/utils/dateUtil';
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
import multipleDropdownTree from "@/components/order/multipleDropdownTree";
import { ImageUtil } from '@/utils/imageUtil';
import DropdownTree from "@/components/order/dropdownTreeTender";

export default {
  components: {
    Header,
    SearchBar,
    Loading,
    UpfileComponent,
    multipleDropdownTree,
    DropdownTree,
    Distpicker
  },
  data() {
    var validateDate = (rule, value, callback) => {
      if (value) {
        var thetime = value
        var curDate = new Date(Date.parse(localStorage.getItem('systemTime').replace(/-/g, "/")));
        if (thetime > curDate) {
          callback(new Error('请选择有效的成立日期'));
        } else {
          callback();
        }
      } else {
        callback();
      }
    };
    var validateDateSection = (rule, value, callback) => {
      if (value) {
        var thetimeFirst = value
        var thetimeSecond = this.form.dealTo
        if (thetimeSecond && thetimeFirst > thetimeSecond) {
          this.form.dealFrom = ''
          // this.form.dealTo = ''
          callback(new Error('请选择有效的营业期限'));
        } else {
          callback();
        }

      } else {
        callback();
      }
    };
    var validateEffectiveStartdate = (rule, value, callback) => {
      if (value) {
        var thetimeFirst = value
        var thetimeSecond = this.form.effectiveEnddate
        if (thetimeSecond && thetimeFirst > thetimeSecond) {
          this.form.effectiveStartdate = ''
          // this.form.dealTo = ''
          callback(new Error('请选择有效的授权委托期'));
        } else {
          callback();
        }

      } else {
        callback();
      }
    };
    var validatePass2 = (rule, value, callback) => {
      if (!/^[A-Za-z0-9]+([._\\-]*[A-Za-z0-9])*@([a-zA-Z0-9]+[-a-z0-9]*[a-zA-Z0-9]+.){1,63}[a-zA-Z0-9]+$/.test(value)) {
        callback(new Error('邮箱格式不正确'));
      } else {
        const mail = value || '',
          mailSuffix = mail.slice(mail.lastIndexOf('.') + 1, mail.length)

        const errorMailSuffix = JSON.parse(this.$getRootLocalStorage('errorMailSuffix') || '[]')
        console.log(mailSuffix, errorMailSuffix, 'errorMailSuffix');
        if (errorMailSuffix.includes(mailSuffix)) {
          callback(new Error('邮箱后缀不正确'));
          return
        }
        callback();
      }
    };
    var validateLegalCertNo = (rule, value, callback) => {
      if (value) {
        if (!this.corporateNameList.length || this.corporateNameList.length && this.corporateNameList[0].value.split(',').every(i => i !== this.form.corpName)) {
          if (!/^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/.test(value)) {
            callback(new Error('请输入正确法人证件号'));
          } else {
            callback();
          }
        } else {
          callback();
        }
      } else {
        callback();
      }
    };

    return {
      isLoading: false,
      isAdmin: "",
      categoryId: "",
      isAdminInfo: {},
      imgList: [
        { 'previewSrcr': '', 'file': '', 'dialogVisible': false },
      ],
      delImgList: [],
      ininBrandList: [],
      cateList: [{
        categoryId: "",
        fullName: "",
        parentId: "",
        originalId: "",
      }],
      dialogFormVisible: false,
      pcbCode: {},
      imgListImgError: '',
      brandListImgError: '',
      upfileResultName: '', // 上传文件名称
      form: {
        corpName: '',
        brandNameCn: '',
        supCorpName: '',
        busiLicense: '',
        corpTypeName: '',
        establishDt: '',
        legalRepresent: '',
        legalCertNo: '',
        taxpayerType: '',
        registCapital: '',
        prodType: [],
        prevPurchase: '',
        attachList: [],
        brandList: [{  // 经营品牌
          brandNameCn: '',//	String	Y	品牌中文名
          brandNameEn: '',//	String	N	品牌英文名
          logoImgUrl: '',//	String	N	品牌Logo地址
          brandCrudFlg: '', // （"insert:新增"，"update:更新"，"delete:删除"）
        }],
        dealFrom: '',
        dealTo: '',
        effectiveStartdate: '',
        effectiveEnddate: '',
        adminName: '',
        adminCertNo: '',
        adminMobile: '',
        adminEmail: '',
        department: '',
        shortCorpName: '',
        position: '',
      },
      brandList: [{
        'previewSrcr': '',
        'file': '',
        'dialogVisible': false,

      }],
      // 用于判断 管理员输入框是否 可以输入
      adminFormBackup: {
        adminName: '',
        adminCertNo: '',
        adminMobile: '',
        adminEmail: '',
      },
      rules: {
        shortCorpName: [
          {
            required: true,
            message: "必填"
          },
          { max: 6, message: "公司简称不得大于6个字", trigger: "blur" }
        ],
        corpName: [
          {
            required: true,
            message: "必填"
          },
          { max: 200, message: "公司名称不得大于200个字", trigger: "blur" }
        ],
        supCorpName: [
          { max: 200, message: "上级公司名称不得大于200个字", trigger: "blur" }
        ],
        busiLicense: [
          {
            required: true,
            message: "必填"
          },
          { pattern: /^[0-9A-Z]{18}/, message: '请输入正确的统一社会信用代码', trigger: "blur" }
        ],
        corpTypeName: [
          {
            required: true,
            message: "必填"
          }
        ],
        establishDt: [
          {
            required: true,
            message: "必填"
          },
          { validator: validateDate, trigger: 'blur' }
        ],
        brandNameCn: [
          {
            required: true,
            message: "必填"
          },
          { validator: validateDate, trigger: 'blur' }
        ],
        legalRepresent: [
          {
            required: true,
            message: "必填"
          },
          { max: 200, message: "法人代表不得大于200个字", trigger: "blur" }
        ],
        legalCertNo: [
          {
            required: true,
            message: "请填写法人证件号"
          },
          { validator: validateLegalCertNo, max: 30, message: "请输入正确法人证件号", trigger: "blur" }
        ],
        registCapital: [
          {
            required: true,
            message: "请填写注册资本"
          }
        ],
        taxpayerType: [
          {
            required: true,
            message: "请选择纳税人资格",
            trigger: "change"
          }
        ],
        dealFrom: [
          {
            required: true,
            message: "必填"
          },
          { validator: validateDateSection, trigger: 'blur' }
        ],
        effectiveStartdate: [
          {
            required: true,
            message: "必填"
          },
          { validator: validateEffectiveStartdate, trigger: 'blur' }
        ],
        brand: [
          {
            required: true,
            message: "请填写经营品牌"
          }
        ],
        attachList: [
          {
            required: true,
            message: "请上传营业执照附件"
          }
        ],

        adminName: [
          {
            required: true,
            message: "必填"
          },
          { pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]{2,200}$/, max: 200, message: "姓名设置不符合要求", trigger: "blur" }
        ],
        adminCertNo: [
          {
            required: true,
            message: "必填"
          },
          { pattern: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/, max: 20, message: "身份证号码不正确", trigger: "blur" }
        ],
        adminMobile: [
          {
            required: true,
            message: "必填"
          },
          { pattern: /^[1][0-9][0-9]{9}$/, max: 11, message: "手机号格式不正确", trigger: "blur" }
        ],
        adminEmail: [
          {
            required: true,
            message: "必填"
          },
          { validator: validatePass2, trigger: 'blur' },
        ],
        department: [
          {
            required: true,
            message: "必填"
          },
          { max: 50, message: "部门名称不得大于50个字", trigger: "blur" }
        ],
        position: [
          {
            required: true,
            message: "必填"
          },
          { max: 40, message: "职务名称不得大于40个字", trigger: "blur" }
        ],
        corporateNameList: [],
      },
      addressCode: {},
      errorRules: {},
      authorizationInfo: {},
      isFirstSubmit: true,
      isChangeImg: false,
      canClick: true,
      timer: '',
      uploadFileSuffix: '',
      focusCorpName: '',
      isReject: false, // 是否为驳回
      registerAdvancedInfo: {}, // 下一页面需要数据
      supplierBiddingInfo: {}, // 招募令 - 去完善注册进入

      isConstruction: '',
    };
  },
  computed: {
    isIE11() {
      let userAgent = navigator.userAgent;
      return userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; // ie11<11
    },
    userInfo() {
      return this.$store.state.userInfo
    },
  },
  methods: {
    ...mapActions(['setUserInfoAction']),
    querySearch(queryString, callback) {
      let commonMailbox = this.$commonMailbox()
      let results = this.$clone(commonMailbox)
      let value = ''
      if(queryString && queryString.indexOf('@') != -1){
        value = queryString.substring(0, queryString.indexOf('@'))
      }else{
        value = queryString
      }
      results.forEach((i,index) =>{
          i.value = value + '' + commonMailbox[index].value
      })
      callback(results)
      this.$refs.autocomplete.handleFocus()
    },
    init() {
      this.getPaymentMethod()
      if (this.$route.query.role == '2') {
        this.accountType = '0'
      } else {
        this.accountType = '1'
      }
      this.isConstruction = this.$route.query.isConstruction || ''
      if(!this.isConstruction){
        this.isConstruction = this.userInfo.corpList.find(i=> i.corpId == this.userInfo.corpId) && this.userInfo.corpList.find(i=> i.corpId == this.userInfo.corpId).isConstruction || ''
      }
      this.initSupplierBiddingInfo()
      this.getOrderConfiguration()
      this.errorRules = {}
      this.isReject = !!this.$route.query.corpId
      if (this.isReject) {
        this.getVendorMessage();
      } else {
        if (!this.userInfo) return
        // this.getCropId()
        this.form.corpName = this.userInfo.corpName || "";
        this.form.busiLicense = this.userInfo.busiLicense || "";
        this.form.legalRepresent = this.userInfo.legalRepresent || "";
        if (this.form.corpName) {
          this.handleSearchCorp(this.form.corpName)
        }
      }

    },

    /**
     * 添加品牌
     */
    handleAddBrandItem() {
      this.form && this.form.brandList && this.form.brandList.push({
        brandNameCn: '',
        brandNameEn: '',
        logoImgUrl: '',
      })
    },

    /**
     * 删除品牌
     * @param idx 数据下标
     */
    handleDeleteBrandItem(idx) {
      const brandUpfileListTemp = this.form && this.form.brandList && this.form.brandList || []
      this.$confirm(`此操作将永久删除${brandUpfileListTemp.brandNameCn || ''}, 是否继续?`, '删除提示', {
        cancelButtonClass: "btn-custom-cancel",
        confirmButtonClass: "btn-custom-confirm",
        center: true,
        confirmButtonText: '确定',
        cancelButtonText: '取消',
      }).then(() => {
        brandUpfileListTemp.splice(idx, 1)
        this.$message({
          type: 'success',
          message: '删除成功!'
        });
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });
      });
    },

    getCategoryInfo(info) {
      info.forEach(f => {
        // 如果一条都没有 做添加处理
        if (!this.cateList.length) {
          this.cateList.push({
            categoryId: f.categoryId,
            fullName: f.brandName,
            parentId: f.parentId,
            originalId: f.originalId,
          })
        } else {
          // 如果没找到 做 新增处理
          if (!this.cateList.some(s => {
            // 如果 已有 做更新处理
            if (f.categoryId == s.categoryId) {
              s.fullName = f.brandName
              s.parentId = f.parentId
              s.originalId = f.originalId
              this.$set(s, 'delete', false)
              return true
            }
          })) {
            // 如果已经添加过 则 跳过
            if (this.cateList.some(s => s.categoryId == f.categoryId)) return
            this.cateList.push({
              categoryId: f.categoryId,
              fullName: f.brandName,
              parentId: f.parentId,
              originalId: f.originalId,
            })
          }
        }
      })
      // 如果 在cateList 没有找到该数据 说明已经删除
      this.cateList.forEach(f => {
        // 未找到
        if (!f.categoryId) return
        if (!info.some(s => f.categoryId == s.categoryId)) {
          this.$set(f, 'delete', true)
        }
      })
    },

    // 如果是去完善 跳转过来 需要 初始化信息
    initSupplierBiddingInfo() {
      try {
        this.supplierBiddingInfo = JSON.parse(this.$getRootScope('supplierBiddingInfo') || '{}')
        if (this.supplierBiddingInfo && this.supplierBiddingInfo.respCode) {
          // 初始化信息
          const {
            supplierName, busiLicense, corpType, establishDt,
            legalRepresent, registCapital, dealFrom, dealTo, legalCertNo, taxpayerType
          } = this.supplierBiddingInfo

          this.form.corpName = supplierName
          this.form.busiLicense = busiLicense
          this.form.corpTypeName = corpType
          this.form.establishDt = establishDt

          this.form.legalRepresent = legalRepresent
          this.form.legalCertNo = legalCertNo
          this.form.taxpayerType = taxpayerType
          this.form.registCapital = registCapital
          this.form.dealFrom = dealFrom
          this.form.dealTo = dealTo

        }
      } catch (error) {
        console.error('initSupplierBiddingInfo', error);
      }
    },

    /**
     * 上传品牌logo
     * @param e: 文件对象
     * @param idx 数据下标
     */
    handleLogoUpFileResult(e, idx) {
      try {
        this.form.brandList[idx].logoImgUrl = e[0].url
      } catch (error) {
        console.error('tryCatch:', error);
      }
    },

    /**
     * 删除品牌logo
     * @param idx 数据下标
     */
    handleDelBrandLogoImg(idx) {
      try {
        this.form.brandList[idx].logoImgUrl = ''
      } catch (error) {
        console.error('tryCatch:', error);
      }
    },

    handleUpFileResult(e) {
      this.delFileInfo()
      const { file, name, targetValue, url } = e[0]
      this.authorizationInfo = {
        file: file,
        attachName: name,
        creTm: this.dateFormat("YYYY-mm-dd HH:MM", new Date()),
        targetValue,
        attachUrl: url
      }
    },
    handleUpload(e) {
      let file = e.target.files[0]
      // 获取当前上传文件名
      let name = file.name || ''
      const fileType = name.slice(name.lastIndexOf('.') + 1, name.length),
        targetValue = e.target.value || ''
      let typeOnOff = true;
      let fileSizeOnOff = true;
      if (this.uploadFileSuffix && fileType != this.uploadFileSuffix) {
        this.$message.error("请上传有公司用印的PDF扫描文件！");
        this.resetInputValue()
        typeOnOff = false
        return;
      }
      if (file.size > 52428800) {
        this.$message.error("上传文件不能超过50M, 请重新选择");
        this.resetInputValue()
        fileSizeOnOff = false
        return;
      }
      let now = new Date();
      if (this.authorizationInfo.id) {
        this.delImgList.push({ attachId: this.authorizationInfo.id })
      }
      this.resetInputValue()
    },
    dateFormat(fmt, date) {
      let ret;
      const opt = {
        "Y+": date.getFullYear().toString(),        // 年
        "m+": (date.getMonth() + 1).toString(),     // 月
        "d+": date.getDate().toString(),            // 日
        "H+": date.getHours().toString(),           // 时
        "M+": date.getMinutes().toString(),         // 分
        "S+": date.getSeconds().toString()          // 秒
      };
      for (let k in opt) {
        ret = new RegExp("(" + k + ")").exec(fmt);
        if (ret) {
          fmt = fmt.replace(ret[1], (ret[1].length == 1) ? (opt[k]) : (opt[k].padStart(ret[1].length, "0")))
        }
      }
      return fmt;
    },
    /**
     * 重置input value  防止 同一个文件连续提交 不触发 onchange事件
     */
    resetInputValue() {
      let isIE10 = false,
        uploadInputs = document.getElementsByName('my-upfile-component-input-name') || []
      if (window.navigator.userAgent.indexOf('MSIE') >= 1) { // 判断ie10以及以下
        isIE10 = true
      } else {
        isIE10 = false
      }
      for (let i = 0, len = uploadInputs.length; i < len; i++) {
        const element = uploadInputs[i];

        if (isIE10) {
          let form = document.createElement('form'),
            beforInput = element.nextSibling,
            parentInput = element.parentNode

          form.appendChild(element)
          form.reset()
          parentInput.insertBefore(element, beforInput)
        } else {
          element.value = ''
        }

      }
    },
    getOrderConfiguration() {
      const params = {
        businessType: 'AUTHORIZATION'
      };
      InterfaceService.getOrderConfiguration(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          let list = res.uploadFileList || [];
          list.forEach(item => {
            if (item.fileTypeId === "regist_authorization") {
              this.templateFileUrl = item.attachUrl || "";
              this.templateFileName = item.templateFileName || "";
              this.uploadFileSuffix = item.uploadFileSuffix || "";
            }
          })
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    delFileInfo() {
      if (this.authorizationInfo.id) {
        this.delImgList.push({ attachId: this.authorizationInfo.id });
      }
      this.authorizationInfo = {};
    },
    timestampToTime(timestamp) {
      let date = new Date(timestamp);
      let Y = date.getFullYear() + '-';
      let M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
      let D = date.getDate() + ' ';
      return Y + M + D;
    },
    handleSearchCorp(name) {
      InterfaceService.doGetProviderRiskDetail(
        { name: name, type: "baseInfo" },
        data => {
          if (data.respData.respCode === "0000") {
            let corpInfo = data.respData.riskBaseInfoBean || {};
            this.form.establishDt = corpInfo.estiblishTime || "";
            this.form.registCapital = corpInfo.regCapital || "";
            this.form.dealFrom = corpInfo.fromTime && this.timestampToTime(corpInfo.fromTime) || "";
            this.form.dealTo = corpInfo.toTime && this.timestampToTime(corpInfo.toTime) || "";
            this.form.corpTypeName = corpInfo.companyOrgType || "";
            this.errorRules = {}
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    // 驳回-查询
    getVendorMessage() {
      const params = {
        corpId: this.$route.query.corpId
      }
      InterfaceService.rejectQuerySupplier(params, (data) => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.antiDisplayDataAcCorpInfoBean(data.respData)
          this.antiDisplayDataAcSupplierInfoBean(data.respData.acSupplierInfoBean)
          this.antiDisplayDataAcCorpAttachInfoList(data.respData.acCorpAttachInfoList)
          this.antiDisplayDataBrandList(data.respData.brandList)
          this.cateList = data.respData.categoryList || [{
            categoryId: "",
            fullName: "",
            parentId: "",
            originalId: "",
          }];
          console.log(this.cateList, 'cateList');
          try {
            if (data.respData.acCorpFinInfoBean && data.respData.acCorpFinInfoBean.invoiceType) {
              data.respData.acCorpFinInfoBean.invoiceType = data.respData.acCorpFinInfoBean && data.respData.acCorpFinInfoBean.invoiceType && data.respData.acCorpFinInfoBean.invoiceType.split('/')
            }
          } catch (error) {
            console.error("tryCatch", error);
          }

          this.form = Object.assign(this.form, data.respData.acCorpFinInfoBean || {}, data.respData.corpAddrInfoRst || {});
          this.registerAdvancedInfo = JSON.stringify(Object.assign({}, data.respData.acCorpFinInfoBean || {}, data.respData.corpAddrInfoRst || {}, { taxClassifyList: data.respData.corpTaxClassifyList || [] }))
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      });
    },
    // 公司基本信息
    antiDisplayDataAcCorpInfoBean(data) {
      const FORM = {
        corpName: data.acCorpInfoBean.corpName,
        supCorpName: data.acCorpInfoBean.supCorpName,
        busiLicense: data.acCorpInfoBean.busiLicense,
        corpTypeName: data.acCorpInfoBean.corpTypeName,
        establishDt: data.acCorpInfoBean.establishDtStr,
        legalRepresent: data.acCorpInfoBean.legalRepresent,
        legalCertNo: data.acCorpInfoBean.legalCertNo,
        taxpayerType: data.acCorpInfoBean.taxpayerType,
        registCapital: data.acCorpInfoBean.registCapital,
        shortCorpName: data.acCorpInfoBean.shortCorpName,
      }
      let adminInfo = {};
      let list = data.acCorpContactInfoList || [];
      list.forEach(item => {
        if (item.contactType === "9") {
          adminInfo = {
            adminName: item.name || "",
            adminEmail: item.email || "",
            adminMobile: item.mobile || "",
            adminCertNo: item.certNo || "",
            department: item.department || "",
            position: item.position || "",
            effectiveStartdate: item.effectiveStartdate || "",
            effectiveEnddate: item.effectiveEnddate || "",
          }
        }
      })
      this.form = Object.assign({}, this.form, adminInfo, FORM)
    },
    //  公司基本信息 - 经营期限-范围
    antiDisplayDataAcSupplierInfoBean(data) {
      if (data) {
        const FORM = {
          dealFrom: data.dealFromStr || "",
          dealTo: data.dealToStr || "",
        }
        this.form = Object.assign({}, this.form, FORM)
      }
    },
    handleDownTemp() {
      this.$download([{
        name: this.templateFileName || '',
        url: this.templateFileUrl || ''
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    antiDisplayDataBrandList(data) {
      if (data) {
        this.brandList = [];
        this.ininBrandList = [];
        this.form.brandList = []
      }
      for (let i = 0, len = data.length; i < len; i++) {
        if (data[i]) {
          const itemUrl = data[i].logoImgUrl || '';
          this.brandList.push({
            previewSrcr: itemUrl,
            brandId: data[i].brandId,
            dialogVisible: false,
          })
          // 备份
          this.ininBrandList.push({
            brandId: data[i].brandId,
            brandNameCn: data[i].brandNameCn,
            brandNameEn: data[i].brandNameEn,
            logoImgUrl: data[i].logoImgUrl,
          });
          this.form.brandList.push({
            brandId: data[i].brandId,
            brandNameCn: data[i].brandNameCn,
            brandNameEn: data[i].brandNameEn,
            logoImgUrl: data[i].logoImgUrl,
          });
          this.form.brandNameCn = data[i].brandNameCn
        }
      }
      console.log(this.brandList);

    },
    // 上传图片
    antiDisplayDataAcCorpAttachInfoList(data) {
      if (data) {
        this.imgList = [];
      }
      for (let i = 0, len = data.length; i < len; i++) {
        if (data[i]) {
          const itemUrl = data[i].attachContent || '';
          const url = itemUrl.slice(itemUrl.indexOf('/djc'), itemUrl.length)
          if (data[i].attachType === "0") {
            this.imgList.push({
              previewSrcr: itemUrl,
              file: { name: itemUrl.slice(itemUrl.lastIndexOf('/') + 1, itemUrl.length) },
              id: data[i].attachId,
              dialogVisible: false,
            })
            this.form.attachList[i] = {
              "attachUrl": `#url#${url}`,
              "attachType": `0`,
            };
          } else if (data[i].attachType === "2") {
            this.form.attachList[i] = {
              "attachUrl": this.authorizationInfo && this.authorizationInfo.attachUrl || '', // 替换地址
              "attachType": `2`,
            };
            this.authorizationInfo = {
              attachName: data[i].attachName,
              id: data[i].attachId || "",
              creTm: data[i].creTm,
            }
          }
        }
      }
      if (this.imgList.length < 3) {
        this.imgList.push({ 'previewSrcr': '', 'file': '', 'dialogVisible': false })
      }
    },
    getCropId() {
      InterfaceService.registerGetCropId({}, (data) => { },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    checkForm(key, ev) {
      if (ev) {
        this.focusCorpName = ev.target.value || ""
      }
      if (this.form[key]) {
        delete this.errorRules[key]
      }
      if (ev == 'establishDt') {
        console.log(ev);
      }
    },
    submit(rules) {
      let _this = this;
      let _loadImg = [];
      let upLoadState = false;
      if (this.form.dealFrom === null) {
        this.form.dealFrom = ''
      }
      if (this.form.dealTo === null) {
        this.form.dealTo = ''
      }
      for (let i = 0; i < _this.imgList.length; i++) {
        if (!_this.imgList[i].id) {
          let file = _this.imgList[i] && _this.imgList[i].file
          if (file) {
            _loadImg.push(_this.imgList[i])
          }
        }
      }
      _this.imgList.forEach(item => {
        if (!!item.id) {
          upLoadState = true;
        }
      })
      if (!upLoadState && _loadImg.length == 0) {
        _this.imgListImgError = '请上传营业执照附件'
        return false
      }
      let brandLoadImg = [];
      let brandUpLoadState = false; // 是否提示 - 请上传图片附件
      for (let i = 0; i < _this.brandList.length; i++) {
        if (!_this.brandList[i].id) {
          let file = _this.brandList[i] && _this.brandList[i].file
          if (file) {
            brandLoadImg.push(_this.brandList[i])
          }
        }
      }
      let bool = this.cateList.some(item => item.categoryId && !item.delete);
      if (!bool) {
        _this.$message.error('请选择经营品类')
        return false
      }
      if (!this.authorizationInfo.attachName) {
        _this.$message.error('请上传授权书')
        return false
      }
      // 如果loadImg长度为0 , 说明用的是反显数据图片, 直接提交
      _this.$refs.form.validate((valid, object) => {
        if (valid) {
          _this.form['attachList'] = []
          _this.form['attachList'].push({
            'attachURL': this.authorizationInfo && this.authorizationInfo.attachUrl || '', // 替换地址,
            'attachType': "2",
          })

          if (_this.isFirstSubmit) {//未上传过图片或者上传过但是更换过图片 则直接提交
            if (_loadImg.length === 0 && brandLoadImg.length === 0) {
              console.log(_this.isReject);
              _this.isReject ? _this.isRejectSubmigCompelet() : _this.submitCompelet()
              return
            }
            if (_loadImg.length) {
              //先上传图片
              //去后端拿签名一次性
              InterfaceService.getOssSignatureDisposable('', {}, (data) => {
                let signature = data
                console.log(data);
                // 如果loadImg长度为0 , 说明用的是反显数据图片, 直接提交
                for (let pos = 0; pos < _loadImg.length; pos++) {
                  let file = _loadImg[pos] && _loadImg[pos].file
                  let fileFlag = false;
                  _loadImg[pos].attachName ? fileFlag = true : fileFlag = false
                  if (file) {
                    let dirType = 'company/'
                    console.log(pos, file, dirType, signature);
                    _this.uploadHander(pos, file, dirType, signature, (pos, file, dirType, signature) => {
                      console.log(signature);
                      //let u = signature.host+'/'+signature.dir+dirType+file.name
                      let u = "#url#" + '/' + signature.dir + dirType + file.name
                      if (!fileFlag) {
                        _this.form['attachList'].push({
                          'attachURL': u,
                          'attachType': "0",
                        })
                      } else {
                      }
                      //图片上传到oss之后 提交注册信息
                      if (pos >= _loadImg.length - 1) {
                        if (brandLoadImg.length) {
                          //先上传图片
                          //去后端拿签名一次性
                          InterfaceService.getOssSignatureDisposable('', {}, (data) => {
                            let signature = data
                            // 如果loadImg长度为0 , 说明用的是反显数据图片, 直接提交
                            for (let pos = 0; pos < brandLoadImg.length; pos++) {
                              let file = brandLoadImg[pos] && brandLoadImg[pos].file
                              if (file) {
                                let dirType = 'company/'
                                _this.uploadHander(pos, file, dirType, signature, (pos, file, dirType, signature) => {
                                  //let u = signature.host+'/'+signature.dir+dirType+file.name
                                  let u = "#url#" + '/' + signature.dir + dirType + file.name;
                                  _this.form['brandList'][0].logoImgUrl = u;
                                  //图片上传到oss之后 提交注册信息
                                  setTimeout(() => {
                                    _this.isReject ? _this.isRejectSubmigCompelet() : _this.submitCompelet()
                                  }, 800)
                                })
                              }
                            }
                          }, (data) => {
                            _this.isLoading = false;
                          },
                            () => {
                              _this.isLoading = true;
                            },
                            () => {
                              //_this.isLoading = false;
                            });
                        } else {
                          setTimeout(() => {
                            _this.isReject ? _this.isRejectSubmigCompelet() : _this.submitCompelet()
                          }, 800)
                        }
                      }
                    })
                  }
                }
              }, (data) => {
                _this.isLoading = false;
              },
                () => {
                  _this.isLoading = true;
                },
                () => {
                  //_this.isLoading = false;
                });
            } else {
              InterfaceService.getOssSignatureDisposable('', {}, (data) => {
                let signature = data
                // 如果loadImg长度为0 , 说明用的是反显数据图片, 直接提交
                for (let pos = 0; pos < brandLoadImg.length; pos++) {
                  let file = brandLoadImg[pos] && brandLoadImg[pos].file
                  if (file) {
                    let dirType = 'company/'
                    _this.uploadHander(pos, file, dirType, signature, (pos, file, dirType, signature) => {
                      //let u = signature.host+'/'+signature.dir+dirType+file.name
                      let u = "#url#" + '/' + signature.dir + dirType + file.name;
                      _this.form['brandList'][0].logoImgUrl = u;
                      //图片上传到oss之后 提交注册信息
                      setTimeout(() => {
                        _this.isReject ? _this.isRejectSubmigCompelet() : _this.submitCompelet()
                      }, 800)
                    })
                  }
                }
              }, (data) => {
                _this.isLoading = false;
              },
                () => {
                  _this.isLoading = true;
                },
                () => {
                  //_this.isLoading = false;
                });
            }
          } else {//已经上传过图片 则直接提交
            _this.isLoading = false;
            _this.isReject ? _this.isRejectSubmigCompelet() : _this.submitCompelet()
          }
        } else {
          // 校验失败滚动到对应位置
          console.log(object)
          for (let i in object) {
            console.log(i);
            let dom = this.$refs[i];
            if (Object.prototype.toString.call(dom) !== '[object Object]') {
              dom = dom[0];
            }
            let top = dom.$el.getBoundingClientRect().top;
            let scrollTop = document.documentElement.scrollTop;
            let diff = top + scrollTop;

            document.documentElement.scrollTop = diff - 276;
            break;
          }
          return false;
        }
      })
    },
    // 格式化imgList URL名字
    formatImgUrlName(imgList) {
      for (let len = imgList.length, i = len - 1; i >= 0; i--) {
        // 如果有ID表示不是新增或者修改 不进入这次更改list
        if (!imgList[i].attachId && imgList[i].attachURL) {
          imgList[i].attachContent = imgList[i].attachURL
          delete imgList[i].attachURL
        } else {
          // 移除未被修改的图片
          imgList.splice(i, 1);
        }
      }
    },

    /**
     * 设置 标记 品牌logo 文件 状态, 更新或删除
     */
    setBarandUpfileList(params) {
      // private String brandCrudFlg; // 品牌处理标志（"insert:新增"，"update:更新"，"delete:删除"）
      let delItemList = []
      // 如果 备份 没有数据 说明 全部 新增
      if (!(this.ininBrandList && this.ininBrandList.length)) {
        params.brandList.some(s => s.brandCrudFlg = 'insert')
      }
      // 判断为新增
      params.brandList.some(s => {
        // 如果 在备份数据 找到 不处理, 否则标记为新增
        if (!this.ininBrandList.some(s1 => s.brandId == s1.brandId)) {
          s.brandCrudFlg = 'insert'
        }
      })

      this.ininBrandList.forEach(f => {
        // 如果 没有 brandId 说明 为新增
        if (!f.brandId) {
          // 标记为新增
          f.brandCrudFlg = 'insert'
        }
        let isDel = false
        // 如果未到了 说明删除
        isDel = !params.brandList.some(s => {
          if (f.brandId === s.brandId) {
            // 数据发生改变
            if (!(f.brandNameCn === s.brandNameCn && f.brandNameEn === s.brandNameEn && f.logoImgUrl === s.logoImgUrl)) {
              // 标记为更新
              s.brandCrudFlg = 'update'
            }
            return true
          }
        })
        if (isDel) {
          // 标记为删除
          f.brandCrudFlg = 'delete'
          delItemList.push(f)
        }
      })

      // 如果删除数组有值, 拼接 删除数据到 params
      if (delItemList.length) {
        params.brandList = params.brandList.concat(delItemList)
      }

      // 数据 未变的 则 不需要上传, 予以删除
      params.brandList = params.brandList.filter(f => !!f.brandCrudFlg)
    },

    // 驳回 下一步 - 提交
    isRejectSubmigCompelet() {
      let _this = this
      // 检测品牌是否有logo
      if (!this.userInfo.contractCorpType && this.isConstruction != '1') {
        if (_this.form.brandList.some((s, idx) => !s.logoImgUrl && this.$message.error(`请上传经营品牌${idx + 1} 品牌logo`))) return
      }

      _this.isFirstSubmit = false;//上传过 则此标记为false
      let params = JSON.parse(JSON.stringify(_this.form));
      params.prodType = ''
      params.supplyType = this.accountType.toString();

      // 转换url名称
      this.formatImgUrlName(params['attachList']);
      params.acCorpAttachInfoList = params['attachList']
      // 拼接 删除的图片
      params.acCorpAttachInfoList = params.attachList.concat(this.delImgList)
      // 移除 旧图片list
      delete params['attachList'];
      params.categoryList = [];
      this.cateList.forEach(item => {
        if (item.categoryId && !item.delete) {
          params.categoryList.push(item)
        }
      });
      params.corpId = this.$route.query.corpId;
      params.contractCorpType = this.userInfo.contractCorpType || null;

      this.setBarandUpfileList(params)
      console.log(_this.form);
      //提交信息
      console.log(this.$clone(params), '===================par');
      InterfaceService.rejectUpdateSupplier(
        params,
        data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            this.$router.push({
              path: "/registerAdvanced",
              query: {
                isReject: true,
                corpId: this.$route.query.corpId,
                corpName: this.form.corpName,
                isVregistet: true,
                isPurchase: true
              }
            });
            this.$setRootScope('registerAdvancedInfo', this.registerAdvancedInfo)
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => {

        },
        () => {
          _this.isLoading = true;
        },
        () => {
          _this.isLoading = false;
        }
      )
      return

    },
    // 第一次 新增 010002
    submitCompelet() {
      let _this = this
      // 检测品牌是否有logo
      if (!this.userInfo.contractCorpType && this.isConstruction != '1') {
        if (_this.form.brandList.some((s, idx) => !s.logoImgUrl && this.$message.error(`请上传经营品牌${idx + 1} 品牌logo`))) {
          _this.isLoading = false;
          return
        }
      }
      let params = JSON.parse(JSON.stringify(_this.form));
      params.prodType = ''
      params.supplyType = this.accountType
      params.corpId = this.userInfo.corpId;
      params.attachList = _this.form['attachList']
      params.brandList = _this.form['brandList']
      params.categoryList = []
      this.cateList.forEach(item => {
        if (item.categoryId && !item.delete) {
          params.categoryList.push(item)
        }
      });
      params.contractCorpType = this.userInfo.contractCorpType || null;
      params.isConstruction = this.isConstruction
      //提交信息
      console.log(_this.form['brandList'], "_this.form['attachList']");
      
      console.log(params, '----新增');
      InterfaceService.registerVendor(
        params,
        data => {
          _this.result = data.respData;
          if (_this.result.respCode == '0000') {
            _this.isFirstSubmit = false;//上传过 则此标记为false
            //去缓存里获取userInfo  加入公司信息
            let userInfo = JSON.parse(_this.$getRootScope('user'))
            // userInfo.corpId = _this.result.corpId
            userInfo.corpName = _this.form.corpName
            userInfo.bs = "S"
            userInfo.regStep = '1'
            _this.$setRootScope('user', JSON.stringify(userInfo))
            _this.setUserInfoAction(userInfo)
            this.$router.push({
              path: "/registerAdvanced",
              query: {
                corpId: userInfo.corpId,
                corpName: this.form.corpName,
              }
            });
          } else {
            if (_this.result.respCode == 'MEM0089' || _this.result.respCode == 'MEM0037') {
              _this.errorRules['orgCode'] = _this.result.respMsg
            } else if (_this.result.respCode == 'MEM0090' || _this.result.respCode == 'MEM0036' || _this.result.respCode == 'MEM0012') {
              _this.errorRules['busiLicense'] = _this.result.respMsg
            } else if (_this.result.respCode == 'MEM0073') {
              _this.errorRules['corpName'] = _this.result.respMsg
            } else if (_this.result.respCode == 'MEM0056') {
              _this.errorRules['prevPurchase'] = _this.result.respMsg
            } else if (_this.result.respCode == 'MEM0013' || _this.result.respCode == 'MEM0037') {
              _this.errorRules['orgCode'] = _this.result.respMsg
            }

            _this.$message.error(_this.result.respMsg);
          }
        },
        data => {

        },
        () => {
          _this.isLoading = true;
        },
        () => {
          _this.isLoading = false;
        }
      );
    },
    pushImg(event, index, listType) {//input控件（自定义）获取文件 上传
      let _this = this;
      _this.isFirstSubmit = true;//更改过图片 则视为第一次提交（需要上传图片)
      let file = event.target.files[0]
      if (file) {
        let checkTextList = JSON.parse(sessionStorage.getItem('checkTextList') || '[]');
        let onOff = false;
        let forbidText = ''
        checkTextList.forEach(i => {
          if (i != '' && file.name.indexOf(i) != -1) {
            onOff = true
            forbidText = i
          }
        });
        if (onOff) {
          this.$message.error('文件名包含特殊字符【' + forbidText + '】,请修改文件名后再上传')
          return false
        }
        _this[listType + 'ImgError'] = ''
        // 判断是否图片
        if ((file.type).indexOf("image/") == -1) {
          _this[listType + 'ImgError'] = '请选择图片!'
          return false
        }

        // let fSize = Math.round(file.size / 1024 * 100) / 100;//取得图片文件的大小
        // if (fSize >= 1024) {//单位为KB
        //   _this[listType + 'ImgError'] = '照片最大尺寸为1024KB，请重新上传!'
        //   return false
        // }
        for (var i in _this[listType]) {
          let cImg = _this[listType][i] && _this[listType][i].file
          if (cImg) {
            if (file.name == cImg.name && file.size == cImg.size && file.type == cImg.type) {
              _this[listType + 'ImgError'] = '图片已经存在，请重新选择!'
              return false
            }
          }
        }
        // 图片压缩
        ImageUtil.handleChangeMasterImg([file], 1024, 1600, (files) => {
          // console.log(files)
          let reader = new FileReader();
          reader.onloadend = function () {
            _this[listType][index].previewSrcr = reader.result
            _this[listType][index].file = file;
            if (listType == "brandList") {
              _this.form['brandList'][0].logoImgUrl = file;
              // _this.form['brandList'].push({ 'logoImgUrl': file })
            } else {
              _this.form['attachList'].push({ 'attachURL': file })
            }
            if (_this.imgList.length < 3) {
              _this.imgList.push({ 'previewSrcr': '', 'file': '', 'dialogVisible': false })
            }
            _this.$forceUpdate();
            _this.$set(_this[listType], _this[listType]);
          }

          if (file) {
            reader.readAsDataURL(file);
          } else {
            _this.previewSrcr = "";
          }
        })
      } else {
        _this[listType + 'ImgError'] = '图片获取错误'
      }
      event.target.value = "";
    },
    uploadHander(pos, file, dirType, signature, callBack) {
      let _this = this;
      //去后端拿签名
      InterfaceService.uploadToOss(signature, file, dirType, pos, callBack)
    },
    reviewImg(index, listType) {
      this[listType][index].dialogVisible = true;
      this.$forceUpdate()
      console.log(this[listType]);
    },
    clearImg(index, listType) {
      // this.isFirstSubmit = true;//更改过图片 则视为第一次提交（需要上传图片)
      // 存储被删除的ID
      if (listType == 'imgList') {
        if (this.imgList[index].id !== '') {
          this.delImgList.push({ attachId: this.imgList[index].id });
        }
        let threeIpt = this.imgList.every((item) => {
          return item.file !== ""
        });
        if (threeIpt && this.imgList.length == 3) {
          this.imgList.splice(index, 1, { 'previewSrcr': '', 'file': '', 'dialogVisible': false })
        } else {
          this.imgList.splice(index, 1)
        }
      } else {
        this.brandList.splice(index, 1, { 'previewSrcr': '', 'file': '', 'dialogVisible': false });
        this.form.brandList[0].logoImgUrl = "";
      }
      this.$forceUpdate();
      this.$set(this[listType], this[listType]);
      //清空input[file]
      let file = '';
      if (listType == 'brandList') {
        file = document.getElementById("brandImg" + index)
      } else {
        file = document.getElementById("masterImg" + index)
      }
      file.value = "";
    },
    handleChangeAdminInfo(ev) {
      if (this.isAdmin == "1") {
        if (Object.keys(this.isAdminInfo).length == 0) {
          InterfaceService.accountInfo({ acctId: this.userInfo.acctId }, (data) => {
            if (data && data.respData && data.respData.respCode === "0000") {
              this.isAdminInfo = data.respData || {};
              this.form.adminName = this.isAdminInfo.accName;
              this.form.adminCertNo = this.isAdminInfo.certNo;
              this.form.adminMobile = this.isAdminInfo.mobile;
              this.form.adminEmail = this.isAdminInfo.email;
              this.form.department = this.isAdminInfo.dept || '';
              this.form.position = this.isAdminInfo.title || '';

              this.adminFormBackup.adminName = this.isAdminInfo.accName;
              this.adminFormBackup.adminCertNo = this.isAdminInfo.certNo;
              this.adminFormBackup.adminMobile = this.isAdminInfo.mobile;
              this.adminFormBackup.adminEmail = this.isAdminInfo.email;

              this.form.effectiveStartdate = this.isAdminInfo.effectiveStartdate || '';
              this.form.effectiveEnddate = this.isAdminInfo.effectiveEnddate || '';
            } else {
              this.$message.error(data.respData.respMsg);
            }
          }, data => { }, () => {
            this.isLoading = true;
          }, () => {
            this.isLoading = false;
          });
        }
        this.form.adminName = this.isAdminInfo.accName;
        this.form.adminCertNo = this.isAdminInfo.certNo;
        this.form.adminMobile = this.isAdminInfo.mobile;
        this.form.adminEmail = this.isAdminInfo.email;
        this.form.department = this.isAdminInfo.dept || '';
        this.form.position = this.isAdminInfo.title || '';
        this.form.effectiveStartdate = this.isAdminInfo.effectiveStartdate || '';
        this.form.effectiveEnddate = this.isAdminInfo.effectiveEnddate || '';
      } else {
        this.form.adminName = "";
        this.form.adminCertNo = "";
        this.form.adminMobile = "";
        this.form.adminEmail = "";
        this.form.department = "";
        this.form.position = "";
        this.form.effectiveStartdate = "";
        this.form.effectiveEnddate = "";
      }
    },
    getPaymentMethod() {
      let params = {
        appName: 'MEMBER',
        groupId: 'REGIST_LEGAL_WHITE_LIST',
      };
      InterfaceService.getPaymentMethod(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.corporateNameList = data.respData.configEntityList || [] //公司白名单
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => { this.isLoading = true; }, () => { this.isLoading = false; })
    },
    goBack() {
      this.$router.go(-1);
    }
  },
  mounted() {
    this.init();
    this.$setRootScope("registerPath", JSON.stringify({ path: this.$route.path, query: this.$route.query }));
  }
};
</script>

<style lang="scss" scoped>
.blue {
  color: #0e88e6 !important;
}
.p-0-20 {
  padding: 0 20px;
}
p {
  margin-bottom: 20px;
}
a.link {
  display: inline-block;
  vertical-align: middle;
  padding: 0 10px;
  color: #7ab7e8;
}

.inner-container {
  margin-bottom: 100px;
  font-size: 14px;
}

.form-inline-item {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  & > div {
    width: 40%;
    flex-shrink: 0;
  }

  &.col-3 > div {
    width: 32%;
  }

  /deep/ .el-select {
    width: 100%;
  }
}
.regist-perfect-info {
  /deep/ .el-form-item__label {
    font-size: 12px;
    white-space: pre;
  }
  /deep/ .el-checkbox {
    min-width: 189px;
    + .el-checkbox {
      margin-left: 0px;
    }
  }
  /deep/ .el-date-editor.el-input {
    width: 100%;
  }
}

.form-item {
  position: relative;
  line-height: 40px;

  .float-right {
    position: absolute;
    top: 0;
    right: 10px;
  }
}

.info-panel {
  margin-top: 30px;
  font-weight: 100;
}
.blue-0e88e6 {
  color: #0e88e6;
}

.brand-other {
  margin-top: 20px;
  padding-left: 30px;
}

.info-panel-title {
  border-left: 3px solid #000;
  margin: 10px 0;
  padding: 0 10px;
  font-weight: bold;
  color: rgb(41, 41, 41);
  i {
    font-size: 12px;
    color: rgb(143, 143, 143);
  }
  a {
    font-size: 12px;
    text-decoration: underline;
    color: #7ab7e8;
  }
}

.info-panel-content {
  padding: 20px 0;
  padding-bottom: 0;
  background: #fff;
  &.bottom {
    padding-bottom: 20px;
  }
}

.info-master-img {
  .img-item {
    position: relative;
    display: inline-block;
    width: 120px;
    height: 120px;
    vertical-align: middle;
    margin-right: 20px;
    border: 1px dashed #ccc;
    border-radius: 2px;
    overflow: hidden;
  }

  .img-item-add {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    font-size: 30px;
    text-align: center;
    color: #ccc;

    position: relative;
    overflow: hidden;

    i {
      cursor: pointer;
    }

    input[type="file"] {
      display: none;
    }
    img {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      pointer-events: none;
      height: auto;
    }
  }

  .img-item-cover {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0);

    .img-item-top,
    .img-item-bottom {
      display: none;
      position: absolute;
      width: 100%;
      padding: 10px;
      text-align: center;
      background: rgba(167, 166, 166, 0.2);
    }

    .img-item-top {
      top: 0;
    }

    .img-item-bottom {
      bottom: 0;
      padding: 0 10px;

      a {
        display: inline-block;
        width: 46%;
        padding: 10px 5px;
        vertical-align: middle;
        color: rgb(88, 167, 231);
      }
    }
  }

  .img-item:hover {
    .img-item-cover {
      background: rgba(255, 255, 255, 0.2);
    }

    .img-item-top,
    .img-item-bottom {
      display: block;
    }
  }

  img {
    width: 100%;
    height: 100%;
    border: none;
  }

  .img-item.has-img {
    border: none;

    .img-item-add {
      // display: none;
    }

    &:hover .img-item-add {
      display: flex;
    }
  }
}

.info-detail {
  position: relative;
  z-index: 0;
}

.info-detail-img {
  padding: 10px 30px;
  border: 1px solid #e0e0e0;
  border-top: none;
  line-height: 30px;
  background: #f5f5f5;

  button {
    float: right;
    margin: 0 5px;
  }
}

.model-table {
  thead td {
    text-align: center;
  }

  td {
    padding: 10px;
    padding-left: 0;
  }
}

.apply-dialog {
  line-height: 25px;

  a {
    text-decoration: underline;
    color: #7ab7e8;
  }
}

.fix-bottom {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  padding: 20px;
  text-align: center;
  background: rgba(79, 82, 90, 0.8);

  button {
    width: 150px;
  }
}

.form-upload-text {
  height: 40px;
  line-height: 40px;
  font-size: 12px;
  color: #888;

  .form-upload-text-left {
    display: inline-block;
    width: 134px;
    text-align: right;
  }
  .form-upload-text-right {
    display: inline-block;
    width: 100%;
    padding-left: 195px;
  }
}

.form-upload-content {
  margin-bottom: 22px;
  .info-master-img {
  }

  /deep/ .el-dialog__header {
    border-bottom: 0;
  }
}
.continue {
  text-align: center;
  margin: 0 auto 0;
}
/deep/ .el-date-editor {
  /deep/ .el-range-separator {
    width: 7%;
  }
}
.neet-upload-upfile {
  box-sizing: border-box;
  display: flex;
  border-top: 1px solid transparent;

  &.disabled {
    /deep/ .center .blue {
      // background: #dddddd !important;
      // color: #a9a9a9 !important;
    }
  }

  & > li {
    width: 87%;

    &:nth-child(1) {
      .input-file-p {
        border: 1px solid #dcdfe6;
        box-sizing: border-box;
        padding: 0 12px;
        color: #606266;
        display: block;
        display: flex;
        flex-wrap: wrap;
        min-height: 40px;

        span {
          height: 38px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        & > .gray {
          color: #c0c4cc;
          font-size: 12px;
          outline: none;
          height: 38px;
        }

        .el-tag {
          margin: 4px;
          height: 30px;
        }
      }
    }

    &:nth-child(2) {
      width: 13%;
    }

    &:nth-child(3) {
      width: 33%;
    }

    .el-button--default {
      height: 40px;
      margin-left: 4px;
    }
  }

  .el-button--primary {
    width: 119px;
    margin-right: 12px;
  }

  /deep/ .upfile-container {
    .center {
      label {
        width: 120px;
        background: linear-gradient(
          120deg,
          rgba(215, 176, 100, 1) 0%,
          rgba(236, 206, 139, 1) 100%
        );
        color: #fff !important;
        text-align: center;
        height: 40px;
      }
    }
  }
}
.isie {
  /deep/ .upfile-container {
    .center {
      label {
        height: 42px;
      }
    }
  }
}
.upload-cont {
  margin: 0 0 30px 134px;
}
.upload-title {
  background: #f5f5f5;
  border-bottom: 1px solid #fff;
  height: 35px;
  line-height: 35px;

  span {
    display: inline-block;
    padding-left: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  & span:nth-child(1) {
    width: 65%;
  }
  & span:nth-child(2) {
    width: 25%;
  }
}
.authorization {
  margin-top: 5px;
  margin-bottom: 0 !important;
}
.upfile-container {
  text-align: left;
  .center {
    input {
      width: 0;
      height: 0;
      overflow: hidden;
      opacity: 0;
      border: 0;
      padding: 0;
    }
    label {
      float: left;
      cursor: pointer;
      user-select: none;
      outline: none;
    }
  }
  ::-webkit-scrollbar {
    width: 1px !important;
  }
}
.info-panel-content {
  /deep/ .el-form-item__error {
    background: #fff;
    width: 100%;
    height: 20px;
  }
}
.multipleDropdownTree {
  position: relative;
  float: left;
  width: 290px;
  margin-bottom: 14px;
  span {
    position: absolute;
    right: 31px;
    top: 2px;
  }
}
.border-EEEEEE {
  border-top: 1px solid #eee;
  border-bottom: 1px solid #eee;
  padding-bottom: 26px;
  padding-top: 20px;
}
.add-brand {
  font-size: 12px;
  font-weight: normal;
}

.brand-management-ul {
  & > li {
    margin-top: 22px;
    &:first-child {
      margin-top: 12px;
    }
    h1 {
      font-weight: bold;
      color: #292929;
    }
    .head-logo {
      font-size: 12px;
      color: #888;
      display: flex;
      align-items: center;
      .upfile-container /deep/.center label {
        display: flex;
        margin-left: 4px;
      }
    }
    .brand-inline-item {
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
      padding: 0 20px;
      margin: 18px 0;
      .upfile-brand-name {
        width: 40%;
        display: flex;
        align-items: center;
        span {
          color: #888;
          width: 195px;
          font-size: 12px;
          text-align: right;
          vertical-align: middle;
        }
        /deep/ .el-input {
          width: 261px;
          background: red;
        }
      }
    }
    .upfile-introduce {
      font-size: 12px;
      color: #888;
      margin-top: 12px;
    }
    ol {
      border: 1px solid #dcdfe6;
      padding: 0 12px 12px;
      margin-top: 12px;
      li {
        overflow: hidden;
        margin-top: 12px;
        span {
          color: #888;
        }
        strong {
          margin-left: 22px;
        }
        &.un-data {
          color: #888;
          font-size: 12px;
        }
      }
    }
  }
}

/deep/ .title-container {
  line-height: 40px;
  text-align: left;
}
/deep/ .tendering-category {
  // width: 90% !important;
}
/deep/ .body-container .center ul li {
  line-height: 35px;
}
/deep/ .body-container .center ul li {
  line-height: 35px;
}
</style>
<style lang="scss">
.delBarandNoticeBox {
  width: 400px !important;
  .el-message-box__btns {
    display: flex;
    justify-content: center;
    .el-button--primary {
      order: -1;
      margin: 0 10px 0 0;
      background: #d7b064 linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
      color: #fff;
    }
  }
}
</style>
