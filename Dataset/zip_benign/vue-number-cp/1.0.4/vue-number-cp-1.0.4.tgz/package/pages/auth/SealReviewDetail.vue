<template>
  <div class="sealReviewDetailContainer">
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" :progress="'印章详情'" :is-border-bottom="true" :product-create-process="2"></SearchBar>
    <div class="inner-container">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
      <div class="header">
        <ul>
          <li class="active">印章信息</li>
        </ul>
      </div>
      <div class="seal-info-container">
        <div class="seal-info-left">
          <img v-if="sealInfo.sealData" :src="'data:image/jpeg;base64,' + sealInfo.sealData">
        </div>
        <div class="seal-info-right">
          <p>
            <span class="title">印章类型: </span>
            {{sealInfo.sealKindName || ''}}
          </p>
          <p>
            <span class="title">公司名称: </span>
            {{sealInfo.corpName || ''}}
          </p>
          <p>
            <span class="title">印章横向文内容: </span>
            {{sealInfo.hText || ''}}
          </p>
          <p>
            <span class="title">印章下眩文内容: </span>
            {{sealInfo.qText || ''}}
          </p>
          <p>
            <span class="title">印章授权日期: </span>
            {{sealInfo.effectiveStartdate || ''}} ~ {{sealInfo.effectiveEnddate || ''}}
          </p>
          <p class="mt40">
            <span class="title">用印人姓名: </span>
            {{sealInfo.sealAcctName || ''}}
          </p>
          <p>
            <span class="title">联系方式: </span>
            {{sealInfo.sealTel || ''}}
          </p>
          <p>
            <span class="title">管理员授权书: </span>
            {{attachListComputed('admin').attachName || ''}}
            <span class="blue hand" @click="handleDownload(attachListComputed('admin'))">下载授权书</span>
            <span class="blue hand" @click="handlePreview(attachListComputed('admin'))">查看授权书</span>
          </p>
          <p>
            <span class="title">印章授权书: </span>
            {{attachListComputed('seal').attachName || ''}}
            <span class="blue hand" @click="handleDownload(attachListComputed('seal'))">下载授权书</span>
            <span class="blue hand" @click="handlePreview(attachListComputed('seal'))">查看授权书</span>
          </p>
        </div>
      </div>

      <div class="line"></div>

      <div class="order-info-title">审批记录</div>

      <div class="review-product-table">
        <!-- 列表 -->
        <table>
          <thead>
            <tr>
              <td width="90">序号</td>
              <td>用印人员</td>
              <td>提交时间</td>
              <td>状态</td>
              <td width="500">审批意见</td>
            </tr>
          </thead>
          <template v-if="sealInfo && sealInfo.sealApproveFlowList && sealInfo.sealApproveFlowList.length">
            <tbody v-for="(seal,index) in sealInfo && sealInfo.sealApproveFlowList" :key="index" class="tc tbody-row">
              <tr>
                <td width="90">
                  {{index + 1}}
                </td>
                <td>
                  {{seal.acctName || ''}}
                </td>
                <td>
                  {{seal.creTm || ''}}
                </td>
                <td>
                  {{seal.approveStatusName || ''}}
                </td>
                <td width="100" class="opreate">
                  {{seal.approveMsg || ''}}
                </td>
              </tr>
              <tr v-if="seal.sealStatus === 'rejected' && seal.approveMsg">
                <td colspan="5" class="p0">
                  <p class="reject_notice">
                    <span>申请失败原因：</span>
                    <span>{{seal.approveMsg}}</span>
                  </p>
                </td>
              </tr>
            </tbody>
          </template>
        </table>
        <div class="product-empty" v-if="!(sealInfo && sealInfo.sealApproveFlowList && sealInfo.sealApproveFlowList.length)">
          <img src="@/assets/images/icon-no-product.png">
          <p>暂无数据！</p>
        </div>
      </div>

    </div>
    <Loading :is-loading="isLoading"></Loading>

    <FixBottom v-if="!isView">
      <div class="tc">
        <el-button type="primary" style="width: 120px;" @click="handlePast">通过</el-button>
        <el-button style="width: 120px;" @click="handleGoBack">退回</el-button>
      </div>
    </FixBottom>

    <!-- 通过 -->
    <el-dialog class="dialog pastDialogContainer" :title="isPast ? '通过' : '退回'" :append-to-body="true" :lock-scroll="true" :visible.sync="pastdialogVisible" width="840px" center :close-on-click-modal="false">
      <div class="tc">
        <span><i class="red" v-if="!isPast">*</i>审批意见：</span>
        <el-input type="textarea" :rows="6" placeholder="请输入" maxlength="200" show-word-limit v-model="approveMsg">
        </el-input>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确认并提交</el-button>
        <el-button size="small" style="width: 100px" @click="pastdialogVisible = false">取消</el-button>
      </div>
    </el-dialog>

  </div>
</template>
<script>

import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import accountMixin from "@/mixins/account";
import Breadcrumb from "@/components/base/Breadcrumb";

import FixBottom from "@/components/base/FixBottom";
import { viewFile } from '@/utils/orderUtil';

export default {
  mixins: [accountMixin],
  name: "ApplicationSeal",
  components: {
    Header,
    SearchBar,
    Loading,
    Breadcrumb,
    FixBottom
  },
  computed: {
    attachListComputed() {
      return attachType => {
        let item = {}

        try {
          item = this.sealInfo.attachList && this.sealInfo.attachList.filter(f => f.attachType == attachType)[0]
        } catch (error) {
          console.error(error)
        }

        return item || {}
      }
    }
  },
  data() {
    return {
      isLoading: false,
      pastdialogVisible: false,
      breadcrumb: [],
      isPast: true,
      isView: true,
      sealInfo: {},
      approveMsg: '',
    }
  },

  mounted() {
    this.init()
  },
  methods: {
    init() {
      const bs = this.userinfo && this.userinfo.bs || ''
      this.breadcrumb = [
        { name: '账户管理中心', path: `/${bs == 'B' ? 'purchaserCenter' : 'vendorCenter'}/accountInfo` },
        { name: '印章审核', path: `/${bs == 'B' ? 'purchaserCenter' : 'vendorCenter'}/sealReviewList` },
        { name: '印章详情' },
      ]

      this.isView = this.$route.query.state == 1

      this.getSealReviewDetails()
    },

    getSealReviewDetails() {
      const params = {
        applyId: this.$route.query.applyId
      }

      InterfaceService.getSealReviewDetails(params, data => {
        if (data.respCode === "0000") {
          if (data.respData.respCode == "0000") {
            this.sealInfo = data.respData
            console.log(this.sealInfo, 'sealInfo');

          } else {
            this.$message.error(data.respData.respMsg);
          }
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },

    postSealReviewSubmit() {
      const { corpId, sealId, applyId } = this.sealInfo,
        params = {
          sealKind: this.$route.query.sealKind, //印章类型("personal:个人名章；corp:企业公章；project:项目章；legal:法人名章")
          sealStatus: this.isPast ? 'approved' : 'rejected', //状态（approved:审核通过；rejected:拒绝）
          corpId, //公司ID
          sealId, //印章ID
          applyId, //授权ID
          approveMsg: this.approveMsg, //审批意见
        }
      console.log(params);

      InterfaceService.postSealReviewSubmit(params, data => {
        if (data.respCode === "0000") {
          if (data.respData.respCode == "0000") {
            this.pastdialogVisible = false
            this.isView = true
            this.$setRootLocalStorage('applicationState', '2')
            this.$message.success(`${this.isPast ? '已通过' : '已退回'} , 页面将在1秒后关闭`)
            window.opener && window.opener.location.reload()
            setTimeout(e => {
              window.close()
            }, 1000)

            // let url = window.location.href;  // 获取当前页面的url
            // if (url.indexOf('state') != -1 && url.indexOf("?") != -1) { // 判断是否存在参数
            //   url = url.replace(/state=0/, 'state=1')  // 修改参数
            //   window.history.pushState({}, 0, url)
            // }
            // this.getSealReviewDetails()
          } else {
            this.$message.error(data.respData.respMsg);
          }
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },


    handlePast() {
      this.approveMsg = ''
      this.isPast = true
      this.pastdialogVisible = true
    },
    handleGoBack() {
      this.isPast = false
      this.pastdialogVisible = true
    },
    handleConfirm() {
      if (!this.approveMsg && !this.isPast) {
        this.$message.error('请输入审批意见')
        return
      }
      this.postSealReviewSubmit()
    },
    handlePreview(item) {
      if (item.attachUrl) {
        viewFile(item.attachUrl)
      }
    },
    handleDownload(item) {
      this.$download([{
        name: item.attachName || '',
        url: item.attachUrl || ''
      }]).then(e => this.$message.success('下载完成'))
    },
  },

}
</script>
<style lang="scss" scoped>
.sealReviewDetailContainer {
  .inner-container {
    margin-top: 20px;
    margin-bottom: 100px;
  }
  .header {
    margin-bottom: 20px;
    background: #f5f5f5;
  }
  .header ul {
    width: 100%;
    height: 48px;
    border-bottom: 3px solid #ffd64e;
    font-weight: bold;
    li {
      width: 110px;
      height: 48px;
      line-height: 48px;
      text-align: center;
      float: left;
      cursor: pointer;
      position: relative;

      &:after {
        display: none;
        position: absolute;
        bottom: 0px;
        left: 0;
        content: "";
        width: 110px;
        height: 3px;
        background: #4f525a;
      }
      &.active:after {
        display: block;
      }
    }
  }

  .order-info-title {
    margin: 5px 0;
    margin-bottom: 20px;
    padding: 0 10px;
    font-size: 14px;
    border-left: 3px solid #000;
    line-height: 12px;
    .blue {
      margin-left: 12px;
    }
  }
  .seal-info-container {
    display: flex;
    .seal-info-left {
      width: 480px;
      height: 220px;
      img {
        width: 220px;
        height: 220px;
      }
    }
    .seal-info-right {
      width: 620px;
      height: 220px;
      color: #545454;
      p {
        margin-bottom: 12px;
        .blue {
          margin-left: 12px;
        }
      }
      .mt40 {
        margin-top: 28px;
      }
      .title {
        color: #b6b6b6;
        margin-right: 4px;
      }
    }
  }

  .review-product-table {
    margin-top: 20px;
    /deep/ .el-table__body-wrapper {
      font-size: 12px;
    }

    /deep/ .el-table th,
    .el-table td {
      padding: 14px 0;
    }
    table {
      margin-top: 40px;
      table-layout: fixed;
      width: 100%;
      line-height: 23px;
      font-size: 12px;
      td {
        padding: 14px 20px;
        vertical-align: middle;
        word-break: break-all;
        text-align: left;
      }
      thead {
        font-size: 14px;
        text-align: center;
        white-space: nowrap;
        color: #909399;
        background: #f5f5f5;
      }
      .tbody-row {
        &:hover {
          background: #e8f3fd;
        }
      }
      tbody {
        text-align: center;
        tr {
          border-bottom: 1px solid #ebeef5;
        }
      }
      .opreate {
        div {
          text-align: right;
        }
        span {
          display: block;
        }
      }
    }
  }

  .product-empty {
    padding: 150px;
    text-align: center;
    line-height: 50px;
    color: #909399;
  }
  .line {
    margin-top: 30px;
    border-top: 1px solid #f6f6f6;
    margin-bottom: 20px;
  }
}
.pastDialogContainer {
  .tc {
    display: flex;
    & > span {
      color: #bababa;
      width: 100px;
    }
    .el-textarea {
      width: calc(100% - 100px) !important;
    }
  }
}
</style>

