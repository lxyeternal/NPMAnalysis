<template>
  <div class="success-wrap">
    <Header></Header>
    <SearchBar :is-white-bg="true" :search-type="isAgent ? 5 : 7" :progress="type == 'admin' ? '提交授权委托书': authorization ? '修改授权书' : '资料完善'" :is-border-bottom="true" :product-create-process="3"></SearchBar>
    <div class="success-wrap-content" id='success-wrap-content-res'>
      <div class="success-icon"></div>
      <p class="success-text">提交成功</p>
      <p class="sub-success-text" v-if="!type && !authorization">
        <template v-if="userInfo.bs == 'S'">
          <template v-if="!isAgent">
            感谢您注册成为我们的用户，账户名为 {{ registerName}}，请重新登录后使用。
          </template>
          <template v-if="isAgent"> 公司名为 {{contactName }}。</template>
        </template>
        <template v-else>
          感谢您注册成为我们的用户，账户名为 {{ registerName}}，您提交的企业信息正在审核中，请耐心等待，审核通过后，您将收到注册成功的短信通知。
        </template>
      </p>
      <div class="btn" v-if="!type && isAgent">
        <el-button type="primary" @click="handleAuthorizeManage">去添加授权商品</el-button>
        <el-button @click="$router.push({path:'/vendorCenter/agentManagement'})">查看代理商列表</el-button>
      </div>
      <p class="sub-success-text" v-if="type =='admin'">
        <template v-if="userInfo.bs=='B' || userInfo.corpTags &&  userInfo.corpTags.length">
          您提交的授权委托书正在审核中，请耐心等待，审核通过后，您将收到审核成功的短信通知。
        </template>
        <template v-else>
          提交成功！请重新登录。
        </template>
      </p>
      <div class="tc" v-if="(!type && userInfo.bs == 'S' && !isAgent) || (type =='admin' && userInfo.bs=='S' && (!userInfo.corpTags || !userInfo.corpTags.length))">
        <el-button type="primary" @click="handleLogin">重新登录</el-button>
      </div>
    </div>

  </div>
</template>

<script>
import Header from "@/components/base/Header";
import Footer from '@/components/base/Footer'
import SearchBar from "@/components/SearchBar";

export default {
  components: {
    Header,
    SearchBar,
    Footer,
  },
  data() {
    return {
      registerName: '',
      contactName: '',
      corpId: '',
      type: '',
      isAgent: false, // 是否代理商
      authorization: false,
    };
  },
  computed: {
    userInfo() {
      console.log(this.$store.state.userInfo)
      return this.$store.state.userInfo
    }
  },
  methods: {
    handleLogin() {
      this.$router.push({
        path: '/login'
      })
    },
    handleAuthorizeManage() {
      window.open(this.$router.resolve({
        path: "/authorizeManage",
        query: {
          agentId: this.corpId,
          agentName: this.contactName,
        }
      }).href, '_blank')
    },
    init() {
      this.type = this.$route.query.type || "";
      this.contactName = this.$route.query.contactName || "";
      this.corpId = this.$route.query.corpId || "";
      this.isAgent = this.$route.query.isAgent || false;
      this.authorization = this.$route.query.authorization || false;
      // 代理过来的 不用 固定在此页面
      if (!this.isAgent) {
        this.$setRootScope("registerPath", JSON.stringify({ path: this.$route.path, query: this.$route.query }));
      } else {
        this.$removeRootScope('registerPath')
      }
      this.$removeRootScope('registerAdvancedInfo');
      this.$removeRootScope('agentUserInfo');
      this.userInfo.corpStatus = '0';
      this.registerName = this.$getRootScope('registerName') || this.userInfo.acctName
    },

  },
  mounted() {
    this.init();

    let w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
    document.getElementById('success-wrap-content-res').style.height = (h - 55 - 34 - 160) + 'px';
  }
};
</script>

<style lang="scss" scoped>
.btn {
  margin-top: 40px;
  text-align: center;
  .el-button {
    width: 260px;
    height: 50px;
    text-align: center;
    line-height: 50%;
    padding: 0px !important;
  }
}
.success-wrap-content {
  padding-top: 90px;
  height: 100%;
}
.success-icon {
  width: 56px;
  height: 56px;
  margin: 0 auto 25px;
  background: url(../../../assets/images/green_yes.png) no-repeat 0 0;
}
.success-text {
  font-size: 20px;
  color: #333;
  text-align: center;
}
.sub-success-text {
  width: 540px;
  font-size: 12px;
  color: #333;
  text-align: center;
  margin: 15px auto;
  line-height: 20px;
}
</style>