<template>
  <div class="changeMail-wrap">
    <Header :is-white-bg="isWhiteBg"></Header>
    <div class="pageTop" :class="{purpleBg: bigInfrastructure}">
      <div class="logo fl">
        <img src="@/assets/images/logo_s.png">
        <div class="company-info">
          <p>{{userInfo.bs == 'B' ? "采购":"供应"}}商管理中心</p>
        </div>
        <div class="company-info f16" style="padding-left: 130px;">
          <p class="go-index hand" @click="goIndex">建材集采</p>
        </div>
      </div>
    </div>
    <div class="changeMail-wrap-inner" id="changeMail-wrap-inner">
      <div class="contain inner-container">
        <Breadcrumb v-if="breadcrumb && breadcrumb.length" :breadcrumbList="breadcrumb" @refresh="handleGoBack()"></Breadcrumb>
        <div class="errorMsg" v-if="errorMsg.false">
          <img src="../../assets/images/login/notice.png" alt="">{{errorMsg.false}}
        </div>
        <el-form :model="ruleForm" ref="ruleForm" :rules="rules" class="form demo-dynamic" label-width="100px" onsubmit="return false;">
          <p class="hint">
            <i class="el-icon-info"></i>
            请确保您输入的新邮箱能正常接收激活邮件，邮箱才能生效。
          </p>
          <el-form-item label="姓名：">
            <span>{{userInfo.acctName}}</span>
          </el-form-item>
          <el-form-item label="新邮箱：" prop="email" class="codeMobile">
            <el-autocomplete ref="autocomplete" :fetch-suggestions="querySearch" :trigger-on-focus="false" type="text" @focus="inputEmail" v-model="ruleForm.email" placeholder="请输入邮箱" clearable> </el-autocomplete>
            <div class="error-msg red" v-if="errorMsg.email">{{errorMsg.email}}</div>
          </el-form-item>
          <el-form-item label="验证码：" prop="validateCode">
            <div class='validate-code' :class="{'visible':isShowValidate}">
              <ValidateCode :is-show-validate="true" @received="getCode" :update="updateCode"></ValidateCode>
              <div class="error-msg red" v-if="errorMsg.validateCode">{{errorMsg.validateCode}}</div>
            </div>
          </el-form-item>
          <el-form-item label="邮箱验证码：" prop="identifyCode">
            <PhoneCode :is-show-phone-code="true" :update="updateCode" :type="'2'" :phone="ruleForm.email" :imgCode="ruleForm.validateCode" :origTxCode="'changeEmail'" :disable="!this.ruleForm.validateCode || !this.ruleForm.email" @error="getError" @received="getMailCode">

            </PhoneCode>
            <div class="error-msg red" v-if="errorMsg.identifyCode">{{errorMsg.identifyCode}}</div>
          </el-form-item>
          <div class="tc">
            <el-button type="primary" class="large-btn" @click="onSubmit('rules')">确认</el-button>
          </div>
          <div class="help">
            <p>邮箱验证码收不到帮助：</p>
            <p>1.您的邮箱验证码可能需要10分钟才能到达您的注册邮箱（这取决于您的邮箱运营商），为避免系统错误请不要重复点击。</p>
            <p>2.请检查您的邮箱是否已停止服务或邮件是否流入垃圾箱或邮箱收件箱已满。</p>
            <p>3.网络异常可能导致邮件丢失，请您重新点击“获取验证码”或稍后使用不同的浏览器或清除浏览器缓存重试。</p>
          </div>
        </el-form>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import {
  mapActions,
  mapState
} from 'vuex'
import SearchBar from '@/components/SearchBar'
import Header from '@/components/base/Header'
import Loading from '@/components/base/Loading'
import ValidateCode from '@/components/base/ValidateCode'
import PhoneCode from '@/components/base/PhoneCode';
// import ValidateCode from '@/components/base/ValidateCode.vue';
import {
  InterfaceService
} from '@/services/api'
import Breadcrumb from "@/components/base/Breadcrumb";
import accountMixin from "@/mixins/account"

export default {
  props: ['isShowValidate'],
  mixins: [accountMixin],
  components: {
    SearchBar,
    Header,
    Loading,
    ValidateCode,
    Breadcrumb,
    PhoneCode
  },
  data() {
    return {
      number: 4,
      updateCode: 0,
      //imgUrl: this.$getConfig().IMAGE_SERVLET,
      validateCode: '', // 图片验证码
      isWhiteBg: true,
      pageName: '修改邮箱',
      searchType: 5,
      isLoading: false,
      breadcrumb: [],
      errorMsg: {},
      identifyCode: '', // 邮箱验证码
      ruleForm: {
        email: '',
        validateCode: '',
        identifyCode: ''
      },
      rules: {
        email: [
          { required: true, message: '请输入邮箱地址', trigger: 'blur' },
          { pattern: this.$commonExpression('email'), message: '请输入正确的邮箱地址', trigger: ['blur', 'change'] },
          { max: 64, message: "邮箱不得大于64个字", trigger: "blur" }
        ],//新邮箱
        validateCode: [],
        identifyCode: [{ required: true, message: "请输入邮箱验证码", trigger: 'blur' }]
      }
    }
  },
  computed: {
    isLogin() {
      return this.$store.state.isLogin
    },
    userInfo() {
      return this.$store.state.userInfo
    }
  },
  methods: {
    querySearch(queryString, callback) {
      let commonMailbox = this.$commonMailbox()
      let results = this.$clone(commonMailbox)
      let value = ''
      if(queryString && queryString.indexOf('@') != -1){
        value = queryString.substring(0, queryString.indexOf('@'))
      }else{
        value = queryString
      }
      results.forEach((i,index) =>{
          i.value = value + '' + commonMailbox[index].value
      })
      callback(results)
      this.$refs.autocomplete.handleFocus()
    },
    init() {
      const breadcrumb = JSON.parse(this.$getRootScope('breadcrumb') || '[]')
      this.breadcrumb = (breadcrumb && breadcrumb.length) && breadcrumb || []
    },
    handleGoBack() {
      this.$router.go(-1);
    },
    goIndex() {
      this.$router.push("/");
    },
    ...mapActions(['setUserInfoAction']),
    getCode: function (code) {
      console.log(code, '-code');

      this.ruleForm.validateCode = code;
      code && (delete this.errorMsg['validateCode'])
      this.$forceUpdate();
    },
    getMailCode(identifyCode) {
      this.ruleForm.identifyCode = identifyCode
      this.$forceUpdate();
    },
    // 判断图形验证码是否正确
    getError(msg) {
      this.updateCode++;
      console.log(msg, '-msg');
      if (msg == '邮箱格式不正确') {
        // this.ruleForm.email = '';
        // this.$set(this.errorMsg, 'email', msg);
        this.$message.error(msg);
      } else {
        this.ruleForm.validateCode = '';
        this.$set(this.errorMsg, 'validateCode', msg);
      }
      this.$forceUpdate();
    },
    inputEmail() {
      this.errorMsg.email = ''
    },
    onSubmit(rules) {
      this.errorMsg = {}
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          var params = {
            'email': this.ruleForm.email,
            'validateCode': this.ruleForm.validateCode,
            'identifyCode': this.ruleForm.identifyCode
          }
          InterfaceService.changeEmail(params, (data) => {
            console.log(data)
            let res = data.respData;
            if (res.respCode == "0000") {

              //去缓存里更改userInfo
              let userInfo = JSON.parse(this.$getRootScope('user'))
              userInfo.email = this.ruleForm.email
              this.$setRootScope('user', JSON.stringify(userInfo))
              this.setUserInfoAction(userInfo)
              // this.$router.go(-1)
              this.$router.push({
                path: "/changeSuccess",
                query: {
                  type: '2'
                }
              });

            } else if (res.respCode == 'F000002') {
              this.$set(this.errorMsg, 'validateCode', res.respMsg);
            } else if (res.respCode == 'F000003' || res.respCode == 'F000005' || res.respCode == 'F000004') {

              if (res.respCode == 'F000005') {
                this.updateCode++
              }
              this.$set(this.errorMsg, 'identifyCode', res.respMsg);
            } else if (res.respCode == 'MEM0111' || res.respCode == 'MEM0110' || res.respCode == 'MEM0165' || res.respCode == 'MEM0115') {
              this.$set(this.errorMsg, 'email', res.respMsg);
            } else if (res.respCode == 'S0001') {  // 失败或为空
              this.$set(this.errorMsg, 'false', '修改邮箱失败，请重试');
            } else {
              this.$message.error(res.respMsg);
            }

            this.$forceUpdate();
          })
        } else {
          console.log('error submit!!');
          return false;
        }
      });

    },
  },
  watch: {

  },
  mounted() {
    this.init()
  },

  destroyed() {
    this.$removeRootScope('breadcrumb')
  }
}
</script>

<style scoped lang="scss">
/deep/ .el-form-item__label {
  color: #888888;
}

.errorMsg {
  background-color: #ffdfe0;
  line-height: 20px;
  font-size: 14px;
  color: #e8323e;
  position: relative;
  padding: 10px 10px 10px 35px;
  margin: 60px auto;
  width: 55%;
  text-align: center;
  img {
    position: absolute;
    top: 12px;
    left: 248px;
  }
}
.changeMail-wrap .search-bar-container {
  height: 100%;
  padding-top: 15px;
}

.changeMail-wrap-inner {
  height: 710px;
  border-top: 2px solid #ffd64e;
}

.changeMail-wrap .contain {
  position: relative;
  height: 100%;

  /deep/ .el-form-item.is-required {
    .el-form-item__label:before {
      display: none;
    }
  }
}

.changeMail-wrap .form {
  width: 650px;
  position: absolute;
  right: 0;
  top: 0;
  left: 0;
  bottom: 0;
  margin: auto;
  margin-top: 90px;
  .hint {
    font-size: 14px;
    font-weight: 900;
    margin-bottom: 30px;
    margin-left: 100px;

    i {
      color: #5dc539;
      font-size: 16px;
    }

    .phone {
      color: red;
      font-weight: 700;
    }

    span:nth-last-child(1) {
      font-weight: 700;
      color: #989898;
    }
  }

  .help {
    margin-top: 20px;
    margin-left: 0;
    color: #888888;

    p {
      margin-bottom: 10px;
    }

    p:nth-child(1) {
      margin-bottom: 30px;
    }
  }
}
.pageTop {
  position: relative;
  width: 100%;
  height: 60px;
  margin: 0 auto;
  background: linear-gradient(
    145deg,
    rgba(215, 176, 100, 1) 0%,
    rgba(236, 206, 139, 1) 100%
  );
  opacity: 1;
  &.purpleBg {
    background: linear-gradient(134deg, #6424de 0%, #a36df8 100%);
  }
  .logo {
    position: absolute;
    left: 0;
    bottom: 0;
    right: 0;
    margin: auto;
    width: 1190px;
    height: 60px;
    line-height: 60px;
  }
  img {
    vertical-align: middle;
  }

  .company-info {
    display: inline-block;
    padding: 0 4px;
    font-size: 18px;
    line-height: 60px;
    vertical-align: top;
    color: #ffffff;
    .hl22 {
      line-height: 22px;
      font-size: 14px;
    }
  }
}
.go-index {
  padding: 0 20px;
  &:hover {
    font-weight: 600;
    color: #fae2a5;
    background: linear-gradient(
      180deg,
      rgba(16, 16, 24, 1) 0%,
      rgba(90, 88, 88, 1) 100%
    );
  }
}
</style>