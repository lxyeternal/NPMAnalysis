<template>
  <div class="activate-wrap">
    <Header :is-white-bg="isWhiteBg"></Header>
    <search-bar :searchType="searchType" :progress='pageName'></search-bar>
    <div class="activate-wrap-inner" id="activate-wrap-inner">
      <div class="contain inner-container" v-if="tab == 1">
        <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="150px" class="form" onsubmit="return false;">
          <p class="hint">
            <i class="el-icon-info"></i>
            为激活您的账号，需确认手机号
            <span class="phone">{{userInfo.mobileNo}}</span> 为您本人操作，请完成以下验证，并设置您的登录密码
            <br>
            <!-- <span>若手机号不正确，或无法收到手机验证码请联系 {{$platformContact()['hotLine']}} </span> -->
          </p>
          <el-form-item label="输入密码：" prop="inputPwd">
            <el-input type="password" placeholder="请输入密码" v-model="ruleForm.inputPwd" v-popover:popoverPwd @blur="checkForm('inputPwd')" auto-complete="off" clearable></el-input>
            <el-popover ref="popoverPwd" placement="right" title="" width="300" trigger="focus">
              <div class="guid-text guid-1"><i class="el-icon-circle-check" :class="{'green':instant && instant ==2}"></i>必须是6-18个字母和数字</div>
              <div class="guid-text guid-2"><i class="el-icon-circle-check" :class="{'green':instant && instant >=1}"></i>同时包含字母和数字</div>
              <!-- <div class="guid-text guid-3"><i :class="{'el-icon-circle-check':!ruleForm.inputPwd,'el-icon-circle-close green':ruleForm.inputPwd &&(ruleForm.inputPwd == userInfo.acctName ) ,'el-icon-circle-check green':ruleForm.inputPwd &&(ruleForm.inputPwd != userInfo.acctName )}"></i>密码不能与用户名相同</div> -->
            </el-popover>
            <div class="error-msg red" v-if="errorMsg.inputPwd">{{errorMsg.inputPwd}}</div>
          </el-form-item>
          <el-form-item>
            <div class='phone-code'>
              <PwdStrength :pwd="ruleForm.inputPwd" @received="getPwdStrength" @instant="getPwdInstant"></PwdStrength>
            </div>
          </el-form-item>
          <el-form-item label="确认密码：" prop="confirmPwd">
            <el-input type="password" placeholder="请再次输入密码" v-model="ruleForm.confirmPwd" @blur="checkForm('confirmPwd')" auto-complete="off" clearable></el-input>
            <div class="error-msg red" v-if="errorMsg.confirmPwd">{{errorMsg.confirmPwd}}</div>
          </el-form-item>
          <el-form-item label="验证码：" prop="validateCode">
            <ValidateCode :is-show-validate="true" @received="getCode" :update="updateCode"></ValidateCode>
            <div class="error-msg red" v-if="errorMsg.validateCode">{{errorMsg.validateCode}}</div>
          </el-form-item>
          <el-form-item label="手机验证码：" prop="identifyCode">
            <PhoneCode :is-show-phone-code="true" :update="updateCode" :type="'1'" :disable="!this.ruleForm.validateCode || !userInfo.mobileNo" :phone="userInfo.mobileNo" :imgCode="ruleForm.validateCode" :origTxCode="'acitveAccount'" @error="getError" @received="getPhoneCode">
            </PhoneCode>
            <div class="error-msg red" v-if="errorMsg.identifyCode">{{errorMsg.identifyCode}}</div>
          </el-form-item>
          <el-button type="primary" @click="onSubmit('rules')">确认</el-button>
        </el-form>
      </div>
      <div class="activate-wrap-inner" v-if="tab ==2">
        <div class="contain inner-container">
          <el-form ref="form" :model="form" :rules="rules" label-width="195px">
          </el-form>
          <div style="margin-top: 20px;">
            <span class="order-info-title">公司授权管理员</span>
            <i class="red f12">需提供公司授权管理员以公司名义在大家采平台上进行操作的授权书。请点击【下载模板】，填写《大家采平台管理员授权委托书》并加盖公司公章后，上传授权书的PDF扫描件。</i>
          </div>
          <el-form ref="form" :model="form" :rules="formRules" label-width="195px">
            <div class="info-panel-content">
              <div class="form-inline-item">
                <el-form-item label="管理员姓名：" prop="adminName">
                  <el-input disabled v-model="form.adminName" placeholder="请输入姓名" @focus="checkForm('adminName')" maxlength="10"></el-input>
                  <div class="el-form-item__error" v-if="errorRules['adminName']">
                    {{ errorRules["adminName"] }}
                  </div>
                </el-form-item>
                <el-form-item label="管理员身份证号：" prop="adminCertNo">
                  <el-input v-model="form.adminCertNo" placeholder="请输入身份证号" @focus="checkForm('adminCertNo')"></el-input>
                  <div class="el-form-item__error" v-if="errorRules['adminCertNo']">
                    {{ errorRules["adminCertNo"] }}
                  </div>
                </el-form-item>
              </div>
              <div class="form-inline-item">
                <el-form-item label="管理员手机号：" prop="adminMobile">
                  <el-input disabled v-model="form.adminMobile" placeholder="请输入手机号" @focus="checkForm('adminMobile')"></el-input>
                  <div class="el-form-item__error">
                    ※该手机号将作为管理员登录大家采的账号
                  </div>
                </el-form-item>
                <el-form-item label="管理员邮箱：" prop="adminEmail">
                  <el-autocomplete ref="autocomplete" :fetch-suggestions="querySearch" :trigger-on-focus="false" v-model="form.adminEmail" placeholder="请输入邮箱" @focus="checkForm('adminEmail')" maxlength="64"></el-autocomplete>
                  <div class="el-form-item__error" v-if="errorRules['adminEmail']">
                    {{ errorRules["adminEmail"] }}
                  </div>
                </el-form-item>
                <el-form-item label="部门：" prop="department">
                  <el-input v-model="form.department" placeholder="请输入部门" @focus="checkForm('department')" maxlength="50"></el-input>
                  <div class="el-form-item__error" v-if="errorRules['department']">
                    {{ errorRules["department"] }}
                  </div>
                </el-form-item>
                <el-form-item label="职务：" prop="position">
                  <el-input v-model="form.position" placeholder="请输入职务" @focus="checkForm('position')" maxlength="40"></el-input>
                  <div class="el-form-item__error" v-if="errorRules['position']">
                    {{ errorRules["position"] }}
                  </div>
                </el-form-item>
              </div>
              <div class="form-item" style="width:60%;">
                <el-form-item label="授权委托期：" prop="effectiveStartdate">
                  <el-row>
                    <el-col :span="11">
                      <el-date-picker value-format="yyyy-MM-dd" v-model="form.effectiveStartdate" size="" type="date" placeholder="开始日期">
                      </el-date-picker>
                    </el-col>
                    <el-col :span="2" class="tc">~</el-col>
                    <el-col :span="11">
                      <el-date-picker value-format="yyyy-MM-dd" v-model="form.effectiveEnddate" size="" type="date" placeholder="结束日期">
                      </el-date-picker>
                    </el-col>
                  </el-row>
                  <div class="el-form-item__error" v-if="errorRules['effectiveStartdate']">
                    {{ errorRules["effectiveStartdate"] }}
                  </div>
                </el-form-item>
              </div>
            </div>
            <el-form-item label="上传授权书：" :required="true" class="authorization">
              <el-col :span="20">
                <ul class="neet-upload-upfile" :class="{isie:isIE11}">
                  <li>
                    <p class="input-file-p">
                      <span class="gray">
                        请上传授权书
                      </span>
                    </p>
                  </li>
                  <li>
                    <div class="upfile-container">
                      <div class="center">
                        <label class="blue">
                          <UpfileComponent ref="upfileRef" :immediateClearList="true" :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :btnName="'选择文件'" :dirName="`${new Date().getTime()}/`" :type="'13'" :fileTypes="uploadFileSuffix" :id="'123'" @outputList="handleUpFileResult($event)"></UpfileComponent>
                        </label>
                      </div>
                    </div>
                  </li>
                </ul>
              </el-col>
              <el-col :span="4">
                <el-button size="small" style="height: 40px;width: 120px;margin-left:20px;" @click="handleDownTemp">下载模板</el-button>
              </el-col>
            </el-form-item>
          </el-form>
          <div class="upload-cont">
            <div class="upload-title">
              <span>
                已上传文本
              </span>
              <span>
                上传时间
              </span>
              <span>
                操作
              </span>
            </div>
            <div class="upload-title tl" v-if="authorizationInfo.attachName">
              <span>
                <em @click="handleViewFile" :class="{hand:canView,blue:canView}">{{authorizationInfo.attachName}}</em>
              </span>
              <span>
                {{authorizationInfo.creTm}}
              </span>
              <span>
                <i class="hand blue" @click="delFileInfo">删除</i>
              </span>
            </div>
          </div>
          <div class="tc">
            <el-button type="primary" class="large-btn" @click="handleSubmit">提交</el-button>
          </div>
        </div>
      </div>
    </div>

    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import {
  mapActions,
  mapState
} from 'vuex'
import SearchBar from '@/components/SearchBar'
import Header from '@/components/base/Header'
import Loading from '@/components/base/Loading'
import PwdStrength from '@/components/base/PwdStrength'
import ValidateCode from '@/components/base/ValidateCode';
import PhoneCode from '@/components/base/PhoneCode';
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
import { DateUtil } from '@/utils/dateUtil';

import {
  InterfaceService
} from '@/services/api'
import CryptoJS from 'crypto-js';
import { viewFile } from '@/utils/orderUtil';

export default {
  props: ['isShowValidate'],
  components: {
    SearchBar,
    Header,
    Loading,
    PwdStrength,
    ValidateCode,
    UpfileComponent,
    PhoneCode
  },
  data() {
    var validateEffectiveStartdate = (rule, value, callback) => {
      if (value) {
        var thetimeFirst = value
        var thetimeSecond = this.form.effectiveEnddate
        if (thetimeSecond && thetimeFirst > thetimeSecond) {
          this.form.effectiveStartdate = ''
          // this.form.dealTo = ''
          callback(new Error('请选择有效的授权委托期'));
        } else {
          callback();
        }

      } else {
        callback();
      }
    };
    var validatePass = (rule, value, callback) => {

      if (value === '') {
        callback(new Error('请输入密码'));
      } else {
        this.ruleForm.inputPwd = this.ruleForm.inputPwd.replace(/[^\u4e00-\u9fa5\w]/g, '')
        if (this.ruleForm.inputPwd.length >= 18) {
          this.ruleForm.inputPwd = this.ruleForm.inputPwd.substr(0, 18)
        }
        if (this.strength <= 1) {
          callback(new Error('密码设置不符合要求'));
        } else {
          callback()
        }
      }
    };
    var validatePass2 = (rule, value, callback) => {
      if (!/^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-zA-Z0-9]+[-a-z0-9]*[a-zA-Z0-9]+.){1,63}[a-zA-Z0-9]+$/.test(value)) {
        callback(new Error('邮箱格式不正确'));
      } else {
        const mail = value || '',
          mailSuffix = mail.slice(mail.lastIndexOf('.') + 1, mail.length)

        const errorMailSuffix = JSON.parse(this.$getRootLocalStorage('errorMailSuffix') || '[]')
        if (errorMailSuffix.includes(mailSuffix)) {
          callback(new Error('邮箱后缀不正确'));
          return
        }
        callback();
      }
    };

    var identifyCodeValueChange = (rule, value, callback) => {
      console.log(this.ruleForm.identifyCode, 'identifyCode-');
      if (this.ruleForm.identifyCode === '' || this.ruleForm.identifyCode === undefined) {
        callback(new Error('请输入验证码'));
      } else {
        callback();
      }
    };

    return {
      updateCode: 0,
      tab: 1,
      validateCode: '',// 图片验证码
      isWhiteBg: true,
      pageName: '激活账户',
      searchType: 5,
      isLoading: false,
      strength: '',
      instant: '',
      errorRules: {},
      identifyCode: '',// 手机验证码
      errorMsg: {},
      form: {
        effectiveStartdate: '',
        effectiveEnddate: '',
        adminName: "",
        adminCertNo: "",
        adminMobile: "",
        department: "",
        position: "",
        adminEmail: "",
      },
      ruleForm: {
        inputPwd: '',// 默认密码
        confirmPwd: '',// 新密码
      },
      rules: {
        inputPwd: [
          { required: true, message: "请输入密码", trigger: 'blur' },

        ],
        confirmPwd: [
          { required: true, message: "请确认密码", trigger: 'blur' },
        ],
        validateCode: [],
        // identifyCode:[{required: true, message: "请输入验证码",trigger: 'blur'}]
        identifyCode: [{ validator: identifyCodeValueChange, trigger: 'change' }]
      },
      formRules: {
        adminName: [
          {
            required: true,
            message: "必填"
          },
          { pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]{2,200}$/, max: 200, message: "姓名设置不符合要求", trigger: "blur" }
        ],
        adminCertNo: [
          {
            required: true,
            message: "必填"
          },
          { pattern: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/, max: 20, message: "身份证号码不正确", trigger: "blur" }
        ],
        adminMobile: [
          {
            required: true,
            message: "必填"
          },
          { pattern: /^[1][0-9][0-9]{9}$/, max: 11, message: "手机号格式不正确", trigger: "blur" }
        ],
        adminEmail: [
          {
            required: true,
            message: "必填"
          },
          { validator: validatePass2, trigger: 'blur' },
        ],
        department: [
          {
            required: true,
            message: "必填"
          },
          { max: 50, message: "部门名称不得大于50个字", trigger: "blur" }
        ],
        position: [
          {
            required: true,
            message: "必填"
          },
          { max: 40, message: "职务名称不得大于40个字", trigger: "blur" }
        ],
        effectiveStartdate: [
          {
            required: true,
            message: "必填"
          },
          { validator: validateEffectiveStartdate, trigger: 'blur' }
        ],
      },
      templateFileUrl: "",
      templateFileName: "",
      uploadFileSuffix: "",
      delId: "",
      authorizationInfo: {},
      returnAddressPath: '', // 完成后返回路径
    }
  },
  computed: {
    isLogin() {
      return this.$store.state.isLogin
    },
    isIE11() {
      let userAgent = navigator.userAgent;
      return userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; // ie11<11
    },
    userInfo() {
      // console.log(this.$store.state.LoginedUser.custName)
      return this.$store.state.userInfo
    },
    canView() {
      return this.authorizationInfo.attachUrl && this.authorizationInfo.attachUrl.indexOf('https') != -1
    }
  },

  methods: {
    ...mapActions(['setUserInfoAction']),
    querySearch(queryString, callback) {
      let commonMailbox = this.$commonMailbox()
      let results = this.$clone(commonMailbox)
      let value = ''
      if (queryString && queryString.indexOf('@') != -1) {
        value = queryString.substring(0, queryString.indexOf('@'))
      } else {
        value = queryString
      }
      results.forEach((i, index) => {
        i.value = value + '' + commonMailbox[index].value
      })
      callback(results)
      this.$refs.autocomplete.handleFocus()
    },
    handleSubmit() {
      if (!this.authorizationInfo.attachName) {
        this.$message.error('请上传授权书')
        return false
      }
      console.log(this.authorizationInfo, 'authorizationInfo');

      this.$refs.form.validate((valid) => {
        if (valid) {
          let params = Object.assign({}, this.form);
          params.approveId = this.$route.query.approveId || this.userInfo.approveId;
          params.approveType = "apply";
          params.approveAttachList = [{
            attachType: "2",
            attachName: this.authorizationInfo.attachName,
            attachUrl: this.authorizationInfo.attachPath,
          }];
          InterfaceService.adminApproval(
            params,
            data => {
              if (data && data.respData && data.respData.respCode === "0000") {
                this.userInfo.custStatus = '0';
                if (this.userInfo.bs == 'S' && (!this.userInfo.corpTags || !this.userInfo.corpTags.length)) {
                  this.$message.success("提交成功！")
                  this.$removeRootScope('registerPath');
                  if (this.userInfo && this.userInfo.bs == 'B') {
                    this.$router.push(`/purchaserCenter/${this.returnAddressPath || 'accountInfo'}`, )
                  } else {
                    this.$router.push(`/vendorCenter/${this.returnAddressPath || 'accountInfo'}`, )
                  }
                } else {
                  this.$router.push({ path: '/registerSuccess', query: { type: 'admin' } });
                }
              } else {
                this.$message.error(data.respData.respMsg);
              }
            },
            data => {
              this.$message.error(data.respMsg);
            },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            }
          )
        }
      });

    },
    handleViewFile() {
      if (this.canView) {
        viewFile(this.authorizationInfo.attachUrl)
      }
    },
    handleUpFileResult(e) {
      this.delFileInfo()
      const { file, name, targetValue, url } = e[0]
      this.authorizationInfo = {
        file: file,
        attachName: name,
        creTm: DateUtil.dateToString(),
        targetValue,
        attachPath: url
      }
    },
    delFileInfo() {
      if (this.authorizationInfo.id) {
        this.delId = this.authorizationInfo.id;
      }
      this.authorizationInfo = {};
    },
    getOrderConfiguration() {
      const params = {
        businessType: 'AUTHORIZATION'
      };
      InterfaceService.getOrderConfiguration(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          let list = res.uploadFileList || [];
          list.forEach(item => {
            if (item.fileTypeId === "regist_authorization") {
              this.templateFileUrl = item.attachUrl || "";
              this.templateFileName = item.templateFileName || "";
              this.uploadFileSuffix = item.uploadFileSuffix || "";

            }
          })
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    handleDownTemp() {
      this.$download([{
        name: this.templateFileName || '',
        url: this.templateFileUrl || ''
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    checkForm(key) {
      //密码验证
      if (key == 'inputPwd') {
        this.ruleForm[key] = this.ruleForm[key].replace(/[^\u4e00-\u9fa5\w]/g, '')

        if (this.ruleForm[key].length >= 18) {
          this.ruleForm[key] = this.ruleForm[key].substr(0, 18)
        }

        if (!this.ruleForm[key]) {
          this.errorMsg[key] = '请输入密码'
        }
        if (this.ruleForm[key] && this.strength <= 1) {
          this.errorMsg[key] = '密码设置不符合要求'
          // if(this.model[key] == this.model['acctName']){
          //   this.loginPwdError = true
          // }
          this.$forceUpdate();
          this.$set(this.ruleForm, this.ruleForm);
          this.$set(this.errorMsg, this.errorMsg);
          return false;
        } else {
          delete this.errorMsg[key]
        }

        if (this.ruleForm.confirmPwd && this.ruleForm.confirmPwd != this.ruleForm.inputPwd) {
          this.errorMsg['confirmPwd'] = '两次输入的密码不一致，请重新输入'
        } else {
          //delete this.errorMsg['inputPwd']
          delete this.errorMsg['confirmPwd']
        }

      }
      //密码验证
      if (key == 'confirmPwd') {
        if (!this.ruleForm[key]) {
          this.errorMsg[key] = '请确认密码'
        }
        if (this.ruleForm.inputPwd && this.ruleForm.confirmPwd != this.ruleForm.inputPwd) {
          this.errorMsg[key] = '两次输入的密码不一致，请重新输入'
        } else {
          delete this.errorMsg[key]
        }
      }
      this.$forceUpdate();
      this.$set(this.ruleForm, this.ruleForm);
      this.$set(this.errorMsg, this.errorMsg);
    },
    getPwdStrength: function (strength) {  //strength = 1弱
      this.strength = strength
    },
    getPwdInstant(instant) {
      this.instant = instant
    },
    getCode: function (code) {
      this.ruleForm.validateCode = code;
      this.$forceUpdate();
      code && (delete this.errorMsg['validateCode']);
    },
    getPhoneCode(identifyCode) {
      // 输入时 移除 后台返回 错误提示
      this.errorMsg.identifyCode = ''
      this.ruleForm.identifyCode = identifyCode;// 手机验证码
      this.$forceUpdate();
    },
    // 判断图形验证码是否正确
    getError(msg) {
      this.ruleForm.validateCode = ''
      this.updateCode++;
      this.$set(this.errorMsg, 'validateCode', msg);
      this.$forceUpdate();
    },
    onSubmit(rules) {
      for (let key in this.errorMsg) {
        if (this.errorMsg[key]) {
          return false;
        }
      }
      // if(this.errorMsg['confirmPwd']){
      //   return false
      // }
      this.$refs.ruleForm.validate((valid) => {
        this.errorMsg = {}
        if (valid) {
          let inputPwd = CryptoJS.MD5(this.ruleForm.inputPwd).toString();
          let confirmPwd = CryptoJS.MD5(this.ruleForm.confirmPwd).toString();
          var params = {
            'mobile': this.$store.state.userInfo.mobileNo,
            'inputPwd': inputPwd,
            'confirmPwd': confirmPwd,
            'validateCode': this.ruleForm.validateCode,
            'identifyCode': this.ruleForm.identifyCode
          }
          //没有授权书，先上传授权书
          InterfaceService.activateTheAccount(params, (data) => {
            let res = data.respData;
            if (res.respCode == 'MEM0026' || res.respCode == "MEM0093") {
              // 密码错误
              this.$set(this.errorMsg, 'inputPwd', res.respMsg);
            } else if (res.respCode == 'MEM0092') {
              // 确认密码错误
              this.$set(this.errorMsg, 'confirmPwd', res.respMsg);
            } else if (res.respCode == 'MEM0025' || res.respCode == "MEM0141") {
              // 手机号错误
              this.$alert(
                "手机号错误",
                {
                  customClass: "alert-box",
                  center: true,
                  confirmButtonText: "知道了",
                  callback: action => { }
                }
              );
            } else if (res.respCode == "0000" || res.respCode == 'MEM0029') {
              // 成功和已激活
              let adminRoles = ['1000', '2000', '3000', '4000', '5000', '9000']
              let isAdmin = this.userInfo.roleIds && this.userInfo.roleIds.some(item => {
                return adminRoles.indexOf(item.roleId) != -1
              });
              if (isAdmin && !this.userInfo.attachUrl) {

                // 显示 完善信息
                const resulstOuter = this.userInfo || {},
                  corpItem = resulstOuter.corpList && resulstOuter.corpList.find(f => f.corpId == resulstOuter.corpId) || {}
                  // ES 导入激活
                if (corpItem.enterFrom == '2') {
                  this.$message.success('激活成功, 请重新登录。')
                  // this.$setRootScope('sessionShowEsUserPerfectListDialog', '1')
                  this.$router.push('/login');
                  return
                }

                this.getAcctInfo()
                window.scrollTo(0, 0)
                this.tab = 2;
                this.getOrderConfiguration();
              } else {
                this.userInfo.custStatus = '0';
                this.$removeRootScope('registerPath');
                if (this.userInfo && this.userInfo.bs == 'B') {
                  this.$router.push(`/purchaserCenter/${this.returnAddressPath || 'accountInfo'}`, )
                } else {
                    this.$router.push(`/vendorCenter/${this.returnAddressPath || 'accountInfo'}`, )
                }
              }
            } else if (res.respCode == 'MEM0028') {
              // 激活失败
              this.$alert(
                "激活失败",
                {
                  customClass: "alert-box",
                  center: true,
                  confirmButtonText: "知道了",
                  callback: action => { }
                }
              );
            }
            else if (res.respCode == 'F000002') {
              this.$set(this.errorMsg, 'validateCode', res.respMsg);
            } else if (res.respCode == 'F000003' || res.respCode == 'F000005') {
              this.$set(this.errorMsg, 'identifyCode', res.respMsg);
              if (res.respCode == 'F000005') {
                this.updateCode++
              }
            }
          })
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    getAcctInfo() {
      InterfaceService.accountInfo({ acctId: this.userInfo.acctId }, (data) => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.isAdminInfo = data.respData || {};
          this.form.adminName = this.isAdminInfo.accName;
          this.form.adminCertNo = this.isAdminInfo.certNo;
          this.form.adminMobile = this.isAdminInfo.mobile;
          this.form.adminEmail = this.isAdminInfo.email;
          this.form.department = this.isAdminInfo.dept || '';
          this.form.position = this.isAdminInfo.title || '';
          this.form.effectiveStartdate = this.isAdminInfo.effectiveStartdate || '';
          this.form.effectiveEnddate = this.isAdminInfo.effectiveEnddate || '';
          let info = this.isAdminInfo.attachInfo || {}
          this.authorizationInfo = {
            attachName: info.attachName || '',
            creTm: this.formatDate(info.creTm || ''),
            attachUrl: info.attachUrl || '',
            attachPath: info.attachPath || '',
          };
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      });
    },
    formatDate(datetime) {
      let date = new Date(datetime);
      let year = date.getFullYear(),
        month = ("0" + (date.getMonth() + 1)).slice(-2),
        sdate = ("0" + date.getDate()).slice(-2),
        hour = ("0" + date.getHours()).slice(-2),
        minute = ("0" + date.getMinutes()).slice(-2),
        second = ("0" + date.getSeconds()).slice(-2);
      // 拼接
      let result = year + "-" + month + "-" + sdate + " " + hour + ":" + minute + ":" + second;
      // 返回
      return result;
    }
  },
  mounted() {
    this.$setRootScope("registerPath", JSON.stringify({ path: this.$route.path, query: this.$route.query }));

    this.returnAddressPath = this.$route.query.path || ''

    let adminRoles = ['1000', '2000', '3000', '4000', '5000', '9000']
    let isAdmin = this.userInfo.roleIds && this.userInfo.roleIds.some(item => {
      return adminRoles.indexOf(item.roleId) != -1
    });
    if (this.userInfo.custStatus == "0" && isAdmin) {
      this.getAcctInfo();
      window.scrollTo(0, 0);
      this.tab = 2;
      this.getOrderConfiguration();
    }
  },
  watch: {

  }
}
</script>

<style lang="scss" scoped>
.guid-text {
  font-size: 12px;
  color: #888;
  line-height: 20px;
  i {
    margin-right: 8px;
  }
}
.activate-wrap .search-bar-container {
  height: 100%;
  padding-top: 15px;
}

.activate-wrap-inner {
  height: 710px;
  border-top: 2px solid #c99f4f;
}

.activate-wrap .contain {
  position: relative;
  height: 100%;
}

.activate-wrap .form {
  width: 660px;
  position: absolute;
  right: 0;
  top: 0;
  left: 0;
  bottom: 0;
  margin: auto;
  margin-top: 110px;

  .el-button {
    width: 262px;
    height: 50px;
    border: 0;
    margin-left: 200px;
    margin-top: 40px;
  }
}

.activate-wrap .form .hint {
  font-size: 14px;
  line-height: 24px;
  font-weight: 900;
  margin-bottom: 30px;
  i {
    color: #5dc539;
    font-size: 16px;
  }

  .phone {
    color: red;
    font-weight: 700;
  }

  span:nth-last-child(1) {
    margin-left: 22px;
    font-weight: 700;
    color: #989898;
  }
}
.order-info-title {
  margin: 40px 0 20px;
  padding: 0 10px;
  font-size: 16px;
  border-left: 3px solid #000;
  line-height: 12px;
}
.neet-upload-upfile {
  box-sizing: border-box;
  padding-left: 20px;
  display: flex;
  border-top: 1px solid transparent;

  &.disabled {
    /deep/ .center .blue {
      // background: #dddddd !important;
      // color: #a9a9a9 !important;
    }
  }

  & > li {
    width: 85%;

    &:nth-child(1) {
      .input-file-p {
        border: 1px solid #dcdfe6;
        box-sizing: border-box;
        padding: 0 12px;
        color: #606266;
        display: block;
        display: flex;
        flex-wrap: wrap;
        min-height: 40px;

        span {
          height: 38px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        & > .gray {
          color: #c0c4cc;
          font-size: 12px;
          outline: none;
          height: 38px;
        }

        .el-tag {
          margin: 4px;
          height: 30px;
        }
      }
    }

    &:nth-child(2) {
      width: 15%;
    }

    &:nth-child(3) {
      width: 33%;
    }

    .el-button--default {
      height: 40px;
      margin-left: 4px;
    }
  }

  .el-button--primary {
    width: 119px;
    margin-right: 12px;
  }

  /deep/ .upfile-container {
    .center {
      label {
        width: 120px;
        background: linear-gradient(
          120deg,
          rgba(215, 176, 100, 1) 0%,
          rgba(236, 206, 139, 1) 100%
        );
        color: #fff !important;
        text-align: center;
        height: 40px;
      }
    }
  }
}
.upload-cont {
  margin: 20px 25px 30px 215px;
}
.upload-title {
  background: #f5f5f5;
  border-bottom: 1px solid #fff;
  height: 35px;
  line-height: 35px;

  span {
    display: inline-block;
    padding-left: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  & span:nth-child(1) {
    width: 65%;
  }
  & span:nth-child(2) {
    width: 25%;
  }
}
.authorization {
  margin-bottom: 0 !important;
}
.info-panel-content {
  padding: 20px;
  padding-bottom: 0;
  padding-right: 30px;
  background: #fff;
  &.bottom {
    padding-bottom: 20px;
  }
  /deep/ .el-form-item__error {
    background: #fff;
    width: 100%;
  }
}
.form-inline-item {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;

  & > div {
    width: 40%;
    flex-shrink: 0;
  }

  &.col-3 > div {
    width: 32%;
  }
}
</style>