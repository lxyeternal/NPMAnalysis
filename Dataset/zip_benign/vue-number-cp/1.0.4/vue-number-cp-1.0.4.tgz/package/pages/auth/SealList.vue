<template>
  <div class="product">
    <!-- !this.specialRole -->
    <PanelTitle :tabs="tabs" @select="handleChangeTab" :titleButton="isHavePermission?'电子印章申请':''" @handleOpen="handleApplySeal"></PanelTitle>
    <div v-if="tab == 1">
      <div class="order-info-title" v-if="personalBadgeComputed().length">公司印章</div>
      <div class="tip" v-if="personalBadgeComputed().length">温馨提示：我们会安全妥善保管您的电子印章，也请您注意账户安全，不要将自己的账号密码或验证码信息告知他人。</div>
      <div class="preview-sign preview-seal" v-for="(item,index) in personalBadgeComputed()" :key="item.type + '' + index">
        <div class="preview-seal-content" :class="{'active':item.active}" @click="handleSelectSign(item, index)">
          <div @click.stop="" class="expire-notice" v-if="item.expireFlg == '1'">
            <el-tooltip @click.stop="" class="item" effect="dark" content="请联系管理员补交授权书, 否则授权日期到期后该印章停用" placement="top">
              <div class="">
                印章授权
                <br>
                到期提醒
                <i @click.stop="" class="el-icon-alarm-clock"></i>
              </div>
            </el-tooltip>
          </div>
          <img v-if="item.sealData" :src="item.sealData? ('data:image/jpeg;base64,'+item.sealData):''">
          <i class="el-icon-plus wait-to-add" v-if="!item.sealData"></i>
          <div class="view-history" v-if="item.sealData">
            <p>
              授权时间: {{item.effectiveStartdate || ''}} ~ {{item.effectiveEnddate || ''}}
            </p>
            <span v-if="isHavePermission" @click.stop="handleViewHistory(item)">查看授权履历</span>
          </div>
          <div v-if="item.sealStatus === 'approving' && item.expireFlg != '0'" class="view-approving">
            <span>审核中</span>
          </div>
          <div v-else-if="['0', '3'].includes(item.expireFlg)" class="view-approving unflex">
            <span>{{item.expireFlg == '0' ? '已过期' : '授权开始日期未到'}}</span>
            <div v-if="item.expireFlg == '0'">请联系管理员补交授权书</div>
          </div>
          <em v-if="!item.sealData">点击创建印章</em>
        </div>
        <label>{{item.sealName || item.label}}</label>
      </div>
      <div class="order-info-title" v-if="personalBadgeComputed(true).length">个人名章</div>
      <div class="tip" v-if="personalBadgeComputed(true).length">添加个人名章指的是创建以自己名字命名的个人名章。</div>
      <div class="preview-sign preview-seal" v-for="(item,index) in personalBadgeComputed(true)" :key="item.type + '' + index">
        <div class="preview-seal-content" :class="{'active':item.active}" @click="handleSelectSign(item, index)">
          <div @click.stop="" class="expire-notice" v-if="item.expireFlg == '1'">
            <el-tooltip @click.stop="" class="item" effect="dark" content="请联系管理员补交授权书, 否则授权日期到期后该印章停用" placement="top">
              <div class="">
                印章授权
                <br>
                到期提醒
                <i @click.stop="" class="el-icon-alarm-clock"></i>
              </div>
            </el-tooltip>
          </div>
          <img v-if="item.sealData" :src="item.sealData? ('data:image/jpeg;base64,'+item.sealData):''">
          <i class="el-icon-plus wait-to-add" v-if="!item.sealData"></i>
          <div class="view-history" v-if="item.sealData && item.type != '4'">
            <p>
              授权时间: {{item.effectiveStartdate || ''}} ~ {{item.effectiveEnddate || ''}}
            </p>
            <span v-if="!['personal'].includes(item.sealKind) && isHavePermission" @click.stop="handleViewHistory(item)">查看授权履历</span>
          </div>
          <div v-if="item.sealStatus === 'approving' && item.expireFlg != '0'" class="view-approving">
            <span>审核中</span>
          </div>
          <div v-else-if="['0', '3'].includes(item.expireFlg)" class="view-approving unflex">
            <span>{{item.expireFlg == '0' ? '已过期' : '授权开始日期未到'}}</span>
            <div v-if="item.expireFlg == '0'">请联系管理员补交授权书</div>
          </div>
          <em v-if="!item.sealData">点击创建印章</em>
        </div>
        <label>{{item.label}}</label>
      </div>
    </div>
    <ApplicationRecordList v-if="tab == 2" :propAcctId="propAcctId || $route.query.propAcctId" :propCorpId="propCorpId || $route.query.propCorpId"></ApplicationRecordList>
    <Loading :is-loading="isLoading"></Loading>

    <el-dialog class="dialog history-resume-dialog" title="历史履历" :append-to-body="true" :lock-scroll="true" :visible.sync="lookHistoryDialog" width="840px" center :close-on-click-modal="false">
      <div class="tl confirm-dialog">
        <!-- 列表 -->
        <table class="history-dialog-table">
          <thead>
            <tr class="tl">
              <td width="120">印章类型</td>
              <td>用印人员</td>
              <td width="200">授权时间</td>
              <td>创建时间</td>
              <td>状态</td>
              <td class="tr" width="100">操作</td>
            </tr>
          </thead>
          <template v-if="sealListDialog && sealListDialog.length">
            <tbody v-for="(seal,index) in sealListDialog" :key="index" class="tl tbody-row">
              <tr>
                <td>
                  {{seal.sealName || seal.sealKindName}}
                </td>
                <td>
                  {{seal.sealAcctName}}
                </td>
                <td>
                  {{seal.effectiveStartdate || ''}} ~ {{seal.effectiveEnddate || ''}}
                </td>
                <td>
                  {{seal.creTm}}
                </td>
                <td>
                  {{seal.sealStatusName}}
                </td>
                <td class="opreate" align="right">
                  <div v-if="!['rejected', 'canceled'].includes(seal.sealStatus)">
                    <span class="blue hand" @click="handleView(seal)">查看</span>
                    <span class="ml12 blue hand" @click="handleDownload(seal)">下载</span>
                  </div>
                  <div v-else>-</div>
                </td>
              </tr>
              <tr v-if="seal.sealStatus === 'rejected' && seal.approveMsg">
                <td colspan="6" class="p0">
                  <p class="reject_notice">
                    <span>申请失败原因：</span>
                    <span>{{seal.approveMsg}}</span>
                  </p>
                </td>
              </tr>
            </tbody>
          </template>
          <template v-else>
            <tr>
              <td colspan="5">
                <p class="txt-center">暂无数据</p>
              </td>
            </tr>
          </template>
        </table>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="lookHistoryDialog = false">关闭</el-button>
      </div>
    </el-dialog>

    <el-dialog class="dialog history-resume-dialog" title="提示" :append-to-body="true" :lock-scroll="true" :visible.sync="authDialog" width="440px" center :close-on-click-modal="false">
      <div class="tc confirm-dialog">
        您尚未进行实名认证，请实名认证后再创建个人印章！
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="confirmAuth">确认</el-button>
        <el-button @click="authDialog = false">关闭</el-button>
      </div>
    </el-dialog>

  </div>
</template>
<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import PanelTitle from "@/components/base/PanelTitle";
import PersonSeal from "@/components/account/PersonSeal";
import ApplicationRecordList from "@/components/electronicSeal/ApplicationRecordList";
import { viewFile } from '@/utils/orderUtil';

const sealList = [
  { label: "合同专用章", type: 1, sealData: "", sealKind: "corp" },
  { label: "项目专用章", type: 2, sealData: "", sealKind: "project" },
  { label: "法人代表章", type: 3, sealData: "", sealKind: "legal" },
  { label: "个人名章", type: 4, sealData: "", sealKind: "personal" },
  { label: "被授权的个人名章", type: 5, sealData: "", sealKind: "authorize" },
];
const changeSealParams = {
  esignId: '',
  acctType: "2",
  processFlg: '',
  sealType: '',
  mainText: '',
  hText: '',
  qText: '',
  sealData: '',
  sealParamFront: ''
};
export default {
  mixins: [accountMixin],
  name: "corporateSeal",
  components: {
    PanelTitle,
    Loading,
    PersonSeal,
    ApplicationRecordList,
  },
  props: ['propCorpId', 'propAcctId', 'mainText', 'propBreadcrumb'],
  data() {
    return {
      tabs: [
        { label: "全部印章", index: 1, active: true },
        { label: "申请履历", index: 2 },
      ],
      lookHistoryDialog: false,
      isLoading: false,
      sealList: this.$clone(sealList),
      sealListDialog: [],
      changeSealParams: Object.assign({}, changeSealParams),
      img: '',
      addCorporateDialogVisible: false,
      companySealList: [],
      tab: "1",
      hPlaceholder: "限8个字符",
      qPlaceholder: "限20个字符",
      changeSealData: '',
      signUserinfo: '',
      ruleForm: {
        mainText: { required: true, message: "请输入企业名称" }
      },
      contractSealFlag: false,
      selectChecked: false, // 是否勾选
      authenticationStatus: false, // 是否实名认证
      authDialog: false,
    }
  },
  computed: {
    /**
     * 印章 list
     * @param isPersonal: 是否为个人 默认非个人
     */
    personalBadgeComputed() {
      return isPersonal => {
        const result = isPersonal ? this.sealList.filter(f => ['personal', 'authorize'].includes(f.sealKind)) : this.sealList.filter(f => !['personal', 'authorize'].includes(f.sealKind))

        return result || []
      }
    },

    // 是否管理员 - 判断多用户
    isHavePermission() {
      return this.computedIsRoleId(['1000', '2000', '3000', '4000', '5000', '9000']) || this.isDivisionEdit
    },

    // 事业部 - 只有 2000 权限 则 哪条数据满足 对应的 corpId 才能编辑哪条
    isDivisionEdit() {
      return this.mixinsRoleIdsAdmin(this.$route.query.propCorpId || this.propCorpId || '')
    },

    // 返回当前用户 持有的 权限
    mixinsRoleIdsAdmin() {
      return (corpId, code = '2000') => {
        const ids = this.roleListFilter(corpId) || []
        // 是否为管理员2000
        return ids.some(s => s.roleId == code)
      }
    },

    // 判断 当前登录用户 是否持有 idList 权限
    computedIsRoleId() {
      return idList => {
        const roleIds = this.mixinsRoleIds || [];
        let bool = false;
        idList.forEach(id => {
          roleIds.forEach(item => {
            if (item.roleId === id) {
              bool = true;
            }
          })
        });
        return bool
      }
    },

    // 返回当前用户 持有的 权限
    mixinsRoleIds() {
      return this.roleListFilter(this.mxCorpId) || []
    },

    acctId() {
      return (
        this.$store.state.userInfo && this.$store.state.userInfo.acctId
      );
    },
    corpName() {
      return (
        this.$store.state.userInfo && this.$store.state.userInfo.corpName
      );
    },
    specialRole() {
      return this.$store.state.userInfo &&
        (this.$store.state.userInfo.contractCorpType == "construction" ||
          this.$store.state.userInfo.contractCorpType == "supervisory")
    }
  },

  methods: {
    handleChangeTab(tab) {
      this.tab = tab.index;
      if (this.tab == '1') {
        this.getSealList()
      }
    },
    handleApplySeal() {
      // 未实名认证不能添加印章
      if (this.authenticationStatus == '0') {
        this.authDialog = true
        return
      }
      const { href } = this.$router.resolve({
        path: "/applicationSeal",
        query: {
          propAcctId: this.propAcctId || this.$route.query.propAcctId || undefined,
          propCorpId: this.propCorpId || this.$route.query.propCorpId || undefined,
          mainText: this.mainText || this.$route.query.mainText || undefined,
        }
      });
      window.open(href, '_blank');
    },
    init() {
      if (this.specialRole) {
        this.sealList = [
          { label: "项目专用章", type: 2, sealData: "", sealKind: "project" },
          { label: "个人名章", type: 4, sealData: "", sealKind: "personal" },
        ];
      }
      // 判断是否需要跳转 到列表 - 来源 电子印章申请
      if (this.$getRootLocalStorage('applicationState')) {
        this.tab = this.$getRootLocalStorage('applicationState')
        this.$removeRootLocalStorage('applicationState')
        this.tabs.forEach(f => {
          f.active = false
          if (f.index === 2) {
            f.active = true
          }
        })
      }
      if (!this.isHavePermission) {
        this.tabs = [
          { label: "全部印章", index: 1, active: true },
        ]
      }
      this.getSealList();
      this.getAccountInfo();
    },
    handleSelectChecked() {
      this.contractSealFlag ? this.contractSeal('refresh') : this.projectSeal('refresh')
    },

    handleView(item) {
      if (item.attachUrl) {
        viewFile(item.attachUrl)
      }
    },

    handleDownload(item) {
      item.name = item.attachName
      item.url = item.attachUrl
      this.$download([item]).then(e => {
        this.$message.success('下载成功')
      })
    },

    searchSealApplicationList(item) {
      let params = {
        sealId: item.sealId,
        sealKind: item.sealKind,
        sealStatus: ""
      };
      try {
        params.corpId = this.$store.state.userInfo.corpId
      } catch (error) {
        console.error(error)
      }
      InterfaceService.searchSealApplicationList(params, data => {
        if (data.respCode === "0000") {
          if (data.respData.respCode == "0000") {
            this.sealListDialog = data.respData.sealApproveList || [];
            this.lookHistoryDialog = true
          } else {
            this.$message.error(data.respData.respMsg);
          }
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },

    getSealList() {
      let params = {
        sealDataType: 3, // 获取公司印章列表参数
        corpId: this.$route.query.propCorpId || undefined,
        acctId: this.$route.query.propAcctId || undefined,
      };
      InterfaceService.getSealList(params, data => {
        if (data.respCode === "0000") {
          if (data.respData && data.respData.respCode == "0000") {
            const sealDataList = data.respData.sealDataList || [];
            // 查询时 初始化 sealData
            this.sealList.forEach(f => (f.sealData = '', f.sealStatus = ''))
            this.sealList = this.$clone(sealList)
            // sealDataList.forEach(f => {
            //   // 匹配对应印章 并 赋值
            //   this.sealList.some(s => (f.sealKind === s.sealKind && Object.assign(s, f)))
            // })

            // 印章数据补全
            let list = []
            sealDataList.forEach(f => {
              this.sealList.forEach(s => {
                if (f.sealKind == s.sealKind) {
                  f.type = s.type
                  f.label = s.label

                  if (this.specialRole) {
                    if (f.sealKind == 'project' || f.sealKind == 'personal') {
                      list.push(f)
                    }
                  } else {
                    list.push(f)
                  }
                }
              })
            })
            if (!this.specialRole && list.findIndex(s => { return s.sealKind == 'corp' }) < 0) {
              list.splice(i, 0, { label: "合同专用章", type: 1, sealData: "", sealKind: "corp" })
            }
            if (!this.specialRole && list.findIndex(s => { return s.sealKind == 'legal' }) < 0) {
              list.splice(i, 0, { label: "法人代表章", type: 3, sealData: "", sealKind: "legal" })
            }
            if (list.findIndex(s => { return s.sealKind == 'personal' }) < 0) {
              list.splice(i, 0, { label: "个人名章", type: 4, sealData: "", sealKind: "personal" })
            }
            if (!this.specialRole && list.findIndex(s => { return s.sealKind == 'authorize' }) < 0) {
              list.splice(i, 0, { label: "被授权的个人名章", type: 5, sealData: "", sealKind: "authorize" })
            }
            // 印章排序
            list.sort((a, b) => {
              return a.type - b.type
            })
            let i = list.findIndex(f => { return f.sealKind == 'legal' })
            list.splice(i, 0, { label: "项目专用章", type: 2, sealData: "", sealKind: "project" })

            this.sealList = list
          } else {
            this.$message.error(data.respData.respMsg);
          }
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    handleViewHistory(item) {
      this.searchSealApplicationList(item)
    },
    handleSelectSign(item, index) {
      // 审核中 不允许查看
      if (item.sealStatus === 'approving') {
        return
      }
      // 未实名认证不能添加印章
      if (item.type == '4' && !item.sealData && this.authenticationStatus == '0') {
        this.authDialog = true
        return
      }
      // 非个人名章 且 非管理员
      if (item.type != '4' && !this.isHavePermission) {
        // 没有印章图片 才提示
        !item.sealData && this.$message.error('管理员尚未创建印章，或者您没有该印章的授权，请联系管理员！')
        return
      }
      console.log('item', item)
      this.selectChecked = false
      const { href } = this.$router.resolve({
        // applicationSeal1 添加多个项目印章时 单独处理 页面
        path: item.esignSealId && item.esignSealId != '' ? "/applicationSeal" : '/applicationSeal1',
        query: {
          sealType: item.type,
          esignSealId: item.esignSealId || '',
          sealId: item.sealId || '',
          hasSelected: "1",
          propAcctId: this.propAcctId || this.$route.query.propAcctId || undefined,
          propCorpId: this.propCorpId || this.$route.query.propCorpId || undefined,
          mainText: this.mainText || this.$route.query.mainText || undefined,
        }
      });
      window.open(href, '_blank');
    },
    handleclearText() {
      this.changeSealParams.hText = "";
      this.changeSealParams.qText = "";
    },
    contractSeal(type) {  //创建预览合同
      this.changeSealParams.esignId = this.signUserinfo.esignId;
      if (type == "refresh") {
        this.changeSealParams.processFlg = "0";
      } else if (type == "confirm") {
        this.changeSealParams.processFlg = "1";
      }
      let params = {};
      params = Object.assign(params, this.changeSealParams);
      InterfaceService.contractSeal(
        params,
        data => {
          if (data.respCode === "0000") {
            if (data.respData.respCode == "0000") {
              const result = data.respData;
              if (type == "refresh") {
                this.changeSealData = result.sealDataPreViewList[0].sealData
              }
              if (type == "confirm") {
                this.addCorporateDialogVisible = false;
                this.getSealList();
                this.$message.success("添加印章成功")
              }
            } else {
              this.$message.error(data.respData.respMsg);
            }
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    projectSeal(type) {  //创建预览合同
      this.changeSealParams.esignId = this.signUserinfo.esignId;
      if (type == "refresh") {
        this.changeSealParams.processFlg = "0";
      } else if (type == "confirm") {
        this.changeSealParams.processFlg = "1";
      }
      let params = {};
      params = Object.assign(params, this.changeSealParams);
      InterfaceService.projectSeal(
        params,
        data => {
          if (data.respCode === "0000") {
            if (data.respData.respCode == "0000") {
              const result = data.respData;
              if (type == "refresh") {
                this.changeSealData = result.sealDataPreViewList[0].sealData
              }
              if (type == "confirm") {
                this.addCorporateDialogVisible = false;
                this.getSealList();
                this.$message.success("添加印章成功")
              }
            } else {
              this.$message.error(data.respData.respMsg);
            }
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    getAccountInfo() {
      const params = {
        acctId: this.propAcctId || this.acctId
      };
      InterfaceService.accountInfo(
        params,
        data => {
          if (data.respCode === "0000") {
            const result = data.respData;
            this.signUserinfo = result;
            this.authenticationStatus = result.authenticationStatus;
            // console.log(this.signUserinfo);
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    confirmAuth() {
      this.$router.push({
        path: '/changeRealName',
        query: {
          certNo: '',
          returnPage: 'sealList'
        }
      })
    }
  },
  mounted() {
    this.init();
  }
}
</script>

<style lang="scss" scoped>
/deep/ .el-checkbox__input.is-checked + .el-checkbox__label {
  color: #444444;
}
.check-container {
  margin-bottom: 20px;
  margin-left: 200px;
  span {
    margin-left: 6px;
  }
}
.product {
  font-size: 14px;
  .tip {
    height: 20px;
    line-height: 20px;
    margin-top: 16px;
    padding-left: 40px;
    background: url("../../assets/images/icon/tip.png") no-repeat 11px center;
  }
}

.nowrap {
  white-space: nowrap;
}

.header {
  margin-bottom: 20px;
  background: #f5f5f5;
}

.header ul {
  width: 100%;
  height: 48px;
  border-bottom: 3px solid #ffd64e;
  font-weight: bold;

  .add {
    float: right;
    color: #4f525a;
    width: 130px;
    height: 26px;
    line-height: 26px;
    margin-right: 20px;
    background: #ffd64e;
    margin-top: 10px;
    font-weight: 500;
  }
  .add:hover {
    color: #000000;
    background-color: #f3c52f;
  }

  li {
    width: 110px;
    height: 48px;
    line-height: 48px;
    text-align: center;
    float: left;
    cursor: pointer;
    position: relative;

    &:after {
      display: none;
      position: absolute;
      bottom: 0px;
      left: 0;
      content: "";
      width: 110px;
      height: 3px;
      background: #4f525a;
    }

    &.active:after {
      display: block;
    }
  }
}

/deep/ .el-button {
  width: 100px;
}

p {
  margin: 10px 0;
}

.link {
  text-decoration: underline;
  cursor: pointer;
  color: #0082ff;
  &:hover {
    color: #0082ff;
  }
  &:active {
    color: #4c9cdd;
  }
}

.preview-seal {
  position: relative;
  display: inline-block;
  vertical-align: middle;
  margin: 10px;
  text-align: center;
  .wait-to-add {
    width: 60px;
    height: 60px;
    font-size: 60px;
    color: #cccccc;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 40px;
    margin: auto;
  }
  p {
    color: #ccc;
    margin-top: 0;
  }
  img {
    max-width: 218px;
    max-height: 218px;
    vertical-align: middle;
  }

  label {
    display: inline-block;
    margin: 10px 0;
    color: #888888;
  }

  i {
    font-size: 30px;
    color: #ccc;
  }

  .preview-seal-content {
    position: relative;
    width: 296px;
    height: 220px;
    line-height: 96px;
    border: 1px solid #ccc;
    cursor: pointer;
    overflow: hidden;
    em {
      color: #e7e7e7;
      position: absolute;
      left: 0;
      right: 0;
      margin: 100px auto 0;
      font-size: 18px;
    }
    .seal-change {
      position: absolute;
      left: 5px;
      bottom: -35px;
    }

    .preview-seal-text {
      position: absolute;
      top: 3px;
      left: -40px;
      display: block;
      width: 100px;
      line-height: 20px;
      font-size: 12px;
      background: #eee;
      transform: rotatez(-45deg);
    }

    &.active .preview-seal-text {
      background: #ffd64e;
    }
  }
}

.preview-company {
  margin: 0 10px;
  .preview-seal-content {
    width: 210px;
    height: 210px;
    line-height: 146px;
  }
}

.pic-code {
  width: 400px;
  margin: auto;
  margin-bottom: 20px;
}

.sms-btn {
  width: 150px;
}

.float-tip {
  position: absolute;
  top: -18px;
  z-index: 1;
  display: inline-block;
  left: -8px;
  padding: 5px 10px;
  border-radius: 5px;
  white-space: nowrap;
  color: #ffffff;
  background: #ff5917;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.3);
  animation: float-tip-animate ease 1s 0s infinite alternate;
  &:before {
    position: absolute;
    bottom: -5px;
    left: 50%;
    transform: translate(-50%);
    content: "";
    border-top: 10px solid #ff5917;
    border-left: 8px solid transparent;
    border-right: 8px solid transparent;
  }
}

@keyframes float-tip-animate {
  from {
    transform: translateY(-2px);
  }
  to {
    transform: translateY(2px);
  }
}
.dialog {
  line-height: 25px;

  // /deep/ .el-dialog__header {
  //   padding: 0;

  //   &:before {
  //     display: none;
  //   }
  // }
}
.history-resume-dialog {
  /deep/ .el-dialog__body {
    max-height: 400px;
    overflow: auto;
  }
}
.company-dialogs-tip {
  text-align: center;
}
.company-seal-content {
  width: 100%;
  padding: 20px 70px 50px 60px;
  img {
    width: 100%;
    height: 100%;
  }
}
.preview-sign {
  .preview-seal-content {
    border: 1px dashed #eee;
    background: #f8f8f8;
    &.active {
      border-style: solid;
      background: #fff;
      cursor: auto;
    }
  }
}
// /deep/ .dialog-footer {
//   position: absolute;
//   left: 150px;
//   margin-top: -106px;
// }
/deep/ .order-info-title {
  margin: 5px 0;
  margin-bottom: 20px;
  padding: 0 10px;
  font-size: 14px;
  border-left: 3px solid #000;
  line-height: 12px;
}
.view-history {
  width: 100%;
  position: absolute;
  bottom: 0;
  background: rgba(255, 255, 255, 0.5);
  color: #01b9f1;
  font-weight: bold;
  height: 50px;
  line-height: 12px;
  p {
    color: #333;
    font-size: 12px;
  }
  i {
    font-size: 16px;
    color: #f00;
  }
}

.history-dialog-table {
  width: 100%;
  thead {
    font-size: 14px;
    text-align: center;
    white-space: nowrap;
    color: #909399;
    background: #f5f5f5;
  }
  td {
    padding: 10px 10px;
    vertical-align: middle;
    word-break: break-all;
    border-bottom: 1px solid #eaeaea;
  }
}

.p0 {
  padding: 0 !important;
}
.reject_notice {
  text-align: left;
  background: #ffe9eb;
  padding: 4px 12px;
  margin: 0;
}
.ml12 {
  margin-left: 12px;
}
.txt-center {
  text-align: center;
  font-size: 14px;
}
.view-approving {
  width: 100%;
  position: absolute;
  bottom: 0;
  background: rgba(255, 255, 255, 0.8);
  height: 100%;
  line-height: 30px;
  color: #444;
  font-weight: bold;
  z-index: 1;
  display: flex;
  justify-content: center;
  align-items: center;
  &.unflex {
    flex-direction: column;
    color: #333;
  }
}
.expire-notice {
  line-height: 10px;
  position: absolute;
  font-size: 12px;
  right: 0;
  top: 0;
  line-height: 14px;
  color: #f00;
  i {
    position: absolute;
    right: 52px;
    top: 0;
    font-size: 16px;
    color: #f00;
  }
}
</style>