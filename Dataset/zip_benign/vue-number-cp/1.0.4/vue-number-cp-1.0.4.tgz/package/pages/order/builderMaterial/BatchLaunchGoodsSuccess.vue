<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <div class="app-search-bar isWhiteBg border-bottom">
            <div class="search-bar-container inner-container" style="position: relative;">
                <div class="index-logo">
                    <div class="logo">
                        <h1>
                            <a @click="go('/home')" class="logo-bd"></a>
                        </h1>
                    </div>
                </div>
                <ViceHeader :title="title" :flow="flow"></ViceHeader>
            </div>
        </div>
        <div class="inner-container" :style="{height:height,minHeight: '350px'}">
            <div class="content">
                <div class="icon-success"></div>
                <h3>批量要货创建成功！</h3>
                <div>
                    <p>您可以点击【查看要货详情】查看对应要货单!</p>
                </div>
                <div v-if="list&&list.length" class="sign-content">
                    <div class="table">
                        <table>
                            <thead>
                                <tr>
                                    <td>合同名称</td>
                                    <td>批次</td>
                                    <td>供应商</td>
                                    <td width="120">操作</td>
                                </tr>
                            </thead>
                            <tr v-for="(row,index) in list" :key="index">
                                <td>《{{row.contractName}}》</td>
                                <td>第{{row.requireBatchNo}}批次</td>
                                <td>{{row.supplierName}}</td>
                                <td>
                                    <el-button type="primary" size="small" @click="handleView(row)">查看要货详情</el-button>
                                </td>
                            </tr>
                        </table>

                    </div>
                </div>
                <p class="tr back">
                    <a @click="handleBack">
                        <i class="icon-return"></i> 返回施工要料计划列表</a>
                </p>
            </div>

        </div>

        <Footer></Footer>
    </div>
</template>
<script>
import Header from "@/components/base/Header";
import ViceHeader from "@/components/base/ViceHeader";
import Footer from "@/components/base/Footer";

export default {
    components: {
        Header,
        ViceHeader,
        Footer
    },
    data() {
        return {
            flow: [
                {
                    name: "批量创建要货单",
                    active: true,
                    next: true
                },
                {
                    name: "确认并签署要货单",
                    active: false,
                    next: true
                },
                {
                    name: "提交要货单",
                    active: false,
                    next: false
                }
            ],
            list: []
        };
    },
    computed: {
        title() {
            let str = `批量要货 - 创建成功`;
            return str;
        },
        height() {
            let h =
                window.innerHeight ||
                document.documentElement.clientHeight ||
                document.body.clientHeight;
            return h - 200 - 55 - 34 - 160 + "px";
        },
        role() {
            return this.$store.state.userInfo
                ? this.$store.state.userInfo.bs
                : 0;
        }
    },
    methods: {
        handleView(row) {
            this.$router.push({
                path: "/requireOrderDetail",
                query: {
                    requireNo: row.requireNo
                }
            });
        },
        handleBack() {
            let path = "";
            if (this.role == "S") {
                path = "/vendorCenter/builderMaterialList";
            } else if (this.role == "B") {
                path = "/purchaserCenter/builderMaterialList";
            }
            this.$router.push({
                path: path
            });
        },
        go(path) {
            this.$router.push({
                path: path
            });
        }
    },
    mounted() {
        this.list = this.$route.query.list? JSON.parse(this.$route.query.list): [];
    }
};
</script>
<style lang="scss" scoped>
h3 {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 10px;
}
.content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;

    p {
        margin-bottom: 20px;
    }
}

.icon-success {
    width: 80px;
    height: 80px;
    margin: auto;
    background: url(../../../assets/images/green_yes.png) no-repeat;
}

.sign-content {
    width: 1000px;
    margin-top: 50px;
    text-align: left;

    /deep/ .el-button {
        width: 110px;
    }

    .table {
        max-height: 150px;
        overflow: auto;
        width: 100%;
        line-height: 23px;
        font-size: 12px;
        text-align: center;

        table {
            width: 100%;
        }

        td {
            padding: 10px 10px;
            vertical-align: middle;
            word-break: break-word;
        }

        thead {
            white-space: nowrap;
            font-size: 14px;
            color: #909399;

            td {
                background: #f5f5f5;
            }
        }
    }
}

.back {
    margin: 20px 0;
    font-size: 14px;
    color: #0082ff;
}
</style>

