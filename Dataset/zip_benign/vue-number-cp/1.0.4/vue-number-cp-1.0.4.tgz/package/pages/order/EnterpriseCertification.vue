<template>
  <div class="enterpriseCertification">
    <PanelTitle :title="page===0 ? '企业实名认证' : page===1 ? '企业银行卡信息认证' : '企业法人手机号验证'"></PanelTitle>
    <div class="list-home">
      <div class="list-content" v-if="page === 0">
        <!-- 基本户银行账户认证 -->
        <div class="company-box">
          <div class="step-box">
            <div class="order-info-title">基本户银行账户认证</div>
            <div class="step-info f12" v-if="bankInfoBasic.checkStatus !== 'CERTIFIED'">
              ① 确认企业基础信息 >> ② 填写企业对公账号资料 >> ③ e签宝向对公账号打款 >> ④ 收到打款后，登录平台，输入打款金额 >> ⑤ 金额正确，认证完成
            </div>
            <ul class="company" v-else>
              <li>
                <span>户&nbsp;&nbsp;&nbsp;&nbsp;名：</span>
                <div class="company-showtext">{{info.corpName}}</div>
              </li>
              <li>
                <span>银行账号：</span>
                <div class="company-showtext">{{bankInfoBasic.bankAcctNo}}</div>
              </li>
              <li>
                <span>银行名称：</span>
                <div class="company-showtext">{{bankInfoBasic.bankName}}</div>
              </li>
              <li>
                <span>支行名称：</span>
                <div class="company-showtext">{{bankInfoBasic.subBranch}}</div>
              </li>
            </ul>
          </div>
          <el-button v-if="bankInfoBasic.checkStatus === 'UNCERTIFIED' || bankInfoBasic.checkStatus === 'CREATED' || !bankInfoBasic.checkStatus" class="normal-btn" type="primary" @click="handleCertification(bankInfoBasic)">去认证</el-button>
          <el-button v-if="bankInfoBasic.checkStatus === 'INITIATED'" class="normal-btn" type="primary" @click="handleCheckMoney(bankInfoBasic)">去验证金额</el-button>
          <div v-if="bankInfoBasic.checkStatus === 'CERTIFIED'" class="verified">√ 已认证</div>
        </div>
        <!-- 承兑汇票银行账户认证 -->
        <div class="company-box" v-if="role === 'S'">
          <div class="step-box">
            <div class="order-info-title">承兑汇票银行账户认证</div>
            <ul class="company" v-if="(bankInfoAcceptance.checkStatus && bankInfoAcceptance.checkStatus === 'CERTIFIED') || bankCacheInfoAcceptance.bankAcctNo">
              <!-- <ul class="company"> -->
              <li>
                <span>户&nbsp;&nbsp;&nbsp;&nbsp;名：</span>
                <div class="company-showtext">{{info.corpName}}</div>
              </li>
              <li>
                <span>银行账号：</span>
                <div class="company-showtext">{{bankCacheInfoAcceptance.bankAcctNo ? bankCacheInfoAcceptance.bankAcctNo : bankInfoAcceptance.bankAcctNo}}</div>
              </li>
              <li>
                <span>银行名称：</span>
                <div class="company-showtext">{{bankCacheInfoAcceptance.bankAcctNo ? bankCacheInfoAcceptance.bankName : bankInfoAcceptance.bankName}}</div>
              </li>
              <li>
                <span>支行名称：</span>
                <div class="company-showtext">{{bankCacheInfoAcceptance.bankAcctNo ? bankCacheInfoAcceptance.subBranch : bankInfoAcceptance.subBranch}}</div>
              </li>
              <li v-if="bankInfoAcceptance.checkStatus === 'CERTIFIED'" class="f12 blue hand" style="text-decoration: underline;" @click="bankAcctType='1';initiateCorporateCer('1')">更换银行卡</li>
            </ul>
            <div class="step-info f12" v-else>
              ① 完成基本户银行账户认证 >> ② 填写企业对公账号资料 >> ③ e签宝向对公账号打款 >> ④ 收到打款后，登录平台，输入打款金额 >> ⑤ 金额正确，认证完成<br>
              <p class="f12 blue hand" v-if="bankInfoBasic.checkStatus === 'CERTIFIED' && (!bankInfoAcceptance.checkStatus || bankInfoAcceptance.checkStatus ==='UNCERTIFIED')" style="text-decoration: underline; margin-top: 6px;display: inline-block;" @click="bankSetAcceptance">使用已认证的基本户作为承兑汇票银行账户</p>
            </div>
          </div>
          <el-button v-if="bankInfoAcceptance.checkStatus === 'UNCERTIFIED' || bankInfoAcceptance.checkStatus === 'CREATED' || !bankInfoAcceptance.checkStatus" class="normal-btn" type="primary" @click="handleCertification(bankInfoAcceptance)">去认证</el-button>
          <el-button v-if="bankInfoAcceptance.checkStatus === 'INITIATED'" class="normal-btn" type="primary" @click="handleCheckMoney(bankInfoAcceptance)">去验证金额</el-button>
          <div v-if="bankInfoAcceptance.checkStatus === 'CERTIFIED'" class="verified">√ 已认证</div>
        </div>
        <div class="company-box">
          <div class="step-box">
            <div class="order-info-title">企业法人手机号验证</div>
            <div class="step-info f12">
              ① 填写法人手机号 >> ② 获取e签宝发出的短信验证码 >> ③ 填写短信验证码 >>④ 验证正确，认证完成
            </div>
          </div>
          <el-button v-if="info.legalIsCertified !== '1'" class="normal-btn" type="primary" @click="goLegalPerson">去认证</el-button>
          <div v-else class="verified">√ 已认证</div>
        </div>
        <div class="order-info-title" style="margin-top: 50px !important;">相关帮助</div>
        <p class="f12 blue hand" style="margin-bottom: 10px" @click="handleViewFile('/djc/statics/operationManual/00_realNameCertification/bankCardCertification.pdf')">1.如何完成企业银行卡信息认证？</p>
        <p class="f12 blue hand" @click="handleViewFile('/djc/statics/operationManual/00_realNameCertification/mobileCertification.pdf')">2.如何完成企业法人手机号验证？</p>
      </div>
      <CompanyBank v-if="page === 1" ref="companyBank" :info="info" :bankInfo="bankInfo" @upDate="upDate"></CompanyBank>
      <LegalPerson v-if="page === 2" ref="legalPerson" :info="info" @upDate="upDate"></LegalPerson>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import CompanyBank from "@/components/order/enterpriseCertification/CompanyBank";
import LegalPerson from "@/components/order/enterpriseCertification/LegalPerson";
import { viewFile } from '@/utils/orderUtil';
import {
  BASE_CONFIG
} from '@/config/config'
export default {
  components: {
    Loading, PanelTitle, viewFile, CompanyBank, LegalPerson
  },
  data() {
    return {
      isLoading: false,
      page: 0,//1:企业银行卡信息认证 2:企业法人手机号验证
      bankAcctType: '',
      info: {},
      bankInfo: {},
      bankInfoBasic: {},//基本户银行账户
      bankInfoAcceptance: {},//承兑汇票银行账户
      bankCacheInfoAcceptance: {},//承兑汇票银行账户缓存
      role: '',
    };
  },
  methods: {
    handleViewFile(url) {
      // console.log(url)
      if (url) {
        viewFile(BASE_CONFIG.OSS_SERVICE_ADDRESS + url)
      } else {
        this.$message('暂无预览地址')
      }
    },
    upDate(type) {
      if (type) this.page = 0
      this.enterpriseCer()
    },
    // 将银行基本户设置成承兑汇票银行
    bankSetAcceptance() {
      this.$confirm(
        '是否使用已认证的基本户作为承兑汇票银行账户？',
        '',
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          // type: 'warning',
          confirmButtonText: "确定",
          cancelButtonText: '取消',
        }).then(() => {
          const param = {
            corpId: this.info.corpId,
          };
          InterfaceService.bankSetAcceptance(param, data => {
            if (data && data.respData && data.respData.respCode === "0000") {
              this.$message.success('操作成功')
              this.enterpriseCer()
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        }).catch(() => {
        });
    },
    // 去认证
    handleCertification(item) {
      this.bankAcctType = item.bankAcctType
      this.bankInfo = item
      if (item.bankAcctType === '0') {
        this.page = 1
        this.$nextTick(() => {
          if (item.checkStatus === 'UNCERTIFIED') {
            this.$refs.companyBank.doGetProviderRiskDetail()
          }
          if (item.checkStatus === 'CREATED') { //已发起
            this.$refs.companyBank.updateStep(1)
          }
        })
      } else {
        if (this.bankInfoBasic.checkStatus != 'CERTIFIED') {
          this.$message.error('请先完成基本户银行账户认证')
        } else {
          // 承兑汇票银行账户认证
          if (item.checkStatus === 'UNCERTIFIED' || !item.checkStatus) {
            this.initiateCorporateCer()
          } else if (item.checkStatus === 'CREATED') {
            this.page = 1
            this.$nextTick(() => {
              this.$refs.companyBank.updateStep(1)
            })
          }
        }
      }
    },
    goLegalPerson() {
      this.page = 2
      this.$nextTick(() => {
        this.$refs.legalPerson.doGetProviderRiskDetail()
      })
    },
    // 发起企业核身认证
    initiateCorporateCer(bankAcctType = '') {
      const param = {
        corpId: this.$store.state.userInfo.corpId,
        corpName: this.info.corpName,
        busiLicense: this.info.busiLicense,
        legalRepresent: this.info.legalRepresent,
        legalCertNo: this.info.legalCertNo,
        bankAcctType: bankAcctType ? bankAcctType : this.bankInfo.bankAcctType,
      };
      InterfaceService.initiateCorporateCer(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          const result = data.respData;
          if (result.status === '1') {
            this.enterpriseCer('initiateCorporateCer')
          } else {
            this.$message.error(result.message)
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 去验证金额
    handleCheckMoney(item) {
      this.bankAcctType = item.bankAcctType
      this.bankInfo = item
      // console.log(this.bankInfo)
      this.page = 1
      this.$nextTick(() => {
        this.$refs.companyBank.updateStep(2)
      })
    },
    // 查询企业及认证情况
    enterpriseCer(come) {
      const param = {
        corpId: this.$route.query.corpId || this.$store.state.userInfo.corpId
      };
      InterfaceService.enterpriseCer(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.info = data.respData || {}
          const obj1 = {
            checkStatus: 'UNCERTIFIED',
            bankAcctType: '0',
          }
          const obj2 = {
            checkStatus: 'UNCERTIFIED',
            bankAcctType: '1',
          }
          const bankInfoList = this.info.bankInfoList // 已认证
          const bankCacheInfoList = this.info.bankCacheInfoList //缓存
          this.bankCacheInfoAcceptance = {}
          if (bankCacheInfoList.length) {
            if (bankCacheInfoList[0].bankAcctType === '0') {
              this.bankInfoBasic = bankCacheInfoList[0]//基本户
            } else {
              this.bankInfoBasic = bankInfoList.filter(i => i.bankAcctType === '0')[0]//基本户
              this.bankInfoAcceptance = bankCacheInfoList[0]//承兑汇票
              if (bankInfoList.filter(i => i.bankAcctType === '1' && i.checkStatus === 'CERTIFIED').length) {
                this.bankCacheInfoAcceptance = bankInfoList.filter(i => i.bankAcctType === '1')[0] //承兑汇票缓存
                // console.log('承兑汇票缓存')
                // console.log(this.bankCacheInfoAcceptance)
              }
            }
          } else {
            if (bankInfoList.length) {
              if (bankInfoList.filter(i => i.bankAcctType === '0').length) { //基本户
                this.bankInfoBasic = bankInfoList.filter(i => i.bankAcctType === '0')[0]
              } else {
                this.bankInfoBasic = obj1
              }
              if (bankInfoList.filter(i => i.bankAcctType === '1').length) { //'承兑汇票
                this.bankInfoAcceptance = bankInfoList.filter(i => i.bankAcctType === '1')[0]
              } else {
                this.bankInfoAcceptance = obj2
              }
            } else {
              this.bankInfoBasic = obj1
              this.bankInfoAcceptance = obj2
            }
          }
          // 更新
          if (this.bankAcctType === '0') {
            this.bankInfo = this.bankInfoBasic
          } else {
            this.bankInfo = this.bankInfoAcceptance
          }

          if (come === 'initiateCorporateCer') {
            console.log(this.bankInfo)
            this.page = 1
            this.$nextTick(() => {
              this.$refs.companyBank.updateStep(1)
            })
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    init() {
      this.enterpriseCer()
    },
  },
  mounted() {
    this.init()
    this.role = this.$store.state.userInfo.bs || ''
  },
};
</script>

<style lang="scss" scoped>
.order-info-title {
  margin-top: 0px !important;
}
.enterpriseCertification {
  margin: 0 auto;
  padding-bottom: 60px;
  .list-content {
    .company-box {
      width: 100%;
      padding: 20px;
      box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
      display: flex;
      align-items: center;
      justify-content: space-between;
      .step-box {
        max-width: 700px;
        .step-info {
          margin-bottom: 10px;
        }
        .company {
          width: 100%;
          > li {
            width: 100%;
            display: flex;
            margin-bottom: 6px;
            line-height: 17px;
            font-size: 12px;
            color: #444444;
            &:last-child {
              margin-bottom: 0px;
            }
            > span {
              color: #888888;
              display: inline-block;
              vertical-align: top;
              white-space: nowrap;
            }
            > div {
              display: inline-block;
            }
          }
        }
      }
      & + .company-box {
        margin-top: 20px;
      }
      .verified {
        font-size: 14px;
        line-height: 20px;
        color: #00b050;
      }
    }
  }
}
</style>
