<template>
  <div class="index-porduct">
    <Header :is-white-bg="true"></Header>
    <SearchBar :is-red-bg="true" :search-type="1" :scrollShowFixed="true" @listenIsShowFooter="listenIsShowFooter()"></SearchBar>
    <LightColorMenuBar :current-router="currentRouter"></LightColorMenuBar>
    <div class="bg-content">
      <div class="search">
        <el-input placeholder="请输入关键词搜索招标公告或招标品类" v-model="keyword"></el-input>
        <el-button type="primary" class="normal-btn" @click="handleSearch">搜索</el-button>
      </div>
    </div>
    <div class="list-home">

      <div class="list-content">
        <table>
          <thead>
          <tr>
            <td width="190px">招标品类</td>
            <td width="160px">发布方</td>
            <td width="40px"></td>
            <td width="446px">招标公告名称</td>
            <td width="70px"></td>
            <td width="176px">报名截止日期</td>
            <td width="108px" class="tr">操作</td>
          </tr>
          </thead>
          <tbody v-for="(item,ind) in biddingList" :key="ind" class="tbody-row">
          <tr>
            <td class="ellipsisOne" :title="item.categoryName">
              {{item.categoryName}}
            </td>
            <td>{{item.shortCorpName || item.publisherName}}</td>
            <td></td>
            <td>
              <span class="hand blue" @click="handleOpen(item)">{{item.bidName &&item.bidName.split("】")[1]}}</span>
            </td>
            <td></td>
            <td v-html="endTime(item)">
            </td>
            <td class="tr">
              <!-- <span v-if="endTime(item) !== '已结束' && (!userinfo || !Object.keys(userinfo).length  || (userinfo.bs  && userinfo.bs !== 'B'))" class="hand blue" @click="handleOpen(item)">报名</span> -->
              <span v-if="endTime(item) !== '已结束' && item.corpId != userinfo.corpId" class="hand blue" @click="handleOpen(item)">报名</span>
              <span v-if="item.publishStatus == 'PUBLISH'" class="hand blue" @click="handleOpenWinnerDetail(item)">查看中标公示</span>
            </td>
          </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="table-pagination" v-if="biddingList.length">
      <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="totoalCount" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
      </el-pagination>
    </div>
    <Footer></Footer>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import Footer from "@/components/base/Footer";
import Header from "@/components/base/Header";
import LightColorMenuBar from "@/components/LightColorMenuBar";
import { DateUtil } from '@/utils/dateUtil';
// import FixedTool from '@/components/FixedTool'
export default {
  components: {
    SearchBar,
    Loading,
    Footer,
    Header,
    LightColorMenuBar,
    // FixedTool,
  },
  watch:{
  },
  computed:{
    isLogin (){
      return this.$store.state.isLogin
    },
    userinfo() {
      return this.$store.state.userInfo;
    },
    endTime(){
      return function (item) {
        if (item.planEndTime) {
          let date = DateUtil.getTimesStr();
          let compuTime =  this.dateDiff(date,item.planEndTime.substring(0,10));
          if (item.bidPhase !== "SUPPLIER_RECRUIT") {
            return "已结束"
          }else{
            if (compuTime < 0 ) {
              return "已结束"
            } else if (compuTime > 0 && compuTime <= 10) {
              return `${item.planEndTime.substring(0,10)}<br>${compuTime}天后截止`
            }else if (compuTime == 0) {
              return `${item.planEndTime.substring(0,10)}<br>今天截止`
            }else {
              return item.planEndTime.substring(0,10)
            }
          }
        }
      }
    },
    dateDiff () {
      return function(date,time) {
        let aDate, oDate1, oDate2, iDays
        aDate = time.split("-")
        oDate1 = new Date(aDate[1] + '-' + aDate[2] + '-' + aDate[0])
        aDate = date.split("-")
        oDate2 = new Date(aDate[1] + '-' + aDate[2] + '-' + aDate[0])
        iDays = parseInt((oDate1 - oDate2) / 1000 / 60 / 60 / 24)
        return iDays
      }

    }
  },
  data() {
    return {
      isLoading:false,
      showDraftBoxList:false,
      currentRouter: "biddingAnnouncement",
      totoalCount: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //分页 每页的长度
      biddingList: [],
      currentList: [],
      keyword: "",
    };
  },
  methods: {
    handleSignUp (bidNo) {
      if (this.isLogin != "1") {
        this.$confirm(
          "<p class='tl'>若要参与该公告的招标，请先注册加入本平台才能报名参与招标。大家采平台为您提供更专业、更丰富的资源。若有疑问请联系平台客服电话：400-0609-008（工作日上午8:30-11:30，下午13:00-17:30）。</p>",
          "温馨提示",
          {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            confirmButtonText: "去注册/登录",
            dangerouslyUseHTMLString: true,
            center:true,
            cancelButtonText: '取消',
          }).then(() => {
          this.$router.push('/login');
          sessionStorage.setItem('toFullPath', "biddingSignUpInfo?bidNo=" + bidNo + "&type=submit"); //\
        }).catch(() => {
        });
      }else {
        this.$router.push({
          path:"/biddingSignUpInfo",
          query:{
            bidNo:bidNo,
            type:"submit",
          },
        })
      }
    },
    listenIsShowFooter() {
      this.showDraftBoxList = true
    },
    handleOpenWinnerDetail(item) {
      window.open(this.$router.resolve({
        path: "/bidBulletinDetail",
        query: {
          bidNo : item.bidNo,
          enterBidNo: item.enterBidNo,
          type: '1',
        },
      }).href, '_blank')
    },
    handleOpen(item) {
      // this.$setRootScope('biddingInfo',JSON.stringify(item));
      const { href } = this.$router.resolve({
        path: "/biddingAnnDetail",
        query: {
          bidNo:item.bidNo,
          // operationType: this.endTime(item) !== '已结束' && (!this.userinfo || !Object.keys(this.userinfo).length  || (this.userinfo.bs  && this.userinfo.bs !== 'B'))
          operationType: this.endTime(item) !== '已结束' && item.corpId != this.userinfo.corpId
        },
      });
      window.open(href, '_blank');
      // window.open(this.$router.resolve({
      //   path: "/biddingAnnDetail",
      // }).href, '_blank')
    },
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.getBiddingList();
      window.scrollTo(0, 0)
    },
    handleSearch() {
      this.pageIndex = 1;
      this.getBiddingList()
    },
    getBiddingList() {
      let params = {
        pageIndex :  this.pageIndex,
        categoryName : "",
        keyword : this.keyword,
        corpIdList: this.userinfo.corpIdList || [this.userinfo.corpId]
      };
      // this.biddingList = [{
      //   categoryName:"三级品类",
      //   publisherName:"绿地建材集团",
      //   bidName:"招标名称一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十",
      //   planEndTime:"2020-06-01",
      // }]
      InterfaceService.biddingAnnList(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            this.isLoading = false;
            this.biddingList = data.respData.supplierBidInfoList || [];
            this.biddingList.forEach(item=>{
              item.categoryName = "";
              if (item.ibBidCategoryInfos) {
                if (item.ibBidCategoryInfos.length === 1) {
                  item.categoryName = item.ibBidCategoryInfos[0].categoryLevelThreeName;
                }else {
                  let list = []
                  item.ibBidCategoryInfos.forEach(_item => {
                    list.push(_item.categoryLevelTwoName)
                  });
                  list = [...new Set(list)]
                  item.categoryName = list.join('、')
                }

              }
            });
            this.pageSize = data.respData.pageSize || 0;
            this.totoalCount = data.respData.totoalCount || 0;
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    init() {
      this.getBiddingList()
    },
  },
  mounted() {
    this.init()
  },
  destroyed() {
  }
};
</script>

<style lang="scss" scoped>
.list-home {
  .list-content {
    width: 1190px;
    margin: 0 auto;
    table {
      table-layout: fixed;
      width: 100%;
      line-height: 17px;
      font-size: 12px;
      td {
        padding: 20px 10px;
        vertical-align: middle;
        word-break: break-all;
      }

      thead {
        font-size: 14px;
        text-align: left;
        white-space: nowrap;
        border-bottom: 1px solid #eee;
        font-weight: bold;
      }
      .tbody-row {
        &:hover {
          background: #f0f8ff;
        }
      }
      tbody {
        text-align: left;
        tr {
          border-bottom: 1px solid #eee;
        }
        .border-none{
          border-bottom:none;
        }
      }
    }

  }
}
.bg-content{
  width: 100%;
  height: 150px;
  margin: 0 auto;
  background: url("../../../assets/images/bidding_bg.png") no-repeat center;
  .search{
    width: 1190px;
    margin: 0 auto;
    text-align: center;
    padding-top: 58px;
    /deep/ .el-input{
      width: 674px;
      height: 34px;
      input{
        height: 34px;
      }
    }
    /deep/ .el-button{
      margin-left: -4px;
    }
  }
}

</style>
