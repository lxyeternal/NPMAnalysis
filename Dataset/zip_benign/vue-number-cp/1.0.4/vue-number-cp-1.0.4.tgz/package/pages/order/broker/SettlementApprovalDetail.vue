<template>
    <div>
        <div class="unShowPrint">
        <Header :is-white-bg="false"></Header>
        <SearchBar :search-type="5" :progress="'详情页'" :is-border-bottom="true" :product-create-process="2"></SearchBar>
        <div class="inner-container">
            <!-- 合同流程 -->
            <OrderProcess v-if="settleInfo.approveFlowList" :isApproval="true" :orderStatus="settleInfo.orderStatus" :processList="settleInfo.approveFlowList"></OrderProcess>
             <!--合同状态 -->
            <SettlementDetailOperate :errorRules="errorRules" :topApproval = "true" :executionId="executionId" :settleInfo="settleInfo" @refresh="refreshDetail" @handleClickPrint="handleClickPrint" @close="closeWindow"></SettlementDetailOperate>
            <PanelTitle :tabs="tabs" @select="handleSelectTab" class="panel-title"></PanelTitle>
            <div class="order-info" v-if="tab == '1'">
                <div class="order-info-title">合同基本信息 </div>
                <!--<span v-if="executionId" class="blue pointer download"  @click="handleBatchDownload()">审批资料查看及下载</span>-->
                <el-row>
                    <el-col :span="24">
                        <p>
                            <label>结算主题：</label>{{settleInfo.settleName}}
                        </p>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <p>
                            <label>合同编号：</label>{{settleInfo.orderNo}}
                        </p>
                    </el-col>
                    <el-col :span="12">
                        <p>
                            <label>合同名称：</label>
                            <span>
                                <span :class="{'blue':hasOrderNo,'hand':hasOrderNo}" @click="handleContractDetail()">《{{settleInfo.contractName}}》</span>
                                <!--<span v-if="executionId" class="blue pointer"  @click="handleBatchDownload()">审批资料下载</span>-->
                             </span>
                        </p>
                    </el-col>
                </el-row>
                <!--<el-row v-if="role==='B'" v-for="(item,index) in filterERP(settleInfo.externalSysList)" :key="index">-->
                <el-row>
                    <el-col :span="12">
                        <label>城市公司：</label>{{settleInfo.cityCompany}}
                    </el-col>
                    <el-col :span="12">
                        <label>项目名称：</label>{{settleInfo.projectName}}
                    </el-col>
                    <!--<el-col :span="8">-->
                        <!--<label>请款次数：</label>{{settleInfo.orderTaxRateRange}}-->
                    <!--</el-col>-->
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <label>甲方：</label>{{settleInfo.brokerName}}
                    </el-col>
                    <el-col :span="12">
                        <label>乙方：</label>{{settleInfo.supplierName}}
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12" v-if="startFlag" class="change-amount">
                        <template v-if="settleInfo.outSettleInfoStatus === 'init'">
                            <label>合同金额（含税）：</label><el-input type="text" v-model="settleInfo.erpContractAmount" @input="change($event)" @blur="handleCheck($event,'erpContractAmount')" maxlength="25"></el-input>元
                            <p class="mb10 red f12" v-if="errorRules['erpContractAmount']">金额填写有误</p>
                            <p class="red">*明源ERP内部含税合同金额</p>
                        </template>
                        <template v-else>
                            <label>合同金额（含税）：</label><el-input type="text" v-model="settleInfo.outContractAmount" @input="change($event)" @blur="handleCheck($event,'outContractAmount')" maxlength="25"></el-input>元
                            <p class="mb10 red f12" v-if="errorRules['outContractAmount']">金额填写有误</p>
                        </template>
                    </el-col>
                    <el-col :span="12" v-else>
                        <label>合同金额（含税）：</label>{{settleInfo.outContractAmount | formatMoney}}元
                    </el-col>
                </el-row>
                <div class="line"></div>
                <div class="order-info-title">合同结算信息 </div>
                <el-row>
                    <el-col :span="12" v-if="startFlag" class="change-amount">
                        <template v-if="settleInfo.outSettleInfoStatus === 'init'">
                            <label>最终结算金额：</label><el-input type="text" v-model.trim="settleInfo.erpSettleAmount" @input="change($event)" @blur="handleCheck($event,'erpSettleAmount')" maxlength="25"></el-input>元
                            <p class="mb10 red f12" v-if="errorRules['erpSettleAmount']">金额填写有误</p>
                            <p class="red" >*明源ERP内部结算造价</p>
                        </template>
                        <template v-else>
                            <label>最终结算金额：</label><el-input type="text" v-model.trim="settleInfo.outSettleAmount" @input="change($event)" @blur="handleCheck($event,'outSettleAmount')" maxlength="25"></el-input>元
                            <p class="mb10 red f12" v-if="errorRules['outSettleAmount']">金额填写有误</p>
                        </template>
                    </el-col>
                    <el-col :span="12" v-else>
                        <label>最终结算金额：</label>{{settleInfo.outSettleAmount | formatMoney}}元
                    </el-col>
                    <el-col :span="12">
                        <el-tooltip effect="dark" placement="top">
                            <div slot="content">
                                <p>结算变动率：（最终结算金额-合同金额）/ 合同金额</p>
                            </div>
                            <i class="el-icon-question tooltip-name"></i>
                        </el-tooltip>
                        <label>结算变动率：</label>
                        <template v-if="startFlag">
                            {{compRateOfChange()}}
                        </template>
                        <template v-else>
                            {{Number(settleInfo.outSettleChgRate).toFixed(2) * 100 + '%' }}
                        </template>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <label>竣工日期：</label>{{settleInfo.completionDt}}
                    </el-col>
                    <el-col :span="12">
                        <label>保修到期日期：</label>{{settleInfo.guaranteeDt}}
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <label>结算提报日期：</label>{{settleInfo.outSettleDt}}
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24" v-if="startFlag">
                        <label class="fl">结算说明：</label>
                        <el-input v-if="settleInfo.outSettleInfoStatus === 'init'" style="width: 94%;" type="textarea" v-model="settleInfo.erpSettleRemark" @input="change($event)"></el-input>
                        <el-input v-else style="width: 94%;" type="textarea" v-model="settleInfo.outSettleRemark" @input="change($event)"  maxlength="1000"></el-input>
                    </el-col>
                    <el-col :span="24" v-else>
                        <label>结算说明：</label><p style="line-height: 18px;" v-html="settleInfo.outSettleRemark && settleInfo.outSettleRemark.replace(/\n/g, '<br/>')"></p>
                    </el-col>
                </el-row>
                <SettlementDetailOperate :errorRules="errorRules" :topApproval = "false"  :executionId="executionId" :settleInfo = settleInfo @refresh="refreshDetail" @close="closeWindow"></SettlementDetailOperate>
            </div>
        </div>
        <!--<Page-nav :navigation="navigation" v-if="requireList.length"></Page-nav>-->
        <!--查看资料详情-->
        <Loading :is-loading="isLoading"></Loading>
        </div>
        <div class="showPrint">
            <SettlementApprovalPrint :startFlag="startFlag" :settleInfo="settleInfo"></SettlementApprovalPrint>
        </div>
    </div>
</template>
<script>
    import Header from "@/components/base/Header";
    import SearchBar from "@/components/SearchBar";
    import Loading from "@/components/base/Loading";
    import PanelTitle from "@/components/base/PanelTitle";
    import SettlementDetailOperate from "@/components/order/broker/SettlementDetailOperate";
    import CirculationOpinion from "@/components/order/broker/CirculationOpinion";
    import OrderProcess from "@/components/order/OrderProcess";
    import { InterfaceService } from "@/services/api";
    import SettlementApprovalPrint from "@/components/order/broker/SettlementApprovalPrint";
    import { MoneyUtil } from '@/utils/moneyUtil';

    export default {
        components: {
            Header,
            SearchBar,
            Loading,
            PanelTitle,
            SettlementDetailOperate,
            OrderProcess,
            CirculationOpinion,
            SettlementApprovalPrint,
        },
        data() {
            return {
                navigation: [
                    {
                        name: "合同信息",
                        position: "order-data-message"
                    },
                    {
                        name: "要货单批次信息",
                        position: "require-order-info"
                    }
                ],
                tab:"1",
                tabs: [
                    { label: "基本信息", index: 1, active: true }
                ],
                isLoading: false,
                order: {},
                status: "",
                executionId: "",
                comment: "",
                orderNo: "",
                startFlag: "",
                settleInfo: {},
                showRejectCommet:false,
                showCloseCommet:false,
                rejectedReason:'',
                errorRules:{},
                execFlowList:[],
                lastFailComment:"",
                lastFailOperator:"",
            };
        },
        computed: {
            userinfo() {
                return this.$store.state.userInfo;
            },
            role() {
                return this.$store.state.userInfo
                    ? this.$store.state.userInfo.bs
                    : 0;
            },
            hasOrderNo(){
                // this.orderNo = "ORD2001928237232232"
                return this.orderNo.indexOf("ORD") != -1
            },

        },
        filters: {
            percent(val) {
                return (val * 100)+ "%";
            }
        },
        methods: {
            change(e) {
                this.$forceUpdate()
            },
            handleCheck(e,type,initType){
                let value = initType ? e : e.target.value;
                const reg = new RegExp(/^[+]{0,1}(\d{1,13})$|^[+]{0,1}(\d{1,13}\.\d+)$/);
                if ((value&&!reg.test(value) || (!value))) {
                    this.errorRules[type] = true
                    // this.$message.error("金额填写有误，请确认后重新输入");
                    // this.settleInfo[type] = "";
                    console.log(this.settleInfo[type]);
                }else{
                    this.errorRules[type] = false
                }
                this.$forceUpdate()

            },
            compRateOfChange(){
                let num = 0
                if (this.settleInfo.outSettleInfoStatus === 'init') {
                    num = ((Number(this.settleInfo.erpSettleAmount) - Number(this.settleInfo.erpContractAmount)) / Number(this.settleInfo.erpContractAmount)).toFixed(2) * 100
                }else {
                    num = ((Number(this.settleInfo.outSettleAmount) - Number(this.settleInfo.outContractAmount)) / Number(this.settleInfo.outContractAmount)).toFixed(2) * 100
                }
                if (isNaN(num) || num === Infinity) {
                    return "合同金额（含税）或最终结算金额填写有误，请确认后重新填写"
                }else {
                    return num + "%"
                }
            },
            handleSelectTab(tab){
                this.tab = tab.index;
            },
            // 进入合同详情页
            handleContractDetail(){
                if (!this.hasOrderNo) {
                    return
                } else {
                    let orderNo = this.orderNo,
                        procDefKey = "CONTRACT_APPROVE_WF"
                        // executionId = this.executionId;

                    const {href} = this.$router.resolve({
                        path: "/brokerApprovalDetail",
                        query: {
                            orderNo,
                            procDefKey,
                            // executionId,
                        },
                    });
                    window.open(href, '_blank');
                }
            },
            // 子组件点击请求打印
            handleClickPrint() {
                window.print();
            },
            //关闭窗口
            handleCloseWindow(){
                window.opener=null;
                window.close();
            },
            closeWindow(){
                this.getApprovalDetail();
                setTimeout(()=>{
                    this.handleCloseWindow()
                },1000)
            },
            refreshDetail(type){
                this.getApprovalDetail(type)
            },
            getApprovalDetail(type) {
                console.log(type);
                let execution = this.executionId || '';
                let params = {};
                // 没有executionId（等待中的合同）入参orderNo；
                if (execution) {
                     params = {
                        executionId: execution,
                        procDefKey:"SETTLE_APPROVE_WF",
                        pageIndex: 1
                    };
                }
                InterfaceService.getApprovalDetail(
                    params,
                    data => {
                        let res = data.respData;
                        if (res.respCode === "0000") {
                            if (!type) {
                                if (window.opener) {
                                    window.opener.location.reload();
                                }
                            }
                            if (type !== "uploadFile") {
                                this.settleInfo = data.respData || {};
                                this.settleInfo = Object.assign(this.settleInfo,data.respData.settleInfo);
                                if (this.settleInfo.outSettleInfoStatus === 'init'){
                                    this.handleCheck(this.settleInfo.erpContractAmount,"erpContractAmount","init");
                                    this.handleCheck(this.settleInfo.erpSettleAmount,"erpSettleAmount","init");
                                } else {
                                    this.handleCheck(this.settleInfo.outContractAmount,"outContractAmount","init");
                                    this.handleCheck(this.settleInfo.outSettleAmount,"outSettleAmount","init");
                                }
                                this.orderNo = this.settleInfo.orderNo || "";
                                this.startFlag = this.settleInfo.operateStatus == "start";
                                this.execFlowList = data.respData.execFlowList || [];
                                if (this.execFlowList.length > 0) {
                                    // 最后一条退回原因
                                    this.lastFailComment = this.execFlowList[0].comment;
                                    //最后一条操作人
                                    this.lastFailOperator = this.execFlowList[0].acctName;
                                    let lastIsAgree = this.execFlowList[0].isAgree;
                                    let firstApproveFlow = this.settleInfo.approveFlowList[0];
                                    // 当前节点是招采部且最近一条流水为退回，则显示退回原因
                                    this.showRejectCommet = firstApproveFlow.isCurrentNode == "1" && firstApproveFlow.step == "1" && lastIsAgree == "N";
                                    // 最近一条流水为关闭，则显示关闭原因
                                    this.showCloseCommet = this.execFlowList[0].taskId == "closed";
                                }
                                let status = this.settleInfo.operateStatus;
                                status == "approve" ? this.approvalButton = true : this.approvalButton = false;
                            }
                            this.settleInfo.execAttachList = data.respData.execAttachList
                        } else {
                            this.$message.error(res.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            init() {
                this.executionId = this.$route.query.executionId;
                this.getApprovalDetail("init");
            },
        },
        mounted() {
            this.init();
        },
    };
</script>
<style lang="scss" scoped>
    .inner-container {
        margin-bottom: 100px;
        font-size: 14px;
    }
    .change-amount{
        .el-input{
            margin-bottom: 10px;
            width: 70%;
        }
    }
    .table {
        /deep/ .el-button {
            font-size: 12px;
            span{
                line-height: 32px;
            }
        }

        width: 100%;
        line-height: 23px;
        font-size: 12px;
        table {
            width: 100%;
        }
        td {
            padding: 14px 10px;
            vertical-align: middle;
            word-break: break-word;
        }

        thead {
            text-align: center;
            white-space: nowrap;
            font-size: 14px;
            color: #909399;
            background: #f5f5f5;
        }

        tbody {
            text-align: center;

            tr:hover {
                background: #e8f3fd;
            }

            td {
                border-bottom: 1px solid #ebeef5;
            }
        }
    }

    .order-info {
        margin-bottom: 20px;
        /*line-height: 25px;*/
        font-size: 12px;
        position: relative;
        /deep/ .el-row {
            height: 100%;
            margin-bottom: 14px;
        }
        /deep/ .el-col {
            padding: 0 10px;
        }

        p {
            width: 100%;
            display: flex;
            padding-right: 10px;
            word-break: break-word;
            white-space: normal;

            & > span {
                display: inline-block;
                flex: 1 1 0%;
            }
            em{
                cursor: pointer;
            }
        }

        label {
            white-space: nowrap;
            color: #888888;
        }

        a {
            color: #0082ff;
        }
    }
    .order-info-title {
        margin: 5px 0;
        margin-bottom: 14px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
    }
    .line{
        width: 100%;
        height: 1px;
        background: #f0f0f0;
        margin: 20px 0;
    }
    .fix-bottom{
        width: 100%;
        margin: 0 auto;
        text-align: center;
    }
    /deep/ .el-textarea__inner{
        height: 100px;
    }
    .tax{
        width: 100%;
        vertical-align:baseline;
        margin-bottom: 20px;
        table-layout:fixed;
        td{
            word-wrap:break-word;
            width: 33%;
            padding: 10px;
            background: #f5f5f5;
            vertical-align:middle;
            text-align: left;
        }
    }
    /deep/ .el-dialog__header:before {
        height: 0;
    }
    .line-top{
        width: 95%;
        height: 1px;
        background: #eee;
        position: absolute;
        top:65px;
    }
    .count{
        float: right;
        span.red{
            color: #f00;
        }
    }
    .panel-title{
        margin-top: 40px;
    }
    .showPrint {
        display: none;
        width: 100%;
    }
    @media print {
        @page {
            size: A4;
        }
        .showPrint {
            display: block;
            width: 100%;
        }
        .unShowPrint {
            display: none
        }
        .printHead {
            position: fixed;
            bottom: 0px;
        }
    }
    .mb10{
        margin-bottom: 10px;
    }
</style>
<style>
    @media print {
        .copy-right, .fixed-tool {
            display: none;
        }
    }
</style>
