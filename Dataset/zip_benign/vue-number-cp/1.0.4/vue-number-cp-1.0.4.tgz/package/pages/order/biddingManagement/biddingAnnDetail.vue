<template>
  <div class="index-porduct">
    <Header :is-white-bg="true"></Header>
    <SearchBar :search-type="5" :progress="'招标公告'" :is-border-bottom="true"></SearchBar>
    <div class="list-home">
      <div class="list-content">
        <h3 class="f20 bold">{{biddingInfo.bidName}}</h3>
        <div style="margin-bottom: 20px;">
          <span>
            发布日期：{{biddingInfo.publishTime}}
          </span>
          <span>
            招标公告编号：{{biddingInfo.bidNo}}
          </span>
          <span>
            浏览量：{{biddingInfo.pageViews || 0|formatMoney(0)}}
          </span>
        </div>
        <div v-if="biddingInfo.bidModelName" class="category" v-html="'招标模式：' + biddingInfo.bidModelName">
        </div>
        <div class="category">
          <!--招标品类：{{biddingInfo.categoryLevelOneName}}-{{biddingInfo.categoryLevelTwoName}}-{{biddingInfo.categoryLevelThreeName}}-->
          招标品类：{{threeCategoryNameList.join("、")}}
          <template v-if="biddingInfo.bidScope">
            （<i class="red">{{biddingInfo.bidScope}}</i>）
          </template>
        </div>
        <div class="closing-date" v-if="biddingInfo.annualPurchaseVolume">
          年度预计采购量：{{biddingInfo.annualPurchaseVolume}}
        </div>
        <div class="steps-cont">
          <Steps :tenderList="tenderList" :active="biddingInfo.activeNode" :space="198"></Steps>
        </div>
        <div style="height: 1px;background: rgb(238, 238, 238);width: 100%;margin-top: 30px;"></div>
        <div class="order-info-title bold">
          报名要求
        </div>
        <div style="margin-bottom: 30px;" v-html="biddingInfo.enterRequire"></div>
        <!--<div>报名方法：</div>-->
        <!--<div style="padding-bottom: 30px;" v-html="biddingInfo.signUpMethod"></div>-->
        <!--<div>其他要求：</div>-->
        <!--<div style="padding-bottom: 30px;border-bottom: 1px solid #eee;" v-html="biddingInfo.otherRequirements"></div>-->
        <div>
          <img style="width: 750px;margin-bottom: 10px;" v-for="item in imgFileInfoList" :src="item.attachUrl">
        </div>
        <div class="order-info-title file-title bold" v-if="ossFileInfoList.length">
          附件
          <span class="hand blue f12" style="padding-left: 6px;" @click="handlePackingDownload">下载</span>
        </div>
        <div class="file-content" v-if="ossFileInfoList.length">
          <p v-for="(file,index) in ossFileInfoList" :key="index">
            <span>{{file.attachName}}</span><a class="hand blue" @click="handleView(file.attachUrl)">预览</a><a class="hand blue" @click="handleDownload(file)">下载</a>
          </p>
        </div>
      </div>
    </div>
    <FixBottom v-if="operationType === 'true'">
      <div class="fix-bottom tc">
        <el-button type="primary" @click="handleSignUp">报名</el-button>
      </div>
    </FixBottom>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import SearchBar from "@/components/SearchBar";
import Header from "@/components/base/Header";
import FixBottom from "@/components/base/FixBottom";
import Steps from "@/components/base/steps";
import Loading from "@/components/base/Loading";
import { viewFile } from '@/utils/orderUtil';

// import FixedTool from '@/components/FixedTool'
export default {
  components: {
    SearchBar,
    Header,
    FixBottom,
    Loading,
    Steps,
    // FixedTool,
  },
  watch: {
  },
  computed: {
    isLogin() {
      return this.$store.state.isLogin
    },
    // addCommas(num){
    //   var string=num+'';
    //   var arr=string.split('.');
    //   var num1=arr[0];
    //   var num2=arr[1]?'.'+arr[1]:'.00';
    //   var reg=/(\d+)(\d{3})/;
    //   while(num1.test(reg)){
    //     num1.replace(reg,'$1'+','+'$2')
    //   }
    //   return num1+num2;
    // }
  },
  data() {
    return {
      biddingInfo: {},
      isLoading: false,
      bidNo: "",
      operationType: "",
      imgFileInfoList: [],
      ossFileInfoList: [],
      threeCategoryNameList: [],
      tenderList: [],
    };
  },
  methods: {
    handleSignUp() {
      if (this.isLogin != "1") {
        this.$confirm(
          "<p class='tl'>若要参与该公告的招标，请先注册加入本平台才能报名参与招标。大家采平台为您提供更专业、更丰富的资源。若有疑问请联系平台客服电话：400-0609-008（工作日上午8:30-11:30，下午13:00-17:30）。</p>",
          "温馨提示",
          {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            dangerouslyUseHTMLString: true,
            confirmButtonText: "去注册/登录",
            cancelButtonText: '取消',
          }).then(() => {
            this.$router.push('/login');
            sessionStorage.setItem('toFullPath', "biddingSignUpInfo?bidNo=" + this.bidNo + "&type=submit"); //\
          }).catch(() => {
          });
      } else {
        this.$router.push({
          path: "/biddingSignUpInfo",
          query: {
            bidNo: this.bidNo,
            type: "submit",
          },
        })
      }
    },
    handleView(url) {
      if (url) {
        viewFile(url)
      }
    },
    handleDownload(item) {
      let attach = [];
      attach.push({
        url: item.attachUrl,
        name: item.attachName
      });
      this.$download(attach).then(res => {
        this.$message.success("已下载");
      }).catch(res => {
        this.$message.error("下载失败");
      })
    },
    handlePackingDownload() {
      let fileInfoBeans = []
      this.ossFileInfoList.forEach(item => {
        fileInfoBeans.push({
          archivePath: item.attachName,
          fileUrl: item.attachUrl,
        })
      })
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            // const files = [
            //   { name: this.biddingInfo.bidName + "附件.zip", url: url }
            // ];
            // this.$download(files, () => {this.isLoading = true}, () => {this.isLoading = false}).then(() => {
            //   this.$message.success("已下载");
            // });
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: this.biddingInfo.bidName + "附件.zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    getBiddingAnnDetail() {
      InterfaceService.biddingAnnDetail(
        { bidNo: this.bidNo },
        data => {
          if (data.respData.respCode === "0000") {
            console.log(data);
            this.biddingInfo = data.respData.bidInfo || {}
            this.imgFileInfoList = data.respData.bidInfo.imgFileInfoList || []
            this.ossFileInfoList = data.respData.bidInfo.ossFileInfoList || []
            this.tenderList = data.respData.bidInfo.nodePlanInfoList || []
            this.threeCategoryNameList = [];
            this.biddingInfo.ibBidCategoryInfos = this.biddingInfo.ibBidCategoryInfos || [];
            if (this.biddingInfo.ibBidCategoryInfos.length == 1) {
              this.threeCategoryNameList.push(this.biddingInfo.ibBidCategoryInfos[0].categoryLevelThreeName)
            } else {
              this.biddingInfo.ibBidCategoryInfos.forEach(i => {
                this.threeCategoryNameList.push(i.categoryLevelTwoName)
              });
              this.threeCategoryNameList = [...new Set(this.threeCategoryNameList)]
            }
            if (data.respData.bidInfo.nodePlanInfoList) {
              this.tenderList = [];
              data.respData.bidInfo.nodePlanInfoList.forEach(item => {
                this.tenderList.push({
                  top_title: item.nodePlanName,
                  top_info: item.planTime,
                  nodePlan: item.nodePlan,
                  lightShow: item.lightShow,
                })
              })
            }
            this.tenderList.forEach((item, index) => {
              if (item.lightShow === '0') {
                this.biddingInfo.activeNode = index
              }
              if (index == 5 && item.lightShow === '1') {
                this.biddingInfo.activeNode = index + 1
              }
            });
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    init() {
      this.bidNo = this.$route.query.bidNo || "";
      this.operationType = this.$route.query.operationType || "";
      const params = {
        businessType: "1",
        businessKey: this.bidNo,
        recordType: "valueAdd",
      };
      InterfaceService.generalBusinessInfoRecord(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            this.getBiddingAnnDetail();
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
  },
  mounted() {
    this.init()
  },
};
</script>

<style lang="scss" scoped>
.list-home {
  .list-content {
    width: 1190px;
    margin: 20px auto;
    padding-bottom: 82px;
    line-height: 23px;
    div {
      font-weight: 500;
      img {
        display: block;
      }
    }
    .f20 {
      font-size: 20px;
      margin-bottom: 12px;
    }
    span {
      font-size: 12px;
      font-weight: 500;
      line-height: 15px;
      margin-right: 56px;
      color: #888;
    }
    .category {
      margin-bottom: 10px;
      font-size: 14px;
      font-weight: bold;
      line-height: 17px;
    }
    .closing-date {
      font-size: 14px;
      margin-top: 10px;
      padding-bottom: 30px;
      font-weight: bold;
    }
    .order-info-title {
      margin: 20px 0;
      padding: 0 10px;
      font-size: 14px;
      border-left: 3px solid #000;
      line-height: 12px;
    }
  }
}
.steps-cont {
  padding: 20px 0;
  /*border:1px solid #eee;*/
  box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
}
/deep/ .el-step__head {
  margin-bottom: 14px;
}
.file-content {
  padding: 14px 10px;
  border: 1px solid #eee;
  span {
    margin-right: 6px !important;
  }
  a {
    margin-right: 10px;
  }
}
.file-title {
  margin: 20px 0 10px;
}
.end {
  color: #c99f4f;
  font-size: 20px;
}
</style>
