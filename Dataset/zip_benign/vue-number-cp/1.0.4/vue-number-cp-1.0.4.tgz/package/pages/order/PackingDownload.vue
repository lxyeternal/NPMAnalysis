<template>
  <div>
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" :progress="'批量下载'" :is-border-bottom="true" :product-create-process="2"></SearchBar>
    <div class="inner-container">
      <div class="warning-tip">请不要关闭本页面，若关闭页面下载终止！下载完成后页面自动关闭。</div>
      <div class="file-name">{{fileName}}</div>
      <div class="download-loading">正在打包下载中<em>...</em></div>
    </div>
  </div>
</template>

<script>
  import SearchBar from "@/components/SearchBar";
  import Header from "@/components/base/Header";
  import { InterfaceService } from "@/services/api";

  export default {
    name: "packingDownload",
    components:{
      SearchBar,
      Header,
    },
    data() {
      return {
        url:"",
        fileName:"",
        submitBidNo:"",
        record:"",
        timer:null
      }
    },
    methods:{
      handleDownload(){
        InterfaceService.getOssFile(this.url,data => {
          // let res = JSON.parse(JSON.stringify(data))
          // console.log(res.response.data.indexOf("NoSuchKey") === -1)
          // if (!res.response || !res.response.data || res.response.data.indexOf("NoSuchKey") === -1) {
          if (typeof data === 'string') {
// if (data.indexOf("Error") == 1) {
              const files = [
                { name: this.fileName + ".zip", url: this.url }
              ];
              this.$download(files).then(() => {
                this.$message.success("已下载");
                clearInterval(this.timer);
                setTimeout(()=>{
                  if (!this.record) {
                    window.opener=null;
                    window.open('','_self');
                    window.close();
                  }else {
                    this.supplierDownloadRecord(this.submitBidNo)
                  }
                },2000)
              });
          }else {
            this.timer = setTimeout(()=> {
              this.handleDownload()
            }, 4000)
          }
          // }
        });
      },
      //记录记录供应商下载招标文件
      supplierDownloadRecord(submitBidNo) {
        const params = {
          submitBidNo
        };
        InterfaceService.supplierDownloadRecord(params, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            window.opener=null;
            window.open('','_self');
            window.close();
          } else {
            this.$message.error(data.respData.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      },
    },
    mounted(){
      this.url = this.$route.query.url || "";
      this.fileName = this.$route.query.name || "";
      this.record = this.$route.query.record || false;
      this.submitBidNo = this.$route.query.submitBidNo || "";

      this.handleDownload()
    },
    destroyed() {
      clearInterval(this.timer)
    }
  }
</script>

<style scoped lang="scss">
  .inner-container{
    div{
      font-size:18px;
      width: 100%;
      text-align: center;
      margin-top: 100px;
      color:rgba(201,159,79,1);
      font-weight:600;
    }
    .file-name{
      color: #444;
    }
    .download-loading{
      margin-top: 30px;
      margin-bottom: 418px;
      em {
        display: inline-block;
        height: 1em;
        line-height: 1;
        text-align: left;
        vertical-align: -.25em;
        overflow: hidden;
      }
      em::before {
        display: block;
        content: '...\A..\A.';
        white-space: pre-wrap;
        animation: dot 1s infinite step-start both;
      }
      @keyframes dot {
        33% { transform: translateY(-2em); }
        66% { transform: translateY(-1em); }
      }
    }
  }

</style>