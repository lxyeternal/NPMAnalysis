<template>
  <div>
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" :progress="'发货-第'+orderInfo.requireBatchNo+'批'" :is-border-bottom="true" :product-create-process="2"></SearchBar>
    <div class="inner-container">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
      <!-- 合同基本信息 -->
      <div class="order-info">
        <PanelTitle title="合同基本信息"></PanelTitle>
        <RequireOrderInfo :showOtherFile="false" v-if="Object.keys(orderInfo).length" :orderInfo="orderInfo"></RequireOrderInfo>
        <PanelTitle title="发货清单"></PanelTitle>

        <FixSearch :TopDistance="900">
          <div slot="center">
            <div class="search-container fix-search-container">
              <div class="left">
                <span>商品名/型号：</span>
                <el-input v-model.trim="form.skuName" placeholder="请输入关键词" maxlength="30" clearable></el-input>
              </div>
              <div class="right">
                <div class="radio-container">
                  <span>筛选：</span>
                  <el-radio-group v-model="form.type">
                    <el-radio label="">全部</el-radio>
                    <el-radio label="01">显示未确认发货数量的商品</el-radio>
                  </el-radio-group>
                </div>
                <div class="btn-contaier">
                  <el-button type="primary" style="width: 80px;" @click="handleSearch">查询</el-button>
                  <el-button style="width: 80px;" @click="handleClear">重置</el-button>
                </div>
              </div>
            </div>
          </div>
        </FixSearch>

        <TableThead :TopDistance="900" :fixedTop="50">
          <tr slot="tr">
            <td width="43px" style="padding-left: 10px;">序号</td>
            <td width="461px">商品名称/型号</td>
            <!--<td width="170px" class="tr">已供货量(含本次)</td>-->
            <td width="60px"></td>
            <td width="170px" class="tr">本批次要货量</td>
            <td width="60px"></td>
            <td width="204px" class="tr"><span class="required"></span>填写发货数量</td>
            <td width="60px"></td>
            <td class="tl" width="132px" style="padding-right: 10px;">操作</td>
          </tr>
        </TableThead>
        <div class="list-content">
          <div class="panel-content" ref="panelContent">
            <el-form class="form" :model="form" size="small" label-width="100px">
              <el-row>
                <el-col :span="12">
                  <el-form-item label="商品名/型号：">
                    <el-input v-model.trim="form.skuName" placeholder="请输入关键词" clearable></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="12">
                  <el-form-item label="筛选：">
                    <el-radio-group v-model="form.type">
                      <el-radio label="">全部</el-radio>
                      <el-radio label="01">显示未确认发货数量的商品</el-radio>
                    </el-radio-group>
                    <el-button style="margin-left: 40px;" type="primary" class="small-btn" @click="handleSearch">查询</el-button>
                    <el-button class="small-btn" @click="handleClear">重置</el-button>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
          </div>

          <table class="table-default">
            <thead>
              <tr>
                <td width="43px" style="padding-left: 10px;">序号</td>
                <td width="461px">商品名称/型号</td>
                <!--<td width="170px" class="tr">已供货量(含本次)</td>-->
                <td width="60px"></td>
                <td width="170px" class="tr">本批次要货量</td>
                <td width="60px"></td>
                <td width="204px" class="tr"><span class="required"></span>填写发货数量</td>
                <td width="60px"></td>
                <td class="tl" width="132px" style="padding-right: 10px;">操作</td>
              </tr>
            </thead>
            <tbody v-for="(item,ind) in goodsList" :key="ind" class="tbody-row" v-if="goodsList.length" style="border-bottom: 1px solid #eee;">
              <tr style="border-bottom: none;">
                <td class="pt38" style="padding-left: 10px;">
                  {{ind + 1 + ((pageIndex - 1) * pageSize)}}
                </td>
                <td>
                  <div class="thumbnail fl" :style="{background:item.picUrl ? 'url('+item.picUrl+')' : '#eee'}"></div>
                  <div :ref="'goodsHeight' + ind" class="fr" style="width: 385px;margin-left: 6px;">
                    <p :title="item.skuName" class="goods-name hover-underline hand" @click="handleGoproduct(item)">{{item.skuName}}</p>
                    <p style="margin-top: 10px;">型号：{{item.model}}</p>
                    <!--<p class="fixed" v-if="item.type == '1'">固定组价商品</p>-->
                    <p class="new-goods" v-if="item.isNewCom == '1'">新组价商品
                      <el-popover popper-class="dark-popover" trigger="hover" placement="right">
                        <div style="color: #fff;width: 185px;">
                          新组价商品是指，代理商创建合同时，新组的商品。
                        </div>
                        <i slot="reference"><em class="triangle-topright"></em></i>
                      </el-popover>
                    </p>
                    <p class="tag" v-if="item.isCombination=='1' && item.isNewCom !== '1'">组价商品</p>
                    <p class="tag bg-lightSteelBlue" v-if="item.bidSurchangeBeanList && item.bidSurchangeBeanList.length">含附加项</p>
                  </div>
                </td>
                <td></td>
                <td class="tr">{{computedReqCount(item.details) | formatMoney}}{{item.goodsUnit}}</td>
                <td></td>
                <td class="tr">
                  <template v-if="item.details && item.details.length === 1 && !item.details[0].location">
                    <el-input v-model="item.details[0].deliveryCount" placeholder="请输入数量" :maxlength="item.details[0].deliveryCount && String(item.details[0].deliveryCount).indexOf('.') != -1 ? 13 : 10" class="right_padding" @input="checkNum($event,item.details[0],'deliveryCount',false, false, item)">
                      <div slot="suffix" class="suffix" :title="item.goodsUnit">{{item.goodsUnit}}</div>
                    </el-input>
                    <div class="red error-msg" v-if="item.errorMsg">{{item.errorMsg}}</div>
                  </template>
                  <template v-else>
                    <template v-if="computedDelCount(item)">
                      {{computedDelCount(item)}}{{item.goodsUnit}}
                    </template>
                    <template v-else>
                      -
                    </template>
                  </template>

                </td>
                <td></td>
                <td style="padding-right: 10px;"><span class="blue-pointer" @click="handleGoodsDetailDia(item)">查看要货要求及附件</span></td>
              </tr>
              <tr v-for="(d,index) in item.details" v-if="!(item.details && item.details.length === 1 && !item.details[0].location)">
                <td colspan="3">{{d.label}}：{{d.location}}</td>
                <td class="tr">{{d.requireCount}}{{item.goodsUnit}}</td>
                <td></td>
                <td>
                  <el-input v-model="d.deliveryCount" placeholder="请输入数量" :maxlength="d.deliveryCount && String(d.deliveryCount).indexOf('.') != -1 ? 13 : 10" class="right_padding" @input="checkNum($event,d,'deliveryCount',false,true)">
                    <div slot="suffix" class="suffix" :title="d.goodsUnit">{{d.goodsUnit}}</div>
                  </el-input>
                  <div class="red error-msg" v-if="d.errorMsg">{{d.errorMsg}}</div>
                </td>
                <td></td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="table-pagination" v-if="goodsList.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
        <div class="product-empty" v-if="!goodsList.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <div>没有搜索到相关商品，请重新修改搜索条件搜索！</div>
        </div>
        <RequireOrderInfo :showOtherFile="true" :fromDeliverGoods="true" v-if="Object.keys(orderInfo).length" :orderInfo="orderInfo"></RequireOrderInfo>
        <PanelTitle title="填写物流信息"></PanelTitle>
        <el-form class="nowrap" :model="deliverForm" :rules="rules" ref="deliverForm">
          <el-form-item label="运送方式：" prop="shippingMethod">
            <el-radio-group v-model="deliverForm.shippingMethod">
              <el-radio label="0">供应商自行配送</el-radio>
              <el-radio label="1">物流配送</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-row v-if="deliverForm.shippingMethod=='1'" class="form-response-item">
            <el-col :span="12">
              <el-form-item label="物流公司：" prop="expressCompany">
                <el-select v-model="deliverForm.expressCompany" placeholder="请选择" clearable @change="handleChangeExpressCompany">
                  <el-option v-for="(item,index) in expressCompanyList" :key="index" :label="item.expressName" :value="item.expressCode"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="运单号码：" prop="trackingNo">
                <el-input v-model="deliverForm.trackingNo" placeholder="请填写运单号码" maxlength="20"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
    </div>
    <FixBottom>
      <div class="tc">
        <el-button type="primary" style="width: 120px;" @click="handleEditExpress('submit')">发货</el-button>
        <el-button style="width: 120px;" @click="handleEditExpress('save')">保存</el-button>
      </div>
    </FixBottom>
    <!-- 确认发货 -->
    <GoodsDetailDialog ref="goodsDetailDialog"></GoodsDetailDialog>

    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import Header from "@/components/base/Header";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import ViceHeader from "@/components/base/ViceHeader";
import InputNumber from "@/components/base/InputNumber";
import GoodsDetailDialog from "@/components/order/dialog/GoodsDetailDialog";
import { InterfaceService } from "@/services/api";
import Breadcrumb from "@/components/base/Breadcrumb";
import RequireOrderInfo from "@/components/order/RequireOrderInfo";
import SearchBar from "@/components/SearchBar";
import { NumberUtil } from '@/utils/numberUtil';
import FixBottom from "@/components/base/FixBottom";

import TableThead from "@/components/base/TableThead";
import FixSearch from "@/components/base/FixSearch";

const deliverForm = {
  shippingMethod: "1",
  expressCompany: "",
  expressName: "",
  trackingNo: ""
};
export default {
  components: {
    Header,
    Loading,
    PanelTitle,
    FixBottom,
    ViceHeader,
    InputNumber,
    RequireOrderInfo,
    GoodsDetailDialog,
    SearchBar,
    FixSearch,
    TableThead,
    Breadcrumb
  },
  props: ["type"],
  data() {
    return {
      isLoading: false,
      allCheck: false,
      isShowTableThead: false,
      reciveText: "",
      requireNo: "",
      deliveryNo: "",
      orderInfo: {},
      form: {
        skuName: '',
        type: '',
      },
      requireList: [],
      breadcrumb: [],
      goodsList: [],
      comfirmRequireList: [],
      storageGoodsList: [],
      flow: [
        {
          name: "确认发货信息",
          active: true,
          next: true
        },
        {
          name: "发货成功",
          active: false,
          next: false
        }
      ],
      showPageNav: false,
      systemTime: "",
      expressCompanyList: [],
      deliverForm: Object.assign({}, deliverForm),
      pageSize: 1,
      total: 0,
      pageIndex: 1,
      rules: {
        expressCompany: [
          {
            required: true,
            message: "请选择物流公司",
            trigger: "change"
          },
        ],
        trackingNo: [
          {
            required: true,
            message: "请填写运单号码",
            trigger: "blur"
          },
        ]
      }
    };
  },
  computed: {
    computedDelCount() {
      return function (item) {
        let num = 0;
        item.details.forEach(i => {
          num = NumberUtil.numAdd(+i.deliveryCount, +num)
        });
        return String(num)
      }
    },
    computedReqCount() {
      return function (details) {
        let num = 0;
        details.forEach(i => {
          num = NumberUtil.numAdd(+i.requireCount, +num)
        });
        return String(num)
      }
    },
    title() {
      let str = "发货";
      str += " - 第" + (this.orderInfo.requireBatchNo || "") + "批";
      return str;
    },
    userinfo() {
      return this.$store.state.userInfo;
    },
    role() {
      return this.$store.state.userInfo
        ? this.$store.state.userInfo.bs
        : 0;
    }
  },
  methods: {
    handleGoproduct(item) {
      window.open(this.$router.resolve({
        path: "/productDetails",
        query: {
          spuId: item.spuId,
          skuId: item.skuId
        }
      }).href, '_blank')
    },
    handleSearch() {
      this.pageIndex = 1;
      this.recordChecked();
      this.handleEditExpress('save', true)
    },
    handleClear() {
      this.form = {
        skuName: '',
        type: '',
      };
      this.handleSearch()
    },
    checkNum(value, item, type, negative, isBid, obj = {}) {
      if (negative) {
        // 负数
        value = value.replace(/[^\d.-]/g, ""); //清除"数字"和"."以外的字符
      } else {
        value = value.replace(/[^\d.]/g, ""); //清除"数字"和"."以外的字符
      }
      value = value.replace(/^\./g, ""); //验证第一个字符是数字
      value = value.replace(/\.{2,}/g, "."); //只保留第一个, 清除多余的
      // value = value.replace(/-{2,}/g,""); //只保留第一个, 清除多余的
      if (value.length > 1 && value[value.length - 1] == '-') {
        value = value.substring(0, value.length - 1)
      }
      value = value.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
      value = value.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3'); //控制可输入的小数
      if (type == 'deliveryCount') {
        if (value.indexOf(".") == -1 && value.length == 10) {
          if (value[9] != '.') {
            value = value.substring(0, value.length - 1)
          }
        }
        if(isBid){
          if(+item.deliveryCount > +item.requireCount){
            this.$set(item, 'errorMsg', '发货数量不能超过本批次要货量')
            value = ''
          }else{
            this.$set(item, 'errorMsg', '')
          }
        }else{
          let requireCount = this.computedReqCount(obj.details)
          if(+item.deliveryCount > requireCount){
            this.$set(obj, 'errorMsg', '发货数量不能超过本批次要货量')
            value = ''
          }else{
            this.$set(obj, 'errorMsg', '')
          }
        }

      }
      item[type] = value;
    },
    handleGoodsDetailDia(item) {
      this.$refs.goodsDetailDialog.open(item, 'checkGoods')
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.recordChecked();
      this.handleEditExpress('save', true)
    },
    // 获取快递列表
    getExpressList() {
      InterfaceService.getExpressList(data => {
        this.expressCompanyList = data.expressList || [];
        this.expressCompanyList.some(s => (s.expressCode == this.deliverForm.expressCompany && (this.deliverForm.expressName = s.expressName)))
      });
    },
    handleSave(type, hideMessage) {
      this.recordChecked()
      if (type === 'save') {
        this.deliverOrder(type, hideMessage)
      } else {
        if (this.storageGoodsList.some(item => {
          return !String(item.deliveryCount)
        })) {
          this.$message.error('还有未填写数量的商品，请重新检查！')
          return false
        }
        if (this.storageGoodsList.every(item => {
          return !+item.deliveryCount
        })) {
          this.$message.error('发货数量不能为0！')
          return false
        }
        this.$refs.deliverForm.validate(valid => {
          if (valid) {
            this.$confirm(
              "确认发货信息并通知采购商已发货？",
              '确认发货',
              {
                cancelButtonClass: "btn-custom-cancel",
                confirmButtonClass: "btn-custom-confirm",
                center: true,
                confirmButtonText: "确认",
                cancelButtonText: '取消',
              }).then(() => {
                this.deliverOrder(type, hideMessage)
              }).catch(() => {
              });
          }
        })
      }
    },
    handleChangeExpressCompany() {
      this.expressCompanyList.some(s => (s.expressCode == this.deliverForm.expressCompany && (this.deliverForm.expressName = s.expressName)))
    },

    // 发货
    deliverOrder(type, hideMessage) {
      const deliveryList = [];
      console.log(this.goodsList, '发货goodsList');
      console.log(this.storageGoodsList, '发货storageGoodsList');

      this.storageGoodsList.forEach(item => {
        deliveryList.push({
          id: item.deliveryDetailId || '',
          skuId: item.skuId,
          deliveryCount: item.deliveryCount,
          requireDetailId: item.id,
        });
      });
      let params = {
        requireNo: this.requireNo,
        deliveryNo: this.deliveryNo || "",
        operType: type,
        deliveryList: deliveryList,
      };
      params = Object.assign(params, this.deliverForm);

      if (params.shippingMethod == "0") {
        delete params.expressCompany;
        delete params.trackingNo;
        delete params.expressName;
      }

      console.log(params, '发货');
      // 发货
      InterfaceService.deliverOrder(
        params,
        data => {
          if (data.respCode === "0000") {
            this.deliveryNo = data.respData.deliveryNo;
            let query = this.$router.history.current.query;
            let path = this.$router.history.current.path;
            //对象的拷贝
            let newQuery = JSON.parse(JSON.stringify(query));
            newQuery.deliveryNo = data.respData.deliveryNo;
            this.$router.push({ path, query: newQuery });
            if (type === 'submit') {
              this.$message.success('发货成功！')
              this.$router.push({
                path: '/resultsFeedback',
                query: {
                  requireNo: this.requireNo,
                  type: 'deliver'
                }
              });
            } else {
              !hideMessage && this.$message.success('保存成功！');
              // this.storageGoodsList = [];
              this.getOrderRequireGoodsList()
            }
            window.opener && window.opener.location.reload();
            // this.handleEditExpress();
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => {
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    // 修改物流
    handleEditExpress(type, hideMessage) {
      // const data = {
      //     requireNo: this.requireNo,
      //     shippingMethod: this.orderInfo.shippingMethod,
      //     expressCompany: this.orderInfo.expressCompany,
      //     trackingNo: this.orderInfo.trackingNo
      // };
      // this.$refs["sendOrderConfirm"].open(data, true);
      let hasChange = false;
      Object.keys(this.deliverForm).forEach(key => {
        if (this.deliverForm[key] != deliverForm[key]) {
          hasChange = true;
        }
      });
      if (hasChange) {
        this.editExpress(type, hideMessage);
      } else {
        this.handleSave(type, hideMessage)
      }
    },
    redirectDetail() {
      if (window.opener) {
        window.opener.location.reload();
      }
      this.$router.push({
        path: "/requireOrderDetail",
        query: {
          requireNo: this.requireNo
        }
      });
    },
    editExpress(type, hideMessage) {
      let params = {
        requireNo: this.requireNo
      };
      params = Object.assign(params, this.deliverForm);
      console.log(params, '---params');

      if (params.shippingMethod == "0") {
        delete params.expressCompany;
        delete params.trackingNo;
        delete params.expressName;
      }
      InterfaceService.editLogistics(
        params,
        data => {
          if (data.respCode === "0000") {
            this.handleSave(type, hideMessage)
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => {
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    // 获取要货单详情
    getRequireOrderDetail() {
      return new Promise(resolve => {
        const params = {
          requireNo: this.requireNo,
          pageIndex: this.pageIndex
        };
        InterfaceService.getRequireOrderDetail(
          params,
          data => {
            if (data.respData.respCode === "0000") {
              this.orderInfo = data.respData || {};
              this.systemTime = data.systemTime;
              if (this.orderInfo.shippingMethod === '1') {
                this.deliverForm.shippingMethod = '1';
                this.deliverForm.expressCompany = this.orderInfo.expressCompany || '';
                this.deliverForm.trackingNo = this.orderInfo.trackingNo || ''
              } else {
                this.deliverForm.shippingMethod = '0';
                this.deliverForm.expressCompany = '';
                this.deliverForm.trackingNo = ''
              }
              this.getOrderRequireGoodsList()
              resolve(true)
            } else {
              this.$message.error(data.respData.respMsg);
            }
          },
          data => { },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      })
    },
    getOrderRequireGoodsList() {
      InterfaceService.getOrderRequireGoodsList(
        {
          requireNo: this.requireNo,
          orderDetailIds: [],
          keywords: this.form.skuName,
          deliveryState: this.form.type,
          pageIndex: this.pageIndex,
        },
        data => {
          if (data.respData.respCode == '0000') {
            this.goodsList = [];
            let attachList = data.respData.attachList || [];
            JSON.parse(JSON.stringify(data.respData.requireList || [])).forEach(item => {
              let onOff = false;
              this.goodsList.forEach(g => {
                if (+g.orderDetailId == +item.orderDetailId) {
                  onOff = true
                }
              });
              if (!onOff) {
                this.goodsList.push(item)
              }
            })
            this.goodsList.forEach(g => {
              this.$set(g, 'details', [])
              JSON.parse(JSON.stringify(data.respData.requireList || [])).forEach((item, ind) => {
                if (+g.orderDetailId == +item.orderDetailId) {
                  g.details.push({
                    requireCount: item.requireCount,
                    deliveryCount: item.deliveryCount === null ? item.requireCount : item.deliveryCount,
                    label: '',
                    goodsUnit: item.goodsUnit,
                    skuId: item.skuId,
                    orderDetailId: item.orderDetailId,
                    deliveryDetailId: item.deliveryDetailId,
                    location: item.location,
                    attachList: [],
                    remark: item.remark,
                    id: item.id,
                    model: item.model,
                  })
                }
              })
              // this.$set(g,'deliveryCount',this.computedReqCount(g.details))
            });
            this.goodsList.forEach((item, ind) => {
              item.details.forEach((_item, _ind) => {
                _item.label = '标段' + (_ind + 1)
                attachList.forEach(att => {
                  if (att.requireDetailId === _item.id) {
                    _item.attachList.push({
                      attachUrl: att.attachUrl,
                      attachName: att.attachName,
                      viewUrl: att.attachUrl,
                      requireDetailId: att.requireDetailId,
                      attachOperFlg: 'Update',
                      attachId: att.attachId,
                      attachType: '0',
                    })
                  }
                })
              });
            });
            this.pageSize = data.respData.pageSize;
            this.total = data.respData.totalCount;
            this.$nextTick(() => {
              this.goodsList.forEach((item, index) => {
                this.$set(item, 'firstTdHeight', this.$refs['goodsHeight' + index][0].offsetHeight + 28)
              })
            });
            this.goodsList.forEach(_item => {
              _item.details.forEach(det => {
                let onOff = false;
                this.storageGoodsList.forEach(item => {
                  if (item.id === det.id) {
                    if (item.details && item.details.length === 1 && !item.details[0].location) {
                      // 如果只有一条  父级 显示数量为 子级第一个
                      _item.deliveryCount = item.deliveryCount
                    } else {
                      det.deliveryCount = item.deliveryCount == null ? item.requireCount : item.deliveryCount
                    }
                    // _item.deliveryCount = item.deliveryCount;
                    item.deliveryDetailId = det.deliveryDetailId;
                    onOff = true;
                  }
                });
                if (!onOff) {
                  this.storageGoodsList.push(det)
                }
              })
            });
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => {
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    recordChecked() {
      this.goodsList.forEach(item => {
        // let onOff = false;
        item.details.forEach(det => {
          this.storageGoodsList.forEach(_item => {
            if (det.id === _item.id) {
              // onOff = true;'
              if (item.details && item.details.length === 1 && !item.details[0].location) {
                _item.deliveryCount = det.deliveryCount
              } else {
                _item.deliveryCount = det.deliveryCount
              }
              _item.deliveryDetailId = det.deliveryDetailId
            }
          })
        })
        // if (!onOff) {
        //   this.storageGoodsList.push(item)
        // }
      })
    },
    async  init() {
      await this.getRequireOrderDetail();
      this.getExpressList();
    },
    handleScroll(e) {
      if (!e.target.documentElement || !e.target.body) return
      let scrollTop = e.target.documentElement.scrollTop || e.target.body.scrollTop;
      let height = this.$refs.panelContent && this.$refs.panelContent.offsetTop || 825;
      // scrollTop > this.TopDistance ? this.isShowTableThead = true : this.isShowTableThead = false
      scrollTop > height ? this.isShowTableThead = true : this.isShowTableThead = false
    },
  },
  mounted() {
    this.breadcrumb = [
      {
        name: '管理中心',
        path: '/vendorCenter/accountInfo'
      },
      {
        name: '交易管理',
        path: '/vendorCenter/orderList',
      },
      {
        name: '材料管理',
        path: '/vendorCenter/requireOrderList',
      },
      { name: '发货' },
    ];
    this.requireNo = this.$route.query.requireNo;
    this.deliveryNo = this.$route.query.deliveryNo;
    this.init();
    window.addEventListener('scroll', this.handleScroll, true)
  },
  destroyed() {
    window.removeEventListener("scroll", this.handleScroll, true);
  }
};
</script>
<style lang="scss" scoped>
.link {
  text-decoration: underline;
  cursor: pointer;
  color: #0082ff;
  &:hover {
    color: #0082ff;
  }
  &:active {
    color: #4c9cdd;
  }
}

.red-font {
  color: #e94650;
}

.nowrap {
  white-space: nowrap;
}

.btn-top {
  width: 100px;
}

.btn-bottom {
  width: 150px;
}

.inner-container {
  margin-bottom: 100px;
  font-size: 14px;
}

.order-info {
  margin-bottom: 20px;
  line-height: 30px;
  font-size: 12px;

  p {
    display: flex;
    padding-right: 10px;
    word-break: break-word;
    white-space: normal;

    & > span {
      display: inline-block;
      flex: 1 1 0%;
    }
  }

  label {
    white-space: nowrap;
    color: #888888;
  }
}

.cut,
.add {
  display: inline-block;
  width: 28px;
  height: 33px;
  background: white;
  text-align: center;
  line-height: 33px;
  border: 1px solid #dddddd;
  cursor: pointer;
  vertical-align: middle;
  user-select: none;
}

.cut.grey,
.add.grey {
  cursor: not-allowed;
  background: #eeeeee;
}

.add {
  margin-left: -3px;
}

.cut {
  margin-right: -3px;
}
.go-blue:hover {
  color: #0082ff;
  text-decoration: underline;
  cursor: pointer;
}
.required {
  &::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
.list-content {
  width: 1190px;
  margin: 0 auto 20px;
  table {
    table-layout: fixed;
    width: 100%;
    line-height: 17px;
    font-size: 12px;
    td {
      table {
        td {
        }
      }
      padding: 15px 5px;
      vertical-align: middle !important;
      word-break: break-all;
      position: relative;
      .error-msg {
        // position: absolute;
        // right: 10px;
        text-align: left;
        margin-top: 6px;
      }
      .add-flg {
        position: absolute;
        left: 10px;
        margin-top: 6px;
      }
      .thumbnail {
        width: 60px;
        height: 60px;
        background: #eee;
      }
      .goods-name {
        width: 100%;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
      }
      .fixed,
      .new-goods {
        position: relative;
        overflow: hidden;
        width: 100px;
        margin-top: 6px;
        height: 20px;
        line-height: 20px;
        background: #6598d3;
        text-align: center;
        font-size: 14px;
        color: #fff;
        border-radius: 2px;
      }
      .new-goods {
        background: #ff7d1d;
        .triangle-topright {
          width: 28px;
          height: 70px;
          position: absolute;
          background: #313131;
          top: -54px;
          right: -50px;
          -webkit-transform: rotate(45deg);
          transform: rotate(45deg);
        }
      }
      i {
        position: absolute;
        right: 16px;
        top: 50%;
        margin-top: -9px;
      }
      > p {
        line-height: 17px;
        & + p {
          margin-top: 4px;
        }
      }
    }
    .pt38 {
      padding-top: 38px !important;
    }
    thead {
      font-size: 14px;
      text-align: left;
      white-space: nowrap;
      background: #f9f9f9;
      color: #888;
      border-bottom: 1px solid #eee;
    }
    .tbody-row {
      &:hover {
        background: #f0f8ff;
      }
    }
    tbody {
      text-align: left;
      /*.notice-td{*/
      /*background: #FFE9EB;*/
      /*padding: 6px 10px;*/
      /*}*/
      tr {
        border-bottom: 1px solid #eee;
      }
      .border-none {
        border-bottom: none;
      }
      .material-description {
        td {
          /deep/ .el-input {
            input {
              height: 34px;
            }
          }
        }
      }
    }
  }
}
/deep/ .right_padding {
  .el-input__inner {
    padding-right: 30px;
    height: 32px;
    line-height: 32px;
  }
  .suffix {
    width: 68px;
    text-align: right;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: #444;
    margin-right: 4px;
    line-height: 32px;
  }
}
.form-response-item {
  margin-top: -10px;
  /deep/ .el-input {
    width: 400px;
    input {
      height: 32px;
      line-height: 32px;
    }
  }
}
.panel-content {
  margin: 0 auto 20px;
  width: 1190px;
  padding: 20px 10px 0 10px;
  background: #f9f9f9;
}
.product-empty {
  padding: 80px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
.table-pagination {
  margin-bottom: 30px;
}
.table-thead-fixed {
  width: 100%;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 2;
  animation: showFixed 0.3s 1;
  top: 0;
  &.bg {
    background-color: transparent;
  }
  @keyframes showFixed {
    0% {
      top: -100px;
    }
    50% {
      top: -50px;
    }
    100% {
      top: 0;
    }
  }
  .inner-container {
    > div {
      position: relative;
      &.bg {
        background-color: #000;
      }
    }
  }
}
.search-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 14px;
  color: #888888;
  white-space: pre;
  &.fix-search-container {
    margin-top: 10px;
    color: #fff;
  }
  .left {
    width: 49%;
    align-items: center;
    display: flex;
    span {
      margin-right: 4px;
    }
    .el-input {
      width: calc(100% - 90px);
    }
  }
  .right {
    width: 45%;
    align-items: center;
    display: flex;
    justify-content: space-between;
    .btn-contaier {
      .el-button {
        padding: 6px 20px !important;
        font-size: 12px;
      }
    }
  }

  /deep/ .el-input__inner {
    height: 34px !important;
    line-height: 34px !important;
    padding: 0 8px !important;
  }
}
</style>

