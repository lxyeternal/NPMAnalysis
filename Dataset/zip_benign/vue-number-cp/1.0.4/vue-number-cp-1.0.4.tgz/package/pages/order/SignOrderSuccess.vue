<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <div class="app-search-bar isWhiteBg">
            <div class="search-bar-container inner-container" style="position: relative;">
                <div class="index-logo">
                    <div class="logo">
                        <h1>
                            <a @click="go('/home')" class="logo-bd"></a>
                        </h1>
                    </div>
                </div>
                <ViceHeader :flow="flow"></ViceHeader>
            </div>
        </div>
        <div class="inner-container" :style="{height:height,minHeight: '350px'}">
            <div class="content">
                <div class="icon-success"></div>
                <h3>合同签章成功！</h3>
                <p>您可以点击【查看合同】查看签署效果！</p>
                <div>
                    <el-button v-if="!brokerRole" size="large" type="primary" @click="handleView">查看合同</el-button>
                    <el-button v-else size="large" type="primary" @click="handleBrokerRoleView">查看合同</el-button>
                    <el-button size="large" @click="handleRequire">返回合同管理</el-button>
                </div>
            </div>

        </div>

        <Footer></Footer>
    </div>
</template>
<script>
import Header from "@/components/base/Header";
import ViceHeader from "@/components/base/ViceHeader";
import PanelTitle from "@/components/base/PanelTitle";
import Footer from "@/components/base/Footer";
import { InterfaceService } from "@/services/api";

export default {
    components: {
        Header,
        ViceHeader,
        Footer,
        PanelTitle
    },
    data() {
        return {
            flow: [
                {
                    name: "确认并签章合同",
                    active: false,
                    next: true
                },
                {
                    name: "合同签章成功",
                    active: true,
                    next: false
                }
            ],
            attachUrl: "",
            orderNo:"",
            order:[]
        };
    },
    computed: {
        height() {
            let h =
                window.innerHeight ||
                document.documentElement.clientHeight ||
                document.body.clientHeight;
            return h - 200 - 55 - 34 - 160 + "px";
        },
        role() {
            return this.$store.state.userInfo
                ? this.$store.state.userInfo.bs
                : 0;
        },
        brokerRole(){
            return this.$store.state.userInfo &&
                this.$store.state.userInfo.contractCorpType === "broker"
        }
    },
    methods: {
        handleView() {
            window.open(this.attachUrl, "_blank");
},
        handleBrokerRoleView(){
            delete this.order.orderList;
            this.$router.push({
                path: "/brokerSignPreview",
                query: {
                    orderNo: this.orderNo,
                    tab : "3"
                }
            });
        },
        handleRequire() {
            let path = "";
            if (this.role == "S") {
                path = "/vendorCenter/orderList";
            } else if (this.role == "B" && !this.brokerRole) {
                path = "/purchaserCenter/orderList";
            }else if (this.brokerRole){
                path = "/purchaserCenter/brokerSignList";
            }
            this.$router.push({
                path: path
            });
        },
        go(path) {
            this.$router.push({
                path: path
            });
        },
        getOrderDetail(){
            InterfaceService.getOrderDetail(
                {
                    orderNo:this.orderNo,
                    pageIndex:1,
                    sort:"0_0_0"
                },
                data => {
                    if (data.respData.respCode === "0000") {
                        this.order = data.respData;
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    },
    mounted() {
        this.attachUrl = this.$route.query.attachUrl;
        this.orderNo = this.$route.query.orderNo
            ? this.$route.query.orderNo
            : "";
        if (this.orderNo && this.brokerRole){
            this.getOrderDetail();
        }
    }
};
</script>
<style lang="scss" scoped>
/deep/ .el-button {
    width: 200px;
}

h3 {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 10px;
}
.content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;

    p {
        margin-bottom: 20px;
    }
}

.icon-success {
    width: 60px;
    height: 60px;
    margin: auto;
    margin-bottom: 20px;
    background: url(../../assets/images/green_yes.png) no-repeat;
    background-size: 100% 100%;
}
</style>

