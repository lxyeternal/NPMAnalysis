
<template>
  <div class="initiate-a-payment-wrap">
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" :is-border-bottom="true" :is-white-bg="true" :progress="`请款详情`"></SearchBar>
    <div class="inner-container">
      <!-- 合同流程 -->
      <OrderProcess v-if="flowList && flowList.length" :isApproval="true" :processList="flowList"></OrderProcess>

      <!-- 合同状态 -->
      <OrderStatusInfoComponent :order="baseInfo" :statusName="statusNameComputed" @refresh="getPlanDetail"></OrderStatusInfoComponent>

      <!-- 流转意见 -->
      <CirculateOpinionsComponent v-if=" role==='B' " :execFlowList="execFlowList"></CirculateOpinionsComponent>
      <div class="head-title">
        <span>请款基本信息</span>
      </div>
      <div class="row-container">
        <BaseInfoComponent :baseInfo="baseInfo"></BaseInfoComponent>
      </div>
      <template v-if="isShowContractPrice">
        <div class="left-border-title"> 合同价款 </div>
        <ul class="contract-price-container">
          <li>
            <span>合同价款(不含税)：</span>
            <span>{{baseInfo.other.orderAmount | formatMoney}}元</span>
          </li>
          <li>
            <span>税率：</span>
            <span>{{baseInfo.other.taxRate}}</span>
          </li>
          <li class="bold">
            <span> 合同价款(含税)：</span>
            <span class="red">{{baseInfo.other.outContractFeeWithTax | formatMoney}}元</span>
          </li>
          <li>
            <span>税额：</span>
            <span>{{baseInfo.other.taxTotal | formatMoney}}元</span>
          </li>
        </ul>
      </template>
      <template v-if="baseInfo.paymentMethod">
        <div class="left-border-title"> 付款方式 </div>
        <div class="payment-method" v-html="paymentMethodComputed"> </div>
      </template>
      <template>
        <div class="left-border-title"> {{role === "S" && '供应商' || ''}}请款申请金额 </div>
        <AskForMoneyComponent :isDetaill="true" :showRole="'S'" :prepaymentRatioValue="prepaymentRatioValue" :prepaymentAmountValue="prepaymentAmountValue" :baseInfo="baseInfo" :progressInfo="progressInfo" :formatShippingNoticeSelected="shippingNotice" :preProgressAmt="preProgressAmt | formatMoney"></AskForMoneyComponent>
      </template>
      <template v-if="approvedRequestAmount.show">
        <div class="left-border-title"> {{approvedRequestAmount.name}} </div>
        <AskForMoneyComponent :isDetaill="true" :showRole="'B'" :prepaymentRatioValue="advancePercent" :prepaymentAmountValue="payablesAmt" :baseInfo="baseInfo" :progressInfo="paymentCheckerItem" :formatShippingNoticeSelected="shippingNotice" :preProgressAmt="payablesAmt"></AskForMoneyComponent>
      </template>
      <template>
        <div class="left-border-title"> 收款账户信息 </div>
        <CollectionAccountComponent :bankAccountInfo="baseInfo.bankAcctInfo" v-if="baseInfo.bankAcctInfo"></CollectionAccountComponent>
      </template>
      <template v-if="billInfoList && billInfoList.length">
        <div class="left-border-title"> 请款资料 <span class="blue hand" @click="handleDownloadFile">下载所有资料</span></div>
        <RequestInformationComponent :billInfoList="billInfoList" :isView="true"> </RequestInformationComponent>
      </template>
    </div>
    <Loading :is-loading="isLoading"> </Loading>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api"
import accountMixin from "@/mixins/account"
import { NumberUtil } from '@/utils/numberUtil'
import Header from "@/components/base/Header"
import SearchBar from "@/components/SearchBar"
import OrderProcess from "@/components/order/OrderProcess";
import Loading from '@/components/base/Loading'
import BaseInfoComponent from "@/components/order/askForMoney/BaseInfoComponent";
import RequestInformationComponent from "@/components/order/askForMoney/RequestInformationComponent";
import CollectionAccountComponent from "@/components/order/askForMoney/CollectionAccountComponent";
import AskForMoneyComponent from "@/components/order/askForMoney/AskForMoneyComponent";
import OrderStatusInfoComponent from "@/components/order/askForMoney/OrderStatusInfoComponent";
import CirculateOpinionsComponent from "@/components/order/askForMoney/CirculateOpinionsComponent";
export default {
  mixins: [accountMixin],
  components: {
    Header,
    SearchBar,
    Loading,
    OrderProcess,
    BaseInfoComponent, // 请款基本信息
    RequestInformationComponent, // 请款资料
    CollectionAccountComponent, // 收款账户
    AskForMoneyComponent, // 请款金额
    OrderStatusInfoComponent, // 合同状态
    CirculateOpinionsComponent, // 流转意见
  },
  data() {
    return {
      isLoading: false,
      prepaymentRatioValue: '', // 预付比例
      collectionAccountValue: '',
      baseInfo: {}, // 基本信息
      preProgressAmt: '',
      progressInfo: {}, // 申请金额
      paymentCheckerItem: {}, // 成本部核定金额
      showHandleLink: false,
      requireme: [],
      shippingNoticeSelected: [],
      billInfoList: [],
      executionId: '',
      shippingNotice: '', // 发货通知单
      flowList: [],
      execFlowList: [], // 流转意见
    }
  },
  computed: {

    // 付款方式
    paymentMethodComputed() {
      // 先查询出 需要 插入 span 标签的条数
      let str = this.baseInfo.paymentMethod || ''
      try {
        const replaceArr = str.match(/\d*%/g) || []
        replaceArr.reverse && replaceArr.reverse().forEach(f => {
          // 从结尾开始找 数据出现位置
          const sIdx = str.lastIndexOf(f)
          // 如果已经替换过 则返回, 防止相同数据多次替换
          const sStr = str.slice(0, sIdx),
            eStr = str.slice(sIdx + f.length, str.length),
            // 改变数据%为≌
            percentStr = `${f.slice(0, f.length - 1)}$≌$`
          // 结束下标
          str = `${sStr}<span class="red">${percentStr}</span>${eStr}`

        })
        // 还原%
        str = str.replace(/\$\≌\$/g, '%')
      } catch (error) {
        console.error('tryCatch-paymentMethodComputed: ', error);
      }
      return str
    },

    // 是否显示合同价款
    isShowContractPrice() {
      const myTaskId = this.baseInfo && this.baseInfo.other && this.baseInfo.other.myTaskId

      return ['contract_op_confirm', 'contract_director_confirm', 'finance_director_confirm', 'general_manager_confirm', 'supplier_confirm'].includes(myTaskId)
    },
    // 采购商审核 - 预付金额
    payablesAmt() {
      const val = this.baseInfo && this.baseInfo.other && this.baseInfo.other.paymentCheckerItem && this.baseInfo.other.paymentCheckerItem.payablesAmt || ''
      console.log(this.baseInfo.other.paymentCheckerItem.payablesAmt, '- this.baseInfo.other.paymentCheckerItem.payablesAmt');

      return this.$options.filters.formatMoney(val)
    },
    //采购商审核 - 预付比例
    advancePercent() {
      return this.baseInfo && this.baseInfo.other && this.baseInfo.other.paymentCheckerItem && NumberUtil.accMul(this.baseInfo.other.paymentCheckerItem.advancePercent, 100) || ''
    },
    // 核定请款金额
    approvedRequestAmount() {
      let item = { name: '', show: false }

      if (this.baseInfo && this.baseInfo.other && this.baseInfo.other.paymentCheckerItem && this.baseInfo.other.paymentCheckerItem.payablesAmt) {
        item.name = `${this.role === 'B' ? '成本部' : '采购商'}核定请款金额`
        item.show = true
        // BUG #6433 鉴证意见弹窗"待请款签证审核流程全部结束后，有平台统一电子签章" => "待请款流程全部结束后，由平台统一电子签章"
        // 3.请款详情页面，预付款的时候，不要出现“采购商核定请款金额”部分
        if (this.role === 'S' && this.baseInfo.paymentType !== 'progress') {
          item.show = false
        }
      }

      return item || {}
    },

    // 合同状态名称
    statusNameComputed() {
      const item = this.flowList.filter(f => f.isCurrentNode == '1')[0] || {}
      return item.flowName || ''
    },

    // 预付金额：
    prepaymentAmountValue() {
      const value = this.$options.filters['formatMoney'](this.baseInfo.outContractFeeWithTax * this.prepaymentRatioValue / 100)
      return (value == '0.00' || !value) ? '' : value
    },
  },
  mounted() {
    this.init()
  },
  methods: {
    async init() {
      this.baseInfo.paymentNo = this.$route.query.paymentNo || ''
      this.executionId = this.$route.query.executionId || ''
      await this.getPlanDetail()
    },

    /**
     * 下载所有资料
     */

    handleDownloadFile() {
      this.paymentDetailDownloadAll()
    },

    /**
     * 打包下载
     */
    paymentDetailDownloadAll() {
      return new Promise(resolve => {
        let params = { //给予后端的入参
          paymentNo: this.baseInfo.paymentNo,
        }
        InterfaceService.paymentDetailDownloadAll(params, data => {
          if (data.respData.respCode === '0000') {
            this.$download([{
              name: data.respData && data.respData.fileName || '全部资料',
              url: data.respData && data.respData.fileUrl
            }])
          }
        }, data => { }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      })
    },

    /**
     * 初始化 请款资料 附件数组
     */
    initBillInfoList() {
      this.billInfoList = []
      this.billInfoList.push({
        name: '发货通知单',
        receiptType: 'require',
        list: [],
        require: true
      })

      this.billInfoList.push({
        name: '工地验收单',
        receiptType: 'delivery',
        list: [],
        require: true
      })

      // 施工监理 不显示

      this.billInfoList.push({
        name: '应付对账单',
        receiptType: 'supplier_statement',
        list: [],
        require: true
      })

      this.billInfoList.push({
        name: '应收对账单',
        receiptType: 'purchaser_statement',
        list: [],
        require: true
      })

      // progress:施工进度附件
      this.billInfoList.push({
        name: '施工进度附件',
        receiptType: 'progress',
        list: [],
        require: true
      })

      this.billInfoList.push({
        name: '其他附件',
        receiptType: 'others',
        list: [],
      })

      this.billInfoList.push({
        name: '外部附件',
        receiptType: 'pmtReportSupplier_pdf',
        list: [],
      })

      this.billInfoList.push({
        name: '内部附件',
        receiptType: 'pmtReportBroker_pdf',
        list: [],
      })
      this.billInfoList.push({
        name: '外部附件-产值报告',
        receiptType: 'outputValueSupplier_pdf',
        list: [],
      })
      this.billInfoList.push({
        name: '内部附件-产值报告',
        receiptType: 'outputValueBroker_pdf',
        list: [],
      })

      //  第三方上传
      this.billInfoList.push({
        name: '第三方咨询单位付款估值协议',
        receiptType: 'assessment_Recommendations',
        list: [],
      })

    },

    /**
     * 详情 - 数据反显
     */
    getPlanDetail() { //获取页面初始化数据
      return new Promise(resolve => {
        let params = { //给予后端的入参
          paymentNo: this.baseInfo.paymentNo,
          executionId: this.executionId
        }
        InterfaceService.getPaymentDetail(params, data => {
          if (data.respData.respCode === '0000') {
            try {
              const { advanceInfo, preProgressInfo, progressInfo, paymentCheckerList, receiptsList, ...other } = data.respData
              this.flowList = other.flowList || []
              this.execFlowList = other.execFlowList
              // 格式化流转意见

              this.execFlowList.forEach(f => {
                // 发起 不显示 原因
                if (f.taskId === 'supplier_apply') {
                  f.comment = ''
                }
                if (!f.comment) return
                let fistStr = '<p>请款报告审批意见：</p>',
                  lastStr = '<p>产值报表审批意见：</p>'

                f.comment = f.comment.replace('请款报告审批意见:', fistStr)
                f.comment = f.comment.replace('产值报表审批意见:', lastStr)

              })
              // todo  mock 退回 显示附件
              // other.oneselfReceiptsList =
              // console.log(other, '---oneselfReceiptsList');
              // other.oneselfReceiptsList = [...receiptsList]
              this.baseInfo = {
                askForReasonsValue: other.paymentTypeName,
                paymentType: other.paymentType,
                paymentNo: other.paymentNo,
                orderNo: other.orderNo,
                contractName: other.contractName,
                paymentMethod: other.paymentMethod,
                orderAmountWithTax: other.orderAmountWithTax,
                outContractFeeWithTax: other.outContractFeeWithTax,
                purchaserName: other.purchaserName,
                bankAcctInfo: other.tdOrderBankAcctInfo,
                datePickerValueStart: progressInfo && progressInfo.fromDt || '',
                datePickerValueEnd: progressInfo && progressInfo.toDt || '',
                orderCateCode: other.orderCateCode,
                other: other,
                preProgressInfo: preProgressInfo,
                advanceInfo: advanceInfo,
                receiptsList: receiptsList || []
              }


              // 数据反显
              if (advanceInfo) {
                // 合同 - 预付款 - 预付比例
                this.prepaymentRatioValue = NumberUtil.accMul(advanceInfo.advancePercent, 100) || ''
              }

              if (preProgressInfo) {
                // 材料进场 - 预付金额
                this.preProgressAmt = preProgressInfo.preProgressAmt || ''
              }

              // 进度款 - 请款金额/工作进度
              if (progressInfo) {
                this.progressInfo = progressInfo
              }

              // 成本部核定金额
              if (paymentCheckerList && paymentCheckerList.length) {
                const paymentCheckerItemList = paymentCheckerList.filter(f => !!f.payablesAmt && f.payablesAmt != 0) || []
                // 取最新一条
                this.paymentCheckerItem = paymentCheckerItemList[paymentCheckerItemList.length - 1] || {}
                this.baseInfo.other.paymentCheckerItem = this.paymentCheckerItem
              }

              // 如果有上传文件 才继续
              if (receiptsList && receiptsList.length) {
                this.initBillInfoList()

                // 上传文件反显 - 请款材料
                this.billInfoList.forEach(f => {
                  f.list = []
                  receiptsList.map(m => {
                    if (f.receiptType === m.receiptType) {
                      f.list.push(m)
                    }
                  })
                })


                // 因为 在请款资料 重复 显示 所以注释掉
                // 上传文件反显 - 第三方
                // if (other.oneselfReceiptsList && other.oneselfReceiptsList.length) {
                //   this.billInfoList.forEach(f => {
                //     !f.list && (f.list = [])
                //     other.oneselfReceiptsList.map(m => {
                //       if (f.receiptType === m.receiptType) {
                //         f.list.push(m)
                //       }
                //     })
                //   })
                // }


                // 上传文件反显 - 上报完成进度及工作量
                this.completeScheduleFiles = []
                this.shippingNotice = ''
                receiptsList.map(m => {
                  if (m.receiptType == 'progress') {
                    this.completeScheduleFiles.push(m)
                  }
                  if (m.requireBatchNo) {
                    this.shippingNotice += `${m.receiptFileName}、`
                  }
                })
                this.shippingNotice = this.shippingNotice.slice(0, this.shippingNotice.length - 1)
              }
            } catch (error) { console.log(error) }
          }

          resolve(true)

        }, data => { }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      })
    },
  }
};
</script>

<style lang="scss" scoped>
.initiate-a-payment-wrap {
  padding-bottom: 140px;
  .mt40 {
    margin-top: 40px;
  }
  .head-title {
    height: 50px;
    line-height: 50px;
    position: relative;
    border-bottom: 2px solid #ffd64e;
    background-color: #f5f5f5;
    color: #4f525a;
    span {
      position: absolute;
      padding: 0 24px;
      left: 0;
      border-bottom: 2px solid #444;
      font-size: 14px;
      font-weight: bold;
      height: 50px;
      &.blue {
        right: 0;
        cursor: pointer;
        left: auto;
        border-bottom: 0;
      }
    }
  }
  .row-container {
    margin: 12px 0;
    .el-row {
      margin-top: 12px;
    }
    .title {
      color: #888;
      &.black {
        color: #000;
      }
    }
    .blue {
      cursor: pointer;
    }
    &.row-flex-item-align-center {
      .el-row {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        [class*="el-col-"] {
          margin-top: 8px;
        }
        /deep/ .el-icon-percentage {
          &::before {
            content: "%";
            color: #000;
          }
        }
        /deep/ .el-icon-yuan {
          &::before {
            content: "元";
            color: #000;
          }
        }
      }
    }
    .account-tips {
      text-align: center;
      p {
        text-align: left;
        margin-bottom: 20px;
      }
    }
    .account-center {
      .account-specific-information {
        margin-top: 22px;
        border-top: 1px dashed #ccc;
        [class*="el-col-"] {
          margin-top: 12px;
        }
      }
    }
  }
  .left-border-title {
    padding: 20px 14px 12px 12px;
    position: relative;
    margin-top: 20px;
    border-top: 1px solid #eee;
    font-size: 14px;
    &::after {
      content: "";
      border-left: 4px solid #333;
      position: absolute;
      left: 0;
      top: 20px;
      height: 14px;
    }
  }
  .payment-method {
    line-height: 20px;
  }
}
.contract-price-container {
  display: flex;
  flex-wrap: wrap;
  li {
    width: 50%;
    margin-top: 12px;
  }
}
</style>
