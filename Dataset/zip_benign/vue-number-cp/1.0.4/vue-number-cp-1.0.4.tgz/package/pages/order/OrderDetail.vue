<template>
  <div>
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" :progress="'合同详情'" :is-border-bottom="true" :product-create-process="2"></SearchBar>
    <div class="inner-container">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
      <!-- 合同流程 -->
      <!--<OrderProcess v-if="orderInfo.orderFlowList" :orderStatus="orderInfo.orderStatus" :processList="orderInfo.orderFlowList"></OrderProcess>-->
      <div class="steps-cont">
        <Steps v-if="orderInfo.busiType != 'ONEWAY_ORDER'" :tenderList="flowList" :active="activeNode" :space="orderInfo.manufacturerCorpId ? 198 : 238"></Steps>
        <Steps v-else :tenderList="flowList" :active="activeNode" :space="orderInfo.manufacturerCorpId ? 297 : 396"></Steps>
      </div>
      <!-- 合同状态 -->
      <TransferOpinions v-if="oAOperFlow.length" :execFlowList="oAOperFlow" :isOA="true"></TransferOpinions>
      <TransferOpinions v-if="orderOperFlow.length" :execFlowList="orderOperFlow" :isOA="false" :terminateType="orderInfo.terminateType"></TransferOpinions>
      <template v-if="role == 'S' || orderInfo.busiType === 'ONEWAY_ORDER'">
        <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>
      </template>
      <template v-else>
        <PanelTitle :tabs="outTabs" @select="handleChangeOutTab"></PanelTitle>
        <div class="tab-change">
          <ul>
            <li :class="{active:tabIndex == 0}" @click="tabIndex = 0">
              <span>基本信息</span>
            </li>
            <li :class="{active:tabIndex == 1}" @click="tabIndex = 1">
              <span>商品清单</span>
            </li>
            <li v-if="replenishContractInfo.relContractList && replenishContractInfo.relContractList.length" :class="{active:tabIndex == 2}" @click="tabIndex = 2">
              <span>补充合同</span>
            </li>
            <!-- showDetailSettle -->
            <li :class="{active:tabIndex == 3}" v-if="settleNo" @click="tabIndex = 3">
              <span>结算单</span>
            </li>
            <li :class="{active:tabIndex == 4}" @click="tabIndex = 4">
              <span v-if="outTypeIndex == 0">付款记录</span>
              <span v-else>收款记录</span>
            </li>
          </ul>
        </div>
      </template>
      <div v-if="tabIndex==0">
        <!-- 合同信息 -->
        <p style="margin-bottom:20px"></p>
        <OrderInfo v-if="orderInfo" :tab="outTypeIndex" :orderNo="orderNo" :orderInfo="orderInfo" :bankAcctInfoList="orderInfo.orderBankAcctInfo" @refresh="handleRefreshStatus"></OrderInfo>
      </div>
      <!-- 商品清单 -->
      <ProductList v-if="tabIndex==1" :orderNo="orderNo" :divisionContract="role == 'B' && outTypeIndex == '1'" :addRate="orderInfo.addRate" :otherMoneyDesc="orderInfo.otherMoneyDesc"></ProductList>
      <!-- 补充合同 -->
      <SupplementaryProductList style="margin-top: -10px" v-if="tabIndex == 2" :divisionContract="role == 'B' && outTypeIndex == '1'" ref="supplementaryProductList" :replenishContractInfo="replenishContractInfo" :orderInfo="orderInfo" @handleOperation="handleOperation" :tab="outTypeIndex"></SupplementaryProductList>

      <!-- 结算单 -->
      <DetaillSettlementComponent v-if="tabIndex==3" ref="detaillSettlementComponentRef" :order="orderInfo" :outTypeIndex="outTypeIndex" @emitData="settlementEmitData"></DetaillSettlementComponent>
      
      <!-- 收款或付款记录 -->
      <ReceivePayRecord v-if="tabIndex==4" ref="receivePayRecord" :handleType="role == 'S' ? '0' : String(outTypeIndex)" :orderNo="orderNo"></ReceivePayRecord>

      <!-- 采购商确认合同 -->
      <ConfirmContract v-if="role == 'B'" :orderNo="orderNo" :verifyCorpId="orderInfo.purchaserId" :inPmtMethod="orderInfo && orderInfo.inPmtMethod || ''" ref="confirmContract" @upDate="getOrderDetail"></ConfirmContract>
      <Loading :is-loading="isLoading"></Loading>
    </div>
    <el-dialog class="dialog" custom-class="reject-dialog" :title="`退回${subOrderNo ? '补充合同' : settleNo? '结算申请' : ''}原因`" :append-to-body="true" :lock-scroll="true" :visible.sync="rejectDialogVisible" width="840px" center :close-on-click-modal="false" @close="rejectForm.refuseReason = ''">
      <div>
        <el-form :model="rejectForm" ref="rejectForm" label-width="94px">
          <el-form-item label="退回原因：" prop="refuseReason" :rules="{required: true,message:'请填写退回原因'}">
            <el-input type="textarea" class="resize-none" v-model="rejectForm.refuseReason" rows="4" maxlength="200" show-word-limit placeholder="请输入..."></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" :disabled="!rejectForm.refuseReason.trim()" @click="handleRejcet">确认退回</el-button>
        <el-button class="normal-btn" @click="rejectDialogVisible = false;subOrderNo = ''">取消</el-button>
      </div>
    </el-dialog>
    <template v-if="role == 'S'">
      <template v-if="!isAgent">
        <FixBottom v-if="orderInfo.orderStatus == '07'">
          <div class="tc">
            <el-button type="primary" style="width: 120px;" @click="handleConfirmS('')">通过</el-button>
            <el-button style="width: 120px;" @click="returnContract">退回</el-button>
          </div>
        </FixBottom>
      </template>

      <!-- 合同结算 - 厂家 -->
      <FixBottom v-if="['1'].includes(settleStatus) && !isAgent">
        <div class="tc">
          <el-button type="primary" style="width: 120px;" @click="handleConfirmS('settlement')">通过</el-button>
          <el-button style="width: 120px;" @click="returnContract()">退回</el-button>
        </div>
      </FixBottom>

      <FixBottom v-if="userinfo.corpId === orderInfo.supplierId && (orderInfo.orderStatus == '04' || orderInfo.orderStatus == '06')">
        <div class="tc">
          <el-button type="primary" style="width: 120px;" @click="handleEditOrder">编辑合同</el-button>
          <el-button style="width: 120px;" @click="handleCloseOrder">关闭合同</el-button>
        </div>
      </FixBottom>
    </template>
    <template v-else>
      <!-- 合同结算 - 采购商 -->
      <FixBottom v-if="['5', '7'].includes(settleStatus) && settleType == '0'">
        <div class="tc">
          <el-button type="primary" style="width: 120px;" @click="handleConfirmSettlement">确认结算</el-button>
          <el-button style="width: 120px;" @click="returnContract">退回结算申请</el-button>
        </div>
      </FixBottom>

      <template v-if="!brokerRole">
        <FixBottom v-if="orderInfo.orderStatus == '03'">
          <div class="tc" v-if="!orderInfo.dataIsIntact">
            <el-button type="primary" style="width: 120px;" @click="handleConfirmB('', true)">确认合同</el-button>
            <el-button style="width: 120px;" @click="$refs['rejectOrder'].open(orderInfo)">拒绝合同</el-button>
          </div>
          <div class="tc" v-else>
            <el-button type="primary" style="width: 120px;" @click="handleOAapproval">提交OA审批</el-button>
            <!-- <el-button style="width: 120px;" @click="handleDownloadContract">下载合同模板</el-button> -->
            <el-button style="width: 120px;" @click="handleConfirmB">上一步</el-button>
            <el-button style="width: 120px;" @click="$refs['rejectOrder'].open(orderInfo)">拒绝合同</el-button>
          </div>
        </FixBottom>
        <FixBottom v-if="orderInfo.orderStatus == '05' && (approveStatus === '4' || approveStatus === '2')">
          <div class="tc">
            <el-button type="primary" style="width: 120px;" @click="handleOAapproval">重新提交审核</el-button>
            <el-button type="primary" style="width: 120px;" @click="$refs['rejectOrder'].open(orderInfo)">拒绝合同</el-button>
            <!-- <el-button style="width: 120px;" @click="handleDownloadContract">下载合同模板</el-button> -->
            <el-button style="width: 120px;" @click="handleConfirmB">上一步</el-button>
          </div>
        </FixBottom>
      </template>
    </template>
    <template v-if="signFlag">
      <FixBottom>
        <div class="tc">
          <el-button type="primary" @click="handleSign()">电子签章</el-button>
          <el-button @click="handleCancel">取消</el-button>
        </div>
      </FixBottom>
    </template>
    <!-- 合同号结算 -->
    <template v-if="isShowSettleSinge && ['4'].includes(settleStatus) && settleType == '0'">
      <FixBottom>
        <div class="tc">
          <el-button type="primary" @click="handleSign('settle')">电子签章</el-button>
        </div>
      </FixBottom>
    </template>

    <!-- 拒绝合同 -->
    <RejectOrder ref="rejectOrder" @close="handleRefresh"></RejectOrder>
    <OrderListOperate :order="orderInfo" ref="OrderListOperate" @refresh="handleRefresh"></OrderListOperate>

    <!--确认结算 -->
    <el-dialog class="dialog bulk-fill-price-container" :title="'确认结算'" :append-to-body="true" :lock-scroll="true" :visible.sync="confirmSettleMentDialog" width="850px" center :close-on-click-modal="false">
      <div class="container">
        <div class="center">
          请再次确认本结算单相关信息及<span class="red">供货合同结算清单附件</span>上传是否有遗漏，确认无误。点击【确认提交OA审核】按钮即可。
        </div>
        <div class="btn-center">
          <el-button size="small" type="primary" style="width: 120px" @click="handleClickConfirmOa">确认提交OA审核</el-button>
          <!-- 点击「上传供货合同结算清单」跳转至事业部合同sheet-结算单sheet对应的结算清单区域。 -->
          <el-button size="small" style="width: 160px" @click="handleClickUploadSettlement">上传供货合同结算清单</el-button>
          <el-button size="small" style="width: 120px" @click="confirmSettleMentDialog = false">取消</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>

import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import PageNav from "@/components/order/PageNav";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import OrderStatusInfo from "@/components/order/OrderStatusInfo";
import OrderInfo from "@/components/order/OrderInfo";
import RequireOrderTable from "@/components/order/RequireOrderTable";
import OrderProcess from "@/components/order/OrderProcess";
import PaymentMethod from '@/components/order/PaymentMethod'
import TransferOpinions from '@/components/order/TransferOpinions'
import ConfirmContract from '@/components/order/dialog/ConfirmContract'
import ProductList from '@/components/order/ProductList'

import { InterfaceService } from "@/services/api";
import accountMixin from "@/mixins/account";
import ConfluenceFloat from '@/components/base/ConfluenceFloat'

import { NumberUtil } from '@/utils/numberUtil';
import Breadcrumb from "@/components/base/Breadcrumb";
import Steps from "@/components/base/steps";
import FixBottom from "@/components/base/FixBottom";
import RejectOrder from "@/components/order/dialog/orderOperate/RejectOrder";
import OrderListOperate from "@/components/order/OrderListOperate";
import DetaillSettlementComponent from "@/components/settlement/DetaillSettlementComponent";
import SupplementaryProductList from "@/components/order/supplementaryContract/SupplementaryProductList";
import ReceivePayRecord from '@/components/order/ReceivePayRecord'
export default {
  mixins: [accountMixin],
  components: {
    Header,
    SearchBar,
    PageNav,
    Loading,
    PanelTitle,
    OrderStatusInfo,
    OrderInfo,
    RequireOrderTable,
    OrderProcess,
    PaymentMethod,
    Breadcrumb,
    TransferOpinions,
    ConfluenceFloat,
    ConfirmContract,
    Steps,
    ProductList,
    FixBottom,
    RejectOrder,
    OrderListOperate,
    DetaillSettlementComponent,
    SupplementaryProductList,
    ReceivePayRecord
  },
  data() {
    return {
      tabs: [
        { label: "基本信息", listType: 0, active: true },
        { label: "商品清单", listType: 1 }
      ],
      outTabs: [
        { label: "材料合同", outType: 0, active: true },
        { label: "事业部合同", outType: 1 },
      ],
      breadcrumb: [],
      flowList: [],
      rejectForm: {
        refuseReason: ""
      },
      isLoading: false,
      rejectDialogVisible: false,
      orderNo: "",
      activeNode: 0,
      brokerCorpId: "",
      signFlag: false, // 合同签章是否置灰
      status: "",
      orderInfo: {},
      orderList: [],
      orderOperFlow: [],
      oAOperFlow: [],
      orderSortList: [0, 0, 0],
      sortList: [0, 2, 0],
      pageSize: 10,
      total: 0,
      orderPageIndex: 1,
      pmtMethod: '', // 付款方式描述
      tabIndex: 0, // tab 切换下标
      outTypeIndex: 0, // 采购商tab 切换下标

      approvalInfo: {},
      attachList: [],
      htqdgcljssList: [],
      zjfjList: [],
      isResubmit: false,
      approveId: '',

      confirmSettleMentDialog: false,

      replenishContractInfo: {},
      subOrderNo: '',

      // 合同结算
      settleStatus: '',
      settleNo: '',
      settleType: '',
    };
  },
  watch: {
    tabIndex() {
    }
  },
  computed: {
    // 判断当前登录用户是是否有签章事件
    isShowSettleSinge() {
      // 如果采购商 非材料公司 材料合同不显示电子签章
      const isDivision = (this.role == 'B' && !this.brokerRole) ? this.outTypeIndex == 1 : true
      return isDivision && this.orderInfo && this.orderInfo.eventList && this.orderInfo.eventList.some(s => {
        if (s.eventType == 5) {
          // 供应商 取登录人 acctId  采购商去acctIdList
          const acctId = this.role == 'B' ? this.mxAcctIdList : this.acctId
          return s.processList && s.processList.some(s1 => acctId.includes(s1.acctId) && s1.processFlg == 0)
        }
      })
    },
    showDetailSettle() {
      // 3 结算申请已退回
      return !['3'].includes(this.settleStatus)
    },
    // oaApprovalFailFlg() {
    //   let bool = ''
    //   let oaApprovalInfo = this.orderInfo.externalSysList && this.orderInfo.externalSysList.find(i => { return i.sysCode === 'OA' }) || {};
    //   bool = oaApprovalInfo.approveStatus === '4'
    //   return bool
    // },

    userInfo() {
      return this.$store.state.userInfo || {};
    },
    approveStatus() {
      let status = ''
      let oaApprovalInfo = this.orderInfo.externalSysList && this.orderInfo.externalSysList.find(i => { return i.sysCode === 'OA' }) || {};
      status = oaApprovalInfo.approveStatus
      // console.log(status);
      return status
    },
  },
  methods: {
    handleCancel() {
      // window.opener = null;
      // window.close();
      this.$router.go(-1)
    },

    settlementEmitData(data) {
      this.settleStatus = data && data.orderBaseBean && data.orderBaseBean.settleStatus || ''
      this.settleType = data && data.orderBaseBean && data.orderBaseBean.settleType || ''
    },

    handleOperation(list) {
      // console.log(list)
      if (list[0] === '1') {
        this.$refs['OrderListOperate'].handleSupplementOrder(list[0], { subOrderNo: list[1] })
      } else if (['2', '3', '4'].includes(list[0])) {
        this.$refs['OrderListOperate'].handleDel(list[0], this.orderInfo, list[1])
      } else if (list[0] === '5') {//厂家审核
        this.getOrderDetail();
      } else if (list[0] === '6') { // 厂家退回合同
        this.subOrderNo = list[1]
        this.returnContract()
      } else if (list[0] === '7') { // 采购商退回合同
        this.$refs['rejectOrder'].open(this.orderInfo, list[1])
      } else if (list[0] === '8') { // 采购商提交OA审核
        this.getOrderDetail()
      } else {
        this.getOrderDetail()
      }
    },
    returnContract() {
      this.rejectDialogVisible = true
      this.$refs['rejectForm'] && this.$refs['rejectForm'].clearValidate(['refuseReason']);
    },
    handleOAapproval() {
      // this.$router.push({
      //   path: "/oAapproval",
      //   query: {
      //     orderNo: this.orderInfo.orderNo,
      //     sybOrderNo: this.orderInfo.sybOrderNo,
      //     clOrderNo: this.orderInfo.clOrderNo,
      //     contractName: this.orderInfo.contractName,
      //     approveStatus: this.orderInfo.externalSysList && this.orderInfo.externalSysList.length ? this.orderInfo.externalSysList[0].approveStatus : '',
      //   }
      // })
      this.isResubmit = (this.approveStatus == '2' || this.approveStatus == '4') ? true : false
      this.$confirm(
        `确认${this.isResubmit ? '重新' : ''}提交OA审批吗？确认请点击【确认提交】`,
        `OA审批`,
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: `确认${this.isResubmit ? '重新' : ''}提交`,
          cancelButtonText: '取消',
        }).then(() => {
          this.getOAapprovalDetail()
        }).catch(() => {
        });
    },
    getOAapprovalDetail() {
      const params = {
        orderNo: this.orderNo
      };
      InterfaceService.getOAapprovalDetail(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          this.approveId = res.approveId || ''
          this.approvalInfo = res.askOaBussinessData || {}
          // const sybOrderNo = this.$route.query.sybOrderNo || ''
          // const clOrderNo = this.$route.query.clOrderNo || ''
          // const contractName = this.$route.query.contractName || ''
          const sybOrderNo = this.orderInfo.sybOrderNo || ''
          const clOrderNo = this.orderInfo.clOrderNo || ''
          const contractName = this.orderInfo.contractName || ''
          this.approvalInfo.approveTitle = this.approvalInfo.approveTitle || (sybOrderNo + (sybOrderNo ? '/' : '') + clOrderNo + '《' + contractName + '》')
          this.approvalInfo.sqdh = this.approvalInfo.sqdh || (sybOrderNo + (sybOrderNo ? '/' : '') + clOrderNo)

          this.approvalInfo.signature = this.approvalInfo.zqzyj || ''
          this.approvalInfo.zjjcd = this.approvalInfo.zjjcd || '0'
          this.attachList = res.attachList || []
          this.htqdgcljssList = []
          this.zjfjList = []

          const htqdgcljssList = this.fileFilter('htqdgcljss')
          this.handleFileData(htqdgcljssList, this.htqdgcljssList)
          const zjfjList = this.fileFilter('zjfjList')
          this.handleFileData(zjfjList, this.zjfjList)

          const toDay = (new Date()).getTime()
          this.approvalInfo.sqrq = this.$formatTime(toDay, 'yyyymmdd')
          this.$forceUpdate()

          if (!this.approvalInfo.sqr) {
            this.$confirm(
              '您还没有绑定集团OA账号，请先去绑定！',
              this.rejectBtn,
              {
                cancelButtonClass: "btn-custom-cancel",
                confirmButtonClass: "btn-custom-confirm",
                center: true,
                dangerouslyUseHTMLString: true,
                confirmButtonText: '去绑定',
                cancelButtonText: '取消',
              }).then(() => {
                this.supplierOaApprove('save', 'bind')
              }).catch(() => {
              });
          } else {
            this.supplierOaApprove('save', 'submit')
          }
        } else {
          this.$message.error(res.respMsg);
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    fileFilter(documentType) {
      return this.attachList.filter(i => i.documentType == documentType)
    },
    supplierOaApprove(operType, type = '') {
      const approveAcctName = this.$store.state.userInfo.acctName || ''
      const approveAttachInfos = this.htqdgcljssList.concat(this.zjfjList)
      // return console.log(type)
      const params = {
        approveId: this.approveId,
        requestLevel: this.approvalInfo.zjjcd || '',
        mobile: this.approvalInfo.zsqrsj || '',
        purchasingManagerName: this.approvalInfo.sybcgjl || '',
        purchasingManagerId: this.approvalInfo.purchasingManagerId || '',
        operType: operType === 'submit' ? (this.isResubmit ? 'resubmit' : 'submit') : operType,
        orderNo: this.orderNo,
        projectEndDt: this.approvalInfo.jgrq,
        approveTitle: this.approvalInfo.approveTitle,
        engineeringAmount: this.approvalInfo.gcl,
        approveNo: this.approvalInfo.sqdh,
        signature: this.approvalInfo.signature,
        approveAcctName: approveAcctName,
        sysCode: this.approvalInfo.sysCode,
        approveType: '1',
        approveAttachInfos: approveAttachInfos
      };

      InterfaceService.supplierOaApprove(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          if (operType == 'save' && type == 'bind') {
            return this.$router.push({ path: '/purchaserCenter/accountInfo' })
          }
          if (type != 'submit') {
            this.$message.success('操作成功')
          }
          if (operType == 'save') {
            type != 'submit' ? this.getOAapprovalDetail() : this.supplierOaApprove('submit')
          } else {
            this.pushOrder()
          }
        } else {
          this.$message.error(res.respMsg);
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    pushOrder() {
      const params = {
        orderNo: this.orderNo,
        operType: 'submit',
      };
      InterfaceService.pushOrder(
        params,
        data => {
          if (data.respData.respCode == "0000") {
            this.$message.success('提交成功')
            // this.$setRootScope('orderListTab', '2')
            // if (this.orderInfo.busiType == 'ONEWAY_ORDER') {
            //   this.$router.push({
            //     path: '/purchaserCenter/orderList',
            //     query: {
            //       busiType: 'ONEWAY_ORDER'
            //     }
            //   })
            // } else {
            //   this.$router.push({
            //     path: '/purchaserCenter/orderList',
            //   })
            // }

            this.getOrderDetail()
            window.opener && window.opener.location.reload();

          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false });
    },
    handleFileData(dataList, list) {
      dataList.forEach(i => {
        list.push({
          attachType: i.documentType,
          attachPath: i.attachPath,
          attachName: i.documentName,
          attachUrl: i.attachUrl,
        })
      })
    },
    handleSign(orderType) {

      if (this.brokerRole) {
        this.$router.push({
          path: "/brokerSignPreview",
          query: {
            orderNo: this.orderInfo.orderNo,
            tab: '1',
            orderType: orderType || "contract",
            settleNo: this.settleNo || ''
          }
        })
      } else {
        this.$router.push({
          path: "/contractSign",
          query: {
            orderNo: this.orderInfo.orderNo,
            orderType: orderType || "contract",
            settleNo: this.settleNo || ''
          }
        })
      }
    },
    handleEditOrder() {
      this.$refs['OrderListOperate'].handleDraftOfCreateOrder(this.orderInfo);
    },
    handleCloseOrder() {
      this.$refs['OrderListOperate'].handleDel('4', this.orderInfo);
    },
    handleConfirmSettlement() {
      this.confirmSettleMentDialog = true
    },
    async handleClickConfirmOa() {
      // 重新提交 需要 查询 userInfo  再提交
      if (this.settleStatus == '5') {
        this.accountInfo()
        return
      }
      this.launchOaExaminationStatementSingle()
    },

    handleClickUploadSettlement() {
      this.outTypeIndex = 1
      this.confirmSettleMentDialog = false
      this.outTabs.forEach(f => f.active = f.outType == this.outTypeIndex)
      this.handleClickScrollBottom()
    },

    // 滚动底部
    handleClickScrollBottom() {
      const scrollTop = document.documentElement.scrollHeight || document.body.scrollHeight || 0
      let top = 0,
        timer = null
      timer = setInterval(() => {
        if (top >= scrollTop) {
          clearInterval(timer)
        }
        top += 200
        document.body.scrollTop = top
        document.documentElement.scrollTop = top
      }, 30);
    },

    // 下载合同模板
    handleDownloadContract() {
      const params = {
        orderNo: this.orderNo,
        bs: this.role === 'S' ? 'S' : "",
        documentVersion: "",
        fileFrom: "userUpload,systemCreate",
        documentTypeList: []
      };
      InterfaceService.getContractInfo(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          // console.log(res);
          let list = [];
          let documentInfos = res.documentInfos || [];
          let attachListB = [];
          let attachListS = [];
          let hasPdf = documentInfos.some(item => {
            return item.documentType === 'dt_10_contract_profession' || item.documentType === 'dt_00_contract_profession'
          });
          documentInfos.forEach(file => {
            if (hasPdf) {
              if (file.documentType === 'dt_10_contract_profession' || file.documentType === 'dt_00_contract_profession' || file.documentType === 'otherFile') {
                list.push(file)
              }
            } else {
              list.push(file)
            }
          });
          list.forEach(item => {
            if (item.bs === 'S') {
              let onOff = false;
              attachListS.forEach(_item => {
                if (item.documentId == _item.documentId) {
                  onOff = true
                }
              });
              if (!onOff) {
                attachListS.push(item)
              }
            } else if (item.bs === 'B') {
              let onOff = false;
              attachListB.forEach(_item => {
                if (item.documentId == _item.documentId) {
                  onOff = true
                }
              });
              if (!onOff) {
                attachListB.push(item)
              }
            } else {
              let onOffB = false;
              let onOffS = false;
              attachListB.forEach(_item => {
                if (item.documentId == _item.documentId) {
                  onOffB = true
                }
              });
              attachListS.forEach(_item => {
                if (item.documentId == _item.documentId) {
                  onOffS = true
                }
              });
              if (!onOffB) {
                attachListB.push(item)
              }
              if (!onOffS) {
                attachListS.push(item)
              }
            }
          });
          if (this.role === 'S') {
            this.handleBatchDownload(attachListS)
          } else {
            this.handleBatchDownload(attachListS, attachListB)
          }
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false });
    },
    handleBatchDownload(attachList1, attachList2) {
      let fileInfoBeans = [];
      if (attachList1.length) {
        attachList1.forEach((item, index) => {
          fileInfoBeans.push({
            archivePath: item.documentName,
            fileUrl: item.attachUrl,
          })
        })
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl;
            // const contractNameCount = '绿地集团' + (this.orderInfo.groupCompanyName || '') + this.orderInfo.projectName + (this.orderInfo.projectTerm ? this.orderInfo.projectTerm : 'XX') + '期' + (this.orderInfo.building ? this.orderInfo.building : 'XX') + '标段' + this.orderInfo.categoryName + '采购合同'
            const contractNameCount = this.orderInfo.contractName;
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: (attachList2 ? contractNameCount : this.role == 'S' ? contractNameCount : (contractNameCount.replace('采购合同', '供应合同'))) + ".zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
                if (attachList2) {
                  this.handleBatchDownload(attachList2)
                }
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false });
    },
    handleRejcet() {
      this.$confirm(
        `确认退回该${this.subOrderNo ? '补充合同' : this.settleNo ? '结算申请' : ''}吗？确认请点击【确认退回】`,
        `${this.settleNo ? '退回结算申请' : '退回合同'}`,
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确认退回",
          cancelButtonText: '取消',
        }).then(() => {
          if (this.settleNo) {
            this.confirmReturnStatementSingle('0')
            return
          }
          this.confirmRejectOrder()
        }).catch(() => {
        });
    },

    confirmRejectOrder() {
      let params = {
        orderNo: this.subOrderNo || this.orderNo,
        refuseReason: this.rejectForm.refuseReason,
      };
      InterfaceService.rejectOrder(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            this.rejectDialogVisible = false;
            this.$message.success(`${this.subOrderNo ? '补充' : ''}合同已退回！`);
            this.subOrderNo = ''
            this.getOrderDetail();
            window.opener && window.opener.location.reload();
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    handleChangeTab(tab) {
      this.tabIndex = tab.listType
      // console.log(this.tabIndex);
    },
    handleChangeOutTab(tab) {
      this.outTypeIndex = tab.outType
      this.showSignBtn(this.orderInfo.eventList || [])
    },
    // 刷新状态
    handleRefreshStatus() {
      this.getOrderDetail();
      window.opener && window.opener.location.reload();
    },
    handleConfirmB(type, first) {
      // console.log(this.orderInfo, '0-type');
      if (first) {
        const params = {
          corpId: this.orderInfo.purchaserId,
        };
        InterfaceService.rejectQueryPurchaser(
          params,
          data => {
            if (data.respCode === "0000") {
              let corpAddrInfoRst = data.respData.corpAddrInfoRst || {}
              if (!corpAddrInfoRst.officeProvCode || !corpAddrInfoRst.officeCityCode) {
                this.$confirm(
                  '您还没有设置公司地址信息，请先去设置！',
                  this.rejectBtn,
                  {
                    cancelButtonClass: "btn-custom-cancel",
                    confirmButtonClass: "btn-custom-confirm",
                    center: true,
                    dangerouslyUseHTMLString: true,
                    confirmButtonText: '去设置',
                    cancelButtonText: '取消',
                  }).then(() => {
                    this.$setRootScope('OrderDetailObj', JSON.stringify({
                      purchaserId: this.orderInfo.purchaserId,
                      type: 'companyAddress',
                    }))
                    this.$router.push({ path: '/purchaserCenter/projectList' })
                  }).catch(() => {
                  });
                return
              }
              if (!corpAddrInfoRst.invoicingProvCode || !corpAddrInfoRst.invoicingCityCode) {
                this.$confirm(
                  '您还没有设置开票信息地址信息，请先去设置！',
                  this.rejectBtn,
                  {
                    cancelButtonClass: "btn-custom-cancel",
                    confirmButtonClass: "btn-custom-confirm",
                    center: true,
                    dangerouslyUseHTMLString: true,
                    confirmButtonText: '去设置',
                    cancelButtonText: '取消',
                  }).then(() => {
                    this.$setRootScope('OrderDetailObj', JSON.stringify({
                      purchaserId: this.orderInfo.purchaserId,
                      type: 'InvoicingAddress',
                    }))
                    this.$router.push({ path: '/purchaserCenter/projectList' })
                  }).catch(() => {
                  });
                return
              }
              this.$refs['confirmContract'].open(this.orderInfo, type, this.orderInfo && this.orderInfo.purchaserId || '')
            } else {
              this.$message.error(data.respMsg);
            }
          }, data => { }, () => { this.isLoading = true; }, () => { this.isLoading = false; });
      } else {
        this.$refs['confirmContract'].open(this.orderInfo, type, this.orderInfo && this.orderInfo.purchaserId || '')
      }
    },
    handleConfirmS(subOrderNo = '') {
      this.$confirm(
        `确认审核通过该${subOrderNo == 'settlement' ? '结算' : subOrderNo ? '补充' : ''}合同吗？确认请点击【通过】`,
        `通过${subOrderNo == 'settlement' ? '结算' : subOrderNo ? '补充' : ''}合同`,
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "通过",
          cancelButtonText: '取消',
        }).then(() => {
          if (subOrderNo == 'settlement') {
            this.launchOaExaminationStatementSingle()
            return
          }
          let params = {
            orderNo: subOrderNo || this.orderNo,
          };
          InterfaceService.confirmOrder(
            params,
            data => {
              let res = data.respData || {};
              if (data && data.respData && res.respCode === "0000") {
                this.$message.success(`${subOrderNo ? '补充' : ''}合同已通过！`);
                this.getOrderDetail();
                window.opener && window.opener.location.reload();
              } else {
                this.$message.error(data.respData.respMsg)
              }
            }, data => {
              this.$message.error(data.respData.respMsg)
            }, () => {
              this.isLoading = true
            }, () => {
              this.isLoading = false
            })
        }).catch(() => {
        });
    },
    showSignBtn(eventList) {
      // console.log(this.outTypeIndex);
      let bool = false;
      eventList.forEach(ev => {
        ev.processList.forEach(pro => {
          if (pro.acctId === this.userinfo.acctId && pro.processFlg !== '1') {
            bool = true
          }
        })
      })
      this.signFlag = bool && this.orderInfo.orderStatus === '05' && ((this.role === 'B' && !this.brokerRole && this.outTypeIndex == '1') || this.role === 'S' || this.brokerRole)
    },

    /**
     * 重新提交时 需要查询
     */
    accountInfo() {
      let param = {
        'acctId': this.userInfo.acctId
      }
      InterfaceService.accountInfo(param, (data) => {
        if (data && data.respData && data.respData.respCode === "0000") {
          const obj = data.respData || {}
          if (!obj.oaAapplicantId) {
            this.$confirm(
              '您还没有绑定集团OA账号，请先去绑定！',
              this.rejectBtn,
              {
                cancelButtonClass: "btn-custom-cancel",
                confirmButtonClass: "btn-custom-confirm",
                center: true,
                dangerouslyUseHTMLString: true,
                confirmButtonText: '去绑定',
                cancelButtonText: '取消',
              }).then(() => {
                this.$router.push({ path: '/purchaserCenter/accountInfo' })
              }).catch(() => {
              });
            return
          }

          this.launchOaExaminationStatementSingle(obj)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      })
    },

    /**
     * 结算合同 - 发起oa审核
     */
    launchOaExaminationStatementSingle(obj = {}) {
      return new Promise(resolve => {
        let params = {
          settleNo: this.settleNo,//	String	Y	结算单编号
          orderNo: this.settleNo,//	String	Y	合同编号
          approveId: '',//	String	N	oa流程编号
          approveName: '',//	String	N	审批流程名称
          approveNo: this.settleNo,//	String	Y	申请单号（暂时和结算单编号一样）

          approveCreateId: obj.oaAapplicantId || '',//	申请人
          approveDivisionId: obj.oaCompanyId || '',//	申请事业部ID
          approveDivisionName: obj.oaCompanyName || '',//	申请事业部名称
          approveDepartmentId: obj.oaDepartmentid || '',//	申请部门ID
          approveDepartmentName: obj.oaDepartmentName || '',//	申请部门名称
          approveUrgency: '0',//	紧急程度
          approveMobile: obj.oaAapplicantMobile || '',//	申请人手机
          // approveCompanyId: obj.companyId || '',//	申请公司ID
          approveCompanyId: obj.oaCompanyId || '',//	申请公司ID
          approveCompanyName: obj.companyName || '',//	申请公司名称
          approveMsg: '审核意见',//	提交审核意见

          applyAcctId: this.userInfo.acctId,//	String	Y	审核人账号
          applyAcctName: this.userInfo.acctName,//	String	Y	审核人名称
          handleType: '1',//	String	Y	操作类型 1-提交， 2-重新提交
          applyType: '0',//	String	Y	操作类型（0-提交审核，1-解除审核，2-终止审核）
        };
        InterfaceService.launchOaExaminationStatementSingle(
          params,
          data => {
            const res = data && data.respData || {};
            if (res.respCode === "0000") {
              if (this.outTypeIndex == 1) {
                this.$message.success(`已提交OA审核！`);
              } else {
                this.$message.success(`结算合同已通过！`);
              }
              this.settleStatus = '2'
              this.confirmSettleMentDialog = false
              this.getOrderDetail();
              this.$refs['detaillSettlementComponentRef'] && this.$refs['detaillSettlementComponentRef'].getInitData()
              window.opener && window.opener.location.reload();
            } else {
              this.$message.error(res.respMsg)
            }
            resolve(true)
          }, data => {
            this.$message.error(data.respMsg)
          }, () => { this.isLoading = true }, () => { this.isLoading = false })
      })
    },

    /**
    * 退回 结算单
    */
    confirmReturnStatementSingle(handleType) {
      return new Promise(resolve => {
        let params = {
          settleNo: this.settleNo, //	String	Y	结算单编号
          handleType, //	String	Y	操作类型（0-提交退回，1-解除退回，2-终止退回）
          rejectReason: this.rejectForm.refuseReason, //	String	Y	退回原因
          rejectAcctName: this.userinfo.acctName, //	String	Y	审核人姓名

        };
        InterfaceService.returnStatementSingle(
          params,
          data => {
            const res = data && data.respData || {};
            if (res.respCode === "0000") {
              this.rejectDialogVisible = false;
              this.$message.success(`结算合同已退回！`);
              this.settleStatus = '3'
              this.getOrderDetail();
              this.$refs['detaillSettlementComponentRef'] && this.$refs['detaillSettlementComponentRef'].getInitData()
              window.opener && window.opener.location.reload();
            } else {
              this.$message.error(res.respMsg)
            }
            resolve(true)
          }, data => {
            this.$message.error(data.respMsg)
          }, () => { this.isLoading = true }, () => { this.isLoading = false })
      })
    },

    getOrderDetail(type, init = '') {
      let sort = this.orderSortList.join("_");
      const params = {
        orderNo: this.orderNo,
        pageIndex: this.orderPageIndex,
        sort: sort
      };
      InterfaceService.getOrderDetail(
        params,
        data => {
          let res = data.respData;
          if (res.respCode === "0000") {
            if (!type) {
              this.orderInfo = data.respData || {};
              // 结算单
              this.settleNo =  this.orderInfo.settleNo || ''
              this.settleStatus =  this.orderInfo.settlementStatus || ''
              this.settleType =  this.orderInfo.settleType || ''
              if(this.$route.query.receivePay){
                this.tabs = [
                  { label: "基本信息", listType: 0 },
                  { label: "商品清单", listType: 1 },
                  { label: this.outTypeIndex == 1 ? "收款记录" : "付款记录", listType: 4, active: true  }
                ]
              }
              // 补充合同列表
              this.replenishContractInfo = this.orderInfo.replenishContractInfo || {}
              if (this.replenishContractInfo.relContractList && this.replenishContractInfo.relContractList.length && init) {
                if (this.tabIndex == 2) {
                  this.tabs = [
                    { label: "基本信息", listType: 0 },
                    { label: "商品清单", listType: 1 },
                    { label: "补充合同", listType: 2, active: true },
                    { label: this.outTypeIndex == 1 ? "收款记录" : "付款记录", listType: 4 }
                  ]
                } else {
                  if(this.tabIndex == 4){
                    this.tabs = [
                      { label: "基本信息", listType: 0},
                      { label: "商品清单", listType: 1 },
                      { label: "补充合同", listType: 2 },
                      { label: this.outTypeIndex == 1 ? "收款记录" : "付款记录", listType: 4, active: true }
                    ]
                  }else{
                    this.tabs = [
                      { label: "基本信息", listType: 0, active: true },
                      { label: "商品清单", listType: 1 },
                      { label: "补充合同", listType: 2 },
                      { label: this.outTypeIndex == 1 ? "收款记录" : "付款记录", listType: 4 }
                    ]
                  }
                }
              }

              // 合同结算
              if (this.settleStatus || this.settleNo) {
                this.tabs = [
                  { label: "基本信息", listType: 0 },
                  { label: "商品清单", listType: 1 },
                  { label: "结算单", listType: 3 },
                  { label: this.outTypeIndex == 1 ? "收款记录" : "付款记录", listType: 4 }
                ]

                if (this.replenishContractInfo.relContractList && this.replenishContractInfo.relContractList.length) {
                  if (this.tabIndex == 2) {
                    this.tabs = [
                      { label: "基本信息", listType: 0 },
                      { label: "商品清单", listType: 1 },
                      { label: "补充合同", listType: 2 },
                      { label: "结算单", listType: 3 },
                      { label: this.outTypeIndex == 1 ? "收款记录" : "付款记录", listType: 4 }
                    ]
                  } else {
                    this.tabs = [
                      { label: "基本信息", listType: 0 },
                      { label: "商品清单", listType: 1 },
                      { label: "补充合同", listType: 2 },
                      { label: "结算单", listType: 3 },
                      { label: this.outTypeIndex == 1 ? "收款记录" : "付款记录", listType: 4 }
                    ]
                  }
                }

                this.tabs.some(s => (s.listType == this.tabIndex && (s.active = true)))
              }
 
              if (this.orderInfo.busiType != 'ONEWAY_ORDER') {
                let receivePay = this.$route.query.receivePay || ''
                this.breadcrumb = [
                  { name: '管理中心', path: this.role == 'B' ? '/purchaserCenter/accountInfo' : '/vendorCenter/accountInfo' },
                  { 
                    name: receivePay ? receivePay == '0' ? '请款管理-付款查询' : '请款管理-收款查询' : '交易管理-双向合同', 
                    path: this.role == 'B' ? (receivePay ? receivePay == '0' ? '/purchaserCenter/receivePayInquiry?pageType=0' : '/purchaserCenter/receivePayInquiry?pageType=1' : '/purchaserCenter/orderList') : 
                                             (receivePay ? receivePay == '0' ? '/vendorCenter/receivePayInquiry?pageType=0' : '/vendorCenter/receivePayInquiry?pageType=1' : '/vendorCenter/orderList') 
                  },
                  { name: '查看合同详情' },
                ];
              } else {
                this.breadcrumb = [
                  { name: '管理中心', path: this.role == 'B' ? '/purchaserCenter/accountInfo' : '/vendorCenter/accountInfo' },
                  { 
                    name: receivePay ? receivePay == '0' ? '请款管理-付款查询' : '请款管理-收款查询' : '交易管理-单向合同', 
                    path: this.role == 'B' ? (receivePay ? receivePay == '0' ? '/purchaserCenter/receivePayInquiry?pageType=0' : '/purchaserCenter/receivePayInquiry?pageType=1' : '/purchaserCenter/orderList?busiType=ONEWAY_ORDER') : 
                                             (receivePay ? receivePay == '0' ? '/vendorCenter/receivePayInquiry?pageType=0' : '/vendorCenter/receivePayInquiry?pageType=1' : '/vendorCenter/orderList?busiType=ONEWAY_ORDER') 
                  },
                  { name: '查看合同详情' },
                ];
              }

              this.orderInfo.whetherClose = this.$route.query.whetherClose;
              this.orderInfo.creator = this.orderInfo.orderAcctId;
              this.orderList = data.respData.orderList || [];
              this.showSignBtn(this.orderInfo.eventList || []);
              this.pmtMethod = data.respData.pmtMethod;
              if (this.orderInfo.orderFlowList) {
                this.flowList = [];
                this.orderInfo.orderFlowList.forEach(item => {
                  this.flowList.push({
                    foot_title: item.flowName,
                    lightShow: item.isCurrentNode,
                    top_info: item.operTime && item.operTime.substring(0, 10) || "",
                    top_end_info: item.operTime && item.operTime.substring(11, item.operTime.length) || "",
                  })
                });
                //manufacturerCorpId没值的时候是厂家
                if (!this.orderInfo.manufacturerCorpId) {
                  this.flowList.splice(1, 1)
                }
              }
              let onOff = false
              this.flowList.forEach((item, index) => {
                if (item.lightShow === '1') {
                  onOff = true
                  this.activeNode = index;
                }
              });
              if (!onOff) {
                this.activeNode = 0
              }
              if(this.orderInfo.orderStatus == "12"){
                this.activeNode = this.flowList.length
              }
              this.flowList.forEach((item, index) => {
                if (index > this.activeNode) {
                  item.top_info = ''
                  item.top_end_info = ''
                }
              });

              // 补充合同列表
              this.replenishContractInfo = this.orderInfo.replenishContractInfo || {}
            } else {
              if (type === "expiration") {
                this.orderInfo.expiration = data.respData.expiration || "";
              } else if (type === "supply") {
                this.orderInfo.supplyFrom = data.respData.supplyFrom;
                this.orderInfo.supplyTo = data.respData.supplyTo;
              } else if (type === "deliveryMethod") {
                this.orderInfo.deliveryMethod = data.respData.deliveryMethod || "";
                this.orderInfo.deliveryTime = data.respData.deliveryTime || "";
                this.orderInfo.deliveryTime1 = data.respData.deliveryTime1 || "";
              } else if (type === "payment") {
                this.pmtMethod = data.respData.pmtMethod
              } else if (type === "confirmContract") {
                this.orderInfo = data.respData || {};
                this.handleConfirmB(type)
              }
            }
            //退回、拒绝流程节点
            this.orderOperFlow = [];
            let list = this.orderInfo.orderOperFlow || [];
            let relContractList = []
            if (this.replenishContractInfo.relContractList && this.replenishContractInfo.relContractList.length) {
              this.replenishContractInfo.relContractList.forEach(i => {
                if (i.orderOperFlow && i.orderOperFlow.length) {
                  i.orderOperFlow.forEach(j => {
                    this.$set(j, 'textDescription', `补充合同（${this.$conversionNumber(i.orderCnt)}）退回原因：`)
                  })
                  relContractList = relContractList.concat(i.orderOperFlow)
                }
              })
            }
            list = relContractList.concat(list)
            list.forEach(item => {
              if (item.operType == '04' || item.operType == '06' || item.operType == '15' || item.operType == '16') {
                this.orderOperFlow.push({
                  name: item.operAcctName,
                  comment: item.operMsg,
                  department: "",
                  time: item.operTime || "",
                  operType: item.operType || "",
                  textDescription: item.textDescription || "",
                })
              }
            })
            // 降序
            if (this.orderOperFlow.length) {
              this.orderOperFlow.sort((a, b) => {
                // Date.parse兼容IE
                const old = Date.parse(new Date(a.time.replace(/-/g, "/")))
                const now = Date.parse(new Date(b.time.replace(/-/g, "/")))
                return now - old
              })
            }
            this.formatTdSettlementFlows()
            console.log(this.orderOperFlow, 'orderOperFlow');

          } else {
            this.$message.error(res.respMsg);
          }
          this.orderInfo.brokerCorpId = this.brokerCorpId;
          this.$set(this.orderInfo, 'brokerCorpId', this.brokerCorpId)
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    formatTdSettlementFlows() {
      const flows = this.orderInfo && this.orderInfo.tdSettlementFlows || []

      flows.forEach(f => {
        if (['3', '8'].includes(f.settleStatus)) {
          if (!f.settleMsg) return
          const obj = {
            textDescription: `合同结算${f.settleType == '1' ? '撤回' : f.settleType == '2' ? '终止' : ''}退回原因：`,
            time: f.settleTime,
            comment: f.settleMsg,
            name: f.settleAcctName,
          }

          if (this.orderOperFlow && this.orderOperFlow.length) {
            this.orderOperFlow.unshift(obj)
          } else {
            this.orderOperFlow = [obj]
          }
        }
      })
    },
    init(type, init) {
      // console.log(this.orderInfo.busiType);
      if (this.role === 'B') {
        if(!this.brokerRole && this.orderInfo.busiType != 'ONEWAY_ORDER'){
          this.outTypeIndex = 1
          this.outTabs.forEach(f => f.active = f.outType == this.outTypeIndex)
        }
        // 查看收付款记录
        if(this.$route.query.receivePay){
          this.outTypeIndex = this.$route.query.receivePay
          this.outTabs.forEach(f => f.active = f.outType == this.outTypeIndex)
        }
      }
      this.getOrderDetail(type, init);
    },
    handleRefresh() {
      this.init();
      // this.handleChangeOutTab()
      window.opener && window.opener.location.reload();
    }
  },
  mounted() {
    this.orderNo = this.$route.query.orderNo;
    this.brokerCorpId = this.$route.query.brokerCorpId;
    this.orderInfo.busiType = this.$route.query.busiType || ''
    this.tabIndex = +(this.$route.query.tabIndex || 0)
    this.init('', 'init');
  },
  destroyed() {
  }
};
</script>
<style lang="scss">
.reject-dialog {
  .el-dialog__body {
    padding: 10px 20px 0px 20px;
  }
  .el-dialog__footer {
    padding-top: 0px;
  }
}
</style>
<style lang="scss" scoped>
.inner-container {
  margin-bottom: 100px;
  font-size: 14px;
  .paymentInfo {
    &.borderBtm {
      border-bottom: 1px solid #f5f5f5;
      margin-bottom: 16px;
      .center {
        margin-bottom: 18px;
      }
    }
    .orderInfo {
      line-height: 20px;
      margin-bottom: 5px;
      .delivery-method {
        .el-select {
          width: 60px;
        }
      }
      input {
        width: 100px;
        background: white;
        height: 34px;
        border: 1px solid #dddddd;
        margin-right: 6px;
      }
    }
    .paymentInfoTitle {
      margin: 5px 0;
      margin-bottom: 12px;
      padding: 0 10px;
      font-size: 14px;
      border-left: 3px solid #000;
      line-height: 12px;
    }
    span {
      white-space: nowrap;
      color: #0082ff;
      margin-left: 10px;
      cursor: pointer;
    }
    .center {
      margin-bottom: 22px;
      line-height: 18px;
      input {
        width: 100px;
        background: white;
        height: 34px;
        border: 1px solid #dddddd;
      }
    }
  }
}

.pointer {
  cursor: pointer;
  &:hover {
    color: #0082ff;
  }
  &:active {
    color: #4c9cdd;
  }

  .active {
    color: #ffd64e;
  }
}
.tab-change {
  height: 40px;
  margin-top: -10px;
  background: #f5f5f5;
  padding: 10px 20px;
  /*letter-spacing: 6px;*/
  font-size: 16px;
  margin-bottom: 15px;
  text-align: center;
  position: relative;
  color: #fff;
  & > ul {
    & > li {
      float: left;
      font-size: 14px;
      color: #888;
      margin-right: 50px;
      text-align: center;
      cursor: pointer;
      position: relative;
      transition: all 0.3s linear;
      &:hover,
      &.active {
        &::after {
          width: 40px;
        }
        span {
          color: #313131;
          font-weight: 600;
        }
      }

      &:hover {
        span {
          font-weight: normal !important;
        }
      }
      &::after {
        content: "";
        width: 0;
        height: 2px;
        border-radius: 2px;
        background: #c99f4f;
        position: absolute;
        bottom: -6px;
        left: 50%;
        transform: translate(-50%, 0);
        transition: all 0.3s linear;
      }
    }
  }
}

label {
  white-space: nowrap;
  color: #888888;
}
/deep/ .order-status {
  margin: 10px 0 30px;
}
.required {
  &::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
.dialog {
  /deep/ .el-form-item__label {
    padding-right: 6px !important;
    line-height: 17px;
  }
}
.steps-cont {
  margin: 10px 0 30px;
  padding: 20px 0;
  /*border:1px solid #eee;*/
  box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
}
.center {
  text-align: center;
}
.btn-center {
  margin-top: 20px;
  text-align: center;
  margin-bottom: 10px;
}
</style>