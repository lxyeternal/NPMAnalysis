<template>
  <div class="order">
    <!-- <PaymentReportListInfo :order="orderInfo" @refresh="handleRefresh"></PaymentReportListInfo> -->
    <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>
    <!-- 查询条件 -->
    <div class="panel-content">
      <el-form class="form" :model="form" size="small" label-width="90px">
        <el-row>
          <el-col :span="8">
            <el-form-item label="合同名称">
              <el-input v-model="form.contractName" placeholder="请输入合同名称"></el-input>
            </el-form-item>
          </el-col>
          <template v-if="brokerRole">
            <el-col :span="8">
              <el-form-item label="采购商">
                <el-input v-model="form.purchaserName" placeholder="请输入采购商名"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="供应商">
                <el-input v-model="form.supplierName" placeholder="请输入供应商名"></el-input>
              </el-form-item>
            </el-col>
          </template>
          <template v-else>
            <el-col :span="8">
              <el-form-item label="采购商" v-if="role=='S'">
                <el-input v-model="form.purchaserName" placeholder="请输入采购商名"></el-input>
              </el-form-item>
              <el-form-item label="供应商" v-if="role=='B'">
                <el-input v-model="form.supplierName" placeholder="请输入供应商名"></el-input>
              </el-form-item>
            </el-col>
          </template>
          <el-col :span="8">
            <el-form-item label="创建时间">
              <el-col :span="11" class="form-item">
                <el-date-picker type="date" placeholder="请选择日期" value-format="yyyy-MM-dd" v-model="form.fromDt" style="width: 100%;"></el-date-picker>
              </el-col>
              <el-col :span="2" class="tc">~</el-col>
              <el-col :span="11" class="form-item">
                <el-date-picker type="date" placeholder="请选择日期" value-format="yyyy-MM-dd" v-model="form.toDt" style="width: 100%;"></el-date-picker>
              </el-col>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="请款事由">
              <el-select v-model="form.paymentType" placeholder="请选择请款事由" clearable>
                <el-option v-for="(price,index) in causeList" :key="index" :label="price.label" :value="price.value"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <!-- <el-col :span="8">
                        <el-form-item label="发起时间">
                            <el-date-picker v-model="form.statementYearMonth" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" placeholder="请选择">
                            </el-date-picker>
                            ~
                            <el-date-picker v-model="form.statementYearMonth" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" placeholder="请选择">
                            </el-date-picker>
                        </el-form-item>
                    </el-col> -->
        </el-row>
        <el-row>
          <el-col :span="24" class="form-btns">
            <el-button type="primary" size="small" @click="handleSearch">搜索</el-button>
            <el-button size="small" @click="handleClear">清除</el-button>
          </el-col>
        </el-row>
      </el-form>
      <!-- <el-button v-if="role==='S'&&!specialRole" class="fr addPaymentButton" type="primary" size="small" style="width:120px" @click="handleOpenGen" icon="el-icon-circle-plus-outline">新增请款计划</el-button> -->
      <el-button v-if="role==='S'&& !contractCorpTypeMixins" class="fr addPaymentButton" type="primary" size="small" style="width:120px" @click="initiateAnApplicationDialogVisible = true" icon="el-icon-circle-plus-outline">发起请款申请</el-button>
    </div>
    <div class="order-table">
      <!-- 列表 -->
      <table>
        <thead>
          <tr>
            <td width="300">请款编号/合同名称</td>
            <td>
              <span v-if="brokerRole">交易双方</span>
              <template v-else>
                <span v-if="role=='S'">采购商</span>
                <span v-if="role=='B'">供应商</span>
              </template>
            </td>
            <td width="120">请款事由</td>
            <td>请款金额(元)</td>
            <td width="154">请款周期</td>
            <td>创建时间</td>
            <td width="110">操作</td>
          </tr>
        </thead>

        <template v-if="orderList.length">
          <tbody v-for="(order,index) in orderList" :key="index" class="tc tbody-row">
            <tr>
              <td class="txtLeft">
                <div>{{order.paymentNo}}</div>
                <span :class="{goDetaill: !notViewContractDetails}" @click="!notViewContractDetails && handleGoDetaill(order)" v-if="order.contractName">《{{order.contractName}}》</span>
              </td>
              <td>
                <template v-if="brokerRole">
                  <p>采购商：{{order.purchaserName}}</p>
                  <p>供应商：{{order.supplierName}}</p>
                </template>
                <template v-else>
                  <span v-if="role=='S'">{{order.purchaserName}}</span>
                  <span v-if="role=='B'">{{order.supplierName}}</span>
                </template>
              </td>
              <td>
                <p>{{order.paymentTypeName}}</p>
              </td>
              <td class="txtRight">
                <p class="white-space-pre">{{order.paymentAmt | formatMoney}}</p>
              </td>
              <td>
                <p v-if="order.applyFromDt">{{order.applyFromDt}}~{{order.applyToDt}}</p>
                <p v-else>-</p>
              </td>
              <td>
                <p>{{order.creTm || '-'}}</p>
              </td>
              <td class="tc">
                <!-- <PaymentReportListOperate :order="order" :status="form.searchType"></PaymentReportListOperate> -->
                <div class="flex-col">
                  <PaymentReportBtnClickComponent v-if="tab==0"  :order="order" @refresh="getOrderList" :tab="tab"></PaymentReportBtnClickComponent>
                  <a v-if="order.status !== 'init' && tab != 0" @click="handleViewDetail(order)">查看请款详情</a>
                </div>
              </td>
            </tr>
            <tr v-if="order.comment">
              <td colspan="7" style="padding:0">
                <div class="notice-td">
                  <span :title="order.comment.replace(/\n/g, ' ')"> 退回原因：{{order.comment.replace(/\n/g, ' ')}}</span>
                  <i class="el-icon-error" @click="order.comment=''"></i>
                </div>
              </td>
            </tr>
          </tbody>
        </template>
      </table>
      <div class="table-pagination" v-if="orderList.length">
        <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
        </el-pagination>
      </div>

      <!-- 空列表 -->
      <div class="order-empty" v-if="!orderList.length&&!isLoading">
        <img src="@/assets/images/icon-no-product.png">
        <p>没有搜索到相关请款记录，请重新修改搜索条件搜索！</p>
      </div>
    </div>
    <AddPaymentReport ref="addPaymentReport"></AddPaymentReport>
    <InitiateAnApplication v-if="initiateAnApplicationDialogVisible" :initiateAnApplicationDialogVisible.sync="initiateAnApplicationDialogVisible"></InitiateAnApplication>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import PaymentReportListInfo from "@/components/order/paymentReport/PaymentReportListInfo";
import PaymentReportListOperate from "@/components/order/paymentReport/PaymentReportListOperate";
import SignProcessStatementList from "@/components/order/statement/SignProcessStatementList";
import AddPaymentReport from "@/components/order/paymentReport/AddPaymentReportDialog";
import InitiateAnApplication from "@/components/order/paymentReport/InitiateAnApplication";
import PaymentReportBtnClickComponent from "@/components/order/askForMoney/PaymentReportBtnClickComponent";

import { InterfaceService } from "@/services/api";

const params = {
  contractName: "",
  fromDt: "",
  toDt: '',
  purchaserName: "",
  supplierName: "",
  pageIndex: 1,
  pageSize: 1,
  searchType: "0",
  pageFlg: 1,
  paymentType: '',
};

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    PanelTitle,
    PaymentReportListInfo,
    PaymentReportListOperate,
    SignProcessStatementList,
    AddPaymentReport,
    InitiateAnApplication,
    PaymentReportBtnClickComponent, // 操作 - 按钮
  },
  data() {
    return {
      tab: "0",
      tabs: [
        { label: "待处理", index: 0, active: true },
        { label: "进行中", index: 1 },
        { label: "已完成", index: 3 },
        { label: "已驳回", index: 2 },
        { label: "已关闭", index: 4 },
      ],
      causeList: [
        {
          label: "合同预付款",
          value: 'advance'
        },
        {
          label: "材料进场预付款",
          value: 'preProgress'
        },
        {
          label: "进度款",
          value: 'progress'
        }
      ],
      form: Object.assign({}, params),
      statusList: [],
      orderInfo: {},
      orderList: [],
      total: 0,
      isLoading: false,
      storeParams: {},
      executionId: '',
      initiateAnApplicationDialogVisible: false,
    };
  },
  methods: {

    handleGoDetaill(order) {
      // 取消增补 功能需要
      window.open(this.$router.resolve({
        path: "/orderDetail",
        query: {
          orderNo: order.orderNo,
        }
      }).href, '_blank')
    },

    // 修改tab
    handleChangeTab(tab) {
      this.clearSearchValue()
      this.tab = tab.index;
      this.recoverStatus(this.tab);
      this.form.pageIndex = 1;
      this.getOrderList();
    },
    // 清除搜索内容
    clearSearchValue() {
      this.form = Object.assign({}, params)
    },
    // 清除状态选择
    handleSelectClear() {
      this.recoverStatus(this.tab);
    },
    // 清除
    handleClear() {
      this.form = Object.assign({}, params);
      this.recoverStatus(this.tab);
    },
    // 搜索
    handleSearch() {
      this.getOrderList();
    },
    // 分页跳转
    handleCurrentChange(page) {
      this.form.pageIndex = page;
      this.getOrderList();
      window.scrollTo(0, 0)
    },
    handleRefresh() {
      this.form.pageIndex = 1;
      this.getOrderList();
    },
    // 切换签署进度显示
    handleChangeProcess(order, index) {
      order.active = !order.active;
      this.$set(this.orderList, index, order);
    },
    // 恢复状态
    recoverStatus(tab) {
      this.form.searchType = tab + "";
    },
    init() {
      if (this.brokerRole) {
        this.tab = 2;
        this.tabs = [{ label: "已完成", index: 2, active: true }];
        this.form.searchType = "2";
      }
      this.getOrderList();
    },
    getOrderList() {
      this.recordFormData();
      const params = {};
      for (let i in this.form) {
        if (this.form[i]) {
          params[i] = this.form[i];
        }
      }
      params.pageFlg = this.form.pageFlg + "";
      InterfaceService.getPaymentDetailList(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            this.orderInfo = data.respData;
            this.orderList = data.respData.paymentReportList || [];
            this.total = Number(data.respData.totalCount);
            this.form.pageSize = Number(data.respData.pageSize);
            this.orderList.forEach((item) => {
              // 复制 taskId 及 executionId
              const itemOther = {
                myTaskId: item.taskId,
                executionId: item.executionId,
                paymentType: item.paymentType
              }
              this.$set(item, 'other', itemOther)
            })
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    recordFormData() {
      let hasChange = false;
      Object.keys(this.storeParams).forEach(key => {
        if (this.storeParams[key] != this.form[key]) {
          hasChange = true;
        }
      });

      if (hasChange) {
        this.form.pageIndex = 1;
      }

      this.storeParams = this.$clone(this.form);
      delete this.storeParams.pageIndex;
      delete this.storeParams.pageSize;
    },
    handleOpenGen(state) {
      this.$refs["addPaymentReport"].open();
    },

    handleViewDetail(order) {
      window.open(this.$router.resolve({
        path: "/paymentPlanDetail",
        query: {
          executionId: order.executionId,
          paymentNo: order.paymentNo
        }
      }).href, '_blank')
    }
  },
  mounted() {
    this.init();
  }
};
</script>

<style lang="scss" scoped>
.flex-col {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}
.hand + .hand {
  margin-left: 10px;
}
.price-tip {
  cursor: pointer;
  color: #a9a9aa;

  &:hover {
    color: #0082ff;
  }
}

.order {
  font-size: 14px;
}

.pointer {
  cursor: pointer;
  &:hover {
    color: #0082ff;
  }
  &:active {
    color: #4c9cdd;
  }

  .active {
    color: #ffd64e;
  }
}

.nowrap {
  white-space: nowrap;
}

.panel-content {
  margin-bottom: 20px;
  padding: 20px 10px;
  background: #f5f5f5;
}

.form {
  min-height: 135px;

  /deep/ .el-col {
    height: 52px;
  }

  /deep/ .el-select {
    width: 100%;
  }

  /deep/ .el-date-editor {
    input.el-input__inner {
      padding: 0 15px;
    }
    .el-input__prefix {
      display: none;
    }
  }

  &:after {
    display: table;
    content: "";
    clear: both;
  }
}

.form-item {
  position: relative;
  display: inline-block;
  line-height: 32px;

  .float-right {
    position: absolute;
    top: 2px;
    right: 1px;
    height: 30px;
    padding: 0 7px;
    line-height: 30px;
    background: #ffffff;
  }
}

.error-info {
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
  position: absolute;
  top: 100%;
  left: 0;
}

.form .form-btns {
  height: auto;
  text-align: center;
}

.order-table {
  /deep/ .el-table__body-wrapper {
    font-size: 12px;
  }

  /deep/ .el-table th,
  .el-table td {
    padding: 14px 0;
  }

  /deep/ .el-button {
    font-size: 12px;
  }

  table {
    width: 100%;
    line-height: 23px;
    font-size: 12px;
    td {
      padding: 14px 10px;
      vertical-align: middle;
      word-break: break-word;
    }

    thead {
      font-size: 14px;
      text-align: center;
      white-space: nowrap;
      color: #909399;
      background: #f5f5f5;
    }

    .tbody-row:hover {
      background: #e8f3fd;
    }

    tbody {
      text-align: center;

      tr {
        &.sign-content {
          display: table-row;

          td {
            padding: 0;
            border-bottom: none;
          }
        }
      }

      tr:hover + tr.sign-content {
        background: #f0f8ff;
      }

      td {
        &.txtRight {
          text-align: right;
        }
        text-align: left;
        border-bottom: 1px solid #ebeef5;
      }
    }
  }
}

.order-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}

.price-popover {
  display: flex;
  color: #ababac;

  > div:first-child {
    margin-right: 10px;
  }

  p:first-child {
    padding: 0 5px;
    border-left: 3px solid #ffd64e;
    line-height: 15px;
  }

  p:last-child {
    margin-top: 10px;
    color: #ffffff;
  }
}

.table-pagination {
  margin: 50px 0 80px;
  text-align: center;
  color: #888888;
}
.addPaymentButton {
  position: absolute;
  right: 10px;
  top: 7px;
}
.tc {
  a {
    color: #0082ff;
  }
}
.goDetaill {
  cursor: pointer;
  &:hover {
    color: #0082ff;
    text-decoration: underline;
  }
}
tr {
  td {
    .notice-td {
      background: #fef4f3;
      text-align: left;
      padding: 4px 8px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      span {
        width: 870px;
        overflow: hidden;
        height: 20px;
        text-overflow: ellipsis;
        white-space: pre;
      }
      i {
        font-size: 16px;
        color: #aaa;
        cursor: pointer;
      }
    }
  }
}
.txtLeft {
  text-align: left;
  p {
    float: left;
  }
}
.white-space-pre {
  white-space: pre;
}
</style>