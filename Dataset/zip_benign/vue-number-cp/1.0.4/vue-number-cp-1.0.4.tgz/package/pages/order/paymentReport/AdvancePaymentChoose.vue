<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <SearchBar :search-type="5" :is-white-bg="true" :progress="'新增请款计划_预付款'" :is-border-bottom="true"></SearchBar>
        <div class="inner-container">
            <p class="title">
                第一步：选择需要请款的合同。</p>
            <div>
                <a v-if="!order" class="pointer" @click="handleSelect">请选择</a>
                <div v-else class="order-info">
                    <p class="order-title">
                        <span>
                            <el-radio checked></el-radio>&nbsp;合同名称： 《{{order.contractName}}》
                        </span>
                        <el-button class="fr" style="margin-top: -10px;" type="text" @click="handleSelect">修改</el-button>
                    </p>
                </div>
            </div>
            <br>
            <p class="title">
                第二步：请确认以下收款银行账户信息，本请款计划对应款项将汇入以下银行账号。</p>
            <div>
                <BankAcctInfo ref="bankAcctInfo" class="bank-info" @changePromise="handleChangePromise"></BankAcctInfo>
            </div>
        </div>

        <div class="tc bottom">
            <el-button type="primary" @click="handleNext" :disabled="!canNext">下一步</el-button>
        </div>

        <SelectOrder ref="selectOrder" :paymentType="'advance'" @close="handleCloseSelect"></SelectOrder>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import SelectOrder from "@/components/order/dialog/SelectOrderDialog";
import BankAcctInfo from "@/components/account/finance/BankAccountInfo";

import { InterfaceService } from "@/services/api";

export default {
    mixins: [accountMixin],
    components: {
        Header,
        SearchBar,
        Loading,
        SelectOrder,
        BankAcctInfo
    },
    data() {
        return {
            canNext: true,
            isLoading: false,
            order: null
        };
    },
    methods: {
        handleSelect() {
            this.$refs["selectOrder"].open({
                title: "选择需要请款的合同"
            });
        },
        handleCloseSelect(data) {
            if (data) {
                this.order = data;
            }
        },
        handleChangePromise(isChecked) {
            this.canNext = isChecked;
        },
        handleNext() {
            const bankAcctId = this.$refs["bankAcctInfo"].getBankAcct();
            if (!this.order) {
                this.$message.error("请选择合同");
            } else if (!bankAcctId) {
                this.$message.error("请选择收款账号");
            } else {
                this.$store.dispatch("setSelectOrder", this.order);
                this.$router.push({
                    path: "/advancePaymentConfirm",
                    query: {
                        orderNo: this.order.orderNo,
                        orderAmt: this.order.orderAmountWithTax,
                        bankAcctId: bankAcctId
                    }
                });
            }
        }
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            if (from.name === "AdvancePaymentConfirm") {
                const order = vm.$store.state.payment.selectOrder;
                vm.order = order && Object.assign({}, order);
            }
            vm.$store.dispatch("clearSelectOrder");
        });
    }
};
</script>

<style lang="scss" scoped>
.pointer {
    color: #0082ff;
}

.title {
    padding: 20px 0;
    margin: 20px 0;
    border-bottom: 1px solid #ececec;
}

.order-title {
    margin-top: 20px;
    padding: 20px 15px;
    border: 1px solid #ececec;
    background: #f0f8ff;
}

.bottom {
    margin: 40px auto 400px;
    /deep/ .el-button {
        width: 150px;
    }
}
</style>
