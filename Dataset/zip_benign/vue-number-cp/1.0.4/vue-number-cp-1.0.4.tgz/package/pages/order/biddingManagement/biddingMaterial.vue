<template>
  <div class="bidding-list-container">
    <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>

    <div class="add-tendering-btn">
      <el-button type="primary" icon="el-icon-circle-plus" @click="handleAddTendering">新增</el-button>
    </div>

    <!-- 查询条件 -->
    <div class="panel-content">
      <el-form class="form" :model="form" size="small" label-width="75px">
        <el-row>
          <el-col :span="23">
            <el-form-item label="名称">
              <el-input v-model.trim="form.tenderingName" placeholder="请输入名称" maxlength="64"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="13">
            <el-form-item label="时间">
              <el-col :span="10" class="form-item">
                <el-date-picker type="date" placeholder="请选择开始日期" :picker-options="startDtOptions" value-format="yyyy-MM-dd" v-model="form.fromTime" style="width: 100%"></el-date-picker>
              </el-col>
              <el-col :span="2" class="tc">~</el-col>
              <el-col :span="10" class="form-item">
                <el-date-picker type="date" placeholder="请选择结束日期" :picker-options="endDtOptions" value-format="yyyy-MM-dd" v-model="form.toTime" style="width: 100%"></el-date-picker>
              </el-col>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24" class="form-btns" align="center">
            <el-button type="primary" size="small" @click="handleSearch">搜索</el-button>
            <el-button size="small" @click="handleClear">清除</el-button>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <!-- 表格数据显示 -->
    <OrderTable :columnDefs="tableGrid.columnDefs" :operation="tableGrid.operation" :rowData="tableGrid.rowData"></OrderTable>

    <div class="table-pagination" v-if="tableGrid.rowData && tableGrid.rowData.length">
      <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="form.total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
      </el-pagination>
    </div>

    <!-- 定标 弹窗 -->
    <el-dialog class="dialog dialog-drafts" title="确认定标" :append-to-body="true" :lock-scroll="true" :visible.sync="showScalingDialog" width="50%" center :close-on-click-modal="false">
      <div class="drafts-list">
        <p class="txt-center">
          暂不支持线上定标, 请联系合制平台进行定标及后续商品入库操作。
        </p>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" class="w100" @click="handleDiaBtnCancel">知道了</el-button>
      </div>
    </el-dialog>

    <!--删除 弹窗 -->
    <el-dialog class="dialog dialog-drafts" title="确认删除" :append-to-body="true" :lock-scroll="true" :visible.sync="showDelDialog" width="50%" center :close-on-click-modal="false">
      <div class="drafts-list">
        <p class="txt-center">
          确认删除后, 我们将不保留该比价的任何记录。 确认要删除<span class="red">{{noticetenderingCode}}号</span>文件吗?
        </p>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" class="w100" @click="handleDiaBtnConfim()">确认删除</el-button>
        <el-button size="small" class="w100" @click="handleDiaBtnCancel">取消</el-button>
      </div>
    </el-dialog>

    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import OrderTable from "@/components/order/orderTable"
import { InterfaceService } from '@/services/api'
import accountMixin from "@/mixins/account";

const params = {
  tenderingName: '', // 名称
  fromTime: '',
  toTime: '',
  pageIndex: 1,
  pageSize: 10,
  total: 1,
};

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    PanelTitle,
    OrderTable
  },
  data() {
    return {
      isLoading: false,
      showScalingDialog: false,
      showDelDialog: false,
      noticetenderingCode: '',
      tab: 1,
      tabs: [
        { label: "发布中", index: 1, active: true, tenderStatus: ['published', 'replying', 'opening', 'decision'] },
        { label: "未发布", index: 2, tenderStatus: ['unpublished'] },
        { label: "已结束", index: 3, tenderStatus: ['success'] },
      ],
      form: Object.assign({}, params),
      tableGrid: {},
      tenderStatus: {
        unpublished: '未发标',
        published: '等待报价',
        replying: '等待报价',
        opening: '正式比价',
        decision: '报价整理',
        success: '已结束',
      },
      startDtOptions: {}, // 搜索开始时间配置
      endDtOptions: {}, // 搜索结束时间配置
    }
  },
  created() {
    const __this = this

    /**
     * 格式化时间
     */
    const formatTime = (val) => {
      return val < 10 ? `0${val}` : val
    }

    this.startDtOptions = {
      disabledDate(time) {
        return __this.form.toTime ? time.getTime() > new Date(__this.form.toTime).getTime() : false;
      },
    }
    this.endDtOptions = {
      disabledDate(time) {
        return new Date(`${time.getFullYear()}-${formatTime(time.getMonth() + 1)}-${formatTime(time.getDate())}`).getTime() < new Date(__this.form.fromTime).getTime();
      },
    }
  },
  computed: {
    // 当前用户 acctId
    acctId() {
      return (
        this.$store.state.userInfo && this.$store.state.userInfo.acctId || ''
      )
    },
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.getInviteTenderList()
      this.setTableDataByTab()
    },

    /**
     * 根据点击tab 设置相应表格数据
     */
    setTableDataByTab() {
      let tableGrid = {}, rowData = []
      const __this = this
      switch (this.tab) {
        case 1:
          tableGrid = {
            columnDefs: [
              { headerName: '编号', field: 'tenderNo', w: '15%', h: '60px' },
              { headerName: '名称', field: 'tenderName', w: '25%' },
              { headerName: '截止时间', field: 'replyEndDt', w: '17%', filter: item => item.replyEndDt && item.replyEndDt.match(/^.[^\s]*/)[0] || '' },
              { headerName: '状态', field: 'tenderStatus', w: '8%', filter: item => __this.tenderStatus[item.tenderStatus] || '' }
            ],
            operation: {
              enable: true,
              w: '20%',
              align: 'right',
              btnList: [
                {
                  btnName: '查看供应商报价',
                  btnFn: item => {
                    this.$store.dispatch("setTenderNo", item.tenderNo || '');
                    this.$router.push({ path: '/backMark', query: { biddingName: encodeURI(item.tenderName) } })
                  }
                },
                {
                  btnName: '查看',
                  btnFn: item => {
                    this.$store.dispatch("setTenderingState", 2);
                    this.$store.dispatch("setTenderNo", item.tenderNo || '');
                    this.$router.push({ path: '/biddingInformation' })
                  }
                },
                // {
                //   btnName: '定标',
                //   btnFn: (item, index) => {
                //     this.showScalingDialog = true
                //   }
                // }
              ]
            },
          }
          break;
        case 2:
          tableGrid = {
            columnDefs: [
              { headerName: '编号', field: 'tenderNo', w: '20%', h: '60px' },
              { headerName: '名称', field: 'tenderName', w: '40%' },
              { headerName: '截止时间', field: 'replyEndDt', w: '20%', filter: item => item.replyEndDt && item.replyEndDt.match(/^.[^\s]*/)[0] || '' },
            ],
            operation: {
              enable: true,
              w: '20%',
              align: 'right',
              btnList: [
                {
                  btnName(item) { return item.personInChargeList.every(e => !(__this.mxAcctIdList.includes(e.acctId))) ? '查看' : '编辑' },
                  btnFn: item => {
                    this.$store.dispatch("setTenderNo", item.tenderNo || '');
                    this.$store.dispatch("setTenderingState", 1);
                    this.$router.push({ path: '/biddingInformation' })
                  }
                },
                {
                  btnName: '删除',
                  rowBtnCellFilter(item) { return !item.personInChargeList.every(e => !(__this.mxAcctIdList.includes(e.acctId))) },
                  btnFn: item => {
                    this.noticetenderingCode = item.tenderNo || ''
                    this.showDelDialog = true
                  }
                }
              ]
            },
          }
          break;
        case 3:
          tableGrid = {
            columnDefs: [
              { headerName: '编号', field: 'tenderNo', w: '15%', h: '60px' },
              { headerName: '名称', field: 'tenderName', w: '25%' },
              { headerName: '截止时间', field: 'replyEndDt', w: '17%', filter: item => item.replyEndDt && item.replyEndDt.match(/^.[^\s]*/)[0] || '' },
              { headerName: '状态', field: 'tenderStatus', w: '8%', filter: item => __this.tenderStatus[item.tenderStatus] || '' }
            ],
            operation: {
              enable: true,
              w: '20%',
              align: 'right',
              btnList: [
                {
                  btnName: '查看供应商报价',
                  btnFn: item => {
                    this.$store.dispatch("setTenderNo", item.tenderNo || '');
                    this.$router.push({ path: '/backMark' })
                  }
                },
                {
                  btnName: '查看',
                  btnFn: item => {
                    this.$store.dispatch("setTenderingState", 2);
                    this.$store.dispatch("setTenderNo", item.tenderNo || '');
                    this.$router.push({ path: '/biddingInformation' })
                  }
                },
              ]
            },
          }
          break;
        default:
          break;
      }

      this.$set(this.tableGrid, 'columnDefs', tableGrid.columnDefs)
      this.$set(this.tableGrid, 'operation', tableGrid.operation)
    },

    /**
     * 修改tab
     * @param tab 当前下标
     */
    handleChangeTab(tab) {
      this.tab = tab.index
      this.form.pageIndex = 1
      this.setTableDataByTab()
      this.resetSearchValues()
      this.getInviteTenderList()
    },

    /**
     * 重置搜索数据
     */
    resetSearchValues() {
      this.form.tenderingName = ''
      this.form.fromTime = ''
      this.form.toTime = ''
    },

    /**
     * 搜索
     */
    handleSearch() {
      if (new Date(this.form.fromTime) > new Date(this.form.toTime)) {
        this.$message.error('开始时间不能大于结束时间')
        return
      }
      this.form.pageIndex = 1
      this.getInviteTenderList()
    },

    /**
     * 搜索取消
     */
    handleClear() {
      this.form.pageIndex = 1
      this.resetSearchValues()
      this.getInviteTenderList()
    },

    /**
     * 分页跳转
     */
    handleCurrentChange(page) {
      this.form.pageIndex = page;
      window.scrollTo(0, 0)
      this.getInviteTenderList()
    },

    /**
     * 新增
     */
    handleAddTendering() {
      this.$store.dispatch("setTenderingState", 0);
      this.$router.push({ path: '/biddingInformation' })
    },

    /**
     * 弹出框 确认按钮
     */
    handleDiaBtnConfim() {
      this.deleteInviteTenderInfo()
    },

    /**
     * 弹出框 取消按钮
     */
    handleDiaBtnCancel() {
      this.showScalingDialog = false
      this.showDelDialog = false
    },

    /**
     * 获取数据列表
     */
    getInviteTenderList() {
      const param = {
        tenderCorpId: '', // 公司ID
        tenderNo: '', // 标号
        tenderName: this.form && this.form.tenderingName, // 标名
        searchDtFrom: this.form && this.form.fromTime, // 查询开始时间（YYYY-MM-DD HH:MM:SS）当开始时间和结束时间都输入时，开始时间<结束时间
        searchDtTo: this.form && this.form.toTime, // 结束时间
        tenderStatusList: this.tabs.filter(f => f.index === this.tab)[0].tenderStatus || [], // 状态列表（目前用于Tab的区分，"未发布"传"unpublished"；"已发布"传"published","replying","opening"和"decision"四种；"已结束"传"success"）
        pageIndex: this.form.pageIndex
      }

      InterfaceService.getInviteTenderList(param, data => {
        this.tableGrid.rowData = []
        if (data && data.respData && data.respData.respCode === "0000") {
          const { tenderList, totalCount, pageSize } = data.respData || {}

          this.form.total = totalCount || 0
          this.form.pageSize = pageSize || 0
          this.$set(this.tableGrid, 'rowData', tenderList || [])

        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },

    /**
     * 删除信息
     */
    deleteInviteTenderInfo() {
      const param = {
        tenderNo: this.noticetenderingCode
      }

      InterfaceService.deleteInviteTenderInfo(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('删除成功')
        } else {
          this.$message.error(data.respData.respMsg)
        }
        this.showDelDialog = false
        this.getInviteTenderList()
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
  }
}
</script>

<style scoped lang="scss">
.bidding-list-container {
  position: relative;
  .add-tendering-btn {
    position: absolute;
    right: 8px;
    top: 8px;
    /deep/ .el-button {
      padding: 8px 16px;
    }
  }
  .panel-content {
    margin-bottom: 20px;
    padding: 20px 10px;
    background: #f5f5f5;
  }

  .table-pagination {
    margin: 50px 0 80px;
    text-align: center;
    color: #888888;
  }
}
.txt-center {
  text-align: center;
}
.w100 {
  width: 100px !important;
}
</style>
