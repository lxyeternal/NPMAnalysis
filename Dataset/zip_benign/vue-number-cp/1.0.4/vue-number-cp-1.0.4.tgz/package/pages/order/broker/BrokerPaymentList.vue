<template>
    <div class="product">
        <PanelTitle :tabs="tabs" @select="handleChangeTab" :titleButton = "titleButton" @handleOpen="handleCreatePayment('init')"></PanelTitle>
        <!-- 查询条件 -->
        <el-form class="form" ref="form" :model="form" label-width="80px">
            <el-row>
                <el-col :span="2">
                    <span class="search-title">请款主题</span>
                </el-col>
                <el-col :span="19">
                    <el-input
                            v-model="form.applyTheme"
                            clearable
                            @keyup.enter.native="handleSearch"
                            placeholder="请输入关键词搜索请款主题"
                    ></el-input>
                </el-col>
                <el-col :span="3">
                    <el-button
                            type="primary"
                            size="small"
                            style="width: 100%"
                            @click="handleSearch"
                    >搜索</el-button
                    >
                </el-col>
            </el-row>
            <!--<el-row>-->
                <!--<el-col class="headSearchContainer" :span="24">-->
                    <!--<span class="search-title">请款主题</span>-->
                    <!--<el-input-->
                        <!--v-model="form.applyTheme"-->
                        <!--clearable-->
                        <!--@keyup.enter.native="handleSearch"-->
                        <!--placeholder="请输入关键词搜索请款主题"-->
                        <!--&gt;</el-input>-->
                    <!--<el-button-->
                        <!--type="primary"-->
                        <!--size="small"-->
                        <!--style="width: 100px"-->
                        <!--@click="handleSearch">搜索</el-button>-->
                <!--</el-col>-->
            <!--</el-row>-->
            <el-row>
                <el-col :span="tab == 1? 8: 7">
                    <el-form-item label="城市公司">
                        <el-select v-model="form.cityCompany" filterable placeholder="请选择城市公司" @change="handleSearch">
                            <el-option value="" label="全部"></el-option>
                            <el-option
                                    v-for="(item,index) in cityCompanyList"
                                    :key="index"
                                    :label="item"
                                    :value="item">
                            </el-option>
                        </el-select>
                        <!--<el-select placeholder="请选择城市公司" v-model="form.cityCompany" @change="getApprovalList">-->
                            <!--<el-option value="" label="全部"></el-option>-->
                            <!--<el-option v-for="(item,index) in projectList" :value="item" :key="index"></el-option>-->
                        <!--</el-select>-->
                    </el-form-item>
                </el-col>
                <el-col :span="tab == 1 ? 8: 7">
                    <el-form-item label="供应商">
                        <el-select v-model="form.supplierName" filterable placeholder="请选择供应商" @change="handleSearch">
                            <el-option value="" label="全部"></el-option>
                            <el-option
                                    v-for="(item,index) in supplierNameList"
                                    :key="index"
                                    :label="item"
                                    :value="item">
                            </el-option>
                        </el-select>
                        <!--<el-select placeholder="请选择供应商" v-model="form.supplierName" @change="getApprovalList">-->
                            <!--<el-option value="" label="全部"></el-option>-->
                            <!--<el-option v-for="(item,index) in supplierNameList" :value="item" :key="index"></el-option>-->
                        <!--</el-select>-->
                    </el-form-item>
                </el-col>
                <el-col :span="8" v-if="tab == 1">
                    <el-form-item label="请款事由">
                        <el-select placeholder="请选择请款事由" v-model="form.paymentType" @change="handleSearch">
                            <el-option value="" label="全部"></el-option>
                            <el-option v-for="(item,index) in paymentTypeList" :value="item" :key="index"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="10" v-if="tab == 3 || tab == 4" class="third-col">
                    <el-col :span="14">
                        <el-form-item label="发起审批时间">
                            <el-col class="form-item">
                                <el-date-picker type="year" placeholder="请选择年份" value-format="yyyy" v-model="form.year" style="width:100%" @change="handleSearch"></el-date-picker>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col class="tc" :span="2"><div style="text-align: center;height: 100%;line-height: 40px">~</div></el-col>
                    <el-col class="form-item" :span="8">
                        <el-select placeholder="请选择季度" v-model="form.season" @change="handleSearch"  style="width:92%">
                            <el-option v-for="(item,index) in seasonList" :label="item.season" :value="item.value" :key="index"></el-option>
                        </el-select>
                    </el-col>
                </el-col>
                <!--<template v-if="tab == 3 || tab == 4">-->
                    <!--<el-col :span="7">-->
                        <!--<el-form-item prop="orderCateCode" class="form-item" label="品类">-->
                            <!--<el-select v-model="form.orderCateCode" @change="handleChangeCate($event)" placeholder="输入选择品类一级类目" clearable>-->
                                <!--<el-option v-for="(item,index) in categoryList" :key="index" :label="item.title" :value="item.key"></el-option>-->
                            <!--</el-select>-->
                        <!--</el-form-item>-->
                    <!--</el-col>-->
                    <!--<el-col :span="7">-->
                        <!--<el-form-item prop="majorCode" class="form-item secondCate">-->
                            <!--<el-select clearable filterable default-first-option no-data-text="请先选择一级类目" no-match-text="请修改匹配关键词" v-model="form.majorCode" @change="handleChangeMajor" placeholder="输入选择品类二级类目">-->
                                <!--<template>-->
                                    <!--<el-option v-for="(item,index) in majorList.children" :key="index" :label="item.title" :value="item.key"></el-option>-->
                                <!--</template>-->
                            <!--</el-select>-->
                        <!--</el-form-item>-->
                    <!--</el-col>-->
                <!--</template>-->
            </el-row>
            <el-row>
                <el-col :span="tab == 1? 8: 7">
                    <el-form-item label="项目名称">
                        <el-select v-model="form.projectName" filterable placeholder="请选择项目名称" @change="handleSearch">
                            <el-option value="" label="全部"></el-option>
                            <el-option
                                    v-for="(item,index) in projectList"
                                    :key="index"
                                    :label="item"
                                    :value="item">
                            </el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="24" v-if="tab == 1 && operateApproval">
                    <div class="specifications-choose clearfloat">
                        <ul>
                            <li :class="{'active':form.executionStatus === ''}" @click="changeExecutionStatus('')">全部</li>
                            <li :class="{'active':form.executionStatus === 'rejected'}" @click="changeExecutionStatus('rejected')">
                                被退回
                                <em class="red" v-if="rejectedRemind == '1'">●</em>
                            </li>
                            <li :class="{'active':form.isDraft === '1'}" @click="changeExecutionStatus('1')">已存草稿</li>
                        </ul>
                    </div>
                </el-col>
                <el-col :span="24" v-if="tab == 3">
                    <div class="specifications-choose clearfloat">
                        <ul>
                            <li :class="{'active':form.executionStatus === ''}" @click="changeExecutionStatus('')">全部</li>
                            <li :class="{'active':form.executionStatus === 'processing'}" @click="changeExecutionStatus('processing')">进行中</li>
                            <li :class="{'active':form.executionStatus === 'end'}" @click="changeExecutionStatus('end')">审批完成</li>
                            <li v-if="operateApproval" :class="{'active':form.executionStatus === 'closed'}"  @click="changeExecutionStatus('closed')">已关闭</li>
                            <li v-else :class="{'active':form.executionStatus === 'rejected'}" @click="changeExecutionStatus('rejected')">已退回</li>
                        </ul>
                    </div>
                </el-col>
            </el-row>
        </el-form>
        <div class="product-table">
            <!-- 列表 -->
            <div class="check-all" v-if="tab == 1 && (contractApproval || financeApproval)">
                <div class="check">
                    <el-checkbox v-model="allChecked" @change="handleAllSelectTableRow" :disabled="disableAllCheck"></el-checkbox><span>当页全选</span>
                </div>
                <div class="sign f18">
                    <el-button size="mini" :disabled="!hasChecked" @click="handleBatchOrderConfirm">批量审批</el-button>
                </div>
            </div>
                <!--</template>-->
            <table v-if="tab != 4">
                <thead ref="head">
                <tr>
                    <th width="5%" v-if="operateApproval">&nbsp;</th>
                    <th width="98px" v-else>&nbsp;</th>
                    <th width="95px">城市公司</th>
                    <th width="14%">项目名称</th>
                    <th width="24%">请款主题</th>
                    <!--<th v-if="tab ==1" width="75px">加价费率</th>-->
                    <th width="10%">供应商</th>
                    <th width="9%">请款事由</th>
                    <th width="11%" v-if="operateApproval && tab == 1">接收时间</th>
                    <th width="11%" v-if="operateApproval && tab == 3">提交时间</th>
                    <th width="10%" v-if="tab == 1">申请金额(元)</th>
                    <th width="10%" v-if="tab == 3">状态</th>
                    <th width="11%" style="text-align: right;padding-right: 6px;">操作</th>
                </tr>
                </thead>
                <div v-if="fixedhead" class="fixedhead">
                    <span style="width:5%" v-if="operateApproval">&nbsp;</span>
                    <span style="width:98px" v-else>&nbsp;</span>
                    <span style="width:95px">城市公司</span>
                    <span style="width:128px">项目名称</span>
                    <span v-if="operateApproval" style="width:216px">请款主题</span>
                    <span v-else style="width:242px">请款主题</span>
                    <!--<th v-if="tab ==1" style="width:""75px">加价费率</th>-->
                    <span style="width:84px">供应商</span>
                    <span v-if="operateApproval" style="width:75px">请款事由</span>
                    <span v-else style="width:85px">请款事由</span>
                    <span style="width:98px" v-if="operateApproval && tab == 1">接收时间</span>
                    <span style="width:98px" v-if="operateApproval && tab == 3">提交时间</span>
                    <span style="width:95px" v-if="tab == 1">申请金额(元)</span>
                    <span style="width:95px" v-if="tab == 3">状态</span>
                    <span style="text-align: right;width:82px">操作</span>
                </div>
                <!--<template v-if="productList.length">-->
                <tbody v-for="(item,index) in pmtApproveInfos" :key="index" class="tbody-row">
                <!--<tbody class="tbody-row">-->
                <tr>
                    <td v-if="tab == 1 && item.taskId != 'operation_apply'" style="text-align: center">
                        <el-checkbox v-model="item.checked" :disabled="disableAllCheck"  @change="handleSelectTableRow(item,index)"></el-checkbox>
                    </td>
                    <td v-else>&nbsp;</td>
                    <td>{{item.cityCompany}}</td>
                    <td>{{item.projectName}}</td>
                    <td><span class="blue hand" @click="handleOpenDetail(item)">{{item.applyTheme}}</span></td>
                    <!--<td v-if="tab == 1">{{item.addRate|percent}}</td>-->
                    <td>{{item.supplierName}}</td>
                    <td>{{item.paymentType}}</td>
                    <td v-if="operateApproval">
                        <template v-if="tab == 1">
                            <div>{{item.creTmDate}}</div>
                            <div>{{item.creTmTime}}</div>
                        </template>
                        <template v-if="tab == 3">
                            <div>{{item.SubmitTmDate}}</div>
                            <div>{{item.SubmitTmTime}}</div>
                        </template>
                    </td>
                    <td v-if="tab == 1">{{item.payablesAmtApply | formatMoney}}</td>
                    <td v-if="tab == 3">{{item.taskDisc}}</td>
                    <td style="text-align: right;padding-right: 0;">
                        <template v-if="tab == '1'">
                            <!--<template v-if="item.taskId != 'operation_apply' && item.executionRole != '1003'">-->
                            <template v-if="item.taskId != 'operation_apply'">
                                <el-button type="primary" @click="handleOpenDetail(item)">审批</el-button>
                            </template>
                            <template v-else>
                                <template v-if="item.sysCode != 'USER_INPUT' || item.executionStatus != '发起审批'">
                                    <el-button type="primary" @click="handleApprovalConfirm(item)" v-if="item.applyFlg == '2'">审批</el-button>
                                    <el-button type="primary" @click="handleImprovePaymentInfo(item)" v-else>完善信息</el-button>
                                    <!--<el-button @click="handleClose(item)">关闭</el-button>-->
                                    <div class="blue pointer" @click="handleOpenDetail(item)">查看详情</div>
                                </template>
                                <template v-else>
                                    <el-button type="primary" @click="handleImprovePaymentInfo(item,'USER_INPUT')">完善信息</el-button>
                                </template>
                            </template>
                        </template>
                        <template v-else>
                            <el-button v-if="tab == '3' && operateApproval && item.status == 'processing'" @click="handleCanceled(item)">撤回</el-button>
                            <div class="blue pointer" @click="handleOpenDetail(item)">查看详情</div>
                        </template >
                        <div class="blue pointer" v-if="item.sysCode != 'USER_INPUT' || item.executionStatus != '发起审批'" @click="handleBatchDownload(item)">审批资料下载</div>
                    </td>
                </tr>
                <tr class="retreat" v-if="tab == 1 && item.status == 'rejected'">
                    <td colspan="8">退回原因：{{item.comment}}</td>
                    <td colspan="1" style="text-align: left;text-indent:0"><span>退回人：{{item.acctName}}</span></td>
                </tr>
                <!--<tr class="retreat" v-if="tab == 1 && item.status == 'rejected' && item.procDefKey=='CONTRACT_TERMINATE_BROKER_WF'">-->
                    <!--<td colspan="5">供应商拒绝解除合同原因：{{item.comment}}</td>-->
                <!--</tr>-->
                <!--<tr class="retreat" v-if="tab == 1 && item.fwStatus == '1' || item.fwStatus == '2' || item.fwStatus == '3'">-->
                    <!--<td :colspan="tab == 1?4:5" :title="item.comment"> {{item.fwStatus == '3' ? '转发留言：' : '批注：'}}{{item.comment}}</td>-->
                    <!--<td colspan="1" style="text-align: left;text-indent:0"><span :title="item.acctName">{{item.fwStatus == '3' ? '转发人：' : '批注人：'}}{{item.acctName}}</span></td>-->
                <!--</tr>-->
                </tbody>

                <!--</template>-->
            </table>
            <!--抄送流程-->
            <table v-if="tab == 4">
                <thead>
                <tr>
                    <th width="120px">城市公司</th>
                    <th width="150px">项目名称</th>
                    <th width="300px">请款主题</th>
                    <th width="150px">请款事由</th>
                    <th width="120px">发起审批日期</th>
                    <th width="80px" style="text-align: center">操作</th>
                </tr>
                </thead>
                <!--<template v-if="productList.length">-->
                <tbody v-for="(item,index) in pmtApproveInfos" :key="index" class="tbody-row">
                <tr>
                    <td>{{item.cityCompany}}</td>
                    <td>{{item.projectName}}</td>
                    <td><span>《{{item.applyTheme}}》</span></td>
                    <td><span>{{item.paymentType}}</span></td>
                    <td>{{item.approvalStartDate}}</td>
                    <td style="text-align: right">
                        <div v-if="item.procDefKey!='CONTRACT_TERMINATE_BROKER_WF'"><span class="blue pointer" @click="handleOpenDetail(item)">查看详情</span></div>
                    </td>
                </tr>
                <tr class="retreat" v-if="tab == 1 && item.status == 'rejected' && item.procDefKey!='CONTRACT_TERMINATE_BROKER_WF'">
                    <td colspan="5">退回原因：{{item.comment}}</td>
                    <td>退回人：{{item.acctName}}</td>
                </tr>
                </tbody>
                <!--</template>-->
            </table>

            <div class="table-pagination" v-if="brokerApprovalList.length">
                <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
                </el-pagination>
            </div>

            <!--空列表-->
            <div class="product-empty" v-if="!brokerApprovalList.length&&!isLoading">
                <img src="@/assets/images/icon-no-product.png">
                <p>没有搜索到相关合同，请重新修改搜索条件搜索！</p>
            </div>
        </div>
        <!-- 批量确认审批合同 -->
        <el-dialog class="dialog" title="确认并进行合同审批" :append-to-body="true" :lock-scroll="true" :visible.sync="batchApproavlDialogVisible" width="840px" center :close-on-click-modal="false" @close="handleClear()">
            <div class="line-top"></div>
            <div class="f14 tl">确认进行已勾选的<em class="red">{{selectedSignLength}}</em>份合同审批</div>
            <div class="contract-list tl">
                <p v-for="item in signbrokerApprovalList">{{item.applyTheme}}</p>
            </div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="comment" placeholder="请填写批量审批或退回的原因,300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirmDialog('Y')">批量同意</el-button>
                <!--<el-button type="primary" size="small" style="width: 100px" @click="rejectedDialogVisible = true;batchApproavlDialogVisible=false">批量退回</el-button>-->
                <el-button :disabled="!comment" type="primary" size="small" style="width: 100px" @click="handleConfirmDialog('N')">批量退回</el-button>
                <el-button size="small" style="width: 100px" @click="batchApproavlDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!--审批退回-->
        <el-dialog class="dialog" title="批量退回原因" :append-to-body="true" :lock-scroll="true" :visible.sync="rejectedDialogVisible" width="840px" center :close-on-click-modal="false" @close="entryNum = 0;rejectedReason = ''">
            <div class="line-top"></div>
            <div class="f14" style="text-align: left">请填写批量退回的原因</div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="rejectedReason" placeholder="请填写批量退回的原因,300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" :disabled="!rejectedReason" size="small" style="width: 100px" @click="handleConfirm('N')">批量退回</el-button>
                <el-button size="small" style="width: 100px" @click="rejectedDialogVisible = false;batchApproavlDialogVisible=true">取消</el-button>
            </div>
        </el-dialog>
        <!--审批结果-->
        <el-dialog class="sign-result-dialog" :title="approvalOrReject+'结果'" :append-to-body="true" :lock-scroll="true" :visible.sync="approavlResultDialogVisible" width="840px" center :close-on-click-modal="false" @close="getApprovalList">
            <div class="line-top" style="top:50px"></div>
            <div style="width: 354px;text-align: left">
                <div v-if="signFailNum > 0">
                    <div class="f14 bold"><em class="red">{{selectedSignLength}}</em>份合同{{approvalOrReject}}成功，<em class="red">{{signFailNum}}</em>份合同{{approvalOrReject}}失败。</div>
                    <div class="fail-reason-list">失败原因：{{failReasonList.join('；')}}。
                    </div>
                    <div style="color:#bbb">{{approvalOrReject}}失败的合同可以在【待处理】栏查看。</div>
                </div>
                <div class="f14 bold" v-if="signFailNum == 0">批量{{approvalOrReject}}成功！{{approvalOrReject}}成功的合同可在【已处理】栏内查看</div>
                <div v-if="signFailNum > 0">※若有疑问请联系平台客服：<em class="blue">{{$platformContact()['hotLine']}} {{$platformContact()['hotLineTime']}}</em></div>
            </div>
            <div class="sign-result">
                <el-button @click="approavlResultDialogVisible=false" size="mini" style="border: 1px solid #000;background: #fff">知道了</el-button>
            </div>
         </el-dialog>
        <!--关闭审批-->
        <el-dialog class="dialog" title="关闭原因" :append-to-body="true" :lock-scroll="true" :visible.sync="closeApproavlDialogVisible" width="840px" center :close-on-click-modal="false" @close="entryNum = 0;closeReason = ''">
            <div class="line-top"></div>
            <!--<div class="f14" style="text-align: left;margin-bottom: 10px;">关闭后，系统会将关闭原因反馈给合同创建人。</div>-->
            <div class="f14" style="text-align: left">请填写关闭原因：</div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="closeReason" placeholder="请填写关闭原因,300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button :disabled="!closeReason" type="primary" size="small" style="width: 100px" @click="handleCloseConfirm('approval')">提交关闭</el-button>
                <el-button size="small" style="width: 100px" @click="closeApproavlDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!--确认撤回审批-->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="cancleApproavlDialogVisible" width="840px" center :close-on-click-modal="false" :show-close="false">
            <div class="f14 form-btns" style="margin-bottom: 10px">确认要撤回合同审批？撤回后的合同，在【待处理】中查看。</div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleCanceledConfirm()">确定撤回</el-button>
                <el-button size="small" style="width: 100px" @click="cancleApproavlDialogVisible = false">取消</el-button>
            </div>
         </el-dialog>
        <!--发起单个审批-->
        <BrokerPaymentApproval ref="brokerPaymentApproval" @goBack = "goBack" @refresh="handleCloseApproval(true)"></BrokerPaymentApproval>
        <!--完善信息-->
        <ImprovePaymentInfo ref="improvePaymentInfo" @close="handleCloseImproveInfo"></ImprovePaymentInfo>
        <!--资料下载-->
        <!-- 合同签章 -->
        <Loading :is-loading="isLoading"></Loading>
        <el-dialog class="dialog dialog-drafts" title="签字意见" :append-to-body="true" :lock-scroll="true" :visible.sync="isShwoAnnotationDialog" width="840px" center :close-on-click-modal="true">
            <div class="dialog-annotation">
                <el-input type="textarea" placeholder="请填写签字意见" v-model="signaturePpinion" maxlength="300"> </el-input>
                <div class="btn-container">
                    <el-button type="primary" size="small" style="width: 100px"  @click="handleClickSubmitAnnotation">
                        提交
                    </el-button>
                    <el-button size="small" style="width: 100px" @click="isShwoAnnotationDialog = false"
                        >取消
                    </el-button>
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    import accountMixin from "@/mixins/account";
    import Loading from "@/components/base/Loading";
    import PanelTitle from "@/components/base/PanelTitle";
    import BrokerPaymentApproval from "@/components/order/broker/dialog/BrokerPaymentApproval";
    import { InterfaceService } from "@/services/api";
    import ImprovePaymentInfo from "@/components/order/broker/dialog/ImprovePaymentInfo";
    import download from "@/utils/download";
    import {DateUtil} from '@/utils/dateUtil';

    const params = {
        procDefKeyList: ["PMT_APPROVE_WF",],
        projectName:"",
        cityCompany:"",
        supplierName:"",
        paymentType:"",
        year:"",
        season:"",
        tab:"",
        executionStatus:"",
        pageIndex: 1,
        approveStatus:"",
        pageSize:10,
        applyTheme: '', // 搜索
        orderCateCode: '', // 搜索
        majorCode: '', // 搜索
        isDraft: '',
    };

    export default {
        mixins: [accountMixin],
        components: {
            Loading,
            PanelTitle,
            BrokerPaymentApproval,
            ImprovePaymentInfo
        },
        data() {
            return {
                tab: "",
                titleButton: "",
                tabs: [
                    { label: "待处理", index: "1"},
                    { label: "已处理", index: "3" },
                ],
                form: Object.assign({}, params),
                allChecked: true,
                disableAllCheck: false,
                hasChecked: true,
                categoryList: [],
                total: 0,
                isLoading: false,
                signbrokerApprovalList:[],
                brokerApprovalList:[],
                pmtApproveInfos:[],
                batchApproavlDialogVisible:false,
                selectedSignLength:0,
                projectList:[],
                supplierNameList:[],
                cityCompanyList:[],
                paymentTypeList:[],
                externalSysList:[],
                approavlResultDialogVisible:false,
                closeApproavlDialogVisible:false,
                cancleApproavlDialogVisible:false,
                rejectedDialogVisible:false,
                signFailNum:"",
                signResultTitle:"",
                seasonList:[
                    {season:"全部季度",value:""},
                    {season:"第一季度",value:"1"},
                    {season:"第二季度",value:"2"},
                    {season:"第三季度",value:"3"},
                    {season:"第四季度",value:"4"},
                ],
                executionId:"",
                canceleExecutionId:"",
                closeExecutionId:"",
                rejectedReason:"",
                rejectedRemind:"0",
                closeReason:"",
                comment:"",
                closeProcDefKey:"",
                contractApproval:false,
                operateApproval:false,
                financeApproval:false,
                managerApproval:false,
                ccTabVisible:"0",
                approvalOrReject:"",
                ccTabVisibleType:true,
                entryNum:0,
                failReasonList:[],
                majorList:[],
                isShwoAnnotationDialog: false, // 是否显示批注弹窗
                fixedhead: false, // 是否显示固定表头
                signaturePpinion: '', // 签字意见
                annotationExecutionId: '', // 批注 -流程实例ID
                canceleProcDefKey: '', // 批注 -流程实例ID
            };
        },
        computed: {
            isShowAnnotation() {
              return (item) => {
                let state = false;
                if (this.$store.state.userInfo.roleIds[0].roleId == item.fwRole && item.fwStatus == '3') {
                    state = true
                }
                return state;
              }

            }
        },
        filters: {
            percent(val) {
                return (val * 100)+ "%";
            }
        },
        methods: {
            // 修改tab
            handleChangeTab(tab) {
                this.tab = tab.index;
                let date = new Date;
                let year = date.getFullYear();
                this.recoverStatus(this.tab);
                // 进入已处理时间默认显示当前年份
                this.tab == "3" || this.tab == "4" ? this.form.year = String(year) : this.form.year = "";
                this.form.pageIndex = 1
                this.getApprovalList();
            },
            // 查看详情
            handleOpenDetail(item) {
                console.log(item);
                if (this.tab == "1" && item.executionStatus === "发起审批" && item.sysCode === "USER_INPUT" && this.operateApproval) {
                    this.$router.push({
                        path : '/createPayment',
                        query: {
                            executionId: item.executionId,
                        }
                    });
                }else {
                    let executionId = item.executionId,
                        orderNo = item.orderNo,
                        procDefKey = item.procDefKey,
                        fwStatus = item.fwStatus,
                        operateApproval = this.operateApproval;

                    const { href } = this.$router.resolve({
                        path: "/brokerPaymentDetail",
                        query: {
                            executionId,
                            orderNo,
                            procDefKey,
                            fwStatus,
                            operateApproval,
                        },
                    });
                    window.open(href, '_blank');
                }
            },
            // 全选
            handleAllSelectTableRow(bool) {
                let arr = [];
                arr = [].concat(this.pmtApproveInfos);
                console.log(this.conItractApproveInfos);
                arr.forEach(item => {
                    item.checked = bool;
                });
                if (arr.length != 0){
                    this.pmtApproveInfos = arr;
                }else {
                    this.allChecked = false
                }
                this.checkBatch();
            },
            // 选中行
            handleSelectTableRow(item, index) {
                this.$set(this.pmtApproveInfos, index, item);
                this.checkBatch();
                this.checkAllSelect();
            },

            // 刷新列表
            // 批量确认合同弹窗
            handleBatchOrderConfirm() {
                this.batchApproavlDialogVisible = true;
                const signbrokerApprovalList = [];
                this.pmtApproveInfos.forEach(item => {
                    if (item.checked) {
                        signbrokerApprovalList.push(item);
                    }
                });
                this.signbrokerApprovalList = signbrokerApprovalList;
                this.selectedSignLength = this.signbrokerApprovalList.length
            },
            handleImprovePaymentInfo(item,type){
                if (type === 'USER_INPUT') {
                    this.$router.push({
                        path : '/createPayment',
                        query: {
                            executionId: item.executionId,
                        }
                    });
                }else {
                    this.$refs["improvePaymentInfo"].open("showAll",item.executionId,item.procDefKey);
                }

            },
            //
            handleApprovalConfirm(item){
                console.log(item);
                this.$refs["brokerPaymentApproval"].open(item);
            },
            /**
             * 流转意见 - 批注
             */
            handleAnnotation(item) {
                console.log(item,'--i')
                this.annotationExecutionId = item.executionId
                this.signaturePpinion = ''
                this.isShwoAnnotationDialog = true
            },

            /**
             *  流转意见 - 批注 - 提交
             */
            handleClickSubmitAnnotation() {
                this.handleConfirm('Annotation');
                // this.$message.success('批注操作成功!')
                this.isShwoAnnotationDialog = false;
            },
            handleConfirmDialog(type){
                let content = "";
                let message = "";
                if (type == "Y") {
                    content = "确认批量审核吗？";
                    message = "批量审核成功！"
                } else if (type == "N") {
                    content = "确认批量退回吗？";
                    message = "批量退回成功！";
                }
                this.$confirm(
                    content,
                    {
                        cancelButtonClass: "btn-custom-cancel",
                        confirmButtonClass: "btn-custom-confirm",
                        center: true,
                        type: 'warning',
                        confirmButtonText: "确认",
                        cancelButtonText: '取消',
                    }).then(() => {
                    this.handleConfirm(type);
                })
            },
            // 审批，非发起审批
            handleConfirm(type){
                let executionList = [];
                if (!this.comment) {
                    this.comment = "同意"
                }
                //同意
                if (type == 'Y'){
                    this.signbrokerApprovalList.forEach(item=>{
                        executionList.push({
                            executionId: item.executionId,
                            isAgree: "Y",
                            comment: this.comment,
                            procDefKey : "PMT_APPROVE_WF",
                        })
                    });
                // 退回
                }else if (type == 'N') {
                    this.signbrokerApprovalList.forEach(item=>{
                        executionList.push({
                            executionId: item.executionId,
                            isAgree: "N",
                            comment:this.comment,
                            procDefKey : "PMT_APPROVE_WF",
                        })
                    });
                } else if (type === 'Annotation') {
                    executionList.push({
                            executionId: this.annotationExecutionId || '',
                            isAgree: "Y",
                            comment: this.signaturePpinion || ''
                    })
                }

                const params = {
                    executionList: executionList
                };
                InterfaceService.batchApprovalProcess(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            this.approvalResult = data.respData.respList;
                            let failNum = 0;                              // 批量审批失败的数量
                            let successNum = 0;
                            let hash=[];
                            this.failReasonList = [];
                            this.approvalResult.forEach(item=>{
                                console.log(item.approveCode);
                                if (item.approveCode == "0000"){
                                    successNum ++;
                                } else {
                                    failNum ++;
                                    hash.push(item.approveMsg);
                                }
                            });
                            //  审批失败时返回的Msg去重
                            for (let i = 0; i < hash.length; i++) {
                                for (let j = i+1; j < hash.length; j++) {
                                    if(hash[i]===hash[j]){
                                        ++i;
                                    }
                                }
                                this.failReasonList.push(hash[i]);
                            }
                            if (failNum == 0) {
                                 let msg = ''
                                if(type === 'Annotation') {
                                    msg = "批注成功!";
                                } else {
                                    msg = "批量审批操作成功";
                                    type == 'Y' ? msg : msg = "批量退回操作完成";
                                }
                                this.$message.success(msg);
                                this.getApprovalList();
                            } else {
                                type == 'Y' ? this.approvalOrReject = "审批" : this.approvalOrReject = "退回";
                                this.approavlResultDialogVisible = true;
                            }
                            this.signFailNum = failNum;
                            this.selectedSignLength = successNum;
                            this.rejectedReason = "";
                            this.batchApproavlDialogVisible = false;
                            this.rejectedDialogVisible = false;
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            // 审批撤回弹窗
            handleCanceled(item){
                this.cancleApproavlDialogVisible = true;
                this.canceleExecutionId = item.executionId;
                this.canceleProcDefKey = item.procDefKey;
            },
            // 关闭流程弹窗
            handleClose(item){
                this.closeApproavlDialogVisible = true;
                this.closeExecutionId = item.executionId;
                this.closeProcDefKey = item.procDefKey;
            },
            //  确认撤回
            handleCanceledConfirm(){
                const params = {
                    executionId : this.canceleExecutionId,
                    procDefKey : this.canceleProcDefKey
                };
                InterfaceService.revokeApprovalProcess(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message.success("撤回成功");
                            this.form.pageIndex = 1;
                            this.getApprovalList();
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
                this.cancleApproavlDialogVisible = false;

            },
            //  确认关闭
            handleCloseConfirm(type){
                let params = {};
                if (type == "approval") {
                    if (this.closeExecutionId) {
                        params = {
                            executionId : this.closeExecutionId,
                            procDefKey: this.closeProcDefKey,
                            comment: this.closeReason,
                        };
                    }
                }
                InterfaceService.closeApprovalProcess(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                                this.$message.success("关闭成功");
                                this.closeApproavlDialogVisible = false;
                                this.closeReason = "";
                            this.form.pageIndex = 1;
                            this.getApprovalList();
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },

            handleCloseApproval(bool) {
                if (bool) {
                    // this.form.pageIndex = 1;
                    this.getApprovalList()
                }
            },
            goBack(id,key){
                if (id && key) {
                    let data = {
                        executionId : id,
                        procDefKey : key,
                    };
                    this.handleImprovePaymentInfo(data);
                }
            },
            handleCloseImproveInfo(bool,data){
                if (bool && data) {
                    this.$refs["brokerPaymentApproval"].open(data);
                }
                this.form.pageIndex = 1;
                this.getApprovalList()
            },
            //资料下载
            handleBatchDownload(item) {
                let DownloadExecutionId = "";
                DownloadExecutionId = item.executionId;
                if (!DownloadExecutionId) {
                    return
                }else {
                    const params = {
                        executionId: DownloadExecutionId,
                        procDefKey:item.procDefKey
                    };
                    InterfaceService.approvalDataDownload(
                        params,
                        data => {
                            if (data.respData.respCode === "0000") {
                                let packingUrl = data.respData.attachUrl;
                                if (!packingUrl){
                                    this.$message.error("暂无审批资料");
                                    return
                                }
                                window.open(packingUrl, "_blank");
                            } else {
                                this.$message.error(data.respData.respMsg);
                            }
                        },
                        data => {},
                        () => {
                            this.isLoading = true;
                        },
                        () => {
                            this.isLoading = false;
                        }
                    )
                }
            },
            handleClear(){
                this.comment = "";
                this.entryNum = 0
            },
            // handleChangeMajor(code) {
            //     console.log(code);
            // },
            // handleChangeCate(ev){
            //     if (ev) {
            //         this.categoryList.forEach(cate=>{
            //             if (cate.key == ev) {
            //                 this.majorList = cate
            //             }
            //         })
            //     }else {
            //         // this.handleChangeMajor()
            //         this.majorList = [];
            //     }
            //     this.form.majorCode = ""
            // },
            handleEntry(ev){
                this.entryNum = ev.length
            },
            // 分页跳转
            handleCurrentChange(page) {
                this.form.pageIndex = page;
                this.getApprovalList();
                window.scrollTo(0,0);
            },
            // 创建请款
            handleCreatePayment(type){
                this.$router.push({
                    path : '/createPayment',
                    query: {
                        type : type
                    }
                });
            },
            //进行中、关闭、完结状态
            changeExecutionStatus(type){
                if (type == "1") {
                    this.form.executionStatus = null;
                    this.form.isDraft = type
                }else {
                    this.form.executionStatus = type;
                    this.form.isDraft = "";
                }
                if (type == "rejected") {
                    this.UpdateCacheInfos()
                }
                this.form.pageIndex = 1;
                this.getApprovalList()
            },
            UpdateCacheInfos(){
                let params = {
                    userCaches:[{
                        targetId:"1003",
                        key:"PAYMENT_REJECTED_CACHE_KEY",
                        value:"0",
                    }]
                };
                // this.rejectedRemind = false
                InterfaceService.UpdateCacheInfos(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.rejectedRemind = "0"
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            //全部、ERP状态
            changeApproveStatus(type){
                this.form.approveStatus = type;
                this.form.pageIndex = 1;
                this.getApprovalList()
            },
            // 是否全选
            checkAllSelect() {
                this.allChecked = this.pmtApproveInfos.every(item => {
                    return item.checked;
                });
            },
            // 是否可批量
            checkBatch() {
                this.hasChecked = this.pmtApproveInfos.some(item => {
                    return item.checked;
                });
                let num = 0;
                this.pmtApproveInfos.forEach(item=>{
                    if (item.checked){
                        num++
                    }
                });
                this.selectedSignLength = num
            },
            // 恢复状态
            recoverStatus(tab) {
                this.form.tab = tab;
                this.form.executionStatus = "";
                this.form.approveStatus = "";
                this.form.projectName="";
                this.form.cityCompany="";
                this.form.supplierName="";
                this.form.year="";
                this.form.season="";
                this.form.applyTheme = "";
                this.form.paymentType = "";
                this.form.isDraft = "";
                this.form.pageIndex = 1;
            },
            // 待签署合同
            init() {
                this.getcTabVisible();
                this.getAccountInfo();
                // this.getCategoryList();
                // this.getApprovalList();
            },
            //获取是否有新增被退回信息
            getCacheInfos(){
                let params = {
                    "targetId":"1003",
                    "key":"PAYMENT_REJECTED_CACHE_KEY",
                };
                // this.rejectedRemind = true
                InterfaceService.getCacheInfos(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.rejectedRemind = data.respData.value || "0"
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            //第一次去看是否抄送可见
            getcTabVisible(){
                let params = {
                    "procDefKeyList":["PMT_APPROVE_WF"],
                    "tab":"1",
                    "pageIndex":1
                };

                InterfaceService.getApprovalList(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.brokerApprovalList = data.respData.executionList || [];
                            this.ccTabVisible = data.respData.ccTabVisible;
                            this.ccTabVisibleType = this.ccTabVisible == "1";
                            if (this.ccTabVisibleType) {
                                this.tabs = [
                                    { label: "流程抄送", index: "4" , active: true},
                                ];
                                this.tab = "4";
                                this.form.tab = "4"
                            }else {
                                this.tabs = [
                                    { label: "待处理", index: "1"},
                                    { label: "已处理", index: "3" },
                                ];
                                this.tab = "1";
                                this.form.tab = "1";
                            }
                            this.getApprovalList();
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            getAccountInfo(){
                this.roleIds.forEach(role=> {
                    //招采部
                    if (role.roleId == "1002") {
                        this.contractApproval = true;
                    }
                    //工程部
                    if (role.roleId == "1003") {
                        this.operateApproval = true;
                        this.titleButton = "创建请款审批"
                    }
                    // //财务部
                    if (role.roleId == "1004" ) {
                        this.financeApproval = true;
                    }
                    if (role.roleId == "1001") {
                        this.managerApproval = true
                    }
                })
            },
            getApprovalList() {
                this.pmtApproveInfos = [];
                // this.total = 0;
                let params = {};
                params = this.$clone(this.form);
                this.tabs.forEach((item) => {
                    if (item.index == this.tab) {
                        item.active = true
                    }
                });
                delete params.status;
                InterfaceService.getApprovalList(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.brokerApprovalList = data.respData.executionList || [];
                            this.brokerApprovalList.forEach(item => {
                                let infos = item.pmtApproveInfos
                                infos.executionId = item.executionId;
                                // infos.executionStatus = item.executionStatus;
                                infos.procDefKey = item.procDefKey;
                                infos.taskId = item.taskId;
                                infos.executionRole = item.executionRole;
                                if (item.creTm) {
                                    infos.SubmitTmDate = item.creTm.substring(0,10);
                                    let startIndex = item.creTm.length-8;
                                    let endIndex = item.creTm.length;
                                    infos.SubmitTmTime = item.creTm.substring(startIndex,endIndex)
                                }
                                if (item.executionCreatTm) {
                                    infos.creTmDate = item.executionCreatTm.substring(0,10);
                                    let startIndex = item.executionCreatTm.length-8;
                                    let endIndex = item.executionCreatTm.length;
                                    infos.creTmTime = item.executionCreatTm.substring(startIndex,endIndex)
                                }
                                if (item.comment){
                                    infos.comment = item.comment;
                                    infos.acctName = item.acctName
                                }
                                // 整理状态
                                if (item.taskId == "operation_apply") {
                                    infos.taskDisc = "工程部审批"
                                }else if (item.taskId == "contract_confirm") {
                                    infos.taskDisc = "招采合约部审批"
                                }else if (item.taskId == "finance_confirm") {
                                    infos.taskDisc = "财务部审批"
                                }else if (item.taskId == null) {
                                    infos.taskDisc = "审批完成"
                                }
                                //   fwStatus	String	转发状态,1:转发，2：被转发（流程表）
                                infos.fwStatus = item.fwStatus
                                infos.fwRole = item.fwRole
                                if (item.procDefKey == "PMT_APPROVE_WF") {
                                    if (item.executionStatus == 'processing'){
                                        infos.status = "processing";
                                        infos.disc = "进行中";
                                    }else if (item.executionStatus == 'end') {
                                        infos.status = "end";
                                        infos.disc = "已归档"
                                    }else if (item.executionStatus == 'closed'){
                                        infos.status = "closed";
                                        infos.disc = "已关闭"
                                    }else if (item.executionStatus == 'rejected'){
                                        infos.status = "rejected"
                                        infos.disc = "已退回";
                                    }else if (item.executionStatus == 'canceled'){
                                        infos.disc = "已撤回";
                                        infos.status = "canceled"
                                    }else if (item.executionStatus == 'forward'){
                                        infos.disc = "转发中";
                                        infos.status = "forward"
                                    }
                                }
                                this.pmtApproveInfos.push(infos)
                            });
                            this.pmtApproveInfos.forEach(item=>{
                                if (item.taskId != 'operation_apply') {
                                    item.checked = true;
                                }
                            });
                            this.allChecked = this.brokerApprovalList.some(item => {
                                return item.executionStatus == 'processing';
                            });
                            // this.selectedSignLength = num;
                            if (this.pmtApproveInfos.length == 0){
                                this.allChecked = false;
                                this.hasChecked = false
                            }else {
                                this.allChecked = true;
                                this.hasChecked = true
                            }
                            this.projectList = data.respData.projectNameList || [];
                            this.cityCompanyList = data.respData.cityCompanyList || [];
                            this.supplierNameList = data.respData.supplierNameList || [];
                            this.paymentTypeList = data.respData.paymentTypeList || [];
                            this.total = data.respData.totalCount;
                            this.form.pageSize = data.respData.pageSize;
                            if (this.operateApproval && this.tab == "1") {
                                this.getCacheInfos()
                            }
                            console.log(this.pmtApproveInfos);
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            /**
             * 查询
             */
            handleSearch() {
                this.form.pageIndex = 1;
                this.getApprovalList();
            },
            getCategoryList() {
                this.categoryList = this.$store.state.categoryList
                return this.$store.state.categoryList
            },
            onScroll(){
                let top = this.$refs["head"] && (this.$refs["head"].getBoundingClientRect().top || 0);
                this.fixedhead = top < 0;
            },
        },
        mounted() {
            if (!this.brokerRole) {
                if (this.role == 'B'){
                    this.$router.push({
                        path : '/purchaserCenter/orderList'
                    });
                }else if (this.role == 'S'){
                    this.$router.push({
                        path : '/vendorCenter/orderList'
                    });
                }
            }else {
                this.init();
                this.$nextTick(function () {
                    setTimeout(()=>{
                        window.addEventListener('scroll', this.onScroll)
                    },500)
                })
            }
        },
        destroyed: function () {
            window.removeEventListener('scroll', this.onScroll)
        }
    };
</script>

<style lang="scss" scoped>
    .hand + .hand {
        margin-left: 10px;
    }
    .price-tip {
        cursor: pointer;
        color: #a9a9aa;

        &:hover {
            color: #0082ff;
        }
    }

    .product {
        font-size: 14px;
        .headSearchContainer {
            display: flex;
            .search-title {
                width: 87px;
            }
        }
        /deep/ .el-select {
            width: 100%;
        }
        /deep/ .el-col{
            height: 50px;
            margin-bottom: 10px;
            .el-button.active{
                background: #ffd64e;
            }
        }
        /deep/ .el-button--primary {
            height: 40px;
            width: 106px;
        }
        .search-title {
            margin-top: 12px;
            display: block;
            margin-left: 10px;
        }
    }

    .pointer {
        cursor: pointer;
        &:hover {
            color: #0082ff;
        }
        &:active {
            color: #4c9cdd;
        }

        .active {
            color: #ffd64e;
        }
    }

    .nowrap {
        white-space: nowrap;
    }

    .panel-content {
        margin-bottom: 20px;
        padding: 20px 10px;
        background: #f5f5f5;
    }

    .form {
        /deep/ .el-col {
            text-align: left;
            height: 52px;
        }
        /deep/ .el-select {
            width: 100%;
        }
        /deep/ .el-date-editor {
            input.el-input__inner {
                padding: 0 15px;
            }
            .el-input__prefix {
                display: none;
            }
        }

        &:after {
            display: table;
            content: "";
            clear: both;
        }
        /deep/ .third-col{
            .el-form-item__label {
                width: 110px !important;
            }
            .el-form-item__content{
                margin-left: 110px !important;
            }
            .el-input__inner{
                width: 120px;
            }
        }
    }

    .form-item {
        position: relative;
        display: inline-block;
        line-height: 32px;

        .float-right {
            position: absolute;
            top: 2px;
            right: 1px;
            height: 30px;
            padding: 0 7px;
            line-height: 30px;
            background: #ffffff;
        }
    }
    .secondCate{
        /deep/ .el-form-item__content{
            width: 197px;
            margin-left: 22px !important;
        }
    }

    .error-info {
        color: #f56c6c;
        font-size: 12px;
        line-height: 1;
        padding-top: 4px;
        position: absolute;
        top: 100%;
        left: 0;
    }

    .form-btns {
        text-align: center;
    }

    .product-table {
        /deep/ .el-table__body-wrapper {
            font-size: 12px;
        }
        .check-all{
            width: 100%;
            height: 70px;
            line-height: 70px;
            background: #535864;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 4px;
            em{
                color: #fa0202;
            }
            .check{
                span{
                    margin-left: 8px;
                }
                /deep/ .el-checkbox__inner::after{
                    border-bottom:2px #000 solid;
                    border-right:2px #000 solid;
                }
            }
            .sign{
                .el-button{
                    margin-left: 20px;
                    background: #ffd64e;
                    border: none;
                    width: 110px;
                    height: 34px;
                }
            }
        }
        .contract{
            span{
                color: #f00;
            }
        }
        /deep/ .el-table th,
        .el-table td {
            padding: 14px 0;
        }

        /deep/ .el-button {
            font-size: 12px;
        }

        table {
            table-layout: fixed;
            position: relative;
            width: 100%;
            line-height: 18px;
            font-size: 12px;
            td,th {
                padding: 6px 15px;
                vertical-align: middle;
                word-break: break-word;
                text-align: center;
                &:last-child {
                    padding-right: 0;
                }
            }
            thead {
                font-size: 14px;
                text-align: center;
                white-space: nowrap;
                color: #909399;
                background: #f5f5f5;
                width: 950px;
                th{
                    text-align: left;
                }
            }
            .fixedhead{
                width: 950px;
                position: fixed;
                top: 0;
                /*left: 0;*/
                height: 32px;
                background: #535864;
                color: #fff;
                span{
                    display: inline-block;
                    line-height: 32px;
                    padding-left: 6px;
                    font-size: 14px;
                }
            }
            .tbody-row{
                td{
                    text-align: left;
                }
                /deep/ .el-button{
                    height: 28px;
                    width: 80px;
                    padding: 0;
                    margin:0 0 4px;
                    span{
                        line-height: 28px;
                    }
                }
            }
            .tbody-row:hover {
                background: #e8f3fd;
            }

            tbody {
                text-align: center;
                tr {
                    &.sign-content {
                        display: none;
                        background: #f0f8ff;

                        &:hover {
                            display: table-row;
                        }

                        td {
                            padding: 0;
                            border-bottom: none;
                        }
                    }

                    &.all-check {
                        text-align: left;

                        &:hover{
                            background: #ffffff;
                        }
                    }
                }

                tr:hover + tr.sign-content {
                    display: table-row;
                }

                td {
                    border-bottom: 1px solid #ebeef5;
                }
                .retreat{
                    height: 20px;
                    td:nth-of-type(1){
                        width: 600px;
                    }
                    td{
                        background: #eee;
                        text-align: left;
                        padding: 0;
                        text-indent: 2em;
                        overflow:hidden;
                        white-space:nowrap;
                        text-overflow:ellipsis;
                    }
                }
            }
        }

        .product-name {
            display: inline-flex;
            width: 100%;
            vertical-align: top;
            line-height: 20px;

            img {
                width: 75px;
                height: 75px;
            }

            .left {
                margin-right: 10px;
            }

            .right {
                text-align: left;

                p:first-child {
                    margin-bottom: 10px;
                }
                p:last-child {
                    word-break: break-all;
                    max-height: 40px;
                    overflow: hidden;
                    color: #969799;
                }
            }
        }
    }

    .product-empty {
        padding: 150px;
        text-align: center;
        line-height: 50px;
        color: #909399;
    }

    .price-popover {
        display: flex;
        color: #ababac;

        > div:first-child {
            margin-right: 10px;
        }

        p:first-child {
            padding: 0 5px;
            border-left: 3px solid #ffd64e;
            line-height: 15px;
        }

        p:last-child {
            margin-top: 10px;
            color: #ffffff;
        }
    }

    .table-pagination {
        margin: 50px 0 80px;
        text-align: center;
        color: #888888;
    }
    /deep/ .el-dialog__title{
        font-size: 16px;
    }
    .contract-list{
        width: 800px;
        height: 286px;
        margin: 10px auto 10px;
        background: #eeeeee;
        overflow: auto;
        p{
            padding-left: 24px;
            height: 40px;
            line-height: 40px;
            border-bottom: 1px solid #fff;
        }
    }
    .order-sign {
        /*padding: 8px 15px;*/

        i {
            margin-right: 3px;
            margin-bottom: 3px;
            background-size: 100%;
            vertical-align: middle;
        }
    }
    /deep/ .el-pagination__jump{
        .el-input{
            width: auto;
        }
    }
    .sign-result-dialog{
        /deep/ .el-dialog__body{
            width: 100%;
        }
        .fail-reason-list{
            line-height: 25px;
        }
        div{
            margin: 20px auto 20px;
        }
        /deep/ .el-button{
            margin: auto;
        }
    }
    .sign-result{
        text-align: center;
        .el-button{
            background: #ffd64e;
            border: none;
            width: 110px;
            height: 34px;
            /*padding-top: 12px;*/
            font-weight: bold;
        }
    }
    .specifications-choose {
        overflow: hidden;
    }
    .specifications-choose ul {
        width: 604px;
        overflow: hidden;
    }
    .specifications-choose ul li {
        padding: 8px;
        float: left;
        line-height: 20px;
        border: 1px solid #dddddd;
        color: #4f525a;
        margin-right: 20px;
        position: relative;
        cursor: pointer;
    }
    .specifications-choose ul li.active {
        padding: 8px;
        border: 2px solid #4f525a;
    }
    .specifications-choose ul li.active:after {
        content: "";
        position: absolute;
        height: 25px;
        width: 25px;
        bottom: -2px;
        right: -2px;
        background: url(../../../assets/images/detail/right.png) no-repeat;
        z-index: 5;
    }
    /deep/ .el-dialog__header:before {
        height: 0;
    }
    .line-top{
        width: 95%;
        height: 1px;
        background: #eee;
        position: absolute;
        top:65px;
    }
    /deep/ .el-pagination__editor.el-input .el-input__inner{
        width: 45px;
    }
    .count{
        float: right;
        width: 100%;
        text-align: right;
        margin-bottom: 20px;
        span.red{
            color: #f00;
        }
    }
    /deep/.textareaContainer {
        .el-textarea__inner {
            min-height: 140px !important;
        }
    }
    .dialog-annotation {
        /deep/ .el-textarea .el-textarea__inner {
            resize: none;
            width: 100%;
            height: 90px !important;
        }
        .btn-container {
            margin-top: 24px;
            text-align: center;
            padding-bottom: 12px;
        }
    }
</style>




