<template>
  <div class="bidProduct">
    <!-- 中标商品页 -->
    <PanelTitle style="margin-bottom: 10px" :tabs="tabs" @select="handleChangeTab"></PanelTitle>
    <div class="list-home">
      <div class="list-content">
        <div class="panel" :style="{'margin-bottom' : userInfo.bs === 'B' && !brokerRole ? '0' : '30px'}">
          <el-form class="form" size="small" label-width="110px" type="flex" justify="space-between">
            <el-row style="overflow: initial;overflow: inherit">
              <el-col>
                <el-form-item>
                  <span slot="label"><i class="red">*</i>品类：</span>
                  <DropdownTree ref="dropdownTree" @categoryInfo="getCategoryInfo" :width="'890px'" :bodyWidth="'808px'"></DropdownTree>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row style="overflow: initial;overflow: inherit">
              <el-col>
                <MultipleSelectorAll ref="multipleSelectorAll" @getData="getSupplierData" :isSearch="true" :dataList="projectList" :width="1000" :paddingHight="8" :labelWidth="110" :pageSize="10" :totalCount="projectList.length" :label="'限定使用项目'" :placeholder="'请输入项目名称(可多选)'"></MultipleSelectorAll>
              </el-col>
            </el-row>
            <el-row>
              <el-col class="seatchW-width">
                <el-form-item label="商品名/型号：">
                  <el-input v-model.trim="skuNameOrModel" placeholder="请输入关键词" maxlength="64" clearable></el-input>
                </el-form-item>
              </el-col>
              <el-col class="seatchW-width">
                <el-form-item>
                  <span slot="label"><i class="red">*</i>供应商：</span>
                  <el-input v-model.trim="corpName" placeholder="请输入关键词" maxlength="64" clearable></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="商品模式：">
                  <el-radio-group v-model="prodMobel">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'BASE_PROD'">基础商品</el-radio>
                    <!-- <el-radio :label="'2'">固定组价商品</el-radio> -->
                    <el-radio :label="'COM_PROD'">组价商品</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
          <el-row>
            <el-col :span="24" align="center">
              <el-button class="small-btn" type="primary" size="small" @click="search()">搜索</el-button>
              <el-button class="small-btn" size="small" @click="clear()">清除</el-button>
              <el-button v-if="pageTag == '0'" class="small-btn" size="small" style="width: 80px;padding: 6px 0px !important;text-align: center;" :disabled="!isExport" :class="{'isDisabled':!isExport}" @click="downloadSupplierGoodsTemp()">导出查询结果</el-button>
            </el-col>
          </el-row>
        </div>
        <el-row>
          <el-col :span="12" v-if="userInfo.bs == 'S' || brokerRole">
            <el-checkbox v-model="allChecked" :disabled="!ownerProdBeanList.length" style="margin: 0 10px" @change="handleAllSelectTableRow">全选</el-checkbox>
            <el-button class="small-btn" type="primary" :disabled="!hasChecked ||ownerProdBeanList.every(i=> !i.checked)" size="small" @click="handleBatchOper('batch')">{{pageTag == '0' ? '批量下架' : '批量上架'}}</el-button>
          </el-col>
        </el-row>
        <TableThead :TopDistance="460" width="1020" left="240">
          <tr slot="tr">
            <td width="38px" v-if="userInfo.bs == 'S' || brokerRole"></td>
            <td>商品名称/型号</td>
            <td width="150px" class="tr">单价(不含税)(元)</td>
            <td width="170px">品类</td>
            <td width="114px">供应商简称</td>
            <td width="230px" class="tl">限定使用项目</td>
            <td v-if="userInfo.contractCorpType === 'broker'" width="96px">操作</td>
          </tr>
        </TableThead>
        <table class="table-default">
          <thead>
            <tr>
              <td width="38px" v-if="userInfo.bs == 'S' || brokerRole"></td>
              <td>商品名称/型号</td>
              <td width="150px" class="tr">单价(不含税)(元)</td>
              <td width="170px">品类</td>
              <td width="114px">供应商简称</td>
              <td width="230px" class="tl">限定使用项目</td>
              <td v-if="userInfo.contractCorpType === 'broker'" width="96px">操作</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in ownerProdBeanList" :key="ind">
            <tr>
              <td v-if="userInfo.bs == 'S' || brokerRole">
                <el-checkbox v-model="item.checked" @change="handleSelectTableRow(item,ind)"></el-checkbox>
              </td>
              <td style="display: flex;align-items: center;">
                <div class="skuName">
                  <div class="attachImg" :class="{'active':!item.attUrl}">
                    <img v-if="item.attUrl" :src="item.attUrl" alt="">
                  </div>
                  <div class="model">
                    <p class="f12 ellipsisTwo blue-pointer" :title="item.skuName" @click="handleGoproduct(item)">{{item.skuName}}</p>
                    <p class="f12" style="margin-top: 10px">型号：{{item.model ? item.model : '-'}}</p>

                    <p style="margin-top: 10px" v-if="item.specifications && item.specifications.length < 6">规格：{{item.specifications}}</p>
                    <el-popover popper-class="dark-popover" trigger="hover" placement="top" v-else-if="item.specifications && item.specifications.length >= 6">
                      <div style="color: #fff;width: 500px">
                        规格：{{item.specifications}}
                      </div>
                      <p style="margin-top: 10px" slot="reference" v-if="$isIE()">规格：{{item.specifications.slice(0,6) + "..."}}</p>
                      <p style="margin-top: 10px" slot="reference" v-else class="ellipsisTwo">规格：{{item.specifications}}</p>
                    </el-popover>
                    <p class="tag" v-if="item.isCombination=='1' && item.isNewCom !== '1'">组价商品</p>
                    <div class="tag bg-lightSteelBlue" style="width: 70px" v-if="item.isSurchangeFlag === '1'">含附加项</div>
                  </div>
                </div>
              </td>
              <td class="tr">{{item.skuPrice | formatMoney}}</td>
              <td>{{item.fullName}}</td>
              <td>{{item.shortCorpName}}</td>
              <td class="tl">
                <!-- ie文本超出...兼容 -->
                <el-tooltip v-if="item.projectInfos !== '全部' && $isIE()" class="item" effect="dark" placement="bottom-start">
                  <div slot="content" style="overflow-x: hidden;overflow-Y: auto;max-height: 400px;">{{item.projectInfos}}</div>
                  <p class="ellipsisTwo">{{item.projectInfos.length > 44 ? (item.projectInfos.substring(0,44) + '...') : item.projectInfos}}</p>
                </el-tooltip>
                <el-tooltip v-else-if="item.projectInfos !== '全部'" class="item" effect="dark" placement="bottom-start">
                  <div slot="content" style="overflow-x: hidden;overflow-Y: auto;max-height: 400px;">{{item.projectInfos}}</div>
                  <p class="ellipsisTwo">{{item.projectInfos}}</p>
                </el-tooltip>
                <p v-else class="ellipsisTwo">{{item.projectInfos}}</p>
              </td>
              <td v-if="userInfo.contractCorpType === 'broker'">
                <p><span class="blue-pointer" @click="handleBatchOper('',item)">{{pageTag == '0' ? '下架' : '上架'}}</span></p>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="noData" v-if="!ownerProdBeanList.length">
          <p class="f14 grey">暂无信息，请先通过搜索条件搜索！</p>
          <p class="f14 grey" v-if="pageTag == '0'">导出查询结果，需满足「品类」、「供应商」中一个筛选条件，即可导出。</p>
        </div>
        <div class="table-pagination" v-if="ownerProdBeanList.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import DropdownTree from "@/components/order/dropdownTreeTender";
import TableThead from "@/components/base/TableThead";
import accountMixin from "@/mixins/account";
import MultipleSelectorAll from "@/components/base/MultipleSelectorAll";

export default {
  components: {
    Loading, PanelTitle, DropdownTree, TableThead, MultipleSelectorAll
  },
  mixins: [accountMixin],
  data() {
    return {
      isLoading: false,
      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码
      pageTag: '0',//1:上架商品;2:下架商品
      tabs: [
        { label: "上架商品", pageTag: '0', active: true },
        { label: "下架商品", pageTag: '1' }
      ],
      isExport: false,
      allChecked: false,
      hasChecked: false,
      categoryIds: '',
      corpName: '',
      skuNameOrModel: '',//商品名/型号
      prodMobel: '',
      ownerProdBeanList: [],

      projectIds: [],
      projectList: [],
    };
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo || {}
    },
  },
  methods: {
    // 获取项目列表
    getProjectInfo() {
      const params = {
        isNew: '1'
      }
      InterfaceService.getProjectInfo(
        params,
        data => {
          if (data.respData.respCode == "0000") {
            this.projectList = []
            const list = data.respData.projectBseInfos || []
            list.forEach((i, index) => {
              this.projectList.push(i)
              this.$set(this.projectList[index], 'index', i.index)
              this.$set(this.projectList[index], 'checked', false)
            })
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { }, () => { this.isLoading = true }, () => { this.isLoading = false }
      );
    },

    // 获取限定项目
    getSupplierData(val = []) {
      this.projectIds = []
      if (val.length) {
        val.forEach(i => this.projectIds.push(i.projectId))
      }
      // console.log(this.projectIds)
    },
    handleBatchOper(type, item) {
      let num = this.ownerProdBeanList.filter(i => i.checked).length;
      let str = '';
      let title = '';
      let btn = '';
      if (type === 'batch') {
        if (this.pageTag == '1') {
          str = "您已勾选<span class='red'>" + num + "</span>款需上架商品，确定上架后，商品将直接公示，可供采购。上架商品请在【管理中心】-【商品管理-中标商品】-【上架商品】中查看。"
          title = '确认批量上架商品'
        } else {
          str = "您已勾选<span class='red'>" + num + "</span>款需下架商品，确定下架后，商品将不再公开展示，下架商品请在【管理中心】-【商品管理-中标商品】-【下架商品】中查看。"
          title = '确认批量下架商品'
        }
      } else {
        if (this.pageTag == '1') {
          str = "确定上架后，商品将直接公示，可供采购。上架商品在【管理中心】-【商品管理-中标商品】-【上架商品】中查看。"
          title = '确认上架商品'
        } else {
          str = "确定下架后，商品将不再公开展示，下架商品请在【管理中心】-【商品管理-中标商品】-【下架商品】中查看。"
          title = '确认下架商品'
        }
      }
      btn = this.pageTag == '1' ? '确认上架' : '确认下架'
      this.$confirm(
        str,
        title,
        {
          dangerouslyUseHTMLString: true,
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          confirmButtonText: btn,
          cancelButtonText: '取消',
        }).then(() => {
          this.offlineProduct(type, item);
        }).catch(() => {
        });
    },
    offlineProduct(type, item) {
      let bidProductBaseInfos = [];
      if (type !== 'batch') {
        bidProductBaseInfos.push({
          spuId: item.spuId,
          skuId: item.skuId,
          isAngent: item.isAngent,
        });
      } else {
        this.ownerProdBeanList.forEach(_item => {
          if (_item.checked) {
            bidProductBaseInfos.push({
              spuId: _item.spuId,
              skuId: _item.skuId,
              isAngent: _item.isAngent,
            });
          }
        });
      }
      console.log(bidProductBaseInfos);
      const params = {
        bidProductBaseInfos: bidProductBaseInfos,
        approveStatus: this.pageTag == '0' ? '1' : '0',
        approver: this.userInfo.acctId || '',
      };
      console.log(params);
      InterfaceService.onlineAndOffonlineGoods(
        params,
        data => {
          if (data.respCode === "0000") {
            this.$message.success('操作成功！');
            this.search();
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    handleAllSelectTableRow(bool) {
      // let arr = [];
      // arr = [].concat(this.ownerProdBeanList);
      this.ownerProdBeanList.forEach(item => {
        item.checked = bool;
      });
      // this.ownerProdBeanList = arr;
      this.checkBatch();
    },
    // 选中行
    handleSelectTableRow(item, index) {
      this.$set(this.ownerProdBeanList, index, item);
      this.checkBatch();
      this.checkAllSelect();
    },
    // 是否可批量
    checkBatch() {
      this.hasChecked = this.ownerProdBeanList.some(item => {
        return item.checked;
      });
    },
    // 是否全选
    checkAllSelect() {
      this.allChecked = this.ownerProdBeanList.every(item => {
        return item.checked;
      });
      if (!this.ownerProdBeanList.length) {
        this.allChecked = false
      }
    },
    //   切换tab
    handleChangeTab(tab) {
      this.pageTag = String(tab.pageTag)
      this.clear(true)
    },
    handleGoproduct(item) {
      window.open(this.$router.resolve({
        path: "/productDetails",
        query: {
          spuId: item.spuId,
          skuId: item.skuId,
          corpId: item.corpId
        }
      }).href, '_blank')
    },
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.bidProductList()
      window.scrollTo(0, 0)
    },
    // 获取招标品类
    getCategoryInfo(info) {
      console.log(info)
      let categoryIds = []
      info.forEach(f => {
        // 入参处理
        categoryIds.push(f.categoryId)
      })
      this.categoryIds = categoryIds.join(',')
    },
    // 下载供方货品库
    downloadSupplierGoodsTemp() {
      let param = {
        // supplierId: supplierId,
        categoryIds: this.categoryIds,
        corpName: this.corpName,
        skuNameOrModel: this.skuNameOrModel,//商品名/型号
        handleType: '1',
      }
      if (this.projectIds.length !== this.projectList.length) {
        param.projectIds = this.projectIds
      } else {
        param.isUsedAll = '1'
      }
      InterfaceService.downloadSupplierGoodsTemp(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          const attachUrl = data.respData.attachUrl || ''
          const attachName = '中标商品查询导出表' + this.$formatTime(new Date().getTime(), 'YYYYMMDDhhiiss') + '.xlsx'
          console.log(attachName)
          if (!attachUrl) {
            this.$message.error('暂无导出查询结果！')
          } else {
            this.$download([{ url: attachUrl, name: attachName }]).then(res => {
              this.$message.success("已下载");
            }).catch(res => {
              this.$message.error("下载失败");
            })
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 材料公司_中标商品列表
    bidProductList(type) {
      let param = {
        categoryIds: this.categoryIds,
        corpName: this.corpName,
        skuNameOrModel: this.skuNameOrModel,//商品名/型号
        prodMobel: this.prodMobel,
        pageIndex: this.pageIndex,
        pageTag: this.pageTag,
      }
      if (type !== 'init') {
        if (this.projectIds.length !== this.projectList.length) {
          param.projectIds = this.projectIds
        } else {
          param.isUsedAll = '1'
        }
      }
      InterfaceService.bidProductList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.ownerProdBeanList = data.respData.ownerProdBeanList || []
          if ((this.categoryIds || this.corpName) && this.ownerProdBeanList.length) {
            this.isExport = true
          } else {
            this.isExport = false
          }
          this.ownerProdBeanList.forEach(item => {
            this.$set(item, 'checked', false)
          });
          this.total = data.respData.totalCount
          this.pageSize = data.respData.pageSize;
          this.checkAllSelect()
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    search() {
      if (!this.categoryIds && !this.corpName) {
        return this.$message.error('品类、供应商搜索条件需至少选择一个进行搜索！')
      }
      this.pageIndex = 1
      this.bidProductList()
    },
    clear(unClearIds) {
      // unClearIds: 不清除 categoryIds
      !unClearIds && (this.categoryIds = '')
      !unClearIds && this.$refs.dropdownTree.clear()
      this.corpName = ''
      this.prodMobel = ''
      this.skuNameOrModel = ''//商品名/型号
      this.pageIndex = 1
      this.projectIds = []
      this.$refs.multipleSelectorAll.clear()
      this.bidProductList()
    },
    init() {
      this.getProjectInfo()
      this.bidProductList('init')
    },
  },
  mounted() {
    this.init()
  },
  destroyed() {
  }
};
</script>

<style lang="scss" scoped>
/deep/ .seatchW-width {
  width: inherit;
  width: initial;
  .el-form-item__content {
    width: 240px !important;
  }
  // &:nth-child(2) {
  //   .el-form-item__label {
  //     width: 130px !important;
  //   }
  //   .el-form-item__content {
  //     margin-left: 130px !important;
  //   }
  // }
}
.bidProduct {
  /*width: 950px;*/
  margin: 0 auto;
  padding-bottom: 60px;
  .box_type {
    width: 100%;
    //   height: 42px;
    background: rgba(255, 252, 240, 1);
    border: 1px solid rgba(250, 226, 165, 1);
    font-size: 12px;
    line-height: 17px;
    color: #444444;
    padding: 11px 10px;
    margin: -10px 0;
  }
  .list-content {
    .panel {
      background-color: #fff;
      background: rgba(249, 249, 249, 1);
      padding: 20px 10px;
      margin: 10px 0 30px;
    }

    .table-default {
      td {
        .skuName {
          display: flex;
          .attachImg {
            width: 60px;
            height: 60px;
            min-width: 60px;
            position: relative;
            overflow: hidden;
            &.active {
              background-color: #eee;
            }
            > img {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              pointer-events: none;
              height: auto;
            }
          }
          .model {
            margin-left: 6px;
          }
        }
      }
    }
    .noData {
      padding-top: 100px;
      > p {
        text-align: center;
        margin-bottom: 8px;
      }
    }
  }
}
</style>
