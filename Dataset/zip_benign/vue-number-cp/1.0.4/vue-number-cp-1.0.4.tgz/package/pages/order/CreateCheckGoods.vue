<template>
    <CheckGoods type="create"></CheckGoods>
</template>

<script>
import CheckGoods from "@/components/order/CheckGoods";
export default {
    components: {
        CheckGoods
    },
    mounted() {
    }
};
</script>

<style lang="scss" scoped>
</style>
